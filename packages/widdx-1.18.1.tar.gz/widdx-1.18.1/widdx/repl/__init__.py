"""WIDDX REPL — professional autonomous AI engineering terminal."""
from __future__ import annotations

import json
import logging
import os
import signal
import time
from datetime import datetime

logger = logging.getLogger("widdx.repl")
from pathlib import Path
from typing import Any

try:
    import winsound
    _has_winsound = True
except ImportError:
    winsound = None  # type: ignore[assignment]
    _has_winsound = False

from rich.panel import Panel
from rich.box import ROUNDED
from rich.text import Text

from .. import ui
from ..classifier import classify as _classify_intent
from ..git_ops import GitOps
from ..indexer import ProjectIndexer
from ..memory import MemoryStore
from ..router import AIRouter
from ..self_learning import SelfLearningEngine
from ..tool_loop import ToolLoop
from ..tool_loop.display import _short_path_display
from .commands import (
    _handle_command,
    _resume,
    _run_agents,
    _search,
    _send_to_llm,
    _show_git,
    _show_help,
    _show_learning,
    _show_model_info,
    _show_task_history,
    _undo,
)
from .context import (
    _check_git_status,
    _estimate_complexity,
    _expand_context_shortcuts,
    _index_project,
    _load_project_md,
)


class WIDDXRepl:
    """Autonomous AI Engineering OS — interactive terminal agent."""

    # ── Injected methods ───────────────────────────────────────────
    _handle_command       = _handle_command
    _show_help            = _show_help
    _show_git             = _show_git
    _search               = _search
    _undo                 = _undo
    _show_model_info      = _show_model_info
    _show_task_history    = _show_task_history
    _send_to_llm          = _send_to_llm
    _run_agents           = _run_agents
    _resume               = _resume
    _show_learning        = _show_learning
    _expand_context_shortcuts = _expand_context_shortcuts
    _index_project        = _index_project
    _check_git_status     = _check_git_status
    _estimate_complexity  = _estimate_complexity
    _load_project_md      = _load_project_md

    def __init__(
        self,
        router: AIRouter,
        config: dict[str, Any],
        memory: MemoryStore | None = None,
        initial_task: str | None = None,
        fast_mode: bool = False,
        pipeline_depth: int = 0,
    ) -> None:
        self._router = router
        self._config = config
        self._fast_mode = fast_mode
        self._pipeline_depth = pipeline_depth
        self._tool_loop = ToolLoop(router)
        self._indexer = ProjectIndexer()
        self._git = GitOps()
        self._memory = memory or MemoryStore(
            config.get("memory", {}).get("db_path", "~/.widdx/memory.db")
        )
        self._streaming = True
        self._messages: list[dict] = []
        self._initial_task = initial_task
        self._task_count = 0
        self._last_result = ""
        self._last_task_info: dict[str, Any] = {}
        self._project_md = ""
        self._interrupt_pending = False
        sessions_dir = Path("~/.widdx/sessions").expanduser()
        sessions_dir.mkdir(parents=True, exist_ok=True)
        self._sessions_dir = sessions_dir
        self._self_learning = SelfLearningEngine(self._memory, config)
        self._toast = ui.ToastNotificationManager(ui.get_console())
        self._dashboard = ui.TaskDashboard(ui.get_console())
        self._status_bar = ui.StatusBar(ui.get_console())

    # ── Lifecycle ──────────────────────────────────────────────────

    def _show_provider_boot(self) -> None:
        """Skip provider selector on first run — show API key warning instead."""
        if self._config.get("boot_providers_shown"):
            return
        self._config["boot_providers_shown"] = True
        # Provider selector is available via /providers command

    def run(self) -> None:
        self._setup()
        _mark_crash_session()
        self._handle_interrupt_signal()
        self._show_provider_boot()
        if self._initial_task:
            self._execute_task(self._initial_task)
        self._main_loop()

    def _setup(self) -> None:
        c = ui.get_console()
        c.print()
        self._load_project_md()
        if self._project_md:
            self._tool_loop.set_project_md(self._project_md)
        self._index_project()
        self._check_git_status()

        # Seed bottom toolbar
        models = self._config.get("models", {})
        exec_model = models.get("executor", {}).get("model", "deepseek")
        ui.update_toolbar(model=exec_model, cwd=os.path.basename(os.getcwd()))

        # Show key status
        dsk = self._config.get("__env__", {}).get("deepseek_key")
        gk = self._config.get("__env__", {}).get("google_key")
        if not dsk and not gk:
            ui.system_bubble("No API keys — AI won't work. Run [warning]/key[/] to set one.")

        providers = self._router.list_providers()
        active = sum(1 for p in providers if p.get("enabled", True))
        total = len(providers)

        status = f"  [dim]{ui.drawing._os_label()}[/]  [dim]·[/]  [brand]{active}/{total}[/] [dim]providers[/]"
        if dsk:
            masked = dsk[:8] + "..." + dsk[-4:]
            status += f"  [dim]·[/]  [success]deepseek ✓[/]"
        if gk:
            masked_g = gk[:8] + "..." + gk[-4:]
            status += f"  [dim]·[/]  [success]google ✓[/]"
        c.print(status)
        c.print(f"  [dim]Type a task or [brand]/help[/] for commands.[/]")
        c.print()

        hook_manager = getattr(self._tool_loop, "_hook_manager", None)
        if hook_manager is not None:
            hook_manager.fire("SessionStart", {})

    def _handle_interrupt_signal(self) -> None:
        signal.signal(signal.SIGINT, self._handle_interrupt)

    # ── Main loop ──────────────────────────────────────────────────

    def _main_loop(self) -> None:
        while True:
            try:
                user_input = ui.prompt("widdx")
            except (EOFError, KeyboardInterrupt):
                self._exit()
                break

            user_input = user_input.strip()
            if not user_input:
                continue

            if user_input.startswith("/"):
                if self._handle_command(user_input):
                    break
            else:
                self._execute_task(user_input)
                ui.get_console().print()

    def _execute_task(self, task: str) -> None:
        self._task_count += 1
        expanded_task = self._expand_context_shortcuts(task)
        task_id = os.urandom(6).hex()
        complexity = self._estimate_complexity(task)
        task_type = self._router.infer_task_type(task)
        self._memory.create_task(task_id, task, task_type, complexity)
        c = ui.get_console()
        start = time.time()

        # ── Classify intent ─────────────────────────────────────
        history = [m.get("content", "") for m in self._messages if m.get("role") == "user"]
        mode = _classify_intent(task, history=history)

        if mode == "chat":
            # Chat mode: respond conversationally, no tool loop
            result = self._send_to_llm(task)
            self._last_result = result
            elapsed = time.time() - start
            self._show_task_feedback(task, task_id, elapsed, complexity)
            self._refresh_toolbar()
            return

        if mode == "spec":
            # Spec mode: plan-driven development
            result = self._tool_loop.run(
                expanded_task, conversation_history=self._messages, mode="spec"
            )
            self._messages = self._tool_loop._messages
            self._last_result = result
            elapsed = time.time() - start
            self._show_task_feedback(task, task_id, elapsed, complexity)
            self._refresh_toolbar()
            return

        # ── Do mode (default: full tool loop with vibe prompt) ──
        ui.task_start(task)

        lowered = task.lower()
        is_build_task = any(kw in lowered for kw in
                            ["build a", "create a full", "fullstack", "complete project",
                             "entire app", "saas", "platform", "full-stack"])
        if not (complexity >= 4 and is_build_task):
            self._run_repl_scaffolding(task)

        use_pipeline = (complexity >= 4 and is_build_task) and not self._fast_mode
        if use_pipeline:
            result = self._run_pipeline_task(task, task_id)
        else:
            result = self._tool_loop.run(
                expanded_task, conversation_history=self._messages, mode="do"
            )
            self._messages = self._tool_loop._messages

        self._last_result = result
        elapsed = time.time() - start

        # ── Completion feedback ──────────────────────────────────
        self._show_task_feedback(task, task_id, elapsed, complexity)

        # ── Fire hooks ───────────────────────────────────────────
        hook_manager = getattr(self._tool_loop, "_hook_manager", None)
        if hook_manager is not None:
            hook_manager.fire_async("TaskCompleted", {
                "task": task,
                "result": self._last_result[:200] if self._last_result else "",
            })

        # ── Persist state ────────────────────────────────────────
        files_touched = list(dict.fromkeys(
            self._tool_loop._created_files + self._tool_loop._edited_files
        ))
        result_preview = (self._last_result or "")[:500]
        success = bool(result_preview.strip()) and not any(kw in result_preview.lower() for kw in ["api error:", "no ai provider", "all providers"])
        self._memory.complete_task(task_id, "completed" if success else "failed")

        self._persist_state(files_touched)
        self._self_learning.record_task(
            task_id=task_id,
            command=task,
            result_summary=result_preview,
            provider=getattr(self._router, "_last_provider", ""),
            files_touched=files_touched,
            tool_calls=self._tool_loop._tool_calls_count,
            success=success,
            complexity=complexity,
        )

        # ── Update toolbar + prompt context ──────────────────────
        self._refresh_toolbar()
        self._last_task_info = {
            "task": task[:60],
            "elapsed": elapsed,
            "tools": self._tool_loop._tool_calls_count,
            "files": len(files_touched),
            "success": success,
            "complexity": complexity,
        }

        # ── Show file changes ────────────────────────────────────
        had_tool_calls = self._tool_loop._tool_calls_count > 0
        if had_tool_calls or files_touched:
            c.print()
            if files_touched:
                self._show_changes()
        c.print()

    # ── Task feedback ────────────────────────────────────────────────

    def _show_task_feedback(self, task: str, task_id: str, elapsed: float, complexity: int) -> None:
        """Show clean completion feedback: elapsed time, tool stats, toast, bell."""
        c = ui.get_console()
        tool_count = self._tool_loop._tool_calls_count
        files = self._tool_loop._created_files + self._tool_loop._edited_files
        result_preview = (self._last_result or "")[:500]
        success = bool(result_preview.strip()) and not any(kw in result_preview.lower() for kw in ["api error:", "no ai provider", "all providers"])

        if elapsed < 1:
            elapsed_str = f"{int(elapsed * 1000)}ms"
        elif elapsed < 60:
            elapsed_str = f"{elapsed:.1f}s"
        else:
            elapsed_str = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"

        icon = "[success]✓[/]" if success else "[error]✗[/]"
        status = "[success]completed[/]" if success else "[error]failed[/]"
        c.print()
        parts = [f"  {icon} {status}"]
        parts.append(f"[dim]in[/] [brand]{elapsed_str}[/]")
        if tool_count:
            parts.append(f"[dim]·[/] [brand]{tool_count}[/] [dim]tools[/]")
        if files:
            parts.append(f"[dim]·[/] [brand]{len(set(files))}[/] [dim]files[/]")
        c.print(" ".join(parts))

        if elapsed > 10:
            try:
                if _has_winsound:
                    winsound.Beep(1200, 80)
                    time.sleep(0.06)
                    winsound.Beep(1600, 120)
                else:
                    c.print("\a", end="")
            except Exception:
                pass

        if elapsed > 5:
            try:
                if success:
                    self._toast.success(f"Done in {elapsed_str}  ·  {tool_count} tools", duration=4.0)
                else:
                    self._toast.error(f"Failed after {elapsed_str}", duration=6.0)
            except Exception:
                pass

    def _persist_state(self, files_touched: list[str]) -> None:
        """Save project state and session snapshot."""
        try:
            from ..project_state import load_state, save_state, ProjectState
            existing = load_state()
            if existing is not None:
                existing.phases_completed += 1
                existing.files_created.extend(files_touched)
                save_state(existing)
            else:
                state = ProjectState(
                    project_name=Path.cwd().name,
                    files_created=files_touched,
                )
                save_state(state)
        except Exception as e:
            logger.warning("Failed to persist project state: %s", e)

        if self._messages:
            try:
                from ..project_state import save_session_snapshot
                save_session_snapshot(self._messages)
            except Exception as e:
                logger.warning("Failed to save session snapshot: %s", e)

    def _refresh_toolbar(self) -> None:
        """Update the bottom toolbar with latest session metrics."""
        tokens = self._router.session_tokens
        cost = self._router.session_cost
        total_tok = tokens["input"] + tokens["output"]
        tok_str = f"{total_tok / 1000:.1f}k" if total_tok >= 1000 else str(total_tok)

        last_info = self._last_task_info
        if last_info:
            elapsed = last_info.get("elapsed", 0)
            if elapsed < 60:
                et = f"{elapsed:.0f}s"
            else:
                et = f"{int(elapsed//60)}m{int(elapsed%60)}s"
            lt = last_info.get("task", "")[:30]
            success = last_info.get("success", True)
            icon = "✓" if success else "✗"
            last_hint = f"{icon} {lt} ({et})"
        else:
            last_hint = ""

        ui.update_toolbar(
            tokens=tok_str,
            cost=f"${cost:.4f}" if cost > 0 else "",
            last_task=last_hint,
        )

    # ── Preflight / scaffolding ──────────────────────────────────────

    def _run_repl_scaffolding(self, task: str) -> None:
        """Automatically scaffold the project if it is empty and a framework is detected."""
        from pathlib import Path

        # Only scaffold for empty directories
        cwd = Path.cwd()
        non_hidden = [f for f in cwd.iterdir() if not f.name.startswith(".")]
        if non_hidden:
            return

        from ..scaffolder import scaffold
        result = scaffold(task, router=self._router)
        if result.installed:
            from widdx import ui
            ui.get_console().print(
                f"  [success]✓[/] {result.framework} scaffolding complete — ready to build"
            )

    def _run_pipeline_task(self, task: str, task_id: str) -> str:
        """Run a complex build task through the full multi-agent pipeline."""
        from ..agent_factory import AgentFactory
        from ..evolution import EvolutionEngine
        from ..pipeline import ExecutionPipeline

        c = ui.get_console()
        start = time.time()

        panel = Panel(
            Text("Assembling team · analyzing requirements...", style="muted"),
            title="[bold brand]⚡ MULTI-AGENT PIPELINE[/]",
            border_style="brand", box=ROUNDED, padding=(1, 2),
        )
        c.print(); c.print(panel)

        agent_factory = AgentFactory(self._router)
        evolution = EvolutionEngine(self._memory, self._config)
        pd = self._pipeline_depth or (1 if self._fast_mode else 0)
        pipeline = ExecutionPipeline(
            self._router, agent_factory, self._memory, evolution, self._config,
            pipeline_depth=pd,
        )

        try:
            result = pipeline.run(task)
            output = result.execution_output or "Pipeline completed."
        except Exception as exc:
            c.print(f"  [error]✗ Pipeline failed: {exc}[/]")
            return f"Pipeline error: {exc}"

        elapsed = time.time() - start
        elapsed_str = f"{int(elapsed//60)}m {int(elapsed%60)}s" if elapsed > 60 else f"{elapsed:.0f}s"

        depth = getattr(result, "pipeline_depth", 0)
        agents = getattr(result, "agents_generated", [])
        output = result.execution_output or ""
        has_content = bool(output.strip()) and "Pipeline completed." not in output

        c.print()
        if not has_content:
            c.print(f"  [warning]⚠ Pipeline finished but no project files were created[/]")
            if output:
                c.print(f"  [dim]{output[:500]}[/]")
        else:
            parts = [f"  [success]✓ Pipeline done[/]"]
            parts.append(f"[dim]in[/] [brand]{elapsed_str}[/]")
            if depth:
                parts.append(f"[dim]· depth[/] [brand]{depth}[/]")
            if agents:
                parts.append(f"[dim]·[/] [brand]{len(agents)}[/] [dim]agents[/]")
            c.print(" ".join(parts))

        if result.plan:
            try:
                from ..project_state import get_widdx_dir
                widdx_dir = get_widdx_dir()
                (widdx_dir / "plan.json").write_text(
                    __import__("json").dumps(result.plan, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception:
                pass

        c.print()
        c.print(Panel(
            Text(f"✓ Pipeline complete · {elapsed_str}", style="success"),
            border_style="success", padding=(0, 2),
        ))
        return output

    def _show_changes(self) -> None:
        """Display created/edited files with professional indicators."""
        created = self._tool_loop._created_files
        edited  = self._tool_loop._edited_files
        seen: set[str] = set()
        all_files: list[tuple[str, str]] = []
        for f in created:
            if f not in seen:
                all_files.append((f, "created"))
                seen.add(f)
        for f in edited:
            if f not in seen:
                all_files.append((f, "edited"))
                seen.add(f)

        if not all_files:
            return

        c = ui.get_console()
        c.print()

        try:
            from rich.table import Table
            from rich.box import SIMPLE

            table = Table(box=SIMPLE, show_header=False, padding=(0, 2))
            table.add_column("", style="bold", width=2)
            table.add_column("File", style="white", width=50)
            table.add_column("Action", style="dim", justify="right")

            shown = 0
            for f, action in all_files:
                if shown >= 12:
                    break
                if action == "created":
                    table.add_row("[success]+[/]", f, "[success]new[/]")
                else:
                    table.add_row("[warning]~[/]", f, "[warning]updated[/]")
                shown += 1
            c.print(table)
        except Exception:
            shown = 0
            for f, action in all_files:
                if shown >= 12:
                    break
                path = _short_path_display(f)
                if action == "created":
                    c.print(f"  [success]+ {path}[/]")
                else:
                    c.print(f"  [warning]~ {path}[/]")
                shown += 1

        remaining = len(all_files) - shown
        if remaining > 0:
            c.print(f"  [dim]  ... and {remaining} more file{'s' if remaining != 1 else ''}[/]")

        created_count = sum(1 for _, a in all_files if a == "created")
        edited_count = sum(1 for _, a in all_files if a == "edited")
        total = created_count + edited_count
        if total > 0:
            parts = []
            if created_count:
                parts.append(f"[success]{created_count} created[/]")
            if edited_count:
                parts.append(f"[warning]{edited_count} updated[/]")
            c.print(f"\n  [dim]Files: {' · '.join(parts)}[/]")

    # ── Session persistence ────────────────────────────────────────

    def _save_session(self, name: str | None = None) -> str:
        ts = datetime.now()
        filename = f"{name}.json" if name else f"session_{ts.strftime('%Y%m%d_%H%M%S')}.json"
        path = self._sessions_dir / filename
        data = {
            "version": 1,
            "saved_at": ts.isoformat(),
            "cwd": str(Path.cwd()),
            "task_count": self._task_count,
            "project_md": self._project_md[:1000] if self._project_md else "",
            "messages": self._messages,
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def _load_session(self, name: str) -> bool:
        if not name.endswith(".json"):
            name = f"{name}.json"
        path = self._sessions_dir / name
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return False
        if data.get("version") != 1:
            return False
        self._messages = data.get("messages", [])
        self._tool_loop._messages = list(self._messages)
        self._task_count = data.get("task_count", 0)
        self._project_md = data.get("project_md", "")
        return True

    def _list_sessions(self) -> list[dict]:
        sessions: list[dict] = []
        for f in sorted(self._sessions_dir.glob("*.json"),
                        key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            sessions.append({
                "name": f.stem,
                "saved_at": data.get("saved_at", ""),
                "task_count": data.get("task_count", 0),
                "msg_count": len(data.get("messages", [])),
                "cwd": data.get("cwd", ""),
            })
        return sessions

    # ── Exit / interrupt ───────────────────────────────────────────

    def _exit(self) -> None:
        # Clean up crash marker on normal exit
        _clear_crash_marker()
        self._tool_loop.shutdown()
        if self._messages:
            path = self._save_session()
            ui.get_console().print(f"  [dim]◈ Session saved → {Path(path).name}[/]")
        ui.get_console().print()
        ui.get_console().print("  [dim]Goodbye.[/]")
        ui.get_console().print()

    def _handle_interrupt(self, sig, frame) -> None:
        if getattr(self, "_interrupt_pending", False):
            self._exit()
            import sys
            sys.exit(0)
        self._interrupt_pending = True
        ui.get_console().print("\n\n  [dim]◈ Ctrl+C again to exit.[/]")
        signal.signal(signal.SIGINT, self._handle_interrupt)


def _mark_crash_session() -> None:
    """Write a crash marker so next launch can offer recovery."""
    try:
        d = Path.home() / ".widdx"
        d.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        (d / ".crash_session").write_text(ts)
    except OSError:
        pass


def _clear_crash_marker() -> None:
    try:
        p = Path.home() / ".widdx" / ".crash_session"
        p.unlink(missing_ok=True)
    except OSError:
        pass
