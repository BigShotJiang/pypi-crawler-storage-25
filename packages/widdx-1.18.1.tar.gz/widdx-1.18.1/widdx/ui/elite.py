"""WIDDX Elite v2 — unified modern terminal UI with chat bubbles,
live dashboard, smooth animations, and consistent Rich theme styles."""

from __future__ import annotations

import random
import shutil
import time
from datetime import datetime

from rich.align import Align
from rich.box import ROUNDED, SIMPLE
from rich.columns import Columns
from rich.layout import Layout
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.rule import Rule
from rich.spinner import Spinner
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

from .theme import get_console


# ── Dividers ───────────────────────────────────────────────────────────

def hr(title: str = "", style: str = "dim") -> Rule:
    return Rule(title, style=style, align="center") if title else Rule(style=style)

def gap(n: int = 1) -> None:
    for _ in range(n):
        get_console().print()


# ── Message Bubbles (chat-style, with timestamps) ─────────────────────

def user_bubble(text: str) -> None:
    c = get_console()
    ts = datetime.now().strftime("%H:%M")
    head = Text()
    head.append(" YOU ", style="bold #7b7bff on #0d0d1f")
    head.append(f" {ts}", style="dim")
    c.print()
    c.print(head)
    c.print(Panel(Text(text, style="text"), border_style="info",
                   box=ROUNDED, padding=(0, 1)))

def ai_bubble(text: str, role: str = "AI") -> None:
    c = get_console()
    ts = datetime.now().strftime("%H:%M")
    head = Text()
    head.append(f" {role} ", style="bold #00c896 on #001a0f")
    head.append(f" {ts}", style="dim")
    c.print()
    c.print(head)
    c.print(Panel(Text.from_markup(text), border_style="success",
                   box=ROUNDED, padding=(0, 1)))

def system_bubble(text: str) -> None:
    c = get_console()
    c.print()
    c.print(Panel(Text.from_markup(text, style="warning"),
                   border_style="warning", title="[warning]system[/]",
                   title_align="left", box=ROUNDED, padding=(0, 1)))


# ── Tool Execution (animated) ─────────────────────────────────────────

def tool_anim(tools: list[str]) -> None:
    """Show tools executing with live animation → permanent checkmark."""
    c = get_console()
    for t in tools:
        with Live(Text(f"  ▶ {t}...", style="dim"), console=c,
                  refresh_per_second=10, transient=True):
            time.sleep(random.uniform(0.15, 0.4))
        c.print(Text(f"  ✓ {t}", style="success"))


# ── Thinking Spinner ──────────────────────────────────────────────────

def thinking_spinner(seconds: float = 1.2) -> None:
    c = get_console()
    with Live(
        Spinner("dots", text=Text(" thinking...", style="dim"), style="success"),
        console=c, refresh_per_second=12, transient=True,
    ):
        time.sleep(seconds)


# ── Live Dashboard ─────────────────────────────────────────────────────

def dashboard_layout() -> Layout:
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="body"),
        Layout(name="footer", size=3),
    )
    layout["body"].split_row(Layout(name="left"), Layout(name="right"))
    return layout

def dash_header(title: str = "WIDDX") -> Panel:
    return Panel(Text(title, justify="center", style="bold brand"),
                 style="brand")

def dash_metrics(data: dict) -> Panel:
    t = Table(box=None, show_header=False, padding=(0, 2))
    t.add_column("k", style="muted", min_width=12)
    t.add_column("v", style="bold text")
    for k, v in data.items():
        t.add_row(k, str(v))
    return Panel(t, title="[bold brand]Metrics[/]", border_style="brand")

def dash_log(lines: list[str]) -> Panel:
    txt = Text()
    for line in lines[-20:]:
        if "[ERROR]" in line:
            txt.append(line + "\n", style="error")
        elif "[WARN]" in line:
            txt.append(line + "\n", style="warning")
        elif "[SUCCESS]" in line:
            txt.append(line + "\n", style="success")
        elif "[DEBUG]" in line:
            txt.append(line + "\n", style="dim")
        else:
            txt.append(line + "\n", style="muted")
    return Panel(txt, title="[bold]Log[/]", border_style="dim")

def dash_board(items: list[dict]) -> Columns:
    panels = []
    for item in items:
        color = "success" if item.get("status") == "done" else "warning"
        content = Text()
        content.append("Status: ", style="muted")
        content.append(item.get("status", "?"), style=f"bold {color}")
        panels.append(Panel(content, title=f"[bold]{item['name']}[/]",
                            border_style=color, width=24))
    return Columns(panels)

def dash_progress(tasks: list[dict]) -> Progress:
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold]{task.description:<20}"),
        BarColumn(bar_width=30),
        TextColumn("[accent]{task.completed:>3}/{task.total}"),
        TimeElapsedColumn(),
        console=get_console(),
        refresh_per_second=10,
    )

def dash_run(update_fn, refresh: float = 0.25) -> None:
    layout = dashboard_layout()
    c = get_console()
    try:
        with Live(layout, refresh_per_second=4, screen=True, console=c) as live:
            while True:
                update_fn(layout)
                time.sleep(refresh)
    except (KeyboardInterrupt, SystemExit):
        c.print()
        c.print(hr(style="dim"))
        c.print(Align.center(Text("Dashboard closed", style="muted")))


# ── Boot Screen ───────────────────────────────────────────────────────

def elite_boot(framework: str = "python", files: int = 0,
               version: str = "1.15.0", model: str = "") -> None:
    c = get_console()

    c.print()
    c.print("  [bold brand]◆[/]  [dim]W  I  D  D  X[/]")
    c.print("  [dim]   autonomous AI terminal[/]")

    info = Text()
    info.append(f" {framework} ", style="bold brand")
    info.append(" · ", style="dim")
    info.append(f"{files} files", style="muted")
    if model:
        info.append(" · ", style="dim")
        info.append(model, style="muted")
    c.print()
    c.print(Align.center(info))

    c.print()
    cmds = Text()
    for k, d in [("Esc", "skip"), ("↵", "start"), ("task", "work"), ("/help", "cmds")]:
        cmds.append(f" {k} ", style="bold brand")
        cmds.append(f" {d}  ", style="muted")
    c.print(Align.center(cmds))
    c.print()


# ── Chat Welcome ──────────────────────────────────────────────────────

def welcome(framework: str, files: int) -> None:
    c = get_console()
    c.print()
    c.print(hr("Session"))
    c.print(f"  [muted]framework:[/] [brand]{framework}[/]  [dim]·[/]  [muted]files:[/] [brand]{files}[/]")
    c.print(f"  [dim]Type your task or [brand]/help[/] for commands.[/]")
    c.print()


# ── Status Messages ───────────────────────────────────────────────────

def ok(msg: str) -> None:
    get_console().print(f"  [success]✓[/] [text]{msg}[/]")

def fail(msg: str) -> None:
    get_console().print(f"  [error]✗[/] [error]{msg}[/]")

def warn(msg: str) -> None:
    get_console().print(f"  [warning]▲[/] [warning]{msg}[/]")


# ── Tool Calling ──────────────────────────────────────────────────────

_TOOLS = {
    "read": ("📖", "tool_read"),
    "write": ("✏️", "tool_write"),
    "shell": ("⚡", "tool_shell"),
    "web": ("🌐", "tool_web"),
    "search": ("🔍", "tool_read"),
    "git": ("📦", "tool_write"),
}

def tool(name: str, detail: str = "") -> str:
    nl = name.lower()
    for k, (icon, color) in _TOOLS.items():
        if k in nl:
            return f"  [dim]{icon}[/] [{color}]{name}[/][dim]{' ' + detail if detail else ''}[/]"
    return f"  [dim]◈[/] [info]{name}[/][dim]{' ' + detail if detail else ''}[/]"


# ── Syntax Highlighting ────────────────────────────────────────────────

def code(code_str: str, lang: str = "python", title: str = "") -> Panel:
    return Panel(
        Syntax(code_str, lang, theme="monokai", line_numbers=True),
        title=f"[dim]{title}[/]" if title else None,
        title_align="left", border_style="dim", box=ROUNDED, padding=(1, 2),
    )


# ── Help Table ─────────────────────────────────────────────────────────

def help_table(commands: dict) -> None:
    c = get_console()
    t = Table(title="[bold brand]Commands[/]", border_style="dim",
              header_style="bold warning", box=SIMPLE)
    t.add_column("Command", style="bold brand", min_width=14)
    t.add_column("Description", style="text")
    for cmd, desc in commands.items():
        t.add_row(cmd, desc)
    c.print(t)


# ── File Tree ──────────────────────────────────────────────────────────

def file_tree(paths: list[str], root_name: str = "project") -> Tree:
    tree = Tree(f"[bold brand]{root_name}/[/]")
    by_dir: dict[str, list[str]] = {}
    for p in sorted(paths):
        parts = p.replace("\\", "/").split("/")
        d = "/".join(parts[:-1]) if len(parts) > 1 else "."
        by_dir.setdefault(d, []).append(parts[-1])
    for d, files in sorted(by_dir.items()):
        node = tree
        if d != ".":
            for part in d.split("/"):
                node = next(
                    (c for c in node.children if c.label and part in str(c.label)),
                    node.add(f"[info]{part}/[/]"),
                )
        for f in files[:20]:
            ext = f.rsplit(".", 1)[-1] if "." in f else ""
            icon = {
                "py": "🐍", "js": "🟨", "ts": "🔷",
                "md": "📝", "json": "📋", "yaml": "⚙️",
            }.get(ext, "📄")
            node.add(f"[muted]{icon}[/] {f}")
    return tree
