"""SMG gRPC servicer implementations."""
