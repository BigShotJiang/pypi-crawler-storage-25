"""Utility MCP tools — markdown writing, env, tool listing."""

import json
import os

from hooks.common import log
from hooks.config import AGENTIHOOKS_HOME


def register(mcp):
    @mcp.tool()
    def write_markdown(filepath: str, content: str) -> str:
        """Write a markdown file.

        MANDATORY tool for docgen agent - Write tool is blocked for markdown files.

        Args:
            filepath: Path to write (must be .md extension, under $AGENTIHOOKS_HOME/package or /tmp)
            content: Markdown content to write

        Returns:
            JSON with write result
        """
        try:
            from pathlib import Path

            path = Path(filepath)
            if path.suffix.lower() != ".md":
                return json.dumps({"success": False, "error": f"Only .md files allowed, got: '{path.suffix}'"})

            resolved = path.resolve()
            allowed_prefixes = [str(AGENTIHOOKS_HOME / "package"), "/tmp"]
            if not any(str(resolved).startswith(p) for p in allowed_prefixes):
                return json.dumps(
                    {"success": False, "error": f"Path not allowed. Must be under: {allowed_prefixes}. Got: {resolved}"}
                )

            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            bytes_written = len(content.encode("utf-8"))

            log(
                "MCP write_markdown completed",
                {"filepath": str(path), "bytes_written": bytes_written},
            )

            return json.dumps(
                {
                    "success": True,
                    "filepath": str(path),
                    "bytes_written": bytes_written,
                }
            )

        except Exception as e:
            log("MCP write_markdown failed", {"filepath": filepath, "error": str(e)})
            return json.dumps({"success": False, "error": str(e)})

    @mcp.tool()
    def get_env(filter: str = "") -> str:
        """Get environment variables, filtered by a substring.

        A non-empty filter is REQUIRED. Values of sensitive keys are redacted.

        Args:
            filter: Substring to filter environment variable names (case-insensitive). Required.

        Returns:
            JSON with matching environment variables (names and redacted values)
        """
        import re as _re

        if not filter or len(filter) < 2:
            return json.dumps(
                {
                    "success": False,
                    "error": "A filter of at least 2 characters is required. Full env dump is not allowed.",
                }
            )

        _SECRET_PATTERN = _re.compile(
            r"(key|secret|token|password|credential|dsn|auth|private|signing)", _re.IGNORECASE
        )

        try:
            env_vars = dict(os.environ)
            filter_lower = filter.lower()
            filtered_vars = {}
            for k, v in env_vars.items():
                if filter_lower not in k.lower():
                    continue
                if _SECRET_PATTERN.search(k):
                    filtered_vars[k] = "[REDACTED]"
                else:
                    filtered_vars[k] = v

            return json.dumps(
                {
                    "success": True,
                    "filter": filter,
                    "count": len(filtered_vars),
                    "variables": filtered_vars,
                }
            )

        except Exception as e:
            log("MCP get_env failed", {"filter": filter, "error": str(e)})
            return json.dumps({"success": False, "error": str(e)})

    @mcp.tool()
    def hooks_list_tools() -> str:
        """List all available MCP tools in this server.

        Returns:
            JSON with tool names grouped by category
        """
        from hooks.mcp._registry import CATEGORY_MODULES

        tools = {
            "aws": [
                "aws_get_profiles",
                "aws_get_account_id",
                "aws_find_account",
            ],
            "email": [
                "email_send",
            ],
            "storage": [
                "storage_upload_path",
            ],
            "database": [
                "dynamodb_put_item",
                "postgres_execute",
            ],
            "compute": [
                "lambda_invoke_function",
            ],
            "observability": [
                "read_session_logs",
                "tail_container_logs",
            ],
            "channels": [
                "channel_publish",
                "channel_list",
                "channel_subscribe",
                "channel_unsubscribe",
                "brain_refresh",
                "brain_status",
            ],
            "profiles": [
                "profile_list",
                "profile_current",
                "overlay_add",
                "overlay_remove",
                "overlay_refresh",
            ],
            "utilities": [
                "write_markdown",
                "get_env",
                "hooks_list_tools",
            ],
        }

        # Filter to only categories that are actually loaded
        registered_tools = {t.name for t in mcp._tool_manager.list_tools()}
        active = {}
        for cat, cat_tools in tools.items():
            present = [t for t in cat_tools if t in registered_tools]
            if present:
                active[cat] = present

        total = sum(len(t) for t in active.values())

        return json.dumps(
            {
                "success": True,
                "total_tools": total,
                "available_categories": list(CATEGORY_MODULES.keys()),
                "categories": active,
            }
        )
