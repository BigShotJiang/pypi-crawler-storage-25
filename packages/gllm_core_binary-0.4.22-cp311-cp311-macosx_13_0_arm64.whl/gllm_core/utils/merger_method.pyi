from gllm_core.utils import mergers as mergers
from gllm_core.utils.imports import deprecated as deprecated
from typing import Any, Callable

class MergerMethod:
    """Deprecated. Use functions from gllm_core.utils.mergers directly."""
    @staticmethod
    def concatenate(delimiter: str = '-') -> Callable[[list[Any]], str]:
        """Deprecated. Use gllm_core.utils.mergers.concatenate instead."""
    @staticmethod
    def pick_first(values: list[Any]) -> Any:
        """Deprecated. Use gllm_core.utils.mergers.pick_first instead."""
    @staticmethod
    def pick_last(values: list[Any]) -> Any:
        """Deprecated. Use gllm_core.utils.mergers.pick_last instead."""
    @staticmethod
    def merge_overlapping_strings(delimiter: str = '\n') -> Callable[[list[str]], str]:
        """Deprecated. Use gllm_core.utils.mergers.merge_overlapping_strings instead."""
