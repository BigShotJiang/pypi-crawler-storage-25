from gllm_core.schema.utils.main_method_resolver import MainMethodResolver as MainMethodResolver

__all__ = ['MainMethodResolver']
