from gllm_core.utils.repr import get_value_repr as get_value_repr
from pydantic import BaseModel
from typing import Annotated, Any

class Chunk(BaseModel, arbitrary_types_allowed=True):
    """Represents a chunk of content retrieved from a vector store.

    Attributes:
        id (str): A unique identifier for the chunk. Defaults to a random UUID.
        content (str | bytes | None): The content of the chunk, either text, binary, or None.
        metadata (dict[str, Any]): Additional metadata associated with the chunk. Defaults to an empty dictionary.
        score (float | None): Similarity score of the chunk (if available). Defaults to None.
    """
    id: str
    content: Annotated[str, None] | Annotated[bytes, None] | None
    metadata: dict[str, Any]
    score: float | None
    def is_text(self) -> bool:
        """Check if the content is text.

        Returns:
            bool: True if the content is text, False otherwise.
        """
    def is_binary(self) -> bool:
        """Check if the content is binary.

        Returns:
            bool: True if the content is binary, False otherwise.
        """
