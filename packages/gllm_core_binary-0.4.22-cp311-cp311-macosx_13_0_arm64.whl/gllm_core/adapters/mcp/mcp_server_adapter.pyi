from _typeshed import Incomplete
from collections.abc import Awaitable as Awaitable, Callable
from gllm_core.logging import LoggerManager as LoggerManager
from mcp.types import CallToolResult
from pydantic import BaseModel
from typing import Any

class UpstreamToolError(Exception):
    """Raised when an upstream MCP tool call fails.

    Attributes:
        tool_name (str): Name of the exposed adapter tool.
        upstream_tool (str): Name of the tool on the upstream server.
        message (str): Human-readable error description.
    """
    tool_name: Incomplete
    upstream_tool: Incomplete
    message: Incomplete
    __cause__: Incomplete
    def __init__(self, tool_name: str, upstream_tool: str, message: str, *, cause: BaseException | None = None) -> None:
        """Initialize an UpstreamToolError.

        Args:
            tool_name (str): Name of the exposed adapter tool.
            upstream_tool (str): Name of the tool on the upstream server.
            message (str): Human-readable error description.
            cause (BaseException | None, optional): The underlying exception that caused this error. Defaults to None.
        """

class MCPToolAdapterConfig(BaseModel):
    '''Defines the configuration for routing an MCP adapter exposed tool to an upstream MCP tool.

    Attributes:
        name (str): Name of the tool as exposed by the adapter.
        upstream_tool (str): Name of the tool on the upstream MCP server.
        description (str): Human-readable description of the tool.
        input_mapping (dict[str, Any]): Mapping from exposed parameter names to upstream parameter names.
            Keys are exposed param names; values are upstream param names.
            Example: {"id": "document_id"} maps adapter\'s "id" to upstream\'s "document_id".
            When omitted or empty, the adapter tool will forward no arguments to the upstream tool.
        transport_output_func (Callable[[CallToolResult], Any]): Callable to transform CallToolResult before returning.
            Defaults to default_transform_output.
    '''
    @staticmethod
    def default_transform_output(result: CallToolResult) -> str:
        """Transform the output of an upstream tool to a string.

        This method serves as the default output transformation for MCPToolAdapterConfig.
        It concatenates all TextContent objects in the result.content list into a single string.
        If the result.content list is empty, it returns an empty string.

        Args:
            result (CallToolResult): The CallToolResult to transform.

        Returns:
            str: The transformed output as a string.
        """
    name: str
    upstream_tool: str
    description: str
    input_mapping: dict[str, Any]
    transport_output_func: Callable[[CallToolResult], Any]
    def get_upstream_args(self, exposed_args: dict[str, Any]) -> dict[str, Any]:
        """Map exposed argument names to upstream argument names.

        Only keys present in input_mapping are forwarded; unmapped keys are dropped.
        All keys in input_mapping must be present in exposed_args.

        Args:
            exposed_args (dict[str, Any]): Keyword arguments passed to the exposed tool.

        Returns:
            dict[str, Any]: Arguments formatted for the upstream tool call.

        Raises:
            KeyError: If a key in input_mapping is not in exposed_args.
        """

class MCPServerAdapter:
    '''MCP server adapter that routes and transforms tools from an upstream MCP server.

    Creates a new MCP server that exposes configurable tools, each delegating to a
    corresponding tool on the upstream server with optional input mapping and
    output transformation.

    Examples:
    ```python
    from gllm_core.adapters.mcp import MCPServerAdapter, MCPToolAdapterConfig

    adapter = MCPServerAdapter(
        mcp_url="http://127.0.0.1:9000/mcp",  # Upstream MCP server URL
        tool_configs=[
            MCPToolAdapterConfig(
                name="search",
                upstream_tool="list_documents",
                description="Search for documents using the configured search tool.",
                input_mapping={"query": "query"},
            ),
            MCPToolAdapterConfig(
                name="fetch",
                upstream_tool="get_document",
                description="Fetch a document by ID using the configured fetch tool.",
                input_mapping={"id": "document_id"},
            ),
        ],
        server_name="deep-research-mcp-server",
    )

    await adapter.serve()
    ```

    Attributes:
        mcp_url (str): URL of the upstream MCP server (Streamable HTTP).
        tool_configs (list[MCPToolAdapterConfig]): List of tool route configurations.
        server_name (str): Name for the adapter MCP server.
    '''
    mcp_url: Incomplete
    tool_configs: Incomplete
    server_name: Incomplete
    def __init__(self, mcp_url: str, tool_configs: list[MCPToolAdapterConfig], *, server_name: str = 'mcp-adapter') -> None:
        '''Initializes a new instance of the MCPServerAdapter class.

        Args:
            mcp_url (str): URL of the upstream MCP server (e.g. "http://host:port/mcp").
            tool_configs (list[MCPToolAdapterConfig]): List of tool route configurations.
            server_name (str, optional): Name for the adapter MCP server. Defaults to "mcp-adapter".
        '''
    async def serve(self, *, host: str = '127.0.0.1', port: int = 7777) -> None:
        '''Run the adapter MCP server until cancelled.

        Registers SIGTERM and SIGINT handlers for graceful shutdown. A brief
        sleep after starting the server task allows it to bind and listen before
        blocking, avoiding races when clients connect immediately.

        Args:
            host (str, optional): Host address to bind. Defaults to "127.0.0.1".
            port (int, optional): Port to bind. Defaults to 7777.
        '''
