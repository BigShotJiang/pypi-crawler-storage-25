from gllm_core.schema.tool import Tool as Tool
from mcp.client.session import ClientSession
from mcp.types import Tool as MCPTool

def from_mcp_tool(session: ClientSession, mcp_tool: MCPTool) -> Tool:
    """Convert an MCP tool into the SDK Tool representation.

    Examples:
        ```python
        # Discover MCP tools
        tools = (await session.list_tools()).tools

        # Convert to SDK tools
        sdk_tools = [Tool.from_mcp(session, t) for t in tools]

        # Invoke through SDK
        result = await sdk_tools[0].invoke(a=2, b=3)
        ```

    Args:
        session (ClientSession): The MCP session to use.
        mcp_tool (MCPTool): The MCP tool to convert.

    Returns:
        Tool: The converted SDK tool.
    """
