import sys
from .models_data import MODELS_DB
from .core import download_model

def print_usage():
    """Вывод справки по командам"""
    print("\n========================================")
    print(" NEXUS MODELS CLI v1.0.1")
    print("========================================\n")
    print("Usage:")
    print("  nexus --models          List all available models in the Vault")
    print("  nexus download <id>     Securely download a model to AppData\n")

def main():
    """Точка входа для команды терминала"""
    # Если юзер ввел просто "nexus" без аргументов
    if len(sys.argv) < 2:
        print_usage()
        return

    cmd = sys.argv[1]

    # Команда: nexus --models
    if cmd == "--models":
        print("\n[Nexus] Authorized Models Database:\n")
        for cat, models in MODELS_DB.items():
            print(f"--- [ {cat} ] ---")
            for m in models: 
                print(f"  {m['id']:<18} | {m['name']:<28} | {m['size']:<6} | VRAM: {m['vram']}")
        print()
        
    # Команда: nexus download <id>
    elif cmd == "download" and len(sys.argv) > 2:
        model_id = sys.argv[2]
        download_model(model_id)
        
    # Неизвестная команда
    else:
        print("\n[Error] Unknown command sequence.")
        print_usage()

if __name__ == "__main__":
    main()