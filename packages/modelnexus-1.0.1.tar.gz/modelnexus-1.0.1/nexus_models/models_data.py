MODELS_DB = {
    "VISION - Depth Estimation": [
        {"id": "depth-any-v2-l", "name": "Depth-Anything-V2-Large", "url": "https://huggingface.co/LiheYoung/depth-anything-v2-large/resolve/main/model.safetensors", "size": "335M", "vram": "2.5GB"},
        {"id": "depthpro-hf", "name": "DepthPro-hf", "url": "https://huggingface.co/apple/DepthPro-hf/resolve/main/model.safetensors", "size": "345M", "vram": "3.0GB"},
        {"id": "dpt-large", "name": "dpt-large", "url": "https://huggingface.co/Intel/dpt-large/resolve/main/model.safetensors", "size": "344M", "vram": "3.0GB"},
        {"id": "marigold-v1-1", "name": "marigold-depth-v1-1", "url": "https://huggingface.co/prs-eth/marigold-depth-v1-1/resolve/main/model.safetensors", "size": "865M", "vram": "5.0GB"},
        {"id": "depthmaster", "name": "DepthMaster", "url": "https://huggingface.co/zysong212/DepthMaster/resolve/main/model.safetensors", "size": "350M", "vram": "3.5GB"}
    ],
    "VISION - Image Classification": [
        {"id": "vit-large-p16", "name": "vit-large-patch16-224", "url": "https://huggingface.co/google/vit-large-patch16-224/resolve/main/model.safetensors", "size": "307M", "vram": "1.5GB"},
        {"id": "internimage-h", "name": "InternImage-H", "url": "https://huggingface.co/OpenGVLab/InternImage-H/resolve/main/model.safetensors", "size": "1.5B", "vram": "6.0GB"},
        {"id": "resnet-152", "name": "resnet-152", "url": "https://huggingface.co/microsoft/resnet-152/resolve/main/model.safetensors", "size": "60M", "vram": "1.0GB"},
        {"id": "convnext-xxl", "name": "convnext-xxlarge", "url": "https://huggingface.co/facebook/convnext-xxlarge/resolve/main/model.safetensors", "size": "846M", "vram": "3.5GB"},
        {"id": "effnetv2-xl", "name": "efficientnetv2-xl", "url": "https://huggingface.co/timm/efficientnetv2-xl/resolve/main/model.safetensors", "size": "208M", "vram": "2.5GB"}
    ],
    "VISION - Object Detection": [
        {"id": "gdino-base", "name": "grounding-dino-base", "url": "https://huggingface.co/IDEA-Research/grounding-dino-base/resolve/main/model.safetensors", "size": "172M", "vram": "2.8GB"},
        {"id": "paddledet", "name": "PaddleDetection", "url": "https://huggingface.co/PaddlePaddle/PaddleDetection/resolve/main/model.safetensors", "size": "1.5B", "vram": "4.0GB"},
        {"id": "rtmdet-x", "name": "rtmdet-x", "url": "https://huggingface.co/openmmlab/rtmdet-x/resolve/main/model.safetensors", "size": "120M", "vram": "2.5GB"},
        {"id": "yolov9-e", "name": "yolov9-e", "url": "https://huggingface.co/jameslahm/yolov9-e/resolve/main/model.safetensors", "size": "60M", "vram": "3.0GB"},
        {"id": "mm-gdino", "name": "MM-Grounding-DINO", "url": "https://huggingface.co/mm-grounding-dino/MM-Grounding-DINO/resolve/main/model.safetensors", "size": "0.3B", "vram": "2.0GB"}
    ],
    "VISION - Image Segmentation": [
        {"id": "mask2former-l", "name": "mask2former-swin-large", "url": "https://huggingface.co/facebook/mask2former-swin-large/resolve/main/model.safetensors", "size": "216M", "vram": "4.0GB"},
        {"id": "sam2-hiera-l", "name": "sam2-hiera-large", "url": "https://huggingface.co/facebook/sam2-hiera-large/resolve/main/model.safetensors", "size": "224M", "vram": "3.5GB"},
        {"id": "segformer-b5", "name": "segformer-b5-finetuned", "url": "https://huggingface.co/nvidia/segformer-b5-finetuned-ade-640-640/resolve/main/model.safetensors", "size": "82M", "vram": "2.5GB"}
    ],
    "VISION - Text-to-Image": [
        {"id": "sdxl-base", "name": "stable-diffusion-xl-base-1.0", "url": "https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors", "size": "2.6B", "vram": "7.5GB"},
        {"id": "flux1-dev", "name": "FLUX.1-dev", "url": "https://huggingface.co/black-forest-labs/FLUX.1-dev/resolve/main/flux1-dev.safetensors", "size": "11.9B", "vram": "18.0GB"},
        {"id": "cogview4-6b", "name": "CogView4-6B", "url": "https://huggingface.co/zai-org/CogView4-6B/resolve/main/model.safetensors", "size": "6B", "vram": "12.0GB"},
        {"id": "z-image-turbo", "name": "Z-Image-Turbo", "url": "https://huggingface.co/Tongyi-MAI/Z-Image-Turbo/resolve/main/model.safetensors", "size": "6B", "vram": "10.0GB"},
        {"id": "qwen-image-25", "name": "Qwen-Image-25", "url": "https://huggingface.co/alibaba/Qwen-Image-25/resolve/main/model.safetensors", "size": "2.6B", "vram": "8.0GB"}
    ],
    "VISION - Image-to-Text": [
        {"id": "blip2-opt", "name": "blip2-opt-2.7b", "url": "https://huggingface.co/Salesforce/blip2-opt-2.7b/resolve/main/model.safetensors", "size": "1.2B", "vram": "6.0GB"},
        {"id": "llava-15-7b", "name": "llava-1.5-7b-hf", "url": "https://huggingface.co/llava-hf/llava-1.5-7b-hf/resolve/main/model.safetensors", "size": "7B", "vram": "14.0GB"},
        {"id": "git-large", "name": "git-large-coco", "url": "https://huggingface.co/microsoft/git-large-coco/resolve/main/model.safetensors", "size": "0.3B", "vram": "2.0GB"},
        {"id": "moondream2", "name": "moondream2", "url": "https://huggingface.co/vikhyatk/moondream2/resolve/main/model.safetensors", "size": "1.6B", "vram": "4.0GB"},
        {"id": "blip-caption", "name": "blip-image-captioning-large", "url": "https://huggingface.co/Salesforce/blip-image-captioning-large/resolve/main/model.safetensors", "size": "0.9B", "vram": "4.5GB"}
    ],
    "VISION - Image-to-Image": [
        {"id": "kandinsky-dec", "name": "kandinsky-2-2-decoder", "url": "https://huggingface.co/kandinsky-community/kandinsky-2-2-decoder/resolve/main/model.safetensors", "size": "1.2B", "vram": "4.0GB"},
        {"id": "sd2-inpaint", "name": "stable-diffusion-2-inpainting", "url": "https://huggingface.co/stabilityai/stable-diffusion-2-inpainting/resolve/main/model.safetensors", "size": "1.2B", "vram": "4.0GB"},
        {"id": "fibo-edit", "name": "FIBO-Edit", "url": "https://huggingface.co/FIBO-Edit/FIBO-Edit/resolve/main/model.safetensors", "size": "8B", "vram": "16.0GB"},
        {"id": "qwen-img-edit", "name": "Qwen-Image-Edit", "url": "https://huggingface.co/alibaba/Qwen-Image-Edit/resolve/main/model.safetensors", "size": "2.6B", "vram": "8.0GB"},
        {"id": "instructpix", "name": "InstructPix2Pix", "url": "https://huggingface.co/google/InstructPix2Pix/resolve/main/model.safetensors", "size": "0.9B", "vram": "3.0GB"}
    ],
    "VISION - Image-to-Video": [
        {"id": "wan22-i2v", "name": "Wan2.2-I2V-A14B", "url": "https://huggingface.co/Wan-AI/Wan2.2-I2V-A14B/resolve/main/model.safetensors", "size": "14B", "vram": "28.0GB"},
        {"id": "kandinsky5-v", "name": "kandinsky-5-video-pro", "url": "https://huggingface.co/kandinsky-community/kandinsky-5-video-pro/resolve/main/model.safetensors", "size": "19B", "vram": "32.0GB"},
        {"id": "ltx-video", "name": "LTX-Video", "url": "https://huggingface.co/Lightricks/LTX-Video/resolve/main/model.safetensors", "size": "2B", "vram": "10.0GB"},
        {"id": "cogvideox-5b", "name": "CogVideoX-5b", "url": "https://huggingface.co/CogVideoX/CogVideoX-5b/resolve/main/model.safetensors", "size": "5B", "vram": "12.0GB"},
        {"id": "hunyuan-i2v", "name": "HunyuanVideo-I2V", "url": "https://huggingface.co/tencent/HunyuanVideo-I2V/resolve/main/model.safetensors", "size": "13B", "vram": "25.0GB"}
    ],
    "VISION - Zero-Shot / Masks / 3D": [
        {"id": "siglip2-base", "name": "siglip2-base-patch16", "url": "https://huggingface.co/google/siglip2-base-patch16-224/resolve/main/model.safetensors", "size": "0.4B", "vram": "2.0GB"},
        {"id": "clip-vit-l", "name": "clip-vit-large-patch14", "url": "https://huggingface.co/openai/clip-vit-large-patch14/resolve/main/model.safetensors", "size": "0.4B", "vram": "2.0GB"},
        {"id": "sam-hq-vit-h", "name": "sam-hq-vit-h", "url": "https://huggingface.co/facebook/sam-hq-vit-h/resolve/main/model.safetensors", "size": "632M", "vram": "5.0GB"},
        {"id": "owlv2-large", "name": "owlv2-large-patch14", "url": "https://huggingface.co/google/owlv2-large-patch14/resolve/main/model.safetensors", "size": "0.6B", "vram": "3.0GB"},
        {"id": "hunyuan3d-2", "name": "Hunyuan3D-2", "url": "https://huggingface.co/tencent/Hunyuan3D-2/resolve/main/model.safetensors", "size": "2B", "vram": "12.0GB"},
        {"id": "trellis-img", "name": "TRELLIS-image-large", "url": "https://huggingface.co/microsoft/TRELLIS-image-large/resolve/main/model.safetensors", "size": "1.5B", "vram": "10.0GB"}
    ],
    "NLP - Text Generation & Processing": [
        {"id": "llama-3.2-3b", "name": "Llama-3.2-3B", "url": "https://huggingface.co/meta-llama/Llama-3.2-3B/resolve/main/model.safetensors", "size": "3B", "vram": "6.0GB"},
        {"id": "phi-4", "name": "phi-4", "url": "https://huggingface.co/microsoft/phi-4/resolve/main/model.safetensors", "size": "14B", "vram": "28.0GB"},
        {"id": "mistral-7b", "name": "Mistral-7B-v0.3", "url": "https://huggingface.co/mistralai/Mistral-7B-v0.3/resolve/main/model.safetensors", "size": "7B", "vram": "14.0GB"},
        {"id": "qwen25-7b", "name": "Qwen2.5-7B-Instruct", "url": "https://huggingface.co/Qwen/Qwen2.5-7B-Instruct/resolve/main/model.safetensors", "size": "7B", "vram": "14.0GB"},
        {"id": "gemma-2-9b", "name": "gemma-2-9b-it", "url": "https://huggingface.co/google/gemma-2-9b-it/resolve/main/model.safetensors", "size": "9B", "vram": "18.0GB"},
        {"id": "bert-base-unc", "name": "bert-base-uncased", "url": "https://huggingface.co/google-bert/bert-base-uncased/resolve/main/model.safetensors", "size": "110M", "vram": "0.8GB"},
        {"id": "roberta-l", "name": "roberta-large-mnli", "url": "https://huggingface.co/roberta-large-mnli/resolve/main/model.safetensors", "size": "355M", "vram": "1.5GB"},
        {"id": "bart-l-cnn", "name": "bart-large-cnn", "url": "https://huggingface.co/facebook/bart-large-cnn/resolve/main/model.safetensors", "size": "406M", "vram": "2.5GB"},
        {"id": "t5-11b", "name": "t5-11b", "url": "https://huggingface.co/google/t5-11b/resolve/main/model.safetensors", "size": "11B", "vram": "22.0GB"}
    ],
    "MULTIMODAL - Any & Advanced": [
        {"id": "whisper-v3", "name": "whisper-large-v3", "url": "https://huggingface.co/openai/whisper-large-v3/resolve/main/model.safetensors", "size": "1.5B", "vram": "6.0GB"},
        {"id": "qwen2-vl-7b", "name": "Qwen2-VL-7B-Instruct", "url": "https://huggingface.co/Qwen/Qwen2-VL-7B-Instruct/resolve/main/model.safetensors", "size": "7B", "vram": "14.0GB"},
        {"id": "videollama3", "name": "VideoLLaMA3-7B", "url": "https://huggingface.co/DAMO-NLP-SG/VideoLLaMA3-7B/resolve/main/model.safetensors", "size": "7B", "vram": "14.0GB"},
        {"id": "minimax-m2", "name": "MiniMax-M2", "url": "https://huggingface.co/MiniMaxAI/MiniMax-M2/resolve/main/model.safetensors", "size": "10B", "vram": "20.0GB"},
        {"id": "llama-3.2-11b-vis", "name": "llama-3.2-11b-vision", "url": "https://huggingface.co/meta-llama/llama-3.2-11b-vision/resolve/main/model.safetensors", "size": "11B", "vram": "22.0GB"}
    ]
}