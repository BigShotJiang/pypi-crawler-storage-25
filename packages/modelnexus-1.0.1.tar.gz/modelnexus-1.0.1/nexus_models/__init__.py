from .core import download_model
from .models_data import MODELS_DB

# Версия твоей библиотеки
__version__ = "1.0.1"

# Список того, что будет доступно при импорте через *
__all__ = ["download_model", "MODELS_DB"]