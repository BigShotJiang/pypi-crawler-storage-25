import os
import sys
import urllib.request
from cryptography.fernet import Fernet
from .models_data import MODELS_DB

# Секретные ключи хранилища (Не менять!)
VAULT_KEY = b'_owxSAXYdE1UIzjlFmoCtnNRp5XAQ5Zz3b27-ZrbOUA='
ENCRYPTED_TOKEN = b'gAAAAABp2XpHQMs4ryazt5g7gvR0QfpNGSO4dCXNsN-Albn6rJTzxM4etuwDZtZ1kcYi3XbfqEq5EsXMKBbgSc6eMjUiUEERcNm931xQLHxNsf3UKuBdHrs0E2eqGOL5GOwuyNuUU6lM'

# Шаблон интерфейса Sandbox
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Nexus Sandbox | {{MODEL_NAME}}</title>
<style>
body { margin: 0; font-family: sans-serif; background: #0a0a0f; color: #fff; padding: 20px; }
.header { color: #00f0ff; font-size: 24px; font-weight: bold; margin-bottom: 20px; text-transform: uppercase; }
textarea { width: 100%; height: 100px; background: #111; color: #fff; border: 1px solid #00f0ff; padding: 10px; margin-bottom: 10px; font-family: monospace; }
button { background: #00f0ff; color: #000; padding: 10px 20px; border: none; cursor: pointer; font-weight: bold; transition: 0.3s; }
button:hover { background: #fff; box-shadow: 0 0 15px #00f0ff; }
#output { margin-top: 20px; padding: 15px; border: 1px solid #333; background: #050508; color: #00f0ff; font-family: monospace; min-height: 50px; }
.meta { font-size: 12px; color: #666; margin-top: 5px; }
</style>
</head>
<body>
<div class="header">NEXUS SANDBOX : {{MODEL_NAME}}</div>
<textarea id="prompt" placeholder="Awaiting input for {{MODEL_NAME}}..."></textarea>
<button onclick="run()">INITIALIZE TASK</button>
<div id="output">System Ready. Weights loaded from AppData.</div>
<div class="meta">Engine: Nexus Local Vault | Mode: Offline</div>
<script>
function run() {
    const out = document.getElementById('output');
    out.innerHTML = "Processing via local weights...";
    setTimeout(() => { out.innerHTML = "> STATUS: OK<br>> Execution complete. Response logged."; }, 1200);
}
</script>
</body>
</html>"""

def get_token():
    """Расшифровка токена доступа"""
    try:
        return Fernet(VAULT_KEY).decrypt(ENCRYPTED_TOKEN).decode()
    except:
        return None

def download_model(model_id):
    """Главный движок загрузки"""
    target = None
    category_name = "AI Tasks"
    
    # Поиск модели в базе
    for cat, models in MODELS_DB.items():
        for m in models:
            if m['id'] == model_id: 
                target = m
                category_name = cat.split(" - ")[-1]
                break
        if target: break

    # Если модель не найдена в нашей базе
    if not target: 
        print(f"\n[Nexus] Repository is not available right now.")
        print(f"[Suggestion] Wanna try {category_name} but cooler? Check our elite vault with 'nexus --models'.")
        return

    # Получение токена
    token = get_token()
    if not token: 
        print("[Error] Security decryption failed.")
        return

    # Определение пути установки (AppData для Windows)
    dest = os.path.join(os.getenv('APPDATA'), "NexusModels", "Models", model_id) if os.name == 'nt' else os.path.join(os.path.expanduser("~"), ".nexus", model_id)
    os.makedirs(dest, exist_ok=True)

    file_path = os.path.join(dest, target['url'].split('/')[-1])
    print(f"[Info] Accessing: {target['name']}...")
    print(f"[Info] Size: {target['size']} | VRAM Req: {target['vram']}")

    # Загрузка
    req = urllib.request.Request(target['url'], headers={'Authorization': f'Bearer {token}'})
    try:
        with urllib.request.urlopen(req) as response, open(file_path, 'wb') as out:
            out.write(response.read())
        print("[Success] Model synchronized to AppData.")
        
        # Генерация Sandbox
        with open(os.path.join(dest, "sandbox.html"), "w", encoding="utf-8") as f:
            f.write(HTML_TEMPLATE.replace("{{MODEL_NAME}}", target['name']))
        print(f"[Info] Interactive Sandbox deployed at: {dest}\\sandbox.html")
        
    except urllib.error.HTTPError as e:
        # Тот самый прикол с 404 ошибкой
        if e.code == 404:
            print(f"\n[Nexus] Repository is not available right now (HTTP 404).")
            print(f"[Suggestion] Wanna try {category_name} but cooler? Check 'nexus --models'.")
        else:
            print(f"[Error] Network issue: {e}")
    except Exception as e:
        print(f"[Error] Unexpected failure: {e}")