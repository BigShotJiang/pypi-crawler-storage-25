# ModelNexus 🌌
**Global AI Model Vault**

A powerful and secure engine to download, manage, and interact with open-source AI models (Vision, NLP, Audio). All weights are securely stored in your system's AppData directory.

### 🚀 Quick Start
```bash
# Install from PyPI
pip install ModelNexus

# List all authorized models
nexus --models

# Securely download a model
nexus download ds-r1-1.5b