from _example_setup import data_path, ensure_repo_root_on_path

ensure_repo_root_on_path()

from resonator_tools import circuit


port1 = circuit.notch_port()
port1.add_froms2p(
    str(data_path("S21testdata.s2p")), 3, 4, "realimag", fdata_unit=1e9, delimiter=None
)
port1.GUIfit()
print("Fit results:", port1.fitresults)
port1.plotall()
print("single photon limit:", port1.get_single_photon_limit(diacorr=True), "dBm")
print(
    "photons in reso for input -140dBm:",
    port1.get_photons_in_resonator(-140, unit="dBm", diacorr=True),
    "photons",
)
print("done")
