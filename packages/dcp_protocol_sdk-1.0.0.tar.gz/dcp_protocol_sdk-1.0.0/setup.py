from setuptools import setup, find_packages

setup(
    name="dcp-protocol-sdk",
    version="1.0.0",
    description="DCP Protocol SDK — 9-layer zero-knowledge AES-256-GCM encryption",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="D.N.A Ecosystem",
    author_email="support@dcprotocol.link",
    url="https://dcprotocol.link",
    packages=find_packages(),
    install_requires=[
        "cryptography>=41.0.0",
        "requests>=2.28.0",
    ],
    python_requires=">=3.8",
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Security :: Cryptography",
    ],
    keywords="encryption aes-256-gcm zero-knowledge cryptography dcp hkdf hmac",
)
