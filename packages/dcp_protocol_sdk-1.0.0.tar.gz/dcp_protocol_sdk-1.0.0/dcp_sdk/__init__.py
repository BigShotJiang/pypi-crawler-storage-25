"""DCP Protocol SDK — 9-layer zero-knowledge AES-256-GCM encryption for Python."""

from .client import DCP, encrypt, decrypt, generate_master_key, generate_salt, derive_key_from_password

__version__ = "1.0.0"
__all__ = ["DCP", "encrypt", "decrypt", "generate_master_key", "generate_salt", "derive_key_from_password"]
