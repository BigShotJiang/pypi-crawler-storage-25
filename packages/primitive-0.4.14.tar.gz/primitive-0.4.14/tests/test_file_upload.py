import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from primitive.files.commands import cli


def _context(debug=False):
    primitive = MagicMock()
    return primitive, {"PRIMITIVE": primitive, "DEBUG": debug, "JSON": False}


class TestFileUploadCommand:
    """file_upload_command — behavioral tests via CliRunner."""

    def test_direct_success_prints_id_and_pk(self, tmp_path):
        test_file = tmp_path / "data.tar.gz"
        test_file.write_bytes(b"x" * 1024)
        primitive, ctx = _context()
        ctx["JSON"] = True
        primitive.files.upload_file_direct.return_value = {"id": "file-abc", "pk": "99"}

        result = CliRunner().invoke(
            cli, ["upload", str(test_file), "--direct"], obj=ctx
        )

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["id"] == "file-abc"
        assert output["pk"] == "99"
        assert output["status"] == "uploaded"

    def test_api_success_prints_id_and_pk(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 512)
        primitive, ctx = _context()
        ctx["JSON"] = True
        primitive.files.upload_file_via_api.return_value = {"id": "file-xyz", "pk": "7"}

        result = CliRunner().invoke(cli, ["upload", str(test_file)], obj=ctx)

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["id"] == "file-xyz"
        assert output["pk"] == "7"
        assert output["status"] == "uploaded"

    def test_direct_failure_logs_upload_path_and_file(self, tmp_path):
        test_file = tmp_path / "data.tar.gz"
        test_file.write_bytes(b"x" * 1024)
        primitive, ctx = _context()
        primitive.files.upload_file_direct.side_effect = Exception(
            "Upload incomplete: one or more parts failed"
        )

        with patch("primitive.files.commands.logger") as mock_logger:
            result = CliRunner().invoke(
                cli, ["upload", str(test_file), "--direct"], obj=ctx
            )

        assert result.exit_code == 1
        mock_logger.error.assert_called_once()
        error_msg = mock_logger.error.call_args[0][0]
        assert "[direct]" in error_msg
        assert "data.tar.gz" in error_msg
        assert "Upload incomplete" in error_msg

    def test_api_failure_logs_http_status(self, tmp_path):
        test_file = tmp_path / "large.zip"
        test_file.write_bytes(b"x" * 512)
        primitive, ctx = _context()
        primitive.files.upload_file_via_api.side_effect = Exception(
            "Upload failed: HTTP 413 from server. Body: Request Entity Too Large"
        )

        with patch("primitive.files.commands.logger") as mock_logger:
            result = CliRunner().invoke(cli, ["upload", str(test_file)], obj=ctx)

        assert result.exit_code == 1
        mock_logger.error.assert_called_once()
        error_msg = mock_logger.error.call_args[0][0]
        assert "[api]" in error_msg
        assert "HTTP 413" in error_msg

    def test_debug_mode_reraises_on_failure(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 512)
        primitive, ctx = _context(debug=True)
        primitive.files.upload_file_direct.side_effect = Exception("boom")

        with patch("primitive.files.commands.logger"):
            result = CliRunner().invoke(
                cli, ["upload", str(test_file), "--direct"], obj=ctx
            )

        assert result.exception is not None
        assert str(result.exception) == "boom"


class TestUploadFileViaApiResponseHandling:
    """upload_file_via_api — non-2xx and server-side error handling."""

    def _make_files(self):
        from primitive.files.actions import Files

        primitive = MagicMock()
        primitive.host_config = {
            "transport": "https",
            "host": "api.dev.primitive.tech",
        }
        primitive.session = MagicMock()
        return Files(primitive)

    def test_non_2xx_raises_with_status_and_body(self, tmp_path):
        test_file = tmp_path / "big.zip"
        test_file.write_bytes(b"x" * 100)

        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = 413
        mock_response.text = "Request Entity Too Large"

        with patch("primitive.files.actions.create_requests_session") as mock_factory:
            mock_factory.return_value.post.return_value = mock_response
            with pytest.raises(Exception, match="HTTP 413"):
                self._make_files().upload_file_via_api(path=test_file)

    def test_success_returns_id_and_pk(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 100)

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "data": {"fileUpload": {"id": "file-999", "pk": "42"}}
        }

        with patch("primitive.files.actions.create_requests_session") as mock_factory:
            mock_factory.return_value.post.return_value = mock_response
            result = self._make_files().upload_file_via_api(path=test_file)

        assert result == {"id": "file-999", "pk": "42"}

    def test_graphql_messages_raise_exception(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 100)

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "data": {
                "fileUpload": {
                    "messages": [{"message": "File too large for organization quota"}]
                }
            }
        }

        with patch("primitive.files.actions.create_requests_session") as mock_factory:
            mock_factory.return_value.post.return_value = mock_response
            with pytest.raises(
                Exception, match="File too large for organization quota"
            ):
                self._make_files().upload_file_via_api(path=test_file)


def _stub_stderr(isatty: bool):
    """Return a mock sys.stderr whose isatty() returns the given value.

    Patching `sys.stderr.isatty` directly can fail on real `_io.TextIOWrapper`
    objects where attributes are read-only; replace the whole stderr attribute
    instead.
    """
    stub = MagicMock()
    stub.isatty.return_value = isatty
    return stub


class TestProgressBarGating:
    """_make_progress — TTY / --json gating rules."""

    def _make_files(self, *, json_mode: bool):
        from primitive.files.actions import Files

        primitive = MagicMock()
        primitive.JSON = json_mode
        return Files(primitive)

    def test_bar_disabled_when_json_enabled(self):
        files = self._make_files(json_mode=True)
        with patch("primitive.files.actions.sys.stderr", _stub_stderr(isatty=True)):
            progress, _ = files._make_progress("↑ x", total=100)
        assert progress.disable is True

    def test_bar_disabled_when_not_tty(self):
        files = self._make_files(json_mode=False)
        with patch("primitive.files.actions.sys.stderr", _stub_stderr(isatty=False)):
            progress, _ = files._make_progress("↑ x", total=100)
        assert progress.disable is True

    def test_bar_enabled_on_tty_without_json(self):
        files = self._make_files(json_mode=False)
        with patch("primitive.files.actions.sys.stderr", _stub_stderr(isatty=True)):
            progress, _ = files._make_progress("↑ x", total=100)
        assert progress.disable is False

    def test_progress_percentage_class_removed(self):
        from primitive.files import actions

        assert not hasattr(actions, "ProgressPercentage")


class TestUploadViaApiProgress:
    """upload_file_via_api wraps the file handle so the bar ticks as bytes are read."""

    def _make_files(self):
        from primitive.files.actions import Files

        primitive = MagicMock()
        primitive.JSON = True  # disable the real bar; we patch Progress below
        primitive.host_config = {
            "transport": "https",
            "host": "api.dev.primitive.tech",
        }
        return Files(primitive)

    def test_session_post_receives_counting_reader(self, tmp_path):
        from primitive.files.actions import _CountingReader

        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 256)

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "data": {"fileUpload": {"id": "f-1", "pk": "1"}}
        }

        with patch("primitive.files.actions.create_requests_session") as mock_factory:
            mock_factory.return_value.post.return_value = mock_response
            self._make_files().upload_file_via_api(path=test_file)

            _, kwargs = mock_factory.return_value.post.call_args
            file_field = kwargs["files"]["fileObject"]
            assert isinstance(file_field[1], _CountingReader)

    def test_counting_reader_advances_on_read(self):
        from primitive.files.actions import _CountingReader

        advances = []
        underlying = MagicMock()
        underlying.read.return_value = b"abcd"

        reader = _CountingReader(underlying, advances.append)
        assert reader.read(4) == b"abcd"
        assert advances == [4]

    def test_counting_reader_no_advance_on_empty(self):
        from primitive.files.actions import _CountingReader

        advances = []
        underlying = MagicMock()
        underlying.read.return_value = b""

        reader = _CountingReader(underlying, advances.append)
        assert reader.read(4) == b""
        assert advances == []

    def test_counting_reader_delegates_other_attrs(self):
        from primitive.files.actions import _CountingReader

        underlying = MagicMock()
        underlying.seek.return_value = 42
        reader = _CountingReader(underlying, lambda _n: None)
        assert reader.seek(0) == 42


class TestDownloadProgress:
    """download_file advances the progress bar per streamed chunk."""

    def _make_files(self):
        from primitive.files.actions import Files

        primitive = MagicMock()
        primitive.JSON = True
        primitive.host_config = {"transport": "https"}
        primitive.host = "api.dev.primitive.tech"
        # make the upstream files() query return a well-formed row
        files_result = MagicMock()
        files_result.data = {
            "files": {
                "edges": [
                    {
                        "node": {
                            "pk": "99",
                            "fileName": "out.bin",
                            "fileSize": "12",
                        }
                    }
                ]
            }
        }
        primitive.files.files.return_value = files_result
        return Files(primitive)

    def test_advances_per_chunk(self, tmp_path):
        files = self._make_files()

        mock_response = MagicMock()
        mock_response.iter_content.return_value = [b"aaaa", b"bbbb", b"cccc"]

        cm = MagicMock()
        cm.__enter__.return_value = mock_response
        cm.__exit__.return_value = False

        with (
            patch("primitive.files.actions.create_requests_session") as mock_factory,
            patch("primitive.files.actions.Progress") as mock_progress_cls,
        ):
            mock_factory.return_value.get.return_value = cm
            mock_progress = MagicMock()
            mock_progress.__enter__.return_value = mock_progress
            mock_progress.add_task.return_value = "task-id"
            mock_progress_cls.return_value = mock_progress

            files.download_file(file_name="out.bin", output_path=tmp_path)

        advances = [
            call.kwargs.get("advance") for call in mock_progress.update.call_args_list
        ]
        assert advances == [4, 4, 4]


class TestProgressStderrOutput:
    """Verify progress renders to stderr, never stdout, even when enabled."""

    def test_make_progress_uses_stderr_console(self):
        from primitive.files.actions import Files

        primitive = MagicMock()
        primitive.JSON = False
        files = Files(primitive)
        with patch("primitive.files.actions.sys.stderr", _stub_stderr(isatty=True)):
            progress, _ = files._make_progress("↑ x", total=100)
        assert progress.console.stderr is True


class TestUploadFileDirectProgress:
    """upload_file_direct advances the progress bar once per completed part."""

    def _make_files(self):
        from primitive.files.actions import Files

        primitive = MagicMock()
        primitive.JSON = True
        return Files(primitive)

    def test_advances_per_completed_part(self, tmp_path):
        files = self._make_files()
        files.upload_speed_mbps = "100"

        test_file = tmp_path / "data.bin"
        test_file.write_bytes(b"x" * 300)

        parts_details = {
            "1": {
                "PartNumber": 1,
                "presigned_url": "https://s3/1",
                "start_byte": 0,
                "end_byte": 100,
            },
            "2": {
                "PartNumber": 2,
                "presigned_url": "https://s3/2",
                "start_byte": 100,
                "end_byte": 250,
            },
            "3": {
                "PartNumber": 3,
                "presigned_url": "https://s3/3",
                "start_byte": 250,
                "end_byte": 300,
            },
        }

        update_result = MagicMock()
        update_result.data = {"fileUpdate": {"id": "file-1", "pk": "1"}}

        with (
            patch.object(files, "_pending_file_create") as mock_create,
            patch.object(files, "_update_file_status") as mock_status,
            patch.object(files, "_upload_part", return_value=None),
            patch("primitive.files.actions.Progress") as mock_progress_cls,
        ):
            mock_create.return_value = {
                "id": "file-1",
                "partsDetails": parts_details,
            }
            mock_status.return_value = update_result

            mock_progress = MagicMock()
            mock_progress.__enter__.return_value = mock_progress
            mock_progress.add_task.return_value = "task-id"
            mock_progress_cls.return_value = mock_progress

            files.upload_file_direct(path=test_file)

        advances = sorted(
            call.kwargs["advance"]
            for call in mock_progress.update.call_args_list
            if "advance" in call.kwargs
        )
        assert advances == [50, 100, 150]
        assert sum(advances) == 300
