import base64
import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from primitive.files.actions import (
    FilesDeleteError,
    Files,
    extract_key_prefix,
    looks_like_file_global_id,
)
from primitive.files.commands import cli


def _encode_global_id(raw: str) -> str:
    return base64.urlsafe_b64encode(raw.encode()).decode().rstrip("=")


def _context(*, yes: bool = False, json_mode: bool = False, debug: bool = False):
    primitive = MagicMock()
    return primitive, {
        "PRIMITIVE": primitive,
        "DEBUG": debug,
        "JSON": json_mode,
        "YES": yes,
    }


def _file_node(
    *,
    id: str = "RmlsZToxMjM0",
    pk: str = "1234",
    file_name: str = "foo.zip",
    location: str = "https://bucket.example.com/org-slug%2Ffoo.zip",
    file_size: str = "1024",
    updated_at: str = "2026-04-20T12:00:00",
    is_deleting: bool = False,
    is_deleted: bool = False,
) -> dict:
    return {
        "id": id,
        "pk": pk,
        "fileName": file_name,
        "location": location,
        "fileSize": file_size,
        "humanReadableMemorySize": "1.0 KB",
        "updatedAt": updated_at,
        "isDeleting": is_deleting,
        "isDeleted": is_deleted,
    }


def _files_result(edges: list[dict], total_count: int | None = None) -> MagicMock:
    result = MagicMock()
    payload = {
        "files": {
            "edges": [{"cursor": "", "node": node} for node in edges],
            "totalCount": total_count if total_count is not None else len(edges),
        }
    }
    result.data = payload
    return result


class TestLooksLikeGlobalID:
    def test_valid_file_global_id(self):
        gid = _encode_global_id("File:1234")
        assert looks_like_file_global_id(gid) is True

    def test_plain_name_not_global_id(self):
        assert looks_like_file_global_id("hopper-hgx.zip") is False

    def test_empty_string(self):
        assert looks_like_file_global_id("") is False

    def test_non_file_prefix(self):
        gid = _encode_global_id("User:99")
        assert looks_like_file_global_id(gid) is False


class TestExtractKeyPrefix:
    def test_no_prefix(self):
        # key: org-slug/foo.zip (no prefix between slug and filename)
        location = "https://bucket.example.com/org-slug%2Ffoo.zip"
        assert extract_key_prefix(location, "foo.zip") == ""

    def test_simple_prefix(self):
        # key: org-slug/abc/foo.zip
        location = "https://bucket.example.com/org-slug%2Fabc%2Ffoo.zip"
        assert extract_key_prefix(location, "foo.zip") == "abc"

    def test_multi_segment_prefix(self):
        location = "https://bucket.example.com/org-slug%2F629-24287%2Fnested%2Ffoo.zip"
        assert extract_key_prefix(location, "foo.zip") == "629-24287/nested"

    def test_path_style_bucket_first_segment(self):
        # path-style URL: /bucket/<encoded-key>
        location = "https://s3.local/bucket/org-slug%2Fabc%2Ffoo.zip"
        assert extract_key_prefix(location, "foo.zip") == "abc"

    def test_missing_location_returns_empty(self):
        assert extract_key_prefix(None, "foo.zip") == ""

    def test_missing_filename_returns_empty(self):
        assert (
            extract_key_prefix("https://bucket.example.com/org-slug%2Ffoo.zip", None)
            == ""
        )


class TestResolveFileIds:
    def _make_files(self) -> Files:
        primitive = MagicMock()
        primitive.JSON = False
        instance = Files(primitive)
        # Stub the scope resolver so tests don't exercise whoami/get_organization.
        instance._resolve_scope_org_id = MagicMock(return_value="org-1")
        return instance

    def test_global_id_pass_through(self):
        files = self._make_files()
        node = _file_node(id="RmlsZToxMjM0", file_name="x.zip")

        with patch.object(
            files, "files", return_value=_files_result([node])
        ) as mock_query:
            resolved, skipped = files.resolve_file_ids(
                ids=["RmlsZToxMjM0"],
                names=[],
                key_prefix=None,
            )

        mock_query.assert_called_once_with(
            file_id="RmlsZToxMjM0", organization_id="org-1", first=1
        )
        assert len(resolved) == 1
        assert resolved[0]["id"] == "RmlsZToxMjM0"
        assert skipped == []

    def test_global_id_not_found_skipped(self):
        files = self._make_files()
        with patch.object(files, "files", return_value=_files_result([])):
            resolved, skipped = files.resolve_file_ids(
                ids=["RmlsZToxMjM0"],
                names=[],
                key_prefix=None,
            )
        assert resolved == []
        assert skipped == [{"id": "RmlsZToxMjM0", "reason": "not found"}]

    def test_name_unique_match(self):
        files = self._make_files()
        node = _file_node(id="RmlsZToxMjM1", file_name="unique.zip")
        with patch.object(files, "files", return_value=_files_result([node])):
            resolved, skipped = files.resolve_file_ids(
                ids=[], names=["unique.zip"], key_prefix=None
            )
        assert len(resolved) == 1
        assert resolved[0]["id"] == "RmlsZToxMjM1"
        assert skipped == []

    def test_name_zero_matches_raises_with_no_similar_names(self):
        files = self._make_files()
        # Both the exact query and the fuzzy fallback return nothing.
        with patch.object(files, "files", return_value=_files_result([])):
            with pytest.raises(ValueError) as excinfo:
                files.resolve_file_ids(ids=[], names=["missing.zip"], key_prefix=None)

        message = str(excinfo.value)
        assert "No file named 'missing.zip'" in message
        assert "case-sensitive" in message
        assert "primitive files list" in message

    def test_name_zero_matches_surfaces_similar_candidates(self):
        files = self._make_files()
        similar = _file_node(
            id="RmlsZToxMjM2",
            file_name="exports.csv",
            location="https://bucket.example.com/org-slug%2Fexports.csv",
        )
        # First call (exact) returns empty, second call (iContains) returns similar.
        with patch.object(
            files,
            "files",
            side_effect=[_files_result([]), _files_result([similar])],
        ):
            with pytest.raises(ValueError) as excinfo:
                files.resolve_file_ids(ids=[], names=["exports.txt"], key_prefix=None)

        message = str(excinfo.value)
        assert "No exact match for 'exports.txt'" in message
        assert "similar" in message.lower()
        assert "exports.csv" in message
        assert "RmlsZToxMjM2" in message

    def test_name_multiple_matches_raises_with_candidates(self):
        files = self._make_files()
        node_a = _file_node(id="RmlsZToxMjM0", file_name="foo.zip")
        node_b = _file_node(
            id="RmlsZToxMjM1",
            file_name="foo.zip",
            location="https://bucket.example.com/org-slug%2Fsubdir%2Ffoo.zip",
        )
        with patch.object(files, "files", return_value=_files_result([node_a, node_b])):
            with pytest.raises(ValueError) as excinfo:
                files.resolve_file_ids(ids=[], names=["foo.zip"], key_prefix=None)

        message = str(excinfo.value)
        assert "Multiple files named 'foo.zip'" in message
        assert "RmlsZToxMjM0" in message
        assert "RmlsZToxMjM1" in message
        assert "subdir" in message

    def test_key_prefix_filters_client_side(self):
        files = self._make_files()
        match = _file_node(
            id="RmlsZToxMjMw",
            file_name="a.zip",
            location="https://bucket.example.com/org-slug%2Ftarget%2Fa.zip",
        )
        non_match = _file_node(
            id="RmlsZToxMjMx",
            file_name="b.zip",
            location="https://bucket.example.com/org-slug%2Fother%2Fb.zip",
        )
        with patch.object(
            files,
            "files",
            return_value=_files_result([match, non_match]),
        ):
            resolved, skipped = files.resolve_file_ids(
                ids=[], names=[], key_prefix="target"
            )
        assert [r["id"] for r in resolved] == ["RmlsZToxMjMw"]
        assert skipped == []

    def test_key_prefix_matches_subpath(self):
        files = self._make_files()
        nested = _file_node(
            id="RmlsZToxMjMy",
            file_name="c.zip",
            location="https://bucket.example.com/org-slug%2Ftarget%2Fsub%2Fc.zip",
        )
        with patch.object(files, "files", return_value=_files_result([nested])):
            resolved, _ = files.resolve_file_ids(ids=[], names=[], key_prefix="target")
        assert [r["id"] for r in resolved] == ["RmlsZToxMjMy"]

    def test_already_deleted_file_skipped(self):
        files = self._make_files()
        dead = _file_node(id="RmlsZToxMjM0", is_deleted=True)
        with patch.object(files, "files", return_value=_files_result([dead])):
            resolved, skipped = files.resolve_file_ids(
                ids=["RmlsZToxMjM0"], names=[], key_prefix=None
            )
        assert resolved == []
        assert len(skipped) == 1
        assert skipped[0]["reason"] == "already deleted"

    def test_in_progress_delete_skipped_with_distinct_reason(self):
        files = self._make_files()
        in_progress = _file_node(id="RmlsZToxMjM0", is_deleting=True)
        with patch.object(files, "files", return_value=_files_result([in_progress])):
            resolved, skipped = files.resolve_file_ids(
                ids=["RmlsZToxMjM0"], names=[], key_prefix=None
            )
        assert resolved == []
        assert skipped[0]["reason"] == "deletion in progress"

    def test_dedup_across_selectors(self):
        files = self._make_files()
        node = _file_node(id="RmlsZToxMjM0", file_name="dup.zip")
        with patch.object(files, "files", return_value=_files_result([node])):
            resolved, _ = files.resolve_file_ids(
                ids=["RmlsZToxMjM0"], names=["dup.zip"], key_prefix=None
            )
        assert len(resolved) == 1

    def test_already_deleted_dedup_across_selectors(self):
        files = self._make_files()
        dead = _file_node(id="RmlsZToxMjM0", file_name="dead.zip", is_deleted=True)
        with patch.object(files, "files", return_value=_files_result([dead])):
            resolved, skipped = files.resolve_file_ids(
                ids=["RmlsZToxMjM0"], names=["dead.zip"], key_prefix=None
            )
        assert resolved == []
        assert len(skipped) == 1

    def test_empty_key_prefix_raises(self):
        files = self._make_files()
        with pytest.raises(ValueError, match="--key-prefix cannot be empty"):
            files.resolve_file_ids(ids=[], names=[], key_prefix="")

    def test_slash_only_key_prefix_raises(self):
        files = self._make_files()
        with pytest.raises(ValueError, match="--key-prefix cannot be empty"):
            files.resolve_file_ids(ids=[], names=[], key_prefix="/")


class TestDeleteFilesAction:
    def _make_files(self) -> tuple[Files, MagicMock]:
        primitive = MagicMock()
        return Files(primitive), primitive

    def test_happy_path_returns_deleted_ids(self):
        files, primitive = self._make_files()
        mock_result = MagicMock()
        mock_result.data = {"filesDelete": {"deletedIds": ["RmlsZToxMjM0"]}}
        primitive.session.execute.return_value = mock_result

        result = files.delete_files(file_ids=["RmlsZToxMjM0"])
        assert result == {"deleted_ids": ["RmlsZToxMjM0"]}

    def test_operation_messages_raise_structured_error(self):
        files, primitive = self._make_files()
        mock_result = MagicMock()
        mock_result.data = {
            "filesDelete": {
                "messages": [
                    {
                        "kind": "PERMISSION",
                        "code": "permission_denied",
                        "message": "You do not have permission to delete files.",
                    }
                ]
            }
        }
        primitive.session.execute.return_value = mock_result

        with pytest.raises(FilesDeleteError) as excinfo:
            files.delete_files(file_ids=["RmlsZToxMjM0"])

        assert excinfo.value.is_permission_denied() is True
        assert "permission" in str(excinfo.value)

    def test_non_permission_operation_message_is_not_permission_denied(self):
        files, primitive = self._make_files()
        mock_result = MagicMock()
        mock_result.data = {
            "filesDelete": {
                "messages": [
                    {
                        "kind": "VALIDATION",
                        "code": "invalid_file",
                        "message": "Unknown file id.",
                    }
                ]
            }
        }
        primitive.session.execute.return_value = mock_result

        with pytest.raises(FilesDeleteError) as excinfo:
            files.delete_files(file_ids=["RmlsZToxMjM0"])

        assert excinfo.value.is_permission_denied() is False


class TestFileDeleteCommand:
    def _resolved_node(self, id: str = "RmlsZToxMjM0") -> dict:
        return {
            **_file_node(id=id),
            "keyPrefix": "",
        }

    def test_no_selector_rejected(self):
        primitive, ctx = _context()
        result = CliRunner().invoke(cli, ["delete"], obj=ctx)
        assert result.exit_code != 0
        assert "At least one selector" in result.output

    def test_empty_key_prefix_rejected(self):
        primitive, ctx = _context(yes=True)
        primitive.files.resolve_file_ids.side_effect = ValueError(
            "--key-prefix cannot be empty. "
            "Pass --file-id or --file-name to target top-level files."
        )
        result = CliRunner().invoke(cli, ["delete", "--key-prefix", ""], obj=ctx)
        assert result.exit_code != 0
        assert "--key-prefix cannot be empty" in result.output
        primitive.files.delete_files.assert_not_called()

    def test_dry_run_with_key_prefix_previews_without_mutating(self):
        primitive, ctx = _context(json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [
                {**_file_node(id="RmlsZToxMjM0"), "keyPrefix": "target"},
                {**_file_node(id="RmlsZToxMjM1"), "keyPrefix": "target"},
            ],
            [],
        )
        result = CliRunner().invoke(
            cli,
            ["delete", "--key-prefix", "target", "--dry-run"],
            obj=ctx,
        )
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["dry_run"] is True
        assert payload["would_delete"] == ["RmlsZToxMjM0", "RmlsZToxMjM1"]
        primitive.files.delete_files.assert_not_called()

    def test_dry_run_skips_mutation(self):
        primitive, ctx = _context(json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [self._resolved_node()],
            [],
        )
        result = CliRunner().invoke(
            cli, ["delete", "--file-id", "RmlsZToxMjM0", "--dry-run"], obj=ctx
        )
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["dry_run"] is True
        assert payload["would_delete"] == ["RmlsZToxMjM0"]
        primitive.files.delete_files.assert_not_called()

    def test_yes_skips_confirmation(self):
        primitive, ctx = _context(yes=True, json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [self._resolved_node()],
            [],
        )
        primitive.files.delete_files.return_value = {"deleted_ids": ["RmlsZToxMjM0"]}

        result = CliRunner().invoke(
            cli, ["delete", "--file-id", "RmlsZToxMjM0"], obj=ctx
        )
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["deleted_ids"] == ["RmlsZToxMjM0"]
        primitive.files.delete_files.assert_called_once_with(file_ids=["RmlsZToxMjM0"])

    def test_json_skips_confirmation(self):
        primitive, ctx = _context(json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [self._resolved_node()],
            [],
        )
        primitive.files.delete_files.return_value = {"deleted_ids": ["RmlsZToxMjM0"]}
        result = CliRunner().invoke(
            cli, ["delete", "--file-id", "RmlsZToxMjM0"], obj=ctx
        )
        assert result.exit_code == 0
        # valid JSON on stdout
        assert json.loads(result.output)["deleted_ids"] == ["RmlsZToxMjM0"]

    def test_positional_global_id_routed_as_id(self):
        primitive, ctx = _context(yes=True, json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [self._resolved_node()],
            [],
        )
        primitive.files.delete_files.return_value = {"deleted_ids": ["RmlsZToxMjM0"]}
        gid = _encode_global_id("File:1234")
        result = CliRunner().invoke(cli, ["delete", gid], obj=ctx)
        assert result.exit_code == 0
        call_kwargs = primitive.files.resolve_file_ids.call_args.kwargs
        assert call_kwargs["ids"] == [gid]
        assert call_kwargs["names"] == []

    def test_positional_name_routed_as_name(self):
        primitive, ctx = _context(yes=True, json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [self._resolved_node()],
            [],
        )
        primitive.files.delete_files.return_value = {"deleted_ids": ["RmlsZToxMjM0"]}
        result = CliRunner().invoke(cli, ["delete", "hopper.zip"], obj=ctx)
        assert result.exit_code == 0
        call_kwargs = primitive.files.resolve_file_ids.call_args.kwargs
        assert call_kwargs["names"] == ["hopper.zip"]
        assert call_kwargs["ids"] == []

    def test_ambiguous_name_surfaces_usage_error(self):
        primitive, ctx = _context()
        primitive.files.resolve_file_ids.side_effect = ValueError(
            "Multiple files named 'foo.zip' in scope."
        )
        result = CliRunner().invoke(cli, ["delete", "--file-name", "foo.zip"], obj=ctx)
        assert result.exit_code != 0
        assert "Multiple files named 'foo.zip'" in result.output

    def test_permission_error_surfaces_clean_message(self):
        primitive, ctx = _context(yes=True)
        primitive.files.resolve_file_ids.return_value = (
            [self._resolved_node()],
            [],
        )
        primitive.files.delete_files.side_effect = FilesDeleteError(
            [
                {
                    "kind": "PERMISSION",
                    "code": "permission_denied",
                    "message": "You do not have permission to delete files.",
                }
            ]
        )
        result = CliRunner().invoke(
            cli, ["delete", "--file-id", "RmlsZToxMjM0"], obj=ctx
        )
        assert result.exit_code != 0
        assert "You do not have permission to delete files." in result.output
        # Not a raw traceback
        assert "Traceback" not in result.output

    def test_exit_nonzero_when_any_file_fails(self):
        primitive, ctx = _context(yes=True, json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [
                self._resolved_node(id="RmlsZToxMjM0"),
                self._resolved_node(id="RmlsZToxMjM1"),
            ],
            [],
        )
        primitive.files.delete_files.return_value = {"deleted_ids": ["RmlsZToxMjM0"]}
        result = CliRunner().invoke(
            cli,
            [
                "delete",
                "--file-id",
                "RmlsZToxMjM0",
                "--file-id",
                "RmlsZToxMjM1",
            ],
            obj=ctx,
        )
        assert result.exit_code == 1
        payload = json.loads(result.output)
        assert payload["deleted_ids"] == ["RmlsZToxMjM0"]
        assert [f["id"] for f in payload["failed"]] == ["RmlsZToxMjM1"]

    def test_already_deleted_flows_to_skipped(self):
        primitive, ctx = _context(yes=True, json_mode=True)
        primitive.files.resolve_file_ids.return_value = (
            [],
            [{"id": "RmlsZToxMjM0", "reason": "already deleted"}],
        )
        result = CliRunner().invoke(
            cli, ["delete", "--file-id", "RmlsZToxMjM0"], obj=ctx
        )
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["deleted_ids"] == []
        assert payload["skipped"] == [
            {"id": "RmlsZToxMjM0", "reason": "already deleted"}
        ]
        primitive.files.delete_files.assert_not_called()

    def test_empty_resolved_with_skipped_mentions_skip_count(self):
        primitive, ctx = _context(yes=True)
        primitive.files.resolve_file_ids.return_value = (
            [],
            [
                {"id": "RmlsZToxMjM0", "reason": "already deleted"},
                {"id": "RmlsZToxMjM1", "reason": "deletion in progress"},
            ],
        )
        result = CliRunner().invoke(
            cli,
            ["delete", "--file-id", "RmlsZToxMjM0", "--file-id", "RmlsZToxMjM1"],
            obj=ctx,
        )
        assert result.exit_code == 0
        assert "skipped 2" in result.output
        assert "already-deleted or missing" in result.output
        primitive.files.delete_files.assert_not_called()

    def test_empty_resolved_without_skipped_uses_original_message(self):
        primitive, ctx = _context(yes=True)
        primitive.files.resolve_file_ids.return_value = ([], [])
        # Reach the empty-resolved branch via --key-prefix (no selector bypass).
        result = CliRunner().invoke(
            cli, ["delete", "--key-prefix", "no-match"], obj=ctx
        )
        assert result.exit_code == 0
        assert "No files matched the given selectors." in result.output
