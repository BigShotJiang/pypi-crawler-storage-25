from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def primitive_mock():
    p = MagicMock()
    p.DEBUG = False
    # Hardware has an active reservation pointing at a waiting_for_hardware
    # JobRun that the agent should resume on startup.
    p.hardware.get_own_hardware_details.return_value = {
        "id": "hw-1",
        "activeReservation": {"id": "res-1", "hardware": []},
    }
    p.reservations.get_job_run_for_reservation_id.return_value = {
        "id": "jr-1",
        "status": "waiting_for_hardware",
        "stepsStarted": 2,
        "stepsCompleted": 1,
        "job": {"slug": "diag"},
        "executionHardware": {"id": "hw-1"},
    }
    p.jobs.job_run_resume.return_value = MagicMock(
        data={
            "jobRunResume": {
                "id": "jr-1",
                "status": "in_progress",
                "stepsStarted": 2,
                "stepsCompleted": 1,
            }
        }
    )
    return p


def test_agent_calls_resume_on_waiting_job_run(primitive_mock):
    from primitive.agent.actions import Agent

    agent = Agent.__new__(Agent)
    agent.primitive = primitive_mock

    with (
        patch("primitive.agent.actions.Runner") as Runner,
        patch("primitive.agent.actions.Uploader"),
        patch("primitive.agent.actions.sleep"),
    ):
        runner_instance = MagicMock()
        Runner.return_value = runner_instance

        # Break out of the agent's outer while-True loop. The inner
        # try/except catches `Exception`, so we must raise a
        # `BaseException` subclass to propagate past it — otherwise the
        # exception is swallowed and the loop spins forever against the
        # same mocked waiting_for_hardware state.
        runner_instance.execute_job_run.side_effect = SystemExit

        with pytest.raises(SystemExit):
            agent.start()

    primitive_mock.jobs.job_run_resume.assert_called_once_with(id="jr-1")
    # setup() IS called on resume — it's the only thing that populates
    # source_dir + env vars on a fresh Runner instance. The git download
    # it performs is a no-op when the workspace already matches the ref.
    runner_instance.setup.assert_called_once()
    runner_instance.execute_job_run.assert_called_once()
    call = runner_instance.execute_job_run.call_args
    assert call.kwargs.get("start_index") == 2 or (call.args and call.args[0] == 2)
    runner_instance.cleanup.assert_called_once()
