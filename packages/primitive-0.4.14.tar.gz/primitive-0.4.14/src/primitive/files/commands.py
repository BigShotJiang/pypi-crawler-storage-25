import sys
import typing
from pathlib import Path

import click
from loguru import logger

from primitive.files.actions import (
    FAIL_REASON_NOT_RETURNED,
    FilesDeleteError,
    looks_like_file_global_id,
)
from primitive.files.ui import render_files_delete_preview, render_files_table

from ..utils.printer import print_result

if typing.TYPE_CHECKING:
    from ..client import Primitive


@click.group("files")
@click.pass_context
def cli(context):
    """Files"""
    pass


@cli.command("upload")
@click.pass_context
@click.argument("path", type=click.Path(exists=True))
@click.option("--public", "-p", help="Is this a Public file", is_flag=True)
@click.option("--key-prefix", "-k", help="Key Prefix", default="")
@click.option("--direct", help="direct", is_flag=True)
def file_upload_command(context, path, public, key_prefix, direct):
    """File Upload"""
    primitive: Primitive = context.obj.get("PRIMITIVE")
    path = Path(path)
    file_size_mb = (
        round(path.stat().st_size / (1024 * 1024), 2) if path.exists() else "?"
    )
    upload_path = "direct" if direct else "api"
    try:
        if direct:
            result = primitive.files.upload_file_direct(
                path, is_public=public, key_prefix=key_prefix
            )
        else:
            result = primitive.files.upload_file_via_api(
                path, is_public=public, key_prefix=key_prefix
            )
        message = {"id": result.get("id"), "pk": result.get("pk"), "status": "uploaded"}
    except Exception as error:
        logger.error(
            f"Upload failed [{upload_path}] {path} ({file_size_mb} MB): {error}"
        )
        if context.obj["DEBUG"]:
            raise
        context.exit(1)
        return

    print_result(message=message, context=context)


@cli.command("download")
@click.pass_context
@click.option("--file-id", help="File ID", required=False)
@click.option("--file-name", help="File Name", required=False)
@click.option("--output", help="Output Path", required=False, type=click.Path())
@click.option("--organization-id", help="Organization ID", required=False)
@click.option("--organization", help="Organization Slug", required=False)
def file_download_command(
    context,
    file_id=None,
    file_name=None,
    output=None,
    organization_id=None,
    organization=None,
):
    """File Download"""
    primitive: Primitive = context.obj.get("PRIMITIVE")

    if not file_id and not file_name:
        raise click.UsageError("Either --id or --file-name must be provided.")

    if not output:
        output = Path().cwd()
    else:
        output = Path(output)

    downloaded_file = primitive.files.download_file(
        output_path=output,
        file_id=file_id,
        file_name=file_name,
        organization_id=organization_id,
        organization_slug=organization,
    )
    print_result(message=f"File downloaded to {downloaded_file}", context=context)


@cli.command("list")
@click.pass_context
@click.option("--organization-id", help="Organization ID", required=False)
@click.option("--organization", help="Organization Slug", required=False)
def list_command(context, organization_id=None, organization=None):
    """List Files"""
    primitive: Primitive = context.obj.get("PRIMITIVE")
    files_result = primitive.files.files(
        organization_id=organization_id, organization_slug=organization
    )

    files = [file.get("node") for file in files_result.data.get("files").get("edges")]

    if context.obj["JSON"]:
        print_result(message=files, context=context)
    else:
        render_files_table(files)


@cli.command("delete")
@click.pass_context
@click.argument("identifiers", nargs=-1)
@click.option(
    "--file-id",
    "file_ids",
    multiple=True,
    help="File GlobalID. Repeatable.",
)
@click.option(
    "--file-name",
    "file_names",
    multiple=True,
    help="File name. Repeatable.",
)
@click.option(
    "--key-prefix",
    "key_prefix",
    default=None,
    help="Delete all files with this keyPrefix in scope.",
)
@click.option(
    "--organization",
    "-o",
    "organization_slug",
    default=None,
    help="Organization slug.",
)
@click.option(
    "--organization-id",
    "organization_id",
    default=None,
    help="Organization ID.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Preview what would be deleted without calling the API.",
)
def file_delete_command(
    context,
    identifiers,
    file_ids,
    file_names,
    key_prefix,
    organization_slug,
    organization_id,
    dry_run,
):
    """Delete files by GlobalID, name, or keyPrefix."""
    primitive: Primitive = context.obj.get("PRIMITIVE")
    json_mode = context.obj.get("JSON", False)
    yes = context.obj.get("YES", False)
    debug = context.obj.get("DEBUG", False)

    explicit_ids: list[str] = list(file_ids)
    explicit_names: list[str] = list(file_names)
    for value in identifiers:
        if looks_like_file_global_id(value):
            explicit_ids.append(value)
        else:
            explicit_names.append(value)

    if not explicit_ids and not explicit_names and key_prefix is None:
        raise click.UsageError(
            "At least one selector is required: "
            "positional identifier, --file-id, --file-name, or --key-prefix."
        )

    try:
        resolved, skipped = primitive.files.resolve_file_ids(
            ids=explicit_ids,
            names=explicit_names,
            key_prefix=key_prefix,
            organization_id=organization_id,
            organization_slug=organization_slug,
        )
    except ValueError as error:
        raise click.UsageError(str(error))

    skipped_out = [{"id": s.get("id"), "reason": s.get("reason")} for s in skipped]

    if not resolved:
        payload = {"deleted_ids": [], "skipped": skipped_out, "failed": []}
        if json_mode:
            print_result(message=payload, context=context)
        elif skipped:
            click.echo(
                f"No files to delete; skipped "
                f"{len(skipped)} already-deleted or missing file(s).",
                err=True,
            )
        else:
            click.echo("No files matched the given selectors.", err=True)
        return

    if not json_mode:
        render_files_delete_preview(resolved)
        if skipped:
            click.echo(
                f"Skipping {len(skipped)} already-deleted or missing file(s).",
                err=True,
            )

    if dry_run:
        payload = {
            "deleted_ids": [],
            "skipped": skipped_out,
            "failed": [],
            "dry_run": True,
            "would_delete": [f.get("id") for f in resolved],
        }
        if json_mode:
            print_result(message=payload, context=context)
        else:
            click.echo("--dry-run: no files were deleted.", err=True)
        return

    # click.confirm(..., err=True) writes the prompt to stderr. If stderr is
    # redirected the prompt is invisible and the command appears to hang on
    # stdin; require both streams be a TTY before prompting.
    needs_confirm = (
        not yes
        and not json_mode
        and sys.stdin.isatty()
        and click.get_text_stream("stderr").isatty()
    )
    if needs_confirm:
        click.confirm("Proceed?", default=False, abort=True, err=True)

    target_ids: list[str] = [f["id"] for f in resolved]
    try:
        result = primitive.files.delete_files(file_ids=target_ids)
    except FilesDeleteError as error:
        if error.is_permission_denied():
            raise click.ClickException("You do not have permission to delete files.")
        logger.error(f"Delete failed: {error}")
        if debug:
            raise
        context.exit(1)
        return
    except Exception as error:  # noqa: BLE001 — surface a clean message
        logger.error(f"Delete failed: {error}")
        if debug:
            raise
        context.exit(1)
        return

    deleted_ids = set(result.get("deleted_ids") or [])
    failed = [
        {"id": f.get("id"), "reason": FAIL_REASON_NOT_RETURNED}
        for f in resolved
        if f.get("id") and f.get("id") not in deleted_ids
    ]

    payload = {
        "deleted_ids": sorted(deleted_ids),
        "skipped": skipped_out,
        "failed": failed,
    }

    if json_mode:
        print_result(message=payload, context=context)
    else:
        click.echo(f"Deleted {len(deleted_ids)} file(s).", err=True)
        if failed:
            click.echo(f"Failed to delete {len(failed)} file(s):", err=True)
            for entry in failed:
                click.echo(f"  - {entry['id']}: {entry['reason']}", err=True)

    if failed:
        context.exit(1)
