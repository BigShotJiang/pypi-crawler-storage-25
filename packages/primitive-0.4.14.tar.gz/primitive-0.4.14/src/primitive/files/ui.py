from rich.console import Console
from rich.table import Table


def render_files_table(file_list) -> None:
    console = Console()

    table = Table(show_header=True, header_style="bold #FFA800")
    table.add_column("File Name")
    table.add_column("File ID")
    table.add_column("File Size (bytes)", justify="right")

    for file in file_list:
        file_name = file.get("fileName")
        file_id = file.get("id")
        file_size = file.get("fileSize")

        table.add_row(
            file_name,
            file_id,
            file_size,
        )

    console.print(table)


def render_files_delete_preview(
    files: list[dict],
    *,
    title: str = "About to delete",
) -> None:
    """Render a table of files to stderr ahead of a delete confirmation."""
    console = Console(stderr=True)

    table = Table(title=title, show_header=True, header_style="bold #FFA800")
    table.add_column("ID")
    table.add_column("Name")
    table.add_column("Size", justify="right")
    table.add_column("Key Prefix")
    table.add_column("Updated")

    for file in files:
        size = file.get("humanReadableMemorySize") or (
            str(file.get("fileSize")) if file.get("fileSize") is not None else ""
        )
        updated_at = file.get("updatedAt") or ""
        table.add_row(
            file.get("id") or "",
            file.get("fileName") or "",
            size,
            file.get("keyPrefix") or "",
            updated_at[:19],
        )

    console.print(table)


def file_status_string(file) -> str:
    if file.get("isQuarantined"):
        return "Quarantined"
    if not file.get("isOnline"):
        return "Offline"
    if not file.get("isHealthy"):
        return "Not healthy"
    if not file.get("isAvailable"):
        return "Not available"
    else:
        return "Available"
