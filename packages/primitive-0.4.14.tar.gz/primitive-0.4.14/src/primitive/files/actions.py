import concurrent
import hashlib
import sys
import urllib.parse
from pathlib import Path
from typing import IO, Callable, Dict, Optional

import requests
from gql import gql
from loguru import logger
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TaskID,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from primitive.graphql.relay import from_base64
from primitive.graphql.sdk import create_requests_session
from primitive.utils.actions import BaseAction
from ..graphql.utility_fragments import operation_info_fragment

from ..utils.auth import create_new_session, guard
from ..utils.chunk_size import calculate_optimal_chunk_size, get_upload_speed_mb
from ..utils.memory_size import MemorySize
from .graphql.mutations import (
    file_update_mutation,
    files_delete_mutation,
    pending_file_create_mutation,
    update_parts_details,
)
from .graphql.queries import files_list


# Upper bound on how many files we'll scan for --key-prefix / --file-name
# resolution. Backend caps `first` at 100 — do not raise this past that without
# wiring up pagination.
_RESOLVE_PAGE_SIZE = 100

SKIP_REASON_ALREADY_DELETED = "already deleted"
SKIP_REASON_DELETION_IN_PROGRESS = "deletion in progress"
SKIP_REASON_NOT_FOUND = "not found"
FAIL_REASON_NOT_RETURNED = "not returned in deletedIds"


class FilesDeleteError(Exception):
    """Raised when ``filesDelete`` returns ``OperationInfo`` messages.

    Carries the structured server messages so the caller can branch on
    message ``kind`` / ``code`` rather than substring-matching the text.
    """

    def __init__(self, messages: list[dict]):
        self.messages = messages
        rendered = "\n".join(
            str(m.get("message") or "") for m in messages if isinstance(m, dict)
        )
        super().__init__(rendered)

    def is_permission_denied(self) -> bool:
        for message in self.messages:
            if not isinstance(message, dict):
                continue
            kind = (message.get("kind") or "").upper()
            code = (message.get("code") or "").upper()
            if "PERMISSION" in kind or "PERMISSION" in code:
                return True
        return False


def looks_like_file_global_id(value: str) -> bool:
    """Does ``value`` base64-decode to a ``File:<id>`` relay GlobalID?"""
    if not value:
        return False
    try:
        type_name, _ = from_base64(value)
    except ValueError:
        return False
    return type_name == "File"


def _format_candidate_line(node: dict) -> str:
    key_prefix = (
        extract_key_prefix(node.get("location"), node.get("fileName")) or "(none)"
    )
    return (
        f"  - {node.get('id')}  "
        f"name={node.get('fileName')!r}  "
        f"keyPrefix={key_prefix}  "
        f"updated={(node.get('updatedAt') or '')[:19]}"
    )


def _format_ambiguous_error(name: str, edges: list[dict]) -> str:
    candidates = "\n".join(_format_candidate_line(e["node"]) for e in edges)
    return (
        f"Multiple files named '{name}' in scope. "
        "Disambiguate with --file-id or --key-prefix:\n" + candidates
    )


def _format_not_found_error(
    name: str,
    fuzzy_edges: list[dict],
    scope_org_id: Optional[str],
) -> str:
    scope = (
        f"organization_id={scope_org_id}"
        if scope_org_id
        else "the default organization"
    )
    if not fuzzy_edges:
        return (
            f"No file named '{name}' found in {scope}. "
            "The name match is exact and case-sensitive. "
            "Try `primitive files list` to see what's available, "
            "or pass --organization / --file-id."
        )
    candidates = "\n".join(_format_candidate_line(e["node"]) for e in fuzzy_edges)
    return (
        f"No exact match for '{name}' in {scope}, but these files have similar "
        f"names:\n{candidates}\n"
        "Re-run with the exact name or pass an explicit --file-id."
    )


def extract_key_prefix(location: Optional[str], file_name: Optional[str]) -> str:
    """Derive the key prefix from a File.location URL.

    Mirrors ``frontend/packages/ui/src/components/files/format-file-name.tsx``.
    Key layout produced by the backend is
    ``<org-slug>/<optional prefix>/<file_name>``.
    """
    if not location or not file_name:
        return ""
    try:
        parsed = urllib.parse.urlparse(location)
        segments = [s for s in parsed.path.split("/") if s]
        if not segments:
            return ""
        encoded_key = segments[-1]
        parts = [p for p in urllib.parse.unquote(encoded_key).split("/") if p]
        prefix_parts = parts[1:]
        if prefix_parts and prefix_parts[-1] == file_name:
            prefix_parts.pop()
        return "/".join(prefix_parts)
    except (ValueError, AttributeError):
        return ""


class _CountingReader:
    """File-like wrapper that advances a callback by the number of bytes read.

    Used to tick a Rich progress bar as `requests` streams a multipart upload body.
    Delegates any attribute that isn't `read` to the underlying file handle so the
    multipart encoder can still inspect size/position as needed.
    """

    def __init__(self, fp: IO[bytes], advance: Callable[[int], None]) -> None:
        self._fp = fp
        self._advance = advance

    def read(self, size: int = -1) -> bytes:
        chunk = self._fp.read(size)
        if chunk:
            self._advance(len(chunk))
        return chunk

    def __getattr__(self, name: str):
        return getattr(self._fp, name)


class Files(BaseAction):
    def __init__(self, primitive):
        super().__init__(primitive)
        self.num_workers = 4
        self.upload_speed_mbps = "100"
        self._stderr_console = Console(stderr=True)

    def _make_progress(
        self, description: str, total: int | None
    ) -> tuple[Progress, TaskID]:
        # Render to stderr so --json stdout is never polluted. Gate on the stream we
        # actually render to (stderr): if stderr is piped to a file, suppress to avoid
        # ANSI artifacts; if stdout is piped but stderr is a terminal (common in CI),
        # still show the bar. --json additionally forces the bar off.
        show_bar = sys.stderr.isatty() and not self.primitive.JSON
        progress = Progress(
            TextColumn("[bold blue]{task.description}", justify="right"),
            BarColumn(bar_width=None),
            "[progress.percentage]{task.percentage:>3.1f}%",
            "•",
            DownloadColumn(),
            "•",
            TransferSpeedColumn(),
            "•",
            TimeRemainingColumn(),
            console=self._stderr_console,
            transient=False,
            disable=not show_bar,
            # Default refresh rate (10 Hz) is too slow for fast local transfers —
            # the bar renders once at 0% and once at 100%, hiding intermediate
            # state. 30 Hz gives visible animation for anything above ~100 ms.
            refresh_per_second=30,
        )
        task_id = progress.add_task(description, total=total)
        return progress, task_id

    def _pending_file_create(
        self,
        file_name: str,
        file_size: int,
        file_checksum: str,
        file_path: str,
        key_prefix: str,
        chunk_size: int,
        number_of_parts: int,
        is_public: bool = False,
        organization_id: Optional[str] = None,
        is_global: Optional[bool] = False,
    ):
        mutation = gql(pending_file_create_mutation)
        input = {
            "filePath": file_path,
            "fileName": file_name,
            "fileSize": file_size,
            "fileChecksum": file_checksum,
            "keyPrefix": key_prefix,
            "isPublic": is_public,
            "chunkSize": chunk_size,
            "numberOfParts": number_of_parts,
            "isGlobal": is_global,
        }
        if organization_id:
            input["organizationId"] = organization_id
        variables = {"input": input}
        result = self.primitive.session.execute(
            mutation, variable_values=variables, get_execution_result=True
        )
        data = result.data.get("pendingFileCreate")

        messages = data.get("messages")
        if messages:
            raise Exception("\n".join([message.get("message") for message in messages]))

        return data

    def _update_file_status(
        self,
        file_id: str,
        is_uploading: Optional[bool] = None,
        is_complete: Optional[bool] = None,
    ):
        mutation = gql(file_update_mutation)
        input: Dict[str, str | bool] = {
            "id": file_id,
        }
        if is_uploading is not None:
            input["isUploading"] = is_uploading
        if is_complete is not None:
            input["isComplete"] = is_complete

        variables = {"input": input}
        result = self.primitive.session.execute(
            mutation, variable_values=variables, get_execution_result=True
        )
        return result

    def _update_parts_details(
        self,
        file_id: str,
        part_number: int,
        etag: str,
    ):
        mutation = gql(update_parts_details)
        input = {
            "fileId": file_id,
            "partNumber": part_number,
            "etag": etag,
        }
        variables = {"input": input}

        # since this is called in a multithreaded environment,
        # we need to create a new session for each thread.
        session = create_new_session(self.primitive)
        result = session.execute(
            mutation, variable_values=variables, get_execution_result=True
        )
        return result

    @guard
    def files(
        self,
        file_id: Optional[str] = None,
        file_name: Optional[str] = None,
        organization_id: Optional[str] = None,
        organization_slug: Optional[str] = None,
        global_files: Optional[bool] = None,
        first: int = 25,
        file_name_lookup: str = "exact",
    ):
        query = gql(files_list)

        filters = {}
        if not organization_id and not organization_slug and not global_files:
            whoami_result = self.primitive.auth.whoami()
            default_organization = whoami_result.data["whoami"]["defaultOrganization"]
            organization_id = default_organization["id"]
            logger.info(
                f"Using default organization ID: {default_organization.get('slug')} ({organization_id})"
            )
        if organization_slug and not organization_id:
            organization = self.primitive.organizations.get_organization(
                slug=organization_slug
            )
            organization_id = organization.get("id")

        if organization_id:
            filters["organization"] = {"id": organization_id}
        if file_id:
            filters["id"] = file_id
        if file_name:
            filters["fileName"] = {file_name_lookup: file_name}
        if global_files:
            filters["isGlobal"] = {"exact": True}

        variables = {
            "first": first,
            "filters": filters,
        }
        result = self.primitive.session.execute(
            query, variable_values=variables, get_execution_result=True
        )
        return result

    def _upload_part(
        self,
        file_id: str,
        file_path: Path,
        part_number: int,
        presigned_url: str,
        start_byte: int,
        end_byte: int,
    ):
        part_data = None
        with open(file_path, "rb") as file:
            file.seek(start_byte)
            part_data = file.read(end_byte - start_byte)
            assert len(part_data) > 0
            file.seek(0)
        logger.debug(
            f"Part {part_number}. Start: {start_byte}. End: {end_byte}. Size: {len(part_data)}"
        )

        md5_hexdigest = hashlib.md5(part_data).hexdigest()  # Get raw MD5 bytes

        logger.debug(f"Uploading part {part_number}...")
        # Upload the part using the pre-signed URL
        response = requests.put(
            presigned_url,
            data=part_data,
        )
        # cleanup memory
        part_data = None

        logger.debug(f"Part {part_number} ETag: {response.headers.get('ETag')}")
        if response.ok:
            # Extract the ETag for the part from the response headers
            etag = response.headers.get("ETag").replace('"', "")
            if not etag:
                logger.error("Failed to retrieve ETag from response headers")
        else:
            logger.error(response.text)
            response.raise_for_status()

        if etag != md5_hexdigest:
            message = f"Part {part_number} ETag does not match MD5 checksum: {etag} != {md5_hexdigest}"
            logger.error(message)
            raise Exception(message)

        if etag:
            return self._update_parts_details(
                file_id, part_number=part_number, etag=etag
            )
        else:
            logger.error(f"Failed to upload part {part_number}")
            return None

    @guard
    def upload_file_direct(
        self,
        path: Path,
        is_public: bool = False,
        key_prefix: str = "",
        file_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        is_global: Optional[bool] = False,
    ):
        if path.exists() is False:
            raise Exception(f"File {path} does not exist.")

        file_size = path.stat().st_size
        if file_size == 0:
            raise Exception(f"{path} is empty.")

        file_checksum = hashlib.md5(path.read_bytes()).hexdigest()

        parts_details = None

        if not self.upload_speed_mbps:
            logger.info("Calculating upload speed...")
            self.upload_speed_mbps = get_upload_speed_mb()
            logger.info(f"Upload speed: {self.upload_speed_mbps} MB/s")

        if not file_id:
            chunk_size, number_of_parts = calculate_optimal_chunk_size(
                upload_speed_mb=self.upload_speed_mbps,
                file_size_bytes=file_size,
                num_workers=self.num_workers,
                optimal_time_seconds=5,
            )
            chunk_size_ms = MemorySize(chunk_size, "B")
            chunk_size_ms.convert_to("MB")
            logger.info(
                f"Creating Pending File for {path}. File Size: {MemorySize(file_size, 'B').get_human_readable()} ({file_size}). Chunk size: {chunk_size_ms} at Number of parts: {number_of_parts}"
            )

            pending_file_create = self._pending_file_create(
                file_name=path.name,
                file_size=path.stat().st_size,
                file_checksum=file_checksum,
                file_path=str(path),
                key_prefix=key_prefix,
                is_public=is_public,
                chunk_size=chunk_size,
                number_of_parts=number_of_parts,
                organization_id=organization_id,
                is_global=is_global,
            )
            file_id = pending_file_create.get("id")
            parts_details = pending_file_create.get("partsDetails")
        else:
            file_result = self.files(file_id=file_id)
            parts_details = (
                file_result.data.get("files")
                .get("edges")[0]
                .get("node")
                .get("partsDetails")
            )

        if not file_id:
            raise Exception("No file_id found or provided.")
        if not parts_details:
            raise Exception(f"No parts_details returned for File ID: {file_id}.")

        self._update_file_status(file_id, is_uploading=True)

        # now create a multithreaded uploader based on the number of cores available
        # each thread will read from its starting and ending byte range provided by parts_details
        # and upload that part to the presigned url
        # an ETag will be returned for each part uploaded and will need to stored in the parts_details
        # on the server side by updating the File object

        is_complete = True

        progress, task_id = self._make_progress(f"↑ {path.name}", total=file_size)

        # Upload parts in parallel
        with (
            progress,
            concurrent.futures.ThreadPoolExecutor(
                max_workers=self.num_workers
            ) as executor,
        ):
            future_to_part = {
                executor.submit(
                    self._upload_part,
                    file_id=file_id,
                    file_path=path,
                    part_number=part_details.get("PartNumber"),
                    presigned_url=part_details.get("presigned_url"),
                    start_byte=part_details.get("start_byte"),
                    end_byte=part_details.get("end_byte"),
                ): part_details
                for _key, part_details in parts_details.items()
            }
            for future in concurrent.futures.as_completed(future_to_part):
                part_detail = future_to_part[future]
                try:
                    future.result()
                    part_size = part_detail["end_byte"] - part_detail["start_byte"]
                    progress.update(task_id, advance=part_size)
                    logger.debug(
                        f"Part {part_detail.get('PartNumber')} uploaded successfully."
                    )
                except Exception as exception:
                    logger.error(
                        f"Part {part_detail.get('PartNumber')} generated an exception: {exception}"
                    )
                    is_complete = False

        # when all parts have ETags (updated), send an update that
        if is_complete:
            result = self._update_file_status(
                file_id, is_uploading=False, is_complete=True
            )
            logger.info(f"File {path} marked is_complete.")
            file_data = result.data.get("fileUpdate", {}) if result.data else {}
            file_id_out = file_data.get("id") if isinstance(file_data, dict) else None
            if not file_id_out:
                error_details = []
                graphql_errors = getattr(result, "errors", None)
                if graphql_errors:
                    error_details.append(
                        "GraphQL errors: " + "; ".join(str(e) for e in graphql_errors)
                    )
                if isinstance(file_data, dict):
                    operation_messages = file_data.get("messages")
                    if operation_messages:
                        error_details.append(
                            "Server messages: "
                            + "; ".join(str(m) for m in operation_messages)
                        )
                detail_suffix = (
                    f" Details: {' | '.join(error_details)}" if error_details else ""
                )
                raise Exception(
                    f"File status update failed for {path}: no id returned.{detail_suffix}"
                )
            return {"id": file_id_out, "pk": file_data.get("pk")}
        else:
            raise Exception(f"Upload incomplete: one or more parts failed for {path}")

    @guard
    def upload_file_via_api(
        self,
        path: Path,
        is_public: bool = False,
        key_prefix: str = "",
        organization_id: Optional[str] = None,
        is_global: bool = False,
    ):
        """
        This method uploads a file via the Primitive API.
        This does NOT upload the file straight to S3
        """
        file_path = str(path.resolve())
        if path.exists() is False:
            raise FileNotFoundError(f"File not found at {file_path}")

        if is_public:
            operations = (
                """{ "query":\""""
                + operation_info_fragment.replace("\n", " ")
                + """mutation fileUpload($input: FileUploadInput!) { fileUpload(input: $input) { ... on File { id pk }, ...OperationInfoFragment } }", "variables": { "input": { "fileObject": null, "isPublic": true, "filePath": \""""
                + file_path
                + """\", "keyPrefix": \""""
                + key_prefix
                + """\", "isGlobal": """
                + ("true" if is_global else "false")
                + (
                    f', "organizationId": "{organization_id}"'
                    if organization_id
                    else ""
                )
                + """ } } }"""
            )  # noqa

        else:
            operations = (
                """{ "query":\""""
                + operation_info_fragment.replace("\n", " ")
                + """mutation fileUpload($input: FileUploadInput!) { fileUpload(input: $input) { ... on File { id pk }, ...OperationInfoFragment } }", "variables": { "input": { "fileObject": null, "isPublic": false, "filePath": \""""
                + file_path
                + """\", "keyPrefix": \""""
                + key_prefix
                + """\", "isGlobal": """
                + ("true" if is_global else "false")
                + (
                    f', "organizationId": "{organization_id}"'
                    if organization_id
                    else ""
                )
                + """ } } }"""
            )  # noqa
        session = create_requests_session(host_config=self.primitive.host_config)
        transport = self.primitive.host_config.get("transport")
        url = f"{transport}://{self.primitive.host}/"

        file_size = path.stat().st_size
        progress, task_id = self._make_progress(f"↑ {path.name}", total=file_size)

        with progress, open(path, "rb") as file_handle:
            counting_handle = _CountingReader(
                file_handle,
                lambda n: progress.update(task_id, advance=n),
            )
            body = {
                "operations": ("", operations),
                "map": ("", '{"fileObject": ["variables.input.fileObject"]}'),
                "fileObject": (path.name, counting_handle),
            }
            response = session.post(url, files=body)

        if not response.ok:
            body_snippet = response.text[:200] if response.text else "(empty body)"
            raise Exception(
                f"Upload failed: HTTP {response.status_code} from server. Body: {body_snippet}"
            )

        response_data = response.json()
        if not isinstance(response_data, dict):
            raise Exception("Upload failed: server returned an invalid JSON response.")

        graphql_errors = response_data.get("errors")
        if graphql_errors:
            error_messages = [
                e.get("message") if isinstance(e, dict) else str(e)
                for e in graphql_errors
            ]
            raise Exception(
                "Upload failed: GraphQL error(s): " + "\n".join(error_messages)
            )

        data = response_data.get("data")
        if not isinstance(data, dict):
            raise Exception(
                "Upload failed: GraphQL response did not include a valid 'data' object."
            )

        file_upload = data.get("fileUpload")
        if not isinstance(file_upload, dict):
            raise Exception(
                "Upload failed: GraphQL response did not include a valid 'fileUpload' object."
            )

        messages = file_upload.get("messages", [])
        if messages:
            raise Exception(
                "\n".join(
                    m.get("message") if isinstance(m, dict) else str(m)
                    for m in messages
                )
            )

        return {"id": file_upload.get("id"), "pk": file_upload.get("pk")}

    def get_presigned_url(self, file_pk: str) -> str:
        transport = self.primitive.host_config.get("transport")
        host = self.primitive.host_config.get("host")
        file_access_url = f"{transport}://{host}/files/{file_pk}/presigned-url/"
        return file_access_url

    def download_file(
        self,
        file_name: str = "",
        file_id: str = "",
        organization_id: str = "",
        organization_slug: str = "",
        output_path: Path = Path().cwd(),
        global_file: Optional[bool] = False,
    ) -> Path:
        file_pk = None
        file_size = None

        files_result = self.primitive.files.files(
            file_id=file_id,
            file_name=file_name,
            organization_id=organization_id,
            organization_slug=organization_slug,
            global_files=global_file,
        )
        if files_data := files_result.data:
            file = files_data["files"]["edges"][0]["node"]
            file_pk = file["pk"]
            file_name = file["fileName"]
            file_size = int(file["fileSize"])

        if not file_pk:
            raise Exception(
                "File not found on remote server. Please check file name or file id"
            )

        session = create_requests_session(host_config=self.primitive.host_config)
        transport = self.primitive.host_config.get("transport")

        if file_size and file_size < 5 * 1024 * 1024:
            url = f"{transport}://{self.primitive.host}/files/{file_pk}/stream/"
        else:
            url = f"{transport}://{self.primitive.host}/files/{file_pk}/presigned-url/"

        downloaded_file = output_path / file_name

        progress, task_id = self._make_progress(f"↓ {file_name}", total=file_size)

        with progress, session.get(url, stream=True) as response:
            response.raise_for_status()
            with open(downloaded_file, "wb") as partial_downloaded_file:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        partial_downloaded_file.write(chunk)
                        partial_downloaded_file.flush()
                        progress.update(task_id, advance=len(chunk))

        return downloaded_file

    def _annotate_file(self, file: dict) -> dict:
        return {
            **file,
            "keyPrefix": extract_key_prefix(file.get("location"), file.get("fileName")),
        }

    def _resolve_scope_org_id(
        self,
        organization_id: Optional[str],
        organization_slug: Optional[str],
    ) -> Optional[str]:
        if organization_id:
            return organization_id
        if organization_slug:
            organization = self.primitive.organizations.get_organization(
                slug=organization_slug
            )
            return organization.get("id")
        whoami_result = self.primitive.auth.whoami()
        default_organization = whoami_result.data["whoami"]["defaultOrganization"]
        return default_organization["id"]

    def resolve_file_ids(
        self,
        *,
        ids: list[str],
        names: list[str],
        key_prefix: Optional[str],
        organization_id: Optional[str] = None,
        organization_slug: Optional[str] = None,
    ) -> tuple[list[dict], list[dict]]:
        """Resolve selectors into concrete file dicts plus a skipped list.

        Returns ``(resolved, skipped)`` where each entry is a file node dict
        with an added ``keyPrefix`` field (and, for skipped, a ``reason``).
        Raises ``ValueError`` with a human-readable message if a name matches
        zero or more than one file in scope, or if ``key_prefix`` resolves to
        the empty string (which would otherwise match all top-level files).
        """
        # An empty --key-prefix (or "/" only) would client-side match every
        # top-level file in the org. The ticket explicitly rules out a
        # "delete everything in scope" path, so reject it here.
        if key_prefix is not None and not key_prefix.strip("/"):
            raise ValueError(
                "--key-prefix cannot be empty. "
                "Pass --file-id or --file-name to target top-level files."
            )

        # Resolve org scope once so downstream `self.files()` calls don't each
        # invoke `whoami()` / `get_organization()`.
        scope_org_id = self._resolve_scope_org_id(
            organization_id=organization_id,
            organization_slug=organization_slug,
        )

        resolved: dict[str, dict] = {}
        skipped: list[dict] = []
        seen_ids: set[str] = set()

        def _add(file: dict) -> None:
            annotated = self._annotate_file(file)
            file_id = annotated.get("id")
            if file_id:
                if file_id in seen_ids:
                    return
                seen_ids.add(file_id)
            if annotated.get("isDeleted"):
                skipped.append({**annotated, "reason": SKIP_REASON_ALREADY_DELETED})
                return
            if annotated.get("isDeleting"):
                skipped.append(
                    {**annotated, "reason": SKIP_REASON_DELETION_IN_PROGRESS}
                )
                return
            if not file_id:
                return
            resolved[file_id] = annotated

        for file_id in ids:
            if file_id in seen_ids:
                continue
            result = self.files(file_id=file_id, organization_id=scope_org_id, first=1)
            edges = (result.data or {}).get("files", {}).get("edges") or []
            if not edges:
                seen_ids.add(file_id)
                skipped.append({"id": file_id, "reason": SKIP_REASON_NOT_FOUND})
                continue
            _add(edges[0]["node"])

        for name in names:
            result = self.files(
                file_name=name,
                organization_id=scope_org_id,
                first=_RESOLVE_PAGE_SIZE,
            )
            edges = (result.data or {}).get("files", {}).get("edges") or []

            if len(edges) == 0:
                # Name match is exact+case-sensitive; fall back to a
                # case-insensitive contains search so the error can tell the
                # user whether the name is wrong, the scope is wrong, or the
                # file really isn't there.
                fuzzy_result = self.files(
                    file_name=name,
                    organization_id=scope_org_id,
                    first=_RESOLVE_PAGE_SIZE,
                    file_name_lookup="iContains",
                )
                fuzzy_edges = (fuzzy_result.data or {}).get("files", {}).get(
                    "edges"
                ) or []
                raise ValueError(
                    _format_not_found_error(name, fuzzy_edges, scope_org_id)
                )

            if len(edges) > 1:
                raise ValueError(_format_ambiguous_error(name, edges))

            _add(edges[0]["node"])

        if key_prefix is not None:
            result = self.files(
                organization_id=scope_org_id,
                first=_RESOLVE_PAGE_SIZE,
            )
            files_data = (result.data or {}).get("files") or {}
            edges = files_data.get("edges") or []
            total = files_data.get("totalCount")
            if isinstance(total, int) and total > _RESOLVE_PAGE_SIZE:
                # Loud on stderr so a user running interactively notices before
                # confirming — `logger.warning` would get swallowed at default
                # log level.
                sys.stderr.write(
                    f"WARNING: only scanning the first {_RESOLVE_PAGE_SIZE} of "
                    f"{total} files in scope for --key-prefix. "
                    "Use --file-id or --file-name to target files outside this "
                    "window.\n"
                )
            target = key_prefix.strip("/")
            for edge in edges:
                node = edge.get("node") or {}
                derived = extract_key_prefix(node.get("location"), node.get("fileName"))
                if derived == target or derived.startswith(target + "/"):
                    _add(node)

        return list(resolved.values()), skipped

    @guard
    def delete_files(self, file_ids: list[str]) -> dict:
        """Call the ``filesDelete`` mutation.

        Raises ``FilesDeleteError`` if the server returns ``OperationInfo``
        messages so the caller can branch on structured error kind / code.
        """
        mutation = gql(files_delete_mutation)
        variables = {"input": {"fileIds": list(file_ids)}}
        result = self.primitive.session.execute(
            mutation,
            variable_values=variables,
            get_execution_result=True,
        )
        data = (result.data or {}).get("filesDelete") or {}
        messages = data.get("messages") or []
        if messages:
            raise FilesDeleteError(messages)
        return {"deleted_ids": data.get("deletedIds") or []}
