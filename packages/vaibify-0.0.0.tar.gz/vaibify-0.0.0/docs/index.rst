Vaibify Documentation
=====================

**Vibe boldly. Verify everything.**

Vaibify is a secure, containerized environment for AI-assisted data science.
It decomposes projects into pipeline steps, executes them inside isolated
Docker containers, verifies the outputs, and publishes the results -- all
with minimal IDE interaction.

Vaibify grew out of efforts to make scientific computing workflows
reproducible and generalizes that approach so that any data science
pipeline can benefit from containerized reproducibility.

.. toctree::
   :maxdepth: 1

   conduct
   install
   quickStart
   setupWizard
   configuration
   cli
   pipelines
   gui
   testFormats
   templates
   security
   reproducibility
   developers
   GitHub <https://github.com/RoryBarnes/Vaibify>
   PyPI <https://pypi.org/project/vaibify/>
