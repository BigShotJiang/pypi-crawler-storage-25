"""Vaibify CLI package."""
