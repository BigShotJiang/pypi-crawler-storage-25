"""UsageTracker — SQLite-backed vault tool call logging for session profiling."""

from __future__ import annotations

from typing import Any

from hive._sqlite_tracker import _SqliteTracker


class UsageTracker(_SqliteTracker):
    """Track vault tool calls for session profiling and analytics."""

    _SCHEMA = """\
CREATE TABLE IF NOT EXISTS tool_calls (
    id INTEGER PRIMARY KEY,
    timestamp TEXT DEFAULT (datetime('now')),
    date TEXT DEFAULT (date('now')),
    tool TEXT NOT NULL,
    project TEXT DEFAULT '',
    response_lines INTEGER DEFAULT 0
);
"""

    def log_call(
        self,
        tool: str,
        project: str = "",
        response_lines: int = 0,
    ) -> None:
        """Record a vault tool call."""
        with self._lock:
            self._conn.execute(
                "INSERT INTO tool_calls (tool, project, response_lines) VALUES (?, ?, ?)",
                (tool, project, response_lines),
            )
            self._conn.commit()

    def stats(self, since_days: int = 30) -> dict[str, Any]:
        """Aggregate usage stats for the last N days."""
        since_clause = "WHERE date >= date('now', ? || ' days')"
        since_param = str(-since_days)

        with self._lock:
            total_row = self._conn.execute(
                f"SELECT COUNT(*) FROM tool_calls {since_clause}",
                (since_param,),
            ).fetchone()
            total_calls = total_row[0] if total_row else 0

            by_tool: dict[str, int] = {}
            rows = self._conn.execute(
                "SELECT tool, COUNT(*) FROM tool_calls "
                f"{since_clause} "
                "GROUP BY tool ORDER BY COUNT(*) DESC",
                (since_param,),
            ).fetchall()
            for tool, count in rows:
                by_tool[tool] = count

            by_project: dict[str, int] = {}
            rows = self._conn.execute(
                "SELECT project, COUNT(*) FROM tool_calls "
                f"{since_clause} "
                "AND project != '' "
                "GROUP BY project ORDER BY COUNT(*) DESC",
                (since_param,),
            ).fetchall()
            for project, count in rows:
                by_project[project] = count

            total_lines_row = self._conn.execute(
                "SELECT COALESCE(SUM(response_lines), 0) FROM tool_calls "
                f"{since_clause}",
                (since_param,),
            ).fetchone()
            total_lines = total_lines_row[0] if total_lines_row else 0

        return {
            "total_calls": total_calls,
            "total_response_lines": total_lines,
            "by_tool": by_tool,
            "by_project": by_project,
        }
