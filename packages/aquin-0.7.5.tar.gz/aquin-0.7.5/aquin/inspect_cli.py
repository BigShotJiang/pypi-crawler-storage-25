"""
aquin-inspect — CLI entry point.

Usage
─────
    # Inspect a dataset — uploads to Aquin servers, no local server needed
    aquin-inspect --dataset ./mydata.jsonl --api-key aq-...

    # Built-in model with pre-configured SAE (needs GPU)
    aquin-inspect --model gpt2-small-np --api-key aq-...

    # Custom / finetuned model with a HuggingFace SAE
    aquin-inspect --model myorg/my-llm --d-model 4096 --sae-layer 16 \
                  --sae-repo myorg/my-sae --sae-file layers.16/sae.safetensors \
                  --api-key aq-...

    # Custom model, train SAE at startup (GPU required)
    aquin-inspect --model myorg/my-llm --d-model 4096 --sae-layer 16 \
                  --train-sae --api-key aq-...
"""

import argparse
import json
import sys
from pathlib import Path


_LABEL = {
    "tq":         "Text quality",
    "pii":        "PII detection",
    "tox":        "Toxicity",
    "syn":        "Synthetic / AI-generated",
    "cr":         "Copyright risk",
    "bias":       "Bias surface",
    "oo":         "Opt-out",
    "pi":         "Prompt injection",
    "ps":         "Poisoned samples",
    "bt":         "Backdoor triggers",
    "lc":         "Liability chain",
    "compliance": "Compliance report",
}


def _load_dataset(path: str) -> tuple[list[dict], list[str]]:
    p = Path(path)
    if not p.exists():
        print(f"[aquin] Dataset not found: {path}", flush=True)
        sys.exit(1)

    rows: list[dict] = []
    if p.suffix in (".jsonl", ".json"):
        with open(p, encoding="utf-8") as f:
            if p.suffix == ".json":
                data = json.load(f)
                rows = data if isinstance(data, list) else [data]
            else:
                for line in f:
                    line = line.strip()
                    if line:
                        rows.append(json.loads(line))
    else:
        # fallback: try jsonl
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))

    if not rows:
        print(f"[aquin] Dataset is empty: {path}", flush=True)
        sys.exit(1)

    text_cols = [k for k, v in rows[0].items() if isinstance(v, str)]
    if not text_cols:
        print(f"[aquin] No string columns found in dataset.", flush=True)
        sys.exit(1)

    return rows, text_cols


def _submit_dataset(
    rows: list[dict],
    text_cols: list[str],
    dataset_name: str,
    api_key: str,
    base_url: str,
) -> None:
    """Upload dataset to Aquin servers and stream scan results."""
    import requests

    url     = f"{base_url}/api/dataset/submit"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    print(f"[aquin] Uploading {len(rows)} rows to Aquin servers …", flush=True)
    print(f"[aquin] Scanning columns: {text_cols}", flush=True)
    print(f"[aquin] This runs on our servers — no GPU needed on your machine.\n", flush=True)

    dims_done: set[str] = set()
    try:
        resp = requests.post(
            url,
            json={"rows": rows, "text_columns": text_cols, "dataset_name": dataset_name},
            headers=headers,
            stream=True,
            timeout=300,
        )
        if resp.status_code == 401:
            print("[aquin] Invalid API key.", flush=True)
            sys.exit(1)
        if not resp.ok:
            print(f"[aquin] Server error {resp.status_code}: {resp.text[:200]}", flush=True)
            sys.exit(1)

        for raw in resp.iter_lines():
            if not raw:
                continue
            try:
                ev = json.loads(raw)
            except Exception:
                continue
            dim = ev.get("dim")
            if dim == "done":
                break
            if dim and dim not in dims_done:
                dims_done.add(dim)
                label = _LABEL.get(dim, dim)
                print(f"  ✓ {label}", flush=True)

        print(f"\n[aquin] Scan complete — {len(dims_done)} checks finished.", flush=True)
        print(f"[aquin] Open the Aquin dashboard → Data Inspection → your results are ready.", flush=True)

    except KeyboardInterrupt:
        print("\n[aquin] Interrupted.", flush=True)
        sys.exit(0)
    except Exception as e:
        print(f"[aquin] Upload failed: {e}", flush=True)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        prog="aquin-inspect",
        description="Inspect a dataset or start a local model inspection server.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--api-key",   required=True,            help="Your Aquin API key (aq-...)")
    parser.add_argument("--dataset",   default=None,             help="Path to .jsonl or .json dataset to scan")
    parser.add_argument("--base-url",  default="https://www.aquin.app", help="Aquin base URL")

    # Model inspection flags (only relevant when NOT doing dataset-only)
    parser.add_argument("--model",     default=None,             help="Model ID for local inspection (built-in alias or HuggingFace ID)")
    parser.add_argument("--port",      type=int, default=7863,   help="Local port for inspection server (default: 7863)")
    parser.add_argument("--openai-key", default=None,            help="OpenAI API key for feature labeling")
    parser.add_argument("--d-model",   type=int, default=None,   help="Hidden size (required for custom HF models)")
    parser.add_argument("--n-layers",  type=int, default=None,   help="Number of layers")
    parser.add_argument("--sae-layer", type=int, default=None,   help="Layer to hook for SAE")
    sae_group = parser.add_mutually_exclusive_group()
    sae_group.add_argument("--sae-repo",  default=None,          help="HuggingFace repo with SAE weights")
    sae_group.add_argument("--train-sae", action="store_true",   help="Train SAE at startup (GPU required)")
    parser.add_argument("--sae-file",  default=None,             help="Path to safetensors inside --sae-repo")
    parser.add_argument("--sae-tokens", type=int, default=500_000, help="Tokens for SAE training")
    parser.add_argument("--sae-features", type=int, default=None, help="SAE feature count")
    # Legacy flag — kept for backwards compat but ignored when --dataset is set
    parser.add_argument("--data-only", action="store_true",      help=argparse.SUPPRESS)

    args = parser.parse_args()

    if args.sae_repo and not args.sae_file:
        parser.error("--sae-file is required when --sae-repo is set")
    if args.sae_file and not args.sae_repo:
        parser.error("--sae-repo is required when --sae-file is set")

    # ── Dataset upload mode (no local server) ─────────────────────────────────
    if args.dataset and not args.model:
        rows, text_cols = _load_dataset(args.dataset)
        dataset_name = Path(args.dataset).stem
        print(f"[aquin] Loaded {len(rows)} rows · columns: {text_cols}", flush=True)
        _submit_dataset(rows, text_cols, dataset_name, args.api_key, args.base_url)
        return

    # ── Model inspection mode (local server + relay) ──────────────────────────
    model_id = args.model or "llama-3.2-1b"

    from aquin.inspect import inspect, data_inspect
    import signal

    if args.data_only and not args.dataset:
        # Legacy data-only local server mode
        session = data_inspect(
            api_key=args.api_key,
            base_url=args.base_url,
            port=args.port,
        )
    else:
        session = inspect(
            model_id=model_id,
            api_key=args.api_key,
            base_url=args.base_url,
            port=args.port,
            openai_api_key=args.openai_key,
            d_model=args.d_model,
            n_layers=args.n_layers,
            sae_layer=args.sae_layer,
            sae_repo=args.sae_repo,
            sae_file=args.sae_file,
            train_sae=args.train_sae,
            sae_tokens=args.sae_tokens,
            sae_features=args.sae_features,
        )

    print(f"\n[aquin] Server running — open the Aquin dashboard and click Connect.", flush=True)
    print(f"[aquin] Press Ctrl+C to stop.\n", flush=True)
    try:
        session._server.wait()
    except KeyboardInterrupt:
        pass
    finally:
        session.stop()
        sys.exit(0)


if __name__ == "__main__":
    main()
