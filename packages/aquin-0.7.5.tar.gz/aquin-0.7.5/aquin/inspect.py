"""
aquin.inspect / aquin.data_inspect
───────────────────────────────────
Starts the Aquin inspection backend locally and connects it to the dashboard
via a WebSocket relay on relay.aquin.app. No tunnel binary required.

Usage
─────
    # Model + data inspection (needs GPU)
    session = aquin.inspect("llama-3.2-1b", api_key="aq-...")
    input("Press Enter to stop…")
    session.stop()

    # Data-only inspection (CPU is fine)
    session = aquin.data_inspect(api_key="aq-...")
    input("Press Enter to stop…")
    session.stop()
"""

from __future__ import annotations

import atexit
import hashlib
import json
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional

import requests

# ── Defaults ──────────────────────────────────────────────────────────────────

_DEFAULT_BASE_URL  = "https://api.aquin.app"
_DEFAULT_RELAY_URL = "ws://relay.aquin.app"
_DEFAULT_PORT      = 7863
_HEARTBEAT_EVERY   = 30   # seconds
_SAE_CACHE_DIR     = Path.home() / ".aquin" / "sae"

# ── WebSocket relay client ────────────────────────────────────────────────────

def _relay_loop(port: int, api_key: str, relay_url: str, stop_event: threading.Event):
    """
    Persistent WebSocket connection to relay.aquin.app.
    Receives request envelopes, calls local FastAPI, sends response back.
    Reconnects automatically on disconnect.
    """
    try:
        from websocket import WebSocketApp
    except ImportError:
        raise RuntimeError("websocket-client is required: pip install websocket-client")

    key_hash = hashlib.sha256(api_key.encode()).hexdigest()
    ws_url   = f"{relay_url}/sdk/{key_hash}"

    def on_message(ws, raw):
        try:
            msg = json.loads(raw)
        except Exception:
            return
        request_id = msg.get("request_id")
        if not request_id:
            return

        method  = msg.get("method", "GET")
        path    = msg.get("path", "/")
        query   = msg.get("query", "")
        headers = msg.get("headers", {})
        body    = msg.get("body", "")

        url = f"http://localhost:{port}{path}"
        if query:
            url += f"?{query}"

        # Strip hop-by-hop headers that shouldn't be forwarded
        forward_headers = {
            k: v for k, v in headers.items()
            if k.lower() not in ("host", "content-length", "transfer-encoding", "connection")
        }
        # Ensure the local server accepts the request (LOCAL_MODE bypasses Supabase auth)
        if "authorization" not in {k.lower() for k in forward_headers}:
            forward_headers["Authorization"] = f"Bearer {api_key}"

        try:
            resp = requests.request(
                method,
                url,
                headers=forward_headers,
                data=body.encode("utf-8") if body else None,
                timeout=120,
                stream=False,
            )
            response_body = resp.text
            status        = resp.status_code
            ct            = resp.headers.get("content-type", "application/json")
        except Exception as e:
            response_body = json.dumps({"error": str(e)})
            status        = 502
            ct            = "application/json"

        ws.send(json.dumps({
            "request_id": request_id,
            "status":     status,
            "headers":    {"content-type": ct},
            "body":       response_body,
        }))

    def on_error(ws, error):
        if not stop_event.is_set():
            print(f"[aquin relay] connection error: {error}", flush=True)

    def on_close(ws, *_):
        if not stop_event.is_set():
            print("[aquin relay] disconnected — reconnecting …", flush=True)

    def on_open(ws):
        print("[aquin relay] connected to relay.aquin.app", flush=True)

    while not stop_event.is_set():
        try:
            ws = WebSocketApp(
                ws_url,
                on_open=on_open,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
            )
            ws.run_forever(ping_interval=20, ping_timeout=10)
        except Exception as e:
            if not stop_event.is_set():
                print(f"[aquin relay] error: {e}", flush=True)
        if not stop_event.is_set():
            time.sleep(3)


# ── SAE weight pull ───────────────────────────────────────────────────────────

def _pull_sae_weights(model_id: str, api_key: str, base_url: str) -> Optional[Path]:
    """Download SAE weights for model_id to ~/.aquin/sae/ if not already cached."""
    _SAE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    safe = model_id.replace("/", "_").replace(":", "_")
    dest      = _SAE_CACHE_DIR / f"sae_{safe}.pt"
    dest_safe = _SAE_CACHE_DIR / f"sae_{safe}.safetensors"
    if dest.exists():
        return dest
    if dest_safe.exists():
        return dest_safe

    print(f"[aquin inspect] pulling SAE weights for {model_id} …", flush=True)
    try:
        resp = requests.get(
            f"{base_url}/api/worker/sae-weights",
            params={"model_id": model_id},
            headers={"Authorization": f"Bearer {api_key}"},
            stream=True,
            timeout=300,
        )
        if resp.status_code == 404:
            print(f"[aquin inspect] SAE weights not available on server — will use HuggingFace.", flush=True)
            return None
        resp.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1024 * 1024):
                f.write(chunk)
        print(f"[aquin inspect] SAE weights cached at {dest}", flush=True)
        return dest
    except Exception as e:
        print(f"[aquin inspect] WARNING: could not pull SAE weights: {e}", flush=True)
        return None


# ── Server launcher ───────────────────────────────────────────────────────────

def _find_server_py() -> Path:
    """Locate server.py — bundled inside the package at aquin/server/server.py."""
    candidates = [
        Path(__file__).parent / "server" / "server.py",
        Path(__file__).parent.parent.parent / "inspection-backend" / "server.py",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError(
        "[aquin inspect] Could not find server.py — try: pip install --force-reinstall 'aquin[inspect]'"
    )


def _launch_server(
    port: int,
    model_id: Optional[str],
    data_only: bool,
    api_key: str,
    base_url: str,
    openai_api_key: Optional[str],
    d_model: Optional[int]       = None,
    n_layers: Optional[int]      = None,
    sae_layer: Optional[int]     = None,
    sae_repo: Optional[str]      = None,
    sae_file: Optional[str]      = None,
    train_sae: bool              = False,
    sae_tokens: int              = 500_000,
    sae_features: Optional[int]  = None,
) -> subprocess.Popen:
    server_py = _find_server_py()
    env = {
        **os.environ,
        "LOCAL_MODE":       "1",
        "DATA_ONLY":        "1" if data_only else "0",
        "LOCAL_MODEL_ID":   model_id or "llama-3.2-1b",
        "TRAIN_SAE":        "1" if train_sae else "0",
        "AQUIN_SAE_TOKENS": str(sae_tokens),
    }
    if openai_api_key:
        env["OPENAI_API_KEY"] = openai_api_key
    if d_model is not None:
        env["AQUIN_D_MODEL"]      = str(d_model)
    if n_layers is not None:
        env["AQUIN_N_LAYERS"]     = str(n_layers)
    if sae_layer is not None:
        env["AQUIN_SAE_LAYER"]    = str(sae_layer)
    if sae_repo:
        env["AQUIN_SAE_REPO"]     = sae_repo
    if sae_file:
        env["AQUIN_SAE_FILE"]     = sae_file
    if sae_features is not None:
        env["AQUIN_SAE_FEATURES"] = str(sae_features)

    _BUILTIN = {"llama-3.2-1b", "pythia-2.8b", "gpt2-small-np", "pythia-70m-hf"}
    if model_id and model_id not in _BUILTIN:
        env["AQUIN_HF_NAME"] = model_id

    cmd = [
        sys.executable, "-m", "uvicorn",
        "server:app",
        "--host", "0.0.0.0",
        "--port", str(port),
        "--log-level", "warning",
    ]
    proc = subprocess.Popen(cmd, cwd=str(server_py.parent), env=env)

    # Wait for startup to fully complete (model + SAE loaded)
    timeout  = 10800 if train_sae else 300
    deadline = time.time() + timeout
    last_status = ""
    while time.time() < deadline:
        try:
            r = requests.get(f"http://localhost:{port}/health", timeout=2)
            if r.status_code == 200:
                info   = r.json()
                status = info.get("status", "")
                if status == "starting" and last_status != "starting":
                    print("[aquin inspect] server starting — loading model + SAE …", flush=True)
                    last_status = "starting"
                elif status == "ok":
                    print(f"[aquin inspect] server ready — model={info.get('model_id')} sae={info.get('sae_loaded')}", flush=True)
                    return proc
        except Exception:
            pass
        if proc.poll() is not None:
            raise RuntimeError("[aquin inspect] server process exited unexpectedly during startup")
        time.sleep(2)

    proc.terminate()
    raise RuntimeError(f"[aquin inspect] server did not become ready within {timeout}s")


# ── Registration + heartbeat ──────────────────────────────────────────────────

def _register(model_id: Optional[str], capabilities: list[str], api_key: str, base_url: str):
    requests.post(
        f"{base_url}/api/worker/register-local-server",
        json={"tunnel_url": "relay", "model_id": model_id, "capabilities": capabilities},
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=10,
    ).raise_for_status()


def _deregister(api_key: str, base_url: str):
    try:
        requests.delete(
            f"{base_url}/api/worker/register-local-server",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=5,
        )
    except Exception:
        pass


def _heartbeat_loop(api_key: str, base_url: str, stop_event: threading.Event):
    while not stop_event.wait(_HEARTBEAT_EVERY):
        try:
            requests.patch(
                f"{base_url}/api/worker/register-local-server",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=5,
            )
        except Exception:
            pass


# ── LocalSession ──────────────────────────────────────────────────────────────

class LocalSession:
    """Handle returned by aquin.inspect() / aquin.data_inspect()."""

    def __init__(
        self,
        server_proc: subprocess.Popen,
        relay_thread: threading.Thread,
        model_id:    Optional[str],
        api_key:     str,
        base_url:    str,
        stop_event:  threading.Event,
        hb_thread:   threading.Thread,
    ):
        self._server      = server_proc
        self._relay       = relay_thread
        self.model_id     = model_id
        self._api_key     = api_key
        self._base_url    = base_url
        self._stop        = stop_event
        self._hb          = hb_thread
        self._stopped     = False

        atexit.register(self.stop)
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, lambda *_: self.stop())
            except (OSError, ValueError):
                pass

    def stop(self):
        if self._stopped:
            return
        self._stopped = True
        print("[aquin inspect] shutting down …", flush=True)
        self._stop.set()
        self._hb.join(timeout=5)
        _deregister(self._api_key, self._base_url)
        try:
            self._server.terminate()
            self._server.wait(timeout=10)
        except Exception:
            pass
        print("[aquin inspect] stopped.", flush=True)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.stop()


# ── Public API ────────────────────────────────────────────────────────────────

def inspect(
    model_id: str                = "llama-3.2-1b",
    api_key: str                 = "",
    base_url: str                = _DEFAULT_BASE_URL,
    relay_url: str               = _DEFAULT_RELAY_URL,
    port: int                    = _DEFAULT_PORT,
    sae_cache_dir: Optional[Path] = None,
    openai_api_key: Optional[str] = None,
    d_model: Optional[int]       = None,
    n_layers: Optional[int]      = None,
    sae_layer: Optional[int]     = None,
    sae_repo: Optional[str]      = None,
    sae_file: Optional[str]      = None,
    train_sae: bool              = False,
    sae_tokens: int              = 500_000,
    sae_features: Optional[int]  = None,
) -> LocalSession:
    """
    Start the full Aquin inspection server locally (model + data) and connect
    it to the dashboard via relay.aquin.app.

    Parameters
    ----------
    model_id:       Built-in alias or any HuggingFace model ID
    api_key:        Your Aquin API key (aq-...)
    base_url:       Aquin API base URL
    relay_url:      WebSocket relay URL (default: wss://relay.aquin.app)
    port:           Local port for the inspection server (default: 7863)
    openai_api_key: Optional OpenAI key for feature labeling
    d_model:        Hidden size — required for custom HF models
    n_layers:       Number of layers (optional)
    sae_layer:      Residual stream layer to hook for SAE (default: 8)
    sae_repo:       HuggingFace repo ID containing SAE weights
    sae_file:       File path inside sae_repo
    train_sae:      Train a SAE from scratch at startup (GPU required)
    sae_tokens:     Tokens to collect for training (default: 500_000)
    sae_features:   SAE feature count for train_sae (default: d_model * 8)
    """
    if not api_key.startswith("aq-"):
        raise ValueError("api_key must start with 'aq-'")

    global _SAE_CACHE_DIR
    if sae_cache_dir:
        _SAE_CACHE_DIR = Path(sae_cache_dir)

    if train_sae:
        print("[aquin inspect] --train-sae: SAE will be trained at startup (this may take a while) …", flush=True)

    print(f"[aquin inspect] starting inspection server on port {port} …", flush=True)
    server_proc = _launch_server(
        port, model_id, data_only=False,
        api_key=api_key, base_url=base_url,
        openai_api_key=openai_api_key,
        d_model=d_model, n_layers=n_layers, sae_layer=sae_layer,
        sae_repo=sae_repo, sae_file=sae_file,
        train_sae=train_sae, sae_tokens=sae_tokens, sae_features=sae_features,
    )

    stop_event = threading.Event()

    print("[aquin inspect] connecting to relay …", flush=True)
    relay_thread = threading.Thread(
        target=_relay_loop,
        args=(port, api_key, relay_url, stop_event),
        daemon=True,
    )
    relay_thread.start()

    # Give the relay a moment to connect
    time.sleep(2)

    capabilities = ["model", "data"]
    _register(model_id, capabilities, api_key, base_url)
    print("[aquin inspect] registered — open the Aquin dashboard and click Connect.", flush=True)

    hb_thread = threading.Thread(
        target=_heartbeat_loop,
        args=(api_key, base_url, stop_event),
        daemon=True,
    )
    hb_thread.start()

    return LocalSession(
        server_proc=server_proc,
        relay_thread=relay_thread,
        model_id=model_id,
        api_key=api_key,
        base_url=base_url,
        stop_event=stop_event,
        hb_thread=hb_thread,
    )


def data_inspect(
    api_key: str  = "",
    base_url: str = _DEFAULT_BASE_URL,
    relay_url: str = _DEFAULT_RELAY_URL,
    port: int     = _DEFAULT_PORT,
) -> LocalSession:
    """
    Start the Aquin inspection server in data-only mode (no model/SAE loading).
    CPU is fine. All dataset analysis endpoints are available.

    Parameters
    ----------
    api_key:   Your Aquin API key (aq-...)
    base_url:  Aquin API base URL
    relay_url: WebSocket relay URL (default: wss://relay.aquin.app)
    port:      Local port for the inspection server (default: 7863)
    """
    if not api_key.startswith("aq-"):
        raise ValueError("api_key must start with 'aq-'")

    print(f"[aquin inspect] starting data-only inspection server on port {port} …", flush=True)
    server_proc = _launch_server(
        port, model_id=None, data_only=True,
        api_key=api_key, base_url=base_url,
        openai_api_key=None,
    )

    stop_event = threading.Event()

    print("[aquin inspect] connecting to relay …", flush=True)
    relay_thread = threading.Thread(
        target=_relay_loop,
        args=(port, api_key, relay_url, stop_event),
        daemon=True,
    )
    relay_thread.start()

    time.sleep(2)

    capabilities = ["data"]
    _register(None, capabilities, api_key, base_url)
    print("[aquin inspect] registered — open the Aquin dashboard and click Connect.", flush=True)

    hb_thread = threading.Thread(
        target=_heartbeat_loop,
        args=(api_key, base_url, stop_event),
        daemon=True,
    )
    hb_thread.start()

    return LocalSession(
        server_proc=server_proc,
        relay_thread=relay_thread,
        model_id=None,
        api_key=api_key,
        base_url=base_url,
        stop_event=stop_event,
        hb_thread=hb_thread,
    )