"""慧媒引擎 MCP Server — AI Agent 社媒自动化工具集

启动方式: huimei-mcp-server (stdio模式)
配置方式: 在 Claude Code / Hermes 的 MCP config 中添加 command: huimei-mcp-server
"""

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "huimei",
    instructions=(
        "慧媒引擎 — 多平台社媒自动化发布工具。"
        "支持抖音/快手/B站/小红书/微博等11个平台的账号管理和内容发布。"
        "使用前请先调用 huimei_login 登录。"
    ),
)


def _get_client():
    """获取已认证的 ApiClient，未登录则返回 None。"""
    from huimei_cli.config import get_server_url, get_token
    from huimei_cli.api_client import ApiClient
    token = get_token()
    if not token:
        return None
    return ApiClient(server_url=get_server_url(), token=token)


@mcp.tool()
def huimei_login(username: str, password: str, server_url: str = "") -> str:
    """登录慧媒引擎。首次使用必须调用。server_url 默认 http://localhost:5002"""
    from huimei_cli.auth import do_login, get_current_user
    url = server_url or None
    ok = do_login(username, password, url)
    if not ok:
        return "❌ 登录失败，请检查用户名密码"
    user = get_current_user()
    name = user.get("username", username) if user else username
    return f"✅ 登录成功，欢迎 {name}"


@mcp.tool()
def huimei_status() -> str:
    """查看当前登录状态、用户信息和订阅情况"""
    from huimei_cli.auth import is_logged_in, get_current_user
    from huimei_cli.config import get_server_url
    if not is_logged_in():
        return "未登录。请先调用 huimei_login"
    user = get_current_user()
    lines = [
        f"用户: {user.get('username', '?')}",
        f"服务器: {get_server_url()}",
    ]
    client = _get_client()
    if client:
        try:
            sub = client.get_subscription_info()
            if sub:
                lines.append(f"订阅: {sub.get('plan_name', '?')} (到期: {sub.get('expire_date', '?')})")
        except Exception:
            lines.append("订阅: 查询失败")
    return "\n".join(lines)


@mcp.tool()
def huimei_logout() -> str:
    """登出当前账号"""
    from huimei_cli.auth import logout
    logout()
    return "✅ 已登出"


@mcp.tool()
def huimei_platforms() -> str:
    """列出所有支持的社媒平台及其能力（视频/图文）"""
    import os, importlib
    registry_dir = os.path.join(
        os.path.dirname(__file__), "platforms", "registry"
    )
    lines = ["平台ID | 名称 | 视频 | 图文", "-------|------|------|------"]
    if not os.path.isdir(registry_dir):
        return "平台注册表为空"
    for f in sorted(os.listdir(registry_dir)):
        if f.endswith(".py") and not f.startswith("_"):
            pid = f[:-3]
            try:
                mod = importlib.import_module(f"huimei_cli.platforms.registry.{pid}")
                cfg = getattr(mod, "PLATFORM_CONFIG", {})
                v = "✅" if cfg.get("support_video") else "❌"
                i = "✅" if cfg.get("support_image") else "❌"
                lines.append(f"{pid} | {cfg.get('name', pid)} | {v} | {i}")
            except Exception:
                lines.append(f"{pid} | 加载失败 | ? | ?")
    return "\n".join(lines)


@mcp.tool()
def huimei_accounts() -> str:
    """列出所有已绑定的社媒平台账号"""
    client = _get_client()
    if not client:
        return "未登录。请先调用 huimei_login"
    try:
        accounts = client.get_accounts()
    except Exception as e:
        return f"查询失败: {e}"
    if not accounts:
        return "暂无绑定账号"
    lines = []
    for a in accounts:
        status = "🟢" if a.get("status") == "online" else "🔴"
        lines.append(f"{status} {a.get('platform_name','?')} | {a.get('account_name','?')} | ID:{a.get('id','?')}")
    return f"共 {len(accounts)} 个账号:\n" + "\n".join(lines)


@mcp.tool()
def huimei_publish(
    account_id: int,
    title: str = "",
    content: str = "",
    video_path: str = "",
    tags: str = "",
) -> str:
    """创建发布任务。account_id 从 huimei_accounts 获取。tags 逗号分隔。"""
    client = _get_client()
    if not client:
        return "未登录。请先调用 huimei_login"
    task_data = {"account_id": account_id}
    if title:
        task_data["title"] = title
    if content:
        task_data["content"] = content
    if video_path:
        task_data["video_path"] = video_path
    if tags:
        task_data["tags"] = [t.strip() for t in tags.split(",")]
    try:
        result = client.create_task(task_data)
        return f"✅ 任务已创建: {result}"
    except Exception as e:
        return f"❌ 创建失败: {e}"


def main():
    """MCP Server 入口 (stdio 模式)"""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
