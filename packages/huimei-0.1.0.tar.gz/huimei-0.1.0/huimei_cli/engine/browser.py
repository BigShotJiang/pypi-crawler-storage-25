"""Local Playwright browser management for CLI mode."""

import logging
from playwright.async_api import async_playwright, Browser, BrowserContext, Page, Playwright

from huimei_cli.config import get_config

logger = logging.getLogger(__name__)


class BrowserManager:
    """Manages a local Playwright Chromium browser instance."""

    def __init__(self, headless: bool = True):
        self.headless = headless
        self._playwright: Playwright | None = None
        self._browser: Browser | None = None

    async def start(self) -> "BrowserManager":
        """Start Playwright and launch Chromium."""
        self._playwright = await async_playwright().start()

        launch_opts: dict = {"headless": self.headless}

        # Apply proxy from config if available
        config = get_config()
        proxy = config.get("proxy")
        if proxy:
            launch_opts["proxy"] = {"server": proxy}
            logger.debug("Using proxy: %s", proxy)

        self._browser = await self._playwright.chromium.launch(**launch_opts)
        logger.info("Browser launched (headless=%s)", self.headless)
        return self

    async def new_context(
        self,
        cookies: list[dict] | None = None,
        storage_state: str | dict | None = None,
    ) -> BrowserContext:
        """Create a new browser context with optional cookies/storage state."""
        if not self._browser:
            raise RuntimeError("Browser not started. Call start() first.")

        ctx_opts: dict = {}
        if storage_state:
            ctx_opts["storage_state"] = storage_state

        context = await self._browser.new_context(**ctx_opts)

        if cookies:
            await context.add_cookies(cookies)
            logger.debug("Added %d cookies to context", len(cookies))

        return context

    async def close(self):
        """Close browser and stop Playwright."""
        if self._browser:
            await self._browser.close()
            self._browser = None
            logger.debug("Browser closed")
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None
            logger.debug("Playwright stopped")


async def create_browser_session(
    headless: bool = True,
    cookies: list[dict] | None = None,
    storage_state: str | dict | None = None,
) -> tuple["BrowserManager", BrowserContext, Page]:
    """Convenience helper: create a ready-to-use browser session.

    Returns (manager, context, page). Caller is responsible for calling
    manager.close() when done.
    """
    manager = BrowserManager(headless=headless)
    await manager.start()
    context = await manager.new_context(cookies=cookies, storage_state=storage_state)
    page = await context.new_page()
    return manager, context, page
