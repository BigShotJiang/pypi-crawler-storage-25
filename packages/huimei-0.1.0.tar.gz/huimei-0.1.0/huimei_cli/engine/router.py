"""Platform router — loads adapters from platforms/ directory."""

import importlib
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def get_login_orchestrator(platform_id: str) -> Optional[object]:
    """Load the login orchestrator for a given platform.

    Tries to import from huimei_cli.platforms.{platform_id}_uploader
    and instantiate the login orchestrator class.

    Args:
        platform_id: Platform identifier, e.g. 'douyin', 'xhs'

    Returns:
        Login orchestrator instance, or None if not found
    """
    # First try to get the class name from registry
    try:
        registry = importlib.import_module(
            f"huimei_cli.platforms.registry.{platform_id}"
        )
        config = getattr(registry, "PLATFORM_CONFIG", {})
        class_name = config.get("login_orchestrator_class")
        uploader_dir = config.get("uploader_dir")
    except ImportError:
        logger.warning(f"No registry config for platform: {platform_id}")
        return None

    if not class_name or not uploader_dir:
        logger.warning(f"Missing orchestrator config for: {platform_id}")
        return None

    # Import the uploader module and get the class
    try:
        module = importlib.import_module(
            f"huimei_cli.platforms.{uploader_dir}.login"
        )
        orchestrator_cls = getattr(module, class_name)
        return orchestrator_cls()
    except (ImportError, AttributeError) as e:
        logger.warning(f"Cannot load orchestrator for {platform_id}: {e}")
        return None


def get_video_uploader(platform_id: str) -> Optional[object]:
    """Load the video uploader for a given platform."""
    try:
        registry = importlib.import_module(
            f"huimei_cli.platforms.registry.{platform_id}"
        )
        config = getattr(registry, "PLATFORM_CONFIG", {})
        class_name = config.get("video_uploader_class")
        uploader_dir = config.get("uploader_dir")
    except ImportError:
        return None

    if not class_name or not uploader_dir:
        return None

    try:
        module = importlib.import_module(
            f"huimei_cli.platforms.{uploader_dir}.upload"
        )
        return getattr(module, class_name)()
    except (ImportError, AttributeError) as e:
        logger.warning(f"Cannot load uploader for {platform_id}: {e}")
        return None
