"""Terminal output handler using rich library."""

from contextlib import contextmanager

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn


class TerminalOutput:
    """Handles all terminal output with rich formatting."""

    def __init__(self):
        self.console = Console()

    def progress(self, message: str, percent: float = None):
        """Show progress with optional percentage bar."""
        if percent is not None:
            filled = int(percent / 5)
            bar = "█" * filled + "░" * (20 - filled)
            self.console.print(f"  [cyan]⏳ {message}[/cyan] [{bar}] {percent:.0f}%")
        else:
            self.console.print(f"  [cyan]⏳ {message}[/cyan]")

    def info(self, message: str):
        """Show info message."""
        self.console.print(f"  [blue]ℹ[/blue]  {message}")

    def success(self, message: str):
        """Show green success message."""
        self.console.print(f"  [green]✔[/green]  {message}")

    def error(self, message: str):
        """Show red error message."""
        self.console.print(f"  [red]✖[/red]  {message}")

    def warning(self, message: str):
        """Show yellow warning message."""
        self.console.print(f"  [yellow]⚠[/yellow]  {message}")

    def complete(self, result: dict):
        """Show completion with result summary."""
        self.console.print()
        self.console.rule("[bold green]Complete[/bold green]")
        if isinstance(result, dict):
            for key, value in result.items():
                self.console.print(f"  [bold]{key}:[/bold] {value}")
        else:
            self.console.print(f"  {result}")
        self.console.print()

    @contextmanager
    def status_context(self, message: str):
        """Context manager for spinner status indicator."""
        with self.console.status(f"[bold cyan]{message}[/bold cyan]", spinner="dots"):
            yield
