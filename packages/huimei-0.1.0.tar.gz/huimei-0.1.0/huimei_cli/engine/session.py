"""CLI Session adapter — drop-in replacement for cloud Session."""

import asyncio
import queue
import time
from enum import Enum
from typing import Any, Dict, Optional
from uuid import uuid4

from huimei_cli.engine.output import TerminalOutput


class SessionType(Enum):
    LOGIN = "login"
    PUBLISH = "publish"
    UNKNOWN = "unknown"

class SessionStatus(Enum):
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"

class BrowserType(Enum):
    PLAYWRIGHT = "playwright"
    DRISSIONPAGE = "drissionpage"
    AUTO = "auto"


class MockRequest:
    """Minimal stand-in for flask.Request."""
    def __init__(self):
        self.headers = {"User-Agent": "huimei-cli"}
        self.remote_addr = "127.0.0.1"


_MSG_MAP = {
    "progress": "progress", "info": "info", "success": "success",
    "error": "error", "warning": "warning", "complete": "complete",
}


class CliSession:
    """CLI-local session with the same attribute surface as cloud Session."""

    def __init__(self, platform_id: str,
                 session_type: SessionType = SessionType.PUBLISH,
                 browser_type: BrowserType = BrowserType.AUTO):
        self.session_id = str(uuid4())
        self.platform_id = platform_id
        self.session_type = session_type
        self.browser_type = browser_type
        self.status = SessionStatus.CREATED
        self.created_at = time.time()
        self.request = MockRequest()
        self.context = {
            "platform_id": platform_id,
            "user_agent": self.request.headers.get("User-Agent", ""),
            "client_ip": self.request.remote_addr,
        }
        # Browser resources (populated later)
        self.playwright_browser = self.playwright_page = self.playwright_context = None
        self.drissionpage_browser = self.drissionpage_tab = None
        self.browser = self.page = self.context_obj = None
        # Queues (interface compat)
        self.message_queue = queue.Queue()
        self.signal_queue = queue.Queue()
        self.input_queue = queue.Queue(maxsize=100)
        self._output = TerminalOutput()

    def send_message(self, message_type: str, data: Dict[str, Any]):
        """Route cloud-style SSE message to terminal output."""
        text = data.get("message") or data.get("msg") or str(data)
        method = getattr(self._output, _MSG_MAP.get(message_type, "info"))
        if message_type == "progress":
            method(text, data.get("percent"))
        elif message_type == "complete":
            method(data)
        else:
            method(text)

    def wait_for_input(self, timeout: float = 30.0) -> Optional[Dict]:
        """Synchronous terminal prompt (replaces queue-based wait)."""
        try:
            return {"type": "input", "data": input("  ⌨  Input required> ")}
        except (EOFError, KeyboardInterrupt):
            return None

    async def wait_for_input_async(self, timeout: float = 30.0) -> Optional[Dict]:
        """Async wrapper — runs blocking prompt in a thread."""
        return await asyncio.to_thread(self.wait_for_input, timeout)

    async def cleanup(self):
        """Release browser resources (mirrors cloud Session.cleanup)."""
        for attr in ("playwright_page", "playwright_context", "playwright_browser"):
            obj = getattr(self, attr, None)
            if obj:
                try:
                    await asyncio.wait_for(obj.close(), timeout=5.0)
                except Exception:
                    pass
                setattr(self, attr, None)
        self.browser = self.page = self.context_obj = None
        if self.status in (SessionStatus.RUNNING, SessionStatus.CREATED):
            self.status = SessionStatus.CANCELLED

    async def close(self):
        """Alias for cleanup."""
        await self.cleanup()
