"""Publish command."""

import typer
from rich.console import Console
from pathlib import Path
from typing import List

from huimei_cli.auth import is_logged_in
from huimei_cli.config import get_config, get_server_url
from huimei_cli.api_client import ApiClient, ApiError

console = Console()
app = typer.Typer(help="内容发布")


def _require_login():
    if not is_logged_in():
        console.print("[red]✗[/red] 请先登录: huimei login")
        raise typer.Exit(1)


@app.callback(invoke_without_command=True)
def publish(
    platform: str = typer.Option(..., "--platform", "-p", help="目标平台，逗号分隔，如 douyin,xhs"),
    video: Path = typer.Option(None, "--video", "-v", help="视频文件路径"),
    images: str = typer.Option(None, "--images", "-i", help="图片文件路径，逗号分隔"),
    title: str = typer.Option("", "--title", "-t", help="作品标题"),
    content: str = typer.Option("", "--content", "-c", help="作品正文/描述"),
    tags: str = typer.Option("", "--tags", help="标签，逗号分隔"),
):
    """发布内容到指定平台"""
    _require_login()

    platforms = [p.strip() for p in platform.split(",")]

    # Validate file
    if video and not video.exists():
        console.print(f"[red]✗[/red] 视频文件不存在: {video}")
        raise typer.Exit(1)

    if images:
        for img_path in images.split(","):
            if not Path(img_path.strip()).exists():
                console.print(f"[red]✗[/red] 图片文件不存在: {img_path}")
                raise typer.Exit(1)

    console.print(f"[cyan]准备发布到: {', '.join(platforms)}[/cyan]")

    # Create task via backend
    cfg = get_config()
    client = ApiClient(get_server_url(), cfg.get("token"))

    task_data = {
        "platforms": platforms,
        "title": title,
        "content": content,
        "tags": [t.strip() for t in tags.split(",") if t.strip()],
        "video_path": str(video) if video else None,
        "image_paths": [p.strip() for p in images.split(",")] if images else [],
    }

    try:
        result = client.create_task(task_data)
        task_id = result.get("task_id") if result else None
        console.print(f"[green]✓[/green] 任务已创建: {task_id}")
    except ApiError as e:
        console.print(f"[red]✗[/red] 创建任务失败: {e.message}")
        raise typer.Exit(1)

    # Execute locally per platform
    import asyncio
    for plat in platforms:
        console.print(f"\n[cyan]>>> 开始发布到 {plat}[/cyan]")
        try:
            asyncio.run(_do_publish(plat, task_data, task_id, client))
        except Exception as e:
            console.print(f"[red]✗[/red] {plat} 发布失败: {e}")
            if task_id:
                try:
                    client.report_task_result(task_id, {
                        "platform": plat, "status": "failed", "error": str(e)
                    })
                except Exception:
                    pass

    console.print("\n[green]发布流程完成[/green]")


async def _do_publish(platform: str, task_data: dict, task_id: str, client: ApiClient):
    """Execute publish for a single platform."""
    from huimei_cli.engine.session import CliSession
    from huimei_cli.engine.browser import create_browser_session
    from huimei_cli.engine.router import get_video_uploader

    uploader = get_video_uploader(platform)
    if not uploader:
        raise RuntimeError(f"平台 {platform} 的上传器暂未实现")

    session = CliSession(platform_id=platform, session_type="publish")
    manager, context, page = await create_browser_session(headless=False)

    try:
        session.playwright_browser = manager.browser
        session.playwright_context = context
        session.playwright_page = page
        session.page = page
        session.context_obj = context
        session.browser = manager.browser

        # TODO: Load cookies for this platform
        # TODO: Call uploader.execute_upload(session, task_data)
        console.print(f"[yellow]⚠[/yellow] {platform} 自动发布功能开发中")

        if task_id:
            client.report_task_result(task_id, {
                "platform": platform, "status": "pending", "message": "功能开发中"
            })
    finally:
        await manager.close()
