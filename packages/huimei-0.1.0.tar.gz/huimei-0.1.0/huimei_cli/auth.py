"""Authentication management for huimei-cli."""

import json
import base64

from huimei_cli.config import get_config, save_config, get_server_url, save_token
from huimei_cli.api_client import ApiClient, ApiError


def do_login(username: str, password: str, server_url: str = None) -> bool:
    """Login to the huimei server and save token to config.

    Args:
        username: User's username.
        password: User's password.
        server_url: Optional server URL override.

    Returns:
        True if login succeeded, False otherwise.
    """
    url = server_url or get_server_url()
    client = ApiClient(server_url=url)
    try:
        data = client.login(username, password)
        token = data.get("token") if isinstance(data, dict) else None
        if not token:
            return False
        save_token(token)
        # Also persist server_url if overridden
        if server_url:
            cfg = get_config()
            cfg["server_url"] = server_url
            save_config(cfg)
        return True
    except (ApiError, Exception):
        return False


def is_logged_in() -> bool:
    """Check whether a valid token exists in config."""
    cfg = get_config()
    return bool(cfg.get("token"))


def get_current_user() -> dict | None:
    """Decode the JWT token payload to get current user info.

    Decodes without verification — only reads the payload claims.

    Returns:
        Dict of user claims from token, or None if not logged in.
    """
    cfg = get_config()
    token = cfg.get("token")
    if not token:
        return None
    try:
        payload_b64 = token.split(".")[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        return json.loads(payload_bytes)
    except (IndexError, ValueError, json.JSONDecodeError):
        return None


def logout() -> None:
    """Clear authentication token from config."""
    cfg = get_config()
    cfg.pop("token", None)
    save_config(cfg)
