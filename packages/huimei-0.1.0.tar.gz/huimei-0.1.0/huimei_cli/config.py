"""Local configuration management for huimei-cli.

Config stored as JSON in ~/.huimei/config.json
"""

import json
import uuid
from pathlib import Path

CONFIG_DIR = Path.home() / ".huimei"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_SERVER_URL = "http://localhost:5002"

_DEFAULTS = {
    "server_url": DEFAULT_SERVER_URL,
    "token": None,
    "device_id": None,
}


def _ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def get_config() -> dict:
    """Load config from disk, returning defaults if file missing."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                stored = json.load(f)
            # Merge with defaults so new keys are always present
            return {**_DEFAULTS, **stored}
        except (json.JSONDecodeError, OSError):
            pass
    return dict(_DEFAULTS)


def save_config(config: dict):
    """Write config dict to disk as JSON."""
    _ensure_config_dir()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def get_server_url() -> str:
    """Return the configured server URL."""
    return get_config().get("server_url") or DEFAULT_SERVER_URL


def get_token() -> str | None:
    """Return the stored auth token, or None."""
    return get_config().get("token")


def save_token(token: str):
    """Persist an auth token to config."""
    config = get_config()
    config["token"] = token
    save_config(config)


def get_device_id() -> str:
    """Return a stable device ID, generating one on first call."""
    config = get_config()
    device_id = config.get("device_id")
    if not device_id:
        device_id = str(uuid.uuid4())
        config["device_id"] = device_id
        save_config(config)
    return device_id
