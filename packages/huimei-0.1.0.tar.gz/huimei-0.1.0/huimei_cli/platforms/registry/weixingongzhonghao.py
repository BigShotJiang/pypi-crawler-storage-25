"""
微信公众号 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: weixingongzhonghao
"""

# 微信公众号 平台配置
PLATFORM_CONFIG = {
    'name': '微信公众号',
    'support_video': True,
    'support_image': False,
    'uploader_dir': 'weixingongzhongonghao_uploader',
    'login_orchestrator_class': 'WechatLoginOrchestrator',
    'video_uploader_class': 'WechatVideoUploader',
    'image_uploader_class': None,
    'publish_params_config': {
        'fields': [
            {
                'key': 'title',
                'label': '标题',
                'type': 'text',
                'required': True,
                'placeholder': '请输入标题，1-30个字',
                'maxlength': 30,
                'description': '视频标题，最多30个字',
            },
        ],
    },
    'differences': {
        'proxy_required': False,
        'timeout_multiplier': 1.0,
        'retry_times': 3,
        'login_type': 'qr_code',
        'max_title_length': 30,
        'max_content_length': 400,
        'video_formats': [
            'mp4',
            'mov',
            'avi',
        ],
        'max_video_size': '2GB',
        'cover_required': True,
        'hashtag_format': '#tag',
        'tags_separator': 'space',
        'supports_scheduled_publish': False,
    },
}
