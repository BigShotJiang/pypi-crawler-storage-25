"""
TikTok 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: tk
"""

# TikTok 平台配置
PLATFORM_CONFIG = {
    'name': 'TikTok',
    'support_video': True,
    'support_image': False,
    'uploader_dir': 'tk_uploader',
    'login_orchestrator_class': 'TiktokLoginOrchestrator',
    'video_uploader_class': 'TiktokVideoUploader',
    'image_uploader_class': None,
    'publish_params_config': {
        'fields': [],
    },
    'differences': {
        'proxy_required': True,
        'timeout_multiplier': 1.5,
        'retry_times': 3,
    },
}
