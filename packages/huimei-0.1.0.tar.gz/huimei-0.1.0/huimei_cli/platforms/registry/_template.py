"""
平台配置模板 - 复制此文件来创建新平台配置

使用方法：
1. 复制此文件为新的平台ID文件名，如：douyin.py, xhs.py
2. 修改 PLATFORM_CONFIG 字典中的配置项
3. 删除不需要的可选配置项
4. 保存文件，系统会自动发现新平台

配置格式说明：
- 必需配置项：少了会报错
- 可选配置项：可以不填，有默认值
"""

PLATFORM_CONFIG = {
    # ==== 必需配置项 ====
    
    'name': '平台中文名称',  # 必需 - 如：'抖音', '小红书', 'B站'
    
    'support_video': True,   # 必需 - 是否支持视频发布，True/False
    'support_image': True,   # 必需 - 是否支持图文发布，True/False
    
    'uploader_dir': 'platform_uploader',  # 必需 - 对应的上传器目录名
    
    'login_orchestrator_class': 'PlatformLoginOrchestrator',  # 必需 - 登录编排器类名
    
    # 如果 support_video=True，必须提供此项
    'video_uploader_class': 'PlatformVideoUploader',  # 视频上传器类名
    
    # 如果 support_image=True，必须提供此项  
    'image_uploader_class': 'PlatformImageUploader',  # 图文上传器类名
    
    
    # ==== 可选配置项 ====
    
    # 发布参数配置 - 用户发布时需要填写的表单字段
    'publish_params_config': {
        'fields': [
            {
                'key': 'title',           # 字段标识符
                'label': '标题',          # 界面显示名称
                'type': 'text',           # 字段类型：text, textarea, select, toggle, location, autocomplete, autocomplete_tags
                'required': True,         # 是否必填
                'placeholder': '请输入标题', # 输入提示文本
                'description': '视频或图文的标题', # 字段说明
                'maxlength': 30,          # 最大长度限制
                
                # 仅select类型需要
                'options': [
                    {'value': 'public', 'label': '公开'},
                    {'value': 'private', 'label': '私密'}
                ],
                'default': 'public',      # 默认值
                
                # 仅autocomplete相关类型需要
                'api': '/api/v1/platforms/platform/tags',  # 自动完成API
                'max_items': 10,          # 最多选择项数
                
                # 验证规则（可选）
                'validation': {
                    'pattern': '^#.+',    # 正则表达式
                    'message': '请以#开头'  # 验证失败提示
                }
            }
            # 可以添加更多字段...
        ]
    },
    
    # 平台差异化参数 - 影响浏览器行为和网络请求
    'differences': {
        'proxy_required': False,      # 是否需要代理，True/False
        'timeout_multiplier': 1.0,    # 超时倍数，如 1.5 表示比默认超时长50%
        'retry_times': 3,             # 失败重试次数
        
        # 以下为可选的高级配置
        'login_type': 'qr_code',      # 登录方式：'qr_code', 'password', 'qr_code_with_password'
        'max_title_length': 30,       # 标题最大长度
        'max_content_length': 200,    # 内容最大长度
        'max_image_count': 60,        # 最多图片数量
        'video_formats': ['mp4', 'mov', 'avi'],  # 支持的视频格式
        'max_video_size': '2GB',      # 最大视频文件大小
        'cover_required': True,       # 是否必需封面图
        'hashtag_format': '#tag',     # 话题标签格式
        'tags_separator': 'space',    # 多标签分隔符：'space', 'comma'
        'supports_scheduled_publish': False,  # 是否支持定时发布
        'requires_sms_verification': False,   # 是否可能需要短信验证
        
        # 特殊HTTP请求头
        'special_headers': {
            'User-Agent': 'Platform/1.0',
            'Referer': 'https://platform.com'
        },
        
        # 反检测配置（高级）
        'anti_detection': {
            'wait_before_click': (1, 3),      # 点击前等待时间范围（秒）
            'wait_before_type': (0.5, 1.5),   # 输入前等待时间范围（秒）
            'min_scroll_delay': 0.3,           # 最小滚动延迟（秒）
            'max_scroll_delay': 1.2,           # 最大滚动延迟（秒）
            'human_like_typing': True,         # 启用类人类型输入
            'random_mouse_movements': True     # 启用随机鼠标移动
        }
    }
}

# ==== 字段类型说明 ====
"""
字段类型 (type)：
- text: 单行文本输入框
- textarea: 多行文本输入框  
- select: 下拉选择框，需要配置 options
- toggle: 开关按钮，True/False
- location: 位置选择器
- autocomplete: 自动完成输入框，需要配置 api
- autocomplete_tags: 多选标签自动完成，需要配置 api

特殊字段说明：
- maxlength: 文本最大长度限制
- max_length: 兼容字段，作用同 maxlength
- multiple: 是否允许多选（适用于某些类型）
- max_items: 最多选择项数（适用于多选类型）
"""