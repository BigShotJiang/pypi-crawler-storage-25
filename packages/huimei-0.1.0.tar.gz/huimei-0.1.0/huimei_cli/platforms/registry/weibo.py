"""
微博 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: weibo
"""

# 微博 平台配置
PLATFORM_CONFIG = {
    'name': '微博',
    'support_video': True,
    'support_image': True,
    'uploader_dir': 'weibo_uploader',
    'login_orchestrator_class': 'WeiboLoginOrchestrator',
    'video_uploader_class': 'WeiboVideoUploader',
    'image_uploader_class': 'WeiboImageUploader',
    'publish_params_config': {
        'fields': [
            {
                'key': 'video_type',
                'label': '视频类型',
                'type': 'select',
                'required': True,
                'options': [
                    {
                        'value': 'original',
                        'label': '原创',
                    },
                    {
                        'value': 'secondary',
                        'label': '二创',
                    },
                    {
                        'value': 'repost',
                        'label': '转载',
                    },
                ],
                'default': 'original',
                'description': '选择视频的创作类型',
            },
            {
                'key': 'category',
                'label': '分类',
                'type': 'select',
                'required': False,
                'options': [
                    {
                        'value': '娱乐',
                        'label': '娱乐',
                    },
                    {
                        'value': '体育',
                        'label': '体育',
                    },
                    {
                        'value': '美食',
                        'label': '美食',
                    },
                    {
                        'value': '旅游',
                        'label': '旅游',
                    },
                    {
                        'value': '科技',
                        'label': '科技',
                    },
                    {
                        'value': '教育',
                        'label': '教育',
                    },
                    {
                        'value': '时尚',
                        'label': '时尚',
                    },
                    {
                        'value': '汽车',
                        'label': '汽车',
                    },
                    {
                        'value': '游戏',
                        'label': '游戏',
                    },
                    {
                        'value': '生活',
                        'label': '生活',
                    },
                ],
                'default': '',
                'description': '选择视频所属分类',
            },
            {
                'key': 'title',
                'label': '标题',
                'type': 'text',
                'required': True,
                'placeholder': '填写标题（0~30个字）',
                'maxlength': 30,
                'description': '视频标题，最多30个字',
            },
            {
                'key': 'content',
                'label': '内容',
                'type': 'textarea',
                'required': False,
                'placeholder': '有什么新鲜事想分享给大家？',
                'maxlength': 2000,
                'description': '微博内容，最多2000字',
            },
            {
                'key': 'topic_tags',
                'label': '话题标签',
                'type': 'text',
                'placeholder': '输入话题，支持#话题格式，多个话题用空格分隔',
                'required': False,
                'description': '话题有助于提升曝光',
            },
            {
                'key': 'allow_highlight',
                'label': '允许划重点',
                'type': 'toggle',
                'default': True,
                'description': '允许用户在视频中划重点',
            },
            {
                'key': 'allow_clip',
                'label': '允许他人剪辑',
                'type': 'toggle',
                'default': True,
                'description': '允许其他用户剪辑你的视频',
            },
            {
                'key': 'allow_comment',
                'label': '允许评论',
                'type': 'toggle',
                'default': True,
                'description': '允许用户在微博下评论',
            },
            {
                'key': 'allow_repost',
                'label': '允许转发',
                'type': 'toggle',
                'default': True,
                'description': '允许用户转发此微博',
            },
        ],
    },
    'differences': {
        'proxy_required': False,
        'timeout_multiplier': 1.2,
        'retry_times': 3,
        'login_type': 'qr_code',
        'max_title_length': 140,
        'max_content_length': 2000,
        'video_formats': [
            'mp4',
            'mov',
            'avi',
        ],
        'max_video_size': '500MB',
        'cover_required': False,
        'hashtag_format': '#tag',
        'tags_separator': 'space',
    },
}
