"""
知乎 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: zhihu
"""

# 知乎 平台配置
PLATFORM_CONFIG = {
    'name': '知乎',
    'support_video': True,
    'support_image': True,
    'uploader_dir': 'zhihu_uploader',
    'login_orchestrator_class': 'ZhihuLoginOrchestrator',
    'video_uploader_class': 'ZhihuVideoUploader',
    'image_uploader_class': 'ZhihuImageUploader',
    'publish_params_config': {
        'fields': [],
    },
    'differences': {
        'proxy_required': True,
        'timeout_multiplier': 1.0,
        'retry_times': 3,
    },
}
