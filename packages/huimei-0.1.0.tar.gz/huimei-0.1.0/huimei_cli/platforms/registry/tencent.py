"""
视频号 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: tencent
"""

# 视频号 平台配置
PLATFORM_CONFIG = {
    'name': '视频号',
    'support_video': True,
    'support_image': True,
    'uploader_dir': 'tencent_uploader',
    'login_orchestrator_class': 'TencentLoginOrchestrator',
    'video_uploader_class': 'TencentVideoUploader',
    'image_uploader_class': None,
    'publish_params_config': {
        'fields': [],
    },
    'differences': {
        'proxy_required': False,
        'timeout_multiplier': 1.0,
        'retry_times': 3,
    },
}
