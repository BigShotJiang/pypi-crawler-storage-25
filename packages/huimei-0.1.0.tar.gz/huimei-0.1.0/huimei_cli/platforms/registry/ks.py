"""
快手 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: ks
"""

# 快手 平台配置
PLATFORM_CONFIG = {
    'name': '快手',
    'support_video': True,
    'support_image': True,
    'uploader_dir': 'ks_uploader',
    'login_orchestrator_class': 'KuaishouLoginOrchestrator',
    'video_uploader_class': 'KuaishouVideoUploader',
    'image_uploader_class': 'KuaishouImageUploader',
    'publish_params_config': {
        'fields': [],
    },
    'differences': {
        'proxy_required': True,
        'timeout_multiplier': 1.2,
        'retry_times': 3,
    },
}
