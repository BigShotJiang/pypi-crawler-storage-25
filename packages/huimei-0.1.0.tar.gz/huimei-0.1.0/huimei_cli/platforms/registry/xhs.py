"""
小红书 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: xhs
"""

# 小红书 平台配置
PLATFORM_CONFIG = {
    'name': '小红书',
    'support_video': True,
    'support_image': True,
    'uploader_dir': 'xhs_uploader',
    'login_orchestrator_class': 'XhsLoginOrchestrator',
    'video_uploader_class': 'XhsVideoUploader',
    'image_uploader_class': 'XhsImageUploader',
    'publish_params_config': {
        'fields': [
            {
                'key': 'location',
                'label': '添加位置',
                'type': 'location',
                'placeholder': '添加位置标签',
                'required': False,
                'description': '添加位置可以增加本地曝光',
            },
            {
                'key': 'topic_tags',
                'label': '话题标签',
                'type': 'autocomplete_tags',
                'api': '/api/v1/platforms/xhs/topic_tags',
                'placeholder': '点击选择话题标签，最多10个',
                'max_items': 10,
                'required': False,
                'description': '话题标签可以提升内容曝光度',
            },
            {
                'key': 'allow_comment',
                'label': '允许评论',
                'type': 'toggle',
                'default': True,
                'description': '关闭后用户无法评论',
            },
            {
                'key': 'allow_favorite',
                'label': '允许收藏',
                'type': 'toggle',
                'default': True,
                'description': '关闭后用户无法收藏',
            },
        ],
    },
    'differences': {
        'proxy_required': True,
        'timeout_multiplier': 1.5,
        'retry_times': 5,
        'special_headers': {
            'Referer': 'https://creator.xiaohongshu.com',
            'Origin': 'https://creator.xiaohongshu.com',
            'X-Requested-With': 'XMLHttpRequest',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
        },
        'anti_detection': {
            'wait_before_click': (1, 3),
            'wait_before_type': (0.5, 1.5),
            'min_scroll_delay': 0.3,
            'max_scroll_delay': 1.2,
            'human_like_typing': True,
            'random_mouse_movements': True,
        },
    },
}
