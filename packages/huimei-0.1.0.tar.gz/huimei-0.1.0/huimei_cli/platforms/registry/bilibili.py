"""
哔哩哔哩 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: bilibili
"""

# 哔哩哔哩 平台配置
PLATFORM_CONFIG = {
    'name': '哔哩哔哩',
    'support_video': True,
    'support_image': True,
    'uploader_dir': 'bilibili_uploader',
    'login_orchestrator_class': 'BilibiliLoginOrchestrator',
    'video_uploader_class': 'BilibiliVideoUploader',
    'image_uploader_class': 'BilibiliImageUploader',
    'publish_params_config': {
        'fields': [
            {
                'key': 'partition',
                'label': '投稿分区',
                'type': 'select',
                'options': [
                    {
                        'label': '动画',
                        'value': '1',
                    },
                    {
                        'label': '音乐',
                        'value': '3',
                    },
                    {
                        'label': '游戏',
                        'value': '4',
                    },
                    {
                        'label': '知识',
                        'value': '36',
                    },
                    {
                        'label': '科技',
                        'value': '230',
                    },
                    {
                        'label': '生活',
                        'value': '5',
                    },
                ],
                'default': '1',
                'required': True,
                'description': '选择视频所属的分区',
            },
            {
                'key': 'video_type',
                'label': '稿件类型',
                'type': 'select',
                'options': [
                    {
                        'label': '普通投稿',
                        'value': 'normal',
                    },
                    {
                        'label': '转载',
                        'value': 'reprint',
                    },
                ],
                'default': 'normal',
                'description': '选择稿件类型，转载需要注明来源',
            },
            {
                'key': 'synopsis',
                'label': '简介',
                'type': 'textarea',
                'placeholder': '输入视频简介，最多200字',
                'required': True,
                'max_length': 200,
                'description': '简介将显示在视频下方',
            },
            {
                'key': 'tags',
                'label': '标签',
                'type': 'autocomplete',
                'api': '/api/v1/platforms/bilibili/tags',
                'placeholder': '最多添加3个标签',
                'multiple': True,
                'max_items': 3,
                'required': True,
                'description': '标签有助于用户发现你的内容',
            },
        ],
    },
    'differences': {
        'proxy_required': False,
        'timeout_multiplier': 2.0,
        'retry_times': 5,
    },
}
