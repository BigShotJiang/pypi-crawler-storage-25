"""
百家号 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: baijiahao
"""

# 百家号 平台配置
PLATFORM_CONFIG = {
    'name': '百家号',
    'support_video': True,
    'support_image': False,
    'uploader_dir': 'baijiahao_uploader',
    'login_orchestrator_class': 'BaijiahaoLoginOrchestrator',
    'video_uploader_class': 'BaijiahaoVideoUploader',
    'publish_params_config': {
        'fields': [
            {
                'key': 'category',
                'label': '分类',
                'type': 'select',
                'required': True,
                'options': [],
                'default': '动漫',
                'description': '选择内容所属分类',
            },
        ],
    },
    'differences': {
        'proxy_required': False,
        'timeout_multiplier': 1.0,
        'retry_times': 3,
        'max_image_count': 60,
        'max_title_length': 30,
        'max_content_length': 200,
    },
}
