"""
示例平台 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: sample
"""

# 示例平台 平台配置
PLATFORM_CONFIG = {
    'name': '示例平台',
    'support_video': True,
    'support_image': True,
    'uploader_dir': 'sample_platform',
    'login_orchestrator_class': 'SampleLoginOrchestrator',
    'video_uploader_class': 'SampleVideoUploader',
    'image_uploader_class': 'SampleImageUploader',
    'publish_params_config': {
        'fields': [
            {
                'key': 'visibility',
                'label': '可见性',
                'type': 'select',
                'required': True,
                'options': [
                    {
                        'value': 'public',
                        'label': '公开',
                    },
                    {
                        'value': 'friends',
                        'label': '好友可见',
                    },
                    {
                        'value': 'private',
                        'label': '私密',
                    },
                ],
                'default': 'public',
            },
            {
                'key': 'allow_comment',
                'label': '允许评论',
                'type': 'select',
                'required': True,
                'options': [
                    {
                        'value': 'all',
                        'label': '所有人',
                    },
                    {
                        'value': 'friends',
                        'label': '仅好友',
                    },
                    {
                        'value': 'none',
                        'label': '禁止评论',
                    },
                ],
                'default': 'all',
            },
            {
                'key': 'tags',
                'label': '标签',
                'type': 'text',
                'required': False,
                'placeholder': '请输入标签，用逗号分隔',
                'maxlength': 200,
            },
        ],
    },
    'differences': {
        'proxy_required': False,
        'timeout_multiplier': 1.0,
        'retry_times': 3,
        'special_headers': {
            'User-Agent': 'SamplePlatform/1.0',
        },
    },
}
