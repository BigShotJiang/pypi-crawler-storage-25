"""
头条 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: toutiao
"""

# 头条 平台配置
PLATFORM_CONFIG = {
    'name': '头条',
    'support_video': True,
    'support_image': False,
    'uploader_dir': 'toutiao_uploader',
    'login_orchestrator_class': 'ToutiaoLoginOrchestrator',
    'video_uploader_class': 'ToutiaoVideoUploader',
    'image_uploader_class': None,
    'publish_params_config': {
        'fields': [
            {
                'key': 'title',
                'label': '标题',
                'type': 'text',
                'required': True,
                'placeholder': '请输入标题，1-30个字',
                'maxlength': 30,
                'description': '视频标题，最多30个字',
            },
            {
                'key': 'topic_tags',
                'label': '话题',
                'type': 'text',
                'placeholder': '请输入话题，最多添加10个',
                'required': False,
                'description': '添加话题有助于提升曝光',
            },
            {
                'key': 'video_desc',
                'label': '视频简介',
                'type': 'textarea',
                'placeholder': '请输入视频简介',
                'required': False,
                'maxlength': 400,
                'description': '视频简介，最多400字',
            },
            {
                'key': 'generate_article',
                'label': '生成图文',
                'type': 'toggle',
                'default': False,
                'description': '勾选后额外得图文创作收益',
            },
        ],
    },
    'differences': {
        'proxy_required': False,
        'timeout_multiplier': 1.0,
        'retry_times': 3,
        'login_type': 'qr_code',
        'max_title_length': 30,
        'max_content_length': 400,
        'video_formats': [
            'mp4',
            'mov',
            'avi',
        ],
        'max_video_size': '2GB',
        'cover_required': True,
        'hashtag_format': '#tag',
        'tags_separator': 'space',
        'supports_scheduled_publish': True,
    },
}
