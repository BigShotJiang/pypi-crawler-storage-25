"""
抖音 平台配置

从原 platform_codes.py 自动迁移生成
平台ID: douyin
"""

# 抖音 平台配置
PLATFORM_CONFIG = {'name': '抖音', 'support_video': True, 'support_image': True, 'uploader_dir': 'douyin_uploader', 'login_orchestrator_class': 'DouyinLoginOrchestrator', 'video_uploader_class': 'DouyinVideoUploader', 'image_uploader_class': 'DouyinImageUploader', 'publish_params_config': {'fields': [{'key': 'topic', 'label': '话题', 'type': 'text', 'placeholder': '输入话题，支持#话题格式，多个话题用空格分隔，如：#美食 #生活', 'required': True, 'description': '支持1-5个话题，话题有助于提升曝光', 'validation': {'pattern': '^((#[\\u4e00-\\u9fa5]+)+\\s*)+$', 'message': '请使用#话题格式，多个话题用空格分隔'}}, {'key': 'is_original', 'label': '原创声明', 'type': 'toggle', 'default': True, 'description': '声明作品为原创内容，获得原创标识'}, {'key': 'visibility', 'label': '作品可见性', 'type': 'select', 'options': [{'label': '公开', 'value': 'public'}, {'label': '仅粉丝可见', 'value': 'follows_only'}, {'label': '私密', 'value': 'private'}], 'default': 'public', 'description': '设置作品可见范围'}, {'key': 'allow_comment', 'label': '允许评论', 'type': 'toggle', 'default': True, 'description': '允许用户在作品下评论'}, {'key': 'allow_download', 'label': '允许下载', 'type': 'toggle', 'default': True, 'description': '允许用户下载视频'}]}, 'differences': {'proxy_required': False, 'timeout_multiplier': 1.0, 'retry_times': 3, 'login_type': 'qr_code_with_password', 'max_title_length': 30, 'max_content_length': 30, 'video_formats': ['mp4', 'mov', 'avi'], 'max_video_size': '2GB', 'cover_required': True, 'hashtag_format': '#tag', 'tags_separator': 'space', 'supports_scheduled_publish': False, 'requires_sms_verification': True}}