"""慧媒引擎CLI客户端 - 主入口"""

import typer
from rich.console import Console

from huimei_cli import __version__
from huimei_cli.commands import auth_cmd, account_cmd, publish_cmd

console = Console()

app = typer.Typer(
    name="huimei",
    help="慧媒引擎CLI - 本地自动化执行器",
    no_args_is_help=True,
)

# Register sub-commands
app.add_typer(auth_cmd.app, name="auth", help="登录/登出/状态")
app.add_typer(account_cmd.app, name="account", help="平台账号管理")
app.add_typer(publish_cmd.app, name="publish", help="内容发布")


# Top-level convenience commands
@app.command()
def login(
    username: str = typer.Option(..., prompt="用户名"),
    password: str = typer.Option(..., prompt="密码", hide_input=True),
    server: str = typer.Option(None, help="服务器地址"),
):
    """登录慧媒引擎账号 (快捷方式)"""
    from huimei_cli.auth import do_login, get_current_user
    with console.status("正在登录..."):
        ok = do_login(username, password, server)
    if ok:
        user = get_current_user()
        name = user.get("username", username) if user else username
        console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
    else:
        console.print("[red]✗[/red] 登录失败")
        raise typer.Exit(1)


@app.command()
def status():
    """查看当前状态 (快捷方式)"""
    auth_cmd.status()


@app.command()
def platforms():
    """列出支持的平台"""
    from huimei_cli.auth import is_logged_in
    from huimei_cli.config import get_config, get_server_url
    from huimei_cli.api_client import ApiClient, ApiError
    from rich.table import Table

    if not is_logged_in():
        console.print("[yellow]未登录[/yellow]，显示本地已知平台")

    # Show platforms from local registry
    table = Table(title="支持的平台")
    table.add_column("平台ID", style="cyan")
    table.add_column("名称")
    table.add_column("视频", justify="center")
    table.add_column("图文", justify="center")

    import importlib
    import os
    registry_dir = os.path.join(
        os.path.dirname(__file__), "platforms", "registry"
    )
    if os.path.isdir(registry_dir):
        for f in sorted(os.listdir(registry_dir)):
            if f.endswith(".py") and not f.startswith("_"):
                pid = f[:-3]
                try:
                    mod = importlib.import_module(
                        f"huimei_cli.platforms.registry.{pid}"
                    )
                    cfg = getattr(mod, "PLATFORM_CONFIG", {})
                    table.add_row(
                        pid,
                        cfg.get("name", pid),
                        "✅" if cfg.get("support_video") else "❌",
                        "✅" if cfg.get("support_image") else "❌",
                    )
                except Exception:
                    table.add_row(pid, "加载失败", "?", "?")
    else:
        console.print("[dim]本地平台注册表为空，需要从引擎同步[/dim]")

    console.print(table)


@app.command()
def version():
    """显示版本信息"""
    console.print(f"慧媒引擎CLI v{__version__}")


if __name__ == "__main__":
    app()
