"""Tests for huimei-cli core modules."""

import json
import os
import tempfile
import pytest


class TestConfig:
    """Test config.py module."""

    def test_get_config_creates_default(self, tmp_path, monkeypatch):
        """get_config should return defaults if no config file exists."""
        config_dir = tmp_path / ".huimei"
        monkeypatch.setattr("huimei_cli.config.CONFIG_DIR", config_dir)
        monkeypatch.setattr("huimei_cli.config.CONFIG_FILE", config_dir / "config.json")

        from huimei_cli.config import get_config
        cfg = get_config()
        assert "server_url" in cfg
        assert cfg["server_url"] == "http://localhost:5002"

    def test_save_and_load_config(self, tmp_path, monkeypatch):
        """save_config + get_config round-trip."""
        config_dir = tmp_path / ".huimei"
        monkeypatch.setattr("huimei_cli.config.CONFIG_DIR", config_dir)
        monkeypatch.setattr("huimei_cli.config.CONFIG_FILE", config_dir / "config.json")

        from huimei_cli.config import get_config, save_config
        cfg = get_config()
        cfg["token"] = "test-jwt-token"
        save_config(cfg)

        cfg2 = get_config()
        assert cfg2["token"] == "test-jwt-token"

    def test_get_device_id_stable(self, tmp_path, monkeypatch):
        """get_device_id should return same ID across calls."""
        config_dir = tmp_path / ".huimei"
        monkeypatch.setattr("huimei_cli.config.CONFIG_DIR", config_dir)
        monkeypatch.setattr("huimei_cli.config.CONFIG_FILE", config_dir / "config.json")

        from huimei_cli.config import get_device_id
        id1 = get_device_id()
        id2 = get_device_id()
        assert id1 == id2
        assert len(id1) == 36  # UUID format


class TestAuth:
    """Test auth.py module."""

    def test_get_current_user_no_token(self, tmp_path, monkeypatch):
        """get_current_user returns None when not logged in."""
        config_dir = tmp_path / ".huimei"
        monkeypatch.setattr("huimei_cli.config.CONFIG_DIR", config_dir)
        monkeypatch.setattr("huimei_cli.config.CONFIG_FILE", config_dir / "config.json")

        from huimei_cli.auth import get_current_user
        assert get_current_user() is None

    def test_get_current_user_with_token(self, tmp_path, monkeypatch):
        """get_current_user decodes JWT payload correctly."""
        import base64
        config_dir = tmp_path / ".huimei"
        monkeypatch.setattr("huimei_cli.config.CONFIG_DIR", config_dir)
        monkeypatch.setattr("huimei_cli.config.CONFIG_FILE", config_dir / "config.json")

        from huimei_cli.config import get_config, save_config
        from huimei_cli.auth import get_current_user

        # Create a fake JWT (header.payload.signature)
        payload = {"user_id": 1, "username": "testuser"}
        payload_b64 = base64.urlsafe_b64encode(
            json.dumps(payload).encode()
        ).rstrip(b"=").decode()
        fake_jwt = f"eyJhbGciOiJIUzI1NiJ9.{payload_b64}.fakesig"

        cfg = get_config()
        cfg["token"] = fake_jwt
        save_config(cfg)

        user = get_current_user()
        assert user is not None
        assert user["username"] == "testuser"

    def test_is_logged_in(self, tmp_path, monkeypatch):
        """is_logged_in returns correct state."""
        config_dir = tmp_path / ".huimei"
        monkeypatch.setattr("huimei_cli.config.CONFIG_DIR", config_dir)
        monkeypatch.setattr("huimei_cli.config.CONFIG_FILE", config_dir / "config.json")

        from huimei_cli.auth import is_logged_in
        from huimei_cli.config import get_config, save_config

        assert not is_logged_in()

        cfg = get_config()
        cfg["token"] = "some-token"
        save_config(cfg)
        assert is_logged_in()


class TestApiClient:
    """Test api_client.py module."""

    def test_create_client(self):
        """ApiClient can be instantiated."""
        from huimei_cli.api_client import ApiClient
        client = ApiClient("http://localhost:5002", "test-token")
        assert client.base_url == "http://localhost:5002"
        assert client.token == "test-token"

    def test_headers_with_token(self):
        """Headers should include Authorization when token is set."""
        from huimei_cli.api_client import ApiClient
        client = ApiClient("http://localhost:5002", "my-jwt")
        headers = client._headers()
        assert headers["Authorization"] == "Bearer my-jwt"

    def test_headers_without_token(self):
        """Headers should not include Authorization when token is None."""
        from huimei_cli.api_client import ApiClient
        client = ApiClient("http://localhost:5002")
        headers = client._headers()
        assert "Authorization" not in headers
