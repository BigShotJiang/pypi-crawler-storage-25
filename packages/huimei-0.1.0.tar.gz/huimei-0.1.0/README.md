# 慧媒引擎 CLI (huimei)

多平台社媒自动化发布工具 — 一个命令发布到抖音/快手/B站/小红书/微博等11个平台。

## 安装

### 方式1: pip (推荐)
```bash
pip install huimei
playwright install chromium
```

### 方式2: pipx (隔离环境)
```bash
pipx install huimei
playwright install chromium
```

### 方式3: 一键脚本
```bash
curl -fsSL https://raw.githubusercontent.com/huimei-engine/huimei-cli/main/install.sh | bash
```

## 快速开始

```bash
# 登录
huimei login

# 查看支持的平台
huimei platforms

# 查看已绑定账号
huimei account list

# 查看状态
huimei status
```

## AI Agent 集成 (MCP Server)

huimei 内置 MCP Server，可供 Claude Code / Hermes / OpenCode 等 AI Agent 直接调用：

### Claude Code 配置
```json
{
  "mcpServers": {
    "huimei": {
      "command": "huimei-mcp-server",
      "args": []
    }
  }
}
```

### Hermes Agent 配置
```yaml
mcp_servers:
  huimei:
    command: huimei-mcp-server
```

### 可用工具

| 工具 | 说明 |
|------|------|
| `huimei_login` | 登录账号 |
| `huimei_status` | 查看状态 |
| `huimei_logout` | 登出 |
| `huimei_platforms` | 列出支持平台 |
| `huimei_accounts` | 列出绑定账号 |
| `huimei_publish` | 创建发布任务 |

## 架构

```
CLI (本地) ──HTTP──► Java后端 (云端)
  │                    │
  ├─ Playwright        ├─ 账号管理
  ├─ Cookie本地存储    ├─ 任务调度
  └─ 住宅IP执行       └─ 订阅计费
```

CLI 是后端的远程执行器（手臂），所有业务决策由后端（大脑）做出。

## 开发

```bash
git clone <repo>
cd huimei-cli
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## License

MIT
