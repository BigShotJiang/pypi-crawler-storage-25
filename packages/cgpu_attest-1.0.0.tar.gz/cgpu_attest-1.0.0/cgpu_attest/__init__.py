"""
Confidential GPU Attestation Toolkit (cgpu-attest)
===================================================
Modular attestation framework for confidential GPUs.  Currently supports
NVIDIA Hopper (H100, H200) and Blackwell architectures, with AMD GPU
support planned.

Quick start
-----------
    from cgpu_attest import run_attestation

    results = run_attestation(mode="remote")
    for r in results:
        print(r.gpu_name, r.overall_status)
"""

from cgpu_attest.models import (
    AttestationEvidence,
    AttestationResult,
    GpuInfo,
)
from cgpu_attest.orchestrator import (
    attest_gpu,
    run_attestation,
)

__all__ = [
    "AttestationEvidence",
    "AttestationResult",
    "GpuInfo",
    "attest_gpu",
    "run_attestation",
]
