"""
High-level attestation orchestrator.

Enumerates GPUs, selects the right attestation mode, and produces a
unified list of :class:`AttestationResult` objects.
"""

from __future__ import annotations

import json
import logging
import secrets
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from cgpu_attest.constants import NVIDIA_NRAS_URL, NVIDIA_OCSP_URL
from cgpu_attest.deps import SDK_AVAILABLE
from cgpu_attest.gpu_discovery import enumerate_gpus, init_nvml, shutdown_nvml
from cgpu_attest.models import AttestationResult, GpuInfo

log = logging.getLogger("cgpu.orchestrator")


def generate_nonce(length: int = 32) -> str:
    """Return a cryptographically random hex nonce."""
    return secrets.token_hex(length)


def _utcnow_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def attest_gpu(
    gpu: GpuInfo,
    nonce: str,
    mode: str = "remote",
    nras_url: str = NVIDIA_NRAS_URL,
    ocsp_url: str = NVIDIA_OCSP_URL,
    proxies: dict[str, str] | None = None,
) -> AttestationResult:
    """
    Orchestrate the full attestation workflow for a single GPU.

    Tries the SDK path first; falls back to NVML + REST when the SDK is
    not installed.

    Parameters
    ----------
    gpu     : Target GPU info.
    nonce   : Fresh random nonce (hex string).
    mode    : ``"remote"`` (submit to NRAS) or ``"local"`` (OCSP-only).
    """
    # ── SDK path (preferred) ─────────────────────────────────────────
    if SDK_AVAILABLE:
        try:
            if mode == "local":
                from cgpu_attest.attest_local import attest_local
                return attest_local(gpu, nonce, ocsp_url=ocsp_url)
            else:
                from cgpu_attest.attest_remote import attest_remote_sdk
                return attest_remote_sdk(
                    gpu, nonce,
                    nras_url=nras_url, ocsp_url=ocsp_url, proxies=proxies,
                )
        except Exception as exc:
            msg = f"SDK attestation failed: {exc}"
            log.error(msg)
            return AttestationResult(
                gpu_uuid=gpu.uuid,
                gpu_name=gpu.name,
                overall_status="ERROR",
                errors=[msg],
                verified_at=_utcnow_iso(),
            )

    # ── NVML fallback path (no SDK) ──────────────────────────────────
    if mode == "local":
        msg = (
            "Local attestation requires nv-attestation-sdk. "
            "Run: pip install nv-attestation-sdk"
        )
        log.error(msg)
        return AttestationResult(
            gpu_uuid=gpu.uuid,
            gpu_name=gpu.name,
            overall_status="ERROR",
            errors=[msg],
            verified_at=_utcnow_iso(),
        )

    log.warning("nv-attestation-sdk not found — using NVML fallback path")
    from cgpu_attest.attest_remote import attest_remote_nvml_fallback
    try:
        return attest_remote_nvml_fallback(
            gpu, nonce, nras_url=nras_url, proxies=proxies,
        )
    except Exception as exc:
        msg = f"NVML fallback attestation failed: {exc}"
        log.error(msg)
        return AttestationResult(
            gpu_uuid=gpu.uuid,
            gpu_name=gpu.name,
            overall_status="ERROR",
            errors=[msg],
            verified_at=_utcnow_iso(),
        )


def run_attestation(
    mode: str = "remote",
    nras_url: str = NVIDIA_NRAS_URL,
    ocsp_url: str = NVIDIA_OCSP_URL,
    gpu_family: str | None = None,
    output_path: str | None = None,
    proxies: dict[str, str] | None = None,
) -> list[AttestationResult]:
    """
    Enumerate GPUs, optionally filter by family, then attest each one.

    Parameters
    ----------
    gpu_family : If given (e.g. ``"H200"``), only attest GPUs whose
                 detected family matches.  Pass ``None`` to attest all.
    output_path : If given, write JSON results to this file.
    """
    init_nvml()
    try:
        gpus = enumerate_gpus()

        if gpu_family:
            family_upper = gpu_family.upper()
            targets = [g for g in gpus if (g.family or "").upper() == family_upper]
            if not targets:
                log.warning(
                    "No %s GPUs detected (found: %s). "
                    "Omit --gpu-family to attest all GPUs.",
                    gpu_family,
                    ", ".join(g.name for g in gpus) or "none",
                )
            gpus = targets

        if not gpus:
            return []

        results: list[AttestationResult] = []
        for gpu in gpus:
            nonce = generate_nonce()
            log.info(
                "═══ Attesting GPU %d: %s [%s] (nonce=%s…) ═══",
                gpu.index, gpu.name, gpu.family or "unknown", nonce[:8],
            )
            result = attest_gpu(
                gpu, nonce=nonce, mode=mode,
                nras_url=nras_url, ocsp_url=ocsp_url, proxies=proxies,
            )
            results.append(result)

            icon = "✅" if result.overall_status == "PASS" else "❌"
            log.info(
                "%s GPU %s (%s): %s",
                icon, gpu.index, gpu.name, result.overall_status,
            )

        if output_path:
            out = Path(output_path)
            report = {
                "tool_version": "2.0",
                "mode": mode,
                "timestamp": _utcnow_iso(),
                "results": [asdict(r) for r in results],
            }
            out.write_text(
                json.dumps(report, indent=2), encoding="utf-8",
            )
            log.info("Results written to %s", out)

        return results

    finally:
        shutdown_nvml()
