"""
GPU family profiles.

Each module in this package calls :func:`register_gpu_profile` to
register one GPU family.  Adding support for a new GPU is as simple as
creating a new module here.

All modules are imported automatically when this package is loaded.
"""

from cgpu_attest.gpu_profiles import h100, h200, blackwell  # noqa: F401
