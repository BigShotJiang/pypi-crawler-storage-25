"""H100 (Hopper) GPU profile."""

from cgpu_attest.constants import register_gpu_profile

register_gpu_profile(
    "H100",
    name_patterns=["H100"],
    pci_subsystem_ids=frozenset({
        0x2322,   # H100 SXM5 80GB
        0x2324,   # H100 PCIe 80GB
        0x2331,   # H100 NVL 94GB
    }),
    architecture="HOPPER",
)
