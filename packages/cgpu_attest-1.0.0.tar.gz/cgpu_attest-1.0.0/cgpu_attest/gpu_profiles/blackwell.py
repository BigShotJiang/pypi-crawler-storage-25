"""Blackwell GPU profiles (B100, B200, GB200)."""

from cgpu_attest.constants import register_gpu_profile

register_gpu_profile(
    "B200",
    name_patterns=["B200"],
    pci_subsystem_ids=frozenset(),   # populate when PCI IDs are known
    architecture="BLACKWELL",
)

register_gpu_profile(
    "B100",
    name_patterns=["B100"],
    pci_subsystem_ids=frozenset(),
    architecture="BLACKWELL",
)

register_gpu_profile(
    "GB200",
    name_patterns=["GB200"],
    pci_subsystem_ids=frozenset(),
    architecture="BLACKWELL",
)
