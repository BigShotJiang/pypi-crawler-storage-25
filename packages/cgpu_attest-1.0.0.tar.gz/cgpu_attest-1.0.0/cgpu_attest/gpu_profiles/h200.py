"""H200 (Hopper) GPU profile."""

from cgpu_attest.constants import register_gpu_profile

register_gpu_profile(
    "H200",
    name_patterns=["H200"],
    pci_subsystem_ids=frozenset({
        0x233,    # H200 SXM5
        0x2330,   # H200 NVL
    }),
    architecture="HOPPER",
)
