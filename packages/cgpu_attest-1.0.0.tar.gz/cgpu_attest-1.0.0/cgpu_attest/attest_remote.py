"""
Remote attestation paths.

Two strategies, tried in order:

1. **SDK REMOTE mode** — the SDK collects evidence, submits to NRAS,
   and returns a JWT in one shot.
2. **NVML fallback + REST** — evidence is collected via NVML, then
   POSTed to NRAS manually.
"""

from __future__ import annotations

import base64
import logging
import time
from typing import Any

import requests

from cgpu_attest.constants import NVIDIA_NRAS_URL, derive_status
from cgpu_attest.deps import attestation, require_sdk
from cgpu_attest.jwt_helpers import decode_sdk_token_list, decode_token
from cgpu_attest.models import AttestationEvidence, AttestationResult, GpuInfo

log = logging.getLogger("cgpu.remote")


# ---------------------------------------------------------------------------
# SDK REMOTE mode
# ---------------------------------------------------------------------------

def attest_remote_sdk(
    gpu: GpuInfo,
    nonce: str,
    nras_url: str = NVIDIA_NRAS_URL,
    ocsp_url: str = "",
    proxies: dict[str, str] | None = None,
) -> AttestationResult:
    """
    Full remote attestation using the NVIDIA Attestation SDK.

    The SDK collects evidence, submits to NRAS, and returns a JWT — all
    in one pipeline.

    Key lessons learned
    -------------------
    - REMOTE environment → ``get_evidence()`` returns serialisable dicts.
    - Pass ``""`` (empty string) as the device-ID argument, not
      ``gpu.uuid``.
    - Set nonce via ``client.set_nonce()`` **before** ``get_evidence()``.
    """
    require_sdk()

    client = attestation.Attestation()
    client.set_name("gpu-attestation-tool")
    client.set_nonce(nonce)

    client.add_verifier(
        attestation.Devices.GPU,
        attestation.Environment.REMOTE,
        nras_url,
        "",          # empty = all GPUs; SDK enumerates them
    )

    log.info("[GPU %s] Collecting evidence via SDK (REMOTE) …", gpu.uuid)
    evidence_list = client.get_evidence()

    if not evidence_list:
        raise RuntimeError("SDK get_evidence() returned empty list")

    log.info("[GPU %s] Attesting via NRAS %s …", gpu.uuid, nras_url)
    attest_result = client.attest(evidence_list)

    status = "PASS" if attest_result else "FAIL"
    token  = ""
    claims: dict[str, Any] = {}

    try:
        raw_token = client.get_token()
        token, claims = decode_sdk_token_list(raw_token)
        if not token:
            log.warning(
                "No valid JWT in get_token() response — status from SDK: %s",
                attest_result,
            )
        else:
            derived = derive_status(claims)
            if derived is not None:
                status = derived
    except AttributeError:
        log.debug("client.get_token() not available on this SDK version")

    return AttestationResult(
        gpu_uuid=gpu.uuid,
        gpu_name=gpu.name,
        overall_status=status,
        claims=claims,
        token=token,
        errors=[],
        verified_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


# ---------------------------------------------------------------------------
# NVML fallback: manual NRAS REST call
# ---------------------------------------------------------------------------

def submit_evidence_to_nras(
    evidence: AttestationEvidence,
    nras_url: str = NVIDIA_NRAS_URL,
    timeout: int = 30,
    proxies: dict[str, str] | None = None,
) -> dict[str, Any]:
    """
    POST evidence to the NVIDIA Remote Attestation Service (NRAS) and
    return the parsed JSON response.
    """
    if not evidence.attestation_report:
        raise RuntimeError(
            "Attestation report is empty — cannot submit to NRAS. "
            "Ensure the GPU is in CC mode and the driver supports "
            "nvmlDeviceGetConfComputeGpuAttestationReport()."
        )

    ev_entry: dict[str, Any] = {"evidence": evidence.attestation_report}
    if evidence.certificate_chain:
        pem_blob = "".join(evidence.certificate_chain).encode()
        ev_entry["certificate"] = base64.b64encode(pem_blob).decode()

    payload = {
        "nonce": evidence.nonce,
        "evidence_list": [ev_entry],
    }

    log.info("[GPU %s] Submitting evidence to NRAS …", evidence.gpu_uuid)

    try:
        resp = requests.post(
            nras_url,
            json=payload,
            timeout=timeout,
            proxies=proxies or {},
            headers={"Content-Type": "application/json"},
        )
        resp.raise_for_status()
        return resp.json()
    except requests.Timeout:
        raise RuntimeError(f"NRAS request timed out after {timeout}s")
    except requests.HTTPError as exc:
        body = exc.response.text if exc.response is not None else ""
        raise RuntimeError(
            f"NRAS returned HTTP {exc.response.status_code}: {body}"
        ) from exc


def attest_remote_nvml_fallback(
    gpu: GpuInfo,
    nonce: str,
    nras_url: str = NVIDIA_NRAS_URL,
    proxies: dict[str, str] | None = None,
) -> AttestationResult:
    """
    Collect evidence via NVML and submit directly to NRAS (no SDK).
    """
    from cgpu_attest.evidence import collect_evidence

    evidence = collect_evidence(gpu, nonce)

    errors: list[str] = []
    claims: dict[str, Any] = {}
    token  = ""
    status = "FAIL"

    try:
        response = submit_evidence_to_nras(
            evidence, nras_url=nras_url, proxies=proxies,
        )
        token  = response.get("token", "")
        status = (
            "PASS"
            if response.get("overall_claim_list", {})
               .get("attestation-result", "")
               .upper() == "TRUE"
            else "FAIL"
        )
        if token:
            claims  = decode_token(token)
            derived = derive_status(claims)
            if derived is not None:
                status = derived
    except Exception as exc:
        msg = str(exc)
        log.error("Remote attestation error: %s", msg)
        errors.append(msg)
        status = "ERROR"

    return AttestationResult(
        gpu_uuid=gpu.uuid,
        gpu_name=gpu.name,
        overall_status=status,
        claims=claims,
        token=token,
        errors=errors,
        verified_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )
