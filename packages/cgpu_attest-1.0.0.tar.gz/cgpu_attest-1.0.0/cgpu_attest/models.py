"""
Data models shared across the attestation toolkit.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class GpuInfo:
    """Information about a single GPU discovered via NVML."""

    index: int
    uuid: str
    name: str
    serial: str
    pci_bus_id: str
    driver_version: str
    vbios_version: str
    family: str | None = None          # matched profile key ("H200", …)
    cc_mode: str = "unknown"           # confidential-computing mode
    cc_dev_mode: bool = False
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class AttestationEvidence:
    """Raw evidence collected from a single GPU."""

    gpu_uuid: str
    nonce: str
    certificate_chain: list[str] = field(default_factory=list)
    rim_certificates: list[str] = field(default_factory=list)
    measurements: dict[str, str] = field(default_factory=dict)
    attestation_report: str = ""       # base64-encoded opaque blob
    timestamp: str = ""


@dataclass
class AttestationResult:
    """Outcome of attesting a single GPU."""

    gpu_uuid: str
    gpu_name: str
    overall_status: str                # "PASS" | "FAIL" | "ERROR"
    claims: dict[str, Any] = field(default_factory=dict)
    token: str = ""                    # JWT returned by NRAS
    errors: list[str] = field(default_factory=list)
    verified_at: str = ""
