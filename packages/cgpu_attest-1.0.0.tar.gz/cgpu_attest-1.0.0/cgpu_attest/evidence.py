"""
Evidence collection from confidential GPUs.

Two collection strategies:

1. **SDK path** — uses the ``nv-attestation-sdk`` when available.
2. **NVML fallback** — pulls raw attestation report and certificate
   directly via pynvml.  Works on driver ≥ 525 with CC mode enabled.
"""

from __future__ import annotations

import base64
import ctypes
import logging
import time
from typing import Any

from cgpu_attest.deps import SDK_AVAILABLE, pynvml, require_nvml
from cgpu_attest.models import AttestationEvidence, GpuInfo

log = logging.getLogger("cgpu.evidence")


def collect_evidence(gpu: GpuInfo, nonce: str) -> AttestationEvidence:
    """
    Collect attestation evidence from *gpu*.

    Uses the NVIDIA Attestation SDK when available, otherwise falls back
    to a direct NVML approach.
    """
    timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    if SDK_AVAILABLE:
        return _collect_evidence_sdk(gpu, nonce, timestamp)

    log.warning(
        "nv-attestation-sdk not found — collecting partial evidence via NVML"
    )
    return _collect_evidence_nvml(gpu, nonce, timestamp)


# ---------------------------------------------------------------------------
# SDK path (stub — the real work happens inside attest_remote / attest_local
# which call client.get_evidence() directly)
# ---------------------------------------------------------------------------

def _collect_evidence_sdk(
    gpu: GpuInfo, nonce: str, timestamp: str
) -> AttestationEvidence:
    """SDK-based evidence collection (placeholder for future expansion)."""
    # The SDK's client.get_evidence() is called in the attestation
    # functions themselves because the evidence objects are opaque SDK
    # types that feed directly into client.attest().
    # This function exists so that collect_evidence() has a uniform
    # interface and can be extended for SDK-level evidence extraction
    # in future.
    return _collect_evidence_nvml(gpu, nonce, timestamp)


# ---------------------------------------------------------------------------
# NVML fallback
# ---------------------------------------------------------------------------

def _collect_evidence_nvml(
    gpu: GpuInfo, nonce: str, timestamp: str,
) -> AttestationEvidence:
    """
    Pull raw attestation report and certificate directly from NVML.

    Only works on driver ≥ 525 with Confidential Computing mode enabled.
    """
    require_nvml()
    h = pynvml.nvmlDeviceGetHandleByIndex(gpu.index)

    cert_chain: list[str] = []
    report_blob = ""

    try:
        cert = pynvml.nvmlDeviceGetConfComputeGpuCertificate(h)
        cert_size = getattr(
            cert, "attestationCertChainSize", len(cert.attestationCertChain),
        )
        cert_pem = bytes(
            cert.attestationCertChain[:cert_size]
        ).decode("utf-8", errors="replace")
        cert_chain = [cert_pem]
        log.debug("Retrieved certificate chain (%d bytes)", cert_size)
    except (pynvml.NVMLError, AttributeError) as exc:
        log.warning("Could not retrieve GPU certificate: %s", exc)

    try:
        nonce_bytes = bytes.fromhex(nonce)[:32].ljust(32, b"\x00")
        c_nonce     = (ctypes.c_uint8 * 32)(*nonce_bytes)
        report      = pynvml.nvmlDeviceGetConfComputeGpuAttestationReport(
            h, c_nonce,
        )
        report_blob = base64.b64encode(
            bytes(report.attestationReport[: report.attestationReportSize])
        ).decode()
    except (pynvml.NVMLError, AttributeError) as exc:
        log.warning("Could not retrieve GPU attestation report: %s", exc)

    return AttestationEvidence(
        gpu_uuid=gpu.uuid,
        nonce=nonce,
        certificate_chain=cert_chain,
        rim_certificates=[],
        measurements={},
        attestation_report=report_blob,
        timestamp=timestamp,
    )
