"""Allow running the package directly: python -m cgpu_attest."""

import sys

from cgpu_attest.cli import main

sys.exit(main())
