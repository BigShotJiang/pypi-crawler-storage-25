"""
GPU enumeration via NVML.

Discovers all GPUs visible to the driver, reads basic metadata, and
matches each device against the registered GPU profiles.
"""

from __future__ import annotations

import logging
from typing import Any

from cgpu_attest.constants import match_gpu_family
from cgpu_attest.deps import NVML_AVAILABLE, pynvml, require_nvml
from cgpu_attest.models import GpuInfo

log = logging.getLogger("cgpu.nvml")


# ---------------------------------------------------------------------------
# NVML lifecycle
# ---------------------------------------------------------------------------

def init_nvml() -> None:
    """Initialise the NVML library."""
    require_nvml()
    pynvml.nvmlInit()
    log.debug("NVML initialised – driver %s", pynvml.nvmlSystemGetDriverVersion())


def shutdown_nvml() -> None:
    """Shut down the NVML library (safe to call even if never initialised)."""
    if NVML_AVAILABLE:
        try:
            pynvml.nvmlShutdown()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_str(handle: Any, fn: Any, *args: Any, default: str = "N/A") -> str:
    """Call an NVML getter and return *default* on NVMLError."""
    try:
        return fn(handle, *args)
    except pynvml.NVMLError:
        return default


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def enumerate_gpus() -> list[GpuInfo]:
    """Return a :class:`GpuInfo` record for every GPU visible to NVML."""
    require_nvml()
    count = pynvml.nvmlDeviceGetCount()
    log.info("Found %d GPU(s) via NVML", count)
    gpus: list[GpuInfo] = []

    for idx in range(count):
        h = pynvml.nvmlDeviceGetHandleByIndex(idx)

        name   = _get_str(h, pynvml.nvmlDeviceGetName)
        uuid   = _get_str(h, pynvml.nvmlDeviceGetUUID)
        serial = _get_str(h, pynvml.nvmlDeviceGetSerial)

        try:
            pci    = pynvml.nvmlDeviceGetPciInfo(h)
            bus_id = pci.busId.decode() if isinstance(pci.busId, bytes) else pci.busId
        except pynvml.NVMLError:
            bus_id = "N/A"

        driver_ver = _get_str(h, lambda _h, *a: pynvml.nvmlSystemGetDriverVersion())
        vbios_ver  = _get_str(h, pynvml.nvmlDeviceGetVbiosVersion)

        # Confidential Computing mode (requires driver 525+)
        cc_mode = "unknown"
        cc_dev  = False
        try:
            cc_state = pynvml.nvmlDeviceGetConfComputeGpuCertificate(h)
            cc_mode  = "enabled"
            _ = cc_state  # noqa: F841
        except (pynvml.NVMLError, AttributeError):
            pass

        family = match_gpu_family(name)

        info = GpuInfo(
            index=idx,
            uuid=uuid,
            name=name,
            serial=serial,
            pci_bus_id=bus_id,
            driver_version=driver_ver,
            vbios_version=vbios_ver,
            family=family,
            cc_mode=cc_mode,
            cc_dev_mode=cc_dev,
            raw={},
        )
        gpus.append(info)
        log.info(
            "[GPU %d] %s  uuid=%s  cc=%s  family=%s",
            idx, name, uuid, cc_mode, family or "unknown",
        )

    return gpus
