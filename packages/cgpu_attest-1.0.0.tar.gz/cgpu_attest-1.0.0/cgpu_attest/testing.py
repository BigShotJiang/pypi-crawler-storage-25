"""
Testing and development utilities.

.. warning::

    This module is intended for **local testing and development only**.
    It monkey-patches SDK internals to redirect RIM fetches to a local
    directory and suppresses RIM signature verification.  **Never use
    these patches in production** — they weaken the attestation trust
    chain.

Equivalent to the C++ CLI flags::

    --rim-store=dir  --rim-dir=<dir>  --no-verify-rim-signatures

Usage (CLI)::

    python -m cgpu_attest --test-rim-dir ./local_rims

Usage (programmatic)::

    from cgpu_attest.testing import patch_local_rim_dir
    patch_local_rim_dir(Path("./local_rims"))
"""

from __future__ import annotations

import importlib
import io
import logging
import re
import urllib.request as _urllib_req
from pathlib import Path
from typing import Any

log = logging.getLogger("cgpu.testing")

_TEST_BANNER = """
╔══════════════════════════════════════════════════════════════╗
║  ⚠  TEST MODE — LOCAL RIM DIRECTORY ACTIVE                 ║
║                                                              ║
║  RIM files are being served from disk and RIM signature      ║
║  verification is DISABLED.  Results from this mode do NOT    ║
║  provide the same assurance as production attestation.        ║
║                                                              ║
║  For production use, omit --test-rim-dir so that RIM files   ║
║  are fetched from the NVIDIA Remote Attestation Service.     ║
╚══════════════════════════════════════════════════════════════╝
""".strip()


def patch_local_rim_dir(rim_dir: Path) -> None:
    """
    Redirect all verifier RIM fetches to a local directory of XML files
    and disable RIM signature verification.

    **This is a testing/development utility.**  In production, RIM files
    should be fetched from the NVIDIA RIM service (the default
    behaviour).

    Parameters
    ----------
    rim_dir : Path to a directory containing RIM XML files named using
              NVIDIA's canonical convention, e.g.::

                  NV_GPU_VBIOS_1010_0230_894_9600B70002.xml
                  NV_GPU_DRIVER_GH100_570.172.08.xml
    """
    log.warning(_TEST_BANNER)

    RIM_ID_RE = re.compile(r"/rim/([^/?# ]+?)(?:[.]xml)?$")

    def _read_local(rim_id: str) -> str | None:
        for candidate in (rim_dir / f"{rim_id}.xml", rim_dir / rim_id):
            if candidate.is_file():
                content = candidate.read_text(encoding="utf-8")
                log.info(
                    "[TEST-RIM] Serving %s from %s", rim_id, candidate.name,
                )
                return content
        log.debug(
            "[TEST-RIM] %s not found in %s — will try NVIDIA",
            rim_id, rim_dir,
        )
        return None

    # ── Layer 1: patch CcAdminUtils.fetch_rim_file ───────────────────
    try:
        utils = importlib.import_module("verifier.cc_admin_utils")
        raw   = utils.CcAdminUtils.__dict__["fetch_rim_file"]
        orig  = raw.__func__ if isinstance(raw, staticmethod) else raw

        def _patched_fetch(url: str, *args: Any, **kwargs: Any) -> str:
            m = RIM_ID_RE.search(str(url))
            if m:
                content = _read_local(m.group(1))
                if content is not None:
                    return content
            return orig(url, *args, **kwargs)

        utils.CcAdminUtils.fetch_rim_file = staticmethod(_patched_fetch)
        log.info(
            "[TEST-RIM] Patched CcAdminUtils.fetch_rim_file → %s", rim_dir,
        )
    except Exception as exc:
        log.warning("[TEST-RIM] Could not patch fetch_rim_file: %s", exc)

    # ── Layer 2: patch urllib.request.urlopen (fallback) ─────────────
    _orig_urlopen = _urllib_req.urlopen

    def _patched_urlopen(req_or_url: Any, *args: Any, **kwargs: Any) -> Any:
        import json as _json
        import base64 as _b64

        url = (
            req_or_url
            if isinstance(req_or_url, str)
            else getattr(req_or_url, "full_url", str(req_or_url))
        )
        m = RIM_ID_RE.search(str(url))
        if m:
            content = _read_local(m.group(1))
            if content is not None:
                envelope = _json.dumps(
                    {"rim": _b64.b64encode(content.encode("utf-8")).decode()}
                ).encode("utf-8")
                buf = io.BytesIO(envelope)
                buf.status  = 200       # type: ignore[attr-defined]
                buf.headers = {}        # type: ignore[attr-defined]
                buf.getcode = lambda: 200  # type: ignore[attr-defined]
                buf.info    = lambda: {}   # type: ignore[attr-defined]
                return buf
        return _orig_urlopen(req_or_url, *args, **kwargs)

    _urllib_req.urlopen = _patched_urlopen  # type: ignore[assignment]
    log.info(
        "[TEST-RIM] Patched urllib.request.urlopen → %s "
        "(JSON: {rim: base64(xml)})",
        rim_dir,
    )

    # ── Disable RIM signature verification ───────────────────────────
    _sig_patched = False

    # Primary: verifier.rim.RIM.verify_signature
    try:
        rim_mod = importlib.import_module("verifier.rim")
        for attr_name in dir(rim_mod):
            cls = getattr(rim_mod, attr_name, None)
            if not isinstance(cls, type):
                continue
            if not hasattr(cls, "verify_signature"):
                continue
            if attr_name == "XMLVerifier" or "signxml" in getattr(
                cls, "__module__", ""
            ):
                continue

            orig_vsig = cls.verify_signature

            def _make_wrap(
                orig_fn: Any = orig_vsig, cname: str = attr_name,
            ):
                def _wrapped(self: Any, *a: Any, **kw: Any) -> bool:
                    try:
                        return orig_fn(self, *a, **kw)
                    except Exception as exc:
                        msg = str(exc).lower()
                        if any(
                            k in msg
                            for k in (
                                "digest", "signature", "invalid",
                                "signatureverification", "rimsignature",
                            )
                        ):
                            log.info(
                                "[TEST-RIM] Suppressing sig error (%s): %s",
                                cname, type(exc).__name__,
                            )
                            for mname in dir(self):
                                if (
                                    "mark" in mname
                                    and "signature" in mname
                                    and callable(getattr(self, mname, None))
                                ):
                                    try:
                                        getattr(self, mname)(True)
                                    except Exception:
                                        pass
                            return True
                        raise
                return _wrapped

            cls.verify_signature = _make_wrap()
            log.info(
                "[TEST-RIM] Patched verifier.rim.%s.verify_signature "
                "→ wrap+suppress",
                attr_name,
            )
            _sig_patched = True
    except Exception as exc:
        log.debug("[TEST-RIM] verifier.rim patch attempt: %s", exc)

    # Secondary: higher-level helpers in cc_admin_utils / cc_admin
    for mod_path, class_name in [
        ("verifier.cc_admin_utils", "CcAdminUtils"),
        ("verifier.cc_admin",       "CcAdmin"),
    ]:
        for method_name in [
            "verify_vbios_rim_cert_and_signature",
            "verify_driver_rim_cert_and_signature",
            "verify_rim_certificate_and_signature",
            "verify_rim_signature",
            "verify_vbios_rim_signature",
            "verify_driver_rim_signature",
        ]:
            try:
                mod = importlib.import_module(mod_path)
                cls = getattr(mod, class_name, None)
                if cls is None or not hasattr(cls, method_name):
                    continue
                raw_m     = cls.__dict__.get(method_name)
                is_static = isinstance(raw_m, staticmethod)

                def _make_passthrough(
                    name: str = method_name, static: bool = is_static,
                ):
                    def _passthrough(*a: Any, **kw: Any) -> bool:
                        log.info(
                            "[TEST-RIM] Skipping higher-level sig check: %s",
                            name,
                        )
                        return True
                    return (
                        staticmethod(_passthrough) if static else _passthrough
                    )

                setattr(cls, method_name, _make_passthrough())
                log.info(
                    "[TEST-RIM] Patched %s.%s → skip",
                    class_name, method_name,
                )
                _sig_patched = True
            except Exception:
                continue

    if not _sig_patched:
        log.warning(
            "[TEST-RIM] Could not patch any RIM signature methods — "
            "attestation will likely fail at the signature verification "
            "step."
        )

    # ── Patch mark_gpu_*_rim_signature_verified setters ──────────────
    _mark_patched = False
    mark_methods_to_force = [
        "mark_gpu_driver_rim_signature_verified",
        "mark_gpu_vbios_rim_signature_verified",
    ]
    for mod_path in [
        "verifier.nvml",
        "verifier.nvml.nvml_handler",
        "verifier.config",
        "verifier.cc_admin",
        "verifier.cc_admin_utils",
        "verifier.attestation",
    ]:
        try:
            mod = importlib.import_module(mod_path)
        except ImportError:
            continue
        for attr_name in dir(mod):
            cls = getattr(mod, attr_name, None)
            if not isinstance(cls, type):
                continue
            for method_name in mark_methods_to_force:
                if not hasattr(cls, method_name):
                    continue
                if getattr(
                    getattr(cls, method_name, None),
                    "_rim_dir_patched", False,
                ):
                    continue

                orig_mark = getattr(cls, method_name)

                def _make_force_true(
                    orig_fn: Any = orig_mark,
                    mname: str = method_name,
                    cname: str = attr_name,
                ):
                    def _forced(self: Any, value: bool = True) -> Any:
                        if not value:
                            log.info(
                                "[TEST-RIM] Overriding %s.%s(False) → True",
                                cname, mname,
                            )
                        try:
                            return orig_fn(self, True)
                        except TypeError:
                            return orig_fn(self)
                    _forced._rim_dir_patched = True  # type: ignore[attr-defined]
                    return _forced

                setattr(cls, method_name, _make_force_true())
                log.info(
                    "[TEST-RIM] Patched %s.%s → always True",
                    attr_name, method_name,
                )
                _mark_patched = True

    if not _mark_patched:
        log.warning(
            "[TEST-RIM] Could not patch mark_gpu_*_rim_signature_verified "
            "methods — the SDK may still report FAIL due to internal "
            "signature flags."
        )

    # ── Summary ──────────────────────────────────────────────────────
    xml_files = sorted(rim_dir.glob("*.xml"))
    if xml_files:
        log.info("[TEST-RIM] Local RIM files available (%d):", len(xml_files))
        for f in xml_files:
            log.info("[TEST-RIM]   %s", f.name)
    else:
        log.warning("[TEST-RIM] No .xml files found in %s", rim_dir)
