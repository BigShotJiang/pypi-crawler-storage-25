"""
Shared constants, NVIDIA service URLs, and GPU profile registry.
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# NVIDIA service endpoints
# ---------------------------------------------------------------------------
NVIDIA_OCSP_URL = "https://ocsp.ndis.nvidia.com"
NVIDIA_RIM_URL  = "https://rim.attestation.nvidia.com/v1/rim"
NVIDIA_NRAS_URL = "https://nras.attestation.nvidia.com/v3/attest/gpu"

ATTESTATION_REPORT_VERSION = "1.0"

# ---------------------------------------------------------------------------
# Canonical claim keys / pass values used across the toolkit
# ---------------------------------------------------------------------------
ATT_RESULT_KEYS: tuple[str, ...] = (
    "x-nvidia-overall-att-result",
    "x-nvidia-attestation-result",
    "attestation-result",
)

PASS_VALUES: frozenset[str] = frozenset({"TRUE", "PASS", "SUCCESS"})


def derive_status(claims: dict[str, Any]) -> str | None:
    """
    Extract the attestation pass/fail status from a claims dict.

    Returns ``"PASS"``, ``"FAIL"``, or ``None`` if no recognised key is
    present.
    """
    for key in ATT_RESULT_KEYS:
        val = claims.get(key)
        if val is not None and val != "":
            return "PASS" if str(val).upper() in PASS_VALUES else "FAIL"
    return None


# ---------------------------------------------------------------------------
# GPU profile registry
# ---------------------------------------------------------------------------
# Each profile describes one GPU family so the tool can match detected
# hardware to the right set of PCI subsystem IDs, architecture tag, and
# any family-specific behaviour.  New GPUs (H100, Blackwell, …) only
# need to add an entry here.

_GPU_PROFILES: dict[str, dict[str, Any]] = {}


def register_gpu_profile(
    family: str,
    *,
    name_patterns: list[str],
    pci_subsystem_ids: frozenset[int] | None = None,
    architecture: str = "",
) -> None:
    """
    Register a GPU family profile.

    Parameters
    ----------
    family            : Short identifier (e.g. ``"H200"``, ``"H100"``).
    name_patterns     : Substrings matched case-insensitively against
                        ``nvmlDeviceGetName()`` (e.g. ``["H200"]``).
    pci_subsystem_ids : Optional set of known PCI subsystem IDs.
    architecture      : Architecture tag (``"HOPPER"``, ``"BLACKWELL"``,
                        …).  Used in NRAS payloads when the server does
                        not auto-detect.
    """
    _GPU_PROFILES[family.upper()] = {
        "name_patterns": [p.upper() for p in name_patterns],
        "pci_subsystem_ids": pci_subsystem_ids or frozenset(),
        "architecture": architecture,
    }


def get_gpu_profiles() -> dict[str, dict[str, Any]]:
    """Return a *copy* of the profile registry."""
    return dict(_GPU_PROFILES)


def match_gpu_family(gpu_name: str) -> str | None:
    """
    Return the family key (e.g. ``"H200"``) if *gpu_name* matches any
    registered profile, otherwise ``None``.
    """
    upper = gpu_name.upper()
    for family, profile in _GPU_PROFILES.items():
        for pattern in profile["name_patterns"]:
            if pattern in upper:
                return family
    return None
