"""
Lazy-import helpers for optional heavy dependencies.

Each dependency is probed once at import time so the rest of the toolkit
can do a cheap boolean check instead of repeated try/except blocks.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# pynvml
# ---------------------------------------------------------------------------
try:
    import pynvml  # noqa: F401

    NVML_AVAILABLE = True
except ImportError:
    pynvml = None  # type: ignore[assignment]
    NVML_AVAILABLE = False

# ---------------------------------------------------------------------------
# NVIDIA Attestation SDK
# ---------------------------------------------------------------------------
try:
    from nv_attestation_sdk import attestation  # type: ignore  # noqa: F401

    SDK_AVAILABLE = True
except ImportError:
    attestation = None  # type: ignore[assignment]
    SDK_AVAILABLE = False

# ---------------------------------------------------------------------------
# PyJWT
# ---------------------------------------------------------------------------
try:
    import jwt  # noqa: F401

    JWT_AVAILABLE = True
except ImportError:
    jwt = None  # type: ignore[assignment]
    JWT_AVAILABLE = False


# ---------------------------------------------------------------------------
# Convenience require_* guards
# ---------------------------------------------------------------------------
def require_nvml() -> None:
    """Raise ``RuntimeError`` if pynvml is not installed."""
    if not NVML_AVAILABLE:
        raise RuntimeError("pynvml is not installed. Run: pip install pynvml")


def require_sdk() -> None:
    """Raise ``RuntimeError`` if nv-attestation-sdk is not installed."""
    if not SDK_AVAILABLE:
        raise RuntimeError(
            "nv-attestation-sdk is not installed. "
            "Run: pip install nv-attestation-sdk"
        )
