"""
JWT helpers for NVIDIA attestation tokens.

Handles decoding NRAS JWTs, extracting claims, surfacing embedded error
details, and parsing the nested token structures returned by the NVIDIA
Attestation SDK.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from cgpu_attest.deps import JWT_AVAILABLE, jwt

log = logging.getLogger("cgpu.jwt")

# Algorithms the NRAS / SDK may use to sign tokens
_SUPPORTED_ALGS = [
    "RS256", "RS384", "RS512",
    "ES256", "ES384", "ES512",
    "HS256",
]


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def is_jwt(token: str) -> bool:
    """Return ``True`` if *token* looks like a JWT (three base64 segments)."""
    if not isinstance(token, str):
        return False
    parts = token.split(".")
    return len(parts) == 3 and all(len(p) > 0 for p in parts)


def decode_token(token: str) -> dict[str, Any]:
    """
    Decode an NRAS JWT **without** signature verification and return the
    claims dict.

    Surfaces embedded ``x-nvidia-error-details`` at WARNING level and
    logs the overall attestation result at INFO level.

    Raises
    ------
    RuntimeError
        If PyJWT is missing or the token cannot be decoded.
    """
    if not JWT_AVAILABLE:
        log.warning("PyJWT not installed — skipping token decode")
        return {}

    try:
        claims = jwt.decode(
            token,
            options={"verify_signature": False},
            algorithms=_SUPPORTED_ALGS,
        )

        # Surface embedded NRAS error details
        err = claims.get("x-nvidia-error-details")
        if err:
            log.warning(
                "NRAS error: [%s] %s — %s",
                err.get("message", ""),
                err.get("httpStatus", ""),
                err.get("description", ""),
            )

        overall = claims.get("x-nvidia-overall-att-result")
        if overall is not None:
            log.info("Overall attestation result from NRAS: %s", overall)

        log.debug(
            "Full token claims: %s",
            json.dumps(claims, indent=2, default=str),
        )
        return claims
    except Exception as exc:
        raise RuntimeError(f"JWT decode failed: {exc}") from exc


def decode_sdk_token_list(raw_token: Any) -> tuple[str, dict[str, Any]]:
    """
    Parse the nested structure returned by ``client.get_token()`` in
    REMOTE mode::

        [["JWT", "<sdk-jwt>"],
         {"REMOTE_GPU_CLAIMS": [["JWT", "<nras-jwt>"], {...}]}]

    Returns ``(best_jwt_string, merged_claims_dict)``.
    """
    if not raw_token:
        return "", {}

    jwt_strings: list[str] = []
    all_claims: dict[str, Any] = {}

    def _extract(obj: Any) -> None:
        """Recursively find all JWT strings in the nested SDK structure."""
        if isinstance(obj, str) and obj.count(".") == 2 and len(obj) > 20:
            jwt_strings.append(obj)
        elif isinstance(obj, list):
            it = iter(obj)
            for item in it:
                if item == "JWT":
                    try:
                        candidate = next(it)
                        if isinstance(candidate, str) and candidate.count(".") == 2:
                            jwt_strings.append(candidate)
                    except StopIteration:
                        pass
                else:
                    _extract(item)
        elif isinstance(obj, dict):
            for v in obj.values():
                _extract(v)

    _extract(raw_token)
    log.debug("decode_sdk_token_list: found %d JWT candidate(s)", len(jwt_strings))

    # Prefer the NRAS platform token (carries "x-nvidia-" claims)
    nras_token = ""
    for t in jwt_strings:
        try:
            if not JWT_AVAILABLE:
                continue
            c = jwt.decode(
                t,
                options={"verify_signature": False},
                algorithms=_SUPPORTED_ALGS,
            )
            log.debug("JWT claims keys: %s", list(c.keys())[:6])
            if any(k.startswith("x-nvidia-") for k in c):
                nras_token = t
                all_claims.update(c)
                err = c.get("x-nvidia-error-details")
                if err:
                    log.warning(
                        "NRAS error: [%s] %s — %s",
                        err.get("message", ""),
                        err.get("httpStatus", ""),
                        err.get("description", ""),
                    )
        except Exception as exc:
            log.debug("JWT decode attempt failed: %s", exc)

    if not nras_token and jwt_strings:
        log.debug("No x-nvidia- claims found; using last JWT as fallback")
        nras_token = jwt_strings[-1]

    return nras_token, all_claims
