"""
Command-line interface for the Confidential GPU Attestation Toolkit.

Usage::

    # Attest all GPUs, remote mode (default):
    cgpu-attest

    # Attest only H200 GPUs, local mode:
    cgpu-attest --gpu-family H200 --mode local

    # Save results:
    cgpu-attest --output results.json

    # [TESTING ONLY] Use local RIM files:
    cgpu-attest --test-rim-dir ./local_rims
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from cgpu_attest.constants import (
    NVIDIA_NRAS_URL,
    NVIDIA_OCSP_URL,
    get_gpu_profiles,
)
from cgpu_attest.deps import NVML_AVAILABLE

# Trigger profile auto-registration
import cgpu_attest.gpu_profiles  # noqa: F401

log = logging.getLogger("cgpu")


def build_parser() -> argparse.ArgumentParser:
    profiles = sorted(get_gpu_profiles().keys())
    profile_help = ", ".join(profiles) if profiles else "(none registered)"

    p = argparse.ArgumentParser(
        description="Attest Confidential GPUs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
Registered GPU profiles: {profile_help}

Examples:
  # Attest all GPUs via NVIDIA Remote Attestation Service (default):
  python -m cgpu_attest

  # Attest only H200 GPUs, local mode (RIMs fetched from NVIDIA):
  python -m cgpu_attest --gpu-family H200 --mode local

  # Save results to JSON:
  python -m cgpu_attest --output results.json

  # [TESTING] Use local RIM files (skips RIM signature verification):
  python -m cgpu_attest --test-rim-dir ./local_rims

  # Route through an HTTP proxy:
  python -m cgpu_attest --http-proxy http://proxy.corp:3128
        """,
    )
    p.add_argument(
        "--mode",
        choices=["remote", "local"],
        default="remote",
        help="Attestation mode: 'remote' sends evidence to NRAS; "
             "'local' verifies via SDK using OCSP + NVIDIA RIM service "
             "(default: remote)",
    )
    p.add_argument(
        "--gpu-family",
        metavar="FAMILY",
        default=None,
        help=f"Only attest GPUs of this family ({profile_help}). "
             "Omit to attest all GPUs.",
    )
    p.add_argument(
        "--nras-url",
        default=NVIDIA_NRAS_URL,
        help=f"NVIDIA Remote Attestation Service URL (default: {NVIDIA_NRAS_URL})",
    )
    p.add_argument(
        "--ocsp-url",
        default=NVIDIA_OCSP_URL,
        help=f"NVIDIA OCSP URL for certificate validation "
             f"(default: {NVIDIA_OCSP_URL})",
    )
    p.add_argument(
        "--output",
        metavar="FILE",
        help="Write attestation results as JSON to FILE",
    )
    p.add_argument(
        "--http-proxy",
        metavar="URL",
        help="HTTP/HTTPS proxy for outbound requests "
             "(e.g. http://proxy:3128)",
    )

    # ── Testing-only options ─────────────────────────────────────────
    test_group = p.add_argument_group(
        "testing / development",
        "These options are for local testing only and weaken the "
        "attestation trust chain.  Do NOT use in production.",
    )
    test_group.add_argument(
        "--test-rim-dir",
        metavar="DIR",
        default=None,
        help=(
            "[TEST ONLY] Directory containing local RIM XML files.  "
            "Implies --mode local.  RIM signature verification is "
            "DISABLED.  In production, omit this flag so RIM files "
            "are fetched from the NVIDIA RIM service."
        ),
    )

    p.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable DEBUG logging",
    )
    return p


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s – %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    parser = build_parser()
    args   = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    proxies: dict[str, str] | None = None
    if args.http_proxy:
        proxies = {"http": args.http_proxy, "https": args.http_proxy}

    # Pre-flight checks
    if not NVML_AVAILABLE:
        log.error("pynvml is required. Run: pip install pynvml")
        return 2

    # ── Test-only: local RIM directory ───────────────────────────────
    if args.test_rim_dir:
        rim_dir = Path(args.test_rim_dir).expanduser().resolve()
        if not rim_dir.is_dir():
            log.error("--test-rim-dir %s is not a directory", rim_dir)
            return 2

        if args.mode != "local":
            log.warning(
                "--test-rim-dir only works with --mode local. "
                "Switching to local mode."
            )
            args.mode = "local"

        from cgpu_attest.testing import patch_local_rim_dir
        patch_local_rim_dir(rim_dir)

    # ── Run attestation ──────────────────────────────────────────────
    from cgpu_attest.orchestrator import run_attestation

    results = run_attestation(
        mode=args.mode,
        nras_url=args.nras_url,
        ocsp_url=args.ocsp_url,
        gpu_family=args.gpu_family,
        output_path=args.output,
        proxies=proxies,
    )

    if not results:
        log.warning("No GPUs were attested.")
        return 1

    # ── Print summary table ──────────────────────────────────────────
    print("\n" + "═" * 60)
    print("  ATTESTATION SUMMARY")
    print("═" * 60)
    all_pass = True
    for r in results:
        icon = "✅ PASS" if r.overall_status == "PASS" else "❌ FAIL"
        print(f"  {r.gpu_name:<30s}  {r.gpu_uuid}  {icon}")
        if r.errors:
            for err in r.errors:
                print(f"    ⚠  {err}")
        if r.overall_status != "PASS":
            all_pass = False
    print("═" * 60 + "\n")

    return 0 if all_pass else 1


if __name__ == "__main__":
    sys.exit(main())
