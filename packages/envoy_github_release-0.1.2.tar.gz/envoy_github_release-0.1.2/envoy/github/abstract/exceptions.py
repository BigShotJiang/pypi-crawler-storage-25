

class GithubReleaseError(Exception):
    pass
