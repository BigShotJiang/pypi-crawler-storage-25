"""One-command installer for Neruva auto-record + MCP into Claude Code.

Usage:

    neruva-record-install                          # interactive, all defaults
    neruva-record-install --api-key nv_... --namespace research-bot --ttl 7
    neruva-record-install --yes                    # non-interactive, env-var defaults
    neruva-record-install --no-mcp                 # only wire hooks, skip MCP add
    neruva-record-install --uninstall              # remove hooks + MCP entry

What it does:

1. Edits ``~/.claude/settings.json`` -- merges our 10 hook entries
   without clobbering any existing user hooks. Backs up first.
2. Runs ``claude mcp add neruva`` to register the MCP server (so the
   agent can also call mcp__neruva__* tools directly). Skips if the
   ``claude`` CLI isn't on PATH, or if --no-mcp is passed.

Restart Claude Code after running.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
from typing import Any, Optional


CLAUDE_CONFIG_PATH = pathlib.Path.home() / ".claude" / "settings.json"
NERUVA_HOOK_CMD = "neruva-record-hook"

# The set of events we wire. Each value matches Claude Code's
# settings.json hook block shape. async=true is critical -- it makes the
# hook fire-and-forget so it never slows down Claude Code's own loop.
_HOOK_EVENTS_NO_MATCHER = (
    "UserPromptSubmit",
    "Stop",
    "SessionStart",
    "SessionEnd",
    "SubagentStart",
    "SubagentStop",
    "TaskCreated",
    "TaskCompleted",
)
_HOOK_EVENTS_WITH_MATCHER = (
    "PostToolUse",
    "PostToolUseFailure",
)


def _hook_block(with_matcher: bool) -> dict[str, Any]:
    """One hook entry: command=neruva-record-hook, async=true."""
    inner = {
        "hooks": [
            {"type": "command", "command": NERUVA_HOOK_CMD, "async": True}
        ]
    }
    if with_matcher:
        inner["matcher"] = "*"
    return inner


def _is_neruva_entry(entry: dict[str, Any]) -> bool:
    """True if this hook entry already points at our recorder."""
    if not isinstance(entry, dict):
        return False
    for h in entry.get("hooks", []) or []:
        if isinstance(h, dict) and h.get("command") == NERUVA_HOOK_CMD:
            return True
    return False


def _merge_hooks(
    existing_hooks: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    """Merge our hook entries into an existing ``hooks`` dict.

    Returns ``(updated_hooks, events_added_or_updated)``. Existing user
    hooks for the same events are preserved; we just append our entry
    if it's not already there.
    """
    out = dict(existing_hooks) if existing_hooks else {}
    events_touched: list[str] = []
    for evt in _HOOK_EVENTS_NO_MATCHER:
        cur = out.get(evt) or []
        if any(_is_neruva_entry(e) for e in cur):
            continue
        out[evt] = list(cur) + [_hook_block(with_matcher=False)]
        events_touched.append(evt)
    for evt in _HOOK_EVENTS_WITH_MATCHER:
        cur = out.get(evt) or []
        if any(_is_neruva_entry(e) for e in cur):
            continue
        out[evt] = list(cur) + [_hook_block(with_matcher=True)]
        events_touched.append(evt)
    return out, events_touched


def _strip_neruva_hooks(
    existing_hooks: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    """Remove our hook entries from the hooks dict (uninstall)."""
    out: dict[str, Any] = {}
    events_touched: list[str] = []
    for evt, entries in (existing_hooks or {}).items():
        if not isinstance(entries, list):
            out[evt] = entries
            continue
        kept = [e for e in entries if not _is_neruva_entry(e)]
        if len(kept) != len(entries):
            events_touched.append(evt)
        # If nothing left, drop the event entirely (cleaner config)
        if kept:
            out[evt] = kept
    return out, events_touched


def _read_settings(path: pathlib.Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"  WARNING: could not parse {path}: {e}", file=sys.stderr)
        print("  Refusing to overwrite. Fix or delete the file and re-run.", file=sys.stderr)
        sys.exit(1)


def _backup(path: pathlib.Path) -> Optional[pathlib.Path]:
    if not path.exists():
        return None
    ts = time.strftime("%Y%m%d-%H%M%S")
    bak = path.with_suffix(path.suffix + f".bak.{ts}")
    shutil.copy2(path, bak)
    return bak


def _write_settings(path: pathlib.Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)


def _prompt(question: str, default: str = "", *, yes: bool) -> str:
    if yes:
        return default
    suffix = f" [{default}]" if default else ""
    try:
        ans = input(f"  {question}{suffix}: ").strip()
    except EOFError:
        return default
    return ans or default


_MCP_PIN = "@neruva/mcp@0.6.1"


def _find_claude_cli() -> Optional[str]:
    """Return the full path to the ``claude`` CLI, or None.

    Cross-platform: ``shutil.which`` handles PATHEXT on Windows so it
    finds ``claude.cmd`` / ``claude.exe`` correctly.
    """
    return shutil.which("claude")


def _claude_cli_available() -> bool:
    """True if the ``claude`` CLI looks usable."""
    path = _find_claude_cli()
    if not path:
        return False
    try:
        r = subprocess.run(
            [path, "--version"],
            capture_output=True, timeout=5, text=True,
        )
        return r.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False


def _register_mcp(
    api_key: str,
    auto_record: str,
    pin: str = _MCP_PIN,
) -> tuple[bool, str]:
    """Register the Neruva MCP with Claude Code via ``claude mcp add``.

    Returns ``(ok, message)``. Idempotent: removes any existing
    'neruva' entry first so re-runs always produce a clean config.
    """
    cli = _find_claude_cli()
    if not cli:
        return False, "claude CLI not found on PATH (skip)"
    # Remove any existing entry, ignore failure
    try:
        subprocess.run(
            [cli, "mcp", "remove", "neruva"],
            capture_output=True, timeout=10, text=True,
        )
    except Exception:
        pass
    cmd = [
        cli, "mcp", "add", "neruva",
        "--env", f"NERUVA_API_KEY={api_key}",
        "--env", f"NERUVA_AUTO_RECORD={auto_record}",
        "--", "npx", "-y", pin,
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=30, text=True)
    except Exception as e:
        return False, f"claude mcp add failed: {e}"
    if r.returncode != 0:
        msg = (r.stderr or r.stdout or "").strip().splitlines()[-1] if (r.stderr or r.stdout) else "unknown"
        return False, f"claude mcp add returned {r.returncode}: {msg}"
    return True, f"registered neruva MCP -> {pin}"


def _unregister_mcp() -> tuple[bool, str]:
    cli = _find_claude_cli()
    if not cli:
        return False, "claude CLI not found on PATH (skip)"
    try:
        r = subprocess.run(
            [cli, "mcp", "remove", "neruva"],
            capture_output=True, timeout=10, text=True,
        )
    except Exception as e:
        return False, f"claude mcp remove failed: {e}"
    if r.returncode != 0:
        # already absent is fine
        return True, "neruva MCP not registered (nothing to remove)"
    return True, "removed neruva MCP entry"


def install(
    api_key: Optional[str] = None,
    namespace: str = "main",
    index: str = "brain",
    ttl_days: int = 30,
    config_path: Optional[pathlib.Path] = None,
    yes: bool = False,
    install_mcp: bool = True,
) -> int:
    path = config_path or CLAUDE_CONFIG_PATH
    print(f"Neruva auto-record installer for Claude Code")
    print(f"  config file: {path}")
    print()

    # Resolve API key
    api_key = api_key or os.environ.get("NERUVA_API_KEY") or ""
    if not api_key:
        api_key = _prompt(
            "NERUVA_API_KEY (get one at https://app.neruva.io)",
            default="", yes=yes,
        )
    if not api_key:
        print("  ERROR: no API key. Set NERUVA_API_KEY or pass --api-key.",
              file=sys.stderr)
        return 1

    namespace = _prompt("namespace (one per agent)", default=namespace, yes=yes)
    ttl_in = _prompt(
        "TTL days (auto-expire records older than N days; 0 = forever)",
        default=str(ttl_days), yes=yes,
    )
    try:
        ttl_int = int(ttl_in)
    except ValueError:
        ttl_int = ttl_days
    auto_record_value = (
        f"{namespace}:{ttl_int}" if ttl_int > 0 else namespace
    )

    settings = _read_settings(path)
    env = dict(settings.get("env") or {})
    env["NERUVA_API_KEY"] = api_key
    env["NERUVA_AUTO_RECORD"] = auto_record_value
    env.setdefault("NERUVA_AUTO_RECALL", "20")  # auto-inject 20 recent records on SessionStart

    new_hooks, touched = _merge_hooks(settings.get("hooks") or {})

    new_settings = dict(settings)
    new_settings["env"] = env
    new_settings["hooks"] = new_hooks

    bak = _backup(path)
    _write_settings(path, new_settings)

    print()
    print(f"  Wrote config to: {path}")
    if bak:
        print(f"  Backup at:       {bak}")
    print(f"  env.NERUVA_API_KEY:    set ({len(api_key)} chars)")
    print(f"  env.NERUVA_AUTO_RECORD: {auto_record_value}")
    print(f"  env.NERUVA_AUTO_RECALL: {env['NERUVA_AUTO_RECALL']}  (records auto-injected on session start)")
    print(f"  secrets redaction:     ON  (set NERUVA_REDACT=off to disable; trusted environments only)")
    if touched:
        print(f"  Hooks added:  {', '.join(touched)}")
    else:
        print("  Hooks already present (no changes).")

    # Register the MCP so the agent can also call mcp__neruva__* tools.
    if install_mcp:
        ok, msg = _register_mcp(api_key=api_key, auto_record=auto_record_value)
        prefix = "  MCP registered:" if ok else "  MCP setup:     "
        print(f"{prefix} {msg}")
        if not ok:
            print("    (You can re-run with --no-mcp to suppress this, or install")
            print("     the Claude Code CLI from https://docs.claude.com/claude-code .)")

    print()
    print("  Next steps:")
    print("    1. Restart Claude Code (full quit + relaunch).")
    print("    2. Try a prompt and a tool call.")
    print(f"    3. Query records_query(namespace='{namespace}', text='...')")
    print("       to recall captured events.")
    print()
    print("  To uninstall later: neruva-record-install --uninstall")
    return 0


def uninstall(
    config_path: Optional[pathlib.Path] = None,
    uninstall_mcp: bool = True,
) -> int:
    path = config_path or CLAUDE_CONFIG_PATH
    if not path.exists():
        print(f"  no config at {path}; nothing to uninstall.")
        # Still try to remove the MCP entry
        if uninstall_mcp:
            ok, msg = _unregister_mcp()
            print(f"  MCP cleanup:    {msg}")
        return 0
    settings = _read_settings(path)
    new_hooks, touched = _strip_neruva_hooks(settings.get("hooks") or {})
    new_settings = dict(settings)
    if new_hooks:
        new_settings["hooks"] = new_hooks
    elif "hooks" in new_settings:
        del new_settings["hooks"]
    # Leave env vars alone -- user may use them elsewhere.

    bak = _backup(path)
    _write_settings(path, new_settings)
    print(f"  Removed Neruva hook entries from {touched if touched else '(none found)'}.")
    print(f"  Backup at: {bak}")
    print(f"  env vars (NERUVA_API_KEY, NERUVA_AUTO_RECORD) left in place.")
    if uninstall_mcp:
        ok, msg = _unregister_mcp()
        print(f"  MCP cleanup:    {msg}")
    print(f"  Restart Claude Code.")
    return 0


def main() -> int:
    p = argparse.ArgumentParser(
        prog="neruva-record-install",
        description="Install / uninstall Neruva auto-record hooks for Claude Code.",
    )
    p.add_argument("--api-key", help="NERUVA_API_KEY (else reads env)")
    p.add_argument("--namespace", default="main",
                   help="records namespace (default: main)")
    p.add_argument("--index", default="brain",
                   help=argparse.SUPPRESS)  # accepted for backwards compat; ignored
    p.add_argument("--ttl", type=int, default=30,
                   help="TTL days, 0 = forever (default: 30)")
    p.add_argument("--config", type=pathlib.Path, default=None,
                   help="path to settings.json (default: ~/.claude/settings.json)")
    p.add_argument("-y", "--yes", action="store_true",
                   help="non-interactive: take all defaults")
    p.add_argument("--no-mcp", action="store_true",
                   help="skip the `claude mcp add neruva` step (only wire hooks)")
    p.add_argument("--uninstall", action="store_true",
                   help="remove the hook entries + MCP entry (env vars preserved)")
    args = p.parse_args()

    if args.uninstall:
        return uninstall(config_path=args.config, uninstall_mcp=not args.no_mcp)
    return install(
        api_key=args.api_key,
        namespace=args.namespace,
        index=args.index,
        ttl_days=args.ttl,
        config_path=args.config,
        yes=args.yes,
        install_mcp=not args.no_mcp,
    )


if __name__ == "__main__":
    raise SystemExit(main())
