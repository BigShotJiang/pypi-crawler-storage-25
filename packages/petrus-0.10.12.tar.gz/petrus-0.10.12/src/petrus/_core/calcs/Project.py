import os
import string
import sys
from functools import cached_property
from typing import *

from identityfunction import identityfunction

from petrus._core import utils
from petrus._core.calcs.CacheCalc import CacheCalc
from petrus._core.consts.Const import Const

__all__ = ["Project"]


class _empty:
    pass


class Project(CacheCalc):

    authors: Any
    classifiers: Any
    dependencies: Any
    description: Any
    keywords: Any
    license: Any
    license_files: Any
    name: Any
    readme: Any
    requires_python: Any
    urls: Any
    version: Any

    def __post_init__(self: Self) -> None:
        self._version = _empty

    @cached_property
    def authors(self: Self) -> Any:
        ans: Any
        author: dict
        used: Any
        fit: Any
        i: Any
        ans = self.get("authors", default=[])
        if type(ans) is not list:
            return ans
        ans = list(ans)
        author = dict()
        if self.prog.kwargs["author"]:
            author["name"] = self.prog.kwargs["author"]
        if self.prog.kwargs["email"]:
            author["email"] = self.prog.kwargs["email"]
        author = self.prog.easy_dict(author)
        used = False
        for i in range(len(ans)):
            try:
                ans[i] = dict(ans[i])
            except Exception:
                continue
            fit = utils.dict_match(ans[i], author)
            if fit and not used:
                ans[i].update(author)
            ans[i] = self.prog.easy_dict(ans[i])
            used |= fit
        if not used:
            ans.insert(0, author)
        return ans

    @cached_property
    def classifiers(self: Self) -> Any:
        preset_gotten: Any
        kwarg: Any
        ans: Any
        prefix: Any
        cleaned: Any
        x: Any
        status: Any
        preset_gotten = self.get("classifiers", default=[])
        if type(preset_gotten) is not list:
            return preset_gotten
        kwarg = self.prog.kwargs["classifiers"]
        if kwarg == "":
            return list(sorted(set(preset_gotten)))
        ans = kwarg
        ans = ans.format(preset=", ".join(preset_gotten))
        ans = ans.split(",")
        ans = self.format_classifiers(ans)
        if self.prog.development_status == "":
            return list(sorted(set(ans)))
        prefix = "Development Status :: "
        cleaned = list()
        for x in ans:
            if x.lower().startswith(prefix.lower()):
                continue
            cleaned.append(x)
        ans = cleaned
        status = prefix + self.prog.development_status
        ans.append(status)
        return list(sorted(set(self.format_classifiers(ans))))

    @cached_property
    def dependencies(self: Self) -> Any:
        x: Any
        x = self.get("dependencies", default=[])
        if type(x) is not list:
            return x
        return list(sorted(set(map(utils.fix_dependency, x))))

    @cached_property
    def description(self: Self) -> Any:
        if self.prog.kwargs["description"]:
            return self.prog.kwargs["description"]
        if self.get("description") is not None:
            return self.get("description")
        return self.name

    @cached_property
    def keywords(self: Self) -> Any:
        return self.get("keywords", default=[])

    @cached_property
    def license(self: Self) -> Any:
        files: Any
        info: Any
        files = self.prog.pp.get("project", "license-files")
        info = self.prog.pp.get("project", "license")
        if files is not None:
            return info
        if info is None:
            return "MIT"
        if type(info) is not dict:
            return info
        if tuple(info.keys()) != ("file",):
            return info
        return "MIT"

    @cached_property
    def license_files(self: Self) -> Any:
        files: Any
        info: Any
        files = self.prog.pp.get("project", "license-files")
        info = self.prog.pp.get("project", "license")
        if files is not None:
            return files
        if info is None:
            return [self.prog.file.license]
        if type(info) is not dict:
            return
        if tuple(info.keys()) != ("file",):
            return
        return [self.prog.file.license]

    @classmethod
    def format_classifiers(cls: type, value: Iterable, /) -> list:
        ans: list
        x: int
        ans = list(value)
        for x in range(len(ans)):
            ans[x] = ans[x].replace("::", " :: ")
            ans[x] = " ".join(ans[x].split())
            ans[x] = ans[x].strip()
        ans = list(filter(identityfunction, ans))
        return ans

    def get(self: Self, *args: Any, default: Any = None) -> Any:
        return self.prog.pp.get("project", *args, default=default)

    @cached_property
    def name(self: Self) -> str:
        basename: Any
        raw: str
        ans: Any
        x: str
        basename = os.path.basename(os.getcwd())
        raw = str(self.get("name") or basename)
        ans = ""
        for x in raw:
            if x in (string.ascii_letters + string.digits):
                ans += x
            else:
                ans += "_"
        return ans

    @property
    def readme(self: Self) -> Any:
        return self.prog.file.readme

    @cached_property
    def requires_python(self: Self) -> Any:
        kwarg: Any
        preset: Any
        current: Any
        kwarg = self.prog.kwargs["requires_python"]
        preset = self.get("requires-python", default="")
        current = ">={0}.{1}.{2}".format(*sys.version_info)
        if kwarg == "":
            return preset
        kwarg = kwarg.format(preset=preset, current=current)
        kwarg = kwarg.split("\\|")
        kwarg = list(map(str.strip, kwarg))
        kwarg = next(filter(identityfunction, kwarg), None)
        return kwarg

    def todict(self: Self) -> Any:
        ans: Any
        x: Any
        y: Any
        ans = self.get(default={})
        for x in Const.const.data["CONST"]["PROJECT-KEYS"]:
            y = getattr(self, x)
            if y is None:
                continue
            x = x.replace("_", "-")
            ans[x] = y
        ans = self.prog.easy_dict(ans)
        return ans

    @cached_property
    def urls(self: Self) -> Any:
        ans: Any
        p: str
        ans = self.get("urls")
        if ans is None:
            ans = dict()
        if type(ans) is not dict:
            return ans
        if self.prog.github:
            ans.setdefault("Source", self.prog.github)
        p = f"https://pypi.org/project/{self.name}/"
        ans.setdefault("Index", p)
        p = f"https://pypi.org/project/{self.name}/#files"
        ans.setdefault("Download", p)
        ans = self.prog.easy_dict(ans)
        return ans

    @property
    def version(self: Self) -> Any:
        if self._version is _empty:
            self._version = self.prog.version_formatted
        return self._version
