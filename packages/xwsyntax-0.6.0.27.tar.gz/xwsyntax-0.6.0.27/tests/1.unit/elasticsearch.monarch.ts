// elasticsearch.monarch.ts
// Auto-generated Monaco language definition
export const elasticsearchLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".elasticsearch",
  "operators": [
    "\n\n// Aggregation\naggregation_query: ",
    "\n\n// Bool query\nbool_query: ",
    "\n\n// Exists query\nexists_query: ",
    "\n\n// Nested query\nnested_query: ",
    "\n\n// Range query\nrange_query: ",
    "\n\n// Terminals\nIDENTIFIER: /[a-zA-Z_][a-zA-Z0-9_]*/\nSTRING: /",
    "\n\n// Wildcard query\nwildcard_query: ",
    "\n\nNULL: ",
    "\n\nagg_definition: STRING ",
    "\n\nagg_param: STRING ",
    "\n\nagg_params: ",
    "\n\nagg_type: ",
    "\n\nbool_clauses: bool_clause (",
    "\n\nfield_match: STRING ",
    "\n\nfield_value: STRING ",
    "\n\nfuzzy_options: fuzzy_option (",
    "\n\nmatch_options: match_option (",
    "\n\nmatch_query: ",
    "\n\nmulti_match_params: ",
    "\n\nquery_string_options: query_string_option (",
    "\n\nrange_condition: range_op ",
    "\n           | query\n\n// Multi-match query\nmulti_match_query: ",
    "\n        | ",
    " (",
    " (STRING | NUMBER)\n            | ",
    " (STRING | match_params)\n\nmatch_params: ",
    " NUMBER\n\n// Prefix query\nprefix_query: ",
    " NUMBER\n\nquery_array: ",
    " NUMBER\n            | ",
    " STRING\n\n// Fuzzy query\nfuzzy_query: ",
    " STRING\n\n// Term queries\nterm_query: ",
    " STRING\n                   | ",
    " STRING ",
    " STRING (",
    " STRING [",
    " STRING)* ",
    " [",
    " agg_definition (",
    " agg_definition)* ",
    " agg_param (",
    " agg_param)* ",
    " agg_params ",
    " agg_type ",
    " bool_clause)*\n\nbool_clause: ",
    " bool_clauses ",
    " field_match ",
    " field_value ",
    " fuzzy_option)*\n\nfuzzy_option: ",
    " fuzzy_options] ",
    " match_option)*\n\nmatch_option: ",
    " match_options]\n\n// Query string\nquery_string_query: ",
    " match_options] ",
    " multi_match_params ",
    " query ",
    " query (",
    " query)* ",
    " query_array\n           | ",
    " query_string_option)*\n\nquery_string_option: ",
    " query_string_options] ",
    " range_condition (",
    " range_condition)* ",
    " value\n\n// Values\nvalue: STRING | NUMBER | BOOLEAN_LITERAL | NULL\n\nBOOLEAN_LITERAL: ",
    " value\n\nrange_op: ",
    " value\n\nterms_query: ",
    " value (",
    " value)* ",
    " | ",
    ")\n                   | ",
    ")\n            | ",
    "AND\\",
    "OR\\",
    "\\",
    "]*",
    "aggs\\",
    "analyzer\\",
    "and\\",
    "avg\\",
    "bool\\",
    "cardinality\\",
    "date_histogram\\",
    "default_field\\",
    "default_operator\\",
    "exists\\",
    "field\\",
    "fields\\",
    "filter\\",
    "fuzziness\\",
    "fuzzy\\",
    "gt\\",
    "gte\\",
    "histogram\\",
    "lt\\",
    "lte\\",
    "match\\",
    "max\\",
    "min\\",
    "minimum_should_match\\",
    "multi_match\\",
    "must\\",
    "must_not\\",
    "nested\\",
    "operator\\",
    "or\\",
    "path\\",
    "prefix\\",
    "prefix_length\\",
    "query\\",
    "query_string\\",
    "range\\",
    "should\\",
    "stats\\",
    "sum\\",
    "term\\",
    "terms\\",
    "value\\",
    "wildcard\\",
    "{"
  ],
  "symbols": "\\ NUMBER\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\{|must_not\\\\|\\ value\\\n\\\nrange_op:\\ |match\\\\|\\\n\\\nquery_string_options:\\ query_string_option\\ \\(|value\\\\|\\\n\\\nfield_match:\\ STRING\\ |\\ agg_param\\ \\(|\\\n\\\n//\\ Aggregation\\\naggregation_query:\\ |\\ \\(STRING\\ \\|\\ match_params\\)\\\n\\\nmatch_params:\\ |\\ \\(|\\\n\\\nmatch_options:\\ match_option\\ \\(|AND\\\\|\\ query_string_option\\)\\*\\\n\\\nquery_string_option:\\ |\\ NUMBER\\\n\\\n//\\ Prefix\\ query\\\nprefix_query:\\ |fuzzy\\\\|\\ STRING\\ \\(|\\ range_condition\\)\\*\\ |must\\\\|term\\\\|\\\n\\\n//\\ Bool\\ query\\\nbool_query:\\ |\\ field_value\\ |\\\n\\\n//\\ Nested\\ query\\\nnested_query:\\ |\\ fuzzy_options\\]\\ |\\\n\\\n//\\ Terminals\\\nIDENTIFIER:\\ /\\[a\\-zA\\-Z_\\]\\[a\\-zA\\-Z0\\-9_\\]\\*/\\\nSTRING:\\ /|filter\\\\|\\\n\\\n//\\ Exists\\ query\\\nexists_query:\\ |\\\n\\\nmulti_match_params:\\ |range\\\\|\\ query_array\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\\n\\\nrange_condition:\\ range_op\\ |\\ field_match\\ |cardinality\\\\|lte\\\\|\\ query_string_options\\]\\ |query_string\\\\|\\ agg_definition\\)\\*\\ |or\\\\|min\\\\|\\ multi_match_params\\ |\\\n\\\nNULL:\\ |\\ STRING\\\n\\\n//\\ Fuzzy\\ query\\\nfuzzy_query:\\ |\\ agg_params\\ |\\\n\\\nagg_param:\\ STRING\\ |wildcard\\\\|\\ match_option\\)\\*\\\n\\\nmatch_option:\\ |sum\\\\|exists\\\\|stats\\\\|\\ match_options\\]\\ |\\ \\[|histogram\\\\|operator\\\\|\\\\|\\ match_options\\]\\\n\\\n//\\ Query\\ string\\\nquery_string_query:\\ |\\ agg_type\\ |max\\\\|terms\\\\|field\\\\|\\\n\\\n//\\ Range\\ query\\\nrange_query:\\ |\\ value\\)\\*\\ |\\\n\\\nagg_params:\\ |analyzer\\\\|\\ value\\\n\\\n//\\ Values\\\nvalue:\\ STRING\\ \\|\\ NUMBER\\ \\|\\ BOOLEAN_LITERAL\\ \\|\\ NULL\\\n\\\nBOOLEAN_LITERAL:\\ |\\ range_condition\\ \\(|\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\\n\\\nagg_type:\\ |fuzziness\\\\|\\\n\\\nbool_clauses:\\ bool_clause\\ \\(|OR\\\\|gt\\\\|\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |bool\\\\|\\ fuzzy_option\\)\\*\\\n\\\nfuzzy_option:\\ |gte\\\\|\\\n\\\nagg_definition:\\ STRING\\ |\\ STRING\\ \\[|default_operator\\\\|\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ query\\\n\\\n//\\ Multi\\-match\\ query\\\nmulti_match_query:\\ |\\ value\\\n\\\nterms_query:\\ |date_histogram\\\\|\\\n\\\n//\\ Wildcard\\ query\\\nwildcard_query:\\ |\\ STRING\\\n\\\n//\\ Term\\ queries\\\nterm_query:\\ |\\ query\\ |aggs\\\\|query\\\\|\\\n\\\nmatch_query:\\ |\\ STRING\\)\\*\\ |path\\\\|\\]\\*|\\ agg_definition\\ \\(|\\ \\(STRING\\ \\|\\ NUMBER\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |fields\\\\|\\\n\\\nfuzzy_options:\\ fuzzy_option\\ \\(|\\ agg_param\\)\\*\\ |\\ STRING\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\\n\\\nfield_value:\\ STRING\\ |\\ NUMBER\\\n\\\nquery_array:\\ |\\ query\\ \\(|prefix_length\\\\|default_field\\\\|\\ query\\)\\*\\ |should\\\\|\\ bool_clause\\)\\*\\\n\\\nbool_clause:\\ |\\ \\|\\ |and\\\\|prefix\\\\|\\ bool_clauses\\ |multi_match\\\\|lt\\\\|nested\\\\|minimum_should_match\\\\|\\ STRING\\ |\\ value\\ \\(|avg\\\\",
  "brackets": [
    {
      "open": "{",
      "close": "}",
      "token": "delimiter.curly"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/\\ value\\\n\\\n//\\ Values\\\nvalue:\\ STRING\\ \\|\\ NUMBER\\ \\|\\ BOOLEAN_LITERAL\\ \\|\\ NULL\\\n\\\nBOOLEAN_LITERAL:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Terminals\\\nIDENTIFIER:\\ /\\[a\\-zA\\-Z_\\]\\[a\\-zA\\-Z0\\-9_\\]\\*/\\\nSTRING:\\ //",
        "operator"
      ],
      [
        "/\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ query\\\n\\\n//\\ Multi\\-match\\ query\\\nmulti_match_query:\\ /",
        "operator"
      ],
      [
        "/\\ match_options\\]\\\n\\\n//\\ Query\\ string\\\nquery_string_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nquery_string_options:\\ query_string_option\\ \\(/",
        "operator"
      ],
      [
        "/\\ query_string_option\\)\\*\\\n\\\nquery_string_option:\\ /",
        "operator"
      ],
      [
        "/\\ \\(STRING\\ \\|\\ match_params\\)\\\n\\\nmatch_params:\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\\n//\\ Prefix\\ query\\\nprefix_query:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\\n//\\ Fuzzy\\ query\\\nfuzzy_query:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\\n//\\ Term\\ queries\\\nterm_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Aggregation\\\naggregation_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Wildcard\\ query\\\nwildcard_query:\\ /",
        "operator"
      ],
      [
        "/\\ \\(STRING\\ \\|\\ NUMBER\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Nested\\ query\\\nnested_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Exists\\ query\\\nexists_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nmatch_options:\\ match_option\\ \\(/",
        "operator"
      ],
      [
        "/\\ match_option\\)\\*\\\n\\\nmatch_option:\\ /",
        "operator"
      ],
      [
        "/\\ fuzzy_option\\)\\*\\\n\\\nfuzzy_option:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfuzzy_options:\\ fuzzy_option\\ \\(/",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Range\\ query\\\nrange_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nbool_clauses:\\ bool_clause\\ \\(/",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ bool_clause\\)\\*\\\n\\\nbool_clause:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Bool\\ query\\\nbool_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nrange_condition:\\ range_op\\ /",
        "operator"
      ],
      [
        "/\\ query_array\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_definition:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ query_string_options\\]\\ /",
        "operator"
      ],
      [
        "/\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfield_match:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nmulti_match_params:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfield_value:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\\nquery_array:\\ /",
        "operator"
      ],
      [
        "/\\ value\\\n\\\nterms_query:\\ /",
        "operator"
      ],
      [
        "/minimum_should_match\\\\/",
        "operator"
      ],
      [
        "/\\ multi_match_params\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_param:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ range_condition\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ value\\\n\\\nrange_op:\\ /",
        "operator"
      ],
      [
        "/\\ agg_definition\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ range_condition\\ \\(/",
        "operator"
      ],
      [
        "/default_operator\\\\/",
        "operator"
      ],
      [
        "/\\ agg_definition\\ \\(/",
        "operator"
      ],
      [
        "/\\ fuzzy_options\\]\\ /",
        "operator"
      ],
      [
        "/\\ match_options\\]\\ /",
        "operator"
      ],
      [
        "/\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/date_histogram\\\\/",
        "operator"
      ],
      [
        "/\\\n\\\nmatch_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_params:\\ /",
        "operator"
      ],
      [
        "/prefix_length\\\\/",
        "operator"
      ],
      [
        "/default_field\\\\/",
        "operator"
      ],
      [
        "/\\ bool_clauses\\ /",
        "operator"
      ],
      [
        "/\\ field_value\\ /",
        "operator"
      ],
      [
        "/\\ field_match\\ /",
        "operator"
      ],
      [
        "/query_string\\\\/",
        "operator"
      ],
      [
        "/\\ agg_param\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ agg_param\\ \\(/",
        "operator"
      ],
      [
        "/cardinality\\\\/",
        "operator"
      ],
      [
        "/\\ agg_params\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_type:\\ /",
        "operator"
      ],
      [
        "/multi_match\\\\/",
        "operator"
      ],
      [
        "/\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/histogram\\\\/",
        "operator"
      ],
      [
        "/\\ agg_type\\ /",
        "operator"
      ],
      [
        "/fuzziness\\\\/",
        "operator"
      ],
      [
        "/\\ STRING\\)\\*\\ /",
        "operator"
      ],
      [
        "/must_not\\\\/",
        "operator"
      ],
      [
        "/\\ STRING\\ \\(/",
        "operator"
      ],
      [
        "/wildcard\\\\/",
        "operator"
      ],
      [
        "/operator\\\\/",
        "operator"
      ],
      [
        "/\\ value\\)\\*\\ /",
        "operator"
      ],
      [
        "/analyzer\\\\/",
        "operator"
      ],
      [
        "/\\ STRING\\ \\[/",
        "operator"
      ],
      [
        "/\\ query\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nNULL:\\ /",
        "operator"
      ],
      [
        "/\\ query\\ \\(/",
        "operator"
      ],
      [
        "/\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ value\\ \\(/",
        "operator"
      ],
      [
        "/filter\\\\/",
        "operator"
      ],
      [
        "/exists\\\\/",
        "operator"
      ],
      [
        "/\\ query\\ /",
        "operator"
      ],
      [
        "/fields\\\\/",
        "operator"
      ],
      [
        "/should\\\\/",
        "operator"
      ],
      [
        "/prefix\\\\/",
        "operator"
      ],
      [
        "/nested\\\\/",
        "operator"
      ],
      [
        "/match\\\\/",
        "operator"
      ],
      [
        "/value\\\\/",
        "operator"
      ],
      [
        "/fuzzy\\\\/",
        "operator"
      ],
      [
        "/range\\\\/",
        "operator"
      ],
      [
        "/stats\\\\/",
        "operator"
      ],
      [
        "/terms\\\\/",
        "operator"
      ],
      [
        "/field\\\\/",
        "operator"
      ],
      [
        "/query\\\\/",
        "operator"
      ],
      [
        "/must\\\\/",
        "operator"
      ],
      [
        "/term\\\\/",
        "operator"
      ],
      [
        "/bool\\\\/",
        "operator"
      ],
      [
        "/aggs\\\\/",
        "operator"
      ],
      [
        "/path\\\\/",
        "operator"
      ],
      [
        "/AND\\\\/",
        "operator"
      ],
      [
        "/lte\\\\/",
        "operator"
      ],
      [
        "/min\\\\/",
        "operator"
      ],
      [
        "/sum\\\\/",
        "operator"
      ],
      [
        "/max\\\\/",
        "operator"
      ],
      [
        "/gte\\\\/",
        "operator"
      ],
      [
        "/and\\\\/",
        "operator"
      ],
      [
        "/avg\\\\/",
        "operator"
      ],
      [
        "/or\\\\/",
        "operator"
      ],
      [
        "/OR\\\\/",
        "operator"
      ],
      [
        "/gt\\\\/",
        "operator"
      ],
      [
        "/\\ \\|\\ /",
        "operator"
      ],
      [
        "/lt\\\\/",
        "operator"
      ],
      [
        "/\\ \\(/",
        "operator"
      ],
      [
        "/\\ \\[/",
        "operator"
      ],
      [
        "/\\]\\*/",
        "operator"
      ],
      [
        "/\\{/",
        "operator"
      ],
      [
        "/\\\\/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const elasticsearchLanguageConfig = {
  "brackets": [
    [
      "{",
      "}"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "{",
      "close": "}"
    }
  ],
  "surroundingPairs": [
    {
      "open": "{",
      "close": "}"
    }
  ]
};
// Register with Monaco Editor
export function registerElasticsearchLanguage(monaco: any) {
  monaco.languages.register({ id: 'elasticsearch' });
  monaco.languages.setMonarchTokensProvider('elasticsearch', elasticsearchLanguage);
  monaco.languages.setLanguageConfiguration('elasticsearch', elasticsearchLanguageConfig);
}
