// xslt.monarch.ts
// Auto-generated Monaco language definition
export const xsltLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".xslt",
  "operators": [
    "\n\nattribute: IDENTIFIER ",
    "\n\nxsl_apply_templates: ",
    "\n\nxsl_choose: ",
    "\n\nxsl_for_each: ",
    "\n\nxsl_if: ",
    "\n\nxsl_otherwise: ",
    "\n\nxsl_when: ",
    " (attribute)* ",
    " (content)* ",
    " (xsl_when)* (xsl_otherwise)? ",
    " /[^",
    " IDENTIFIER ",
    " IDENTIFIER (attribute)* (",
    " attribute_value\n\nattribute_value: ",
    " | ",
    ")\n\ncontent: xsl_element | literal_element | text | xsl_value_of | xsl_for_each | xsl_if | xsl_choose | xsl_apply_templates\n\nxsl_value_of: ",
    ")\n\nliteral_element: ",
    "/\n\nstylesheet_element: xsl_element | literal_element\n\nxsl_element: ",
    "<?xml",
    "?>",
    "[^",
    "\\"
  ],
  "symbols": "\\ \\(content\\)\\*\\ |\\)\\\n\\\nliteral_element:\\ |\\ /\\[\\^|\\ attribute_value\\\n\\\nattribute_value:\\ |\\\\|\\\n\\\nxsl_if:\\ |\\)\\\n\\\ncontent:\\ xsl_element\\ \\|\\ literal_element\\ \\|\\ text\\ \\|\\ xsl_value_of\\ \\|\\ xsl_for_each\\ \\|\\ xsl_if\\ \\|\\ xsl_choose\\ \\|\\ xsl_apply_templates\\\n\\\nxsl_value_of:\\ |\\\n\\\nxsl_when:\\ |<\\?xml|\\\n\\\nxsl_apply_templates:\\ |\\\n\\\nxsl_otherwise:\\ |\\ IDENTIFIER\\ \\(attribute\\)\\*\\ \\(|\\[\\^|\\ \\|\\ |\\ \\(attribute\\)\\*\\ |\\ IDENTIFIER\\ |/\\\n\\\nstylesheet_element:\\ xsl_element\\ \\|\\ literal_element\\\n\\\nxsl_element:\\ |\\?>|\\\n\\\nxsl_for_each:\\ |\\\n\\\nattribute:\\ IDENTIFIER\\ |\\\n\\\nxsl_choose:\\ |\\ \\(xsl_when\\)\\*\\ \\(xsl_otherwise\\)\\?\\ ",
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/\\)\\\n\\\ncontent:\\ xsl_element\\ \\|\\ literal_element\\ \\|\\ text\\ \\|\\ xsl_value_of\\ \\|\\ xsl_for_each\\ \\|\\ xsl_if\\ \\|\\ xsl_choose\\ \\|\\ xsl_apply_templates\\\n\\\nxsl_value_of:\\ /",
        "operator"
      ],
      [
        "//\\\n\\\nstylesheet_element:\\ xsl_element\\ \\|\\ literal_element\\\n\\\nxsl_element:\\ /",
        "operator"
      ],
      [
        "/\\ attribute_value\\\n\\\nattribute_value:\\ /",
        "operator"
      ],
      [
        "/\\ \\(xsl_when\\)\\*\\ \\(xsl_otherwise\\)\\?\\ /",
        "operator"
      ],
      [
        "/\\ IDENTIFIER\\ \\(attribute\\)\\*\\ \\(/",
        "operator"
      ],
      [
        "/\\\n\\\nattribute:\\ IDENTIFIER\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nxsl_apply_templates:\\ /",
        "operator"
      ],
      [
        "/\\)\\\n\\\nliteral_element:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nxsl_otherwise:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nxsl_for_each:\\ /",
        "operator"
      ],
      [
        "/\\ \\(attribute\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nxsl_choose:\\ /",
        "operator"
      ],
      [
        "/\\ \\(content\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nxsl_when:\\ /",
        "operator"
      ],
      [
        "/\\ IDENTIFIER\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nxsl_if:\\ /",
        "operator"
      ],
      [
        "/<\\?xml/",
        "operator"
      ],
      [
        "/\\ /\\[\\^/",
        "operator"
      ],
      [
        "/\\ \\|\\ /",
        "operator"
      ],
      [
        "/\\[\\^/",
        "operator"
      ],
      [
        "/\\?>/",
        "operator"
      ],
      [
        "/\\\\/",
        "operator"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const xsltLanguageConfig = {};
// Register with Monaco Editor
export function registerXsltLanguage(monaco: any) {
  monaco.languages.register({ id: 'xslt' });
  monaco.languages.setMonarchTokensProvider('xslt', xsltLanguage);
  monaco.languages.setLanguageConfiguration('xslt', xsltLanguageConfig);
}
