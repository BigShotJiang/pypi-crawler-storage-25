// sql.monarch.ts
// Auto-generated Monaco language definition
export const sqlLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".sql",
  "ignoreCase": true,
  "keywords": [
    "ALL",
    "BLOB",
    "BOOL",
    "BOOLEAN",
    "CHAR",
    "CROSS",
    "DATE",
    "DATETIME",
    "DECIMAL",
    "DISTINCT",
    "DOUBLE",
    "FLOAT",
    "FULL",
    "INNER",
    "INT",
    "INTEGER",
    "LEFT",
    "NUMERIC",
    "RIGHT",
    "TEXT",
    "TIME",
    "TIMESTAMP",
    "TOP",
    "VARCHAR"
  ],
  "operators": [
    "!=",
    "%",
    "(",
    ")",
    "*",
    "+",
    ",",
    "-",
    ".",
    "/",
    "/\n\n// Keywords (case-insensitive)\nSELECT: ",
    "<",
    "<=",
    "<>",
    "=",
    ">",
    ">=",
    "[^",
    "]+",
    "i\n\n// Terminals\nQUOTED_IDENTIFIER: /`[^`]+`/ | /\\[[^\\]]+\\]/ | /",
    "i\nADD: ",
    "i\nALTER: ",
    "i\nAND: ",
    "i\nAS: ",
    "i\nASC: ",
    "i\nBETWEEN: ",
    "i\nBOOLEAN: ",
    "i\nBY: ",
    "i\nCHECK: ",
    "i\nCOLUMN: ",
    "i\nCREATE: ",
    "i\nDATABASE: ",
    "i\nDELETE: ",
    "i\nDESC: ",
    "i\nDROP: ",
    "i\nFOREIGN_KEY: ",
    "i\nFROM: ",
    "i\nGROUP: ",
    "i\nHAVING: ",
    "i\nIN: ",
    "i\nINDEX: ",
    "i\nINSERT: ",
    "i\nINTO: ",
    "i\nIS: ",
    "i\nJOIN: ",
    "i\nLIKE: ",
    "i\nLIMIT: ",
    "i\nMODIFY: ",
    "i\nNOT: ",
    "i\nNOT_NULL: ",
    "i\nNULL: ",
    "i\nOFFSET: ",
    "i\nON: ",
    "i\nOR: ",
    "i\nORDER: ",
    "i\nPRIMARY_KEY: ",
    "i\nSET: ",
    "i\nTABLE: ",
    "i\nUNIQUE: ",
    "i\nUPDATE: ",
    "i\nVALUES: ",
    "i\nVIEW: ",
    "i\nWHERE: ",
    "i ",
    "i | "
  ],
  "symbols": "i\\ |<|i\\\nALTER:\\ |i\\\nSET:\\ |i\\\nTABLE:\\ |%|i\\\nINDEX:\\ |i\\\nASC:\\ |i\\\nUNIQUE:\\ |i\\\nDATABASE:\\ |\\]\\+|i\\\nVIEW:\\ |\\+|i\\\nCREATE:\\ |i\\\nAND:\\ |i\\\nNOT:\\ |i\\\nFOREIGN_KEY:\\ |<=|\\.|i\\\nINTO:\\ |i\\\nORDER:\\ |!=|i\\\nDESC:\\ |\\)|i\\\nHAVING:\\ |i\\\nIN:\\ |i\\\nUPDATE:\\ |i\\\nLIMIT:\\ |i\\ \\|\\ |i\\\nCHECK:\\ |i\\\n\\\n//\\ Terminals\\\nQUOTED_IDENTIFIER:\\ /`\\[\\^`\\]\\+`/\\ \\|\\ /\\\\\\[\\[\\^\\\\\\]\\]\\+\\\\\\]/\\ \\|\\ /|,|>|i\\\nBOOLEAN:\\ |>=|<>|i\\\nWHERE:\\ |i\\\nINSERT:\\ |i\\\nOR:\\ |i\\\nBETWEEN:\\ |i\\\nPRIMARY_KEY:\\ |i\\\nNULL:\\ |i\\\nON:\\ |\\[\\^|i\\\nDELETE:\\ |i\\\nLIKE:\\ |i\\\nNOT_NULL:\\ |i\\\nMODIFY:\\ |i\\\nJOIN:\\ |i\\\nFROM:\\ |/|=|i\\\nADD:\\ |i\\\nGROUP:\\ |i\\\nAS:\\ |i\\\nCOLUMN:\\ |i\\\nBY:\\ |/\\\n\\\n//\\ Keywords\\ \\(case\\-insensitive\\)\\\nSELECT:\\ |i\\\nDROP:\\ |i\\\nOFFSET:\\ |\\(|\\-|i\\\nIS:\\ |i\\\nVALUES:\\ |\\*",
  "brackets": [
    {
      "open": "(",
      "close": ")",
      "token": "delimiter.parenthesis"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/i\\\n\\\n//\\ Terminals\\\nQUOTED_IDENTIFIER:\\ /`\\[\\^`\\]\\+`/\\ \\|\\ /\\\\\\[\\[\\^\\\\\\]\\]\\+\\\\\\]/\\ \\|\\ //",
        "operator"
      ],
      [
        "//\\\n\\\n//\\ Keywords\\ \\(case\\-insensitive\\)\\\nSELECT:\\ /",
        "operator"
      ],
      [
        "/i\\\nFOREIGN_KEY:\\ /",
        "operator"
      ],
      [
        "/i\\\nPRIMARY_KEY:\\ /",
        "operator"
      ],
      [
        "/i\\\nDATABASE:\\ /",
        "operator"
      ],
      [
        "/i\\\nNOT_NULL:\\ /",
        "operator"
      ],
      [
        "/i\\\nBOOLEAN:\\ /",
        "operator"
      ],
      [
        "/i\\\nBETWEEN:\\ /",
        "operator"
      ],
      [
        "/i\\\nUNIQUE:\\ /",
        "operator"
      ],
      [
        "/i\\\nCREATE:\\ /",
        "operator"
      ],
      [
        "/i\\\nHAVING:\\ /",
        "operator"
      ],
      [
        "/i\\\nUPDATE:\\ /",
        "operator"
      ],
      [
        "/i\\\nINSERT:\\ /",
        "operator"
      ],
      [
        "/i\\\nDELETE:\\ /",
        "operator"
      ],
      [
        "/i\\\nMODIFY:\\ /",
        "operator"
      ],
      [
        "/i\\\nCOLUMN:\\ /",
        "operator"
      ],
      [
        "/i\\\nOFFSET:\\ /",
        "operator"
      ],
      [
        "/i\\\nVALUES:\\ /",
        "operator"
      ],
      [
        "/i\\\nALTER:\\ /",
        "operator"
      ],
      [
        "/i\\\nTABLE:\\ /",
        "operator"
      ],
      [
        "/i\\\nINDEX:\\ /",
        "operator"
      ],
      [
        "/i\\\nORDER:\\ /",
        "operator"
      ],
      [
        "/i\\\nLIMIT:\\ /",
        "operator"
      ],
      [
        "/i\\\nCHECK:\\ /",
        "operator"
      ],
      [
        "/i\\\nWHERE:\\ /",
        "operator"
      ],
      [
        "/i\\\nGROUP:\\ /",
        "operator"
      ],
      [
        "/i\\\nVIEW:\\ /",
        "operator"
      ],
      [
        "/i\\\nINTO:\\ /",
        "operator"
      ],
      [
        "/i\\\nDESC:\\ /",
        "operator"
      ],
      [
        "/i\\\nNULL:\\ /",
        "operator"
      ],
      [
        "/i\\\nLIKE:\\ /",
        "operator"
      ],
      [
        "/i\\\nJOIN:\\ /",
        "operator"
      ],
      [
        "/i\\\nFROM:\\ /",
        "operator"
      ],
      [
        "/i\\\nDROP:\\ /",
        "operator"
      ],
      [
        "/i\\\nSET:\\ /",
        "operator"
      ],
      [
        "/i\\\nASC:\\ /",
        "operator"
      ],
      [
        "/i\\\nAND:\\ /",
        "operator"
      ],
      [
        "/i\\\nNOT:\\ /",
        "operator"
      ],
      [
        "/i\\\nADD:\\ /",
        "operator"
      ],
      [
        "/i\\\nIN:\\ /",
        "operator"
      ],
      [
        "/i\\\nOR:\\ /",
        "operator"
      ],
      [
        "/i\\\nON:\\ /",
        "operator"
      ],
      [
        "/i\\\nAS:\\ /",
        "operator"
      ],
      [
        "/i\\\nBY:\\ /",
        "operator"
      ],
      [
        "/i\\\nIS:\\ /",
        "operator"
      ],
      [
        "/i\\ \\|\\ /",
        "operator"
      ],
      [
        "/i\\ /",
        "operator"
      ],
      [
        "/\\]\\+/",
        "operator"
      ],
      [
        "/<=/",
        "operator"
      ],
      [
        "/!=/",
        "operator"
      ],
      [
        "/>=/",
        "operator"
      ],
      [
        "/<>/",
        "operator"
      ],
      [
        "/\\[\\^/",
        "operator"
      ],
      [
        "/</",
        "operator"
      ],
      [
        "/%/",
        "operator"
      ],
      [
        "/\\+/",
        "operator"
      ],
      [
        "/\\./",
        "operator"
      ],
      [
        "/\\)/",
        "operator"
      ],
      [
        "/,/",
        "operator"
      ],
      [
        "/>/",
        "operator"
      ],
      [
        "///",
        "operator"
      ],
      [
        "/=/",
        "operator"
      ],
      [
        "/\\(/",
        "operator"
      ],
      [
        "/\\-/",
        "operator"
      ],
      [
        "/\\*/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const sqlLanguageConfig = {
  "brackets": [
    [
      "(",
      ")"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "'",
      "close": "'"
    }
  ],
  "surroundingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "'",
      "close": "'"
    }
  ]
};
// Register with Monaco Editor
export function registerSqlLanguage(monaco: any) {
  monaco.languages.register({ id: 'sql' });
  monaco.languages.setMonarchTokensProvider('sql', sqlLanguage);
  monaco.languages.setLanguageConfiguration('sql', sqlLanguageConfig);
}
