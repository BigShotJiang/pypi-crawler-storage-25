// mongodb.monarch.ts
// Auto-generated Monaco language definition
export const mongodbLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".mongodb",
  "keywords": [
    "Date",
    "ISODate",
    "ObjectId",
    "aggregate",
    "countDocuments",
    "db",
    "deleteMany",
    "deleteOne",
    "false",
    "find",
    "insertMany",
    "insertOne",
    "new",
    "null",
    "project",
    "replaceOne",
    "true",
    "updateMany",
    "updateOne"
  ],
  "operators": [
    "$addFields",
    "$addToSet",
    "$all",
    "$and",
    "$bucket",
    "$count",
    "$elemMatch",
    "$eq",
    "$exists",
    "$facet",
    "$graphLookup",
    "$group",
    "$gt",
    "$gte",
    "$in",
    "$inc",
    "$limit",
    "$lookup",
    "$lt",
    "$lte",
    "$match",
    "$mul",
    "$ne",
    "$nin",
    "$nor",
    "$not",
    "$or",
    "$pop",
    "$project",
    "$pull",
    "$push",
    "$regex",
    "$rename",
    "$replaceRoot",
    "$set",
    "$size",
    "$skip",
    "$sort",
    "$text",
    "$type",
    "$unset",
    "$unwind",
    "$where",
    "(",
    ")",
    ",",
    ".",
    "/ | /",
    "0",
    "1",
    ":",
    "[",
    "[^",
    "]",
    "]*",
    "{",
    "}"
  ],
  "symbols": "\\$addToSet|\\$exists|\\$gt|\\{|\\$count|\\$pull|1|\\$not|0|\\$eq|\\}|\\$where|\\$mul|\\$nor|\\$sort|\\$facet|\\$in|\\.|\\$rename|\\]\\*|\\$ne|\\$limit|\\$graphLookup|\\)|\\$lookup|\\$lte|\\$lt|\\$text|,|\\$and|\\$regex|\\$replaceRoot|\\$unset|\\$project|\\$skip|\\$elemMatch|\\[|\\$group|\\$bucket|\\$addFields|\\$type|\\[\\^|\\$inc|\\$set|\\$all|\\$pop|\\$unwind|\\$match|/\\ \\|\\ /|\\]|\\$push|\\$size|\\$or|:|\\$gte|\\(|\\$nin",
  "brackets": [
    {
      "open": "(",
      "close": ")",
      "token": "delimiter.parenthesis"
    },
    {
      "open": "[",
      "close": "]",
      "token": "delimiter.square"
    },
    {
      "open": "{",
      "close": "}",
      "token": "delimiter.curly"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/\\$graphLookup/",
        "operator"
      ],
      [
        "/\\$replaceRoot/",
        "operator"
      ],
      [
        "/\\$elemMatch/",
        "operator"
      ],
      [
        "/\\$addFields/",
        "operator"
      ],
      [
        "/\\$addToSet/",
        "operator"
      ],
      [
        "/\\$project/",
        "operator"
      ],
      [
        "/\\$exists/",
        "operator"
      ],
      [
        "/\\$rename/",
        "operator"
      ],
      [
        "/\\$lookup/",
        "operator"
      ],
      [
        "/\\$bucket/",
        "operator"
      ],
      [
        "/\\$unwind/",
        "operator"
      ],
      [
        "/\\$count/",
        "operator"
      ],
      [
        "/\\$where/",
        "operator"
      ],
      [
        "/\\$facet/",
        "operator"
      ],
      [
        "/\\$limit/",
        "operator"
      ],
      [
        "/\\$regex/",
        "operator"
      ],
      [
        "/\\$unset/",
        "operator"
      ],
      [
        "/\\$group/",
        "operator"
      ],
      [
        "/\\$match/",
        "operator"
      ],
      [
        "/\\$pull/",
        "operator"
      ],
      [
        "/\\$sort/",
        "operator"
      ],
      [
        "/\\$text/",
        "operator"
      ],
      [
        "/\\$skip/",
        "operator"
      ],
      [
        "/\\$type/",
        "operator"
      ],
      [
        "//\\ \\|\\ //",
        "operator"
      ],
      [
        "/\\$push/",
        "operator"
      ],
      [
        "/\\$size/",
        "operator"
      ],
      [
        "/\\$not/",
        "operator"
      ],
      [
        "/\\$mul/",
        "operator"
      ],
      [
        "/\\$nor/",
        "operator"
      ],
      [
        "/\\$lte/",
        "operator"
      ],
      [
        "/\\$and/",
        "operator"
      ],
      [
        "/\\$inc/",
        "operator"
      ],
      [
        "/\\$set/",
        "operator"
      ],
      [
        "/\\$all/",
        "operator"
      ],
      [
        "/\\$pop/",
        "operator"
      ],
      [
        "/\\$gte/",
        "operator"
      ],
      [
        "/\\$nin/",
        "operator"
      ],
      [
        "/\\$gt/",
        "operator"
      ],
      [
        "/\\$eq/",
        "operator"
      ],
      [
        "/\\$in/",
        "operator"
      ],
      [
        "/\\$ne/",
        "operator"
      ],
      [
        "/\\$lt/",
        "operator"
      ],
      [
        "/\\$or/",
        "operator"
      ],
      [
        "/\\]\\*/",
        "operator"
      ],
      [
        "/\\[\\^/",
        "operator"
      ],
      [
        "/\\{/",
        "operator"
      ],
      [
        "/1/",
        "operator"
      ],
      [
        "/0/",
        "operator"
      ],
      [
        "/\\}/",
        "operator"
      ],
      [
        "/\\./",
        "operator"
      ],
      [
        "/\\)/",
        "operator"
      ],
      [
        "/,/",
        "operator"
      ],
      [
        "/\\[/",
        "operator"
      ],
      [
        "/\\]/",
        "operator"
      ],
      [
        "/:/",
        "operator"
      ],
      [
        "/\\(/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const mongodbLanguageConfig = {
  "brackets": [
    [
      "(",
      ")"
    ],
    [
      "[",
      "]"
    ],
    [
      "{",
      "}"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "[",
      "close": "]"
    },
    {
      "open": "{",
      "close": "}"
    },
    {
      "open": "'",
      "close": "'"
    }
  ],
  "surroundingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "[",
      "close": "]"
    },
    {
      "open": "{",
      "close": "}"
    },
    {
      "open": "'",
      "close": "'"
    }
  ]
};
// Register with Monaco Editor
export function registerMongodbLanguage(monaco: any) {
  monaco.languages.register({ id: 'mongodb' });
  monaco.languages.setMonarchTokensProvider('mongodb', mongodbLanguage);
  monaco.languages.setLanguageConfiguration('mongodb', mongodbLanguageConfig);
}
