import os, json
from pathlib import Path
import datetime as dt
from sdevpy.volatility.impliedvol.models import biexp, vsvi, cubicvol
from sdevpy.volatility.localvol import localvol
from sdevpy.utilities import dates
from sdevpy.maths import interpolation as itp


def get_local_vols(names, valdate, **kwargs):
    folder = kwargs.get('folder', test_data_folder())
    lvs = []
    for name in names:
        lvs.append(load_lv_from_folder(None, valdate, name, folder))

    return lvs


def create_sections(t_grid, model):
    sections = []
    for t in t_grid:
        config = {'time': t, 'model': model, 'params': None}
        section = create_section(config)
        sections.append(section)

    return sections


def create_section(config):
    time = config.get('time', None)
    model = config.get('model', None)
    param_config = config.get('params', None)
    if time is None or model is None: # or param_config is None:
        raise ValueError("Invalid section input in local vol file")

    match model.lower():
        case 'biexp':
            section = biexp.create_section(time, param_config)
        case 'cubicvol':
            section = cubicvol.create_section(time, param_config)
        case 'vsvi':
            section = vsvi.create_section(time, param_config)
        case _:
            section = None
            raise ValueError(f"Unknown section type: {model}")

    return section


def load_lv_new(t_grid, model):
    sections = create_sections(t_grid, model)
    lv = localvol.InterpolatedParamLocalVol(sections)
    return lv


def load_lv_from_folder(t_grid, store_date, name, folder):
    file = os.path.join(folder, name)
    os.makedirs(file, exist_ok=True)
    file = os.path.join(file, store_date.strftime(dates.DATE_FILE_FORMAT) + ".json")

    # Check file existence
    if not os.path.exists(file):
        raise FileNotFoundError(f"Local vol file not found: {file}")

    # Retrieve LV definition
    with open(file) as f:
        data = json.load(f)

    # Load LV
    lv = load_lv_from_data(t_grid, data)
    return lv


def load_lv_from_data(new_t_grid, data):
    # Create sections
    sections = data['sections']
    if sections is None:
        raise KeyError("Sections node not valid in LV data")

    if new_t_grid is None: # Just use the data
        new_section_grid = []
        for section_config in sections:
            section = create_section(section_config)
            new_section_grid.append(section)
    else:
        # Collect stored grids
        old_t_grid, model_names, parameters = [], [], []
        for section in sections:
            old_t_grid.append(section['time'])
            model_names.append(section['model'])
            parameters.append(section['params'])

        # Check section consistency
        model_name = model_names[0]
        param_names = parameters[0].keys()
        param_size = len(param_names)
        same_models = all(x == model_name for x in model_names)
        same_sizes = all(len(x.keys()) == param_size for x in parameters)

        if not same_models or not same_sizes:
            raise RuntimeError("Impossible to set LV from previous data due to inconsistent sections")

        # Collect parameter vectors per parameter name
        param_vectors = {}
        for name in param_names:
            param_vectors[name] = []

        for p in parameters:
            for name in param_names:
                param_vectors[name].append(p[name])

        # Define interpolations
        interps = {}
        for name in param_names:
            interps[name] = itp.create_interpolation(interp='linear', l_extrap='flat', r_extrap='flat',
                                                    x_grid=old_t_grid, y_grid=param_vectors[name])

        # Interpolate
        new_section_grid = []
        for time in new_t_grid:
            params = {}
            for name in param_names:
                params[name] = float(interps[name].value(time))

            section_config = {'time': time, 'model': model_name, 'params': params}
            section = create_section(section_config)
            new_section_grid.append(section)

    # Create LV
    lv = localvol.InterpolatedParamLocalVol(new_section_grid)
    return lv


def write_example(date, name, folder):
    file = os.path.join(folder, name)
    os.makedirs(file, exist_ok=True)
    file = os.path.join(file, "localvol_" + date.strftime("%Y%m%d-%H.%M.%S") + ".json")
    sections = []
    print(file)
    for i in range(4):
        time = i / 4.0 * 2.5
        model = 'BiExp'
        params = {'f0': 0.5, 'fl': 0.2, 'fr': 0.2, 'taul': 0.2, 'taur': 0.2, 'fp': 0.2}
        section = {'time': time, 'model': model, 'params': params}
        sections.append(section)

    obj = {'name': name, 'datetime': date.strftime(dates.DATE_FORMAT), 'sections': sections}

    with open(file, 'w') as f:
        json.dump(obj, f, indent=2)


def test_data_folder():
    folder = Path(__file__).parent.parent.parent.parent.resolve()
    folder = os.path.join(os.path.join(folder, "datasets"), "localvol")
    os.makedirs(folder, exist_ok=True)
    return folder


if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import numpy as np

    name = "XYZ" # "ABC"
    valdate = dt.datetime(2025, 12, 15)
    folder = test_data_folder()

    # # Generate a sample to start from
    # write_example(valdate, name, folder)

    # Load
    store_date = valdate
    # new_date = valdate
    new_expiries = None # [1.0, 2.0]# [dt.datetime(2026, 12, 15), dt.datetime(2027, 12, 15)]
    lv = load_lv_from_folder(new_expiries, store_date, name, folder)
    lv.name = name
    lv.valdate = valdate

    # Dump
    lv_data = lv.dump_data()
    print(lv_data)
    data = {'valdate': valdate.strftime(dates.DATE_FORMAT),
            'snapdate': valdate.strftime(dates.DATETIME_FORMAT),
            'sections': lv_data}
    file = os.path.join(folder, 'test_dump.json')
    print(file)
    print(data)
    with open(file, 'w') as f:
        json.dump(data, f, indent=2)

    # View
    expiries = lv.t_grid
    n_expiries = len(expiries)
    x = np.linspace(-0.5, 0.5, 100)
    exp_idx = n_expiries - 1
    lparams = lv.params(exp_idx)
    print(lparams)
    lvols = lv.value(expiries[exp_idx], x)

    plt.plot(x, lvols)
    plt.show()
