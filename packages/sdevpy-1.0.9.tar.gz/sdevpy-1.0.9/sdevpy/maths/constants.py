import sys


FLOAT_INFTY = float('inf')
FLOAT_MAX = sys.float_info.max
FLOAT_MIN = sys.float_info.min
MACHINE_EPS = sys.float_info.epsilon
EPS = 1e-11 # Practical machine epsilon to avoid risk of confusion, well above real eps~1e-15
DEATH_PENALTY = 1e6
C_SQRT_2 = 0.7071067811865475244008443621048490392848359376887
C_SQRT1_2 = 0.7071067811865475244008443621048490392848359376887
C_1_SQRTPI = 0.564189583547756286948
C_SQRT2 = 1.41421356237309504880
C_SQRTPI = 1.77245385090551602792981
C_PI = 3.141592653589793238462643383280
C_SQRT2PI = 2.50662827459518
C_2_SQRTPI = 1.12837916709551257390
k_2powneg32 = 2.3283064365387e-10 # Normalization factor for Sobol


if __name__ == "__main__":
    print(f"FLOAT_INFTY: {FLOAT_INFTY}")
    print(f"FLOAT_MAX: {FLOAT_MAX}")
    print(f"FLOAT_MIN: {FLOAT_MIN}")
    print(f"MACHINE_EPS: {MACHINE_EPS}")
    print(f"EPS: {EPS}")
    print(f"DEATH_PENALTY: {DEATH_PENALTY}")
    print(f"FLOAT_INFTY: {FLOAT_INFTY}")
