import os, json, logging
import datetime as dt
import numpy as np
from pathlib import Path
from sdevpy.utilities import dates
from sdevpy.utilities import timegrids
from sdevpy.analytics import black
log = logging.getLogger(__name__)


class EqVolSurfaceData:
    def __init__(self, valdate: dt.datetime, sections, **kwargs):
        self.valdate = valdate
        self.name = kwargs.get('name', '')
        self.snapdate = kwargs.get('snapdate', self.valdate)
        self.strike_input_type = kwargs.get('strike_input_type', 'absolute').lower()

        # Sort by increasing date
        sections.sort(key=lambda x: x['expiry'])

        # Extract
        self.expiries = np.asarray([s['expiry'] for s in sections])
        self.forwards = np.asarray([s['forward'] for s in sections])
        self.input_strikes = [np.asarray(s['strikes']) for s in sections]
        self.vols = [np.asarray(s['vols']) for s in sections]

        # Size checks
        n_times = len(self.expiries)
        if any(len(x) != n_times for x in (self.forwards, self.input_strikes, self.vols)):
            raise ValueError("Incompatible size along time direction between expiries, forwards, strikes and vols")

        # Calculate missing strike type
        if self.strike_input_type == 'absolute':
            self.abs_strikes = self.input_strikes
        elif self.strike_input_type == 'relative':
            # self.abs_strikes = self.forwards * self.input_strikes # Old way assuming numpy matrix
            # The code below is a quick non-tested implementation to cater for the non-matrix case.
            # To be tested if/when case presents itself.
            log.warning("Relative strike conversion should be tested")
            self.abs_strikes = []
            for i in range(n_times):
                self.abs_strikes.append(self.forwards[i] * self.input_strikes[i])
        else:
            raise ValueError(f"Strike input type not supported yet: {self.strike_input_type}")

        # Calculate prices
        self.call_prices = []
        for exp_idx, expiry in enumerate(self.expiries):
            t = timegrids.model_time(self.valdate, expiry)
            fwd = self.forwards[exp_idx]
            strikes = self.abs_strikes[exp_idx]
            vols = self.vols[exp_idx]
            self.call_prices.append(black.price(t, strikes, True, fwd, vols))

    def get_strikes(self, type: str='absolute'):
        req_type = type.lower()
        if req_type == 'absolute':
            return self.abs_strikes
        elif req_type == 'relative':
            return self.abs_strikes / self.forwards.reshape(-1, 1)
        else:
            raise ValueError(f"Unknown strike type {req_type}: expected absolute or relative")

    def dump(self, file, indent=2):
        data = self.dump_data()
        with open(file, 'w') as f:
            json.dump(data, f, indent=indent)

    def dump_data(self):
        sections = []
        for i, expiry in enumerate(self.expiries):
            expiry_str = expiry.strftime(dates.DATE_FORMAT)
            section = {'expiry': expiry_str, 'forward': self.forwards[i], 'strikes': self.input_strikes[i].tolist(),
                       'vols': self.vols[i].tolist()}
            sections.append(section)

        data = {'name': self.name, 'valdate': self.valdate.strftime(dates.DATE_FORMAT),
                'snapdate': self.snapdate.strftime(dates.DATETIME_FORMAT),
                'strike_input_type': self.strike_input_type, 'sections': sections}

        return data

    def pretty_print(self, n_digits=4):
        sep = '-'*70
        print(sep)
        print(sep)
        print(f"Name: {self.name}")
        print(f"Valuation date: {self.valdate.strftime(dates.DATE_FORMAT)}")
        print(f"Snap date: {self.snapdate.strftime(dates.DATETIME_FORMAT)}")
        print(f"Strike input type: {self.strike_input_type}")
        n_exp = len(self.expiries)
        print(f"Number of expiries: {n_exp}")
        for i in range(n_exp):
            print(sep)
            print(f"Expiry {i+1}/{n_exp}: {self.expiries[i].strftime(dates.DATE_FORMAT)}")
            print(f"Forward: {self.forwards[i]:,.{n_digits}f}")
            with np.printoptions(precision=n_digits):
                print("Strikes", self.input_strikes[i])
                print("Vols", self.vols[i])

        print(sep)
        print(sep)


def eqvolsurfacedata_from_file(file: str) -> EqVolSurfaceData:
    """ Retrieve EqVolSurfaceData from file """
    with open(file) as f:
        data = json.load(f)

    name = data.get('name')
    valdate = data.get('valdate')
    snapdate = data.get('snapdate')
    strike_input_type = data.get('strike_input_type')
    sections = data.get('sections')

    # Convert date strings into dates
    for section in sections:
        date_str = section.get('expiry')
        date = dt.datetime.strptime(date_str, dates.DATE_FORMAT)
        section['expiry'] = date

    data = EqVolSurfaceData(dt.datetime.strptime(valdate, dates.DATE_FORMAT), sections,
                            name=name, snapdate=dt.datetime.strptime(snapdate, dates.DATETIME_FORMAT),
                            strike_input_type=strike_input_type)
    return data


def data_file(name: str, date: dt.datetime, **kwargs) -> str:
    """ Data file path for EQ vol surfaces """
    folder = kwargs.get('folder', test_data_folder())
    name_folder = os.path.join(folder, name)
    os.makedirs(name_folder, exist_ok=True)
    file = os.path.join(name_folder, date.strftime(dates.DATE_FILE_FORMAT) + ".json")
    return file


def test_data_folder() -> str:
    """ Test data folder for EQ vol surfaces """
    folder = Path(__file__).parent.parent.parent.resolve()
    dataset_folder = os.path.join(folder, "datasets")
    folder = os.path.join(os.path.join(dataset_folder, "marketdata"), "eqoptions")
    os.makedirs(folder, exist_ok=True)
    return folder


if __name__ == "__main__":
    name = "ABC"
    valdate = dt.datetime(2025, 12, 15)
    folder = test_data_folder()

    # # Generate a sample to start from
    # from sdevpy.models import svivol
    # terms = [0.1, 0.25, 0.5, 1.0, 2.0, 5.0]
    # expiries, fwds, strike_surface, vol_surface = svivol.generate_sample_data(valdate, terms)
    # strike_types = ['absolute' for expiry in expiries]
    # surface_data = VolSufaceData(valdate, expiries, fwds, strike_surface, vol_surface, strike_types,
    #                              name=name)
    # file = data_file(folder, name, valdate)
    # surface_data.dump(file)

    # Get data from existing file
    file = data_file(folder, name, valdate)
    surface_data = eqvolsurfacedata_from_file(file)
    print(surface_data.get_strikes('absolute'))
    print(surface_data.get_strikes('relative'))
    surface_data.pretty_print(4)
