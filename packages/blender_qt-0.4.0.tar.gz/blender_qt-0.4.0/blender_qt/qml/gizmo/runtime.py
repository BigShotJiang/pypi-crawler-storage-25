"""QML viewport gizmo runtimes."""

from __future__ import annotations

from pathlib import Path

from ..._internal.viewport_gizmo import _ViewportPanelRuntimeBase, clear_runtimes, get_runtime
from ..render.renderer import OffscreenQuickRenderer


class QuickViewportPanelRuntime(_ViewportPanelRuntimeBase):
    def __init__(self, gizmo_id: str, qml_path: Path, **kwargs: object) -> None:
        super().__init__(gizmo_id, **kwargs)
        self._attach_renderer(OffscreenQuickRenderer(qml_path, 1.0))


__all__ = ["QuickViewportPanelRuntime", "clear_runtimes", "get_runtime"]
