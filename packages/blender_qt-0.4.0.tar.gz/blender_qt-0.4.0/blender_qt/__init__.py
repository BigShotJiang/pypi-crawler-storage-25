"""Blender Qt — Blender Qt integration library.

Public API surface.  Import directly from ``blender_qt``:

.. code-block:: python

    import blender_qt

    blender_qt.init()
    blender_qt.register_qml_space(...)
    blender_qt.register_widget_space(...)
    blender_qt.unregister_space(...)
    blender_qt.shutdown()
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING
from typing import Callable

from ._version import __version__

if TYPE_CHECKING:
    from PySide6 import QtWidgets
    from .core.interfaces import WidgetFactory

LOGGER = logging.getLogger(__name__)

__all__ = [
    "__version__",
    "init",
    "shutdown",
    "register_qml_space",
    "register_widget_space",
    "registered_space_types",
    "unregister_space",
    "register_qml_viewport_gizmo",
    "register_widget_viewport_gizmo",
    "registered_viewport_gizmo_ids",
    "unregister_viewport_gizmo",
    "register_window",
    "managed_windows",
    "close_managed_windows",
    "get_qt_application",
]


def init() -> None:
    """Initialise the Blender Qt runtime.

    Call this once during addon ``register()``.  It bootstraps the
    ``QApplication`` singleton, configures DPI overrides, applies the
    Blender theme, and starts the event-loop timer.
    """
    from .core.config import configure_logging  # noqa: WPS433
    from .core.config import get_runtime_options  # noqa: WPS433
    from .core.app import ensure_qt_app  # noqa: WPS433
    from .core.app import get_qt_application  # noqa: WPS433

    configure_logging()
    options = get_runtime_options()
    if options.disable_startup and get_qt_application() is None:
        LOGGER.warning("Blender Qt startup disabled by environment.")
        return

    ensure_qt_app()
    LOGGER.info("Blender Qt initialised.")


def shutdown() -> None:
    """Tear down the Blender Qt runtime.

    Call this during addon ``unregister()``.  Stops the event timer and
    unregisters all spaces and gizmos.
    """
    from .core.app import clear_renderers  # noqa: WPS433
    from .core.app import shutdown_qt_app  # noqa: WPS433
    from .core.windows import close_managed_windows as _close_managed_windows  # noqa: WPS433
    from .core.space.registration import get_registered_tree_types, unregister_space  # noqa: WPS433
    from .core.gizmo.registry import (
        get_registered_gizmo_ids,
        shutdown_global_operators,
        unregister_viewport_gizmo,
    )  # noqa: WPS433

    for gizmo_id in list(get_registered_gizmo_ids()):
        unregister_viewport_gizmo(gizmo_id)

    for tree_type in list(get_registered_tree_types()):
        unregister_space(tree_type)

    _close_managed_windows()
    clear_renderers()
    shutdown_global_operators()
    shutdown_qt_app()
    LOGGER.info("Blender Qt shut down.")


def register_qml_space(
    tree_type: str,
    label: str,
    qml_path: Path | str,
    *,
    icon: str = "RESTRICT_VIEW_OFF",
    sidebar_category: str = "Blender Qt",
    menu_draw_callback: Callable[[object, object], None] | None = None,
) -> None:
    """Register a QML-based custom space in a Blender node editor.

    Args:
        tree_type: Unique node-tree ``bl_idname``.
        label: Human-readable label shown in the header.
        qml_path: Path to the root ``.qml`` file.
        icon: Blender icon name.
        sidebar_category: N-panel tab name.
        menu_draw_callback: Optional Blender menu draw callback for the custom header menu.
    """
    from .qml.space.registry import register_space as _register  # noqa: WPS433

    _register(
        tree_type=tree_type,
        label=label,
        qml_path=qml_path,
        icon=icon,
        sidebar_category=sidebar_category,
        menu_draw_callback=menu_draw_callback,
    )


def register_widget_space(
    tree_type: str,
    label: str,
    widget_factory: WidgetFactory,
    *,
    icon: str = "RESTRICT_VIEW_OFF",
    sidebar_category: str = "Blender Qt",
    menu_draw_callback: Callable[[object, object], None] | None = None,
) -> None:
    """Register a widget-based custom space in a Blender node editor.

    Args:
        tree_type: Unique node-tree ``bl_idname``.
        label: Human-readable label shown in the header.
        widget_factory: ``QWidget`` subclass or callable returning one.
        icon: Blender icon name.
        sidebar_category: N-panel tab name.
        menu_draw_callback: Optional Blender menu draw callback for the custom header menu.
    """
    from .widgets.space.registry import register_space as _register  # noqa: WPS433

    _register(
        tree_type=tree_type,
        label=label,
        widget_factory=widget_factory,
        icon=icon,
        sidebar_category=sidebar_category,
        menu_draw_callback=menu_draw_callback,
    )


def unregister_space(tree_type: str) -> None:
    """Unregister a previously registered space.

    Args:
        tree_type: The tree-type identifier used at registration.
    """
    from .core.space.registration import unregister_space as _unregister  # noqa: WPS433

    _unregister(tree_type)


def registered_space_types() -> list[str]:
    """Return the currently registered custom node-space tree types."""
    from .core.space.registration import get_registered_tree_types as _get  # noqa: WPS433

    return _get()


def register_window(
    widget: QtWidgets.QWidget,
    *,
    unique: bool | None = None,
    stay_on_top: bool | None = None,
    on_close: callable | None = None,
) -> QtWidgets.QWidget:
    """Register and show a standalone managed top-level Qt window."""
    from .core.windows import register_window as _register_window  # noqa: WPS433

    return _register_window(
        widget,
        unique=unique,
        stay_on_top=stay_on_top,
        on_close=on_close,
    )


def managed_windows() -> list[QtWidgets.QWidget]:
    """Return the currently live managed windows."""
    from .core.windows import managed_windows as _managed_windows  # noqa: WPS433

    return _managed_windows()


def close_managed_windows() -> None:
    """Close every currently managed top-level Qt window."""
    from .core.windows import close_managed_windows as _close_managed_windows  # noqa: WPS433

    _close_managed_windows()


def get_qt_application() -> QtWidgets.QApplication | None:
    """Return the managed ``QApplication``, or ``None`` if not yet created.

    Returns:
        The current ``QApplication`` if Blender Qt has been initialised.
    """
    from .core.app import get_qt_application as _get  # noqa: WPS433

    return _get()


# MARK: Viewport gizmo API


def register_qml_viewport_gizmo(
    gizmo_id: str,
    qml_path: Path | str,
    *,
    space_type: str = "VIEW_3D",
    width: int = 260,
    height: int = 220,
    is_2d: bool = True,
    billboard: bool = True,
    panel_normal: tuple[float, float, float] = (0.0, -1.0, 0.0),
    panel_up: tuple[float, float, float] = (0.0, 0.0, 1.0),
    panel_world_width: float = 2.0,
    initial_position: tuple[int, int] = (100, 100),
    initial_3d_position: tuple[float, float, float] | None = None,
    use_depth_test: bool = False,
    cull_backfaces: bool = False,
) -> None:
    """Register a QML-based floating panel gizmo in a Blender editor.

    Args:
        gizmo_id: Unique identifier for this gizmo.
        qml_path: Path to the root ``.qml`` file.
        space_type: Blender editor type (``"VIEW_3D"``, ``"IMAGE_EDITOR"``, etc.).
        width: Panel width in pixels.
        height: Panel height in pixels.
        is_2d: When ``True`` draw as a screen-space overlay, otherwise anchor in world space.
        billboard: When ``True`` (default) the 3D panel always faces the
            camera.  When ``False`` it is drawn as a perspective quad.
        panel_normal: World-space facing direction (non-billboard only).
        panel_up: World-space up direction (non-billboard only).
        panel_world_width: Width in Blender units (non-billboard only).
        initial_position: Starting ``(x, y)`` in region pixels (2D mode).
        initial_3d_position: Starting world coordinate (3D mode).
        use_depth_test: When ``True`` a 3D gizmo respects the viewport depth buffer.
        cull_backfaces: When ``True`` back-facing 3D gizmo triangles are culled.
    """
    from .qml.gizmo.registry import register_viewport_gizmo as _register  # noqa: WPS433

    _register(
        gizmo_id=gizmo_id,
        qml_path=qml_path,
        space_type=space_type,
        width=width,
        height=height,
        is_2d=is_2d,
        billboard=billboard,
        panel_normal=panel_normal,
        panel_up=panel_up,
        panel_world_width=panel_world_width,
        initial_position=initial_position,
        initial_3d_position=initial_3d_position,
        use_depth_test=use_depth_test,
        cull_backfaces=cull_backfaces,
    )


def register_widget_viewport_gizmo(
    gizmo_id: str,
    widget_factory: WidgetFactory,
    *,
    space_type: str = "VIEW_3D",
    label: str = "Qt Panel",
    width: int = 260,
    height: int = 220,
    is_2d: bool = True,
    billboard: bool = True,
    panel_normal: tuple[float, float, float] = (0.0, -1.0, 0.0),
    panel_up: tuple[float, float, float] = (0.0, 0.0, 1.0),
    panel_world_width: float = 2.0,
    initial_position: tuple[int, int] = (100, 100),
    initial_3d_position: tuple[float, float, float] | None = None,
    use_depth_test: bool = False,
    cull_backfaces: bool = False,
) -> None:
    """Register a widget-based floating panel gizmo in a Blender editor."""
    from .widgets.gizmo.registry import register_viewport_gizmo as _register  # noqa: WPS433

    _register(
        gizmo_id=gizmo_id,
        widget_factory=widget_factory,
        space_type=space_type,
        label=label,
        width=width,
        height=height,
        is_2d=is_2d,
        billboard=billboard,
        panel_normal=panel_normal,
        panel_up=panel_up,
        panel_world_width=panel_world_width,
        initial_position=initial_position,
        initial_3d_position=initial_3d_position,
        use_depth_test=use_depth_test,
        cull_backfaces=cull_backfaces,
    )


def unregister_viewport_gizmo(gizmo_id: str) -> None:
    """Unregister a previously registered viewport gizmo.

    Args:
        gizmo_id: The identifier passed to :func:`register_qml_viewport_gizmo`.
    """
    from .core.gizmo.registry import unregister_viewport_gizmo as _unregister  # noqa: WPS433

    _unregister(gizmo_id)


def registered_viewport_gizmo_ids() -> list[str]:
    """Return the currently registered viewport gizmo identifiers."""
    from .core.gizmo.registry import get_registered_gizmo_ids as _get  # noqa: WPS433

    return _get()
