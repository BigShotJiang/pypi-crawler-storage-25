"""Blender Qt utils — shared utilities."""
