"""Base gizmo classes shared by QML and widget node spaces."""

from __future__ import annotations

import bpy
from mathutils import Matrix

from ..interfaces import ContextPoll, GetSpaceRuntime
from ..constants import MOUSE_BUTTONS, event_modifiers, keyboard_modifiers


class InputCaptureGizmoBase(bpy.types.Gizmo):
    """Base gizmo for capturing input in a Blender Qt custom node-editor space.

    Subclasses must set ``bl_idname`` and implement :meth:`get_runtime`.
    Set ``include_inbetween_mousemove`` class variable to control whether
    ``INBETWEEN_MOUSEMOVE`` events are forwarded.
    """

    include_inbetween_mousemove: bool = False

    def get_runtime(self, context: bpy.types.Context, *, create: bool = True):
        """Return the associated :class:`ISpaceRuntime`, or ``None``."""
        raise NotImplementedError

    def setup(self) -> None:
        self._active_button: str | None = None
        self._last_local: tuple[int, int] = (0, 0)
        self._last_modifiers: dict[str, bool] = {"shift": False, "ctrl": False, "alt": False}

    def _sync_shape(self, context: bpy.types.Context) -> None:
        region = getattr(context, "region", None)
        if region is None:
            return
        half_width = max(region.width * 0.5, 1.0)
        half_height = max(region.height * 0.5, 1.0)
        self.matrix_basis = Matrix(
            (
                (half_width, 0.0, 0.0, half_width),
                (0.0, half_height, 0.0, half_height),
                (0.0, 0.0, 1.0, 0.0),
                (0.0, 0.0, 0.0, 1.0),
            )
        )
        self.color = (0.0, 0.0, 0.0)
        self.alpha = 0.0
        self.color_highlight = (0.0, 0.0, 0.0)
        self.alpha_highlight = 0.0

    def draw(self, context: bpy.types.Context) -> None:
        pass

    def draw_select(self, context: bpy.types.Context, select_id: int) -> None:
        self._sync_shape(context)
        self.draw_preset_box(self.matrix_basis, select_id=select_id)

    def test_select(self, context: bpy.types.Context, location: tuple[int, int]) -> int:
        runtime = self.get_runtime(context)
        if runtime is None:
            return -1
        local = runtime.region_point(context, location[0], location[1])
        return 0 if runtime.contains(local[0], local[1]) else -1

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        runtime = self.get_runtime(context)
        if runtime is None:
            return {"CANCELLED"}
        self._active_button = event.type
        self._last_local = runtime.event_region_point(context, event)
        self._last_modifiers = {
            "shift": getattr(event, "shift", False),
            "ctrl": getattr(event, "ctrl", False),
            "alt": getattr(event, "alt", False),
        }
        runtime.handle_mouse_move(context, event)
        runtime.handle_mouse_press(context, event)
        context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def modal(self, context: bpy.types.Context, event: bpy.types.Event, tweak: set[str]) -> set[str]:
        runtime = self.get_runtime(context)
        if runtime is None:
            return {"CANCELLED"}
        local = runtime.event_region_point(context, event)
        self._last_local = local
        self._last_modifiers = {
            "shift": getattr(event, "shift", False),
            "ctrl": getattr(event, "ctrl", False),
            "alt": getattr(event, "alt", False),
        }
        if event.type == "ESC":
            self._active_button = None
            return {"CANCELLED"}
        if event.type == "WINDOW_DEACTIVATE":
            if self._active_button is not None:
                runtime.schedule_mouse_release(
                    local,
                    self._active_button,
                    keyboard_modifiers(**self._last_modifiers),
                )
                self._active_button = None
                context.area.tag_redraw()
            return {"FINISHED"}
        if event.type in MOUSE_BUTTONS and event.value == "RELEASE":
            runtime.handle_mouse_release(context, event)
            self._active_button = None
            context.area.tag_redraw()
            return {"FINISHED"}
        if event.type == "MOUSEMOVE" or (self.include_inbetween_mousemove and event.type == "INBETWEEN_MOUSEMOVE"):
            if not runtime.contains(local[0], local[1]):
                if self._active_button is not None:
                    synthetic_release = type(
                        "SyntheticRelease",
                        (),
                        {
                            "type": self._active_button,
                            "mouse_region_x": local[0],
                            "mouse_region_y": local[1],
                            "shift": self._last_modifiers["shift"],
                            "ctrl": self._last_modifiers["ctrl"],
                            "alt": self._last_modifiers["alt"],
                        },
                    )
                    runtime.handle_mouse_release(context, synthetic_release)
                    self._active_button = None
                return {"FINISHED"}
            runtime.handle_mouse_move(context, event)
            context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def exit(self, context: bpy.types.Context, cancel: bool) -> None:
        runtime = self.get_runtime(context, create=False)
        if runtime is None or self._active_button is None:
            return
        runtime.schedule_mouse_release(
            self._last_local,
            self._active_button,
            keyboard_modifiers(**self._last_modifiers),
        )
        self._active_button = None
        context.area.tag_redraw()


class InputCaptureGizmoGroupBase(bpy.types.GizmoGroup):
    """Base gizmo group for Blender Qt custom node-editor spaces.

    Subclasses must set ``bl_idname``, ``bl_label`` and provide
    :attr:`gizmo_type` (the ``bl_idname`` of the companion gizmo).
    """

    bl_space_type = "NODE_EDITOR"
    bl_region_type = "WINDOW"
    bl_options = {"PERSISTENT", "SELECT", "SHOW_MODAL_ALL"}
    gizmo_type: str = ""  # bl_idname of the InputCaptureGizmoBase subclass

    def get_runtime(self, context: bpy.types.Context):
        """Return the associated :class:`ISpaceRuntime`, or ``None``."""
        raise NotImplementedError

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return True

    def setup(self, context: bpy.types.Context) -> None:
        self.capture_gizmo = self.gizmos.new(self.gizmo_type)
        self.capture_gizmo.use_select_background = True

    def refresh(self, context: bpy.types.Context) -> None:
        self.get_runtime(context)

    def draw_prepare(self, context: bpy.types.Context) -> None:
        runtime = self.get_runtime(context)
        if runtime is not None:
            runtime.sync_region(context)
        self.capture_gizmo._sync_shape(context)
