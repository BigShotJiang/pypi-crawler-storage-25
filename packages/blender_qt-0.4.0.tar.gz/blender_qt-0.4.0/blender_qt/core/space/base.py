"""Node-editor space plumbing — tree helpers, header override, specs.

This module contains the low-level Blender integration for hijacking a node
editor area into a custom space: dummy node-trees, space detection, header
draw replacement, and redraw tagging.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable

import bpy

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class CustomSpaceSpec:
    tree_type: str
    tree_label: str
    tree_icon: str
    tree_name: str
    sidebar_category: str
    sidebar_label: str
    window_title: str
    reload_operator: str
    create_graph_operator: str
    menu_draw_callback: Callable[[bpy.types.Menu, bpy.types.Context], None] | None = None
    header_menu_idname: str = ""
    show_sidebar: bool = False


class CustomNodeTreeBase:
    bl_icon = "NODETREE"
    bl_use_group_interface = False
    color_tag = "NONE"


def is_custom_space(context: bpy.types.Context, tree_type: str) -> bool:
    space = getattr(context, "space_data", None)
    return bool(space and space.type == "NODE_EDITOR" and getattr(space, "tree_type", "") == tree_type)


def get_current_space_tree(
    context: bpy.types.Context,
    tree_type: str,
) -> bpy.types.NodeTree | None:
    space = getattr(context, "space_data", None)
    if space is None or space.type != "NODE_EDITOR":
        return None
    tree = getattr(space, "edit_tree", None) or getattr(space, "node_tree", None)
    if tree is None or getattr(tree, "bl_idname", "") != tree_type:
        return None
    return tree


def configure_custom_space(
    context: bpy.types.Context,
    tree_type: str,
) -> bpy.types.SpaceNodeEditor | None:
    space = getattr(context, "space_data", None)
    if space is None or space.type != "NODE_EDITOR" or getattr(space, "tree_type", "") != tree_type:
        return None
    if not space.pin:
        space.pin = True
    if space.show_region_toolbar:
        space.show_region_toolbar = False
    if space.show_region_ui:
        space.show_region_ui = False
    if space.show_region_asset_shelf:
        space.show_region_asset_shelf = False
    if space.show_annotation:
        space.show_annotation = False
    return space


def find_space_tree(tree_type: str) -> bpy.types.NodeTree | None:
    for tree in bpy.data.node_groups:
        if getattr(tree, "bl_idname", "") == tree_type:
            return tree
    return None


def ensure_space_tree(
    context: bpy.types.Context,
    spec: CustomSpaceSpec,
) -> bpy.types.NodeTree | None:
    space = configure_custom_space(context, spec.tree_type)
    if space is None:
        return None
    tree = get_current_space_tree(context, spec.tree_type)
    if tree is None:
        tree = find_space_tree(spec.tree_type)
    if tree is None:
        tree = bpy.data.node_groups.new(spec.tree_name, spec.tree_type)
        tree.use_fake_user = True
    if getattr(space, "node_tree", None) != tree:
        space.node_tree = tree
    return tree


def tag_redraw_custom_spaces(tree_type: str) -> None:
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type != "NODE_EDITOR":
                continue
            for space in area.spaces:
                if getattr(space, "tree_type", "") == tree_type:
                    area.tag_redraw()
                    break


_CUSTOM_HEADER_SPECS: dict[str, CustomSpaceSpec] = {}
_ORIGINAL_NODE_HEADER_DRAW: type | None = None


def draw_custom_space_header(
    layout: bpy.types.UILayout,
    context: bpy.types.Context,
    spec: CustomSpaceSpec,
) -> None:
    layout.template_header()
    if spec.header_menu_idname:
        layout.separator()
        layout.menu(spec.header_menu_idname, text=spec.tree_label, icon=spec.tree_icon)


def _draw_node_header(self: bpy.types.Header, context: bpy.types.Context) -> None:
    space = getattr(context, "space_data", None)
    tree_type = getattr(space, "tree_type", "") if space and space.type == "NODE_EDITOR" else ""
    spec = _CUSTOM_HEADER_SPECS.get(tree_type)
    if spec is None:
        if _ORIGINAL_NODE_HEADER_DRAW is not None:
            _ORIGINAL_NODE_HEADER_DRAW(self, context)
        return
    draw_custom_space_header(self.layout, context, spec)


def register_custom_header(spec: CustomSpaceSpec) -> None:
    global _ORIGINAL_NODE_HEADER_DRAW
    _CUSTOM_HEADER_SPECS[spec.tree_type] = spec
    if _ORIGINAL_NODE_HEADER_DRAW is None:
        _ORIGINAL_NODE_HEADER_DRAW = bpy.types.NODE_HT_header.draw
        bpy.types.NODE_HT_header.draw = _draw_node_header


def unregister_custom_header(tree_type: str) -> None:
    global _ORIGINAL_NODE_HEADER_DRAW
    _CUSTOM_HEADER_SPECS.pop(tree_type, None)
    if not _CUSTOM_HEADER_SPECS and _ORIGINAL_NODE_HEADER_DRAW is not None:
        bpy.types.NODE_HT_header.draw = _ORIGINAL_NODE_HEADER_DRAW
        _ORIGINAL_NODE_HEADER_DRAW = None
