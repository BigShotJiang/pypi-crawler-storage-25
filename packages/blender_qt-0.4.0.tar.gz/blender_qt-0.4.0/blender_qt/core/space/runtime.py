"""Base runtime shared by QML and widget space implementations."""

from __future__ import annotations

import logging

import bpy
from mathutils import Vector

from ..interfaces import IOffscreenRenderer
from ..config import log_message
from ..constants import MOUSE_BUTTONS, KeyboardModifier, MouseButton, LogCategory, event_modifiers

from ...render.gpu import blit_qimage

LOGGER = logging.getLogger(__name__)


class SpaceRuntimeBase:
    renderer: IOffscreenRenderer | None
    tree_type: str

    def __init__(self, area_pointer: int | None) -> None:
        self.area_pointer: int | None = area_pointer
        self.draw_area: tuple[int, int, int, int] = (0, 0, 1, 1)
        self.renderer = None
        self.tree_type = ""

    def region_point(self, context: bpy.types.Context, screen_x: int, screen_y: int) -> tuple[int, int]:
        region = getattr(context, "region", None)
        if region is None:
            return int(screen_x), int(screen_y)
        local_x = int(screen_x)
        local_y = int(screen_y)
        if local_x < 0 or local_x > region.width or local_y < 0 or local_y > region.height:
            local_x = int(screen_x - region.x)
            local_y = int(screen_y - region.y)
        return local_x, local_y

    def event_region_point(self, context: bpy.types.Context, event: bpy.types.Event) -> tuple[int, int]:
        if hasattr(event, "mouse_region_x") and hasattr(event, "mouse_region_y"):
            return self.region_point(context, int(event.mouse_region_x), int(event.mouse_region_y))
        return self.region_point(context, event.mouse_x, event.mouse_y)

    def sync_region(self, context: bpy.types.Context) -> None:
        region = getattr(context, "region", None)
        region_width = region.width if region else 1
        region_height = region.height if region else 1
        self.draw_area = (0, 0, region_width, region_height)
        if self.renderer is not None:
            self.renderer.set_size(region_width, region_height)

    def contains(self, local_x: int, local_y: int) -> bool:
        draw_x, draw_y, draw_width, draw_height = self.draw_area
        return draw_x <= local_x < draw_x + draw_width and draw_y <= local_y < draw_y + draw_height

    def to_surface_point(self, logical_position: tuple[int, int]) -> Vector:
        if self.renderer is None:
            return Vector((0.0, 0.0, 0.0))
        renderer_width = self.renderer.window_size.width()
        renderer_height = self.renderer.window_size.height()
        draw_width = max(1, self.draw_area[2])
        draw_height = max(1, self.draw_area[3])
        scale_x = renderer_width / draw_width
        scale_y = renderer_height / draw_height
        qt_x = int(logical_position[0] * scale_x)
        qt_y = int((draw_height - 1 - logical_position[1]) * scale_y)
        qt_x = max(0, min(renderer_width - 1, qt_x))
        qt_y = max(0, min(renderer_height - 1, qt_y))
        return Vector((float(qt_x), float(qt_y), 0.0))

    @staticmethod
    def event_modifiers(event: bpy.types.Event) -> KeyboardModifier:
        return event_modifiers(event)

    def has_keyboard_focus(self) -> bool:
        if self.renderer is None:
            return False
        return self.renderer.has_keyboard_focus()

    def handle_mouse_press(self, context: bpy.types.Context, event: bpy.types.Event) -> None:
        if self.renderer is None:
            return
        self.sync_region(context)
        logical_position = self.event_region_point(context, event)
        button = MOUSE_BUTTONS.get(event.type, MouseButton.LEFT)
        log_message(
            LOGGER,
            LogCategory.MOUSE,
            logging.INFO,
            "Space mouse press %s at %s for %s",
            event.type,
            logical_position,
            self.tree_type,
        )
        self.renderer.send_mouse_press(self.to_surface_point(logical_position), button, self.event_modifiers(event))

    def handle_mouse_release(self, context: bpy.types.Context, event: bpy.types.Event) -> None:
        if self.renderer is None:
            return
        self.sync_region(context)
        logical_position = self.event_region_point(context, event)
        button = MOUSE_BUTTONS.get(event.type, MouseButton.LEFT)
        log_message(
            LOGGER,
            LogCategory.MOUSE,
            logging.INFO,
            "Space mouse release %s at %s for %s",
            event.type,
            logical_position,
            self.tree_type,
        )
        self.renderer.send_mouse_release(self.to_surface_point(logical_position), button, self.event_modifiers(event))

    def handle_mouse_move(self, context: bpy.types.Context, event: bpy.types.Event) -> None:
        if self.renderer is None:
            return
        self.sync_region(context)
        logical_position = self.event_region_point(context, event)
        log_message(
            LOGGER,
            LogCategory.MOUSE,
            logging.INFO,
            "Space mouse move at %s for %s",
            logical_position,
            self.tree_type,
        )
        self.renderer.send_mouse_move(self.to_surface_point(logical_position), self.event_modifiers(event))

    def handle_key_event(self, context: bpy.types.Context, event: bpy.types.Event) -> bool:
        if self.renderer is None:
            return False
        self.sync_region(context)
        unicode_text = getattr(event, "unicode", "") or ""
        log_message(
            LOGGER,
            LogCategory.KEYBOARD,
            logging.INFO,
            "Space key %s/%s for %s",
            event.type,
            event.value,
            self.tree_type,
        )
        return self.renderer.send_key(event.type, event.value, unicode_text, self.event_modifiers(event))

    def schedule_mouse_release(
        self,
        logical_position: tuple[int, int],
        event_type: str,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        if self.renderer is None:
            return
        button = MOUSE_BUTTONS.get(event_type, MouseButton.LEFT)
        surface_point = self.to_surface_point(logical_position)
        captured_renderer = self.renderer

        def _dispatch_release() -> None:
            captured_renderer.send_mouse_release(surface_point, button, modifiers)

        bpy.app.timers.register(_dispatch_release, first_interval=0.0)

    def draw(self, context: bpy.types.Context) -> None:
        if self.renderer is None:
            return
        self.sync_region(context)
        self.renderer.mark_visible()
        image = self.renderer.render()
        if image.isNull():
            return
        blit_qimage(image, self.draw_area)

    def cleanup(self) -> None:
        self.renderer = None

    def reload_surface(self) -> None:
        pass
