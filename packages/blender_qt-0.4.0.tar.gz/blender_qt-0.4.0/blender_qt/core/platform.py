"""Platform-specific helpers for native Blender window integration.

Windows
    `SetWindowPos(HWND_TOP)` to re-stack Qt windows above Blender
    each time Blender's window activates, driven by a WinEvent hook.

Linux (X11)
    `XSetTransientForHint` to declare Qt windows as transient for
    Blender's top-level X window.  The window manager keeps them above
    automatically.  A `QTimer`-based poll detects focus changes.

macOS (Cocoa)
    `NSWindow.addChildWindow:ordered:` to parent Qt windows under
    Blender's `NSWindow`.  A `QTimer`-based poll detects focus
    changes.

Implementation lives in `blender_qt._internal.platform` modules; this
module exposes the cross-platform public API.
"""

from __future__ import annotations

import logging
import sys
from typing import Callable

from PySide6 import QtCore, QtWidgets

LOGGER = logging.getLogger(__name__)

_IS_WINDOWS = sys.platform == "win32"
_IS_MACOS = sys.platform == "darwin"
_IS_LINUX = sys.platform == "linux"

_foreground_hook: int | QtCore.QTimer | None = None
_on_blender_activated: Callable[[], None] | None = None
_last_poll_foreground: bool = False


def bind_widget_to_blender_host(widget: QtWidgets.QWidget) -> bool:
    """Keep *widget* above the Blender window.

    Windows
        `SetWindowPos(HWND_TOP)` each time Blender activates.
    Linux (X11)
        `XSetTransientForHint` (one-time, WM handles stacking).
    macOS
        `NSWindow.addChildWindow:ordered:` (one-time).
    """
    if _IS_WINDOWS:
        from .._internal.platform.windows import bind_widget

        return bind_widget(widget)
    if _IS_LINUX:
        from .._internal.platform.linux import bind_widget

        return bind_widget(widget)
    if _IS_MACOS:
        from .._internal.platform.macos import bind_widget

        return bind_widget(widget)
    return False


def install_foreground_hook(on_blender_activated: Callable[[], None]) -> None:
    """Fire *on_blender_activated* when Blender's window gains focus.

    Windows uses a native `WinEventHook`; Linux and macOS use a
    `QTimer` that polls `process_has_foreground_window`.
    """
    if _IS_WINDOWS:
        from .._internal.platform.windows import install_foreground_hook as _install

        _install(on_blender_activated)
    elif _IS_LINUX or _IS_MACOS:
        _install_foreground_hook_poll(on_blender_activated)


def uninstall_foreground_hook() -> None:
    """Remove the hook installed by `install_foreground_hook`."""
    global _foreground_hook, _on_blender_activated
    if _IS_WINDOWS:
        from .._internal.platform.windows import uninstall_foreground_hook as _uninstall

        _uninstall()
        return
    if isinstance(_foreground_hook, QtCore.QTimer):
        _foreground_hook.stop()
        _foreground_hook.deleteLater()
    _foreground_hook = None
    _on_blender_activated = None


def process_has_foreground_window() -> bool:
    """Return `True` when a window owned by this process has focus."""
    if _IS_WINDOWS:
        from .._internal.platform.windows import has_foreground

        return has_foreground()
    if _IS_LINUX:
        from .._internal.platform.linux import has_foreground

        return has_foreground()
    if _IS_MACOS:
        from .._internal.platform.macos import has_foreground

        return has_foreground()
    return True


def reset_modifier_state() -> None:
    """Force-release common modifier keys after Blender regains focus."""
    if _IS_WINDOWS:
        from .._internal.platform.windows import reset_modifier_state as _reset

        _reset()


def get_main_blender_window_handle() -> int | None:
    """Return the native window handle for Blender's main top-level window."""
    if _IS_WINDOWS:
        from .._internal.platform.windows import find_blender_window

        return find_blender_window()
    if _IS_LINUX:
        from .._internal.platform.linux import find_blender_window

        return find_blender_window()
    if _IS_MACOS:
        from .._internal.platform.macos import find_blender_window

        return find_blender_window()
    return None


def _install_foreground_hook_poll(on_blender_activated: Callable[[], None]) -> None:
    """Use a `QTimer` to poll `process_has_foreground_window`."""
    global _foreground_hook, _on_blender_activated, _last_poll_foreground
    if _foreground_hook is not None:
        return
    _on_blender_activated = on_blender_activated
    _last_poll_foreground = process_has_foreground_window()

    timer = QtCore.QTimer()
    timer.setInterval(250)

    def _poll():
        global _last_poll_foreground
        current = process_has_foreground_window()
        if current and not _last_poll_foreground and _on_blender_activated:
            _on_blender_activated()
        _last_poll_foreground = current

    timer.timeout.connect(_poll)
    timer.start()
    _foreground_hook = timer
