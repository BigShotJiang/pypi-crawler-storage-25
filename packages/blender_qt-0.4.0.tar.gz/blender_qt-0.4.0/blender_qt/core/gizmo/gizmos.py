"""Base gizmo and gizmo-group classes shared by viewport backends."""

from __future__ import annotations

import bpy
from mathutils import Vector, Matrix

from ..._internal.viewport_gizmo import set_focused_gizmo
from ..interfaces import GetViewportRuntime
from ..constants import MOUSE_BUTTONS, MouseButton, keyboard_modifiers
from .operators import ensure_capture_keys_running


class PanelGizmoBase(bpy.types.Gizmo):
    """Base gizmo for Blender Qt viewport panels.

    Subclasses must set ``bl_idname`` and define :meth:`get_runtime`.
    """

    def get_runtime(self):
        """Return the associated :class:`IViewportRuntime`, or ``None``."""
        raise NotImplementedError

    def setup(self) -> None:
        self._dragging = False
        self._drag_offset = (0, 0)
        self._active_button: str | None = None
        self._want_capture = False
        self._last_rx = 0
        self._last_ry = 0
        self._last_modifiers = {"shift": False, "ctrl": False, "alt": False}

    def draw(self, context: bpy.types.Context) -> None:
        pass

    def draw_select(self, context: bpy.types.Context, select_id: int) -> None:
        runtime = self.get_runtime()
        if runtime is None:
            return

        x, y, w, h = runtime.draw_area
        cx = x + w * 0.5
        cy = y + h * 0.5
        hw = max(w * 0.5, 1.0)
        hh = max(h * 0.5, 1.0)
        self.matrix_basis = Matrix(
            ((hw, 0.0, 0.0, cx), (0.0, hh, 0.0, cy), (0.0, 0.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0))
        )
        self.color = (0.0, 0.0, 0.0)
        self.alpha = 0.0
        self.color_highlight = (0.0, 0.0, 0.0)
        self.alpha_highlight = 0.0
        self.draw_preset_box(self.matrix_basis, select_id=select_id)

    def test_select(self, context: bpy.types.Context, location: tuple[int, int]) -> int:
        runtime = self.get_runtime()
        if runtime is None:
            return -1
        screen_position = Vector((float(location[0]), float(location[1]), 0.0))
        return 0 if runtime.contains(screen_position) else -1

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        runtime = self.get_runtime()
        if runtime is None:
            return {"CANCELLED"}

        rx = int(event.mouse_region_x)
        ry = int(event.mouse_region_y)
        self._last_rx = rx
        self._last_ry = ry
        self._last_modifiers = {
            "shift": getattr(event, "shift", False),
            "ctrl": getattr(event, "ctrl", False),
            "alt": getattr(event, "alt", False),
        }
        screen_position = Vector((float(rx), float(ry), 0.0))
        if runtime.in_drag_handle(screen_position):
            set_focused_gizmo(None)
            self._dragging = True
            self._drag_offset = (rx - runtime.screen_x, ry - runtime.screen_y)
            return {"RUNNING_MODAL"}

        set_focused_gizmo(None)
        self._dragging = False
        self._want_capture = True
        self._active_button = event.type
        runtime.handle_mouse_move(screen_position, event)
        runtime.handle_mouse_press(screen_position, event)
        context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def modal(self, context: bpy.types.Context, event: bpy.types.Event, tweak: set[str]) -> set[str]:
        runtime = self.get_runtime()
        if runtime is None:
            return {"CANCELLED"}
        rx = int(event.mouse_region_x)
        ry = int(event.mouse_region_y)
        self._last_rx = rx
        self._last_ry = ry
        self._last_modifiers = {
            "shift": getattr(event, "shift", False),
            "ctrl": getattr(event, "ctrl", False),
            "alt": getattr(event, "alt", False),
        }
        screen_position = Vector((float(rx), float(ry), 0.0))
        if self._dragging:
            if event.type in ("MOUSEMOVE", "INBETWEEN_MOUSEMOVE"):
                if not runtime.is_2d:
                    runtime.drag_3d(context, screen_position, self._drag_offset)
                else:
                    runtime.screen_x = rx - self._drag_offset[0]
                    runtime.screen_y = ry - self._drag_offset[1]
                context.area.tag_redraw()
                return {"RUNNING_MODAL"}
            if event.type in MOUSE_BUTTONS and event.value == "RELEASE":
                self._dragging = False
                context.area.tag_redraw()
                return {"FINISHED"}
            if event.type == "ESC":
                self._dragging = False
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        if event.type == "ESC":
            self._active_button = None
            return {"CANCELLED"}
        if event.type == "WINDOW_DEACTIVATE":
            if self._active_button is not None:
                runtime.handle_mouse_release(screen_position, event)
                self._active_button = None
                context.area.tag_redraw()
            return {"FINISHED"}
        if event.type in MOUSE_BUTTONS and event.value == "RELEASE":
            runtime.handle_mouse_release(screen_position, event)
            self._active_button = None
            self._want_capture = True
            context.area.tag_redraw()
            return {"FINISHED"}
        if event.type in ("MOUSEMOVE", "INBETWEEN_MOUSEMOVE"):
            if not runtime.contains(screen_position):
                if self._active_button is not None:
                    synthetic = type(
                        "SyntheticRelease",
                        (),
                        {
                            "type": self._active_button,
                            "mouse_region_x": rx,
                            "mouse_region_y": ry,
                            "shift": self._last_modifiers["shift"],
                            "ctrl": self._last_modifiers["ctrl"],
                            "alt": self._last_modifiers["alt"],
                        },
                    )
                    runtime.handle_mouse_release(screen_position, synthetic)
                    self._active_button = None
                return {"FINISHED"}
            runtime.handle_mouse_move(screen_position, event)
            context.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def exit(self, context: bpy.types.Context, cancel: bool) -> None:
        runtime = self.get_runtime()
        if runtime is None or self._dragging:
            self._dragging = False
            self._want_capture = False
            return
        if self._active_button is not None and runtime.renderer is not None:
            surface_point = runtime.to_surface_point(Vector((float(self._last_rx), float(self._last_ry), 0.0)))
            button = MOUSE_BUTTONS.get(self._active_button, MouseButton.LEFT)
            mods = keyboard_modifiers(**self._last_modifiers)
            runtime.renderer.send_mouse_release(surface_point, button, mods)
        self._active_button = None
        self._dragging = False
        if self._want_capture:
            self._want_capture = False
            gizmo_id = self._get_gizmo_id()
            if runtime.has_keyboard_focus():
                set_focused_gizmo(gizmo_id)
                ensure_capture_keys_running()
            else:
                set_focused_gizmo(None)
        context.area.tag_redraw()

    def _get_gizmo_id(self) -> str:
        """Return the gizmo registration ID. Override if not derivable from ``bl_idname``."""
        raise NotImplementedError


class PanelGizmoGroupBase(bpy.types.GizmoGroup):
    """Base gizmo group for Blender Qt viewport panels.

    Subclasses must set ``bl_idname``, ``bl_label``, ``bl_space_type`` and
    provide :attr:`gizmo_type` (the ``bl_idname`` of the companion :class:`PanelGizmoBase`).
    """

    bl_region_type = "WINDOW"
    bl_options = {"PERSISTENT", "SELECT", "SHOW_MODAL_ALL"}
    gizmo_type: str = ""  # bl_idname of the PanelGizmoBase subclass

    def get_runtime(self):
        """Return the associated :class:`IViewportRuntime`, or ``None``."""
        raise NotImplementedError

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return True

    def setup(self, context: bpy.types.Context) -> None:
        self.panel_gizmo = self.gizmos.new(self.gizmo_type)
        self.panel_gizmo.use_select_background = True

    def draw_prepare(self, context: bpy.types.Context) -> None:
        runtime = self.get_runtime()
        if runtime is not None:
            runtime.update_screen_position(context)
