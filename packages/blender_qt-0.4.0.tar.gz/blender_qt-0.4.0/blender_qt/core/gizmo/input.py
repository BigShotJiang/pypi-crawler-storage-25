"""Shared viewport gizmo keymap helpers."""

from __future__ import annotations

import logging
from typing import Any

import bpy

from ..constants import KEY_TYPES
from .operators import BQT_OT_forward_key

LOGGER = logging.getLogger(__name__)

_GIZMO_KEYMAPS: dict[str, list[tuple[Any, Any]]] = {}
_KEYMAP_NAMES: dict[str, str] = {
    "VIEW_3D": "3D View",
    "IMAGE_EDITOR": "Image",
    "NODE_EDITOR": "Node Editor",
    "CLIP_EDITOR": "Clip",
    "SEQUENCE_EDITOR": "Sequencer",
}


def register_gizmo_keymaps(space_type: str, gizmo_id: str) -> None:
    """Register keymaps for the shared forward key operator in *space_type*."""
    window_manager = bpy.context.window_manager
    keyconfig = window_manager.keyconfigs.addon
    if keyconfig is None:
        LOGGER.warning("Addon keyconfig not available; gizmo keymaps not registered.")
        return
    km_name = _KEYMAP_NAMES.get(space_type, "Window")
    keymap = keyconfig.keymaps.new(name=km_name, space_type=space_type, region_type="WINDOW")
    items: list[tuple[Any, Any]] = []
    for key_type in KEY_TYPES:
        for value in ("PRESS", "RELEASE"):
            keymap_item = keymap.keymap_items.new(BQT_OT_forward_key.bl_idname, key_type, value, any=True, head=True)
            keymap_item.properties.event_type = key_type
            items.append((keymap, keymap_item))
    keymap_item = keymap.keymap_items.new("blender_qt_gizmo.focus_check", "LEFTMOUSE", "PRESS", any=True, head=True)
    items.append((keymap, keymap_item))
    _GIZMO_KEYMAPS[gizmo_id] = items


def unregister_gizmo_keymaps(gizmo_id: str) -> None:
    items = _GIZMO_KEYMAPS.pop(gizmo_id, [])
    for keymap, keymap_item in items:
        try:
            keymap.keymap_items.remove(keymap_item)
        except ReferenceError:
            LOGGER.debug("Gizmo keymap item already removed.", exc_info=True)
