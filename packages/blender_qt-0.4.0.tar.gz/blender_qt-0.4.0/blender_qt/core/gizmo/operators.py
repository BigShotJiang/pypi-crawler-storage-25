"""Operator definitions shared by viewport gizmo backends."""

from __future__ import annotations

import bpy
from bpy.props import StringProperty
from mathutils import Vector

from ..._internal.viewport_gizmo import get_focused_gizmo_id, get_runtime, iter_runtimes, set_focused_gizmo
from ..interfaces import GetViewportRuntime
from ..constants import KEY_TYPES, MOUSE_BUTTONS


class BQT_OT_focus_check(bpy.types.Operator):
    bl_idname = "blender_qt_gizmo.focus_check"
    bl_label = "Blender Qt Gizmo Focus Check"
    bl_options = {"INTERNAL"}

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        if get_focused_gizmo_id() is None:
            return {"PASS_THROUGH"}
        screen_position = Vector((float(event.mouse_region_x), float(event.mouse_region_y), 0.0))
        for runtime in iter_runtimes():
            if runtime.contains(screen_position):
                return {"PASS_THROUGH"}
        set_focused_gizmo(None)
        return {"PASS_THROUGH"}


class BQT_OT_capture_keys(bpy.types.Operator):
    bl_idname = "blender_qt_gizmo.capture_keys"
    bl_label = "Blender Qt Gizmo Key Capture"
    bl_options = {"INTERNAL"}
    _is_running: bool = False
    _start_pending: bool = False

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        if BQT_OT_capture_keys._is_running:
            return {"CANCELLED"}
        BQT_OT_capture_keys._start_pending = False
        BQT_OT_capture_keys._is_running = True
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        runtimes = tuple(iter_runtimes())
        if not runtimes:
            BQT_OT_capture_keys._is_running = False
            return {"FINISHED"}

        if event.type in MOUSE_BUTTONS and event.value == "PRESS":
            screen_position = Vector((float(event.mouse_region_x), float(event.mouse_region_y), 0.0))
            if not any(runtime.contains(screen_position) for runtime in runtimes):
                if get_focused_gizmo_id() is not None:
                    set_focused_gizmo(None)
                    if context.area is not None:
                        context.area.tag_redraw()
            return {"PASS_THROUGH"}

        gizmo_id = get_focused_gizmo_id()
        if gizmo_id is None:
            BQT_OT_capture_keys._is_running = False
            return {"FINISHED"}
        runtime = get_runtime(gizmo_id)
        if runtime is None:
            set_focused_gizmo(None)
            BQT_OT_capture_keys._is_running = False
            return {"FINISHED"}
        if not runtime.has_keyboard_focus():
            set_focused_gizmo(None)
            if context.area is not None:
                context.area.tag_redraw()
            BQT_OT_capture_keys._is_running = False
            return {"FINISHED"}
        if event.type in KEY_TYPES:
            if runtime.handle_key_event(event):
                if context.area:
                    context.area.tag_redraw()
                return {"RUNNING_MODAL"}
            return {"PASS_THROUGH"}
        return {"PASS_THROUGH"}


def ensure_capture_keys_running() -> None:
    if BQT_OT_capture_keys._is_running or BQT_OT_capture_keys._start_pending:
        return
    BQT_OT_capture_keys._start_pending = True

    def _start() -> float | None:
        if BQT_OT_capture_keys._is_running:
            BQT_OT_capture_keys._start_pending = False
            return None
        if not tuple(iter_runtimes()):
            BQT_OT_capture_keys._start_pending = False
            return None
        try:
            bpy.ops.blender_qt_gizmo.capture_keys("INVOKE_DEFAULT")
        except Exception:
            return 0.1
        BQT_OT_capture_keys._start_pending = False
        return None

    bpy.app.timers.register(_start, first_interval=0.0)


class BQT_OT_forward_key(bpy.types.Operator):
    """Single shared forward-key operator reused by all Qt gizmos."""

    bl_idname = "blender_qt_gizmo.forward_key"
    bl_label = "Blender Qt Gizmo Forward Key"
    bl_options = {"INTERNAL"}

    event_type: StringProperty(options={"SKIP_SAVE"})  # type: ignore[valid-type]

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        gizmo_id = get_focused_gizmo_id()
        return gizmo_id is not None and get_runtime(gizmo_id) is not None

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        gizmo_id = get_focused_gizmo_id()
        if gizmo_id is None:
            return {"PASS_THROUGH"}
        runtime = get_runtime(gizmo_id)
        if runtime is None:
            return {"CANCELLED"}
        runtime.handle_key_event(event)
        if context.area is not None:
            context.area.tag_redraw()
        return {"FINISHED"}
