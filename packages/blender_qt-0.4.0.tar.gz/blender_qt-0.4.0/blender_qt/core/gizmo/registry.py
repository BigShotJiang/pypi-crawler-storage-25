"""Shared viewport gizmo registration plumbing used by backend packages."""

from __future__ import annotations

import logging
from typing import Callable

import bpy

from ..interfaces import IViewportRuntime
from ..config import log_message
from ..constants import LogCategory
from ..._internal.viewport_gizmo import get_runtime, remove_runtime, set_runtime
from .gizmos import PanelGizmoBase, PanelGizmoGroupBase
from .input import register_gizmo_keymaps, unregister_gizmo_keymaps
from .operators import BQT_OT_capture_keys, BQT_OT_focus_check, BQT_OT_forward_key, ensure_capture_keys_running

LOGGER = logging.getLogger(__name__)

_REGISTERED_GIZMOS: dict[str, "_GizmoRegistration"] = {}
_CAPTURE_OP_REGISTERED = False


class _GizmoRegistration:
    __slots__ = ("gizmo_id", "blender_classes", "space_type", "draw_handler")

    def __init__(
        self, gizmo_id: str, blender_classes: list[type], space_type: str, draw_handler: object | None = None
    ) -> None:
        self.gizmo_id = gizmo_id
        self.blender_classes = blender_classes
        self.space_type = space_type
        self.draw_handler = draw_handler


def get_registered_gizmo_ids() -> list[str]:
    return list(_REGISTERED_GIZMOS.keys())


def is_gizmo_registered(gizmo_id: str) -> bool:
    """Return whether *gizmo_id* is currently registered."""
    return gizmo_id in _REGISTERED_GIZMOS


def _draw_handler_type(space_type: str) -> type | None:
    mapping = {
        "VIEW_3D": "SpaceView3D",
        "IMAGE_EDITOR": "SpaceImageEditor",
        "NODE_EDITOR": "SpaceNodeEditor",
        "CLIP_EDITOR": "SpaceClipEditor",
        "SEQUENCE_EDITOR": "SpaceSequenceEditor",
    }
    attr_name = mapping.get(space_type)
    return None if attr_name is None else getattr(bpy.types, attr_name, None)


def _install_draw_handler(space_type: str, get_runtime_fn, draw_stage: str = "POST_PIXEL") -> object | None:
    space_cls = _draw_handler_type(space_type)
    if space_cls is None:
        LOGGER.warning("No draw handler class for space type %r", space_type)
        return None

    def _draw_callback():
        runtime = get_runtime_fn()
        if runtime is not None:
            runtime.draw(bpy.context)

    return space_cls.draw_handler_add(_draw_callback, (), "WINDOW", draw_stage)


def _remove_draw_handler(space_type: str, handler: object) -> None:
    space_cls = _draw_handler_type(space_type)
    if space_cls is not None and handler is not None:
        space_cls.draw_handler_remove(handler, "WINDOW")


def ensure_global_operators() -> None:
    global _CAPTURE_OP_REGISTERED
    if _CAPTURE_OP_REGISTERED:
        return
    for operator in (BQT_OT_focus_check, BQT_OT_capture_keys, BQT_OT_forward_key):
        bpy.utils.register_class(operator)
    _CAPTURE_OP_REGISTERED = True


def shutdown_global_operators() -> None:
    """Unregister shared gizmo operators and reset their transient state."""
    global _CAPTURE_OP_REGISTERED

    if not _CAPTURE_OP_REGISTERED:
        BQT_OT_capture_keys._is_running = False
        BQT_OT_capture_keys._start_pending = False
        return

    BQT_OT_capture_keys._is_running = False
    BQT_OT_capture_keys._start_pending = False

    for operator in (BQT_OT_forward_key, BQT_OT_capture_keys, BQT_OT_focus_check):
        try:
            bpy.utils.unregister_class(operator)
        except RuntimeError:
            LOGGER.debug("Failed to unregister %r", operator, exc_info=True)

    _CAPTURE_OP_REGISTERED = False


def register_runtime(
    *,
    gizmo_id: str,
    runtime: IViewportRuntime,
    space_type: str,
    is_2d: bool,
    draw_stage: str = "POST_PIXEL",
    register_global_operators: Callable[[], None] | None = None,
) -> None:
    ensure_global_operators()
    if register_global_operators is not None:
        register_global_operators()
    set_runtime(gizmo_id, runtime)

    def get_runtime_fn():
        return get_runtime(gizmo_id)

    safe_name = gizmo_id.replace(".", "_").lower()
    gizmo_idname = f"BQT_GIZMO_{safe_name.upper()}_GT_panel"
    gizmo_group_idname = f"BQT_GIZMO_{safe_name.upper()}_GGT_panel"

    gizmo_cls = type(
        gizmo_idname,
        (PanelGizmoBase,),
        {
            "bl_idname": gizmo_idname,
            "get_runtime": lambda self: get_runtime_fn(),
            "_get_gizmo_id": lambda self: gizmo_id,
        },
    )

    def _group_poll(cls, context):
        return get_runtime_fn() is not None

    gizmo_group_cls = type(
        gizmo_group_idname,
        (PanelGizmoGroupBase,),
        {
            "bl_idname": gizmo_group_idname,
            "bl_label": f"Blender Qt Gizmo {gizmo_id}",
            "bl_space_type": space_type,
            "gizmo_type": gizmo_idname,
            "get_runtime": lambda self: get_runtime_fn(),
            "poll": classmethod(_group_poll),
        },
    )

    blender_classes = [gizmo_cls, gizmo_group_cls]
    for blender_class in blender_classes:
        bpy.utils.register_class(blender_class)
    register_gizmo_keymaps(space_type, gizmo_id)
    draw_handler = _install_draw_handler(space_type, get_runtime_fn, draw_stage)
    _REGISTERED_GIZMOS[gizmo_id] = _GizmoRegistration(gizmo_id, blender_classes, space_type, draw_handler)
    ensure_capture_keys_running()
    log_message(
        LOGGER,
        LogCategory.REGISTRATION,
        logging.INFO,
        "Registered viewport gizmo %r (%s, %s)",
        gizmo_id,
        space_type,
        "2d" if is_2d else "3d",
    )


def unregister_viewport_gizmo(gizmo_id: str) -> None:
    registration = _REGISTERED_GIZMOS.pop(gizmo_id, None)
    if registration is None:
        LOGGER.warning("Gizmo %r is not registered; nothing to unregister.", gizmo_id)
        return
    if registration.draw_handler is not None:
        _remove_draw_handler(registration.space_type, registration.draw_handler)
    unregister_gizmo_keymaps(gizmo_id)
    remove_runtime(gizmo_id)
    for blender_class in reversed(registration.blender_classes):
        try:
            bpy.utils.unregister_class(blender_class)
        except RuntimeError:
            LOGGER.debug("Failed to unregister %r", blender_class, exc_info=True)
    log_message(
        LOGGER,
        LogCategory.REGISTRATION,
        logging.INFO,
        "Unregistered viewport gizmo %r",
        gizmo_id,
    )
