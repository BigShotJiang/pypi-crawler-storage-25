"""Runtime configuration and logging helpers for Blender Qt."""

from __future__ import annotations

from dataclasses import dataclass, replace
import logging

from .constants import LogCategory

DEFAULT_UPDATE_INTERVAL_MS = 100
DEFAULT_LOG_LEVEL_NAME = "WARNING"


@dataclass(frozen=True)
class RuntimeConfig:
    """Resolved runtime configuration for the current process."""

    update_interval_ms: int = DEFAULT_UPDATE_INTERVAL_MS
    log_level_name: str = DEFAULT_LOG_LEVEL_NAME
    log_all_events: bool = False
    log_mouse_events: bool = False
    log_keyboard_events: bool = False
    log_focus_events: bool = False
    log_registration_events: bool = False
    log_debug_events: bool = False


_RUNTIME_CONFIG = RuntimeConfig()


def get_runtime_config() -> RuntimeConfig:
    """Return the active runtime configuration."""
    return _RUNTIME_CONFIG


def update_runtime_config(**changes: object) -> RuntimeConfig:
    """Apply partial runtime configuration updates."""
    global _RUNTIME_CONFIG

    if not changes:
        return _RUNTIME_CONFIG

    normalized_changes: dict[str, object] = {}
    for key, value in changes.items():
        if value is None:
            continue
        if key == "update_interval_ms":
            normalized_changes[key] = max(1, int(value))
        elif key == "log_level_name":
            normalized_changes[key] = str(value or DEFAULT_LOG_LEVEL_NAME)
        else:
            normalized_changes[key] = bool(value)

    _RUNTIME_CONFIG = replace(_RUNTIME_CONFIG, **normalized_changes)
    return _RUNTIME_CONFIG


def reset_runtime_config() -> RuntimeConfig:
    """Reset the runtime configuration back to defaults."""
    global _RUNTIME_CONFIG

    _RUNTIME_CONFIG = RuntimeConfig()
    return _RUNTIME_CONFIG


def get_update_interval_ms(default: int = DEFAULT_UPDATE_INTERVAL_MS) -> int:
    """Return the configured Qt service interval in milliseconds."""
    return max(1, int(get_runtime_config().update_interval_ms or default))


def get_update_interval_seconds(default_seconds: float = DEFAULT_UPDATE_INTERVAL_MS / 1000.0) -> float:
    """Return the configured Qt service interval in seconds."""
    return max(0.001, get_update_interval_ms(int(default_seconds * 1000.0)) / 1000.0)


def get_logging_level_name(default: str = DEFAULT_LOG_LEVEL_NAME) -> str:
    """Return the configured minimum logging severity."""
    return str(get_runtime_config().log_level_name or default)


def should_log_category(category: LogCategory) -> bool:
    """Return whether a logging category is enabled in runtime configuration."""
    config = get_runtime_config()
    if config.log_all_events:
        return True

    mapping = {
        LogCategory.MOUSE: config.log_mouse_events,
        LogCategory.KEYBOARD: config.log_keyboard_events,
        LogCategory.FOCUS: config.log_focus_events,
        LogCategory.REGISTRATION: config.log_registration_events,
        LogCategory.DEBUG: config.log_debug_events,
    }
    return bool(mapping.get(category, False))


def log_message(logger: logging.Logger, category: LogCategory, level: int, message: str, *args: object) -> None:
    """Emit a log message when the matching category is enabled."""
    if should_log_category(category):
        logger.log(level, message, *args)


# MARK: Runtime options

LOGGER = logging.getLogger(__name__)

_LOGGING_CONFIGURED = False


@dataclass(frozen=True)
class RuntimeOptions:
    """Resolved runtime options for the current process."""

    disable_startup: bool
    update_interval_ms: int
    log_level_name: str
    manage_windows: bool
    unique_windows: bool
    stay_on_top_windows: bool
    attach_windows_to_blender: bool
    enable_focus_recovery: bool


def get_runtime_options() -> RuntimeOptions:
    """Return the resolved runtime options for the current process."""
    return RuntimeOptions(
        disable_startup=False,
        update_interval_ms=max(1, int(get_update_interval_ms(DEFAULT_UPDATE_INTERVAL_MS))),
        log_level_name=get_logging_level_name(DEFAULT_LOG_LEVEL_NAME),
        manage_windows=True,
        unique_windows=True,
        stay_on_top_windows=True,
        attach_windows_to_blender=True,
        enable_focus_recovery=True,
    )


def configure_logging() -> None:
    """Apply Blender Qt logging configuration once per process."""
    global _LOGGING_CONFIGURED

    if not _LOGGING_CONFIGURED:
        logging.basicConfig(encoding="utf-8")
        _LOGGING_CONFIGURED = True

    options = get_runtime_options()
    logging.getLogger("blender_qt").setLevel(getattr(logging, options.log_level_name, logging.WARNING))
