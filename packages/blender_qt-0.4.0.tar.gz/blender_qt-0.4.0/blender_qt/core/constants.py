"""Key and mouse mappings, enumerations, and constants for the Blender Qt package.

This module is the single source of truth for input translation tables
used by the gizmo input capture and key-forwarding operator, as well as
shared enumerations and logging category flags.
"""

from __future__ import annotations

from enum import Flag, auto

from PySide6 import QtCore


# MARK: Enumerations


class KeyboardModifier(Flag):
    """Modifier key flags for input events."""

    NONE = 0
    SHIFT = auto()
    CTRL = auto()
    ALT = auto()


class MouseButton(Flag):
    """Mouse button flags for input events."""

    NONE = 0
    LEFT = auto()
    MIDDLE = auto()
    RIGHT = auto()


class LogCategory(Flag):
    """Bit-flag categories for selective runtime logging."""

    NONE = 0
    MOUSE = auto()
    KEYBOARD = auto()
    FOCUS = auto()
    REGISTRATION = auto()
    DEBUG = auto()
    ALL = MOUSE | KEYBOARD | FOCUS | REGISTRATION | DEBUG


def keyboard_modifiers(*, shift: bool = False, ctrl: bool = False, alt: bool = False) -> KeyboardModifier:
    """Build modifier flags from Blender-style modifier booleans."""

    modifiers = KeyboardModifier.NONE
    if shift:
        modifiers |= KeyboardModifier.SHIFT
    if ctrl:
        modifiers |= KeyboardModifier.CTRL
    if alt:
        modifiers |= KeyboardModifier.ALT
    return modifiers


def event_modifiers(event: object) -> KeyboardModifier:
    """Extract modifier flags from an event-like object."""

    return keyboard_modifiers(
        shift=getattr(event, "shift", False),
        ctrl=getattr(event, "ctrl", False),
        alt=getattr(event, "alt", False),
    )


# MARK: Blender key type -> Qt key code

KEY_MAP: dict[str, QtCore.Qt.Key] = {
    # Letters
    "A": QtCore.Qt.Key_A,
    "B": QtCore.Qt.Key_B,
    "C": QtCore.Qt.Key_C,
    "D": QtCore.Qt.Key_D,
    "E": QtCore.Qt.Key_E,
    "F": QtCore.Qt.Key_F,
    "G": QtCore.Qt.Key_G,
    "H": QtCore.Qt.Key_H,
    "I": QtCore.Qt.Key_I,
    "J": QtCore.Qt.Key_J,
    "K": QtCore.Qt.Key_K,
    "L": QtCore.Qt.Key_L,
    "M": QtCore.Qt.Key_M,
    "N": QtCore.Qt.Key_N,
    "O": QtCore.Qt.Key_O,
    "P": QtCore.Qt.Key_P,
    "Q": QtCore.Qt.Key_Q,
    "R": QtCore.Qt.Key_R,
    "S": QtCore.Qt.Key_S,
    "T": QtCore.Qt.Key_T,
    "U": QtCore.Qt.Key_U,
    "V": QtCore.Qt.Key_V,
    "W": QtCore.Qt.Key_W,
    "X": QtCore.Qt.Key_X,
    "Y": QtCore.Qt.Key_Y,
    "Z": QtCore.Qt.Key_Z,
    # Number row
    "ZERO": QtCore.Qt.Key_0,
    "ONE": QtCore.Qt.Key_1,
    "TWO": QtCore.Qt.Key_2,
    "THREE": QtCore.Qt.Key_3,
    "FOUR": QtCore.Qt.Key_4,
    "FIVE": QtCore.Qt.Key_5,
    "SIX": QtCore.Qt.Key_6,
    "SEVEN": QtCore.Qt.Key_7,
    "EIGHT": QtCore.Qt.Key_8,
    "NINE": QtCore.Qt.Key_9,
    # Numpad
    "NUMPAD_0": QtCore.Qt.Key_0,
    "NUMPAD_1": QtCore.Qt.Key_1,
    "NUMPAD_2": QtCore.Qt.Key_2,
    "NUMPAD_3": QtCore.Qt.Key_3,
    "NUMPAD_4": QtCore.Qt.Key_4,
    "NUMPAD_5": QtCore.Qt.Key_5,
    "NUMPAD_6": QtCore.Qt.Key_6,
    "NUMPAD_7": QtCore.Qt.Key_7,
    "NUMPAD_8": QtCore.Qt.Key_8,
    "NUMPAD_9": QtCore.Qt.Key_9,
    "NUMPAD_PLUS": QtCore.Qt.Key_Plus,
    "NUMPAD_MINUS": QtCore.Qt.Key_Minus,
    "NUMPAD_ASTERIX": QtCore.Qt.Key_Asterisk,
    "NUMPAD_SLASH": QtCore.Qt.Key_Slash,
    "NUMPAD_PERIOD": QtCore.Qt.Key_Period,
    "NUMPAD_ENTER": QtCore.Qt.Key_Enter,
    # Whitespace / navigation
    "SPACE": QtCore.Qt.Key_Space,
    "TAB": QtCore.Qt.Key_Tab,
    "RET": QtCore.Qt.Key_Return,
    "ESC": QtCore.Qt.Key_Escape,
    "BACK_SPACE": QtCore.Qt.Key_Backspace,
    "DEL": QtCore.Qt.Key_Delete,
    "INSERT": QtCore.Qt.Key_Insert,
    "HOME": QtCore.Qt.Key_Home,
    "END": QtCore.Qt.Key_End,
    "PAGE_UP": QtCore.Qt.Key_PageUp,
    "PAGE_DOWN": QtCore.Qt.Key_PageDown,
    # Arrow keys
    "LEFT_ARROW": QtCore.Qt.Key_Left,
    "RIGHT_ARROW": QtCore.Qt.Key_Right,
    "UP_ARROW": QtCore.Qt.Key_Up,
    "DOWN_ARROW": QtCore.Qt.Key_Down,
    # Punctuation
    "MINUS": QtCore.Qt.Key_Minus,
    "EQUAL": QtCore.Qt.Key_Equal,
    "SEMI_COLON": QtCore.Qt.Key_Semicolon,
    "PERIOD": QtCore.Qt.Key_Period,
    "COMMA": QtCore.Qt.Key_Comma,
    "QUOTE": QtCore.Qt.Key_Apostrophe,
    "ACCENT_GRAVE": QtCore.Qt.Key_QuoteLeft,
    "SLASH": QtCore.Qt.Key_Slash,
    "BACK_SLASH": QtCore.Qt.Key_Backslash,
    "LEFT_BRACKET": QtCore.Qt.Key_BracketLeft,
    "RIGHT_BRACKET": QtCore.Qt.Key_BracketRight,
    # Function keys
    "F1": QtCore.Qt.Key_F1,
    "F2": QtCore.Qt.Key_F2,
    "F3": QtCore.Qt.Key_F3,
    "F4": QtCore.Qt.Key_F4,
    "F5": QtCore.Qt.Key_F5,
    "F6": QtCore.Qt.Key_F6,
    "F7": QtCore.Qt.Key_F7,
    "F8": QtCore.Qt.Key_F8,
    "F9": QtCore.Qt.Key_F9,
    "F10": QtCore.Qt.Key_F10,
    "F11": QtCore.Qt.Key_F11,
    "F12": QtCore.Qt.Key_F12,
    # Modifier keys
    "LEFT_SHIFT": QtCore.Qt.Key_Shift,
    "RIGHT_SHIFT": QtCore.Qt.Key_Shift,
    "LEFT_CTRL": QtCore.Qt.Key_Control,
    "RIGHT_CTRL": QtCore.Qt.Key_Control,
    "LEFT_ALT": QtCore.Qt.Key_Alt,
    "RIGHT_ALT": QtCore.Qt.Key_Alt,
}

# Ordered tuple of every Blender key type that should be intercepted

KEY_TYPES: tuple[str, ...] = tuple(KEY_MAP.keys())

# Blender -> Qt mouse button

MOUSE_BUTTONS: dict[str, MouseButton] = {
    "LEFTMOUSE": MouseButton.LEFT,
    "MIDDLEMOUSE": MouseButton.MIDDLE,
    "RIGHTMOUSE": MouseButton.RIGHT,
}
