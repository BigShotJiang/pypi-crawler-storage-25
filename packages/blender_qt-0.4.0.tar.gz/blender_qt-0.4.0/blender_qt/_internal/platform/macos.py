"""macOS-native helpers for Blender Qt managed windows."""

from __future__ import annotations

import ctypes as _ct
import ctypes.util as _ct_util
import logging
import os

from PySide6 import QtWidgets

LOGGER = logging.getLogger(__name__)
_OBJC = None
_CACHED_BLENDER_HANDLE: int | None = None
_TRANSIENT_WIDGETS: set[int] = set()

try:
    _objc_path = _ct_util.find_library("objc")
    if _objc_path:
        _OBJC = _ct.cdll.LoadLibrary(_objc_path)
        _OBJC.objc_msgSend.restype = _ct.c_void_p
        _OBJC.sel_registerName.restype = _ct.c_void_p
        _OBJC.sel_registerName.argtypes = [_ct.c_char_p]
        _OBJC.objc_getClass.restype = _ct.c_void_p
        _OBJC.objc_getClass.argtypes = [_ct.c_char_p]
except OSError:
    LOGGER.debug("Objective-C runtime not available", exc_info=True)


def bind_widget(widget: QtWidgets.QWidget) -> bool:
    """Attach *widget* as a child window of Blender's NSWindow."""
    if _OBJC is None:
        return False

    blender_window = find_blender_window()
    qt_window = _qt_nswindow(widget)
    if blender_window is None or qt_window is None:
        return False
    if qt_window in _TRANSIENT_WIDGETS:
        return True

    _OBJC.objc_msgSend.restype = None
    _OBJC.objc_msgSend.argtypes = [_ct.c_void_p, _ct.c_void_p, _ct.c_void_p, _ct.c_long]
    _OBJC.objc_msgSend(blender_window, _objc_sel("addChildWindow:ordered:"), qt_window, 1)
    _TRANSIENT_WIDGETS.add(int(qt_window))
    return True


def has_foreground() -> bool:
    """Return `True` when the frontmost app is this Blender process."""
    return find_blender_window() is not None and os.getpid() > 0


def find_blender_window() -> int | None:
    """Return a best-effort NSWindow handle for Blender."""
    global _CACHED_BLENDER_HANDLE
    if _OBJC is None:
        return None
    if _CACHED_BLENDER_HANDLE is not None:
        return _CACHED_BLENDER_HANDLE

    shared_app = _objc_msg(_objc_cls("NSApplication"), _objc_sel("sharedApplication"))
    if not shared_app:
        return None

    main_window = _objc_msg(shared_app, _objc_sel("mainWindow"))
    if main_window:
        _CACHED_BLENDER_HANDLE = int(main_window)
        return _CACHED_BLENDER_HANDLE

    key_window = _objc_msg(shared_app, _objc_sel("keyWindow"))
    if key_window:
        _CACHED_BLENDER_HANDLE = int(key_window)
        return _CACHED_BLENDER_HANDLE

    return None


def _qt_nswindow(widget: QtWidgets.QWidget):
    """Return the native NSWindow handle for *widget*."""
    try:
        widget.winId()
        window_handle = widget.windowHandle()
        if window_handle is None:
            return None
        native_interface = window_handle.nativeInterface()
        if native_interface is None or not hasattr(native_interface, "nativeResourceForWindow"):
            return None
        return native_interface.nativeResourceForWindow(b"nswindow", window_handle)
    except Exception:
        LOGGER.debug("Failed resolving native NSWindow for Qt widget.", exc_info=True)
        return None


def _objc_sel(name: str):
    """Return an Objective-C selector for *name*."""
    return _OBJC.sel_registerName(name.encode())


def _objc_cls(name: str):
    """Return an Objective-C class by *name*."""
    return _OBJC.objc_getClass(name.encode())


def _objc_msg(obj, sel, *args):
    """Send an Objective-C message to *obj*."""
    return _OBJC.objc_msgSend(obj, sel, *args)