"""Widget-backed node-space runtime."""

from __future__ import annotations

import logging
import inspect
from dataclasses import dataclass
from typing import Callable, Optional

import bpy
from PySide6 import QtCore, QtWidgets

from ...core.app import ensure_qt_app, register_renderer, unregister_renderer
from ...core.interfaces import WidgetFactory
from ...core.space.base import tag_redraw_custom_spaces
from ...core.space.runtime import SpaceRuntimeBase
from ...theme.scale import get_scale_model
from ...theme.sync import apply_theme_to_widget
from .renderer import HostWindow, OffscreenWidgetsRenderer

LOGGER = logging.getLogger(__name__)

_WIDGET_RUNTIME_BY_EDITOR: dict[int, "WidgetSpaceRuntime"] = {}


def _instantiate_widget(factory: WidgetFactory, parent: QtWidgets.QWidget) -> QtWidgets.QWidget:
    if inspect.isclass(factory) and issubclass(factory, QtWidgets.QWidget):
        return factory(parent)

    signature = inspect.signature(factory)
    positional_count = sum(
        1
        for parameter in signature.parameters.values()
        if parameter.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    )
    widget = factory() if positional_count == 0 else factory(parent)
    if widget.parent() is not parent:
        widget.setParent(parent)
    return widget


@dataclass(slots=True)
class SurfaceWidgetHandle:
    widget: QtWidgets.QWidget
    popup_geometry: Callable[[QtWidgets.QWidget], tuple[int, int, int, int]]
    widget_rect: Callable[[QtWidgets.QWidget], tuple[int, int, int, int]]


def create_surface_widget(factory: WidgetFactory, *, width: int, height: int) -> SurfaceWidgetHandle:
    host_window = HostWindow()
    surface = host_window.surface
    widget = _instantiate_widget(factory, surface)
    if widget.objectName() == "":
        widget.setObjectName(widget.__class__.__name__)
    widget.setVisible(True)
    layout = QtWidgets.QVBoxLayout(surface)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(0)
    layout.addWidget(widget)
    host_window.resize(width, height)
    surface.resize(width, height)
    return SurfaceWidgetHandle(
        widget=widget,
        popup_geometry=lambda popup_widget: (0, 0, max(1, popup_widget.width()), -1),
        widget_rect=lambda any_widget: (0, 0, max(1, any_widget.width()), max(1, any_widget.height())),
    )


class WidgetSpaceRuntime(SpaceRuntimeBase):
    def __init__(
        self,
        context: bpy.types.Context,
        *,
        widget_factory: WidgetFactory,
        tree_type: str,
        window_title: str = "Blender Qt Widget Space",
    ) -> None:
        area = getattr(context, "area", None)
        area_pointer = area.as_pointer() if area else None
        super().__init__(area_pointer)
        ensure_qt_app()
        self.tree_type = tree_type
        self._open_dialogs: list[QtWidgets.QDialog] = []
        self.host_window = HostWindow()
        self.host_window.setWindowTitle(window_title)
        self.surface = self.host_window.surface
        self.widget = _instantiate_widget(widget_factory, self.surface)
        layout = QtWidgets.QVBoxLayout(self.surface)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.widget)
        self.host_window.popup_geometry_provider = self.popup_geometry_for_widget
        self.host_window.widget_rect_provider = self.widget_rect_for_widget
        scale_model = get_scale_model(context)
        renderer = OffscreenWidgetsRenderer(self.host_window, render_scale=scale_model.render_scale)
        self.renderer = renderer
        self.renderer.updated.connect(lambda: tag_redraw_custom_spaces(self.tree_type))
        register_renderer(renderer)
        apply_theme_to_widget(self.host_window)
        renderer.apply_theme()
        self.widget.show()
        self.surface.show()
        self.host_window.show()

    @property
    def renderer(self) -> OffscreenWidgetsRenderer:
        return self._renderer  # type: ignore[return-value]

    @renderer.setter
    def renderer(self, value: OffscreenWidgetsRenderer | None) -> None:
        self._renderer = value

    def popup_geometry_for_widget(self, widget: QtWidgets.QWidget) -> tuple[int, int, int, int]:
        return self.renderer.popup_geometry_for_widget(widget)

    def widget_rect_for_widget(self, widget: QtWidgets.QWidget) -> tuple[int, int, int, int]:
        return self.renderer.widget_rect_for_widget(widget)

    def cleanup(self) -> None:
        if self.renderer is not None:
            unregister_renderer(self.renderer)
            self.renderer.cleanup()
        for dialog in list(self._open_dialogs):
            try:
                dialog.close()
                dialog.deleteLater()
            except Exception:
                LOGGER.debug("Failed to close widget-space dialog", exc_info=True)
        self._open_dialogs.clear()
        self.renderer = None
        super().cleanup()


class WidgetViewportRuntime(WidgetSpaceRuntime):
    pass


def register_runtime(area_hash: int, runtime: WidgetSpaceRuntime) -> WidgetSpaceRuntime:
    previous = _WIDGET_RUNTIME_BY_EDITOR.get(area_hash)
    if previous is not None:
        previous.cleanup()
    _WIDGET_RUNTIME_BY_EDITOR[area_hash] = runtime
    return runtime


def get_runtime(area_hash: int) -> Optional[WidgetSpaceRuntime]:
    return _WIDGET_RUNTIME_BY_EDITOR.get(area_hash)


def get_any_runtime() -> Optional[WidgetSpaceRuntime]:
    return next(iter(_WIDGET_RUNTIME_BY_EDITOR.values()), None)


def get_runtime_for_context(
    context: bpy.types.Context,
    *,
    create: bool = True,
    surface_factory: WidgetFactory | None = None,
    tree_type: str = "",
    window_title: str = "Blender Qt Widget Space",
) -> Optional[WidgetSpaceRuntime]:
    area = getattr(context, "area", None)
    key = area.as_pointer() if area else None
    if key is None:
        return None
    runtime = _WIDGET_RUNTIME_BY_EDITOR.get(key)
    if runtime is None and create and surface_factory is not None:
        runtime = WidgetSpaceRuntime(
            context,
            widget_factory=surface_factory,
            tree_type=tree_type,
            window_title=window_title,
        )
        _WIDGET_RUNTIME_BY_EDITOR[key] = runtime
    return runtime


def clear_runtimes() -> None:
    runtimes = list(_WIDGET_RUNTIME_BY_EDITOR.values())
    _WIDGET_RUNTIME_BY_EDITOR.clear()
    for runtime in runtimes:
        runtime.cleanup()
