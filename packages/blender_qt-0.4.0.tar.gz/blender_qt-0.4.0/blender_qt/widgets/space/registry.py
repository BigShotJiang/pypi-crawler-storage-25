"""Widget-specific node space registration."""

from __future__ import annotations

from typing import Callable

import bpy

from ...core.interfaces import WidgetFactory
from ...core.config import log_message
from ...core.constants import LogCategory
from ...core.space.base import CustomSpaceSpec, ensure_space_tree, get_current_space_tree, is_custom_space
from ...core.space.registration import LOGGER, finalize_space_registration, is_space_registered
from ..render.runtime import clear_runtimes, get_runtime_for_context as get_runtime


def register_space(
    tree_type: str,
    label: str,
    widget_factory: WidgetFactory,
    *,
    icon: str = "RESTRICT_VIEW_OFF",
    sidebar_category: str = "Blender Qt",
    menu_draw_callback: Callable[[bpy.types.Menu, bpy.types.Context], None] | None = None,
) -> None:
    if is_space_registered(tree_type):
        raise ValueError(f"Space {tree_type!r} is already registered.")
    safe_name = tree_type.replace(".", "_").lower()
    spec = CustomSpaceSpec(
        tree_type=tree_type,
        tree_label=label,
        tree_icon=icon,
        tree_name=f"{label} Graph",
        sidebar_category=sidebar_category,
        sidebar_label=label,
        window_title=label,
        reload_operator=f"blender_qt_{safe_name}.reload",
        create_graph_operator=f"blender_qt_{safe_name}.create_graph",
        menu_draw_callback=menu_draw_callback,
        header_menu_idname=f"BQT_{safe_name.upper()}_MT_header_menu" if menu_draw_callback is not None else "",
    )

    def poll_function(context: bpy.types.Context) -> bool:
        return is_custom_space(context, tree_type)

    def get_area_runtime(context: bpy.types.Context, create: bool = True):
        if get_current_space_tree(context, tree_type) is None:
            ensure_space_tree(context, spec)
        return get_runtime(
            context, create=create, surface_factory=widget_factory, tree_type=tree_type, window_title=label
        )

    finalize_space_registration(
        tree_type=tree_type,
        spec=spec,
        poll_function=poll_function,
        get_runtime_function=get_area_runtime,
        clear_runtimes_function=clear_runtimes,
        is_qml=False,
    )
    log_message(LOGGER, LogCategory.REGISTRATION, 20, "Registered widget space %r", tree_type)
