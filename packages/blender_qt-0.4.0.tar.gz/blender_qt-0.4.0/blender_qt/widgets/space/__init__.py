"""Widget node-space exports."""

from .registry import register_space
from ..render.runtime import (
    WidgetSpaceRuntime,
    clear_runtimes,
    get_any_runtime,
    get_runtime_for_context as get_runtime,
)

__all__ = ["WidgetSpaceRuntime", "clear_runtimes", "get_any_runtime", "get_runtime", "register_space"]
