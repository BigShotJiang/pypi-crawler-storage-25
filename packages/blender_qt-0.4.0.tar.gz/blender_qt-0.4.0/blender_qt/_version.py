"""Package version for the distributable blender_qt wheel."""

__version__ = "0.4.0"
