# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

import argparse
import asyncio
import json
import logging
import sys
import time
from collections import defaultdict, namedtuple
from dataclasses import asdict
from operator import attrgetter

import aiohttp
import colorama
import tqdm
from colorama import Fore, Style

from omniscan import __version__
from omniscan.platforms import PlatformResponse, Platforms
from omniscan.util import EMAIL_REGEX, PHONE_REGEX, init_checkers, init_prerequest, query

BAR_WIDTH = 50
BAR_FORMAT = "{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed_s:.2f}s]"

DIVIDER_LENGTH = 40

Colour = namedtuple("Colour", ["Primary", "Secondary"])
COLOUR_AVAILABLE = Colour(Fore.LIGHTGREEN_EX, Fore.LIGHTGREEN_EX)
COLOUR_UNAVAILABLE = Colour(Fore.YELLOW, Fore.WHITE)
COLOUR_INVALID = Colour(Fore.CYAN, Fore.WHITE)
COLOUR_ERROR = Colour(Fore.RED, Fore.RED)


def init_parser():
    parser = argparse.ArgumentParser(
        description="Command-line interface for checking email address and username usage on online platforms: "
        + ", ".join(p.value.__name__ for p in Platforms)
    )
    parser.add_argument(
        "queries",
        metavar="query",
        nargs="*",
        help="one or more usernames/email addresses to query (email addresses are automatically be queried if they match the format)",
    )
    parser.add_argument(
        "--platforms",
        "-p",
        metavar="platform",
        nargs="*",
        help="list of platforms to query " "(default: all platforms)",
    )
    parser.add_argument(
        "--view-by",
        dest="view_key",
        choices=["platform", "query"],
        default="query",
        help="view results sorted by platform or by query (default: query)",
    )
    parser.add_argument(
        "--available-only",
        "-a",
        action="store_true",
        help="only print usernames/email addresses that are available and not in use",
    )
    parser.add_argument(
        "--cache-tokens",
        "-c",
        action="store_true",
        help="cache tokens for platforms requiring more than one HTTP request (Snapchat, GitHub, Instagram. Lastfm, Tumblr & Yahoo), reducing total number of requests sent",
    )
    parser.add_argument(
        "--input", "-i", metavar="input.txt", help="file containg list of queries to execute"
    )
    parser.add_argument(
        "--proxy-list",
        metavar="proxy_list.txt",
        help="file containing list of HTTP proxy servers to execute queries with",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="show query responses as they are received"
    )
    parser.add_argument(
        "--show-urls",
        action="store_true",
        help="display profile URLs for usernames on supported platforms (profiles may not exist if usernames are reserved or belong to deleted/banned accounts)",
    )
    parser.add_argument(
        "--json",
        metavar="json.txt",
        help="output results in JSON format to the specified file",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="output debug messages",
    )
    parser.add_argument(
        "--sherlock",
        "-s",
        action="store_true",
        help="also run Sherlock to check username across 400+ additional sites",
    )
    parser.add_argument(
        "--phoneinfoga",
        "-n",
        action="store_true",
        help="run PhoneInfoga to scan phone numbers (e.g. +12025551234); requires phoneinfoga in PATH",
    )
    parser.add_argument(
        "--holehe",
        action="store_true",
        help="check email addresses on 120+ sites via Holehe (bundled)",
    )
    parser.add_argument(
        "--maigret",
        action="store_true",
        help="sweep usernames across 2500+ sites via Maigret; requires maigret in PATH",
    )
    parser.add_argument(
        "--ghunt",
        action="store_true",
        help="Google account OSINT from email via GHunt; requires ghunt in PATH and prior 'ghunt login'",
    )
    parser.add_argument("--version", version=f"%(prog)s {__version__}", action="version")
    return parser


def pretty_print(results, *, view_value, available_only, show_urls):
    for key, responses in results.items():
        if available_only and not [r for r in responses if r.available]:
            continue

        header = (
            f"{'-' * DIVIDER_LENGTH}\n"
            f"{' ' * (DIVIDER_LENGTH // 2 - len(key) // 2) + Style.BRIGHT + str(key) + Style.RESET_ALL}\n"
            f"{'-' * DIVIDER_LENGTH}"
        )
        print(header)

        responses.sort(key=lambda response: str(getattr(response, view_value)).lower())
        responses.sort(key=attrgetter("available", "valid", "success"), reverse=True)
        for response in responses:
            value = str(getattr(response, view_value))
            if available_only and not response.available:
                continue
            if not response.success:
                print(COLOUR_ERROR.Primary + f"{value}: {response.message}", file=sys.stderr)
            elif not response.valid:
                print(
                    COLOUR_INVALID.Primary
                    + f"{value}: {COLOUR_INVALID.Secondary}{response.message}"
                )
            else:
                col = COLOUR_AVAILABLE if response.available else COLOUR_UNAVAILABLE
                result_text = col.Primary + value
                if response.link and show_urls:
                    result_text += col.Secondary + f" - {response.link}"
                print(result_text)

    print("\n" + COLOUR_AVAILABLE.Primary + "Available, ", end="")
    print(COLOUR_UNAVAILABLE.Primary + "Taken/Reserved, ", end="")
    print(COLOUR_INVALID.Primary + "Invalid, ", end="")
    print(COLOUR_ERROR.Primary + "Error")


def print_json(results, *, file, available_only):
    if available_only:
        results = {key: [v for v in values if v.available] for key, values in results.items()}

    def serialize(obj):
        if isinstance(obj, PlatformResponse):
            # Omit None and convert Platform objects to str
            return asdict(
                obj,
                dict_factory=lambda data: dict(
                    [(x[0], str(x[1])) for x in data if x[1] is not None]
                ),
            )

    with open(file, "w") as f:
        f.write(json.dumps(results, default=serialize, indent=4))


async def run_sherlock(username, per_request_timeout=10, overall_timeout=120):
    from sherlock_project.notify import QueryNotify
    from sherlock_project.sherlock import sherlock as sherlock_scan
    from sherlock_project.sites import SitesInformation

    sites_info = SitesInformation()
    site_data = {site.name: site.information for site in sites_info}
    try:
        return await asyncio.wait_for(
            asyncio.to_thread(
                sherlock_scan, username, site_data, QueryNotify(), timeout=per_request_timeout
            ),
            timeout=overall_timeout,
        )
    except asyncio.TimeoutError:
        print(f"\nomniscan: Sherlock scan timed out after {overall_timeout}s")
        return {}


def print_sherlock_results(sherlock_results, *, available_only, show_urls):
    from sherlock_project.result import QueryStatus

    print("\n" + "=" * DIVIDER_LENGTH)
    print(" " * (DIVIDER_LENGTH // 2 - 8) + Style.BRIGHT + "SHERLOCK SCAN" + Style.RESET_ALL)
    print("=" * DIVIDER_LENGTH)

    for username, results in sherlock_results.items():
        header = (
            f"{'-' * DIVIDER_LENGTH}\n"
            f"{' ' * (DIVIDER_LENGTH // 2 - len(username) // 2) + Style.BRIGHT + username + Style.RESET_ALL}\n"
            f"{'-' * DIVIDER_LENGTH}"
        )
        print(header)

        claimed = sorted(
            [(site, info) for site, info in results.items()
             if info["status"].status == QueryStatus.CLAIMED],
            key=lambda x: x[0].lower(),
        )
        available = sorted(
            [(site, info) for site, info in results.items()
             if info["status"].status == QueryStatus.AVAILABLE],
            key=lambda x: x[0].lower(),
        )

        if not available_only:
            for site, info in claimed:
                line = COLOUR_UNAVAILABLE.Primary + site
                if show_urls:
                    line += COLOUR_UNAVAILABLE.Secondary + f" - {info['url_user']}"
                print(line)

        if available_only:
            for site, info in available:
                print(COLOUR_AVAILABLE.Primary + site)

        if not available_only:
            errors = sum(
                1 for info in results.values()
                if info["status"].status not in (QueryStatus.CLAIMED, QueryStatus.AVAILABLE, QueryStatus.ILLEGAL)
            )
            print(
                f"\n{COLOUR_UNAVAILABLE.Primary}{len(claimed)} found"
                f"{Fore.RESET}, {COLOUR_AVAILABLE.Primary}{len(available)} available"
                f"{Fore.RESET}, {COLOUR_ERROR.Primary}{errors} errors"
            )


async def run_phoneinfoga(number, overall_timeout=60):
    import os
    import shutil
    import subprocess

    phoneinfoga_bin = shutil.which("phoneinfoga")
    if not phoneinfoga_bin:
        bin_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        candidate = os.path.join(bin_dir, "phoneinfoga.exe" if sys.platform == "win32" else "phoneinfoga")
        if os.path.exists(candidate):
            phoneinfoga_bin = candidate

    if not phoneinfoga_bin:
        print(
            "\nomniscan: PhoneInfoga not found.\n"
            "Install it from: https://github.com/sundowndev/phoneinfoga/releases\n"
            "Then make sure 'phoneinfoga' is in your PATH."
        )
        return None

    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(
                subprocess.run,
                [phoneinfoga_bin, "scan", "-n", number],
                capture_output=True,
                text=True,
            ),
            timeout=overall_timeout,
        )
        return (result.stdout + result.stderr).strip()
    except asyncio.TimeoutError:
        print(f"\nomniscan: PhoneInfoga scan timed out after {overall_timeout}s")
        return None


def print_phoneinfoga_results(phoneinfoga_results):
    print("\n" + "=" * DIVIDER_LENGTH)
    print(" " * (DIVIDER_LENGTH // 2 - 8) + Style.BRIGHT + "PHONEINFOGA SCAN" + Style.RESET_ALL)
    print("=" * DIVIDER_LENGTH)

    for number, output in phoneinfoga_results.items():
        header = (
            f"{'-' * DIVIDER_LENGTH}\n"
            f"{' ' * (DIVIDER_LENGTH // 2 - len(number) // 2) + Style.BRIGHT + number + Style.RESET_ALL}\n"
            f"{'-' * DIVIDER_LENGTH}"
        )
        print(header)
        if output:
            print(output)
        else:
            print(COLOUR_ERROR.Primary + "No results returned.")


async def run_holehe(email, overall_timeout=120):
    try:
        import httpx
        from holehe.core import get_holehe_results
    except ImportError:
        print("\nomniscan: Holehe not available. Install: pip install holehe")
        return None

    try:
        async with httpx.AsyncClient() as client:
            return await asyncio.wait_for(
                get_holehe_results(email, client),
                timeout=overall_timeout,
            )
    except asyncio.TimeoutError:
        print(f"\nomniscan: Holehe scan timed out after {overall_timeout}s")
        return []


def print_holehe_results(holehe_results, *, available_only):
    print("\n" + "=" * DIVIDER_LENGTH)
    print(" " * (DIVIDER_LENGTH // 2 - 6) + Style.BRIGHT + "HOLEHE SCAN" + Style.RESET_ALL)
    print("=" * DIVIDER_LENGTH)

    for email, results in holehe_results.items():
        if results is None:
            continue
        header = (
            f"{'-' * DIVIDER_LENGTH}\n"
            f"{' ' * (DIVIDER_LENGTH // 2 - len(email) // 2)}{Style.BRIGHT}{email}{Style.RESET_ALL}\n"
            f"{'-' * DIVIDER_LENGTH}"
        )
        print(header)

        found = sorted([r for r in results if r.get("exists")], key=lambda r: r["name"].lower())
        not_found = [r for r in results if not r.get("exists") and not r.get("rateLimit")]
        rate_limited = [r for r in results if r.get("rateLimit")]

        if not available_only:
            for r in found:
                line = COLOUR_UNAVAILABLE.Primary + r["name"]
                extras = []
                if r.get("emailrecovery"):
                    extras.append(f"recovery: {r['emailrecovery']}")
                if r.get("phoneNumber"):
                    extras.append(f"phone: {r['phoneNumber']}")
                if extras:
                    line += COLOUR_UNAVAILABLE.Secondary + f" ({', '.join(extras)})"
                print(line)
        else:
            for r in sorted(not_found, key=lambda r: r["name"].lower()):
                print(COLOUR_AVAILABLE.Primary + r["name"])

        if not available_only:
            print(
                f"\n{COLOUR_UNAVAILABLE.Primary}{len(found)} found"
                f"{Fore.RESET}, {COLOUR_AVAILABLE.Primary}{len(not_found)} not registered"
                f"{Fore.RESET}, {COLOUR_ERROR.Primary}{len(rate_limited)} rate limited"
            )


async def _run_subprocess_tool(cmd, overall_timeout):
    import subprocess
    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True),
            timeout=overall_timeout,
        )
        return (result.stdout + result.stderr).strip()
    except asyncio.TimeoutError:
        print(f"\nomniscan: {cmd[0]} timed out after {overall_timeout}s")
        return None


def _find_tool(name):
    import os
    import shutil
    tool = shutil.which(name)
    if not tool:
        bin_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        candidate = os.path.join(bin_dir, name + (".exe" if sys.platform == "win32" else ""))
        if os.path.exists(candidate):
            tool = candidate
    return tool


def _print_tool_section(title, results):
    pad = DIVIDER_LENGTH // 2 - len(title) // 2
    print("\n" + "=" * DIVIDER_LENGTH)
    print(" " * pad + Style.BRIGHT + title + Style.RESET_ALL)
    print("=" * DIVIDER_LENGTH)

    for query_str, output in results.items():
        header = (
            f"{'-' * DIVIDER_LENGTH}\n"
            f"{' ' * (DIVIDER_LENGTH // 2 - len(query_str) // 2)}{Style.BRIGHT}{query_str}{Style.RESET_ALL}\n"
            f"{'-' * DIVIDER_LENGTH}"
        )
        print(header)
        if output:
            print(output)
        else:
            print(COLOUR_ERROR.Primary + "No results returned.")


async def run_maigret(username, overall_timeout=300):
    tool = _find_tool("maigret")
    if not tool:
        print(
            "\nomniscan: Maigret not found.\n"
            "Install: pipx install maigret  or  pip install maigret\n"
            "Then make sure 'maigret' is in your PATH."
        )
        return None
    return await _run_subprocess_tool(
        [tool, username, "--no-color", "--no-progressbar", "--timeout", "30"], overall_timeout
    )


async def run_ghunt(email, overall_timeout=120):
    tool = _find_tool("ghunt")
    if not tool:
        print(
            "\nomniscan: GHunt not found.\n"
            "Install: pipx install ghunt  then run: ghunt login\n"
            "Then make sure 'ghunt' is in your PATH."
        )
        return None
    return await _run_subprocess_tool([tool, "email", email], overall_timeout)


async def main():
    start_time = time.time()
    colorama.init(autoreset=True)
    if sys.version_info >= (3, 7):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = init_parser()
    args = parser.parse_args()

    if args.debug:
        logging.basicConfig(level=logging.DEBUG)
    queries = args.queries
    if args.input:
        with open(args.input, "r") as f:
            for line in f:
                queries.append(line.strip("\n"))
    if not args.queries:
        raise ValueError("You must specify either at least one query or an input file")
    queries = list(dict.fromkeys(queries))
    phone_queries = [q for q in queries if PHONE_REGEX.match(q)]
    queries = [q for q in queries if not PHONE_REGEX.match(q)]
    if phone_queries and not args.phoneinfoga:
        print(
            f"Note: {len(phone_queries)} phone number(s) detected but --phoneinfoga flag not set. "
            "Use -n / --phoneinfoga to scan them."
        )
    if args.platforms:
        platforms = []
        for p in args.platforms:
            if p.upper() in Platforms.__members__:
                platforms.append(Platforms[p.upper()])
            else:
                raise ValueError(p + " is not a valid platform")
    else:
        platforms = [p for p in Platforms]
    proxy_list = []
    if args.proxy_list:
        with open(args.proxy_list, "r") as f:
            for line in f:
                proxy_list.append(line.strip("\n"))
    if args.view_key == "query":
        view_value = "platform"
    elif args.view_key == "platform":
        view_value = "query"

    async with aiohttp.ClientSession() as session:
        checkers = init_checkers(session, proxy_list=proxy_list)
        results = defaultdict(list)
        if args.cache_tokens:
            print("Caching tokens...", end="")
            await asyncio.gather(*(init_prerequest(platform, checkers) for platform in platforms))
            print(end="\r")
        platform_queries = [query(q, p, checkers) for q in queries for p in platforms]
        for future in tqdm.tqdm(
            asyncio.as_completed(platform_queries),
            total=len(platform_queries),
            disable=args.verbose or args.debug,
            leave=False,
            ncols=BAR_WIDTH,
            bar_format=BAR_FORMAT,
        ):
            platform_response = await future
            if platform_response is None:
                continue
            if args.verbose:
                print(platform_response, getattr(platform_response, args.view_key))
                print(
                    f"Checked {platform_response.query: ^25} on {platform_response.platform.value.__name__:<10}: {platform_response.message}"
                )
            results[str(getattr(platform_response, args.view_key))].append(platform_response)

    if args.json:
        print_json(results, file=args.json, available_only=args.available_only)
    else:
        pretty_print(
            results,
            view_value=view_value,
            available_only=args.available_only,
            show_urls=args.show_urls,
        )
    print(f"Completed {len(platform_queries)} queries in {time.time() - start_time:.2f}s")

    if args.sherlock:
        username_queries = [q for q in queries if not EMAIL_REGEX.match(q)]
        if username_queries:
            print("\nRunning Sherlock scan (this may take a moment)...")
            sherlock_results = {}
            for uq in username_queries:
                sherlock_results[uq] = await run_sherlock(uq)
            print_sherlock_results(
                sherlock_results,
                available_only=args.available_only,
                show_urls=args.show_urls,
            )
        else:
            print("\n[Sherlock] Skipped: Sherlock only supports username queries, not email addresses.")

    if args.phoneinfoga and phone_queries:
        print("\nRunning PhoneInfoga scan (this may take a moment)...")
        phoneinfoga_results = {}
        for pq in phone_queries:
            phoneinfoga_results[pq] = await run_phoneinfoga(pq)
        print_phoneinfoga_results(phoneinfoga_results)
    elif args.phoneinfoga and not phone_queries:
        print("\n[PhoneInfoga] Skipped: no phone numbers detected in queries (expected format: +12025551234).")

    email_queries = [q for q in queries if EMAIL_REGEX.match(q)]
    username_queries = [q for q in queries if not EMAIL_REGEX.match(q)]

    if args.holehe:
        if email_queries:
            print("\nRunning Holehe scan (this may take a moment)...")
            holehe_results = {}
            for eq in email_queries:
                holehe_results[eq] = await run_holehe(eq)
            print_holehe_results(holehe_results, available_only=args.available_only)
        else:
            print("\n[Holehe] Skipped: Holehe only scans email addresses.")

    if args.maigret:
        if username_queries:
            print("\nRunning Maigret scan (this may take a few minutes)...")
            maigret_results = {}
            for uq in username_queries:
                maigret_results[uq] = await run_maigret(uq)
            _print_tool_section("MAIGRET SCAN", maigret_results)
        else:
            print("\n[Maigret] Skipped: Maigret only scans usernames.")

    if args.ghunt:
        if email_queries:
            print("\nRunning GHunt scan (this may take a moment)...")
            ghunt_results = {}
            for eq in email_queries:
                ghunt_results[eq] = await run_ghunt(eq)
            _print_tool_section("GHUNT SCAN", ghunt_results)
        else:
            print("\n[GHunt] Skipped: GHunt only scans email addresses.")
