"""Base review agent with shared functionality for code review agents."""

from abc import abstractmethod
from typing import Any, Dict, Optional

from cicaddy.agent.base import BaseAIAgent
from cicaddy.config.settings import Settings
from cicaddy.delegation.triage import (
    DelegationEntry,
    DelegationPlan,
)
from cicaddy.git.diff_analyzer import DiffAnalyzer
from cicaddy.utils.logger import get_logger

logger = get_logger(__name__)


class BaseReviewAgent(BaseAIAgent):
    """Base class for code review agents with shared review functionality."""

    def __init__(self, settings: Optional[Settings] = None):
        super().__init__(settings)
        self.diff_analyzer: Optional[DiffAnalyzer] = None

    async def initialize(self):
        """Initialize the review agent with diff analyzer."""
        await super().initialize()

        # Initialize diff analyzer with git working directory
        working_dir = getattr(self.settings, "git_working_directory", None)
        self.diff_analyzer = DiffAnalyzer(working_directory=working_dir)

        logger.info(
            "Review agent initialized",
            git_working_directory=working_dir,
            diff_analyzer_available=self.diff_analyzer is not None,
        )

    @abstractmethod
    async def get_diff_content(self) -> str:
        """
        Get the diff content for this review.

        Returns:
            Diff content as string

        Raises:
            NotImplementedError: Must be implemented by subclasses
        """
        pass

    @abstractmethod
    async def get_review_context(self) -> Dict[str, Any]:
        """
        Get review-specific context information.

        Returns:
            Dictionary containing review context

        Raises:
            NotImplementedError: Must be implemented by subclasses
        """
        pass

    async def get_analysis_context(self) -> Dict[str, Any]:
        """
        Gather analysis context including diff and review-specific information.

        Returns:
            Dictionary containing complete analysis context
        """
        if not self.diff_analyzer:
            raise ValueError("Diff analyzer not initialized - call initialize() first")

        logger.info("Gathering analysis context for review")

        # Get diff content
        try:
            diff_content = await self.get_diff_content()
        except Exception as e:
            logger.error(f"Failed to get diff content: {e}")
            diff_content = f"Error retrieving diff: {str(e)}"

        # Get review-specific context
        try:
            review_context = await self.get_review_context()
        except Exception as e:
            logger.error(f"Failed to get review context: {e}")
            review_context = {"error": f"Failed to get review context: {str(e)}"}

        # Get project information if platform analyzer is available
        project_info = {}
        if self.platform_analyzer:
            try:
                project_info = await self.platform_analyzer.get_project_info()
            except Exception as e:
                logger.warning(f"Could not get project info: {e}")
                project_info = {"name": "Unknown Project", "error": str(e)}

        # Combine all context
        context = {
            "project": project_info,
            "diff": diff_content,
            "platform_available": self.platform_analyzer is not None,
            "timestamp": self.start_time.isoformat(),
            "diff_lines": len(diff_content.splitlines()) if diff_content else 0,
            **review_context,  # Merge review-specific context
        }

        logger.info(
            "Analysis context gathered",
            diff_lines=context["diff_lines"],
            analysis_type=context.get("analysis_type", "unknown"),
            platform_available=context["platform_available"],
        )

        return context

    async def get_diff_summary(self) -> Dict[str, Any]:
        """
        Generate a summary of the diff changes.

        Returns:
            Dictionary containing diff statistics and summary
        """
        try:
            diff_content = await self.get_diff_content()

            lines = diff_content.splitlines()
            added_lines = len([line for line in lines if line.startswith("+")])
            removed_lines = len([line for line in lines if line.startswith("-")])
            modified_files = len(
                [line for line in lines if line.startswith("diff --git")]
            )

            return {
                "total_lines": len(lines),
                "added_lines": added_lines,
                "removed_lines": removed_lines,
                "modified_files": modified_files,
                "has_changes": len(lines) > 0,
            }

        except Exception as e:
            logger.error(f"Failed to generate diff summary: {e}")
            return {
                "total_lines": 0,
                "added_lines": 0,
                "removed_lines": 0,
                "modified_files": 0,
                "has_changes": False,
                "error": str(e),
            }

    # Delegation hooks

    def _get_agent_type(self) -> str:
        """Review agents use the 'review' delegation registry."""
        return "review"

    def _get_delegation_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Shape context for review delegation triage.

        Structures diff, MR/PR metadata, and changed files list
        so the triage agent can route to specialized reviewers.
        """
        delegation_ctx: Dict[str, Any] = {}

        # Project info (always included)
        if "project" in context:
            delegation_ctx["project"] = context["project"]

        # Diff content
        if "diff" in context:
            delegation_ctx["diff"] = context["diff"]

        # Changed files list for triage routing
        diff_content = context.get("diff", "")
        if diff_content:
            changed_files = [
                line.split(" b/")[-1]
                for line in diff_content.splitlines()
                if line.startswith("diff --git")
            ]
            delegation_ctx["changed_files"] = changed_files

        # MR/PR metadata (description, title, labels, etc.)
        for key in (
            "mr_description",
            "mr_title",
            "pr_description",
            "pr_title",
            "labels",
            "target_branch",
            "source_branch",
            "analysis_type",
        ):
            if key in context:
                delegation_ctx[key] = context[key]

        # Diff stats
        if "diff_lines" in context:
            delegation_ctx["diff_lines"] = context["diff_lines"]

        return delegation_ctx

    def _post_process_plan(
        self, plan: DelegationPlan, registry: Dict[str, Any]
    ) -> DelegationPlan:
        """Ensure general-reviewer is always included in review plans."""
        from cicaddy.delegation.triage import find_general_agent

        general_name = find_general_agent(registry)

        if general_name is None:
            return plan

        # Check if already in plan
        existing_names = {e.agent_name for e in plan.entries}
        if general_name in existing_names:
            return plan

        # Inject general-reviewer with its registry priority
        spec = registry[general_name]
        plan.entries.append(
            DelegationEntry(
                agent_name=general_name,
                categories=list(spec.categories),
                rationale="Auto-included: baseline code review coverage",
                priority=spec.priority,
            )
        )

        # Re-sort by priority to maintain ordering invariant
        plan.entries.sort(key=lambda e: e.priority)

        logger.info(
            f"Post-process: injected '{general_name}' into delegation plan "
            f"(priority={spec.priority})"
        )

        return plan

    def _validate_initialized(self):
        """Validate that the agent is properly initialized."""
        if not self.diff_analyzer:
            raise ValueError(
                "Review agent not properly initialized - diff analyzer missing"
            )
