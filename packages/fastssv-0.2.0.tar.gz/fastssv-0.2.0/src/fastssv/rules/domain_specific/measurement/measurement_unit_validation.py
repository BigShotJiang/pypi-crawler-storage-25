"""Measurement Unit Validation Rule.

OMOP semantic rule:
When a query filters measurement.value_as_number against a numeric threshold,
it must also constrain unit_concept_id.

The measurement table stores numeric results alongside their units. The same
clinical concept (e.g. blood glucose, HbA1c) can be recorded in different
units across source systems and ETL pipelines:

    Blood glucose: 5.5 (mmol/L) vs 100 (mg/dL)
    HbA1c: 7.0 (%) vs 53 (mmol/mol)

Filtering on a numeric threshold without specifying the unit means both
representations are tested against the same cutoff, silently including or
excluding patients based on which unit convention was used at their site.

Correct pattern:
    WHERE m.value_as_number > 7.0
      AND m.unit_concept_id = 8554  -- % (UCUM)
"""

from typing import Dict, List, Optional, Tuple

from sqlglot import exp

from fastssv.core.base import Rule, RuleViolation, Severity
from fastssv.core.helpers import (
    extract_aliases,
    is_in_where_or_join_clause,
    normalize_name,
    parse_sql,
    resolve_table_col,
    has_table_reference,
)
from fastssv.core.patch import add as patch_add, locate
from fastssv.core.registry import register

# Comparison operators that indicate a numeric threshold filter
_NUMERIC_COMPARISON_TYPES = (exp.GT, exp.GTE, exp.LT, exp.LTE, exp.EQ)


def _find_value_as_number_threshold(
    tree: exp.Expression,
    aliases: Dict[str, str],
) -> Optional[Tuple[exp.Expression, Optional[str]]]:
    """Return ``(predicate_node, qualifier)`` for the first value_as_number
    threshold filter, or None.

    ``qualifier`` is the alias-or-table written next to the column in the
    source SQL (e.g. ``m`` from ``m.value_as_number``); None if the column
    was unqualified. The caller uses this to build a structured patch.

    Handles both aliased (m.value_as_number > 7) and unqualified
    (value_as_number > 7) column references, and both comparison directions.
    """
    for node in tree.find_all(_NUMERIC_COMPARISON_TYPES):
        if not is_in_where_or_join_clause(node):
            continue

        left, right = node.left, node.right

        # Check both orientations: col OP literal and literal OP col
        for col_side, val_side in ((left, right), (right, left)):
            if not isinstance(col_side, exp.Column):
                continue

            # Accept numeric literals and negated literals (e.g. -1.5)
            if not isinstance(val_side, (exp.Literal, exp.Neg)):
                continue

            # Confirm the literal side is numeric (not a string)
            literal = val_side if isinstance(val_side, exp.Literal) else val_side.this
            if not isinstance(literal, exp.Literal) or not literal.is_number:
                continue

            table, col = resolve_table_col(col_side, aliases)
            if normalize_name(col) != "value_as_number":
                continue

            # Accept if column is unqualified (only measurement in scope)
            # or explicitly from measurement
            if table is None or normalize_name(table) == "measurement":
                qualifier = (
                    normalize_name(col_side.table) if col_side.table else None
                )
                return node, qualifier

    # Also handle: value_as_number BETWEEN low AND high
    for node in tree.find_all(exp.Between):
        if not is_in_where_or_join_clause(node):
            continue
        col_node = node.this
        if not isinstance(col_node, exp.Column):
            continue
        low = node.args.get("low")
        high = node.args.get("high")
        if not (isinstance(low, (exp.Literal, exp.Neg)) and isinstance(high, (exp.Literal, exp.Neg))):
            continue
        for side in (low, high):
            literal = side if isinstance(side, exp.Literal) else side.this
            if not (isinstance(literal, exp.Literal) and literal.is_number):
                break
        else:
            table, col = resolve_table_col(col_node, aliases)
            if normalize_name(col) != "value_as_number":
                continue
            if table is None or normalize_name(table) == "measurement":
                qualifier = (
                    normalize_name(col_node.table) if col_node.table else None
                )
                return node, qualifier

    return None


def _has_unit_concept_constraint(tree: exp.Expression) -> bool:
    """Return True if unit_concept_id participates in a WHERE or JOIN condition.

    We intentionally require unit_concept_id to appear in a filtering/join context,
    not just in the SELECT list. This aligns with the rule's goal of ensuring the
    numeric threshold is evaluated under an explicit unit constraint, rather than
    merely being aware of the column's existence.
    """
    for col in tree.find_all(exp.Column):
        if normalize_name(col.name) == "unit_concept_id" and is_in_where_or_join_clause(col):
            return True
    return False


@register
class MeasurementUnitValidationRule(Rule):
    """Detects numeric measurement threshold filters missing a unit_concept_id constraint."""

    rule_id = "domain_specific.measurement_unit_validation"
    name = "Measurement Unit Validation"
    description = (
        "Detects queries that filter measurement.value_as_number against a numeric "
        "threshold without also constraining unit_concept_id. The same measurement "
        "concept can be stored in different units across sites (e.g. glucose in "
        "mmol/L vs mg/dL). A numeric threshold applied without a unit filter silently "
        "mixes patients measured in different unit conventions."
    )
    severity = Severity.WARNING
    suggested_fix = "ADD: `AND m.unit_concept_id = <unit_concept_id>` alongside any numeric threshold on m.value_as_number. Look up the UCUM concept_id: `SELECT concept_id FROM concept WHERE concept_code = '<ucum_code>' AND vocabulary_id = 'UCUM' AND invalid_reason IS NULL`."
    example_bad = (
        "SELECT m.person_id FROM measurement m\n"
        "WHERE m.measurement_concept_id = 3004249\n"
        "  AND m.value_as_number > 140;"
    )
    example_good = (
        "SELECT m.person_id FROM measurement m\n"
        "WHERE m.measurement_concept_id = 3004249\n"
        "  AND m.value_as_number > 140\n"
        "  AND m.unit_concept_id = 8876;"
    )

    def validate(self, sql: str, dialect: str = "postgres") -> List[RuleViolation]:
        """Validate SQL and return list of violations."""
        violations = []

        trees, parse_error = parse_sql(sql, dialect)
        if parse_error:
            return []

        for tree in trees:
            if tree is None:
                continue

            # Only examine queries that reference the measurement table
            if not has_table_reference(tree, "measurement"):
                continue

            aliases = extract_aliases(tree)

            threshold = _find_value_as_number_threshold(tree, aliases)
            if threshold is None:
                continue

            if _has_unit_concept_constraint(tree):
                continue

            predicate_node, qualifier = threshold

            # Structured patch: ADD `AND <qualifier>.unit_concept_id =
            # <unit_concept_id>` immediately after the offending threshold
            # predicate. The unit value is left as a `<unit_concept_id>`
            # placeholder for the outer correction loop. If the predicate
            # isn't uniquely locatable, fall back to FREEFORM via auto-default.
            patch = None
            qual = qualifier or "measurement"
            span = locate(sql, predicate_node.sql())
            if span is not None:
                patch = patch_add(
                    span[1],
                    f" AND {qual}.unit_concept_id = <unit_concept_id>",
                )

            violations.append(self.create_violation(
                message=(
                    "Query filters measurement.value_as_number against a numeric "
                    "threshold without constraining unit_concept_id. The same "
                    "measurement concept can be stored in different units across "
                    "sites (e.g. glucose: 5.5 mmol/L vs 100 mg/dL), making the "
                    "numeric threshold unreliable without a unit filter."
                ),
                details={
                    "column": "measurement.value_as_number",
                    "missing": "unit_concept_id constraint",
                },
                suggested_fix_patch=patch,
            ))

        return violations


__all__ = ["MeasurementUnitValidationRule"]
