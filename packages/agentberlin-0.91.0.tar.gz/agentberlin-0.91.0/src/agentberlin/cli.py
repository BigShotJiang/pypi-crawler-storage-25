"""Command-line interface for Agent Berlin SDK.

This module provides CLI commands for managing workflows, uploading outputs,
and executing workflow scripts.
"""

import importlib.util
import json
import os
import secrets
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

import click
import requests

from . import __version__
from .config import DEFAULT_BASE_URL
from .session import configure_session as _configure_session
from .session import load_session_config


@click.group()
@click.version_option(version=__version__, prog_name="agentberlin")
def main() -> None:
    """Agent Berlin CLI - Manage workflows."""
    pass


@main.command()
@click.option("--token", "-t", required=True, help="Authentication token from get_auth_token MCP tool")
@click.option("--domain", "-d", required=True, help="Project domain (e.g., example.com)")
@click.option("--config-path", help="Custom config file path")
def configure(token: str, domain: str, config_path: Optional[str]) -> None:
    """Configure session credentials for Agent Berlin."""
    _configure_session(token, domain, config_path)
    click.echo(f"Session configured for domain: {domain}")


@main.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--description", "-d", required=True, help="Output description")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def save_output(
    file_path: str,
    description: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Upload a JSON file as an output to Agent Berlin.

    FILE_PATH is the path to the JSON file to upload. The file must have a
    ``.json`` extension and contain valid JSON.

    This uploads the file to Agent Berlin's storage and registers it
    so users can download it from the Agent Berlin UI.
    """
    # Resolve token and project_domain from config
    config = load_session_config()

    if not token:
        token = config.get("token")

    if not token:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")

    if not project_domain:
        project_domain = config.get("project_domain")

    if not project_domain:
        raise click.ClickException("No project domain found. Use --project-domain or configure session first.")

    source = Path(file_path)
    if not source.exists():
        raise click.ClickException(f"File not found: {file_path}")

    if source.suffix.lower() != ".json":
        raise click.ClickException("Only JSON outputs are supported. File must have a .json extension.")

    try:
        json.loads(source.read_bytes())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Output file does not contain valid JSON: {e}")

    # Upload file to backend API
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{base_url}/outputs/upload"

    try:
        with open(source, "rb") as f:
            files = {"file": (source.name, f, "application/json")}
            form_data = {"description": description, "project_domain": project_domain}
            resp = requests.post(url, headers=headers, files=files, data=form_data, timeout=120)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_msg = resp.json().get("error", "Bad request")
        raise click.ClickException(f"Upload failed: {error_msg}")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    result = resp.json()
    click.echo(f"Output uploaded: {source.name}")
    click.echo(f"Description: {description}")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


def _resolve_project_domain(project_domain: Optional[str]) -> str:
    """Resolve project_domain from CLI arg or session config."""
    if project_domain:
        return project_domain
    config = load_session_config()
    resolved = config.get("project_domain")
    if not resolved:
        raise click.ClickException(
            "No project domain found. Use --project-domain or configure session first."
        )
    return resolved


@main.group("brand-files")
def brand_files_group() -> None:
    """List and download brand context files (keywords, prompts, brand tone, etc.)."""
    pass


@brand_files_group.command("list")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a table")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_files_list(
    project_domain: Optional[str],
    token: Optional[str],
    as_json: bool,
    base_url: str,
) -> None:
    """List all brand files attached to the project."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    _handle_api_error(resp, "Brand file list")
    files = resp.json().get("files", [])

    if as_json:
        click.echo(json.dumps(files, indent=2))
        return

    if not files:
        click.echo("No brand files found.")
        return

    id_w = max(len("ID"), max(len(f["id"]) for f in files))
    name_w = max(len("FILENAME"), max(len(f["filename"]) for f in files))
    click.echo(f"{'ID':<{id_w}}  {'FILENAME':<{name_w}}  {'SIZE':>10}  DESCRIPTION")
    for f in files:
        size_kb = f.get("size_bytes", 0) / 1024
        size_str = f"{size_kb:.1f} KB"
        desc = f.get("description", "") or ""
        click.echo(f"{f['id']:<{id_w}}  {f['filename']:<{name_w}}  {size_str:>10}  {desc}")


@brand_files_group.command("download")
@click.argument("file_id")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path. Defaults to the original filename in the current directory.",
)
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_files_download(
    file_id: str,
    project_domain: Optional[str],
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a brand file's contents by its ID.

    FILE_ID is the file identifier shown by `agentberlin brand-files list`.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/content",
            headers=headers,
            json={"project_domain": project_domain, "file_id": file_id},
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Brand file '{file_id}' not found.")
    _handle_api_error(resp, "Brand file download")

    if output:
        out_path = Path(output)
    else:
        # Extract filename from Content-Disposition, fall back to file_id.
        disposition = resp.headers.get("Content-Disposition", "")
        filename = file_id
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        out_path = Path.cwd() / filename

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(resp.content)
    click.echo(f"Downloaded: {out_path} ({len(resp.content)} bytes)")


WORKFLOW_GROUP_HELP = """Manage workflows (create, update, publish).

\b
Commands:
  create    Create a new workflow from a natural-language spec
  update    Update metadata of an existing workflow (name, description, details, schedule)
  publish   Push a built file (e.g. main.py) onto the latest version of a workflow

`create` and `update` read from the same manifest file. Editing `details` on an
existing workflow (via `update`) bumps the workflow version and flags it for
rebuild by the builder. `publish` is intended for the workflow_builder agent
running in a sandbox; it does not use the manifest format.

MANIFEST FILE FORMAT
====================

The manifest is a JSON file that defines your workflow metadata:

\b
{
  "name": "My Workflow",
  "description": "Optional description",
  "id": "wfl_abc123xyz",
  "details": "Natural-language spec describing what the workflow does",
  "schedule": {"type": "cron", "cron_expression": "...", "timezone": "UTC"}
}

REQUIRED FIELDS
===============
  name  - Workflow name (always required)
  id    - Required by `update`; absent for `create`

OPTIONAL FIELDS
===============
  description - Workflow description
  details     - Natural-language spec describing what the workflow should do.
                The builder turns this into an executable spec on the server.
  schedule    - {type: "cron"|"one_time"|"manual", cron_expression?, timezone?}

DETAILS
=======
`details` is the most important field. Be thorough: cover data sources,
analysis logic, outputs, and any thresholds or decision criteria. The builder
uses this to generate the executable workflow spec.

SCHEDULE
========
`schedule.type` may be "cron", "one_time", or "manual". Schedules are stored
disabled and start running only after the workflow reaches the "ready" phase.

EXAMPLE
=======

\b
# plan.json
{
  "name": "Weekly Keyword Rank Tracking",
  "description": "Track target keyword positions weekly",
  "details": "Read target keywords from the keywords resource. Every Monday query GSC for rank data for the past 7 days. Flag any keyword that dropped more than 3 positions WoW. Write a summary CSV and email it to the SEO lead.",
  "schedule": { "type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC" }
}

\b
agentberlin workflow create --manifest plan.json
# Later revise details or schedule:
agentberlin workflow update --manifest plan.json
"""


def _handle_api_error(resp: requests.Response, context: str = "API request") -> None:
    """Handle API error responses with appropriate messages."""
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_data = resp.json()
        # Check for validation errors (syntax/type check failures)
        if "validation_errors" in error_data:
            click.echo("Script validation failed:", err=True)
            for err in error_data["validation_errors"]:
                click.echo(f"  - {err}", err=True)
            raise click.ClickException("Fix the errors above and try again")
        error_msg = error_data.get("error", "Bad request")
        raise click.ClickException(f"{context} failed: {error_msg}")
    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"{context} failed: {e}")


def _resolve_token(token: Optional[str]) -> str:
    """Resolve API token from CLI arg, env, or session config."""
    if token:
        return token
    config = load_session_config()
    resolved = config.get("token")
    if not resolved:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")
    return resolved


def _load_manifest(manifest: str) -> tuple[dict[str, Any], Path, Path]:
    """Load a manifest JSON file. Returns (data, path, parent_dir)."""
    manifest_path = Path(manifest)
    try:
        data = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid manifest JSON: {e}")
    if not isinstance(data, dict):
        raise click.ClickException("Manifest must be a JSON object")
    if not data.get("name"):
        raise click.ClickException("manifest must include 'name' field")
    return data, manifest_path, manifest_path.parent


def _build_metadata_payload(manifest_data: dict[str, Any]) -> dict[str, Any]:
    """Extract metadata fields (name, description, details, schedule) from a manifest.

    Only includes keys that are present and non-empty. Used as the body for both
    POST /workflows and PATCH /workflows/:id.
    """
    payload: dict[str, Any] = {"name": manifest_data["name"]}
    description = manifest_data.get("description")
    if description:
        payload["description"] = description
    details = manifest_data.get("details")
    if details:
        payload["details"] = details
    schedule = manifest_data.get("schedule")
    if schedule:
        payload["schedule"] = schedule
    return payload


def _post_create_workflow(base_url: str, headers: dict[str, str], payload: dict[str, Any]) -> str:
    """Call POST /workflows. Returns the new workflow_id."""
    try:
        resp = requests.post(f"{base_url}/workflows", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Workflow creation")
    return resp.json()["workflow_id"]


def _patch_workflow(
    base_url: str, headers: dict[str, str], workflow_id: str, payload: dict[str, Any]
) -> dict[str, Any]:
    """Call PATCH /workflows/:id. Returns the response JSON."""
    try:
        resp = requests.patch(f"{base_url}/workflows/{workflow_id}", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found.")
    _handle_api_error(resp, "Workflow update")
    return resp.json()


def _post_publish_workflow_version(
    base_url: str,
    headers: dict[str, str],
    workflow_id: str,
    files_map: dict[str, str],
) -> dict[str, Any]:
    """Call POST /workflows/:id/versions/current/files. Returns the response JSON."""
    try:
        resp = requests.post(
            f"{base_url}/workflows/{workflow_id}/versions/current/files",
            headers=headers,
            json={"files": files_map},
            timeout=60,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(
            f"Workflow '{workflow_id}' not found, or no version exists yet."
        )
    _handle_api_error(resp, "Workflow publish")
    return resp.json()


def _write_id_to_manifest(manifest_path: Path, manifest_data: dict[str, Any], workflow_id: str) -> None:
    """Persist the workflow_id back to the manifest file."""
    manifest_data["id"] = workflow_id
    manifest_path.write_text(json.dumps(manifest_data, indent=2))


@main.group("workflow")
def workflow_group() -> None:
    """Manage workflows (create, update, publish)."""
    pass


workflow_group.help = WORKFLOW_GROUP_HELP


_WORKFLOW_CREATE_HELP = """Create a new workflow from a manifest file.

The manifest must NOT include an 'id' field (the id is written back after creation).
Required: 'name'. Optional: 'description', 'details', 'schedule'.

On success, the new 'id' is written back to the manifest file for future
`agentberlin workflow update` calls.

See `agentberlin workflow --help` for the full manifest format reference.
"""


@workflow_group.command("create", help=_WORKFLOW_CREATE_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_create(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, manifest_path, _ = _load_manifest(manifest)

    if manifest_data.get("id"):
        raise click.ClickException(
            "manifest already has an 'id'. Use `agentberlin workflow update` instead."
        )

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    metadata_payload = _build_metadata_payload(manifest_data)
    workflow_id = _post_create_workflow(base_url, headers, metadata_payload)
    _write_id_to_manifest(manifest_path, manifest_data, workflow_id)
    click.echo(f"Created workflow: {manifest_data['name']} ({workflow_id})")


_WORKFLOW_UPDATE_HELP = """Update an existing workflow.

Requires the manifest to have an 'id' field. Sends any of the following fields
present in the manifest: 'name', 'description', 'details', 'schedule'.

When 'details' changes, the backend bumps the workflow version and flags the
workflow for rebuild by the builder.
"""


@workflow_group.command("update", help=_WORKFLOW_UPDATE_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_update(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, _, _ = _load_manifest(manifest)

    workflow_id = manifest_data.get("id")
    if not workflow_id:
        raise click.ClickException(
            "manifest must include 'id'. Use `agentberlin workflow create` for new workflows."
        )

    payload = _build_metadata_payload(manifest_data)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _patch_workflow(base_url, headers, workflow_id, payload)
    click.echo(f"Workflow updated: {result.get('name', manifest_data['name'])} ({workflow_id})")
    phase = result.get("phase")
    if phase:
        click.echo(f"Phase: {phase}")


_WORKFLOW_PUBLISH_HELP = """Publish a built workflow file to the latest version.

Reads the file at --file, sends its contents to the latest workflow_versions row
of the workflow identified by --workflow-id (or the WORKFLOW_ID env var, set
automatically inside the workflow_builder sandbox).

The server stores the file under its basename. Status is not changed by this
call — the agent's terminal-status hook flips the version from `building` to
`ready` when the agent reports done.
"""


@workflow_group.command("publish", help=_WORKFLOW_PUBLISH_HELP)
@click.option(
    "--file",
    "-f",
    "file_path",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
    help="Path to the file to publish (e.g. main.py)",
)
@click.option(
    "--workflow-id",
    envvar="WORKFLOW_ID",
    help="Workflow id. Defaults to the WORKFLOW_ID env var set inside the sandbox.",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_publish(
    file_path: str,
    workflow_id: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    if not workflow_id:
        raise click.ClickException(
            "workflow id is required. Pass --workflow-id or set WORKFLOW_ID."
        )
    token = _resolve_token(token)

    path = Path(file_path)
    try:
        content = path.read_text()
    except OSError as e:
        raise click.ClickException(f"Failed to read {file_path}: {e}")

    files_map = {path.name: content}
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _post_publish_workflow_version(base_url, headers, workflow_id, files_map)
    version = result.get("version")
    if version is not None:
        click.echo(f"Published {path.name} to workflow {workflow_id} (version {version})")
    else:
        click.echo(f"Published {path.name} to workflow {workflow_id}")


REPORT_GROUP_HELP = """Manage reports (create, update, publish).

\b
A report is an HTML viewer paired with a JSON spec. Agents read the spec to
know what shape of data to produce; `report publish` uploads that data as
the live data.json the HTML reads.

\b
Commands:
  create    Register a new report and upload its HTML + spec
  update    Update html, spec, title, or description on an existing report
  publish   Upload a new data.json conforming to the spec
"""


@main.group("report", help=REPORT_GROUP_HELP)
def report_group() -> None:
    pass


def _load_json_file(path: str, field_name: str, require_object: bool) -> None:
    """Validate a path is a readable JSON file (and optionally a top-level object).

    Raises click.ClickException with a friendly message on failure. Does not
    return the parsed JSON — callers upload the raw bytes, this is only a
    fail-fast check before hitting the network.
    """
    p = Path(path)
    if p.suffix.lower() != ".json":
        raise click.ClickException(f"--{field_name} must be a .json file")
    try:
        parsed = json.loads(p.read_bytes())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"--{field_name} is not valid JSON: {e}")
    if require_object and not isinstance(parsed, dict):
        raise click.ClickException(f"--{field_name} must be a JSON object at the top level")


def _check_html_file(path: str, field_name: str) -> None:
    if Path(path).suffix.lower() != ".html":
        raise click.ClickException(f"--{field_name} must be a .html file")


@report_group.command("create")
@click.option("--slug", required=True, help="URL-safe identifier, e.g. 'audit'. Lowercase alphanumeric + hyphens, max 64 chars.")
@click.option("--html", "html_path", type=click.Path(exists=True), required=True, help="Path to the report HTML viewer.")
@click.option("--spec", "spec_path", type=click.Path(exists=True), required=True, help="Path to the JSON spec agents read.")
@click.option("--title", help="Display title for the report.")
@click.option("--description", help="Optional description.")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_create(
    slug: str,
    html_path: str,
    spec_path: str,
    title: Optional[str],
    description: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Create a new report: uploads the HTML viewer and spec, writes the report row."""
    _check_html_file(html_path, "html")
    _load_json_file(spec_path, "spec", require_object=True)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    form: dict[str, str] = {"slug": slug, "project_domain": project_domain}
    if title:
        form["title"] = title
    if description:
        form["description"] = description

    headers = {"Authorization": f"Bearer {token}"}
    try:
        with open(html_path, "rb") as html_f, open(spec_path, "rb") as spec_f:
            files = {
                "file": (Path(html_path).name, html_f, "text/html"),
                "spec": (Path(spec_path).name, spec_f, "application/json"),
            }
            resp = requests.post(
                f"{base_url}/reports", headers=headers, files=files, data=form, timeout=120
            )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 409:
        error_msg = resp.json().get("error", "Report already exists")
        raise click.ClickException(error_msg)
    _handle_api_error(resp, "Report create")

    result = resp.json()
    click.echo(f"Report created: {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


@report_group.command("update")
@click.option("--slug", required=True, help="Slug of the existing report to update.")
@click.option("--html", "html_path", type=click.Path(exists=True), help="New HTML viewer (optional).")
@click.option("--spec", "spec_path", type=click.Path(exists=True), help="New JSON spec (optional).")
@click.option("--title", default=None, help="New title (optional).")
@click.option("--description", default=None, help="New description (optional).")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_update(
    slug: str,
    html_path: Optional[str],
    spec_path: Optional[str],
    title: Optional[str],
    description: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Update an existing report. Provide at least one of --html, --spec, --title, --description."""
    if html_path is None and spec_path is None and title is None and description is None:
        raise click.ClickException(
            "provide at least one of --html, --spec, --title, --description"
        )

    if html_path is not None:
        _check_html_file(html_path, "html")
    if spec_path is not None:
        _load_json_file(spec_path, "spec", require_object=True)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    form: dict[str, str] = {"project_domain": project_domain}
    if title is not None:
        form["title"] = title
    if description is not None:
        form["description"] = description

    headers = {"Authorization": f"Bearer {token}"}
    html_f = open(html_path, "rb") if html_path else None
    spec_f = open(spec_path, "rb") if spec_path else None
    try:
        files: dict[str, tuple[str, Any, str]] = {}
        if html_f is not None and html_path is not None:
            files["file"] = (Path(html_path).name, html_f, "text/html")
        if spec_f is not None and spec_path is not None:
            files["spec"] = (Path(spec_path).name, spec_f, "application/json")
        try:
            resp = requests.patch(
                f"{base_url}/reports/{slug}",
                headers=headers,
                files=files if files else None,
                data=form,
                timeout=120,
            )
        except requests.RequestException as e:
            raise click.ClickException(f"Failed to connect to API: {e}")
    finally:
        if html_f is not None:
            html_f.close()
        if spec_f is not None:
            spec_f.close()

    if resp.status_code == 404:
        raise click.ClickException(f"Report '{slug}' not found. Use `agentberlin report create` first.")
    _handle_api_error(resp, "Report update")

    result = resp.json()
    click.echo(f"Report updated: {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


@report_group.command("publish")
@click.option("--slug", required=True, help="Slug of the report to publish data for.")
@click.option("--data", "data_path", type=click.Path(exists=True), required=True, help="Path to the JSON data file conforming to the spec.")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_publish(
    slug: str,
    data_path: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Publish a new data.json for an existing report."""
    _load_json_file(data_path, "data", require_object=False)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}"}
    try:
        with open(data_path, "rb") as data_f:
            files = {"file": (Path(data_path).name, data_f, "application/json")}
            resp = requests.post(
                f"{base_url}/reports/{slug}/publish",
                headers=headers,
                files=files,
                data={"project_domain": project_domain},
                timeout=120,
            )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Report '{slug}' not found. Use `agentberlin report create` first.")
    _handle_api_error(resp, "Report publish")

    result = resp.json()
    click.echo(f"Report data published: {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


def _load_script_module(script_path: str) -> Any:
    """Dynamically load a Python script as a module.

    Args:
        script_path: Path to the Python script file.

    Returns:
        The loaded module object.

    Raises:
        click.ClickException: If the script cannot be loaded.
    """
    path = Path(script_path)
    if not path.exists():
        raise click.ClickException(f"Script not found: {script_path}")

    if not path.suffix == ".py":
        raise click.ClickException(f"Script must be a Python file (.py): {script_path}")

    spec = importlib.util.spec_from_file_location("_script_module", path)
    if spec is None or spec.loader is None:
        raise click.ClickException(f"Failed to load script: {script_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules["_script_module"] = module

    try:
        spec.loader.exec_module(module)
    except Exception as e:
        raise click.ClickException(f"Failed to execute script: {e}")

    return module


def _find_script_function(module: Any) -> Optional[Callable[..., Any]]:
    """Find the function decorated with @script in a module.

    Args:
        module: The module to search.

    Returns:
        The decorated function, or None if not found.
    """
    script_funcs: list[Callable[..., Any]] = []

    for name in dir(module):
        obj = getattr(module, name)
        if callable(obj) and getattr(obj, "_is_script", False):
            script_funcs.append(obj)

    if len(script_funcs) == 0:
        return None
    if len(script_funcs) > 1:
        names = ", ".join(f.__name__ for f in script_funcs)
        raise click.ClickException(f"Multiple @script decorators found: {names}. Only one is allowed per script.")

    return script_funcs[0]


def _get_max_depth(schema: dict[str, Any], current_depth: int = 0) -> int:
    """Calculate the maximum nesting depth of a JSON schema.

    Args:
        schema: The JSON schema to analyze.
        current_depth: Current depth in the traversal.

    Returns:
        The maximum nesting depth.
    """
    max_depth = current_depth

    # Check properties (object nesting)
    if "properties" in schema:
        for prop_schema in schema["properties"].values():
            if isinstance(prop_schema, dict):
                prop_depth = _get_max_depth(prop_schema, current_depth + 1)
                max_depth = max(max_depth, prop_depth)

    # Check array items
    if "items" in schema and isinstance(schema["items"], dict):
        items_depth = _get_max_depth(schema["items"], current_depth + 1)
        max_depth = max(max_depth, items_depth)

    # Check additionalProperties (for dict types)
    if "additionalProperties" in schema and isinstance(schema["additionalProperties"], dict):
        add_props_depth = _get_max_depth(schema["additionalProperties"], current_depth + 1)
        max_depth = max(max_depth, add_props_depth)

    return max_depth


def _has_recursive_refs(schema: dict[str, Any], seen_refs: Optional[set[str]] = None) -> bool:
    """Check if a schema has recursive type definitions.

    Args:
        schema: The JSON schema to check.
        seen_refs: Set of refs already seen in this path.

    Returns:
        True if recursive refs are found.
    """
    if seen_refs is None:
        seen_refs = set()

    # Check for $ref
    if "$ref" in schema:
        ref = schema["$ref"]
        if ref in seen_refs:
            return True
        seen_refs = seen_refs | {ref}

    # Recursively check nested schemas
    for key in ["properties", "items", "additionalProperties"]:
        if key in schema:
            value = schema[key]
            if isinstance(value, dict):
                if key == "properties":
                    for prop_schema in value.values():
                        if isinstance(prop_schema, dict):
                            if _has_recursive_refs(prop_schema, seen_refs):
                                return True
                else:
                    if _has_recursive_refs(value, seen_refs):
                        return True

    return False


def _validate_schema_complexity(schema: dict[str, Any]) -> list[str]:
    """Validate that a schema isn't too complex for LLMs.

    Checks:
    - Maximum nesting depth of 2 levels
    - No recursive type definitions
    - Reasonable parameter count (max 10)

    Args:
        schema: The JSON schema to validate.

    Returns:
        List of error messages. Empty if valid.
    """
    errors: list[str] = []

    # Rule 1: Max nesting depth of 2 levels
    max_depth = _get_max_depth(schema)
    if max_depth > 2:
        errors.append(
            f"Schema nesting depth is {max_depth}, max allowed is 2. "
            "Flatten your parameters - use simple types (str, int, bool, list[str]) "
            "instead of nested dicts."
        )

    # Rule 2: No recursive types
    if _has_recursive_refs(schema):
        errors.append("Recursive type definitions are not supported by LLMs.")

    return errors


@main.command(name="extract-schema")
@click.argument("script_path", type=click.Path(exists=True))
def extract_schema(script_path: str) -> None:
    """Extract the JSON schema from a @script-decorated function.

    SCRIPT_PATH is the path to the Python script file.

    This command loads the script, finds the @script decorated function,
    and outputs its parameter schema as JSON to stdout.

    Exit codes:
        0: Success
        1: No @script decorator found (legacy script)
        2: Multiple @script decorators found
        3: Schema validation failed (too complex)
    """
    module = _load_script_module(script_path)
    func = _find_script_function(module)

    if func is None:
        click.echo(
            "ERROR: No @script decorator found in this script.\n\n"
            "This script uses the legacy INPUT variable pattern which is no longer supported.\n\n"
            "REQUIRED ACTION: This workflow/agent must be upgraded before execution.\n"
            "DO NOT attempt to run this workflow. Instead, upgrade it to use the @script decorator pattern.\n\n"
            "Example of required format:\n"
            "  from agentberlin import AgentBerlin, script\n\n"
            "  @script\n"
            "  def main(param1: str, param2: int = 10):\n"
            "      # script logic\n",
            err=True,
        )
        raise SystemExit(1)

    schema = getattr(func, "_script_schema", {})

    # Validate schema complexity
    complexity_errors = _validate_schema_complexity(schema)
    if complexity_errors:
        click.echo("ERROR: Schema is too complex for LLM tools:\n", err=True)
        for err in complexity_errors:
            click.echo(f"  - {err}", err=True)
        click.echo(
            "\nSimplify your function parameters to use basic types " "(str, int, float, bool, list[str]).",
            err=True,
        )
        raise SystemExit(3)

    # Output schema as JSON
    click.echo(json.dumps(schema, indent=2))


@main.command()
@click.argument("script_path", type=click.Path(exists=True))
@click.option(
    "--input",
    "-i",
    "input_json",
    help="Inline JSON string with input parameters (for simple inputs)",
)
@click.option(
    "--input-file",
    "-f",
    "input_file",
    type=click.Path(exists=True),
    help="Path to JSON file with input parameters (for complex/large inputs)",
)
def run(script_path: str, input_json: Optional[str], input_file: Optional[str]) -> None:
    """Execute a @script-decorated Python function from a workflow.

    SCRIPT_PATH is the path to the Python script file.

    \b
    Logging:
      On startup, prints the log file path: [LOG] ~/.agentberlin/logs/<run_id>.log
      Scripts can write progress via the log() function from agentberlin.
      For long-running operations, monitor progress by reading or tailing this file:
        tail -f <log_path>

    \b
    Input options (use one or neither):
      --input, -i     Inline JSON string (e.g., --input '{"url": "example.com"}')
      --input-file, -f  Path to JSON file (e.g., --input-file params.json)

    Use --input for simple parameters, --input-file for complex or large inputs.

    \b
    Exit codes:
        0: Success
        1: No @script decorator found
        2: Execution error
    """
    if input_json and input_file:
        raise click.ClickException("Cannot use both --input and --input-file")

    module = _load_script_module(script_path)
    func = _find_script_function(module)

    if func is None:
        click.echo(
            "ERROR: This script uses the legacy INPUT variable pattern which is no longer supported.\n\n"
            "REQUIRED ACTION: This workflow/agent must be upgraded before execution.\n"
            "DO NOT attempt to run this workflow. Instead, upgrade it to use the @script decorator pattern.\n\n"
            "Example of required format:\n"
            "  from agentberlin import AgentBerlin, script\n\n"
            "  @script\n"
            "  def main(param1: str, param2: int = 10):\n"
            "      # script logic\n",
            err=True,
        )
        raise SystemExit(1)

    # Parse input if provided (from --input or --input-file)
    kwargs: dict[str, Any] = {}
    if input_json:
        try:
            kwargs = json.loads(input_json)
        except json.JSONDecodeError as e:
            raise click.ClickException(f"Invalid JSON in --input: {e}")
        if not isinstance(kwargs, dict):
            raise click.ClickException("Input JSON must be an object (dict)")
    elif input_file:
        try:
            with open(input_file) as f:
                kwargs = json.load(f)
        except json.JSONDecodeError as e:
            raise click.ClickException(f"Invalid JSON in input file: {e}")
        except Exception as e:
            raise click.ClickException(f"Failed to read input file: {e}")
        if not isinstance(kwargs, dict):
            raise click.ClickException("Input JSON must be an object (dict)")

    # Set up logging for the run
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + secrets.token_hex(2)
    log_dir = Path.home() / ".agentberlin" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{run_id}.log"

    # Set the log path environment variable for the log() function
    os.environ["AGENTBERLIN_LOG_PATH"] = str(log_path)

    # Print the log path so agents can monitor progress
    click.echo(f"[LOG] {log_path}")

    # Execute the function
    try:
        func(**kwargs)
    except TypeError as e:
        # Handle missing required arguments or unexpected arguments
        raise click.ClickException(f"Argument error: {e}")
    except Exception as e:
        click.echo(f"Script execution failed: {e}", err=True)
        raise SystemExit(2)


if __name__ == "__main__":
    main()
