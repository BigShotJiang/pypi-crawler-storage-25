"""CLI interface for pipu using rich_click."""

import json
import logging
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Optional

import rich_click as click
from click.core import ParameterSource
from rich.console import Console
from rich.logging import RichHandler
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table

from pipu_cli.package_management import (
    BlockedPackageInfo,
    Package,
    _parse_package_name,
    inspect_installed_packages,
    get_latest_versions,
    get_latest_versions_parallel,
    resolve_upgradable_packages,
    resolve_upgradable_packages_with_reasons,
    reinstall_editable_packages,
    run_pip_install,
    run_pip_uninstall,
)
from packaging.utils import canonicalize_name
from packaging.version import Version
from pipu_cli.pretty import (
    print_upgradable_packages_table,
    print_upgrade_results,
    print_install_results,
    print_uninstall_results,
    print_blocked_packages_table,
    ConsoleStream,
    select_packages_interactively,
)
from pipu_cli.output import JsonOutputFormatter
from pipu_cli.ui import UpgradeUI
from pipu_cli.download import download_packages, install_from_local
from pipu_cli.config_file import load_config, get_config_value
from pipu_cli.groups import (
    add_environment,
    remove_environment,
    delete_group,
    list_groups,
    get_group,
    validate_python_path,
)
from pipu_cli.config import DEFAULT_CACHE_TTL
from pipu_cli.cache import (
    is_cache_fresh,
    load_cache,
    save_cache,
    build_version_cache,
    get_cache_info,
    format_cache_age,
    get_cache_age_seconds,
    clear_cache,
    clear_all_caches,
)


# Configure rich_click
click.rich_click.USE_RICH_MARKUP = True
click.rich_click.SHOW_ARGUMENTS = True
click.rich_click.GROUP_ARGUMENTS_OPTIONS = True


def parse_package_spec(spec: str) -> tuple[str, Optional[str]]:
    """Parse a package specification like 'requests==2.31.0' or 'requests>=2.30'.

    :param spec: Package specification string
    :returns: Tuple of (package_name, version_constraint or None)
    """
    # Common specifier patterns (check longest operators first to avoid partial matches)
    for op in ['==', '>=', '<=', '~=', '!=', '>', '<']:
        if op in spec:
            parts = spec.split(op, 1)
            return (parts[0].strip(), op + parts[1].strip())

    return (spec.strip(), None)


@click.group(invoke_without_command=True)
@click.version_option(package_name="pipu-cli", message="%(version)s")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """
    [bold cyan]pipu[/bold cyan] - A cute Python package updater

    Automatically checks for package updates and upgrades them with proper
    constraint resolution.

    Running [cyan]pipu[/cyan] with no subcommand defaults to [cyan]pipu upgrade[/cyan].

    Run [cyan]pipu <command> --help[/cyan] for command-specific help.
    """
    # If no subcommand provided, default to upgrade
    if ctx.invoked_subcommand is None:
        ctx.invoke(upgrade)


@cli.command()
@click.pass_context
@click.option(
    "--timeout",
    type=int,
    default=10,
    help="Network timeout in seconds for package queries"
)
@click.option(
    "--pre",
    is_flag=True,
    help="Include pre-release versions"
)
@click.option(
    "--parallel", "-p",
    type=int,
    default=min(4, mp.cpu_count()),
    help=f"Number of parallel requests for version checking (default: {min(4, mp.cpu_count())})"
)
@click.option(
    "--debug",
    is_flag=True,
    help="Enable debug logging"
)
@click.option(
    "--output", "-o",
    type=click.Choice(["human", "json"]),
    default="human",
    help="Output format (human-readable or json)"
)
def update(ctx: click.Context, timeout: int, pre: bool, parallel: int, debug: bool, output: str) -> None:
    """
    Refresh the package version cache.

    Fetches the latest version information from PyPI for all installed
    packages and stores it locally. This speeds up subsequent upgrade
    commands by avoiding repeated network requests.

    Constraint resolution is performed at upgrade time, not during update.

    \b
    Examples:
      pipu update              Update cache with defaults
      pipu update --parallel 4 Update with parallel requests
      pipu update --pre        Include pre-release versions
    """
    console = Console()

    # Load configuration file
    config = load_config()
    if ctx.get_parameter_source('timeout') == ParameterSource.DEFAULT:
        timeout = get_config_value(config, 'timeout', 10)
    if ctx.get_parameter_source('pre') == ParameterSource.DEFAULT:
        pre = get_config_value(config, 'pre', False)
    if ctx.get_parameter_source('debug') == ParameterSource.DEFAULT:
        debug = get_config_value(config, 'debug', False)
    if ctx.get_parameter_source('parallel') == ParameterSource.DEFAULT:
        parallel = get_config_value(config, 'parallel', min(4, mp.cpu_count()))
    if ctx.get_parameter_source('output') == ParameterSource.DEFAULT:
        output = get_config_value(config, 'output', 'human')

    # Configure logging
    if debug and output != "json":
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(message)s',
            handlers=[RichHandler(console=console, show_time=False, show_path=False, markup=True)]
        )
        logging.getLogger('pip._internal').setLevel(logging.WARNING)
        logging.getLogger('pip._vendor').setLevel(logging.WARNING)
        console.print("[dim]Debug mode enabled[/dim]\n")

    try:
        # Step 1: Inspect installed packages
        if output != "json":
            console.print("[bold]Step 1/2:[/bold] Inspecting installed packages...")

        step1_start = time.time()
        if output != "json":
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
                transient=True
            ) as progress:
                task = progress.add_task("Loading packages...", total=None)
                installed_packages = inspect_installed_packages(timeout=timeout)
                progress.update(task, completed=True)
        else:
            installed_packages = inspect_installed_packages(timeout=timeout)
        step1_time = time.time() - step1_start

        num_installed = len(installed_packages)
        if output != "json":
            console.print(f"  Found {num_installed} installed packages")
            if debug:
                console.print(f"  [dim]Time: {step1_time:.2f}s[/dim]")

        if not installed_packages:
            if output == "json":
                print('{"error": "No packages found"}')
            else:
                console.print("[yellow]No packages found.[/yellow]")
            sys.exit(0)

        # Step 2: Fetch latest versions from PyPI and save to cache
        if output != "json":
            console.print("\n[bold]Step 2/2:[/bold] Fetching latest versions from PyPI...")

        step2_start = time.time()
        if output != "json":
            with Progress(
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                console=console,
                transient=True
            ) as progress:
                task = progress.add_task("Checking packages...", total=len(installed_packages))

                def update_progress(current: int, total: int) -> None:
                    progress.update(task, completed=current)

                if parallel > 1:
                    latest_versions = get_latest_versions_parallel(
                        installed_packages, timeout=timeout, include_prereleases=pre,
                        max_workers=parallel, progress_callback=update_progress
                    )
                else:
                    latest_versions = get_latest_versions(
                        installed_packages, timeout=timeout, include_prereleases=pre,
                        progress_callback=update_progress
                    )
        else:
            if parallel > 1:
                latest_versions = get_latest_versions_parallel(
                    installed_packages, timeout=timeout, include_prereleases=pre, max_workers=parallel
                )
            else:
                latest_versions = get_latest_versions(
                    installed_packages, timeout=timeout, include_prereleases=pre
                )
        step2_time = time.time() - step2_start

        # Build and save cache (only latest versions, no constraint resolution)
        cache_data = build_version_cache(latest_versions)
        cache_path = save_cache(cache_data, include_prereleases=pre)

        num_with_updates = len(latest_versions)

        if output == "json":
            result = {
                "status": "success",
                "packages_checked": num_installed,
                "packages_with_updates": num_with_updates,
                "cache_path": str(cache_path)
            }
            print(json.dumps(result, indent=2))
        else:
            console.print(f"  Cached {num_with_updates} packages with updates available")
            if debug:
                console.print(f"  [dim]Time: {step2_time:.2f}s[/dim]")
                console.print(f"  [dim]Cache saved to: {cache_path}[/dim]")

            console.print("\n[bold green]Cache updated![/bold green] Run [cyan]pipu upgrade[/cyan] to upgrade your packages.")

            total_time = step1_time + step2_time
            if debug:
                console.print(f"[dim]Total time: {total_time:.2f}s[/dim]")

        sys.exit(0)

    except KeyboardInterrupt:
        console.show_cursor(True)
        sys.exit(130)
    except Exception as e:
        if output == "json":
            print(json.dumps({"error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)


# --- Helper functions for upgrade command ---

def _step1_inspect_packages(
    console: Console, output: str, timeout: int, debug: bool,
    total_steps: int = 5, python_path: Optional[str] = None,
    ui: Optional[UpgradeUI] = None,
) -> tuple[list, float]:
    """Step 1: Inspect installed packages."""
    if output != "json":
        if ui is not None:
            ui.start_phase("Inspecting installed packages...")
        else:
            console.print(f"[bold]Step 1/{total_steps}:[/bold] Inspecting installed packages...")

    step_start = time.time()
    if output != "json" and ui is None:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True
        ) as progress:
            progress.add_task("Loading packages...", total=None)
            installed_packages = inspect_installed_packages(timeout=timeout, python_path=python_path)
    else:
        installed_packages = inspect_installed_packages(timeout=timeout, python_path=python_path)
    step_time = time.time() - step_start

    if output != "json":
        if ui is not None:
            ui.complete_phase(f"Found {len(installed_packages)} installed packages")
        else:
            console.print(f"  Found {len(installed_packages)} installed packages")
        if debug:
            console.print(f"  [dim]Time: {step_time:.2f}s[/dim]")

    return installed_packages, step_time


def _step2_get_latest_versions(
    console: Console, output: str, debug: bool,
    installed_packages: list, use_cache: bool, cache_enabled: bool,
    timeout: int, pre: bool, parallel: int, total_steps: int = 5,
    python_path: Optional[str] = None,
    ui: Optional[UpgradeUI] = None,
) -> tuple[dict, float, bool]:
    """Step 2: Get latest versions from cache or network."""
    if output != "json":
        if ui is not None:
            ui.start_phase("Checking for updates...")
        elif use_cache:
            console.print(f"\n[bold]Step 2/{total_steps}:[/bold] Loading cached version data...")
        else:
            console.print(f"\n[bold]Step 2/{total_steps}:[/bold] Fetching latest versions from PyPI...")

    step_start = time.time()
    latest_versions: dict = {}
    cache_was_used = False

    if use_cache:
        cache_data = load_cache(python_path=python_path)
        if cache_data and cache_data.latest_versions:
            for installed_pkg in installed_packages:
                name_lower = installed_pkg.name.lower()
                if name_lower in cache_data.latest_versions:
                    cached_version = cache_data.latest_versions[name_lower]
                    try:
                        latest_ver = Version(cached_version)
                        if latest_ver > installed_pkg.version:
                            latest_pkg = Package(name=installed_pkg.name, version=latest_ver)
                            latest_versions[installed_pkg] = latest_pkg
                    except Exception:
                        pass
            cache_was_used = True
        else:
            use_cache = False

    if not use_cache:
        if output != "json":
            with Progress(
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                console=console,
                transient=True
            ) as progress:
                task = progress.add_task("Checking packages...", total=len(installed_packages))

                def update_progress(current: int, total: int) -> None:
                    progress.update(task, completed=current)

                if parallel > 1:
                    latest_versions = get_latest_versions_parallel(
                        installed_packages, timeout=timeout, include_prereleases=pre,
                        max_workers=parallel, progress_callback=update_progress
                    )
                else:
                    latest_versions = get_latest_versions(
                        installed_packages, timeout=timeout, include_prereleases=pre,
                        progress_callback=update_progress
                    )
        else:
            if parallel > 1:
                latest_versions = get_latest_versions_parallel(
                    installed_packages, timeout=timeout, include_prereleases=pre, max_workers=parallel
                )
            else:
                latest_versions = get_latest_versions(
                    installed_packages, timeout=timeout, include_prereleases=pre
                )

        if cache_enabled:
            version_cache = build_version_cache(latest_versions)
            save_cache(version_cache, include_prereleases=pre, python_path=python_path)

    step_time = time.time() - step_start

    if output != "json":
        if ui is not None:
            ui.complete_phase(f"{len(latest_versions)} packages with newer versions available")
        else:
            console.print(f"  Found {len(latest_versions)} packages with newer versions available")
            if cache_was_used:
                console.print("  [dim](from cache)[/dim]")
        if debug:
            console.print(f"  [dim]Time: {step_time:.2f}s[/dim]")

    return latest_versions, step_time, cache_was_used


def _parse_excludes(exclude_tuple: tuple) -> str:
    """Flatten repeatable --exclude values into comma-separated string.

    :param exclude_tuple: Tuple of exclude values from Click multiple option
    :returns: Comma-separated string of package names
    """
    result: list[str] = []
    for item in exclude_tuple:
        result.extend(name.strip() for name in item.split(",") if name.strip())
    return ",".join(result)


def _step3_resolve_packages(
    console: Console, output: str, debug: bool,
    latest_versions: dict, installed_packages: list, show_blocked: bool,
    exclude: str, packages: tuple, total_steps: int = 5,
    ui: Optional[UpgradeUI] = None,
) -> tuple[list, list, dict, float]:
    """Step 3: Resolve upgradable packages and apply filters."""
    if output != "json":
        if ui is not None:
            ui.start_phase("Resolving dependency constraints...")
        else:
            console.print(f"\n[bold]Step 3/{total_steps}:[/bold] Resolving dependency constraints...")
    step_start = time.time()

    if show_blocked:
        upgradable_packages, blocked_packages = resolve_upgradable_packages_with_reasons(
            latest_versions, installed_packages
        )
    else:
        all_upgradable = resolve_upgradable_packages(latest_versions, installed_packages)
        upgradable_packages = [pkg for pkg in all_upgradable if pkg.upgradable]
        blocked_packages = []

    step_time = time.time() - step_start

    # Apply exclusions
    excluded_names = set()
    if exclude:
        excluded_names = {name.strip().lower() for name in exclude.split(',')}
        if debug and excluded_names:
            console.print(f"  [dim]Excluding: {', '.join(sorted(excluded_names))}[/dim]")

    can_upgrade = [pkg for pkg in upgradable_packages if pkg.name.lower() not in excluded_names]

    # Parse package specifications and filter
    package_constraints: dict = {}
    if packages:
        requested_packages = set()
        for spec in packages:
            name, constraint = parse_package_spec(spec)
            requested_packages.add(name.lower())
            if constraint:
                package_constraints[name.lower()] = constraint

        can_upgrade = [pkg for pkg in can_upgrade if pkg.name.lower() in requested_packages]

        if debug:
            console.print(f"  [dim]Filtering to: {', '.join(packages)}[/dim]")
            if package_constraints:
                console.print(f"  [dim]Version constraints: {package_constraints}[/dim]")

    if output != "json":
        if ui is not None:
            ui.complete_phase(f"{len(can_upgrade)} safe to upgrade")
        else:
            console.print(f"  {len(can_upgrade)} packages can be safely upgraded")
        if debug:
            console.print(f"  [dim]Time: {step_time:.2f}s[/dim]")

    return can_upgrade, blocked_packages, package_constraints, step_time


def _step5_install_packages(
    console: Console, output: str,
    can_upgrade: list, package_constraints: dict,
    python_path: Optional[str] = None,
    ui: Optional[UpgradeUI] = None,
    debug: bool = False,
    parallel: int = 1,
) -> tuple[list, float]:
    """Download and install packages."""
    editable_packages = [pkg for pkg in can_upgrade if pkg.is_editable]
    non_editable_packages = [pkg for pkg in can_upgrade if not pkg.is_editable]

    step_start = time.time()

    # Save state for potential rollback
    from pipu_cli.rollback import save_state
    pre_upgrade_packages = [
        {"name": pkg.name, "version": str(pkg.version)}
        for pkg in can_upgrade
    ]
    description = "Pre-upgrade state"
    if python_path is not None:
        description = f"Pre-upgrade state ({python_path})"
    save_state(pre_upgrade_packages, description)

    results = []

    if non_editable_packages:
        # Build pinned specs
        specs = []
        for pkg in non_editable_packages:
            name_lower = pkg.name.lower()
            if name_lower in package_constraints:
                specs.append(f"{pkg.name}{package_constraints[name_lower]}")
            else:
                specs.append(f"{pkg.name}=={pkg.latest_version}")

        with tempfile.TemporaryDirectory(prefix="pipu-") as tmp_dir:
            dest_dir = Path(tmp_dir)

            # Download phase
            if ui and output != "json":
                tracker = ui.show_download_progress(specs)

                def on_download_start(spec: str) -> None:
                    tracker.start(spec)

                def on_download(spec: str, success: bool, error_msg: str) -> None:
                    if success:
                        tracker.complete(spec)
                    else:
                        tracker.fail(spec, error_msg)

                try:
                    download_packages(
                        specs=specs, dest_dir=dest_dir,
                        python_path=python_path,
                        max_workers=parallel,
                        progress_callback=on_download,
                        start_callback=on_download_start,
                    )
                except RuntimeError:
                    pass
                finally:
                    tracker.finish()
            else:
                download_packages(
                    specs=specs, dest_dir=dest_dir,
                    python_path=python_path,
                    max_workers=parallel,
                )

            # Install phase
            if ui and output != "json":
                install_tracker = ui.show_install_progress(specs)

                def on_install(spec: str) -> None:
                    install_tracker.complete(spec)

                regular_results = install_from_local(
                    dest_dir=dest_dir, specs=specs,
                    python_path=python_path,
                    progress_callback=on_install,
                )
                install_tracker.finish()
            else:
                regular_results = install_from_local(
                    dest_dir=dest_dir, specs=specs,
                    python_path=python_path,
                )

            results.extend(regular_results)

    # Editable packages bypass download pipeline
    if editable_packages:
        if ui and output != "json":
            ui.start_phase(f"Reinstalling {len(editable_packages)} editable package(s)...")
        stream = None
        if debug:
            stream = ConsoleStream(console)
        editable_results = reinstall_editable_packages(
            editable_packages, output_stream=stream, timeout=300, python_path=python_path,
        )
        if ui and output != "json":
            ui.complete_phase(f"{len([r for r in editable_results if r.upgraded])} reinstalled")
        results.extend(editable_results)

    step_time = time.time() - step_start
    return results, step_time


@cli.command()
@click.pass_context
@click.argument('packages', nargs=-1)
@click.option(
    "--timeout",
    type=int,
    default=10,
    help="Network timeout in seconds for package queries"
)
@click.option(
    "--pre",
    is_flag=True,
    help="Include pre-release versions"
)
@click.option(
    "--yes", "-y",
    is_flag=True,
    help="Automatically confirm upgrade without prompting"
)
@click.option(
    "--debug",
    is_flag=True,
    help="Enable debug logging and show performance timing"
)
@click.option(
    "--dry-run",
    is_flag=True,
    hidden=True,
    help="Show what would be upgraded without actually upgrading"
)
@click.option(
    "--exclude", "-e",
    multiple=True,
    help="Packages to exclude from upgrade (repeatable, comma-separated)"
)
@click.option(
    "--show-blocked", "-b",
    is_flag=True,
    help="Show packages that cannot be upgraded and why"
)
@click.option(
    "--output", "-o",
    type=click.Choice(["human", "json"]),
    default="human",
    help="Output format (human-readable or json)"
)
@click.option(
    "--update-requirements",
    type=click.Path(exists=True),
    default=None,
    help="Update the specified requirements.txt file with new versions"
)
@click.option(
    "--parallel", "-p",
    type=int,
    default=min(4, mp.cpu_count()),
    help=f"Number of parallel requests for version checking (default: {min(4, mp.cpu_count())})"
)
@click.option(
    "--interactive", "-i",
    is_flag=True,
    hidden=True,
    help="Interactively select packages to upgrade"
)
@click.option(
    "--no-cache",
    is_flag=True,
    help="Skip cache and fetch fresh version data"
)
@click.option(
    "--cache-ttl",
    type=int,
    default=None,
    help=f"Cache freshness threshold in seconds (default: {DEFAULT_CACHE_TTL})"
)
@click.option(
    "--group", "-g",
    "group_name",
    default=None,
    help="Run upgrade across all environments in a named group"
)
def upgrade(ctx: click.Context, packages: tuple[str, ...], timeout: int, pre: bool, yes: bool, debug: bool, dry_run: bool,
            exclude: tuple, show_blocked: bool, output: str, update_requirements: Optional[str],
            parallel: int, interactive: bool, no_cache: bool, cache_ttl: Optional[int],
            group_name: Optional[str] = None) -> None:
    """
    Upgrade installed packages.

    By default, upgrades all packages that have newer versions available.
    Optionally specify PACKAGES to upgrade only those packages.

    Uses cached version data if available and fresh. Run [cyan]pipu update[/cyan]
    to refresh the cache manually.

    \b
    Examples:
      pipu upgrade                    Upgrade all packages
      pipu upgrade requests numpy     Upgrade specific packages
      pipu upgrade --no-cache         Force fresh version check
      pipu upgrade -e numpy -e pandas Exclude packages
    """
    console = Console()

    # Load configuration file
    config = load_config()

    # Apply config file values only when CLI option is at its default
    if ctx.get_parameter_source('timeout') == ParameterSource.DEFAULT:
        timeout = get_config_value(config, 'timeout', 10)
    if ctx.get_parameter_source('exclude') == ParameterSource.DEFAULT:
        exclude_list = get_config_value(config, 'exclude', [])
        exclude_str = ','.join(exclude_list) if exclude_list else ""
    else:
        exclude_str = _parse_excludes(exclude)
    if ctx.get_parameter_source('pre') == ParameterSource.DEFAULT:
        pre = get_config_value(config, 'pre', False)
    if ctx.get_parameter_source('yes') == ParameterSource.DEFAULT:
        yes = get_config_value(config, 'yes', False)
    if ctx.get_parameter_source('debug') == ParameterSource.DEFAULT:
        debug = get_config_value(config, 'debug', False)
    if ctx.get_parameter_source('dry_run') == ParameterSource.DEFAULT:
        dry_run = get_config_value(config, 'dry_run', False)
    if ctx.get_parameter_source('show_blocked') == ParameterSource.DEFAULT:
        show_blocked = get_config_value(config, 'show_blocked', False)
    if ctx.get_parameter_source('output') == ParameterSource.DEFAULT:
        output = get_config_value(config, 'output', 'human')
    if ctx.get_parameter_source('cache_ttl') == ParameterSource.DEFAULT:
        cache_ttl = get_config_value(config, 'cache_ttl', DEFAULT_CACHE_TTL)

    # Check if caching is enabled
    cache_enabled = get_config_value(config, 'cache_enabled', True) and not no_cache

    # Initialize JSON formatter if needed
    json_formatter = JsonOutputFormatter() if output == "json" else None

    # Group mode: dispatch to group execution loop
    if group_name is not None:
        _run_group_upgrade(
            group_name=group_name, console=console, output=output,
            timeout=timeout, pre=pre, yes=yes, debug=debug,
            exclude_str=exclude_str, show_blocked=show_blocked,
            parallel=parallel, no_cache=no_cache, cache_ttl=cache_ttl,
            packages=packages, package_constraints={},
            update_requirements=update_requirements,
            json_formatter=json_formatter, cache_enabled=cache_enabled,
        )
        return

    # Interactive mode deprecation warning
    if interactive:
        if output != "json":
            console.print("[yellow]Warning: --interactive/-i is deprecated. "
                         "Use positional args instead: pipu upgrade requests numpy[/yellow]\n")

    # Interactive mode only works in human output mode
    if interactive and output == "json":
        console.print("[yellow]Warning: --interactive is not compatible with --output json. Ignoring --interactive.[/yellow]")
        interactive = False

    # Configure logging
    if debug and output != "json":
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(message)s',
            handlers=[RichHandler(console=console, show_time=False, show_path=False, markup=True)]
        )
        logging.getLogger('pip._internal').setLevel(logging.WARNING)
        logging.getLogger('pip._vendor').setLevel(logging.WARNING)
        console.print("[dim]Debug mode enabled[/dim]\n")

        # Show cache diagnostics
        info = get_cache_info()
        console.print("[dim]Cache diagnostics:[/dim]")
        console.print(f"  [dim]Cache path: {info['path']}[/dim]")
        console.print(f"  [dim]Environment ID: {info['environment_id']}[/dim]")
        console.print(f"  [dim]Python: {info['python_executable']}[/dim]")
        if info['exists']:
            console.print(f"  [dim]Packages cached: {info.get('package_count', 0)}[/dim]")
            console.print(f"  [dim]Cache age: {info.get('age_human', 'unknown')}[/dim]")
        else:
            console.print("  [dim]No cache exists[/dim]")
        console.print()

    ui = UpgradeUI(console) if output != "json" else None

    try:
        # Check cache freshness
        effective_cache_ttl = DEFAULT_CACHE_TTL if cache_ttl is None else cache_ttl
        use_cache = cache_enabled and is_cache_fresh(effective_cache_ttl)

        if use_cache and output != "json":
            cache_age = get_cache_age_seconds()
            console.print(f"[dim]Using cached data ({format_cache_age(cache_age)})[/dim]\n")

        # Step 1: Inspect installed packages
        installed_packages, step1_time = _step1_inspect_packages(
            console, output, timeout, debug, ui=ui,
        )

        if not installed_packages:
            if output == "json":
                print('{"error": "No packages found"}')
            else:
                console.print("[yellow]No packages found.[/yellow]")
            sys.exit(0)

        # Step 2: Get latest versions (from cache or network)
        latest_versions, step2_time, _ = _step2_get_latest_versions(
            console, output, debug, installed_packages, use_cache, cache_enabled,
            timeout, pre, parallel, ui=ui,
        )

        if not latest_versions:
            if output == "json":
                print('{"upgradable": [], "blocked": [], "results": [], "summary": {"total": 0, "upgraded": 0, "failed": 0}}')
            else:
                console.print("\n[bold green]All packages are up to date![/bold green]")
            sys.exit(0)

        # Step 3: Resolve upgradable packages
        can_upgrade, blocked_packages, package_constraints, step3_time = _step3_resolve_packages(
            console, output, debug, latest_versions, installed_packages, show_blocked,
            exclude_str, packages, ui=ui,
        )

        if not can_upgrade:
            if output == "json":
                assert json_formatter is not None
                json_data = json_formatter.format_all(
                    upgradable=[],
                    blocked=blocked_packages if show_blocked else None
                )
                print(json_data)
            else:
                console.print("\n[yellow]No packages can be upgraded (all blocked by constraints).[/yellow]")
                if show_blocked and blocked_packages:
                    console.print()
                    print_blocked_packages_table(blocked_packages, console=console)
            sys.exit(0)

        # Step 4: Display table and ask for confirmation
        if output == "json":
            assert json_formatter is not None
            if dry_run:
                json_data = json_formatter.format_all(
                    upgradable=can_upgrade,
                    blocked=blocked_packages if show_blocked else None
                )
                print(json_data)
                sys.exit(0)
        else:
            console.print()
            print_upgradable_packages_table(can_upgrade, console=console)

            if show_blocked and blocked_packages:
                console.print()
                print_blocked_packages_table(blocked_packages, console=console)

            if interactive:
                can_upgrade = select_packages_interactively(can_upgrade, console)
                if not can_upgrade:
                    console.print("[yellow]No packages selected for upgrade.[/yellow]")
                    sys.exit(0)

            if dry_run:
                console.print("\n[bold cyan]Dry run complete.[/bold cyan] No packages were modified.")
                sys.exit(0)

        # Skip confirmation if interactive mode (already confirmed) or --yes flag
        if not yes and not interactive and output != "json":
            console.print()
            confirm = click.confirm(f"Upgrade {len(can_upgrade)} package(s)?", default=True)
            if not confirm:
                console.print("[yellow]Upgrade cancelled.[/yellow]")
                sys.exit(0)

        # Step 5: Install packages
        results, step5_time = _step5_install_packages(
            console, output, can_upgrade, package_constraints, ui=ui, debug=debug,
            parallel=parallel,
        )

        # Update requirements file if requested
        if update_requirements:
            from pathlib import Path
            from pipu_cli.requirements import update_requirements_file
            req_path = Path(update_requirements)
            updated = update_requirements_file(req_path, results)
            if updated and output != "json":
                console.print(f"\n[bold green]Updated {updated} package(s) in {update_requirements}[/bold green]")

        # Print results summary
        if output == "json":
            assert json_formatter is not None
            json_data = json_formatter.format_all(
                upgradable=can_upgrade,
                blocked=blocked_packages if show_blocked else None,
                results=results
            )
            print(json_data)
        else:
            print_upgrade_results(results, console=console, verbose=debug)

            if debug:
                console.print(f"\n[dim]Step 5 time: {step5_time:.2f}s[/dim]")
                total_time = step1_time + step2_time + step3_time + step5_time
                console.print(f"[dim]Total time: {total_time:.2f}s[/dim]")

        # Exit with appropriate code
        failed = [pkg for pkg in results if not pkg.upgraded]
        if failed:
            sys.exit(1)
        else:
            sys.exit(0)

    except KeyboardInterrupt:
        if ui:
            ui.cleanup()
        console.show_cursor(True)
        sys.exit(130)
    except click.Abort:
        if ui:
            ui.cleanup()
        console.show_cursor(True)
        sys.exit(130)
    except Exception as e:
        if ui:
            ui.cleanup()
        console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)


@cli.command()
@click.pass_context
@click.option("--timeout", type=int, default=10, help="Network timeout in seconds for package queries")
@click.option("--pre", is_flag=True, help="Include pre-release versions")
@click.option("--debug", is_flag=True, help="Enable debug logging and show performance timing")
@click.option("--exclude", "-e", multiple=True, help="Packages to exclude (repeatable, comma-separated)")
@click.option("--show-blocked", "-b", is_flag=True, default=True,
              help="Show packages blocked by constraints (default: enabled)")
@click.option("--output", "-o", type=click.Choice(["human", "json"]), default="human",
              help="Output format (human-readable or json)")
@click.option("--parallel", "-p", type=int, default=min(4, mp.cpu_count()),
              help=f"Number of parallel requests for version checking (default: {min(4, mp.cpu_count())})")
@click.option("--no-cache", is_flag=True, help="Skip cache and fetch fresh version data")
@click.option("--cache-ttl", type=int, default=None,
              help=f"Cache freshness threshold in seconds (default: {DEFAULT_CACHE_TTL})")
@click.option("--group", "-g", "group_name", default=None,
              help="Show outdated packages across all environments in a named group")
def outdated(ctx, timeout, pre, debug, exclude, show_blocked, output, parallel, no_cache, cache_ttl,
             group_name=None):
    """
    Show outdated packages.

    Displays packages that have newer versions available, along with any
    packages blocked by dependency constraints. Does not install anything.

    \b
    Examples:
      pipu outdated              Show all outdated packages
      pipu outdated --no-cache   Force fresh version check
      pipu outdated -o json      Machine-readable output
    """
    console = Console()

    # Load config and apply defaults (same pattern as upgrade)
    config = load_config()
    if ctx.get_parameter_source('timeout') == ParameterSource.DEFAULT:
        timeout = get_config_value(config, 'timeout', 10)
    if ctx.get_parameter_source('pre') == ParameterSource.DEFAULT:
        pre = get_config_value(config, 'pre', False)
    if ctx.get_parameter_source('debug') == ParameterSource.DEFAULT:
        debug = get_config_value(config, 'debug', False)
    if ctx.get_parameter_source('show_blocked') == ParameterSource.DEFAULT:
        show_blocked = get_config_value(config, 'show_blocked', True)
    if ctx.get_parameter_source('output') == ParameterSource.DEFAULT:
        output = get_config_value(config, 'output', 'human')
    if ctx.get_parameter_source('parallel') == ParameterSource.DEFAULT:
        parallel = get_config_value(config, 'parallel', min(4, mp.cpu_count()))
    if ctx.get_parameter_source('cache_ttl') == ParameterSource.DEFAULT:
        cache_ttl = get_config_value(config, 'cache_ttl', DEFAULT_CACHE_TTL)

    # Process excludes
    if ctx.get_parameter_source('exclude') == ParameterSource.DEFAULT:
        exclude_list = get_config_value(config, 'exclude', [])
        exclude_str = ','.join(exclude_list) if exclude_list else ""
    else:
        exclude_str = _parse_excludes(exclude)

    cache_enabled = get_config_value(config, 'cache_enabled', True) and not no_cache
    json_formatter = JsonOutputFormatter() if output == "json" else None

    if group_name is not None:
        _run_group_outdated(
            group_name=group_name, console=console, output=output,
            timeout=timeout, pre=pre, debug=debug,
            exclude_str=exclude_str, show_blocked=show_blocked,
            parallel=parallel, no_cache=no_cache, cache_ttl=cache_ttl,
            json_formatter=json_formatter, cache_enabled=cache_enabled,
        )
        return

    if debug and output != "json":
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(message)s',
            handlers=[RichHandler(console=console, show_time=False, show_path=False, markup=True)]
        )
        logging.getLogger('pip._internal').setLevel(logging.WARNING)
        logging.getLogger('pip._vendor').setLevel(logging.WARNING)
        console.print("[dim]Debug mode enabled[/dim]\n")

        # Show cache diagnostics
        info = get_cache_info()
        console.print("[dim]Cache diagnostics:[/dim]")
        console.print(f"  [dim]Cache path: {info['path']}[/dim]")
        console.print(f"  [dim]Environment ID: {info['environment_id']}[/dim]")
        console.print(f"  [dim]Python: {info['python_executable']}[/dim]")
        if info['exists']:
            console.print(f"  [dim]Packages cached: {info.get('package_count', 0)}[/dim]")
            console.print(f"  [dim]Cache age: {info.get('age_human', 'unknown')}[/dim]")
        else:
            console.print("  [dim]No cache exists[/dim]")
        console.print()

    try:
        effective_cache_ttl = DEFAULT_CACHE_TTL if cache_ttl is None else cache_ttl
        use_cache = cache_enabled and is_cache_fresh(effective_cache_ttl)

        if use_cache and output != "json":
            cache_age = get_cache_age_seconds()
            console.print(f"[dim]Using cached data ({format_cache_age(cache_age)})[/dim]\n")

        # Step 1: Inspect
        installed_packages, step1_time = _step1_inspect_packages(console, output, timeout, debug, total_steps=3)
        if not installed_packages:
            if output == "json":
                print('{"upgradable": [], "blocked": [], "results": [], "summary": {"total": 0, "upgraded": 0, "failed": 0}}')
            else:
                console.print("[yellow]No packages found.[/yellow]")
            sys.exit(0)

        # Step 2: Get latest versions
        latest_versions, step2_time, _ = _step2_get_latest_versions(
            console, output, debug, installed_packages, use_cache, cache_enabled,
            timeout, pre, parallel, total_steps=3
        )

        if not latest_versions:
            if output == "json":
                print('{"upgradable": [], "blocked": [], "results": [], "summary": {"total": 0, "upgraded": 0, "failed": 0}}')
            else:
                console.print("\n[bold green]All packages are up to date![/bold green]")
            sys.exit(0)

        # Step 3: Resolve
        can_upgrade, blocked_packages, _, step3_time = _step3_resolve_packages(
            console, output, debug, latest_versions, installed_packages, show_blocked,
            exclude_str, (), total_steps=3
        )

        # Display results
        if output == "json":
            assert json_formatter is not None
            json_data = json_formatter.format_all(
                upgradable=can_upgrade,
                blocked=blocked_packages if show_blocked else None
            )
            print(json_data)
        else:
            if can_upgrade:
                console.print("\n[bold]Packages with updates available:\n")
                print_upgradable_packages_table(can_upgrade, console=console)

            if not can_upgrade:
                console.print("\n[yellow]No packages can be upgraded (all blocked by constraints).[/yellow]")

            if show_blocked and blocked_packages:
                console.print()
                print_blocked_packages_table(blocked_packages, console=console)

            if debug:
                total_time = step1_time + step2_time + step3_time
                console.print(f"\n[dim]Total time: {total_time:.2f}s[/dim]")

        sys.exit(0)

    except KeyboardInterrupt:
        console.show_cursor(True)
        sys.exit(130)
    except Exception as e:
        if output == "json":
            print(json.dumps({"error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)


@cli.command()
@click.option(
    "--list", "-l",
    "list_states_flag",
    is_flag=True,
    help="List all saved rollback states"
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be restored without actually restoring"
)
@click.option(
    "--yes", "-y",
    is_flag=True,
    help="Automatically confirm rollback without prompting"
)
@click.option(
    "--state",
    type=str,
    default=None,
    help="Specific state file to rollback to (use --list to see available states)"
)
@click.option(
    "--output", "-o",
    type=click.Choice(["human", "json"]),
    default="human",
    help="Output format (human-readable or json)"
)
def rollback(list_states_flag: bool, dry_run: bool, yes: bool, state: Optional[str], output: str) -> None:
    """
    Restore packages to a previous state.

    Before each upgrade, pipu saves the current package versions. Use this
    command to restore packages to their pre-upgrade state.

    \b
    Examples:
      pipu rollback --list       List all saved states
      pipu rollback --dry-run    Preview what would be restored
      pipu rollback --yes        Rollback without confirmation
      pipu rollback --state FILE Rollback to a specific state
    """
    from pipu_cli.rollback import get_latest_state, rollback_to_state, list_states as get_states, ROLLBACK_DIR

    console = Console()

    # List saved states if requested
    if list_states_flag:
        states = get_states()
        if not states:
            if output == "json":
                print(json.dumps({"states": []}, indent=2))
            else:
                console.print("[yellow]No saved states found.[/yellow]")
                console.print(f"[dim]States are saved in: {ROLLBACK_DIR}[/dim]")
            sys.exit(0)

        if output == "json":
            print(json.dumps({"states": states}, indent=2))
            sys.exit(0)

        table = Table(title="[bold]Saved Rollback States[/bold]")
        table.add_column("#", style="dim", width=3)
        table.add_column("State File", style="cyan")
        table.add_column("Timestamp", style="green")
        table.add_column("Packages", style="magenta", justify="right")
        table.add_column("Description", style="dim")

        for idx, s in enumerate(states, 1):
            ts = s["timestamp"]
            if len(ts) == 15 and ts[8] == "_":
                formatted_ts = f"{ts[:4]}-{ts[4:6]}-{ts[6:8]} {ts[9:11]}:{ts[11:13]}:{ts[13:15]}"
            else:
                formatted_ts = ts

            table.add_row(
                str(idx),
                s["file"],
                formatted_ts,
                str(s["package_count"]),
                s["description"] or "-"
            )

        console.print(table)
        console.print(f"\n[dim]States saved in: {ROLLBACK_DIR}[/dim]")
        console.print("[dim]Use --state <filename> to rollback to a specific state[/dim]")
        sys.exit(0)

    # Get the state to rollback to
    if state:
        state_path = ROLLBACK_DIR / state
        if not state_path.exists():
            if output == "json":
                print(json.dumps({"error": f"State file not found: {state}"}, indent=2))
            else:
                console.print(f"[red]State file not found:[/red] {state}")
                console.print("[dim]Use 'pipu rollback --list' to see available states[/dim]")
            sys.exit(1)

        with open(state_path, 'r') as f:
            state_data = json.load(f)
    else:
        state_data = get_latest_state()

    if state_data is None:
        if output == "json":
            print(json.dumps({"error": "No saved state found"}, indent=2))
        else:
            console.print("[yellow]No saved state found.[/yellow]")
            console.print("[dim]A state is automatically saved before each upgrade.[/dim]")
        sys.exit(0)

    # Show what will be rolled back
    packages = state_data.get("packages", [])
    timestamp = state_data.get("timestamp", "unknown")
    description = state_data.get("description", "")

    if len(timestamp) == 15 and timestamp[8] == "_":
        formatted_ts = f"{timestamp[:4]}-{timestamp[4:6]}-{timestamp[6:8]} {timestamp[9:11]}:{timestamp[11:13]}:{timestamp[13:15]}"
    else:
        formatted_ts = timestamp

    if output == "json":
        if dry_run:
            print(json.dumps({"packages": packages, "timestamp": formatted_ts, "description": description}, indent=2))
            sys.exit(0)
    else:
        console.print(f"\n[bold]Rollback State:[/bold] {formatted_ts}")
        if description:
            console.print(f"[dim]{description}[/dim]")
        console.print()

        table = Table(title=f"[bold]{len(packages)} Package(s) to Restore[/bold]")
        table.add_column("Package", style="cyan")
        table.add_column("Version", style="green")

        for pkg in packages:
            table.add_row(pkg["name"], pkg["version"])

        console.print(table)

        if dry_run:
            console.print("\n[bold cyan]Dry run complete.[/bold cyan] No packages were modified.")
            sys.exit(0)

    if not yes:
        console.print()
        confirm = click.confirm("Do you want to proceed with the rollback?", default=True)
        if not confirm:
            console.print("[yellow]Rollback cancelled.[/yellow]")
            sys.exit(0)

    if output != "json":
        console.print("\n[bold]Rolling back packages...[/bold]\n")

    rolled_back = rollback_to_state(state_data, dry_run=False)

    if output == "json":
        print(json.dumps({"rolled_back": rolled_back or []}, indent=2))
    else:
        if rolled_back:
            console.print(f"\n[bold green]Successfully rolled back {len(rolled_back)} package(s):[/bold green]")
            for pkg in rolled_back:
                console.print(f"  - {pkg}")
        else:
            console.print("[yellow]No packages were rolled back.[/yellow]")

    sys.exit(0)


@cli.command()
@click.option(
    "--all", "-a",
    "clean_all",
    is_flag=True,
    help="Clean up files for all environments"
)
@click.option(
    "--group", "-g",
    "group_name",
    default=None,
    help="Clean caches for all environments in a named group"
)
def clean(clean_all: bool, group_name: Optional[str]) -> None:
    """
    Clean up pipu caches and temporary files.

    Removes cached package version data and other temporary files
    created by pipu. By default, cleans up files for the current
    Python environment only.

    \b
    Examples:
      pipu clean              Clean current environment
      pipu clean --all        Clean all environments
      pipu clean -g mygroup   Clean all environments in a group
    """
    console = Console()

    if clean_all and group_name:
        console.print("[red]Cannot use --all and --group together.[/red]")
        sys.exit(1)

    if clean_all:
        count = clear_all_caches()
        if count > 0:
            console.print(f"[bold green]Cleared {count} cache(s).[/bold green]")
        else:
            console.print("[yellow]No caches to clear.[/yellow]")
    elif group_name:
        environments = get_group(group_name)
        if environments is None:
            console.print(f"[red]Group '{group_name}' not found.[/red]")
            sys.exit(1)

        cleared = 0
        for env_path in environments:
            if clear_cache(python_path=env_path):
                cleared += 1

        if cleared > 0:
            console.print(f"[bold green]Cleared {cleared} cache(s) for group '{group_name}'.[/bold green]")
        else:
            console.print(f"[yellow]No caches to clear for group '{group_name}'.[/yellow]")
    else:
        if clear_cache():
            console.print("[bold green]Cache cleared for current environment.[/bold green]")
        else:
            console.print("[yellow]No cache to clear for current environment.[/yellow]")

    sys.exit(0)


@cli.group("group")
def group_cmd() -> None:
    """Manage groups of Python environments.

    Groups allow you to run pipu commands across multiple Python
    environments at once.

    \b
    Examples:
      pipu group list                          List all groups
      pipu group add mygroup                   Add current env to group
      pipu group add mygroup --python /path    Add specific env
      pipu group remove mygroup                Remove current env
      pipu group delete mygroup                Delete entire group
    """
    pass


@group_cmd.command("list")
def group_list() -> None:
    """List all groups and their environments."""
    console = Console()
    groups = list_groups()

    if not groups:
        console.print("[yellow]No groups defined. Use `pipu group add` to create one.[/yellow]")
        sys.exit(0)

    table = Table(title="[bold]Environment Groups[/bold]")
    table.add_column("Group Name", style="cyan", no_wrap=True)
    table.add_column("Environments", style="magenta", justify="right")
    table.add_column("Python Paths", style="dim")

    for name, environments in sorted(groups.items()):
        paths = "\n".join(environments)
        table.add_row(name, str(len(environments)), paths)

    console.print(table)
    sys.exit(0)


@group_cmd.command("add")
@click.argument("group_name")
@click.option("--python", "python_path", default=None,
              help="Path to Python interpreter (defaults to current Python)")
@click.option("--force", "-f", is_flag=True,
              help="Skip Python path validation")
def group_add(group_name: str, python_path: Optional[str], force: bool) -> None:
    """Add a Python environment to a group.

    Creates the group if it doesn't exist.

    \b
    Examples:
      pipu group add mygroup                    Add current Python
      pipu group add mygroup --python /path     Add specific Python
      pipu group add mygroup --python /path -f  Skip validation
    """
    console = Console()

    if python_path is None:
        python_path = sys.executable

    if not force:
        is_valid, error = validate_python_path(python_path)
        if not is_valid:
            console.print(f"[red]Invalid Python path:[/red] {error}")
            sys.exit(1)

    added = add_environment(group_name, python_path)
    if added:
        console.print(f"[green]Added[/green] {python_path} to group [cyan]{group_name}[/cyan]")
    else:
        console.print(f"[yellow]{python_path} is already in group {group_name}[/yellow]")
    sys.exit(0)


@group_cmd.command("remove")
@click.argument("group_name")
@click.option("--python", "python_path", default=None,
              help="Path to Python interpreter (defaults to current Python)")
def group_remove(group_name: str, python_path: Optional[str]) -> None:
    """Remove a Python environment from a group.

    If this removes the last environment, the group is deleted.

    \b
    Examples:
      pipu group remove mygroup                Remove current Python
      pipu group remove mygroup --python /path Remove specific Python
    """
    console = Console()

    if python_path is None:
        python_path = sys.executable

    removed = remove_environment(group_name, python_path)
    if not removed:
        console.print(f"[red]Environment not found[/red] in group [cyan]{group_name}[/cyan]")
        sys.exit(1)

    console.print(f"[green]Removed[/green] {python_path} from group [cyan]{group_name}[/cyan]")
    sys.exit(0)


@group_cmd.command("delete")
@click.argument("group_name")
def group_delete(group_name: str) -> None:
    """Delete an entire group.

    \b
    Examples:
      pipu group delete mygroup    Delete the group
    """
    console = Console()

    deleted = delete_group(group_name)
    if not deleted:
        console.print(f"[red]Group not found:[/red] [cyan]{group_name}[/cyan]")
        sys.exit(1)

    console.print(f"[green]Deleted[/green] group [cyan]{group_name}[/cyan]")
    sys.exit(0)


def _run_group_upgrade(
    group_name: str, console: Console, output: str,
    timeout: int, pre: bool, yes: bool, debug: bool,
    exclude_str: str, show_blocked: bool,
    parallel: int, no_cache: bool, cache_ttl: Optional[int],
    packages: tuple, package_constraints: dict,
    update_requirements: Optional[str],
    json_formatter: Optional[JsonOutputFormatter],
    cache_enabled: bool,
) -> None:
    """Execute upgrade across all environments in a group using consolidated pipeline."""
    import os

    environments = get_group(group_name)
    if environments is None:
        if output == "json":
            print(json.dumps({"error": f"Group '{group_name}' not found"}))
        else:
            console.print(f"[red]Group not found:[/red] [cyan]{group_name}[/cyan]")
        sys.exit(1)

    ui = UpgradeUI(console) if output != "json" else None

    # Build short name mapping
    env_name_map: dict[str, str] = {}  # short_name -> full_path
    used_names: set[str] = set()
    valid_envs: list[str] = []
    for env_path in environments:
        if not os.path.exists(env_path):
            if output != "json":
                console.print(f"[yellow]Warning: Skipping {env_path} (path not found)[/yellow]")
            continue
        valid_envs.append(env_path)
        from pipu_cli.pretty import extract_env_short_name
        short = extract_env_short_name(env_path, existing_names=used_names)
        env_name_map[short] = env_path
        used_names.add(short)

    if not valid_envs:
        console.print("[yellow]No valid environments in group.[/yellow]")
        sys.exit(1)

    reverse_map = {v: k for k, v in env_name_map.items()}  # full_path -> short_name

    try:
        # Phase 1: Inspect all environments
        env_installed: dict[str, list] = {}
        if ui:
            ui.start_phase(f"Inspecting {len(valid_envs)} environments...")
        for env_path in valid_envs:
            installed = inspect_installed_packages(timeout=timeout, python_path=env_path)
            env_installed[reverse_map[env_path]] = installed
        if ui:
            total_pkgs = sum(len(v) for v in env_installed.values())
            ui.complete_phase(f"Found {total_pkgs} total packages")

        # Phase 2: Fetch latest versions (deduplicated across environments)
        if ui:
            ui.start_phase("Checking for updates across all environments...")
        # Merge all installed packages for a single version check
        all_installed_by_name: dict = {}
        for env_name, installed in env_installed.items():
            for pkg in installed:
                key = pkg.name.lower()
                if key not in all_installed_by_name or pkg.version < all_installed_by_name[key].version:
                    all_installed_by_name[key] = pkg
        all_installed = list(all_installed_by_name.values())

        effective_cache_ttl = DEFAULT_CACHE_TTL if cache_ttl is None else cache_ttl
        use_cache = cache_enabled and not no_cache
        cache_was_used = False

        latest_versions: dict = {}

        # Try cache first (using first env as cache key)
        if use_cache and is_cache_fresh(effective_cache_ttl, python_path=valid_envs[0]):
            cache_data = load_cache(python_path=valid_envs[0])
            if cache_data and cache_data.latest_versions:
                for pkg in all_installed:
                    name_lower = pkg.name.lower()
                    if name_lower in cache_data.latest_versions:
                        try:
                            latest_ver = Version(cache_data.latest_versions[name_lower])
                            if latest_ver > pkg.version:
                                latest_versions[pkg] = Package(name=pkg.name, version=latest_ver)
                        except Exception:
                            pass
                cache_was_used = True

        if not cache_was_used:
            if parallel > 1:
                latest_versions = get_latest_versions_parallel(
                    all_installed, timeout=timeout, include_prereleases=pre, max_workers=parallel,
                )
            else:
                latest_versions = get_latest_versions(
                    all_installed, timeout=timeout, include_prereleases=pre,
                )
            # Save to cache
            if use_cache:
                cache_dict = build_version_cache(latest_versions)
                save_cache(cache_dict, include_prereleases=pre, python_path=valid_envs[0])

        # Re-key latest_versions by canonical name for cross-environment lookup
        latest_by_name: dict[str, Package] = {
            pkg.name.lower(): latest_versions[pkg] for pkg in latest_versions
        }

        if ui:
            ui.complete_phase(f"{len(latest_versions)} packages with newer versions")

        # Phase 3: Resolve constraints per environment
        if ui:
            ui.start_phase("Resolving dependency constraints...")
        env_upgrades: dict[str, list] = {}
        all_blocked: list[tuple[str, BlockedPackageInfo]] = []

        for env_name, installed in env_installed.items():
            env_latest = {pkg: latest_by_name[pkg.name.lower()] for pkg in installed if pkg.name.lower() in latest_by_name}
            if show_blocked:
                upgradable, blocked = resolve_upgradable_packages_with_reasons(env_latest, installed)
                for b in blocked:
                    all_blocked.append((env_name, b))
            else:
                upgradable = [p for p in resolve_upgradable_packages(env_latest, installed) if p.upgradable]

            # Apply exclusions and package filters
            excluded_names = set()
            if exclude_str:
                excluded_names = {n.strip().lower() for n in exclude_str.split(',')}
            can_upgrade = [p for p in upgradable if p.name.lower() not in excluded_names]
            if packages:
                requested = {parse_package_spec(s)[0].lower() for s in packages}
                can_upgrade = [p for p in can_upgrade if p.name.lower() in requested]

            env_upgrades[env_name] = can_upgrade

        total_upgradable = sum(len(v) for v in env_upgrades.values())
        if ui:
            ui.complete_phase(f"{total_upgradable} upgrades across {len(valid_envs)} environments")

        if total_upgradable == 0:
            if output != "json":
                console.print("\n[yellow]No packages can be upgraded.[/yellow]")
                if show_blocked and all_blocked:
                    from pipu_cli.pretty import print_group_blocked_table
                    print_group_blocked_table(all_blocked, console=console)
            else:
                assert json_formatter is not None
                group_results = []
                for env_name in env_name_map:
                    env_path = env_name_map[env_name]
                    group_results.append({
                        "environment": env_path,
                        "upgradable": [],
                        "blocked": [json_formatter._package_to_dict(b) for en, b in all_blocked if en == env_name],
                        "results": [],
                        "summary": {"total": 0, "upgraded": 0, "failed": 0},
                    })
                print(json_formatter.format_group_results(group_results))
            sys.exit(0)

        # Phase 4: Show matrix table and confirm
        if output != "json":
            console.print()
            from pipu_cli.pretty import print_env_legend, print_group_upgrade_matrix
            print_env_legend(env_name_map, console=console)
            console.print()
            print_group_upgrade_matrix(env_upgrades, env_name_map, console=console)

            if show_blocked and all_blocked:
                from pipu_cli.pretty import print_group_blocked_table
                print_group_blocked_table(all_blocked, console=console)

            if not yes:
                console.print()
                confirm = click.confirm(
                    f"Upgrade {total_upgradable} packages across {len(valid_envs)} environments?",
                    default=True,
                )
                if not confirm:
                    console.print("[yellow]Upgrade cancelled.[/yellow]")
                    sys.exit(0)

        # Phase 5: Save rollback state for each environment
        from pipu_cli.rollback import save_state
        for env_name, upgrades in env_upgrades.items():
            if upgrades:
                env_path = env_name_map[env_name]
                pre_pkgs = [{"name": p.name, "version": str(p.version)} for p in upgrades]
                save_state(pre_pkgs, f"Pre-upgrade state ({env_path})")

        # Phase 6: Shared download (editable packages bypass this)
        env_specs: dict[str, list[str]] = {}
        for env_name, upgrades in env_upgrades.items():
            specs = []
            for pkg in upgrades:
                if pkg.is_editable:
                    continue
                name_lower = pkg.name.lower()
                if name_lower in package_constraints:
                    specs.append(f"{pkg.name}{package_constraints[name_lower]}")
                else:
                    specs.append(f"{pkg.name}=={pkg.latest_version}")
            env_specs[env_name] = specs

        with tempfile.TemporaryDirectory(prefix="pipu-group-") as tmp_dir:
            dest_dir = Path(tmp_dir)

            from pipu_cli.download import download_packages_for_group, install_from_local

            if ui:
                unique_specs = list(dict.fromkeys(
                    s for specs in env_specs.values() for s in specs
                ))
                tracker = ui.show_download_progress(unique_specs)
                def on_download_start(spec: str) -> None:
                    tracker.start(spec)
                def on_download(spec: str, success: bool, error_msg: str) -> None:
                    if success:
                        tracker.complete(spec)
                    else:
                        tracker.fail(spec, error_msg)
                try:
                    download_packages_for_group(
                        env_specs, dest_dir, pre=pre, max_workers=parallel,
                        progress_callback=on_download, start_callback=on_download_start,
                    )
                except RuntimeError:
                    pass
                finally:
                    tracker.finish()
            else:
                download_packages_for_group(env_specs, dest_dir, pre=pre, max_workers=parallel)

            # Phase 7: Install per environment
            env_results: dict[str, list] = {}
            env_order = list(env_name_map.keys())

            active_envs = [name for name in env_order if env_specs.get(name)]

            def _install_env(env_name: str, tracker=None):
                env_path = env_name_map[env_name]
                specs = env_specs[env_name]
                try:
                    callback = None
                    if tracker:
                        def on_install(spec: str, en=env_name) -> None:
                            pkg_name = spec.split("==")[0] if "==" in spec else spec
                            tracker.advance(en, pkg_name)
                        callback = on_install
                    results = install_from_local(
                        dest_dir=dest_dir, specs=specs,
                        python_path=env_path,
                        progress_callback=callback,
                    )
                    if tracker:
                        tracker.complete_env(env_name)
                    return env_name, results
                except Exception as e:
                    if tracker:
                        tracker.fail_env(env_name, str(e))
                    return env_name, []

            if ui:
                env_totals = {name: len(env_specs.get(name, [])) for name in active_envs}
                group_tracker = ui.show_group_install_progress(active_envs, env_totals)

                with ThreadPoolExecutor(max_workers=len(active_envs)) as executor:
                    futures = {
                        executor.submit(_install_env, name, group_tracker): name
                        for name in active_envs
                    }
                    for future in as_completed(futures):
                        name, results = future.result()
                        env_results[name] = results

                group_tracker.finish()
            else:
                with ThreadPoolExecutor(max_workers=len(active_envs)) as executor:
                    futures = {
                        executor.submit(_install_env, name): name
                        for name in active_envs
                    }
                    for future in as_completed(futures):
                        name, results = future.result()
                        env_results[name] = results

            # Handle editable packages per environment
            for env_name, upgrades in env_upgrades.items():
                editables = [p for p in upgrades if p.is_editable]
                if editables:
                    env_path = env_name_map[env_name]
                    if ui:
                        ui.start_phase(f"Reinstalling {len(editables)} editable package(s) in {env_name}...")
                    ed_results = reinstall_editable_packages(
                        editables, timeout=300, python_path=env_path,
                    )
                    if ui:
                        ui.complete_phase("done")
                    if env_name in env_results:
                        env_results[env_name].extend(ed_results)
                    else:
                        env_results[env_name] = list(ed_results)

        # Phase 8: Show results
        if output == "json":
            assert json_formatter is not None
            group_results = []
            for env_name in env_order:
                env_path = env_name_map[env_name]
                results = env_results.get(env_name, [])
                upgraded = len([r for r in results if r.upgraded])
                failed = len([r for r in results if not r.upgraded])
                group_results.append({
                    "environment": env_path,
                    "upgradable": [json_formatter._package_to_dict(p) for p in env_upgrades.get(env_name, [])],
                    "blocked": [json_formatter._package_to_dict(b) for en, b in all_blocked if en == env_name],
                    "results": [json_formatter._package_to_dict(r) for r in results],
                    "summary": {"total": upgraded + failed, "upgraded": upgraded, "failed": failed},
                })
            print(json_formatter.format_group_results(group_results))
        else:
            console.print()
            from pipu_cli.pretty import print_group_results_matrix, print_group_blocked_table
            print_group_results_matrix(env_results, env_name_map, console=console)
            if show_blocked and all_blocked:
                print_group_blocked_table(all_blocked, console=console)

        total_failed = sum(
            len([r for r in env_results.get(n, []) if not r.upgraded])
            for n in env_order
        )
        if total_failed:
            sys.exit(1)
        sys.exit(0)

    except KeyboardInterrupt:
        if ui:
            ui.cleanup()
        console.show_cursor(True)
        sys.exit(130)


def _run_group_outdated(
    group_name: str, console: Console, output: str,
    timeout: int, pre: bool, debug: bool,
    exclude_str: str, show_blocked: bool,
    parallel: int, no_cache: bool, cache_ttl: Optional[int],
    json_formatter: Optional[JsonOutputFormatter],
    cache_enabled: bool,
) -> None:
    """Execute outdated check across all environments in a group."""
    import os

    environments = get_group(group_name)
    if environments is None:
        if output == "json":
            print(json.dumps({"error": f"Group '{group_name}' not found"}))
        else:
            console.print(f"[red]Group not found:[/red] [cyan]{group_name}[/cyan]")
        sys.exit(1)

    group_results: list[dict[str, Any]] = []

    try:
        for env_path in environments:
            if not os.path.exists(env_path):
                if output != "json":
                    console.print(f"\n[yellow]Warning: Skipping {env_path} (path not found)[/yellow]")
                continue

            if output != "json":
                console.print()
                console.print(Panel(env_path, title="Environment", border_style="cyan", expand=False))
                console.print()

            try:
                effective_cache_ttl = DEFAULT_CACHE_TTL if cache_ttl is None else cache_ttl
                use_cache = cache_enabled and is_cache_fresh(effective_cache_ttl, python_path=env_path)

                if use_cache and output != "json":
                    cache_age = get_cache_age_seconds(python_path=env_path)
                    console.print(f"[dim]Using cached data ({format_cache_age(cache_age)})[/dim]\n")

                installed_packages, _ = _step1_inspect_packages(
                    console, output, timeout, debug, total_steps=3, python_path=env_path
                )
                if not installed_packages:
                    if output != "json":
                        console.print("[yellow]No packages found.[/yellow]")
                    if output == "json":
                        group_results.append({
                            "environment": env_path,
                            "upgradable": [], "blocked": [], "results": [],
                            "summary": {"total": 0, "upgraded": 0, "failed": 0},
                        })
                    continue

                latest_versions, _, _ = _step2_get_latest_versions(
                    console, output, debug, installed_packages, use_cache, cache_enabled,
                    timeout, pre, parallel, total_steps=3, python_path=env_path
                )
                if not latest_versions:
                    if output != "json":
                        console.print("\n[bold green]All packages are up to date![/bold green]")
                    if output == "json":
                        group_results.append({
                            "environment": env_path,
                            "upgradable": [], "blocked": [], "results": [],
                            "summary": {"total": 0, "upgraded": 0, "failed": 0},
                        })
                    continue

                can_upgrade, blocked_packages, _, _ = _step3_resolve_packages(
                    console, output, debug, latest_versions, installed_packages,
                    show_blocked, exclude_str, (), total_steps=3
                )

                if output != "json":
                    if can_upgrade:
                        console.print("\n[bold]Packages with updates available:\n")
                        print_upgradable_packages_table(can_upgrade, console=console)
                    else:
                        console.print("\n[yellow]No packages can be upgraded.[/yellow]")
                    if show_blocked and blocked_packages:
                        console.print()
                        print_blocked_packages_table(blocked_packages, console=console)
                else:
                    assert json_formatter is not None
                    group_results.append({
                        "environment": env_path,
                        "upgradable": [json_formatter._package_to_dict(p) for p in can_upgrade],
                        "blocked": [json_formatter._package_to_dict(p) for p in blocked_packages] if show_blocked else [],
                        "results": [],
                        "summary": {"total": 0, "upgraded": 0, "failed": 0},
                    })

            except Exception as e:
                if output != "json":
                    console.print(f"\n[red]Error in {env_path}:[/red] {e}")

    except KeyboardInterrupt:
        console.show_cursor(True)
        sys.exit(130)

    if output == "json":
        assert json_formatter is not None
        print(json_formatter.format_group_results(group_results))

    sys.exit(0)


@cli.command()
@click.pass_context
@click.argument('packages', nargs=-1, required=True)
@click.option(
    "--no-update",
    is_flag=True,
    help="Use plain pip install without -U flag (don't upgrade existing packages)"
)
@click.option(
    "--timeout",
    type=int,
    default=300,
    help="Installation timeout in seconds"
)
@click.option(
    "--pre",
    is_flag=True,
    help="Include pre-release versions"
)
@click.option(
    "--yes", "-y",
    is_flag=True,
    help="Skip confirmation prompt"
)
@click.option(
    "--debug",
    is_flag=True,
    help="Enable debug logging"
)
@click.option(
    "--output", "-o",
    type=click.Choice(["human", "json"]),
    default="human",
    help="Output format (human-readable or json)"
)
@click.option(
    "--group", "-g",
    "group_name",
    default=None,
    help="Install across all environments in a named group"
)
def install(ctx: click.Context, packages: tuple[str, ...], no_update: bool, timeout: int,
            pre: bool, yes: bool, debug: bool, output: str,
            group_name: Optional[str] = None) -> None:
    """
    Install packages using pip.

    By default uses pip install -U (install or update). Use --no-update
    for plain pip install without upgrading existing packages.

    \b
    Examples:
      pipu install requests flask       Install/update packages
      pipu install requests --no-update  Install without updating
      pipu install "numpy>=1.24"         Install with version constraint
      pipu install requests -g mygroup   Install across a group
    """
    console = Console()

    # Load configuration file
    config = load_config()
    if ctx.get_parameter_source('timeout') == ParameterSource.DEFAULT:
        timeout = get_config_value(config, 'timeout', 300)
    if ctx.get_parameter_source('pre') == ParameterSource.DEFAULT:
        pre = get_config_value(config, 'pre', False)
    if ctx.get_parameter_source('yes') == ParameterSource.DEFAULT:
        yes = get_config_value(config, 'yes', False)
    if ctx.get_parameter_source('debug') == ParameterSource.DEFAULT:
        debug = get_config_value(config, 'debug', False)
    if ctx.get_parameter_source('output') == ParameterSource.DEFAULT:
        output = get_config_value(config, 'output', 'human')

    json_formatter = JsonOutputFormatter() if output == "json" else None

    # Group mode
    if group_name is not None:
        _run_group_install(
            group_name=group_name, console=console, output=output,
            packages=packages, no_update=no_update, timeout=timeout,
            pre=pre, yes=yes, debug=debug, json_formatter=json_formatter,
        )
        return

    # Configure logging
    if debug and output != "json":
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(message)s',
            handlers=[RichHandler(console=console, show_time=False, show_path=False, markup=True)]
        )
        logging.getLogger('pip._internal').setLevel(logging.WARNING)
        logging.getLogger('pip._vendor').setLevel(logging.WARNING)
        console.print("[dim]Debug mode enabled[/dim]\n")

    try:
        # Step 1: Show what will be installed and confirm
        if output != "json":
            console.print("[bold]Step 1/2:[/bold] Packages to install:\n")
            for pkg_spec in packages:
                console.print(f"  - {pkg_spec}")
            if no_update:
                console.print("\n  [dim](install only, no upgrade)[/dim]")
            else:
                console.print("\n  [dim](install or upgrade to latest)[/dim]")

        if not yes and output != "json":
            console.print()
            confirm = click.confirm("Do you want to proceed?", default=True)
            if not confirm:
                console.print("[yellow]Installation cancelled.[/yellow]")
                sys.exit(0)

        # Step 2: Install packages
        if output != "json":
            console.print(f"\n[bold]Step 2/2:[/bold] Installing {len(packages)} package(s)...\n")

        stream = ConsoleStream(console) if output != "json" else None
        results = run_pip_install(
            package_specs=list(packages),
            upgrade=not no_update,
            output_stream=stream,
            timeout=timeout,
            pre=pre,
        )

        # Display results
        if output == "json":
            assert json_formatter is not None
            print(json_formatter.format_install_results(results))
        else:
            print_install_results(results, console=console)

        # Exit with appropriate code
        failed = [r for r in results if not r.installed]
        sys.exit(1 if failed else 0)

    except KeyboardInterrupt:
        console.show_cursor(True)
        sys.exit(130)
    except click.Abort:
        console.show_cursor(True)
        sys.exit(130)
    except Exception as e:
        if output == "json":
            print(json.dumps({"error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)


def _run_group_install(
    group_name: str, console: Console, output: str,
    packages: tuple, no_update: bool, timeout: int,
    pre: bool, yes: bool, debug: bool,
    json_formatter: Optional[JsonOutputFormatter],
) -> None:
    """Execute install across all environments in a group."""
    import os
    from pipu_cli.pretty import (
        extract_env_short_name, print_env_legend,
        print_group_install_matrix, print_group_install_results_matrix,
    )

    environments = get_group(group_name)
    if environments is None:
        if output == "json":
            print(json.dumps({"error": f"Group '{group_name}' not found"}))
        else:
            console.print(f"[red]Group not found:[/red] [cyan]{group_name}[/cyan]")
        sys.exit(1)

    ui = UpgradeUI(console) if output != "json" else None

    env_name_map: dict[str, str] = {}
    used_names: set[str] = set()
    valid_envs: list[str] = []
    for env_path in environments:
        if not os.path.exists(env_path):
            if output != "json":
                console.print(f"[yellow]Warning: Skipping {env_path} (path not found)[/yellow]")
            continue
        valid_envs.append(env_path)
        short = extract_env_short_name(env_path, existing_names=used_names)
        env_name_map[short] = env_path
        used_names.add(short)

    if not valid_envs:
        if output != "json":
            console.print("[yellow]No valid environments in group.[/yellow]")
        else:
            print(json.dumps({"error": "No valid environments in group"}))
        sys.exit(1)

    reverse_map = {v: k for k, v in env_name_map.items()}

    try:
        # Phase 1: Inspect current state across all environments
        canonical_pkgs = [_parse_package_name(p) for p in packages]
        env_versions: dict[str, dict[str, Optional[Version]]] = {}

        if ui:
            ui.start_phase(f"Inspecting {len(valid_envs)} environments...")

        for env_path in valid_envs:
            installed = inspect_installed_packages(timeout=timeout, python_path=env_path)
            installed_map: dict[str, Version] = {canonicalize_name(p.name): p.version for p in installed}
            short = reverse_map[env_path]
            pkg_versions: dict[str, Optional[Version]] = {}
            for i, spec in enumerate(packages):
                pkg_versions[spec] = installed_map.get(canonical_pkgs[i])
            env_versions[short] = pkg_versions

        if ui:
            ui.complete_phase(f"{len(valid_envs)} environments inspected")

        # Phase 2: Show matrix and confirm
        if output != "json":
            console.print()
            print_env_legend(env_name_map, console=console)
            console.print()
            print_group_install_matrix(
                env_versions, list(packages), env_name_map,
                upgrade=not no_update, console=console,
            )

            if not yes:
                action = "install/upgrade" if not no_update else "install"
                console.print()
                confirm = click.confirm(
                    f"{action.capitalize()} {len(packages)} package(s) across {len(valid_envs)} environments?",
                    default=True,
                )
                if not confirm:
                    console.print("[yellow]Installation cancelled.[/yellow]")
                    sys.exit(0)

        # Phase 3: Parallel install across environments
        env_results: dict[str, list] = {}
        env_order = list(env_name_map.keys())

        def _install_env(env_name: str, tracker=None):
            env_path = env_name_map[env_name]
            try:
                results = run_pip_install(
                    package_specs=list(packages),
                    upgrade=not no_update,
                    timeout=timeout,
                    python_path=env_path,
                    pre=pre,
                )
                if tracker:
                    tracker.complete_env(env_name)
                return env_name, results
            except Exception as e:
                if tracker:
                    tracker.fail_env(env_name, str(e))
                return env_name, []

        if ui:
            env_totals = {name: len(packages) for name in env_order}
            group_tracker = ui.show_group_install_progress(env_order, env_totals)

            with ThreadPoolExecutor(max_workers=len(env_order)) as executor:
                futures = {
                    executor.submit(_install_env, name, group_tracker): name
                    for name in env_order
                }
                for future in as_completed(futures):
                    name, results = future.result()
                    env_results[name] = results

            group_tracker.finish()
        else:
            with ThreadPoolExecutor(max_workers=len(env_order)) as executor:
                futures = {
                    executor.submit(_install_env, name): name
                    for name in env_order
                }
                for future in as_completed(futures):
                    name, results = future.result()
                    env_results[name] = results

        # Phase 4: Show results
        if output == "json":
            assert json_formatter is not None
            group_results = []
            for env_name in env_order:
                env_path = env_name_map[env_name]
                env_res = env_results.get(env_name, [])
                n_installed = len([r for r in env_res if r.installed])
                n_failed = len([r for r in env_res if not r.installed])
                group_results.append({
                    "environment": env_path,
                    "results": [json_formatter._package_to_dict(r) for r in env_res],
                    "summary": {
                        "total": len(env_res),
                        "installed": n_installed,
                        "failed": n_failed,
                    },
                })
            print(json_formatter.format_group_install_results(group_results))
        else:
            console.print()
            print_group_install_results_matrix(env_results, env_name_map, console=console)

        total_failed = sum(
            len([r for r in env_results.get(n, []) if not r.installed])
            for n in env_order
        )
        if total_failed:
            sys.exit(1)
        sys.exit(0)

    except KeyboardInterrupt:
        if ui:
            ui.cleanup()
        console.show_cursor(True)
        sys.exit(130)


@cli.command()
@click.pass_context
@click.argument('packages', nargs=-1, required=True)
@click.option(
    "--timeout",
    type=int,
    default=300,
    help="Uninstallation timeout in seconds"
)
@click.option(
    "--yes", "-y",
    is_flag=True,
    help="Skip confirmation prompt"
)
@click.option(
    "--debug",
    is_flag=True,
    help="Enable debug logging"
)
@click.option(
    "--output", "-o",
    type=click.Choice(["human", "json"]),
    default="human",
    help="Output format (human-readable or json)"
)
@click.option(
    "--group", "-g",
    "group_name",
    default=None,
    help="Uninstall across all environments in a named group"
)
def uninstall(ctx: click.Context, packages: tuple[str, ...], timeout: int,
              yes: bool, debug: bool, output: str,
              group_name: Optional[str] = None) -> None:
    """Uninstall packages using pip.

    \b
    Examples:
      pipu uninstall requests flask       Uninstall packages
      pipu uninstall requests -y          Skip confirmation
      pipu uninstall requests -g mygroup  Uninstall across a group
    """
    console = Console()

    config = load_config()
    if ctx.get_parameter_source('timeout') == ParameterSource.DEFAULT:
        timeout = get_config_value(config, 'timeout', 300)
    if ctx.get_parameter_source('yes') == ParameterSource.DEFAULT:
        yes = get_config_value(config, 'yes', False)
    if ctx.get_parameter_source('debug') == ParameterSource.DEFAULT:
        debug = get_config_value(config, 'debug', False)
    if ctx.get_parameter_source('output') == ParameterSource.DEFAULT:
        output = get_config_value(config, 'output', 'human')

    json_formatter = JsonOutputFormatter() if output == "json" else None

    if group_name is not None:
        _run_group_uninstall(
            group_name=group_name, console=console, output=output,
            packages=packages, timeout=timeout,
            yes=yes, json_formatter=json_formatter,
        )
        return

    if debug and output != "json":
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(message)s',
            handlers=[RichHandler(console=console, show_time=False, show_path=False, markup=True)]
        )
        logging.getLogger('pip._internal').setLevel(logging.WARNING)
        logging.getLogger('pip._vendor').setLevel(logging.WARNING)
        console.print("[dim]Debug mode enabled[/dim]\n")

    try:
        if output != "json":
            console.print("[bold]Step 1/2:[/bold] Packages to uninstall:\n")
            for pkg in packages:
                console.print(f"  - {pkg}")

        if not yes and output != "json":
            console.print()
            confirm = click.confirm("Do you want to proceed?", default=True)
            if not confirm:
                console.print("[yellow]Uninstallation cancelled.[/yellow]")
                sys.exit(0)

        if output != "json":
            console.print(f"\n[bold]Step 2/2:[/bold] Uninstalling {len(packages)} package(s)...\n")

        stream = ConsoleStream(console) if output != "json" else None
        results = run_pip_uninstall(
            package_names=list(packages),
            output_stream=stream,
            timeout=timeout,
        )

        if output == "json":
            assert json_formatter is not None
            print(json_formatter.format_uninstall_results(results))
        else:
            print_uninstall_results(results, console=console)

        failed = [r for r in results if not r.uninstalled]
        sys.exit(1 if failed else 0)

    except KeyboardInterrupt:
        console.show_cursor(True)
        sys.exit(130)
    except click.Abort:
        console.show_cursor(True)
        sys.exit(130)
    except Exception as e:
        if output == "json":
            print(json.dumps({"error": str(e)}))
        else:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)


def _run_group_uninstall(
    group_name: str, console: Console, output: str,
    packages: tuple, timeout: int,
    yes: bool,
    json_formatter: Optional[JsonOutputFormatter],
) -> None:
    """Execute uninstall across all environments in a group."""
    import os
    from pipu_cli.pretty import (
        extract_env_short_name, print_env_legend,
        print_group_uninstall_matrix, print_group_uninstall_results_matrix,
    )

    environments = get_group(group_name)
    if environments is None:
        if output == "json":
            print(json.dumps({"error": f"Group '{group_name}' not found"}))
        else:
            console.print(f"[red]Group not found:[/red] [cyan]{group_name}[/cyan]")
        sys.exit(1)

    ui = UpgradeUI(console) if output != "json" else None

    env_name_map: dict[str, str] = {}
    used_names: set[str] = set()
    valid_envs: list[str] = []
    for env_path in environments:
        if not os.path.exists(env_path):
            if output != "json":
                console.print(f"[yellow]Warning: Skipping {env_path} (path not found)[/yellow]")
            continue
        valid_envs.append(env_path)
        short = extract_env_short_name(env_path, existing_names=used_names)
        env_name_map[short] = env_path
        used_names.add(short)

    if not valid_envs:
        if output != "json":
            console.print("[yellow]No valid environments in group.[/yellow]")
        else:
            print(json.dumps({"error": "No valid environments in group"}))
        sys.exit(1)

    reverse_map = {v: k for k, v in env_name_map.items()}

    try:
        # Phase 1: Inspect current state across all environments
        canonical_pkgs = [_parse_package_name(p) for p in packages]
        env_versions: dict[str, dict[str, Optional[Version]]] = {}

        if ui:
            ui.start_phase(f"Inspecting {len(valid_envs)} environments...")

        for env_path in valid_envs:
            installed = inspect_installed_packages(timeout=timeout, python_path=env_path)
            installed_map: dict[str, Version] = {canonicalize_name(p.name): p.version for p in installed}
            short = reverse_map[env_path]
            pkg_versions: dict[str, Optional[Version]] = {}
            for i, pkg_name in enumerate(packages):
                pkg_versions[pkg_name] = installed_map.get(canonical_pkgs[i])
            env_versions[short] = pkg_versions

        if ui:
            ui.complete_phase(f"{len(valid_envs)} environments inspected")

        # Phase 2: Show matrix and confirm
        if output != "json":
            console.print()
            print_env_legend(env_name_map, console=console)
            console.print()
            print_group_uninstall_matrix(
                env_versions, list(packages), env_name_map, console=console,
            )

            if not yes:
                console.print()
                confirm = click.confirm(
                    f"Uninstall {len(packages)} package(s) across {len(valid_envs)} environments?",
                    default=True,
                )
                if not confirm:
                    console.print("[yellow]Uninstallation cancelled.[/yellow]")
                    sys.exit(0)

        # Phase 3: Parallel uninstall across environments
        env_results: dict[str, list] = {}
        env_order = list(env_name_map.keys())

        def _uninstall_env(env_name: str, tracker=None):
            env_path = env_name_map[env_name]
            try:
                results = run_pip_uninstall(
                    package_names=list(packages),
                    timeout=timeout,
                    python_path=env_path,
                )
                if tracker:
                    tracker.complete_env(env_name)
                return env_name, results
            except Exception as e:
                if tracker:
                    tracker.fail_env(env_name, str(e))
                return env_name, []

        if ui:
            env_totals = {name: len(packages) for name in env_order}
            group_tracker = ui.show_group_install_progress(env_order, env_totals)

            with ThreadPoolExecutor(max_workers=len(env_order)) as executor:
                futures = {
                    executor.submit(_uninstall_env, name, group_tracker): name
                    for name in env_order
                }
                for future in as_completed(futures):
                    name, results = future.result()
                    env_results[name] = results

            group_tracker.finish()
        else:
            with ThreadPoolExecutor(max_workers=len(env_order)) as executor:
                futures = {
                    executor.submit(_uninstall_env, name): name
                    for name in env_order
                }
                for future in as_completed(futures):
                    name, results = future.result()
                    env_results[name] = results

        # Phase 4: Show results
        if output == "json":
            assert json_formatter is not None
            group_results = []
            for env_name in env_order:
                env_path = env_name_map[env_name]
                results = env_results.get(env_name, [])
                uninstalled = len([r for r in results if r.uninstalled])
                failed = len([r for r in results if not r.uninstalled])
                group_results.append({
                    "environment": env_path,
                    "results": [{
                        "name": r.name,
                        "previous_version": str(r.previous_version) if r.previous_version else None,
                        "uninstalled": r.uninstalled,
                        "already_absent": r.already_absent,
                        "failure_reason": r.failure_reason,
                    } for r in results],
                    "summary": {
                        "total": len(results),
                        "uninstalled": uninstalled,
                        "failed": failed,
                    },
                })
            print(json_formatter.format_group_uninstall_results(group_results))
        else:
            console.print()
            print_group_uninstall_results_matrix(env_results, env_name_map, console=console)

        total_failed = sum(
            len([r for r in env_results.get(n, []) if not r.uninstalled])
            for n in env_order
        )
        if total_failed:
            sys.exit(1)
        sys.exit(0)

    except KeyboardInterrupt:
        if ui:
            ui.cleanup()
        console.show_cursor(True)
        sys.exit(130)


def pipuu() -> None:
    """Shorthand CLI that runs ``pipu upgrade``."""
    from rich.console import Console
    console = Console(stderr=True)
    console.print("[yellow]Warning: 'pipuu' is deprecated. Use 'pipu upgrade' (or just 'pipu') instead.[/yellow]\n")
    sys.argv = ["pipu", "upgrade"] + sys.argv[1:]
    cli()


if __name__ == "__main__":
    cli()
