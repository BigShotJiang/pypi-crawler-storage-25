import hashlib
import os
import secrets
import time
from typing import Any

from .step_runner import StepRunner, RunContext, StepResult


class RestApiRunner(StepRunner):
    """
    Default runner — handles HTTP REST steps and ``randomize`` utility steps.

    This runner is always registered automatically by ApiE2ETestsManager as
    the fallback runner. Steps that have a ``method:`` key are routed here,
    as are pure ``randomize:`` steps (no ``method:`` key).

    Retry is handled internally: set ``retry.attempts`` and
    ``retry.delay_seconds`` on any HTTP step.

    Supported ``send_as`` values: ``json`` (default), ``form``, ``multipart``.

    Example HTTP step::

        - name: "Create user"
          method: POST
          endpoint: "/api/v1/users"
          send_as: json
          body:
            email: "user@example.com"
          expect:
            status: 201
            body:
              id: string
          save:
            user_id: "{{body.id}}"
          assertions:
            - "{{body.email}} == 'user@example.com'"

    Example randomize step::

        - name: "Generate test identifiers"
          randomize:
            username: 8     # 8-char random hex string
            suffix: 4
    """

    @property
    def name(self) -> str:
        return "rest"

    def handles(self, step: dict) -> bool:
        return "method" in step or ("randomize" in step and "method" not in step)

    # setup / teardown not needed — stateless runner

    def execute(self, step: dict, ctx: RunContext) -> StepResult:
        if "randomize" in step and "method" not in step:
            return self._handle_randomize(step, ctx)
        return self._handle_http(step, ctx)

    # ------------------------------------------------------------------ #
    #  Randomize
    # ------------------------------------------------------------------ #

    def _handle_randomize(self, step: dict, ctx: RunContext) -> StepResult:
        spec = step["randomize"]
        if isinstance(spec, dict):
            for key, length in spec.items():
                if not isinstance(length, int) or length <= 0:
                    length = 8
                ctx.store_value(key, self._random_string(length))
        elif isinstance(spec, list):
            for key in spec:
                ctx.store_value(key, self._random_string(8))
        return StepResult.passed()

    @staticmethod
    def _random_string(length: int = 8) -> str:
        n_bytes = (length + 1) // 2
        return secrets.token_hex(n_bytes)[:length]

    # ------------------------------------------------------------------ #
    #  HTTP
    # ------------------------------------------------------------------ #

    def _handle_http(self, step: dict, ctx: RunContext) -> StepResult:
        retry_config = step.get("retry", {})
        max_attempts = retry_config.get("attempts", 1)
        delay_seconds = retry_config.get("delay_seconds", 0)

        last_error: Any = None
        for attempt in range(max_attempts):
            try:
                if attempt > 0:
                    print(f"   Retry attempt {attempt + 1}/{max_attempts} after {delay_seconds}s delay...")
                    time.sleep(delay_seconds)

                result = self._do_request(step, ctx)

                if attempt > 0:
                    print(f"   Passed on retry attempt {attempt + 1}/{max_attempts}")

                return result

            except Exception as e:
                last_error = e
                if attempt < max_attempts - 1:
                    print(f"[RETRY] Attempt {attempt + 1} failed: {e}")

        return StepResult.failed(str(last_error))

    def _do_request(self, step: dict, ctx: RunContext) -> StepResult:
        url = ctx.base_url + ctx.substitute_stored(step["endpoint"])
        method = step["method"].upper()

        # --- Headers ---
        request_headers = {}
        for header in step.get("request_headers", []):
            for hk, hv in header.items():
                if isinstance(hv, str):
                    hv = ctx.substitute_stored(hv)
                request_headers[hk] = hv

        # --- Query params ---
        request_query_params = {}
        params = step.get("request_query_params", {})
        if isinstance(params, dict):
            for pk, pv in params.items():
                if isinstance(pv, str):
                    pv = ctx.substitute_stored(pv)
                request_query_params[pk] = pv
        elif params:
            raise ValueError(f"request_query_params must be a dict, got {type(params)}")

        # --- Body ---
        body = step.get("body")
        if body is not None:
            body = ctx.substitute_stored_in_body(body)

        expect = step.get("expect", {})
        timeout = step.get("request_timeout", 10)
        send_as = step.get("send_as", "json").lower()

        request_kwargs = {
            "method": method,
            "url": url,
            "headers": request_headers,
            "params": request_query_params,
            "timeout": timeout,
        }

        if send_as == "json":
            if body is not None:
                request_kwargs["json"] = body
        elif send_as == "form":
            if body is not None:
                request_kwargs["data"] = body
        elif send_as == "multipart":
            files_to_send = []
            for f_spec in step.get("files", []):
                field = f_spec["field"]
                path = ctx.substitute_stored(f_spec["path"])
                content_type = f_spec.get("content_type", "application/octet-stream")
                with open(path, "rb") as fp:
                    file_content = fp.read()
                files_to_send.append((field, (os.path.basename(path), file_content, content_type)))
            if body is not None:
                request_kwargs["data"] = {k: str(v) for k, v in body.items()}
            if files_to_send:
                request_kwargs["files"] = files_to_send
        elif body is not None:
            raise ValueError(f"Invalid send_as: '{send_as}'. Must be 'json', 'form', or 'multipart'.")

        resp = ctx.session.request(**request_kwargs)
        print(f" -> {method} {url} -> {resp.status_code}")

        if ctx.is_verbose:
            print(f"Response text: {resp.text}")

        # --- Status assertion ---
        expected_status = expect.get("status")
        if expected_status and resp.status_code != expected_status:
            raise AssertionError(f"Expected status {expected_status}, got {resp.status_code}")

        # --- JSON parsing ---
        needs_json = "body" in expect or "assertions" in step or "save" in step
        resp_json = None
        if needs_json:
            try:
                resp_json = resp.json()
            except Exception:
                raise AssertionError("Response is not valid JSON")

        # --- File SHA256 check ---
        if "file_sha256_matches" in expect:
            local_path = ctx.substitute_stored(expect["file_sha256_matches"])
            response_sha256 = hashlib.sha256(resp.content).hexdigest()
            with open(local_path, "rb") as f:
                local_sha256 = hashlib.sha256(f.read()).hexdigest()
            if response_sha256 != local_sha256:
                raise AssertionError(
                    f"File SHA256 mismatch: response={response_sha256}, local={local_sha256}"
                )

        if "save_file_sha256" in step:
            ctx.store_value(step["save_file_sha256"], hashlib.sha256(resp.content).hexdigest())

        if resp_json is not None:
            if "body" in expect:
                if ctx.is_verbose:
                    print(f"Response body: {resp_json}")
                ctx.validate_structure(resp_json, expect["body"])

            if "assertions" in step:
                for expr in step["assertions"]:
                    try:
                        expr = ctx.substitute_stored(expr)
                        rendered = ctx.render_template(expr, {"body": resp_json}, add_quotes=True)
                        ctx.try_eval(rendered, expr)
                    except Exception as e:
                        raise AssertionError(
                            f"Assertion failed for expression\n    -->'{expr}'\n    -->{e}"
                        )

            if "save" in step:
                for key, path_expr in step["save"].items():
                    try:
                        path_expr = ctx.substitute_stored(str(path_expr))
                        rendered = ctx.render_template(path_expr, {"body": resp_json})
                        ctx.store_value(key, rendered)
                    except Exception as e:
                        raise AssertionError(
                            f"Failed to render save path\n    -->'{path_expr}'\n    -->{e}"
                        )

        return StepResult.passed()
