﻿import ast
import datetime
import hashlib
import os
import re
import secrets
import time
import yaml
import requests
from pathlib import Path
from typing import Any, Dict, List, Optional

from .step_runner import StepRunner, RunContext, StepResult
from .runner_rest_api import RestApiRunner
from .runner_email_mock import EmailMockRunner


class ScenarioSkippedException(Exception):
    """Raised when a scenario skip_if condition evaluates to true."""
    pass


class ApiE2ETestsManager:
    VAR_PATTERN = re.compile(r"\$var\(([A-Za-z0-9_]+)\)")
    STORED_PATTERN = re.compile(r"\{\$stored\.([a-zA-Z0-9_.]+)\}")
    TEMPLATE_PATTERN = re.compile(r"\{\{\s*([^}]+?)\s*\}\}")

    global_store: Dict[str, Any] = {}
    scenario_results: List[Dict[str, Any]] = []

    @staticmethod
    def run_all_tests(
        folder_paths,
        env_file_path,
        is_verbose: bool = False,
        runners: Optional[List[StepRunner]] = None
    ):
        print("\nRunning API E2E tests...")
        ApiE2ETestsManager.global_store = {}
        ApiE2ETestsManager.scenario_results = []

        active_runners: List[StepRunner] = [RestApiRunner()]
        if runners:
            active_runners.extend(runners)

        default_runner = active_runners[0]
        extra_runners = active_runners[1:]

        for runner in active_runners:
            runner.setup(env_file_path)

        if isinstance(folder_paths, (str, Path)):
            folder_paths = [folder_paths]

        scenario_entries = []
        for folder in folder_paths:
            p = Path(folder)
            entries = sorted(
                [(str(folder), f.name) for f in p.iterdir() if f.is_file() and f.suffix == ".yaml"],
                key=lambda x: x[1],
            )
            scenario_entries.extend(entries)

        total_start = time.time()
        all_tests_passed = True

        try:
            for i, (folder_path, filename) in enumerate(scenario_entries):
                yaml_file_path = os.path.join(folder_path, filename)
                scenario_name = os.path.splitext(filename)[0]
                start_time = None
                step_metrics = []

                try:
                    print(f"\n--- Running scenario: {filename} ---")
                    spec = ApiE2ETestsManager.parse_and_load_yaml(yaml_file_path, env_file_path)
                    start_time = time.time()
                    step_metrics = ApiE2ETestsManager.run_yaml_test(
                        spec, scenario_name, is_verbose, default_runner, extra_runners
                    )
                    elapsed = time.time() - start_time

                    any_failed = any(s["result"] == "FAIL" for s in step_metrics)
                    all_skipped = step_metrics and all(s["result"] == "SKIP" for s in step_metrics)

                    if any_failed:
                        ApiE2ETestsManager.scenario_results.append({
                            "scenario": scenario_name, "status": "[FAIL]",
                            "steps": step_metrics, "total_time": elapsed,
                        })
                        all_tests_passed = False
                        for _, sf in scenario_entries[i + 1:]:
                            ApiE2ETestsManager.scenario_results.append({
                                "scenario": os.path.splitext(sf)[0], "status": "[SKIP]",
                                "steps": [], "total_time": 0,
                            })
                        break
                    else:
                        ApiE2ETestsManager.scenario_results.append({
                            "scenario": scenario_name,
                            "status": "[SKIP]" if all_skipped else "[PASS]",
                            "steps": step_metrics, "total_time": elapsed,
                        })

                except ScenarioSkippedException:
                    ApiE2ETestsManager.scenario_results.append({
                        "scenario": scenario_name, "status": "[SKIP]",
                        "steps": [], "total_time": 0,
                    })

                except AssertionError:
                    failed_elapsed = time.time() - start_time if start_time else 0
                    ApiE2ETestsManager.scenario_results.append({
                        "scenario": scenario_name, "status": "[FAIL]",
                        "steps": step_metrics, "total_time": failed_elapsed,
                    })
                    all_tests_passed = False
                    for _, sf in scenario_entries[i + 1:]:
                        ApiE2ETestsManager.scenario_results.append({
                            "scenario": os.path.splitext(sf)[0], "status": "[SKIP]",
                            "steps": [], "total_time": 0,
                        })
                    break

        finally:
            for runner in reversed(active_runners):
                runner.teardown()

        total_elapsed = time.time() - total_start
        print("\nAPI E2E tests completed.")
        ApiE2ETestsManager.print_summary(total_elapsed, all_tests_passed)

        if not all_tests_passed:
            exit(1)

    @staticmethod
    def _resolve_runner(step, default_runner, extra_runners):
        runner_name = step.get("runner")
        if runner_name is not None:
            if runner_name == default_runner.name:
                return default_runner
            for r in extra_runners:
                if r.name == runner_name:
                    return r
            raise ValueError(
                f"Step '{step.get('name', '?')}' specifies runner='{runner_name}' "
                f"but no runner with that name is registered. "
                f"Registered: {[default_runner.name] + [r.name for r in extra_runners]}"
            )
        for r in extra_runners:
            if r.handles(step):
                return r
        return default_runner

    @staticmethod
    def run_yaml_test(spec, scenario_name, is_verbose=False,
                      default_runner=None, extra_runners=None):
        base_url = spec.get("base_url", "")
        steps = spec.get("steps", [])
        step_metrics = []

        if default_runner is None:
            default_runner = RestApiRunner()
        if extra_runners is None:
            extra_runners = []

        print(f"Running test: {spec.get('name', scenario_name)}")
        print(f"Base URL: {base_url}")
        print("=" * 60)

        for condition in spec.get("skip_if", []):
            if ApiE2ETestsManager._eval_condition(condition, scenario_name):
                print(f"   Skipping scenario: condition '{condition}' was true")
                raise ScenarioSkippedException(f"skip_if condition met: {condition}")

        session = requests.Session()
        ctx = RunContext(
            scenario_name=scenario_name,
            is_verbose=is_verbose,
            base_url=base_url,
            session=session,
            _fn_substitute_stored=ApiE2ETestsManager.substitute_stored,
            _fn_render_template=ApiE2ETestsManager.render_template,
            _fn_try_eval=ApiE2ETestsManager.try_eval,
            _fn_store_value=ApiE2ETestsManager.store_value,
            _fn_substitute_stored_in_body=ApiE2ETestsManager.substitute_stored_in_body,
            _fn_validate_structure=ApiE2ETestsManager.validate_structure,
        )

        for step in steps:
            step_start = time.time()
            print(f"Step: {step['name']}")

            if any(ApiE2ETestsManager._eval_condition(c, scenario_name) for c in step.get("skip_if", [])):
                elapsed = time.time() - step_start
                step_metrics.append({"name": step["name"], "time": elapsed, "result": "SKIP"})
                print(f"[SKIP] Step skipped in {elapsed:.2f}s\n")
                continue

            try:
                runner = ApiE2ETestsManager._resolve_runner(step, default_runner, extra_runners)
            except ValueError as e:
                elapsed = time.time() - step_start
                step_metrics.append({"name": step["name"], "time": elapsed, "result": "FAIL", "error": str(e)})
                print(f"[FAIL] {e}\n")
                break

            result = runner.execute(step, ctx)
            elapsed = time.time() - step_start

            metric = {"name": step["name"], "time": elapsed, "result": result.result}
            if result.error:
                metric["error"] = result.error
            step_metrics.append(metric)

            if result.result == "PASS":
                print(f"[OK  ] Step passed in {elapsed:.2f}s\n")
            elif result.result == "SKIP":
                print(f"[SKIP] Step skipped in {elapsed:.2f}s\n")
            else:
                print(f"[FAIL] Step failed in {elapsed:.2f}s\n       Error: {result.error}\n")
                break

        print("=" * 60)
        return step_metrics

    @staticmethod
    def read_env_value_from_file(env_file_path, env_var):
        try:
            with open(env_file_path, "r", encoding="utf-8") as file:
                for raw in file:
                    line = raw.strip()
                    if not line or line.startswith("#"):
                        continue
                    if line.startswith(f"{env_var}="):
                        return line[len(f"{env_var}="):].strip()
        except FileNotFoundError:
            print(f"[WARN] Environment file not found: {env_file_path}")
            return ""
        print(f"[WARN] Environment variable '{env_var}' not found in {env_file_path}.")
        return ""

    @staticmethod
    def parse_and_load_yaml(yaml_file_path, env_file_path):
        with open(yaml_file_path, "r", encoding="utf-8") as f:
            content = f.read()

        def replacer(match):
            key = match.group(1)
            return ApiE2ETestsManager.read_env_value_from_file(env_file_path, key)

        resolved_content = ApiE2ETestsManager.VAR_PATTERN.sub(replacer, content)
        return yaml.safe_load(resolved_content)

    @staticmethod
    def check_type(value, expected_type):
        is_nullable = expected_type.endswith("?")
        if is_nullable:
            base_type = expected_type[:-1]
            if value is None:
                return True
        else:
            base_type = expected_type

        type_map = {
            "string": str, "number": (int, float),
            "boolean": bool, "datetime": str,
        }
        if base_type not in type_map:
            raise ValueError(f"Unknown type in YAML: {expected_type}")
        if base_type == "datetime":
            try:
                datetime.datetime.fromisoformat(value)
                return True
            except Exception:
                try:
                    if re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{1,6}$", value):
                        datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%f")
                    return True
                except Exception:
                    return False
        return isinstance(value, type_map[base_type])

    @staticmethod
    def validate_structure(data, expected):
        if isinstance(expected, dict):
            if not isinstance(data, dict):
                raise AssertionError(f"Expected dict but got {type(data)}")
            for k, v in expected.items():
                if k not in data:
                    raise AssertionError(f"Missing key: {k} (Data keys: {list(data.keys())})")
                ApiE2ETestsManager.validate_structure(data[k], v)
        elif isinstance(expected, list):
            if not isinstance(data, list):
                raise AssertionError(f"Expected list but got {type(data)}")
            if len(expected) > 0:
                for item in data:
                    ApiE2ETestsManager.validate_structure(item, expected[0])
        elif isinstance(expected, str):
            if not ApiE2ETestsManager.check_type(data, expected):
                raise AssertionError(f"Expected {expected}, got {data} ({type(data)})")
        else:
            raise ValueError(f"Invalid expected type: {expected}")

    @staticmethod
    def render_template(template_str, context, add_quotes=False):
        def resolve_path(expr, ctx):
            val = ctx
            current_path = ""
            i = 0
            while i < len(expr):
                if expr[i] == "[":
                    end = expr.find("]", i)
                    if end == -1:
                        raise ValueError(f"Unclosed bracket in path: {expr}")
                    index_str = expr[i + 1:end].strip()
                    try:
                        index = int(index_str)
                    except ValueError:
                        raise ValueError(f"Invalid array index '{index_str}' in path: {expr}")
                    if not isinstance(val, list):
                        raise KeyError(f"Cannot index non-list at '{current_path}' in path: {expr}")
                    if index < 0 or index >= len(val):
                        raise KeyError(f"Index {index} out of range at '{current_path}' in path: {expr}")
                    val = val[index]
                    current_path += f"[{index}]"
                    i = end + 1
                    if i < len(expr) and expr[i] == ".":
                        i += 1
                elif expr[i] == ".":
                    i += 1
                else:
                    next_dot = expr.find(".", i)
                    next_bracket = expr.find("[", i)
                    next_paren = expr.find("(", i)
                    candidates = [c for c in [next_dot, next_bracket, next_paren] if c != -1]
                    end_pos = min(candidates) if candidates else len(expr)
                    prop = expr[i:end_pos].strip()
                    if prop:
                        if end_pos < len(expr) and expr[end_pos] == "(":
                            if prop == "count":
                                close_paren = expr.find(")", end_pos)
                                if close_paren == -1:
                                    raise ValueError(f"Unclosed parenthesis in: {expr}")
                                if expr[end_pos + 1:close_paren].strip():
                                    raise ValueError(f"count() takes no arguments: {expr}")
                                if isinstance(val, (list, dict)):
                                    val = len(val)
                                else:
                                    raise KeyError(f"Cannot call count() on {type(val).__name__}")
                                current_path += ".count()"
                                i = close_paren + 1
                                if i < len(expr) and expr[i] == ".":
                                    i += 1
                            else:
                                raise ValueError(f"Unsupported function '{prop}()': {expr}")
                        elif isinstance(val, dict) and prop in val:
                            val = val[prop]
                            current_path += f".{prop}" if current_path and not current_path.endswith("]") else prop
                            i = end_pos
                        else:
                            raise KeyError(f"Cannot resolve '{expr}': '{prop}' not found at '{current_path}'")
                    else:
                        i = end_pos
            return val

        def replacer(match):
            expr = match.group(1).strip()
            val = resolve_path(expr, context)
            if isinstance(val, str):
                return repr(val) if add_quotes else str(val)
            elif val is True:
                return "True"
            elif val is False:
                return "False"
            elif val is None:
                return "None"
            else:
                return str(val)

        return ApiE2ETestsManager.TEMPLATE_PATTERN.sub(replacer, template_str)

    @staticmethod
    def substitute_stored(expr, scenario_name):
        def repl(match):
            key = match.group(1).strip()
            parts = key.split(".")
            if len(parts) == 1:
                return str(ApiE2ETestsManager.global_store.get(
                    f"{scenario_name}.{parts[0]}", f"<MISSING:{parts[0]}>"
                ))
            elif len(parts) == 2:
                scen, subkey = parts
                return str(ApiE2ETestsManager.global_store.get(f"{scen}.{subkey}", f"<MISSING:{key}>"))
            else:
                raise ValueError(f"Invalid stored key reference: {key} (too many dots)")
        return ApiE2ETestsManager.STORED_PATTERN.sub(repl, expr)

    @staticmethod
    def substitute_stored_in_body(body, scenario_name):
        if body is None:
            return None
        elif isinstance(body, dict):
            return {k: ApiE2ETestsManager.substitute_stored_in_body(v, scenario_name) for k, v in body.items()}
        elif isinstance(body, list):
            return [ApiE2ETestsManager.substitute_stored_in_body(item, scenario_name) for item in body]
        elif isinstance(body, str):
            return ApiE2ETestsManager.substitute_stored(body, scenario_name)
        else:
            return body

    @staticmethod
    def store_value(key, value, scenario_name):
        namespaced_key = f"{scenario_name}.{key}"
        ApiE2ETestsManager.global_store[namespaced_key] = value
        print(f"   Saved: {namespaced_key} = {value}")

    @staticmethod
    def generate_random_string(length: int = 8) -> str:
        n_bytes = (length + 1) // 2
        return secrets.token_hex(n_bytes)[:length]

    @staticmethod
    def _eval_condition(condition, scenario_name) -> bool:
        try:
            resolved = ApiE2ETestsManager.substitute_stored(condition, scenario_name)
            ApiE2ETestsManager.try_eval(resolved, condition)
            return True
        except AssertionError:
            return False

    @staticmethod
    def _generate_random_file_content(file_type: str) -> bytes:
        random_payload = os.urandom(128)
        if file_type in ("png", "jpeg", "jpg"):
            return b"\x89PNG\r\n\x1a\n" + random_payload
        elif file_type == "pdf":
            return b"%PDF-1.0\n" + random_payload + b"\n%%EOF\n"
        else:
            return random_payload

    @staticmethod
    def generate_test_assets(assets_dir: str, assets: list):
        os.makedirs(assets_dir, exist_ok=True)
        for spec in assets:
            filename = spec["filename"]
            file_type = spec.get("type", "bin")
            path = os.path.join(assets_dir, filename)
            content = ApiE2ETestsManager._generate_random_file_content(file_type)
            with open(path, "wb") as f:
                f.write(content)
            print(f"[assets] Generated: {filename} ({len(content)} bytes)")

    @staticmethod
    def cleanup_test_assets(assets_dir: str, assets: list):
        for spec in assets:
            path = os.path.join(assets_dir, spec["filename"])
            try:
                os.remove(path)
                print(f"[assets] Removed: {spec['filename']}")
            except FileNotFoundError:
                pass

    @staticmethod
    def try_eval(rendered, expr):
        operators = ["not in", ">=", "<=", ">", "<", "==", "!=", "in", "include"]
        matched_op = None
        left = right = ""
        for op in operators:
            if f" {op} " in rendered:
                matched_op = op
                left, right = [p.strip() for p in rendered.split(f" {op} ", 1)]
                break

        if not matched_op:
            raise AssertionError(f"Unsupported assertion format: '{expr}'")

        def try_eval_part(value):
            if re.match(r"^-?\d+\.\d+$", value):
                return float(value)
            elif re.match(r"^-?\d+$", value):
                return int(value)
            elif value.lower() == "true":
                return True
            elif value.lower() == "false":
                return False
            elif value.lower() == "none":
                return None
            elif value.startswith('"') and value.endswith('"'):
                return value.strip('"')
            elif value.startswith("'") and value.endswith("'"):
                return value.strip("'")
            else:
                try:
                    return ast.literal_eval(value)
                except Exception:
                    return value

        left_val = try_eval_part(left)
        right_val = try_eval_part(right)

        result = False
        if matched_op == "==":
            result = left_val == right_val
        elif matched_op == "!=":
            result = left_val != right_val
        elif matched_op == ">":
            result = left_val > right_val
        elif matched_op == "<":
            result = left_val < right_val
        elif matched_op == ">=":
            result = left_val >= right_val
        elif matched_op == "<=":
            result = left_val <= right_val
        elif matched_op == "in":
            result = left_val in right_val
        elif matched_op == "not in":
            result = left_val not in right_val
        elif matched_op == "include":
            result = right_val in left_val

        if not result:
            raise AssertionError(
                f"Assertion failed: {expr}  ->  evaluated as {left_val} {matched_op} {right_val}"
            )
        return True

    @staticmethod
    def print_summary(total_time, all_tests_passed):
        print("\n[SUMMARY] TEST RESULTS")
        print("=" * 80)
        headers = ["Scenario", "Status", "Time (s)", "Steps"]
        col_widths = [30, 7, 8, 50]
        header_line = (
            f"{headers[0]:<{col_widths[0]}} | {headers[1]:<{col_widths[1]}} | "
            f"{headers[2]:<{col_widths[2]}} | {headers[3]}"
        )
        print(header_line)
        print("-" * len(header_line))

        for result in ApiE2ETestsManager.scenario_results:
            print(
                f"{result['scenario']:<{col_widths[0]}} | "
                f"{result['status']:<{col_widths[1]}} | "
                f"{result['total_time']:<{col_widths[2]}.2f} | "
            )
            if result["steps"]:
                for step in result["steps"]:
                    parsed = f"[{step['result']}] {step['name']} ({step['time']:.2f}s)"
                    print(
                        f"{'':<{col_widths[0]}} | {'':<{col_widths[1]}} | "
                        f"{'':<{col_widths[2]}} | {parsed:<{col_widths[3]}}"
                    )
                    if step["result"] == "FAIL" and "error" in step:
                        print(
                            f"{'':<{col_widths[0]}} | {'':<{col_widths[1]}} | "
                            f"{'':<{col_widths[2]}} | ===> {step['error']}"
                        )
            else:
                print(
                    f"{'':<{col_widths[0]}} | {'':<{col_widths[1]}} | "
                    f"{'':<{col_widths[2]}} | {'(no steps run)':<{col_widths[3]}}"
                )

        print("=" * 80)
        print(f"Total Execution Time: {total_time:.2f}s\n")
        if all_tests_passed:
            print("ALL TESTS PASSED")
        else:
            print("SOME TESTS FAILED")
