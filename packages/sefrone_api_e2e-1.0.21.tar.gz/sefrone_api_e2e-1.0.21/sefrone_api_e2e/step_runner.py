from abc import ABC, abstractmethod
from typing import Any, Optional

import requests


class RunContext:
    """
    Immutable context passed to every StepRunner.execute() call.

    Provides scenario-scoped access to the global store and template helpers
    so that runners never need to import ApiE2ETestsManager directly.
    """

    def __init__(
        self,
        scenario_name: str,
        is_verbose: bool,
        base_url: str,
        session: "requests.Session",
        _fn_substitute_stored,
        _fn_render_template,
        _fn_try_eval,
        _fn_store_value,
        _fn_substitute_stored_in_body,
        _fn_validate_structure,
    ):
        self.scenario_name = scenario_name
        self.is_verbose = is_verbose
        self.base_url = base_url
        self.session = session
        self._fn_substitute_stored = _fn_substitute_stored
        self._fn_render_template = _fn_render_template
        self._fn_try_eval = _fn_try_eval
        self._fn_store_value = _fn_store_value
        self._fn_substitute_stored_in_body = _fn_substitute_stored_in_body
        self._fn_validate_structure = _fn_validate_structure

    def substitute_stored(self, expr: str) -> str:
        return self._fn_substitute_stored(expr, self.scenario_name)

    def render_template(self, template: str, context: dict, add_quotes: bool = False) -> str:
        return self._fn_render_template(template, context, add_quotes)

    def try_eval(self, rendered: str, expr: str) -> bool:
        return self._fn_try_eval(rendered, expr)

    def store_value(self, key: str, value: Any) -> None:
        return self._fn_store_value(key, value, self.scenario_name)

    def substitute_stored_in_body(self, body: Any) -> Any:
        return self._fn_substitute_stored_in_body(body, self.scenario_name)

    def validate_structure(self, data: Any, expected: Any) -> None:
        return self._fn_validate_structure(data, expected)


class StepResult:
    """Result returned from StepRunner.execute()."""

    __slots__ = ("result", "error")

    def __init__(self, result: str, error: Optional[str] = None):
        if result not in ("PASS", "FAIL", "SKIP"):
            raise ValueError(f"Invalid result value: {result!r}. Must be PASS, FAIL, or SKIP.")
        self.result = result
        self.error = error

    @classmethod
    def passed(cls) -> "StepResult":
        return cls("PASS")

    @classmethod
    def failed(cls, error: str) -> "StepResult":
        return cls("FAIL", error=error)

    @classmethod
    def skipped(cls) -> "StepResult":
        return cls("SKIP")


class StepRunner(ABC):
    """
    Abstract base class for all e2e step runners.

    Each runner manages its own resources (servers, clients, etc.) and handles
    a specific category of YAML step.

    Lifecycle (called by ApiE2ETestsManager.run_all_tests):
        1. setup(env_file_path)   — once, before the first scenario starts
        2. execute(step, ctx)     — once per step this runner owns
        3. teardown()             — once, after all scenarios finish (always called)

    Routing:
        Steps opt into a specific runner by setting ``runner: <name>`` in their
        YAML definition. When ``runner:`` is omitted the manager calls
        ``handles(step)`` on each extra runner in registration order; the first
        match wins. If no extra runner claims the step, the default
        ``RestApiRunner`` is used.

    Example — adding a custom runner::

        class MyRunner(StepRunner):
            @property
            def name(self) -> str:
                return "my_runner"

            def handles(self, step: dict) -> bool:
                return "my_key" in step and "method" not in step

            def execute(self, step: dict, ctx: RunContext) -> StepResult:
                ...
                return StepResult.passed()

        ApiE2ETestsManager.run_all_tests(
            [...],
            ".env",
            runners=[MyRunner()],
        )

    The corresponding YAML step::

        - name: "Do something custom"
          runner: my_runner        # explicit — or omit for auto-detection via handles()
          my_key:
            some_param: value
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique name — must match the ``runner:`` value used in YAML steps."""

    def setup(self, env_file_path: str) -> None:
        """
        Initialise runner resources (start servers, patch env files, etc.).
        Called once before any scenario runs.
        """

    def teardown(self) -> None:
        """
        Release runner resources.
        Always called, even when tests fail mid-run.
        """

    @abstractmethod
    def execute(self, step: dict, ctx: RunContext) -> StepResult:
        """
        Execute one step and return a StepResult.
        Must not raise unhandled exceptions — catch and return StepResult.failed().
        """

    def handles(self, step: dict) -> bool:
        """
        Auto-detection hook used when a step has no explicit ``runner:`` key.
        Return True only when this runner exclusively owns the step type.
        """
        return False
