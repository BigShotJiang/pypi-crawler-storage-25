from pathlib import Path

import pytest

from keep import state
from keep._daemon import runtime_state
from keep._daemon.verdict_handlers import _handle_task_claim, _handle_task_design_review
from keep._daemon.review import check_task_design_review_events


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    (state_dir / "missions").mkdir(parents=True)
    monkeypatch.setenv("KEEP_HOME", str(state_dir))
    return state_dir


@pytest.fixture
def mission_id(isolated_state: Path) -> str:
    name = "test-mission"
    state.create_mission(name)
    return name


# ── Task default status ───────────────────────────────────────


def test_task_default_status_is_proposed(isolated_state: Path) -> None:
    task = state.create_task("m1", subject="do something")
    assert task["status"] == "proposed"


# ── Reviewer CRUD ─────────────────────────────────────────────
#
# Reviewer IDs are opaque UUID4 strings (see `keep._state.reviewers.
# _next_reviewer_id`). Tests must not hard-code them; use whatever
# `add_reviewer` returns.


def _is_uuid_like(value: str) -> bool:
    # UUID4 canonical form: 8-4-4-4-12 hex.
    import re
    return bool(re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", value))


def test_add_reviewer_returns_reviewer_id(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-abc", "role": "reviewer"})
    assert isinstance(reviewer_id, str)
    assert _is_uuid_like(reviewer_id)


def test_add_reviewer_stores_data(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-abc", "role": "reviewer"})
    reviewer = state.get_reviewer(mission_id, reviewer_id)
    assert reviewer["session"] == "sess-abc"
    assert reviewer["role"] == "reviewer"
    assert reviewer["id"] == reviewer_id


def test_get_reviewer_existing(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    reviewer = state.get_reviewer(mission_id, reviewer_id)
    assert reviewer["id"] == reviewer_id


def test_get_reviewer_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.get_reviewer(mission_id, "r99")


def test_remove_reviewer_then_get_raises(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    state.remove_reviewer(mission_id, reviewer_id)
    with pytest.raises(ValueError, match=reviewer_id):
        state.get_reviewer(mission_id, reviewer_id)


def test_remove_reviewer_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.remove_reviewer(mission_id, "r99")


def test_update_reviewer_updates_field(mission_id: str) -> None:
    reviewer_id = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    updated = state.update_reviewer(mission_id, reviewer_id, status="active")
    assert updated["status"] == "active"
    # Persisted
    reloaded = state.get_reviewer(mission_id, reviewer_id)
    assert reloaded["status"] == "active"


def test_update_reviewer_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.update_reviewer(mission_id, "r99", status="active")


def test_iter_reviewers_returns_all(mission_id: str) -> None:
    id1 = state.add_reviewer(mission_id, {"session": "sess-1", "role": "reviewer"})
    id2 = state.add_reviewer(mission_id, {"session": "sess-2", "role": "reviewer"})
    reviewers = list(state.iter_reviewers(mission_id))
    assert len(reviewers) == 2
    ids = {r["id"] for r in reviewers}
    assert ids == {id1, id2}


def test_iter_reviewers_empty(mission_id: str) -> None:
    reviewers = list(state.iter_reviewers(mission_id))
    assert reviewers == []


# ── Review Event CRUD ─────────────────────────────────────────


def test_add_review_event_returns_event_id(mission_id: str) -> None:
    event_id = state.add_review_event(mission_id, {"type": "lgtm", "reviewer": "r1"})
    assert event_id == "re1"


def test_add_review_event_stores_data(mission_id: str) -> None:
    state.add_review_event(mission_id, {"type": "lgtm", "reviewer": "r1"})
    event = state.get_review_event(mission_id, "re1")
    assert event["type"] == "lgtm"
    assert event["reviewer"] == "r1"
    assert event["id"] == "re1"
    assert event["round"] == 1


def test_get_review_event_existing(mission_id: str) -> None:
    state.add_review_event(mission_id, {"type": "request_changes"})
    event = state.get_review_event(mission_id, "re1")
    assert event["id"] == "re1"


def test_get_review_event_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="re99"):
        state.get_review_event(mission_id, "re99")


def test_update_review_event_updates_field(mission_id: str) -> None:
    state.add_review_event(mission_id, {"type": "lgtm"})
    updated = state.update_review_event(mission_id, "re1", resolved=True)
    assert updated["resolved"] is True
    # Persisted
    reloaded = state.get_review_event(mission_id, "re1")
    assert reloaded["resolved"] is True


def test_update_review_event_nonexistent_raises(mission_id: str) -> None:
    with pytest.raises(ValueError, match="re99"):
        state.update_review_event(mission_id, "re99", resolved=True)


def test_add_multiple_review_events_sequential_ids(mission_id: str) -> None:
    id1 = state.add_review_event(mission_id, {"type": "lgtm"})
    id2 = state.add_review_event(mission_id, {"type": "request_changes"})
    assert id1 == "re1"
    assert id2 == "re2"


def test_check_task_design_review_events_reopens_same_event_and_keeps_passed_reviewers(
    mission_id: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reviewer_pass = state.add_reviewer(mission_id, {"session": "sess-pass", "role": "reviewer"})
    reviewer_reject = state.add_reviewer(mission_id, {"session": "sess-reject", "role": "reviewer"})
    state.create_task(mission_id, subject="Task 1")
    state.create_task(mission_id, subject="Task 2")
    state.update_task(
        mission_id,
        "1",
        {"status": "awaiting_review", "review_rationale": "/tmp/rationale-1.md"},
    )
    state.update_task(
        mission_id,
        "2",
        {"status": "awaiting_review", "review_rationale": "/tmp/rationale-1.md"},
    )

    sent: list[set[str] | None] = []
    monkeypatch.setattr(
        "keep._daemon.review.notify_all_reviewers",
        lambda mission, msg, reviewer_ids=None: sent.append(reviewer_ids),
    )
    runtime_state.review_dispatched.clear()
    runtime_state.save()

    mission = state.load_mission(mission_id)
    assert mission is not None
    check_task_design_review_events(mission_id, mission)

    first_event = state.get_review_event(mission_id, "re1")
    assert first_event["round"] == 1
    assert first_event["task_ids"] == ["1", "2"]
    assert state.get_task(mission_id, "1")["review_event_id"] == "re1"
    assert state.get_task(mission_id, "2")["review_event_id"] == "re1"

    state.update_review_event(
        mission_id,
        "re1",
        final_verdict="rejected",
        reviewer_verdicts={reviewer_pass: "pass", reviewer_reject: "reject"},
        reviewer_rationales={reviewer_reject: "/tmp/reject-round-1.md"},
    )
    runtime_state.review_dispatched.discard(f"{mission_id}:re1")
    runtime_state.save()
    state.update_task(
        mission_id,
        "1",
        {"status": "proposed"},
    )
    state.update_task(
        mission_id,
        "2",
        {"status": "proposed"},
    )
    state.update_task(
        mission_id,
        "1",
        {"status": "awaiting_review", "review_rationale": "/tmp/rationale-2.md"},
    )
    state.update_task(
        mission_id,
        "2",
        {"status": "awaiting_review", "review_rationale": "/tmp/rationale-2.md"},
    )

    mission = state.load_mission(mission_id)
    assert mission is not None
    check_task_design_review_events(mission_id, mission)

    reopened = state.get_review_event(mission_id, "re1")
    assert reopened["round"] == 2
    assert reopened.get("final_verdict") is None
    assert reopened["reviewer_verdicts"] == {reviewer_pass: "pass"}
    assert reopened["reviewer_rationales"] == {}
    assert reopened["rationale"] == "/tmp/rationale-2.md"
    assert len(state.load_mission(mission_id)["review_events"]) == 1
    assert len(sent) == 2
    assert sent[0] == {reviewer_pass, reviewer_reject}
    assert sent[1] == {reviewer_reject}


@pytest.mark.parametrize("terminal_verdict", ["approved", "cancelled"])
def test_check_task_design_review_events_creates_new_event_after_terminal_batch(
    mission_id: str,
    terminal_verdict: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_task(mission_id, subject="Task 1")
    state.update_task(
        mission_id,
        "1",
        {"status": "awaiting_review", "review_rationale": "/tmp/rationale-1.md"},
    )

    monkeypatch.setattr("keep._daemon.review.notify_all_reviewers", lambda mission, msg, reviewer_ids=None: None)
    runtime_state.review_dispatched.clear()
    runtime_state.save()

    mission = state.load_mission(mission_id)
    assert mission is not None
    check_task_design_review_events(mission_id, mission)
    state.update_review_event(mission_id, "re1", final_verdict=terminal_verdict)
    runtime_state.review_dispatched.discard(f"{mission_id}:re1")
    runtime_state.save()

    state.update_task(mission_id, "1", {"status": "proposed"})
    state.update_task(
        mission_id,
        "1",
        {"status": "awaiting_review", "review_rationale": "/tmp/rationale-2.md"},
    )

    mission = state.load_mission(mission_id)
    assert mission is not None
    check_task_design_review_events(mission_id, mission)

    review_events = state.load_mission(mission_id)["review_events"]
    assert [event["id"] for event in review_events] == ["re1", "re2"]
    assert review_events[1]["round"] == 1


def test_blocking_task_design_review_rejection_does_not_notify_supervisor(
    mission_id: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_task(mission_id, subject="Task 1")
    state.create_task(mission_id, subject="Task 2")
    state.update_task(mission_id, "1", {"status": "awaiting_review"})
    state.update_task(mission_id, "2", {"status": "awaiting_review"})
    mission = state.load_mission(mission_id)
    assert mission is not None

    sent: list[str] = []
    monkeypatch.setattr("keep._daemon.verdict_handlers.notify_supervisor", lambda mission, message: sent.append(message))

    _handle_task_design_review(
        mission_id,
        mission,
        "re1",
        {
            "task_ids": ["1", "2"],
            "reviewer_verdicts": {"rv1": "reject"},
            "reviewer_rationales": {"rv1": "/tmp/review-reject.md"},
        },
        "rejected",
    )

    assert state.get_task(mission_id, "1")["status"] == "proposed"
    assert state.get_task(mission_id, "2")["status"] == "proposed"
    assert sent == []


def test_blocking_task_claim_rejection_does_not_notify_supervisor(
    mission_id: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_task(mission_id, subject="Task 1")
    state.create_task(mission_id, subject="Task 2")
    state.update_task(mission_id, "1", {"status": "submitted"})
    state.update_task(mission_id, "2", {"status": "submitted"})
    mission = state.load_mission(mission_id)
    assert mission is not None

    sent: list[str] = []
    monkeypatch.setattr("keep._daemon.verdict_handlers.notify_supervisor", lambda mission, message: sent.append(message))

    _handle_task_claim(
        mission_id,
        mission,
        "re2",
        {
            "task_ids": ["1", "2"],
            "reviewer_verdicts": {"rv1": "reject"},
            "reviewer_rationales": {"rv1": "/tmp/claimed-reject.md"},
        },
        "rejected",
    )

    assert state.get_task(mission_id, "1")["status"] == "in_progress"
    assert state.get_task(mission_id, "2")["status"] == "in_progress"
    assert sent == []
