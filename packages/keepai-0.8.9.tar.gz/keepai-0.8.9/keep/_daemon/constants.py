"""Daemon constants, signal-file paths, module logger.

Kept dependency-light so every other `_daemon.*` module can import from here
without risk of cycles.

All filesystem paths resolve dynamically from ``_paths.STATE_DIR`` (backed by
the ``KEEP_HOME`` env var). Tests set ``KEEP_HOME`` via ``monkeypatch.setenv``
and every path derivation picks it up — no more per-constant patching.
"""

from __future__ import annotations

import logging
from pathlib import Path

from keep._state import paths as _paths


def _state_dir() -> Path:
    return _paths.STATE_DIR


def __getattr__(name: str):
    # Lazy, env-driven path attributes. Accessed as `constants.LOG_FILE` etc.
    if name == "LOG_FILE":
        return _state_dir() / "daemon.log"
    if name == "RUNTIME_STATE_FILE":
        return _state_dir() / "daemon-runtime.json"
    if name == "STATE_DIR":
        return _state_dir()
    raise AttributeError(f"module 'keep._daemon.constants' has no attribute {name!r}")


# ── Logger ────────────────────────────────────────────────────────
# Ensure the state dir exists once at import so FileHandler can open the log.
_state_dir().mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [daemon] %(message)s",
    handlers=[logging.FileHandler(_state_dir() / "daemon.log")],
)
log = logging.getLogger("keep.daemon")

# ── Review event types ────────────────────────────────────────────
EV_TASK_RATIONALE = "task_claim"
EV_TASK_REVIEW = "task_design_review"
EV_MISSION_STOP = "mission_stop"
EV_MISSION_QUIESCENT = "mission_idle"

# ── Timing / policy constants ─────────────────────────────────────
POLL_INTERVAL = 2
MIN_NOTIFY_INTERVAL = 10   # 最小通知间隔，防刷屏
SILENT_TIMEOUT = 180        # JSONL 无写入多久后视为 silent（秒）
SILENT_MAX_COUNT = 10       # 连续 silent 事件最多发送次数
SILENT_SUSPEND_HINT_AT = 2  # 第几次 silent 时附上 worker remove/restore 提示
REPLY_INLINE_LIMIT = 200   # stop reply 超过此长度则截断，完整内容溢写到文件
QUIESCENT_TIMEOUT = 300    # 所有 worker 空闲超过此时间（秒）视为 quiescent
SUPERVISOR_QUIESCENT_DELAY = 10  # supervisor 停止后等待多久再触发 quiescent


# ── Signal file path helpers ──────────────────────────────────────
def mission_stop_signal_file(mission_name: str) -> Path:
    return _state_dir() / f"mission-stop-{mission_name}"


def mission_sync_signal_file(mission_name: str) -> Path:
    return _state_dir() / f"mission-sync-{mission_name}"


def stop_file(session_id: str) -> Path:
    return _state_dir() / f"stop-{session_id}"
