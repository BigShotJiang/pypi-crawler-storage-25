"""Daemon in-memory runtime state + disk persistence.

All dicts/sets here are **module-level singletons**. Importers must reference
them via attribute (`runtime_state._last_notify`) rather than rebinding names,
otherwise updates will not be seen across modules.

`load()` is called once from `run_daemon` startup; `save()` is called after any
mutation that must survive a daemon restart.
"""

from __future__ import annotations

import json

from keep._daemon import constants as _constants
from keep._daemon.constants import log
from keep._state.missions import list_missions, load_mission
from keep._state.participants import iter_workers
from keep._state.paths import atomic_write_text

# ── Per-(mission, session) throttling ─────────────────────────────
# key format: "mission:session"
last_notify: dict[str, float] = {}
last_silent: dict[str, float] = {}

# ── Silent escalation state ───────────────────────────────────────
silent_count: dict[str, int] = {}
silent_closed: set[str] = set()  # A0 terminal — stop re-announcing

# ── First-stop suppression ────────────────────────────────────────
# worker create 成功返回已覆盖初始化确认：每个 worker 的首个 stop 事件不再推送
first_stop_suppressed: set[str] = set()

# ── Quiescent tracking ────────────────────────────────────────────
quiescent_since: dict[str, float] = {}
quiescent_fired: set[str] = set()
supervisor_stopped_since: dict[str, float] = {}

# ── Review event dispatch ─────────────────────────────────────────
# key: "mission:event_id"
review_dispatched: set[str] = set()
# {mission_name: event_id}
pending_stop_event: dict[str, str] = {}


def load() -> None:
    """Restore runtime state on daemon startup.

    Two kinds of state are restored here:
    - **Persisted** (read from disk): the transient throttling / silent /
      quiescence / review-dispatch containers written by ``save()``.
    - **Derived** (rebuilt from mission state): ``first_stop_suppressed`` is
      not persisted because its single source of truth is
      ``worker.bootstrapped`` — every already-bootstrapped worker must keep
      its first real stop unsuppressed.

    Each container is mutated in-place (``.clear()`` + ``.update()``) rather
    than rebound, so the ``keep.daemon`` facade's re-exported aliases keep
    pointing at the same live objects.
    """
    try:
        runtime_file = _constants.RUNTIME_STATE_FILE
        if runtime_file.exists():
            data = json.loads(runtime_file.read_text())

            def _replace_dict(target: dict, src: dict) -> None:
                target.clear()
                target.update(src)

            def _replace_set(target: set, src) -> None:
                target.clear()
                target.update(src)

            _replace_dict(last_notify, data.get("last_notify", {}))
            _replace_dict(last_silent, data.get("last_silent", {}))
            _replace_dict(silent_count, data.get("silent_count", {}))
            _replace_set(silent_closed, data.get("silent_closed", []))
            _replace_dict(quiescent_since, data.get("quiescent_since", {}))
            _replace_set(quiescent_fired, data.get("quiescent_fired", []))
            _replace_dict(supervisor_stopped_since, data.get("supervisor_stopped_since", {}))
            _replace_set(review_dispatched, data.get("review_dispatched", []))
            _replace_dict(pending_stop_event, data.get("pending_stop_event", {}))
            log.info(
                "Loaded runtime state: %d silent keys, %d closed",
                len(silent_count), len(silent_closed),
            )
    except Exception as e:
        log.warning("Failed to load runtime state, starting fresh: %s", e)

    first_stop_suppressed.clear()
    for mn in list_missions():
        m = load_mission(mn)
        if not m:
            continue
        for w in iter_workers(m):
            if w.get("bootstrapped", False):
                first_stop_suppressed.add(w["session"])
    if first_stop_suppressed:
        log.info(
            "Rebuilt first_stop_suppressed from missions: %d sessions",
            len(first_stop_suppressed),
        )


def save() -> None:
    """Atomically persist runtime state so it survives daemon restart."""
    try:
        data = {
            "last_notify": last_notify,
            "last_silent": last_silent,
            "silent_count": silent_count,
            "silent_closed": list(silent_closed),
            "quiescent_since": quiescent_since,
            "quiescent_fired": list(quiescent_fired),
            "supervisor_stopped_since": supervisor_stopped_since,
            "review_dispatched": list(review_dispatched),
            "pending_stop_event": pending_stop_event,
        }
        atomic_write_text(_constants.RUNTIME_STATE_FILE, json.dumps(data))
    except Exception as e:
        log.warning("Failed to save runtime state: %s", e)


def purge_worker(mission_name: str, session: str) -> None:
    """Drop every runtime-state entry tied to a single (mission, session).

    Call after CLI removes a worker so stale throttling/silent/suppression
    state doesn't leak. The live daemon keeps its own in-memory copy, so a
    subsequent restart is what actually adopts the clean state.
    """
    key = f"{mission_name}:{session}"
    last_notify.pop(key, None)
    last_silent.pop(key, None)
    silent_count.pop(key, None)
    silent_closed.discard(key)
    first_stop_suppressed.discard(session)
    save()


def purge_mission(mission_name: str, worker_sessions: list[str]) -> None:
    """Drop every runtime-state entry tied to a mission.

    `worker_sessions` must be collected *before* mission deletion since we
    need the bare session ids to evict `first_stop_suppressed` (keyed by
    session, not mission:session).
    """
    worker_keys = {f"{mission_name}:{s}" for s in worker_sessions}
    for s in worker_sessions:
        first_stop_suppressed.discard(s)

    for container in (last_notify, last_silent, silent_count):
        for k in list(container.keys()):
            if k in worker_keys:
                container.pop(k, None)
    for k in list(silent_closed):
        if k in worker_keys:
            silent_closed.discard(k)

    # mission-only keys
    quiescent_since.pop(mission_name, None)
    quiescent_fired.discard(mission_name)
    supervisor_stopped_since.pop(mission_name, None)
    pending_stop_event.pop(mission_name, None)

    # mission:event_id keys (review_dispatched)
    prefix = f"{mission_name}:"
    for k in list(review_dispatched):
        if k.startswith(prefix):
            review_dispatched.discard(k)

    save()
