"""Quiescent (mission-level idle) detection.

Two paths:
  - With workers: fire when every worker's JSONL has been silent for
    QUIESCENT_TIMEOUT seconds.
  - No workers: fire when the supervisor stops (consumed stop file) and stays
    down for SUPERVISOR_QUIESCENT_DELAY seconds. The supervisor's *first* stop
    (= bootstrap) is suppressed, matching worker first-stop semantics.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from keep._daemon import runtime_state
from keep._daemon.constants import (
    EV_MISSION_QUIESCENT,
    QUIESCENT_TIMEOUT,
    SUPERVISOR_QUIESCENT_DELAY,
    log,
    stop_file,
)
from keep._daemon.review import dispatch_review_event
from keep._daemon.xml_format import build_review_summary
from keep.state import (
    add_review_event,
    find_supervisor,
    iter_workers,
    worker_session_id,
)


def _create_idle_event(
    mission_name: str,
    mission: dict[str, Any],
    idle_seconds: int,
) -> None:
    """Register a quiescent review event and dispatch to reviewers."""
    try:
        event_data: dict[str, Any] = {
            "type": EV_MISSION_QUIESCENT,
            "reviewer_verdicts": {},
            "idle_seconds": idle_seconds,
        }
        event_id = add_review_event(mission_name, event_data)
        log.info("Created mission_idle review event %s [%s]", event_id, mission_name)
        summary = build_review_summary(event_data | {"id": event_id}, mission_name)
        dispatch_review_event(mission_name, mission, event_id, EV_MISSION_QUIESCENT, summary)
    except Exception as e:
        log.warning("Failed to create quiescent event for %r: %s", mission_name, e)


def _handle_no_workers(mission_name: str, mission: dict[str, Any], now: float) -> None:
    """Supervisor-only quiescent path (no workers present)."""
    sup = find_supervisor(mission)
    if not sup:
        return
    sup_session_id = worker_session_id(sup)
    if not sup_session_id:
        return

    sf = stop_file(sup_session_id)
    if sf.exists() and mission_name not in runtime_state.supervisor_stopped_since:
        sf.unlink(missing_ok=True)
        # Suppress bootstrap stop — same as worker first-stop suppression
        if sup_session_id not in runtime_state.first_stop_suppressed:
            runtime_state.first_stop_suppressed.add(sup_session_id)
            log.info("Supervisor bootstrap stop suppressed [%s]", mission_name)
            return
        runtime_state.supervisor_stopped_since[mission_name] = now
        runtime_state.save()
        log.info("Supervisor stopped with no workers, grace period started [%s]", mission_name)
        return

    if mission_name not in runtime_state.supervisor_stopped_since:
        return

    elapsed = now - runtime_state.supervisor_stopped_since[mission_name]
    if elapsed < SUPERVISOR_QUIESCENT_DELAY:
        return

    if mission_name in runtime_state.quiescent_fired:
        return

    log.info("Supervisor quiescent after %.0fs grace [%s]", elapsed, mission_name)
    runtime_state.quiescent_fired.add(mission_name)
    del runtime_state.supervisor_stopped_since[mission_name]
    runtime_state.save()
    _create_idle_event(mission_name, mission, int(elapsed))


def _workers_all_idle(workers: list[dict[str, Any]], now: float) -> bool:
    """Return True iff every worker has no stop file AND JSONL mtime >= QUIESCENT_TIMEOUT."""
    for worker in workers:
        session = worker.get("session")
        if not session:
            continue
        session_id = worker_session_id(worker)
        if not session_id:
            return False
        sf = stop_file(session_id)
        if sf.exists():
            return False
        cache = worker.get("cache") or {}
        jsonl = cache.get("jsonl_path")
        if jsonl:
            jsonl_path = Path(jsonl)
            if jsonl_path.exists():
                age = now - jsonl_path.stat().st_mtime
                if age < QUIESCENT_TIMEOUT:
                    return False
    return True


def check_idle(mission_name: str, mission: dict[str, Any]) -> None:
    """检测 quiescent 状态：所有 worker 都空闲超过 QUIESCENT_TIMEOUT 秒。
    无 worker 时改为检查 supervisor 是否有 stop file（即 supervisor 已停止）。"""
    workers = list(iter_workers(mission))
    now = time.time()

    if not workers:
        _handle_no_workers(mission_name, mission, now)
        return

    if not _workers_all_idle(workers, now):
        # Workers are active — reset quiescent tracking
        runtime_state.quiescent_since.pop(mission_name, None)
        runtime_state.quiescent_fired.discard(mission_name)
        return

    if mission_name not in runtime_state.quiescent_since:
        runtime_state.quiescent_since[mission_name] = now
        runtime_state.save()
        return

    if now - runtime_state.quiescent_since[mission_name] < QUIESCENT_TIMEOUT:
        return

    if mission_name in runtime_state.quiescent_fired:
        return

    idle_secs = int(now - runtime_state.quiescent_since[mission_name])
    log.info("Quiescent detected for mission %r (idle %ds)", mission_name, idle_secs)
    runtime_state.quiescent_fired.add(mission_name)
    runtime_state.save()
    _create_idle_event(mission_name, mission, idle_secs)
