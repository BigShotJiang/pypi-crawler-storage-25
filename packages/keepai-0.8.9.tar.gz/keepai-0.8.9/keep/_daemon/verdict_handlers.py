"""Per-event-type verdict handlers called after reviewers reach consensus.

Split out of `review.py` to keep that module focused on dispatch + aggregation.
Each handler is responsible for its own mission/task mutations + any follow-up
notification to the supervisor.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable
from xml.sax.saxutils import escape as xml_escape

from keep._daemon import runtime_state
from keep._daemon.constants import (
    EV_MISSION_QUIESCENT,
    EV_MISSION_STOP,
    EV_TASK_RATIONALE,
    EV_TASK_REVIEW,
    log,
    mission_stop_signal_file,
)
from keep._daemon.notify import notify_supervisor
from keep._daemon.xml_format import build_event_xml
from keep.hooks import fire_hook
from keep.state import (
    get_task,
    mutate_mission,
    update_task,
)


VerdictHandler = Callable[[str, dict[str, Any], str, dict[str, Any], str], None]


def _load_reviewer_reject_rationales(event: dict[str, Any]) -> str:
    texts: list[str] = []
    verdicts = dict(event.get("reviewer_verdicts") or {})
    rationale_paths = dict(event.get("reviewer_rationales") or {})
    for reviewer_id, rationale_path in rationale_paths.items():
        if verdicts.get(reviewer_id) != "reject":
            continue
        try:
            rationale_text = Path(rationale_path).read_text(encoding="utf-8")
        except OSError:
            rationale_text = "(rationale file not found)"
        texts.append(f"[{reviewer_id}] {rationale_text}")
    return "\n\n".join(texts)


def _handle_task_claim(
    mission_name: str,
    mission: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    verdict: str,
) -> None:
    task_ids_raw = event.get("task_ids") or (
        [str(event["task_id"])] if event.get("task_id") else []
    )
    if not task_ids_raw:
        log.warning("task_claim event %s missing task_id(s)", event_id)
        return

    target_status = "completed" if verdict == "approved" else "in_progress"
    action_word = "marked completed" if verdict == "approved" else "reverted to in_progress"
    qualifier = "approved" if verdict == "approved" else "rejected"

    for tid in task_ids_raw:
        try:
            update_task(mission_name, str(tid), {"status": target_status})
            log.info(
                "Task %s %s after rationale %s [%s]",
                tid, action_word, qualifier, mission_name,
            )
        except Exception as e:
            log.warning("Failed to update task %s to %s: %s", tid, target_status, e)


def _handle_task_design_review(
    mission_name: str,
    mission: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    verdict: str,
) -> None:
    task_ids = event.get("task_ids", [])
    if verdict == "approved":
        next_status, log_tmpl = "pending", "Task %s approved → pending [%s]"
    else:
        next_status, log_tmpl = "proposed", "Task %s rejected → proposed [%s]"

    for tid in task_ids:
        try:
            task = get_task(mission_name, str(tid))
            if task and task.get("status") == "awaiting_review":
                update_task(mission_name, str(tid), {"status": next_status})
                log.info(log_tmpl, tid, mission_name)
        except Exception as e:
            log.warning("Failed to transition task %s → %s: %s", tid, next_status, e)


def _handle_mission_stop(
    mission_name: str,
    mission: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    verdict: str,
) -> None:
    runtime_state.pending_stop_event.pop(mission_name, None)
    runtime_state.save()
    mission_stop_signal_file(mission_name).unlink(missing_ok=True)

    if verdict == "approved":
        log.info("mission_stop approved — stopping mission %r", mission_name)
        with mutate_mission(mission_name) as fresh:
            fresh["status"] = "stopped"
        mission["status"] = "stopped"
    else:
        notify_supervisor(
            mission,
            build_event_xml(
                "review_rejected",
                {"mission": mission_name, "event_id": event_id, "type": EV_MISSION_STOP},
                xml_escape("Mission stop rejected by reviewer. Mission continues."),
            ),
        )


def _handle_mission_idle(
    mission_name: str,
    mission: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    verdict: str,
) -> None:
    # Reset idle tracking so re-detection can happen after supervisor resumes
    runtime_state.quiescent_fired.discard(mission_name)
    runtime_state.quiescent_since.pop(mission_name, None)
    runtime_state.supervisor_stopped_since.pop(mission_name, None)
    runtime_state.save()

    if verdict == "approved":
        log.info("mission_idle approved — stopping mission %r", mission_name)
        with mutate_mission(mission_name) as fresh:
            fresh["status"] = "stopped"
        mission["status"] = "stopped"
        fire_hook("idle", {"mission": mission_name})
        return

    # Rejected: wrap rationale and send to supervisor as wake-up message
    rationale_text = _load_reviewer_reject_rationales(event)
    notify_supervisor(
        mission,
        build_event_xml(
            "idle_rejected",
            {"mission": mission_name, "event_id": event_id},
            xml_escape(
                f"Mission idle review rejected. Reviewer says:\n{rationale_text}\n"
                "Please reassess mission goals and continue."
            ),
        ),
    )


HANDLERS: dict[str, VerdictHandler] = {
    EV_TASK_RATIONALE: _handle_task_claim,
    EV_TASK_REVIEW: _handle_task_design_review,
    EV_MISSION_STOP: _handle_mission_stop,
    EV_MISSION_QUIESCENT: _handle_mission_idle,
}


def dispatch(
    mission_name: str,
    mission: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    event_type: str,
    verdict: str,
) -> None:
    """Look up and invoke the handler for `event_type`. Logs + no-op on unknown type."""
    handler = HANDLERS.get(event_type)
    if handler is None:
        log.warning("No verdict handler for event_type=%s", event_type)
        return
    handler(mission_name, mission, event_id, event, verdict)
