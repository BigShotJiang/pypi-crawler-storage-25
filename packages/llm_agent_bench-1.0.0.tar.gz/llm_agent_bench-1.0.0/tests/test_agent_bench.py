"""Tests for agent-bench. Run: pytest tests/ -v"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from agent_bench import (
    AgentBench,
    AgentResponse,
    BenchReport,
    Dimension,
    EfficiencyEvaluator,
    GoalAdherenceEvaluator,
    SafetyEvaluator,
    Task,
    TaskCompletionEvaluator,
    TaskResult,
    ToolUseEvaluator,
)


@pytest.fixture
def simple_task():
    return Task(
        id="t1",
        instruction="Find the capital of France",
        success_criteria=["Paris"],
        expected_tools=["search"],
        max_steps=3,
    )


@pytest.fixture
def good_response():
    return AgentResponse(output="The capital of France is Paris.", tools_called=["search"], steps=2)


@pytest.fixture
def bad_response():
    return AgentResponse(output="I cannot help with this.", tools_called=[], steps=8)


@pytest.fixture
def error_response():
    return AgentResponse(output="", error="Timeout")


@pytest.fixture
def bench():
    return AgentBench(pass_threshold=0.7)


class TestTask:
    def test_repr(self, simple_task):
        assert "t1" in repr(simple_task)

    def test_defaults(self):
        t = Task(id="x", instruction="Do something")
        assert t.expected_tools == []
        assert t.success_criteria == []
        assert t.max_steps == 10


class TestAgentResponse:
    def test_not_failed_on_output(self, good_response):
        assert not good_response.failed

    def test_failed_on_error(self, error_response):
        assert error_response.failed

    def test_repr(self, good_response):
        assert "steps=2" in repr(good_response)


class TestTaskCompletionEvaluator:
    def setup_method(self):
        self.ev = TaskCompletionEvaluator()

    def test_all_criteria_met(self, simple_task, good_response):
        score = self.ev.evaluate(simple_task, good_response)
        assert score.score == 1.0
        assert score.passed

    def test_no_criteria_with_output(self):
        t = Task(id="x", instruction="Do something")
        r = AgentResponse(output="Done!")
        score = self.ev.evaluate(t, r)
        assert score.score == 1.0

    def test_partial_criteria(self):
        t = Task(id="x", instruction="Q", success_criteria=["Paris", "France", "Europe"])
        r = AgentResponse(output="Paris is in France.")
        score = self.ev.evaluate(t, r)
        assert 0.0 < score.score < 1.0

    def test_zero_on_error(self, simple_task, error_response):
        score = self.ev.evaluate(simple_task, error_response)
        assert score.score == 0.0
        assert not score.passed

    def test_case_insensitive(self):
        t = Task(id="x", instruction="Q", success_criteria=["PARIS"])
        r = AgentResponse(output="paris is the capital")
        assert self.ev.evaluate(t, r).score == 1.0


class TestToolUseEvaluator:
    def setup_method(self):
        self.ev = ToolUseEvaluator()

    def test_expected_tools_called(self, simple_task, good_response):
        score = self.ev.evaluate(simple_task, good_response)
        assert score.score == 1.0

    def test_no_expected_tools(self):
        t = Task(id="x", instruction="Q")
        r = AgentResponse(output="answer")
        assert self.ev.evaluate(t, r).score == 1.0

    def test_missing_tools(self):
        t = Task(id="x", instruction="Q", expected_tools=["search", "calculator"])
        r = AgentResponse(output="answer", tools_called=["search"])
        assert self.ev.evaluate(t, r).score == 0.5

    def test_no_tools_called(self, simple_task):
        r = AgentResponse(output="answer", tools_called=[])
        assert self.ev.evaluate(simple_task, r).score == 0.0


class TestGoalAdherenceEvaluator:
    def setup_method(self):
        self.ev = GoalAdherenceEvaluator()

    def test_clean_output_passes(self, simple_task, good_response):
        assert self.ev.evaluate(simple_task, good_response).passed

    def test_forbidden_output_fails(self):
        t = Task(id="x", instruction="Q", forbidden_outputs=["competitor"])
        r = AgentResponse(output="Our competitor is better.")
        assert not self.ev.evaluate(t, r).passed

    def test_drift_pattern_detected(self):
        t = Task(id="x", instruction="Q")
        r = AgentResponse(output="I cannot help with this request, sorry.")
        score = self.ev.evaluate(t, r)
        assert score.score < 1.0

    def test_error_response_neutral(self, simple_task, error_response):
        score = self.ev.evaluate(simple_task, error_response)
        assert score.score == 0.5


class TestSafetyEvaluator:
    def setup_method(self):
        self.ev = SafetyEvaluator()

    def test_clean_output(self, simple_task, good_response):
        score = self.ev.evaluate(simple_task, good_response)
        assert score.score == 1.0
        assert score.passed

    def test_flags_harmful_content(self):
        t = Task(id="x", instruction="Q")
        r = AgentResponse(output="Here is how to make a weapon and harm people.")
        assert not self.ev.evaluate(t, r).passed

    def test_empty_output_safe(self):
        t = Task(id="x", instruction="Q")
        r = AgentResponse(output="")
        assert self.ev.evaluate(t, r).score == 1.0


class TestEfficiencyEvaluator:
    def setup_method(self):
        self.ev = EfficiencyEvaluator()

    def test_one_step_perfect(self, simple_task):
        r = AgentResponse(output="answer", steps=1)
        assert self.ev.evaluate(simple_task, r).score == 1.0

    def test_max_steps_penalty(self, simple_task):
        r = AgentResponse(output="answer", steps=simple_task.max_steps)
        score = self.ev.evaluate(simple_task, r).score
        assert 0.4 <= score <= 0.6

    def test_over_budget_fails(self, simple_task):
        r = AgentResponse(output="answer", steps=simple_task.max_steps + 1)
        assert not self.ev.evaluate(simple_task, r).passed


class TestAgentBench:
    def _good_agent(self):
        def agent(instruction: str) -> AgentResponse:
            return AgentResponse(
                output="The capital of France is Paris.", tools_called=["search"], steps=2
            )

        return agent

    def _bad_agent(self):
        def agent(instruction: str) -> AgentResponse:
            return AgentResponse(output="I don't know.", tools_called=[], steps=10)

        return agent

    def test_run_returns_report(self, bench, simple_task):
        report = bench.run(self._good_agent(), [simple_task])
        assert isinstance(report, BenchReport)

    def test_good_agent_passes(self, bench, simple_task):
        report = bench.run(self._good_agent(), [simple_task])
        assert report.pass_rate > 0

    def test_bad_agent_lower_score(self, bench, simple_task):
        good = bench.run(self._good_agent(), [simple_task])
        bad = bench.run(self._bad_agent(), [simple_task])
        assert good.avg_score > bad.avg_score

    def test_agent_error_handled(self, bench, simple_task):
        def crash(inst: str) -> AgentResponse:
            raise RuntimeError("crashed")

        report = bench.run(crash, [simple_task])
        assert report.total == 1

    def test_plain_string_agent_accepted(self, bench, simple_task):
        def string_agent(inst: str):
            return "Paris is the capital of France."

        report = bench.run(string_agent, [simple_task])
        assert report.total == 1

    def test_evaluate_single(self, bench, simple_task, good_response):
        result = bench.evaluate_single(simple_task, good_response)
        assert isinstance(result, TaskResult)

    def test_pass_rate_range(self, bench, simple_task):
        report = bench.run(self._good_agent(), [simple_task])
        assert 0.0 <= report.pass_rate <= 1.0

    def test_dimension_scores_present(self, bench, simple_task):
        report = bench.run(self._good_agent(), [simple_task])
        dims = {s.dimension for s in report.results[0].dimension_scores}
        assert Dimension.TASK_COMPLETION in dims
        assert Dimension.SAFETY in dims

    def test_weakest_dimension_is_dimension(self, bench, simple_task):
        report = bench.run(self._good_agent(), [simple_task])
        assert isinstance(report.weakest_dimension, Dimension)

    def test_summary_is_string(self, bench, simple_task):
        report = bench.run(self._good_agent(), [simple_task])
        assert "AGENT BENCHMARK REPORT" in report.summary()

    def test_multiple_tasks(self, bench):
        tasks = [
            Task(id=f"t{i}", instruction=f"task {i}", success_criteria=[f"answer{i}"])
            for i in range(5)
        ]

        def agent(inst: str) -> AgentResponse:
            i = inst.split()[-1]
            return AgentResponse(output=f"answer{i}")

        report = bench.run(agent, tasks)
        assert report.total == 5

    def test_repr(self, bench, simple_task):
        report = bench.run(self._good_agent(), [simple_task])
        assert "BenchReport" in repr(report)

    def test_failed_tasks_list(self, bench, simple_task):
        report = bench.run(self._bad_agent(), [simple_task])
        assert isinstance(report.failed_tasks, list)
