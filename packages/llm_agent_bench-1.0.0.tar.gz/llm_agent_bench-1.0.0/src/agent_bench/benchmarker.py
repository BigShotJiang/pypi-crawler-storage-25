"""AgentBench — orchestrates evaluation across all dimensions."""

from __future__ import annotations

from typing import Callable

from agent_bench.evaluators import (
    EfficiencyEvaluator,
    GoalAdherenceEvaluator,
    SafetyEvaluator,
    TaskCompletionEvaluator,
    ToolUseEvaluator,
)
from agent_bench.models import AgentResponse, BenchReport, Dimension, Task, TaskResult

DEFAULT_WEIGHTS = {
    Dimension.TASK_COMPLETION: 0.35,
    Dimension.TOOL_USE: 0.20,
    Dimension.GOAL_ADHERENCE: 0.20,
    Dimension.SAFETY: 0.15,
    Dimension.EFFICIENCY: 0.10,
}


class AgentBench:
    """
    Benchmark an AI agent across five evaluation dimensions.

    Example:
        bench = AgentBench(pass_threshold=0.7)
        report = bench.run(agent=my_agent_fn, tasks=my_tasks)
        print(report.summary())
        print(f"Pass rate: {report.pass_rate:.0%}")
    """

    def __init__(
        self,
        pass_threshold: float = 0.7,
        weights: dict[Dimension, float] | None = None,
        verbose: bool = False,
    ) -> None:
        self.pass_threshold = pass_threshold
        self.weights = weights or DEFAULT_WEIGHTS
        self.verbose = verbose
        self._evaluators = [
            TaskCompletionEvaluator(),
            ToolUseEvaluator(),
            GoalAdherenceEvaluator(),
            SafetyEvaluator(),
            EfficiencyEvaluator(),
        ]

    def run(self, agent: Callable[[str], AgentResponse], tasks: list[Task]) -> BenchReport:
        """
        Run the benchmark.

        Args:
            agent: Callable that takes instruction string, returns AgentResponse
            tasks: List of Task objects

        Returns:
            BenchReport with full results
        """
        results: list[TaskResult] = []
        for i, task in enumerate(tasks):
            if self.verbose:
                print(f"  [{i+1}/{len(tasks)}] {task.id}: {task.instruction[:60]}...")
            try:
                response = agent(task.instruction)
                if not isinstance(response, AgentResponse):
                    response = AgentResponse(output=str(response))
            except Exception as e:
                response = AgentResponse(output="", error=str(e))
            result = self._evaluate_task(task, response)
            results.append(result)
            if self.verbose:
                print(f"    {'PASS' if result.passed else 'FAIL'} score={result.overall_score:.2f}")
        return BenchReport(results=results, pass_threshold=self.pass_threshold)

    def evaluate_single(self, task: Task, response: AgentResponse) -> TaskResult:
        """Evaluate a single task-response pair without running an agent."""
        return self._evaluate_task(task, response)

    def _evaluate_task(self, task: Task, response: AgentResponse) -> TaskResult:
        scores = [e.evaluate(task, response) for e in self._evaluators]
        total_weight = sum(self.weights.values())
        overall = sum(s.score * self.weights.get(s.dimension, 1.0) for s in scores) / total_weight
        return TaskResult(
            task=task,
            response=response,
            dimension_scores=scores,
            overall_score=round(overall, 4),
            passed=overall >= self.pass_threshold,
        )
