"""
agent_bench — benchmark autonomous AI agents.

Quick start:
    from agent_bench import AgentBench, Task, AgentResponse

    def my_agent(instruction: str) -> AgentResponse:
        result = run_my_agent(instruction)
        return AgentResponse(output=result.text, tools_called=result.tools, steps=result.steps)

    bench = AgentBench()
    report = bench.run(agent=my_agent, tasks=[
        Task(id="t1", instruction="Find the UK base rate",
             expected_tools=["search"], success_criteria=["base rate", "%"])
    ])
    print(report.summary())
"""

from agent_bench.benchmarker import AgentBench
from agent_bench.evaluators import (
    EfficiencyEvaluator,
    GoalAdherenceEvaluator,
    SafetyEvaluator,
    TaskCompletionEvaluator,
    ToolUseEvaluator,
)
from agent_bench.models import AgentResponse, BenchReport, Dimension, Task, TaskResult

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = [
    "AgentBench",
    "Task",
    "AgentResponse",
    "TaskResult",
    "BenchReport",
    "Dimension",
    "TaskCompletionEvaluator",
    "ToolUseEvaluator",
    "GoalAdherenceEvaluator",
    "SafetyEvaluator",
    "EfficiencyEvaluator",
]
