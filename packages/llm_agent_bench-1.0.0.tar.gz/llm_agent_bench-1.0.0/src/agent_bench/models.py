"""Data models for agent-bench."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Dimension(str, Enum):
    TASK_COMPLETION = "task_completion"
    TOOL_USE = "tool_use"
    GOAL_ADHERENCE = "goal_adherence"
    SAFETY = "safety"
    EFFICIENCY = "efficiency"


@dataclass
class Task:
    """A single benchmark task for an agent."""

    id: str
    instruction: str
    expected_tools: list[str] = field(default_factory=list)
    success_criteria: list[str] = field(default_factory=list)
    forbidden_outputs: list[str] = field(default_factory=list)
    max_steps: int = 10
    category: str = "general"
    difficulty: str = "medium"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"Task({self.id!r}, {self.instruction[:50]!r})"


@dataclass
class AgentResponse:
    """The response from an agent for a given task."""

    output: str
    tools_called: list[str] = field(default_factory=list)
    steps: int = 1
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def failed(self) -> bool:
        return self.error is not None

    def __repr__(self) -> str:
        return f"AgentResponse(steps={self.steps}, tools={self.tools_called}, output={self.output[:40]!r})"


@dataclass
class DimensionScore:
    dimension: Dimension
    score: float
    passed: bool
    reason: str = ""

    def __repr__(self) -> str:
        return f"DimensionScore({self.dimension.value}={self.score:.2f}, {'PASS' if self.passed else 'FAIL'})"


@dataclass
class TaskResult:
    task: Task
    response: AgentResponse
    dimension_scores: list[DimensionScore]
    overall_score: float
    passed: bool

    @property
    def task_id(self) -> str:
        return self.task.id

    @property
    def score_by_dimension(self) -> dict[str, float]:
        return {d.dimension.value: d.score for d in self.dimension_scores}

    def __repr__(self) -> str:
        return (
            f"TaskResult({self.task.id!r}, "
            f"{'PASS' if self.passed else 'FAIL'}, "
            f"score={self.overall_score:.2f})"
        )


@dataclass
class BenchReport:
    results: list[TaskResult]
    pass_threshold: float = 0.7

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.passed)

    @property
    def failed(self) -> int:
        return self.total - self.passed

    @property
    def pass_rate(self) -> float:
        return round(self.passed / self.total, 4) if self.total else 0.0

    @property
    def avg_score(self) -> float:
        return (
            round(sum(r.overall_score for r in self.results) / self.total, 4) if self.total else 0.0
        )

    def avg_dimension_score(self, dim: Dimension) -> float:
        scores = [r.score_by_dimension.get(dim.value, 0.0) for r in self.results]
        return round(sum(scores) / len(scores), 4) if scores else 0.0

    @property
    def weakest_dimension(self) -> Dimension:
        return min(Dimension, key=lambda d: self.avg_dimension_score(d))

    @property
    def failed_tasks(self) -> list[TaskResult]:
        return [r for r in self.results if not r.passed]

    def summary(self) -> str:
        lines = [
            "",
            "=" * 60,
            "  AGENT BENCHMARK REPORT",
            "=" * 60,
            f"  Tasks:       {self.total}",
            f"  Pass rate:   {self.pass_rate:.0%}  ({self.passed}/{self.total})",
            f"  Avg score:   {self.avg_score:.2f}",
            "",
            "  DIMENSION SCORES",
            "-" * 60,
        ]
        for dim in Dimension:
            score = self.avg_dimension_score(dim)
            bar = "█" * int(score * 20) + "░" * (20 - int(score * 20))
            marker = "  <-- weakest" if dim == self.weakest_dimension else ""
            lines.append(f"  {dim.value:<20} {score:.2f}  [{bar}]{marker}")
        if self.failed_tasks:
            lines += ["", f"  FAILED TASKS ({len(self.failed_tasks)})", "-" * 60]
            for r in self.failed_tasks[:5]:
                lines.append(f"  x [{r.overall_score:.2f}] {r.task.id}: {r.task.instruction[:50]}")
        lines += ["=" * 60, ""]
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"BenchReport({self.passed}/{self.total} passed, avg={self.avg_score:.2f})"
