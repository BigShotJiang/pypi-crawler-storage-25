"""Unit tests for the JSON structured-output renderer.

Covers plug-in registration, the top-level schema shape (mirrors the
py8dis-fork ``emit_structured()`` keys), and per-classification item
emission. The full-ROM parity diff against py8dis lives in
``test_nfs_roundtrip.py`` — these tests are the focused unit-level
checks.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from dasmos.disassembler import Disassembler
from dasmos.ext.renderers.json import JsonRenderer
from dasmos.output import StructuredOutput
from dasmos.renderer import create_renderer


@pytest.fixture
def tiny_disassembler(tmp_path):
    """A disassembler primed with a 6-byte program at &8000:

        &8000  ldy #&00
        &8002  jsr &fff4    ; OSBYTE
        &8005  rts

    Yields the IR after disassemble() so each test can render it
    however it wants.
    """
    bin_path = tmp_path / "p.bin"
    bin_path.write_bytes(bytes([0xa0, 0x00, 0x20, 0xf4, 0xff, 0x60]))
    d = Disassembler.create(cpu="6502")
    d.load(bin_path, 0x8000)
    d.entry(0x8000, name="start")
    d.label(0xfff4, "osbyte")
    return d.disassemble()


class TestPluginRegistration:

    def test_loadable_via_stevedore(self):
        r = create_renderer("json")
        assert isinstance(r, JsonRenderer)
        assert r.name == "json"

    def test_supports_nmos6502_and_cmos65c02(self):
        r = JsonRenderer()
        cpus = r.cpus_supported()
        assert "6502" in cpus
        assert "65C02" in cpus


class TestTopLevelSchema:
    """The dict has a stable top-level shape. Compared to py8dis-fork's
    schema, dasmos splits ``data_banner`` out into its own ``banners``
    array (so consumers can tell "subroutine entry point" from "data
    region with header"). All other keys mirror py8dis (see
    ``project_jsonrenderer_schema`` memory).
    """

    EXPECTED_KEYS = (
        "meta", "constants", "subroutines", "banners",
        "external_labels", "memory_map", "items",
    )

    def test_render_returns_structured_output(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        assert isinstance(out, StructuredOutput)

    def test_top_level_keys_match_py8dis_schema(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        assert tuple(out.data.keys()) == self.EXPECTED_KEYS

    def test_meta_has_load_and_end_addrs(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        assert out.data["meta"]["load_addr"] == 0x8000
        assert out.data["meta"]["end_addr"] == 0x8006

    def test_str_round_trips_via_json(self, tiny_disassembler):
        # ``str(output)`` is canonical JSON; loading it back gives the
        # same dict. Confirms the StructuredOutput shape works.
        import json
        out = tiny_disassembler.render(JsonRenderer())
        assert json.loads(str(out)) == out.data


class TestItemEmission:

    def test_code_item_has_mnemonic_and_operand(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        items = out.data["items"]
        ldy = items[0]
        assert ldy["addr"] == 0x8000
        assert ldy["type"] == "code"
        assert ldy["mnemonic"] == "ldy"
        # py8dis-fork format: ``#0`` decimal for n < 10.
        assert ldy["operand"] == "#0"
        assert ldy["bytes"] == [0xa0, 0x00]

    def test_code_item_has_labels_when_present(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        ldy = out.data["items"][0]
        assert ldy["labels"] == ["start"]

    def test_code_item_has_target_and_target_label(self, tiny_disassembler):
        # The JSR resolves to ``osbyte`` at &fff4 (registered as an
        # external label).
        out = tiny_disassembler.render(JsonRenderer())
        jsr = out.data["items"][1]
        assert jsr["mnemonic"] == "jsr"
        assert jsr["target"] == 0xfff4
        assert jsr["target_label"] == "osbyte"
        assert jsr["operand"] == "osbyte"

    def test_format_hint_char_renders_quoted_and_surfaces_metadata(
        self, tmp_path,
    ):
        # ``FormatHint.CHAR`` declares "this byte is intended as an
        # ASCII character". The JSON renderer translates this into:
        # - operand text using a universal char-literal form (``'g'``
        #   — beebasm-style, also valid in most 6502 dialects);
        # - a ``format_hint: "char"`` field on the item, so consumers
        #   that want to render a different visual representation
        #   (e.g. an HTML page showing both the hex and the char) have
        #   the abstract semantic available.
        from dasmos.core.format_hint import FormatHint
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xa0, 0x67, 0x60]))  # ldy #&67 ; rts
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        d.char_literal(0x8001)
        items = d.disassemble().render(JsonRenderer()).data["items"]
        ldy = items[0]
        assert ldy["operand"] == "#'g'"
        assert ldy["format_hint"] == "char"

    def test_format_hint_decimal_forces_base_10_in_operand(self, tmp_path):
        from dasmos.core.format_hint import FormatHint
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xa9, 0xff, 0x60]))  # lda #&ff ; rts
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        d.format_hint(0x8001, FormatHint.DECIMAL)
        items = d.disassemble().render(JsonRenderer()).data["items"]
        assert items[0]["operand"] == "#255"
        assert items[0]["format_hint"] == "decimal"

    def test_format_hint_hex_overrides_small_int_decimal(self, tmp_path):
        from dasmos.core.format_hint import FormatHint
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xa9, 0x07, 0x60]))  # lda #&07 ; rts
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        d.format_hint(0x8001, FormatHint.HEX)
        items = d.disassemble().render(JsonRenderer()).data["items"]
        assert items[0]["operand"] == "#&07"
        assert items[0]["format_hint"] == "hex"

    def test_format_hint_binary_produces_percent_form(self, tmp_path):
        from dasmos.core.format_hint import FormatHint
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xa9, 0xaa, 0x60]))  # lda #&aa ; rts
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        d.format_hint(0x8001, FormatHint.BINARY)
        items = d.disassemble().render(JsonRenderer()).data["items"]
        assert items[0]["operand"] == "#%10101010"
        assert items[0]["format_hint"] == "binary"

    def test_format_hint_octal_warns_and_falls_back_in_json(self, tmp_path):
        # Like the beebasm renderer, JSON's operand syntax (modeled
        # on beebasm) has no octal sigil. Best-effort: emit decimal
        # and warn; the consumer still sees ``format_hint: "octal"``
        # in the metadata, so a sophisticated reader can render its
        # own octal form from the byte value.
        import warnings as _warnings
        from dasmos.core.format_hint import FormatHint
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xa9, 0xff, 0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        d.format_hint(0x8001, FormatHint.OCTAL)
        ir = d.disassemble()
        with _warnings.catch_warnings(record=True) as caught:
            _warnings.simplefilter("always")
            items = ir.render(JsonRenderer()).data["items"]
        assert items[0]["operand"] == "#255"
        assert items[0]["format_hint"] == "octal"
        warning_messages = [str(w.message) for w in caught]
        assert any("octal" in m.lower() for m in warning_messages)

    def test_no_format_hint_field_when_unset(self, tiny_disassembler):
        # Items without an explicit hint must NOT emit the field at
        # all (vs. emitting it with a null / placeholder value),
        # matching the schema-thrift convention used elsewhere in
        # the JSON output.
        items = tiny_disassembler.render(JsonRenderer()).data["items"]
        for item in items:
            assert "format_hint" not in item

    def test_format_hint_char_non_printable_falls_back_with_warning(
        self, tmp_path,
    ):
        import warnings as _warnings
        from dasmos.core.format_hint import FormatHint
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xa9, 0x07, 0x60]))  # non-printable
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        d.char_literal(0x8001)
        ir = d.disassemble()
        with _warnings.catch_warnings(record=True) as caught:
            _warnings.simplefilter("always")
            items = ir.render(JsonRenderer()).data["items"]
        # Operand fell back to plain decimal (small-int rule kicks in).
        assert items[0]["operand"] == "#7"
        # Hint metadata IS still surfaced — the consumer learns "the
        # user wanted a char here" even though no clean literal exists.
        assert items[0]["format_hint"] == "char"
        warning_messages = [str(w.message) for w in caught]
        assert any("char" in m.lower() and "&07" in m for m in warning_messages)

    def test_immediate_uses_decimal_below_10_hex_above(self, tmp_path):
        # py8dis-fork ``mainformatter.uint_formatter`` rule: decimal
        # for n < 10, hex for n >= 10. The JsonRenderer mirrors this
        # so the parity diff against py8dis stays small.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xa9, 0x00, 0xa9, 0x09, 0xa9, 0x0a, 0xa9, 0xff]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        ir = d.disassemble()
        items = ir.render(JsonRenderer()).data["items"]
        # LDA #0 .. LDA #9 → decimal; LDA #&0a, #&ff → hex.
        assert items[0]["operand"] == "#0"
        assert items[1]["operand"] == "#9"
        assert items[2]["operand"] == "#&0a"
        assert items[3]["operand"] == "#&ff"

    def test_index_register_letters_lowercase(self, tmp_path):
        # py8dis runs with ``lower_case=True`` so its operand text
        # uses ``,y`` / ``,x``. The JsonRenderer mirrors this.
        bin_path = tmp_path / "p.bin"
        # LDA $1234,X ; LDA $5678,Y ; LDA ($12,X) ; LDA ($34),Y
        bin_path.write_bytes(bytes([
            0xbd, 0x34, 0x12,
            0xb9, 0x78, 0x56,
            0xa1, 0x12,
            0xb1, 0x34,
        ]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000)
        ir = d.disassemble()
        items = ir.render(JsonRenderer()).data["items"]
        assert items[0]["operand"].endswith(",x")
        assert items[1]["operand"].endswith(",y")
        assert items[2]["operand"].endswith(",x)")
        assert items[3]["operand"].endswith("),y")

    def test_implied_opcode_has_no_operand_field(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        rts = out.data["items"][2]
        assert rts["mnemonic"] == "rts"
        assert "operand" not in rts
        assert rts["bytes"] == [0x60]

    def test_byte_classification_emits_values(self, tmp_path):
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x42, 0x43, 0x44]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.byte(0x8000, length=3)
        ir = d.disassemble()
        out = ir.render(JsonRenderer())
        bytes_item = out.data["items"][0]
        assert bytes_item["type"] == "byte"
        assert bytes_item["values"] == [0x42, 0x43, 0x44]
        assert bytes_item["bytes"] == [0x42, 0x43, 0x44]

    def test_string_classification_emits_text(self, tmp_path):
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(b"hi!")
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.string(0x8000, length=3)
        ir = d.disassemble()
        out = ir.render(JsonRenderer())
        s_item = out.data["items"][0]
        assert s_item["type"] == "string"
        assert s_item["string"] == "hi!"


class TestExternalLabels:
    """External labels (out-of-load-range) appear as a name → address
    mapping. py8dis schema is ``dict[str, int]``.
    """

    def test_external_labels_emitted_by_name(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        ext = out.data["external_labels"]
        assert ext["osbyte"] == 0xfff4

    def test_in_range_labels_not_external(self, tiny_disassembler):
        # ``start`` is at &8000 which IS loaded — it should appear in
        # an item's ``labels`` field, NOT in ``external_labels``.
        out = tiny_disassembler.render(JsonRenderer())
        assert "start" not in out.data["external_labels"]


class TestEmptySectionsArePresent:
    """A driver that doesn't register constants / subroutines /
    memory-map metadata still gets the keys, as empty lists.
    Downstream consumers may iterate them unconditionally.
    """

    def test_constants_present_as_empty_list(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        assert out.data["constants"] == []

    def test_subroutines_present_as_empty_list(self, tiny_disassembler):
        # tiny_disassembler uses d.entry(), not d.subroutine() — no
        # subroutines registered.
        out = tiny_disassembler.render(JsonRenderer())
        assert out.data["subroutines"] == []

    def test_memory_map_present_as_empty_list(self, tiny_disassembler):
        out = tiny_disassembler.render(JsonRenderer())
        assert out.data["memory_map"] == []


class TestConstantsSection:

    def test_emits_registered_constants(self, tmp_path):
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.constant(0xFE60, "system_via_orb", "System VIA port B")
        d.constant(0xFE61, "system_via_ddrb")
        ir = d.disassemble()
        out = ir.render(JsonRenderer())
        assert out.data["constants"] == [
            {"name": "system_via_orb", "value": 0xFE60,
             "comment": "System VIA port B"},
            {"name": "system_via_ddrb", "value": 0xFE61},
        ]


class TestSubroutinesSection:

    def test_emits_registered_subroutines(self, tmp_path):
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60, 0x60, 0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.subroutine(0x8000, "init",
                     title="Init", description="Sets things up.")
        d.subroutine(0x8002, "tick")
        ir = d.disassemble()
        subs = ir.render(JsonRenderer()).data["subroutines"]
        assert subs[0]["addr"] == 0x8000
        assert subs[0]["name"] == "init"
        assert subs[0]["title"] == "Init"
        assert subs[0]["description"] == "Sets things up."
        assert subs[1]["addr"] == 0x8002
        assert subs[1]["name"] == "tick"

    def test_fall_through_detected_when_no_terminator(self, tmp_path):
        # Sub at &8000: nop nop (two instructions, neither RTS/JMP/
        # BRK/RTI) → falls through into &8002.
        # Sub at &8002: rts (terminates).
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xea, 0xea, 0x60]))  # nop nop rts
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.subroutine(0x8000, "fall_in")
        d.subroutine(0x8002, "lands_here")
        ir = d.disassemble()
        subs = ir.render(JsonRenderer()).data["subroutines"]
        assert subs[0]["name"] == "fall_in"
        assert subs[0].get("fall_through") is True
        # Last sub in the region — no fall-through can be computed,
        # so the field is absent (not False).
        assert "fall_through" not in subs[1]

    def test_no_fall_through_when_terminator_present(self, tmp_path):
        # Sub at &8000: rts (terminates).  Sub at &8001: rts.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60, 0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.subroutine(0x8000, "first")
        d.subroutine(0x8001, "second")
        ir = d.disassemble()
        subs = ir.render(JsonRenderer()).data["subroutines"]
        assert "fall_through" not in subs[0]

    def test_non_relocated_sub_omits_binary_addr(self, tmp_path):
        # When a subroutine sits at its natural binary address (no
        # ``move()`` redirects it), the JSON entry omits ``binary_addr``
        # — matching the per-item convention. The acornaeology site
        # generator uses ``(addr, binary_addr)`` as the key that joins
        # subroutine entries to item entries, so a stray ``binary_addr``
        # on the sub side breaks the lookup and the structured banner
        # falls back to plain-comment rendering.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.subroutine(0x8000, "frob", title="Frob the bus")
        ir = d.disassemble()
        subs = ir.render(JsonRenderer()).data["subroutines"]
        assert subs[0]["addr"] == 0x8000
        assert "binary_addr" not in subs[0], subs[0]

    def test_standalone_banner_appears_in_banners_array(self, tmp_path):
        # d.banner() (without an accompanying d.subroutine()) is the
        # dasmos analogue of py8dis's data_banner — a visual section
        # header for a data region. dasmos's JSON schema gives these
        # their own ``banners`` array (parallel to ``subroutines``) so
        # downstream consumers can tell "subroutine entry point" from
        # "data region with header" without inspecting fields.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x00] * 4))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.label(0x8000, "table_x")
        d.banner(0x8000, title="Lookup table X",
                 description="32-entry sine table.")
        out = d.disassemble().render(JsonRenderer())
        # Not in subroutines (no entry-point semantics).
        assert all(s["addr"] != 0x8000 for s in out.data["subroutines"])
        # In banners.
        entry = next((b for b in out.data["banners"] if b["addr"] == 0x8000), None)
        assert entry is not None, out.data["banners"]
        assert entry["name"] == "table_x"
        assert entry["title"] == "Lookup table X"
        assert entry["description"] == "32-entry sine table."

    def test_subroutine_with_internal_banner_does_not_appear_in_banners(self, tmp_path):
        # d.subroutine() internally attaches a Banner annotation
        # (so the asm renderer can produce a banner block). The
        # subroutine's title/description are already on the
        # ``subroutines`` entry — the internal Banner must NOT
        # produce a duplicate ``banners`` entry at the same address.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.subroutine(0x8000, "frob",
                     title="Frob the bus", description="Does things.")
        out = d.disassemble().render(JsonRenderer())
        # In subroutines.
        subs = [s for s in out.data["subroutines"] if s["addr"] == 0x8000]
        assert len(subs) == 1, subs
        assert subs[0]["name"] == "frob"
        # NOT in banners.
        banners = [b for b in out.data["banners"] if b["addr"] == 0x8000]
        assert banners == [], banners

    def test_banner_carries_on_entry_on_exit(self, tmp_path):
        # Banner annotations can carry register-usage tables too.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x00] * 4))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.label(0x8000, "table_y")
        d.banner(0x8000, title="Table Y",
                 description="...",
                 on_entry={"a": "index"},
                 on_exit={"a": "value"})
        out = d.disassemble().render(JsonRenderer())
        entry = next(b for b in out.data["banners"] if b["addr"] == 0x8000)
        assert entry["on_entry"] == {"a": "index"}
        assert entry["on_exit"] == {"a": "value"}

    def test_banner_without_label_uses_no_name(self, tmp_path):
        # Bannered addresses don't strictly need a label.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x00]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.banner(0x8000, title="Anonymous banner",
                 description="No label here.")
        out = d.disassemble().render(JsonRenderer())
        entry = next(b for b in out.data["banners"] if b["addr"] == 0x8000)
        assert "name" not in entry, entry
        assert entry["title"] == "Anonymous banner"

    def test_banners_present_as_empty_list_when_none_attached(self, tmp_path):
        # The top-level ``banners`` key is always present, as an
        # empty list when no Banner annotations exist. Downstream
        # consumers can iterate it unconditionally.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.entry(0x8000, name="start")
        out = d.disassemble().render(JsonRenderer())
        assert out.data["banners"] == []

    def test_relocated_sub_keeps_binary_addr(self, tmp_path):
        # When a subroutine is in a relocated region, the binary
        # address differs from the runtime address and BOTH must be
        # surfaced (the item-level emission also keeps both).
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0xea, 0x60]))  # nop, rts
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.add_move(0x0400, 0x8000, 2)
        d.subroutine(0x0400, "moved")
        d.entry(0x0400)
        ir = d.disassemble()
        subs = ir.render(JsonRenderer()).data["subroutines"]
        assert subs[0]["addr"] == 0x0400
        assert subs[0]["binary_addr"] == 0x8000


class TestMemoryMapMetadata:
    """``memory_map`` entries describe out-of-load-range labels that
    document RAM / hardware locations. Driver scripts attach extra
    metadata via ``d.label(addr, name, length=, group=, access=,
    description=)``; the JSON renderer must surface every populated
    field so the site generator can render the access column,
    group-bucket the rows, and show address ranges.
    """

    def test_emits_length_group_access(self, tmp_path):
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.label(0x0080, "mem_ptr", description="Indirect pointer.",
                length=2, group="zero_page", access="rw")
        out = d.disassemble().render(JsonRenderer())
        mm = out.data["memory_map"]
        entry = next(e for e in mm if e["name"] == "mem_ptr")
        assert entry["addr"] == 0x80
        assert entry["length"] == 2
        assert entry["group"] == "zero_page"
        assert entry["access"] == "rw"
        assert entry["description"] == "Indirect pointer."

    def test_label_with_metadata_but_no_description_still_emitted(self, tmp_path):
        # An author may want a memory-map row purely as a labelled
        # workspace location with a bus-access annotation, without
        # narrative description text. Skipping such labels would drop
        # them from the rendered memory-map page.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.label(0xFE40, "system_via_orb",
                length=1, group="io", access="rw")
        out = d.disassemble().render(JsonRenderer())
        mm = out.data["memory_map"]
        entry = next(e for e in mm if e["name"] == "system_via_orb")
        assert entry["access"] == "rw"
        assert entry["group"] == "io"
        assert "description" not in entry

    def test_optional_fields_omitted_when_unset(self, tmp_path):
        # A label with only a description (no length/group/access)
        # emits just description — no spurious empty fields.
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.label(0x0070, "scratch", description="Scratch byte.")
        out = d.disassemble().render(JsonRenderer())
        mm = out.data["memory_map"]
        entry = next(e for e in mm if e["name"] == "scratch")
        assert entry["description"] == "Scratch byte."
        assert "length" not in entry
        assert "group" not in entry
        assert "access" not in entry

    def test_in_range_label_with_metadata_not_in_memory_map(self, tmp_path):
        # Labels INSIDE the loaded range describe code/data in the
        # ROM and should NOT appear in memory_map (which is about
        # out-of-ROM memory: zero page, workspace, hardware).
        bin_path = tmp_path / "p.bin"
        bin_path.write_bytes(bytes([0x60]))
        d = Disassembler.create(cpu="6502")
        d.load(bin_path, 0x8000)
        d.label(0x8000, "in_rom",
                length=1, group="rom", access="r",
                description="Inside ROM.")
        out = d.disassemble().render(JsonRenderer())
        mm = out.data["memory_map"]
        assert all(e["name"] != "in_rom" for e in mm), mm
