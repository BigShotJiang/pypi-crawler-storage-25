"""youtune — The smartest YouTube → MP3 downloader."""

__version__ = "1.0.0"
