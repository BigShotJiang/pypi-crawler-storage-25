"""Tests for the agent-first Hypernote CLI."""

from __future__ import annotations

import json
from dataclasses import dataclass
from types import SimpleNamespace

import pytest
from click.testing import CliRunner

from hypernote import CellType, ChangeKind, JobStatus, RuntimeStatus
from hypernote.cli import main as cli_main
from hypernote.cli.main import cli


class FakeJob:
    def __init__(
        self,
        notebook: "FakeNotebook",
        cell_ids: tuple[str, ...],
        transitions: list[dict] | None = None,
    ):
        self.notebook = notebook
        self.id = f"job-{len(notebook.created_jobs) + 1}"
        self.status = JobStatus.RUNNING if transitions else JobStatus.SUCCEEDED
        self.cell_ids = cell_ids
        self.notebook_path = notebook.path
        self._transitions = list(transitions or [])

    def refresh(self) -> "FakeJob":
        if self._transitions:
            transition = self._transitions.pop(0)
            for cell_id, outputs in transition.get("outputs", {}).items():
                self.notebook._cells[cell_id]["outputs"] = outputs
            for cell_id, execution_count in transition.get("execution_counts", {}).items():
                self.notebook._cells[cell_id]["execution_count"] = execution_count
            if "status" in transition:
                self.status = transition["status"]
        return self

    def wait(self, timeout: float | None = None) -> "FakeJob":  # noqa: ARG002
        while self.status not in {
            JobStatus.SUCCEEDED,
            JobStatus.FAILED,
            JobStatus.INTERRUPTED,
            JobStatus.AWAITING_INPUT,
        }:
            self.refresh()
        return self

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "status": self.status.value,
            "cell_ids": list(self.cell_ids),
            "notebook_path": self.notebook_path,
        }


class FakeTimeoutJob(FakeJob):
    def wait(self, timeout: float | None = None) -> "FakeJob":  # noqa: ARG002
        raise cli_main.ExecutionTimeoutError(cli_main._job_timeout_message(self))


class FakeRuntime:
    def __init__(self, notebook: "FakeNotebook"):
        self.notebook = notebook
        self.status = RuntimeStatus.STOPPED

    def ensure(self) -> "FakeRuntime":
        self.status = RuntimeStatus.LIVE_ATTACHED
        return self

    def stop(self) -> "FakeRuntime":
        self.status = RuntimeStatus.STOPPED
        return self

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "recoverable": False,
            "session_id": None,
            "kernel_id": None,
            "kernel_name": "python3",
        }


class FakeCellHandle:
    def __init__(self, notebook: "FakeNotebook", cell_id: str):
        self._notebook = notebook
        self.id = cell_id

    @property
    def _cell(self) -> dict:
        return self._notebook._cells[self.id]

    @property
    def type(self) -> CellType:
        return CellType(self._cell["cell_type"])

    @property
    def source(self) -> str:
        return self._cell["source"]

    @property
    def outputs(self) -> tuple[dict, ...]:
        return tuple(self._cell.get("outputs", []))

    @property
    def execution_count(self) -> int | None:
        return self._cell.get("execution_count")

    def replace(self, source: str) -> "FakeCellHandle":
        self._cell["source"] = source
        return self

    def delete(self) -> None:
        self._notebook._order.remove(self.id)
        self._notebook._cells.pop(self.id, None)

    def move(self, *, before: str | None = None, after: str | None = None) -> None:
        self._notebook._order.remove(self.id)
        if before is not None:
            index = self._notebook._order.index(before)
            self._notebook._order.insert(index, self.id)
        elif after is not None:
            index = self._notebook._order.index(after) + 1
            self._notebook._order.insert(index, self.id)
        else:
            self._notebook._order.append(self.id)

    def clear_outputs(self) -> "FakeCellHandle":
        self._cell["outputs"] = []
        return self

    def run(self) -> FakeJob:
        if self.type != CellType.CODE:
            raise cli_main.click.ClickException(f"Cell {self.id} is {self.type.value}, not code")
        return self._notebook._create_job((self.id,))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type.value,
            "source": self.source,
            "outputs": list(self.outputs),
            "execution_count": self.execution_count,
        }


class FakeCellCollection:
    def __init__(self, notebook: "FakeNotebook"):
        self._notebook = notebook

    def __getitem__(self, cell_id: str) -> FakeCellHandle:
        if cell_id not in self._notebook._cells:
            raise cli_main.CellNotFoundError(cell_id)
        return FakeCellHandle(self._notebook, cell_id)

    def __iter__(self):
        for cell_id in self._notebook._order:
            yield FakeCellHandle(self._notebook, cell_id)

    def insert_code(
        self,
        source: str,
        *,
        id: str | None = None,
        before: str | None = None,
        after: str | None = None,
    ) -> FakeCellHandle:
        return self._insert("code", source, id=id, before=before, after=after)

    def insert_markdown(
        self,
        source: str,
        *,
        id: str | None = None,
        before: str | None = None,
        after: str | None = None,
    ) -> FakeCellHandle:
        return self._insert("markdown", source, id=id, before=before, after=after)

    def _insert(
        self,
        cell_type: str,
        source: str,
        *,
        id: str | None,
        before: str | None,
        after: str | None,
    ) -> FakeCellHandle:
        cell_id = id or f"cell-{len(self._notebook._order) + 1}"
        self._notebook._cells[cell_id] = {
            "id": cell_id,
            "cell_type": cell_type,
            "source": source,
            "outputs": [],
            "execution_count": None,
        }
        if before is not None:
            index = self._notebook._order.index(before)
            self._notebook._order.insert(index, cell_id)
        elif after is not None:
            index = self._notebook._order.index(after) + 1
            self._notebook._order.insert(index, cell_id)
        else:
            self._notebook._order.append(cell_id)
        return FakeCellHandle(self._notebook, cell_id)


@dataclass
class FakeCellStatus:
    id: str
    type: CellType
    source: str
    outputs: tuple[dict, ...]
    execution_count: int | None
    change_kinds: tuple[ChangeKind, ...] = ()

    def has_error_output(self) -> bool:
        return any(output.get("output_type") == "error" for output in self.outputs)

    def compact_dict(
        self,
        *,
        full_source: bool = False,
        include_outputs: bool = False,
        full_output: bool = False,  # noqa: ARG002
        max_output_chars: int = 400,
    ) -> dict:
        entry = {
            "id": self.id,
            "type": self.type.value,
            "execution_count": self.execution_count,
            "output_count": len(self.outputs),
            "has_error_output": self.has_error_output(),
            "source_preview": self.source[:120] + ("…" if len(self.source) > 120 else ""),
        }
        if len(self.source) > 120:
            entry["source_truncated"] = True
            entry["source_total_chars"] = len(self.source)
            entry["source_hint"] = "truncated, use --full to see complete source"
        if full_source:
            entry["source"] = self.source
        if self.outputs:
            text = str(self.outputs[-1].get("text", ""))
            preview = text[:max_output_chars] + ("…" if len(text) > max_output_chars else "")
            entry["output_preview"] = preview
            if len(text) > max_output_chars:
                entry["output_truncated"] = True
                entry["output_total_chars"] = len(text)
                entry["output_hint"] = (
                    f"truncated, {len(text)} chars total; "
                    "use --full-output to see complete text"
                )
        if include_outputs:
            summarized = []
            for output in self.outputs:
                text = str(output.get("text", ""))
                item = {"output_type": output.get("output_type", "unknown"), "text": text}
                if len(text) > max_output_chars:
                    item["text"] = text[:max_output_chars] + "…"
                    item["truncated"] = True
                    item["total_chars"] = len(text)
                    item["hint"] = (
                        f"truncated, {len(text)} chars total; "
                        "use --full-output to see complete text"
                    )
                summarized.append(item)
            entry["outputs"] = summarized
        return entry

    def output_payload(
        self,
        *,
        max_chars: int = 400,
        full_output: bool = False,  # noqa: ARG002
        tail: bool = False,
    ) -> dict:
        outputs = []
        for output in self.outputs:
            text = str(output.get("text", ""))
            item = {"output_type": output.get("output_type", "unknown"), "text": text}
            if len(text) > max_chars:
                item["text"] = text[:max_chars] + "…"
                item["truncated"] = True
                item["total_chars"] = len(text)
                item["hint"] = (
                    f"truncated, {len(text)} chars total; "
                    "use --full-output to see complete text"
                )
            outputs.append(item)
        payload = {"cell_id": self.id, "output_count": len(outputs), "outputs": outputs}
        if tail and outputs:
            payload["tail_output"] = outputs[-1]["text"]
            if outputs[-1].get("truncated"):
                payload["tail_output_truncated"] = True
                payload["tail_output_total_chars"] = outputs[-1]["total_chars"]
        return payload


class FakeNotebookStatus:
    def __init__(self, notebook: "FakeNotebook", *, diff: bool = False):
        self.notebook_path = notebook.path
        self.summary = f"{notebook.path} · {'diff' if diff else 'status'}"
        self.current = SimpleNamespace(token="snap-123")
        self.runtime = notebook.runtime.status
        self.cells = tuple(
            FakeCellStatus(
                id=cell_id,
                type=CellType(notebook._cells[cell_id]["cell_type"]),
                source=notebook._cells[cell_id]["source"],
                outputs=tuple(notebook._cells[cell_id]["outputs"]),
                execution_count=notebook._cells[cell_id]["execution_count"],
                change_kinds=((ChangeKind.ADDED,) if diff else ()),
            )
            for cell_id in notebook._order
        )

    def to_dict(self) -> dict:
        return {
            "summary": self.summary,
            "cells": [
                {
                    "id": cell.id,
                    "type": cell.type.value,
                    "source": cell.source,
                    "outputs": list(cell.outputs),
                    "execution_count": cell.execution_count,
                    "change_kinds": [kind.value for kind in cell.change_kinds],
                }
                for cell in self.cells
            ],
        }

    def aggregates(self) -> dict:
        code_cells = sum(1 for cell in self.cells if cell.type == CellType.CODE)
        markdown_cells = sum(1 for cell in self.cells if cell.type == CellType.MARKDOWN)
        executed_cells = sum(1 for cell in self.cells if cell.execution_count is not None)
        failed_cells = sum(1 for cell in self.cells if cell.has_error_output())
        output_count = sum(1 for cell in self.cells if cell.outputs)
        return {
            "cells_total": len(self.cells),
            "code_cells": code_cells,
            "markdown_cells": markdown_cells,
            "raw_cells": 0,
            "executed_cells": executed_cells,
            "failed_cells": failed_cells,
            "changed_cells": 0,
            "output_cells": output_count,
            "runtime_state": self.runtime.value,
            "snapshot": self.current.token,
            "summary": {
                "headline": self.summary,
                "cell_count": len(self.cells),
                "code_cells": code_cells,
                "markdown_cells": markdown_cells,
                "raw_cells": 0,
                "executed_cells": executed_cells,
                "failed_cells": failed_cells,
                "output_count": output_count,
                "runtime_state": self.runtime.value,
            },
        }

    def compact_cells(
        self,
        *,
        full_source: bool = False,
        include_outputs: bool = False,
        full_output: bool = False,
        failed_only: bool = False,
        query: str | None = None,
        max_output_chars: int = 400,
    ) -> list[dict]:
        cells = []
        for cell in self.cells:
            if failed_only and not cell.has_error_output():
                continue
            payload = cell.compact_dict(
                full_source=full_source,
                include_outputs=include_outputs,
                full_output=full_output,
                max_output_chars=max_output_chars,
            )
            if query and query.lower() not in json.dumps(payload).lower():
                continue
            cells.append(payload)
        return cells

    def compact_dict(
        self,
        *,
        full_source: bool = False,
        include_outputs: bool = False,
        full_output: bool = False,
        failed_only: bool = False,
        query: str | None = None,
        max_output_chars: int = 400,
        include_details: bool = False,
    ) -> dict:
        payload = {
            **self.aggregates(),
            "filters": {"failed_only": failed_only, "query": query},
            "cells": self.compact_cells(
                full_source=full_source,
                include_outputs=include_outputs,
                full_output=full_output,
                failed_only=failed_only,
                query=query,
                max_output_chars=max_output_chars,
            ),
        }
        if include_details:
            payload["details"] = self.to_dict()
        return payload

    def cell(self, cell_id: str) -> FakeCellStatus:
        for cell in self.cells:
            if cell.id == cell_id:
                return cell
        raise cli_main.CellNotFoundError(cell_id)


class FakeNotebook:
    def __init__(self, path: str):
        self.path = path
        self.runtime = FakeRuntime(self)
        self.cells = FakeCellCollection(self)
        self._cells: dict[str, dict] = {}
        self._order: list[str] = []
        self.created_jobs: list[FakeJob] = []
        self.next_job_transitions: list[list[dict]] = []
        self.interrupted = False
        self.restarted = False

    def _create_job(self, cell_ids: tuple[str, ...]) -> FakeJob:
        transitions = self.next_job_transitions.pop(0) if self.next_job_transitions else None
        job = FakeJob(self, cell_ids, transitions)
        self.created_jobs.append(job)
        return job

    def run(self, *cell_ids: str) -> FakeJob:
        return self._create_job(tuple(cell_ids))

    def run_all(self) -> FakeJob:
        code_ids = tuple(
            cell_id for cell_id in self._order if self._cells[cell_id]["cell_type"] == "code"
        )
        return self._create_job(code_ids)

    def restart(self) -> FakeRuntime:
        self.restarted = True
        self.runtime.status = RuntimeStatus.LIVE_ATTACHED
        return self.runtime

    def interrupt(self) -> None:
        self.interrupted = True

    def status(self, *, full: bool = False) -> FakeNotebookStatus:  # noqa: ARG002
        return FakeNotebookStatus(self, diff=False)

    def diff(self, *, snapshot, full: bool = False) -> FakeNotebookStatus:  # noqa: ARG002
        return FakeNotebookStatus(self, diff=True)


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def fake_notebooks(monkeypatch):
    notebooks: dict[str, FakeNotebook] = {}

    def factory(path: str, create: bool = False, **kwargs):  # noqa: ARG001
        if path not in notebooks and not create:
            raise cli_main.NotebookNotFoundError(path)
        was_created = path not in notebooks
        nb = notebooks.setdefault(path, FakeNotebook(path))
        nb._was_created = was_created
        return nb

    monkeypatch.setattr(cli_main, "connect", factory)
    return notebooks


def test_cli_help(runner):
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    for cmd in [
        "create",
        "ix",
        "exec",
        "edit",
        "run-all",
        "restart",
        "restart-run-all",
        "interrupt",
        "status",
        "diff",
        "cat",
        "job",
        "runtime",
        "setup",
    ]:
        assert cmd in result.output


def test_cli_home_view_reports_server_state_and_hints(runner, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)

    class FakeControl:
        def list_jobs(self) -> dict:
            return {"jobs": []}

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, [])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "home"
    assert payload["bin"] == "hypernote"
    assert payload["server_reachable"] is True
    assert payload["active_job_count"] == 0
    assert any("create tmp/demo.ipynb --empty" in hint for hint in payload["hints"])
    assert any("setup doctor" in hint for hint in payload["hints"])


def test_cli_home_view_surfaces_unreachable_server_without_crashing(runner, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)

    class FakeControl:
        def list_jobs(self) -> dict:
            raise RuntimeError("connection refused")

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, [])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "home"
    assert payload["server_reachable"] is False
    assert "connection refused" in payload["server_error"]
    assert any("setup serve" in hint for hint in payload["hints"])


def test_ix_non_tty_returns_compact_json_by_default(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.next_job_transitions.append(
        [{"status": JobStatus.SUCCEEDED, "execution_counts": {"cell-1": 1}}]
    )

    result = runner.invoke(cli, ["ix", "demo.ipynb", "-s", "print(1)"])

    assert result.exit_code == 0
    payload = json.loads(result.output.strip().splitlines()[-1])
    assert payload["command"] == "ix"
    assert payload["job"]["status"] == "succeeded"
    assert payload["inserted_cells"][0]["id"] == "cell-1"
    assert any("hypernote cat demo.ipynb" in hint for hint in payload["hints"])
    assert any("hypernote status demo.ipynb" in hint for hint in payload["hints"])


def test_ix_tty_streams_human_progress_by_default(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: True)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.next_job_transitions.append(
        [
            {
                "status": JobStatus.RUNNING,
                "outputs": {
                    "cell-1": [{"output_type": "stream", "name": "stdout", "text": "42\n"}]
                },
            },
            {
                "status": JobStatus.SUCCEEDED,
                "outputs": {
                    "cell-1": [{"output_type": "stream", "name": "stdout", "text": "42\n"}]
                },
                "execution_counts": {"cell-1": 1},
            },
        ]
    )

    result = runner.invoke(cli, ["ix", "demo.ipynb", "-s", "print(42)"])

    assert result.exit_code == 0
    assert "Started job" in result.output
    assert "42" in result.output
    assert "succeeded" in result.output


def test_ix_stream_json_emits_events(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.next_job_transitions.append(
        [
            {
                "status": JobStatus.RUNNING,
                "outputs": {
                    "cell-1": [{"output_type": "stream", "name": "stdout", "text": "tick:0\n"}]
                },
            },
            {
                "status": JobStatus.SUCCEEDED,
                "outputs": {
                    "cell-1": [{"output_type": "stream", "name": "stdout", "text": "tick:0\n"}]
                },
                "execution_counts": {"cell-1": 1},
            },
        ]
    )

    result = runner.invoke(cli, ["ix", "demo.ipynb", "-s", "print(1)", "--stream-json"])

    assert result.exit_code == 0
    events = [json.loads(line) for line in result.output.strip().splitlines()]
    event_names = [event["event"] for event in events]
    assert "cell_inserted" in event_names
    assert "job_started" in event_names
    assert "output_delta" in event_names
    assert "job_completed" in event_names


def test_create_empty_removes_default_cells_on_new_notebook(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    # Notebook does not exist yet — factory will mark _was_created=True
    result = runner.invoke(cli, ["create", "new.ipynb", "--empty"])
    nb = fake_notebooks["new.ipynb"]

    assert result.exit_code == 0
    assert len(nb._order) == 0
    payload = json.loads(result.output)
    assert payload["command"] == "create"


def test_create_empty_preserves_cells_on_existing_notebook(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("existing.ipynb", FakeNotebook("existing.ipynb"))
    nb.cells.insert_code("print(1)", id="existing-cell")

    result = runner.invoke(cli, ["create", "existing.ipynb", "--empty"])

    assert result.exit_code == 0
    assert len(nb._order) == 1  # cells NOT deleted on existing notebook
    payload = json.loads(result.output)
    assert payload["command"] == "create"


def test_exec_on_markdown_cell_fails_clearly(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.cells.insert_markdown("hello", id="md-1")

    result = runner.invoke(cli, ["exec", "demo.ipynb", "md-1"])

    assert result.exit_code != 0
    assert "not code" in result.output


def test_batch_ix_no_wait_is_rejected(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))

    result = runner.invoke(
        cli,
        [
            "ix",
            "demo.ipynb",
            "--cells-json",
            json.dumps(
                [
                    {"type": "markdown", "source": "# Title"},
                    {"type": "code", "source": "print(1)"},
                ]
            ),
            "--no-wait",
        ],
    )

    assert result.exit_code != 0
    assert "batch ix does not support --no-wait" in result.output


def test_batch_ix_reports_partial_state_after_failure(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.next_job_transitions.append(
        [
            {
                "status": JobStatus.FAILED,
                "execution_counts": {"setup-cell": 1},
            }
        ]
    )

    result = runner.invoke(
        cli,
        [
            "ix",
            "demo.ipynb",
            "--cells-json",
            json.dumps(
                [
                    {"id": "intro-md", "type": "markdown", "source": "# Intro"},
                    {"id": "setup-cell", "type": "code", "source": "raise RuntimeError('boom')"},
                    {"id": "later-cell", "type": "code", "source": "print('later')"},
                ]
            ),
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output.strip().splitlines()[-1])
    assert payload["status"] == "error"
    assert payload["halt_reason"] == "job_failed"
    assert payload["last_processed_cell_id"] == "setup-cell"
    assert payload["cells_inserted"] == 2
    assert payload["cells_total"] == 3
    assert payload["cells_remaining"] == 1
    assert [entry["cell_id"] for entry in payload["results"]] == ["intro-md", "setup-cell"]


def test_ix_failure_returns_repair_hints(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.next_job_transitions.append([{"status": JobStatus.FAILED}])

    result = runner.invoke(cli, ["ix", "demo.ipynb", "-s", "raise RuntimeError('boom')"])

    assert result.exit_code == 0
    payload = json.loads(result.output.strip().splitlines()[-1])
    assert payload["job"]["status"] == "failed"
    assert any("edit replace demo.ipynb cell-1" in hint for hint in payload["hints"])
    assert any("exec demo.ipynb cell-1" in hint for hint in payload["hints"])


def test_edit_replace_maps_to_sdk_mutation(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.cells.insert_code("print(1)", id="code-1")

    result = runner.invoke(cli, ["edit", "replace", "demo.ipynb", "code-1", "-s", "print(2)"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["cell"]["source"] == "print(2)"


def test_status_and_diff_surface_observation_model(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.cells.insert_code("print(1)", id="code-1")

    status_result = runner.invoke(cli, ["status", "demo.ipynb"])
    diff_result = runner.invoke(cli, ["diff", "demo.ipynb", "--snapshot", "snap-123"])

    assert status_result.exit_code == 0
    assert diff_result.exit_code == 0
    assert json.loads(status_result.output)["command"] == "status"
    assert json.loads(diff_result.output)["command"] == "diff"


def test_status_returns_summary_first_payload_with_hints_and_truncation(
    runner,
    fake_notebooks,
    monkeypatch,
):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    long_source = "print('" + ("x" * 200) + "')"
    nb.cells.insert_code(long_source, id="code-1")
    nb._cells["code-1"]["outputs"] = [
        {"output_type": "stream", "name": "stdout", "text": "y" * 500}
    ]
    nb._cells["code-1"]["execution_count"] = 1

    result = runner.invoke(cli, ["status", "demo.ipynb"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "status"
    assert payload["cells_total"] == 1
    assert payload["executed_cells"] == 1
    assert payload["failed_cells"] == 0
    assert payload["snapshot"] == "snap-123"
    cell = payload["cells"][0]
    assert cell["source_truncated"] is True
    assert cell["output_truncated"] is True
    assert "use --full" in cell["source_hint"]
    assert "use --full-output" in cell["output_hint"]
    assert any("hypernote cat demo.ipynb" in hint for hint in payload["hints"])


def test_cat_defaults_to_compact_cells_and_truncates_outputs(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    long_source = "value = '" + ("x" * 180) + "'"
    nb.cells.insert_code(long_source, id="code-1")
    nb._cells["code-1"]["outputs"] = [
        {"output_type": "stream", "name": "stdout", "text": "z" * 500}
    ]
    nb._cells["code-1"]["execution_count"] = 1

    result = runner.invoke(cli, ["cat", "demo.ipynb"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "cat"
    assert payload["summary"]["cell_count"] == 1
    assert payload["summary"]["output_count"] == 1
    cell = payload["cells"][0]
    assert "source_preview" in cell
    assert "source" not in cell
    assert cell["source_truncated"] is True
    output = cell["outputs"][0]
    assert output["truncated"] is True
    assert output["total_chars"] == 500
    assert "use --full-output" in output["hint"]
    assert any("hypernote status demo.ipynb" in hint for hint in payload["hints"])


def test_home_without_subcommand_returns_live_state_payload(runner, monkeypatch, tmp_path):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    monkeypatch.chdir(tmp_path)
    (tmp_path / "demo.ipynb").write_text("{}")

    class FakeControl:
        def list_jobs(self) -> dict:
            return {
                "jobs": [
                    {
                        "job_id": "job-1",
                        "status": "running",
                        "notebook_id": "demo.ipynb",
                        "target_cells": '["cell-1"]',
                    }
                ]
            }

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, [])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "home"
    assert payload["server_reachable"] is True
    assert payload["active_job_count"] == 1
    assert payload["workspace_notebook_count"] == 1
    assert payload["hints"]


def test_home_without_subcommand_accepts_list_target_cells(runner, monkeypatch, tmp_path):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    monkeypatch.chdir(tmp_path)
    (tmp_path / "demo.ipynb").write_text("{}")

    class FakeControl:
        def list_jobs(self) -> dict:
            return {
                "jobs": [
                    {
                        "job_id": "job-1",
                        "status": "running",
                        "notebook_id": "demo.ipynb",
                        "target_cells": ["cell-1", "cell-2"],
                    }
                ]
            }

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, [])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["active_job_count"] == 1
    assert payload["active_jobs"][0]["target_cell_count"] == 2


def test_status_returns_aggregates_and_hints(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.runtime.status = RuntimeStatus.LIVE_ATTACHED
    nb.cells.insert_code("print(1)", id="code-1")

    result = runner.invoke(cli, ["status", "demo.ipynb"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "status"
    assert payload["cells_total"] == 1
    assert payload["runtime_state"] == "live-attached"
    assert payload["hints"]


def test_cat_cell_returns_compact_summary_and_hints(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    cell = nb.cells.insert_code("print('hello')", id="code-1")
    nb._cells[cell.id]["outputs"] = [{"output_type": "stream", "name": "stdout", "text": "hello\n"}]
    nb._cells[cell.id]["execution_count"] = 1

    result = runner.invoke(cli, ["cat", "demo.ipynb", "--cell", "code-1"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "cat"
    assert payload["cell_id"] == "code-1"
    assert len(payload["cells"]) == 1
    assert payload["hints"]


def test_cat_output_payload_keeps_command_and_path_envelope(
    runner,
    fake_notebooks,
    monkeypatch,
):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    cell = nb.cells.insert_code("print('hello')", id="code-1")
    nb._cells[cell.id]["outputs"] = [{"output_type": "stream", "name": "stdout", "text": "hello\n"}]

    result = runner.invoke(cli, ["cat", "demo.ipynb", "--output", "code-1"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "cat"
    assert payload["path"] == "demo.ipynb"
    assert payload["cell_id"] == "code-1"
    assert payload["selected_cell_id"] == "code-1"
    assert payload["summary"]["output_count"] == 1


def test_cat_tail_output_payload_surfaces_tail_truncation_metadata(
    runner,
    fake_notebooks,
    monkeypatch,
):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    cell = nb.cells.insert_code("print('hello')", id="code-1")
    nb._cells[cell.id]["outputs"] = [
        {"output_type": "stream", "name": "stdout", "text": "x" * 500}
    ]

    result = runner.invoke(cli, ["cat", "demo.ipynb", "--tail-output", "code-1"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "cat"
    assert payload["path"] == "demo.ipynb"
    assert payload["tail_output_truncated"] is True
    assert payload["tail_output_total_chars"] == 500


def test_job_get_and_stdin_use_sdk_control(runner, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)

    class FakeControl:
        def get_job_payload(self, job_id: str) -> dict:
            return {"job_id": job_id, "status": "running"}

        def send_job_stdin(self, job_id: str, value: str) -> dict:
            return {"job_id": job_id, "sent": True, "value": value}

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    get_result = runner.invoke(cli, ["job", "get", "job-1"])
    stdin_result = runner.invoke(cli, ["job", "stdin", "job-1", "--value", "gilad"])

    assert get_result.exit_code == 0
    assert stdin_result.exit_code == 0
    assert json.loads(get_result.output)["job_id"] == "job-1"
    assert json.loads(stdin_result.output)["sent"] is True


def test_job_await_uses_sdk_control_lookup(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.cells.insert_code("print(1)", id="code-1")
    job = nb._create_job(("code-1",))
    job.status = JobStatus.SUCCEEDED

    class FakeControl:
        def get_job(self, job_id: str) -> FakeJob:
            assert job_id == "job-1"
            return job

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["job", "await", "job-1"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["command"] == "job.await"
    assert payload["job"]["status"] == "succeeded"


def test_setup_doctor_uses_sdk_control(runner, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)

    class FakeControl:
        def list_jobs(self) -> dict:
            return {"jobs": []}

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["setup", "doctor"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["hypernote_api"] == "ok"
    assert payload["jobs_endpoint"] is True


def test_setup_doctor_reports_default_kernel_launcher(runner, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)

    class FakeControl:
        def list_jobs(self) -> dict:
            return {"jobs": []}

        def get_kernelspec(self, kernel_name: str) -> dict:
            assert kernel_name == "python3"
            return {"name": "python3", "spec": {"argv": ["/repo/.venv/bin/python", "-m"]}}

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["setup", "doctor"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["hypernote_api"] == "ok"
    assert payload["default_kernel"] == "/repo/.venv/bin/python"


def test_setup_doctor_reports_jupyterlab_integration_stack(runner, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    monkeypatch.setattr(cli_main, "_running_jupyter_servers", lambda: [], raising=False)

    class FakeControl:
        def get_server_diagnostics(self) -> dict:
            return {
                "jupyter_server_nbmodel": "ok",
                "jupyter_server_ydoc": "ok",
            }

        def list_jobs(self) -> dict:
            return {"jobs": []}

        def get_kernelspec(self, kernel_name: str) -> dict:
            assert kernel_name == "python3"
            return {"name": "python3", "spec": {"argv": ["/repo/.venv/bin/python", "-m"]}}

        def get_lab_extensions(self) -> list[dict]:
            return [
                {"name": "@jupyter/collaboration-extension", "enabled": True, "status": "ok"},
                {"name": "@jupyter/docprovider-extension", "enabled": True, "status": "ok"},
            ]

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["setup", "doctor"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["hypernote_api"] == "ok"
    assert payload["jupyter_server_nbmodel"] == "ok"
    assert payload["jupyter_server_ydoc"] == "ok"
    assert payload["jupyterlab"] == "ok"
    assert payload["jupyter_collaboration"] == "ok"
    assert payload["jupyter_docprovider"] == "ok"


def test_setup_doctor_warns_about_duplicate_servers_for_same_workspace(
    runner,
    monkeypatch,
    tmp_path,
):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    monkeypatch.setattr(
        cli_main,
        "_running_jupyter_servers",
        lambda: [
            {
                "url": "http://127.0.0.1:8888/",
                "port": 8888,
                "root_dir": str(tmp_path),
                "pid": 111,
            },
            {
                "url": "http://127.0.0.1:8889/",
                "port": 8889,
                "root_dir": str(tmp_path),
                "pid": 222,
            },
        ],
    )

    class FakeControl:
        def list_jobs(self) -> dict:
            return {"jobs": []}

        def get_kernelspec(self, kernel_name: str) -> dict:
            assert kernel_name == "python3"
            return {"name": "python3", "spec": {"argv": ["/repo/.venv/bin/python", "-m"]}}

        def get_lab_extensions(self) -> list[dict]:
            return []

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["setup", "doctor"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["duplicate_servers"][0]["port"] == 8889
    assert any("another Jupyter server" in warning for warning in payload["warnings"])


def test_setup_doctor_does_not_flag_wildcard_bind_as_duplicate(
    runner,
    monkeypatch,
    tmp_path,
):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    monkeypatch.setattr(
        cli_main,
        "_running_jupyter_servers",
        lambda: [
            {
                "url": "http://0.0.0.0:8888/",
                "port": 8888,
                "root_dir": str(tmp_path),
                "pid": 111,
            },
        ],
    )

    class FakeControl:
        def get_server_diagnostics(self) -> dict:
            return {
                "jupyter_server_nbmodel": "ok",
                "jupyter_server_ydoc": "ok",
            }

        def list_jobs(self) -> dict:
            return {"jobs": []}

        def get_kernelspec(self, kernel_name: str) -> dict:
            assert kernel_name == "python3"
            return {"name": "python3", "spec": {"argv": ["/repo/.venv/bin/python", "-m"]}}

        def get_lab_extensions(self) -> list[dict]:
            return []

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["setup", "doctor"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert "duplicate_servers" not in payload


def test_setup_serve_launches_jupyterlab_with_browser_by_default(
    runner,
    monkeypatch,
    tmp_path,
):
    monkeypatch.setattr(cli_main.importlib.util, "find_spec", lambda name: object())
    captured: dict[str, object] = {}

    def fake_run(cmd, cwd, check):  # noqa: ANN001
        captured["cmd"] = cmd
        captured["cwd"] = cwd
        captured["check"] = check
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(cli_main.subprocess, "run", fake_run)

    result = runner.invoke(
        cli,
        [
            "--server",
            "http://127.0.0.1:8899",
            "setup",
            "serve",
            "--root",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    assert "Starting Hypernote JupyterLab server at http://127.0.0.1:8899" in result.output
    cmd = captured["cmd"]
    assert cmd[:3] == [cli_main.sys.executable, "-m", "jupyterlab"]
    assert "--no-browser" not in cmd
    assert "--ServerApp.ip=127.0.0.1" in cmd
    assert "--ServerApp.port=8899" in cmd
    assert f"--ServerApp.root_dir={tmp_path.resolve()}" in cmd
    assert (
        f"--ServerApp.jpserver_extensions={cli_main.HYPERNOTE_EXTENSION_FLAGS}" in cmd
    )
    assert (
        "--YDocExtension.ystore_class=jupyter_server_ydoc.stores.TempFileYStore"
        in cmd
    )
    assert captured["cwd"] == str(tmp_path.resolve())
    assert captured["check"] is False


def test_setup_serve_no_browser_suppresses_browser_launch(runner, monkeypatch, tmp_path):
    monkeypatch.setattr(cli_main.importlib.util, "find_spec", lambda name: object())
    captured: dict[str, object] = {}

    def fake_run(cmd, cwd, check):  # noqa: ANN001
        captured["cmd"] = cmd
        captured["cwd"] = cwd
        captured["check"] = check
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(cli_main.subprocess, "run", fake_run)

    result = runner.invoke(cli, ["setup", "serve", "--root", str(tmp_path), "--no-browser"])

    assert result.exit_code == 0
    assert "--no-browser" in captured["cmd"]


def test_setup_serve_fails_cleanly_without_jupyterlab(runner, monkeypatch, tmp_path):
    monkeypatch.setattr(cli_main.importlib.util, "find_spec", lambda name: None)

    result = runner.invoke(cli, ["setup", "serve", "--root", str(tmp_path)])

    assert result.exit_code != 0
    assert "jupyterlab is not installed" in result.output


def test_setup_serve_fails_cleanly_without_collaboration_stack(
    runner,
    monkeypatch,
    tmp_path,
):
    def find_spec(name: str):
        if name == "jupyter_collaboration":
            return None
        return object()

    monkeypatch.setattr(cli_main.importlib.util, "find_spec", find_spec)

    result = runner.invoke(cli, ["setup", "serve", "--root", str(tmp_path)])

    assert result.exit_code != 0
    assert "jupyter-collaboration is not installed" in result.output


def test_setup_doctor_with_path_reports_runtime_and_kernel_details(runner, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)

    class FakeControl:
        def list_jobs(self) -> dict:
            return {"jobs": []}

        def get_notebook_document(self, notebook_id: str, *, content: bool = True) -> dict:
            assert notebook_id == "demo.ipynb"
            assert content is True
            return {
                "path": notebook_id,
                "content": {
                    "metadata": {
                        "kernelspec": {"display_name": "Subtext", "name": "subtext-kernel"}
                    }
                },
            }

        def get_runtime_status(self, notebook_id: str) -> dict:
            assert notebook_id == "demo.ipynb"
            return {"state": "live-detached", "kernel_name": "python3"}

        def get_kernelspec(self, kernel_name: str) -> dict:
            assert kernel_name == "subtext-kernel"
            return {"name": kernel_name, "spec": {"argv": ["/envs/subtext/bin/python", "-m"]}}

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["setup", "doctor", "--path", "demo.ipynb"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["path"] == "demo.ipynb"
    assert payload["notebook_kernelspec"] == "subtext-kernel"
    assert payload["runtime_state"] == "live-detached"
    assert payload["runtime_kernel_name"] == "python3"
    assert payload["kernelspec_launcher"] == "/envs/subtext/bin/python"
    assert payload["warnings"]


def test_job_await_timeout_surfaces_recovery_hint(runner, fake_notebooks, monkeypatch):
    monkeypatch.setattr(cli_main, "_stdout_is_tty", lambda: False)
    nb = fake_notebooks.setdefault("demo.ipynb", FakeNotebook("demo.ipynb"))
    nb.cells.insert_code("print(1)", id="code-1")
    job = FakeTimeoutJob(nb, ("code-1",))
    job.status = JobStatus.RUNNING

    class FakeControl:
        def get_job(self, job_id: str) -> FakeJob:
            assert job_id == "job-1"
            return job

    monkeypatch.setattr(cli_main, "_sdk_control", lambda ctx: FakeControl())

    result = runner.invoke(cli, ["job", "await", "job-1", "--timeout", "0.01"])

    assert result.exit_code != 0
    assert "last status: running" in result.output
    assert "hypernote job get job-1" in result.output
    assert "hypernote cat demo.ipynb --no-outputs" in result.output
