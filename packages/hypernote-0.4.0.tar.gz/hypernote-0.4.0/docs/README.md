# Hypernote Docs

Hypernote is a notebook-first execution layer on top of Jupyter shared documents.

Jupyter owns durable notebook contents and outputs. Hypernote owns an ephemeral control plane for runtimes, jobs, and attribution.

Start here:

- [Getting Started](getting-started.md)
- [CLI Reference](cli.md)
- [SDK Reference](sdk.md)
- [Runtime Model](runtime-model.md)
- [Browser Regression Spec](browser-regression-spec.md)

The common operator entrypoint is now `hypernote setup serve`, followed by
`hypernote setup doctor` when you need to confirm server and kernelspec state.
The bare `hypernote` command is the live workspace dashboard: it shows current
workspace state, active jobs, and next-step hints without needing a subcommand.

Public docs should describe shipped behavior only. Internal implementation notes belong in `dev/`.
Public docs should describe stable contracts and user-visible invariants, not just happy-path examples.
