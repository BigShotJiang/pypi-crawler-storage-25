from typing import Generic, Literal

from agentic_base.settings import FromConfigMixinSettings
from agentic_base.types import TCRetriever
from pydantic_settings import BaseSettings

from agentic_mcp.constants import TCEvidenceBuilder


class ServerSettings(BaseSettings):
    transport: Literal["stdio", "http", "sse", "streamable-http"]
    host: str
    port: int


class RunnerSettings(FromConfigMixinSettings):
    pass


class EvidenceBuilderSettings(FromConfigMixinSettings):
    pass


class RetrieverWrapperSettings(BaseSettings, Generic[TCRetriever]):
    engine: TCRetriever
    retrieve_limit: int
    final_limit: int


class MCPRunnerSettings(RunnerSettings, Generic[TCRetriever, TCEvidenceBuilder]):
    server: ServerSettings
    retriever: RetrieverWrapperSettings[TCRetriever]
    evidence: TCEvidenceBuilder
