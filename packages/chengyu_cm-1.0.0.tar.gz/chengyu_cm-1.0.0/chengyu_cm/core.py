"""
成语工具核心模块
提供成语判断和随机抽取功能，收录 29502 个四字成语。
"""

import json
import random
import os

# 加载成语数据（仅在首次导入时加载一次）
_data_path = os.path.join(os.path.dirname(__file__), 'data', 'idioms.json')
with open(_data_path, 'r', encoding='utf-8') as _f:
    _idiom_list = json.load(_f)
_idiom_set = set(_idiom_list)  # 用集合加速查找


def is_chengyu(text):
    """
    判断输入的字符串是否是四字成语。

    参数：
        text (str): 需要判断的字符串

    返回值：
        bool: 如果是成语返回 True，否则返回 False

    示例：
        >>> is_chengyu('守株待兔')
        True
        >>> is_chengyu('你好世界')
        False
    """
    return text in _idiom_set


def random_chengyu():
    """
    随机返回一个四字成语。

    返回值：
        str: 一个随机的四字成语

    示例：
        >>> cy = random_chengyu()
        >>> len(cy)
        4
    """
    return random.choice(_idiom_list)


def all_chengyu():
    """
    返回所有四字成语的列表（共 29502 个）。

    返回值：
        list: 包含所有四字成语的列表（已排序）

    示例：
        >>> cylist = all_chengyu()
        >>> len(cylist)
        29502
    """
    return _idiom_list.copy()


def count():
    """
    返回成语库中成语的总数。

    返回值：
        int: 成语总数

    示例：
        >>> count()
        29502
    """
    return len(_idiom_list)
