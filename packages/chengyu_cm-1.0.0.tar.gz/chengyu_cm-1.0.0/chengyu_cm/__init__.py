"""
chengyu_cm - 四字成语工具库
============================

一个简单好用的中文四字成语工具库，收录 29502 个四字成语。

主要功能：
    - is_chengyu(text): 判断是否是四字成语
    - random_chengyu(): 随机返回一个四字成语
    - all_chengyu(): 返回所有成语的列表
    - count(): 返回成语总数

使用示例：
    >>> from chengyu_cm import is_chengyu, random_chengyu
    >>> is_chengyu('守株待兔')
    True
    >>> random_chengyu()
    '画蛇添足'
"""

from .core import is_chengyu, random_chengyu, all_chengyu, count

__version__ = '1.0.0'
__all__ = ['is_chengyu', 'random_chengyu', 'all_chengyu', 'count']
