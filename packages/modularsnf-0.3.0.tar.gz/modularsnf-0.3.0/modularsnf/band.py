"""Band reduction transforms for Storjohann's block algorithms.

Provides helpers for triang and shift steps that manipulate banded blocks to
support Smith normal form reduction over modular rings.
"""

from typing import Tuple

import numpy as np

from modularsnf.echelon import lemma_3_1
from modularsnf.matrix import RingMatrix
from modularsnf.ring import RingZModN


def triang(B: RingMatrix, b: int) -> Tuple[RingMatrix, RingMatrix]:
    """
    Triangulates the top-right block of an upper-b-banded matrix.

    Args:
        B: An n1 x n1 upper-b-banded block with s1 = floor(b/2), s2 = b - 1,
            and n1 = s1 + s2.
        b: Bandwidth parameter; must satisfy b > 2.

    Returns:
        A tuple ``(B_prime, W)`` where ``W`` is the s2 x s2 local right
        transform such that ``B_prime = B * diag(I_{s1}, W)`` and the
        top-right s1 x s2 block of ``B_prime`` has the triangulated structure
        induced by ``lemma_3_1`` on ``B2^T``.

    Raises:
        ValueError: If ``b <= 2`` or ``B`` is not an n1 x n1 block with
            ``n1 = s1 + s2``.
    """
    ring: RingZModN = B.ring
    if b <= 2:
        raise ValueError("Triang requires b > 2")

    s1 = b // 2
    s2 = b - 1
    n1 = s1 + s2

    if B.nrows != B.ncols or B.nrows != n1:
        raise ValueError(
            f"Triang expects an n1 x n1 block with n1 = s1 + s2 = {n1}"
        )

    # Extract the top-right s1 x s2 block.
    row0, row1 = 0, s1
    col0, col1 = s1, s1 + s2
    B2 = B.submatrix(row0, row1, col0, col1)  # shape (s1, s2)

    # Transpose B2 to work with the s2 x s1 view.
    C = B2.transpose()

    # Apply Lemma 3.1 to obtain the left transform for C.
    U_left, T_ech, _ = lemma_3_1(C)  # U_left: s2 x s2, T_ech: s2 x s1

    # Use the transpose of the left transform as the local right transform.
    W = U_left.transpose()  # W: s2 x s2

    # Form the block-diagonal right transform.
    I_s1 = RingMatrix.identity(ring, s1)
    V_loc = RingMatrix.block_diag(I_s1, W)  # n1 x n1

    # Multiply by the block-diagonal transform.
    B_prime = B @ V_loc

    return B_prime, W


def shift(C: RingMatrix, b: int) -> Tuple[RingMatrix, RingMatrix, RingMatrix]:
    """
    Applies Storjohann's Lemma 7.4 (Shift) to a local block.

    Args:
        C: An n2 x n2 block with ``s2 = b - 1`` and ``n2 = 2 * s2`` that is
            conceptually upper b-banded.
        b: Bandwidth parameter; must satisfy b > 2.

    Returns:
        A tuple ``(C_prime, U_block, V_block)`` where ``U_block`` and
        ``V_block`` are the s2 x s2 local left and right transforms embedded as
        ``diag(U_block, I_{s2})`` and ``diag(I_{s2}, V_block)`` such that
        ``C_prime = diag(U_block, I_{s2}) * C * diag(I_{s2}, V_block)`` is the
        shifted block from Lemma 7.4.

    Raises:
        ValueError: If ``b <= 2`` or ``C`` is not an n2 x n2 block with
            ``n2 = 2 * (b - 1)``.

    This function does not attempt to check or enforce bandedness; that is left
    to higher-level tests.
    """
    ring: RingZModN = C.ring
    if b <= 2:
        raise ValueError("Shift requires b > 2")

    s2 = b - 1
    n2 = 2 * s2

    if C.nrows != C.ncols or C.nrows != n2:
        raise ValueError(
            f"Shift expects an n2 x n2 block with n2 = 2*(b-1) = {n2}, "
            f"got shape {C.shape}"
        )

    # Block partition where each block is s2 x s2.
    C1 = C.submatrix(0, s2, 0, s2)  # top-left
    C2 = C.submatrix(0, s2, s2, 2 * s2)  # top-right
    # C3 = C.submatrix(s2, 2 * s2, 0, s2)   # bottom-left (not used directly)
    # C4 = C.submatrix(s2, 2 * s2, s2, 2 * s2)

    # Apply Lemma 3.1 to triangularize C1 on the left.
    U1, T1, _ = lemma_3_1(C1)  # shapes: U1 s2×s2, T1 s2×s2

    # Triangularize U1 * C2 on the right via Lemma 3.1 applied to its transpose.
    C2_prime = U1 @ C2  # s2×s2

    C2_prime_T = C2_prime.transpose()  # s2×s2
    U2, T2, _ = lemma_3_1(C2_prime_T)  # U2 s2×s2, T2 s2×s2
    V_block = U2.transpose()  # s2×s2

    # Assemble the local transforms and apply them to C.
    I_s2 = RingMatrix.identity(ring, s2)

    U_full = RingMatrix.block_diag(U1, I_s2)  # n2×n2 = diag(U1, I_s2)
    V_full = RingMatrix.block_diag(I_s2, V_block)  # n2×n2 = diag(I_s2, V_block)

    C_prime = U_full @ C @ V_full

    return C_prime, U1, V_block


def band_reduction(
    A: RingMatrix,
    b: int,
    t: int = 0,
) -> Tuple[RingMatrix, RingMatrix, RingMatrix, int]:
    """
    Proposition 7.1 (band reduction) with transform tracking.

    Input:
        A : n x n upper-b-banded matrix (over a PIR)
        b : current upper bandwidth
        t : number of trailing zero columns (as in the paper, often 0 in practice)

    Output:
        A_reduced : n x n upper-b'-banded matrix, with b' = floor(b/2) + 1
        U_band    : n x n left transform
        V_band    : n x n right transform
        b_new     : new bandwidth (floor(b/2) + 1)

    Such that:
        A_reduced = U_band * A * V_band
    """
    ring = A.ring
    n = A.nrows
    if n != A.ncols:
        raise ValueError("band_reduction expects a square matrix.")

    # Already at or below 2-banded: nothing to do.
    if b <= 2:
        I = RingMatrix.identity(ring, n)
        return A.copy(), I, I, b

    # Storjohann parameters
    s1 = b // 2
    s2 = b - 1
    n1 = s1 + s2  # size of the "triang" block
    n2 = 2 * s2  # size of each "shift" block

    # Padding size in both directions (as in the paper / your original code)
    pad = 2 * b - t
    N_big = n + pad

    # Build padded matrix B with A in the top-left n x n principal block
    B_arr = np.zeros((N_big, N_big), dtype=int)
    B_arr[:n, :n] = A.data
    B = RingMatrix._from_ndarray(ring, B_arr)

    # Global transforms on the padded system
    U_big = RingMatrix.identity(ring, N_big)
    V_big = RingMatrix.identity(ring, N_big)

    # Number of outer iterations (as in the paper)
    num_i = max(0, (n - t + s1 - 1) // s1)

    for i in range(num_i):
        top = i * s1
        if top + n1 > N_big:
            break  # safety guard

        # --- Step: triang on n1 x n1 principal block starting at (top, top)
        B_block = B.submatrix(top, top + n1, top, top + n1)
        # triang returns B_block_prime, W with B_block_prime = B_block * diag(I_{s1}, W)
        B_block_prime, W = triang(B_block, b)

        # V_loc = diag(I_{s1}, W), so only W at position (top+s1, top+s1)
        # differs from identity.  Apply as sparse block update.
        w_start = top + s1
        B.right_apply_block(W.data, w_start)
        V_big.right_apply_block(W.data, w_start)

        # --- Inner "shift" blocks
        numer = n - t - (i + 1) * s1
        if numer <= 0:
            continue

        num_j = max(0, (numer + s2 - 1) // s2)

        for j in range(num_j):
            offset = (i + 1) * s1 + j * s2
            if offset + n2 > N_big:
                break  # safety guard

            # Take current 2*s2 x 2*s2 block from B
            C_block = B.submatrix(offset, offset + n2, offset, offset + n2)

            # shift returns C_prime, U_block, V_block with:
            # C_prime = diag(U_block, I_{s2}) * C_block * diag(I_{s2}, V_block)
            C_prime, U_block, V_block = shift(C_block, b)

            # U_loc = diag(U_block, I_{s2}): non-identity part is U_block
            # at (offset, offset).
            # V_loc2 = diag(I_{s2}, V_block): non-identity part is V_block
            # at (offset+s2, offset+s2).
            # Apply as sparse block updates instead of full N_big matmuls.
            B.left_apply_block(U_block.data, offset)
            B.right_apply_block(V_block.data, offset + s2)
            U_big.left_apply_block(U_block.data, offset)
            V_big.right_apply_block(V_block.data, offset + s2)

    # Extract the reduced n x n principal block and the corresponding transforms
    A_reduced = B.submatrix(0, n, 0, n)
    U_band = U_big.submatrix(0, n, 0, n)
    V_band = V_big.submatrix(0, n, 0, n)

    b_new = (b // 2) + 1
    return A_reduced, U_band, V_band, b_new


def compute_upper_bandwidth(M: RingMatrix) -> int:
    """
    Compute the upper bandwidth 'b' in the sense:
        b = max{ j - i | M[i,j] ≠ 0, j ≥ i } + 1,
    or 0 if the matrix is identically zero.
    """
    nrows, ncols = M.shape
    N = M.ring.N
    nonzero = M.data % N != 0
    rows, cols = np.nonzero(nonzero)
    if len(rows) == 0:
        return 0
    offsets = cols - rows
    upper_offsets = offsets[offsets >= 0]
    if len(upper_offsets) == 0:
        return 0
    return int(upper_offsets.max()) + 1


def project_to_upper_bandwidth(M: RingMatrix, b: int) -> RingMatrix:
    """
    Zero out entries outside the upper bandwidth 'b':
        keep entries with 0 ≤ j - i < b,
        zero everything else.
    """
    nrows, ncols = M.shape
    rows, cols = np.ogrid[:nrows, :ncols]
    mask = (cols - rows >= 0) & (cols - rows < b)
    arr = np.where(mask, M.data, 0)
    return RingMatrix._from_ndarray(M.ring, arr)
