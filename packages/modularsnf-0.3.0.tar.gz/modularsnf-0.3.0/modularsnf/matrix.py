"""Ring-aware matrix utilities for modular Smith normal form routines.

Defines the ``RingMatrix`` dataclass and helpers that normalize data, manage
block operations, and align shapes for modular arithmetic workflows.
"""

from dataclasses import InitVar, dataclass, field
from typing import List, Tuple

import numpy as np

from modularsnf.ring import INT64_MAX, INT64_MIN, RingZModN, _coerce_int64


def _coerce_object_array_to_int64(data: np.ndarray) -> np.ndarray:
    """Convert an object array to ``np.int64`` with explicit range checks."""
    flat = np.empty(data.size, dtype=np.int64)
    for idx, value in enumerate(data.flat):
        flat[idx] = _coerce_int64("matrix entry", value)
    return flat.reshape(data.shape)


def _normalize_ndarray(data: np.ndarray) -> np.ndarray:
    """Normalize ndarray inputs to a 2-D ``np.int64`` array."""
    arr = np.array(data, copy=True)
    if arr.size == 0:
        return np.zeros((0, 0), dtype=np.int64)
    if arr.ndim == 1:
        arr = arr.reshape(1, arr.size)
    if arr.ndim != 2:
        raise ValueError("Matrix data must be 2-dimensional")

    if arr.dtype == object:
        return _coerce_object_array_to_int64(arr)

    if np.issubdtype(arr.dtype, np.unsignedinteger):
        max_val = int(arr.max())
        if max_val > INT64_MAX:
            raise OverflowError(
                "matrix entries must fit in a signed 64-bit integer"
            )
        return arr.astype(np.int64, copy=False)

    if np.issubdtype(arr.dtype, np.signedinteger):
        min_val = int(arr.min())
        max_val = int(arr.max())
        if min_val < INT64_MIN or max_val > INT64_MAX:
            raise OverflowError(
                "matrix entries must fit in a signed 64-bit integer"
            )
        return arr.astype(np.int64, copy=False)

    raise TypeError(
        "Matrix data must contain integers representable as signed 64-bit "
        "values"
    )


def _normalize_matrix_data(
    data: list[list[int]] | np.ndarray,
) -> np.ndarray:
    """
    Ensure matrix-like input is a 2D ``np.ndarray`` of ints.

    Allows callers to pass either a list-of-lists or an ndarray. Empty inputs
    become an explicit (0, 0) array so downstream shape logic remains simple.
    """
    if isinstance(data, np.ndarray):
        return _normalize_ndarray(data)

    rows = [list(row) for row in data]
    if not rows:
        return np.zeros((0, 0), dtype=np.int64)

    ncols = len(rows[0])
    for row in rows:
        if len(row) != ncols:
            raise ValueError("All rows must have the same length")

    arr = np.empty((len(rows), ncols), dtype=np.int64)
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            arr[i, j] = _coerce_int64("matrix entry", value)
    return arr


def _is_within_modulus(data: np.ndarray, N: int) -> bool:
    """Return True when ``data`` is provably in ``[0, N)``.

    Avoids expensive copies by only skipping the modulus reduction when values
    are demonstrably safe.
    """
    if data.size == 0:
        return True
    if not np.issubdtype(data.dtype, np.integer):
        return False
    try:
        min_val = data.min()
        max_val = data.max()
    except (OverflowError, TypeError, ValueError):
        return False
    return 0 <= min_val and max_val < N


def _to_list_if_array(
    data: list[list[int]] | np.ndarray,
) -> list[list[int]]:
    """Return nested Python lists, preserving list inputs for callers that expect them."""
    if isinstance(data, np.ndarray):
        return data.tolist()
    return data


@dataclass
class RingMatrix:
    ring: RingZModN
    _data_init: InitVar[list[list[int]] | np.ndarray]
    data: np.ndarray = field(init=False)
    _assume_reduced: bool = field(default=False, init=True, repr=False)

    def __post_init__(self, _data_init: list[list[int]] | np.ndarray) -> None:
        self.data = _normalize_matrix_data(_data_init)
        N = self.ring.N

        # Fast path: internal callers that explicitly guarantee the array is
        # already reduced, or data we can verify is inside [0, N).
        if not (self._assume_reduced or _is_within_modulus(self.data, N)):
            self.data %= N

    @property
    def nrows(self) -> int:
        return self.data.shape[0]

    @property
    def ncols(self) -> int:
        return self.data.shape[1] if self.data.size else 0

    @property
    def shape(self) -> Tuple[int, int]:
        return self.nrows, self.ncols

    @classmethod
    def from_rows(cls, ring: RingZModN, rows: List[List[int]]) -> "RingMatrix":
        return cls(ring, rows)

    @classmethod
    def identity(cls, ring: RingZModN, n: int) -> "RingMatrix":
        return cls(ring, np.eye(n, dtype=np.int64))

    @classmethod
    def diagonal(cls, ring: RingZModN, diag: List[int]) -> "RingMatrix":
        n = len(diag)
        rows = np.zeros((n, n), dtype=np.int64)
        for i, v in enumerate(diag):
            rows[i, i] = v
        return cls(ring, rows)

    @classmethod
    def _from_ndarray(cls, ring: RingZModN, data: np.ndarray) -> "RingMatrix":
        """Internal fast constructor for pre-normalized arrays.

        Callers must ensure ``data`` is already 2-D, reduced modulo ``ring.N``,
        and uses an appropriate dtype. No copying or normalization is
        performed.
        """
        if data.ndim != 2:
            raise ValueError("Matrix data must be 2-dimensional")

        obj = cls.__new__(cls)
        obj.ring = ring
        obj.data = data
        return obj

    @classmethod
    def block_diag(cls, A: "RingMatrix", B: "RingMatrix") -> "RingMatrix":
        """
        Block-diagonal composition:
            [ A  0 ]
            [ 0  B ]

        A and B may be rectangular, but must share the same ring.
        """
        if A.ring is not B.ring:
            raise ValueError("Cannot form block diagonal over different rings")
        ring = A.ring
        a_rows, a_cols = A.shape
        b_rows, b_cols = B.shape

        total_rows = a_rows + b_rows
        total_cols = a_cols + b_cols

        data = np.zeros((total_rows, total_cols), dtype=np.int64)

        # top-left: A
        data[:a_rows, :a_cols] = A.data

        # bottom-right: B
        data[a_rows:, a_cols:] = B.data

        return cls._from_ndarray(ring, data)

    def copy(self) -> "RingMatrix":
        return RingMatrix._from_ndarray(self.ring, np.copy(self.data))

    def transpose(self) -> "RingMatrix":
        return RingMatrix._from_ndarray(self.ring, np.transpose(self.data))

    def __matmul__(self, other: "RingMatrix") -> "RingMatrix":
        if self.ring is not other.ring:
            raise ValueError("Cannot multiply matrices over different rings")

        cA = self.ncols
        rB = other.nrows

        if cA != rB:
            raise ValueError(f"Dimension mismatch: {cA} != {rB}")

        ring = self.ring
        N = ring.N

        A = self.data
        B = other.data

        C = (A @ B) % N

        return RingMatrix._from_ndarray(ring, C)

    def pad_to(self, target_rows: int, target_cols: int) -> "RingMatrix":
        rows, cols = self.shape
        if rows == target_rows and cols == target_cols:
            return self.copy()
        N = self.ring.N
        new = np.zeros((target_rows, target_cols), dtype=np.int64)
        new[:rows, :cols] = self.data[:rows, :cols] % N
        return RingMatrix._from_ndarray(self.ring, new)

    def pad_to_square_power2(self) -> "RingMatrix":
        n = max(self.nrows, self.ncols)
        if n <= 0:
            return self.copy()
        size = 1 << (n - 1).bit_length()
        return self.pad_to(size, size)

    def submatrix(
        self, row_start: int, row_end: int, col_start: int, col_end: int
    ) -> "RingMatrix":
        """
        Return a view copy of rows [row_start:row_end) and
        cols [col_start:col_end).
        """
        rows = self.data[row_start:row_end, col_start:col_end]
        return RingMatrix._from_ndarray(self.ring, np.copy(rows))

    def write_block(
        self, row_start: int, col_start: int, block: "RingMatrix"
    ) -> None:
        """
        Overwrite a sub-block of self starting at (row_start, col_start)
        with the contents of 'block'. Rings must match.
        """
        if self.ring is not block.ring:
            raise ValueError("Cannot write block with different ring")
        b_rows, b_cols = block.shape
        self.data[
            row_start : row_start + b_rows, col_start : col_start + b_cols
        ] = block.data

    def apply_row_2x2(
        self, r: int, i: int, s: int, t: int, u: int, v: int
    ) -> None:
        """In-place:  [row_r; row_i] <- [s t; u v] [row_r; row_i]."""
        N = self.ring.N
        rows = self.data[[r, i], :]
        transform = np.array([[s, t], [u, v]], dtype=int) % N
        new_rows = (transform @ rows) % N
        self.data[r, :] = new_rows[0]
        self.data[i, :] = new_rows[1]

    def left_apply_block(self, block: np.ndarray, start: int) -> None:
        """In-place ``self <- M @ self`` where ``M = I`` with *block* at ``(start, start)``.

        Only rows ``[start:start+k]`` are modified (``k = block.shape[0]``).
        """
        N = self.ring.N
        k = block.shape[0]
        rows = self.data[start : start + k, :].copy()
        self.data[start : start + k, :] = (block @ rows) % N

    def right_apply_block(self, block: np.ndarray, start: int) -> None:
        """In-place ``self <- self @ M`` where ``M = I`` with *block* at ``(start, start)``.

        Only columns ``[start:start+k]`` are modified.
        """
        N = self.ring.N
        k = block.shape[0]
        cols = self.data[:, start : start + k].copy()
        self.data[:, start : start + k] = (cols @ block) % N

    def left_apply_block_pair(
        self,
        u00: np.ndarray,
        u01: np.ndarray,
        u10: np.ndarray,
        u11: np.ndarray,
        start1: int,
        start2: int,
    ) -> None:
        """In-place ``self <- M @ self`` where ``M = I`` with a 2x2 block arrangement.

        ``M[start1:start1+t, start1:start1+t] = u00``, etc.
        Only rows ``[start1:start1+t]`` and ``[start2:start2+t]`` change.
        """
        N = self.ring.N
        t = u00.shape[0]
        r1 = self.data[start1 : start1 + t, :].copy()
        r2 = self.data[start2 : start2 + t, :].copy()
        self.data[start1 : start1 + t, :] = (u00 @ r1 + u01 @ r2) % N
        self.data[start2 : start2 + t, :] = (u10 @ r1 + u11 @ r2) % N

    def right_apply_block_pair(
        self,
        v00: np.ndarray,
        v01: np.ndarray,
        v10: np.ndarray,
        v11: np.ndarray,
        start1: int,
        start2: int,
    ) -> None:
        """In-place ``self <- self @ M`` where ``M = I`` with a 2x2 block arrangement.

        Only columns ``[start1:start1+t]`` and ``[start2:start2+t]`` change.
        """
        N = self.ring.N
        t = v00.shape[0]
        c1 = self.data[:, start1 : start1 + t].copy()
        c2 = self.data[:, start2 : start2 + t].copy()
        self.data[:, start1 : start1 + t] = (c1 @ v00 + c2 @ v10) % N
        self.data[:, start2 : start2 + t] = (c1 @ v01 + c2 @ v11) % N

    def to_sympy(self):
        import sympy as sp

        return sp.Matrix(_to_list_if_array(self.data))

    def pprint(self):
        from sympy import pprint

        pprint(self.to_sympy())
