"""datom: Version-controlled data management for reproducible workflows."""

__version__ = "0.0.1"