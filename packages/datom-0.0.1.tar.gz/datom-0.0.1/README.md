# datom

Version-controlled data management for reproducible clinical and scientific workflows.

datom provides content-addressed, versioned storage for tabular data with 
SHA-based identity, metadata tracking, lineage, and git integration.

**This package is under active development.** The R implementation is available 
at [github.com/amashadihossein/datom](https://github.com/amashadihossein/datom). 
Python implementation coming soon.