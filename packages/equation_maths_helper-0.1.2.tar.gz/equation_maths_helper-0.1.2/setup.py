from setuptools import setup, find_packages


def readme():
  with open('README.md', 'r') as f:
    return f.read()


setup(
  name='equation_maths_helper',
  version='0.1.2',
  author='Danil1310',
  author_email='zdan131011@gmail.com',
  description= "ENG: A class that allows you to solve quadratic and linear equations. | RU: Класс, позволяющий решать квадратные и линейные уравнения.",
  long_description=readme(),
  long_description_content_type='text/markdown',
  url='https://github.com/Danil1310/Equation_library.git',
  packages=find_packages(),
  install_requires=['requests>=2.25.1'],
  classifiers=[
    'Programming Language :: Python :: 3.11',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent'
  ],
  keywords='equation ',
  project_urls={
    'GitHub': 'https://github.com/Danil1310/Equation_library.git'
  },
  python_requires='>=3.6'
)