<?php

$CONFIG = [
    'filesystem_check_changes' => 1,
    'filelocking.enabled' => false,
    'trashbin_retention_obligation' => 'auto, 1',
];
