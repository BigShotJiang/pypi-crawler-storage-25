from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        # Synapse container runs as uid 991 (synapse user)
        return {
            "children": [
                {
                    "name": "synapse",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "children": [
                        {
                            "name": "data",
                            "type": DiskItemType.DIRECTORY,
                            "should_exist": True,
                            "mode": {
                                "owner": "991:991",
                                "permissions": "755",
                                "recursive": True,
                            },
                        }
                    ],
                }
            ]
        }
