from __future__ import annotations

from wexample_wex_addon_services_collab.services_collab_addon_manager import (
    ServicesCollabAddonManager,
)

__all__ = ["ServicesCollabAddonManager"]
