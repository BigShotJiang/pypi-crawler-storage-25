from __future__ import annotations

from typing import Any

from wexample_helpers.decorator.base_class import base_class
from wexample_wex_core.common.abstract_addon_manager import AbstractAddonManager


@base_class
class ServicesCollabAddonManager(AbstractAddonManager):
    @classmethod
    def get_package_module(cls) -> Any:
        import wexample_wex_addon_services_collab

        return wexample_wex_addon_services_collab
