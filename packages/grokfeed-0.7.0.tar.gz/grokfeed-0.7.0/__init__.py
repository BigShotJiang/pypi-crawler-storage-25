import warnings
warnings.warn(
    "grokfeed has been renamed to devskim. Run: pip install devskim",
    DeprecationWarning,
    stacklevel=2,
)
