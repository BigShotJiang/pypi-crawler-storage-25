# Installation

## Quick Install (recommended)

```bash
# Clone the repository
git clone https://github.com/preethamak/vyper.git
cd vyper

# Install with uv (fastest)
uv sync

# Verify installation
vyper-guard --version
```

## Install with pip

```bash
# From PyPI
pip install vyper-guard

# From local source checkout
pip install -e .
```

## Optional Features

Vyper Guard is modular. The core static analyzer has **zero heavy dependencies** — it works without the Vyper compiler.

| Feature | Install Command | What it adds |
|---------|----------------|--------------|
| **Core** | `pip install -e .` | Static analysis, 12 detectors, CLI, reporting |
| **Live Monitoring** | `pip install -e ".[monitor]"` | Real-time contract monitoring via RPC (requires `web3`) |
| **All Features** | `pip install -e ".[all]"` | Everything above + GitHub integration |

## Docker

```bash
# Build the image
docker build -t vyper-guard .

# Scan a contract (mount your project directory)
docker run --rm -v $(pwd):/code vyper-guard analyze /code/vault.vy

# With auto-fix
docker run --rm -v $(pwd):/code vyper-guard analyze /code/vault.vy --fix
```

## Development Setup

```bash
# Clone and install in dev mode
git clone https://github.com/preethamak/vyper.git
cd vyper
uv sync --dev

# Run tests
uv run pytest tests/ -v

# Run linter
uv run ruff check src/ tests/

# Install pre-commit hooks
uv run pre-commit install
```

## Publishing to PyPI (Maintainers)

```bash
# 1) bump versions in:
#    pyproject.toml
#    src/guardian/__init__.py

# 2) clean + build
rm -rf dist build
python -m build
python -m twine check dist/*

# 3) upload only the target version artifacts
export TWINE_USERNAME=__token__
export TWINE_PASSWORD='pypi-<YOUR_FULL_TOKEN>'
python -m twine upload \
  dist/vyper_guard-<VERSION>-py3-none-any.whl \
  dist/vyper_guard-<VERSION>.tar.gz
```

Notes:

- Prefer explicit filenames over `dist/*` to avoid uploading stale artifacts.
- A version can be published only once on PyPI.
- Keep token secret and rotate if exposed.

## Requirements

- **Python 3.10+** (3.11 or 3.12 recommended)
- No Vyper compiler needed for static analysis
- `web3` package needed only for live monitoring

## CI/CD Integration

### GitHub Actions

Add to your `.github/workflows/security.yml`:

```yaml
name: Vyper Security
on: [push, pull_request]

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v4
      - run: uv pip install vyper-guard
      - run: |
          find contracts -name '*.vy' -print0 | \
          xargs -0 -I{} vyper-guard analyze "{}" --ci --severity-threshold HIGH
```

### Pre-commit Hook

Add to your project's `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: https://github.com/preethamak/vyper
    rev: v0.1.0
    hooks:
      - id: vyper-guard
```

Then: `pre-commit install`

Every commit touching `.vy` files will be scanned automatically.
