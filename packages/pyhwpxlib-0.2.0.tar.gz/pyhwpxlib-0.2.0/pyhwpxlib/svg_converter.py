"""Convert HWPX drawing objects and tables to SVG.

This module provides functions to render HWPX shapes (rect, ellipse, line, etc.)
and tables as SVG elements.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import List, Optional, Tuple, Dict, Any


def hwpunit_to_px(unit: int) -> float:
    """Convert HWPUNIT (1/7200 inch) to pixels (assuming 96 DPI).
    1 inch = 7200 HWPUNIT = 96 px
    1 px = 7200 / 96 = 75 HWPUNIT
    """
    return unit / 75.0


class SVGConverter:
    """Converts HWPX elements to SVG string fragments."""

    def __init__(self, scale: float = 1.0):
        self.scale = scale
        self.parts: List[str] = []

    def convert_shape(self, shape_elem: ET.Element) -> str:
        """Convert a single HWPX shape element to SVG."""
        tag = shape_elem.tag.split("}")[-1]
        
        # Common attributes
        sz = shape_elem.find(".//{http://www.hancom.co.kr/hwpml/2011/paragraph}sz")
        width = int(sz.get("width", "0")) if sz is not None else 0
        height = int(sz.get("height", "0")) if sz is not None else 0
        
        w_px = hwpunit_to_px(width) * self.scale
        h_px = hwpunit_to_px(height) * self.scale
        
        # Line/Fill properties
        line_shape = shape_elem.find(".//{http://www.hancom.co.kr/hwpml/2011/paragraph}lineShape")
        stroke_color = line_shape.get("color", "#000000") if line_shape is not None else "#000000"
        stroke_width = hwpunit_to_px(int(line_shape.get("width", "283"))) if line_shape is not None else 1.0
        
        fill_brush = shape_elem.find(".//{http://www.hancom.co.kr/hwpml/2011/core}winBrush")
        fill_color = fill_brush.get("faceColor", "none") if fill_brush is not None else "none"
        if fill_color.lower() == "none":
            fill_color = "none"

        if tag == "rect":
            return f'<rect width="{w_px:.2f}" height="{h_px:.2f}" fill="{fill_color}" stroke="{stroke_color}" stroke-width="{stroke_width:.2f}" />'
        
        elif tag == "ellipse":
            return f'<ellipse cx="{w_px/2:.2f}" cy="{h_px/2:.2f}" rx="{w_px/2:.2f}" ry="{h_px/2:.2f}" fill="{fill_color}" stroke="{stroke_color}" stroke-width="{stroke_width:.2f}" />'
        
        elif tag == "line":
            start_pt = shape_elem.find(".//{http://www.hancom.co.kr/hwpml/2011/core}startPt")
            end_pt = shape_elem.find(".//{http://www.hancom.co.kr/hwpml/2011/core}endPt")
            x1 = hwpunit_to_px(int(start_pt.get("x", "0"))) if start_pt is not None else 0
            y1 = hwpunit_to_px(int(start_pt.get("y", "0"))) if start_pt is not None else 0
            x2 = hwpunit_to_px(int(end_pt.get("x", "0"))) if end_pt is not None else w_px
            y2 = hwpunit_to_px(int(end_pt.get("y", "0"))) if end_pt is not None else h_px
            return f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" stroke="{stroke_color}" stroke-width="{stroke_width:.2f}" />'
        
        return f"<!-- Unsupported shape: {tag} -->"

    def render_document_to_svg(self, section_roots: List[ET.Element]) -> str:
        """Render all shapes in sections to a single SVG."""
        shapes_svg = []
        max_w = 0.0
        max_h = 0.0
        y_offset = 0.0
        
        HP_NS = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"
        
        for root in section_roots:
            for shape_tag in ["rect", "ellipse", "line", "pic", "tbl"]:
                for elem in root.findall(f".//{HP_NS}{shape_tag}"):
                    svg_frag = self.convert_shape(elem)
                    # Simple vertical stacking for now
                    sz = elem.find(f".//{HP_NS}sz")
                    h = hwpunit_to_px(int(sz.get("height", "3600"))) if sz is not None else 50.0
                    w = hwpunit_to_px(int(sz.get("width", "7200"))) if sz is not None else 100.0
                    
                    wrapped = f'<g transform="translate(0, {y_offset:.2f})">{svg_frag}</g>'
                    shapes_svg.append(wrapped)
                    
                    y_offset += h + 10.0
                    max_w = max(max_w, w)
        
        max_h = y_offset
        
        header = f'<svg width="{max_w:.2f}" height="{max_h:.2f}" xmlns="http://www.w3.org/2000/svg">'
        footer = '</svg>'
        
        return header + "\n" + "\n".join(shapes_svg) + "\n" + footer

def extract_svg(hwpx_path: str) -> str:
    """Extract all shapes from HWPX as a combined SVG."""
    import zipfile
    import re
    
    section_roots = []
    _SECTION_RE = re.compile(r"^Contents/section\d+\.xml$", re.IGNORECASE)
    
    with zipfile.ZipFile(hwpx_path, "r") as zf:
        names = zf.namelist()
        section_names = sorted(n for n in names if _SECTION_RE.match(n))
        
        for sec_name in section_names:
            raw = zf.read(sec_name)
            # Simple namespace normalization if needed
            root = ET.fromstring(raw)
            section_roots.append(root)
            
    converter = SVGConverter()
    return converter.render_document_to_svg(section_roots)
