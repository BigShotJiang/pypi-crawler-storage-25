# Contributing to GeoRankPy

Thank you for your interest in contributing!

## Setup

```bash
git clone https://github.com/Hero777-tech/georankpy
cd georankpy
pip install -e ".[dev]"
```

## Running tests

```bash
pytest tests/ -v
```

## Code style

```bash
ruff check georankpy/
mypy georankpy/
```

## Submitting a PR

1. Fork the repo
2. Create a branch: `git checkout -b feature/my-feature`
3. Write tests for your changes
4. Ensure all tests pass: `pytest tests/ -v`
5. Open a Pull Request against `main`

## Ideas for contributions

- New GEO scoring dimensions
- Async crawler support
- More entity types
- Report themes (dark mode HTML)
- Benchmark datasets
- Language support (non-English analysis)
