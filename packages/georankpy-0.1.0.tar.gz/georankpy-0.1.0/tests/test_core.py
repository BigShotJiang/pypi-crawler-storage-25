"""
Tests for GeoRankPy core modules.

Run with:  pytest tests/ -v
"""

import pytest
from georankpy.core.models import (
    AuditResult,
    CrawlResult,
    GeoIssue,
    GeoScore,
    IssueLevel,
    MetadataResult,
    ScoreBand,
    ScoreBreakdown,
    SemanticChunk,
    SemanticReport,
)


# ---------------------------------------------------------------------------
# Model tests
# ---------------------------------------------------------------------------

class TestScoreBreakdown:
    def test_total_sums_correctly(self):
        bd = ScoreBreakdown(
            semantic_clarity=20.0,
            metadata_completeness=18.0,
            chunk_retrievability=15.0,
            schema_quality=10.0,
            entity_richness=8.0,
            llms_txt_quality=7.0,
        )
        assert bd.total == pytest.approx(78.0)

    def test_total_zero_by_default(self):
        bd = ScoreBreakdown()
        assert bd.total == 0.0


class TestGeoScore:
    def test_band_excellent(self):
        assert GeoScore.band_for(90) == ScoreBand.EXCELLENT

    def test_band_good(self):
        assert GeoScore.band_for(75) == ScoreBand.GOOD

    def test_band_fair(self):
        assert GeoScore.band_for(50) == ScoreBand.FAIR

    def test_band_poor(self):
        assert GeoScore.band_for(20) == ScoreBand.POOR

    def test_band_boundary_86(self):
        assert GeoScore.band_for(86) == ScoreBand.EXCELLENT

    def test_band_boundary_68(self):
        assert GeoScore.band_for(68) == ScoreBand.GOOD


class TestCrawlResult:
    def test_default_no_llms_txt(self):
        cr = CrawlResult(url="https://example.com", status_code=200)
        assert cr.has_llms_txt is False
        assert cr.llms_txt_content == ""

    def test_error_result(self):
        cr = CrawlResult(url="https://example.com", status_code=0, error="timeout")
        assert cr.error == "timeout"


class TestSemanticReport:
    def test_overall_score_weighted(self):
        sr = SemanticReport(
            url="https://example.com",
            heading_structure_score=1.0,
            paragraph_clarity_score=1.0,
            semantic_density_score=1.0,
            chunk_quality_score=1.0,
            readability_score=1.0,
        )
        assert sr.overall_score == pytest.approx(1.0)

    def test_overall_score_zero(self):
        sr = SemanticReport(url="https://example.com")
        assert sr.overall_score == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# Semantic Analyzer tests (no network)
# ---------------------------------------------------------------------------

class TestSemanticAnalyzer:
    def _make_crawl(self, text: str, headings=None) -> CrawlResult:
        return CrawlResult(
            url="https://example.com",
            status_code=200,
            text=text,
            headings=headings or [],
        )

    def test_no_headings_gives_critical_issue(self):
        from georankpy.analyzer.semantic import SemanticAnalyzer
        analyzer = SemanticAnalyzer()
        crawl = self._make_crawl("Some text without any headings.", headings=[])
        report = analyzer.analyze(crawl)
        codes = [i.code for i in report.issues]
        assert "NO_HEADINGS" in codes

    def test_single_h1_no_issue(self):
        from georankpy.analyzer.semantic import SemanticAnalyzer
        analyzer = SemanticAnalyzer()
        crawl = self._make_crawl(
            "Introduction content here.",
            headings=[{"level": "h1", "text": "Introduction"}],
        )
        report = analyzer.analyze(crawl)
        codes = [i.code for i in report.issues]
        assert "MISSING_H1" not in codes
        assert "MULTIPLE_H1" not in codes

    def test_multiple_h1_gives_warning(self):
        from georankpy.analyzer.semantic import SemanticAnalyzer
        analyzer = SemanticAnalyzer()
        crawl = self._make_crawl(
            "Text",
            headings=[
                {"level": "h1", "text": "Title One"},
                {"level": "h1", "text": "Title Two"},
            ],
        )
        report = analyzer.analyze(crawl)
        codes = [i.code for i in report.issues]
        assert "MULTIPLE_H1" in codes

    def test_chunk_building_returns_chunks(self):
        from georankpy.analyzer.semantic import SemanticAnalyzer
        analyzer = SemanticAnalyzer()
        text = (
            "Introduction\n"
            "This is a short intro paragraph.\n\n"
            "Details\n"
            "These are the details of the topic. " * 5
        )
        crawl = self._make_crawl(
            text,
            headings=[
                {"level": "h1", "text": "Introduction"},
                {"level": "h2", "text": "Details"},
            ],
        )
        report = analyzer.analyze(crawl)
        assert len(report.chunks) >= 1


# ---------------------------------------------------------------------------
# Entity Extractor tests (no network, no spaCy)
# ---------------------------------------------------------------------------

class TestEntityExtractor:
    def _make_crawl(self, text: str) -> CrawlResult:
        return CrawlResult(url="https://example.com", status_code=200, text=text)

    def test_detects_technology_entities(self):
        from georankpy.entities.extractor import EntityExtractor
        extractor = EntityExtractor(use_nlp=False)
        crawl = self._make_crawl(
            "We use Python and PyTorch for our machine learning pipeline. "
            "The API is built with FastAPI and deployed on AWS."
        )
        entities = extractor.extract(crawl)
        detected = {e.text.lower() for e in entities}
        assert "python" in detected or "pytorch" in detected

    def test_empty_text_returns_empty(self):
        from georankpy.entities.extractor import EntityExtractor
        extractor = EntityExtractor(use_nlp=False)
        crawl = self._make_crawl("")
        entities = extractor.extract(crawl)
        assert isinstance(entities, list)


# ---------------------------------------------------------------------------
# llms.txt Generator tests (no network)
# ---------------------------------------------------------------------------

class TestLlmsTxtGenerator:
    def _make_crawl(self, title="Test Site", description="A test site.") -> CrawlResult:
        return CrawlResult(
            url="https://example.com",
            status_code=200,
            text="Some page content here with multiple words to fill things out.",
            headings=[
                {"level": "h1", "text": "Welcome"},
                {"level": "h2", "text": "Features"},
                {"level": "h2", "text": "About"},
            ],
            metadata=MetadataResult(title=title, description=description),
        )

    def test_generates_valid_content(self):
        from georankpy.generators.llms_txt import LlmsTxtGenerator
        gen = LlmsTxtGenerator()
        result = gen.generate("https://example.com", self._make_crawl())
        assert result.content.startswith("#")
        assert ">" in result.content  # description line

    def test_contains_site_name(self):
        from georankpy.generators.llms_txt import LlmsTxtGenerator
        gen = LlmsTxtGenerator()
        result = gen.generate("https://example.com", self._make_crawl(title="My Awesome Site"))
        assert "My Awesome Site" in result.content

    def test_word_count_positive(self):
        from georankpy.generators.llms_txt import LlmsTxtGenerator
        gen = LlmsTxtGenerator()
        result = gen.generate("https://example.com", self._make_crawl())
        assert result.word_count > 0


# ---------------------------------------------------------------------------
# Scorer tests (no network)
# ---------------------------------------------------------------------------

class TestGeoScorer:
    def _make_inputs(self):
        crawl = CrawlResult(
            url="https://example.com",
            status_code=200,
            text="Content",
            metadata=MetadataResult(
                title="Test",
                description="A test page with good description text here.",
                og_title="Test OG",
                og_description="Test OG description",
                schema_types=["Article", "FAQPage"],
                has_faq_schema=True,
                has_article_schema=True,
            ),
            has_llms_txt=True,
            llms_txt_content="# Test\n\n> A test site.\n\n## Pages\n- [Home](https://example.com)",
        )
        semantic = SemanticReport(
            url="https://example.com",
            heading_structure_score=0.9,
            paragraph_clarity_score=0.8,
            semantic_density_score=0.7,
            chunk_quality_score=0.8,
            readability_score=0.7,
            chunks=[SemanticChunk(index=0, text="x", word_count=80, retrievability_score=0.85)],
        )
        return crawl, semantic

    def test_score_in_range(self):
        from georankpy.scoring.scorer import GeoScorer
        crawl, semantic = self._make_inputs()
        scorer = GeoScorer()
        result = scorer.score(crawl, semantic, [])
        assert 0 <= result.geo_score <= 100

    def test_good_metadata_raises_score(self):
        from georankpy.scoring.scorer import GeoScorer
        crawl, semantic = self._make_inputs()
        scorer = GeoScorer()
        result = scorer.score(crawl, semantic, [])
        assert result.geo_score > 50  # well-configured page should score well

    def test_missing_llms_txt_creates_issue(self):
        from georankpy.scoring.scorer import GeoScorer
        crawl, semantic = self._make_inputs()
        crawl.has_llms_txt = False
        crawl.llms_txt_content = ""
        scorer = GeoScorer()
        result = scorer.score(crawl, semantic, [])
        codes = [i.code for i in result.issues]
        assert "MISSING_LLMS_TXT" in codes
