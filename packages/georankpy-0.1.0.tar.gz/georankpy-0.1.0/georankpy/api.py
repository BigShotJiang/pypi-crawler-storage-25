"""
Top-level convenience functions — the public face of georankpy.

>>> from georankpy import audit, generate_llms_txt, analyze
"""

from __future__ import annotations

from georankpy.core.engine import GeoEngine
from georankpy.core.models import AuditResult, LlmsTxtResult, SemanticReport

_default_engine: GeoEngine | None = None


def _get_engine(**kwargs) -> GeoEngine:
    global _default_engine
    if kwargs or _default_engine is None:
        _default_engine = GeoEngine(**kwargs)
    return _default_engine


def audit(
    url: str,
    *,
    timeout: int = 15,
    use_nlp: bool = False,
    generate_llms_txt: bool = True,
    respect_robots: bool = True,
) -> AuditResult:
    """
    Run a complete GEO audit for *url*.

    Parameters
    ----------
    url : str
        The URL to audit (must include scheme, e.g. ``https://example.com``).
    timeout : int
        HTTP timeout in seconds.
    use_nlp : bool
        Enable spaCy NLP entity extraction.
        Requires ``pip install georankpy[nlp]``.
    generate_llms_txt : bool
        Generate an llms.txt file as part of the audit.
    respect_robots : bool
        Honour robots.txt directives.

    Returns
    -------
    AuditResult
        Full audit result including GEO score, semantic report, entities,
        and generated llms.txt.

    Example
    -------
    >>> result = audit("https://example.com")
    >>> print(result.geo_score.geo_score)   # e.g. 74
    >>> print(result.geo_score.band)        # ScoreBand.GOOD
    """
    engine = GeoEngine(
        timeout=timeout,
        use_nlp=use_nlp,
        generate_llms_txt=generate_llms_txt,
        respect_robots=respect_robots,
    )
    return engine.audit(url)


def generate_llms_txt(url: str, *, timeout: int = 15) -> LlmsTxtResult:
    """
    Generate an llms.txt file for *url* without a full audit.

    Returns
    -------
    LlmsTxtResult
        Object containing the generated ``content`` string (save to
        ``/llms.txt`` on your server) plus structured sections.

    Example
    -------
    >>> result = generate_llms_txt("https://example.com")
    >>> print(result.content)
    """
    engine = GeoEngine(timeout=timeout, generate_llms_txt=True)
    return engine.generate_llms_txt_for(url)


def analyze(url: str, *, timeout: int = 15) -> SemanticReport:
    """
    Run only the semantic analysis for *url* (faster than a full audit).

    Returns
    -------
    SemanticReport
        Detailed semantic analysis including chunk quality, heading
        structure, and readability metrics.

    Example
    -------
    >>> report = analyze("https://example.com")
    >>> print(report.overall_score)
    """
    engine = GeoEngine(timeout=timeout, generate_llms_txt=False)
    return engine.analyze_semantics(url)
