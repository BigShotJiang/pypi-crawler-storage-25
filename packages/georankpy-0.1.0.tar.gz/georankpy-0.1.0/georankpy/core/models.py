"""
Core Pydantic models used across all GeoRankPy modules.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ScoreBand(str, Enum):
    EXCELLENT = "excellent"   # 86–100
    GOOD = "good"             # 68–85
    FAIR = "fair"             # 36–67
    POOR = "poor"             # 0–35


class EntityType(str, Enum):
    PERSON = "person"
    ORGANIZATION = "organization"
    TECHNOLOGY = "technology"
    PRODUCT = "product"
    LOCATION = "location"
    CONCEPT = "concept"


class IssueLevel(str, Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------

class GeoIssue(BaseModel):
    """A single detected GEO issue."""
    level: IssueLevel
    code: str
    message: str
    fix: str = ""


class ScoreBreakdown(BaseModel):
    """Per-dimension breakdown of the GEO score."""
    semantic_clarity: float = Field(0.0, ge=0, le=25, description="0–25 pts")
    metadata_completeness: float = Field(0.0, ge=0, le=20, description="0–20 pts")
    chunk_retrievability: float = Field(0.0, ge=0, le=20, description="0–20 pts")
    schema_quality: float = Field(0.0, ge=0, le=15, description="0–15 pts")
    entity_richness: float = Field(0.0, ge=0, le=10, description="0–10 pts")
    llms_txt_quality: float = Field(0.0, ge=0, le=10, description="0–10 pts")

    @property
    def total(self) -> float:
        return (
            self.semantic_clarity
            + self.metadata_completeness
            + self.chunk_retrievability
            + self.schema_quality
            + self.entity_richness
            + self.llms_txt_quality
        )


class GeoScore(BaseModel):
    """Overall GEO score result."""
    geo_score: int = Field(..., ge=0, le=100)
    band: ScoreBand
    breakdown: ScoreBreakdown
    issues: list[GeoIssue] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)

    @classmethod
    def band_for(cls, score: float) -> ScoreBand:
        if score >= 86:
            return ScoreBand.EXCELLENT
        if score >= 68:
            return ScoreBand.GOOD
        if score >= 36:
            return ScoreBand.FAIR
        return ScoreBand.POOR


class Entity(BaseModel):
    """An extracted AI-relevant entity."""
    text: str
    type: EntityType
    confidence: float = Field(1.0, ge=0.0, le=1.0)
    count: int = 1


class SemanticChunk(BaseModel):
    """A single retrievable chunk of content."""
    index: int
    heading: str = ""
    text: str
    word_count: int
    has_definition: bool = False    # starts with a definition sentence
    has_anchor_sentence: bool = False  # first sentence is self-contained
    retrievability_score: float = Field(0.0, ge=0.0, le=1.0)


class MetadataResult(BaseModel):
    """Extracted metadata from a crawled page."""
    title: str = ""
    description: str = ""
    og_title: str = ""
    og_description: str = ""
    og_image: str = ""
    canonical: str = ""
    robots: str = ""
    schema_types: list[str] = Field(default_factory=list)
    has_faq_schema: bool = False
    has_article_schema: bool = False
    has_organization_schema: bool = False


class CrawlResult(BaseModel):
    """Raw crawled page data."""
    url: str
    status_code: int
    html: str = ""
    text: str = ""
    headings: list[dict[str, str]] = Field(default_factory=list)
    links: list[str] = Field(default_factory=list)
    metadata: MetadataResult = Field(default_factory=MetadataResult)
    has_llms_txt: bool = False
    llms_txt_content: str = ""
    robots_txt_content: str = ""
    sitemap_urls: list[str] = Field(default_factory=list)
    error: str = ""


class SemanticReport(BaseModel):
    """Full semantic analysis of a page."""
    url: str
    heading_structure_score: float = Field(0.0, ge=0, le=1)
    paragraph_clarity_score: float = Field(0.0, ge=0, le=1)
    semantic_density_score: float = Field(0.0, ge=0, le=1)
    chunk_quality_score: float = Field(0.0, ge=0, le=1)
    readability_score: float = Field(0.0, ge=0, le=1)
    chunks: list[SemanticChunk] = Field(default_factory=list)
    issues: list[GeoIssue] = Field(default_factory=list)

    @property
    def overall_score(self) -> float:
        return (
            self.heading_structure_score * 0.2
            + self.paragraph_clarity_score * 0.2
            + self.semantic_density_score * 0.2
            + self.chunk_quality_score * 0.25
            + self.readability_score * 0.15
        )


class LlmsTxtResult(BaseModel):
    """Generated llms.txt content and metadata."""
    url: str
    content: str
    sections: list[dict[str, Any]] = Field(default_factory=list)
    word_count: int = 0
    generated_at: datetime = Field(default_factory=datetime.utcnow)


class AuditResult(BaseModel):
    """
    Complete GEO audit result — top-level object returned by `georankpy.audit()`.
    """
    url: str
    crawl: CrawlResult
    geo_score: GeoScore
    semantic: SemanticReport
    entities: list[Entity] = Field(default_factory=list)
    llms_txt: LlmsTxtResult | None = None
    audited_at: datetime = Field(default_factory=datetime.utcnow)

    def summary(self) -> dict[str, Any]:
        return {
            "url": self.url,
            "geo_score": self.geo_score.geo_score,
            "band": self.geo_score.band.value,
            "issues": [i.message for i in self.geo_score.issues],
            "recommendations": self.geo_score.recommendations,
            "entity_count": len(self.entities),
        }
