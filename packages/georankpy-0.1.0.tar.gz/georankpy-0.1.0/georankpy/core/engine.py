"""
GeoEngine — Central orchestration layer.

Coordinates the crawler, analyzer, entity extractor, scorer,
and generator into a single pipeline.
"""

from __future__ import annotations

import logging
from typing import Any

from georankpy.core.models import AuditResult, CrawlResult

logger = logging.getLogger(__name__)


class GeoEngine:
    """
    Main orchestrator for a full GEO audit pipeline.

    Parameters
    ----------
    timeout : int
        HTTP request timeout in seconds (default 15).
    user_agent : str
        User-agent string for the crawler.
    respect_robots : bool
        Whether to honour robots.txt directives (default True).
    generate_llms_txt : bool
        Whether to auto-generate llms.txt as part of the audit.
    use_nlp : bool
        Enable spaCy NLP entity extraction (requires `pip install georankpy[nlp]`).
    """

    def __init__(
        self,
        timeout: int = 15,
        user_agent: str = "GeoRankPy/0.1 (+https://github.com/Hero777-tech/georankpy)",
        respect_robots: bool = True,
        generate_llms_txt: bool = True,
        use_nlp: bool = False,
    ) -> None:
        self.timeout = timeout
        self.user_agent = user_agent
        self.respect_robots = respect_robots
        self.generate_llms_txt_flag = generate_llms_txt
        self.use_nlp = use_nlp

        # Lazy imports — only pulled in when needed
        self._crawler: Any = None
        self._analyzer: Any = None
        self._entity_extractor: Any = None
        self._scorer: Any = None
        self._generator: Any = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def audit(self, url: str) -> AuditResult:
        """
        Run a full GEO audit for the given URL.

        Returns an :class:`~georankpy.core.models.AuditResult`.
        """
        logger.info("Starting GEO audit for %s", url)

        crawl = self._crawl(url)
        if crawl.error:
            logger.warning("Crawl error for %s: %s", url, crawl.error)

        semantic = self._analyze(crawl)
        entities = self._extract_entities(crawl)
        geo_score = self._score(crawl, semantic, entities)

        llms_txt_result = None
        if self.generate_llms_txt_flag:
            llms_txt_result = self._generate_llms_txt(url, crawl)

        result = AuditResult(
            url=url,
            crawl=crawl,
            geo_score=geo_score,
            semantic=semantic,
            entities=entities,
            llms_txt=llms_txt_result,
        )
        logger.info(
            "Audit complete for %s — GEO score: %d (%s)",
            url,
            result.geo_score.geo_score,
            result.geo_score.band.value,
        )
        return result

    def analyze_semantics(self, url: str):
        """Run only semantic analysis (faster, no scoring)."""
        crawl = self._crawl(url)
        return self._analyze(crawl)

    def extract_entities(self, url: str):
        """Run only entity extraction."""
        crawl = self._crawl(url)
        return self._extract_entities(crawl)

    def generate_llms_txt_for(self, url: str):
        """Generate llms.txt content for a URL without a full audit."""
        crawl = self._crawl(url)
        return self._generate_llms_txt(url, crawl)

    # ------------------------------------------------------------------
    # Internal pipeline steps
    # ------------------------------------------------------------------

    def _crawl(self, url: str) -> CrawlResult:
        from georankpy.crawler.fetcher import PageCrawler
        if self._crawler is None:
            self._crawler = PageCrawler(
                timeout=self.timeout,
                user_agent=self.user_agent,
                respect_robots=self.respect_robots,
            )
        return self._crawler.crawl(url)

    def _analyze(self, crawl: CrawlResult):
        from georankpy.analyzer.semantic import SemanticAnalyzer
        if self._analyzer is None:
            self._analyzer = SemanticAnalyzer()
        return self._analyzer.analyze(crawl)

    def _extract_entities(self, crawl: CrawlResult) -> list:
        from georankpy.entities.extractor import EntityExtractor
        if self._entity_extractor is None:
            self._entity_extractor = EntityExtractor(use_nlp=self.use_nlp)
        return self._entity_extractor.extract(crawl)

    def _score(self, crawl: CrawlResult, semantic, entities) -> Any:
        from georankpy.scoring.scorer import GeoScorer
        if self._scorer is None:
            self._scorer = GeoScorer()
        return self._scorer.score(crawl, semantic, entities)

    def _generate_llms_txt(self, url: str, crawl: CrawlResult) -> Any:
        from georankpy.generators.llms_txt import LlmsTxtGenerator
        if self._generator is None:
            self._generator = LlmsTxtGenerator()
        return self._generator.generate(url, crawl)
