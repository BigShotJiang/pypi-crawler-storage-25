"""
EntityExtractor — AI-relevant named entity extraction.

Two modes:
  - Rule-based (default, no extra deps): extracts tech, org, and product
    entities using regex heuristics.
  - NLP mode (``use_nlp=True``): uses spaCy for richer extraction.
    Requires ``pip install georankpy[nlp]`` and ``python -m spacy download en_core_web_sm``.
"""

from __future__ import annotations

import re
from collections import Counter

from georankpy.core.models import CrawlResult, Entity, EntityType

# Heuristic tech-stack keywords (curated for AI/web context)
_TECH_KEYWORDS: set[str] = {
    "python", "javascript", "typescript", "react", "vue", "angular", "nextjs",
    "django", "flask", "fastapi", "node", "nodejs", "docker", "kubernetes",
    "aws", "gcp", "azure", "postgresql", "mysql", "mongodb", "redis",
    "tensorflow", "pytorch", "scikit-learn", "openai", "chatgpt", "claude",
    "gemini", "llm", "gpt", "bert", "transformer", "langchain", "rag",
    "vector", "embedding", "fine-tuning", "api", "rest", "graphql",
    "github", "gitlab", "ci/cd", "devops", "microservices", "kafka",
    "elasticsearch", "spark", "airflow", "dbt",
}

# Org-like patterns: capitalized words possibly followed by Inc/Ltd/Corp/AI/Labs
_ORG_RE = re.compile(
    r"\b([A-Z][a-zA-Z]{2,}(?:\s+[A-Z][a-zA-Z]{2,}){0,3}"
    r"(?:\s+(?:Inc|Ltd|Corp|AI|Labs|Technologies|Solutions|Systems|Group|Co))?)\.?\b"
)

# URL / domain-like patterns → products/services
_URL_ENTITY_RE = re.compile(r"\b([A-Z][a-zA-Z0-9]{2,}(?:\.[a-zA-Z]{2,3})?)\b")


class EntityExtractor:
    """
    Extract AI-relevant entities from crawled content.

    Parameters
    ----------
    use_nlp : bool
        If True, use spaCy. Falls back to rule-based if spaCy is unavailable.
    """

    def __init__(self, use_nlp: bool = False) -> None:
        self.use_nlp = use_nlp
        self._nlp = None

        if use_nlp:
            self._nlp = self._load_spacy()

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def extract(self, crawl: CrawlResult) -> list[Entity]:
        text = crawl.text
        if self._nlp is not None:
            return self._extract_spacy(text)
        return self._extract_rules(text)

    # ------------------------------------------------------------------
    # Rule-based extraction (zero extra deps)
    # ------------------------------------------------------------------

    def _extract_rules(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        text_lower = text.lower()

        # Technologies
        tech_counter: Counter[str] = Counter()
        for keyword in _TECH_KEYWORDS:
            pattern = re.compile(rf"\b{re.escape(keyword)}\b", re.I)
            count = len(pattern.findall(text))
            if count > 0:
                tech_counter[keyword] = count

        for tech, count in tech_counter.most_common(20):
            entities.append(Entity(
                text=tech,
                type=EntityType.TECHNOLOGY,
                confidence=0.85,
                count=count,
            ))

        # Organizations (capitalized proper nouns)
        org_counter: Counter[str] = Counter()
        for match in _ORG_RE.finditer(text):
            org = match.group(1).strip()
            if 3 < len(org) < 60 and org.lower() not in _TECH_KEYWORDS:
                org_counter[org] += 1

        seen_orgs: set[str] = set()
        for org, count in org_counter.most_common(15):
            if org.lower() not in seen_orgs:
                seen_orgs.add(org.lower())
                entities.append(Entity(
                    text=org,
                    type=EntityType.ORGANIZATION,
                    confidence=0.65,
                    count=count,
                ))

        # Deduplicate and sort by count desc
        entities.sort(key=lambda e: e.count, reverse=True)
        return entities

    # ------------------------------------------------------------------
    # spaCy-based extraction (richer, requires georankpy[nlp])
    # ------------------------------------------------------------------

    def _extract_spacy(self, text: str) -> list[Entity]:
        assert self._nlp is not None
        # spaCy has 1M char limit
        doc = self._nlp(text[:500_000])

        counter: Counter[tuple[str, str]] = Counter()
        for ent in doc.ents:
            if ent.label_ in ("PERSON", "ORG", "GPE", "LOC", "PRODUCT", "WORK_OF_ART"):
                counter[(ent.text.strip(), ent.label_)] += 1

        type_map = {
            "PERSON": EntityType.PERSON,
            "ORG": EntityType.ORGANIZATION,
            "GPE": EntityType.LOCATION,
            "LOC": EntityType.LOCATION,
            "PRODUCT": EntityType.PRODUCT,
            "WORK_OF_ART": EntityType.PRODUCT,
        }

        entities: list[Entity] = []
        for (text_val, label), count in counter.most_common(30):
            entity_type = type_map.get(label, EntityType.CONCEPT)
            entities.append(Entity(
                text=text_val,
                type=entity_type,
                confidence=0.90,
                count=count,
            ))

        # Also add technologies via rule-based
        tech_entities = [
            e for e in self._extract_rules(text)
            if e.type == EntityType.TECHNOLOGY
        ]
        entities.extend(tech_entities)
        entities.sort(key=lambda e: e.count, reverse=True)
        return entities

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _load_spacy(self):
        try:
            import spacy  # noqa: PLC0415
            try:
                return spacy.load("en_core_web_sm")
            except OSError:
                import warnings
                warnings.warn(
                    "spaCy model 'en_core_web_sm' not found. "
                    "Run: python -m spacy download en_core_web_sm\n"
                    "Falling back to rule-based extraction.",
                    stacklevel=3,
                )
                return None
        except ImportError:
            import warnings
            warnings.warn(
                "spaCy not installed. Install with: pip install georankpy[nlp]\n"
                "Falling back to rule-based extraction.",
                stacklevel=3,
            )
            return None
