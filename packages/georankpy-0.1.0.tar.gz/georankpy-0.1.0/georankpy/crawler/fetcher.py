"""
PageCrawler — HTTP fetcher and HTML parser.

Fetches a URL, parses HTML, extracts metadata, headings, links,
checks for llms.txt / robots.txt / sitemap.
"""

from __future__ import annotations

import json
import logging
import re
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

from georankpy.core.models import CrawlResult, MetadataResult

logger = logging.getLogger(__name__)

_SCHEMA_TYPES_RE = re.compile(r'"@type"\s*:\s*"([^"]+)"')


class PageCrawler:
    """
    Crawls a single page and adjacent AI-relevant files.

    Parameters
    ----------
    timeout : int
        Request timeout in seconds.
    user_agent : str
        User-agent header value.
    respect_robots : bool
        If True, skip crawling if robots.txt disallows the path.
    """

    def __init__(
        self,
        timeout: int = 15,
        user_agent: str = "GeoRankPy/0.1",
        respect_robots: bool = True,
    ) -> None:
        self.timeout = timeout
        self.user_agent = user_agent
        self.respect_robots = respect_robots

        self._client = httpx.Client(
            timeout=self.timeout,
            headers={"User-Agent": self.user_agent},
            follow_redirects=True,
        )

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def crawl(self, url: str) -> CrawlResult:
        """Crawl *url* and return a fully populated :class:`CrawlResult`."""
        base = self._base_url(url)

        robots_txt = self._fetch_text(f"{base}/robots.txt")
        if self.respect_robots and self._is_disallowed(url, robots_txt):
            return CrawlResult(
                url=url,
                status_code=0,
                error="Blocked by robots.txt",
                robots_txt_content=robots_txt,
            )

        try:
            response = self._client.get(url)
        except Exception as exc:  # noqa: BLE001
            return CrawlResult(url=url, status_code=0, error=str(exc))

        html = response.text
        soup = BeautifulSoup(html, "lxml")

        metadata = self._extract_metadata(soup)
        headings = self._extract_headings(soup)
        links = self._extract_links(soup, base)
        text = self._extract_text(soup)

        llms_txt_content = self._fetch_text(f"{base}/llms.txt")
        sitemap_urls = self._parse_sitemap(base)

        return CrawlResult(
            url=url,
            status_code=response.status_code,
            html=html,
            text=text,
            headings=headings,
            links=links,
            metadata=metadata,
            has_llms_txt=bool(llms_txt_content),
            llms_txt_content=llms_txt_content,
            robots_txt_content=robots_txt,
            sitemap_urls=sitemap_urls,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _base_url(self, url: str) -> str:
        p = urlparse(url)
        return f"{p.scheme}://{p.netloc}"

    def _fetch_text(self, url: str) -> str:
        try:
            r = self._client.get(url)
            if r.status_code == 200:
                return r.text
        except Exception:  # noqa: BLE001
            pass
        return ""

    def _extract_metadata(self, soup: BeautifulSoup) -> MetadataResult:
        def meta(name: str = "", prop: str = "") -> str:
            tag = (
                soup.find("meta", {"name": name}) if name
                else soup.find("meta", {"property": prop})
            )
            return tag.get("content", "") if tag else ""  # type: ignore[union-attr]

        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else ""

        canonical_tag = soup.find("link", {"rel": "canonical"})
        canonical = canonical_tag.get("href", "") if canonical_tag else ""  # type: ignore[union-attr]

        # Schema.org types
        schema_scripts = soup.find_all("script", {"type": "application/ld+json"})
        schema_types: list[str] = []
        for script in schema_scripts:
            types = _SCHEMA_TYPES_RE.findall(script.string or "")
            schema_types.extend(types)

        return MetadataResult(
            title=title,
            description=meta(name="description"),
            og_title=meta(prop="og:title"),
            og_description=meta(prop="og:description"),
            og_image=meta(prop="og:image"),
            canonical=str(canonical),
            robots=meta(name="robots"),
            schema_types=schema_types,
            has_faq_schema="FAQPage" in schema_types,
            has_article_schema=any(t in schema_types for t in ("Article", "BlogPosting", "NewsArticle")),
            has_organization_schema=any(t in schema_types for t in ("Organization", "LocalBusiness")),
        )

    def _extract_headings(self, soup: BeautifulSoup) -> list[dict[str, str]]:
        headings = []
        for tag in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"]):
            headings.append({"level": tag.name, "text": tag.get_text(strip=True)})
        return headings

    def _extract_links(self, soup: BeautifulSoup, base: str) -> list[str]:
        links = []
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.startswith("http"):
                links.append(href)
            elif href.startswith("/"):
                links.append(urljoin(base, href))
        return list(set(links))

    def _extract_text(self, soup: BeautifulSoup) -> str:
        for tag in soup(["script", "style", "noscript", "header", "footer", "nav"]):
            tag.decompose()
        return soup.get_text(separator="\n", strip=True)

    def _parse_sitemap(self, base: str) -> list[str]:
        content = self._fetch_text(f"{base}/sitemap.xml")
        if not content:
            return []
        urls = re.findall(r"<loc>(.*?)</loc>", content)
        return urls[:50]  # cap at 50 for MVP

    def _is_disallowed(self, url: str, robots_txt: str) -> bool:
        if not robots_txt:
            return False
        path = urlparse(url).path
        disallowed: list[str] = []
        in_georank_block = False
        for line in robots_txt.splitlines():
            line = line.strip()
            if line.lower().startswith("user-agent:"):
                agent = line.split(":", 1)[1].strip()
                in_georank_block = agent in ("*", "GeoRankPy")
            elif in_georank_block and line.lower().startswith("disallow:"):
                disallowed.append(line.split(":", 1)[1].strip())
        return any(path.startswith(d) for d in disallowed if d)
