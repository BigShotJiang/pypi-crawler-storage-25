"""Django AppConfig for GeoRankPy."""

from django.apps import AppConfig


class GeoRankPyConfig(AppConfig):
    name = "georankpy.integrations.django_ext"
    label = "georankpy"
    verbose_name = "GeoRankPy"

    def ready(self) -> None:
        # Auto-register URL patterns when app is ready
        pass
