"""
GeoRankPy Django Integration
==============================

Add to INSTALLED_APPS and MIDDLEWARE to get automatic GEO headers,
llms.txt endpoint, and management commands.

Usage
-----
In settings.py:

    INSTALLED_APPS = [
        ...
        "georankpy.integrations.django_ext",
    ]

    MIDDLEWARE = [
        ...
        "georankpy.integrations.django_ext.middleware.GeoMiddleware",
    ]

    # Optional config block
    GEORANKPY = {
        "SITE_NAME": "My Site",
        "SITE_DESCRIPTION": "What my site does.",
        "INJECT_META": True,
        "ROUTES": [
            {"path": "/", "title": "Home", "description": "Main page"},
            {"path": "/about/", "title": "About", "description": "About us"},
        ],
    }

This automatically adds:
  GET /llms.txt     — AI-readable site summary
  GET /geo/score/   — JSON status endpoint

Management command:
  python manage.py geo_audit <url>
"""

default_app_config = "georankpy.integrations.django_ext.apps.GeoRankPyConfig"
