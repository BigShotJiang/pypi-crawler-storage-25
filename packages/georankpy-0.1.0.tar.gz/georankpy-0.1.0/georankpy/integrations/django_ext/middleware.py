"""Django middleware — injects GEO headers and meta tag."""

from __future__ import annotations


class GeoMiddleware:
    """
    Adds GEO optimization headers to every response.

    Install in settings.py MIDDLEWARE list.
    """

    def __init__(self, get_response) -> None:
        self.get_response = get_response

        try:
            from django.conf import settings  # noqa: PLC0415
            self.config: dict = getattr(settings, "GEORANKPY", {})
        except Exception:  # noqa: BLE001
            self.config = {}

        self.inject_meta: bool = self.config.get("INJECT_META", True)

    def __call__(self, request):
        response = self.get_response(request)

        # Inject header
        response["X-GEO-Optimized"] = "georankpy/0.1"

        # Inject meta tag into HTML responses
        if self.inject_meta:
            content_type = response.get("Content-Type", "")
            if "text/html" in content_type:
                try:
                    content = response.content.decode("utf-8")
                    meta_tag = '<meta name="ai-optimized" content="georankpy" data-version="0.1">'
                    content = content.replace("</head>", f"{meta_tag}\n</head>", 1)
                    response.content = content.encode("utf-8")
                except Exception:  # noqa: BLE001
                    pass

        return response
