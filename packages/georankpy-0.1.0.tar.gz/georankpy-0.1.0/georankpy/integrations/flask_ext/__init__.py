"""
GeoRankPy Flask Integration
============================

Adds automatic GEO optimization middleware and AI-friendly routes to any
Flask application with two lines of code.

Usage
-----
>>> from flask import Flask
>>> from georankpy.integrations.flask_ext import GEO
>>>
>>> app = Flask(__name__)
>>> geo = GEO(app)

Routes added automatically
--------------------------
  GET /llms.txt          — AI-readable site summary
  GET /geo/score         — JSON GEO score for this app
  GET /ai-sitemap.xml    — AI-friendly sitemap

Middleware
----------
  - Injects `X-GEO-Optimized: true` response header
  - Injects `<meta name="ai-optimized">` into HTML responses (optional)
"""

from __future__ import annotations

from typing import Any


class GEO:
    """
    Flask extension for GeoRankPy.

    Parameters
    ----------
    app : flask.Flask | None
        Pass the Flask app directly, or use :meth:`init_app` for
        the application factory pattern.
    site_name : str
        Human-readable site name used in llms.txt.
    site_description : str
        One-line description used in llms.txt.
    inject_meta : bool
        If True, inject an AI optimization meta tag into all HTML responses.
    auto_routes : bool
        If True, register /llms.txt and /geo/score routes automatically.
    llms_txt_extra : str
        Extra content appended verbatim to the generated llms.txt.
    """

    def __init__(
        self,
        app=None,
        *,
        site_name: str = "",
        site_description: str = "",
        inject_meta: bool = True,
        auto_routes: bool = True,
        llms_txt_extra: str = "",
    ) -> None:
        self.site_name = site_name
        self.site_description = site_description
        self.inject_meta = inject_meta
        self.auto_routes = auto_routes
        self.llms_txt_extra = llms_txt_extra

        self._app = app
        self._routes: list[dict[str, Any]] = []  # manually registered routes

        if app is not None:
            self.init_app(app)

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def init_app(self, app) -> None:
        """
        Initialise GEO with a Flask app (application factory pattern).

        >>> geo = GEO()
        >>> geo.init_app(app)
        """
        try:
            from flask import Flask  # noqa: PLC0415
        except ImportError as e:
            raise ImportError(
                "Flask is required. Install with: pip install georankpy[flask]"
            ) from e

        self._app = app
        app.extensions["georankpy"] = self

        if self.auto_routes:
            self._register_routes(app)

        if self.inject_meta:
            app.after_request(self._after_request_hook)

    def add_route(self, path: str, title: str, description: str = "") -> None:
        """
        Register a custom page in the llms.txt output.

        >>> geo.add_route("/docs", "Documentation", "Full API reference")
        """
        self._routes.append({"path": path, "title": title, "description": description})

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _register_routes(self, app) -> None:
        from flask import Response, jsonify, request  # noqa: PLC0415

        geo_ext = self  # capture for closures

        @app.route("/llms.txt")
        def georankpy_llms_txt():  # type: ignore[return]
            content = geo_ext._build_llms_txt(request.host_url)
            return Response(content, mimetype="text/plain; charset=utf-8")

        @app.route("/geo/score")
        def georankpy_geo_score():  # type: ignore[return]
            return jsonify({
                "status": "ok",
                "message": "Run `georank audit <your-url>` for a full GEO score.",
                "library": "georankpy",
                "version": "0.1.0",
                "docs": "https://github.com/Hero777-tech/georankpy",
            })

        @app.route("/ai-sitemap.xml")
        def georankpy_ai_sitemap():  # type: ignore[return]
            urls = [r["path"] for r in geo_ext._routes]
            xml_parts = ['<?xml version="1.0" encoding="UTF-8"?>']
            xml_parts.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')
            for path in urls:
                xml_parts.append(f"  <url><loc>{request.host_url.rstrip('/')}{path}</loc></url>")
            xml_parts.append("</urlset>")
            return Response("\n".join(xml_parts), mimetype="application/xml")

    def _after_request_hook(self, response):
        """Inject GEO header + optional meta tag into HTML responses."""
        response.headers["X-GEO-Optimized"] = "georankpy/0.1"

        if self.inject_meta and response.content_type.startswith("text/html"):
            try:
                body = response.get_data(as_text=True)
                meta_tag = (
                    '<meta name="ai-optimized" content="georankpy" '
                    'data-version="0.1">'
                )
                body = body.replace("</head>", f"{meta_tag}\n</head>", 1)
                response.set_data(body)
            except Exception:  # noqa: BLE001
                pass  # never break the response

        return response

    def _build_llms_txt(self, host_url: str) -> str:
        from datetime import datetime  # noqa: PLC0415

        name = self.site_name or host_url.rstrip("/")
        desc = self.site_description or "A web application."

        lines = [
            f"# {name}",
            "",
            f"> {desc}",
            "",
        ]

        if self._routes:
            lines.append("## Key Pages")
            lines.append("")
            for route in self._routes:
                url = host_url.rstrip("/") + route["path"]
                title = route["title"]
                description = route.get("description", "")
                if description:
                    lines.append(f"- [{title}]({url}): {description}")
                else:
                    lines.append(f"- [{title}]({url})")
            lines.append("")

        if self.llms_txt_extra:
            lines.append(self.llms_txt_extra)
            lines.append("")

        lines.append(
            f"<!-- Generated by GeoRankPy Flask extension on "
            f"{datetime.utcnow().strftime('%Y-%m-%d')} -->"
        )

        return "\n".join(lines)
