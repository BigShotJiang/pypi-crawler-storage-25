"""
GeoRankPy CLI
=============

Commands:
  georank audit <url>         — full GEO audit
  georank generate llms <url> — generate llms.txt
  georank analyze <url>       — semantic analysis only
  georank report <url>        — export HTML/MD/JSON report
"""

from __future__ import annotations

import json
from enum import Enum
from pathlib import Path
from typing import Optional

import typer
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

app = typer.Typer(
    name="georank",
    help="GeoRankPy — Make your website visible to AI systems.",
    add_completion=False,
    rich_markup_mode="rich",
)

generate_app = typer.Typer(help="Generator commands.")
app.add_typer(generate_app, name="generate")

console = Console()


class ReportFormat(str, Enum):
    json = "json"
    markdown = "md"
    html = "html"


# ---------------------------------------------------------------------------
# georank audit <url>
# ---------------------------------------------------------------------------

@app.command()
def audit(
    url: str = typer.Argument(..., help="URL to audit (include https://)"),
    use_nlp: bool = typer.Option(False, "--nlp", help="Enable spaCy NLP entity extraction"),
    no_llms_txt: bool = typer.Option(False, "--no-llms-txt", help="Skip llms.txt generation"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Save report to file"),
    fmt: ReportFormat = typer.Option(ReportFormat.json, "--format", "-f", help="Output format"),
):
    """
    Run a full GEO audit for a URL and display the results.

    \b
    Examples:
      georank audit https://example.com
      georank audit https://example.com --format md --output report.md
      georank audit https://example.com --nlp
    """
    from georankpy.core.engine import GeoEngine  # noqa: PLC0415
    from georankpy.reports.formatter import save_html, save_json, save_markdown, to_markdown  # noqa: PLC0415

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        progress.add_task(f"Auditing [bold cyan]{url}[/bold cyan]...", total=None)
        engine = GeoEngine(use_nlp=use_nlp, generate_llms_txt=not no_llms_txt)
        result = engine.audit(url)

    gs = result.geo_score
    _print_score_panel(url, gs.geo_score, gs.band.value)

    # Score breakdown table
    table = Table(title="Score Breakdown", show_header=True, header_style="bold magenta")
    table.add_column("Dimension", style="cyan")
    table.add_column("Score", justify="right")
    table.add_column("Max", justify="right")
    bd = gs.breakdown
    table.add_row("Semantic Clarity",      f"{bd.semantic_clarity:.1f}",      "25")
    table.add_row("Metadata Completeness", f"{bd.metadata_completeness:.1f}", "20")
    table.add_row("Chunk Retrievability",  f"{bd.chunk_retrievability:.1f}",  "20")
    table.add_row("Schema Quality",        f"{bd.schema_quality:.1f}",        "15")
    table.add_row("Entity Richness",       f"{bd.entity_richness:.1f}",       "10")
    table.add_row("llms.txt Quality",      f"{bd.llms_txt_quality:.1f}",      "10")
    console.print(table)

    # Issues
    if gs.issues:
        console.print("\n[bold red]Issues:[/bold red]")
        for issue in gs.issues:
            icon = {"critical": "🔴", "warning": "🟡", "info": "🔵"}.get(issue.level.value, "⚪")
            console.print(f"  {icon} [{issue.code}] {issue.message}")
            if issue.fix:
                console.print(f"     [dim]→ {issue.fix}[/dim]")

    # Recommendations
    if gs.recommendations:
        console.print("\n[bold yellow]Recommendations:[/bold yellow]")
        for i, rec in enumerate(gs.recommendations, 1):
            console.print(f"  {i}. {rec}")

    # Entities
    if result.entities:
        console.print(f"\n[bold green]Top Entities ({len(result.entities)} detected):[/bold green]")
        for e in result.entities[:8]:
            console.print(f"  • [cyan]{e.text}[/cyan] ({e.type.value}) — {e.count}×")

    # Save output
    if output:
        if fmt == ReportFormat.json:
            save_json(result, output)
        elif fmt == ReportFormat.markdown:
            save_markdown(result, output)
        elif fmt == ReportFormat.html:
            save_html(result, output)
        console.print(f"\n✅ Report saved to [bold]{output}[/bold]")


# ---------------------------------------------------------------------------
# georank generate llms <url>
# ---------------------------------------------------------------------------

@generate_app.command("llms")
def generate_llms(
    url: str = typer.Argument(..., help="URL to generate llms.txt for"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Save to file (default: stdout)"),
):
    """
    Generate an llms.txt file for a URL.

    \b
    Examples:
      georank generate llms https://example.com
      georank generate llms https://example.com --output llms.txt
    """
    from georankpy.api import generate_llms_txt as gen  # noqa: PLC0415

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        p.add_task(f"Generating llms.txt for [cyan]{url}[/cyan]...", total=None)
        result = gen(url)

    if output:
        output.write_text(result.content, encoding="utf-8")
        console.print(f"✅ llms.txt saved to [bold]{output}[/bold]")
        console.print(f"   → Deploy it at: [cyan]{url.rstrip('/')}/llms.txt[/cyan]")
    else:
        console.print(Panel(result.content, title="Generated llms.txt", border_style="green"))


# ---------------------------------------------------------------------------
# georank analyze <url>
# ---------------------------------------------------------------------------

@app.command()
def analyze(
    url: str = typer.Argument(..., help="URL to analyze"),
):
    """Run semantic analysis only (faster than full audit)."""
    from georankpy.api import analyze as sem_analyze  # noqa: PLC0415

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        p.add_task(f"Analyzing [cyan]{url}[/cyan]...", total=None)
        report = sem_analyze(url)

    console.print(Panel(
        f"[cyan]Heading Structure:[/cyan]  {report.heading_structure_score:.2f}/1.0\n"
        f"[cyan]Paragraph Clarity:[/cyan]  {report.paragraph_clarity_score:.2f}/1.0\n"
        f"[cyan]Semantic Density:[/cyan]   {report.semantic_density_score:.2f}/1.0\n"
        f"[cyan]Chunk Quality:[/cyan]      {report.chunk_quality_score:.2f}/1.0\n"
        f"[cyan]Readability:[/cyan]        {report.readability_score:.2f}/1.0\n"
        f"[cyan]Overall:[/cyan]            {report.overall_score:.2f}/1.0\n"
        f"[cyan]Chunks found:[/cyan]       {len(report.chunks)}",
        title=f"Semantic Analysis — {url}",
        border_style="cyan",
    ))

    if report.issues:
        console.print("\n[bold]Issues:[/bold]")
        for issue in report.issues:
            console.print(f"  • {issue.message}")


# ---------------------------------------------------------------------------
# georank version
# ---------------------------------------------------------------------------

@app.command()
def version():
    """Show GeoRankPy version."""
    from georankpy import __version__  # noqa: PLC0415
    rprint(f"[bold cyan]GeoRankPy[/bold cyan] v{__version__}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _print_score_panel(url: str, score: int, band: str) -> None:
    colors = {"excellent": "green", "good": "cyan", "fair": "yellow", "poor": "red"}
    color = colors.get(band, "white")
    console.print(Panel(
        f"[bold {color}]{score}/100[/bold {color}]  •  [{color}]{band.upper()}[/{color}]",
        title=f"🔍 GEO Score — {url}",
        border_style=color,
    ))


if __name__ == "__main__":
    app()
