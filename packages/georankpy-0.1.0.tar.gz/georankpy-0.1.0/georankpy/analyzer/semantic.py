"""
SemanticAnalyzer — GeoRankPy's core differentiator.

Evaluates a crawled page for AI retrievability across five dimensions:
  1. Heading structure
  2. Paragraph clarity
  3. Semantic density
  4. Chunk quality (RAG-readiness)
  5. Readability
"""

from __future__ import annotations

import re
import statistics
from dataclasses import dataclass, field

from georankpy.core.models import (
    CrawlResult,
    GeoIssue,
    IssueLevel,
    SemanticChunk,
    SemanticReport,
)

# Approximate syllable count using vowel clusters
_VOWEL_RE = re.compile(r"[aeiouy]+", re.I)
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
_DEFINITION_STARTERS = (
    "is ", "are ", "refers to", "means ", "defined as",
    "a type of", "an approach", "the process of",
)


class SemanticAnalyzer:
    """
    Analyzes semantic quality of crawled content for AI retrievability.
    """

    def analyze(self, crawl: CrawlResult) -> SemanticReport:
        issues: list[GeoIssue] = []

        h_score = self._heading_structure_score(crawl.headings, issues)
        p_score = self._paragraph_clarity_score(crawl.text, issues)
        d_score = self._semantic_density_score(crawl.text, crawl.headings, issues)
        chunks = self._build_chunks(crawl.text, crawl.headings)
        c_score = self._chunk_quality_score(chunks, issues)
        r_score = self._readability_score(crawl.text, issues)

        return SemanticReport(
            url=crawl.url,
            heading_structure_score=h_score,
            paragraph_clarity_score=p_score,
            semantic_density_score=d_score,
            chunk_quality_score=c_score,
            readability_score=r_score,
            chunks=chunks,
            issues=issues,
        )

    # ------------------------------------------------------------------
    # 1. Heading structure (0–1)
    # ------------------------------------------------------------------

    def _heading_structure_score(
        self, headings: list[dict], issues: list[GeoIssue]
    ) -> float:
        if not headings:
            issues.append(GeoIssue(
                level=IssueLevel.CRITICAL,
                code="NO_HEADINGS",
                message="No headings found. AI cannot segment this page.",
                fix="Add H1–H3 headings to structure your content.",
            ))
            return 0.0

        levels = [int(h["level"][1]) for h in headings]
        h1_count = levels.count(1)
        score = 1.0

        if h1_count == 0:
            issues.append(GeoIssue(
                level=IssueLevel.CRITICAL,
                code="MISSING_H1",
                message="No H1 heading found.",
                fix="Add exactly one H1 that clearly states the page topic.",
            ))
            score -= 0.4

        elif h1_count > 1:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="MULTIPLE_H1",
                message=f"Found {h1_count} H1 headings. Use only one.",
                fix="Consolidate to a single H1.",
            ))
            score -= 0.2

        # Check hierarchy skips (e.g. H1 → H4 with no H2/H3)
        for i in range(1, len(levels)):
            if levels[i] - levels[i - 1] > 1:
                issues.append(GeoIssue(
                    level=IssueLevel.WARNING,
                    code="HEADING_HIERARCHY_SKIP",
                    message=f"Heading level skips from H{levels[i-1]} to H{levels[i]}.",
                    fix="Use sequential heading levels without skipping.",
                ))
                score -= 0.1
                break  # report once

        # Reward having multiple H2s (good chunking signal)
        h2_count = levels.count(2)
        if h2_count >= 3:
            score = min(1.0, score + 0.1)

        return round(max(0.0, score), 3)

    # ------------------------------------------------------------------
    # 2. Paragraph clarity (0–1)
    # ------------------------------------------------------------------

    def _paragraph_clarity_score(self, text: str, issues: list[GeoIssue]) -> float:
        if not text.strip():
            return 0.0

        paragraphs = [p.strip() for p in text.split("\n\n") if len(p.strip()) > 40]
        if not paragraphs:
            return 0.3

        long_paras = [p for p in paragraphs if len(p.split()) > 120]
        ratio = len(long_paras) / len(paragraphs)

        if ratio > 0.4:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="LONG_PARAGRAPHS",
                message=f"{int(ratio * 100)}% of paragraphs exceed 120 words. Hard to chunk for RAG.",
                fix="Break long paragraphs into shorter, focused blocks (60–100 words each).",
            ))

        score = 1.0 - (ratio * 0.6)
        return round(max(0.0, min(1.0, score)), 3)

    # ------------------------------------------------------------------
    # 3. Semantic density (0–1)
    # ------------------------------------------------------------------

    def _semantic_density_score(
        self, text: str, headings: list[dict], issues: list[GeoIssue]
    ) -> float:
        words = text.split()
        if not words:
            return 0.0

        word_count = len(words)
        heading_count = len(headings)

        # Density: headings per 500 words (ideal ~1.5–3)
        density = (heading_count / word_count) * 500 if word_count > 0 else 0

        if density < 1.0:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="LOW_SEMANTIC_DENSITY",
                message="Low heading density. AI struggles to identify content boundaries.",
                fix="Add more H2/H3 subheadings (aim for one every 200–400 words).",
            ))
            score = density / 1.0
        elif density > 6.0:
            issues.append(GeoIssue(
                level=IssueLevel.INFO,
                code="HIGH_HEADING_DENSITY",
                message="Very high heading density — content may be too fragmented.",
                fix="Ensure each section has enough body text to be self-contained.",
            ))
            score = max(0.5, 1.0 - (density - 6.0) * 0.05)
        else:
            # Sweet spot: score proportional to how close to ideal (2.0)
            score = 1.0 - abs(density - 2.0) / 4.0

        return round(max(0.0, min(1.0, score)), 3)

    # ------------------------------------------------------------------
    # 4. Chunk quality — RAG-readiness (0–1)
    # ------------------------------------------------------------------

    def _build_chunks(
        self, text: str, headings: list[dict]
    ) -> list[SemanticChunk]:
        """Split content into heading-delimited chunks and score each."""
        chunks: list[SemanticChunk] = []

        # Split on heading markers embedded in text (best-effort)
        heading_texts = {h["text"] for h in headings}
        sections: list[tuple[str, str]] = []

        current_heading = ""
        current_lines: list[str] = []

        for line in text.splitlines():
            stripped = line.strip()
            if stripped in heading_texts:
                if current_lines:
                    sections.append((current_heading, "\n".join(current_lines)))
                current_heading = stripped
                current_lines = []
            else:
                if stripped:
                    current_lines.append(stripped)

        if current_lines:
            sections.append((current_heading, "\n".join(current_lines)))

        if not sections:
            # Fallback: treat full text as one chunk
            sections = [("", text)]

        for idx, (heading, body) in enumerate(sections):
            words = body.split()
            word_count = len(words)

            first_sentence = _SENTENCE_SPLIT_RE.split(body.strip())[0] if body.strip() else ""
            has_definition = any(
                d in first_sentence.lower() for d in _DEFINITION_STARTERS
            )
            # Anchor = first sentence is ≥8 words and ends with punctuation
            has_anchor = (
                len(first_sentence.split()) >= 8
                and first_sentence[-1:] in ".!?"
            )

            # Score: 60–200 words = ideal chunk size for RAG
            if 60 <= word_count <= 200:
                size_score = 1.0
            elif word_count < 60:
                size_score = word_count / 60
            else:
                size_score = max(0.4, 1.0 - (word_count - 200) / 400)

            # Bonuses
            bonus = (0.1 if has_definition else 0) + (0.1 if has_anchor else 0)
            chunk_score = round(min(1.0, size_score + bonus), 3)

            chunks.append(SemanticChunk(
                index=idx,
                heading=heading,
                text=body[:500],  # truncate stored text
                word_count=word_count,
                has_definition=has_definition,
                has_anchor_sentence=has_anchor,
                retrievability_score=chunk_score,
            ))

        return chunks

    def _chunk_quality_score(
        self, chunks: list[SemanticChunk], issues: list[GeoIssue]
    ) -> float:
        if not chunks:
            return 0.0

        scores = [c.retrievability_score for c in chunks]
        avg = statistics.mean(scores)

        poor_chunks = [c for c in chunks if c.retrievability_score < 0.4]
        if poor_chunks:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="POOR_CHUNKS",
                message=f"{len(poor_chunks)} content sections have low RAG retrievability.",
                fix="Ensure each section has 60–200 words and starts with a clear topic sentence.",
            ))

        no_anchor = [c for c in chunks if not c.has_anchor_sentence and c.word_count > 30]
        if len(no_anchor) > len(chunks) // 2:
            issues.append(GeoIssue(
                level=IssueLevel.INFO,
                code="WEAK_ANCHOR_SENTENCES",
                message="Most sections lack strong opening (anchor) sentences.",
                fix="Start each section with a complete, self-contained sentence that summarises the section.",
            ))

        return round(avg, 3)

    # ------------------------------------------------------------------
    # 5. Readability — simplified Flesch-Kincaid estimate (0–1)
    # ------------------------------------------------------------------

    def _readability_score(self, text: str, issues: list[GeoIssue]) -> float:
        sentences = [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if len(s.strip()) > 5]
        if not sentences:
            return 0.5

        words_per_sentence = [len(s.split()) for s in sentences]
        avg_wps = statistics.mean(words_per_sentence)

        all_words = text.split()
        syllable_counts = [max(1, len(_VOWEL_RE.findall(w))) for w in all_words]
        avg_syllables = statistics.mean(syllable_counts) if syllable_counts else 1.5

        # Flesch Reading Ease ≈ 206.835 − 1.015×(words/sentence) − 84.6×(syllables/word)
        fre = 206.835 - (1.015 * avg_wps) - (84.6 * avg_syllables)
        fre = max(0.0, min(100.0, fre))

        if fre < 30:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="LOW_READABILITY",
                message=f"Content readability is very low (FRE ≈ {fre:.0f}). Hard for AI to parse.",
                fix="Use shorter sentences and simpler vocabulary where possible.",
            ))
        elif fre < 50:
            issues.append(GeoIssue(
                level=IssueLevel.INFO,
                code="MODERATE_READABILITY",
                message=f"Moderate readability (FRE ≈ {fre:.0f}). Consider simplifying.",
                fix="Aim for Flesch Reading Ease ≥ 60 for better AI parsability.",
            ))

        return round(fre / 100.0, 3)
