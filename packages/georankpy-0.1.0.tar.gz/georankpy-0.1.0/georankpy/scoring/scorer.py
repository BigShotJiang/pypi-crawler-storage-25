"""
GeoScorer — Computes the final GEO score from all analysis dimensions.

Score breakdown (total 100 pts):
  semantic_clarity       25 pts
  metadata_completeness  20 pts
  chunk_retrievability   20 pts
  schema_quality         15 pts
  entity_richness        10 pts
  llms_txt_quality       10 pts
"""

from __future__ import annotations

from georankpy.core.models import (
    CrawlResult,
    Entity,
    GeoIssue,
    GeoScore,
    IssueLevel,
    ScoreBreakdown,
    ScoreBand,
    SemanticReport,
)


class GeoScorer:
    """Computes multi-dimensional GEO scores."""

    def score(
        self,
        crawl: CrawlResult,
        semantic: SemanticReport,
        entities: list[Entity],
    ) -> GeoScore:
        issues: list[GeoIssue] = []
        recommendations: list[str] = []

        bd = ScoreBreakdown(
            semantic_clarity=self._semantic_clarity(semantic, issues, recommendations),
            metadata_completeness=self._metadata_completeness(crawl, issues, recommendations),
            chunk_retrievability=self._chunk_retrievability(semantic, issues),
            schema_quality=self._schema_quality(crawl, issues, recommendations),
            entity_richness=self._entity_richness(entities, issues, recommendations),
            llms_txt_quality=self._llms_txt_quality(crawl, issues, recommendations),
        )

        total = round(bd.total)
        band = GeoScore.band_for(total)

        return GeoScore(
            geo_score=total,
            band=band,
            breakdown=bd,
            issues=issues,
            recommendations=recommendations,
        )

    # ------------------------------------------------------------------
    # Dimension scorers
    # ------------------------------------------------------------------

    def _semantic_clarity(
        self, semantic: SemanticReport, issues: list, recs: list
    ) -> float:
        """0–25 pts based on semantic report overall score."""
        issues.extend(semantic.issues)
        raw = semantic.overall_score  # 0–1
        score = raw * 25

        if raw < 0.5:
            recs.append(
                "Improve semantic structure: add clear H2/H3 headings every 200–400 words "
                "and start sections with self-contained topic sentences."
            )
        return round(score, 2)

    def _metadata_completeness(
        self, crawl: CrawlResult, issues: list, recs: list
    ) -> float:
        """0–20 pts. Title + description + OG tags + canonical."""
        m = crawl.metadata
        score = 0.0

        if m.title:
            score += 5
        else:
            issues.append(GeoIssue(
                level=IssueLevel.CRITICAL,
                code="MISSING_TITLE",
                message="Page has no <title> tag.",
                fix="Add a descriptive <title> tag.",
            ))

        if m.description:
            score += 4
            if len(m.description) < 50:
                issues.append(GeoIssue(
                    level=IssueLevel.WARNING,
                    code="SHORT_DESCRIPTION",
                    message="Meta description is too short (<50 chars).",
                    fix="Write a 120–160 character meta description.",
                ))
                score -= 1
        else:
            issues.append(GeoIssue(
                level=IssueLevel.CRITICAL,
                code="MISSING_META_DESCRIPTION",
                message="No meta description found.",
                fix="Add a 120–160 character meta description summarising the page.",
            ))

        if m.og_title and m.og_description:
            score += 4
        else:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="MISSING_OG_TAGS",
                message="Open Graph tags (og:title, og:description) are missing.",
                fix="Add og:title and og:description meta tags for social and AI sharing.",
            ))

        if m.canonical:
            score += 4
        else:
            issues.append(GeoIssue(
                level=IssueLevel.INFO,
                code="MISSING_CANONICAL",
                message="No canonical URL tag found.",
                fix="Add <link rel='canonical' href='...'> to prevent duplicate content issues.",
            ))

        if m.og_image:
            score += 3

        if score < 12:
            recs.append("Complete all metadata: title, meta description, Open Graph tags, and canonical URL.")

        return round(min(20.0, score), 2)

    def _chunk_retrievability(
        self, semantic: SemanticReport, issues: list
    ) -> float:
        """0–20 pts based on average chunk retrievability score."""
        if not semantic.chunks:
            return 0.0
        avg = sum(c.retrievability_score for c in semantic.chunks) / len(semantic.chunks)
        return round(avg * 20, 2)

    def _schema_quality(
        self, crawl: CrawlResult, issues: list, recs: list
    ) -> float:
        """0–15 pts for structured data richness."""
        m = crawl.metadata
        score = 0.0

        if m.schema_types:
            score += 5  # has any schema
            if m.has_faq_schema:
                score += 4
            if m.has_article_schema:
                score += 3
            if m.has_organization_schema:
                score += 3
        else:
            issues.append(GeoIssue(
                level=IssueLevel.CRITICAL,
                code="NO_SCHEMA_MARKUP",
                message="No JSON-LD schema markup found.",
                fix="Add Schema.org markup (Article, FAQPage, Organization) via JSON-LD.",
            ))
            recs.append(
                "Add JSON-LD structured data: at minimum Organization and FAQPage schemas "
                "dramatically improve AI citation likelihood."
            )

        return round(min(15.0, score), 2)

    def _entity_richness(
        self, entities: list[Entity], issues: list, recs: list
    ) -> float:
        """0–10 pts based on number and diversity of extracted entities."""
        if not entities:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="LOW_ENTITY_RICHNESS",
                message="Very few named entities detected.",
                fix="Include specific technologies, organizations, and concepts relevant to your domain.",
            ))
            recs.append("Name specific technologies, organizations, and methodologies to improve entity richness.")
            return 0.0

        unique_types = len({e.type for e in entities})
        count_score = min(5.0, len(entities) / 4.0)    # up to 5 pts for quantity
        type_score = min(5.0, unique_types * 1.5)       # up to 5 pts for diversity

        if unique_types < 2:
            recs.append("Mention different types of entities: people, organizations, technologies, and locations.")

        return round(count_score + type_score, 2)

    def _llms_txt_quality(
        self, crawl: CrawlResult, issues: list, recs: list
    ) -> float:
        """0–10 pts for llms.txt presence and quality."""
        if not crawl.has_llms_txt:
            issues.append(GeoIssue(
                level=IssueLevel.WARNING,
                code="MISSING_LLMS_TXT",
                message="No /llms.txt file found.",
                fix="Generate and host an llms.txt file. Use: georank generate llms <url>",
            ))
            recs.append("Create an /llms.txt file to give AI systems a structured overview of your site.")
            return 0.0

        content = crawl.llms_txt_content
        score = 5.0  # present

        if len(content) > 300:
            score += 3
        if "## " in content or "# " in content:
            score += 2  # has sections

        return round(min(10.0, score), 2)
