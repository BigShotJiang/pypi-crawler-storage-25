"""
GeoRankPy — Generative Engine Optimization Toolkit
====================================================

Make your website visible to AI systems: ChatGPT, Claude,
Gemini, Perplexity, RAG pipelines, and autonomous agents.

Quick start
-----------
>>> from georankpy import audit
>>> result = audit("https://example.com")
>>> print(result.geo_score)
>>> print(result.issues)

>>> from georankpy import generate_llms_txt
>>> llms_txt = generate_llms_txt("https://example.com")
"""

from georankpy.core.engine import GeoEngine
from georankpy.core.models import AuditResult, GeoScore, SemanticReport
from georankpy.api import audit, generate_llms_txt, analyze

__all__ = [
    "audit",
    "generate_llms_txt",
    "analyze",
    "GeoEngine",
    "AuditResult",
    "GeoScore",
    "SemanticReport",
]

__version__ = "0.1.0"
__author__ = "Akash Nath"
