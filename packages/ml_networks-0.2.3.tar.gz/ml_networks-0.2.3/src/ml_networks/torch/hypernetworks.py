"""ハイパーネットワークを扱うモジュール."""

from __future__ import annotations

import warnings
from typing import Any, Literal

import numpy as np
import pytorch_lightning as pl
import torch
import torch.nn as nn
from torch.nn import init

from ml_networks.config import MLPConfig
from ml_networks.torch.layers import MLPLayer

Shape = tuple[int, ...]

InputMode = Literal["cos|sin", "z|1-z"] | None

encoding_multiplier: dict[InputMode, int] = {
    None: 1,
    "cos|sin": 2,
    "z|1-z": 2,
}


def _same_keys(
    required: dict[str, Any],
    provided: dict[str, Any],
    name: str = "",
) -> None:
    """Check if two dictionaries have the same keys.

    Args:
        required: A dictionary with required keys.
        provided: A dictionary with provided keys.
        name: A string name to identify the dictionaries.

    Raises
    ------
    ValueError
        If the dictionaries have missing or unexpected keys.

    Examples
    --------
    >>> required = {"a": 1, "b": 2}
    >>> provided = {"a": 1, "b": 2}
    >>> _same_keys(required, provided)
    >>> provided = {"a": 1}
    >>> _same_keys(required, provided)  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
    ValueError: Missing : ['b']
    """
    missing = required.keys() - provided.keys()
    if len(missing) > 0:
        msg = f"Missing {name}: {list(missing)}"
        raise ValueError(msg)

    unexpected = provided.keys() - required.keys()
    if len(unexpected) > 0:
        msg = f"Unexpected {name}: {list(missing)}"
        raise ValueError(msg)


class HyperNetMixin:
    input_shapes: dict[str, Shape]
    output_shapes: dict[str, Shape]
    encoding: InputMode

    def encode_inputs(self, inputs: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        """Encode the inputs using the specified `encoding` mode.

        Args:
            inputs: A dictionary of input names and shapes.

        Returns
        -------
            dict[str, Shape]: A dictionary of encoded input names and shapes.

        Examples
        --------
        >>> class TestHyperNet(HyperNetMixin):
        ...     def __init__(self):
        ...         self.input_shapes = {"x": (2,)}
        ...         self.encoding = "cos|sin"
        >>> net = TestHyperNet()
        >>> inputs = {"x": torch.tensor([[0.5, 0.3]])}
        >>> encoded = net.encode_inputs(inputs)
        >>> encoded["x"].shape
        torch.Size([1, 4])
        """
        if self.encoding is None:
            return inputs
        return {k: encode_input(x, mode=self.encoding) for k, x in inputs.items()}

    def flat_input_size(self) -> int:
        """Return the flat input size after encoding.

        Returns
        -------
            int: The flat input size.

        Examples
        --------
        >>> class TestHyperNet(HyperNetMixin):
        ...     def __init__(self):
        ...         self.input_shapes = {"x": (2,), "y": (3,)}
        ...         self.encoding = "cos|sin"
        >>> net = TestHyperNet()
        >>> net.flat_input_size()
        10
        """
        flat_input_size = sum(int(np.prod(v)) for v in self.input_shapes.values())
        flat_input_size *= encoding_multiplier[self.encoding]
        return flat_input_size

    def flat_output_size(self) -> int:
        """Return the flat output size.

        Returns
        -------
            int: The flat output size.

        Examples
        --------
        >>> class TestHyperNet(HyperNetMixin):
        ...     def __init__(self):
        ...         self.output_shapes = {"x": (2,), "y": (3,)}
        >>> net = TestHyperNet()
        >>> net.flat_output_size()
        5
        """
        return sum(int(np.prod(v)) for v in self.output_shapes.values())

    def output_offsets(self) -> dict[str, tuple[int, int]]:
        """Return the output offsets.

        Returns
        -------
            dict[str, Tuple[int, int]]: A dictionary of output names and
            their corresponding offsets and sizes.

        Examples
        --------
        >>> class TestHyperNet(HyperNetMixin):
        ...     def __init__(self):
        ...         self.output_shapes = {"x": (2,), "y": (3,)}
        >>> net = TestHyperNet()
        >>> offsets = net.output_offsets()
        >>> offsets["x"]
        (0, 2)
        >>> offsets["y"]
        (2, 3)
        """
        offset = 0
        offsets = {}
        for name, shape in self.output_shapes.items():
            size = int(np.prod(shape))
            offsets[name] = (offset, size)
            offset += size
        return offsets

    def _validate_inputs(self, inputs: dict[str, torch.Tensor]) -> int:
        """Validate the inputs.

        Args:
            inputs (dict[str, Tensor]): A dictionary of input names and their corresponding tensors

        Returns
        -------
            int: The batch dimension.

        Raises
        ------
        ValueError
            If the input shapes are not as expected or if different batch dimensions are found.

        Examples
        --------
        >>> class TestHyperNet(HyperNetMixin):
        ...     def __init__(self):
        ...         self.input_shapes = {"x": (2,), "y": (3,)}
        >>> net = TestHyperNet()
        >>> inputs = {"x": torch.randn(1, 2), "y": torch.randn(1, 3)}
        >>> net._validate_inputs(inputs)
        1
        >>> inputs = {"x": torch.randn(2,), "y": torch.randn(3,)}
        >>> net._validate_inputs(inputs)
        1
        """
        _same_keys(self.input_shapes, inputs, name="inputs")

        for name, required_shape in self.input_shapes.items():
            shape = inputs[name].shape

            # If batch dimension is already provided
            if shape[1:] == required_shape:
                continue

            # If no batch dimension is provided, but shape is correct
            if shape == required_shape:
                # Add batch dimension
                inputs[name] = inputs[name][None]
                continue

            error_msg = f"Wrong shape for {name}, expected {required_shape} or {('B', *required_shape)}, got {shape}"
            raise ValueError(error_msg)

        # All batch dims must match
        batch_dims = [x.shape[0] for x in inputs.values()]
        if len(set(batch_dims)) > 1:
            msg = f"Multiple batch dimensions found: {batch_dims}"
            raise ValueError(msg)

        return batch_dims[0]

    def flatten_inputs(self, inputs: dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Flattens the input tensors into a single tensor along the last dimension.

        Args:
            inputs (dict[str, torch.Tensor]): A dictionary of input tensor names and tensor values.

        Returns
        -------
            Tensor: The flattened input tensor.

        Examples
        --------
        >>> class TestHyperNet(HyperNetMixin):
        ...     def __init__(self):
        ...         self.input_shapes = {"x": (2,), "y": (3,)}
        >>> net = TestHyperNet()
        >>> inputs = {"x": torch.randn(1, 2), "y": torch.randn(1, 3)}
        >>> flat = net.flatten_inputs(inputs)
        >>> flat.shape
        torch.Size([1, 5])
        """
        batch_dim = self._validate_inputs(inputs)

        return torch.cat(
            [inputs[hp].view(batch_dim, -1) for hp in sorted(self.input_shapes)],
            dim=-1,
        )

    def unflatten_output(self, flat_output: torch.Tensor) -> dict[str, torch.Tensor]:
        """
        Unflattens the output tensor into a dictionary of named tensors.

        Args:
            flat_output (Tensor): The flattened output tensor.

        Returns
        -------
            dict[str, Tensor]: A dictionary of named tensors.

        Examples
        --------
        >>> class TestHyperNet(HyperNetMixin):
        ...     def __init__(self):
        ...         self.output_shapes = {"x": (2,), "y": (3,)}
        ...         self._output_offsets = {"x": (0, 2), "y": (2, 3)}
        >>> net = TestHyperNet()
        >>> flat_output = torch.randn(1, 5)
        >>> outputs = net.unflatten_output(flat_output)
        >>> outputs["x"].shape
        torch.Size([1, 2])
        >>> outputs["y"].shape
        torch.Size([1, 3])
        """
        outputs = {}
        batch_dim = flat_output.shape[0]
        for name, shape in self.output_shapes.items():
            shape_tuple = (batch_dim, *shape)
            offsets = self.output_offsets()[name]
            outputs[name] = flat_output.narrow(1, offsets[0], offsets[1]).view(shape_tuple)
        return outputs


class HyperNet(pl.LightningModule, HyperNetMixin):
    """A hypernetwork that generates weights for a target network. Shape is dict[str, Tuple[int, ...]].

    Args:
        input_dim: The dimension of the input.
        output_shapes: The shapes of the primary network weights being predicted.
        mlp_cfg: Configuration for the MLP backbone.
        encoding: The input encoding mode. Defaults to None.

    Examples
    --------
    >>> from ml_networks.config import MLPConfig, LinearConfig
    >>> input_dim = 10
    >>> cond_dim = 128
    >>> target_net = nn.Linear(10, 5)
    >>> output_params = target_net.state_dict()
    >>> mlp_cfg = MLPConfig(
    ...     hidden_dim=64,
    ...     n_layers=2,
    ...     output_activation="ReLU",
    ...     linear_cfg=LinearConfig(
    ...         activation="ReLU",
    ...     )
    ... )
    >>> net = HyperNet(cond_dim, output_params, mlp_cfg)
    >>> condition = torch.randn(2, cond_dim)
    >>> x = torch.randn(2, input_dim)
    >>> param = net(condition)
    >>> outputs = torch.func.functional_call(target_net, param, x)
    >>> outputs.shape
    torch.Size([2, 5])
    """

    def __init__(
        self,
        input_dim: int,
        output_params: dict[str, Shape],
        fc_cfg: MLPConfig | None = None,
        encoding: InputMode = None,
    ) -> None:
        super().__init__()

        self.input_dim = input_dim
        self.output_shapes = output_params
        self.encoding = encoding

        # Cache this property to avoid recomputation
        self._output_offsets = self.output_offsets()

        self.backbone: nn.Module
        if fc_cfg is not None:
            self.backbone = MLPLayer(
                self.input_dim,
                self.flat_output_size(),
                fc_cfg,
            )
        else:
            self.backbone = nn.Linear(
                self.input_dim,
                self.flat_output_size(),
            )

    def forward(self, inputs: torch.Tensor) -> dict[str, torch.Tensor]:
        """Perform a forward pass of the neural network.

        Args:
            inputs: The input tensors.

        Returns
        -------
            A dictionary of output tensors.

        Examples
        --------
        >>> from ml_networks.config import MLPConfig, LinearConfig
        >>> input_dim = 10
        >>> output_shapes = {"weight": (5, 10), "bias": (5,)}
        >>> mlp_cfg = MLPConfig(
        ...     hidden_dim=64,
        ...     n_layers=2,
        ...     output_activation="ReLU",
        ...     linear_cfg=LinearConfig(
        ...         activation="ReLU",
        ...         norm="none",
        ...         dropout=0.0,
        ...         bias=True
        ...     )
        ... )
        >>> net = HyperNet(input_dim, output_shapes, mlp_cfg)
        >>> x = torch.randn(2, input_dim)
        >>> outputs = net(x)
        >>> outputs["weight"].shape
        torch.Size([2, 5, 10])
        >>> outputs["bias"].shape
        torch.Size([2, 5])
        """
        if self.encoding is not None:
            inputs = encode_input(inputs, self.encoding)

        flat_output = self.backbone(inputs)
        return self.unflatten_output(flat_output)


def encode_input(input: torch.Tensor, mode: InputMode = "cos|sin") -> torch.Tensor:
    """Encode the input tensor based on the specified mode.

    Args
    ----
    input : Tensor
        The input tensor.
    mode : InputMode
        The encoding mode.

    Returns
    -------
    Tensor
        The encoded tensor.

    Raises
    ------
    ValueError
        If an unsupported encoding mode is given.

    Examples
    --------
    >>> x = torch.tensor([[0.5, 0.3], [0.7, 0.9]])
    >>> encoded = encode_input(x, "cos|sin")
    >>> encoded.shape
    torch.Size([2, 4])
    >>> x = torch.tensor([[0.5, 0.3], [0.7, 0.9]])
    >>> encoded = encode_input(x, "z|1-z")
    >>> encoded.shape
    torch.Size([2, 4])
    >>> x = torch.tensor([[0.5, 0.3], [0.7, 0.9]])
    >>> encoded = encode_input(x, None)
    >>> encoded.shape
    torch.Size([2, 2])
    """
    z = input

    if mode is None:
        return input

    if mode == "cos|sin":
        _check_tensor_range(input, low=0, high=1)
        scaled_z = torch.pi * z / 2

        return torch.cat([torch.cos(scaled_z), torch.sin(scaled_z)], dim=-1)

    if mode == "z|1-z":
        return torch.cat([z, 1 - z], dim=-1)
    msg = f"Unsupported encoding mode: {mode}"
    raise ValueError(msg)


def _check_tensor_range(tensor: torch.Tensor, low: float, high: float) -> None:
    """
    Check if the input tensor is within specified range.

    Args:
        tensor (Tensor): The input tensor.
        low (float): The lower bound of the range.
        high (float): The upper bound of the range.

    Raises
    ------
        UserWarning: If the input tensor is outside the specified range.

    Examples
    --------
    >>> x = torch.tensor([[0.5, 0.3], [0.7, 0.9]])
    >>> _check_tensor_range(x, 0, 1)  # No warning
    >>> x = torch.tensor([[0.5, 0.3], [0.7, 1.1]])
    """
    if (tensor < low).any() or (tensor > high).any():
        warnings.warn(f"Input tensor has dimensions outside of [{low},{high}].", stacklevel=2)


Nonlinearity = Literal[
    "linear",
    "conv1d",
    "conv2d",
    "conv3d",
    "conv_transpose1d",
    "conv_transpose2d",
    "conv_transpose3d",
    "sigmoid",
    "tanh",
    "relu",
    "leaky_relu",
    "selu",
]


def initialize_weight(
    weight: torch.Tensor,
    distribution: str | None,
    nonlinearity: str | None = "LeakyReLU",
) -> None:
    """Initialize weight tensor using the specified distribution and nonlinearity function.

    Args:
        weight (torch.Tensor): Tensor to be initialized.
        distribution (str, optional): Distribution to use for initialization.
        nonlinearity (str, optional): Nonlinearity function to use. Defaults to "LeakyReLU".

    Raises
    ------
    ValueError
        When the specified distribution is not supported.

    Examples
    --------
    >>> weight = torch.empty(2, 3)
    >>> initialize_weight(weight, "kaiming_normal")
    >>> weight = torch.empty(2, 3)
    >>> initialize_weight(weight, "zeros")
    >>> weight = torch.empty(2, 3)
    >>> initialize_weight(weight, "invalid")  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
    ValueError: Unsupported weight distribution 'invalid'
    """
    if distribution is None:
        return

    nl: Nonlinearity = "linear"
    if nonlinearity is not None:
        n = nonlinearity.lower()
        if n == "leakyrelu":
            n = "leaky_relu"
        if n in {"silu", "gelu", "mish", "tanhexp", "elu"}:
            n = "leaky_relu"
        # 型チェックのために Nonlinearity に制限
        if n in {
            "linear",
            "conv1d",
            "conv2d",
            "conv3d",
            "conv_transpose1d",
            "conv_transpose2d",
            "conv_transpose3d",
            "sigmoid",
            "tanh",
            "relu",
            "leaky_relu",
            "selu",
        }:
            nl = n  # type: ignore[assignment]

    gain = init.calculate_gain(nl)

    if distribution == "zeros":
        init.zeros_(weight)
    elif distribution == "kaiming_normal":
        init.kaiming_normal_(weight, nonlinearity=nl)
    elif distribution == "kaiming_uniform":
        init.kaiming_uniform_(weight, nonlinearity=nl)
    elif distribution == "kaiming_normal_fanout":
        init.kaiming_normal_(weight, nonlinearity=nl, mode="fan_out")
    elif distribution == "kaiming_uniform_fanout":
        init.kaiming_uniform_(weight, nonlinearity=nl, mode="fan_out")
    elif distribution == "glorot_normal":
        init.xavier_normal_(weight, gain=gain)
    elif distribution == "glorot_uniform":
        init.xavier_uniform_(weight, gain)
    elif distribution == "orthogonal":
        init.orthogonal_(weight, gain)
    else:
        msg = f"Unsupported weight distribution '{distribution}'"
        raise ValueError(msg)


def initialize_bias(bias: torch.Tensor, distribution: float | None = 0.0) -> None:
    """Initialize the bias tensor of a layer using the given distribution.

    Args:
        bias (nn.Parameter): the bias tensor to be initialized
        distribution (float): the distribution to use for initialization, default is 0 (constant)

    Raises
    ------
    ValueError
        When the specified distribution is not supported.

    Examples
    --------
    >>> bias = torch.empty(3)
    >>> initialize_bias(bias, 0.1)
    >>> bias = torch.empty(3)
    >>> initialize_bias(bias, "invalid")  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
    ValueError: Unsupported bias distribution 'invalid'
    """
    if distribution is None:
        return

    if isinstance(distribution, int | float):
        init.constant_(bias, distribution)
        return

    msg = f"Unsupported bias distribution '{distribution}'"
    raise ValueError(msg)


def initialize_layer(
    layer: nn.Module,
    distribution: str | None = "kaiming_normal",
    init_bias: float | None = 0.0,
    nonlinearity: str | None = "LeakyReLU",
) -> None:
    """Initialize the weight and bias tensors of a linear or convolutional layer using the given distribution.

    Args:
    - layer (nn.Module): the linear or convolutional layer to be initialized
    - distribution (str): the distribution to use for initialization, default is 'kaiming_normal'
    - init_bias (float): the initial value of the bias tensor, default is 0
    - nonlinearity (str): the nonlinearity function to use for initialization, default is "LeakyReLU"

    Examples
    --------
    >>> layer = nn.Linear(2, 3)
    >>> initialize_layer(layer, "kaiming_normal", 0.1)
    >>> layer = nn.Conv2d(2, 3, 3)
    >>> initialize_layer(layer, "kaiming_normal", 0.1)
    >>> layer = nn.BatchNorm2d(3)
    >>> initialize_layer(layer, "kaiming_normal", 0.1)  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
    AssertionError: Can only be applied to linear and conv layers, given BatchNorm2d
    """
    assert isinstance(
        layer,
        nn.Linear | nn.Conv1d | nn.Conv2d | nn.Conv3d,
    ), f"Can only be applied to linear and conv layers, given {layer.__class__.__name__}"

    initialize_weight(layer.weight, distribution, nonlinearity)
    if layer.bias is not None:
        initialize_bias(layer.bias, init_bias)


if __name__ == "__main__":
    import doctest

    doctest.testmod()
