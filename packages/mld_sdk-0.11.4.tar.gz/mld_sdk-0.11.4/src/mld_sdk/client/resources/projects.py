"""Projects resource for the MLD API client."""

from __future__ import annotations

from typing import Any

from mld_sdk.client._http import HTTPClient


class ProjectsAPI:
    """Project management operations."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(
        self,
        *,
        status: str | None = None,
        search: str | None = None,
        my_projects: bool = False,
        skip: int = 0,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List projects with optional filtering."""
        return self._http.get(
            "/projects",
            status=status,
            search=search,
            my_projects=my_projects if my_projects else None,
            skip=skip,
            limit=limit,
        )

    def get(self, project_id: int) -> dict[str, Any]:
        """Get a single project by ID."""
        return self._http.get(f"/projects/{project_id}")

    def create(
        self,
        *,
        name: str,
        description: str | None = None,
        tags: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new project."""
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        if tags is not None:
            body["tags"] = tags
        return self._http.post("/projects", json=body)

    def update(self, project_id: int, **fields: Any) -> dict[str, Any]:
        """Update a project."""
        return self._http.patch(f"/projects/{project_id}", json=fields)

    def delete(self, project_id: int) -> None:
        """Delete a project."""
        self._http.delete(f"/projects/{project_id}")

    def experiments(
        self,
        project_id: int,
        *,
        skip: int = 0,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List experiments belonging to a project."""
        return self._http.get(
            f"/projects/{project_id}/experiments",
            skip=skip,
            limit=limit,
        )

    def members(self, project_id: int) -> list[dict[str, Any]]:
        """List project members."""
        return self._http.get(f"/projects/{project_id}/members")
