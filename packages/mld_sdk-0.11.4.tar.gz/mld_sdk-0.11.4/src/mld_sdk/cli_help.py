"""Shared CLI help formatting with ANSI colors and command grouping."""

from __future__ import annotations

import os
import sys


def _supports_color() -> bool:
    """Return True if stdout likely supports ANSI color."""
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    return os.environ.get("TERM", "") != "dumb"


def _bold(text: str, c: bool) -> str:
    return f"\033[1m{text}\033[0m" if c else text


def _dim(text: str, c: bool) -> str:
    return f"\033[2m{text}\033[0m" if c else text


def _cyan(text: str, c: bool) -> str:
    return f"\033[36m{text}\033[0m" if c else text


def _green(text: str, c: bool) -> str:
    return f"\033[32m{text}\033[0m" if c else text


def format_help(
    title: str,
    description: str,
    groups: list[tuple[str, list[tuple[str, str]]]],
    *,
    prog: str | None = None,
) -> str:
    """Render grouped, colored help text.

    *groups* is a list of ``(group_name, [(cmd, description), ...])``.
    When *group_name* is empty, the header line is omitted (useful for
    subcommands that need only a flat list).

    *prog* overrides the program name used in the footer hint.
    Defaults to *title* (useful when *title* contains a version suffix).
    """
    c = _supports_color()
    footer_prog = prog or title

    lines = [
        "",
        f"  {_bold(title, c)}",
        f"  {_dim(description, c)}",
        "",
    ]

    for group_name, commands in groups:
        if group_name:
            lines.append(f"  {_bold(_cyan(group_name, c), c)}")
        for cmd, desc in commands:
            padded = f"{cmd:14s}"
            lines.append(f"    {_green(padded, c)}  {desc}")
        lines.append("")

    lines.append(
        f"  {_dim('Run', c)} {_green(f'{footer_prog} <command> --help', c)} "
        f"{_dim('for details.', c)}"
    )
    lines.append("")

    return "\n".join(lines)
