# forge-openai

Forge Verify guardrail for the [OpenAI Agents SDK](https://github.com/openai/openai-agents-python). Verifies every AI agent tool call against your policies **before** execution.

## Install

```bash
pip install forge-openai
```

## Quick Start

```python
import os
from agents import Agent, Runner, function_tool
from forge_openai import forge_tool_guardrail, forge_protect

os.environ["VERITERA_API_KEY"] = "vt_live_..."
os.environ["OPENAI_API_KEY"] = "sk-..."

# Define your tools
@function_tool
def send_payment(amount: float, recipient: str) -> str:
    """Send a payment to a recipient."""
    return f"Sent ${amount} to {recipient}"

@function_tool
def delete_record(record_id: str) -> str:
    """Delete a database record."""
    return f"Deleted {record_id}"

@function_tool
def read_balance() -> str:
    """Check account balance."""
    return "Balance: $50,000"

# Protect all tools with Forge — one line
agent = Agent(
    name="finance-bot",
    instructions="You help with financial operations.",
    tools=forge_protect(
        send_payment, delete_record, read_balance,
        policy="finance-controls",
        skip_actions=["read_balance"],  # read-only tools don't need verification
    ),
)

# Run the agent — Forge checks every tool call automatically
result = await Runner.run(agent, "Send $500 to vendor@acme.com")
```

## How It Works

1. Your agent decides to call a tool (e.g. `send_payment`)
2. **Before execution**, Forge checks the action against your policies
3. If **approved**: the tool runs normally
4. If **denied**: the LLM receives a denial message and can explain why to the user

No tool ever executes without verification. Every decision is logged with a cryptographic proof.

## Per-Tool Guardrail

```python
from forge_openai import forge_tool_guardrail

guardrail = forge_tool_guardrail(policy="email-controls")

@function_tool(tool_input_guardrails=[guardrail])
def send_email(to: str, subject: str, body: str) -> str:
    """Send an email."""
    return f"Email sent to {to}"
```

## Full Control

```python
from forge_openai import ForgeGuardrail

forge = ForgeGuardrail(
    api_key="vt_live_...",
    agent_id="prod-finance-bot",
    policy="finance-controls",
    fail_closed=True,
    skip_actions=["read_balance", "get_time"],
    on_blocked=lambda action, reason, result: print(f"BLOCKED: {action} — {reason}"),
    on_verified=lambda action, result: print(f"APPROVED: {action}"),
)

agent = Agent(
    name="finance-bot",
    tools=forge.protect(send_payment, delete_record),
    input_guardrails=[forge.input_guardrail()],  # also screen agent input
)
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `VERITERA_API_KEY` | Your Forge API key (starts with `vt_live_` or `vt_test_`) |

## License

MIT — [Veritera AI](https://veritera.ai)
