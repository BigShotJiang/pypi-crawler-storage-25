from sys import implementation as I, modules as M
if I.name != 'cpython': __import__('_warnings').warn('asyncutils is not yet tested in this python implementation', ImportWarning)
if I.version < (3, 12): raise ImportError('asyncutils currently only supports python 3.12 or above')
from time import monotonic as T
def time_since_boot(t=T(), T=T): return round(T()-t, 7)*1000 # noqa: B008
from .version import VersionInfo as V
__hexversion__, console_preloaded_submodules = int(__version__ := V('0.8.27')), (preloaded_submodules := frozenset(('config', 'constants', 'context', 'exceptions', 'version'))).union(('base', 'cli', 'console'))
def __getattr__(name, /, _=globals()):
    from ._internal import initialize as I; _.update(__getattr__=I.Module, __all__=I.a, submodules_map=I.s); del I
    try: return _[name]
    except KeyError: return __getattr__(name)
def __dir__(_=M[__name__]): return _.__all__
del V, I, T, M