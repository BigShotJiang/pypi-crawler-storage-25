'''Functions of utility one tier below the `base` submodule, such that they are not worth preloading but still quite useful.'''
from ._internal.types import AsyncLockLike, ToSyncFromLoopRV, TransientBlockFromLoopRV
from .exceptions import IgnoreErrors
from _collections_abc import AsyncGenerator, Awaitable, Callable, Coroutine, Generator
from asyncio.events import AbstractEventLoop
from asyncio.futures import Future
from asyncio.locks import BoundedSemaphore, Lock, Semaphore
from asyncio.tasks import Task
from typing import Any, Concatenate, Literal, overload
__all__ = 'aiter_from_f', 'get_future', 'lockf', 'new_tasks', 'safe_cancel', 'semaphore', 'sync_await', 'sync_lock', 'sync_lock_from_binder', 'to_async', 'to_sync', 'to_sync_from_loop', 'transient_block', 'transient_block_from_loop'
_ignore_cancellation: IgnoreErrors
'''Context manager to ignore :exc:`~asyncio.exceptions.CancelledError`. This annotation is for module-internal use only.'''
def get_future[T](aw: Awaitable[T], loop: AbstractEventLoop|None=...) -> Future[T]:
    '''Wrap an arbitrary awaitable `aw` in a task under `loop`, creating one and setting if required, and begin waiting on it.
    Critical exceptions are wrapped in :exc:`~exceptions.Critical`.
    This is as opposed to :meth:`~asyncio.base_events.BaseEventLoop.create_task`, which only takes coroutines.'''
def new_tasks[T](*coro: Coroutine[Any, Any, T]) -> Generator[Task[T]]: '''Yield eagerly started tasks wrapping the coroutines under a new event loop in order.'''
def to_sync[T, **P](f: Callable[P, Awaitable[T]], /, timeout: float|None=..., loop: AbstractEventLoop|None=...) -> Callable[P, T]: '''Convert a function that returns an awaitable to an sync function with the same signature, using the event loop `loop` when required or creating when necessary.'''
def to_sync_from_loop(loop: AbstractEventLoop) -> ToSyncFromLoopRV: '''A version of :func:`to_sync` that is a decorator factory, returning its partial under `loop=loop`.'''
def sync_await[T](aw: Awaitable[T], *, timeout: float|None=..., loop: AbstractEventLoop|None=...) -> T: '''Synchronously await the awaitable object `aw` under the given event loop `loop` with timeout `timeout`. It is preferred to use :func:`asyncio.run` to synchronously run one single top-level async function that awaits the necessary awaitables.'''
@overload
def semaphore(bounded: Literal[False]=..., workers: int=...) -> Semaphore: ...
@overload
def semaphore(bounded: Literal[True], workers: int=...) -> BoundedSemaphore: '''Simple helper to return a (bounded) semaphore of value `workers`, default :const:`context.SEMAPHORE_DEFAULT_VALUE`.'''
def lockf[T, **P](f: Callable[P, Awaitable[T]], /, lf: type[AsyncLockLike[Any]]=...) -> Callable[P, Coroutine[Any, Any, T]]: '''Apply a lock that implements the async lock interface, as created by `lf`, to a function `f` that returns an awaitable, also converting it to an async function.'''
def sync_lock[T, **P](l: Lock, /, timeout: float|None=...) -> Callable[[Callable[P, Awaitable[T]]], Callable[P, T]]: '''Decorator factory to ensure a function returning an awaitable only be called if a lock is acquired within `timeout`, also converting it to a sync function.'''
def sync_lock_from_binder[T, R, **P](f: Callable[[T], AsyncLockLike[Any]], /, timeout: float|None=...) -> Callable[[Callable[Concatenate[T, P], R]], Callable[Concatenate[T, P], R]]: '''Method version of :func:`sync_lock`, where `binder` is a function returning a suitable lock from the instance.'''
def to_async[T, **P](f: Callable[P, T], /, loop: AbstractEventLoop|None=...) -> tuple[Callable[P, Coroutine[Any, Any, T]], Callable[[], None]]: '''Returns a tuple `(asyncf, shutdown)`. asyncf is the async version of the original function (runs in an executor) and shutdown is a function to shut down the executor.'''
def aiter_from_f[T](f: Callable[[], Awaitable[T]], sentinel: T=..., /) -> AsyncGenerator[T]: '''Emulates the second form of the builtin :func:`iter` function in async, which the :func:`aiter` function does not have.'''
async def safe_cancel(fut: Future[Any], /) -> None:
    '''Cancel a single future and wait for the cancellation to complete asynchronously. The cancellation itself can be reliably cancelled.
    See :func:`~base.safe_cancel_batch` for a much more efficient way to cancel multiple futures at once.'''
@overload
def transient_block[T, **P](loop: AbstractEventLoop, f: Callable[P, T], /, *a: P.args, **k: P.kwargs) -> Future[T]: ...
@overload
def transient_block[T](loop: AbstractEventLoop, f: Callable[..., T], /, *a: Any, _threadsafe_: Literal[True], **k: Any) -> Future[T]: # type: ignore[overload-cannot-match]
    '''Run a function `f`, with the provided parameters passed straight through, in the event loop `loop`, and return a future for it.
    Assumes the loop is already running, so that its :meth:`run_in_executor` method is not used.
    Instead, schedule the function to run at the next iteration of the loop. To avoid overhead, the function should thus return fast.
    If `_threadsafe_` is `True`, then the function is scheduled in a thread-safe way, so that this can be called from threads not owning the loop.'''
def transient_block_from_loop(loop: AbstractEventLoop, *, threadsafe: bool=...) -> TransientBlockFromLoopRV: '''Return the partial of :func:`transient_block` under the specified `loop`.'''