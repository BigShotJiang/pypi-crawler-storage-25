"""Minimal install flow for the agentic-bootstrap CLI.

This slice implements four responsibilities:

1. Clone (or fast-forward) ``<remote_url>`` at ``<remote_ref>`` into
   ``<target>/.agentic/remote/``.
2. Symlink the six known shared overlay surfaces from the clone into the
   consumer repo, preserving any pre-existing real local directory at the
   same path (overlay precedence: local wins per surface).
3. When ``mcp_servers`` is provided, configure the three consumer-tool
   surfaces — ``.mcp.json`` (Claude Code), ``.vscode/mcp.json`` (VS Code),
   and ``.codex/config.toml`` (Codex CLI) — by deep-merging or
   tomlkit-replacing only the managed entries while preserving everything
   else the user had configured.
4. When ``<target>`` is a git repo, point ``core.hooksPath`` at the
   materialized ``scripts/hooks/git`` directory so git resolves shared
   hooks by name (``post-checkout``, ``pre-commit``, ``pre-push`` …).
   The parent ``scripts/hooks/`` symlink ships Python helpers and other
   non-git-hook files; setting ``core.hooksPath`` there makes git
   silently resolve nothing. See plan 0006 Slice 0.
5. Write ``<target>/.agentic-bootstrap.json`` describing the resolved remote,
   the materialized surfaces, and the configs that were touched. Older
   installs wrote ``.agentic-overlay.json``; the legacy file is migrated
   in-place on first run when present.

The ``doctor`` / ``repair`` / ``update`` / ``status`` subcommands land in
follow-on slices of E17-10 and are deliberately out of scope here.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from collections.abc import Iterable
from typing import Any, Mapping

import tomlkit

BOOTSTRAP_MANIFEST_NAME = ".agentic-bootstrap.json"
LEGACY_OVERLAY_MANIFEST_NAME = ".agentic-overlay.json"
# Deprecated alias kept for downstream code importing the old name. Points
# at the canonical (new) filename, NOT the legacy file. Reading legacy
# installs goes through _migrate_legacy_manifest below.
OVERLAY_MANIFEST_NAME = BOOTSTRAP_MANIFEST_NAME
SCHEMA_VERSION = 2
CLONE_SUBDIR = (".agentic", "remote")


def _build_install_manifest(
    *,
    remote_url: str,
    remote_ref: str,
    remote_sha: str,
    surfaces: list[dict[str, str]],
    configs: list[dict[str, str]],
    mcp_servers: Mapping[str, Mapping[str, Any]] | None,
) -> dict[str, object]:
    """Build the dict that will be written to ``.agentic-bootstrap.json``.

    ``mcp_servers`` is the mapping that ``install()`` actually used to
    write the three config surfaces. Persisting the sorted key list as
    ``manifest["mcp_servers"]`` gives ``sync_mcp_configs(prune_removed_managed=True)``
    an authoritative previously-managed provenance: any name in this
    list that disappears from the new managed set is a removal that
    sync may prune from the surface files; everything else is treated
    as third-party and left untouched.
    """
    return {
        "schema_version": SCHEMA_VERSION,
        "remote_url": remote_url,
        "remote_ref": remote_ref,
        "remote_sha": remote_sha,
        "surfaces": surfaces,
        "configs": configs,
        "mcp_servers": sorted(mcp_servers) if mcp_servers else [],
    }

# In the agentic-protocol-monorepo, the shared agentic-system surfaces live
# under packages/agentic-system/ rather than at the clone root. We probe this
# subdirectory first when resolving a surface in the clone, and fall back to
# the clone root for legacy/hoisted overlay layouts (and for the
# fake_remote_with_surfaces fixture used elsewhere in the test suite).
AGENTIC_SYSTEM_SUBDIR = "packages/agentic-system"

# Shared overlay surfaces materialized as symlinks into ``.agentic/remote``.
# Plan 0002 step 1 (3/3): per-agent surfaces (.claude/skills, .claude/commands,
# .github/prompts, .codex/skills) are no longer canonical in the overlay
# clone — they are generated artifacts produced by
# generate_agent_workflows.py during install. Only the truly shared
# surfaces remain symlinked here.
SHARED_SURFACES: tuple[str, ...] = (
    ".github/hooks",
    "scripts/hooks",
    "docs/agentic/contracts",
    # AHMCP-50 Slice 1: hoist canonical rule docs (development-workflow.md,
    # branch-review-guide.md, planning-artifact-home.md) to consumers.
    # Prior to this entry rule docs sat repo-local even though hooks and
    # skills cite them by path; only contracts propagated.
    "docs/agentic/rules",
    # Plan 0007 Slice 0: plan-targets surface and the optional git
    # plan-cat shell wrapper. Hoisted as directory symlinks so consumers
    # inherit Makefile.d/plans.mk and scripts/agentic/git-plan-cat.sh
    # (and any sibling files added in later slices) without re-running
    # bootstrap on every file addition. The Python logic the wrappers
    # invoke lives in the agent_handoff_mcp package, fetched on demand
    # by uvx — no Python module is hoisted via overlay.
    "Makefile.d",
    "scripts/agentic",
)

# Per-agent surfaces written by the generator into the target as real
# directories (not symlinks). Bootstrap ensures these exist as real
# dirs before the generator runs; pre-existing symlinks pointing into
# .agentic/remote/ (left over from the legacy overlay model) are
# replaced. Recorded in the manifest with ``source: "generated"``.
GENERATED_SURFACES: tuple[str, ...] = (
    ".claude/commands",
    ".claude/skills",
    ".github/prompts",
    ".codex/skills",
)

# Path to the generator script inside the cloned overlay.
GENERATOR_SCRIPT = "scripts/generate_agent_workflows.py"
GENERATOR_MANIFEST = "config/agent-workflows/portable_commands.json"
GENERATOR_SKILLS_SOURCE = "skills"

# Plan 0009 (AHMCP-40) lifecycle profile: hoist the lifecycle Make
# fragment and the Python runner package into the consumer overlay.
# Source paths are resolved through ``_resolve_in_clone`` so they pick
# up the ``packages/agentic-system/`` prefix in the monorepo layout and
# fall back to a flat layout for hoisted fixture remotes. Destination
# paths are flat under the consumer root because the runner/Makefile
# fragment must be reachable from a vanilla consumer with no monorepo
# packaging knowledge.
LIFECYCLE_HOISTS: tuple[tuple[str, str], ...] = (
    ("Makefile.d/lifecycle.mk", "Makefile.d/lifecycle.mk"),
    ("scripts/agentic/lifecycle", "scripts/agentic/lifecycle"),
)

# Sentinel block managed by ``_ensure_consumer_makefile_include`` so we
# can recognize and uninstall our edit without clobbering user content.
LIFECYCLE_INCLUDE_SENTINEL_BEGIN = "# >>> AGENTIC_BOOTSTRAP LIFECYCLE INCLUDE >>>"
LIFECYCLE_INCLUDE_SENTINEL_END = "# <<< AGENTIC_BOOTSTRAP LIFECYCLE INCLUDE <<<"
LIFECYCLE_INCLUDE_DIRECTIVE = "-include Makefile.d/*.mk"

# Profile contract (Plan 0009 §Constraints). ``minimal`` is the new
# default for the CLI; ``all`` preserves the legacy broad surface and
# remains the API default for backward compatibility with existing
# rehearsal/test harnesses that pre-date this contract.
PROFILE_MINIMAL = "minimal"
PROFILE_LIFECYCLE = "lifecycle"
PROFILE_ALL = "all"
SUPPORTED_PROFILES: frozenset[str] = frozenset(
    {PROFILE_MINIMAL, PROFILE_LIFECYCLE, PROFILE_ALL}
)

# Built-in managed-server map (Plan 0002 step 2a). The two MCP servers
# the agentic-protocol-monorepo ships, both runnable via ``uvx``. Package
# specs are pinned to the latest coordinated release so consumer repos do
# not drift when PyPI advances independently of their overlay tag. Used
# when callers pass ``mcp_servers="default"`` or, in the CLI, when
# ``--mcp-servers`` is omitted and ``--no-mcp-servers`` is not set.
# Operators wanting a custom managed map keep providing a JSON file via
# ``--mcp-servers <path>``.
DEFAULT_MCP_SERVERS: dict[str, dict[str, Any]] = {
    "agent-handoff-mcp": {
        "command": "uvx",
        "args": ["mcp-agent-handoff@0.11.1", "--workspace-root", ".", "serve-stdio"],
    },
    "agent-orchestrator-mcp": {
        "command": "uvx",
        "args": ["mcp-agent-orchestrator@0.4.5", "--workspace-root", ".", "serve-stdio"],
    },
}


class BootstrapManifestValidationError(RuntimeError):
    """Raised when the install manifest fails the cross-repo wire-shape contract."""


class RemoteUrlMismatchError(RuntimeError):
    """Raised when an existing ``.agentic/remote`` clone tracks a different
    ``origin`` URL than the one passed to ``install``.

    Silently rewriting the manifest while leaving the on-disk clone pointed at
    the old origin would make ``.agentic-bootstrap.json`` lie about provenance
    (E17-10-BR13-H-01). Operators get an actionable error instead.
    """


def _migrate_legacy_manifest(target: Path) -> Path | None:
    """One-shot rename of legacy ``.agentic-overlay.json`` to ``.agentic-bootstrap.json``.

    Renames only when the legacy file looks like a bootstrap manifest
    (top-level dict with a list ``surfaces`` key) so consumer-owned files
    that happen to share the legacy name are not touched. Prefers
    ``git mv`` when ``target`` is a git worktree so the rename is tracked
    in history; falls back to ``Path.rename`` otherwise. Returns the new
    path on success, ``None`` when no migration was needed or the legacy
    file did not match the bootstrap shape.
    """
    legacy = target / LEGACY_OVERLAY_MANIFEST_NAME
    canonical = target / BOOTSTRAP_MANIFEST_NAME
    if not legacy.is_file() or canonical.exists():
        return None
    try:
        data = json.loads(legacy.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict) or not isinstance(data.get("surfaces"), list):
        return None
    try:
        _git("mv", LEGACY_OVERLAY_MANIFEST_NAME, BOOTSTRAP_MANIFEST_NAME, cwd=target)
    except (subprocess.CalledProcessError, FileNotFoundError):
        legacy.rename(canonical)
    return canonical


def _git(*args: str, cwd: Path | None = None) -> str:
    """Run ``git`` with the given args, returning stripped stdout."""
    cmd = ["git"]
    if cwd is not None:
        cmd.extend(["-C", str(cwd)])
    cmd.extend(args)
    result = subprocess.run(
        cmd,
        check=True,
        capture_output=True,
        text=True,
        timeout=120,
    )
    return result.stdout.strip()


def _resolve_ref_to_sha(clone: Path, remote_ref: str) -> str:
    """Resolve ``remote_ref`` against the just-fetched clone, preferring the
    fresh remote-tracking branch over any stale local ref.

    Resolution order:

    1. ``refs/remotes/origin/<ref>`` — picks up freshly fetched branch tips
       (E17-10-BR13-M-01: avoids the stale local-branch trap that
       ``git checkout --detach <branch>`` falls into after ``fetch``).
    2. ``refs/tags/<ref>`` — tag refs.
    3. ``<ref>`` raw — last-resort for SHAs and exotic refspecs.
    """
    candidates = (
        f"refs/remotes/origin/{remote_ref}",
        f"refs/tags/{remote_ref}",
        remote_ref,
    )
    for candidate in candidates:
        try:
            return _git("rev-parse", "--verify", f"{candidate}^{{commit}}", cwd=clone)
        except subprocess.CalledProcessError:
            continue
    raise RuntimeError(
        f"could not resolve remote_ref {remote_ref!r} in {clone} "
        "(tried remote-tracking branch, tag, and raw ref)"
    )


def _resolve_in_clone(clone: Path, relpath: str) -> Path:
    """Resolve a surface/asset path against the clone.

    Probes ``<clone>/packages/agentic-system/<relpath>`` first (the
    agentic-protocol-monorepo layout) and falls back to ``<clone>/<relpath>``
    for legacy hoisted overlays. Returns the nested path when neither exists
    so callers can use ``.exists()`` as the discriminator.
    """
    nested = clone / AGENTIC_SYSTEM_SUBDIR / relpath
    if nested.exists():
        return nested
    root = clone / relpath
    if root.exists():
        return root
    return nested


def _materialize_surfaces(target: Path, clone: Path) -> list[dict[str, str]]:
    """Symlink each known shared surface from ``clone`` into ``target``.

    Per-surface behavior:

    - Surface absent in the clone: skip silently. Not recorded in the manifest.
    - Surface absent in target: create the parent directory if needed, then
      ``symlink`` ``target/<surface> -> ../...../.agentic/remote/<surface>``
      using a relative target. Recorded as ``source='shared'``.
    - Target already a symlink into our clone: leave it; recorded as
      ``source='shared'`` (idempotent rerun path).
    - Target already a symlink pointing elsewhere (foreign symlink): leave it
      untouched; recorded as ``source='local'`` so overlay precedence is
      honored.
    - Target already a real file or directory: leave it untouched; recorded as
      ``source='local'``.
    """
    materialized: list[dict[str, str]] = []
    clone_resolved = clone.resolve()

    for surface in SHARED_SURFACES:
        remote_path = _resolve_in_clone(clone, surface)
        target_path = target / surface

        if not remote_path.exists():
            continue

        if target_path.is_symlink():
            try:
                resolved = target_path.resolve(strict=False)
            except OSError:
                resolved = None
            points_into_clone = (
                resolved is not None
                and (
                    resolved == remote_path.resolve()
                    or str(resolved).startswith(str(clone_resolved) + os.sep)
                )
            )
            if points_into_clone:
                materialized.append({"path": surface, "source": "shared"})
                continue
            # Foreign symlink — local content takes precedence.
            materialized.append({"path": surface, "source": "local"})
            continue

        if target_path.exists():
            materialized.append({"path": surface, "source": "local"})
            continue

        target_path.parent.mkdir(parents=True, exist_ok=True)
        rel = os.path.relpath(remote_path, target_path.parent)
        target_path.symlink_to(rel, target_is_directory=True)
        materialized.append({"path": surface, "source": "shared"})

    return materialized


def _prepare_generated_surfaces(target: Path, clone: Path) -> list[dict[str, str]]:
    """Ensure each per-agent generated surface exists as a real directory.

    Pre-existing symlinks pointing into the clone (left over from the
    pre-Plan-0002 overlay model where these surfaces were shared
    symlinks) are replaced with empty directories so the generator can
    write into them. Pre-existing real local content is preserved —
    the operator may have intentionally placed local overrides there;
    the generator's per-file write logic will only replace the files
    it owns.
    """
    materialized: list[dict[str, str]] = []
    clone_resolved = clone.resolve()

    for surface in GENERATED_SURFACES:
        target_path = target / surface

        if target_path.is_symlink():
            try:
                resolved = target_path.resolve(strict=False)
            except OSError:
                resolved = None
            points_into_clone = (
                resolved is not None
                and str(resolved).startswith(str(clone_resolved) + os.sep)
            )
            broken = resolved is not None and not target_path.exists()
            if points_into_clone or broken:
                # Legacy overlay symlink, or a dangling symlink whose
                # target is gone — replace with a real directory so the
                # generator can write into it. (A dangling symlink also
                # blocks the mkdir below, since lexists() is True.)
                target_path.unlink()
                target_path.mkdir(parents=True, exist_ok=True)
            # Foreign live symlinks are left alone (operator chose them);
            # the generator will write through them into wherever they point.

        elif not target_path.exists():
            target_path.mkdir(parents=True, exist_ok=True)

        materialized.append({"path": surface, "source": "generated"})

    return materialized


def _run_generator(target: Path, clone: Path) -> None:
    """Invoke the agent-workflow generator against the target.

    Uses the generator + manifest + skills source from the overlay
    clone. Writes per-agent surfaces into the target via the
    generator's ``--target`` convenience flag.
    """
    generator_script = _resolve_in_clone(clone, GENERATOR_SCRIPT)
    manifest_path = _resolve_in_clone(clone, GENERATOR_MANIFEST)
    skills_source = _resolve_in_clone(clone, GENERATOR_SKILLS_SOURCE)

    if not generator_script.is_file():
        # Older overlays don't ship the generator (Plan 0002 introduced it).
        # That's acceptable when bootstrapping from a legacy ref; emit
        # nothing rather than fail.
        return

    cmd = [
        sys.executable,
        str(generator_script),
        "--manifest",
        str(manifest_path),
        "--skills-source-root",
        str(skills_source),
        "--target",
        str(target),
    ]
    subprocess.run(cmd, check=True, cwd=str(clone), timeout=120)


def _install_lifecycle_profile(
    target: Path, clone: Path
) -> list[dict[str, str]]:
    """Hoist the Plan 0009 lifecycle Make fragment + runner into ``target``.

    Each entry in :data:`LIFECYCLE_HOISTS` is resolved against the clone
    (preferring the ``packages/agentic-system/`` layout, falling back to
    a flat layout for hoisted fixture remotes), then copied to the
    consumer at the destination relpath. Files use ``shutil.copy2``;
    directories use ``shutil.copytree`` with ``dirs_exist_ok=True`` so
    re-runs are idempotent. Sources missing in the clone are skipped
    silently — older overlay refs may pre-date Plan 0009.
    """
    entries: list[dict[str, str]] = []
    for src_rel, dest_rel in LIFECYCLE_HOISTS:
        src = _resolve_in_clone(clone, src_rel)
        if not src.exists():
            continue
        dest = target / dest_rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        # AHMCP-48: under ``--profile all``, the shared-overlay
        # materialization may already have linked ``dest`` to the same
        # file inside the clone (Makefile.d/ and scripts/agentic/ ride
        # on the overlay symlink path). When dest already resolves to
        # src, ``shutil.copy2``/``copytree`` would raise
        # ``SameFileError``. Treat the existing symlink as the canonical
        # materialization and record the surface entry without copying.
        if dest.exists() and dest.resolve() == src.resolve():
            entries.append({"path": dest_rel, "source": "lifecycle"})
            continue
        if src.is_dir():
            shutil.copytree(src, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dest)
        entries.append({"path": dest_rel, "source": "lifecycle"})
    return entries


def _ensure_consumer_makefile_include(target: Path) -> dict[str, str] | None:
    """Idempotently inject the lifecycle ``-include`` directive into
    ``<target>/Makefile``.

    Wraps the directive in a sentinel-bracketed block so re-runs don't
    duplicate, and a future uninstall can excise it cleanly. When the
    sentinel block is already present the file is left untouched and
    ``action='already_present'`` is returned. When the consumer has no
    Makefile, one is created containing only the sentinel block.
    """
    makefile = target / "Makefile"
    block = (
        f"{LIFECYCLE_INCLUDE_SENTINEL_BEGIN}\n"
        f"{LIFECYCLE_INCLUDE_DIRECTIVE}\n"
        f"{LIFECYCLE_INCLUDE_SENTINEL_END}\n"
    )
    if not makefile.exists():
        makefile.write_text(block)
        return {"path": "Makefile", "action": "created"}
    existing = makefile.read_text()
    if LIFECYCLE_INCLUDE_SENTINEL_BEGIN in existing:
        return {"path": "Makefile", "action": "already_present"}
    sep = "" if existing.endswith("\n") else "\n"
    makefile.write_text(existing + sep + block)
    return {"path": "Makefile", "action": "appended"}


def install(
    *,
    target: Path,
    remote_url: str,
    remote_ref: str,
    mcp_servers: Mapping[str, Mapping[str, Any]] | str | None = None,
    enforce_required_surfaces: bool = False,
    profile: str = PROFILE_ALL,
    harness_hook_scope: str = "local",
) -> dict[str, object]:
    """Clone the shared agentic-system remote, materialize overlay surfaces,
    write consumer-tool configs, and write the overlay manifest.

    Args:
        target: Consumer repository root. Must already exist.
        remote_url: Git URL for the shared agentic-system remote.
        remote_ref: Tag, branch, or SHA to check out (e.g. ``"v0.1.0"``).
        mcp_servers: Mapping of ``<server_name> -> {command, args, env}`` to
            register in ``.mcp.json``, ``.vscode/mcp.json``, and
            ``.codex/config.toml``. Pass the sentinel string ``"default"``
            to use :data:`DEFAULT_MCP_SERVERS` (the two MCP servers shipped
            by this monorepo). When ``None``, the three file-writers are
            skipped. ``core.hooksPath`` is set independently whenever the
            target is a git repo.

    Returns:
        The manifest dict that was written to ``<target>/.agentic-bootstrap.json``.

    Raises:
        FileNotFoundError: ``target`` does not exist.
        FileExistsError: ``<target>/.agentic/remote`` exists but is not a git clone.
        RemoteUrlMismatchError: existing clone tracks a different ``origin`` URL.
        subprocess.CalledProcessError: ``git`` command failed.
    """
    if profile not in SUPPORTED_PROFILES:
        raise ValueError(
            f"profile={profile!r} is not a recognized install profile; "
            f"expected one of {sorted(SUPPORTED_PROFILES)!r}."
        )

    if harness_hook_scope not in SUPPORTED_HARNESS_HOOK_SCOPES:
        raise ValueError(
            f"harness_hook_scope={harness_hook_scope!r} is not supported; "
            f"expected one of {sorted(SUPPORTED_HARNESS_HOOK_SCOPES)!r}."
        )

    target = Path(target).resolve()
    if not target.is_dir():
        raise FileNotFoundError(f"target directory does not exist: {target}")

    _migrate_legacy_manifest(target)

    if isinstance(mcp_servers, str):
        if mcp_servers != "default":
            raise ValueError(
                f"mcp_servers={mcp_servers!r} is not a recognized sentinel; "
                "pass a mapping, the literal 'default', or None."
            )
        mcp_servers = DEFAULT_MCP_SERVERS

    clone = target.joinpath(*CLONE_SUBDIR)

    if (clone / ".git").exists():
        existing_origin = _git("remote", "get-url", "origin", cwd=clone)
        if existing_origin != remote_url:
            raise RemoteUrlMismatchError(
                f"{clone} already tracks origin {existing_origin!r}, "
                f"but install was called with remote_url={remote_url!r}. "
                "Move or remove .agentic/remote (or pass the original URL) to "
                "switch overlays."
            )
        _git("fetch", "--tags", "--prune", "--force", "origin", cwd=clone)
    else:
        clone.parent.mkdir(parents=True, exist_ok=True)
        if clone.exists():
            raise FileExistsError(
                f"{clone} exists but is not a git clone. "
                "Move or remove it before re-running install."
            )
        _git("clone", "--branch", remote_ref, remote_url, str(clone))

    sha = _resolve_ref_to_sha(clone, remote_ref)
    if len(sha) != 40:
        raise RuntimeError(f"unexpected sha shape from git rev-parse: {sha!r}")

    _git("checkout", "--detach", sha, cwd=clone)

    surfaces: list[dict[str, str]] = []
    configs: list[dict[str, str]] = []

    if profile == PROFILE_ALL:
        surfaces.extend(_materialize_surfaces(target, clone))
        surfaces.extend(_prepare_generated_surfaces(target, clone))

        # Required-surfaces refusal: founding plan 0001 calls for bootstrap
        # to refuse install when required hooks are missing, so consumers
        # cannot end up with a half-installed harness. Run BEFORE the
        # generator, config writers, and init-state so a failing install
        # cannot leave generated artifacts, .mcp.json, or .task-state/
        # behind on disk.
        materialized_paths = {entry["path"] for entry in surfaces if isinstance(entry, dict)}
        if enforce_required_surfaces and "scripts/hooks" not in materialized_paths:
            raise BootstrapManifestValidationError(
                "refusing to declare install successful: required surface 'scripts/hooks' "
                "was not materialized. Bootstrap-installed hooks are part of the harness "
                "contract; without them, target-side guardrails do not run. "
                "Set enforce_required_surfaces=False to bypass for non-standard remotes."
            )

        _run_generator(target, clone)
        configs.extend(_write_configs(target, mcp_servers, include_hooks=False))
        _run_init_state(target, mcp_servers, expected_remote_url=remote_url)

    # AHMCP-48: ``all`` now also performs the lifecycle hoist so a
    # consumer that ships the lifecycle-referencing skills (branch-
    # lifecycle / tdd / incremental-implementation / branch-review /
    # handoff-lifecycle and the body-only references in auto-fix /
    # review-parallel / investigate) also receives the matching
    # ``Makefile.d/lifecycle.mk`` + ``scripts/agentic/lifecycle/``
    # runner that defines those targets. ``--profile lifecycle``
    # remains the dedicated lean profile (no skills, lifecycle only);
    # ``--profile minimal`` is unchanged. Both hoist helpers below are
    # idempotent on rerun.
    if profile in (PROFILE_ALL, PROFILE_LIFECYCLE):
        surfaces.extend(_install_lifecycle_profile(target, clone))
        include_entry = _ensure_consumer_makefile_include(target)
        if include_entry is not None:
            configs.append(include_entry)

    hooks_entry = _set_git_hooks_path(target)
    if hooks_entry is not None:
        configs.append(hooks_entry)

    configs.append(
        _write_claude_settings_hooks(target, scope=harness_hook_scope)
    )

    manifest: dict[str, object] = _build_install_manifest(
        remote_url=remote_url,
        remote_ref=remote_ref,
        remote_sha=sha,
        surfaces=surfaces,
        configs=configs,
        mcp_servers=mcp_servers,
    )

    # Wire-shape validation: refuse to write a manifest that does not
    # validate against agentic_protocol.BootstrapManifest. This is the
    # install-time schema check called for in founding plan 0001.
    # When agentic-protocol is not installed (partial migrations), we
    # warn but still write — the manifest contract is best-effort
    # until the protocol is mandatory.
    try:
        from agentic_protocol import BootstrapManifest  # type: ignore[import-not-found]

        BootstrapManifest.model_validate(manifest)
    except ImportError:
        pass
    except Exception as exc:  # noqa: BLE001
        raise BootstrapManifestValidationError(
            f"refusing to write {BOOTSTRAP_MANIFEST_NAME}: agentic_protocol.BootstrapManifest "
            f"validation failed: {exc}"
        ) from exc

    manifest_path = target / BOOTSTRAP_MANIFEST_NAME
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

    return manifest


# ---------------------------------------------------------------------------
# Config writers
# ---------------------------------------------------------------------------


HOOKS_PATH_VALUE = "scripts/hooks/git"
"""Workspace-relative ``core.hooksPath`` value.

Points at the ``git/`` subdirectory of the materialized ``scripts/hooks``
surface. The parent directory ships Python helpers, ``.sh`` utilities,
and tests alongside the actual hook scripts; pointing git at the parent
makes git look for hook files by name (``post-checkout`` etc.) at a path
where they do not exist, so it silently resolves nothing. The named
hooks themselves live at ``scripts/hooks/git/<name>``.

Single-line invariant: the on-disk hook layout and this value MUST agree.
The Slice 5 install rehearsal pins both halves of that contract.
"""


def _deep_merge(dst: dict[str, Any], src: Mapping[str, Any]) -> dict[str, Any]:
    """Recursively merge ``src`` into ``dst`` and return ``dst``.

    Dict-into-dict merges recurse. Any non-dict value in ``src`` (including
    lists) replaces the corresponding key in ``dst`` outright — list-concat
    semantics would silently grow user config across reruns.
    """
    for key, value in src.items():
        existing = dst.get(key)
        if isinstance(existing, dict) and isinstance(value, Mapping):
            _deep_merge(existing, value)
        elif isinstance(value, Mapping):
            new_dict: dict[str, Any] = {}
            _deep_merge(new_dict, value)
            dst[key] = new_dict
        else:
            dst[key] = value
    return dst


def _write_configs(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None,
    *,
    include_hooks: bool = True,
) -> list[dict[str, str]]:
    """Run the four post-install config writers and return per-surface entries
    suitable for ``manifest['configs']``.

    The three file-writers run only when ``mcp_servers`` is provided. The git
    ``core.hooksPath`` writer runs whenever the target looks like a git repo.
    """
    entries: list[dict[str, str]] = []

    if mcp_servers:
        entries.append(_write_mcp_json(target, mcp_servers))
        entries.append(_write_vscode_mcp_json(target, mcp_servers))
        entries.append(_write_codex_config(target, mcp_servers))

    if include_hooks:
        hooks_entry = _set_git_hooks_path(target)
        if hooks_entry is not None:
            entries.append(hooks_entry)

    return entries


def _run_init_state(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None,
    *,
    expected_remote_url: str | None = None,
) -> None:
    if not mcp_servers:
        return

    spec = mcp_servers.get("agent-handoff-mcp")
    if spec is None:
        return

    command = spec.get("command")
    if not isinstance(command, str) or not command:
        raise ValueError("agent-handoff-mcp config must include a non-empty command")

    raw_args = spec.get("args", [])
    if not isinstance(raw_args, list) or not all(isinstance(arg, str) for arg in raw_args):
        raise ValueError("agent-handoff-mcp config args must be a list[str]")

    args = list(raw_args)
    raw_env = spec.get("env")
    env_has_state_dir = isinstance(raw_env, Mapping) and "AGENT_HANDOFF_STATE_DIR" in raw_env
    if args and args[-1] in {"serve-stdio", "serve-http", "init-state"}:
        args = args[:-1]
    if not any(arg == "--workspace-root" or arg.startswith("--workspace-root=") for arg in args):
        args.extend(["--workspace-root", str(target)])
    if (
        not any(arg == "--state-dir" or arg.startswith("--state-dir=") for arg in args)
        and not env_has_state_dir
    ):
        args.extend(["--state-dir", str(target / ".task-state")])
    args.append("init-state")
    if expected_remote_url is not None:
        args.extend(["--expected-remote-url", expected_remote_url])

    cmd = [command, *args]
    env = os.environ.copy()
    if raw_env is not None:
        if not isinstance(raw_env, Mapping) or not all(
            isinstance(key, str) and isinstance(value, str) for key, value in raw_env.items()
        ):
            raise ValueError("agent-handoff-mcp config env must be a mapping[str, str]")
        env.update(raw_env)

    subprocess.run(
        cmd,
        check=True,
        capture_output=True,
        text=True,
        cwd=str(target),
        env=env,
        timeout=120,
    )


def _render_mcp_json(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]],
    *,
    prune_names: Iterable[str] = (),
) -> bytes:
    """Pure render half of the .mcp.json seam: read the existing file
    (if any), deep-merge managed servers under ``mcpServers``, and return
    the bytes that ``_write_mcp_json`` would persist. No filesystem
    mutation.

    ``prune_names`` are server names to remove from the existing
    ``mcpServers`` block before the merge — driven by
    ``sync_mcp_configs(prune_removed_managed=True)`` reading the
    ledger's previously-managed provenance. Default ``()`` keeps the
    install path's behavior byte-identical."""
    path = target / ".mcp.json"
    doc: dict[str, Any] = _load_json_or_empty(path)
    if prune_names:
        servers = doc.get("mcpServers")
        if isinstance(servers, dict):
            for name in prune_names:
                servers.pop(name, None)
    incoming = {"mcpServers": {name: dict(spec) for name, spec in mcp_servers.items()}}
    _deep_merge(doc, incoming)
    return (json.dumps(doc, indent=2) + "\n").encode("utf-8")


def _load_json_or_empty(path: Path) -> dict[str, Any]:
    """Return parsed JSON or ``{}`` when the file is missing or malformed.

    Managed surfaces are this tool's own output. If the file is invalid
    JSON (interrupted prior write, hand edit), treat it as empty so the
    next reconcile rewrites it cleanly instead of letting JSONDecodeError
    escape through doctor / mcp-sync. Third-party preservation is
    impossible in that case (the existing content is already lost).
    """
    if not path.exists():
        return {}
    try:
        loaded = json.loads(path.read_text())
    except (json.JSONDecodeError, UnicodeDecodeError):
        return {}
    return loaded if isinstance(loaded, dict) else {}


def _write_mcp_json(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]],
    *,
    prune_names: Iterable[str] = (),
) -> dict[str, str]:
    """Deep-merge managed servers into ``<target>/.mcp.json`` under
    ``mcpServers``. Preserves all other keys and other servers."""
    path = target / ".mcp.json"
    existed = path.exists()
    rendered = _render_mcp_json(target, mcp_servers, prune_names=prune_names)
    path.write_bytes(rendered)
    return {"path": ".mcp.json", "action": "merged" if existed else "created"}


def _render_vscode_mcp_json(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]],
    *,
    prune_names: Iterable[str] = (),
) -> bytes:
    """Pure render half of the .vscode/mcp.json seam: read the existing
    file (if any), deep-merge managed servers under ``servers``, and
    return the bytes that ``_write_vscode_mcp_json`` would persist. No
    filesystem mutation (the ``.vscode/`` directory is created by the
    write half).

    ``prune_names`` removes those entries from the existing ``servers``
    block before the merge; see ``_render_mcp_json`` for the contract."""
    path = target / ".vscode" / "mcp.json"
    doc: dict[str, Any] = _load_json_or_empty(path)
    if prune_names:
        servers = doc.get("servers")
        if isinstance(servers, dict):
            for name in prune_names:
                servers.pop(name, None)
    incoming = {"servers": {name: dict(spec) for name, spec in mcp_servers.items()}}
    _deep_merge(doc, incoming)
    return (json.dumps(doc, indent=2) + "\n").encode("utf-8")


def _write_vscode_mcp_json(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]],
    *,
    prune_names: Iterable[str] = (),
) -> dict[str, str]:
    """Deep-merge managed servers into ``<target>/.vscode/mcp.json`` under
    ``servers``. Creates the ``.vscode`` directory if absent."""
    path = target / ".vscode" / "mcp.json"
    existed = path.exists()
    rendered = _render_vscode_mcp_json(target, mcp_servers, prune_names=prune_names)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(rendered)
    return {"path": ".vscode/mcp.json", "action": "merged" if existed else "created"}


def _render_codex_config(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]],
    *,
    prune_names: Iterable[str] = (),
) -> bytes:
    """Pure render half of the .codex/config.toml seam: read the existing
    TOML (if any), replace the ``[mcp_servers.<name>]`` tables for each
    managed server while preserving every other key and comment, and
    return the bytes that ``_write_codex_config`` would persist. No
    filesystem mutation (the ``.codex/`` directory is created by the
    write half).

    ``prune_names`` removes those tables from ``[mcp_servers]`` before
    the managed tables are added; see ``_render_mcp_json`` for the
    contract."""
    path = target / ".codex" / "config.toml"
    if path.exists():
        try:
            doc = tomlkit.parse(path.read_text())
        except (tomlkit.exceptions.TOMLKitError, UnicodeDecodeError):
            doc = tomlkit.document()
    else:
        doc = tomlkit.document()

    if "mcp_servers" not in doc:
        doc["mcp_servers"] = tomlkit.table(is_super_table=True)
    servers_table = doc["mcp_servers"]

    if prune_names:
        for name in prune_names:
            if name in servers_table:
                del servers_table[name]

    for name, spec in mcp_servers.items():
        new_table = tomlkit.table()
        for spec_key, spec_value in spec.items():
            new_table[spec_key] = spec_value
        servers_table[name] = new_table

    return tomlkit.dumps(doc).encode("utf-8")


def _write_codex_config(
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]],
    *,
    prune_names: Iterable[str] = (),
) -> dict[str, str]:
    """Replace the ``[mcp_servers.<name>]`` tables in
    ``<target>/.codex/config.toml`` for each managed server, leaving every
    other root key, table, and comment untouched (tomlkit round-trip)."""
    path = target / ".codex" / "config.toml"
    existed = path.exists()
    rendered = _render_codex_config(target, mcp_servers, prune_names=prune_names)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(rendered)
    return {"path": ".codex/config.toml", "action": "merged" if existed else "created"}


def _set_git_hooks_path(target: Path) -> dict[str, str] | None:
    """If ``target`` is a git repo, set ``core.hooksPath`` to
    ``scripts/hooks/git`` (under the materialized ``scripts/hooks``
    symlink) and return a manifest entry. Otherwise return ``None``
    (silent skip).

    See ``HOOKS_PATH_VALUE`` for why the path includes the ``git/``
    subdirectory.
    """
    if not (target / ".git").exists():
        return None
    _git("config", "core.hooksPath", HOOKS_PATH_VALUE, cwd=target)
    return {"path": "core.hooksPath", "action": "set"}


# Plan 0008 Slice 1: Claude Code Stop-hook wiring.
#
# Bootstrap-owned ``hooks.Stop[]`` entries carry a stable sentinel so
# repeat installs deduplicate by ``(_managed_by, basename(command))``
# rather than by raw command-string equality. That collapses
# absolute-vs-relative path drift between install runs into a single
# managed entry while leaving every unrelated entry the user (or
# another tool) wrote untouched.
HARNESS_HOOK_MANAGED_BY = "agentic-bootstrap"
HARNESS_HOOK_SCRIPT_BASENAME = "compact-session.py"
HARNESS_HOOK_SCRIPT_RELPATH = "scripts/hooks/compact-session.py"
HARNESS_HOOK_SCOPE_LOCAL = "local"
HARNESS_HOOK_SCOPE_USER = "user"
SUPPORTED_HARNESS_HOOK_SCOPES: frozenset[str] = frozenset(
    {HARNESS_HOOK_SCOPE_LOCAL, HARNESS_HOOK_SCOPE_USER}
)


def _harness_hook_settings_path(target: Path, scope: str) -> Path:
    if scope == HARNESS_HOOK_SCOPE_LOCAL:
        return target / ".claude" / "settings.local.json"
    if scope == HARNESS_HOOK_SCOPE_USER:
        return Path.home() / ".claude" / "settings.json"
    raise ValueError(
        f"harness_hook_scope={scope!r} is not supported; "
        f"expected one of {sorted(SUPPORTED_HARNESS_HOOK_SCOPES)!r}."
    )


def _build_managed_stop_entry(target: Path) -> dict[str, Any]:
    return {
        "_managed_by": HARNESS_HOOK_MANAGED_BY,
        "command": str(target / HARNESS_HOOK_SCRIPT_RELPATH),
    }


def _is_managed_stop_entry(entry: Any) -> bool:
    if not isinstance(entry, Mapping):
        return False
    if entry.get("_managed_by") != HARNESS_HOOK_MANAGED_BY:
        return False
    command = entry.get("command")
    if not isinstance(command, str):
        return False
    return Path(command).name == HARNESS_HOOK_SCRIPT_BASENAME


def _write_claude_settings_hooks(
    target: Path, *, scope: str
) -> dict[str, str]:
    """Idempotently merge a managed Stop-hook entry into Claude settings.

    Returns a manifest entry describing the action taken (``created``,
    ``merged``, or ``noop``). The merge logic:

    1. Load (or initialise) the JSON document at the scoped path.
    2. Find existing managed entries via the ``(_managed_by, basename)``
       equality key from the plan.
    3. Replace the first match in place (so absolute-vs-relative drift
       collapses to one entry); append when no match exists.
    4. Drop any duplicate managed entries beyond the first to recover
       from manual hand-edits or earlier buggy installs.

    Unrelated ``hooks.Stop[]`` entries and unrelated top-level keys are
    preserved verbatim.
    """
    settings_path = _harness_hook_settings_path(target, scope)
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existed = settings_path.exists()
    doc: dict[str, Any] = (
        json.loads(settings_path.read_text()) if existed else {}
    )
    if not isinstance(doc, dict):
        raise ValueError(
            f"refusing to merge harness hooks into {settings_path}: "
            "existing JSON document is not an object"
        )

    hooks = doc.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        raise ValueError(
            f"refusing to merge harness hooks into {settings_path}: "
            "'hooks' value is not an object"
        )
    stop_entries_raw = hooks.get("Stop", [])
    if not isinstance(stop_entries_raw, list):
        raise ValueError(
            f"refusing to merge harness hooks into {settings_path}: "
            "'hooks.Stop' value is not a list"
        )

    managed_entry = _build_managed_stop_entry(target)
    new_stop: list[Any] = []
    replaced = False
    matched_existing = False
    for entry in stop_entries_raw:
        if _is_managed_stop_entry(entry):
            matched_existing = True
            if not replaced:
                new_stop.append(managed_entry)
                replaced = True
            # silently drop any duplicate managed entries
            continue
        new_stop.append(entry)
    if not replaced:
        new_stop.append(managed_entry)

    hooks["Stop"] = new_stop
    settings_path.write_text(json.dumps(doc, indent=2) + "\n")

    if not existed:
        action = "created"
    elif matched_existing:
        action = "noop"
    else:
        action = "merged"

    rel_path = (
        str(settings_path.relative_to(target))
        if scope == HARNESS_HOOK_SCOPE_LOCAL
        else str(settings_path)
    )
    return {"path": rel_path, "action": action}

