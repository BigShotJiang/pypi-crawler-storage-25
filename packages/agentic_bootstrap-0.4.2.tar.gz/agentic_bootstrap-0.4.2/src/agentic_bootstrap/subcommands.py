"""Post-install subcommands: status / doctor / update / repair.

Each subcommand is a small library function with a clear contract:

- ``status(target)`` returns a human-readable summary of the overlay manifest.
- ``doctor(target, mcp_servers=None)`` returns a list of drift findings.
- ``update(target, remote_ref, ...)`` (future slice) re-runs install at a new ref.
- ``repair(target, ..., force_dirty)`` (future slice) rewrites drifted overlays.

The CLI in ``agentic_bootstrap.cli`` is a thin argparse wrapper over these.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Mapping

from agentic_bootstrap.install import (
    BOOTSTRAP_MANIFEST_NAME,
    CLONE_SUBDIR,
    GENERATED_SURFACES,
    GENERATOR_MANIFEST,
    GENERATOR_SCRIPT,
    GENERATOR_SKILLS_SOURCE,
    SHARED_SURFACES,
    _migrate_legacy_manifest,
)


def _load_manifest(target: Path) -> dict[str, object]:
    _migrate_legacy_manifest(target)
    manifest_path = target / BOOTSTRAP_MANIFEST_NAME
    if not manifest_path.is_file():
        raise FileNotFoundError(
            f"{manifest_path} not found. Run `agentic-bootstrap install --target "
            f"{target}` first."
        )
    return json.loads(manifest_path.read_text())


def _preserved_mcp_servers(
    target: Path, manifest: Mapping[str, object]
) -> Mapping[str, Mapping[str, Any]] | None:
    """Return the currently registered managed MCP mapping, if any.

    Updates inherit the existing managed registration by default. This keeps
    `.mcp.json` / `.vscode/mcp.json` / `.codex/config.toml` listed in the
    refreshed manifest and ensures init-state still runs after a managed
    install when the caller omits ``mcp_servers``.
    """
    configs = manifest.get("configs", []) or []
    registered_mcp = any(
        isinstance(entry, dict) and entry.get("path") == ".mcp.json"
        for entry in configs
    )
    if not registered_mcp:
        return None

    mcp_path = target / ".mcp.json"
    if not mcp_path.is_file():
        raise FileNotFoundError(
            f"{mcp_path} missing for managed update; re-run install or pass --mcp-servers."
        )

    try:
        doc = json.loads(mcp_path.read_text())
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"{mcp_path} is not valid JSON; repair or replace it before update."
        ) from exc

    servers = doc.get("mcpServers")
    if not isinstance(servers, dict):
        raise ValueError(
            f"{mcp_path} does not contain an mcpServers mapping; repair it before update."
        )

    preserved: dict[str, Mapping[str, Any]] = {}
    for name, spec in servers.items():
        if isinstance(name, str) and isinstance(spec, dict):
            preserved[name] = spec
    return preserved


def status(*, target: Path) -> str:
    """Return a multi-line human-readable summary of the overlay manifest at
    ``<target>/.agentic-bootstrap.json``.

    When the install registered MCP servers (``.mcp.json`` recorded in
    ``configs``), invokes ``init-state --check`` to append the resolved
    state directory, database path, exports directory, and schema
    version. ``--no-mcp-servers`` installs skip this section.

    Raises ``FileNotFoundError`` when the manifest is absent.
    """
    target = Path(target).resolve()
    manifest = _load_manifest(target)

    surfaces = manifest.get("surfaces", []) or []
    configs = manifest.get("configs", []) or []
    shared = sum(1 for s in surfaces if s.get("source") == "shared")
    local = sum(1 for s in surfaces if s.get("source") == "local")
    generated = sum(1 for s in surfaces if s.get("source") == "generated")

    lines = [
        f"agentic-bootstrap overlay at {target}",
        f"  remote_url:  {manifest.get('remote_url')}",
        f"  remote_ref:  {manifest.get('remote_ref')}",
        f"  remote_sha:  {manifest.get('remote_sha')}",
        f"  surfaces:    {len(surfaces)} ({shared} shared, {local} local, {generated} generated)",
        f"  configs:     {len(configs)}",
    ]
    for entry in configs:
        lines.append(f"    - {entry.get('path')} ({entry.get('action')})")

    state_lines = _status_handoff_state_lines(target, configs)
    if state_lines:
        lines.append("  handoff state:")
        lines.extend(f"    {line}" for line in state_lines)

    return "\n".join(lines) + "\n"


def _status_handoff_state_lines(
    target: Path, configs: list[dict[str, Any]]
) -> list[str]:
    """Invoke ``init-state --check`` against the agent-handoff-mcp entry in
    ``.mcp.json`` and return zero or more summary lines.

    Returns an empty list when the install did not register MCP servers
    (so init-state was never expected to run) — this mirrors doctor's
    state-check gating per Plan 0003 §4.
    """
    import subprocess

    registered_mcp = any(
        isinstance(entry, dict) and entry.get("path") == ".mcp.json"
        for entry in configs
    )
    if not registered_mcp:
        return []

    mcp_path = target / ".mcp.json"
    if not mcp_path.is_file():
        return ["error: .mcp.json missing — re-run install"]

    try:
        spec = json.loads(mcp_path.read_text()).get("mcpServers", {}).get("agent-handoff-mcp")
    except json.JSONDecodeError:
        return ["error: .mcp.json is not valid JSON"]
    if not isinstance(spec, dict):
        return []

    cmd = _resolve_init_state_check_command(target, spec)
    if cmd is None:
        return ["error: agent-handoff-mcp entry in .mcp.json is malformed"]

    env = os.environ.copy()
    raw_env = spec.get("env")
    if isinstance(raw_env, dict):
        for key, value in raw_env.items():
            if isinstance(key, str) and isinstance(value, str):
                env[key] = value

    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            cwd=str(target),
            env=env,
            timeout=120,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return [f"error: init-state --check failed: {exc}"]

    if proc.returncode != 0:
        first = (proc.stderr or proc.stdout or "").strip().splitlines()
        detail = first[-1] if first else f"exit {proc.returncode}"
        return [f"error: init-state --check failed: {detail}"]

    payload: dict[str, Any]
    try:
        payload = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return [f"error: init-state --check returned non-JSON: {proc.stdout[:120]!r}"]

    return [
        f"state_dir:      {payload.get('state_dir')}",
        f"db_path:        {payload.get('db_path')}",
        f"exports_dir:    {payload.get('exports_dir')}",
        f"schema_version: {payload.get('schema_version')}",
        f"initialized:    {payload.get('initialized')}",
    ]


def _resolve_init_state_check_command(
    target: Path, spec: dict[str, Any]
) -> list[str] | None:
    """Map the ``.mcp.json`` agent-handoff-mcp entry to an
    ``init-state --check`` invocation, mirroring install-time resolution
    in ``install._run_init_state``.
    """
    command = spec.get("command")
    raw_args = spec.get("args", [])
    if not isinstance(command, str) or not command:
        return None
    if not isinstance(raw_args, list) or not all(isinstance(a, str) for a in raw_args):
        return None

    args = list(raw_args)
    if args and args[-1] in {"serve-stdio", "serve-http", "init-state"}:
        args = args[:-1]
    if not any(a == "--workspace-root" or a.startswith("--workspace-root=") for a in args):
        args.extend(["--workspace-root", str(target)])
    raw_env = spec.get("env")
    env_has_state_dir = isinstance(raw_env, dict) and "AGENT_HANDOFF_STATE_DIR" in raw_env
    if (
        not any(a == "--state-dir" or a.startswith("--state-dir=") for a in args)
        and not env_has_state_dir
    ):
        args.extend(["--state-dir", str(target / ".task-state")])
    args.extend(["init-state", "--check"])
    return [command, *args]


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


Finding = dict[str, str]


def doctor(
    *,
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None = None,
) -> list[Finding]:
    """Return a list of drift findings for the overlay at ``target``.

    Each finding is a dict with at least ``kind`` and ``path``. Recognized
    kinds:

    - ``missing_manifest`` — ``.agentic-bootstrap.json`` is gone.
    - ``missing_clone`` — ``.agentic/remote/.git`` is gone.
    - ``surface_drift`` — a surface recorded as ``shared`` in the manifest is
      no longer a symlink resolving into the clone.
    - ``generated_drift`` — a surface recorded as ``generated`` differs from
      what ``scripts/generate_agent_workflows.py`` would write today. Detected
      by re-running the generator in ``--check`` mode against the target.
    - ``config_drift`` — a managed MCP server in ``mcp_servers`` is no longer
      present (or no longer matches) in ``.mcp.json`` / ``.vscode/mcp.json``.
      Only checked when ``mcp_servers`` is provided.
    - ``state_drift`` — ``.task-state/handoff.db`` is missing even though the
      manifest's ``configs`` array recorded ``.mcp.json``. Suppressed when the
      install was ``--no-mcp-servers`` (no managed servers registered, so no
      state init was expected).

    Returns an empty list when everything is clean.
    """
    target = Path(target).resolve()
    findings: list[Finding] = []

    _migrate_legacy_manifest(target)
    manifest_path = target / BOOTSTRAP_MANIFEST_NAME
    if not manifest_path.is_file():
        findings.append(
            {"kind": "missing_manifest", "path": BOOTSTRAP_MANIFEST_NAME}
        )
        return findings

    manifest = json.loads(manifest_path.read_text())
    clone = target.joinpath(*CLONE_SUBDIR)
    clone_resolved = clone.resolve(strict=False)

    if not (clone / ".git").exists():
        findings.append(
            {"kind": "missing_clone", "path": "/".join(CLONE_SUBDIR)}
        )

    surfaces = manifest.get("surfaces") or []
    for entry in surfaces:
        if entry.get("source") != "shared":
            continue
        surface = entry.get("path", "")
        link = target / surface
        if not link.is_symlink():
            findings.append({"kind": "surface_drift", "path": surface})
            continue
        try:
            resolved = link.resolve(strict=False)
        except OSError:
            findings.append({"kind": "surface_drift", "path": surface})
            continue
        in_clone = (
            resolved == (clone / surface).resolve(strict=False)
            or str(resolved).startswith(str(clone_resolved) + os.sep)
        )
        if not in_clone:
            findings.append({"kind": "surface_drift", "path": surface})

    findings.extend(_doctor_generated_surfaces(target, clone, manifest))

    if mcp_servers:
        findings.extend(
            _doctor_mcp_config_drift(target, manifest, mcp_servers)
        )

    findings.extend(_doctor_state(target, manifest))

    return findings


_MANAGED_SURFACE_BY_CONFIG_PATH: dict[str, str] = {
    ".mcp.json": "claude",
    ".vscode/mcp.json": "vscode",
    ".codex/config.toml": "codex",
}
_CONFIG_PATH_BY_MANAGED_SURFACE: dict[str, str] = {
    surface: path for path, surface in _MANAGED_SURFACE_BY_CONFIG_PATH.items()
}


def _registered_managed_surfaces(manifest: Mapping[str, object]) -> list[str]:
    """Return the managed-surface names recorded in the ledger's configs.

    Doctor / repair only reconcile surfaces that ``install`` actually
    wrote. Legacy ledgers without ``.codex/config.toml`` therefore skip
    codex even when the resolved map is supplied.
    """
    registered: list[str] = []
    for entry in manifest.get("configs") or []:
        if not isinstance(entry, dict):
            continue
        path = entry.get("path")
        surface = _MANAGED_SURFACE_BY_CONFIG_PATH.get(str(path))
        if surface is not None and surface not in registered:
            registered.append(surface)
    return registered


def _doctor_mcp_config_drift(
    target: Path,
    manifest: Mapping[str, object],
    mcp_servers: Mapping[str, Mapping[str, Any]],
) -> list[Finding]:
    """Run ``sync_mcp_configs(check_only=True)`` and translate per-surface
    drift into ``config_drift`` findings.

    Filtered to surfaces the ledger says ``install`` wrote so doctor
    does not invent drift for surfaces the consumer never opted into.
    """
    from agentic_bootstrap.mcp_sync import sync_mcp_configs

    surfaces = _registered_managed_surfaces(manifest)
    if not surfaces:
        return []
    report = sync_mcp_configs(
        target, mcp_servers, surfaces=surfaces, check_only=True
    )
    return [
        {"kind": "config_drift", "path": s.path}
        for s in report.surfaces
        if s.drift
    ]


def _doctor_state(target: Path, manifest: dict[str, object]) -> list[Finding]:
    # Plan 0003 §4: the manifest's configs array records whether bootstrap
    # registered MCP servers. .mcp.json is only present when an mcp_servers
    # map was provided, so its presence is the gate for expecting init-state
    # to have run. --no-mcp-servers installs leave .mcp.json out of configs
    # and must not trigger state_drift.
    registered_mcp = any(
        isinstance(entry, dict) and entry.get("path") == ".mcp.json"
        for entry in manifest.get("configs") or []
    )
    if not registered_mcp:
        return []

    db_path = target / ".task-state" / "handoff.db"
    if db_path.is_file():
        return []
    return [{"kind": "state_drift", "path": ".task-state/handoff.db"}]


def _doctor_generated_surfaces(
    target: Path, clone: Path, manifest: dict[str, object]
) -> list[Finding]:
    """Detect drift in per-agent generated surfaces.

    Runs ``scripts/generate_agent_workflows.py --check --target <target>``
    against the target. Each ``drift detected: <path>`` line in the
    generator's stderr is mapped back to the manifest's ``generated``
    surface that owns it; one ``generated_drift`` finding per affected
    surface (deduplicated). Silent when no generated surfaces are recorded
    (legacy manifests) or the generator script is missing from the clone
    (older overlay refs that pre-date Plan 0002).
    """
    import subprocess
    import sys

    surfaces = manifest.get("surfaces") or []
    generated_surfaces = [
        str(entry.get("path", ""))
        for entry in surfaces
        if entry.get("source") == "generated" and entry.get("path")
    ]
    if not generated_surfaces:
        return []

    from agentic_bootstrap.install import _resolve_in_clone

    generator_script = _resolve_in_clone(clone, GENERATOR_SCRIPT)
    manifest_path = _resolve_in_clone(clone, GENERATOR_MANIFEST)
    skills_source = _resolve_in_clone(clone, GENERATOR_SKILLS_SOURCE)
    if not generator_script.is_file() or not manifest_path.is_file():
        return []

    try:
        proc = subprocess.run(
            [
                sys.executable,
                str(generator_script),
                "--manifest",
                str(manifest_path),
                "--skills-source-root",
                str(skills_source),
                "--target",
                str(target),
                "--check",
            ],
            cwd=str(clone),
            capture_output=True,
            text=True,
            timeout=120,
        )
    except (OSError, subprocess.TimeoutExpired):
        # Generator unavailable / hung — surface as a single coarse finding
        # rather than crashing doctor.
        return [
            {"kind": "generated_drift", "path": surface}
            for surface in generated_surfaces
        ]

    if proc.returncode == 0:
        return []

    # Parse "drift detected: <abs path>" lines and map each back to the
    # manifest surface whose target-relative path it sits under.
    drifted: set[str] = set()
    for line in (proc.stderr or "").splitlines():
        line = line.strip()
        if not line.startswith("drift detected:"):
            continue
        drifted_path = line.split(":", 1)[1].strip()
        try:
            rel = Path(drifted_path).resolve().relative_to(target)
        except (ValueError, OSError):
            continue
        rel_str = str(rel)
        for surface in generated_surfaces:
            if rel_str == surface or rel_str.startswith(surface.rstrip("/") + "/"):
                drifted.add(surface)
                break

    if not drifted:
        # Generator reported failure but we couldn't map any path. Flag
        # all generated surfaces coarsely so the operator knows there's
        # work to do.
        drifted.update(generated_surfaces)

    return [{"kind": "generated_drift", "path": surface} for surface in sorted(drifted)]


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


def update(
    *,
    target: Path,
    remote_ref: str,
    remote_url: str | None = None,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None = None,
    enforce_required_surfaces: bool = True,
) -> dict[str, object]:
    """Re-run ``install`` against ``target`` at a new ``remote_ref``.

    ``remote_url`` defaults to whatever the current manifest already records,
    so callers don't need to repeat it. When ``mcp_servers`` is omitted,
    managed installs preserve their existing ``.mcp.json`` registration so
    config surfaces and init-state still refresh. ``enforce_required_surfaces``
    defaults to ``True`` to match the install CLI contract.
    """
    from agentic_bootstrap.install import install

    target = Path(target).resolve()
    manifest = _load_manifest(target)
    if remote_url is None:
        remote_url = str(manifest["remote_url"])
    if mcp_servers is None:
        mcp_servers = _preserved_mcp_servers(target, manifest)

    return install(
        target=target,
        remote_url=remote_url,
        remote_ref=remote_ref,
        mcp_servers=mcp_servers,
        enforce_required_surfaces=enforce_required_surfaces,
    )


# ---------------------------------------------------------------------------
# repair
# ---------------------------------------------------------------------------


def repair(
    *,
    target: Path,
    force_dirty: bool = False,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, list[Finding]]:
    """Restore drifted overlay surfaces flagged by :func:`doctor`.

    For each surface flagged as ``surface_drift``:

    - If the path no longer exists or is a broken/foreign symlink, the
      canonical symlink into the clone is recreated.
    - If the path has been replaced by a real directory or file, the surface
      is **skipped** unless ``force_dirty=True`` (per regression guard rg-017
      "never silently force-remove dirty content"). With ``force_dirty=True``
      the dirty content is removed and the symlink reinstated.

    Config drift (``.mcp.json`` / ``.vscode/mcp.json``) is repaired by
    re-running the install-time writers when ``mcp_servers`` is supplied.

    Returns a report dict ``{"repaired": [...], "skipped": [...]}`` whose
    entries reuse the :func:`doctor` finding shape.
    """
    from agentic_bootstrap.install import (
        _run_generator,
        _set_git_hooks_path,
    )
    from agentic_bootstrap.mcp_sync import sync_mcp_configs
    import shutil

    target = Path(target).resolve()
    findings = doctor(target=target, mcp_servers=mcp_servers)
    repaired: list[Finding] = []
    skipped: list[Finding] = []

    if not findings:
        return {"repaired": repaired, "skipped": skipped}

    clone = target.joinpath(*CLONE_SUBDIR)

    config_drift_paths = {
        f["path"] for f in findings if f["kind"] == "config_drift"
    }
    if config_drift_paths and mcp_servers:
        drifted_surfaces = [
            _MANAGED_SURFACE_BY_CONFIG_PATH[p]
            for p in config_drift_paths
            if p in _MANAGED_SURFACE_BY_CONFIG_PATH
        ]
        if drifted_surfaces:
            sync_mcp_configs(
                target, mcp_servers, surfaces=drifted_surfaces, check_only=False
            )

    for finding in findings:
        kind = finding["kind"]
        path = finding["path"]

        if kind == "surface_drift":
            from agentic_bootstrap.install import _resolve_in_clone

            link = target / path
            remote_path = _resolve_in_clone(clone, path)
            if not remote_path.exists():
                skipped.append(finding)
                continue

            if link.is_symlink() or not link.exists():
                # Broken/foreign symlink or missing entirely: safe to replace.
                if link.is_symlink():
                    link.unlink()
            elif link.is_dir() and any(link.iterdir()):
                if not force_dirty:
                    skipped.append(finding)
                    continue
                shutil.rmtree(link)
            elif link.is_dir():
                link.rmdir()
            else:
                if not force_dirty:
                    skipped.append(finding)
                    continue
                link.unlink()

            link.parent.mkdir(parents=True, exist_ok=True)
            rel = os.path.relpath(remote_path, link.parent)
            link.symlink_to(rel, target_is_directory=True)
            repaired.append(finding)
            continue

        if kind == "generated_drift":
            # Re-run the generator once for the whole batch — it rewrites
            # every per-agent surface from the canonical source. Collapse
            # subsequent generated_drift findings into the same repair op.
            if any(f["kind"] == "generated_drift" for f in repaired):
                repaired.append(finding)
                continue
            try:
                _run_generator(target, clone)
            except Exception:
                skipped.append(finding)
                continue
            repaired.append(finding)
            continue

        if kind == "config_drift":
            if mcp_servers and path in _MANAGED_SURFACE_BY_CONFIG_PATH:
                repaired.append(finding)
            else:
                skipped.append(finding)
            continue

        # missing_clone / missing_manifest are out of scope here — caller
        # should run install/update instead. Surface as skipped.
        skipped.append(finding)

    # Refresh git hooks path defensively when we touched anything.
    if repaired and (target / ".git").exists():
        try:
            _set_git_hooks_path(target)
        except Exception:
            pass

    return {"repaired": repaired, "skipped": skipped}
