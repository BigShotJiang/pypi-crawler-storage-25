"""Packaging-floor pin for `agentic-bootstrap`.

Bootstrap's default install path invokes `uvx mcp-agent-handoff` which
imports `agentic_protocol.branch_naming` at module import. Bootstrap's
own `agentic-protocol` declaration must therefore not allow `uvx` to
resolve a protocol older than what those servers import at startup.
The floor tracks `mcp-agent-handoff` / `mcp-agent-orchestrator`'s own
declared `agentic-protocol` floor so the bootstrap venv cannot resolve
an older protocol than the launched servers expect.
"""

from __future__ import annotations

import re
import tomllib
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parents[1]

# Minimum acceptable lower bound. Bumped alongside coordinated releases
# of mcp-agent-handoff / mcp-agent-orchestrator that raise their own
# `agentic-protocol` floor. >=0.1.2 was the original branch_naming
# floor; >=0.1.4 matches the 0.4.1 / 0.11.0 / 0.4.4 release coordinate.
_MIN_PROTOCOL_FLOOR = (0, 1, 4)
_FLOOR_RE = re.compile(r">=(\d+)\.(\d+)\.(\d+)")


def _load_pyproject() -> dict:
    with (PACKAGE_ROOT / "pyproject.toml").open("rb") as handle:
        return tomllib.load(handle)


def test_pyproject_pins_agentic_protocol_lower_bound_at_branch_naming_release() -> None:
    pyproject = _load_pyproject()
    deps = pyproject["project"]["dependencies"]
    protocol_dep = next((d for d in deps if d.startswith("agentic-protocol")), None)
    assert protocol_dep is not None, "agentic-protocol must be declared as a runtime dep"
    match = _FLOOR_RE.search(protocol_dep)
    assert match is not None, (
        f"agentic-protocol must declare an explicit >=X.Y.Z lower bound, got {protocol_dep!r}"
    )
    actual_floor = tuple(int(part) for part in match.groups())
    assert actual_floor >= _MIN_PROTOCOL_FLOOR, (
        f"agentic-protocol lower bound must be >={'.'.join(str(p) for p in _MIN_PROTOCOL_FLOOR)} "
        f"(matches the floor pinned by mcp-agent-handoff / mcp-agent-orchestrator that bootstrap "
        f"launches via uvx), got {protocol_dep!r}"
    )
    assert "<0.2.0" in protocol_dep, (
        f"agentic-protocol upper bound must remain <0.2.0 (single major hard pin), "
        f"got {protocol_dep!r}"
    )
