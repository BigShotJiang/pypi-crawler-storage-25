"""Subcommand contracts for ``agentic-bootstrap status / doctor / update / repair``.

These tests pin the smallest end-to-end behavior of each post-install
subcommand. They use the ``fake_remote`` and ``fake_remote_with_surfaces``
fixtures from ``test_install.py`` via direct import so the fixtures stay in
one place.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from tests.test_install import (  # noqa: F401
    _handoff_src_dir,
    fake_remote,
    fake_remote_with_generator,
    fake_remote_with_surfaces,
)


SAMPLE_MCP_SERVERS = {
    "agent-handoff-mcp": {
        "command": sys.executable,
        "args": ["-m", "agent_handoff_mcp"],
        "env": {"PYTHONPATH": str(_handoff_src_dir())},
    },
}


def _git(*args: str, cwd: Path) -> str:
    return subprocess.run(
        ["git", *args],
        check=True,
        capture_output=True,
        text=True,
        cwd=str(cwd),
        timeout=30,
    ).stdout.strip()


def _init_git_repo(path: Path) -> None:
    _git("init", "--initial-branch=main", cwd=path)
    _git("config", "user.email", "test@example.com", cwd=path)
    _git("config", "user.name", "Test", cwd=path)


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


def test_status_prints_manifest_summary(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """``status(target=...)`` reads the manifest and returns a multi-line
    human-readable summary that names the remote, the resolved SHA, and the
    counts of materialized surfaces and touched configs."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import status

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    manifest = install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    summary = status(target=target)

    assert manifest["remote_sha"] in summary
    assert url in summary
    assert ref in summary
    # fake_remote_with_surfaces ships 3 shared surfaces; install also
    # prepares the 4 generated per-agent surfaces — 7 total.
    assert "surfaces:" in summary and "7" in summary
    assert "configs:" in summary and "4" in summary
    assert "shared" in summary
    assert "generated" in summary


def test_status_reports_handoff_state_paths_and_schema_version(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """PLAN0003-S4-ST-001: after a managed install, status must invoke
    init-state --check and append the resolved state_dir, db_path,
    exports_dir, and schema_version to the summary so operators can see
    the cold-start contract was satisfied."""
    from agent_handoff_mcp.shared_schema import HANDOFF_SCHEMA_VERSION

    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import status

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    summary = status(target=target)

    assert "handoff state:" in summary
    assert str(target / ".task-state") in summary
    assert str(target / ".task-state" / "handoff.db") in summary
    assert str(target / ".task-state" / "exports") in summary
    assert f"schema_version: {HANDOFF_SCHEMA_VERSION}" in summary


def test_status_omits_handoff_state_section_for_no_mcp_servers_install(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """PLAN0003-S4-ST-002: a --no-mcp-servers install does not register
    init-state, so status must not attempt to query it (no
    'handoff state:' section in the summary)."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import status

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=None,
    )

    summary = status(target=target)
    assert "handoff state:" not in summary


def test_status_missing_manifest_raises(tmp_path: Path) -> None:
    """``status`` against a target that was never installed must raise
    ``FileNotFoundError`` rather than silently returning a stub."""
    from agentic_bootstrap.subcommands import status

    target = tmp_path / "uninstalled"
    target.mkdir()

    with pytest.raises(FileNotFoundError):
        status(target=target)


def test_status_console_script(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """``python -m agentic_bootstrap status --target <path>`` exits 0 and
    prints the same summary."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    manifest = install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    result = subprocess.run(
        [sys.executable, "-m", "agentic_bootstrap", "status", "--target", str(target)],
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0, result.stderr
    assert manifest["remote_sha"] in result.stdout


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


def test_doctor_clean_install_returns_no_findings(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """A fresh install must produce zero doctor findings."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    findings = doctor(target=target)
    assert findings == []


def test_doctor_detects_missing_clone(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """When `.agentic/remote/.git` is gone, doctor must flag it."""
    import shutil

    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )
    shutil.rmtree(target / ".agentic" / "remote")

    findings = doctor(target=target)
    kinds = {f["kind"] for f in findings}
    assert "missing_clone" in kinds


def test_doctor_detects_broken_surface_symlink(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """When a shared surface is recorded as `shared` in the manifest but the
    symlink no longer resolves into the clone, doctor must flag it."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    # Break the scripts/hooks symlink: replace it with a stub directory.
    hooks_link = target / "scripts" / "hooks"
    hooks_link.unlink()
    hooks_link.mkdir()

    findings = doctor(target=target)
    kinds_paths = {(f["kind"], f["path"]) for f in findings}
    assert ("surface_drift", "scripts/hooks") in kinds_paths


def test_doctor_detects_drift_in_generated_surface(
    tmp_path: Path, fake_remote_with_generator: tuple[str, str]
) -> None:
    """When a per-agent generated artifact has been hand-edited away from
    what the canonical sources would produce, doctor must emit a
    ``generated_drift`` finding pointing at the owning surface."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_generator
    install(target=target, remote_url=url, remote_ref=ref)

    # Tamper with a generated SKILL.md.
    skill_files = list((target / ".claude" / "skills").glob("*/SKILL.md"))
    assert skill_files, "fixture must have produced at least one Claude SKILL.md"
    skill_files[0].write_text(skill_files[0].read_text() + "\nhand-edited drift\n")

    findings = doctor(target=target)
    kinds_paths = {(f["kind"], f["path"]) for f in findings}
    assert ("generated_drift", ".claude/skills") in kinds_paths


def test_repair_re_runs_generator_for_generated_drift(
    tmp_path: Path, fake_remote_with_generator: tuple[str, str]
) -> None:
    """Repair must re-run the generator and clear ``generated_drift``."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor, repair

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_generator
    install(target=target, remote_url=url, remote_ref=ref)

    skill_files = list((target / ".claude" / "skills").glob("*/SKILL.md"))
    drifted = skill_files[0]
    drifted.write_text(drifted.read_text() + "\nhand-edited drift\n")
    assert any(f["kind"] == "generated_drift" for f in doctor(target=target))

    report = repair(target=target)
    assert any(
        e["kind"] == "generated_drift" for e in report["repaired"]
    ), report

    # After repair, doctor reports no generated drift.
    follow_up = doctor(target=target)
    assert not any(f["kind"] == "generated_drift" for f in follow_up), follow_up


def test_doctor_detects_drifted_managed_mcp_server(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """When `.mcp.json` no longer carries the managed server config, doctor
    must flag a `config_drift` for `.mcp.json`."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    mcp_path = target / ".mcp.json"
    doc = json.loads(mcp_path.read_text())
    del doc["mcpServers"]["agent-handoff-mcp"]
    mcp_path.write_text(json.dumps(doc, indent=2))

    findings = doctor(target=target, mcp_servers=SAMPLE_MCP_SERVERS)
    kinds_paths = {(f["kind"], f["path"]) for f in findings}
    assert ("config_drift", ".mcp.json") in kinds_paths


def test_doctor_flags_missing_handoff_db_when_mcp_servers_registered(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """PLAN0003-S4-DR-001: install registered .mcp.json -> doctor must flag
    missing .task-state/handoff.db as state_drift."""
    import shutil

    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    # Sanity: install wrote .mcp.json into configs and produced handoff.db.
    manifest = json.loads((target / ".agentic-bootstrap.json").read_text())
    paths = {entry["path"] for entry in manifest["configs"]}
    assert ".mcp.json" in paths
    assert (target / ".task-state" / "handoff.db").is_file()

    shutil.rmtree(target / ".task-state")

    findings = doctor(target=target)
    kinds_paths = {(f["kind"], f["path"]) for f in findings}
    assert ("state_drift", ".task-state/handoff.db") in kinds_paths


def test_doctor_suppresses_state_check_after_no_mcp_servers_install(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """PLAN0003-S4-DR-002: install with mcp_servers=None must NOT register
    .mcp.json in the manifest, and doctor must NOT raise state_drift even
    though .task-state/handoff.db is intentionally absent."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=None,
    )

    manifest = json.loads((target / ".agentic-bootstrap.json").read_text())
    paths = {entry["path"] for entry in manifest["configs"]}
    assert ".mcp.json" not in paths
    assert not (target / ".task-state").exists()

    findings = doctor(target=target)
    kinds = {f["kind"] for f in findings}
    assert "state_drift" not in kinds


def test_doctor_console_script_exit_codes(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """`agentic-bootstrap doctor --target` exits 0 when clean, 1 when drift
    is detected."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    clean = subprocess.run(
        [sys.executable, "-m", "agentic_bootstrap", "doctor", "--target", str(target)],
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert clean.returncode == 0, clean.stderr

    (target / "scripts" / "hooks").unlink()

    dirty = subprocess.run(
        [sys.executable, "-m", "agentic_bootstrap", "doctor", "--target", str(target)],
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert dirty.returncode == 1
    assert "surface_drift" in dirty.stdout or "surface_drift" in dirty.stderr


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


@pytest.fixture()
def fake_remote_with_surfaces_two_refs(tmp_path: Path) -> tuple[str, str, str]:
    """Build a local bare git remote with required shared surfaces on two refs."""
    src = tmp_path / "remote-src"
    src.mkdir()
    _git("init", "--initial-branch=main", cwd=src)
    _git("config", "user.email", "test@example.com", cwd=src)
    _git("config", "user.name", "Test", cwd=src)

    for surface in (".github/hooks", "scripts/hooks", "docs/agentic/contracts"):
        surface_dir = src / surface
        surface_dir.mkdir(parents=True)
        (surface_dir / "MARKER.md").write_text(f"shared {surface} v1\n")

    _git("add", "-A", cwd=src)
    _git("commit", "-m", "v1", cwd=src)
    _git("tag", "v0.1.0", cwd=src)

    (src / "docs" / "agentic" / "contracts" / "MARKER.md").write_text(
        "shared docs/agentic/contracts v2\n"
    )
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "v2", cwd=src)
    _git("tag", "v0.2.0", cwd=src)

    bare = tmp_path / "remote.git"
    _git("clone", "--bare", str(src), str(bare), cwd=tmp_path)
    return f"file://{bare}", "v0.1.0", "v0.2.0"


@pytest.fixture()
def fake_remote_with_two_refs(tmp_path: Path) -> tuple[str, str, str]:
    """Build a local bare git remote shipping two refs (v0.1.0 and v0.2.0)
    with different content so the resolved SHA changes between updates."""
    src = tmp_path / "remote-src"
    src.mkdir()
    _git("init", "--initial-branch=main", cwd=src)
    _git("config", "user.email", "test@example.com", cwd=src)
    _git("config", "user.name", "Test", cwd=src)
    (src / "skill.md").write_text("# v1\n")
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "v1", cwd=src)
    _git("tag", "v0.1.0", cwd=src)
    (src / "skill.md").write_text("# v2\n")
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "v2", cwd=src)
    _git("tag", "v0.2.0", cwd=src)

    bare = tmp_path / "remote.git"
    _git("clone", "--bare", str(src), str(bare), cwd=tmp_path)
    return f"file://{bare}", "v0.1.0", "v0.2.0"


def test_update_advances_remote_sha(
    tmp_path: Path, fake_remote_with_two_refs: tuple[str, str, str]
) -> None:
    """`update(target, remote_ref=<new>)` re-runs install and the manifest's
    remote_sha must change to the new ref's tip."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import update

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref_old, ref_new = fake_remote_with_two_refs

    install(target=target, remote_url=url, remote_ref=ref_old)
    sha_before = json.loads((target / ".agentic-bootstrap.json").read_text())["remote_sha"]

    manifest = update(target=target, remote_ref=ref_new, enforce_required_surfaces=False)

    assert manifest["remote_ref"] == ref_new
    assert manifest["remote_sha"] != sha_before


def test_update_uses_existing_manifest_remote_url(
    tmp_path: Path, fake_remote_with_two_refs: tuple[str, str, str]
) -> None:
    """`update` reads remote_url from the existing manifest by default so the
    caller doesn't need to repeat it."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import update

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref_old, ref_new = fake_remote_with_two_refs

    install(target=target, remote_url=url, remote_ref=ref_old)

    manifest = update(target=target, remote_ref=ref_new, enforce_required_surfaces=False)
    assert manifest["remote_url"] == url


def test_update_preserves_managed_mcp_registration_when_flag_omitted(
    tmp_path: Path, fake_remote_with_surfaces_two_refs: tuple[str, str, str]
) -> None:
    """PLAN0003-S4-UP-001: managed installs must retain MCP registration
    across update() calls even when the caller omits mcp_servers."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import status, update

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref_old, ref_new = fake_remote_with_surfaces_two_refs

    install(
        target=target,
        remote_url=url,
        remote_ref=ref_old,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    manifest = update(target=target, remote_ref=ref_new)
    config_paths = {entry["path"] for entry in manifest["configs"]}

    assert ".mcp.json" in config_paths
    assert ".vscode/mcp.json" in config_paths
    assert ".codex/config.toml" in config_paths
    assert "handoff state:" in status(target=target)


def test_update_requires_required_surfaces_by_default(
    tmp_path: Path, fake_remote_with_two_refs: tuple[str, str, str]
) -> None:
    """PLAN0003-S4-UP-002: update must refuse refs missing scripts/hooks
    unless the caller explicitly opts out."""
    from agentic_bootstrap.install import BootstrapManifestValidationError, install
    from agentic_bootstrap.subcommands import update

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref_old, ref_new = fake_remote_with_two_refs

    install(
        target=target,
        remote_url=url,
        remote_ref=ref_old,
        enforce_required_surfaces=False,
    )

    with pytest.raises(BootstrapManifestValidationError):
        update(target=target, remote_ref=ref_new)


def test_update_console_script(
    tmp_path: Path, fake_remote_with_two_refs: tuple[str, str, str]
) -> None:
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref_old, ref_new = fake_remote_with_two_refs

    install(target=target, remote_url=url, remote_ref=ref_old)
    sha_before = json.loads((target / ".agentic-bootstrap.json").read_text())["remote_sha"]

    result = subprocess.run(
        [
            sys.executable, "-m", "agentic_bootstrap",
            "update", "--target", str(target), "--remote-ref", ref_new,
            "--no-enforce-required-surfaces",
        ],
        check=False, capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 0, result.stderr
    sha_after = json.loads((target / ".agentic-bootstrap.json").read_text())["remote_sha"]
    assert sha_after != sha_before


def test_update_preserves_profile_all_lifecycle_hoist(
    tmp_path: Path,
    fake_remote_with_generator: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """AHMCP-48: ``agentic-bootstrap update`` (which delegates to
    ``install(profile=PROFILE_ALL, ...)``) must preserve the lifecycle
    hoist on the consumer.

    The production fix lives entirely in ``install.py`` — ``update()``
    inherits it via line ``subcommands.py:486``'s install delegation.
    This explicit assertion exists so a future refactor of ``update()``
    that bypasses ``install()`` (e.g. to skip surfaces for speed) cannot
    silently regress the epic-level drift contract.
    """
    from agentic_bootstrap.install import (
        LIFECYCLE_INCLUDE_SENTINEL_BEGIN,
        install,
    )
    from agentic_bootstrap.subcommands import update

    monkeypatch.setenv("HOME", str(tmp_path / "fake-home"))
    monkeypatch.setenv("USERPROFILE", str(tmp_path / "fake-home"))
    (tmp_path / "fake-home").mkdir()

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_generator

    install(target=target, remote_url=url, remote_ref=ref, profile="all")
    update(target=target, remote_ref=ref, enforce_required_surfaces=False)

    assert (target / "Makefile.d" / "lifecycle.mk").is_file(), (
        "after install(--profile all) followed by update(), the lifecycle "
        "fragment must remain materialized in the consumer"
    )
    assert (target / "scripts" / "agentic" / "lifecycle" / "__init__.py").is_file()

    makefile_text = (target / "Makefile").read_text()
    assert makefile_text.count(LIFECYCLE_INCLUDE_SENTINEL_BEGIN) == 1, (
        "update() must not duplicate the sentinel-bracketed include block; "
        "exactly one LIFECYCLE_INCLUDE_SENTINEL_BEGIN marker is the "
        "post-fix invariant for the install->update sequence"
    )


# ---------------------------------------------------------------------------
# repair
# ---------------------------------------------------------------------------


def test_repair_restores_missing_surface_symlink(
    tmp_path: Path, fake_remote_with_surfaces
) -> None:
    """A clean install whose `scripts/hooks` symlink was deleted entirely
    should be restored by `repair` without --force-dirty."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor, repair

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(target=target, remote_url=url, remote_ref=ref)

    surface = target / "scripts/hooks"
    surface.unlink()
    assert any(f["kind"] == "surface_drift" for f in doctor(target=target))

    report = repair(target=target)
    assert report["repaired"], report
    assert surface.is_symlink()
    assert doctor(target=target) == []


def test_repair_refuses_real_directory_without_force(
    tmp_path: Path, fake_remote_with_surfaces
) -> None:
    """A real non-empty directory at a managed surface is treated as user
    content and must NOT be silently overwritten without --force-dirty."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import repair

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(target=target, remote_url=url, remote_ref=ref)

    surface = target / "scripts/hooks"
    surface.unlink()
    surface.mkdir()
    (surface / "user-content.txt").write_text("important local notes\n")

    report = repair(target=target)
    assert any(s["path"] == "scripts/hooks" for s in report["skipped"]), report
    assert (surface / "user-content.txt").exists()
    assert not surface.is_symlink()


def test_repair_force_dirty_overwrites_real_directory(
    tmp_path: Path, fake_remote_with_surfaces
) -> None:
    """With --force-dirty the dirty surface is replaced with the canonical
    symlink (rg-017: never silently force; here it's explicit)."""
    from agentic_bootstrap.install import install
    from agentic_bootstrap.subcommands import doctor, repair

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(target=target, remote_url=url, remote_ref=ref)

    surface = target / "scripts/hooks"
    surface.unlink()
    surface.mkdir()
    (surface / "user-content.txt").write_text("user data lost on force\n")

    report = repair(target=target, force_dirty=True)
    assert "scripts/hooks" in [s["path"] for s in report["repaired"]], report
    assert surface.is_symlink()
    assert doctor(target=target) == []


def test_repair_console_script_force_dirty_flag(
    tmp_path: Path, fake_remote_with_surfaces
) -> None:
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(target=target, remote_url=url, remote_ref=ref)

    surface = target / "scripts/hooks"
    surface.unlink()
    surface.mkdir()
    (surface / "user-content.txt").write_text("x\n")

    # Without --force-dirty: refuses, exit 0 (skipped is not a failure).
    refused = subprocess.run(
        [sys.executable, "-m", "agentic_bootstrap", "repair", "--target", str(target)],
        check=False, capture_output=True, text=True, timeout=30,
    )
    assert refused.returncode == 0, refused.stderr
    assert "skipped" in refused.stdout.lower()
    assert not surface.is_symlink()

    # With --force-dirty: replaces.
    forced = subprocess.run(
        [sys.executable, "-m", "agentic_bootstrap",
         "repair", "--target", str(target), "--force-dirty"],
        check=False, capture_output=True, text=True, timeout=30,
    )
    assert forced.returncode == 0, forced.stderr
    assert surface.is_symlink()


# ---------------------------------------------------------------------------
# CLI --mcp-servers flag plumbing
# ---------------------------------------------------------------------------


def test_cli_install_with_mcp_servers_flag_writes_configs(
    tmp_path: Path, fake_remote_with_surfaces
) -> None:
    """`agentic-bootstrap install --mcp-servers <file.json>` reads the JSON
    file and writes managed MCP entries into .mcp.json + .vscode/mcp.json."""
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    spec_file = tmp_path / "servers.json"
    spec_file.write_text(json.dumps(SAMPLE_MCP_SERVERS))

    result = subprocess.run(
        [
            sys.executable, "-m", "agentic_bootstrap",
            "install",
            "--target", str(target),
            "--remote-url", url,
            "--remote-ref", ref,
            "--mcp-servers", str(spec_file),
            # Plan 0009 flipped the CLI default profile to ``minimal``;
            # MCP-config writers run only under ``all``.
            "--profile", "all",
        ],
        check=False, capture_output=True, text=True, timeout=60,
    )
    assert result.returncode == 0, result.stderr

    mcp_doc = json.loads((target / ".mcp.json").read_text())
    assert mcp_doc["mcpServers"]["agent-handoff-mcp"] == SAMPLE_MCP_SERVERS["agent-handoff-mcp"]
    vscode_doc = json.loads((target / ".vscode/mcp.json").read_text())
    assert vscode_doc["servers"]["agent-handoff-mcp"] == SAMPLE_MCP_SERVERS["agent-handoff-mcp"]


def test_cli_doctor_with_mcp_servers_flag_detects_drift(
    tmp_path: Path, fake_remote_with_surfaces
) -> None:
    """`doctor --mcp-servers <file>` flags config_drift when an installed
    managed MCP entry has been removed from .mcp.json."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target, remote_url=url, remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    # Tamper with .mcp.json by removing the managed entry.
    mcp_path = target / ".mcp.json"
    doc = json.loads(mcp_path.read_text())
    del doc["mcpServers"]["agent-handoff-mcp"]
    mcp_path.write_text(json.dumps(doc))

    spec_file = tmp_path / "servers.json"
    spec_file.write_text(json.dumps(SAMPLE_MCP_SERVERS))

    result = subprocess.run(
        [
            sys.executable, "-m", "agentic_bootstrap",
            "doctor",
            "--target", str(target),
            "--mcp-servers", str(spec_file),
        ],
        check=False, capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 1, result.stdout
    assert "config_drift: .mcp.json" in result.stdout


def test_cli_repair_with_mcp_servers_flag_restores_config(
    tmp_path: Path, fake_remote_with_surfaces
) -> None:
    """`repair --mcp-servers <file>` re-writes .mcp.json so the managed
    entry is present again."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces
    install(
        target=target, remote_url=url, remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    mcp_path = target / ".mcp.json"
    doc = json.loads(mcp_path.read_text())
    del doc["mcpServers"]["agent-handoff-mcp"]
    mcp_path.write_text(json.dumps(doc))

    spec_file = tmp_path / "servers.json"
    spec_file.write_text(json.dumps(SAMPLE_MCP_SERVERS))

    result = subprocess.run(
        [
            sys.executable, "-m", "agentic_bootstrap",
            "repair",
            "--target", str(target),
            "--mcp-servers", str(spec_file),
        ],
        check=False, capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 0, result.stderr
    fixed = json.loads(mcp_path.read_text())
    assert fixed["mcpServers"]["agent-handoff-mcp"] == SAMPLE_MCP_SERVERS["agent-handoff-mcp"]
