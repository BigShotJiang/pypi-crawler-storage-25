"""Slice 1 (Plan 0008) — bootstrap harness-hook wiring.

Verifies ``_write_claude_settings_hooks`` and the public ``install()``
``harness_hook_scope`` parameter:

1. Cold install (default ``local`` scope) writes a single ``Stop`` hook
   entry into ``<target>/.claude/settings.local.json`` with the
   ``_managed_by: agentic-bootstrap`` sentinel and a command whose
   basename ends in ``compact-session.py``.
2. Re-running install matches the existing entry by sentinel +
   basename and does NOT duplicate it (in-place rewrite, one entry).
3. Pre-existing unrelated ``hooks.Stop[]`` entries are preserved
   (append, not replace).
4. ``harness_hook_scope='user'`` writes into the sandboxed
   ``~/.claude/settings.json`` rather than the project-local file.
5. Path-variant idempotency: an install whose recorded command happens
   to be relative is collapsed to one entry on a re-install whose
   command resolves to an absolute path.

The user-scope tests use ``monkeypatch.setenv("HOME", ...)`` so the
real user's ``~/.claude/settings.json`` is never touched.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Fixtures (re-implemented locally so this slice does not depend on the
# fixtures defined in test_install.py — keeps the failure surface small.)
# ---------------------------------------------------------------------------


def _git(*args: str, cwd: Path) -> str:
    return subprocess.run(
        ["git", *args],
        check=True,
        capture_output=True,
        text=True,
        cwd=str(cwd),
        timeout=30,
    ).stdout.strip()


def _init_git_repo(path: Path) -> None:
    _git("init", "--initial-branch=main", cwd=path)
    _git("config", "user.email", "test@example.com", cwd=path)
    _git("config", "user.name", "Test", cwd=path)


@pytest.fixture()
def fake_remote(tmp_path: Path) -> tuple[str, str]:
    src = tmp_path / "remote-src"
    src.mkdir()
    _init_git_repo(src)
    (src / "skill.md").write_text("# fake skill\n")
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "seed", cwd=src)
    _git("tag", "v0.1.0", cwd=src)

    bare = tmp_path / "remote.git"
    _git("clone", "--bare", str(src), str(bare), cwd=tmp_path)
    return f"file://{bare}", "v0.1.0"


def _fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "fake-home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("USERPROFILE", str(home))
    return home


# ---------------------------------------------------------------------------
# Cold install: default scope (local) writes the sentinel-tagged Stop entry
# ---------------------------------------------------------------------------


def test_cold_install_writes_stop_hook_with_sentinel_to_local_settings(
    tmp_path: Path,
    fake_remote: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentic_bootstrap.install import install

    _fake_home(tmp_path, monkeypatch)
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    manifest = install(
        target=target,
        remote_url=url,
        remote_ref=ref,
    )

    settings_path = target / ".claude" / "settings.local.json"
    assert settings_path.is_file(), (
        ".claude/settings.local.json must be created for the default local scope"
    )

    doc = json.loads(settings_path.read_text())
    stop_entries = doc["hooks"]["Stop"]
    assert isinstance(stop_entries, list), "hooks.Stop must be a list"
    managed = [e for e in stop_entries if e.get("_managed_by") == "agentic-bootstrap"]
    assert len(managed) == 1, "exactly one bootstrap-managed Stop entry expected"
    assert managed[0]["command"].endswith("compact-session.py"), (
        "managed entry command must point at compact-session.py"
    )

    # Manifest records the new surface.
    paths = [c["path"] for c in manifest["configs"]]
    assert ".claude/settings.local.json" in paths


# ---------------------------------------------------------------------------
# Sentinel-based no-op: a second install does not duplicate the entry.
# ---------------------------------------------------------------------------


def test_repeat_install_dedupes_managed_entry_via_sentinel(
    tmp_path: Path,
    fake_remote: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentic_bootstrap.install import install

    _fake_home(tmp_path, monkeypatch)
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    install(target=target, remote_url=url, remote_ref=ref)
    install(target=target, remote_url=url, remote_ref=ref)

    doc = json.loads((target / ".claude" / "settings.local.json").read_text())
    managed = [
        e for e in doc["hooks"]["Stop"] if e.get("_managed_by") == "agentic-bootstrap"
    ]
    assert len(managed) == 1, "repeat install must collapse to one managed entry"


# ---------------------------------------------------------------------------
# Append (do not replace) pre-existing unrelated Stop entries.
# ---------------------------------------------------------------------------


def test_install_appends_to_existing_unrelated_stop_entries(
    tmp_path: Path,
    fake_remote: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentic_bootstrap.install import install

    _fake_home(tmp_path, monkeypatch)
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    pre_existing = {
        "hooks": {
            "Stop": [
                {"command": "echo unrelated", "_owner": "user"},
            ]
        },
        "unrelatedTopLevelKey": {"keepMe": True},
    }
    settings_path = target / ".claude" / "settings.local.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(json.dumps(pre_existing) + "\n")

    install(target=target, remote_url=url, remote_ref=ref)

    doc = json.loads(settings_path.read_text())
    commands = [e.get("command") for e in doc["hooks"]["Stop"]]
    assert "echo unrelated" in commands, "unrelated Stop entry must be preserved"
    managed = [
        e for e in doc["hooks"]["Stop"] if e.get("_managed_by") == "agentic-bootstrap"
    ]
    assert len(managed) == 1, "managed entry appended exactly once"
    assert doc["unrelatedTopLevelKey"] == {"keepMe": True}, (
        "unrelated top-level keys must survive the merge"
    )


# ---------------------------------------------------------------------------
# Scope=user writes into the sandboxed home, NOT the project file.
# ---------------------------------------------------------------------------


def test_user_scope_writes_to_home_settings(
    tmp_path: Path,
    fake_remote: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentic_bootstrap.install import install

    home = _fake_home(tmp_path, monkeypatch)
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        harness_hook_scope="user",
    )

    user_path = home / ".claude" / "settings.json"
    assert user_path.is_file(), (
        "user-scope must write ~/.claude/settings.json (sandboxed via HOME)"
    )
    doc = json.loads(user_path.read_text())
    managed = [
        e for e in doc["hooks"]["Stop"] if e.get("_managed_by") == "agentic-bootstrap"
    ]
    assert len(managed) == 1

    # Project-local file must NOT be created when scope=user.
    assert not (target / ".claude" / "settings.local.json").exists(), (
        "user-scope install must not also write the project-local settings file"
    )


# ---------------------------------------------------------------------------
# Path-variant idempotency: rel-cwd install + abs-cwd reinstall = one entry.
# ---------------------------------------------------------------------------


def test_path_variant_idempotency_collapses_to_one_managed_entry(
    tmp_path: Path,
    fake_remote: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Simulate a prior install whose recorded command path is in a
    different shape (e.g. relative vs absolute) — re-running install
    must match by ``(_managed_by, basename(command))`` and rewrite in
    place rather than appending a second managed entry.
    """
    from agentic_bootstrap.install import install

    _fake_home(tmp_path, monkeypatch)
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    settings_path = target / ".claude" / "settings.local.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    pre_existing = {
        "hooks": {
            "Stop": [
                {
                    "_managed_by": "agentic-bootstrap",
                    "command": "scripts/hooks/compact-session.py",
                }
            ]
        }
    }
    settings_path.write_text(json.dumps(pre_existing) + "\n")

    install(target=target, remote_url=url, remote_ref=ref)

    doc = json.loads(settings_path.read_text())
    managed = [
        e for e in doc["hooks"]["Stop"] if e.get("_managed_by") == "agentic-bootstrap"
    ]
    assert len(managed) == 1, (
        "path-variant managed entry must be replaced in place, not duplicated"
    )


# ---------------------------------------------------------------------------
# CLI surface: --harness-hook-scope user routes through to install().
# ---------------------------------------------------------------------------


def test_cli_harness_hook_scope_user_writes_to_home(
    tmp_path: Path,
    fake_remote: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentic_bootstrap.cli import main

    home = _fake_home(tmp_path, monkeypatch)
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    rc = main(
        [
            "install",
            "--target",
            str(target),
            "--remote-url",
            url,
            "--remote-ref",
            ref,
            "--no-mcp-servers",
            "--harness-hook-scope",
            "user",
        ]
    )
    assert rc == 0

    user_path = home / ".claude" / "settings.json"
    assert user_path.is_file()
    doc = json.loads(user_path.read_text())
    managed = [
        e for e in doc["hooks"]["Stop"] if e.get("_managed_by") == "agentic-bootstrap"
    ]
    assert len(managed) == 1
    assert not (target / ".claude" / "settings.local.json").exists()
