"""TDD gate for agentic-bootstrap minimal `install` flow.

Verifies the smallest end-to-end behavior that unblocks E17-10 Slice 5:

    agentic_bootstrap.install.install(
        target=<consumer_root>,
        remote_url=<git url>,
        remote_ref=<tag or branch>,
    )

must

1. Clone the remote into ``<consumer_root>/.agentic/remote/`` at
   ``remote_ref`` (the directory must contain a ``.git`` folder).
2. Write ``<consumer_root>/.agentic-bootstrap.json`` carrying schema_version,
   remote_url, remote_ref, the resolved 40-char remote_sha, and an empty
   ``surfaces`` list (symlinks land in a follow-on slice).

Both the library entrypoint and the ``agentic-bootstrap install --target ...``
console script must satisfy the contract.

The test uses a local bare repository as the remote so it is offline-safe and
deterministic. No network is required.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _git(*args: str, cwd: Path) -> str:
    result = subprocess.run(
        ["git", *args],
        check=True,
        capture_output=True,
        text=True,
        cwd=str(cwd),
        timeout=30,
    )
    return result.stdout.strip()


def _handoff_src_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "mcp-agent-handoff" / "src"


def _install_fake_uvx(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    shim_dir = tmp_path / "bin"
    shim_dir.mkdir()
    uvx = shim_dir / "uvx"
    uvx.write_text(
        "#!/bin/sh\n"
        "case \"$1\" in\n"
        "mcp-agent-handoff|mcp-agent-handoff@*)\n"
        f"  shift\n  PYTHONPATH=\"{_handoff_src_dir()}:$PYTHONPATH\" exec python -m agent_handoff_mcp \"$@\"\n"
        "  ;;\n"
        "--from)\n"
        "  case \"$2\" in\n"
        "  mcp-agent-handoff|mcp-agent-handoff@*)\n"
        f"  shift 2\n  PYTHONPATH=\"{_handoff_src_dir()}:$PYTHONPATH\" exec \"$@\"\n"
        "    ;;\n"
        "  esac\n"
        "  ;;\n"
        "esac\n"
        "echo \"unsupported uvx payload: $1\" >&2\n"
        "exit 1\n"
    )
    uvx.chmod(0o755)
    monkeypatch.setenv("PATH", f"{shim_dir}:{os.environ.get('PATH', '')}")


@pytest.fixture()
def fake_remote(tmp_path: Path) -> tuple[str, str]:
    """Build a local bare git remote with one tag ``v0.1.0``.

    Returns (remote_url, tag_name). The remote_url is a ``file://`` URL so it
    can be passed to ``git clone`` exactly as a real ``git+ssh://`` URL would
    be.
    """
    src = tmp_path / "remote-src"
    src.mkdir()
    _git("init", "--initial-branch=main", cwd=src)
    _git("config", "user.email", "test@example.com", cwd=src)
    _git("config", "user.name", "Test", cwd=src)
    (src / "skill.md").write_text("# fake skill\n")
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "seed", cwd=src)
    _git("tag", "v0.1.0", cwd=src)

    bare = tmp_path / "remote.git"
    _git("clone", "--bare", str(src), str(bare), cwd=tmp_path)

    return f"file://{bare}", "v0.1.0"


# ---------------------------------------------------------------------------
# Library API contract
# ---------------------------------------------------------------------------


def test_install_clones_remote_into_dot_agentic(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    remote_url, ref = fake_remote

    install(target=target, remote_url=remote_url, remote_ref=ref)

    clone = target / ".agentic" / "remote"
    assert clone.is_dir(), "clone directory must exist"
    assert (clone / ".git").exists(), "clone must contain a .git directory"
    assert (clone / "skill.md").read_text() == "# fake skill\n"


def test_install_writes_overlay_manifest(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    remote_url, ref = fake_remote

    install(target=target, remote_url=remote_url, remote_ref=ref)

    manifest_path = target / ".agentic-bootstrap.json"
    assert manifest_path.is_file(), ".agentic-bootstrap.json must be written"

    manifest = json.loads(manifest_path.read_text())
    assert manifest["schema_version"] == 2
    assert manifest["remote_url"] == remote_url
    assert manifest["remote_ref"] == ref
    assert isinstance(manifest["remote_sha"], str)
    assert len(manifest["remote_sha"]) == 40, "remote_sha must be the full 40-char SHA"
    # Even against the lean fake_remote (no shared surface dirs), the
    # four generated per-agent surfaces are still prepared as empty
    # directories so the generator (when present in richer remotes) has
    # somewhere to write. Plan 0002 step 1 (3/3).
    sources = {entry["path"]: entry["source"] for entry in manifest["surfaces"]}
    assert sources == {
        ".claude/commands": "generated",
        ".claude/skills": "generated",
        ".github/prompts": "generated",
        ".codex/skills": "generated",
    }


def test_install_migrates_legacy_overlay_manifest(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """A legacy ``.agentic-overlay.json`` written by an older bootstrap must be
    renamed to ``.agentic-bootstrap.json`` on first run, preserving its data."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    remote_url, ref = fake_remote

    legacy_payload = {
        "schema_version": 1,
        "remote_url": remote_url,
        "remote_ref": ref,
        "remote_sha": "a" * 40,
        "surfaces": [],
        "configs": [],
    }
    legacy_path = target / ".agentic-overlay.json"
    legacy_path.write_text(json.dumps(legacy_payload))

    install(target=target, remote_url=remote_url, remote_ref=ref)

    assert not legacy_path.exists(), "legacy .agentic-overlay.json must be removed"
    canonical = target / ".agentic-bootstrap.json"
    assert canonical.is_file()
    fresh = json.loads(canonical.read_text())
    # The migrated file is overwritten by the fresh install, but the rename
    # itself must have happened (verified above) and the file is now
    # canonical-named.
    assert fresh["schema_version"] == 2


def test_install_leaves_unrelated_overlay_file_untouched(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """A consumer-owned ``.agentic-overlay.json`` that is NOT a bootstrap manifest
    (no list ``surfaces`` key) must not be renamed by the migration."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    remote_url, ref = fake_remote

    consumer_payload = {"my_overlay_config": {"theme": "dark"}}
    legacy_path = target / ".agentic-overlay.json"
    legacy_path.write_text(json.dumps(consumer_payload))

    install(target=target, remote_url=remote_url, remote_ref=ref)

    assert legacy_path.is_file(), "consumer-owned overlay file must not be migrated"
    assert json.loads(legacy_path.read_text()) == consumer_payload
    assert (target / ".agentic-bootstrap.json").is_file()


def test_install_is_idempotent_on_repeat_call(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """Running ``install`` twice against the same target must not error and must
    leave the manifest pointing at the same remote_sha. Symlink reconciliation
    is a separate slice; this contract is just for the clone + manifest."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    remote_url, ref = fake_remote

    install(target=target, remote_url=remote_url, remote_ref=ref)
    first_sha = json.loads((target / ".agentic-bootstrap.json").read_text())["remote_sha"]

    install(target=target, remote_url=remote_url, remote_ref=ref)
    second_sha = json.loads((target / ".agentic-bootstrap.json").read_text())["remote_sha"]

    assert first_sha == second_sha


# ---------------------------------------------------------------------------
# Console script contract
# ---------------------------------------------------------------------------


def test_install_console_script_runs_end_to_end(
    tmp_path: Path, fake_remote: tuple[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """``python -m agentic_bootstrap install --target <path> --remote-url ...
    --remote-ref ...`` must drive the same flow as the library entrypoint."""
    target = tmp_path / "consumer"
    target.mkdir()
    remote_url, ref = fake_remote

    _install_fake_uvx(monkeypatch, tmp_path)

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "agentic_bootstrap",
            "install",
            "--target",
            str(target),
            "--remote-url",
            remote_url,
            "--remote-ref",
            ref,
            # The minimal `fake_remote` fixture intentionally does not ship
            # scripts/hooks. The default install now enforces required
            # surfaces; opt out here since this test is about the console
            # script wiring, not the harness shape.
            "--no-enforce-required-surfaces",
        ],
        check=False,
        capture_output=True,
        text=True,
        timeout=60,
    )

    assert result.returncode == 0, (
        f"console script failed: stdout={result.stdout!r} stderr={result.stderr!r}"
    )
    assert (target / ".agentic" / "remote" / ".git").exists()
    assert (target / ".agentic-bootstrap.json").is_file()


# ---------------------------------------------------------------------------
# Refresh-path correctness (E17-10-BR13-H-01 + E17-10-BR13-M-01)
# ---------------------------------------------------------------------------


def _build_remote(workdir: Path, name: str, seed_file: str = "skill.md") -> tuple[Path, str]:
    """Build a fresh bare git remote at <workdir>/<name>.git seeded with one
    commit and tag ``v0.1.0``. Returns (bare_path, file_url)."""
    src = workdir / f"{name}-src"
    src.mkdir()
    _git("init", "--initial-branch=main", cwd=src)
    _git("config", "user.email", "test@example.com", cwd=src)
    _git("config", "user.name", "Test", cwd=src)
    (src / seed_file).write_text(f"# {name}\n")
    _git("add", "-A", cwd=src)
    _git("commit", "-m", f"seed {name}", cwd=src)
    _git("tag", "v0.1.0", cwd=src)
    bare = workdir / f"{name}.git"
    _git("clone", "--bare", str(src), str(bare), cwd=workdir)
    return bare, f"file://{bare}"


def test_install_rejects_existing_clone_with_different_remote_url(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """E17-10-BR13-H-01: a rerun pointed at a different remote_url must not
    silently rewrite the manifest while leaving the on-disk clone tracking the
    original origin. Fail-fast with RemoteUrlMismatchError instead."""
    from agentic_bootstrap.install import RemoteUrlMismatchError, install

    target = tmp_path / "consumer"
    target.mkdir()
    first_url, ref = fake_remote
    install(target=target, remote_url=first_url, remote_ref=ref)

    _, second_url = _build_remote(tmp_path, "other")

    with pytest.raises(RemoteUrlMismatchError) as exc:
        install(target=target, remote_url=second_url, remote_ref=ref)
    # Error must name both URLs so the operator can act on it.
    msg = str(exc.value)
    assert first_url in msg
    assert second_url in msg

    # Manifest must still describe the original remote.
    manifest = json.loads((target / ".agentic-bootstrap.json").read_text())
    assert manifest["remote_url"] == first_url


def test_install_branch_ref_advances_to_upstream_head(tmp_path: Path) -> None:
    """E17-10-BR13-M-01: rerunning install with a branch ref must move the
    clone to the latest upstream commit, not stay pinned to the original
    local branch ref after fetch."""
    from agentic_bootstrap.install import install

    # Build a remote with a 'main' branch carrying commit A.
    src = tmp_path / "branch-src"
    src.mkdir()
    _git("init", "--initial-branch=main", cwd=src)
    _git("config", "user.email", "test@example.com", cwd=src)
    _git("config", "user.name", "Test", cwd=src)
    (src / "a.md").write_text("a\n")
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "A", cwd=src)
    bare = tmp_path / "branch.git"
    _git("clone", "--bare", str(src), str(bare), cwd=tmp_path)
    remote_url = f"file://{bare}"

    target = tmp_path / "consumer"
    target.mkdir()

    first = install(target=target, remote_url=remote_url, remote_ref="main")
    sha_a = first["remote_sha"]

    # Add commit B upstream and push it to the bare remote.
    (src / "b.md").write_text("b\n")
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "B", cwd=src)
    _git("push", str(bare), "main", cwd=src)

    second = install(target=target, remote_url=remote_url, remote_ref="main")
    sha_b = second["remote_sha"]

    assert sha_b != sha_a, "branch ref must advance to fresh upstream commit"
    # Sanity: the new sha is the new upstream HEAD.
    new_head = _git("rev-parse", "HEAD", cwd=src)
    assert sha_b == new_head


# ---------------------------------------------------------------------------
# Symlink materialization for the six shared overlay surfaces
# ---------------------------------------------------------------------------


SHARED_SURFACES_EXPECTED = (
    ".github/hooks",
    "scripts/hooks",
    "docs/agentic/contracts",
    "docs/agentic/rules",
    "Makefile.d",
    "scripts/agentic",
)

# Standard git hook names shipped under ``scripts/hooks/git/`` in the real
# monorepo. The fake remote fixtures mirror this layout so the rehearsal
# can assert that ``core.hooksPath`` resolves to a directory containing
# git-resolvable hook files (regression for plan 0006 Slice 0: a parent
# ``scripts/hooks/`` was previously set, which made git look up hook
# names at a path where only Python helpers lived).
SHARED_GIT_HOOK_NAMES = (
    "post-checkout",
    "post-commit",
    "post-merge",
    "post-rewrite",
    "pre-commit",
    "pre-push",
)
# Plan 0006 Slice 5: Python helpers shipped alongside the git hook
# scripts. ``check_branch_naming.py`` is the delegate that the
# pre-commit / pre-push / post-checkout hooks ``exec`` — if it is
# missing from the materialized ``scripts/hooks/`` surface, the
# Slice 3/4/4b gates silently no-op.
SHARED_HOOK_HELPER_NAMES = ("check_branch_naming.py",)
GENERATED_SURFACES_EXPECTED = (
    ".claude/commands",
    ".claude/skills",
    ".github/prompts",
    ".codex/skills",
)


@pytest.fixture()
def fake_remote_with_surfaces(tmp_path: Path) -> tuple[str, str]:
    """Local bare git remote that ships the three shared overlay surfaces."""
    src = tmp_path / "rich-src"
    src.mkdir()
    _git("init", "--initial-branch=main", cwd=src)
    _git("config", "user.email", "test@example.com", cwd=src)
    _git("config", "user.name", "Test", cwd=src)
    for surface in SHARED_SURFACES_EXPECTED:
        d = src / surface
        d.mkdir(parents=True)
        (d / "MARKER.md").write_text(f"shared {surface}\n")
    # Mirror the real monorepo: ``scripts/hooks/git/<name>`` carries the
    # actual git hook scripts that ``core.hooksPath`` resolves against.
    git_hooks_dir = src / "scripts" / "hooks" / "git"
    git_hooks_dir.mkdir(parents=True, exist_ok=True)
    for name in SHARED_GIT_HOOK_NAMES:
        hook = git_hooks_dir / name
        hook.write_text("#!/bin/sh\nexit 0\n")
        hook.chmod(0o755)
    # Plan 0006 Slice 5: ship the helper script the hooks delegate to.
    for helper in SHARED_HOOK_HELPER_NAMES:
        helper_path = src / "scripts" / "hooks" / helper
        helper_path.write_text("#!/usr/bin/env python3\nimport sys; sys.exit(0)\n")
        helper_path.chmod(0o755)
    _git("add", "-A", cwd=src)
    _git("commit", "-m", "seed surfaces", cwd=src)
    _git("tag", "v0.1.0", cwd=src)
    bare = tmp_path / "rich.git"
    _git("clone", "--bare", str(src), str(bare), cwd=tmp_path)
    return f"file://{bare}", "v0.1.0"


def _agentic_system_root() -> Path | None:
    """Return packages/agentic-system inside this monorepo, or None when
    bootstrap is being tested in isolation (no sibling agentic-system)."""
    candidate = Path(__file__).resolve().parents[3] / "packages" / "agentic-system"
    return candidate if candidate.is_dir() else None


@pytest.fixture()
def fake_remote_with_generator(tmp_path: Path) -> tuple[str, str]:
    """Local bare git remote that mirrors the real monorepo layout: shared
    surfaces, generator, manifest, and canonical ``skills/`` source all live
    under ``packages/agentic-system/`` — same as
    ``agentic-protocol-monorepo`` itself.

    Skipped when the sibling ``packages/agentic-system`` is not on disk
    (bootstrap-in-isolation test environments).
    """
    import shutil

    system_root = _agentic_system_root()
    if system_root is None:
        pytest.skip("packages/agentic-system not available in this environment")

    src = tmp_path / "gen-src"
    src.mkdir()
    _git("init", "--initial-branch=main", cwd=src)
    _git("config", "user.email", "test@example.com", cwd=src)
    _git("config", "user.name", "Test", cwd=src)
    system_subdir = src / "packages" / "agentic-system"
    for surface in SHARED_SURFACES_EXPECTED:
        source_dir = system_root / surface
        target_dir = system_subdir / surface
        if source_dir.is_dir() and any(source_dir.iterdir()):
            # Mirror the real surface so rehearsal tests see actual hoisted
            # content (e.g. Plan 0007 Slice 0 needs Makefile.d/plans.mk's
            # launcher token to land verbatim).
            shutil.copytree(source_dir, target_dir)
        else:
            target_dir.mkdir(parents=True)
            (target_dir / "MARKER.md").write_text(f"shared {surface}\n")
    # Mirror the real monorepo: ``scripts/hooks/git/<name>`` carries the
    # actual git hook scripts that ``core.hooksPath`` resolves against
    # (plan 0006 Slice 0).
    git_hooks_dir = system_subdir / "scripts" / "hooks" / "git"
    git_hooks_dir.mkdir(parents=True, exist_ok=True)
    for name in SHARED_GIT_HOOK_NAMES:
        hook = git_hooks_dir / name
        if hook.exists():
            continue
        hook.write_text("#!/bin/sh\nexit 0\n")
        hook.chmod(0o755)
    # Plan 0006 Slice 5: ship the Python helpers the hooks delegate to
    # (e.g. check_branch_naming.py for the post-checkout/pre-commit/pre-push
    # branch-naming gates). Bootstrap symlinks the entire scripts/hooks/
    # surface, so the helpers come along automatically — but the install
    # rehearsal must pin their presence to catch a future regression.
    for helper in SHARED_HOOK_HELPER_NAMES:
        helper_path = system_subdir / "scripts" / "hooks" / helper
        if helper_path.exists():
            continue
        helper_path.write_text("#!/usr/bin/env python3\nimport sys; sys.exit(0)\n")
        helper_path.chmod(0o755)
    # Generator + manifest + neutral skill source, all under packages/agentic-system/.
    (system_subdir / "scripts").mkdir(parents=True, exist_ok=True)
    shutil.copy2(
        system_root / "scripts" / "generate_agent_workflows.py",
        system_subdir / "scripts" / "generate_agent_workflows.py",
    )
    shutil.copytree(
        system_root / "config" / "agent-workflows",
        system_subdir / "config" / "agent-workflows",
    )
    shutil.copytree(system_root / "skills", system_subdir / "skills")

    _git("add", "-A", cwd=src)
    _git("commit", "-m", "seed surfaces + generator", cwd=src)
    _git("tag", "v0.1.0", cwd=src)
    bare = tmp_path / "gen-remote.git"
    _git("clone", "--bare", str(src), str(bare), cwd=tmp_path)
    return f"file://{bare}", "v0.1.0"


def test_install_runs_generator_and_populates_per_agent_surfaces(
    tmp_path: Path, fake_remote_with_generator: tuple[str, str]
) -> None:
    """End-to-end: when the overlay clone ships the generator, ``install``
    runs it and the four per-agent surfaces are populated with real
    artifacts (not just empty directories)."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    url, ref = fake_remote_with_generator

    install(target=target, remote_url=url, remote_ref=ref)

    claude_skills = target / ".claude" / "skills"
    claude_commands = target / ".claude" / "commands"
    prompts = target / ".github" / "prompts"
    codex_skills = target / ".codex" / "skills"

    assert any(claude_skills.glob("*/SKILL.md")), "Claude SKILL.md files must be generated"
    assert any(claude_commands.glob("*.md")), "Claude command files must be generated"
    assert any(prompts.glob("*.prompt.md")), "Copilot prompt files must be generated"
    assert any(codex_skills.glob("*/SKILL.md")), "Codex SKILL.md files must be generated"

    # Every generated surface stays a real directory, not a symlink.
    for surface in GENERATED_SURFACES_EXPECTED:
        assert (target / surface).is_dir()
        assert not (target / surface).is_symlink()


def test_shared_surface_set_includes_docs_agentic_rules() -> None:
    """AHMCP-50 Slice 1: ``docs/agentic/rules`` must be a hoisted shared
    surface so the canonical rule docs (``branch-review-guide.md``,
    ``development-workflow.md``, ``planning-artifact-home.md``) reach
    consumers via the bootstrap regenerate path. Prior to this slice
    only ``docs/agentic/contracts`` was hoisted, leaving rule docs
    repo-local."""
    from agentic_bootstrap.install import SHARED_SURFACES

    assert "docs/agentic/rules" in SHARED_SURFACES, (
        "docs/agentic/rules must be in SHARED_SURFACES so canonical rule "
        "docs (planning-artifact-home.md, development-workflow.md, "
        "branch-review-guide.md) propagate to consumers"
    )


def test_planning_artifact_home_rule_materializes(
    tmp_path: Path, fake_remote_with_generator: tuple[str, str]
) -> None:
    """AHMCP-50 Slice 2: after a clean install, the consumer worktree
    must expose ``docs/agentic/rules/planning-artifact-home.md`` (and
    the two pre-existing rule docs) under the materialized symlink.
    Uses ``fake_remote_with_generator`` because that fixture copies the
    real ``packages/agentic-system/docs/agentic/rules/`` content — the
    bare-MARKER fixture would only ship a placeholder file."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    url, ref = fake_remote_with_generator

    install(target=target, remote_url=url, remote_ref=ref)

    rules_dir = target / "docs" / "agentic" / "rules"
    assert rules_dir.is_symlink(), "rules directory must be hoisted as a symlink"
    expected_rule_docs = (
        "planning-artifact-home.md",
        "development-workflow.md",
        "branch-review-guide.md",
    )
    for name in expected_rule_docs:
        path = rules_dir / name
        assert path.is_file(), f"{name} must materialize in the consumer worktree"

    home_rule = (rules_dir / "planning-artifact-home.md").read_text()
    assert "# Planning Artifact Home" in home_rule
    assert "## Canonical homes" in home_rule
    assert "## Recovery" in home_rule


def test_install_materializes_known_shared_surfaces(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """The SHARED_SURFACES present in the remote become symlinks
    under <target>/<surface> pointing into <target>/.agentic/remote/<surface>,
    and each appears in manifest['surfaces'] with source='shared'.

    Per-agent surfaces (.claude/skills, .claude/commands, .github/prompts,
    .codex/skills) are *generated* into the target as real directories,
    not symlinks; covered by test_install_prepares_generated_surfaces.
    """
    from agentic_bootstrap.install import (
        GENERATED_SURFACES,
        SHARED_SURFACES,
        install,
    )

    target = tmp_path / "consumer"
    target.mkdir()
    url, ref = fake_remote_with_surfaces

    manifest = install(target=target, remote_url=url, remote_ref=ref)

    assert tuple(SHARED_SURFACES) == SHARED_SURFACES_EXPECTED, (
        "SHARED_SURFACES must match the documented shared-surface tuple"
    )
    assert tuple(GENERATED_SURFACES) == GENERATED_SURFACES_EXPECTED
    for surface in SHARED_SURFACES:
        link = target / surface
        assert link.is_symlink(), f"{surface} must be a symlink"
        assert link.resolve() == (target / ".agentic" / "remote" / surface).resolve()
        assert (link / "MARKER.md").read_text() == f"shared {surface}\n"

    by_path = {entry["path"]: entry for entry in manifest["surfaces"]}
    for surface in SHARED_SURFACES:
        assert by_path[surface]["source"] == "shared", by_path[surface]


def test_install_prepares_generated_surfaces_as_real_directories(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """Per-agent surfaces are real directories ready for the generator,
    not symlinks into the overlay clone."""
    from agentic_bootstrap.install import GENERATED_SURFACES, install

    target = tmp_path / "consumer"
    target.mkdir()
    url, ref = fake_remote_with_surfaces

    manifest = install(target=target, remote_url=url, remote_ref=ref)

    by_path = {entry["path"]: entry for entry in manifest["surfaces"]}
    for surface in GENERATED_SURFACES:
        path = target / surface
        assert path.exists(), f"{surface} must exist after install"
        assert path.is_dir(), f"{surface} must be a real directory"
        assert not path.is_symlink(), (
            f"{surface} must be a real directory, not a symlink "
            "(generator writes into it)"
        )
        assert by_path[surface]["source"] == "generated"


def test_install_symlinks_are_idempotent(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """Re-running install must not duplicate, replace, or break existing
    symlinks the bootstrap itself created. Uses a SHARED surface
    (scripts/hooks) since per-agent surfaces are now generated, not
    symlinked."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    url, ref = fake_remote_with_surfaces

    install(target=target, remote_url=url, remote_ref=ref)
    hooks_link = target / "scripts" / "hooks"
    first_target = os.readlink(hooks_link)

    install(target=target, remote_url=url, remote_ref=ref)

    assert hooks_link.is_symlink()
    assert os.readlink(hooks_link) == first_target


def test_install_preserves_existing_local_surface(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """If a SHARED surface path already exists as a real local directory,
    install must leave it untouched and record source='local' in the
    manifest. Per-agent surfaces are no longer 'shared' — they are
    always 'generated' — so this test now uses scripts/hooks as the
    local-override candidate."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    local_hooks = target / "scripts" / "hooks"
    local_hooks.mkdir(parents=True)
    (local_hooks / "local-hook.sh").write_text("#!/bin/sh\necho local\n")

    url, ref = fake_remote_with_surfaces
    manifest = install(target=target, remote_url=url, remote_ref=ref)

    assert local_hooks.is_dir() and not local_hooks.is_symlink()
    assert (local_hooks / "local-hook.sh").read_text().endswith("echo local\n")

    by_path = {entry["path"]: entry for entry in manifest["surfaces"]}
    assert by_path["scripts/hooks"]["source"] == "local"
    assert by_path[".github/hooks"]["source"] == "shared"


def test_install_skips_shared_surfaces_missing_in_remote(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """A remote that does not ship any SHARED surface produces no shared
    symlinks. Generated surfaces are still prepared (empty dirs) so the
    generator has somewhere to write — but the lean fixture has no
    generator script either, so the dirs stay empty."""
    from agentic_bootstrap.install import GENERATED_SURFACES, install

    target = tmp_path / "consumer"
    target.mkdir()
    url, ref = fake_remote  # lean fixture: only ships skill.md, no surface dirs

    manifest = install(target=target, remote_url=url, remote_ref=ref)

    by_path = {entry["path"]: entry for entry in manifest["surfaces"]}
    # No shared surfaces materialized.
    shared_entries = [e for e in manifest["surfaces"] if e["source"] == "shared"]
    assert shared_entries == []
    assert not (target / "scripts" / "hooks").exists()

    # Generated surfaces are still prepared as real (empty) directories.
    for surface in GENERATED_SURFACES:
        assert (target / surface).is_dir()
        assert by_path[surface]["source"] == "generated"


# ---------------------------------------------------------------------------
# Config writers (.mcp.json, .vscode/mcp.json, .codex/config.toml, hooksPath)
# ---------------------------------------------------------------------------


SAMPLE_MCP_SERVERS = {
    "agent-handoff-mcp": {
        "command": sys.executable,
        "args": ["-m", "agent_handoff_mcp"],
        "env": {"PYTHONPATH": str(_handoff_src_dir())},
    },
}


def _runnable_handoff_server_spec() -> dict[str, dict[str, object]]:
    return {
        "agent-handoff-mcp": {
            "command": sys.executable,
            "args": ["-m", "agent_handoff_mcp"],
            "env": {"PYTHONPATH": str(_handoff_src_dir())},
        }
    }


def _init_git_repo(path: Path) -> None:
    _git("init", "--initial-branch=main", cwd=path)
    _git("config", "user.email", "test@example.com", cwd=path)
    _git("config", "user.name", "Test", cwd=path)


def test_install_writes_all_four_config_surfaces_when_mcp_servers_provided(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """When ``mcp_servers`` is provided and target is a git repo, install must
    write ``.mcp.json``, ``.vscode/mcp.json``, ``.codex/config.toml`` and set
    ``core.hooksPath`` — and record each surface in ``manifest['configs']``."""
    from agentic_bootstrap.install import install
    import tomllib

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    manifest = install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    mcp_doc = json.loads((target / ".mcp.json").read_text())
    assert mcp_doc["mcpServers"]["agent-handoff-mcp"]["command"] == sys.executable
    assert mcp_doc["mcpServers"]["agent-handoff-mcp"]["args"] == [
        "-m",
        "agent_handoff_mcp",
    ]

    vscode_doc = json.loads((target / ".vscode" / "mcp.json").read_text())
    assert vscode_doc["servers"]["agent-handoff-mcp"]["command"] == sys.executable

    codex_doc = tomllib.loads((target / ".codex" / "config.toml").read_text())
    assert codex_doc["mcp_servers"]["agent-handoff-mcp"]["command"] == sys.executable
    assert codex_doc["mcp_servers"]["agent-handoff-mcp"]["args"] == [
        "-m",
        "agent_handoff_mcp",
    ]

    hooks_path = _git("config", "--get", "core.hooksPath", cwd=target)
    assert hooks_path == "scripts/hooks/git"

    by_path = {entry["path"]: entry for entry in manifest["configs"]}
    # Plan 0008 Slice 1 adds .claude/settings.local.json (harness Stop hook).
    # AHMCP-48: ``--profile all`` (the default) hoists the lifecycle
    # runner, so the sentinel-bracketed ``-include`` directive lands a
    # ``Makefile`` config entry alongside the MCP-server surfaces.
    assert set(by_path) == {
        ".mcp.json",
        ".vscode/mcp.json",
        ".codex/config.toml",
        "core.hooksPath",
        ".claude/settings.local.json",
        "Makefile",
    }
    assert by_path[".mcp.json"]["action"] == "created"
    assert by_path["core.hooksPath"]["action"] == "set"
    assert by_path[".claude/settings.local.json"]["action"] == "created"


def test_install_deep_merges_existing_mcp_json(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """A pre-existing ``.mcp.json`` with unrelated servers and top-level keys
    must keep all of them; only the bootstrap-managed server entries get
    overwritten."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)

    pre_existing = {
        "mcpServers": {
            "user-tool": {"command": "node", "args": ["server.js"]},
            "agent-handoff-mcp": {"command": "OLD", "args": ["stale"]},
        },
        "userKey": {"keepMe": True},
    }
    (target / ".mcp.json").write_text(json.dumps(pre_existing, indent=2))

    url, ref = fake_remote
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    doc = json.loads((target / ".mcp.json").read_text())
    # User's other server preserved.
    assert doc["mcpServers"]["user-tool"] == {"command": "node", "args": ["server.js"]}
    # User's top-level key preserved.
    assert doc["userKey"] == {"keepMe": True}
    # Managed server overwritten with new values.
    assert doc["mcpServers"]["agent-handoff-mcp"]["command"] == sys.executable
    assert doc["mcpServers"]["agent-handoff-mcp"]["args"] == [
        "-m",
        "agent_handoff_mcp",
    ]


def test_install_codex_config_preserves_user_tables_and_comments(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """tomlkit-backed write must preserve unrelated ``[other]`` tables, root
    keys, and trailing user comments. Only the managed
    ``[mcp_servers.<name>]`` table gets replaced."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    codex_dir = target / ".codex"
    codex_dir.mkdir()

    pre_existing = (
        "# user comment at top\n"
        'model = "gpt-5"\n'
        "\n"
        "[other]\n"
        'value = "keep"\n'
        "\n"
        "[mcp_servers.agent-handoff-mcp]\n"
        'command = "STALE"\n'
        'args = ["old"]\n'
    )
    (codex_dir / "config.toml").write_text(pre_existing)

    url, ref = fake_remote
    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    text = (codex_dir / "config.toml").read_text()
    assert "# user comment at top" in text, "user comment must survive"
    assert 'model = "gpt-5"' in text, "user root key must survive"
    assert "[other]" in text and 'value = "keep"' in text, "user table must survive"

    import tomllib

    doc = tomllib.loads(text)
    assert doc["mcp_servers"]["agent-handoff-mcp"]["command"] == sys.executable
    assert doc["mcp_servers"]["agent-handoff-mcp"]["args"] == [
        "-m",
        "agent_handoff_mcp",
    ]
    assert doc["other"]["value"] == "keep"


def test_install_skips_hooks_path_when_target_not_git_repo(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """When target is not a git repo, hooksPath is silently skipped and
    ``manifest['configs']`` does not include a ``core.hooksPath`` entry."""
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()  # no git init
    url, ref = fake_remote

    manifest = install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=SAMPLE_MCP_SERVERS,
    )

    paths = {entry["path"] for entry in manifest["configs"]}
    assert ".mcp.json" in paths, "JSON writers still run"
    assert ".codex/config.toml" in paths
    assert "core.hooksPath" not in paths


def test_install_with_default_sentinel_uses_built_in_server_map(
    tmp_path: Path, fake_remote: tuple[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """``install(mcp_servers="default")`` resolves to ``DEFAULT_MCP_SERVERS``
    and writes the three managed-config files (Plan 0002 step 2a)."""
    import json as _json

    from agentic_bootstrap.install import DEFAULT_MCP_SERVERS, install

    _install_fake_uvx(monkeypatch, tmp_path)

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    manifest = install(target=target, remote_url=url, remote_ref=ref, mcp_servers="default")

    mcp_doc = _json.loads((target / ".mcp.json").read_text())
    vscode_doc = _json.loads((target / ".vscode" / "mcp.json").read_text())
    assert set(mcp_doc["mcpServers"].keys()) == set(DEFAULT_MCP_SERVERS.keys())
    assert set(vscode_doc["servers"].keys()) == set(DEFAULT_MCP_SERVERS.keys())
    for entry in mcp_doc["mcpServers"].values():
        assert "--workspace-root" in entry["args"]
        assert entry["args"][-1] == "serve-stdio"
    assert mcp_doc["mcpServers"]["agent-handoff-mcp"]["args"][0] == "mcp-agent-handoff@0.11.1"
    assert mcp_doc["mcpServers"]["agent-orchestrator-mcp"]["args"][0] == "mcp-agent-orchestrator@0.4.5"
    for entry in vscode_doc["servers"].values():
        assert "--workspace-root" in entry["args"]
        assert entry["args"][-1] == "serve-stdio"
    assert (target / ".codex" / "config.toml").is_file()
    paths = {entry["path"] for entry in manifest["configs"]}
    assert {".mcp.json", ".vscode/mcp.json", ".codex/config.toml"}.issubset(paths)


def test_install_rejects_unknown_mcp_servers_sentinel(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    with pytest.raises(ValueError, match="not a recognized sentinel"):
        install(target=target, remote_url=url, remote_ref=ref, mcp_servers="bogus")


def test_install_cli_default_writes_managed_servers(
    tmp_path: Path, fake_remote: tuple[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Under ``--profile all``, calling the CLI without ``--mcp-servers``
    should still write all three managed-config files thanks to the
    default-on resolver. (Plan 0009 flipped the CLI default profile to
    ``minimal``; managed-server writers run only under ``all``.)"""
    import json as _json

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    _install_fake_uvx(monkeypatch, tmp_path)

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "agentic_bootstrap",
            "install",
            "--target",
            str(target),
            "--remote-url",
            url,
            "--remote-ref",
            ref,
            "--no-enforce-required-surfaces",
            "--profile",
            "all",
        ],
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0, result.stderr

    mcp_doc = _json.loads((target / ".mcp.json").read_text())
    assert "agent-handoff-mcp" in mcp_doc["mcpServers"]
    assert "agent-orchestrator-mcp" in mcp_doc["mcpServers"]


def test_install_cli_no_mcp_servers_opt_out(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "agentic_bootstrap",
            "install",
            "--target",
            str(target),
            "--remote-url",
            url,
            "--remote-ref",
            ref,
            "--no-mcp-servers",
            "--no-enforce-required-surfaces",
        ],
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0, result.stderr
    assert not (target / ".mcp.json").exists()
    assert not (target / ".vscode" / "mcp.json").exists()
    assert not (target / ".codex" / "config.toml").exists()


def test_install_without_mcp_servers_writes_no_config_files(
    tmp_path: Path, fake_remote: tuple[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """When ``mcp_servers`` is None, the three MCP-server file-writers
    are skipped. ``core.hooksPath`` and the harness Stop-hook write
    (Plan 0008 Slice 1) still run because they do not depend on the
    server map.
    """
    from agentic_bootstrap.install import install

    # Sandbox HOME so the harness-hook write cannot escape the tmp dir
    # via the user-scope path. Default scope is local, but the sandbox
    # also protects against future scope-default flips.
    monkeypatch.setenv("HOME", str(tmp_path / "fake-home"))
    monkeypatch.setenv("USERPROFILE", str(tmp_path / "fake-home"))
    (tmp_path / "fake-home").mkdir()

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    manifest = install(target=target, remote_url=url, remote_ref=ref)

    assert not (target / ".mcp.json").exists()
    assert not (target / ".vscode" / "mcp.json").exists()
    assert not (target / ".codex" / "config.toml").exists()

    paths = {entry["path"] for entry in manifest["configs"]}
    # hooksPath and the harness Stop entry are independent of mcp_servers.
    # AHMCP-48: ``--profile all`` (the default) hoists the lifecycle
    # runner, so the sentinel-bracketed include lands the Makefile
    # config entry alongside hooksPath and the harness Stop entry.
    assert paths == {
        "core.hooksPath",
        ".claude/settings.local.json",
        "Makefile",
    }


def test_install_with_runnable_handoff_server_bootstraps_state_db(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers=_runnable_handoff_server_spec(),
    )

    assert (target / ".task-state" / "handoff.db").is_file()
    assert (target / ".task-state" / "exports").is_dir()


def test_install_does_not_create_task_state_when_required_surface_missing(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """PLAN0003-S3-BR-001: required-surface refusal must run BEFORE init-state
    so a failing install does not leave .task-state/ behind on disk.

    The minimal ``fake_remote`` fixture intentionally ships no ``scripts/hooks``
    surface, so an enforcing install must raise before any state-init runs.
    """
    from agentic_bootstrap.install import (
        BootstrapManifestValidationError,
        install,
    )

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    with pytest.raises(BootstrapManifestValidationError):
        install(
            target=target,
            remote_url=url,
            remote_ref=ref,
            mcp_servers=_runnable_handoff_server_spec(),
            enforce_required_surfaces=True,
        )

    # No state files left behind from the failed install.
    assert not (target / ".task-state").exists()
    # No manifest written either.
    assert not (target / ".agentic-bootstrap.json").exists()


def test_install_refuses_to_reuse_state_with_mismatched_remote_url(
    tmp_path: Path, fake_remote: tuple[str, str]
) -> None:
    """PLAN0003-S3-BR-002: install must thread its remote_url to init-state so
    the remote_url guard rejects a stale adjacent overlay manifest from a
    different remote."""
    import sqlite3

    from agentic_bootstrap.install import install

    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote

    # Plant a stale .task-state/handoff.db plus an .agentic-bootstrap.json that
    # points at a *different* remote_url. The remote_url guard inside
    # init-state must refuse to reuse that DB rather than silently adopting it.
    state_dir = target / ".task-state"
    state_dir.mkdir()
    with sqlite3.connect(state_dir / "handoff.db"):
        pass
    (target / ".agentic-bootstrap.json").write_text(
        json.dumps(
            {
                "schema_version": 1,
                "remote_url": "git@example.com:some/other-overlay.git",
                "remote_ref": "main",
                "remote_sha": "a" * 40,
                "surfaces": [],
                "configs": [],
            }
        )
    )

    with pytest.raises(subprocess.CalledProcessError) as exc:
        install(
            target=target,
            remote_url=url,
            remote_ref=ref,
            mcp_servers=_runnable_handoff_server_spec(),
        )

    # Surface the underlying ForeignStateReuseError to the operator.
    assert "remote_url" in (exc.value.stderr or ""), exc.value.stderr
