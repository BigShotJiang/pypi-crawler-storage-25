"""CLI ``--profile`` flag for the install subcommand (BR-AHMCP40-S1-01).

The library ``install()`` API keeps ``profile="all"`` as the back-compat
default (so existing rehearsals keep their assertions); the CLI layer
defaults to ``minimal`` per Plan 0009's minimal-by-default contract.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from tests.test_install import (  # noqa: F401  -- reused fixture
    fake_remote_with_surfaces,
)


def _git(*args: str, cwd: Path) -> str:
    result = subprocess.run(
        ["git", *args],
        check=True,
        capture_output=True,
        text=True,
        cwd=str(cwd),
        timeout=30,
    )
    return result.stdout.strip()


def _init_git_repo(path: Path) -> None:
    _git("init", "--initial-branch=main", cwd=path)
    _git("config", "user.email", "test@example.com", cwd=path)
    _git("config", "user.name", "Test", cwd=path)


def _run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "agentic_bootstrap", *args],
        check=False,
        capture_output=True,
        text=True,
        timeout=90,
    )


def test_install_cli_default_profile_is_minimal(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """Default `agentic-bootstrap install` (no --profile) must be minimal:
    no per-agent generated surfaces, no shared overlay symlinks, no
    Makefile lifecycle injection."""
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    result = _run_cli(
        "install",
        "--target", str(target),
        "--remote-url", url,
        "--remote-ref", ref,
        "--no-mcp-servers",
        "--no-enforce-required-surfaces",
    )
    assert result.returncode == 0, result.stderr

    # Per-agent and shared surfaces MUST NOT be materialized under minimal.
    assert not (target / ".claude" / "skills").exists()
    assert not (target / ".claude" / "commands").exists()
    assert not (target / ".github" / "prompts").exists()
    assert not (target / ".codex" / "skills").exists()
    assert not (target / "scripts" / "hooks").exists()
    # Lifecycle hoist artifacts MUST NOT appear under minimal.
    assert not (target / "Makefile").exists()
    assert not (target / "Makefile.d").exists()

    manifest = json.loads((target / ".agentic-bootstrap.json").read_text())
    assert manifest["surfaces"] == []


def test_install_cli_lifecycle_profile_hoists_runner(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """`--profile lifecycle` must hoist Makefile.d/lifecycle.mk and the
    runner package, regardless of whether the fake remote happens to ship
    those paths (it doesn't — the hoist is no-op in that case but the
    Makefile include block must still be created)."""
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    result = _run_cli(
        "install",
        "--target", str(target),
        "--remote-url", url,
        "--remote-ref", ref,
        "--no-mcp-servers",
        "--no-enforce-required-surfaces",
        "--profile", "lifecycle",
    )
    assert result.returncode == 0, result.stderr

    # Even when the remote doesn't ship the lifecycle source paths, the
    # Makefile include block must still be created so the consumer can
    # later drop in the fragment manually.
    assert (target / "Makefile").exists()
    text = (target / "Makefile").read_text()
    assert "AGENTIC_BOOTSTRAP LIFECYCLE INCLUDE" in text
    assert "-include Makefile.d/*.mk" in text


def test_install_cli_rejects_unknown_profile(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    result = _run_cli(
        "install",
        "--target", str(target),
        "--remote-url", url,
        "--remote-ref", ref,
        "--no-mcp-servers",
        "--profile", "frobnicate",
    )
    assert result.returncode != 0
    assert "frobnicate" in result.stderr or "frobnicate" in result.stdout


def test_install_cli_all_profile_preserves_legacy_surfaces(
    tmp_path: Path, fake_remote_with_surfaces: tuple[str, str]
) -> None:
    """Explicit `--profile all` must materialize the legacy broad-surface
    behavior so existing rehearsals keep working when opted-in."""
    target = tmp_path / "consumer"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_surfaces

    result = _run_cli(
        "install",
        "--target", str(target),
        "--remote-url", url,
        "--remote-ref", ref,
        "--no-mcp-servers",
        "--profile", "all",
    )
    assert result.returncode == 0, result.stderr

    # Per-agent generated surfaces must exist under `all`.
    assert (target / ".claude" / "skills").is_dir()
    assert (target / ".claude" / "commands").is_dir()
    # Shared surface symlink must be materialized under `all`.
    assert (target / "scripts" / "hooks").exists()
