# Changelog — agentic-bootstrap

## Unreleased

## [0.4.2] — 2026-05-10

### Changed

- **Bump default managed MCP server pins** to `mcp-agent-handoff@0.11.1`
  and `mcp-agent-orchestrator@0.4.5` so consumer repos pick up the
  AHMCP-54 (multi-active CURRENT_TASK projection, import/export
  malformed-payload rejection, target_branch/worktree_path/plan_path
  preservation) and AHMCP-55 (compaction env-var namespace
  consolidation under `AGENT_HANDOFF_COMPACTION_*` with `AHMCP_*` kept
  as a deprecated alias) fixes by default.

## [0.4.1] — 2026-05-09

### Fixed

- **`--profile all` now performs the lifecycle hoist** (AHMCP-48). The
  legacy default profile shipped lifecycle-referencing skills
  (`branch-lifecycle`, `tdd`, `incremental-implementation`,
  `branch-review`, `handoff-lifecycle`) but did not install the
  matching `Makefile.d/lifecycle.mk` and
  `scripts/agentic/lifecycle/` runner that those skills' `make
  task-start` / `make slice-start` / `make context` /
  `make review-ready` / `make handoff-close-check` /
  `make format-all` references resolve through. Consumer repos
  bootstrapped under `--profile all` now receive the runner and the
  sentinel-bracketed `-include Makefile.d/*.mk` directive, so the
  skill manifest and the make graph stay aligned.

### Changed

- **Default managed MCP servers are now version-pinned.** The built-in
  `--mcp-servers default` map writes `uvx mcp-agent-handoff@0.11.0` and
  `uvx mcp-agent-orchestrator@0.4.4` (rather than unpinned `uvx
  mcp-agent-handoff` / `uvx mcp-agent-orchestrator`) so consumer repos
  do not silently drift when PyPI advances independently of the overlay
  tag they bootstrapped against. Operators wanting a different pin
  continue to pass `--mcp-servers <path>`.
- **Raise `agentic-protocol` lower bound to `>=0.1.4,<0.2.0`** to match
  the floor pinned by `mcp-agent-handoff` 0.11.0 and
  `mcp-agent-orchestrator` 0.4.4 — the two packages bootstrap launches
  via `uvx` — so the bootstrap venv cannot resolve a protocol release
  older than what those servers import at startup.

## [0.4.0] — 2026-05-04

### Added

- **Install profile contract: `--profile {minimal,lifecycle,all}`**
  (Plan 0009 / AHMCP-40 Slice 1.5.a). The CLI now accepts an explicit
  install profile flag and honors it across the manifest layers, so
  consumer repos can pick a smaller hoist surface than the default.
- **Hoist `Makefile.d/plans.mk` + `git-plan-cat.sh` stub** (Plan 0007 /
  AHMCP-38 Slice 0). Consumer repos installed via `agentic-bootstrap`
  pick up `make plan-show / plan-edit / plans-list / plan-register`
  out of the box; the targets shell out to `uvx mcp-agent-handoff`
  under the hood.

### Changed

- Bootstrap installs and rehearsals are validated against
  `mcp-agent-handoff>=0.8.0` (the version that ships the
  `plan_resolve` / `plan_cli` surface targeted by the new make
  recipes).

## [0.3.1] — 2026-05-03

- **Plan 0006 BR-01 — raise `agentic-protocol` lower bound to
  `>=0.1.2,<0.2.0`.** Bootstrap's default install path invokes
  `uvx mcp-agent-handoff`, which imports `agentic_protocol.branch_naming`
  at startup; the previous `>=0.1.0` floor let `uvx` resolve a protocol
  release missing the module, crashing init-state on a fresh install. A
  new packaging test (`tests/test_package_metadata.py`) pins the floor
  so the declaration cannot silently drift back below the contract.
- **Plan 0006 Slice 5 — install rehearsal pins six-hook surface +
  helper materialization.** `SHARED_GIT_HOOK_NAMES` now includes
  `pre-commit` (in addition to `post-checkout`, `post-commit`,
  `post-merge`, `post-rewrite`, `pre-push`); the install rehearsal
  test asserts that `core.hooksPath` resolves to the directory
  carrying all six executable hook scripts AND that the Python helper
  `scripts/hooks/check_branch_naming.py` (the delegate the
  post-checkout / pre-commit / pre-push hooks `exec`) is materialized
  alongside them. Without the helper, every branch-naming gate
  silently no-ops. The shared surface itself is unchanged
  (`scripts/hooks` is symlinked from `.agentic/remote`); the new
  assertion catches a future regression where the upstream package
  drops the helper.
- **Manifest renamed: `.agentic-overlay.json` → `.agentic-bootstrap.json`
  (schema_version bumped to 2).** Resolves a name collision with consumer
  repos that also use `.agentic-overlay.json` for unrelated config. On first
  run, an existing `.agentic-overlay.json` carrying the bootstrap shape
  (top-level dict with a list `surfaces` key) is renamed in-place via
  `git mv` (or filesystem rename when the target is not a git worktree).
  Consumer-owned files at the legacy name are left untouched. The Python
  alias `OVERLAY_MANIFEST_NAME` is preserved (now pointing at the canonical
  filename) for downstream import compatibility.
- **Managed MCP defaults now launch stdio servers.** The built-in
  `--mcp-servers default` map writes `uvx mcp-agent-handoff
  --workspace-root . serve-stdio` and `uvx mcp-agent-orchestrator
  --workspace-root . serve-stdio` into `.mcp.json`,
  `.vscode/mcp.json`, and `.codex/config.toml`, so external clients
  start runnable MCP servers from a fresh install or update.
- **`regenerate-task-views` harness hook contract dropped (Plan 0005).**
  Bootstrap no longer materializes any Claude / VS Code / Codex hook
  wiring that invokes `regenerate-task-views`; `DASHBOARD.txt` is now
  auto-regenerated server-side inside `mcp-agent-handoff` on every
  state-mutating MCP call. The shared `scripts/hooks/` surface is still
  materialized; `regenerate-task-views.sh` remains there only as a
  documented manual fallback for the auto-regen opt-out path
  (`AGENT_HANDOFF_DASHBOARD_AUTO_REGEN=0`). Operators upgrading from
  0.3.0 do not need to touch any harness config — the next
  `agentic-bootstrap update` removes the obsolete hook wiring.

## 0.3.0 — 2026-04-28

- **Install-time state provisioning (Plan 0003).** `install` now runs
  the handoff server's `init-state` after surface/config materialization
  but before `core.hooksPath` is set, so a fresh install ends with a
  schema-current `.task-state/handoff.db` and `.task-state/exports/`
  ready for the first MCP call. The init-state invocation is resolved
  from the same `mcp_servers` map written into `.mcp.json` /
  `.vscode/mcp.json` / `.codex/config.toml` (avoiding dogfood version
  skew between PyPI and local-source schemas), and the bootstrap
  manifest's `remote_url` is threaded through `--expected-remote-url`
  so a stale adjacent overlay from a different remote is rejected.
  Skipped under `--no-mcp-servers`.
- **Required-surfaces refusal runs before the generator and
  init-state.** A failing required-surface check now leaves no
  `.task-state/`, no generated artifacts, and no manifest behind on
  disk, so refused installs no longer half-write the target.
- **`status` reports handoff state.** When the install registered MCP
  servers, `status` invokes `init-state --check` and appends the
  resolved `state_dir` / `db_path` / `exports_dir` / `schema_version` /
  `initialized` to the summary. `--no-mcp-servers` installs suppress
  the section.
- **`doctor` flags missing `.task-state/handoff.db` as `state_drift`,**
  gated on `.mcp.json` being present in the manifest's `configs` array
  so config-only installs (`--no-mcp-servers`) do not produce
  false-positive drift.
- **`switch_task` cold-start fix.** Plan 0003 Slice 1 (in
  `mcp-agent-handoff` 0.5.0+) drops `BranchMismatchError` from
  `switch_task`; the cold-start cycle (register task → `switch_task`
  → first content write) now completes from any branch. Branch
  enforcement on content writes (`record_event`, `close_slice`,
  `set_handoff_state`, `record_review_finding`,
  `record_verified_test`) is unchanged — bootstrap's docs reflect
  this, but the behavior change lives in the handoff package.

## 0.2.1 — 2026-04-26

- Add `pyyaml>=6` to runtime dependencies. The agent-workflow generator
  imports `yaml` to read `skill.yaml`; bootstrap invokes the generator
  via its own `sys.executable`, so PyYAML must be present in bootstrap's
  uvx-isolated venv. Without it, install fails with
  `PyYAML is required to read skill.yaml` on a clean uvx run.

## 0.2.0 — 2026-04-26

- Resolve shared overlay surfaces and the agent-workflow generator under
  `packages/agentic-system/` (the agentic-protocol-monorepo layout) with
  fallback to the clone root for legacy hoisted overlays. Fixes
  `BootstrapManifestValidationError: required surface 'scripts/hooks' was
  not materialized` against monorepo refs at or after Plan 0002 step 1.
- Rehearsal fixture (`fake_remote_with_generator`) now mirrors the real
  monorepo layout so this regression cannot return silently.

### Note on previously published refs

The monorepo `v0.1.0` tag pre-dates this fix. Consumers using
`uvx --from "...@v0.1.0..." agentic-bootstrap install ...` will hit the
required-surface error. Pin to `v0.1.1` or later.
