# AHMCP-49 Task Plan — Single Source of Truth for Managed MCP Server Versions

> - **Date**: 2026-05-09 EST
> - **Author**: Claude Opus 4.7
> - **Project**: agentic-bootstrap
> - **Owning Scope**: `docs/scopes/agentic-bootstrap-mcp-sync-config-only-scope.md` (Section B)
> - **Task ID**: AHMCP-49
> - **Target Branch**: `feature/ahmcp-49-managed-server-versions-constant`
> - **Review Coverage Target**: 1

## AHMCP-49. Single Source of Truth for Managed MCP Server Versions

## Objective

Move the literal MCP server version pins out of `DEFAULT_MCP_SERVERS` into a typed constant `MCP_SERVER_PACKAGE_VERSIONS`, and rebuild `DEFAULT_MCP_SERVERS` from it so a coordinated stack bump edits exactly one table. Tests and `docs/CONSUMER.md` derive the same values from the same constant, eliminating the six-place version-literal scatter the parent scope documents.

## Intake (scope context)

- **Scope one-pager**: `docs/scopes/agentic-bootstrap-mcp-sync-config-only-scope.md`
- **Key Q&A decisions**: Section B explicitly recommends Option 1 (hand-edited constant + release-script hook); Option 2 (pyproject discovery) is deferred for cost reasons.
- **Not-Doing**: Promoting `MCP_SERVER_PACKAGE_VERSIONS` to a wire schema in `agentic-protocol`. Defer until a second consumer (outside `agentic-bootstrap`) needs to read the table.

## Problem Statement

Today's coordinated stack bump (`agentic-protocol` 0.1.4, `mcp-agent-handoff` 0.11.0, `mcp-agent-orchestrator` 0.4.4) required hand-editing six places: `DEFAULT_MCP_SERVERS` at `install.py:142,146`, two test argv literals (`test_install.py:984-985`, `test_bootstrap_install_rehearsal.py:213-214`), one comment in `test_package_metadata.py:23`, and one example block in `docs/CONSUMER.md:99-100`. None of these are derived. A bump that forgets one ships skew between what the bootstrap installs and what the tests/docs claim.

## Constraints

- The exported in-code symbol `DEFAULT_MCP_SERVERS` must stay (it has external callers and downstream tests). It becomes a derived value, not a literal.
- The new constant only carries package-name → version-string. It does not carry launcher argv, env vars, or transport shape — those stay in the existing `_build_default_mcp_servers` (or equivalent) builder so the launcher contract change surface stays in one place.
- No new dependency on `pyproject.toml` parsing. Section B Option 1 is chosen explicitly to keep the bootstrap install path free of source-tree path discovery.
- The release flow today is human-driven and clean-tree-gated: bumpers commit `version =` edits in `packages/<name>/pyproject.toml` themselves, then `scripts/release.sh preflight` reads those versions via `pkg_version()` and refuses to proceed if the working tree is dirty (`ensure_clean_main`). This task does not introduce a release-time rewriter (that would fight the clean-tree gate). Instead it adds two things at the bumper's commit boundary: (1) a contract test (`test_managed_server_versions_pin.py`, Slice 2) that asserts `MCP_SERVER_PACKAGE_VERSIONS` matches the per-package `pyproject.toml` versions, and (2) an optional helper (`scripts/sync-mcp-versions.py`, Slice 2) that re-derives the constant from the pyproject versions in-place so the bumper can run it before staging. The contract test is the binding gate — it runs under each package's pytest suite, which `scripts/release.sh cmd_preflight` already invokes per package, so any drift between the constant and the pyproject versions fails preflight before tagging or upload.

## Workflow Principles

- Land the constant, the rebuild, and the test refactor in one slice. They are inseparable: the test refactor is what proves the literal-removal claim.
- Generate the `docs/CONSUMER.md` example block from the same constant via the existing `packages/agentic-system/scripts/generate_agent_workflows.py` pattern (or a sibling generator if that script is workflow-only). Hand-editing the doc is the failure mode this task closes.
- Pick one term — "managed server map" — and use it consistently in code, docstrings, and CONSUMER.md. The in-code symbol stays `DEFAULT_MCP_SERVERS` for backwards compatibility but new prose uses "managed server map." (Closes finding `mcp-sync-terminology-drift-managed-vs-default-vs-mcp-server-map`.)

## Terminology

- **Managed server map**: The mapping from MCP server name to its full launcher spec (command, args, env). Exposed in code as `DEFAULT_MCP_SERVERS`.
- **`MCP_SERVER_PACKAGE_VERSIONS`**: The new typed constant `Mapping[str, str]` from package name (e.g. `"mcp-agent-handoff"`) to its pinned version (e.g. `"0.11.0"`). The single literal source for the managed server map.

## Current State Analysis

- `DEFAULT_MCP_SERVERS` at `packages/agentic-bootstrap/src/agentic_bootstrap/install.py:120-148` carries inline literal `"mcp-agent-handoff@0.11.0"` and `"mcp-agent-orchestrator@0.4.4"` strings.
- Three tests assert against those same literals (`test_install.py:984-985`, `test_bootstrap_install_rehearsal.py:213-214`, `test_package_metadata.py:23`).
- `docs/CONSUMER.md:99-100` shows a hand-edited example block.
- The release script that bumps `version =` lines in `packages/agentic-bootstrap/pyproject.toml`, `packages/mcp-agent-handoff/pyproject.toml`, `packages/mcp-agent-orchestrator/pyproject.toml` does not currently touch `install.py` or any test/doc surface.

## Target Outcome

A coordinated MCP-stack bump is a single human commit that touches three surfaces: `MCP_SERVER_PACKAGE_VERSIONS`, the per-package `pyproject.toml` `version =` lines, and the regenerated `docs/CONSUMER.md` example block (regeneration is mechanical via `make check-agent-workflows`). Every other version reference — `DEFAULT_MCP_SERVERS`, the three test argv assertions — derives from the constant at runtime and needs no edit. The optional `scripts/sync-mcp-versions.py` helper lets the bumper rewrite the constant from the new pyproject versions in one step; the new contract test (`test_managed_server_versions_pin.py`) fails `scripts/release.sh preflight` if the constant and pyproject versions ever drift apart.

## Context Loading

- Rules: none specific (refactor task).
- Contracts: `packages/agentic-bootstrap/src/agentic_bootstrap/install.py` `_write_*` writer family (do not change shape).
- Handoff/MCP state: this task plan (AHMCP-49); MAINT-PLAN-ANALYZE-MCP-SYNC-20260509 carries the planning findings to address.
- External docs via `ctx7`: not required.

## Contract and Boundary Impact

| Boundary | Owner | Current Contract | Expected Change | Compatibility Needed? | Verification |
| --- | --- | --- | --- | --- | --- |
| `DEFAULT_MCP_SERVERS` (Python) | agentic-bootstrap | Module-level `Mapping[str, Mapping[str, Any]]` | Becomes a derived value built from `MCP_SERVER_PACKAGE_VERSIONS`; same shape, same name | yes — keep symbol exported with same shape so downstream importers do not break | `test_install.py` install-resolves test |
| Release-script bump procedure | release tooling | Human commits `version =` line edits in three `pyproject.toml` files; `scripts/release.sh preflight` reads them and refuses to run on a dirty tree | Bumper additionally edits `MCP_SERVER_PACKAGE_VERSIONS` in the same commit (optionally via `scripts/sync-mcp-versions.py`); no change to `release.sh` itself | no | Contract test in slice 2 asserts constant matches `pyproject.toml` versions and runs under the per-package pytest suite that `cmd_preflight` already invokes |

## Proposed Solution

Two slices. Slice 1 introduces the constant and rebuild and refactors the three test assertions to derive from it (smallest revertable unit). Slice 2 adds the contract test that pins constant ↔ pyproject parity (the binding gate, runs under `release.sh preflight` via the per-package pytest suite), the optional `scripts/sync-mcp-versions.py` helper for bumpers, and the CONSUMER.md generator step. Slice 2 does not modify `scripts/release.sh` — adding a release-time rewriter would fight the existing clean-tree gate (`ensure_clean_main`), so the constant edit stays at the bumper's commit boundary instead.

## Files and Surfaces to Change

| Surface | File | Change |
| --- | --- | --- |
| code | `packages/agentic-bootstrap/src/agentic_bootstrap/install.py` | Add `MCP_SERVER_PACKAGE_VERSIONS`; rebuild `DEFAULT_MCP_SERVERS` from it |
| tests | `packages/agentic-bootstrap/tests/test_install.py` | Replace literal `@0.11.0` argv assertion with `f"mcp-agent-handoff@{MCP_SERVER_PACKAGE_VERSIONS['mcp-agent-handoff']}"` |
| tests | `packages/agentic-bootstrap/tests/test_bootstrap_install_rehearsal.py` | Same replacement for handoff + orchestrator literals |
| tests | `packages/agentic-bootstrap/tests/test_package_metadata.py` | Drop the version-literal comment; assert constant exists if useful |
| tests (new) | `packages/agentic-bootstrap/tests/test_managed_server_versions_pin.py` | Contract test asserting `MCP_SERVER_PACKAGE_VERSIONS[name]` matches the corresponding `packages/<name>/pyproject.toml` `version =` line |
| docs | `docs/CONSUMER.md` (and generator) | Generate the MCP server example block from `MCP_SERVER_PACKAGE_VERSIONS` |
| tooling (new, optional) | `scripts/sync-mcp-versions.py` | New helper that reads `version =` from each `packages/<name>/pyproject.toml` listed in `MCP_SERVER_PACKAGE_VERSIONS` and rewrites the constant in `install.py` in-place. Invoked manually by the bumper (or wired as a pre-commit hook on changed pyproject files in a follow-up). Not called from `scripts/release.sh` — the contract test under `cmd_preflight`'s per-package pytest is the binding gate. (Closes finding `mcp-sync-release-script-hook-non-existent`.) |

## Related Files

| File | Note |
| --- | --- |
| `packages/agentic-bootstrap/src/agentic_bootstrap/subcommands.py` | Currently calls `DEFAULT_MCP_SERVERS`; should keep working unchanged. |
| `packages/agentic-system/scripts/generate_agent_workflows.py` | Existing generator pattern that the CONSUMER.md generation should mirror. |

## Verification Strategy

- Deterministic tests:
  - `uv run pytest packages/agentic-bootstrap/tests/test_install.py packages/agentic-bootstrap/tests/test_bootstrap_install_rehearsal.py packages/agentic-bootstrap/tests/test_package_metadata.py packages/agentic-bootstrap/tests/test_managed_server_versions_pin.py -q`
- Contract verification:
  - The new `test_managed_server_versions_pin.py` asserts `MCP_SERVER_PACKAGE_VERSIONS["mcp-agent-handoff"] == <version from packages/mcp-agent-handoff/pyproject.toml>` for every entry. This is the regression gate against silent drift.
- Manual verification:
  - Inspect generated `docs/CONSUMER.md` diff after running the generator: example block matches the constant.

## Slice Delivery

### Slice 1: Introduce constant and refactor literal call sites

**Goal**: Replace hand-written version literals in `install.py` and the three test files with values derived from `MCP_SERVER_PACKAGE_VERSIONS`.

Changes:

- Add `MCP_SERVER_PACKAGE_VERSIONS: Mapping[str, str]` near `DEFAULT_MCP_SERVERS` in `install.py`.
- Refactor `DEFAULT_MCP_SERVERS` builder to consume the constant.
- Update three test files to derive expected argv from the constant.

Proof:

- All four test files pass at the new HEAD.
- `grep -nE "(mcp-agent-(handoff|orchestrator))@[0-9]" packages/agentic-bootstrap/{src,tests}/` returns no results outside `MCP_SERVER_PACKAGE_VERSIONS`.

### Slice 2: Pin the constant via contract test, sync helper, generated CONSUMER.md

**Goal**: Make the constant the only literal source and gate every release on it staying in sync with the pyproject versions.

Changes:

- Add `test_managed_server_versions_pin.py` asserting `MCP_SERVER_PACKAGE_VERSIONS[name]` equals the `version =` line in `packages/<name>/pyproject.toml` for every entry. This is the binding gate: it runs under `packages/agentic-bootstrap`'s pytest suite, which `scripts/release.sh cmd_preflight` already invokes per package, so any drift fails preflight before any tag or upload.
- Add `scripts/sync-mcp-versions.py` (optional helper for the human bumper): reads each pyproject's `version =` line and rewrites the `MCP_SERVER_PACKAGE_VERSIONS` literal in `install.py` in-place. Not invoked from `release.sh` (which gates on a clean tree); intended for the bumper's commit boundary or a future pre-commit hook on changed pyproject files.
- Convert the `docs/CONSUMER.md` MCP server example block to a generated section sourced from the constant. Wire the regeneration into `make check-agent-workflows` (or sibling check) so CI fails on a stale block. Future bumps regenerate it as part of the same commit; the regenerated diff is expected and is part of the bump-touches set in the success criteria.
- Do not modify `scripts/release.sh`. The clean-tree gate (`ensure_clean_main`) makes a release-time rewriter incompatible with the current flow; the contract test plus the optional sync helper cover the same drift surface without that conflict.

Proof:

- New contract test passes against the current `MCP_SERVER_PACKAGE_VERSIONS` and the three managed pyproject versions.
- Manually editing `packages/mcp-agent-handoff/pyproject.toml` to a new version without updating the constant makes the contract test fail (and a dry-run `scripts/release.sh preflight` against that state fails on the same per-package pytest invocation).
- Running `scripts/sync-mcp-versions.py` after a pyproject bump produces a single in-place rewrite of `MCP_SERVER_PACKAGE_VERSIONS` and leaves the contract test green.
- `make check-agent-workflows` fails when the committed `docs/CONSUMER.md` block is out of sync with the constant; running the generator regenerates it deterministically.

---

## Consolidated Checklist

## Context and Ownership

- [ ] Loaded `install.py` (`DEFAULT_MCP_SERVERS` site) and the three test files that pin literal versions.
- [ ] Confirmed `ctx7` is not required (pure refactor, no external API).
- [ ] Recorded that `DEFAULT_MCP_SERVERS` is an exported boundary; symbol shape preserved.

### Checklist for Slice 1: Introduce constant and refactor literal call sites

- [ ] `MCP_SERVER_PACKAGE_VERSIONS` added with current pinned versions.
- [ ] `DEFAULT_MCP_SERVERS` rebuilt from the constant; symbol export preserved.
- [ ] `test_install.py`, `test_bootstrap_install_rehearsal.py`, `test_package_metadata.py` updated to derive expected values from the constant.
- [ ] `grep` for raw `@<version>` literals across `packages/agentic-bootstrap/{src,tests}/` returns only the constant table.
- [ ] Verification evidence: all touched test files pass.

### Checklist for Slice 2: Pin via contract test, sync helper, generated CONSUMER.md

- [ ] `test_managed_server_versions_pin.py` added; asserts constant ↔ pyproject parity for every entry; runs under the per-package pytest suite that `scripts/release.sh cmd_preflight` invokes.
- [ ] `scripts/sync-mcp-versions.py` added; reads each managed pyproject's `version =` line and rewrites `MCP_SERVER_PACKAGE_VERSIONS` in `install.py` in-place; not invoked from `release.sh`.
- [ ] CONSUMER.md MCP server example block generated from the constant; generator wired into `make check-agent-workflows` (or sibling check); regenerated diff is documented as expected on every bump.
- [ ] `scripts/release.sh` is unmodified; rationale (clean-tree gate vs. release-time rewriter) recorded in the slice-complete decision.
- [ ] Verification evidence: contract test passes; manual constant-mismatch experiment makes it fail; running the sync helper after a pyproject bump restores parity in one step.

## Review Readiness

- [ ] No new code path duplicates the version literal anywhere.
- [ ] Bumper workflow (edit `MCP_SERVER_PACKAGE_VERSIONS` + the three pyproject `version =` lines + regenerate `docs/CONSUMER.md` via `make check-agent-workflows` in the same commit; optionally drive the constant edit with `scripts/sync-mcp-versions.py`) is documented in `docs/RELEASING.md` (or wherever the per-package bump procedure lives) so the next bumper does not skip a step by accident.
- [ ] Handoff decision records the constant introduction and the contract-test pin.

## Success Criteria

- [ ] A future MCP-stack bump touches exactly three surfaces in one commit: `MCP_SERVER_PACKAGE_VERSIONS`, the three `pyproject.toml` `version =` lines, and the regenerated `docs/CONSUMER.md` example block (regenerated mechanically via `make check-agent-workflows`). No test literal, no `DEFAULT_MCP_SERVERS` literal, no `release.sh` edit.
- [ ] The contract test fails loudly if the constant and the pyproject versions get out of sync, and that failure surfaces under `scripts/release.sh preflight` via the per-package pytest suite.
- [ ] `docs/CONSUMER.md` example block derives from the constant via the existing generator pattern; `make check-agent-workflows` fails on a stale committed block.
