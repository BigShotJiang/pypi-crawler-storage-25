# AHMCP-48 Task Plan — Bootstrap `all` Profile Implies Lifecycle Hoist (Skills→Lifecycle Drift Fix)

> - **Date**: 2026-05-08 EST
> - **Author**: Claude Opus 4.7
> - **Project**: agentic-bootstrap
> - **Owning Epic**: `docs/scopes/bootstrap-consumption-hardening-scope.md`
> - **Task ID**: AHMCP-48
> - **Target Branch**: `feature/ahmcp-48-skills-imply-lifecycle-hoist`
> - **Review Coverage Target**: 1

## AHMCP-48. Bootstrap `all` Profile Implies Lifecycle Hoist (Skills→Lifecycle Drift Fix)

## Objective

Make `agentic-bootstrap install --profile all` (the legacy/default profile that ships skills) also hoist `Makefile.d/lifecycle.mk` and `scripts/agentic/lifecycle/`, so a consumer cannot end up with the `branch-lifecycle` / `tdd` / `incremental-implementation` / `branch-review` / `handoff-lifecycle` skills referencing `make task-start` / `make slice-start` / `make context` / `make review-ready` / `make handoff-close-check` / `make format-all` while the matching make fragment and Python runner are absent.

## Intake (epic context)

- **Scope one-pager**: `docs/scopes/bootstrap-consumption-hardening-scope.md`
- **Key Q&A decisions**: Intake decisions 1–5 captured inline in the scope doc (MCP recording is a pre-planning blocker — recorded once `record_event` is reachable; until then this plan references the scope's inline table).
- **Not-Doing**: bootstrap will not write managed `.gitignore` blocks for harness-created files (`.claude/worktrees/`, `.claude/settings.local.json`); that gap is explicitly out of scope per user direction.

## Problem Statement

`altcontext-marketing-monorepo` was bootstrapped with the default profile (`all`) and ended up with the branch-lifecycle skill body but no `Makefile.d/lifecycle.mk` and no `scripts/agentic/lifecycle/`. Every `/branch-lifecycle` invocation in that consumer references make targets the install did not provide; the canonical-policy doc paths (`docs/agentic/...`) referenced from the skill are also absent.

The cause is structural, not transitional. `install.py:548-557` deliberately scopes the lifecycle hoist to `profile == PROFILE_LIFECYCLE`, while skills are materialized only under `profile == PROFILE_ALL` (`install.py:525-526`). The two profiles are disjoint paths in the same `install()` body, and `all` predates `lifecycle`. The code comment at `install.py:548-552` already anticipates folding the hoist into `all` ("folding the hoist into `all` is a follow-on once the seven-profile contract lands in full") — this task is that follow-on, scoped to the minimum diff that closes the drift class.

A consumer cannot fix this from their side: re-running `bootstrap install --profile lifecycle` would re-do the install in lifecycle-only mode and lose every other surface. The drift has to close at install time, in the bootstrap.

## Constraints

- The fix must be additive: `--profile lifecycle` must continue to mean "lifecycle-only" (no skills, no generated surfaces). Only `--profile all` gains the lifecycle hoist.
- `--profile minimal` must continue to be lean. It does not ship skills today; it must not start shipping `lifecycle.mk` either.
- Idempotency is required: re-running `install --profile all` against a consumer that already has lifecycle hoisted must not duplicate the `Makefile.d/lifecycle.mk` file, the runner directory, or the `-include Makefile.d/*.mk` sentinel block in the consumer `Makefile`.
- The manifest contract (`agentic_protocol.BootstrapManifest`) must continue to validate; lifecycle entries already appear under `surfaces` with `source: "lifecycle"` and `configs` (the Makefile-include directive) — those shapes do not change.
- No change to `LIFECYCLE_HOISTS` membership. The two existing entries (`Makefile.d/lifecycle.mk`, `scripts/agentic/lifecycle`) cover the consumer-visible surface today.
- No change to `--profile lifecycle` semantics. Operators who want lifecycle without skills keep using it.

## Workflow Principles

- Land the install-side hoist promotion and its regression test in one slice. They are inseparable: the test asserts the new behavior, and the production code is small enough that splitting them adds bookkeeping without buying revertability.
- Prefer asserting against materialized filesystem state (the consumer target after `install()` returns) rather than against the manifest dict alone. Manifest entries can drift from disk if a future bug skips a copy step; only filesystem assertions catch that.
- Do not re-derive the lifecycle hoist logic. Reuse `_install_lifecycle_profile` and `_ensure_consumer_makefile_include` exactly — both are already idempotent.

## Terminology

- **Profile**: A named install plan (`minimal`, `lifecycle`, `all`). Selects which surfaces, generated artifacts, and configs the bootstrap materializes.
- **Surface**: A path materialized into the consumer (skill bodies, hook scripts, `Makefile.d/lifecycle.mk`, the lifecycle runner package).
- **Lifecycle hoist**: The action of copying `Makefile.d/lifecycle.mk` and `scripts/agentic/lifecycle/` into the consumer and injecting the `-include` sentinel into the consumer `Makefile`. Implemented by `_install_lifecycle_profile` + `_ensure_consumer_makefile_include`.
- **Skills→Lifecycle drift**: The state where a consumer has skill bodies that reference lifecycle make targets but the runner / Makefile fragment that defines those targets is missing.

## Current State Analysis

- `packages/agentic-bootstrap/src/agentic_bootstrap/install.py:104-107` declares `LIFECYCLE_HOISTS = (("Makefile.d/lifecycle.mk", ...), ("scripts/agentic/lifecycle", ...))`.
- `install.py:380-405` (`_install_lifecycle_profile`) is idempotent: file copies use `shutil.copy2`; directory copies use `shutil.copytree(..., dirs_exist_ok=True)`; missing sources are silently skipped.
- `install.py:408-432` (`_ensure_consumer_makefile_include`) wraps the `-include Makefile.d/*.mk` directive in `LIFECYCLE_INCLUDE_SENTINEL_BEGIN`/`_END` markers. Re-runs short-circuit when the sentinel is already present (`action='already_present'`); first runs either create or append.
- `install.py:525-557` is the profile-dispatch body of `install()`. Today:
  - `if profile == PROFILE_ALL`: materializes skills + generated surfaces; runs the workflow generator; writes harness configs; runs init-state.
  - `if profile == PROFILE_LIFECYCLE`: hoists lifecycle, ensures Makefile include.
  - The two branches are independent `if` statements (not `elif`), so a hypothetical caller could already pass `profile=PROFILE_ALL` and then re-run with `profile=PROFILE_LIFECYCLE` — but no caller does this in practice, and the CLI / API rejects multi-profile calls because `profile` is a single string.
- `install.py:96-103` comment: "Plan 0009 (AHMCP-40) lifecycle profile … destination paths are flat under the consumer root because the runner/Makefile fragment must be reachable from a vanilla consumer with no monorepo packaging knowledge." Confirms the hoist is the canonical mechanism.
- `install.py:548-552` comment: explicit acknowledgement that folding the hoist into `all` is the planned follow-on.
- The `branch-lifecycle` skill body (`packages/agentic-system/skills/branch-lifecycle/body.md`) references `make task-start`, `make slice-start`, `make slice-commit`, `make task-finish`, `make review-ready`, `make handoff-close-check`, `make context`, `make format-all`. These are all defined in `Makefile.d/lifecycle.mk` (verified at `packages/agentic-system/Makefile.d/lifecycle.mk:41-58`).
- The same skill is materialized into the consumer's `.claude/skills/branch-lifecycle/` and `.codex/skills/branch-lifecycle/` under `--profile all` via `_materialize_surfaces` + the workflow generator. The skill body and the make fragment ship from the same monorepo and the same `remote_sha`, so a single `--profile all` install can keep them in sync as long as both are hoisted.
- Existing test surface in `packages/agentic-bootstrap/tests/`: confirm with the test author whether `tests/test_install.py` (or equivalent) already exercises `_install_lifecycle_profile` under `--profile lifecycle`. The new regression must add coverage for `--profile all` hoisting lifecycle, not duplicate the lifecycle-only assertion.

### Lifecycle-touching skill inventory (closed audit)

The fix must close drift for *every* skill body that materializes under `--profile all` and references a lifecycle make target. Two disjoint sources contribute to that set: (a) the generated command map in `packages/agentic-system/config/agent-workflows/portable_commands.json`, and (b) skill body prose that references `make …` targets without exposing them through the manifest's `makefile_target` field. Both are covered by hoisting lifecycle under `PROFILE_ALL` because the skill body and the lifecycle make fragment ship from the same monorepo at the same `remote_sha`.

**(a) Generated `portable_commands.json` entries that route through a lifecycle make target.** The `command_id` → `makefile_target`/`secondary_targets` mapping is the closed, manifest-grade list:

| `command_id`                | Lifecycle target(s) referenced via the manifest                                    | Why `PROFILE_ALL ⇒ lifecycle` covers it                                                                                                                          |
| --------------------------- | ---------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `branch-lifecycle`          | `make task-start`, `make review-ready`, `make handoff-close-check`, `make task-finish` | All four are defined in `packages/agentic-system/Makefile.d/lifecycle.mk` and only resolve in the consumer when the hoist runs.                                  |
| `branch-review`             | `make review-run`                                                                  | Defined in `lifecycle.mk`; same hoist closes the gap.                                                                                                            |
| `handoff-lifecycle`         | `make context`                                                                     | Defined in `lifecycle.mk`; hoist materializes the runner and the include sentinel.                                                                              |
| `incremental-implementation`| `make slice-start`, `make slice-commit`                                            | Defined in `lifecycle.mk`; covered by the hoist.                                                                                                                |
| `plan-analyze`              | `make plan-analyze DOC=<path>`                                                     | Defined in `lifecycle.mk`; covered by the hoist.                                                                                                                |
| `planning-review`           | `make plan-review DOC=<path>`                                                      | Defined in `lifecycle.mk`; covered by the hoist.                                                                                                                |
| `tdd`                       | `make slice-start`                                                                 | Defined in `lifecycle.mk`; covered by the hoist.                                                                                                                |
| `scope`                     | (none — in-session intake)                                                         | No lifecycle dependency; included for completeness so the inventory is closed.                                                                                  |
| `auto-fix`                  | (none in the manifest target; **see (b)**)                                          | Manifest does not advertise a lifecycle target, but the skill body does — see body-only audit below.                                                            |
| `review-parallel`           | (none in the manifest target; **see (b)**)                                          | Same as auto-fix: covered by the body-only audit.                                                                                                               |

**(b) Body-only references that bypass the manifest's `makefile_target` field.** These are caught by `grep -n '\bmake \(task-start\|slice-start\|slice-commit\|task-finish\|review-ready\|review-run\|handoff-close-check\|context\|plan-analyze\|plan-review\|format-all\|status\|tasks\|maint-archive-stale\)\b'` against `packages/agentic-system/skills/*/body.md`:

| Skill body                                 | Lifecycle target(s) referenced in prose only           | Why `PROFILE_ALL ⇒ lifecycle` covers it                                                                                       |
| ------------------------------------------ | ------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------- |
| `skills/auto-fix/body.md`                  | `make task-start`                                      | Body cites `make task-start TASK=<id>` as the precondition recovery path. Hoisting `lifecycle.mk` under `--profile all` makes that target resolvable. |
| `skills/review-parallel/body.md`           | `make context`, `make maint-archive-stale`             | Body cites these as ambiguity-recovery commands. Both are defined in `lifecycle.mk`.                                          |
| `skills/investigate/body.md`               | `make status`, `make tasks`, `make context`, `make maint-archive-stale` | Body cites these as the orientation path before raw MCP reads. All are defined in `lifecycle.mk`.                              |
| `skills/branch-lifecycle/body.md`          | (already covered by manifest row; body adds `make slice-start`, `make slice-commit`, `make format-all`) | All defined in `lifecycle.mk`; subsumed by manifest-row coverage.                                                              |

**Audit checklist (cold-start implementer must run before merging the fix):**

- [ ] Run the manifest-row pass: open `packages/agentic-system/config/agent-workflows/portable_commands.json` and confirm the 7 lifecycle-target rows above (`branch-lifecycle`, `branch-review`, `handoff-lifecycle`, `incremental-implementation`, `plan-analyze`, `planning-review`, `tdd`) still resolve to targets defined in `Makefile.d/lifecycle.mk`. If a new row gains a lifecycle `makefile_target`, the table above must be extended.
- [ ] Run the body-only grep above against `packages/agentic-system/skills/*/body.md` and confirm the only hits outside the manifest-row skills are `auto-fix`, `review-parallel`, and `investigate`. A new hit means a new skill ships with a lifecycle dependency and the inventory must be re-closed before merge.
- [ ] Confirm every target referenced in either pass is defined in `packages/agentic-system/Makefile.d/lifecycle.mk` (so the hoist is sufficient). If a referenced target lives in a non-hoisted fragment (e.g. a future `Makefile.d/review.mk`), the hoist set must be extended — that is out of scope for AHMCP-48 but flagged here so the auditor cannot silently miss it.

This closes the drift class for the entire `--profile all` skill payload: every lifecycle-target reference, whether routed through the generated manifest or only in skill prose, is satisfied by the same `_install_lifecycle_profile` + `_ensure_consumer_makefile_include` pair this task promotes into `--profile all`.

## Target Outcome

`install(profile=PROFILE_ALL, ...)` returns with the consumer containing:

- All `--profile all` surfaces it produces today (skills, generated workflow files, harness configs, init-state).
- **Plus** `Makefile.d/lifecycle.mk` and `scripts/agentic/lifecycle/` materialized in the consumer (identical to what `--profile lifecycle` produces today).
- **Plus** the `-include Makefile.d/*.mk` sentinel block injected idempotently into the consumer's `Makefile`.
- A returned manifest whose `surfaces` list includes both `source: "lifecycle"` entries and whose `configs` list includes the Makefile-include directive entry (when newly added).

`install(profile=PROFILE_LIFECYCLE, ...)` and `install(profile=PROFILE_MINIMAL, ...)` are unchanged.

`install(profile=PROFILE_ALL, ...)` re-run against the same target is idempotent: no duplicate sentinel block, no duplicate manifest entries (or, if duplication is impossible-by-construction in the manifest writer, no diff in the materialized files).

## Context Loading

- Rules: `packages/agentic-system/docs/agentic/rules/development-workflow.md` (packaged anchor; the only loadable rule that bears on this task — bootstrap consumers receive a copy under `.agentic/rules/` after install). `docs/agentic/rules/planning-pipeline.md` does not exist in this monorepo and is intentionally not referenced.
- Contracts: `packages/agentic-protocol/...` for `BootstrapManifest` shape (only consult if a manifest field changes — this task does not change the shape).
- Code anchors: `packages/agentic-bootstrap/src/agentic_bootstrap/install.py:96-107`, `:380-432`, `:435-557`. Read once at session start; do not re-load on every slice.
- Existing tests: `packages/agentic-bootstrap/tests/` — locate the lifecycle profile test at session start. The new test sits next to it.
- Handoff/MCP state: scope decisions for `SCOPE-bootstrap-consumption-hardening-20260508` (inline in scope doc until MCP recording lands).
- External docs via `ctx7`: not required for this task.

## Contract and Boundary Impact

| Boundary                                       | Owner             | Current Contract                                                                                                                                | Expected Change                                                                                                                                                                                              | Compatibility Needed?                                                            | Verification                                                                                                              |
| ---------------------------------------------- | ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| `agentic-bootstrap install` profile API        | agentic-bootstrap | `profile in {minimal, lifecycle, all}`; `all` → skills + generated + configs; `lifecycle` → hoist lifecycle + Makefile-include                  | `all` additionally performs the lifecycle hoist + Makefile-include. `minimal` and `lifecycle` semantics unchanged.                                                                                            | yes — `--profile all` is the legacy/default profile; existing consumers must keep working. The change is purely additive (more files materialized) so no caller-visible removal. | New `tests/test_install_profile_all_lifecycle.py` (or extension of existing suite) asserts the hoist + idempotency after `--profile all`. |
| `BootstrapManifest` (`packages/agentic-protocol`) | agentic-protocol  | `surfaces: list[{path, source}]`, `configs: list[{path, action}]`. Lifecycle entries use `source: "lifecycle"`; Makefile-include uses `action: "appended"\|"created"\|"already_present"`. | No shape change. New behavior produces additional list entries already supported by the schema.                                                                                                              | no                                                                               | Existing `BootstrapManifest.model_validate(manifest)` call at `install.py:585` continues to pass.                          |
| Consumer `Makefile`                            | consumer repo     | If absent, bootstrap creates one with the sentinel block; if present, bootstrap appends or no-ops. Always wrapped in sentinels for clean uninstall. | No change to the writer logic itself. Now triggered under `--profile all` as well.                                                                                                                            | yes — must remain idempotent across profile re-runs.                              | Regression test invokes `install(profile=PROFILE_ALL, ...)` twice against the same target; asserts single sentinel block. |

## Proposed Solution

Replace the dedicated `if profile == PROFILE_LIFECYCLE:` block at `install.py:553-557` with a guard that fires for both `PROFILE_ALL` and `PROFILE_LIFECYCLE`. Concretely:

```python
# Lifecycle hoist now fires for both `all` (so consumers that ship the
# branch-lifecycle / tdd / etc. skills also get the matching make
# fragment + runner) and `lifecycle` (the dedicated lean profile).
if profile in (PROFILE_ALL, PROFILE_LIFECYCLE):
    surfaces.extend(_install_lifecycle_profile(target, clone))
    include_entry = _ensure_consumer_makefile_include(target)
    if include_entry is not None:
        configs.append(include_entry)
```

Update the in-source comment block at `install.py:548-552` to note the follow-on has landed and reference AHMCP-48.

That is the entire production change. `_install_lifecycle_profile` and `_ensure_consumer_makefile_include` are already idempotent; the manifest schema already accepts the entries; the lifecycle hoist sources are already cloned via the existing `_resolve_in_clone` mechanism.

The reason a more elaborate "skill registry" design (per the scope's "skills-imply-lifecycle" framing) is not used here: today, skills are materialized only under `--profile all`. There is no profile that ships skills without `all`. Promoting `all` to imply lifecycle therefore covers every drift case in the current code, with the smallest possible diff and no new data structures. If a future profile adds skills, this plan must be reconsidered — captured in Stretch Goals as a follow-up guard.

## Files and Surfaces to Change

| Surface                | File                                                                                | Change                                                                                                                                                                                                |
| ---------------------- | ----------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| backend (install body)  | `packages/agentic-bootstrap/src/agentic_bootstrap/install.py:548-557`                | Replace `if profile == PROFILE_LIFECYCLE:` with `if profile in (PROFILE_ALL, PROFILE_LIFECYCLE):`. Update comment block to reflect that the AHMCP-40 follow-on has landed.                                                                                         |
| backend (update path)   | `packages/agentic-bootstrap/src/agentic_bootstrap/subcommands.py:461-492`            | **No production change.** `update()` already delegates to `install()` (line 486), so the install fix automatically propagates to the `agentic-bootstrap update` path. Listed here so the auditor sees the surface explicitly and the test below has a named home. |
| tests (install profile) | `packages/agentic-bootstrap/tests/test_install_profile_all_lifecycle.py` (new file) | New regression test: `install(profile=PROFILE_ALL, ...)` materializes `Makefile.d/lifecycle.mk`, `scripts/agentic/lifecycle/`, and the `-include` sentinel block; second run is idempotent.                                                                       |
| tests (update path)     | `packages/agentic-bootstrap/tests/test_subcommands.py` (extend existing file)       | Add a focused test that calls `update()` against a target previously bootstrapped with `--profile all` and asserts the consumer now contains `Makefile.d/lifecycle.mk`, `scripts/agentic/lifecycle/`, and exactly one `LIFECYCLE_INCLUDE_SENTINEL` block in `Makefile`. This proves the epic-level drift contract holds for the `update` path, not just first-time installs. |
| changelog               | `packages/agentic-bootstrap/CHANGELOG.md`                                           | Entry under the next unreleased version describing the behavior change ("`--profile all` now also hoists `Makefile.d/lifecycle.mk` so consumers that ship lifecycle-referencing skills can run them; `agentic-bootstrap update` inherits the same hoist via its existing `install()` delegation"). |

## Related Files

| File                                                                          | Note                                                                                                                                                          |
| ----------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `packages/agentic-system/Makefile.d/lifecycle.mk`                             | Source for the hoist; not modified, but its existence at the resolved clone path is a precondition for the assertion in the new test.                          |
| `packages/agentic-system/scripts/agentic/lifecycle/`                          | Source for the hoist runner; same precondition.                                                                                                               |
| `packages/agentic-system/skills/branch-lifecycle/body.md`                     | The skill whose `make task-start` references motivated the fix. Not modified by this task; AHMCP-49 (cold-start runbook + commit-prefix) edits it separately. |
| `packages/agentic-bootstrap/tests/...` (existing lifecycle-profile test)      | Locate at session start; the new test reuses any helpers it exposes (e.g. fixture clones, target tempdirs). Do not duplicate the lifecycle-only assertion.    |
| `packages/agentic-protocol/...` (`BootstrapManifest`)                         | Validation continues unchanged; named for traceability.                                                                                                       |

## Verification Strategy

- Deterministic tests:
  - `cd packages/agentic-bootstrap && uv run pytest tests/test_install_profile_all_lifecycle.py -x`
  - `cd packages/agentic-bootstrap && uv run pytest tests/test_subcommands.py -x` (must include the new `update`-path lifecycle-hoist assertion; protects against an `update()` regression that breaks the epic's drift contract even though the production code change lives entirely in `install.py`).
  - `cd packages/agentic-bootstrap && uv run pytest -x` (full suite must remain green; in particular the existing `--profile lifecycle` and `--profile minimal` tests).
- Runtime-parity / environment checks:
  - `cd /tmp && rm -rf bootstrap-smoke && mkdir bootstrap-smoke && cd bootstrap-smoke && git init -q && uvx --from /Users/daniel/Development/agentic-protocol-monorepo/packages/agentic-bootstrap agentic-bootstrap install --remote-url file:///Users/daniel/Development/agentic-protocol-monorepo --remote-ref HEAD --profile all && test -f Makefile.d/lifecycle.mk && test -d scripts/agentic/lifecycle && grep -q LIFECYCLE_INCLUDE_SENTINEL Makefile && echo "smoke OK"` _(adapt the `uvx` invocation to the local install path; the assertion is "lifecycle artifacts present after `--profile all`")._
  - Idempotency: re-run the same install command and assert no second sentinel block (`grep -c "AGENTIC_BOOTSTRAP LIFECYCLE INCLUDE" Makefile` returns `1`).
- Contract/fixture verification:
  - `BootstrapManifest.model_validate(manifest)` is exercised by the install path itself; no extra fixture needed.
- Manual verification:
  - Re-bootstrap `altcontext-marketing-monorepo` against the candidate build and confirm `make task-start TASK=… OBJECTIVE=…` runs end-to-end. This is the epic-level done-signal and is verified after the PR lands, not as part of merge gating.

## Slice Delivery

### Slice 1: Promote `--profile all` to imply lifecycle hoist

**Goal**: `install(profile=PROFILE_ALL, ...)` materializes `Makefile.d/lifecycle.mk` + `scripts/agentic/lifecycle/` + Makefile `-include` sentinel; behavior under `lifecycle` and `minimal` is unchanged; re-runs are idempotent.

Changes:

- Replace the `if profile == PROFILE_LIFECYCLE:` guard at `install.py:553` with `if profile in (PROFILE_ALL, PROFILE_LIFECYCLE):`.
- Update the inline comment block at `install.py:548-552` to record that the AHMCP-40 follow-on has landed under AHMCP-48.
- Add `tests/test_install_profile_all_lifecycle.py` with at minimum:
  - One test that asserts post-install file presence after `--profile all` (the three expected artifacts).
  - One test that asserts manifest entries (`surfaces` has two `source: "lifecycle"` entries; `configs` has the Makefile-include entry on first run).
  - One test that asserts idempotency on a second run against the same target (single sentinel; no exception).
- Extend `tests/test_subcommands.py` with one focused test that:
  - Bootstraps a target via `install(profile=PROFILE_ALL, ...)`.
  - Calls `update(target=..., remote_ref=...)` against that target.
  - Asserts `Makefile.d/lifecycle.mk` and `scripts/agentic/lifecycle/` are present after the update and that `Makefile` contains exactly one `LIFECYCLE_INCLUDE_SENTINEL_BEGIN` marker (idempotent across the install+update sequence).
  - This is the epic-level drift contract for the `update` path: even though `update()` delegates to `install()` and inherits the fix indirectly, an explicit assertion prevents a future refactor of `update()` from silently regressing the contract.
- CHANGELOG entry.

Proof:

- `uv run pytest tests/test_install_profile_all_lifecycle.py -v` shows three passing cases.
- `uv run pytest tests/test_subcommands.py -v` shows the new update-path lifecycle-hoist case passing alongside the existing subcommand tests.
- `uv run pytest tests/` full suite green.
- Smoke command from the Verification Strategy returns `smoke OK` and the idempotency `grep -c` returns `1`.

## Consolidated Checklist

## Context and Ownership

- [ ] Loaded `install.py:96-107`, `:380-432`, `:525-557` and the existing lifecycle-profile test in `tests/`.
- [ ] Confirmed `BootstrapManifest` shape does not require updates (entries are already supported).
- [ ] Confirmed `_install_lifecycle_profile` and `_ensure_consumer_makefile_include` are idempotent before relying on them under a second profile.

### Checklist for Slice 1: Promote `--profile all` to imply lifecycle hoist

- [ ] Edit `install.py` profile-dispatch guard from `== PROFILE_LIFECYCLE` to `in (PROFILE_ALL, PROFILE_LIFECYCLE)`.
- [ ] Update the inline comment block at `install.py:548-552` to reflect AHMCP-48.
- [ ] Add `tests/test_install_profile_all_lifecycle.py` covering filesystem state, manifest shape, and idempotency.
- [ ] Extend `tests/test_subcommands.py` with a focused `update`-path test that asserts `Makefile.d/lifecycle.mk`, `scripts/agentic/lifecycle/`, and a single `LIFECYCLE_INCLUDE_SENTINEL_BEGIN` marker after `install(--profile all)` followed by `update()`.
- [ ] Confirm by code reading that no other entry point bypasses `install()` (`subcommands.py:update`, `subcommands.py:repair`, CLI). Document the audit result in the slice-complete decision.
- [ ] Add CHANGELOG entry under the next unreleased agentic-bootstrap version.
- [ ] Run `uv run pytest -x` and capture green output.

## Review Readiness

- [ ] No boundary-touching implementation is left without matching contract/test evidence (`BootstrapManifest` validation is exercised by the test path itself; no manifest schema change required).
- [ ] Runtime-parity smoke test (manual, against a temp consumer repo) was run and produced the lifecycle artifacts under `--profile all`.
- [ ] Handoff decision records the install-time behavior change and links to the AHMCP-48 PR.

## Stretch Goals

- [ ] Add a defensive runtime check in `install()` that detects "skills materialized but lifecycle hoist did not run" and refuses the install with a clear error. This is a guard against future profiles that add skills without auditing the lifecycle dependency. Stretch because the immediate drift class is closed by the `PROFILE_ALL ⇒ lifecycle` promotion alone.

## Success Criteria

- [ ] After `agentic-bootstrap install --profile all` against any target, `Makefile.d/lifecycle.mk`, `scripts/agentic/lifecycle/`, and the `-include` sentinel block are all present in the consumer.
- [ ] Re-running the same install against the same target produces no duplicate sentinel blocks and no test failures.
- [ ] `--profile lifecycle` and `--profile minimal` produce byte-identical surface and config sets to their pre-AHMCP-48 outputs (regression coverage in the existing test suite).
- [ ] After the PR lands and `altcontext-marketing-monorepo` re-bootstraps against the candidate build, `make task-start TASK=<ref> OBJECTIVE="…"` runs end-to-end without "missing target" errors. This is the epic-level done-signal; verified out-of-band, not as a merge gate for AHMCP-48 itself.

---

## Epic Sequencing Note

This is task **1 of 4** under the `bootstrap-consumption-hardening` epic. The remaining sub-tasks each need their own task plan:

- **AHMCP-49**: Document `<branch-name>:` commit-prefix convention + cold-start worktree-isolation runbook in `branch-lifecycle/body.md` (gaps 2 + 3 of the scope, bundled because both edit the same skill body).
- **AHMCP-50**: New canonical rule `docs/agentic/rules/planning-artifact-home.md` + optional `git status` guardrail for untracked `docs/scopes|plans|assessments/*` on `main` (gap 4 of the scope).
- **Verification**: Re-bootstrap `altcontext-marketing-monorepo` clean as the epic-level done-signal (not a code task).

These plans are deliberately not drafted in this file. Each gets its own branch and review cycle, per the scope's "one epic, sub-tasks each as their own task plan and branch" decision.
