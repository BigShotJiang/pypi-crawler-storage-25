# AHMCP-50 Task Plan — `agentic-bootstrap mcp-sync` Config-Only Subcommand

> - **Date**: 2026-05-09 EST
> - **Author**: Claude Opus 4.7
> - **Project**: agentic-bootstrap
> - **Owning Scope**: `docs/scopes/agentic-bootstrap-mcp-sync-config-only-scope.md` (Sections A and C)
> - **Task ID**: AHMCP-50
> - **Target Branch**: `feature/ahmcp-50-mcp-sync-config-only-subcommand`
> - **Review Coverage Target**: 2
> - **Depends on**: AHMCP-49 (uses `MCP_SERVER_PACKAGE_VERSIONS` as the resolved input)
> - **Sequencing note**: Lands AFTER `docs/scopes/bootstrap-consumption-hardening-scope.md` AHMCP-48 finishes its `agentic-bootstrap update` parity refactor, OR shares an `update` integration test that asserts both behaviors hold. (Closes finding `mcp-sync-update-codepath-sequencing-vs-bootstrap-hardening`.)

## AHMCP-50. `agentic-bootstrap mcp-sync` Config-Only Subcommand

## Objective

Add `agentic-bootstrap mcp-sync` (and its underlying `sync_mcp_configs(target, mcp_servers, *, surfaces, check_only)` API) as a config-only refresh path that updates `.mcp.json`, `.vscode/mcp.json`, `.codex/config.toml`, and the ledger's `mcp_servers` provenance block from the resolved managed server map — without fetching the remote, regenerating skills, or touching anything `agentic-bootstrap update` touches today. Operators bumping only the MCP launcher pins run one command and inherit none of `update`'s overlay-cache failure modes.

Surface paths are exact: the writer in `install.py` resolves `target / ".mcp.json"` (`:751`), `target / ".vscode" / "mcp.json"` (`:765`), and `target / ".codex" / "config.toml"` (`:781`). The plan's `mcp.json` and `config.toml` references throughout always mean the `.vscode/` and `.codex/` paths respectively — never repository-root files.

## Intake (scope context)

- **Scope one-pager**: `docs/scopes/agentic-bootstrap-mcp-sync-config-only-scope.md`
- **Key Q&A decisions**: Belongs in `agentic-bootstrap` (cross-harness, agent-agnostic). Internal API is parameter-only so non-CLI callers (Make targets, doctor, future release helpers) drive the same code path.
- **Not-Doing**: Changes to MCP server wire shape; new client surfaces (Cursor, JetBrains); promoting the constant to `agentic-protocol` wire schema; replacing `agentic-bootstrap update`.

## Problem Statement

Today the only config-refresh path is `agentic-bootstrap update`, which fetches the remote, switches the cached `.agentic/remote/` checkout, regenerates skill/hook/workflow surfaces, and runs `init-state`. Operators who only want "point my MCP launchers at the new server release" pay the full overlay refresh cost and inherit dirty-overlay-cache failure modes for what should be a four-file rewrite. There is no surface that takes a managed server map and reconciles only the three client config files plus the ledger.

A second pain: the existing writers (`_write_mcp_json` at `install.py:677`, `_write_vscode_mcp_json` at `:678`, `_write_codex_config` at `:679`) live inside the install path. Without a config-only entry point, callers either re-run install (destructive) or copy the writer logic (drift).

## Constraints

- The new subcommand MUST NOT fetch the git remote, mutate `.agentic/remote/`, regenerate skill/hook/workflow surfaces, run `init-state`, validate the overlay tag, or touch any file `install` writes outside the four named surfaces. (Anything else and operators would just keep using `update`.)
- The internal API is parameter-only: no implicit file discovery past what is passed in. `target` and `mcp_servers` are required; `surfaces` and `check_only` are keyword-only.
- The implementation MUST go through a pure render/merge seam, not the disk-writing helpers as they exist today. Slice 1 factors `_write_mcp_json` / `_write_vscode_mcp_json` / `_write_codex_config` into a `_render_*` step (returns the post-merge document object) plus a thin `_write_*` wrapper that calls `path.write_text(...)`. `sync_mcp_configs` calls the render step, diffs the rendered bytes against on-disk content for drift detection, and only invokes the write step when `check_only=False`. This pins the contract that `check_only=True` cannot mutate the real target — even transiently — because the write helper is never reached. New writer code is out of scope; the rendered output must byte-match the legacy writer's output for the same inputs (slice 1 covers this with a parity test). (Closes findings `mcp-sync-impl-seam-vs-existing-writers-undefined` and `AHMCP50-PR-03`.)
- Exit codes are CI-actionable: `0` clean reconcile (apply or check), `1` drift detected with `--check`, non-zero (>=2) on resolution failure. (Closes finding `mcp-sync-check-exit-code-undefined`. Diverges from the scope's literal text; explicitly documented in this plan.)
- Idempotent: re-running on an already-synced target with the same managed map is a no-op; the receipt says "no drift" and writes nothing.
- Preservation contract: launchers in the consumer's config files that name servers NOT in `MCP_SERVER_PACKAGE_VERSIONS` are preserved untouched (the existing writers already only touch managed names). Removed managed servers default to preserve; `--prune-removed-managed` is the explicit operator opt-in to delete. (Closes findings `mcp-sync-managed-map-deletion-semantics-undefined` and `mcp-sync-third-party-launcher-preservation-not-pinned`.)
- Provenance source for `--prune-removed-managed`: the prune classifier MUST NOT scan client config files to guess which launcher names "look managed" — names there can be reused by third parties. Instead, the ledger's `mcp_servers` block (`.agentic-bootstrap.json` → `mcp_servers`) is the authoritative record of names this tool previously managed, and is read as input BEFORE the rewrite step. The prune set is `previously_managed_names - resolved_map.keys()`. After the writes complete, the ledger's `mcp_servers` block is rewritten to `resolved_map.keys()` so the next run sees the new baseline. On first run against a target whose ledger has no `mcp_servers` block (legacy installs), `--prune-removed-managed` is a no-op for that run with a printed notice; the block is seeded from the resolved map on the same pass. The block stores names only — the spec values come from the resolved map at write time, not from the ledger. (Closes finding `AHMCP50-PR-02`.)
- Ledger reconciliation: `.agentic-bootstrap.json`'s `mcp_servers` block is BOTH an input (provenance for prune classification, see above) AND a write target. The contract is read-then-rewrite: read the previously-managed names, compute the new state, write the new names. If the block disagrees with the resolved map after writing, that is a bug. The block contains the list of currently-managed server names (no spec values); `install.py` must learn to write this block on install — slice 1 covers the install-side wire-up. (Closes finding `mcp-sync-stale-ledger-mcp-servers-block-reconciliation`.)

## Workflow Principles

- Internal API first, CLI as a thin adapter. The signature is what makes this agent-agnostic; the CLI is one of several future drivers (doctor, Make target, release helper).
- Reuse existing writers via a render/merge seam — do not parallel-implement. The first slice splits each `_write_*` helper into a pure `_render_*` step and a thin disk-write wrapper so `check_only` mode never reaches the writer; both `install` and `mcp-sync` go through the same render path.
- The doctor integration is `sync_mcp_configs(check_only=True)` — not a parallel detection codepath. (Closes finding `mcp-sync-doctor-drift-detection-shape-undefined`.)

## Terminology

- **Managed server map**: As defined in AHMCP-49. The resolved input to `sync_mcp_configs`, sourced from `MCP_SERVER_PACKAGE_VERSIONS` for `--mcp-servers default` and from a JSON file otherwise.
- **Surface**: One of `claude` (writes `.mcp.json`), `vscode` (writes `.vscode/mcp.json`), `codex` (writes `.codex/config.toml`).
- **Drift**: A surface whose on-disk content does not match what `sync_mcp_configs` would write given the resolved managed server map.
- **SyncReport**: The structured return value from `sync_mcp_configs`. Includes per-surface drift status, list of writes applied (or planned in `check_only` mode), and any preserved third-party launcher names.

## Current State Analysis

- `install.py` carries the three writers (`_write_mcp_json` `:746`, `_write_vscode_mcp_json` `:760`, `_write_codex_config` `:775`). Each writer reads the existing file, deep-merges/replaces only the managed-named entries, and writes back — third-party launchers are preserved structurally because the writers never touch unrelated keys, not via a separate preserve helper. Each writer is exercised only via `install()`.
- `subcommands.py` exposes `status`, `doctor`, `update`, `repair`. No config-only entry point.
- The `.agentic-bootstrap.json` ledger (recently renamed from `.agentic-overlay.json` per commit `f9f519f`, see `BOOTSTRAP_MANIFEST_NAME` `:42`) currently stores `schema_version`, `remote_url`, `remote_ref`, `remote_sha`, `surfaces`, and `configs` (`install.py:589`). It does NOT yet have an `mcp_servers` block — slice 1 must add it to the manifest write and to the `BootstrapManifest` wire-shape model in `agentic-protocol`. Until then there is no provenance record of which server names the tool managed on a given install.
- `agentic-bootstrap update` is the only public surface for refreshing config; it does the full overlay refresh.

## Target Outcome

A CLI invocation `uvx agentic-bootstrap mcp-sync --target . --mcp-servers default` rewrites the four surfaces (`.mcp.json`, `.vscode/mcp.json`, `.codex/config.toml`, `.agentic-bootstrap.json`) from `MCP_SERVER_PACKAGE_VERSIONS`, leaves remote/overlay/skills untouched, exits `0` on clean reconcile, and prints a SyncReport (writes applied, third-party launchers preserved). `--check` exits `1` if any surface drifts. `bootstrap doctor` calls the same internal API in check mode and surfaces drift as a finding recommending `mcp-sync --apply`. `repair --mcp-servers default` becomes a thin wrapper around `sync_mcp_configs`.

## Context Loading

- Rules: `docs/agentic/instructions.md` (canonical-policy fallback; `docs/agentic/constitution.md` is referenced by skills but does not currently exist in this repo — closes finding `mcp-sync-constitution-anchor-missing` by noting the gap; the canonical-policy gap itself is out of scope of this task and tracked separately).
- Contracts: `install.py` writers (`_write_mcp_json`, `_write_vscode_mcp_json`, `_write_codex_config` — managed-name merge, third-party launchers preserved structurally; no separate `_preserved_mcp_servers` helper exists), manifest write (`install.py:589`), `BootstrapManifest` wire-shape model in `agentic-protocol`; `subcommands.py` (existing surface for `doctor`/`repair`).
- Handoff/MCP state: AHMCP-49 (provides the resolved input); MAINT-PLAN-ANALYZE-MCP-SYNC-20260509 (carries the planning findings closed by this plan).
- External docs via `ctx7`: not required.

## Contract and Boundary Impact

| Boundary | Owner | Current Contract | Expected Change | Compatibility Needed? | Verification |
| --- | --- | --- | --- | --- | --- |
| `agentic-bootstrap` CLI | bootstrap | Subcommands: install, status, doctor, update, repair | Adds `mcp-sync` subcommand with `--target`, `--mcp-servers`, `--check`, `--apply`, `--prune-removed-managed`, `--surfaces`, `--json` | yes — additive only; existing subcommands unchanged | Slice 4 contract test invokes the CLI |
| `sync_mcp_configs` (Python) | bootstrap | None today | New public function in a module imported by both install and the new subcommand | yes — must remain stable for doctor/repair to call | Slice 1 unit tests |
| `_write_mcp_json` etc. | bootstrap | Module-private writers in `install.py` that read disk, merge managed entries, and write back in one pass | Split into `_render_<surface>(target, mcp_servers) -> bytes/document` (pure, no I/O writes) plus `_write_<surface>(target, rendered)` (disk write). `install` calls render+write; `mcp_sync` calls render then either compares for drift (check) or calls the write helper (apply). | no — render output must byte-match legacy writer output for the same inputs | Slice 1 parity test pins legacy-vs-render byte equality; existing install tests still pass |
| `BootstrapManifest` (`agentic-protocol`) | protocol | Wire-shape model validated at install time; lacks `mcp_servers` field | Add an optional `mcp_servers: list[str]` field (managed-name provenance). Validation tolerates legacy installs (field absent) but install going forward writes it. | yes — additive optional field; legacy ledgers without the field still validate | `BootstrapManifest.model_validate` round-trip in slice 1 unit tests |
| `bootstrap doctor` | bootstrap | Reports overlay/skill drift | Adds MCP-config drift finding via `sync_mcp_configs(check_only=True)` | yes — additive finding, existing findings unchanged | Slice 4 doctor test |
| `bootstrap repair --mcp-servers` | bootstrap | Currently re-applies install-time MCP server config | Becomes a thin wrapper around `sync_mcp_configs` | yes — output shape preserved | Existing repair tests still pass |

## Proposed Solution

Four slices. Slice 1 splits the install-side writers into render + write halves, adds the ledger `mcp_servers` provenance block (manifest write + `BootstrapManifest` field), and lands `sync_mcp_configs` with unit tests including the legacy-vs-render parity check. Slice 2 wires the CLI subcommand including `--json` output. Slice 3 wires the doctor and repair integrations to call `sync_mcp_configs`. Slice 4 lands the end-to-end contract test (fixture target with stale launchers, asserts `--check` exit `1` then `--apply` exit `0` with the four files rewritten and nothing else touched) and the CONSUMER.md "Refresh MCP servers" section.

## Files and Surfaces to Change

| Surface | File | Change |
| --- | --- | --- |
| code (new) | `packages/agentic-bootstrap/src/agentic_bootstrap/mcp_sync.py` | New module with `sync_mcp_configs` + `SyncReport` + ledger reader/writer helpers; imports the `_render_*` and `_write_*` halves |
| code | `packages/agentic-bootstrap/src/agentic_bootstrap/install.py` | Split each `_write_<surface>` into `_render_<surface>` (pure) + `_write_<surface>` (disk). Existing call sites in `_write_configs` go through render+write. Manifest write at `install.py:589` adds `"mcp_servers": sorted(mcp_servers.keys())` when `mcp_servers` is provided. Decide in slice 1 whether `_render_*` lives in `install.py` or moves to a `_writers.py` module that both `install` and `mcp_sync` import. |
| code | `packages/agentic-bootstrap/src/agentic_bootstrap/subcommands.py` | Add `mcp-sync` subcommand; rewrite `repair --mcp-servers` to call `sync_mcp_configs`; add doctor's MCP-drift check via `sync_mcp_configs(check_only=True)` |
| code | `packages/agentic-bootstrap/src/agentic_bootstrap/__main__.py` (or `cli.py`) | Register the `mcp-sync` argparse subparser |
| code | `packages/agentic-protocol/src/agentic_protocol/...` (`BootstrapManifest`) | Add optional `mcp_servers: list[str]` field for the managed-name provenance block. Required by slice 1's validation round-trip. |
| tests (new) | `packages/agentic-bootstrap/tests/test_mcp_sync_unit.py` | Unit tests: legacy-writer-vs-render byte parity, idempotent no-op, drift detection per surface, third-party preservation, `--prune-removed-managed` provenance from ledger, ledger seeding on legacy install (no `mcp_servers` block), surfaces filter, check-only never invokes the disk-write helper (mock the wrapper, assert zero calls) |
| tests (new) | `packages/agentic-bootstrap/tests/test_mcp_sync_cli.py` | End-to-end: fixture target with stale launchers; `--check` exits `1` and writes nothing; `--apply` exits `0` and rewrites the four surfaces; nothing else touched |
| tests | `packages/agentic-bootstrap/tests/test_doctor.py` (or equivalent) | Add MCP-drift finding case |
| tests | `packages/agentic-bootstrap/tests/test_repair.py` (or equivalent) | Repair now delegates to `sync_mcp_configs`; assert behavior preserved |
| docs | `docs/CONSUMER.md` | Add "Refresh MCP servers" section: one command, no caveats |

## Related Files

| File | Note |
| --- | --- |
| `packages/agentic-bootstrap/src/agentic_bootstrap/install.py` writers (`:746`/`:760`/`:775`) | Existing managed-only merge logic preserves third-party launchers structurally — `sync_mcp_configs` inherits this property by reusing the same render path; no separate preserve helper exists today. |
| `docs/scopes/bootstrap-consumption-hardening-scope.md` | Adjacent scope; both touch `agentic-bootstrap update`. Sequencing constraint at top of this plan covers it. |

## Verification Strategy

- Deterministic tests:
  - `uv run pytest packages/agentic-bootstrap/tests/test_mcp_sync_unit.py packages/agentic-bootstrap/tests/test_mcp_sync_cli.py packages/agentic-bootstrap/tests/test_doctor.py packages/agentic-bootstrap/tests/test_repair.py -q`
- Runtime-parity / environment checks:
  - End-to-end CLI invocation against a tmp_path fixture target carrying stale launchers; assert `git status` shows only the four expected files modified.
- Contract / fixture verification:
  - The slice-4 contract test pins the post-fix behavior so a future change cannot silently re-introduce hand-patched literals or extend the write surface beyond the four files.
- Manual verification:
  - On a real consumer checkout (e.g. `altcontext-marketing-monorepo`), run `uvx agentic-bootstrap@<new> mcp-sync --check` and confirm drift is reported correctly without remote fetch or overlay disturbance.

## Slice Delivery

### Slice 1: `sync_mcp_configs` internal API + unit tests

**Goal**: Land the parameter-only API that everything else (CLI, doctor, repair) drives, plus the render/merge seam and ledger provenance block that the contract depends on.

Changes:

- Split each `_write_<surface>` in `install.py` into `_render_<surface>(target, mcp_servers) -> bytes` (pure: read existing, merge managed entries, return rendered bytes) and `_write_<surface>(target, rendered: bytes)` (disk write only). Update `_write_configs` to call render then write so install behavior is byte-identical.
- Add a `mcp_servers: list[str]` field to the manifest (`install.py:589`) when `mcp_servers` is provided; sort the names for stable output. Add the matching optional field to `agentic_protocol.BootstrapManifest`. Legacy ledgers without the field continue to validate.
- New `mcp_sync.py` module with `sync_mcp_configs(target, mcp_servers, *, surfaces=("claude","vscode","codex"), check_only=False, prune_removed_managed=False) -> SyncReport`. Internally:
  - Call `_render_<surface>` for each requested surface, compare rendered bytes against on-disk content to populate per-surface drift status.
  - When `check_only=True`, return without invoking any `_write_*` wrapper (the seam is the contract).
  - When `check_only=False`, call `_write_<surface>` only for surfaces with drift; skip otherwise (idempotency).
  - For `--prune-removed-managed`, read the existing ledger's `mcp_servers` block as the previously-managed name set, compute `prune_set = previously_managed - resolved_map.keys()`, and pass it down to the render step so those keys are removed from the target file. After writes, rewrite the ledger's block to `sorted(resolved_map.keys())`. On legacy targets without the block, log "first-run: no prior provenance" and skip pruning for that pass; the block is seeded from the resolved map at write time so the next run has provenance.
  - The ledger block is the single source of truth for provenance; `mcp_sync` never inspects client config files to guess which keys "look managed."

Proof:

- `test_mcp_sync_unit.py` covers: legacy-writer-vs-render byte parity for each surface (calls the legacy `_write_*` against a tmp file, calls `_render_*`, asserts equal bytes); idempotent no-op on clean target; drift detection per surface; third-party launcher preservation (fixture target with both managed and unmanaged keys, asserts unmanaged keys untouched); `--prune-removed-managed` reads ledger block correctly (managed name absent from resolved map is removed; third-party name is preserved); legacy ledger without `mcp_servers` block → first-run prune is no-op + block is seeded; ledger rewritten when stale; surfaces filter limits writes to the requested subset; `check_only=True` never reaches `_write_*` (mock asserts zero calls).

### Slice 2: CLI subcommand + exit-code contract

**Goal**: Wire `agentic-bootstrap mcp-sync` to the API; pin exit codes.

Changes:

- Argparse subparser with `--target`, `--mcp-servers`, `--check`, `--apply`, `--prune-removed-managed`, `--surfaces`, `--json`.
- `--check` mutually exclusive with `--apply` (default behavior is `--apply` when neither given; document explicitly in `--help`).
- Exit codes: `0` clean, `1` drift in check mode, `>=2` resolution failure.
- Print SyncReport to stdout (JSON when `--json`, human-readable otherwise). JSON shape: `{"surfaces": [{"name": str, "path": str, "drift": bool, "action": "created"|"merged"|"unchanged"|"would_write"}], "preserved_third_party": [str], "pruned_managed": [str], "ledger_mcp_servers": [str], "exit_code": int}`. Pinned by a contract test.

Proof:

- `test_mcp_sync_cli.py` slice-2 cases: argparse parses each flag combo (including `--json`); mutex enforced; exit codes match the contract; `--json` output validates against the pinned JSON shape; human-readable output is non-empty when `--json` is omitted.

### Slice 3: Doctor + repair integration

**Goal**: Make `bootstrap doctor` surface MCP-config drift and `repair --mcp-servers` reuse `sync_mcp_configs`.

Changes:

- Doctor runs `sync_mcp_configs(check_only=True)` and emits one finding per drifted surface, recommending `mcp-sync --apply`.
- `repair --mcp-servers <spec>` becomes a thin wrapper that resolves the map then calls `sync_mcp_configs(check_only=False)`.

Proof:

- Doctor test: drifted fixture → drift findings present; clean fixture → no MCP findings.
- Repair test: existing behavior preserved; new internal call observable via the SyncReport.

### Slice 4: End-to-end contract test + CONSUMER.md section

**Goal**: Pin the four-surface write boundary and document the operator path.

Changes:

- `test_mcp_sync_cli.py` end-to-end: fixture target carrying outdated launchers; `--check` exits `1` and reports the expected delta; `--apply` exits `0`; assert ONLY `.mcp.json`, `.vscode/mcp.json`, `.codex/config.toml`, `.agentic-bootstrap.json` are modified (snapshot the rest of the tree before/after).
- `docs/CONSUMER.md` adds "Refresh MCP servers" section: one command, no caveats.

Proof:

- The contract test fails if anyone later widens the write surface (e.g. accidentally regenerates a skill).
- CONSUMER.md renders correctly; no version literal hand-edited.

---

## Consolidated Checklist

## Context and Ownership

- [ ] Loaded `install.py` writers (`:746`/`:760`/`:775`); understood that third-party preservation is structural (managed-name merge), not a separate helper.
- [ ] Loaded `subcommands.py` to confirm `doctor` / `repair` / `update` integration points.
- [ ] Confirmed AHMCP-49 has landed (`MCP_SERVER_PACKAGE_VERSIONS` exists) before starting slice 1.
- [ ] Verified the bootstrap-consumption-hardening sequencing constraint (top of plan): either AHMCP-48 has landed its `update` parity work, or this task carries the shared `update` integration test.

### Checklist for Slice 1: `sync_mcp_configs` internal API + unit tests

- [ ] `_render_<surface>` / `_write_<surface>` split landed in `install.py` (or `_writers.py`); install behavior byte-identical.
- [ ] Manifest write at `install.py:589` includes `"mcp_servers": sorted(mcp_servers.keys())` when servers are provided; `BootstrapManifest` gained the optional field.
- [ ] `mcp_sync.py` module created; `SyncReport` shape pinned in a docstring.
- [ ] Decision recorded (render-helpers-stay-in-install vs move-to-`_writers.py`); one writer code path only.
- [ ] `--prune-removed-managed` reads provenance from the ledger `mcp_servers` block; never inspects client config keys.
- [ ] Legacy-target fallback (no `mcp_servers` block) seeds the block and skips pruning for that pass.
- [ ] `check_only=True` never invokes `_write_<surface>` (mock-verified).
- [ ] `test_mcp_sync_unit.py` covers all listed cases (parity, idempotency, drift, preservation, prune-from-ledger, legacy-fallback, ledger-rewrite, surfaces-filter, check-only-no-write).
- [ ] Verification evidence: unit suite passes.

### Checklist for Slice 2: CLI subcommand + exit-code contract

- [ ] Argparse subparser registered with all seven flags including `--json`.
- [ ] Exit codes implemented per the constraint (`0`/`1`/`>=2`).
- [ ] `--check` and `--apply` mutex enforced and documented in `--help`.
- [ ] SyncReport JSON shape pinned by test (per the schema in slice 2 changes).
- [ ] `--json` and human-readable output paths both exercised.
- [ ] Verification evidence: CLI suite slice-2 cases pass.

### Checklist for Slice 3: Doctor + repair integration

- [ ] Doctor surfaces MCP-drift findings via `sync_mcp_configs(check_only=True)`.
- [ ] Repair `--mcp-servers` delegates to `sync_mcp_configs`.
- [ ] Existing doctor / repair tests still pass.
- [ ] Verification evidence: doctor/repair tests pass with new + preserved cases.

### Checklist for Slice 4: End-to-end contract test + CONSUMER.md section

- [ ] End-to-end test asserts the four-surface write boundary (snapshot tree diff).
- [ ] CONSUMER.md "Refresh MCP servers" section added; example block uses `mcp-sync`, not raw config edits.
- [ ] Verification evidence: end-to-end test passes; CONSUMER.md generated/checked.

## Review Readiness

- [ ] No new code path duplicates the install-side writers.
- [ ] Doctor's MCP-drift detection codepath is `sync_mcp_configs(check_only=True)`, not a parallel detector.
- [ ] Sequencing relative to bootstrap-consumption-hardening (AHMCP-48) is explicit and verifiable.
- [ ] Handoff decision records the new public surface (`mcp-sync` CLI + `sync_mcp_configs` API).

## Success Criteria

- [ ] An operator running `agentic-bootstrap mcp-sync --target .` after a coordinated MCP-stack release sees `.mcp.json` / `.vscode/mcp.json` / `.codex/config.toml` / `.agentic-bootstrap.json` updated to the new pins in one command, with no remote fetch and no overlay-cache disturbance.
- [ ] `bootstrap doctor` reports MCP-config drift and recommends `mcp-sync --apply` as the repair.
- [ ] `bootstrap repair --mcp-servers default` produces the same observable filesystem outcome as `mcp-sync --apply`.
- [ ] The end-to-end contract test fails if anyone widens the write surface beyond the four named files.
- [ ] The CLI invocation works from any harness (Claude / VS Code / Codex / future) — agent-agnosticism verified by the parameter-only internal API plus the cross-harness CLI test.
