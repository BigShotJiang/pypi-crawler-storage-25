# -*- coding: utf-8 -*-
"""AutoCompact - Progressive Context Compression.

From Claude Code architecture:
- 3,960 lines compression module, cache hit rate ↑300%
- Three-stage density gradient compression
- Avoids violent truncation that loses information
- Structured dependency injection

Three-stage density gradient:
1. Full fidelity: Recent N messages (complete text)
2. Summarized: Mid-range messages (key points extracted)
3. Key facts only: Old messages (structured facts)

This replaces the traditional "same agent keeps compressing" approach
which retains completion bias and increasing costs.
"""

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class CompressionLevel(str, Enum):
    """Compression levels for messages."""
    FULL = "full"
    SUMMARIZED = "summarized"
    KEY_FACTS = "key_facts"


@dataclass
class CompactPolicy:
    """Policy for context compaction."""
    full_fidelity_count: int = 10
    summarize_threshold: int = 20
    key_facts_threshold: int = 50
    max_summary_length: int = 200
    max_key_fact_length: int = 50
    preserve_system_prompt: bool = True
    preserve_tool_results: bool = True
    preserve_recent_exchanges: int = 4


@dataclass
class KeyFact:
    """A key fact extracted from conversation."""
    content: str
    source_turn: int
    category: str = "general"
    confidence: float = 1.0
    timestamp: float = field(default_factory=time.time)


@dataclass
class CompactResult:
    """Result of a compaction operation."""
    original_message_count: int = 0
    compressed_message_count: int = 0
    original_token_estimate: int = 0
    compressed_token_estimate: int = 0
    compression_ratio: float = 0.0
    key_facts_extracted: int = 0
    summaries_generated: int = 0
    level_distribution: Dict[str, int] = field(default_factory=dict)
    duration: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_message_count": self.original_message_count,
            "compressed_message_count": self.compressed_message_count,
            "original_token_estimate": self.original_token_estimate,
            "compressed_token_estimate": self.compressed_token_estimate,
            "compression_ratio": self.compression_ratio,
            "key_facts_extracted": self.key_facts_extracted,
            "summaries_generated": self.summaries_generated,
            "level_distribution": self.level_distribution,
            "duration": self.duration,
        }


class AutoCompact:
    """Progressive context compression engine.

    Key innovations from Claude Code:
    1. Three-stage density gradient (not violent truncation)
    2. Key facts extraction preserves critical information
    3. Structured dependency injection for summaries
    4. Cache hit rate ↑300% through smart compression

    Usage:
        compact = AutoCompact(llm_fn=my_llm)

        result = await compact.compact(messages)
        compressed_messages = result.compressed_messages
    """

    def __init__(
        self,
        llm_fn: Optional[Callable] = None,
        policy: Optional[CompactPolicy] = None,
    ):
        """Initialize AutoCompact.

        Args:
            llm_fn: LLM function for summarization
            policy: Compaction policy
        """
        self.llm_fn = llm_fn
        self.policy = policy or CompactPolicy()
        self._key_facts: List[KeyFact] = []
        self._compaction_count = 0

    async def compact(
        self,
        messages: List[Dict[str, Any]],
        token_budget_ratio: float = 0.0,
    ) -> tuple[List[Dict[str, Any]], CompactResult]:
        """Compress messages using three-stage density gradient.

        Args:
            messages: Conversation messages to compress
            token_budget_ratio: Current token usage ratio (0.0-1.0)

        Returns:
            Tuple of (compressed_messages, CompactResult)
        """
        start_time = time.time()

        if len(messages) <= self.policy.full_fidelity_count:
            result = CompactResult(
                original_message_count=len(messages),
                compressed_message_count=len(messages),
                duration=time.time() - start_time,
            )
            return messages, result

        # Adjust thresholds based on budget pressure
        policy = self._adjust_policy(token_budget_ratio)

        compressed: List[Dict[str, Any]] = []
        level_dist: Dict[str, int] = {"full": 0, "summarized": 0, "key_facts": 0}
        summaries_generated = 0
        key_facts_extracted = 0

        # Separate system messages (always preserve)
        system_messages = []
        conversation_messages = []
        for msg in messages:
            if msg.get("role") == "system" and policy.preserve_system_prompt:
                system_messages.append(msg)
            else:
                conversation_messages.append(msg)

        total = len(conversation_messages)

        # Apply three-stage density gradient
        for i, msg in enumerate(conversation_messages):
            distance_from_end = total - i

            if distance_from_end <= policy.full_fidelity_count:
                # Stage 1: Full fidelity (recent messages)
                compressed.append(msg)
                level_dist["full"] += 1

            elif distance_from_end <= policy.summarize_threshold:
                # Stage 2: Summarized (mid-range)
                summary = await self._summarize_message(msg, i)
                compressed.append({
                    "role": msg.get("role", "assistant"),
                    "content": f"[Summary] {summary}",
                    "compression_level": CompressionLevel.SUMMARIZED.value,
                })
                level_dist["summarized"] += 1
                summaries_generated += 1

            else:
                # Stage 3: Key facts only (old messages)
                facts = await self._extract_key_facts(msg, i)
                for fact in facts:
                    self._key_facts.append(fact)
                    key_facts_extracted += 1
                level_dist["key_facts"] += 1

        # Prepend key facts as a structured context block
        if self._key_facts:
            facts_text = self._format_key_facts()
            compressed.insert(0, {
                "role": "system",
                "content": f"[Context Memory - Key Facts]\n{facts_text}",
                "compression_level": CompressionLevel.KEY_FACTS.value,
            })

        # Prepend system messages
        compressed = system_messages + compressed

        # Calculate compression metrics
        original_tokens = self._estimate_tokens(messages)
        compressed_tokens = self._estimate_tokens(compressed)

        result = CompactResult(
            original_message_count=len(messages),
            compressed_message_count=len(compressed),
            original_token_estimate=original_tokens,
            compressed_token_estimate=compressed_tokens,
            compression_ratio=compressed_tokens / original_tokens if original_tokens > 0 else 1.0,
            key_facts_extracted=key_facts_extracted,
            summaries_generated=summaries_generated,
            level_distribution=level_dist,
            duration=time.time() - start_time,
        )

        self._compaction_count += 1
        logger.info(
            f"AutoCompact: {len(messages)} → {len(compressed)} messages, "
            f"ratio={result.compression_ratio:.2f}"
        )

        return compressed, result

    def _adjust_policy(self, token_budget_ratio: float) -> CompactPolicy:
        """Adjust compaction policy based on budget pressure.

        Higher pressure = more aggressive compression.

        Args:
            token_budget_ratio: Current token usage ratio

        Returns:
            Adjusted policy
        """
        if token_budget_ratio < 0.5:
            return self.policy

        adjusted = CompactPolicy(
            preserve_system_prompt=self.policy.preserve_system_prompt,
            preserve_tool_results=self.policy.preserve_tool_results,
        )

        if token_budget_ratio >= 0.8:
            adjusted.full_fidelity_count = max(3, self.policy.full_fidelity_count // 3)
            adjusted.summarize_threshold = max(5, self.policy.summarize_threshold // 3)
            adjusted.key_facts_threshold = max(10, self.policy.key_facts_threshold // 3)
        elif token_budget_ratio >= 0.65:
            adjusted.full_fidelity_count = max(5, self.policy.full_fidelity_count // 2)
            adjusted.summarize_threshold = max(10, self.policy.summarize_threshold // 2)
            adjusted.key_facts_threshold = max(20, self.policy.key_facts_threshold // 2)

        return adjusted

    async def _summarize_message(
        self,
        message: Dict[str, Any],
        turn_index: int,
    ) -> str:
        """Summarize a single message.

        Args:
            message: Message to summarize
            turn_index: Turn index in conversation

        Returns:
            Summary text
        """
        content = message.get("content", "")
        role = message.get("role", "unknown")

        if not content or len(content) < 50:
            return content

        if self.llm_fn:
            try:
                prompt = (
                    f"Summarize this {role} message in under "
                    f"{self.policy.max_summary_length} characters. "
                    f"Preserve key information and decisions:\n\n{content}"
                )

                summary = None
                try:
                    from xingzierai.agents.local_model_dispatcher import LocalModelDispatcher
                    dispatcher = LocalModelDispatcher.get_instance()
                    if dispatcher.has_local_model("fact_extract"):
                        summary = await dispatcher.dispatch(
                            task_type="fact_extract",
                            input_text=prompt,
                            max_new_tokens=128,
                            temperature=0.3,
                            collect_data=False,
                        )
                except Exception:
                    pass

                if not summary:
                    async def _llm_summarize():
                        if asyncio.iscoroutinefunction(self.llm_fn):
                            return await self.llm_fn(prompt)
                        return self.llm_fn(prompt)

                    try:
                        from xingzierai.agents.local_model_dispatcher import LocalModelDispatcher
                        dispatcher = LocalModelDispatcher.get_instance()
                        summary = await dispatcher.dispatch(
                            task_type="fact_extract",
                            input_text=prompt,
                            fallback_fn=_llm_summarize,
                            max_new_tokens=128,
                            temperature=0.3,
                            collect_data=True,
                        )
                    except Exception:
                        if asyncio.iscoroutinefunction(self.llm_fn):
                            summary = await self.llm_fn(prompt)
                        else:
                            summary = self.llm_fn(prompt)

                return str(summary)[:self.policy.max_summary_length]
            except Exception as e:
                logger.warning(f"LLM summarization failed: {e}")

        # Heuristic fallback: take first and last sentences
        sentences = content.replace(". ", ".\n").split("\n")
        if len(sentences) <= 2:
            return content[:self.policy.max_summary_length]

        summary = f"{sentences[0]} ... {sentences[-1]}"
        return summary[:self.policy.max_summary_length]

    async def _extract_key_facts(
        self,
        message: Dict[str, Any],
        turn_index: int,
    ) -> List[KeyFact]:
        """Extract key facts from a message.

        Args:
            message: Message to extract facts from
            turn_index: Turn index

        Returns:
            List of extracted key facts
        """
        content = message.get("content", "")
        if not content:
            return []

        if self.llm_fn:
            try:
                prompt = (
                    f"Extract key facts from this message as a JSON list. "
                    f"Each fact should be under {self.policy.max_key_fact_length} chars.\n\n"
                    f"Message: {content}\n\n"
                    f'Output format: ["fact1", "fact2", ...]'
                )

                result = None
                try:
                    from xingzierai.agents.local_model_dispatcher import LocalModelDispatcher
                    dispatcher = LocalModelDispatcher.get_instance()
                    if dispatcher.has_local_model("fact_extract"):
                        result = await dispatcher.dispatch(
                            task_type="fact_extract",
                            input_text=prompt,
                            max_new_tokens=128,
                            temperature=0.3,
                            collect_data=False,
                        )
                except Exception:
                    pass

                if not result:
                    async def _llm_extract():
                        if asyncio.iscoroutinefunction(self.llm_fn):
                            return await self.llm_fn(prompt)
                        return self.llm_fn(prompt)

                    try:
                        from xingzierai.agents.local_model_dispatcher import LocalModelDispatcher
                        dispatcher = LocalModelDispatcher.get_instance()
                        result = await dispatcher.dispatch(
                            task_type="fact_extract",
                            input_text=prompt,
                            fallback_fn=_llm_extract,
                            max_new_tokens=128,
                            temperature=0.3,
                            collect_data=True,
                        )
                    except Exception:
                        if asyncio.iscoroutinefunction(self.llm_fn):
                            result = await self.llm_fn(prompt)
                        else:
                            result = self.llm_fn(prompt)

                facts_json = str(result)
                try:
                    facts_list = json.loads(facts_json)
                except json.JSONDecodeError:
                    start = facts_json.find("[")
                    end = facts_json.rfind("]") + 1
                    if start >= 0 and end > start:
                        facts_list = json.loads(facts_json[start:end])
                    else:
                        facts_list = [facts_json[:self.policy.max_key_fact_length]]

                return [
                    KeyFact(
                        content=str(fact)[:self.policy.max_key_fact_length],
                        source_turn=turn_index,
                        category="extracted",
                    )
                    for fact in facts_list
                    if fact
                ]
            except Exception as e:
                logger.warning(f"Key fact extraction failed: {e}")

        # Heuristic fallback: split by sentences
        sentences = [s.strip() for s in content.replace(". ", ".\n").split("\n") if s.strip()]
        return [
            KeyFact(
                content=s[:self.policy.max_key_fact_length],
                source_turn=turn_index,
                category="heuristic",
            )
            for s in sentences[:5]
        ]

    def _format_key_facts(self) -> str:
        """Format key facts for context injection.

        Returns:
            Formatted key facts string
        """
        if not self._key_facts:
            return ""

        # Deduplicate and sort by recency
        seen = set()
        unique_facts = []
        for fact in reversed(self._key_facts):
            if fact.content not in seen:
                seen.add(fact.content)
                unique_facts.append(fact)

        unique_facts = unique_facts[:30]  # Limit total facts

        lines = []
        for i, fact in enumerate(unique_facts, 1):
            lines.append(f"{i}. {fact.content}")

        return "\n".join(lines)

    def _estimate_tokens(self, messages: List[Dict[str, Any]]) -> int:
        """Estimate token count for messages.

        Uses rough heuristic: 1 token ≈ 4 characters.

        Args:
            messages: Messages to estimate

        Returns:
            Estimated token count
        """
        total_chars = sum(len(str(msg.get("content", ""))) for msg in messages)
        return total_chars // 4

    def get_key_facts(self) -> List[KeyFact]:
        """Get all accumulated key facts."""
        return self._key_facts

    def clear_key_facts(self) -> None:
        """Clear accumulated key facts."""
        self._key_facts.clear()
