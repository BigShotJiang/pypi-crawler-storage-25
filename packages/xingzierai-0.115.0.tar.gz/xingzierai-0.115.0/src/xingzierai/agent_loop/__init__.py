# -*- coding: utf-8 -*-
"""XINGZIERAI AgentLoop - Dual-Layer Decoupled Architecture.

Inspired by Claude Code's architecture:
- Session Layer: LLM Prompt interaction (Generator)
- Execution Layer: State machine flow (Evaluator)

Key innovations from Anthropic research:
1. Generator-Evaluator separation prevents Context Anxiety
2. Evaluator operates in "skeptic mode" (40% accuracy improvement)
3. AsyncGenerator streaming for 200ms first-byte response
4. Token Budget dynamic monitoring with circuit breaker

Architecture:
    User Input → Session Layer (Generator)
                    ↓
              Evaluator (Skeptic Mode)
                    ↓
              Execution Layer (State Machine)
                    ↓
              Tool Execution → Feedback Loop
"""

from .loop import AgentLoop, LoopState, LoopEvent
from .evaluator import SkepticEvaluator, EvaluationResult, EvaluationVerdict
from .token_budget import TokenBudget, BudgetPolicy
from .circuit_breaker import CircuitBreaker, BreakerState
from .rollout import (
    RolloutTree,
    RolloutNode,
    RolloutManager,
    RolloutManager as Rollout,
    Action,
    Observation,
    StateSnapshot,
    NodeStatus,
    BacktrackResult,
)
from .rollout_loop import RolloutAgentLoop, RolloutEvent, RolloutLoopResult
from .branch_strategy import (
    BranchStrategy,
    BranchScore,
    BranchingPolicy,
    BranchRegistry,
    SmartBranchSelector,
    AdaptiveBranchingController,
)
from .persistence import (
    RolloutPersistence,
    RolloutPersistenceAsync,
    PersistedRollout,
)
from .anchor_linkage import (
    AnchorLinkage,
    Anchor,
    AnchorChain,
    AnchorReference,
    AnchorType,
)
from .qaoa import (
    QAOEvaluator,
    QAOAResult,
    Query,
    Action,
    Observation,
    Answer,
    EvaluationLevel,
    QAOAStatus,
    FunctionLevelMetrics,
    TurnLevelMetrics,
    ConversationLevelMetrics,
)
from .hierarchical_evaluator import (
    HierarchicalEvaluator,
    FunctionEvaluation,
    TurnEvaluation,
    ConversationEvaluation,
    ValidationMode,
)

__all__ = [
    "AgentLoop",
    "LoopState",
    "LoopEvent",
    "SkepticEvaluator",
    "EvaluationResult",
    "EvaluationVerdict",
    "TokenBudget",
    "BudgetPolicy",
    "CircuitBreaker",
    "BreakerState",
    "RolloutTree",
    "RolloutNode",
    "RolloutManager",
    "Rollout",
    "Action",
    "Observation",
    "StateSnapshot",
    "NodeStatus",
    "BacktrackResult",
    "RolloutAgentLoop",
    "RolloutEvent",
    "RolloutLoopResult",
    "BranchStrategy",
    "BranchScore",
    "BranchingPolicy",
    "BranchRegistry",
    "SmartBranchSelector",
    "AdaptiveBranchingController",
    "RolloutPersistence",
    "RolloutPersistenceAsync",
    "PersistedRollout",
    "AnchorLinkage",
    "Anchor",
    "AnchorChain",
    "AnchorReference",
    "AnchorType",
    "QAOEvaluator",
    "QAOAResult",
    "Query",
    "Answer",
    "EvaluationLevel",
    "QAOAStatus",
    "FunctionLevelMetrics",
    "TurnLevelMetrics",
    "ConversationLevelMetrics",
    "HierarchicalEvaluator",
    "FunctionEvaluation",
    "TurnEvaluation",
    "ConversationEvaluation",
    "ValidationMode",
]
