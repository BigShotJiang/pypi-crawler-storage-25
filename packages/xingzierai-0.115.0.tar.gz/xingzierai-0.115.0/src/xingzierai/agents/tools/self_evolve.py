# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import logging
import os
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import List, Optional

from xingzierai.agentscope_core.message import TextBlock
from xingzierai.agentscope_core.tool import ToolResponse

logger = logging.getLogger(__name__)

EVOLUTION_DAEMON_URL = "http://localhost:8580"

PROTECTED_PATHS = (
    "src/xingzierai/security/",
    "src/xingzierai/config/config.py",
    ".env",
    "pyproject.toml",
    "src/xingzierai/__version__.py",
)


def _is_protected_path(file_path: str) -> bool:
    normalized = file_path.replace("\\", "/")
    for protected in PROTECTED_PATHS:
        if normalized.startswith(protected):
            return True
    return False


def _find_project_root() -> Optional[str]:
    try:
        import xingzierai
        module_path = os.path.dirname(os.path.abspath(xingzierai.__file__))
        project_root = os.path.dirname(os.path.dirname(module_path))
        if os.path.exists(os.path.join(project_root, "src", "xingzierai")):
            return project_root
    except Exception as _find_err:
        logger.debug("Project root detection failed: %s", _find_err)

    common_paths = [
        os.path.expanduser("~/Desktop/XINGZIERAI40"),
        os.path.expanduser("~/XINGZIERAI40"),
    ]
    for path in common_paths:
        if os.path.exists(os.path.join(path, "src", "xingzierai")):
            return path
    return None


def _git_checkpoint(project_root: str, message: str) -> Optional[str]:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        current_hash = result.stdout.strip()

        subprocess.run(
            ["git", "add", "-A"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=30,
        )
        subprocess.run(
            ["git", "commit", "-m", message, "--allow-empty"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=30,
        )

        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout.strip() if result.returncode == 0 else current_hash
    except Exception as e:
        logger.warning("Git checkpoint failed: %s", e)
        return None


def _git_rollback(project_root: str, commit_hash: str) -> bool:
    try:
        result = subprocess.run(
            ["git", "reset", "--hard", commit_hash],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=30,
        )
        return result.returncode == 0
    except Exception as e:
        logger.error("Git rollback failed: %s", e)
        return False


def _validate_python_syntax(file_path: str) -> Optional[str]:
    import ast

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            ast.parse(f.read())
        return None
    except SyntaxError as e:
        return f"Syntax error at line {e.lineno}: {e.msg}"
    except Exception as e:
        return f"Validation error: {e}"


def _run_smoke_test(project_root: str) -> dict:
    try:
        result = subprocess.run(
            [
                "python3", "-c",
                "import xingzierai; print('import ok')",
            ],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return {"passed": True, "output": result.stdout.strip()}
        return {"passed": False, "output": result.stderr.strip()[:500]}
    except subprocess.TimeoutExpired:
        return {"passed": False, "output": "Smoke test timed out"}
    except Exception as e:
        return {"passed": False, "output": str(e)[:500]}


def self_evolve(
    task: str,
    target_files: Optional[List[str]] = None,
    agent: str = "opencode",
    validation: str = "auto",
    rollback_on_failure: bool = True,
    dry_run: bool = False,
) -> ToolResponse:
    """Self-evolution tool: Let XINGZIERAI modify its own source code via ACP agents.

    This tool enables XINGZIERAI to evolve itself by delegating code modification
    tasks to external ACP agents (like OpenCode). The process includes:

    1. Git checkpoint (save current state)
    2. Validate target files are not protected
    3. Delegate to ACP agent for code generation
    4. Validate syntax of modified files
    5. Run smoke test (import check)
    6. If validation fails, rollback to checkpoint

    IMPORTANT: Protected files cannot be modified:
    - src/xingzierai/security/
    - src/xingzierai/config/config.py
    - .env
    - pyproject.toml
    - src/xingzierai/__version__.py

    Args:
        task: Description of what to evolve. Be specific.
            Example: "Optimize react_agent.py to reduce token usage by 20%"
            Example: "Add retry logic to the SSE stream handler"
        target_files: List of target file paths relative to project root.
            Example: ["src/xingzierai/agents/react_agent.py"]
            If not specified, the ACP agent will determine the files.
        agent: ACP agent to use. Default "opencode".
            Options: "opencode", "qwen_code", "claude_code", "codex"
        validation: Validation mode. Default "auto".
            - "auto": Run syntax check + smoke test
            - "full": Run syntax check + smoke test + unit tests
            - "skip": Skip validation (dangerous)
        rollback_on_failure: Whether to rollback on failure. Default True.
        dry_run: If True, only show what would be done without executing.
            Default False.

    Returns:
        `ToolResponse`: Evolution result with status and details.
    """
    project_root = _find_project_root()
    if not project_root:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text="Cannot find XINGZIERAI project root directory.",
                )
            ],
        )

    if target_files:
        for fp in target_files:
            if _is_protected_path(fp):
                return ToolResponse(
                    content=[
                        TextBlock(
                            type="text",
                            text=(
                                f"PROTECTED FILE: '{fp}' cannot be modified "
                                f"by self_evolve for security reasons.\n"
                                f"Protected paths: {', '.join(PROTECTED_PATHS)}"
                            ),
                        )
                    ],
                )

    if dry_run:
        details = [
            "DRY RUN - No changes will be made.\n",
            f"Task: {task}",
            f"Agent: {agent}",
            f"Project root: {project_root}",
            f"Validation: {validation}",
            f"Rollback on failure: {rollback_on_failure}",
        ]
        if target_files:
            details.append(f"Target files: {', '.join(target_files)}")
        else:
            details.append("Target files: (agent will determine)")
        return ToolResponse(
            content=[TextBlock(type="text", text="\n".join(details))],
        )

    checkpoint_hash = _git_checkpoint(
        project_root,
        f"pre-evolution: {task[:80]}",
    )
    if not checkpoint_hash:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        "Failed to create git checkpoint. "
                        "Cannot proceed with evolution for safety."
                    ),
                )
            ],
        )

    prompt_parts = [
        f"Task: {task}",
        "",
        "IMPORTANT CONTEXT: You are modifying XINGZIERAI's own source code.",
        "This is a self-evolution operation. Follow these rules:",
        "1. Only modify the files necessary for the task",
        "2. Maintain backward compatibility",
        "3. Follow existing code style and patterns",
        "4. Do not add unnecessary dependencies",
        "5. Ensure all imports are valid",
    ]
    if target_files:
        prompt_parts.append(f"\nTarget files: {', '.join(target_files)}")
    prompt_parts.append(f"\nWorking directory: {project_root}")

    full_prompt = "\n".join(prompt_parts)

    from xingzierai.agents.tools.acp_tools import delegate_external_agent

    acp_result = delegate_external_agent(
        runner=agent,
        prompt=full_prompt,
        cwd=project_root,
    )

    acp_text = ""
    if isinstance(acp_result.content, list):
        for block in acp_result.content:
            if isinstance(block, dict):
                acp_text += block.get("text", "")
            elif hasattr(block, "text"):
                acp_text += block.text
    elif isinstance(acp_result.content, str):
        acp_text = acp_result.content

    if "permission_request" in acp_text.lower() or "permission required" in acp_text.lower():
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"ACP agent '{agent}' is requesting permission.\n\n"
                        f"{acp_text}\n\n"
                        f"Git checkpoint: {checkpoint_hash}\n"
                        f"Use 'acp_resume' to approve, then run self_evolve again "
                        f"with the same task to validate changes."
                    ),
                )
            ],
        )

    if validation == "skip":
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Self-evolution completed (validation skipped).\n\n"
                        f"Agent output:\n{acp_text}\n\n"
                        f"Git checkpoint: {checkpoint_hash}\n"
                        f"To rollback: git reset --hard {checkpoint_hash}"
                    ),
                )
            ],
        )

    validation_results = []
    all_valid = True

    if target_files:
        for fp in target_files:
            full_path = os.path.join(project_root, fp)
            if os.path.exists(full_path) and fp.endswith(".py"):
                error = _validate_python_syntax(full_path)
                if error:
                    validation_results.append(f"FAIL: {fp} - {error}")
                    all_valid = False
                else:
                    validation_results.append(f"OK: {fp} - syntax valid")

    smoke_result = _run_smoke_test(project_root)
    if smoke_result["passed"]:
        validation_results.append(f"OK: smoke test - {smoke_result['output']}")
    else:
        validation_results.append(f"FAIL: smoke test - {smoke_result['output']}")
        all_valid = False

    if validation == "full" and all_valid:
        try:
            test_result = subprocess.run(
                [
                    "python3", "-m", "pytest",
                    "src/xingzierai/tests/",
                    "-x", "-q", "--timeout=30",
                ],
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if test_result.returncode == 0:
                validation_results.append("OK: unit tests passed")
            else:
                validation_results.append(
                    f"FAIL: unit tests - {test_result.stdout[-300:]}"
                )
                all_valid = False
        except subprocess.TimeoutExpired:
            validation_results.append("FAIL: unit tests timed out")
            all_valid = False
        except Exception as e:
            validation_results.append(f"WARN: unit tests skipped - {e}")

    if not all_valid and rollback_on_failure:
        rollback_ok = _git_rollback(project_root, checkpoint_hash)
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Self-evolution FAILED - validation errors detected.\n\n"
                        f"Agent output:\n{acp_text}\n\n"
                        f"Validation results:\n"
                        + "\n".join(f"  {r}" for r in validation_results)
                        + f"\n\nRollback: {'SUCCESS' if rollback_ok else 'FAILED'}\n"
                        f"Checkpoint: {checkpoint_hash}"
                    ),
                )
            ],
        )

    if all_valid:
        _git_checkpoint(project_root, f"post-evolution: {task[:80]}")
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Self-evolution COMPLETED successfully!\n\n"
                        f"Agent output:\n{acp_text}\n\n"
                        f"Validation results:\n"
                        + "\n".join(f"  {r}" for r in validation_results)
                        + f"\n\nPre-evolution checkpoint: {checkpoint_hash}\n"
                        f"Changes have been committed."
                    ),
                )
            ],
        )
    else:
        return ToolResponse(
            content=[
                TextBlock(
                    type="text",
                    text=(
                        f"Self-evolution completed with validation warnings.\n\n"
                        f"Agent output:\n{acp_text}\n\n"
                        f"Validation results:\n"
                        + "\n".join(f"  {r}" for r in validation_results)
                        + f"\n\nPre-evolution checkpoint: {checkpoint_hash}\n"
                        f"Rollback was NOT performed (rollback_on_failure=False).\n"
                        f"To manually rollback: git reset --hard {checkpoint_hash}"
                    ),
                )
            ],
        )


def self_evolve_status() -> ToolResponse:
    """Check the status of the self-evolution system.

    Returns:
        `ToolResponse`: Status of ACP agents, git state, and evolution daemon.
    """
    results = []

    project_root = _find_project_root()
    if project_root:
        results.append(f"Project root: {project_root}")

        try:
            result = subprocess.run(
                ["git", "status", "--short"],
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                changed = result.stdout.strip()
                if changed:
                    lines = changed.split("\n")
                    results.append(f"Git: {len(lines)} uncommitted change(s)")
                else:
                    results.append("Git: clean working tree")
        except Exception as _git_err:
            logger.debug("Git status check failed: %s", _git_err)
            results.append("Git: unable to check status")
    else:
        results.append("Project root: NOT FOUND")

    try:
        req = urllib.request.Request(
            f"{EVOLUTION_DAEMON_URL}/api/health", method="GET",
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read())
            if data.get("status") == "healthy":
                results.append("Evolution daemon: running")
            else:
                results.append(f"Evolution daemon: {data.get('status', 'unknown')}")
    except Exception as _daemon_err:
        logger.debug("Evolution daemon health check failed: %s", _daemon_err)
        results.append("Evolution daemon: not running")

    try:
        from xingzierai.agents.tools.acp_tools import _get_acp_service

        service = _get_acp_service()
        agent_list = []
        for name, cfg in service.config.agents.items():
            agent_list.append(
                f"  {name}: {'enabled' if cfg.enabled else 'disabled'}"
            )
        results.append("ACP agents:\n" + "\n".join(agent_list))
    except Exception as e:
        results.append(f"ACP service: not available ({e})")

    return ToolResponse(
        content=[TextBlock(type="text", text="\n".join(results))],
    )
