# -*- coding: utf-8 -*-
"""XINGZIER AI Agents Tools Package.

This package provides both legacy function-based tools and the new
standardized BaseTool system. Both interfaces are fully supported
for backward compatibility and gradual migration.

LEGACY INTERFACE (function-based, backward compatible):
    from xingzierai.agents.tools import execute_shell_command, read_file

NEW INTERFACE (BaseTool-based, recommended for new code):
    from xingzierai.agents.tools.new_tools import (
        BashTool,
        FileReadTool,
        init_tools,
        get_global_registry,
    )

INTEGRATION (use both seamlessly):
    from xingzierai.agents.tools.compatibility import (
        create_hybrid_toolkit,
        register_base_tools_with_toolkit,
    )
"""

# =============================================================================
# LEGACY TOOLS (Backward Compatible - Keep These Imports)
# =============================================================================

from xingzierai.agentscope_core.tool import (
    execute_python_code,
    view_text_file,
    write_text_file,
)

from .file_io import (
    read_file,
    write_file,
    edit_file,
    append_file,
)
from .file_search import (
    grep_search,
    glob_search,
)
from .shell import execute_shell_command
from .send_file import send_file_to_user
from .browser_control import browser_use
from .desktop_screenshot import desktop_screenshot
from .view_image import view_image
from .memory_search import create_memory_search_tool
from .mdrm_search import create_mdrm_search_tool
from .get_current_time import get_current_time, set_user_timezone
from .get_token_usage import get_token_usage


# =============================================================================
# NEW STANDARDIZED TOOLS (BaseTool System)
# =============================================================================

try:
    # Import new tool system (may fail if not installed/configured)
    from ...tools import (
        BaseTool as NewBaseTool,
        ToolRegistry as NewToolRegistry,
        PermissionEngine,
        ToolCapability,
        ToolPermissionResult,

        BashTool,
        FileReadTool,
        FileWriteTool,
        FileEditTool,
        FileAppendTool,
        GlobTool,
        GrepTool,

        init_tools,
        reset_tools,
        get_tool,
        list_available_tools,
        get_tool_count,
        get_global_registry,
        reset_global_registry,

        configure_safe_mode,
        configure_full_access,
        configure_developer_mode,
    )

    from ...tools.compatibility import (
        ToolAdapter,
        create_legacy_wrapper,
        register_base_tools_with_toolkit,
        create_hybrid_toolkit,
        validate_integration,
        MigrationHelper,
    )

    NEW_TOOLS_AVAILABLE = True

except ImportError as e:
    # New tools not available - that's okay, legacy tools still work
    NEW_TOOLS_AVAILABLE = False
    import logging
    logging.getLogger(__name__).warning(
        f"New standardized tools not available: {e}. "
        f"Using legacy tools only."
    )


# =============================================================================
# CONVENIENCE ALIASES (Unified Access)
# =============================================================================

def get_new_tool_system_status() -> dict:
    """Check if new BaseTool system is available and configured.

    Returns:
        Dict with availability status and info.
    """
    if not NEW_TOOLS_AVAILABLE:
        return {
            "available": False,
            "reason": "Import failed",
            "recommendation": "Use legacy tools or install new tool system",
        }

    try:
        registry = get_global_registry()
        return {
            "available": True,
            "tool_count": len(registry),
            "tools": list_available_tools(),
            "migration_ready": True,
        }
    except Exception as e:
        return {
            "available": True,
            "error": str(e),
            "migration_ready": False,
        }


def create_unified_toolkit(
    mode: str = "full",
    include_legacy: bool = True,
) -> 'Toolkit':
    """Create a unified toolkit with both new and legacy tools.

    This is the recommended way to get a fully-populated toolkit
    that works with XingzierAIAgent.

    Args:
        mode: Mode for new tools ('default', 'safe', 'full', 'minimal').
        include_legacy: Whether to include old-style tools too.

    Returns:
        A Toolkit instance ready to use.

    Example:
        ```python
        from xingzierai.agents.tools import create_unified_toolkit

        toolkit = create_unified_toolkit(mode="full")
        agent = XingzierAIAgent(config, toolkit=toolkit)
        ```
    """
    if NEW_TOOLS_AVAILABLE:
        return create_hybrid_toolkit(mode=mode, include_legacy=include_legacy)
    else:
        # Fallback to legacy-only toolkit
        from xingzierai.agentscope_core.tool import Toolkit
        toolkit = Toolkit()

        if include_legacy:
            legacy_funcs = [
                execute_shell_command,
                read_file,
                write_file,
                edit_file,
                grep_search,
                glob_search,
                browser_use,
                desktop_screenshot,
                view_image,
                send_file_to_user,
                get_current_time,
                get_token_usage,
            ]

            for func in legacy_funcs:
                try:
                    toolkit.register_tool_function(func)
                except Exception:
                    pass

        return toolkit


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Legacy tools (always available)
    "execute_python_code",
    "execute_shell_command",
    "view_text_file",
    "write_text_file",
    "read_file",
    "write_file",
    "edit_file",
    "append_file",
    "grep_search",
    "glob_search",
    "send_file_to_user",
    "desktop_screenshot",
    "view_image",
    "browser_use",
    "create_memory_search_tool",
    "create_mdrm_search_tool",
    "get_current_time",
    "set_user_timezone",
    "get_token_usage",

    # Unified access
    "create_unified_toolkit",
    "get_new_tool_system_status",
    "NEW_TOOLS_AVAILABLE",
]

# Conditionally export new tools if available
if NEW_TOOLS_AVAILABLE:
    __all__.extend([
        # Core classes
        "BaseTool",
        "NewBaseTool",
        "ToolRegistry",
        "NewToolRegistry",
        "PermissionEngine",
        "ToolCapability",
        "ToolPermissionResult",

        # Concrete tools
        "BashTool",
        "FileReadTool",
        "FileWriteTool",
        "FileEditTool",
        "FileAppendTool",
        "GlobTool",
        "GrepTool",

        # Initialization
        "init_tools",
        "reset_tools",
        "get_tool",
        "list_available_tools",
        "get_tool_count",
        "get_global_registry",
        "reset_global_registry",

        # Configuration
        "configure_safe_mode",
        "configure_full_access",
        "configure_developer_mode",

        # Compatibility layer
        "ToolAdapter",
        "create_legacy_wrapper",
        "register_base_tools_with_toolkit",
        "create_hybrid_toolkit",
        "validate_integration",
        "MigrationHelper",
    ])
