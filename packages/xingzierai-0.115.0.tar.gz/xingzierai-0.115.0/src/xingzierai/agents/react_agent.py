# -*- coding: utf-8 -*-
"""XINGZIER AI Agent - Main agent implementation.

This module provides the main XingzierAIAgent class built on ReActAgent,
with integrated tools, skills, and memory management.
"""

import asyncio
import logging
import os
from pathlib import Path
from typing import Any, AsyncGenerator, List, Literal, Optional, Type, TYPE_CHECKING

from xingzierai.agentscope_core.agent import ReActAgent
from xingzierai.agentscope_core.mcp import HttpStatefulClient, StdIOStatefulClient
from xingzierai.agentscope_core.memory import InMemoryMemory
from xingzierai.agentscope_core.message import Msg, TextBlock
from xingzierai.agentscope_core.tool import Toolkit
from anyio import ClosedResourceError
from pydantic import BaseModel

from .command_handler import CommandHandler
from .hooks import BootstrapHook, MemoryCompactionHook, MDRMMemoryHook
from .hooks.failure_learning_hook import FailureLearningHook
from .model_factory import create_model_and_formatter
from .evolution import (
    CodeEvolutionEngine,
    AutonomousWorkerMixin,
    LocalFallbackMixin,
)
from .prompt import (
    build_multimodal_hint,
    build_system_prompt_from_working_dir,
    get_active_model_supports_multimodal,
)
from .skills_manager import (
    ensure_skills_initialized,
    get_working_skills_dir,
    list_available_skills,
)
from .tool_guard_mixin import ToolGuardMixin
from .tools import (
    browser_use,
    desktop_screenshot,
    edit_file,
    execute_shell_command,
    get_current_time,
    get_token_usage,
    glob_search,
    grep_search,
    read_file,
    send_file_to_user,
    set_user_timezone,
    view_image,
    write_file,
    create_memory_search_tool,
    create_mdrm_search_tool,
)
from .tools.evolution_tools import request_evolution, check_evolution_status
from .tools.train_model import train_model
from .tools.enterprise_tools import enterprise_tools
from .tools.acp_tools import delegate_external_agent, acp_resume, acp_list_agents
from .tools.self_evolve import self_evolve, self_evolve_status
from .utils import process_file_and_media_blocks_in_message

from ..constant import (
    WORKING_DIR,
)
from ..agents.memory import MemoryManager

if TYPE_CHECKING:
    from ..config.config import AgentProfileConfig

logger = logging.getLogger(__name__)

_jieba_available = False
try:
    import jieba
    _jieba_available = True
except ImportError:
    pass


def _tokenize(text: str) -> list:
    if not text:
        return []
    if _jieba_available:
        return [t for t in jieba.cut(text) if t.strip()]
    return text.split()

# Valid namesake strategies for tool registration
NamesakeStrategy = Literal["override", "skip", "raise", "rename"]

_AUTO_CONTINUE_MAX_EXTRA = int(os.getenv("XINGZIERAI_AUTO_CONTINUE_MAX", "2"))
_AUTO_CONTINUE_TAIL_CHARS = 600

_AUTO_CONTINUE_HINT_ZH = (
    "<system-hint>"
    "上轮助手仅输出文字、未调用任何工具。请结合上下文与 <previous-assistant-tail> "
    "（若有）在本轮推理中判断：如果用户任务仍需执行工具操作，请立即调用工具；"
    "如果任务已完全完成，请给出简短总结收尾。需要实际操作时不要只输出计划或代码块。"
    "</system-hint>"
)
_AUTO_CONTINUE_HINT_EN = (
    "<system-hint>"
    "Your previous assistant turn had text only (no tool calls). "
    "Use the trailing excerpt in <previous-assistant-tail> (if present) "
    "plus the conversation to decide in this **reasoning** step: if the "
    "user's task still needs tools, emit tool_use now; if it is fully "
    "done, reply with a short text only (no tools). "
    "Do not stop with plans or code fences alone when tools are still "
    "needed."
    "</system-hint>"
)


class RAPPlanner:
    """Reasoning via Planning: predict-before-act.

    Uses LLM to predict the outcome of an action before executing it,
    enabling the agent to avoid dangerous or counterproductive actions.
    """

    def __init__(self, llm_model=None):
        self._llm = llm_model

    def set_llm(self, model) -> None:
        self._llm = model

    async def predict_outcome(self, state: str, action: str) -> str:
        if not self._llm:
            return "unknown"
        prompt = (
            f"Given current state:\n{state[:500]}\n\n"
            f"If I execute action: {action[:200]}\n\n"
            f"Predict the most likely outcome in 1-2 sentences."
        )
        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(None, lambda: self._llm(prompt))
            return response.text if hasattr(response, "text") else str(response)
        except Exception as e:
            logger.debug("RAP prediction failed: %s", e)
            return "unknown"

    async def should_execute(self, state: str, action: str) -> tuple:
        predicted = await self.predict_outcome(state, action)
        danger_keywords = ["delete", "destroy", "irreversible", "permanent", "不可逆", "删除", "销毁"]
        is_dangerous = any(kw in predicted.lower() for kw in danger_keywords)
        if is_dangerous:
            return False, predicted
        return True, predicted


class XingzierAIAgent(ToolGuardMixin, ReActAgent):
    """XINGZIER AI Agent with integrated tools, skills, and memory management.

    This agent extends ReActAgent with:
    - Built-in tools (shell, file operations, browser, etc.)
    - Dynamic skill loading from working directory
    - Memory management with auto-compaction
    - Bootstrap guidance for first-time setup
    - System command handling (/compact, /new, etc.)
    - Tool-guard security interception (via ToolGuardMixin)

    MRO note
    ~~~~~~~~
    ``ToolGuardMixin`` overrides ``_acting`` and ``_reasoning`` via
    Python's MRO: XingzierAIAgent → ToolGuardMixin → ReActAgent.  If you
    add a ``_acting`` or ``_reasoning`` override in this class, you
    **must** call ``super()._acting(...)`` / ``super()._reasoning(...)``
    so the guard interception remains active.
    """

    def __init__(
        self,
        agent_config: "AgentProfileConfig",
        env_context: Optional[str] = None,
        enable_memory_manager: bool = True,
        mcp_clients: Optional[List[Any]] = None,
        memory_manager: "MemoryManager | None" = None,
        request_context: Optional[dict[str, str]] = None,
        namesake_strategy: NamesakeStrategy = "skip",
        workspace_dir: Path | None = None,
    ):
        """Initialize XingzierAIAgent.

        Args:
            agent_config: Agent profile configuration containing all settings
                including running config (max_iters, max_input_length,
                memory_compact_threshold, etc.) and language setting.
            env_context: Optional environment context to prepend to
                system prompt
            enable_memory_manager: Whether to enable memory manager
            mcp_clients: Optional list of MCP clients for tool
                integration
            memory_manager: Optional memory manager instance
            request_context: Optional request context with session_id,
                user_id, channel, agent_id
            namesake_strategy: Strategy to handle namesake tool functions.
                Options: "override", "skip", "raise", "rename"
                (default: "skip")
            workspace_dir: Workspace directory for reading prompt files
                (if None, uses global WORKING_DIR)
        """
        self._agent_config = agent_config
        self._env_context = env_context
        self._request_context = dict(request_context or {})
        self._mcp_clients = mcp_clients or []
        self._namesake_strategy = namesake_strategy
        self._workspace_dir = workspace_dir

        self._cancellation_requested = False
        self._current_tool_task: Optional[asyncio.Task] = None
        self._completion_verify_count = 0

        self._harness_session = None
        self._harness = None

        # Extract configuration from agent_config
        running_config = agent_config.running
        self._language = agent_config.language

        # Initialize toolkit with built-in tools
        toolkit = self._create_toolkit(namesake_strategy=namesake_strategy)

        # Load and register skills
        self._register_skills(toolkit)

        # Build system prompt
        sys_prompt = self._build_sys_prompt()

        # Create model and formatter using factory method
        model, formatter = create_model_and_formatter(agent_id=agent_config.id)
        model_info = (
            f"{agent_config.active_model.provider_id}/"
            f"{agent_config.active_model.model}"
            if agent_config.active_model
            else "global-fallback"
        )
        logger.info(
            f"Agent '{agent_config.id}' initialized with model: "
            f"{model_info} (class: {model.__class__.__name__})",
        )
        # Initialize parent ReActAgent
        from ..agentscope_core.plan import PlanNotebook
        _plan_notebook = PlanNotebook(
            max_subtasks=10,
        )
        super().__init__(
            name="Friday",
            model=model,
            sys_prompt=sys_prompt,
            toolkit=toolkit,
            memory=InMemoryMemory(),
            formatter=formatter,
            max_iters=running_config.max_iters,
            plan_notebook=_plan_notebook,
        )

        # Setup memory manager
        self._setup_memory_manager(
            enable_memory_manager,
            memory_manager,
            namesake_strategy,
        )

        # Setup MDRM memory hook (for structured memory extraction)
        self._mdrm_hook: Optional[MDRMMemoryHook] = None

        # Setup command handler
        self.command_handler = CommandHandler(
            agent_name=self.name,
            memory=self.memory,
            memory_manager=self.memory_manager,
            enable_memory_manager=self._enable_memory_manager,
        )

        # Track active skill phase for UI display
        self._active_skill_phase: str | None = None

        # Register hooks
        self._register_hooks()

        # Setup evolution engine for self-modification
        self._setup_evolution_engine()

        # Initialize agent monitor for communication (lazy start)
        self._monitor = None
        self._monitor_config = None

    def reset_for_new_request(
        self,
        request_context: dict | None = None,
    ) -> None:
        self._cancellation_requested = False
        self._current_tool_task = None
        self._active_skill_phase = None
        self._harness_session = None
        self._harness = None
        if request_context is not None:
            self._request_context = dict(request_context)

    def _create_toolkit(
        self,
        namesake_strategy: NamesakeStrategy = "skip",
    ) -> Toolkit:
        """Create and populate toolkit with built-in tools.

        Args:
            namesake_strategy: Strategy to handle namesake tool functions.
                Options: "override", "skip", "raise", "rename"
                (default: "skip")

        Returns:
            Configured toolkit instance
        """
        toolkit = Toolkit()

        # Check which tools are enabled from agent config
        enabled_tools = {}
        try:
            if hasattr(self._agent_config, "tools") and hasattr(
                self._agent_config.tools,
                "builtin_tools",
            ):
                builtin_tools = self._agent_config.tools.builtin_tools
                enabled_tools = {
                    name: tool.enabled for name, tool in builtin_tools.items()
                }
        except Exception as e:
            logger.warning(
                f"Failed to load agent tools config: {e}, "
                "all tools will be disabled",
            )

        # Map of tool functions
        tool_functions = {
            "execute_shell_command": execute_shell_command,
            "read_file": read_file,
            "write_file": write_file,
            "edit_file": edit_file,
            "grep_search": grep_search,
            "glob_search": glob_search,
            "browser_use": browser_use,
            "desktop_screenshot": desktop_screenshot,
            "view_image": view_image,
            "send_file_to_user": send_file_to_user,
            "get_current_time": get_current_time,
            "set_user_timezone": set_user_timezone,
            "get_token_usage": get_token_usage,
            "request_evolution": request_evolution,
            "check_evolution_status": check_evolution_status,
            "train_model": train_model,
            "enterprise_tools": enterprise_tools,
            "delegate_external_agent": delegate_external_agent,
            "acp_resume": acp_resume,
            "acp_list_agents": acp_list_agents,
            "self_evolve": self_evolve,
            "self_evolve_status": self_evolve_status,
        }

        multimodal = get_active_model_supports_multimodal()

        # Register only enabled tools
        for tool_name, tool_func in tool_functions.items():
            # If tool not in config, enable by default (backward compatibility)
            if not enabled_tools.get(tool_name, True):
                logger.debug("Skipped disabled tool: %s", tool_name)
                continue

            if tool_name == "view_image" and not multimodal:
                logger.debug(
                    "Skipped view_image — model does not support multimodal",
                )
                continue

            toolkit.register_tool_function(
                tool_func,
                namesake_strategy=namesake_strategy,
            )
            logger.debug("Registered tool: %s", tool_name)

        return toolkit

    def _register_skills(self, toolkit: Toolkit) -> None:
        """Load and register skills from workspace directory.

        Args:
            toolkit: Toolkit to register skills to
        """
        workspace_dir = self._workspace_dir or WORKING_DIR

        # Check skills initialization
        ensure_skills_initialized(workspace_dir)

        working_skills_dir = get_working_skills_dir(workspace_dir)
        available_skills = list_available_skills(workspace_dir)

        for skill_name in available_skills:
            skill_dir = working_skills_dir / skill_name
            if skill_dir.exists():
                try:
                    toolkit.register_agent_skill(str(skill_dir))
                    logger.debug("Registered skill: %s", skill_name)
                except Exception as e:
                    logger.error(
                        "Failed to register skill '%s': %s",
                        skill_name,
                        e,
                    )

    def _build_sys_prompt(self) -> str:
        """Build system prompt from working dir files and env context.

        Returns:
            Complete system prompt string
        """
        # Get agent_id from request_context
        agent_id = (
            self._request_context.get("agent_id")
            if self._request_context
            else None
        )

        # Check if heartbeat is enabled in agent config
        heartbeat_enabled = False
        if (
            hasattr(self._agent_config, "heartbeat")
            and self._agent_config.heartbeat is not None
        ):
            heartbeat_enabled = self._agent_config.heartbeat.enabled

        sys_prompt = build_system_prompt_from_working_dir(
            working_dir=self._workspace_dir,
            agent_id=agent_id,
            heartbeat_enabled=heartbeat_enabled,
        )
        logger.debug("System prompt:\n%s", sys_prompt)

        # Inject multimodal capability awareness
        multimodal_hint = build_multimodal_hint()
        if multimodal_hint:
            sys_prompt = sys_prompt + "\n\n" + multimodal_hint

        if self._env_context is not None:
            sys_prompt = sys_prompt + "\n\n" + self._env_context

        sys_prompt += (

            "\n\n【因果预演原则】Before executing any tool, ask yourself:"
            "\n1. What will happen if this tool call succeeds?"
            "\n2. What will happen if it fails?"
            "\n3. Are there any irreversible side effects?"
            "\nOnly proceed if the predicted outcome is desirable and safe."
        )

        return sys_prompt

    def _setup_memory_manager(
        self,
        enable_memory_manager: bool,
        memory_manager: MemoryManager | None,
        namesake_strategy: NamesakeStrategy,
    ) -> None:
        """Setup memory manager and register memory search tool if enabled.

        Args:
            enable_memory_manager: Whether to enable memory manager
            memory_manager: Optional memory manager instance
            namesake_strategy: Strategy to handle namesake tool functions
        """
        # Check env var: if ENABLE_MEMORY_MANAGER=false, disable memory manager
        env_enable_mm = os.getenv("ENABLE_MEMORY_MANAGER", "")
        if env_enable_mm.lower() == "false":
            enable_memory_manager = False

        self._enable_memory_manager: bool = enable_memory_manager
        self.memory_manager = memory_manager

        # Register memory_search tool if enabled and available
        if self._enable_memory_manager and self.memory_manager is not None:
            # update memory manager (only if reme is available)
            in_memory = self.memory_manager.get_in_memory_memory()
            if in_memory is not None:
                self.memory = in_memory
            self.memory_manager.chat_model = self.model
            self.memory_manager.formatter = self.formatter

            # Register memory_search as a tool function
            self.toolkit.register_tool_function(
                create_memory_search_tool(self.memory_manager),
                namesake_strategy=namesake_strategy,
            )
            logger.debug("Registered memory_search tool")

    def _register_hooks(self) -> None:
        """Register pre-reasoning and pre-acting hooks."""
        # Bootstrap hook - checks BOOTSTRAP.md on first interaction
        # Use workspace_dir if available, else fallback to WORKING_DIR
        working_dir = (
            self._workspace_dir if self._workspace_dir else WORKING_DIR
        )
        bootstrap_hook = BootstrapHook(
            working_dir=working_dir,
            language=self._language,
        )
        self.register_instance_hook(
            hook_type="pre_reasoning",
            hook_name="bootstrap_hook",
            hook=bootstrap_hook.__call__,
        )
        logger.debug("Registered bootstrap hook")

        # Memory compaction hook - auto-compact when context is full
        if self._enable_memory_manager and self.memory_manager is not None:
            memory_compact_hook = MemoryCompactionHook(
                memory_manager=self.memory_manager,
            )
            self.register_instance_hook(
                hook_type="pre_reasoning",
                hook_name="memory_compact_hook",
                hook=memory_compact_hook.__call__,
            )
            logger.debug("Registered memory compaction hook")

        # MDRM memory hook - auto-extract structured memories from conversations
        try:
            agent_id = self._agent_config.id if self._agent_config else "default"
            self._mdrm_hook = MDRMMemoryHook(
                agent_id=agent_id,
                min_importance=6,
                max_memories_per_turn=2,
            )
            self.register_instance_hook(
                hook_type="post_reasoning",
                hook_name="mdrm_memory_hook",
                hook=self._mdrm_hook.__call__,
            )
            # Register MDRM search tool
            self.toolkit.register_tool_function(
                create_mdrm_search_tool(self._mdrm_hook),
                namesake_strategy=self._namesake_strategy,
            )
            logger.info("Registered MDRM memory hook and search tool for agent: %s", agent_id)
        except Exception as e:
            logger.warning("Failed to register MDRM memory hook: %s", e)

        # Cross-session memory recall hook - pre-reasoning memory injection
        try:
            from .hooks.cross_session_recall_hook import CrossSessionRecallHook
            self._cross_session_recall_hook = CrossSessionRecallHook(
                max_entries=3,
                max_mdrm_results=2,
            )
            logger.debug("Registered cross-session recall hook")
        except Exception as e:
            logger.warning("Failed to register cross-session recall hook: %s", e)
            self._cross_session_recall_hook = None

        # Cross-session memory write hook - post-reasoning memory persistence
        try:
            from .hooks.cross_session_write_hook import CrossSessionWriteHook
            self._cross_session_write_hook = CrossSessionWriteHook(
                importance=0.5,
            )
            logger.debug("Registered cross-session write hook")
        except Exception as e:
            logger.warning("Failed to register cross-session write hook: %s", e)
            self._cross_session_write_hook = None

        # Outcomes evaluation hook - post-reasoning self-assessment
        try:
            from .hooks.outcomes_eval_hook import OutcomesEvalHook
            self._outcomes_eval_hook = OutcomesEvalHook()
            logger.debug("Registered outcomes eval hook")
        except Exception as e:
            logger.warning("Failed to register outcomes eval hook: %s", e)
            self._outcomes_eval_hook = None

        # Failure learning hook - auto-trigger Kappa reflection on tool failures
        try:
            self._failure_learning_hook = FailureLearningHook()
            self.register_instance_hook(
                hook_type="post_acting",
                hook_name="failure_learning_hook",
                hook=self._failure_learning_hook.__call__,
            )
            logger.debug("Registered failure learning hook")
        except Exception as e:
            logger.warning("Failed to register failure learning hook: %s", e)
            self._failure_learning_hook = None

        # Tool result pruning hook - immediately truncate large tool outputs
        try:
            from .hooks.tool_result_pruning import ToolResultPruningHook
            self._tool_result_pruning_hook = ToolResultPruningHook()
            self.register_instance_hook(
                hook_type="post_acting",
                hook_name="tool_result_pruning_hook",
                hook=self._tool_result_pruning_hook.__call__,
            )
            logger.debug("Registered tool result pruning hook")
        except Exception as e:
            logger.warning("Failed to register tool result pruning hook: %s", e)
            self._tool_result_pruning_hook = None

    def _setup_evolution_engine(self) -> None:
        """Setup evolution engine for self-modification capabilities.

        Initializes:
        - CodeEvolutionEngine for hot-swap code updates
        - LocalFallbackMixin for local model error recovery
        - Registers evolution tools in the toolkit
        """
        workspace = self._workspace_dir or WORKING_DIR

        self._evolution_engine = CodeEvolutionEngine(
            workspace_dir=workspace,
            backup_dir="backups",
            changelog_path="docs/CHANGELOG.md",
        )
        self._local_fallback = LocalFallbackMixin(
            evolution_engine=self._evolution_engine,
        )
        logger.info("Evolution engine initialized")

    def apply_self_patch(
        self,
        file_path: str,
        new_code: str,
        description: str,
        target_module: Optional[str] = None,
    ) -> bool:
        """Apply a code patch to a file with backup and automatic rollback.

        This enables the agent to modify its own code at runtime.

        Args:
            file_path: Path to the file to patch
            new_code: New code content
            description: Human-readable description of the change
            target_module: Optional module name for importlib.reload()

        Returns:
            True if patch was applied successfully
        """
        result = self._evolution_engine.apply_patch(
            file_path,
            new_code,
            target_module,
        )

        self._evolution_engine.record_change(
            description=description,
            file_path=file_path,
            change_type="self_patch",
            metadata={
                "success": result.success,
                "reverted": result.reverted,
                "error": result.error_message,
            },
        )

        if result.success:
            logger.info(f"Self-patch applied to {file_path}: {description}")
        else:
            logger.error(
                f"Self-patch failed for {file_path}: {result.error_message}"
            )

        return result.success

    def get_evolution_status(self) -> dict:
        """Get current evolution engine status.

        Returns:
            Dict with engine status, recent changes, and backups info
        """
        return {
            "engine_status": self._evolution_engine.status.value,
            "backups": self._evolution_engine.list_backups()[:5],
        }

    def rebuild_sys_prompt(self) -> None:
        """Rebuild and replace the system prompt.

        Useful after load_session_state to ensure the prompt reflects
        the latest AGENTS.md / SOUL.md / PROFILE.md on disk.

        Updates both self._sys_prompt and the first system-role
        message stored in self.memory.content (if one exists).
        """
        self._sys_prompt = self._build_sys_prompt()

        if self.memory is None:
            return

        for msg, _marks in self.memory.content:
            if msg.role == "system":
                msg.content = self.sys_prompt
                break

    async def register_mcp_clients(
        self,
        namesake_strategy: NamesakeStrategy = "skip",
    ) -> None:
        """Register MCP clients on this agent's toolkit after construction.

        Args:
            namesake_strategy: Strategy to handle namesake tool functions.
                Options: "override", "skip", "raise", "rename"
                (default: "skip")
        """
        for i, client in enumerate(self._mcp_clients):
            client_name = getattr(client, "name", repr(client))
            try:
                await self.toolkit.register_mcp_client(
                    client,
                    namesake_strategy=namesake_strategy,
                )
            except (ClosedResourceError, asyncio.CancelledError) as error:
                if self._should_propagate_cancelled_error(error):
                    raise
                logger.warning(
                    "MCP client '%s' session interrupted while listing tools; "
                    "trying recovery",
                    client_name,
                )
                recovered_client = await self._recover_mcp_client(client)
                if recovered_client is not None:
                    self._mcp_clients[i] = recovered_client
                    try:
                        await self.toolkit.register_mcp_client(
                            recovered_client,
                            namesake_strategy=namesake_strategy,
                        )
                        continue
                    except asyncio.CancelledError as recover_error:
                        if self._should_propagate_cancelled_error(
                            recover_error,
                        ):
                            raise
                        logger.warning(
                            "MCP client '%s' registration cancelled after "
                            "recovery, skipping",
                            client_name,
                        )
                    except Exception as e:  # pylint: disable=broad-except
                        logger.warning(
                            "MCP client '%s' still unavailable after "
                            "recovery, skipping: %s",
                            client_name,
                            e,
                        )
                else:
                    logger.warning(
                        "MCP client '%s' recovery failed, skipping",
                        client_name,
                    )
            except Exception as e:  # pylint: disable=broad-except
                logger.warning(
                    "Failed to register MCP client '%s', skipping: %s",
                    client_name,
                    e,
                    exc_info=True,
                )

    async def _recover_mcp_client(self, client: Any) -> Any | None:
        """Recover MCP client from broken session and return healthy client."""
        if await self._reconnect_mcp_client(client):
            return client

        rebuilt_client = self._rebuild_mcp_client(client)
        if rebuilt_client is None:
            return None

        if await self._reconnect_mcp_client(rebuilt_client):
            return self._reuse_shared_client_reference(
                original_client=client,
                rebuilt_client=rebuilt_client,
            )

        return None

    @staticmethod
    def _reuse_shared_client_reference(
        original_client: Any,
        rebuilt_client: Any,
    ) -> Any:
        """Keep manager-shared client reference stable after rebuild."""
        original_dict = getattr(original_client, "__dict__", None)
        rebuilt_dict = getattr(rebuilt_client, "__dict__", None)
        if isinstance(original_dict, dict) and isinstance(rebuilt_dict, dict):
            original_dict.update(rebuilt_dict)
            return original_client
        return rebuilt_client

    @staticmethod
    def _should_propagate_cancelled_error(error: BaseException) -> bool:
        """Only swallow MCP-internal cancellations, not task cancellation."""
        if not isinstance(error, asyncio.CancelledError):
            return False

        task = asyncio.current_task()
        if task is None:
            return False

        cancelling = getattr(task, "cancelling", None)
        if callable(cancelling):
            return cancelling() > 0

        # Python < 3.11: Task.cancelling() is unavailable.
        # Fall back to propagating CancelledError to avoid swallowing
        # genuine task cancellations when we cannot inspect the state.
        return True

    @staticmethod
    async def _reconnect_mcp_client(
        client: Any,
        timeout: float = 60.0,
    ) -> bool:
        """Best-effort reconnect for stateful MCP clients."""
        close_fn = getattr(client, "close", None)
        if callable(close_fn):
            try:
                await close_fn()
            except asyncio.CancelledError:  # pylint: disable=try-except-raise
                raise
            except Exception:  # pylint: disable=broad-except
                pass

        connect_fn = getattr(client, "connect", None)
        if not callable(connect_fn):
            return False

        try:
            await asyncio.wait_for(connect_fn(), timeout=timeout)
            return True
        except asyncio.CancelledError:  # pylint: disable=try-except-raise
            raise
        except asyncio.TimeoutError:
            return False
        except Exception:  # pylint: disable=broad-except
            return False

    @staticmethod
    def _rebuild_mcp_client(client: Any) -> Any | None:
        """Rebuild a fresh MCP client instance from stored config metadata."""
        rebuild_info = getattr(client, "_xingzierai_rebuild_info", None)
        if not isinstance(rebuild_info, dict):
            return None

        transport = rebuild_info.get("transport")
        name = rebuild_info.get("name")

        try:
            if transport == "stdio":
                rebuilt_client = StdIOStatefulClient(
                    name=name,
                    command=rebuild_info.get("command"),
                    args=rebuild_info.get("args", []),
                    env=rebuild_info.get("env", {}),
                    cwd=rebuild_info.get("cwd"),
                )
                setattr(rebuilt_client, "_xingzierai_rebuild_info", rebuild_info)
                return rebuilt_client

            raw_headers = rebuild_info.get("headers") or {}
            headers = (
                {k: os.path.expandvars(v) for k, v in raw_headers.items()}
                if raw_headers
                else None
            )
            rebuilt_client = HttpStatefulClient(
                name=name,
                transport=transport,
                url=rebuild_info.get("url"),
                headers=headers,
            )
            setattr(rebuilt_client, "_xingzierai_rebuild_info", rebuild_info)
            return rebuilt_client
        except Exception:  # pylint: disable=broad-except
            return None

    # ------------------------------------------------------------------
    # Media-block fallback: strip unsupported media blocks (image, audio,
    # video) from memory and retry when the model rejects them.
    # ------------------------------------------------------------------

    _MEDIA_BLOCK_TYPES = {"image", "audio", "video"}

    def _proactive_strip_media_blocks(self) -> int:
        """Proactively strip media blocks from memory before model call.

        Only called when the active model does not support multimodal.
        Returns the number of blocks stripped.
        """
        return self._strip_media_blocks_from_memory()

    TOOL_TIMEOUT_SECONDS = int(os.getenv("XINGZIERAI_TOOL_TIMEOUT", "300"))
    REASONING_TIMEOUT_SECONDS = int(os.getenv("XINGZIERAI_REASONING_TIMEOUT", "600"))

    async def _acting(self, tool_call) -> dict | None:
        """Override _acting to track the current tool task for cancellation,
        add timeout protection, and record outcomes to Procedural Memory.
        """
        current_task = asyncio.current_task()
        self._current_tool_task = current_task
        tool_name = str(tool_call.get("name", ""))
        try:
            result = await asyncio.wait_for(
                super()._acting(tool_call),
                timeout=self.TOOL_TIMEOUT_SECONDS,
            )
            if result is not None:
                try:
                    from .procedural_memory import get_procedural_memory
                    pm = get_procedural_memory()
                    proc = await pm.get_or_create_for_tool(tool_name)
                    await pm.record_outcome(proc.procedure_id, success=True)
                except Exception as _pm_err:
                    logger.debug("Procedural memory record failed: %s", _pm_err)
            return result
        except asyncio.TimeoutError:
            logger.warning(
                "Tool call %s (%s) timed out after %ds",
                tool_call.get("id", "?"),
                tool_name,
                self.TOOL_TIMEOUT_SECONDS,
            )
            try:
                from .procedural_memory import get_procedural_memory
                pm = get_procedural_memory()
                proc = await pm.get_or_create_for_tool(tool_name)
                await pm.record_outcome(proc.procedure_id, success=False)
            except Exception as _pm_err2:
                logger.debug("Procedural memory record failed: %s", _pm_err2)
            from xingzierai.agentscope_core.message import Msg as _Msg
            return _Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(type="text", text=(
                    f"⏱️ 工具 `{tool_name}` 执行超时（{self.TOOL_TIMEOUT_SECONDS}秒），"
                    "已自动中断。请稍后重试或简化请求。"
                ))],
            )
        except asyncio.CancelledError:
            logger.info(
                "Tool call %s (%s) was cancelled",
                tool_call.get("id", "?"),
                tool_call.get("name", "?"),
            )
            raise
        except Exception as e:
            logger.warning(
                "Tool call %s (%s) failed: %s",
                tool_call.get("id", "?"),
                tool_call.get("name", "?"),
                e,
            )
            try:
                from .procedural_memory import get_procedural_memory
                pm = get_procedural_memory()
                proc = await pm.get_or_create_for_tool(tool_name)
                await pm.record_outcome(proc.procedure_id, success=False)
            except Exception as _pm_err3:
                logger.debug("Procedural memory record failed: %s", _pm_err3)
            raise
        finally:
            self._current_tool_task = None

    async def _reasoning(
        self,
        tool_choice: Literal["auto", "none", "required"] | None = None,
    ) -> Msg:
        """Override reasoning with proactive media filtering and cancellation check.

        1. Cancellation check: if cancellation requested, raise CancelledError
        2. Proactive layer: if the model does not support
           multimodal, strip media blocks *before* calling.
        3. Passive layer: if the model call still fails with a
           bad-request / media error, strip remaining blocks and retry.
        4. Context overflow: if context exceeds limit, use aligned
           trimming (port from QwenPaw) instead of blind deletion.

        Calls ``super()._reasoning`` to keep the ToolGuardMixin
        interception active.
        """
        if self._cancellation_requested:
            logger.info("Reasoning cancelled by user")
            raise asyncio.CancelledError("Reasoning cancelled")
        
        _active_model_key = self._get_active_model_key() if hasattr(self, '_get_active_model_key') else None
        _cached_rejects_media = False
        if _active_model_key:
            try:
                from ..providers.model_capability_cache import get_capability_cache
                cache = get_capability_cache()
                _cached_rejects_media = cache.get(_active_model_key, "rejects_media", False)
            except Exception as _cache_err:
                logger.debug("Capability cache lookup failed: %s", _cache_err)
            if _cached_rejects_media or not get_active_model_supports_multimodal():
                n = self._proactive_strip_media_blocks()
                if n > 0:
                    logger.warning(
                        "Proactively stripped %d media block(s) - "
                        "model does not support multimodal (cached=%s).",
                        n,
                        _cached_rejects_media,
                    )

        try:
            result = await asyncio.wait_for(
                super()._reasoning(tool_choice=tool_choice),
                timeout=self.REASONING_TIMEOUT_SECONDS,
            )
            return await self._auto_continue_if_text_only(result, tool_choice)
        except asyncio.TimeoutError:
            logger.warning(
                "Reasoning timed out after %ds",
                self.REASONING_TIMEOUT_SECONDS,
            )
            return Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(type="text", text=(
                    f"⏱️ 模型推理超时（{self.REASONING_TIMEOUT_SECONDS}秒），"
                    "已自动中断。请缩短输入或稍后重试。\n\n"
                    f"⏱️ Model reasoning timed out ({self.REASONING_TIMEOUT_SECONDS}s). "
                    "Please shorten input or retry later."
                ))],
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            error_str = str(e).lower()
            is_auth_error = (
                '401' in error_str or
                'unauthorized' in error_str or
                'invalid api key' in error_str or
                'authenticationerror' in error_str or
                'autherror' in error_str
            )
            if is_auth_error:
                logger.warning("react_agent: 401认证错误，尝试免费模型降级")
                try:
                    from ..app.audit_logger import AuditLogger, AuditEventType
                    audit = AuditLogger.get_instance()
                    if audit:
                        audit.log_event(
                            event_type=AuditEventType.LLM_401_FALLBACK,
                            action="401_auth_fallback",
                            details={"error": str(e)[:200]},
                            status="attempt",
                        )
                except Exception as _audit_err:
                    logger.debug("Audit log failed during 401 fallback: %s", _audit_err)
                free_result = await self._try_free_model_fallback()
                if free_result:
                    return free_result
                raise

            from ..smart_llm_client import LLMError
            if isinstance(e, LLMError):
                return self._make_llm_error_msg(e)
            if self._is_context_window_exceeded(e) or self._is_timeout_with_large_context(e, len(self.memory.content)):
                max_attempts = self.MAX_EMERGENCY_TRIM_ATTEMPTS
                for _attempt in range(max_attempts):
                    n_trimmed = await self._emergency_context_trimming(
                        attempt=_attempt,
                    )
                    if n_trimmed == 0:
                        break
                    logger.warning(
                        "Context issue (%s: %s). "
                        "Emergency trimmed %d message(s), "
                        "retrying (attempt %d/%d).",
                        type(e).__name__,
                        str(e)[:100],
                        n_trimmed,
                        _attempt + 1,
                        max_attempts,
                    )
                    try:
                        retry_result = await super()._reasoning(
                            tool_choice=tool_choice,
                        )
                        return await self._auto_continue_if_text_only(retry_result, tool_choice)
                    except Exception as retry_exc:
                        if not self._is_context_window_exceeded(retry_exc) and not self._is_timeout_with_large_context(retry_exc, len(self.memory.content)):
                            raise
                        e = retry_exc
                        continue
                logger.error(
                    "Context window still exceeded after %d trimming "
                    "attempts: %s. Sending user-friendly error instead of crashing.",
                    max_attempts,
                    e,
                )
                await self._send_context_overflow_message()
                return Msg(
                    name=self.name,
                    role="assistant",
                    content=[TextBlock(type="text", text=(
                        "⚠️ **上下文已超出模型限制**\n\n"
                        "当前对话的上下文长度已超过模型支持的最大范围，无法继续推理。\n\n"
                        "**建议操作：**\n"
                        "1. 输入 `/clear` 清除当前上下文后继续\n"
                        "2. 输入 `/new` 开启新会话\n"
                        "3. 缩短当前对话内容后重试\n\n"
                        "---\n"
                        "⚠️ **Context exceeds model limit**\n\n"
                        "The conversation context has exceeded the model's maximum capacity.\n\n"
                        "**Suggested actions:**\n"
                        "1. Type `/clear` to reset context and continue\n"
                        "2. Type `/new` to start a new session\n"
                        "3. Shorten the conversation and retry"
                    ))],
                )

            if not self._is_bad_request_or_media_error(e):
                raise

            n_stripped = self._strip_media_blocks_from_memory()
            if n_stripped == 0:
                raise

            if get_active_model_supports_multimodal():
                logger.warning(
                    "Model marked multimodal but "
                    "rejected media. "
                    "Capability flag may be wrong.",
                )

            logger.warning(
                "_reasoning failed (%s). "
                "Stripped %d media block(s) from memory, retrying.",
                e,
                n_stripped,
            )
            media_result = await super()._reasoning(tool_choice=tool_choice)
            return await self._auto_continue_if_text_only(media_result, tool_choice)

    def _auto_continue_system_hint(self) -> str:
        raw_lang = getattr(self, '_agent_language', None) or ""
        lang = raw_lang.strip().lower()
        if lang == "zh":
            return _AUTO_CONTINUE_HINT_ZH
        return _AUTO_CONTINUE_HINT_EN

    @staticmethod
    def _auto_continue_tail_context(msg: Msg, max_chars: int) -> str:
        if msg is None:
            return ""
        raw = getattr(msg, 'get_text_content', None)
        text = raw() if callable(raw) else (getattr(msg, 'content', '') or "")
        if isinstance(text, list):
            text_parts = []
            for b in text:
                if isinstance(b, dict) and b.get("type") == "text":
                    text_parts.append(b.get("text", ""))
                elif isinstance(b, str):
                    text_parts.append(b)
            text = "".join(text_parts)
        text = (text or "").strip()
        if not text or len(text) <= max_chars:
            return text
        return text[-max_chars:].lstrip()

    async def _auto_continue_if_text_only(
        self,
        msg: Msg,
        tool_choice: Literal["auto", "none", "required"] | None = None,
    ) -> Msg:
        if msg is None:
            return msg
        running_cfg = getattr(self, '_agent_config', None)
        if running_cfg is not None:
            running = getattr(running_cfg, 'running', None)
            if running is not None and not getattr(running, 'auto_continue_on_text_only', True):
                return msg
        has_tool_use = False
        content = msg.content
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    has_tool_use = True
                    break
                if hasattr(block, 'type') and getattr(block, 'type') == "tool_use":
                    has_tool_use = True
                    break
        if has_tool_use:
            return msg

        raw_text = ""
        if isinstance(content, list):
            for b in content:
                if isinstance(b, dict) and b.get("type") == "text":
                    raw_text += b.get("text", "")
                elif isinstance(b, str):
                    raw_text += b
        elif isinstance(content, str):
            raw_text = content
        text_len = len(raw_text.strip())

        if text_len >= 200:
            return msg

        iteration = getattr(self, '_current_iteration', 0)
        max_iters = getattr(self, '_max_iterations', 10)
        if iteration >= max_iters - 1:
            return msg

        has_pending_tools = False
        try:
            mem = getattr(self, 'memory', None)
            if mem is not None:
                msgs_list = getattr(mem, '_messages', []) or []
                for m in reversed(msgs_list[-6:]):
                    m_content = getattr(m, 'content', None)
                    if isinstance(m_content, list):
                        for block in m_content:
                            if isinstance(block, dict) and block.get("type") == "tool_use":
                                has_pending_tools = True
                                break
                    if has_pending_tools:
                        break
        except Exception as _auto_cont_err:
            logger.debug("Auto-continue check failed: %s", _auto_cont_err)

        if not has_pending_tools and text_len > 0:
            logger.info(
                "Auto-continue: skipping (no pending tool_use in recent "
                "context, text-only response is likely intentional, %d chars)",
                text_len,
            )
            return msg

        best_msg = msg
        best_len = text_len
        extra = 0
        while extra < _AUTO_CONTINUE_MAX_EXTRA:
            extra += 1
            tail = self._auto_continue_tail_context(best_msg, _AUTO_CONTINUE_TAIL_CHARS)
            hint_body = self._auto_continue_system_hint()
            if tail:
                hint_body += (
                    "\n\n<previous-assistant-tail>\n"
                    f"{tail}\n"
                    "</previous-assistant-tail>"
                )
            logger.info(
                "Auto-continue: text-only response (%d/%d, %d chars); "
                "injecting hint for extra _reasoning",
                extra,
                _AUTO_CONTINUE_MAX_EXTRA,
                best_len,
            )
            hint_msg = Msg("user", hint_body, "user")
            try:
                await self.memory.add(hint_msg)
            except Exception as _hint_add_err:
                logger.debug("Failed to add hint message to memory: %s", _hint_add_err)
            try:
                next_msg = await super()._reasoning(tool_choice=tool_choice)
            except Exception as exc:
                logger.warning(
                    "Auto-continue extra _reasoning#%d failed: %s; "
                    "keeping prior response",
                    extra,
                    exc,
                )
                break
            next_has_tool = False
            next_content = next_msg.content if next_msg else None
            if isinstance(next_content, list):
                for block in next_content:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        next_has_tool = True
                        break
                    if hasattr(block, 'type') and getattr(block, 'type') == "tool_use":
                        next_has_tool = True
                        break
            if next_has_tool:
                logger.info(
                    "Auto-continue#%d: model emitted tool_use, accepting",
                    extra,
                )
                return next_msg
            next_text = ""
            if isinstance(next_content, list):
                for b in next_content:
                    if isinstance(b, dict) and b.get("type") == "text":
                        next_text += b.get("text", "")
                    elif isinstance(b, str):
                        next_text += b
            elif isinstance(next_content, str):
                next_text = next_content
            next_len = len(next_text.strip())
            if next_len > best_len:
                best_msg = next_msg
                best_len = next_len
            logger.info(
                "Auto-continue#%d: still text-only (%d chars vs best %d); "
                "stopping to avoid degradation",
                extra,
                next_len,
                best_len,
            )
            break

        return best_msg

    def request_cancellation(self) -> None:
        """Request cancellation of the current task.
        
        This method:
        1. Sets the cancellation flag
        2. Cancels the current tool task if any
        
        Call this method when user clicks the stop button.
        """
        logger.info("Cancellation requested for agent %s", self.name)
        self._cancellation_requested = True
        
        # Cancel current tool execution if any
        if self._current_tool_task and not self._current_tool_task.done():
            self._current_tool_task.cancel()
            logger.info("Cancelled current tool task")
    
    def is_cancelled(self) -> bool:
        """Check if cancellation has been requested."""
        return self._cancellation_requested
    
    def reset_cancellation(self) -> None:
        """Reset the cancellation flag for reuse."""
        self._cancellation_requested = False

    async def _summarizing(self) -> Msg:
        """Override summarizing with proactive media filtering,
        passive fallback, and tool_use block filtering.

        1. Proactive layer: if the model does not support multimodal,
           strip media blocks *before* calling the model.
        2. Passive layer: if the model call still fails with a
           bad-request / media error, strip remaining blocks and retry.
        3. If the model IS marked as multimodal but still errors on
           media, log a warning about possibly inaccurate capability flag.

        Some models (e.g. kimi-k2.5) generate tool_use blocks even when
        no tools are provided.  We set ``_in_summarizing`` so that
        ``print`` can strip tool_use blocks from streaming chunks.
        """
        self._reached_max_iters = True
        # --- Proactive filtering layer ---
        if not get_active_model_supports_multimodal():
            n = self._proactive_strip_media_blocks()
            if n > 0:
                logger.warning(
                    "Proactively stripped %d media block(s) - "
                    "model does not support multimodal.",
                    n,
                )

        # --- Passive fallback layer ---
        self._in_summarizing = True
        summarizing_msg = None
        try:
            try:
                summarizing_msg = await super()._summarizing()
            except Exception as e:
                if self._is_context_window_exceeded(e):
                    logger.warning(
                        "_summarizing context window exceeded (%s). "
                        "Emergency trimming and retrying.",
                        e,
                    )
                    n_trimmed = await self._emergency_context_trimming()
                    if n_trimmed > 0:
                        try:
                            summarizing_msg = await super()._summarizing()
                        except Exception as _summarize_err:
                            logger.debug("Summarizing after emergency trim failed: %s", _summarize_err)
                    if summarizing_msg is None:
                        summarizing_msg = Msg(
                            name=self.name,
                            role="assistant",
                            content=[TextBlock(type="text", text=self._TASK_TERMINAL_MESSAGE)],
                        )
                elif not self._is_bad_request_or_media_error(e):
                    raise

                n_stripped = self._strip_media_blocks_from_memory()
                if n_stripped == 0:
                    raise

                if get_active_model_supports_multimodal():
                    logger.warning(
                        "Model marked multimodal but "
                        "rejected media. "
                        "Capability flag may be wrong.",
                    )

                logger.warning(
                    "_summarizing failed (%s). "
                    "Stripped %d media block(s) from memory, retrying.",
                    e,
                    n_stripped,
                )
                summarizing_msg = await super()._summarizing()
        finally:
            self._in_summarizing = False

        return self._strip_tool_use_from_msg(summarizing_msg)

    async def print(
        self,
        msg: Msg,
        last: bool = True,
        speech: Any = None,
    ) -> None:
        """Filter tool_use blocks during _summarizing before they hit the
        message queue, preventing the frontend from briefly rendering
        phantom tool calls that will never be executed.

        On the *final* streaming event (``last=True``), append the
        round-end notice so users see it immediately instead of only
        after a page refresh.  Intermediate events that become empty
        after filtering are silently skipped to avoid blank UI flashes.
        """

        if not getattr(self, "_in_summarizing", False):
            return await super().print(msg, last, speech=speech)

        original = msg.content
        modified = False

        if isinstance(original, list):
            filtered = [
                b
                for b in original
                if not (isinstance(b, dict) and b.get("type") == "tool_use")
            ]
            if not filtered and not last:
                return
            if len(filtered) != len(original) or last:
                msg.content = filtered
                if last:
                    msg.content.append(
                        {"type": "text", "text": self._ROUND_END_NOTICE},
                    )
                modified = True
        elif isinstance(original, str) and last:
            msg.content = original + self._ROUND_END_NOTICE
            modified = True
        if modified:
            try:
                return await super().print(msg, last, speech=speech)
            finally:
                msg.content = original
        return await super().print(msg, last, speech=speech)

    _ROUND_END_NOTICE = (
        "\n\n---\n"
        "本轮调用已达最大次数，回复已终止，请继续输入。\n"
        "Maximum iterations reached for this round. "
        "Please send a new message to continue."
    )

    _TASK_TERMINAL_STATUS = "max_iters_exceeded"
    _TASK_TERMINAL_MESSAGE = (
        "\n\n---\n"
        "【任务终端状态】本轮因达到最大调用次数而终止。\n"
        "当前会话的累积上下文可能导致后续轮次响应变慢，"
        "建议开启新会话继续工作。\n"
        "[Task Terminal] This round terminated due to max iterations.\n"
        "Accumulated context may slow subsequent rounds.\n"
        "Consider starting a new session to continue."
    )

    _INCOMPLETE_KEYWORDS_ZH = [
        "无法完成", "未能完成", "暂时无法", "暂时不能",
        "无法继续", "无法解决", "没有完成", "还没完成",
        "部分完成", "部分实现", "未能全部", "未能完全",
        "需要继续", "还需要", "剩余", "待完成",
        "未完成", "未实现", "还没做完",
    ]
    _INCOMPLETE_KEYWORDS_EN = [
        "i cannot complete", "unable to complete", "could not complete",
        "partially completed", "partially done", "not yet finished",
        "still need to", "remaining tasks", "unfinished",
        "incomplete", "not fully", "not all steps",
        "some tasks remain", "more work needed",
    ]
    _ABANDON_KEYWORDS_ZH = [
        "放弃", "跳过", "忽略", "不再继续",
        "无法处理", "超出范围", "不支持",
    ]
    _ABANDON_KEYWORDS_EN = [
        "i give up", "skip this", "beyond scope",
        "not supported", "cannot handle", "out of scope",
    ]
    _MAX_COMPLETION_VERIFICATIONS = 3

    async def _verify_task_completion(
        self,
        msg_reasoning: Msg,
        iteration: int = 0,
    ) -> bool:
        """Verify whether the task is truly complete before exiting.

        Uses a multi-signal approach:
        1. Keyword analysis: detect incomplete/abandon signals in the text
        2. Tool call history: check if tool calls were made in recent iterations
        3. Iteration depth: early iterations are more likely premature exits

        Returns:
            True if the task appears complete (safe to exit).
            False if the task may be incomplete (should continue).
        """
        text = (msg_reasoning.get_text_content() or "").lower()

        if not text.strip():
            return True

        abandon_detected = any(
            kw in text for kw in self._ABANDON_KEYWORDS_ZH + self._ABANDON_KEYWORDS_EN
        )
        if abandon_detected:
            logger.info(
                "[TaskCompletion] Abandon signal detected, allowing exit at iter %d",
                iteration,
            )
            return True

        incomplete_detected = any(
            kw in text for kw in self._INCOMPLETE_KEYWORDS_ZH + self._INCOMPLETE_KEYWORDS_EN
        )

        if not incomplete_detected:
            return True

        if self._completion_verify_count >= self._MAX_COMPLETION_VERIFICATIONS:
            logger.info(
                "[TaskCompletion] Max verifications (%d) reached, allowing exit",
                self._MAX_COMPLETION_VERIFICATIONS,
            )
            self._completion_verify_count = 0
            return True

        self._completion_verify_count += 1
        logger.warning(
            "[TaskCompletion] Incomplete signal detected at iter %d "
            "(verify %d/%d), forcing continuation",
            iteration,
            self._completion_verify_count,
            self._MAX_COMPLETION_VERIFICATIONS,
        )
        return False

    @staticmethod
    def _strip_tool_use_from_msg(msg: Msg) -> Msg:
        """Remove tool_use blocks from a message and append a user notice.

        When _summarizing is called without tools, some models still
        return tool_use blocks.  Those blocks can never be executed, so
        strip them and append a bilingual notice telling the user this
        round of calls has ended.
        """
        if isinstance(msg.content, str):
            msg.content += XingzierAIAgent._ROUND_END_NOTICE
            return msg

        filtered = [
            block
            for block in msg.content
            if not (
                isinstance(block, dict) and block.get("type") == "tool_use"
            )
        ]

        n_removed = len(msg.content) - len(filtered)
        if n_removed:
            logger.debug(
                "Stripped %d tool_use block(s) from _summarizing response",
                n_removed,
            )

        filtered.append({"type": "text", "text": XingzierAIAgent._ROUND_END_NOTICE})
        msg.content = filtered
        return msg

    @staticmethod
    def _is_bad_request_or_media_error(exc: Exception) -> bool:
        """Return True for 400-class or media-related model errors.

        Targets bad-request (400) errors because unsupported media
        content typically causes request validation failures.  Keyword
        matching provides an extra safety net for providers that use
        non-standard status codes.

        Note: Context window exceeded errors are explicitly excluded
        because they should be handled by _is_context_window_exceeded
        and _emergency_context_trimming, not by media stripping.
        """
        if XingzierAIAgent._is_context_window_exceeded(exc):
            return False

        status = getattr(exc, "status_code", None)
        if status == 400:
            error_str = str(exc).lower()
            context_keywords = [
                "context window exceeds",
                "context_length_exceeded",
                "maximum context length",
                "too many tokens",
                "token limit exceeded",
                "context length exceeded",
                "input is too long",
            ]
            if any(kw in error_str for kw in context_keywords):
                return False
            return True

        error_str = str(exc).lower()
        keywords = [
            "image",
            "audio",
            "video",
            "vision",
            "multimodal",
            "image_url",
        ]
        return any(kw in error_str for kw in keywords)

    def _make_llm_error_msg(self, error) -> Msg:
        """根据LLMError语义化错误码生成中文友好提示"""
        from ..smart_llm_client import LLMError
        code = getattr(error, 'code', None) if isinstance(error, LLMError) else None
        error_messages = {
            LLMError.CODE_TIMEOUT: (
                "⏱️ **模型响应超时**\n\n"
                "当前请求等待时间过长，模型未能及时响应。\n\n"
                "**建议操作：**\n"
                "1. 稍后重试\n"
                "2. 简化问题后重新提问\n"
                "3. 输入 `/new` 开启新会话\n\n"
                "---\n"
                "⏱️ **Model response timeout**\n\n"
                "The request timed out before the model could respond.\n\n"
                "**Suggested actions:**\n"
                "1. Retry later\n"
                "2. Simplify your question\n"
                "3. Type `/new` to start a new session"
            ),
            LLMError.CODE_RATE_LIMIT: (
                "🚦 **API调用频率受限**\n\n"
                "当前模型的调用次数已达到限制，请稍后再试。\n\n"
                "**建议操作：**\n"
                "1. 等待几分钟后重试\n"
                "2. 系统会自动切换到备用模型\n\n"
                "---\n"
                "🚦 **API rate limit reached**\n\n"
                "The current model's call limit has been reached. Please try again later.\n\n"
                "**Suggested actions:**\n"
                "1. Wait a few minutes and retry\n"
                "2. The system will auto-switch to a backup model"
            ),
            LLMError.CODE_NETWORK: (
                "🌐 **网络连接异常**\n\n"
                "无法连接到模型服务，请检查网络。\n\n"
                "**建议操作：**\n"
                "1. 检查网络连接\n"
                "2. 稍后重试\n\n"
                "---\n"
                "🌐 **Network connection error**\n\n"
                "Unable to connect to the model service. Please check your network.\n\n"
                "**Suggested actions:**\n"
                "1. Check network connection\n"
                "2. Retry later"
            ),
            LLMError.CODE_NO_FREE: (
                "⚠️ **免费模型暂不可用**\n\n"
                "当前没有可用的免费模型作为备选。\n\n"
                "**建议操作：**\n"
                "1. 检查API密钥是否有效\n"
                "2. 稍后重试\n\n"
                "---\n"
                "⚠️ **No free models available**\n\n"
                "There are currently no free models available as fallback.\n\n"
                "**Suggested actions:**\n"
                "1. Check if your API key is valid\n"
                "2. Retry later"
            ),
        }
        text = error_messages.get(code, (
            "❌ **模型调用失败**\n\n"
            f"错误信息：{str(error)[:200]}\n\n"
            "**建议操作：**\n"
            "1. 稍后重试\n"
            "2. 输入 `/new` 开启新会话\n\n"
            "---\n"
            "❌ **Model call failed**\n\n"
            f"Error: {str(error)[:200]}\n\n"
            "**Suggested actions:**\n"
            "1. Retry later\n"
            "2. Type `/new` to start a new session"
        ))
        return Msg(
            name=self.name,
            role="assistant",
            content=[TextBlock(type="text", text=text)],
        )

    async def _try_free_model_fallback(self) -> Optional[Msg]:
        """When paid models fail with 401, try OpenCode free models as fallback."""
        try:
            from ..smart_llm_client import SmartLLMClient
            client = SmartLLMClient._instance
            if client is None:
                return None

            last_user_msg = ""
            for msg in reversed(self.memory.content):
                if hasattr(msg, 'role') and msg.role == "user":
                    if hasattr(msg, 'content'):
                        if isinstance(msg.content, list):
                            for block in msg.content:
                                if hasattr(block, 'text'):
                                    last_user_msg = block.text
                                    break
                        elif isinstance(msg.content, str):
                            last_user_msg = msg.content
                    if last_user_msg:
                        break

            if not last_user_msg:
                return None

            result = await client.ask_free_model(last_user_msg)
            if result:
                from agentscope.message import Msg
                return Msg(
                    name=self.name,
                    role="assistant",
                    content=[TextBlock(type="text", text=(
                        result + "\n\n---\n💡 *当前使用免费模型回复（付费API密钥无效），如需使用完整功能请更新API密钥*"
                    ))],
                )
        except Exception as e:
            logger.warning(f"react_agent: 免费模型降级失败: {e}")

        return None

    @staticmethod
    def _is_context_window_exceeded(exc: Exception) -> bool:
        error_str = str(exc).lower()
        keywords = [
            "context window exceeds",
            "context_length_exceeded",
            "maximum context length",
            "too many tokens",
            "token limit exceeded",
            "context length exceeded",
            "input is too long",
        ]
        status = getattr(exc, "status_code", None)
        if status == 400 and any(kw in error_str for kw in keywords):
            return True
        return any(kw in error_str for kw in keywords)

    MIN_CONTEXT_FOR_EMERGENCY_TRIM = 20
    MAX_EMERGENCY_TRIM_ATTEMPTS = 5

    @staticmethod
    def _is_timeout_with_large_context(exc: Exception, memory_content_len: int = 0) -> bool:
        is_timeout = False
        try:
            import httpx
            timeout_types = (httpx.ReadTimeout, httpx.ReadError, httpx.ConnectError, httpx.WriteError)
            if isinstance(exc, timeout_types):
                is_timeout = True
        except ImportError:
            pass
        if not is_timeout:
            error_str = str(exc).lower()
            timeout_keywords = ["readtimeout", "read error", "readerror", "timed out", "deadline exceeded"]
            is_timeout = any(kw in error_str for kw in timeout_keywords)
        if not is_timeout:
            return False
        return memory_content_len > XingzierAIAgent.MIN_CONTEXT_FOR_EMERGENCY_TRIM

    async def _emergency_context_trimming(
        self,
        attempt: int = 0,
        override_trim_count: int | None = None,
    ) -> int:
        """Emergency context trimming with tool ID alignment.

        Ported from QwenPaw's approach: use context_check() to properly
        split messages into "to compact" and "to keep" groups, ensuring
        tool_use/tool_result ID alignment. This prevents API errors from
        unpaired tool blocks that the old blind-deletion approach caused.

        The trimmed messages are REMOVED from memory (not just marked),
        and the compressed summary is updated to preserve key information.
        """
        memory_content = self.memory.content
        if len(memory_content) <= 2:
            return 0

        messages = [msg for msg, _ in memory_content]

        skip_count = 0
        for i, (msg, _) in enumerate(memory_content):
            if getattr(msg, 'role', None) == 'system':
                skip_count = i + 1
            else:
                break

        non_system_messages = messages[skip_count:]
        if not non_system_messages:
            return 0

        if override_trim_count is not None:
            trim_count = min(override_trim_count, len(non_system_messages))
            ids_to_delete = [
                msg.id for msg in non_system_messages[:trim_count]
            ]
        else:
            from .utils import context_check

            reserve_ratio = 0.3 if attempt < 2 else 0.5
            estimated_total = sum(
                max(1, len(str(getattr(msg, 'content', ''))) // 4)
                for msg in non_system_messages
            )
            reserve_tokens = int(estimated_total * reserve_ratio)
            compact_threshold = int(estimated_total * 0.5)

            messages_to_compact, messages_to_keep, _, _ = context_check(
                messages=non_system_messages,
                context_compact_threshold=compact_threshold,
                context_compact_reserve=reserve_tokens,
            )

            if not messages_to_compact:
                return 0

            ids_to_delete = [msg.id for msg in messages_to_compact]

        if ids_to_delete:
            await self.memory.delete(ids_to_delete)
            trimmed = len(ids_to_delete)
        else:
            trimmed = 0

        if trimmed > 0:
            logger.warning(
                "Emergency context trimming: removed %d messages (aligned), "
                "%d remaining",
                trimmed,
                len(self.memory.content),
            )
            try:
                compressed_summary = self.memory.get_compressed_summary() or ""
                summary_addition = (
                    f"\n[Emergency trim: {trimmed} messages removed] "
                    f"Remaining: {len(self.memory.content)}"
                )
                await self.memory.update_compressed_summary(
                    compressed_summary + summary_addition
                )
            except Exception as summary_err:
                logger.debug("Failed to update summary after trimming: %s", summary_err)

        return trimmed

    _MEDIA_PLACEHOLDER = (
        "[Media content removed - model does not support this media type]"
    )

    async def _send_context_overflow_message(self) -> None:
        try:
            msg = Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(type="text", text="⚠️ Context overflow - emergency cleanup in progress")],
            )
            await self.print(msg)
        except Exception as _overflow_notify_err:
            logger.debug("Failed to notify context overflow: %s", _overflow_notify_err)

    def _strip_media_blocks_from_memory(self) -> int:
        """Remove media blocks (image/audio/video) from all messages.

        Also strips media blocks nested inside ToolResultBlock outputs.
        Inserts placeholder text when stripping leaves content empty to
        avoid malformed API requests.

        Returns:
            Total number of media blocks removed.
        """
        media_types = self._MEDIA_BLOCK_TYPES
        total_stripped = 0

        for msg, _marks in self.memory.content:
            if not isinstance(msg.content, list):
                continue

            new_content = []
            for block in msg.content:
                if (
                    isinstance(block, dict)
                    and block.get("type") in media_types
                ):
                    total_stripped += 1
                    continue

                if (
                    isinstance(block, dict)
                    and block.get("type") == "tool_result"
                    and isinstance(block.get("output"), list)
                ):
                    original_len = len(block["output"])
                    block["output"] = [
                        item
                        for item in block["output"]
                        if not (
                            isinstance(item, dict)
                            and item.get("type") in media_types
                        )
                    ]
                    stripped_count = original_len - len(block["output"])
                    total_stripped += stripped_count
                    if stripped_count > 0 and not block["output"]:
                        block["output"] = self._MEDIA_PLACEHOLDER

                new_content.append(block)

            if not new_content and total_stripped > 0:
                new_content.append(
                    {"type": "text", "text": self._MEDIA_PLACEHOLDER},
                )

            msg.content = new_content

        return total_stripped

    async def _track_managed_agent_event(self, query: str) -> None:
        try:
            from .managed_agent import (
                ManagedAgentOrchestrator, Session, Event, EventType,
            )
            agent_id = self._request_context.get("agent_id", "default")
            orch = ManagedAgentOrchestrator.get_instance()
            if self._harness is None or self._harness_session is None:
                self._harness = orch.create_agent(agent_id)
                self._harness_session = self._harness.session.session_id
            self._harness.session.append(Event(
                event_type=EventType.USER_INPUT,
                content={"text": (query or "")[:2000]},
                agent_id=agent_id,
            ))
        except Exception as e:
            logger.debug("ManagedAgent event append failed: %s", e)

    async def _recall_cross_session_memory(self) -> str:
        if not self._cross_session_recall_hook:
            return ""
        try:
            recall_result = await self._cross_session_recall_hook(
                self, {"msg": None}
            )
            if recall_result and "memory_context" in recall_result:
                return recall_result["memory_context"]
        except Exception as e:
            logger.debug("Cross-session recall hook failed: %s", e)
        return ""

    async def _persist_cross_session_memory(self, msg, response) -> None:
        if self._cross_session_write_hook:
            try:
                await self._cross_session_write_hook(
                    self, {"msg": msg}, output=response
                )
            except Exception as e:
                logger.debug("Cross-session write hook failed: %s", e)

    async def _evaluate_outcomes(self, msg, response) -> None:
        if self._outcomes_eval_hook:
            try:
                await self._outcomes_eval_hook(
                    self, {"msg": msg}, output=response
                )
            except Exception as e:
                logger.debug("Outcomes eval hook failed: %s", e)

    async def _generate_summary_for_tool_only_response(self, response) -> Optional[Msg]:
        try:
            summary_hint = Msg(
                "user",
                "Based on the tool execution results above, "
                "please provide a clear and concise summary to the user. "
                "Do not make any more tool calls.",
                role="user",
            )
            prompt = await self.formatter.format(
                [
                    Msg("system", self.sys_prompt, "system"),
                    *await self.memory.get_memory(),
                    summary_hint,
                ],
            )
            summary_res = await self.model(prompt)
            summary_msg = Msg(self.name, [], "assistant")
            if isinstance(summary_res, AsyncGenerator):
                async for chunk in summary_res:
                    summary_msg.content = chunk.content
                    await self.print(summary_msg, False)
            else:
                summary_msg.content = summary_res.content
            await self.print(summary_msg, True)
            await self.memory.add(summary_msg)
            logger.info("XingzierAIAgent.reply: Summary generated successfully")
            return summary_msg
        except Exception as summary_err:
            logger.warning(
                "XingzierAIAgent.reply: Summary generation failed: %s, "
                "using tool result fallback",
                summary_err,
            )
            tool_names = []
            if hasattr(response, 'content') and isinstance(response.content, list):
                for block in response.content:
                    if isinstance(block, dict) and block.get("type") == "tool_result":
                        name = block.get("name", "")
                        if name:
                            tool_names.append(name)
            if tool_names:
                fallback_text = (
                    f"已执行工具：{', '.join(tool_names)}\n\n"
                    f"Tools executed: {', '.join(tool_names)}"
                )
            else:
                fallback_text = (
                    "工具已执行完成。\n\n"
                    "Tools executed successfully."
                )
            fallback_msg = Msg(
                self.name,
                [TextBlock(type="text", text=fallback_text)],
                "assistant",
            )
            await self.print(fallback_msg, True)
            await self.memory.add(fallback_msg)
            return fallback_msg

    async def reply(
        self,
        msg: Msg | list[Msg] | None = None,
        structured_model: Type[BaseModel] | None = None,
    ) -> Msg:
        """Override reply to process file blocks and handle commands.

        Args:
            msg: Input message(s) from user
            structured_model: Optional pydantic model for structured output

        Returns:
            Response message
        """
        from ..config.context import set_current_workspace_dir

        set_current_workspace_dir(self._workspace_dir)

        last_msg = msg[-1] if isinstance(msg, list) else msg
        query = (
            last_msg.get_text_content() if isinstance(last_msg, Msg) else None
        )

        await self._track_managed_agent_event(query)

        memory_context = await self._recall_cross_session_memory()

        if msg is not None:
            await process_file_and_media_blocks_in_message(msg)

        if self.command_handler.is_command(query):
            logger.info(f"Received command: {query}")
            from .slash_commands import get_slash_command
            cmd_name = query.strip().lstrip("/").split(" ", maxsplit=1)[0]
            slash_cmd = get_slash_command(cmd_name)
            if slash_cmd:
                self._active_skill_phase = slash_cmd.phase
            else:
                self._active_skill_phase = None
            msg = await self.command_handler.handle_command(query)
            await self.print(msg)
            return msg

        logger.info("XingzierAIAgent.reply: max_iters=%s", self.max_iters)
        self._reached_max_iters = False
        self._completion_verify_count = 0

        # Auto-create a simple plan from user input
        try:
            if query and isinstance(query, str):
                # Try both public and private attribute names
                plan_nb = getattr(self, "plan_notebook", None) or getattr(self, "_plan_notebook", None)
                logger.debug(f"[Plan] Auto-plan: plan_notebook={plan_nb is not None}")
                if plan_nb is not None:
                    current = getattr(plan_nb, "current_plan", None)
                    logger.debug(f"[Plan] Auto-plan: current_plan={current is not None}")
                    if current is None:
                        from ..agentscope_core.plan import Plan, SubTask
                        q_short = query[:100].strip()
                        subtasks = [
                            SubTask(
                                name="理解需求",
                                description="分析用户请求的核心意图和约束条件",
                                expected_outcome="明确用户想要达成什么目标",
                            ),
                            SubTask(
                                name="制定方案",
                                description="根据需求制定可行的执行方案",
                                expected_outcome="产出具体可执行的步骤",
                            ),
                            SubTask(
                                name="执行任务",
                                description="按方案逐步执行，完成用户请求",
                                expected_outcome="达成用户要求的结果",
                            ),
                        ]
                        auto_plan = Plan(
                            name=f"执行：{q_short[:30]}{'...' if len(q_short) > 30 else ''}",
                            description=f"用户请求：{q_short}",
                            expected_outcome="完成用户的请求",
                            subtasks=subtasks,
                        )
                        plan_nb.current_plan = auto_plan
                        logger.info("Auto-created plan: %s with %d subtasks", auto_plan.name, len(subtasks))
        except Exception as e:
            logger.error("Auto-plan creation failed: %s", e, exc_info=True)

        original_sys_prompt = self._sys_prompt
        if memory_context:
            self._sys_prompt = original_sys_prompt + memory_context

        try:
            response = await super().reply(msg=msg, structured_model=structured_model)

            self._sys_prompt = original_sys_prompt

            logger.info(
                "XingzierAIAgent.reply: after super().reply() - "
                "text_content=%s, has_tool_use=%s, has_tool_result=%s, "
                "reached_max_iters=%s, content_type=%s",
                repr((response.get_text_content() or "")[:100]) if response else "None",
                bool(response.get_content_blocks("tool_use")) if response else False,
                bool(response.get_content_blocks("tool_result")) if response else False,
                getattr(self, "_reached_max_iters", False),
                type(response.content).__name__ if response else "None",
            )

            if getattr(self, "_reached_max_iters", False):
                if response and response.metadata is None:
                    response.metadata = {}
                if response and isinstance(response.metadata, dict):
                    response.metadata["task_terminal_status"] = (
                        XingzierAIAgent._TASK_TERMINAL_STATUS
                    )
                    response.metadata["task_terminal_message"] = (
                        XingzierAIAgent._TASK_TERMINAL_MESSAGE
                    )
                logger.warning(
                    "Max iters (%d) reached. Terminal status appended.",
                    self.max_iters,
                )

            if response and not response.get_text_content():
                has_tool_use = bool(response.get_content_blocks("tool_use"))
                has_tool_result = bool(response.get_content_blocks("tool_result"))
                has_thinking = bool(response.get_content_blocks("thinking"))
                if has_tool_use or has_tool_result:
                    logger.info(
                        "XingzierAIAgent.reply: Response has no text but has tool calls, "
                        "generating summary via LLM"
                    )
                    summary_msg = await self._generate_summary_for_tool_only_response(response)
                    if summary_msg:
                        response = summary_msg
                elif has_thinking:
                    logger.info(
                        "XingzierAIAgent.reply: Response has thinking content but no text, "
                        "this is normal for reasoning models - not treating as empty"
                    )
                else:
                    text_val = response.get_text_content()
                    content_blocks = response.get_content_blocks() if hasattr(response, 'get_content_blocks') else []
                    has_any_content = len(content_blocks) > 0 if content_blocks else False
                    if (text_val is None or (isinstance(text_val, str) and not text_val.strip())) and not has_any_content:
                        logger.warning(
                            "XingzierAIAgent.reply: Agent returned truly empty response "
                            "(no text, no content blocks, no tool calls). "
                            "Generating a fallback response."
                        )
                        response.content = [
                            TextBlock(
                                type="text",
                                text=(
                                    "⚠️ **响应异常**\n\n"
                                    "模型未能生成有效回复，请重试或换一种方式提问。\n\n"
                                    "**建议操作：**\n"
                                    "1. 重新发送你的问题\n"
                                    "2. 换一种方式描述你的需求\n"
                                    "3. 输入 `/new` 开启新会话\n\n"
                                    "---\n"
                                    "⚠️ **Empty response**\n\n"
                                    "The model failed to generate a valid reply. "
                                    "Please retry or rephrase.\n\n"
                                    "**Suggested actions:**\n"
                                    "1. Resend your question\n"
                                    "2. Rephrase your request\n"
                                    "3. Type `/new` to start a new session"
                                ),
                            )
                        ]
                        await self.print(response, True)

            await self._persist_cross_session_memory(msg, response)
            await self._evaluate_outcomes(msg, response)

            if self._monitor:
                text_content = response.get_text_content() if response else None
                response_text = text_content[:100] if text_content else "(no response)"
                self._monitor.log_activity(
                    f"Response generated: {response_text}...",
                    "response_generated",
                    {"response_length": len(text_content) if text_content else 0}
                )
                self._monitor.update_status("idle", current_task=None)
            
            return response
        except Exception as e:
            self._sys_prompt = original_sys_prompt
            if self._monitor:
                self._monitor.log_activity(
                    f"Error processing query: {str(e)}",
                    "error",
                    {"error": str(e)}
                )
                self._monitor.update_status("error", current_task=f"Error: {str(e)[:50]}")
            raise

    async def interrupt(self, msg: Msg | list[Msg] | None = None) -> None:
        """Interrupt the current reply process and wait for cleanup."""
        if self._reply_task and not self._reply_task.done():
            task = self._reply_task
            task.cancel(msg)
            try:
                await task
            except asyncio.CancelledError:
                if not task.cancelled():
                    raise
            except Exception as _cleanup_err:
                logger.warning(
                    "Exception occurred during interrupt cleanup: %s",
                    _cleanup_err,
                    exc_info=True,
                )
