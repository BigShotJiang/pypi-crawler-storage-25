# -*- coding: utf-8 -*-
"""MDRM Memory Hook v2 - Automatic Cone Graph structured memory extraction.

Inspired by M-Flow's Cone Graph architecture:
- Extracts Episodes (semantic focus), Facets (dimensions), FacetPoints (atomic facts), Entities
- Builds hierarchical memory structure with graph-routed relationships
- Supports graph-routed retrieval via GraphRouter
"""
import json
import logging
from typing import TYPE_CHECKING, Any, AsyncGenerator, Dict, List, Optional
from datetime import datetime

from xingzierai.agentscope_core.agent import ReActAgent
from xingzierai.agentscope_core.message import Msg

from xingzierai.memory.mdrm import (
    MDRMGraph,
    MDRMNode,
    MDRMEdge,
    MDRMNodeType,
    MDRMConeLayer,
    MDRMRelationType,
    MDRMStore,
    GraphRouter,
    EpisodeBundle,
)
from xingzierai.agents.model_factory import create_model_and_formatter
from xingzierai.config.config import load_agent_config

if TYPE_CHECKING:
    from xingzierai.agentscope_core.model import ChatModelBase
    from xingzierai.agentscope_core.formatter import FormatterBase

logger = logging.getLogger(__name__)


class MDRMMemoryHook:
    """Hook for automatic MDRM Cone Graph memory extraction and storage.

    This hook analyzes conversations and automatically extracts:
    - Episodes: bounded semantic focus (e.g., "Monday standup discussion")
    - Facets: dimensions of an Episode (e.g., "deadline communication")
    - FacetPoints: atomic assertions (e.g., "Maria wasn't told about the deadline")
    - Entities: named things linking across layers (e.g., "Maria", "deadline")

    It then stores them in MDRM graph with hierarchical Cone Graph structure,
    enabling graph-routed retrieval.
    """

    EXTRACTION_PROMPT = """Analyze the following conversation and extract structured memories.

Organize the extraction as a Cone Graph with these layers:
1. Episode: A bounded semantic focus - an incident, decision process, or workflow (1 per conversation turn)
2. Facet: One dimension of that Episode - a topical cross-section (1-3 per Episode)
3. FacetPoint: An atomic assertion or fact derived from a Facet (1-3 per Facet)
4. Entity: Named things - people, tools, metrics - that appear across layers

Conversation:
{conversation}

Respond in JSON format:
{{
  "episode": {{
    "title": "Brief title for this conversation turn",
    "summary": "Concise summary of what happened",
    "type": "event|decision|fact|goal"
  }},
  "facets": [
    {{
      "title": "Dimension name",
      "summary": "What this dimension covers"
    }}
  ],
  "facet_points": [
    {{
      "facet_index": 0,
      "content": "Atomic fact or assertion",
      "entities": ["entity_name"]
    }}
  ],
  "entities": [
    {{
      "name": "Entity name",
      "type": "person|tool|metric|place|other"
    }}
  ],
  "relationships": [
    {{
      "from": "episode|facet_N|point_N|entity_N",
      "to": "episode|facet_N|point_N|entity_N",
      "relation": "contains|has_facet|has_point|mentions|causes|depends_on|related_to",
      "edge_text": "Natural language description of this relationship"
    }}
  ]
}}

Only include significant information. If nothing important, return empty structures."""

    def __init__(
        self,
        agent_id: str,
        graph_name: Optional[str] = None,
        min_importance: int = 6,
        max_memories_per_turn: int = 3,
    ):
        self.agent_id = agent_id
        self.graph_name = graph_name or f"agent_{agent_id}_memories"
        self.min_importance = min_importance
        self.max_memories_per_turn = max_memories_per_turn

        self._store = MDRMStore()
        self._graph: Optional[MDRMGraph] = None
        self._chat_model: Optional["ChatModelBase"] = None
        self._formatter: Optional["FormatterBase"] = None
        self._initialized = False
        self._init_attempted = False
        self._store.start_periodic_persist()
        self._turn_counter = 0
        self._token_accumulator = 0
        self._CONSOLIDATION_INTERVAL_TURNS = 3
        self._CONSOLIDATION_INTERVAL_TOKENS = 500

    async def _initialize(self) -> bool:
        if self._initialized:
            return True

        if self._init_attempted and not self._initialized:
            return False

        self._init_attempted = True

        try:
            graphs = await self._store.list_graphs()
            for graph in graphs:
                if graph.name == self.graph_name:
                    self._graph = graph
                    break

            if self._graph is None:
                self._graph = MDRMGraph(name=self.graph_name)
                await self._store.save_graph(self._graph)
                logger.info(f"Created new MDRM graph: {self.graph_name}")
            else:
                logger.info(f"Loaded existing MDRM graph: {self.graph_name} ({len(self._graph.nodes)} nodes)")

            try:
                self._chat_model, self._formatter = create_model_and_formatter(
                    self.agent_id
                )
            except Exception as model_err:
                logger.warning(f"MDRM hook: model creation failed ({model_err}), will retry without dedicated model")
                self._chat_model = None
                self._formatter = None

            self._initialized = True
            return True

        except Exception as e:
            logger.error(f"Failed to initialize MDRM memory hook: {e}")
            return False

    async def __call__(
        self,
        agent: ReActAgent,
        kwargs: Dict[str, Any],
        output: Any = None,
    ) -> Any:
        try:
            if not await self._initialize():
                return None

            memory = agent.memory
            if not memory:
                return None

            messages = await memory.get_memory(prepend_summary=False)
            if len(messages) < 2:
                return None

            self._turn_counter += 1
            recent_text = self._build_conversation_text(messages[-6:])
            self._token_accumulator += len(recent_text) // 4

            should_extract = (
                self._turn_counter >= self._CONSOLIDATION_INTERVAL_TURNS
                or self._token_accumulator >= self._CONSOLIDATION_INTERVAL_TOKENS
            )
            if not should_extract:
                return None

            self._turn_counter = 0
            self._token_accumulator = 0

            conversation = recent_text

            chat_model = self._chat_model
            if chat_model is None and hasattr(agent, 'model'):
                chat_model = agent.model
                logger.info("MDRM hook: using agent's model for extraction (dedicated model unavailable)")

            if chat_model is None:
                logger.warning("MDRM hook: no model available for extraction, skipping")
                return None

            extraction_result = await self._extract_cone_graph(conversation, chat_model)
            if not extraction_result:
                return None

            await self._store_cone_graph(extraction_result, messages)

        except Exception as e:
            logger.exception(f"Error in MDRM memory hook: {e}")

        return None

    def _build_conversation_text(self, messages: List[Any]) -> str:
        """Build conversation text from messages."""
        lines = []
        for msg in messages:
            if isinstance(msg, dict):
                role = msg.get("role", "unknown")
                content = msg.get("content", "")
            else:
                role = getattr(msg, "role", "unknown")
                content = getattr(msg, "content", "")

            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif isinstance(block, dict):
                        text_parts.append(block.get("text", ""))
                content = " ".join(text_parts)

            if content:
                lines.append(f"{role.upper()}: {content[:500]}")

        return "\n\n".join(lines)

    async def _extract_cone_graph(self, conversation: str, chat_model=None) -> Optional[Dict[str, Any]]:
        model = chat_model or self._chat_model
        if not model:
            return None

        try:
            prompt = self.EXTRACTION_PROMPT.format(conversation=conversation)

            messages = [
                {"role": "system", "content": "You are a structured memory extraction assistant."},
                {"role": "user", "content": prompt},
            ]

            response = await model(
                messages,
                temperature=0.3,
                max_tokens=3000,
            )

            if isinstance(response, AsyncGenerator):
                chunks = []
                async for chunk in response:
                    if hasattr(chunk, 'content') and chunk.content:
                        for block in chunk.content:
                            if hasattr(block, 'text') and block.text:
                                chunks.append(block.text)
                content = "".join(chunks)
            elif hasattr(response, 'content'):
                content = ""
                for block in response.content:
                    if hasattr(block, 'text') and block.text:
                        content += block.text
            elif isinstance(response, dict):
                content = response.get("content", "")
            else:
                content = str(response) if response else ""

            if not content:
                logger.warning("MDRM hook: extraction returned empty content")
                return None

            json_start = content.find("{")
            json_end = content.rfind("}")
            if json_start == -1 or json_end == -1:
                logger.warning("MDRM hook: no JSON found in extraction response")
                return None

            json_str = content[json_start:json_end + 1]
            result = json.loads(json_str)

            logger.info(f"MDRM hook: extracted cone graph with episode='{result.get('episode', {}).get('title', 'N/A')}'")
            return result

        except json.JSONDecodeError as e:
            logger.warning(f"MDRM hook: failed to parse extraction JSON: {e}")
            return None
        except Exception as e:
            logger.error(f"MDRM hook: error extracting memories: {e}")
            return None

    async def _store_cone_graph(
        self,
        extraction_result: Dict[str, Any],
        context_messages: List[Any],
    ) -> None:
        """Store extracted Cone Graph in MDRM."""
        if not self._graph:
            return

        episode_data = extraction_result.get("episode")
        facets_data = extraction_result.get("facets", [])
        facet_points_data = extraction_result.get("facet_points", [])
        entities_data = extraction_result.get("entities", [])
        relationships_data = extraction_result.get("relationships", [])

        if not episode_data:
            return

        node_refs: Dict[str, MDRMNode] = {}

        episode = MDRMNode(
            node_type=MDRMNodeType(episode_data.get("type", "event")),
            cone_layer=MDRMConeLayer.EPISODE,
            content=episode_data.get("summary", ""),
            metadata={
                "title": episode_data.get("title", ""),
                "context_message_count": len(context_messages),
                "extracted_at": datetime.now().isoformat(),
            },
            confidence=0.9,
        )
        self._graph.add_node(episode)
        node_refs["episode"] = episode
        logger.info(f"Added Episode: {episode.content[:50]}...")

        for idx, facet_data in enumerate(facets_data):
            facet = MDRMNode(
                node_type=MDRMNodeType.FACT,
                cone_layer=MDRMConeLayer.FACET,
                content=facet_data.get("summary", ""),
                metadata={
                    "title": facet_data.get("title", ""),
                    "facet_index": idx,
                },
                confidence=0.8,
            )
            self._graph.add_node(facet)
            node_refs[f"facet_{idx}"] = facet

            edge = MDRMEdge(
                source_id=episode.id,
                target_id=facet.id,
                relation_type=MDRMRelationType.HAS_FACET,
                edge_text=f"Episode '{episode_data.get('title', '')}' has facet '{facet_data.get('title', '')}'",
                weight=2.0,
            )
            self._graph.add_edge(edge)

        for idx, point_data in enumerate(facet_points_data):
            facet_idx = point_data.get("facet_index", 0)
            point = MDRMNode(
                node_type=MDRMNodeType.FACT,
                cone_layer=MDRMConeLayer.FACET_POINT,
                content=point_data.get("content", ""),
                metadata={
                    "facet_index": facet_idx,
                    "entities": point_data.get("entities", []),
                },
                confidence=0.95,
            )
            self._graph.add_node(point)
            node_refs[f"point_{idx}"] = point

            facet_key = f"facet_{facet_idx}"
            if facet_key in node_refs:
                edge = MDRMEdge(
                    source_id=node_refs[facet_key].id,
                    target_id=point.id,
                    relation_type=MDRMRelationType.HAS_POINT,
                    edge_text=f"Facet contains atomic point: {point.content[:50]}...",
                    weight=3.0,
                )
                self._graph.add_edge(edge)

        for idx, entity_data in enumerate(entities_data):
            entity_name = entity_data.get("name", "")
            existing = None
            for node in self._graph.nodes.values():
                if node.cone_layer == MDRMConeLayer.ENTITY and node.content == entity_name:
                    existing = node
                    break

            if existing:
                node_refs[f"entity_{idx}"] = existing
            else:
                entity = MDRMNode(
                    node_type=MDRMNodeType.FACT,
                    cone_layer=MDRMConeLayer.ENTITY,
                    content=entity_name,
                    metadata={
                        "entity_type": entity_data.get("type", "other"),
                    },
                    confidence=1.0,
                )
                self._graph.add_node(entity)
                node_refs[f"entity_{idx}"] = entity

        for rel_data in relationships_data:
            from_key = rel_data.get("from", "")
            to_key = rel_data.get("to", "")
            if from_key in node_refs and to_key in node_refs:
                try:
                    relation_type = MDRMRelationType(rel_data.get("relation", "related_to"))
                except ValueError:
                    relation_type = MDRMRelationType.RELATED_TO

                edge = MDRMEdge(
                    source_id=node_refs[from_key].id,
                    target_id=node_refs[to_key].id,
                    relation_type=relation_type,
                    edge_text=rel_data.get("edge_text", ""),
                    weight=2.0,
                    metadata={"auto_extracted": True},
                )
                self._graph.add_edge(edge)

        await self._connect_similar_memories({k: v for k, v in node_refs.items() if not k.startswith("entity_")})
        await self._store.save_graph(self._graph)

        logger.info(f"Stored Cone Graph: 1 Episode, {len(facets_data)} Facets, {len(facet_points_data)} Points, {len(entities_data)} Entities")

    async def _connect_similar_memories(
        self,
        new_nodes: Dict[str, MDRMNode],
    ) -> None:
        """Connect new memories with existing similar ones."""
        if not self._graph:
            return

        for new_node in new_nodes.values():
            for existing_id, existing_node in self._graph.nodes.items():
                if existing_id == new_node.id:
                    continue

                new_content = new_node.content.lower()
                existing_content = existing_node.content.lower()

                new_words = set(new_content.split())
                existing_words = set(existing_content.split())

                common_words = new_words & existing_words
                if len(common_words) >= 3:
                    similarity = len(common_words) / max(len(new_words), len(existing_words))

                    if similarity >= 0.3:
                        edge = MDRMEdge(
                            source_id=new_node.id,
                            target_id=existing_id,
                            relation_type=MDRMRelationType.RELATED_TO,
                            edge_text=f"Similar content: shares {', '.join(list(common_words)[:3])}",
                            weight=similarity * 10,
                            metadata={
                                "auto_extracted": True,
                                "similarity": similarity,
                                "common_words": list(common_words)[:5],
                            },
                        )
                        self._graph.add_edge(edge)

    async def search_memories(
        self,
        query: str,
        max_results: int = 5,
        use_graph_route: bool = True,
    ) -> List[Dict[str, Any]]:
        """Search memories using graph-routed Bundle Search.

        Args:
            query: Search query
            max_results: Maximum results to return
            use_graph_route: Use M-Flow inspired graph routing instead of flat search

        Returns:
            List of matching memories or Episode Bundles
        """
        if not await self._initialize() or not self._graph:
            return []

        if use_graph_route and len(self._graph.nodes) > 5:
            router = GraphRouter(self._graph)
            bundles = router.route_search(query, top_k=max_results)
            return [bundle.to_dict() for bundle in bundles]

        query_lower = query.lower()
        query_words = set(query_lower.split())

        results = []

        for node_id, node in self._graph.nodes.items():
            content_lower = node.content.lower()

            score = 0.0

            if query_lower in content_lower:
                score += 2.0

            content_words = set(content_lower.split())
            common = query_words & content_words
            score += len(common) * 0.5

            if any(word in content_lower for word in ["decided", "decision", "决定"]):
                if "decision" in query_lower or "决定" in query_lower:
                    score += 0.5

            if score > 0:
                neighbors = self._graph.get_neighbors(node_id)
                neighbor_contents = [n.content for n in neighbors[:3]]

                results.append({
                    "id": node_id,
                    "content": node.content,
                    "type": node.node_type.value,
                    "cone_layer": node.cone_layer.value,
                    "score": score,
                    "confidence": node.confidence,
                    "related": neighbor_contents,
                    "created_at": node.created_at,
                })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:max_results]

    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics."""
        if not self._graph:
            return {"initialized": False}

        node_types = {}
        cone_layers = {}
        for node in self._graph.nodes.values():
            t = node.node_type.value
            node_types[t] = node_types.get(t, 0) + 1
            cl = node.cone_layer.value
            cone_layers[cl] = cone_layers.get(cl, 0) + 1

        return {
            "initialized": True,
            "graph_name": self.graph_name,
            "total_nodes": len(self._graph.nodes),
            "total_edges": len(self._graph.edges),
            "node_types": node_types,
            "cone_layers": cone_layers,
        }
