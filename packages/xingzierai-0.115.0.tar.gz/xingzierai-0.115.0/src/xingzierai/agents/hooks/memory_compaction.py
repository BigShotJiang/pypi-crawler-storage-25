# -*- coding: utf-8 -*-
"""Memory compaction hook for managing context window.

This hook monitors token usage and automatically compacts older messages
when the context window approaches its limit, preserving recent messages
and the system prompt.

Deep integration with LocalModelDispatcher:
- If a local small model is available for "memory_compact", it is used instead of LLM
- If not, the LLM is used and the I/O is collected as training data
- When enough data accumulates (50+ samples), a small model is auto-trained
- The system gradually becomes more self-sufficient for memory compaction
"""
import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any

from xingzierai.agentscope_core.agent import ReActAgent
from xingzierai.agentscope_core.message import Msg, TextBlock

from ..utils import (
    get_xingzierai_token_counter,
)
from ...config.config import load_agent_config

if TYPE_CHECKING:
    from ..memory import MemoryManager
    from xingzierai.reme_sdk.reme.memory.file_based import ReMeInMemoryMemory

logger = logging.getLogger(__name__)


def _messages_to_text(messages: list) -> str:
    lines = []
    for msg in messages:
        if isinstance(msg, dict):
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
        else:
            role = getattr(msg, "role", "unknown")
            content = getattr(msg, "content", "")

        if isinstance(content, list):
            text_parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
            content = " ".join(text_parts)

        if content:
            lines.append(f"{role}: {content[:500]}")

    return "\n".join(lines)


class MemoryCompactionHook:
    """Hook for automatic memory compaction when context is full.

    Ported and enhanced from QwenPaw's LightContextManager.pre_reasoning().

    Key improvements over the old version:
    - Uses mark_messages_compressed() to actually REMOVE messages from memory
    - Uses context_check() for proper tool_use/tool_result ID alignment
    - Has a robust fallback with larger reserve when compaction fails
    - Validates summary format before accepting
    """

    def __init__(self, memory_manager: "MemoryManager"):
        self.memory_manager = memory_manager

    @staticmethod
    async def _print_status_message(
        agent: ReActAgent,
        text: str,
    ) -> None:
        msg = Msg(
            name=agent.name,
            role="assistant",
            content=[TextBlock(type="text", text=text)],
        )
        await agent.print(msg)

    @staticmethod
    def _is_valid_summary(content: str) -> bool:
        """Check if the summary content is valid.

        Ported from QwenPaw's LightContextManager._is_valid_summary().
        A valid summary should contain meaningful content.
        Markdown headers (##) are preferred but not strictly required.
        """
        if not content or not content.strip():
            return False
        stripped = content.strip()
        if len(stripped) < 20:
            return False
        return True

    async def __call__(
        self,
        agent: ReActAgent,
        kwargs: dict[str, Any],
    ) -> dict[str, Any] | None:
        _compact_stage = "init"
        messages_to_compact = []
        try:
            agent_config = load_agent_config(self.memory_manager.agent_id)
            running_config = agent_config.running
            token_counter = get_xingzierai_token_counter(agent_config)

            memory = agent.memory

            system_prompt = agent.sys_prompt
            compressed_summary = memory.get_compressed_summary()
            str_token_count = await token_counter.count(
                messages=[],
                text=(system_prompt or "") + (compressed_summary or ""),
            )

            tools_token_count = 0
            try:
                tool_schemas = agent.toolkit.get_json_schemas() if agent.toolkit else []
                if tool_schemas:
                    tools_text = json.dumps(tool_schemas, ensure_ascii=False)
                    tools_token_count = await token_counter.count(
                        messages=[],
                        text=tools_text,
                    )
            except Exception as e:
                logger.debug("Failed to count tool tokens: %s", e)
                tools_token_count = 0

            overhead_tokens = str_token_count + tools_token_count

            left_compact_threshold = (
                running_config.memory_compact_threshold - overhead_tokens
            )

            if left_compact_threshold <= 0:
                logger.warning(
                    "The memory_compact_threshold is set too low; "
                    "the combined token length of system_prompt and "
                    "compressed_summary exceeds the configured threshold.",
                )
                return None

            messages = await memory.get_memory(prepend_summary=False)

            recent_threshold = (
                running_config.tool_result_compact_recent_threshold
            )
            retention_days = running_config.tool_result_compact_retention_days
            await self.memory_manager.compact_tool_result(
                messages=messages,
                recent_n=running_config.tool_result_compact_recent_n,
                old_threshold=running_config.tool_result_compact_old_threshold,
                recent_threshold=recent_threshold,
                retention_days=retention_days,
            )

            from ..utils import context_check

            messages = await memory.get_memory(prepend_summary=False)

            estimated_tokens = []
            for msg in messages:
                try:
                    text_content = msg.get_text_content() or ""
                    if text_content:
                        msg_tokens = await token_counter.count(
                            messages=[], text=text_content,
                        )
                    else:
                        msg_tokens = max(1, len(str(msg.content or "")) // 4)
                    estimated_tokens.append(msg_tokens)
                except Exception as _tok_est_err:
                    logger.debug("Token estimation fallback: %s", _tok_est_err)
                    estimated_tokens.append(max(1, len(str(msg.content or "")) // 4))

            total_tokens = sum(estimated_tokens)

            if total_tokens < left_compact_threshold:
                return None

            context_compact_reserve = running_config.memory_compact_reserve

            messages_to_compact, messages_to_keep, _, _ = context_check(
                messages=messages,
                context_compact_threshold=left_compact_threshold,
                context_compact_reserve=context_compact_reserve,
                token_counts=estimated_tokens,
            )

            if not messages_to_compact:
                return None

            compact_count = len(messages_to_compact)
            keep_count = len(messages_to_keep)
            total_msgs = len(messages)

            await self._print_status_message(
                agent,
                f"🔄 Context compaction started... "
                f"💬 {total_msgs} msgs -> compact({compact_count}) + keep({keep_count})",
            )

            self.memory_manager.add_async_summary_task(
                messages=messages_to_compact,
            )

            MAX_INPUT_CHARS = 8000
            input_text = _messages_to_text(messages_to_compact)
            if len(input_text) > MAX_INPUT_CHARS:
                logger.info(
                    "Truncating compaction input from %d to %d chars",
                    len(input_text), MAX_INPUT_CHARS,
                )
                input_text = input_text[:MAX_INPUT_CHARS] + "\n[...truncated...]"
            previous_summary = memory.get_compressed_summary() or ""
            if previous_summary:
                input_text = f"[Previous Summary]\n{previous_summary}\n\n[New Messages]\n{input_text}"

            compact_content = None
            _compact_stage = "init"

            try:
                from ..local_model_dispatcher import LocalModelDispatcher
                dispatcher = LocalModelDispatcher.get_instance()

                if dispatcher.has_local_model("memory_compact"):
                    _compact_stage = "local_model"
                    await self._print_status_message(
                        agent,
                        "🧠 Using local small model for compaction...",
                    )
                    compact_content = await dispatcher.dispatch(
                        task_type="memory_compact",
                        input_text=input_text,
                        max_new_tokens=256,
                        temperature=0.3,
                        collect_data=False,
                    )
                    if compact_content:
                        logger.info("Memory compaction completed using local small model")
            except Exception as e:
                logger.debug("Local model dispatch failed, falling back to free model: %s", e)

            if not compact_content:
                _compact_stage = "free_model"
                try:
                    from ...smart_llm_client import SmartLLMClient
                    client = SmartLLMClient._instance
                    if client is not None:
                        await self._print_status_message(
                            agent,
                            "🆓 Using free model for compaction...",
                        )
                        for _attempt in range(2):
                            try:
                                compact_content = await client.ask_free_model(
                                    prompt=f"Summarize the following conversation concisely, preserving key facts, decisions, and action items. Use markdown headers (##) to organize the summary.\n\n{input_text}",
                                    system="You are a memory compaction assistant. Summarize conversations concisely while preserving all important facts, decisions, and action items. Use the same language as the original text. Format your summary with ## markdown headers for sections like ## Task Overview, ## Current State, ## Key Decisions, ## Next Steps.",
                                    max_tokens=512,
                                )
                                if compact_content and self._is_valid_summary(compact_content):
                                    logger.info("Memory compaction completed using free model (cost=$0.00)")
                                    break
                                else:
                                    logger.warning("Free model returned invalid summary (attempt %d)", _attempt + 1)
                                    compact_content = None
                            except Exception as e:
                                logger.warning("Free model compaction attempt %d failed: %s", _attempt + 1, e)
                                compact_content = None
                    else:
                        logger.debug("SmartLLMClient not initialized, skipping free model path")
                except Exception as e:
                    logger.debug("Free model compaction failed, falling back to LLM: %s", e)

            if not compact_content:
                _compact_stage = "llm"
                await self._print_status_message(
                    agent,
                    "🔄 Context compaction in progress...",
                )

                COMPACT_TIMEOUT_SECONDS = 60

                async def _llm_compact():
                    return await asyncio.wait_for(
                        self.memory_manager.compact_memory(
                            messages=messages_to_compact,
                            previous_summary=previous_summary,
                        ),
                        timeout=COMPACT_TIMEOUT_SECONDS,
                    )

                try:
                    from ..local_model_dispatcher import LocalModelDispatcher
                    dispatcher = LocalModelDispatcher.get_instance()
                    compact_content = await asyncio.wait_for(
                        dispatcher.dispatch(
                            task_type="memory_compact",
                            input_text=input_text,
                            fallback_fn=_llm_compact,
                            max_new_tokens=256,
                            temperature=0.3,
                            collect_data=True,
                        ),
                        timeout=COMPACT_TIMEOUT_SECONDS,
                    )
                except asyncio.TimeoutError:
                    logger.error("Memory compaction timed out after %ds", COMPACT_TIMEOUT_SECONDS)
                except Exception as _compact_err:
                    logger.warning("Primary compaction failed (stage=%s): %s", _compact_stage, _compact_err)
                    try:
                        compact_content = await _llm_compact()
                    except asyncio.TimeoutError:
                        logger.error("LLM compact fallback also timed out after %ds", COMPACT_TIMEOUT_SECONDS)
                    except Exception as _llm_err:
                        logger.warning("LLM compact fallback also failed: %s", _llm_err)

            if not compact_content or not self._is_valid_summary(compact_content):
                logger.warning(
                    "Memory compaction returned invalid result at stage=%s "
                    "(content=%s, valid=%s), using fallback",
                    _compact_stage,
                    repr(compact_content[:100]) if compact_content else "None",
                    self._is_valid_summary(compact_content) if compact_content else False,
                )

                existing_summary = memory.get_compressed_summary() or ""

                if existing_summary:
                    compact_content = existing_summary
                    logger.info(
                        "Using existing compressed_summary as fallback (%d chars), "
                        "dropping %d old messages",
                        len(compact_content),
                        compact_count,
                    )
                elif compact_count > 0:
                    truncated_summary_parts = []
                    for msg in messages_to_compact[:20]:
                        text = msg.get_text_content() if hasattr(msg, 'get_text_content') else ""
                        if text:
                            truncated_summary_parts.append(f"- {text[:200]}")
                    if truncated_summary_parts:
                        truncated_summary = "## Truncated Context\n" + "\n".join(truncated_summary_parts)
                        if self._is_valid_summary(truncated_summary):
                            compact_content = truncated_summary
                            logger.info("Using truncated summary as fallback (%d chars)", len(compact_content))

                if compact_count > 0:
                    await self._print_status_message(
                        agent,
                        f"⚠️ 上下文压缩使用降级方案，保留最近{keep_count}条，"
                        f"丢弃旧{compact_count}条。/ "
                        f"Context compaction used fallback. "
                        f"Keep({keep_count}) + drop({compact_count}) msgs.",
                    )
                else:
                    await self._print_status_message(
                        agent,
                        "⚠️ 上下文压缩失败，如遇问题请使用 /new 或 /clear 重置。/ "
                        "Context compaction failed. Use /new or /clear if issues persist.",
                    )
            else:
                await self._print_status_message(
                    agent,
                    "✅ Context compaction completed",
                )

            if messages_to_compact and hasattr(memory, 'mark_messages_compressed'):
                updated_count = await memory.mark_messages_compressed(
                    messages_to_compact,
                )
                logger.info("Marked %d messages as compressed (removed from memory)", updated_count)
            elif messages_to_compact:
                logger.warning(
                    "Memory does not support mark_messages_compressed, "
                    "using delete as fallback"
                )
                ids_to_delete = [msg.id for msg in messages_to_compact]
                await memory.delete(ids_to_delete)

            if compact_content:
                await memory.update_compressed_summary(compact_content)

        except Exception as e:
            logger.exception(
                "Failed to compact memory in pre_reasoning hook: %s (type=%s, stage=%s)",
                e,
                type(e).__name__,
                _compact_stage,
                exc_info=True,
            )
            if messages_to_compact:
                try:
                    if hasattr(memory, 'mark_messages_compressed'):
                        removed = await memory.mark_messages_compressed(messages_to_compact)
                        logger.warning(
                            "Emergency: removed %d messages after compaction failure",
                            removed,
                        )
                    else:
                        ids_to_delete = [msg.id for msg in messages_to_compact]
                        await memory.delete(ids_to_delete)
                        logger.warning(
                            "Emergency: deleted %d messages after compaction failure",
                            len(ids_to_delete),
                        )
                except Exception as _emergency_err:
                    logger.error("Emergency message removal also failed: %s", _emergency_err)

            try:
                if isinstance(e, (asyncio.TimeoutError, TimeoutError)):
                    await self._print_status_message(
                        agent,
                        "⚠️ 上下文压缩超时，已紧急删除旧消息保留最近对话。"
                        "如遇问题请使用 /clear 或 /new 重置。/ "
                        "Context compaction timed out, old messages removed. "
                        "Use /clear or /new if issues persist.",
                    )
                elif isinstance(e, (ConnectionError, OSError)):
                    await self._print_status_message(
                        agent,
                        "⚠️ 上下文压缩网络错误，已紧急删除旧消息保留最近对话。"
                        "如遇问题请使用 /clear 或 /new 重置。/ "
                        "Context compaction network error, old messages removed. "
                        "Use /clear or /new if issues persist.",
                    )
                else:
                    err_type = type(e).__name__
                    err_msg = str(e)[:200]
                    await self._print_status_message(
                        agent,
                        f"⚠️ 上下文压缩失败({err_type}): {err_msg}。"
                        "已紧急删除旧消息。"
                        "如遇问题请使用 /clear 或 /new 重置。/ "
                        f"Context compaction failed ({err_type}): {err_msg}. "
                        "Old messages removed. Use /clear or /new if issues persist.",
                    )
            except Exception as _notify_err:
                logger.debug("Failed to send compaction failure notification: %s", _notify_err)

        return None


DREAM_OPTIMIZATION_PROMPT = """\
Enter dream state for memory optimization. Read today's logs and existing \
long-term memory, extract high-value incremental information in your dream \
state, deduplicate and merge, and ultimately overwrite `MEMORY.md`. Ensure \
the long-term memory file remains up-to-date, concise, and non-redundant.

Current date: {current_date}

[Dream Optimization Principles]
1. Extreme Minimalism: Strictly forbid recording daily routines, specific \
bug-fix details, or one-off tasks. Retain ONLY 'core business decisions', \
'confirmed user preferences', and 'high-value reusable experiences'.
2. State Overwrite: If a state change is detected (e.g., tech stack changes, \
config updates), you MUST replace the old state with the new one. \
Contradictory old and new information must not coexist.
3. Inductive Consolidation: Proactively distill and merge fragmented, similar \
rules into highly universal, independent entries.
4. Deprecation: Proactively delete hypotheses that have been proven false or \
outdated entries that no longer apply.

[Dream Execution Steps]
Step 1 [Load]: Read `MEMORY.md` in the workspace and today's log file \
`memory/YYYY-MM-DD.md`.
Step 2 [Dream Purification]: Compare the old and new content in your dream \
state. Strictly follow the [Dream Optimization Principles] to deduplicate, \
replace, remove, and merge, generating entirely new memory content.
Step 3 [Save]: Write the newly organized Markdown content into `MEMORY.md` \
(maintain clear hierarchy and list structures).
Step 4 [Awake Report]: After waking from your dream, briefly report: \
1) What core memories were newly added/consolidated; 2) What outdated content \
was corrected/deleted.
"""


def get_dream_prompt(current_date: str = "") -> str:
    from datetime import date
    if not current_date:
        current_date = str(date.today())
    return DREAM_OPTIMIZATION_PROMPT.format(current_date=current_date)
