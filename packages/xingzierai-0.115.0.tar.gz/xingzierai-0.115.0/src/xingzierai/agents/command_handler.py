# -*- coding: utf-8 -*-
"""Agent command handler for system commands.

This module handles system commands like /compact, /new, /clear, etc.
"""
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from xingzierai.agentscope_core.message import Msg, TextBlock

from ..config.config import load_agent_config
from ..constant import DEBUG_HISTORY_FILE, MAX_LOAD_HISTORY_COUNT

if TYPE_CHECKING:
    from .memory import MemoryManager
    from xingzierai.reme_sdk.reme.memory.file_based import ReMeInMemoryMemory

logger = logging.getLogger(__name__)


class ConversationCommandHandlerMixin:
    """Mixin for conversation (system) commands: /compact, /new, /clear, etc.

    Expects self to have: agent_name, memory, formatter, memory_manager,
    _enable_memory_manager.
    """

    # Supported conversation commands (unchanged set)
    SYSTEM_COMMANDS = frozenset(
        {
            "compact",
            "new",
            "clear",
            "history",
            "compact_str",
            "await_summary",
            "message",
            "dump_history",
            "load_history",
            "stop",
            "plan",
            "plans",
            "persona",
            "spec",
            "build",
            "test",
            "review",
            "ship",
            "mission",
            "proactive",
            "dream",
        },
    )

    def is_conversation_command(self, query: str | None) -> bool:
        """Check if the query is a conversation system command.

        Args:
            query: User query string

        Returns:
            True if query is a system command
        """
        if not isinstance(query, str) or not query.startswith("/"):
            return False
        return query.strip().lstrip("/") in self.SYSTEM_COMMANDS


class CommandHandler(ConversationCommandHandlerMixin):
    """Handler for system commands (uses ConversationCommandHandlerMixin)."""

    def __init__(
        self,
        agent_name: str,
        memory: "ReMeInMemoryMemory",
        memory_manager: "MemoryManager | None" = None,
        enable_memory_manager: bool = True,
    ):
        """Initialize command handler.

        Args:
            agent_name: Name of the agent for message creation
            memory: Agent's ReMeInMemoryMemory instance
            memory_manager: Optional memory manager instance
            enable_memory_manager: Whether memory manager is enabled
        """
        self.agent_name = agent_name
        self.memory = memory
        self.memory_manager = memory_manager
        self._enable_memory_manager = enable_memory_manager

    def _get_agent_config(self):
        """Get hot-reloaded agent config.

        Returns:
            AgentProfileConfig: The current agent configuration
        """
        return load_agent_config(self.memory_manager.agent_id)

    def is_command(self, query: str | None) -> bool:
        """Check if the query is a system command (alias for mixin)."""
        return self.is_conversation_command(query)

    async def _make_system_msg(self, text: str) -> Msg:
        """Create a system response message.

        Args:
            text: Message text content

        Returns:
            System message
        """
        return Msg(
            name=self.agent_name,
            role="assistant",
            content=[TextBlock(type="text", text=text)],
        )

    def _has_memory_manager(self) -> bool:
        """Check if memory manager is available."""
        return self._enable_memory_manager and self.memory_manager is not None

    async def _process_compact(
        self,
        messages: list[Msg],
        _args: str = "",
    ) -> Msg:
        """Process /compact command."""
        if not messages:
            return await self._make_system_msg(
                "**No messages to compact.**\n\n"
                "- Current memory is empty\n"
                "- No action taken",
            )
        if not self._has_memory_manager():
            return await self._make_system_msg(
                "**Memory Manager Disabled**\n\n"
                "- Memory compaction is not available\n"
                "- Enable memory manager to use this feature",
            )

        self.memory_manager.add_async_summary_task(messages=messages)
        compact_content = await self.memory_manager.compact_memory(
            messages=messages,
            previous_summary=self.memory.get_compressed_summary(),
        )

        if not compact_content:
            return await self._make_system_msg(
                "**Compact Failed!**\n\n"
                "- Memory compaction returned empty result\n"
                "- Please check the logs for details\n"
                "- If context exceeds max length, "
                "please use `/new` or `/clear` to clear the context",
            )

        await self.memory.update_compressed_summary(compact_content)
        updated_count = len(messages)
        self.memory.clear_content()
        return await self._make_system_msg(
            f"**Compact Complete!**\n\n"
            f"- Messages compacted: {updated_count}\n"
            f"**Compressed Summary:**\n{compact_content}\n"
            f"- Summary task started in background\n",
        )

    async def _process_new(self, messages: list[Msg], _args: str = "") -> Msg:
        """Process /new command."""
        if not messages:
            self.memory.clear_compressed_summary()
            return await self._make_system_msg(
                "**No messages to summarize.**\n\n"
                "- Current memory is empty\n"
                "- Compressed summary is clear\n"
                "- No action taken",
            )
        if not self._has_memory_manager():
            return await self._make_system_msg(
                "**Memory Manager Disabled**\n\n"
                "- Cannot start new conversation with summary\n"
                "- Enable memory manager to use this feature",
            )

        self.memory_manager.add_async_summary_task(messages=messages)
        self.memory.clear_compressed_summary()

        self.memory.clear_content()
        return await self._make_system_msg(
            "**New Conversation Started!**\n\n"
            "- Summary task started in background\n"
            "- Ready for new conversation",
        )

    async def _process_clear(
        self,
        _messages: list[Msg],
        _args: str = "",
    ) -> Msg:
        """Process /clear command."""
        self.memory.clear_content()
        self.memory.clear_compressed_summary()
        return await self._make_system_msg(
            "**History Cleared!**\n\n"
            "- Compressed summary reset\n"
            "- Memory is now empty",
        )

    async def _process_compact_str(
        self,
        _messages: list[Msg],
        _args: str = "",
    ) -> Msg:
        """Process /compact_str command to show compressed summary."""
        summary = self.memory.get_compressed_summary()
        if not summary:
            return await self._make_system_msg(
                "**No Compressed Summary**\n\n"
                "- No summary has been generated yet\n"
                "- Use /compact or wait for auto-compaction",
            )
        return await self._make_system_msg(
            f"**Compressed Summary**\n\n{summary}",
        )

    async def _process_history(
        self,
        _messages: list[Msg],
        _args: str = "",
    ) -> Msg:
        """Process /history command."""
        agent_config = self._get_agent_config()
        running_config = agent_config.running
        history_str = await self.memory.get_history_str(
            max_input_length=running_config.max_input_length,
        )

        # Truncate if too long
        if len(history_str) > running_config.history_max_length:
            half = running_config.history_max_length // 2
            history_str = f"{history_str[:half]}\n...\n{history_str[-half:]}"

        history_str += (
            "\n\n---\n\n- Use /message <index> to view full message content"
        )

        # Add compact summary hint if available
        if self.memory.get_compressed_summary():
            history_str += "\n- Use /compact_str to view full compact summary"

        return await self._make_system_msg(history_str)

    async def _process_await_summary(
        self,
        _messages: list[Msg],
        _args: str = "",
    ) -> Msg:
        """Process /await_summary command to wait for all summary tasks."""
        if not self._has_memory_manager():
            return await self._make_system_msg(
                "**Memory Manager Disabled**\n\n"
                "- Cannot await summary tasks\n"
                "- Enable memory manager to use this feature",
            )

        task_count = len(self.memory_manager.summary_tasks)
        if task_count == 0:
            return await self._make_system_msg(
                "**No Summary Tasks**\n\n"
                "- No pending summary tasks to wait for",
            )

        result = await self.memory_manager.await_summary_tasks()
        return await self._make_system_msg(
            f"**Summary Tasks Complete**\n\n"
            f"- Waited for {task_count} summary task(s)\n"
            f"- {result}"
            f"- All tasks have finished",
        )

    async def _process_message(
        self,
        messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /message x command to show the nth message.

        Args:
            messages: List of messages in memory
            args: Command arguments (message index)

        Returns:
            System message with the requested message content
        """
        agent_config = self._get_agent_config()
        history_max_length = agent_config.running.history_max_length

        if not args:
            return await self._make_system_msg(
                "**Usage: /message <index>**\n\n"
                "- Example: /message 1 (show first message)\n"
                f"- Available messages: 1 to {len(messages)}",
            )

        try:
            index = int(args.strip())
        except ValueError:
            return await self._make_system_msg(
                f"**Invalid Index: '{args}'**\n\n"
                "- Index must be a number\n"
                "- Example: /message 1",
            )

        if not messages:
            return await self._make_system_msg(
                "**No Messages Available**\n\n- Current memory is empty",
            )

        if index < 1 or index > len(messages):
            return await self._make_system_msg(
                f"**Index Out of Range: {index}**\n\n"
                f"- Available range: 1 to {len(messages)}\n"
                f"- Example: /message 1",
            )

        msg = messages[index - 1]

        # Handle content display with truncation
        content_str = str(msg.content)
        truncated = False
        if len(content_str) > history_max_length:
            half = history_max_length // 2
            content_str = f"{content_str[:half]}\n...\n{content_str[-half:]}"
            truncated = True

        truncation_hint = (
            "\n\n- Content truncated, use /dump_history to view full content"
            if truncated
            else ""
        )
        return await self._make_system_msg(
            f"**Message {index}/{len(messages)}**\n\n"
            f"- **Timestamp:** {msg.timestamp}\n"
            f"- **Name:** {msg.name}\n"
            f"- **Role:** {msg.role}\n"
            f"- **Content:**\n{content_str}{truncation_hint}",
        )

    async def _process_dump_history(
        self,
        messages: list[Msg],
        _args: str = "",
    ) -> Msg:
        """Process /dump_history command to save messages to a JSONL file.

        Args:
            messages: List of messages in memory
            _args: Command arguments (unused)

        Returns:
            System message with dump result
        """
        agent_config = self._get_agent_config()
        history_file = Path(agent_config.workspace_dir) / DEBUG_HISTORY_FILE

        try:
            # Check if there's a compressed summary
            compressed_summary = self.memory.get_compressed_summary()
            has_summary = bool(compressed_summary)

            # Build dump messages: summary first (if exists), then messages
            dump_messages = []
            if has_summary:
                summary_msg = Msg(
                    name="user",
                    role="user",
                    content=[TextBlock(type="text", text=compressed_summary)],
                    metadata={"has_compressed_summary": "true"},
                )
                dump_messages.append(summary_msg)

            dump_messages.extend(messages)

            tmp = Path(str(history_file) + ".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                for msg in dump_messages:
                    f.write(
                        json.dumps(msg.to_dict(), ensure_ascii=False) + "\n",
                    )
            tmp.replace(history_file)

            logger.info(
                f"Dumped {len(dump_messages)} messages to {history_file}",
            )
            return await self._make_system_msg(
                f"**History Dumped!**\n\n"
                f"- Messages saved: {len(dump_messages)}\n"
                f"- Has summary: {has_summary}\n"
                f"- File: `{history_file}`",
            )
        except Exception as e:
            logger.exception(f"Failed to dump history: {e}")
            return await self._make_system_msg(
                f"**Dump Failed**\n\n" f"- Error: {e}",
            )

    async def _process_load_history(
        self,
        _messages: list[Msg],
        _args: str = "",
    ) -> Msg:
        """Process /load_history command to load messages from a JSONL file.

        Args:
            _messages: List of messages in memory (unused)
            _args: Command arguments (unused)

        Returns:
            System message with load result
        """
        agent_config = self._get_agent_config()
        history_file = Path(agent_config.workspace_dir) / DEBUG_HISTORY_FILE

        if not history_file.exists():
            return await self._make_system_msg(
                f"**Load Failed**\n\n"
                f"- File not found: `{history_file}`\n"
                f"- Use /dump_history first to create the file",
            )

        try:
            loaded_messages: list[Msg] = []
            has_summary_marker = False
            with open(history_file, encoding="utf-8") as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if line:
                        msg_dict = json.loads(line)
                        msg = Msg.from_dict(msg_dict)
                        loaded_messages.append(msg)
                        # Check first message for summary marker
                        if (
                            i == 0
                            and msg.metadata.get("has_compressed_summary")
                            == "true"
                        ):
                            has_summary_marker = True
                        if len(loaded_messages) >= MAX_LOAD_HISTORY_COUNT:
                            break

            # Clear existing memory
            self.memory.content.clear()
            self.memory.clear_compressed_summary()

            # If first message has summary marker, extract and restore summary
            if has_summary_marker and loaded_messages:
                summary_msg = loaded_messages.pop(0)
                # Extract summary content from the message
                summary_content = summary_msg.get_text_content() or ""
                # Set the compressed summary directly
                await self.memory.update_compressed_summary(summary_content)
                logger.info("Restored compressed summary from history file")

            for msg in loaded_messages:
                await self.memory.add(msg)

            logger.info(
                f"Loaded {len(loaded_messages)} messages from {history_file}",
            )
            return await self._make_system_msg(
                f"**History Loaded!**\n\n"
                f"- Messages loaded: {len(loaded_messages)}\n"
                f"- Has summary: {has_summary_marker}\n"
                f"- File: `{history_file}`\n"
                f"- Memory cleared before loading",
            )
        except Exception as e:
            logger.exception(f"Failed to load history: {e}")
            return await self._make_system_msg(
                f"**Load Failed**\n\n" f"- Error: {e}",
            )

    async def _process_stop(
        self,
        messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /stop command to cancel ongoing tasks."""
        from ..priority_queue import get_global_stop_queue

        queue = get_global_stop_queue()

        if not args:
            queue_info = queue.get_queue_info()
            running = queue_info.get("current_running", 0)
            return await self._make_system_msg(
                f"**Task Queue Status**\n\n"
                f"- Running: {running}\n"
                f"- Pending: {queue_info.get('total_pending', 0)}\n\n"
                f"**Usage:**\n"
                f"- `/stop <task_id>` - Stop specific task\n"
                f"- `/stop session` - Stop all session tasks\n"
                f"- `/stop all` - Stop all channel tasks\n"
            )

        if args == "session":
            session_id = self._get_session_id()
            channel = self._get_channel()
            stopped = await queue.stop_session(channel, session_id)
            return await self._make_system_msg(
                f"**Session Stopped**\n\n"
                f"- Stopped {len(stopped)} task(s) in session {session_id}",
            )

        if args == "all":
            channel = self._get_channel()
            stopped = await queue.stop_channel(channel)
            return await self._make_system_msg(
                f"**Channel Stopped**\n\n"
                f"- Stopped {len(stopped)} task(s) in channel {channel}",
            )

        success = await queue.stop(args)
        if success:
            return await self._make_system_msg(
                f"**Task Stopped**\n\n- Task `{args}` has been stopped",
            )
        return await self._make_system_msg(
            f"**Task Not Found**\n\n- Task `{args}` not found or already completed",
        )

    async def _process_plan(
        self,
        messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /plan command to create and execute a plan."""
        from ..plan_engine import PlanEngine

        if not args:
            return await self._make_system_msg(
                "**Plan Mode**\n\n"
                "Usage: `/plan <task description>`\n\n"
                "Creates a step-by-step plan for complex tasks with:\n"
                "- Automatic task decomposition\n"
                "- Progress tracking\n"
                "- Checkpoint/rollback on failure\n"
            )

        try:
            engine = PlanEngine(agent=None)
            plan = await engine.create_plan(args)

            plan_lines = ["**Plan Created**\n\n"]
            for i, step in enumerate(plan.steps, 1):
                plan_lines.append(f"{i}. {step.description}")

            plan_lines.append(f"\n**Total Steps:** {len(plan.steps)}")
            plan_lines.append("\nUse `/plans` to see all plans and their status.")

            return await self._make_system_msg("\n".join(plan_lines))

        except Exception as e:
            logger.error(f"Plan creation failed: {e}")
            return await self._make_system_msg(
                f"**Plan Creation Failed**\n\n- Error: {e}",
            )

    async def _process_plans(
        self,
        messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /plans command to list active plans."""
        from ..plan_engine import PlanEngine

        return await self._make_system_msg(
            "**Plan Status**\n\n"
            "Use the Plan Mode UI in the console to view active plans.\n"
            "Use `/plan <task>` to create a new plan.",
        )

    async def _process_persona(
        self,
        messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /persona command to switch between personas."""
        from ..persona import PERSONAS, PersonaType

        if not args:
            persona_list = []
            for p_type, persona in PERSONAS.items():
                emoji = persona.emoji
                persona_list.append(
                    f"- **{emoji} {p_type.value}**: {persona.name} - {persona.description}"
                )

            return await self._make_system_msg(
                "**Available Personas**\n\n" +
                "\n".join(persona_list) +
                "\n\n**Usage:** `/persona <type>` to switch\n" +
                "Example: `/persona tech_expert`"
            )

        args_lower = args.lower().strip()
        persona_map = {
            "default": PersonaType.DEFAULT,
            "tech": PersonaType.TECH_EXPERT,
            "tech_expert": PersonaType.TECH_EXPERT,
            "boyfriend": PersonaType.BOYFRIEND,
            "girlfriend": PersonaType.GIRLFRIEND,
            "jarvis": PersonaType.JARVIS,
            "butler": PersonaType.BUTLER,
            "business": PersonaType.BUSINESS,
            "family": PersonaType.FAMILY,
        }

        if args_lower not in persona_map:
            return await self._make_system_msg(
                f"**Unknown Persona: {args}**\n\n"
                "Use `/persona` to see available personas."
            )

        persona_type = persona_map[args_lower]
        persona = PERSONAS.get(persona_type)

        return await self._make_system_msg(
            f"**Persona Switched**\n\n"
            f"{persona.emoji} **{persona.name}**\n"
            f"_{persona.description}_\n\n"
            f"Tone: {persona.tone}\n"
            f"Traits: {', '.join(persona.traits)}"
        )

    async def _process_spec(
        self,
        _messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /spec command to activate spec-driven-development skill."""
        return await self._process_skill_command(
            "spec",
            "spec-driven-development",
            args,
            "Define what to build before writing any code.",
            "Write a PRD for: ",
        )

    async def _process_build(
        self,
        _messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /build command to activate incremental-implementation skill."""
        return await self._process_skill_command(
            "build",
            "incremental-implementation",
            args,
            "Build incrementally with thin vertical slices.",
            "Implement incrementally: ",
        )

    async def _process_test(
        self,
        _messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /test command to activate test-driven-development skill."""
        return await self._process_skill_command(
            "test",
            "test-driven-development",
            args,
            "Prove it works with tests. Red-Green-Refactor.",
            "Write tests for: ",
        )

    async def _process_review(
        self,
        _messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /review command to activate code-review-and-quality skill."""
        return await self._process_skill_command(
            "review",
            "code-review-and-quality",
            args,
            "Five-axis code review with staff engineer standard.",
            "Review code for: ",
        )

    async def _process_ship(
        self,
        _messages: list[Msg],
        args: str = "",
    ) -> Msg:
        """Process /ship command to activate shipping-and-launch skill."""
        return await self._process_skill_command(
            "ship",
            "shipping-and-launch",
            args,
            "Ship to production with confidence. Faster is safer.",
            "Prepare to ship: ",
        )

    async def _process_skill_command(
        self,
        command: str,
        skill_name: str,
        args: str,
        description: str,
        prompt_prefix: str,
    ) -> Msg:
        """Generic handler for skill-activating slash commands.

        These commands inject the skill's workflow into the conversation
        as a system prompt, then let the agent follow the structured process.

        Args:
            command: The slash command name (e.g. "spec", "build")
            skill_name: The skill directory name (e.g. "spec-driven-development")
            args: User-provided arguments after the command
            description: Brief description of the skill
            prompt_prefix: Prefix for the injected prompt

        Returns:
            System message with skill activation confirmation
        """
        skill_content = self._load_skill_content(skill_name)

        if not skill_content:
            return await self._make_system_msg(
                f"**/{ command } — {description}**\n\n"
                f"Skill `{skill_name}` is not installed.\n\n"
                f"Install it from the Skills panel to use this command."
            )

        if args:
            return await self._make_system_msg(
                f"**/{command} — {description}**\n\n"
                f"Following the **{skill_name}** workflow:\n\n"
                f"{skill_content}\n\n"
                f"---\n\n"
                f"**Task:** {prompt_prefix}{args}"
            )

        return await self._make_system_msg(
            f"**/{command} — {description}**\n\n"
            f"Following the **{skill_name}** workflow:\n\n"
            f"{skill_content}\n\n"
            f"---\n\n"
            f"Please describe what you'd like to work on."
        )

    def _load_skill_content(self, skill_name: str) -> str:
        """Load SKILL.md content from active_skills directory.

        Args:
            skill_name: Name of the skill directory

        Returns:
            SKILL.md content or empty string if not found
        """
        try:
            agent_config = self._get_agent_config()
            workspace_dir = Path(agent_config.workspace_dir)
            skill_file = workspace_dir / "active_skills" / skill_name / "SKILL.md"
            if skill_file.exists():
                return skill_file.read_text(encoding="utf-8")
        except Exception as _skill_err:
            logger.debug("Failed to read skill file %s: %s", skill_name, _skill_err)
        return ""

    def _get_session_id(self) -> str:
        """Get current session ID from agent config."""
        try:
            config = self._get_agent_config()
            return getattr(config, "session_id", "default")
        except Exception as _sid_err:
            logger.debug("Failed to get session_id: %s", _sid_err)
            return "default"

    def _get_channel(self) -> str:
        """Get current channel from agent config."""
        try:
            config = self._get_agent_config()
            return getattr(config, "channel", "default")
        except Exception as _ch_err:
            logger.debug("Failed to get channel: %s", _ch_err)
            return "default"

    async def handle_conversation_command(self, query: str) -> Msg:
        """Process conversation system commands.

        Args:
            query: Command string (e.g., "/compact", "/new", "/message 5")

        Returns:
            System response message

        Raises:
            RuntimeError: If command is not recognized
        """
        messages = await self.memory.get_memory(
            prepend_summary=False,
        )
        # Parse command and arguments
        parts = query.strip().lstrip("/").split(" ", maxsplit=1)
        command = parts[0]
        args = parts[1] if len(parts) > 1 else ""
        logger.info(f"Processing command: {command}, args: {args}")

        handler = getattr(self, f"_process_{command}", None)
        if handler is None:
            raise RuntimeError(f"Unknown command: {query}")
        return await handler(messages, args)

    async def _process_mission(self, messages: list, args: str = "") -> Msg:
        from .mission.handler import handle_mission_command

        workspace_dir = Path.home() / ".xingzierai" / "workspace"
        workspace_dir.mkdir(parents=True, exist_ok=True)

        agent_id = getattr(self, "_agent_id", "default")
        session_id = getattr(self, "_session_id", "")

        def rewrite_fn(msgs, new_text):
            if msgs and hasattr(msgs[-1], "content"):
                msgs[-1] = Msg(role="user", content=new_text)

        full_query = f"/mission {args}" if args else "/mission"
        result = await handle_mission_command(
            query=full_query,
            msgs=messages,
            workspace_dir=workspace_dir,
            agent_id=agent_id,
            rewrite_fn=rewrite_fn,
            session_id=session_id,
        )

        if isinstance(result, str):
            return Msg(role="system", content=result)
        return Msg(
            role="system",
            content=f"Mission started: {result.get('loop_dir', 'unknown')}",
        )

    async def _process_proactive(self, messages: list, args: str = "") -> Msg:
        from .proactive.proactive_trigger import (
            enable_proactive_for_session,
            disable_proactive_for_session,
            is_proactive_enabled,
        )

        session_id = getattr(self, "_session_id", "default")

        if args.strip().lower() in ("off", "disable", "stop"):
            result = disable_proactive_for_session(session_id)
        elif args.strip().lower() in ("on", "enable", "start", ""):
            idle_minutes = 30
            parts = args.strip().split()
            for i, p in enumerate(parts):
                if p in ("--idle", "--minutes") and i + 1 < len(parts):
                    try:
                        idle_minutes = int(parts[i + 1])
                    except ValueError:
                        pass
            result = enable_proactive_for_session(session_id, idle_minutes)
        elif args.strip().lower() == "status":
            enabled = is_proactive_enabled(session_id)
            result = f"Proactive mode: {'enabled' if enabled else 'disabled'}"
        else:
            result = (
                "**Proactive Mode**\n\n"
                "Usage:\n"
                "- `/proactive` or `/proactive on` — enable (30 min idle)\n"
                "- `/proactive --idle 15` — enable with custom idle time\n"
                "- `/proactive off` — disable\n"
                "- `/proactive status` — check status\n\n"
                "When enabled, the agent will proactively reach out "
                "after the specified idle period."
            )

        return Msg(role="system", content=result)

    async def _process_dream(self, messages: list, args: str = "") -> Msg:
        from .hooks.memory_compaction import get_dream_prompt

        prompt = get_dream_prompt()
        return Msg(
            role="system",
            content=prompt,
        )

    async def handle_command(self, query: str) -> Msg:
        """Process system commands (alias for handle_conversation_command)."""
        return await self.handle_conversation_command(query)
