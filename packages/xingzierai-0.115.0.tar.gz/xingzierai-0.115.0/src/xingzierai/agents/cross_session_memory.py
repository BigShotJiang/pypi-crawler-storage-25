# -*- coding: utf-8 -*-
"""Cross-Session Persistent Memory.

Enterprise-level memory that persists across sessions, agents, and restarts.
Integrates with existing MDRM graph memory and Session event logs.

Architecture:
- CrossSessionMemory: Main interface for cross-session read/write
- MemoryStore: Persistent storage backend (JSON files, extensible to DB)
- SessionLinker: Auto-link related sessions by topic/entity overlap
- MemoryConsolidation: Merge short-term memories into long-term knowledge

Key principles:
1. Memory survives session boundaries and process restarts
2. Agents can read/write shared memories with namespace isolation
3. Related sessions are auto-linked for context retrieval
4. Short-term episodic memories consolidate into long-term semantic knowledge
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

_BACKGROUND_TASKS: set = set()


def _track_background_task(task: asyncio.Task) -> None:
    _BACKGROUND_TASKS.add(task)
    task.add_done_callback(_BACKGROUND_TASKS.discard)

_MEMORY_DIR = Path.home() / ".xingzierai" / "cross_session_memory"


class MemoryScope(str, Enum):
    PRIVATE = "private"
    AGENT_SHARED = "agent_shared"
    GLOBAL = "global"


class MemoryType(str, Enum):
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    ENTITY = "entity"


class MemoryTier(int, Enum):
    L1_WORKING = 1
    L2_EPISODIC = 2
    L3_SEMANTIC = 3

    @property
    def max_capacity(self) -> int:
        return {1: 50, 2: 500, 3: 2000}[self.value]

    @property
    def ttl_seconds(self) -> int:
        return {1: 3600, 2: 86400 * 30, 3: 0}[self.value]

    @property
    def promotion_threshold(self) -> float:
        return {1: 0.6, 2: 0.8, 3: 1.0}[self.value]

    @property
    def demotion_threshold(self) -> float:
        return {1: 0.0, 2: 0.2, 3: 0.3}[self.value]


@dataclass
class MemoryEntry:
    entry_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    content: str = ""
    memory_type: MemoryType = MemoryType.EPISODIC
    scope: MemoryScope = MemoryScope.PRIVATE
    agent_id: str = ""
    session_id: str = ""
    namespace: str = "default"
    tags: List[str] = field(default_factory=list)
    entities: List[str] = field(default_factory=list)
    importance: float = 0.5
    access_count: int = 0
    source_ids: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    expires_at: Optional[str] = None
    metadata: dict = field(default_factory=dict)
    strength: float = 1.0
    last_accessed_at: Optional[str] = None
    tier: int = 2


@dataclass
class SessionLink:
    link_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    session_a: str = ""
    session_b: str = ""
    similarity: float = 0.0
    shared_entities: List[str] = field(default_factory=list)
    shared_tags: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class EpisodeRecord:
    episode_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    session_id: str = ""
    agent_id: str = ""
    goal: str = ""
    reasoning_steps: List[str] = field(default_factory=list)
    actions_taken: List[str] = field(default_factory=list)
    outcome: str = ""
    success: bool = False
    reflection: str = ""
    raw_interaction: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "episode_id": self.episode_id,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "goal": self.goal,
            "reasoning_steps": self.reasoning_steps,
            "actions_taken": self.actions_taken,
            "outcome": self.outcome,
            "success": self.success,
            "reflection": self.reflection,
            "raw_interaction": self.raw_interaction,
            "created_at": self.created_at,
        }


class MemoryStore:
    """Persistent storage backend for cross-session memory.

    Uses JSON files for storage, organized by namespace.
    Can be extended to use SQLite, Redis, or vector databases.
    """

    MAX_ENTRIES = 5000
    MAX_LINKS = 10000
    MAX_EPISODES = 3000
    MAX_INDEX_KEYS = 10000
    STRENGTH_DECAY_THRESHOLD = 0.1

    EBINGHAUS_S = 1.0
    EBINGHAUS_DECAY_RATES = {
        MemoryType.EPISODIC: 0.48,
        MemoryType.SEMANTIC: 0.15,
        MemoryType.PROCEDURAL: 0.08,
        MemoryType.ENTITY: 0.10,
    }
    EBINGHAUS_REINFORCE_FACTOR = 0.3

    def __init__(self, base_dir: Optional[Path] = None):
        self._base_dir = base_dir or _MEMORY_DIR
        self._base_dir.mkdir(parents=True, exist_ok=True)
        self._entries: Dict[str, MemoryEntry] = {}
        self._links: Dict[str, SessionLink] = {}
        self._episodes: Dict[str, EpisodeRecord] = {}
        self._index_by_tag: Dict[str, Set[str]] = {}
        self._index_by_entity: Dict[str, Set[str]] = {}
        self._index_by_session: Dict[str, Set[str]] = {}
        self._index_by_agent: Dict[str, Set[str]] = {}
        self._lock = asyncio.Lock()
        self._last_cleanup_time = 0.0
        self._CLEANUP_INTERVAL = 60
        self._load()

    def _load(self):
        entries_file = self._base_dir / "entries.json"
        if entries_file.exists():
            try:
                data = json.loads(entries_file.read_text(encoding="utf-8"))
                for item in data:
                    entry = MemoryEntry(
                        entry_id=item.get("entry_id", uuid.uuid4().hex[:12]),
                        content=item.get("content", ""),
                        memory_type=MemoryType(item.get("memory_type", "episodic")),
                        scope=MemoryScope(item.get("scope", "private")),
                        agent_id=item.get("agent_id", ""),
                        session_id=item.get("session_id", ""),
                        namespace=item.get("namespace", "default"),
                        tags=item.get("tags", []),
                        entities=item.get("entities", []),
                        importance=item.get("importance", 0.5),
                        access_count=item.get("access_count", 0),
                        source_ids=item.get("source_ids", []),
                        created_at=item.get("created_at", datetime.now().isoformat()),
                        updated_at=item.get("updated_at", datetime.now().isoformat()),
                        expires_at=item.get("expires_at"),
                        metadata=item.get("metadata", {}),
                        strength=item.get("strength", 1.0),
                        last_accessed_at=item.get("last_accessed_at"),
                        tier=item.get("tier", 2),
                    )
                    self._entries[entry.entry_id] = entry
                    self._update_indexes(entry)
                logger.info("Loaded %d memory entries from disk", len(self._entries))
            except Exception as e:
                logger.warning("Failed to load memory entries: %s", e)

        links_file = self._base_dir / "session_links.json"
        if links_file.exists():
            try:
                data = json.loads(links_file.read_text(encoding="utf-8"))
                for item in data:
                    link = SessionLink(
                        link_id=item.get("link_id", uuid.uuid4().hex[:8]),
                        session_a=item.get("session_a", ""),
                        session_b=item.get("session_b", ""),
                        similarity=item.get("similarity", 0.0),
                        shared_entities=item.get("shared_entities", []),
                        shared_tags=item.get("shared_tags", []),
                        created_at=item.get("created_at", datetime.now().isoformat()),
                    )
                    self._links[link.link_id] = link
                logger.info("Loaded %d session links from disk", len(self._links))
            except Exception as e:
                logger.warning("Failed to load session links: %s", e)

        episodes_file = self._base_dir / "episodes.json"
        if episodes_file.exists():
            try:
                data = json.loads(episodes_file.read_text(encoding="utf-8"))
                for item in data[-self.MAX_EPISODES:]:
                    episode = EpisodeRecord(
                        episode_id=item.get("episode_id", uuid.uuid4().hex[:12]),
                        session_id=item.get("session_id", ""),
                        agent_id=item.get("agent_id", ""),
                        goal=item.get("goal", ""),
                        reasoning_steps=item.get("reasoning_steps", []),
                        actions_taken=item.get("actions_taken", []),
                        outcome=item.get("outcome", ""),
                        success=item.get("success", False),
                        reflection=item.get("reflection", ""),
                        raw_interaction=item.get("raw_interaction", ""),
                        created_at=item.get("created_at", datetime.now().isoformat()),
                    )
                    self._episodes[episode.episode_id] = episode
                logger.info("Loaded %d episode records from disk", len(self._episodes))
            except Exception as e:
                logger.warning("Failed to load episode records: %s", e)

    def _cleanup_expired_and_oversized(self):
        now = time.time()
        if now - self._last_cleanup_time < self._CLEANUP_INTERVAL:
            return
        self._last_cleanup_time = now

        now_iso = datetime.now().isoformat()
        expired_ids = []
        for eid, entry in self._entries.items():
            if entry.expires_at and entry.expires_at < now_iso:
                expired_ids.append(eid)
            else:
                self._update_entry_strength(entry)
                self._check_demotion(entry)
                if entry.strength < self.STRENGTH_DECAY_THRESHOLD and entry.access_count == 0:
                    expired_ids.append(eid)
                tier = MemoryTier(entry.tier)
                if tier.ttl_seconds > 0:
                    try:
                        from datetime import timezone
                        created = datetime.fromisoformat(entry.created_at)
                        if created.tzinfo is None:
                            age = (datetime.now() - created).total_seconds()
                        else:
                            age = (datetime.now(timezone.utc) - created).total_seconds()
                        if age > tier.ttl_seconds:
                            expired_ids.append(eid)
                    except Exception as _age_err:
                        pass
        for eid in expired_ids:
            self._remove_entry_from_indexes(eid)
            del self._entries[eid]
        if expired_ids:
            logger.info("Cleaned up %d expired/decayed memory entries", len(expired_ids))
        if len(self._entries) > self.MAX_ENTRIES:
            sorted_entries = sorted(
                self._entries.items(),
                key=lambda x: (x[1].strength, x[1].importance, x[1].access_count),
            )
            remove_count = len(self._entries) - self.MAX_ENTRIES
            for eid, _ in sorted_entries[:remove_count]:
                self._remove_entry_from_indexes(eid)
                del self._entries[eid]
            logger.info("Evicted %d low-strength entries (max=%d)", remove_count, self.MAX_ENTRIES)
        self._enforce_tier_capacity()
        if len(self._links) > self.MAX_LINKS:
            sorted_links = sorted(
                self._links.items(),
                key=lambda x: x[1].created_at if hasattr(x[1], "created_at") else "",
            )
            remove_count = len(self._links) - self.MAX_LINKS
            for lid, _ in sorted_links[:remove_count]:
                del self._links[lid]
            logger.info("Evicted %d old session links (max=%d)", remove_count, self.MAX_LINKS)
        if len(self._episodes) > self.MAX_EPISODES:
            sorted_episodes = sorted(
                self._episodes.items(),
                key=lambda x: x[1].created_at,
            )
            remove_count = len(self._episodes) - self.MAX_EPISODES
            for eid, _ in sorted_episodes[:remove_count]:
                del self._episodes[eid]
            logger.info("Evicted %d old episode records (max=%d)", remove_count, self.MAX_EPISODES)
        self._prune_stale_indexes()

    def _update_entry_strength(self, entry: MemoryEntry) -> float:
        try:
            from datetime import timezone
            ref_time = entry.last_accessed_at or entry.created_at
            ref_dt = datetime.fromisoformat(ref_time)
            now_dt = datetime.now(timezone.utc)
            age_days = max(0, (now_dt - ref_dt).total_seconds() / 86400)
        except Exception as _decay_err:
            logger.debug("Age calculation failed, using default: %s", _decay_err)
            age_days = 30.0

        decay_rate = self.EBINGHAUS_DECAY_RATES.get(
            entry.memory_type, self.EBINGHAUS_DECAY_RATES[MemoryType.EPISODIC]
        )
        retention = self.EBINGHAUS_S * max(0, 1.0 - decay_rate * (1.0 - 0.9 ** (1.0 / max(age_days, 0.01))))
        if age_days > 0:
            retention = max(0, 1.0 - decay_rate * (1.0 - (0.9 ** (1.0 / max(age_days, 1.0)))))
        else:
            retention = 1.0

        base_strength = entry.importance * 0.4 + min(entry.access_count / 10.0, 1.0) * 0.3 + retention * 0.3
        entry.strength = max(0.0, min(1.0, base_strength))
        return entry.strength

    def reinforce_entry(self, entry: MemoryEntry) -> None:
        boost = self.EBINGHAUS_REINFORCE_FACTOR * (1.0 - entry.strength)
        entry.strength = min(1.0, entry.strength + boost)
        entry.access_count += 1
        entry.last_accessed_at = datetime.now().isoformat()
        entry.updated_at = datetime.now().isoformat()
        self._check_promotion(entry)

    def _check_promotion(self, entry: MemoryEntry) -> None:
        current_tier = MemoryTier(entry.tier)
        if current_tier == MemoryTier.L3_SEMANTIC:
            return
        if entry.strength >= current_tier.promotion_threshold and entry.access_count >= 3:
            new_tier = MemoryTier(current_tier.value + 1)
            entry.tier = new_tier.value
            if new_tier == MemoryTier.L3_SEMANTIC:
                entry.memory_type = MemoryType.SEMANTIC
                entry.scope = MemoryScope.AGENT_SHARED
                entry.importance = min(1.0, entry.importance + 0.2)
            logger.info(
                "Memory %s promoted: L%d → L%d (strength=%.2f, accesses=%d)",
                entry.entry_id[:8], current_tier.value, new_tier.value,
                entry.strength, entry.access_count,
            )

    def _check_demotion(self, entry: MemoryEntry) -> None:
        current_tier = MemoryTier(entry.tier)
        if current_tier == MemoryTier.L1_WORKING:
            return
        if entry.strength < current_tier.demotion_threshold:
            new_tier = MemoryTier(current_tier.value - 1)
            entry.tier = new_tier.value
            if new_tier == MemoryTier.L2_EPISODIC and entry.memory_type == MemoryType.SEMANTIC:
                entry.memory_type = MemoryType.EPISODIC
            logger.info(
                "Memory %s demoted: L%d → L%d (strength=%.2f)",
                entry.entry_id[:8], current_tier.value, new_tier.value, entry.strength,
            )

    def _enforce_tier_capacity(self) -> None:
        tier_counts: Dict[int, int] = {1: 0, 2: 0, 3: 0}
        for entry in self._entries.values():
            tier_counts[entry.tier] = tier_counts.get(entry.tier, 0) + 1

        for tier_value, count in tier_counts.items():
            tier = MemoryTier(tier_value)
            cap = tier.max_capacity
            if count <= cap:
                continue
            overflow = count - cap
            tier_entries = [
                (eid, e) for eid, e in self._entries.items() if e.tier == tier_value
            ]
            tier_entries.sort(key=lambda x: (x[1].strength, x[1].access_count))
            for eid, entry in tier_entries[:overflow]:
                if tier_value > 1:
                    self._check_demotion(entry)
                    if entry.tier == tier_value:
                        self._remove_entry_from_indexes(eid)
                        del self._entries[eid]
                else:
                    self._remove_entry_from_indexes(eid)
                    del self._entries[eid]

    def _remove_entry_from_indexes(self, entry_id: str):
        entry = self._entries.get(entry_id)
        if not entry:
            return
        for tag in entry.tags:
            if tag in self._index_by_tag:
                self._index_by_tag[tag].discard(entry_id)
                if not self._index_by_tag[tag]:
                    del self._index_by_tag[tag]
        for entity in entry.entities:
            if entity in self._index_by_entity:
                self._index_by_entity[entity].discard(entry_id)
                if not self._index_by_entity[entity]:
                    del self._index_by_entity[entity]
        if entry.session_id in self._index_by_session:
            self._index_by_session[entry.session_id].discard(entry_id)
            if not self._index_by_session[entry.session_id]:
                del self._index_by_session[entry.session_id]
        if entry.agent_id in self._index_by_agent:
            self._index_by_agent[entry.agent_id].discard(entry_id)
            if not self._index_by_agent[entry.agent_id]:
                del self._index_by_agent[entry.agent_id]

    def _prune_stale_indexes(self):
        for index in (self._index_by_tag, self._index_by_entity,
                      self._index_by_session, self._index_by_agent):
            if len(index) <= self.MAX_INDEX_KEYS:
                continue
            sorted_keys = sorted(index.keys(), key=lambda k: len(index[k]))
            remove_count = len(index) - self.MAX_INDEX_KEYS
            for k in sorted_keys[:remove_count]:
                del index[k]
            logger.info("Pruned %d stale index keys (max=%d)", remove_count, self.MAX_INDEX_KEYS)

    def _persist(self):
        self._cleanup_expired_and_oversized()
        try:
            entries_file = self._base_dir / "entries.json"
            data = []
            for entry in self._entries.values():
                data.append({
                    "entry_id": entry.entry_id,
                    "content": entry.content,
                    "memory_type": entry.memory_type.value,
                    "scope": entry.scope.value,
                    "agent_id": entry.agent_id,
                    "session_id": entry.session_id,
                    "namespace": entry.namespace,
                    "tags": entry.tags,
                    "entities": entry.entities,
                    "importance": entry.importance,
                    "access_count": entry.access_count,
                    "source_ids": entry.source_ids,
                    "created_at": entry.created_at,
                    "updated_at": entry.updated_at,
                    "expires_at": entry.expires_at,
                    "metadata": entry.metadata,
                    "strength": entry.strength,
                    "last_accessed_at": entry.last_accessed_at,
                    "tier": entry.tier,
                })
            self._atomic_write(entries_file, json.dumps(data, ensure_ascii=False, indent=2))

            links_file = self._base_dir / "session_links.json"
            links_data = []
            for link in self._links.values():
                links_data.append({
                    "link_id": link.link_id,
                    "session_a": link.session_a,
                    "session_b": link.session_b,
                    "similarity": link.similarity,
                    "shared_entities": link.shared_entities,
                    "shared_tags": link.shared_tags,
                    "created_at": link.created_at,
                })
            self._atomic_write(links_file, json.dumps(links_data, ensure_ascii=False, indent=2))

            episodes_file = self._base_dir / "episodes.json"
            episodes_data = [ep.to_dict() for ep in self._episodes.values()]
            self._atomic_write(episodes_file, json.dumps(episodes_data, ensure_ascii=False, indent=2))
        except Exception as e:
            logger.warning("Failed to persist memory: %s", e)

    @staticmethod
    def _atomic_write(path: Path, content: str):
        import tempfile
        tmp_fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                f.write(content)
            os.replace(tmp_path, str(path))
        except Exception as _atomic_err:
            logger.debug("Atomic write failed for %s: %s", path, _atomic_err)
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    def _update_indexes(self, entry: MemoryEntry):
        for tag in entry.tags:
            if tag not in self._index_by_tag:
                self._index_by_tag[tag] = set()
            self._index_by_tag[tag].add(entry.entry_id)

        for entity in entry.entities:
            if entity not in self._index_by_entity:
                self._index_by_entity[entity] = set()
            self._index_by_entity[entity].add(entry.entry_id)

        if entry.session_id:
            if entry.session_id not in self._index_by_session:
                self._index_by_session[entry.session_id] = set()
            self._index_by_session[entry.session_id].add(entry.entry_id)

        if entry.agent_id:
            if entry.agent_id not in self._index_by_agent:
                self._index_by_agent[entry.agent_id] = set()
            self._index_by_agent[entry.agent_id].add(entry.entry_id)


class CrossSessionMemory:
    """Cross-session persistent memory interface.

    Provides:
    - write(): Store a memory entry with metadata
    - read(): Retrieve memories by ID, session, agent, or tags
    - search(): Semantic search across all memories
    - link_sessions(): Auto-link related sessions
    - consolidate(): Merge short-term memories into long-term knowledge
    - get_context(): Get relevant context from past sessions for current query
    """

    _instance: Optional["CrossSessionMemory"] = None

    def __init__(self, store: Optional[MemoryStore] = None):
        self.store = store or MemoryStore()
        self._consolidation_threshold = 3
        self._embedder = None
        self._embeddings_cache = None
        self._cache_entry_ids = None
        self._preload_task = None
        self._write_counter = 0
        self._token_accumulator = 0
        self._AUTO_CONSOLIDATE_WRITES = 10
        self._AUTO_CONSOLIDATE_TOKENS = 8000
        self._AUTO_REFLECT_WRITES = 20
        self._last_consolidate_time = 0.0
        self._MIN_CONSOLIDATE_INTERVAL = 300
        self._MAX_EMBEDDINGS_CACHE_ENTRIES = 2000

    def preload_embedder(self):
        """Background preload the sentence-transformers model.

        Call this at service startup so the first user request does not
        block on model loading (~2-5 seconds).
        """
        if self._embedder is not None or self._preload_task is not None:
            return

        import threading

        def _load():
            try:
                from .embedding_loader import get_embedder
                loader = get_embedder()
                loader.preload()
                if loader.is_available:
                    self._embedder = loader
                    logger.info("[CrossSessionMemory] Embedding model preloaded via EmbeddingLoader (backend=%s)", loader.backend.value)
                else:
                    logger.info("[CrossSessionMemory] No embedding backend available, semantic search degraded")
            except Exception as e:
                logger.warning("[CrossSessionMemory] Failed to preload embedding model: %s", e)

        self._preload_task = threading.Thread(target=_load, daemon=True)
        self._preload_task.start()

    @classmethod
    def get_instance(cls) -> "CrossSessionMemory":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        cls._instance = None

    async def write(
        self,
        content: str,
        memory_type: MemoryType = MemoryType.EPISODIC,
        scope: MemoryScope = MemoryScope.PRIVATE,
        agent_id: str = "",
        session_id: str = "",
        namespace: str = "default",
        tags: Optional[List[str]] = None,
        entities: Optional[List[str]] = None,
        importance: float = 0.5,
        source_ids: Optional[List[str]] = None,
        metadata: Optional[dict] = None,
    ) -> str:
        async with self.store._lock:
            initial_tier = {
                MemoryType.EPISODIC: MemoryTier.L2_EPISODIC.value,
                MemoryType.SEMANTIC: MemoryTier.L3_SEMANTIC.value,
                MemoryType.PROCEDURAL: MemoryTier.L2_EPISODIC.value,
                MemoryType.ENTITY: MemoryTier.L2_EPISODIC.value,
            }.get(memory_type, MemoryTier.L2_EPISODIC.value)

            entry = MemoryEntry(
                content=content,
                memory_type=memory_type,
                scope=scope,
                agent_id=agent_id,
                session_id=session_id,
                namespace=namespace,
                tags=tags or [],
                entities=entities or [],
                importance=importance,
                source_ids=source_ids or [],
                metadata=metadata or {},
                tier=initial_tier,
            )
            self.store._entries[entry.entry_id] = entry
            self.store._update_indexes(entry)
            self.store._persist()
            self.invalidate_search_cache()

        logger.debug(
            "Wrote memory %s (type=%s, scope=%s, agent=%s, session=%s)",
            entry.entry_id, memory_type.value, scope.value, agent_id, session_id,
        )

        self._write_counter += 1
        self._token_accumulator += len(content) // 4
        if self._should_auto_consolidate():
            task = asyncio.create_task(self._auto_consolidate_background())
            _track_background_task(task)

        return entry.entry_id

    def _should_auto_consolidate(self) -> bool:
        import time as _time
        now = _time.time()
        if now - self._last_consolidate_time < self._MIN_CONSOLIDATE_INTERVAL:
            return False
        if self._write_counter >= self._AUTO_CONSOLIDATE_WRITES:
            return True
        if self._token_accumulator >= self._AUTO_CONSOLIDATE_TOKENS:
            return True
        return False

    async def _auto_consolidate_background(self) -> None:
        import time as _time
        try:
            self._last_consolidate_time = _time.time()
            self._write_counter = 0
            self._token_accumulator = 0
            count = await self.consolidate()
            logger.info("[AutoConsolidate] Consolidated %d entity groups", count)
            if self._write_counter >= self._AUTO_REFLECT_WRITES:
                await self.reflect()
        except Exception as e:
            logger.warning("[AutoConsolidate] Failed: %s", e)

    async def read(self, entry_id: str) -> Optional[MemoryEntry]:
        entry = self.store._entries.get(entry_id)
        if entry:
            self.store.reinforce_entry(entry)
        return entry

    async def record_episode(
        self,
        goal: str,
        reasoning_steps: List[str],
        actions_taken: List[str],
        outcome: str,
        success: bool,
        session_id: str = "",
        agent_id: str = "",
        reflection: str = "",
        raw_interaction: str = "",
    ) -> str:
        async with self.store._lock:
            episode = EpisodeRecord(
                session_id=session_id,
                agent_id=agent_id,
                goal=goal,
                reasoning_steps=reasoning_steps,
                actions_taken=actions_taken,
                outcome=outcome,
                success=success,
                reflection=reflection,
                raw_interaction=raw_interaction,
            )
            self.store._episodes[episode.episode_id] = episode
            self.store._persist()

        logger.debug(
            "Recorded episode %s (success=%s, agent=%s, session=%s)",
            episode.episode_id, success, agent_id, session_id,
        )
        return episode.episode_id

    async def search_episodes(
        self,
        goal: str = "",
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        success_only: bool = False,
        limit: int = 20,
    ) -> List[EpisodeRecord]:
        results = list(self.store._episodes.values())
        if goal:
            goal_lower = goal.lower()
            results = [ep for ep in results if goal_lower in ep.goal.lower() or goal_lower in ep.outcome.lower()]
        if session_id:
            results = [ep for ep in results if ep.session_id == session_id]
        if agent_id:
            results = [ep for ep in results if ep.agent_id == agent_id]
        if success_only:
            results = [ep for ep in results if ep.success]
        results.sort(key=lambda ep: ep.created_at, reverse=True)
        return results[:limit]

    async def search(
        self,
        query: str = "",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        namespace: Optional[str] = None,
        tags: Optional[List[str]] = None,
        entities: Optional[List[str]] = None,
        memory_type: Optional[MemoryType] = None,
        scope: Optional[MemoryScope] = None,
        min_importance: float = 0.0,
        min_strength: float = 0.0,
        min_tier: int = 1,
        limit: int = 20,
        use_semantic: bool = True,
        caller_agent_id: Optional[str] = None,
        caller_session_id: Optional[str] = None,
    ) -> List[MemoryEntry]:
        async with self.store._lock:
            query_lower = query.lower() if query else ""

            if use_semantic and query:
                semantic_results = await self._semantic_search(query, limit=limit * 3)
                candidate_ids = {e.entry_id for e in semantic_results}
            else:
                candidate_ids = None

            results = []
            for entry in self.store._entries.values():
                if candidate_ids is not None and entry.entry_id not in candidate_ids:
                    if query_lower and query_lower not in entry.content.lower():
                        continue

                if entry.scope == MemoryScope.PRIVATE:
                    can_access = False
                    if agent_id and entry.agent_id == agent_id:
                        can_access = True
                    if session_id and entry.session_id == session_id:
                        can_access = True
                    if caller_agent_id and entry.agent_id == caller_agent_id:
                        can_access = True
                    if caller_session_id and entry.session_id == caller_session_id:
                        can_access = True
                    if not can_access:
                        continue

                if scope and entry.scope != scope:
                    continue

                if namespace and entry.namespace != namespace:
                    continue

                if memory_type and entry.memory_type != memory_type:
                    continue

                if entry.importance < min_importance:
                    continue

                if entry.strength < min_strength:
                    continue

                if entry.tier < min_tier:
                    continue

                if tags and not all(t in entry.tags for t in tags):
                    continue

                if entities and not any(e in entry.entities for e in entities):
                    continue

                results.append(entry)

            results.sort(key=lambda e: self._recency_score(e), reverse=True)
            return results[:limit]

    @staticmethod
    def _recency_score(entry: MemoryEntry) -> float:
        tier_boost = {3: 0.15, 2: 0.0, 1: -0.1}.get(entry.tier, 0.0)
        base = entry.strength * 0.45 + entry.importance * 0.25 + min(entry.access_count / 10.0, 1.0) * 0.15 + tier_boost
        return base

    async def _semantic_search(self, query: str, limit: int = 60) -> List[MemoryEntry]:
        try:
            import numpy as np
        except ImportError:
            return list(self.store._entries.values())

        if not hasattr(self, '_embedder') or self._embedder is None:
            try:
                from .embedding_loader import get_embedder
                loader = get_embedder()
                loader.preload()
                if loader.is_available:
                    self._embedder = loader
                else:
                    return list(self.store._entries.values())
            except Exception as e:
                logger.warning("Failed to load embedding model: %s", e)
                return list(self.store._entries.values())

        entries = list(self.store._entries.values())
        if not entries:
            return []

        if len(entries) > self._MAX_EMBEDDINGS_CACHE_ENTRIES:
            entries.sort(key=lambda e: self._recency_score(e), reverse=True)
            entries = entries[:self._MAX_EMBEDDINGS_CACHE_ENTRIES]

        loop = asyncio.get_event_loop()

        if not hasattr(self, '_embeddings_cache') or self._embeddings_cache is None:
            texts = [e.content[:512] for e in entries]
            self._embeddings_cache = await loop.run_in_executor(
                None, lambda: self._embedder.encode(texts)
            )
            self._cache_entry_ids = [e.entry_id for e in entries]

        if len(self._cache_entry_ids) != len(entries):
            texts = [e.content[:512] for e in entries]
            self._embeddings_cache = await loop.run_in_executor(
                None, lambda: self._embedder.encode(texts)
            )
            self._cache_entry_ids = [e.entry_id for e in entries]

        query_emb = await loop.run_in_executor(
            None, lambda: self._embedder.encode([query])
        )
        similarities = np.dot(self._embeddings_cache, query_emb.T).flatten()
        top_indices = np.argsort(similarities)[::-1][:limit]

        id_to_entry = {e.entry_id: e for e in entries}
        return [id_to_entry[self._cache_entry_ids[i]] for i in top_indices if self._cache_entry_ids[i] in id_to_entry]

    def invalidate_search_cache(self):
        self._embeddings_cache = None
        self._cache_entry_ids = None

    async def get_context(
        self,
        current_query: str,
        agent_id: str = "",
        session_id: str = "",
        max_entries: int = 5,
        min_tier: int = 2,
        min_strength: float = 0.3,
    ) -> str:
        relevant = await self.search(
            query=current_query,
            agent_id=agent_id or None,
            min_importance=0.3,
            min_tier=min_tier,
            min_strength=min_strength,
            limit=max_entries * 2,
        )

        if session_id:
            linked_sessions = await self.get_linked_sessions(session_id)
            for link in linked_sessions[:3]:
                other_session = link.session_b if link.session_a == session_id else link.session_a
                session_entries = await self.search(
                    session_id=other_session,
                    min_importance=0.5,
                    min_tier=min_tier,
                    min_strength=min_strength,
                    limit=3,
                )
                relevant.extend(session_entries)

        relevant.sort(key=lambda e: (e.tier, e.strength, e.importance), reverse=True)
        relevant = relevant[:max_entries]

        if not relevant:
            return ""

        parts = []
        for entry in relevant:
            time_ago = self._time_ago(entry.created_at)
            tier_name = {1: "L1工作", 2: "L2情景", 3: "L3语义"}.get(entry.tier, "L?")
            parts.append(
                f"[{tier_name} | {entry.memory_type.value} | {time_ago} | strength={entry.strength:.2f}]\n"
                f"{entry.content}"
            )

        return "\n\n---\n\n".join(parts)

    async def link_sessions(
        self,
        session_a: str,
        session_b: str,
        similarity: float = 0.0,
        shared_entities: Optional[List[str]] = None,
        shared_tags: Optional[List[str]] = None,
    ) -> str:
        for link in self.store._links.values():
            if {link.session_a, link.session_b} == {session_a, session_b}:
                link.similarity = max(link.similarity, similarity)
                if shared_entities:
                    link.shared_entities = list(set(link.shared_entities + shared_entities))
                if shared_tags:
                    link.shared_tags = list(set(link.shared_tags + shared_tags))
                self.store._persist()
                return link.link_id

        link = SessionLink(
            session_a=session_a,
            session_b=session_b,
            similarity=similarity,
            shared_entities=shared_entities or [],
            shared_tags=shared_tags or [],
        )
        self.store._links[link.link_id] = link
        self.store._persist()
        return link.link_id

    async def get_linked_sessions(self, session_id: str) -> List[SessionLink]:
        links = []
        for link in self.store._links.values():
            if link.session_a == session_id or link.session_b == session_id:
                links.append(link)
        links.sort(key=lambda l: l.similarity, reverse=True)
        return links

    async def auto_link_sessions(self, session_id: str) -> int:
        current_entries = await self.search(
            session_id=session_id,
            limit=50,
        )
        if not current_entries:
            return 0

        current_entities = set()
        current_tags = set()
        for entry in current_entries:
            current_entities.update(entry.entities)
            current_tags.update(entry.tags)

        if not current_entities and not current_tags:
            return 0

        other_sessions = set()
        for entity in current_entities:
            if entity in self.store._index_by_entity:
                for eid in self.store._index_by_entity[entity]:
                    entry = self.store._entries.get(eid)
                    if entry and entry.session_id and entry.session_id != session_id:
                        other_sessions.add(entry.session_id)

        linked_count = 0
        for other_session in other_sessions:
            other_entries = await self.search(session_id=other_session, limit=50)
            other_entities = set()
            other_tags = set()
            for entry in other_entries:
                other_entities.update(entry.entities)
                other_tags.update(entry.tags)

            shared_entities = list(current_entities & other_entities)
            shared_tags = list(current_tags & other_tags)

            if shared_entities or shared_tags:
                similarity = (
                    len(shared_entities) / max(1, len(current_entities | other_entities)) * 0.6
                    + len(shared_tags) / max(1, len(current_tags | other_tags)) * 0.4
                )
                await self.link_sessions(
                    session_id, other_session,
                    similarity=similarity,
                    shared_entities=shared_entities,
                    shared_tags=shared_tags,
                )
                linked_count += 1

        return linked_count

    async def consolidate(
        self,
        agent_id: str = "",
        namespace: str = "default",
    ) -> int:
        episodic = await self.search(
            memory_type=MemoryType.EPISODIC,
            agent_id=agent_id or None,
            namespace=namespace or None,
            limit=100,
        )

        entity_groups: Dict[str, List[MemoryEntry]] = {}
        tag_groups: Dict[str, List[MemoryEntry]] = {}

        for entry in episodic:
            for entity in entry.entities:
                if entity not in entity_groups:
                    entity_groups[entity] = []
                entity_groups[entity].append(entry)
            for tag in entry.tags:
                if tag not in tag_groups:
                    tag_groups[tag] = []
                tag_groups[tag].append(entry)

        consolidated_count = 0

        for entity, entries in entity_groups.items():
            if len(entries) < self._consolidation_threshold:
                continue

            combined_content = "\n".join(
                f"- {e.content[:200]}" for e in entries[:10]
            )

            semantic_content = await self._llm_consolidate(entity, combined_content)
            if not semantic_content:
                semantic_content = f"[Consolidated knowledge about '{entity}']\n{combined_content}"

            existing = await self.search(
                entities=[entity],
                memory_type=MemoryType.SEMANTIC,
                agent_id=agent_id or None,
                namespace=namespace or None,
                limit=1,
            )

            if existing:
                existing[0].content = semantic_content
                existing[0].importance = min(1.0, existing[0].importance + 0.1)
                existing[0].source_ids = [e.entry_id for e in entries[:10]]
                existing[0].updated_at = datetime.now().isoformat()
            else:
                await self.write(
                    content=semantic_content,
                    memory_type=MemoryType.SEMANTIC,
                    scope=MemoryScope.AGENT_SHARED,
                    agent_id=agent_id,
                    namespace=namespace,
                    tags=[entity, "consolidated"],
                    entities=[entity],
                    importance=0.7,
                    source_ids=[e.entry_id for e in entries[:10]],
                )
            consolidated_count += 1

        for tag, entries in tag_groups.items():
            if len(entries) < self._consolidation_threshold:
                continue
            if any(tag in e.entities for e in entries):
                continue

            combined_content = "\n".join(
                f"- {e.content[:200]}" for e in entries[:10]
            )
            semantic_content = await self._llm_consolidate(tag, combined_content)
            if not semantic_content:
                continue

            await self.write(
                content=semantic_content,
                memory_type=MemoryType.SEMANTIC,
                scope=MemoryScope.AGENT_SHARED,
                agent_id=agent_id,
                namespace=namespace,
                tags=[tag, "consolidated"],
                entities=[tag],
                importance=0.6,
                source_ids=[e.entry_id for e in entries[:10]],
            )
            consolidated_count += 1

        return consolidated_count

    async def _llm_consolidate(self, topic: str, raw_content: str) -> Optional[str]:
        try:
            from xingzierai.agents.local_model_dispatcher import get_local_model_dispatcher
            dispatcher = get_local_model_dispatcher()

            prompt = (
                f"请将以下关于'{topic}'的多条记忆整合为一条简洁的语义知识摘要。"
                f"要求：1)提取共性知识 2)消除矛盾 3)保留关键细节 4)不超过200字\n\n"
                f"原始记忆：\n{raw_content}\n\n整合摘要："
            )

            result = await dispatcher.dispatch(
                task_type="memory_compact",
                input_text=prompt,
                fallback_fn=lambda: self._simple_consolidate(topic, raw_content),
            )
            if result and len(result.strip()) > 10:
                return result.strip()
        except Exception as e:
            logger.debug("LLM consolidation failed, trying free model: %s", e)

        try:
            from xingzierai.smart_llm_client import SmartLLMClient
            client = SmartLLMClient._instance
            if client is not None:
                result = await client.ask_free_model(
                    prompt=f"请将以下关于'{topic}'的多条记忆整合为一条简洁的语义知识摘要。要求：1)提取共性知识 2)消除矛盾 3)保留关键细节 4)不超过200字\n\n原始记忆：\n{raw_content}\n\n整合摘要：",
                    system="你是一个记忆整合助手。将多条记忆合并为一条简洁摘要。",
                    max_tokens=256,
                )
                if result and len(result.strip()) > 10:
                    logger.info("CrossSessionMemory: consolidation using free model (cost=$0.00)")
                    return result.strip()
        except Exception as e:
            logger.debug("Free model consolidation failed: %s", e)

        return self._simple_consolidate(topic, raw_content)

    def _simple_consolidate(self, topic: str, raw_content: str) -> Optional[str]:
        if not raw_content.strip():
            return None
        return f"[Consolidated knowledge about '{topic}']\n{raw_content}"

    async def reflect(
        self,
        agent_id: str = "",
        namespace: str = "default",
        min_episodes: int = 3,
    ) -> Dict[str, Any]:
        episodes = await self.search_episodes(
            agent_id=agent_id or None,
            success_only=False,
            limit=50,
        )
        if len(episodes) < min_episodes:
            return {"reflections": [], "episode_count": len(episodes), "skipped": True}

        success_rate = sum(1 for ep in episodes if ep.success) / len(episodes)
        goals = [ep.goal for ep in episodes if ep.goal]
        common_goals: Dict[str, int] = {}
        for g in goals:
            key = g.lower()[:50]
            common_goals[key] = common_goals.get(key, 0) + 1

        reflections = []
        if success_rate < 0.5:
            reflections.append({
                "type": "low_success_rate",
                "insight": f"Success rate is {success_rate:.0%} across {len(episodes)} episodes",
                "recommendation": "Review failing episodes for common patterns",
            })

        failed_episodes = [ep for ep in episodes if not ep.success]
        if failed_episodes:
            common_outcomes: Dict[str, int] = {}
            for ep in failed_episodes:
                key = ep.outcome.lower()[:30]
                common_outcomes[key] = common_outcomes.get(key, 0) + 1
            top_failure = max(common_outcomes.items(), key=lambda x: x[1])
            reflections.append({
                "type": "recurring_failure",
                "insight": f"Most common failure: '{top_failure[0]}' ({top_failure[1]} times)",
                "recommendation": "Investigate root cause of this recurring failure pattern",
            })

        recurring_goals = [(g, c) for g, c in common_goals.items() if c >= 2]
        if recurring_goals:
            top_goal = max(recurring_goals, key=lambda x: x[1])
            reflections.append({
                "type": "recurring_goal",
                "insight": f"Goal '{top_goal[0]}' attempted {top_goal[1]} times",
                "recommendation": "Consider creating a reusable template or tool for this recurring goal",
            })

        reflection_entry = await self.write(
            content=f"[Reflection] {len(reflections)} insights from {len(episodes)} episodes (success_rate={success_rate:.0%})",
            memory_type=MemoryType.SEMANTIC,
            scope=MemoryScope.AGENT_SHARED,
            agent_id=agent_id,
            namespace=namespace,
            tags=["reflection", "auto-generated"],
            importance=0.8,
        )

        return {
            "reflections": reflections,
            "episode_count": len(episodes),
            "success_rate": success_rate,
            "reflection_entry_id": reflection_entry,
            "skipped": False,
        }

    async def delete(self, entry_id: str) -> bool:
        async with self.store._lock:
            if entry_id in self.store._entries:
                entry = self.store._entries.pop(entry_id)
                for tag in getattr(entry, 'tags', []):
                    if tag in self.store._index_by_tag:
                        self.store._index_by_tag[tag].discard(entry_id)
                        if not self.store._index_by_tag[tag]:
                            del self.store._index_by_tag[tag]
                for entity in getattr(entry, 'entities', []):
                    if entity in self.store._index_by_entity:
                        self.store._index_by_entity[entity].discard(entry_id)
                        if not self.store._index_by_entity[entity]:
                            del self.store._index_by_entity[entity]
                sid = getattr(entry, 'session_id', None)
                if sid and sid in self.store._index_by_session:
                    self.store._index_by_session[sid].discard(entry_id)
                    if not self.store._index_by_session[sid]:
                        del self.store._index_by_session[sid]
                aid = getattr(entry, 'agent_id', None)
                if aid and aid in self.store._index_by_agent:
                    self.store._index_by_agent[aid].discard(entry_id)
                    if not self.store._index_by_agent[aid]:
                        del self.store._index_by_agent[aid]
                self.store._persist()
                return True
        return False

    async def get_stats(self) -> dict:
        by_type = {}
        by_scope = {}
        by_namespace = {}
        by_tier = {1: 0, 2: 0, 3: 0}
        for entry in self.store._entries.values():
            t = entry.memory_type.value
            by_type[t] = by_type.get(t, 0) + 1
            s = entry.scope.value
            by_scope[s] = by_scope.get(s, 0) + 1
            ns = entry.namespace
            by_namespace[ns] = by_namespace.get(ns, 0) + 1
            by_tier[entry.tier] = by_tier.get(entry.tier, 0) + 1

        return {
            "total_entries": len(self.store._entries),
            "by_type": by_type,
            "by_scope": by_scope,
            "by_namespace": by_namespace,
            "by_tier": by_tier,
            "session_links": len(self.store._links),
            "unique_agents": len(self.store._index_by_agent),
            "unique_sessions": len(self.store._index_by_session),
            "unique_entities": len(self.store._index_by_entity),
            "avg_strength": sum(e.strength for e in self.store._entries.values()) / max(1, len(self.store._entries)),
            "low_strength_count": sum(1 for e in self.store._entries.values() if e.strength < 0.3),
        }

    def _time_ago(self, iso_time: str) -> str:
        try:
            dt = datetime.fromisoformat(iso_time)
            delta = datetime.now() - dt
            seconds = int(delta.total_seconds())
            if seconds < 60:
                return f"{seconds}s ago"
            if seconds < 3600:
                return f"{seconds // 60}m ago"
            if seconds < 86400:
                return f"{seconds // 3600}h ago"
            return f"{seconds // 86400}d ago"
        except Exception as _fmt_err:
            logger.debug("Time format error: %s", _fmt_err)
            return "unknown"
