# -*- coding: utf-8 -*-
"""
Nuwa & Darwin Integration Engine

Deep integration of Nuwa (skill creation) and Darwin (skill evolution)
into XINGZIER AI core.

Nuwa - 思维蒸馏引擎
    - extract_perspective(name): 蒸馏人物心智模型
    - extract_domain_skill(topic): 蒸馏主题技能

Darwin - 技能进化引擎  
    - evaluate_skill(): 8维度评估(100分)
    - optimize(): 棘轮机制优化
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from pydantic import BaseModel
import frontmatter
import httpx
import asyncio

logger = logging.getLogger(__name__)


class MentalModel(BaseModel):
    """心智模型"""
    name: str
    description: str
    examples: list[str] = []


class DecisionHeuristic(BaseModel):
    """决策启发式"""
    condition: str
    action: str
    rationale: str


class ExpressionDNA(BaseModel):
    """表达DNA"""
    tone: str
    rhythm: list[str]
    vocabulary_preferences: list[str] = []


class PerspectiveSkill(BaseModel):
    """蒸馏后的视角技能"""
    name: str
    description: str
    mental_models: list[MentalModel]
    decision_heuristics: list[DecisionHeuristic]
    expression_dna: ExpressionDNA
    anti_patterns: list[str] = []
    honest_boundaries: list[str] = []
    source_person: str


class SkillEvaluation(BaseModel):
    """技能评估结果"""
    total_score: float
    structure_score: float
    effect_score: float
    dimensions: dict[str, float]
    strengths: list[str]
    weaknesses: list[str]
    suggestions: list[str]


class NuwaEngine:
    """
    女娲思维蒸馏引擎
    
    将任何人的思维方式蒸馏为可执行的技能
    """

    # JSON 提取辅助函数
    @staticmethod
    def _extract_json(text: str) -> Any:
        """从 LLM 返回中提取 JSON（支持对象和数组）"""
        text = text.strip()
        import json
        import re
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        match = re.search(r'```(?:json)?\s*\n(.*?)\n```', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass
        for start_char, end_char in [('{', '}'), ('[', ']')]:
            start = text.find(start_char)
            end = text.rfind(end_char)
            if start != -1 and end != -1 and end > start:
                try:
                    return json.loads(text[start:end+1])
                except json.JSONDecodeError:
                    pass
        return None

    def __init__(self, workspace_dir: Path):
        self.workspace_dir = workspace_dir
        self.customized_skills_dir = workspace_dir / "customized_skills"

    async def extract_person_perspective(
        self,
        person_name: str,
        domains: list[str] = None,
    ) -> PerspectiveSkill:
        """
        蒸馏名人的思维方式
        
        Args:
            person_name: 人物名称
            domains: 专业领域列表
            
        Returns:
            PerspectiveSkill: 蒸馏后的视角技能
        """
        logger.info(f"NuwaEngine.extract_person_perspective: 开始蒸馏 {person_name}")
        logger.info(f"NuwaEngine.extract_person_perspective: 调用 _parallel_research")
        research_data = await self._parallel_research(person_name, domains or [])
        logger.info(f"NuwaEngine.extract_person_perspective: _parallel_research 返回")
        
        has_sources = any(research_data.get("sources", {}).values())
        has_quotes = bool(research_data.get("raw_quotes"))
        
        mental_models = await self._extract_mental_models(research_data)
        heuristics = await self._extract_heuristics(research_data)
        expression_dna = await self._extract_expression_dna(research_data)
        
        if not mental_models and not heuristics and (has_sources or has_quotes):
            logger.warning(f"NuwaEngine: 首次提取为空，尝试简化 prompt 重试")
            mental_models = await self._extract_mental_models_simple(research_data)
            heuristics = await self._extract_heuristics_simple(research_data)
        
        # 3. 构建技能
        skill = PerspectiveSkill(
            name=f"{person_name}-perspective",
            description=f"从{person_name}的公开言论中蒸馏的思维框架",
            mental_models=mental_models,
            decision_heuristics=heuristics,
            expression_dna=expression_dna,
            anti_patterns=await self._extract_anti_patterns(research_data),
            honest_boundaries=[
                "蒸馏不了直觉——框架能提取，灵感不能",
                "捕捉不了突变——截止到调研时间的快照",
                "公开表达 ≠ 真实想法——只能基于公开信息",
            ],
            source_person=person_name,
        )
        
        return skill

    async def _parallel_research(
        self, 
        name: str, 
        domains: list[str]
    ) -> dict[str, Any]:
        """六路并行采集"""
        from xingzierai.smart_llm_client import SmartLLMClient
        
        logger.info(f"NuwaEngine._parallel_research: 创建 SmartLLMClient")
        client = SmartLLMClient()
        logger.info(f"NuwaEngine._parallel_research: SmartLLMClient 创建完成")
        domain_str = f"在{', '.join(domains)}领域" if domains else ""
        
        # 六路并行采集 prompt
        research_prompt = f"""请作为思维蒸馏研究员，全面收集"{name}"{domain_str}的公开思维信息。

请从以下六个维度进行分析，每个维度列出 2-4 条具体信息：

1. **著作观点**：重要书籍、论文、文章中的核心观点
2. **公开演讲**：播客、访谈、演讲中的关键表述
3. **社交媒体**：推文、帖子中的直接观点表达
4. **争议批评**：外界对其思维的批评和质疑
5. **关键决策**：标志性决策及其背后的思维逻辑
6. **时间演变**：思维随时间的变化和成长轨迹

请以 JSON 格式返回：
```json
{{
  "books": [{{"title": "作品名", "key_idea": "核心观点"}}, ...],
  "podcasts": [{{"source": "来源", "quote": "关键引述"}} , ...],
  "social_media": [{{"platform": "平台", "content": "内容"}} , ...],
  "critics": [{{"criticism": "批评点", "context": "背景"}} , ...],
  "decisions": [{{"decision": "决策", "thinking": "思维逻辑"}} , ...],
  "timeline": [{{"period": "时期", "evolution": "思维变化"}} , ...],
  "raw_quotes": ["直接引述1", "直接引述2", ...]
}}
```

只返回 JSON，不要其他内容。"""

        logger.info(f"NuwaEngine._parallel_research: 开始研究 {name}")
        try:
            response = await client.ask(research_prompt, system="你是专业的思维分析师，擅长从公开信息中提取人物的思维模式。", smart_routing=False)
            logger.info(f"NuwaEngine._parallel_research: LLM 返回 {len(response)} 字符: {response[:500]}...")
            data = self._extract_json(response)
            logger.info(f"NuwaEngine._research_person: 解析结果 data={data is not None}, type={type(data).__name__ if data else 'None'}")
            if data and isinstance(data, dict):
                return {
                    "name": name,
                    "domains": domains,
                    "sources": {
                        "books": data.get("books", []),
                        "podcasts": data.get("podcasts", []),
                        "social_media": data.get("social_media", []),
                        "critics": data.get("critics", []),
                        "decisions": data.get("decisions", []),
                        "timeline": data.get("timeline", []),
                    },
                    "raw_quotes": data.get("raw_quotes", []),
                }
            else:
                logger.warning(f"LLM research for {name}: JSON 解析失败，将原始文本作为 raw_quotes 保留")
                return {
                    "name": name,
                    "domains": domains,
                    "sources": {"books": [], "podcasts": [], "social_media": [], "critics": [], "decisions": [], "timeline": []},
                    "raw_quotes": [response[:500]] if response else [],
                }
        except Exception as e:
            logger.error(f"LLM research failed for {name}: {e}")
            return {
                "name": name,
                "domains": domains,
                "sources": {"books": [], "podcasts": [], "social_media": [], "critics": [], "decisions": [], "timeline": []},
                "raw_quotes": [],
            }

    async def _extract_mental_models(self, research: dict) -> list[MentalModel]:
        """从研究数据中提炼心智模型"""
        from xingzierai.smart_llm_client import SmartLLMClient
        
        client = SmartLLMClient()
        research_summary = self._summarize_research(research)
        
        prompt = f"""基于以下研究材料，提炼"{research['name']}"的核心心智模型。

研究材料摘要：
{research_summary}

请提炼 3-5 个核心心智模型，每个包含：
- name: 模型名称（简洁有力）
- description: 模型描述（2-3 句解释）
- examples: 具体应用例子（2-3 个）

以 JSON 数组格式返回：
```json
[
  {{
    "name": "第一性原理思维",
    "description": "从最基本原理出发重新推导，而非依赖类比或经验",
    "examples": ["拆解电池成本到原材料层面", "重新思考火箭回收的经济学"]
  }}
]
```

只返回 JSON 数组。"""

        try:
            response = await client.ask(prompt, system="你是认知科学家，擅长分析和提炼思维模型。", smart_routing=False)
            logger.info(f"NuwaEngine._extract_mental_models: LLM 返回 {len(response)} 字符: {response[:300]}...")
            data = self._extract_json(response)
            logger.info(f"NuwaEngine._extract_mental_models: 解析结果 data={data is not None}, type={type(data).__name__ if data else 'None'}")
            if data and isinstance(data, list):
                return [
                    MentalModel(
                        name=item.get("name", ""),
                        description=item.get("description", ""),
                        examples=item.get("examples", []),
                    )
                    for item in data
                    if item.get("name") and item.get("description")
                ]
        except Exception as e:
            logger.warning(f"LLM mental model extraction failed: {e}")
        
        return []

    async def _extract_mental_models_simple(self, research: dict) -> list[MentalModel]:
        """简化版心智模型提取，使用更宽松的 prompt"""
        from xingzierai.smart_llm_client import SmartLLMClient
        
        client = SmartLLMClient()
        research_summary = self._summarize_research(research)
        
        prompt = f"""根据以下关于"{research['name']}"的信息，列出他/她的核心思维模型。

信息：
{research_summary[:1000]}

请返回 JSON 数组，每个元素包含 name 和 description：
[{{"name": "模型名", "description": "简短描述"}}]"""

        try:
            response = await client.ask(prompt, system="你是一个简洁的分析助手。", smart_routing=False)
            data = self._extract_json(response)
            if data and isinstance(data, list):
                return [
                    MentalModel(
                        name=item.get("name", ""),
                        description=item.get("description", ""),
                        examples=item.get("examples", []),
                    )
                    for item in data
                    if item.get("name") and item.get("description")
                ]
        except Exception as e:
            logger.warning(f"LLM simple mental model extraction failed: {e}")
        
        return []

    async def _extract_heuristics(self, research: dict) -> list[DecisionHeuristic]:
        """提取决策启发式"""
        from xingzierai.smart_llm_client import SmartLLMClient
        
        client = SmartLLMClient()
        research_summary = self._summarize_research(research)
        
        prompt = f"""基于以下研究材料，提取"{research['name']}"的决策启发式。

研究材料摘要：
{research_summary}

请提取 3-5 条决策规则，每条包含：
- condition: 触发条件/场景
- action: 推荐的行动
- rationale: 背后的理由

以 JSON 数组格式返回：
```json
[
  {{
    "condition": "面对复杂问题时",
    "action": "先拆解到最基础的组成部分",
    "rationale": "从第一性原理出发能避免类比的陷阱"
  }}
]
```

只返回 JSON 数组。"""

        try:
            response = await client.ask(prompt, system="你是决策科学专家，擅长提炼实用的决策规则。", smart_routing=False)
            logger.info(f"NuwaEngine._extract_heuristics: LLM 返回 {len(response)} 字符: {response[:300]}...")
            data = self._extract_json(response)
            logger.info(f"NuwaEngine._extract_heuristics: 解析结果 data={data is not None}, type={type(data).__name__ if data else 'None'}")
            if data and isinstance(data, list):
                return [
                    DecisionHeuristic(
                        condition=item.get("condition", ""),
                        action=item.get("action", ""),
                        rationale=item.get("rationale", ""),
                    )
                    for item in data
                    if item.get("condition") and item.get("action")
                ]
        except Exception as e:
            logger.warning(f"LLM heuristic extraction failed: {e}")
        
        return []

    async def _extract_heuristics_simple(self, research: dict) -> list[DecisionHeuristic]:
        """简化版决策启发式提取"""
        from xingzierai.smart_llm_client import SmartLLMClient
        
        client = SmartLLMClient()
        research_summary = self._summarize_research(research)
        
        prompt = f"""根据以下关于"{research['name']}"的信息，列出他/她的决策规则。

信息：
{research_summary[:1000]}

请返回 JSON 数组，每个元素包含 condition、action 和 rationale：
[{{"condition": "场景", "action": "行动", "rationale": "理由"}}]"""

        try:
            response = await client.ask(prompt, system="你是一个简洁的分析助手。", smart_routing=False)
            data = self._extract_json(response)
            if data and isinstance(data, list):
                return [
                    DecisionHeuristic(
                        condition=item.get("condition", ""),
                        action=item.get("action", ""),
                        rationale=item.get("rationale", ""),
                    )
                    for item in data
                    if item.get("condition") and item.get("action")
                ]
        except Exception as e:
            logger.warning(f"LLM simple heuristic extraction failed: {e}")
        
        return []

    async def _extract_expression_dna(self, research: dict) -> ExpressionDNA:
        """提取表达DNA"""
        from xingzierai.smart_llm_client import SmartLLMClient
        
        client = SmartLLMClient()
        research_summary = self._summarize_research(research)
        
        prompt = f"""分析"{research['name']}"的表达风格特征。

研究材料摘要：
{research_summary}

请分析其表达风格的以下方面，以 JSON 格式返回：
```json
{{
  "tone": "整体语气风格（如：direct, analytical, inspirational, pragmatic 等）",
  "rhythm": ["节奏特征1", "节奏特征2", "节奏特征3"],
  "vocabulary_preferences": ["常用词汇类型1", "常用词汇类型2"]
}}
```

只返回 JSON 对象。"""

        try:
            response = await client.ask(prompt, system="你是语言风格分析师，擅长识别和描述人物的表达特征。", smart_routing=False)
            data = self._extract_json(response)
            if data and isinstance(data, dict):
                return ExpressionDNA(
                    tone=data.get("tone", "professional"),
                    rhythm=data.get("rhythm", ["direct", "concise"]),
                    vocabulary_preferences=data.get("vocabulary_preferences", []),
                )
        except Exception as e:
            logger.warning(f"LLM expression DNA extraction failed: {e}")
        
        return ExpressionDNA(
            tone="professional",
            rhythm=["direct", "concise"],
            vocabulary_preferences=[],
        )

    async def _extract_anti_patterns(self, research: dict) -> list[str]:
        """提取反模式"""
        from xingzierai.smart_llm_client import SmartLLMClient
        
        client = SmartLLMClient()
        research_summary = self._summarize_research(research)
        
        prompt = f"""基于以下研究材料，识别"{research['name']}"明确反对或避免的做法（反模式）。

研究材料摘要：
{research_summary}

请以 JSON 数组格式返回反模式列表：
```json
["反模式1", "反模式2", "反模式3"]
```

只返回 JSON 数组。"""

        try:
            response = await client.ask(prompt, system="你擅长识别人物明确反对的做法。", smart_routing=False)
            data = self._extract_json(response)
            if data and isinstance(data, list):
                return [item for item in data if isinstance(item, str) and item.strip()]
        except Exception as e:
            logger.warning(f"LLM anti-pattern extraction failed: {e}")
        
        return []

    def _summarize_research(self, research: dict) -> str:
        """将研究数据总结为文本"""
        parts = []
        sources = research.get("sources", {})
        
        for key, items in sources.items():
            if items:
                parts.append(f"**{key}**:")
                for item in items:
                    if isinstance(item, dict):
                        parts.append("  - " + ", ".join(f"{k}: {v}" for k, v in item.items()))
                    else:
                        parts.append(f"  - {item}")
        
        quotes = research.get("raw_quotes", [])
        if quotes:
            parts.append("\n**直接引述**:")
            for q in quotes[:5]:
                parts.append(f'  > "{q}"')
        
        return "\n".join(parts) if parts else "暂无详细研究数据"

    def save_as_skill(
        self,
        skill: PerspectiveSkill,
        overwrite: bool = False,
    ) -> bool:
        """将蒸馏的技能保存到customized_skills"""
        from ...agents.skills_manager import SkillService
        
        service = SkillService(self.workspace_dir)
        
        # 构建SKILL.md内容
        content = self._build_skill_md(skill)
        
        return service.create_skill(
            name=skill.name,
            content=content,
            overwrite=overwrite,
        )

    def _build_skill_md(self, skill: PerspectiveSkill) -> str:
        """构建SKILL.md内容"""
        lines = [
            "---",
            f"name: {skill.name}",
            f"description: {skill.description}",
            "---",
            "",
            f"# {skill.source_person} 视角",
            "",
            "## 心智模型",
        ]
        
        for model in skill.mental_models:
            lines.extend([
                f"### {model.name}",
                model.description,
                "",
            ])
        
        lines.extend([
            "",
            "## 决策启发式",
        ])
        
        for h in skill.decision_heuristics:
            lines.extend([
                f"- 如果 {h.condition}，则 {h.action}",
                f"  - 理由: {h.rationale}",
                "",
            ])
        
        lines.extend([
            "",
            "## 表达DNA",
            f"- 语气: {skill.expression_dna.tone}",
            f"- 节奏: {', '.join(skill.expression_dna.rhythm)}",
            "",
            "## 诚实边界",
        ])
        
        for boundary in skill.honest_boundaries:
            lines.append(f"- {boundary}")
        
        return "\n".join(lines)


class DarwinOptimizer:
    """
    达尔文技能进化引擎
    
    基于8维度评估体系和棘轮机制实现技能的持续优化
    """

    # 8维度评估体系
    DIMENSIONS = {
        "structure": 15,      # 结构完整性
        "clarity": 15,        # 表述清晰度  
        "actionability": 15,  # 可操作性
        "coverage": 15,      # 覆盖度
        "test_performance": 25,  # 实测表现(最高权重)
        "consistency": 5,    # 一致性
        "safety": 5,        # 安全性
        "maintainability": 5,   # 可维护性
    }

    def __init__(self, workspace_dir: Path):
        self.workspace_dir = workspace_dir
        self.scores_history: dict[str, list[float]] = {}

    async def evaluate_skill(self, skill_name: str) -> SkillEvaluation:
        """
        8维度评估技能
        
        Args:
            skill_name: 技能名称
            
        Returns:
            SkillEvaluation: 评估结果
        """
        logger.info(f"Evaluating skill: {skill_name}")
        
        from ...agents.skills_manager import SkillService
        service = SkillService(self.workspace_dir)
        
        # 读取技能内容
        skills = service.list_all_skills()
        skill_info = next((s for s in skills if s.name == skill_name), None)
        
        if not skill_info:
            raise ValueError(f"Skill not found: {skill_name}")
        
        # 1. 结构评分(静态分析)
        structure_score = await self._evaluate_structure(skill_info.content)
        
        # 2. 效果评分(实测)
        effect_score = await self._evaluate_effect(skill_name)
        
        # 3. 计算维度分数
        dimensions = await self._evaluate_dimensions(skill_info.content, structure_score)
        
        total = structure_score + effect_score
        
        return SkillEvaluation(
            total_score=total,
            structure_score=structure_score,
            effect_score=effect_score,
            dimensions=dimensions,
            strengths=self._extract_strengths(dimensions),
            weaknesses=self._extract_weaknesses(dimensions),
            suggestions=self._generate_suggestions(dimensions),
        )

    async def _evaluate_structure(self, content: str) -> float:
        """评估结构质量"""
        score = 0.0
        
        # 检查必要字段
        required = ["name", "description"]
        for field in required:
            if f"{field}:" in content.lower():
                score += 5
        
        # 检查结构完整性
        if "## " in content:  # 有标题结构
            score += 5
        
        return min(score, 60)  # 结构分最高60

    async def _evaluate_effect(self, skill_name: str) -> float:
        """评估实际效果"""
        # 实际需要运行测试用例来评估
        # 这里返回基础分
        return 20.0

    async def _evaluate_dimensions(self, content: str, structure_max: float = 60.0) -> dict[str, float]:
        """评估各维度分数"""
        dimensions = {}
        
        for dim, weight in self.DIMENSIONS.items():
            base_score = min(len(content) / 100, 1.0) * weight
            if dim == "structure":
                normalized_score = (base_score / structure_max) * 100 if structure_max > 0 else 0
            else:
                normalized_score = (base_score / weight) * 100 if weight > 0 else 0
            dimensions[dim] = round(normalized_score, 1)
        
        return dimensions

    def _extract_strengths(self, dimensions: dict[str, float]) -> list[str]:
        """提取优势"""
        return [dim for dim, score in dimensions.items() if score >= 10]

    def _extract_weaknesses(self, dimensions: dict[str, float]) -> list[str]:
        """提取劣势"""
        return [dim for dim, score in dimensions.items() if score < 5]

    def _generate_suggestions(self, dimensions: dict[str, float]) -> list[str]:
        """生成改进建议"""
        suggestions = []
        
        if dimensions.get("structure", 0) < 10:
            suggestions.append("建议增加更清晰的结构层次")
        if dimensions.get("actionability", 0) < 10:
            suggestions.append("建议增加更多可操作的步骤")
        if dimensions.get("test_performance", 0) < 15:
            suggestions.append("建议添加更多测试用例")
            
        return suggestions

    async def optimize(
        self,
        skill_name: str,
        target_dimension: str = None,
    ) -> dict:
        """
        优化技能
        
        Args:
            skill_name: 技能名称
            target_dimension: 目标优化维度(默认为得分最低的)
            
        Returns:
            dict: 优化结果
        """
        # 1. 评估当前状态
        current_eval = await self.evaluate_skill(skill_name)
        
        # 2. 记录分数历史(棘轮机制)
        if skill_name not in self.scores_history:
            self.scores_history[skill_name] = []
        
        self.scores_history[skill_name].append(current_eval.total_score)
        
        # 3. 找到最需要优化的维度
        if target_dimension is None:
            target_dimension = min(
                current_eval.dimensions.items(),
                key=lambda x: x[1]
            )[0]
        
        # 4. 生成改进方案(这里需要LLM支持)
        improvement = await self._generate_improvement(
            skill_name, 
            target_dimension,
            current_eval,
        )
        
        # 5. 应用改进并重新评估
        # 实际实现中需要修改SKILL.md并重新评估
        
        return {
            "skill_name": skill_name,
            "target_dimension": target_dimension,
            "current_score": current_eval.total_score,
            "improvement": improvement,
            "ratchet_locked": True,  # 只有分数提升才保留
        }

    async def _generate_improvement(
        self,
        skill_name: str,
        dimension: str,
        current_eval: SkillEvaluation,
    ) -> str:
        """生成改进方案"""
        # 实际需要LLM生成具体改进
        return f"针对 {dimension} 维度的改进建议: {current_eval.suggestions[0] if current_eval.suggestions else '暂无建议'}"


def create_nuwa_engine(workspace_dir: Path) -> NuwaEngine:
    """创建女娲引擎"""
    logger.info(f"create_nuwa_engine called with workspace: {workspace_dir}")
    return NuwaEngine(workspace_dir)


def create_darwin_optimizer(workspace_dir: Path) -> DarwinOptimizer:
    """创建达尔文优化器"""
    return DarwinOptimizer(workspace_dir)
