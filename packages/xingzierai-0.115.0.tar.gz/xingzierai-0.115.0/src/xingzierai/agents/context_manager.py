# -*- coding: utf-8 -*-
"""Active Context Management - Enhanced from CoPaw/OpenClaw.

This module provides proactive context management features:
- Active memory retrieval before reasoning
- Context layer management (system, history, recent, tools)
- Intelligent context prioritization
- Tool result time-based compression
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
import hashlib
from collections import deque

logger = logging.getLogger(__name__)


class ContextLayer(str, Enum):
    """Layers of context in the memory hierarchy."""
    SYSTEM = "system"
    SUMMARY = "summary"
    HISTORY = "history"
    RECENT = "recent"
    TOOLS = "tools"


@dataclass
class ContextSegment:
    """A segment of context."""
    layer: ContextLayer
    content: str
    token_count: int
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ContextBudget:
    """Token budget for each context layer."""
    system: int = 2000
    summary: int = 3000
    history: int = 8000
    recent: int = 4000
    tools: int = 2000


@dataclass
class RetrievalResult:
    """Result from memory retrieval."""
    content: str
    source: str
    score: float
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)


class ActiveContextManager:
    """
    Active Context Management System.

    Features:
    - Proactive memory retrieval before reasoning
    - Layer-based context organization
    - Time-based tool result compression
    - Context prioritization based on relevance
    - Token budget management per layer

    This implementation is inspired by CoPaw's context management v2.0.
    """

    def __init__(
        self,
        budget: Optional[ContextBudget] = None,
        enable_proactive_search: bool = True,
        min_relevant_score: float = 0.3,
    ):
        self.budget = budget or ContextBudget()
        self.enable_proactive_search = enable_proactive_search
        self.min_relevant_score = min_relevant_score
        self._retrieval_history: deque = deque(maxlen=100)

    async def prepare_context(
        self,
        system_prompt: str,
        summary: Optional[str],
        history: List[Any],
        recent_messages: List[Any],
        tools_context: Optional[str] = None,
        task_query: Optional[str] = None,
        token_counter: Optional[Any] = None,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
        """Prepare context for LLM call.

        Args:
            system_prompt: System prompt.
            summary: Compressed summary of older messages.
            history: Full history messages.
            recent_messages: Recent messages to preserve.
            tools_context: Tools schema/context.
            task_query: Current task query for retrieval.
            token_counter: Token counter for estimation.

        Returns:
            Tuple of (messages, token_usage_by_layer)
        """
        messages = []
        token_usage = {}

        sys_tokens = await self._estimate_tokens(system_prompt, token_counter)
        messages.append({"role": "system", "content": system_prompt})
        token_usage[ContextLayer.SYSTEM.value] = sys_tokens

        if summary:
            summary_tokens = await self._estimate_tokens(summary, token_counter)
            if summary_tokens <= self.budget.summary:
                messages.append({"role": "system", "content": f"[Summary of previous conversation]\n{summary}"})
                token_usage[ContextLayer.SUMMARY.value] = summary_tokens
            else:
                logger.warning(f"Summary too large ({summary_tokens} tokens), truncating")
                truncated = await self._truncate_to_tokens(summary, self.budget.summary, token_counter)
                messages.append({"role": "system", "content": f"[Summary of previous conversation]\n{truncated}"})
                token_usage[ContextLayer.SUMMARY.value] = self.budget.summary

        if self.enable_proactive_search and task_query:
            retrieved = await self._proactive_retrieve(task_query, history)
            if retrieved:
                retrieved_text = "\n\n".join([
                    f"[Relevant memory - {r.source}]: {r.content}"
                    for r in retrieved
                ])
                retrieved_tokens = await self._estimate_tokens(retrieved_text, token_counter)
                if retrieved_tokens <= self.budget.history // 2:
                    messages.append({"role": "system", "content": f"[Retrieved relevant context]\n{retrieved_text}"})
                    token_usage["retrieved"] = retrieved_tokens

        remaining_budget = self._calculate_remaining_budget(token_usage)

        history_to_include = await self._select_history_messages(
            history, remaining_budget, token_counter
        )
        for msg in history_to_include:
            messages.append(msg)
        token_usage[ContextLayer.HISTORY.value] = await self._estimate_messages_tokens(
            history_to_include, token_counter
        )

        remaining_budget = self._calculate_remaining_budget(token_usage)

        recent_to_add = recent_messages[-10:]
        history_ids = {id(m) for m in history_to_include}
        deduped_recent = [m for m in recent_to_add if id(m) not in history_ids]
        for msg in deduped_recent:
            messages.append(msg)
        token_usage[ContextLayer.RECENT.value] = await self._estimate_messages_tokens(
            deduped_recent, token_counter
        )

        if tools_context:
            tools_tokens = await self._estimate_tokens(tools_context, token_counter)
            token_usage[ContextLayer.TOOLS.value] = min(tools_tokens, self.budget.tools)

        self._record_retrieval(task_query, messages, token_usage)

        return messages, token_usage

    async def compress_tool_results(
        self,
        messages: List[Any],
        recent_threshold: int = 5,
        old_threshold: int = 3,
    ) -> List[Any]:
        """Compress tool results based on time/relevance.

        Inspired by CoPaw's tool result compaction.

        Args:
            messages: Messages to compress.
            recent_threshold: Keep full results for recent N messages.
            old_threshold: Summary length for older messages.

        Returns:
            Compressed messages.
        """
        if not messages:
            return messages

        compressed = []
        tool_result_count = 0

        for i, msg in enumerate(messages):
            if isinstance(msg, dict):
                content = msg.get("content")
                role = msg.get("role")
            else:
                content = getattr(msg, "content", None)
                role = getattr(msg, "role", None)

            is_tool_result = role == "tool" or (isinstance(content, list) and 
                any(getattr(c, "type", "") == "tool_use_result" for c in content))

            if is_tool_result:
                tool_result_count += 1
                if tool_result_count <= recent_threshold:
                    compressed.append(msg)
                else:
                    compressed_msg = await self._compress_single_tool_result(msg, old_threshold)
                    compressed.append(compressed_msg)
            else:
                compressed.append(msg)

        return compressed

    async def _compress_single_tool_result(
        self,
        message: Any,
        max_length: int = 500,
    ) -> Any:
        """Compress a single tool result message."""
        if isinstance(message, dict):
            content = message.get("content", "")
            if isinstance(content, str) and len(content) > max_length:
                message = message.copy()
                message["content"] = f"[Tool result truncated - {len(content)} chars -> {max_length}]\n" + content[:max_length]
            return message
        return message

    async def _proactive_retrieve(
        self,
        query: str,
        history: List[Any],
    ) -> List[RetrievalResult]:
        """Proactively retrieve relevant context.

        Args:
            query: Current task query.
            history: Message history.

        Returns:
            List of retrieval results.
        """
        results = []
        query_lower = query.lower()

        keywords = self._extract_keywords(query_lower)

        for msg in history[-50:]:
            if isinstance(msg, dict):
                content = str(msg.get("content", ""))
                role = msg.get("role", "")
            else:
                content = str(getattr(msg, "content", ""))
                role = getattr(msg, "role", "")

            if not content:
                continue

            content_lower = content.lower()
            score = 0.0

            for kw in keywords:
                if kw in content_lower:
                    score += 0.3

            if role == "user" and any(kw in content_lower for kw in ["create", "build", "make", "generate"]):
                score += 0.2

            if role == "assistant" and "error" in content_lower:
                score += 0.1

            if score >= self.min_relevant_score:
                results.append(RetrievalResult(
                    content=content[:500],
                    source=f"history:{role}",
                    score=score,
                    timestamp=time.time(),
                ))

        results.sort(key=lambda x: x.score, reverse=True)
        return results[:3]

    def _extract_keywords(self, text: str) -> List[str]:
        """Extract keywords from text."""
        stop_words = {"the", "a", "an", "is", "are", "was", "were", "be", "been",
                     "being", "have", "has", "had", "do", "does", "did", "will",
                     "would", "could", "should", "may", "might", "must", "shall",
                     "can", "need", "dare", "ought", "used", "to", "of", "in",
                     "for", "on", "with", "at", "by", "from", "as", "into", "through"}

        words = text.replace(",", " ").replace(".", " ").replace("?", " ").split()
        keywords = [w for w in words if len(w) > 3 and w.lower() not in stop_words]

        return keywords[:10]

    async def _estimate_tokens(
        self,
        text: str,
        token_counter: Optional[Any],
    ) -> int:
        """Estimate token count for text."""
        if not text:
            return 0

        if token_counter and hasattr(token_counter, "count"):
            try:
                return await token_counter.count(texts=[text])
            except Exception as _token_count_err:
                logger.debug("Token counter failed: %s", _token_count_err)

        return len(text) // 4

    async def _estimate_messages_tokens(
        self,
        messages: List[Any],
        token_counter: Optional[Any],
    ) -> int:
        """Estimate total tokens for messages."""
        total = 0
        for msg in messages:
            if isinstance(msg, dict):
                content = msg.get("content", "")
            else:
                content = getattr(msg, "content", "")

            if isinstance(content, str):
                total += await self._estimate_tokens(content, token_counter)
            elif isinstance(content, list):
                for c in content:
                    if isinstance(c, str):
                        total += await self._estimate_tokens(c, token_counter)
                    elif isinstance(c, dict):
                        total += await self._estimate_tokens(c.get("text", ""), token_counter)

        return total

    async def _select_history_messages(
        self,
        history: List[Any],
        remaining_budget: int,
        token_counter: Optional[Any],
    ) -> List[Any]:
        """Select history messages within budget."""
        if not history or remaining_budget <= 0:
            return []

        selected = []
        current_tokens = 0

        for msg in reversed(history[-30:]):
            msg_tokens = await self._estimate_messages_tokens([msg], token_counter)

            if current_tokens + msg_tokens > remaining_budget:
                break

            selected.insert(0, msg)
            current_tokens += msg_tokens

        return selected

    async def _truncate_to_tokens(
        self,
        text: str,
        max_tokens: int,
        token_counter: Optional[Any],
    ) -> str:
        """Truncate text to fit within token budget."""
        estimated_tokens = await self._estimate_tokens(text, token_counter)

        if estimated_tokens <= max_tokens:
            return text

        char_per_token = len(text) / max(estimated_tokens, 1)
        max_chars = int(max_tokens * char_per_token * 0.9)

        return text[:max_chars] + "..."

    def _calculate_remaining_budget(
        self,
        token_usage: Dict[str, int],
    ) -> int:
        """Calculate remaining token budget."""
        total_used = sum(token_usage.values())
        total_budget = (
            self.budget.system +
            self.budget.summary +
            self.budget.history +
            self.budget.recent +
            self.budget.tools
        )
        return max(0, total_budget - total_used)

    def _record_retrieval(
        self,
        query: Optional[str],
        messages: List[Dict[str, Any]],
        token_usage: Dict[str, int],
    ) -> None:
        """Record retrieval for analysis."""
        self._retrieval_history.append({
            "timestamp": time.time(),
            "query": query,
            "message_count": len(messages),
            "token_usage": token_usage,
        })

    def get_retrieval_stats(self) -> Dict[str, Any]:
        """Get retrieval statistics."""
        if not self._retrieval_history:
            return {"total_retrievals": 0}

        total_tokens = sum(
            sum(h.get("token_usage", {}).values())
            for h in self._retrieval_history
        )

        return {
            "total_retrievals": len(self._retrieval_history),
            "average_tokens": total_tokens / len(self._retrieval_history),
            "recent_queries": [
                {"query": h.get("query"), "tokens": sum(h.get("token_usage", {}).values())}
                for h in self._retrieval_history[-5:]
            ],
        }


class ContextCompactionManager:
    """
    Manager for time-based context compaction.

    Implements tool result compaction based on:
    - Recency (keep recent results full)
    - Time-based retention (compress older results)
    - Relevance scoring
    """

    def __init__(
        self,
        recent_n: int = 10,
        retention_days: int = 7,
        compress_older_than_days: int = 1,
    ):
        self.recent_n = recent_n
        self.retention_days = retention_days
        self.compress_older_than_days = compress_older_than_days

    async def compact_messages(
        self,
        messages: List[Any],
        get_message_time: Optional[callable] = None,
    ) -> List[Any]:
        """Compact messages based on time and relevance.

        Args:
            messages: Messages to compact.
            get_message_time: Function to get message timestamp.

        Returns:
            Compacted messages.
        """
        if not messages:
            return messages

        current_time = time.time()
        cutoff_time = current_time - (self.compress_older_than_days * 24 * 3600)

        compacted = []
        tool_results_after_recent = 0

        for i, msg in enumerate(messages):
            is_tool_result = False

            if isinstance(msg, dict):
                role = msg.get("role", "")
                content = msg.get("content", "")
                msg_time = msg.get("_timestamp", current_time)
                is_tool_result = role == "tool"
            else:
                role = getattr(msg, "role", "")
                content = getattr(msg, "content", "")
                msg_time = getattr(msg, "_timestamp", current_time)
                is_tool_result = role == "tool"

            if is_tool_result:
                position_from_end = len(messages) - i
                if position_from_end <= self.recent_n:
                    compacted.append(msg)
                elif msg_time < cutoff_time:
                    compacted_msg = await self._create_compacted_tool_result(msg)
                    compacted.append(compacted_msg)
                    tool_results_after_recent += 1
                else:
                    compacted.append(msg)
            else:
                compacted.append(msg)

        if tool_results_after_recent > 0:
            logger.info(f"Compacted {tool_results_after_recent} tool results")

        return compacted

    async def _create_compacted_tool_result(self, message: Any) -> Any:
        """Create a compacted version of tool result."""
        if isinstance(message, dict):
            content = message.get("content", "")
            if isinstance(content, str) and len(content) > 300:
                compacted = message.copy()
                compacted["content"] = (
                    f"[Tool result - {len(content)} chars compressed to 300]\n"
                    + content[:300]
                )
                compacted["_compacted"] = True
                return compacted

        return message


ActiveContext = ActiveContextManager
ContextCompaction = ContextCompactionManager
