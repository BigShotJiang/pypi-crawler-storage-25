# -*- coding: utf-8 -*-
"""XINGZIERAI A2A Protocol - Agent-to-Agent Communication.

This module implements a standardized protocol for inter-agent communication,
inspired by Anthropic's Agent JSON Protocol and similar systems.
"""

from .protocol import (
    A2AMessage,
    A2ATask,
    A2ATaskResult,
    A2AAgentInfo,
    A2AMessageType,
    A2ATaskStatus,
)
from .registry import AgentRegistry
from .client import A2AClient
from .server import A2ARouter
from .exceptions import A2AError, AgentNotFoundError, TaskTimeoutError

__all__ = [
    "A2AMessage",
    "A2ATask",
    "A2ATaskResult",
    "A2AAgentInfo",
    "A2AMessageType",
    "A2ATaskStatus",
    "AgentRegistry",
    "A2AClient",
    "A2ARouter",
    "A2AError",
    "AgentNotFoundError",
    "TaskTimeoutError",
]
