import math
import numpy as np
from typing import List
from genLhs import combine_samples, lcm_reduce, split_rngs, \
    GEN, RNG, INT, DISTRIBUTIONS, \
    CatLhs, ContLhs


class Lhs:

    def __init__(self,
                 distributions: DISTRIBUTIONS,
                 n_samples: INT = None,
                 sample_factor: INT = None,
                 criterion: str = 'random',
                 verbose: bool = False,
                 **kwargs) -> None:
        """
        Mixed Latin Hypercube sampler for *both* continuous and categorical columns.

        Parameters
        ----------
        distributions : list[Distribution]
            A list of Distribution children (some 'continuous', some 'discrete').
        n_samples : int, optional
            Number of rows to generate. If categorical columns exist, this will be
            rounded up to the LCM of their category counts to keep equal representation.
        sample_factor : int, optional
            If n_samples is not given, base sample count = (n_vars * sample_factor),
            then rounded up to LCM for categorical balance if needed.
        criterion : str
            Only 'random' is supported (stratified LHS with random column permutations).
        """
        self.verbose = verbose
        self.distributions = distributions
        self.n_samples = n_samples
        self.sample_factor = sample_factor
        self.criterion = criterion

        names = [dist.name for dist in self.distributions]
        if len(set(names)) != len(names):
            dupes = sorted({n for n in names if names.count(n) > 1})
            raise ValueError(f"[{__class__.__name__}] duplicate field names not allowed: {dupes}")
        self.names = names

        if not self.criterion.lower().startswith('rand'):
            raise NotImplementedError(f"[{__class__.__name__}] criterion '{self.criterion}' is not implemented.")

        # Partition the incoming list of Distribution objects
        self._cat = [d for d in self.distributions if getattr(d, 'distType', None) == 'discrete']
        self._cont = [d for d in self.distributions if getattr(d, 'distType', None) == 'continuous']

        self.rcv_cat = len(self._cat) > 0
        self.rcv_cont = len(self._cont) > 0
        if not (self.rcv_cat or self.rcv_cont):
            raise ValueError(f"[{__class__.__name__}] received no distributions.")

        self.n_vars = len(self.distributions)
        self.sample_factor = sample_factor

        # --- Determine n_samples (with LCM rounding for categoricals) ---
        rcv_n = n_samples is not None
        rcv_sf = sample_factor is not None
        if rcv_n:
            n_samples = int(n_samples)
        elif rcv_sf:
            n_samples = self.n_vars * int(sample_factor)
        else:
            raise ValueError(f"[{__class__.__name__}] either 'n_samples' or 'sample_factor' must be provided")

        if self.rcv_cat:
            # LCM of categorical sizes to maintain equal sampling of categories
            cat_sizes = [int(getattr(d, 'size', 0)) for d in self._cat]
            lcm = lcm_reduce(cat_sizes)
            if lcm == 0:
                raise ValueError(f"[{__class__.__name__}] categorical LCM is 0 (empty category set?)")
            n_samples = math.ceil(n_samples / lcm) * lcm
        if n_samples <= 0:
            raise AttributeError(f"[{__class__.__name__}] must have a positive number of samples, not {n_samples}!")
        self.n_samples = n_samples

        # --- Build child LHS samplers ---
        if self.rcv_cat:
            # Pass n_samples (not sample_factor) so LCM rounding is enforced here in Lhs
            self.catLhs = CatLhs(self._cat, n_samples=self.n_samples, criterion=self.criterion)
        if self.rcv_cont:
            self.contLhs = ContLhs(self._cont, n_samples=self.n_samples, criterion=self.criterion)
    # </Lhs.__init__>

    def __setattr__(self, attr_name, attr_value) -> None:
        if getattr(self, 'verbose', False):
            print(f"{__class__.__name__}.{attr_name} = {attr_value}")
        super().__setattr__(attr_name, attr_value)
    # </Lhs.__setattr__>

    def __call__(self,
                 seed: INT = None,
                 rng: RNG = None) -> np.ndarray:
        """
        Generate a mixed-type LHS with shape (n_samples,).

        Seeding / RNG policy
        --------------------
        - If both continuous and categorical are present: derive TWO independent child
          Generators from either the provided `rng` or the scalar `seed` using split_rngs().
        - If only one child is present: pass through the provided `seed` / `rng`.
        - Returns a structured array with one field per parameter name.
        """
        if not (self.rcv_cat or self.rcv_cont):
            raise RuntimeError(f"[{__class__.__name__}] no active samplers to run.")

        pieces = []
        if self.rcv_cat and self.rcv_cont:
            # Two child RNGs: SeedSequence when seed is set, otherwise derived from parent rng (or fresh)
            rng_cont, rng_cat = split_rngs(seed=seed, rng=rng, k=2)
            pieces.append(self.contLhs(seed=None, rng=rng_cont))
            pieces.append(self.catLhs(seed=None, rng=rng_cat))
        elif self.rcv_cont:
            pieces.append(self.contLhs(seed=seed, rng=rng))  # pass through
        elif self.rcv_cat:
            pieces.append(self.catLhs(seed=seed, rng=rng))  # pass through

        if len(pieces) == 1:
            return pieces[0]
        return combine_samples(*pieces)
    # </Lhs.__call__>


if __name__ == "__main__":
    import numpy as np
    from genLhs import Lhs, dst

    # Continuous + Categorical distributions
    cont = [
        dst.Uniform("x0", low=0.0, high=1.0),
        dst.Normal("x1",  loc=0.0, scale=1.0),
    ]

    cat = [
        dst.Default_Cat("color", np.array(["red", "green", "blue"])),
        dst.Poisson("pois", np.array(["p1", "p2", "p3", "p4"]), lam=1.1),
    ]

    dists = cont + cat

    # n_samples will be rounded to the LCM of categorical sizes if needed
    lhs = Lhs(dists, n_samples=10)
    sample = lhs(seed=42)
    print("Mixed LHS (preview):")
    print(sample[:3])
