import numpy as np
import warnings
from scipy import stats
from typing import Sequence

EPSILON = np.finfo(float).eps

class Distribution:
    """
    Subclasses define per-instance attributes like:
      - self.distType   : 'continuous' | 'discrete'
      - self.name       : the numpy distribution name
      - self.dtype      : tuple data type to represent field in structured array
      - self.kwargs     : the numpy distribution inputs are converted to
                          parameters used by scipy and stored here.
    """
    def __init__(self,
                 name: str,
                 dtype: str = None,
                 **kwargs):
        self.distType: str = 'continuous'
        self.name: str = name
        if dtype is None:
            self.dtype: tuple = (self.name, 'd') # numpy.float64
        else:
            self.dtype: tuple = (self.name, dtype)

    @staticmethod
    def clip(x: np.ndarray) -> np.ndarray:
        # Clip to (0,1) open interval using EPSILON margins
        return np.clip(x, EPSILON, 1 - EPSILON)
    # </Distribution>

# ================================
# CONTINUOUS DISTRIBUTIONS
# ================================

class Uniform(Distribution):
    def __init__(self,
                 name: str,
                 low: float = 0.0,
                 high: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.uniform.ppf(q, loc=low, scale=high-low)
        Notes: NumPy Generator.uniform(low, high) → SciPy uniform(loc=low, scale=high-low)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : low,
                       'scale'  : high - low}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.uniform.ppf(x, **self.kwargs)
    # </Uniform>


class Normal(Distribution):
    def __init__(self,
                 name: str,
                 loc: float = 0.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.norm.ppf(q, loc=loc, scale=scale)
        Notes: NumPy Generator.normal(loc, scale) → SciPy norm(loc, scale)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : loc,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.norm.ppf(x, **self.kwargs)
    # </Normal>


class Lognormal(Distribution):
    def __init__(self,
                 name: str,
                 mean: float = 0.0,
                 sigma: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.lognorm.ppf(q, s=sigma, loc=0, scale=exp(mean))
        Notes: NumPy Generator.lognormal(mean, sigma) → SciPy lognorm(s, scale=exp(mean))
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'s'      : sigma,
                       'loc'    : 0.0,
                       'scale'  : float(np.exp(mean))}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.lognorm.ppf(x, **self.kwargs)
    # </Lognormal>


class Exponential(Distribution):
    def __init__(self,
                 name: str,
                 scale: float = 1,
                 **kwargs):
        """
        ppf usage: scipy.stats.expon.ppf(q, loc=0, scale=scale)
        Notes: NumPy Generator.exponential(scale) → SciPy expon(scale=scale)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : 0.0,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.expon.ppf(x, **self.kwargs)
    # </Exponential>


class Gamma(Distribution):
    def __init__(self,
                 name: str,
                 shape: float = 1.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.gamma.ppf(q, a=shape, loc=0, scale=scale)
        Notes: NumPy Generator.gamma(shape, scale) → SciPy gamma(a=shape, scale=scale)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'a'      : shape,
                       'loc'    : 0.0,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.gamma.ppf(x, **self.kwargs)
    # </Gamma>


class Beta(Distribution):
    def __init__(self,
                 name: str,
                 a: float = 1.0,
                 b: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.beta.ppf(q, a=a, b=b, loc=0, scale=1)
        Notes: NumPy Generator.beta(a, b) → SciPy beta(a, b)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'a'  : a,
                       'b'  : b}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.beta.ppf(x, **self.kwargs)
    # </Beta>


class ChiSquare(Distribution):
    def __init__(self,
                 name: str,
                 df: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.chi2.ppf(q, df=df, loc=0, scale=1)
        Notes: NumPy Generator.chisquare(df) → SciPy chi2(df)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'df' : df}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.chi2.ppf(x, **self.kwargs)
    # </ChiSquare>


class NoncentralChiSquare(Distribution):
    def __init__(self,
                 name: str,
                 df: float = 1.0,
                 nonc: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.ncx2.ppf(q, df=df, nc=nonc, loc=0, scale=1)
        Notes: NumPy Generator.noncentral_chisquare(df, nonc) → SciPy ncx2(df, nc)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'df' : df,
                       'nc' : nonc}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.ncx2.ppf(x, **self.kwargs)
    # </NoncentralChiSquare>


class FisherF(Distribution):
    def __init__(self,
                 name: str,
                 dfnum: float = 1.0,
                 dfden: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.f.ppf(q, dfn=dfnum, dfd=dfden, loc=0, scale=1)
        Notes: NumPy Generator.f(dfnum, dfden) → SciPy f(dfn, dfd)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'dfn'    : dfnum,
                       'dfd'    : dfden}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.f.ppf(x, **self.kwargs)
    # </FisherF>


class NoncentralF(Distribution):
    def __init__(self,
                 name: str,
                 dfnum: float = 1.0,
                 dfden: float = 1.0,
                 nonc: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.ncf.ppf(q, dfn=dfnum, dfd=dfden, nc=nonc, loc=0, scale=1)
        Notes: NumPy Generator.noncentral_f(dfnum, dfden, nonc) → SciPy ncf(dfn, dfd, nc)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'dfn'    : dfnum,
                       'dfd'    : dfden,
                       'nc'     : nonc}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.ncf.ppf(x, **self.kwargs)
    # </NoncentralF>


class StudentT(Distribution):
    def __init__(self,
                 name: str,
                 df: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.t.ppf(q, df=df, loc=0, scale=1)
        Notes: NumPy standard_t(df) corresponds to loc=0, scale=1
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'df' : df}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.t.ppf(x, **self.kwargs)
    # </StudentT>


class Cauchy(Distribution):
    def __init__(self,
                 name: str,
                 loc: float = 0.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.cauchy.ppf(q, loc=loc, scale=scale)
        Notes: NumPy standard_cauchy() ↔ SciPy cauchy(loc=0, scale=1)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : loc,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.cauchy.ppf(x, **self.kwargs)
    # </Cauchy>


class Gumbel(Distribution):
    def __init__(self,
                 name: str,
                 loc: float = 0.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.gumbel_r.ppf(q, loc=loc, scale=scale)
        Notes: NumPy Generator.gumbel(loc, scale) → SciPy gumbel_r(loc, scale)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : loc,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.gumbel_r.ppf(x, **self.kwargs)
    # </Gumbel>


class Laplace(Distribution):
    def __init__(self,
                 name: str,
                 loc: float = 0.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.laplace.ppf(q, loc=loc, scale=scale)
        Notes: NumPy Generator.laplace(loc, scale) → SciPy laplace(loc, scale)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : loc,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.laplace.ppf(x, **self.kwargs)
    # </Laplace>


class Logistic(Distribution):
    def __init__(self,
                 name: str,
                 loc: float = 0.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.logistic.ppf(q, loc=loc, scale=scale)
        Notes: NumPy Generator.logistic(loc, scale) → SciPy logistic(loc, scale)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : loc,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.logistic.ppf(x, **self.kwargs)
    # </Logistic>


class Rayleigh(Distribution):
    def __init__(self,
                 name: str,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.rayleigh.ppf(q, loc=0, scale=scale)
        Notes: NumPy Generator.rayleigh(scale) → SciPy rayleigh(scale=scale)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'loc'    : 0.0,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.rayleigh.ppf(x, **self.kwargs)
    # </Rayleigh>


class Wald(Distribution):
    def __init__(self,
                 name: str,
                 mean: float = 1.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.invgauss.ppf(q, mu, loc=0, scale)
        Notes: NumPy Generator.wald(mean=ν, scale=λ) → SciPy invgauss(mu=ν/λ, scale=λ)
        """
        super().__init__(name, **kwargs)
        mu = float(mean) / float(scale) if scale != 0 else np.inf
        self.kwargs = {'mu'     : mu,
                       'loc'    : 0.0,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.invgauss.ppf(x, **self.kwargs)
    # </Wald>


class WeibullMin(Distribution):
    def __init__(self,
                 name: str,
                 a: float = 1.0,
                 scale: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.weibull_min.ppf(q, c=a, loc=0, scale=scale)
        Notes: NumPy Generator.weibull(a) is shape-only; scale handled by SciPy's scale
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'c'      : a,
                       'loc'    : 0.0,
                       'scale'  : scale}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.weibull_min.ppf(x, **self.kwargs)
    # </WeibullMin>


class Pareto(Distribution):
    def __init__(self,
                 name: str,
                 a: float = 1.0,
                 xm: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.pareto.ppf(q, b=a, loc=0, scale=xm)
        Notes: NumPy Generator.pareto(a) with minimum xm ↔ SciPy pareto(b=a, scale=xm)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'b'      : a,
                       'loc'    : 0.0,
                       'scale'  : xm}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.pareto.ppf(x, **self.kwargs)
    # </Pareto>


class Power(Distribution):
    def __init__(self,
                 name: str,
                 a: float = 1.0,
                 left: float = 0.0,
                 right: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.powerlaw.ppf(q, a=a, loc=left, scale=right-left)
        Notes: NumPy Generator.power(a) corresponds to SciPy powerlaw(a) on [0, 1]
        """
        super().__init__(name, **kwargs)
        width = float(right) - float(left)
        if width == 0:
            width = 1.0  # guard
        self.kwargs = {'a'      : a,
                       'loc'    : left,
                       'scale'  : width}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.powerlaw.ppf(x, **self.kwargs)
    # </Power>


class Triangular(Distribution):
    def __init__(self,
                 name: str,
                 left: float = 0.0,
                 mode: float = 0.5,
                 right: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.triang.ppf(q, c, loc=left, scale=right-left)
        Notes: NumPy Generator.triangular(left, mode, right)
        c = (mode - left) / (right - left); scale = right - left
        """
        super().__init__(name, **kwargs)
        width = float(right) - float(left)
        c = ((float(mode) - float(left)) / width) if width != 0 else 0.5
        if width == 0:
            width = 1.0  # guard
        self.kwargs = {'c'      : c,
                       'loc'    : left,
                       'scale'  : width}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.triang.ppf(x, **self.kwargs)
    # </Triangular>


class VonMises(Distribution):
    def __init__(self,
                 name: str,
                 mu: float = 0.0,
                 kappa: float = 1.0,
                 **kwargs):
        """
        ppf usage: scipy.stats.vonmises.ppf(q, kappa, loc=mu, scale=1)
        Notes: NumPy Generator.vonmises(mu, kappa) → SciPy vonmises(kappa, loc=mu)
        """
        super().__init__(name, **kwargs)
        self.kwargs = {'kappa'  : kappa,
                       'loc'    : mu}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = self.clip(x)
        return stats.vonmises.ppf(x, **self.kwargs)
    # </VonMises>


# ================================
# DISCRETE DISTRIBUTIONS (PMF-based categorical mapping)
# ================================

class Default_Cat(Distribution):

    def __init__(self,
                 name: str,
                 cats: Sequence,
                 dtype: str = None,
                 **kwargs):
        """
        Default categorical: categories are used directly with uniform → index mapping.
        """
        self.distType = 'discrete'
        self.name = name
        self.cats = np.asarray(cats).ravel()
        self.size = self.cats.size
        if dtype is None:
            self.dtype = (self.name, self.cats.dtype)
        else:
            self.dtype = (self.name, dtype)

        if self.size == 0:
            raise ValueError(f"[{self.__class__.__name__}] empty categories shall not pass!")

        if np.unique(self.cats).size != self.cats.size:
            raise ValueError(f"[{self.__class__.__name__}] duplicate category values detected")

    def __call__(self, x: np.ndarray) -> np.ndarray:
        # Uniforms in [0,1) -> equally spaced bins -> integer indices in [0, size-1]
        x = np.floor(x * self.size).astype(int)
        return x

    # --- helper for PMF → CDF → inverse-categorical mapping ---
    def _inv_categorical(self, u: np.ndarray, probs: np.ndarray) -> np.ndarray:
        """
        Map uniform(0,1) draws `u` to categorical indices using `probs` as the PMF.
        Length of `probs` must equal `self.size`.
        Returns 0-based integer indices of shape u.shape.
        """
        p = np.asarray(probs, dtype=float)
        s = p.sum()
        if not np.isfinite(s) or s <= 0.0:
            raise ValueError(f"[{self.__class__.__name__}] PMF has non-positive or non-finite sum.")
        cdf = np.cumsum(p) / s
        # keep u strictly within (0,1) for stable searchsorted
        u = np.clip(u, EPSILON, np.nextafter(1.0, 0.0))
        idx = np.searchsorted(cdf, u, side='right')
        return idx.astype(np.intp, copy=False)
    # </Default_Cat>


class Poisson(Default_Cat):
    """
    Poisson-weighted categorical selector (PMF-based).
    - We interpret categories as k = 0..size-1 buckets.
    - When tail='lump', the last bin collects P(K ≥ size-1).
    """
    def __init__(self,
                 name: str,
                 cats: Sequence,
                 lam: float = 1.0,
                 tail: str = 'renormalize',
                 **kwargs):
        super().__init__(name, cats)
        self.tail = tail.lower()
        self.kwargs = {'mu' : lam}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        u = self.clip(x)
        if self.tail.startswith('lump'):
            # bins: 0..size-2 exact; last is ≥ (size-1)
            pmf = np.zeros(self.size, dtype=float)
            if self.size == 1:
                pmf[0] = 1.0
            else:
                k = np.arange(self.size - 1, dtype=int)
                pmf[:-1] = stats.poisson.pmf(k, **self.kwargs)
                pmf[-1]  = 1.0 - stats.poisson.cdf(self.size - 2, **self.kwargs)
            return self._inv_categorical(u, pmf)
        else:
            k = np.arange(self.size, dtype=int)  # 0..size-1
            pmf = stats.poisson.pmf(k, **self.kwargs)
            return self._inv_categorical(u, pmf)
    # </Poisson>


class Binomial(Default_Cat):
    """
    Binomial-weighted categorical selector (PMF-based).
    (Finite support; tail policy not applicable.)
    """
    def __init__(self,
                 name: str,
                 cats: Sequence,
                 n: int = None,
                 p: float = 0.5,
                 **kwargs):
        super().__init__(name, cats)
        if n is None:
            n = max(0, self.size - 1)
        else:
            n = int(n)
            support_len = n + 1
            if support_len > self.size:
                warnings.warn(
                    f"[Binomial@{self.name}] Provided n={n} yields support length {support_len} "
                    f"larger than number of categories {self.size}. "
                    f"PMF will be truncated to the first {self.size} outcomes and renormalized. "
                    f"Consider using n={self.size - 1} for one-to-one mapping.",
                    RuntimeWarning
                )
            elif support_len < self.size:
                warnings.warn(
                    f"[Binomial@{self.name}] Provided n={n} yields support length {support_len} "
                    f"smaller than number of categories {self.size}. "
                    f"The last {self.size - support_len} categories are unreachable (zero probability). "
                    f"Consider using n={self.size - 1} for one-to-one mapping, or reduce category count.",
                    RuntimeWarning
                )
        self.kwargs = {'n'  : n,
                       'p'  : p}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        u = self.clip(x)
        n = self.kwargs['n']
        k = np.arange(n + 1, dtype=int)  # 0..n
        pmf_full = stats.binom.pmf(k, **self.kwargs)
        if pmf_full.size >= self.size:
            pmf = pmf_full[:self.size]
        else:
            pmf = np.pad(pmf_full,
                         (0, self.size - pmf_full.size),
                         mode='constant',
                         constant_values=0.0)
        return self._inv_categorical(u, pmf)
    # </Binomial>


class NegativeBinomial(Default_Cat):
    """
    Negative-binomial-weighted categorical selector (PMF-based).
    - Support k = 0..∞; when tail='lump', last bin collects P(K ≥ size-1).
    """
    def __init__(self,
                 name: str,
                 cats: Sequence,
                 n: int = 1,
                 p: float = 0.5,
                 tail: str = 'renormalize',
                 **kwargs):
        super().__init__(name, cats)
        self.tail = tail.lower()
        self.kwargs = {'n'  : n,
                       'p'  : p}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        u = self.clip(x)
        if self.tail.startswith('lump'):
            pmf = np.zeros(self.size, dtype=float)
            if self.size == 1:
                pmf[0] = 1.0
            else:
                k = np.arange(self.size - 1, dtype=int)  # 0..size-2
                pmf[:-1] = stats.nbinom.pmf(k, **self.kwargs)
                pmf[-1]  = 1.0 - stats.nbinom.cdf(self.size - 2, **self.kwargs)
            return self._inv_categorical(u, pmf)
        else:
            k = np.arange(self.size, dtype=int)
            pmf = stats.nbinom.pmf(k, **self.kwargs)
            return self._inv_categorical(u, pmf)
    # </NegativeBinomial>


class Geometric(Default_Cat):
    """
    Geometric-weighted categorical selector (PMF-based).
    - Support k = 1..∞; when tail='lump', last bin collects P(K ≥ size).
    """
    def __init__(self,
                 name: str,
                 cats: Sequence,
                 p: float = 0.5,
                 tail: str = 'renormalize',
                 **kwargs):
        super().__init__(name, cats)
        self.tail = tail.lower()
        self.kwargs = {'p'  : p}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        u = self.clip(x)
        if self.tail.startswith('lump'):
            pmf = np.zeros(self.size, dtype=float)
            if self.size == 1:
                pmf[0] = 1.0
            else:
                k = np.arange(1, self.size, dtype=int)  # 1..size-1
                pmf[:-1] = stats.geom.pmf(k, **self.kwargs)
                pmf[-1]  = 1.0 - stats.geom.cdf(self.size - 1, **self.kwargs)
            return self._inv_categorical(u, pmf)
        else:
            k = np.arange(1, self.size + 1, dtype=int)  # 1..size
            pmf = stats.geom.pmf(k, **self.kwargs)
            return self._inv_categorical(u, pmf)
    # </Geometric>


class Hypergeometric(Default_Cat):
    """
    Hypergeometric-weighted categorical selector (PMF-based).
    (Finite support; tail policy not applicable.)
    """
    def __init__(self,
                 name: str,
                 cats: Sequence,
                 ngood: int = 1,
                 nbad: int = 1,
                 nsample: int = 1,
                 **kwargs):
        super().__init__(name, cats)
        self.kwargs = {'M'  : ngood + nbad,
                       'n'  : ngood,
                       'N'  : nsample}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        u = self.clip(x)
        M = self.kwargs['M']
        n = self.kwargs['n']
        N = self.kwargs['N']
        kmin = max(0, N - (M - n))
        kmax = min(n, N)
        if kmin > kmax:
            pmf = np.zeros(self.size, dtype=float)
            pmf[0] = 1.0
            return self._inv_categorical(u, pmf)

        k = np.arange(kmin, kmax + 1, dtype=int)
        pmf_k = stats.hypergeom.pmf(k, M, n, N)
        width = k.size
        if width >= self.size:
            pmf = pmf_k[:self.size]
        else:
            pmf = np.pad(pmf_k, (0, self.size - width), mode='constant', constant_values=0.0)
        return self._inv_categorical(u, pmf)
    # </Hypergeometric>


class LogSeries(Default_Cat):
    """
    Log-series-weighted categorical selector (PMF-based).
    - Support k = 1..∞; when tail='lump', last bin collects P(K ≥ size).
    """
    def __init__(self,
                 name: str,
                 cats: Sequence,
                 p: float = 0.5,
                 tail: str = 'renormalize',
                 **kwargs):
        super().__init__(name, cats)
        self.tail = tail.lower()
        self.kwargs = {'p'  : p}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        u = self.clip(x)
        if self.tail.startswith('lump'):
            pmf = np.zeros(self.size, dtype=float)
            if self.size == 1:
                pmf[0] = 1.0
            else:
                k = np.arange(1, self.size, dtype=int)  # 1..size-1
                pmf[:-1] = stats.logser.pmf(k, **self.kwargs)
                pmf[-1]  = 1.0 - stats.logser.cdf(self.size - 1, **self.kwargs)
            return self._inv_categorical(u, pmf)
        else:
            k = np.arange(1, self.size + 1, dtype=int)  # 1..size
            pmf = stats.logser.pmf(k, **self.kwargs)
            return self._inv_categorical(u, pmf)
    # </LogSeries>


class Zipf(Default_Cat):
    """
    Zipf-weighted categorical selector (PMF-based).
    - Support k = 1..∞; when tail='lump', last bin collects P(K ≥ size).
    - For small 'a' the tail is heavy; truncation (renormalize) or lumping keeps indices valid.
    """
    def __init__(self,
                 name: str,
                 cats: Sequence,
                 a: float = 2.0,
                 tail: str = 'renormalize',
                 **kwargs):
        super().__init__(name, cats)
        self.tail = tail.lower()
        self.kwargs = {'a'  : a}

    def __call__(self, x: np.ndarray) -> np.ndarray:
        u = self.clip(x)
        if self.tail.startswith('lump'):
            pmf = np.zeros(self.size, dtype=float)
            if self.size == 1:
                pmf[0] = 1.0
            else:
                k = np.arange(1, self.size, dtype=int)  # 1..size-1
                pmf[:-1] = stats.zipf.pmf(k, **self.kwargs)
                pmf[-1]  = 1.0 - stats.zipf.cdf(self.size - 1, **self.kwargs)
            return self._inv_categorical(u, pmf)
        else:
            k = np.arange(1, self.size + 1, dtype=int)  # 1..size
            pmf = stats.zipf.pmf(k, **self.kwargs)
            return self._inv_categorical(u, pmf)
    # </Zipf>
