__all__ = [
    "__version__",
    "choices", "default",
    "GEN", "RNG", "SEED", "INT", "DISTRIBUTIONS",
    "split_rngs", "combine_samples", "lcm_reduce", "parse_seed", "get_parser",
    "CatLhs", "ContLhs", "Lhs",
    "dst"
]

# imports
import argparse
import math
import numpy as np
import numpy.lib.recfunctions as rfn

from typing import List, Optional, Tuple

__version__ = '0.1.0'

# --- configuration options ---
class choices:
    criterion: List[str] = ['random']

class default:
    criterion: str = choices.criterion[0]
    n_samples: int = None
    sample_factor: int = 10
    seed: List[str] = [ '1-3' ]

# -- data types --
GEN = np.random.Generator        # non-optional
RNG = Optional[GEN]              # optional
SEED = Optional[int]
SEEDS = List[SEED]
INT = Optional[int]

from . import distribution as dst
DISTRIBUTIONS = List[dst.Distribution]

# --- functions ---
def split_rngs(seed: SEED = None,
               rng: RNG = None,
               k: int = 2) -> List[GEN]:
    """
    Return `k` independent child Generators.

    When rng is provided, reproducibility is governed by the caller’s Generator
    state.

    - If `rng` provided: sample `k` child seeds from it and build child Generators.
    - Else if `seed` provided: use SeedSequence.spawn(k) for stable, independent streams.
    - Else: make a fresh parent rng and sample `k` child seeds from it.
    """
    if rng is not None:
        # Caller controls reproducibility; we only ensure independence
        seeds = rng.integers(low=0, high=2**63 - 1, size=k, dtype=np.uint64)
        return [np.random.default_rng(int(s)) for s in seeds.tolist()]

    if seed is not None:
        ss = np.random.SeedSequence(int(seed))
        return [np.random.default_rng(child_ss) for child_ss in ss.spawn(k)]

    # No inputs: non-deterministic parent, sample child seeds
    parent = np.random.default_rng()
    seeds = parent.integers(low=0, high=2**63 - 1, size=k, dtype=np.uint64)
    return [np.random.default_rng(int(s)) for s in seeds.tolist()]

def combine_samples(*A: Tuple[np.ndarray]) -> np.ndarray:
    """
    Combines any number of structured arrays

    Returns numpy structured array | np.ndarray
    """
    return rfn.merge_arrays(A, flatten=True, usemask=False)
# </combine_samples>

def lcm_reduce(sizes) -> int:
    """
    Overflow-safe LCM of an iterable of integers.
    Works with Python 3.8.8 (no math.lcm dependency).

    Parameters
    ----------
    sizes : Iterable[int] | np.ndarray
        Iterable of integer-like values (e.g., lengths of category lists).

    Returns
    -------
    int
        The least common multiple as a Python int (arbitrary precision).

    Notes
    -----
    - Returns 0 if *any* element is 0 (conventional definition).
    - Raises ValueError on empty input.
    - Accepts negative integers; uses absolute values.
    - Safe for very large results (no fixed-width overflow).
    """
    sizes = np.asarray(sizes).ravel()
    it = iter(sizes)

    # Detect empty input early
    try:
        first = next(it)
    except StopIteration:
        raise ValueError("lcm_reduce() received an empty iterable")

    # Normalize first element
    res = abs(int(first))

    # Reduce across the rest
    for x in it:
        x = abs(int(x))
        if res == 0 or x == 0:
            return 0
        # lcm(a,b) = a // math.gcd(a,b) * b; division first prevents intermediate blow-up
        res = res // math.gcd(res, x) * x

    return res
# </lcm_reduce>

def parse_seed(seed_str: List[str]) -> SEEDS:
    seed_int = []
    for s in seed_str:
        if s.isnumeric():
            seed_int.append( int(s) )
        else:
            rng = s.split('-')
            assert len(rng) == 2, f"proper --seed usage eg: 0 2-3 5-10"
            rng[0] = int(rng[0])
            rng[1] = int(rng[1]) + 1 # make range inclusive of final number
            rng = list(range(*rng))
            seed_int.extend(rng)
    return seed_int
# </parse_seed>

def get_parser(add_help: bool = False) -> argparse.ArgumentParser:
    # --- run time options ---
    parser = argparse.ArgumentParser(description='genLhs - Generate Latin Hypercube Sample - User Options.',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                                     add_help=add_help)

    parser.add_argument('-c', '--criterion',
                        choices = choices.criterion,
                        default = default.criterion,
                        help = """[genLhs]
                        the method to generate the latin hypercube.""")
    parser.add_argument('-n', '--n_samples',
                        default = default.n_samples,
                        type = int,
                        help = """[genLhs]
                        the number of samples to generate. if not provided, will
                        determine sample size by multiplying the number of
                        discovered parameters and the -x --sample_factor value.""")
    parser.add_argument('-x', '--sample_factor',
                        default = default.sample_factor,
                        type = int,
                        help = """[genLhs]
                        the factor to multiply with the discovered number of
                        parameters in the calculation of the sample size. this
                        option is un-used if -n --n_samples is provided.""")
    parser.add_argument('-s', '--seed',
                        default = default.seed,
                        nargs = '*',
                        help = """[genLhs]
                        the seed(s) to use when generating the sample. if more than
                        one seed is provided, the additional seeds will be used for
                        new random replicates. accepted input include:
                        1) single int value (eg: 0),
                        2) single string value (eg: '0-3'),
                        3) list of values (eg: 1 2 5-10.""")
    parser.add_argument('-v', '--verbose',
                        action = 'store_true',
                        help = """[genLhs]
                        if provided, additional stdout is generated that may aid in
                        debugging.""")
    return parser

# --- internal module imports ---
from .ContLhs import ContLhs
from .CatLhs import CatLhs
from .Lhs import Lhs
