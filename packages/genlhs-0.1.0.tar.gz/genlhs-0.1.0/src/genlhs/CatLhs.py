import math
import numpy as np
from typing import List, Tuple

from genLhs import lcm_reduce, DISTRIBUTIONS, INT, RNG, SEED

class CatLhs:

    def __init__(self,
                 distributions: DISTRIBUTIONS,
                 n_samples: INT = None,
                 sample_factor: INT = None,
                 criterion: str = 'random',
                 verbose: bool = False,
                 **kwargs) -> None:
        """
        Intializes the platform to generate categorical latin hypercube samples
        on demand.

        Parameters:
        -----------
        distributions   : list of Distribution children instances
            objects that contain parameter name, categorical , and
            desired distribution hyperparameters

        n_samples       : int
            Number of LHS samples to generate

        sample_factor   : int
            Scale factor to determine minimum number of samples from number of
            categories

        criterion       : str
            Only 'random' supported here; for other criteria, post-process with
            optimization
        """
        self.verbose = verbose
        self.distributions = distributions
        self.n_samples = n_samples
        self.sample_factor = sample_factor
        self.criterion = criterion

        names = [dist.name for dist in self.distributions]
        if len(set(names)) != len(names):
            dupes = sorted({n for n in names if names.count(n) > 1})
            raise ValueError(f"[{__class__.__name__}] duplicate field names not allowed: {dupes}")
        self.names = names

        if not self.criterion.lower().startswith('rand'):
            raise NotImplementedError(f"[{__class__.__name__}] criterion '{self.criterion}' is not implemented.")

        self.n_cats = len(distributions)
        self.cats = [ dist.cats for dist in self.distributions ]
        self.sizes = [ dist.size for dist in self.distributions ]
        self.dtype = [ cat.dtype for cat in self.distributions ]

        rcv_n_samples = (self.n_samples is not None)
        rcv_sample_factor = (self.sample_factor is not None)
        if rcv_n_samples:
            pass
        elif rcv_sample_factor:
            self.n_samples = (self.n_cats * self.sample_factor)
            lcm = lcm_reduce(self.sizes)
            # round up the number of samples to the next multiple of the
            # least common multiple so each category gets sampled equally
            self.n_samples = math.ceil(self.n_samples/lcm) * lcm
        else:
            raise ValueError(f"[{__class__.__name__}] either 'n_samples' or 'sample_factor' must be provided")

        self.shape = (self.n_samples, self.n_cats)
        self.strata = np.arange(self.n_samples)[:, None] / self.n_samples
    # </CatLhs.__init__>

    def __setattr__(self, attr_name, attr_value) -> None:
        if getattr(self, 'verbose', False):
            print(f"{__class__.__name__}.{attr_name} = {attr_value}")
        super().__setattr__(attr_name, attr_value)
    # </CatLhs.__setattr__>

    def __call__(self,
                 seed: SEED = None,
                 rng: RNG = None) -> np.ndarray:
        """
        Generate a Latin Hypercube Sample for discrete categorical variables
        using NumPy.

        Parameters:
        -----------
        seed : int, optional
            Random seed for reproducibility

        Returns:
        --------
        structured np.array of shape (n_samples,)
            Array of sampled categorical combinations
        """
        rng = rng or (np.random.default_rng(seed) if seed is not None else np.random.default_rng())

        # Generate LHS in [0, 1) and scale to integer bins
        offsets = rng.random(self.shape) / self.n_samples # 2D (n_samples,n_cats)
        perm_idx = np.argsort(rng.random(self.shape), axis=0) # 2D (n_samples,n_cats)
        samples = self.strata + offsets # 2D (n_samples,n_cats)
        samples = np.take_along_axis(samples, perm_idx, 0)

        # apply each categorical parameters assigned method to convert the [0,1)
        # sampled data to integer indices.
        for i, distribution in enumerate(self.distributions):
            if distribution.distType == 'discrete':
                pass
            elif distribution.distType == 'continuous':
                raise AttributeError(f"""[{__class__.__name__}] you are trying to
                apply a continuous distribution to a discrete parameter!""")
            else:
                raise AttributeError(f"""[{__class__.__name__}] you are tyring
                to apply an unknown distribution, {distribution.distType}!""")
            x = samples[:,i]
            x = distribution(x)
            samples[:,i] = x

        # Map back to original categories
        cols = [np.take(cat, samples[:, j].astype(np.intp, copy=False))
                for j, cat in enumerate(self.cats)]

        # write final result as structured array
        samples = np.empty(self.n_samples, dtype=self.dtype)
        for j, name in enumerate(self.names):
            samples[name] = cols[j]
        return samples
    # </CatLhs.__call__>

if __name__ == "__main__":
    import numpy as np
    from genLhs import CatLhs, dst

    dists = [
        dst.Default_Cat("color", np.array(["red", "green", "blue"])),
        dst.Poisson("label", np.array(["p1", "p2", "p3", "p4"]), lam=1.2, tail="renormalize"),
    ]

    # Use a tiny fixed sample size; CatLhs won’t round when n_samples is given
    lhs = CatLhs(dists, n_samples=9)
    sample = lhs(seed=42)
    print("Categorical LHS (preview):")
    print(sample[:3])
