import numpy as np
from typing import List, Tuple

from genLhs import DISTRIBUTIONS, INT, RNG, SEED

class ContLhs:

    def __init__(self,
                 distributions: DISTRIBUTIONS,
                 n_samples: INT = None,
                 sample_factor: INT = None,
                 criterion: str = 'random',
                 verbose: bool = False,
                 **kwargs) -> None:
        """
        Initialize a continuous Latin Hypercube sampler.

        Parameters
        ----------
        distributions : list[Distribution]
            Each element must be a *continuous* Distribution child whose __call__(u)
            maps u in (0,1) to the target marginal via its PPF.
        n_samples : int, optional
            Number of rows to generate.
        sample_factor : int, optional
            If n_samples is not provided, defaults to n_vars * sample_factor.
        criterion : str
            Only 'random' is supported (stratified LHS with random column permutations).
        """
        self.verbose = verbose
        self.distributions = distributions
        self.n_samples = n_samples
        self.sample_factor = sample_factor
        self.criterion = criterion

        names = [dist.name for dist in self.distributions]
        if len(set(names)) != len(names):
            dupes = sorted({n for n in names if names.count(n) > 1})
            raise ValueError(f"[{__class__.__name__}] duplicate field names not allowed: {dupes}")
        self.names = names

        if not self.criterion.lower().startswith('rand'):
            raise NotImplementedError(f"[{__class__.__name__}] criterion '{self.criterion}' is not implemented.")

        self.n_vars = len(self.distributions)
        self.dtype = [ dist.dtype for dist in self.distributions ]

        rcv_n_samples = (self.n_samples is not None)
        rcv_sample_factor = (self.sample_factor is not None)
        if rcv_n_samples:
            pass
        elif rcv_sample_factor:
            # No LCM rounding needed for continuous variables
            self.n_samples = self.n_vars * int(self.sample_factor)
        else:
            raise ValueError(f"[{__class__.__name__}] either 'n_samples' or 'sample_factor' must be provided")

        self.shape = (self.n_samples, self.n_vars)
        self.strata = np.arange(self.n_samples)[:, None] / self.n_samples
    # </ContLhs.__init__>

    def __setattr__(self, attr_name, attr_value) -> None:
        if getattr(self, 'verbose', False):
            print(f"{__class__.__name__}.{attr_name} = {attr_value}")
        super().__setattr__(attr_name, attr_value)
    # </ContLhs.__setattr__>

    def __call__(self,
                 seed: SEED = None,
                 rng: RNG = None) -> np.ndarray:
        """
        Generate a Latin Hypercube Sample for continuous variables.

        Parameters
        ----------
        seed : int, optional
            Random seed for reproducibility.

        Returns
        -------
        samples : np.ndarray (structured), shape (n_samples,)
            Structured array with one float64 field per variable name.
        """
        rng = rng or (np.random.default_rng(seed) if seed is not None else np.random.default_rng())

        # Core LHS on uniforms in [0,1): strata + jitter + independent column permutations
        offsets = rng.random(self.shape) / self.n_samples               # (n_samples, n_vars)
        perm_idx = np.argsort(rng.random(self.shape), axis=0)           # (n_samples, n_vars)
        U = self.strata + offsets                                       # (n_samples, n_vars)
        U = np.take_along_axis(U, perm_idx, 0)                          # column-wise shuffle

        # Apply per-column continuous distribution transform (PPF)
        X = np.empty_like(U, dtype=np.float64)
        for j, dist in enumerate(self.distributions):
            if getattr(dist, 'distType', None) == 'continuous':
                x = U[:, j]
                y = dist(x)  # PPF mapping
                # Optional bounds if attached to the dist (e.g., dist.bounds = (min, max))
                b = getattr(dist, 'bounds', None)
                if b is not None:
                    lo, hi = b
                    if lo is not None:
                        y = np.maximum(y, lo)
                    if hi is not None:
                        y = np.minimum(y, hi)
                X[:, j] = y
            elif getattr(dist, 'distType', None) == 'discrete':
                raise AttributeError(
                    f"[{__class__.__name__}] attempted to apply a DISCRETE distribution "
                    f"to a continuous LHS column ('{self.names[j]}')."
                )
            else:
                raise AttributeError(
                    f"[{__class__.__name__}] unknown distribution type for column '{self.names[j]}'."
                )

        # Write final result as a structured array (n_samples,)
        samples = np.empty(self.n_samples, dtype=self.dtype)
        for j, name in enumerate(self.names):
            samples[name] = X[:, j]
        return samples
    # </ContLhs.__call__>


if __name__ == "__main__":
    from genLhs import ContLhs, dst

    dists = [
        dst.Uniform("x0", low=0.0, high=1.0),
        dst.Normal("x1",  loc=0.0, scale=1.0),
        dst.Triangular("x2", left=-1.0, mode=0.0, right=2.0),
    ]

    lhs = ContLhs(dists, n_samples=8)
    sample = lhs(seed=42)
    print("Continuous LHS (preview):")
    print(sample[:3])

