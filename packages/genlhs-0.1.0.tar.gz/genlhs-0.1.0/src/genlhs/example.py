import numpy as np
from genLhs import get_parser, parse_seed, dst, Lhs

if "__main__" == __name__:
    cont = [dst.Uniform('uniform_param', 0.0, 1.0),
            dst.Normal('normal_param', 0.0, 1.0)]
    cat = [dst.Default_Cat("color", np.array(["red", "green", "blue"])),
           dst.Poisson("pois", np.array(["p1", "p2", "p3", "p4"]), lam=1.1)]
    distributions = cont + cat

    parser = get_parser(add_help=True)
    opts = parser.parse_args()
    seeds = parse_seed(opts.seed)
    lhs = Lhs(distributions, **opts.__dict__)

    replicates = []
    for seed in seeds:
        sample = lhs(seed)
        replicates.append(sample)

    scenario_matrix = np.concatenate(replicates, axis=0)

    print(f"\nSCENARIO MATRIX RESULTS\
            \n=======================\
            \nNUMBER OF SAMPLES     : {scenario_matrix.size}\
            \nNUMBER OF REPLICATES  : {len(seeds)}\
            \nNUMBER OF PARAMETERS  : {len(scenario_matrix.dtype.names)}\
            \nPARAMETERS            : {scenario_matrix.dtype.names}\
            \n\n{scenario_matrix[:3]}\n...")

