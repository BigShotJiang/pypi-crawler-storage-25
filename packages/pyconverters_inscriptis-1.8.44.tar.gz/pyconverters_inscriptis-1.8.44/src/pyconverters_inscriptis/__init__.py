"""Sherpa HTML inscriptis converter"""

__version__ = "1.8.44"
