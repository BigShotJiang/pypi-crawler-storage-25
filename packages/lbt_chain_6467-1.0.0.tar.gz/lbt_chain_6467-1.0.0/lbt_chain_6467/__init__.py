"""Breeze Loop Mark"""
__version__ = "1.0.0"
