# -*- coding: utf-8 -*-
"""
威科夫终端读盘室 — 入口。

用法:
    wyckoff                # 直接启动，在 TUI 内配置模型
    wyckoff update         # 升级到最新版
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys

from dotenv import load_dotenv

# 加载 .env（项目根目录）
load_dotenv()

# 抑制 Streamlit 在非 Streamlit 环境下的全部日志
os.environ["STREAMLIT_LOG_LEVEL"] = "error"
import logging as _logging


def _silence_streamlit():
    """强制清除 streamlit 所有 logger handler，必须在 streamlit import 之后调用。"""
    for name in list(_logging.Logger.manager.loggerDict):
        if name.startswith("streamlit"):
            lg = _logging.getLogger(name)
            lg.handlers.clear()
            lg.setLevel(_logging.CRITICAL)
            lg.propagate = False


# 预先 import streamlit 触发它的 logger 初始化，然后立即压制
try:
    import streamlit  # noqa: F401
except Exception:
    pass
_silence_streamlit()


# ---------------------------------------------------------------------------
# Provider 工厂
# ---------------------------------------------------------------------------

# API Key 环境变量映射
KEY_ENV_MAP = {
    "gemini": "GEMINI_API_KEY",
    "claude": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
}

# 默认模型
DEFAULT_MODELS = {
    "gemini": "gemini-2.5-flash",
    "claude": "claude-sonnet-4-20250514",
    "openai": "gpt-4o",
}


def _create_provider(provider_name: str, api_key: str, model: str = "", base_url: str = ""):
    """根据 provider 名称创建 LLMProvider 实例。"""
    from cli.providers import PROVIDERS

    cls = PROVIDERS.get(provider_name)
    if cls is None:
        install_hints = {
            "gemini": "pip install google-genai",
            "claude": "pip install anthropic",
            "openai": "pip install openai",
        }
        hint = install_hints.get(provider_name, "")
        return None, f"Provider '{provider_name}' 不可用，请先安装依赖：{hint}"

    kwargs = {"api_key": api_key}
    if model:
        kwargs["model"] = model
    if base_url:
        kwargs["base_url"] = base_url

    import inspect
    sig = inspect.signature(cls.__init__)
    kwargs = {k: v for k, v in kwargs.items() if k in sig.parameters}

    return cls(**kwargs), None


def _load_system_prompt() -> str:
    """加载系统提示词。"""
    from core.prompts import CHAT_AGENT_SYSTEM_PROMPT
    return CHAT_AGENT_SYSTEM_PROMPT


def _do_update():
    """执行升级，优先 uv，回退 pip。"""
    import shutil
    print("正在升级 youngcan-wyckoff-analysis ...")
    pkg = "youngcan-wyckoff-analysis"
    # 优先用 uv
    uv = shutil.which("uv")
    if uv:
        cmd = [uv, "pip", "install", "--upgrade", pkg]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", pkg]
    try:
        subprocess.check_call(cmd)
        print("\n升级完成！请重新运行 wyckoff。")
    except subprocess.CalledProcessError as e:
        print(f"\n升级失败: {e}")
    sys.exit(0)


def main():
    parser = argparse.ArgumentParser(description="威科夫终端读盘室")
    parser.add_argument(
        "command", nargs="?", default=None,
        help="子命令: update（升级到最新版）",
    )
    parser.add_argument(
        "--user-id",
        default=os.getenv("WYCKOFF_USER_ID", ""),
        help="用户 ID（用于加载 Supabase 持仓和凭证）",
    )
    args = parser.parse_args()

    # 子命令处理
    if args.command == "update":
        _do_update()
        return
    elif args.command is not None:
        print(f"未知命令: {args.command}")
        print("可用命令: wyckoff update")
        sys.exit(1)

    # 创建工具注册表
    from cli.tools import ToolRegistry
    tools = ToolRegistry(user_id=args.user_id)

    # 加载系统提示词
    system_prompt = _load_system_prompt()

    # UI
    from cli import ui

    # 当前 provider 状态（可通过 /model 随时切换）
    state = {
        "provider": None,
        "provider_name": "",
        "model": "",
        "api_key": "",
        "base_url": "",
    }

    def _ensure_provider() -> bool:
        """确保 provider 已配置，未配置则提示。返回是否可用。"""
        if state["provider"] is not None:
            return True
        ui.print_info("尚未配置模型，请先运行 /model 设置。")
        return False

    # 打印 Banner
    ui.print_banner()

    # 对话历史
    messages: list[dict] = []

    # REPL 循环
    while True:
        user_input = ui.get_input()

        if not user_input:
            continue

        # 命令处理
        if user_input.startswith("/"):
            cmd = user_input.lower().split()[0]
            if cmd in ("/quit", "/exit", "/q"):
                ui.print_info("再见。")
                break
            elif cmd in ("/clear", "/new"):
                messages.clear()
                ui.print_info("对话已清空。")
                continue
            elif cmd == "/help":
                ui.print_help()
                continue
            elif cmd == "/model":
                result = ui.configure_model(state)
                if result:
                    provider_name = result["provider_name"]
                    api_key = result["api_key"]
                    model = result["model"]
                    base_url = result["base_url"]

                    provider, err = _create_provider(provider_name, api_key, model, base_url)
                    if err:
                        ui.print_error(err)
                    else:
                        state["provider"] = provider
                        state["provider_name"] = provider_name
                        state["api_key"] = api_key
                        state["model"] = model
                        state["base_url"] = base_url
                        ui.print_info(f"已切换到: {provider.name}")
                continue
            else:
                ui.print_error(f"未知命令: {user_input}，输入 /help 查看可用命令。")
                continue

        # 检查 provider
        if not _ensure_provider():
            continue

        # 添加用户消息
        messages.append({"role": "user", "content": user_input})

        # 工具调用回调
        def on_tool_call(name, call_args):
            ui.print_tool_call(name, tools.display_name(name), call_args)

        def on_tool_result(name, result):
            ui.print_tool_result(name, tools.display_name(name), result)

        # 执行 Agent 循环
        try:
            from cli.agent import run
            response = run(
                provider=state["provider"],
                tools=tools,
                messages=messages,
                system_prompt=system_prompt,
                on_tool_call=on_tool_call,
                on_tool_result=on_tool_result,
            )
            ui.print_response(response)
        except KeyboardInterrupt:
            ui.print_info("\n已中断。")
            # 移除最后的 user 消息（未完成的对话）
            if messages and messages[-1]["role"] == "user":
                messages.pop()
        except Exception as e:
            ui.print_error(f"Agent 错误: {e}")
            # 移除本轮不完整的消息
            while messages and messages[-1]["role"] != "user":
                messages.pop()
            if messages and messages[-1]["role"] == "user":
                messages.pop()


if __name__ == "__main__":
    main()
