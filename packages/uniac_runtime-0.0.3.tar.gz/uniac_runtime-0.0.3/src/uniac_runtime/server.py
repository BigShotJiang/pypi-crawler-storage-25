"""FastAPI application factory and startup helpers for Uniac runtimes."""
from __future__ import annotations

import asyncio
import json
import os
import time
import urllib.request
from collections.abc import Mapping
from dataclasses import dataclass, field

from fastapi import FastAPI

from uniac.user.service import FastAPIService


@dataclass
class StartupTimeline:
    """Captures startup timestamps from Python entrypoint to readiness."""

    process_entry: float = field(default_factory=time.perf_counter)
    vm_uptime_at_python_start: float = -1.0
    import_path_ready: float | None = None
    service_loaded: float | None = None
    app_built: float | None = None
    server_started: float | None = None
    callback_started: float | None = None
    callback_acked: float | None = None

    def mark(self, field_name: str) -> None:
        setattr(self, field_name, time.perf_counter())

    def as_timings(self) -> dict[str, float]:
        timings: dict[str, float] = {}

        if self.vm_uptime_at_python_start >= 0:
            timings["vm_uptime_at_python_start"] = round(self.vm_uptime_at_python_start, 6)

        def add(name: str, start: float | None, end: float | None) -> None:
            if start is None or end is None:
                return
            timings[name] = round(max(0.0, end - start), 6)

        add("process_entry_to_import_path", self.process_entry, self.import_path_ready)
        add("import_path_to_service_load", self.import_path_ready, self.service_loaded)
        add("service_load_to_app_build", self.service_loaded, self.app_built)
        add("app_build_to_server_started", self.app_built, self.server_started)
        add(
            "process_entry_to_server_started",
            self.process_entry,
            self.server_started,
        )
        add(
            "server_started_to_callback_dispatch",
            self.server_started,
            self.callback_started,
        )
        add("callback_http_roundtrip", self.callback_started, self.callback_acked)
        add("process_entry_to_ready_ack", self.process_entry, self.callback_acked)
        return timings


def readiness_target_from_env(
    environ: Mapping[str, str] | None = None,
) -> tuple[str, str] | None:
    env = os.environ if environ is None else environ
    ready_url = env.get("UNIAC_READY_URL", "")
    ready_token = env.get("UNIAC_READY_TOKEN", "")
    if ready_url and ready_token:
        return ready_url, ready_token
    return None


def _post_ready_callback(
    ready_url: str,
    ready_token: str,
    timings: Mapping[str, float] | None,
) -> int:
    payload: dict[str, object] = {"token": ready_token}
    if timings:
        payload["timings"] = dict(timings)
    request = urllib.request.Request(
        ready_url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=5) as response:
        response.read()
        return getattr(response, "status", 200)


async def send_ready_callback(
    ready_url: str,
    ready_token: str,
    timings: Mapping[str, float] | None,
) -> int:
    return await asyncio.to_thread(
        _post_ready_callback,
        ready_url,
        ready_token,
        timings,
    )


def create_app(service: FastAPIService) -> FastAPI:
    """Build a FastAPI application from a FastAPIService instance."""
    if not isinstance(service, FastAPIService):
        raise TypeError(
            f"Expected a FastAPIService instance, got {type(service).__name__!r}"
        )
    return service.build_app()
