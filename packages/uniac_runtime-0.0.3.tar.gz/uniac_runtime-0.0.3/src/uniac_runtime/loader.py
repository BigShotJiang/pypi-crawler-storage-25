"""Dynamic loading of Service instances from entrypoint strings."""
from __future__ import annotations

import importlib
import json
import logging
import os
import sys
from pathlib import Path

from uniac.user.service import FastAPIService, Service


logger = logging.getLogger(__name__)


class LoadError(Exception):
    """Failed to load the user's Service."""


def setup_import_path(project_dir: str = ".", deps_dir: str = "deps") -> None:
    """Configure sys.path so user code and bundled dependencies are importable.

    This must be called before any attempt to import user modules.

    Args:
        project_dir: Root directory containing user code.
        deps_dir: Subdirectory name for pre-bundled pip dependencies.
    """
    project = str(Path(project_dir).resolve())
    deps = str((Path(project_dir).resolve() / deps_dir))

    if deps not in sys.path:
        sys.path.insert(0, deps)
    if project not in sys.path:
        sys.path.insert(0, project)


def load_service(entrypoint: str) -> Service:
    """Import and return a Service instance from an entrypoint string.

    Args:
        entrypoint: ``module:object`` (e.g. ``app:app``).
            The object may be a Service instance (returned directly)
            or a Service subclass (instantiated and returned).

    Returns:
        A Service instance.

    Raises:
        LoadError: if the module cannot be imported, the attribute is missing,
                   or it is not a Service instance or subclass.
    """
    if ":" not in entrypoint:
        raise LoadError(
            f"Invalid entrypoint {entrypoint!r}: expected 'module:object' format"
        )

    module_name, attr_name = entrypoint.split(":", 1)
    if not module_name or not attr_name:
        raise LoadError(
            f"Invalid entrypoint {entrypoint!r}: module and object must be non-empty"
        )

    try:
        mod = importlib.import_module(module_name)
    except ModuleNotFoundError as exc:
        raise LoadError(f"Cannot import module {module_name!r}: {exc}") from exc

    obj = getattr(mod, attr_name, None)
    if obj is None:
        raise LoadError(
            f"Module {module_name!r} has no attribute {attr_name!r}"
        )

    # Instance — return directly.
    if isinstance(obj, Service):
        return obj

    # Class — instantiate and return.
    if isinstance(obj, type) and issubclass(obj, Service):
        return obj()

    raise LoadError(
        f"{module_name}:{attr_name} is not a Service instance or subclass"
    )


def hydrate_deps(service: Service) -> None:
    """Inject child-Node URLs from ``UNIAC_DEPS_JSON`` onto the loaded
    Service's owned-Node tree.

    The platform writes ``UNIAC_DEPS_JSON`` on the container, keyed by
    each owned child's ``_uniac_local_name``::

        {"db": {"url": "https://abc.svc.uniac.ai", "primitive": "db", "version": "latest"}}

    For each owned Node in ``service._uniac_walk()``, look up the child's
    local name in the env-var map and set ``_uniac_url`` on the Node.
    Children not present in the map (e.g., the env var is empty for
    zero-dep services) are silently skipped — their ``url`` stays
    ``None`` so user code can detect "unhydrated" states.

    Must be called AFTER ``service._uniac_populate()`` (so the Node
    tree is materialized) and BEFORE ``service.build_app()``.
    """
    raw = os.environ.get("UNIAC_DEPS_JSON", "")
    if not raw:
        return
    try:
        deps = json.loads(raw)
    except json.JSONDecodeError as exc:
        logger.warning("UNIAC_DEPS_JSON is not valid JSON, skipping hydration: %s", exc)
        return
    if not isinstance(deps, dict):
        logger.warning("UNIAC_DEPS_JSON must be a JSON object, got %s", type(deps).__name__)
        return

    for child in service._uniac_walk():
        info = deps.get(child._uniac_local_name)
        if not isinstance(info, dict):
            continue
        url = info.get("url")
        if isinstance(url, str):
            object.__setattr__(child, "_uniac_url", url)
