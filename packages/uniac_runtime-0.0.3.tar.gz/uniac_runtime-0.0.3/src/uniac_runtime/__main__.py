"""Container entrypoint: ``python -m uniac_runtime app:health``

Import-path setup is the very first thing that happens, before any user
module imports.
"""
from __future__ import annotations

import time as _time

_PROCESS_START_MONOTONIC = _time.perf_counter()

try:
    with open("/proc/uptime") as _f:
        _VM_UPTIME_AT_PROCESS_START = float(_f.read().split()[0])
except Exception:
    _VM_UPTIME_AT_PROCESS_START = -1.0

import asyncio
import json
import logging
import os
import socket as _socket
import sys

from .server import StartupTimeline, create_app, readiness_target_from_env, send_ready_callback


logger = logging.getLogger(__name__)


def _configure_logging() -> None:
    if logging.getLogger().handlers:
        return
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )


def _bind_listening_socket(host: str, port: int, backlog: int = 2048) -> _socket.socket:
    # Bind + listen ourselves so the readiness callback can fire the moment
    # ``listen()`` returns. From that instant the kernel completes the TCP
    # handshake for incoming SYNs into the accept queue regardless of
    # whether ``accept()`` has been called — which means Caddy's first
    # connect after the callback succeeds, even if uvicorn hasn't yet
    # entered its accept loop. The handed-off socket goes to
    # ``Server.serve(sockets=[sock])`` so uvicorn wraps the existing fd
    # instead of creating its own.
    family = _socket.AF_INET6 if ":" in host else _socket.AF_INET
    sock = _socket.socket(family, _socket.SOCK_STREAM)
    sock.setsockopt(_socket.SOL_SOCKET, _socket.SO_REUSEADDR, 1)
    sock.bind((host, port))
    sock.listen(backlog)
    sock.setblocking(False)
    return sock


async def _serve_app(
    app,
    *,
    host: str,
    port: int,
    entrypoint: str,
    ready_target: tuple[str, str] | None,
    timeline,
) -> None:
    # Bind ourselves first so the readiness signal is the kernel's listen
    # syscall return, not a polled flag. NodeManager treats the callback
    # as "the guest is ready to take requests" and immediately registers
    # the Caddy route + Consul service; firing it before listen() means
    # Caddy's first connect 502s.
    import uvicorn

    sock = _bind_listening_socket(host, port)
    timeline.mark("server_started")
    logger.info(
        "UNIAC_STARTUP entrypoint=%s host=%s port=%s timings=%s",
        entrypoint,
        host,
        port,
        json.dumps(timeline.as_timings(), sort_keys=True),
    )

    config = uvicorn.Config(app, log_level="info")
    server = uvicorn.Server(config)
    serve_task = asyncio.create_task(server.serve(sockets=[sock]))

    try:
        # Listener is up; kernel is queueing handshakes. Fire the callback.
        if ready_target is not None:
            ready_url, ready_token = ready_target
            timeline.mark("callback_started")
            status_code = await send_ready_callback(
                ready_url,
                ready_token,
                timeline.as_timings(),
            )
            timeline.mark("callback_acked")
            logger.info(
                "UNIAC_READY_CALLBACK entrypoint=%s status=%s timings=%s",
                entrypoint,
                status_code,
                json.dumps(timeline.as_timings(), sort_keys=True),
            )
        else:
            logger.info(
                "UNIAC_READY_CALLBACK entrypoint=%s status=skipped timings=%s",
                entrypoint,
                json.dumps(timeline.as_timings(), sort_keys=True),
            )

        await serve_task
    finally:
        if not serve_task.done():
            server.should_exit = True
            await serve_task
        try:
            sock.close()
        except Exception:
            pass


def main() -> None:
    _configure_logging()
    if len(sys.argv) != 2:
        print(
            "Usage: python -m uniac_runtime <module:object>",
            file=sys.stderr,
        )
        sys.exit(1)

    entrypoint = sys.argv[1]

    timeline = StartupTimeline(
        process_entry=_PROCESS_START_MONOTONIC,
        vm_uptime_at_python_start=_VM_UPTIME_AT_PROCESS_START,
    )

    # --- 1. Set up import path FIRST ---
    # This must happen before importing loader/server, which will in turn
    # import user code that depends on these paths being set.
    project_dir = os.environ.get("UNIAC_PROJECT_DIR", "/app")
    deps_dir = os.environ.get("UNIAC_DEPS_DIR", "deps")

    from .loader import setup_import_path

    setup_import_path(project_dir, deps_dir)
    timeline.mark("import_path_ready")

    # --- 2. Load service or module ---
    from .loader import LoadError, hydrate_deps, load_service

    try:
        module = load_service(entrypoint)
    except LoadError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    timeline.mark("service_loaded")

    # Materialize the Node tree from class-level annotations, then
    # inject child-Node URLs from UNIAC_DEPS_JSON. Both calls must
    # complete before build_app so user code inside FastAPI handlers
    # can read self.<child>.url.
    module._uniac_populate()
    hydrate_deps(module)

    # --- 3. Create app and run ---
    app = create_app(module)
    timeline.mark("app_built")

    port = int(os.environ.get("UNIAC_PORT", "8080"))
    host = os.environ.get("UNIAC_HOST", "0.0.0.0")
    ready_target = readiness_target_from_env()

    asyncio.run(
        _serve_app(
            app,
            host=host,
            port=port,
            entrypoint=entrypoint,
            ready_target=ready_target,
            timeline=timeline,
        )
    )


if __name__ == "__main__":
    main()
