"""Tests for uniac_runtime.loader."""
import json
import sys
import textwrap
from pathlib import Path

import pytest

from uniac.node import Node
from uniac.user.service import FastAPIService
from uniac_runtime.loader import (
    LoadError,
    hydrate_deps,
    load_service,
    setup_import_path,
)


@pytest.fixture()
def tmp_project(tmp_path: Path):
    """Create a minimal FastAPIService in a temp directory."""
    code = textwrap.dedent("""\
        from fastapi import FastAPI
        from uniac import FastAPIService

        class HelloService(FastAPIService):
            def build_app(self):
                api = FastAPI()

                @api.get("/hello")
                def hello():
                    return {"message": "hi"}

                return api

        hello = HelloService()
    """)
    (tmp_path / "app.py").write_text(code)
    return tmp_path


class TestSetupImportPath:

    def test_adds_project_dir(self, tmp_path: Path):
        project = str(tmp_path)
        setup_import_path(str(tmp_path))
        assert project in sys.path

    def test_adds_deps_dir(self, tmp_path: Path):
        deps = str(tmp_path / "deps")
        setup_import_path(str(tmp_path))
        assert deps in sys.path

    def test_idempotent(self, tmp_path: Path):
        setup_import_path(str(tmp_path))
        before = list(sys.path)
        setup_import_path(str(tmp_path))
        assert sys.path == before


class TestLoadService:

    def test_valid_instance(self, tmp_project: Path):
        """When the entrypoint points to an instance, it is returned directly."""
        setup_import_path(str(tmp_project))
        try:
            result = load_service("app:hello")
            assert isinstance(result, FastAPIService)
            assert type(result).__name__ == "HelloService"
        finally:
            sys.modules.pop("app", None)

    def test_valid_class(self, tmp_project: Path):
        """When the entrypoint points to a class, it is instantiated."""
        setup_import_path(str(tmp_project))
        try:
            result = load_service("app:HelloService")
            assert isinstance(result, FastAPIService)
            assert type(result).__name__ == "HelloService"
        finally:
            sys.modules.pop("app", None)

    def test_instance_is_same_object(self, tmp_project: Path):
        """Loading an instance returns the exact same object."""
        setup_import_path(str(tmp_project))
        try:
            import importlib
            mod = importlib.import_module("app")
            original = mod.hello
            result = load_service("app:hello")
            assert result is original
        finally:
            sys.modules.pop("app", None)

    def test_missing_colon(self):
        with pytest.raises(LoadError, match="expected 'module:object'"):
            load_service("appHelloService")

    def test_empty_module(self):
        with pytest.raises(LoadError, match="must be non-empty"):
            load_service(":HelloService")

    def test_empty_object(self):
        with pytest.raises(LoadError, match="must be non-empty"):
            load_service("app:")

    def test_module_not_found(self, tmp_path: Path):
        setup_import_path(str(tmp_path))
        with pytest.raises(LoadError, match="Cannot import module"):
            load_service("nonexistent_module:Foo")

    def test_attribute_not_found(self, tmp_project: Path):
        setup_import_path(str(tmp_project))
        try:
            with pytest.raises(LoadError, match="has no attribute"):
                load_service("app:DoesNotExist")
        finally:
            sys.modules.pop("app", None)

    def test_not_a_service(self, tmp_path: Path):
        (tmp_path / "bad.py").write_text("class Foo: pass\n")
        setup_import_path(str(tmp_path))
        try:
            with pytest.raises(LoadError, match="not a Service instance or subclass"):
                load_service("bad:Foo")
        finally:
            sys.modules.pop("bad", None)


# ---- Test fixtures for hydrate_deps ----

class _DbNode(Node):
    _uniac_primitive = "db"


class _CacheNode(Node):
    _uniac_primitive = "cache"


class _Greeter(FastAPIService):
    db: _DbNode
    cache: _CacheNode

    def build_app(self):
        from fastapi import FastAPI
        return FastAPI()


class TestHydrateDeps:

    def test_no_env_var_leaves_urls_unset(self, monkeypatch):
        monkeypatch.delenv("UNIAC_DEPS_JSON", raising=False)
        svc = _Greeter()
        svc._uniac_populate()
        hydrate_deps(svc)
        assert svc.db.url is None
        assert svc.cache.url is None

    def test_empty_env_var_leaves_urls_unset(self, monkeypatch):
        monkeypatch.setenv("UNIAC_DEPS_JSON", "")
        svc = _Greeter()
        svc._uniac_populate()
        hydrate_deps(svc)
        assert svc.db.url is None

    def test_hydrates_each_child_by_local_name(self, monkeypatch):
        monkeypatch.setenv("UNIAC_DEPS_JSON", json.dumps({
            "db": {"url": "https://abc.svc.uniac.ai", "primitive": "db", "version": "latest"},
            "cache": {"url": "https://def.svc.uniac.ai", "primitive": "cache", "version": "1.0"},
        }))
        svc = _Greeter()
        svc._uniac_populate()
        hydrate_deps(svc)
        assert svc.db.url == "https://abc.svc.uniac.ai"
        assert svc.cache.url == "https://def.svc.uniac.ai"

    def test_skips_children_missing_from_env(self, monkeypatch):
        """If only some children appear in UNIAC_DEPS_JSON, hydrate
        only those — don't fail on the others."""
        monkeypatch.setenv("UNIAC_DEPS_JSON", json.dumps({
            "db": {"url": "https://abc.svc.uniac.ai"},
        }))
        svc = _Greeter()
        svc._uniac_populate()
        hydrate_deps(svc)
        assert svc.db.url == "https://abc.svc.uniac.ai"
        assert svc.cache.url is None

    def test_invalid_json_logs_and_continues(self, monkeypatch):
        monkeypatch.setenv("UNIAC_DEPS_JSON", "not-json")
        svc = _Greeter()
        svc._uniac_populate()
        # Must not raise.
        hydrate_deps(svc)
        assert svc.db.url is None

    def test_non_object_payload_logs_and_continues(self, monkeypatch):
        """JSON array (or any non-object) is rejected gracefully."""
        monkeypatch.setenv("UNIAC_DEPS_JSON", "[1, 2, 3]")
        svc = _Greeter()
        svc._uniac_populate()
        hydrate_deps(svc)
        assert svc.db.url is None

    def test_child_without_url_field_skipped(self, monkeypatch):
        """A child entry missing the `url` key is skipped without error."""
        monkeypatch.setenv("UNIAC_DEPS_JSON", json.dumps({
            "db": {"primitive": "db"},  # no `url`
        }))
        svc = _Greeter()
        svc._uniac_populate()
        hydrate_deps(svc)
        assert svc.db.url is None

    def test_url_property_reflects_hydrated_value(self, monkeypatch):
        """User code reads ``self.db.url`` (not ``_uniac_url``); the property
        must surface the hydrated value."""
        monkeypatch.setenv("UNIAC_DEPS_JSON", json.dumps({
            "db": {"url": "https://x.test"},
        }))
        svc = _Greeter()
        svc._uniac_populate()
        hydrate_deps(svc)
        assert svc.db.url == "https://x.test"
