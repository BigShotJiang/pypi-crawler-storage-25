"""FastMCP server exposing CoinGeckoPandas as MCP tools.

Run with: ``coingecko-mcp`` (after ``uv pip install -e ".[mcp]"``).
"""

from __future__ import annotations

import inspect
from typing import Any

import pandas as pd
from fastmcp import FastMCP
from tabulate import tabulate

from coingecko_pandas import CoinGeckoPandas

mcp = FastMCP("coingecko-pandas")
_client: CoinGeckoPandas | None = None


def _get_client() -> CoinGeckoPandas:
    global _client
    if _client is None:
        _client = CoinGeckoPandas()
    return _client


def _format_result(result: Any) -> str:
    if isinstance(result, pd.DataFrame):
        if result.empty:
            return "(empty DataFrame)"
        return tabulate(result.head(50), headers="keys", tablefmt="pipe", showindex=False)
    if isinstance(result, dict):
        return tabulate(list(result.items()), headers=["key", "value"], tablefmt="pipe")
    return str(result)


def _register_tools() -> None:
    client = _get_client()
    for name in dir(CoinGeckoPandas):
        if name.startswith("_"):
            continue
        attr = getattr(CoinGeckoPandas, name, None)
        if not callable(attr):
            continue

        sig = inspect.signature(attr)
        doc = inspect.getdoc(attr) or name

        def _make_tool(method_name: str, _doc: str = doc, _sig: inspect.Signature = sig):
            def _tool(**kwargs) -> str:
                fn = getattr(client, method_name)
                return _format_result(fn(**kwargs))

            _tool.__name__ = method_name
            _tool.__doc__ = _doc
            _tool.__signature__ = _sig.replace(
                parameters=[p for p in _sig.parameters.values() if p.name != "self"]
            )
            return _tool

        mcp.tool(name=name, description=doc)(_make_tool(name))


def main() -> None:
    _register_tools()
    mcp.run()


if __name__ == "__main__":
    main()
