"""Stateless helpers shared across the coingecko-pandas client."""

from __future__ import annotations

from datetime import datetime

import orjson
import pandas as pd

__all__ = [
    "DEFAULT_BOOL_COLUMNS",
    "DEFAULT_DROP_COLUMNS",
    "DEFAULT_INT_DATETIME_COLUMNS",
    "DEFAULT_JSON_COLUMNS",
    "DEFAULT_MS_INT_DATETIME_COLUMNS",
    "DEFAULT_NUMERIC_COLUMNS",
    "DEFAULT_STR_DATETIME_COLUMNS",
    "expand_column_lists",
    "filter_params",
    "instance_cache",
    "preprocess_dataframe",
    "preprocess_dict",
    "snake_columns_to_camel",
    "snake_to_camel",
    "to_unix_timestamp",
]


# CoinGecko-specific defaults — built from the spec response shapes
DEFAULT_NUMERIC_COLUMNS: tuple = (
    "current_price",
    "market_cap",
    "market_cap_rank",
    "fully_diluted_valuation",
    "total_volume",
    "high_24h",
    "low_24h",
    "price_change_24h",
    "price_change_percentage_24h",
    "market_cap_change_24h",
    "market_cap_change_percentage_24h",
    "circulating_supply",
    "total_supply",
    "max_supply",
    "ath",
    "ath_change_percentage",
    "atl",
    "atl_change_percentage",
    "price_change_percentage_1h_in_currency",
    "price_change_percentage_24h_in_currency",
    "price_change_percentage_7d_in_currency",
    "price_change_percentage_14d_in_currency",
    "price_change_percentage_30d_in_currency",
    "price_change_percentage_200d_in_currency",
    "price_change_percentage_1y_in_currency",
    "trust_score",
    "bid_ask_spread_percentage",
    "volume",
    "value",
    "trade_volume_24h_btc",
    "trade_volume_24h_btc_normalized",
    "open_interest_btc",
    "open_interest",
    "funding_rate",
    "basis",
    "spread",
    "expired_at",
    "trust_rank",
    "year_established",
    "last",
)

DEFAULT_STR_DATETIME_COLUMNS: tuple = (
    "last_updated",
    "ath_date",
    "atl_date",
    "timestamp",
    "genesis_date",
    "filing_date",
    "last_traded_at",
    "last_fetch_at",
)

DEFAULT_INT_DATETIME_COLUMNS: tuple = ()
DEFAULT_MS_INT_DATETIME_COLUMNS: tuple = ()
DEFAULT_BOOL_COLUMNS: tuple = (
    "is_anomaly",
    "is_stale",
    "trade_url",
    "perpetual",
)
DEFAULT_DROP_COLUMNS: tuple = ("icon", "image", "thumb", "small", "large")
DEFAULT_JSON_COLUMNS: tuple = ()


# ── Conversions ──────────────────────────────────────────────────────


def to_unix_timestamp(value: int | float | str | pd.Timestamp | datetime) -> int:
    """Convert a datetime-like value to a Unix timestamp in seconds."""
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str):
        value = pd.Timestamp(value, tz="UTC")
    if isinstance(value, pd.Timestamp):
        if value.tzinfo is None:
            value = value.tz_localize("UTC")
        return int(value.timestamp())
    if isinstance(value, datetime):
        if value.tzinfo is None:
            from zoneinfo import ZoneInfo

            value = value.replace(tzinfo=ZoneInfo("UTC"))
        return int(value.timestamp())
    raise TypeError(f"Cannot convert {type(value).__name__} to Unix timestamp")


def snake_to_camel(value: str) -> str:
    """Convert snake_case (or kebab-case) to lowerCamelCase."""
    if "_" in value:
        parts = value.split("_")
        value = parts[0] + "".join(p[:1].upper() + p[1:] for p in parts[1:] if p)
    return value


def snake_columns_to_camel(data: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of df with camelCase column names."""
    data = data.copy()
    data.columns = [snake_to_camel(col) for col in data.columns]
    return data


# ── Caching ──────────────────────────────────────────────────────────


def instance_cache(method=None, *, ttl: float | None = None, maxsize: int = 256):
    """Cache results of an instance method, keyed by arguments."""
    from cachetools import Cache, TTLCache, cachedmethod

    def decorator(fn):
        attr = f"_cache_{fn.__name__}"

        def _get_cache(self):
            cache = getattr(self, attr, None)
            if cache is None:
                cache = TTLCache(maxsize=maxsize, ttl=ttl) if ttl else Cache(maxsize=maxsize)
                setattr(self, attr, cache)
            return cache

        return cachedmethod(_get_cache)(fn)

    if method is not None:
        return decorator(method)
    return decorator


# ── Param filtering ──────────────────────────────────────────────────


def filter_params(params: dict | None) -> dict:
    """Remove None values and empty lists; convert Timestamps to Unix seconds."""
    if params is None:
        return {}
    new_params = {}
    for key, value in params.items():
        if isinstance(value, list):
            if len(value) > 0:
                new_params[key] = value
        elif pd.notnull(value):
            if isinstance(value, (pd.Timestamp, datetime)):
                value = int(value.timestamp())
            new_params[key] = value
    return new_params


# ── Preprocessing ────────────────────────────────────────────────────


def preprocess_dataframe(
    df: pd.DataFrame,
    *,
    numeric_columns: list,
    str_datetime_columns: list,
    int_datetime_columns: list,
    ms_int_datetime_columns: list,
    bool_columns: list,
    drop_columns: list,
    json_columns: list,
    int_datetime_unit: str = "s",
) -> pd.DataFrame:
    """Apply column renaming and type coercion to a raw API DataFrame."""
    df = snake_columns_to_camel(df)
    df = df.drop(columns=drop_columns, errors="ignore")
    columns = df.columns

    numeric_to_convert = [
        x for x in columns if x in numeric_columns + int_datetime_columns + ms_int_datetime_columns
    ]
    int_datetime_to_convert = [x for x in columns if x in int_datetime_columns]
    ms_int_datetime_to_convert = [x for x in columns if x in ms_int_datetime_columns]
    str_datetime_to_convert = [x for x in columns if x in str_datetime_columns]
    bool_to_convert = [x for x in columns if x in bool_columns]
    json_to_convert = [x for x in columns if x in json_columns]

    if numeric_to_convert:
        df[numeric_to_convert] = df[numeric_to_convert].apply(pd.to_numeric, errors="coerce")
    if int_datetime_to_convert:
        df[int_datetime_to_convert] = df[int_datetime_to_convert].apply(
            pd.to_datetime, utc=True, unit=int_datetime_unit, errors="coerce"
        )
    if ms_int_datetime_to_convert:
        df[ms_int_datetime_to_convert] = df[ms_int_datetime_to_convert].apply(
            pd.to_datetime, utc=True, unit="ms", errors="coerce"
        )
    for col in str_datetime_to_convert:
        df[col] = pd.to_datetime(df[col], utc=True, errors="coerce")

    _bool_map = {
        "true": True,
        "True": True,
        "1": True,
        True: True,
        "false": False,
        "False": False,
        "0": False,
        "": False,
        False: False,
    }
    for col in bool_to_convert:
        df[col] = df[col].map(_bool_map).astype("boolean")
    for column in json_to_convert:
        df[column] = df[column].apply(lambda x: orjson.loads(x) if pd.notnull(x) else x)
    return df


def preprocess_dict(
    data: dict,
    *,
    numeric_columns: list,
    str_datetime_columns: list,
    int_datetime_columns: list,
    ms_int_datetime_columns: list,
    bool_columns: list,
    drop_columns: list,
    json_columns: list,
) -> dict:
    """Apply the same coercion as preprocess_dataframe to a single dict."""
    data = {snake_to_camel(k): v for k, v in data.items()}
    for key in drop_columns:
        data.pop(key, None)

    for key, val in list(data.items()):
        if not isinstance(val, str):
            continue
        if key in json_columns:
            try:
                data[key] = orjson.loads(val)
            except Exception:
                pass
        elif key in (*numeric_columns, *int_datetime_columns, *ms_int_datetime_columns):
            try:
                data[key] = float(val)
            except (ValueError, TypeError):
                pass
        elif key in str_datetime_columns:
            try:
                data[key] = pd.Timestamp(val, tz="UTC")
            except Exception:
                pass
        elif key in bool_columns:
            data[key] = val.lower() not in ("false", "0", "")
    return data


def expand_column_lists(base: tuple, prefixes: tuple = ()) -> list:
    """Return base columns plus prefixed camelCase variants."""
    result = [snake_to_camel(x) for x in base]
    for prefix in prefixes:
        result += [snake_to_camel(f"{prefix}_{x}") for x in base]
    return result
