"""coingecko-pandas — pandas-style API client for CoinGecko."""

from __future__ import annotations

from coingecko_pandas.async_client import AsyncCoinGeckoPandas
from coingecko_pandas.client import CoinGeckoPandas

try:
    from coingecko_pandas.async_ws import AsyncCoinGeckoWebSocket
    from coingecko_pandas.ws import CoinGeckoWebSocket
except ImportError:  # ws extras not installed
    CoinGeckoWebSocket = None  # type: ignore[assignment,misc]
    AsyncCoinGeckoWebSocket = None  # type: ignore[assignment,misc]
from coingecko_pandas.exceptions import (
    CoinGeckoAPIError,
    CoinGeckoAuthError,
    CoinGeckoError,
    CoinGeckoRateLimitError,
)
from coingecko_pandas.schemas import (
    AssetPlatformSchema,
    CategorySchema,
    CoinSchema,
    CurrencySchema,
    DerivativeExchangeSchema,
    DerivativeSchema,
    ExchangeRateSchema,
    ExchangeSchema,
    MarketChartSchema,
    MarketSchema,
    NFTSchema,
    OHLCSchema,
    SimplePriceSchema,
    TickerSchema,
    TreasuryEntitySchema,
    TreasuryTransactionSchema,
    VolumeChartSchema,
)
from coingecko_pandas.types import (
    CoinDetail,
    CoinHistory,
    DerivativeExchangeDetail,
    ExchangeDetail,
    GlobalData,
    GlobalDeFi,
    NFTDetail,
    Ping,
    SearchResult,
    TokenList,
    TreasuryEntityDetail,
    TrendingResult,
)

__all__ = [
    "AssetPlatformSchema",
    "AsyncCoinGeckoPandas",
    "AsyncCoinGeckoWebSocket",
    "CoinGeckoWebSocket",
    "CategorySchema",
    "CoinDetail",
    "CoinGeckoAPIError",
    "CoinGeckoAuthError",
    "CoinGeckoError",
    "CoinGeckoPandas",
    "CoinGeckoRateLimitError",
    "CoinHistory",
    "CoinSchema",
    "CurrencySchema",
    "DerivativeExchangeDetail",
    "DerivativeExchangeSchema",
    "DerivativeSchema",
    "ExchangeDetail",
    "ExchangeRateSchema",
    "ExchangeSchema",
    "GlobalData",
    "GlobalDeFi",
    "MarketChartSchema",
    "MarketSchema",
    "NFTDetail",
    "NFTSchema",
    "OHLCSchema",
    "Ping",
    "SearchResult",
    "SimplePriceSchema",
    "TickerSchema",
    "TokenList",
    "TreasuryEntityDetail",
    "TreasuryEntitySchema",
    "TreasuryTransactionSchema",
    "TrendingResult",
    "VolumeChartSchema",
]
