"""Sync WebSocket client for CoinGecko (websocket-client based).

CoinGecko publishes 4 channels:

| Channel name              | Code | Purpose                                  |
|---------------------------|------|------------------------------------------|
| OnchainSimpleTokenPrice   | G1   | Real-time token prices (GeckoTerminal)   |
| CGSimplePrice             | C1   | Real-time token prices (CoinGecko)       |
| OnchainTrade              | G2   | Real-time pool trades                    |
| OnchainOHLCV              | G3   | Real-time pool OHLCV                     |

The Pro WebSocket URL and exact subscribe payload format are not publicly
documented; check the CoinGecko Pro dashboard for the current URL.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Self

import pandas as pd
from websocket import WebSocketApp

from coingecko_pandas.utils import preprocess_dataframe as _preprocess_dataframe


@dataclass
class CoinGeckoWebSocket:
    """Sync WebSocket client. Use ``from_client(client)`` to share column config."""

    ws_url: str = "wss://ws.coingecko.com/v1"  # placeholder — confirm with Pro dashboard
    api_key: str | None = None
    ping_interval: int = 10  # CoinGecko sends ping every 10s
    numeric_columns: tuple = ()
    str_datetime_columns: tuple = ()
    int_datetime_columns: tuple = ()
    ms_int_datetime_columns: tuple = ()
    bool_columns: tuple = ()
    drop_columns: tuple = ()
    json_columns: tuple = ()

    @classmethod
    def from_client(cls, client) -> Self:
        """Build a WS client that shares column config with an HTTP client."""
        return cls(
            api_key=getattr(client, "pro_api_key", None) or getattr(client, "api_key", None),
            numeric_columns=tuple(client._numeric_columns),
            str_datetime_columns=tuple(client._str_datetime_columns),
            int_datetime_columns=tuple(client._int_datetime_columns),
            ms_int_datetime_columns=tuple(client._ms_int_datetime_columns),
            bool_columns=tuple(client._bool_columns),
            drop_columns=tuple(client._drop_columns),
            json_columns=tuple(client._json_columns),
        )

    def _preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        return _preprocess_dataframe(
            df,
            numeric_columns=list(self.numeric_columns),
            str_datetime_columns=list(self.str_datetime_columns),
            int_datetime_columns=list(self.int_datetime_columns),
            ms_int_datetime_columns=list(self.ms_int_datetime_columns),
            bool_columns=list(self.bool_columns),
            drop_columns=list(self.drop_columns),
            json_columns=list(self.json_columns),
        )

    # ── Channel subscriptions ───────────────────────────────────────────

    def subscribe_simple_price(self, **payload) -> CoinGeckoWebSocketSession:
        """Subscribe to ``CGSimplePrice`` (C1) — CoinGecko real-time prices."""
        return self._open(channel="C1", payload=payload)

    def subscribe_onchain_token_price(self, **payload) -> CoinGeckoWebSocketSession:
        """Subscribe to ``OnchainSimpleTokenPrice`` (G1) — GeckoTerminal token prices."""
        return self._open(channel="G1", payload=payload)

    def subscribe_onchain_trade(self, **payload) -> CoinGeckoWebSocketSession:
        """Subscribe to ``OnchainTrade`` (G2) — pool trades."""
        return self._open(channel="G2", payload=payload)

    def subscribe_onchain_ohlcv(self, **payload) -> CoinGeckoWebSocketSession:
        """Subscribe to ``OnchainOHLCV`` (G3) — pool OHLCV."""
        return self._open(channel="G3", payload=payload)

    def _open(self, *, channel: str, payload: dict) -> CoinGeckoWebSocketSession:
        return CoinGeckoWebSocketSession(
            ws_url=self.ws_url,
            api_key=self.api_key,
            channel=channel,
            subscribe_payload=payload,
            ping_interval=self.ping_interval,
            preprocessor=self._preprocess,
        )


@dataclass
class CoinGeckoWebSocketSession:
    ws_url: str
    api_key: str | None
    channel: str
    subscribe_payload: dict
    ping_interval: int
    preprocessor: Callable[[pd.DataFrame], pd.DataFrame]
    _app: WebSocketApp | None = field(default=None, init=False, repr=False)

    def __enter__(self) -> Self:
        url = self.ws_url
        if self.api_key:
            url += ("&" if "?" in url else "?") + f"api_key={self.api_key}"
        self._app = WebSocketApp(
            url,
            on_open=self._on_open,
            on_message=self._on_message,
            on_ping=self._on_ping,
        )
        threading.Thread(target=self._app.run_forever, daemon=True).start()
        return self

    def __exit__(self, *_: object) -> None:
        if self._app is not None:
            self._app.close()

    def _on_open(self, ws):
        ws.send(
            json.dumps({"type": "subscribe", "channel": self.channel, **self.subscribe_payload})
        )

    def _on_message(self, ws, message):
        # Override or hook a queue in your subclass
        pass

    def _on_ping(self, ws, message):
        # Respond to keep connection alive (must reply within 20s)
        try:
            ws.send(json.dumps({"type": "pong"}))
        except Exception:
            pass
