"""Pandera DataFrameModel schemas for CoinGecko endpoints.

Convention: every public method that returns a ``pd.DataFrame`` is annotated
``DataFrame[SomeSchema]``. All schemas are lenient (``strict=False``,
``coerce=True``) so the API can add fields without breaking us.
"""

from __future__ import annotations

import pandera.pandas as pa


class _Lenient(pa.DataFrameModel):
    class Config:
        strict = False
        coerce = True


# ── Coins ────────────────────────────────────────────────────────────


class CoinSchema(_Lenient):
    """Schema for ``coins_list`` (id/symbol/name map)."""

    id: str | None = pa.Field(nullable=True)
    symbol: str | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)


class MarketSchema(_Lenient):
    """Schema for ``coins_markets`` and per-coin market entries."""

    id: str | None = pa.Field(nullable=True)
    symbol: str | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)
    currentPrice: float | None = pa.Field(nullable=True, alias="currentPrice")
    marketCap: float | None = pa.Field(nullable=True)
    marketCapRank: float | None = pa.Field(nullable=True)
    fullyDilutedValuation: float | None = pa.Field(nullable=True)
    totalVolume: float | None = pa.Field(nullable=True)
    high24h: float | None = pa.Field(nullable=True)
    low24h: float | None = pa.Field(nullable=True)
    priceChange24h: float | None = pa.Field(nullable=True)
    priceChangePercentage24h: float | None = pa.Field(nullable=True)
    circulatingSupply: float | None = pa.Field(nullable=True)
    totalSupply: float | None = pa.Field(nullable=True)
    maxSupply: float | None = pa.Field(nullable=True)
    ath: float | None = pa.Field(nullable=True)
    atl: float | None = pa.Field(nullable=True)


class TickerSchema(_Lenient):
    """Schema for tickers (per-coin / per-exchange)."""

    base: str | None = pa.Field(nullable=True)
    target: str | None = pa.Field(nullable=True)
    last: float | None = pa.Field(nullable=True)
    volume: float | None = pa.Field(nullable=True)
    trustScore: str | None = pa.Field(nullable=True)
    bidAskSpreadPercentage: float | None = pa.Field(nullable=True)
    timestamp: object | None = pa.Field(nullable=True)
    lastTradedAt: object | None = pa.Field(nullable=True)
    lastFetchAt: object | None = pa.Field(nullable=True)
    isAnomaly: bool | None = pa.Field(nullable=True)
    isStale: bool | None = pa.Field(nullable=True)


class MarketChartSchema(_Lenient):
    """Schema for /coins/{id}/market_chart and similar (price/cap/vol over time)."""

    timestamp: object | None = pa.Field(nullable=True)
    price: float | None = pa.Field(nullable=True)
    marketCap: float | None = pa.Field(nullable=True)
    volume: float | None = pa.Field(nullable=True)


class OHLCSchema(_Lenient):
    """Schema for /coins/{id}/ohlc."""

    timestamp: object | None = pa.Field(nullable=True)
    open: float | None = pa.Field(nullable=True)
    high: float | None = pa.Field(nullable=True)
    low: float | None = pa.Field(nullable=True)
    close: float | None = pa.Field(nullable=True)


class VolumeChartSchema(_Lenient):
    """Schema for exchange volume_chart and treasury holding_chart."""

    timestamp: object | None = pa.Field(nullable=True)
    volume: float | None = pa.Field(nullable=True)


# ── Exchanges / derivatives ──────────────────────────────────────────


class ExchangeSchema(_Lenient):
    id: str | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)
    yearEstablished: float | None = pa.Field(nullable=True)
    country: str | None = pa.Field(nullable=True)
    description: str | None = pa.Field(nullable=True)
    url: str | None = pa.Field(nullable=True)
    trustScore: float | None = pa.Field(nullable=True)
    trustScoreRank: float | None = pa.Field(nullable=True)
    tradeVolume24hBtc: float | None = pa.Field(nullable=True)
    tradeVolume24hBtcNormalized: float | None = pa.Field(nullable=True)


class DerivativeSchema(_Lenient):
    market: str | None = pa.Field(nullable=True)
    symbol: str | None = pa.Field(nullable=True)
    indexId: str | None = pa.Field(nullable=True)
    price: str | None = pa.Field(nullable=True)
    contractType: str | None = pa.Field(nullable=True)
    basis: float | None = pa.Field(nullable=True)
    spread: float | None = pa.Field(nullable=True)
    fundingRate: float | None = pa.Field(nullable=True)
    openInterest: float | None = pa.Field(nullable=True)
    volume24h: float | None = pa.Field(nullable=True)


class DerivativeExchangeSchema(_Lenient):
    name: str | None = pa.Field(nullable=True)
    id: str | None = pa.Field(nullable=True)
    openInterestBtc: float | None = pa.Field(nullable=True)
    tradeVolume24hBtc: str | None = pa.Field(nullable=True)
    numberOfPerpetualPairs: float | None = pa.Field(nullable=True)
    numberOfFuturesPairs: float | None = pa.Field(nullable=True)
    yearEstablished: float | None = pa.Field(nullable=True)


# ── NFTs ─────────────────────────────────────────────────────────────


class NFTSchema(_Lenient):
    id: str | None = pa.Field(nullable=True)
    contractAddress: str | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)
    assetPlatformId: str | None = pa.Field(nullable=True)
    symbol: str | None = pa.Field(nullable=True)


# ── Categories / asset platforms ─────────────────────────────────────


class CategorySchema(_Lenient):
    id: str | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)
    marketCap: float | None = pa.Field(nullable=True)
    marketCapChange24h: float | None = pa.Field(nullable=True)
    volume24h: float | None = pa.Field(nullable=True)


class AssetPlatformSchema(_Lenient):
    id: str | None = pa.Field(nullable=True)
    chainIdentifier: float | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)
    shortname: str | None = pa.Field(nullable=True)


# ── Misc ─────────────────────────────────────────────────────────────


class CurrencySchema(_Lenient):
    """Schema for /simple/supported_vs_currencies."""

    currency: str | None = pa.Field(nullable=True)


class ExchangeRateSchema(_Lenient):
    """Schema for /exchange_rates."""

    currency: str | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)
    unit: str | None = pa.Field(nullable=True)
    value: float | None = pa.Field(nullable=True)
    type: str | None = pa.Field(nullable=True)


class SimplePriceSchema(_Lenient):
    """Schema for /simple/price (dict-of-dicts pivoted)."""

    id: str | None = pa.Field(nullable=True)


class TreasuryEntitySchema(_Lenient):
    id: str | None = pa.Field(nullable=True)
    name: str | None = pa.Field(nullable=True)
    type: str | None = pa.Field(nullable=True)


class TreasuryTransactionSchema(_Lenient):
    timestamp: object | None = pa.Field(nullable=True)
    type: str | None = pa.Field(nullable=True)
    amount: float | None = pa.Field(nullable=True)
    coinId: str | None = pa.Field(nullable=True)
