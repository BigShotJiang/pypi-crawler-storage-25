"""Async WebSocket client for CoinGecko (websockets library).

See ``coingecko_pandas.ws`` for the channel reference table.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Self

import pandas as pd
import websockets

from coingecko_pandas.utils import preprocess_dataframe as _preprocess_dataframe


@dataclass
class AsyncCoinGeckoWebSocket:
    """Async WebSocket client. Use ``from_client(client)`` to share column config."""

    ws_url: str = "wss://ws.coingecko.com/v1"  # placeholder — confirm with Pro dashboard
    api_key: str | None = None
    ping_interval: int = 10
    reconnect_max_backoff: float = 30.0
    numeric_columns: tuple = ()
    str_datetime_columns: tuple = ()
    int_datetime_columns: tuple = ()
    ms_int_datetime_columns: tuple = ()
    bool_columns: tuple = ()
    drop_columns: tuple = ()
    json_columns: tuple = ()

    @classmethod
    def from_client(cls, client) -> Self:
        sync = getattr(client, "_sync", client)
        return cls(
            api_key=getattr(sync, "pro_api_key", None) or getattr(sync, "api_key", None),
            numeric_columns=tuple(sync._numeric_columns),
            str_datetime_columns=tuple(sync._str_datetime_columns),
            int_datetime_columns=tuple(sync._int_datetime_columns),
            ms_int_datetime_columns=tuple(sync._ms_int_datetime_columns),
            bool_columns=tuple(sync._bool_columns),
            drop_columns=tuple(sync._drop_columns),
            json_columns=tuple(sync._json_columns),
        )

    def _preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        return _preprocess_dataframe(
            df,
            numeric_columns=list(self.numeric_columns),
            str_datetime_columns=list(self.str_datetime_columns),
            int_datetime_columns=list(self.int_datetime_columns),
            ms_int_datetime_columns=list(self.ms_int_datetime_columns),
            bool_columns=list(self.bool_columns),
            drop_columns=list(self.drop_columns),
            json_columns=list(self.json_columns),
        )

    def subscribe_simple_price(self, **payload) -> AsyncCoinGeckoWebSocketSession:
        return self._open(channel="C1", payload=payload)

    def subscribe_onchain_token_price(self, **payload) -> AsyncCoinGeckoWebSocketSession:
        return self._open(channel="G1", payload=payload)

    def subscribe_onchain_trade(self, **payload) -> AsyncCoinGeckoWebSocketSession:
        return self._open(channel="G2", payload=payload)

    def subscribe_onchain_ohlcv(self, **payload) -> AsyncCoinGeckoWebSocketSession:
        return self._open(channel="G3", payload=payload)

    def _open(self, *, channel: str, payload: dict) -> AsyncCoinGeckoWebSocketSession:
        return AsyncCoinGeckoWebSocketSession(
            ws_url=self.ws_url,
            api_key=self.api_key,
            channel=channel,
            subscribe_payload=payload,
            ping_interval=self.ping_interval,
            reconnect_max_backoff=self.reconnect_max_backoff,
            preprocessor=self._preprocess,
        )


@dataclass
class AsyncCoinGeckoWebSocketSession:
    ws_url: str
    api_key: str | None
    channel: str
    subscribe_payload: dict
    ping_interval: int
    reconnect_max_backoff: float
    preprocessor: Callable[[pd.DataFrame], pd.DataFrame]
    _ws: object | None = field(default=None, init=False, repr=False)
    _ping_task: asyncio.Task | None = field(default=None, init=False, repr=False)

    async def __aenter__(self) -> Self:
        await self._connect()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def _connect(self) -> None:
        url = self.ws_url
        if self.api_key:
            url += ("&" if "?" in url else "?") + f"api_key={self.api_key}"
        backoff = 1.0
        while True:
            try:
                self._ws = await websockets.connect(url)
                await self._ws.send(
                    json.dumps(
                        {
                            "type": "subscribe",
                            "channel": self.channel,
                            **self.subscribe_payload,
                        }
                    )
                )
                self._ping_task = asyncio.create_task(self._ping_loop())
                return
            except Exception:
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, self.reconnect_max_backoff)

    async def _ping_loop(self) -> None:
        while self._ws is not None:
            try:
                await self._ws.ping()
            except Exception:
                return
            await asyncio.sleep(self.ping_interval)

    async def close(self) -> None:
        if self._ping_task:
            self._ping_task.cancel()
        if self._ws:
            await self._ws.close()

    def __aiter__(self) -> AsyncCoinGeckoWebSocketSession:
        return self

    async def __anext__(self) -> tuple[str, object]:
        while True:
            if self._ws is None:
                await self._connect()
            try:
                raw = await self._ws.recv()
            except websockets.ConnectionClosed:
                await self._connect()
                continue
            payload = json.loads(raw)
            if isinstance(payload, dict):
                return payload.get("type", "message"), payload
            return "message", payload
