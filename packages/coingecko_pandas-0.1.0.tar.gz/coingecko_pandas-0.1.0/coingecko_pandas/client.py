"""CoinGeckoPandas — core HTTP client dataclass."""

from __future__ import annotations

import inspect
import os
from dataclasses import dataclass, field
from typing import Self

import httpx
import pandas as pd
from tqdm import tqdm

from coingecko_pandas.exceptions import (
    CoinGeckoAPIError,
    CoinGeckoAuthError,
    CoinGeckoRateLimitError,
)
from coingecko_pandas.mixins import (
    AssetPlatformsMixin,
    CategoriesMixin,
    CoinsMixin,
    ContractMixin,
    DerivativesMixin,
    ExchangeRatesMixin,
    ExchangesMixin,
    GlobalMixin,
    NFTsMixin,
    PingMixin,
    PublicTreasuryMixin,
    SearchMixin,
    SimpleMixin,
    TrendingMixin,
)
from coingecko_pandas.utils import (
    DEFAULT_BOOL_COLUMNS,
    DEFAULT_DROP_COLUMNS,
    DEFAULT_INT_DATETIME_COLUMNS,
    DEFAULT_JSON_COLUMNS,
    DEFAULT_MS_INT_DATETIME_COLUMNS,
    DEFAULT_NUMERIC_COLUMNS,
    DEFAULT_STR_DATETIME_COLUMNS,
    expand_column_lists,
    filter_params,
)
from coingecko_pandas.utils import (
    preprocess_dataframe as _preprocess_dataframe,
)
from coingecko_pandas.utils import (
    preprocess_dict as _preprocess_dict,
)


@dataclass
class CoinGeckoPandas(
    PingMixin,
    SimpleMixin,
    SearchMixin,
    CoinsMixin,
    ContractMixin,
    AssetPlatformsMixin,
    CategoriesMixin,
    ExchangesMixin,
    DerivativesMixin,
    NFTsMixin,
    ExchangeRatesMixin,
    TrendingMixin,
    GlobalMixin,
    PublicTreasuryMixin,
):
    """CoinGecko HTTP client returning preprocessed pandas DataFrames.

    All endpoint methods live in the mixins; this class provides the HTTP
    transport, authentication, DataFrame preprocessing, and pagination
    infrastructure. Credentials fall back to environment variables when
    not supplied. Use as a context manager to close the connection pool.
    """

    base_url: str = "https://api.coingecko.com/api/v3/"
    timeout: int = field(default=30, repr=False)
    api_key: str | None = field(default=None, repr=False)
    pro_api_key: str | None = field(default=None, repr=False)
    max_pages: int = field(default=100, repr=False)
    use_tqdm: bool = field(default=True, repr=True)
    tqdm_description: str = field(default="", repr=False)

    numeric_columns: tuple = field(default=DEFAULT_NUMERIC_COLUMNS, repr=False)
    str_datetime_columns: tuple = field(default=DEFAULT_STR_DATETIME_COLUMNS, repr=False)
    int_datetime_columns: tuple = field(default=DEFAULT_INT_DATETIME_COLUMNS, repr=False)
    ms_int_datetime_columns: tuple = field(default=DEFAULT_MS_INT_DATETIME_COLUMNS, repr=False)
    bool_columns: tuple = field(default=DEFAULT_BOOL_COLUMNS, repr=False)
    drop_columns: tuple = field(default=DEFAULT_DROP_COLUMNS, repr=False)
    json_columns: tuple = field(default=DEFAULT_JSON_COLUMNS, repr=False)

    def __post_init__(self) -> None:
        if self.api_key is None:
            self.api_key = os.getenv("COINGECKO_API_KEY") or os.getenv("COINGECKO_DEMO_API_KEY")
        if self.pro_api_key is None:
            self.pro_api_key = os.getenv("COINGECKO_PRO_API_KEY")

        # Pro key overrides demo if both are set; switch base URL accordingly
        if self.pro_api_key and self.base_url.startswith("https://api.coingecko.com"):
            self.base_url = "https://pro-api.coingecko.com/api/v3/"

        self._client = httpx.Client(timeout=self.timeout)

        self._numeric_columns = expand_column_lists(self.numeric_columns)
        self._str_datetime_columns = expand_column_lists(self.str_datetime_columns)
        self._int_datetime_columns = expand_column_lists(self.int_datetime_columns)
        self._ms_int_datetime_columns = expand_column_lists(self.ms_int_datetime_columns)
        self._bool_columns = expand_column_lists(self.bool_columns)
        self._drop_columns = expand_column_lists(self.drop_columns)
        self._json_columns = expand_column_lists(self.json_columns)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ── Preprocessing helpers ───────────────────────────────────────────

    def preprocess_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        return _preprocess_dataframe(
            df,
            numeric_columns=self._numeric_columns,
            str_datetime_columns=self._str_datetime_columns,
            int_datetime_columns=self._int_datetime_columns,
            ms_int_datetime_columns=self._ms_int_datetime_columns,
            bool_columns=self._bool_columns,
            drop_columns=self._drop_columns,
            json_columns=self._json_columns,
        )

    def preprocess_dict(self, data: dict) -> dict:
        return _preprocess_dict(
            data,
            numeric_columns=self._numeric_columns,
            str_datetime_columns=self._str_datetime_columns,
            int_datetime_columns=self._int_datetime_columns,
            ms_int_datetime_columns=self._ms_int_datetime_columns,
            bool_columns=self._bool_columns,
            drop_columns=self._drop_columns,
            json_columns=self._json_columns,
        )

    # ── Auth headers ────────────────────────────────────────────────────

    def _auth_headers(self) -> dict:
        if self.pro_api_key:
            return {"x-cg-pro-api-key": self.pro_api_key}
        if self.api_key:
            return {"x-cg-demo-api-key": self.api_key}
        return {}

    # ── Request helper ──────────────────────────────────────────────────

    def _request(
        self,
        *,
        path: str,
        method: str = "GET",
        params: dict | None = None,
        data: dict | list | None = None,
    ) -> dict | list:
        url = self.base_url + path.lstrip("/")
        response = self._client.request(
            method,
            url,
            params=filter_params(params),
            json=data,
            headers=self._auth_headers(),
        )
        return self._handle_response(response)

    # ── Error handling ──────────────────────────────────────────────────

    def _handle_response(self, response: httpx.Response) -> dict | list:
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            url = str(exc.request.url)
            try:
                detail: object = exc.response.json()
            except Exception:
                detail = exc.response.text
            if status in (401, 403):
                raise CoinGeckoAuthError(status, url, detail) from exc
            if status == 429:
                raise CoinGeckoRateLimitError(status, url, detail) from exc
            raise CoinGeckoAPIError(status, url, detail) from exc
        return response.json()

    # ── Pagination ──────────────────────────────────────────────────────

    def _autopage(
        self,
        fetcher,
        /,
        *,
        max_pages: int | None = None,
        page_param: str = "page",
        per_page_param: str = "per_page",
        **kwargs,
    ) -> pd.DataFrame:
        """Auto-paginate any fetcher with ``page=`` / ``per_page=``."""
        sig = inspect.signature(fetcher)
        default_per_page = sig.parameters.get(per_page_param)
        per_page = (
            kwargs.get(per_page_param)
            or (default_per_page.default if default_per_page else 100)
            or 100
        )
        page = kwargs.get(page_param, 1) or 1
        data = []
        n = 0
        progress_bar = (
            tqdm(total=max_pages, desc=self.tqdm_description)
            if self.use_tqdm and max_pages
            else None
        )
        while max_pages is None or n < max_pages:
            n += 1
            call_kwargs = dict(kwargs)
            call_kwargs[page_param] = page
            call_kwargs[per_page_param] = per_page
            df = fetcher(**call_kwargs)
            if not isinstance(df, pd.DataFrame) or df.empty:
                break
            data.append(df)
            if len(df) < per_page:
                break
            page += 1
            if progress_bar:
                progress_bar.update(1)
        if progress_bar:
            progress_bar.close()
        return pd.concat(data, ignore_index=True) if data else pd.DataFrame()
