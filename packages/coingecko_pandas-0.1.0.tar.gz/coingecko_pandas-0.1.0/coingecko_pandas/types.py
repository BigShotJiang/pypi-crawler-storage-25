"""TypedDict models for dict-returning CoinGecko endpoints."""

from __future__ import annotations

from typing import TypedDict


class Ping(TypedDict, total=False):
    """Response from /ping."""

    geckoSays: str


class CoinDetail(TypedDict, total=False):
    """Response from /coins/{id} — large nested object."""

    id: str
    symbol: str
    name: str
    description: dict
    marketData: dict
    communityData: dict
    developerData: dict
    publicInterestStats: dict
    lastUpdated: object


class CoinHistory(TypedDict, total=False):
    """Response from /coins/{id}/history."""

    id: str
    symbol: str
    name: str
    marketData: dict
    communityData: dict
    developerData: dict
    publicInterestStats: dict


class ExchangeDetail(TypedDict, total=False):
    """Response from /exchanges/{id}."""

    name: str
    yearEstablished: int
    country: str
    description: str
    url: str
    trustScore: int
    tradeVolume24hBtc: float
    tickers: list


class DerivativeExchangeDetail(TypedDict, total=False):
    """Response from /derivatives/exchanges/{id}."""

    name: str
    openInterestBtc: float
    tradeVolume24hBtc: str
    numberOfPerpetualPairs: int
    numberOfFuturesPairs: int


class GlobalData(TypedDict, total=False):
    """Response from /global."""

    activeCryptocurrencies: int
    upcomingIcos: int
    ongoingIcos: int
    endedIcos: int
    markets: int
    totalMarketCap: dict
    totalVolume: dict
    marketCapPercentage: dict
    marketCapChangePercentage24hUsd: float
    updatedAt: int


class GlobalDeFi(TypedDict, total=False):
    """Response from /global/decentralized_finance_defi."""

    defiMarketCap: str
    ethMarketCap: str
    defiToEthRatio: str
    tradingVolume24h: str
    defiDominance: str
    topCoinName: str
    topCoinDefiDominance: float


class NFTDetail(TypedDict, total=False):
    """Response from /nfts/{id}."""

    id: str
    contractAddress: str
    assetPlatformId: str
    name: str
    symbol: str
    description: str
    nativeCurrency: str
    floorPrice: dict
    marketCap: dict
    volume24h: dict
    floorPriceInUsd24hPercentageChange: float


class TokenList(TypedDict, total=False):
    """Response from /token_lists/{asset_platform_id}/all.json."""

    name: str
    timestamp: str
    version: dict
    tokens: list


class SearchResult(TypedDict, total=False):
    """Response from /search."""

    coins: list
    exchanges: list
    icos: list
    categories: list
    nfts: list


class TrendingResult(TypedDict, total=False):
    """Response from /search/trending."""

    coins: list
    nfts: list
    categories: list


class TreasuryEntityDetail(TypedDict, total=False):
    """Response from /public_treasury/{entity_id}."""

    id: str
    name: str
    type: str
    holdings: list
