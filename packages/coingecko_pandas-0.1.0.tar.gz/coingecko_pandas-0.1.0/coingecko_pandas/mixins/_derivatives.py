"""Derivatives endpoints mixin."""

from __future__ import annotations

import pandas as pd


class DerivativesMixin:
    """Methods for the ``Derivatives`` resource group."""

    def derivatives_tickers(self) -> pd.DataFrame:
        """
        Derivatives Tickers List

        https://docs.coingecko.com/reference/derivatives-tickers
        """
        params: dict = {}
        data = self._request(path="derivatives", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def derivatives_exchanges(
        self, *, order: str | None = None, per_page: int | None = None, page: int | None = None
    ) -> pd.DataFrame:
        """
        Derivatives Exchanges List with Data

        https://docs.coingecko.com/reference/derivatives-exchanges

        Args:
            order: use this to sort the order of responses, default: open_interest_btc_desc (optional)
            per_page: total results per page (optional)
            page: page through results, default: 1 (optional)
        """
        params = {"order": order, "per_page": per_page, "page": page}
        data = self._request(path="derivatives/exchanges", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def derivatives_exchanges_id(self, id: str, *, include_tickers: str | None = None) -> dict:
        """
        Derivatives Exchange Data by ID

        https://docs.coingecko.com/reference/derivatives-exchanges-id

        Args:
            id: derivative exchange ID
            include_tickers: include tickers data (optional)
        """
        params = {"include_tickers": include_tickers}
        data = self._request(path=f"derivatives/exchanges/{id}", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def derivatives_exchanges_list(self) -> pd.DataFrame:
        """
        Derivatives Exchanges List (ID Map)

        https://docs.coingecko.com/reference/derivatives-exchanges-list
        """
        params: dict = {}
        data = self._request(path="derivatives/exchanges/list", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)
