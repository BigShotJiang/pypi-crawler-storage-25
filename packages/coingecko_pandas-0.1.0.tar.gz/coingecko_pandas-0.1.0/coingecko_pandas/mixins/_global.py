"""Global endpoints mixin."""

from __future__ import annotations


class GlobalMixin:
    """Methods for the ``Global`` resource group."""

    def crypto_global(self) -> dict:
        """
        Crypto Global Market Data

        https://docs.coingecko.com/reference/crypto-global
        """
        params: dict = {}
        data = self._request(path="global", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def global_defi(self) -> dict:
        """
        Global DeFi Market Data

        https://docs.coingecko.com/reference/global-defi
        """
        params: dict = {}
        data = self._request(path="global/decentralized_finance_defi", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data
