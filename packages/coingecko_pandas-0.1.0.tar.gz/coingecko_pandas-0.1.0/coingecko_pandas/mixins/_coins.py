"""Coins endpoints mixin."""

from __future__ import annotations

import pandas as pd


class CoinsMixin:
    """Methods for the ``Coins`` resource group."""

    def coins_list(self, *, include_platform: bool | None = None) -> pd.DataFrame:
        """
        Coins List (ID Map)

        https://docs.coingecko.com/reference/coins-list

        Args:
            include_platform: include platform and token's contract addresses, default: false (optional)
        """
        params = {"include_platform": include_platform}
        data = self._request(path="coins/list", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def coins_markets(
        self,
        vs_currency: str,
        *,
        ids: str | None = None,
        names: str | None = None,
        symbols: str | None = None,
        include_tokens: str | None = None,
        category: str | None = None,
        order: str | None = None,
        per_page: int | None = None,
        page: int | None = None,
        sparkline: bool | None = None,
        price_change_percentage: str | None = None,
        locale: str | None = None,
        precision: str | None = None,
        include_rehypothecated: bool | None = None,
    ) -> pd.DataFrame:
        """
        Coins List with Market Data

        https://docs.coingecko.com/reference/coins-markets

        Args:
            vs_currency: target currency of coins and market data
            ids: coins' IDs, comma-separated if querying more than 1 coin. (optional)
            names: coins' names, comma-separated if querying more than 1 coin. (optional)
            symbols: coins' symbols, comma-separated if querying more than 1 coin. (optional)
            include_tokens: for `symbols` lookups, specify `all` to include all matching tokens (optional)
            category: filter based on coins' category (optional)
            order: sort result by field, default: market_cap_desc (optional)
            per_page: total results per page, default: 100 (optional)
            page: page through results, default: 1 (optional)
            sparkline: include sparkline 7 days data, default: false (optional)
            price_change_percentage: include price change percentage timeframe, comma-separated if query more than 1 timeframe (optional)
            locale: language background, default: en (optional)
            precision: decimal place for currency price value (optional)
            include_rehypothecated: include rehypothecated tokens in results, default: false (optional)
        """
        params = {
            "vs_currency": vs_currency,
            "ids": ids,
            "names": names,
            "symbols": symbols,
            "include_tokens": include_tokens,
            "category": category,
            "order": order,
            "per_page": per_page,
            "page": page,
            "sparkline": sparkline,
            "price_change_percentage": price_change_percentage,
            "locale": locale,
            "precision": precision,
            "include_rehypothecated": include_rehypothecated,
        }
        data = self._request(path="coins/markets", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def coins_id(
        self,
        id: str,
        *,
        localization: bool | None = None,
        tickers: bool | None = None,
        market_data: bool | None = None,
        community_data: bool | None = None,
        developer_data: bool | None = None,
        sparkline: bool | None = None,
        include_categories_details: bool | None = None,
        dex_pair_format: str | None = None,
    ) -> dict:
        """
        Coin Data by ID

        https://docs.coingecko.com/reference/coins-id

        Args:
            id: coin ID
            localization: include all the localized languages in the response, default: true (optional)
            tickers: include tickers data, default: true (optional)
            market_data: include market data, default: true (optional)
            community_data: include community data, default: true (optional)
            developer_data: include developer data, default: true (optional)
            sparkline: include sparkline 7 days data, default: false (optional)
            include_categories_details: include categories details, default: false (optional)
            dex_pair_format: set to `symbol` to display DEX pair base and target as symbols, default: `contract_address` (optional)
        """
        params = {
            "localization": localization,
            "tickers": tickers,
            "market_data": market_data,
            "community_data": community_data,
            "developer_data": developer_data,
            "sparkline": sparkline,
            "include_categories_details": include_categories_details,
            "dex_pair_format": dex_pair_format,
        }
        data = self._request(path=f"coins/{id}", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def coins_id_tickers(
        self,
        id: str,
        *,
        exchange_ids: str | None = None,
        include_exchange_logo: bool | None = None,
        page: int | None = None,
        order: str | None = None,
        depth: bool | None = None,
        dex_pair_format: str | None = None,
    ) -> pd.DataFrame:
        """
        Coin Tickers by ID

        https://docs.coingecko.com/reference/coins-id-tickers

        Args:
            id: coin ID
            exchange_ids: exchange ID (optional)
            include_exchange_logo: include exchange logo, default: false (optional)
            page: page through results (optional)
            order: use this to sort the order of responses, default: trust_score_desc (optional)
            depth: include 2% orderbook depth, ie. `cost_to_move_up_usd` and `cost_to_move_down_usd` (optional)
            dex_pair_format: set to `symbol` to display DEX pair base and target as symbols, default: `contract_address` (optional)
        """
        params = {
            "exchange_ids": exchange_ids,
            "include_exchange_logo": include_exchange_logo,
            "page": page,
            "order": order,
            "depth": depth,
            "dex_pair_format": dex_pair_format,
        }
        data = self._request(path=f"coins/{id}/tickers", params=params)
        records = data.get("tickers", []) if isinstance(data, dict) else data
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def coins_id_history(self, id: str, date: str, *, localization: bool | None = None) -> dict:
        """
        Coin Historical Data by ID

        https://docs.coingecko.com/reference/coins-id-history

        Args:
            id: coin ID
            date: the date of data snapshot
            localization: include all the localized languages in response, default: true (optional)
        """
        params = {"date": date, "localization": localization}
        data = self._request(path=f"coins/{id}/history", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def coins_id_market_chart(
        self,
        id: str,
        vs_currency: str,
        days: str,
        *,
        interval: str | None = None,
        precision: str | None = None,
    ) -> pd.DataFrame:
        """
        Coin Historical Chart Data by ID

        https://docs.coingecko.com/reference/coins-id-market-chart

        Args:
            id: coin ID
            vs_currency: target currency of market data
            days: data up to number of days ago
            interval: data interval, leave empty for auto granularity (optional)
            precision: decimal place for currency price value (optional)
        """
        params = {
            "vs_currency": vs_currency,
            "days": days,
            "interval": interval,
            "precision": precision,
        }
        data = self._request(path=f"coins/{id}/market_chart", params=params)
        prices = data.get("prices", []) if isinstance(data, dict) else []
        market_caps = data.get("market_caps", []) if isinstance(data, dict) else []
        volumes = data.get("total_volumes", []) if isinstance(data, dict) else []
        df = pd.DataFrame(prices, columns=["timestamp", "price"])
        if market_caps:
            df["marketCap"] = [r[1] for r in market_caps]
        if volumes:
            df["volume"] = [r[1] for r in volumes]
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df

    def coins_id_market_chart_range(
        self, id: str, vs_currency: str, from_: int, to: int, *, precision: str | None = None
    ) -> pd.DataFrame:
        """
        Coin Historical Chart Data within Time Range by ID

        https://docs.coingecko.com/reference/coins-id-market-chart-range

        Args:
            id: coin ID
            vs_currency: target currency of market data
            from: starting date in UNIX timestamp
            to: ending date in UNIX timestamp
            precision: decimal place for currency price value (optional)
        """
        params = {"vs_currency": vs_currency, "from": from_, "to": to, "precision": precision}
        data = self._request(path=f"coins/{id}/market_chart/range", params=params)
        prices = data.get("prices", []) if isinstance(data, dict) else []
        market_caps = data.get("market_caps", []) if isinstance(data, dict) else []
        volumes = data.get("total_volumes", []) if isinstance(data, dict) else []
        df = pd.DataFrame(prices, columns=["timestamp", "price"])
        if market_caps:
            df["marketCap"] = [r[1] for r in market_caps]
        if volumes:
            df["volume"] = [r[1] for r in volumes]
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df

    def coins_id_ohlc(
        self, id: str, vs_currency: str, days: str, *, precision: str | None = None
    ) -> pd.DataFrame:
        """
        Coin OHLC Chart by ID

        https://docs.coingecko.com/reference/coins-id-ohlc

        Args:
            id: coin ID
            vs_currency: target currency of price data
            days: data up to number of days ago
            precision: decimal place for currency price value (optional)
        """
        params = {"vs_currency": vs_currency, "days": days, "precision": precision}
        data = self._request(path=f"coins/{id}/ohlc", params=params)
        df = pd.DataFrame(data, columns=["timestamp", "open", "high", "low", "close"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df
