"""Categories endpoints mixin."""

from __future__ import annotations

import pandas as pd


class CategoriesMixin:
    """Methods for the ``Categories`` resource group."""

    def coins_categories_list(self) -> pd.DataFrame:
        """
        Coins Categories List (ID Map)

        https://docs.coingecko.com/reference/coins-categories-list
        """
        params: dict = {}
        data = self._request(path="coins/categories/list", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def coins_categories(self, *, order: str | None = None) -> pd.DataFrame:
        """
        Coins Categories List with Market Data

        https://docs.coingecko.com/reference/coins-categories

        Args:
            order: sort results by field, default: market_cap_desc (optional)
        """
        params = {"order": order}
        data = self._request(path="coins/categories", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)
