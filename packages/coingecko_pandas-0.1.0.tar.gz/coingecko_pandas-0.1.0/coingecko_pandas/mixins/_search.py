"""Search endpoints mixin."""

from __future__ import annotations


class SearchMixin:
    """Methods for the ``Search`` resource group."""

    def search_data(self, query: str) -> dict:
        """
        Search Queries

        https://docs.coingecko.com/reference/search-data

        Args:
            query: search query
        """
        params = {"query": query}
        data = self._request(path="search", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data
