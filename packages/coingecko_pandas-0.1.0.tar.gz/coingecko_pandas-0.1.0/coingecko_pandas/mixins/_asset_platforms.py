"""Asset Platforms endpoints mixin."""

from __future__ import annotations

import pandas as pd


class AssetPlatformsMixin:
    """Methods for the ``Asset Platforms`` resource group."""

    def asset_platforms_list(self, *, filter: str | None = None) -> pd.DataFrame:
        """
        Asset Platforms List (ID Map)

        https://docs.coingecko.com/reference/asset-platforms-list

        Args:
            filter: apply relevant filters to results (optional)
        """
        params = {"filter": filter}
        data = self._request(path="asset_platforms", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def token_lists(self, asset_platform_id: str) -> dict:
        """
        Token Lists by Asset Platform ID

        https://docs.coingecko.com/reference/token-lists

        Args:
            asset_platform_id: asset platform ID
        """
        params: dict = {}
        data = self._request(path=f"token_lists/{asset_platform_id}/all.json", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data
