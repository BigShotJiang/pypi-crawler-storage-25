"""Mixin classes — one per OpenAPI tag."""

from coingecko_pandas.mixins._asset_platforms import AssetPlatformsMixin
from coingecko_pandas.mixins._categories import CategoriesMixin
from coingecko_pandas.mixins._coins import CoinsMixin
from coingecko_pandas.mixins._contract import ContractMixin
from coingecko_pandas.mixins._derivatives import DerivativesMixin
from coingecko_pandas.mixins._exchange_rates import ExchangeRatesMixin
from coingecko_pandas.mixins._exchanges import ExchangesMixin
from coingecko_pandas.mixins._global import GlobalMixin
from coingecko_pandas.mixins._nfts_beta import NFTsMixin
from coingecko_pandas.mixins._ping import PingMixin
from coingecko_pandas.mixins._public_treasury import PublicTreasuryMixin
from coingecko_pandas.mixins._search import SearchMixin
from coingecko_pandas.mixins._simple import SimpleMixin
from coingecko_pandas.mixins._trending import TrendingMixin

__all__ = [
    "AssetPlatformsMixin",
    "CategoriesMixin",
    "CoinsMixin",
    "ContractMixin",
    "DerivativesMixin",
    "ExchangeRatesMixin",
    "ExchangesMixin",
    "GlobalMixin",
    "NFTsMixin",
    "PingMixin",
    "PublicTreasuryMixin",
    "SearchMixin",
    "SimpleMixin",
    "TrendingMixin",
]
