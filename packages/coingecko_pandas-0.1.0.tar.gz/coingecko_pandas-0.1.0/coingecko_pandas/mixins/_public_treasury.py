"""Public Treasury endpoints mixin."""

from __future__ import annotations

import pandas as pd


class PublicTreasuryMixin:
    """Methods for the ``Public Treasury`` resource group."""

    def entities_list(
        self,
        *,
        entity_type: str | None = None,
        per_page: int | None = None,
        page: int | None = None,
    ) -> pd.DataFrame:
        """
        Entities List (ID Map)

        https://docs.coingecko.com/reference/entities-list

        Args:
            entity_type: filter by entity type, default: false (optional)
            per_page: total results per page, default: 100 (optional)
            page: page through results, default: 1 (optional)
        """
        params = {"entity_type": entity_type, "per_page": per_page, "page": page}
        data = self._request(path="entities/list", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def companies_public_treasury(
        self,
        entity: str,
        coin_id: str,
        *,
        per_page: int | None = None,
        page: int | None = None,
        order: str | None = None,
    ) -> dict:
        """
        Crypto Treasury Holdings by Coin ID

        https://docs.coingecko.com/reference/companies-public-treasury

        Args:
            entity: public company or government entity
            coin_id: coin ID. example: bitcoin, ethereum, solana, binancecoin
            per_page: Number of results to return per page (optional)
            page: Page number to return (optional)
            order: Sort order for results (optional)
        """
        params = {"per_page": per_page, "page": page, "order": order}
        data = self._request(path=f"{entity}/public_treasury/{coin_id}", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def public_treasury_entity(
        self,
        entity_id: str,
        *,
        holding_amount_change: str | None = None,
        holding_change_percentage: str | None = None,
    ) -> dict:
        """
        Crypto Treasury Holdings by Entity ID

        https://docs.coingecko.com/reference/public-treasury-entity

        Args:
            entity_id: public company or government entity ID
            holding_amount_change: include holding amount change for specified timeframes, comma-separated if querying more than 1 timeframe (optional)
            holding_change_percentage: include holding change percentage for specified timeframes, comma-separated if querying more than 1 timeframe (optional)
        """
        params = {
            "holding_amount_change": holding_amount_change,
            "holding_change_percentage": holding_change_percentage,
        }
        data = self._request(path=f"public_treasury/{entity_id}", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def public_treasury_entity_chart(
        self,
        entity_id: str,
        coin_id: str,
        days: str,
        *,
        include_empty_intervals: bool | None = None,
    ) -> pd.DataFrame:
        """
        Crypto Treasury Holdings Historical Chart Data by ID

        https://docs.coingecko.com/reference/public-treasury-entity-chart

        Args:
            entity_id: public company or government entity ID
            coin_id: coin ID. example: bitcoin, ethereum, solana, binancecoin
            days: data up to number of days ago
            include_empty_intervals: include empty intervals with no transaction data, default: false (optional)
        """
        params = {"days": days, "include_empty_intervals": include_empty_intervals}
        data = self._request(
            path=f"public_treasury/{entity_id}/{coin_id}/holding_chart", params=params
        )
        df = pd.DataFrame(data, columns=["timestamp", "value"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df

    def public_treasury_transaction_history(
        self,
        entity_id: str,
        *,
        per_page: float | None = None,
        page: float | None = None,
        order: str | None = None,
        coin_ids: str | None = None,
    ) -> pd.DataFrame:
        """
        Crypto Treasury Transaction History by Entity ID

        https://docs.coingecko.com/reference/public-treasury-transaction-history

        Args:
            entity_id: public company or government entity ID
            per_page: total results per page, default: `100` (optional)
            page: page through results, default: `1` (optional)
            order: use this to sort the order of transactions, default: `date_desc` (optional)
            coin_ids: filter transactions by coin IDs, comma-separated if querying more than 1 coin (optional)
        """
        params = {"per_page": per_page, "page": page, "order": order, "coin_ids": coin_ids}
        data = self._request(path=f"public_treasury/{entity_id}/transaction_history", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)
