"""Trending endpoints mixin."""

from __future__ import annotations


class TrendingMixin:
    """Methods for the ``Trending`` resource group."""

    def trending_search(self) -> dict:
        """
        Trending Search List

        https://docs.coingecko.com/reference/trending-search
        """
        params: dict = {}
        data = self._request(path="search/trending", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data
