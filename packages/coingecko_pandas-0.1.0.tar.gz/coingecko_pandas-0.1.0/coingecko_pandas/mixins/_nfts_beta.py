"""NFTs (Beta) endpoints mixin."""

from __future__ import annotations

import pandas as pd


class NFTsMixin:
    """Methods for the ``NFTs (Beta)`` resource group."""

    def nfts_list(
        self, *, order: str | None = None, per_page: int | None = None, page: int | None = None
    ) -> pd.DataFrame:
        """
        NFTs List (ID Map)

        https://docs.coingecko.com/reference/nfts-list

        Args:
            order: use this to sort the order of responses (optional)
            per_page: total results per page (optional)
            page: page through results (optional)
        """
        params = {"order": order, "per_page": per_page, "page": page}
        data = self._request(path="nfts/list", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def nfts_id(self, id: str) -> dict:
        """
        NFTs Collection Data by ID

        https://docs.coingecko.com/reference/nfts-id

        Args:
            id: NFTs ID
        """
        params: dict = {}
        data = self._request(path=f"nfts/{id}", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def nfts_contract_address(self, asset_platform_id: str, contract_address: str) -> dict:
        """
        NFTs Collection Data by Contract Address

        https://docs.coingecko.com/reference/nfts-contract-address

        Args:
            asset_platform_id: asset platform ID
            contract_address: the contract address of token
        """
        params: dict = {}
        data = self._request(
            path=f"nfts/{asset_platform_id}/contract/{contract_address}", params=params
        )
        return self.preprocess_dict(data) if isinstance(data, dict) else data
