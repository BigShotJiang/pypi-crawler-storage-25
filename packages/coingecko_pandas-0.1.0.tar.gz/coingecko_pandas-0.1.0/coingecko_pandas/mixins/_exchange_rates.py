"""Exchange Rates endpoints mixin."""

from __future__ import annotations

import pandas as pd


class ExchangeRatesMixin:
    """Methods for the ``Exchange Rates`` resource group."""

    def exchange_rates(self) -> pd.DataFrame:
        """
        BTC-to-Currency Exchange Rates

        https://docs.coingecko.com/reference/exchange-rates
        """
        params: dict = {}
        data = self._request(path="exchange_rates", params=params)
        rates = data.get("rates", {}) if isinstance(data, dict) else {}
        df = (
            pd.DataFrame.from_dict(rates, orient="index")
            .reset_index()
            .rename(columns={"index": "currency"})
        )
        return self.preprocess_dataframe(df)
