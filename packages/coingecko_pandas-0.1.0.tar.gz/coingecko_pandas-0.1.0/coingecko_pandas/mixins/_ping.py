"""Ping endpoints mixin."""

from __future__ import annotations


class PingMixin:
    """Methods for the ``Ping`` resource group."""

    def ping_server(self) -> dict:
        """
        Check API server status

        https://docs.coingecko.com/reference/ping-server
        """
        params: dict = {}
        data = self._request(path="ping", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data
