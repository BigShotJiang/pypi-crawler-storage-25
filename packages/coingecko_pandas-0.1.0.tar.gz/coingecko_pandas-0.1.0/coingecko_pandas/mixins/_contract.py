"""Contract endpoints mixin."""

from __future__ import annotations

import pandas as pd


class ContractMixin:
    """Methods for the ``Contract`` resource group."""

    def coins_contract_address(self, id: str, contract_address: str) -> dict:
        """
        Coin Data by Token Address

        https://docs.coingecko.com/reference/coins-contract-address

        Args:
            id: asset platform ID
            contract_address: the contract address of token
        """
        params: dict = {}
        data = self._request(path=f"coins/{id}/contract/{contract_address}", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def contract_address_market_chart(
        self,
        id: str,
        contract_address: str,
        vs_currency: str,
        days: str,
        *,
        interval: str | None = None,
        precision: str | None = None,
    ) -> pd.DataFrame:
        """
        Coin Historical Chart Data by Token Address

        https://docs.coingecko.com/reference/contract-address-market-chart

        Args:
            id: asset platform ID
            contract_address: the contract address of token
            vs_currency: target currency of market data
            days: data up to number of days ago
            interval: data interval, leave empty for auto granularity (optional)
            precision: decimal place for currency price value (optional)
        """
        params = {
            "vs_currency": vs_currency,
            "days": days,
            "interval": interval,
            "precision": precision,
        }
        data = self._request(
            path=f"coins/{id}/contract/{contract_address}/market_chart", params=params
        )
        prices = data.get("prices", []) if isinstance(data, dict) else []
        market_caps = data.get("market_caps", []) if isinstance(data, dict) else []
        volumes = data.get("total_volumes", []) if isinstance(data, dict) else []
        df = pd.DataFrame(prices, columns=["timestamp", "price"])
        if market_caps:
            df["marketCap"] = [r[1] for r in market_caps]
        if volumes:
            df["volume"] = [r[1] for r in volumes]
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df

    def contract_address_market_chart_range(
        self,
        id: str,
        contract_address: str,
        vs_currency: str,
        from_: int,
        to: int,
        *,
        precision: str | None = None,
    ) -> pd.DataFrame:
        """
        Coin Historical Chart Data within Time Range by Token Address

        https://docs.coingecko.com/reference/contract-address-market-chart-range

        Args:
            id: asset platform ID
            contract_address: the contract address of token
            vs_currency: target currency of market data
            from: starting date in UNIX timestamp
            to: ending date in UNIX timestamp
            precision: decimal place for currency price value (optional)
        """
        params = {"vs_currency": vs_currency, "from": from_, "to": to, "precision": precision}
        data = self._request(
            path=f"coins/{id}/contract/{contract_address}/market_chart/range", params=params
        )
        prices = data.get("prices", []) if isinstance(data, dict) else []
        market_caps = data.get("market_caps", []) if isinstance(data, dict) else []
        volumes = data.get("total_volumes", []) if isinstance(data, dict) else []
        df = pd.DataFrame(prices, columns=["timestamp", "price"])
        if market_caps:
            df["marketCap"] = [r[1] for r in market_caps]
        if volumes:
            df["volume"] = [r[1] for r in volumes]
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df
