"""Exchanges endpoints mixin."""

from __future__ import annotations

import pandas as pd


class ExchangesMixin:
    """Methods for the ``Exchanges`` resource group."""

    def exchanges(self, *, per_page: int | None = None, page: int | None = None) -> pd.DataFrame:
        """
        Exchanges List with Data

        https://docs.coingecko.com/reference/exchanges

        Args:
            per_page: total results per page, default: 100 (optional)
            page: page through results, default: 1 (optional)
        """
        params = {"per_page": per_page, "page": page}
        data = self._request(path="exchanges", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def exchanges_list(self, *, status: str | None = None) -> pd.DataFrame:
        """
        Exchanges List (ID Map)

        https://docs.coingecko.com/reference/exchanges-list

        Args:
            status: filter by status of exchanges, default: active (optional)
        """
        params = {"status": status}
        data = self._request(path="exchanges/list", params=params)
        records = data if isinstance(data, list) else [data]
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def exchanges_id(self, id: str, *, dex_pair_format: str | None = None) -> dict:
        """
        Exchange Data by ID

        https://docs.coingecko.com/reference/exchanges-id

        Args:
            id: exchange ID
            dex_pair_format: set to `symbol` to display DEX pair base and target as symbols, default: `contract_address` (optional)
        """
        params = {"dex_pair_format": dex_pair_format}
        data = self._request(path=f"exchanges/{id}", params=params)
        return self.preprocess_dict(data) if isinstance(data, dict) else data

    def exchanges_id_tickers(
        self,
        id: str,
        *,
        coin_ids: str | None = None,
        include_exchange_logo: bool | None = None,
        page: int | None = None,
        depth: bool | None = None,
        order: str | None = None,
        dex_pair_format: str | None = None,
    ) -> pd.DataFrame:
        """
        Exchange Tickers by ID

        https://docs.coingecko.com/reference/exchanges-id-tickers

        Args:
            id: exchange ID
            coin_ids: filter tickers by coin IDs, comma-separated if querying more than 1 coin (optional)
            include_exchange_logo: include exchange logo, default: false (optional)
            page: page through results (optional)
            depth: include 2% orderbook depth (Example: cost_to_move_up_usd & cost_to_move_down_usd),default: false (optional)
            order: use this to sort the order of responses, default: trust_score_desc (optional)
            dex_pair_format: set to `symbol` to display DEX pair base and target as symbols, default: `contract_address` (optional)
        """
        params = {
            "coin_ids": coin_ids,
            "include_exchange_logo": include_exchange_logo,
            "page": page,
            "depth": depth,
            "order": order,
            "dex_pair_format": dex_pair_format,
        }
        data = self._request(path=f"exchanges/{id}/tickers", params=params)
        records = data.get("tickers", []) if isinstance(data, dict) else data
        df = pd.DataFrame(records)
        return self.preprocess_dataframe(df)

    def exchanges_id_volume_chart(self, id: str, days: str) -> pd.DataFrame:
        """
        Exchange Volume Chart by ID

        https://docs.coingecko.com/reference/exchanges-id-volume-chart

        Args:
            id: exchange ID or derivatives exchange ID
            days: data up to number of days ago
        """
        params = {"days": days}
        data = self._request(path=f"exchanges/{id}/volume_chart", params=params)
        df = pd.DataFrame(data, columns=["timestamp", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df
