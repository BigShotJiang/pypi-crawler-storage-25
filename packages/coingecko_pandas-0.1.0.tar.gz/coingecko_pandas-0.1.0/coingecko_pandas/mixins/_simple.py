"""Simple endpoints mixin."""

from __future__ import annotations

import pandas as pd


class SimpleMixin:
    """Methods for the ``Simple`` resource group."""

    def simple_price(
        self,
        vs_currencies: str,
        *,
        ids: str | None = None,
        names: str | None = None,
        symbols: str | None = None,
        include_tokens: str | None = None,
        include_market_cap: bool | None = None,
        include_24hr_vol: bool | None = None,
        include_24hr_change: bool | None = None,
        include_last_updated_at: bool | None = None,
        precision: str | None = None,
    ) -> pd.DataFrame:
        """
        Coin Price by IDs, Symbols, or Names

        https://docs.coingecko.com/reference/simple-price

        Args:
            vs_currencies: target currency of coins, comma-separated if querying more than 1 currency.
            ids: coins' IDs, comma-separated if querying more than 1 coin. (optional)
            names: coins' names, comma-separated if querying more than 1 coin. (optional)
            symbols: coins' symbols, comma-separated if querying more than 1 coin. (optional)
            include_tokens: for `symbols` lookups, specify `all` to include all matching tokens (optional)
            include_market_cap: include market capitalization, default: false (optional)
            include_24hr_vol: include 24hr volume, default: false (optional)
            include_24hr_change: include 24hr change percentage, default: false (optional)
            include_last_updated_at: include last updated price time in UNIX, default: false (optional)
            precision: decimal place for currency price value (optional)
        """
        params = {
            "vs_currencies": vs_currencies,
            "ids": ids,
            "names": names,
            "symbols": symbols,
            "include_tokens": include_tokens,
            "include_market_cap": include_market_cap,
            "include_24hr_vol": include_24hr_vol,
            "include_24hr_change": include_24hr_change,
            "include_last_updated_at": include_last_updated_at,
            "precision": precision,
        }
        data = self._request(path="simple/price", params=params)
        df = (
            pd.DataFrame.from_dict(data, orient="index")
            .reset_index()
            .rename(columns={"index": "id"})
        )
        return self.preprocess_dataframe(df)

    def simple_token_price(
        self,
        id: str,
        contract_addresses: str,
        vs_currencies: str,
        *,
        include_market_cap: bool | None = None,
        include_24hr_vol: bool | None = None,
        include_24hr_change: bool | None = None,
        include_last_updated_at: bool | None = None,
        precision: str | None = None,
    ) -> pd.DataFrame:
        """
        Coin Price by Token Addresses

        https://docs.coingecko.com/reference/simple-token-price

        Args:
            id: asset platform's ID
            contract_addresses: the contract address of a token
            vs_currencies: target currency of coins, comma-separated if querying more than 1 currency.
            include_market_cap: include market capitalization, default: false (optional)
            include_24hr_vol: include 24hr volume, default: false (optional)
            include_24hr_change: include 24hr change (optional)
            include_last_updated_at: include last updated price time in UNIX , default: false (optional)
            precision: decimal place for currency price value (optional)
        """
        params = {
            "contract_addresses": contract_addresses,
            "vs_currencies": vs_currencies,
            "include_market_cap": include_market_cap,
            "include_24hr_vol": include_24hr_vol,
            "include_24hr_change": include_24hr_change,
            "include_last_updated_at": include_last_updated_at,
            "precision": precision,
        }
        data = self._request(path=f"simple/token_price/{id}", params=params)
        df = (
            pd.DataFrame.from_dict(data, orient="index")
            .reset_index()
            .rename(columns={"index": "id"})
        )
        return self.preprocess_dataframe(df)

    def simple_supported_currencies(self) -> pd.DataFrame:
        """
        Supported Currencies List

        https://docs.coingecko.com/reference/simple-supported-currencies
        """
        params: dict = {}
        data = self._request(path="simple/supported_vs_currencies", params=params)
        df = pd.DataFrame({"currency": data}) if isinstance(data, list) else pd.DataFrame(data)
        return self.preprocess_dataframe(df)
