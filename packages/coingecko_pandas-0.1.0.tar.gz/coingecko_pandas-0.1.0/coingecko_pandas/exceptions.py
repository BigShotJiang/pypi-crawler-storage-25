"""CoinGecko-specific exception hierarchy."""

from __future__ import annotations


class CoinGeckoError(Exception):
    """Base exception for all coingecko-pandas errors."""


class CoinGeckoAPIError(CoinGeckoError):
    """Raised when the CoinGecko API returns a non-2xx response."""

    def __init__(self, status_code: int, url: str, detail: object) -> None:
        self.status_code = status_code
        self.url = url
        self.detail = detail
        super().__init__(f"HTTP {status_code} from {url}: {detail}")


class CoinGeckoAuthError(CoinGeckoAPIError):
    """Raised on 401/403 responses, or when required credentials are missing."""

    def __init__(
        self,
        status_code: int = 0,
        url: str = "",
        detail: object = "",
    ) -> None:
        super().__init__(status_code, url, detail)


class CoinGeckoRateLimitError(CoinGeckoAPIError):
    """Raised on 429 Too Many Requests."""
