"""Async wrapper for CoinGeckoPandas.

Wraps the synchronous client via composition, running each method in a
ThreadPoolExecutor for non-blocking behavior in asyncio contexts.
"""

from __future__ import annotations

import asyncio
import functools
from concurrent.futures import ThreadPoolExecutor
from typing import Self

from coingecko_pandas.client import CoinGeckoPandas

_SKIP = frozenset({"close", "preprocess_dataframe", "preprocess_dict"})


def _make_async_wrapper(method_name: str):
    async def wrapper(self, *args, **kwargs):
        loop = asyncio.get_running_loop()
        fn = getattr(self._sync, method_name)
        return await loop.run_in_executor(self._executor, functools.partial(fn, *args, **kwargs))

    wrapper.__name__ = method_name
    wrapper.__qualname__ = f"AsyncCoinGeckoPandas.{method_name}"
    sync_method = getattr(CoinGeckoPandas, method_name, None)
    if sync_method is not None:
        annotations = getattr(sync_method, "__annotations__", {})
        if "return" in annotations:
            wrapper.__annotations__ = {"return": annotations["return"]}
    return wrapper


class AsyncCoinGeckoPandas:
    """Async version of :class:`~coingecko_pandas.CoinGeckoPandas`."""

    def __init__(self, *, max_workers: int = 10, **kwargs):
        self._sync = CoinGeckoPandas(**kwargs)
        self._executor = ThreadPoolExecutor(max_workers=max_workers)

    @property
    def base_url(self) -> str:
        return self._sync.base_url

    @property
    def api_key(self) -> str | None:
        return self._sync.api_key

    @property
    def pro_api_key(self) -> str | None:
        return self._sync.pro_api_key

    async def close(self) -> None:
        self._sync.close()
        self._executor.shutdown(wait=False)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    def __repr__(self) -> str:
        return f"Async{self._sync!r}"


def _populate_async_methods() -> None:
    for name in dir(CoinGeckoPandas):
        if name.startswith("_") or name in _SKIP:
            continue
        attr = getattr(CoinGeckoPandas, name, None)
        # callable() not inspect.isfunction so cachedmethod descriptors are caught
        if not callable(attr):
            continue
        if hasattr(AsyncCoinGeckoPandas, name):
            continue
        wrapper = _make_async_wrapper(name)
        wrapper.__doc__ = getattr(attr, "__doc__", None)
        setattr(AsyncCoinGeckoPandas, name, wrapper)


_populate_async_methods()
