"""Live integration tests. Skipped unless ``PYTEST_LIVE=1``.

Run with::

    PYTEST_LIVE=1 uv run pytest tests/test_integration.py -v
"""

import os

import pandas as pd
import pytest

from coingecko_pandas import CoinGeckoPandas

pytestmark = pytest.mark.skipif(
    not os.getenv("PYTEST_LIVE"),
    reason="Live tests disabled. Set PYTEST_LIVE=1 to enable.",
)


@pytest.fixture(scope="module")
def live_client() -> CoinGeckoPandas:
    return CoinGeckoPandas(use_tqdm=False)


def test_ping_live(live_client):
    result = live_client.ping_server()
    assert isinstance(result, dict)


def test_coins_list_live(live_client):
    df = live_client.coins_list()
    assert isinstance(df, pd.DataFrame)
    assert len(df) > 1000  # CoinGecko tracks thousands of coins
    assert {"id", "symbol", "name"}.issubset(df.columns)


def test_coins_markets_live(live_client):
    df = live_client.coins_markets("usd", per_page=10, page=1)
    assert isinstance(df, pd.DataFrame)
    assert len(df) <= 10
    assert "currentPrice" in df.columns


def test_simple_price_live(live_client):
    df = live_client.simple_price("usd", ids="bitcoin,ethereum")
    assert isinstance(df, pd.DataFrame)
    assert set(df["id"]) >= {"bitcoin", "ethereum"}


def test_global_live(live_client):
    result = live_client.crypto_global()
    assert isinstance(result, dict)


def test_simple_supported_currencies_live(live_client):
    df = live_client.simple_supported_currencies()
    assert isinstance(df, pd.DataFrame)
    assert len(df) > 10
