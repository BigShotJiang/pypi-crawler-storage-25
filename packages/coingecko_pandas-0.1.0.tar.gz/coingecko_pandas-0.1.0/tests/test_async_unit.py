"""Async unit tests via pytest-asyncio."""

import pandas as pd
import pytest
from pytest_httpx import HTTPXMock

from coingecko_pandas import AsyncCoinGeckoPandas, CoinGeckoPandas

pytestmark = pytest.mark.asyncio

BASE = "https://api.coingecko.com/api/v3/"


async def test_async_client_constructible():
    async with AsyncCoinGeckoPandas() as client:
        assert client.base_url.startswith("https://api.coingecko.com")


async def test_async_methods_match_sync():
    """Every public method on the sync client is reachable on the async one."""
    sync_methods = {
        m
        for m in dir(CoinGeckoPandas)
        if not m.startswith("_") and callable(getattr(CoinGeckoPandas, m, None))
    }
    async_methods = {
        m
        for m in dir(AsyncCoinGeckoPandas)
        if not m.startswith("_") and callable(getattr(AsyncCoinGeckoPandas, m, None))
    }
    skip = {"close", "preprocess_dataframe", "preprocess_dict"}
    missing = sync_methods - async_methods - skip
    assert not missing, f"Missing async wrappers: {missing}"


async def test_async_ping(httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE}ping", json={"gecko_says": "hello"})
    async with AsyncCoinGeckoPandas() as client:
        result = await client.ping_server()
        assert result["geckoSays"] == "hello"


async def test_async_coins_list(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}coins/list",
        json=[{"id": "bitcoin", "symbol": "btc", "name": "Bitcoin"}],
    )
    async with AsyncCoinGeckoPandas() as client:
        df = await client.coins_list()
        assert isinstance(df, pd.DataFrame)
        assert df.iloc[0]["id"] == "bitcoin"
