"""Unit tests — no live API calls, all HTTP interactions mocked via pytest-httpx."""

import pandas as pd
import pytest
from pytest_httpx import HTTPXMock

from coingecko_pandas import (
    CoinGeckoAPIError,
    CoinGeckoAuthError,
    CoinGeckoPandas,
    CoinGeckoRateLimitError,
)
from coingecko_pandas.utils import filter_params, snake_to_camel

BASE = "https://api.coingecko.com/api/v3/"


# ── Utility tests ────────────────────────────────────────────────────


def test_snake_to_camel_basic():
    assert snake_to_camel("market_cap") == "marketCap"
    assert snake_to_camel("alreadyCamel") == "alreadyCamel"


def test_filter_params_removes_none():
    assert filter_params({"a": 1, "b": None}) == {"a": 1}


def test_filter_params_removes_empty_lists():
    assert filter_params({"a": [], "b": [1]}) == {"b": [1]}


def test_filter_params_keeps_zero_and_false():
    # 0 and False are not "null"
    result = filter_params({"x": 0, "y": False, "z": None})
    assert result == {"x": 0, "y": False}


# ── Client construction ──────────────────────────────────────────────


def test_client_default_base_url():
    c = CoinGeckoPandas(use_tqdm=False)
    assert c.base_url == BASE


def test_pro_key_switches_base_url():
    c = CoinGeckoPandas(use_tqdm=False, pro_api_key="some-pro-key")
    assert "pro-api.coingecko.com" in c.base_url


def test_demo_auth_header(authed_client):
    headers = authed_client._auth_headers()
    assert headers == {"x-cg-demo-api-key": "test-demo-api-key"}


def test_pro_auth_header(pro_client):
    headers = pro_client._auth_headers()
    assert headers == {"x-cg-pro-api-key": "test-pro-api-key"}


# ── Error handling ───────────────────────────────────────────────────


def test_auth_error_on_401(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(status_code=401, json={"error": "unauthorized"})
    with pytest.raises(CoinGeckoAuthError):
        client._request(path="ping")


def test_rate_limit_error_on_429(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(status_code=429, json={"error": "rate limited"})
    with pytest.raises(CoinGeckoRateLimitError):
        client._request(path="ping")


def test_api_error_on_500(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(status_code=500, json={"error": "boom"})
    with pytest.raises(CoinGeckoAPIError):
        client._request(path="ping")


# ── Representative endpoint tests ────────────────────────────────────


def test_ping_returns_dict(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE}ping", json={"gecko_says": "(V3) To the Moon!"})
    result = client.ping_server()
    assert isinstance(result, dict)
    assert "geckoSays" in result


def test_coins_list_returns_dataframe(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}coins/list",
        json=[
            {"id": "bitcoin", "symbol": "btc", "name": "Bitcoin"},
            {"id": "ethereum", "symbol": "eth", "name": "Ethereum"},
        ],
    )
    df = client.coins_list()
    assert isinstance(df, pd.DataFrame)
    assert {"id", "symbol", "name"}.issubset(df.columns)
    assert len(df) == 2


def test_coins_markets_returns_dataframe(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}coins/markets?vs_currency=usd",
        json=[
            {
                "id": "bitcoin",
                "symbol": "btc",
                "name": "Bitcoin",
                "current_price": 50000.0,
                "market_cap": 950_000_000_000,
                "total_volume": 30_000_000_000,
            }
        ],
    )
    df = client.coins_markets("usd")
    assert isinstance(df, pd.DataFrame)
    assert "currentPrice" in df.columns  # snake → camel after preprocess


def test_simple_price_returns_dataframe(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}simple/price?vs_currencies=usd",
        json={"bitcoin": {"usd": 50000.0}, "ethereum": {"usd": 3000.0}},
    )
    df = client.simple_price("usd")
    assert isinstance(df, pd.DataFrame)
    assert "id" in df.columns
    assert "usd" in df.columns
    assert set(df["id"]) == {"bitcoin", "ethereum"}


def test_coins_id_ohlc_returns_ohlc_dataframe(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}coins/bitcoin/ohlc?vs_currency=usd&days=1",
        json=[
            [1700000000000, 50000, 51000, 49000, 50500],
            [1700003600000, 50500, 52000, 50000, 51500],
        ],
    )
    df = client.coins_id_ohlc("bitcoin", vs_currency="usd", days="1")
    assert isinstance(df, pd.DataFrame)
    assert list(df.columns) == ["timestamp", "open", "high", "low", "close"]
    assert pd.api.types.is_datetime64_any_dtype(df["timestamp"])


def test_coins_id_market_chart_returns_dataframe(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}coins/bitcoin/market_chart?vs_currency=usd&days=1",
        json={
            "prices": [[1700000000000, 50000.0], [1700003600000, 50500.0]],
            "market_caps": [[1700000000000, 950e9], [1700003600000, 960e9]],
            "total_volumes": [[1700000000000, 30e9], [1700003600000, 31e9]],
        },
    )
    df = client.coins_id_market_chart("bitcoin", vs_currency="usd", days="1")
    assert isinstance(df, pd.DataFrame)
    assert {"timestamp", "price", "marketCap", "volume"}.issubset(df.columns)


def test_simple_supported_currencies_returns_dataframe(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}simple/supported_vs_currencies",
        json=["btc", "eth", "usd", "eur"],
    )
    df = client.simple_supported_currencies()
    assert isinstance(df, pd.DataFrame)
    assert "currency" in df.columns
    assert len(df) == 4


def test_exchange_rates_returns_dataframe(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}exchange_rates",
        json={
            "rates": {
                "usd": {"name": "US Dollar", "unit": "$", "value": 50000, "type": "fiat"},
                "btc": {"name": "Bitcoin", "unit": "BTC", "value": 1.0, "type": "crypto"},
            }
        },
    )
    df = client.exchange_rates()
    assert isinstance(df, pd.DataFrame)
    assert "currency" in df.columns
    assert set(df["currency"]) == {"usd", "btc"}


def test_global_returns_dict(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}global",
        json={
            "data": {
                "active_cryptocurrencies": 12000,
                "markets": 800,
                "market_cap_percentage": {"btc": 50.0, "eth": 18.0},
            }
        },
    )
    result = client.crypto_global()
    assert isinstance(result, dict)


def test_search_returns_dict(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE}search?query=bitcoin",
        json={
            "coins": [{"id": "bitcoin", "name": "Bitcoin", "symbol": "btc"}],
            "exchanges": [],
            "categories": [],
            "nfts": [],
        },
    )
    result = client.search_data("bitcoin")
    assert isinstance(result, dict)
    assert "coins" in result
