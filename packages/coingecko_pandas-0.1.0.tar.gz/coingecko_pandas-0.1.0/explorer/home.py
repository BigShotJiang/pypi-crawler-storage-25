"""coingecko-pandas explorer — home page."""

import streamlit as st

from coingecko_pandas import CoinGeckoPandas

st.set_page_config(page_title="coingecko-pandas explorer", layout="wide")

st.title("coingecko-pandas explorer")
st.caption("Interactive playground for the CoinGecko API")

with st.sidebar:
    st.header("Client config")
    api_key = st.text_input("Demo API key", value="", type="password")
    pro_key = st.text_input("Pro API key", value="", type="password")

if "client" not in st.session_state:
    st.session_state.client = CoinGeckoPandas(
        api_key=api_key or None,
        pro_api_key=pro_key or None,
        use_tqdm=False,
    )

st.markdown(
    """
    Pick an endpoint from the sidebar pages on the left.

    Each page shows the raw DataFrame, a Plotly visualization, and the Python
    snippet that would reproduce the call.
    """
)
