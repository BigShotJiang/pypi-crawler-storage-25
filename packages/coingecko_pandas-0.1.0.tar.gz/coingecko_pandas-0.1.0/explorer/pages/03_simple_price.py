"""Simple price lookup."""

import streamlit as st

st.title("Simple price")

client = st.session_state.client
ids = st.text_input("Coin IDs (comma-separated)", "bitcoin,ethereum,solana")
vs = st.text_input("vs_currencies", "usd,eur")

with st.spinner("Fetching..."):
    df = client.simple_price(vs, ids=ids)

st.dataframe(df, use_container_width=True)

with st.expander("Code"):
    st.code(
        f"""
from coingecko_pandas import CoinGeckoPandas

with CoinGeckoPandas() as client:
    df = client.simple_price("{vs}", ids="{ids}")
""".strip(),
        language="python",
    )
