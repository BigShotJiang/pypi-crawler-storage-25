"""OHLC candles for a coin."""

import plotly.graph_objects as go
import streamlit as st

st.title("OHLC")

client = st.session_state.client
coin_id = st.text_input("Coin ID", "bitcoin")
days = st.selectbox("Days", ["1", "7", "14", "30", "90", "180", "365"], index=2)

with st.spinner("Fetching..."):
    df = client.coins_id_ohlc(coin_id, vs_currency="usd", days=days)

st.subheader("DataFrame")
st.dataframe(df, use_container_width=True)

st.subheader("Candles")
fig = go.Figure(
    data=[
        go.Candlestick(
            x=df["timestamp"],
            open=df["open"],
            high=df["high"],
            low=df["low"],
            close=df["close"],
        )
    ]
)
st.plotly_chart(fig, use_container_width=True)

with st.expander("Code"):
    st.code(
        f"""
from coingecko_pandas import CoinGeckoPandas

with CoinGeckoPandas() as client:
    df = client.coins_id_ohlc("{coin_id}", vs_currency="usd", days="{days}")
""".strip(),
        language="python",
    )
