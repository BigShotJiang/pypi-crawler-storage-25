"""Top coins by market cap."""

import plotly.express as px
import streamlit as st

st.title("Markets")

client = st.session_state.client
n = st.slider("Number of coins", 5, 250, 25)

with st.spinner("Fetching..."):
    df = client.coins_markets("usd", per_page=n, page=1)

st.subheader("DataFrame")
st.dataframe(df, use_container_width=True)

st.subheader("Market cap")
fig = px.bar(df, x="symbol", y="marketCap", title="Market cap by symbol")
st.plotly_chart(fig, use_container_width=True)

with st.expander("Code"):
    st.code(
        f"""
from coingecko_pandas import CoinGeckoPandas

with CoinGeckoPandas() as client:
    df = client.coins_markets("usd", per_page={n}, page=1)
""".strip(),
        language="python",
    )
