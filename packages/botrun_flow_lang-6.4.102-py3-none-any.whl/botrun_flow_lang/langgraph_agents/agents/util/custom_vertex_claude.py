"""
Custom Vertex AI Claude chat model for LangGraph.

Lightweight BaseChatModel that calls Claude via Vertex AI's rawPredict REST API,
avoiding the heavy google-cloud-aiplatform dependency (~26s import time).

Supports tool calling for LangGraph react agent compatibility.
"""

import json
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

import httpx

from google.auth.transport.requests import Request
from google.oauth2 import service_account
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from pydantic import ConfigDict

from botrun_flow_lang.utils.botrun_logger import get_default_botrun_logger

logger = get_default_botrun_logger()


class ChatVertexAIClaude(BaseChatModel):
    """
    Lightweight Vertex AI Claude chat model using rawPredict REST API.

    Replaces ChatAnthropicVertex without importing google-cloud-aiplatform.
    Supports tool calling for LangGraph react agent.

    Usage:
        model = ChatVertexAIClaude(
            model="claude-sonnet-4-5-20250929",
            project_id="my-project",
            location="asia-east1",
            credentials=my_credentials,  # or service_account_file="path/to/sa.json"
        )
    """

    model: str = "claude-sonnet-4-5-20250929"
    max_tokens: int = 64000
    temperature: float = 0
    project_id: str = ""
    location: str = "asia-east1"
    credentials: Any = None
    service_account_file: str = ""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @property
    def _llm_type(self) -> str:
        return "vertex-ai-claude-custom"

    @property
    def _identifying_params(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "project_id": self.project_id,
            "location": self.location,
        }

    def bind_tools(
        self,
        tools: List[Any],
        *,
        tool_choice: Optional[Union[str, Dict]] = None,
        **kwargs,
    ):
        """Convert tools to Anthropic format and bind via Runnable.bind()."""
        formatted_tools = _convert_tools_to_anthropic(tools)
        bind_kwargs: Dict[str, Any] = {"tools": formatted_tools, **kwargs}
        if tool_choice is not None:
            bind_kwargs["tool_choice"] = tool_choice
        return self.bind(**bind_kwargs)

    def _get_access_token(self) -> str:
        """Get OAuth2 access token for Vertex AI API."""
        if self.credentials:
            creds = self.credentials
        elif self.service_account_file:
            creds = service_account.Credentials.from_service_account_file(
                self.service_account_file,
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
        else:
            raise ValueError(
                "ChatVertexAIClaude requires either 'credentials' or 'service_account_file'"
            )

        if not creds.valid or creds.expired:
            creds.refresh(Request())
        return creds.token

    def _convert_messages(
        self, messages: List[BaseMessage]
    ) -> Tuple[Union[str, List[Dict]], List[Dict]]:
        """Convert LangChain messages to Anthropic API format.

        Returns:
            (system, api_messages) tuple.
            system: str or list of content blocks (preserves cache_control).
            api_messages: list of Anthropic-format message dicts.
        """
        system_blocks: List[Any] = []
        raw_messages: List[Dict] = []

        for msg in messages:
            if isinstance(msg, SystemMessage):
                if isinstance(msg.content, str):
                    system_blocks.append({"type": "text", "text": msg.content})
                elif isinstance(msg.content, list):
                    for block in msg.content:
                        if isinstance(block, dict):
                            system_blocks.append(block)
                        elif isinstance(block, str):
                            system_blocks.append({"type": "text", "text": block})

            elif isinstance(msg, HumanMessage):
                raw_messages.append({"role": "user", "content": msg.content})

            elif isinstance(msg, AIMessage):
                content_blocks = []
                if msg.content:
                    if isinstance(msg.content, str):
                        content_blocks.append(
                            {"type": "text", "text": msg.content}
                        )
                    elif isinstance(msg.content, list):
                        for block in msg.content:
                            if isinstance(block, str):
                                content_blocks.append(
                                    {"type": "text", "text": block}
                                )
                            elif isinstance(block, dict):
                                content_blocks.append(block)
                for tc in msg.tool_calls or []:
                    content_blocks.append(
                        {
                            "type": "tool_use",
                            "id": tc["id"],
                            "name": tc["name"],
                            "input": tc["args"],
                        }
                    )
                raw_messages.append(
                    {
                        "role": "assistant",
                        "content": content_blocks if content_blocks else "",
                    }
                )

            elif isinstance(msg, ToolMessage):
                tool_content = msg.content
                if not isinstance(tool_content, str):
                    tool_content = json.dumps(tool_content, ensure_ascii=False)
                raw_messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": msg.tool_call_id,
                                "content": tool_content,
                            }
                        ],
                    }
                )

        merged = _merge_consecutive_messages(raw_messages)

        # Return system as string (simple) or list (structured with cache_control)
        has_cache_control = any(
            isinstance(b, dict) and "cache_control" in b for b in system_blocks
        )
        if len(system_blocks) == 1 and not has_cache_control:
            system: Union[str, List[Dict]] = system_blocks[0].get("text", "")
        elif system_blocks:
            system = system_blocks
        else:
            system = ""

        return system, merged

    def _build_payload(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> Tuple[str, Dict[str, Any], int]:
        """Build API payload shared by _generate and _stream.

        Returns:
            (access_token, payload, tools_count)
        """
        system, api_messages = self._convert_messages(messages)
        access_token = self._get_access_token()

        payload: Dict[str, Any] = {
            "anthropic_version": "vertex-2023-10-16",
            "messages": api_messages,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
        }
        if system:
            payload["system"] = system
        if stop:
            payload["stop_sequences"] = stop

        tools = kwargs.get("tools", [])
        if tools:
            payload["tools"] = tools

        tool_choice = kwargs.get("tool_choice")
        if tool_choice:
            if isinstance(tool_choice, str):
                if tool_choice == "auto":
                    payload["tool_choice"] = {"type": "auto"}
                elif tool_choice == "any":
                    payload["tool_choice"] = {"type": "any"}
                elif tool_choice == "none":
                    payload.pop("tools", None)
                else:
                    payload["tool_choice"] = {
                        "type": "tool",
                        "name": tool_choice,
                    }
            elif isinstance(tool_choice, dict):
                payload["tool_choice"] = tool_choice

        return access_token, payload, len(tools)

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs,
    ) -> ChatResult:
        """Call Vertex AI Claude via rawPredict (non-streaming)."""
        access_token, payload, tools_count = self._build_payload(
            messages, stop, **kwargs
        )

        url = (
            f"https://{self.location}-aiplatform.googleapis.com/v1/"
            f"projects/{self.project_id}/locations/{self.location}/"
            f"publishers/anthropic/models/{self.model}:rawPredict"
        )

        logger.info(
            f"[ChatVertexAIClaude] rawPredict: model={self.model}, "
            f"location={self.location}, messages={len(payload['messages'])}, "
            f"tools={tools_count}"
        )

        data = _http_post_json(url, payload, access_token)

        # Parse response
        text_parts = []
        tool_calls = []
        for block in data.get("content", []):
            block_type = block.get("type", "")
            if block_type == "text":
                text_parts.append(block.get("text", ""))
            elif block_type == "tool_use":
                tool_calls.append(
                    {
                        "id": block["id"],
                        "name": block["name"],
                        "args": block.get("input", {}),
                    }
                )

        usage = data.get("usage", {})
        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)

        ai_message = AIMessage(
            content="".join(text_parts),
            tool_calls=tool_calls,
            usage_metadata={
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
            },
            response_metadata={
                "model": self.model,
                "stop_reason": data.get("stop_reason", ""),
            },
        )

        logger.info(
            f"[ChatVertexAIClaude] Response: "
            f"text_len={len(ai_message.content)}, "
            f"tool_calls={len(tool_calls)}, "
            f"tokens=({input_tokens}+{output_tokens}={input_tokens + output_tokens})"
        )

        return ChatResult(
            generations=[ChatGeneration(message=ai_message)],
            llm_output={
                "model": self.model,
                "usage": {
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                },
            },
        )

    def _stream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs,
    ) -> Iterator[ChatGenerationChunk]:
        """Call Vertex AI Claude via streamRawPredict (streaming).

        Yields ChatGenerationChunk with AIMessageChunk for each SSE event.
        Handles both text and tool_use content blocks.
        """
        access_token, payload, tools_count = self._build_payload(
            messages, stop, **kwargs
        )
        payload["stream"] = True

        url = (
            f"https://{self.location}-aiplatform.googleapis.com/v1/"
            f"projects/{self.project_id}/locations/{self.location}/"
            f"publishers/anthropic/models/{self.model}:streamRawPredict"
        )

        logger.info(
            f"[ChatVertexAIClaude] streamRawPredict: model={self.model}, "
            f"location={self.location}, messages={len(payload['messages'])}, "
            f"tools={tools_count}"
        )

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}",
        }

        # Track state across SSE events
        usage_metadata: Dict[str, int] = {}
        # Map block index -> tool info for tool_use streaming
        tool_use_blocks: Dict[int, Dict[str, Any]] = {}

        try:
            with httpx.Client(timeout=300.0) as client:
                with client.stream(
                    "POST", url, headers=headers, json=payload
                ) as response:
                    if response.status_code != 200:
                        error_body = response.read().decode("utf-8", errors="ignore")
                        error_msg = f"Vertex AI API error: {response.status_code} - {error_body}"
                        logger.error(f"[ChatVertexAIClaude] {error_msg}")
                        raise Exception(error_msg)

                    for line in response.iter_lines():
                        if isinstance(line, bytes):
                            line = line.decode("utf-8")
                        line = line.strip()

                        if not line or line.startswith("event:"):
                            continue

                        if line.startswith("data:"):
                            data_str = line[5:].strip()
                        else:
                            data_str = line

                        try:
                            data = json.loads(data_str)
                        except json.JSONDecodeError:
                            continue

                        if not data:
                            continue

                        event_type = data.get("type", "")

                        if event_type == "message_start":
                            msg = data.get("message", {})
                            if "usage" in msg:
                                usage_metadata["input_tokens"] = msg["usage"].get(
                                    "input_tokens", 0
                                )

                        elif event_type == "content_block_start":
                            block = data.get("content_block", {})
                            index = data.get("index", 0)
                            if block.get("type") == "tool_use":
                                # Start of a tool_use block
                                tool_use_blocks[index] = {
                                    "id": block.get("id", ""),
                                    "name": block.get("name", ""),
                                    "args_json": "",
                                }
                                chunk = AIMessageChunk(
                                    content="",
                                    tool_call_chunks=[
                                        {
                                            "name": block.get("name", ""),
                                            "args": "",
                                            "id": block.get("id", ""),
                                            "index": index,
                                        }
                                    ],
                                )
                                yield ChatGenerationChunk(message=chunk)
                                if run_manager:
                                    run_manager.on_llm_new_token(
                                        "", chunk=chunk
                                    )

                        elif event_type == "content_block_delta":
                            delta = data.get("delta", {})
                            index = data.get("index", 0)
                            delta_type = delta.get("type", "")

                            if delta_type == "text_delta":
                                text = delta.get("text", "")
                                if text:
                                    chunk = AIMessageChunk(content=text)
                                    yield ChatGenerationChunk(message=chunk)
                                    if run_manager:
                                        run_manager.on_llm_new_token(
                                            text, chunk=chunk
                                        )

                            elif delta_type == "input_json_delta":
                                partial_json = delta.get("partial_json", "")
                                if index in tool_use_blocks:
                                    tool_use_blocks[index][
                                        "args_json"
                                    ] += partial_json
                                chunk = AIMessageChunk(
                                    content="",
                                    tool_call_chunks=[
                                        {
                                            "name": None,
                                            "args": partial_json,
                                            "id": None,
                                            "index": index,
                                        }
                                    ],
                                )
                                yield ChatGenerationChunk(message=chunk)
                                if run_manager:
                                    run_manager.on_llm_new_token(
                                        "", chunk=chunk
                                    )

                        elif event_type == "message_delta":
                            delta = data.get("delta", {})
                            if "usage" in data:
                                usage_metadata["output_tokens"] = data[
                                    "usage"
                                ].get("output_tokens", 0)

                        elif event_type == "message_stop":
                            # Yield final chunk with usage metadata
                            input_tokens = usage_metadata.get("input_tokens", 0)
                            output_tokens = usage_metadata.get(
                                "output_tokens", 0
                            )
                            chunk = AIMessageChunk(
                                content="",
                                usage_metadata={
                                    "input_tokens": input_tokens,
                                    "output_tokens": output_tokens,
                                    "total_tokens": input_tokens
                                    + output_tokens,
                                },
                                response_metadata={
                                    "model": self.model,
                                },
                            )
                            yield ChatGenerationChunk(message=chunk)

                            logger.info(
                                f"[ChatVertexAIClaude] Stream complete: "
                                f"tokens=({input_tokens}+{output_tokens}"
                                f"={input_tokens + output_tokens})"
                            )

        except httpx.HTTPStatusError as e:
            error_body = e.response.text if e.response else ""
            error_msg = (
                f"Vertex AI API error: {e.response.status_code} - {error_body}"
            )
            logger.error(f"[ChatVertexAIClaude] {error_msg}")
            raise Exception(error_msg) from e


def _http_post_json(
    url: str, payload: Dict[str, Any], access_token: str
) -> Dict[str, Any]:
    """POST JSON to URL with Bearer auth. Returns parsed JSON response."""
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}",
    }
    try:
        with httpx.Client(timeout=300.0) as client:
            response = client.post(url, headers=headers, json=payload)
            if response.status_code != 200:
                error_msg = (
                    f"Vertex AI API error: {response.status_code} - {response.text}"
                )
                logger.error(f"[ChatVertexAIClaude] {error_msg}")
                raise Exception(error_msg)
            return response.json()
    except httpx.HTTPStatusError as e:
        error_body = e.response.text if e.response else ""
        error_msg = f"Vertex AI API error: {e.response.status_code} - {error_body}"
        logger.error(f"[ChatVertexAIClaude] {error_msg}")
        raise Exception(error_msg) from e


def _convert_tools_to_anthropic(tools: List[Any]) -> List[Dict]:
    """Convert LangChain tools to Anthropic tool format."""
    from langchain_core.utils.function_calling import convert_to_openai_tool

    anthropic_tools = []
    for tool in tools:
        if isinstance(tool, dict):
            if "input_schema" in tool:
                anthropic_tools.append(tool)
            elif "function" in tool:
                func = tool["function"]
                anthropic_tools.append(
                    {
                        "name": func["name"],
                        "description": func.get("description", ""),
                        "input_schema": func.get(
                            "parameters",
                            {"type": "object", "properties": {}},
                        ),
                    }
                )
            else:
                anthropic_tools.append(tool)
        else:
            try:
                oai_tool = convert_to_openai_tool(tool)
                func = oai_tool["function"]
                anthropic_tools.append(
                    {
                        "name": func["name"],
                        "description": func.get("description", ""),
                        "input_schema": func.get(
                            "parameters",
                            {"type": "object", "properties": {}},
                        ),
                    }
                )
            except Exception as e:
                logger.warning(
                    f"[ChatVertexAIClaude] Failed to convert tool "
                    f"{getattr(tool, 'name', tool)}: {e}"
                )

    return anthropic_tools


def _merge_consecutive_messages(messages: List[Dict]) -> List[Dict]:
    """Merge consecutive messages with the same role (required by Anthropic API)."""
    if not messages:
        return []

    merged: List[Dict] = []
    for msg in messages:
        if merged and merged[-1]["role"] == msg["role"]:
            prev_content = merged[-1]["content"]
            curr_content = msg["content"]

            # Normalize to list of content blocks
            if isinstance(prev_content, str):
                prev_content = [{"type": "text", "text": prev_content}]
            elif not isinstance(prev_content, list):
                prev_content = [prev_content]

            if isinstance(curr_content, str):
                curr_content = [{"type": "text", "text": curr_content}]
            elif not isinstance(curr_content, list):
                curr_content = [curr_content]

            merged[-1]["content"] = prev_content + curr_content
        else:
            merged.append(msg)

    return merged
