"""Extract documentation from the MLD Frontend SDK via bun subprocess."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any


def extract_frontend_sdk(platform_root: Path) -> dict[str, Any]:
    """Run the TypeScript extraction script and return parsed JSON.

    Falls back to a stub manifest on any failure so Python docs still work.
    """
    script = platform_root / "packages" / "sdk-frontend" / "scripts" / "extract-docs.ts"
    frontend_dir = platform_root / "packages" / "sdk-frontend"

    if not script.exists():
        print(
            f"Warning: frontend extraction script not found at {script}",
            file=sys.stderr,
        )
        return _stub_manifest()

    pm_cmd = _detect_pm(frontend_dir)

    try:
        result = subprocess.run(
            [pm_cmd, "run", str(script)],
            cwd=str(frontend_dir),
            capture_output=True,
            text=True,
            timeout=30,
        )
    except FileNotFoundError:
        print(
            f"Warning: '{pm_cmd}' not found. Install bun or npm to extract frontend docs.",
            file=sys.stderr,
        )
        return _stub_manifest()
    except subprocess.TimeoutExpired:
        print("Warning: frontend extraction timed out.", file=sys.stderr)
        return _stub_manifest()

    if result.returncode != 0:
        print(
            f"Warning: frontend extraction failed:\n{result.stderr[:500]}",
            file=sys.stderr,
        )
        return _stub_manifest()

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        print(f"Warning: invalid JSON from extraction script: {e}", file=sys.stderr)
        return _stub_manifest()

    return data


def _detect_pm(frontend_dir: Path) -> str:
    """Detect bun or npm from lock files."""
    if (frontend_dir / "bun.lockb").exists() or (frontend_dir / "bun.lock").exists():
        return "bun"
    if (frontend_dir / "package-lock.json").exists():
        return "npx"
    # Default to bun
    return "bun"


def _stub_manifest() -> dict[str, Any]:
    """Return an empty frontend manifest."""
    return {
        "sdk": "frontend",
        "version": "",
        "categories": {},
    }
