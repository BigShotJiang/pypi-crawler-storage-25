"""Handler for the ``mld docs`` CLI command."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from mld_sdk.docs.cache import (
    clear_cache,
    find_platform_root,
    get_cache_dir,
    is_cache_fresh,
    read_cache,
    write_cache,
)
from mld_sdk.docs.formatter import (
    format_category,
    format_component_group,
    format_components_grouped,
    format_composables,
    format_css_overview,
    format_css_section,
    format_item_detail,
    format_sdk_overview,
    format_search_results,
    format_toc,
)

_BUNDLED_DIR = Path(__file__).parent / "docs" / "bundled"


def cmd_docs(
    *,
    path_args: list[str] | None = None,
    json_output: bool = False,
    no_cache: bool = False,
    clear_cache: bool = False,
) -> None:
    """Execute the ``mld docs`` command."""
    path_args = path_args or []
    as_json: bool = json_output
    do_clear: bool = clear_cache

    # Locate platform root (optional — bundled docs used as fallback)
    try:
        root: Path | None = find_platform_root()
    except FileNotFoundError:
        root = None

    cache_dir = get_cache_dir(root) if root else None

    # Handle --clear-cache
    if do_clear:
        if cache_dir:
            clear_cache(cache_dir)
            print("Cache cleared.")
        else:
            print("No cache to clear (not inside MLD platform tree).")
        return

    # Load manifests (with caching when in-tree, bundled fallback otherwise)
    python_data = _load_sdk(cache_dir, "python", root, no_cache=no_cache)
    frontend_data = _load_sdk(cache_dir, "frontend", root, no_cache=no_cache)

    # Route based on path_args
    if not path_args:
        print(format_toc(python_data, frontend_data, as_json=as_json))
        return

    first = path_args[0]

    # Search
    if first == "search":
        query = " ".join(path_args[1:])
        if not query:
            print("Usage: mld docs search <query>", file=sys.stderr)
            sys.exit(1)
        from mld_sdk.docs.search import search

        results = search(query, python_data, frontend_data)
        print(format_search_results(results, query, as_json=as_json))
        return

    # Python SDK
    if first == "python":
        _route_python(python_data, path_args[1:], as_json=as_json)
        return

    # Frontend SDK
    if first == "frontend":
        _route_frontend(frontend_data, path_args[1:], as_json=as_json)
        return

    # Try as a direct item name across both SDKs
    item = _find_item_by_name(first, python_data, frontend_data)
    if item:
        print(format_item_detail(item, as_json=as_json))
        return

    print(f"Unknown argument: {first}", file=sys.stderr)
    print("Usage: mld docs [python|frontend] [category] [item]", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# SDK routing
# ---------------------------------------------------------------------------


def _route_python(data: dict[str, Any] | None, rest: list[str], *, as_json: bool) -> None:
    if data is None:
        print("Python SDK data not available.", file=sys.stderr)
        sys.exit(1)

    categories = data.get("categories", {})

    if not rest:
        print(format_sdk_overview(data, "python", as_json=as_json))
        return

    target = rest[0]

    # Check if target is a category name
    if target in categories:
        print(format_category(categories[target], target, as_json=as_json))
        return

    # Check if target is an item name within any category
    for _cat_name, items in categories.items():
        for item in items:
            if item.get("name") == target:
                print(format_item_detail(item, as_json=as_json))
                return

    print(f"Not found: {target}", file=sys.stderr)
    print(
        f"Available categories: {', '.join(categories.keys())}",
        file=sys.stderr,
    )
    sys.exit(1)


def _route_frontend(data: dict[str, Any] | None, rest: list[str], *, as_json: bool) -> None:
    if data is None:
        print("Frontend SDK data not available.", file=sys.stderr)
        sys.exit(1)

    categories = data.get("categories", {})

    if not rest:
        print(format_sdk_overview(data, "frontend", as_json=as_json))
        return

    target = rest[0]

    # Category-level routing
    if target == "components":
        if len(rest) > 1:
            print(format_component_group(data, rest[1], as_json=as_json))
        else:
            print(format_components_grouped(data, as_json=as_json))
        return

    if target == "composables":
        print(format_composables(data, as_json=as_json))
        return

    if target == "css":
        if len(rest) > 1:
            print(format_css_section(data, rest[1], as_json=as_json))
        else:
            print(format_css_overview(data, as_json=as_json))
        return

    if target in categories:
        items = categories[target]
        if isinstance(items, list):
            print(format_category(items, target, as_json=as_json))
        return

    # Item name lookup (component or composable)
    item = _find_in_manifest(target, data)
    if item:
        print(format_item_detail(item, as_json=as_json))
        return

    print(f"Not found: {target}", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------


def _load_sdk(
    cache_dir: Path | None,
    sdk: str,
    platform_root: Path | None,
    *,
    no_cache: bool = False,
) -> dict[str, Any] | None:
    """Load an SDK manifest, using cache when available.

    When *platform_root* is ``None`` (running outside the monorepo),
    Python docs use runtime introspection and frontend docs fall back
    to the bundled manifest shipped with the package.
    """
    if cache_dir and platform_root and not no_cache and is_cache_fresh(cache_dir, sdk, platform_root):
        cached = read_cache(cache_dir, sdk)
        if cached is not None:
            return cached

    if sdk == "python":
        from mld_sdk.docs.python_extractor import extract_python_sdk

        data = extract_python_sdk()
    elif sdk == "frontend":
        if platform_root:
            from mld_sdk.docs.frontend_extractor import extract_frontend_sdk

            data = extract_frontend_sdk(platform_root)
        else:
            data = _load_bundled("frontend")
    else:
        return None

    if cache_dir and platform_root:
        write_cache(cache_dir, sdk, data, platform_root)
    return data


def _load_bundled(sdk: str) -> dict[str, Any]:
    """Load a pre-extracted manifest bundled with the package."""
    bundled_file = _BUNDLED_DIR / f"{sdk}.json"
    if bundled_file.exists():
        return json.loads(bundled_file.read_text())
    return {"sdk": sdk, "version": "", "categories": {}}


# ---------------------------------------------------------------------------
# Item lookup
# ---------------------------------------------------------------------------


def _find_item_by_name(
    name: str,
    python_data: dict[str, Any] | None,
    frontend_data: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Search for an item by name across both SDKs."""
    for data in (python_data, frontend_data):
        if data is None:
            continue
        item = _find_in_manifest(name, data)
        if item:
            return item
    return None


def _find_in_manifest(name: str, data: dict[str, Any]) -> dict[str, Any] | None:
    """Search all categories in a manifest for an item by name."""
    for _cat_name, cat_data in data.get("categories", {}).items():
        if isinstance(cat_data, list):
            for item in cat_data:
                if item.get("name") == name:
                    return item
    return None
