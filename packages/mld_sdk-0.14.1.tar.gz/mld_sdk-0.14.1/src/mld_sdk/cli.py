"""CLI entry point for the MLD SDK.

Provides commands for plugin development: build, init, dev, info, link, unlink.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Optional

import typer

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib  # type: ignore[no-redef]

from mld_sdk.cli_commands.auth_cmd import auth_app
from mld_sdk.cli_commands.experiment_cmd import experiment_app
from mld_sdk.cli_commands.project_cmd import project_app

# ---------------------------------------------------------------------------
# App and sub-apps
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="mld",
    help="MLD plugin development CLI",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

dev_app = typer.Typer(
    name="dev",
    help="Run plugin in development mode with hot reload",
)

sdk_app = typer.Typer(
    name="sdk",
    help="Manage mld-sdk dependencies and linking",
)

# ---------------------------------------------------------------------------
# Register sub-apps — Platform first, then Develop
# ---------------------------------------------------------------------------

# Platform
app.add_typer(auth_app, name="auth", rich_help_panel="Platform")
app.add_typer(experiment_app, name="experiment", rich_help_panel="Platform")
app.add_typer(project_app, name="project", rich_help_panel="Platform")

# Develop
app.add_typer(dev_app, name="dev", rich_help_panel="Develop")
app.add_typer(sdk_app, name="sdk", rich_help_panel="Develop")


# ---------------------------------------------------------------------------
# Version callback
# ---------------------------------------------------------------------------


def _version_callback(value: bool) -> None:
    if value:
        try:
            from mld_sdk._version import __version__
        except ImportError:
            __version__ = "dev"
        print(f"mld {__version__}")
        raise typer.Exit()


@app.callback()
def _app_callback(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-V",
            help="Show version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """MLD plugin development CLI."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _read_pyproject(project_dir: Path) -> dict:
    """Read and return the [project] table from pyproject.toml."""
    path = project_dir / "pyproject.toml"
    if not path.exists():
        print(f"Error: {path} not found.", file=sys.stderr)
        sys.exit(1)
    with open(path, "rb") as f:
        data = tomllib.load(f)
    if "project" not in data:
        print("Error: pyproject.toml has no [project] table.", file=sys.stderr)
        sys.exit(1)
    return data["project"]


def _detect_package_manager(frontend_dir: Path) -> tuple[str, str]:
    """Detect the JavaScript package manager for a frontend directory.

    Returns a (name, command) tuple, e.g. ("bun", "bun") or ("npm", "npm").
    Exits if the required tool is not on PATH.
    """
    has_bun_lockfile = any((frontend_dir / f).exists() for f in ("bun.lockb", "bun.lock"))
    if has_bun_lockfile:
        if not shutil.which("bun"):
            print("Error: bun lockfile found but 'bun' is not on PATH.", file=sys.stderr)
            sys.exit(1)
        return ("bun", "bun")

    if (frontend_dir / "package-lock.json").exists():
        if not shutil.which("npm"):
            print(
                "Error: package-lock.json found but 'npm' is not on PATH.",
                file=sys.stderr,
            )
            sys.exit(1)
        return ("npm", "npm")

    # No lockfile — prefer bun, fallback to npm
    if shutil.which("bun"):
        return ("bun", "bun")
    if shutil.which("npm"):
        return ("npm", "npm")

    print(
        "Error: No JavaScript package manager found. Install bun or npm.",
        file=sys.stderr,
    )
    sys.exit(1)


def _build_frontend(project_dir: Path) -> bool:
    """Build the plugin frontend if present. Returns True if a frontend was built."""
    frontend_dir = project_dir / "frontend"
    if not (frontend_dir / "package.json").exists():
        return False

    pm_name, pm_cmd = _detect_package_manager(frontend_dir)
    print(f"Building frontend with {pm_name}...")

    for step, cmd in [("install", [pm_cmd, "install"]), ("run build", [pm_cmd, "run", "build"])]:
        result = subprocess.run(cmd, cwd=frontend_dir, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Error: {pm_name} {step} failed:\n{result.stderr}", file=sys.stderr)
            sys.exit(1)

    # Verify dist exists and is non-empty
    dist_dir = frontend_dir / "dist"
    if not dist_dir.exists() or not any(dist_dir.iterdir()):
        print(
            "Error: frontend build produced no output in frontend/dist/.",
            file=sys.stderr,
        )
        sys.exit(1)

    print("Frontend build complete.")
    return True


def _check_force_include(project_dir: Path) -> None:
    """Warn if pyproject.toml lacks a force-include entry for frontend/dist."""
    path = project_dir / "pyproject.toml"
    if not path.exists():
        return
    with open(path, "rb") as f:
        data = tomllib.load(f)
    wheel_config = data.get("tool", {}).get("hatch", {}).get("build", {}).get("targets", {}).get("wheel", {})
    force_include = wheel_config.get("force-include", {})
    has_frontend_entry = any("frontend/dist" in k for k in force_include)
    if not has_frontend_entry:
        print(
            "Warning: pyproject.toml has no [tool.hatch.build.targets.wheel.force-include] "
            "entry for frontend/dist. The frontend build output may not be included in the wheel.",
            file=sys.stderr,
        )


def _build_wheel(project_dir: Path, output_dir: Path) -> Path:
    """Build a wheel using ``uv build`` and return its path.

    If a wheel already exists in the output directory, it is reused.
    """
    result = subprocess.run(
        ["uv", "build", "--wheel", "--out-dir", str(output_dir)],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Error: uv build failed:\n{result.stderr}", file=sys.stderr)
        sys.exit(1)

    whls = list(output_dir.glob("*.whl"))
    if not whls:
        print("Error: uv build produced no .whl file.", file=sys.stderr)
        sys.exit(1)
    return whls[0]


def _download_deps(project_dir: Path, dest: Path) -> list[Path]:
    """Download binary dependency wheels into *dest*."""
    # Export requirements from pyproject.toml, then download wheels
    req_file = dest / "_requirements.txt"
    export_result = subprocess.run(
        ["uv", "export", "--no-dev", "--no-hashes", "-o", str(req_file)],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if export_result.returncode != 0:
        print(
            f"Warning: requirements export failed (non-fatal):\n{export_result.stderr}",
            file=sys.stderr,
        )
        return []

    result = subprocess.run(
        [
            "uv",
            "pip",
            "download",
            "--only-binary",
            ":all:",
            "--dest",
            str(dest),
            "--requirement",
            str(req_file),
        ],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    req_file.unlink(missing_ok=True)
    if result.returncode != 0:
        print(
            f"Warning: dependency download failed (non-fatal):\n{result.stderr}",
            file=sys.stderr,
        )
        return []
    return list(dest.glob("*.whl"))


def _build_manifest(
    project: dict,
    main_whl_name: str,
    dep_whl_names: list[str],
    *,
    has_frontend: bool = False,
) -> dict:
    """Build the manifest.json content."""
    return {
        "format_version": 1,
        "plugin": {
            "name": project["name"],
            "version": project["version"],
            "description": project.get("description", ""),
            "requires_mld": project.get("requires_mld", ">=0.1.0"),
            "has_frontend": has_frontend,
        },
        "wheels": {
            "main": main_whl_name,
            "dependencies": dep_whl_names,
        },
    }


def _version_from_wheel(whl_path: Path, name: str) -> str:
    """Extract version from a wheel filename (name-version-...)."""
    # Wheel filenames use underscores: my_pkg-1.2.3-py3-none-any.whl
    normalized = name.replace("-", "_").lower()
    stem = whl_path.stem  # strip .whl
    prefix = f"{normalized}-"
    if stem.startswith(prefix):
        # Everything between name- and the next - after version
        rest = stem[len(prefix) :]
        # Version ends at the first segment that looks like a tag (py3, cp312, etc.)
        parts = rest.split("-")
        return parts[0]
    # Fallback: split on second hyphen
    parts = stem.split("-")
    return parts[1] if len(parts) >= 2 else "0.0.0"


# ---------------------------------------------------------------------------
# Top-level commands — Platform panel
# ---------------------------------------------------------------------------


@app.command(rich_help_panel="Platform")
def status() -> None:
    """Show platform health and connection info."""
    from mld_sdk.cli_commands.status_cmd import cmd_status

    cmd_status()


# ---------------------------------------------------------------------------
# Top-level commands — Develop panel
# ---------------------------------------------------------------------------


@app.command(rich_help_panel="Develop")
def init(
    directory: Annotated[str, typer.Argument(help="Target directory")] = ".",
    name: Annotated[Optional[str], typer.Option("--name", "-n", help="Plugin name (human-readable)")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="One-line description")] = None,
    plugin_type: Annotated[
        Optional[str], typer.Option("--type", "-t", help="Plugin type (analysis or experiment-design)")
    ] = None,
    no_frontend: Annotated[bool, typer.Option("--no-frontend", help="Skip frontend scaffolding")] = False,
    no_install: Annotated[bool, typer.Option("--no-install", help="Skip uv sync and bun install")] = False,
    no_git: Annotated[bool, typer.Option("--no-git", help="Skip git init")] = False,
    force: Annotated[bool, typer.Option("--force", help="Allow non-empty directory")] = False,
    ai_assistant: Annotated[
        Optional[str],
        typer.Option("--ai-assistant", help="AI assistants, comma-separated (claude,codex,cursor,windsurf,none)"),
    ] = None,
) -> None:
    """Scaffold a new plugin project."""
    from mld_sdk.init_command import cmd_init

    cmd_init(
        directory=directory,
        name=name,
        description=description,
        plugin_type=plugin_type,
        no_frontend=no_frontend,
        no_install=no_install,
        no_git=no_git,
        force=force,
        ai_assistant=ai_assistant,
    )


@app.command(rich_help_panel="Develop")
def build(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    vendor_deps: Annotated[
        bool, typer.Option("--vendor-deps", help="Include dependency wheels in the .mld bundle")
    ] = False,
    no_frontend: Annotated[
        bool, typer.Option("--no-frontend", help="Skip frontend build even if frontend/package.json exists")
    ] = False,
    output_dir: Annotated[str, typer.Option("--output-dir", help="Output directory")] = "dist",
) -> None:
    """Package a plugin into a .mld bundle."""
    project_dir = Path(path).resolve()
    out_dir = Path(output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    project = _read_pyproject(project_dir)
    name = project["name"]

    # Build frontend (before wheel so Hatch force-include picks up dist/)
    has_frontend = not no_frontend and _build_frontend(project_dir)
    if has_frontend:
        _check_force_include(project_dir)

    # Build the wheel
    with tempfile.TemporaryDirectory() as build_tmp:
        build_path = Path(build_tmp)
        main_whl = _build_wheel(project_dir, build_path)

        # Resolve version: static from pyproject.toml or dynamic from wheel
        version = project.get("version") or _version_from_wheel(main_whl, name)
        project["version"] = version

        # Optionally vendor dependencies
        dep_whls: list[Path] = []
        if vendor_deps:
            dep_dir = build_path / "deps"
            dep_dir.mkdir()
            dep_whls = _download_deps(project_dir, dep_dir)
            # Exclude the main wheel if it ended up in deps
            dep_whls = [w for w in dep_whls if w.name != main_whl.name]

        # Build manifest
        manifest = _build_manifest(
            project,
            main_whl.name,
            [w.name for w in dep_whls],
            has_frontend=has_frontend,
        )

        # Create .mld archive
        mld_filename = f"{name}-{version}.mld"
        mld_path = out_dir / mld_filename

        with zipfile.ZipFile(mld_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            zf.write(main_whl, main_whl.name)
            for dep in dep_whls:
                zf.write(dep, dep.name)

    print(f"Built {mld_path}")


@app.command(rich_help_panel="Develop")
def doctor(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    deps: Annotated[bool, typer.Option("--deps", help="Check platform core dependency alignment")] = False,
    fix: Annotated[bool, typer.Option("--fix", help="Fix misaligned deps (requires --deps)")] = False,
) -> None:
    """Validate plugin project structure and configuration."""
    if fix and not deps:
        typer.echo("Error: --fix requires --deps", err=True)
        raise typer.Exit(1)

    if deps:
        from mld_sdk.deps_command import cmd_doctor_deps

        cmd_doctor_deps(path=path, fix=fix)
        return

    from mld_sdk.doctor_command import cmd_doctor

    cmd_doctor(path=path)


@app.command(rich_help_panel="Develop")
def info(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Show plugin metadata."""
    from mld_sdk.info_command import cmd_info

    cmd_info(path=path, json_output=json_output)


@app.command(rich_help_panel="Develop")
def docs(
    path_args: Annotated[
        Optional[list[str]], typer.Argument(help="Path to browse: [python|frontend] [category] [item]")
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    no_cache: Annotated[bool, typer.Option("--no-cache", help="Force fresh extraction (ignore cache)")] = False,
    clear_cache: Annotated[bool, typer.Option("--clear-cache", help="Remove cached documentation and exit")] = False,
) -> None:
    """Browse SDK reference documentation."""
    from mld_sdk.docs_command import cmd_docs

    cmd_docs(
        path_args=path_args or [],
        json_output=json_output,
        no_cache=no_cache,
        clear_cache=clear_cache,
    )


# ---------------------------------------------------------------------------
# dev sub-app
# ---------------------------------------------------------------------------


@dev_app.callback(invoke_without_command=True)
def dev_callback(
    ctx: typer.Context,
    port: Annotated[int, typer.Option("--port", "-p", help="Backend server port")] = 8003,
    host: Annotated[str, typer.Option("--host", help="Backend host")] = "127.0.0.1",
    no_frontend: Annotated[bool, typer.Option("--no-frontend", help="Skip frontend dev server")] = False,
    platform: Annotated[
        bool, typer.Option("--platform", help="Also start the platform and configure dev proxy")
    ] = False,
    platform_dir: Annotated[
        Optional[str], typer.Option("--platform-dir", help="Path to platform mld/ directory")
    ] = None,
    prefix: Annotated[Optional[str], typer.Option("--prefix", help="Override routes prefix for dev proxy")] = None,
) -> None:
    """Run plugin in development mode with hot reload."""
    if ctx.invoked_subcommand is not None:
        return
    from mld_sdk.dev_command import cmd_dev

    cmd_dev(
        port=port,
        host=host,
        no_frontend=no_frontend,
        platform=platform,
        platform_dir=platform_dir,
        prefix=prefix,
    )


@dev_app.command()
def logs(
    process: Annotated[
        Optional[str], typer.Argument(help="Filter by process name (e.g., 'backend', 'frontend', 'platform')")
    ] = None,
    follow: Annotated[bool, typer.Option("--follow", "-f", help="Follow logs in real time")] = False,
    lines: Annotated[int, typer.Option("--lines", "-n", help="Number of recent lines to show")] = 50,
    list_logs: Annotated[bool, typer.Option("--list", help="List available log files")] = False,
    clear: Annotated[bool, typer.Option("--clear", help="Remove old log files")] = False,
) -> None:
    """View dev server logs."""
    from mld_sdk.logs_command import cmd_logs

    cmd_logs(
        process=process,
        follow=follow,
        lines=lines,
        list_logs=list_logs,
        clear=clear,
    )


# ---------------------------------------------------------------------------
# sdk sub-app
# ---------------------------------------------------------------------------


@sdk_app.command()
def link(
    sdk_path: Annotated[Optional[str], typer.Option("--sdk-path", help="Override path to SDK packages")] = None,
) -> None:
    """Link local SDK to sibling plugin repos."""
    from mld_sdk.link_command import cmd_link

    cmd_link(sdk_path=sdk_path)


@sdk_app.command()
def unlink() -> None:
    """Restore plugins to published SDK versions."""
    from mld_sdk.link_command import cmd_unlink

    cmd_unlink()


class UpdateScope(StrEnum):
    patch = "patch"
    minor = "minor"
    major = "major"


@sdk_app.command()
def update(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    scope: Annotated[UpdateScope, typer.Option("--scope", help="Update scope")] = UpdateScope.patch,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would be updated without modifying files")
    ] = False,
    no_sync: Annotated[bool, typer.Option("--no-sync", help="Skip running uv sync / bun install after update")] = False,
) -> None:
    """Update mld-sdk to the latest version."""
    from mld_sdk.update_command import cmd_update

    cmd_update(
        path=path,
        scope=scope,
        dry_run=dry_run,
        no_sync=no_sync,
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Main CLI entry point."""
    app()


if __name__ == "__main__":
    main()
