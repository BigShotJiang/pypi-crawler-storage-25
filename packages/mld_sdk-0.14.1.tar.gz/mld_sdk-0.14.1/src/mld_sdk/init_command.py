"""Core logic for the ``mld init`` scaffolding command."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from mld_sdk import init_templates as T

# ---------------------------------------------------------------------------
# AI assistant configurations
# ---------------------------------------------------------------------------

AI_ASSISTANTS: dict[str, dict[str, str]] = {
    "claude": {
        "filename": "CLAUDE.md",
        "tool_name": "Claude Code",
        "label": "Claude Code",
        "extra": "\n**Skill:** `mld-sdk-plugin` - Build full-stack analysis plugins for MorscherLabDatabase platform.\n",
    },
    "codex": {
        "filename": "AGENTS.md",
        "tool_name": "Codex",
        "label": "Codex (OpenAI)",
        "extra": "",
    },
    "cursor": {
        "filename": ".cursorrules",
        "tool_name": "Cursor",
        "label": "Cursor",
        "extra": "",
    },
    "windsurf": {
        "filename": ".windsurfrules",
        "tool_name": "Windsurf",
        "label": "Windsurf",
        "extra": "",
    },
}

# Derived from AI_ASSISTANTS — single source of truth
AI_KEYS = list(AI_ASSISTANTS)
AI_LABELS = [cfg["label"] for cfg in AI_ASSISTANTS.values()]


@dataclass(slots=True)
class PluginNames:
    """All derived name forms for a plugin."""

    human: str  # "Drug Response Analyzer"
    slug: str  # "drug-response-analyzer"
    package_name: str  # "mld-plugin-drug-response-analyzer"
    module_name: str  # "mld_plugin_drug_response_analyzer"
    class_name: str  # "DrugResponseAnalyzerPlugin"
    routes_prefix: str  # "/drug-response-analyzer"


def derive_names(human_name: str) -> PluginNames:
    """Derive all name forms from a human-readable plugin name."""
    # Normalize: strip leading/trailing whitespace
    name = human_name.strip()

    # Strip any existing "mld-plugin-" or "mld_plugin_" prefix to avoid doubling
    name = re.sub(r"^mld[-_]plugin[-_]", "", name, flags=re.IGNORECASE)

    if not name:
        raise ValueError("Plugin name cannot be empty.")

    # Build slug: lowercase, replace non-alnum with hyphens, collapse multiples
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    if not slug:
        raise ValueError("Plugin name must contain at least one alphanumeric character.")
    if slug[0].isdigit():
        raise ValueError("Plugin name must start with a letter.")
    if not re.search(r"[a-z]", slug):
        raise ValueError("Plugin name must contain at least one letter.")

    package_name = f"mld-plugin-{slug}"
    module_name = package_name.replace("-", "_")

    # Build class name from slug segments for deterministic Python identifier output.
    class_name = "".join(part.capitalize() for part in slug.split("-")) + "Plugin"

    routes_prefix = f"/{slug}"

    return PluginNames(
        human=human_name.strip(),
        slug=slug,
        package_name=package_name,
        module_name=module_name,
        class_name=class_name,
        routes_prefix=routes_prefix,
    )


def _get_git_config(key: str) -> str:
    """Read a git config value, returning empty string on failure."""
    try:
        result = subprocess.run(
            ["git", "config", "--get", key],
            capture_output=True,
            text=True,
        )
        return result.stdout.strip() if result.returncode == 0 else ""
    except FileNotFoundError:
        return ""


def _get_sdk_version() -> str:
    """Get the current SDK version for dependency pinning."""
    try:
        from mld_sdk import __version__

        ver = __version__
        if ver and ver != "0.0.0" and "dev" not in ver:
            # Use major.minor.patch only
            match = re.match(r"(\d+\.\d+\.\d+)", ver)
            return match.group(1) if match else "0.11.0"
    except Exception:
        pass
    return "0.11.0"


_PLUGIN_TYPES = ["analysis", "experiment-design"]
_PLUGIN_TYPE_LABELS = ["Analysis", "Experiment Design"]


def prompt_config(
    *,
    directory: str = ".",
    name: str | None = None,
    description: str | None = None,
    plugin_type: str | None = None,
    no_frontend: bool = False,
    ai_assistant: str | None = None,
) -> dict[str, str]:
    """Gather configuration from explicit values and interactive prompts."""
    from mld_sdk._prompt import prompt_confirm, prompt_multiselect, prompt_select, prompt_text

    config: dict[str, str] = {}

    # Directory
    config["directory"] = directory or "."

    # Plugin name
    if name:
        config["name"] = name
    else:
        default_name = directory.replace("-", " ").replace("_", " ").title() if directory != "." else "My Plugin"
        config["name"] = prompt_text("Plugin name", default_name)

    # Description
    if description:
        config["description"] = description
    else:
        config["description"] = prompt_text("Description", "An MLD analysis plugin")

    # Plugin type
    if plugin_type:
        config["type"] = plugin_type
    else:
        idx = prompt_select("Plugin type", _PLUGIN_TYPE_LABELS, default=0)
        config["type"] = _PLUGIN_TYPES[idx]

    # Frontend
    if not no_frontend:
        config["include_frontend"] = "true" if prompt_confirm("Include frontend?") else "false"
    else:
        config["include_frontend"] = "false"

    # AI assistants (multi-select)
    if ai_assistant:
        # CLI flag: comma-separated list like "claude,cursor"
        config["ai_assistants"] = ai_assistant
    else:
        indices = prompt_multiselect("AI coding assistants", AI_LABELS, defaults=[0])
        selected = [AI_KEYS[i] for i in indices]
        config["ai_assistants"] = ",".join(selected) if selected else ""

    return config


def _build_template_context(
    names: PluginNames,
    config: dict[str, str],
) -> dict[str, str]:
    """Build the placeholder -> value mapping for template rendering."""
    plugin_type = config.get("type", "analysis")
    plugin_type_enum = "EXPERIMENT_DESIGN" if plugin_type == "experiment-design" else "ANALYSIS"

    # Resolve AI assistants — pick the primary by priority order
    ai_keys = _parse_ai_assistants(config.get("ai_assistants", "claude"))
    primary_key = _pick_primary(ai_keys)
    ai_cfg = AI_ASSISTANTS.get(primary_key) if primary_key else None

    return {
        "PLUGIN_NAME": names.human,
        "SLUG": names.slug,
        "PACKAGE_NAME": names.package_name,
        "MODULE_NAME": names.module_name,
        "CLASS_NAME": names.class_name,
        "ROUTES_PREFIX": names.routes_prefix,
        "DESCRIPTION": config.get("description", "An MLD analysis plugin"),
        "PLUGIN_TYPE": config.get("type", "analysis"),
        "PLUGIN_TYPE_ENUM": plugin_type_enum,
        "AUTHOR": _get_git_config("user.name") or "Your Name",
        "EMAIL": _get_git_config("user.email") or "you@example.com",
        "SDK_VERSION": _get_sdk_version(),
        "AI_FILENAME": ai_cfg["filename"] if ai_cfg else "",
        "AI_TOOL_NAME": ai_cfg["tool_name"] if ai_cfg else "",
        "AI_EXTRA": ai_cfg.get("extra", "") if ai_cfg else "",
    }


def _parse_ai_assistants(raw: str) -> list[str]:
    """Parse comma-separated AI assistant keys, warning about invalid ones."""
    if not raw or raw.strip() == "none":
        return []
    valid: list[str] = []
    for token in raw.split(","):
        key = token.strip()
        if not key:
            continue
        if key == "none":
            continue
        if key in AI_ASSISTANTS:
            valid.append(key)
        else:
            print(
                f"  Warning: unknown AI assistant '{key}' (valid: {', '.join(sorted(AI_ASSISTANTS))})",
                file=sys.stderr,
            )
    return valid


def _pick_primary(keys: list[str]) -> str | None:
    """Pick the primary AI file by priority (Claude first — it has the Skill line)."""
    if not keys:
        return None
    for candidate in AI_KEYS:
        if candidate in keys:
            return candidate
    return keys[0]


def render(template: str, context: dict[str, str]) -> str:
    """Replace ``__KEY__`` placeholders in a template string."""
    result = template
    for key, value in context.items():
        result = result.replace(f"__{key.upper()}__", str(value))
    return result


# File tree: (relative_path, template_constant)
# None template means empty file.
BACKEND_FILES: list[tuple[str, str | None]] = [
    ("pyproject.toml", "PYPROJECT_TOML"),
    ("README.md", "README_MD"),
    ("CHANGELOG.md", "CHANGELOG_MD"),
    (".gitignore", "GITIGNORE"),
    ("src/__MODULE_NAME__/__init__.py", "INIT_PY"),
    ("src/__MODULE_NAME__/plugin.py", "PLUGIN_PY"),
    ("src/__MODULE_NAME__/routers/__init__.py", "ROUTERS_INIT_PY"),
    ("src/__MODULE_NAME__/routers/analysis.py", "ROUTERS_ANALYSIS_PY"),
    ("src/__MODULE_NAME__/schemas/__init__.py", "SCHEMAS_INIT_PY"),
    ("src/__MODULE_NAME__/schemas/requests.py", "SCHEMAS_REQUESTS_PY"),
    ("src/__MODULE_NAME__/services/__init__.py", "SERVICES_INIT_PY"),
    ("src/__MODULE_NAME__/services/analysis_service.py", "SERVICES_ANALYSIS_PY"),
    ("tests/__init__.py", None),
    ("tests/test_plugin.py", "TEST_PLUGIN_PY"),
    ("scripts/dev.sh", "SCRIPT_DEV_SH"),
    ("scripts/build.sh", "SCRIPT_BUILD_SH"),
    ("scripts/release.sh", "SCRIPT_RELEASE_SH"),
    (".github/workflows/ci.yml", "CI_YML"),
    (".github/workflows/release.yml", "RELEASE_YML"),
]

FRONTEND_FILES: list[tuple[str, str | None]] = [
    ("frontend/package.json", "FRONTEND_PACKAGE_JSON"),
    ("frontend/vite.config.ts", "FRONTEND_VITE_CONFIG_TS"),
    ("frontend/tsconfig.json", "FRONTEND_TSCONFIG_JSON"),
    ("frontend/tsconfig.node.json", "FRONTEND_TSCONFIG_NODE_JSON"),
    ("frontend/postcss.config.js", "FRONTEND_POSTCSS_CONFIG_JS"),
    ("frontend/index.html", "FRONTEND_INDEX_HTML"),
    ("frontend/src/main.ts", "FRONTEND_MAIN_TS"),
    ("frontend/src/style.css", "FRONTEND_STYLE_CSS"),
    ("frontend/src/env.d.ts", "FRONTEND_ENV_D_TS"),
    ("frontend/src/App.vue", "FRONTEND_APP_VUE"),
    ("frontend/src/views/DashboardView.vue", "FRONTEND_DASHBOARD_VIEW_VUE"),
    ("frontend/src/views/AnalysisView.vue", "FRONTEND_ANALYSIS_VIEW_VUE"),
]


def write_files(
    target_dir: Path,
    context: dict[str, str],
    include_frontend: bool,
    ai_keys: list[str] | None = None,
) -> list[str]:
    """Write all scaffolded files. Returns list of relative paths created."""
    files = list(BACKEND_FILES)
    if include_frontend:
        files.extend(FRONTEND_FILES)

    # Also copy the sdk-auto-update workflow if the template exists
    sdk_auto_update = _find_sdk_auto_update_template()
    created: list[str] = []

    for rel_path, template_name in files:
        # Replace __MODULE_NAME__ in path
        rel_path = rel_path.replace("__MODULE_NAME__", context["MODULE_NAME"])
        abs_path = target_dir / rel_path

        abs_path.parent.mkdir(parents=True, exist_ok=True)

        if template_name is None:
            abs_path.write_text("")
        else:
            template = getattr(T, template_name)
            abs_path.write_text(render(template, context))

        created.append(rel_path)

    # Copy sdk-auto-update template if available
    if sdk_auto_update:
        dest = target_dir / ".github" / "workflows" / "sdk-auto-update.yml"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(sdk_auto_update, dest)
        created.append(".github/workflows/sdk-auto-update.yml")

    # Write AI instructions: primary file + symlinks for others
    if ai_keys is None:
        ai_keys = []
    primary_key = _pick_primary(ai_keys)
    if primary_key:
        ai_template = Path(__file__).parent / "ai_instructions.md.template"
        if ai_template.exists():
            primary_filename = AI_ASSISTANTS[primary_key]["filename"]
            content = render(ai_template.read_text(), context)
            content = re.sub(r"\n{3,}", "\n\n", content)
            primary_dest = target_dir / primary_filename
            primary_dest.parent.mkdir(parents=True, exist_ok=True)
            primary_dest.write_text(content)
            created.append(primary_filename)

            # Symlink other selected AI files → primary
            for key in ai_keys:
                if key == primary_key:
                    continue
                link_filename = AI_ASSISTANTS[key]["filename"]
                link_path = target_dir / link_filename
                link_path.parent.mkdir(parents=True, exist_ok=True)
                if link_path.exists() or link_path.is_symlink():
                    link_path.unlink()
                os.symlink(primary_filename, link_path)
                created.append(f"{link_filename} -> {primary_filename}")

    return created


def _find_sdk_auto_update_template() -> Path | None:
    """Locate the sdk-auto-update workflow template in the SDK package."""
    # Check relative to this file (monorepo layout)
    candidate = (
        Path(__file__).resolve().parent.parent.parent.parent.parent
        / ".github"
        / "workflows"
        / "sdk-auto-update.template.yml"
    )
    if candidate.exists():
        return candidate
    return None


def post_scaffold(
    target_dir: Path,
    *,
    no_install: bool,
    no_git: bool,
    has_frontend: bool,
) -> None:
    """Run post-scaffolding steps: git init, install deps, chmod scripts."""
    # chmod scripts
    scripts_dir = target_dir / "scripts"
    if scripts_dir.exists():
        for script in scripts_dir.glob("*.sh"):
            script.chmod(script.stat().st_mode | 0o755)

    # git init
    if not no_git:
        if not (target_dir / ".git").exists():
            result = subprocess.run(
                ["git", "init"],
                cwd=target_dir,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                print("  Initialized git repository")
            else:
                print(f"  Warning: git init failed: {result.stderr}", file=sys.stderr)

    # Create frontend/dist placeholder so hatch force-include doesn't fail
    if has_frontend:
        (target_dir / "frontend" / "dist").mkdir(parents=True, exist_ok=True)

    # uv sync
    if not no_install:
        if shutil.which("uv"):
            print("  Running uv sync...")
            result = subprocess.run(
                ["uv", "sync"],
                cwd=target_dir,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                print(
                    f"  Warning: uv sync failed: {result.stderr}",
                    file=sys.stderr,
                )
        else:
            print("  Warning: uv not found, skipping dependency install")

        # bun install
        if has_frontend:
            frontend_dir = target_dir / "frontend"
            if shutil.which("bun"):
                print("  Running bun install...")
                result = subprocess.run(
                    ["bun", "install"],
                    cwd=frontend_dir,
                    capture_output=True,
                    text=True,
                )
                if result.returncode != 0:
                    print(
                        f"  Warning: bun install failed: {result.stderr}",
                        file=sys.stderr,
                    )
            else:
                print("  Warning: bun not found, skipping frontend install")


def cmd_init(
    *,
    directory: str = ".",
    name: str | None = None,
    description: str | None = None,
    plugin_type: str | None = None,
    no_frontend: bool = False,
    no_install: bool = False,
    no_git: bool = False,
    force: bool = False,
    ai_assistant: str | None = None,
) -> None:
    """Execute the ``mld init`` command."""
    config = prompt_config(
        directory=directory,
        name=name,
        description=description,
        plugin_type=plugin_type,
        no_frontend=no_frontend,
        ai_assistant=ai_assistant,
    )

    try:
        names = derive_names(config["name"])
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    include_frontend = config.get("include_frontend", "true") == "true"

    # Resolve target directory
    resolved_directory = config["directory"]
    if resolved_directory == ".":
        target_dir = Path.cwd()
    else:
        target_dir = Path(resolved_directory).resolve()

    # Safety check: non-empty directory
    if target_dir.exists() and any(target_dir.iterdir()) and not force:
        print(
            f"Error: {target_dir} is not empty. Use --force to scaffold anyway.",
            file=sys.stderr,
        )
        sys.exit(1)

    target_dir.mkdir(parents=True, exist_ok=True)

    ai_keys = _parse_ai_assistants(config.get("ai_assistants", "claude"))
    context = _build_template_context(names, config)
    print(f"\nCreating {names.package_name}/ ...")

    created = write_files(target_dir, context, include_frontend, ai_keys=ai_keys)

    for f in created:
        print(f"  {f}")

    print()
    post_scaffold(
        target_dir,
        no_install=no_install,
        no_git=no_git,
        has_frontend=include_frontend,
    )

    # Print next steps
    print(f"""
Done! Next steps:
  cd {resolved_directory}
  mld doctor          # validate plugin structure
  mld dev             # start backend + frontend dev servers
""")
