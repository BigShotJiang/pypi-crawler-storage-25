"""TypedDict definitions for MLD API responses.

These provide IDE autocompletion hints for the dict responses returned
by resource API methods. At runtime the values are plain dicts.
"""

from __future__ import annotations

from typing import Any, TypedDict


class UserInfo(TypedDict, total=False):
    id: str
    username: str
    role: str
    shortname: str | None
    first_name: str | None
    last_name: str | None
    email: str | None
    is_active: bool


class LoginResponse(TypedDict):
    access_token: str
    token_type: str
    expires_in: int
    user: UserInfo


class TokenVerifyResponse(TypedDict, total=False):
    valid: bool
    user: UserInfo | None
    username: str | None
    expires_at: str | None


class ExperimentDict(TypedDict, total=False):
    id: int
    name: str
    experiment_code: str | None
    experiment_type: str
    status: str
    parent_experiment_id: int | None
    project: str | None
    project_id: int | None
    notes: str | None
    tags: dict[str, Any] | None
    created_at: str
    updated_at: str
    created_by: int | None
    has_design_data: bool


class DesignDataDict(TypedDict, total=False):
    experiment_id: int
    plugin_id: str
    data: dict[str, Any]
    schema_version: str
    updated_at: str | None


class AnalysisResultDict(TypedDict, total=False):
    experiment_id: int
    plugin_id: str
    result: dict[str, Any]
    updated_at: str | None


class ProjectDict(TypedDict, total=False):
    id: int
    name: str
    description: str | None
    status: str
    lead_id: int | None
    tags: dict[str, Any] | None
    start_date: str | None
    end_date: str | None
    created_at: str
    updated_at: str
    member_count: int
    experiment_count: int


class PluginDict(TypedDict, total=False):
    name: str
    version: str
    routes_prefix: str
    plugin_type: str
    description: str
    enabled: bool
