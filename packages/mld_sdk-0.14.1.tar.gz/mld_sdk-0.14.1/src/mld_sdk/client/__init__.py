"""MLD platform API client.

Usage:
    from mld_sdk.client import MLDClient

    client = MLDClient("http://localhost:8001")
    client.login("admin", "password")
    experiments = client.experiments.list()
"""

from mld_sdk.client._exceptions import (
    AuthenticationError,
    ConflictError,
    MLDAPIError,
    MLDConnectionError,
    MLDPermissionError,
    MLDValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
)
from mld_sdk.client.client import MLDClient

__all__ = [
    "MLDClient",
    "MLDAPIError",
    "AuthenticationError",
    "MLDPermissionError",
    "NotFoundError",
    "ConflictError",
    "MLDValidationError",
    "RateLimitError",
    "ServerError",
    "MLDConnectionError",
]
