"""Platform dependency alignment for ``mld doctor --deps``.

Compares installed versions of platform core packages against the
lockfile (``uv.lock``) and optionally pins correct versions in
``pyproject.toml`` and runs ``uv sync`` to restore the environment.

Typical use: after a plugin force-install downgrades a core package
(e.g. bcrypt 5.0.0 → 4.3.0), run ``mld doctor --deps --fix`` to
pin the correct versions as ``[tool.uv] constraint-dependencies``
and re-sync the environment.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python < 3.11
    import tomli as tomllib  # type: ignore[no-redef]

from mld_sdk.info_command import _supports_color

# Platform core packages — should match api/plugins/conflict.py
PLATFORM_CORE_PACKAGES: frozenset[str] = frozenset({
    "fastapi",
    "pydantic",
    "pydantic-core",
    "starlette",
    "uvicorn",
    "httpx",
    "sqlalchemy",
    "bcrypt",
    "python-jose",
    "python-multipart",
    "aiosqlite",
    "asyncpg",
    "webauthn",
    "pydantic-settings",
})


def _normalize(name: str) -> str:
    """PEP 503 normalize: lowercase, collapse [-_.] to single hyphen."""
    return re.sub(r"[-_.]+", "-", name.lower())


@dataclass(slots=True)
class DepMismatch:
    """A core package whose installed version differs from the lockfile."""

    name: str
    installed: str | None
    expected: str
    is_downgrade: bool


def _find_platform_root(start: Path) -> Path | None:
    """Locate the MLD platform root directory.

    Checks *start* first, then scans sibling directories.
    """
    # Direct: cwd is the platform root
    if (start / "api" / "main.py").exists() and (start / "uv.lock").exists():
        return start

    # Sibling: we're in a plugin dir, platform is a sibling
    workspace = start.parent
    candidate = workspace / "mld"
    if candidate.is_dir() and (candidate / "api" / "main.py").exists():
        return candidate

    try:
        for child in workspace.iterdir():
            if child == start or not child.is_dir():
                continue
            if (child / "api" / "main.py").exists() and (child / "uv.lock").exists():
                return child
    except OSError:
        pass

    return None


def _parse_lockfile_versions(lock_path: Path) -> dict[str, str]:
    """Parse ``uv.lock`` → {normalized_name: version}.

    Skips editable/path packages that have no ``version`` field.
    """
    data = tomllib.loads(lock_path.read_text())
    versions: dict[str, str] = {}
    for pkg in data.get("package", []):
        name = pkg.get("name", "")
        version = pkg.get("version", "")
        if name and version:
            versions[_normalize(name)] = version
    return versions


def _get_installed_versions(platform_root: Path) -> dict[str, str]:
    """Get installed package versions via ``uv pip list``."""
    result = subprocess.run(
        ["uv", "pip", "list", "--format", "json"],
        capture_output=True,
        text=True,
        cwd=platform_root,
    )
    if result.returncode != 0:
        return {}
    packages = json.loads(result.stdout)
    return {_normalize(p["name"]): p["version"] for p in packages}


def _compare_versions(expected: str, actual: str) -> bool:
    """Return True if *actual* is lower than *expected* (a downgrade)."""
    try:
        from packaging.version import Version

        return Version(actual) < Version(expected)
    except Exception:
        return actual != expected


def _update_pyproject_constraints(
    platform_root: Path,
    mismatches: list[DepMismatch],
) -> bool:
    """Add or update ``[tool.uv] constraint-dependencies`` in pyproject.toml.

    Merges new constraints with any existing ones, replacing entries for the
    same package name. Returns True on success.
    """
    pyproject_path = platform_root / "pyproject.toml"
    if not pyproject_path.exists():
        return False

    content = pyproject_path.read_text()
    data = tomllib.loads(content)

    # Build new constraint specs from mismatches
    new_specs = {_normalize(m.name): f"{m.name}>={m.expected}" for m in mismatches}

    # Merge with existing constraints
    existing = data.get("tool", {}).get("uv", {}).get("constraint-dependencies", [])
    for constraint in existing:
        name_match = re.match(r"([a-zA-Z0-9][-a-zA-Z0-9_.]*)", constraint)
        if name_match:
            norm = _normalize(name_match.group(1))
            if norm not in new_specs:
                new_specs[norm] = constraint

    sorted_specs = sorted(new_specs.values(), key=lambda s: s.lower())
    lines = ",\n    ".join(f'"{s}"' for s in sorted_specs)
    block = f"constraint-dependencies = [\n    {lines},\n]"

    if "constraint-dependencies" in content:
        # Replace existing constraint-dependencies array
        content = re.sub(
            r"constraint-dependencies\s*=\s*\[.*?\]",
            block,
            content,
            count=1,
            flags=re.DOTALL,
        )
    elif "[tool.uv]" in content:
        # Section exists, add constraint-dependencies after it
        content = content.replace(
            "[tool.uv]",
            f"[tool.uv]\n{block}",
            1,
        )
    else:
        # No [tool.uv] section — append
        content = content.rstrip() + f"\n\n[tool.uv]\n{block}\n"

    pyproject_path.write_text(content)
    return True


def cmd_doctor_deps(*, path: str = ".", fix: bool = False) -> None:
    """Check and optionally fix platform core dependency alignment."""
    project_dir = Path(path).resolve()

    color = _supports_color()
    green = "\033[32m" if color else ""
    red = "\033[31m" if color else ""
    yellow = "\033[33m" if color else ""
    dim = "\033[2m" if color else ""
    bold = "\033[1m" if color else ""
    reset = "\033[0m" if color else ""

    platform_root = _find_platform_root(project_dir)
    if not platform_root:
        print(f"{red}Could not find MLD platform root.{reset}")
        print("Run from the platform directory or a sibling plugin directory.")
        sys.exit(1)

    lock_path = platform_root / "uv.lock"
    if not lock_path.exists():
        print(f"{red}No uv.lock found at {platform_root}{reset}")
        sys.exit(1)

    locked = _parse_lockfile_versions(lock_path)
    installed = _get_installed_versions(platform_root)

    if not installed:
        print(f"{red}Could not read installed packages (is uv available?){reset}")
        sys.exit(1)

    print(f"\n{bold}Platform core dependencies{reset}  {dim}{platform_root}{reset}\n")

    mismatches: list[DepMismatch] = []
    for name in sorted(PLATFORM_CORE_PACKAGES):
        expected = locked.get(name)
        actual = installed.get(name)

        if expected is None:
            # Not in lockfile (editable or optional) — skip
            continue

        if actual is None:
            mismatches.append(DepMismatch(name, None, expected, True))
            print(f"  {red}!!{reset}  {name:<22s}  {red}missing{reset}  {dim}(expected {expected}){reset}")
        elif actual != expected:
            is_down = _compare_versions(expected, actual)
            mismatches.append(DepMismatch(name, actual, expected, is_down))
            icon = f"{red}!!{reset}" if is_down else f"{yellow}!!{reset}"
            label = "downgraded" if is_down else "differs"
            print(f"  {icon}  {name:<22s}  {actual} -> {expected}  {dim}({label}){reset}")
        else:
            print(f"  {green}ok{reset}  {name:<22s}  {dim}{actual}{reset}")

    print()

    if not mismatches:
        print(f"{green}All core dependencies aligned with lockfile.{reset}")
        return

    downs = sum(1 for m in mismatches if m.is_downgrade)
    summary = f"{len(mismatches)} misaligned"
    if downs:
        summary += f" ({downs} downgraded)"
    print(f"{yellow}{summary}{reset}")

    if not fix:
        print(f"\nRun {bold}mld doctor --deps --fix{reset} to restore locked versions.")
        sys.exit(1)

    # Fix: pin core packages in pyproject.toml and uv sync
    specs = [f"{m.name}>={m.expected}" for m in mismatches]

    print(f"\n{bold}Pinning in pyproject.toml:{reset} {', '.join(specs)}")
    if not _update_pyproject_constraints(platform_root, mismatches):
        print(f"{red}Failed to update pyproject.toml{reset}")
        sys.exit(1)

    print(f"\n{bold}Running uv sync...{reset}\n")
    result = subprocess.run(["uv", "sync"], cwd=platform_root)

    if result.returncode == 0:
        print(f"\n{green}Restored {len(mismatches)} package(s) — pinned in pyproject.toml and synced.{reset}")
        print(f"{dim}Plugins will be re-installed on next server start.{reset}")
    else:
        print(f"\n{red}uv sync failed — see output above.{reset}")
        sys.exit(1)
