"""CLI commands for MLD platform authentication.

Provides: mld auth login, mld auth logout, mld auth status
"""

from __future__ import annotations

import getpass
import sys
from typing import Annotated, Optional

import typer

from mld_sdk.client._config import get_default_host, get_stored_token, get_stored_username

auth_app = typer.Typer(help="Manage platform authentication", no_args_is_help=True)


@auth_app.command()
def login(
    url: Annotated[Optional[str], typer.Option("--url", help="Platform URL (e.g. http://localhost:8001)")] = None,
    username: Annotated[
        Optional[str], typer.Option("--username", "-u", help="Username (prompted if not provided)")
    ] = None,
) -> None:
    """Authenticate to an MLD platform instance."""
    url = url or get_default_host()
    if not url:
        url = input("Platform URL: ").strip()
        if not url:
            print("Error: Platform URL is required.", file=sys.stderr)
            sys.exit(1)

    if not username:
        username = input("Username: ").strip()
        if not username:
            print("Error: Username is required.", file=sys.stderr)
            sys.exit(1)

    password = getpass.getpass("Password: ")

    try:
        from mld_sdk.client import MLDClient

        client = MLDClient(base_url=url)
        result = client.login(username, password)
        user = result.get("user", {})
        print(f"Logged in as {user.get('username', username)} ({user.get('role', 'user')})")
        print(f"Host: {url}")
        client.close()
    except Exception as e:
        print(f"Login failed: {e}", file=sys.stderr)
        sys.exit(1)


@auth_app.command()
def logout(
    url: Annotated[
        Optional[str], typer.Option("--url", help="Platform URL to logout from (defaults to current host)")
    ] = None,
) -> None:
    """Clear stored credentials."""
    from mld_sdk.client._config import remove_token

    url = url or get_default_host()
    if not url:
        print("No host configured. Nothing to do.", file=sys.stderr)
        return

    remove_token(url)
    print(f"Logged out from {url}")


@auth_app.command(name="status")
def auth_status() -> None:
    """Show current authentication status."""
    host = get_default_host()
    if not host:
        print("Not logged in (no host configured)")
        print("  Run: mld auth login --url <URL>")
        return

    token = get_stored_token(host)
    username = get_stored_username(host)

    if not token:
        print(f"Host: {host}")
        print("Status: Not logged in")
        print("  Run: mld auth login")
        return

    print(f"Host: {host}")
    print(f"User: {username or 'unknown'}")
    print("Status: Authenticated")

    # Optionally verify the token is still valid
    try:
        from mld_sdk.client import MLDClient

        client = MLDClient(base_url=host)
        info = client.auth.verify()
        if info.get("valid"):
            user_info = info.get("user", {})
            role = user_info.get("role", "")
            if role:
                print(f"Role: {role}")
            expires = info.get("expires_at")
            if expires:
                print(f"Expires: {expires}")
        client.close()
    except Exception:
        print("(could not verify token — server may be unreachable)")
