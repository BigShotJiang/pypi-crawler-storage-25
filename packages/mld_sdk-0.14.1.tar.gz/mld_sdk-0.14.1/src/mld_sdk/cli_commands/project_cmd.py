"""CLI commands for MLD project management.

Provides: mld project list, mld project get
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Optional

import typer

from mld_sdk.cli_commands._utils import get_client, print_json
from mld_sdk.info_command import _supports_color


class ProjectStatus(StrEnum):
    active = "active"
    archived = "archived"
    completed = "completed"


project_app = typer.Typer(help="Manage projects", no_args_is_help=True)

_PROJECT_STATUS_COLORS = {"active": "32", "archived": "2", "completed": "34"}  # green, dim, blue


def _project_status_str(status: str, color: bool) -> str:
    code = _PROJECT_STATUS_COLORS.get(status, "0")
    return f"\033[{code}m{status}\033[0m" if color else status


@project_app.command(name="list")
def list_projects(
    search: Annotated[Optional[str], typer.Option("--search", help="Search by name")] = None,
    status: Annotated[Optional[ProjectStatus], typer.Option("--status", help="Filter by status")] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List projects."""
    client = get_client()
    projects = client.projects.list(
        search=search,
        status=status,
    )
    if json_output:
        print_json(projects)
    else:
        if not projects:
            print("No projects found.")
        else:
            c = _supports_color()
            bold = "\033[1m" if c else ""
            dim = "\033[2m" if c else ""
            r = "\033[0m" if c else ""

            print(f"{bold}{'ID':<6} {'Name':<30} {'Status':<12} {'Experiments':<12}{r}")
            print(f"{dim}{'-' * 62}{r}")
            for p in projects:
                st = _project_status_str(str(p.get("status", "")), c)
                print(
                    f"{p.get('id', ''):<6} "
                    f"{str(p.get('name', ''))[:28]:<30} "
                    f"{st:<{12 if not c else 21}} "
                    f"{dim}{p.get('experiment_count', 0)}{r}"
                )
            print(f"\n{dim}{len(projects)} project(s){r}")
    client.close()


@project_app.command()
def get(
    id: Annotated[int, typer.Argument(help="Project ID")],
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Get project details."""
    client = get_client()
    proj = client.projects.get(id)
    if json_output:
        print_json(proj)
    else:
        c = _supports_color()
        bold = "\033[1m" if c else ""
        dim = "\033[2m" if c else ""
        r = "\033[0m" if c else ""

        st = _project_status_str(str(proj.get("status", "")), c)
        print(f"{bold}Project #{proj.get('id')}{r}")
        print(f"  {dim}Name:{r}        {proj.get('name')}")
        print(f"  {dim}Status:{r}      {st}")
        if proj.get("description"):
            print(f"  {dim}Desc:{r}        {proj.get('description')}")
        print(f"  {dim}Members:{r}     {proj.get('member_count', 0)}")
        print(f"  {dim}Experiments:{r} {proj.get('experiment_count', 0)}")
        print(f"  {dim}Created:{r}     {proj.get('created_at')}")
    client.close()
