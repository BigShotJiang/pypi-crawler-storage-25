"""Shared utilities for CLI command modules."""

from __future__ import annotations

import json
import sys


def get_client(*, base_url: str | None = None):
    """Create an MLDClient."""
    try:
        from mld_sdk.client import MLDClient

        return MLDClient(base_url=base_url) if base_url else MLDClient()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def print_json(data: object) -> None:
    """Pretty-print a JSON-serializable object."""
    print(json.dumps(data, indent=2, default=str))
