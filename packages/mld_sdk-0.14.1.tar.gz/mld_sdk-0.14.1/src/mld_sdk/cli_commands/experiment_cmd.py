"""CLI commands for MLD experiment management.

Provides: mld experiment list, get, create, data, results, delete
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Optional

import typer

from mld_sdk.cli_commands._utils import get_client, print_json
from mld_sdk.info_command import _supports_color


class ExportFormat(StrEnum):
    json = "json"
    csv = "csv"


experiment_app = typer.Typer(help="Manage experiments", no_args_is_help=True)

_STATUS_COLORS = {"planned": "34", "ongoing": "33", "completed": "32"}  # blue, yellow, green


def _status_str(status: str, color: bool) -> str:
    code = _STATUS_COLORS.get(status, "0")
    return f"\033[{code}m{status}\033[0m" if color else status


def _print_experiment_table(experiments: list[dict]) -> None:
    """Print experiments as a formatted table."""
    if not experiments:
        print("No experiments found.")
        return

    c = _supports_color()
    bold = "\033[1m" if c else ""
    dim = "\033[2m" if c else ""
    r = "\033[0m" if c else ""

    print(f"{bold}{'ID':<6} {'Name':<30} {'Type':<15} {'Status':<12} {'Created':<20}{r}")
    print(f"{dim}{'-' * 85}{r}")
    for exp in experiments:
        created = str(exp.get("created_at", ""))[:19]
        status = _status_str(str(exp.get("status", ""))[:10], c)
        print(
            f"{exp.get('id', ''):<6} "
            f"{str(exp.get('name', ''))[:28]:<30} "
            f"{dim}{str(exp.get('experiment_type', ''))[:13]:<15}{r} "
            f"{status:<{12 if not c else 21}} "
            f"{dim}{created}{r}"
        )
    print(f"\n{dim}{len(experiments)} experiment(s){r}")


def _print_experiment_detail(exp: dict) -> None:
    """Print a single experiment with details."""
    c = _supports_color()
    bold = "\033[1m" if c else ""
    dim = "\033[2m" if c else ""
    r = "\033[0m" if c else ""

    print(f"{bold}Experiment #{exp.get('id')}{r}")
    print(f"  {dim}Name:{r}   {exp.get('name')}")
    print(f"  {dim}Code:{r}   {exp.get('experiment_code', '—')}")
    print(f"  {dim}Type:{r}   {exp.get('experiment_type')}")
    print(f"  {dim}Status:{r} {_status_str(str(exp.get('status', '')), c)}")
    if exp.get("project"):
        print(f"  {dim}Project:{r} {exp.get('project')}")
    if exp.get("notes"):
        print(f"  {dim}Notes:{r}  {exp.get('notes')}")
    if exp.get("tags"):
        print(f"  {dim}Tags:{r}   {exp.get('tags')}")
    print(f"  {dim}Created:{r} {exp.get('created_at')}")
    print(f"  {dim}Updated:{r} {exp.get('updated_at')}")


@experiment_app.command(name="list")
def list_experiments(
    status: Annotated[Optional[str], typer.Option("--status", help="Filter by status")] = None,
    experiment_type: Annotated[Optional[str], typer.Option("--type", help="Filter by experiment type")] = None,
    project_id: Annotated[Optional[int], typer.Option("--project-id", help="Filter by project ID")] = None,
    search: Annotated[Optional[str], typer.Option("--search", help="Search by name")] = None,
    mine: Annotated[bool, typer.Option("--mine", help="Show only my experiments")] = False,
    since: Annotated[Optional[str], typer.Option("--since", help="Created after date (YYYY-MM-DD)")] = None,
    before: Annotated[Optional[str], typer.Option("--before", help="Created before date (YYYY-MM-DD)")] = None,
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 20,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List experiments."""
    client = get_client()
    experiments = client.experiments.list(
        status=status,
        experiment_type=experiment_type,
        project_id=project_id,
        search=search,
        mine=mine,
        created_after=since,
        created_before=before,
        limit=limit,
    )
    if json_output:
        print_json(experiments)
    else:
        _print_experiment_table(experiments)
    client.close()


@experiment_app.command()
def get(
    id: Annotated[int, typer.Argument(help="Experiment ID")],
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Get experiment details."""
    client = get_client()
    exp = client.experiments.get(id)
    if json_output:
        print_json(exp)
    else:
        _print_experiment_detail(exp)
    client.close()


@experiment_app.command()
def create(
    name: Annotated[str, typer.Argument(help="Experiment name")],
    experiment_type: Annotated[str, typer.Option("--type", help="Experiment type")] = "custom",
    project_id: Annotated[Optional[int], typer.Option("--project-id", help="Project ID")] = None,
    notes: Annotated[Optional[str], typer.Option("--notes", help="Notes")] = None,
) -> None:
    """Create a new experiment."""
    client = get_client()
    exp = client.experiments.create(
        name=name,
        experiment_type=experiment_type,
        project_id=project_id,
        notes=notes,
    )
    print(f"Created experiment #{exp.get('id')}: {exp.get('name')}")
    client.close()


@experiment_app.command()
def data(
    id: Annotated[int, typer.Argument(help="Experiment ID")],
    format: Annotated[ExportFormat, typer.Option("--format", help="Export format")] = ExportFormat.json,
) -> None:
    """Get experiment design data."""
    client = get_client()
    if format == ExportFormat.csv:
        result = client.experiments.export_data(id, format="csv")
    else:
        result = client.experiments.get_data(id)
    print_json(result) if isinstance(result, dict) else print(result)
    client.close()


@experiment_app.command()
def results(
    id: Annotated[int, typer.Argument(help="Experiment ID")],
    plugin: Annotated[Optional[str], typer.Option("--plugin", help="Filter by plugin ID")] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Get analysis results."""
    client = get_client()
    if plugin:
        result = client.experiments.get_result(id, plugin)
        print_json(result)
    else:
        all_results = client.experiments.get_results(id)
        if json_output:
            print_json(all_results)
        else:
            if not all_results:
                print("No analysis results.")
            else:
                for r in all_results:
                    print(f"  Plugin: {r.get('plugin_id', '?')}")
                    print(f"  Updated: {r.get('updated_at', '?')}")
                    print()
    client.close()


@experiment_app.command()
def delete(
    id: Annotated[int, typer.Argument(help="Experiment ID")],
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Delete an experiment."""
    if not yes:
        typer.confirm(f"Delete experiment #{id}?", abort=True)

    client = get_client()
    client.experiments.delete(id)
    print(f"Deleted experiment #{id}")
    client.close()
