"""Migration error types."""

from __future__ import annotations


class MigrationError(Exception):
    """Base error for all migration failures."""


class DestructiveMigrationError(MigrationError):
    """Raised when a migration attempts a destructive op without destructive=True."""

    def __init__(self, operation: str, table: str, target: str = "") -> None:
        self.operation = operation
        self.table = table
        self.target = target
        detail = f" on '{target}'" if target else ""
        super().__init__(
            f"Destructive operation '{operation}' on table '{table}'{detail} "
            f"requires the migration to set destructive = True"
        )


class MigrationChecksumError(MigrationError):
    """Raised when a previously-applied migration's source has changed."""

    def __init__(
        self, plugin_name: str, version: int, expected: str, actual: str
    ) -> None:
        self.plugin_name = plugin_name
        self.version = version
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"Migration v{version:03d} for plugin '{plugin_name}' has changed "
            f"since it was applied (expected checksum {expected[:8]}…, "
            f"got {actual[:8]}…). Migrations are immutable once applied."
        )


class SchemaVersionAheadError(MigrationError):
    """Raised when the DB schema is newer than the plugin's bundled migrations."""

    def __init__(
        self, plugin_name: str, *, db_version: int, plugin_max_version: int
    ) -> None:
        self.plugin_name = plugin_name
        self.db_version = db_version
        self.plugin_max_version = plugin_max_version
        super().__init__(
            f"Plugin '{plugin_name}' schema is at v{db_version} but plugin "
            f"only bundles up to v{plugin_max_version}. Deploy a newer plugin "
            f"version or roll back the schema manually."
        )
