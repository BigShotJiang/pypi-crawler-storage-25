"""Per-plugin advisory locks for migration concurrency safety."""

from __future__ import annotations

import hashlib
import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine

logger = logging.getLogger(__name__)

LOCK_TIMEOUT_SECONDS = 30


def _plugin_lock_id(plugin_name: str) -> int:
    """Deterministic 32-bit lock ID from plugin name."""
    digest = hashlib.md5(plugin_name.encode()).hexdigest()  # noqa: S324
    return int(digest[:8], 16)


@asynccontextmanager
async def advisory_lock(
    engine: AsyncEngine,
    plugin_name: str,
    *,
    dialect: str,
) -> AsyncGenerator[AsyncConnection, None]:
    """Acquire a per-plugin advisory lock for the duration of migrations.

    - **PostgreSQL**: ``pg_advisory_lock`` on a hash of the plugin name.
    - **SQLite**: ``BEGIN EXCLUSIVE`` (single-writer).

    Yields the locked connection for the runner to use.
    """
    lock_id = _plugin_lock_id(plugin_name)

    if dialect == "postgresql":
        async with engine.begin() as conn:
            await conn.execute(
                text(f"SET lock_timeout = '{LOCK_TIMEOUT_SECONDS}s'")
            )
            await conn.execute(text(f"SELECT pg_advisory_lock({lock_id})"))
            logger.debug(
                "Acquired advisory lock %d for plugin '%s'", lock_id, plugin_name
            )
            try:
                yield conn
            finally:
                await conn.execute(text(f"SELECT pg_advisory_unlock({lock_id})"))
                logger.debug(
                    "Released advisory lock %d for plugin '%s'",
                    lock_id,
                    plugin_name,
                )
    else:
        # SQLite: BEGIN EXCLUSIVE gives us single-writer
        async with engine.begin() as conn:
            logger.debug(
                "Acquired SQLite exclusive lock for plugin '%s'", plugin_name
            )
            yield conn
