"""PluginMigration abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mld_sdk.migrations.ops import MigrationOps


class _MigrationMeta(type(ABC)):
    """Metaclass that validates required class attributes on instantiation."""

    def __call__(cls, *args: Any, **kwargs: Any) -> Any:
        instance = super().__call__(*args, **kwargs)
        if type(instance) is not PluginMigration:
            if not isinstance(getattr(instance, "version", None), int):
                raise TypeError(
                    f"{cls.__name__} must define 'version' as an integer"
                )
            if not isinstance(getattr(instance, "name", None), str):
                raise TypeError(
                    f"{cls.__name__} must define 'name' as a string"
                )
        return instance


class PluginMigration(ABC, metaclass=_MigrationMeta):
    """Base class for plugin schema migrations.

    Subclasses must set ``version`` (int) and ``name`` (str) as class
    attributes, and implement :meth:`upgrade`.  ``downgrade`` is optional.
    """

    version: int
    name: str
    depends_on: int | None = None
    destructive: bool = False

    @abstractmethod
    async def upgrade(self, op: "MigrationOps") -> None:
        """Apply the schema change."""

    async def downgrade(self, op: "MigrationOps") -> None:
        """Reverse the schema change.  Optional — override to enable rollback."""

    @property
    def has_downgrade(self) -> bool:
        """True if the subclass overrides ``downgrade``."""
        return type(self).downgrade is not PluginMigration.downgrade

    def __repr__(self) -> str:
        return f"<Migration v{self.version:03d}_{self.name}>"
