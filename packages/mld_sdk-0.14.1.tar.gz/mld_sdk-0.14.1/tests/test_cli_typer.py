"""Tests for the Typer-based mld CLI."""

from typer.testing import CliRunner

from mld_sdk.cli import app

runner = CliRunner()


class TestCliHelp:
    def test_help_shows_platform_panel(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Platform" in result.output

    def test_help_shows_develop_panel(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Develop" in result.output

    def test_platform_before_develop_in_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        platform_pos = result.output.index("Platform")
        develop_pos = result.output.index("Develop")
        assert platform_pos < develop_pos

    def test_no_args_shows_help(self) -> None:
        result = runner.invoke(app, [])
        assert result.exit_code == 2  # Click convention for no_args_is_help
        assert "Platform" in result.output


class TestCliVersion:
    def test_version_flag(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "mld" in result.output

    def test_version_short_flag(self) -> None:
        result = runner.invoke(app, ["-V"])
        assert result.exit_code == 0
        assert "mld" in result.output


class TestSubApps:
    def test_dev_help(self) -> None:
        result = runner.invoke(app, ["dev", "--help"])
        assert result.exit_code == 0
        assert "logs" in result.output

    def test_sdk_help(self) -> None:
        result = runner.invoke(app, ["sdk", "--help"])
        assert result.exit_code == 0
        assert "link" in result.output
        assert "unlink" in result.output
        assert "update" in result.output

    def test_auth_help(self) -> None:
        result = runner.invoke(app, ["auth", "--help"])
        assert result.exit_code == 0
        assert "login" in result.output
        assert "logout" in result.output

    def test_experiment_help(self) -> None:
        result = runner.invoke(app, ["experiment", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output
        assert "get" in result.output

    def test_project_help(self) -> None:
        result = runner.invoke(app, ["project", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output
        assert "get" in result.output
