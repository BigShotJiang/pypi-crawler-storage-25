from __future__ import annotations

import pytest
import sqlalchemy as sa
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from mld_sdk.migrations.base import PluginMigration
from mld_sdk.migrations.errors import MigrationChecksumError, SchemaVersionAheadError
from mld_sdk.migrations.runner import MigrationRunner


# ── Fake migrations for testing ──────────────────────────────────


class MigrationV1(PluginMigration):
    version = 1
    name = "create_items"
    depends_on = None

    async def upgrade(self, op):
        await op.create_table(
            "items",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("name", sa.String(100)),
        )

    async def downgrade(self, op):
        await op.drop_table("items")


class MigrationV2(PluginMigration):
    version = 2
    name = "add_description"
    depends_on = 1

    async def upgrade(self, op):
        await op.add_column("items", sa.Column("description", sa.Text()))


class MigrationV3Destructive(PluginMigration):
    version = 3
    name = "remove_name"
    depends_on = 2
    destructive = True

    async def upgrade(self, op):
        await op.drop_column("items", "name")


# ── Fixtures ─────────────────────────────────────────────────────


@pytest.fixture
async def engine():
    eng = create_async_engine("sqlite+aiosqlite:///:memory:")
    yield eng
    await eng.dispose()


@pytest.fixture
def migrations_v2():
    return [MigrationV1(), MigrationV2()]


@pytest.fixture
def migrations_v3():
    return [MigrationV1(), MigrationV2(), MigrationV3Destructive()]


@pytest.fixture
def runner(engine):
    return MigrationRunner(
        engine=engine, plugin_name="test_plugin", dialect="sqlite"
    )


# ── Tests ────────────────────────────────────────────────────────


class TestDiscovery:
    def test_sort_by_version(self, runner, migrations_v3):
        ordered = runner._sort_migrations(migrations_v3[::-1])
        assert [m.version for m in ordered] == [1, 2, 3]

    def test_compute_checksum_is_stable(self, runner):
        cs1 = runner._compute_checksum(MigrationV1)
        cs2 = runner._compute_checksum(MigrationV1)
        assert cs1 == cs2
        assert len(cs1) == 64  # SHA-256 hex


class TestExecution:
    @pytest.mark.asyncio
    async def test_run_creates_tracking_table(self, runner, engine):
        await runner.run([])
        async with engine.connect() as conn:
            result = await conn.execute(
                text(
                    "SELECT 1 FROM sqlite_master WHERE name='_plugin_migrations'"
                )
            )
            assert result.scalar() is not None

    @pytest.mark.asyncio
    async def test_run_applies_all_migrations(self, runner, migrations_v2):
        result = await runner.run(migrations_v2)
        assert result.applied == [1, 2]
        assert result.current_version == 2

    @pytest.mark.asyncio
    async def test_run_creates_tables(self, runner, engine, migrations_v2):
        await runner.run(migrations_v2)
        async with engine.connect() as conn:
            res = await conn.execute(text("PRAGMA table_info(items)"))
            columns = {row[1] for row in res.fetchall()}
            assert columns == {"id", "name", "description"}

    @pytest.mark.asyncio
    async def test_run_is_idempotent(self, runner, migrations_v2):
        await runner.run(migrations_v2)
        result = await runner.run(migrations_v2)
        assert result.applied == []
        assert result.current_version == 2

    @pytest.mark.asyncio
    async def test_run_applies_only_pending(self, runner, migrations_v3):
        await runner.run(migrations_v3[:2])
        result = await runner.run(migrations_v3)
        assert result.applied == [3]


class TestVersionGuard:
    @pytest.mark.asyncio
    async def test_refuses_when_db_ahead_of_plugin(self, runner, migrations_v3):
        await runner.run(migrations_v3)
        with pytest.raises(SchemaVersionAheadError):
            await runner.run(migrations_v3[:1])


class TestChecksumValidation:
    @pytest.mark.asyncio
    async def test_detects_changed_migration(self, runner, engine, migrations_v2):
        await runner.run(migrations_v2)

        # Tamper with the stored checksum
        async with engine.begin() as conn:
            await conn.execute(
                text(
                    "UPDATE _plugin_migrations SET checksum = 'tampered' "
                    "WHERE version = 1"
                )
            )

        with pytest.raises(MigrationChecksumError):
            await runner.run(migrations_v2)


class TestFreshInstallStamp:
    @pytest.mark.asyncio
    async def test_stamps_all_when_tables_exist(self, runner, engine, migrations_v2):
        # Pre-create the table as if create_all ran
        async with engine.begin() as conn:
            await conn.execute(
                text(
                    "CREATE TABLE items ("
                    "id INTEGER PRIMARY KEY, "
                    "name VARCHAR(100), "
                    "description TEXT)"
                )
            )

        result = await runner.run(migrations_v2, tables_already_exist=True)
        assert result.stamped == [1, 2]
        assert result.applied == []
        assert result.current_version == 2


class TestFailedMigrationRetry:
    @pytest.mark.asyncio
    async def test_retries_failed_migration(self, runner, engine):
        # Insert a failed migration record
        await runner.run([])  # create tracking table
        async with engine.begin() as conn:
            await conn.execute(
                text(
                    "INSERT INTO _plugin_migrations "
                    "(plugin_name, version, name, applied_at, checksum, success, error_message) "
                    "VALUES ('test_plugin', 1, 'create_items', "
                    "datetime('now'), 'old', 0, 'previous failure')"
                )
            )

        migrations = [MigrationV1()]
        result = await runner.run(migrations)
        assert result.applied == [1]
