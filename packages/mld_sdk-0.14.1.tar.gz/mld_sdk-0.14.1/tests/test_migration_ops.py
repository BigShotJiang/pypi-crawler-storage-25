from __future__ import annotations

import pytest
import sqlalchemy as sa
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from mld_sdk.migrations.errors import DestructiveMigrationError
from mld_sdk.migrations.ops import MigrationOps


@pytest.fixture
async def engine():
    eng = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with eng.begin() as conn:
        await conn.execute(
            text(
                "CREATE TABLE users ("
                "id INTEGER PRIMARY KEY, "
                "name VARCHAR(100) NOT NULL, "
                "email VARCHAR(255))"
            )
        )
    yield eng
    await eng.dispose()


# ── Additive operations ──────────────────────────────────────────


class TestAddColumn:
    @pytest.mark.asyncio
    async def test_add_column(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.add_column("users", sa.Column("age", sa.Integer()))

        async with engine.connect() as conn:
            result = await conn.execute(text("PRAGMA table_info(users)"))
            columns = {row[1] for row in result.fetchall()}
            assert "age" in columns

    @pytest.mark.asyncio
    async def test_add_column_idempotent(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.add_column("users", sa.Column("age", sa.Integer()))
            await op.add_column("users", sa.Column("age", sa.Integer()))


class TestCreateIndex:
    @pytest.mark.asyncio
    async def test_create_index(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.create_index("ix_users_email", "users", ["email"])

        async with engine.connect() as conn:
            result = await conn.execute(text("PRAGMA index_list(users)"))
            indexes = {row[1] for row in result.fetchall()}
            assert "ix_users_email" in indexes

    @pytest.mark.asyncio
    async def test_create_index_idempotent(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.create_index("ix_users_email", "users", ["email"])
            await op.create_index("ix_users_email", "users", ["email"])


class TestCreateTable:
    @pytest.mark.asyncio
    async def test_create_table(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.create_table(
                "posts",
                sa.Column("id", sa.Integer(), primary_key=True),
                sa.Column("title", sa.String(255), nullable=False),
                sa.Column("user_id", sa.Integer()),
            )

        async with engine.connect() as conn:
            result = await conn.execute(text("PRAGMA table_info(posts)"))
            columns = {row[1] for row in result.fetchall()}
            assert columns == {"id", "title", "user_id"}

    @pytest.mark.asyncio
    async def test_create_table_idempotent(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.create_table(
                "posts", sa.Column("id", sa.Integer(), primary_key=True)
            )
            await op.create_table(
                "posts", sa.Column("id", sa.Integer(), primary_key=True)
            )


class TestBackfill:
    @pytest.mark.asyncio
    async def test_backfill_sets_null_values(self, engine):
        async with engine.begin() as conn:
            await conn.execute(text("INSERT INTO users (id, name) VALUES (1, 'Alice')"))
            await conn.execute(
                text("INSERT INTO users (id, name, email) VALUES (2, 'Bob', 'bob@test.com')")
            )

        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.backfill("users", "email", "unknown@test.com")

        async with engine.connect() as conn:
            result = await conn.execute(text("SELECT email FROM users ORDER BY id"))
            emails = [row[0] for row in result.fetchall()]
            assert emails == ["unknown@test.com", "bob@test.com"]


class TestExecute:
    @pytest.mark.asyncio
    async def test_execute_raw_statement(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.execute(text("INSERT INTO users (id, name) VALUES (99, 'raw')"))

        async with engine.connect() as conn:
            result = await conn.execute(text("SELECT name FROM users WHERE id=99"))
            assert result.scalar() == "raw"


# ── Destructive operations ───────────────────────────────────────


class TestDropColumn:
    @pytest.mark.asyncio
    async def test_drop_column_blocked_without_destructive(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            with pytest.raises(DestructiveMigrationError, match="drop_column"):
                await op.drop_column("users", "email")

    @pytest.mark.asyncio
    async def test_drop_column_works_when_destructive(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=True)
            await op.drop_column("users", "email")

        async with engine.connect() as conn:
            result = await conn.execute(text("PRAGMA table_info(users)"))
            columns = {row[1] for row in result.fetchall()}
            assert "email" not in columns
            assert "name" in columns


class TestDropTable:
    @pytest.mark.asyncio
    async def test_drop_table_blocked_without_destructive(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            with pytest.raises(DestructiveMigrationError, match="drop_table"):
                await op.drop_table("users")

    @pytest.mark.asyncio
    async def test_drop_table_works_when_destructive(self, engine):
        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=True)
            await op.drop_table("users")

        async with engine.connect() as conn:
            op2 = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            assert not await op2._table_exists("users")


class TestDropIndex:
    @pytest.mark.asyncio
    async def test_drop_index_blocked_without_destructive(self, engine):
        async with engine.begin() as conn:
            await conn.execute(text("CREATE INDEX ix_test ON users (email)"))

        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            with pytest.raises(DestructiveMigrationError):
                await op.drop_index("ix_test")

    @pytest.mark.asyncio
    async def test_drop_index_works_when_destructive(self, engine):
        async with engine.begin() as conn:
            await conn.execute(text("CREATE INDEX ix_test ON users (email)"))

        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=True)
            await op.drop_index("ix_test")

        async with engine.connect() as conn:
            op2 = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            assert not await op2._index_exists("ix_test")


class TestRenameColumn:
    @pytest.mark.asyncio
    async def test_rename_column_sqlite(self, engine):
        async with engine.begin() as conn:
            await conn.execute(
                text("INSERT INTO users (id, name, email) VALUES (1, 'A', 'a@x.com')")
            )

        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.rename_column("users", "email", "email_address")

        async with engine.connect() as conn:
            result = await conn.execute(text("PRAGMA table_info(users)"))
            columns = {row[1] for row in result.fetchall()}
            assert "email_address" in columns
            assert "email" not in columns
            result = await conn.execute(
                text("SELECT email_address FROM users WHERE id=1")
            )
            assert result.scalar() == "a@x.com"


class TestAlterColumn:
    @pytest.mark.asyncio
    async def test_alter_column_type_sqlite(self, engine):
        async with engine.begin() as conn:
            await conn.execute(
                text("INSERT INTO users (id, name, email) VALUES (1, 'A', 'a@x.com')")
            )

        async with engine.begin() as conn:
            op = MigrationOps(conn, dialect="sqlite", destructive_allowed=False)
            await op.alter_column("users", "name", sa.Text())

        async with engine.connect() as conn:
            result = await conn.execute(text("PRAGMA table_info(users)"))
            for row in result.fetchall():
                if row[1] == "name":
                    assert "TEXT" in row[2].upper()
            result = await conn.execute(text("SELECT name FROM users WHERE id=1"))
            assert result.scalar() == "A"
