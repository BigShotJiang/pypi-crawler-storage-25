`next` command improvements.

- [X] next should add to tasks.md in cwd before home
- [ ] next should have -e too, to edit task files
- [X] show diff when adding task with next
- [X] next reads stdin to add multiple tasks at once
- [X] wrap text to a maximum width when adding to the task file;
      .whatnext config and env var
- [ ] directive in a file to tell `next` where to put new tasks
