"""auto_connect: phase-based connection establishment.

Four phases run in order. The first phase to produce a viable pipe
wins; auto_connect short-circuits and returns it.

  Phase 1 -- direct_connect / reverse_connect
            Race every (plugin x af x route_type x src x dest) combo
            concurrently. 3-second total budget. LOOPBACK_BIND combos
            are eligible when both sides advertise a loopback alias
            (same-machine peers).

  Phase 2 -- tcp_punch "punch"
            NIC_BIND sub-phase first; if no NIC_BIND combos exist or
            none win, EXT_BIND. Within each sub-phase, IPv4 first then
            IPv6 (never concurrent). NICs on each side are sorted by
            info["nat"]["type"] ascending so easiest NATs pair first.
            Each parallel slot is a matching: no two attempts in a
            slot share a src NIC or a dest NIC. Slots advance only
            once every parallel attempt has finished or timed out.

  Phase 3 -- udp_punch + random_probe "spray"
            Identical scheduling to Phase 2. Both plugins race
            concurrently within each scheduled (src, dest) pair.

  Phase 4 -- turn
            Sequential, no concurrency. Up to TURN_TOTAL_CAP attempts
            in total. Prefer a fresh dest NIC each attempt; reuse one
            only when the dest side has no untried NIC left.

The `plugins=` argument filters which phases run. A phase is skipped
when none of its plugins are in the configured set.
"""
import asyncio
import ipaddress
import os
import time
from aionetiface import (
    IP4, IP6, IPRange, NIC_BIND, EXT_BIND, LOOPBACK_BIND, SUB_ALL, TCP, UDP,
    af_bitlen, fstr, log, log_exception, parse_node_addr,
)
from aionetiface.nic.nat.nat_defs import SYMMETRIC_NAT
from .node_connect import resolve_pnp_addr
from .node_protocol import (
    WG_LIVENESS_PING_PREFIX,
    WG_LIVENESS_PONG_PREFIX,
    register_liveness_pong_future,
    unregister_liveness_pong_future,
)
from .node_utils import enrich_addr_map_with_loopback
from ..traversal.traversal_utils import close_plugin
from ..traversal.strategy_registry import plugin_registry


async def verify_pipe_alive(pipe, transport=TCP, per_try_timeout=3.0, retries=3):
    """Round-trip a WG-LIVENESS-PING over *pipe* and return True iff the
    matching PONG comes back within the budget.

    Auto_connect calls this after a phase function returns a non-None
    pipe and before committing the pipe as the cascade winner.  Catches
    the "engine declared ESTABLISHED but the pipe doesn't actually
    carry bytes" failure mode -- NAT closed the mapping, OS RST'd the
    socket, multi-NIC route asymmetry, etc.

    PONG delivery uses a per-nonce future registered on the pipe
    (register_liveness_pong_future).  node_protocol peels incoming
    PONG bytes off and resolves the matching future, so PONG content
    never enters the pipe's SUB_ALL subscription queue and can't
    pollute the application's first recv() call.  This replaces an
    earlier design where verify drained SUB_ALL until it found the
    matching PONG -- duplicate PONGs from listener-side multi-broker
    fan-out remained queued and surfaced as echo_msg=b'WG-LIVENESS-...'
    in the application echo (observed on macOS and Win10).

    ``transport=TCP`` runs one PING with a ``per_try_timeout`` budget
    (TCP retransmits handle datagram loss for us).  ``transport=UDP``
    loops up to ``retries`` times, re-sending the PING with a fresh
    timeout each iteration -- a UDP datagram lost in either direction
    would otherwise false-negative this entire check on the first
    attempt.

    per_try_timeout default is 3.0s.  It was 500ms, which false-negated
    healthy tcp_punch pipes: timestamped logs measured the liveness
    PING->PONG round trip at ~490ms on a freshly punched pipe -- not
    network latency (LAN RTT is single-digit ms) but the post-punch
    busy window, where both nodes are still tearing down the 18-socket
    engine, running NAT classification, and processing MQTT signals,
    so the PING queues behind that work before node_protocol peels it.
    490ms sat right on the 500ms edge and flapped run to run.  3.0s
    clears the post-punch window with margin while still rejecting a
    genuinely dead pipe quickly enough for the cascade to fall through.

    Returns True on the first matching PONG, False on timeout or send
    error.  The caller should ``close_plugin`` the pipe and continue
    the cascade on False.
    """
    # Diagnostic bypass: WG_SKIP_VERIFY=1 makes verify always pass so
    # the cascade commits the pipe and the application echo gets a
    # chance to run.  Used to split "pipe genuinely broken" from
    # "pipe fine, liveness PING/PONG path broken" -- if the app echo
    # succeeds under the bypass, the bug is in the liveness peel /
    # per-nonce future, not the punch itself.
    if os.environ.get("WG_SKIP_VERIFY") == "1":
        log("[AC-VERIFY] WG_SKIP_VERIFY=1; skipping liveness check")
        return True

    nonce = os.urandom(8).hex().encode("ascii")
    ping = WG_LIVENESS_PING_PREFIX + nonce + b"\n"

    loop = asyncio.get_event_loop()
    pong_fut = loop.create_future()
    register_liveness_pong_future(pipe, nonce, pong_fut)
    log("[LIVENESS] mono={0:.4f} verify registered nonce={1} pipe_id={2} "
        "pipe_type={3}".format(
            time.monotonic(), nonce, id(pipe), type(pipe).__name__,
        ))

    # TCP fires one PING (TCP retransmits handle datagram loss); UDP
    # retries.  The freshly-punched-pipe warm-up race -- verify firing
    # before the worker's selector_proxy copy loop is pumping -- is
    # NOT handled here: start_punching_process now withholds the pipe
    # until the bridge signals ready (its ready socketpair), so by the
    # time verify runs the copy loop is guaranteed live.  Retrying the
    # PING on TCP only re-introduced duplicate PONGs that leaked into
    # the application recv queue, so it stays UDP-only.
    attempts = retries if transport == UDP else 1
    try:
        for attempt in range(attempts):
            try:
                await pipe.send(ping)
                log("[LIVENESS] mono={0:.4f} PING sent attempt={1}".format(
                    time.monotonic(), attempt + 1,
                ))
            except (OSError, ConnectionError, asyncio.TimeoutError) as exc:
                log(fstr(
                    "verify_pipe_alive: send failed attempt={0}/{1}: {2}: {3}",
                    (attempt + 1, attempts, type(exc).__name__,
                     str(exc) or "(no message)"),
                ))
                return False

            try:
                await asyncio.wait_for(
                    asyncio.shield(pong_fut), per_try_timeout,
                )
                return True
            except asyncio.TimeoutError:
                if pong_fut.done():
                    return True
                log("[LIVENESS] mono={0:.4f} PING attempt={1} timed out "
                    "after {2}s".format(
                        time.monotonic(), attempt + 1, per_try_timeout,
                    ))
                # Loop to next attempt (UDP) or fall through (TCP).
                continue
        return False
    finally:
        unregister_liveness_pong_future(pipe, nonce)


def plugins_for_phase(phase):
    """Return plugin names registered for a cascade phase, in registration order."""
    return tuple(c.name for c in plugin_registry if getattr(c, "phase", None) == phase)


def plugins_for_protocol(protocol):
    """Return the default plugin set for a transport.

    `protocol=TCP` -- only stream plugins.  The returned pipe has TCP semantics.
    `protocol=UDP` -- only datagram plugins.  The returned pipe has UDP semantics.
    `protocol=None` -- every cascade plugin, mixed transport.  Caller must be
                       ready to handle either pipe shape.

    Plugin classes set `transport = TCP` / `UDP` (the SOCK_STREAM /
    SOCK_DGRAM constants from aionetiface).  Compare directly against
    those enums.
    """
    if protocol not in (TCP, UDP, None):
        raise ValueError("protocol must be TCP, UDP, or None")

    out = []
    for c in plugin_registry:
        if getattr(c, "phase", None) is None:
            continue  # non-cascade helper
        if protocol is None or getattr(c, "transport", None) == protocol:
            out.append(c.name)
    return tuple(out)

PHASE1_BUDGET = 3.0
TURN_TOTAL_CAP = 3
DEFAULT_PLUGIN_TIMEOUT = 25.0
# ICE-PAC (draft-ietf-ice-pac) grace window after race_combos timeout:
# probe-lab data (arXiv:2510.27500 §6) shows ~8% of successes arrive in
# the window immediately after the local probe timeout fires.
PHASE_GRACE_S = 0.200


# ---------------------------------------------------------------------------
# Pair filtering primitives
# ---------------------------------------------------------------------------

def af_compatible(src_map, dest_map, af):
    """True if both nodes have at least one interface for this address family."""
    return bool(src_map.get(af)) and bool(dest_map.get(af))


def pair_distinct(route_type, src, dest):
    """Per-pair validity for a route type.

    NIC_BIND      different NIC IPs (otherwise bind/connect collide)
    LOOPBACK_BIND both sides advertise a loopback alias (different by
                  construction since alias is per-pubkey)
    EXT_BIND      different external IPs (otherwise connect loops
                  through the router back to the local stack)
    """
    if route_type == NIC_BIND:
        return int(src["nic"]) != int(dest["nic"])
    if route_type == LOOPBACK_BIND:
        return (
            src.get("loopback") is not None
            and dest.get("loopback") is not None
        )
    if route_type == EXT_BIND:
        return int(src["ext"]) != int(dest["ext"])
    return True


def same_lan(af, src, dest):
    """True when src and dest can reach each other on the LAN.

    Mirrors traversal_utils.select_dest_ipr's same-LAN detection so
    NIC_BIND combos are only generated for peers actually on the same
    L2 segment / same NAT. Cross-internet peers have private NIC IPs
    that aren't routable from each other -- generating NIC_BIND combos
    for them just burns the slot budget firing SYNs into RFC1918 space.

    Detection prefers the wire-encoded NIC subnet when the peer's addr
    advertises one; otherwise falls back to the v4 ext-equality
    heuristic (same NAT -> shared external IP).
    """
    src_nic_subnet = getattr(src.get("nic"), "subnet", None)
    if src_nic_subnet is not None and src_nic_subnet > 0:
        host_bits = af_bitlen(af) - src_nic_subnet
        try:
            if af == IP6 and str(src["nic"]).lower().startswith("fe80:"):
                src_net = IPRange(str(src["ext"]), bitlen=host_bits)
                return dest.get("ext") is not None and dest["ext"] in src_net
            src_net = IPRange(str(src["nic"]), bitlen=host_bits)
            in_nic = dest.get("nic") is not None and dest["nic"] in src_net
            in_ext = dest.get("ext") is not None and dest["ext"] in src_net
            return in_nic or in_ext
        except (ValueError, TypeError):
            return False
    src_ext = src.get("ext")
    dest_ext = dest.get("ext")
    return src_ext is not None and dest_ext is not None and src_ext == dest_ext


def is_same_machine(src_map, dest_map):
    """True if both addr_maps belong to the same physical host."""
    sid = src_map.get("machine_id")
    did = dest_map.get("machine_id")
    return bool(sid) and sid == did


def is_transition_v6(ip_str):
    """Return True for IPv6 transition addresses that route via IPv4 middleboxes.

    Teredo (2001:0000::/32) and 6to4 (2002::/16) look like global unicast
    but require functional relay infrastructure and fail silently when the
    relay is unreachable or the local NAT blocks the encapsulation protocol.
    Filtering them from direct-connect candidates avoids 3-30s stall
    timeouts on Vista/Win7-10 hosts that enable Teredo by default.
    """
    try:
        packed = ipaddress.ip_address(ip_str).packed
        if len(packed) != 16:
            return False
        # Teredo: 2001:0000::/32
        if packed[:4] == b"\x20\x01\x00\x00":
            return True
        # 6to4: 2002::/16
        if packed[:2] == b"\x20\x02":
            return True
    except ValueError:
        pass
    return False


def path_bound(if_info, route_type):
    """True if this route_type's bind path has a listener on this if_info.

    Per-path ports come from the node address: NIC_BIND uses nic_port,
    EXT_BIND uses ext_port. A port of 0 is the "no listener bound on
    that path" sentinel (make_node_addr / listen_on_ifs). A missing
    nic_port/ext_port key -- an older 9-field addr -- falls back to the
    shared "port" field, so legacy peers are unaffected.
    """
    if route_type == NIC_BIND:
        p = if_info.get("nic_port")
    elif route_type == EXT_BIND:
        p = if_info.get("ext_port")
    else:
        p = if_info.get("port")
    if p is None:
        p = if_info.get("port")
    return bool(p)


def viable_pairs_for_arc(
    af,
    route_type,
    src_map,
    dest_map,
):
    """Ordered (src, dest) pairs that survive per-pair filtering.

    Different-machine peers: restricted to matching-if_index pairs (alice's
    NIC0 may not have a route to bob's NIC1's subnet across NATs).

    Same-machine peers: emit the cross-product. Both nodes' NICs share one
    kernel routing table so dest["nic"] is reachable from any src NIC
    via the local stack. Matching-if_index pairs come first so direct
    in-subnet paths are tried before cross-subnet local routing.
    """
    src_af = src_map.get(af, {}) or {}
    dest_af = dest_map.get(af, {}) or {}
    if not src_af or not dest_af:
        return []

    same_machine = is_same_machine(src_map, dest_map)

    def viable(src, dest):
        if not pair_distinct(route_type, src, dest):
            return False
        # Skip a combo whose route_type path has no bound listener on
        # one side. Port 0 = "this path was not bound" (see
        # make_node_addr / listen_on_ifs per-NIC bind paths) -- e.g. a
        # NIC whose v6 fe80 failed to bind has nic_port 0, so NIC_BIND
        # to it can't work and would otherwise burn a slot.
        if not (path_bound(src, route_type) and path_bound(dest, route_type)):
            return False
        # NIC_BIND combos for cross-internet peers fire SYNs at peer's
        # private RFC1918 LAN IP, which isn't routable. Gate on same_lan
        # (or same_machine, which is implicitly same_lan) so the slot
        # budget isn't burned on combos that can't possibly converge.
        # LOOPBACK_BIND has its own same_machine semantics handled by
        # pair_distinct's loopback check; EXT_BIND is global by nature.
        if route_type == NIC_BIND and not (same_machine or same_lan(af, src, dest)):
            return False
        # Skip IPv6 transition addresses (Teredo/6to4) on EXT_BIND paths.
        # They look like global unicast but route through IPv4 relays that
        # are often unreachable or NAT-blocked, causing 3-30s stall before
        # the TCP connect times out (Vista/Win7-10 enable Teredo by default).
        if af == IP6 and route_type == EXT_BIND:
            dest_ext = dest.get("ext")
            if dest_ext is not None and is_transition_v6(str(dest_ext)):
                return False
        return True

    pairs = []
    seen = set()

    for if_idx, dest in dest_af.items():
        src = src_af.get(if_idx)
        if src is None:
            continue
        if viable(src, dest):
            seen.add((id(src), id(dest)))
            pairs.append((src, dest))

    if same_machine:
        for src in src_af.values():
            for dest in dest_af.values():
                key = (id(src), id(dest))
                if key in seen:
                    continue
                if viable(src, dest):
                    pairs.append((src, dest))

    return pairs


def plugin_supports_route_type(loader, route_type):
    """True if the plugin loader's class accepts this route_type.

    Reads ``route_types`` off the loader's plugin class
    (default: every route_type allowed).
    """
    if loader is None:
        return True
    cls = loader.get("class") if isinstance(loader, dict) else None
    if cls is None:
        return True
    supported = getattr(cls, "route_types", None)
    if supported is None:
        return True
    return route_type in supported


def plugin_timeout(loader):
    """Per-plugin declared timeout from its loader meta, with a fallback."""
    if isinstance(loader, dict):
        t = loader.get("timeout")
        if t is not None:
            return float(t)
    return DEFAULT_PLUGIN_TIMEOUT


# ---------------------------------------------------------------------------
# Attempt + race helpers
# ---------------------------------------------------------------------------

async def attempt_one_combo(
    node,
    sig_pipe,
    src_map,
    dest_map,
    combo,
):
    """Run one (plugin, af, route_type, src, dest) attempt to completion.

    For plugins whose run() returns early and resolves plugin.result
    from a background task (tcp_punch, udp_punch, random_probe via
    delayed_start_punching_proc), we need to await plugin.result
    before returning -- otherwise race_combos sees an unresolved
    plugin and treats it as a loss while the engine is still mid-
    spray. The plugin's own timeout caps the wait, so a hung plugin
    can't stall the race.
    """
    plugin_name, af, route_type, src, dest = combo
    try:
        plugin = await node.traversal.attempt_plugin(
            src_map=src_map,
            dest_map=dest_map,
            sig_pipe=sig_pipe,
            plugin_name=plugin_name,
            af=af,
            route_type=route_type,
            src=src,
            dest=dest,
        )
    except asyncio.CancelledError:  # pylint: disable=try-except-raise
        raise
    except (ValueError, OSError, ConnectionError):
        log_exception()
        return None
    if plugin is None or plugin.result.done():
        return plugin
    try:
        await asyncio.wait_for(plugin.result, timeout=plugin.timeout)
    except asyncio.TimeoutError:
        log("attempt_one_combo: plugin.result timed out for {0}".format(plugin_name))
    except asyncio.CancelledError:
        raise
    except Exception:  # pylint: disable=broad-except
        # Plugin-side failure -- race_combos sees it via plugin_pipe
        # returning None on the unresolved future.
        log_exception()
    return plugin


def plugin_pipe(plugin):
    """Return the resolved pipe from a finished plugin, or None."""
    if plugin is None:
        return None
    fut = getattr(plugin, "result", None)
    if fut is None or not fut.done():
        return None
    try:
        return fut.result()
    except Exception:  # noqa: BLE001 -- failed plugin = None pipe
        return None


async def race_combos(
    node,
    sig_pipe,
    src_map,
    dest_map,
    combos,
    timeout,
):
    """Launch combos concurrently; return (pipe, winner_plugin) or (None, None).

    First non-None pipe wins. Outstanding tasks are cancelled, then drained,
    and every losing plugin is closed via close_plugin so its sockets are
    released before the next slot.
    """
    if not combos:
        return None, None

    tasks = [
        asyncio.ensure_future(
            attempt_one_combo(node, sig_pipe, src_map, dest_map, combo)
        )
        for combo in combos
    ]

    plugins = []
    winner_pipe = None
    winner_plugin = None
    try:
        for fut in asyncio.as_completed(tasks, timeout=timeout):
            try:
                plugin = await fut
            except asyncio.CancelledError:  # pylint: disable=try-except-raise
                raise
            except (asyncio.TimeoutError, OSError, ConnectionError, ValueError):
                log_exception()
                plugin = None
            except Exception:  # noqa: BLE001 -- log unexpected, treat as loss
                log_exception()
                plugin = None
            if plugin is None:
                continue
            plugins.append(plugin)
            pipe = plugin_pipe(plugin)
            if pipe is not None:
                winner_pipe = pipe
                winner_plugin = plugin
                break
    except asyncio.TimeoutError:
        # ICE-PAC grace window (draft-ietf-ice-pac, arXiv:2510.27500 §6):
        # probe-lab data shows ~8% of successful punches arrive in the window
        # just after the local timeout fires -- the peer's spray lands while
        # our tasks are still alive but as_completed has already raised.
        # Waiting PHASE_GRACE_S lets any task that completes in that window
        # resolve as a winner before we cancel everything.
        await asyncio.sleep(PHASE_GRACE_S)
        for t in tasks:
            if not t.done():
                continue
            try:
                late_plugin = t.result()
            except Exception:  # noqa: BLE001
                continue
            if late_plugin is None:
                continue
            plugins.append(late_plugin)
            late_pipe = plugin_pipe(late_plugin)
            if late_pipe is not None and winner_pipe is None:
                winner_pipe = late_pipe
                winner_plugin = late_plugin
    except asyncio.CancelledError:
        for t in tasks:
            if not t.done():
                t.cancel()
        late = await asyncio.gather(*tasks, return_exceptions=True)
        for item in late:
            if (
                item is not None
                and not isinstance(item, BaseException)
                and item not in plugins
            ):
                plugins.append(item)
        for p in plugins:
            await close_plugin(p, node.traversal.plugins, node.traversal.inbound_pipes)
        raise

    for t in tasks:
        if not t.done():
            t.cancel()
    late = await asyncio.gather(*tasks, return_exceptions=True)
    for item in late:
        if (
            item is not None
            and not isinstance(item, BaseException)
            and item is not winner_plugin
            and item not in plugins
        ):
            plugins.append(item)

    for p in plugins:
        if p is not winner_plugin:
            await close_plugin(p, node.traversal.plugins, node.traversal.inbound_pipes)

    return winner_pipe, winner_plugin


# ---------------------------------------------------------------------------
# Bipartite slot scheduling
# ---------------------------------------------------------------------------

def sort_nics_by_nat(nics):
    """Sort NIC info dicts by ``info["nat"]["type"]`` ascending.

    NICs without a parseable nat type are placed last so they don't crowd
    out NICs with a known easy classification.
    """
    sentinel = 1 << 30

    def key(info):
        nat = info.get("nat") if isinstance(info, dict) else None
        if isinstance(nat, dict) and "type" in nat:
            try:
                return int(nat["type"])
            except (TypeError, ValueError):
                return sentinel
        return sentinel

    return sorted(nics, key=key)


def round_robin_slots(
    src_nics,
    dest_nics,
):
    """Schedule every (src, dest) pair into matching-disjoint slots.

    Yields slots; each slot is a list of (src, dest) pairs in
    which no two pairs share a src NIC or a dest NIC. Slot 0 pairs by
    sorted index ((src[0], dest[0]), (src[1], dest[1]), ...) -- so the
    easiest NATs on each side meet first when the input lists are sorted
    by nat_type. Subsequent slots rotate the dest index so every (src,
    dest) combination appears exactly once across all yielded slots.

    For ``m = len(src_nics)``, ``n = len(dest_nics)`` the schedule has
    ``max(m, n)`` slots and ``min(m, n)`` parallel pairs per slot --
    which is the minimum possible (chromatic index of K(m,n)).
    """
    m = len(src_nics)
    n = len(dest_nics)
    if m == 0 or n == 0:
        return

    if m <= n:
        for k in range(n):
            slot = []
            for i in range(m):
                j = (i + k) % n
                slot.append((src_nics[i], dest_nics[j]))
            yield slot
    else:
        for k in range(m):
            slot = []
            for j in range(n):
                i = (j + k) % m
                slot.append((src_nics[i], dest_nics[j]))
            yield slot


def derive_sorted_nics(
    pairs,
):
    """Extract unique src and dest NICs from `pairs` and sort by nat_type."""
    src_seen = {}
    dest_seen = {}
    for s, d in pairs:
        src_seen.setdefault(id(s), s)
        dest_seen.setdefault(id(d), d)
    return (
        sort_nics_by_nat(src_seen.values()),
        sort_nics_by_nat(dest_seen.values()),
    )


# ---------------------------------------------------------------------------
# Phase implementations
# ---------------------------------------------------------------------------

async def phase1_direct(
    node,
    src_map,
    dest_map,
    sig_pipe,
    plugins,
):
    """Race direct_connect / reverse_connect across all valid combos."""
    names = [n for n in plugins_for_phase("direct") if n in plugins]
    if not names:
        return None, None

    loaders = node.traversal.plugin_loaders
    combos = []
    for af in (IP4, IP6):
        if not af_compatible(src_map, dest_map, af):
            continue
        for route_type in (NIC_BIND, LOOPBACK_BIND, EXT_BIND):
            for src, dest in viable_pairs_for_arc(
                af, route_type, src_map, dest_map,
            ):
                for name in names:
                    if name not in loaders:
                        continue
                    if not plugin_supports_route_type(loaders.get(name), route_type):
                        continue
                    combos.append((name, af, route_type, src, dest))

    if not combos:
        return None, None

    log(fstr(
        "auto_connect: phase1 racing {0} combos (budget={1}s)",
        (len(combos), PHASE1_BUDGET),
    ))
    return await race_combos(
        node, sig_pipe, src_map, dest_map, combos, PHASE1_BUDGET,
    )


async def punch_phase(
    node,
    src_map,
    dest_map,
    sig_pipe,
    plugin_names,
    label,
):
    """Generic phase-2/3 driver shared by tcp_punch and udp/probe.

    NIC_BIND sub-phase first, then EXT_BIND if NIC_BIND yielded nothing.
    Within a sub-phase, IP4 first then IP6, never concurrent. Per AF a
    bipartite schedule (sorted by nat_type) drives parallel attempts in
    each slot. plugin_names supplies the plugins raced concurrently
    against each scheduled (src, dest) pair.
    """
    loaders = node.traversal.plugin_loaders
    names = [n for n in plugin_names if n in loaders]
    if not names:
        return None, None

    for route_type in (NIC_BIND, EXT_BIND):
        active_names = [
            n for n in names
            if plugin_supports_route_type(loaders.get(n), route_type)
        ]
        if not active_names:
            continue

        slot_to = max(
            (plugin_timeout(loaders.get(n)) for n in active_names),
            default=DEFAULT_PLUGIN_TIMEOUT,
        )

        for af in (IP4, IP6):
            if not af_compatible(src_map, dest_map, af):
                continue
            pairs = viable_pairs_for_arc(af, route_type, src_map, dest_map)
            if not pairs:
                continue

            src_nics, dest_nics = derive_sorted_nics(pairs)
            allowed = {(id(s), id(d)) for s, d in pairs}

            for slot_idx, slot in enumerate(round_robin_slots(src_nics, dest_nics)):
                # Drop pairs the route_type filter rejected (e.g. equal
                # NIC IPs under NIC_BIND on same-machine cross-products).
                slot = [(s, d) for s, d in slot if (id(s), id(d)) in allowed]
                if not slot:
                    continue

                combos = []
                for src, dest in slot:
                    pair_sym = pair_has_symmetric(src, dest)
                    for name in active_names:
                        if pair_sym and name in SYMMETRIC_INCOMPATIBLE_PLUGINS:
                            # Predictable-port punch plugins can't work
                            # when either end of THIS specific pair is
                            # behind a symmetric NAT -- the bucket math
                            # has no fixed peer port to target. Other
                            # pairs in this slot may still be punchable
                            # so we filter at the combo level, not the
                            # phase level.
                            continue
                        combos.append(
                            (name, af, route_type, src, dest)
                        )
                if not combos:
                    continue

                log(fstr(
                    "auto_connect: {0} route={1} af={2} slot={3} pairs={4} timeout={5}s",
                    (label, route_type, af, slot_idx, len(slot), slot_to),
                ))
                pipe, plugin = await race_combos(
                    node, sig_pipe, src_map, dest_map, combos, slot_to,
                )
                if pipe is not None:
                    return pipe, plugin

    return None, None


def addr_map_has_symmetric(addr_map):
    """True if any (af, nic) entry in addr_map has NAT type SYMMETRIC.

    Kept for tests / external callers; the cascade now filters
    per-pair via pair_has_symmetric in punch_phase.
    """
    for af in (IP4, IP6):
        for entry in (addr_map.get(af) or {}).values():
            nat = entry.get("nat") or {}
            if nat.get("type") == SYMMETRIC_NAT:
                return True
    return False


def pair_has_symmetric(src, dest):
    """True if either end of this specific (src, dest) NIC pair is symmetric."""
    src_nat = (src.get("nat") or {}).get("type")
    dest_nat = (dest.get("nat") or {}).get("type")
    return src_nat == SYMMETRIC_NAT or dest_nat == SYMMETRIC_NAT


# Plugins whose port-prediction math (boundary_port_alloc) requires
# a deterministic NAT mapping function on both sides. Excluded from
# pairs where either NIC reports SYMMETRIC NAT. random_probe is
# specifically designed to handle the symmetric case via birthday-
# paradox spread, so it is NOT in this set.
SYMMETRIC_INCOMPATIBLE_PLUGINS = frozenset({"tcp_punch", "udp_punch"})


async def phase2_tcp_punch(
    node,
    src_map,
    dest_map,
    sig_pipe,
    plugins,
):
    names = tuple(n for n in plugins_for_phase("punch") if n in plugins)
    if not names:
        return None, None
    # Skip tcp_punch entirely when either peer is behind a SYMMETRIC
    # NAT. The plugin's port-prediction math (boundary_port_alloc) is
    # built on EIM/EDM/preserving NAT behaviour where the next outbound
    # source-port is predictable. Symmetric NATs assign a fresh
    # external port per (src,dst) tuple, so the predicted ports never
    # match the peer's actual mappings -- every spray returns
    # successful=0/N. Without this skip, phase2 burns its full plugin
    # timeout (5 s per slot) on a punch that's mathematically
    # impossible.
    # Going straight to phase3 (where random_probe handles symmetric)
    # is strictly faster with no loss in success.
    # Symmetric-NAT skipping is now per-pair inside punch_phase via
    # the SYMMETRIC_INCOMPATIBLE filter, not a coarse addr_map check.
    # The coarse check was over-broad: hosts with multiple NICs (e.g.
    # a primary FULL_CONE LAN NIC and a secondary SYMMETRIC mobile
    # NIC) would have phase2 skipped entirely even though the
    # FULL_CONE-FULL_CONE pair could punch fine. Per-pair filtering
    # keeps the impossible (sym, *) and (*, sym) pairs out of the
    # combo list while preserving viable LAN-LAN and EXT-EXT combos.
    # Windows-XP / Windows-2000 are NOT special-cased here any more.
    # Previously an XP/2000 connector cross-machine was routed to
    # tcp_punch_pcap or, if pcap wasn't installed, had phase2 skipped
    # outright -- on the assumption legacy tcp_punch would always hit
    # XP's tcpip.sys simul-open RST and waste the plugin timeout.
    # XP is now allowed through the normal tcp_punch path
    # like every other OS; if a given XP pair genuinely can't punch,
    # the cascade falls through to phase3/phase4 on its own.
    names = tuple(n for n in names if n != "tcp_punch_pcap")
    return await punch_phase(
        node, src_map, dest_map, sig_pipe,
        plugin_names=names,
        label="phase2",
    )


async def phase3_udp_probe(
    node,
    src_map,
    dest_map,
    sig_pipe,
    plugins,
):
    names = tuple(n for n in plugins_for_phase("spray") if n in plugins)
    if not names:
        return None, None

    # The "never run two punches against the same dest concurrently"
    # rule applies here too: udp_punch and random_probe both fire UDP
    # sprays from the same NIC at the same dest, so racing them in
    # parallel causes (a) bind contention on local ephemeral ports
    # (random_probe takes 256, udp_punch tries 16 boundary buckets),
    # (b) recv-buffer pressure on the peer's NIC, and (c) extra
    # cross-magic frames each plugin's filter has to discard. Pick
    # one based on NAT shape: random_probe is the only plugin that
    # works when either peer is symmetric, so use it then; otherwise
    # udp_punch is the predictable-NAT optimised path.
    if addr_map_has_symmetric(src_map) or addr_map_has_symmetric(dest_map):
        chosen = "random_probe" if "random_probe" in names else names[0]
    else:
        chosen = "udp_punch" if "udp_punch" in names else names[0]
    log("phase3_udp_probe: chose plugin={0} from {1}".format(chosen, names))
    return await punch_phase(
        node, src_map, dest_map, sig_pipe,
        plugin_names=(chosen,),
        label="phase3",
    )


async def phase4_turn(
    node,
    src_map,
    dest_map,
    sig_pipe,
    plugins,
    cap=TURN_TOTAL_CAP,
):
    """Sequential TURN attempts, cap total attempts.

    Iterate AFs (IP4 then IP6). For each AF, walk our NICs in nat_type
    order. Pick the first dest NIC with which we form a valid
    EXT_BIND pair and that we haven't paired with yet. Fall back to a
    previously-used dest NIC only if every fresh option is invalid.
    Stop as soon as we hit `cap` total attempts.
    """
    relay_names = [n for n in plugins_for_phase("relay") if n in plugins]
    if not relay_names:
        return None, None
    # Phase 4 is single-plugin sequential. If multiple relay plugins
    # exist in the registry they'd need a different scheduler; for now
    # pick the first registered one.
    relay_name = relay_names[0]
    if relay_name not in node.traversal.plugin_loaders:
        return None, None
    loader = node.traversal.plugin_loaders[relay_name]
    if not plugin_supports_route_type(loader, EXT_BIND):
        return None, None

    timeout = plugin_timeout(loader)
    attempts = 0

    for af in (IP4, IP6):
        if attempts >= cap:
            break
        if not af_compatible(src_map, dest_map, af):
            continue
        pairs = viable_pairs_for_arc(af, EXT_BIND, src_map, dest_map)
        if not pairs:
            continue

        src_nics, dest_nics = derive_sorted_nics(pairs)
        allowed = {(id(s), id(d)) for s, d in pairs}
        used_dests = set()

        for src in src_nics:
            if attempts >= cap:
                break

            chosen = None
            for dest in dest_nics:
                if id(dest) in used_dests:
                    continue
                if (id(src), id(dest)) in allowed:
                    chosen = dest
                    break
            if chosen is None:
                for dest in dest_nics:
                    if (id(src), id(dest)) in allowed:
                        chosen = dest
                        break
            if chosen is None:
                continue

            used_dests.add(id(chosen))
            attempts += 1
            log(fstr(
                "auto_connect: phase4 turn af={0} attempt={1}/{2}",
                (af, attempts, cap),
            ))
            pipe, plugin = await race_combos(
                node, sig_pipe, src_map, dest_map,
                [(relay_name, af, EXT_BIND, src, chosen)],
                timeout,
            )
            if pipe is not None:
                return pipe, plugin

    return None, None


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

async def auto_connect(
    node,
    dest_addr,
    protocol=TCP,
    plugins=None,
    test_all_phases=False,
    afs=None,
):
    """Establish a P2P connection to dest_addr without picking a plugin.

    `protocol` controls which transport the returned pipe will use. Default
    is TCP so callers can rely on stream semantics without thinking about
    which plugin won. Pass `protocol=UDP` for a datagram pipe, or
    `protocol=None` to allow any plugin (mixed-transport caller — be ready
    to handle either pipe shape).

    `plugins` is the power-user override: pass an explicit sequence of
    plugin names and the protocol filter is bypassed. A phase whose
    plugins are all absent from the resolved set is skipped entirely.

    `test_all_phases=True` is a diagnostic mode: every phase runs even
    after an earlier one already produced a pipe. Each phase's outcome
    is logged with an [AC-PHASE] prefix so you can grep cumulative
    behaviour (e.g. punch failing after direct's TIME_WAIT residue).
    The first winning pipe is what gets returned to the caller; later
    phases run for telemetry and any pipes they produce are closed
    via close_plugin so they don't leak.

    `afs` (default None = both IP4 and IP6) restricts the phases to
    the given iterable of address families. Pass ``[IP6]`` to test
    only the v6 path -- the v4 entries are stripped from src_map /
    dest_map before any phase runs, so af_compatible() naturally
    short-circuits the v4 branches inside each phase.

    Returns ``(pipe, plugin)`` on success, ``(None, None)`` on failure.
    """
    if plugins is None:
        plugins = plugins_for_protocol(protocol)
    plugin_set = frozenset(plugins)

    try:
        addr_bytes, dest_vk, _ = await resolve_pnp_addr(node, dest_addr)
        dest_map = parse_node_addr(addr_bytes)
    except (ValueError, OSError, ConnectionError, asyncio.TimeoutError):
        log_exception()
        return None, None
    if dest_vk:
        dest_map["vk"] = dest_vk

    enrich_addr_map_with_loopback(dest_map)

    try:
        sig_pipe = await node.router.pipe(
            dest_map["pub_key_hex"],
            use_cache=True,
            hint_brokers=dest_map.get("mqtt_brokers") or [],
        )
    except (OSError, ConnectionError, asyncio.TimeoutError):
        log_exception()
        return None, None

    src_map = node.addr_map

    if afs is not None:
        # Diagnostic / power-user override: pin the cascade to a
        # specific AF or AF set by stripping the others off the addr
        # maps. Phase loops iterate (IP4, IP6) and call
        # af_compatible(src_map, dest_map, af) which returns False
        # when one side is empty -- so a v6-only run produces only
        # v6 combos and the v4 branches are no-ops.
        keep = set(afs)
        src_map = {k: v for k, v in src_map.items() if k not in (IP4, IP6) or k in keep}
        dest_map = {k: v for k, v in dest_map.items() if k not in (IP4, IP6) or k in keep}

    def worst_nat(addr_map):
        """Return the highest NAT type integer across all AFs in addr_map, or None."""
        worst = None
        for af in (IP4, IP6):
            for entry in (addr_map.get(af) or {}).values():
                nat_type = (entry.get("nat") or {}).get("type")
                try:
                    v = int(nat_type)
                    if worst is None or v > worst:
                        worst = v
                except (TypeError, ValueError):
                    pass
        return worst

    def is_cgnat_external(addr_map):
        """Return True if any external IP in addr_map is a CGNAT/RFC-6598 address.

        RFC 6598 (100.64.0.0/10) is IANA shared address space allocated for
        carrier-grade NAT.  An external IP in this range means the peer is
        behind at least two NAT hops.  RFC 1918 in the external slot means a
        private UPnP or CGNAT mapping that never reached a public address.
        """
        cgnat_net = ipaddress.ip_network(u"100.64.0.0/10")
        private_nets = [
            ipaddress.ip_network(u"10.0.0.0/8"),
            ipaddress.ip_network(u"172.16.0.0/12"),
            ipaddress.ip_network(u"192.168.0.0/16"),
        ]
        for af in (IP4, IP6):
            for entry in (addr_map.get(af) or {}).values():
                ext = entry.get("ext")
                if not ext:
                    continue
                try:
                    addr = ipaddress.ip_address(str(ext))
                    if addr.version != 4:
                        continue
                    if addr in cgnat_net:
                        return True
                    for net in private_nets:
                        if addr in net:
                            return True
                except (ValueError, TypeError):
                    pass
        return False

    winner_pipe = None
    winner_plugin = None

    if test_all_phases:
        for phase_fn in (
            phase1_direct,
            phase2_tcp_punch,
            phase3_udp_probe,
            phase4_turn,
        ):
            phase_t0 = time.monotonic()
            # test_all_phases runs every phase for measurement even
            # after one has won. A later phase raising must NOT abort
            # the loop and discard an earlier phase's winner_pipe -- it
            # is only bonus measurement at that point. Treat any phase
            # error as "no pipe" and carry on. A CancelledError with no
            # winner yet is a genuine teardown and is re-raised.
            try:
                pipe, plugin = await phase_fn(
                    node, src_map, dest_map, sig_pipe, plugin_set,
                )
            except asyncio.CancelledError:
                if winner_pipe is None:
                    raise
                log(fstr(
                    "[AC-PHASE] {0} cancelled; keeping earlier winner",
                    (phase_fn.__name__,),
                ))
                pipe, plugin = None, None
            except Exception:  # pylint: disable=broad-except
                log_exception()
                log(fstr(
                    "[AC-PHASE] {0} raised; treating as no-pipe",
                    (phase_fn.__name__,),
                ))
                pipe, plugin = None, None
            elapsed_ms = int((time.monotonic() - phase_t0) * 1000)
            src_nat = worst_nat(src_map)
            dest_nat = worst_nat(dest_map)
            src_cgnat = is_cgnat_external(src_map)
            dest_cgnat = is_cgnat_external(dest_map)
            line = "[AC-PHASE] {0} -> pipe={1} plugin={2} src_nat={3} dest_nat={4} elapsed={5}ms src_cgnat={6} dest_cgnat={7}".format(
                phase_fn.__name__,
                pipe is not None,
                getattr(plugin, "name", type(plugin).__name__) if plugin is not None else None,
                src_nat,
                dest_nat,
                elapsed_ms,
                src_cgnat,
                dest_cgnat,
            )
            log(line)
            print(line, flush=True)
            tel = getattr(node, "telemetry", None)
            if tel is not None:
                try:
                    tel.record(
                        phase_fn.__name__,
                        getattr(plugin, "name", None) if plugin is not None else None,
                        pipe is not None,
                        elapsed_ms,
                        src_nat,
                        dest_nat,
                    )
                except Exception:
                    pass
            if pipe is not None and winner_pipe is None:
                # Liveness verify: punch engines occasionally declare
                # ESTABLISHED for a pipe that the kernel then tears
                # down before app bytes can flow (multi-NIC routing
                # asymmetry, NAT mapping closing on the spray's
                # trailing SYNs, XP-style 174ms post-handshake RST,
                # etc).  Round-trip a PING and fall through to the
                # next phase if no PONG comes back.
                transport = getattr(plugin, "transport", TCP)
                alive = await verify_pipe_alive(pipe, transport=transport)
                if not alive:
                    log("[AC-VERIFY] {0} pipe failed liveness ping; closing and continuing".format(
                        phase_fn.__name__,
                    ))
                    try:
                        await close_plugin(
                            plugin, node.traversal.plugins, node.traversal.inbound_pipes,
                        )
                    except (OSError, asyncio.TimeoutError):
                        log_exception()
                else:
                    winner_pipe = pipe
                    winner_plugin = plugin
            elif pipe is not None:
                try:
                    await close_plugin(
                        plugin, node.traversal.plugins, node.traversal.inbound_pipes,
                    )
                except (OSError, asyncio.TimeoutError):
                    log_exception()
        return winner_pipe, winner_plugin

    # Strict-serial cascade.  Run each phase to completion before
    # starting the next.  The previous design (Happy Eyeballs 1.5 s
    # interleave) ran phases concurrently for a small latency win on
    # cases that needed multiple phases, but the combined flow rate
    # from one host was bad enough to:
    #   - exceed the XP 10-half-open SYN cap (Tcpip Event 4226) when
    #     tcp_punch's spray overlapped with anything else
    #   - exceed the consumer-router ~256 v6-flow cap when udp_punch's
    #     256-socket spray overlapped tcp_punch's SYNs and TURN traffic
    #   - look indistinguishable from a port-scan / attack to common
    #     "port scan" heuristics on enterprise / hotel / dorm networks
    #     (~150 distinct dest tuples in a burst triggers filter-out)
    #   - confuse attribution: when a pipe lands during overlap, we
    #     can't tell which plugin's spray actually opened the path
    #   - silently diverge from test behaviour: test_all_phases=True
    #     (what gate_sweep uses) ran phases serially, so we tested one
    #     mode and shipped a different one.
    # Strict serialisation costs latency on the rare path that needs
    # all four phases (worst case = sum of phase budgets), but every
    # plugin gets a clean stage with no concurrent flow pressure.
    phase_fns = (phase1_direct, phase2_tcp_punch, phase3_udp_probe, phase4_turn)
    for phase_fn in phase_fns:
        pipe, plugin = await phase_fn(
            node, src_map, dest_map, sig_pipe, plugin_set,
        )
        if pipe is not None:
            # Same liveness check as the test_all_phases path above:
            # only accept the pipe as the cascade winner if a PING
            # actually round-trips through it.  Catches the "engine
            # reported ESTABLISHED but the OS / NAT then RST'd the
            # connection" failure mode.  On failure, close the
            # plugin and let the next phase have a shot.
            transport = getattr(plugin, "transport", TCP)
            alive = await verify_pipe_alive(pipe, transport=transport)
            if alive:
                winner_pipe = pipe
                winner_plugin = plugin
                break
            log("[AC-VERIFY] {0} pipe failed liveness ping; closing and continuing".format(
                phase_fn.__name__,
            ))
            try:
                await close_plugin(
                    plugin, node.traversal.plugins, node.traversal.inbound_pipes,
                )
            except (OSError, asyncio.TimeoutError):
                log_exception()

    return winner_pipe, winner_plugin
