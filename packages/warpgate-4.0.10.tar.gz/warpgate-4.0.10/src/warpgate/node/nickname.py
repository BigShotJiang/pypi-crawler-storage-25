"""
Prefer IPv6 as it will potentially have fewer bumping from dynamic swapping across a shared IPv4 if there's
multiple ifaces; Otherwise use what we've got

python3 run_pnp_serv.py
"""
import asyncio
import time
from aionetiface import (
    to_s, to_b, fstr, log, log_exception, h_to_b,
    DUEL_STACK, IP4, IP6, PNP_SERVERS, VALID_AFS,
    strip_none, async_wrap_errors, SigningKey,
)
import namebump
from ..errors import StartNodeNicknameFailed


# Timestamp envelope for PNP record values. Wraps the payload with a
# magic prefix + 8-byte big-endian unix timestamp so peers can detect
# stale records (e.g. node that died, public-key got rotated, dest
# behind a partition that hasn't refreshed its put). Records written
# before this envelope existed don't have the prefix and are treated
# as ts=0 ("indefinitely old") so the staleness filter only flags
# them when a min_fresh_secs is requested.
PNP_TS_MAGIC = b"PNP1"
PNP_TS_HEADER_LEN = 12  # 4 magic + 8 timestamp


def pnp_wrap_with_ts(value, ts=None):
    """Prefix value with a timestamp envelope for staleness detection."""
    if ts is None:
        ts = int(time.time())
    return PNP_TS_MAGIC + ts.to_bytes(8, "big") + to_b(value)


def pnp_unwrap_ts(value):
    """Split a (possibly wrapped) PNP value into (timestamp, payload).

    Returns (0, value) if the value isn't in the wrapped format -- this
    keeps callers backwards-compatible with records that pre-date the
    envelope. ts=0 means "unknown / treat as very old"; only records
    with a ts > 0 survive a non-zero min_fresh_secs filter.
    """
    if not isinstance(value, (bytes, bytearray)):
        return 0, value
    if len(value) < PNP_TS_HEADER_LEN or bytes(value[:4]) != PNP_TS_MAGIC:
        return 0, value
    ts = int.from_bytes(bytes(value[4:12]), "big")
    return ts, bytes(value[12:])

PNP_INDEX_TO_TLD = {
    frozenset([0]): ".p2p",
    frozenset([1]): ".node",
    frozenset([0, 1]): ".peer",
}

PNP_TLD_TO_INDEX = {
    ".p2p": frozenset([0]),
    ".node": frozenset([1]),
    ".peer": frozenset([0, 1]),
}


def pnp_get_tld(offsets):
    """Return the PNP TLD string (e.g. '.peer') corresponding to the given server index list."""
    index = frozenset(offsets)
    return PNP_INDEX_TO_TLD[index]


def pnp_get_offsets(tld):
    """Return the list of PNP server offsets that must hold a record for the given TLD."""
    index = PNP_TLD_TO_INDEX[tld]
    return list(index)


def pnp_strip_tlds(name):
    """Strip any known PNP TLD suffix from name and return the bare label."""
    name = to_s(name)
    for tld in PNP_TLD_TO_INDEX:
        # Grab the last len(tld) characters in name.
        # Underflows will grab everything.
        portion = name[-len(tld) :]

        # TLD found so strip it.
        # Underflows set the str to "" empty.
        if portion == tld:
            name = name[: -len(tld)]
            break

    return name


def pnp_name_has_tld(name):
    """Return True if name ends with a recognised PNP TLD suffix."""
    name = to_s(name)
    for tld in PNP_TLD_TO_INDEX:
        portion = name[-len(tld) :]
        if portion == tld:
            return True

    return False


NAMING_TIMEOUT = 10
# Note: per-server retry now lives inside namebump.Client (with_retry).
# Each call to client.put / get / delete already retries DEFAULT_RETRIES
# times on transient network errors before propagating the exception.
# Nickname methods therefore do not need their own retry loop; the
# NAMING_TIMEOUT bound here applies across all of namebump's retries.


class PartialNameSuccess(Exception):
    """Raised when a nickname was registered on some but not all PNP servers."""


class FullNameFailure(Exception):
    """Raised when a nickname registration failed on all PNP servers."""


class PnpServerUnreachable(Exception):
    """Raised when one or more configured PNP servers could not be
    reached during start(), name-collision check, or strict put.
    Strict registration requires every configured server to be
    reachable so the all-or-fail contract is meaningful."""


class PnpServerResourceLimit(Exception):
    """Raised when at least one PNP server rejected the put with a
    ResourceLimit signal -- typically the per-source-IP name quota
    has been hit.  Distinguished from generic FullNameFailure so
    callers can surface a more actionable error to the user."""


class Nickname:
    """Manages PNP nickname registration and lookup for a P2P node."""

    def __init__(self, sk, ifs, sys_clock):
        self.sk = sk
        self.ifs = ifs
        self.sys_clock = sys_clock

        # Select best NIC from if list to be primary NIC.
        for preferred_stack in [DUEL_STACK, IP4, IP6]:
            break_all = False
            for nic in self.ifs:
                if nic.stack == preferred_stack:
                    self.interface = nic
                    break_all = True
                    break

            if break_all:
                break

        self.clients = {IP4: {}, IP6: {}}
        self.started = False

    async def start(self, timeout=2):
        """Connect to all reachable PNP servers and mark the client as started."""
        tasks = []

        for index in range(len(PNP_SERVERS[IP4])):
            for af in [IP4, IP6]:
                if af not in self.interface.supported():
                    self.clients[af][index] = None
                    continue

                serv_info = PNP_SERVERS[af][index]
                dest = (serv_info["ip"], serv_info["port"])
                client = namebump.Client(
                    dest,
                    h_to_b(serv_info["pk"]),
                    sys_clock=self.sys_clock,
                    nic=self.interface,
                )
                client.kp = namebump.Keypair(self.sk)

                async def job(af=af, index=index, client=client):
                    """Start the namebump client and verify connectivity, returning (af, index, client)."""
                    pipe = None
                    try:
                        await client.start()
                        pipe = await asyncio.wait_for(
                            client.get_dest_pipe(), timeout=timeout
                        )
                        if pipe is None:
                            return (af, index, None)
                    except (OSError, ConnectionError, asyncio.TimeoutError):
                        log_exception()
                        return (af, index, None)
                    finally:
                        if pipe is not None:
                            await pipe.close()
                    return (af, index, client)

                tasks.append(asyncio.create_task(job()))

        results = await asyncio.gather(*tasks, return_exceptions=False)

        for af, index, client in results:
            self.clients[af][index] = client

        # Strict reachability: every configured offset must have at
        # least one working AF client.  An offset with all-None clients
        # means we have no path to that PNP server, so the strict
        # all-or-fail put contract can't be enforced -- bail now rather
        # than let the first put() collide with an unverified server.
        unreachable = []
        for offset in range(len(PNP_SERVERS[IP4])):
            if all(self.clients[af].get(offset) is None for af in [IP4, IP6]):
                unreachable.append(offset)
        if unreachable:
            raise PnpServerUnreachable(fstr(
                "PNP server offsets unreachable: {0}", (unreachable,),
            ))

        self.started = True
        return self

    async def put(
        self,
        name,
        value,
        behavior=namebump.DO_BUMP,
        timeout=NAMING_TIMEOUT,
    ):
        """Store value under name on every PNP server (strict all-or-fail).

        Raises if any server fails to write.  The TLD of the returned
        name is determined by the configured server list.

        The stored bytes are wrapped with a timestamp envelope (magic
        prefix + unix ts) so readers can filter by staleness via
        Nickname.get(min_fresh_secs=...).  Callers pass the raw
        payload (e.g. addr_bytes); the envelope is added here.
        """
        if not self.started:
            raise AssertionError("Nickname client not started. Call start() first.")
        name = pnp_strip_tlds(name)
        log(fstr("Nickname.put: name={0} timeout={1}", (name, timeout)))

        # Wrap the value with the freshness envelope. The timestamp
        # written here is what Nickname.get(min_fresh_secs=...) checks
        # against -- a writer with a wildly skewed clock would produce
        # records that look "from the future" or "indefinitely old"
        # depending on direction. The matrix VMs have NTP-aligned
        # clocks so this isn't a concern in practice; for hosts
        # without working NTP the staleness filter degrades to "treat
        # all wrapped records as fresh" which is the same as the
        # legacy unwrapped behaviour.
        wrapped_value = pnp_wrap_with_ts(value)

        # Captured by per-offset workers so the post-gather check can
        # surface ResourceLimit (per-IP name quota) as a typed
        # exception distinct from generic FullNameFailure.
        rejections = []

        # Single coro for storing at one server. namebump.Client.put
        # retries internally on transient network errors, so this worker
        # only needs to walk the AFs and surface any non-network failure.
        async def worker(offset):
            """Attempt to store the name on the PNP server at offset and return offset on success."""
            import time as _time
            for af in VALID_AFS:
                t0 = _time.time()
                try:
                    client = self.clients[af][offset]
                    if client is None:
                        log(fstr(
                            "Nickname.put: offset={0} af={1} client=None (skip)",
                            (offset, af),
                        ))
                        continue
                    log(fstr(
                        "Nickname.put: offset={0} af={1} -> client.put",
                        (offset, af),
                    ))
                    ret = await client.put(name, wrapped_value, client.kp, behavior)
                    dt = int((_time.time() - t0) * 1000)
                    if ret is None:
                        log(fstr(
                            "Nickname.put: offset={0} af={1} ret=None elapsed_ms={2} (continue)",
                            (offset, af, dt),
                        ))
                        continue
                    if ret.value is not None:
                        log(fstr(
                            "Nickname.put: offset={0} af={1} success elapsed_ms={2}",
                            (offset, af, dt),
                        ))
                        return offset
                    log(fstr(
                        "Nickname.put: offset={0} af={1} value=None elapsed_ms={2} (server rejected)",
                        (offset, af, dt),
                    ))
                except namebump.PutRejected as exc:
                    log(fstr(
                        "Nickname.put: offset={0} af={1} ResourceLimit: {2}",
                        (offset, af, str(exc)),
                    ))
                    rejections.append((offset, af, str(exc)))
                    # Fall through to the next AF.  v6 has its own
                    # per-IP quota row on the server (V6_NAME_LIMIT)
                    # entirely separate from v4's, so a v4 quota
                    # rejection doesn't preclude a v6 put succeeding.
                    # Previously we returned None here and v6's quota
                    # went forever unused.
                    continue
                except (OSError, ConnectionError, asyncio.TimeoutError):
                    log_exception()
                    log(fstr(
                        "Nickname.put: offset={0} af={1} network error elapsed_ms={2}",
                        (offset, af, int((_time.time() - t0) * 1000)),
                    ))
            return None

        # Schedule store tasks at all PNP servers.
        tasks = []
        for offset in range(0, len(self.clients[IP4])):
            tasks.append(
                async_wrap_errors(
                    worker(offset),
                    timeout,
                )
            )

        # Attempt storage at all PNP servers.
        log(fstr("Nickname.put: gathering {0} workers", (len(tasks),)))
        results = await asyncio.gather(*tasks)
        log(fstr("Nickname.put: gather done, results={0}", (results,)))
        success_offsets = set(strip_none(results))
        expected_offsets = set(range(len(self.clients[IP4])))
        missing = sorted(expected_offsets - success_offsets)
        if missing:
            if rejections:
                raise PnpServerResourceLimit(fstr(
                    "Nickname.put: PNP server quota exhausted: {0}",
                    (rejections,),
                ))
            raise FullNameFailure(fstr(
                "Nickname.put: strict-all-or-fail: missing offsets {0}; "
                "succeeded={1}",
                (missing, sorted(success_offsets)),
            ))

        # All offsets succeeded.  TLD is fully determined by the
        # configured server list.
        tld = pnp_get_tld(sorted(expected_offsets))
        return fstr("{0}{1}", (name, tld))

    async def get(
        self,
        name,
        timeout=NAMING_TIMEOUT,
        min_fresh_secs=0,
        wait_for_fresh=False,
        max_wait_secs=30,
        retry_interval=2.0,
    ):
        """Look up name on the authoritative PNP servers and return the first successful result.

        min_fresh_secs > 0 enables staleness filtering. The stored
        record's timestamp must be within (now - min_fresh_secs)
        seconds for the result to be returned; older records are
        skipped and the next server / next iteration is tried.
        Records written without the freshness envelope (legacy data
        that pre-dates pnp_wrap_with_ts) report ts=0 and pass through
        the filter only when min_fresh_secs == 0.

        wait_for_fresh=True changes the behaviour when min_fresh_secs > 0
        and no fresh-enough record is found on the first sweep: instead
        of raising FullNameFailure immediately, sleep retry_interval
        seconds and try again, repeating until either a fresh record
        is observed or max_wait_secs has elapsed. This is useful for
        peers waiting on a node-rotation / publication-propagation
        race where the writer's put() may not yet have reached every
        PNP server. The PNP timestamp envelope makes the freshness
        check authoritative across servers (no clock-of-the-reader
        confusion).

        On a successful return, ret.value is the unwrapped payload
        (envelope stripped) and ret.pnp_ts is set to the record's
        timestamp (0 for legacy records).
        """
        if not self.started:
            raise AssertionError("Nickname client not started. Call start() first.")

        async def worker(offset, name):
            """Query the PNP server at offset for name and return the first non-None record."""
            import time as _time
            for af in VALID_AFS:
                t0 = _time.time()
                try:
                    client = self.clients[af][offset]
                    if client is None:
                        log(fstr(
                            "Nickname.get: offset={0} af={1} client=None (skip)",
                            (offset, af),
                        ))
                        continue
                    log(fstr(
                        "Nickname.get: offset={0} af={1} -> client.get",
                        (offset, af),
                    ))
                    ret = await client.get(name)
                    dt = _time.time() - t0
                    has_val = ret is not None and ret.value is not None
                    log(fstr(
                        "Nickname.get: offset={0} af={1} ret_value_present={2} elapsed_ms={3}",
                        (offset, af, has_val, int(dt * 1000)),
                    ))
                    if ret is not None:
                        # Unwrap freshness envelope. Legacy unwrapped
                        # records report ts=0; ret.value is replaced
                        # with the bare payload either way so callers
                        # don't see the envelope bytes.
                        if ret.value is not None:
                            ts, payload = pnp_unwrap_ts(ret.value)
                            ret.value = payload
                            ret.pnp_ts = ts
                            if min_fresh_secs > 0:
                                age = int(_time.time()) - ts if ts else None
                                if ts == 0 or age > min_fresh_secs:
                                    log(fstr(
                                        "Nickname.get: offset={0} af={1} stale "
                                        "ts={2} age={3}s threshold={4}s "
                                        "(skipping)",
                                        (offset, af, ts, age, min_fresh_secs),
                                    ))
                                    continue
                        else:
                            ret.pnp_ts = 0
                        return ret
                except asyncio.CancelledError:  # pylint: disable=try-except-raise
                    raise
                except (OSError, ConnectionError, asyncio.TimeoutError):
                    log_exception()
                    log(fstr(
                        "Nickname.get: offset={0} af={1} network error elapsed_ms={2}",
                        (offset, af, int((_time.time() - t0) * 1000)),
                    ))

        # Convert TLD to client offset list.
        tld = "." + name.split(".")[-1]
        offsets = pnp_get_offsets(tld)
        name = name[: -len(tld)]

        async def one_sweep():
            """Fan out one round of PNP queries and return the first
            non-None result, or None if no server responded with a
            record that passed the freshness filter."""
            tasks = []
            for offset in offsets:
                tasks.append(async_wrap_errors(worker(offset, name), timeout))
            t = timeout + 1
            first_in = asyncio.as_completed(tasks, timeout=t)
            try:
                for task in first_in:
                    ret = await task
                    if ret is not None and ret.value is not None:
                        return ret
            except asyncio.TimeoutError:
                pass
            return None

        # Single-sweep fast path: legacy behaviour. Either no
        # freshness filter at all, or a filter that should fail-fast
        # so the caller decides what to do (retry, fall back, abort).
        if not wait_for_fresh:
            ret = await one_sweep()
            if ret is not None:
                return ret
            raise FullNameFailure(fstr("Could not fetch {0}", (name,)))

        # Retry loop: keep asking the PNP pool until a fresh-enough
        # record is observed or max_wait_secs elapses. The retry
        # cadence is intentionally coarse (retry_interval seconds
        # between sweeps) because PNP propagation is on the order of
        # seconds and tighter polling just hammers the servers
        # without changing the answer.
        import time as _time
        deadline = _time.time() + max_wait_secs
        attempt = 0
        while True:
            attempt += 1
            ret = await one_sweep()
            if ret is not None:
                log(fstr(
                    "Nickname.get: wait_for_fresh succeeded attempt={0} ts={1}",
                    (attempt, getattr(ret, "pnp_ts", 0)),
                ))
                return ret
            if _time.time() >= deadline:
                log(fstr(
                    "Nickname.get: wait_for_fresh exhausted attempts={0} "
                    "max_wait={1}s name={2}",
                    (attempt, max_wait_secs, name),
                ))
                raise FullNameFailure(fstr(
                    "Could not fetch {0} fresh within {1}s",
                    (name, max_wait_secs),
                ))
            log(fstr(
                "Nickname.get: wait_for_fresh attempt={0} no fresh record yet, "
                "sleeping {1}s",
                (attempt, retry_interval),
            ))
            await asyncio.sleep(retry_interval)

    async def usage(self, timeout=NAMING_TIMEOUT):
        """Return current per-IP quota usage from the first reachable
        PNP server, as a dict::

            {"af": int, "names_used": int, "name_limit": int}

        Tries v4 first, falls back to v6.  Returns None if no client
        responds within ``timeout``.
        """
        if not self.started:
            raise AssertionError("Nickname client not started. Call start() first.")
        for af in VALID_AFS:
            for offset in sorted(self.clients[af].keys()):
                client = self.clients[af][offset]
                if client is None:
                    continue
                try:
                    info = await asyncio.wait_for(
                        client.usage(client.kp), timeout,
                    )
                    if info is not None:
                        return info
                except (OSError, ConnectionError, asyncio.TimeoutError):
                    log_exception()
                    continue
        return None

    async def usage_all(self, timeout=NAMING_TIMEOUT):
        """Return per-AF quota usage, keyed by address family::

            {IP4: {"af": int, "names_used": int, "name_limit": int},
             IP6: {...}}

        Each AF has its own independent per-IP name quota on the
        server, so a dual-stack node has two separate budgets and
        Nickname.put falls back from a full v4 quota onto the v6 one.
        This reports both so the demo can show the spare AF's headroom
        even when it isn't the AF currently in use.

        Only AFs the node actually has PNP clients for appear: a
        single-stack node yields one entry, a dual-stack node two.
        Within an AF the first responding server's answer is used.
        Returns an empty dict if no client responds within ``timeout``.
        """
        if not self.started:
            raise AssertionError("Nickname client not started. Call start() first.")
        out = {}
        for af in VALID_AFS:
            for offset in sorted(self.clients[af].keys()):
                client = self.clients[af][offset]
                if client is None:
                    continue
                try:
                    info = await asyncio.wait_for(
                        client.usage(client.kp), timeout,
                    )
                except (OSError, ConnectionError, asyncio.TimeoutError):
                    log_exception()
                    continue
                if info is not None:
                    out[af] = info
                    break
        return out

    async def delete(self, name, timeout=NAMING_TIMEOUT):
        """Delete the record for name from all reachable PNP servers concurrently."""
        if not self.started:
            raise AssertionError("Nickname client not started. Call start() first.")
        name = pnp_strip_tlds(name)

        async def worker(offset):
            """Send a delete request for name to the PNP server at offset and return the result."""
            for af in VALID_AFS:
                try:
                    client = self.clients[af][offset]
                    if client is None:
                        continue
                    ret = await client.delete(name, client.kp)
                    if ret is not None:
                        return ret
                except (OSError, ConnectionError, asyncio.TimeoutError):
                    log_exception()

        tasks = []
        for offset in range(0, len(self.clients[IP4])):
            tasks.append(async_wrap_errors(worker(offset), timeout))

        await asyncio.gather(*tasks)

    async def close(self):
        """Close all active PNP client connections and reset the started flag."""
        for af in self.clients:
            for index in list(self.clients[af]):
                client = self.clients[af][index]
                if client is not None and hasattr(client, "close"):
                    try:
                        await client.close()
                    except (OSError, asyncio.TimeoutError):
                        pass
                self.clients[af][index] = None
        self.started = False

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, *_):
        await self.close()
        return False

    def __await__(self):
        return self.start().__await__()


# push:
#     - try to store on all of them
#     - store success offsets
#     - convert success offsets to tld
#     - return name + tld on success
#
# fetch:
#     - name + tld
#     - convert to list of offsets
#     - use first in to get the fastest success result
#
# delete:
#     - name + tld
#     - convert to list of offsets
#     - concurrently delete them
#     - no follow up
