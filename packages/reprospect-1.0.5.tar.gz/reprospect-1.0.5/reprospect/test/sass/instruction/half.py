import typing

import regex

from reprospect.test.sass.instruction.immediate import Immediate
from reprospect.test.sass.instruction.instruction import (
    OpCode,
    PatternMatcher,
    ZeroOrOne,
)
from reprospect.test.sass.instruction.operand import Operand
from reprospect.test.sass.instruction.pattern import PatternBuilder
from reprospect.test.sass.instruction.register import Register

MODIFIER_HALF_SEL: typing.Final[str] = r'H[01]_H[01]'

class Fp16:
    """
    Helper for FP16 matchers.

    These instructions typically operate on *packed half-precision pairs* (2 *lanes* per 32-bit register).

    - Each 32-bit register holds two FP16 values (**H0** on bits 0-15 and **H1** on bits 16-31).
    - The instruction can process both lanes in parallel.

    They optionally use *lane selectors*, *e.g.* ``.H0_H0`` or ``.H1_H1``.

    - ``R0.H0_H0`` broadcasts the low half of ``R0`` to both lanes.
    - ``R0.H1_H1`` broadcasts the high half of ``R0`` to both lanes.

    References:

    * :cite:`ho-exploiting-2017`
    """
    REGZ_HALF_SEL: typing.Final[str] = Register.REGZ + rf'\.{MODIFIER_HALF_SEL}'

    @classmethod
    def regz_half_sel(cls) -> str:
        return PatternBuilder.group(cls.REGZ_HALF_SEL, group='operands')

    @classmethod
    def mod(cls, reg: str, *, half_sel: bool | None = None, captured: bool = True) -> str:
        """
        Wrap a register pattern with a half selector modifier.
        """
        if half_sel is None:
            inner = reg + PatternBuilder.zero_or_one(rf'\.{MODIFIER_HALF_SEL}')
        elif half_sel is True:
            inner = reg + rf'\.{MODIFIER_HALF_SEL}'
        else:
            inner = reg
        return PatternBuilder.group(inner, group='operands') if captured else inner

    @classmethod
    def build_pattern_operand(cls, *, half_sel: bool | None = None, math: bool | None = None, immediate: bool | None = None, captured: bool = True) -> str:
        """
        Build pattern for an FP16 operand.
        """
        opnd_reg = Operand.mod(cls.mod(Register.REGZ, half_sel=half_sel, captured=False), math=math, captured=False)

        if immediate is None:
            inner = PatternBuilder.any(opnd_reg, Immediate.FLOATING)
        elif immediate is True:
            inner = Immediate.FLOATING
        else:
            inner = opnd_reg

        return PatternBuilder.group(inner, group='operands') if captured else inner

class Fp16FusedMulAddMatcher(PatternMatcher):
    """
    Matcher for 16-bit floating-point fused multiply add (``HFMA2``) instruction, such as::

        HFMA2 R7, R2, R2, -RZ
        HFMA2 R0, R0.H0_H0, R0.H1_H1, 3, 3
        HFMA2 R0, R2, 5, 2, R0.H1_H1

    .. note::

        The FMA computes ``D = A * B + C``. However, it may accept 4 or 5 operands.

        - 4 operands (``HFMA2 D, A, B, C``)

          The addend ``C`` is a register or a single immediate value applied to both lanes.
          Therefore, the following::

            HFMA2 R7, R2, R2, R0

          computes ``R7.H0 = R2.H0 * R2.H0 + R0.H0`` and ``R7.H1 = R2.H1 * R2.H1 + R0.H1``.

        - 5 operands (``HFMA2 E, A, B, C, D``)

          The addend is split per lane with separate immediate values. Therefore, the following::

            HFMA2 R0, R1.H0_H0, R2.H1_H1, 3, 1

          computes ``R0.H0 = R1.H0 * R2.H1 + 3.0`` and ``R0.H1 = R1.H0 * R2.H1 + 1.0``.

    .. note::

        For ``HFMA2.MMA`` with 5 operands, operands 2 and 3 appear to be multipliers for each lane.
        The following results from ``dst += src`` where operands 2 and 3 are set to immediate unit::

            LDG.E.CONSTANT R5, [R4.64]
            LDG.E R0, [R2.64]
            HFMA2.MMA R7, R0, 1, 1, R5
            STG.E [R2.64], R7

        This likely means "multiply both lanes of ``R0`` by 1 and add ``R5``".
    """
    TEMPLATE: typing.Final[str] = f"{OpCode.mod('HFMA2', modifiers=(ZeroOrOne('MMA'),))} {Register.dst()}, {{op1}}, {{op2}}, {{op3}}(?:, {{op4}})?"

    PATTERN_ANY: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(),
        op2=Fp16.build_pattern_operand(),
        op3=Fp16.build_pattern_operand(),
        op4=Fp16.build_pattern_operand(),
    ))

    PATTERN_INDIVIDUAL: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(half_sel=True, immediate=False),
        op2=Fp16.build_pattern_operand(half_sel=True, immediate=False),
        op3=Fp16.build_pattern_operand(half_sel=True),
        op4=Fp16.build_pattern_operand(half_sel=True),
    ))

    PATTERN_PACKED: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(half_sel=False, immediate=False),
        op2=Fp16.build_pattern_operand(half_sel=False),
        op3=Fp16.build_pattern_operand(half_sel=False),
        op4=Fp16.build_pattern_operand(half_sel=False),
    ))

    def __init__(self, *, packed: bool | None = None) -> None:
        """
        :param packed: If it is packed or not.
        """
        if packed is None:
            pattern = self.PATTERN_ANY
        elif packed is True:
            pattern = self.PATTERN_PACKED
        else:
            pattern = self.PATTERN_INDIVIDUAL
        super().__init__(pattern=pattern)


class Fp16MulMatcher(PatternMatcher):
    """
    Matcher for 16-bit floating-point multiply (``HMUL2``) instruction.

    It may apply on :code:`__half`::

        HMUL2 R0, R2.H0_H0, R3.H0_H0

    or on :code:`__half2`::

        HMUL2 R0, R2, R3
    """
    TEMPLATE: typing.Final[str] = f"{OpCode.mod('HMUL2', modifiers=())} {Register.dst()}, {{op1}}, {{op2}}"

    PATTERN_ANY: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(),
        op2=Fp16.build_pattern_operand(),
    ))

    PATTERN_INDIVIDUAL: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(half_sel=True, immediate=False),
        op2=Fp16.build_pattern_operand(half_sel=True, immediate=False),
    ))

    PATTERN_PACKED: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(half_sel=False, math=False, immediate=False),
        op2=Fp16.build_pattern_operand(half_sel=False, math=False, immediate=False),
    ))

    def __init__(self, *, packed: bool | None = None) -> None:
        """
        :param packed: If it is packed or not.

        References:

        * https://developer.nvidia.com/blog/mixed-precision-programming-cuda-8/
        * https://docs.nvidia.com/cuda/cuda-math-api/cuda_math_api/group__CUDA__MATH____HALF2__ARITHMETIC.html
        """
        if packed is None:
            pattern = self.PATTERN_ANY
        elif packed is True:
            pattern = self.PATTERN_PACKED
        else:
            pattern = self.PATTERN_INDIVIDUAL
        super().__init__(pattern=pattern)

class Fp16AddMatcher(PatternMatcher):
    """
    Matcher for 16-bit floating-point add (``HADD2``) instruction.

    It may apply on :code:`__half`::

        HADD2 R0, R2.H0_H0, R3.H0_H0

    or on :code:`__half2`::

        HADD2 R0, R2, R3
    """
    TEMPLATE: typing.Final[str] = f"{OpCode.mod('HADD2', modifiers=(ZeroOrOne('F32'),))} {Register.dst()}, {{op1}}, {{op2}}"

    PATTERN_ANY: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(),
        op2=Fp16.build_pattern_operand(),
    ))

    PATTERN_INDIVIDUAL: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(half_sel=True, immediate=False),
        op2=Fp16.build_pattern_operand(half_sel=True, immediate=False),
    ))

    PATTERN_PACKED: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(half_sel=False, math=False, immediate=False),
        op2=Fp16.build_pattern_operand(half_sel=False, math=False, immediate=False),
    ))

    def __init__(self, *, packed: bool | None = None) -> None:
        if packed is None:
            pattern = self.PATTERN_ANY
        elif packed is True:
            pattern = self.PATTERN_PACKED
        else:
            pattern = self.PATTERN_INDIVIDUAL
        super().__init__(pattern=pattern)

class Fp16MinMaxMatcher(PatternMatcher):
    """
    Matcher for 16-bit floating-point min-max (``HMNMX2``) instruction.
    """
    TEMPLATE: typing.Final[str] = f"{OpCode.mod('HMNMX2', modifiers=())} {Register.dst()}, {{op1}}, {{op2}}, {{which}}"

    PATTERN_ANY: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(),
        op2=Fp16.build_pattern_operand(),
        which=PatternBuilder.group(r'!?PT', group='operands'),
    ))

    PATTERN_MAX: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(),
        op2=Fp16.build_pattern_operand(),
        which=PatternBuilder.group('!PT', group='operands'),
    ))

    PATTERN_MIN: typing.Final[regex.Pattern[str]] = regex.compile(TEMPLATE.format(
        op1=Fp16.build_pattern_operand(),
        op2=Fp16.build_pattern_operand(),
        which=PatternBuilder.group('PT', group='operands'),
    ))

    def __init__(self, *, pmax: bool | None = None) -> None:
        """
        :param pmax: If :py:obj:`True`, match a *max*. If :py:obj:`False`, match a *min*. Otherwise, match either *max* or *min*.
        """
        if pmax is None:
            pattern = self.PATTERN_ANY
        elif pmax is False:
            pattern = self.PATTERN_MIN
        else:
            pattern = self.PATTERN_MAX
        super().__init__(pattern=pattern)
