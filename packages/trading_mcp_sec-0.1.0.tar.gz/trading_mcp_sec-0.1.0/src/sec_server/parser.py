"""HTML-to-text parser for SEC EDGAR filings.

EDGAR serves filings as HTML. This module extracts clean text from
filing documents, identifies sections (Risk Factors, Business, MD&A,
Financials), and chunks them for RAG pipelines.
"""

import re

# ── Section header patterns ──────────────────────────────────────
# These match common 10-K/10-Q section headers in EDGAR HTML text.

_SECTION_PATTERNS: dict[str, list[re.Pattern]] = {
    "risk_factors": [
        re.compile(r"(?:item\s*1a[\.\s:\-]*)?risk\s+factors", re.IGNORECASE),
    ],
    "business": [
        re.compile(r"(?:item\s*1[\.\s:\-]*)business\b", re.IGNORECASE),
        re.compile(r"^item\s*1[.\s]", re.IGNORECASE | re.MULTILINE),
    ],
    "mda": [
        re.compile(
            r"(?:item\s*7[\.\s:\-]*)?management.s?\s+discussion\s+and\s+analysis",
            re.IGNORECASE,
        ),
        re.compile(r"item\s*7[\.\s:\-]*md\s*&\s*a", re.IGNORECASE),
    ],
    "financials": [
        re.compile(
            r"(?:item\s*8[\.\s:\-]*)?financial\s+statements\s+and\s+supplementary",
            re.IGNORECASE,
        ),
        re.compile(r"item\s*8[\.\s:\-]*financial\s+statements", re.IGNORECASE),
    ],
}

# Item headers used to detect section boundaries
_ITEM_BOUNDARY = re.compile(r"\n\s*item\s+\d+[a-z]?[\.\s:\-]", re.IGNORECASE)


def strip_html(html: str) -> str:
    """Remove HTML tags and collapse whitespace to produce clean text."""
    # Remove script/style blocks
    text = re.sub(
        r"<(script|style)[^>]*>.*?</\1>", "", html, flags=re.DOTALL | re.IGNORECASE
    )
    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)
    # Decode common entities
    for entity, char in [
        ("&amp;", "&"),
        ("&lt;", "<"),
        ("&gt;", ">"),
        ("&nbsp;", " "),
        ("&quot;", '"'),
        ("&#39;", "'"),
        ("&apos;", "'"),
        ("&rsquo;", "'"),
        ("&lsquo;", "'"),
        ("&rdquo;", '"'),
        ("&ldquo;", '"'),
        ("&mdash;", "—"),
        ("&ndash;", "–"),
    ]:
        text = text.replace(entity, char)
    # Collapse whitespace
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text)
    return text.strip()


def extract_section(full_text: str, section_name: str, max_chars: int = 3000) -> str:
    """Extract a named section from filing text.

    Looks for the section header, then captures text until the next
    Item header or max_chars, whichever comes first.
    """
    patterns = _SECTION_PATTERNS.get(section_name, [])
    if not patterns:
        return ""

    best_start = -1
    for pattern in patterns:
        match = pattern.search(full_text)
        if match:
            if best_start == -1 or match.start() < best_start:
                best_start = match.start()

    if best_start == -1:
        return ""

    # Find the next Item boundary after our section start
    rest = full_text[best_start:]
    # Skip past the header line itself
    header_end = rest.find("\n")
    if header_end == -1:
        header_end = 0
    body_start = header_end + 1

    # Find next section boundary
    next_boundary = _ITEM_BOUNDARY.search(rest[body_start:])
    if next_boundary:
        section_text = rest[body_start : body_start + next_boundary.start()]
    else:
        section_text = rest[body_start:]

    section_text = section_text.strip()
    if len(section_text) > max_chars:
        # Cut at last sentence boundary within limit
        truncated = section_text[:max_chars]
        last_period = truncated.rfind(".")
        if last_period > max_chars * 0.5:
            truncated = truncated[: last_period + 1]
        return truncated
    return section_text


def extract_all_sections(full_text: str, max_chars: int = 3000) -> dict[str, str]:
    """Extract all known sections from filing text."""
    return {
        name: extract_section(full_text, name, max_chars) for name in _SECTION_PATTERNS
    }


def chunk_text(text: str, chunk_size: int = 800) -> list[dict]:
    """Split text into RAG-ready chunks.

    Tries to split on paragraph boundaries. Each chunk gets an index
    and an extracted headline (first line or sentence).
    """
    if not text:
        return []

    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: list[dict] = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 > chunk_size and current:
            chunks.append(_make_chunk(current, len(chunks)))
            current = para
        else:
            current = f"{current}\n\n{para}" if current else para

    if current:
        chunks.append(_make_chunk(current, len(chunks)))

    return chunks


def _make_chunk(text: str, index: int) -> dict:
    """Create a chunk dict with index, text, and extracted headline."""
    text = text.strip()
    # Use first sentence or first 80 chars as headline
    first_line = text.split("\n")[0].strip()
    period = first_line.find(".")
    if 0 < period < 120:
        headline = first_line[: period + 1]
    else:
        headline = first_line[:80] + ("..." if len(first_line) > 80 else "")
    return {"index": index, "text": text, "headline": headline}
