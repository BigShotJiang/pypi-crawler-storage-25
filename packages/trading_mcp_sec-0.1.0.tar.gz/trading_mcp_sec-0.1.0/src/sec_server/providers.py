"""SEC EDGAR data provider.

All data comes from SEC EDGAR (efts.sec.gov + data.sec.gov).
Completely free — no API key required.
Rate limit: 10 requests/second (EDGAR policy).
"""

import asyncio

import httpx

from trading_mcp_shared.errors import ProviderError

_TIMEOUT = 10.0
_USER_AGENT = "TradingMCP/1.0 (open-source MCP server; contact@tradingmcp.dev)"

# EDGAR requires a User-Agent header identifying the caller
_HEADERS = {"User-Agent": _USER_AGENT, "Accept-Encoding": "gzip, deflate"}

# Rate limiting: simple semaphore to stay under 10 req/s
_rate_semaphore = asyncio.Semaphore(8)


async def _edgar_request(
    client: httpx.AsyncClient,
    url: str,
    params: dict | None = None,
) -> httpx.Response:
    """Make a rate-limited request to EDGAR."""
    async with _rate_semaphore:
        resp = await client.get(
            url,
            params=params,
            headers=_HEADERS,
            timeout=_TIMEOUT,
        )
        if resp.status_code != 200:
            raise ProviderError(
                "edgar", f"HTTP {resp.status_code} for {url}", resp.status_code
            )
        return resp


# ── CIK resolution ───────────────────────────────────────────────


async def resolve_cik(client: httpx.AsyncClient, query: str) -> tuple[str, str]:
    """Resolve a ticker or company name to (CIK, company_name).

    Tries the EDGAR company tickers JSON first, then full-text search.
    """
    # Try the tickers endpoint (maps ticker → CIK)
    resp = await _edgar_request(
        client,
        "https://www.sec.gov/files/company_tickers.json",
    )
    tickers_data = resp.json()

    query_upper = query.upper().strip()

    # Search by ticker
    for entry in tickers_data.values():
        if entry.get("ticker", "").upper() == query_upper:
            cik = str(entry["cik_str"]).zfill(10)
            return cik, entry.get("title", "")

    # Search by CIK directly
    if query.isdigit():
        cik = query.zfill(10)
        for entry in tickers_data.values():
            if str(entry["cik_str"]).zfill(10) == cik:
                return cik, entry.get("title", "")
        return cik, ""

    # Search by partial company name
    query_lower = query.lower()
    for entry in tickers_data.values():
        if query_lower in entry.get("title", "").lower():
            cik = str(entry["cik_str"]).zfill(10)
            return cik, entry.get("title", "")

    raise ProviderError("edgar", f"Could not resolve '{query}' to a CIK number")


# ── Filing search ────────────────────────────────────────────────


async def search_filings_edgar(
    client: httpx.AsyncClient,
    cik: str,
    company_name: str,
    form_type: str,
    limit: int,
) -> list[dict]:
    """Search EDGAR for filings by CIK."""
    resp = await _edgar_request(
        client,
        f"https://data.sec.gov/submissions/CIK{cik}.json",
    )
    data = resp.json()
    recent = data.get("filings", {}).get("recent", {})

    forms = recent.get("form", [])
    dates = recent.get("filingDate", [])
    accessions = recent.get("accessionNumber", [])
    primary_docs = recent.get("primaryDocument", [])
    report_dates = recent.get("reportDate", [])

    results = []
    for i in range(len(forms)):
        if form_type != "all" and forms[i] != form_type:
            continue
        acc = accessions[i]
        acc_no_dash = acc.replace("-", "")
        doc = primary_docs[i] if i < len(primary_docs) else ""
        url = f"https://www.sec.gov/Archives/edgar/data/{cik.lstrip('0')}/{acc_no_dash}/{doc}"

        results.append(
            {
                "accessionNumber": acc,
                "formType": forms[i],
                "filedAt": dates[i] if i < len(dates) else "",
                "reportDate": report_dates[i] if i < len(report_dates) else "",
                "company": company_name or data.get("name", ""),
                "cik": cik,
                "url": url,
            }
        )
        if len(results) >= limit:
            break

    return results


# ── Filing document fetch ────────────────────────────────────────


async def fetch_filing_document(
    client: httpx.AsyncClient,
    accession_number: str,
    cik: str,
) -> tuple[str, dict]:
    """Fetch the primary HTML document for a filing.

    Returns (html_text, metadata_dict).
    """
    # Get the filing index to find the primary document
    acc_no_dash = accession_number.replace("-", "")

    # First get the index page
    resp = await _edgar_request(
        client,
        f"https://www.sec.gov/Archives/edgar/data/{cik.lstrip('0')}/{acc_no_dash}/index.json",
    )
    index_data = resp.json()

    directory = index_data.get("directory", {})
    items = directory.get("item", [])

    # Find the primary document (usually the .htm file that's not R*.htm)
    primary_doc = ""
    for item in items:
        name = item.get("name", "")
        if name.endswith((".htm", ".html")) and not name.startswith("R"):
            primary_doc = name
            break

    if not primary_doc:
        # Fallback: use first .htm file
        for item in items:
            name = item.get("name", "")
            if name.endswith((".htm", ".html")):
                primary_doc = name
                break

    if not primary_doc:
        raise ProviderError(
            "edgar", f"No HTML document found for filing {accession_number}"
        )

    doc_url = f"https://www.sec.gov/Archives/edgar/data/{cik.lstrip('0')}/{acc_no_dash}/{primary_doc}"
    doc_resp = await _edgar_request(client, doc_url)

    metadata = {
        "accessionNumber": accession_number,
        "company": index_data.get("directory", {}).get("name", ""),
    }

    return doc_resp.text, metadata


# ── XBRL financials ──────────────────────────────────────────────


async def fetch_company_facts(
    client: httpx.AsyncClient,
    cik: str,
) -> dict:
    """Fetch XBRL company facts from EDGAR.

    Returns the full companyfacts JSON which contains all reported
    financial concepts across all filings.
    """
    resp = await _edgar_request(
        client,
        f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json",
    )
    return resp.json()


def extract_financials(facts: dict, period: str) -> dict:
    """Extract key financial metrics from XBRL company facts.

    Args:
        facts: Raw companyfacts JSON from EDGAR
        period: "annual" (10-K) or "quarterly" (10-Q)
    """
    us_gaap = facts.get("facts", {}).get("us-gaap", {})
    form_filter = "10-K" if period == "annual" else "10-Q"

    def _get_latest(concept: str) -> tuple[float | None, str, str]:
        """Get the most recent value for a GAAP concept.

        Returns (value, filed_date, period_end).
        """
        concept_data = us_gaap.get(concept, {})
        units = concept_data.get("units", {})
        # Try USD first, then shares
        values = units.get("USD", units.get("USD/shares", units.get("shares", [])))
        if not values:
            return None, "", ""

        # Filter by form type and find most recent
        filtered = [v for v in values if v.get("form") == form_filter]
        if not filtered:
            filtered = values

        # Sort by filed date descending
        filtered.sort(key=lambda x: x.get("filed", ""), reverse=True)
        if not filtered:
            return None, "", ""

        latest = filtered[0]
        return latest.get("val"), latest.get("filed", ""), latest.get("end", "")

    revenue, filed, period_end = _get_latest("Revenues")
    if revenue is None:
        revenue, filed, period_end = _get_latest(
            "RevenueFromContractWithCustomerExcludingAssessedTax"
        )
    net_income, _, _ = _get_latest("NetIncomeLoss")
    eps, _, _ = _get_latest("EarningsPerShareDiluted")
    if eps is None:
        eps, _, _ = _get_latest("EarningsPerShareBasic")
    total_assets, _, _ = _get_latest("Assets")
    total_debt, _, _ = _get_latest("LongTermDebt")
    if total_debt is None:
        total_debt, _, _ = _get_latest("LongTermDebtNoncurrent")
    cash, _, _ = _get_latest("CashAndCashEquivalentsAtCarryingValue")
    op_cf, _, _ = _get_latest("NetCashProvidedByUsedInOperatingActivities")
    capex, _, _ = _get_latest("PaymentsToAcquirePropertyPlantAndEquipment")

    fcf = None
    if op_cf is not None and capex is not None:
        fcf = op_cf - capex

    return {
        "revenue": revenue,
        "netIncome": net_income,
        "eps": eps,
        "totalAssets": total_assets,
        "totalDebt": total_debt,
        "cashAndEquivalents": cash,
        "operatingCashFlow": op_cf,
        "freeCashFlow": fcf,
        "filedAt": filed,
        "fiscalPeriodEnd": period_end,
        "period": period,
    }
