"""SEC Filings MCP server — 4 tools for SEC EDGAR filing data."""

import httpx
from fastmcp import FastMCP

from trading_mcp_shared.cache import TTLCacheWrapper

from sec_server.parser import (
    chunk_text,
    extract_all_sections,
    extract_section,
    strip_html,
)
from sec_server.providers import (
    extract_financials,
    fetch_company_facts,
    fetch_filing_document,
    resolve_cik,
    search_filings_edgar,
)

mcp = FastMCP("SEC Filings")

# ── Caches (24h TTL for filings — they don't change) ────────────

_search_cache = TTLCacheWrapper(maxsize=128, ttl=86400)
_filing_cache = TTLCacheWrapper(maxsize=64, ttl=86400)
_financials_cache = TTLCacheWrapper(maxsize=64, ttl=86400)
_risk_cache = TTLCacheWrapper(maxsize=64, ttl=86400)

# ── Shared client ────────────────────────────────────────────────

_client: httpx.AsyncClient | None = None


async def _get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient()
    return _client


# ── Valid enums ──────────────────────────────────────────────────

_VALID_FORM_TYPES = {"10-K", "10-Q", "8-K", "DEF 14A", "all"}
_VALID_SECTIONS = {"risk_factors", "business", "financials", "mda", "all"}
_VALID_PERIODS = {"annual", "quarterly"}


# ── Tool 1: search_filings ──────────────────────────────────────


@mcp.tool()
async def search_filings(
    query: str,
    form_type: str = "all",
    limit: int = 5,
) -> dict:
    """Search for SEC filings by company name, ticker, or CIK number.

    Args:
        query: Company name, ticker, or CIK number e.g. "AAPL", "Apple", "320193"
        form_type: Filing type filter: "10-K", "10-Q", "8-K", "DEF 14A", "all". Defaults to "all".
        limit: Max results (max 20). Defaults to 5.
    """
    try:
        query = query.strip()
        if not query:
            return {"error": "Query is required."}
        if form_type not in _VALID_FORM_TYPES:
            return {
                "error": f"Invalid form_type '{form_type}'. Must be one of: {', '.join(sorted(_VALID_FORM_TYPES))}"
            }
        limit = max(1, min(limit, 20))

        cache_key = f"search:{query}:{form_type}:{limit}"
        cached = _search_cache.get(cache_key)
        if cached is not None:
            return cached

        client = await _get_client()
        cik, company_name = await resolve_cik(client, query)
        filings = await search_filings_edgar(
            client, cik, company_name, form_type, limit
        )

        result = {"filings": filings, "company": company_name, "cik": cik}
        _search_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[sec] error: {e}")
        return {"error": f"Unable to search filings for '{query}' — {e}"}


# ── Tool 2: get_filing_summary ───────────────────────────────────


@mcp.tool()
async def get_filing_summary(
    accession_number: str,
    sections: list[str] | None = None,
    max_chars: int = 3000,
) -> dict:
    """Get an LLM-ready summary of a specific SEC filing with key extracted sections.

    Args:
        accession_number: SEC accession number from search_filings e.g. "0000320193-23-000106"
        sections: Which sections to extract: "risk_factors", "business", "financials", "mda", "all". Defaults to all.
        max_chars: Max characters per section. Defaults to 3000.
    """
    try:
        accession_number = accession_number.strip()
        if not accession_number:
            return {"error": "Accession number is required."}

        if sections is None:
            sections = ["all"]

        for s in sections:
            if s not in _VALID_SECTIONS:
                return {
                    "error": f"Invalid section '{s}'. Must be one of: {', '.join(sorted(_VALID_SECTIONS))}"
                }

        max_chars = max(500, min(max_chars, 50000))

        cache_key = (
            f"filing:{accession_number}:{','.join(sorted(sections))}:{max_chars}"
        )
        cached = _filing_cache.get(cache_key)
        if cached is not None:
            return cached

        # We need the CIK to construct the URL. Extract from accession number format
        # or search for it. The accession number format is XXXXXXXXXX-YY-ZZZZZZ
        # where XXXXXXXXXX is the CIK.
        cik = accession_number.split("-")[0].zfill(10)

        client = await _get_client()
        html, metadata = await fetch_filing_document(client, accession_number, cik)
        full_text = strip_html(html)

        if "all" in sections:
            extracted = extract_all_sections(full_text, max_chars)
        else:
            extracted = {}
            for section_name in sections:
                extracted[section_name] = extract_section(
                    full_text, section_name, max_chars
                )

        result = {
            "sections": extracted,
            "metadata": metadata,
        }
        _filing_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[sec] error: {e}")
        return {"error": f"Unable to fetch filing {accession_number} — {e}"}


# ── Tool 3: get_key_financials ───────────────────────────────────


@mcp.tool()
async def get_key_financials(
    symbol: str,
    period: str = "annual",
) -> dict:
    """Extract structured financial metrics from the most recent 10-K or 10-Q.

    Args:
        symbol: Ticker symbol e.g. "AAPL", "MSFT"
        period: "annual" (from 10-K) or "quarterly" (from 10-Q). Defaults to "annual".
    """
    try:
        symbol = symbol.strip().upper()
        if not symbol:
            return {"error": "Symbol is required."}
        if period not in _VALID_PERIODS:
            return {
                "error": f"Invalid period '{period}'. Must be one of: {', '.join(sorted(_VALID_PERIODS))}"
            }

        cache_key = f"financials:{symbol}:{period}"
        cached = _financials_cache.get(cache_key)
        if cached is not None:
            return cached

        client = await _get_client()
        cik, company_name = await resolve_cik(client, symbol)
        facts = await fetch_company_facts(client, cik)
        financials = extract_financials(facts, period)
        financials["symbol"] = symbol
        financials["company"] = company_name

        _financials_cache.set(cache_key, financials)
        return financials
    except Exception as e:
        print(f"[sec] error: {e}")
        return {"error": f"Unable to fetch financials for '{symbol}' — {e}"}


# ── Tool 4: get_risk_factors ─────────────────────────────────────


@mcp.tool()
async def get_risk_factors(
    symbol: str,
    chunk_size: int = 800,
) -> dict:
    """Extract and chunk the Risk Factors section from the most recent 10-K — optimised for RAG pipelines.

    Args:
        symbol: Ticker symbol e.g. "AAPL", "MSFT"
        chunk_size: Character size of each chunk for RAG. Defaults to 800.
    """
    try:
        symbol = symbol.strip().upper()
        if not symbol:
            return {"error": "Symbol is required."}
        chunk_size = max(200, min(chunk_size, 5000))

        cache_key = f"risk:{symbol}:{chunk_size}"
        cached = _risk_cache.get(cache_key)
        if cached is not None:
            return cached

        client = await _get_client()
        cik, company_name = await resolve_cik(client, symbol)

        # Find the most recent 10-K
        filings = await search_filings_edgar(client, cik, company_name, "10-K", 1)
        if not filings:
            return {"error": f"No 10-K filing found for {symbol}."}

        acc = filings[0]["accessionNumber"]
        html, _ = await fetch_filing_document(client, acc, cik)
        full_text = strip_html(html)

        risk_text = extract_section(full_text, "risk_factors", max_chars=100000)
        if not risk_text:
            return {
                "symbol": symbol,
                "chunks": [],
                "totalRisks": 0,
                "note": "Risk Factors section could not be located in the filing.",
            }

        chunks = chunk_text(risk_text, chunk_size)

        result = {
            "symbol": symbol,
            "company": company_name,
            "filingAccession": acc,
            "chunks": chunks,
            "totalRisks": len(chunks),
        }
        _risk_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[sec] error: {e}")
        return {"error": f"Unable to fetch risk factors for '{symbol}' — {e}"}


def main() -> None:
    mcp.run()
