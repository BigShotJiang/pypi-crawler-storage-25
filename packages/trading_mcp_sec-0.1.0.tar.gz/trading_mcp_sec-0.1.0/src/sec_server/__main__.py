"""Entry point: uv run python -m sec_server"""

from sec_server.server import mcp

mcp.run()
