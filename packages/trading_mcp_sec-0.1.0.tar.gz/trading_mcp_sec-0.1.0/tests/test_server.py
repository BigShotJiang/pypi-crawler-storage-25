"""Tests for all 4 SEC Filings MCP tools."""

import httpx
import pytest

from sec_server.server import (
    get_filing_summary,
    get_key_financials,
    get_risk_factors,
    search_filings,
)


# ═══════════════════════════════════════════════════════════════════
# Tool 1: search_filings
# ═══════════════════════════════════════════════════════════════════


class TestSearchFilings:
    @pytest.mark.asyncio
    async def test_search_filings_happy_path(self, mock_edgar):
        result = await search_filings("AAPL")
        assert "filings" in result
        assert len(result["filings"]) > 0
        assert result["company"] == "Apple Inc."
        assert result["filings"][0]["formType"] == "10-K"
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_search_filings_by_form_type(self, mock_edgar):
        result = await search_filings("AAPL", form_type="10-Q")
        assert "filings" in result
        for f in result["filings"]:
            assert f["formType"] == "10-Q"

    @pytest.mark.asyncio
    async def test_search_filings_by_cik(self, mock_edgar):
        result = await search_filings("320193")
        assert "filings" in result
        assert result["cik"] == "0000320193"

    @pytest.mark.asyncio
    async def test_search_filings_by_name(self, mock_edgar):
        result = await search_filings("Apple")
        assert "filings" in result
        assert "Apple" in result["company"]

    @pytest.mark.asyncio
    async def test_search_filings_all_fail(self, mock_routes):
        mock_routes.get("https://www.sec.gov/files/company_tickers.json").mock(
            return_value=httpx.Response(500)
        )
        result = await search_filings("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_search_filings_invalid_input(self):
        result = await search_filings("")
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_search_filings_invalid_form_type(self):
        result = await search_filings("AAPL", form_type="invalid")
        assert "error" in result
        assert "Invalid form_type" in result["error"]

    @pytest.mark.asyncio
    async def test_search_filings_not_found(self, mock_routes):
        mock_routes.get("https://www.sec.gov/files/company_tickers.json").mock(
            return_value=httpx.Response(
                200,
                json={
                    "0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}
                },
            )
        )
        result = await search_filings("ZZZNOTFOUND")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_search_filings_respects_limit(self, mock_edgar):
        result = await search_filings("AAPL", limit=2)
        assert len(result["filings"]) <= 2


# ═══════════════════════════════════════════════════════════════════
# Tool 2: get_filing_summary
# ═══════════════════════════════════════════════════════════════════


class TestGetFilingSummary:
    @pytest.mark.asyncio
    async def test_get_filing_summary_happy_path(self, mock_edgar):
        result = await get_filing_summary("0000320193-23-000106")
        assert "sections" in result
        assert "metadata" in result
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_filing_summary_specific_sections(self, mock_edgar):
        result = await get_filing_summary(
            "0000320193-23-000106", sections=["risk_factors", "business"]
        )
        assert "risk_factors" in result["sections"]
        assert "business" in result["sections"]
        assert "mda" not in result["sections"]

    @pytest.mark.asyncio
    async def test_get_filing_summary_all_sections(self, mock_edgar):
        result = await get_filing_summary("0000320193-23-000106", sections=["all"])
        sections = result["sections"]
        assert "risk_factors" in sections
        assert "business" in sections
        assert "mda" in sections
        assert "financials" in sections

    @pytest.mark.asyncio
    async def test_get_filing_summary_invalid_input(self):
        result = await get_filing_summary("")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_filing_summary_invalid_section(self):
        result = await get_filing_summary("0000320193-23-000106", sections=["invalid"])
        assert "error" in result
        assert "Invalid section" in result["error"]

    @pytest.mark.asyncio
    async def test_get_filing_summary_all_fail(self, mock_routes):
        mock_routes.get(
            url__regex=r"https://www\.sec\.gov/Archives/.*index\.json"
        ).mock(return_value=httpx.Response(500))
        result = await get_filing_summary("0000320193-23-000106")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_filing_summary_custom_max_chars(self, mock_edgar):
        result = await get_filing_summary("0000320193-23-000106", max_chars=500)
        assert "sections" in result


# ═══════════════════════════════════════════════════════════════════
# Tool 3: get_key_financials
# ═══════════════════════════════════════════════════════════════════


class TestGetKeyFinancials:
    @pytest.mark.asyncio
    async def test_get_key_financials_happy_path(self, mock_edgar):
        result = await get_key_financials("AAPL")
        assert result["revenue"] == 383285000000
        assert result["netIncome"] == 96995000000
        assert result["eps"] == 6.13
        assert result["totalAssets"] == 352583000000
        assert result["totalDebt"] == 95281000000
        assert result["cashAndEquivalents"] == 29965000000
        assert result["operatingCashFlow"] == 110543000000
        assert result["freeCashFlow"] == 110543000000 - 11084000000
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_key_financials_quarterly(self, mock_edgar):
        result = await get_key_financials("AAPL", period="quarterly")
        assert result["period"] == "quarterly"
        # Quarterly revenue from the fixture
        assert result["revenue"] == 117154000000

    @pytest.mark.asyncio
    async def test_get_key_financials_all_fail(self, mock_routes):
        mock_routes.get("https://www.sec.gov/files/company_tickers.json").mock(
            return_value=httpx.Response(500)
        )
        result = await get_key_financials("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_key_financials_invalid_input(self):
        result = await get_key_financials("")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_key_financials_invalid_period(self):
        result = await get_key_financials("AAPL", period="monthly")
        assert "error" in result
        assert "Invalid period" in result["error"]

    @pytest.mark.asyncio
    async def test_get_key_financials_not_found(self, mock_routes):
        mock_routes.get("https://www.sec.gov/files/company_tickers.json").mock(
            return_value=httpx.Response(
                200,
                json={
                    "0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}
                },
            )
        )
        result = await get_key_financials("ZZZNOTFOUND")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════
# Tool 4: get_risk_factors
# ═══════════════════════════════════════════════════════════════════


class TestGetRiskFactors:
    @pytest.mark.asyncio
    async def test_get_risk_factors_happy_path(self, mock_edgar):
        result = await get_risk_factors("AAPL")
        assert "chunks" in result
        assert result["totalRisks"] > 0
        assert result["symbol"] == "AAPL"
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_risk_factors_chunk_structure(self, mock_edgar):
        result = await get_risk_factors("AAPL", chunk_size=200)
        for chunk in result["chunks"]:
            assert "index" in chunk
            assert "text" in chunk
            assert "headline" in chunk

    @pytest.mark.asyncio
    async def test_get_risk_factors_all_fail(self, mock_routes):
        mock_routes.get("https://www.sec.gov/files/company_tickers.json").mock(
            return_value=httpx.Response(500)
        )
        result = await get_risk_factors("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_risk_factors_invalid_input(self):
        result = await get_risk_factors("")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_risk_factors_not_found(self, mock_routes):
        mock_routes.get("https://www.sec.gov/files/company_tickers.json").mock(
            return_value=httpx.Response(
                200,
                json={
                    "0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}
                },
            )
        )
        result = await get_risk_factors("ZZZNOTFOUND")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════
# Cache behavior
# ═══════════════════════════════════════════════════════════════════


class TestCache:
    @pytest.mark.asyncio
    async def test_cache_hit(self, mock_edgar):
        r1 = await search_filings("AAPL")
        r2 = await search_filings("AAPL")
        assert r1["filings"] == r2["filings"]
        # The company_tickers route should only be called once (cached)
