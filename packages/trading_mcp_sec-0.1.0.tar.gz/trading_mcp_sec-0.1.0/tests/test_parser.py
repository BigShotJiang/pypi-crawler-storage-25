"""Tests for the EDGAR HTML parser."""

from sec_server.parser import (
    chunk_text,
    extract_all_sections,
    extract_section,
    strip_html,
)

_SAMPLE_HTML = """
<html><body>
<h1>Test &amp; Filing</h1>
<p>Some   <b>bold</b>   text&nbsp;here.</p>
<script>var x = 1;</script>
<style>.cls { color: red; }</style>
<p>Another paragraph.</p>
</body></html>
"""

_SAMPLE_FILING = """
Item 1. Business

Apple Inc. designs and manufactures consumer electronics. The company sells
products worldwide through retail and online channels.

Item 1A. Risk Factors

The company faces risks from global economic uncertainty. Supply chain
disruptions could adversely affect operations.

Competition in the technology sector is intense.

Item 7. Management's Discussion and Analysis of Financial Condition

Revenue decreased 3% year-over-year. Services segment grew 9%.

Item 8. Financial Statements and Supplementary Data

See consolidated financial statements on page F-1.
"""


class TestStripHtml:
    def test_removes_tags(self):
        text = strip_html(_SAMPLE_HTML)
        assert "<b>" not in text
        assert "<p>" not in text

    def test_decodes_entities(self):
        text = strip_html(_SAMPLE_HTML)
        assert "Test & Filing" in text

    def test_removes_script_style(self):
        text = strip_html(_SAMPLE_HTML)
        assert "var x" not in text
        assert "color: red" not in text

    def test_collapses_whitespace(self):
        text = strip_html("<p>too   many    spaces</p>")
        assert "too many spaces" in text


class TestExtractSection:
    def test_extract_risk_factors(self):
        text = extract_section(_SAMPLE_FILING, "risk_factors")
        assert "global economic uncertainty" in text
        assert "competition" in text.lower()

    def test_extract_business(self):
        text = extract_section(_SAMPLE_FILING, "business")
        assert "consumer electronics" in text

    def test_extract_mda(self):
        text = extract_section(_SAMPLE_FILING, "mda")
        assert "Revenue decreased" in text

    def test_extract_financials(self):
        text = extract_section(_SAMPLE_FILING, "financials")
        assert "consolidated financial statements" in text

    def test_extract_missing_section(self):
        text = extract_section("No sections here at all", "risk_factors")
        assert text == ""

    def test_max_chars_truncation(self):
        text = extract_section(_SAMPLE_FILING, "risk_factors", max_chars=50)
        assert len(text) <= 50 + 10  # some slack for sentence boundary

    def test_extract_all(self):
        sections = extract_all_sections(_SAMPLE_FILING)
        assert "risk_factors" in sections
        assert "business" in sections
        assert "mda" in sections
        assert "financials" in sections


class TestChunkText:
    def test_basic_chunking(self):
        text = "Paragraph one.\n\nParagraph two.\n\nParagraph three."
        chunks = chunk_text(text, chunk_size=30)
        assert len(chunks) >= 2
        assert chunks[0]["index"] == 0
        assert "headline" in chunks[0]

    def test_empty_text(self):
        assert chunk_text("") == []

    def test_single_chunk(self):
        chunks = chunk_text("Short text.", chunk_size=1000)
        assert len(chunks) == 1
        assert chunks[0]["text"] == "Short text."

    def test_headline_extraction(self):
        chunks = chunk_text(
            "First sentence here. More text follows.\n\nAnother paragraph."
        )
        assert chunks[0]["headline"].startswith("First sentence here.")
