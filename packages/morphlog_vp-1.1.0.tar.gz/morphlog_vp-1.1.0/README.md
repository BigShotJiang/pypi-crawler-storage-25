# morphlog-vp

`morphlog-vp` provides structured training logs for model training loops.

It builds on `vpterm-vp` and includes:

- training headers
- live batch updates
- epoch summaries
- interruption/completion messages
- plain-text history log support

Install:

```bash
pip install morphlog-vp
```

Import:

```python
import morphlog
```
