"""Structured training logger with per-expert loss display.

Uses vpterm for beautiful terminal rendering.
"""

from morphlog.train_logger import TrainLogger
from morphlog.formatters import format_loss_breakdown, format_expert_losses

__version__: str = "1.1.0"
