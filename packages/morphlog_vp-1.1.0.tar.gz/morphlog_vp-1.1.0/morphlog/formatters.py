"""Formatting helpers for training metrics and per-expert losses."""

from __future__ import annotations

from vpterm.style import Style


def format_loss_value(value: float, precision: int = 4) -> str:
    """Format a loss value with color coding based on magnitude."""
    formatted = f"{value:.{precision}f}"
    if value > 10.0:
        return Style.bright_red(formatted)
    if value > 5.0:
        return Style.yellow(formatted)
    if value > 1.0:
        return Style.bright_yellow(formatted)
    return Style.bright_green(formatted)


def format_loss_breakdown(losses: dict[str, float], precision: int = 4) -> str:
    """Format a flat loss dict into a human-readable string.

    Supports keys like 'total', 'final', 'universal', 'family/slavic',
    'language/rus', etc.

    Returns a multi-line string with grouped losses.
    """
    lines: list[str] = []

    total = losses.get("total")
    final = losses.get("final")
    if total is not None:
        parts = [f"  {Style.metric_name('total')}{Style.dim('=')}{format_loss_value(total, precision)}"]
        if final is not None:
            parts.append(f"{Style.metric_name('final')}{Style.dim('=')}{format_loss_value(final, precision)}")
        lines.append("  ".join(parts))

    universal = losses.get("universal")
    if universal is not None:
        lines.append(f"  {Style.metric_name('universal')}{Style.dim('=')}{format_loss_value(universal, precision)}")

    family_losses = {key: value for key, value in losses.items() if key.startswith("family/")}
    if family_losses:
        parts = [f"  {Style.cyan('family')}  "]
        for key, value in sorted(family_losses.items()):
            expert_name = key.split("/", 1)[1]
            parts.append(f"{Style.label(expert_name)}{Style.dim('=')}{format_loss_value(value, precision)}")
        lines.append("  ".join(parts))

    language_losses = {key: value for key, value in losses.items() if key.startswith("language/")}
    if language_losses:
        parts = [f"  {Style.cyan('language')}"]
        for key, value in sorted(language_losses.items()):
            expert_name = key.split("/", 1)[1]
            parts.append(f"{Style.label(expert_name)}{Style.dim('=')}{format_loss_value(value, precision)}")
        lines.append("  ".join(parts))

    return "\n".join(lines)


def format_expert_losses(expert_losses: dict[str, float], precision: int = 4) -> str:
    """Format per-expert losses as a single line for compact display.

    Args:
        expert_losses: Dict like {"slavic": 5.12, "romance": 5.83}.
        precision: Decimal places.
    """
    parts = []
    for name, value in sorted(expert_losses.items()):
        parts.append(f"{Style.label(name)}{Style.dim('=')}{format_loss_value(value, precision)}")
    return "  ".join(parts)


def format_lr(learning_rate: float) -> str:
    """Format learning rate with scientific notation coloring."""
    return Style.metric_value(f"{learning_rate:.2e}")


def format_improvement(current: float, best: float) -> str:
    """Format a value showing improvement or degradation vs best."""
    formatted = f"{current:.4f}"
    if current <= best:
        return Style.improved(f"{formatted} ★")
    return format_loss_value(current)
