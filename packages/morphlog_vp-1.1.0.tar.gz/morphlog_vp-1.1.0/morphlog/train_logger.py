"""Structured training logger for CELMoE-style training loops.

Provides:
- a rich training header
- live-updating batch output inside each epoch
- permanent epoch summaries
- optional plain-text history log on disk
"""

from __future__ import annotations

import math
from pathlib import Path

from vpterm.kv import KeyValue
from vpterm.panel import Panel
from vpterm.progress import ProgressBar, format_duration, format_number
from vpterm.style import Style, strip_ansi
from vpterm.terminal import Terminal, get_terminal

from morphlog.formatters import format_improvement, format_loss_value, format_lr


class TrainLogger:
    """Structured logger for CELMoE training sessions.

    Batch updates within an epoch use a live block that overwrites itself.
    Permanent summaries are also recorded into an optional plain-text log file.
    """

    def __init__(self, terminal: Terminal | None = None, log_file: Path | None = None) -> None:
        self.terminal = terminal or get_terminal()
        self._log_lines: list[str] = []
        self._log_file = log_file

    @property
    def history_path(self) -> Path | None:
        """Return the optional plain-text history log path."""
        return self._log_file

    def _record(self, text: str) -> None:
        """Append a plain-text copy of a record to memory and optional file."""
        plain_text = strip_ansi(text)
        self._log_lines.append(plain_text)
        if self._log_file is not None:
            self._log_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self._log_file, "a", encoding="utf-8") as handle:
                handle.write(plain_text + "\n\n")

    def handle_shortcuts(self) -> bool:
        """Handle runtime terminal shortcuts.

        Currently supports Ctrl+O to open the full history log.
        """
        if self._log_file is None or not self.terminal.poll_ctrl_o():
            return False
        return self.terminal.open_path(self._log_file)

    def training_header(
        self,
        *,
        version: str,
        model_family: str,
        model_series: str,
        stage: str,
        device: str,
        amp: bool,
        train_rows: int,
        dev_rows: int,
        num_languages: int,
        num_families: int,
        families: list[str],
        languages: list[str],
        max_len: int,
        max_features: int,
        d_model: int,
        dim_ff: int,
        num_heads: int,
        num_kv_heads: int,
        universal_layers: int,
        family_layers: int,
        language_layers: int,
        total_params: int,
        trainable_params: int,
        epochs: int,
        batch_size: int,
        train_batches: int,
        dev_batches: int,
        total_steps: int,
        warmup_steps: int,
        lr: float,
        weight_decay: float,
        betas: tuple[float, float],
        output_dir: str,
        loss_weights: dict[str, float],
    ) -> None:
        """Print the full training configuration header."""
        panel = Panel(title=f"MorphFormer {model_series} - CELMoE Training")

        panel.add_section("Run")
        panel.add_kv("version", version)
        panel.add_kv("family", model_family)
        panel.add_kv("stage", Style.bold(stage))
        panel.add_kv("device", f"{device}  {'AMP' if amp else 'FP32'}")
        panel.add_kv("output", output_dir)

        panel.add_blank()
        panel.add_section("Data")
        panel.add_kv("train", f"{format_number(train_rows)} rows")
        panel.add_kv("dev", f"{format_number(dev_rows)} rows")
        panel.add_kv("languages", f"{num_languages}  {Style.dim(' '.join(languages))}")
        panel.add_kv("families", f"{num_families}  {Style.dim(' '.join(families))}")
        panel.add_kv("max length", str(max_len))
        panel.add_kv("max features", str(max_features))

        panel.add_blank()
        panel.add_section("Model")
        panel.add_kv("d_model", str(d_model))
        panel.add_kv("dim_ff", str(dim_ff))
        panel.add_kv("heads", f"{num_heads} query  {num_kv_heads} kv")
        panel.add_kv("layers", f"{universal_layers} universal  {family_layers} family  {language_layers} language")
        panel.add_kv("parameters", f"{format_number(total_params)} total  {format_number(trainable_params)} trainable")

        panel.add_blank()
        panel.add_section("Training")
        panel.add_kv("epochs", str(epochs))
        panel.add_kv("batch size", str(batch_size))
        panel.add_kv("batches", f"{format_number(train_batches)} train  {format_number(dev_batches)} dev")
        panel.add_kv("steps", f"{format_number(total_steps)} total  {format_number(warmup_steps)} warmup")

        panel.add_blank()
        panel.add_section("Optimizer")
        panel.add_kv("lr", str(lr))
        panel.add_kv("weight decay", str(weight_decay))
        panel.add_kv("betas", str(list(betas)))

        panel.add_blank()
        panel.add_section("Loss Weights")
        for name, weight in sorted(loss_weights.items()):
            panel.add_kv(name, f"{weight:.2f}")

        rendered_panel = panel.render()
        self.terminal.writeln(rendered_panel)
        self._record(rendered_panel)

        if self._log_file is not None:
            history_hint = (
                f" {Style.dim('full history')} {Style.cyan(str(self._log_file))} "
                f"{Style.dim('(Ctrl+O to open)')}"
            )
            self.terminal.writeln(history_hint)
            self._record(history_hint)

        self.terminal.blank_line()

    def epoch_start(self, epoch: int, total_epochs: int, train_batches: int, dev_batches: int) -> None:
        """Log epoch start."""
        self.terminal.end_live()
        self.terminal.blank_line()
        self.terminal.header(f"Epoch {epoch}/{total_epochs}")
        batches_line = (
            f"  {Style.dim('train')} {format_number(train_batches)} batches  "
            f"{Style.dim('dev')} {format_number(dev_batches)} batches"
        )
        self.terminal.writeln(batches_line)
        self._record(f"Epoch {epoch}/{total_epochs}\n{strip_ansi(batches_line)}")
        self.terminal.blank_line()

    def batch_update(
        self,
        *,
        epoch: int,
        total_epochs: int,
        batch: int,
        total_batches: int,
        step: int,
        total_steps: int,
        learning_rate: float,
        losses: dict[str, float],
        elapsed_seconds: float,
        total_completed_batches: int,
        total_train_batches: int,
        best_dev_loss: float,
    ) -> None:
        """Log a live-updating batch block with per-expert loss breakdown."""
        seconds_per_batch = elapsed_seconds / max(1, total_completed_batches)
        remaining_batches = max(0, total_train_batches - total_completed_batches)
        remaining_seconds = seconds_per_batch * remaining_batches

        progress = ProgressBar(total=total_batches, width=20)
        progress_line = f"  {progress.render_with_label(batch, 'progress')}"

        line = KeyValue(separator="  ")
        line.add("epoch", f"{epoch}/{total_epochs}")
        line.add("batch", f"{batch}/{total_batches}")
        line.add("step", f"{step}/{total_steps}")
        line.add_raw(f"{Style.metric_name('lr')}{Style.dim('=')}{format_lr(learning_rate)}")
        main_line = line.render()

        loss_parts: list[str] = []
        total_loss = losses.get("total")
        final_loss = losses.get("final")
        universal_loss = losses.get("universal")
        if total_loss is not None:
            loss_parts.append(f"{Style.metric_name('loss')}{Style.dim('=')}{format_loss_value(total_loss)}")
        if final_loss is not None:
            loss_parts.append(f"{Style.metric_name('final')}{Style.dim('=')}{format_loss_value(final_loss)}")
        if universal_loss is not None:
            loss_parts.append(f"{Style.metric_name('universal')}{Style.dim('=')}{format_loss_value(universal_loss)}")
        loss_line = "  ".join(loss_parts)

        family_losses = {key: value for key, value in sorted(losses.items()) if key.startswith("family/")}
        language_losses = {key: value for key, value in sorted(losses.items()) if key.startswith("language/")}

        output_lines: list[str] = [
            f"  {main_line}",
            f"  {loss_line}",
            progress_line,
        ]

        if family_losses:
            family_parts = [f"  {Style.cyan('family')}  "]
            for key, value in family_losses.items():
                expert_name = key.split("/", 1)[1]
                family_parts.append(f"{Style.label(expert_name)}{Style.dim('=')}{format_loss_value(value)}")
            output_lines.append(" ".join(family_parts))

        if language_losses:
            language_parts = [f"  {Style.cyan('language')}"]
            for key, value in language_losses.items():
                expert_name = key.split("/", 1)[1]
                language_parts.append(f"{Style.label(expert_name)}{Style.dim('=')}{format_loss_value(value)}")
            output_lines.append(" ".join(language_parts))

        best_display = "n/a" if math.isinf(best_dev_loss) else f"{best_dev_loss:.4f}"
        time_line = (
            f"  {Style.dim('elapsed')}{Style.dim('=')}{Style.timestamp(format_duration(elapsed_seconds))}"
            f"  {Style.dim('remaining')}{Style.dim('=')}{Style.timestamp(format_duration(remaining_seconds))}"
            f"  {Style.dim('best dev')}{Style.dim('=')}{Style.metric_value(best_display)}"
        )
        output_lines.append(time_line)

        block = "\n".join(output_lines)
        self.terminal.write_live(block)
        self._record(block)

    def epoch_end(
        self,
        *,
        epoch: int,
        total_epochs: int,
        dev_loss: float,
        best_dev_loss: float,
        improved: bool,
        epoch_elapsed: float,
        total_elapsed: float,
        remaining_seconds: float,
        checkpoint_path: str | None,
        dev_expert_losses: dict[str, float] | None = None,
    ) -> None:
        """Log epoch completion with dev evaluation results."""
        self.terminal.end_live()
        self.terminal.blank_line()

        status_icon = Style.success("+") if improved else Style.dim(".")
        dev_display = format_improvement(dev_loss, best_dev_loss) if improved else format_loss_value(dev_loss)
        best_display = format_loss_value(best_dev_loss)

        summary = (
            f" {status_icon} {Style.bold(f'Epoch {epoch}/{total_epochs}')}"
            f"  {Style.dim('dev loss')}{Style.dim('=')}{dev_display}"
            f"  {Style.dim('best')}{Style.dim('=')}{best_display}"
            f"  {Style.dim('epoch time')}{Style.dim('=')}{Style.timestamp(format_duration(epoch_elapsed))}"
            f"  {Style.dim('elapsed')}{Style.dim('=')}{Style.timestamp(format_duration(total_elapsed))}"
            f"  {Style.dim('remaining')}{Style.dim('=')}{Style.timestamp(format_duration(remaining_seconds))}"
        )
        self.terminal.writeln(summary)
        self._record(summary)

        if dev_expert_losses:
            family_losses = {key: value for key, value in dev_expert_losses.items() if key.startswith("family/")}
            language_losses = {key: value for key, value in dev_expert_losses.items() if key.startswith("language/")}

            if family_losses:
                family_parts = [f"   {Style.cyan('dev family')}"]
                for key, value in sorted(family_losses.items()):
                    name = key.split("/", 1)[1]
                    family_parts.append(f"{Style.label(name)}{Style.dim('=')}{format_loss_value(value)}")
                family_line = " ".join(family_parts)
                self.terminal.writeln(family_line)
                self._record(family_line)

            if language_losses:
                language_parts = [f"   {Style.cyan('dev language')}"]
                for key, value in sorted(language_losses.items()):
                    name = key.split("/", 1)[1]
                    language_parts.append(f"{Style.label(name)}{Style.dim('=')}{format_loss_value(value)}")
                language_line = " ".join(language_parts)
                self.terminal.writeln(language_line)
                self._record(language_line)

        if checkpoint_path:
            checkpoint_line = f"   {Style.dim('checkpoint')} {Style.green(checkpoint_path)}"
            self.terminal.writeln(checkpoint_line)
            self._record(checkpoint_line)

        self.terminal.blank_line()

    def training_interrupted(
        self,
        epoch: int,
        total_epochs: int,
        batch: int,
        total_batches: int,
        step: int,
        total_steps: int,
        elapsed_seconds: float,
        checkpoint_path: str,
    ) -> None:
        """Log training interruption."""
        self.terminal.end_live()
        self.terminal.blank_line()

        summary = (
            f" {Style.warning('!')} {Style.bold('Training interrupted')}"
            f"  epoch={epoch}/{total_epochs}"
            f"  batch={batch}/{total_batches}"
            f"  step={step}/{total_steps}"
            f"  elapsed={Style.timestamp(format_duration(elapsed_seconds))}"
        )
        checkpoint_line = f"   {Style.dim('checkpoint')} {Style.yellow(checkpoint_path)}"

        self.terminal.writeln(summary)
        self.terminal.writeln(checkpoint_line)
        self._record(summary)
        self._record(checkpoint_line)
        if self._log_file is not None:
            history_line = f"   {Style.dim('full log')} {Style.cyan(str(self._log_file))} {Style.dim('(Ctrl+O to open)')}"
            self.terminal.writeln(history_line)
            self._record(history_line)
        self.terminal.blank_line()

    def training_complete(self, best_path: str, best_dev_loss: float, total_elapsed: float) -> None:
        """Log training completion."""
        self.terminal.end_live()
        self.terminal.blank_line()

        summary = (
            f" {Style.success('+')} {Style.bold('Training complete')}"
            f"  best dev={Style.improved(f'{best_dev_loss:.4f}')}"
            f"  time={Style.timestamp(format_duration(total_elapsed))}"
        )
        best_line = f"   {Style.dim('best checkpoint')} {Style.green(best_path)}"

        self.terminal.writeln(summary)
        self.terminal.writeln(best_line)
        self._record(summary)
        self._record(best_line)

        if self._log_file is not None:
            history_line = f"   {Style.dim('full log')} {Style.cyan(str(self._log_file))} {Style.dim('(Ctrl+O to open)')}"
            self.terminal.writeln(history_line)
            self._record(history_line)

        self.terminal.blank_line()
