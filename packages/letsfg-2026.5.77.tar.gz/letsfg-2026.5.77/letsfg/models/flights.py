"""Flight search request/response models — multi-provider."""

from __future__ import annotations

import re
from datetime import date, datetime, timezone
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


def _raw_duration_seconds(departure: datetime, arrival: datetime) -> int:
    try:
        return max(int((arrival - departure).total_seconds()), 0)
    except Exception:
        return 0


def _airport_duration_seconds(
    departure: datetime,
    arrival: datetime,
    origin: str,
    destination: str,
) -> int:
    if departure.year <= 2000 or arrival.year <= 2000 or not origin or not destination:
        return 0

    try:
        from letsfg.connectors.airport_tz import duration_seconds_from_local_times

        return duration_seconds_from_local_times(departure, arrival, origin, destination)
    except Exception:
        return 0


def _airport_local_naive(value: datetime, airport: str) -> datetime:
    if value.tzinfo is None or not airport:
        return value

    try:
        from letsfg.connectors.airport_tz import get_airport_tz

        airport_tz = get_airport_tz(airport)
    except Exception:
        airport_tz = None

    try:
        if airport_tz is not None:
            return value.astimezone(airport_tz).replace(tzinfo=None)
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    except Exception:
        return value.replace(tzinfo=None)


# ── Request ──────────────────────────────────────────────────────────────────

class FlightSearchRequest(BaseModel):
    """Parameters for a flight search — FREE for agents."""

    origin: str = Field(
        ...,
        description="IATA code of departure airport/city (e.g. 'PRG', 'LON')",
        min_length=2,
        max_length=4,
    )
    destination: str = Field(
        ...,
        description="IATA code of arrival airport/city (e.g. 'BCN', 'NYC')",
        min_length=2,
        max_length=4,
    )
    date_from: date = Field(..., description="Departure date")
    date_to: Optional[date] = Field(None, description="Latest departure date")
    return_from: Optional[date] = Field(None, description="Return date (omit for one-way)")
    return_to: Optional[date] = Field(None, description="Latest return date")
    adults: int = Field(1, ge=1, le=9)
    children: int = Field(0, ge=0, le=9)
    infants: int = Field(0, ge=0, le=9)
    cabin_class: Optional[str] = Field(
        None,
        description="M (economy), W (premium economy), C (business), F (first)",
        pattern=r"^[MWCF]$",
    )
    max_stopovers: int = Field(2, ge=0, le=4, description="Max connections per direction")
    currency: str = Field("EUR", min_length=3, max_length=3)
    locale: str = Field("en", description="Language for city/airport names")
    limit: int = Field(50, ge=1, le=200, description="Max results to return")
    sort: str = Field("price", description="Sort by: price, duration, departure_time")
    departure_time_from: Optional[str] = Field(
        None,
        description="Earliest departure time HH:MM (e.g. '06:00' for morning flights)",
        pattern=r"^([01]?[0-9]|2[0-3]):[0-5][0-9]$",
    )
    departure_time_to: Optional[str] = Field(
        None,
        description="Latest departure time HH:MM (e.g. '14:00' for flights before 2pm)",
        pattern=r"^([01]?[0-9]|2[0-3]):[0-5][0-9]$",
    )
    provider_filters: dict[str, Any] = Field(
        default_factory=dict,
        description="Provider-specific filter payloads keyed by provider name, e.g. {'google_flights': {...}}",
    )
    country_filter: Optional[frozenset[str]] = Field(
        default=None,
        description="ISO alpha-2 countries used to filter source markets and route endpoints",
    )
    include_global: bool = Field(
        False,
        description="Include global aggregators when country_filter is active",
    )

    @field_validator("country_filter", mode="before")
    @classmethod
    def validate_country_filter(cls, v: Any) -> Optional[frozenset[str]]:
        if v is None:
            return None
        return frozenset(str(code).strip().upper() for code in v if str(code).strip())

    @field_validator("origin", "destination")
    @classmethod
    def validate_iata_code(cls, v: str) -> str:
        v = v.strip().upper()
        if not re.fullmatch(r"[A-Z]{2,4}", v):
            raise ValueError(f"Invalid IATA code '{v}': must be 2-4 letters (e.g. 'LON', 'PRG')")
        return v

    @field_validator("date_from")
    @classmethod
    def validate_date_not_past(cls, v: date) -> date:
        if v < date.today():
            raise ValueError(f"date_from ({v}) cannot be in the past")
        return v


# ── Response ─────────────────────────────────────────────────────────────────

class FlightSegment(BaseModel):
    """A single flight leg (e.g., PRG→FRA)."""

    airline: str = Field(..., description="Operating carrier IATA code")
    airline_name: str = ""
    flight_no: str = ""
    origin: str = Field(..., description="Departure IATA")
    destination: str = Field(..., description="Arrival IATA")
    origin_city: str = ""
    destination_city: str = ""
    departure: datetime
    arrival: datetime
    duration_seconds: int = 0
    cabin_class: str = "economy"
    aircraft: str = ""

    @model_validator(mode="after")
    def backfill_duration_seconds(self) -> "FlightSegment":
        self.departure = _airport_local_naive(self.departure, self.origin)
        self.arrival = _airport_local_naive(self.arrival, self.destination)

        computed = _airport_duration_seconds(
            self.departure,
            self.arrival,
            self.origin,
            self.destination,
        )
        if computed <= 0:
            return self

        raw = _raw_duration_seconds(self.departure, self.arrival)
        if self.duration_seconds <= 0 or self.duration_seconds == raw:
            self.duration_seconds = computed

        return self


class FlightRoute(BaseModel):
    """One direction (outbound or return) composed of segments."""

    segments: list[FlightSegment] = []
    total_duration_seconds: int = 0
    stopovers: int = 0

    @model_validator(mode="after")
    def backfill_total_duration_seconds(self) -> "FlightRoute":
        if not self.segments:
            return self

        first_segment = self.segments[0]
        last_segment = self.segments[-1]
        computed = _airport_duration_seconds(
            first_segment.departure,
            last_segment.arrival,
            first_segment.origin,
            last_segment.destination,
        )
        if computed <= 0:
            computed = sum(max(segment.duration_seconds, 0) for segment in self.segments)
        if computed <= 0:
            return self

        raw = _raw_duration_seconds(first_segment.departure, last_segment.arrival)
        if self.total_duration_seconds <= 0 or self.total_duration_seconds == raw:
            self.total_duration_seconds = computed

        return self


class FlightOffer(BaseModel):
    """
    A single flight offer.

    A single flight offer with full itinerary, pricing, and booking details.
    """

    id: str = Field(..., description="Unique offer ID")
    price: float
    currency: str = "EUR"
    price_formatted: str = ""
    outbound: FlightRoute
    inbound: Optional[FlightRoute] = None
    airlines: list[str] = Field(default_factory=list, description="All airlines in itinerary")
    owner_airline: str = Field("", description="Validating carrier")
    bags_price: dict[str, Any] = Field(default_factory=dict, description="Baggage pricing")
    availability_seats: Optional[int] = None
    conditions: dict[str, str] = Field(default_factory=dict, description="Refund/change policies")
    source: str = Field("", description="Provider source tag (e.g. 'duffel', 'amadeus', 'kiwi', 'travelpayouts')")
    source_tier: str = Field(
        "paid",
        description=(
            "Data source cost tier: "
            "'free' = cached/aggregated data (Travelpayouts), "
            "'low' = affordable API (Kiwi Tequila), "
            "'paid' = GDS/NDC providers (Duffel, Amadeus), "
            "'protocol' = LCC direct via Agent Interaction Protocol (Ryanair, Wizzair)"
        ),
    )
    is_locked: bool = Field(False, description="Whether booking details require unlock")
    fetched_at: datetime = Field(default_factory=datetime.utcnow)
    booking_url: str = Field("", description="Only available after unlock")
    price_normalized: Optional[float] = Field(None, description="Price converted to the search currency for sorting")


class AirlineSummary(BaseModel):
    """Cheapest offer summary for one airline."""
    airline_code: str
    airline_name: str = ""
    cheapest_price: float
    currency: str = "EUR"
    offer_count: int
    cheapest_offer_id: str = ""
    sample_route: str = Field("", description="e.g. KRK→WAW→BER")


class FlightSearchResponse(BaseModel):
    """Full response from a flight search — always FREE."""

    search_id: str = ""
    offer_request_id: str = Field("", description="Offer request ID (for booking flow)")
    passenger_ids: list[str] = Field(
        default_factory=list,
        description="Passenger IDs from the offer request — REQUIRED for booking. "
        "Map these 1:1 to your passengers when calling POST /bookings/book.",
    )

    origin: str
    destination: str
    currency: str = "EUR"
    offers: list[FlightOffer] = []
    total_results: int = 0
    airlines_summary: list[AirlineSummary] = Field(
        default_factory=list,
        description="Cheapest offer per airline — quick overview of all options.",
    )
    search_params: dict = Field(default_factory=dict)
    source_tiers: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Breakdown of which source tiers were used in this search. "
            "Keys are tier names, values describe the data source. "
            "Example: {'paid': 'Duffel (NDC), Amadeus (GDS)', 'low': 'Kiwi Tequila', 'free': 'Travelpayouts'}"
        ),
    )
    pricing_note: str = Field(
        default="Search is free. Booking is free. No hidden fees.",
        description="Pricing transparency for agents",
    )


# ── Public offer (SDK-facing, no sensitive booking data) ─────────────────────

#: IATA codes of well-known low-cost carriers — used to mask the owner airline
#: until the user pays on the website.
LCC_IATA: frozenset[str] = frozenset({
    "FR", "W6", "W4", "W9", "U2", "RK", "EI", "DY", "N0", "VY", "V7",
    "LS", "HV", "PC", "XQ", "WN", "B6", "NK", "F9", "G4", "AK", "FZ",
    "G9", "6E", "5J",
})


def get_airline_category(iata: str) -> str:
    """Return ``'lcc'`` for low-cost carriers, ``'fsc'`` for full-service."""
    return "lcc" if iata.upper() in LCC_IATA else "fsc"


def _strip_sensitive_conditions(conditions: dict) -> dict:
    """Keep only publicly-safe condition keys."""
    _SAFE_KEYS = {"refund_before_departure", "change_before_departure"}
    return {k: v for k, v in conditions.items() if k in _SAFE_KEYS}


class PublicFlightOffer(BaseModel):
    """
    A masked flight offer returned to SDK callers before unlock.

    Sensitive fields (exact booking URL, full airline name) are hidden until
    the user pays on the website.  After payment the SDK can call
    ``GET /api/developers/payment-verify?token={payment_token}`` every ~5 s
    for up to 60 s to retrieve the booking URL.
    """

    id: str
    price: float
    currency: str = "EUR"
    price_formatted: str = ""
    owner_airline: str = ""
    airlines: list[str] = Field(default_factory=list)
    origin: str = ""
    destination: str = ""
    outbound: Optional[Any] = None
    inbound: Optional[Any] = None
    conditions: dict[str, str] = Field(default_factory=dict)
    unlock_url: str = Field(
        "",
        description=(
            "Open this URL in a browser to pay and unlock the booking link. "
            "After payment, poll the payment-verify endpoint with ``payment_token``."
        ),
    )
    payment_token: str = Field(
        "",
        description=(
            "Poll ``GET https://letsfg.co/api/developers/payment-verify?token=<value>`` "
            "every 5 seconds (up to ~60 s) after the user completes payment.  "
            "Returns ``{verified: true, booking_url: '...'}`` when ready."
        ),
    )


def to_public_offer(
    offer: FlightOffer,
    *,
    unlock_url: str = "",
    payment_token: str = "",
) -> PublicFlightOffer:
    """Convert a raw ``FlightOffer`` to a ``PublicFlightOffer`` safe for SDK output."""
    origin = (
        offer.outbound.segments[0].origin
        if offer.outbound and offer.outbound.segments
        else ""
    )
    destination = (
        offer.outbound.segments[-1].destination
        if offer.outbound and offer.outbound.segments
        else ""
    )
    return PublicFlightOffer(
        id=offer.id,
        price=offer.price,
        currency=offer.currency,
        price_formatted=offer.price_formatted,
        owner_airline=offer.owner_airline,
        airlines=list(offer.airlines),
        origin=origin,
        destination=destination,
        outbound=offer.outbound,
        inbound=offer.inbound,
        conditions=_strip_sensitive_conditions(dict(offer.conditions)),
        unlock_url=unlock_url,
        payment_token=payment_token,
    )
