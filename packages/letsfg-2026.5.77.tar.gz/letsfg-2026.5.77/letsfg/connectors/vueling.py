"""
Vueling hybrid scraper — direct API first, Playwright fallback.

Vueling (IATA: VY) is a Spanish low-cost carrier.
Booking engine: tickets.vueling.com (Angular 17 SPA).

Hybrid strategy (Mar 2026):
1. Try direct HTTP via curl_cffi (Chrome TLS fingerprint):
   a. Auth: POST ams.vueling.com/asm/v1/Auth → Bearer JWT (1199s TTL)
   b. GQL:  POST ams.vueling.com/avy/v1/graphql → all flights for date
   - Token is cached and reused until close to expiry
   - ~0.7s total (auth + search), no browser needed
2. If direct API fails → fall back to full Playwright browser flow
   - Navigate to tickets.vueling.com, capture GQL request, replay in-page

GQL query extracted from Angular bundle (chunk-EXIIY677.js):
  query GetAvy($requestAVY: AvailabilityRequestGraphQLInput!) {
    amsAvy(amsAvailabilityRequest: $requestAVY) { ... }
  }
  Variables: requestAVY.request.{criteria, passengers, flightType, ...}
  Returns: trips (journeys with segments) + faresAvailable (prices per fare class)
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import re
import time
from datetime import datetime
from typing import Any, Optional

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .browser import auto_block_if_proxied, get_curl_cffi_proxies, launch_headed_browser

logger = logging.getLogger(__name__)

_ancillary_cache: dict[str, tuple[float, dict]] = {}
_ANCILLARY_CACHE_TTL = 1800  # 30 min

# ── Direct API constants ─────────────────────────────────
_AUTH_URL = "https://ams.vueling.com/asm/v1/Auth"
_GQL_URL = "https://ams.vueling.com/avy/v1/graphql"
_PROFILE_ID = "e8ffa738-cb67-4a02-b501-9bfd975a4b65"
_TOKEN_MARGIN = 60  # refresh token 60s before expiry

# Cached token state
_token: str | None = None
_token_expiry: float = 0  # monotonic timestamp

_GQL_QUERY = """query GetAvy($requestAVY:AvailabilityRequestGraphQLInput!){ amsAvy (amsAvailabilityRequest  : $requestAVY) {
      currencyCode,
      trips {
        trips {
        journeysAvailableByMarket  {
            key,
          value{
                journeyKey,
                segments {
                    carrierCodeShare,
                    segmentType,
                    segmentKey,
                    identifier {
                        carrierCode,
                        identifier
                    },
                    designator{
                        arrival,
                        departure,
                        destination,
                        origin
                    },
                    segmentDuration,
                    legs {
                        legKey,
                        legInfo {
                            operatingCarrier,
                            operatedByText,
                            departureTerminal,
                            arrivalTerminal,
                            arrivalTimeUtc,
                            departureTimeUtc,
                            departureTimeVariant,
                            lid,
                            sold
                        },
                        ssrs {
                            available,
                            ssrNestCode
                        }
                    },
                },designator{
                    arrival,
                    departure,
                    destination,
                    origin
                },
                fares{
                    fareAvailabilityKey,
                    fareSellKey,
                    details {
                        serviceBundleSetCode,
                        bundleReferences,
                        reference,
                        availableCount
                    }
                },
                flightType,
                duration,
                connectionTime
            }
        }
      }
    },
    faresAvailable {
      value {
            fares {
                productClass,
                classOfService,
                fareBasisCode,
                passengerFares {
                    amsFareAmount
                },
                reference,
                ruleNumber
            },
            fareAvailabilityKey
      }
    },
    bundleOffers {
        key,
        value {
            bundlePrices{
                totalPrice, taxTotal, feePrice, passengerType,
                program {
                    code, level
                },
                bundleSsrPrices {
                    bundleSsrPrice, taxTotal, ssrCode
                }
            }, bundleCode
        }
    }
 }
}"""

_VIEWPORTS = [
    {"width": 1366, "height": 768},
    {"width": 1440, "height": 900},
    {"width": 1920, "height": 1080},
    {"width": 1280, "height": 720},
]
_TIMEZONES = ["Europe/London", "Europe/Berlin", "Europe/Paris", "Europe/Madrid"]

_pw_instance = None
_browser = None
_browser_lock: Optional[asyncio.Lock] = None


def _get_lock() -> asyncio.Lock:
    global _browser_lock
    if _browser_lock is None:
        _browser_lock = asyncio.Lock()
    return _browser_lock


async def _get_browser():
    """Shared headed Chromium (launched once, reused across searches)."""
    global _pw_instance, _browser
    lock = _get_lock()
    async with lock:
        if _browser and _browser.is_connected():
            return _browser
        from .browser import launch_headed_browser
        _browser = await launch_headed_browser()
        logger.info("Vueling: browser launched")
        return _browser


async def _ensure_token() -> str | None:
    """Get a valid Bearer token, refreshing if needed."""
    global _token, _token_expiry
    if _token and time.monotonic() < _token_expiry:
        return _token
    try:
        from curl_cffi import requests as cffi_requests
        ses = cffi_requests.Session(impersonate="chrome131", proxies=get_curl_cffi_proxies())
        r = ses.post(_AUTH_URL, json={"profileId": _PROFILE_ID}, timeout=10)
        if r.status_code != 200:
            logger.warning("Vueling auth failed: %s %s", r.status_code, r.text[:200])
            return None
        data = r.json()
        tok = data.get("token") or data.get("accessToken")
        if not tok:
            for v in data.values():
                if isinstance(v, str) and len(v) > 50:
                    tok = v
                    break
        if tok:
            ttl = data.get("expiresIn", data.get("expires_in", 1199))
            _token = tok
            _token_expiry = time.monotonic() + ttl - _TOKEN_MARGIN
            logger.info("Vueling: auth token acquired (TTL=%ss)", ttl)
            return tok
        logger.warning("Vueling: no token in auth response")
        return None
    except Exception as e:
        logger.warning("Vueling: auth error: %s", e)
        return None


class VuelingConnectorClient:
    """Vueling hybrid scraper — direct API first, Playwright fallback."""

    def __init__(self, timeout: float = 60.0):
        self.timeout = timeout
        self._route_rejected = False

    async def close(self):
        pass  # Browser is shared singleton

    # ── Main entry point ─────────────────────────────────
    async def search_flights(self, req: FlightSearchRequest) -> FlightSearchResponse:
        ob_result = await self._search_ow(req)
        if req.return_from and ob_result.total_results > 0:
            ib_req = req.model_copy(update={"origin": req.destination, "destination": req.origin, "date_from": req.return_from, "return_from": None})
            ib_result = await self._search_ow(ib_req)
            if ib_result.total_results > 0:
                ob_result.offers = self._combine_rt(ob_result.offers, ib_result.offers, req)
                ob_result.total_results = len(ob_result.offers)
        if ob_result.offers:
            segs = ob_result.offers[0].outbound.segments if ob_result.offers[0].outbound else []
            anc_origin = segs[0].origin if segs else req.origin
            anc_dest = segs[-1].destination if segs else req.destination
            try:
                ancillary = await asyncio.wait_for(
                    self._fetch_ancillaries(anc_origin, anc_dest, req.date_from.isoformat(), req.adults, ob_result.currency),
                    timeout=45.0,
                )
                if ancillary:
                    self._apply_ancillaries(ob_result.offers, ancillary)
            except (asyncio.TimeoutError, TimeoutError):
                logger.debug("Ancillary fetch timed out for %s\u2192%s", anc_origin, anc_dest)
            except Exception as _anc_err:
                logger.debug("Ancillary fetch error for %s\u2192%s: %s", anc_origin, anc_dest, _anc_err)
        return ob_result


    async def _fetch_ancillaries(
        self, origin: str, dest: str, date_str: str, adults: int, currency: str
    ) -> dict | None:
        # Ancillary prices are now extracted inline in _parse_graphql / _parse_graphql_return
        # (IB fare price - BB fare price = live checked bag cost per journey).
        # Returning None lets the engine's _enrich_ancillaries act as fallback for
        # offers where both BB and IB were not available (i.e. bags_price is empty).
        return None
    def _apply_ancillaries(self, offers: list, ancillary: dict) -> None:
        bags_note = ancillary.get("bags_note")
        seat_note = ancillary.get("seat_note")
        bags_from = ancillary.get("bags_from")
        checked_bag_note = ancillary.get("checked_bag_note")
        checked_bag_from = ancillary.get("checked_bag_from")
        anc_currency = ancillary.get("currency", "EUR")
        for offer in offers:
            if bags_note:
                offer.conditions["cabin_bag"] = bags_note
            if seat_note:
                offer.conditions["seat"] = seat_note
            if checked_bag_note:
                offer.conditions["checked_bag"] = checked_bag_note
            if bags_from == 0.0:
                offer.bags_price["cabin_bag"] = 0.0
            if checked_bag_from == 0.0:
                offer.bags_price["checked_bag"] = 0.0
    async def _search_ow(self, req: FlightSearchRequest) -> FlightSearchResponse:
        # Try direct API first (no browser)
        result = await self._search_via_api(req)
        if result and result.total_results > 0:
            return result
        # If API explicitly said "no valid markets", the route doesn't exist —
        # no point launching browser fallback.
        if self._route_rejected:
            logger.info("Vueling: route %s->%s not in network, skipping browser", req.origin, req.destination)
            return result or self._empty(req)
        logger.info("Vueling: API path returned 0 results, trying Playwright fallback")
        return await self._search_via_browser(req)

    # ── Direct API path (curl_cffi) ──────────────────────
    async def _search_via_api(self, req: FlightSearchRequest) -> FlightSearchResponse | None:
        t0 = time.monotonic()
        token = await _ensure_token()
        if not token:
            return None
        try:
            from curl_cffi import requests as cffi_requests

            criteria = [
                {
                    "origin": req.origin,
                    "destination": req.destination,
                    "date": req.date_from.strftime("%Y-%m-%d"),
                }
            ]
            itinerary_type = "ONE_WAY"
            if req.return_from:
                criteria.append({
                    "origin": req.destination,
                    "destination": req.origin,
                    "date": req.return_from.strftime("%Y-%m-%d"),
                })
                itinerary_type = "ROUND_TRIP"

            variables = {
                "requestAVY": {
                    "request": {
                        "criteria": criteria,
                        "cultureCode": "en-GB",
                        "currencyCode": req.currency or "EUR",
                        "flightType": "ALL",
                        "itineraryType": itinerary_type,
                        "maxConnections": 10,
                        "passengers": [
                            {"count": req.adults, "type": "Adult"},
                        ],
                        "serviceCode": "Search1Day",
                        "servicesToRequest": [],
                        "bundleControlFilter": 2,
                    },
                    "trackingPoint": "BBV",
                }
            }

            # Add children if requested
            if req.children:
                variables["requestAVY"]["request"]["passengers"].append(
                    {"count": req.children, "type": "Child"}
                )
            if req.infants:
                variables["requestAVY"]["request"]["servicesToRequest"].append(
                    {"count": req.infants, "serviceCode": "INFANT"}
                )

            payload = json.dumps({"query": _GQL_QUERY, "variables": variables})
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            }

            ses = cffi_requests.Session(impersonate="chrome131", proxies=get_curl_cffi_proxies())
            r = ses.post(_GQL_URL, data=payload, headers=headers, timeout=15)

            if r.status_code != 200:
                logger.warning("Vueling GQL HTTP %s: %s", r.status_code, r.text[:300])
                return None

            data = r.json()
            if "errors" in data:
                errors_str = str(data["errors"])
                logger.warning("Vueling GQL errors: %s", data["errors"])
                # "No valid markets" = route doesn't exist, skip browser fallback
                if "no valid markets" in errors_str.lower():
                    self._route_rejected = True
                return None

            elapsed = time.monotonic() - t0
            outbound_offers = self._parse_graphql(data, req)

            # Parse return journeys + build combos for RT
            if req.return_from and outbound_offers:
                inbound_offers = self._parse_graphql_return(data, req)
                if inbound_offers:
                    combos = self._build_rt_combos(outbound_offers, inbound_offers, req)
                    if combos:
                        outbound_offers = combos + outbound_offers

            logger.info(
                "Vueling API: %d offers %s->%s in %.2fs",
                len(outbound_offers), req.origin, req.destination, elapsed,
            )
            return self._build_response(outbound_offers, req, elapsed)

        except Exception as e:
            logger.warning("Vueling API error: %s", e)
            return None

    # ── Playwright fallback ──────────────────────────────
    async def _search_via_browser(self, req: FlightSearchRequest) -> FlightSearchResponse:
        t0 = time.monotonic()
        try:
            browser = await _get_browser()
        except Exception as e:
            logger.error("Vueling: browser launch failed: %s", e)
            return self._empty(req)
        context = await browser.new_context(
            viewport=random.choice(_VIEWPORTS),
            locale="en-GB",
            timezone_id=random.choice(_TIMEZONES),
            service_workers="block",
        )

        try:
            try:
                from playwright_stealth import stealth_async

                page = await context.new_page()
                await auto_block_if_proxied(page)
                await stealth_async(page)
            except ImportError:
                page = await context.new_page()
                await auto_block_if_proxied(page)

            # Intercept the GraphQL REQUEST to capture auth + query template
            gql_request: dict = {}
            gql_event = asyncio.Event()

            async def on_request(request):
                if (
                    "graphql" in request.url.lower()
                    and "vueling" in request.url.lower()
                    and request.method == "POST"
                    and not gql_request
                ):
                    body = request.post_data
                    if body:
                        gql_request["body"] = body
                        gql_request["headers"] = dict(request.headers)
                        gql_event.set()

            page.on("request", on_request)

            logger.info(
                "Vueling: searching %s->%s on %s",
                req.origin, req.destination, req.date_from.strftime("%Y-%m-%d"),
            )

            # Step 1: Navigate directly to Angular SPA
            await page.goto(
                "https://tickets.vueling.com/booking/flightSearch",
                wait_until="domcontentloaded",
                timeout=int(self.timeout * 1000),
            )
            await asyncio.sleep(4)
            await self._dismiss_cookies(page)

            # Step 2: Fill destination to establish session + trigger allFlights
            dest_input = page.locator("#id-destination")
            if await dest_input.count() > 0 and await dest_input.is_visible():
                await dest_input.click()
                await dest_input.fill(req.destination)
                await asyncio.sleep(1.5)
                opts = page.locator("[role='option']")
                for i in range(await opts.count()):
                    txt = await opts.nth(i).text_content() or ""
                    if req.destination in txt:
                        await opts.nth(i).click()
                        break
                else:
                    if await opts.count() > 0:
                        await opts.first.click()
                await asyncio.sleep(1)

            # Step 3: Click Search — triggers GraphQL with default date
            # (we only need the request headers + query template)
            search_btn = page.locator(
                "button:has-text('Search'), "
                "button:has-text('SEARCH'), "
                "button:has-text('Buscar'), "
                "button.btn--full-width"
            )
            if await search_btn.count() > 0:
                await search_btn.first.click(timeout=5000)
                logger.info("Vueling: clicked Search to capture template")
            else:
                logger.warning("Vueling: no Search button found")
                return self._empty(req)

            # Wait for GQL request to be captured
            remaining = max(self.timeout - (time.monotonic() - t0), 10)
            try:
                await asyncio.wait_for(gql_event.wait(), timeout=min(remaining, 15))
            except asyncio.TimeoutError:
                logger.warning("Vueling: timed out capturing GQL request template")
                return self._empty(req)

            await asyncio.sleep(1)

            # Step 4: Replay GraphQL with correct parameters
            original = json.loads(gql_request["body"])
            query = original["query"]
            date_str = req.date_from.strftime("%Y-%m-%dT00:00:00.000Z")

            new_variables = {
                "requestAVY": {
                    "request": {
                        "criteria": [
                            {
                                "origin": req.origin,
                                "destination": req.destination,
                                "date": date_str,
                            },
                            {
                                "origin": req.destination,
                                "destination": req.origin,
                                "date": date_str,
                            },
                        ],
                        "cultureCode": "en-GB",
                        "currencyCode": req.currency or "EUR",
                        "flightType": "ALL",
                        "itineraryType": "ROUND_TRIP",
                        "maxConnections": 10,
                        "passengers": [
                            {"count": req.adults, "type": "Adult"},
                        ],
                        "serviceCode": "Search1Day",
                        "servicesToRequest": [],
                        "bundleControlFilter": 2,
                    },
                    "trackingPoint": "BBV",
                }
            }

            payload = json.dumps({"query": query, "variables": new_variables})
            headers = gql_request["headers"]

            result_text = await page.evaluate(
                """async ([url, headers, body]) => {
                    const h = {};
                    for (const [k, v] of Object.entries(headers)) {
                        if (!['host','content-length',':method',':path',':scheme',':authority']
                            .includes(k.toLowerCase())) {
                            h[k] = v;
                        }
                    }
                    h['content-type'] = 'application/json';
                    const resp = await fetch(url, {
                        method: 'POST', headers: h, body: body, credentials: 'include'
                    });
                    return resp.text();
                }""",
                ["https://ams.vueling.com/avy/v1/graphql", headers, payload],
            )

            data = json.loads(result_text)
            elapsed = time.monotonic() - t0
            offers = self._parse_graphql(data, req)
            return self._build_response(offers, req, elapsed)

        except Exception as e:
            logger.error("Vueling Playwright error: %s", e)
            return self._empty(req)
        finally:
            await context.close()

    # ------------------------------------------------------------------
    # Cookie dismissal
    # ------------------------------------------------------------------

    async def _dismiss_cookies(self, page) -> None:
        try:
            btn = page.locator("#onetrust-accept-btn-handler")
            if await btn.count() > 0:
                await btn.click(timeout=3000)
                await asyncio.sleep(0.5)
                return
        except Exception:
            pass

        for label in [
            "Accept all cookies", "Accept All", "ACCEPT ALL COOKIES",
        ]:
            try:
                btn = page.get_by_role(
                    "button", name=re.compile(rf"^{re.escape(label)}$", re.IGNORECASE)
                )
                if await btn.count() > 0:
                    await btn.first.click(timeout=2000)
                    await asyncio.sleep(0.5)
                    return
            except Exception:
                continue

    # ------------------------------------------------------------------
    # GraphQL response parsing
    # ------------------------------------------------------------------

    def _build_route(
        self,
        segments_data: list[dict],
        default_origin: str,
        default_destination: str,
        cabin_class: str,
        journey_duration: Any = None,
        connection_time: Any = None,
    ) -> tuple[FlightRoute | None, list[str]]:
        flight_segments: list[FlightSegment] = []
        flight_numbers: list[str] = []

        for seg in segments_data:
            ident = seg.get("identifier", {})
            carrier = ident.get("carrierCode", "VY")
            flight_num = ident.get("identifier", "")
            seg_des = seg.get("designator", {})
            departure = self._parse_dt(seg_des.get("departure", ""))
            arrival = self._parse_dt(seg_des.get("arrival", ""))

            flight_numbers.append(f"{carrier}{flight_num}")
            flight_segments.append(FlightSegment(
                airline=carrier,
                airline_name="Vueling",
                flight_no=f"{carrier}{flight_num}",
                origin=seg_des.get("origin", default_origin),
                destination=seg_des.get("destination", default_destination),
                departure=departure,
                arrival=arrival,
                duration_seconds=self._segment_duration_seconds(seg, departure, arrival),
                cabin_class=cabin_class or "M",
            ))

        if not flight_segments:
            return None, []

        return (
            FlightRoute(
                segments=flight_segments,
                total_duration_seconds=self._route_duration_seconds(
                    segments_data,
                    flight_segments,
                    journey_duration,
                    connection_time,
                ),
                stopovers=max(len(segments_data) - 1, 0),
            ),
            flight_numbers,
        )

    def _parse_graphql(
        self, data: dict, req: FlightSearchRequest,
    ) -> list[FlightOffer]:
        """Parse the GraphQL response into FlightOffers.

        Structure:
        - data.amsAvy.trips[0].trips[0].journeysAvailableByMarket[{key, value}]
          Each journey: designator, segments, fareAvailabilityKey
        - data.amsAvy.faresAvailable[{value: {fareAvailabilityKey, fares}}]
          Maps fareAvailabilityKey → product-class prices (BA/OP/TF/FF)
        """
        ams = data.get("data", {}).get("amsAvy", {})
        if not ams:
            logger.warning("Vueling: no amsAvy in GraphQL response")
            return []

        currency = ams.get("currencyCode", req.currency or "EUR")

        # Build fare price lookup: fareAvailabilityKey -> {productClass: amount}
        # Track all fare classes so we can compute live bag add-on price (IB - BB)
        fare_lookup: dict[str, dict[str, float]] = {}
        for fa_entry in ams.get("faresAvailable", []):
            val = fa_entry.get("value", {})
            fak = val.get("fareAvailabilityKey", "")
            if not fak:
                continue
            if fak not in fare_lookup:
                fare_lookup[fak] = {}
            for fare in val.get("fares", []):
                pc = fare.get("productClass", "")
                for pf in fare.get("passengerFares", []):
                    amount = pf.get("amsFareAmount")
                    if amount is not None and amount > 0:
                        existing = fare_lookup[fak].get(pc)
                        if existing is None or amount < existing:
                            fare_lookup[fak][pc] = amount

        # Extract outbound journeys
        trips_list = ams.get("trips", [])
        if not trips_list:
            logger.warning("Vueling: no trips in GraphQL response")
            return []

        journeys: list[dict] = []
        inner_trips = trips_list[0].get("trips", [])
        if inner_trips:
            target_key = f"{req.origin}|{req.destination}"
            for market in inner_trips[0].get("journeysAvailableByMarket", []):
                if market.get("key", "") == target_key:
                    journeys = market.get("value", [])
                    break
            if not journeys and inner_trips[0].get("journeysAvailableByMarket"):
                journeys = inner_trips[0]["journeysAvailableByMarket"][0].get(
                    "value", []
                )

        if not journeys:
            logger.warning(
                "Vueling: no journeys for %s|%s", req.origin, req.destination
            )
            return []

        booking_url = self._build_booking_url(req)
        offers: list[FlightOffer] = []

        for journey in journeys:
            if journey.get("notForSale") or journey.get("isSoldOut"):
                continue

            des = journey.get("designator", {})
            origin = des.get("origin", req.origin)
            destination = des.get("destination", req.destination)

            # Find fares: collect all productClass prices for this journey
            all_class_prices: dict[str, float] = {}
            for fare in journey.get("fares", []):
                fak = fare.get("fareAvailabilityKey", "")
                class_prices = fare_lookup.get(fak, {})
                for pc, amt in class_prices.items():
                    if pc not in all_class_prices or amt < all_class_prices[pc]:
                        all_class_prices[pc] = amt

            if not all_class_prices:
                continue

            # Best price = cheapest fare class (BB = Basic, no checked bag)
            best_price = min(all_class_prices.values())
            best_class = min(all_class_prices, key=all_class_prices.get)

            # Live checked bag price: IB (Optima, bag included) - BB (Basic, no bag)
            bb_price = all_class_prices.get("BB")
            ib_price = all_class_prices.get("IB")
            live_bag_price: float | None = None
            if bb_price and ib_price and ib_price > bb_price:
                live_bag_price = round(ib_price - bb_price, 2)

            # Build segments
            segments_data = journey.get("segments", [])
            route, flight_numbers = self._build_route(
                segments_data,
                origin,
                destination,
                best_class,
                journey.get("duration"),
                journey.get("connectionTime"),
            )

            if route is None:
                continue

            dep_str = des.get("departure", "")
            offer_key = "_".join(flight_numbers) + f"_{dep_str[:10]}"
            price = round(best_price, 2)

            offer = FlightOffer(
                id=f"vy_{hashlib.md5(offer_key.encode()).hexdigest()[:12]}",
                price=price,
                currency=currency,
                price_formatted=f"{price:.2f} {currency}",
                outbound=route,
                inbound=None,
                airlines=["Vueling"],
                owner_airline="VY",
                booking_url=booking_url,
                is_locked=False,
                source="vueling_direct",
                source_tier="free",
            )
            if live_bag_price is not None:
                offer.bags_price["checked_bag"] = live_bag_price
                offer.conditions["checked_bag"] = (
                    f"First checked bag: {currency} {live_bag_price:.0f} (live)"
                )
                offer.bags_price["cabin_bag"] = 0.0
                offer.conditions["cabin_bag"] = "10 kg cabin bag included in all fares"
                offer.conditions["seat"] = "seat selection: add-on (price varies by route)"
            offers.append(offer)

        logger.info(
            "Vueling: found %d offers for %s->%s on %s",
            len(offers), req.origin, req.destination,
            req.date_from.strftime("%Y-%m-%d"),
        )
        return offers

    def _parse_graphql_return(
        self, data: dict, req: FlightSearchRequest,
    ) -> list[FlightOffer]:
        """Parse return-leg journeys from GraphQL RT response."""
        ams = data.get("data", {}).get("amsAvy", {})
        if not ams:
            return []
        currency = ams.get("currencyCode", req.currency or "EUR")
        fare_lookup: dict[str, dict[str, float]] = {}
        for fa_entry in ams.get("faresAvailable", []):
            val = fa_entry.get("value", {})
            fak = val.get("fareAvailabilityKey", "")
            if not fak:
                continue
            if fak not in fare_lookup:
                fare_lookup[fak] = {}
            for fare in val.get("fares", []):
                pc = fare.get("productClass", "")
                for pf in fare.get("passengerFares", []):
                    amount = pf.get("amsFareAmount")
                    if amount is not None and amount > 0:
                        existing = fare_lookup[fak].get(pc)
                        if existing is None or amount < existing:
                            fare_lookup[fak][pc] = amount

        trips_list = ams.get("trips", [])
        if not trips_list:
            return []
        # Return journeys are in trips[1] (second trip) or in the second market key
        inner_trips = trips_list[0].get("trips", [])
        ret_key = f"{req.destination}|{req.origin}"
        journeys: list[dict] = []
        # Check trips[1] first (RT second leg)
        if len(inner_trips) > 1:
            for market in inner_trips[1].get("journeysAvailableByMarket", []):
                if market.get("key", "") == ret_key:
                    journeys = market.get("value", [])
                    break
            if not journeys and inner_trips[1].get("journeysAvailableByMarket"):
                journeys = inner_trips[1]["journeysAvailableByMarket"][0].get("value", [])
        # Fallback: check trips[0] for the return key
        if not journeys and inner_trips:
            for market in inner_trips[0].get("journeysAvailableByMarket", []):
                if market.get("key", "") == ret_key:
                    journeys = market.get("value", [])
                    break

        if not journeys:
            return []

        booking_url = self._build_booking_url(req)
        offers: list[FlightOffer] = []
        for journey in journeys:
            if journey.get("notForSale") or journey.get("isSoldOut"):
                continue
            des = journey.get("designator", {})
            all_class_prices: dict[str, float] = {}
            for fare in journey.get("fares", []):
                fak = fare.get("fareAvailabilityKey", "")
                class_prices = fare_lookup.get(fak, {})
                for pc, amt in class_prices.items():
                    if pc not in all_class_prices or amt < all_class_prices[pc]:
                        all_class_prices[pc] = amt
            if not all_class_prices:
                continue
            best_price = min(all_class_prices.values())
            best_class = min(all_class_prices, key=all_class_prices.get)
            bb_price = all_class_prices.get("BB")
            ib_price = all_class_prices.get("IB")
            live_bag_price: float | None = None
            if bb_price and ib_price and ib_price > bb_price:
                live_bag_price = round(ib_price - bb_price, 2)
            segments_data = journey.get("segments", [])
            route, flight_numbers = self._build_route(
                segments_data,
                req.destination,
                req.origin,
                best_class,
                journey.get("duration"),
                journey.get("connectionTime"),
            )
            if route is None:
                continue
            dep_str = des.get("departure", "")
            offer_key = "_".join(flight_numbers) + f"_{dep_str[:10]}_ret"
            price = round(best_price, 2)
            offer = FlightOffer(
                id=f"vy_{hashlib.md5(offer_key.encode()).hexdigest()[:12]}",
                price=price, currency=currency,
                price_formatted=f"{price:.2f} {currency}",
                outbound=route, inbound=None,
                airlines=["Vueling"], owner_airline="VY",
                booking_url=booking_url, is_locked=False,
                source="vueling_direct", source_tier="free",
            )
            if live_bag_price is not None:
                offer.bags_price["checked_bag"] = live_bag_price
                offer.conditions["checked_bag"] = (
                    f"First checked bag: {currency} {live_bag_price:.0f} (live)"
                )
                offer.bags_price["cabin_bag"] = 0.0
                offer.conditions["cabin_bag"] = "10 kg cabin bag included in all fares"
                offer.conditions["seat"] = "seat selection: add-on (price varies by route)"
            offers.append(offer)
        return offers

    def _build_rt_combos(
        self,
        outbound: list[FlightOffer],
        inbound: list[FlightOffer],
        req: FlightSearchRequest,
    ) -> list[FlightOffer]:
        """Combine outbound × inbound into RT offers."""
        combos: list[FlightOffer] = []
        for ob in outbound[:15]:
            for ib in inbound[:10]:
                price = round(ob.price + ib.price, 2)
                combo_key = f"vy_rt_{ob.id}_{ib.id}"
                combos.append(FlightOffer(
                    id=f"vy_{hashlib.md5(combo_key.encode()).hexdigest()[:12]}",
                    price=price, currency=ob.currency,
                    price_formatted=f"{price:.2f} {ob.currency}",
                    outbound=ob.outbound, inbound=ib.outbound,
                    airlines=list(set(ob.airlines + ib.airlines)),
                    owner_airline="VY",
                    booking_url=self._build_booking_url(req),
                    is_locked=False,
                    source="vueling_direct", source_tier="free",
                ))
        combos.sort(key=lambda o: o.price)
        return combos[:50]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _segment_duration_seconds(
        self,
        seg: dict,
        departure: datetime,
        arrival: datetime,
    ) -> int:
        dep_utc, arr_utc = self._segment_utc_bounds(seg)
        if dep_utc and arr_utc:
            seconds = int((arr_utc - dep_utc).total_seconds())
            if seconds > 0:
                return seconds

        segment_duration = self._parse_duration_seconds(seg.get("segmentDuration"))
        if segment_duration > 0:
            return segment_duration

        return self._fallback_local_duration_seconds(departure, arrival)

    def _route_duration_seconds(
        self,
        segments_data: list[dict],
        flight_segments: list[FlightSegment],
        journey_duration: Any = None,
        connection_time: Any = None,
    ) -> int:
        if segments_data:
            first_dep_utc, _ = self._segment_utc_bounds(segments_data[0])
            _, last_arr_utc = self._segment_utc_bounds(segments_data[-1])
            if first_dep_utc and last_arr_utc:
                seconds = int((last_arr_utc - first_dep_utc).total_seconds())
                if seconds > 0:
                    return seconds

        parsed_journey_duration = self._parse_duration_seconds(journey_duration)
        if parsed_journey_duration > 0:
            return parsed_journey_duration

        segment_total = sum(segment.duration_seconds for segment in flight_segments)
        connection_seconds = self._parse_duration_seconds(connection_time)
        if segment_total > 0:
            return segment_total + connection_seconds

        if not flight_segments:
            return 0

        return self._fallback_local_duration_seconds(
            flight_segments[0].departure,
            flight_segments[-1].arrival,
        )

    def _segment_utc_bounds(self, seg: dict) -> tuple[Optional[datetime], Optional[datetime]]:
        dep_utc: Optional[datetime] = None
        arr_utc: Optional[datetime] = None

        for leg in seg.get("legs", []):
            leg_info = leg.get("legInfo", {})
            if dep_utc is None:
                dep_utc = self._parse_utc_dt(leg_info.get("departureTimeUtc"))
            candidate_arrival = self._parse_utc_dt(leg_info.get("arrivalTimeUtc"))
            if candidate_arrival is not None:
                arr_utc = candidate_arrival

        return dep_utc, arr_utc

    @staticmethod
    def _parse_duration_seconds(value: Any) -> int:
        if value is None:
            return 0
        if isinstance(value, (list, tuple)):
            return sum(VuelingConnectorClient._parse_duration_seconds(item) for item in value)
        if isinstance(value, (int, float)):
            raw = int(value)
            if raw <= 0:
                return 0
            return raw * 60 if raw <= 1440 else raw

        text = str(value).strip()
        if not text:
            return 0

        iso_match = re.fullmatch(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", text, re.IGNORECASE)
        if iso_match:
            hours = int(iso_match.group(1) or 0)
            minutes = int(iso_match.group(2) or 0)
            seconds = int(iso_match.group(3) or 0)
            return hours * 3600 + minutes * 60 + seconds

        if ":" in text:
            parts = text.split(":")
            if len(parts) == 2 and all(part.isdigit() for part in parts):
                return int(parts[0]) * 3600 + int(parts[1]) * 60
            if len(parts) == 3 and all(part.isdigit() for part in parts):
                return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])

        if text.isdigit():
            raw = int(text)
            if raw <= 0:
                return 0
            return raw * 60 if raw <= 1440 else raw

        return 0

    @staticmethod
    def _parse_utc_dt(s: Any) -> Optional[datetime]:
        if not s:
            return None
        s = str(s).strip()
        try:
            return datetime.fromisoformat(s.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            return None

    @staticmethod
    def _fallback_local_duration_seconds(departure: datetime, arrival: datetime) -> int:
        if departure.year <= 2000 or arrival.year <= 2000:
            return 0
        seconds = int((arrival - departure).total_seconds())
        if seconds < 0:
            seconds += 24 * 3600
        return max(seconds, 0)

    def _build_response(
        self, offers: list[FlightOffer], req: FlightSearchRequest, elapsed: float,
    ) -> FlightSearchResponse:
        offers.sort(key=lambda o: o.price)
        logger.info(
            "Vueling %s->%s returned %d offers in %.1fs",
            req.origin, req.destination, len(offers), elapsed,
        )
        search_hash = hashlib.md5(
            f"vueling{req.origin}{req.destination}{req.date_from}{req.return_from or ''}".encode()
        ).hexdigest()[:12]
        return FlightSearchResponse(
            search_id=f"fs_{search_hash}",
            origin=req.origin,
            destination=req.destination,
            currency=offers[0].currency if offers else (req.currency or "EUR"),
            offers=offers,
            total_results=len(offers),
        )

    @staticmethod
    def _parse_dt(s: Any) -> datetime:
        if not s:
            return datetime(2000, 1, 1)
        # Vueling designator timestamps are local airport clock times, even when
        # they arrive with a trailing UTC suffix. Strip offsets so we preserve
        # the user-facing local schedule and rely on UTC leg metadata for duration.
        s = re.sub(r"(Z|[+-]\d{2}:?\d{2})$", "", str(s).strip())
        try:
            return datetime.fromisoformat(s)
        except (ValueError, AttributeError):
            pass
        for fmt in (
            "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M",
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
        ):
            try:
                return datetime.strptime(s[:len(fmt) + 2], fmt)
            except (ValueError, IndexError):
                continue
        return datetime(2000, 1, 1)

    @staticmethod
    def _build_booking_url(req: FlightSearchRequest) -> str:
        dep = req.date_from.strftime("%Y-%m-%d")
        return (
            f"https://tickets.vueling.com/ScheduleSelect.aspx"
            f"?culture=en-GB&origin={req.origin}&destination={req.destination}"
            f"&departureDate={dep}&adults={req.adults}"
            f"&children={req.children}&infants={req.infants}"
        )

    def _empty(self, req: FlightSearchRequest) -> FlightSearchResponse:
        search_hash = hashlib.md5(
            f"vueling{req.origin}{req.destination}{req.date_from}{req.return_from or ''}".encode()
        ).hexdigest()[:12]
        return FlightSearchResponse(
            search_id=f"fs_{search_hash}",
            origin=req.origin,
            destination=req.destination,
            currency=req.currency or "EUR",
            offers=[],
            total_results=0,
        )


    @staticmethod
    def _combine_rt(
        ob: list[FlightOffer], ib: list[FlightOffer], req,
    ) -> list[FlightOffer]:
        combos: list[FlightOffer] = []
        for o in ob[:15]:
            for i in ib[:10]:
                price = round(o.price + i.price, 2)
                cid = hashlib.md5(f"{o.id}_{i.id}".encode()).hexdigest()[:12]
                combos.append(FlightOffer(
                    id=f"rt_vuel_{cid}", price=price, currency=o.currency,
                    outbound=o.outbound, inbound=i.outbound,
                    airlines=list(dict.fromkeys(o.airlines + i.airlines)),
                    owner_airline=o.owner_airline,
                    booking_url=o.booking_url, is_locked=False,
                    source=o.source, source_tier=o.source_tier,
                ))
        combos.sort(key=lambda c: c.price)
        return combos[:20]
