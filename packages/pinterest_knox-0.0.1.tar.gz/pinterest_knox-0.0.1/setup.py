from setuptools import setup; setup(name='pinterest-knox', version='0.0.1')
