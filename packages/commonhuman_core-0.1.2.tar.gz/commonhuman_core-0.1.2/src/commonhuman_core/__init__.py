# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 CommonHuman-Lab
"""
commonhuman-core — shared HTTP, crawling, and scanning infrastructure.
"""

__version__ = "0.1.2"

__all__ = ["__version__"]
