from __future__ import annotations
import json
import pygame
import pygame_gui
import numpy as np
import yaml
from .camera import Camera2D
from .world import World
from .robots import create_robot
from .lidar import Lidar
from .waypoints import WaypointManager
from .ui.gui import GUI



class Simulator:
    def __init__(self, config: dict, controller=None, draw_callback=None):
        pygame.init()
        self.config = config
        w = int(config["window"]["width"]); h = int(config["window"]["height"])
        self.min_width = int(config["window"].get("min_width", 1000))
        self.min_height = int(config["window"].get("min_height", 650))
        self.panel_width = int(config["window"].get("panel_width", 300))
        self.colors = config["colors"]
        self.width, self.height = w, h
        self.world_view_width = max(400, self.width - self.panel_width)
        self.panel_x = self.world_view_width
        self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
        pygame.display.set_caption(config["window"].get("title", "NavSim"))
        self.clock = pygame.time.Clock()
        self.manager = pygame_gui.UIManager((self.width, self.height))
        self.world = World(config)
        self.camera = Camera2D(self.world.width, self.world.height, self.world_view_width, self.height, **config["camera"])
        self.robot = create_robot(config)
        self.lidar = Lidar(config)
        self.lidar_readings = []
        self.collision = False
        self.waypoints = WaypointManager(config)
        self.controller = controller
        self.gui = GUI(self.screen, self.manager, self._layout())
        self.running = True
        self.running_simulation = False
        self.dt = 0.03
        self.dragging = False
        self.last_mouse_pos = None
        self.pending_obstacle_position = None

        self.draw_callback = draw_callback

    def _layout(self):
        return {"width": self.width, "height": self.height, "panel_width": self.panel_width, "world_view_width": self.world_view_width, "panel_x": self.panel_x, "config": self.config}

    def resize(self, new_width, new_height):
        self.width = max(int(new_width), self.min_width)
        self.height = max(int(new_height), self.min_height)
        self.world_view_width = max(400, self.width - self.panel_width)
        self.panel_x = self.world_view_width
        self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
        self.manager.set_window_resolution((self.width, self.height))
        self.camera.resize(self.world_view_width, self.height)
        self.gui.rebuild(self._layout())

    def reset(self):
        self.robot.reset()
        self.waypoints.current_index = 0
        self.camera.reset()
        self.collision = False
        self.lidar_readings = []

    
    


    def save_config(self, path="config/default.yaml"):
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(self.config, f, sort_keys=False)
        print(f"Config saved to {path}")



    def mouse_inside_world(self, pos):
        x, y = pos
        return 0 <= x < self.world_view_width and 0 <= y < self.height

    
    def handle_button_event(self, event):
        if event.type != pygame_gui.UI_BUTTON_PRESSED:
            return

        # Botões da janela/modal de raio do obstáculo
        if event.ui_element == self.gui.obstacle_radius_ok:
            self.confirm_obstacle_radius()
            return

        if event.ui_element == self.gui.obstacle_radius_cancel:
            self.pending_obstacle_position = None
            self.gui.close_obstacle_radius_window()
            return

        e = self.gui.elements

        if event.ui_element == e["start"]:
            self.running_simulation = not self.running_simulation

        elif event.ui_element == e["reset"]:
            self.running_simulation = False
            self.reset()

        elif event.ui_element == e["clear_path"]:
            self.robot.clear_path()

        elif event.ui_element == e["clear_waypoints"]:
            self.waypoints.clear()

        elif event.ui_element == e["clear_obstacles"]:
            self.world.clear_obstacles()

        elif event.ui_element == e["toggle_lidar"]:
            self.lidar.enabled = not self.lidar.enabled

        elif event.ui_element == e["save_config"]:
            self.save_config()

        elif event.ui_element == e["center_camera"]:
            self.camera.center_on_origin_with_margin()

        
    def check_collision(self):
        q = self.robot.position
        r_robot = self.robot.radius   

        for obs in self.world.obstacles:
            center = self.world.obstacle_center(obs)
            r_obs = self.world.obstacle_radius(obs)

            dist = np.linalg.norm(q - center)

            if dist < (r_obs + r_robot):
                return True

        return False

    
    def confirm_obstacle_radius(self):
        if self.pending_obstacle_position is None:
            self.gui.close_obstacle_radius_window()
            return

        try:
            radius_text = self.gui.obstacle_radius_entry.get_text()
            radius = float(radius_text)

            if radius <= 0:
                print("Raio inválido. O raio deve ser maior que zero.")
                return

        except ValueError:
            print("Raio inválido. Digite um número, por exemplo: 0.4")
            return

        self.world.add_obstacle(
            self.pending_obstacle_position,
            radius=radius
        )
        self.config["world"]["obstacles"] = np.array(self.world.obstacles).tolist()

        self.pending_obstacle_position = None
        self.gui.close_obstacle_radius_window()

    
    def is_modal_open(self):
        return self.gui.obstacle_radius_window is not None

    def process_events(self):
        for event in pygame.event.get():

            # ==================================================
            # EVENTOS BÁSICOS DA JANELA
            # ==================================================

            if event.type == pygame.QUIT:
                self.running = False

            elif event.type == pygame.VIDEORESIZE:
                self.resize(event.w, event.h)

            # ==================================================
            # PRIMEIRO: ENTREGAR EVENTOS PARA A GUI
            # ==================================================
            # Isso garante que botões, caixas de texto e janelas
            # recebam o clique antes do mundo.

            self.manager.process_events(event)

            self.handle_button_event(event)

            self.gui.process_slider_event(
                event,
                self.robot,
                self.world,
                self.lidar,
                self.config
            )

            # ==================================================
            # ENTER NA CAIXA DE RAIO DO OBSTÁCULO
            # ==================================================

            if event.type == pygame_gui.UI_TEXT_ENTRY_FINISHED:
                if event.ui_element == self.gui.obstacle_radius_entry:
                    self.confirm_obstacle_radius()
                    continue

            # ==================================================
            # SE MODAL ESTIVER ABERTA, O MUNDO NÃO RECEBE EVENTO
            # ==================================================
            # Isso evita que clicar no OK vire waypoint.

            if self.is_modal_open():
                continue

            # ==================================================
            # SE O MOUSE ESTIVER SOBRE ALGUM ELEMENTO DA GUI,
            # O MUNDO TAMBÉM NÃO RECEBE EVENTO
            # ==================================================

            if self.manager.get_hovering_any_element():
                continue

            # ==================================================
            # EVENTOS DO MUNDO
            # ==================================================

            if event.type == pygame.MOUSEWHEEL:
                mouse_pos = pygame.mouse.get_pos()

                if self.mouse_inside_world(mouse_pos):
                    self.camera.zoom_at(mouse_pos, event.y)

            elif event.type == pygame.MOUSEBUTTONDOWN:

                # Botão do meio: pan
                if event.button == 2 and self.mouse_inside_world(event.pos):
                    self.dragging = True
                    self.last_mouse_pos = event.pos

                # Botão esquerdo: waypoint
                elif event.button == 1 and self.mouse_inside_world(event.pos):
                    self.waypoints.add_waypoint(
                        self.camera.screen_to_world(*event.pos)
                    )

                # Botão direito: abre janela para raio do obstáculo
                elif event.button == 3 and self.mouse_inside_world(event.pos):
                    self.pending_obstacle_position = self.camera.screen_to_world(
                        *event.pos
                    )

                    self.gui.open_obstacle_radius_window(
                        default_radius=self.world.default_obstacle_radius
                    )

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 2:
                    self.dragging = False

            elif event.type == pygame.MOUSEMOTION and self.dragging:
                dx = event.pos[0] - self.last_mouse_pos[0]
                dy = event.pos[1] - self.last_mouse_pos[1]

                self.camera.pan_pixels(dx, dy)

                self.last_mouse_pos = event.pos
    
    def update_simulation(self):
        if not self.running_simulation:
            return

        self.waypoints.update(self.robot.position)

        goal = self.waypoints.get_current_waypoint()

        # ======================================================
        # LiDAR salvo como atributo da classe
        # ======================================================

        self.lidar_readings = []

        if self.lidar.enabled:
            self.lidar_readings = self.lidar.cast_rays(
                self.robot,
                self.world
            )

        # ======================================================
        # Controlador
        # ======================================================

        if self.controller is None:
            command = {}
        else:
            try:
                command = self.controller(
                    self.robot,
                    self.world,
                    goal,
                    self.config,
                    self.dt,
                    self.lidar_readings   
                )
            except TypeError:
                command = self.controller(
                    self.robot,
                    self.world,
                    goal,
                    self.config,
                    self.dt
                )

        if command is None:
            command = {}

        
        if self.collision:
            return

        self.robot.step(command, self.dt)
        
        if self.check_collision():
            self.collision = True




    def draw(self, fps):
        c = self.config["colors"]
        self.screen.fill(tuple(c["background"]))
        self.world.draw_grid(self.screen, self.camera)
        self.world.draw_origin(self.screen, self.camera)
        self.world.draw_axes(self.screen, self.camera)
        pygame.draw.rect(self.screen, tuple(c["panel"]), (self.panel_x, 0, self.panel_width, self.height))
        pygame.draw.line(self.screen, tuple(c["white"]), (self.world_view_width, 0), (self.world_view_width, self.height), 2)
        self.robot.draw_path(self.screen, self.camera)
        self.world.draw_obstacles(self.screen, self.camera)
        self.waypoints.draw(self.screen, self.camera)
        self.lidar.draw(self.screen, self.camera, self.robot, self.world)
        self.robot.draw(self.screen, self.camera)
        self.gui.update_info(self.robot, self.waypoints, self.world, fps, self.running_simulation, self.lidar, self.camera)
        self.manager.draw_ui(self.screen)
        
        # ======================================================
        # INDICADOR DE COLISÃO
        # ======================================================

        if self.collision:
            x, y = self.robot.position
            px, py = self.camera.world_to_screen(x, y)

            font = pygame.font.SysFont("Segoe UI Emoji", int(55*self.camera.zoom))

            emoji = font.render("💥", True, (255, 255, 255))

            rect = emoji.get_rect(center=(px, py))

            self.screen.blit(emoji, rect)

        
        # ==================================================
        # DESENHO CUSTOMIZADO
        # ==================================================        
        if hasattr(self, "draw_callback") and self.draw_callback is not None:
            self.draw_callback(self, self.screen)

        pygame.display.flip()

    def run(self):
        while self.running:
            time_delta = self.clock.tick(60) / 1000.0
            fps = self.clock.get_fps()
            self.process_events()
            self.manager.update(time_delta)
            self.update_simulation()
            self.draw(fps)
        pygame.quit()
