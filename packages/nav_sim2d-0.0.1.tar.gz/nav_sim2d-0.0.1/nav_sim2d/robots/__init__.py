from .holonomic import HolonomicRobot
from .differential import DifferentialRobot
from .ackermann import AckermannRobot


def create_robot(config: dict):
    robot_type = config["robot"].get("type", "ackermann").lower()
    if robot_type in ["holonomic", "omni", "omnidirectional"]:
        return HolonomicRobot(config)
    if robot_type in ["differential", "diff", "unicycle", "nonholonomic"]:
        return DifferentialRobot(config)
    if robot_type in ["ackermann", "car", "racecar"]:
        return AckermannRobot(config)
    raise ValueError(f"Tipo de robô desconhecido: {robot_type}")

__all__ = ["create_robot", "HolonomicRobot", "DifferentialRobot", "AckermannRobot"]
