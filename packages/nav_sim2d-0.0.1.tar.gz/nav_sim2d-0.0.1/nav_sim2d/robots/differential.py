from __future__ import annotations
import math
import numpy as np
import pygame
from .base import BaseRobot
from nav_sim2d.geometry import wrap_to_pi, clamp


class DifferentialRobot(BaseRobot):
    def __init__(self, config: dict):
        super().__init__(config)
        c = config["robot"]
        self.initial_pose = np.array(c.get("initial_pose", [2.0, 2.0, 0.0]), dtype=float)
        self.x, self.y, self.theta = self.initial_pose.tolist()
        self.radius = float(c.get("radius", 0.3))
        self.max_speed = float(c.get("max_speed", 2.0))
        self.max_omega = float(c.get("max_omega", 2.0))
        self.path_max_length = int(c.get("path_max_length", 4000))
        self.v = 0.0
        self.omega = 0.0
        self.colors = config["colors"]

    @property
    def position(self):
        return np.array([self.x, self.y], dtype=float)

    def reset(self):
        self.x, self.y, self.theta = self.initial_pose.tolist()
        self.v = 0.0
        self.omega = 0.0
        self.path.clear()

    def state(self):
        return {"type": "differential", "x": self.x, "y": self.y, "theta": self.theta, "position": self.position.copy(), "v": self.v, "omega": self.omega}

    def step(self, command: dict, dt: float):
        self.v = clamp(float(command.get("v", 0.0)), -self.max_speed, self.max_speed)
        self.omega = clamp(float(command.get("omega", 0.0)), -self.max_omega, self.max_omega)
        self.x += self.v * math.cos(self.theta) * dt
        self.y += self.v * math.sin(self.theta) * dt
        self.theta = wrap_to_pi(self.theta + self.omega * dt)
        self.path.append(self.position.copy())
        if len(self.path) > self.path_max_length:
            self.path.pop(0)

    def draw_path(self, screen, camera):
        if len(self.path) < 2:
            return
        pygame.draw.lines(screen, tuple(self.colors["path"]), False, [camera.world_to_screen(*p) for p in self.path], 2)

    def draw(self, screen, camera):
        center = camera.world_to_screen(self.x, self.y)
        radius_px = max(5, int(self.radius * camera.scale))
        pygame.draw.circle(screen, tuple(self.colors["robot"]), center, radius_px)
        front = self.position + np.array([math.cos(self.theta), math.sin(self.theta)]) * self.radius * 1.6
        pygame.draw.line(screen, tuple(self.colors["white"]), center, camera.world_to_screen(*front), 3)
