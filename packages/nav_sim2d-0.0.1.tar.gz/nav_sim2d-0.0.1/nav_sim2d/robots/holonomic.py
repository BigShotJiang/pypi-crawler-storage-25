from __future__ import annotations
import math
import numpy as np
import pygame
from .base import BaseRobot
from nav_sim2d.geometry import wrap_to_pi


class HolonomicRobot(BaseRobot):
    def __init__(self, config: dict):
        super().__init__(config)
        c = config["robot"]
        self.initial_pose = np.array(c.get("initial_pose", [2.0, 2.0, 0.0]), dtype=float)
        self.x, self.y, self.theta = self.initial_pose.tolist()
        self.radius = float(c.get("radius", 0.3))
        self.max_speed = float(c.get("max_speed", 2.0))
        self.path_max_length = int(c.get("path_max_length", 4000))
        self.vx = 0.0
        self.vy = 0.0
        self.colors = config["colors"]

    @property
    def position(self):
        return np.array([self.x, self.y], dtype=float)

    def reset(self):
        self.x, self.y, self.theta = self.initial_pose.tolist()
        self.vx = 0.0
        self.vy = 0.0
        self.path.clear()

    def state(self):
        return {"type": "holonomic", "x": self.x, "y": self.y, "theta": self.theta, "position": self.position.copy(), "vx": self.vx, "vy": self.vy}

    def step(self, command: dict, dt: float):
        vx = float(command.get("vx", 0.0))
        vy = float(command.get("vy", 0.0))
        norm = math.hypot(vx, vy)
        if norm > self.max_speed:
            scale = self.max_speed / norm
            vx *= scale
            vy *= scale
        self.vx, self.vy = vx, vy
        self.x += self.vx * dt
        self.y += self.vy * dt
        if norm > 1e-8:
            self.theta = wrap_to_pi(math.atan2(self.vy, self.vx))
        self.path.append(self.position.copy())
        if len(self.path) > self.path_max_length:
            self.path.pop(0)

    def draw_path(self, screen, camera):
        if len(self.path) < 2:
            return
        pygame.draw.lines(screen, tuple(self.colors["path"]), False, [camera.world_to_screen(*p) for p in self.path], 2)

    def draw(self, screen, camera):
        center = camera.world_to_screen(self.x, self.y)
        radius_px = max(5, int(self.radius * camera.scale))
        pygame.draw.circle(screen, tuple(self.colors["robot"]), center, radius_px)
        front = self.position + np.array([math.cos(self.theta), math.sin(self.theta)]) * self.radius * 1.6
        pygame.draw.line(screen, tuple(self.colors["white"]), center, camera.world_to_screen(*front), 3)
