from __future__ import annotations
import math
import pygame
import pygame_gui
from nav_sim2d.geometry import distance_between


class GUI:
    def __init__(self, screen, manager, layout):
        self.manager = manager
        self.screen = screen
        self.layout = layout
        self.elements = {}
        self.buttons_bottom_y = 0
        self.create_buttons()
        self.create_sliders()
        # self.create_info_labels()
        self.obstacle_radius_window = None
        self.obstacle_radius_entry = None
        self.obstacle_radius_ok = None
        self.obstacle_radius_cancel = None
        self.font = pygame.font.SysFont(
            "consolas",
            18
        )

    @property
    def panel_x(self):
        return self.layout["panel_x"]

    @property
    def height(self):
        return self.layout["height"]

    def rebuild(self, layout):
        self.layout = layout
        for element in self.elements.values():
            element.kill()
        self.elements.clear()
        self.create_buttons()
        self.create_sliders()
        self.create_info_labels()

    def create_buttons(self):
        x = self.panel_x + 35
        y = 30
        w, h, gap = 230, 34, 42
        
        buttons = [
            ("start", "Start / Pause"),
            ("reset", "Reset"),
            ("clear_path", "Clear Path"),
            ("clear_waypoints", "Clear Waypoints"),
            ("clear_obstacles", "Clear Obstacles"),
            ("toggle_lidar", "Toggle LiDAR"),
            ("save_config", "Save Config"),
            ("center_camera", "Center Camera"),
        ]

        for i, (key, text) in enumerate(buttons):
            self.elements[key] = pygame_gui.elements.UIButton(pygame.Rect(x, y + i*gap, w, h), text, self.manager)
        self.buttons_bottom_y = y + len(buttons) * gap

    def draw_hud(self,        running,        robot,        rtype,        motion,        waypoints,        dist,        fps,        world,        camera    ):
        text = (
            f"{'RUN' if running else 'PAUSE'}"
            f" | {rtype}"
            f" | x={robot.x:.2f}"
            f", y={robot.y:.2f}"
            f" | θ={math.degrees(robot.theta):.1f}°"
            f" | {motion}"
            f" | WP={waypoints.status_text()}"
            f" | d={dist}"
            f" | FPS={fps:.0f}"
            f" | Obs={len(world.obstacles)}"
            f" | Zoom={camera.zoom:.2f}"
        )

        padding = 8

        info_surface = self.font.render(
            text,
            True,
            (255,255,255)
        )

        bg_rect = pygame.Rect(
            5,
            5,
            info_surface.get_width() + 2*padding,
            info_surface.get_height() + 2*padding
        )

        overlay = pygame.Surface(
            (bg_rect.width, bg_rect.height),
            pygame.SRCALPHA
        )

        overlay.fill((0,0,0,180))

        self.screen.blit(
            overlay,
            (bg_rect.x, bg_rect.y)
        )

        self.screen.blit(
            info_surface,
            (10, 10)
        )

    def add_slider(self, key, label, y, start, value_range):
        x = self.panel_x + 35
        w = 230
        self.elements[f"{key}_label"] = pygame_gui.elements.UILabel(pygame.Rect(x, y, w, 22), label, self.manager)
        self.elements[key] = pygame_gui.elements.UIHorizontalSlider(pygame.Rect(x, y+24, w, 22), start, value_range, self.manager)
        self.elements[f"{key}_value"] = pygame_gui.elements.UILabel(pygame.Rect(x, y+47, w, 22), f"{start:.2f}", self.manager)

    def create_sliders(self):
        cfg = self.layout["config"]
        start_y = self.buttons_bottom_y + 16
        spacing = 70
        self.add_slider("max_speed", "Max Speed", start_y, cfg["robot"].get("max_speed", 2.0), (0.2, 8.0))
        self.add_slider("max_omega", "Max Omega", start_y + spacing, cfg["robot"].get("max_omega", 2.0), (0.1, 6.0))
        self.add_slider("max_steer", "Max Steering", start_y + 2*spacing, cfg["robot"].get("max_steer", 0.6), (0.1, 1.2))
        self.add_slider("grid_size", "Grid Size", start_y + 3*spacing, cfg["world"].get("grid_size", 1.0), (0.2, 5.0))

    def create_info_labels(self):
        x = self.panel_x + 20
        w, h = 260, 30
        y = self.height - 45
        # self.elements["info"] = pygame_gui.elements.UILabel(pygame.Rect(x, y, w, h), "Ready", self.manager)

    def process_slider_event(self, event, robot, world, lidar, config):
        if event.type != pygame_gui.UI_HORIZONTAL_SLIDER_MOVED:
            return
        e = self.elements
        if event.ui_element == e["max_speed"]:
            robot.max_speed = e["max_speed"].get_current_value(); config["robot"]["max_speed"] = robot.max_speed; e["max_speed_value"].set_text(f"{robot.max_speed:.2f}")
        elif event.ui_element == e["max_omega"]:
            value = e["max_omega"].get_current_value(); config["robot"]["max_omega"] = value; e["max_omega_value"].set_text(f"{value:.2f}")
            if hasattr(robot, "max_omega"):
                robot.max_omega = value
        elif event.ui_element == e["max_steer"]:
            value = e["max_steer"].get_current_value(); config["robot"]["max_steer"] = value; e["max_steer_value"].set_text(f"{value:.2f}")
            if hasattr(robot, "max_steer"):
                robot.max_steer = value
        elif event.ui_element == e["grid_size"]:
            world.grid_size = e["grid_size"].get_current_value(); config["world"]["grid_size"] = world.grid_size; e["grid_size_value"].set_text(f"{world.grid_size:.2f}")

    def close_obstacle_radius_window(self):
        if self.obstacle_radius_window is not None:
            self.obstacle_radius_window.kill()

        self.obstacle_radius_window = None
        self.obstacle_radius_entry = None
        self.obstacle_radius_ok = None
        self.obstacle_radius_cancel = None
    def open_obstacle_radius_window(self, default_radius=0.4):
        # Se já existir uma janela aberta, fecha antes
        if self.obstacle_radius_window is not None:
            self.obstacle_radius_window.kill()

        window_rect = pygame.Rect(
            self.panel_x - 360,
            120,
            320,
            180
        )

        self.obstacle_radius_window = pygame_gui.elements.UIWindow(
            rect=window_rect,
            manager=self.manager,
            window_display_title="Novo Obstáculo"
        )

        pygame_gui.elements.UILabel(
            relative_rect=pygame.Rect(20, 35, 260, 30),
            text="Raio do obstáculo:",
            manager=self.manager,
            container=self.obstacle_radius_window
        )

        self.obstacle_radius_entry = pygame_gui.elements.UITextEntryLine(
            relative_rect=pygame.Rect(20, 70, 260, 32),
            manager=self.manager,
            container=self.obstacle_radius_window
        )

        self.obstacle_radius_entry.set_text(f"{default_radius:.2f}")

        self.obstacle_radius_ok = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect(35, 115, 100, 35),
            text="OK",
            manager=self.manager,
            container=self.obstacle_radius_window
        )

        self.obstacle_radius_cancel = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect(165, 115, 100, 35),
            text="Cancelar",
            manager=self.manager,
            container=self.obstacle_radius_window
        )

    def update_info(self, robot, waypoints, world, fps, running, lidar, camera):
        goal = waypoints.get_current_waypoint()
        dist = "None" if goal is None else f"{distance_between(robot.position, goal):.2f}"
        state = robot.state()
        rtype = state.get("type", "robot")
        if rtype == "holonomic":
            motion = f"vx={state.get('vx', 0.0):.2f} | vy={state.get('vy', 0.0):.2f}"
        elif rtype == "differential":
            motion = f"v={state.get('v', 0.0):.2f} | ω={state.get('omega', 0.0):.2f}"
        elif rtype == "ackermann":
            motion = f"v={state.get('speed', 0.0):.2f} | δ={math.degrees(state.get('steer', 0.0)):.1f}°"
        else:
            motion = "motion=None"
        text = f"{'RUN' if running else 'PAUSE'} | {rtype} | x={robot.x:.2f}, y={robot.y:.2f} | θ={math.degrees(robot.theta):.1f}° | {motion} | WP={waypoints.status_text()} | d={dist} | FPS={fps:.0f} | Obs={len(world.obstacles)} | Zoom={camera.zoom:.2f}"
        # self.elements["info"].set_text(text)
        
        padding = 8

        info_surface = self.font.render(
            text,
            True,
            (255,255,255)
        )

        bg_rect = pygame.Rect(
            5,
            5,
            info_surface.get_width() + 2*padding,
            info_surface.get_height() + 2*padding
        )

        overlay = pygame.Surface(
            (bg_rect.width, bg_rect.height),
            pygame.SRCALPHA
        )

        overlay.fill((0,0,0,180))

        self.screen.blit(
            overlay,
            (bg_rect.x, bg_rect.y)
        )

        self.screen.blit(
            info_surface,
            (10 + padding//2, 10 + padding//2)
        )
