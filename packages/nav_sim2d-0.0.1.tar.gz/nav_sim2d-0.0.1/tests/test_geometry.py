import math
from nav_sim2d.geometry import wrap_to_pi, clamp


def test_clamp():
    assert clamp(5, 0, 1) == 1
    assert clamp(-1, 0, 1) == 0
    assert clamp(0.5, 0, 1) == 0.5


def test_wrap_to_pi():
    assert -math.pi <= wrap_to_pi(4 * math.pi) <= math.pi
