from typing import Any, Dict, Literal, Mapping, Optional, Union

from msgflux.auto import AutoParams
from msgflux.core.dotdict import dotdict
from msgflux.core.message import Message
from msgflux.exceptions import _GuardInterrupt
from msgflux.models import Model
from msgflux.models.gateway import ModelGateway
from msgflux.models.response import ModelResponse, ModelStreamResponse
from msgflux.models.types import TextToSpeechModel
from msgflux.nn.modules.generator import Generator
from msgflux.nn.modules.module import Module


class Speaker(Module, metaclass=AutoParams):
    """Speaker is a Module type that uses language models to transform text in speak."""

    def __init__(
        self,
        model: Union[TextToSpeechModel, ModelGateway, str],
        *,
        hooks: Optional[list] = None,
        message_fields: Optional[Dict[str, Any]] = None,
        response_mode: Optional[str] = None,
        response_format: Optional[
            Literal["mp3", "opus", "aac", "flac", "wav", "pcm"]
        ] = "opus",
        prompt: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        name: Optional[str] = None,
    ):
        """Initialize the Speaker module.

        Args:
        model:
            Text-to-Speech model client. Accepts a `TextToSpeechModel`,
            `ModelGateway`, or a shorthand string in the form
            ``"provider/model-id"`` (e.g. ``"openai/gpt-4o-mini-tts"``).
            When a string is provided, `Model.text_to_speech` is called
            internally with no extra configuration.
        hooks:
            List of Hook instances to register on the model.
        message_fields:
            Dictionary mapping Message field names to their paths in the Message object.
            Valid keys: "task" (other fields not supported for Speaker).
            !!! example
                message_fields={"task": "input.user"}

            Field description:
            - task: Field path for task input (str)
        response_mode:
            Controls how the response is returned.
            * ``None`` (default): Returns the response directly.
            * ``"<path>"``: Writes to ``obj.<path>`` and returns ``None``
              (``dotdict`` or ``Message`` is mutated in place).
        response_format:
            The format to audio in.
        prompt:
            Useful for instructing the model to follow some speak generation pattern.
        config:
            Dictionary with configuration options. Accepts any keys without validation.
            Common option: "stream"
            !!! example
                config={"stream": False}

            Configuration option:
            - stream: Transmit response on-the-fly (bool)
        name:
            Speaker name in snake case format.
        """
        super().__init__()
        self._set_model(model)
        self._set_hooks(hooks)
        self._set_prompt(prompt)
        self._set_response_format(response_format)
        self._set_response_mode(response_mode)
        self._set_message_fields(message_fields)
        self._set_config(config)
        if name:
            self.set_name(name)

    def forward(
        self, message: Union[str, Message], **kwargs: Any
    ) -> Union[bytes, ModelStreamResponse]:
        """Execute the speaker with the given message.

        Args:
            message: The input message, which can be:
                - str: Direct text input to convert to speech
                - Message: Message object with fields mapped via message_fields
            **kwargs: Runtime overrides for message_fields. Can include:
                - task: Override field path or direct value

        Returns:
            Audio bytes or ModelStreamResponse if stream=True

        Examples:
            # Direct string input
            speaker("Hello world")

            # Using Message object with message_fields
            msg = Message(text="Hello world")
            speaker(msg)

            # Runtime override
            speaker(msg, task="custom.path")
        """
        inputs = self._prepare_inputs(message, **kwargs)
        try:
            model_response = self._execute_model(**inputs)
        except _GuardInterrupt as e:
            return e.response
        response = self._process_model_response(model_response, message)
        return response

    async def aforward(
        self, message: Union[str, Message], **kwargs: Any
    ) -> Union[bytes, ModelStreamResponse]:
        """Async version of forward. Execute the speaker asynchronously."""
        inputs = self._prepare_inputs(message, **kwargs)
        try:
            model_response = await self._aexecute_model(**inputs)
        except _GuardInterrupt as e:
            return e.response
        response = self._process_model_response(model_response, message)
        return response

    def _execute_model(
        self, data: str, model_preference: Optional[str] = None
    ) -> Union[ModelResponse, ModelStreamResponse]:
        model_execution_params = self._prepare_model_execution(data, model_preference)
        model_response = self.generator(**model_execution_params)
        return model_response

    async def _aexecute_model(
        self, data: str, model_preference: Optional[str] = None
    ) -> Union[ModelResponse, ModelStreamResponse]:
        model_execution_params = self._prepare_model_execution(data, model_preference)
        model_response = await self.generator.acall(**model_execution_params)
        return model_response

    def _prepare_model_execution(
        self, data: str, model_preference: Optional[str] = None
    ) -> Dict[str, Union[str, bool]]:
        model_execution_params = dotdict(
            data=data, response_format=self.response_format, prompt=self.prompt
        )
        stream = self.config.get("stream", False)
        if stream:
            model_execution_params.stream = stream
        if isinstance(self.model, ModelGateway) and model_preference is not None:
            model_execution_params.model_preference = model_preference
        return model_execution_params

    def _process_model_response(
        self,
        model_response: Union[ModelResponse, ModelStreamResponse],
        message: Union[str, Message],
    ) -> Union[bytes, Message, ModelStreamResponse]:
        if model_response.response_type == "audio_generation":
            raw_response = self._extract_raw_response(model_response)
            response = self._prepare_response(raw_response, message)
            return response
        else:
            raise ValueError(
                f"Unsupported model response type `{model_response.response_type}`"
            )

    def _prepare_inputs(self, message: Union[str, Message], **kwargs) -> Dict[str, str]:
        if isinstance(message, dotdict):
            data = self._extract_message_values(self.task, message)
            if data is None:
                raise ValueError(f"No text found in paths: `{self.task}`")
        elif isinstance(message, str):
            data = message
        else:
            raise ValueError(f"Unsupported message type: `{type(message)}`")

        model_preference = kwargs.pop("model_preference", None)
        if model_preference is None and isinstance(message, dotdict):
            model_preference = self.get_model_preference_from_message(message)

        return {"data": data, "model_preference": model_preference}

    def inspect_model_execution_params(self, *args, **kwargs) -> Mapping[str, Any]:
        """Debug model input parameters."""
        inputs = self._prepare_inputs(*args, **kwargs)
        model_execution_params = self._prepare_model_execution(**inputs)
        return model_execution_params

    def _set_model(self, model: Union[TextToSpeechModel, ModelGateway, str]):
        if isinstance(model, str):
            model = Model.text_to_speech(model)
        if model.model_type == "text_to_speech":
            self.generator = Generator(model)
        else:
            raise TypeError(
                f"`model` need be a `text_to_speech` model, given `{type(model)}`"
            )

    @property
    def model(self):
        """Access underlying model."""
        return self.generator.model

    @model.setter
    def model(self, value: Union[TextToSpeechModel, ModelGateway, str]):
        self._set_model(value)

    def _set_response_format(self, response_format: str):
        supported_formats = ["mp3", "opus", "aac", "flac", "wav", "pcm"]
        if isinstance(response_format, str):
            if response_format in supported_formats:
                self.register_buffer("response_format", response_format)
            else:
                raise ValueError(
                    f"`response_format` can be `{supported_formats}` "
                    f"given `{response_format}"
                )
        else:
            raise TypeError(
                f"`response_format` need be a str or given `{type(response_format)}"
            )

    def _set_config(self, config: Optional[Dict[str, Any]] = None):
        if config is None:
            self.register_buffer("config", {})
            return

        if not isinstance(config, dict):
            raise TypeError(f"`config` must be a dict or None, given `{type(config)}`")

        self.register_buffer("config", config.copy())
