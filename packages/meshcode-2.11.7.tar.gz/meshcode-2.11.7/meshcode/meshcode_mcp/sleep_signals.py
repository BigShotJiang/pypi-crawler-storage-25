"""Sleep-authorization signal parser for the wait loop.

Pure module — no side effects, no env deps. Extracted from server.py so the
parser can be imported and tested in isolation. server.py re-exports these
names for back-compat.

Authorizes a wait-loop exit (must_exit=True) only on explicit sleep-auth
context. Two valid encodings:

  (1) STRUCTURED DIRECTIVE — payload.type or payload.directive is in
      _SLEEP_PAYLOAD_TYPES. Deliberately-shaped messages; an agent that
      sets payload.type to a sleep verb is issuing a directive on purpose.
  (2) HUMAN TEXT KEYWORD — payload.text contains a sleep marker AND the
      sender is a human user.

Plain text idioms from AI-role agents are deliberately IGNORED — quoting
"a dormir" or describing "Samuel cierra la sesion" inside a debate-close
summary is not authorization. Task fabfc602 (bob@justforfun 2026-05-14).
"""
from __future__ import annotations

from typing import Any, Dict, List

_SLEEP_PAYLOAD_TYPES = {"sleep", "go_to_sleep", "shutdown", "got_done", "done",
                        "exit", "stop", "kill", "terminate"}

# Multi-word imperative markers ONLY. Single Spanish verbs like "salir" /
# "terminar" / "duerme" were too loose and caught idiomatic prose like
# "terminaron sus tasks" or "no puedo salir" (msg cfbd36b0 2026-05-14 alexa +
# commander incidents — feedback_done_signal_false_positive_idiomatic
# precedent). The parser requires a directive-shaped phrase: a verb
# combined with a temporal/object qualifier ("ahora" / "todos" / "to sleep")
# so describing an event in prose can't trip must_exit.
_SLEEP_TEXT_MARKERS = (
    # English directives
    "go to sleep", "all sleep now", "sleep now", "got_done", "go_done",
    "shut down", "shutdown", "stop now", "exit now",
    # Spanish directives (es-MX). Each requires a leading "a"/"todos" or
    # a trailing "ahora" so plain conjugations in prose don't trigger.
    "a dormir", "todos a dormir", "duerme ahora", "duerman ahora",
    "dormir ahora", "para la sesion", "exit y duerme",
)

# Back-compat fallback for messages predating mig 289 (payload.sender_role
# stamping). Kept in sync with _stop_hook_template._KNOWN_HUMAN_HANDLES so
# server + hook share authority on who counts as a human user.
_KNOWN_HUMAN_HANDLES = frozenset({"sammybenu", "samuel", "sam"})


def _is_human_authored(m: Dict[str, Any]) -> bool:
    """True when the message carries explicit human-user authorship.

    Two encodings (mig 289 + back-compat):
      (a) payload.sender_role == "human_user" (or .from_role) — server-stamped
      (b) sender handle in _KNOWN_HUMAN_HANDLES — pre-mig-289 fallback
    """
    pl = m.get("payload") or {}
    if isinstance(pl, dict):
        role = pl.get("sender_role") or pl.get("from_role")
        if isinstance(role, str) and role.lower() == "human_user":
            return True
    sender = m.get("from") or ""
    if isinstance(sender, str) and sender.lower() in _KNOWN_HUMAN_HANDLES:
        return True
    return False


def _looks_like_sleep_signal(m: Dict[str, Any]) -> bool:
    """Detect mesh messages that authorize the wait-loop exit.

    See module docstring for the two valid encodings and the rationale
    for ignoring idiom matches from AI-role senders.
    """
    pl = m.get("payload") or {}
    if isinstance(pl, dict):
        if str(pl.get("type", "")).lower() in _SLEEP_PAYLOAD_TYPES:
            return True
        if str(pl.get("directive", "")).lower() in _SLEEP_PAYLOAD_TYPES:
            return True
        text = str(pl.get("text", "")).lower()
        if text and any(marker in text for marker in _SLEEP_TEXT_MARKERS):
            if _is_human_authored(m):
                return True
    return False


def _split_messages(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Split a list of normalized message dicts into messages / acks / done_signals.

    Classifies any message carrying a sleep intent into done_signals so
    meshcode_wait surfaces them with must_exit=True. Idiom matches from
    AI-role senders fall through to plain `messages` (no must_exit).
    """
    real: List[Dict[str, Any]] = []
    acks: List[Dict[str, Any]] = []
    dones: List[Dict[str, Any]] = []
    for m in messages:
        t = m.get("type", "msg")
        if t == "ack":
            acks.append(m)
        elif t == "done" or _looks_like_sleep_signal(m):
            dones.append(m)
        else:
            real.append(m)
    return {
        "messages": real,
        "acks": acks,
        "done_signals": dones,
        "count": len(real),
    }
