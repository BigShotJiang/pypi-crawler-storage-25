"""
Epistemic V1 stop-condition tests (task b4befbfd item 5).

Hits public.mc_epistemic_v1_health() (mig 316) and asserts every condition
reports is_healthy=true. If any trips, this test fails — pausing instrumentation
until the condition is investigated per the original task spec.

Five conditions covered:
  1. phase3_eta — Phase 3 ETA > 3 weeks
  2. detector_false_positive_rate — > 30% on samples >= 20
  3. memory_hints_p95_latency_ms — > 100ms (stub, healthy-by-default in v1)
  4. mc_traces_3mo_count — > 1,000,000 rows in trailing 3 months
  5. meshcode_explain_calls_2wk — zero in trailing 14d after first seen

Usage:
    MESHCODE_SUPABASE_URL=https://...supabase.co \\
    MESHCODE_SUPABASE_ANON_KEY=sb_publishable_... \\
    pytest tests/test_epistemic_v1_stop_conditions.py -v
"""

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


def _live_or_skip():
    if not os.environ.get("MESHCODE_SUPABASE_URL"):
        pytest.skip("MESHCODE_SUPABASE_URL not set; epistemic V1 health is live-only.")


def test_epistemic_v1_health_all_conditions_healthy():
    """Live check: call mc_epistemic_v1_health() and assert each is_healthy."""
    _live_or_skip()
    from meshcode.meshcode_mcp import backend as be
    resp = be.sb_rpc("mc_epistemic_v1_health", {})
    assert isinstance(resp, dict) and resp.get("ok"), f"RPC failed: {resp}"
    conditions = resp.get("conditions") or {}
    expected_keys = {
        "phase3_eta",
        "detector_false_positive_rate",
        "memory_hints_p95_latency_ms",
        "mc_traces_3mo_count",
        "meshcode_explain_calls_2wk",
    }
    assert set(conditions.keys()) == expected_keys, (
        f"missing or extra conditions: got {sorted(conditions.keys())} "
        f"expected {sorted(expected_keys)}"
    )
    unhealthy = {k: v for k, v in conditions.items() if not v.get("is_healthy")}
    assert not unhealthy, f"Unhealthy stop conditions tripped: {unhealthy}"


def test_phase3_eta_trip():
    """Offline: synthetic response with phase3_eta breached → assert detected."""
    fake = {
        "ok": True,
        "conditions": {
            "phase3_eta": {"value": "2026-06-30T00:00Z", "is_healthy": False},
            "detector_false_positive_rate": {"is_healthy": True},
            "memory_hints_p95_latency_ms": {"is_healthy": True},
            "mc_traces_3mo_count": {"is_healthy": True},
            "meshcode_explain_calls_2wk": {"is_healthy": True},
        },
    }
    with patch("meshcode.meshcode_mcp.backend.sb_rpc", return_value=fake):
        from meshcode.meshcode_mcp import backend as be
        resp = be.sb_rpc("mc_epistemic_v1_health", {})
    unhealthy = {k: v for k, v in resp["conditions"].items() if not v["is_healthy"]}
    assert list(unhealthy.keys()) == ["phase3_eta"]


def test_detector_fp_rate_trip():
    fake = {
        "ok": True,
        "conditions": {
            "phase3_eta": {"is_healthy": True},
            "detector_false_positive_rate": {"value": 0.42, "is_healthy": False, "sample_size": 50},
            "memory_hints_p95_latency_ms": {"is_healthy": True},
            "mc_traces_3mo_count": {"is_healthy": True},
            "meshcode_explain_calls_2wk": {"is_healthy": True},
        },
    }
    with patch("meshcode.meshcode_mcp.backend.sb_rpc", return_value=fake):
        from meshcode.meshcode_mcp import backend as be
        resp = be.sb_rpc("mc_epistemic_v1_health", {})
    assert resp["conditions"]["detector_false_positive_rate"]["is_healthy"] is False
    assert resp["conditions"]["detector_false_positive_rate"]["value"] > 0.30


def test_mc_traces_capacity_trip():
    fake = {
        "ok": True,
        "conditions": {
            "phase3_eta": {"is_healthy": True},
            "detector_false_positive_rate": {"is_healthy": True},
            "memory_hints_p95_latency_ms": {"is_healthy": True},
            "mc_traces_3mo_count": {"value": 1_500_000, "is_healthy": False},
            "meshcode_explain_calls_2wk": {"is_healthy": True},
        },
    }
    with patch("meshcode.meshcode_mcp.backend.sb_rpc", return_value=fake):
        from meshcode.meshcode_mcp import backend as be
        resp = be.sb_rpc("mc_epistemic_v1_health", {})
    assert resp["conditions"]["mc_traces_3mo_count"]["value"] > 1_000_000


def test_explain_read_path_failure_trip():
    """Zero meshcode_explain calls in 14d after first_seen → read_path_failure_suspected."""
    fake = {
        "ok": True,
        "conditions": {
            "phase3_eta": {"is_healthy": True},
            "detector_false_positive_rate": {"is_healthy": True},
            "memory_hints_p95_latency_ms": {"is_healthy": True},
            "mc_traces_3mo_count": {"is_healthy": True},
            "meshcode_explain_calls_2wk": {
                "value": 0,
                "first_seen_at": "2026-04-01T00:00Z",  # >14d ago
                "is_healthy": False,
            },
        },
    }
    with patch("meshcode.meshcode_mcp.backend.sb_rpc", return_value=fake):
        from meshcode.meshcode_mcp import backend as be
        resp = be.sb_rpc("mc_epistemic_v1_health", {})
    cond = resp["conditions"]["meshcode_explain_calls_2wk"]
    assert cond["is_healthy"] is False
    assert cond["value"] == 0
    assert cond["first_seen_at"] is not None  # first_seen was before window


def test_memory_hints_latency_stub_returns_healthy():
    """Stub returns healthy-by-default until recorder ships."""
    fake = {
        "ok": True,
        "conditions": {
            "phase3_eta": {"is_healthy": True},
            "detector_false_positive_rate": {"is_healthy": True},
            "memory_hints_p95_latency_ms": {
                "value": None,
                "sample_size": 0,
                "is_healthy": True,
            },
            "mc_traces_3mo_count": {"is_healthy": True},
            "meshcode_explain_calls_2wk": {"is_healthy": True},
        },
    }
    with patch("meshcode.meshcode_mcp.backend.sb_rpc", return_value=fake):
        from meshcode.meshcode_mcp import backend as be
        resp = be.sb_rpc("mc_epistemic_v1_health", {})
    cond = resp["conditions"]["memory_hints_p95_latency_ms"]
    assert cond["is_healthy"] is True
    assert cond["sample_size"] == 0
