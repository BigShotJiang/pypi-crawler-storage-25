"""
Install-guard sentinel (task dbae99ed → closes
feedback_pip_install_into_live_mcp_env_self_kill weight 9).

Verifies that _install_guard_check() in meshcode_mcp.server detects
mid-session *.py mtime bumps under the package path and triggers a
clean execv-restart (not crash).

Strategy:
  - Snapshot the package mtimes on a fake directory inside a tmpdir,
    monkey-patched in as _PKG_DIR and _PKG_PY_MTIMES.
  - Touch one of the tracked files to simulate `pip install --force-reinstall`.
  - Monkey-patch os.execv / os._exit / _release_lease_synchronous so the
    test process doesn't actually re-exec.
  - Call _install_guard_check(); assert execv was invoked with the right
    argv shape.

Pure unit test — no subprocess, no live DB.
"""

import os
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


def _setup_fake_pkg(tmpdir):
    """Materialize two *.py files under tmpdir and return a {path: mtime} snapshot."""
    pkg = Path(tmpdir)
    (pkg / "a.py").write_text("x = 1\n")
    (pkg / "b.py").write_text("y = 2\n")
    snap = {str(p): p.stat().st_mtime for p in pkg.rglob("*.py")}
    return pkg, snap


def test_install_guard_no_modification_is_silent():
    """When nothing changed, _install_guard_check returns quickly without
    triggering execv. Catches a future regression that would force re-exec
    on every tick."""
    from meshcode.meshcode_mcp import server as srv
    with tempfile.TemporaryDirectory() as td:
        pkg, snap = _setup_fake_pkg(td)
        with patch.object(srv, "_PKG_DIR", pkg), \
             patch.object(srv, "_PKG_PY_MTIMES", snap), \
             patch.object(srv.os, "execv") as mock_execv, \
             patch.object(srv.os, "_exit") as mock_exit, \
             patch.object(srv, "_release_lease_synchronous", return_value=True):
            srv._install_guard_check()
            assert not mock_execv.called
            assert not mock_exit.called


def test_install_guard_mtime_bump_triggers_execv():
    """Simulate pip --force-reinstall: bump mtime on a tracked *.py.
    Assert _install_guard_check calls os.execv with (sys.executable, [sys.executable]+sys.argv)."""
    from meshcode.meshcode_mcp import server as srv
    with tempfile.TemporaryDirectory() as td:
        pkg, snap = _setup_fake_pkg(td)
        # Sleep so the new mtime exceeds the 0.5s slack window
        time.sleep(0.7)
        (pkg / "a.py").write_text("x = 99\n")  # "reinstall" rewrites the file
        with patch.object(srv, "_PKG_DIR", pkg), \
             patch.object(srv, "_PKG_PY_MTIMES", snap), \
             patch.object(srv.os, "execv") as mock_execv, \
             patch.object(srv.os, "_exit") as mock_exit, \
             patch.object(srv, "_release_lease_synchronous", return_value=True):
            srv._install_guard_check()
            assert mock_execv.called, "execv was not called on mtime bump"
            args, _ = mock_execv.call_args
            assert args[0] == sys.executable, f"first arg should be sys.executable, got {args[0]!r}"
            assert args[1][0] == sys.executable, "argv[0] should match sys.executable"
            assert args[1][1:] == sys.argv, "execv argv tail should match current sys.argv"
            # _exit fallback should NOT fire when execv "succeeded" (mock)
            assert not mock_exit.called


def test_install_guard_execv_failure_falls_back_to_os_exit():
    """If execv raises (rare, but e.g. permissions), the guard should not
    crash — it should fall back to os._exit(0) so lifespan finally + the
    stop_hook recover the agent."""
    from meshcode.meshcode_mcp import server as srv
    with tempfile.TemporaryDirectory() as td:
        pkg, snap = _setup_fake_pkg(td)
        time.sleep(0.7)
        (pkg / "a.py").write_text("x = 99\n")
        with patch.object(srv, "_PKG_DIR", pkg), \
             patch.object(srv, "_PKG_PY_MTIMES", snap), \
             patch.object(srv.os, "execv", side_effect=OSError("simulated execv failure")), \
             patch.object(srv.os, "_exit") as mock_exit, \
             patch.object(srv, "_release_lease_synchronous", return_value=True):
            srv._install_guard_check()
            assert mock_exit.called, "os._exit fallback did not fire after execv failure"
            args, _ = mock_exit.call_args
            assert args[0] == 0, "fallback exit code should be 0"


def test_install_guard_with_empty_snapshot_no_op():
    """If _PKG_PY_MTIMES is empty (boot couldn't scan), the guard must be
    a no-op — never trigger execv on an empty baseline."""
    from meshcode.meshcode_mcp import server as srv
    with patch.object(srv, "_PKG_PY_MTIMES", {}), \
         patch.object(srv.os, "execv") as mock_execv, \
         patch.object(srv.os, "_exit") as mock_exit:
        srv._install_guard_check()
        assert not mock_execv.called
        assert not mock_exit.called
