"""
Boot-bug regression sentinels (task abae2997 → closes the class identified in
memory project_mesh_commander_mcp_failed_at_launch weight 10).

Two tests, one per RC of the 2026-05-18 boot bug:

(a) IMPORT-TIME RPC ALLOWLIST
    Spawns a subprocess that:
      - Monkeypatches meshcode.meshcode_mcp.backend.sb_rpc to record every
        call name. Then ALLOWS only an explicit whitelist (currently:
        mc_register_agent — required for agent identity at startup), and
        raises on anything else.
      - Sets the minimum env vars so the import doesn't legitimately fall
        through to the mc_resolve_project path.
      - Imports meshcode.meshcode_mcp.server.
      - Asserts the import completes and no NON-WHITELISTED RPC was called
        at module-import time. Catches drift toward the Claude Code MCP-
        handshake window (Plan A bug, RC #2).

    To widen the whitelist intentionally, add to ALLOWED_IMPORT_RPCS below
    AND document why in the comment block. Most import-time RPCs are bugs
    waiting to happen — keep the list as short as possible.

(b) REGISTER-ALL-VALID-STATUSES
    Live-DB test (skips without env vars). Reads public.mc_agent_all_statuses()
    from prod, attempts mc_register_agent with each value (inside a transaction
    that rolls back). Asserts no 23514 / valid_agent_status CHECK violation.
    This catches future SDK↔DDL enum drift like the 'needs_launch' incident
    (mig 312 bug, RC #1).

Usage:
    pytest tests/test_boot_bug_regression.py -v

    # live test only:
    MESHCODE_SUPABASE_URL=https://...supabase.co \\
    MESHCODE_SUPABASE_ANON_KEY=sb_publishable_... \\
    MESHCODE_PROJECT_ID=... \\
    pytest tests/test_boot_bug_regression.py::test_register_all_valid_statuses_live -v
"""

import os
import subprocess
import sys
import textwrap
import uuid
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).parent.parent


def test_module_import_rpc_allowlist():
    """RC #2 sentinel — Plan A. Fails if a NON-WHITELISTED be.sb_rpc is
    called at module-import time. That class of call breaks MCP handshake
    on heavy-memory agents."""
    snippet = textwrap.dedent(
        """
        import os, sys
        os.environ.setdefault('MESHCODE_PROJECT', 'meshcode-self-improve')
        os.environ.setdefault('MESHCODE_AGENT', 'backend')
        os.environ.setdefault('MESHCODE_PROJECT_ID',
            '00000000-0000-0000-0000-000000000000')
        os.environ.setdefault('MESHCODE_SUPABASE_URL', 'https://fake.local')
        os.environ.setdefault('MESHCODE_SUPABASE_ANON_KEY', 'fake_anon')

        # Allow-list: RPCs that may legitimately run at module-import time.
        # Keep this list as short as possible — most additions indicate a
        # latent boot-bug. Document each entry's reason.
        ALLOWED_IMPORT_RPCS = {
            # mc_register_agent: agent identity must exist before the first
            # tool call; lazy-registering on first call would mean tools
            # can fire from a non-existent agent_id. Tolerated at boot;
            # response is small (single row insert/upsert).
            'mc_register_agent',
            # mc_release_agent_lease: post-SIGKILL stale-lease release.
            # Only fires when _kill_stale_mcp_process found a prior dead
            # process. Single-row update; latency negligible.
            'mc_release_agent_lease',
            # mc_memory_get: restore inbox watermark (last_seen). Single-
            # row lookup; cheap. Could be deferred to first meshcode_check
            # but the value is needed before the first wait() returns.
            'mc_memory_get',
        }

        import meshcode.meshcode_mcp.backend as be
        _calls = []

        def _gated(name, *a, **kw):
            _calls.append(name)
            if name not in ALLOWED_IMPORT_RPCS:
                raise RuntimeError(
                    'MODULE_IMPORT_RPC_LEAK: be.sb_rpc called at module-import '
                    f'time with NON-WHITELISTED rpc={name!r}. '
                    'If this is intentional, defer to lifespan BG thread '
                    '(see _load_persona_bg pattern) or add to ALLOWED_IMPORT_RPCS '
                    'with rationale.'
                )
            # Return a minimal-shape ok response so import flow completes.
            return {'ok': True, 'id': None}

        be.sb_rpc = _gated

        import meshcode.meshcode_mcp.server  # noqa: F401
        print(f'IMPORT_OK calls={_calls}')
        """
    )

    result = subprocess.run(
        [sys.executable, '-c', snippet],
        capture_output=True,
        text=True,
        cwd=REPO_ROOT,
        timeout=30,
    )

    # meshcode boot prints to stderr by design; combine both streams for the
    # IMPORT_OK / leak markers.
    combined = (result.stdout or '') + '\n' + (result.stderr or '')
    assert result.returncode == 0, (
        f"Module import subprocess crashed.\n"
        f"--- stdout ---\n{result.stdout}\n"
        f"--- stderr ---\n{result.stderr}"
    )
    assert 'IMPORT_OK' in combined, (
        f"Module import did not complete cleanly:\n{combined}"
    )
    assert 'MODULE_IMPORT_RPC_LEAK' not in combined, (
        f"Non-whitelisted be.sb_rpc fired at module-import time. "
        f"This breaks MCP handshake on heavy-memory agents.\n{combined}"
    )


def test_register_all_valid_statuses_live():
    """RC #1 sentinel — mig 312. Catches SDK↔DDL enum drift like the
    'needs_launch' incident.

    Live-only. Reads public.mc_agent_all_statuses() and tries each value via
    mc_register_agent inside a savepoint-rolled-back transaction so no real
    agents are created. Assertion: no 23514 CHECK constraint violation.
    """
    pat = os.environ.get('MESHCODE_SUPABASE_MGMT_PAT') or os.environ.get('SUPABASE_PAT')
    project_ref = (
        os.environ.get('MESHCODE_SUPABASE_PROJECT_REF')
        or os.environ.get('SUPABASE_PROJECT_REF')
        or 'gjinagyyjttyxnaoavnz'
    )
    project_id = os.environ.get('MESHCODE_PROJECT_ID')

    if not (pat and project_id):
        pytest.skip(
            'MESHCODE_SUPABASE_MGMT_PAT + MESHCODE_PROJECT_ID required for live '
            'register-all-statuses test'
        )

    import json
    import urllib.request

    def run_sql(sql: str) -> object:
        req = urllib.request.Request(
            f'https://api.supabase.com/v1/projects/{project_ref}/database/query',
            data=json.dumps({'query': sql}).encode('utf-8'),
            headers={
                'Authorization': f'Bearer {pat}',
                'Content-Type': 'application/json',
            },
            method='POST',
        )
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())

    rows = run_sql("SELECT unnest(public.mc_agent_all_statuses()) AS status;")
    statuses = [r['status'] for r in rows if isinstance(r, dict) and 'status' in r]
    assert statuses, f'public.mc_agent_all_statuses() returned no rows: {rows!r}'

    failures = []
    for st in statuses:
        marker = f'__sentinel_{uuid.uuid4().hex[:8]}__'
        sql = (
            "BEGIN; "
            f"INSERT INTO meshcode.mc_agents (project_id, name, role, status, "
            f"registered_at, last_heartbeat) VALUES "
            f"('{project_id}'::uuid, '{marker}', 'sentinel', '{st}', now(), now()) "
            f"RETURNING status; "
            "ROLLBACK;"
        )
        try:
            res = run_sql(sql)
        except urllib.error.HTTPError as e:
            body = e.read().decode('utf-8', 'replace')
            failures.append((st, f'HTTP {e.code}: {body[:200]}'))
            continue

        # Mgmt API returns either a list of rows or {"message": "..."} on err
        if isinstance(res, dict) and 'message' in res:
            msg = res['message']
            # Tolerate name-format CHECK or other unrelated checks; the
            # status CHECK is the one we care about.
            if 'valid_agent_status' in msg or '23514' in msg and 'status' in msg:
                failures.append((st, msg[:200]))

    assert not failures, (
        'SDK↔DDL enum drift detected — some statuses fail valid_agent_status '
        f'CHECK:\n{failures}'
    )
