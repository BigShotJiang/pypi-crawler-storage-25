"""Regression tests for the done_signals / must_exit parser.

Task fabfc602 (bob@justforfun 2026-05-14): the parser was tripping must_exit
on idiom matches from AI-role agents — quoting "a dormir", describing
"cierra los ojos / descansa", saying "close" in a debate-close summary. This
suite locks in the new rule: text-marker matches require a human sender;
only structured payload.type/directive matches fire on their own.
"""
from __future__ import annotations

import unittest

from meshcode.meshcode_mcp.sleep_signals import (
    _is_human_authored,
    _looks_like_sleep_signal,
    _split_messages,
)


def _msg(sender="ai-agent", payload=None, mtype="msg"):
    return {"from": sender, "type": mtype, "payload": payload or {}}


class TestIdiomFalsePositives(unittest.TestCase):
    """The 4 idioms in the bug report MUST NOT trip must_exit when an
    AI-role agent says them in arbitrary prose."""

    def test_terminar_sesion_in_ai_prose(self):
        m = _msg(sender="alexa", payload={"text": "vamos a terminar sesion ya"})
        self.assertFalse(_looks_like_sleep_signal(m))

    def test_close_idiom_in_ai_prose(self):
        m = _msg(sender="bob", payload={"text": "let's close out the debate"})
        self.assertFalse(_looks_like_sleep_signal(m))

    def test_cierra_los_ojos_descansa(self):
        m = _msg(sender="commander-bot", payload={"text": "cierra los ojos / descansa"})
        self.assertFalse(_looks_like_sleep_signal(m))

    def test_sleep_keyword_in_ai_prose(self):
        m = _msg(sender="wren", payload={"text": "go to sleep was Samuel's old line"})
        self.assertFalse(_looks_like_sleep_signal(m))

    def test_quoted_a_dormir_from_ai_summary(self):
        # Real-world false positive precedent (feedback_done_signal_false_positive_idiomatic)
        m = _msg(sender="mesh-commander",
                 payload={"text": 'Samuel respondió "a dormir" hace rato'})
        self.assertFalse(_looks_like_sleep_signal(m))


class TestHumanTextAuthorization(unittest.TestCase):
    """Same idioms from a human user MUST trip must_exit (gold path)."""

    def test_human_sender_role_stamp_sleep_now(self):
        m = _msg(sender="bob@justforfun",
                 payload={"text": "sleep now", "sender_role": "human_user"})
        self.assertTrue(_looks_like_sleep_signal(m))

    def test_human_sender_role_stamp_a_dormir(self):
        m = _msg(sender="wren@justforfun",
                 payload={"text": "todos a dormir", "sender_role": "human_user"})
        self.assertTrue(_looks_like_sleep_signal(m))

    def test_known_handle_back_compat_sammybenu(self):
        # Pre-mig-289 fallback: sammybenu has no sender_role stamp.
        m = _msg(sender="sammybenu", payload={"text": "a dormir"})
        self.assertTrue(_looks_like_sleep_signal(m))

    def test_from_role_alias_accepted(self):
        m = _msg(sender="someone",
                 payload={"text": "go to sleep", "from_role": "human_user"})
        self.assertTrue(_looks_like_sleep_signal(m))


class TestStructuredDirective(unittest.TestCase):
    """Structured payload.type / payload.directive matches fire regardless
    of sender — these are deliberately-shaped directives."""

    def test_got_done_broadcast_from_commander(self):
        m = _msg(sender="mesh-commander", mtype="broadcast",
                 payload={"type": "got_done"})
        self.assertTrue(_looks_like_sleep_signal(m))

    def test_payload_type_sleep_from_ai(self):
        m = _msg(sender="any-agent", payload={"type": "sleep"})
        self.assertTrue(_looks_like_sleep_signal(m))

    def test_payload_directive_shutdown(self):
        m = _msg(sender="any-agent", payload={"directive": "shutdown"})
        self.assertTrue(_looks_like_sleep_signal(m))

    def test_payload_type_unknown_is_not_sleep(self):
        m = _msg(sender="any-agent", payload={"type": "msg"})
        self.assertFalse(_looks_like_sleep_signal(m))


class TestEdgeCases(unittest.TestCase):

    def test_empty_payload(self):
        self.assertFalse(_looks_like_sleep_signal(_msg(payload={})))

    def test_payload_not_dict(self):
        self.assertFalse(_looks_like_sleep_signal({"from": "x", "payload": "a dormir"}))

    def test_human_authored_helper_payload_role(self):
        self.assertTrue(_is_human_authored({"from": "x",
                                            "payload": {"sender_role": "human_user"}}))

    def test_human_authored_helper_known_handle(self):
        self.assertTrue(_is_human_authored({"from": "Sammybenu", "payload": {}}))

    def test_human_authored_helper_negative(self):
        self.assertFalse(_is_human_authored({"from": "bob", "payload": {}}))


class TestSplitMessages(unittest.TestCase):
    """End-to-end: _split_messages routes by source-of-authority."""

    def test_idiom_from_ai_lands_in_messages_not_dones(self):
        msgs = [_msg(sender="mesh-commander",
                     payload={"text": "ya cierra los ojos y descansa"})]
        out = _split_messages(msgs)
        self.assertEqual(len(out["done_signals"]), 0)
        self.assertEqual(len(out["messages"]), 1)
        self.assertEqual(out["count"], 1)

    def test_human_sleep_lands_in_dones(self):
        msgs = [_msg(sender="sammybenu", payload={"text": "a dormir"})]
        out = _split_messages(msgs)
        self.assertEqual(len(out["done_signals"]), 1)
        self.assertEqual(len(out["messages"]), 0)

    def test_got_done_broadcast_lands_in_dones(self):
        msgs = [_msg(sender="mesh-commander", mtype="broadcast",
                     payload={"type": "got_done"})]
        out = _split_messages(msgs)
        self.assertEqual(len(out["done_signals"]), 1)

    def test_ack_lands_in_acks(self):
        msgs = [_msg(mtype="ack", payload={})]
        out = _split_messages(msgs)
        self.assertEqual(len(out["acks"]), 1)
        self.assertEqual(out["count"], 0)

    def test_mixed_batch(self):
        msgs = [
            _msg(sender="ai", payload={"text": "a dormir is what Samuel said"}),
            _msg(sender="sammybenu", payload={"text": "a dormir"}),
            _msg(sender="commander", mtype="broadcast", payload={"type": "got_done"}),
            _msg(sender="other", payload={"text": "normal chatter"}),
            _msg(mtype="ack", payload={}),
        ]
        out = _split_messages(msgs)
        self.assertEqual(len(out["done_signals"]), 2)  # human + got_done
        self.assertEqual(len(out["messages"]), 2)      # ai idiom + normal
        self.assertEqual(len(out["acks"]), 1)


if __name__ == "__main__":
    unittest.main()
