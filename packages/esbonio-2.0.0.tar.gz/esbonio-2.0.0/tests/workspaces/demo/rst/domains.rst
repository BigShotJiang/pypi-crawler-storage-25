.. toctree::
   :glob:

   domains/*
