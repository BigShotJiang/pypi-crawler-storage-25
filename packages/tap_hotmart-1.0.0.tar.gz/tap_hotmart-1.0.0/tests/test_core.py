"""Singer SDK standard compliance tests.

These tests verify that the tap conforms to the Singer spec.
When config.json is present (real credentials), all tests run against the live API.
Without config.json, tests that require real records are skipped.
"""

from __future__ import annotations

import json
from pathlib import Path

from singer_sdk.testing import SuiteConfig, get_tap_test_class

from tap_hotmart.tap import TapHotmart
from tests.conftest import FAKE_CONFIG

_config_path = Path(__file__).parent.parent / "config.json"
if _config_path.exists():
    with _config_path.open() as _f:
        _TEST_CONFIG = json.load(_f)
else:
    _TEST_CONFIG = FAKE_CONFIG

TestTapHotmart = get_tap_test_class(
    TapHotmart,
    config=_TEST_CONFIG,
    suite_config=SuiteConfig(ignore_no_records_for_streams=["transactions", "subscriptions", "commissions"]),
)
