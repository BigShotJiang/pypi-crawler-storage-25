# edgellm-bench

CLI tool for benchmarking TensorRT Edge-LLM models. Automates the full pipeline: **download ONNX model -> build TensorRT engine -> run benchmark**.

Supports standard LLM, VLM (vision-language), Eagle speculative decoding, ASR (audio speech recognition), and TTS (text-to-speech) models.

## Prerequisites

- Python >= 3.10
- NVIDIA GPU with TensorRT support
- Network access to NAS server (for model download)
- Git (for automatic repo cloning in Step 0)
- CMake >= 3.20 and a C++17 compiler (for project build)

> **Note:** The TensorRT Edge-LLM SDK no longer needs to be pre-built.
> `edgellm-bench run` will automatically clone the repo and build the C++ executables
> if they are not found (Step 0). You can skip this with `--skip-project-build`.

## Setup

```bash
pip install edgellm-bench
```

If the install fails (e.g. on systems with a custom PyPI mirror), specify the index URL explicitly:

```bash
pip install --upgrade edgellm-bench --extra-index-url https://pypi.org/simple/
```

Or install from source for development:

```bash
# From the edgellm-bench directory
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

### Quick start

```bash
# Standard LLM
edgellm-bench run --model Qwen2.5-0.5B-Instruct --precision llm-nvfp4-lmhead-fp16

# VLM (LLM + visual encoder)
edgellm-bench run --model InternVL3-1B --precision llm-nvfp4-lmhead-fp16-vit-fp16

# Eagle speculative decoding (base + draft)
edgellm-bench run --model Qwen3-1.7B --precision llm-nvfp4-lmhead-fp16-draft-nvfp4

# ASR (LLM + audio encoder)
edgellm-bench run --model Qwen3-ASR-0.6B --precision llm-fp16-lmhead-fp16-audio-fp16
```

### Running location (important)

Default paths are resolved **relative to the current working directory**:

| Path | Default | Used for |
|------|---------|----------|
| `build/` | `./build` | Locating `llm_build` / `llm_bench` / `llm_inference` |
| `tmp/onnx/` | `./tmp/onnx` | Downloaded ONNX models |
| `tmp/engines/` | `./tmp/engines` | Built TensorRT engines |

**Recommended (simplest):** `cd` to the TensorRT Edge-LLM SDK root (the directory containing `build/`) and run from there — defaults just work:

```bash
cd /path/to/tensorrt-edge-llm        # SDK root with ./build inside
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16
```

**Otherwise, specify paths manually.** Either via env vars (persistent, convenient for a session):

```bash
export LLM_SDK_DIR=/path/to/tensorrt-edge-llm      # auto-uses $LLM_SDK_DIR/build
# or point directly at the build dir:
export BUILD_DIR=/path/to/tensorrt-edge-llm/build
```

Or via explicit CLI flags (per command, overrides env vars):

```bash
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 \
    --build-dir /path/to/tensorrt-edge-llm/build \
    --download-dir /path/to/onnx-cache \
    --engine-dir /path/to/engine-cache
```

### Environment Variables (optional)

| Variable | Description | Default |
|----------|-------------|---------|
| `BUILD_DIR` | Directory containing `llm_build` / `llm_bench` / `llm_inference` | `build` |
| `LLM_SDK_DIR` | Edge-LLM SDK root (uses `$LLM_SDK_DIR/build`) | — |
| `TRT_PACKAGE_DIR` | TensorRT package dir (sets `LD_LIBRARY_PATH`) | — |
| `TRTEXEC_SHAPE_MODE` | Shape mode for visual encoder trtexec benchmark: `min`, `opt`, `max` | `min` |

You can also pass `--build-dir` explicitly on each command.

## Step 0: Automatic Project Download & Build

When you run `edgellm-bench run`, the tool looks for the Edge-LLM SDK at `./TensorRT-Edge-LLM` under the current directory. If the SDK is not found, it clones it from GitHub. If already cloned but not built, it builds. If already built, Step 0 is skipped entirely.

1. **Locates** the SDK: `--repo-dir` > `./TensorRT-Edge-LLM` (default)
2. **Clones** from GitHub if the SDK directory doesn't exist
3. **Checks** for existing executables in `<repo>/build-<arch>/` — skips build if found
4. **Creates a Python venv** at `<repo>/.venv-<arch>` for build dependencies (`nvidia-cutlass-dsl`, `cupy`)
5. **Detects** the build target (`x86`, `jetson-thor`, or `auto-thor`) from the current architecture
6. **Resolves** `TRT_PACKAGE_DIR` from env, scratch workspace, or system paths
7. **Runs** `cmake` + `make` with the venv activated and the correct flags for the detected target

> **Why a venv?** CuTe DSL FMHA kernel compilation requires `nvidia-cutlass-dsl` and `cupy`.
> The venv keeps these build-time dependencies isolated from your system Python.
> The venv is architecture-specific (`<repo>/.venv-x86_64` or `<repo>/.venv-aarch64`)
> so x86 and aarch64 machines can safely share the same NFS workspace.
> Similarly, the build directory is `<repo>/build-x86_64` or `<repo>/build-aarch64`.

### Build profiles (native only)

| Profile | Architecture | TRT candidates | CuTe DSL FMHA |
|---------|-------------|----------------|----------------|
| `x86` | x86_64 | `/usr/lib/x86_64-linux-gnu/` | on |
| `jetson-thor` | aarch64 | `/usr/src/tensorrt`, `/usr/lib/aarch64-linux-gnu/` | off |
| `auto-thor` | aarch64 | `/usr/src/tensorrt`, `/usr/lib/aarch64-linux-gnu/` | on |

### Step 0 CLI flags

```bash
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 \
    --target auto-thor \                 # Force a specific build profile
    --repo-dir /path/to/edge-llm \       # Use existing checkout
    --repo-ref release/0.6.1 \           # Git branch (default)
    --trt-package-dir /path/to/TRT \     # Override TRT detection
    --cmake-build-type Release \         # Debug or Release
    --enable-cute-dsl-fmha on \          # on/off/auto
    --build-jobs 16 \                    # make -j parallelism
    --clean-build \                      # Wipe build/ first
    --skip-project-build \               # Skip Step 0 entirely
    --force-project-build                # Force rebuild even if binaries exist
```

## Commands

```
edgellm-bench list    List available models and precisions from NAS
edgellm-bench run     Download, build, and benchmark (one command)
edgellm-bench infer   Run end-to-end inference on pre-built engines
```

## Usage

### List available models

```bash
edgellm-bench list
edgellm-bench list --json
```

The `list` output uses a compact labeled format grouping available precisions per model:

```
Qwen3-0.6B        llm-{fp16/nvfp4}-lmhead-fp16-draft-{fp16/nvfp4}-audio-fp16
InternVL3-1B      llm-{fp16/nvfp4}-lmhead-fp16-vit-{fp16/fp8}
```

Pick one option from each `{opt1/opt2}` group to form a valid `--precision` string.

### Standard LLM benchmark (download + build + bench)

Runs `llm_bench` for kernel-level **prefill + decode** performance.

```bash
# Using labeled format (from list output)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16
edgellm-bench run --model Qwen3-0.6B --precision llm-nvfp4-lmhead-fp16

# Using standard format (also accepted)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-fp16
edgellm-bench run --model Qwen3-0.6B --precision llm-nvfp4-fp16

# Single mode only
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 --mode decode
```

### VLM benchmark (LLM + visual encoder)

When `--precision` includes a `-vit-<quant>` suffix, the tool automatically downloads and builds both LLM and visual encoder, benchmarks the LLM with `llm_bench`, and benchmarks the visual encoder with `trtexec`:

```bash
# LLM + ViT benchmark
edgellm-bench run --model InternVL3-1B --precision llm-nvfp4-lmhead-fp16-vit-fp16
```

### ASR benchmark (LLM + audio encoder)

When `--precision` includes an `-audio-<quant>` suffix, both LLM and audio encoder are downloaded, built, and benchmarked:

```bash
edgellm-bench run --model Qwen3-ASR-0.6B --precision llm-fp16-lmhead-fp16-audio-fp16
```

### Eagle speculative decoding benchmark

When `--precision` includes `-draft-<quant>`, Eagle mode is activated automatically:
1. Downloads both base and draft ONNX models
2. Builds both engines into a shared directory
3. Runs `llm_inference --eagle` with 100 MT-Bench prompts for end-to-end decode perf

```bash
# Single command — builds both base + draft, then runs eagle inference
edgellm-bench run --model Qwen3-1.7B --precision llm-nvfp4-lmhead-fp16-draft-nvfp4

# Using standard format
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16

# Custom draft precision (default: auto-derived as draft-eagle3-<quant>-<lmhead>)
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --draft-precision draft-eagle3-fp16-fp16

# Control generation length
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --max-generate-length 1024
```

Output includes acceptance rate and tokens/s:
```
Eagle mode: base=llm-base-nvfp4-fp16  draft=draft-eagle3-nvfp4-fp16

eagle_inference (MT-Bench, 100 prompts):
  Warmup: 10  Max Generate Length: 512
  Total Tokens: 51200  Iterations: 12800
  Prefill: 2345.6 tokens/s
  >>> Acceptance Rate: 0.78  |  Decode: 156.3 tokens/s
  Peak Memory: 1234.5 MB
```

### TTS benchmark (multi-component models)

TTS models with multiple sub-components (e.g., `talker/` + `code_predictor/`) are detected automatically. Each component is built and benchmarked independently:

```bash
edgellm-bench run --model Qwen3-TTS-12Hz-0.6B-CustomVoice --precision llm-fp16-lmhead-fp16
```

> **Note:** Multi-component models force `--maxBatchSize=1` for engine build (required by the ONNX export).

### End-to-end inference benchmark (pre-built engines)

Use `infer` when you already have built engines and want to run `llm_inference` directly.

```bash
# Eagle inference
edgellm-bench infer --engine-dir tmp/engines/Qwen3-1.7B/eagle --eagle

# Standard inference
edgellm-bench infer --engine-dir tmp/engines/Qwen3-0.6B/llm-fp16-fp16

# Custom input file instead of built-in MT-Bench prompts
edgellm-bench infer --engine-dir /path/to/engines --eagle --input-file my_prompts.json

# Pass extra flags to llm_inference
edgellm-bench infer --engine-dir /path/to/engines --eagle \
    --extra-infer-args --draftTopK=20 --draftStep=8
```

### Download only

Download ONNX models without building engines or running benchmarks:

```bash
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 --download-only
```

### Benchmark parameters

```bash
# Standard LLM kernel benchmark
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 \
    --iterations 100 \
    --warmup 10 \
    --input-len 1024 \
    --max-seq-len 4096 \
    --max-input-len 2048

# Eagle inference benchmark
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --warmup 3 \
    --max-generate-length 512
```

Note: In Eagle mode, `--iterations`, `--input-len`, and `--mode` are ignored (a warning is printed).
Eagle uses `--warmup` and `--max-generate-length` instead.

### Skip steps

```bash
# Skip download (reuse cached ONNX)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 --skip-download

# Skip download and build (reuse cached engine, benchmark only)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 --skip-download --skip-build
```

### Pass extra args to underlying executables

```bash
# Extra args for llm_build
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 \
    --extra-build-args --maxBatchSize=4

# Extra args for llm_bench (standard mode)
edgellm-bench run --model Qwen3-0.6B --precision llm-fp16-lmhead-fp16 \
    --extra-bench-args --dumpDetailedLayerProfile

# Extra args for llm_inference (Eagle mode)
edgellm-bench run --model Qwen3-1.7B --precision llm-base-nvfp4-fp16 \
    --extra-infer-args --draftTopK=20 --verifyTreeSize=80
```

## Precision String Format

The `--precision` flag supports two formats:

### Labeled format (from `list` output)

Components are explicit with labels. Pick one option from each `{opt1/opt2}` group:

| Pattern | Type | Example |
|---------|------|---------|
| `llm-<quant>-lmhead-<lmhead>` | Standard LLM | `llm-fp16-lmhead-fp16`, `llm-nvfp4-lmhead-fp16` |
| `llm-<quant>-lmhead-<lmhead>-draft-<quant>` | Eagle (base+draft) | `llm-nvfp4-lmhead-fp16-draft-nvfp4` |
| `llm-<quant>-lmhead-<lmhead>-vit-<quant>` | LLM + ViT | `llm-nvfp4-lmhead-fp16-vit-fp16` |
| `llm-<quant>-lmhead-<lmhead>-audio-<quant>` | LLM + Audio | `llm-fp16-lmhead-fp16-audio-fp16` |
| `llm-<quant>-lmhead-<lmhead>-vit-<quant>-audio-<quant>` | LLM + ViT + Audio | Combined |

### Standard format (also accepted)

| Pattern | Type | Example |
|---------|------|---------|
| `llm-<quant>-<lmhead>` | Standard LLM | `llm-fp16-fp16`, `llm-fp8-fp16`, `llm-nvfp4-fp16` |
| `llm-<quant>-<lmhead>-fp8kv` | LLM with FP8 KV cache | `llm-nvfp4-fp16-fp8kv` |
| `llm-<quant>-<lmhead>-rvs<N>` | LLM with reduced vocab | `llm-fp16-fp16-rvs16384` |
| `llm-base-<quant>-<lmhead>` | Eagle base model | `llm-base-fp8-fp16`, `llm-base-nvfp4-fp16` |
| `draft-eagle3-<quant>-<lmhead>` | Eagle draft model | `draft-eagle3-fp16-fp16` |
| `visual-<quant>` | Vision encoder (ViT) | `visual-fp16`, `visual-fp8` |
| `audio-<quant>` | Audio encoder (ASR) | `audio-fp16` |

Supported quantization types: `fp16`, `bf16`, `fp8`, `nvfp4`, `int4_awq`, `mxfp8`, `int8_sq`.

## Auto-detection

The tool automatically detects model type from the precision string and selects the appropriate workflow:

| Precision pattern | Build tool | Benchmark tool | Default mode |
|-------------------|-----------|---------------|--------------|
| `llm-base-*` (Eagle) | `llm_build --eagleBase` | `llm_inference --eagle` | MT-Bench 100 prompts |
| `draft-*` (Eagle draft only) | `llm_build --eagleDraft` | `llm_bench` | `eagle_draft_prefill` |
| `llm-*` (standard) | `llm_build` | `llm_inference` | MT-Bench prompts |
| `*ASR*` / `*-audio-*` | `llm_build` + `audio_build` | `llm_bench` + `trtexec` | `prefill` + `decode` |
| `visual-*` | `visual_build` | `trtexec` | Profile MIN shapes |
| `audio-*` | `audio_build` | `trtexec` | — |

For Eagle base models, the draft precision is auto-derived:
`llm-base-<quant>-<lmhead>` -> `draft-eagle3-<quant>-<lmhead>`

For labeled format, the parsing extracts each component:
`llm-nvfp4-lmhead-fp16-vit-fp16` -> LLM: `llm-nvfp4-fp16` + ViT: `visual-fp16`

## Cache Layout

```
tmp/
  onnx/
    <model>/<precision>/         # Downloaded ONNX files
  engines/
    <model>/<precision>/         # Standard engines + bench logs
    <model>/eagle/               # Eagle engines (base + draft together)
    <model>/visual-<quant>/      # Visual encoder engines
    <model>/audio-<quant>/       # Audio encoder engines
```

The default base directory is `tmp/` relative to the current working directory. Override with `--download-dir` and `--engine-dir`.

## Compatibility Checks

The tool performs pre-flight compatibility checks before building engines:

- **ONNX version mismatch**: Models exported with older `edgellm_version` (e.g., TTS models from 0.5.0) that are known to crash the current runtime (SIGFPE in TRT compiler) are rejected with a clear error message instead of silent coredumps.
- **Engine truncation**: After build, verifies engine file size matches what TRT reported, catching scratch filesystem I/O errors.
- **NAS validation**: Before downloading, checks that the requested model/precision combination exists on NAS and shows valid alternatives if not.

## Project Structure

```
edgellm_bench/
  __main__.py          CLI entry point (list, run, infer subcommands)
  config.py            Default parameters, path resolution, TRT lib detection
  nas_client.py        NAS server client (list + download ONNX models)
  engine_builder.py    Wraps llm_build / visual_build / audio_build for TRT engine building
  benchmark_runner.py  Wraps llm_bench and trtexec for kernel-level benchmarks
  inference_runner.py  Wraps llm_inference for end-to-end inference (Eagle, standard, multimodal)
  project_builder.py   Project clone + cmake/make with auto venv and venv activation
  utils.py             Shared utilities (executable finder, env setup, precision helpers)
```
