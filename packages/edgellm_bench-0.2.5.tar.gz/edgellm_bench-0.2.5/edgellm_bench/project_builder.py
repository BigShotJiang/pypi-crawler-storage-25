"""Project downloader and builder — clones the repo and runs cmake + make."""

import glob
import os
import platform
import shutil
import subprocess
import sys
import venv

from .config import (
    DEFAULT_REPO_REF,
    DEFAULT_REPO_REMOTE,
)


# ---------------------------------------------------------------------------
# Build profiles — native only (no cross-compilation)
# ---------------------------------------------------------------------------

BUILD_PROFILES = {
    "x86": {
        "description": "x86_64 GPU workstation (native)",
        "trt_package_dir_candidates": [
            "/usr/lib/x86_64-linux-gnu/",
        ],
        "build_type": "Release",
        "enable_cute_dsl_fmha": False,
        "build_unit_tests": False,
        "extra_cmake_args": [],
    },
    "jetson-thor": {
        "description": "Jetson Thor / DRIVE Thor (native aarch64)",
        "trt_package_dir_candidates": [
            "/usr/src/tensorrt",
            "/usr/lib/aarch64-linux-gnu/",
        ],
        "build_type": "Release",
        "enable_cute_dsl_fmha": False,
        "build_unit_tests": False,
        "extra_cmake_args": [
            "-DAARCH64_BUILD=TRUE",
            "-DCMAKE_CUDA_ARCHITECTURES=110",
        ],
    },
    "auto-thor": {
        "description": "DRIVE Thor (native aarch64)",
        "trt_package_dir_candidates": [
            "/usr/src/tensorrt",
            "/usr/lib/aarch64-linux-gnu/",
        ],
        "build_type": "Release",
        "enable_cute_dsl_fmha": False,
        "build_unit_tests": False,
        "extra_cmake_args": [
            "-DAARCH64_BUILD=TRUE",
            "-DCMAKE_CUDA_ARCHITECTURES=110",
        ],
    },
}


def detect_build_profile():
    """Auto-detect which build profile to use based on the current machine.

    Returns the profile name string.  Raises RuntimeError if ambiguous.
    """
    arch = platform.machine()
    if arch == "x86_64":
        return "x86"
    elif arch == "aarch64":
        # On aarch64 default to auto-thor (has CuTe DSL FMHA enabled)
        return "jetson-thor"
    else:
        raise RuntimeError(
            f"Unknown architecture '{arch}'. Please specify --target explicitly."
        )


def resolve_trt_package_dir(profile_name, explicit_trt_dir=None):
    """Resolve TRT_PACKAGE_DIR from explicit value, env, or profile candidates.

    Priority:
      1. explicit_trt_dir (--trt-package-dir CLI flag)
      2. $TRT_PACKAGE_DIR env var
      3. Profile candidate list (first existing on disk)
      4. Glob /home/scratch.ruochengj_sw/thor_workspace/TensorRT-*
         (only for aarch64 profiles — these are Thor TRT packages)
    """
    # 1. Explicit flag
    if explicit_trt_dir:
        if os.path.isdir(explicit_trt_dir):
            return explicit_trt_dir
        raise FileNotFoundError(f"TRT_PACKAGE_DIR not found: {explicit_trt_dir}")

    # 2. Env var
    env_trt = os.environ.get("TRT_PACKAGE_DIR")
    if env_trt and os.path.isdir(env_trt):
        return env_trt

    # 3. Profile candidates (architecture-appropriate)
    profile = BUILD_PROFILES.get(profile_name, {})
    for candidate in profile.get("trt_package_dir_candidates", []):
        if os.path.isdir(candidate):
            return candidate

    # 4. Scratch workspace glob — only for aarch64 profiles (Thor TRT packages)
    is_aarch64_profile = profile_name in ("jetson-thor", "auto-thor")
    scratch_trt = []
    if is_aarch64_profile:
        scratch_trt = sorted(
            glob.glob("/home/scratch.ruochengj_sw/thor_workspace/TensorRT-*"),
            reverse=True,
        )
        for d in scratch_trt:
            if os.path.isdir(d):
                return d

    tried = list(profile.get("trt_package_dir_candidates", [])) + scratch_trt
    raise FileNotFoundError(
        f"Cannot find TRT_PACKAGE_DIR for profile '{profile_name}'. Tried: {tried}\n"
        "Set --trt-package-dir or $TRT_PACKAGE_DIR."
    )


# ---------------------------------------------------------------------------
# Git clone / update
# ---------------------------------------------------------------------------

def _mark_safe_directory(repo_dir):
    """Add repo_dir to git safe.directory to avoid 'dubious ownership' errors.

    NFS-mounted scratch spaces typically have a different owner than the
    running user, which causes git >= 2.35.2 to refuse operations.
    """
    try:
        # Check if already marked safe
        result = subprocess.run(
            ["git", "config", "--global", "--get-all", "safe.directory"],
            capture_output=True, text=True, timeout=5,
        )
        if repo_dir in result.stdout.splitlines():
            return  # already safe
    except Exception:
        pass

    try:
        subprocess.run(
            ["git", "config", "--global", "--add", "safe.directory", repo_dir],
            capture_output=True, timeout=5,
        )
    except Exception:
        pass  # best-effort; git will report the real error if this fails


def _mark_submodules_safe(repo_dir):
    """Mark all submodule paths inside repo_dir as git safe.directory.

    Parses .gitmodules to find submodule paths, then marks each as safe.
    """
    gitmodules = os.path.join(repo_dir, ".gitmodules")
    if not os.path.isfile(gitmodules):
        return
    try:
        with open(gitmodules) as f:
            for line in f:
                line = line.strip()
                if line.startswith("path"):
                    _, _, subpath = line.partition("=")
                    subpath = subpath.strip()
                    if subpath:
                        full = os.path.join(repo_dir, subpath)
                        _mark_safe_directory(full)
    except Exception:
        pass  # best-effort


def _cleanup_corrupted_submodules(repo_dir):
    """Remove partially-cloned submodule state that blocks re-initialization.

    When a submodule clone is interrupted, .git/modules/<submod> may contain
    only config/hooks but no HEAD/objects/refs.  Git then refuses to re-clone
    with "not a git repository".  We detect and remove these broken dirs.
    """
    modules_dir = os.path.join(repo_dir, ".git", "modules")
    if not os.path.isdir(modules_dir):
        return

    gitmodules = os.path.join(repo_dir, ".gitmodules")
    if not os.path.isfile(gitmodules):
        return

    subpaths = []
    try:
        with open(gitmodules) as f:
            for line in f:
                line = line.strip()
                if line.startswith("path"):
                    _, _, subpath = line.partition("=")
                    subpath = subpath.strip()
                    if subpath:
                        subpaths.append(subpath)
    except Exception:
        return

    for subpath in subpaths:
        mod_dir = os.path.join(modules_dir, subpath)
        if not os.path.isdir(mod_dir):
            continue
        head_file = os.path.join(mod_dir, "HEAD")
        if not os.path.isfile(head_file):
            # Corrupted: has module dir but no HEAD
            print(f"  Cleaning corrupted submodule state: {subpath}")
            try:
                shutil.rmtree(mod_dir)
                # Also remove the working tree so git will re-clone
                wt = os.path.join(repo_dir, subpath)
                if os.path.isdir(wt):
                    shutil.rmtree(wt)
            except OSError as e:
                print(f"  Warning: Could not clean {subpath}: {e}")


def _restore_working_tree(repo_dir):
    """Restore working tree files if a previous clone was interrupted.

    When git clone is interrupted by dubious-ownership errors after objects
    are fetched but before checkout completes, the working tree may be
    mostly empty while the index is intact.  Detect this by checking if
    key files (CMakeLists.txt) are missing and run 'git checkout .' to
    restore everything.
    """
    marker = os.path.join(repo_dir, "CMakeLists.txt")
    if os.path.isfile(marker):
        return  # working tree looks intact

    # Check if git thinks files are deleted
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=repo_dir, capture_output=True, text=True, timeout=30,
    )
    deleted_count = sum(1 for line in result.stdout.splitlines() if line.startswith(" D"))
    if deleted_count > 0:
        print(f"  Restoring {deleted_count} files from interrupted checkout ...")
        subprocess.check_call(
            ["git", "checkout", "."],
            cwd=repo_dir,
        )


def ensure_project(
    repo_dir,
    ref=None,
    remote=None,
    pull=False,
):
    """Ensure the Edge-LLM repo exists at repo_dir with submodules initialized.

    Args:
        repo_dir: Path where the repo should live.
        ref: Git branch/tag/sha to checkout. Default: DEFAULT_REPO_REF.
        remote: Git remote URL. Default: DEFAULT_REPO_REMOTE.
        pull: If True and repo already exists, run git pull.

    Returns:
        The absolute path to repo_dir.
    """
    ref = ref or DEFAULT_REPO_REF
    remote = remote or DEFAULT_REPO_REMOTE
    repo_dir = os.path.abspath(repo_dir)

    # NFS scratch spaces often have different ownership than the current user.
    # Mark the repo (and its submodules) as safe to avoid git's "dubious
    # ownership" error.
    _mark_safe_directory(repo_dir)

    if os.path.isdir(os.path.join(repo_dir, ".git")):
        print(f"  Repo already exists at {repo_dir}")

        # Restore working tree if a previous clone/checkout was interrupted
        # by dubious-ownership errors (files show as "deleted" in git status).
        _restore_working_tree(repo_dir)

        if pull:
            print(f"  Pulling latest from {ref} ...")
            subprocess.check_call(
                ["git", "pull", "origin", ref],
                cwd=repo_dir,
            )
        # Make sure we're on the right branch
        _current_ref = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=repo_dir,
            text=True,
        ).strip()
        if _current_ref != ref:
            print(f"  Switching from {_current_ref} to {ref} ...")
            subprocess.check_call(
                ["git", "fetch", "origin", ref],
                cwd=repo_dir,
            )
            subprocess.check_call(
                ["git", "checkout", ref],
                cwd=repo_dir,
            )
    else:
        print(f"  Cloning {remote} -> {repo_dir} (branch: {ref}) ...")
        os.makedirs(os.path.dirname(repo_dir), exist_ok=True)
        subprocess.check_call(
            ["git", "clone", "--branch", ref, "--single-branch", remote, repo_dir],
        )

    # Mark all submodule paths as safe before initializing them
    _mark_submodules_safe(repo_dir)

    # Clean up corrupted submodules before attempting init.
    # A partial clone leaves .git/modules/<path> with only config/hooks
    # but no HEAD — git then refuses to re-clone ("not a git repository").
    _cleanup_corrupted_submodules(repo_dir)

    # Always ensure submodules are initialized
    print("  Initializing submodules ...")
    subprocess.check_call(
        ["git", "submodule", "update", "--init", "--recursive"],
        cwd=repo_dir,
    )

    return repo_dir


# ---------------------------------------------------------------------------
# CMake configure + build
# ---------------------------------------------------------------------------

def _read_cmake_cache_var(build_dir, var_name):
    """Read a variable from CMakeCache.txt. Returns None if not found."""
    cache_path = os.path.join(build_dir, "CMakeCache.txt")
    if not os.path.isfile(cache_path):
        return None
    prefix = f"{var_name}:"
    with open(cache_path) as f:
        for line in f:
            if line.startswith(prefix):
                _, _, value = line.partition("=")
                return value.strip()
    return None


def _cmake_define_value(cmake_args, var_name):
    """Return the last -D value for var_name from a list of cmake args."""
    value = None
    for arg in cmake_args or []:
        if not arg.startswith("-D"):
            continue
        define, sep, define_value = arg[2:].partition("=")
        if not sep:
            continue
        define_name = define.split(":", 1)[0]
        if define_name == var_name:
            value = define_value
    return value


def _cmake_cache_matches(
    build_dir,
    profile_name,
    trt_package_dir,
    enable_cute_dsl,
    intended_cmake_args=None,
):
    """Check if existing CMakeCache.txt matches the intended build config.

    Returns False if cmake configure didn't complete properly or if
    key variables don't match.
    """
    # If essential cmake variables are NOTFOUND, configure was broken
    for var in ("CUDART_LIB", "CUDA_RUNTIME_API_INCLUDE_DIR"):
        val = _read_cmake_cache_var(build_dir, var)
        if val and "NOTFOUND" in val:
            return False

    cached_trt = _read_cmake_cache_var(build_dir, "TRT_PACKAGE_DIR")
    if cached_trt and os.path.normpath(cached_trt) != os.path.normpath(trt_package_dir):
        return False

    cached_fmha = _read_cmake_cache_var(build_dir, "ENABLE_CUTE_DSL_FMHA")
    want_fmha = "ON" if enable_cute_dsl else "OFF"
    if cached_fmha and cached_fmha.upper() != want_fmha:
        return False

    expected_arch = _cmake_define_value(
        intended_cmake_args,
        "CMAKE_CUDA_ARCHITECTURES",
    )
    if expected_arch:
        cached_arch = _read_cmake_cache_var(build_dir, "CMAKE_CUDA_ARCHITECTURES")
        if cached_arch != expected_arch:
            return False

    return True


def _check_cutlass_dsl_available(python=None):
    """Check if nvidia-cutlass-dsl is importable (needed for ENABLE_CUTE_DSL_FMHA).

    Args:
        python: Path to Python interpreter to check. Defaults to sys.executable.
    """
    python = python or sys.executable
    try:
        result = subprocess.run(
            [python, "-c", "import cutlass.dsl"],
            capture_output=True, timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Virtual environment management
# ---------------------------------------------------------------------------

def _ensure_venv(repo_dir):
    """Create a Python venv at <repo_dir>/.venv-<arch> if it doesn't already exist.

    The venv is architecture-specific (e.g. `.venv-x86_64`, `.venv-aarch64`)
    because the repo may live on a shared NFS filesystem accessed from both
    x86 and aarch64 machines.  Python packages with native extensions
    (nvidia-cutlass-dsl, cupy) are not cross-compatible.

    Returns:
        The absolute path to the venv directory.
    """
    arch = platform.machine()  # e.g. "x86_64", "aarch64"
    venv_dir = os.path.join(repo_dir, f".venv-{arch}")
    venv_python = os.path.join(venv_dir, "bin", "python")

    if os.path.isfile(venv_python):
        print(f"  Using existing venv: {venv_dir}")
        return venv_dir

    print(f"  Creating venv: {venv_dir} ...")
    venv.create(venv_dir, with_pip=True, system_site_packages=True)

    # Upgrade pip in the venv (best-effort)
    try:
        subprocess.run(
            [venv_python, "-m", "pip", "install", "--upgrade", "pip"],
            capture_output=True, timeout=60,
        )
    except Exception:
        pass

    # Install edgellm-bench into the venv so the CLI is available from within it
    edgellm_bench_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    try:
        subprocess.run(
            [venv_python, "-m", "pip", "install", "-e", edgellm_bench_dir],
            capture_output=True, timeout=120,
        )
    except Exception:
        pass

    return venv_dir


def _get_venv_env(venv_dir):
    """Return an env dict with the venv activated and CUDA paths set.

    Sets VIRTUAL_ENV and prepends venv bin/ to PATH so that
    cmake's find_package(Python3) picks up the venv Python.
    Also ensures CUDA toolkit paths are in PATH / LD_LIBRARY_PATH
    (needed on machines where nvcc is not in the default PATH).
    """
    env = os.environ.copy()
    venv_bin = os.path.join(venv_dir, "bin")
    env["VIRTUAL_ENV"] = venv_dir
    env["PATH"] = venv_bin + os.pathsep + env.get("PATH", "")
    # Remove PYTHONHOME if set — it conflicts with venv activation
    env.pop("PYTHONHOME", None)

    # Ensure CUDA toolkit is discoverable by cmake.
    # Check standard locations: /usr/local/cuda/bin, /usr/local/cuda-*/bin
    cuda_home = env.get("CUDA_HOME") or env.get("CUDA_PATH")
    if not cuda_home:
        for candidate in ("/usr/local/cuda",):
            if os.path.isfile(os.path.join(candidate, "bin", "nvcc")):
                cuda_home = candidate
                break
    if cuda_home:
        cuda_bin = os.path.join(cuda_home, "bin")
        cuda_lib = os.path.join(cuda_home, "lib64")
        if cuda_bin not in env.get("PATH", ""):
            env["PATH"] = cuda_bin + os.pathsep + env["PATH"]
        if os.path.isdir(cuda_lib) and cuda_lib not in env.get("LD_LIBRARY_PATH", ""):
            env["LD_LIBRARY_PATH"] = cuda_lib + os.pathsep + env.get("LD_LIBRARY_PATH", "")

    return env


def _detect_cuda_version():
    """Detect the CUDA toolkit version from nvcc --version.

    Returns a version string like '13.0' or '12.8', or None if detection fails.
    """
    try:
        result = subprocess.run(
            ["nvcc", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            # Parse: "Cuda compilation tools, release 13.0, V13.0.76"
            for line in result.stdout.splitlines():
                if "release" in line.lower():
                    # Extract version after "release "
                    import re
                    match = re.search(r"release\s+(\d+\.\d+)", line)
                    if match:
                        return match.group(1)
    except Exception:
        pass
    return None


def build_project(
    repo_dir,
    profile_name,
    build_dir=None,
    trt_package_dir=None,
    build_type=None,
    enable_cute_dsl_fmha=None,
    jobs=None,
    clean=False,
    extra_cmake_args=None,
):
    """Run cmake + make for the Edge-LLM C++ runtime.

    Args:
        repo_dir: Root of the Edge-LLM repo.
        profile_name: One of BUILD_PROFILES keys.
        build_dir: Where to build (default: repo_dir/build).
        trt_package_dir: Resolved TRT path (if None, auto-resolved from profile).
        build_type: Debug or Release (default from profile).
        enable_cute_dsl_fmha: Override profile's FMHA setting.
        jobs: Parallelism for make -j (default: os.cpu_count()).
        clean: If True, wipe build dir first.
        extra_cmake_args: Additional cmake args.

    Returns:
        dict with 'success', 'build_dir', 'error' keys.
    """
    profile = BUILD_PROFILES.get(profile_name)
    if not profile:
        return {
            "success": False,
            "build_dir": None,
            "error": f"Unknown profile '{profile_name}'. Available: {list(BUILD_PROFILES.keys())}",
        }

    repo_dir = os.path.abspath(repo_dir)
    if build_dir is None:
        build_dir = os.path.join(repo_dir, "build")
    build_dir = os.path.abspath(build_dir)

    if trt_package_dir is None:
        trt_package_dir = resolve_trt_package_dir(profile_name)
    trt_package_dir = os.path.abspath(trt_package_dir)

    if build_type is None:
        build_type = profile["build_type"]

    if enable_cute_dsl_fmha is None:
        enable_cute_dsl_fmha = profile["enable_cute_dsl_fmha"]

    # Set up venv for build dependencies (nvidia-cutlass-dsl, cupy)
    venv_dir = _ensure_venv(repo_dir)
    build_env = _get_venv_env(venv_dir)
    venv_python = os.path.join(venv_dir, "bin", "python")

    # If cute DSL requested, verify the package is available (check in venv)
    if enable_cute_dsl_fmha:
        if not _check_cutlass_dsl_available(python=venv_python):
            print("  Note: nvidia-cutlass-dsl not yet in venv; cmake will install it")

    if jobs is None:
        jobs = os.cpu_count() or 4

    profile_cmake_args = list(profile.get("extra_cmake_args", []))
    user_cmake_args = list(extra_cmake_args or [])
    intended_cmake_args = profile_cmake_args + user_cmake_args

    # Clean if requested
    if clean and os.path.isdir(build_dir):
        print(f"  Cleaning build directory: {build_dir}")
        shutil.rmtree(build_dir)

    os.makedirs(build_dir, exist_ok=True)

    # Check if existing CMake cache matches
    needs_configure = True
    if os.path.isfile(os.path.join(build_dir, "CMakeCache.txt")):
        if _cmake_cache_matches(
            build_dir,
            profile_name,
            trt_package_dir,
            enable_cute_dsl_fmha,
            intended_cmake_args,
        ):
            print("  CMake cache matches current config, skipping configure")
            needs_configure = False
        else:
            print("  CMake cache mismatch detected, reconfiguring ...")
            # Remove stale cache
            for f in ("CMakeCache.txt",):
                p = os.path.join(build_dir, f)
                if os.path.isfile(p):
                    os.remove(p)
            cmake_files = os.path.join(build_dir, "CMakeFiles")
            if os.path.isdir(cmake_files):
                shutil.rmtree(cmake_files)

    # CMake configure
    if needs_configure:
        cmake_cmd = [
            "cmake", repo_dir,
            f"-DTRT_PACKAGE_DIR={trt_package_dir}",
            f"-DCMAKE_BUILD_TYPE={build_type}",
        ]

        # Resolve CUDA_DIR: the project defaults to /usr/local/cuda-12.8 which
        # may not exist (e.g. Thor has CUDA 13.0).  Point to /usr/local/cuda
        # (symlink) if it exists and no explicit CUDA_DIR was passed.
        cuda_dir_set = any(a.startswith("-DCUDA_DIR") for a in (extra_cmake_args or []))
        if not cuda_dir_set:
            cuda_symlink = "/usr/local/cuda"
            if os.path.isdir(cuda_symlink):
                cmake_cmd.append(f"-DCUDA_DIR={cuda_symlink}")

        # Detect actual CUDA toolkit version and pass it to cmake.
        # The CMakeLists.txt defaults CUDA_CTK_VERSION to 12.8, which causes
        # cupy-cuda12x to be installed on CUDA 13 systems.
        ctk_version_set = any(a.startswith("-DCUDA_CTK_VERSION") for a in (extra_cmake_args or []))
        if not ctk_version_set:
            detected_ctk = _detect_cuda_version()
            if detected_ctk:
                cmake_cmd.append(f"-DCUDA_CTK_VERSION={detected_ctk}")

        if enable_cute_dsl_fmha:
            cmake_cmd.append("-DENABLE_CUTE_DSL_FMHA=on")

        cmake_cmd.extend(intended_cmake_args)

        print(f"  CMake configure:")
        print(f"    cd {build_dir}")
        print(f"    {' '.join(cmake_cmd)}")

        try:
            result = subprocess.run(
                cmake_cmd,
                cwd=build_dir,
                capture_output=True,
                text=True,
                timeout=120,
                env=build_env,
            )
            if result.returncode != 0:
                sys.stderr.write(result.stderr)
                return {
                    "success": False,
                    "build_dir": build_dir,
                    "error": f"cmake configure failed (exit {result.returncode}): {result.stderr[-500:]}",
                }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "build_dir": build_dir,
                "error": "cmake configure timed out (120s)",
            }

    # Make
    make_cmd = ["make", f"-j{jobs}"]
    print(f"  Building with: {' '.join(make_cmd)}")

    try:
        proc = subprocess.Popen(
            make_cmd,
            cwd=build_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=build_env,
        )
        log_path = os.path.join(build_dir, "project_build.log")
        output_lines = []
        with open(log_path, "w") as log_file:
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
                # Print progress hints (percentage lines from make)
                stripped = line.strip()
                if stripped.startswith("[") and "%" in stripped[:10]:
                    sys.stdout.write(f"\r  {stripped[:80]}")
                    sys.stdout.flush()
        proc.wait(timeout=1800)  # 30 min timeout for large builds

        if output_lines:
            sys.stdout.write("\n")  # newline after progress

        if proc.returncode != 0:
            sys.stderr.write(f"Build FAILED (exit {proc.returncode}). Last lines of {log_path}:\n")
            for line in output_lines[-20:]:
                sys.stderr.write(f"  {line}")
            return {
                "success": False,
                "build_dir": build_dir,
                "error": f"make failed with exit code {proc.returncode}",
            }
    except subprocess.TimeoutExpired:
        proc.kill()
        return {
            "success": False,
            "build_dir": build_dir,
            "error": "make timed out (1800s)",
        }

    # Verify key executables exist
    required_executables = ["llm_build", "llm_inference"]
    for exe_name in required_executables:
        found = False
        for subdir in ("examples/llm", "examples/multimodal", ""):
            path = os.path.join(build_dir, subdir, exe_name)
            if os.path.isfile(path) and os.access(path, os.X_OK):
                found = True
                break
        if not found:
            return {
                "success": False,
                "build_dir": build_dir,
                "error": f"Build succeeded but '{exe_name}' not found in {build_dir}",
            }

    print(f"  Project build complete: {build_dir}")
    return {
        "success": True,
        "build_dir": build_dir,
        "error": None,
    }


_ELF_MACHINE = {
    "x86_64": b"\x3e\x00",     # EM_X86_64 = 0x3E
    "aarch64": b"\xb7\x00",    # EM_AARCH64 = 0xB7
}


def _is_native_elf(path):
    """Check if an ELF binary matches the current architecture.

    Reads the e_machine field (bytes 18-19) from the ELF header and
    compares to the expected value for platform.machine().
    On non-Linux or unrecognised arches, returns True (optimistic).
    """
    expected = _ELF_MACHINE.get(platform.machine())
    if expected is None:
        return True  # unknown arch — skip check
    try:
        with open(path, "rb") as f:
            magic = f.read(4)
            if magic != b"\x7fELF":
                return False
            f.seek(18)
            e_machine = f.read(2)
            return e_machine == expected
    except OSError:
        return False


def has_required_executables(build_dir):
    """Check if the build directory contains the required native executables.

    Verifies both existence and ELF architecture match, so x86 binaries
    on a shared NFS filesystem won't fool an aarch64 machine (and vice versa).
    """
    if not build_dir or not os.path.isdir(build_dir):
        return False
    for exe_name in ("llm_build", "llm_inference"):
        found = False
        for subdir in ("examples/llm", "examples/multimodal", ""):
            path = os.path.join(build_dir, subdir, exe_name)
            if os.path.isfile(path) and os.access(path, os.X_OK) and _is_native_elf(path):
                found = True
                break
        if not found:
            return False
    return True
