"""Benchmark runner — wraps the llm_bench and trtexec executables."""

import os
import re
import shutil
import subprocess
import sys

from .config import get_build_dir, get_trt_package_dir
from .utils import (
    find_executable,
    get_subprocess_env,
    has_eagle_engines,
    is_audio_precision,
    is_eagle_base,
    is_eagle_draft,
    is_visual_precision,
)


def _parse_benchmark_output(output: str) -> dict:
    """Parse benchmark output for performance metrics.

    Parses from the "Bench Config" and "Results" sections to get the actual
    bench parameters (not the engine's max capabilities).
    """
    metrics = {}

    # Parse from "Results:" section at end of output
    results_match = re.search(r"Results:(.+)", output, re.DOTALL)
    results_section = results_match.group(1) if results_match else output

    avg_match = re.search(r"Avg Time:\s*([\d.]+)\s*ms", results_section)
    if avg_match:
        metrics["avg_time_ms"] = float(avg_match.group(1))

    mode_match = re.search(r"Mode:\s*(\w+)", results_section)
    if mode_match:
        metrics["mode"] = mode_match.group(1)

    # Parse from "Bench Config:" section for actual bench parameters
    bench_section_match = re.search(r"Bench Config:(.+?)(?:Mode [A-Z]|Running Benchmark)", output, re.DOTALL)
    bench_section = bench_section_match.group(1) if bench_section_match else output

    for pattern, key in [
        (r"Batch Size:\s*(\d+)", "batch_size"),
        (r"Iterations:\s*(\d+)", "iterations"),
        (r"Input Len:\s*(\d+)", "input_len"),
        (r"Verify Tree Size:\s*(\d+)", "verify_tree_size"),
        (r"Draft Tree Size:\s*(\d+)", "draft_tree_size"),
    ]:
        match = re.search(pattern, bench_section)
        if match:
            metrics[key] = int(match.group(1))

    # Compute throughput in Python based on mode and parsed parameters
    mode = metrics.get("mode", "")
    avg_ms = metrics.get("avg_time_ms", 0)
    batch_size = metrics.get("batch_size", 1)
    if avg_ms > 0:
        if mode in ("prefill", "eagle_draft_prefill"):
            tokens_per_iter = metrics.get("input_len", 0) * batch_size
        elif mode == "decode":
            tokens_per_iter = 1 * batch_size
        elif mode == "eagle_verify":
            tokens_per_iter = metrics.get("verify_tree_size", 0) * batch_size
        elif mode == "eagle_draft_proposal":
            tokens_per_iter = metrics.get("draft_tree_size", 0) * batch_size
        else:
            tokens_per_iter = 0
        if tokens_per_iter > 0:
            metrics["throughput_tokens_per_sec"] = tokens_per_iter * 1000.0 / avg_ms

    return metrics


def _parse_engine_config(output: str) -> dict:
    """Extract engine config from llm_bench output."""
    config = {}
    section = re.search(r"Base Engine Config:(.+?)Bench Config:", output, re.DOTALL)
    if not section:
        return config
    text = section.group(1)
    for pattern, key in [
        (r"Layers:\s*(\d+)", "layers"),
        (r"KV Heads:\s*(\d+)", "kv_heads"),
        (r"Head Dim:\s*(\d+)", "head_dim"),
        (r"Hidden Size:\s*(\d+)", "hidden_size"),
        (r"Vocab Size:\s*(\d+)", "vocab_size"),
        (r"Max Supported Batch Size:\s*(\d+)", "max_batch_size"),
        (r"Max Supported Input Length:\s*(\d+)", "max_input_len"),
        (r"Max KV Cache Capacity:\s*(\d+)", "max_kv_cache"),
        (r"Eagle Enable:\s*(\w+)", "eagle_enable"),
    ]:
        match = re.search(pattern, text)
        if match:
            val = match.group(1)
            config[key] = val if key == "eagle_enable" else int(val)
    return config


def _default_modes_for_precision(precision: str) -> list[str]:
    """Return the default benchmark modes for a given precision string.

    Eagle base  -> ['eagle_verify']
    Eagle draft -> ['eagle_draft_prefill']
    Standard    -> ['prefill', 'decode']
    """
    if not precision:
        return ["prefill", "decode"]
    if is_eagle_base(precision):
        return ["eagle_verify"]
    if is_eagle_draft(precision):
        return ["eagle_draft_prefill"]
    return ["prefill", "decode"]


def _run_single_benchmark(
    llm_bench: str,
    engine_dir: str,
    batch_size: int,
    warmup: int,
    iterations: int,
    mode: str,
    input_len: int | None,
    extra_args: list | None,
    build_dir: str | None = None,
) -> dict:
    """Run a single benchmark invocation for one mode."""
    cmd = [
        llm_bench,
        f"--engineDir={engine_dir}",
        f"--batchSize={batch_size}",
        f"--warmup={warmup}",
        f"--iterations={iterations}",
        f"--mode={mode}",
    ]

    # Add required tree size args for eagle modes
    if mode == "eagle_verify":
        cmd.append("--verifyTreeSize=60")
    elif mode in ("eagle_draft_proposal", "eagle_draft_prefill"):
        cmd.append("--draftTreeSize=10")
    if input_len is not None:
        cmd.append(f"--inputLen={input_len}")
    if extra_args:
        cmd.extend(extra_args)

    log_path = os.path.join(engine_dir, f"bench_{mode}.log")

    try:
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(build_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=600)
        output = "".join(output_lines)
        if proc.returncode != 0:
            # Print last 20 lines to terminal on failure
            print(f"  FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"    {line}")
            return {
                "success": False,
                "output": output,
                "error": f"llm_bench exited with code {proc.returncode}",
                "metrics": {},
                "engine_config": {},
                "log_path": log_path,
                "cmd": " ".join(cmd),
            }
        metrics = _parse_benchmark_output(output)
        engine_config = _parse_engine_config(output)
        return {
            "success": True,
            "output": output,
            "error": None,
            "metrics": metrics,
            "engine_config": engine_config,
            "log_path": log_path,
            "cmd": " ".join(cmd),
        }
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"success": False, "output": "", "error": "Benchmark timed out (600s)",
                "metrics": {}, "engine_config": {}, "log_path": log_path, "cmd": " ".join(cmd)}
    except Exception as e:
        return {"success": False, "output": "", "error": str(e),
                "metrics": {}, "engine_config": {}, "log_path": log_path, "cmd": " ".join(cmd)}


def _find_engine_files(engine_dir: str) -> list[str]:
    """Find all .engine files under engine_dir (including subdirectories)."""
    engine_files = []
    for root, _dirs, files in os.walk(engine_dir):
        for f in files:
            if f.endswith(".engine"):
                engine_files.append(os.path.join(root, f))
    return sorted(engine_files)


def _parse_trtexec_output(output: str) -> dict:
    """Parse trtexec output for performance metrics and I/O shapes."""
    metrics = {}

    # trtexec reports: mean = X ms, ...
    # Look for the "GPU Compute Time" or "Latency" summary
    for pattern, key in [
        (r"mean\s*=\s*([\d.]+)\s*ms", "avg_time_ms"),
        (r"min\s*=\s*([\d.]+)\s*ms", "min_time_ms"),
        (r"max\s*=\s*([\d.]+)\s*ms", "max_time_ms"),
        (r"median\s*=\s*([\d.]+)\s*ms", "median_time_ms"),
        (r"Throughput:\s*([\d.]+)\s*qps", "throughput_qps"),
    ]:
        match = re.search(pattern, output)
        if match:
            metrics[key] = float(match.group(1))

    # Parse input/output tensor shapes from trtexec binding info
    # e.g. "Input binding for input with dimensions 1x3x448x448 is created."
    # e.g. "Output binding for output with dimensions 256x896 is created."
    in_match = re.search(r"Input binding for \S+ with dimensions (\S+)", output)
    if in_match:
        metrics["input_shape"] = in_match.group(1)
    out_match = re.search(r"Output binding for \S+ with dimensions (\S+)", output)
    if out_match:
        metrics["output_shape"] = out_match.group(1)

    return metrics


# Visual encoder profile shape computation.
#
# The engine's optimization profile is set by
#   cpp/builder/visualBuilder.cpp :: setupQwenViTProfile()
# driven by these build-time knobs, which edgellm-bench fixes when calling
# visual_build (see engine_builder.py::build_engine):
#
#   minImageTokens          = 256     (edgellm-bench fixed)
#   maxImageTokens          = 1024    (visual_build default)
#   maxImageTokensPerImage  = 512     (visual_build default)
#
# All dynamic-input profile points derive from these three constants via the
# closed-form formulas below. We mirror them here so _run_trtexec_benchmark
# can inject the correct --shapes for MIN, OPT or MAX without needing the
# tensorrt Python runtime.
#
# Shape mode is selected at bench time via TRTEXEC_SHAPE_MODE env var:
#   "min" (default) -> use profile MIN (smallest legal image -> HW=1024 for
#                      Qwen2.5-VL, matches the common 1024-ISL bench setting)
#   "opt"           -> use profile OPT (what the kernel selector tuned for)
#   "max"           -> use profile MAX (worst-case image)
#
# The input feature dims (1176 for `input`, 40 for `rotary_pos_emb`) are
# architectural constants of every released Qwen2/2.5/3-VL checkpoint:
#   input feature dim = 2 * patch_size^2 * channels = 2*14*14*3 = 1176
#   rope embed size   = 40 (2x head_dim_per_rope_dim)
# They are read from the ONNX graph at build time but are fixed for this
# model family, so we hardcode them.
_VIT_BUILD_CONFIG = {
    "min_image_tokens": 256,
    "max_image_tokens": 1024,
    "max_image_tokens_per_image": 512,
    "input_dim": 1176,
    "rope_embed_size": 40,
}


def _vit_profile_points() -> dict:
    """Return MIN/OPT/MAX values of every dim used by setupQwenViTProfile()."""
    cfg = _VIT_BUILD_CONFIG
    min_tok, max_tok = cfg["min_image_tokens"], cfg["max_image_tokens"]
    max_tok_per = cfg["max_image_tokens_per_image"]
    min_hw = min_tok * 4
    opt_hw = (min_tok + max_tok) // 2 * 4
    max_hw = max_tok * 4
    max_num_images = max(1, max_tok // min_tok)
    max_seq_len = max_tok_per * 4
    return {
        "hw":              {"min": min_hw,           "opt": opt_hw,           "max": max_hw},
        "cu_seqlens":      {"min": 2,                "opt": max_num_images + 1, "max": max_num_images + 1},
        "max_seqlen_car":  {"min": 1,                "opt": max_seq_len // 2, "max": max_seq_len},
        "cu_window_seq":   {"min": 2,                "opt": max_tok,          "max": max_tok},
        "window_idx":      {"min": min_hw // 4,      "opt": opt_hw // 4,      "max": max_hw // 4},
        "input_dim":       cfg["input_dim"],
        "rope_embed_size": cfg["rope_embed_size"],
    }


def _build_vit_shapes(family: str, mode: str) -> str:
    """Assemble a --shapes= string for a known ViT family at the requested mode."""
    pts = _vit_profile_points()
    hw            = pts["hw"][mode]
    cu_seqlens    = pts["cu_seqlens"][mode]
    max_seqlen_c  = pts["max_seqlen_car"][mode]
    input_dim     = pts["input_dim"]
    rope_size     = pts["rope_embed_size"]
    parts = [
        f"input:{hw}x{input_dim}",
        f"rotary_pos_emb:{hw}x{rope_size}",
        f"cu_seqlens:{cu_seqlens}",
        f"max_seqlen_carrier:{max_seqlen_c}",
    ]
    if family == "qwen2_5_vl":
        parts.extend([
            f"cu_window_seqlens:{pts['cu_window_seq'][mode]}",
            f"window_index:{pts['window_idx'][mode]}",
            f"reverse_window_index:{pts['window_idx'][mode]}",
        ])
    elif family == "qwen3_vl":
        # Qwen3-VL / Qwen3-Omni use fast_pos_emb_* with shape (4, hw).
        parts.extend([
            f"fast_pos_emb_idx:4x{hw}",
            f"fast_pos_emb_weight:4x{hw}",
        ])
    return ",".join(parts)


def _detect_vit_family(engine_file: str) -> str:
    """Best-effort family detection by scanning the engine path."""
    p = engine_file.lower()
    if "qwen2.5-vl" in p or "qwen2_5-vl" in p:
        return "qwen2_5_vl"
    if "qwen3-vl" in p or "qwen3-omni" in p:
        return "qwen3_vl"
    if "qwen2-vl" in p:
        return "qwen_vl"  # base Qwen-VL, no window / no fast_pos_emb
    return ""


def _default_shapes_for_engine(engine_file: str) -> str:
    """Return a trtexec --shapes value for known VLM visual engines.

    Returns empty string when no heuristic matches; user must then provide
    --shapes=... via --extra-bench-args or TRTEXEC_DEFAULT_SHAPES env var.
    """
    family = _detect_vit_family(engine_file)
    if not family:
        return ""
    mode = os.environ.get("TRTEXEC_SHAPE_MODE", "min").lower()
    if mode not in ("min", "opt", "max"):
        mode = "min"
    return _build_vit_shapes(family, mode)


def _run_trtexec_benchmark(
    engine_file: str,
    warmup: int,
    iterations: int,
    log_path: str,
    extra_args: list | None,
    build_dir: str | None = None,
) -> dict:
    """Run trtexec benchmark on a single engine file."""
    # Prefer trtexec from the TRT package the engines were built with (version match).
    trtexec = None
    trt_pkg = get_trt_package_dir()
    if trt_pkg:
        candidate = os.path.join(trt_pkg, "bin", "trtexec")
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            trtexec = candidate

    if not trtexec:
        trtexec = shutil.which("trtexec")

    if not trtexec:
        # Fall back to common TensorRT install paths
        for candidate in ("/opt/tensorrt/bin/trtexec", "/usr/local/bin/trtexec"):
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                trtexec = candidate
                break
    if not trtexec:
        return {
            "success": False,
            "output": "",
            "error": "trtexec not found. Install TensorRT or add trtexec to PATH.",
            "metrics": {},
            "log_path": log_path,
            "cmd": "",
        }

    # trtexec warmup is in milliseconds, convert from iterations
    warmup_ms = warmup * 200  # rough estimate: ~200ms per warmup iteration
    cmd = [
        trtexec,
        f"--loadEngine={engine_file}",
        f"--warmUp={warmup_ms}",
        f"--iterations={iterations}",
    ]

    # Load edgellm custom plugins so trtexec can deserialize the engine
    env = get_subprocess_env(build_dir)
    plugin_path = env.get("EDGELLM_PLUGIN_PATH")
    if plugin_path and os.path.isfile(plugin_path):
        cmd.append(f"--staticPlugins={plugin_path}")

    if extra_args:
        cmd.extend(extra_args)

    # Auto-default --shapes: trtexec picks min-batch=1 for unspecified dynamic
    # inputs, which usually falls outside the engine's optimization profile
    # (e.g. Qwen2.5-VL visual encoder: profile 0 = [1024..4096]xD). Without
    # this every dynamic input needs to be filled on the command line. We
    # inject the profile-MIN shape for every known model family so trtexec
    # can deserialize and run out-of-the-box.
    #
    # Resolution order:
    #   1. user passed --shapes=... via extra_args  -> keep as-is
    #   2. TRTEXEC_DEFAULT_SHAPES env var           -> use it
    #   3. per-model heuristic on engine file path  -> profile MIN for all
    #      dynamic inputs of known VLM families.
    if not any(a.startswith("--shapes") for a in cmd):
        default_shapes = os.environ.get("TRTEXEC_DEFAULT_SHAPES")
        if not default_shapes:
            default_shapes = _default_shapes_for_engine(engine_file)
        if default_shapes:
            cmd.append(f"--shapes={default_shapes}")

    cmd_str = " ".join(cmd)
    try:
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {cmd_str}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=600)
        output = "".join(output_lines)
        if proc.returncode != 0:
            print(f"  FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"    {line}")
            return {
                "success": False,
                "output": output,
                "error": f"trtexec exited with code {proc.returncode}",
                "metrics": {},
                "log_path": log_path,
                "cmd": cmd_str,
            }
        metrics = _parse_trtexec_output(output)
        return {
            "success": True,
            "output": output,
            "error": None,
            "metrics": metrics,
            "log_path": log_path,
            "cmd": cmd_str,
        }
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"success": False, "output": "", "error": "trtexec timed out (600s)",
                "metrics": {}, "log_path": log_path, "cmd": cmd_str}
    except Exception as e:
        return {"success": False, "output": "", "error": str(e),
                "metrics": {}, "log_path": log_path, "cmd": cmd_str}


def run_multimodal_benchmark(
    engine_dir: str,
    warmup: int = 10,
    iterations: int = 100,
    precision: str = None,
    extra_args: list = None,
    build_dir: str | None = None,
) -> dict:
    """Run trtexec benchmark for visual/audio encoder engines.

    Finds all .engine files in the engine directory (including subdirectories
    like visual/, audio/, code2wav/) and benchmarks each with trtexec.
    """
    engine_files = _find_engine_files(engine_dir)
    if not engine_files:
        return {
            "success": False,
            "output": "",
            "error": f"No .engine files found under {engine_dir}",
            "metrics": {},
        }

    all_output = []
    all_metrics = {}

    for engine_file in engine_files:
        engine_name = os.path.basename(engine_file).replace(".engine", "")
        log_path = os.path.join(os.path.dirname(engine_file), f"bench_{engine_name}.log")

        result = _run_trtexec_benchmark(
            engine_file=engine_file,
            warmup=warmup,
            iterations=iterations,
            log_path=log_path,
            extra_args=extra_args,
            build_dir=build_dir,
        )

        all_output.append(result["output"])
        if not result["success"]:
            return {
                "success": False,
                "output": "\n".join(all_output),
                "error": f"[{engine_name}] {result['error']}",
                "metrics": all_metrics,
            }

        # Print summary aligned with LLM prefill/decode format
        metrics = result["metrics"]
        avg = metrics.get("avg_time_ms", "?")
        in_shape = metrics.get("input_shape", "?")
        out_shape = metrics.get("output_shape", "?")
        print(f"\n{engine_name}_encode:")
        print(f"  Input: {in_shape}  Output: {out_shape}  Iterations: {iterations}")
        print(f"  log: {log_path}")
        avg_str = f"{avg:.2f}" if isinstance(avg, (int, float)) else avg
        print(f"  >>> \033[1mAvg Time: {avg_str} ms\033[0m")

        # Prefix metrics with engine name
        if len(engine_files) > 1:
            for key, value in metrics.items():
                all_metrics[f"{engine_name}/{key}"] = value
        else:
            all_metrics = metrics

    return {
        "success": True,
        "output": "\n".join(all_output),
        "error": None,
        "metrics": all_metrics,
    }


def run_benchmark(
    engine_dir: str,
    build_dir: str = None,
    batch_size: int = 1,
    warmup: int = 10,
    iterations: int = 100,
    mode: str = None,
    input_len: int = None,
    precision: str = None,
    extra_args: list = None,
) -> dict:
    """Run benchmark for a model.

    For Eagle base models with both engines present: uses llm_inference --eagle.
    This helper uses llm_bench for kernel-level benchmarks when called
    directly. The top-level standard `run` path uses llm_inference,
    except ASR models which still route here.

    Note: visual/audio encoder benchmarks are handled separately via
    run_multimodal_inference() in inference_runner.py, which uses
    llm_inference --multimodalEngineDir.  These engines use the TRT
    compiler backend and cannot be loaded by trtexec.
    """
    if build_dir is None:
        build_dir = get_build_dir()

    # Eagle auto-detection: use llm_inference for e2e perf when both engines exist
    if mode is None and is_eagle_base(precision) and has_eagle_engines(engine_dir):
        from .inference_runner import run_eagle_inference

        return run_eagle_inference(
            engine_dir=engine_dir,
            build_dir=build_dir,
            warmup=warmup,
            batch_size=batch_size,
            extra_args=extra_args,
        )

    llm_bench = find_executable(build_dir, "llm_bench")

    # Determine which modes to run
    if mode is not None:
        modes = [mode]
    else:
        modes = _default_modes_for_precision(precision)

    all_output = []
    all_metrics = {}
    results = []  # collect (mode, result) for final summary

    for i, m in enumerate(modes):
        result = _run_single_benchmark(
            llm_bench=llm_bench,
            engine_dir=engine_dir,
            batch_size=batch_size,
            warmup=warmup,
            iterations=iterations,
            mode=m,
            input_len=input_len,
            extra_args=extra_args,
            build_dir=build_dir,
        )

        all_output.append(result["output"])
        results.append((m, result))

        if not result["success"]:
            return {
                "success": False,
                "output": "\n".join(all_output),
                "error": f"[mode={m}] {result['error']}",
                "metrics": all_metrics,
            }

        # Prefix metrics with mode name when running multiple modes
        if len(modes) > 1:
            for key, value in result["metrics"].items():
                all_metrics[f"{m}/{key}"] = value
        else:
            all_metrics = result["metrics"]

    # Print clean summary to terminal
    # Engine config (from first mode)
    first_result = results[0][1]
    ec = first_result.get("engine_config", {})
    if ec:
        print(f"\nEngine: {engine_dir}")
        print(f"  Layers: {ec.get('layers', '?')}  Hidden: {ec.get('hidden_size', '?')}  "
              f"KV Heads: {ec.get('kv_heads', '?')}  Head Dim: {ec.get('head_dim', '?')}  "
              f"Vocab: {ec.get('vocab_size', '?')}")
        print(f"  Max Batch: {ec.get('max_batch_size', '?')}  "
              f"Max Input: {ec.get('max_input_len', '?')}  "
              f"Max KV Cache: {ec.get('max_kv_cache', '?')}  "
              f"Eagle: {ec.get('eagle_enable', '?')}")

    # Per-mode results
    for m, result in results:
        metrics = result["metrics"]
        avg = metrics.get("avg_time_ms", "?")
        tps = metrics.get("throughput_tokens_per_sec", "?")
        bs = metrics.get("batch_size", "?")
        iters = metrics.get("iterations", "?")
        il = metrics.get("input_len", "?")
        log = result.get("log_path", "?")
        # Tokens per step depends on mode
        if m == "decode":
            tokens_per_step = 1
        elif m == "eagle_verify":
            tokens_per_step = metrics.get("verify_tree_size", "?")
        elif m == "eagle_draft_proposal":
            tokens_per_step = metrics.get("draft_tree_size", "?")
        else:
            tokens_per_step = il
        print(f"\n{m}:")
        print(f"  Batch Size: {bs}  Input Seq Length: {tokens_per_step}  Iterations: {iters}")
        print(f"  log: {log}")
        avg_str = f"{avg:.2f}" if isinstance(avg, (int, float)) else avg
        tps_str = f"{tps:.2f}" if isinstance(tps, (int, float)) else tps
        print(f"  >>> \033[1mAvg Time: {avg_str} ms  |  Perf: {tps_str} tokens/s\033[0m")

    return {
        "success": True,
        "output": "\n".join(all_output),
        "error": None,
        "metrics": all_metrics,
    }
