"""CLI entry point for edgellm-bench."""

import argparse
import json
import os
import platform
import sys

from .benchmark_runner import run_benchmark, run_multimodal_benchmark
from .config import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_ENGINE_DIR,
    DEFAULT_INPUT_LEN,
    DEFAULT_ITERATIONS,
    DEFAULT_MAX_BATCH_SIZE,
    DEFAULT_MAX_INPUT_LEN,
    DEFAULT_MAX_SEQ_LEN,
    DEFAULT_NAS_BASE_URL,
    DEFAULT_ONNX_DIR,
    DEFAULT_REPO_REF,
    DEFAULT_REPO_REMOTE,
    DEFAULT_WARMUP,
    get_build_dir,
)
from .engine_builder import build_engine
from .inference_runner import run_eagle_inference, run_multimodal_inference, run_standard_inference
from .nas_client import download_model, list_models, list_precisions
from .project_builder import (
    BUILD_PROFILES,
    build_project,
    detect_build_profile,
    ensure_project,
    has_required_executables,
    resolve_trt_package_dir,
)
from .utils import derive_draft_precision, is_eagle_base


def _format_precision(precision_str):
    """Parse a precision string and return a human-readable description.

    Precision string formats:
      llm-<model>-<lmhead>[-extra...]              -> "LLM    model=<model>  lm_head=<lmhead>"
      llm-base-<model>-<lmhead>[-extra...]          -> "Base   model=<model>  lm_head=<lmhead>"
      draft-<type>-<model>-<lmhead>[-extra...]       -> "Draft  type=<type>  model=<model>  lm_head=<lmhead>"
      visual-<prec>                                  -> "ViT    model=<prec>"

    Known extra suffixes:
      rvsN   -> reduced_vocab_size=N
      fp8kv  -> fp8kv
    """
    parts = precision_str.split("-")
    component = parts[0]

    def _parse_extras(extra_parts):
        """Parse extra suffix parts into human-readable tags."""
        tags = []
        for part in extra_parts:
            if part.startswith("rvs"):
                tags.append(f"reduced_vocab={part[3:]}")
            else:
                tags.append(part)
        return ("  " + "  ".join(tags)) if tags else ""

    # Eagle base: llm-base-<model>-<lmhead>[-extras]
    if component == "llm" and len(parts) >= 4 and parts[1] == "base":
        model_prec = parts[2]
        lmhead_prec = parts[3]
        extras = _parse_extras(parts[4:])
        return f"Base   model={model_prec:<10s} lm_head={lmhead_prec:<10s}{extras}"

    # Eagle draft: draft-<type>-<model>-<lmhead>[-extras]
    if component == "draft" and len(parts) >= 4:
        draft_type = parts[1]
        model_prec = parts[2]
        lmhead_prec = parts[3]
        extras = _parse_extras(parts[4:])
        return f"Draft  {draft_type:<8s} model={model_prec:<10s} lm_head={lmhead_prec:<10s}{extras}"

    # Standard LLM: llm-<model>-<lmhead>[-extras]
    if component == "llm" and len(parts) >= 3:
        model_prec = parts[1]
        lmhead_prec = parts[2]
        extras = _parse_extras(parts[3:])
        return f"LLM    model={model_prec:<10s} lm_head={lmhead_prec:<10s}{extras}"

    # Visual: visual-<prec>
    if component == "visual" and len(parts) >= 2:
        extras = _parse_extras(parts[2:])
        return f"ViT    model={parts[1]}{extras}"

    # Audio: audio-<prec>
    if component == "audio" and len(parts) >= 2:
        extras = _parse_extras(parts[2:])
        return f"Audio  model={parts[1]}{extras}"

    return precision_str


def _get_components(onnx_dir):
    """Return list of sub-component names if onnx_dir is a multi-component model.

    A multi-component model has subdirectories containing model.onnx
    (e.g., TTS models with talker/ and code_predictor/).
    Returns an empty list for standard single-model directories.
    """
    components = []
    if not os.path.isdir(onnx_dir):
        return components
    for entry in sorted(os.listdir(onnx_dir)):
        subdir = os.path.join(onnx_dir, entry)
        if os.path.isdir(subdir) and os.path.isfile(os.path.join(subdir, "model.onnx")):
            components.append(entry)
    return components


def _compact_precisions(precisions, color=False):
    """Group precisions into labeled one-line format.

    Format: llm-{quants}-lmhead-{lmheads}-draft-{quants}-vit-{quants}-audio-{quants}
    Sections omitted if not available. Not all combinations are valid;
    invalid ones are caught at runtime with a clear error message.

    If color=True, structural labels (llm, lmhead, etc.) are rendered in
    bold cyan and punctuation ({, /, }) is dimmed using ANSI escape codes
    for better terminal readability.
    """
    # ANSI styles: bold cyan for labels, dim for braces/slashes
    LABEL = "\033[1;36m" if color else ""  # bold + cyan
    DIM = "\033[2m" if color else ""       # dim
    R = "\033[0m" if color else ""         # reset

    QUANT_ORDER = {
        "fp16": 0, "bf16": 1, "fp8": 2, "mxfp8": 3,
        "int8_sq": 4, "int4_awq": 5, "nvfp4": 6,
    }

    llm_quants = set()      # model quantization options
    lmhead_opts = set()     # lmhead + extras (e.g. fp16, fp16-fp8kv, nvfp4)
    draft_quants = set()    # eagle draft quant options
    visual_quants = set()   # visual encoder quant options
    audio_quants = set()    # audio encoder quant options
    standalone = []

    for p in precisions:
        parts = p.split("-")
        if parts[0] == "visual" and len(parts) >= 2:
            visual_quants.add(parts[1])
        elif parts[0] == "audio" and len(parts) >= 2:
            audio_quants.add(parts[1])
        elif parts[0] == "llm" and len(parts) >= 3:
            if parts[1] == "base" and len(parts) >= 4:
                # llm-base-<quant>-<lmhead>[-extras] — same quant pool as llm
                llm_quants.add(parts[2])
                lmhead_opts.add("-".join(parts[3:]))
            else:
                # llm-<quant>-<lmhead>[-extras]
                llm_quants.add(parts[1])
                lmhead_opts.add("-".join(parts[2:]))
        elif parts[0] == "draft" and len(parts) >= 4:
            # draft-eagle3-<quant>-<lmhead> — only track quant
            draft_quants.add(parts[2])
        else:
            standalone.append(p)

    def _fmt(options, order=None):
        items = sorted(options, key=lambda x: order.get(x, 50)) if order else sorted(options)
        if len(items) == 1:
            return items[0]
        sep = f"{DIM}/{R}"
        return f"{DIM}{{{R}" + sep.join(items) + f"{DIM}}}{R}"

    sections = []
    if llm_quants:
        sections.append(f"{LABEL}llm{R}-{_fmt(llm_quants, QUANT_ORDER)}")
    if lmhead_opts:
        sections.append(f"{LABEL}lmhead{R}-{_fmt(lmhead_opts)}")
    if draft_quants:
        sections.append(f"{LABEL}draft{R}-{_fmt(draft_quants, QUANT_ORDER)}")
    if visual_quants:
        sections.append(f"{LABEL}vit{R}-{_fmt(visual_quants, QUANT_ORDER)}")
    if audio_quants:
        sections.append(f"{LABEL}audio{R}-{_fmt(audio_quants, QUANT_ORDER)}")
    if standalone:
        sections.extend(standalone)
    return "-".join(sections)


def cmd_list(args):
    """Handle 'edgellm-bench list' command."""
    print(f"Fetching model list from {args.url} ...")
    models = list_models(args.url)

    if not models:
        print("No models found.")
        return 1

    if args.json:
        print(json.dumps(models, indent=2))
        return 0

    # Compact one-line-per-model format with grouped quant options
    use_color = sys.stdout.isatty()
    max_name_len = max(len(name) for name in models) + 2
    for model_name in sorted(models.keys()):
        compact = _compact_precisions(models[model_name], color=use_color)
        print(f"{model_name:<{max_name_len}}  {compact}")
    print(f"\nTotal: {len(models)} models")
    print("Usage: edgellm-bench run --model <MODEL> --precision <PRECISION>")
    print("  Pick one from {opt1/opt2/...}, e.g. llm-{fp16/nvfp4}-fp16 -> llm-nvfp4-fp16")
    return 0


def _parse_labeled_precision(precision):
    """Parse labeled format from 'list' output into standard precision string(s).

    Accepts both labeled and standard formats:
      llm-nvfp4-lmhead-fp16                -> ('llm-nvfp4-fp16', None, None)
      llm-nvfp4-lmhead-fp16-draft-nvfp4    -> ('llm-base-nvfp4-fp16', None, None)
      llm-nvfp4-lmhead-fp16-vit-fp16       -> ('llm-nvfp4-fp16', 'visual-fp16', None)
      llm-fp16-lmhead-fp16-audio-fp16      -> ('llm-fp16-fp16', None, 'audio-fp16')
      llm-nvfp4-fp16                       -> ('llm-nvfp4-fp16', None, None)  # passthrough
      visual-fp16                          -> ('visual-fp16', None, None)     # passthrough
      audio-fp16                           -> ('audio-fp16', None, None)      # passthrough

    Returns (llm_precision, visual_precision, audio_precision).
    """
    if "-lmhead-" not in precision:
        return precision, None, None  # Already standard format

    vit_prec = None
    audio_prec = None
    draft_quant = None
    remaining = precision

    # Extract -audio-<quant> section
    if "-audio-" in remaining:
        remaining, audio_part = remaining.rsplit("-audio-", 1)
        audio_prec = f"audio-{audio_part}"

    # Extract -vit-<quant> section (must be last or before draft)
    if "-vit-" in remaining:
        remaining, vit_part = remaining.rsplit("-vit-", 1)
        vit_prec = f"visual-{vit_part}"

    # Extract -draft-<quant> section
    if "-draft-" in remaining:
        remaining, draft_quant = remaining.rsplit("-draft-", 1)

    # remaining is now: llm-<quant>-lmhead-<lmhead>
    llm_part, lmhead = remaining.split("-lmhead-", 1)
    quant = llm_part.split("-", 1)[1]  # strip "llm-" prefix

    if draft_quant:
        llm_precision = f"llm-base-{quant}-{lmhead}"
    else:
        llm_precision = f"llm-{quant}-{lmhead}"

    return llm_precision, vit_prec, audio_prec


def _to_labeled(available):
    """Convert raw NAS precisions into labeled input format.

    Groups llm/llm-base precisions into labeled form and appends
    visual/audio/draft as selectable suffixes so the user can
    copy-paste a valid combination directly.

    Example output lines:
      llm-nvfp4-lmhead-fp16[-vit-{fp16/fp8}]
      llm-nvfp4-lmhead-fp16-fp8kv[-vit-{fp16/fp8}]
      llm-base-nvfp4-lmhead-fp16-draft-nvfp4[-vit-{fp16/fp8}]
    """
    llm_labeled = []     # (labeled_str, is_eagle_base)
    visual_opts = []
    audio_opts = []
    draft_quants = {}    # quant -> draft precision string
    other = []

    for p in available:
        parts = p.split("-")
        if parts[0] == "visual" and len(parts) >= 2:
            visual_opts.append(parts[1])
        elif parts[0] == "audio" and len(parts) >= 2:
            audio_opts.append(parts[1])
        elif parts[0] == "draft" and len(parts) >= 4:
            # draft-eagle3-<quant>-<lmhead> — index by quant
            draft_quants[parts[2]] = p
        elif parts[0] == "llm" and len(parts) >= 3:
            if parts[1] == "base" and len(parts) >= 4:
                quant = parts[2]
                lmhead = "-".join(parts[3:])
                llm_labeled.append((f"llm-{quant}-lmhead-{lmhead}-draft", True, quant))
            else:
                quant = parts[1]
                lmhead = "-".join(parts[2:])
                llm_labeled.append((f"llm-{quant}-lmhead-{lmhead}", False, quant))
        else:
            other.append(p)

    # Build optional suffixes
    def _fmt_opts(opts):
        s = sorted(opts)
        return s[0] if len(s) == 1 else "{" + "/".join(s) + "}"

    vit_suffix = f"-vit-{_fmt_opts(visual_opts)}" if visual_opts else ""
    audio_suffix = f"-audio-{_fmt_opts(audio_opts)}" if audio_opts else ""
    suffix = vit_suffix + audio_suffix

    # Expand eagle base lines with available draft quants
    lines = []
    for label, is_base, quant in llm_labeled:
        if is_base and quant in draft_quants:
            # draft-eagle3-<quant>-<lmhead> -> append just the quant
            label = f"{label}-{quant}"
        elif is_base:
            label = f"{label}-?"  # no matching draft on NAS
        lines.append(f"{label}{suffix}")

    lines.extend(other)
    return lines


def _validate_precision(model, precision):
    """Check if precision exists on NAS. Returns None on success, error string on failure."""
    import requests
    try:
        available = list_precisions(model)
    except requests.exceptions.HTTPError as e:
        if e.response is not None and e.response.status_code == 404:
            return f"Model '{model}' not found on NAS."
        return None  # Other HTTP error, skip validation
    except Exception:
        return None  # Network error, skip validation
    if not available:
        return f"Model '{model}' has no precision variants on NAS."
    if precision not in available:
        labeled = _to_labeled(available)
        lines = "\n  ".join(labeled)
        return (
            f"Precision '{precision}' not available for {model}.\n"
            f"Valid combinations:\n  {lines}"
        )
    return None


def _activate_project_venv(repo_dir):
    """Activate the project venv for the current process.

    Sets VIRTUAL_ENV and prepends the venv bin/ to PATH so that all
    subsequent Python imports and subprocess calls use the project venv.
    """
    arch = platform.machine()
    venv_dir = os.path.join(repo_dir, f".venv-{arch}")
    venv_bin = os.path.join(venv_dir, "bin")
    if os.path.isdir(venv_bin):
        os.environ["VIRTUAL_ENV"] = venv_dir
        os.environ["PATH"] = venv_bin + os.pathsep + os.environ.get("PATH", "")


_SDK_DIR_NAME = "TensorRT-Edge-LLM"


def _resolve_repo_dir(args, build_dir):
    """Resolve the Edge-LLM SDK repo directory.

    Priority:
      1. --repo-dir (explicit)
      2. --build-dir parent (if build dir looks like <repo>/build*)
      3. ./<SDK_DIR_NAME> under cwd (default — clone target)
    """
    explicit = getattr(args, "repo_dir", None)
    if explicit:
        return os.path.abspath(explicit)

    _abs_build = os.path.abspath(build_dir)
    _base = os.path.basename(_abs_build)
    if _base == "build" or _base.startswith("build-"):
        parent = os.path.dirname(_abs_build)
        if os.path.isfile(os.path.join(parent, "CMakeLists.txt")):
            return parent

    return os.path.join(os.getcwd(), _SDK_DIR_NAME)


def _run_step0_project_build(args, build_dir):
    """Step 0: Clone repo (if needed) and build the C++ project.

    Default SDK location: ./<SDK_DIR_NAME> under the current working directory.
    If the SDK is already built (executables exist), Step 0 is skipped entirely.

    Returns the resolved build_dir on success, or None on failure.
    """
    skip = getattr(args, "skip_project_build", False)
    force = getattr(args, "force_project_build", False)

    import platform as _platform
    _arch = _platform.machine()

    repo_dir = _resolve_repo_dir(args, build_dir)

    # Candidate build dirs to check for existing executables:
    #   1. Explicit --build-dir
    #   2. <repo>/build-<arch>  (Step 0's default output)
    #   3. <repo>/build         (manual cmake builds)
    candidates = [
        os.path.abspath(build_dir),
        os.path.join(repo_dir, f"build-{_arch}"),
        os.path.join(repo_dir, "build"),
    ]
    # Deduplicate while preserving order
    seen = set()
    unique_candidates = []
    for c in candidates:
        if c not in seen:
            seen.add(c)
            unique_candidates.append(c)

    # Check if any candidate already has the required executables
    if not force:
        for candidate in unique_candidates:
            if has_required_executables(candidate):
                if skip:
                    print(f"\n=== Step 0: Project build skipped (--skip-project-build) ===")
                else:
                    print(f"\n=== Step 0: Project build skipped (executables found in {candidate}) ===")
                _activate_project_venv(repo_dir)
                return candidate

    if skip:
        print(f"\n=== Step 0: Project build skipped (--skip-project-build) ===")
        print(f"Warning: Required executables not found in any of:", file=sys.stderr)
        for c in unique_candidates:
            print(f"  - {c}", file=sys.stderr)
        print("  Run without --skip-project-build, or build manually.", file=sys.stderr)
        return None

    print(f"\n=== Step 0: Project download & build ===")

    repo_ref = getattr(args, "repo_ref", None) or DEFAULT_REPO_REF
    repo_remote = getattr(args, "repo_remote", None) or DEFAULT_REPO_REMOTE

    # Step 0a: Ensure repo exists (clone if needed)
    try:
        repo_dir = ensure_project(
            repo_dir=repo_dir,
            ref=repo_ref,
            remote=repo_remote,
            pull=False,
        )
    except Exception as e:
        print(f"Error cloning/updating repo: {e}", file=sys.stderr)
        return None

    # Step 0b: Detect target profile
    target = getattr(args, "target", None) or "auto"
    if target == "auto":
        try:
            target = detect_build_profile()
        except RuntimeError as e:
            print(f"Error: {e}", file=sys.stderr)
            return None
    print(f"  Target profile: {target}")

    # Step 0c: Resolve TRT package dir
    trt_dir = getattr(args, "trt_package_dir", None)
    try:
        trt_dir = resolve_trt_package_dir(target, explicit_trt_dir=trt_dir)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return None
    print(f"  TRT_PACKAGE_DIR: {trt_dir}")

    # Build dir: <repo>/build-<arch>
    actual_build_dir = os.path.join(repo_dir, f"build-{_arch}")

    # Step 0d: CMake + make
    enable_fmha = getattr(args, "enable_cute_dsl_fmha", None)
    if enable_fmha == "auto" or enable_fmha is None:
        enable_fmha = None  # let profile decide
    elif enable_fmha == "on":
        enable_fmha = True
    elif enable_fmha == "off":
        enable_fmha = False

    result = build_project(
        repo_dir=repo_dir,
        profile_name=target,
        build_dir=actual_build_dir,
        trt_package_dir=trt_dir,
        build_type=getattr(args, "cmake_build_type", None),
        enable_cute_dsl_fmha=enable_fmha,
        jobs=getattr(args, "build_jobs", None),
        clean=getattr(args, "clean_build", False),
        extra_cmake_args=getattr(args, "extra_cmake_args", None),
    )

    if not result["success"]:
        print(f"Project build failed: {result['error']}", file=sys.stderr)
        return None

    # Set TRT_PACKAGE_DIR in env so downstream steps find libs
    os.environ["TRT_PACKAGE_DIR"] = trt_dir

    # Activate project venv for remaining steps
    _activate_project_venv(repo_dir)

    return result["build_dir"]


def cmd_run(args):
    """Handle 'edgellm-bench run' command."""
    build_dir = args.build_dir or get_build_dir()
    download_dir = args.download_dir or str(DEFAULT_ONNX_DIR)
    engine_base_dir = args.engine_dir or str(DEFAULT_ENGINE_DIR)

    # Step 0: Project download & build (on by default)
    resolved_build_dir = _run_step0_project_build(args, build_dir)
    if resolved_build_dir is None:
        return 1
    build_dir = resolved_build_dir

    # Parse labeled format from 'list' output (e.g. llm-nvfp4-lmhead-fp16-vit-fp8)
    llm_precision, vit_precision, audio_precision = _parse_labeled_precision(args.precision)
    if llm_precision != args.precision:
        extras = []
        if vit_precision:
            extras.append(vit_precision)
        if audio_precision:
            extras.append(audio_precision)
        extra_str = (" + " + " + ".join(extras)) if extras else ""
        print(f"Parsed precision: {llm_precision}{extra_str}")
    args.precision = llm_precision

    # Validate all precisions exist before doing any work
    if not args.skip_download:
        for prec in [args.precision, vit_precision, audio_precision]:
            if prec is None:
                continue
            err = _validate_precision(args.model, prec)
            if err:
                print(f"Error: {err}")
                return 1

    is_eagle = is_eagle_base(args.precision)

    if is_eagle:
        rc = _cmd_run_eagle(args, build_dir, download_dir, engine_base_dir,
                            vit_precision=vit_precision, audio_precision=audio_precision)
    else:
        rc = _cmd_run_standard(args, build_dir, download_dir, engine_base_dir,
                               vit_precision=vit_precision, audio_precision=audio_precision)

    if is_eagle:
        llm_engine_dir = os.path.join(engine_base_dir, args.model, "eagle")
    else:
        llm_engine_dir = os.path.join(engine_base_dir, args.model, llm_precision)

    # Benchmark visual/audio encoder via trtexec (download + build already done above)
    for mm_prec, label in [(vit_precision, "visual"), (audio_precision, "audio")]:
        if rc != 0 or mm_prec is None:
            continue
        rc = _cmd_run_multimodal(
            args, build_dir, download_dir, engine_base_dir,
            mm_precision=mm_prec,
            llm_engine_dir=llm_engine_dir,
            skip_download=True,
            skip_build=True,
        )

    return rc


def _fixup_multimodal_configs(onnx_dir, engine_dir):
    """Copy config files from ONNX dir if the engine copies are missing or empty.

    Scratch filesystems sometimes write 0-byte configs despite a successful build.
    This ensures llm_inference can find the config files it needs.
    """
    import shutil
    for subdir in ("visual", "audio", "code2wav"):
        eng_sub = os.path.join(engine_dir, subdir)
        if not os.path.isdir(eng_sub):
            continue
        for cfg_name in ("config.json", "preprocessor_config.json"):
            eng_cfg = os.path.join(eng_sub, cfg_name)
            src_cfg = os.path.join(onnx_dir, cfg_name)
            if (not os.path.isfile(eng_cfg) or os.path.getsize(eng_cfg) == 0) and os.path.isfile(src_cfg):
                try:
                    shutil.copy2(src_cfg, eng_cfg)
                    print(f"  Recovered {cfg_name} from ONNX dir (engine copy was empty)")
                except OSError:
                    pass


def _cmd_run_standard(args, build_dir, download_dir, engine_base_dir,
                      vit_precision=None, audio_precision=None):
    """Standard (non-eagle) run: download, build, and benchmark."""
    onnx_dir = os.path.join(download_dir, args.model, args.precision)
    engine_dir = os.path.join(engine_base_dir, args.model, args.precision)

    mm_precisions = [(p, l) for p, l in [(vit_precision, "visual"), (audio_precision, "audio")] if p]
    use_llm_bench = audio_precision is not None or "asr" in args.model.lower()

    # Step 1: Download ONNX model
    if not args.skip_download:
        print(f"\n=== Step 1/3: Downloading {args.model}/{args.precision} ===")
        try:
            onnx_dir = download_model(
                model_name=args.model,
                precision=args.precision,
                dest_dir=download_dir,
                base_url=args.url,
            )
        except Exception as e:
            print(f"Download failed: {e}", file=sys.stderr)
            return 1

        # Also download visual/audio ONNX
        for mm_prec, label in mm_precisions:
            print(f"  Downloading {label}: {args.model}/{mm_prec} ...")
            try:
                download_model(
                    model_name=args.model,
                    precision=mm_prec,
                    dest_dir=download_dir,
                    base_url=args.url,
                )
            except Exception as e:
                print(f"{label.title()} download failed: {e}", file=sys.stderr)
                return 1
    else:
        print(f"\n=== Step 1/3: Download skipped (using {onnx_dir}) ===")
        if not os.path.isdir(onnx_dir):
            print(f"Error: ONNX directory not found: {onnx_dir}", file=sys.stderr)
            return 1

    # Detect multi-component models (e.g., TTS with talker/ + code_predictor/)
    components = _get_components(onnx_dir)
    if components:
        print(f"\nMulti-component model detected: {', '.join(components)}")
        if args.download_only:
            print("Download-only mode: done.")
            return 0
        return _cmd_run_multi_component(
            args, build_dir, onnx_dir, engine_dir, components,
        )

    if args.download_only:
        print("Download-only mode: done.")
        return 0

    # Step 2: Build engine
    if not args.skip_build:
        print(f"\n=== Step 2/3: Building engine ===")
        result = build_engine(
            onnx_dir=onnx_dir,
            engine_dir=engine_dir,
            build_dir=build_dir,
            max_seq_len=args.max_seq_len,
            max_batch_size=args.max_batch_size,
            max_input_len=args.max_input_len,
            precision=args.precision,
            extra_args=args.extra_build_args,
        )
        if not result["success"]:
            print(f"Engine build failed: {result['error']}", file=sys.stderr)
            return 1

        # Also build visual/audio engines
        for mm_prec, label in mm_precisions:
            mm_onnx = os.path.join(download_dir, args.model, mm_prec)
            mm_engine = os.path.join(engine_base_dir, args.model, mm_prec)
            print(f"  Building {label} engine ...")
            result = build_engine(
                onnx_dir=mm_onnx,
                engine_dir=mm_engine,
                build_dir=build_dir,
                precision=mm_prec,
                extra_args=args.extra_build_args,
            )
            if not result["success"]:
                print(f"{label.title()} engine build failed: {result['error']}", file=sys.stderr)
                return 1
            _fixup_multimodal_configs(mm_onnx, mm_engine)
    else:
        print(f"\n=== Step 2/3: Build skipped (using {engine_dir}) ===")
        if not os.path.isdir(engine_dir):
            print(f"Error: Engine directory not found: {engine_dir}", file=sys.stderr)
            return 1

    if use_llm_bench:
        ignored = []
        if getattr(args, "input_file", None):
            ignored.append("--input-file")
        if args.max_generate_length != 512:
            ignored.append("--max-generate-length")
        if args.extra_infer_args:
            ignored.append("--extra-infer-args")
        if ignored:
            print(
                f"Warning: ASR mode ignores: {', '.join(ignored)} "
                "(using llm_bench instead of llm_inference)"
            )

        # ASR models currently use MRope in llm_inference and can hit a
        # CosSinCache batch-shape issue, so keep ASR on llm_bench.
        print(f"\n=== Step 3/3: Running ASR benchmark ===")
        result = run_benchmark(
            engine_dir=engine_dir,
            build_dir=build_dir,
            batch_size=args.batch_size,
            warmup=args.warmup,
            iterations=args.iterations,
            mode=args.mode,
            input_len=args.input_len,
            precision=args.precision,
            extra_args=args.extra_bench_args,
        )

        if not result["success"]:
            print(f"Benchmark failed: {result['error']}", file=sys.stderr)
            return 1
    else:
        ignored = []
        if args.mode:
            ignored.append("--mode")
        if args.input_len != DEFAULT_INPUT_LEN:
            ignored.append("--input-len")
        if args.iterations != DEFAULT_ITERATIONS:
            ignored.append("--iterations")
        if args.extra_bench_args:
            ignored.append("--extra-bench-args")
        if ignored:
            print(
                f"Warning: standard mode ignores: {', '.join(ignored)} "
                "(using llm_inference instead of llm_bench)"
            )

        # Step 3: Run inference benchmark
        print(f"\n=== Step 3/3: Running inference benchmark ===")
        result = run_standard_inference(
            engine_dir=engine_dir,
            build_dir=build_dir,
            input_file=getattr(args, "input_file", None),
            batch_size=args.batch_size,
            warmup=args.warmup,
            max_generate_length=args.max_generate_length,
            extra_args=args.extra_infer_args,
        )

        if not result["success"]:
            print(f"Inference failed: {result['error']}", file=sys.stderr)
            return 1

    return 0


def _cmd_run_multi_component(args, build_dir, onnx_dir, engine_dir, components):
    """Build and benchmark each component of a multi-component model (e.g., TTS).

    TTS models require --maxBatchSize=1 (ONNX export uses fixed batch=1).
    """
    total = len(components)

    # TTS models require batch size 1 for engine build
    max_batch_size = 1
    if args.max_batch_size is not None and args.max_batch_size != 1:
        print(f"  Note: Forcing --maxBatchSize=1 for multi-component model (required by TTS ONNX export)")

    for idx, comp in enumerate(components, 1):
        comp_onnx = os.path.join(onnx_dir, comp)
        comp_engine = os.path.join(engine_dir, comp)

        # Build
        if not args.skip_build:
            print(f"\n=== [{idx}/{total}] Building engine for '{comp}' ===")
            result = build_engine(
                onnx_dir=comp_onnx,
                engine_dir=comp_engine,
                build_dir=build_dir,
                max_seq_len=args.max_seq_len,
                max_batch_size=max_batch_size,
                max_input_len=args.max_input_len,
                precision=args.precision,
                extra_args=args.extra_build_args,
            )
            if not result["success"]:
                print(f"Engine build failed for '{comp}': {result['error']}", file=sys.stderr)
                return 1
        else:
            print(f"\n=== [{idx}/{total}] Build skipped for '{comp}' (using {comp_engine}) ===")
            if not os.path.isdir(comp_engine):
                print(f"Error: Engine directory not found: {comp_engine}", file=sys.stderr)
                return 1

        # Benchmark
        print(f"\n=== [{idx}/{total}] Benchmarking '{comp}' ===")
        result = run_benchmark(
            engine_dir=comp_engine,
            build_dir=build_dir,
            batch_size=args.batch_size,
            warmup=args.warmup,
            iterations=args.iterations,
            mode=args.mode,
            input_len=args.input_len,
            precision=args.precision,
            extra_args=args.extra_bench_args,
        )
        if not result["success"]:
            print(f"Benchmark failed for '{comp}': {result['error']}", file=sys.stderr)
            return 1

    return 0


def _cmd_run_multimodal(args, build_dir, download_dir, engine_base_dir,
                        mm_precision, llm_engine_dir,
                        skip_download=False, skip_build=False):
    """Download + build a visual/audio encoder, then benchmark via trtexec.

    Finds all .engine files under the engine directory and benchmarks each
    with trtexec.  trtexec uses the optimization profile shapes baked into
    the engine at build time (controlled by visual_build --minImageTokens).

    When called from cmd_run(), download and build are already handled by
    _cmd_run_standard/_cmd_run_eagle, so skip_download/skip_build are True.
    """
    onnx_dir = os.path.join(download_dir, args.model, mm_precision)
    engine_dir = os.path.join(engine_base_dir, args.model, mm_precision)

    do_download = not args.skip_download and not skip_download
    do_build = not args.skip_build and not skip_build

    # Step 1: Download ONNX
    if do_download:
        print(f"  Downloading {args.model}/{mm_precision} ...")
        try:
            onnx_dir = download_model(
                model_name=args.model,
                precision=mm_precision,
                dest_dir=download_dir,
                base_url=args.url,
            )
        except Exception as e:
            print(f"Download failed: {e}", file=sys.stderr)
            return 1
    elif not skip_download:
        if not os.path.isdir(onnx_dir):
            print(f"Error: ONNX directory not found: {onnx_dir}", file=sys.stderr)
            return 1

    if args.download_only:
        print("Download-only mode: done.")
        return 0

    # Step 2: Build engine
    if do_build:
        print(f"  Building engine ...")
        result = build_engine(
            onnx_dir=onnx_dir,
            engine_dir=engine_dir,
            build_dir=build_dir,
            precision=mm_precision,
            extra_args=args.extra_build_args,
        )
        if not result["success"]:
            print(f"Engine build failed: {result['error']}", file=sys.stderr)
            return 1
    elif not skip_build:
        if not os.path.isdir(engine_dir):
            print(f"Error: Engine directory not found: {engine_dir}", file=sys.stderr)
            return 1

    # Fixup: scratch filesystems sometimes write 0-byte configs despite success.
    # Copy config.json from ONNX dir if the engine copy is missing or empty.
    import shutil
    for subdir in ("visual", "audio", "code2wav"):
        eng_sub = os.path.join(engine_dir, subdir)
        if not os.path.isdir(eng_sub):
            continue
        for cfg_name in ("config.json", "preprocessor_config.json"):
            eng_cfg = os.path.join(eng_sub, cfg_name)
            src_cfg = os.path.join(onnx_dir, cfg_name)
            if (not os.path.isfile(eng_cfg) or os.path.getsize(eng_cfg) == 0) and os.path.isfile(src_cfg):
                try:
                    shutil.copy2(src_cfg, eng_cfg)
                    print(f"  Recovered {cfg_name} from ONNX dir (engine copy was empty)")
                except OSError:
                    pass

    # Step 3: Benchmark via trtexec
    result = run_multimodal_benchmark(
        engine_dir=engine_dir,
        warmup=args.warmup,
        iterations=args.iterations,
        precision=mm_precision,
        extra_args=args.extra_bench_args,
        build_dir=build_dir,
    )

    if not result["success"]:
        print(f"Multimodal benchmark failed: {result['error']}", file=sys.stderr)
        return 1

    return 0


def _cmd_run_eagle(args, build_dir, download_dir, engine_base_dir,
                   vit_precision=None, audio_precision=None):
    """Eagle run: download + build both base & draft, then llm_inference --eagle."""
    base_precision = args.precision
    draft_precision = getattr(args, "draft_precision", None) or derive_draft_precision(base_precision)
    if not draft_precision:
        print(f"Error: Cannot derive draft precision from {base_precision}", file=sys.stderr)
        return 1

    engine_dir = os.path.join(engine_base_dir, args.model, "eagle")

    base_onnx = os.path.join(download_dir, args.model, base_precision)
    draft_onnx = os.path.join(download_dir, args.model, draft_precision)

    mm_precisions = [(p, l) for p, l in [(vit_precision, "visual"), (audio_precision, "audio")] if p]

    # Warn about args that are ignored in Eagle mode
    ignored = []
    if args.mode:
        ignored.append("--mode")
    if args.input_len != DEFAULT_INPUT_LEN:
        ignored.append("--input-len")
    if args.iterations != DEFAULT_ITERATIONS:
        ignored.append("--iterations")
    if ignored:
        print(f"Warning: Eagle mode ignores: {', '.join(ignored)} (using llm_inference instead of llm_bench)")

    print(f"\nEagle mode: base={base_precision}  draft={draft_precision}")
    print(f"Engine dir: {engine_dir}")

    # Step 1: Download base ONNX
    if not args.skip_download:
        print(f"\n=== Step 1/5: Downloading base {args.model}/{base_precision} ===")
        try:
            base_onnx = download_model(
                model_name=args.model,
                precision=base_precision,
                dest_dir=download_dir,
                base_url=args.url,
            )
        except Exception as e:
            print(f"Base download failed: {e}", file=sys.stderr)
            return 1

        # Step 2: Download draft ONNX
        print(f"\n=== Step 2/5: Downloading draft {args.model}/{draft_precision} ===")
        try:
            draft_onnx = download_model(
                model_name=args.model,
                precision=draft_precision,
                dest_dir=download_dir,
                base_url=args.url,
            )
        except Exception as e:
            print(f"Draft download failed: {e}", file=sys.stderr)
            return 1

        # Also download visual/audio ONNX
        for mm_prec, label in mm_precisions:
            print(f"  Downloading {label}: {args.model}/{mm_prec} ...")
            try:
                download_model(
                    model_name=args.model,
                    precision=mm_prec,
                    dest_dir=download_dir,
                    base_url=args.url,
                )
            except Exception as e:
                print(f"{label.title()} download failed: {e}", file=sys.stderr)
                return 1
    else:
        print(f"\n=== Step 1-2/5: Download skipped ===")
        for label, path in [("Base ONNX", base_onnx), ("Draft ONNX", draft_onnx)]:
            if not os.path.isdir(path):
                print(f"Error: {label} not found: {path}", file=sys.stderr)
                return 1

    if args.download_only:
        print("Download-only mode: done.")
        return 0

    # Step 3: Build base engine
    if not args.skip_build:
        print(f"\n=== Step 3/5: Building base engine ===")
        result = build_engine(
            onnx_dir=base_onnx,
            engine_dir=engine_dir,
            build_dir=build_dir,
            max_seq_len=args.max_seq_len,
            max_batch_size=args.max_batch_size,
            max_input_len=args.max_input_len,
            precision=base_precision,
            extra_args=args.extra_build_args,
        )
        if not result["success"]:
            print(f"Base engine build failed: {result['error']}", file=sys.stderr)
            return 1

        # Step 4: Build draft engine
        print(f"\n=== Step 4/5: Building draft engine ===")
        result = build_engine(
            onnx_dir=draft_onnx,
            engine_dir=engine_dir,
            build_dir=build_dir,
            max_seq_len=args.max_seq_len,
            max_batch_size=args.max_batch_size,
            max_input_len=args.max_input_len,
            precision=draft_precision,
            extra_args=args.extra_build_args,
        )
        if not result["success"]:
            print(f"Draft engine build failed: {result['error']}", file=sys.stderr)
            return 1

        # Also build visual/audio engines
        for mm_prec, label in mm_precisions:
            mm_onnx = os.path.join(download_dir, args.model, mm_prec)
            mm_engine = os.path.join(engine_base_dir, args.model, mm_prec)
            print(f"  Building {label} engine ...")
            result = build_engine(
                onnx_dir=mm_onnx,
                engine_dir=mm_engine,
                build_dir=build_dir,
                precision=mm_prec,
                extra_args=args.extra_build_args,
            )
            if not result["success"]:
                print(f"{label.title()} engine build failed: {result['error']}", file=sys.stderr)
                return 1
            _fixup_multimodal_configs(mm_onnx, mm_engine)
    else:
        print(f"\n=== Step 3-4/5: Build skipped (using {engine_dir}) ===")
        if not os.path.isdir(engine_dir):
            print(f"Error: Engine directory not found: {engine_dir}", file=sys.stderr)
            return 1

    # Step 5: Run eagle inference benchmark
    print(f"\n=== Step 5/5: Running Eagle inference benchmark ===")
    result = run_eagle_inference(
        engine_dir=engine_dir,
        build_dir=build_dir,
        warmup=args.warmup,
        max_generate_length=args.max_generate_length,
        batch_size=args.batch_size,
        extra_args=args.extra_infer_args,
    )

    if not result["success"]:
        print(f"Eagle benchmark failed: {result['error']}", file=sys.stderr)
        return 1

    return 0


def cmd_infer(args):
    """Handle 'edgellm-bench infer' command."""
    build_dir = args.build_dir or get_build_dir()
    engine_dir = args.engine_dir

    if not os.path.isdir(engine_dir):
        print(f"Error: Engine directory not found: {engine_dir}", file=sys.stderr)
        return 1

    print(f"\n=== Running inference benchmark ===")
    print(f"Engine: {engine_dir}")

    if args.eagle:
        result = run_eagle_inference(
            engine_dir=engine_dir,
            build_dir=build_dir,
            input_file=args.input_file,
            warmup=args.warmup,
            max_generate_length=args.max_generate_length,
            batch_size=args.batch_size,
            extra_args=args.extra_infer_args,
        )
    else:
        result = run_standard_inference(
            engine_dir=engine_dir,
            build_dir=build_dir,
            input_file=args.input_file,
            warmup=args.warmup,
            max_generate_length=args.max_generate_length,
            batch_size=args.batch_size,
            extra_args=args.extra_infer_args,
        )

    if not result["success"]:
        print(f"Inference failed: {result['error']}", file=sys.stderr)
        return 1

    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="edgellm-bench",
        description="TensorRT Edge-LLM Benchmark Tool",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- list ---
    list_parser = subparsers.add_parser("list", help="List available models and precisions")
    list_parser.add_argument(
        "--url", default=DEFAULT_NAS_BASE_URL, help="NAS base URL"
    )
    list_parser.add_argument(
        "--json", action="store_true", help="Output in JSON format"
    )

    # --- run ---
    run_parser = subparsers.add_parser(
        "run",
        help="Download, build, and benchmark a model",
        description=(
            "Download ONNX model, build TensorRT engine, and run benchmark.\n\n"
            "For Eagle models (--precision llm-base-*): automatically downloads and builds\n"
            "both base and draft engines, then runs llm_inference --eagle with MT-Bench\n"
            "prompts for end-to-end decode perf (acceptance rate + tokens/s).\n\n"
            "For standard models: runs llm_inference with MT-Bench prompts for end-to-end perf.\n"
            "For ASR models: runs llm_bench for prefill + decode benchmarks."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    run_parser.add_argument(
        "--model", required=True, help="Model name (e.g., Qwen2.5-7B-Instruct)"
    )
    run_parser.add_argument(
        "--precision", required=True,
        help="Precision variant (e.g., llm-fp16-fp16, llm-base-nvfp4-fp16 for Eagle)",
    )
    run_parser.add_argument(
        "--draft-precision",
        help="Draft precision for Eagle (auto-derived from --precision if not set)",
    )
    run_parser.add_argument("--build-dir", help="Build directory with C++ executables")
    run_parser.add_argument("--download-dir", help="Directory to download ONNX models")
    run_parser.add_argument(
        "--engine-dir",
        help="Base directory for engines (actual path: <engine-dir>/<model>/<precision>)",
    )
    run_parser.add_argument(
        "--max-seq-len", type=int, default=DEFAULT_MAX_SEQ_LEN, help="Max sequence length"
    )
    run_parser.add_argument(
        "--max-batch-size", type=int, default=DEFAULT_MAX_BATCH_SIZE, help="Max batch size for engine (omit to use llm_build default)"
    )
    run_parser.add_argument(
        "--max-input-len", type=int, default=DEFAULT_MAX_INPUT_LEN, help="Max input length for engine"
    )
    run_parser.add_argument(
        "--batch-size", type=int, default=DEFAULT_BATCH_SIZE, help="Batch size for benchmark"
    )
    run_parser.add_argument(
        "--warmup", type=int, default=DEFAULT_WARMUP, help="Warmup iterations"
    )
    run_parser.add_argument(
        "--iterations", type=int, default=DEFAULT_ITERATIONS,
        help="llm_bench compatibility option; ignored for llm_inference-based run",
    )
    run_parser.add_argument(
        "--mode",
        help="llm_bench compatibility option; ignored for llm_inference-based run",
    )
    run_parser.add_argument(
        "--input-len", type=int, default=DEFAULT_INPUT_LEN,
        help="llm_bench compatibility option; ignored for llm_inference-based run",
    )
    run_parser.add_argument(
        "--max-generate-length", type=int, default=512,
        help="Max tokens to generate per request (default: 512)",
    )
    run_parser.add_argument(
        "--input-file",
        help="Input JSON file for llm_inference (generates MT-Bench prompts if not provided)",
    )
    run_parser.add_argument("--skip-download", action="store_true", help="Skip ONNX download")
    run_parser.add_argument("--skip-build", action="store_true", help="Skip engine build")
    run_parser.add_argument("--download-only", action="store_true", help="Only download ONNX model, skip build and benchmark")
    run_parser.add_argument("--url", default=DEFAULT_NAS_BASE_URL, help="NAS base URL")
    run_parser.add_argument(
        "--extra-build-args", nargs="*", default=None,
        help="Extra arguments passed to llm_build",
    )
    run_parser.add_argument(
        "--extra-bench-args", nargs="*", default=None,
        help="Extra arguments passed to llm_bench for ASR/component benchmarks",
    )
    run_parser.add_argument(
        "--extra-infer-args", nargs="*", default=None,
        help="Extra arguments passed to llm_inference",
    )

    # --- Step 0: project download & build flags ---
    step0_group = run_parser.add_argument_group(
        "Project build (Step 0)",
        "Clone the Edge-LLM repo and build C++ executables automatically. "
        "Runs by default if executables are missing; skipped if they already exist.",
    )
    step0_group.add_argument(
        "--target",
        choices=list(BUILD_PROFILES.keys()) + ["auto"],
        default="auto",
        help="Build profile (default: auto-detect from architecture)",
    )
    step0_group.add_argument(
        "--repo-dir",
        help="Path to existing Edge-LLM repo checkout (skip clone)",
    )
    step0_group.add_argument(
        "--repo-ref",
        default=DEFAULT_REPO_REF,
        help=f"Git branch/tag/sha to checkout (default: {DEFAULT_REPO_REF})",
    )
    step0_group.add_argument(
        "--repo-remote",
        default=DEFAULT_REPO_REMOTE,
        help="Git remote URL (default: GitHub NVIDIA/TensorRT-Edge-LLM)",
    )
    step0_group.add_argument(
        "--trt-package-dir",
        help="TensorRT package directory (auto-resolved if not set)",
    )
    step0_group.add_argument(
        "--cmake-build-type",
        choices=["Debug", "Release"],
        default=None,
        help="CMake build type (default: Release)",
    )
    step0_group.add_argument(
        "--enable-cute-dsl-fmha",
        choices=["on", "off", "auto"],
        default="auto",
        help="Enable CuTe DSL FMHA kernels (default: auto, per profile)",
    )
    step0_group.add_argument(
        "--build-jobs", type=int, default=None,
        help="Parallelism for make -j (default: all cores)",
    )
    step0_group.add_argument(
        "--clean-build", action="store_true",
        help="Wipe build directory before building",
    )
    step0_group.add_argument(
        "--skip-project-build", action="store_true",
        help="Skip Step 0 entirely (assumes executables already exist)",
    )
    step0_group.add_argument(
        "--force-project-build", action="store_true",
        help="Force Step 0 even if executables already exist",
    )
    step0_group.add_argument(
        "--extra-cmake-args", nargs="*", default=None,
        help="Extra arguments passed to cmake configure",
    )

    # --- infer ---
    infer_parser = subparsers.add_parser(
        "infer", help="Run end-to-end inference benchmark (Eagle or standard) using MT-Bench prompts"
    )
    infer_parser.add_argument(
        "--engine-dir", required=True,
        help="Engine directory (for Eagle: must contain both base and draft engines)",
    )
    infer_parser.add_argument("--build-dir", help="Build directory with C++ executables")
    infer_parser.add_argument(
        "--eagle", action="store_true",
        help="Enable Eagle speculative decoding mode",
    )
    infer_parser.add_argument(
        "--input-file",
        help="Input JSON file for llm_inference (generates MT-Bench prompts if not provided)",
    )
    infer_parser.add_argument(
        "--warmup", type=int, default=3, help="Number of warmup runs (default: 3)",
    )
    infer_parser.add_argument(
        "--max-generate-length", type=int, default=512,
        help="Max tokens to generate per request (default: 512)",
    )
    infer_parser.add_argument(
        "--batch-size", type=int, default=DEFAULT_BATCH_SIZE, help="Batch size (default: 1)",
    )
    infer_parser.add_argument(
        "--extra-infer-args", nargs="*", default=None,
        help="Extra arguments passed to llm_inference",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 1

    if args.command == "list":
        return cmd_list(args)
    elif args.command == "run":
        return cmd_run(args)
    elif args.command == "infer":
        return cmd_infer(args)

    return 0


if __name__ == "__main__":
    sys.exit(main())
