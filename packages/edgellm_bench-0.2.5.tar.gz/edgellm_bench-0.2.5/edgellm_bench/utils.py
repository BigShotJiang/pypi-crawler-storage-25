"""Shared utilities for edgellm-bench modules."""

import os

from .config import get_build_dir, get_trt_lib_paths


def find_executable(build_dir: str, name: str) -> str:
    """Find a C++ executable in the build directory.

    Searches in order: examples/llm/, examples/multimodal/, build root.
    """
    for subdir in ("examples/llm", "examples/multimodal"):
        path = os.path.join(build_dir, subdir, name)
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    path = os.path.join(build_dir, name)
    if os.path.isfile(path) and os.access(path, os.X_OK):
        return path
    raise FileNotFoundError(
        f"Cannot find executable '{name}' in {build_dir}. "
        "Make sure the project is built (cmake + make) and --build-dir is correct."
    )


def get_subprocess_env(build_dir: str | None = None):
    """Build subprocess environment with LD_LIBRARY_PATH and EDGELLM_PLUGIN_PATH set.

    Args:
        build_dir: Explicit build directory for finding the plugin .so.
                   Falls back to get_build_dir() if not provided.
    """
    env = os.environ.copy()
    lib_paths = get_trt_lib_paths()
    if lib_paths:
        existing = env.get("LD_LIBRARY_PATH", "")
        prepend = ":".join(lib_paths)
        env["LD_LIBRARY_PATH"] = f"{prepend}:{existing}" if existing else prepend

    # Auto-detect plugin .so from build directory if not already set
    if "EDGELLM_PLUGIN_PATH" not in env:
        _build_dir = build_dir or get_build_dir()
        plugin_path = os.path.join(_build_dir, "libNvInfer_edgellm_plugin.so")
        if os.path.isfile(plugin_path):
            env["EDGELLM_PLUGIN_PATH"] = plugin_path

    return env


# --- Precision helpers ---


def is_visual_precision(precision: str) -> bool:
    """Check if precision string indicates a visual encoder model."""
    if not precision:
        return False
    return precision.split("-")[0] == "visual"


def is_audio_precision(precision: str) -> bool:
    """Check if precision string indicates an audio encoder model."""
    if not precision:
        return False
    return precision.split("-")[0] == "audio"


# --- Eagle precision helpers ---

EAGLE_ENGINE_FILES = ["llm.engine", "config.json", "eagle_draft.engine", "draft_config.json"]


def is_eagle_base(precision: str) -> bool:
    """Check if precision string indicates an Eagle base model."""
    if not precision:
        return False
    parts = precision.split("-")
    return parts[0] == "llm" and len(parts) >= 2 and parts[1] == "base"


def is_eagle_draft(precision: str) -> bool:
    """Check if precision string indicates an Eagle draft model."""
    if not precision:
        return False
    return precision.split("-")[0] == "draft"


def has_eagle_engines(engine_dir: str) -> bool:
    """Check if engine_dir contains both base and draft engines for Eagle inference."""
    return all(os.path.exists(os.path.join(engine_dir, f)) for f in EAGLE_ENGINE_FILES)


def derive_draft_precision(base_precision: str) -> str | None:
    """Derive eagle draft precision from base precision.

    llm-base-<model>-<lmhead>[-extras] -> draft-eagle3-<model>-<lmhead>
    (base-specific extras like fp8kv are dropped for the draft)
    """
    parts = base_precision.split("-")
    if len(parts) >= 4 and parts[0] == "llm" and parts[1] == "base":
        return f"draft-eagle3-{parts[2]}-{parts[3]}"
    return None
