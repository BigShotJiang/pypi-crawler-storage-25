"""Engine builder — wraps the llm_build C++ executable."""

import json
import os
import re
import subprocess
import sys

from .config import get_build_dir
from .utils import find_executable, get_subprocess_env, is_audio_precision, is_eagle_base, is_eagle_draft, is_visual_precision


# Known ONNX exports that are incompatible with the current runtime and
# crash TRT's compiler backend with SIGFPE instead of producing a diagnostic.
# Each entry describes when to refuse the build.
#
# Key observation: Qwen3-TTS models on NAS
# (tensorrt-edge-llm-release-0.6.0) are still exported from edgellm_version
# 0.5.0. The LLM-only models tolerate that mismatch, but the TTS talker /
# code_predictor trigger a SIGFPE inside libnvinfer during the Compiler
# backend pass. Refuse the build up front so the failure is actionable instead
# of a silent coredump.
_INCOMPATIBLE_MODEL_TYPES = {
    # Matches config.json ``model`` (preferred) or ``model_type`` field.
    # Value is the minimum edgellm_version that is known-good.
    "qwen3ttstalker": "0.6.0",               # TTS talker (model field)
    "qwen3_tts_talker": "0.6.0",             # TTS talker (model_type field)
    "qwen3ttstalkercodepredictor": "0.6.0",  # TTS code_predictor (model field)
}


def _read_onnx_model_config(onnx_dir: str) -> dict | None:
    """Return the parsed ``config.json`` inside ``onnx_dir``, or ``None``."""
    cfg_path = os.path.join(onnx_dir, "config.json")
    if not os.path.isfile(cfg_path):
        return None
    try:
        with open(cfg_path) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _parse_semver(v: str | None) -> tuple[int, int, int] | None:
    """Parse ``major.minor.patch`` semver string; return ``None`` if invalid."""
    if not v or not isinstance(v, str):
        return None
    parts = v.strip().split(".")
    if len(parts) != 3:
        return None
    try:
        return tuple(int(p) for p in parts)  # type: ignore[return-value]
    except ValueError:
        return None


def _check_model_compatibility(onnx_dir: str) -> str | None:
    """Check ONNX export vs runtime compatibility before launching llm_build.

    Returns ``None`` if the model should be built normally. Returns a human-
    readable error string if the combination is known to crash and the build
    should be refused.
    """
    cfg = _read_onnx_model_config(onnx_dir)
    if not cfg:
        return None

    # Look up incompatibility entry by either ``model`` or ``model_type``.
    model_field = cfg.get("model") or ""
    model_type_field = cfg.get("model_type") or ""
    min_required_raw = (
        _INCOMPATIBLE_MODEL_TYPES.get(model_field)
        or _INCOMPATIBLE_MODEL_TYPES.get(model_type_field)
    )
    if min_required_raw is None:
        return None

    model_version_raw = cfg.get("edgellm_version")
    model_version = _parse_semver(model_version_raw)
    model_label = model_field or model_type_field

    min_required = _parse_semver(min_required_raw)
    if not min_required:
        return None

    if model_version is not None and model_version >= min_required:
        return None

    # Incompatible: the ONNX export is known to crash the current runtime.
    return (
        f"ONNX model in {onnx_dir} was exported with edgellm_version="
        f"{model_version_raw!r}, but model={model_label!r} requires "
        f"at least {min_required_raw}. Building this model is known to "
        f"trigger a SIGFPE in TensorRT's compiler backend. Re-export the "
        f"ONNX at >= {min_required_raw} or use a matching release of the "
        f"tensorrt-edgellm runtime."
    )


def _detect_engine_filename(precision: str) -> str:
    """Determine engine filename based on precision string.

    Eagle base models produce 'eagle_base.engine',
    Eagle draft models produce 'eagle_draft.engine',
    standard LLMs produce 'llm.engine'.
    """
    if is_eagle_draft(precision):
        return "eagle_draft.engine"
    if is_eagle_base(precision):
        return "eagle_base.engine"
    return "llm.engine"


def _create_bench_symlinks(engine_dir: str, precision: str | None) -> None:
    """Create symlinks so llm_bench finds eagle engines by expected names.

    llm_bench expects:
      eagle_verify mode   -> llm.engine + config.json
      eagle_draft_* mode  -> eagle_draft.engine + draft_config.json

    llm_build produces:
      --eagleBase  -> eagle_base.engine + base_config.json
      --eagleDraft -> eagle_draft.engine + draft_config.json  (already correct)
    """
    if not precision or not is_eagle_base(precision):
        return

    symlink_map = {
        "llm.engine": "eagle_base.engine",
        "config.json": "base_config.json",
    }
    for link_name, target_name in symlink_map.items():
        link_path = os.path.join(engine_dir, link_name)
        target_path = os.path.join(engine_dir, target_name)
        if os.path.exists(target_path) and not os.path.exists(link_path):
            os.symlink(target_name, link_path)
            print(f"  Symlinked {link_name} -> {target_name}")


def _print_visual_engine_info(engine_subdir: str) -> None:
    """Print visual engine input/output shape info from config.json."""
    import json
    cfg_path = os.path.join(engine_subdir, "config.json")
    if not os.path.isfile(cfg_path):
        return
    try:
        with open(cfg_path) as f:
            cfg = json.load(f)
        bc = cfg.get("builder_config", {})
        min_tok = bc.get("min_image_tokens", "?")
        max_tok = bc.get("max_image_tokens", "?")
        img_size = cfg.get("vision_config", {}).get("image_size")
        hidden = cfg.get("text_config", {}).get("hidden_size", "?")
        if isinstance(img_size, list):
            img_str = f"{img_size[0]}x{img_size[1]}"
        elif img_size:
            img_str = f"{img_size}x{img_size}"
        else:
            img_str = "?"
        print(f"  Input: 1x3x{img_str}  Output: [{min_tok}..{max_tok}]x{hidden}  (image_tokens: {min_tok}~{max_tok})")
    except Exception:
        pass


def build_engine(
    onnx_dir: str,
    engine_dir: str,
    build_dir: str = None,
    max_seq_len: int = 4096,
    max_batch_size: int = None,
    max_input_len: int = 2048,
    precision: str = None,
    extra_args: list = None,
) -> dict:
    """Build a TensorRT engine from ONNX model.

    Args:
        onnx_dir: Directory containing model.onnx and related files.
        engine_dir: Output directory for the built engine.
        build_dir: Build directory containing C++ executables.
        max_seq_len: Maximum sequence length (KV cache capacity).
        max_batch_size: Maximum batch size.
        max_input_len: Maximum input length.
        precision: Precision string (e.g., 'llm-base-fp8-fp16', 'draft-eagle3-fp16-fp16').
        extra_args: Additional command-line arguments for llm_build.

    Returns:
        dict with 'success', 'output', 'error' keys.
    """
    if build_dir is None:
        build_dir = get_build_dir()

    is_visual = is_visual_precision(precision)
    is_audio = is_audio_precision(precision)

    # Pre-flight compatibility check. ONNX exports from older edgellm versions
    # can crash TRT's compiler backend (e.g. Qwen3-TTS 0.5.0 + runtime 0.6.0
    # -> SIGFPE). Refuse the build with a clear message instead of coredumping.
    if not is_visual and not is_audio:
        compat_error = _check_model_compatibility(onnx_dir)
        if compat_error:
            return {"success": False, "output": "", "error": compat_error}

    os.makedirs(engine_dir, exist_ok=True)
    log_path = os.path.join(engine_dir, "build.log")

    # Check if engine already exists (filename / path depends on model type)
    if is_visual:
        # visual_build saves engine to <engineDir>/visual/ subdirectory
        visual_engine_subdir = os.path.join(engine_dir, "visual")
        if os.path.isdir(visual_engine_subdir) and any(
            f.endswith(".engine") for f in os.listdir(visual_engine_subdir)
        ):
            print(f"Visual engine already exists at {visual_engine_subdir}, skipping build.")
            print(f"  log: {log_path}")
            return {"success": True, "output": "Engine already exists", "error": None, "log_path": log_path}
    elif is_audio:
        # audio_build saves engine to <engineDir>/audio/ or <engineDir>/code2wav/ subdirectory
        for audio_subdir_name in ("audio", "code2wav"):
            audio_engine_subdir = os.path.join(engine_dir, audio_subdir_name)
            if os.path.isdir(audio_engine_subdir) and any(
                f.endswith(".engine") for f in os.listdir(audio_engine_subdir)
            ):
                print(f"Audio engine already exists at {audio_engine_subdir}, skipping build.")
                print(f"  log: {log_path}")
                return {"success": True, "output": "Engine already exists", "error": None, "log_path": log_path}
    else:
        engine_filename = _detect_engine_filename(precision) if precision else "llm.engine"
        engine_file = os.path.join(engine_dir, engine_filename)
        if os.path.exists(engine_file):
            print(f"Engine already exists at {engine_file}, skipping build.")
            print(f"  log: {log_path}")
            _create_bench_symlinks(engine_dir, precision)
            return {"success": True, "output": "Engine already exists", "error": None, "log_path": log_path}

    if is_visual:
        executable = find_executable(build_dir, "visual_build")
        cmd = [
            executable,
            f"--onnxDir={onnx_dir}",
            f"--engineDir={engine_dir}",
            "--minImageTokens=256",
        ]
    elif is_audio:
        executable = find_executable(build_dir, "audio_build")
        cmd = [
            executable,
            f"--onnxDir={onnx_dir}",
            f"--engineDir={engine_dir}",
        ]
    else:
        executable = find_executable(build_dir, "llm_build")
        cmd = [
            executable,
            f"--onnxDir={onnx_dir}",
            f"--engineDir={engine_dir}",
            f"--maxInputLen={max_input_len}",
            f"--maxKVCacheCapacity={max_seq_len}",
        ]
        if max_batch_size is not None:
            cmd.append(f"--maxBatchSize={max_batch_size}")

        # Auto-detect Eagle flags from precision string
        if precision:
            if is_eagle_draft(precision):
                cmd.append("--eagleDraft")
            elif is_eagle_base(precision):
                cmd.append("--eagleBase")

    if extra_args:
        cmd.extend(extra_args)

    print(f"Building engine... (log: {log_path})")
    print(f"  cmd: {' '.join(cmd)}")

    try:
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(build_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=1200)
        output = "".join(output_lines)
        if proc.returncode != 0:
            # Send the failure banner and last lines to stderr so they are
            # preserved even when stdout has been clobbered by upstream tqdm
            # progress bars (download `\r` repaint). Stderr is also what the
            # verify scripts tee via `2>&1`, so this keeps the log usable.
            exe_name = "visual_build" if is_visual else "audio_build" if is_audio else "llm_build"
            signal_hint = ""
            if proc.returncode < 0:
                # Popen reports signal kills as negative returncode (-8 for SIGFPE).
                sig_num = -proc.returncode
                try:
                    import signal as _signal
                    sig_name = _signal.Signals(sig_num).name
                except (ValueError, ImportError):
                    sig_name = f"signal {sig_num}"
                if sig_num == 8:  # SIGFPE
                    signal_hint = f" (killed by {sig_name} — arithmetic exception, typically a TRT compiler crash)"
                else:
                    signal_hint = f" (killed by {sig_name})"
            banner = f"Build FAILED (exit code {proc.returncode}){signal_hint}. Last lines of {log_path}:"
            sys.stdout.flush()
            sys.stderr.write(banner + "\n")
            for line in output_lines[-30:]:
                sys.stderr.write(f"  {line}")
            sys.stderr.flush()
            return {
                "success": False,
                "output": output,
                "error": f"{exe_name} exited with code {proc.returncode}{signal_hint}",
            }

        # Verify engine files were fully written (scratch filesystems may truncate)
        engine_size_match = re.search(
            r"Loaded engine size:\s*(\d+)\s*MiB", output
        )
        if engine_size_match:
            # We found "Loaded engine size: N MiB" — verify on disk
            expected_mib = int(engine_size_match.group(1))
            for root, _dirs, files in os.walk(engine_dir):
                for f in files:
                    if f.endswith(".engine"):
                        fpath = os.path.join(root, f)
                        actual = os.path.getsize(fpath)
                        actual_mib = actual / (1024 * 1024)
                        # Allow 10% tolerance for MiB rounding
                        if actual_mib < expected_mib * 0.9:
                            return {
                                "success": False,
                                "output": output,
                                "error": (
                                    f"Engine file appears truncated: {fpath} is "
                                    f"{actual_mib:.1f} MiB on disk but build reported "
                                    f"{expected_mib} MiB. This usually indicates a "
                                    f"filesystem I/O error (common on scratch mounts). "
                                    f"Delete the engine and rebuild."
                                ),
                            }
        else:
            # Fallback: check "Engine saved to <path>" and verify file exists & non-empty
            engine_saved_match = re.search(
                r"Engine saved to\s+(\S+)", output
            )
            if engine_saved_match:
                saved_path = engine_saved_match.group(1)
                if os.path.isfile(saved_path):
                    actual = os.path.getsize(saved_path)
                    if actual == 0:
                        return {
                            "success": False,
                            "output": output,
                            "error": (
                                f"Engine file is empty (0 bytes): {saved_path}. "
                                f"This usually indicates a filesystem I/O error "
                                f"(common on scratch mounts). Delete the engine and rebuild."
                            ),
                        }

        # Create symlinks so llm_bench can find the engine files.
        if not is_visual and not is_audio:
            _create_bench_symlinks(engine_dir, precision)

        if is_visual:
            done_path = os.path.join(engine_dir, "visual")
            _print_visual_engine_info(done_path)
        elif is_audio:
            # audio_build creates either audio/ or code2wav/ subdirectory
            for subdir in ("audio", "code2wav"):
                candidate = os.path.join(engine_dir, subdir)
                if os.path.isdir(candidate):
                    done_path = candidate
                    break
            else:
                done_path = engine_dir
        else:
            done_path = engine_dir
        print(f"Build complete: {done_path}")
        return {"success": True, "output": output, "error": None}
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"success": False, "output": "", "error": "Engine build timed out (1200s)"}
    except Exception as e:
        return {"success": False, "output": "", "error": str(e)}
