"""NAS server client for listing and downloading Edge-LLM ONNX models."""

import os
import re
import shutil
from typing import Dict, List

import requests
from bs4 import BeautifulSoup
from tqdm import tqdm

from .config import DEFAULT_NAS_BASE_URL, IGNORED_SUBDIRS, PRECISION_PREFIXES


def _safe_makedirs(path: str) -> None:
    """Create ``path`` as a directory, tolerating stale leftovers.

    ``os.makedirs(path, exist_ok=True)`` raises ``FileExistsError`` (errno 17)
    if ``path`` already exists as a non-directory (regular file, broken symlink,
    etc.). This is common on network-mounted scratch filesystems (sshfs, NFS)
    where partial writes from a previous run can leave corrupt entries behind.

    This helper promotes such stale leftovers by removing them and retrying,
    so downloads keep going in the presence of filesystem flakiness.
    """
    try:
        os.makedirs(path, exist_ok=True)
        return
    except FileExistsError:
        # Leaf exists but is not a directory. Remove and retry.
        pass

    # Attempt cleanup of the offending leaf.
    try:
        if os.path.islink(path) or os.path.isfile(path):
            os.remove(path)
        elif os.path.isdir(path):
            # It is actually a directory now (race?), nothing to do.
            return
        else:
            # Unknown: try rmtree as a last resort.
            shutil.rmtree(path, ignore_errors=True)
    except OSError:
        pass

    # Retry makedirs; if it still fails, re-raise with a clearer message.
    try:
        os.makedirs(path, exist_ok=True)
    except FileExistsError as exc:
        raise FileExistsError(
            f"Could not create download directory {path!r}: a non-directory "
            f"entry exists and could not be removed. If this path is on a "
            f"network mount (sshfs/NFS), the filesystem may be full or stale. "
            f"Try `rm -rf {path}` manually, or pass --download-dir pointing "
            f"to a local filesystem with free space."
        ) from exc


def _parse_directory_listing(html: str) -> List[str]:
    """Parse Apache directory index HTML and return subdirectory names."""
    soup = BeautifulSoup(html, "html.parser")
    dirs = []
    for link in soup.find_all("a"):
        href = link.get("href", "")
        # Subdirectories end with / and are not parent links
        if href.endswith("/") and not href.startswith("/") and not href.startswith("?"):
            name = href.rstrip("/")
            dirs.append(name)
    return dirs


def _parse_file_listing(html: str) -> List[dict]:
    """Parse Apache directory index HTML and return file info (name, size text)."""
    soup = BeautifulSoup(html, "html.parser")
    files = []
    for row in soup.find_all("tr"):
        cells = row.find_all("td")
        if len(cells) < 4:
            continue
        link = cells[1].find("a")
        if not link:
            continue
        href = link.get("href", "")
        # Skip directories and parent links
        if href.endswith("/") or href.startswith("/") or href.startswith("?"):
            continue
        name = href
        size_text = cells[3].get_text(strip=True)
        files.append({"name": name, "size_text": size_text})
    return files


def _parse_size(size_text: str) -> int:
    """Parse Apache size text like '13G', '476K', '551' to bytes (approximate)."""
    size_text = size_text.strip().rstrip()
    if size_text == "-":
        return 0
    multipliers = {"K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4}
    match = re.match(r"([\d.]+)\s*([KMGT])?", size_text)
    if not match:
        return 0
    value = float(match.group(1))
    unit = match.group(2)
    if unit and unit in multipliers:
        return int(value * multipliers[unit])
    return int(value)


def list_models(base_url: str = DEFAULT_NAS_BASE_URL) -> Dict[str, List[str]]:
    """Scrape the NAS server and return {model_name: [precision_variants]}.

    Filters out quantized/intermediate directories.
    """
    resp = requests.get(base_url, timeout=30)
    resp.raise_for_status()
    model_names = _parse_directory_listing(resp.text)

    models = {}
    for model_name in model_names:
        model_url = f"{base_url.rstrip('/')}/{model_name}/"
        try:
            resp = requests.get(model_url, timeout=30)
            resp.raise_for_status()
        except requests.RequestException:
            continue
        subdirs = _parse_directory_listing(resp.text)
        # Only keep dirs matching known precision prefixes, skip ignored ones
        precisions = [
            d for d in subdirs
            if d not in IGNORED_SUBDIRS and d.startswith(PRECISION_PREFIXES)
        ]
        if precisions:
            models[model_name] = sorted(precisions)

    return models


def _download_files(source_url: str, local_dir: str, files: List[dict]) -> None:
    """Download a list of files from source_url into local_dir, skipping existing."""
    for file_info in files:
        fname = file_info["name"]
        file_url = f"{source_url}{fname}"
        local_path = os.path.join(local_dir, fname)

        # Check if file exists and has roughly the right size
        if os.path.exists(local_path):
            local_size = os.path.getsize(local_path)
            expected_size = _parse_size(file_info["size_text"])
            # Allow 10% tolerance since Apache shows approximate sizes
            if expected_size > 0 and abs(local_size - expected_size) / expected_size < 0.1:
                print(f"  Skipping {fname} (already exists, {local_size} bytes)")
                continue

        # Stream download with progress bar
        with requests.get(file_url, stream=True, timeout=30) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            with open(local_path, "wb") as f, tqdm(
                total=total,
                unit="B",
                unit_scale=True,
                desc=fname,
                leave=True,
            ) as pbar:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
                    pbar.update(len(chunk))


def list_precisions(model_name: str, base_url: str = DEFAULT_NAS_BASE_URL) -> List[str]:
    """Fetch available precisions for a specific model (single HTTP request)."""
    model_url = f"{base_url.rstrip('/')}/{model_name}/"
    resp = requests.get(model_url, timeout=30)
    resp.raise_for_status()
    subdirs = _parse_directory_listing(resp.text)
    return sorted(
        d for d in subdirs
        if d not in IGNORED_SUBDIRS and d.startswith(PRECISION_PREFIXES)
    )


def download_model(
    model_name: str,
    precision: str,
    dest_dir: str,
    base_url: str = DEFAULT_NAS_BASE_URL,
) -> str:
    """Download all files for a model/precision variant from NAS.

    Handles both flat models (model.onnx at top level) and multi-component
    models (subdirectories like talker/, code_predictor/ each with model.onnx).

    Returns the local directory path containing the downloaded files.
    Skips files that already exist with matching size.
    """
    source_url = f"{base_url.rstrip('/')}/{model_name}/{precision}/"
    local_dir = os.path.join(dest_dir, model_name, precision)
    _safe_makedirs(local_dir)

    # Get file and directory listing
    resp = requests.get(source_url, timeout=30)
    resp.raise_for_status()
    files = _parse_file_listing(resp.text)
    subdirs = _parse_directory_listing(resp.text)

    # Download top-level files
    if files:
        print(f"Downloading {len(files)} files to {local_dir}")
        _download_files(source_url, local_dir, files)

    # Download subdirectories (multi-component models like TTS)
    for subdir in subdirs:
        sub_url = f"{source_url}{subdir}/"
        try:
            sub_resp = requests.get(sub_url, timeout=30)
            sub_resp.raise_for_status()
        except requests.RequestException:
            continue
        sub_files = _parse_file_listing(sub_resp.text)
        if not sub_files:
            continue
        sub_local = os.path.join(local_dir, subdir)
        _safe_makedirs(sub_local)
        print(f"Downloading {len(sub_files)} files to {sub_local}")
        _download_files(sub_url, sub_local, sub_files)

    if not files and not subdirs:
        raise RuntimeError(f"No files found at {source_url}")

    print(f"Download complete: {local_dir}")
    return local_dir
