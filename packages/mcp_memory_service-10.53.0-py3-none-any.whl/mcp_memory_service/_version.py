"""Version information for MCP Memory Service."""

__version__ = "10.53.0"
