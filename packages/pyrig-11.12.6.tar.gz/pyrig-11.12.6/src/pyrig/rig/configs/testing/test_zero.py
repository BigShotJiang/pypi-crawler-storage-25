"""Configuration for generating the test_zero.py placeholder test file."""

from pathlib import Path
from types import ModuleType

from pyrig.core.introspection.functions import module_functions
from pyrig.rig.configs.base.copy_module import CopyModuleConfigFile
from pyrig.rig.tests import test_zero as test_zero_module
from pyrig.rig.tests.test_zero import test_zero
from pyrig.rig.tools.project_tester import ProjectTester


class ZeroTestConfigFile(CopyModuleConfigFile):
    """Generates ``test_zero.py`` in the tests package root of a scaffolded project.

    Copies the content of ``pyrig.rig.tests.test_zero`` into the
    project's ``tests/`` directory. The result is a ``test_zero.py`` file
    containing a module docstring and a single empty ``test_zero()`` function.

    The generated file serves two purposes:

    - It ensures pytest always collects at least one test, preventing exit
      (no tests found) in CI pipelines for projects that have not yet
      written any real tests.
    - It triggers session-scoped autouse fixtures on the very first test run.

    Note:
        The class is named ``ZeroTestConfigFile`` rather than
        ``TestZeroConfigFile`` to prevent pytest from collecting it as a test
        class when it is imported into test files.

    Example:
        Generate ``test_zero.py`` for the current project::

            ZeroTestConfigFile.I.validate()
    """

    def parent_path(self) -> Path:
        """Return the tests package root as the destination directory.

        Overrides the base class, which would derive a nested path from
        the source module name (for example ``src/<pkg>/rig/tests``).
        This override places ``test_zero.py`` directly in the top-level
        ``tests/`` directory, which is where pytest expects to find it.

        Returns:
            ``Path("tests")`` — the root of the project's tests package.
        """
        return ProjectTester.I.tests_package_root()

    def copy_module(self) -> ModuleType:
        """Return the source module whose content is written to the project.

        Returns:
            ``pyrig.rig.tests.test_zero``
        """
        return test_zero_module

    def is_correct(self) -> bool:
        """Considered correct if ``test_zero`` is a function in the target module.

        Imports the target module and inspects its functions rather than scanning
        raw file content.
        """
        return test_zero.__name__ in (
            f.__name__  # ty:ignore[unresolved-attribute]
            for f in module_functions(self.module())
        )
