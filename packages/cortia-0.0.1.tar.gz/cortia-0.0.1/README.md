# cortia

Cortia is a Python package (currently a placeholder).

## Installation

```bash
pip install cortia
```
