def hello():
    return "Hello from cortia!"