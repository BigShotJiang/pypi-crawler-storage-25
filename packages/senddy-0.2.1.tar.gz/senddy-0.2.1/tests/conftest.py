from __future__ import annotations

import pytest


@pytest.fixture
def api_key() -> str:
    return "senddy_test_123"
