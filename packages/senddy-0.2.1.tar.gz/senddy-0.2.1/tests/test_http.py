from __future__ import annotations

import httpx
import pytest
import respx

from senddy._errors import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from senddy._http import (
    _parse_retry_after,
    async_http_request,
    http_request,
)

BASE_URL = "https://api.example.com"
API_KEY = "senddy_test"


class TestParseRetryAfter:
    def test_integer_seconds(self) -> None:
        assert _parse_retry_after("30") == 30

    def test_none(self) -> None:
        assert _parse_retry_after(None) == 0

    def test_invalid(self) -> None:
        assert _parse_retry_after("not-a-number") == 0

    def test_http_date_in_future(self) -> None:
        result = _parse_retry_after("Thu, 01 Jan 2099 00:00:00 GMT")
        assert result > 0

    def test_empty_string(self) -> None:
        assert _parse_retry_after("") == 0


class TestHttpRequest:
    @respx.mock
    def test_successful_json_response(self) -> None:
        respx.get(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )

        with httpx.Client(base_url=BASE_URL) as client:
            result = http_request(client, "GET", "/test", api_key=API_KEY, retries=0)

        assert result == {"ok": True}

    @respx.mock
    def test_204_returns_none(self) -> None:
        respx.delete(f"{BASE_URL}/thing").mock(
            return_value=httpx.Response(204)
        )

        with httpx.Client(base_url=BASE_URL) as client:
            result = http_request(client, "DELETE", "/thing", api_key=API_KEY, retries=0)

        assert result is None

    @respx.mock
    def test_sends_auth_header(self) -> None:
        route = respx.get(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(200, json={})
        )

        with httpx.Client(base_url=BASE_URL) as client:
            http_request(client, "GET", "/test", api_key="senddy_test_secret", retries=0)

        assert route.calls[0].request.headers["authorization"] == "Bearer senddy_test_secret"

    @respx.mock
    def test_sends_idempotency_key_on_post(self) -> None:
        route = respx.post(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(202, json={"id": "1"})
        )

        with httpx.Client(base_url=BASE_URL) as client:
            http_request(
                client,
                "POST",
                "/emails",
                api_key=API_KEY,
                retries=0,
                body={"test": True},
                idempotency_key="idem_abc",
            )

        assert route.calls[0].request.headers["idempotency-key"] == "idem_abc"

    @respx.mock
    def test_400_raises_validation_error(self) -> None:
        respx.post(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(
                400,
                json={
                    "error": "validation_error",
                    "message": "Invalid email",
                    "details": [{"field": "to", "message": "required"}],
                },
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            with pytest.raises(ValidationError) as exc_info:
                http_request(client, "POST", "/emails", api_key=API_KEY, retries=0)

        assert exc_info.value.status_code == 400
        assert len(exc_info.value.details) == 1

    @respx.mock
    def test_401_raises_authentication_error(self) -> None:
        respx.get(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(
                401,
                json={"error": "unauthorized", "message": "Bad key"},
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            with pytest.raises(AuthenticationError):
                http_request(client, "GET", "/test", api_key=API_KEY, retries=0)

    @respx.mock
    def test_404_raises_not_found_error(self) -> None:
        respx.get(f"{BASE_URL}/emails/missing").mock(
            return_value=httpx.Response(
                404,
                json={"error": "not_found", "message": "Email not found"},
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            with pytest.raises(NotFoundError):
                http_request(client, "GET", "/emails/missing", api_key=API_KEY, retries=0)

    @respx.mock
    def test_429_raises_rate_limit_error(self) -> None:
        respx.get(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(
                429,
                json={"error": "rate_limit_exceeded", "message": "Too many requests"},
                headers={
                    "retry-after": "30",
                    "x-ratelimit-limit": "100",
                    "x-ratelimit-remaining": "0",
                },
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            with pytest.raises(RateLimitError) as exc_info:
                http_request(client, "GET", "/test", api_key=API_KEY, retries=0)

        assert exc_info.value.retry_after == 30
        assert exc_info.value.limit == 100
        assert exc_info.value.remaining == 0

    @respx.mock
    def test_retries_on_500(self) -> None:
        route = respx.get(f"{BASE_URL}/test")
        route.side_effect = [
            httpx.Response(500, json={"error": "internal", "message": "Server error"}),
            httpx.Response(200, json={"ok": True}),
        ]

        with httpx.Client(base_url=BASE_URL) as client:
            result = http_request(client, "GET", "/test", api_key=API_KEY, retries=1)

        assert result == {"ok": True}
        assert route.call_count == 2

    @respx.mock
    def test_no_retry_on_400(self) -> None:
        route = respx.post(f"{BASE_URL}/emails")
        route.side_effect = [
            httpx.Response(
                400,
                json={"error": "validation_error", "message": "Bad", "details": []},
            ),
        ]

        with httpx.Client(base_url=BASE_URL) as client:
            with pytest.raises(ValidationError):
                http_request(client, "POST", "/emails", api_key=API_KEY, retries=2)

        assert route.call_count == 1

    @respx.mock
    def test_passes_query_params(self) -> None:
        route = respx.get(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(200, json={"data": []})
        )

        with httpx.Client(base_url=BASE_URL) as client:
            http_request(
                client,
                "GET",
                "/emails",
                api_key=API_KEY,
                retries=0,
                query={"limit": 10, "status": "delivered", "skip": None},
            )

        url = str(route.calls[0].request.url)
        assert "limit=10" in url
        assert "status=delivered" in url
        assert "skip" not in url


class TestAsyncHttpRequest:
    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_json_response(self) -> None:
        respx.get(f"{BASE_URL}/test").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            result = await async_http_request(
                client, "GET", "/test", api_key=API_KEY, retries=0
            )

        assert result == {"ok": True}

    @respx.mock
    @pytest.mark.asyncio
    async def test_retries_on_429(self) -> None:
        route = respx.get(f"{BASE_URL}/test")
        route.side_effect = [
            httpx.Response(
                429,
                json={"error": "rate_limit", "message": "Slow down"},
                headers={"retry-after": "0"},
            ),
            httpx.Response(200, json={"ok": True}),
        ]

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            result = await async_http_request(
                client, "GET", "/test", api_key=API_KEY, retries=1
            )

        assert result == {"ok": True}
        assert route.call_count == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_timeout_raises_api_error(self) -> None:
        respx.get(f"{BASE_URL}/test").mock(side_effect=httpx.ReadTimeout("timed out"))

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            with pytest.raises(APIError, match="timed out"):
                await async_http_request(
                    client, "GET", "/test", api_key=API_KEY, retries=0
                )
