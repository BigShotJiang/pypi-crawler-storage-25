from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from senddy import AsyncSenddy, Senddy
from senddy._errors import AuthenticationError
from senddy.resources._emails import AsyncEmails, Emails
from senddy.resources._suppressions import AsyncSuppressions, Suppressions


class TestSenddy:
    def test_creates_with_explicit_key(self) -> None:
        client = Senddy("senddy_test")
        assert client._api_key == "senddy_test"
        assert isinstance(client.emails, Emails)
        assert isinstance(client.suppressions, Suppressions)
        client.close()

    def test_raises_on_blank_key(self) -> None:
        with pytest.raises(AuthenticationError, match="must not be blank"):
            Senddy("")

    def test_raises_on_whitespace_key(self) -> None:
        with pytest.raises(AuthenticationError, match="must not be blank"):
            Senddy("   ")

    def test_reads_key_from_env(self) -> None:
        with patch.dict(os.environ, {"SENDDY_API_KEY": "senddy_test_env_key"}):
            with pytest.warns(match="SENDDY_API_KEY"):
                client = Senddy()
            assert client._api_key == "senddy_test_env_key"
            client.close()

    def test_raises_without_key(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("SENDDY_API_KEY", None)
            with pytest.raises(AuthenticationError, match="API key is required"):
                Senddy()

    def test_explicit_key_preferred_over_env(self) -> None:
        with patch.dict(os.environ, {"SENDDY_API_KEY": "senddy_test_env"}):
            client = Senddy("senddy_test_explicit")
            assert client._api_key == "senddy_test_explicit"
            client.close()

    def test_context_manager(self) -> None:
        with Senddy("senddy_test") as client:
            assert isinstance(client, Senddy)
        # After exiting, the internal client should be closed
        assert client._http_client.is_closed

    def test_custom_config(self) -> None:
        client = Senddy(
            "senddy_test",
            timeout=10.0,
            retries=5,
        )
        assert client._retries == 5
        client.close()


class TestAsyncSenddy:
    def test_creates_with_explicit_key(self) -> None:
        client = AsyncSenddy("senddy_test")
        assert client._api_key == "senddy_test"
        assert isinstance(client.emails, AsyncEmails)
        assert isinstance(client.suppressions, AsyncSuppressions)

    def test_raises_without_key(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("SENDDY_API_KEY", None)
            with pytest.raises(AuthenticationError, match="API key is required"):
                AsyncSenddy()

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        async with AsyncSenddy("senddy_test") as client:
            assert isinstance(client, AsyncSenddy)
        assert client._http_client.is_closed
