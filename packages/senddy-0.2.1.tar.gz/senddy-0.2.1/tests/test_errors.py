from __future__ import annotations

from senddy._errors import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InternalError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)


class TestAPIError:
    def test_base_error(self) -> None:
        err = APIError("Something broke", 500, "internal", "req_123")
        assert str(err) == "Something broke"
        assert err.status_code == 500
        assert err.code == "internal"
        assert err.request_id == "req_123"
        assert isinstance(err, Exception)

    def test_repr(self) -> None:
        err = APIError("test", 400, "bad_request", "req_1")
        assert "APIError" in repr(err)
        assert "400" in repr(err)


class TestValidationError:
    def test_has_details(self) -> None:
        details = [{"field": "email", "message": "required"}]
        err = ValidationError("Validation failed", "validation_error", "req_1", details)
        assert err.status_code == 400
        assert err.details == details
        assert isinstance(err, APIError)


class TestAuthenticationError:
    def test_status_401(self) -> None:
        err = AuthenticationError("Unauthorized", "unauthorized", "req_1")
        assert err.status_code == 401
        assert isinstance(err, APIError)


class TestForbiddenError:
    def test_status_403(self) -> None:
        err = ForbiddenError("Forbidden", "forbidden", "req_1")
        assert err.status_code == 403


class TestNotFoundError:
    def test_status_404(self) -> None:
        err = NotFoundError("Not found", "not_found", "req_1")
        assert err.status_code == 404


class TestRateLimitError:
    def test_rate_limit_metadata(self) -> None:
        err = RateLimitError("Too many requests", "rate_limit", "req_1", 30, 100, 0)
        assert err.status_code == 429
        assert err.retry_after == 30
        assert err.limit == 100
        assert err.remaining == 0
        assert isinstance(err, APIError)


class TestInternalError:
    def test_status_5xx(self) -> None:
        err = InternalError("Server error", 502, "bad_gateway", "req_1")
        assert err.status_code == 502
        assert isinstance(err, APIError)
