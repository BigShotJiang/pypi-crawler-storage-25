"""Test data factories with sensible defaults."""

from __future__ import annotations

from typing import Any


def make_email_response(**overrides: Any) -> dict[str, Any]:
    """Build a full email API response dict with sensible defaults."""
    base: dict[str, Any] = {
        "id": "email_123",
        "message_id": None,
        "from_address": "sender@example.com",
        "to_addresses": ["recipient@example.com"],
        "subject": "Test Subject",
        "status": "delivered",
        "has_attachments": False,
        "created_at": "2026-01-01T00:00:00Z",
        "delivered_at": None,
        "organization_id": 1,
        "api_key_id": 1,
        "cc_addresses": [],
        "bcc_addresses": [],
        "reply_to": None,
        "track_opens": False,
        "track_clicks": False,
        "tags": None,
        "s3_content_bucket": None,
        "s3_content_key": None,
        "recipients": [],
        "events": [],
    }
    return {**base, **overrides}


def make_email_summary(**overrides: Any) -> dict[str, Any]:
    """Build an email summary API response dict with sensible defaults."""
    base: dict[str, Any] = {
        "id": "email_123",
        "message_id": None,
        "from_address": "sender@example.com",
        "to_addresses": ["recipient@example.com"],
        "subject": "Test Subject",
        "status": "delivered",
        "has_attachments": False,
        "created_at": "2026-01-01T00:00:00Z",
        "delivered_at": None,
    }
    return {**base, **overrides}


def make_send_response(**overrides: Any) -> dict[str, Any]:
    """Build a send email API response dict with sensible defaults."""
    base: dict[str, Any] = {
        "id": "email_123",
        "status": "queued",
        "created_at": "2026-01-01T00:00:00Z",
    }
    return {**base, **overrides}


def make_suppression_entry(**overrides: Any) -> dict[str, Any]:
    """Build a suppression entry API response dict with sensible defaults."""
    base: dict[str, Any] = {
        "id": 1,
        "email_address": "bounce@example.com",
        "reason": "hard_bounce",
        "created_at": "2026-01-01T00:00:00Z",
    }
    return {**base, **overrides}
