from __future__ import annotations

import json

import httpx
import pytest
import respx

from senddy._types import CreateSuppressionParams, ListSuppressionsParams
from senddy.resources._suppressions import AsyncSuppressions, Suppressions

from ..factories import make_suppression_entry

BASE_URL = "https://api.example.com"
API_KEY = "senddy_test"


class TestSuppressions:
    @respx.mock
    def test_list(self) -> None:
        body = {
            "data": [make_suppression_entry()],
            "pagination": {"limit": 50, "offset": 0, "total": 1, "has_more": False},
        }
        route = respx.get(f"{BASE_URL}/suppression").mock(
            return_value=httpx.Response(200, json=body)
        )

        with httpx.Client(base_url=BASE_URL) as client:
            suppressions = Suppressions(client, API_KEY, 0)
            result = suppressions.list(ListSuppressionsParams(limit=50, reason="hard_bounce"))

        assert len(result.data) == 1
        assert result.data[0].email_address == "bounce@example.com"
        assert result.data[0].reason == "hard_bounce"
        url = str(route.calls[0].request.url)
        assert "reason=hard_bounce" in url

    @respx.mock
    def test_list_no_params(self) -> None:
        body = {
            "data": [],
            "pagination": {"limit": 50, "offset": 0, "total": 0, "has_more": False},
        }
        respx.get(f"{BASE_URL}/suppression").mock(
            return_value=httpx.Response(200, json=body)
        )

        with httpx.Client(base_url=BASE_URL) as client:
            suppressions = Suppressions(client, API_KEY, 0)
            result = suppressions.list()

        assert result.data == []

    @respx.mock
    def test_create(self) -> None:
        route = respx.post(f"{BASE_URL}/suppression").mock(
            return_value=httpx.Response(
                200,
                json=make_suppression_entry(
                    id=42,
                    email_address="manual@example.com",
                    reason="manual",
                ),
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            suppressions = Suppressions(client, API_KEY, 0)
            result = suppressions.create(
                CreateSuppressionParams(email_address="manual@example.com")
            )

        assert result.id == 42
        assert result.email_address == "manual@example.com"

        body = json.loads(route.calls[0].request.read())
        assert body["email_address"] == "manual@example.com"

    @respx.mock
    def test_delete(self) -> None:
        respx.delete(f"{BASE_URL}/suppression/test%40example.com").mock(
            return_value=httpx.Response(
                200,
                json={"removed": True, "email_address": "test@example.com"},
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            suppressions = Suppressions(client, API_KEY, 0)
            result = suppressions.delete("test@example.com")

        assert result.removed is True
        assert result.email_address == "test@example.com"


class TestAsyncSuppressions:
    @respx.mock
    @pytest.mark.asyncio
    async def test_list(self) -> None:
        body = {
            "data": [make_suppression_entry(email_address="x@y.com", reason="complaint")],
            "pagination": {"limit": 50, "offset": 0, "total": 1, "has_more": False},
        }
        respx.get(f"{BASE_URL}/suppression").mock(
            return_value=httpx.Response(200, json=body)
        )

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            suppressions = AsyncSuppressions(client, API_KEY, 0)
            result = await suppressions.list()

        assert len(result.data) == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_create(self) -> None:
        respx.post(f"{BASE_URL}/suppression").mock(
            return_value=httpx.Response(
                200,
                json=make_suppression_entry(
                    id=2,
                    email_address="a@b.com",
                    reason="manual",
                ),
            )
        )

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            suppressions = AsyncSuppressions(client, API_KEY, 0)
            result = await suppressions.create(
                CreateSuppressionParams(email_address="a@b.com")
            )

        assert result.email_address == "a@b.com"

    @respx.mock
    @pytest.mark.asyncio
    async def test_delete(self) -> None:
        respx.delete(f"{BASE_URL}/suppression/x%40y.com").mock(
            return_value=httpx.Response(
                200,
                json={"removed": True, "email_address": "x@y.com"},
            )
        )

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            suppressions = AsyncSuppressions(client, API_KEY, 0)
            result = await suppressions.delete("x@y.com")

        assert result.removed is True
