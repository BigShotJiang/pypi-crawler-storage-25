from __future__ import annotations

import json

import httpx
import pytest
import respx

from senddy._types import (
    EmailDownloadResponse,
    ListEmailsParams,
    RequestOptions,
    SendEmailParams,
)
from senddy.resources._emails import AsyncEmails, Emails

from ..factories import make_email_response, make_email_summary, make_send_response

BASE_URL = "https://api.example.com"
API_KEY = "senddy_test"


class TestEmails:
    @respx.mock
    def test_send_posts_to_emails(self) -> None:
        route = respx.post(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(202, json=make_send_response())
        )

        with httpx.Client(base_url=BASE_URL) as client:
            emails = Emails(client, API_KEY, 0)
            result = emails.send(
                SendEmailParams(
                    from_="sender@example.com",
                    to="recipient@example.com",
                    subject="Test",
                    html="<p>Hello</p>",
                )
            )

        assert result.id == "email_123"
        assert result.status == "queued"
        body = route.calls[0].request.read()
        parsed = json.loads(body)
        assert parsed["from"] == "sender@example.com"
        assert parsed["to"] == "recipient@example.com"
        assert "from_" not in parsed

    @respx.mock
    def test_send_with_idempotency_key(self) -> None:
        route = respx.post(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(202, json=make_send_response(id="x"))
        )

        with httpx.Client(base_url=BASE_URL) as client:
            emails = Emails(client, API_KEY, 0)
            emails.send(
                SendEmailParams(from_="a@b.com", to="c@d.com", subject="X", html=""),
                options=RequestOptions(idempotency_key="idem_abc"),
            )

        assert route.calls[0].request.headers["idempotency-key"] == "idem_abc"

    @respx.mock
    def test_get_email(self) -> None:
        respx.get(f"{BASE_URL}/emails/email_123").mock(
            return_value=httpx.Response(
                200,
                json=make_email_response(delivered_at="2026-01-01T00:00:01Z"),
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            emails = Emails(client, API_KEY, 0)
            result = emails.get("email_123")

        assert result.id == "email_123"
        assert result.status == "delivered"

    @respx.mock
    def test_get_encodes_id(self) -> None:
        respx.get(f"{BASE_URL}/emails/id%20with%20spaces").mock(
            return_value=httpx.Response(
                200,
                json=make_email_response(
                    id="id with spaces",
                    to_addresses=[],
                    subject="",
                    status="queued",
                    created_at="",
                ),
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            emails = Emails(client, API_KEY, 0)
            result = emails.get("id with spaces")

        assert result.id == "id with spaces"

    @respx.mock
    def test_list_with_params(self) -> None:
        body = {
            "data": [make_email_summary(id="1", subject="Hi")],
            "pagination": {"limit": 25, "offset": 0, "total": 1, "has_more": False},
        }
        route = respx.get(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(200, json=body)
        )

        with httpx.Client(base_url=BASE_URL) as client:
            emails = Emails(client, API_KEY, 0)
            result = emails.list(ListEmailsParams(limit=25, status="delivered"))

        assert len(result.data) == 1
        assert result.pagination.total == 1
        url = str(route.calls[0].request.url)
        assert "limit=25" in url
        assert "status=delivered" in url

    @respx.mock
    def test_list_no_params(self) -> None:
        body = {
            "data": [],
            "pagination": {"limit": 50, "offset": 0, "total": 0, "has_more": False},
        }
        respx.get(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(200, json=body)
        )

        with httpx.Client(base_url=BASE_URL) as client:
            emails = Emails(client, API_KEY, 0)
            result = emails.list()

        assert result.data == []

    @respx.mock
    def test_download_returns_bytes(self) -> None:
        eml_content = b"From: test@example.com\r\nSubject: Test\r\n\r\nBody"
        respx.get(f"{BASE_URL}/emails/email_123/eml").mock(
            return_value=httpx.Response(
                200,
                content=eml_content,
                headers={"content-type": "message/rfc822"},
            )
        )

        with httpx.Client(base_url=BASE_URL) as client:
            emails = Emails(client, API_KEY, 0)
            result = emails.download("email_123")

        assert isinstance(result, EmailDownloadResponse)
        assert result.content == eml_content
        assert result.content_type == "message/rfc822"


class TestAsyncEmails:
    @respx.mock
    @pytest.mark.asyncio
    async def test_send(self) -> None:
        respx.post(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(
                202, json=make_send_response(id="email_async")
            )
        )

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            emails = AsyncEmails(client, API_KEY, 0)
            result = await emails.send(
                SendEmailParams(from_="a@b.com", to="c@d.com", subject="Async", html="<p>hi</p>")
            )

        assert result.id == "email_async"

    @respx.mock
    @pytest.mark.asyncio
    async def test_list(self) -> None:
        body = {
            "data": [],
            "pagination": {"limit": 50, "offset": 0, "total": 0, "has_more": False},
        }
        respx.get(f"{BASE_URL}/emails").mock(
            return_value=httpx.Response(200, json=body)
        )

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            emails = AsyncEmails(client, API_KEY, 0)
            result = await emails.list()

        assert result.data == []

    @respx.mock
    @pytest.mark.asyncio
    async def test_download(self) -> None:
        eml = b"From: x@y.com\r\nSubject: T\r\n\r\nB"
        respx.get(f"{BASE_URL}/emails/e1/eml").mock(
            return_value=httpx.Response(
                200, content=eml, headers={"content-type": "message/rfc822"}
            )
        )

        async with httpx.AsyncClient(base_url=BASE_URL) as client:
            emails = AsyncEmails(client, API_KEY, 0)
            result = await emails.download("e1")

        assert result.content == eml
