from __future__ import annotations

import asyncio
import math
import os
import random
import time
from email.utils import parsedate_to_datetime
from typing import TYPE_CHECKING, Any, Optional

import httpx

from ._errors import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InternalError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)

if TYPE_CHECKING:
    from ._types import RequestOptions

DEFAULT_BASE_URL = os.environ.get("SENDDY_BASE_URL", "https://senddy.io/api")
DEFAULT_TIMEOUT = 30.0
DEFAULT_RETRIES = 2
MAX_BACKOFF = 60.0


def _parse_retry_after(header: Optional[str]) -> int:
    if not header:
        return 0
    try:
        return int(header)
    except ValueError:
        pass
    try:
        dt = parsedate_to_datetime(header)
        return max(0, math.ceil((dt.timestamp() - time.time())))
    except Exception:
        return 0


def _safe_int_header(value: Optional[str], default: int = 0) -> int:
    if not value:
        return default
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def _is_retryable(status_code: int) -> bool:
    return status_code == 429 or status_code >= 500


def _map_response_to_error(response: httpx.Response, request_id: str) -> APIError:
    try:
        body = response.json()
    except Exception:
        body = {"error": "unknown", "message": response.reason_phrase}

    message = str(body.get("message") or body.get("error") or response.reason_phrase)
    code = str(body.get("error", "unknown"))

    status = response.status_code
    if status == 400:
        raw_details = body.get("details")
        details: list[dict[str, str]] = raw_details if isinstance(raw_details, list) else []
        return ValidationError(message, code, request_id, details)
    if status == 401:
        return AuthenticationError(message, code, request_id)
    if status == 403:
        return ForbiddenError(message, code, request_id)
    if status == 404:
        return NotFoundError(message, code, request_id)
    if status == 429:
        retry_after = _parse_retry_after(response.headers.get("retry-after"))
        limit = _safe_int_header(response.headers.get("x-ratelimit-limit"))
        remaining = _safe_int_header(response.headers.get("x-ratelimit-remaining"))
        return RateLimitError(message, code, request_id, retry_after, limit, remaining)
    if status >= 500:
        return InternalError(message, status, code, request_id)
    return APIError(message, status, code, request_id)


def _compute_backoff(attempt: int, last_error: Optional[APIError]) -> float:
    retry_after_secs: float = (
        float(last_error.retry_after) if isinstance(last_error, RateLimitError) else 0.0
    )
    backoff: float = max(retry_after_secs, 0.5 * (2**attempt))
    jitter: float = random.random() * 0.2  # noqa: S311
    return min(backoff + jitter, MAX_BACKOFF)


def _build_query(query: Optional[dict[str, Any]]) -> Optional[dict[str, str]]:
    if not query:
        return None
    return {k: str(v) for k, v in query.items() if v is not None}


def build_request_opts(options: Optional[RequestOptions]) -> dict[str, Any]:
    """Convert a RequestOptions dataclass to kwargs for http_request/async_http_request."""
    if options is None:
        return {}
    d: dict[str, Any] = {}
    if options.idempotency_key is not None:
        d["idempotency_key"] = options.idempotency_key
    if options.headers is not None:
        d["extra_headers"] = options.headers
    if options.timeout is not None:
        d["timeout"] = options.timeout
    return d


# --- Sync HTTP ---


def http_request(
    client: httpx.Client,
    method: str,
    path: str,
    *,
    api_key: str,
    retries: int = DEFAULT_RETRIES,
    body: Optional[dict[str, Any]] = None,
    query: Optional[dict[str, Any]] = None,
    extra_headers: Optional[dict[str, str]] = None,
    idempotency_key: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Any:
    headers: dict[str, str] = {"Authorization": f"Bearer {api_key}"}
    if extra_headers:
        headers.update(extra_headers)
    if idempotency_key and method == "POST":
        headers["Idempotency-Key"] = idempotency_key

    params = _build_query(query)
    last_error: Optional[APIError] = None

    for attempt in range(retries + 1):
        try:
            response = client.request(
                method,
                path,
                json=body,
                params=params,
                headers=headers,
                timeout=timeout,
            )
        except httpx.TimeoutException as exc:
            last_error = APIError(str(exc), 0, "timeout", "")
            if attempt < retries:
                time.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc
        except httpx.HTTPError as exc:
            last_error = APIError(str(exc), 0, "network_error", "")
            if attempt < retries:
                time.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc

        if response.is_success:
            if response.status_code == 204:
                return None
            return response.json()

        request_id = response.headers.get("x-request-id", "")
        error = _map_response_to_error(response, request_id)

        if not _is_retryable(response.status_code):
            raise error

        last_error = error
        if attempt < retries:
            time.sleep(_compute_backoff(attempt, last_error))

    if last_error is None:
        raise RuntimeError("Retry loop exited without error — this is a bug")
    raise last_error


def http_request_raw(
    client: httpx.Client,
    method: str,
    path: str,
    *,
    api_key: str,
    retries: int = DEFAULT_RETRIES,
    extra_headers: Optional[dict[str, str]] = None,
    timeout: Optional[float] = None,
) -> tuple[bytes, str]:
    headers: dict[str, str] = {"Authorization": f"Bearer {api_key}"}
    if extra_headers:
        headers.update(extra_headers)

    last_error: Optional[APIError] = None

    for attempt in range(retries + 1):
        try:
            response = client.request(
                method,
                path,
                headers=headers,
                timeout=timeout,
            )
        except httpx.TimeoutException as exc:
            last_error = APIError(str(exc), 0, "timeout", "")
            if attempt < retries:
                time.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc
        except httpx.HTTPError as exc:
            last_error = APIError(str(exc), 0, "network_error", "")
            if attempt < retries:
                time.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc

        if response.is_success:
            content_type = response.headers.get("content-type", "application/octet-stream")
            return response.content, content_type

        request_id = response.headers.get("x-request-id", "")
        error = _map_response_to_error(response, request_id)

        if not _is_retryable(response.status_code):
            raise error

        last_error = error
        if attempt < retries:
            time.sleep(_compute_backoff(attempt, last_error))

    if last_error is None:
        raise RuntimeError("Retry loop exited without error — this is a bug")
    raise last_error


# --- Async HTTP ---


async def async_http_request(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    *,
    api_key: str,
    retries: int = DEFAULT_RETRIES,
    body: Optional[dict[str, Any]] = None,
    query: Optional[dict[str, Any]] = None,
    extra_headers: Optional[dict[str, str]] = None,
    idempotency_key: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Any:
    headers: dict[str, str] = {"Authorization": f"Bearer {api_key}"}
    if extra_headers:
        headers.update(extra_headers)
    if idempotency_key and method == "POST":
        headers["Idempotency-Key"] = idempotency_key

    params = _build_query(query)
    last_error: Optional[APIError] = None

    for attempt in range(retries + 1):
        try:
            response = await client.request(
                method,
                path,
                json=body,
                params=params,
                headers=headers,
                timeout=timeout,
            )
        except httpx.TimeoutException as exc:
            last_error = APIError(str(exc), 0, "timeout", "")
            if attempt < retries:
                await asyncio.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc
        except httpx.HTTPError as exc:
            last_error = APIError(str(exc), 0, "network_error", "")
            if attempt < retries:
                await asyncio.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc

        if response.is_success:
            if response.status_code == 204:
                return None
            return response.json()

        request_id = response.headers.get("x-request-id", "")
        error = _map_response_to_error(response, request_id)

        if not _is_retryable(response.status_code):
            raise error

        last_error = error
        if attempt < retries:
            await asyncio.sleep(_compute_backoff(attempt, last_error))

    if last_error is None:
        raise RuntimeError("Retry loop exited without error — this is a bug")
    raise last_error


async def async_http_request_raw(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    *,
    api_key: str,
    retries: int = DEFAULT_RETRIES,
    extra_headers: Optional[dict[str, str]] = None,
    timeout: Optional[float] = None,
) -> tuple[bytes, str]:
    headers: dict[str, str] = {"Authorization": f"Bearer {api_key}"}
    if extra_headers:
        headers.update(extra_headers)

    last_error: Optional[APIError] = None

    for attempt in range(retries + 1):
        try:
            response = await client.request(
                method,
                path,
                headers=headers,
                timeout=timeout,
            )
        except httpx.TimeoutException as exc:
            last_error = APIError(str(exc), 0, "timeout", "")
            if attempt < retries:
                await asyncio.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc
        except httpx.HTTPError as exc:
            last_error = APIError(str(exc), 0, "network_error", "")
            if attempt < retries:
                await asyncio.sleep(_compute_backoff(attempt, last_error))
                continue
            raise last_error from exc

        if response.is_success:
            content_type = response.headers.get("content-type", "application/octet-stream")
            return response.content, content_type

        request_id = response.headers.get("x-request-id", "")
        error = _map_response_to_error(response, request_id)

        if not _is_retryable(response.status_code):
            raise error

        last_error = error
        if attempt < retries:
            await asyncio.sleep(_compute_backoff(attempt, last_error))

    if last_error is None:
        raise RuntimeError("Retry loop exited without error — this is a bug")
    raise last_error
