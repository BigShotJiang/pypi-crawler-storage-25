from __future__ import annotations


class APIError(Exception):
    """Base exception for all API errors."""

    status_code: int
    code: str
    request_id: str

    def __init__(self, message: str, status_code: int, code: str, request_id: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.request_id = request_id

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(message={str(self)!r}, "
            f"status_code={self.status_code}, code={self.code!r})"
        )


class ValidationError(APIError):
    """Raised on 400 responses with field-level validation details."""

    details: list[dict[str, str]]

    def __init__(
        self,
        message: str,
        code: str,
        request_id: str,
        details: list[dict[str, str]],
    ) -> None:
        super().__init__(message, 400, code, request_id)
        self.details = details


class AuthenticationError(APIError):
    """Raised on 401 responses."""

    def __init__(self, message: str, code: str, request_id: str) -> None:
        super().__init__(message, 401, code, request_id)


class ForbiddenError(APIError):
    """Raised on 403 responses."""

    def __init__(self, message: str, code: str, request_id: str) -> None:
        super().__init__(message, 403, code, request_id)


class NotFoundError(APIError):
    """Raised on 404 responses."""

    def __init__(self, message: str, code: str, request_id: str) -> None:
        super().__init__(message, 404, code, request_id)


class RateLimitError(APIError):
    """Raised on 429 responses with rate limit metadata."""

    retry_after: int
    limit: int
    remaining: int

    def __init__(
        self,
        message: str,
        code: str,
        request_id: str,
        retry_after: int,
        limit: int,
        remaining: int,
    ) -> None:
        super().__init__(message, 429, code, request_id)
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining


class InternalError(APIError):
    """Raised on 5xx responses."""

    def __init__(self, message: str, status_code: int, code: str, request_id: str) -> None:
        super().__init__(message, status_code, code, request_id)
