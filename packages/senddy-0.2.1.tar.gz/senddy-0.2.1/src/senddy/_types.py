from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Generic, Optional, TypeVar

T = TypeVar("T")


# --- Request options ---


@dataclass
class RequestOptions:
    idempotency_key: Optional[str] = None
    headers: Optional[dict[str, str]] = None
    timeout: Optional[float] = None


# --- Pagination ---


@dataclass
class Pagination:
    limit: int
    offset: int
    total: int
    has_more: bool


@dataclass
class PaginatedResponse(Generic[T]):
    data: list[T]
    pagination: Pagination


# --- Emails ---


@dataclass
class Attachment:
    filename: str
    content: str
    content_type: Optional[str] = None


@dataclass
class SendEmailParams:
    from_: str
    to: str | list[str]
    subject: str
    html: Optional[str] = None
    text: Optional[str] = None
    cc: Optional[str | list[str]] = None
    bcc: Optional[str | list[str]] = None
    reply_to: Optional[str] = None
    attachments: Optional[list[Attachment]] = None
    headers: Optional[dict[str, str]] = None
    tags: Optional[dict[str, str]] = None
    track_opens: Optional[bool] = None
    track_clicks: Optional[bool] = None
    scheduled_at: Optional[str] = None


@dataclass
class SendEmailResponse:
    id: str
    status: str
    created_at: str
    test_mode: Optional[bool] = None
    suppressed: Optional[list[str]] = None


@dataclass
class ListEmailsParams:
    limit: Optional[int] = None
    offset: Optional[int] = None
    status: Optional[str] = None
    from_: Optional[str] = None
    to: Optional[str] = None
    recipient: Optional[str] = None
    since: Optional[str] = None
    until: Optional[str] = None


@dataclass
class EmailSummary:
    id: str
    message_id: Optional[str]
    from_address: str
    to_addresses: list[str]
    subject: str
    status: str
    has_attachments: bool
    created_at: str
    delivered_at: Optional[str]


@dataclass
class EmailRecipient:
    address: str = field(repr=False)
    type: str
    status: str
    ses_message_id: Optional[str]
    delivered_at: Optional[str]
    bounced_at: Optional[str]
    complained_at: Optional[str]


@dataclass
class EmailEvent:
    type: str
    timestamp: str
    # Event data shape varies by event type; no fixed schema.
    data: Optional[dict[str, Any]]


@dataclass
class Email:
    id: str
    message_id: Optional[str]
    from_address: str
    to_addresses: list[str]
    subject: str
    status: str
    has_attachments: bool
    created_at: str
    delivered_at: Optional[str]
    cc_addresses: list[str]
    bcc_addresses: list[str]
    reply_to: Optional[str]
    track_opens: bool
    track_clicks: bool
    tags: Optional[dict[str, str]]
    recipients: list[EmailRecipient] = field(default_factory=list)
    events: list[EmailEvent] = field(default_factory=list)


@dataclass
class EmailDownloadResponse:
    content: bytes
    content_type: str


@dataclass
class EmailContentResponse:
    html: Optional[str]
    text: Optional[str]


# --- Suppressions ---


@dataclass
class ListSuppressionsParams:
    limit: Optional[int] = None
    offset: Optional[int] = None
    search: Optional[str] = None
    reason: Optional[str] = None


@dataclass
class SuppressionEntry:
    id: int
    email_address: str = field(repr=False)
    reason: str
    created_at: str


@dataclass
class CreateSuppressionParams:
    email_address: str


@dataclass
class DeleteSuppressionResponse:
    removed: bool
    email_address: str = field(repr=False)


# --- Domains ---


@dataclass
class Domain:
    id: int
    domain: str
    status: str
    dkim_selector: str
    dkim_public_key: Optional[str]
    dkim_verified: bool
    verification_token: Optional[str]
    verified_at: Optional[str]
    last_checked_at: Optional[str]
    created_at: str


@dataclass
class CreateDomainParams:
    domain: str


@dataclass
class ListDomainsParams:
    limit: Optional[int] = None
    offset: Optional[int] = None


@dataclass
class VerifyDomainResponse:
    verified: bool
    dkim_verified: bool
    errors: list[str]


@dataclass
class DeleteDomainResponse:
    deleted: bool


@dataclass
class DnsHealthEntry:
    domain: str
    status: str
    dkim_verified: bool
    verified_at: Optional[str]


@dataclass
class DnsHealthResponse:
    data: list[DnsHealthEntry]


# --- Inbound Routes ---


@dataclass
class InboundRoute:
    id: int
    domain_id: Optional[int]
    match_pattern: str
    match_type: str
    webhook_url: str
    enabled: bool
    generated_address: Optional[str]
    priority: int
    created_at: str
    updated_at: Optional[str]


@dataclass
class InboundRouteDetail(InboundRoute):
    secret: str = ""


@dataclass
class ListInboundRoutesParams:
    limit: Optional[int] = None
    offset: Optional[int] = None


@dataclass
class CreateInboundRouteParams:
    webhook_url: str
    match_type: str
    domain_id: Optional[int] = None
    match_pattern: Optional[str] = None


@dataclass
class CreateInboundRouteResponse:
    id: int
    match_pattern: str
    match_type: str
    webhook_url: Optional[str]
    secret: str
    enabled: bool
    generated_address: Optional[str]
    created_at: str


@dataclass
class UpdateInboundRouteParams:
    webhook_url: Optional[str] = None
    match_pattern: Optional[str] = None
    enabled: Optional[bool] = None


@dataclass
class UpdateInboundRouteResponse:
    id: int
    match_pattern: str
    match_type: str
    webhook_url: Optional[str]
    enabled: bool
    generated_address: Optional[str]
    priority: int
    updated_at: Optional[str]


@dataclass
class DeleteInboundRouteResponse:
    id: int
    deleted: bool


@dataclass
class VerifyMxResponse:
    domain: str
    verified: bool
    expected_mx: str
    actual_records: list[dict[str, Any]]
    error: Optional[str] = None


# --- Inbound Emails ---


@dataclass
class InboundEmailSummary:
    id: str
    route_id: int
    from_address: str
    to_addresses: list[str]
    subject: str
    spam_verdict: str
    virus_verdict: str
    webhook_status: str
    webhook_attempts: int
    received_at: str
    expires_at: str


@dataclass
class InboundEmail(InboundEmailSummary):
    cc_addresses: list[str] = field(default_factory=list)
    text_body: Optional[str] = None
    html_body: Optional[str] = None
    headers: Optional[dict[str, str]] = None
    attachments: Optional[list[dict[str, Any]]] = None
    webhook_last_attempt_at: Optional[str] = None


@dataclass
class ListInboundEmailsParams:
    limit: Optional[int] = None
    offset: Optional[int] = None
    route_id: Optional[int] = None
    from_: Optional[str] = None
    to: Optional[str] = None


# --- Webhook Endpoints ---


@dataclass
class WebhookEndpoint:
    id: int
    domain: str
    event_type: str
    url: str
    description: Optional[str]
    is_active: bool
    created_at: str
    updated_at: Optional[str]


@dataclass
class CreateWebhookEndpointParams:
    url: str
    domain: str
    event_type: str
    description: Optional[str] = None


@dataclass
class CreateWebhookEndpointResponse(WebhookEndpoint):
    secret: str = ""


@dataclass
class UpdateWebhookEndpointParams:
    url: Optional[str] = None
    description: Optional[str] = None


@dataclass
class DeleteWebhookEndpointResponse:
    id: int
    deleted: bool


@dataclass
class TestWebhookResponse:
    success: bool
    delivery_id: int


@dataclass
class WebhookDelivery:
    id: int
    event_type: str
    response_status: Optional[int]
    attempt: int
    status: str
    created_at: str


@dataclass
class ListWebhookEndpointsParams:
    limit: Optional[int] = None
    offset: Optional[int] = None


# --- Billing ---


@dataclass
class BillingBalance:
    billing_tier: str
    credit_balance: int
    lifetime_send_count: int
    inbound_email_count: int
    auto_refill_enabled: bool
    auto_refill_threshold: Optional[int]
    auto_refill_amount_cents: Optional[int]
    credits_expire_at: Optional[str]
