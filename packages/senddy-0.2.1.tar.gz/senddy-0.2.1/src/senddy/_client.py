from __future__ import annotations

import os
import warnings
from types import TracebackType
from typing import Optional

import httpx

from ._errors import AuthenticationError
from ._http import DEFAULT_BASE_URL, DEFAULT_RETRIES, DEFAULT_TIMEOUT
from .resources._billing import AsyncBilling, Billing
from .resources._domains import AsyncDomains, Domains
from .resources._emails import AsyncEmails, Emails
from .resources._inbound_emails import AsyncInboundEmails, InboundEmails
from .resources._inbound_routes import AsyncInboundRoutes, InboundRoutes
from .resources._suppressions import AsyncSuppressions, Suppressions
from .resources._webhook_endpoints import AsyncWebhookEndpoints, WebhookEndpoints

ENV_VAR_NAME = "SENDDY_API_KEY"


def _resolve_api_key(api_key: Optional[str]) -> str:
    if api_key is not None:
        if not api_key.strip():
            raise AuthenticationError(
                "API key must not be blank.",
                "missing_api_key",
                "",
            )
        return api_key

    env_key = os.environ.get(ENV_VAR_NAME, "").strip()
    if env_key:
        warnings.warn(
            f"Using API key from {ENV_VAR_NAME} environment variable. "
            "Pass the key explicitly to suppress this warning.",
            stacklevel=3,
        )
        return env_key

    raise AuthenticationError(
        f"API key is required. Pass it to the constructor or set the {ENV_VAR_NAME} "
        "environment variable.",
        "missing_api_key",
        "",
    )


class Senddy:
    """Synchronous client for the Senddy.io API."""

    billing: Billing
    domains: Domains
    emails: Emails
    inbound_emails: InboundEmails
    inbound_routes: InboundRoutes
    suppressions: Suppressions
    webhook_endpoints: WebhookEndpoints

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
        headers: Optional[dict[str, str]] = None,
    ) -> None:
        resolved_key = _resolve_api_key(api_key)

        self._http_client = httpx.Client(
            base_url=DEFAULT_BASE_URL,
            timeout=timeout,
            headers=headers,
        )
        self._api_key = resolved_key
        self._retries = retries

        self.billing = Billing(self._http_client, resolved_key, retries)
        self.domains = Domains(self._http_client, resolved_key, retries)
        self.emails = Emails(self._http_client, resolved_key, retries)
        self.inbound_emails = InboundEmails(self._http_client, resolved_key, retries)
        self.inbound_routes = InboundRoutes(self._http_client, resolved_key, retries)
        self.suppressions = Suppressions(self._http_client, resolved_key, retries)
        self.webhook_endpoints = WebhookEndpoints(self._http_client, resolved_key, retries)

    def close(self) -> None:
        self._http_client.close()

    def __enter__(self) -> Senddy:
        return self

    def __exit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        self.close()


class AsyncSenddy:
    """Asynchronous client for the Senddy.io API."""

    billing: AsyncBilling
    domains: AsyncDomains
    emails: AsyncEmails
    inbound_emails: AsyncInboundEmails
    inbound_routes: AsyncInboundRoutes
    suppressions: AsyncSuppressions
    webhook_endpoints: AsyncWebhookEndpoints

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
        headers: Optional[dict[str, str]] = None,
    ) -> None:
        resolved_key = _resolve_api_key(api_key)

        self._http_client = httpx.AsyncClient(
            base_url=DEFAULT_BASE_URL,
            timeout=timeout,
            headers=headers,
        )
        self._api_key = resolved_key
        self._retries = retries

        self.billing = AsyncBilling(self._http_client, resolved_key, retries)
        self.domains = AsyncDomains(self._http_client, resolved_key, retries)
        self.emails = AsyncEmails(self._http_client, resolved_key, retries)
        self.inbound_emails = AsyncInboundEmails(self._http_client, resolved_key, retries)
        self.inbound_routes = AsyncInboundRoutes(self._http_client, resolved_key, retries)
        self.suppressions = AsyncSuppressions(self._http_client, resolved_key, retries)
        self.webhook_endpoints = AsyncWebhookEndpoints(self._http_client, resolved_key, retries)

    async def close(self) -> None:
        await self._http_client.aclose()

    async def __aenter__(self) -> AsyncSenddy:
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        await self.close()
