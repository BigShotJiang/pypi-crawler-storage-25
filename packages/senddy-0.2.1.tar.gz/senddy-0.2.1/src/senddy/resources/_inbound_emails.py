from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

import httpx

from .._http import async_http_request, build_request_opts, http_request
from .._types import (
    InboundEmail,
    InboundEmailSummary,
    ListInboundEmailsParams,
    PaginatedResponse,
    Pagination,
    RequestOptions,
)


def _serialize_list_params(params: Optional[ListInboundEmailsParams]) -> Optional[dict[str, Any]]:
    if params is None:
        return None
    d: dict[str, Any] = {}
    if params.limit is not None:
        d["limit"] = params.limit
    if params.offset is not None:
        d["offset"] = params.offset
    if params.route_id is not None:
        d["route_id"] = params.route_id
    if params.from_ is not None:
        d["from"] = params.from_
    if params.to is not None:
        d["to"] = params.to
    return d or None


def _parse_summary(data: Any) -> InboundEmailSummary:
    return InboundEmailSummary(
        id=data["id"], route_id=data["route_id"],
        from_address=data["from_address"], to_addresses=data["to_addresses"],
        subject=data["subject"], spam_verdict=data["spam_verdict"],
        virus_verdict=data["virus_verdict"], webhook_status=data["webhook_status"],
        webhook_attempts=data["webhook_attempts"],
        received_at=data["received_at"], expires_at=data["expires_at"],
    )


def _parse_email(data: Any) -> InboundEmail:
    return InboundEmail(
        id=data["id"], route_id=data["route_id"],
        from_address=data["from_address"], to_addresses=data["to_addresses"],
        subject=data["subject"], spam_verdict=data["spam_verdict"],
        virus_verdict=data["virus_verdict"], webhook_status=data["webhook_status"],
        webhook_attempts=data["webhook_attempts"],
        received_at=data["received_at"], expires_at=data["expires_at"],
        cc_addresses=data.get("cc_addresses", []),
        text_body=data.get("text_body"), html_body=data.get("html_body"),
        headers=data.get("headers"), attachments=data.get("attachments"),
        webhook_last_attempt_at=data.get("webhook_last_attempt_at"),
    )


class InboundEmails:
    """Synchronous inbound emails resource."""

    def __init__(self, client: httpx.Client, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    def list(
        self, params: Optional[ListInboundEmailsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[InboundEmailSummary]:
        query = _serialize_list_params(params)
        data = http_request(
            self._client, "GET", "/inbound-emails",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_summary(e) for e in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )

    def get(self, id: str, options: Optional[RequestOptions] = None) -> InboundEmail:
        data = http_request(
            self._client, "GET", f"/inbound-emails/{quote(id, safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_email(data)


class AsyncInboundEmails:
    """Asynchronous inbound emails resource."""

    def __init__(self, client: httpx.AsyncClient, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    async def list(
        self, params: Optional[ListInboundEmailsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[InboundEmailSummary]:
        query = _serialize_list_params(params)
        data = await async_http_request(
            self._client, "GET", "/inbound-emails",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_summary(e) for e in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )

    async def get(self, id: str, options: Optional[RequestOptions] = None) -> InboundEmail:
        data = await async_http_request(
            self._client, "GET", f"/inbound-emails/{quote(id, safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_email(data)
