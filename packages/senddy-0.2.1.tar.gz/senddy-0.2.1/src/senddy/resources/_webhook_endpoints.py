from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

import httpx

from .._http import async_http_request, build_request_opts, http_request
from .._types import (
    CreateWebhookEndpointParams,
    CreateWebhookEndpointResponse,
    DeleteWebhookEndpointResponse,
    ListWebhookEndpointsParams,
    PaginatedResponse,
    Pagination,
    RequestOptions,
    TestWebhookResponse,
    UpdateWebhookEndpointParams,
    WebhookDelivery,
    WebhookEndpoint,
)


def _serialize_list_params(params: Optional[ListWebhookEndpointsParams]) -> Optional[dict[str, Any]]:
    if params is None:
        return None
    d: dict[str, Any] = {}
    if params.limit is not None:
        d["limit"] = params.limit
    if params.offset is not None:
        d["offset"] = params.offset
    return d or None


def _parse_endpoint(data: Any) -> WebhookEndpoint:
    return WebhookEndpoint(
        id=data["id"], domain=data["domain"], event_type=data["event_type"],
        url=data["url"], description=data.get("description"),
        is_active=data["is_active"], created_at=data["created_at"],
        updated_at=data.get("updated_at"),
    )


def _parse_delivery(data: Any) -> WebhookDelivery:
    return WebhookDelivery(
        id=data["id"], event_type=data["event_type"],
        response_status=data.get("response_status"), attempt=data["attempt"],
        status=data["status"], created_at=data["created_at"],
    )


class WebhookEndpoints:
    """Synchronous webhook endpoints resource."""

    def __init__(self, client: httpx.Client, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    def list(
        self, params: Optional[ListWebhookEndpointsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[WebhookEndpoint]:
        query = _serialize_list_params(params)
        data = http_request(
            self._client, "GET", "/webhook-endpoints",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_endpoint(w) for w in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )

    def create(
        self, params: CreateWebhookEndpointParams, options: Optional[RequestOptions] = None,
    ) -> CreateWebhookEndpointResponse:
        body: dict[str, Any] = {
            "url": params.url, "domain": params.domain, "event_type": params.event_type,
        }
        if params.description is not None:
            body["description"] = params.description
        data = http_request(
            self._client, "POST", "/webhook-endpoints",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return CreateWebhookEndpointResponse(
            id=data["id"], domain=data["domain"], event_type=data["event_type"],
            url=data["url"], description=data.get("description"),
            is_active=data["is_active"], created_at=data["created_at"],
            updated_at=data.get("updated_at"), secret=data.get("secret", ""),
        )

    def update(
        self, id: int, params: UpdateWebhookEndpointParams,
        options: Optional[RequestOptions] = None,
    ) -> WebhookEndpoint:
        body: dict[str, Any] = {}
        if params.url is not None:
            body["url"] = params.url
        if params.description is not None:
            body["description"] = params.description
        data = http_request(
            self._client, "PUT", f"/webhook-endpoints/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return _parse_endpoint(data)

    def delete(self, id: int, options: Optional[RequestOptions] = None) -> DeleteWebhookEndpointResponse:
        data = http_request(
            self._client, "DELETE", f"/webhook-endpoints/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DeleteWebhookEndpointResponse(id=data["id"], deleted=data["deleted"])

    def test(self, id: int, options: Optional[RequestOptions] = None) -> TestWebhookResponse:
        data = http_request(
            self._client, "POST", f"/webhook-endpoints/{quote(str(id), safe='')}/test",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return TestWebhookResponse(success=data["success"], delivery_id=data["delivery_id"])

    def deliveries(
        self, id: int, params: Optional[ListWebhookEndpointsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[WebhookDelivery]:
        query = _serialize_list_params(params)
        data = http_request(
            self._client, "GET", f"/webhook-endpoints/{quote(str(id), safe='')}/deliveries",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_delivery(d) for d in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )


class AsyncWebhookEndpoints:
    """Asynchronous webhook endpoints resource."""

    def __init__(self, client: httpx.AsyncClient, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    async def list(
        self, params: Optional[ListWebhookEndpointsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[WebhookEndpoint]:
        query = _serialize_list_params(params)
        data = await async_http_request(
            self._client, "GET", "/webhook-endpoints",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_endpoint(w) for w in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )

    async def create(
        self, params: CreateWebhookEndpointParams, options: Optional[RequestOptions] = None,
    ) -> CreateWebhookEndpointResponse:
        body: dict[str, Any] = {
            "url": params.url, "domain": params.domain, "event_type": params.event_type,
        }
        if params.description is not None:
            body["description"] = params.description
        data = await async_http_request(
            self._client, "POST", "/webhook-endpoints",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return CreateWebhookEndpointResponse(
            id=data["id"], domain=data["domain"], event_type=data["event_type"],
            url=data["url"], description=data.get("description"),
            is_active=data["is_active"], created_at=data["created_at"],
            updated_at=data.get("updated_at"), secret=data.get("secret", ""),
        )

    async def update(
        self, id: int, params: UpdateWebhookEndpointParams,
        options: Optional[RequestOptions] = None,
    ) -> WebhookEndpoint:
        body: dict[str, Any] = {}
        if params.url is not None:
            body["url"] = params.url
        if params.description is not None:
            body["description"] = params.description
        data = await async_http_request(
            self._client, "PUT", f"/webhook-endpoints/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return _parse_endpoint(data)

    async def delete(self, id: int, options: Optional[RequestOptions] = None) -> DeleteWebhookEndpointResponse:
        data = await async_http_request(
            self._client, "DELETE", f"/webhook-endpoints/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DeleteWebhookEndpointResponse(id=data["id"], deleted=data["deleted"])

    async def test(self, id: int, options: Optional[RequestOptions] = None) -> TestWebhookResponse:
        data = await async_http_request(
            self._client, "POST", f"/webhook-endpoints/{quote(str(id), safe='')}/test",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return TestWebhookResponse(success=data["success"], delivery_id=data["delivery_id"])

    async def deliveries(
        self, id: int, params: Optional[ListWebhookEndpointsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[WebhookDelivery]:
        query = _serialize_list_params(params)
        data = await async_http_request(
            self._client, "GET", f"/webhook-endpoints/{quote(str(id), safe='')}/deliveries",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_delivery(d) for d in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )
