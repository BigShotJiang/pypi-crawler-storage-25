from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

import httpx

from .._http import async_http_request, build_request_opts, http_request
from .._types import (
    CreateInboundRouteParams,
    CreateInboundRouteResponse,
    DeleteInboundRouteResponse,
    InboundRoute,
    InboundRouteDetail,
    ListInboundRoutesParams,
    PaginatedResponse,
    Pagination,
    RequestOptions,
    UpdateInboundRouteParams,
    UpdateInboundRouteResponse,
    VerifyMxResponse,
)


def _serialize_list_params(params: Optional[ListInboundRoutesParams]) -> Optional[dict[str, Any]]:
    if params is None:
        return None
    d: dict[str, Any] = {}
    if params.limit is not None:
        d["limit"] = params.limit
    if params.offset is not None:
        d["offset"] = params.offset
    return d or None


def _parse_route(data: Any) -> InboundRoute:
    return InboundRoute(
        id=data["id"], domain_id=data.get("domain_id"),
        match_pattern=data["match_pattern"], match_type=data["match_type"],
        webhook_url=data["webhook_url"], enabled=data["enabled"],
        generated_address=data.get("generated_address"), priority=data.get("priority", 0),
        created_at=data["created_at"], updated_at=data.get("updated_at"),
    )


def _parse_route_detail(data: Any) -> InboundRouteDetail:
    return InboundRouteDetail(
        id=data["id"], domain_id=data.get("domain_id"),
        match_pattern=data["match_pattern"], match_type=data["match_type"],
        webhook_url=data["webhook_url"], enabled=data["enabled"],
        generated_address=data.get("generated_address"), priority=data.get("priority", 0),
        created_at=data["created_at"], updated_at=data.get("updated_at"),
        secret=data.get("secret", ""),
    )


class InboundRoutes:
    """Synchronous inbound routes resource."""

    def __init__(self, client: httpx.Client, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    def list(
        self, params: Optional[ListInboundRoutesParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[InboundRoute]:
        query = _serialize_list_params(params)
        data = http_request(
            self._client, "GET", "/inbound-routes",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_route(r) for r in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )

    def get(self, id: int, options: Optional[RequestOptions] = None) -> InboundRouteDetail:
        data = http_request(
            self._client, "GET", f"/inbound-routes/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_route_detail(data)

    def create(
        self, params: CreateInboundRouteParams, options: Optional[RequestOptions] = None,
    ) -> CreateInboundRouteResponse:
        body: dict[str, Any] = {"webhook_url": params.webhook_url, "match_type": params.match_type}
        if params.domain_id is not None:
            body["domain_id"] = params.domain_id
        if params.match_pattern is not None:
            body["match_pattern"] = params.match_pattern
        data = http_request(
            self._client, "POST", "/inbound-routes",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return CreateInboundRouteResponse(
            id=data["id"], match_pattern=data["match_pattern"], match_type=data["match_type"],
            webhook_url=data.get("webhook_url"), secret=data["secret"],
            enabled=data["enabled"], generated_address=data.get("generated_address"),
            created_at=data["created_at"],
        )

    def update(
        self, id: int, params: UpdateInboundRouteParams,
        options: Optional[RequestOptions] = None,
    ) -> UpdateInboundRouteResponse:
        body: dict[str, Any] = {}
        if params.webhook_url is not None:
            body["webhook_url"] = params.webhook_url
        if params.match_pattern is not None:
            body["match_pattern"] = params.match_pattern
        if params.enabled is not None:
            body["enabled"] = params.enabled
        data = http_request(
            self._client, "PUT", f"/inbound-routes/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return UpdateInboundRouteResponse(
            id=data["id"], match_pattern=data["match_pattern"], match_type=data["match_type"],
            webhook_url=data.get("webhook_url"), enabled=data["enabled"],
            generated_address=data.get("generated_address"), priority=data.get("priority", 0),
            updated_at=data.get("updated_at"),
        )

    def delete(self, id: int, options: Optional[RequestOptions] = None) -> DeleteInboundRouteResponse:
        data = http_request(
            self._client, "DELETE", f"/inbound-routes/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DeleteInboundRouteResponse(id=data["id"], deleted=data["deleted"])

    def verify_mx(self, id: int, options: Optional[RequestOptions] = None) -> VerifyMxResponse:
        data = http_request(
            self._client, "POST", f"/inbound-routes/{quote(str(id), safe='')}/verify-mx",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return VerifyMxResponse(
            domain=data["domain"], verified=data["verified"],
            expected_mx=data["expected_mx"], actual_records=data.get("actual_records", []),
            error=data.get("error"),
        )


class AsyncInboundRoutes:
    """Asynchronous inbound routes resource."""

    def __init__(self, client: httpx.AsyncClient, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    async def list(
        self, params: Optional[ListInboundRoutesParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[InboundRoute]:
        query = _serialize_list_params(params)
        data = await async_http_request(
            self._client, "GET", "/inbound-routes",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        pag = data["pagination"]
        return PaginatedResponse(
            data=[_parse_route(r) for r in data["data"]],
            pagination=Pagination(limit=pag["limit"], offset=pag["offset"], total=pag["total"], has_more=pag["has_more"]),
        )

    async def get(self, id: int, options: Optional[RequestOptions] = None) -> InboundRouteDetail:
        data = await async_http_request(
            self._client, "GET", f"/inbound-routes/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_route_detail(data)

    async def create(
        self, params: CreateInboundRouteParams, options: Optional[RequestOptions] = None,
    ) -> CreateInboundRouteResponse:
        body: dict[str, Any] = {"webhook_url": params.webhook_url, "match_type": params.match_type}
        if params.domain_id is not None:
            body["domain_id"] = params.domain_id
        if params.match_pattern is not None:
            body["match_pattern"] = params.match_pattern
        data = await async_http_request(
            self._client, "POST", "/inbound-routes",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return CreateInboundRouteResponse(
            id=data["id"], match_pattern=data["match_pattern"], match_type=data["match_type"],
            webhook_url=data.get("webhook_url"), secret=data["secret"],
            enabled=data["enabled"], generated_address=data.get("generated_address"),
            created_at=data["created_at"],
        )

    async def update(
        self, id: int, params: UpdateInboundRouteParams,
        options: Optional[RequestOptions] = None,
    ) -> UpdateInboundRouteResponse:
        body: dict[str, Any] = {}
        if params.webhook_url is not None:
            body["webhook_url"] = params.webhook_url
        if params.match_pattern is not None:
            body["match_pattern"] = params.match_pattern
        if params.enabled is not None:
            body["enabled"] = params.enabled
        data = await async_http_request(
            self._client, "PUT", f"/inbound-routes/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return UpdateInboundRouteResponse(
            id=data["id"], match_pattern=data["match_pattern"], match_type=data["match_type"],
            webhook_url=data.get("webhook_url"), enabled=data["enabled"],
            generated_address=data.get("generated_address"), priority=data.get("priority", 0),
            updated_at=data.get("updated_at"),
        )

    async def delete(self, id: int, options: Optional[RequestOptions] = None) -> DeleteInboundRouteResponse:
        data = await async_http_request(
            self._client, "DELETE", f"/inbound-routes/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DeleteInboundRouteResponse(id=data["id"], deleted=data["deleted"])

    async def verify_mx(self, id: int, options: Optional[RequestOptions] = None) -> VerifyMxResponse:
        data = await async_http_request(
            self._client, "POST", f"/inbound-routes/{quote(str(id), safe='')}/verify-mx",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return VerifyMxResponse(
            domain=data["domain"], verified=data["verified"],
            expected_mx=data["expected_mx"], actual_records=data.get("actual_records", []),
            error=data.get("error"),
        )
