from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

import httpx

from .._http import async_http_request, build_request_opts, http_request
from .._types import (
    CreateSuppressionParams,
    DeleteSuppressionResponse,
    ListSuppressionsParams,
    PaginatedResponse,
    Pagination,
    RequestOptions,
    SuppressionEntry,
)


def _serialize_list_params(params: Optional[ListSuppressionsParams]) -> Optional[dict[str, Any]]:
    if params is None:
        return None
    d: dict[str, Any] = {}
    if params.limit is not None:
        d["limit"] = params.limit
    if params.offset is not None:
        d["offset"] = params.offset
    if params.search is not None:
        d["search"] = params.search
    if params.reason is not None:
        d["reason"] = params.reason
    return d or None


def _parse_entry(data: Any) -> SuppressionEntry:
    return SuppressionEntry(
        id=data["id"],
        email_address=data["email_address"],
        reason=data["reason"],
        created_at=data["created_at"],
    )


def _parse_paginated(data: Any) -> PaginatedResponse[SuppressionEntry]:
    pag = data["pagination"]
    return PaginatedResponse(
        data=[_parse_entry(e) for e in data["data"]],
        pagination=Pagination(
            limit=pag["limit"],
            offset=pag["offset"],
            total=pag["total"],
            has_more=pag["has_more"],
        ),
    )


def _parse_delete_response(data: Any) -> DeleteSuppressionResponse:
    return DeleteSuppressionResponse(
        removed=data["removed"],
        email_address=data["email_address"],
    )


class Suppressions:
    """Synchronous suppressions resource."""

    def __init__(self, client: httpx.Client, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    def list(
        self,
        params: Optional[ListSuppressionsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[SuppressionEntry]:
        query = _serialize_list_params(params)
        data = http_request(
            self._client,
            "GET",
            "/suppression",
            api_key=self._api_key,
            retries=self._retries,
            query=query,
            **build_request_opts(options),
        )
        return _parse_paginated(data)

    def create(
        self,
        params: CreateSuppressionParams,
        options: Optional[RequestOptions] = None,
    ) -> SuppressionEntry:
        data = http_request(
            self._client,
            "POST",
            "/suppression",
            api_key=self._api_key,
            retries=self._retries,
            body={"email_address": params.email_address},
            **build_request_opts(options),
        )
        return _parse_entry(data)

    def delete(
        self,
        email_address: str,
        options: Optional[RequestOptions] = None,
    ) -> DeleteSuppressionResponse:
        data = http_request(
            self._client,
            "DELETE",
            f"/suppression/{quote(email_address, safe='')}",
            api_key=self._api_key,
            retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_delete_response(data)


class AsyncSuppressions:
    """Asynchronous suppressions resource."""

    def __init__(self, client: httpx.AsyncClient, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    async def list(
        self,
        params: Optional[ListSuppressionsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[SuppressionEntry]:
        query = _serialize_list_params(params)
        data = await async_http_request(
            self._client,
            "GET",
            "/suppression",
            api_key=self._api_key,
            retries=self._retries,
            query=query,
            **build_request_opts(options),
        )
        return _parse_paginated(data)

    async def create(
        self,
        params: CreateSuppressionParams,
        options: Optional[RequestOptions] = None,
    ) -> SuppressionEntry:
        data = await async_http_request(
            self._client,
            "POST",
            "/suppression",
            api_key=self._api_key,
            retries=self._retries,
            body={"email_address": params.email_address},
            **build_request_opts(options),
        )
        return _parse_entry(data)

    async def delete(
        self,
        email_address: str,
        options: Optional[RequestOptions] = None,
    ) -> DeleteSuppressionResponse:
        data = await async_http_request(
            self._client,
            "DELETE",
            f"/suppression/{quote(email_address, safe='')}",
            api_key=self._api_key,
            retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_delete_response(data)
