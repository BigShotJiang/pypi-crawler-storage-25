from __future__ import annotations

from dataclasses import asdict
from typing import Any, Optional
from urllib.parse import quote

import httpx

from .._http import async_http_request, build_request_opts, http_request
from .._types import (
    CreateDomainParams,
    DeleteDomainResponse,
    DnsHealthEntry,
    DnsHealthResponse,
    Domain,
    ListDomainsParams,
    PaginatedResponse,
    Pagination,
    RequestOptions,
    VerifyDomainResponse,
)


def _serialize_list_params(params: Optional[ListDomainsParams]) -> Optional[dict[str, Any]]:
    if params is None:
        return None
    d: dict[str, Any] = {}
    if params.limit is not None:
        d["limit"] = params.limit
    if params.offset is not None:
        d["offset"] = params.offset
    return d or None


def _parse_domain(data: Any) -> Domain:
    return Domain(
        id=data["id"],
        domain=data["domain"],
        status=data["status"],
        dkim_selector=data["dkim_selector"],
        dkim_public_key=data.get("dkim_public_key"),
        dkim_verified=data["dkim_verified"],
        verification_token=data.get("verification_token"),
        verified_at=data.get("verified_at"),
        last_checked_at=data.get("last_checked_at"),
        created_at=data["created_at"],
    )


def _parse_paginated(data: Any) -> PaginatedResponse[Domain]:
    pag = data["pagination"]
    return PaginatedResponse(
        data=[_parse_domain(d) for d in data["data"]],
        pagination=Pagination(
            limit=pag["limit"],
            offset=pag["offset"],
            total=pag["total"],
            has_more=pag["has_more"],
        ),
    )


class Domains:
    """Synchronous domains resource."""

    def __init__(self, client: httpx.Client, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    def list(
        self,
        params: Optional[ListDomainsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[Domain]:
        query = _serialize_list_params(params)
        data = http_request(
            self._client, "GET", "/domains",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        return _parse_paginated(data)

    def get(self, id: int, options: Optional[RequestOptions] = None) -> Domain:
        data = http_request(
            self._client, "GET", f"/domains/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_domain(data)

    def create(
        self, params: CreateDomainParams, options: Optional[RequestOptions] = None,
    ) -> Domain:
        body = {k: v for k, v in asdict(params).items() if v is not None}
        data = http_request(
            self._client, "POST", "/domains",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return _parse_domain(data)

    def verify(self, id: int, options: Optional[RequestOptions] = None) -> VerifyDomainResponse:
        data = http_request(
            self._client, "POST", f"/domains/{quote(str(id), safe='')}/verify",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return VerifyDomainResponse(
            verified=data["verified"],
            dkim_verified=data["dkim_verified"],
            errors=data.get("errors", []),
        )

    def delete(self, id: int, options: Optional[RequestOptions] = None) -> DeleteDomainResponse:
        data = http_request(
            self._client, "DELETE", f"/domains/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DeleteDomainResponse(deleted=data["deleted"])

    def regenerate_dkim(self, id: int, options: Optional[RequestOptions] = None) -> Domain:
        data = http_request(
            self._client, "POST", f"/domains/{quote(str(id), safe='')}/regenerate-dkim",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_domain(data)

    def check_dns_health(self, options: Optional[RequestOptions] = None) -> DnsHealthResponse:
        data = http_request(
            self._client, "GET", "/domains/dns-health",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DnsHealthResponse(
            data=[
                DnsHealthEntry(
                    domain=d["domain"], status=d["status"],
                    dkim_verified=d["dkim_verified"], verified_at=d.get("verified_at"),
                )
                for d in data["data"]
            ],
        )


class AsyncDomains:
    """Asynchronous domains resource."""

    def __init__(self, client: httpx.AsyncClient, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    async def list(
        self, params: Optional[ListDomainsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[Domain]:
        query = _serialize_list_params(params)
        data = await async_http_request(
            self._client, "GET", "/domains",
            api_key=self._api_key, retries=self._retries,
            query=query, **build_request_opts(options),
        )
        return _parse_paginated(data)

    async def get(self, id: int, options: Optional[RequestOptions] = None) -> Domain:
        data = await async_http_request(
            self._client, "GET", f"/domains/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_domain(data)

    async def create(
        self, params: CreateDomainParams, options: Optional[RequestOptions] = None,
    ) -> Domain:
        body = {k: v for k, v in asdict(params).items() if v is not None}
        data = await async_http_request(
            self._client, "POST", "/domains",
            api_key=self._api_key, retries=self._retries,
            body=body, **build_request_opts(options),
        )
        return _parse_domain(data)

    async def verify(self, id: int, options: Optional[RequestOptions] = None) -> VerifyDomainResponse:
        data = await async_http_request(
            self._client, "POST", f"/domains/{quote(str(id), safe='')}/verify",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return VerifyDomainResponse(
            verified=data["verified"], dkim_verified=data["dkim_verified"],
            errors=data.get("errors", []),
        )

    async def delete(self, id: int, options: Optional[RequestOptions] = None) -> DeleteDomainResponse:
        data = await async_http_request(
            self._client, "DELETE", f"/domains/{quote(str(id), safe='')}",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DeleteDomainResponse(deleted=data["deleted"])

    async def regenerate_dkim(self, id: int, options: Optional[RequestOptions] = None) -> Domain:
        data = await async_http_request(
            self._client, "POST", f"/domains/{quote(str(id), safe='')}/regenerate-dkim",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_domain(data)

    async def check_dns_health(self, options: Optional[RequestOptions] = None) -> DnsHealthResponse:
        data = await async_http_request(
            self._client, "GET", "/domains/dns-health",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return DnsHealthResponse(
            data=[
                DnsHealthEntry(
                    domain=d["domain"], status=d["status"],
                    dkim_verified=d["dkim_verified"], verified_at=d.get("verified_at"),
                )
                for d in data["data"]
            ],
        )
