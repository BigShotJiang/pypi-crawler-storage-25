from __future__ import annotations

from typing import Optional

import httpx

from .._http import async_http_request, build_request_opts, http_request
from .._types import BillingBalance, RequestOptions


class Billing:
    """Synchronous billing resource."""

    def __init__(self, client: httpx.Client, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    def get_balance(self, options: Optional[RequestOptions] = None) -> BillingBalance:
        data = http_request(
            self._client, "GET", "/billing/balance",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return BillingBalance(
            billing_tier=data["billing_tier"],
            credit_balance=data["credit_balance"],
            lifetime_send_count=data["lifetime_send_count"],
            inbound_email_count=data["inbound_email_count"],
            auto_refill_enabled=data["auto_refill_enabled"],
            auto_refill_threshold=data.get("auto_refill_threshold"),
            auto_refill_amount_cents=data.get("auto_refill_amount_cents"),
            credits_expire_at=data.get("credits_expire_at"),
        )


class AsyncBilling:
    """Asynchronous billing resource."""

    def __init__(self, client: httpx.AsyncClient, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    async def get_balance(self, options: Optional[RequestOptions] = None) -> BillingBalance:
        data = await async_http_request(
            self._client, "GET", "/billing/balance",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return BillingBalance(
            billing_tier=data["billing_tier"],
            credit_balance=data["credit_balance"],
            lifetime_send_count=data["lifetime_send_count"],
            inbound_email_count=data["inbound_email_count"],
            auto_refill_enabled=data["auto_refill_enabled"],
            auto_refill_threshold=data.get("auto_refill_threshold"),
            auto_refill_amount_cents=data.get("auto_refill_amount_cents"),
            credits_expire_at=data.get("credits_expire_at"),
        )
