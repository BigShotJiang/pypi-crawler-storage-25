from __future__ import annotations

from dataclasses import asdict
from typing import Any, Optional
from urllib.parse import quote

import httpx

from .._http import (
    async_http_request,
    async_http_request_raw,
    build_request_opts,
    http_request,
    http_request_raw,
)
from .._types import (
    Email,
    EmailContentResponse,
    EmailDownloadResponse,
    EmailEvent,
    EmailRecipient,
    EmailSummary,
    ListEmailsParams,
    PaginatedResponse,
    Pagination,
    RequestOptions,
    SendEmailParams,
    SendEmailResponse,
)


def _serialize_send_params(params: SendEmailParams) -> dict[str, Any]:
    """Convert SendEmailParams to a JSON-serializable dict, mapping from_ -> from."""
    d = asdict(params)
    d["from"] = d.pop("from_")
    return {k: v for k, v in d.items() if v is not None}


def _serialize_list_params(params: Optional[ListEmailsParams]) -> Optional[dict[str, Any]]:
    if params is None:
        return None
    d: dict[str, Any] = {}
    if params.limit is not None:
        d["limit"] = params.limit
    if params.offset is not None:
        d["offset"] = params.offset
    if params.status is not None:
        d["status"] = params.status
    if params.from_ is not None:
        d["from"] = params.from_
    if params.to is not None:
        d["to"] = params.to
    if params.recipient is not None:
        d["recipient"] = params.recipient
    if params.since is not None:
        d["since"] = params.since
    if params.until is not None:
        d["until"] = params.until
    return d or None


def _parse_send_response(data: Any) -> SendEmailResponse:
    return SendEmailResponse(
        id=data["id"],
        status=data["status"],
        created_at=data["created_at"],
        test_mode=data.get("test_mode"),
        suppressed=data.get("suppressed"),
    )


def _parse_email_summary(data: Any) -> EmailSummary:
    return EmailSummary(
        id=data["id"],
        message_id=data.get("message_id"),
        from_address=data["from_address"],
        to_addresses=data["to_addresses"],
        subject=data["subject"],
        status=data["status"],
        has_attachments=data["has_attachments"],
        created_at=data["created_at"],
        delivered_at=data.get("delivered_at"),
    )


def _parse_email(data: Any) -> Email:
    recipients = [
        EmailRecipient(
            address=r["address"],
            type=r["type"],
            status=r["status"],
            ses_message_id=r.get("ses_message_id"),
            delivered_at=r.get("delivered_at"),
            bounced_at=r.get("bounced_at"),
            complained_at=r.get("complained_at"),
        )
        for r in data.get("recipients", [])
    ]
    events = [
        EmailEvent(
            type=e["type"],
            timestamp=e["timestamp"],
            data=e.get("data"),
        )
        for e in data.get("events", [])
    ]
    return Email(
        id=data["id"],
        message_id=data.get("message_id"),
        from_address=data["from_address"],
        to_addresses=data["to_addresses"],
        subject=data["subject"],
        status=data["status"],
        has_attachments=data["has_attachments"],
        created_at=data["created_at"],
        delivered_at=data.get("delivered_at"),
        cc_addresses=data["cc_addresses"],
        bcc_addresses=data["bcc_addresses"],
        reply_to=data.get("reply_to"),
        track_opens=data["track_opens"],
        track_clicks=data["track_clicks"],
        tags=data.get("tags"),
        recipients=recipients,
        events=events,
    )


def _parse_paginated_summaries(data: Any) -> PaginatedResponse[EmailSummary]:
    pag = data["pagination"]
    return PaginatedResponse(
        data=[_parse_email_summary(e) for e in data["data"]],
        pagination=Pagination(
            limit=pag["limit"],
            offset=pag["offset"],
            total=pag["total"],
            has_more=pag["has_more"],
        ),
    )


class Emails:
    """Synchronous emails resource."""

    def __init__(self, client: httpx.Client, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    def send(
        self,
        params: SendEmailParams,
        options: Optional[RequestOptions] = None,
    ) -> SendEmailResponse:
        body = _serialize_send_params(params)
        data = http_request(
            self._client,
            "POST",
            "/emails",
            api_key=self._api_key,
            retries=self._retries,
            body=body,
            **build_request_opts(options),
        )
        return _parse_send_response(data)

    def get(self, id: str, options: Optional[RequestOptions] = None) -> Email:
        data = http_request(
            self._client,
            "GET",
            f"/emails/{quote(id, safe='')}",
            api_key=self._api_key,
            retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_email(data)

    def list(
        self,
        params: Optional[ListEmailsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[EmailSummary]:
        query = _serialize_list_params(params)
        data = http_request(
            self._client,
            "GET",
            "/emails",
            api_key=self._api_key,
            retries=self._retries,
            query=query,
            **build_request_opts(options),
        )
        return _parse_paginated_summaries(data)

    def get_content(self, id: str, options: Optional[RequestOptions] = None) -> EmailContentResponse:
        data = http_request(
            self._client, "GET", f"/emails/{quote(id, safe='')}/content",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return EmailContentResponse(html=data.get("html"), text=data.get("text"))

    def download(self, id: str, options: Optional[RequestOptions] = None) -> EmailDownloadResponse:
        content, content_type = http_request_raw(
            self._client,
            "GET",
            f"/emails/{quote(id, safe='')}/eml",
            api_key=self._api_key,
            retries=self._retries,
            **build_request_opts(options),
        )
        return EmailDownloadResponse(content=content, content_type=content_type)


class AsyncEmails:
    """Asynchronous emails resource."""

    def __init__(self, client: httpx.AsyncClient, api_key: str, retries: int) -> None:
        self._client = client
        self._api_key = api_key
        self._retries = retries

    async def send(
        self,
        params: SendEmailParams,
        options: Optional[RequestOptions] = None,
    ) -> SendEmailResponse:
        body = _serialize_send_params(params)
        data = await async_http_request(
            self._client,
            "POST",
            "/emails",
            api_key=self._api_key,
            retries=self._retries,
            body=body,
            **build_request_opts(options),
        )
        return _parse_send_response(data)

    async def get(self, id: str, options: Optional[RequestOptions] = None) -> Email:
        data = await async_http_request(
            self._client,
            "GET",
            f"/emails/{quote(id, safe='')}",
            api_key=self._api_key,
            retries=self._retries,
            **build_request_opts(options),
        )
        return _parse_email(data)

    async def list(
        self,
        params: Optional[ListEmailsParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse[EmailSummary]:
        query = _serialize_list_params(params)
        data = await async_http_request(
            self._client,
            "GET",
            "/emails",
            api_key=self._api_key,
            retries=self._retries,
            query=query,
            **build_request_opts(options),
        )
        return _parse_paginated_summaries(data)

    async def get_content(self, id: str, options: Optional[RequestOptions] = None) -> EmailContentResponse:
        data = await async_http_request(
            self._client, "GET", f"/emails/{quote(id, safe='')}/content",
            api_key=self._api_key, retries=self._retries,
            **build_request_opts(options),
        )
        return EmailContentResponse(html=data.get("html"), text=data.get("text"))

    async def download(
        self, id: str, options: Optional[RequestOptions] = None
    ) -> EmailDownloadResponse:
        content, content_type = await async_http_request_raw(
            self._client,
            "GET",
            f"/emails/{quote(id, safe='')}/eml",
            api_key=self._api_key,
            retries=self._retries,
            **build_request_opts(options),
        )
        return EmailDownloadResponse(content=content, content_type=content_type)
