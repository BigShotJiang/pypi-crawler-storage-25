class PeyemException(Exception):
    """Raised when PeyemAPI returns an error response."""

    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code
