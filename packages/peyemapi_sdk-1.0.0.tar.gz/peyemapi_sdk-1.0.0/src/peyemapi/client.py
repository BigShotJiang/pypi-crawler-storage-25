from __future__ import annotations

import hashlib
import hmac
import os
from typing import Any

import requests
from dotenv import load_dotenv

from .exceptions import PeyemException

load_dotenv()

_DEFAULT_API_URL = "https://fyxmoljbnionrylsmfoo.supabase.co/functions/v1/bazik-api"


class PeyemClient:
    """
    PeyemAPI client for Python.

    Usage::

        from peyemapi import PeyemClient

        client = PeyemClient(secret_key="sk_user_...")
        payment = client.create_payment(
            amount=500,
            reference_id="ORDER-123",
            return_url="https://example.com/return",
        )
    """

    def __init__(
        self,
        secret_key: str | None = None,
        api_url: str | None = None,
        timeout: int = 30,
    ) -> None:
        self.secret_key = secret_key or os.getenv("PEYEM_API_KEY", "")
        self.api_url = (api_url or os.getenv("PEYEM_API_URL") or _DEFAULT_API_URL).rstrip("/")
        self.timeout = timeout

        if not self.secret_key:
            raise ValueError(
                "API Secret Key is required. Pass it to the constructor or set the "
                "PEYEM_API_KEY environment variable."
            )

        self._session = requests.Session()
        self._session.headers.update(
            {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": f"Bearer {self.secret_key}",
            }
        )

    # ──────────────────────────────────────────────────────────────────
    # Public methods
    # ──────────────────────────────────────────────────────────────────

    def create_payment(
        self,
        amount: float,
        reference_id: str,
        return_url: str = "",
        description: str = "Paiement commande",
    ) -> dict[str, Any]:
        """
        Initiate a payment via PeyemAPI.

        :param amount: Amount in HTG (e.g. 500)
        :param reference_id: Unique order ID (e.g. "ORDER-123")
        :param return_url: URL to redirect the user to after payment
        :param description: Optional payment description
        :return: API response dict (may contain ``payment_url``)
        """
        return self._request(
            "POST",
            "/pay",
            json={
                "amount": amount,
                "referenceId": reference_id,
                "description": description,
                "returnUrl": return_url,
            },
        )

    def check_status(self, reference_id: str) -> dict[str, Any]:
        """
        Check the status of a payment.

        :param reference_id: The reference ID used when creating the payment
        :return: API response dict with ``status``, ``amount``, etc.
        """
        return self._request("GET", "/status", params={"referenceId": reference_id})

    def get_balance(self) -> dict[str, Any]:
        """
        Retrieve the account balance.

        :return: API response dict with ``balance`` and ``currency``
        """
        return self._request("GET", "/balance")

    @staticmethod
    def verify_webhook(payload: bytes, signature: str, webhook_secret: str) -> bool:
        """
        Verify an incoming webhook signature using HMAC-SHA256.

        :param payload: Raw request body as bytes
        :param signature: The value from the ``X-Webhook-Signature`` header
        :param webhook_secret: Your webhook secret (``whsec_...``)
        :return: ``True`` if the signature is valid, ``False`` otherwise
        """
        expected = hmac.new(
            webhook_secret.encode(),
            payload,
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(expected, signature)

    # ──────────────────────────────────────────────────────────────────
    # Internals
    # ──────────────────────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: dict | None = None,
    ) -> dict[str, Any]:
        url = f"{self.api_url}{path}"
        try:
            response = self._session.request(
                method,
                url,
                params=params,
                json=json,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise PeyemException(str(exc)) from exc

        try:
            data: dict = response.json()
        except ValueError:
            data = {}

        if not response.ok:
            raise PeyemException(
                data.get("message", f"API request failed with status {response.status_code}"),
                status_code=response.status_code,
            )

        return data
