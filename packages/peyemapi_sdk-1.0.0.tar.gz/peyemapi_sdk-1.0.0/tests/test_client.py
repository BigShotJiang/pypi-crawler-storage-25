import hashlib
import hmac

import pytest
import responses as rsps_lib
from responses import RequestsMock

from peyemapi import PeyemClient, PeyemException

API_URL = "https://fyxmoljbnionrylsmfoo.supabase.co/functions/v1/bazik-api"


@pytest.fixture
def client():
    return PeyemClient(secret_key="test_secret_key")


# ── create_payment ────────────────────────────────────────────────────

@rsps_lib.activate
def test_create_payment_success(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{API_URL}/pay",
        json={"payment_url": "https://moncash.com/pay/abc"},
        status=200,
    )

    result = client.create_payment(
        amount=500,
        reference_id="ORDER-123",
        return_url="https://example.com/return",
    )

    assert result["payment_url"] == "https://moncash.com/pay/abc"
    req = rsps_lib.calls[0].request
    assert "Bearer test_secret_key" in req.headers["Authorization"]


@rsps_lib.activate
def test_create_payment_raises_on_error(client):
    rsps_lib.add(
        rsps_lib.POST,
        f"{API_URL}/pay",
        json={"message": "Invalid amount"},
        status=400,
    )

    with pytest.raises(PeyemException, match="Invalid amount"):
        client.create_payment(amount=-1, reference_id="REF", return_url="")


# ── check_status ──────────────────────────────────────────────────────

@rsps_lib.activate
def test_check_status(client):
    rsps_lib.add(
        rsps_lib.GET,
        f"{API_URL}/status",
        json={"status": "completed", "amount": 500},
        status=200,
    )

    result = client.check_status("ORDER-123")

    assert result["status"] == "completed"
    assert "referenceId=ORDER-123" in rsps_lib.calls[0].request.url


# ── get_balance ───────────────────────────────────────────────────────

@rsps_lib.activate
def test_get_balance(client):
    rsps_lib.add(
        rsps_lib.GET,
        f"{API_URL}/balance",
        json={"balance": 12500, "currency": "HTG"},
        status=200,
    )

    result = client.get_balance()

    assert result["balance"] == 12500
    assert result["currency"] == "HTG"


# ── verify_webhook ────────────────────────────────────────────────────

def test_verify_webhook_valid():
    payload = b'{"event":"payment.completed"}'
    secret = "whsec_test"
    signature = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()

    assert PeyemClient.verify_webhook(payload, signature, secret) is True


def test_verify_webhook_invalid():
    assert PeyemClient.verify_webhook(b"payload", "fake_sig", "whsec_test") is False


# ── constructor validation ────────────────────────────────────────────

def test_no_key_raises():
    with pytest.raises(ValueError, match="API Secret Key is required"):
        PeyemClient(secret_key="")
