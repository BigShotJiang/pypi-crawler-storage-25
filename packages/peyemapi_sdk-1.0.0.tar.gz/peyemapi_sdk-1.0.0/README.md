# PeyemAPI Python SDK

A modern, typed Python SDK for integrating [PeyemAPI](https://peyem.app) payments into any Python project — works with Django, Flask, FastAPI, or plain scripts.

## Installation

```bash
pip install peyemapi-sdk
```

> **Requirements**: Python ≥ 3.9

## Quick Start

```python
from peyemapi import PeyemClient

# Credentials are loaded automatically from environment variables
client = PeyemClient()

# Or pass them directly
client = PeyemClient(secret_key="sk_user_...")
```

## Usage

### Create a Payment

```python
response = client.create_payment(
    amount=500,                          # HTG
    reference_id="ORDER-123",
    return_url="https://example.com/return",
    description="Optional description",
)

if "payment_url" in response:
    # Redirect your user to MonCash
    redirect_url = response["payment_url"]
```

### Check Payment Status

```python
status = client.check_status("ORDER-123")
print(status["status"])  # "completed", "pending", etc.
```

### Get Account Balance

```python
balance = client.get_balance()
print(f"{balance['balance']} {balance['currency']}")  # "12500 HTG"
```

### Webhook Verification

```python
import os
from peyemapi import PeyemClient

# Example using Flask
from flask import Flask, request, abort

app = Flask(__name__)

@app.post("/webhook")
def webhook():
    payload = request.get_data()
    signature = request.headers.get("X-Webhook-Signature", "")

    if not PeyemClient.verify_webhook(payload, signature, os.getenv("PEYEM_WEBHOOK_SECRET")):
        abort(401)

    data = request.get_json()
    print("Valid webhook received:", data)
    return "", 200
```

## Environment Variables

| Variable | Description |
|---|---|
| `PEYEM_API_KEY` | Your secret API key |
| `PEYEM_API_URL` | Override the API base URL (optional) |
| `PEYEM_WEBHOOK_SECRET` | Your webhook signing secret |

Copy `.env.example` → `.env` and fill in your credentials.

## Error Handling

```python
from peyemapi import PeyemClient, PeyemException

try:
    result = client.create_payment(amount=500, reference_id="REF", return_url="")
except PeyemException as e:
    print(f"API Error [{e.status_code}]: {e}")
```

## Running Tests

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT
