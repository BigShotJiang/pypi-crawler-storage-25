from econ_instrumentation import instrument_langchain_callback_handler, instrument_langchain_runnable

# runnable = ...
# wrapped = instrument_langchain_runnable(runnable, "FraudDetection", "model_v2")
# callbacks = [instrument_langchain_callback_handler("FraudDetection", "model_v2")]
# wrapped.invoke({"input": "hello"}, config={"callbacks": callbacks})
