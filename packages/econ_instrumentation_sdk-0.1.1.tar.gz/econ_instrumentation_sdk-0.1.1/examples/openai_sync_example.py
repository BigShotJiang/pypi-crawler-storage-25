from econ_instrumentation import InstrumentationConfig, configure, instrument_openai_client

# from openai import OpenAI
# client = OpenAI()

configure(InstrumentationConfig(base_url="http://localhost:8000/v1"))

# wrapped = instrument_openai_client(client, "FraudDetection", "model_v2", tags={"env": "staging"})
# wrapped.chat.completions.create(model="gpt-4.1", messages=[{"role": "user", "content": "hello"}])
