import asyncio

from econ_instrumentation import InstrumentationConfig, configure, instrument_anthropic_async_client

# from anthropic import AsyncAnthropic
# client = AsyncAnthropic()

configure(InstrumentationConfig(base_url="http://localhost:8000/v1"))


async def main() -> None:
    # wrapped = instrument_anthropic_async_client(client, "FraudDetection", "model_v2")
    # await wrapped.messages.create(model="claude-3-5-sonnet", max_tokens=128, messages=[{"role": "user", "content": "hello"}])
    pass


if __name__ == "__main__":
    asyncio.run(main())
