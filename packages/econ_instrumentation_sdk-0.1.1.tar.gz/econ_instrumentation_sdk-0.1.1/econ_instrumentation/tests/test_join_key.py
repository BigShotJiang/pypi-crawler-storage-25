from datetime import datetime, timezone

from econ_instrumentation.client import join_key_context, track_execution, track_outcome
from econ_instrumentation.runtime import get_runtime
from econ_instrumentation.schemas import ExecutionEvent, OutcomeEvent


def test_execution_and_outcome_share_join_key_from_mapping() -> None:
    runtime = get_runtime()
    sent_exec = []
    sent_out = []
    runtime.transport.enqueue_execution = lambda event: sent_exec.append(event)  # type: ignore[assignment]
    runtime.transport.enqueue_outcome = lambda event: sent_out.append(event)  # type: ignore[assignment]

    exec_event = ExecutionEvent(
        execution_id="exec_join_1",
        capability_id="SupportRefundTriage",
        implementation_id="model_v2",
        timestamp=datetime.now(timezone.utc),
        metadata={"request_id": "REQ-123"},
    )
    track_execution(exec_event)

    outcome = OutcomeEvent(
        execution_id="exec_join_1",
        capability_id="SupportRefundTriage",
        outcome_type="custom",
        outcome_value="approved",
        outcome_timestamp=datetime.now(timezone.utc),
    )
    track_outcome(outcome)

    assert sent_exec[-1].join_key == "REQ-123"
    assert sent_out[-1].join_key == "REQ-123"


def test_outcome_uses_context_join_key_when_execution_unknown() -> None:
    runtime = get_runtime()
    sent_out = []
    runtime.transport.enqueue_outcome = lambda event: sent_out.append(event)  # type: ignore[assignment]

    with join_key_context("REQ-CONTEXT-1"):
        outcome = OutcomeEvent(
            execution_id="exec_unknown_1",
            capability_id="FraudReview",
            outcome_type="custom",
            outcome_value="ok",
            outcome_timestamp=datetime.now(timezone.utc),
        )
        track_outcome(outcome)

    assert sent_out[-1].join_key == "REQ-CONTEXT-1"
