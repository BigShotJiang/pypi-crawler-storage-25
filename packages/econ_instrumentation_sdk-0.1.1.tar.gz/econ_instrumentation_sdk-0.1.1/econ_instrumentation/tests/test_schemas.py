from econ_instrumentation.schemas import ExecutionEvent, OutcomeEvent


def test_event_schema() -> None:
    evt = ExecutionEvent(capability_id="FraudDetection", implementation_id="model_v1")
    assert evt.execution_id

    out = OutcomeEvent(
        execution_id=evt.execution_id,
        capability_id="FraudDetection",
        outcome_type="fraud_flag",
        outcome_value=False,
    )
    assert out.capability_id == "FraudDetection"
