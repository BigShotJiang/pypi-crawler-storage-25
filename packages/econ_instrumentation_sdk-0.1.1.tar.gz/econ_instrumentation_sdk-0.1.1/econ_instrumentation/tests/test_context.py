from unittest.mock import patch

from econ_instrumentation.client import with_instrumentation


def test_context_manager_tracks_execution() -> None:
    with patch("econ_instrumentation.client.track_execution") as mock_track:
        with with_instrumentation("FraudDetection", "model_v1"):
            pass
        assert mock_track.called
