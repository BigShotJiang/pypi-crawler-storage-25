from __future__ import annotations

from econ_instrumentation.otel import maybe_span


def test_optional_otel_bridge_no_dependency_required() -> None:
    with maybe_span(True, "ecp.test", {"a": 1}):
        value = 42
    assert value == 42
