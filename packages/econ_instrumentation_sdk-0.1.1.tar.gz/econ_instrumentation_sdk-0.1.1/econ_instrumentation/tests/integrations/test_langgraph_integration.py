from __future__ import annotations

from econ_instrumentation.integrations.langgraph import instrument_langgraph_graph
from econ_instrumentation.runtime import get_runtime
from econ_instrumentation.schemas import ExecutionEvent


class _RecorderTransport:
    def __init__(self) -> None:
        self.events: list[ExecutionEvent] = []

    def enqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)

    async def aenqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)


class FakeGraph:
    def invoke(self, *_args, **_kwargs):
        return {"ok": True}

    def stream(self, *_args, **_kwargs):
        yield {"chunk": 1}
        yield {"chunk": 2}


def test_langgraph_invoke_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    graph = instrument_langgraph_graph(FakeGraph(), "FraudDetection", "model_v1")
    out = graph.invoke({"x": 1})
    assert out["ok"] is True
    assert len(recorder.events) == 1
    assert recorder.events[0].metadata["source_layer"] == "langgraph"


def test_langgraph_stream_emits_event_on_close() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    graph = instrument_langgraph_graph(FakeGraph(), "FraudDetection", "model_v1")
    chunks = list(graph.stream({"x": 1}))
    assert len(chunks) == 2
    assert len(recorder.events) == 1
    assert recorder.events[0].metadata["streaming"] is True
