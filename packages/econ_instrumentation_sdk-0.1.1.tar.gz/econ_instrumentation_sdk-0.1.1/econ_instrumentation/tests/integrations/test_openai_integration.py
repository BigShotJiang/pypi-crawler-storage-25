from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

import pytest

from econ_instrumentation.config import AutoInstrumentationConfig
from econ_instrumentation.integrations.openai import instrument_openai_async_client, instrument_openai_client
from econ_instrumentation.runtime import get_runtime
from econ_instrumentation.schemas import ExecutionEvent


@dataclass
class Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class Response:
    model: str
    usage: Usage


class _RecorderTransport:
    def __init__(self) -> None:
        self.events: list[ExecutionEvent] = []

    def enqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)

    async def aenqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)


class _SyncCompletions:
    def create(self, **kwargs):
        return Response(model=kwargs.get("model", "gpt-4.1"), usage=Usage(10, 5, 15))


class _AsyncCompletions:
    async def create(self, **kwargs):
        return Response(model=kwargs.get("model", "gpt-4.1"), usage=Usage(8, 4, 12))


class _SyncChat:
    completions = _SyncCompletions()


class _AsyncChat:
    completions = _AsyncCompletions()


class SyncClient:
    chat = _SyncChat()


class AsyncClient:
    chat = _AsyncChat()


def test_openai_sync_wrapper_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    client = instrument_openai_client(SyncClient(), "FraudDetection", "model_v2", tags={"env": "test"})
    _ = client.chat.completions.create(model="gpt-4.1")

    assert len(recorder.events) == 1
    event = recorder.events[0]
    assert event.capability_id == "FraudDetection"
    assert event.metadata["provider"] == "openai"
    assert event.metadata["total_tokens"] == 15


@pytest.mark.asyncio
async def test_openai_async_wrapper_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    client = instrument_openai_async_client(AsyncClient(), "FraudDetection", "model_v3")
    _ = await client.chat.completions.create(model="gpt-4.1")

    assert len(recorder.events) == 1
    assert recorder.events[0].metadata["is_async"] is True


def test_openai_suppressed_in_hierarchical_when_framework_context_active() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]
    runtime.enable_auto_instrumentation(AutoInstrumentationConfig(capture_mode="hierarchical"))
    try:
        client = instrument_openai_client(SyncClient(), "FraudDetection", "model_v2", tags={"env": "test"})
        with runtime.capture_context("langchain", run_id="lc_parent"):
            _ = client.chat.completions.create(model="gpt-4.1")
        assert len(recorder.events) == 0
    finally:
        runtime.disable_auto_instrumentation()
