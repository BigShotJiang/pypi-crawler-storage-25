from __future__ import annotations

import pytest

from econ_instrumentation.integrations.langchain import (
    instrument_langchain_app,
    instrument_langchain_async_runnable,
    instrument_langchain_callback_handler,
    instrument_langchain_runnable,
)
from econ_instrumentation.runtime import get_runtime
from econ_instrumentation.schemas import ExecutionEvent


class _RecorderTransport:
    def __init__(self) -> None:
        self.events: list[ExecutionEvent] = []

    def enqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)

    async def aenqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)


class FakeRunnable:
    def invoke(self, *args, **kwargs):
        return {"ok": True}

    async def ainvoke(self, *args, **kwargs):
        return {"ok": True}


class FakeAppWithConfig:
    def __init__(self) -> None:
        self.last_config = None

    def with_config(self, cfg):
        self.last_config = cfg
        return self


def test_langchain_callback_handler_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    handler = instrument_langchain_callback_handler("FraudDetection", "model_v1")
    handler.on_chain_start({}, {}, run_id="run_1")
    handler.on_chain_end({}, run_id="run_1")

    assert len(recorder.events) == 1
    assert recorder.events[0].metadata["library"] == "langchain"


def test_langchain_runnable_sync_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    wrapped = instrument_langchain_runnable(FakeRunnable(), "FraudDetection", "model_v1")
    out = wrapped.invoke({"x": 1})

    assert out["ok"] is True
    assert len(recorder.events) == 1


@pytest.mark.asyncio
async def test_langchain_runnable_async_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    wrapped = instrument_langchain_async_runnable(FakeRunnable(), "FraudDetection", "model_v1")
    out = await wrapped.ainvoke({"x": 1})

    assert out["ok"] is True
    assert len(recorder.events) == 1


def test_langchain_app_prefers_with_config_when_available() -> None:
    app = FakeAppWithConfig()
    instrumented = instrument_langchain_app(app, "FraudDetection", "model_v1")
    assert instrumented is app
    assert "callbacks" in app.last_config
