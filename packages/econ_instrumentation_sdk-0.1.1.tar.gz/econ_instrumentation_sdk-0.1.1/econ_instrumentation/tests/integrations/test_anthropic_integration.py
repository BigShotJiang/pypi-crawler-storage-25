from __future__ import annotations

from dataclasses import dataclass

import pytest

from econ_instrumentation.integrations.anthropic import instrument_anthropic_async_client, instrument_anthropic_client
from econ_instrumentation.runtime import get_runtime
from econ_instrumentation.schemas import ExecutionEvent


@dataclass
class Usage:
    input_tokens: int
    output_tokens: int


@dataclass
class Response:
    model: str
    usage: Usage


class _RecorderTransport:
    def __init__(self) -> None:
        self.events: list[ExecutionEvent] = []

    def enqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)

    async def aenqueue_execution(self, event: ExecutionEvent) -> None:
        self.events.append(event)


class _SyncMessages:
    def create(self, **kwargs):
        return Response(model=kwargs.get("model", "claude-3-5-sonnet"), usage=Usage(7, 3))


class _AsyncMessages:
    async def create(self, **kwargs):
        return Response(model=kwargs.get("model", "claude-3-5-sonnet"), usage=Usage(6, 2))


class SyncClient:
    messages = _SyncMessages()


class AsyncClient:
    messages = _AsyncMessages()


def test_anthropic_sync_wrapper_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    client = instrument_anthropic_client(SyncClient(), "FraudDetection", "model_v2")
    _ = client.messages.create(model="claude-3-5-sonnet")

    assert len(recorder.events) == 1
    event = recorder.events[0]
    assert event.metadata["provider"] == "anthropic"
    assert event.metadata["total_tokens"] == 10


@pytest.mark.asyncio
async def test_anthropic_async_wrapper_emits_event() -> None:
    runtime = get_runtime()
    recorder = _RecorderTransport()
    runtime.transport = recorder  # type: ignore[assignment]

    client = instrument_anthropic_async_client(AsyncClient(), "FraudDetection", "model_v3")
    _ = await client.messages.create(model="claude-3-5-sonnet")

    assert len(recorder.events) == 1
    assert recorder.events[0].metadata["is_async"] is True
