from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import patch

from econ_instrumentation.config import InstrumentationConfig
from econ_instrumentation.schemas import ExecutionEvent
from econ_instrumentation.transport import TelemetryTransport


def test_config_defaults() -> None:
    config = InstrumentationConfig()
    assert config.capture_content is False
    assert config.enabled is True
    assert config.flush_interval_ms > 0


def test_transport_drops_oldest_when_queue_full() -> None:
    config = InstrumentationConfig(buffer_max_events=2, flush_interval_ms=10000)
    transport = TelemetryTransport(config)

    for idx in range(3):
        transport.enqueue_execution(
            ExecutionEvent(
                execution_id=f"exec_{idx}",
                timestamp=datetime.now(timezone.utc),
                capability_id="FraudDetection",
                implementation_id="model_v1",
            )
        )

    assert transport.queue_size() == 2
    assert transport.dropped_events == 1


def test_transport_retry_drop_on_failure_max_retries_one() -> None:
    config = InstrumentationConfig(base_url="http://127.0.0.1:9/v1", max_retries=1)
    transport = TelemetryTransport(config)
    transport.enqueue_execution(
        ExecutionEvent(
            execution_id="exec_fail",
            timestamp=datetime.now(timezone.utc),
            capability_id="FraudDetection",
            implementation_id="model_v1",
        )
    )

    with patch("httpx.Client.post", side_effect=RuntimeError("down")):
        transport.flush_once()

    assert transport.queue_size() == 0
    assert transport.dropped_events == 1
