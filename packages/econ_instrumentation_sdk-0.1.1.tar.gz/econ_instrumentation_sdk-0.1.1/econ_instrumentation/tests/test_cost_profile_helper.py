from econ_instrumentation.client import build_cost_profile_input


def test_build_cost_profile_input() -> None:
    payload = build_cost_profile_input(
        requests_per_period=1000,
        avg_input_tokens=300,
        avg_output_tokens=120,
        model_mix_json={"gpt-4.1": 1.0},
        provider_rate_overrides_json={},
        avg_tool_calls_per_request_json={},
        tool_unit_price_overrides_json={},
        infra_monthly_spend_usd=500.0,
        retry_rate=0.02,
        cache_hit_rate=0.10,
    )
    assert payload["requests_per_period"] == 1000
    assert payload["cache_hit_rate"] == 0.10
