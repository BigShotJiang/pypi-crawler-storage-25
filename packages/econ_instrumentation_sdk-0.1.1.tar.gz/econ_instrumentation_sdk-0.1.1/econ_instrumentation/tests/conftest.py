from __future__ import annotations

import os

import pytest

from econ_instrumentation.client import configure
from econ_instrumentation.config import InstrumentationConfig


@pytest.fixture(autouse=True)
def _isolate_runtime(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ECP_INSTRUMENT_OPENAI", "true")
    monkeypatch.setenv("ECP_INSTRUMENT_ANTHROPIC", "true")
    monkeypatch.setenv("ECP_INSTRUMENT_LANGCHAIN", "true")
    configure(
        InstrumentationConfig(
            base_url="http://localhost:9999/v1",
            enabled=True,
            buffer_max_events=100,
            flush_interval_ms=10_000,
            request_timeout_s=0.1,
        )
    )
    yield
    configure(InstrumentationConfig.from_env())
    for key in ["ECP_INSTRUMENT_OPENAI", "ECP_INSTRUMENT_ANTHROPIC", "ECP_INSTRUMENT_LANGCHAIN"]:
        if key in os.environ:
            del os.environ[key]
