# kd Operating Guide

This guide is the prose companion to `kd --reference`. Use `kd --reference` for the exact command catalog. Use this guide for the operating model, safe command composition, cost expectations, and YouTrack-specific gotchas that are easy to miss from syntax alone.

## What kd Is

kd is a knowledge-network tool for YouTrack-backed work. Its primary loop is:

1. Pull context from live systems.
2. Reason over that context in the operator's head or an LLM session.
3. Push focused updates back.

The primer is the canonical shape: a small local `.kd/primer.yaml` file with curated notes and pinned references that sits on top of live systems. It does not replace YouTrack. It tells the operator what matters before they start pulling issues, articles, tags, queries, and project metadata.

The CLI is SDK-first. Commands are thin wrappers over `kd.client`; business behavior belongs in the SDK and API layers. This matters for LLMs because command behavior should be predictable and repeatable across the terminal, scripts, and programmatic use.

## What kd Is Not

kd is not a migration platform, a data warehouse, or a hidden local mirror of YouTrack.

Cross-system moves should stay thin and deliberate. The default knowledge-network move is a stub or reference with a backref to the source, not a faithful copy of every field. Same-provider import/export can preserve more, but that is the corner case, not the product center.

Avoid designing workflows that turn kd into bulk synchronization, silent lossy migration, or a replacement database. If a proposed feature stops looking primer-shaped, it probably needs a proposal before implementation.

## First Read Workflow

For a fresh repository or an LLM session, start with the durable context:

```bash
kd /primer show -o yaml
kd --reference
```

Then pull live context narrowly:

```bash
kd /issue show KDCLI-42 -o yaml
kd /article show KDCLI-A-12 -o yaml
kd /tag entities kind:note --project KDCLI -o yaml
kd /tag entities --primer-scope -o yaml
```

Read the primer before deciding which live queries to run. Use pinned articles for durable background. Use pinned tags as the workspace's curated content-management pivots. `kd /tag entities --primer-scope` expands those pinned tags into an explicit OR scope across issues and articles, which is usually the fastest way to see what the workspace says matters right now. Use saved queries for recurring issue searches, not for article full-text search.

## Command Composition Rules

Prefer explicit context when composing commands:

```bash
kd -c support /issue list --project KDCLI -o json
```

Use `-o json` or `-o yaml` for LLM and script consumption. Table output is for humans. kd does not auto-switch output when stdout is piped, by design. The same command has the same output shape unless you pass a different `--output`.

Use `--fields` only as an output projection. It filters returned keys or columns; it does not request more upstream data. When a command has a separate upstream-expansion flag, such as `/issue list --with-tags`, pass that flag explicitly.

For aggregate commands, read metadata before deciding success. `/tag entities` can return partial results with exit 0 when one kind succeeds and another kind fails. Check `meta.<kind>.scanned`, `meta.<kind>.complete`, `meta.<kind>.truncated`, and `meta.<kind>.error`.

`/tag entities --primer-scope` is an explicit curated-scope shortcut. It reads tags pinned in `.kd/primer.yaml` and matches entities tagged with any pinned tag. It is mutually exclusive with positional `TAG` and repeatable `--tag` arguments because explicit tag filters use intersection semantics, while primer scope is intentionally a union.

Mutation commands return structured payloads in JSON/YAML mode. Scripts and LLMs should read `ok`, `action`, and entity IDs rather than parse prose.

Every upstream-mutation command except `/tag add` emits a parseable single-line ack as the last line of stdout in text/md modes, so shell loops can extract the new entity ID without parsing prose. (`/tag add` is reshaped with a multi-tag `applied[]` envelope in a separate session.)

```bash
id=$(kd /issue create "Fix router config" --project KDCLI --quiet | tail -1 | awk '{print $2}')
```

The tail line is `ok: <ID> <action> [key=value ...]` on success, `error: <ID> <code>` on failure. Pass `--quiet` to suppress the detail block above the ack so stdout is exactly that single line. Comment-add tail lines use the parent entity ID as the primary tail-line ID (`$2`) and put the new comment ID in `comment_id=<id>`. See §Output And Debugging for the full grammar.

Some successful commands may also return `warnings: [{code, message, context}]`. Treat warnings as advisory, not failures. The first common case is `/primer/tag add`, which may write the local primer entry while warning that upstream tag validation failed or found no current tag by that name. In text/md modes warnings render to **stderr** so stdout stays parseable; structured modes (`-o yaml`/`-o json`) keep `warnings` in the payload.

## Cost And Safety Model

Not every read has the same cost.

**Direct reads** fetch one entity or one server-side page. Examples: `/issue show`, `/article show`, `/project show`, `/tag show`, `/query show`.

**Query-backed reads** rely on an upstream query or filter. Examples: `/issue list --query`, `/query issues`, `/tag issues`, `/tag list --prefix`, `/tag list --namespace`, `/article search`. They are usually cheap but still depend on YouTrack query semantics.

**Scan-backed reads** walk pages and filter client-side because YouTrack has no matching endpoint. Examples: `/tag articles`, the article half of `/tag entities`, the article half of `/search --types article` (client-side substring), and deep `/article tree` traversal. Use limits and project scoping.

Write-side commands do not prompt for confirmation unless their help says so. Pair destructive or broad operations with a read first:

```bash
kd /issue show KDCLI-42 -o yaml
kd /issue update KDCLI-42 --state Fixed -o yaml
```

For article push, use `--dry-run` before a risky write and inspect conflicts with `/article pull`.
`/article push --tag` rejects missing tags by default and prints the concrete recovery commands. Use `--create-tags` only for scripted flows that already own the tag namespace.

Three delete commands bypass YouTrack's Deleted Items safety net and require an explicit `--confirm` flag:

- `/project delete` — all issues and articles in the project are permanently removed, not moved to Deleted Items.
- `/tag delete` — tag membership is lost across every tagged issue and article; recreating the tag does not restore assignments.
- `/user delete` — identity references in issue history become detached; consider banning in the Hub UI instead.

Without `--confirm` these commands exit non-zero with an error that names the failure mode and prints the literal retry command. Recovery for any of the three requires a database backup restore. `/issue delete`, `/article delete`, and attachment deletes do not require `--confirm` — they go to Deleted Items and are admin-restorable for roughly 14 days.

## Write-gating And Mutation Safety

Commands that mutate upstream require a live tracker. They refuse to operate on cache-only context. No stale cache read can silently become a destructive upstream write.

In practice every mutation runs through a client gate before the command body executes. When kd cannot establish a live client for the mutation — token environment variable unset, broken `token_cmd`, no auth source on the active connection, 401 from the server, request timeout, or actual network outage — the dispatcher exits non-zero with a connection-named message and the command never starts. Cache contents never substitute. The intentional hybrids are `/primer/tag add` and `/primer/issue add`, which each validate upstream and either succeed, return a `*_not_found` warning when the entity is unknown, or return `*_validation_skipped` when validation cannot run mid-flight; that behavior is described in §Primer Practices.

The cache namespace (`kd /cache refresh|status|search|clear`) is read-side by construction; there is no mutation path that consults the cache. The canonical statement of this rule lives in `KDCLI-A-18` §Write-gating.

## YouTrack Gotchas

YouTrack's article query API is undocumented but supported on the YT tiers kd targets (cloud + on-prem 2023.2). `kd /article search QUERY` calls `GET /api/articles?query=…` and returns relevance-ranked results matching across body, summary, tags, and comments. Instances that reject the parameter surface a specific capability error rather than falling back silently. Server-side article-by-tag is still missing — `/tag articles` scans article pages that include `tags(id,name)` and filters locally.

Saved queries are YouTrack issue-search objects. `/query issues` executes them directly. `/query articles` only translates supported `project:` and `tag:` fields into article scans; issue-specific fields such as state or assignee are rejected for articles.

Tag names with colons or spaces need YouTrack query literal handling in both issue and article queries (the article query DSL is the same syntax family). `tag: type:case` is wrong; YouTrack reads `type` as the tag value and `case` as another field. Use `tag: {type:case}` in hand-written queries — for `/issue list --query` and `/article search` alike. kd command paths that compose tag queries use the shared literal helper; `/article search` preserves the YouTrack 400 and appends a brace-wrapping hint when a bare colon-bearing `tag:` literal trips the misparse.

Repeated same-field clauses in YouTrack query syntax default to OR. `tag: A tag: B` matches either tag. kd multi-tag issue operations join tag clauses with explicit `and` when intersection is required.

Issue custom fields are project-specific and need `$type` discriminators on mutation. Prefer semantic options such as `--state`, `--type`, and `--priority` for common fields, and inspect project fields before using generic `--field NAME=VALUE`:

```bash
kd /project/field list KDCLI
```

Clear optional custom fields with an empty value, for example `kd /issue update KDCLI-42 --field "Milestone="`. Required fields reject empty values before any upstream write.

`--field` supports bundle families (enum, state, owned, version, build), user fields, period, and string `SimpleProjectCustomField` subtypes; whitespace inside the value is preserved. Unsupported families (text, `Multi*` enum/user variants, and `SimpleProjectCustomField` with `integer` / `float` / `date` subtypes) fail client-side with a message naming both the project `$type` and the `fieldType.id` subtype so a follow-on bug report can skip the probe.

On fresh (zero-issue, contributor-token) projects where schema discovery returns no fields, kd synthesizes a best-effort bootstrap payload for `--type`, `--priority`, and `--state` and lets YouTrack accept or reject; YouTrack's rejection text surfaces unchanged so an unusual project setup is auditable upstream. `--field NAME=VALUE` still requires a sample issue or admin token because kd lacks server-side `$type` knowledge to synthesize generic fields safely. KDCLI-A-22 carries the detail.

Attachment metadata download URLs may start with `/api/`. kd handles this internally on download commands; do not assume the raw URL can be appended unchanged to an API base URL in custom scripts.

Tag existence, tag visibility, and tag sharing rights are different concerns. A visible tag may not be usable for every operation, and sharing settings are provider-specific security posture, not just display metadata.

## Primer Practices

For a fresh workspace, scaffold the primer with `kd /primer init`. The default `hitl` template drops placeholder prose into three slots — scope guard, session workflow, canonical reference — that the operator fills in an editor. The command refuses if a primer already exists and has no `--force`; deletion is explicit operator work.

Primer notes should capture durable project rules, not temporary status. Good notes explain naming conventions, required workflows, dangerous assumptions, and pointers to canonical references.

Do not use the primer as a session log. Avoid recording current focus, completed session lists, release-cadence details copied from a plan, or other progress facts that can become false by the next agent session. If the primer needs to point at active work, stop at the current master plan or equivalent planning document; the agent should open that document and derive the next step from there.

Pinned tags should capture the workspace's current content-management lens: the tag pivots that define what to read first, what to maintain, and where related issues and articles cluster. They are not a complete taxonomy. They are the small curated set that makes `--primer-scope` useful.

The primer stores pinned tags as a top-level `tags:` block:

```yaml
tags:
  - name: kind:incident
    summary: Active incident investigations
```

Manage that block through kd rather than editing YAML by hand:

```bash
kd /primer/tag add kind:incident --summary "Active incident investigations"
kd /primer/tag list -o yaml
kd /primer/tag update kind:incident --summary "Updated lens"   # in-place; --summary "" clears
kd /primer/tag remove kind:incident
```

`/primer/tag add` validates the tag name against YouTrack when a connection is configured and reachable. If the tag is not found, kd still writes the local primer entry and returns a `tag_not_found` warning so a planned taxonomy can be declared before every tag exists upstream. If validation cannot run because the server is unreachable, kd writes the entry and returns `tag_validation_skipped`. If no usable connection or token is configured, the command fails and does not edit the primer.

`/primer/tag update` replaces the summary on a pinned tag in place — entry position is preserved. It is local-only: no upstream call, no re-validation. Pass `--summary ""` to clear an existing summary. To rename a tag, use `remove` then `add` (identity changes are rare and may need cross-reference updates).

Pinned issues are the active execution anchors — the YouTrack issues this workspace is currently *working on*. Unlike tags (a discovery lens) or articles (deep reference), pinned issues represent in-flight work an LLM (or a human resuming tomorrow) needs to see immediately via `/primer show`. The block lives next to `tags:` and `articles:` in `.kd/primer.yaml`:

```yaml
issues:
  - id: KDCLI-175
    summary: Pinned issues + render-time refs
```

Manage the block through kd:

```bash
kd /primer/issue add KDCLI-175 --summary "Pinned issues + refs"
kd /primer/issue list -o yaml
kd /primer/issue update KDCLI-175 --summary "Refined scope"   # in-place; --summary "" clears
kd /primer/issue remove KDCLI-175
```

`/primer/issue add` mirrors `/primer/tag add`: it validates the issue ID against YouTrack via `client.issues.get(id, detail="brief")`. If the issue is not found, kd still writes the local primer entry and returns an `issue_not_found` warning so a planned issue can be declared before it exists upstream. If validation fails mid-flight (transient upstream fault), kd writes the entry and returns `issue_validation_skipped`. Pre-execute connection failures (no connection, missing token, expired auth) reject the command before the body runs — the warning paths cover the upstream's transient faults, not configuration faults.

`/primer/issue update` replaces the summary on a pinned issue in place — entry position is preserved. It is local-only: no upstream call, no re-validation. Pass `--summary ""` to clear. To re-key an issue, use `remove` then `add`.

`/primer/article` follows the same shape: `add ARTICLE_ID [--summary S]`, `list`, `update ARTICLE_ID --summary S` (or `--summary ""` to clear), `remove ARTICLE_ID | --all`. Article add and update are both local-only — kd does not validate the article ID against upstream on add or update.

`kd /cache refresh --primer-scope` hydrates pinned issues alongside pinned articles and the pinned-tag query: each pinned issue is rich-fetched and projected to `cache/connections/<slug>/issues/<id>.yaml` using the same single-issue projection (`source.reason: primer pinned issue`).

Pinned articles should be few and high-signal. They are starting points for reasoning, not an export of the knowledge base.

Prose fields in the primer (note text, tag/issue/article summaries) can carry inline cross-reference markers — `tag:<name>`, `article:<id>`, `issue:<id>`. The render-time parser surfaces them as a derived `refs: [...]` array on every prose-bearing row in `kd /primer show -o json|yaml`; table / md keep the markers inline in the prose itself. There is no `note:` form (notes have no stable identity; ADR-013 has the rationale). Path-extending punctuation (`/`, `\`, `@`, `#`, `?`, `=`) breaks a marker — URLs and code paths are not silently captured. `tag:` markers in note prose do **not** feed `/tag entities --primer-scope`; only the explicit `tags:` section defines that lens.

When pinned tags, issues, and articles all exist, read them in canonical order: notes tell you how to think, tags tell you where live content clusters, issues anchor active execution, and articles provide deeper durable references.

Keep the primer local and curated. If a note becomes generally true for kd, move it into docs or this guide. If it is workspace-specific, keep it in `.kd/primer.yaml`.

Primer mutations are serialized per file through an advisory lock on `.kd/primer.yaml.lock`; concurrent kd processes writing to the same primer queue rather than conflict, so agent-launched parallel `/primer/note`, `/primer/tag`, `/primer/issue`, and `/primer/article` commands all converge without lost updates. The lock works identically on macOS, Linux, and Windows — the underlying primitive is `fcntl.flock` on POSIX and `msvcrt.locking` on Windows, both selected automatically.

## Articles And Push

Use `/article show` for metadata plus rendered content. Pass `--preview` (sugar for `--body-lines 40`) or `--body-lines N` for an N-line head; the structured envelope gains `content_truncated`, `content_chars`, `content_lines`, and `content_preview_lines` only when truncation actually applies. Pass `--no-content` for metadata only (drops `content`, sets `content_omitted: true`). `--no-content` is mutually exclusive with `--body-lines`/`--preview`. Use `/article pull` when you need raw article content on stdout; `pull` is format-agnostic and ignores `--output`.

`/article push` is an idempotent file-to-YouTrack workflow. The local file gains a `<!-- kd-meta ... -->` marker exactly once — on the first push that creates or resolves the upstream article (or to repair a stale `upstream-id`). Subsequent pushes do not modify the file. Commit the one-time marker insertion with the content; from there `git status` stays clean across pushes. The marker is identity (`slug` + `upstream-id`), not tool state.

Do not use push for one-off web edits or broad tree migration. It is single-file by design. If the remote changed, pull, diff, merge by hand, then push again. Use `--force` only after inspecting the remote state.

Every update push performs a live read of the upstream `updated` field and reports the outcome through `conflict_check` in the structured response. Baseline priority is `cache > legacy_marker > none`: when the per-connection cache holds a sidecar for the article, its `upstream_updated` is the drift baseline (`conflict_check: cache`); otherwise the legacy in-marker timestamp drives the check (`conflict_check: legacy_marker`); identity-only markers with no cache report `conflict_check: skipped_no_baseline` and proceed under the explicit trust-new policy. Every successful push refreshes the active-connection cache scope, so the seam stays current invocation-to-invocation without operator intervention. Cache reads are fail-closed: a malformed sidecar (bad YAML, wrong kind/id, malformed ISO) refuses before any upstream write and names `kd /cache refresh --article ID`, `kd /cache clear`, and `--force` as concrete recoveries. Cache failures *after* a successful upstream write surface as structured `warnings[]` entries (`cache_refresh_failed`, `cache_scope_mismatch`) and never fail the command.

For one-way migrations where the local file will be deleted after the push, pass `--no-marker-write`. The server article is still created or updated and tags are still applied, but kd skips the local `kd-meta` rewrite so `git rm` works without `-f`. The structured response gains `marker_written: false`; re-running `--no-marker-write` pays the scan-by-slug cost every invocation because no `upstream-id` is cached locally.

When pushing with `--tag`, kd validates all tags before the article write. Missing tags abort with commands to list the namespace, create the tag, retry without it, or apply the tag separately after push. `--create-tags` is the explicit opt-in for automation that should create missing tags first.

`/article create --tag` applies the same preflight: every tag must exist, missing tags abort before the article write (no orphan article on a typo), and the structured response reflects post-tag state so it matches an immediate `/article show` on the returned id. There is no `--create-tags` on `/article create` — curate the namespace with `/tag create` first, or omit `--tag` and apply tags after creation via `/tag add ARTICLE-ID TAG`.

## Cache

`.kd/cache/` is a disposable upstream-mirror under each scope at `connections/<slug>/`. Every cached file landed there because a `kd /cache refresh` command put it there; reads are explicit. `kd /cache status` is the read-only health surface: per-scope counts, latest and oldest fetch timestamps, and a `stale_count` against an inclusive `fetched_at <= now - stale_after_days` rule (default 7 days). The default scan is workspace-wide; `--scope NAME` focuses on one connection. Status is local-only, resolves no tracker token, and reports per-file parse failures as warnings rather than aborting. A schema-invalid `scope.yaml` is the only condition that exits non-zero; identity drift between a manifest and the active config is **not** flagged here — that comparison stays a write-time concern owned by `refresh`.

`kd /cache search TEXT` is the read-side query verb: a local-only, case-insensitive substring search across hydrated cache content. The default scan walks every connection scope (plus legacy flat cache content under `unscoped`); `--scope NAME` focuses on one scope with the same matcher used by `status`. The global `-c NAME` selector is informational on search — it does not narrow the walk, exactly as it does not narrow `status`. `--kind {article,issue,query}` restricts the walk to one kind; `--limit N` (default 200) caps total matches and short-circuits the sweep with `meta.truncated: true`. Searched fields follow a fixed precedence so the first-match field is deterministic: article (`summary`, `body`); issue (`summary`, `description`, `comment.text`); query files dispatch by structural shape (saved-query / milestone, primer-scope tag entities, epic-children manifest). Each match row exposes both the operator-facing `connection` (manifest name) and the directory `slug`. Per-file parse failures collect into warnings rather than aborting; YAML files with an unrecognizable banner but a parseable payload still search the payload's selected fields, since the raw banner string is never inside the searchable field set.

## Reconciliation

When the tracker is unreachable, kd does not buffer ticket transitions or queue closeouts — those rejoin the cycle on the next online attempt. The protocol step that surfaces the work is `kd /issue touched --git-range <A>..<B>`: a local-only helper that derives touched tickets from a git revision range and never reads the tracker. The strict prefix match is `^[A-Z]+-[0-9]+:` against each commit subject (case-sensitive, anchored, colon-terminated — same shape as the doctrine's `--grep` example), so a commit like `KDCLI-105: make tag create idempotent` registers under `KDCLI-105` while `Revert "KDCLI-105: ..."`, `WIP KDCLI-105: ...`, and `Initial commit` go to `meta.unmatched_commits` as `{sha, subject}` objects. Tickets list in first-occurrence order in `git log` output (reverse-chronological by default); within each ticket, commits keep that order. Empty ranges exit 0 with empty lists. Bad revisions surface git's stderr verbatim through `ValidationError`, and a missing `git` executable converts to a clear `git executable not found; install git or ensure it is on PATH` message — no tracebacks. The helper is local-only by design: no client, no token, no `.kd/` writes. The reconciliation loop itself (push commits, post closeouts, transition state) stays the operator's job; `touched` just enumerates the work.

```bash
kd /issue touched --git-range origin/main..HEAD -o yaml
kd /issue touched --git-range HEAD~10..HEAD --output json | jq '.tickets[].id'
```

## Tags And Discovery

Tags are the main YouTrack-native cross-entity discovery primitive. A namespaced taxonomy such as `kind:*`, `component:*`, and `outcome:*` gives both humans and LLMs a stable way to move across issues and articles.

Start by discovering existing tag names:

```bash
kd /tag list --namespace kind -o yaml
kd /tag list --prefix component: -o yaml
```

Then query membership:

```bash
kd /tag issues kind:note --tag component:authservice -o yaml
kd /tag articles kind:note --tag component:authservice -o yaml
kd /tag entities kind:note --tag component:authservice -o yaml
kd /tag entities --primer-scope -o yaml
```

Use `/tag entities` when the question is "what do we know about this topic across kinds?" Explicit tags mean intersection: `kind:note --tag component:authservice` finds entities that have both tags. Primer scope means union: `--primer-scope` finds entities that have any pinned tag. Use `/tag issues` or `/tag articles` when the kind is already known.

Do not treat `--primer-scope` as implicit global state. It is a deliberate flag for content-management triage and workspace orientation. When you need a precise topical intersection, pass the tags explicitly.

`/tag entities` structured output (`-o yaml` / `-o json`) populates the `tags` field on both issue and article rows with the entity's visible tags, so a primer-scope or explicit-tag match is self-describing — no second `/issue show` round-trip is needed to confirm which tags caused a row to surface. Table output groups by kind and does not render a tag column.

`/tag create TAG_NAME` is idempotent. It resolves the name first (same case-insensitive resolver `/tag show` uses) and returns `{ok, action, tag}` with `action: exists` when the tag is already visible, or `action: create` after a successful POST. Taxonomy bootstrapping and fixture setup can re-run the command safely without decoding `Tag.name-is-invalid`. When the POST still fails — either a genuinely unacceptable name or an existing tag hidden by sharing/visibility — kd surfaces a factual diagnostic naming both plausible causes rather than the raw upstream error.

### Tag Name Resolution And Duplicates

Tags are a **global** YouTrack entity. Two different users can independently create tags with the same display name (e.g., one automation account owns a private `lifecycle:draft` taxonomy and a user re-creates `lifecycle:draft` they cannot see) — both tags are real and both can be visible to a third principal. The case-folded name is therefore not a unique identifier; the tag id (`NN-NN`) is.

`kd` exposes this distinction directly:

- **Name form (`sprint-47`, `lifecycle:draft`).** Used by every tag command. Resolves to exactly one visible tag, or refuses with a structured candidate list listing each id and owner. The resolver never silently picks among duplicates.
- **Id form (`NN-NN`, e.g. `10-178`).** Skips name resolution. Accepted by `/tag show`, `/tag delete`, `/tag rename` (first arg), `/tag add`, `/tag remove`, `/tag articles`, and — with scope limits — `/tag issues` and `/tag entities`. Use the id form to disambiguate when a name collides.

The id-form scope for `/tag issues` and `/tag entities` is narrower because YouTrack's query DSL `tag:` predicate is name-keyed; there is no id-keyed tag predicate. Concretely:

- `/tag issues TAG_NAME_OR_ID` — id form works on the fast path (single tag, no `--project`). Add `--project` or another `--tag`, and the id form is refused with guidance to use the fast path or the name form.
- `/tag entities TAG_NAME_OR_ID` — id form works when the issue half stays on the fast path (single tag, no `--project`) or when the run is restricted to `--kind article` (article filtering is client-side by id). With `--project` or multiple tags AND the issue kind included, id form is refused.

`/tag create TAG_NAME` is the one exception: it refuses on visible-global collision rather than silently returning "the first existing tag", and does not accept an id form (creating with an existing id is meaningless). Inspect each candidate with `kd /tag show <id>` to decide whether to reuse or rename one.

`/tag entities` pre-validates every tag argument before fanout. Ambiguity refusal is therefore the whole-command outcome — duplicate-name refusal is never reported as a per-kind partial-success row.

## Output And Debugging

For deterministic machine consumption, always pass an explicit output format:

```bash
kd /issue list --project KDCLI -o json
kd /primer show -o yaml
```

Raise debug detail progressively:

```bash
kd -D /issue list --project KDCLI
kd -DD /issue list --project KDCLI
kd -DDD /issue list --project KDCLI
```

Debug output goes to stderr and tokens are redacted. Use `-DDD` when investigating upstream API behavior because it includes request and response details.

On Windows, kd forces UTF-8 on stdin, stdout, and stderr at the entry point so non-ASCII characters (`→`, `—`, `≤`, em-dash) render correctly regardless of the console's default code page (cp1252 on most installs), and every kd-owned file read/write (primer, config, history snapshots, `--content @file` and `--description @file`) uses explicit UTF-8 so primer/config files written by macOS or Linux load cleanly on Windows. Stdin uses strict decoding so invalid UTF-8 piped into `kd /primer/note update -` or `kd /article create --content @-` fails loudly with a clear diagnostic (`Error: Stdin input could not be decoded as UTF-8 ...`) rather than silently corrupting persisted content. No `PYTHONIOENCODING` or `PYTHONUTF8` workaround is needed.

Unhandled exceptions render a one-line or one-paragraph friendly diagnostic and exit non-zero. To see the full traceback (for bug reports or local debugging), re-run with `--debug` / `-D`; the wrapper re-raises the original exception so the runtime prints the traceback. `KdError` (expected user-facing failures) keep their existing one-line `Error: ...` / optional `Hint: ...` shape on every platform.

If config resolution is confusing, inspect it directly:

```bash
kd /system/config list
kd /system/config which issue_list.limit
kd /system/config which primer_show.output
```

If a command exits 0 but includes `warnings` in JSON or YAML, keep the primary result and inspect the warning code. For example, `tag_not_found` on `/primer/tag add` means the local primer changed but the upstream tag did not resolve at validation time. In text/md modes the same warnings render to stderr; redirect with `2>` if a script captures them.

### Mutation Tail Line

Every upstream-mutation command uses the write-output contract except `/tag add` (reshaped with a multi-tag `applied[]` envelope in a separate session). For each contracted command, the last line of stdout in text/md modes is a parseable single-line ack:

```
ok: <ID> <action> [key=value ...]
error: <ID> <code>
```

Token order is fixed. `tail -1 | awk '{print $2}'` extracts the entity ID, `tail -1 | awk '{print $3}'` extracts the action, and `tail -1 | awk -F= '/state=/ {print $2}'` extracts a specific field value. Multi-value list fields join with comma (`tags=foo,bar`), not key repetition.

Pass `--quiet` to suppress the detail block above the ack:

```bash
for i in 1 2 3; do
  id=$(kd /issue create "loop $i" --project TST --quiet | tail -1 | awk '{print $2}')
  echo "created: $id"
done
```

`--quiet` is silently ignored on read commands and on structured output modes (`-o yaml` / `-o json`); structured output always returns the full envelope.

Update commands (`/issue update`, `/article update`, `/query update`, `/time update`) carry `changed: [...]` listing every key the call mutated. It is the only signal a body-only update produces (the body is dropped) and the only way to tell a field clear (`--field Sprint=` → `{sprint: "", changed: ["sprint"]}`) apart from a field that was not touched.

`/article push` carries a dry-run carve-out: a dry-run **create** has no upstream article yet and `id` is `null` in the envelope. The tail line carries `dry_run=true` and is **not ID-extractable** via `tail -1 | awk '{print $2}'`. Drop `--dry-run` before relying on tail extraction. Production-create and production-update branches both carry the article ID as expected.

Multi-target commands (`/issue/attachment add`, `/article/attachment add`) carry both `attachments: [<name>, ...]` (scalar names — the source of the tail-line token) and `applied: [{name, size, id}, ...]` (per-file detail). The shape is consistent for both single-file and multi-file calls. The duplication is deliberate so shell loops can read names from the tail token while structured consumers read per-file details from `applied[]`.

When filing a kd bug, include the output of `kd /system info -o yaml`. It names the active connection alongside `kd_version`, `python_version`, and `platform`, so the report is self-describing without hand-typing the version. Redact `url` / `email` before sharing externally.

## Windows Shells

kd works directly from PowerShell and `cmd.exe` on Windows — `kd /system info`, `kd /primer show`, and the rest run as written.

From git-bash (and other MSYS environments), the leading `/` of a kd subcommand path is converted to a Windows path *before* kd ever sees argv, so `kd /primer show` arrives as `kd C:/Program Files/Git/primer show` and falls through to `Unknown command: C:/Program Files/Git/primer`. kd detects this shape on Windows and prints a one-line hint to stderr above the failure.

Per-invocation recovery:

- `MSYS_NO_PATHCONV=1 kd /primer show` — turn MSYS path conversion off for one call.
- `kd //primer show` — the double-slash form MSYS itself documents as "I meant a literal slash."

Recommended permanent fix — a kd-scoped bash alias in `~/.bashrc`:

```bash
alias kd='MSYS_NO_PATHCONV=1 kd'
```

Lowest blast radius: only `kd` invocations are affected. Other MSYS-aware tools (docker volume mounts, MinGW build scripts, etc.) keep their normal path-conversion behavior.

The global form (`export MSYS_NO_PATHCONV=1` in `~/.bashrc` or a Windows-level environment variable via `setx MSYS_NO_PATHCONV 1`) also works but turns path conversion off for *every* program in the shell — that surprises tools that rely on it. Prefer the alias unless you have a deliberate reason to disable conversion globally.

## Where To Go Next

Use these sources together:

- `kd --reference` for exact command syntax.
- `kd --sdlc` for the portable SDLC doctrine (layers, cycle variants,
  verification modes, publication tiers) — the project-agnostic method
  this guide assumes. This guide covers kd-specific operation; `--sdlc`
  covers the method itself.
- `kd /primer show -o yaml` for workspace context.
- `docs/user/01-kd-usage-guide.md` for scenario-driven workflows.
- `docs/how-to/` for task-specific guides.
- `docs/knowledge/` for verified YouTrack API gotchas.
- `docs/design/architecture.md` and ADRs for architectural constraints.

---
Updated: 2026-05-02
