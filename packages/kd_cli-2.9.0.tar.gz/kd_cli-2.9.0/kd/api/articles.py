"""Articles REST API wrapper.

Covers ``/api/articles`` endpoints:
- Articles: list (global + project-scoped), search, get, create, update, delete
- Child articles: list, attach, detach parent
- Comments: list, create
- Attachments: list, get, create, delete

The ``query`` parameter on ``/api/articles`` is undocumented in the
public REST reference but probed-and-supported on the YT tiers kd
targets (current cloud + on-prem 2023.2); ``search_articles`` is the
canonical full-text path. Servers that reject it surface as a 400 with
"unknown parameter" wording, classified at the SDK boundary.
"""

from __future__ import annotations

from kd.api.http import HttpClient
from kd.models import (
    Article,
    ArticleCreate,
    ArticleUpdate,
    Attachment,
    Comment,
    CommentCreate,
    FieldSet,
)

# List fields omit content to keep responses lightweight
_ARTICLE_LIST_FIELDS = str(
    FieldSet(
        "id",
        "idReadable",
        "summary",
        "created",
        "updated",
        "hasChildren",
        project=FieldSet("id", "name"),
        reporter=FieldSet("id", "name"),
        parentArticle=FieldSet("id", "idReadable"),
    )
)

# Tag-scan fields include tags for client-side tag filtering.
# Kept separate from _ARTICLE_LIST_FIELDS so normal article list
# calls don't pay the tag payload cost.
_ARTICLE_TAG_SCAN_FIELDS = str(
    FieldSet(
        "id",
        "idReadable",
        "summary",
        "created",
        "updated",
        "hasChildren",
        project=FieldSet("id", "name"),
        reporter=FieldSet("id", "name"),
        parentArticle=FieldSet("id", "idReadable"),
        tags=FieldSet("id", "name"),
    )
)

# Detail fields include content for single-article views
_ARTICLE_DETAIL_FIELDS = str(
    FieldSet(
        "id",
        "idReadable",
        "summary",
        "content",
        "created",
        "updated",
        "hasChildren",
        project=FieldSet("id", "name"),
        reporter=FieldSet("id", "name"),
        parentArticle=FieldSet("id", "idReadable"),
        tags=FieldSet("id", "name"),
    )
)


_ARTICLE_COMMENT_FIELDS = "id,text,deleted,pinned,author(id,login,name),created,updated"
_ARTICLE_ATTACHMENT_FIELDS = (
    "id,name,size,mimeType,extension,author(id,login,name),created,updated,url"
)


class ArticlesAPI:
    """Articles REST API wrapper (/api/articles)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    # --- List ---

    def list_articles(self, top: int = 50, skip: int = 0) -> list[Article]:
        data = self._http.get(
            "/articles",
            fields=_ARTICLE_LIST_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [Article.model_validate(a) for a in data]

    def list_project_articles(self, project_id: str, top: int = 50, skip: int = 0) -> list[Article]:
        data = self._http.get(
            f"/admin/projects/{project_id}/articles",
            fields=_ARTICLE_LIST_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [Article.model_validate(a) for a in data]

    # --- Search ---

    def search_articles(self, query: str, top: int = 50, skip: int = 0) -> list[Article]:
        data = self._http.get(
            "/articles",
            fields=_ARTICLE_LIST_FIELDS,
            params={"query": query, "$top": top, "$skip": skip},
        )
        return [Article.model_validate(a) for a in data]

    # --- Tag scan (articles with tags for client-side filtering) ---

    def list_articles_with_tags(self, top: int = 50, skip: int = 0) -> list[Article]:
        data = self._http.get(
            "/articles",
            fields=_ARTICLE_TAG_SCAN_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [Article.model_validate(a) for a in data]

    def list_project_articles_with_tags(
        self, project_id: str, top: int = 50, skip: int = 0
    ) -> list[Article]:
        data = self._http.get(
            f"/admin/projects/{project_id}/articles",
            fields=_ARTICLE_TAG_SCAN_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [Article.model_validate(a) for a in data]

    # --- Get ---

    def get_article(self, article_id: str) -> Article:
        data = self._http.get(
            f"/articles/{article_id}",
            fields=_ARTICLE_DETAIL_FIELDS,
        )
        return Article.model_validate(data)

    # --- Children ---

    def list_child_articles(self, article_id: str, top: int = 50, skip: int = 0) -> list[Article]:
        data = self._http.get(
            f"/articles/{article_id}/childArticles",
            fields=_ARTICLE_LIST_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [Article.model_validate(a) for a in data]

    # --- Create / Update / Delete ---

    def create_article(self, article: ArticleCreate) -> Article:
        data = self._http.post(
            "/articles",
            json=article.model_dump(by_alias=True, exclude_none=True),
            fields=_ARTICLE_DETAIL_FIELDS,
        )
        return Article.model_validate(data)

    def update_article(self, article_id: str, update: ArticleUpdate) -> Article:
        data = self._http.post(
            f"/articles/{article_id}",
            json=update.model_dump(by_alias=True, exclude_none=True),
            fields=_ARTICLE_DETAIL_FIELDS,
        )
        return Article.model_validate(data)

    def delete_article(self, article_id: str) -> None:
        self._http.delete(f"/articles/{article_id}")

    # --- Comments ---

    def list_article_comments(self, article_id: str) -> list[Comment]:
        data = self._http.get(
            f"/articles/{article_id}/comments",
            fields=_ARTICLE_COMMENT_FIELDS,
        )
        return [Comment.model_validate(c) for c in data]

    def create_article_comment(self, article_id: str, comment: CommentCreate) -> Comment:
        data = self._http.post(
            f"/articles/{article_id}/comments",
            json=comment.model_dump(exclude_none=True),
            fields=_ARTICLE_COMMENT_FIELDS,
        )
        return Comment.model_validate(data)

    # --- Attachments ---

    def list_article_attachments(self, article_id: str) -> list[Attachment]:
        data = self._http.get(
            f"/articles/{article_id}/attachments",
            fields=_ARTICLE_ATTACHMENT_FIELDS,
        )
        return [Attachment.model_validate(a) for a in data]

    def get_article_attachment(self, article_id: str, attachment_id: str) -> Attachment:
        data = self._http.get(
            f"/articles/{article_id}/attachments/{attachment_id}",
            fields=_ARTICLE_ATTACHMENT_FIELDS,
        )
        return Attachment.model_validate(data)

    def create_article_attachment(
        self, article_id: str, file_name: str, file_content: bytes
    ) -> Attachment:
        data = self._http.post_file(
            f"/articles/{article_id}/attachments",
            file_name=file_name,
            file_content=file_content,
            fields=_ARTICLE_ATTACHMENT_FIELDS,
        )
        if isinstance(data, list):
            return Attachment.model_validate(data[0])
        return Attachment.model_validate(data)

    def delete_article_attachment(self, article_id: str, attachment_id: str) -> None:
        self._http.delete(f"/articles/{article_id}/attachments/{attachment_id}")

    # --- Hierarchy ---

    def attach_child_article(self, parent_id: str, child_id: str) -> None:
        """Attach an existing article as a child of another."""
        self._http.post(
            f"/articles/{parent_id}/childArticles",
            json={"id": child_id},
        )

    def detach_parent_article(self, article_id: str) -> None:
        """Remove an article's parent (move to project root).

        Uses POST update with parentArticle set to null.
        """
        self._http.post(
            f"/articles/{article_id}",
            json={"parentArticle": None},
        )
