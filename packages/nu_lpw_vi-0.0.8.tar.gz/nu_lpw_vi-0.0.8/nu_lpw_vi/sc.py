def doc():
  print(r"""
| Function | Description |
|:--------:|-------------|
| p1() | TSP(Brute, NN), 8-Puzzle(Simple, Steepest-Ascent) |
| p2() | 0/1 knapsack GA |
| p3() | Symmetric TSP using GA |
| p4() | Document Clustering using GA |
| p5() | Symmetric TSP using ANT |
| p6() | Document Clustering using ANT |
| p7() | Membership functions for fuzzy set |
| p8() | Fuzzy C Means Algorithm) |

""")

def p1():
    print(r"""
          
----------------------TSP BRUTE----------------------
#include <bits/stdc++.h>
using namespace std;

long long bruteForceTSP(const vector<vector<int>> &dist, int n)
{
    vector<int> cities;
    for (int i = 1; i < n; i++)
        cities.push_back(i);

    long long best = LLONG_MAX;

    do
    {
        long long curr = 0;
        int prev = 0;

        for (int c : cities)
        {
            curr += dist[prev][c];
            prev = c;
        }

        curr += dist[prev][0];

        best = min(best, curr);

    } while (next_permutation(cities.begin(), cities.end()));

    return best;
}

int main()
{
    srand(time(0));

    ofstream csvFile("tsp_bruteforce_results.csv");
    csvFile << "number_of_nodes,duration,best_cost\n";

    for (int n = 2; n <= 13; n++)
    {
        vector<vector<int>> dist(n, vector<int>(n));

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                    dist[i][j] = 0;
                else
                    dist[i][j] = rand() % 100 + 1;
            }
        }

        using Clock = chrono::high_resolution_clock;
        auto start_time = Clock::now();

        long long best = bruteForceTSP(dist, n);

        auto end_time = Clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(end_time - start_time);

        csvFile << n << "," << duration.count() << "," << best << "\n";
    }

    csvFile.close();
    return 0;
}


-----------------------------TSP NN---------------------------------
#include <iostream>
#include <vector>
#include <climits>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <string>
#include <fstream>

using namespace std;

int rec(int start, int node, int n, vector<vector<pair<int, int>>> &adj, vector<bool> &visited)
{

    visited[node] = true;
    int cost = 0;
    int minNode = -1;
    int minDist = INT_MAX;
    for (auto it : adj[node])
    {
        if (!visited[it.first] && it.second < minDist)
        {
            minNode = it.first;
            minDist = it.second;
        }
    }
    if (minNode == -1)
        return adj[node][start].second;
    cost += (minDist + rec(start, minNode, n, adj, visited));
    return cost;
}

int main()
{
    srand(time(0));

    ofstream csvFile("tsp_nn_results.csv");
    csvFile << "number_of_nodes,duration\n";

    for (int i = 2; i <= 10000; i++)
    {
        int n = i;
        vector<vector<pair<int, int>>> adj(n);
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i != j)
                {
                    int weight = rand() % 100 + 1;
                    adj[i].push_back({j, weight});
                }
            }
        }

        vector<bool> visited(n, false);
        using Clock = std::chrono::high_resolution_clock;
        using std::chrono::milliseconds;
        auto start_time = Clock::now();

        int cost = rec(0, 0, n - 1, adj, visited);

        auto end_time = Clock::now();
        auto duration_native = end_time - start_time;
        csvFile << n << "," << duration_native.count() << "\n";
    }
    csvFile.close();

    return 0;
}

-----------------------------8-Puzzle-Simple------------------------
#include <iostream>
#include <vector>
#include <map>
#include <utility>
#include <chrono>
#include <thread>

using namespace std;

void printBoard(const vector<vector<int>> &arr)
{
    for (auto &row : arr)
    {
        for (auto &x : row)
        {
            if (x == -1)
                cout << "  ";
            else
                cout << x << " ";
        }
        cout << endl;
    }
    cout << endl;
}

int misplacedTiles(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    int cnt = 0;
    int m = arr.size();
    int n = arr[0].size();
    map<int, pair<int, int>> mpp;

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1 && (mpp[arr[i][j]].first != i || mpp[arr[i][j]].second != j))
            {
                cnt++;
            }
        }
    }
    return cnt;
}

int manhattan(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    map<int, pair<int, int>> mpp;
    int m = arr.size();
    int dist = 0;
    int n = arr[0].size();
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1)
            {
                dist += abs(i - mpp[arr[i][j]].first) + abs(j - mpp[arr[i][j]].second);
            }
        }
    }
    return dist;
}

bool recTiles(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;
    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};
    int currMisplacedTiles = misplacedTiles(arr, goal);
    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];
        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            char move;
            if (i == 0)
            {
                move = 'U';
            }
            else if (i == 1)
            {
                move = 'R';
            }
            else if (i == 2)
            {
                move = 'D';
            }
            else
            {
                move = 'L';
            }
            swap(arr[row][col], arr[nrow][ncol]);
            int newMisplacedTiles = misplacedTiles(arr, goal);
            if (newMisplacedTiles < currMisplacedTiles)
            {
                str.push_back(move);
                if (recTiles(nrow, ncol, arr, goal, str))
                    return true;
                str.pop_back();
            }
            swap(arr[row][col], arr[nrow][ncol]);
        }
    }
    return false;
}

bool recDist(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;
    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};
    int currDistance = manhattan(arr, goal);
    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];
        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            char move;
            if (i == 0)
            {
                move = 'U';
            }
            else if (i == 1)
            {
                move = 'R';
            }
            else if (i == 2)
            {
                move = 'D';
            }
            else
            {
                move = 'L';
            }
            swap(arr[row][col], arr[nrow][ncol]);
            int newDistance = manhattan(arr, goal);
            if (newDistance < currDistance)
            {
                str.push_back(move);

                // system("cls");
                // printBoard(arr);
                // std::this_thread::sleep_for(std::chrono::milliseconds(400));

                if (recDist(nrow, ncol, arr, goal, str))
                    return true;

                str.pop_back();
            }

            swap(arr[row][col], arr[nrow][ncol]);
        }
    }
    return false;
}

int main()
{
    vector<vector<int>> arr(3, vector<int>(3));
    vector<vector<int>> goal(3, vector<int>(3));

    cout << "Enter Your Start Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> arr[i][j];

    cout << "Enter Your Solved Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> goal[i][j];
    int choice;
    cout << "Enter Your Choice\n'1' -> Manhattan Distance\n'2' -> Number of Misplaced Tiles" << endl;
    cin >> choice;
    string str;

    int br = -1, bc = -1;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (arr[i][j] == -1)
            {
                br = i;
                bc = j;
            }

    if (choice == 1)
    {
        recDist(br, bc, arr, goal, str);
        cout << str;
    }
    else if (choice == 2)
    {
        recTiles(br, bc, arr, goal, str);
        cout << str;
    }
    else
    {
        cout << "Enter valid choice";
    }

    return 0;
}

// arr = {{1, 2, 3}, {4, -1, 6}, {7, 5, 8}}
// goal = {{1, 2, 3}, {4, 5, 6}, {7, 8, -1}}

-------------------8-Puzzle-Steepest-Ascent------------------------
#include <bits/stdc++.h>

using namespace std;
int misplacedTiles(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    int cnt = 0;
    int m = arr.size();
    int n = arr[0].size();
    map<int, pair<int, int>> mpp;

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1 && (mpp[arr[i][j]].first != i || mpp[arr[i][j]].second != j))
            {
                cnt++;
            }
        }
    }
    return cnt;
}

int manhattan(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    map<int, pair<int, int>> mpp;
    int m = arr.size();
    int dist = 0;
    int n = arr[0].size();
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1)
            {
                dist += abs(i - mpp[arr[i][j]].first) + abs(j - mpp[arr[i][j]].second);
            }
        }
    }
    return dist;
}

bool recTiles(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;

    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};

    int currTiles = misplacedTiles(arr, goal);
    int minTiles = INT_MAX;

    char optMove;
    int optNrow = -1, optNcol = -1;

    bool foundBetter = false;
    bool foundEqual = false;

    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];

        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            swap(arr[nrow][ncol], arr[row][col]);
            int newTiles = misplacedTiles(arr, goal);

            if (newTiles < currTiles)
            {
                foundBetter = true;
            }
            else if (newTiles == currTiles)
            {
                foundEqual = true;
            }

            if (newTiles < minTiles)
            {
                minTiles = newTiles;
                optMove = (i == 0 ? 'U' : i == 1 ? 'R'
                                      : i == 2   ? 'D'
                                                 : 'L');
                optNrow = nrow;
                optNcol = ncol;
            }

            swap(arr[nrow][ncol], arr[row][col]);
        }
    }

    if (!foundBetter)
    {
        if (foundEqual)
            cout << "Plateau detected\n";
        else
            cout << "Local maxima detected\n";
        return false;
    }

    swap(arr[row][col], arr[optNrow][optNcol]);
    str.push_back(optMove);

    if (recTiles(optNrow, optNcol, arr, goal, str))
        return true;

    str.pop_back();
    swap(arr[row][col], arr[optNrow][optNcol]);

    return false;
}

bool recDist(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;

    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};

    int currDistance = manhattan(arr, goal);
    int minDistance = INT_MAX;

    char optMove;
    int optNrow = -1, optNcol = -1;

    bool foundBetter = false;
    bool foundEqual = false;

    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];

        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            swap(arr[nrow][ncol], arr[row][col]);
            int newDist = manhattan(arr, goal);

            if (newDist < currDistance)
            {
                foundBetter = true;
            }
            else if (newDist == currDistance)
            {
                foundEqual = true;
            }

            if (newDist < minDistance)
            {
                minDistance = newDist;
                optMove = (i == 0 ? 'U' : i == 1 ? 'R'
                                      : i == 2   ? 'D'
                                                 : 'L');
                optNrow = nrow;
                optNcol = ncol;
            }

            swap(arr[nrow][ncol], arr[row][col]);
        }
    }

    if (!foundBetter)
    {
        if (foundEqual)
            cout << "Plateau detected\n";
        else
            cout << "Local maxima detected\n";
        return false;
    }

    swap(arr[row][col], arr[optNrow][optNcol]);
    str.push_back(optMove);

    if (recDist(optNrow, optNcol, arr, goal, str))
        return true;

    str.pop_back();
    swap(arr[row][col], arr[optNrow][optNcol]);

    return false;
}

int main()
{
    vector<vector<int>> arr(3, vector<int>(3));
    vector<vector<int>> goal(3, vector<int>(3));

    cout << "Enter Your Start Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> arr[i][j];

    cout << "Enter Your Solved Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> goal[i][j];
    int choice;
    cout << "Enter Your Choice\n'1' -> Manhattan Distance\n'2' -> Number of Misplaced Tiles";
    cout << endl;
    cin >> choice;
    string str;

    int br = -1, bc = -1;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (arr[i][j] == -1)
            {
                br = i;
                bc = j;
            }

    if (choice == 1)
    {
        recDist(br, bc, arr, goal, str);
        cout << str;
    }
    else if (choice == 2)
    {
        recTiles(br, bc, arr, goal, str);
        cout << str;
    }
    else
    {
        cout << "Enter valid choice";
    }

    return 0;
}
""")

def p2():
    print("""
---------------------------Genetic Algorithm-------------------------
#include <bits/stdc++.h>
using namespace std;

int n;
int capacity;
vector<int> weight, value;

const int POP_SIZE = 10;
const int GENERATIONS = 200;

mt19937 rng(time(0));

vector<int> randomChromosome()
{
    vector<int> ch(n);
    for (int i = 0; i < n; i++)
    {
        ch[i] = rng() % 2;
    }
    return ch;
}

int fitness(const vector<int> &ch)
{
    int totalW = 0, totalV = 0;
    for (int i = 0; i < n; i++)
    {
        if (ch[i])
        {
            totalW += weight[i];
            totalV += value[i];
        }
    }
    if (totalW > capacity)
        return 0;
    return totalV;
}

vector<int> rouletteSelect(const vector<vector<int>> &population,
                           const vector<int> &fit)
{
    int sum = accumulate(fit.begin(), fit.end(), 0);

    if (sum == 0)
    {
        return population[rng() % POP_SIZE];
    }

    int r = rng() % sum;
    int curr = 0;
    for (int i = 0; i < POP_SIZE; i++)
    {
        curr += fit[i];
        if (curr > r)
        {
            return population[i];
        }
    }
    return population.back();
}

pair<vector<int>, vector<int>> crossover(const vector<int> &p1,
                                         const vector<int> &p2)
{
    vector<int> c1 = p1, c2 = p2;

    int point = rng() % n;

    for (int i = point; i < n; i++)
    {
        swap(c1[i], c2[i]);
    }

    return {c1, c2};
}

pair<vector<int>, vector<int>> kPointCrossover(const vector<int> &p1,
                                               const vector<int> &p2,
                                               int k)
{
    int n = p1.size();
    vector<int> c1 = p1, c2 = p2;

    if (k > 0)
    {
        k = min(k, n - 1);

        vector<int> points;
        unordered_set<int> used;

        while ((int)points.size() < k)
        {
            int pt = rng() % (n - 1) + 1;
            if (!used.count(pt))
            {
                used.insert(pt);
                points.push_back(pt);
            }
        }

        sort(points.begin(), points.end());

        bool takeFromP1 = true;
        int prev = 0;

        for (int cut : points)
        {
            for (int i = prev; i < cut; i++)
            {
                if (!takeFromP1)
                    swap(c1[i], c2[i]);
            }
            takeFromP1 = !takeFromP1;
            prev = cut;
        }

        for (int i = prev; i < n; i++)
        {
            if (!takeFromP1)
                swap(c1[i], c2[i]);
        }
    }

    return {c1, c2};
}

void mutateOneBit(vector<int> &ch)
{
    int idx = rng() % n;
    ch[idx] = 1 - ch[idx];
}

int main()
{
    cout << "Enter number of items: ";
    cin >> n;

    weight.resize(n);
    value.resize(n);

    cout << "Enter weights:\n";
    for (int i = 0; i < n; i++)
        cin >> weight[i];

    cout << "Enter values:\n";
    for (int i = 0; i < n; i++)
        cin >> value[i];

    cout << "Enter knapsack capacity: ";
    cin >> capacity;

    vector<vector<int>> population;
    for (int i = 0; i < POP_SIZE; i++)
    {
        population.push_back(randomChromosome());
    }

    vector<int> bestEver;
    int bestFitness = 0;

    for (int gen = 0; gen < GENERATIONS; gen++)
    {
        vector<int> fit(POP_SIZE);
        for (int i = 0; i < POP_SIZE; i++)
        {
            fit[i] = fitness(population[i]);
            if (fit[i] > bestFitness)
            {
                bestFitness = fit[i];
                bestEver = population[i];
            }
        }

        vector<vector<int>> newPop;

        while ((int)newPop.size() < POP_SIZE)
        {
            vector<int> p1 = rouletteSelect(population, fit);
            vector<int> p2 = rouletteSelect(population, fit);

            auto [c1, c2] = crossover(p1, p2);

            mutateOneBit(c1);
            mutateOneBit(c2);

            newPop.push_back(c1);
            if ((int)newPop.size() < POP_SIZE)
                newPop.push_back(c2);
        }

        population = newPop;
    }

    cout << "\nBest solution found:\n";
    cout << "Chromosome: ";
    for (int b : bestEver)
        cout << b << " ";
    cout << "\nMaximum Value: " << bestFitness << "\n";

    int finalWeight = 0;
    for (int i = 0; i < n; i++)
    {
        if (bestEver[i])
            finalWeight += weight[i];
    }
    cout << "Total Weight: " << finalWeight << "\n";

    return 0;
}

""")

def p3():
    print("""
-------------------------TSP-Genetic-------------------------------
#include <bits/stdc++.h>
using namespace std;

int GENERATIONS = 200;
mt19937 rng(time(0));
vector<int> arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
vector<vector<int>> allPerms;
vector<vector<int>> population;

void generateInitialPopulation()
{
    while (population.size() < 10)
    {
        int index = rng() % 3628800;
        population.push_back(allPerms[index]);
    }
}
void generatePermutations(int index, vector<int> &arr, vector<vector<int>> &ans)
{
    if (index == arr.size())
    {
        ans.push_back(arr);
        return;
    }
    for (int i = index; i < arr.size(); i++)
    {
        swap(arr[index], arr[i]);
        generatePermutations(index + 1, arr, ans);
        swap(arr[index], arr[i]);
    }
}

int main()
{
    vector<vector<int>> cost = {{0, 29, 20, 21, 16, 31, 100, 12, 4, 31},
                                {29, 0, 15, 29, 28, 40, 72, 21, 29, 41},
                                {20, 15, 0, 15, 14, 25, 81, 9, 23, 27},
                                {21, 29, 15, 0, 4, 12, 92, 12, 25, 13},
                                {16, 28, 14, 4, 0, 16, 94, 9, 20, 16},
                                {31, 40, 25, 12, 16, 0, 95, 24, 36, 3},
                                {100, 72, 81, 92, 94, 95, 0, 90, 101, 99},
                                {12, 21, 9, 12, 9, 24, 90, 0, 15, 25},
                                {4, 29, 23, 25, 20, 36, 101, 15, 0, 35},
                                {31, 41, 27, 13, 16, 3, 99, 25, 35, 0}};
    generatePermutations(0, arr, allPerms);
    generateInitialPopulation();
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < population.size(); j++)
        {
            cout << population[i][j] << ((j == 9) ? "" : ", ");
        }
        cout << endl;
    }
    vector<int> best = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    int bestFitness = INT_MAX;
    for (int i = 0; i < GENERATIONS; i++)
    {
        vector<int> fit(10);
        for (int j = 0; j < population.size(); j++)
        {
            vector<int> temp = population[j];
            int currCost = 0;
            for (int k = 0; k < temp.size() - 1; k++)
            {
                currCost += cost[temp[k] - 1][temp[k + 1] - 1];
            }
            currCost += cost[temp[9] - 1][temp[0] - 1];
            fit[j] = currCost;
            if (currCost < bestFitness)
            {
                bestFitness = currCost;
                best = temp;
            }
        }

        vector<vector<int>> newPop;
        while (newPop.size() < 10)
        {
            vector<int> parent1;
            vector<int> parent2;
            int maxEl = *max_element(fit.begin(), fit.end());
            int sum = 0;
            vector<int> weight(10);
            for (int j = 0; j < 10; j++)
            {
                weight[j] = (maxEl - fit[j]) + 1;
                sum += weight[j];
            }
            int randomNumber1 = rng() % sum;
            int curr = 0;
            for (int j = 0; j < 10; j++)
            {
                curr += weight[j];
                if (curr > randomNumber1)
                {
                    parent1 = population[j];
                    break;
                }
            }
            int randomNumber2 = rng() % sum;
            curr = 0;
            for (int j = 0; j < 10; j++)
            {
                curr += weight[j];
                if (curr > randomNumber2)
                {
                    parent2 = population[j];
                    break;
                }
            }
            int randomIndex = rng() % 10;

            vector<int> child1 = parent1;
            set<int> used;
            for (int j = 0; j < randomIndex; j++)
            {
                used.insert(parent1[j]);
            }
            int ptr = 0;
            for (int j = randomIndex; j < 10; j++)
            {
                while (used.find(parent2[ptr]) != used.end())
                    ptr++;
                child1[j] = parent2[ptr];
                used.insert(parent2[ptr]);
                ptr++;
            }
            newPop.push_back(child1);
        }
        population = newPop;
        for (int j = 0; j < 10; j++)
        {
            cout << best[j] << ((j == 9) ? "" : ", ");
        }
        cout << endl;
        cout << bestFitness;
        cout << endl;
        cout << endl;
        cout << endl;
    }

    return 0;
}
""")

def p4():
    print("""
-----------------------Clustering using GA--------------------------
import numpy as np
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
---------------------------------------------------------------------
documents = [
    "Artificial intelligence and machine learning",
    "Deep learning and neural networks",
    "Football and cricket are popular sports",
    "Sports like football and basketball",
    "AI is transforming the world",
    "Cricket is a famous sport"
]
---------------------------------------------------------------------
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(documents).toarray()

num_docs = len(documents)
---------------------------------------------------------------------
num_clusters = 2
population_size = 10
generations = 50
mutation_rate = 0.1
---------------------------------------------------------------------
def create_chromosome():
    return [random.randint(0, num_clusters - 1) for _ in range(num_docs)]
---------------------------------------------------------------------
def fitness(chromosome):
    similarity_matrix = cosine_similarity(X)

    intra_sim = 0
    inter_sim = 0
    intra_count = 0
    inter_count = 0

    for i in range(num_docs):
        for j in range(i + 1, num_docs):
            if chromosome[i] == chromosome[j]:
                intra_sim += similarity_matrix[i][j]
                intra_count += 1
            else:
                inter_sim += similarity_matrix[i][j]
                inter_count += 1

    if intra_count == 0 or inter_count == 0:
        return 0

    return (intra_sim / intra_count) - (inter_sim / inter_count)
---------------------------------------------------------------------
def initialize_population():
    return [create_chromosome() for _ in range(population_size)]
---------------------------------------------------------------------
def selection(population):
    tournament_size = 3
    selected = random.sample(population, tournament_size)
    selected.sort(key=lambda x: fitness(x), reverse=True)
    return selected[0]
---------------------------------------------------------------------
def crossover(parent1, parent2):
    point = random.randint(1, num_docs - 2)
    child = parent1[:point] + parent2[point:]
    return child
---------------------------------------------------------------------
def mutate(chromosome):
    for i in range(num_docs):
        if random.random() < mutation_rate:
            chromosome[i] = random.randint(0, num_clusters - 1)
    return chromosome
---------------------------------------------------------------------
def genetic_algorithm():
    population = initialize_population()

    best_solution = None
    best_fitness = float('-inf')

    for gen in range(generations):
        new_population = []

        for _ in range(population_size):
            parent1 = selection(population)
            parent2 = selection(population)

            child = crossover(parent1, parent2)
            child = mutate(child)

            new_population.append(child)

        population = new_population

        # Track best solution
        for chrom in population:
            f = fitness(chrom)
            if f > best_fitness:
                best_fitness = f
                best_solution = chrom

        print(f"Generation {gen+1}, Best Fitness: {best_fitness:.4f}")

    return best_solution
---------------------------------------------------------------------
best_clustering = genetic_algorithm()
---------------------------------------------------------------------
print("\nFinal Clustering:")

clusters = {i: [] for i in range(num_clusters)}

for i, cluster_id in enumerate(best_clustering):
    clusters[cluster_id].append(documents[i])

for cluster_id, docs in clusters.items():
    print(f"\nCluster {cluster_id}:")
    for doc in docs:
        print(" -", doc)
""")

def p5():
    print("""
--------------------Symmetric TSP using ANT-------------------------
#include <bits/stdc++.h>
using namespace std;

class AntColonyTSP
{
private:
    int numCities;
    int numAnts;
    int maxIterations;

    double alpha; // pheromone importance
    double beta;  // heuristic importance
    double evaporationRate;
    double Q; // pheromone deposit factor

    vector<vector<double>> distanceMatrix;
    vector<vector<double>> pheromoneMatrix;

    mt19937 rng;

public:
    AntColonyTSP(vector<vector<double>> dist, int ants, int iterations)
    {
        distanceMatrix = dist;
        numCities = dist.size();
        numAnts = ants;
        maxIterations = iterations;

        alpha = 1.0;
        beta = 5.0;
        evaporationRate = 0.5;
        Q = 100.0;

        pheromoneMatrix.assign(numCities, vector<double>(numCities, 1.0));

        rng.seed(chrono::steady_clock::now().time_since_epoch().count());
    }

    double getDistance(int i, int j)
    {
        return distanceMatrix[i][j];
    }

    double calculateTourLength(const vector<int> &tour)
    {
        double length = 0.0;
        for (int i = 0; i < numCities - 1; i++)
        {
            length += getDistance(tour[i], tour[i + 1]);
        }
        length += getDistance(tour.back(), tour[0]); // return to start
        return length;
    }

    int selectNextCity(int currentCity, vector<bool> &visited)
    {
        vector<double> probabilities(numCities, 0.0);
        double total = 0.0;

        for (int j = 0; j < numCities; j++)
        {
            if (!visited[j])
            {
                double tau = pow(pheromoneMatrix[currentCity][j], alpha);
                double eta = pow(1.0 / getDistance(currentCity, j), beta);

                probabilities[j] = tau * eta;
                total += probabilities[j];
            }
        }

        uniform_real_distribution<double> dist(0.0, total);
        double randomValue = dist(rng);

        double cumulative = 0.0;
        for (int j = 0; j < numCities; j++)
        {
            if (!visited[j])
            {
                cumulative += probabilities[j];
                if (cumulative >= randomValue)
                    return j;
            }
        }

        // fallback
        for (int j = 0; j < numCities; j++)
        {
            if (!visited[j])
                return j;
        }

        return -1;
    }

    vector<int> constructTour(int startCity)
    {
        vector<int> tour;
        vector<bool> visited(numCities, false);

        int currentCity = startCity;
        tour.push_back(currentCity);
        visited[currentCity] = true;

        for (int i = 1; i < numCities; i++)
        {
            int nextCity = selectNextCity(currentCity, visited);
            tour.push_back(nextCity);
            visited[nextCity] = true;
            currentCity = nextCity;
        }

        return tour;
    }

    void updatePheromones(const vector<vector<int>> &allTours,
                          const vector<double> &tourLengths)
    {

        // Evaporation
        for (int i = 0; i < numCities; i++)
        {
            for (int j = 0; j < numCities; j++)
            {
                pheromoneMatrix[i][j] *= (1.0 - evaporationRate);
            }
        }

        // Deposit
        for (int k = 0; k < numAnts; k++)
        {
            double contribution = Q / tourLengths[k];
            const vector<int> &tour = allTours[k];

            for (int i = 0; i < numCities - 1; i++)
            {
                int u = tour[i];
                int v = tour[i + 1];

                pheromoneMatrix[u][v] += contribution;
                pheromoneMatrix[v][u] += contribution; // symmetric
            }

            // last edge
            int last = tour.back();
            int first = tour[0];
            pheromoneMatrix[last][first] += contribution;
            pheromoneMatrix[first][last] += contribution;
        }
    }

    pair<vector<int>, double> solve()
    {
        vector<int> bestTour;
        double bestLength = DBL_MAX;

        for (int iter = 0; iter < maxIterations; iter++)
        {
            vector<vector<int>> allTours;
            vector<double> tourLengths;

            for (int k = 0; k < numAnts; k++)
            {
                int startCity = k % numCities;
                vector<int> tour = constructTour(startCity);

                double length = calculateTourLength(tour);

                allTours.push_back(tour);
                tourLengths.push_back(length);

                if (length < bestLength)
                {
                    bestLength = length;
                    bestTour = tour;
                }
            }

            updatePheromones(allTours, tourLengths);
        }

        return {bestTour, bestLength};
    }
};

int main()
{
    vector<vector<double>> dist = {
        {0, 10, 15, 20},
        {10, 0, 35, 25},
        {15, 35, 0, 30},
        {20, 25, 30, 0}};

    AntColonyTSP solver(dist, 10, 100);

    auto result = solver.solve();

    cout << "Best Tour: ";
    for (int city : result.first)
        cout << city << " ";
    cout << endl;

    cout << "Tour Length: " << result.second << endl;

    return 0;
}
""")

def p6():
    print("""
------------------Document Clusterng using ANT--------------------
#include <bits/stdc++.h>
using namespace std;

/*
DOCUMENT CLUSTERING USING ANT COLONY OPTIMIZATION

Steps:
1. Initialize documents with feature vectors
2. Place randomly on grid
3. Initialize ants
4. Iterate:
   - Move ants randomly
   - Pick or drop documents based on similarity
5. Output clustered grid
*/

struct Document
{
    vector<double> features;
    int id;
};

struct Cell
{
    bool hasDoc;
    Document doc;
};

struct Ant
{
    int x, y;
    bool carrying;
    Document carriedDoc;
};

class AntClustering
{
private:
    int gridSize;
    int numAnts;
    int maxSteps;
    double k1, k2;
    vector<vector<Cell>> grid;
    vector<Ant> ants;
    vector<Document> documents;

public:
    AntClustering(int g, int a, int steps)
        : gridSize(g), numAnts(a), maxSteps(steps), k1(0.1), k2(0.3)
    {
        grid.resize(gridSize, vector<Cell>(gridSize));
    }

    // -----------------------------
    // Generate Random Documents
    // -----------------------------
    void generateDocuments(int numDocs, int dim)
    {
        srand(time(0));
        for (int i = 0; i < numDocs; i++)
        {
            Document d;
            d.id = i;
            for (int j = 0; j < dim; j++)
            {
                d.features.push_back((double)rand() / RAND_MAX);
            }
            documents.push_back(d);
        }
    }

    // -----------------------------
    // Place Documents Randomly
    // -----------------------------
    void placeDocuments()
    {
        for (auto &doc : documents)
        {
            while (true)
            {
                int x = rand() % gridSize;
                int y = rand() % gridSize;
                if (!grid[x][y].hasDoc)
                {
                    grid[x][y].hasDoc = true;
                    grid[x][y].doc = doc;
                    break;
                }
            }
        }
    }

    // -----------------------------
    // Initialize Ants
    // -----------------------------
    void initAnts()
    {
        for (int i = 0; i < numAnts; i++)
        {
            Ant a;
            a.x = rand() % gridSize;
            a.y = rand() % gridSize;
            a.carrying = false;
            ants.push_back(a);
        }
    }

    // -----------------------------
    // Euclidean Distance
    // -----------------------------
    double distance(const Document &a, const Document &b)
    {
        double sum = 0;
        for (int i = 0; i < a.features.size(); i++)
        {
            sum += pow(a.features[i] - b.features[i], 2);
        }
        return sqrt(sum);
    }

    // -----------------------------
    // Local Similarity Function
    // -----------------------------
    double localSimilarity(int x, int y, const Document &doc)
    {
        int radius = 1;
        double sum = 0;
        int count = 0;

        for (int i = -radius; i <= radius; i++)
        {
            for (int j = -radius; j <= radius; j++)
            {
                int nx = (x + i + gridSize) % gridSize;
                int ny = (y + j + gridSize) % gridSize;

                if (grid[nx][ny].hasDoc)
                {
                    double dist = distance(doc, grid[nx][ny].doc);
                    double sim = max(0.0, 1.0 - dist);
                    sum += sim;
                    count++;
                }
            }
        }

        if (count == 0)
            return 0;
        return sum / count;
    }

    // -----------------------------
    // Move Ant Randomly
    // -----------------------------
    void moveAnt(Ant &a)
    {
        int dx[4] = {1, -1, 0, 0};
        int dy[4] = {0, 0, 1, -1};

        int dir = rand() % 4;
        a.x = (a.x + dx[dir] + gridSize) % gridSize;
        a.y = (a.y + dy[dir] + gridSize) % gridSize;
    }

    // -----------------------------
    // Simulation Step
    // -----------------------------
    void simulate()
    {
        for (int step = 0; step < maxSteps; step++)
        {
            for (auto &ant : ants)
            {

                int x = ant.x, y = ant.y;

                // CASE 1: Not carrying → Try to pick
                if (!ant.carrying && grid[x][y].hasDoc)
                {
                    double f = localSimilarity(x, y, grid[x][y].doc);
                    double p_pick = pow(k1 / (k1 + f), 2);

                    if (((double)rand() / RAND_MAX) < p_pick)
                    {
                        ant.carrying = true;
                        ant.carriedDoc = grid[x][y].doc;
                        grid[x][y].hasDoc = false;
                    }
                }

                // CASE 2: Carrying → Try to drop
                else if (ant.carrying && !grid[x][y].hasDoc)
                {
                    double f = localSimilarity(x, y, ant.carriedDoc);
                    double p_drop = (f < k2) ? 2 * f : 1;

                    if (((double)rand() / RAND_MAX) < p_drop)
                    {
                        grid[x][y].hasDoc = true;
                        grid[x][y].doc = ant.carriedDoc;
                        ant.carrying = false;
                    }
                }

                // Move ant
                moveAnt(ant);
            }
        }
    }

    // -----------------------------
    // Print Grid (Cluster Output)
    // -----------------------------
    void printGrid()
    {
        for (int i = 0; i < gridSize; i++)
        {
            for (int j = 0; j < gridSize; j++)
            {
                if (grid[i][j].hasDoc)
                    cout << grid[i][j].doc.id % 10 << " ";
                else
                    cout << ". ";
            }
            cout << "\n";
        }
    }
};

// -----------------------------
// MAIN
// -----------------------------
int main()
{
    int gridSize = 20;
    int numAnts = 50;
    int steps = 10000;

    AntClustering ac(gridSize, numAnts, steps);

    ac.generateDocuments(100, 5); // 100 docs, 5 features
    ac.placeDocuments();
    ac.initAnts();

    ac.simulate();

    cout << "\nClustered Grid:\n";
    ac.printGrid();

    return 0;
}
""")

def p7():
    print("""
----------------------MEMBERSHIP FUNCTIONS FOR FUZZY SETS-----------
#include <iostream>
#include <cmath>
using namespace std;

/*
----------------------------------------
Membership Functions for Fuzzy Sets
----------------------------------------
Each function returns a value in [0, 1]
----------------------------------------
*/

// 1. Triangular Membership Function
double triangularMF(double x, double a, double b, double c)
{
    if (x <= a || x >= c)
        return 0.0;
    else if (x == b)
        return 1.0;
    else if (x > a && x < b)
        return (x - a) / (b - a);
    else
        return (c - x) / (c - b);
}

// 2. Trapezoidal Membership Function
double trapezoidalMF(double x, double a, double b, double c, double d)
{
    if (x <= a || x >= d)
        return 0.0;
    else if (x >= b && x <= c)
        return 1.0;
    else if (x > a && x < b)
        return (x - a) / (b - a);
    else
        return (d - x) / (d - c);
}

// 3. Gaussian Membership Function
double gaussianMF(double x, double mean, double sigma)
{
    return exp(-pow(x - mean, 2) / (2 * pow(sigma, 2)));
}

// 4. Sigmoid Membership Function
double sigmoidMF(double x, double a, double c)
{
    return 1.0 / (1.0 + exp(-a * (x - c)));
}

// 5. Generalized Bell Membership Function
double bellMF(double x, double a, double b, double c)
{
    return 1.0 / (1.0 + pow(abs((x - c) / a), 2 * b));
}

// Utility function to test all MFs
void testMembershipFunctions(double x)
{
    cout << "Input x = " << x << endl;

    cout << "Triangular MF: "
         << triangularMF(x, 0, 5, 10) << endl;

    cout << "Trapezoidal MF: "
         << trapezoidalMF(x, 0, 3, 7, 10) << endl;

    cout << "Gaussian MF: "
         << gaussianMF(x, 5, 2) << endl;

    cout << "Sigmoid MF: "
         << sigmoidMF(x, 1, 5) << endl;

    cout << "Bell MF: "
         << bellMF(x, 2, 4, 5) << endl;

    cout << "---------------------------\n";
}

int main()
{
    // Test with different inputs
    for (double x = 0; x <= 10; x += 1.0)
    {
        testMembershipFunctions(x);
    }

    return 0;
}
""")

def p8():
    print("""
-------------------FUZZY C MEANS ALGORITHM-------------------------
#include <bits/stdc++.h>
using namespace std;

class FuzzyCMeans
{
private:
    int nPoints, nClusters, maxIter;
    double m, epsilon;

    vector<vector<double>> data;       // input data
    vector<vector<double>> membership; // u_ij
    vector<vector<double>> centers;    // cluster centers

public:
    FuzzyCMeans(vector<vector<double>> inputData, int clusters, double fuzziness = 2.0, int iterations = 100, double eps = 1e-5)
    {
        data = inputData;
        nPoints = data.size();
        nClusters = clusters;
        m = fuzziness;
        maxIter = iterations;
        epsilon = eps;

        membership.resize(nPoints, vector<double>(nClusters));
        centers.resize(nClusters, vector<double>(data[0].size()));

        initializeMembership();
    }

    // 🔹 Step 1: Initialize membership randomly
    void initializeMembership()
    {
        srand(time(0));
        for (int i = 0; i < nPoints; i++)
        {
            double sum = 0.0;
            for (int j = 0; j < nClusters; j++)
            {
                membership[i][j] = rand() % 100 + 1;
                sum += membership[i][j];
            }
            for (int j = 0; j < nClusters; j++)
            {
                membership[i][j] /= sum;
            }
        }
    }

    // 🔹 Distance function (Euclidean)
    double distance(vector<double> &a, vector<double> &b)
    {
        double sum = 0;
        for (int i = 0; i < a.size(); i++)
        {
            sum += (a[i] - b[i]) * (a[i] - b[i]);
        }
        return sqrt(sum);
    }

    // 🔹 Step 2: Update cluster centers
    void updateCenters()
    {
        for (int j = 0; j < nClusters; j++)
        {
            vector<double> numerator(data[0].size(), 0.0);
            double denominator = 0.0;

            for (int i = 0; i < nPoints; i++)
            {
                double u = pow(membership[i][j], m);
                for (int d = 0; d < data[0].size(); d++)
                {
                    numerator[d] += u * data[i][d];
                }
                denominator += u;
            }

            for (int d = 0; d < data[0].size(); d++)
            {
                centers[j][d] = numerator[d] / denominator;
            }
        }
    }

    // 🔹 Step 3: Update membership values
    void updateMembership()
    {
        for (int i = 0; i < nPoints; i++)
        {
            for (int j = 0; j < nClusters; j++)
            {
                double sum = 0.0;
                double dist_ij = distance(data[i], centers[j]);

                for (int k = 0; k < nClusters; k++)
                {
                    double dist_ik = distance(data[i], centers[k]);
                    if (dist_ik == 0)
                        dist_ik = 1e-10;

                    sum += pow(dist_ij / dist_ik, 2.0 / (m - 1));
                }

                membership[i][j] = 1.0 / sum;
            }
        }
    }

    // 🔹 Check convergence
    double maxDiff(vector<vector<double>> &oldMem)
    {
        double diff = 0.0;
        for (int i = 0; i < nPoints; i++)
        {
            for (int j = 0; j < nClusters; j++)
            {
                diff = max(diff, fabs(oldMem[i][j] - membership[i][j]));
            }
        }
        return diff;
    }

    // 🔹 Main algorithm
    void run()
    {
        for (int iter = 0; iter < maxIter; iter++)
        {
            vector<vector<double>> oldMem = membership;

            updateCenters();
            updateMembership();

            if (maxDiff(oldMem) < epsilon)
            {
                cout << "Converged at iteration: " << iter << endl;
                break;
            }
        }
    }

    // 🔹 Print results
    void printResults()
    {
        cout << "\nCluster Centers:\n";
        for (int j = 0; j < nClusters; j++)
        {
            cout << "Cluster " << j << ": ";
            for (double val : centers[j])
            {
                cout << val << " ";
            }
            cout << endl;
        }

        cout << "\nMembership Matrix:\n";
        for (int i = 0; i < nPoints; i++)
        {
            for (int j = 0; j < nClusters; j++)
            {
                cout << membership[i][j] << " ";
            }
            cout << endl;
        }
    }
};

// 🔥 Driver Code
int main()
{
    vector<vector<double>> data = {
        {1.0, 2.0}, {1.5, 1.8}, {5.0, 8.0}, {8.0, 8.0}, {1.0, 0.6}, {9.0, 11.0}};

    int clusters = 2;

    FuzzyCMeans fcm(data, clusters);
    fcm.run();
    fcm.printResults();

    return 0;
}
""")