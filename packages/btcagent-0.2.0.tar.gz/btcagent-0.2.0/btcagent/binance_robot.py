import logging
import requests
import hmac
import hashlib
import time
import json
import numpy as np


logger = logging.getLogger(__name__)

btc_symbol = "BTCUSDT"


# Funções auxiliares para criar as requisições à API
def cancel_order(order, symbol, api_key, api_secret):
    """Cancel an open order on Binance.

    Parameters
    ----------
    order : dict
        Order dict containing at least an ``"orderId"`` key.
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``).
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.

    Returns
    -------
    dict
        Binance API cancellation response.
    """
    # Cancela uma ordem
    logger.info("Cancelling order %s", order.get("orderId", order))

    # Endpoint da API para cancelar uma ordem
    import binance

    binance.set(api_key, api_secret)

    return binance.cancel(symbol=symbol, orderId=order["orderId"])


def create_buy_order(quantity, buy_price, symbol, api_key, api_secret):
    """Place a limit buy order on Binance.

    Quantities are truncated to 5 decimal places and prices to 2 decimal
    places before submission.

    Parameters
    ----------
    quantity : float
        Amount of the base asset to buy.
    buy_price : float
        Limit price in quote asset.
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``).
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.

    Returns
    -------
    dict
        Binance API order response.
    """
    quantity = int(quantity / 0.00001) * 0.00001
    buy_price = int(buy_price / 0.01) * 0.01
    # Compre a mercado
    logger.info("Placing BUY order: quantity=%.5f price=%.2f symbol=%s", quantity, buy_price, symbol)
    import binance

    binance.set(api_key, api_secret)
    # Retornando a resposta da API
    return binance.order(
        symbol=symbol,
        side="BUY",
        quantity=quantity,
        price=buy_price,
    )


def create_sell_order(quantity, sell_price, symbol, api_key, api_secret):
    """Place a limit sell order on Binance.

    Quantities are truncated to 5 decimal places and prices to 2 decimal
    places before submission.

    Parameters
    ----------
    quantity : float
        Amount of the base asset to sell.
    sell_price : float
        Limit price in quote asset.
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``).
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.

    Returns
    -------
    dict
        Binance API order response.
    """
    quantity = int(quantity / 0.00001) * 0.00001
    sell_price = int(sell_price / 0.01) * 0.01

    # Venda a mercado
    logger.info("Placing SELL order: quantity=%.5f price=%.2f symbol=%s", quantity, sell_price, symbol)
    # Endpoint da API para criar uma nova ordem
    import binance

    binance.set(api_key, api_secret)
    # Retornando a resposta da API
    return binance.order(
        symbol=symbol,
        side="SELL",
        quantity=quantity,
        price=sell_price,
    )


import requests
import json


def get_binance_depth(symbol="BTCUSDT", limit=100):
    """Fetch the order book depth for a symbol from the Binance public API.

    Parameters
    ----------
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.
    limit : int, optional
        Number of price levels to retrieve (max 5000). Default is 100.

    Returns
    -------
    dict or None
        Order book with ``"bids"`` and ``"asks"`` lists, or *None* on
        failure.
    """
    url = f"https://api.binance.com/api/v3/depth?symbol={symbol}&limit={limit}"
    response = requests.get(url)
    if response.status_code == 200:
        depth = response.json()
        return depth
    else:
        logger.error("Failed to fetch Binance depth for %s: HTTP %d", symbol, response.status_code)
        return None
