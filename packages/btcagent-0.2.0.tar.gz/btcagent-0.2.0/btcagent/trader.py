import logging
import time
import json
import datetime

import numpy as np
import requests
import binance

import btcagent
import btcagent.binance_robot as binance_robot
from btcagent.sentiment_analysis import get_sentiment


logger = logging.getLogger(__name__)


def get_wallet_performance(api_key, api_secret, wallet_value0, symbol="BTCUSDT"):
    """Get current wallet value and compute performance.

    Fetches the account balance (including amounts locked in open orders)
    and the current spot price, then calculates the total wallet value and
    its percentage change relative to *wallet_value0*.

    Parameters
    ----------
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    wallet_value0 : float
        Reference wallet value used to compute performance.
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.

    Returns
    -------
    dict
        ``{"usdt", "btc", "current_price", "wallet_value",
        "performance"}`` where *performance* is a percentage.
    """
    usdt, btc = btcagent.get_account_balance_using_binance(
        api_key=api_key, api_secret=api_secret, full=True
    )
    current_price = float(btcagent.get_current_price_using_binance(api_key, api_secret, symbol=symbol))
    wallet_value = float(usdt) + float(btc) * current_price
    performance = 100 * (wallet_value / wallet_value0 - 1)
    return dict(
        usdt=float(usdt),
        btc=float(btc),
        current_price=current_price,
        wallet_value=wallet_value,
        performance=performance,
    )


def compute_target_prices(api_key, api_secret, symbol="BTCUSDT", threshold=1,
                          range_wc=None, range_wv=None,
                          range_epsc=None, range_epsv=None,
                          n_scenarios=5_000_000, n_prices=1000):
    """Compute buy/sell target prices via Monte Carlo optimisation.

    Fetches recent prices from Binance and runs
    :func:`btcagent.get_recommendation` to find optimal trading parameters.

    Parameters
    ----------
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.
    threshold : float, optional
        Minimum return percentage for quality scoring. Default is 1.
    range_wc : list[int] or None, optional
        Buy window range. Default is ``[1, 400]``.
    range_wv : list[int] or None, optional
        Sell window range. Default is ``[1, 400]``.
    range_epsc : list[float] or None, optional
        Buy threshold range. Default is ``[0.004, 0.04]``.
    range_epsv : list[float] or None, optional
        Sell threshold range. Default is ``[0.004, 0.04]``.
    n_scenarios : int, optional
        Number of Monte Carlo scenarios. Default is 5 000 000.
    n_prices : int, optional
        Number of 1-minute candles to fetch. Default is 1000.

    Returns
    -------
    dict
        ``{"buy_price", "sell_price", "score", "current_price"}``.
    """
    if range_wc is None:
        range_wc = [1, 400]
    if range_wv is None:
        range_wv = [1, 400]
    if range_epsc is None:
        range_epsc = [0.004, 0.04]
    if range_epsv is None:
        range_epsv = [0.004, 0.04]

    prices = btcagent.get_prices_using_binance(api_key, api_secret, symbol, n_prices)
    recommendation = btcagent.get_recommendation(
        prices,
        USDTo=100,
        BTCo=0,
        threshold=threshold,
        range_wc=range_wc,
        range_wv=range_wv,
        range_epsc=range_epsc,
        range_epsv=range_epsv,
        n_scenarios=n_scenarios,
    )
    return dict(
        buy_price=recommendation["buy_price"],
        sell_price=recommendation["sell_price"],
        score=recommendation["score"] + 0.0001,
        current_price=float(prices[-1]),
    )


def adjust_prices_with_sentiment(buy_price, sell_price, sentiment_data):
    """Blend target prices with sentiment-based price boundaries.

    Applies a weighted average between the optimisation-derived prices and
    the sentiment-derived minimum/maximum prices.  The weights depend on
    the sentiment direction:

    * Positive sentiment: favours the sentiment maximum for the sell price.
    * Negative sentiment: favours the sentiment minimum for the buy price.
    * Neutral: equal 50/50 blend.

    Parameters
    ----------
    buy_price : float
        Optimisation-derived buy price.
    sell_price : float
        Optimisation-derived sell price.
    sentiment_data : dict
        Must contain ``"sentiment"`` (float, -1 to 1),
        ``"minimum_price"`` (float), and ``"maximum_price"`` (float).

    Returns
    -------
    tuple[float, float]
        ``(adjusted_buy_price, adjusted_sell_price)``.
    """
    sentiment = sentiment_data["sentiment"]
    minimum_price = sentiment_data["minimum_price"]
    maximum_price = sentiment_data["maximum_price"]

    if sentiment > 0:
        buy_price = buy_price * 0.7 + minimum_price * 0.3
        sell_price = sell_price * 0.3 + maximum_price * 0.7
    elif sentiment < 0:
        buy_price = buy_price * 0.3 + minimum_price * 0.7
        sell_price = sell_price * 0.7 + maximum_price * 0.3
    else:
        buy_price = buy_price * 0.5 + minimum_price * 0.5
        sell_price = sell_price * 0.5 + maximum_price * 0.5

    return buy_price, sell_price


def fetch_sentiment(token="BTC"):
    """Fetch sentiment analysis from multiple AI models.

    Calls :func:`btcagent.sentiment_analysis.get_sentiment` and normalises
    the key names.

    Parameters
    ----------
    token : str, optional
        Token/coin symbol to analyse. Default is ``"BTC"``.

    Returns
    -------
    dict or None
        ``{"sentiment", "minimum_price", "maximum_price", "reasoning"}``
        on success, or *None* if all models failed.
    """
    result = get_sentiment(token)
    if not result["status"]:
        return None
    return dict(
        sentiment=result["sentiment"],
        minimum_price=result["minimum price"],
        maximum_price=result["maximum price"],
        reasoning=result["reasoning"],
    )


def cancel_stale_orders(orders, buy_price, sell_price, symbol, api_key, api_secret,
                        tolerance=0.012, force=False):
    """Cancel open orders that deviate from target prices.

    A buy order is cancelled if its price is below
    ``buy_price * (1 - tolerance)``.  A sell order is cancelled if its
    price is above ``sell_price * (1 + tolerance)``.  When *force* is
    *True* all orders are cancelled regardless.

    Parameters
    ----------
    orders : list[dict]
        Open orders as returned by ``binance.openOrders()``.
    buy_price : float
        Current target buy price.
    sell_price : float
        Current target sell price.
    symbol : str
        Trading pair symbol.
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    tolerance : float, optional
        Fractional deviation threshold. Default is 0.012 (1.2%).
    force : bool, optional
        If *True*, cancel all orders unconditionally. Default is *False*.

    Returns
    -------
    list[dict]
        List of cancellation responses from the Binance API.
    """
    cancelled = []
    for order in orders:
        price = float(order["price"])

        if order["side"] == "BUY":
            if price < buy_price * (1 - tolerance) or force:
                o = binance_robot.cancel_order(
                    order, symbol=symbol, api_key=api_key, api_secret=api_secret
                )
                cancelled.append(o)

        if order["side"] == "SELL":
            if price > sell_price * (1 + tolerance) or force:
                o = binance_robot.cancel_order(
                    order, symbol=symbol, api_key=api_key, api_secret=api_secret
                )
                cancelled.append(o)

    return cancelled


def place_orders(buy_price, sell_price, symbol, api_key, api_secret,
                 max_size_buy=0.15, max_size_sell=0.15):
    """Place new buy and sell limit orders on Binance.

    Delegates to :func:`btcagent.create_orders`.

    Parameters
    ----------
    buy_price : float
        Limit price for the buy order.
    sell_price : float
        Limit price for the sell order.
    symbol : str
        Trading pair symbol.
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    max_size_buy : float, optional
        Fraction of token balance to sell. Default is 0.15.
    max_size_sell : float, optional
        Fraction of USDT balance to buy with. Default is 0.15.

    Returns
    -------
    list[dict]
        List of order responses from the Binance API.
    """
    return btcagent.create_orders(
        buy_price,
        sell_price,
        symbol=symbol,
        api_key=api_key,
        api_secret=api_secret,
        max_size_buy=max_size_buy,
        max_size_sell=max_size_sell,
    )


def save_reports(orders_report, performance_report, sentiment_report, suggestion_report):
    """Persist trading reports to JSON files.

    Writes four files in the current working directory:
    ``orders_report.json``, ``performance_report.json``,
    ``sentiment_report.json``, and ``suggestion_report.json``.

    Parameters
    ----------
    orders_report : list
        Accumulated order data entries.
    performance_report : list
        Entries of ``[timestamp, wallet_value, performance]``.
    sentiment_report : list
        Entries of ``[timestamp, sentiment, min_price, max_price, reasoning]``.
    suggestion_report : list
        Entries of ``[timestamp, buy_price, sell_price, min_price,
        max_price, sentiment, reasoning]``.
    """
    with open("orders_report.json", "w") as f:
        f.write(json.dumps({"orders_report": orders_report}))

    with open("performance_report.json", "w") as f:
        f.write(json.dumps({
            "performance_report": performance_report,
            "fields": ["timestamp", "wallet_value", "performance"],
        }))

    with open("sentiment_report.json", "w") as f:
        f.write(json.dumps({
            "sentiment_report": sentiment_report,
            "fields": ["timestamp", "minimum_price", "maximum_price", "sentiment", "reasoning"],
        }))

    with open("suggestion_report.json", "w") as f:
        f.write(json.dumps({
            "suggestion_report": suggestion_report,
            "fields": ["timestamp", "buy_price", "sell_price", "minimum_price", "maximum_price", "sentiment", "reasoning"],
        }))


def run_trading_iteration(api_key, api_secret, wallet_value0, symbol="BTCUSDT",
                          threshold=1, max_size_buy=0.15, max_size_sell=0.15,
                          n_scenarios=5_000_000, n_prices=1000):
    """Execute a single trading iteration.

    Orchestrates the full cycle: fetch sentiment, compute wallet
    performance, optimise target prices, adjust with sentiment, cancel
    stale orders, and place new orders.

    Parameters
    ----------
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    wallet_value0 : float
        Reference wallet value for performance tracking.
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.
    threshold : float, optional
        Optimisation quality threshold. Default is 1.
    max_size_buy : float, optional
        Fraction of token balance to sell. Default is 0.15.
    max_size_sell : float, optional
        Fraction of USDT balance to buy with. Default is 0.15.
    n_scenarios : int, optional
        Number of Monte Carlo scenarios. Default is 5 000 000.
    n_prices : int, optional
        Number of 1-minute candles to fetch. Default is 1000.

    Returns
    -------
    dict
        ``{"performance", "cancelled", "new_orders", "sentiment",
        "suggestion"}`` containing data for report accumulation.
    """
    # Sentiment analysis
    sentiment_data = fetch_sentiment(token=btcagent.get_token(symbol))
    sentiment_active = sentiment_data is not None

    # Wallet performance
    perf = get_wallet_performance(api_key, api_secret, wallet_value0, symbol=symbol)
    current_price = perf["current_price"]
    logger.info("Current %s price: %.2f", symbol, current_price)

    # Validate sentiment range
    if sentiment_active:
        if (sentiment_data["maximum_price"] < current_price or
                sentiment_data["minimum_price"] > current_price):
            logger.warning("Current price %.2f outside sentiment range (%.2f, %.2f) — disabling sentiment for this iteration",
                           current_price, sentiment_data['minimum_price'], sentiment_data['maximum_price'])
            sentiment_active = False

    t = time.time()
    logger.info("Wallet value: %.2f | Performance: %.2f%%", perf["wallet_value"], perf["performance"])

    # Compute target prices
    targets = compute_target_prices(
        api_key, api_secret, symbol=symbol,
        threshold=threshold, n_scenarios=n_scenarios, n_prices=n_prices,
    )
    bp = targets["buy_price"]
    sp = targets["sell_price"]
    score = targets["score"]
    logger.info("Optimization targets: buy=%.2f sell=%.2f score=%.4f", bp, sp, score)

    # Adjust with sentiment
    minimum_price = sentiment_data["minimum_price"] if sentiment_data else 0
    maximum_price = sentiment_data["maximum_price"] if sentiment_data else 0
    sentiment = sentiment_data["sentiment"] if sentiment_data else 0
    reasoning = sentiment_data["reasoning"] if sentiment_data else ""

    if sentiment_active:
        bp, sp = adjust_prices_with_sentiment(bp, sp, sentiment_data)
        logger.info("Sentiment adjustment applied: min=%.2f max=%.2f sentiment=%.2f",
                    minimum_price, maximum_price, sentiment)
    else:
        logger.info("Sentiment unavailable — using price-based recommendation only")

    logger.info("Final recommendation: buy=%.2f sell=%.2f", bp, sp)

    # Cancel stale orders
    orders = binance.openOrders(symbol=symbol)
    force_cancel = np.random.uniform(0, 1) < 0.001
    if force_cancel:
        logger.info("Random forced cancellation triggered")
    cancelled = cancel_stale_orders(
        orders, bp, sp, symbol, api_key, api_secret, force=force_cancel,
    )
    if cancelled:
        logger.info("Cancelled %d stale orders", len(cancelled))

    for order in orders:
        logger.debug("Open order: side=%s price=%s qty=%s status=%s",
                     order['side'], order['price'], order['origQty'], order['status'])

    # Place new orders
    new_orders = place_orders(
        bp, sp, symbol, api_key, api_secret,
        max_size_buy=max_size_buy, max_size_sell=max_size_sell,
    )
    logger.info("Placed %d new orders", len(new_orders))
    for o in new_orders:
        logger.debug("New order: %s", o)

    return dict(
        performance=[t, perf["wallet_value"], perf["performance"]],
        cancelled=cancelled,
        new_orders=new_orders,
        sentiment=[t, sentiment, minimum_price, maximum_price, reasoning] if sentiment_data else None,
        suggestion=[t, bp, sp, score, minimum_price, maximum_price, sentiment, reasoning],
    )
