"""Framework integrations (optional extras)."""
