"""
ASCEND SDK Data Models
=====================

Type-safe data models for API interactions.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any, List

# SDK 2.5.1 / SDK-251: needed for to_dict()'s top-level governance-field
# validation (mcp_server_name / model_id must be non-empty strings).
from .exceptions import ValidationError


class ActionType(str, Enum):
    """Supported action types for agent authorization."""
    DATA_ACCESS = "data_access"
    DATA_MODIFICATION = "data_modification"
    TRANSACTION = "transaction"
    RECOMMENDATION = "recommendation"
    COMMUNICATION = "communication"
    SYSTEM_OPERATION = "system_operation"
    QUERY = "query"
    ANALYSIS = "analysis"
    REPORT_GENERATION = "report_generation"
    API_CALL = "api_call"


class DecisionStatus(str, Enum):
    """Authorization decision statuses (legacy)."""
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    REQUIRES_MODIFICATION = "requires_modification"
    TIMEOUT = "timeout"
    AUTO_APPROVED = "auto_approved"
    ESCALATED = "escalated"


class Decision(str, Enum):
    """
    Authorization decision values (v2.0).

    Used by AscendClient.evaluate_action() response.
    """
    ALLOWED = "allowed"
    DENIED = "denied"
    PENDING = "pending"


class RiskLevel(str, Enum):
    """Risk assessment levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class RiskIndicators:
    """Risk assessment indicators for an action."""
    pii_involved: bool = False
    financial_data: bool = False
    external_transfer: bool = False
    data_sensitivity: str = "low"
    amount_threshold: Optional[str] = None
    compliance_flags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class ActionContext:
    """Contextual information for an action."""
    user_request: Optional[str] = None
    session_id: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    timestamp: Optional[str] = None
    custom_fields: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API-compatible dictionary."""
        result = {}
        if self.user_request:
            result["user_request"] = self.user_request
        if self.session_id:
            result["session_id"] = self.session_id
        if self.ip_address:
            result["ip_address"] = self.ip_address
        if self.user_agent:
            result["user_agent"] = self.user_agent
        if self.timestamp:
            result["timestamp"] = self.timestamp
        result.update(self.custom_fields)
        return result


@dataclass
class AgentAction:
    """
    Represents an agent action requiring authorization.

    This is the primary model for submitting actions to ASCEND.

    SDK 2.3.0 / FEAT-007: Multi-agent orchestration fields.
        orchestration_session_id - groups related agent actions into a session
        parent_action_id - AgentAction.id on the ASCEND backend for the parent
                           step. Backend enforces cross-tenant scoping and
                           session-graft protection on submit.
        orchestration_depth - delegation depth (0-5). Server caps at 5.
    """
    agent_id: str
    agent_name: str
    action_type: str
    resource: str
    resource_id: Optional[str] = None
    action_details: Optional[Dict[str, Any]] = None
    context: Optional[ActionContext] = None
    risk_indicators: Optional[RiskIndicators] = None
    # SDK 2.3.0 orchestration linkage (optional; backend validates).
    orchestration_session_id: Optional[str] = None
    parent_action_id: Optional[int] = None
    orchestration_depth: Optional[int] = None
    # SDK 2.5.1 / G-P0-01: MCP server governance.
    # Pass the registered MCP server name to trigger
    # Layer 13 enforcement at submit time.
    # Unregistered or deactivated servers → HTTP 403.
    mcp_server_name: Optional[str] = None
    # SDK 2.5.1 / G-P0-02: Model registry governance.
    # Pass the registered model_id to trigger
    # DeployedModel compliance check at submit time.
    # Non-compliant or unregistered models → HTTP 403.
    # SR-11-7 / EU-AI-ACT-ART9 enforcement.
    model_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to API-compatible dictionary.

        PY-SEC-005: Strips risk_score/risk_level from outbound payloads.
        Risk scoring is server-side only — clients must never influence it.
        """
        data = {
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "action_type": self.action_type,
            "resource": self.resource,
        }

        if self.resource_id:
            data["resource_id"] = self.resource_id
        if self.action_details:
            data["action_details"] = self.action_details
        if self.context:
            data["context"] = (
                self.context.to_dict()
                if isinstance(self.context, ActionContext)
                else self.context
            )
        if self.risk_indicators:
            data["risk_indicators"] = (
                self.risk_indicators.to_dict()
                if isinstance(self.risk_indicators, RiskIndicators)
                else self.risk_indicators
            )

        # SDK 2.3.0: Orchestration pass-through fields (only when set).
        if self.orchestration_session_id is not None:
            data["orchestration_session_id"] = self.orchestration_session_id
        if self.parent_action_id is not None:
            data["parent_action_id"] = self.parent_action_id
        if self.orchestration_depth is not None:
            data["orchestration_depth"] = self.orchestration_depth

        # SDK 2.5.1: Governance routing fields.
        # Must be top-level — backend reads these
        # at data["mcp_server_name"] and data["model_id"]
        # directly, never nested.
        if self.mcp_server_name:
            if not isinstance(self.mcp_server_name, str) \
                    or not self.mcp_server_name.strip():
                raise ValidationError(
                    "mcp_server_name must be a non-empty string."
                )
            data["mcp_server_name"] = self.mcp_server_name.strip()

        if self.model_id:
            if not isinstance(self.model_id, str) \
                    or not self.model_id.strip():
                raise ValidationError(
                    "model_id must be a non-empty string."
                )
            data["model_id"] = self.model_id.strip()

        # PY-SEC-005: Strip risk scoring fields from outbound payload
        data.pop("risk_score", None)
        data.pop("riskScore", None)
        data.pop("risk_level", None)

        return data


@dataclass
class AuthorizationDecision:
    """
    Authorization decision response from ASCEND.

    Supports both v1.0 (legacy) and v2.0 response formats.
    v2.0 uses Decision enum (ALLOWED/DENIED/PENDING).

    SDK 2.5.0 (G-P2-01) — promotes 22 fields the platform has been
    returning all along (CVSS, MITRE, NIST, code/prompt/MCP/model
    governance, processing time, alerts, workflow, output scan,
    thresholds) from the catch-all `metadata` dict to first-class
    typed attributes. ZERO BREAKING CHANGE: `metadata` continues to
    carry every key returned by the platform (the new typed fields
    are populated *in addition to*, not instead of, the metadata
    entries — existing callers reading `decision.metadata["cvss_score"]`
    keep working unchanged).
    """
    action_id: str
    decision: Decision  # v2.0: Decision enum
    risk_score: Optional[float] = None
    risk_level: Optional[RiskLevel] = None
    reason: Optional[str] = None
    policy_violations: List[str] = field(default_factory=list)
    conditions: List[str] = field(default_factory=list)
    approval_request_id: Optional[str] = None
    required_approvers: List[str] = field(default_factory=list)
    expires_at: Optional[str] = None
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    comments: Optional[str] = None
    execution_allowed: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    # ----- SDK 2.5.0 / G-P2-01 — promoted typed fields ---------------------

    # Compliance-framework attributes
    correlation_id: Optional[str] = None
    cvss_score: Optional[float] = None
    cvss_severity: Optional[str] = None
    cvss_vector: Optional[str] = None
    mitre_tactic: Optional[str] = None
    mitre_technique: Optional[str] = None
    nist_control: Optional[str] = None
    nist_description: Optional[str] = None

    # Analysis-result blocks (kept as nested dicts — schemas are stable
    # but rich; callers iterate keys rather than read scalar fields)
    code_analysis: Optional[Dict[str, Any]] = None
    prompt_security: Optional[Dict[str, Any]] = None
    # Shipped 2026-04-26 with G-P0-01 / G-P0-02
    mcp_governance: Optional[Dict[str, Any]] = None
    model_governance: Optional[Dict[str, Any]] = None

    # Action-level metadata
    processing_time_ms: Optional[int] = None
    alert_triggered: Optional[bool] = None
    alert_id: Optional[int] = None
    workflow_id: Optional[int] = None
    policy_decision: Optional[str] = None
    matched_policies: Optional[int] = None
    matched_smart_rules: Optional[int] = None
    output_scan_result: Optional[str] = None
    output_findings_count: Optional[int] = None
    thresholds: Optional[Dict[str, Any]] = None

    # SDK 2.6.0 / SDK-260: CWG-compatibility convenience accessor.
    # `result.status` returns the raw string form of the decision so legacy
    # callers and string-comparison code work unchanged. Use `result.decision`
    # for the typed `Decision` enum. Note: `action_id` is already a typed
    # top-level field on this dataclass (line 227), so no property needed.
    @property
    def status(self) -> str:
        """SDK-260: string alias for `self.decision.value`. Returns
        'allowed', 'denied', or 'pending'."""
        return self.decision.value

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuthorizationDecision":
        """Create from API response dictionary (v2.0 format).

        ZERO BREAKING CHANGE rule:
        - `metadata` still ends up populated with the platform's metadata
          dict (or {} if absent), exactly as in pre-2.5.0 SDKs.
        - Callers that read `decision.metadata["cvss_score"]` continue to
          work IFF the platform put cvss_score in metadata. To preserve
          that, we ALSO mirror the new top-level fields into metadata
          so that both `decision.cvss_score` and
          `decision.metadata["cvss_score"]` resolve to the same value.
        """
        # Map v1.0 status to v2.0 decision
        raw_decision = data.get("decision", data.get("status", "pending"))
        if raw_decision == "approved":
            decision = Decision.ALLOWED
        elif raw_decision == "denied":
            decision = Decision.DENIED
        elif raw_decision in ("allowed", "denied", "pending"):
            decision = Decision(raw_decision)
        else:
            decision = Decision.PENDING

        # Preserve original metadata dict + mirror new typed fields into
        # it so the two access patterns stay consistent.
        metadata = dict(data.get("metadata", {}) or {})

        # Action_id may be returned as int by some endpoints (e.g. submit
        # returns numeric `id` + `action_id` aliases). Coerce to str so
        # the dataclass type stays str across all return paths.
        raw_action_id = data.get("action_id", data.get("id", ""))
        action_id_str = "" if raw_action_id is None else str(raw_action_id)

        # Promote the 22 new fields when present in the top-level payload.
        # Each new attribute is also written into metadata for back-compat.
        promoted_keys = (
            "correlation_id",
            "cvss_score", "cvss_severity", "cvss_vector",
            "mitre_tactic", "mitre_technique",
            "nist_control", "nist_description",
            "code_analysis", "prompt_security",
            "mcp_governance", "model_governance",
            "processing_time_ms", "alert_triggered", "alert_id",
            "workflow_id", "policy_decision",
            "matched_policies", "matched_smart_rules",
            "output_scan_result", "output_findings_count",
            "thresholds",
        )
        promoted: Dict[str, Any] = {}
        for k in promoted_keys:
            if k in data:
                promoted[k] = data[k]
                # Mirror into metadata only if not already present, so we
                # don't clobber a different value the caller put there.
                metadata.setdefault(k, data[k])

        return cls(
            action_id=action_id_str,
            decision=decision,
            risk_score=data.get("risk_score"),
            risk_level=RiskLevel(data["risk_level"]) if data.get("risk_level") else None,
            reason=data.get("reason"),
            policy_violations=data.get("policy_violations", []),
            conditions=data.get("conditions", []),
            approval_request_id=data.get("approval_request_id"),
            required_approvers=data.get("required_approvers", []),
            expires_at=data.get("expires_at"),
            approved_by=data.get("approved_by", data.get("reviewed_by")),
            approved_at=data.get("approved_at", data.get("reviewed_at")),
            comments=data.get("comments"),
            execution_allowed=data.get("execution_allowed", decision == Decision.ALLOWED),
            metadata=metadata,
            **promoted,
        )


@dataclass
class ActionDetails:
    """Detailed information about an action."""
    action_id: str
    agent_id: str
    agent_name: str
    action_type: str
    resource: str
    resource_id: Optional[str]
    status: DecisionStatus
    risk_score: Optional[float]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    audit_trail: List[Dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActionDetails":
        """Create from API response dictionary."""
        return cls(
            action_id=str(data.get("id", data.get("action_id", ""))),
            agent_id=data.get("agent_id", ""),
            agent_name=data.get("agent_name", ""),
            action_type=data.get("action_type", ""),
            resource=data.get("resource", ""),
            resource_id=data.get("resource_id"),
            status=DecisionStatus(data.get("status", "pending")),
            risk_score=data.get("risk_score"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            audit_trail=data.get("audit_trail", [])
        )


# =========================================================================
# Enterprise Dataclasses (v2.1.0)
# =========================================================================


@dataclass
class KillSwitchStatus:
    """Kill switch status from the ASCEND API."""
    active: bool
    reason: Optional[str] = None
    activated_at: Optional[str] = None
    activated_by: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "KillSwitchStatus":
        return cls(
            active=data.get("active", data.get("is_active", False)),
            reason=data.get("reason"),
            activated_at=data.get("activated_at"),
            activated_by=data.get("activated_by"),
        )


@dataclass
class PolicyEvaluationResult:
    """Result of a real-time policy evaluation."""
    decision: str
    matched_policies: List[Dict[str, Any]] = field(default_factory=list)
    violations: List[str] = field(default_factory=list)
    risk_score: Optional[float] = None
    evaluation_time_ms: Optional[int] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PolicyEvaluationResult":
        return cls(
            decision=data.get("decision", "unknown"),
            matched_policies=data.get("matched_policies", []),
            violations=data.get("violations", []),
            risk_score=data.get("risk_score"),
            evaluation_time_ms=data.get("evaluation_time_ms"),
        )


@dataclass
class ResourceClassification:
    """Resource classification entry."""
    resource_id: str
    resource_type: str
    sensitivity_level: str
    compliance_tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ResourceClassification":
        return cls(
            resource_id=data.get("resource_id", data.get("id", "")),
            resource_type=data.get("resource_type", ""),
            sensitivity_level=data.get("sensitivity_level", ""),
            compliance_tags=data.get("compliance_tags", []),
            metadata=data.get("metadata", {}),
        )


@dataclass
class AuditEvent:
    """A single audit log event."""
    event_id: str
    event_type: str
    timestamp: str
    actor: Optional[str] = None
    resource: Optional[str] = None
    action: Optional[str] = None
    outcome: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditEvent":
        return cls(
            event_id=data.get("event_id", data.get("id", "")),
            event_type=data.get("event_type", ""),
            timestamp=data.get("timestamp", ""),
            actor=data.get("actor"),
            resource=data.get("resource"),
            action=data.get("action"),
            outcome=data.get("outcome"),
            details=data.get("details", {}),
        )


@dataclass
class AuditLogResponse:
    """Paginated audit log response."""
    events: List[AuditEvent] = field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 50

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditLogResponse":
        events_data = data.get("events", data.get("logs", data.get("items", [])))
        return cls(
            events=[AuditEvent.from_dict(e) for e in events_data],
            total=data.get("total", len(events_data)),
            page=data.get("page", 1),
            page_size=data.get("page_size", data.get("limit", 50)),
        )


@dataclass
class AgentHealthStatus:
    """Health status of a registered agent."""
    agent_id: str
    status: str
    last_heartbeat: Optional[str] = None
    uptime_seconds: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentHealthStatus":
        return cls(
            agent_id=data.get("agent_id", ""),
            status=data.get("status", "unknown"),
            last_heartbeat=data.get("last_heartbeat"),
            uptime_seconds=data.get("uptime_seconds"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class Webhook:
    """Webhook configuration."""
    webhook_id: str
    url: str
    events: List[str] = field(default_factory=list)
    active: bool = True
    secret: Optional[str] = None
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Webhook":
        return cls(
            webhook_id=data.get("webhook_id", data.get("id", "")),
            url=data.get("url", ""),
            events=data.get("events", []),
            active=data.get("active", True),
            secret=data.get("secret"),
            created_at=data.get("created_at"),
        )


@dataclass
class WebhookTestResult:
    """Result of testing a webhook."""
    success: bool
    status_code: Optional[int] = None
    response_time_ms: Optional[int] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WebhookTestResult":
        return cls(
            success=data.get("success", False),
            status_code=data.get("status_code"),
            response_time_ms=data.get("response_time_ms"),
            error=data.get("error"),
        )


@dataclass
class BulkActionResult:
    """Result for a single action within a bulk evaluation."""
    action_type: str
    resource: str
    decision: Optional[AuthorizationDecision] = None
    error: Optional[str] = None
    succeeded: bool = True


@dataclass
class BulkEvaluationResult:
    """Aggregate result from bulk action evaluation."""
    total: int = 0
    succeeded: int = 0
    failed: int = 0
    results: List[BulkActionResult] = field(default_factory=list)
