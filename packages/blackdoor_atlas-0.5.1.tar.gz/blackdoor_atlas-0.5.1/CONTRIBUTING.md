# Contributing to ATLAS

Welcome. The rules and workflow live in [`AGENTS.md`](AGENTS.md) — this
file is the deeper dive for new contributors: how to set up a dev env,
where things live, how to run tests, how to debug.

## Dev environment

You need:

- **Python 3.11+** (3.12 / 3.13 also fine)
- **Node 20+** — to build the React dashboard frontend
- **macOS, Linux, or WSL2** — Windows native works for the CLI but the
  dashboard launcher path is shaped around POSIX. CI tests Windows on
  every release anyway.

```sh
git clone https://github.com/ryderderder/atlas-cli
cd atlas-cli
make bootstrap                 # python deps + node deps + pyinstaller
make smoke                     # confirm the local install works
```

`make bootstrap` runs:

```sh
pip install --upgrade pip
pip install -e '.[dev]' pyinstaller
cd apps/web && npm install
```

## Running locally

Two flavors:

```sh
# 1. Editable Python install (default — same as a published pipx install,
#    just pointed at your source tree)
pipx install -e .
atlas

# 2. Legacy dogfood stack (Node API + Vite dev server)
./app dev
```

The two share the same SQLite file at `~/.atlas/data.sqlite`, so any
data you create in one shows up in the other.

## Testing

```sh
make smoke                     # install + run version, init, workspace ls, REPL turn
pytest tests/                  # unit tests (sparse for now, growing)
```

To exercise the FastAPI dashboard without launching it:

```sh
~/.local/pipx/venvs/atlas-cli/bin/python -c "
from fastapi.testclient import TestClient
from atlas.dash.server import create_app
c = TestClient(create_app())
print(c.get('/api/auth/me').json())
"
```

To exercise the agent runtime without API keys:

```sh
ATLAS_PROVIDER=mock printf 'hi\n/quit\n' | atlas
```

## Branching + PR flow

See [`AGENTS.md`](AGENTS.md) for the canonical workflow. The short
version:

```sh
git switch -c feat/short-slug
# work, commit with conventional prefix
git push -u origin feat/short-slug
gh pr create
# wait for CI; squash-merge when approved
```

The PR template's checklist is required.

## Releases

You don't tag. `release-please` reads conventional commits and opens a
**Release PR** automatically when new releasable changes land on master.
Merging that PR creates the tag, which fires the binary build + PyPI
publish workflows.

See [`.github/workflows/release-please.yml`](.github/workflows/release-please.yml)
and the release flow section of `AGENTS.md`.

## Debugging tips

### REPL hangs or doesn't render
- Check the bottom-status line — if `provider=mock`, the wizard wasn't
  completed. Run `atlas init` to reset.
- Pipe input to bypass prompt_toolkit (helpful in CI):
  `printf 'hi\n/quit\n' | atlas`
- Set `ATLAS_HOME=$(mktemp -d)` to test against a clean state without
  nuking your real `~/.atlas/`.

### Dashboard won't start
- Check `~/.atlas/dash.log` (the subprocess form's output) or your
  terminal (the binary form's output).
- Port collision: `lsof -i :41821` to see what's holding it.
- `atlas stop` tears down a stuck instance.

### CI failing on a PR
- `gh run view <id> --log-failed` pulls just the failed step.
- `gh run rerun <id>` retries a transient failure.
- 90% of failures: a commit message that doesn't match conventional
  format. Fix and force-push the branch.

## Style

- Python: type hints required on public functions; ruff clean; line
  length 100. We're permissive on docstring style — explain *why*, not
  *what*. The named identifiers do the *what*.
- TypeScript (legacy `apps/`): existing style; no new code expected
  there until v0.2 deletes it.
- Markdown: 80-character wrap on prose, no wrap on code blocks or tables.

## License

By contributing you agree your contributions are licensed under
Apache 2.0 (same as the rest of the project — see [`LICENSE`](LICENSE)).
