import { defineConfig, devices } from '@playwright/test';
import { existsSync, rmSync } from 'node:fs';
import path from 'node:path';

const WEB = process.env.WEB_BASE_URL ?? 'http://localhost:41822';

// Reset the dogfood database *before* the webServer is spawned so the API
// boots against a clean SQLite file. Skipping this is fine for ad-hoc runs;
// the harness always wants a fresh slate.
if (!process.env.HARNESS_KEEP_DB) {
  for (const f of ['data.sqlite', 'data.sqlite-journal', 'data.sqlite-wal', 'data.sqlite-shm']) {
    const p = path.resolve(process.cwd(), 'apps', 'api', f);
    if (existsSync(p)) rmSync(p, { force: true });
  }
}

export default defineConfig({
  testDir: './tests/browser',
  fullyParallel: false,
  retries: 0,
  reporter: [['list'], ['html', { open: 'never', outputFolder: '.agent/artifacts/browser/html' }]],
  use: {
    baseURL: WEB,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'off',
  },
  outputDir: '.agent/artifacts/browser/test-results',
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: process.env.PLAYWRIGHT_NO_WEBSERVER
    ? undefined
    : {
        command: 'npm run dev',
        url: WEB,
        reuseExistingServer: !process.env.CI,
        timeout: 120_000,
        stdout: 'pipe',
        stderr: 'pipe',
      },
});
