"""IO layer: workflow loader, schema validators, report writers."""
