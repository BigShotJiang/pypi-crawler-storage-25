"""Load and validate workflow YAML files."""

from __future__ import annotations

import os
from typing import Any, Dict, List

import yaml


_REQUIRED_KEYS = ("name", "objective", "entrypoint", "success_criteria", "steps")


def load_workflow(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"workflow not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    _validate(data, path)
    return data


def _validate(data: Dict[str, Any], path: str) -> None:
    missing: List[str] = [k for k in _REQUIRED_KEYS if k not in data]
    if missing:
        raise ValueError(f"{path}: workflow missing required keys: {missing}")
    if not isinstance(data["steps"], list) or not data["steps"]:
        raise ValueError(f"{path}: steps must be a non-empty list")
    if not isinstance(data["success_criteria"], list) or not data["success_criteria"]:
        raise ValueError(f"{path}: success_criteria must be a non-empty list")
