"""JSONSchema validators backed by ``agent/schemas/*``."""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional


def _load(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def validator_for(repo_root: str, name: str):
    """Return a validate(obj) -> None function for one of the bundled schemas."""

    try:
        from jsonschema import Draft202012Validator  # type: ignore
    except Exception:
        # If jsonschema isn't installed, return a no-op so the harness can still
        # run; emit a single warning so callers know validation is off.
        def _noop(obj: Any) -> None:
            return None

        return _noop

    schema_path = os.path.join(repo_root, "agent", "schemas", f"{name}.schema.json")
    schema = _load(schema_path)
    base_dir = os.path.dirname(schema_path)
    # Resolve cross-schema $ref against the schemas/ dir.
    base_uri = f"file://{base_dir}/"
    try:
        from jsonschema import RefResolver  # type: ignore

        resolver = RefResolver(base_uri=base_uri, referrer=schema)
        v = Draft202012Validator(schema, resolver=resolver)
    except Exception:
        v = Draft202012Validator(schema)

    def _validate(obj: Any) -> None:
        v.validate(obj)

    return _validate
