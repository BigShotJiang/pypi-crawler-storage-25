"""Report writers — markdown + JSON under ``.agent/reports/``."""

from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List


def _reports_dir(repo_root: str) -> str:
    path = os.path.join(repo_root, ".agent", "reports")
    os.makedirs(path, exist_ok=True)
    return path


# ---- environment-check.md ----


def write_environment_check(repo_root: str, versions: Dict[str, str], workspace: Dict[str, Any]) -> str:
    rows = "\n".join(f"| `{k}` | {v} |" for k, v in sorted(versions.items()))
    content = f"""# Environment check

_Generated {_now()}_

## Tool versions

| Tool | Version |
|------|---------|
{rows}

## Workspace flags

| Flag | Value |
|------|-------|
| git_initialized | {workspace.get("git_initialized")} |
| has_playwright | {workspace.get("has_playwright")} |
| has_apps_web | {workspace.get("has_apps_web")} |
| has_apps_api | {workspace.get("has_apps_api")} |
"""
    out = os.path.join(_reports_dir(repo_root), "environment-check.md")
    _write(out, content)
    return out


# ---- patch-<ts>.md ----


def write_patch_report(repo_root: str, patch: Dict[str, Any]) -> str:
    ts = patch.get("created_at", _now()).replace(":", "").replace("-", "")
    out = os.path.join(_reports_dir(repo_root), f"patch-{ts}-{patch['id']}.md")
    files_md = "\n".join(
        f"- `{f['path']}` ({f['operation']}; +{f.get('bytes_added', 0)} / -{f.get('bytes_removed', 0)})"
        for f in patch.get("files_changed", [])
    ) or "- (none)"
    commands_md = "\n".join(
        f"- `{' '.join(c['argv'])}` -> exit {c['exit_code']} ({c.get('duration_ms', 0)} ms)"
        for c in patch.get("commands", [])
    ) or "- (none)"
    risks_md = "\n".join(f"- {r}" for r in patch.get("remaining_risks", [])) or "- (none)"
    diff = patch.get("diff", "")
    diff_section = f"\n\n## Diff\n\n```diff\n{diff}```\n" if diff else ""
    content = f"""# Patch {patch['id']}

_{patch.get('created_at', _now())}_

## Intent
{patch.get('intent', '')}

## Task
{patch.get('task_id') or '(none)'}

## Files changed
{files_md}

## Commands
{commands_md}

## Result
- pass: **{patch.get('results', {}).get('pass')}**
- summary: {patch.get('results', {}).get('summary', '')}

## Remaining risks
{risks_md}
{diff_section}"""
    _write(out, content)
    return out


# ---- task-status.json ----


def write_task_status(repo_root: str, state: Dict[str, Any]) -> str:
    snapshot = {
        "run_id": state.get("run_id"),
        "status": state.get("status"),
        "completed": [t["id"] for t in state.get("completed_tasks", [])],
        "failed": [t["id"] for t in state.get("failed_tasks", [])],
        "pending": [
            t["id"]
            for t in state.get("task_queue", [])
            if t.get("status") not in ("completed", "failed")
        ],
        "approvals": state.get("approval_requests", []),
        "risks": state.get("risks", []),
        "last_updated": _now(),
    }
    out = os.path.join(_reports_dir(repo_root), "task-status.json")
    _write(out, json.dumps(snapshot, indent=2))
    return out


# ---- test-summary.md ----


def write_test_summary(repo_root: str, state: Dict[str, Any]) -> str:
    static = [r for r in state.get("test_results", []) if r["kind"] == "static"]
    unit = [r for r in state.get("test_results", []) if r["kind"] == "unit"]
    integration = [r for r in state.get("test_results", []) if r["kind"] == "integration"]
    content = f"""# Test summary

_Generated {_now()}_

## Static
{_format_results(static)}

## Unit
{_format_results(unit)}

## Integration
{_format_results(integration)}
"""
    out = os.path.join(_reports_dir(repo_root), "test-summary.md")
    _write(out, content)
    return out


# ---- browser-summary.md ----


def write_browser_summary(repo_root: str, state: Dict[str, Any]) -> str:
    ui = state.get("ui_results", [])
    content = f"""# Browser summary

_Generated {_now()}_

{_format_results(ui)}

## Evidence

Artifacts: `.agent/artifacts/browser/`
"""
    out = os.path.join(_reports_dir(repo_root), "browser-summary.md")
    _write(out, content)
    return out


# ---- final-status.md ----


def write_final_status(repo_root: str, state: Dict[str, Any]) -> str:
    completed = "\n".join(f"- {t['id']}: {t['title']}" for t in state.get("completed_tasks", [])) or "- (none)"
    blocked = "\n".join(f"- {t['id']}: {t['title']}" for t in state.get("failed_tasks", [])) or "- (none)"
    deferred_list = state.get("workspace", {}).get("deferred", []) if isinstance(state.get("workspace"), dict) else []
    deferred = "\n".join(f"- {d}" for d in deferred_list) or "- (none)"
    risks = "\n".join(f"- {r}" for r in state.get("risks", [])) or "- (none)"
    services = state.get("services", {})
    front_url = services.get("web", {}).get("health_url") or "(not started)"
    back_url = services.get("api", {}).get("health_url") or "(not started)"
    db = "apps/api/data.sqlite"

    static_p = _pass_count(state.get("test_results", []), "static")
    unit_p = _pass_count(state.get("test_results", []), "unit")
    integ_p = _pass_count(state.get("test_results", []), "integration")
    browser_p = _pass_count(state.get("ui_results", []), "browser")

    content = f"""# Final status

## Goal
{state.get('goal', '')}

## Outcome
- Completed:
{completed}
- Blocked:
{blocked}
- Deferred:
{deferred}

## Environment
- Frontend URL: {front_url}
- Backend URL: {back_url}
- Database: {db}

## Validation
- Lint/Static: {static_p}
- Typecheck: see Static
- Unit tests: {unit_p}
- Integration tests: {integ_p}
- Browser flows: {browser_p}

## Artifacts
- Screenshots: .agent/artifacts/screenshots/
- Traces: .agent/artifacts/traces/
- Logs: .agent/logs/

## Risks
{risks}

## Next action
- Address blocked tasks listed above.
- Resume with `python -m harness.cli resume` after approving any pending requests.
"""
    out = os.path.join(_reports_dir(repo_root), "final-status.md")
    _write(out, content)
    return out


# ---- helpers ----


def _format_results(records: List[Dict[str, Any]]) -> str:
    if not records:
        return "(no runs)"
    lines = []
    for r in records:
        lines.append(f"- **{r.get('status')}** — {r.get('summary', '')} ({r.get('finished_at')})")
    return "\n".join(lines)


def _pass_count(records: List[Dict[str, Any]], kind: str) -> str:
    subset = [r for r in records if r.get("kind") == kind]
    if not subset:
        return "n/a"
    passes = sum(1 for r in subset if r.get("status") == "pass")
    return f"{passes}/{len(subset)} pass"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _write(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
