"""Autonomous build harness.

A LangGraph-driven runner that owns project bootstrap, planning, code
generation, validation, repair, and reporting. Designed to run without an LLM
present so the orchestration is testable; LLM-driven node prompts are loaded
from ``agent/prompts/*.md`` and applied by callers that bind a model.
"""

__version__ = "0.1.0"
