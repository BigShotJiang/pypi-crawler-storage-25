"""Durable state for the autonomous build harness.

Mirrors ``agent/schemas/state.schema.json``. We use a plain ``dict``-shaped
``TypedDict`` so the same value is trivially serializable to JSON for
checkpoints and reports.
"""

from __future__ import annotations

import os
import time
import uuid
from typing import Any, Dict, List, Optional, TypedDict


class Task(TypedDict, total=False):
    id: str
    title: str
    depends_on: List[str]
    artifacts_changed: List[str]
    definition_of_done: List[str]
    validation: List[str]
    retry_count: int
    max_retries: int
    epic_id: Optional[str]
    status: str
    notes: List[str]


class Stack(TypedDict, total=False):
    frontend: str
    backend: str
    database: str


class HarnessState(TypedDict, total=False):
    run_id: str
    goal: str
    repo_root: str
    workflow: str
    stack: Stack
    workspace: Dict[str, Any]
    task_queue: List[Task]
    active_task: Optional[Task]
    completed_tasks: List[Task]
    failed_tasks: List[Task]
    artifacts: List[str]
    services: Dict[str, Dict[str, Any]]
    test_results: List[Dict[str, Any]]
    ui_results: List[Dict[str, Any]]
    patch_history: List[Dict[str, Any]]
    risks: List[str]
    approval_requests: List[Dict[str, Any]]
    decision_log: List[Dict[str, Any]]
    retry_budget: Dict[str, int]
    status: str
    # Routing scratchpad for the engine — never persisted to reports.
    _route: Optional[str]


DEFAULT_RETRY_BUDGET: Dict[str, int] = {
    "static": 3,
    "unit": 5,
    "integration": 4,
    "browser": 4,
    "bootstrap_per_dependency": 2,
}


def new_state(goal: str, repo_root: str, workflow: str = "default-build") -> HarnessState:
    """Construct an initial state with sensible defaults."""

    return HarnessState(
        run_id=f"run-{int(time.time())}-{uuid.uuid4().hex[:8]}",
        goal=goal,
        repo_root=os.path.abspath(repo_root),
        workflow=workflow,
        stack={},
        workspace={},
        task_queue=[],
        active_task=None,
        completed_tasks=[],
        failed_tasks=[],
        artifacts=[],
        services={},
        test_results=[],
        ui_results=[],
        patch_history=[],
        risks=[],
        approval_requests=[],
        decision_log=[],
        retry_budget=dict(DEFAULT_RETRY_BUDGET),
        status="planning",
        _route=None,
    )


def log_decision(state: HarnessState, node: str, decision: str, **details: Any) -> None:
    """Append an audit entry to ``state.decision_log``."""

    entry = {
        "at": _now_iso(),
        "node": node,
        "decision": decision,
    }
    if details:
        entry["details"] = details
    state.setdefault("decision_log", []).append(entry)


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
