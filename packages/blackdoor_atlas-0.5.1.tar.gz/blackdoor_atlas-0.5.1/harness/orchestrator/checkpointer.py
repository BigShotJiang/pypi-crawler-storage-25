"""Durable checkpoint store backed by SQLite.

Stores one row per (run_id, node) pair with the full serialized state. The
latest row per run_id is the resume point. We intentionally avoid SQLAlchemy
or any third-party ORM so the harness has no install-time DB dependency.
"""

from __future__ import annotations

import json
import os
import sqlite3
import time
from typing import Any, Dict, Iterable, Optional, Tuple


_SCHEMA = """
CREATE TABLE IF NOT EXISTS checkpoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    node TEXT NOT NULL,
    created_at TEXT NOT NULL,
    state_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_checkpoints_run ON checkpoints(run_id, id);
"""


class SQLiteCheckpointer:
    """Append-only SQLite checkpoint log."""

    def __init__(self, path: str) -> None:
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._conn = sqlite3.connect(path)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def save(self, run_id: str, node: str, state: Dict[str, Any]) -> None:
        self._conn.execute(
            "INSERT INTO checkpoints (run_id, node, created_at, state_json) VALUES (?, ?, ?, ?)",
            (
                run_id,
                node,
                time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                json.dumps(state, default=str, sort_keys=True),
            ),
        )
        self._conn.commit()

    def latest(self, run_id: Optional[str] = None) -> Optional[Tuple[str, str, Dict[str, Any]]]:
        cur = self._conn.cursor()
        if run_id is None:
            cur.execute(
                "SELECT run_id, node, state_json FROM checkpoints ORDER BY id DESC LIMIT 1"
            )
        else:
            cur.execute(
                "SELECT run_id, node, state_json FROM checkpoints WHERE run_id = ? ORDER BY id DESC LIMIT 1",
                (run_id,),
            )
        row = cur.fetchone()
        if not row:
            return None
        return row[0], row[1], json.loads(row[2])

    def history(self, run_id: str) -> Iterable[Tuple[str, str]]:
        cur = self._conn.cursor()
        cur.execute(
            "SELECT node, created_at FROM checkpoints WHERE run_id = ? ORDER BY id ASC",
            (run_id,),
        )
        return cur.fetchall()

    def close(self) -> None:
        self._conn.close()
