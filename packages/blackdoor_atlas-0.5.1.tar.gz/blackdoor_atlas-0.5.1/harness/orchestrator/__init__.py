"""LangGraph-based orchestration with a built-in fallback engine.

If ``langgraph`` is importable we use it; otherwise a small, dependency-free
``MiniGraph`` runner with equivalent semantics for our subset (linear flow with
conditional routing, durable checkpoints, and interrupts) is used. This keeps
the harness runnable in environments without network installs while preserving
the same node contract.

Heavy submodules (``graph``) are not imported eagerly so that lightweight
consumers (the ``state`` types, the checkpointer) don't transitively pull in
node modules and their optional dependencies. Import ``graph`` explicitly.
"""

from .state import HarnessState, new_state  # noqa: F401

__all__ = ["HarnessState", "new_state"]
