"""Approval interrupts.

The harness expresses an approval boundary by raising ``ApprovalRequired``.
The engine catches that, persists an entry to ``state.approval_requests`` and
to ``.agent/state/approvals.jsonl``, then stops. ``resume`` re-runs the same
node after verifying the approval status flipped to ``approved``.
"""

from __future__ import annotations

import json
import os
import time
import uuid
from typing import Any, Dict, Optional


class ApprovalRequired(Exception):
    """Raised by a node to request human approval."""

    def __init__(self, action: str, context: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(action)
        self.action = action
        self.context = context or {}


def write_pending(repo_root: str, action: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """Append a pending approval to ``.agent/state/approvals.jsonl``."""

    entry = {
        "id": f"appr-{uuid.uuid4().hex[:10]}",
        "action": action,
        "context": context,
        "status": "pending",
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "resolved_at": None,
        "reviewer": None,
    }
    path = os.path.join(repo_root, ".agent", "state", "approvals.jsonl")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")
    return entry


def find_approval(repo_root: str, request_id: str) -> Optional[Dict[str, Any]]:
    """Return the latest record for ``request_id`` from the JSONL file."""

    path = os.path.join(repo_root, ".agent", "state", "approvals.jsonl")
    if not os.path.exists(path):
        return None
    latest: Optional[Dict[str, Any]] = None
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get("id") == request_id:
                latest = row
    return latest


def is_approved(repo_root: str, request_id: str) -> bool:
    record = find_approval(repo_root, request_id)
    return bool(record and record.get("status") == "approved")
