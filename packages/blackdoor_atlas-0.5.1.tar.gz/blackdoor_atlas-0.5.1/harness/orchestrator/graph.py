"""Build and run the 18-node graph.

The graph is built twice:

* If ``langgraph`` is installed, we hand the same node functions to a
  ``StateGraph`` so callers benefit from the upstream checkpointer, streaming,
  and interrupt support.
* Otherwise, ``MiniGraph`` runs the nodes with the same routing semantics
  (conditional edges via ``state["_route"]`` and ``ApprovalRequired`` for
  interrupts). This keeps the harness runnable in offline environments and
  makes the orchestration unit-testable without network installs.

The node contract:

  def node(state: HarnessState) -> HarnessState

Each node returns a *mutated* state. ``_route`` may be set to the name of the
next node when the canonical edge depends on runtime decisions (failure vs
success, more tasks vs done, approval required vs not).
"""

from __future__ import annotations

import os
from typing import Callable, Dict, List, Optional

from ..nodes import (
    approval,
    bootstrap,
    commit,
    contract,
    execute,
    finalize,
    ingest,
    inspect,
    patch,
    plan,
    report,
    retest,
    test_browser,
    test_integration,
    test_unit,
    triage,
    validate_static,
)
from .checkpointer import SQLiteCheckpointer
from .interrupts import ApprovalRequired, write_pending
from .state import HarnessState, log_decision


NodeFn = Callable[[HarnessState], HarnessState]


# The order matters: it is the canonical linear sequence. Conditional edges
# layered on top are handled in ``_next_node``.
NODES: Dict[str, NodeFn] = {
    "ingest_goal": ingest.ingest_goal,
    "read_repo_contract": contract.read_repo_contract,
    "inspect_workspace": inspect.inspect_workspace,
    "bootstrap_environment": bootstrap.bootstrap_environment,
    "plan_build": plan.plan_build,
    "execute_task": execute.execute_task,
    "run_static_validation": validate_static.run_static_validation,
    "run_unit_tests": test_unit.run_unit_tests,
    "run_integration_tests": test_integration.run_integration_tests,
    "run_browser_validation": test_browser.run_browser_validation,
    "triage_failures": triage.triage_failures,
    "generate_patch": patch.generate_patch,
    "apply_patch": patch.apply_patch,
    "retest": retest.retest,
    "request_approval": approval.request_approval,
    "finalize_artifacts": finalize.finalize_artifacts,
    "commit_changes": commit.commit_changes,
    "emit_report": report.emit_report,
}


# Canonical happy-path order, used by the mini-engine when a node didn't set
# ``state["_route"]``.
LINEAR_ORDER: List[str] = [
    "ingest_goal",
    "read_repo_contract",
    "inspect_workspace",
    "bootstrap_environment",
    "plan_build",
    "execute_task",
    "run_static_validation",
    "run_unit_tests",
    "run_integration_tests",
    "run_browser_validation",
    "finalize_artifacts",
    "commit_changes",
    "emit_report",
]


def _next_node(current: str, state: HarnessState) -> Optional[str]:
    """Return the next node name given the current node and routing scratchpad.

    Honors ``state["_route"]`` first; falls back to the linear order otherwise.
    Returns ``None`` when the graph is finished.
    """

    explicit = state.get("_route")
    if explicit:
        state["_route"] = None
        return explicit

    # Default: continue the linear path.
    try:
        idx = LINEAR_ORDER.index(current)
    except ValueError:
        # ``triage_failures``, ``generate_patch``, ``apply_patch``, ``retest``,
        # and ``request_approval`` live off the linear order and always set
        # ``_route`` explicitly. Reaching here without an explicit route is a
        # bug we want to surface.
        return None

    if idx + 1 >= len(LINEAR_ORDER):
        return None
    return LINEAR_ORDER[idx + 1]


class MiniGraph:
    """Built-in fallback runner with conditional edges + checkpoints."""

    def __init__(self, repo_root: str) -> None:
        self.repo_root = repo_root
        self.checkpointer = SQLiteCheckpointer(
            os.path.join(repo_root, ".agent", "state", "checkpoints.sqlite")
        )

    def run(self, state: HarnessState, start: str = "ingest_goal") -> HarnessState:
        node_name: Optional[str] = start
        while node_name is not None:
            fn = NODES.get(node_name)
            if fn is None:
                raise RuntimeError(f"Unknown node: {node_name}")
            log_decision(state, node_name, "enter")
            try:
                state = fn(state)
            except ApprovalRequired as exc:
                entry = write_pending(self.repo_root, exc.action, exc.context)
                state.setdefault("approval_requests", []).append(entry)
                state["status"] = "awaiting_approval"
                log_decision(state, node_name, "approval_required", action=exc.action, id=entry["id"])
                self.checkpointer.save(state["run_id"], node_name, state)
                return state
            log_decision(state, node_name, "exit", status=state.get("status"))
            self.checkpointer.save(state["run_id"], node_name, state)
            node_name = _next_node(node_name, state)
        return state


def build_graph(repo_root: str):
    """Return a runner. Uses LangGraph if available, else MiniGraph."""

    try:
        from langgraph.graph import END, StateGraph  # type: ignore
        from langgraph.checkpoint.sqlite import SqliteSaver  # type: ignore
    except Exception:
        return MiniGraph(repo_root)

    graph = StateGraph(dict)
    for name, fn in NODES.items():
        graph.add_node(name, fn)

    graph.set_entry_point("ingest_goal")

    # Static, unconditional linear edges:
    linear = list(zip(LINEAR_ORDER, LINEAR_ORDER[1:]))
    for a, b in linear:
        graph.add_edge(a, b)
    graph.add_edge("emit_report", END)

    # Off-linear repair edges:
    graph.add_edge("triage_failures", "generate_patch")
    graph.add_edge("generate_patch", "apply_patch")
    graph.add_edge("apply_patch", "retest")
    graph.add_edge("retest", "execute_task")
    graph.add_edge("request_approval", "finalize_artifacts")

    # Conditional fanout from validations back into triage on failure:
    def _route(state):
        return state.get("_route") or "continue"

    for guard in (
        "run_static_validation",
        "run_unit_tests",
        "run_integration_tests",
        "run_browser_validation",
    ):
        graph.add_conditional_edges(
            guard,
            _route,
            {
                "triage_failures": "triage_failures",
                "request_approval": "request_approval",
                "continue": _next_in_linear(guard),
            },
        )

    saver = SqliteSaver.from_conn_string(
        f"sqlite:///{os.path.join(repo_root, '.agent', 'state', 'checkpoints.sqlite')}"
    )
    return graph.compile(checkpointer=saver, interrupt_before=["request_approval"])


def _next_in_linear(node: str) -> str:
    idx = LINEAR_ORDER.index(node)
    return LINEAR_ORDER[idx + 1]


def run_graph(state: HarnessState, start: str = "ingest_goal") -> HarnessState:
    runner = build_graph(state["repo_root"])
    if isinstance(runner, MiniGraph):
        return runner.run(state, start)
    # LangGraph runner expects a dict input and a run config carrying run_id.
    return runner.invoke(state, config={"configurable": {"thread_id": state["run_id"]}})
