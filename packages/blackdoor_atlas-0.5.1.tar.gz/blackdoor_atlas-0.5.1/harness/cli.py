"""Command-line entry for the harness."""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List, Optional

from .io.reports import write_final_status, write_task_status
from .nodes.inspect import inspect_workspace
from .orchestrator.checkpointer import SQLiteCheckpointer
from .orchestrator.graph import run_graph
from .orchestrator.state import HarnessState, new_state


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="harness", description="Autonomous build harness")
    parser.set_defaults(cmd=None)
    sub = parser.add_subparsers(dest="cmd")

    build = sub.add_parser("build", help="Run the full graph end-to-end.")
    build.add_argument("--goal", required=True)
    build.add_argument("--workflow", default="default-build")
    build.add_argument("--repo-root", default=".")

    insp = sub.add_parser("inspect", help="Run inspect_workspace only.")
    insp.add_argument("--repo-root", default=".")

    plan = sub.add_parser("plan", help="Run planner only and write plan.json.")
    plan.add_argument("--goal", required=True)
    plan.add_argument("--workflow", default="default-build")
    plan.add_argument("--repo-root", default=".")

    resume = sub.add_parser("resume", help="Resume from the latest checkpoint.")
    resume.add_argument("--repo-root", default=".")
    resume.add_argument("--run-id", default=None)

    report = sub.add_parser("report", help="Regenerate final-status.md from the latest checkpoint.")
    report.add_argument("--repo-root", default=".")
    report.add_argument("--run-id", default=None)

    args = parser.parse_args(argv)

    if args.cmd is None:
        parser.print_help()
        return 0

    if args.cmd == "inspect":
        state = new_state(goal="(inspect)", repo_root=args.repo_root)
        inspect_workspace(state)
        print(json.dumps(state.get("workspace", {}), indent=2, default=str))
        return 0

    if args.cmd == "plan":
        from .nodes.contract import read_repo_contract
        from .nodes.ingest import ingest_goal
        from .nodes.plan import plan_build

        state = new_state(args.goal, args.repo_root, workflow=args.workflow)
        ingest_goal(state)
        read_repo_contract(state)
        plan_build(state)
        print(json.dumps(state.get("task_queue", []), indent=2, default=str))
        return 0

    if args.cmd == "build":
        state = new_state(args.goal, args.repo_root, workflow=args.workflow)
        final = run_graph(state)
        write_task_status(state["repo_root"], final)
        print(json.dumps({"run_id": final["run_id"], "status": final.get("status")}, indent=2))
        return 0 if final.get("status") in ("done", "awaiting_approval", "finalizing") else 1

    if args.cmd == "resume":
        cp = _checkpointer(args.repo_root)
        loaded = cp.latest(args.run_id)
        if loaded is None:
            print("No checkpoint to resume.", file=sys.stderr)
            return 1
        run_id, node, state_dict = loaded
        # Re-enter at the node *after* the last successful one. For the
        # MiniGraph runner, that means we re-run the node that previously
        # raised ``ApprovalRequired`` — the approval flag has now flipped.
        state: HarnessState = state_dict  # type: ignore[assignment]
        final = run_graph(state, start=node)
        write_task_status(state["repo_root"], final)
        print(json.dumps({"run_id": final["run_id"], "status": final.get("status")}, indent=2))
        return 0

    if args.cmd == "report":
        cp = _checkpointer(args.repo_root)
        loaded = cp.latest(args.run_id)
        if loaded is None:
            print("No checkpoint to report on.", file=sys.stderr)
            return 1
        _, _, state_dict = loaded
        write_task_status(args.repo_root, state_dict)
        write_final_status(args.repo_root, state_dict)
        print("Wrote .agent/reports/final-status.md")
        return 0

    parser.error(f"unknown command: {args.cmd}")
    return 2


def _checkpointer(repo_root: str) -> SQLiteCheckpointer:
    return SQLiteCheckpointer(
        os.path.join(os.path.abspath(repo_root), ".agent", "state", "checkpoints.sqlite")
    )


if __name__ == "__main__":
    raise SystemExit(main())
