"""Tool authorities: terminal, files, git, Playwright."""
