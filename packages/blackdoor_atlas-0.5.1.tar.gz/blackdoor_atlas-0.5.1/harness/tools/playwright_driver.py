"""Playwright driver.

Prefers an MCP server when ``.agent/state/mcp.json`` is configured and the
MCP host can reach it; otherwise falls back to running the local Playwright
Test runner via subprocess. The flow definitions live in
``tests/browser/critical-flows.yaml``; the driver compiles each into a
generated Playwright spec file under ``tests/browser/.generated/`` so the
authoring contract stays YAML while the executor stays standard Playwright.
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import yaml

from .terminal import run


@dataclass
class FlowResult:
    flow_id: str
    passed: bool
    summary: str
    artifacts: List[str]


class PlaywrightDriver:
    def __init__(self, repo_root: str) -> None:
        self.repo_root = repo_root
        self.flows_path = os.path.join(repo_root, "tests", "browser", "critical-flows.yaml")
        self.generated_dir = os.path.join(repo_root, "tests", "browser", ".generated")
        self.evidence_dir = os.path.join(repo_root, ".agent", "artifacts", "browser")
        os.makedirs(self.generated_dir, exist_ok=True)
        os.makedirs(self.evidence_dir, exist_ok=True)

    # --- availability -----------------------------------------------------

    def is_available(self) -> bool:
        if shutil.which("npx") is None:
            return False
        # Look for an installed @playwright/test in node_modules; cheap check.
        nm = os.path.join(self.repo_root, "node_modules", "@playwright", "test")
        return os.path.isdir(nm)

    def mcp_configured(self) -> bool:
        path = os.path.join(self.repo_root, ".agent", "state", "mcp.json")
        if not os.path.exists(path):
            return False
        with open(path, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        servers = cfg.get("mcpServers") or {}
        return "playwright" in servers

    # --- flow loading -----------------------------------------------------

    def load_flows(self) -> Dict[str, Dict[str, Any]]:
        if not os.path.exists(self.flows_path):
            raise FileNotFoundError(self.flows_path)
        with open(self.flows_path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return {flow["id"]: flow for flow in data.get("flows", [])}

    # --- execution --------------------------------------------------------

    def run_flow(self, flow_id: str) -> FlowResult:
        flows = self.load_flows()
        if flow_id not in flows:
            raise FileNotFoundError(f"flow not defined: {flow_id}")
        spec_path = self._compile_spec(flow_id, flows[flow_id])
        result = run(
            ["npx", "playwright", "test", spec_path, "--reporter=line"],
            cwd=self.repo_root,
            repo_root=self.repo_root,
            timeout=180,
            check=False,
        )
        passed = result.exit_code == 0
        return FlowResult(
            flow_id=flow_id,
            passed=passed,
            summary=(result.stdout.splitlines() or [""])[-1],
            artifacts=[result.stdout_path or "", result.stderr_path or ""],
        )

    # --- spec generation --------------------------------------------------

    def _compile_spec(self, flow_id: str, flow: Dict[str, Any]) -> str:
        steps_js: List[str] = []
        for step in flow.get("steps", []):
            steps_js.append(_compile_step(step))
        body = "\n  ".join(steps_js)

        spec = f"""// Auto-generated from tests/browser/critical-flows.yaml — do not edit.
import {{ test, expect }} from '@playwright/test';

test('{flow_id}', async ({{ page }}) => {{
  await page.goto({json.dumps(flow.get('start_url', '/'))});
  {body}
}});
"""
        out = os.path.join(self.generated_dir, f"{flow_id}.spec.ts")
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(spec)
        return out


_STEP_HANDLERS = {}


def _step(name):
    def deco(fn):
        _STEP_HANDLERS[name] = fn
        return fn

    return deco


def _compile_step(step: Dict[str, Any]) -> str:
    if not isinstance(step, dict) or len(step) != 1:
        raise ValueError(f"step must be a single-key mapping: {step!r}")
    [(name, arg)] = step.items()
    handler = _STEP_HANDLERS.get(name)
    if handler is None:
        raise ValueError(f"unknown step kind: {name}")
    return handler(arg)


@_step("assert_text")
def _assert_text(arg: str) -> str:
    return f"await expect(page.getByText({json.dumps(arg)})).toBeVisible();"


@_step("assert_url_contains")
def _assert_url(arg: str) -> str:
    return f"await expect(page).toHaveURL(new RegExp({json.dumps(arg)}));"


@_step("click_role")
def _click_role(arg: Dict[str, str]) -> str:
    return (
        f"await page.getByRole({json.dumps(arg['role'])}, "
        f"{{ name: {json.dumps(arg['name'])} }}).click();"
    )


@_step("fill_label")
def _fill_label(arg: Dict[str, str]) -> str:
    return (
        f"await page.getByLabel({json.dumps(arg['label'])}).fill("
        f"{json.dumps(arg['value'])});"
    )


@_step("press")
def _press(arg: str) -> str:
    return f"await page.keyboard.press({json.dumps(arg)});"


@_step("type")
def _type(arg: str) -> str:
    return f"await page.keyboard.type({json.dumps(arg)});"


@_step("expect_visible_role")
def _expect_visible_role(arg: Dict[str, str]) -> str:
    return (
        f"await expect(page.getByRole({json.dumps(arg['role'])}, "
        f"{{ name: {json.dumps(arg['name'])} }})).toBeVisible();"
    )


@_step("goto")
def _goto(arg: str) -> str:
    return f"await page.goto({json.dumps(arg)});"


@_step("click_role_exact")
def _click_role_exact(arg: Dict[str, str]) -> str:
    return (
        f"await page.getByRole({json.dumps(arg['role'])}, "
        f"{{ name: {json.dumps(arg['name'])}, exact: true }}).click();"
    )
