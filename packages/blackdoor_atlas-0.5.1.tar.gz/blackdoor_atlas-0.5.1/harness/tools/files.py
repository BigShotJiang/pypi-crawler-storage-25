"""Safe file mutation layer.

Every write produces a per-write patch report under ``.agent/reports/`` and
appends a structured entry to ``state.patch_history`` via the caller. This
module is intentionally thin: it constrains writes to the workspace and
returns a record the caller appends to history.
"""

from __future__ import annotations

import difflib
import os
import time
import uuid
from typing import Any, Dict, Optional


def _ensure_inside(repo_root: str, path: str) -> str:
    abs_path = os.path.abspath(path)
    if not abs_path.startswith(os.path.abspath(repo_root) + os.sep) and abs_path != os.path.abspath(repo_root):
        raise PermissionError(f"refusing to write outside repo_root: {abs_path}")
    return abs_path


def write_with_patch_report(
    repo_root: str,
    path: str,
    content: str,
    *,
    intent: str,
    task_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Create or overwrite ``path`` with ``content``. Returns a patch dict."""

    abs_path = _ensure_inside(repo_root, path)
    operation = "update" if os.path.exists(abs_path) else "create"
    prior = ""
    if operation == "update":
        with open(abs_path, "r", encoding="utf-8", errors="replace") as fh:
            prior = fh.read()
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as fh:
        fh.write(content)
    diff = "".join(
        difflib.unified_diff(
            prior.splitlines(keepends=True),
            content.splitlines(keepends=True),
            fromfile=f"a/{os.path.relpath(abs_path, repo_root)}",
            tofile=f"b/{os.path.relpath(abs_path, repo_root)}",
        )
    )
    return {
        "id": f"patch-{uuid.uuid4().hex[:8]}",
        "task_id": task_id,
        "intent": intent,
        "files_changed": [
            {
                "path": os.path.relpath(abs_path, repo_root),
                "operation": operation,
                "bytes_added": max(len(content) - len(prior), 0),
                "bytes_removed": max(len(prior) - len(content), 0),
            }
        ],
        "commands": [],
        "results": {"pass": True, "summary": "file written"},
        "remaining_risks": [],
        "created_at": _now(),
        "diff": diff,
    }


def delete_with_patch_report(
    repo_root: str,
    path: str,
    *,
    intent: str,
    task_id: Optional[str] = None,
) -> Dict[str, Any]:
    abs_path = _ensure_inside(repo_root, path)
    prior = ""
    if os.path.exists(abs_path):
        with open(abs_path, "r", encoding="utf-8", errors="replace") as fh:
            prior = fh.read()
        os.remove(abs_path)
    return {
        "id": f"patch-{uuid.uuid4().hex[:8]}",
        "task_id": task_id,
        "intent": intent,
        "files_changed": [
            {
                "path": os.path.relpath(abs_path, repo_root),
                "operation": "delete",
                "bytes_added": 0,
                "bytes_removed": len(prior),
            }
        ],
        "commands": [],
        "results": {"pass": True, "summary": "file deleted"},
        "remaining_risks": [],
        "created_at": _now(),
    }


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
