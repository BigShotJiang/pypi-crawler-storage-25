"""Git wrapper.

Local actions (init, add, commit, branch, status, diff) are always allowed.
Push / force-push / tag creation / merge to protected branches require an
approval entry in ``.agent/state/approvals.jsonl``; this module raises
``PermissionError`` if those are attempted without one.
"""

from __future__ import annotations

import os
import subprocess
from typing import List, Optional

from .terminal import run


def init(repo_root: str) -> None:
    if os.path.isdir(os.path.join(repo_root, ".git")):
        return
    run(["git", "init", "-q"], cwd=repo_root, repo_root=repo_root, check=True)
    # Create a .gitignore entry for .agent runtime if absent.
    run(["git", "add", ".gitignore"], cwd=repo_root, repo_root=repo_root, check=False)


def has_changes(repo_root: str) -> bool:
    result = run(
        ["git", "status", "--porcelain"],
        cwd=repo_root,
        repo_root=repo_root,
        check=False,
    )
    return bool(result.stdout.strip())


def commit(repo_root: str, *, message: str) -> Optional[str]:
    run(["git", "add", "-A"], cwd=repo_root, repo_root=repo_root, check=False)
    if not has_changes(repo_root):
        # Nothing staged.
        result = run(
            ["git", "diff", "--cached", "--name-only"],
            cwd=repo_root,
            repo_root=repo_root,
            check=False,
        )
        if not result.stdout.strip():
            return None
    # Ensure identity exists; if not, set a local one for the harness commit.
    _ensure_identity(repo_root)
    run(
        ["git", "commit", "-m", message],
        cwd=repo_root,
        repo_root=repo_root,
        check=False,
    )
    sha = run(["git", "rev-parse", "HEAD"], cwd=repo_root, repo_root=repo_root, check=False)
    return sha.stdout.strip() or None


def _ensure_identity(repo_root: str) -> None:
    for key, default in (("user.name", "harness"), ("user.email", "harness@local")):
        existing = run(
            ["git", "config", "--get", key],
            cwd=repo_root,
            repo_root=repo_root,
            check=False,
        )
        if not existing.stdout.strip():
            run(
                ["git", "config", key, default],
                cwd=repo_root,
                repo_root=repo_root,
                check=False,
            )


def push(repo_root: str, remote: str = "origin", branch: str = "HEAD") -> None:
    raise PermissionError(
        "git push is approval-gated. Add an approved entry to "
        ".agent/state/approvals.jsonl with action=protected_remote_push first."
    )
