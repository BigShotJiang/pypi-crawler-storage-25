"""Terminal executor with structured logging.

Every command is appended to ``.agent/logs/commands.jsonl``. Stdout/stderr are
captured to per-command files under ``.agent/logs/<run>/<argv0>-<id>.{out,err}``.
"""

from __future__ import annotations

import json
import os
import shlex
import subprocess
import time
import uuid
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence


_SECRET_ENV_PREFIXES = ("AWS_", "GH_", "GITHUB_", "OPENAI_", "ANTHROPIC_")


@dataclass
class CommandResult:
    argv: List[str]
    cwd: str
    exit_code: int
    duration_ms: int
    stdout: str
    stderr: str
    stdout_path: Optional[str]
    stderr_path: Optional[str]


def run(
    argv: Sequence[str],
    *,
    cwd: str,
    repo_root: str,
    env_overrides: Optional[Dict[str, str]] = None,
    timeout: Optional[int] = 120,
    check: bool = False,
    capture: bool = True,
) -> CommandResult:
    """Run a command synchronously and log it."""

    env = _scrub_env(os.environ.copy())
    if env_overrides:
        env.update(env_overrides)

    logs_dir = os.path.join(repo_root, ".agent", "logs")
    os.makedirs(logs_dir, exist_ok=True)
    rid = uuid.uuid4().hex[:8]
    out_path = os.path.join(logs_dir, f"{argv[0]}-{rid}.out") if capture else None
    err_path = os.path.join(logs_dir, f"{argv[0]}-{rid}.err") if capture else None

    started = time.time()
    stdout = ""
    stderr = ""
    try:
        proc = subprocess.run(
            list(argv),
            cwd=cwd,
            env=env,
            capture_output=capture,
            text=True,
            timeout=timeout,
            check=False,
        )
        exit_code = proc.returncode
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
    except subprocess.TimeoutExpired as exc:
        exit_code = 124
        stderr = f"TIMEOUT after {exc.timeout}s\n"
    duration_ms = int((time.time() - started) * 1000)

    if out_path:
        with open(out_path, "w", encoding="utf-8", errors="replace") as fh:
            fh.write(stdout)
    if err_path:
        with open(err_path, "w", encoding="utf-8", errors="replace") as fh:
            fh.write(stderr)

    _log_command(repo_root, argv, cwd, exit_code, duration_ms, out_path, err_path)

    if check and exit_code != 0:
        raise RuntimeError(
            f"Command failed ({exit_code}): {shlex.join(argv)}\n--stderr--\n{stderr}"
        )

    return CommandResult(
        argv=list(argv),
        cwd=cwd,
        exit_code=exit_code,
        duration_ms=duration_ms,
        stdout=stdout,
        stderr=stderr,
        stdout_path=out_path,
        stderr_path=err_path,
    )


def spawn(
    argv: Sequence[str],
    *,
    cwd: str,
    env_overrides: Optional[Dict[str, str]] = None,
    log_path: Optional[str] = None,
) -> subprocess.Popen:
    """Spawn a long-running process and return the Popen handle."""

    env = _scrub_env(os.environ.copy())
    if env_overrides:
        env.update(env_overrides)

    stdout_fh = open(log_path, "w", encoding="utf-8") if log_path else subprocess.DEVNULL
    proc = subprocess.Popen(
        list(argv),
        cwd=cwd,
        env=env,
        stdout=stdout_fh,
        stderr=subprocess.STDOUT,
    )
    return proc


def _scrub_env(env: Dict[str, str]) -> Dict[str, str]:
    """Return a copy of ``env`` with obvious secrets redacted."""

    out = dict(env)
    for key in list(out.keys()):
        if any(key.startswith(p) for p in _SECRET_ENV_PREFIXES) or "TOKEN" in key or "SECRET" in key or "KEY" in key:
            out[key] = "<redacted>"
    return out


def _log_command(
    repo_root: str,
    argv: Sequence[str],
    cwd: str,
    exit_code: int,
    duration_ms: int,
    out_path: Optional[str],
    err_path: Optional[str],
) -> None:
    log_path = os.path.join(repo_root, ".agent", "logs", "commands.jsonl")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    entry = {
        "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "argv": list(argv),
        "cwd": cwd,
        "exit_code": exit_code,
        "duration_ms": duration_ms,
        "stdout_path": out_path,
        "stderr_path": err_path,
    }
    with open(log_path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")
