"""inspect_workspace — probe the host environment and existing repo."""

from __future__ import annotations

import os
import shutil
import sys
from typing import Dict

from ..io.reports import write_environment_check
from ..orchestrator.state import HarnessState, log_decision
from ..tools.terminal import run


def _tool(name: str) -> bool:
    return shutil.which(name) is not None


def inspect_workspace(state: HarnessState) -> HarnessState:
    repo_root = state["repo_root"]
    workspace = state.setdefault("workspace", {})

    versions: Dict[str, str] = {}
    for cmd in ("node", "npm", "pnpm", "uv", "git", "playwright", "docker"):
        if not _tool(cmd):
            versions[cmd] = "absent"
            continue
        result = run([cmd, "--version"], cwd=repo_root, repo_root=repo_root, check=False)
        versions[cmd] = (result.stdout or result.stderr or "").strip().splitlines()[0] if (result.stdout or result.stderr) else "unknown"
    versions["python"] = sys.version.split()[0]

    workspace.update(
        {
            "versions": versions,
            "package_managers": [m for m in ("npm", "pnpm") if _tool(m)],
            "git_initialized": os.path.isdir(os.path.join(repo_root, ".git")),
            "has_playwright": _tool("playwright")
            or os.path.exists(os.path.join(repo_root, "node_modules", "@playwright")),
            "has_apps_web": os.path.isdir(os.path.join(repo_root, "apps", "web")),
            "has_apps_api": os.path.isdir(os.path.join(repo_root, "apps", "api")),
        }
    )

    write_environment_check(repo_root, versions, workspace)
    log_decision(state, "inspect_workspace", "workspace_inspected", versions=versions)
    return state
