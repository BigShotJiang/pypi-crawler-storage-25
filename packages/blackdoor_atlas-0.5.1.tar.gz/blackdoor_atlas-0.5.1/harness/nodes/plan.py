"""plan_build — derive a task plan from the workflow + repo contract."""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List

from ..io.workflow_loader import load_workflow
from ..orchestrator.state import HarnessState, Task, log_decision


def plan_build(state: HarnessState) -> HarnessState:
    repo_root = state["repo_root"]
    workflow_path = os.path.join(
        repo_root, "agent", "workflows", f"{state.get('workflow', 'default-build')}.yaml"
    )
    workflow = load_workflow(workflow_path)

    # Default dogfood plan. A model-driven planner would replace this; the
    # contract-defined plan keeps the harness runnable end-to-end without an LLM.
    plan: Dict[str, Any] = {
        "epics": [
            {
                "id": "E1",
                "title": "Scaffold dogfood app",
                "tasks": [
                    _task(
                        "T1",
                        "Verify dogfood scaffold exists",
                        artifacts=["apps/web/package.json", "apps/api/package.json"],
                        dod=["apps/web and apps/api exist with package.json"],
                        validation=["check:apps_exist"],
                    ),
                ],
            },
            {
                "id": "E2",
                "title": "Validate dogfood app",
                "tasks": [
                    _task(
                        "T2",
                        "Static checks pass",
                        dod=["lint and typecheck succeed"],
                        validation=["npm run lint", "npm run typecheck"],
                    ),
                    _task(
                        "T3",
                        "Unit tests pass",
                        dod=["all unit tests green"],
                        validation=["npm run test"],
                    ),
                    _task(
                        "T4",
                        "Integration smoke",
                        dod=["api boots and /healthz returns 200"],
                        validation=["smoke:api_health"],
                    ),
                    _task(
                        "T5",
                        "Critical browser flows",
                        dod=["landing, signup, notes-crud all pass"],
                        validation=[
                            "browser:landing-page-smoke",
                            "browser:signup-flow",
                            "browser:notes-crud",
                        ],
                    ),
                ],
            },
        ],
        "success_criteria": workflow.get("success_criteria", []),
    }

    queue: List[Task] = []
    for epic in plan["epics"]:
        for t in epic["tasks"]:
            t["epic_id"] = epic["id"]
            t["status"] = "pending"
            t["retry_count"] = 0
            t["max_retries"] = 3
            queue.append(t)
    state["task_queue"] = queue
    state["status"] = "executing"

    plans_dir = os.path.join(repo_root, ".agent", "plans")
    os.makedirs(plans_dir, exist_ok=True)
    out = os.path.join(plans_dir, "plan.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(plan, fh, indent=2)

    # Companion markdown index — referenced by the blueprint as
    # ``.agent/reports/plan.md`` but kept under ``.agent/plans/`` so the JSON
    # and its narrative live side by side.
    md_lines = ["# Plan", "", f"_Run goal:_ {state.get('goal', '')}", ""]
    for epic in plan["epics"]:
        md_lines.append(f"## {epic['id']} — {epic['title']}")
        for t in epic["tasks"]:
            md_lines.append(f"- **{t['id']}** {t['title']}  ")
            md_lines.append(f"  - validation: `{', '.join(t['validation'])}`")
        md_lines.append("")
    reports_md = os.path.join(repo_root, ".agent", "reports", "plan.md")
    os.makedirs(os.path.dirname(reports_md), exist_ok=True)
    with open(reports_md, "w", encoding="utf-8") as fh:
        fh.write("\n".join(md_lines))

    log_decision(state, "plan_build", "plan_written", epics=len(plan["epics"]), tasks=len(queue))
    return state


def _task(
    id: str,
    title: str,
    *,
    artifacts: List[str] | None = None,
    dod: List[str],
    validation: List[str],
) -> Task:
    return Task(
        id=id,
        title=title,
        depends_on=[],
        artifacts_changed=artifacts or [],
        definition_of_done=dod,
        validation=validation,
    )
