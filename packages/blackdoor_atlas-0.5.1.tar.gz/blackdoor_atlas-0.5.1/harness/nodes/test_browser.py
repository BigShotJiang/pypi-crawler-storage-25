"""run_browser_validation — drive Playwright through critical flows."""

from __future__ import annotations

import os

from ._validation_common import record_result
from ..orchestrator.state import HarnessState, log_decision
from ..tools.playwright_driver import PlaywrightDriver


def run_browser_validation(state: HarnessState) -> HarnessState:
    active = state.get("active_task")
    if not active:
        return state

    flows = [v.split(":", 1)[1] for v in active.get("validation", []) if v.startswith("browser:")]
    if not flows:
        log_decision(state, "run_browser_validation", "no_browser_flows")
        return state

    repo_root = state["repo_root"]
    # The Playwright config spawns the dev server; record its URL on
    # state.services so the final report doesn't show "(not started)".
    state.setdefault("services", {}).setdefault(
        "web",
        {"pid": None, "port": 41822, "health_url": "http://localhost:41822/", "log_path": None},
    )
    driver = PlaywrightDriver(repo_root=repo_root)
    if not driver.is_available():
        # Treat as a soft fail — the harness still completes, but the task is
        # marked as blocked on Playwright bootstrap so the report surfaces it.
        record_result(
            state,
            "browser",
            "skipped",
            summary="Playwright is not installed; run `npx playwright install`",
        )
        state.setdefault("risks", []).append(
            "Browser validation skipped — Playwright not installed."
        )
        log_decision(state, "run_browser_validation", "playwright_unavailable")
        return state

    failed_flows = []
    for flow in flows:
        try:
            result = driver.run_flow(flow)
        except FileNotFoundError as exc:
            failed_flows.append((flow, str(exc)))
            continue
        if not result.passed:
            failed_flows.append((flow, result.summary))

    if failed_flows:
        record_result(
            state,
            "browser",
            "fail",
            summary="; ".join(f"{f}: {msg}" for f, msg in failed_flows),
        )
        state["_route"] = "triage_failures"
        log_decision(state, "run_browser_validation", "failed", flows=[f for f, _ in failed_flows])
    else:
        record_result(state, "browser", "pass", summary=f"{len(flows)} flows passed")
        log_decision(state, "run_browser_validation", "passed", flows=flows)

    # Save evidence path on state for the final report.
    artifacts_dir = os.path.join(repo_root, ".agent", "artifacts", "browser")
    if os.path.isdir(artifacts_dir):
        state.setdefault("artifacts", []).append(artifacts_dir)

    return state
