"""request_approval — raise ApprovalRequired so the engine interrupts."""

from __future__ import annotations

from ..orchestrator.interrupts import ApprovalRequired
from ..orchestrator.state import HarnessState, log_decision


def request_approval(state: HarnessState) -> HarnessState:
    task = state.get("active_task") or {}
    failed = state.get("failed_tasks", [])

    action = "manual_review_required"
    context = {
        "active_task": task,
        "failed_tasks": failed,
        "risks": state.get("risks", []),
    }
    log_decision(state, "request_approval", "interrupting", action=action)
    raise ApprovalRequired(action, context)
