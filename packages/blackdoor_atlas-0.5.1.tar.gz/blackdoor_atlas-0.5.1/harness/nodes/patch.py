"""generate_patch + apply_patch — minimal repair surface.

The autonomous fallback emits a *placeholder* patch report describing the
failure and the suggested fix class, but does not modify code on its own —
that is the LLM-driven coder's job. An LLM-bound caller should override
``generate_patch`` with a model-backed implementation; the engine contract is
that, after both nodes run, ``state["patch_history"]`` grows by one entry and
``state["_route"]`` is set to ``retest``.
"""

from __future__ import annotations

import os
import time
import uuid
from typing import Any, Dict

from ..io.reports import write_patch_report
from ..orchestrator.state import HarnessState, log_decision


def generate_patch(state: HarnessState) -> HarnessState:
    active = state.get("active_task") or {}
    record: Dict[str, Any] = {
        "id": f"patch-{uuid.uuid4().hex[:8]}",
        "task_id": active.get("id"),
        "intent": f"Address last failure for task {active.get('id')}: {active.get('title')}",
        "files_changed": [],
        "commands": [],
        "results": {"pass": False, "summary": "no-op (autonomous fallback)"},
        "remaining_risks": [
            "Autonomous fallback did not modify code — bind an LLM coder to make progress here.",
        ],
        "created_at": _now(),
    }
    state.setdefault("patch_history", []).append(record)
    log_decision(state, "generate_patch", "no_op_fallback", patch_id=record["id"])
    state["_route"] = "apply_patch"
    return state


def apply_patch(state: HarnessState) -> HarnessState:
    history = state.get("patch_history", [])
    if not history:
        log_decision(state, "apply_patch", "no_patch_to_apply")
        state["_route"] = "retest"
        return state

    last = history[-1]
    write_patch_report(state["repo_root"], last)
    log_decision(state, "apply_patch", "report_written", patch_id=last["id"])
    state["_route"] = "retest"
    return state


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
