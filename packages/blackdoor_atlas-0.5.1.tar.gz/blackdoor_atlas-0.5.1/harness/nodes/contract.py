"""read_repo_contract — load CLAUDE.md and agent/*.md instructions into state."""

from __future__ import annotations

import os
from typing import Dict, List

from ..orchestrator.state import HarnessState, log_decision


_CONTRACT_FILES = [
    "CLAUDE.md",
    "agent/system-overview.md",
    "agent/build-rules.md",
    "agent/product-spec.md",
    "agent/architecture.md",
]


def read_repo_contract(state: HarnessState) -> HarnessState:
    repo_root = state["repo_root"]
    contract: Dict[str, str] = {}
    missing: List[str] = []
    for rel in _CONTRACT_FILES:
        path = os.path.join(repo_root, rel)
        if not os.path.exists(path):
            missing.append(rel)
            continue
        with open(path, "r", encoding="utf-8") as fh:
            contract[rel] = fh.read()
    state.setdefault("workspace", {})["contract"] = contract
    if missing:
        state.setdefault("risks", []).append(
            "Missing contract files: " + ", ".join(missing)
        )
    log_decision(
        state,
        "read_repo_contract",
        "contract_loaded",
        files=list(contract.keys()),
        missing=missing,
    )
    return state
