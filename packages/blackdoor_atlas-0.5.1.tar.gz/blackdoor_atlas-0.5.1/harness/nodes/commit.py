"""commit_changes — local commit of the workspace state."""

from __future__ import annotations

import os

from ..orchestrator.state import HarnessState, log_decision
from ..tools import git as gittool


def commit_changes(state: HarnessState) -> HarnessState:
    repo_root = state["repo_root"]
    if not os.path.isdir(os.path.join(repo_root, ".git")):
        gittool.init(repo_root)
    if not gittool.has_changes(repo_root):
        log_decision(state, "commit_changes", "no_changes")
        return state
    sha = gittool.commit(
        repo_root,
        message=f"chore(harness): run {state['run_id']} — {state.get('goal', 'autonomous build')}",
    )
    if sha:
        log_decision(state, "commit_changes", "committed", sha=sha)
        state.setdefault("artifacts", []).append(f"git:{sha}")
    else:
        log_decision(state, "commit_changes", "commit_failed")
    return state
