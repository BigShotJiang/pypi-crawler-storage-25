"""run_static_validation — lint, typecheck, format check, build check."""

from __future__ import annotations

from ._validation_common import run_validation_layer
from ..orchestrator.state import HarnessState


def run_static_validation(state: HarnessState) -> HarnessState:
    return run_validation_layer(state, kind="static", commands_filter=_static_filter)


def _static_filter(command: str) -> bool:
    """Return True when this command is part of the static layer."""

    return any(
        token in command
        for token in ("lint", "typecheck", "format", "tsc", "build", "check:")
    )
