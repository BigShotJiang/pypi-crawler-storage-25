"""Graph nodes.

Each module exposes a single top-level function that takes ``HarnessState`` and
returns it. Conditional edges are expressed by setting ``state["_route"]``.
"""
