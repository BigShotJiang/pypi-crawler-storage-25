"""emit_report — write the final status report and task-status.json."""

from __future__ import annotations

from ..io.reports import write_browser_summary, write_final_status, write_task_status, write_test_summary
from ..orchestrator.state import HarnessState, log_decision


def emit_report(state: HarnessState) -> HarnessState:
    repo_root = state["repo_root"]
    write_task_status(repo_root, state)
    write_test_summary(repo_root, state)
    write_browser_summary(repo_root, state)
    write_final_status(repo_root, state)
    state["status"] = "done" if not state.get("failed_tasks") else "blocked"
    log_decision(state, "emit_report", "reports_written", final_status=state["status"])
    return state
