"""execute_task — pop the next task and route based on its validation kind.

For tasks whose validation is purely a shell command, ``execute_task`` does
not need an LLM: it simply readies the task and the downstream validation
nodes do the work. For tasks that change artifacts (``artifacts_changed``
non-empty), an LLM-driven coder would generate the patch; in the autonomous
fallback path we assume the artifacts already exist (the dogfood plan only
verifies them) and emit a check.
"""

from __future__ import annotations

import os
from typing import Optional

from ..orchestrator.state import HarnessState, Task, log_decision


def execute_task(state: HarnessState) -> HarnessState:
    queue = state.setdefault("task_queue", [])

    # Pull the next runnable task whose dependencies are met.
    task = _next_runnable(state)
    if task is None:
        # No more work — go straight to finalize.
        state["_route"] = "finalize_artifacts"
        log_decision(state, "execute_task", "queue_empty")
        return state

    task["status"] = "in_progress"
    state["active_task"] = task

    # Pre-execution check for "check:*" pseudo-validations that don't need any
    # validator node.
    for v in task.get("validation", []):
        if v == "check:apps_exist":
            ok = (
                os.path.exists(os.path.join(state["repo_root"], "apps", "web", "package.json"))
                and os.path.exists(os.path.join(state["repo_root"], "apps", "api", "package.json"))
            )
            if not ok:
                state.setdefault("risks", []).append("Dogfood apps not yet scaffolded")
                task["status"] = "blocked"
                task.setdefault("notes", []).append("apps/web or apps/api missing")

    log_decision(state, "execute_task", "task_started", id=task["id"], title=task["title"])
    return state


def _next_runnable(state: HarnessState) -> Optional[Task]:
    completed = {t["id"] for t in state.get("completed_tasks", [])}
    failed = {t["id"] for t in state.get("failed_tasks", [])}
    for t in state.get("task_queue", []):
        if t.get("status") in ("completed", "failed"):
            continue
        if t["id"] in completed or t["id"] in failed:
            continue
        if all(dep in completed for dep in t.get("depends_on", [])):
            return t
    return None
