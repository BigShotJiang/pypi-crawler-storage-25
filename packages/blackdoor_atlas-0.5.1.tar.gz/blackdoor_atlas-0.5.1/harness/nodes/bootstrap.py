"""bootstrap_environment — install dependencies, prepare .env, seed data."""

from __future__ import annotations

import os
import shutil

from ..orchestrator.state import HarnessState, log_decision
from ..tools.terminal import run


def bootstrap_environment(state: HarnessState) -> HarnessState:
    repo_root = state["repo_root"]
    workspace = state.get("workspace", {})

    actions = []

    # 1. Copy .env.example to .env.local when safe.
    example = os.path.join(repo_root, "apps", "api", ".env.example")
    target = os.path.join(repo_root, "apps", "api", ".env.local")
    if os.path.exists(example) and not os.path.exists(target):
        shutil.copyfile(example, target)
        actions.append("copied apps/api/.env.example -> apps/api/.env.local")

    # 2. Install workspace dependencies. Prefer pnpm if present, else npm.
    if "pnpm" in workspace.get("package_managers", []):
        install = ["pnpm", "install"]
    elif "npm" in workspace.get("package_managers", []):
        install = ["npm", "install"]
    else:
        install = None

    if install and os.path.exists(os.path.join(repo_root, "package.json")):
        result = run(install, cwd=repo_root, repo_root=repo_root, timeout=600, check=False)
        actions.append(f"{' '.join(install)} -> exit {result.exit_code}")
        if result.exit_code != 0:
            state.setdefault("risks", []).append(
                f"Dependency install failed: {' '.join(install)}"
            )

    # 3. The dogfood app uses better-sqlite3 with no migration tool — the DB
    #    is created lazily by ``apps/api/src/db.ts`` on first boot. Nothing to
    #    do here.

    log_decision(state, "bootstrap_environment", "bootstrapped", actions=actions)
    state["status"] = "executing"
    return state
