"""run_integration_tests — service boot + API smoke."""

from __future__ import annotations

import os
import socket
import time
import urllib.error
import urllib.request

from ._validation_common import record_result
from ..orchestrator.state import HarnessState, log_decision
from ..tools.terminal import spawn


def run_integration_tests(state: HarnessState) -> HarnessState:
    active = state.get("active_task")
    if not active:
        return state

    smoke_steps = [v for v in active.get("validation", []) if v.startswith("smoke:")]
    if not smoke_steps:
        state["_route"] = "run_browser_validation"
        return state

    repo_root = state["repo_root"]
    api_dir = os.path.join(repo_root, "apps", "api")

    failures = []

    if "smoke:api_health" in smoke_steps:
        if not os.path.exists(api_dir):
            failures.append("apps/api missing — cannot run api health smoke")
        else:
            port = _free_port()
            log_path = os.path.join(repo_root, ".agent", "logs", "api.smoke.log")
            proc = spawn(
                ["npm", "run", "dev"],
                cwd=api_dir,
                env_overrides={"PORT": str(port)},
                log_path=log_path,
            )
            state.setdefault("services", {})["api"] = {
                "pid": proc.pid,
                "port": port,
                "health_url": f"http://localhost:{port}/healthz",
                "log_path": log_path,
            }
            ok = _await_healthy(f"http://localhost:{port}/healthz", timeout_s=30)
            try:
                proc.terminate()
            except Exception:
                pass
            if not ok:
                failures.append("api /healthz did not respond in time")

    status = "fail" if failures else "pass"
    record_result(state, "integration", status, summary="; ".join(failures) or "smoke ok")

    if failures:
        state["_route"] = "triage_failures"
        log_decision(state, "run_integration_tests", "failed", failures=failures)
    else:
        log_decision(state, "run_integration_tests", "passed")
    return state


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _await_healthy(url: str, timeout_s: float) -> bool:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as resp:
                if 200 <= resp.status < 300:
                    return True
        except (urllib.error.URLError, ConnectionError, TimeoutError):
            pass
        time.sleep(0.5)
    return False
