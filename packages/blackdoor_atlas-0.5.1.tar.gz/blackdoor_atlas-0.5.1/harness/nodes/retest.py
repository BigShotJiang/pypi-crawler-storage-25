"""retest — re-run validation for the active task; back to execute_task on pass."""

from __future__ import annotations

from ..orchestrator.state import HarnessState, log_decision


def retest(state: HarnessState) -> HarnessState:
    """Hand back to execute_task to re-run validation for the active task.

    If the latest patch was a no-op fallback, mark the task failed and route to
    request_approval rather than spinning on a hopeless retry loop.
    """

    history = state.get("patch_history", [])
    last = history[-1] if history else None
    if last and not last.get("results", {}).get("pass", False) and not last.get("files_changed"):
        active = state.get("active_task")
        if active is not None:
            active["status"] = "failed"
            state.setdefault("failed_tasks", []).append(active)
            state["active_task"] = None
        state["_route"] = "request_approval"
        state["status"] = "blocked"
        log_decision(state, "retest", "no_op_patch_abort")
        return state

    state["_route"] = "execute_task"
    log_decision(state, "retest", "rerouted_to_execute_task")
    return state
