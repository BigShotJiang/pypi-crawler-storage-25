"""Helpers shared by static / unit / integration / browser validation nodes."""

from __future__ import annotations

import os
import time
from typing import Callable, List

from ..orchestrator.state import HarnessState, log_decision
from ..tools.terminal import run


def run_validation_layer(
    state: HarnessState,
    *,
    kind: str,
    commands_filter: Callable[[str], bool],
) -> HarnessState:
    """Run the subset of the active task's ``validation`` matching this layer.

    On any non-zero exit, route to ``triage_failures``; on no matching
    commands, advance via the linear order.
    """

    active = state.get("active_task")
    if not active:
        return state

    matched: List[str] = [v for v in active.get("validation", []) if commands_filter(v)]
    if not matched:
        log_decision(state, f"run_{kind}_validation", "no_commands")
        return state

    repo_root = state["repo_root"]
    failed: List[str] = []
    for command in matched:
        if command.startswith("check:"):
            # Pseudo-validation handled by execute_task; record as pass.
            continue
        argv = command.split()
        result = run(argv, cwd=repo_root, repo_root=repo_root, check=False, timeout=600)
        if result.exit_code != 0:
            failed.append(f"{command} (exit {result.exit_code})")

    if failed:
        record_result(state, kind, "fail", summary="; ".join(failed))
        state["_route"] = "triage_failures"
        log_decision(state, f"run_{kind}_validation", "failed", failures=failed)
    else:
        record_result(state, kind, "pass", summary=f"{len(matched)} command(s) passed")
        log_decision(state, f"run_{kind}_validation", "passed", count=len(matched))
    return state


def record_result(state: HarnessState, kind: str, status: str, summary: str) -> None:
    record = {
        "id": f"{kind}-{int(time.time() * 1000)}",
        "kind": kind,
        "started_at": _now(),
        "finished_at": _now(),
        "status": status,
        "summary": summary,
    }
    if kind == "browser":
        state.setdefault("ui_results", []).append(record)
    else:
        state.setdefault("test_results", []).append(record)


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
