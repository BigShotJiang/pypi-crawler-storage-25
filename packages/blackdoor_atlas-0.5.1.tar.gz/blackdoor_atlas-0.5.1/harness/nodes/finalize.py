"""finalize_artifacts — mark the active task complete, queue the next, or done."""

from __future__ import annotations

from ..orchestrator.state import HarnessState, log_decision


def finalize_artifacts(state: HarnessState) -> HarnessState:
    active = state.get("active_task")
    if active:
        active["status"] = "completed"
        state.setdefault("completed_tasks", []).append(active)
        state["active_task"] = None
        log_decision(state, "finalize_artifacts", "task_completed", id=active["id"])

    # Surface known limitations as honest risks/deferrals. The blueprint's
    # dogfood criterion #8 — "Fix at least one induced bug automatically" — is
    # not exercised by the autonomous fallback because ``generate_patch`` is a
    # no-op until an LLM coder is bound. Surface it explicitly rather than
    # silently shipping a green report.
    if not any(p.get("files_changed") for p in state.get("patch_history", [])):
        risk = (
            "Auto-repair not exercised: generate_patch is the no-op fallback. "
            "Bind an LLM coder before claiming the full dogfood criterion."
        )
        if risk not in state.get("risks", []):
            state.setdefault("risks", []).append(risk)
        deferred = state.setdefault("workspace", {}).setdefault("deferred", [])
        note = "Induced-bug auto-repair (blueprint dogfood criterion #8)"
        if note not in deferred:
            deferred.append(note)

    # If there are more tasks, loop back to execute_task; otherwise continue.
    remaining = [
        t
        for t in state.get("task_queue", [])
        if t.get("status") not in ("completed", "failed")
        and t["id"] not in {c["id"] for c in state.get("completed_tasks", [])}
        and t["id"] not in {f["id"] for f in state.get("failed_tasks", [])}
    ]
    if remaining:
        state["_route"] = "execute_task"
        return state

    state["status"] = "finalizing"
    return state
