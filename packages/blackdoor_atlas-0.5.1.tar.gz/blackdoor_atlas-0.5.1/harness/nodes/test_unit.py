"""run_unit_tests — drive the unit test runner for the active task."""

from __future__ import annotations

from ._validation_common import run_validation_layer
from ..orchestrator.state import HarnessState


def run_unit_tests(state: HarnessState) -> HarnessState:
    return run_validation_layer(state, kind="unit", commands_filter=_unit_filter)


def _unit_filter(command: str) -> bool:
    if command.startswith("browser:") or command.startswith("smoke:"):
        return False
    return "test" in command and "test:e2e" not in command and "integration" not in command
