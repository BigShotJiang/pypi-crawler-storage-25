"""triage_failures — classify the latest failure and route accordingly."""

from __future__ import annotations

from ..orchestrator.state import HarnessState, log_decision


_CLASSES = (
    ("MODULE_NOT_FOUND", "missing_dependency"),
    ("ECONNREFUSED", "service_not_ready"),
    ("EADDRINUSE", "port_in_use"),
    ("Cannot find module", "missing_dependency"),
    ("Type", "type_mismatch"),
    ("Timeout", "async_timing"),
    ("Selector resolved to", "browser_flow"),
    ("locator", "browser_flow"),
)


def triage_failures(state: HarnessState) -> HarnessState:
    last = _last_failure(state)
    if not last:
        # Nothing to triage — fall through.
        state["_route"] = "execute_task"
        log_decision(state, "triage_failures", "no_failure_found")
        return state

    summary = last.get("summary", "")
    classification = "unknown"
    for token, label in _CLASSES:
        if token in summary:
            classification = label
            break

    state.setdefault("decision_log", []).append({"at": _now(), "node": "triage_failures", "decision": "classified", "details": {"summary": summary, "class": classification}})

    active = state.get("active_task") or {}
    active["retry_count"] = active.get("retry_count", 0) + 1

    if active["retry_count"] >= active.get("max_retries", 3):
        # Budget exhausted — escalate.
        active["status"] = "failed"
        state.setdefault("failed_tasks", []).append(active)
        state["active_task"] = None
        state["_route"] = "request_approval"
        state["status"] = "blocked"
        log_decision(state, "triage_failures", "budget_exhausted", id=active.get("id"))
        return state

    state["_route"] = "generate_patch"
    log_decision(state, "triage_failures", "patch_requested", id=active.get("id"), classification=classification)
    return state


def _last_failure(state: HarnessState):
    for record in reversed(state.get("ui_results", [])):
        if record.get("status") in ("fail", "error"):
            return record
    for record in reversed(state.get("test_results", [])):
        if record.get("status") in ("fail", "error"):
            return record
    return None


def _now() -> str:
    import time

    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
