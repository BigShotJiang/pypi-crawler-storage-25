"""ingest_goal — record the goal and prepare run scaffolding."""

from __future__ import annotations

import os

from ..orchestrator.state import HarnessState, log_decision


def ingest_goal(state: HarnessState) -> HarnessState:
    repo_root = state["repo_root"]
    for sub in ("state", "logs", "artifacts", "plans", "reports"):
        os.makedirs(os.path.join(repo_root, ".agent", sub), exist_ok=True)
    state["status"] = "planning"
    log_decision(state, "ingest_goal", "goal_recorded", goal=state.get("goal", ""))
    return state
