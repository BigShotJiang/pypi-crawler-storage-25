// Workspaces ("companies") HTTP routes. List + create + rename + delete +
// switch-active. All routes are scoped to the authenticated user via
// company_members; you can only see / modify workspaces you belong to.

import { Router } from 'express';
import { z } from 'zod';
import { requireUser } from '../auth.js';
import { CompanyRepo } from '../repos/CompanyRepo.js';

const companyInput = z.object({
  name: z.string().min(1).max(60),
  color: z.string().regex(/^#[0-9a-fA-F]{3,8}$/).optional(),
  description: z.string().max(280).optional(),
});

const companyPatch = companyInput.partial();

const switchInput = z.object({
  company_id: z.number().int().positive(),
});

export const companiesRouter: Router = Router();
companiesRouter.use(requireUser);

// GET /api/companies — list workspaces the user belongs to.
companiesRouter.get('/', (req, res) => {
  // Resolve active first so we report is_active correctly. resolveActive
  // also self-heals if the stored id no longer points at a valid membership.
  const active = CompanyRepo.resolveActiveForUser(req.user!.id);
  res.json({
    active_company_id: active,
    companies: CompanyRepo.listForUser(req.user!.id, active),
  });
});

// POST /api/companies — create a new workspace. The creator is added as owner.
companiesRouter.post('/', (req, res) => {
  const parsed = companyInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_company', issues: parsed.error.flatten() }); return; }
  const company = CompanyRepo.create({
    ownerId: req.user!.id,
    name: parsed.data.name.trim(),
    color: parsed.data.color,
    description: parsed.data.description ?? '',
  });
  res.status(201).json(company);
});

// PATCH /api/companies/:id — rename / recolor / re-describe.
companiesRouter.patch('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  if (!CompanyRepo.isMember(id, req.user!.id)) { res.status(404).json({ error: 'not_found' }); return; }
  const parsed = companyPatch.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_company' }); return; }
  // Only owners + admins can edit company metadata. Members get a 403.
  const role = CompanyRepo.roleOf(id, req.user!.id);
  if (role !== 'owner' && role !== 'admin') { res.status(403).json({ error: 'forbidden' }); return; }
  res.json(CompanyRepo.update(id, parsed.data));
});

// DELETE /api/companies/:id — refuses if the user would be left without any
// workspace; owners only. Cascades through projects + members.
companiesRouter.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  if (!CompanyRepo.isMember(id, req.user!.id)) { res.status(404).json({ error: 'not_found' }); return; }
  if (CompanyRepo.roleOf(id, req.user!.id) !== 'owner') { res.status(403).json({ error: 'owner_only' }); return; }
  const remaining = CompanyRepo.listForUser(req.user!.id, null).filter((c) => c.id !== id);
  if (remaining.length === 0) {
    res.status(400).json({ error: 'last_workspace', hint: 'Create another workspace before deleting this one.' });
    return;
  }
  CompanyRepo.delete(id);
  // If we deleted the active workspace, swing to the next available one.
  CompanyRepo.setActiveForUser(req.user!.id, remaining[0]!.id);
  res.status(204).end();
});

// POST /api/companies/switch — set users.active_company_id. The next call
// to /api/projects and friends will scope to the new workspace.
companiesRouter.post('/switch', (req, res) => {
  const parsed = switchInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_request' }); return; }
  const cid = parsed.data.company_id;
  if (!CompanyRepo.isMember(cid, req.user!.id)) { res.status(404).json({ error: 'not_found' }); return; }
  CompanyRepo.setActiveForUser(req.user!.id, cid);
  res.json({ active_company_id: cid });
});
