import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db.js';
import { requireUser } from '../auth.js';

const noteInput = z.object({
  title: z.string().min(1).max(200),
  body: z.string().max(10_000).optional().default(''),
});

const notePatch = noteInput.partial();

export const notesRouter: Router = Router();

notesRouter.use(requireUser);

notesRouter.get('/', (req, res) => {
  const user = req.user!;
  const rows = db
    .prepare(
      'SELECT id, title, body, created_at FROM notes WHERE user_id = ? ORDER BY id DESC',
    )
    .all(user.id);
  res.json(rows);
});

notesRouter.post('/', (req, res) => {
  const user = req.user!;
  const parsed = noteInput.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'invalid_note' });
    return;
  }
  const info = db
    .prepare('INSERT INTO notes (user_id, title, body) VALUES (?, ?, ?)')
    .run(user.id, parsed.data.title, parsed.data.body);
  const row = db
    .prepare('SELECT id, title, body, created_at FROM notes WHERE id = ?')
    .get(Number(info.lastInsertRowid));
  res.status(201).json(row);
});

notesRouter.patch('/:id', (req, res) => {
  const user = req.user!;
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    res.status(400).json({ error: 'invalid_id' });
    return;
  }
  const parsed = notePatch.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'invalid_note' });
    return;
  }
  const existing = db
    .prepare('SELECT id FROM notes WHERE id = ? AND user_id = ?')
    .get(id, user.id);
  if (!existing) {
    res.status(404).json({ error: 'not_found' });
    return;
  }
  const fields: string[] = [];
  const values: unknown[] = [];
  if (parsed.data.title !== undefined) {
    fields.push('title = ?');
    values.push(parsed.data.title);
  }
  if (parsed.data.body !== undefined) {
    fields.push('body = ?');
    values.push(parsed.data.body);
  }
  if (fields.length > 0) {
    values.push(id);
    db.prepare(`UPDATE notes SET ${fields.join(', ')} WHERE id = ?`).run(...values);
  }
  const row = db
    .prepare('SELECT id, title, body, created_at FROM notes WHERE id = ?')
    .get(id);
  res.json(row);
});

notesRouter.delete('/:id', (req, res) => {
  const user = req.user!;
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    res.status(400).json({ error: 'invalid_id' });
    return;
  }
  const info = db
    .prepare('DELETE FROM notes WHERE id = ? AND user_id = ?')
    .run(id, user.id);
  if (info.changes === 0) {
    res.status(404).json({ error: 'not_found' });
    return;
  }
  res.status(204).end();
});
