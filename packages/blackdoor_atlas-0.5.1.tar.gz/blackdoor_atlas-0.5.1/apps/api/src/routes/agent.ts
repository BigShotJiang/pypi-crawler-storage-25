// POST /api/agent/chat        — SSE stream of agent events
// GET  /api/agent/info        — provider availability for the UI
// POST /api/agent/permission  — allow/deny a parked sensitive tool call

import { Router } from 'express';
import { z } from 'zod';
import { COOKIE_NAME, userFromSession } from '../auth.js';
import { decide as decidePermission } from '../agent/permissions.js';
import { runAgent } from '../agent/runner.js';
import { listProviders, selectProvider } from '../agent/providers/index.js';
import { repoMapData } from '../agent/repoMap.js';
import { CompanyRepo } from '../repos/CompanyRepo.js';
import { SessionsRepo } from '../repos/SessionsRepo.js';
import type { AgentEvent, ChatMessage } from '../agent/types.js';

export const agentRouter: Router = Router();

// The agent has unauthenticated tool access (read/write files, run commands).
// This is acceptable for local dev only. Reject any request whose source IP is
// not loopback so `vite --host` (or a misconfigured proxy) can't accidentally
// expose it to the LAN. Override with AGENT_ALLOW_REMOTE=1 (do not do this on
// a shared machine).
function isLocalhostOnly(req: { ip?: string; ips?: string[] }): boolean {
  if (process.env.AGENT_ALLOW_REMOTE === '1') return true;
  const candidates = [req.ip, ...(req.ips ?? [])].filter(Boolean) as string[];
  return candidates.every((ip) =>
    ip === '127.0.0.1' ||
    ip === '::1' ||
    ip === '::ffff:127.0.0.1' ||
    ip.startsWith('127.'),
  );
}

agentRouter.use((req, res, next) => {
  if (!isLocalhostOnly(req)) {
    res.status(403).json({
      error: 'forbidden',
      hint: 'Agent route is loopback-only. Set AGENT_ALLOW_REMOTE=1 to override (not recommended).',
    });
    return;
  }
  next();
});

agentRouter.get('/info', (_req, res) => {
  const providers = listProviders();
  const active = selectProvider();
  res.json({
    active: active ? { id: active.id, model: active.model } : null,
    providers,
  });
});

const blockSchema = z.union([
  z.object({ type: z.literal('text'), text: z.string() }),
  z.object({
    type: z.literal('tool_use'),
    id: z.string(),
    name: z.string(),
    input: z.record(z.unknown()),
  }),
]);

const messageSchema = z.union([
  z.object({ role: z.literal('user'), content: z.string() }),
  z.object({ role: z.literal('assistant'), content: z.array(blockSchema) }),
  z.object({
    role: z.literal('tool'),
    tool_use_id: z.string(),
    content: z.string(),
    is_error: z.boolean().optional(),
  }),
]);

const chatSchema = z.object({
  messages: z.array(messageSchema).min(1),
  thinking: z.boolean().optional(),
  effort: z.enum(['low', 'medium', 'high', 'xhigh', 'max']).optional(),
  /**
   * Aider-style mode. Determines which tools the agent gets and the system
   * prompt's editorial stance.
   *   - 'code'  (default) — full tool set, agent may edit and run commands
   *   - 'ask'             — read-only tools only (list_dir, read_file, search, list_projects, list_tasks); the agent discusses, never writes
   *   - 'plan'            — read-only tools + instruction to draft a numbered plan first; the user confirms with "go" before switching to code
   */
  mode: z.enum(['code', 'ask', 'plan']).optional().default('code'),
  /**
   * Aider-style explicit scope. The agent gets these as a system-prompt hint
   * — "you should treat these files as the canonical scope". Doesn't strictly
   * gate tool access; that would be too rigid for read-only exploration.
   */
  scope_files: z.array(z.string()).optional(),
  /**
   * OpenClaude action_required gate. When true the server emits a
   * `permission_required` event and parks the runner before write_file,
   * edit_file, or run_command. Default off; the terminal REPL sets it on.
   */
  confirm: z.boolean().optional().default(false),
});

agentRouter.post('/chat', (req, res) => {
  const parsed = chatSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'invalid_request', issues: parsed.error.flatten() });
    return;
  }

  const provider = selectProvider();
  if (!provider) {
    res.status(503).json({
      error: 'no_provider_configured',
      providers: listProviders(),
      hint: 'Set ANTHROPIC_API_KEY, or OPENAI_API_KEY, or run Ollama at http://localhost:11434/v1 (set OPENAI_BASE_URL).',
    });
    return;
  }

  res.status(200);
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('X-Accel-Buffering', 'no');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const controller = new AbortController();
  // res.on('close') fires only when the response stream actually ends.
  // req.on('close') would fire as soon as the request body finished being
  // received — which for an SSE handler is immediately after we read the
  // JSON body, aborting the upstream before it produces any tokens.
  res.on('close', () => controller.abort());

  // Tracks the wall-clock time of the most recent visible event so heartbeats
  // can report "elapsed since last token" — OpenClaude's pattern: the client
  // sees `thinking… 12s` ticking, not just dead air.
  const start = Date.now();
  let lastVisibleAt = start;

  const send = (event: AgentEvent) => {
    // Any event that the user can render counts as "activity" — heartbeat
    // doesn't, otherwise the elapsed counter would reset itself.
    if (event.type !== 'heartbeat') lastVisibleAt = Date.now();
    res.write(`event: ${event.type}\n`);
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };

  // Heartbeat: emit a real event every 3s. Carries the seconds since the
  // last token/tool/etc so the REPL can show a live counter. Doubles as the
  // SSE keep-alive — intermediaries don't drop a connection that's still
  // shipping events.
  const heartbeat = setInterval(() => {
    const idle = Math.round((Date.now() - lastVisibleAt) / 1000);
    const elapsed = Math.round((Date.now() - start) / 1000);
    res.write(`event: heartbeat\n`);
    res.write(`data: ${JSON.stringify({ type: 'heartbeat', idle_s: idle, elapsed_s: elapsed })}\n\n`);
  }, 3_000);

  // Resolve the user from the session cookie (best-effort) so PM tools can
  // scope by user_id. Terminal-only clients (./app chat) won't have a cookie
  // and get filesystem-only tools — the agent banner makes that visible.
  const sid = req.cookies?.[COOKIE_NAME] as string | undefined;
  const user = userFromSession(sid);

  runAgent(
    {
      userId: user?.id ?? null,
      companyId: user ? CompanyRepo.resolveActiveForUser(user.id) : null,
      provider,
      messages: parsed.data.messages as ChatMessage[],
      thinking: parsed.data.thinking,
      effort: parsed.data.effort,
      signal: controller.signal,
      mode: parsed.data.mode,
      scopeFiles: parsed.data.scope_files,
      confirm: parsed.data.confirm,
    },
    send,
  )
    .catch((err: Error) => {
      send({ type: 'error', message: err.message });
      send({ type: 'done' });
    })
    .finally(() => {
      clearInterval(heartbeat);
      res.end();
    });
});

// POST /api/agent/permission — { token, decision: "allow"|"deny", message? }
const permissionSchema = z.object({
  token: z.string().min(1),
  decision: z.enum(['allow', 'deny']),
  message: z.string().max(280).optional(),
});

agentRouter.post('/permission', (req, res) => {
  const parsed = permissionSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_permission' }); return; }
  const ok = decidePermission(
    parsed.data.token,
    parsed.data.decision === 'allow'
      ? { allow: true }
      : { allow: false, message: parsed.data.message ?? 'user denied' },
  );
  res.json({ ok });
});

// Session search (FTS5). Used by the REPL `/search` command — bypasses the
// LLM entirely for "have we talked about X" lookups.
const searchSchema = z.object({
  q: z.string().trim().min(1),
  limit: z.coerce.number().int().positive().max(50).optional().default(10),
});

agentRouter.get('/sessions/search', (req, res) => {
  const parsed = searchSchema.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_query', issues: parsed.error.flatten() }); return; }
  try {
    const hits = SessionsRepo.searchSessions(parsed.data.q, parsed.data.limit);
    res.json({ hits });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

agentRouter.get('/sessions/recent', (req, res) => {
  const limit = Math.max(1, Math.min(50, Number(req.query.limit ?? 10)));
  res.json({ sessions: SessionsRepo.recentSessions(limit) });
});

// Aider-style repo map for the Code Map tab. Cheap (in-memory cache, 30s
// TTL) so a tab switch doesn't re-walk the tree.
agentRouter.get('/repo-map', (_req, res) => {
  res.json(repoMapData());
});
