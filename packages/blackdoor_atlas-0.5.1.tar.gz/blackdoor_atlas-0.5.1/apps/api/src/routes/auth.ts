import { Router } from 'express';
import { z } from 'zod';
import { COOKIE_NAME, requireUser } from '../auth.js';
import { UserRepo } from '../repos/UserRepo.js';
import { SeedRepo } from '../repos/SeedRepo.js';

const credentials = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export const authRouter: Router = Router();

authRouter.post('/signup', (req, res) => {
  const parsed = credentials.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'invalid_credentials', issues: parsed.error.flatten() });
    return;
  }
  const { email, password } = parsed.data;
  if (UserRepo.findByEmail(email)) {
    res.status(409).json({ error: 'email_taken' });
    return;
  }
  const user = UserRepo.create(email, password);
  // Drop a Linear-style demo workspace in so the first-login experience
  // shows off the board, hotkeys, cycles, sub-issues — instead of an empty
  // inbox with "create a project" as the only call to action.
  try { SeedRepo.seedIfEmpty(user.id); }
  catch (err) { console.warn('[auth] seed failed for new user:', (err as Error).message); }
  const sid = UserRepo.createSession(user.id);
  res.cookie(COOKIE_NAME, sid, { httpOnly: true, sameSite: 'lax' });
  res.status(201).json({ id: user.id, email: user.email });
});

authRouter.post('/login', (req, res) => {
  const parsed = credentials.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'invalid_credentials' });
    return;
  }
  const { email, password } = parsed.data;
  const row = UserRepo.findByEmail(email);
  if (!row || !UserRepo.verifyPassword(password, row.password_hash)) {
    res.status(401).json({ error: 'invalid_credentials' });
    return;
  }
  // Auto-seed on login for accounts that signed up before SeedRepo existed
  // (or were created via a path that bypassed signup). seedIfEmpty is a
  // no-op when the user already has projects.
  try { SeedRepo.seedIfEmpty(row.id); }
  catch (err) { console.warn('[auth] seed failed on login:', (err as Error).message); }
  const sid = UserRepo.createSession(row.id);
  res.cookie(COOKIE_NAME, sid, { httpOnly: true, sameSite: 'lax' });
  res.json({ id: row.id, email: row.email });
});

authRouter.post('/logout', (req, res) => {
  const sid = req.cookies?.[COOKIE_NAME] as string | undefined;
  if (sid) UserRepo.destroySession(sid);
  res.clearCookie(COOKIE_NAME);
  res.status(204).end();
});

authRouter.get('/me', requireUser, (req, res) => {
  // Idempotent seed for users created before SeedRepo existed. seedIfEmpty
  // is a single COUNT(*) when projects already exist — cheap enough to run
  // on every /me call rather than gating on a one-shot flag.
  try { SeedRepo.seedIfEmpty(req.user!.id); }
  catch (err) { console.warn('[auth] seed failed on /me:', (err as Error).message); }
  res.json(req.user);
});
