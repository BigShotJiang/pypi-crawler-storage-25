// Cycles, insights, saved views, templates — all project-scoped.

import { Router } from 'express';
import { z } from 'zod';
import { requireCompany, requireUser } from '../auth.js';
import { CycleRepo } from '../repos/CycleRepo.js';
import { InsightsRepo } from '../repos/InsightsRepo.js';
import { ProjectRepo } from '../repos/ProjectRepo.js';
import { SavedViewRepo } from '../repos/SavedViewRepo.js';
import { TemplateRepo } from '../repos/TemplateRepo.js';
import { TASK_PRIORITIES } from '../domain/types.js';

export const cyclesRouter: Router = Router();
cyclesRouter.use(requireUser, requireCompany);

function ownsProject(req: Express.Request, projectId: number): boolean {
  return Boolean(ProjectRepo.findForCompany(projectId, (req as unknown as { companyId: number }).companyId));
}

// ---- cycles ----------------------------------------------------------------

const cycleInput = z.object({
  name: z.string().max(120).optional().default(''),
  start_date: z.string().min(1),
  end_date: z.string().min(1),
});

cyclesRouter.get('/projects/:projectId/cycles', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  res.json(CycleRepo.listForProject(projectId));
});

cyclesRouter.post('/projects/:projectId/cycles', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  const parsed = cycleInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_cycle' }); return; }
  if (parsed.data.end_date < parsed.data.start_date) { res.status(400).json({ error: 'end_before_start' }); return; }
  res.status(201).json(CycleRepo.create(projectId, parsed.data));
});

cyclesRouter.delete('/projects/:projectId/cycles/:cycleId', (req, res) => {
  const projectId = Number(req.params.projectId);
  const cycleId = Number(req.params.cycleId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  if (!CycleRepo.delete(projectId, cycleId)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});

// ---- insights --------------------------------------------------------------

cyclesRouter.get('/projects/:projectId/insights', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  res.json(InsightsRepo.forProject(projectId));
});

// ---- saved views -----------------------------------------------------------

const savedViewInput = z.object({
  name: z.string().min(1).max(120),
  payload: z.record(z.unknown()).optional().default({}),
});

cyclesRouter.get('/projects/:projectId/views', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  res.json(SavedViewRepo.listFor(req.user!.id, projectId));
});

cyclesRouter.post('/projects/:projectId/views', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  const parsed = savedViewInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_view' }); return; }
  res.status(201).json(SavedViewRepo.create(req.user!.id, projectId, parsed.data.name, parsed.data.payload));
});

cyclesRouter.delete('/projects/:projectId/views/:viewId', (req, res) => {
  const projectId = Number(req.params.projectId);
  const viewId = Number(req.params.viewId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  if (!SavedViewRepo.delete(req.user!.id, projectId, viewId)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});

// ---- templates -------------------------------------------------------------

const templateInput = z.object({
  name: z.string().min(1).max(120),
  title: z.string().min(1).max(280),
  body: z.string().max(20_000).optional().default(''),
  priority: z.enum(TASK_PRIORITIES).optional().default('med'),
  estimate: z.number().int().min(1).max(13).nullable().optional(),
});

cyclesRouter.get('/projects/:projectId/templates', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  res.json(TemplateRepo.listForProject(projectId));
});

cyclesRouter.post('/projects/:projectId/templates', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  const parsed = templateInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_template' }); return; }
  res.status(201).json(TemplateRepo.create(projectId, parsed.data));
});

cyclesRouter.delete('/projects/:projectId/templates/:templateId', (req, res) => {
  const projectId = Number(req.params.projectId);
  const templateId = Number(req.params.templateId);
  if (!ownsProject(req, projectId)) { res.status(404).json({ error: 'project_not_found' }); return; }
  if (!TemplateRepo.delete(projectId, templateId)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});
