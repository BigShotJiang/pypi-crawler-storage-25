// Projects + labels HTTP routes. Logic lives in ProjectRepo — this file is
// only request validation, workspace scoping (via requireCompany), and
// response shaping.

import { Router } from 'express';
import { z } from 'zod';
import { requireCompany, requireUser } from '../auth.js';
import { ProjectRepo } from '../repos/ProjectRepo.js';

const projectInput = z.object({
  name: z.string().min(1).max(120),
  description: z.string().max(4_000).optional().default(''),
  color: z.string().regex(/^#[0-9a-fA-F]{3,8}$/).optional(),
  status: z.enum(['active', 'paused', 'archived']).optional().default('active'),
});

const projectPatch = projectInput.partial();

const labelInput = z.object({
  name: z.string().min(1).max(40),
  color: z.string().regex(/^#[0-9a-fA-F]{3,8}$/).optional(),
});

export const projectsRouter: Router = Router();
projectsRouter.use(requireUser, requireCompany);

projectsRouter.get('/', (req, res) => {
  res.json(ProjectRepo.listForCompany(req.companyId!));
});

projectsRouter.post('/', (req, res) => {
  const parsed = projectInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_project' }); return; }
  res.status(201).json(
    ProjectRepo.create({
      userId: req.user!.id,
      companyId: req.companyId!,
      name: parsed.data.name,
      description: parsed.data.description,
      color: parsed.data.color,
      status: parsed.data.status,
    }),
  );
});

projectsRouter.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  const row = ProjectRepo.findForCompany(id, req.companyId!);
  if (!row) { res.status(404).json({ error: 'not_found' }); return; }
  res.json(row);
});

projectsRouter.patch('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  if (!ProjectRepo.findForCompany(id, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  const parsed = projectPatch.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_project' }); return; }
  res.json(ProjectRepo.update(id, parsed.data));
});

projectsRouter.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  if (!ProjectRepo.delete(id, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});

// --- labels ---------------------------------------------------------------

projectsRouter.get('/:id/labels', (req, res) => {
  const id = Number(req.params.id);
  if (!ProjectRepo.findForCompany(id, req.companyId!)) { res.status(404).json({ error: 'project_not_found' }); return; }
  res.json(ProjectRepo.listLabels(id));
});

projectsRouter.post('/:id/labels', (req, res) => {
  const id = Number(req.params.id);
  if (!ProjectRepo.findForCompany(id, req.companyId!)) { res.status(404).json({ error: 'project_not_found' }); return; }
  const parsed = labelInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_label' }); return; }
  try {
    res.status(201).json(ProjectRepo.createLabel(id, parsed.data.name, parsed.data.color ?? '#6b7280'));
  } catch (err) {
    const e = err as { code?: string };
    if (e.code === 'SQLITE_CONSTRAINT_UNIQUE') { res.status(409).json({ error: 'label_taken' }); return; }
    throw err;
  }
});

projectsRouter.delete('/:projectId/labels/:labelId', (req, res) => {
  const projectId = Number(req.params.projectId);
  const labelId = Number(req.params.labelId);
  if (!ProjectRepo.findForCompany(projectId, req.companyId!)) { res.status(404).json({ error: 'project_not_found' }); return; }
  if (!ProjectRepo.deleteLabel(projectId, labelId)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});
