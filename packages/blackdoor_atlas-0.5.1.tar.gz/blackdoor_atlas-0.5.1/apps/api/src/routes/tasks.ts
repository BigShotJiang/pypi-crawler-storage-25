// Tasks (issues) HTTP routes. Logic lives in TaskRepo / CycleRepo.

import { Router } from 'express';
import { z } from 'zod';
import { requireCompany, requireUser } from '../auth.js';
import { CycleRepo } from '../repos/CycleRepo.js';
import { ProjectRepo } from '../repos/ProjectRepo.js';
import { TaskRepo } from '../repos/TaskRepo.js';
import {
  TASK_PRIORITIES,
  TASK_STATUSES,
  type TaskStatus,
} from '../domain/types.js';

// Accept legacy 'doing' and map to 'started' on read.
const statusSchema = z
  .union([z.enum(TASK_STATUSES), z.literal('doing')])
  .transform((s): TaskStatus => (s === 'doing' ? 'started' : s));

const taskInput = z.object({
  project_id: z.number().int().positive(),
  title: z.string().min(1).max(280),
  body: z.string().max(20_000).optional().default(''),
  status: statusSchema.optional().default('todo'),
  priority: z.enum(TASK_PRIORITIES).optional().default('med'),
  assignee: z.string().max(120).optional().default(''),
  due_date: z.string().nullable().optional(),
  estimate: z.number().int().min(1).max(13).nullable().optional(),
  parent_id: z.number().int().positive().nullable().optional(),
  cycle_id: z.number().int().positive().nullable().optional(),
});
const taskPatch = taskInput.omit({ project_id: true }).partial();

const REACTION_EMOJI = new Set(['👍', '❤️', '🚀', '👀', '🎉', '😂', '🙏', '🔥']);

export const tasksRouter: Router = Router();
tasksRouter.use(requireUser, requireCompany);

// ---- list / inbox / mine / search -----------------------------------------

tasksRouter.get('/', (req, res) => {
  const projectId = Number(req.query.project_id);
  if (!Number.isInteger(projectId)) { res.status(400).json({ error: 'project_id_required' }); return; }
  if (!ProjectRepo.findForCompany(projectId, req.companyId!)) { res.status(404).json({ error: 'project_not_found' }); return; }

  let cycle_id: number | 'none' | undefined;
  if (req.query.cycle_id !== undefined) {
    const cid = Number(req.query.cycle_id);
    cycle_id = cid === 0 ? 'none' : Number.isInteger(cid) ? cid : undefined;
  }
  let parent_id: number | 'none' | undefined;
  if (req.query.parent_id !== undefined) {
    const pid = Number(req.query.parent_id);
    parent_id = pid === 0 ? 'none' : Number.isInteger(pid) ? pid : undefined;
  }
  res.json(TaskRepo.listInProject(projectId, { cycle_id, parent_id }));
});

tasksRouter.get('/inbox', (req, res) => {
  res.json(TaskRepo.inboxFor(req.companyId!));
});

tasksRouter.get('/mine', (req, res) => {
  res.json(TaskRepo.mineFor(req.companyId!, req.user!.email));
});

tasksRouter.get('/search', (req, res) => {
  res.json(TaskRepo.search(req.companyId!, String(req.query.q ?? '')));
});

// ---- detail ---------------------------------------------------------------

tasksRouter.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  const base = TaskRepo.findForCompany(id, req.companyId!);
  if (!base) { res.status(404).json({ error: 'not_found' }); return; }
  res.json({
    ...base,
    comments: TaskRepo.listComments(id, req.user!.email),
    activity: TaskRepo.listActivity(id),
  });
});

// ---- write ----------------------------------------------------------------

tasksRouter.post('/', (req, res) => {
  const parsed = taskInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_task', issues: parsed.error.flatten() }); return; }
  const { project_id, parent_id, cycle_id } = parsed.data;
  if (!ProjectRepo.findForCompany(project_id, req.companyId!)) { res.status(404).json({ error: 'project_not_found' }); return; }
  if (parent_id != null && !TaskRepo.workspaceCheck(parent_id, req.companyId!)) {
    res.status(400).json({ error: 'parent_not_in_workspace' });
    return;
  }
  if (cycle_id != null && !CycleRepo.belongsToProject(cycle_id, project_id)) {
    res.status(400).json({ error: 'cycle_not_in_project' });
    return;
  }
  const created = TaskRepo.create(parsed.data);
  TaskRepo.logActivity(created.id, 'created', req.user!.email, {
    title: created.title, status: created.status, priority: created.priority,
  });
  res.status(201).json(created);
});

tasksRouter.patch('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  const existing = TaskRepo.workspaceCheck(id, req.companyId!);
  if (!existing) { res.status(404).json({ error: 'not_found' }); return; }
  const parsed = taskPatch.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_task' }); return; }
  const updated = TaskRepo.update(id, parsed.data);
  // Side effects: completed_at + activity log.
  if (parsed.data.status !== undefined && parsed.data.status !== existing.status) {
    TaskRepo.setCompletedAt(id, parsed.data.status === 'done' ? new Date().toISOString() : null);
    TaskRepo.logActivity(id, 'status_changed', req.user!.email, { from: existing.status, to: parsed.data.status });
  }
  if (parsed.data.priority !== undefined) TaskRepo.logActivity(id, 'priority_changed', req.user!.email, { to: parsed.data.priority });
  if (parsed.data.title !== undefined)    TaskRepo.logActivity(id, 'title_changed', req.user!.email, { to: parsed.data.title });
  if (parsed.data.estimate !== undefined) TaskRepo.logActivity(id, 'estimate_changed', req.user!.email, { to: parsed.data.estimate });
  if (parsed.data.cycle_id !== undefined) TaskRepo.logActivity(id, 'cycle_changed', req.user!.email, { to: parsed.data.cycle_id });
  res.json(updated);
});

tasksRouter.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
  if (!TaskRepo.delete(id, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});

// ---- bulk + reorder -------------------------------------------------------

const bulkInput = z.object({
  ids: z.array(z.number().int().positive()).min(1).max(200),
  patch: z.object({
    status: statusSchema.optional(),
    priority: z.enum(TASK_PRIORITIES).optional(),
    estimate: z.number().int().min(1).max(13).nullable().optional(),
    cycle_id: z.number().int().nullable().optional(),
    assignee: z.string().max(120).optional(),
  }),
});

tasksRouter.post('/bulk', (req, res) => {
  const parsed = bulkInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_bulk' }); return; }
  const { ids, patch } = parsed.data;
  const { ids: ownedIds, previousStatusById } = TaskRepo.bulkUpdate(req.companyId!, ids, patch);
  if (patch.status !== undefined) {
    for (const id of ownedIds) {
      const prev = previousStatusById.get(id);
      if (prev && prev !== patch.status) {
        TaskRepo.setCompletedAt(id, patch.status === 'done' ? new Date().toISOString() : null);
        TaskRepo.logActivity(id, 'status_changed', req.user!.email, { from: prev, to: patch.status, bulk: true });
      }
    }
  }
  res.json({ updated: ownedIds.length });
});

const reorderInput = z.object({
  status: statusSchema,
  ordered_ids: z.array(z.number().int().positive()).max(500),
});

tasksRouter.post('/projects/:projectId/reorder', (req, res) => {
  const projectId = Number(req.params.projectId);
  if (!ProjectRepo.findForCompany(projectId, req.companyId!)) { res.status(404).json({ error: 'project_not_found' }); return; }
  const parsed = reorderInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_reorder' }); return; }
  TaskRepo.reorder(projectId, parsed.data.status, parsed.data.ordered_ids);
  res.json({ ok: true, n: parsed.data.ordered_ids.length });
});

// ---- labels on a task -----------------------------------------------------

tasksRouter.post('/:id/labels/:labelId', (req, res) => {
  const id = Number(req.params.id);
  const labelId = Number(req.params.labelId);
  const existing = TaskRepo.workspaceCheck(id, req.companyId!);
  if (!existing) { res.status(404).json({ error: 'not_found' }); return; }
  const labels = ProjectRepo.listLabels(existing.project_id);
  const label = labels.find((l) => l.id === labelId);
  if (!label) { res.status(404).json({ error: 'label_not_found' }); return; }
  TaskRepo.attachLabel(id, labelId);
  TaskRepo.logActivity(id, 'label_added', req.user!.email, { label: label.name });
  res.status(204).end();
});

tasksRouter.delete('/:id/labels/:labelId', (req, res) => {
  const id = Number(req.params.id);
  const labelId = Number(req.params.labelId);
  if (!TaskRepo.workspaceCheck(id, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  TaskRepo.detachLabel(id, labelId);
  TaskRepo.logActivity(id, 'label_removed', req.user!.email, { label_id: labelId });
  res.status(204).end();
});

// ---- subtasks -------------------------------------------------------------

const subtaskInput = z.object({ title: z.string().min(1).max(200), done: z.boolean().optional() });
const subtaskPatch = subtaskInput.partial();

tasksRouter.post('/:id/subtasks', (req, res) => {
  const id = Number(req.params.id);
  if (!TaskRepo.workspaceCheck(id, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  const parsed = subtaskInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_subtask' }); return; }
  const sub = TaskRepo.addSubtask(id, parsed.data.title, parsed.data.done ?? false);
  TaskRepo.logActivity(id, 'subtask_added', req.user!.email, { title: sub.title });
  res.status(201).json(sub);
});

tasksRouter.patch('/:taskId/subtasks/:subtaskId', (req, res) => {
  const taskId = Number(req.params.taskId);
  const subtaskId = Number(req.params.subtaskId);
  if (!TaskRepo.workspaceCheck(taskId, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  const parsed = subtaskPatch.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_subtask' }); return; }
  const result = TaskRepo.updateSubtask(taskId, subtaskId, parsed.data);
  if (parsed.data.done !== undefined) {
    TaskRepo.logActivity(taskId, 'subtask_toggled', req.user!.email, { subtask_id: subtaskId, done: parsed.data.done });
  }
  res.json(result);
});

tasksRouter.delete('/:taskId/subtasks/:subtaskId', (req, res) => {
  const taskId = Number(req.params.taskId);
  const subtaskId = Number(req.params.subtaskId);
  if (!TaskRepo.workspaceCheck(taskId, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  if (!TaskRepo.deleteSubtask(taskId, subtaskId)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});

// ---- comments + reactions -------------------------------------------------

const commentInput = z.object({ body: z.string().min(1).max(8_000) });
const reactionInput = z.object({ emoji: z.string().min(1).max(8) });

tasksRouter.post('/:id/comments', (req, res) => {
  const id = Number(req.params.id);
  if (!TaskRepo.workspaceCheck(id, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  const parsed = commentInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: 'invalid_comment' }); return; }
  const c = TaskRepo.addComment(id, req.user!.email, parsed.data.body);
  TaskRepo.logActivity(id, 'commented', req.user!.email, { snippet: parsed.data.body.slice(0, 80) });
  res.status(201).json(c);
});

tasksRouter.delete('/:taskId/comments/:commentId', (req, res) => {
  const taskId = Number(req.params.taskId);
  const commentId = Number(req.params.commentId);
  if (!TaskRepo.workspaceCheck(taskId, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  if (!TaskRepo.deleteComment(taskId, commentId, req.user!.email)) { res.status(404).json({ error: 'not_found' }); return; }
  res.status(204).end();
});

tasksRouter.post('/:taskId/comments/:commentId/reactions', (req, res) => {
  const taskId = Number(req.params.taskId);
  const commentId = Number(req.params.commentId);
  if (!TaskRepo.workspaceCheck(taskId, req.companyId!)) { res.status(404).json({ error: 'not_found' }); return; }
  const parsed = reactionInput.safeParse(req.body);
  if (!parsed.success || !REACTION_EMOJI.has(parsed.data.emoji)) {
    res.status(400).json({ error: 'invalid_emoji' });
    return;
  }
  res.json(TaskRepo.toggleReaction(commentId, req.user!.email, parsed.data.emoji));
});
