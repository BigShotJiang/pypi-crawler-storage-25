import type { User } from '../domain/types.js';

declare global {
  namespace Express {
    interface Request {
      user?: User;
      /** Resolved by requireCompany(): the user's active workspace id. */
      companyId?: number;
    }
  }
}

export {};
