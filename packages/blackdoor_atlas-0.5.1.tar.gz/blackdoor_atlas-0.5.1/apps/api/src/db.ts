import Database from 'better-sqlite3';
import path from 'node:path';

const DEFAULT_PATH = path.resolve(process.cwd(), 'data.sqlite');

const dbPath = process.env.DATABASE_PATH ?? DEFAULT_PATH;
export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#5b8def',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'todo',
    priority TEXT NOT NULL DEFAULT 'med',
    assignee TEXT NOT NULL DEFAULT '',
    due_date TEXT,
    sort_index INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT
  );

  CREATE TABLE IF NOT EXISTS labels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    color TEXT NOT NULL DEFAULT '#6b7280',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(project_id, name)
  );

  CREATE TABLE IF NOT EXISTS task_labels (
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    label_id INTEGER NOT NULL REFERENCES labels(id) ON DELETE CASCADE,
    PRIMARY KEY (task_id, label_id)
  );

  CREATE TABLE IF NOT EXISTS subtasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    sort_index INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    author TEXT NOT NULL DEFAULT '',
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL DEFAULT '{}',
    actor TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS cycles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    number INTEGER NOT NULL,
    name TEXT NOT NULL DEFAULT '',
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'upcoming',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(project_id, number)
  );

  CREATE TABLE IF NOT EXISTS reactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    comment_id INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    author TEXT NOT NULL,
    emoji TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(comment_id, author, emoji)
  );

  CREATE TABLE IF NOT EXISTS saved_views (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    payload TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL DEFAULT '',
    priority TEXT NOT NULL DEFAULT 'med',
    estimate INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  -- Linear-style workspaces ("companies"). A user belongs to many companies
  -- via company_members; each company owns its own projects, cycles, labels.
  CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    key TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#5e6ad2',
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS company_members (
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL DEFAULT 'member',   -- owner | admin | member
    joined_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (company_id, user_id)
  );

  CREATE INDEX IF NOT EXISTS idx_notes_user ON notes(user_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
  CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
  CREATE INDEX IF NOT EXISTS idx_tasks_project_status ON tasks(project_id, status);
  CREATE INDEX IF NOT EXISTS idx_labels_project ON labels(project_id);
  CREATE INDEX IF NOT EXISTS idx_subtasks_task ON subtasks(task_id);
  CREATE INDEX IF NOT EXISTS idx_comments_task ON comments(task_id);
  CREATE INDEX IF NOT EXISTS idx_activity_task ON activity(task_id);
  CREATE INDEX IF NOT EXISTS idx_cycles_project ON cycles(project_id);
  CREATE INDEX IF NOT EXISTS idx_reactions_comment ON reactions(comment_id);
  CREATE INDEX IF NOT EXISTS idx_savedviews_user ON saved_views(user_id, project_id);
  CREATE INDEX IF NOT EXISTS idx_templates_project ON templates(project_id);
  CREATE INDEX IF NOT EXISTS idx_company_members_user ON company_members(user_id);
  CREATE INDEX IF NOT EXISTS idx_company_members_company ON company_members(company_id);
`);

// --- runtime migrations -----------------------------------------------------
// SQLite has no native migration tool; we add columns idempotently here so a
// repo that's been running keeps its data while picking up new columns.

function columns(table: string): Set<string> {
  const rows = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  return new Set(rows.map((r) => r.name));
}

function ensureColumn(table: string, name: string, ddl: string): void {
  if (!columns(table).has(name)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${ddl}`);
  }
}

// Linear-style project key (e.g. LAU) — derived from name on insert, then
// becomes immutable so existing task identifiers stay stable.
ensureColumn('projects', 'key', "TEXT NOT NULL DEFAULT ''");
// Per-project monotonic counter; combined with project.key into LAU-1.
ensureColumn('tasks', 'task_number', 'INTEGER NOT NULL DEFAULT 0');

// Linear-DNA additions.
ensureColumn('tasks', 'estimate', 'INTEGER');                          // 1, 2, 3, 5, 8, null
ensureColumn('tasks', 'parent_id', 'INTEGER REFERENCES tasks(id) ON DELETE CASCADE');
ensureColumn('tasks', 'cycle_id', 'INTEGER REFERENCES cycles(id) ON DELETE SET NULL');

// Status pipeline: existing 'doing' rows become 'started' so the Linear
// pipeline (backlog/todo/started/review/done/cancelled) takes effect without
// dropping data. Idempotent.
db.exec(`UPDATE tasks SET status = 'started' WHERE status = 'doing'`);

// Backfill: any existing project without a `key` gets a 3-letter slug from its
// name; any existing task without `task_number` gets one based on creation
// order within its project. This keeps the running dev DB working through the
// schema change without requiring a wipe.
const backfillProjectKey = db.prepare(
  `UPDATE projects
     SET key = SUBSTR(UPPER(REPLACE(name, ' ', '')), 1, 3) || CAST(id AS TEXT)
   WHERE key = '' OR key IS NULL`,
);
backfillProjectKey.run();

const tasksMissingNumber = db
  .prepare(`SELECT id, project_id FROM tasks WHERE task_number = 0 ORDER BY project_id, id`)
  .all() as Array<{ id: number; project_id: number }>;
if (tasksMissingNumber.length > 0) {
  const counters = new Map<number, number>();
  const upd = db.prepare(`UPDATE tasks SET task_number = ? WHERE id = ?`);
  const tx = db.transaction((rows: typeof tasksMissingNumber) => {
    for (const row of rows) {
      const next = (counters.get(row.project_id) ?? 0) + 1;
      counters.set(row.project_id, next);
      upd.run(next, row.id);
    }
  });
  tx(tasksMissingNumber);
}

// --- workspaces (companies) migration -------------------------------------
// projects.user_id stays as the creator/legacy owner. company_id is the new
// authoritative scope. Each existing user gets a "Personal" company on first
// boot, and their existing projects are attached to it. users.active_company_id
// records which workspace they last viewed (the sidebar's selected option).
ensureColumn('projects', 'company_id', 'INTEGER REFERENCES companies(id) ON DELETE CASCADE');
ensureColumn('users', 'active_company_id', 'INTEGER REFERENCES companies(id) ON DELETE SET NULL');

const usersNeedingPersonal = db
  .prepare(
    `SELECT u.id, u.email
       FROM users u
      WHERE NOT EXISTS (SELECT 1 FROM company_members cm WHERE cm.user_id = u.id)`,
  )
  .all() as Array<{ id: number; email: string }>;
if (usersNeedingPersonal.length > 0) {
  const insertCompany = db.prepare(
    `INSERT INTO companies (name, key, color, description) VALUES (?, ?, ?, ?)`,
  );
  const insertMember = db.prepare(
    `INSERT INTO company_members (company_id, user_id, role) VALUES (?, ?, 'owner')`,
  );
  const attachExistingProjects = db.prepare(
    `UPDATE projects SET company_id = ? WHERE user_id = ? AND company_id IS NULL`,
  );
  const setActive = db.prepare(`UPDATE users SET active_company_id = ? WHERE id = ?`);
  const tx = db.transaction((rows: typeof usersNeedingPersonal) => {
    for (const u of rows) {
      const info = insertCompany.run('Personal', 'PRS', '#5e6ad2', `Personal workspace for ${u.email}`);
      const cid = Number(info.lastInsertRowid);
      insertMember.run(cid, u.id);
      attachExistingProjects.run(cid, u.id);
      setActive.run(cid, u.id);
    }
  });
  tx(usersNeedingPersonal);
}

// Belt-and-suspenders: any orphaned project (user has a company, project
// somehow lacks company_id) gets attached to that user's first company.
db.exec(`
  UPDATE projects
     SET company_id = (
       SELECT cm.company_id FROM company_members cm
        WHERE cm.user_id = projects.user_id
        ORDER BY cm.joined_at LIMIT 1
     )
   WHERE company_id IS NULL
`);

// Set active_company_id for any user that has memberships but no active set.
db.exec(`
  UPDATE users
     SET active_company_id = (
       SELECT cm.company_id FROM company_members cm
        WHERE cm.user_id = users.id
        ORDER BY cm.joined_at LIMIT 1
     )
   WHERE active_company_id IS NULL
`);

db.exec(`CREATE INDEX IF NOT EXISTS idx_projects_company ON projects(company_id)`);
