import express from 'express';
import cookieParser from 'cookie-parser';
import { agentRouter } from './routes/agent.js';
import { authRouter } from './routes/auth.js';
import { companiesRouter } from './routes/companies.js';
import { cyclesRouter } from './routes/cycles.js';
import { notesRouter } from './routes/notes.js';
import { projectsRouter } from './routes/projects.js';
import { tasksRouter } from './routes/tasks.js';

export function createServer(): express.Express {
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  app.use(cookieParser());

  app.get('/healthz', (_req, res) => {
    res.json({ ok: true });
  });

  app.use('/api/auth', authRouter);
  app.use('/api/companies', companiesRouter);
  app.use('/api/notes', notesRouter);
  app.use('/api/projects', projectsRouter);
  app.use('/api/tasks', tasksRouter);
  app.use('/api/agent', agentRouter);
  app.use('/api', cyclesRouter);

  return app;
}

const port = Number(process.env.PORT ?? 41821);

if (process.env.VITEST !== 'true' && process.argv[1]?.endsWith('server.ts')) {
  const app = createServer();
  app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`api listening on http://localhost:${port}`);
  });
}
