// Tool registry — provider-agnostic. Each tool has a JSONSchema input shape
// and a `run(input)` that returns a string result. Path-taking tools are
// constrained to the repo root via `safeJoin`.
//
// Two tool families:
//   - Static (filesystem, shell, search) — repo-scoped, no user context.
//   - Session-bound (PM data) — closed over a user_id from the agent route.
// `buildTools(ctx)` assembles the per-request list.

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile, writeFile, readdir, stat, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { db } from '../db.js';
import { MemoryRepo } from '../repos/MemoryRepo.js';
import { SessionsRepo } from '../repos/SessionsRepo.js';
import { invalidateRepoMap } from './repoMap.js';
import { repoRoot } from './system.js';
import type { ToolDef } from './types.js';

const execFileP = promisify(execFile);
const ROOT = repoRoot();

export interface ToolContext {
  userId: number | null;
  /** Active workspace. PM tools scope all queries by this. */
  companyId: number | null;
}

function safeJoin(rel: string): string {
  const abs = path.resolve(ROOT, rel);
  if (!abs.startsWith(ROOT + path.sep) && abs !== ROOT) {
    throw new Error(`path escapes repo root: ${rel}`);
  }
  return abs;
}

export interface ToolImpl {
  def: ToolDef;
  run(input: Record<string, unknown>): Promise<string>;
}

const staticTools: ToolImpl[] = [
  {
    def: {
      name: 'list_dir',
      description: 'List the entries of a directory (relative to the repo root). Use this to discover paths before reading or editing.',
      input_schema: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Directory path relative to the repo root. Use "." for the repo root.' },
        },
        required: ['path'],
        additionalProperties: false,
      },
    },
    async run({ path: p }) {
      const target = safeJoin(String(p ?? '.'));
      const entries = await readdir(target, { withFileTypes: true });
      const rows = await Promise.all(
        entries
          .filter((e) => !e.name.startsWith('.git') && e.name !== 'node_modules' && e.name !== '.venv')
          .sort((a, b) => a.name.localeCompare(b.name))
          .map(async (e) => {
            const full = path.join(target, e.name);
            const s = await stat(full);
            const kind = e.isDirectory() ? 'dir' : e.isFile() ? 'file' : 'other';
            return `${kind.padEnd(5)} ${String(s.size).padStart(8)} ${e.name}${e.isDirectory() ? '/' : ''}`;
          }),
      );
      return rows.length ? rows.join('\n') : '(empty)';
    },
  },
  {
    def: {
      name: 'read_file',
      description: 'Read a UTF-8 text file relative to the repo root. Returns at most ~200KB; longer files are truncated with a marker.',
      input_schema: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'File path relative to the repo root.' },
        },
        required: ['path'],
        additionalProperties: false,
      },
    },
    async run({ path: p }) {
      const target = safeJoin(String(p));
      const body = await readFile(target, 'utf8');
      const MAX = 200_000;
      return body.length > MAX
        ? body.slice(0, MAX) + `\n…[truncated ${body.length - MAX} bytes]`
        : body;
    },
  },
  {
    def: {
      name: 'write_file',
      description: 'Write a UTF-8 text file relative to the repo root. Creates parent directories. Overwrites if the file exists. Use sparingly — only when you intend to change the file.',
      input_schema: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'File path relative to the repo root.' },
          content: { type: 'string', description: 'Full file contents.' },
        },
        required: ['path', 'content'],
        additionalProperties: false,
      },
    },
    async run({ path: p, content }) {
      const target = safeJoin(String(p));
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, String(content ?? ''), 'utf8');
      invalidateRepoMap();
      return `wrote ${path.relative(ROOT, target)} (${String(content ?? '').length} bytes)`;
    },
  },
  {
    def: {
      name: 'edit_file',
      description: 'In-place edit: replace the first exact occurrence of `find` with `replace` in `path`. `find` must match exactly (whitespace included) and appear exactly once. For broader changes use write_file.',
      input_schema: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          find: { type: 'string' },
          replace: { type: 'string' },
        },
        required: ['path', 'find', 'replace'],
        additionalProperties: false,
      },
    },
    async run({ path: p, find, replace }) {
      const target = safeJoin(String(p));
      const body = await readFile(target, 'utf8');
      const f = String(find);
      const r = String(replace);
      const first = body.indexOf(f);
      if (first === -1) return `ERROR: find string not found in ${p}`;
      if (body.indexOf(f, first + 1) !== -1) return `ERROR: find string appears more than once in ${p}; use write_file or provide more context in find`;
      const next = body.slice(0, first) + r + body.slice(first + f.length);
      await writeFile(target, next, 'utf8');
      invalidateRepoMap();
      return `edited ${path.relative(ROOT, target)} (−${f.length} +${r.length} bytes)`;
    },
  },
  {
    def: {
      name: 'search',
      description: 'Search file contents for a regular expression. Returns up to 80 matching lines with path:line:content. Use this to locate symbols, error messages, or call sites before reading whole files.',
      input_schema: {
        type: 'object',
        properties: {
          pattern: { type: 'string', description: 'Regex pattern (Perl-compatible).' },
          path: { type: 'string', description: 'Directory or file to search. Defaults to the repo root.' },
        },
        required: ['pattern'],
        additionalProperties: false,
      },
    },
    async run({ pattern, path: p }) {
      const where = safeJoin(String(p ?? '.'));
      const args = [
        '-rnI', String(pattern), where,
        '--include=*.ts', '--include=*.tsx', '--include=*.js', '--include=*.py',
        '--include=*.md', '--include=*.yaml', '--include=*.yml', '--include=*.json',
        '--exclude-dir=node_modules', '--exclude-dir=.git', '--exclude-dir=.venv',
        '--exclude-dir=dist', '--exclude-dir=.agent',
      ];
      try {
        const { stdout } = await execFileP('grep', args, { maxBuffer: 1024 * 1024, timeout: 15_000 });
        const lines = stdout.split('\n').filter(Boolean);
        const head = lines.slice(0, 80);
        const truncated = lines.length > 80 ? `\n…[${lines.length - 80} more matches]` : '';
        return head.length ? head.join('\n') + truncated : '(no matches)';
      } catch (err) {
        const e = err as { code?: number; stderr?: string };
        if (e.code === 1) return '(no matches)';
        return `ERROR: ${e.stderr ?? String(err)}`;
      }
    },
  },
  {
    def: {
      name: 'run_command',
      description: 'Run a shell command inside the repo root. 30s timeout, 4MB output cap. Use for `git`, `npm run …`, file inspection, etc. Do not use for long-running servers — start them in another tool or hand off to the user.',
      input_schema: {
        type: 'object',
        properties: {
          command: { type: 'string', description: 'Command to run via /bin/sh -c.' },
        },
        required: ['command'],
        additionalProperties: false,
      },
    },
    async run({ command }) {
      const cmd = String(command);
      try {
        const { stdout, stderr } = await execFileP('/bin/sh', ['-c', cmd], {
          cwd: ROOT,
          timeout: 30_000,
          maxBuffer: 4 * 1024 * 1024,
        });
        const out = stdout?.toString() ?? '';
        const err = stderr?.toString() ?? '';
        return [
          `$ ${cmd}`,
          out && `--- stdout ---\n${out}`,
          err && `--- stderr ---\n${err}`,
          '(exit 0)',
        ].filter(Boolean).join('\n');
      } catch (err) {
        const e = err as { code?: number | string; stdout?: string; stderr?: string; killed?: boolean };
        return [
          `$ ${cmd}`,
          e.stdout && `--- stdout ---\n${e.stdout}`,
          e.stderr && `--- stderr ---\n${e.stderr}`,
          e.killed ? '(killed — exceeded 30s)' : `(exit ${e.code ?? 'unknown'})`,
        ].filter(Boolean).join('\n');
      }
    },
  },
];

// --- PM tools (workspace-scoped) -----------------------------------------

function pmTools(companyId: number): ToolImpl[] {
  return [
    {
      def: {
        name: 'list_projects',
        description: 'List all projects in the active workspace. Returns id, name, status, and counts. Use this before suggesting work — match by project name to find ids.',
        input_schema: { type: 'object', properties: {}, additionalProperties: false },
      },
      async run() {
        const rows = db
          .prepare(
            `SELECT p.id, p.name, p.status,
                    (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) AS task_count,
                    (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'done') AS done_count
               FROM projects p
              WHERE p.company_id = ?
              ORDER BY p.created_at DESC`,
          )
          .all(companyId) as Array<{ id: number; name: string; status: string; task_count: number; done_count: number }>;
        if (rows.length === 0) return '(no projects)';
        return rows
          .map((p) => `#${p.id}  [${p.status}]  ${p.name}  (${p.done_count}/${p.task_count} done)`)
          .join('\n');
      },
    },
    {
      def: {
        name: 'list_tasks',
        description: 'List tasks for one project (user-scoped). Returns id, status, priority, title, assignee.',
        input_schema: {
          type: 'object',
          properties: {
            project_id: { type: 'number', description: 'Project id (from list_projects).' },
          },
          required: ['project_id'],
          additionalProperties: false,
        },
      },
      async run({ project_id }) {
        const pid = Number(project_id);
        if (!Number.isInteger(pid)) return 'ERROR: project_id must be an integer';
        const proj = db.prepare('SELECT id FROM projects WHERE id = ? AND company_id = ?').get(pid, companyId);
        if (!proj) return `ERROR: project ${pid} not found in active workspace`;
        const rows = db
          .prepare(
            `SELECT id, title, status, priority, assignee, due_date
               FROM tasks WHERE project_id = ?
              ORDER BY status, sort_index, id`,
          )
          .all(pid) as Array<{ id: number; title: string; status: string; priority: string; assignee: string; due_date: string | null }>;
        if (rows.length === 0) return '(no tasks)';
        return rows
          .map((t) => `#${t.id}  [${t.status}/${t.priority}]  ${t.title}${t.assignee ? `  @${t.assignee}` : ''}${t.due_date ? `  due ${t.due_date}` : ''}`)
          .join('\n');
      },
    },
    {
      def: {
        name: 'create_task',
        description: 'Create a task in a project. Returns the new task id.',
        input_schema: {
          type: 'object',
          properties: {
            project_id: { type: 'number' },
            title: { type: 'string', description: 'Short imperative description, max 280 chars.' },
            body: { type: 'string', description: 'Optional longer notes.' },
            priority: { type: 'string', description: 'one of: low | med | high (default med)' },
            status: { type: 'string', description: 'one of: todo | doing | done (default todo)' },
          },
          required: ['project_id', 'title'],
          additionalProperties: false,
        },
      },
      async run({ project_id, title, body, priority, status }) {
        const pid = Number(project_id);
        if (!Number.isInteger(pid)) return 'ERROR: project_id must be an integer';
        const proj = db.prepare('SELECT id FROM projects WHERE id = ? AND company_id = ?').get(pid, companyId);
        if (!proj) return `ERROR: project ${pid} not found in active workspace`;
        const t = String(title ?? '').trim();
        if (!t) return 'ERROR: title is required';
        const pri = ['low', 'med', 'high'].includes(String(priority)) ? String(priority) : 'med';
        const st = ['todo', 'doing', 'done'].includes(String(status)) ? String(status) : 'todo';
        const sortRow = db
          .prepare('SELECT COALESCE(MAX(sort_index), -1) AS max_sort FROM tasks WHERE project_id = ? AND status = ?')
          .get(pid, st) as { max_sort: number };
        const info = db
          .prepare(
            `INSERT INTO tasks (project_id, title, body, status, priority, sort_index)
             VALUES (?, ?, ?, ?, ?, ?)`,
          )
          .run(pid, t.slice(0, 280), String(body ?? ''), st, pri, sortRow.max_sort + 1);
        return `created task #${Number(info.lastInsertRowid)} "${t}" in project ${pid} (${st}/${pri})`;
      },
    },
    {
      def: {
        name: 'update_task',
        description: 'Update one task: change status, priority, title, body, or assignee. Use to mark a task done, re-prioritize, or refine a title. Only one task at a time.',
        input_schema: {
          type: 'object',
          properties: {
            id: { type: 'number' },
            title: { type: 'string' },
            body: { type: 'string' },
            status: { type: 'string', description: 'todo | doing | done' },
            priority: { type: 'string', description: 'low | med | high' },
            assignee: { type: 'string' },
          },
          required: ['id'],
          additionalProperties: false,
        },
      },
      async run(input) {
        const id = Number(input.id);
        if (!Number.isInteger(id)) return 'ERROR: id must be an integer';
        const row = db
          .prepare(
            `SELECT t.id, t.status FROM tasks t
               JOIN projects p ON p.id = t.project_id
              WHERE t.id = ? AND p.company_id = ?`,
          )
          .get(id, companyId) as { id: number; status: string } | undefined;
        if (!row) return `ERROR: task ${id} not found in active workspace`;
        const fields: string[] = [];
        const values: unknown[] = [];
        for (const key of ['title', 'body', 'status', 'priority', 'assignee'] as const) {
          if (input[key] !== undefined) {
            fields.push(`${key} = ?`);
            values.push(String(input[key]));
          }
        }
        if (input.status !== undefined && input.status !== row.status) {
          fields.push('completed_at = ?');
          values.push(input.status === 'done' ? new Date().toISOString() : null);
        }
        if (fields.length === 0) return `(no-op; task ${id} unchanged)`;
        values.push(id);
        db.prepare(`UPDATE tasks SET ${fields.join(', ')} WHERE id = ?`).run(...values);
        return `updated task #${id}: ${fields.join(', ')}`;
      },
    },
  ];
}

// --- memory tool (Hermes-style, always on) -------------------------------

const memoryTool: ToolImpl = {
  def: {
    name: 'memory',
    description:
      'Read or write the agent\'s persistent memory. There are two files: ' +
      '`memory` (notes about this repo / environment / conventions) and ' +
      '`user` (preferences and communication style). Use sparingly — only for ' +
      '*durable* facts you want to recall next session. Writes are visible ' +
      'in the system prompt starting the next session (this turn keeps its ' +
      'cached snapshot). Actions: read | add | replace | remove.',
    input_schema: {
      type: 'object',
      properties: {
        action: { type: 'string', description: 'read | add | replace | remove' },
        target: { type: 'string', description: 'memory | user (default: memory)' },
        entry: { type: 'string', description: 'For add: the line to add. Bullet prefix is optional.' },
        find: { type: 'string', description: 'For replace/remove: substring to match.' },
        replace: { type: 'string', description: 'For replace: substring to insert in place of `find`.' },
      },
      required: ['action'],
      additionalProperties: false,
    },
  },
  async run(input) {
    const action = String(input.action ?? '');
    const target = (input.target === 'user' ? 'user' : 'memory') as 'memory' | 'user';
    if (action === 'read') {
      const snap = MemoryRepo.read();
      return `--- ${target}.md ---\n${target === 'memory' ? snap.memory : snap.user}`;
    }
    if (action === 'add') {
      const r = MemoryRepo.add(target, String(input.entry ?? ''));
      return r.added ? `added to ${target}.md` : `skipped (${r.reason})`;
    }
    if (action === 'replace') {
      const r = MemoryRepo.replace(target, String(input.find ?? ''), String(input.replace ?? ''));
      if (!r.changed && r.matches === 0) return `ERROR: \`find\` not found in ${target}.md`;
      if (!r.changed && r.matches > 1) return `ERROR: \`find\` matches ${r.matches} times in ${target}.md — be more specific`;
      return `replaced in ${target}.md`;
    }
    if (action === 'remove') {
      const r = MemoryRepo.remove(target, String(input.find ?? ''));
      return r.removed === 0 ? `ERROR: \`find\` not found in ${target}.md` : `removed ${r.removed} occurrence(s) from ${target}.md`;
    }
    return `ERROR: unknown action "${action}" (use read | add | replace | remove)`;
  },
};

// --- session_search (Hermes-style FTS5 over .agent/sessions/*.json) -------

const sessionSearchTool: ToolImpl = {
  def: {
    name: 'session_search',
    description:
      'Full-text search across the agent\'s prior session transcripts ' +
      '(.agent/sessions/*.json). Use this when the user references "last ' +
      'time we…", "previous session", "earlier conversation", or to ' +
      'recall what was discussed before. Supports FTS5 syntax: bare terms ' +
      'are ANDed, "exact phrase" for phrases, term* for prefix, OR / NOT. ' +
      'Returns ranked snippets with session ids — read the JSON via ' +
      'read_file if you need the full transcript.',
    input_schema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'FTS5 query. Examples: `permission gate`, `"linear sidebar"`, `cycle* NOT done`' },
        limit: { type: 'number', description: 'Max results (1–50, default 10).' },
      },
      required: ['query'],
      additionalProperties: false,
    },
  },
  async run(input) {
    const q = String(input.query ?? '').trim();
    if (!q) return 'ERROR: query is required';
    const limit = Number.isFinite(Number(input.limit)) ? Number(input.limit) : 10;
    let hits;
    try {
      hits = SessionsRepo.searchSessions(q, limit);
    } catch (err) {
      return `ERROR: ${(err as Error).message}`;
    }
    if (hits.length === 0) return '(no matches across prior sessions)';
    return hits
      .map((h, i) => {
        const when = (h.updated_at || h.created_at || '').slice(0, 19).replace('T', ' ');
        const head = `${i + 1}. ${h.session_id}  ${when}  ${h.provider}/${h.model}  (${h.message_count} msgs)`;
        const first = h.first_user ? `   first: ${h.first_user.replace(/\s+/g, ' ').slice(0, 120)}` : '';
        const snip = `   match: ${h.snippet.replace(/\s+/g, ' ').slice(0, 200)}`;
        const file = `   file:  ${h.path}`;
        return [head, first, snip, file].filter(Boolean).join('\n');
      })
      .join('\n\n');
  },
};

function activeTools(ctx: ToolContext): ToolImpl[] {
  if (ctx.userId == null || ctx.companyId == null) {
    return [...staticTools, memoryTool, sessionSearchTool];
  }
  return [...staticTools, memoryTool, sessionSearchTool, ...pmTools(ctx.companyId)];
}

export function buildToolDefs(ctx: ToolContext): ToolDef[] {
  return activeTools(ctx).map((t) => t.def);
}

export async function runTool(
  name: string,
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<{ content: string; is_error: boolean }> {
  const tool = activeTools(ctx).find((t) => t.def.name === name);
  if (!tool) return { content: `ERROR: unknown tool ${name}`, is_error: true };
  try {
    const content = await tool.run(input);
    const is_error = content.startsWith('ERROR:');
    return { content, is_error };
  } catch (err) {
    return { content: `ERROR: ${(err as Error).message}`, is_error: true };
  }
}
