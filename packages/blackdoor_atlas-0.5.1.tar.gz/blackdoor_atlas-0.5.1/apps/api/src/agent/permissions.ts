// In-process permission registry. Each entry is a promise the runner awaits
// while the SSE stream stays open. The client decides via
// POST /api/agent/permission { token, decision, message? }.
//
// Auto-deny if no decision arrives within TTL_MS — keeps the runner from
// hanging forever if the client disappears mid-prompt.

import crypto from 'node:crypto';

export type Decision = { allow: true } | { allow: false; message: string };

interface Pending {
  resolve: (d: Decision) => void;
  timer: NodeJS.Timeout;
  context: { tool: string; tool_use_id: string };
}

const TTL_MS = 120_000;
const pending = new Map<string, Pending>();

/**
 * Returns { token, decisionPromise }. The runner awaits decisionPromise.
 * The route uses the token in the permission_required SSE event.
 */
export function awaitDecision(ctx: { tool: string; tool_use_id: string }): {
  token: string;
  decisionPromise: Promise<Decision>;
} {
  const token = `perm-${crypto.randomBytes(8).toString('hex')}`;
  let resolveFn!: (d: Decision) => void;
  const decisionPromise = new Promise<Decision>((res) => { resolveFn = res; });
  const timer = setTimeout(() => {
    if (pending.delete(token)) {
      resolveFn({ allow: false, message: 'timed out (no decision in 2 min)' });
    }
  }, TTL_MS);
  pending.set(token, { resolve: resolveFn, timer, context: ctx });
  return { token, decisionPromise };
}

/** Decide a pending request. No-op if the token doesn't exist (idempotent). */
export function decide(token: string, decision: Decision): boolean {
  const p = pending.get(token);
  if (!p) return false;
  pending.delete(token);
  clearTimeout(p.timer);
  p.resolve(decision);
  return true;
}

/** Force-deny all pending requests for cleanup (e.g. on client disconnect). */
export function denyAll(reason: string): void {
  for (const [token, p] of pending.entries()) {
    pending.delete(token);
    clearTimeout(p.timer);
    p.resolve({ allow: false, message: reason });
  }
}
