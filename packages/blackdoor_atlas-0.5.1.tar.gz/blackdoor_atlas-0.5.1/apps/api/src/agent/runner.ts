// Agent runner: drives the manual agentic loop and yields events.
//
// Aider-style modes:
//   code (default) — full tool set, agent may edit files and run commands
//   ask            — read-only tools only; the agent discusses, never writes
//   plan           — read-only tools + an editorial directive to draft a
//                    numbered plan first and ask for confirmation before
//                    switching to code mode

import path from 'node:path';
import { readFileSync } from 'node:fs';
import type { AgentEvent, ChatMessage, Provider, ToolDef } from './types.js';
import { buildToolDefs, runTool, type ToolContext } from './tools.js';
import { loadSystemPrompt, repoRoot } from './system.js';
import { MemoryRepo } from '../repos/MemoryRepo.js';
import { awaitDecision } from './permissions.js';

export type AgentMode = 'code' | 'ask' | 'plan';

export interface RunOptions {
  provider: Provider;
  // Conversation up to (and including) the latest user message. The runner
  // appends assistant + tool messages as it iterates, but does not persist —
  // the caller (web client) keeps its own history.
  messages: ChatMessage[];
  thinking?: boolean;
  effort?: 'low' | 'medium' | 'high' | 'xhigh' | 'max';
  maxIterations?: number;
  signal?: AbortSignal;
  // Auth context for user-scoped tools (PM data). Null disables those tools
  // — the agent falls back to filesystem-only access.
  userId?: number | null;
  /** Active workspace; required for PM tools to be enabled. */
  companyId?: number | null;
  mode?: AgentMode;
  // Aider-style file scope: paths the user explicitly added. Surfaced to the
  // model as a system-prompt hint, not enforced — the model can still read
  // anywhere if it needs to.
  scopeFiles?: string[];
  // OpenClaude action_required gate. When true (default in code mode), the
  // runner pauses before executing write_file, edit_file, or run_command,
  // emits a permission_required event, and awaits a POST decision.
  confirm?: boolean;
}

// Tools that mutate state OR run arbitrary code. These are the ones the
// permission gate covers.
const SENSITIVE_TOOLS = new Set(['write_file', 'edit_file', 'run_command']);

// Tools that mutate state. Stripped from the tool set in `ask` and `plan`.
const WRITE_TOOLS = new Set([
  'write_file',
  'edit_file',
  'run_command',
  'create_task',
  'update_task',
]);

const DEFAULT_MAX_ITERATIONS = 10;

export async function runAgent(
  opts: RunOptions,
  onEvent: (e: AgentEvent) => void,
): Promise<void> {
  const mode: AgentMode = opts.mode ?? 'code';
  const toolCtx: ToolContext = { userId: opts.userId ?? null, companyId: opts.companyId ?? null };
  const allTools: ToolDef[] = buildToolDefs(toolCtx);
  const tools: ToolDef[] = mode === 'code'
    ? allTools
    : allTools.filter((t) => !WRITE_TOOLS.has(t.name));

  // Snapshot memory + user files NOW, at turn start, and freeze them for the
  // duration of this iteration. Memory writes that happen during the turn
  // persist to disk but only appear in the system prompt next session — the
  // Hermes "frozen snapshot pattern" that keeps the prompt cache hot.
  const memSnapshot = MemoryRepo.read();
  const system = decorateSystem(
    loadSystemPrompt({ memory: memSnapshot.memory, user: memSnapshot.user }),
    mode,
    opts.scopeFiles,
  );

  const max = opts.maxIterations ?? DEFAULT_MAX_ITERATIONS;
  const messages: ChatMessage[] = [...opts.messages];

  onEvent({ type: 'started', provider: opts.provider.id, model: opts.provider.model });

  for (let i = 0; i < max; i++) {
    if (opts.signal?.aborted) {
      onEvent({ type: 'error', message: 'aborted by client' });
      onEvent({ type: 'done' });
      return;
    }

    let result;
    try {
      result = await opts.provider.iterate(
        {
          system,
          tools,
          messages,
          thinking: opts.thinking,
          effort: opts.effort,
          signal: opts.signal,
        },
        onEvent,
      );
    } catch (err) {
      onEvent({ type: 'error', message: (err as Error).message });
      onEvent({ type: 'done' });
      return;
    }

    messages.push({ role: 'assistant', content: result.assistant });

    if (result.stop_reason !== 'tool_use') {
      onEvent({ type: 'done' });
      return;
    }

    for (const block of result.assistant) {
      if (block.type !== 'tool_use') continue;
      // Belt-and-suspenders: even if a model fabricates a write tool name
      // we don't expose, refuse it.
      if (mode !== 'code' && WRITE_TOOLS.has(block.name)) {
        const content = `ERROR: write tool "${block.name}" is not available in ${mode} mode. Switch to /mode code in the REPL (or add ?mode=code) and ask again.`;
        onEvent({ type: 'tool_result', id: block.id, name: block.name, content, is_error: true });
        messages.push({ role: 'tool', tool_use_id: block.id, content, is_error: true });
        continue;
      }

      // OpenClaude action_required: park sensitive tool calls and wait for
      // the user to allow or deny. Skipped when the caller disabled confirm
      // (default off for web AI panel, default on for the terminal REPL).
      if (opts.confirm && SENSITIVE_TOOLS.has(block.name)) {
        const { token, decisionPromise } = awaitDecision({ tool: block.name, tool_use_id: block.id });
        onEvent({
          type: 'permission_required',
          token,
          tool_use_id: block.id,
          tool: block.name,
          input: block.input,
          preview: summarizeToolInput(block.name, block.input),
        });
        const decision = await decisionPromise;
        if (!decision.allow) {
          const content = `ERROR: user denied (${decision.message || 'no reason given'})`;
          onEvent({ type: 'tool_result', id: block.id, name: block.name, content, is_error: true });
          messages.push({ role: 'tool', tool_use_id: block.id, content, is_error: true });
          continue;
        }
      }

      const { content, is_error } = await runTool(block.name, block.input, toolCtx);
      onEvent({ type: 'tool_result', id: block.id, name: block.name, content, is_error });
      messages.push({ role: 'tool', tool_use_id: block.id, content, is_error });
    }
  }

  onEvent({ type: 'error', message: `reached max iterations (${max})` });
  onEvent({ type: 'done' });
}

function decorateSystem(base: string, mode: AgentMode, scope: string[] | undefined): string {
  const lines: string[] = [base];
  if (mode === 'ask') {
    lines.push(
      '',
      '== MODE: ask ==',
      'You are read-only. You can search the repo, list directories, read files, and discuss approach.',
      'You CANNOT write files, edit files, run shell commands, or modify project/task data.',
      'When the user wants you to actually do something, tell them to switch with `/mode code`.',
    );
  } else if (mode === 'plan') {
    lines.push(
      '',
      '== MODE: plan ==',
      'Draft a concrete, numbered plan first. Use only read-only tools to gather context.',
      'Do NOT make any changes. End with: "Reply `go` to execute, or `/mode code` to take over manually."',
    );
  }
  if (scope && scope.length > 0) {
    lines.push(
      '',
      '== Files in explicit scope ==',
      'The user has added these files to the chat. Treat them as the canonical surface for this turn:',
      ...scope.map((p) => `  - ${p}`),
      'You may still read outside this list when necessary, but prefer these for edits and primary reasoning.',
    );
  }
  return lines.join('\n');
}

// Multi-line preview of a tool call for the permission prompt. Plandex-style:
// for write_file/edit_file we render a unified diff against the file on disk
// so the user sees what's actually changing before they hit `y`. Tokens like
// `+`/`-` are deliberately ASCII so the REPL can colorize them.
//
// Each line is prefixed with two spaces (the REPL indents the whole block).
// Diff body is capped at MAX_DIFF_LINES so a wholesale rewrite doesn't
// explode the prompt — we trail off with "…(N more lines)".
const MAX_DIFF_LINES = 40;

function summarizeToolInput(name: string, input: Record<string, unknown>): string {
  if (name === 'write_file') {
    const rel = String(input.path ?? '');
    const newBody = String(input.content ?? '');
    const oldBody = readIfExists(rel);
    const header = oldBody === null
      ? `write_file(${rel})   NEW FILE, ${newBody.length} bytes`
      : `write_file(${rel})   ${oldBody.length} → ${newBody.length} bytes`;
    const body = oldBody === null
      ? previewNewFile(newBody)
      : unifiedDiff(oldBody, newBody);
    return body ? `${header}\n${body}` : header;
  }
  if (name === 'edit_file') {
    const rel = String(input.path ?? '');
    const find = String(input.find ?? '');
    const replace = String(input.replace ?? '');
    const header = `edit_file(${rel})   −${find.length} / +${replace.length} bytes`;
    // Show the find/replace blocks themselves as a mini diff — useful even
    // before we resolve where they land in the file.
    const body = miniReplaceDiff(find, replace);
    return body ? `${header}\n${body}` : header;
  }
  if (name === 'run_command') {
    const cmd = String(input.command ?? '');
    return `run_command\n  $ ${cmd}`;
  }
  return `${name}(${Object.keys(input).slice(0, 2).join(', ')})`;
}

function readIfExists(rel: string): string | null {
  try {
    const abs = path.resolve(repoRoot(), rel);
    return readFileSync(abs, 'utf8');
  } catch {
    return null;
  }
}

function previewNewFile(body: string): string {
  const lines = body.split('\n');
  const head = lines.slice(0, MAX_DIFF_LINES).map((l) => `  +${l}`);
  if (lines.length > MAX_DIFF_LINES) head.push(`  …(${lines.length - MAX_DIFF_LINES} more lines)`);
  return head.join('\n');
}

function miniReplaceDiff(find: string, replace: string): string {
  const out: string[] = [];
  for (const l of find.split('\n')) out.push(`  -${l}`);
  for (const l of replace.split('\n')) out.push(`  +${l}`);
  if (out.length > MAX_DIFF_LINES) {
    const head = out.slice(0, MAX_DIFF_LINES);
    head.push(`  …(${out.length - MAX_DIFF_LINES} more lines)`);
    return head.join('\n');
  }
  return out.join('\n');
}

/**
 * Unified diff over lines. Uses LCS dynamic programming — quadratic in line
 * count, fine for typical edits. Caps inputs at LCS_LINE_CAP to avoid pathological
 * cost on giant files; beyond the cap we fall back to a head/tail summary.
 */
const LCS_LINE_CAP = 800;

function unifiedDiff(oldBody: string, newBody: string): string {
  if (oldBody === newBody) return '  (no change)';
  const a = oldBody.split('\n');
  const b = newBody.split('\n');
  if (a.length > LCS_LINE_CAP || b.length > LCS_LINE_CAP) {
    return `  (file too large for inline diff — ${a.length} → ${b.length} lines)`;
  }
  // LCS table.
  const m = a.length, n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      dp[i]![j] = a[i] === b[j] ? dp[i + 1]![j + 1]! + 1 : Math.max(dp[i + 1]![j]!, dp[i]![j + 1]!);
    }
  }
  // Walk back to produce hunks.
  const ops: Array<{ kind: ' ' | '-' | '+'; line: string }> = [];
  let i = 0, j = 0;
  while (i < m && j < n) {
    if (a[i] === b[j]) { ops.push({ kind: ' ', line: a[i]! }); i++; j++; }
    else if (dp[i + 1]![j]! >= dp[i]![j + 1]!) { ops.push({ kind: '-', line: a[i]! }); i++; }
    else { ops.push({ kind: '+', line: b[j]! }); j++; }
  }
  while (i < m) { ops.push({ kind: '-', line: a[i++]! }); }
  while (j < n) { ops.push({ kind: '+', line: b[j++]! }); }

  // Collapse runs of context to ±3 lines around changes (the standard
  // `diff -u` window). If we have nothing but context, return empty.
  const CONTEXT = 3;
  const keep: boolean[] = ops.map(() => false);
  for (let k = 0; k < ops.length; k++) {
    if (ops[k]!.kind !== ' ') {
      for (let z = Math.max(0, k - CONTEXT); z <= Math.min(ops.length - 1, k + CONTEXT); z++) {
        keep[z] = true;
      }
    }
  }
  const lines: string[] = [];
  let lastShown = -1;
  for (let k = 0; k < ops.length; k++) {
    if (!keep[k]) continue;
    if (lastShown !== -1 && k - lastShown > 1) lines.push('  ⋯');
    lines.push(`  ${ops[k]!.kind}${ops[k]!.line}`);
    lastShown = k;
    if (lines.length > MAX_DIFF_LINES) break;
  }
  if (lines.length > MAX_DIFF_LINES) {
    lines.length = MAX_DIFF_LINES;
    lines.push('  …(truncated)');
  }
  return lines.length ? lines.join('\n') : '  (whitespace-only change)';
}
