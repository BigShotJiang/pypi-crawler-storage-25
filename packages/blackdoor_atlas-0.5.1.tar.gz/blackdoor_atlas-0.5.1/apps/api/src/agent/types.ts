// Provider-agnostic agent types.
//
// The Provider interface normalizes the differences between Anthropic, any
// OpenAI-compatible endpoint (OpenAI, Mistral, Together, OpenRouter), and
// local servers (Ollama, LM Studio, vLLM — all speak the OpenAI-compatible
// wire). The runner only knows about these types; it never touches a
// vendor-specific SDK directly.

export interface ToolDef {
  name: string;
  description: string;
  // JSON Schema for the tool's input. We use a shape both Anthropic
  // (`input_schema`) and OpenAI (`function.parameters`) accept.
  input_schema: {
    type: 'object';
    properties: Record<string, unknown>;
    required?: string[];
    additionalProperties?: false;
  };
}

export type ChatMessage =
  | { role: 'user'; content: string }
  | { role: 'assistant'; content: AssistantBlock[] }
  | { role: 'tool'; tool_use_id: string; content: string; is_error?: boolean };

export type AssistantBlock =
  | { type: 'text'; text: string }
  | { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> };

// Events emitted by the runner. Every event is JSON-serializable so it can be
// wire-encoded as SSE without further marshalling. The web UI is the primary
// consumer; the harness CLI is a secondary consumer.
export type AgentEvent =
  | { type: 'started'; provider: string; model: string }
  | { type: 'text_delta'; text: string }
  | { type: 'thinking_delta'; text: string }
  | { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> }
  | { type: 'tool_result'; id: string; name: string; content: string; is_error: boolean }
  | { type: 'message_stop'; stop_reason: string }
  | { type: 'usage'; input_tokens?: number; output_tokens?: number; cache_read_input_tokens?: number; cache_creation_input_tokens?: number }
  // OpenClaude-style: emitted by the route every few seconds during a turn
  // so the REPL can render a live "thinking… 12s" counter without dead air.
  | { type: 'heartbeat'; idle_s: number; elapsed_s: number }
  // OpenClaude action_required: server has parked a sensitive tool call and
  // is awaiting a POST /api/agent/permission with the matching token. Until
  // that arrives (or the 2-min timer fires) the SSE stream stays open but
  // emits only heartbeats.
  | {
      type: 'permission_required';
      token: string;
      tool_use_id: string;
      tool: string;
      input: Record<string, unknown>;
      preview: string;       // short human-readable summary
    }
  | { type: 'error'; message: string }
  | { type: 'done' };

export interface ProviderRequest {
  system: string;
  tools: ToolDef[];
  messages: ChatMessage[];
  // Per-request hint. Providers that support adaptive thinking (Anthropic
  // 4.6+) honor this; others ignore it.
  thinking?: boolean;
  // 'low' | 'medium' | 'high' | 'xhigh' | 'max'. Anthropic Opus-tier honors
  // effort; other providers ignore it.
  effort?: 'low' | 'medium' | 'high' | 'xhigh' | 'max';
  // AbortSignal lets the route cancel the upstream when the client
  // disconnects.
  signal?: AbortSignal;
}

// One iteration of the agent loop produces this. The runner inspects
// `stop_reason` to decide whether to execute tools and loop again.
export interface ProviderIterationResult {
  assistant: AssistantBlock[];
  stop_reason: 'end_turn' | 'tool_use' | 'max_tokens' | 'refusal' | 'other';
  usage?: {
    input_tokens?: number;
    output_tokens?: number;
    cache_read_input_tokens?: number;
    cache_creation_input_tokens?: number;
  };
}

export interface Provider {
  readonly id: string;       // e.g. "anthropic", "openai-compatible", "ollama"
  readonly model: string;    // active model id

  // Stream one model turn. Yields incremental events; resolves with the
  // final assembled blocks + stop reason. The runner is responsible for
  // executing tools and calling again with the updated messages.
  iterate(
    req: ProviderRequest,
    onEvent: (e: AgentEvent) => void,
  ): Promise<ProviderIterationResult>;
}

export interface ProviderInfo {
  id: string;
  label: string;
  model: string;
  ready: boolean;       // true if env / config make this provider usable
  reason?: string;      // when not ready, the actionable hint
}
