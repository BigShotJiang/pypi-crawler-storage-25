// Mock provider for testing the agent loop without a real model.
//
// Activated by `AGENT_PROVIDER=mock`. Emits a deterministic, scripted
// sequence so end-to-end paths (SSE wire, runner, tool execution, multi-turn
// history replay) can be exercised in CI and on dev machines with no key.
//
// Behaviour: when it sees a user message whose last word is a path or
// filename, it calls `list_dir` or `read_file` to look at it, then replies
// with text describing what it found. Otherwise it just echoes.

import type {
  AgentEvent,
  ChatMessage,
  Provider,
  ProviderIterationResult,
  ProviderRequest,
} from '../types.js';

export class MockProvider implements Provider {
  readonly id = 'mock';
  readonly model = 'mock-1';

  async iterate(
    req: ProviderRequest,
    onEvent: (e: AgentEvent) => void,
  ): Promise<ProviderIterationResult> {
    const lastUser = [...req.messages].reverse().find((m) => m.role === 'user') as
      | { role: 'user'; content: string }
      | undefined;
    const lastToolResult = [...req.messages].reverse().find((m) => m.role === 'tool') as
      | { role: 'tool'; tool_use_id: string; content: string }
      | undefined;

    // If we already ran a tool this conversation, finish with a text turn
    // that summarizes the result.
    if (lastToolResult) {
      const summary = `Done. Tool output was:\n\n${lastToolResult.content.split('\n').slice(0, 5).join('\n')}…`;
      for (const ch of summary) {
        await sleep(2);
        onEvent({ type: 'text_delta', text: ch });
      }
      onEvent({ type: 'message_stop', stop_reason: 'end_turn' });
      return { assistant: [{ type: 'text', text: summary }], stop_reason: 'end_turn' };
    }

    if (!lastUser) {
      onEvent({ type: 'message_stop', stop_reason: 'end_turn' });
      return { assistant: [{ type: 'text', text: '(no user message)' }], stop_reason: 'end_turn' };
    }

    const target = pickPath(lastUser.content);
    const intro = target
      ? `I'll look at \`${target}\` first.`
      : 'Echo: ' + lastUser.content;
    for (const ch of intro) {
      await sleep(2);
      onEvent({ type: 'text_delta', text: ch });
    }

    if (!target) {
      onEvent({ type: 'message_stop', stop_reason: 'end_turn' });
      return { assistant: [{ type: 'text', text: intro }], stop_reason: 'end_turn' };
    }

    const toolName = target.endsWith('/') || !target.includes('.') ? 'list_dir' : 'read_file';
    const toolUseId = `mock_${Date.now()}`;
    const toolInput = { path: target.replace(/\/$/, '') };
    onEvent({ type: 'tool_use', id: toolUseId, name: toolName, input: toolInput });
    onEvent({ type: 'message_stop', stop_reason: 'tool_use' });

    return {
      assistant: [
        { type: 'text', text: intro },
        { type: 'tool_use', id: toolUseId, name: toolName, input: toolInput },
      ],
      stop_reason: 'tool_use',
    };
  }
}

function pickPath(text: string): string | null {
  // Find a candidate path: last whitespace-separated token that looks like
  // one (contains "/" or a known extension).
  const tokens = text.split(/\s+/).filter(Boolean);
  for (let i = tokens.length - 1; i >= 0; i--) {
    const t = tokens[i]!.replace(/[.,;:!?'"`]+$/g, '').replace(/^[`'"]+/, '');
    if (!t) continue;
    if (t.includes('/') || /\.(ts|tsx|js|md|json|yaml|yml|py|css)$/.test(t)) return t;
  }
  return null;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

// Re-export to keep TS module resolution happy when this file is imported only
// for its types from other providers.
export type _ChatMessage = ChatMessage;
