// Provider selection.
//
// Picks the active provider from env, but also reports which providers *would*
// be configurable so the UI can guide the user toward enabling them. We never
// pick a provider that can't successfully run a request — if nothing is
// configured, the agent route returns a structured "not configured" error
// with actionable next steps.

import type { Provider, ProviderInfo } from '../types.js';
import { AnthropicProvider, isConfigured as anthropicReady } from './anthropic.js';
import { ClaudeOAuthProvider, claudeOAuthStatus } from './claudeOAuth.js';
import { MockProvider } from './mock.js';
import {
  OpenAICompatibleProvider,
  detectKind as detectOpenAIKind,
  isConfigured as openAIReady,
} from './openaiCompatible.js';

export type ProviderId =
  | 'anthropic'
  | 'claude-oauth'
  | 'openai'
  | 'ollama'
  | 'openai-compatible'
  | 'mock';

export function listProviders(): ProviderInfo[] {
  const out: ProviderInfo[] = [];

  const oauth = claudeOAuthStatus();
  out.push({
    id: 'claude-oauth',
    label: 'Claude Code (subscription / Pro)',
    model: process.env.AGENT_MODEL ?? 'claude-opus-4-7',
    ready: oauth.ready,
    reason: oauth.reason,
  });

  out.push({
    id: 'anthropic',
    label: 'Anthropic (API key)',
    model: process.env.AGENT_MODEL ?? 'claude-opus-4-7',
    ready: anthropicReady(),
    reason: anthropicReady() ? undefined : 'Set ANTHROPIC_API_KEY in apps/api/.env.local',
  });

  const oaiKind = detectOpenAIKind();
  if (oaiKind === 'ollama') {
    out.push({
      id: 'ollama',
      label: 'Local (Ollama)',
      model: process.env.AGENT_MODEL ?? 'llama3.1',
      ready: openAIReady(),
      reason: openAIReady() ? undefined : 'Start Ollama and pull a model (e.g. `ollama pull llama3.1`).',
    });
  } else if (oaiKind === 'openai-compatible') {
    out.push({
      id: 'openai-compatible',
      label: 'OpenAI-compatible',
      model: process.env.AGENT_MODEL ?? 'gpt-4o-mini',
      ready: openAIReady(),
      reason: openAIReady() ? undefined : 'Set OPENAI_BASE_URL (and OPENAI_API_KEY if required).',
    });
  } else {
    out.push({
      id: 'openai',
      label: 'OpenAI (API key)',
      model: process.env.AGENT_MODEL ?? 'gpt-4o-mini',
      ready: openAIReady(),
      reason: openAIReady() ? undefined : 'Set OPENAI_API_KEY (or set OPENAI_BASE_URL=http://localhost:11434/v1 for Ollama).',
    });
  }

  if (process.env.AGENT_PROVIDER === 'mock' || process.env.NODE_ENV !== 'production') {
    out.push({
      id: 'mock',
      label: 'Mock (no model — scripted demo)',
      model: 'mock-1',
      ready: true,
      reason: 'Set AGENT_PROVIDER=mock to use without a real model. Useful for testing the UI.',
    });
  }

  return out;
}

export function selectProvider(): Provider | null {
  const explicit = (process.env.AGENT_PROVIDER ?? '').toLowerCase();
  if (explicit === 'mock') return new MockProvider();
  if (explicit === 'claude-oauth' && claudeOAuthStatus().ready) return new ClaudeOAuthProvider();
  if (explicit === 'anthropic' && anthropicReady()) return new AnthropicProvider();
  if ((explicit === 'openai' || explicit === 'openai-compatible' || explicit === 'ollama') && openAIReady()) {
    return new OpenAICompatibleProvider();
  }
  // Auto-pick priority:
  //   1. Claude Code OAuth (free for subscribers — picks itself up from the
  //      Keychain, no env vars needed)
  //   2. Anthropic API key (explicit setup; first-party)
  //   3. Any OpenAI-compatible (covers local Ollama too)
  if (claudeOAuthStatus().ready) return new ClaudeOAuthProvider();
  if (anthropicReady()) return new AnthropicProvider();
  if (openAIReady()) return new OpenAICompatibleProvider();
  return null;
}
