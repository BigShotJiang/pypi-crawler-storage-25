// OpenAI-compatible provider — speaks /v1/chat/completions with SSE
// streaming and tool calls. Works against:
//   - OpenAI         (OPENAI_BASE_URL unset, OPENAI_API_KEY required)
//   - Ollama         (OPENAI_BASE_URL=http://localhost:11434/v1, no key needed)
//   - LM Studio      (OPENAI_BASE_URL=http://localhost:1234/v1)
//   - vLLM           (whatever URL the server exposes)
//   - Mistral, Together, OpenRouter, Anyscale, Groq, Fireworks, ...
//
// No SDK — the wire is small enough that plain fetch + a line-based SSE
// parser is clearer and avoids dragging in a vendor SDK that may diverge.

import type {
  AgentEvent,
  AssistantBlock,
  Provider,
  ProviderIterationResult,
  ProviderRequest,
} from '../types.js';

interface OpenAITool {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: object;
  };
}

interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content?: string | null;
  name?: string;
  tool_call_id?: string;
  tool_calls?: Array<{ id: string; type: 'function'; function: { name: string; arguments: string } }>;
}

export function detectKind(): 'openai' | 'ollama' | 'openai-compatible' | 'none' {
  const base = (process.env.OPENAI_BASE_URL ?? '').toLowerCase();
  if (!base) {
    return process.env.OPENAI_API_KEY ? 'openai' : 'none';
  }
  if (base.includes('11434')) return 'ollama';
  if (base.includes('openai.com')) return 'openai';
  return 'openai-compatible';
}

export function isConfigured(): boolean {
  const kind = detectKind();
  // OpenAI itself requires a key. Local servers (Ollama, LM Studio) don't.
  if (kind === 'none') return false;
  if (kind === 'openai') return Boolean(process.env.OPENAI_API_KEY);
  return true;
}

const DEFAULT_MODEL_BY_KIND: Record<string, string> = {
  openai: 'gpt-4o-mini',
  ollama: 'llama3.1',
  'openai-compatible': 'gpt-4o-mini',
};

export class OpenAICompatibleProvider implements Provider {
  readonly id: string;
  readonly model: string;
  private baseUrl: string;
  private apiKey: string | undefined;

  constructor() {
    const kind = detectKind();
    this.id = kind === 'ollama' ? 'ollama' : kind === 'openai' ? 'openai' : 'openai-compatible';
    this.baseUrl = (process.env.OPENAI_BASE_URL ?? 'https://api.openai.com/v1').replace(/\/+$/, '');
    this.apiKey = process.env.OPENAI_API_KEY;
    this.model = process.env.AGENT_MODEL ?? DEFAULT_MODEL_BY_KIND[this.id] ?? 'gpt-4o-mini';
  }

  async iterate(
    req: ProviderRequest,
    onEvent: (e: AgentEvent) => void,
  ): Promise<ProviderIterationResult> {
    const tools: OpenAITool[] = req.tools.map((t) => ({
      type: 'function',
      function: {
        name: t.name,
        description: t.description,
        parameters: t.input_schema,
      },
    }));

    const messages: OpenAIMessage[] = [{ role: 'system', content: req.system }];
    for (const m of req.messages) {
      if (m.role === 'user') {
        messages.push({ role: 'user', content: m.content });
      } else if (m.role === 'tool') {
        messages.push({
          role: 'tool',
          tool_call_id: m.tool_use_id,
          content: m.content,
        });
      } else {
        // assistant: split text vs tool_use blocks
        const text = m.content.filter((b) => b.type === 'text').map((b) => (b as { text: string }).text).join('');
        const toolCalls = m.content
          .filter((b) => b.type === 'tool_use')
          .map((b) => {
            const t = b as { id: string; name: string; input: Record<string, unknown> };
            return { id: t.id, type: 'function' as const, function: { name: t.name, arguments: JSON.stringify(t.input ?? {}) } };
          });
        const out: OpenAIMessage = { role: 'assistant', content: text || null };
        if (toolCalls.length) out.tool_calls = toolCalls;
        messages.push(out);
      }
    }

    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (this.apiKey) headers.Authorization = `Bearer ${this.apiKey}`;

    const resp = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers,
      signal: req.signal,
      body: JSON.stringify({
        model: this.model,
        stream: true,
        messages,
        tools: tools.length ? tools : undefined,
        tool_choice: tools.length ? 'auto' : undefined,
      }),
    });

    if (!resp.ok || !resp.body) {
      const detail = await resp.text().catch(() => '');
      throw new Error(`${this.id} chat/completions failed (${resp.status}): ${detail.slice(0, 500)}`);
    }

    // Accumulate streamed deltas into a single assistant turn.
    let textBuf = '';
    const toolBuf = new Map<number, { id: string; name: string; arguments: string }>();
    let stop: ProviderIterationResult['stop_reason'] = 'other';

    const decoder = new TextDecoder();
    let pending = '';
    const reader = resp.body.getReader();
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      pending += decoder.decode(value, { stream: true });
      let sep: number;
      while ((sep = pending.indexOf('\n\n')) !== -1) {
        const frame = pending.slice(0, sep);
        pending = pending.slice(sep + 2);
        for (const line of frame.split('\n')) {
          if (!line.startsWith('data:')) continue;
          const data = line.slice(5).trim();
          if (!data || data === '[DONE]') continue;
          // Reasoning models (Qwen 3, DeepSeek, Ollama "thinking" wrappers)
          // stream chain-of-thought under `delta.reasoning` or
          // `delta.reasoning_content` rather than `delta.content`. Route it
          // through the same `thinking_delta` channel the Anthropic
          // provider uses.
          let evt: {
            choices?: Array<{
              delta?: {
                content?: string;
                reasoning?: string;
                reasoning_content?: string;
                tool_calls?: Array<{ index: number; id?: string; function?: { name?: string; arguments?: string } }>;
              };
              finish_reason?: string;
            }>;
          };
          try {
            evt = JSON.parse(data);
          } catch {
            continue;
          }
          const choice = evt.choices?.[0];
          if (!choice) continue;
          const delta = choice.delta ?? {};
          if (delta.content) {
            textBuf += delta.content;
            onEvent({ type: 'text_delta', text: delta.content });
          }
          const reasoning = delta.reasoning ?? delta.reasoning_content;
          if (reasoning) {
            onEvent({ type: 'thinking_delta', text: reasoning });
          }
          if (delta.tool_calls) {
            for (const tc of delta.tool_calls) {
              const existing = toolBuf.get(tc.index) ?? { id: '', name: '', arguments: '' };
              if (tc.id) existing.id = tc.id;
              if (tc.function?.name) existing.name = tc.function.name;
              if (tc.function?.arguments) existing.arguments += tc.function.arguments;
              toolBuf.set(tc.index, existing);
            }
          }
          if (choice.finish_reason) {
            stop = mapFinishReason(choice.finish_reason);
          }
        }
      }
    }

    const blocks: AssistantBlock[] = [];
    if (textBuf) blocks.push({ type: 'text', text: textBuf });
    for (const tc of toolBuf.values()) {
      if (!tc.name) continue;
      let input: Record<string, unknown> = {};
      try {
        input = tc.arguments ? JSON.parse(tc.arguments) : {};
      } catch {
        input = { _raw: tc.arguments };
      }
      blocks.push({ type: 'tool_use', id: tc.id || `call_${Math.random().toString(36).slice(2, 10)}`, name: tc.name, input });
      onEvent({ type: 'tool_use', id: tc.id, name: tc.name, input });
    }

    onEvent({ type: 'message_stop', stop_reason: stop });
    return { assistant: blocks, stop_reason: stop };
  }
}

function mapFinishReason(s: string): ProviderIterationResult['stop_reason'] {
  if (s === 'tool_calls') return 'tool_use';
  if (s === 'stop') return 'end_turn';
  if (s === 'length') return 'max_tokens';
  return 'other';
}
