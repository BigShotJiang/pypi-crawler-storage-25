// Anthropic provider — streams one model turn and yields normalized
// AgentEvents. Uses the official SDK with adaptive thinking + effort
// (Opus 4.7), prompt caching on the system prompt, and tool use.

import Anthropic from '@anthropic-ai/sdk';
import type {
  AgentEvent,
  AssistantBlock,
  ChatMessage,
  Provider,
  ProviderIterationResult,
  ProviderRequest,
} from '../types.js';

const DEFAULT_MODEL = 'claude-opus-4-7';
const MAX_TOKENS = 16000;

export function isConfigured(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

export class AnthropicProvider implements Provider {
  readonly id: string = 'anthropic';
  readonly model: string;
  protected client: Anthropic;

  constructor(
    model = process.env.AGENT_MODEL ?? DEFAULT_MODEL,
    client?: Anthropic,
  ) {
    this.client = client ?? new Anthropic();
    this.model = model;
  }

  async iterate(
    req: ProviderRequest,
    onEvent: (e: AgentEvent) => void,
  ): Promise<ProviderIterationResult> {
    const tools = req.tools.map((t) => ({
      name: t.name,
      description: t.description,
      input_schema: t.input_schema,
    }));

    // Build Anthropic-shaped messages from our normalized ChatMessage[].
    // Tool results are sent as a user message with `tool_result` content
    // blocks; consecutive tool results must be in the same user message.
    type AnthMsg = { role: 'user' | 'assistant'; content: unknown };
    const messages: AnthMsg[] = [];
    let pendingToolResults: unknown[] = [];
    const flushToolResults = () => {
      if (pendingToolResults.length) {
        messages.push({ role: 'user', content: pendingToolResults });
        pendingToolResults = [];
      }
    };

    for (const m of req.messages) {
      if (m.role === 'tool') {
        pendingToolResults.push({
          type: 'tool_result',
          tool_use_id: m.tool_use_id,
          content: m.content,
          is_error: m.is_error ?? false,
        });
      } else if (m.role === 'user') {
        flushToolResults();
        messages.push({ role: 'user', content: m.content });
      } else {
        flushToolResults();
        // Pass blocks through; Anthropic accepts our shape directly.
        messages.push({ role: 'assistant', content: m.content });
      }
    }
    flushToolResults();

    const params: Record<string, unknown> = {
      model: this.model,
      max_tokens: MAX_TOKENS,
      system: [
        {
          type: 'text',
          text: req.system,
          cache_control: { type: 'ephemeral' as const },
        },
      ],
      tools,
      messages,
    };

    // Adaptive thinking + effort are Opus 4.6+/4.7-only. Pass them only when
    // the user opted in and surface them as a `summarized` display so the
    // UI can show progress without a long silent pause.
    if (req.thinking) {
      params.thinking = { type: 'adaptive', display: 'summarized' };
    }
    if (req.effort) {
      params.output_config = { effort: req.effort };
    }

    const blocks: AssistantBlock[] = [];
    let toolUseId: string | null = null;
    let toolUseName: string | null = null;
    let toolUseJson = '';
    let stop: ProviderIterationResult['stop_reason'] = 'other';
    let usage: ProviderIterationResult['usage'] | undefined;

    const stream = (this.client as unknown as {
      messages: {
        stream: (
          p: typeof params,
          o?: { signal?: AbortSignal },
        ) => AsyncIterable<{ type: string; [k: string]: unknown }>;
      };
    }).messages.stream(params, { signal: req.signal });

    for await (const event of stream as AsyncIterable<{
      type: string;
      index?: number;
      content_block?: { type: string; id?: string; name?: string; text?: string };
      delta?: { type: string; text?: string; partial_json?: string; thinking?: string; stop_reason?: string };
      message?: { stop_reason?: string; usage?: Record<string, number> };
      usage?: Record<string, number>;
    }>) {
      switch (event.type) {
        case 'content_block_start': {
          const cb = event.content_block;
          if (cb?.type === 'text') {
            blocks.push({ type: 'text', text: '' });
          } else if (cb?.type === 'tool_use') {
            toolUseId = cb.id ?? '';
            toolUseName = cb.name ?? '';
            toolUseJson = '';
            blocks.push({ type: 'tool_use', id: toolUseId, name: toolUseName, input: {} });
          }
          break;
        }
        case 'content_block_delta': {
          const d = event.delta;
          if (!d) break;
          if (d.type === 'text_delta' && d.text) {
            const last = blocks[blocks.length - 1];
            if (last?.type === 'text') last.text += d.text;
            onEvent({ type: 'text_delta', text: d.text });
          } else if (d.type === 'thinking_delta' && d.thinking) {
            onEvent({ type: 'thinking_delta', text: d.thinking });
          } else if (d.type === 'input_json_delta' && d.partial_json) {
            toolUseJson += d.partial_json;
          }
          break;
        }
        case 'content_block_stop': {
          // If we just finished a tool_use block, parse the accumulated JSON
          // and emit the tool_use event so the UI can render the card before
          // the runner runs the tool.
          const last = blocks[blocks.length - 1];
          if (last?.type === 'tool_use' && toolUseId) {
            try {
              last.input = toolUseJson ? JSON.parse(toolUseJson) : {};
            } catch {
              last.input = {};
            }
            onEvent({ type: 'tool_use', id: last.id, name: last.name, input: last.input });
            toolUseId = null;
            toolUseName = null;
            toolUseJson = '';
          }
          break;
        }
        case 'message_delta': {
          const sr = event.delta?.stop_reason;
          if (sr) stop = normalizeStop(sr);
          if (event.usage) {
            usage = {
              ...(usage ?? {}),
              ...event.usage,
            };
          }
          break;
        }
        case 'message_stop': {
          if (event.message?.usage) {
            usage = { ...(usage ?? {}), ...event.message.usage };
          }
          break;
        }
        default:
          break;
      }
    }

    if (usage) onEvent({ type: 'usage', ...usage });
    onEvent({ type: 'message_stop', stop_reason: stop });
    return { assistant: blocks, stop_reason: stop, usage };
  }
}

function normalizeStop(s: string): ProviderIterationResult['stop_reason'] {
  switch (s) {
    case 'end_turn':
    case 'tool_use':
    case 'max_tokens':
    case 'refusal':
      return s;
    default:
      return 'other';
  }
}

// Reach into the union type without forcing a full ChatMessage import here.
// Kept inline because it's the only place we touch user-message blocks.
export type _msg = ChatMessage;
