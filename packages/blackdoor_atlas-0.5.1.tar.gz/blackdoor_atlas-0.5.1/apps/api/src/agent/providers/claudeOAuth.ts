// Claude Code OAuth provider — reuses the access token Claude Code already
// stored on the user's machine. No separate API key required.
//
// Storage:
//   macOS: Keychain entry service="Claude Code-credentials", account=$USER
//   Linux: ~/.claude/.credentials.json (when present; varies by distro)
//
// The credential JSON looks roughly like:
//   {"claudeAiOauth":{"accessToken":"sk-ant-oat01-...","refreshToken":"...","expiresAt":1234567890123,"scopes":["user:inference","..."],"subscriptionType":"max"}}
//
// We hand the access token to the Anthropic SDK as `authToken`, which sends
// it as `Authorization: Bearer ...` instead of `x-api-key`. Tokens expire
// (typically ~1h); we don't refresh in this iteration — on 401 we surface a
// "run `claude` to refresh" hint.

import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import Anthropic from '@anthropic-ai/sdk';
import { AnthropicProvider } from './anthropic.js';

interface ClaudeCreds {
  accessToken: string;
  refreshToken?: string;
  expiresAt?: number;
  source: 'keychain' | 'file';
}

const CACHED: { value: ClaudeCreds | null; readAt: number } = { value: null, readAt: 0 };
const CACHE_TTL_MS = 60_000;

export function readClaudeOAuth(): ClaudeCreds | null {
  if (CACHED.value && Date.now() - CACHED.readAt < CACHE_TTL_MS) return CACHED.value;

  // 1) macOS Keychain. `security find-generic-password -s "Claude Code-credentials" -w`
  //    triggers a one-time user prompt to "Always Allow" the binary; once
  //    approved, returns the secret on stdout.
  if (process.platform === 'darwin') {
    try {
      const raw = execFileSync(
        '/usr/bin/security',
        ['find-generic-password', '-s', 'Claude Code-credentials', '-w'],
        { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 5000 },
      ).trim();
      const parsed = parseCreds(raw);
      if (parsed) {
        CACHED.value = { ...parsed, source: 'keychain' };
        CACHED.readAt = Date.now();
        return CACHED.value;
      }
    } catch {
      // Keychain entry absent / user denied / `security` not on PATH — fall through.
    }
  }

  // 2) Plain file at ~/.claude/.credentials.json (Linux + manual setup).
  for (const candidate of [
    path.join(os.homedir(), '.claude', '.credentials.json'),
    path.join(os.homedir(), '.claude', 'credentials.json'),
  ]) {
    if (!existsSync(candidate)) continue;
    try {
      const parsed = parseCreds(readFileSync(candidate, 'utf8'));
      if (parsed) {
        CACHED.value = { ...parsed, source: 'file' };
        CACHED.readAt = Date.now();
        return CACHED.value;
      }
    } catch {
      // unreadable / malformed — keep looking
    }
  }

  CACHED.value = null;
  CACHED.readAt = Date.now();
  return null;
}

function parseCreds(raw: string): { accessToken: string; refreshToken?: string; expiresAt?: number } | null {
  try {
    const obj = JSON.parse(raw) as Record<string, unknown>;
    const block = (obj.claudeAiOauth ?? obj.ClaudeAiOauth ?? obj) as Record<string, unknown>;
    const accessToken = String(block.accessToken ?? block.access_token ?? '');
    if (!accessToken) return null;
    return {
      accessToken,
      refreshToken: (block.refreshToken ?? block.refresh_token) as string | undefined,
      expiresAt: (block.expiresAt ?? block.expires_at) as number | undefined,
    };
  } catch {
    return null;
  }
}

export function claudeOAuthStatus(): { ready: boolean; reason?: string } {
  if (process.platform !== 'darwin') {
    // We currently only auto-detect on macOS. The file fallback is supported,
    // but we don't actively probe Linux users.
    const creds = readClaudeOAuth();
    return creds
      ? { ready: true }
      : { ready: false, reason: 'No Claude Code credentials found. macOS Keychain auto-detect is currently the supported path.' };
  }
  const creds = readClaudeOAuth();
  if (!creds) {
    return {
      ready: false,
      reason: 'Run `claude` once to sign in (stores creds in macOS Keychain). First request will prompt to allow access.',
    };
  }
  if (creds.expiresAt && creds.expiresAt < Date.now()) {
    return {
      ready: false,
      reason: 'Claude Code token has expired. Run `claude` to refresh.',
    };
  }
  return { ready: true };
}

export class ClaudeOAuthProvider extends AnthropicProvider {
  // Re-uses AnthropicProvider's streaming + tool-use loop, but constructs the
  // SDK client with `authToken` (Bearer auth) instead of `apiKey`.
  override readonly id = 'claude-oauth';

  constructor() {
    const creds = readClaudeOAuth();
    if (!creds) throw new Error('Claude Code OAuth credentials not found');
    super(
      process.env.AGENT_MODEL ?? 'claude-opus-4-7',
      new Anthropic({
        authToken: creds.accessToken,
        defaultHeaders: {
          // Claude Code identifies itself this way; some routes 403 without it.
          'anthropic-beta': 'oauth-2025-04-20',
        },
      }),
    );
  }
}
