// Build the agent's system prompt from the repo contract.
//
// The blueprint says the agent reads layered instructions from CLAUDE.md and
// agent/*.md. We assemble those at startup (and cache the result so the
// upstream prompt cache hits — Anthropic only).
//
// IMPORTANT: keep this assembly deterministic. The system prompt is part of
// the cache prefix; reordering files or interpolating timestamps invalidates
// the cache for every subsequent request.

import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { repoMap } from './repoMap.js';

const REPO_ROOT = path.resolve(process.cwd(), '..', '..');

const ORDERED_CONTRACT_FILES = [
  'CLAUDE.md',
  'agent/system-overview.md',
  'agent/build-rules.md',
  'agent/product-spec.md',
  'agent/architecture.md',
  'agent/memory/known-good-patterns.md',
];

// Cache key includes a snapshot of memory + user. Captured at the start of
// every request via loadSystemPrompt() — within a single request the prompt
// is frozen, but across requests it can change. That's the Hermes pattern:
// memory writes persist immediately, but the *visible* memory in the system
// prompt for the current turn is the snapshot we captured at turn start.
const promptCache = new Map<string, string>();

export function repoRoot(): string {
  return REPO_ROOT;
}

export interface SystemPromptInputs {
  memory?: string;
  user?: string;
}

export function loadSystemPrompt(extras: SystemPromptInputs = {}): string {
  const memSig = (extras.memory ?? '').length + ':' + ((extras.user ?? '').length);
  const cached = promptCache.get(memSig);
  if (cached !== undefined) return cached;

  const parts: string[] = [
    'You are an autonomous build agent embedded in the user\'s local repository.',
    'You operate inside the repo described below. Use the provided tools to read,',
    'search, edit, and execute code in this repo. Prefer narrow, minimal changes.',
    '',
    'Operating rules:',
    '- Read before you write. List directories and read files before editing.',
    '- For any non-trivial change, sketch the plan in 1–3 sentences first.',
    '- Run tests / lint / typecheck after edits when relevant.',
    '- Never invent file paths or credentials. If unsure, list_dir or search first.',
    '- Keep responses concise; let tool calls do the work.',
    '- Use the `memory` tool sparingly — only when you learn a *durable* fact',
    '  about this repo, the user\'s preferences, or environment. Avoid logging',
    '  per-turn state. Entries will appear in your system prompt next session.',
    '',
    `Repo root: ${REPO_ROOT}`,
    '',
    '## Repo contract',
    '',
  ];
  for (const rel of ORDERED_CONTRACT_FILES) {
    const abs = path.join(REPO_ROOT, rel);
    if (!existsSync(abs)) continue;
    const body = readFileSync(abs, 'utf8');
    parts.push(`### ${rel}`, '', body.trim(), '');
  }
  // Aider-style repo map. Tells the model what's in the codebase without
  // needing a list_dir + grep loop. Inserted between contract and memory
  // because it's stable across turns (cached 30s, invalidated on edits).
  try {
    const map = repoMap();
    if (map.trim()) {
      parts.push('', '## Repo map', '', '```', map, '```', '');
    }
  } catch { /* don't let a malformed file kill the prompt */ }

  // Append memory + user profile at the END so the more-stable repo contract
  // + repo map sit earlier in the prefix (better for prefix caching).
  if (extras.memory && extras.memory.trim()) {
    parts.push('', '## Agent memory (writable via `memory` tool)', '', extras.memory.trim(), '');
  }
  if (extras.user && extras.user.trim()) {
    parts.push('', '## User profile (writable via `memory` tool, target=user)', '', extras.user.trim(), '');
  }
  const out = parts.join('\n');
  promptCache.set(memSig, out);
  return out;
}
