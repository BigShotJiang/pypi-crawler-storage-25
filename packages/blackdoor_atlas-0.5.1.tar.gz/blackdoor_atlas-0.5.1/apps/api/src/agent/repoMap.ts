// Aider-style repo map. Walks the workspace, extracts a compact symbol
// list per source file (exports, top-level functions, classes, types), and
// emits a tree the agent can read instead of repeatedly list_dir'ing the
// same directories.
//
// Reference: aider's repo map is the canonical version — it uses tree-sitter
// for symbol extraction. We do something cruder (line-prefix regexes) which
// is good enough for TS/TSX/JS/Python in a workspace of this size and adds
// zero new runtime deps.
//
// Token budget: we cap each file's symbol list at ~10 entries and the whole
// tree at ~1500 tokens of content. The map is cached for 30s — long enough
// to not re-scan on every turn, short enough that recent edits show up.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { repoRoot } from './system.js';

export interface FileEntry {
  rel: string;
  symbols: string[];
}

export interface RepoMapData {
  generated_at: string;
  total_files: number;
  groups: Array<{ top: string; files: FileEntry[] }>;
}

// Lazy — system.ts and repoMap.ts have a circular import at module-init time
// (system imports repoMap to compose the prompt; repoMap wants repoRoot from
// system). Resolving inside the function defers it past both module loads.
const ROOT = (): string => repoRoot();
const CACHE_TTL_MS = 30_000;
const MAX_SYMBOLS_PER_FILE = 10;
const TOKEN_BUDGET_APPROX_CHARS = 6000; // ~1500 tokens of English

const SKIP_DIRS = new Set([
  'node_modules', '.git', '.venv', '.agent', 'dist', 'build', '.vite',
  '.next', '__pycache__', 'coverage', '.turbo', '.cache',
]);

const SKIP_FILE_SUFFIXES = ['.tsbuildinfo', '.log', '.lock', '.map', '.min.js'];

interface Cache {
  body: string;
  at: number;
}
let cache: Cache | null = null;

export function repoMap(): string {
  const now = Date.now();
  if (cache && now - cache.at < CACHE_TTL_MS) return cache.body;
  const entries: FileEntry[] = [];
  walk(ROOT(), '', entries);
  const body = format(entries);
  cache = { body, at: now };
  return body;
}

/** Force a refresh — useful when the agent has just edited a file. */
export function invalidateRepoMap(): void {
  cache = null;
}

/** Structured form for the "Code Map" UI tab. Groups files by top-level
 *  directory (apps, harness, agent, references, …) so the tree reads at a
 *  glance. Skips the same noise the prompt form skips. */
export function repoMapData(): RepoMapData {
  const entries: FileEntry[] = [];
  walk(ROOT(), '', entries);
  const groups = new Map<string, FileEntry[]>();
  for (const e of entries) {
    const top = e.rel.split('/')[0] ?? '.';
    const g = groups.get(top) ?? [];
    g.push(e);
    groups.set(top, g);
  }
  const ordered = Array.from(groups.entries()).sort(([a], [b]) => {
    const rank = (k: string) => (k === 'apps' || k === 'harness' || k === 'src' ? 0 : k === 'tests' ? 2 : 1);
    return rank(a) - rank(b) || a.localeCompare(b);
  });
  return {
    generated_at: new Date().toISOString(),
    total_files: entries.length,
    groups: ordered.map(([top, files]) => ({ top, files })),
  };
}

function walk(absDir: string, relDir: string, out: FileEntry[]): void {
  let names: string[];
  try {
    names = readdirSync(absDir);
  } catch {
    return;
  }
  for (const name of names.sort()) {
    if (name.startsWith('.') && name !== '.gitignore') continue;
    if (SKIP_DIRS.has(name)) continue;
    const abs = path.join(absDir, name);
    let st;
    try { st = statSync(abs); } catch { continue; }
    const rel = relDir ? `${relDir}/${name}` : name;
    if (st.isDirectory()) {
      walk(abs, rel, out);
      continue;
    }
    if (!st.isFile()) continue;
    if (SKIP_FILE_SUFFIXES.some((s) => name.endsWith(s))) continue;
    if (st.size > 500_000) continue;

    const ext = name.split('.').pop() ?? '';
    if (!['ts', 'tsx', 'js', 'jsx', 'py', 'mjs', 'cjs'].includes(ext)) continue;

    const symbols = extractSymbols(abs, ext);
    if (symbols.length > 0) out.push({ rel, symbols });
  }
}

const TS_REGEXES: RegExp[] = [
  /^export\s+(?:async\s+)?function\s+([A-Za-z_][\w]*)/,
  /^export\s+class\s+([A-Za-z_][\w]*)/,
  /^export\s+interface\s+([A-Za-z_][\w]*)/,
  /^export\s+type\s+([A-Za-z_][\w]*)/,
  /^export\s+const\s+([A-Za-z_][\w]*)\s*[:=]/,
  /^export\s+default\s+(?:function|class)\s+([A-Za-z_][\w]*)/,
  /^(?:async\s+)?function\s+([A-Za-z_][\w]*)/,
  /^class\s+([A-Za-z_][\w]*)/,
];

const PY_REGEXES: RegExp[] = [
  /^class\s+([A-Za-z_][\w]*)/,
  /^def\s+([A-Za-z_][\w]*)/,
  /^async\s+def\s+([A-Za-z_][\w]*)/,
];

function extractSymbols(abs: string, ext: string): string[] {
  let body: string;
  try {
    body = readFileSync(abs, 'utf8');
  } catch {
    return [];
  }
  const regexes = ext === 'py' ? PY_REGEXES : TS_REGEXES;
  const out: string[] = [];
  const seen = new Set<string>();
  for (const line of body.split('\n')) {
    if (out.length >= MAX_SYMBOLS_PER_FILE) break;
    const trimmed = line.replace(/^\s+/, '');
    if (trimmed.length > 200) continue;
    for (const re of regexes) {
      const m = re.exec(trimmed);
      if (m && m[1] && !seen.has(m[1])) {
        seen.add(m[1]);
        // Tag with a one-char kind: f=function, c=class, t=type/interface, x=const, d=def
        let kind = 'f';
        if (/^class\s/.test(trimmed) || /^export\s+class/.test(trimmed)) kind = 'c';
        else if (/^export\s+(interface|type)/.test(trimmed)) kind = 't';
        else if (/^export\s+const/.test(trimmed)) kind = 'x';
        else if (/^def\s/.test(trimmed) || /^async\s+def\s/.test(trimmed)) kind = 'd';
        out.push(`${kind} ${m[1]}`);
        break;
      }
    }
  }
  return out;
}

function format(entries: FileEntry[]): string {
  // Group by top-level directory so the tree reads at a glance.
  const groups = new Map<string, FileEntry[]>();
  for (const e of entries) {
    const top = e.rel.split('/')[0] ?? '.';
    const g = groups.get(top) ?? [];
    g.push(e);
    groups.set(top, g);
  }

  const lines: string[] = [];
  const groupOrder = Array.from(groups.keys()).sort((a, b) => {
    // Project source dirs first, then tests, then everything else.
    const rank = (k: string) => (k === 'apps' || k === 'harness' || k === 'src' ? 0 : k === 'tests' ? 2 : 1);
    return rank(a) - rank(b) || a.localeCompare(b);
  });

  let charCount = 0;
  for (const top of groupOrder) {
    const section: string[] = [`├─ ${top}/`];
    for (const e of (groups.get(top) ?? [])) {
      section.push(`│  ${e.rel}: ${e.symbols.join(', ')}`);
    }
    const sectionStr = section.join('\n');
    if (charCount + sectionStr.length > TOKEN_BUDGET_APPROX_CHARS) {
      lines.push(`(${entries.length - lines.filter((l) => l.includes(':')).length} more files truncated for budget)`);
      break;
    }
    lines.push(sectionStr);
    charCount += sectionStr.length;
  }

  return lines.join('\n');
}
