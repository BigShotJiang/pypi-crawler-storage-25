import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import http from 'node:http';
import { createServer } from './server.js';

async function start(): Promise<{ url: string; close: () => Promise<void> }> {
  const app = createServer();
  return new Promise((resolve) => {
    const server = http.createServer(app);
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      if (addr === null || typeof addr === 'string') throw new Error('bad address');
      resolve({
        url: `http://127.0.0.1:${addr.port}`,
        close: () =>
          new Promise<void>((res, rej) => server.close((err) => (err ? rej(err) : res()))),
      });
    });
  });
}

describe('healthz', () => {
  let handle: Awaited<ReturnType<typeof start>>;
  beforeAll(async () => {
    handle = await start();
  });
  afterEach(() => {});
  it('responds with ok=true', async () => {
    const res = await fetch(`${handle.url}/healthz`);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { ok: boolean };
    expect(body.ok).toBe(true);
    await handle.close();
  });
});
