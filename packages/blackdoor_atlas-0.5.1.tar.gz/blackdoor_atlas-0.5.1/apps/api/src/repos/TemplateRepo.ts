// Project-scoped issue templates. A template seeds a quick-create with a
// pre-filled title / body / priority / estimate.

import { db } from '../db.js';
import type { Template, TaskPriority } from '../domain/types.js';

const COLS = `id, project_id, name, title, body, priority, estimate, created_at`;

export interface TemplateInput {
  name: string;
  title: string;
  body?: string;
  priority?: TaskPriority;
  estimate?: number | null;
}

export class TemplateRepo {
  static listForProject(projectId: number): Template[] {
    return db
      .prepare(`SELECT ${COLS} FROM templates WHERE project_id = ? ORDER BY id`)
      .all(projectId) as Template[];
  }

  static create(projectId: number, input: TemplateInput): Template {
    const info = db
      .prepare(`INSERT INTO templates (project_id, name, title, body, priority, estimate) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(projectId, input.name, input.title, input.body ?? '', input.priority ?? 'med', input.estimate ?? null);
    return db.prepare(`SELECT ${COLS} FROM templates WHERE id = ?`).get(Number(info.lastInsertRowid)) as Template;
  }

  static delete(projectId: number, templateId: number): boolean {
    const info = db.prepare(`DELETE FROM templates WHERE id = ? AND project_id = ?`).run(templateId, projectId);
    return info.changes > 0;
  }
}
