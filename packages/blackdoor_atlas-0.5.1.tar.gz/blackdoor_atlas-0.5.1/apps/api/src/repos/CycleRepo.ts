// Cycles (sprints): time-boxed iterations attached to a project. The repo
// also owns the small status state machine (upcoming / active / completed).

import { db } from '../db.js';
import type { Cycle, CycleStatus, CycleWithCounts } from '../domain/types.js';

const CYCLE_COLS = `id, project_id, number, name, start_date, end_date, status, created_at`;

export class CycleRepo {
  /** Compute and persist the status given today's date vs start/end. */
  static recomputeStatus(cycleId: number): void {
    const today = new Date().toISOString().slice(0, 10);
    const row = db
      .prepare(`SELECT start_date, end_date FROM cycles WHERE id = ?`)
      .get(cycleId) as { start_date: string; end_date: string } | undefined;
    if (!row) return;
    const status: CycleStatus = row.end_date < today ? 'completed' : row.start_date > today ? 'upcoming' : 'active';
    db.prepare(`UPDATE cycles SET status = ? WHERE id = ?`).run(status, cycleId);
  }

  static listForProject(projectId: number): CycleWithCounts[] {
    // Refresh statuses so "active" is accurate at read time.
    const ids = db.prepare(`SELECT id FROM cycles WHERE project_id = ?`).all(projectId) as Array<{ id: number }>;
    for (const r of ids) CycleRepo.recomputeStatus(r.id);
    return db
      .prepare(
        `SELECT ${CYCLE_COLS},
                (SELECT COUNT(*) FROM tasks t WHERE t.cycle_id = c.id) AS task_count,
                (SELECT COUNT(*) FROM tasks t WHERE t.cycle_id = c.id AND t.status = 'done') AS done_count
           FROM cycles c WHERE project_id = ?
          ORDER BY start_date DESC`,
      )
      .all(projectId) as CycleWithCounts[];
  }

  static create(projectId: number, input: { name?: string; start_date: string; end_date: string }): Cycle {
    const numberRow = db
      .prepare(`SELECT COALESCE(MAX(number), 0) AS n FROM cycles WHERE project_id = ?`)
      .get(projectId) as { n: number };
    const info = db
      .prepare(`INSERT INTO cycles (project_id, number, name, start_date, end_date) VALUES (?, ?, ?, ?, ?)`)
      .run(projectId, numberRow.n + 1, input.name ?? '', input.start_date, input.end_date);
    const id = Number(info.lastInsertRowid);
    CycleRepo.recomputeStatus(id);
    return db.prepare(`SELECT ${CYCLE_COLS} FROM cycles WHERE id = ?`).get(id) as Cycle;
  }

  static delete(projectId: number, cycleId: number): boolean {
    const info = db.prepare(`DELETE FROM cycles WHERE id = ? AND project_id = ?`).run(cycleId, projectId);
    return info.changes > 0;
  }

  static belongsToProject(cycleId: number, projectId: number): boolean {
    return Boolean(db.prepare(`SELECT id FROM cycles WHERE id = ? AND project_id = ?`).get(cycleId, projectId));
  }
}
