// SeedRepo — populates a fresh account with a realistic Linear-style
// demo workspace so the user lands on something interesting on first
// login instead of an empty inbox. Idempotent at the user level: only
// seeds when the user has zero projects.
//
// The data is deliberately Linear-flavored: two projects (one product,
// one ops), real cycles, a label taxonomy, mixed statuses & priorities,
// a parent issue with sub-issues, a small backlog of cancelled/done
// items to show that the columns work. Calibrated to ~25 issues total
// so the board, list view, and Insights tab all read as populated.

import { db } from '../db.js';
import { CompanyRepo } from './CompanyRepo.js';
import { ProjectRepo } from './ProjectRepo.js';
import { TaskRepo } from './TaskRepo.js';
import { CycleRepo } from './CycleRepo.js';
import type { TaskPriority, TaskStatus } from '../domain/types.js';

interface SeedSpec {
  name: string;
  description: string;
  color: string;
  labels: Array<{ name: string; color: string }>;
  cycles: Array<{ name: string; daysFromNow: number; lengthDays: number; status?: 'active' | 'upcoming' | 'completed' }>;
  issues: SeedIssue[];
}

interface SeedIssue {
  title: string;
  body?: string;
  status: TaskStatus;
  priority: TaskPriority;
  estimate?: number | null;
  assignee?: string;
  labels?: string[];      // matched by name to labels[]
  cycleIndex?: number;    // index into cycles[]; omit for no cycle
  children?: Array<Omit<SeedIssue, 'children'>>;
}

function addDays(d: Date, days: number): string {
  const out = new Date(d.getTime() + days * 86_400_000);
  return out.toISOString().slice(0, 10);
}

const TEAMMATES = ['drew', 'mira', 'ivan', 'sasha'];

const SPECS: SeedSpec[] = [
  {
    name: 'Launchpad',
    description: 'Public beta. Polish the onboarding, lock down billing, ship the v1 marketing site.',
    color: '#5e6ad2',
    labels: [
      { name: 'bug', color: '#ef4444' },
      { name: 'feature', color: '#3b82f6' },
      { name: 'design', color: '#a855f7' },
      { name: 'infra', color: '#10b981' },
      { name: 'docs', color: '#f59e0b' },
    ],
    cycles: [
      { name: 'Polish', daysFromNow: -3, lengthDays: 14, status: 'active' },
      { name: 'Beta', daysFromNow: 11, lengthDays: 14, status: 'upcoming' },
    ],
    issues: [
      {
        title: 'Onboarding empty-state lands on a useful page',
        status: 'started', priority: 'high', estimate: 3,
        assignee: 'me', labels: ['feature', 'design'], cycleIndex: 0,
        body: 'A brand-new account currently lands on an empty Inbox. Seed a demo workspace or take them straight into the first project.',
      },
      {
        title: 'Billing portal: handle expired card retries',
        status: 'todo', priority: 'urgent', estimate: 5,
        assignee: 'drew', labels: ['bug', 'feature'], cycleIndex: 0,
      },
      {
        title: 'Drag a card across columns updates status optimistically',
        status: 'review', priority: 'med', estimate: 2,
        assignee: 'mira', labels: ['feature'], cycleIndex: 0,
      },
      {
        title: 'Refactor TaskRow to share a row primitive with Inbox',
        status: 'started', priority: 'low', estimate: 2,
        assignee: 'me', labels: ['design'], cycleIndex: 0,
      },
      {
        title: 'Inline edit titles with `e` (Linear parity)',
        status: 'backlog', priority: 'med', estimate: 2,
        labels: ['feature'], cycleIndex: 1,
      },
      {
        title: 'Cycle picker: rotate through cycles with Shift+C',
        status: 'done', priority: 'med', estimate: 1,
        assignee: 'me', labels: ['feature'],
      },
      {
        title: 'Comment threads: load reactions in the same query',
        status: 'todo', priority: 'low', estimate: 3,
        assignee: 'sasha', labels: ['infra'], cycleIndex: 1,
      },
      {
        title: 'Migration runner: idempotent column adds with PRAGMA introspection',
        status: 'done', priority: 'high', estimate: 5,
        assignee: 'ivan', labels: ['infra'],
      },
      {
        title: 'Hero portrait is too dark on the marketing site',
        status: 'cancelled', priority: 'low',
        assignee: 'drew', labels: ['design', 'bug'],
        body: 'Decided not to ship the hero shot at launch. Closing.',
      },
      {
        title: 'Sub-issue support on the issue drawer',
        status: 'started', priority: 'high', estimate: 5,
        assignee: 'mira', labels: ['feature'], cycleIndex: 0,
        children: [
          { title: 'Schema: tasks.parent_id with ON DELETE CASCADE', status: 'done', priority: 'med', estimate: 1, assignee: 'ivan', labels: ['infra'] },
          { title: 'Render sub-issue list with progress', status: 'review', priority: 'med', estimate: 2, assignee: 'mira', labels: ['feature'] },
          { title: 'Hotkey to add a sub-issue from the parent', status: 'todo', priority: 'low', estimate: 1, labels: ['feature'] },
        ],
      },
      {
        title: 'SSO: error states for invalid SAML cert',
        status: 'backlog', priority: 'med', estimate: 3,
        labels: ['feature', 'infra'],
      },
      {
        title: 'Docs: update CLAUDE.md with the bring-your-own-model table',
        status: 'todo', priority: 'med', estimate: 1,
        assignee: 'me', labels: ['docs'], cycleIndex: 0,
      },
      {
        title: 'Search across saved views and templates',
        status: 'backlog', priority: 'low', estimate: 3,
        labels: ['feature'],
      },
    ],
  },
  {
    name: 'Internal',
    description: 'Ops, on-call, and quality of life for the team.',
    color: '#22c55e',
    labels: [
      { name: 'oncall', color: '#dc2626' },
      { name: 'tooling', color: '#0ea5e9' },
      { name: 'meeting', color: '#a3a3a3' },
    ],
    cycles: [
      { name: 'Q2 ops', daysFromNow: -7, lengthDays: 28, status: 'active' },
    ],
    issues: [
      {
        title: 'Rotate Anthropic API key (90-day cadence)',
        status: 'todo', priority: 'high', estimate: 1,
        assignee: 'me', labels: ['oncall'], cycleIndex: 0,
      },
      {
        title: 'Weekly bug triage — Wednesdays 10am',
        status: 'started', priority: 'med',
        assignee: 'drew', labels: ['meeting'], cycleIndex: 0,
      },
      {
        title: 'Bring up a staging clone of the prod DB',
        status: 'backlog', priority: 'med', estimate: 5,
        labels: ['tooling'],
      },
      {
        title: 'Postmortem: 03-29 deploy outage',
        status: 'done', priority: 'urgent', estimate: 3,
        assignee: 'ivan', labels: ['oncall'],
      },
      {
        title: 'Add Slack notification on long-running tasks',
        status: 'review', priority: 'low', estimate: 2,
        assignee: 'sasha', labels: ['tooling'], cycleIndex: 0,
      },
    ],
  },
];

export class SeedRepo {
  /** Provision workspaces + demo data for users who don't have any yet.
   *  Idempotent: returns true the first time it actually creates state. */
  static seedIfEmpty(userId: number): boolean {
    const hasCompanies = db
      .prepare(
        `SELECT COUNT(*) AS n FROM company_members WHERE user_id = ?`,
      )
      .get(userId) as { n: number };
    if (hasCompanies.n > 0) return false;
    SeedRepo.runSeed(userId);
    return true;
  }

  /** Force-seed without the empty check; useful for tests / manual reset.
   *  Creates two workspaces — a clean "Personal" and a populated "Demo Co"
   *  — and points the user's active_company_id at Demo Co so the first
   *  view of the app is full of realistic data. */
  static runSeed(userId: number): void {
    const tx = db.transaction(() => {
      // Always create a clean Personal workspace first — that's where the
      // user will eventually do real work. Empty by design.
      const personal = CompanyRepo.create({
        ownerId: userId,
        name: 'Personal',
        color: '#5e6ad2',
        description: 'Your private workspace.',
      });

      // Demo Co holds the dogfood projects (Launchpad + Internal). New users
      // land here so the board, hotkeys, cycles all read as populated.
      const demoCo = CompanyRepo.create({
        ownerId: userId,
        name: 'Demo Co',
        color: '#22c55e',
        description: 'Demo workspace — explore the board, hotkeys, cycles, and AI agent.',
      });
      CompanyRepo.setActiveForUser(userId, demoCo.id);

      const now = new Date();
      for (const spec of SPECS) {
        const project = ProjectRepo.create({
          userId,
          companyId: demoCo.id,
          name: spec.name,
          description: spec.description,
          color: spec.color,
        });
        void personal; // keep linter quiet; reserved for future per-workspace seeds
        const labels = new Map<string, number>();
        for (const l of spec.labels) {
          const created = ProjectRepo.createLabel(project.id, l.name, l.color);
          labels.set(l.name, created.id);
        }
        const cycles = spec.cycles.map((c, i) => {
          const start = addDays(now, c.daysFromNow);
          const end = addDays(now, c.daysFromNow + c.lengthDays);
          const cyc = CycleRepo.create(project.id, { name: c.name, start_date: start, end_date: end });
          // CycleRepo.create defaults to 'upcoming'; if the spec wants
          // active/completed we patch directly.
          if (c.status && c.status !== 'upcoming') {
            db.prepare(`UPDATE cycles SET status = ? WHERE id = ?`).run(c.status, cyc.id);
          }
          void i;
          return cyc;
        });

        const completedISO = (now.toISOString());
        for (const iss of spec.issues) {
          const cycleId = iss.cycleIndex !== undefined ? cycles[iss.cycleIndex]?.id ?? null : null;
          const task = TaskRepo.create({
            project_id: project.id,
            title: iss.title,
            body: iss.body ?? '',
            status: iss.status,
            priority: iss.priority,
            assignee: iss.assignee ?? '',
            estimate: iss.estimate ?? null,
            cycle_id: cycleId,
          });
          if (iss.status === 'done' || iss.status === 'cancelled') {
            TaskRepo.setCompletedAt(task.id, completedISO);
          }
          for (const lname of iss.labels ?? []) {
            const lid = labels.get(lname);
            if (lid) TaskRepo.attachLabel(task.id, lid);
          }
          for (const child of iss.children ?? []) {
            const childCycleId = cycleId; // children inherit the parent's cycle
            const ch = TaskRepo.create({
              project_id: project.id,
              title: child.title,
              body: child.body ?? '',
              status: child.status,
              priority: child.priority,
              assignee: child.assignee ?? '',
              estimate: child.estimate ?? null,
              parent_id: task.id,
              cycle_id: childCycleId,
            });
            if (child.status === 'done' || child.status === 'cancelled') {
              TaskRepo.setCompletedAt(ch.id, completedISO);
            }
            for (const lname of child.labels ?? []) {
              const lid = labels.get(lname);
              if (lid) TaskRepo.attachLabel(ch.id, lid);
            }
          }
        }
      }
      void TEAMMATES;
    });
    tx();
  }
}
