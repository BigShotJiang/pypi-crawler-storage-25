// User-scoped saved filters for a project page.

import { db } from '../db.js';
import type { SavedView } from '../domain/types.js';

interface Row {
  id: number;
  user_id: number;
  project_id: number | null;
  name: string;
  payload: string;
  created_at: string;
}

function hydrate(r: Row): SavedView {
  let payload: Record<string, unknown> = {};
  try { payload = JSON.parse(r.payload || '{}') as Record<string, unknown>; } catch { /* ignore */ }
  return { ...r, payload };
}

export class SavedViewRepo {
  static listFor(userId: number, projectId: number): SavedView[] {
    const rows = db
      .prepare(`SELECT id, user_id, project_id, name, payload, created_at FROM saved_views WHERE user_id = ? AND project_id = ? ORDER BY id DESC`)
      .all(userId, projectId) as Row[];
    return rows.map(hydrate);
  }

  static create(userId: number, projectId: number, name: string, payload: Record<string, unknown>): SavedView {
    const info = db
      .prepare(`INSERT INTO saved_views (user_id, project_id, name, payload) VALUES (?, ?, ?, ?)`)
      .run(userId, projectId, name, JSON.stringify(payload));
    const row = db
      .prepare(`SELECT id, user_id, project_id, name, payload, created_at FROM saved_views WHERE id = ?`)
      .get(Number(info.lastInsertRowid)) as Row;
    return hydrate(row);
  }

  static delete(userId: number, projectId: number, viewId: number): boolean {
    const info = db
      .prepare(`DELETE FROM saved_views WHERE id = ? AND user_id = ? AND project_id = ?`)
      .run(viewId, userId, projectId);
    return info.changes > 0;
  }
}
