// CompanyRepo — workspaces (Linear's "workspace" = our "company"). A user
// belongs to many companies via company_members; projects + cycles + labels
// live under a company. The user's active_company_id picks which workspace
// the sidebar shows.

import { db } from '../db.js';
import type { Company, CompanyRole, CompanyWithMeta } from '../domain/types.js';

const COMPANY_COLS = `id, name, key, color, description, created_at`;

export class CompanyRepo {
  // -- keys ---------------------------------------------------------------

  /** Three-letter slug, like Linear's workspace shortcut. */
  static deriveKey(name: string): string {
    const cleaned = name.replace(/[^A-Za-z]/g, '').toUpperCase();
    return (cleaned.slice(0, 3) || 'WRK').padEnd(3, 'X');
  }

  static uniqueKey(base: string): string {
    const rows = db.prepare(`SELECT key FROM companies`).all() as Array<{ key: string }>;
    const taken = new Set(rows.map((r) => r.key));
    if (!taken.has(base)) return base;
    for (let i = 2; i < 1000; i++) {
      const candidate = `${base}${i}`.slice(0, 4);
      if (!taken.has(candidate)) return candidate;
    }
    return base + Math.floor(Math.random() * 1000);
  }

  // -- CRUD ---------------------------------------------------------------

  static findById(id: number): Company | null {
    const row = db.prepare(`SELECT ${COMPANY_COLS} FROM companies WHERE id = ?`).get(id) as Company | undefined;
    return row ?? null;
  }

  /** All companies the user is a member of, with metadata. */
  static listForUser(userId: number, activeId: number | null): CompanyWithMeta[] {
    return db
      .prepare(
        `SELECT c.id, c.name, c.key, c.color, c.description, c.created_at,
                cm.role AS role,
                (SELECT COUNT(*) FROM company_members WHERE company_id = c.id) AS member_count,
                (SELECT COUNT(*) FROM projects WHERE company_id = c.id) AS project_count
           FROM companies c
           JOIN company_members cm ON cm.company_id = c.id
          WHERE cm.user_id = ?
          ORDER BY c.created_at ASC`,
      )
      .all(userId)
      .map((r) => {
        const row = r as Company & { role: CompanyRole; member_count: number; project_count: number };
        return { ...row, is_active: row.id === activeId };
      });
  }

  static create(input: { name: string; color?: string; description?: string; ownerId: number }): Company {
    const key = CompanyRepo.uniqueKey(CompanyRepo.deriveKey(input.name));
    const info = db
      .prepare(`INSERT INTO companies (name, key, color, description) VALUES (?, ?, ?, ?)`)
      .run(input.name.trim(), key, input.color ?? '#5e6ad2', input.description ?? '');
    const id = Number(info.lastInsertRowid);
    db.prepare(`INSERT INTO company_members (company_id, user_id, role) VALUES (?, ?, 'owner')`)
      .run(id, input.ownerId);
    return CompanyRepo.findById(id)!;
  }

  static update(id: number, patch: Partial<Pick<Company, 'name' | 'color' | 'description'>>): Company | null {
    const fields: string[] = [];
    const values: unknown[] = [];
    for (const k of ['name', 'color', 'description'] as const) {
      if (patch[k] !== undefined) { fields.push(`${k} = ?`); values.push(patch[k]); }
    }
    if (fields.length === 0) return CompanyRepo.findById(id);
    values.push(id);
    db.prepare(`UPDATE companies SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    return CompanyRepo.findById(id);
  }

  /** Delete a company. Cascades through ON DELETE CASCADE on projects /
   *  members. Refuses to delete if this would leave the user with zero
   *  workspaces — the caller should handle that case. */
  static delete(id: number): boolean {
    const info = db.prepare(`DELETE FROM companies WHERE id = ?`).run(id);
    return info.changes > 0;
  }

  // -- membership ---------------------------------------------------------

  static isMember(companyId: number, userId: number): boolean {
    const row = db
      .prepare(`SELECT 1 FROM company_members WHERE company_id = ? AND user_id = ?`)
      .get(companyId, userId);
    return !!row;
  }

  static roleOf(companyId: number, userId: number): CompanyRole | null {
    const row = db
      .prepare(`SELECT role FROM company_members WHERE company_id = ? AND user_id = ?`)
      .get(companyId, userId) as { role: CompanyRole } | undefined;
    return row?.role ?? null;
  }

  static addMember(companyId: number, userId: number, role: CompanyRole = 'member'): void {
    db.prepare(`INSERT OR IGNORE INTO company_members (company_id, user_id, role) VALUES (?, ?, ?)`)
      .run(companyId, userId, role);
  }

  static removeMember(companyId: number, userId: number): void {
    db.prepare(`DELETE FROM company_members WHERE company_id = ? AND user_id = ?`).run(companyId, userId);
  }

  // -- active workspace selection -----------------------------------------

  /** Update users.active_company_id. The caller MUST first verify membership. */
  static setActiveForUser(userId: number, companyId: number): void {
    db.prepare(`UPDATE users SET active_company_id = ? WHERE id = ?`).run(companyId, userId);
  }

  /** Read the user's active company; fall back to their first membership
   *  if the active id is null or no longer points at a valid workspace. */
  static resolveActiveForUser(userId: number): number | null {
    const row = db
      .prepare(
        `SELECT u.active_company_id AS a,
                (SELECT cm.company_id
                   FROM company_members cm
                  WHERE cm.user_id = u.id
                  ORDER BY cm.joined_at LIMIT 1) AS fallback
           FROM users u WHERE u.id = ?`,
      )
      .get(userId) as { a: number | null; fallback: number | null } | undefined;
    if (!row) return null;
    // Confirm the stored active is still a valid membership.
    if (row.a && CompanyRepo.isMember(row.a, userId)) return row.a;
    if (row.fallback) {
      CompanyRepo.setActiveForUser(userId, row.fallback);
      return row.fallback;
    }
    return null;
  }
}
