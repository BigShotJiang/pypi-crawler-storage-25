// User authentication and session storage. Wraps the `users` and `sessions`
// tables behind typed methods so routes never construct SQL directly.

import crypto from 'node:crypto';
import { db } from '../db.js';
import type { Session, User } from '../domain/types.js';

const SCRYPT_KEYLEN = 64;

export class UserRepo {
  // -- credentials --------------------------------------------------------

  static hashPassword(password: string): string {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(password, salt, SCRYPT_KEYLEN).toString('hex');
    return `${salt}:${hash}`;
  }

  static verifyPassword(password: string, stored: string): boolean {
    const [salt, expected] = stored.split(':');
    if (!salt || !expected) return false;
    const actual = crypto.scryptSync(password, salt, SCRYPT_KEYLEN).toString('hex');
    const a = Buffer.from(actual, 'hex');
    const b = Buffer.from(expected, 'hex');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }

  // -- CRUD ---------------------------------------------------------------

  static findByEmail(email: string): (User & { password_hash: string }) | null {
    const row = db
      .prepare(`SELECT id, email, password_hash, created_at, active_company_id FROM users WHERE email = ?`)
      .get(email) as (User & { password_hash: string }) | undefined;
    return row ?? null;
  }

  static findById(id: number): User | null {
    const row = db
      .prepare(`SELECT id, email, created_at, active_company_id FROM users WHERE id = ?`)
      .get(id) as User | undefined;
    return row ?? null;
  }

  static create(email: string, password: string): User {
    const info = db
      .prepare(`INSERT INTO users (email, password_hash) VALUES (?, ?)`)
      .run(email, UserRepo.hashPassword(password));
    return UserRepo.findById(Number(info.lastInsertRowid))!;
  }

  // -- sessions -----------------------------------------------------------

  static createSession(userId: number): string {
    const id = crypto.randomBytes(32).toString('hex');
    db.prepare(`INSERT INTO sessions (id, user_id) VALUES (?, ?)`).run(id, userId);
    return id;
  }

  static destroySession(sessionId: string): void {
    db.prepare(`DELETE FROM sessions WHERE id = ?`).run(sessionId);
  }

  static userFromSession(sessionId: string | undefined): User | null {
    if (!sessionId) return null;
    const row = db
      .prepare(
        `SELECT u.id AS id, u.email AS email, u.created_at AS created_at,
                u.active_company_id AS active_company_id
           FROM sessions s JOIN users u ON u.id = s.user_id
          WHERE s.id = ?`,
      )
      .get(sessionId) as User | undefined;
    return row ?? null;
  }

  static getSession(sessionId: string): Session | null {
    const row = db
      .prepare(`SELECT id, user_id, created_at FROM sessions WHERE id = ?`)
      .get(sessionId) as Session | undefined;
    return row ?? null;
  }
}
