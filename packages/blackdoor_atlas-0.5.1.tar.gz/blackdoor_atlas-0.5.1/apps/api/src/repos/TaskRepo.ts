// Tasks (issues) + the things that hang off a task: labels, subtasks,
// comments + reactions, activity, child issues. The route layer never touches
// SQL directly — it composes these typed methods.

import { db } from '../db.js';
import type {
  ActivityEntry,
  ChildIssue,
  Comment,
  CommentWithReactions,
  Label,
  ReactionMap,
  Subtask,
  Task,
  TaskPriority,
  TaskStatus,
  TaskWithRels,
} from '../domain/types.js';

const TASK_COLS = `
  t.id, t.project_id, t.title, t.body, t.status, t.priority, t.assignee, t.due_date,
  t.sort_index, t.task_number, t.estimate, t.parent_id, t.cycle_id,
  t.created_at, t.completed_at,
  p.key AS project_key, p.name AS project_name, p.color AS project_color
`;

type TaskRow = Task & { project_key: string; project_name: string; project_color: string };

export interface CreateTaskInput {
  project_id: number;
  title: string;
  body?: string;
  status?: TaskStatus;
  priority?: TaskPriority;
  assignee?: string;
  due_date?: string | null;
  estimate?: number | null;
  parent_id?: number | null;
  cycle_id?: number | null;
}

export interface UpdateTaskInput {
  title?: string;
  body?: string;
  status?: TaskStatus;
  priority?: TaskPriority;
  assignee?: string;
  due_date?: string | null;
  estimate?: number | null;
  parent_id?: number | null;
  cycle_id?: number | null;
}

export class TaskRepo {
  // ------- helpers ------------------------------------------------------

  private static enrich(row: TaskRow, currentUserEmail?: string): TaskWithRels {
    void currentUserEmail; // currently unused at task-level; comments use it
    const id = row.id;
    return {
      ...row,
      key: `${row.project_key}-${row.task_number}`,
      labels: TaskRepo.listLabels(id),
      subtasks: TaskRepo.listSubtasks(id),
      children: TaskRepo.listChildren(id),
    };
  }

  static listLabels(taskId: number): Label[] {
    return db
      .prepare(
        `SELECT l.id, l.project_id, l.name, l.color, l.created_at
           FROM labels l JOIN task_labels tl ON tl.label_id = l.id
          WHERE tl.task_id = ? ORDER BY l.name`,
      )
      .all(taskId) as Label[];
  }

  static listSubtasks(taskId: number): Subtask[] {
    return db
      .prepare(`SELECT id, task_id, title, done, sort_index, created_at FROM subtasks WHERE task_id = ? ORDER BY sort_index, id`)
      .all(taskId) as Subtask[];
  }

  static listChildren(taskId: number): ChildIssue[] {
    return db
      .prepare(
        `SELECT id, task_number, title, status, priority, estimate
           FROM tasks WHERE parent_id = ? ORDER BY sort_index, id`,
      )
      .all(taskId) as ChildIssue[];
  }

  // ------- ownership ----------------------------------------------------

  /** Returns the task only if it lives in the given workspace. */
  static findForCompany(taskId: number, companyId: number): TaskWithRels | null {
    const row = db
      .prepare(
        `SELECT ${TASK_COLS}
           FROM tasks t JOIN projects p ON p.id = t.project_id
          WHERE t.id = ? AND p.company_id = ?`,
      )
      .get(taskId, companyId) as TaskRow | undefined;
    return row ? TaskRepo.enrich(row) : null;
  }

  /** Lightweight check that this task lives in the given workspace. */
  static workspaceCheck(taskId: number, companyId: number): { id: number; project_id: number; status: TaskStatus } | null {
    return (
      (db
        .prepare(
          `SELECT t.id, t.project_id, t.status
             FROM tasks t JOIN projects p ON p.id = t.project_id
            WHERE t.id = ? AND p.company_id = ?`,
        )
        .get(taskId, companyId) as { id: number; project_id: number; status: TaskStatus } | undefined) ?? null
    );
  }

  // ------- list / search -----------------------------------------------

  static listInProject(
    projectId: number,
    filters: { cycle_id?: number | 'none'; parent_id?: number | 'none' } = {},
  ): TaskWithRels[] {
    const where: string[] = ['t.project_id = ?'];
    const args: unknown[] = [projectId];
    if (filters.cycle_id === 'none') where.push('t.cycle_id IS NULL');
    else if (typeof filters.cycle_id === 'number') { where.push('t.cycle_id = ?'); args.push(filters.cycle_id); }
    if (filters.parent_id === 'none') where.push('t.parent_id IS NULL');
    else if (typeof filters.parent_id === 'number') { where.push('t.parent_id = ?'); args.push(filters.parent_id); }
    const rows = db
      .prepare(
        `SELECT ${TASK_COLS}
           FROM tasks t JOIN projects p ON p.id = t.project_id
          WHERE ${where.join(' AND ')}
          ORDER BY t.status, t.sort_index, t.id`,
      )
      .all(...args) as TaskRow[];
    return rows.map((r) => TaskRepo.enrich(r));
  }

  static inboxFor(companyId: number): { open: TaskWithRels[]; recent_done: TaskWithRels[] } {
    const open = db
      .prepare(
        `SELECT ${TASK_COLS}
           FROM tasks t JOIN projects p ON p.id = t.project_id
          WHERE p.company_id = ? AND t.status IN ('backlog', 'todo', 'started', 'review')
          ORDER BY
            CASE t.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
            (t.due_date IS NULL),
            t.due_date,
            t.created_at`,
      )
      .all(companyId) as TaskRow[];
    const recent = db
      .prepare(
        `SELECT ${TASK_COLS}
           FROM tasks t JOIN projects p ON p.id = t.project_id
          WHERE p.company_id = ? AND t.status = 'done' AND t.completed_at > datetime('now', '-7 days')
          ORDER BY t.completed_at DESC
          LIMIT 10`,
      )
      .all(companyId) as TaskRow[];
    return { open: open.map((r) => TaskRepo.enrich(r)), recent_done: recent.map((r) => TaskRepo.enrich(r)) };
  }

  static mineFor(companyId: number, email: string): TaskWithRels[] {
    const rows = db
      .prepare(
        `SELECT ${TASK_COLS}
           FROM tasks t JOIN projects p ON p.id = t.project_id
          WHERE p.company_id = ? AND t.assignee = ? AND t.status NOT IN ('done', 'cancelled')
          ORDER BY
            CASE t.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
            (t.due_date IS NULL),
            t.due_date,
            t.created_at`,
      )
      .all(companyId, email) as TaskRow[];
    return rows.map((r) => TaskRepo.enrich(r));
  }

  static search(companyId: number, query: string): TaskWithRels[] {
    const q = query.trim();
    if (!q) return [];
    const keyMatch = q.match(/^([A-Za-z]{2,4})-(\d+)$/);
    if (keyMatch) {
      const [, prefix, num] = keyMatch;
      const row = db
        .prepare(
          `SELECT ${TASK_COLS}
             FROM tasks t JOIN projects p ON p.id = t.project_id
            WHERE p.company_id = ? AND UPPER(p.key) = UPPER(?) AND t.task_number = ?
            LIMIT 1`,
        )
        .get(companyId, prefix!, Number(num!)) as TaskRow | undefined;
      return row ? [TaskRepo.enrich(row)] : [];
    }
    const like = `%${q.replace(/[%_]/g, (m) => `\\${m}`)}%`;
    const rows = db
      .prepare(
        `SELECT ${TASK_COLS}
           FROM tasks t JOIN projects p ON p.id = t.project_id
          WHERE p.company_id = ?
            AND (t.title LIKE ? ESCAPE '\\' OR t.body LIKE ? ESCAPE '\\')
          ORDER BY
            (t.status NOT IN ('done', 'cancelled')) DESC,
            t.id DESC
          LIMIT 25`,
      )
      .all(companyId, like, like) as TaskRow[];
    return rows.map((r) => TaskRepo.enrich(r));
  }

  // ------- write --------------------------------------------------------

  static create(input: CreateTaskInput): TaskWithRels {
    const status: TaskStatus = input.status ?? 'todo';
    const sortRow = db
      .prepare(`SELECT COALESCE(MAX(sort_index), -1) AS max_sort FROM tasks WHERE project_id = ? AND status = ?`)
      .get(input.project_id, status) as { max_sort: number };
    const numberRow = db
      .prepare(`SELECT COALESCE(MAX(task_number), 0) AS n FROM tasks WHERE project_id = ?`)
      .get(input.project_id) as { n: number };
    const info = db
      .prepare(
        `INSERT INTO tasks (project_id, title, body, status, priority, assignee, due_date,
                            sort_index, task_number, estimate, parent_id, cycle_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        input.project_id,
        input.title,
        input.body ?? '',
        status,
        input.priority ?? 'med',
        input.assignee ?? '',
        input.due_date ?? null,
        sortRow.max_sort + 1,
        numberRow.n + 1,
        input.estimate ?? null,
        input.parent_id ?? null,
        input.cycle_id ?? null,
      );
    return TaskRepo.findForUserUnchecked(Number(info.lastInsertRowid))!;
  }

  /** Used internally after writes. The caller is responsible for ownership. */
  private static findForUserUnchecked(id: number): TaskWithRels | null {
    const row = db
      .prepare(
        `SELECT ${TASK_COLS} FROM tasks t JOIN projects p ON p.id = t.project_id WHERE t.id = ?`,
      )
      .get(id) as TaskRow | undefined;
    return row ? TaskRepo.enrich(row) : null;
  }

  static update(taskId: number, patch: UpdateTaskInput): TaskWithRels | null {
    const fields: string[] = [];
    const values: unknown[] = [];
    for (const k of ['title', 'body', 'status', 'priority', 'assignee'] as const) {
      if (patch[k] !== undefined) { fields.push(`${k} = ?`); values.push(patch[k]); }
    }
    for (const k of ['due_date', 'estimate', 'parent_id', 'cycle_id'] as const) {
      if (patch[k] !== undefined) { fields.push(`${k} = ?`); values.push(patch[k]); }
    }
    if (fields.length > 0) {
      values.push(taskId);
      db.prepare(`UPDATE tasks SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    }
    return TaskRepo.findForUserUnchecked(taskId);
  }

  static setCompletedAt(taskId: number, value: string | null): void {
    db.prepare(`UPDATE tasks SET completed_at = ? WHERE id = ?`).run(value, taskId);
  }

  static delete(taskId: number, companyId: number): boolean {
    const info = db
      .prepare(
        `DELETE FROM tasks WHERE id = ?
           AND project_id IN (SELECT id FROM projects WHERE company_id = ?)`,
      )
      .run(taskId, companyId);
    return info.changes > 0;
  }

  /** Bulk patch. Returns the count of rows touched. */
  static bulkUpdate(
    companyId: number,
    ids: number[],
    patch: Pick<UpdateTaskInput, 'status' | 'priority' | 'estimate' | 'cycle_id' | 'assignee'>,
  ): { ids: number[]; previousStatusById: Map<number, TaskStatus> } {
    if (ids.length === 0) return { ids: [], previousStatusById: new Map() };
    const placeholders = ids.map(() => '?').join(',');
    const owned = db
      .prepare(
        `SELECT t.id, t.status FROM tasks t JOIN projects p ON p.id = t.project_id
          WHERE p.company_id = ? AND t.id IN (${placeholders})`,
      )
      .all(companyId, ...ids) as Array<{ id: number; status: TaskStatus }>;
    const fields: string[] = [];
    const values: unknown[] = [];
    if (patch.status !== undefined) { fields.push('status = ?'); values.push(patch.status); }
    if (patch.priority !== undefined) { fields.push('priority = ?'); values.push(patch.priority); }
    if (patch.estimate !== undefined) { fields.push('estimate = ?'); values.push(patch.estimate); }
    if (patch.cycle_id !== undefined) { fields.push('cycle_id = ?'); values.push(patch.cycle_id); }
    if (patch.assignee !== undefined) { fields.push('assignee = ?'); values.push(patch.assignee); }
    if (fields.length === 0) return { ids: owned.map((r) => r.id), previousStatusById: new Map() };
    const stmt = db.prepare(`UPDATE tasks SET ${fields.join(', ')} WHERE id = ?`);
    const tx = db.transaction((rows: typeof owned) => {
      for (const r of rows) stmt.run(...values, r.id);
    });
    tx(owned);
    return {
      ids: owned.map((r) => r.id),
      previousStatusById: new Map(owned.map((r) => [r.id, r.status])),
    };
  }

  static reorder(projectId: number, status: TaskStatus, orderedIds: number[]): void {
    const stmt = db.prepare(`UPDATE tasks SET sort_index = ?, status = ? WHERE id = ? AND project_id = ?`);
    const tx = db.transaction((ids: number[]) => {
      ids.forEach((id, idx) => stmt.run(idx, status, id, projectId));
    });
    tx(orderedIds);
  }

  // ------- labels (task ↔ label) ---------------------------------------

  static attachLabel(taskId: number, labelId: number): void {
    db.prepare(`INSERT OR IGNORE INTO task_labels (task_id, label_id) VALUES (?, ?)`).run(taskId, labelId);
  }

  static detachLabel(taskId: number, labelId: number): void {
    db.prepare(`DELETE FROM task_labels WHERE task_id = ? AND label_id = ?`).run(taskId, labelId);
  }

  // ------- subtasks ----------------------------------------------------

  static addSubtask(taskId: number, title: string, done = false): Subtask {
    const sortRow = db
      .prepare(`SELECT COALESCE(MAX(sort_index), -1) AS max_sort FROM subtasks WHERE task_id = ?`)
      .get(taskId) as { max_sort: number };
    const info = db
      .prepare(`INSERT INTO subtasks (task_id, title, done, sort_index) VALUES (?, ?, ?, ?)`)
      .run(taskId, title.trim(), done ? 1 : 0, sortRow.max_sort + 1);
    return db
      .prepare(`SELECT id, task_id, title, done, sort_index, created_at FROM subtasks WHERE id = ?`)
      .get(Number(info.lastInsertRowid)) as Subtask;
  }

  static updateSubtask(taskId: number, subtaskId: number, patch: Partial<{ title: string; done: boolean }>): Subtask | null {
    const fields: string[] = [];
    const values: unknown[] = [];
    if (patch.title !== undefined) { fields.push('title = ?'); values.push(patch.title); }
    if (patch.done !== undefined) { fields.push('done = ?'); values.push(patch.done ? 1 : 0); }
    if (fields.length > 0) {
      values.push(subtaskId, taskId);
      db.prepare(`UPDATE subtasks SET ${fields.join(', ')} WHERE id = ? AND task_id = ?`).run(...values);
    }
    return (db
      .prepare(`SELECT id, task_id, title, done, sort_index, created_at FROM subtasks WHERE id = ?`)
      .get(subtaskId) as Subtask | undefined) ?? null;
  }

  static deleteSubtask(taskId: number, subtaskId: number): boolean {
    const info = db.prepare(`DELETE FROM subtasks WHERE id = ? AND task_id = ?`).run(subtaskId, taskId);
    return info.changes > 0;
  }

  // ------- comments + reactions ----------------------------------------

  static listComments(taskId: number, currentUserEmail: string): CommentWithReactions[] {
    const rows = db
      .prepare(`SELECT id, task_id, author, body, created_at FROM comments WHERE task_id = ? ORDER BY id`)
      .all(taskId) as Comment[];
    const reactionRows = db
      .prepare(
        `SELECT r.comment_id, r.emoji, r.author
           FROM reactions r JOIN comments c ON c.id = r.comment_id
          WHERE c.task_id = ?`,
      )
      .all(taskId) as Array<{ comment_id: number; emoji: string; author: string }>;
    const byComment = new Map<number, ReactionMap>();
    for (const r of reactionRows) {
      const bucket = byComment.get(r.comment_id) ?? {};
      const cur = bucket[r.emoji] ?? { count: 0, mine: false, authors: [] };
      cur.count += 1;
      cur.authors.push(r.author);
      if (r.author === currentUserEmail) cur.mine = true;
      bucket[r.emoji] = cur;
      byComment.set(r.comment_id, bucket);
    }
    return rows.map((c) => ({ ...c, reactions: byComment.get(c.id) ?? {} }));
  }

  static addComment(taskId: number, author: string, body: string): Comment {
    const info = db
      .prepare(`INSERT INTO comments (task_id, author, body) VALUES (?, ?, ?)`)
      .run(taskId, author, body.trim());
    return db
      .prepare(`SELECT id, task_id, author, body, created_at FROM comments WHERE id = ?`)
      .get(Number(info.lastInsertRowid)) as Comment;
  }

  static deleteComment(taskId: number, commentId: number, author: string): boolean {
    const info = db
      .prepare(`DELETE FROM comments WHERE id = ? AND task_id = ? AND author = ?`)
      .run(commentId, taskId, author);
    return info.changes > 0;
  }

  static toggleReaction(commentId: number, author: string, emoji: string): { toggled_off: boolean } {
    const prior = db
      .prepare(`SELECT id FROM reactions WHERE comment_id = ? AND author = ? AND emoji = ?`)
      .get(commentId, author, emoji) as { id: number } | undefined;
    if (prior) {
      db.prepare(`DELETE FROM reactions WHERE id = ?`).run(prior.id);
      return { toggled_off: true };
    }
    db.prepare(`INSERT INTO reactions (comment_id, author, emoji) VALUES (?, ?, ?)`).run(commentId, author, emoji);
    return { toggled_off: false };
  }

  // ------- activity ----------------------------------------------------

  static logActivity(taskId: number, kind: string, actor: string, payload: Record<string, unknown> = {}): void {
    db.prepare(`INSERT INTO activity (task_id, kind, actor, payload) VALUES (?, ?, ?, ?)`)
      .run(taskId, kind, actor, JSON.stringify(payload));
  }

  static listActivity(taskId: number, limit = 50): ActivityEntry[] {
    const rows = db
      .prepare(`SELECT id, task_id, kind, actor, payload, created_at FROM activity WHERE task_id = ? ORDER BY id DESC LIMIT ?`)
      .all(taskId, limit) as Array<{ id: number; task_id: number; kind: string; actor: string; payload: string; created_at: string }>;
    return rows.map((r) => {
      let payload: Record<string, unknown> = {};
      try { payload = JSON.parse(r.payload || '{}'); } catch { /* ignore */ }
      return { ...r, payload };
    });
  }
}
