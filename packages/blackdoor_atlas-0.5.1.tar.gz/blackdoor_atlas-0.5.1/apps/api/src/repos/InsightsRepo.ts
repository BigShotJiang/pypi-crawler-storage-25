// Read-only aggregates for the Insights tab.

import { db } from '../db.js';
import type { TaskPriority, TaskStatus } from '../domain/types.js';

export interface ProjectInsights {
  byStatus: Array<{ status: TaskStatus; n: number }>;
  byPriority: Array<{ priority: TaskPriority; n: number }>;
  byAssignee: Array<{ assignee: string; n: number }>;
  completion: Array<{ day: string; n: number }>;
}

export class InsightsRepo {
  static forProject(projectId: number): ProjectInsights {
    const byStatus = db
      .prepare(`SELECT status, COUNT(*) AS n FROM tasks WHERE project_id = ? GROUP BY status`)
      .all(projectId) as Array<{ status: TaskStatus; n: number }>;
    const byPriority = db
      .prepare(`SELECT priority, COUNT(*) AS n FROM tasks WHERE project_id = ? AND status NOT IN ('done', 'cancelled') GROUP BY priority`)
      .all(projectId) as Array<{ priority: TaskPriority; n: number }>;
    const byAssignee = db
      .prepare(
        `SELECT COALESCE(NULLIF(assignee, ''), '(unassigned)') AS assignee, COUNT(*) AS n
           FROM tasks WHERE project_id = ? AND status NOT IN ('done', 'cancelled')
          GROUP BY assignee ORDER BY n DESC`,
      )
      .all(projectId) as Array<{ assignee: string; n: number }>;
    const completion = db
      .prepare(
        `SELECT DATE(completed_at) AS day, COUNT(*) AS n
           FROM tasks
          WHERE project_id = ? AND status = 'done' AND completed_at IS NOT NULL
            AND completed_at >= datetime('now', '-14 days')
          GROUP BY day ORDER BY day`,
      )
      .all(projectId) as Array<{ day: string; n: number }>;
    return { byStatus, byPriority, byAssignee, completion };
  }
}
