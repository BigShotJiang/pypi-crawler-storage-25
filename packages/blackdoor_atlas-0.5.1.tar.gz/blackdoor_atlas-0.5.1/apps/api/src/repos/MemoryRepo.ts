// Hermes-style two-layer memory: a bounded MEMORY.md (agent-authored notes
// about the environment + conventions) and USER.md (preferences + style).
//
// The "frozen snapshot pattern" matters here: writes persist immediately to
// disk, but `loadForPrompt()` returns the snapshot that was captured at the
// *start of the current session*. That keeps the prefix cache hot across
// turns — the system prompt's bytes don't shift mid-conversation.
//
// Reference: https://hermes-agent.nousresearch.com/docs/user-guide/features/memory/

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { repoRoot } from '../agent/system.js';

const MEM_DIR = path.join(repoRoot(), '.agent', 'memory');
const MEM_PATH = path.join(MEM_DIR, 'MEMORY.md');
const USER_PATH = path.join(MEM_DIR, 'USER.md');

// Hermes' published limits (chars, not tokens — works out to ~800 / ~500
// tokens of English). We enforce on write so an unbounded agent can't bloat
// the system prompt and blow the cache window.
const MEM_LIMIT = 2200;
const USER_LIMIT = 1375;

const MEM_HEADER =
`# Agent memory

Persistent notes for the agent. The contents of this file are injected into
the system prompt at session start. Entries should be terse, durable facts
about this repository / environment / conventions — not transient state.
`;

const USER_HEADER =
`# User profile

Persistent notes about the user. Communication style, preferences,
expectations. Loaded into the system prompt at session start.
`;

function ensureDir(): void {
  mkdirSync(MEM_DIR, { recursive: true });
}

function readOrSeed(p: string, header: string): string {
  if (!existsSync(p)) {
    ensureDir();
    writeFileSync(p, header, 'utf8');
    return header;
  }
  return readFileSync(p, 'utf8');
}

function truncate(text: string, limit: number): string {
  if (text.length <= limit) return text;
  // Cut on a newline boundary near the limit so we don't slice a heading mid-line.
  const cut = text.lastIndexOf('\n', limit);
  return text.slice(0, cut > limit - 200 ? cut : limit) + '\n…[truncated]\n';
}

export class MemoryRepo {
  /** Snapshot of (memory, user) as they were on disk right now. */
  static read(): { memory: string; user: string } {
    return {
      memory: readOrSeed(MEM_PATH, MEM_HEADER),
      user: readOrSeed(USER_PATH, USER_HEADER),
    };
  }

  /** Replace one of the two files wholesale. Enforces the size cap. */
  static write(which: 'memory' | 'user', body: string): void {
    ensureDir();
    const limit = which === 'memory' ? MEM_LIMIT : USER_LIMIT;
    const safe = truncate(body, limit);
    writeFileSync(which === 'memory' ? MEM_PATH : USER_PATH, safe, 'utf8');
  }

  /**
   * Append a memory entry as a bullet under a heading, idempotently. If an
   * identical entry already exists, do nothing.
   */
  static add(which: 'memory' | 'user', entry: string): { added: boolean; reason?: string } {
    const trimmed = entry.trim();
    if (!trimmed) return { added: false, reason: 'empty' };
    const cur = which === 'memory' ? readOrSeed(MEM_PATH, MEM_HEADER) : readOrSeed(USER_PATH, USER_HEADER);
    const bullet = trimmed.startsWith('- ') ? trimmed : `- ${trimmed}`;
    if (cur.includes(bullet)) return { added: false, reason: 'duplicate' };
    const next = cur.replace(/\s*$/, '') + '\n' + bullet + '\n';
    MemoryRepo.write(which, next);
    return { added: true };
  }

  /**
   * Replace the first substring match. If `find` isn't a unique hit, returns
   * the count so the caller can be more specific.
   */
  static replace(which: 'memory' | 'user', find: string, replace: string): { changed: boolean; matches: number } {
    const cur = which === 'memory' ? readOrSeed(MEM_PATH, MEM_HEADER) : readOrSeed(USER_PATH, USER_HEADER);
    const matches = cur.split(find).length - 1;
    if (matches === 0) return { changed: false, matches: 0 };
    if (matches > 1) return { changed: false, matches };
    MemoryRepo.write(which, cur.replace(find, replace));
    return { changed: true, matches: 1 };
  }

  static remove(which: 'memory' | 'user', find: string): { removed: number } {
    const cur = which === 'memory' ? readOrSeed(MEM_PATH, MEM_HEADER) : readOrSeed(USER_PATH, USER_HEADER);
    const matches = cur.split(find).length - 1;
    if (matches === 0) return { removed: 0 };
    MemoryRepo.write(which, cur.split(find).join(''));
    return { removed: matches };
  }
}
