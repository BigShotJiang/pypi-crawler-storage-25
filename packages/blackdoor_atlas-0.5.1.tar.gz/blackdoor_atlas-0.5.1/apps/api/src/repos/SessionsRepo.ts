// SessionsRepo — Hermes-style full-text search over the agent's session
// transcripts on disk (.agent/sessions/*.json).
//
// Goals (modeled on Hermes' sessions FTS):
//   1. The user can ask "have we worked on X before?" — grep is too narrow
//      (only matches inside the literal JSON; punctuation / encoding noise
//      and you miss the hit). FTS5 with the porter+unicode61 tokenizer makes
//      "session search" actually find prior conversations.
//   2. The index is rebuilt lazily, keyed on (path, mtime), so we never
//      re-tokenize an unchanged file. Cold start over ~50 sessions is ~50ms.
//   3. We index user messages and assistant text only — never tool outputs
//      (file listings, command stdouts) which are noisy and crowd out the
//      real signal. The Hermes folks call this "intent-only indexing".
//
// Storage: the agent_sessions table holds metadata; agent_sessions_fts is a
// contentless FTS5 virtual table whose rowid matches agent_sessions.id. We
// avoid the "content=" trick because it'd require a triggered sync that
// adds complexity for no benefit on a file-derived index.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { db } from '../db.js';
import { repoRoot } from '../agent/system.js';

// --- schema (idempotent) ---------------------------------------------------

db.exec(`
  CREATE TABLE IF NOT EXISTS agent_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL UNIQUE,
    path TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT '',
    provider TEXT NOT NULL DEFAULT '',
    model TEXT NOT NULL DEFAULT '',
    first_user TEXT NOT NULL DEFAULT '',
    message_count INTEGER NOT NULL DEFAULT 0,
    mtime_ms INTEGER NOT NULL DEFAULT 0
  );

  CREATE INDEX IF NOT EXISTS idx_agent_sessions_mtime ON agent_sessions(mtime_ms DESC);
`);

// FTS5 may not be compiled in on every build of better-sqlite3, but it is on
// macOS / the prebuilt binary we ship. Wrap creation so we surface a clear
// message rather than an opaque SQLITE_ERROR.
try {
  db.exec(`
    CREATE VIRTUAL TABLE IF NOT EXISTS agent_sessions_fts
    USING fts5(text, tokenize='porter unicode61');
  `);
} catch (err) {
  // eslint-disable-next-line no-console
  console.warn('[SessionsRepo] FTS5 unavailable, session_search will be a no-op:', (err as Error).message);
}

// --- types -----------------------------------------------------------------

export interface SessionHit {
  session_id: string;
  path: string;          // relative to repo root
  created_at: string;
  updated_at: string;
  provider: string;
  model: string;
  first_user: string;    // first user message, truncated
  message_count: number;
  snippet: string;       // FTS snippet with <<>> markers around hits
  rank: number;          // bm25 score (lower = better; we sort ascending)
}

// --- indexing --------------------------------------------------------------

const SESSIONS_DIR = (): string => path.join(repoRoot(), '.agent', 'sessions');

interface FsEntry { abs: string; rel: string; mtime: number; }

function listSessionFiles(): FsEntry[] {
  const dir = SESSIONS_DIR();
  let names: string[];
  try { names = readdirSync(dir); } catch { return []; }
  const out: FsEntry[] = [];
  for (const name of names) {
    if (!name.endsWith('.json')) continue;
    const abs = path.join(dir, name);
    try {
      const st = statSync(abs);
      if (!st.isFile()) continue;
      out.push({ abs, rel: path.join('.agent', 'sessions', name), mtime: Math.floor(st.mtimeMs) });
    } catch {
      continue;
    }
  }
  return out;
}

// Pull just the parts of the session JSON we want to index. We deliberately
// skip tool_use blocks (the inputs are JSON, often paths/regexes — not what
// a human is searching for) and tool results (file listings, stderr — pure
// noise for intent search).
interface ParsedSession {
  session_id: string;
  created_at: string;
  updated_at: string;
  provider: string;
  model: string;
  first_user: string;
  text: string;
  message_count: number;
}

function parseSession(abs: string): ParsedSession | null {
  let body: string;
  try { body = readFileSync(abs, 'utf8'); } catch { return null; }
  let json: any; // eslint-disable-line @typescript-eslint/no-explicit-any
  try { json = JSON.parse(body); } catch { return null; }
  if (!json || typeof json !== 'object') return null;

  const messages: any[] = Array.isArray(json.messages) ? json.messages : []; // eslint-disable-line @typescript-eslint/no-explicit-any
  const parts: string[] = [];
  let firstUser = '';
  for (const m of messages) {
    if (m?.role === 'user' && typeof m.content === 'string') {
      if (!firstUser) firstUser = m.content;
      parts.push(m.content);
      continue;
    }
    if (m?.role === 'assistant' && Array.isArray(m.content)) {
      for (const block of m.content) {
        if (block?.type === 'text' && typeof block.text === 'string') {
          parts.push(block.text);
        }
      }
    }
  }

  return {
    session_id: String(json.id ?? path.basename(abs, '.json')),
    created_at: String(json.created_at ?? ''),
    updated_at: String(json.updated_at ?? ''),
    provider: String(json.provider ?? ''),
    model: String(json.model ?? ''),
    first_user: firstUser.slice(0, 200),
    text: parts.join('\n\n'),
    message_count: messages.length,
  };
}

const upsertMeta = db.prepare(
  `INSERT INTO agent_sessions (
     session_id, path, created_at, updated_at, provider, model,
     first_user, message_count, mtime_ms
   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
   ON CONFLICT(session_id) DO UPDATE SET
     path = excluded.path,
     created_at = excluded.created_at,
     updated_at = excluded.updated_at,
     provider = excluded.provider,
     model = excluded.model,
     first_user = excluded.first_user,
     message_count = excluded.message_count,
     mtime_ms = excluded.mtime_ms`,
);

const selectId = db.prepare(`SELECT id, mtime_ms FROM agent_sessions WHERE session_id = ?`);
const deleteFtsByRowid = db.prepare(`DELETE FROM agent_sessions_fts WHERE rowid = ?`);
const insertFts = db.prepare(`INSERT INTO agent_sessions_fts (rowid, text) VALUES (?, ?)`);
const listKnown = db.prepare(`SELECT id, session_id FROM agent_sessions`);
const deleteMeta = db.prepare(`DELETE FROM agent_sessions WHERE id = ?`);

/**
 * Sync the SQLite index with what's on disk:
 *   - new files → insert + FTS row
 *   - files whose mtime advanced → update meta + replace FTS row
 *   - files removed from disk → drop from both tables
 *
 * Safe to call on every request; the per-file mtime check is the fast path.
 */
export function reindexSessions(): { added: number; updated: number; removed: number } {
  const files = listSessionFiles();
  const onDisk = new Set(files.map((f) => path.basename(f.abs, '.json')));
  let added = 0, updated = 0, removed = 0;

  for (const f of files) {
    const sid = path.basename(f.abs, '.json');
    const existing = selectId.get(sid) as { id: number; mtime_ms: number } | undefined;
    if (existing && existing.mtime_ms === f.mtime) continue; // already current
    const parsed = parseSession(f.abs);
    if (!parsed) continue;

    const tx = db.transaction(() => {
      upsertMeta.run(
        parsed.session_id, f.rel, parsed.created_at, parsed.updated_at,
        parsed.provider, parsed.model, parsed.first_user, parsed.message_count, f.mtime,
      );
      const row = selectId.get(parsed.session_id) as { id: number; mtime_ms: number };
      // Replace the FTS row (delete then insert — FTS5 doesn't support upsert
      // on rowid directly, and an UPDATE of `text` is equivalent to a delete +
      // insert internally anyway).
      deleteFtsByRowid.run(row.id);
      insertFts.run(row.id, parsed.text);
    });
    tx();
    if (existing) updated++; else added++;
  }

  // Garbage-collect rows whose file vanished from disk.
  const known = listKnown.all() as Array<{ id: number; session_id: string }>;
  for (const k of known) {
    if (onDisk.has(k.session_id)) continue;
    const tx = db.transaction(() => {
      deleteFtsByRowid.run(k.id);
      deleteMeta.run(k.id);
    });
    tx();
    removed++;
  }
  return { added, updated, removed };
}

// --- query -----------------------------------------------------------------

const searchStmt = db.prepare(
  `SELECT s.session_id, s.path, s.created_at, s.updated_at, s.provider, s.model,
          s.first_user, s.message_count,
          snippet(agent_sessions_fts, 0, '<<', '>>', '…', 12) AS snippet,
          bm25(agent_sessions_fts) AS rank
     FROM agent_sessions_fts
     JOIN agent_sessions s ON s.id = agent_sessions_fts.rowid
    WHERE agent_sessions_fts MATCH ?
    ORDER BY rank ASC
    LIMIT ?`,
);

const recentStmt = db.prepare(
  `SELECT session_id, path, created_at, updated_at, provider, model,
          first_user, message_count
     FROM agent_sessions
    ORDER BY mtime_ms DESC
    LIMIT ?`,
);

const getByIdStmt = db.prepare(
  `SELECT session_id, path, created_at, updated_at, provider, model,
          first_user, message_count
     FROM agent_sessions
    WHERE session_id = ?`,
);

/**
 * FTS5 search. The query is passed through verbatim — callers should use
 * FTS5 query syntax (term1 term2, "exact phrase", term*, OR, NOT).
 */
export function searchSessions(query: string, limit = 10): SessionHit[] {
  reindexSessions();
  const q = query.trim();
  if (!q) return [];
  try {
    return searchStmt.all(q, Math.max(1, Math.min(50, limit))) as SessionHit[];
  } catch (err) {
    // FTS5 throws on malformed queries (unbalanced quotes, lone NEAR, etc).
    // Surface a useful message rather than 500ing the agent loop.
    throw new Error(`session_search: invalid FTS5 query: ${(err as Error).message}`);
  }
}

export function recentSessions(limit = 10): Array<Omit<SessionHit, 'snippet' | 'rank'>> {
  reindexSessions();
  return recentStmt.all(Math.max(1, Math.min(50, limit))) as Array<Omit<SessionHit, 'snippet' | 'rank'>>;
}

export function getSession(sessionId: string): Omit<SessionHit, 'snippet' | 'rank'> | null {
  reindexSessions();
  return (getByIdStmt.get(sessionId) as Omit<SessionHit, 'snippet' | 'rank'> | undefined) ?? null;
}

export const SessionsRepo = { reindexSessions, searchSessions, recentSessions, getSession };
