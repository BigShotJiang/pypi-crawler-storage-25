// Projects + labels live together since labels are a property of a project.

import { db } from '../db.js';
import type {
  Label,
  Project,
  ProjectStatus,
  ProjectWithCounts,
} from '../domain/types.js';

const PROJECT_COLS = `id, user_id, company_id, name, description, color, status, key, created_at`;
const LABEL_COLS = `id, project_id, name, color, created_at`;

export class ProjectRepo {
  // -- keys / slugs -------------------------------------------------------

  /** Derive a Linear-style 3-letter slug. Falls back to PRJ. */
  static deriveKey(name: string): string {
    const cleaned = name.replace(/[^A-Za-z]/g, '').toUpperCase();
    return (cleaned.slice(0, 3) || 'PRJ').padEnd(3, 'X');
  }

  /** Pick a key not yet used in this workspace. */
  static uniqueKey(companyId: number, base: string): string {
    const rows = db.prepare(`SELECT key FROM projects WHERE company_id = ?`).all(companyId) as Array<{ key: string }>;
    const taken = new Set(rows.map((r) => r.key));
    if (!taken.has(base)) return base;
    for (let i = 2; i < 1000; i++) {
      const candidate = `${base}${i}`.slice(0, 4);
      if (!taken.has(candidate)) return candidate;
    }
    return base + Math.floor(Math.random() * 1000);
  }

  // -- CRUD ---------------------------------------------------------------

  static listForCompany(companyId: number): ProjectWithCounts[] {
    return db
      .prepare(
        `SELECT ${PROJECT_COLS},
                (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) AS task_count,
                (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'done') AS done_count
           FROM projects p
          WHERE p.company_id = ?
          ORDER BY p.created_at ASC`,
      )
      .all(companyId) as ProjectWithCounts[];
  }

  static findById(id: number): Project | null {
    const row = db.prepare(`SELECT ${PROJECT_COLS} FROM projects WHERE id = ?`).get(id) as Project | undefined;
    return row ?? null;
  }

  /** Returns the project only if it lives in the given company. */
  static findForCompany(id: number, companyId: number): Project | null {
    const row = db
      .prepare(`SELECT ${PROJECT_COLS} FROM projects WHERE id = ? AND company_id = ?`)
      .get(id, companyId) as Project | undefined;
    return row ?? null;
  }

  static create(input: {
    userId: number;
    companyId: number;
    name: string;
    description?: string;
    color?: string;
    status?: ProjectStatus;
  }): Project {
    const key = ProjectRepo.uniqueKey(input.companyId, ProjectRepo.deriveKey(input.name));
    const info = db
      .prepare(
        `INSERT INTO projects (user_id, company_id, name, description, color, status, key)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        input.userId,
        input.companyId,
        input.name,
        input.description ?? '',
        input.color ?? '#5b8def',
        input.status ?? 'active',
        key,
      );
    return ProjectRepo.findById(Number(info.lastInsertRowid))!;
  }

  static update(id: number, patch: Partial<Pick<Project, 'name' | 'description' | 'color' | 'status'>>): Project | null {
    const fields: string[] = [];
    const values: unknown[] = [];
    for (const key of ['name', 'description', 'color', 'status'] as const) {
      if (patch[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(patch[key]);
      }
    }
    if (fields.length === 0) return ProjectRepo.findById(id);
    values.push(id);
    db.prepare(`UPDATE projects SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    return ProjectRepo.findById(id);
  }

  static delete(id: number, companyId: number): boolean {
    const info = db
      .prepare(`DELETE FROM projects WHERE id = ? AND company_id = ?`)
      .run(id, companyId);
    return info.changes > 0;
  }

  // -- labels (project-scoped) --------------------------------------------

  static listLabels(projectId: number): Label[] {
    return db
      .prepare(`SELECT ${LABEL_COLS} FROM labels WHERE project_id = ? ORDER BY name`)
      .all(projectId) as Label[];
  }

  static createLabel(projectId: number, name: string, color: string): Label {
    const info = db
      .prepare(`INSERT INTO labels (project_id, name, color) VALUES (?, ?, ?)`)
      .run(projectId, name.trim(), color);
    return db
      .prepare(`SELECT ${LABEL_COLS} FROM labels WHERE id = ?`)
      .get(Number(info.lastInsertRowid)) as Label;
  }

  static deleteLabel(projectId: number, labelId: number): boolean {
    const info = db
      .prepare(`DELETE FROM labels WHERE id = ? AND project_id = ?`)
      .run(labelId, projectId);
    return info.changes > 0;
  }
}
