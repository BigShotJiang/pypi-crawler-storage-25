// Domain types — the canonical TypeScript shape of every database row.
//
// These are POJOs (plain object types), not classes with behavior. The data
// access layer (`repos/`) is responsible for turning rows into these types,
// and services / routes layer business logic on top. Keeping the types
// behavior-free means they can be sent over the wire without further mapping
// and consumed as-is by the web client.

export const TASK_STATUSES = ['backlog', 'todo', 'started', 'review', 'done', 'cancelled'] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const TASK_PRIORITIES = ['urgent', 'high', 'med', 'low'] as const;
export type TaskPriority = (typeof TASK_PRIORITIES)[number];

export const ESTIMATES = [1, 2, 3, 5, 8, 13] as const;
export type Estimate = (typeof ESTIMATES)[number];

export const CYCLE_STATUSES = ['upcoming', 'active', 'completed'] as const;
export type CycleStatus = (typeof CYCLE_STATUSES)[number];

export const PROJECT_STATUSES = ['active', 'paused', 'archived'] as const;
export type ProjectStatus = (typeof PROJECT_STATUSES)[number];

export interface User {
  id: number;
  email: string;
  created_at: string;
  active_company_id: number | null;
}

export type CompanyRole = 'owner' | 'admin' | 'member';

export interface Company {
  id: number;
  name: string;
  key: string;
  color: string;
  description: string;
  created_at: string;
}

export interface CompanyWithMeta extends Company {
  role: CompanyRole;       // the requesting user's role in this workspace
  member_count: number;
  project_count: number;
  is_active: boolean;      // true if this matches user.active_company_id
}

export interface Session {
  id: string;          // opaque token
  user_id: number;
  created_at: string;
}

export interface Project {
  id: number;
  user_id: number;          // creator; kept for back-compat. Auth uses company_id.
  company_id: number | null; // owning workspace
  name: string;
  description: string;
  color: string;
  status: ProjectStatus;
  key: string;
  created_at: string;
}

// Returned by ProjectRepo.listForUser — includes counts.
export interface ProjectWithCounts extends Project {
  task_count: number;
  done_count: number;
}

export interface Label {
  id: number;
  project_id: number;
  name: string;
  color: string;
  created_at: string;
}

export interface Task {
  id: number;
  project_id: number;
  title: string;
  body: string;
  status: TaskStatus;
  priority: TaskPriority;
  assignee: string;
  due_date: string | null;
  sort_index: number;
  task_number: number;
  estimate: number | null;
  parent_id: number | null;
  cycle_id: number | null;
  created_at: string;
  completed_at: string | null;
}

// What the API ships over the wire: a Task joined to its project + the
// derived `key`, plus all the related collections the web UI expects.
export interface TaskWithRels extends Task {
  project_key: string;
  project_name: string;
  project_color: string;
  key: string;
  labels: Label[];
  subtasks: Subtask[];
  children: ChildIssue[];
}

export interface ChildIssue {
  id: number;
  task_number: number;
  title: string;
  status: TaskStatus;
  priority: TaskPriority;
  estimate: number | null;
}

export interface Subtask {
  id: number;
  task_id: number;
  title: string;
  done: number;        // 0/1 — kept as int to match SQLite
  sort_index: number;
  created_at: string;
}

export type ReactionMap = Record<string, { count: number; mine: boolean; authors: string[] }>;

export interface Comment {
  id: number;
  task_id: number;
  author: string;
  body: string;
  created_at: string;
}

export interface CommentWithReactions extends Comment {
  reactions: ReactionMap;
}

export interface ActivityEntry {
  id: number;
  task_id: number;
  kind: string;
  actor: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface Cycle {
  id: number;
  project_id: number;
  number: number;
  name: string;
  start_date: string;
  end_date: string;
  status: CycleStatus;
  created_at: string;
}

export interface CycleWithCounts extends Cycle {
  task_count: number;
  done_count: number;
}

export interface Reaction {
  id: number;
  comment_id: number;
  author: string;
  emoji: string;
  created_at: string;
}

export interface SavedView {
  id: number;
  user_id: number;
  project_id: number | null;
  name: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface Template {
  id: number;
  project_id: number;
  name: string;
  title: string;
  body: string;
  priority: TaskPriority;
  estimate: number | null;
  created_at: string;
}
