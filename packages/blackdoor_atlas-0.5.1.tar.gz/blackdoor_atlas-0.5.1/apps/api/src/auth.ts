// Request-level auth glue. Re-exports primitives from UserRepo so callers
// outside `routes/` can keep importing from this module.

import type { NextFunction, Request, Response } from 'express';
import { UserRepo } from './repos/UserRepo.js';
import { CompanyRepo } from './repos/CompanyRepo.js';
import type { User } from './domain/types.js';

export type { User };

export const COOKIE_NAME = 'sid';

export const hashPassword = UserRepo.hashPassword.bind(UserRepo);
export const verifyPassword = UserRepo.verifyPassword.bind(UserRepo);
export const createSession = UserRepo.createSession.bind(UserRepo);
export const destroySession = UserRepo.destroySession.bind(UserRepo);
export const userFromSession = UserRepo.userFromSession.bind(UserRepo);

export function requireUser(req: Request, res: Response, next: NextFunction): void {
  const sid = req.cookies?.[COOKIE_NAME] as string | undefined;
  const user = UserRepo.userFromSession(sid);
  if (!user) {
    res.status(401).json({ error: 'unauthorized' });
    return;
  }
  req.user = user;
  next();
}

/** Resolves `req.user`'s active workspace and stashes it on `req.companyId`.
 *  404s if the user has no workspaces. Routes that operate inside a
 *  workspace should chain this after requireUser. */
export function requireCompany(req: Request, res: Response, next: NextFunction): void {
  if (!req.user) { res.status(401).json({ error: 'unauthorized' }); return; }
  const cid = CompanyRepo.resolveActiveForUser(req.user.id);
  if (!cid) { res.status(404).json({ error: 'no_active_workspace' }); return; }
  req.companyId = cid;
  next();
}
