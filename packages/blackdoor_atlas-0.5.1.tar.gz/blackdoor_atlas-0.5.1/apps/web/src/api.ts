export interface User {
  id: number;
  email: string;
  active_company_id?: number | null;
}

export type CompanyRole = 'owner' | 'admin' | 'member';

export interface Company {
  id: number;
  name: string;
  key: string;
  color: string;
  description: string;
  role: CompanyRole;
  member_count: number;
  project_count: number;
  is_active: boolean;
}

export interface CompaniesResponse {
  active_company_id: number | null;
  companies: Company[];
}

export interface Note {
  id: number;
  title: string;
  body: string;
  created_at: string;
}

export type AssistantBlock =
  | { type: 'text'; text: string }
  | { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> };

export type ChatMessage =
  | { role: 'user'; content: string }
  | { role: 'assistant'; content: AssistantBlock[] }
  | { role: 'tool'; tool_use_id: string; content: string; is_error?: boolean };

export interface ProviderInfo {
  id: string;
  label: string;
  model: string;
  ready: boolean;
  reason?: string;
}

export interface AgentInfo {
  active: { id: string; model: string } | null;
  providers: ProviderInfo[];
}

export interface RepoMap {
  generated_at: string;
  total_files: number;
  groups: Array<{
    top: string;
    files: Array<{ rel: string; symbols: string[] }>;
  }>;
}

export interface Project {
  id: number;
  name: string;
  description: string;
  color: string;
  status: 'active' | 'paused' | 'archived';
  key: string;
  created_at: string;
  task_count?: number;
  done_count?: number;
}

// Linear-style 6-state pipeline. `doing` is accepted by the API for back-compat
// but new code should use `started`.
export type TaskStatus = 'backlog' | 'todo' | 'started' | 'review' | 'done' | 'cancelled';
export type TaskPriority = 'low' | 'med' | 'high' | 'urgent';
export type Estimate = 1 | 2 | 3 | 5 | 8 | 13;
export const STATUSES: TaskStatus[] = ['backlog', 'todo', 'started', 'review', 'done', 'cancelled'];
export const PRIORITIES: TaskPriority[] = ['urgent', 'high', 'med', 'low'];
export const ESTIMATES: Estimate[] = [1, 2, 3, 5, 8, 13];

export interface Label {
  id: number;
  project_id?: number;
  name: string;
  color: string;
}

export interface Subtask {
  id: number;
  title: string;
  done: number;       // 0 or 1
  sort_index: number;
}

export interface ChildIssue {
  id: number;
  task_number: number;
  title: string;
  status: TaskStatus;
  priority: TaskPriority;
  estimate: number | null;
}

export type ReactionMap = Record<string, { count: number; mine: boolean; authors: string[] }>;

export interface Comment {
  id: number;
  author: string;
  body: string;
  created_at: string;
  reactions?: ReactionMap;
}

export interface ActivityEntry {
  id: number;
  kind: string;
  actor: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface Task {
  id: number;
  project_id: number;
  title: string;
  body: string;
  status: TaskStatus;
  priority: TaskPriority;
  assignee: string;
  due_date: string | null;
  sort_index: number;
  task_number: number;
  estimate: number | null;
  parent_id: number | null;
  cycle_id: number | null;
  created_at: string;
  completed_at: string | null;
  project_key?: string;
  project_name?: string;
  project_color?: string;
  key?: string;
  labels: Label[];
  subtasks: Subtask[];
  children: ChildIssue[];
}

export interface TaskDetail extends Task {
  comments: Comment[];
  activity: ActivityEntry[];
}

export interface Inbox {
  open: Task[];
  recent_done: Task[];
}

export interface Cycle {
  id: number;
  project_id: number;
  number: number;
  name: string;
  start_date: string;
  end_date: string;
  status: 'upcoming' | 'active' | 'completed';
  task_count?: number;
  done_count?: number;
}

export interface ProjectInsights {
  byStatus: Array<{ status: TaskStatus; n: number }>;
  byPriority: Array<{ priority: TaskPriority; n: number }>;
  byAssignee: Array<{ assignee: string; n: number }>;
  completion: Array<{ day: string; n: number }>;
}

export interface SavedView {
  id: number;
  name: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface Template {
  id: number;
  name: string;
  title: string;
  body: string;
  priority: TaskPriority;
  estimate: number | null;
}

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let detail: unknown = null;
    try {
      detail = await res.json();
    } catch {
      // ignore non-JSON bodies
    }
    const err = new Error(`request failed ${res.status}`) as Error & { detail?: unknown };
    err.detail = detail;
    throw err;
  }
  if (res.status === 204) return undefined as unknown as T;
  return (await res.json()) as T;
}

const opts: RequestInit = { credentials: 'include' };

export const api = {
  me: () => fetch('/api/auth/me', opts).then((r) => json<User>(r)),
  signup: (email: string, password: string) =>
    fetch('/api/auth/signup', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    }).then((r) => json<User>(r)),
  login: (email: string, password: string) =>
    fetch('/api/auth/login', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    }).then((r) => json<User>(r)),
  logout: () =>
    fetch('/api/auth/logout', { ...opts, method: 'POST' }).then((r) => json<void>(r)),

  // ---- companies (workspaces) ----
  listCompanies: () =>
    fetch('/api/companies', opts).then((r) => json<CompaniesResponse>(r)),
  createCompany: (input: { name: string; color?: string; description?: string }) =>
    fetch('/api/companies', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    }).then((r) => json<Company>(r)),
  updateCompany: (id: number, patch: Partial<{ name: string; color: string; description: string }>) =>
    fetch(`/api/companies/${id}`, {
      ...opts,
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => json<Company>(r)),
  deleteCompany: (id: number) =>
    fetch(`/api/companies/${id}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),
  switchCompany: (companyId: number) =>
    fetch('/api/companies/switch', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ company_id: companyId }),
    }).then((r) => json<{ active_company_id: number }>(r)),

  listNotes: () => fetch('/api/notes', opts).then((r) => json<Note[]>(r)),
  createNote: (title: string, body: string) =>
    fetch('/api/notes', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, body }),
    }).then((r) => json<Note>(r)),
  updateNote: (id: number, patch: Partial<{ title: string; body: string }>) =>
    fetch(`/api/notes/${id}`, {
      ...opts,
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => json<Note>(r)),
  deleteNote: (id: number) =>
    fetch(`/api/notes/${id}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),

  // ---- projects ----
  listProjects: () => fetch('/api/projects', opts).then((r) => json<Project[]>(r)),
  getProject: (id: number) => fetch(`/api/projects/${id}`, opts).then((r) => json<Project>(r)),
  createProject: (input: { name: string; description?: string; color?: string }) =>
    fetch('/api/projects', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    }).then((r) => json<Project>(r)),
  updateProject: (id: number, patch: Partial<Pick<Project, 'name' | 'description' | 'color' | 'status'>>) =>
    fetch(`/api/projects/${id}`, {
      ...opts,
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => json<Project>(r)),
  deleteProject: (id: number) =>
    fetch(`/api/projects/${id}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),

  // ---- tasks ----
  listTasks: (projectId: number, opts2: { cycle_id?: number | 'none'; parent_id?: number | 'none' } = {}) => {
    const params = new URLSearchParams({ project_id: String(projectId) });
    if (opts2.cycle_id !== undefined) params.set('cycle_id', opts2.cycle_id === 'none' ? '0' : String(opts2.cycle_id));
    if (opts2.parent_id !== undefined) params.set('parent_id', opts2.parent_id === 'none' ? '0' : String(opts2.parent_id));
    return fetch(`/api/tasks?${params.toString()}`, opts).then((r) => json<Task[]>(r));
  },
  inbox: () => fetch('/api/tasks/inbox', opts).then((r) => json<Inbox>(r)),
  myIssues: () => fetch('/api/tasks/mine', opts).then((r) => json<Task[]>(r)),
  searchTasks: (q: string) =>
    fetch(`/api/tasks/search?q=${encodeURIComponent(q)}`, opts).then((r) => json<Task[]>(r)),
  getTask: (id: number) => fetch(`/api/tasks/${id}`, opts).then((r) => json<TaskDetail>(r)),
  createTask: (input: {
    project_id: number;
    title: string;
    body?: string;
    status?: TaskStatus;
    priority?: TaskPriority;
    assignee?: string;
    due_date?: string | null;
    estimate?: number | null;
    parent_id?: number | null;
    cycle_id?: number | null;
  }) =>
    fetch('/api/tasks', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    }).then((r) => json<Task>(r)),
  updateTask: (
    id: number,
    patch: Partial<Pick<Task, 'title' | 'body' | 'status' | 'priority' | 'assignee' | 'due_date' | 'estimate' | 'parent_id' | 'cycle_id'>>,
  ) =>
    fetch(`/api/tasks/${id}`, {
      ...opts,
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => json<Task>(r)),
  deleteTask: (id: number) =>
    fetch(`/api/tasks/${id}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),
  bulkUpdate: (
    ids: number[],
    patch: Partial<{ status: TaskStatus; priority: TaskPriority; estimate: number | null; cycle_id: number | null; assignee: string }>,
  ) =>
    fetch('/api/tasks/bulk', {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids, patch }),
    }).then((r) => json<{ updated: number }>(r)),
  reorder: (projectId: number, status: TaskStatus, orderedIds: number[]) =>
    fetch(`/api/tasks/projects/${projectId}/reorder`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, ordered_ids: orderedIds }),
    }).then((r) => json<{ ok: boolean; n: number }>(r)),
  toggleReaction: (taskId: number, commentId: number, emoji: string) =>
    fetch(`/api/tasks/${taskId}/comments/${commentId}/reactions`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ emoji }),
    }).then((r) => json<{ toggled_off: boolean }>(r)),

  // ---- cycles + insights + views + templates ----
  listCycles: (projectId: number) => fetch(`/api/projects/${projectId}/cycles`, opts).then((r) => json<Cycle[]>(r)),
  createCycle: (projectId: number, input: { name?: string; start_date: string; end_date: string }) =>
    fetch(`/api/projects/${projectId}/cycles`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    }).then((r) => json<Cycle>(r)),
  deleteCycle: (projectId: number, cycleId: number) =>
    fetch(`/api/projects/${projectId}/cycles/${cycleId}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),
  getInsights: (projectId: number) => fetch(`/api/projects/${projectId}/insights`, opts).then((r) => json<ProjectInsights>(r)),
  listViews: (projectId: number) => fetch(`/api/projects/${projectId}/views`, opts).then((r) => json<SavedView[]>(r)),
  createView: (projectId: number, name: string, payload: Record<string, unknown>) =>
    fetch(`/api/projects/${projectId}/views`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, payload }),
    }).then((r) => json<SavedView>(r)),
  deleteView: (projectId: number, viewId: number) =>
    fetch(`/api/projects/${projectId}/views/${viewId}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),
  listTemplates: (projectId: number) => fetch(`/api/projects/${projectId}/templates`, opts).then((r) => json<Template[]>(r)),
  createTemplate: (projectId: number, input: Partial<Template> & { name: string; title: string }) =>
    fetch(`/api/projects/${projectId}/templates`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    }).then((r) => json<Template>(r)),
  deleteTemplate: (projectId: number, templateId: number) =>
    fetch(`/api/projects/${projectId}/templates/${templateId}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),

  // ---- labels (project-scoped) ----
  listLabels: (projectId: number) =>
    fetch(`/api/projects/${projectId}/labels`, opts).then((r) => json<Label[]>(r)),
  createLabel: (projectId: number, name: string, color: string) =>
    fetch(`/api/projects/${projectId}/labels`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, color }),
    }).then((r) => json<Label>(r)),
  attachLabel: (taskId: number, labelId: number) =>
    fetch(`/api/tasks/${taskId}/labels/${labelId}`, { ...opts, method: 'POST' }).then((r) => json<void>(r)),
  detachLabel: (taskId: number, labelId: number) =>
    fetch(`/api/tasks/${taskId}/labels/${labelId}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),

  // ---- subtasks ----
  createSubtask: (taskId: number, title: string) =>
    fetch(`/api/tasks/${taskId}/subtasks`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    }).then((r) => json<Subtask>(r)),
  updateSubtask: (taskId: number, subtaskId: number, patch: Partial<{ title: string; done: boolean }>) =>
    fetch(`/api/tasks/${taskId}/subtasks/${subtaskId}`, {
      ...opts,
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => json<Subtask>(r)),
  deleteSubtask: (taskId: number, subtaskId: number) =>
    fetch(`/api/tasks/${taskId}/subtasks/${subtaskId}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),

  // ---- comments ----
  addComment: (taskId: number, body: string) =>
    fetch(`/api/tasks/${taskId}/comments`, {
      ...opts,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ body }),
    }).then((r) => json<Comment>(r)),
  deleteComment: (taskId: number, commentId: number) =>
    fetch(`/api/tasks/${taskId}/comments/${commentId}`, { ...opts, method: 'DELETE' }).then((r) => json<void>(r)),

  agentInfo: () => fetch('/api/agent/info', opts).then((r) => json<AgentInfo>(r)),
  repoMap: () => fetch('/api/agent/repo-map', opts).then((r) => json<RepoMap>(r)),
};

export interface ChatStreamHandlers {
  onText?: (delta: string) => void;
  onThinking?: (delta: string) => void;
  onToolUse?: (b: { id: string; name: string; input: Record<string, unknown> }) => void;
  onToolResult?: (b: { id: string; name: string; content: string; is_error: boolean }) => void;
  onStarted?: (b: { provider: string; model: string }) => void;
  onUsage?: (u: { input_tokens?: number; output_tokens?: number; cache_read_input_tokens?: number; cache_creation_input_tokens?: number }) => void;
  onError?: (m: string) => void;
  onDone?: () => void;
}

export async function streamAgentChat(
  messages: ChatMessage[],
  handlers: ChatStreamHandlers,
  options: { signal?: AbortSignal; thinking?: boolean; effort?: 'low' | 'medium' | 'high' | 'xhigh' | 'max' } = {},
): Promise<void> {
  const resp = await fetch('/api/agent/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
    body: JSON.stringify({ messages, thinking: options.thinking, effort: options.effort }),
    signal: options.signal,
  });

  if (!resp.ok) {
    let detail: { error?: string; hint?: string } | null = null;
    try {
      detail = await resp.json();
    } catch {
      /* ignore */
    }
    handlers.onError?.(detail?.hint ?? detail?.error ?? `HTTP ${resp.status}`);
    handlers.onDone?.();
    return;
  }
  if (!resp.body) {
    handlers.onError?.('no response body');
    handlers.onDone?.();
    return;
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let pending = '';

  const dispatch = (event: string, dataStr: string) => {
    if (!dataStr) return;
    let data: Record<string, unknown> = {};
    try { data = JSON.parse(dataStr); } catch { return; }
    switch (event) {
      case 'started':       handlers.onStarted?.({ provider: String(data.provider ?? ''), model: String(data.model ?? '') }); break;
      case 'text_delta':    handlers.onText?.(String(data.text ?? '')); break;
      case 'thinking_delta':handlers.onThinking?.(String(data.text ?? '')); break;
      case 'tool_use':      handlers.onToolUse?.({ id: String(data.id ?? ''), name: String(data.name ?? ''), input: (data.input as Record<string, unknown>) ?? {} }); break;
      case 'tool_result':   handlers.onToolResult?.({ id: String(data.id ?? ''), name: String(data.name ?? ''), content: String(data.content ?? ''), is_error: Boolean(data.is_error) }); break;
      case 'usage':         handlers.onUsage?.(data as { input_tokens?: number; output_tokens?: number }); break;
      case 'error':         handlers.onError?.(String(data.message ?? 'unknown error')); break;
      case 'done':          handlers.onDone?.(); break;
    }
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    pending += decoder.decode(value, { stream: true });
    let sep: number;
    while ((sep = pending.indexOf('\n\n')) !== -1) {
      const frame = pending.slice(0, sep);
      pending = pending.slice(sep + 2);
      let event = 'message';
      let dataStr = '';
      for (const line of frame.split('\n')) {
        if (line.startsWith(':')) continue;
        if (line.startsWith('event:')) event = line.slice(6).trim();
        else if (line.startsWith('data:')) dataStr += (dataStr ? '\n' : '') + line.slice(5).trim();
      }
      dispatch(event, dataStr);
    }
  }
}
