// Linear-style inline title editor. When `editing` flips true, swaps the
// rendered title for a borderless <input>, autofocuses it, and selects the
// existing text. Enter / blur submit; Escape cancels.
//
// Submitting an unchanged or empty title is treated as a cancel — saves
// nothing, keeps the original. Submitting a real change calls onSubmit
// and lets the parent flip `editing` back off (and refresh the data).

import { useEffect, useRef, useState, type CSSProperties, type KeyboardEvent } from 'react';

interface Props {
  value: string;
  editing: boolean;
  onSubmit: (next: string) => void | Promise<void>;
  onCancel: () => void;
  /** Render the read-only form with this tag. Defaults to `strong`. */
  as?: 'strong' | 'span' | 'div';
  className?: string;
  style?: CSSProperties;
  /** Optional handler when the user double-clicks the title in read mode. */
  onActivate?: () => void;
}

export function EditableTitle({
  value,
  editing,
  onSubmit,
  onCancel,
  as = 'strong',
  className,
  style,
  onActivate,
}: Props): JSX.Element {
  const [draft, setDraft] = useState<string>(value);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Reset draft whenever we *enter* edit mode — guarantees the input always
  // starts from the canonical value, not whatever was left over from a
  // prior cancelled edit.
  useEffect(() => {
    if (editing) setDraft(value);
  }, [editing, value]);

  // Autofocus + select on mount of the edit input. Done in an effect so we
  // run after the DOM node is attached. Selecting the existing text gives
  // the same one-keystroke replace behavior Linear has.
  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  if (!editing) {
    const Tag = as;
    return (
      <Tag
        className={className}
        style={style}
        onDoubleClick={onActivate
          ? (e) => { e.stopPropagation(); onActivate(); }
          : undefined}
        title={onActivate ? 'Double-click to rename · `e` to edit' : undefined}
      >
        {value}
      </Tag>
    );
  }

  function commit(): void {
    const next = draft.trim();
    if (!next || next === value) { onCancel(); return; }
    void onSubmit(next);
  }
  function onKey(e: KeyboardEvent<HTMLInputElement>): void {
    if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); commit(); return; }
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); onCancel(); return; }
    // Don't let single-key hotkeys from the parent (s/p/x/c) fire while we
    // type a title that happens to contain those letters.
    e.stopPropagation();
  }

  return (
    <input
      ref={inputRef}
      className={`inline-title-edit ${className ?? ''}`}
      style={style}
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      onKeyDown={onKey}
      onBlur={commit}
      onClick={(e) => e.stopPropagation()}
      onDoubleClick={(e) => e.stopPropagation()}
      aria-label="Edit issue title"
    />
  );
}
