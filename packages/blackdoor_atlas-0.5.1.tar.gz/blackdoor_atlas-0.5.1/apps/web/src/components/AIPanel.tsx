// Slide-out AI panel that re-uses the same streaming agent backend. Pages
// pass an optional "context" string (project / task summary) which gets
// prepended to the user's prompt so the model knows what it's looking at.

import { type FormEvent, useEffect, useRef, useState } from 'react';
import {
  streamAgentChat,
  type AssistantBlock,
  type ChatMessage,
} from '../api.js';
import { ToolInspector, type ToolEvent } from './ToolInspector.js';

interface Props {
  contextLabel: string;       // shown in the header, e.g. "Project: Acme launch"
  contextPrompt: string;      // injected as a leading user-message system note
  suggestions?: string[];
}

// Same shape the inspector renders. AIPanel owns the array; inspector reads.
type ToolCard = ToolEvent;

interface Turn {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  thinking?: string;
  tools: ToolCard[];
  partial?: boolean;
}

export function AIPanel({ contextLabel, contextPrompt, suggestions = [] }: Props): JSX.Element {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  // Collapsed by default so the panel doesn't intercept clicks on board
  // controls (Add task, drag handles). The floating "✦ AI" button opens it.
  const [open, setOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns]);

  async function send(question: string): Promise<void> {
    if (!question.trim() || streaming) return;
    const userTurn: Turn = { id: id(), role: 'user', text: question.trim(), tools: [] };
    const assistantTurn: Turn = { id: id(), role: 'assistant', text: '', tools: [], partial: true };
    setTurns((prev) => [...prev, userTurn, assistantTurn]);
    setInput('');
    setStreaming(true);

    const priorWire = buildWireHistory(turns);
    const composed = `${contextPrompt}\n\nUser: ${question.trim()}`;
    const wire: ChatMessage[] = [...priorWire, { role: 'user', content: composed }];

    const controller = new AbortController();
    abortRef.current = controller;

    await streamAgentChat(
      wire,
      {
        onText: (delta) => setTurns((p) => withLast(p, (t) => ({ ...t, text: t.text + delta }))),
        onThinking: (delta) => setTurns((p) => withLast(p, (t) => ({ ...t, thinking: (t.thinking ?? '') + delta }))),
        onToolUse: (b) =>
          setTurns((p) => withLast(p, (t) => ({
            ...t,
            tools: [...t.tools, { id: b.id, name: b.name, input: b.input, started_at: Date.now() }],
          }))),
        onToolResult: (b) =>
          setTurns((p) =>
            withLast(p, (t) => ({
              ...t,
              tools: t.tools.map((c) => (c.id === b.id
                ? { ...c, result: b.content, is_error: b.is_error, ended_at: Date.now() }
                : c)),
            })),
          ),
        onError: (msg) => setTurns((p) => withLast(p, (t) => ({ ...t, text: t.text + `\n[error: ${msg}]` }))),
        onDone: () => {
          setTurns((p) => withLast(p, (t) => ({ ...t, partial: false })));
          setStreaming(false);
          abortRef.current = null;
        },
      },
      { signal: controller.signal },
    );
  }

  function submit(e: FormEvent<HTMLFormElement>): void {
    e.preventDefault();
    void send(input);
  }

  if (!open) {
    return (
      <button type="button" className="ai-fab" onClick={() => setOpen(true)} aria-label="Open AI assistant">
        ✦ AI
      </button>
    );
  }

  return (
    <aside className="ai-panel" aria-label="AI assistant">
      <header>
        <div>
          <strong>✦ AI assistant</strong>
          <div className="ai-context">{contextLabel}</div>
        </div>
        <button type="button" className="secondary small" onClick={() => setOpen(false)} aria-label="Collapse AI panel">
          ✕
        </button>
      </header>

      <div className="ai-body">
        {turns.length === 0 ? (
          <div className="ai-starters">
            <p className="muted">Ask about this project. The agent can read your files, search the repo, and run commands.</p>
            <ul>
              {suggestions.map((s) => (
                <li key={s}>
                  <button type="button" className="starter small" onClick={() => void send(s)}>{s}</button>
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        {turns.map((t) =>
          t.role === 'user' ? (
            <article key={t.id} className="bubble user small" aria-label="You">
              <pre>{t.text}</pre>
            </article>
          ) : (
            <article key={t.id} className="bubble assistant small" aria-label="Assistant">
              {t.thinking ? (
                <details className="thinking">
                  <summary>Thinking…</summary>
                  <pre>{t.thinking}</pre>
                </details>
              ) : null}
              {t.text ? <pre className="agent-text">{t.text}</pre> : null}
              <ToolInspector tools={t.tools} />
              {t.partial && !t.text && t.tools.length === 0 ? <p className="muted small">thinking…</p> : null}
            </article>
          ),
        )}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={submit} className="ai-composer">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={streaming ? 'streaming…' : 'Ask about this project'}
          rows={2}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              void send(input);
            }
          }}
          disabled={streaming}
        />
        {streaming ? (
          <button type="button" className="small" onClick={() => abortRef.current?.abort()}>Stop</button>
        ) : (
          <button type="submit" className="small" disabled={!input.trim()}>Send</button>
        )}
      </form>
    </aside>
  );
}

function buildWireHistory(turns: Turn[]): ChatMessage[] {
  const out: ChatMessage[] = [];
  for (const t of turns) {
    if (t.role === 'user') {
      out.push({ role: 'user', content: t.text });
      continue;
    }
    const blocks: AssistantBlock[] = [];
    if (t.text) blocks.push({ type: 'text', text: t.text });
    for (const tool of t.tools) {
      blocks.push({ type: 'tool_use', id: tool.id, name: tool.name, input: tool.input });
    }
    if (blocks.length) out.push({ role: 'assistant', content: blocks });
    for (const tool of t.tools) {
      if (tool.result !== undefined) {
        out.push({
          role: 'tool',
          tool_use_id: tool.id,
          content: tool.result,
          is_error: tool.is_error ?? false,
        });
      }
    }
  }
  return out;
}

function withLast(turns: Turn[], fn: (t: Turn) => Turn): Turn[] {
  if (turns.length === 0) return turns;
  const idx = turns.length - 1;
  const next = [...turns];
  next[idx] = fn(turns[idx]!);
  return next;
}

let counter = 0;
function id(): string {
  counter += 1;
  return `aiP${Date.now().toString(36)}_${counter}`;
}
