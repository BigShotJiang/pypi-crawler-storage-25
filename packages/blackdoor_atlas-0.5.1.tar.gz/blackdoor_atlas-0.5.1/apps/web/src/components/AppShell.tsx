// Persistent sidebar + topbar + content slot. The router renders children
// into <Outlet/>. The shell is responsible for the project list, Inbox link,
// new-project flow, keyboard shortcut hint, and the ⌘K command palette.

import { type ReactNode, useCallback, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api, type Company, type Project, type User } from '../api.js';
import { useHotkeys } from '../hooks/useHotkeys.js';
import { Icon } from './Icon.js';
import { CommandPalette } from './CommandPalette.js';
import { WorkspaceSwitcher } from './WorkspaceSwitcher.js';
import { WorkspaceManager } from './WorkspaceManager.js';

interface Props {
  user: User;
  onLogout: () => void;
}

export function AppShell({ user, onLogout }: Props): JSX.Element {
  const [projects, setProjects] = useState<Project[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [activeCompanyId, setActiveCompanyId] = useState<number | null>(null);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [inboxCount, setInboxCount] = useState<number>(0);
  const [workspaceManager, setWorkspaceManager] = useState<null | 'create' | 'manage'>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const params = useParams();

  const refreshWorkspaces = useCallback(async () => {
    try {
      const r = await api.listCompanies();
      setCompanies(r.companies);
      setActiveCompanyId(r.active_company_id);
    } catch {
      setCompanies([]);
      setActiveCompanyId(null);
    }
  }, []);

  const refresh = useCallback(async () => {
    try {
      const ps = await api.listProjects();
      setProjects(ps);
    } catch {
      setProjects([]);
    }
    try {
      const inbox = await api.inbox();
      setInboxCount(inbox.open.length);
    } catch {
      setInboxCount(0);
    }
  }, []);

  useEffect(() => {
    void refreshWorkspaces();
  }, [refreshWorkspaces]);

  useEffect(() => {
    void refresh();
  }, [refresh, location.pathname, activeCompanyId]);

  // When the user switches workspace, navigate to inbox so the project
  // route param (a project id from the old workspace) doesn't 404.
  const onWorkspaceSwitched = useCallback(async () => {
    await refreshWorkspaces();
    await refresh();
    navigate('/inbox');
  }, [refreshWorkspaces, refresh, navigate]);

  // Global keyboard shortcuts — Linear-style chords for jumping between
  // views plus ⌘K for the command palette.
  useHotkeys({
    'k': { handler: () => setPaletteOpen((v) => !v), allowMod: true, allowInField: true },
    'Escape': { handler: () => setPaletteOpen(false), allowInField: true },
    'g i': () => navigate('/inbox'),
    'g a': () => navigate('/agent'),
    '?': () => setPaletteOpen(true),
  });

  async function createProject(): Promise<void> {
    if (!newName.trim()) return;
    const p = await api.createProject({ name: newName.trim() });
    setNewName('');
    setCreating(false);
    await refresh();
    navigate(`/projects/${p.id}`);
  }

  const activeProjectId = params.id ? Number(params.id) : null;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <WorkspaceSwitcher
          companies={companies}
          active={companies.find((c) => c.is_active) ?? null}
          onSwitched={() => void onWorkspaceSwitched()}
          onOpenCreate={() => setWorkspaceManager('create')}
          onOpenManage={() => setWorkspaceManager('manage')}
        />

        <NavLink to="/inbox" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <Icon name="inbox" />
          <span className="label">Inbox</span>
          {inboxCount > 0 ? <span className="count">{inboxCount}</span> : null}
        </NavLink>

        <NavLink to="/agent" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <Icon name="sparkle" />
          <span className="label">AI Agent</span>
        </NavLink>

        <div className="section">
          <span>Projects</span>
          <button
            type="button"
            className="icon ghost"
            onClick={() => setCreating((v) => !v)}
            title="New project"
            aria-label="New project"
          >
            <Icon name="plus" />
          </button>
        </div>

        {projects.map((p) => (
          <Link
            to={`/projects/${p.id}`}
            key={p.id}
            className={`nav-link ${activeProjectId === p.id ? 'active' : ''}`}
          >
            <span className="project-swatch" style={{ background: p.color }} aria-hidden />
            <span className="label">{p.name}</span>
            {p.task_count ? <span className="count">{p.task_count}</span> : null}
          </Link>
        ))}

        {creating ? (
          <form
            className="new-project"
            onSubmit={(e) => { e.preventDefault(); void createProject(); }}
            style={{ display: 'flex', gap: '0.3rem' }}
          >
            <input
              aria-label="Project name"
              autoFocus
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Project name"
              onKeyDown={(e) => { if (e.key === 'Escape') { setCreating(false); setNewName(''); } }}
              style={{ background: 'var(--surface)' }}
            />
          </form>
        ) : null}

        <div className="footer">
          <span>{user.email}</span>
          <button type="button" className="icon ghost" onClick={onLogout} title="Log out" aria-label="Log out">
            <Icon name="logout" />
          </button>
        </div>
      </aside>

      <div className="workspace">
        <TopBar onOpenPalette={() => setPaletteOpen(true)} />
        <main className="content">
          <Outlet />
        </main>
      </div>

      {paletteOpen ? (
        <CommandPalette
          projects={projects}
          onClose={() => setPaletteOpen(false)}
          onGoto={(path) => { setPaletteOpen(false); navigate(path); }}
        />
      ) : null}

      {workspaceManager ? (
        <WorkspaceManager
          initialMode={workspaceManager}
          companies={companies}
          onClose={() => setWorkspaceManager(null)}
          onChanged={() => { void refreshWorkspaces(); }}
        />
      ) : null}
    </div>
  );
}

function TopBar({ onOpenPalette }: { onOpenPalette: () => void }): ReactNode {
  return (
    <header className="topbar">
      <div className="breadcrumb"><Breadcrumb /></div>
      <div className="spacer" />
      <button type="button" className="ghost small" onClick={onOpenPalette}>
        <Icon name="search" size={14} />
        <span>Search</span>
        <span className="kbd">⌘K</span>
      </button>
    </header>
  );
}

function Breadcrumb(): JSX.Element {
  const loc = useLocation();
  if (loc.pathname === '/inbox' || loc.pathname === '/') return <span><strong>Inbox</strong></span>;
  if (loc.pathname.startsWith('/projects/')) return <span>Projects <Icon name="chevron-right" size={12} /> <strong>—</strong></span>;
  if (loc.pathname === '/agent') return <span><strong>AI Agent</strong></span>;
  if (loc.pathname === '/settings') return <span><strong>Settings</strong></span>;
  return <span>{loc.pathname}</span>;
}
