// ⌘K palette — fuzzy match against a flat command list. Adds:
//   - jump to Inbox / AI agent / Settings
//   - open each project by name
//   - "Create task in <project>" entries
//   - "New project" action (no inline form; sidebar handles that)

import { useEffect, useMemo, useRef, useState } from 'react';
import type { Project } from '../api.js';
import { Icon, type IconName } from './Icon.js';

interface Cmd {
  id: string;
  label: string;
  meta?: string;
  icon: IconName;
  run: () => void;
}

interface Props {
  projects: Project[];
  onClose: () => void;
  onGoto: (path: string) => void;
}

export function CommandPalette({ projects, onClose, onGoto }: Props): JSX.Element {
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const commands: Cmd[] = useMemo(() => {
    const base: Cmd[] = [
      { id: 'go-inbox', label: 'Go to Inbox', icon: 'inbox', meta: 'Navigation', run: () => onGoto('/inbox') },
      { id: 'go-agent', label: 'Open AI agent', icon: 'sparkle', meta: 'Navigation', run: () => onGoto('/agent') },
    ];
    for (const p of projects) {
      base.push({
        id: `proj-${p.id}`,
        label: `Go to ${p.name}`,
        icon: 'folder',
        meta: p.key || 'Project',
        run: () => onGoto(`/projects/${p.id}`),
      });
    }
    return base;
  }, [projects, onGoto]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return commands;
    return commands.filter((c) => c.label.toLowerCase().includes(needle) || (c.meta?.toLowerCase().includes(needle) ?? false));
  }, [commands, q]);

  useEffect(() => {
    setActive(0);
  }, [q]);

  function handleKey(e: React.KeyboardEvent<HTMLDivElement>): void {
    if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActive((v) => Math.min(v + 1, Math.max(filtered.length - 1, 0)));
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((v) => Math.max(v - 1, 0));
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      const sel = filtered[active];
      if (sel) {
        sel.run();
      }
    }
  }

  return (
    <div className="palette-backdrop" onMouseDown={onClose} role="dialog" aria-label="Command palette">
      <div className="palette" onMouseDown={(e) => e.stopPropagation()} onKeyDown={handleKey}>
        <input
          ref={inputRef}
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Type a command or project name…"
          aria-label="Command palette search"
        />
        <ul role="listbox">
          {filtered.length === 0 ? (
            <li className="muted">No commands match.</li>
          ) : (
            filtered.map((c, i) => (
              <li
                key={c.id}
                className={i === active ? 'active' : ''}
                onMouseEnter={() => setActive(i)}
                onClick={() => c.run()}
                role="option"
                aria-selected={i === active}
              >
                <Icon name={c.icon} size={14} />
                <span>{c.label}</span>
                {c.meta ? <span className="meta">{c.meta}</span> : null}
              </li>
            ))
          )}
        </ul>
      </div>
    </div>
  );
}
