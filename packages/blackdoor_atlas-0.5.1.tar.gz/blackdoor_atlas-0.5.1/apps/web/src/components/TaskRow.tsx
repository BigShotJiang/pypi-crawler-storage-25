// One row in a Linear-style task list. Renders status, key, title, labels,
// sub-issue progress, estimate, assignee, due, priority. Status + priority
// are click-to-cycle. Supports multi-select via `selected` + `onToggleSelect`.

import { type MouseEvent, useState } from 'react';
import { api, STATUSES, type Task, type TaskPriority, type TaskStatus } from '../api.js';
import { EstimateBadge, PriorityIcon, StatusIcon } from './Icon.js';

interface Props {
  task: Task;
  onOpen: () => void;
  onChanged: () => void;
  selected?: boolean;
  onToggleSelect?: (taskId: number, mode: 'single' | 'toggle' | 'range') => void;
}

const NEXT_STATUS: Record<TaskStatus, TaskStatus> = {
  backlog: 'todo',
  todo: 'started',
  started: 'review',
  review: 'done',
  done: 'backlog',
  cancelled: 'backlog',
};

const NEXT_PRIORITY: Record<TaskPriority, TaskPriority> = {
  low: 'med',
  med: 'high',
  high: 'urgent',
  urgent: 'low',
};

export function TaskRow({ task, onOpen, onChanged, selected, onToggleSelect }: Props): JSX.Element {
  const [status, setStatus] = useState<TaskStatus>(task.status);
  const [priority, setPriority] = useState<TaskPriority>(task.priority);

  async function updateStatus(next: TaskStatus): Promise<void> {
    setStatus(next);
    try { await api.updateTask(task.id, { status: next }); onChanged(); }
    catch { setStatus(task.status); }
  }
  async function updatePriority(next: TaskPriority): Promise<void> {
    setPriority(next);
    try { await api.updateTask(task.id, { priority: next }); onChanged(); }
    catch { setPriority(task.priority); }
  }

  function rowClick(e: MouseEvent<HTMLLIElement>): void {
    if ((e.metaKey || e.ctrlKey) && onToggleSelect) { onToggleSelect(task.id, 'toggle'); return; }
    if (e.shiftKey && onToggleSelect) { onToggleSelect(task.id, 'range'); return; }
    onOpen();
  }

  const safeStatus = (STATUSES as string[]).includes(status) ? status : 'todo';

  return (
    <li className={`task-row ${selected ? 'selected' : ''}`} onClick={rowClick}>
      <span
        onClick={(e) => { e.stopPropagation(); updateStatus(NEXT_STATUS[safeStatus as TaskStatus]); }}
        title={`Status: ${safeStatus} — click to cycle`}
        style={{ display: 'inline-flex' }}
      >
        <StatusIcon status={safeStatus} />
      </span>

      <span className="key">{task.key ?? `#${task.id}`}</span>

      <div className="title-cell">
        <strong>{task.title}</strong>
        {task.labels.map((l) => (
          <span key={l.id} className="label-chip" title={l.name}>
            <span className="dot" style={{ background: l.color }} />
            {l.name}
          </span>
        ))}
        {task.children.length > 0 ? (
          <span className="label-chip" title="Sub-issues">
            ↳ {task.children.filter((c) => c.status === 'done').length}/{task.children.length}
          </span>
        ) : null}
        <EstimateBadge value={task.estimate} />
      </div>

      <span className="meta">{task.assignee || ''}</span>

      <span className="meta">{task.due_date ? formatDue(task.due_date) : ''}</span>

      <span
        onClick={(e) => { e.stopPropagation(); updatePriority(NEXT_PRIORITY[priority]); }}
        title={`Priority: ${priority} — click to cycle`}
      >
        <span className={`priority-pill p-${priority}`}>
          <PriorityIcon priority={priority} />
        </span>
      </span>
    </li>
  );
}

function formatDue(iso: string): string {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  } catch {
    return iso;
  }
}
