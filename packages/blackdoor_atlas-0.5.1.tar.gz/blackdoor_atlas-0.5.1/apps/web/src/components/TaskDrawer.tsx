// Right-slide drawer that opens on task/issue click. Renders the full issue:
// title (inline edit), description (markdown rendered when not editing),
// status / priority / estimate / assignee / due / labels / cycle / parent
// controls, sub-issues list, subtasks checklist, comments thread with
// reactions, and an activity timeline.

import { type FormEvent, type KeyboardEvent, useCallback, useEffect, useRef, useState } from 'react';
import {
  api,
  ESTIMATES,
  PRIORITIES,
  STATUSES,
  type Comment,
  type Cycle,
  type Label,
  type Subtask,
  type Task,
  type TaskDetail,
  type TaskPriority,
  type TaskStatus,
} from '../api.js';
import { EstimateBadge, Icon, PriorityIcon, StatusIcon } from './Icon.js';
import { Markdown } from './Markdown.js';

interface Props {
  taskId: number;
  projectLabels?: Label[];
  projectCycles?: Cycle[];
  projectTasks?: Task[];   // for parent picker
  onClose: () => void;
  onChanged: () => void;
}

const STATUS_LABEL: Record<TaskStatus, string> = {
  backlog: 'Backlog', todo: 'Todo', started: 'In progress', review: 'In review', done: 'Done', cancelled: 'Cancelled',
};
const PRIORITY_LABEL: Record<TaskPriority, string> = { urgent: 'Urgent', high: 'High', med: 'Medium', low: 'Low' };
const REACTION_EMOJI = ['👍', '❤️', '🚀', '👀', '🎉', '😂', '🙏', '🔥'];

export function TaskDrawer(props: Props): JSX.Element {
  const { taskId, projectLabels, projectCycles, projectTasks, onClose, onChanged } = props;
  const [task, setTask] = useState<TaskDetail | null>(null);
  const [savingTitle, setSavingTitle] = useState(false);
  const [labels, setLabels] = useState<Label[]>(projectLabels ?? []);
  const [labelOpen, setLabelOpen] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [newSubtask, setNewSubtask] = useState('');
  const [editingBody, setEditingBody] = useState(false);
  const [openReactionPicker, setOpenReactionPicker] = useState<number | null>(null);
  const titleRef = useRef<HTMLTextAreaElement>(null);
  const bodyRef = useRef<HTMLTextAreaElement>(null);

  const refresh = useCallback(async () => {
    try {
      const t = await api.getTask(taskId);
      setTask(t);
      if (!projectLabels) {
        try { setLabels(await api.listLabels(t.project_id)); } catch { /* ignore */ }
      }
    } catch {
      onClose();
    }
  }, [taskId, projectLabels, onClose]);

  useEffect(() => { void refresh(); }, [refresh]);

  useEffect(() => {
    function onKey(e: globalThis.KeyboardEvent): void {
      if (e.key === 'Escape') {
        if (labelOpen) { setLabelOpen(false); return; }
        if (openReactionPicker != null) { setOpenReactionPicker(null); return; }
        onClose();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, labelOpen, openReactionPicker]);

  if (!task) {
    return (
      <>
        <div className="drawer-backdrop" onClick={onClose} />
        <aside className="drawer" aria-label="Loading task">
          <header>
            <button type="button" className="icon ghost" onClick={onClose}><Icon name="x" /></button>
            <span className="muted">Loading…</span>
          </header>
          <div className="body">
            <div className="skeleton" style={{ width: '70%', height: 26, marginBottom: 12 }} />
            <div className="skeleton" style={{ width: '100%', height: 14, marginBottom: 8 }} />
            <div className="skeleton" style={{ width: '90%', height: 14, marginBottom: 8 }} />
          </div>
        </aside>
      </>
    );
  }

  async function patch(p: Partial<{ title: string; body: string; status: TaskStatus; priority: TaskPriority; assignee: string; due_date: string | null; estimate: number | null; parent_id: number | null; cycle_id: number | null }>): Promise<void> {
    if (!task) return;
    try {
      await api.updateTask(task.id, p);
      await refresh();
      onChanged();
    } catch { /* leave UI as-is */ }
  }

  async function saveTitle(): Promise<void> {
    if (!task) return;
    const next = titleRef.current?.value ?? '';
    if (next.trim() && next !== task.title) {
      setSavingTitle(true);
      await patch({ title: next });
      setSavingTitle(false);
    }
  }

  async function saveBody(): Promise<void> {
    if (!task) return;
    const next = bodyRef.current?.value ?? '';
    if (next !== task.body) await patch({ body: next });
    setEditingBody(false);
  }

  async function toggleSubtask(s: Subtask): Promise<void> {
    if (!task) return;
    await api.updateSubtask(task.id, s.id, { done: s.done === 0 });
    await refresh();
    onChanged();
  }

  async function addSubtask(): Promise<void> {
    if (!task || !newSubtask.trim()) return;
    await api.createSubtask(task.id, newSubtask.trim());
    setNewSubtask('');
    await refresh();
    onChanged();
  }

  async function removeSubtask(s: Subtask): Promise<void> {
    if (!task) return;
    await api.deleteSubtask(task.id, s.id);
    await refresh();
    onChanged();
  }

  async function addComment(): Promise<void> {
    if (!task || !newComment.trim()) return;
    await api.addComment(task.id, newComment.trim());
    setNewComment('');
    await refresh();
  }

  async function deleteComment(c: Comment): Promise<void> {
    if (!task) return;
    await api.deleteComment(task.id, c.id);
    await refresh();
  }

  async function toggleReaction(c: Comment, emoji: string): Promise<void> {
    if (!task) return;
    await api.toggleReaction(task.id, c.id, emoji);
    setOpenReactionPicker(null);
    await refresh();
  }

  async function toggleLabel(l: Label): Promise<void> {
    if (!task) return;
    const has = task.labels.some((x) => x.id === l.id);
    if (has) await api.detachLabel(task.id, l.id);
    else await api.attachLabel(task.id, l.id);
    await refresh();
    onChanged();
  }

  async function createAndAttachLabel(name: string): Promise<void> {
    if (!task || !name.trim()) return;
    const palette = ['#5e6ad2', '#f59e0b', '#10b981', '#ef4444', '#9b8cff', '#0ea5e9', '#f43f5e'];
    const color = palette[Math.floor(Math.random() * palette.length)]!;
    try {
      const l = await api.createLabel(task.project_id, name.trim(), color);
      await api.attachLabel(task.id, l.id);
      setLabels(await api.listLabels(task.project_id));
      await refresh();
      onChanged();
    } catch { /* dup name */ }
  }

  const parentTask = task.parent_id != null
    ? projectTasks?.find((t) => t.id === task.parent_id) ?? null
    : null;

  const candidateParents = (projectTasks ?? []).filter(
    (t) => t.id !== task.id && t.parent_id !== task.id,   // avoid cycles
  );

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <aside className="drawer" aria-label={`Issue ${task.key} ${task.title}`}>
        <header>
          <button type="button" className="icon ghost" onClick={onClose} aria-label="Close"><Icon name="x" /></button>
          {parentTask ? (
            <span className="muted xsmall" title={parentTask.title}>
              {parentTask.key} <Icon name="chevron-right" size={10} />
            </span>
          ) : null}
          <span className="key">{task.key ?? `#${task.id}`}</span>
          <span className="spacer" />
          <span className="muted xsmall">{savingTitle ? 'Saving…' : 'Saved'}</span>
        </header>

        <div className="body">
          <textarea
            ref={titleRef}
            defaultValue={task.title}
            className="title-input"
            rows={1}
            onBlur={saveTitle}
            onKeyDown={(e: KeyboardEvent<HTMLTextAreaElement>) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                (e.target as HTMLTextAreaElement).blur();
              }
            }}
            aria-label="Title"
          />

          <div className="props">
            <span className="lbl">Status</span>
            <select value={task.status} onChange={(e) => patch({ status: e.target.value as TaskStatus })} aria-label="Status">
              {STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
            </select>

            <span className="lbl">Priority</span>
            <select value={task.priority} onChange={(e) => patch({ priority: e.target.value as TaskPriority })} aria-label="Priority">
              {PRIORITIES.map((p) => <option key={p} value={p}>{PRIORITY_LABEL[p]}</option>)}
            </select>

            <span className="lbl">Estimate</span>
            <select
              value={task.estimate ?? ''}
              onChange={(e) => patch({ estimate: e.target.value === '' ? null : Number(e.target.value) })}
              aria-label="Estimate"
            >
              <option value="">No estimate</option>
              {ESTIMATES.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>

            <span className="lbl">Assignee</span>
            <input
              defaultValue={task.assignee}
              onBlur={(e) => patch({ assignee: e.target.value })}
              placeholder="Unassigned"
              aria-label="Assignee"
            />

            <span className="lbl">Due</span>
            <input
              type="date"
              defaultValue={task.due_date ?? ''}
              onBlur={(e) => patch({ due_date: e.target.value || null })}
              aria-label="Due date"
            />

            {projectCycles && projectCycles.length > 0 ? (
              <>
                <span className="lbl">Cycle</span>
                <select
                  value={task.cycle_id ?? ''}
                  onChange={(e) => patch({ cycle_id: e.target.value === '' ? null : Number(e.target.value) })}
                  aria-label="Cycle"
                >
                  <option value="">None</option>
                  {projectCycles.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.status === 'active' ? '★ ' : ''}Cycle {c.number}{c.name ? `: ${c.name}` : ''}
                    </option>
                  ))}
                </select>
              </>
            ) : null}

            {projectTasks && projectTasks.length > 1 ? (
              <>
                <span className="lbl">Parent</span>
                <select
                  value={task.parent_id ?? ''}
                  onChange={(e) => patch({ parent_id: e.target.value === '' ? null : Number(e.target.value) })}
                  aria-label="Parent issue"
                >
                  <option value="">None</option>
                  {candidateParents.map((t) => (
                    <option key={t.id} value={t.id}>{t.key} {t.title}</option>
                  ))}
                </select>
              </>
            ) : null}

            <span className="lbl">Labels</span>
            <LabelEditor
              value={task.labels}
              all={labels}
              open={labelOpen}
              onOpen={() => setLabelOpen(true)}
              onClose={() => setLabelOpen(false)}
              onToggle={toggleLabel}
              onCreate={createAndAttachLabel}
            />
          </div>

          <div className="subsection">
            <h3>Description</h3>
            {editingBody ? (
              <textarea
                ref={bodyRef}
                defaultValue={task.body}
                className="desc-input"
                placeholder="Add description, context, or links… (Markdown supported)"
                onBlur={saveBody}
                autoFocus
                aria-label="Description"
              />
            ) : task.body.trim() ? (
              <div onClick={() => setEditingBody(true)} style={{ cursor: 'text' }}>
                <Markdown source={task.body} />
              </div>
            ) : (
              <div className="muted" onClick={() => setEditingBody(true)} style={{ cursor: 'text', fontSize: 'var(--text-sm)', padding: '0.4rem 0' }}>
                Add a description… (Markdown supported)
              </div>
            )}
          </div>

          {task.children.length > 0 ? (
            <div className="subsection">
              <h3>Sub-issues ({task.children.filter((c) => c.status === 'done').length}/{task.children.length})</h3>
              <ul className="sub-issues">
                {task.children.map((c) => (
                  <li key={c.id}>
                    <StatusIcon status={c.status} size={14} />
                    <span className="key">{task.project_key}-{c.task_number}</span>
                    <span>{c.title}</span>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
                      <EstimateBadge value={c.estimate} />
                      <span className={`priority-pill p-${c.priority}`}><PriorityIcon priority={c.priority as TaskPriority} /></span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="subsection">
            <h3>Subtasks {task.subtasks.length > 0 ? `(${task.subtasks.filter((s) => s.done).length}/${task.subtasks.length})` : ''}</h3>
            {task.subtasks.map((s) => (
              <div key={s.id} className={`subtask-row ${s.done ? 'done' : ''}`}>
                <button type="button" className="check" onClick={() => void toggleSubtask(s)} aria-label={s.done ? 'Mark not done' : 'Mark done'}>
                  <Icon name="check" size={11} />
                </button>
                <input
                  type="text"
                  defaultValue={s.title}
                  onBlur={(e) => {
                    if (e.target.value !== s.title) {
                      void api.updateSubtask(task.id, s.id, { title: e.target.value }).then(refresh);
                    }
                  }}
                />
                <span style={{ flex: 1 }} />
                <button type="button" className="icon ghost del" onClick={() => void removeSubtask(s)} aria-label="Delete subtask">
                  <Icon name="x" size={12} />
                </button>
              </div>
            ))}
            <form className="subtask-add" onSubmit={(e: FormEvent) => { e.preventDefault(); void addSubtask(); }}>
              <span style={{ width: 16 }} />
              <input type="text" placeholder="+ Add subtask" value={newSubtask} onChange={(e) => setNewSubtask(e.target.value)} />
            </form>
          </div>

          <div className="subsection comments">
            <h3>Comments</h3>
            {task.comments.map((c) => (
              <div className="comment" key={c.id}>
                <header>
                  <strong>{c.author}</strong>
                  <span>{relativeTime(c.created_at)}</span>
                  <span style={{ flex: 1 }} />
                  <button
                    type="button"
                    className="reaction add"
                    onClick={() => setOpenReactionPicker(openReactionPicker === c.id ? null : c.id)}
                    aria-label="Add reaction"
                  >
                    <Icon name="plus" size={10} />
                  </button>
                  <button type="button" className="icon ghost" onClick={() => void deleteComment(c)} aria-label="Delete comment">
                    <Icon name="x" size={12} />
                  </button>
                </header>
                <div className="body"><Markdown source={c.body} /></div>
                <div className="reactions">
                  {Object.entries(c.reactions ?? {}).map(([emoji, info]) => (
                    <button
                      type="button"
                      key={emoji}
                      className={`reaction ${info.mine ? 'mine' : ''}`}
                      onClick={() => void toggleReaction(c, emoji)}
                      title={info.authors.map((a) => a.split('@')[0]).join(', ')}
                    >
                      <span className="emoji">{emoji}</span>
                      <span>{info.count}</span>
                    </button>
                  ))}
                </div>
                {openReactionPicker === c.id ? (
                  <div className="reactions" style={{ marginTop: 4 }}>
                    {REACTION_EMOJI.map((e) => (
                      <button type="button" key={e} className="reaction" onClick={() => void toggleReaction(c, e)}>
                        <span className="emoji">{e}</span>
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
            ))}
            <form className="composer" onSubmit={(e: FormEvent) => { e.preventDefault(); void addComment(); }}>
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Leave a comment… (Markdown supported, ⌘↩ to submit)"
                rows={2}
                onKeyDown={(e: KeyboardEvent<HTMLTextAreaElement>) => {
                  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                    e.preventDefault();
                    void addComment();
                  }
                }}
              />
              <button type="submit" disabled={!newComment.trim()}>Comment</button>
            </form>
          </div>

          <div className="subsection">
            <h3>Activity</h3>
            <ul className="activity-log">
              {task.activity.length === 0 ? (
                <li className="muted">No activity yet.</li>
              ) : task.activity.map((a) => (
                <li key={a.id}>
                  <span className="at">{relativeTime(a.created_at)}</span>
                  <span>{describeActivity(a.kind, a.payload, a.actor)}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </aside>
    </>
  );
}

interface LabelEditorProps {
  value: Label[];
  all: Label[];
  open: boolean;
  onOpen: () => void;
  onClose: () => void;
  onToggle: (l: Label) => void;
  onCreate: (name: string) => void;
}

function LabelEditor({ value, all, open, onOpen, onClose, onToggle, onCreate }: LabelEditorProps): JSX.Element {
  const [filter, setFilter] = useState('');
  return (
    <div className="label-picker">
      <button type="button" className="ghost small" onClick={open ? onClose : onOpen}>
        {value.length > 0 ? value.map((l) => (
          <span key={l.id} className="label-chip"><span className="dot" style={{ background: l.color }} />{l.name}</span>
        )) : <span className="muted">+ Add labels</span>}
      </button>
      {open ? (
        <div className="menu" role="menu">
          <input
            type="search"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Find or create…"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                const trimmed = filter.trim();
                if (!trimmed) return;
                const exact = all.find((l) => l.name.toLowerCase() === trimmed.toLowerCase());
                if (exact) onToggle(exact);
                else onCreate(trimmed);
                setFilter('');
              }
            }}
          />
          {all
            .filter((l) => l.name.toLowerCase().includes(filter.toLowerCase()))
            .map((l) => {
              const checked = value.some((v) => v.id === l.id);
              return (
                <div key={l.id} className="row" onClick={() => onToggle(l)}>
                  <span style={{ width: 12, display: 'inline-flex' }}>
                    {checked ? <Icon name="check" size={12} /> : null}
                  </span>
                  <span className="label-chip"><span className="dot" style={{ background: l.color }} />{l.name}</span>
                </div>
              );
            })}
          {filter.trim() && !all.some((l) => l.name.toLowerCase() === filter.trim().toLowerCase()) ? (
            <div className="row" onClick={() => { onCreate(filter.trim()); setFilter(''); }}>
              <Icon name="plus" size={12} />
              <span>Create label "<strong>{filter.trim()}</strong>"</span>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function relativeTime(iso: string): string {
  try {
    const safe = iso.replace(' ', 'T') + (iso.includes('Z') || iso.includes('+') ? '' : 'Z');
    const t = new Date(safe).getTime();
    if (Number.isNaN(t)) return iso;
    const secs = Math.max(0, Math.floor((Date.now() - t) / 1000));
    if (secs < 60) return 'just now';
    if (secs < 3600) return `${Math.floor(secs / 60)}m ago`;
    if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`;
    if (secs < 86400 * 7) return `${Math.floor(secs / 86400)}d ago`;
    return new Date(safe).toLocaleDateString();
  } catch {
    return iso;
  }
}

function describeActivity(kind: string, payload: Record<string, unknown>, actor: string): string {
  const who = actor ? actor.split('@')[0] : 'someone';
  switch (kind) {
    case 'created': return `${who} created the issue`;
    case 'status_changed': return `${who} moved to ${payload.to}`;
    case 'priority_changed': return `${who} set priority to ${payload.to}`;
    case 'title_changed': return `${who} renamed`;
    case 'estimate_changed': return `${who} set estimate to ${payload.to ?? 'none'}`;
    case 'cycle_changed': return `${who} ${payload.to ? `moved to cycle ${payload.to}` : 'removed from cycle'}`;
    case 'commented': return `${who} commented`;
    case 'label_added': return `${who} added label ${payload.label}`;
    case 'label_removed': return `${who} removed a label`;
    case 'subtask_added': return `${who} added subtask "${payload.title}"`;
    case 'subtask_toggled': return `${who} ${payload.done ? 'completed' : 'reopened'} a subtask`;
    default: return `${who} ${kind}`;
  }
}
