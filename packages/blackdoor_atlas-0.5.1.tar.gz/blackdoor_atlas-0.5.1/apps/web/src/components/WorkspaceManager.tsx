// Modal for managing workspaces. Two modes:
//   - 'create' — single-screen new-workspace form
//   - 'manage' — list of the user's workspaces with rename / recolor /
//                delete affordances per row, plus a "create another" CTA
//
// All mutations go through /api/companies and are persisted to SQLite.

import { useEffect, useState } from 'react';
import { api, type Company } from '../api.js';
import { Icon } from './Icon.js';

const PALETTE = [
  '#5e6ad2', '#22c55e', '#f59e0b', '#ef4444',
  '#0ea5e9', '#a855f7', '#10b981', '#ec4899',
];

interface Props {
  initialMode: 'create' | 'manage';
  companies: Company[];
  onClose: () => void;
  onChanged: () => void;
}

export function WorkspaceManager({ initialMode, companies, onClose, onChanged }: Props): JSX.Element {
  const [mode, setMode] = useState<'create' | 'manage'>(initialMode);

  useEffect(() => {
    function onKey(e: KeyboardEvent): void { if (e.key === 'Escape') onClose(); }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onClick={onClose} role="presentation">
      <div className="modal workspace-modal" onClick={(e) => e.stopPropagation()}>
        <header className="modal-header">
          <h3>{mode === 'create' ? 'New workspace' : 'Manage workspaces'}</h3>
          <button type="button" className="icon ghost" onClick={onClose} aria-label="Close">
            <Icon name="x" size={14} />
          </button>
        </header>

        {mode === 'create' ? (
          <CreateForm
            onCancel={() => companies.length > 0 ? setMode('manage') : onClose()}
            onCreated={() => { onChanged(); setMode('manage'); }}
          />
        ) : (
          <ManageList
            companies={companies}
            onChanged={onChanged}
            onCreate={() => setMode('create')}
          />
        )}
      </div>
    </div>
  );
}

function CreateForm({ onCancel, onCreated }: { onCancel: () => void; onCreated: () => void }): JSX.Element {
  const [name, setName] = useState('');
  const [color, setColor] = useState(PALETTE[0]!);
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent): Promise<void> {
    e.preventDefault();
    if (!name.trim()) { setError('Name is required.'); return; }
    setBusy(true);
    setError(null);
    try {
      await api.createCompany({ name: name.trim(), color, description: description.trim() });
      onCreated();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={(e) => void submit(e)} className="workspace-form">
      <label>
        <span className="form-label">Name</span>
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Acme Inc."
          maxLength={60}
        />
      </label>
      <label>
        <span className="form-label">Color</span>
        <div className="color-picker">
          {PALETTE.map((c) => (
            <button
              key={c}
              type="button"
              className={`color-swatch ${color === c ? 'selected' : ''}`}
              style={{ background: c }}
              onClick={() => setColor(c)}
              aria-label={`Pick ${c}`}
            />
          ))}
        </div>
      </label>
      <label>
        <span className="form-label">Description (optional)</span>
        <textarea
          rows={2}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Short context — what is this workspace for?"
          maxLength={280}
        />
      </label>
      {error ? <div className="form-error">{error}</div> : null}
      <div className="modal-actions">
        <button type="button" className="ghost" onClick={onCancel} disabled={busy}>Cancel</button>
        <button type="submit" className="primary" disabled={busy || !name.trim()}>
          {busy ? 'Creating…' : 'Create workspace'}
        </button>
      </div>
    </form>
  );
}

function ManageList({ companies, onChanged, onCreate }: { companies: Company[]; onChanged: () => void; onCreate: () => void }): JSX.Element {
  return (
    <div className="workspace-list">
      {companies.map((c) => (
        <ManageRow key={c.id} company={c} onChanged={onChanged} canDelete={companies.length > 1 && c.role === 'owner'} />
      ))}
      <button type="button" className="ghost workspace-add" onClick={onCreate}>
        <Icon name="plus" size={14} /> New workspace
      </button>
    </div>
  );
}

function ManageRow({ company, onChanged, canDelete }: { company: Company; onChanged: () => void; canDelete: boolean }): JSX.Element {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(company.name);
  const [color, setColor] = useState(company.color);
  const [busy, setBusy] = useState(false);

  async function save(): Promise<void> {
    setBusy(true);
    try {
      await api.updateCompany(company.id, {
        name: name.trim() || company.name,
        color,
      });
      onChanged();
      setEditing(false);
    } catch (err) {
      alert((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function remove(): Promise<void> {
    if (!confirm(`Delete "${company.name}"? Its projects and issues will be removed.`)) return;
    setBusy(true);
    try {
      await api.deleteCompany(company.id);
      onChanged();
    } catch (err) {
      alert((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (!editing) {
    return (
      <div className="workspace-row">
        <span className="workspace-swatch" style={{ background: company.color }} aria-hidden />
        <div className="workspace-row-body">
          <strong>{company.name}</strong>
          <span className="muted xsmall">
            {company.project_count} {company.project_count === 1 ? 'project' : 'projects'}
            {' · '}{company.role}
            {company.is_active ? ' · active' : ''}
          </span>
        </div>
        <button type="button" className="ghost small" onClick={() => setEditing(true)}>Edit</button>
        {canDelete ? (
          <button type="button" className="ghost small danger" onClick={() => void remove()} disabled={busy}>
            Delete
          </button>
        ) : null}
      </div>
    );
  }

  return (
    <div className="workspace-row editing">
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        autoFocus
        maxLength={60}
      />
      <div className="color-picker">
        {PALETTE.map((c) => (
          <button
            key={c}
            type="button"
            className={`color-swatch ${color === c ? 'selected' : ''}`}
            style={{ background: c }}
            onClick={() => setColor(c)}
          />
        ))}
      </div>
      <button type="button" className="primary small" onClick={() => void save()} disabled={busy}>Save</button>
      <button type="button" className="ghost small" onClick={() => setEditing(false)}>Cancel</button>
    </div>
  );
}
