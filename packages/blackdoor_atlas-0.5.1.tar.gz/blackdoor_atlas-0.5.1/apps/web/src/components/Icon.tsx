// Tiny inline-SVG icon set. Stroke-based, 16px default — refined enough to
// pass a Linear/Notion aesthetic bar without a heavyweight icon library.

import type { SVGAttributes } from 'react';

export type IconName =
  | 'inbox' | 'circle' | 'half-circle' | 'check-circle' | 'check' | 'plus'
  | 'x' | 'search' | 'sparkle' | 'folder' | 'settings' | 'list' | 'columns'
  | 'priority-bars' | 'priority-flag' | 'kebab' | 'grip' | 'arrow-right'
  | 'calendar' | 'user' | 'tag' | 'trash' | 'logout' | 'terminal' | 'command'
  | 'chevron-down' | 'chevron-right';

const D: Record<IconName, string> = {
  'inbox': 'M22 12h-6l-2 3h-4l-2-3H2 M22 12v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6 M22 12L18 5H6L2 12',
  'circle': '',
  'half-circle': '',
  'check-circle': 'M22 11.08V12a10 10 0 1 1-5.93-9.14 M22 4L12 14.01l-3-3',
  'check': 'M20 6L9 17l-5-5',
  'plus': 'M12 5v14M5 12h14',
  'x': 'M18 6L6 18 M6 6l12 12',
  'search': 'M21 21l-4.35-4.35 M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z',
  'sparkle': 'M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1',
  'folder': 'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z',
  'settings': 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',
  'list': 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
  'columns': 'M3 3h7v18H3z M14 3h7v18h-7z',
  'priority-bars': 'M3 17v3 M9 13v7 M15 9v11 M21 5v15',
  'priority-flag': 'M4 22V4 M4 14h13l-2-3 2-3H4',
  'kebab': 'M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2z M12 6a1 1 0 1 0 0-2 1 1 0 0 0 0 2z M12 20a1 1 0 1 0 0-2 1 1 0 0 0 0 2z',
  'grip': 'M9 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM9 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM9 17a1 1 0 1 0 0 2 1 1 0 0 0 0-2z M15 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM15 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM15 17a1 1 0 1 0 0 2 1 1 0 0 0 0-2z',
  'arrow-right': 'M5 12h14M12 5l7 7-7 7',
  'calendar': 'M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM16 2v4 M8 2v4 M3 10h18',
  'user': 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  'tag': 'M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z M7 7h.01',
  'trash': 'M3 6h18 M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2',
  'logout': 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9',
  'terminal': 'M4 17l6-6-6-6 M12 19h8',
  'command': 'M18 3a3 3 0 0 0-3 3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3',
  'chevron-down': 'M6 9l6 6 6-6',
  'chevron-right': 'M9 6l6 6-6 6',
};

interface Props extends SVGAttributes<SVGSVGElement> {
  name: IconName;
  size?: number;
}

export function Icon({ name, size = 16, ...rest }: Props): JSX.Element {
  if (name === 'circle') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none" {...rest}>
        <circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.5" />
      </svg>
    );
  }
  if (name === 'half-circle') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none" {...rest}>
        <circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.5" />
        <path d="M8 1.5a6.5 6.5 0 0 1 0 13z" fill="currentColor" />
      </svg>
    );
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...rest}
    >
      <path d={D[name]} />
    </svg>
  );
}

export type StatusKey = 'backlog' | 'todo' | 'started' | 'review' | 'done' | 'cancelled';

export function StatusIcon({ status, size = 16 }: { status: StatusKey | string; size?: number }): JSX.Element {
  // Linear-style status glyphs at 16px: dashed backlog, empty todo,
  // quarter-fill started, three-quarter-fill review, filled green done,
  // gray X cancelled.
  const s = (status === 'doing' ? 'started' : status) as StatusKey;
  if (s === 'backlog') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="6.5" stroke="var(--st-todo)" strokeWidth="1.4" strokeDasharray="2 2" />
      </svg>
    );
  }
  if (s === 'todo') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="6.5" stroke="var(--st-todo)" strokeWidth="1.5" />
      </svg>
    );
  }
  if (s === 'started') {
    // Linear's started glyph: outer ring + a wedge that starts at the top
    // and sweeps clockwise to ~3 o'clock (~25% complete). Inset by 1px to
    // avoid touching the stroke — that's the touch that reads as "Linear".
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="6.5" stroke="var(--st-doing)" strokeWidth="1.5" />
        <path d="M8 8 L8 2.8 A5.2 5.2 0 0 1 13.2 8 Z" fill="var(--st-doing)" />
      </svg>
    );
  }
  if (s === 'review') {
    // ~75% wedge: top → right → bottom → left (three quadrants).
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="6.5" stroke="var(--st-review)" strokeWidth="1.5" />
        <path d="M8 8 L8 2.8 A5.2 5.2 0 0 1 13.2 8 A5.2 5.2 0 0 1 8 13.2 Z" fill="var(--st-review)" />
      </svg>
    );
  }
  if (s === 'cancelled') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="7" fill="var(--text-3)" />
        <path d="M5.5 5.5 L10.5 10.5 M10.5 5.5 L5.5 10.5" stroke="white" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="7" fill="var(--st-done)" />
      <path d="M4.5 8.2 L7 10.7 L11.5 6" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// Estimate as a small pill that fits any Fibonacci.
export function EstimateBadge({ value }: { value: number | null }): JSX.Element | null {
  if (value == null) return null;
  return <span className="estimate-badge" title={`Estimate: ${value}`}>{value}</span>;
}

export function PriorityIcon({ priority, size = 14 }: { priority: 'urgent' | 'high' | 'med' | 'low'; size?: number }): JSX.Element {
  // Linear-style bars. Urgent has the urgent flag glyph.
  if (priority === 'urgent') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <rect x="2" y="2" width="12" height="12" rx="2" fill="var(--p-urgent)" />
        <path d="M8 4.5v4.7" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="8" cy="11.5" r="0.9" fill="white" />
      </svg>
    );
  }
  const filled = priority === 'high' ? 3 : priority === 'med' ? 2 : 1;
  const color = priority === 'high' ? 'var(--p-high)' : priority === 'med' ? 'var(--p-med)' : 'var(--p-low)';
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect x="2"  y="10" width="3" height="4" rx="0.6" fill={filled >= 1 ? color : 'var(--surface-3)'} />
      <rect x="6.5" y="7"  width="3" height="7" rx="0.6" fill={filled >= 2 ? color : 'var(--surface-3)'} />
      <rect x="11" y="4"  width="3" height="10" rx="0.6" fill={filled >= 3 ? color : 'var(--surface-3)'} />
    </svg>
  );
}
