// Tiny dependency-free markdown renderer.
// Handles: headings (#, ##, ###), bold/italic, inline code, fenced code blocks,
// unordered + ordered lists, blockquotes, hr, links. Newlines become <br>.
//
// Output is React, not raw HTML — no dangerouslySetInnerHTML, so unbounded
// strings can't XSS the page. URL hrefs are sanitised against `javascript:`
// and `data:` prefixes.

import { type ReactNode } from 'react';

interface Props {
  source: string;
  className?: string;
}

export function Markdown({ source, className }: Props): JSX.Element {
  return <div className={`md${className ? ' ' + className : ''}`}>{renderBlocks(source)}</div>;
}

function renderBlocks(src: string): ReactNode[] {
  const lines = src.replace(/\r\n/g, '\n').split('\n');
  const out: ReactNode[] = [];
  let i = 0;
  let key = 0;

  while (i < lines.length) {
    const line = lines[i]!;

    // fenced code block
    const fence = line.match(/^```(\w*)\s*$/);
    if (fence) {
      const lang = fence[1] ?? '';
      const buf: string[] = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i]!)) {
        buf.push(lines[i]!);
        i++;
      }
      if (i < lines.length) i++; // skip closing fence
      out.push(
        <pre key={++key} data-lang={lang || undefined}><code>{buf.join('\n')}</code></pre>,
      );
      continue;
    }

    // horizontal rule
    if (/^---+\s*$/.test(line)) {
      out.push(<hr key={++key} />);
      i++;
      continue;
    }

    // heading
    const heading = line.match(/^(#{1,3})\s+(.*)$/);
    if (heading) {
      const level = heading[1]!.length;
      const text = heading[2]!;
      if (level === 1) out.push(<h1 key={++key}>{renderInline(text)}</h1>);
      else if (level === 2) out.push(<h2 key={++key}>{renderInline(text)}</h2>);
      else out.push(<h3 key={++key}>{renderInline(text)}</h3>);
      i++;
      continue;
    }

    // blockquote (one or more consecutive lines)
    if (line.startsWith('> ')) {
      const buf: string[] = [];
      while (i < lines.length && lines[i]!.startsWith('> ')) {
        buf.push(lines[i]!.slice(2));
        i++;
      }
      out.push(<blockquote key={++key}>{renderInline(buf.join(' '))}</blockquote>);
      continue;
    }

    // unordered list
    if (/^[-*]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*]\s+/.test(lines[i]!)) {
        items.push(lines[i]!.replace(/^[-*]\s+/, ''));
        i++;
      }
      out.push(<ul key={++key}>{items.map((it, idx) => <li key={idx}>{renderInline(it)}</li>)}</ul>);
      continue;
    }

    // ordered list
    if (/^\d+\.\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i]!)) {
        items.push(lines[i]!.replace(/^\d+\.\s+/, ''));
        i++;
      }
      out.push(<ol key={++key}>{items.map((it, idx) => <li key={idx}>{renderInline(it)}</li>)}</ol>);
      continue;
    }

    // blank line → paragraph break
    if (line.trim() === '') {
      i++;
      continue;
    }

    // paragraph: consume subsequent non-blank lines
    const buf: string[] = [line];
    i++;
    while (i < lines.length && lines[i]!.trim() !== '' && !/^([-*#>]|\d+\.|```)/.test(lines[i]!)) {
      buf.push(lines[i]!);
      i++;
    }
    out.push(<p key={++key}>{renderInline(buf.join(' '))}</p>);
  }

  return out;
}

// Inline tokens: `code`, **bold**, *italic*, [text](url), <url>, @mention.
function renderInline(text: string): ReactNode[] {
  const out: ReactNode[] = [];
  let cursor = 0;
  let key = 0;

  // Process inline code first so we don't bold inside it.
  const codeRegex = /`([^`]+)`/g;
  let lastEnd = 0;
  const tokens: Array<{ kind: 'text' | 'code'; value: string }> = [];
  let m: RegExpExecArray | null;
  while ((m = codeRegex.exec(text)) !== null) {
    if (m.index > lastEnd) tokens.push({ kind: 'text', value: text.slice(lastEnd, m.index) });
    tokens.push({ kind: 'code', value: m[1]! });
    lastEnd = m.index + m[0].length;
  }
  if (lastEnd < text.length) tokens.push({ kind: 'text', value: text.slice(lastEnd) });

  for (const t of tokens) {
    if (t.kind === 'code') {
      out.push(<code key={++key}>{t.value}</code>);
      continue;
    }
    // Now handle bold/italic/link/mention in this plain-text chunk.
    let s = t.value;
    cursor = 0;
    while (cursor < s.length) {
      // [text](url)
      const link = matchAt(s, cursor, /\[([^\]]+)\]\(([^)]+)\)/);
      if (link) {
        out.push(<span key={++key}>{s.slice(cursor, link.index)}</span>);
        const href = safeHref(link[2]!);
        out.push(<a key={++key} href={href} target="_blank" rel="noreferrer noopener">{link[1]}</a>);
        cursor = link.index + link[0].length;
        continue;
      }
      // **bold**
      const bold = matchAt(s, cursor, /\*\*([^*]+)\*\*/);
      if (bold) {
        out.push(<span key={++key}>{s.slice(cursor, bold.index)}</span>);
        out.push(<strong key={++key}>{bold[1]}</strong>);
        cursor = bold.index + bold[0].length;
        continue;
      }
      // *italic*
      const italic = matchAt(s, cursor, /(?<![*])\*([^*\n]+)\*(?![*])/);
      if (italic) {
        out.push(<span key={++key}>{s.slice(cursor, italic.index)}</span>);
        out.push(<em key={++key}>{italic[1]}</em>);
        cursor = italic.index + italic[0].length;
        continue;
      }
      // @mention
      const mention = matchAt(s, cursor, /(^|\s)@([A-Za-z0-9._-]+)/);
      if (mention) {
        out.push(<span key={++key}>{s.slice(cursor, mention.index)}{mention[1]}</span>);
        out.push(<span key={++key} className="mention">@{mention[2]}</span>);
        cursor = mention.index + mention[0].length;
        continue;
      }
      out.push(<span key={++key}>{s.slice(cursor)}</span>);
      cursor = s.length;
    }
  }
  return out;
}

function matchAt(s: string, from: number, re: RegExp): (RegExpExecArray & { index: number }) | null {
  const sliced = s.slice(from);
  const m = re.exec(sliced);
  if (!m) return null;
  return Object.assign(m, { index: m.index + from });
}

function safeHref(url: string): string {
  const trimmed = url.trim();
  if (/^(javascript|data|vbscript):/i.test(trimmed)) return '#';
  if (/^[a-z]+:/i.test(trimmed) || trimmed.startsWith('/') || trimmed.startsWith('#') || trimmed.startsWith('mailto:')) return trimmed;
  return `https://${trimmed}`;
}
