// Linear-style workspace switcher. Renders the active workspace name as a
// pressable button at the top of the sidebar; clicking opens a popover with
// the user's other workspaces, "New workspace…", and "Manage workspaces…"
// items. Switching POSTs to /api/companies/switch and tells the shell to
// refresh (the parent passes onSwitched).

import { useEffect, useRef, useState } from 'react';
import { api, type Company } from '../api.js';
import { Icon } from './Icon.js';

interface Props {
  companies: Company[];
  active: Company | null;
  onSwitched: () => void;
  onOpenManage: () => void;
  onOpenCreate: () => void;
}

export function WorkspaceSwitcher({ companies, active, onSwitched, onOpenManage, onOpenCreate }: Props): JSX.Element {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  // Close on click outside / Escape.
  useEffect(() => {
    if (!open) return;
    function onDoc(e: MouseEvent): void {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent): void { if (e.key === 'Escape') setOpen(false); }
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  async function pick(c: Company): Promise<void> {
    setOpen(false);
    if (c.is_active) return;
    try {
      await api.switchCompany(c.id);
      onSwitched();
    } catch {
      // Surface a minimal hint; in practice this only fails for a stale list.
      alert(`Could not switch to "${c.name}".`);
    }
  }

  const label = active?.name ?? 'No workspace';
  const swatch = active?.color ?? '#9ca3af';

  return (
    <div className="workspace-switcher" ref={ref}>
      <button
        type="button"
        className="workspace-trigger"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
        title="Switch workspace"
      >
        <span className="workspace-swatch" style={{ background: swatch }} aria-hidden />
        <strong className="workspace-name">{label}</strong>
        <Icon name="chevron-down" size={14} />
      </button>

      {open ? (
        <div className="workspace-popover" role="menu">
          <div className="workspace-popover-section">
            {companies.length === 0 ? (
              <div className="workspace-empty">No workspaces yet.</div>
            ) : companies.map((c) => (
              <button
                key={c.id}
                type="button"
                role="menuitem"
                className={`workspace-option ${c.is_active ? 'active' : ''}`}
                onClick={() => void pick(c)}
              >
                <span className="workspace-swatch" style={{ background: c.color }} aria-hidden />
                <span className="workspace-option-body">
                  <span className="workspace-option-name">{c.name}</span>
                  <span className="workspace-option-meta">
                    {c.project_count} {c.project_count === 1 ? 'project' : 'projects'}
                    {' · '}{c.role}
                  </span>
                </span>
                {c.is_active ? <Icon name="check" size={14} /> : null}
              </button>
            ))}
          </div>
          <div className="workspace-popover-section workspace-popover-actions">
            <button type="button" className="workspace-action" onClick={() => { setOpen(false); onOpenCreate(); }}>
              <Icon name="plus" size={14} /> New workspace
            </button>
            <button type="button" className="workspace-action" onClick={() => { setOpen(false); onOpenManage(); }}>
              <Icon name="settings" size={14} /> Manage workspaces
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
