// OpenHands-style tool call inspector. Renders a vertical timeline of tool
// invocations with status dot, duration badge, click-to-expand input/output,
// and per-section copy buttons.
//
// Drop-in: AIPanel still owns the ToolCard array; this just renders it.

import { useState } from 'react';
import { Icon } from './Icon.js';

export interface ToolEvent {
  id: string;
  name: string;
  input: Record<string, unknown>;
  result?: string;
  is_error?: boolean;
  started_at?: number;        // epoch ms; set when tool_use lands
  ended_at?: number;          // epoch ms; set when tool_result lands
}

interface Props {
  tools: ToolEvent[];
}

export function ToolInspector({ tools }: Props): JSX.Element | null {
  if (tools.length === 0) return null;
  return (
    <div className="tool-inspector">
      <div className="tool-rail" aria-hidden />
      {tools.map((t, i) => (
        <ToolNode key={t.id} tool={t} isLast={i === tools.length - 1} />
      ))}
    </div>
  );
}

function ToolNode({ tool, isLast }: { tool: ToolEvent; isLast: boolean }): JSX.Element {
  const [expanded, setExpanded] = useState(false);
  const status: 'running' | 'done' | 'error' =
    tool.result === undefined ? 'running' : tool.is_error ? 'error' : 'done';

  // Pretty input — try JSON formatting, fall back to one-liner.
  const inputPretty = formatJson(tool.input);
  const inputSummary = summariseInput(tool.input);

  return (
    <div className={`tool-node ${status}`}>
      <div className="tool-dot" aria-label={status}>
        {status === 'running' ? <span className="spin" /> :
         status === 'error'   ? <Icon name="x" size={10} /> :
         <Icon name="check" size={10} />}
      </div>
      {isLast ? <div className="tool-rail-cap" aria-hidden /> : null}

      <button
        type="button"
        className="tool-node-header"
        onClick={() => setExpanded((v) => !v)}
        aria-expanded={expanded}
      >
        <Icon name={expanded ? 'chevron-down' : 'chevron-right'} size={12} />
        <code className="tool-name">{tool.name}</code>
        <span className="tool-summary">{inputSummary}</span>
        <span className="tool-meta">
          {durationLabel(tool.started_at, tool.ended_at)}
        </span>
      </button>

      {expanded ? (
        <div className="tool-body">
          <Section label="input" payload={inputPretty} mono />
          <Section
            label="output"
            payload={tool.result ?? '(running…)'}
            mono
            error={tool.is_error}
          />
        </div>
      ) : null}
    </div>
  );
}

function Section({ label, payload, mono, error }: {
  label: string;
  payload: string;
  mono?: boolean;
  error?: boolean;
}): JSX.Element {
  const [copied, setCopied] = useState(false);
  async function copy(): Promise<void> {
    try {
      await navigator.clipboard.writeText(payload);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {
      // Clipboard API blocked (e.g. insecure context). Ignore — the body is
      // visible and selectable.
    }
  }
  return (
    <div className={`tool-section ${error ? 'err' : ''}`}>
      <div className="tool-section-header">
        <span className="tool-section-label">{label}</span>
        <button type="button" className="tool-copy" onClick={() => void copy()} title="Copy">
          {copied ? 'copied' : 'copy'}
        </button>
      </div>
      <pre className={mono ? 'mono' : ''}>{payload}</pre>
    </div>
  );
}

function formatJson(input: Record<string, unknown>): string {
  try {
    return JSON.stringify(input, null, 2);
  } catch {
    return String(input);
  }
}

function summariseInput(input: Record<string, unknown>): string {
  const entries = Object.entries(input).slice(0, 3);
  return entries
    .map(([k, v]) => {
      const s = typeof v === 'string' ? v : JSON.stringify(v);
      const short = s.length > 36 ? s.slice(0, 36) + '…' : s;
      return `${k}=${short}`;
    })
    .join('  ');
}

function durationLabel(start: number | undefined, end: number | undefined): string {
  if (!start) return '';
  const stop = end ?? Date.now();
  const ms = Math.max(0, stop - start);
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(ms < 10_000 ? 1 : 0)}s`;
}
