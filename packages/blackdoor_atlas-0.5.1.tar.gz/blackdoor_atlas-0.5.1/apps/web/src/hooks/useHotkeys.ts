// Global keyboard handler with two flavors of bindings:
//
//   single-key bindings: { 'c': () => create() }
//   chord bindings:      { 'g i': () => goto('/inbox') }
//
// The hook itself is dependency-free. It listens on `window` so callers don't
// have to worry about focus. Bindings are skipped while typing in an input,
// textarea, or contentEditable element — except when explicitly opted in via
// `allowInField: true` on a binding.

import { useEffect, useRef } from 'react';

export interface HotkeyAction {
  handler: (e: KeyboardEvent) => void;
  /** Allow firing even when focus is in a form field. Default false. */
  allowInField?: boolean;
  /** Allow firing while a modifier is held. Default false — modifiers usually mean OS shortcut. */
  allowMod?: boolean;
}

export type HotkeyMap = Record<string, HotkeyAction | ((e: KeyboardEvent) => void)>;

const CHORD_TIMEOUT_MS = 1000;

function inField(target: EventTarget | null): boolean {
  const el = target as HTMLElement | null;
  if (!el) return false;
  return (
    el instanceof HTMLInputElement ||
    el instanceof HTMLTextAreaElement ||
    el instanceof HTMLSelectElement ||
    (el.isContentEditable ?? false)
  );
}

export function useHotkeys(bindings: HotkeyMap, deps: ReadonlyArray<unknown> = []): void {
  // Latest bindings live in a ref so we don't re-attach the listener every
  // render (and so chord state survives re-renders).
  const ref = useRef(bindings);
  ref.current = bindings;

  const pendingPrefix = useRef<{ key: string; at: number } | null>(null);

  useEffect(() => {
    function onKey(e: KeyboardEvent): void {
      const k = e.key;
      const hasMod = e.metaKey || e.ctrlKey || e.altKey;
      const field = inField(e.target);

      // Clear stale chord prefix.
      if (pendingPrefix.current && Date.now() - pendingPrefix.current.at > CHORD_TIMEOUT_MS) {
        pendingPrefix.current = null;
      }

      // Check for chord match first.
      if (pendingPrefix.current && k.length === 1) {
        const chord = `${pendingPrefix.current.key} ${k.toLowerCase()}`;
        const action = ref.current[chord];
        if (action) {
          pendingPrefix.current = null;
          if (field && !((typeof action !== 'function' && action.allowInField))) return;
          if (hasMod && !((typeof action !== 'function' && action.allowMod))) return;
          e.preventDefault();
          (typeof action === 'function' ? action : action.handler)(e);
          return;
        }
        pendingPrefix.current = null;
      }

      const single = k.length === 1 ? k.toLowerCase() : k;
      const directAction = ref.current[single];
      if (directAction) {
        const a = typeof directAction === 'function' ? { handler: directAction } : directAction;
        if (field && !a.allowInField) return;
        if (hasMod && !a.allowMod) return;
        e.preventDefault();
        a.handler(e);
        return;
      }

      // If a chord prefix is registered (e.g. 'g i'), wait for the next key.
      if (k.length === 1 && !hasMod && !field) {
        const lower = k.toLowerCase();
        for (const key of Object.keys(ref.current)) {
          if (key.startsWith(`${lower} `)) {
            pendingPrefix.current = { key: lower, at: Date.now() };
            return;
          }
        }
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
