import { useEffect, useState } from 'react';
import { Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { api, type User } from './api.js';
import { AppShell } from './components/AppShell.js';
import { Agent } from './pages/Agent.js';
import { Inbox } from './pages/Inbox.js';
import { Landing } from './pages/Landing.js';
import { Login } from './pages/Login.js';
import { ProjectView } from './pages/ProjectView.js';
import { Signup } from './pages/Signup.js';

export function App(): JSX.Element {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    api
      .me()
      .then((u) => setUser(u))
      .catch(() => setUser(null))
      .finally(() => setReady(true));
  }, []);

  async function handleLogout(): Promise<void> {
    await api.logout();
    setUser(null);
    navigate('/');
  }

  if (!ready) return <main className="auth-page"><div className="muted">Loading…</div></main>;

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<Login onAuth={(u) => setUser(u)} />} />
        <Route path="/signup" element={<Signup onAuth={(u) => setUser(u)} />} />
        <Route path="/" element={<Landing hasUser={false} />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<AppShell user={user} onLogout={handleLogout} />}>
        <Route index element={<Navigate to="/inbox" replace />} />
        <Route path="inbox" element={<Inbox />} />
        <Route path="projects/:id" element={<ProjectView />} />
        <Route path="agent" element={<Agent />} />
      </Route>
      <Route path="*" element={<Navigate to="/inbox" replace />} />
    </Routes>
  );
}
