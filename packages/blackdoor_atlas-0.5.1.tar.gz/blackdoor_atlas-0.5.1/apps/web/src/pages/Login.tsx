import { type FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, type User } from '../api.js';

export function Login({ onAuth }: { onAuth: (u: User) => void }): JSX.Element {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  async function submit(e: FormEvent<HTMLFormElement>): Promise<void> {
    e.preventDefault();
    setError(null);
    try {
      const user = await api.login(email, password);
      onAuth(user);
      navigate('/inbox');
    } catch {
      setError('Login failed. Check your credentials.');
    }
  }

  return (
    <main className="auth-page">
      <div className="auth-card">
        <h1>Welcome back</h1>
        <p className="muted small">Sign in to your workspace.</p>
        <form onSubmit={submit} aria-label="Log in form" style={{ marginTop: '1.25rem' }}>
          <label>
            Email
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </label>
          <label style={{ marginTop: '0.75rem' }}>
            Password
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </label>
          {error ? <p className="small" role="alert" style={{ color: 'var(--p-urgent)' }}>{error}</p> : null}
          <button type="submit" style={{ marginTop: '1rem', width: '100%', justifyContent: 'center' }}>Log in</button>
        </form>
        <div className="switch">
          New here? <Link to="/signup">Create an account</Link>
        </div>
      </div>
    </main>
  );
}
