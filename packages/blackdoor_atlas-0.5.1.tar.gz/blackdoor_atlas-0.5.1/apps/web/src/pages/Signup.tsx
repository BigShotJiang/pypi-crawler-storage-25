import { type FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, type User } from '../api.js';

export function Signup({ onAuth }: { onAuth: (u: User) => void }): JSX.Element {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  async function submit(e: FormEvent<HTMLFormElement>): Promise<void> {
    e.preventDefault();
    setError(null);
    try {
      const user = await api.signup(email, password);
      onAuth(user);
      navigate('/inbox');
    } catch {
      setError('Sign up failed. Try a different email or a longer password.');
    }
  }

  return (
    <main className="auth-page">
      <div className="auth-card">
        <h1>Create your workspace</h1>
        <p className="muted small">Projects, tasks, and an AI agent that can work on them.</p>
        <form onSubmit={submit} aria-label="Sign up form" style={{ marginTop: '1.25rem' }}>
          <label>
            Email
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </label>
          <label style={{ marginTop: '0.75rem' }}>
            Password
            <input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
            />
          </label>
          {error ? <p className="small" role="alert" style={{ color: 'var(--p-urgent)' }}>{error}</p> : null}
          <button type="submit" style={{ marginTop: '1rem', width: '100%', justifyContent: 'center' }}>Create account</button>
        </form>
        <div className="switch">
          Have an account? <Link to="/login">Log in</Link>
        </div>
      </div>
    </main>
  );
}
