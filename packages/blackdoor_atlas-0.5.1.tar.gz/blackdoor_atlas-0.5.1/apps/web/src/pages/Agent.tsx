import { type FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  api,
  streamAgentChat,
  type AgentInfo,
  type AssistantBlock,
  type ChatMessage,
} from '../api.js';
import { ToolInspector, type ToolEvent } from '../components/ToolInspector.js';

type ToolCard = ToolEvent;

interface Turn {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  thinking?: string;
  tools: ToolCard[];
  partial?: boolean;
}

const STARTER_PROMPTS = [
  'Read CLAUDE.md and summarize what this harness does in 4 bullets.',
  'List apps/api/src and explain how the auth flow works.',
  'Add a /api/agent/version endpoint that returns { version: "0.1.0" }.',
  'Search the repo for TODOs and group them by file.',
];

export function Agent(): JSX.Element {
  const [info, setInfo] = useState<AgentInfo | null>(null);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [effort, setEffort] = useState<'low' | 'medium' | 'high' | 'xhigh' | 'max'>('high');
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.agentInfo().then(setInfo).catch(() => setInfo(null));
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns]);

  const wireMessages = useMemo(() => buildWireHistory(turns), [turns]);

  async function send(question: string): Promise<void> {
    if (!question.trim() || streaming) return;
    const userTurn: Turn = { id: id(), role: 'user', text: question.trim(), tools: [] };
    const assistantTurn: Turn = { id: id(), role: 'assistant', text: '', tools: [], partial: true };
    setTurns((prev) => [...prev, userTurn, assistantTurn]);
    setInput('');
    setStreaming(true);

    const wire: ChatMessage[] = [...wireMessages, { role: 'user', content: question.trim() }];

    const controller = new AbortController();
    abortRef.current = controller;

    await streamAgentChat(
      wire,
      {
        onText: (delta) => {
          setTurns((prev) => withLast(prev, (t) => ({ ...t, text: t.text + delta })));
        },
        onThinking: (delta) => {
          setTurns((prev) => withLast(prev, (t) => ({ ...t, thinking: (t.thinking ?? '') + delta })));
        },
        onToolUse: (b) => {
          setTurns((prev) => withLast(prev, (t) => ({
            ...t,
            tools: [...t.tools, { id: b.id, name: b.name, input: b.input, started_at: Date.now() }],
          })));
        },
        onToolResult: (b) => {
          setTurns((prev) => withLast(prev, (t) => ({
            ...t,
            tools: t.tools.map((c) => (c.id === b.id
              ? { ...c, result: b.content, is_error: b.is_error, ended_at: Date.now() }
              : c)),
          })));
        },
        onError: (msg) => {
          setTurns((prev) => withLast(prev, (t) => ({ ...t, text: t.text + `\n[error: ${msg}]` })));
        },
        onDone: () => {
          setTurns((prev) => withLast(prev, (t) => ({ ...t, partial: false })));
          setStreaming(false);
          abortRef.current = null;
        },
      },
      { signal: controller.signal, thinking, effort },
    );
  }

  function submit(e: FormEvent<HTMLFormElement>): void {
    e.preventDefault();
    void send(input);
  }

  function stop(): void {
    abortRef.current?.abort();
  }

  function reset(): void {
    abortRef.current?.abort();
    setTurns([]);
  }

  const notReady = info && (!info.active || !info.providers.some((p) => p.ready));

  return (
    <main aria-label="Agent" className="agent">
      <header className="agent-header">
        <div>
          <h1>AI Harness</h1>
          <p className="agent-sub">
            A local Claude-Code-style agent with file, shell, and search tools. Active model:&nbsp;
            <strong>{info?.active ? `${info.active.id} · ${info.active.model}` : '(none configured)'}</strong>
          </p>
        </div>
        <div className="agent-controls">
          <label className="chip">
            <input type="checkbox" checked={thinking} onChange={(e) => setThinking(e.target.checked)} /> thinking
          </label>
          <label className="chip">
            effort&nbsp;
            <select value={effort} onChange={(e) => setEffort(e.target.value as typeof effort)}>
              <option value="low">low</option>
              <option value="medium">medium</option>
              <option value="high">high</option>
              <option value="xhigh">xhigh</option>
              <option value="max">max</option>
            </select>
          </label>
          <button type="button" className="secondary" onClick={reset} disabled={streaming && turns.length === 0}>
            New chat
          </button>
        </div>
      </header>

      {notReady ? <ProviderBanner info={info!} /> : null}

      <aside className="agent-warn" role="status">
        <strong>Auto-approve mode.</strong> Tool calls (including <code>write_file</code>,
        <code> edit_file</code>, and <code>run_command</code>) execute immediately
        as the model emits them. Review prompts before sending. Permission gating
        is a planned follow-up.
      </aside>


      {turns.length === 0 ? (
        <section className="agent-starters" aria-label="Starter prompts">
          <p>Try one of these:</p>
          <ul>
            {STARTER_PROMPTS.map((p) => (
              <li key={p}>
                <button type="button" className="starter" onClick={() => void send(p)}>{p}</button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="agent-thread" aria-live="polite">
        {turns.map((t) => (t.role === 'user' ? <UserBubble key={t.id} turn={t} /> : <AssistantBubble key={t.id} turn={t} />))}
        <div ref={bottomRef} />
      </section>

      <form onSubmit={submit} className="agent-composer" aria-label="Composer">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={streaming ? 'streaming…' : 'Ask the agent to read, search, edit, or run something. Shift+Enter for newline.'}
          rows={3}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              void send(input);
            }
          }}
          disabled={streaming}
        />
        <div className="agent-composer-row">
          {streaming ? (
            <button type="button" onClick={stop}>Stop</button>
          ) : (
            <button type="submit" disabled={!input.trim()}>Send</button>
          )}
        </div>
      </form>
    </main>
  );
}

function ProviderBanner({ info }: { info: AgentInfo }): JSX.Element {
  return (
    <aside className="agent-banner" role="status">
      <strong>No provider is configured.</strong> Set one of these in <code>apps/api/.env.local</code> and restart <code>./app</code>:
      <ul>
        {info.providers.map((p) => (
          <li key={p.id}>
            <strong>{p.label}</strong> — {p.ready ? <em>ready</em> : (p.reason ?? 'not configured')}
          </li>
        ))}
      </ul>
    </aside>
  );
}

function UserBubble({ turn }: { turn: Turn }): JSX.Element {
  return (
    <article className="bubble user" aria-label="You">
      <header>You</header>
      <pre>{turn.text}</pre>
    </article>
  );
}

function AssistantBubble({ turn }: { turn: Turn }): JSX.Element {
  return (
    <article className="bubble assistant" aria-label="Agent">
      <header>Agent{turn.partial ? ' · streaming…' : ''}</header>
      {turn.thinking ? (
        <details className="thinking">
          <summary>Thinking…</summary>
          <pre>{turn.thinking}</pre>
        </details>
      ) : null}
      {turn.text ? <pre className="agent-text">{turn.text}</pre> : null}
      <ToolInspector tools={turn.tools} />
      {turn.partial && !turn.text && turn.tools.length === 0 ? <p className="muted">thinking…</p> : null}
    </article>
  );
}

function buildWireHistory(turns: Turn[]): ChatMessage[] {
  const out: ChatMessage[] = [];
  for (const t of turns) {
    if (t.role === 'user') {
      out.push({ role: 'user', content: t.text });
    } else {
      const blocks: AssistantBlock[] = [];
      if (t.text) blocks.push({ type: 'text', text: t.text });
      for (const tool of t.tools) {
        blocks.push({ type: 'tool_use', id: tool.id, name: tool.name, input: tool.input });
      }
      if (blocks.length) out.push({ role: 'assistant', content: blocks });
      for (const tool of t.tools) {
        if (tool.result !== undefined) {
          out.push({
            role: 'tool',
            tool_use_id: tool.id,
            content: tool.result,
            is_error: tool.is_error ?? false,
          });
        }
      }
    }
  }
  return out;
}

function withLast(turns: Turn[], fn: (t: Turn) => Turn): Turn[] {
  if (turns.length === 0) return turns;
  const idx = turns.length - 1;
  const next = [...turns];
  next[idx] = fn(turns[idx]!);
  return next;
}

let counter = 0;
function id(): string {
  counter += 1;
  return `t${Date.now().toString(36)}_${counter}`;
}
