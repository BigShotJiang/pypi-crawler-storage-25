import { type DragEvent, type MouseEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Navigate, useParams } from 'react-router-dom';
import {
  api,
  ESTIMATES,
  PRIORITIES,
  STATUSES,
  type Cycle,
  type Label,
  type Project,
  type ProjectInsights,
  type SavedView,
  type Task,
  type TaskPriority,
  type TaskStatus,
  type Template,
} from '../api.js';
import { useHotkeys } from '../hooks/useHotkeys.js';
import { EditableTitle } from '../components/EditableTitle.js';
import { EstimateBadge, Icon, PriorityIcon, StatusIcon } from '../components/Icon.js';
import { TaskDrawer } from '../components/TaskDrawer.js';
import { AIPanel } from '../components/AIPanel.js';

type ViewKind = 'board' | 'list' | 'cycles' | 'insights' | 'codemap';

const COLUMNS: { key: TaskStatus; label: string }[] = [
  { key: 'backlog', label: 'Backlog' },
  { key: 'todo',    label: 'Todo' },
  { key: 'started', label: 'In progress' },
  { key: 'review',  label: 'In review' },
  { key: 'done',    label: 'Done' },
  { key: 'cancelled', label: 'Cancelled' },
];

const STATUS_LABEL: Record<TaskStatus, string> = {
  backlog: 'Backlog', todo: 'Todo', started: 'In progress', review: 'In review', done: 'Done', cancelled: 'Cancelled',
};

export function ProjectView(): JSX.Element {
  const params = useParams();
  const projectId = Number(params.id);

  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [labels, setLabels] = useState<Label[]>([]);
  const [cycles, setCycles] = useState<Cycle[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [savedViews, setSavedViews] = useState<SavedView[]>([]);

  const [view, setView] = useState<ViewKind>('board');
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<TaskPriority | null>(null);
  const [cycleFilter, setCycleFilter] = useState<'all' | 'none' | number>('all');
  const [hideCancelled, setHideCancelled] = useState(true);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [openTaskId, setOpenTaskId] = useState<number | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [templateMenuOpen, setTemplateMenuOpen] = useState(false);
  const [focusedId, setFocusedId] = useState<number | null>(null);
  const [groupBy, setGroupBy] = useState<'status' | 'priority' | 'assignee' | 'cycle' | 'label' | 'none'>('status');
  const [statusPickerForId, setStatusPickerForId] = useState<number | null>(null);
  const [priorityPickerForId, setPriorityPickerForId] = useState<number | null>(null);
  // Task id whose title is currently being inline-edited (Linear's `e` hotkey).
  // null = nobody. Set by the `e` hotkey, cleared on submit/cancel.
  const [editingTitleId, setEditingTitleId] = useState<number | null>(null);

  const searchRef = useRef<HTMLInputElement>(null);
  const lastClickedRef = useRef<number | null>(null);

  const refresh = useCallback(async () => {
    try {
      const [p, ts, ls, cs, tpls] = await Promise.all([
        api.getProject(projectId),
        api.listTasks(projectId),
        api.listLabels(projectId),
        api.listCycles(projectId).catch(() => [] as Cycle[]),
        api.listTemplates(projectId).catch(() => [] as Template[]),
      ]);
      setProject(p);
      setTasks(ts);
      setLabels(ls);
      setCycles(cs);
      setTemplates(tpls);
    } catch {
      setNotFound(true);
    }
  }, [projectId]);

  const refreshViews = useCallback(async () => {
    try { setSavedViews(await api.listViews(projectId)); } catch { setSavedViews([]); }
  }, [projectId]);

  useEffect(() => {
    if (!Number.isInteger(projectId)) { setNotFound(true); return; }
    void refresh();
    void refreshViews();
  }, [projectId, refresh, refreshViews]);

  // Linear-style hotkeys. See the `useHotkeys` hook for chord support.

  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return tasks.filter((t) => {
      if (priorityFilter && t.priority !== priorityFilter) return false;
      if (cycleFilter !== 'all') {
        if (cycleFilter === 'none' && t.cycle_id != null) return false;
        if (typeof cycleFilter === 'number' && t.cycle_id !== cycleFilter) return false;
      }
      if (hideCancelled && t.status === 'cancelled') return false;
      if (needle) {
        const hay = `${t.title} ${t.body} ${t.key ?? ''}`.toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      return true;
    });
  }, [tasks, search, priorityFilter, cycleFilter, hideCancelled]);

  const visibleIds = useMemo(() => filtered.map((t) => t.id), [filtered]);

  // Derived groups for the board. When grouped by status, each group's
  // `statusForDnd` is set so dropping a card on it mutates `tasks.status`.
  // For other groupings (priority/assignee/cycle/label), DnD between groups
  // doesn't make sense — leave statusForDnd null and the column won't accept.
  const groups = useMemo(() => deriveGroups(groupBy, filtered, cycles, labels), [groupBy, filtered, cycles, labels]);

  // Legacy `grouped` kept for places (AI context, insights) that want a
  // status-bucketed map.
  const grouped = useMemo(() => {
    const map: Record<TaskStatus, Task[]> = {
      backlog: [], todo: [], started: [], review: [], done: [], cancelled: [],
    };
    for (const t of filtered) map[t.status]?.push(t);
    return map;
  }, [filtered]);

  const activeCycle = useMemo(() => cycles.find((c) => c.status === 'active') ?? null, [cycles]);

  const aiContext = useMemo(() => {
    if (!project) return '';
    return (
      `You are helping with a Linear-style project management workspace.\n` +
      `Active project (id=${project.id}, key=${project.key}): "${project.name}".\n` +
      (activeCycle ? `Active cycle: ${activeCycle.name || `Cycle ${activeCycle.number}`} (${activeCycle.start_date} → ${activeCycle.end_date}).\n` : '') +
      `Open issues (${filtered.filter((t) => t.status !== 'done' && t.status !== 'cancelled').length}):\n` +
      filtered
        .filter((t) => t.status !== 'done' && t.status !== 'cancelled')
        .slice(0, 30)
        .map((t) => `  - ${t.key} [${t.status}/${t.priority}${t.estimate ? `/E${t.estimate}` : ''}] ${t.title}${t.labels.map((l) => ` #${l.name}`).join('')}`)
        .join('\n')
    );
  }, [project, filtered, activeCycle]);

  // Linear-style hotkeys: c create, / search, j/k navigate, x toggle select,
  // Cmd/Ctrl+A select all, s/p/l/a/i set status/priority/label/assignee/self,
  // Space preview the focused issue, Esc clear selection, ? help, d delete.
  // These hooks MUST run on every render, so they go before any early return.
  function moveFocus(dir: 1 | -1): void {
    if (visibleIds.length === 0) return;
    const idx = focusedId == null ? -1 : visibleIds.indexOf(focusedId);
    const nextIdx = idx === -1 ? (dir === 1 ? 0 : visibleIds.length - 1) : (idx + dir + visibleIds.length) % visibleIds.length;
    setFocusedId(visibleIds[nextIdx]!);
  }
  async function patchFocused(p: Partial<{ status: TaskStatus; priority: TaskPriority; assignee: string; estimate: number | null; cycle_id: number | null }>): Promise<void> {
    if (focusedId == null) return;
    await api.updateTask(focusedId, p);
    await refresh();
  }
  // Cycle the focused task's cycle assignment forward: none → first cycle →
  // next → … → none. Mirrors Linear's Shift+C, with `cycles` ordered the way
  // they were loaded (most recent first from the API).
  async function rotateFocusedCycle(): Promise<void> {
    if (focusedId == null) return;
    const t = tasks.find((x) => x.id === focusedId);
    if (!t || cycles.length === 0) return;
    const ids: Array<number | null> = [null, ...cycles.map((c) => c.id)];
    const idx = ids.indexOf(t.cycle_id);
    const next = ids[(idx + 1) % ids.length] ?? null;
    await patchFocused({ cycle_id: next });
  }
  function toggleSelectFocused(mode: 'toggle' | 'range'): void {
    if (focusedId == null) return;
    toggleSelect(focusedId, mode);
  }
  async function saveInlineTitle(taskId: number, nextTitle: string): Promise<void> {
    setEditingTitleId(null);
    await api.updateTask(taskId, { title: nextTitle });
    await refresh();
  }

  useHotkeys({
    'c': () => void quickCreateLocal('todo'),
    '/': () => searchRef.current?.focus(),
    'j': () => moveFocus(1),
    'k': () => moveFocus(-1),
    'x': () => toggleSelectFocused('toggle'),
    'Enter': () => { if (focusedId != null) setOpenTaskId(focusedId); },
    ' ': () => { if (focusedId != null) setOpenTaskId(focusedId); },
    'i': () => void patchFocused({ assignee: 'me' }),
    's': () => { if (focusedId != null) setStatusPickerForId(focusedId); },
    'p': () => { if (focusedId != null) setPriorityPickerForId(focusedId); },
    'e': () => { if (focusedId != null) setEditingTitleId(focusedId); },
    'g c': () => setView('cycles'),
    'Escape': () => {
      if (editingTitleId != null) { setEditingTitleId(null); return; }
      if (statusPickerForId != null) { setStatusPickerForId(null); return; }
      if (priorityPickerForId != null) { setPriorityPickerForId(null); return; }
      if (selected.size > 0) { setSelected(new Set()); return; }
      setFocusedId(null);
    },
    '?': () => alert('Hotkeys:\nj/k — move focus\nx — toggle select\nShift+click row — range select\n⌘A — select all\nEnter/Space — open\nc — new issue\nC — cycle through cycle assignment\ne — rename focused issue inline\n/ — search\ns/p — change status/priority of focused\ni — assign to me\nEsc — close pickers / clear selection\ng i — Inbox\ng a — Agent\ng c — Cycles tab'),
  }, [visibleIds, focusedId, selected, statusPickerForId, priorityPickerForId, editingTitleId]);

  // ⌘A select all visible and Shift+C rotate focused cycle — both bound
  // directly because useHotkeys lowercases single-char keys, which would
  // collapse `c` and `C` into the same binding.
  useEffect(() => {
    function onKey(e: KeyboardEvent): void {
      const target = e.target as HTMLElement | null;
      const inForm = target instanceof HTMLInputElement
        || target instanceof HTMLTextAreaElement
        || (target?.isContentEditable ?? false);
      if (inForm) return;
      if ((e.metaKey || e.ctrlKey) && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        setSelected(new Set(visibleIds));
        return;
      }
      if (e.shiftKey && !e.metaKey && !e.ctrlKey && !e.altKey && (e.key === 'C')) {
        e.preventDefault();
        void rotateFocusedCycle();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // rotateFocusedCycle closes over `tasks`, `cycles`, `focusedId` so we
    // depend on all three; visibleIds for ⌘A.
  }, [visibleIds, tasks, cycles, focusedId]);

  if (notFound) return <Navigate to="/inbox" replace />;
  if (!project) return <ProjectSkeleton />;

  // Re-bind to the project-aware quickCreate — defined after the guard so it
  // can safely reference `project`. The hotkey's `void quickCreateLocal` above
  // calls this closure when fired.
  function quickCreateLocal(status: TaskStatus): void { void quickCreate(status); }

  async function quickCreate(status: TaskStatus, fromTemplate?: Template): Promise<void> {
    let title = fromTemplate?.title;
    if (!title) {
      const raw = prompt(`New issue (${STATUS_LABEL[status]})`);
      if (!raw?.trim()) return;
      title = raw.trim();
    }
    await api.createTask({
      project_id: projectId,
      title,
      status,
      priority: fromTemplate?.priority ?? 'med',
      body: fromTemplate?.body ?? '',
      estimate: fromTemplate?.estimate ?? null,
      cycle_id: typeof cycleFilter === 'number' ? cycleFilter : null,
    });
    await refresh();
  }

  async function moveTask(taskId: number, to: TaskStatus): Promise<void> {
    const t = tasks.find((x) => x.id === taskId);
    if (!t || t.status === to) return;
    setTasks((prev) => prev.map((x) => (x.id === taskId ? { ...x, status: to } : x)));
    try { await api.updateTask(taskId, { status: to }); await refresh(); }
    catch { void refresh(); }
  }

  async function reorderColumn(status: TaskStatus, orderedIds: number[]): Promise<void> {
    // Optimistic
    setTasks((prev) => {
      const out: Task[] = [];
      const inCol = new Map(prev.filter((p) => p.status === status).map((p) => [p.id, p]));
      let i = 0;
      for (const p of prev) {
        if (p.status === status) {
          const id = orderedIds[i++];
          const found = id != null ? inCol.get(id) : p;
          out.push((found ?? p) as Task);
        } else {
          out.push(p);
        }
      }
      return out;
    });
    try { await api.reorder(projectId, status, orderedIds); }
    catch { void refresh(); }
  }

  function toggleSelect(taskId: number, mode: 'single' | 'toggle' | 'range'): void {
    setSelected((prev) => {
      const next = new Set(prev);
      if (mode === 'range' && lastClickedRef.current != null) {
        const a = visibleIds.indexOf(lastClickedRef.current);
        const b = visibleIds.indexOf(taskId);
        if (a >= 0 && b >= 0) {
          const [lo, hi] = a < b ? [a, b] : [b, a];
          for (let i = lo; i <= hi; i++) next.add(visibleIds[i]!);
        } else {
          next.add(taskId);
        }
      } else if (mode === 'toggle') {
        if (next.has(taskId)) next.delete(taskId); else next.add(taskId);
      } else {
        next.clear();
        next.add(taskId);
      }
      lastClickedRef.current = taskId;
      return next;
    });
  }

  async function bulkPatch(patch: Parameters<typeof api.bulkUpdate>[1]): Promise<void> {
    if (selected.size === 0) return;
    await api.bulkUpdate(Array.from(selected), patch);
    await refresh();
  }

  /** Attach a label to every selected task. Server has no bulk label endpoint
   *  so we fan out per-task; cheap enough for the typical < 100-issue selection. */
  async function bulkAttachLabel(labelId: number): Promise<void> {
    if (selected.size === 0) return;
    const ids = Array.from(selected);
    await Promise.all(ids.map((id) => api.attachLabel(id, labelId).catch(() => null)));
    await refresh();
  }

  /** Delete every selected task. Confirms because there is no undo. */
  async function bulkDelete(): Promise<void> {
    if (selected.size === 0) return;
    if (!confirm(`Delete ${selected.size} issue${selected.size === 1 ? '' : 's'}? This cannot be undone.`)) return;
    const ids = Array.from(selected);
    await Promise.all(ids.map((id) => api.deleteTask(id).catch(() => null)));
    setSelected(new Set());
    await refresh();
  }

  async function saveCurrentView(): Promise<void> {
    const name = prompt('Save view as:');
    if (!name?.trim()) return;
    await api.createView(projectId, name.trim(), {
      view, search, priorityFilter, cycleFilter, hideCancelled, groupBy,
    });
    await refreshViews();
  }

  function applySavedView(v: SavedView): void {
    const p = v.payload as Record<string, unknown>;
    if (typeof p.view === 'string' && ['board', 'list', 'cycles', 'insights', 'codemap'].includes(p.view)) setView(p.view as ViewKind);
    if (typeof p.search === 'string') setSearch(p.search);
    if (p.priorityFilter === null || typeof p.priorityFilter === 'string') setPriorityFilter(p.priorityFilter as TaskPriority | null);
    if (p.cycleFilter !== undefined) setCycleFilter(p.cycleFilter as 'all' | 'none' | number);
    if (typeof p.hideCancelled === 'boolean') setHideCancelled(p.hideCancelled);
    if (typeof p.groupBy === 'string' && ['status', 'priority', 'assignee', 'cycle', 'label', 'none'].includes(p.groupBy)) {
      setGroupBy(p.groupBy as typeof groupBy);
    }
  }

  return (
    <div onClick={() => setTemplateMenuOpen(false)}>
      <div className="project-header">
        <div className="project-icon" style={{ background: project.color }} />
        <h1>
          {project.name}
          {project.key ? <span className="key">{project.key}</span> : null}
          {activeCycle ? (
            <span className="label-chip" style={{ marginLeft: '0.5rem' }} title={`Active cycle ${activeCycle.start_date} → ${activeCycle.end_date}`}>
              <span className="dot" style={{ background: 'var(--accent)' }} />
              Cycle {activeCycle.number}{activeCycle.name ? `: ${activeCycle.name}` : ''}
            </span>
          ) : null}
        </h1>
      </div>
      {project.description ? <p className="project-desc">{project.description}</p> : null}

      <div className="tabs" role="tablist">
        <button type="button" className={`tab ${view === 'board' ? 'active' : ''}`} onClick={() => setView('board')}>
          <Icon name="columns" size={14} /> Board
        </button>
        <button type="button" className={`tab ${view === 'list' ? 'active' : ''}`} onClick={() => setView('list')}>
          <Icon name="list" size={14} /> List
        </button>
        <button type="button" className={`tab ${view === 'cycles' ? 'active' : ''}`} onClick={() => setView('cycles')}>
          <Icon name="calendar" size={14} /> Cycles
        </button>
        <button type="button" className={`tab ${view === 'insights' ? 'active' : ''}`} onClick={() => setView('insights')}>
          <Icon name="priority-bars" size={14} /> Insights
        </button>
        <button type="button" className={`tab ${view === 'codemap' ? 'active' : ''}`} onClick={() => setView('codemap')}>
          <Icon name="terminal" size={14} /> Code Map
        </button>
      </div>

      {view === 'board' || view === 'list' ? (
        <FilterBar
          searchRef={searchRef}
          search={search}
          onSearch={setSearch}
          priorityFilter={priorityFilter}
          onPriority={setPriorityFilter}
          cycleFilter={cycleFilter}
          onCycle={setCycleFilter}
          cycles={cycles}
          hideCancelled={hideCancelled}
          onHideCancelled={setHideCancelled}
          savedViews={savedViews}
          onSaveView={() => void saveCurrentView()}
          onApplyView={applySavedView}
          onDeleteView={async (id) => { await api.deleteView(projectId, id); await refreshViews(); }}
          templates={templates}
          templateMenuOpen={templateMenuOpen}
          onToggleTemplateMenu={() => setTemplateMenuOpen((v) => !v)}
          onCreate={() => void quickCreate('todo')}
          onCreateFromTemplate={(t) => { setTemplateMenuOpen(false); void quickCreate('todo', t); }}
          groupBy={groupBy}
          onGroupBy={setGroupBy}
        />
      ) : null}

      {/* Selection bar rendered at the bottom of the viewport (Linear pattern) — see below */}

      {view === 'board' ? (
        <BoardView
          groups={groups}
          onMove={moveTask}
          onReorder={reorderColumn}
          onAdd={(s) => void quickCreate(s)}
          onOpen={setOpenTaskId}
          selected={selected}
          onToggleSelect={toggleSelect}
          focusedId={focusedId}
          editingTitleId={editingTitleId}
          onStartEdit={setEditingTitleId}
          onSubmitTitle={saveInlineTitle}
          onCancelEdit={() => setEditingTitleId(null)}
        />
      ) : null}

      {view === 'list' ? (
        <ListView
          tasks={filtered}
          onOpen={setOpenTaskId}
          onChanged={() => void refresh()}
          selected={selected}
          onToggleSelect={toggleSelect}
          focusedId={focusedId}
          editingTitleId={editingTitleId}
          onStartEdit={setEditingTitleId}
          onSubmitTitle={saveInlineTitle}
          onCancelEdit={() => setEditingTitleId(null)}
        />
      ) : null}

      {view === 'cycles' ? (
        <CyclesView cycles={cycles} projectId={projectId} onChanged={() => { void refresh(); }} />
      ) : null}

      {view === 'insights' ? (
        <InsightsView projectId={projectId} />
      ) : null}

      {view === 'codemap' ? (
        <CodeMapView />
      ) : null}

      {openTaskId != null ? (
        <TaskDrawer
          taskId={openTaskId}
          projectLabels={labels}
          projectCycles={cycles}
          projectTasks={tasks}
          onClose={() => setOpenTaskId(null)}
          onChanged={() => void refresh()}
        />
      ) : null}

      <AIPanel
        contextLabel={`Project ${project.key}`}
        contextPrompt={aiContext}
        suggestions={[
          'List my open issues in this project.',
          'Suggest 3 next issues to add.',
          'Move all urgent issues into the active cycle.',
          'Summarize what is left to do for this cycle.',
        ]}
      />

      {/* Linear-style bottom selection bar — only when something is selected. */}
      {selected.size > 0 ? (
        <SelectionBar
          count={selected.size}
          onClear={() => setSelected(new Set())}
          onStatus={(s) => void bulkPatch({ status: s })}
          onPriority={(p) => void bulkPatch({ priority: p })}
          onEstimate={(e) => void bulkPatch({ estimate: e })}
          onCycle={(cid) => void bulkPatch({ cycle_id: cid })}
          onAssignee={(a) => void bulkPatch({ assignee: a })}
          onAddLabel={(id) => void bulkAttachLabel(id)}
          onDelete={() => void bulkDelete()}
          cycles={cycles}
          labels={labels}
        />
      ) : null}

      {/* Lightweight one-off pickers for `s` / `p` hotkeys. */}
      {statusPickerForId != null ? (
        <QuickPicker
          label="Status"
          options={STATUSES.map((s) => ({ value: s, label: STATUS_LABEL[s] }))}
          onPick={async (v) => { await patchFocused({ status: v as TaskStatus }); setStatusPickerForId(null); }}
          onClose={() => setStatusPickerForId(null)}
        />
      ) : null}
      {priorityPickerForId != null ? (
        <QuickPicker
          label="Priority"
          options={PRIORITIES.map((p) => ({ value: p, label: p }))}
          onPick={async (v) => { await patchFocused({ priority: v as TaskPriority }); setPriorityPickerForId(null); }}
          onClose={() => setPriorityPickerForId(null)}
        />
      ) : null}
    </div>
  );
}

function QuickPicker({ label, options, onPick, onClose }: {
  label: string;
  options: Array<{ value: string; label: string }>;
  onPick: (v: string) => void;
  onClose: () => void;
}): JSX.Element {
  const [active, setActive] = useState(0);
  return (
    <div className="palette-backdrop" onMouseDown={onClose}>
      <div className="palette" onMouseDown={(e) => e.stopPropagation()}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown') { e.preventDefault(); setActive((v) => Math.min(v + 1, options.length - 1)); return; }
          if (e.key === 'ArrowUp')   { e.preventDefault(); setActive((v) => Math.max(v - 1, 0)); return; }
          if (e.key === 'Enter') { e.preventDefault(); onPick(options[active]!.value); return; }
          if (e.key === 'Escape') { onClose(); }
        }}
        tabIndex={-1}
        ref={(el) => el?.focus()}
      >
        <div style={{ padding: '0.6rem 1rem', borderBottom: '1px solid var(--border)', fontSize: 'var(--text-sm)', color: 'var(--text-3)' }}>{label}</div>
        <ul>
          {options.map((o, i) => (
            <li key={o.value} className={i === active ? 'active' : ''} onMouseEnter={() => setActive(i)} onClick={() => onPick(o.value)}>
              <span>{o.label}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// ---------- Filter bar ----------------------------------------------------

interface FilterBarProps {
  searchRef: React.RefObject<HTMLInputElement>;
  search: string;
  onSearch: (v: string) => void;
  priorityFilter: TaskPriority | null;
  onPriority: (v: TaskPriority | null) => void;
  cycleFilter: 'all' | 'none' | number;
  onCycle: (v: 'all' | 'none' | number) => void;
  cycles: Cycle[];
  hideCancelled: boolean;
  onHideCancelled: (v: boolean) => void;
  savedViews: SavedView[];
  onSaveView: () => void;
  onApplyView: (v: SavedView) => void;
  onDeleteView: (id: number) => void;
  templates: Template[];
  templateMenuOpen: boolean;
  onToggleTemplateMenu: () => void;
  onCreate: () => void;
  onCreateFromTemplate: (t: Template) => void;
  groupBy: 'status' | 'priority' | 'assignee' | 'cycle' | 'label' | 'none';
  onGroupBy: (v: 'status' | 'priority' | 'assignee' | 'cycle' | 'label' | 'none') => void;
}

function FilterBar(p: FilterBarProps): JSX.Element {
  return (
    <div className="filter-bar" onClick={(e) => e.stopPropagation()}>
      <div className="search">
        <Icon name="search" size={14} />
        <input
          ref={p.searchRef}
          type="search"
          value={p.search}
          onChange={(e) => p.onSearch(e.target.value)}
          placeholder="Search this project… (/)"
        />
      </div>
      <button
        type="button"
        className={`chip ${p.priorityFilter === null ? 'active' : ''}`}
        onClick={() => p.onPriority(null)}
      >All priorities</button>
      {PRIORITIES.map((pr) => (
        <button
          key={pr}
          type="button"
          className={`chip ${p.priorityFilter === pr ? 'active' : ''}`}
          onClick={() => p.onPriority(pr === p.priorityFilter ? null : pr)}
        >
          <PriorityIcon priority={pr} size={12} />
          <span>{pr}</span>
        </button>
      ))}

      <select
        value={p.cycleFilter === 'all' ? 'all' : p.cycleFilter === 'none' ? 'none' : String(p.cycleFilter)}
        onChange={(e) => {
          const v = e.target.value;
          if (v === 'all' || v === 'none') p.onCycle(v);
          else p.onCycle(Number(v));
        }}
        style={{ width: 'auto', padding: '0.25rem 0.4rem' }}
        title="Cycle"
      >
        <option value="all">All cycles</option>
        <option value="none">No cycle</option>
        {p.cycles.map((c) => (
          <option key={c.id} value={c.id}>
            {c.status === 'active' ? '★ ' : ''}Cycle {c.number}{c.name ? `: ${c.name}` : ''}
          </option>
        ))}
      </select>

      <button
        type="button"
        className={`chip ${p.hideCancelled ? 'active' : ''}`}
        onClick={() => p.onHideCancelled(!p.hideCancelled)}
      >Hide cancelled</button>

      {p.savedViews.length > 0 ? (
        <select
          onChange={(e) => {
            const id = Number(e.target.value);
            const v = p.savedViews.find((x) => x.id === id);
            if (v) p.onApplyView(v);
          }}
          style={{ width: 'auto', padding: '0.25rem 0.4rem' }}
          defaultValue=""
        >
          <option value="">Views…</option>
          {p.savedViews.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
        </select>
      ) : null}
      <button type="button" className="chip" onClick={p.onSaveView}>Save view</button>

      <label className="group-by" title="Group the board / list by">
        <span>Group</span>
        <select
          value={p.groupBy}
          onChange={(e) => p.onGroupBy(e.target.value as 'status' | 'priority' | 'assignee' | 'cycle' | 'label' | 'none')}
        >
          {GROUP_BY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </label>

      <div className="spacer" />

      <div style={{ position: 'relative' }}>
        <button type="button" className="secondary small" onClick={p.onCreate}>
          <Icon name="plus" size={14} /> New issue <span className="kbd">c</span>
        </button>
        {p.templates.length > 0 ? (
          <button
            type="button"
            className="ghost small"
            style={{ marginLeft: '0.25rem' }}
            onClick={(e) => { e.stopPropagation(); p.onToggleTemplateMenu(); }}
            aria-label="Templates"
          >
            <Icon name="chevron-down" size={14} />
          </button>
        ) : null}
        {p.templateMenuOpen ? (
          <div className="template-menu" onClick={(e) => e.stopPropagation()}>
            {p.templates.map((t) => (
              <div className="row" key={t.id} onClick={() => p.onCreateFromTemplate(t)}>
                <Icon name="plus" size={12} />
                <span>{t.name}</span>
                <span style={{ marginLeft: 'auto' }}><PriorityIcon priority={t.priority} size={12} /></span>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}

// ---------- Selection bar -------------------------------------------------

interface SelectionBarProps {
  count: number;
  onClear: () => void;
  onStatus: (s: TaskStatus) => void;
  onPriority: (p: TaskPriority) => void;
  onEstimate: (e: number | null) => void;
  onCycle: (cid: number | null) => void;
  onAssignee: (a: string) => void;
  onAddLabel: (labelId: number) => void;
  onDelete: () => void;
  cycles: Cycle[];
  labels: Label[];
}

function SelectionBar(p: SelectionBarProps): JSX.Element {
  return (
    <div className="selection-bar">
      <span className="count">{p.count} selected</span>
      <div className="group">
        <select onChange={(e) => { if (e.target.value) p.onStatus(e.target.value as TaskStatus); e.target.value = ''; }} defaultValue="">
          <option value="" disabled>Status…</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select onChange={(e) => { if (e.target.value) p.onPriority(e.target.value as TaskPriority); e.target.value = ''; }} defaultValue="">
          <option value="" disabled>Priority…</option>
          {PRIORITIES.map((pr) => <option key={pr} value={pr}>{pr}</option>)}
        </select>
        <select onChange={(e) => { if (e.target.value) p.onEstimate(e.target.value === 'null' ? null : Number(e.target.value)); e.target.value = ''; }} defaultValue="">
          <option value="" disabled>Estimate…</option>
          <option value="null">No estimate</option>
          {[1, 2, 3, 5, 8, 13].map((n) => <option key={n} value={n}>{n}</option>)}
        </select>
        <select onChange={(e) => { if (e.target.value) p.onCycle(e.target.value === 'null' ? null : Number(e.target.value)); e.target.value = ''; }} defaultValue="">
          <option value="" disabled>Cycle…</option>
          <option value="null">No cycle</option>
          {p.cycles.map((c) => <option key={c.id} value={c.id}>Cycle {c.number}{c.name ? `: ${c.name}` : ''}</option>)}
        </select>
        <select onChange={(e) => { if (e.target.value !== '') p.onAssignee(e.target.value === '@clear' ? '' : e.target.value); e.target.value = ''; }} defaultValue="">
          <option value="" disabled>Assignee…</option>
          <option value="me">me</option>
          <option value="@clear">unassign</option>
        </select>
        <select onChange={(e) => { if (e.target.value) p.onAddLabel(Number(e.target.value)); e.target.value = ''; }} defaultValue="" disabled={p.labels.length === 0}>
          <option value="" disabled>{p.labels.length === 0 ? 'No labels' : 'Add label…'}</option>
          {p.labels.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>
      </div>
      <span style={{ flex: 1 }} />
      <button type="button" className="danger" onClick={p.onDelete} title="Delete selected">
        Delete
      </button>
      <button type="button" onClick={p.onClear}>Clear</button>
    </div>
  );
}

// ---------- Board ---------------------------------------------------------

interface BoardProps {
  groups: BoardGroup[];
  onMove: (taskId: number, to: TaskStatus) => void;
  onReorder: (status: TaskStatus, orderedIds: number[]) => void;
  onAdd: (status: TaskStatus) => void;
  onOpen: (taskId: number) => void;
  selected: Set<number>;
  onToggleSelect: (taskId: number, mode: 'single' | 'toggle' | 'range') => void;
  focusedId: number | null;
  editingTitleId: number | null;
  onStartEdit: (taskId: number) => void;
  onSubmitTitle: (taskId: number, title: string) => void | Promise<void>;
  onCancelEdit: () => void;
}

function BoardView(p: BoardProps): JSX.Element {
  return (
    <div className="board">
      {p.groups.map((g) => (
        <BoardColumn key={g.key} group={g} {...p} />
      ))}
    </div>
  );
}

interface ColProps extends BoardProps {
  group: BoardGroup;
}

function BoardColumn({ group, onMove, onReorder, onAdd, onOpen, selected, onToggleSelect, focusedId, editingTitleId, onStartEdit, onSubmitTitle, onCancelEdit }: ColProps): JSX.Element {
  const [dragOverId, setDragOverId] = useState<number | 'end' | null>(null);
  const [dragOverCol, setDragOverCol] = useState(false);
  const tasks = group.tasks;
  const droppable = group.statusForDnd != null;

  function dropOnColumn(e: DragEvent<HTMLDivElement>): void {
    if (!droppable) return;
    e.preventDefault();
    setDragOverCol(false);
    setDragOverId(null);
    const target = group.statusForDnd!;
    const id = Number(e.dataTransfer.getData('text/task-id'));
    const fromStatus = e.dataTransfer.getData('text/from-status') as TaskStatus;
    if (!Number.isInteger(id)) return;
    if (fromStatus === target) {
      const ids = tasks.map((t) => t.id).filter((x) => x !== id);
      ids.push(id);
      onReorder(target, ids);
    } else {
      onMove(id, target);
    }
  }

  function dropOnCard(e: DragEvent<HTMLDivElement>, beforeId: number): void {
    if (!droppable) return;
    e.preventDefault();
    e.stopPropagation();
    setDragOverCol(false);
    setDragOverId(null);
    const target = group.statusForDnd!;
    const id = Number(e.dataTransfer.getData('text/task-id'));
    const fromStatus = e.dataTransfer.getData('text/from-status') as TaskStatus;
    if (!Number.isInteger(id) || id === beforeId) return;
    if (fromStatus === target) {
      const ids = tasks.map((t) => t.id).filter((x) => x !== id);
      const idx = ids.indexOf(beforeId);
      ids.splice(idx, 0, id);
      onReorder(target, ids);
    } else {
      onMove(id, target);
    }
  }

  const columnClass = group.iconStatus ? `column column-${group.iconStatus}` : 'column';

  return (
    <div
      className={`${columnClass} ${dragOverCol && droppable ? 'drag-over' : ''}`}
      onDragOver={(e) => { if (droppable) { e.preventDefault(); setDragOverCol(true); } }}
      onDragLeave={() => setDragOverCol(false)}
      onDrop={dropOnColumn}
    >
      <header>
        {group.iconStatus ? <StatusIcon status={group.iconStatus} size={14} /> : null}
        {group.swatch ? <span className="status-dot" style={{ background: group.swatch }} /> : null}
        <strong>{group.label}</strong>
        <span className="count">{tasks.length}</span>
        {group.statusForDnd ? (
          <button type="button" className="add-btn" onClick={() => onAdd(group.statusForDnd!)} aria-label={`Add issue to ${group.label}`}>
            <Icon name="plus" size={14} />
          </button>
        ) : null}
      </header>
      <div className="scroll">
        {tasks.map((t) => (
          <TaskCard
            key={t.id}
            task={t}
            selected={selected.has(t.id)}
            focused={focusedId === t.id}
            onOpen={() => onOpen(t.id)}
            onToggleSelect={onToggleSelect}
            onDropBefore={(e) => dropOnCard(e, t.id)}
            isDropTarget={dragOverId === t.id}
            onDragEnter={() => setDragOverId(t.id)}
            editing={editingTitleId === t.id}
            onStartEdit={() => onStartEdit(t.id)}
            onSubmitTitle={(title) => onSubmitTitle(t.id, title)}
            onCancelEdit={onCancelEdit}
          />
        ))}
        {tasks.length === 0 ? <div className="muted xsmall" style={{ padding: '0.5rem' }}>{droppable ? 'Drop here' : 'Empty'}</div> : null}
      </div>
    </div>
  );
}

interface TaskCardProps {
  task: Task;
  selected: boolean;
  focused: boolean;
  onOpen: () => void;
  onToggleSelect: (id: number, mode: 'single' | 'toggle' | 'range') => void;
  onDropBefore: (e: DragEvent<HTMLDivElement>) => void;
  isDropTarget: boolean;
  onDragEnter: () => void;
  editing: boolean;
  onStartEdit: () => void;
  onSubmitTitle: (title: string) => void | Promise<void>;
  onCancelEdit: () => void;
}

function TaskCard({ task, selected, focused, onOpen, onToggleSelect, onDropBefore, isDropTarget, onDragEnter, editing, onStartEdit, onSubmitTitle, onCancelEdit }: TaskCardProps): JSX.Element {
  function onDragStart(e: DragEvent<HTMLDivElement>): void {
    e.dataTransfer.setData('text/task-id', String(task.id));
    e.dataTransfer.setData('text/from-status', task.status);
    e.dataTransfer.effectAllowed = 'move';
    (e.currentTarget as HTMLDivElement).classList.add('dragging');
  }
  function onDragEnd(e: DragEvent<HTMLDivElement>): void {
    (e.currentTarget as HTMLDivElement).classList.remove('dragging');
  }
  function click(e: MouseEvent<HTMLDivElement>): void {
    if (e.metaKey || e.ctrlKey) { onToggleSelect(task.id, 'toggle'); return; }
    if (e.shiftKey) { onToggleSelect(task.id, 'range'); return; }
    onOpen();
  }
  return (
    <div
      className={`task-card ${selected ? 'selected' : ''} ${focused ? 'focused' : ''}`}
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onDragOver={(e) => { e.preventDefault(); onDragEnter(); }}
      onDrop={onDropBefore}
      onClick={click}
      role="button"
      tabIndex={0}
      style={isDropTarget ? { borderTopColor: 'var(--accent)', borderTopWidth: 3 } : undefined}
    >
      <div className="header">
        <span className={`priority-pill p-${task.priority}`}><PriorityIcon priority={task.priority} /></span>
        <span className="key">{task.key}</span>
        <EstimateBadge value={task.estimate} />
      </div>
      <EditableTitle
        as="div"
        className="title"
        value={task.title}
        editing={editing}
        onSubmit={onSubmitTitle}
        onCancel={onCancelEdit}
        onActivate={onStartEdit}
      />
      {task.labels.length > 0 || task.subtasks.length > 0 || task.children.length > 0 ? (
        <div className="labels">
          {task.labels.map((l) => (
            <span key={l.id} className="label-chip">
              <span className="dot" style={{ background: l.color }} />
              {l.name}
            </span>
          ))}
          {task.subtasks.length > 0 ? (
            <span className="label-chip muted">☐ {task.subtasks.filter((s) => s.done).length}/{task.subtasks.length}</span>
          ) : null}
          {task.children.length > 0 ? (
            <span className="label-chip muted">↳ {task.children.filter((c) => c.status === 'done').length}/{task.children.length}</span>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

// ---------- List ----------------------------------------------------------

interface ListProps {
  tasks: Task[];
  onOpen: (id: number) => void;
  onChanged: () => void;
  selected: Set<number>;
  onToggleSelect: (id: number, mode: 'single' | 'toggle' | 'range') => void;
  focusedId: number | null;
  editingTitleId: number | null;
  onStartEdit: (taskId: number) => void;
  onSubmitTitle: (taskId: number, title: string) => void | Promise<void>;
  onCancelEdit: () => void;
}

function ListView({ tasks, onOpen, onChanged, selected, onToggleSelect, focusedId, editingTitleId, onStartEdit, onSubmitTitle, onCancelEdit }: ListProps): JSX.Element {
  return (
    <div className="list-view">
      <table>
        <thead>
          <tr>
            <th style={{ width: 24 }}></th>
            <th>Key</th>
            <th>Title</th>
            <th>Assignee</th>
            <th>Due</th>
            <th style={{ width: 40 }}>Est</th>
            <th style={{ width: 40 }}>Pri</th>
          </tr>
        </thead>
        <tbody>
          {tasks.length === 0 ? (
            <tr><td colSpan={7} className="muted" style={{ textAlign: 'center', padding: '1.5rem' }}>No issues match.</td></tr>
          ) : tasks.map((t) => (
            <tr
              key={t.id}
              className={`${selected.has(t.id) ? 'selected' : ''} ${focusedId === t.id ? 'focused' : ''}`}
              onClick={(e) => {
                if (e.metaKey || e.ctrlKey) { onToggleSelect(t.id, 'toggle'); return; }
                if (e.shiftKey) { onToggleSelect(t.id, 'range'); return; }
                onOpen(t.id);
              }}
            >
              <td>
                <span
                  style={{ display: 'inline-flex' }}
                  onClick={async (e) => {
                    e.stopPropagation();
                    // cycle status
                    const order: TaskStatus[] = ['backlog', 'todo', 'started', 'review', 'done', 'cancelled'];
                    const idx = order.indexOf(t.status);
                    const next = order[(idx + 1) % order.length]!;
                    await api.updateTask(t.id, { status: next });
                    onChanged();
                  }}
                >
                  <StatusIcon status={t.status} size={14} />
                </span>
              </td>
              <td className="key-col">{t.key}</td>
              <td>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <EditableTitle
                    as="strong"
                    style={{ fontWeight: 500 }}
                    value={t.title}
                    editing={editingTitleId === t.id}
                    onSubmit={(title) => onSubmitTitle(t.id, title)}
                    onCancel={onCancelEdit}
                    onActivate={() => onStartEdit(t.id)}
                  />
                  {t.labels.map((l) => (
                    <span key={l.id} className="label-chip"><span className="dot" style={{ background: l.color }} />{l.name}</span>
                  ))}
                </div>
              </td>
              <td>{t.assignee || ''}</td>
              <td>{t.due_date ?? ''}</td>
              <td><EstimateBadge value={t.estimate} /></td>
              <td><span className={`priority-pill p-${t.priority}`}><PriorityIcon priority={t.priority} /></span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------- Cycles --------------------------------------------------------

function CyclesView({ cycles, projectId, onChanged }: { cycles: Cycle[]; projectId: number; onChanged: () => void }): JSX.Element {
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [start, setStart] = useState(new Date().toISOString().slice(0, 10));
  const [end, setEnd] = useState(new Date(Date.now() + 14 * 86_400_000).toISOString().slice(0, 10));

  async function create(): Promise<void> {
    try {
      await api.createCycle(projectId, { name: name.trim(), start_date: start, end_date: end });
      setCreating(false);
      setName('');
      onChanged();
    } catch { /* show inline? */ }
  }

  async function remove(id: number): Promise<void> {
    if (!confirm('Delete this cycle? Issues stay but become uncycled.')) return;
    await api.deleteCycle(projectId, id);
    onChanged();
  }

  const groups = {
    active: cycles.filter((c) => c.status === 'active'),
    upcoming: cycles.filter((c) => c.status === 'upcoming'),
    completed: cycles.filter((c) => c.status === 'completed'),
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
        <h2 style={{ fontSize: 'var(--text-lg)' }}>Cycles</h2>
        <span style={{ flex: 1 }} />
        <button type="button" onClick={() => setCreating((v) => !v)}>
          <Icon name="plus" size={14} /> {creating ? 'Cancel' : 'New cycle'}
        </button>
      </div>

      {creating ? (
        <div className="card">
          <label>Name (optional)<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sprint 1" /></label>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
            <label>Start<input type="date" value={start} onChange={(e) => setStart(e.target.value)} /></label>
            <label>End<input type="date" value={end} onChange={(e) => setEnd(e.target.value)} /></label>
          </div>
          <button type="button" onClick={create} style={{ marginTop: '0.5rem' }}>Create</button>
        </div>
      ) : null}

      <CycleGroup title="Active" cycles={groups.active} onDelete={remove} />
      <CycleGroup title="Upcoming" cycles={groups.upcoming} onDelete={remove} />
      <CycleGroup title="Completed" cycles={groups.completed} onDelete={remove} />
    </div>
  );
}

function CycleGroup({ title, cycles, onDelete }: { title: string; cycles: Cycle[]; onDelete: (id: number) => void }): JSX.Element {
  if (cycles.length === 0) return <></>;
  return (
    <div style={{ marginBottom: '1rem' }}>
      <div className="section-heading">{title}</div>
      {cycles.map((c) => (
        <div key={c.id} className={`cycle-card ${c.status === 'active' ? 'active' : ''}`}>
          <span className="badge">{c.status}</span>
          <strong>Cycle {c.number}</strong>
          {c.name ? <span style={{ color: 'var(--text-2)' }}>· {c.name}</span> : null}
          <span className="dates">{c.start_date} → {c.end_date}</span>
          {c.task_count !== undefined ? (
            <>
              <span className="progress" aria-label="completion">
                <span className="fill" style={{ width: `${(c.task_count ? (c.done_count ?? 0) / c.task_count : 0) * 100}%` }} />
              </span>
              <span className="muted xsmall">{c.done_count ?? 0}/{c.task_count}</span>
            </>
          ) : null}
          <button type="button" className="icon ghost" onClick={() => onDelete(c.id)} aria-label="Delete cycle"><Icon name="trash" size={14} /></button>
        </div>
      ))}
    </div>
  );
}

// ---------- Insights ------------------------------------------------------

function InsightsView({ projectId }: { projectId: number }): JSX.Element {
  const [data, setData] = useState<ProjectInsights | null>(null);

  useEffect(() => {
    api.getInsights(projectId).then(setData).catch(() => setData(null));
  }, [projectId]);

  if (!data) {
    return <div className="insights-grid">
      <div className="insights-card"><div className="skeleton" style={{ height: 64 }} /></div>
      <div className="insights-card"><div className="skeleton" style={{ height: 64 }} /></div>
      <div className="insights-card"><div className="skeleton" style={{ height: 64 }} /></div>
    </div>;
  }

  const totalOpen = data.byStatus.filter((s) => s.status !== 'done' && s.status !== 'cancelled').reduce((a, b) => a + b.n, 0);
  const totalDone = data.byStatus.find((s) => s.status === 'done')?.n ?? 0;
  const priorityMax = Math.max(1, ...data.byPriority.map((p) => p.n));
  const assigneeMax = Math.max(1, ...data.byAssignee.map((p) => p.n));
  // Pad completion to 14 days back so the sparkline is even-width.
  const last14: number[] = Array.from({ length: 14 }, (_v, i) => {
    const target = new Date(Date.now() - (13 - i) * 86_400_000).toISOString().slice(0, 10);
    const row = data.completion.find((c) => c.day === target);
    return row ? row.n : 0;
  });
  const completionMax = Math.max(1, ...last14);

  return (
    <div className="insights-grid">
      <div className="insights-card">
        <h3>Open issues</h3>
        <div className="big-number">{totalOpen}</div>
        <p className="muted small">{totalDone} completed all-time</p>
      </div>
      <div className="insights-card">
        <h3>By priority (open)</h3>
        <div className="bars">
          {PRIORITIES.map((p) => {
            const row = data.byPriority.find((r) => r.priority === p);
            const n = row?.n ?? 0;
            return (
              <div className="row" key={p}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}><PriorityIcon priority={p} size={12} /> {p}</span>
                <span className="bar"><span className="fill" style={{ width: `${(n / priorityMax) * 100}%` }} /></span>
                <span style={{ textAlign: 'right' }}>{n}</span>
              </div>
            );
          })}
        </div>
      </div>
      <div className="insights-card">
        <h3>By assignee (open)</h3>
        <div className="bars">
          {data.byAssignee.slice(0, 6).map((row) => (
            <div className="row" key={row.assignee}>
              <span>{row.assignee.split('@')[0]}</span>
              <span className="bar"><span className="fill" style={{ width: `${(row.n / assigneeMax) * 100}%` }} /></span>
              <span style={{ textAlign: 'right' }}>{row.n}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="insights-card">
        <h3>Completed (14d)</h3>
        <div className="sparkline">
          {last14.map((n, i) => (
            <span key={i} className="col" style={{ height: `${Math.max(4, (n / completionMax) * 60)}px` }} title={`${n} on day -${13 - i}`} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- Code Map (aider-style repo map) --------------------------------

function CodeMapView(): JSX.Element {
  const [data, setData] = useState<import('../api.js').RepoMap | null>(null);
  const [filter, setFilter] = useState('');
  // Track which top-level groups are open. Default-open the source dirs.
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({ apps: true, harness: true });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.repoMap().then(setData).catch((e) => setError((e as Error).message));
  }, []);

  if (error) return <div className="codemap-empty">Could not load repo map: {error}</div>;
  if (!data) return <div className="codemap-loading">Walking the repo…</div>;

  const lower = filter.toLowerCase().trim();
  const filtered = lower === '' ? data.groups : data.groups
    .map((g) => ({
      ...g,
      files: g.files.filter((f) =>
        f.rel.toLowerCase().includes(lower) ||
        f.symbols.some((s) => s.toLowerCase().includes(lower)),
      ),
    }))
    .filter((g) => g.files.length > 0);

  function toggle(top: string): void {
    setOpenGroups((g) => ({ ...g, [top]: !g[top] }));
  }

  return (
    <div className="codemap">
      <div className="codemap-toolbar">
        <input
          type="text"
          className="codemap-filter"
          placeholder="Filter files or symbols…"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        <span className="codemap-meta">{data.total_files} files</span>
      </div>

      <div className="codemap-tree">
        {filtered.length === 0 ? (
          <div className="codemap-empty">No matches.</div>
        ) : filtered.map((g) => {
          const isOpen = lower !== '' || openGroups[g.top] !== false;
          return (
            <section key={g.top} className={`codemap-group ${isOpen ? 'open' : ''}`}>
              <button type="button" className="codemap-group-header" onClick={() => toggle(g.top)}>
                <Icon name={isOpen ? 'chevron-down' : 'chevron-right'} size={12} />
                <strong>{g.top}/</strong>
                <span className="codemap-count">{g.files.length}</span>
              </button>
              {isOpen ? (
                <ul className="codemap-files">
                  {g.files.map((f) => (
                    <li key={f.rel} className="codemap-file">
                      <div className="codemap-file-path">{f.rel}</div>
                      {f.symbols.length > 0 ? (
                        <div className="codemap-symbols">
                          {f.symbols.map((s) => {
                            const [kind, ...rest] = s.split(' ');
                            return (
                              <span key={s} className={`codemap-symbol kind-${kind}`} title={SYMBOL_KIND_LABEL[kind ?? ''] ?? kind}>
                                <span className="codemap-symbol-kind">{kind}</span>
                                <span className="codemap-symbol-name">{rest.join(' ')}</span>
                              </span>
                            );
                          })}
                        </div>
                      ) : null}
                    </li>
                  ))}
                </ul>
              ) : null}
            </section>
          );
        })}
      </div>
    </div>
  );
}

const SYMBOL_KIND_LABEL: Record<string, string> = {
  f: 'function',
  c: 'class',
  t: 'type / interface',
  x: 'const',
  d: 'def',
};

// ---------- Group derivation -----------------------------------------------

interface BoardGroup {
  key: string;
  label: string;
  // When grouping by status, DnD onto a column mutates `task.status` to this.
  // null for other groupings (priority etc.) — DnD between groups is disabled
  // because changing priority/assignee/label-on-drop is more confusing than
  // helpful in a single click.
  statusForDnd: TaskStatus | null;
  // Status used to pick the column's accent icon. For non-status groupings,
  // fall back to a generic icon-less header.
  iconStatus: TaskStatus | null;
  // Optional swatch color shown next to the label (used for cycle/label groups).
  swatch?: string;
  tasks: Task[];
}

const GROUP_BY_OPTIONS: Array<{ value: 'status' | 'priority' | 'assignee' | 'cycle' | 'label' | 'none'; label: string }> = [
  { value: 'status',   label: 'Status' },
  { value: 'priority', label: 'Priority' },
  { value: 'assignee', label: 'Assignee' },
  { value: 'cycle',    label: 'Cycle' },
  { value: 'label',    label: 'Label' },
  { value: 'none',     label: 'No grouping' },
];

const STATUS_LABEL_LOCAL: Record<TaskStatus, string> = {
  backlog: 'Backlog', todo: 'Todo', started: 'In progress', review: 'In review', done: 'Done', cancelled: 'Cancelled',
};

function deriveGroups(
  by: 'status' | 'priority' | 'assignee' | 'cycle' | 'label' | 'none',
  tasks: Task[],
  cycles: Cycle[],
  labels: Label[],
): BoardGroup[] {
  if (by === 'none') {
    return [{ key: 'all', label: 'All issues', statusForDnd: null, iconStatus: null, tasks }];
  }
  if (by === 'status') {
    const order: TaskStatus[] = ['backlog', 'todo', 'started', 'review', 'done', 'cancelled'];
    return order.map((s) => ({
      key: s,
      label: STATUS_LABEL_LOCAL[s],
      statusForDnd: s,
      iconStatus: s,
      tasks: tasks.filter((t) => t.status === s),
    }));
  }
  if (by === 'priority') {
    const order: TaskPriority[] = ['urgent', 'high', 'med', 'low'];
    return order.map((p) => ({
      key: p,
      label: p.charAt(0).toUpperCase() + p.slice(1),
      statusForDnd: null,
      iconStatus: null,
      tasks: tasks.filter((t) => t.priority === p),
    }));
  }
  if (by === 'assignee') {
    const byName = new Map<string, Task[]>();
    for (const t of tasks) {
      const k = t.assignee || '(unassigned)';
      const arr = byName.get(k) ?? [];
      arr.push(t);
      byName.set(k, arr);
    }
    return Array.from(byName.entries())
      .sort(([a], [b]) => (a === '(unassigned)' ? 1 : b === '(unassigned)' ? -1 : a.localeCompare(b)))
      .map(([assignee, ts]) => ({
        key: assignee, label: assignee.split('@')[0] ?? assignee,
        statusForDnd: null, iconStatus: null, tasks: ts,
      }));
  }
  if (by === 'cycle') {
    const grouped = new Map<number | null, Task[]>();
    for (const t of tasks) {
      const k = t.cycle_id ?? null;
      const arr = grouped.get(k) ?? [];
      arr.push(t);
      grouped.set(k, arr);
    }
    const out: BoardGroup[] = [];
    for (const c of cycles) {
      const ts = grouped.get(c.id) ?? [];
      if (ts.length === 0) continue;
      out.push({
        key: `cycle:${c.id}`,
        label: `${c.status === 'active' ? '★ ' : ''}Cycle ${c.number}${c.name ? `: ${c.name}` : ''}`,
        statusForDnd: null, iconStatus: null, tasks: ts,
      });
    }
    const none = grouped.get(null);
    if (none && none.length > 0) out.push({ key: 'cycle:none', label: 'No cycle', statusForDnd: null, iconStatus: null, tasks: none });
    return out;
  }
  if (by === 'label') {
    const out: BoardGroup[] = [];
    for (const l of labels) {
      const ts = tasks.filter((t) => t.labels.some((tl) => tl.id === l.id));
      if (ts.length === 0) continue;
      out.push({
        key: `label:${l.id}`,
        label: l.name,
        statusForDnd: null, iconStatus: null, tasks: ts, swatch: l.color,
      });
    }
    const unlabelled = tasks.filter((t) => t.labels.length === 0);
    if (unlabelled.length > 0) out.push({ key: 'label:none', label: 'No labels', statusForDnd: null, iconStatus: null, tasks: unlabelled });
    return out;
  }
  return [];
}

// ---------- Skeleton ------------------------------------------------------

function ProjectSkeleton(): JSX.Element {
  return (
    <div>
      <div className="project-header">
        <div className="skeleton" style={{ width: 28, height: 28, borderRadius: 6 }} />
        <div className="skeleton" style={{ width: 180, height: 24 }} />
      </div>
      <div className="skeleton" style={{ width: '60%', height: 14, marginTop: '0.4rem' }} />
      <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
        {[1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ flex: 1, height: 280, borderRadius: 8 }} />)}
      </div>
    </div>
  );
}
