import { Link } from 'react-router-dom';

export function Landing({ hasUser }: { hasUser: boolean }): JSX.Element {
  return (
    <main className="auth-page">
      <div className="auth-card" style={{ maxWidth: 460, textAlign: 'center' }}>
        <h1>Project work with an AI teammate</h1>
        <p className="muted small" style={{ margin: '0.75rem 0 1.5rem' }}>
          Linear-style projects, tasks, and a sidebar that opens an agent who can
          actually read your work and act on it. Bring any model — Claude
          Pro, Anthropic / OpenAI API keys, or a local model via Ollama.
        </p>
        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'center' }}>
          {hasUser ? (
            <Link to="/inbox"><button type="button">Open workspace</button></Link>
          ) : (
            <>
              <Link to="/signup"><button type="button">Get started</button></Link>
              <Link to="/login"><button type="button" className="secondary">Log in</button></Link>
            </>
          )}
        </div>
        <p className="muted xsmall" style={{ marginTop: '1.25rem' }}>
          Tip: run <code>./app</code> in your terminal — same workspace, plus a Claude-Code-style chat REPL in your shell.
        </p>
      </div>
    </main>
  );
}
