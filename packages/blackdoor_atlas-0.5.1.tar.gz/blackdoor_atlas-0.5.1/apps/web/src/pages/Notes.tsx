import { type FormEvent, useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { api, type Note, type User } from '../api.js';

export function Notes({ user }: { user: User | null }): JSX.Element {
  const [notes, setNotes] = useState<Note[]>([]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  useEffect(() => {
    if (!user) return;
    void refresh();
  }, [user]);

  async function refresh(): Promise<void> {
    const next = await api.listNotes();
    setNotes(next);
  }

  if (!user) return <Navigate to="/login" replace />;

  async function create(e: FormEvent<HTMLFormElement>): Promise<void> {
    e.preventDefault();
    if (!title.trim()) return;
    await api.createNote(title, body);
    setTitle('');
    setBody('');
    await refresh();
  }

  async function saveEdit(id: number): Promise<void> {
    await api.updateNote(id, { title: editingTitle });
    setEditingId(null);
    setEditingTitle('');
    await refresh();
  }

  async function remove(id: number): Promise<void> {
    await api.deleteNote(id);
    await refresh();
  }

  return (
    <main aria-label="Notes">
      <h1>Notes</h1>

      <form onSubmit={create} aria-label="Create note form">
        <label>
          Title
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </label>
        <label>
          Body
          <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={3} />
        </label>
        <button type="submit">Add note</button>
      </form>

      <ul className="notes" aria-label="Notes list">
        {notes.map((n) => (
          <li key={n.id}>
            {editingId === n.id ? (
              <>
                <label>
                  Title
                  <input
                    value={editingTitle}
                    onChange={(e) => setEditingTitle(e.target.value)}
                    aria-label={`Edit title for note ${n.id}`}
                  />
                </label>
                <button type="button" onClick={() => void saveEdit(n.id)}>
                  Save
                </button>
                <button
                  type="button"
                  className="secondary"
                  onClick={() => {
                    setEditingId(null);
                    setEditingTitle('');
                  }}
                >
                  Cancel
                </button>
              </>
            ) : (
              <>
                <strong>{n.title}</strong>
                <p>{n.body}</p>
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(n.id);
                    setEditingTitle(n.title);
                  }}
                  aria-label={`Edit ${n.title}`}
                >
                  Edit
                </button>
                <button
                  type="button"
                  className="secondary"
                  onClick={() => void remove(n.id)}
                  aria-label={`Delete ${n.title}`}
                >
                  Delete
                </button>
              </>
            )}
          </li>
        ))}
        {notes.length === 0 ? <li>No notes yet — create one above.</li> : null}
      </ul>
    </main>
  );
}
