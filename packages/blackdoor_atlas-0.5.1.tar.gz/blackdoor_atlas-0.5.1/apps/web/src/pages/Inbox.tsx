import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, type Inbox as InboxData, type Task } from '../api.js';
import { TaskRow } from '../components/TaskRow.js';
import { TaskDrawer } from '../components/TaskDrawer.js';

export function Inbox(): JSX.Element {
  const [data, setData] = useState<InboxData | null>(null);
  const [openTaskId, setOpenTaskId] = useState<number | null>(null);
  const navigate = useNavigate();

  const refresh = useCallback(async () => {
    try {
      setData(await api.inbox());
    } catch {
      setData({ open: [], recent_done: [] });
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  if (!data) {
    return <div className="muted">Loading inbox…</div>;
  }

  const grouped = groupByProject(data.open);

  return (
    <div className="inbox-page">
      <header>
        <h1>Inbox</h1>
        <span className="count">{data.open.length} open</span>
      </header>

      {data.open.length === 0 ? (
        <div className="empty-state">
          You're all clear. Create a project from the sidebar to start adding work.
        </div>
      ) : (
        Array.from(grouped.entries()).map(([projectId, tasks]) => {
          const first = tasks[0]!;
          return (
            <section key={projectId} style={{ marginBottom: '1.5rem' }}>
              <div
                className="section-heading"
                style={{ cursor: 'pointer' }}
                onClick={() => navigate(`/projects/${projectId}`)}
              >
                <span className="project-swatch" style={{ background: first.project_color, width: 8, height: 8, borderRadius: 999 }} />
                <span>{first.project_name}</span>
                <span className="muted xsmall">{tasks.length}</span>
              </div>
              <ul className="task-list">
                {tasks.map((t) => (
                  <TaskRow key={t.id} task={t} onOpen={() => setOpenTaskId(t.id)} onChanged={() => void refresh()} />
                ))}
              </ul>
            </section>
          );
        })
      )}

      {data.recent_done.length > 0 ? (
        <section>
          <div className="section-heading">Completed this week</div>
          <ul className="task-list">
            {data.recent_done.map((t) => (
              <TaskRow key={t.id} task={t} onOpen={() => setOpenTaskId(t.id)} onChanged={() => void refresh()} />
            ))}
          </ul>
        </section>
      ) : null}

      {openTaskId != null ? (
        <TaskDrawer taskId={openTaskId} onClose={() => setOpenTaskId(null)} onChanged={() => void refresh()} />
      ) : null}
    </div>
  );
}

function groupByProject(tasks: Task[]): Map<number, Task[]> {
  const map = new Map<number, Task[]>();
  for (const t of tasks) {
    const arr = map.get(t.project_id) ?? [];
    arr.push(t);
    map.set(t.project_id, arr);
  }
  return map;
}
