"""ATLAS — a terminal AI harness with a built-in project workspace.

The wordmark says it: *shift the world, reach beyond yourself*. ATLAS is a
chat-first agent CLI in the spirit of Claude Code, Codex, hermes, and aider,
but with a real PM workspace (projects, cycles, issues, multi-workspace) so
humans manage agents and work alongside them in one place.

This package is the *CLI half* — the `atlas` command that drops into a REPL
in whatever folder you launch it from. The web dashboard (Day 12) is the
`atlas dash` sidecar; the REST API (Day 8-10) lives at `atlas.dash.server`.

Run::

    pipx install -e .
    atlas

from any directory.
"""

# release-please-start-version
__version__ = "0.1.5"
# release-please-end
__all__ = ["__version__"]
