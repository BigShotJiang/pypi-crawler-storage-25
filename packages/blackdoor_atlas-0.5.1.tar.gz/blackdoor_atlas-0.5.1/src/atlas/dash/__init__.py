"""Optional web dashboard — FastAPI + the React frontend.

Lands Day 8-12:

  server.py    # FastAPI app factory, mounts routes + static frontend
  routes/      # auth, companies, projects, tasks, cycles, agent (SSE)
  static/      # apps/web/dist/ build output, served at /
  launcher.py  # `atlas dash` subprocess spawn + browser open + /healthz wait

Same SQLite file as the CLI agent. Same JSON contracts as the legacy Node
API, so the React frontend ports over with zero changes.
"""
