# Web dashboard — local conventions

Read this when working under `src/atlas/dash/`. The root
[`AGENTS.md`](../../../AGENTS.md) still applies.

## What lives here

- `server.py` — FastAPI app factory. Mounts routes, serves the React
  build from `static/`, exposes `/healthz`.
- `auth.py` — session cookie auth (`require_user`, `require_company`).
  Single-user default; `ATLAS_DASH_REQUIRE_LOGIN=1` flips on real auth.
- `routes/` — one file per concern, mirrors the legacy Express server
  at `apps/api/src/routes/`:
   - `auth.py` — /api/auth/*
   - `companies.py` — /api/companies/*
   - `projects.py` — /api/projects/*
   - `tasks.py` — /api/tasks/*
   - `cycles.py` — /api/projects/{id}/{cycles,insights,views,templates}
   - `agent.py` — /api/agent/* including the SSE chat route
- `launcher.py` — `atlas dash` subprocess (pipx) / in-process (binary)
  spawn logic.
- `static/` — built from `apps/web/` by `make build`; not tracked in git.

## Adding a new route

1. Find or create the right file under `routes/`. Group by concern
   (one file per `/api/<name>/*` prefix).
2. Use the `Depends(require_user)` and `Depends(require_company)`
   middleware — don't reinvent auth.
3. JSON shapes must match what the React frontend at `apps/web/`
   already sends/receives. Same field names, same types, same status
   codes. The legacy TS server's route in `apps/api/src/routes/` is
   the canonical reference.
4. Mount the router in `server.py`'s `create_app()`.
5. Smoke test:
   ```python
   from fastapi.testclient import TestClient
   from atlas.dash.server import create_app
   c = TestClient(create_app())
   c.get('/api/auth/me')
   ```

## Adding a DB-backed entity (a new repo)

1. New file at `src/atlas/repos/<name>.py`. Module-level functions,
   not classes (idiomatic Python). One function per operation.
2. Use `from atlas.db.connection import connect`. Don't open your own
   sqlite connection.
3. Schema changes go in `src/atlas/db/schema.py`, in the idempotent
   `_add_columns()` block. Never `ALTER TABLE ... DROP COLUMN` — that
   breaks downgrades.
4. Expose the repo's data via a route in `routes/`. The route does
   validation + auth; the repo does SQL.

## SSE / streaming

`/api/agent/chat` is the load-bearing SSE endpoint. Pattern:

- Spawn the runner on a worker thread (it's sync).
- Put events on a `queue.Queue`.
- An async generator drains the queue and yields `{event, data}` dicts.
- Heartbeat every ~3s when no events arrive so dropped TCP gets
  noticed quickly.
- Watch `request.is_disconnected()` so we can flip the cancel flag
  when the client tab closes.

If you need another streaming route, copy that pattern — don't try to
make the runner itself async (it'd cascade through every provider).

## Static frontend

`make build` regenerates `static/` from `apps/web/dist`. Hatchling
auto-includes it in the wheel; PyInstaller picks it up via
`datas=...` in `packaging/atlas.spec`. The release workflow runs
`npm install && npm run build` before any wheel or binary build.

Don't `git add` anything under `static/` — it's in `.gitignore`.
