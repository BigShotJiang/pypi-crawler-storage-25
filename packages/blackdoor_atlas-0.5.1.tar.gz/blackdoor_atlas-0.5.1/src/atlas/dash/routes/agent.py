"""/api/agent — chat (SSE), permission decisions, session search, repo map.

The chat endpoint is the load-bearing one: it streams agent events out as
SSE so the React UI renders deltas live. Internally it spawns the runner
on a worker thread and pipes events into an asyncio queue the SSE
generator reads from. This lets the Provider protocol stay synchronous
while the HTTP layer stays cleanly async.

Permission decisions, session search, recent sessions, and the repo map
are small companion endpoints — same shape as the legacy Express ones.
"""

from __future__ import annotations

import asyncio
import json
import queue
import threading
import time
from dataclasses import asdict
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse

from atlas.agent import sessions as sessions_mod
from atlas.agent.permissions import Decision, decide
from atlas.agent.providers import list_providers, select_provider
from atlas.agent.repo_map import repo_map_data
from atlas.agent.runner import RunOptions, run_agent
from atlas.agent.types import AgentEvent, ChatMessage
from atlas.dash.auth import require_user
from atlas.repos import company as company_repo
from atlas.repos import user as user_repo


router = APIRouter(prefix="/api/agent", tags=["agent"])


# --- info -----------------------------------------------------------------


@router.get("/info")
def info() -> dict:
    active = select_provider()
    return {
        "active": ({"id": active.id, "model": active.model} if active else None),
        "providers": [asdict(p) for p in list_providers()],
    }


# --- chat (SSE) -----------------------------------------------------------


class ChatRequest(BaseModel):
    messages: list[dict] = Field(min_length=1)
    thinking: bool | None = False
    effort: str | None = None      # low | medium | high | xhigh | max
    mode: str | None = "code"      # code | ask | plan
    scope_files: list[str] | None = None
    confirm: bool | None = False
    scope_root: str | None = None  # cwd to scope tools to; defaults to user's home


@router.post("/chat")
async def chat(req: ChatRequest, request: Request,
               user: user_repo.User = Depends(require_user)) -> EventSourceResponse:
    """Stream one user turn through the agent loop as SSE events.

    Wire format matches the legacy Express server exactly:
      event: <type>
      data: <json>

    Heartbeats fire every 3s with idle_s / elapsed_s so the React UI can
    render a live "thinking… 12s" without dead air on long thinking turns.
    """
    provider = select_provider()
    if provider is None:
        raise HTTPException(status_code=503, detail={
            "error": "no_provider_configured",
            "providers": [asdict(p) for p in list_providers()],
            "hint": "Set ANTHROPIC_API_KEY, or OPENAI_API_KEY, or point ATLAS_OPENAI_BASE_URL at Ollama.",
        })

    if req.mode not in (None, "code", "ask", "plan"):
        raise HTTPException(status_code=400, detail="invalid_mode")

    company_id = company_repo.resolve_active_for_user(user.id)
    # `/` is a terrible default — repo_map would walk the entire filesystem.
    # The dashboard's chat is workspace-flavored, so scope to the server's
    # cwd (where uvicorn was launched). The CLI passes an explicit
    # scope_root for its own chat path.
    import os as _os
    scope_root = req.scope_root or _os.getcwd()

    # Producer queue: the runner thread pushes events; the SSE loop drains.
    # Bounded so a runaway provider can't OOM us by flooding deltas.
    q: queue.Queue[AgentEvent | None] = queue.Queue(maxsize=1024)
    cancel = [False]

    def _emit(event: AgentEvent) -> None:
        try:
            q.put_nowait(event)
        except queue.Full:
            # Last-resort backpressure — drop oldest, push new. SSE viewers
            # would rather skip a delta than stall the stream.
            try:
                q.get_nowait()
            except queue.Empty:
                pass
            q.put_nowait(event)

    def _drive() -> None:
        try:
            run_agent(
                RunOptions(
                    provider=provider,
                    messages=list(req.messages),  # type: ignore[arg-type]
                    scope_root=scope_root,
                    user_id=user.id,
                    company_id=company_id,
                    mode=req.mode or "code",  # type: ignore[arg-type]
                    thinking=bool(req.thinking),
                    effort=req.effort,  # type: ignore[arg-type]
                    confirm=bool(req.confirm),
                    scope_files=list(req.scope_files or []),
                    cancel=cancel,
                ),
                _emit,
            )
        except Exception as e:  # noqa: BLE001 — surface as an `error` SSE event
            _emit({"type": "error", "message": str(e)})
            _emit({"type": "done"})
        finally:
            q.put(None)  # sentinel: stream is over

    worker = threading.Thread(target=_drive, daemon=True)
    worker.start()

    async def _stream():
        start = time.monotonic()
        last_visible = start
        # Drain the queue with periodic heartbeats. We poll with a short
        # timeout so heartbeats fire even when no events arrive.
        loop = asyncio.get_event_loop()
        while True:
            if await request.is_disconnected():
                cancel[0] = True
                break
            try:
                event = await loop.run_in_executor(None, _poll, q, 0.5)
            except _StopSentinel:
                break
            now = time.monotonic()
            if event is None:
                # Heartbeat tick.
                if now - last_visible >= 3.0:
                    yield _format(
                        "heartbeat",
                        {"type": "heartbeat",
                         "idle_s": int(now - last_visible),
                         "elapsed_s": int(now - start)},
                    )
                    last_visible = now  # avoid stacking heartbeats every poll
                continue
            last_visible = now
            yield _format(event["type"], event)
            if event["type"] == "done":
                break

    return EventSourceResponse(_stream())


class _StopSentinel(Exception):
    pass


def _poll(q: queue.Queue, timeout: float) -> AgentEvent | None:
    try:
        event = q.get(timeout=timeout)
    except queue.Empty:
        return None
    if event is None:
        raise _StopSentinel()
    return event


def _format(event_type: str, payload: Any) -> dict:
    """Shape an SSE message. EventSourceResponse expects {event, data}."""
    return {"event": event_type, "data": json.dumps(payload)}


# --- permission decision --------------------------------------------------


class PermissionInput(BaseModel):
    token: str = Field(min_length=1)
    decision: str  # "allow" | "deny"
    message: str | None = Field(default=None, max_length=280)


@router.post("/permission")
def permission(payload: PermissionInput) -> dict:
    """Resolve a permission_required gate. The chat SSE stream sends the
    token; the client POSTs here with allow / deny and the runner unblocks."""
    if payload.decision == "allow":
        ok = decide(payload.token, Decision(allow=True))
    else:
        ok = decide(payload.token, Decision(allow=False, message=payload.message or "user denied"))
    return {"ok": ok}


# --- session search + recent ----------------------------------------------


@router.get("/sessions/search")
def session_search(q: str, limit: int = 10) -> dict:
    q = (q or "").strip()
    if not q:
        raise HTTPException(status_code=400, detail="invalid_query")
    try:
        hits = sessions_mod.search(q, limit=limit)
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"hits": hits}


@router.get("/sessions/recent")
def sessions_recent(limit: int = 10) -> dict:
    return {"sessions": sessions_mod.list_recent(limit=limit)}


# --- repo map -------------------------------------------------------------


@router.get("/repo-map")
def repo_map(root: str | None = None) -> dict:
    """Aider-style symbol tree for the dashboard's Code Map tab."""
    import os
    data = repo_map_data(root or os.getcwd())
    return {
        "generated_at": data.generated_at,
        "total_files": data.total_files,
        "groups": [
            {"top": top, "files": [asdict(f) for f in files]}
            for top, files in data.groups
        ],
    }
