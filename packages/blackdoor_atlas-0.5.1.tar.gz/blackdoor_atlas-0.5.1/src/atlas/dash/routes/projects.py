"""/api/projects — projects + labels, workspace-scoped.

Ported from apps/api/src/routes/projects.ts. ``require_company`` scopes
every query to the user's active workspace; same JSON contracts as the
TS routes so the React frontend ports unchanged.
"""

from __future__ import annotations

import re
import sqlite3
from dataclasses import asdict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from atlas.dash.auth import require_company, require_user
from atlas.repos import project as project_repo
from atlas.repos import user as user_repo


router = APIRouter(prefix="/api/projects", tags=["projects"])

_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{3,8}$")


class ProjectInput(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str | None = Field(default="", max_length=4_000)
    color: str | None = None
    status: str | None = Field(default="active")


class ProjectPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    description: str | None = Field(default=None, max_length=4_000)
    color: str | None = None
    status: str | None = None


class LabelInput(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    color: str | None = None


# --- projects --------------------------------------------------------------


@router.get("")
def list_projects(company_id: int = Depends(require_company)) -> list[dict]:
    return [asdict(p) for p in project_repo.list_for_company(company_id)]


@router.post("", status_code=201)
def create_project(payload: ProjectInput,
                   user: user_repo.User = Depends(require_user),
                   company_id: int = Depends(require_company)) -> dict:
    if payload.color is not None and not _COLOR_RE.match(payload.color):
        raise HTTPException(status_code=400, detail="invalid_color")
    if payload.status not in (None, "active", "paused", "archived"):
        raise HTTPException(status_code=400, detail="invalid_status")
    p = project_repo.create(
        user_id=user.id,
        company_id=company_id,
        name=payload.name,
        description=payload.description or "",
        color=payload.color or "#5b8def",
        status=payload.status or "active",  # type: ignore[arg-type]
    )
    return asdict(p)


@router.get("/{project_id}")
def get_project(project_id: int, company_id: int = Depends(require_company)) -> dict:
    p = project_repo.find_for_company(project_id, company_id)
    if p is None:
        raise HTTPException(status_code=404, detail="not_found")
    return asdict(p)


@router.patch("/{project_id}")
def update_project(project_id: int, payload: ProjectPatch,
                   company_id: int = Depends(require_company)) -> dict:
    if project_repo.find_for_company(project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="not_found")
    if payload.color is not None and not _COLOR_RE.match(payload.color):
        raise HTTPException(status_code=400, detail="invalid_color")
    if payload.status is not None and payload.status not in ("active", "paused", "archived"):
        raise HTTPException(status_code=400, detail="invalid_status")
    out = project_repo.update(
        project_id, name=payload.name, description=payload.description,
        color=payload.color,
        status=payload.status,  # type: ignore[arg-type]
    )
    return asdict(out) if out else {}


@router.delete("/{project_id}", status_code=204)
def delete_project(project_id: int, company_id: int = Depends(require_company)) -> None:
    if not project_repo.delete(project_id, company_id):
        raise HTTPException(status_code=404, detail="not_found")


# --- labels ----------------------------------------------------------------


@router.get("/{project_id}/labels")
def list_labels(project_id: int, company_id: int = Depends(require_company)) -> list[dict]:
    if project_repo.find_for_company(project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="project_not_found")
    return [asdict(l) for l in project_repo.list_labels(project_id)]


@router.post("/{project_id}/labels", status_code=201)
def create_label(project_id: int, payload: LabelInput,
                 company_id: int = Depends(require_company)) -> dict:
    if project_repo.find_for_company(project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="project_not_found")
    if payload.color is not None and not _COLOR_RE.match(payload.color):
        raise HTTPException(status_code=400, detail="invalid_color")
    try:
        l = project_repo.create_label(
            project_id, payload.name, payload.color or "#6b7280",
        )
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="label_taken")
    return asdict(l)


@router.delete("/{project_id}/labels/{label_id}", status_code=204)
def delete_label(project_id: int, label_id: int,
                 company_id: int = Depends(require_company)) -> None:
    if project_repo.find_for_company(project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="project_not_found")
    if not project_repo.delete_label(project_id, label_id):
        raise HTTPException(status_code=404, detail="not_found")
