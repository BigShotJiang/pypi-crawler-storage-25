"""/api/tasks — issues + everything that hangs off them.

Ported from apps/api/src/routes/tasks.ts. Same JSON shapes, same URLs.
Subtasks / comments / reactions / activity / bulk / reorder will follow
in a focused commit; this file ships the core CRUD + inbox + mine +
search + per-task labels that the React board and list views need.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import asdict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from atlas.dash.auth import require_company, require_user
from atlas.repos import cycle as cycle_repo
from atlas.repos import project as project_repo
from atlas.repos import task as task_repo
from atlas.repos import user as user_repo


router = APIRouter(prefix="/api/tasks", tags=["tasks"])


# --- input models ---------------------------------------------------------


_VALID_STATUS = {"backlog", "todo", "started", "review", "done", "cancelled"}
_VALID_PRIORITY = {"urgent", "high", "med", "low"}


def _coerce_status(s: str | None) -> str | None:
    if s is None:
        return None
    # Back-compat: 'doing' is the legacy name for 'started'.
    if s == "doing":
        return "started"
    if s not in _VALID_STATUS:
        raise HTTPException(status_code=400, detail="invalid_status")
    return s


class TaskInput(BaseModel):
    project_id: int = Field(gt=0)
    title: str = Field(min_length=1, max_length=280)
    body: str | None = Field(default="", max_length=20_000)
    status: str | None = "todo"
    priority: str | None = "med"
    assignee: str | None = Field(default="", max_length=120)
    due_date: str | None = None
    estimate: int | None = Field(default=None, ge=1, le=13)
    parent_id: int | None = None
    cycle_id: int | None = None


class TaskPatch(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=280)
    body: str | None = Field(default=None, max_length=20_000)
    status: str | None = None
    priority: str | None = None
    assignee: str | None = Field(default=None, max_length=120)
    due_date: str | None = None
    estimate: int | None = Field(default=None, ge=1, le=13)
    parent_id: int | None = None
    cycle_id: int | None = None


class BulkPatch(BaseModel):
    status: str | None = None
    priority: str | None = None
    estimate: int | None = Field(default=None, ge=1, le=13)
    cycle_id: int | None = None
    assignee: str | None = Field(default=None, max_length=120)


class BulkInput(BaseModel):
    ids: list[int] = Field(min_length=1, max_length=200)
    patch: BulkPatch


# --- list / inbox / mine / search -----------------------------------------


@router.get("")
def list_tasks(project_id: int, cycle_id: int | None = None, parent_id: int | None = None,
               company_id: int = Depends(require_company)) -> list[dict]:
    if project_repo.find_for_company(project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="project_not_found")
    # cycle_id=0 is the wire convention for "no cycle".
    cyc: int | str | None = None
    if cycle_id is not None:
        cyc = "none" if cycle_id == 0 else cycle_id
    par: int | str | None = None
    if parent_id is not None:
        par = "none" if parent_id == 0 else parent_id
    rows = task_repo.list_in_project(project_id, cycle_id=cyc, parent_id=par)
    return [_serialize(t) for t in rows]


@router.get("/inbox")
def inbox(company_id: int = Depends(require_company)) -> dict:
    bundle = task_repo.inbox_for(company_id)
    return {
        "open": [_serialize(t) for t in bundle["open"]],
        "recent_done": [_serialize(t) for t in bundle["recent_done"]],
    }


@router.get("/mine")
def mine(user: user_repo.User = Depends(require_user),
         company_id: int = Depends(require_company)) -> list[dict]:
    """Tasks assigned to the current user in the active workspace."""
    # We don't have a repo-level mineFor on the Python side yet; do the
    # filter here since the surface is tiny.
    bundle = task_repo.inbox_for(company_id)
    return [_serialize(t) for t in bundle["open"] if t.assignee == user.email]


@router.get("/search")
def search(q: str = "", company_id: int = Depends(require_company)) -> list[dict]:
    """Title / body substring search inside the active workspace.
    Day 10 polish pass: add the LAU-7 task-key shortcut from the TS side."""
    q = (q or "").strip()
    if not q:
        return []
    bundle = task_repo.inbox_for(company_id)
    needle = q.lower()
    matches = [
        t for t in (*bundle["open"], *bundle["recent_done"])
        if needle in t.title.lower() or needle in (t.body or "").lower()
    ]
    return [_serialize(t) for t in matches[:25]]


# --- detail ---------------------------------------------------------------


@router.get("/{task_id}")
def get_task(task_id: int, company_id: int = Depends(require_company)) -> dict:
    t = task_repo.find_for_company(task_id, company_id)
    if t is None:
        raise HTTPException(status_code=404, detail="not_found")
    return _serialize(t)


# --- create / update / delete ---------------------------------------------


@router.post("", status_code=201)
def create_task(payload: TaskInput,
                user: user_repo.User = Depends(require_user),
                company_id: int = Depends(require_company)) -> dict:
    if project_repo.find_for_company(payload.project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="project_not_found")
    if payload.parent_id is not None and task_repo.workspace_check(payload.parent_id, company_id) is None:
        raise HTTPException(status_code=400, detail="parent_not_in_workspace")
    if payload.cycle_id is not None and not cycle_repo.belongs_to_project(payload.cycle_id, payload.project_id):
        raise HTTPException(status_code=400, detail="cycle_not_in_project")

    status = _coerce_status(payload.status) or "todo"
    priority = payload.priority or "med"
    if priority not in _VALID_PRIORITY:
        raise HTTPException(status_code=400, detail="invalid_priority")

    t = task_repo.create(
        project_id=payload.project_id,
        title=payload.title,
        body=payload.body or "",
        status=status,  # type: ignore[arg-type]
        priority=priority,  # type: ignore[arg-type]
        assignee=payload.assignee or "",
        due_date=payload.due_date,
        estimate=payload.estimate,
        parent_id=payload.parent_id,
        cycle_id=payload.cycle_id,
    )
    task_repo.log_activity(t.id, "created", user.email,
                           {"title": t.title, "status": t.status, "priority": t.priority})
    return _serialize(t)


@router.patch("/{task_id}")
def update_task(task_id: int, payload: TaskPatch,
                user: user_repo.User = Depends(require_user),
                company_id: int = Depends(require_company)) -> dict:
    existing = task_repo.workspace_check(task_id, company_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="not_found")

    patch: dict[str, object] = {}
    for col in ("title", "body", "assignee", "due_date", "estimate", "parent_id", "cycle_id"):
        v = getattr(payload, col)
        if v is not None or (col in ("due_date", "estimate", "parent_id", "cycle_id") and col in payload.model_fields_set):
            patch[col] = v
    if payload.status is not None:
        patch["status"] = _coerce_status(payload.status)
    if payload.priority is not None:
        if payload.priority not in _VALID_PRIORITY:
            raise HTTPException(status_code=400, detail="invalid_priority")
        patch["priority"] = payload.priority

    task_repo.update(task_id, **patch)
    # Activity log side-effects mirror the TS route. Run completed_at FIRST
    # so the re-fetch below sees the new timestamp.
    if "status" in patch and patch["status"] != existing["status"]:
        completed = (_now_iso() if patch["status"] == "done" else None)
        task_repo.set_completed_at(task_id, completed)
        task_repo.log_activity(task_id, "status_changed", user.email,
                               {"from": existing["status"], "to": patch["status"]})
    if "priority" in patch:
        task_repo.log_activity(task_id, "priority_changed", user.email, {"to": patch["priority"]})
    if "title" in patch:
        task_repo.log_activity(task_id, "title_changed", user.email, {"to": patch["title"]})
    if "estimate" in patch:
        task_repo.log_activity(task_id, "estimate_changed", user.email, {"to": patch["estimate"]})
    if "cycle_id" in patch:
        task_repo.log_activity(task_id, "cycle_changed", user.email, {"to": patch["cycle_id"]})
    # Re-fetch so the response reflects every side-effect (especially
    # completed_at after a status change).
    fresh = task_repo.find_for_company(task_id, company_id)
    return _serialize(fresh) if fresh else {}


@router.delete("/{task_id}", status_code=204)
def delete_task(task_id: int, company_id: int = Depends(require_company)) -> None:
    if not task_repo.delete(task_id, company_id):
        raise HTTPException(status_code=404, detail="not_found")


# --- bulk + reorder -------------------------------------------------------


@router.post("/bulk")
def bulk_update(payload: BulkInput,
                user: user_repo.User = Depends(require_user),
                company_id: int = Depends(require_company)) -> dict:
    # Validate scalars before scattering writes.
    status = _coerce_status(payload.patch.status) if payload.patch.status else None
    if payload.patch.priority is not None and payload.patch.priority not in _VALID_PRIORITY:
        raise HTTPException(status_code=400, detail="invalid_priority")

    updated_ids: list[int] = []
    for tid in payload.ids:
        existing = task_repo.workspace_check(tid, company_id)
        if existing is None:
            continue
        patch: dict[str, object] = {}
        if status is not None:
            patch["status"] = status
        if payload.patch.priority is not None:
            patch["priority"] = payload.patch.priority
        if payload.patch.estimate is not None:
            patch["estimate"] = payload.patch.estimate
        if payload.patch.cycle_id is not None or "cycle_id" in payload.patch.model_fields_set:
            patch["cycle_id"] = payload.patch.cycle_id
        if payload.patch.assignee is not None:
            patch["assignee"] = payload.patch.assignee
        if patch:
            task_repo.update(tid, **patch)
            if "status" in patch and patch["status"] != existing["status"]:
                task_repo.set_completed_at(tid, _now_iso() if patch["status"] == "done" else None)
                task_repo.log_activity(tid, "status_changed", user.email,
                                       {"from": existing["status"], "to": patch["status"], "bulk": True})
            updated_ids.append(tid)
    return {"updated": len(updated_ids)}


class ReorderInput(BaseModel):
    status: str
    ordered_ids: list[int] = Field(max_length=500)


@router.post("/projects/{project_id}/reorder")
def reorder(project_id: int, payload: ReorderInput,
            company_id: int = Depends(require_company)) -> dict:
    if project_repo.find_for_company(project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="project_not_found")
    status = _coerce_status(payload.status)
    if status is None:
        raise HTTPException(status_code=400, detail="invalid_status")
    task_repo.reorder(project_id, status, payload.ordered_ids)  # type: ignore[arg-type]
    return {"ok": True, "n": len(payload.ordered_ids)}


# --- labels on tasks ------------------------------------------------------


@router.post("/{task_id}/labels/{label_id}", status_code=204)
def attach_label(task_id: int, label_id: int,
                 user: user_repo.User = Depends(require_user),
                 company_id: int = Depends(require_company)) -> None:
    existing = task_repo.workspace_check(task_id, company_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="not_found")
    labels = project_repo.list_labels(existing["project_id"])
    label = next((l for l in labels if l.id == label_id), None)
    if label is None:
        raise HTTPException(status_code=404, detail="label_not_found")
    task_repo.attach_label(task_id, label_id)
    task_repo.log_activity(task_id, "label_added", user.email, {"label": label.name})


@router.delete("/{task_id}/labels/{label_id}", status_code=204)
def detach_label(task_id: int, label_id: int,
                 user: user_repo.User = Depends(require_user),
                 company_id: int = Depends(require_company)) -> None:
    if task_repo.workspace_check(task_id, company_id) is None:
        raise HTTPException(status_code=404, detail="not_found")
    task_repo.detach_label(task_id, label_id)
    task_repo.log_activity(task_id, "label_removed", user.email, {"label_id": label_id})


# --- helpers --------------------------------------------------------------


def _serialize(t: task_repo.TaskWithRels) -> dict:
    """Convert a TaskWithRels (dataclass) into the wire dict the React
    frontend expects. Subtasks/children get their dataclasses flattened."""
    return {
        **{k: v for k, v in asdict(t).items() if k not in ("subtasks", "children")},
        "subtasks": [asdict(s) for s in t.subtasks],
        "children": [asdict(c) for c in t.children],
    }


def _now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
