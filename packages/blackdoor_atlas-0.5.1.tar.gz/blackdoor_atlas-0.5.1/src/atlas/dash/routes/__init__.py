"""HTTP route modules. One file per concern, mounted at /api/<name>.

Each route module follows the Express → FastAPI port convention: same
URL paths, same JSON shapes, same status codes, so the React frontend in
apps/web/ ports over without changes.
"""
