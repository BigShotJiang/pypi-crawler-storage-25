"""/api/companies — workspaces.

Ported from apps/api/src/routes/companies.ts. Same JSON shape so the React
sidebar's workspace switcher keeps working unchanged.
"""

from __future__ import annotations

import re
from dataclasses import asdict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from atlas.dash.auth import require_user
from atlas.repos import company as company_repo
from atlas.repos import user as user_repo


router = APIRouter(prefix="/api/companies", tags=["companies"])


_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{3,8}$")


class CompanyInput(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    color: str | None = None
    description: str | None = Field(default=None, max_length=280)


class CompanyPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=60)
    color: str | None = None
    description: str | None = Field(default=None, max_length=280)


class SwitchInput(BaseModel):
    company_id: int = Field(gt=0)


def _serialize(c: company_repo.CompanyWithMeta) -> dict:
    return asdict(c)


@router.get("")
def list_companies(user: user_repo.User = Depends(require_user)) -> dict:
    active = company_repo.resolve_active_for_user(user.id)
    rows = company_repo.list_for_user(user.id, active)
    return {
        "active_company_id": active,
        "companies": [_serialize(c) for c in rows],
    }


@router.post("", status_code=201)
def create_company(payload: CompanyInput, user: user_repo.User = Depends(require_user)) -> dict:
    if payload.color is not None and not _COLOR_RE.match(payload.color):
        raise HTTPException(status_code=400, detail="invalid_color")
    c = company_repo.create(
        owner_id=user.id,
        name=payload.name,
        color=payload.color or "#5e6ad2",
        description=payload.description or "",
    )
    return asdict(c)


@router.patch("/{company_id}")
def update_company(company_id: int, payload: CompanyPatch,
                   user: user_repo.User = Depends(require_user)) -> dict:
    if not company_repo.is_member(company_id, user.id):
        raise HTTPException(status_code=404, detail="not_found")
    role = company_repo.role_of(company_id, user.id)
    if role not in ("owner", "admin"):
        raise HTTPException(status_code=403, detail="forbidden")
    if payload.color is not None and not _COLOR_RE.match(payload.color):
        raise HTTPException(status_code=400, detail="invalid_color")
    c = company_repo.update(
        company_id,
        name=payload.name,
        color=payload.color,
        description=payload.description,
    )
    if c is None:
        raise HTTPException(status_code=404, detail="not_found")
    return asdict(c)


@router.delete("/{company_id}", status_code=204)
def delete_company(company_id: int, user: user_repo.User = Depends(require_user)) -> None:
    if not company_repo.is_member(company_id, user.id):
        raise HTTPException(status_code=404, detail="not_found")
    if company_repo.role_of(company_id, user.id) != "owner":
        raise HTTPException(status_code=403, detail="owner_only")
    remaining = [c for c in company_repo.list_for_user(user.id, None) if c.id != company_id]
    if not remaining:
        # Refuse to leave the user with zero workspaces — mirrors the TS
        # behavior so the React UI doesn't have to special-case it.
        raise HTTPException(
            status_code=400,
            detail={"error": "last_workspace",
                    "hint": "Create another workspace before deleting this one."},
        )
    company_repo.delete(company_id)
    company_repo.set_active_for_user(user.id, remaining[0].id)


@router.post("/switch")
def switch(payload: SwitchInput, user: user_repo.User = Depends(require_user)) -> dict:
    if not company_repo.is_member(payload.company_id, user.id):
        raise HTTPException(status_code=404, detail="not_found")
    company_repo.set_active_for_user(user.id, payload.company_id)
    return {"active_company_id": payload.company_id}
