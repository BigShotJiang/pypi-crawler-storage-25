"""/api/projects/{id}/{cycles,insights,views,templates}.

Ported from apps/api/src/routes/cycles.ts. The TS server grouped all
project-scoped sub-collections under one router; we follow the same
layout so URL paths match 1:1.
"""

from __future__ import annotations

import json
from dataclasses import asdict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from atlas.dash.auth import require_company, require_user
from atlas.repos import cycle as cycle_repo
from atlas.repos import insights as insights_repo
from atlas.repos import project as project_repo
from atlas.repos import saved_view as views_repo
from atlas.repos import template as templates_repo
from atlas.repos import user as user_repo


router = APIRouter(prefix="/api/projects", tags=["projects-sub"])


def _own(project_id: int, company_id: int) -> None:
    if project_repo.find_for_company(project_id, company_id) is None:
        raise HTTPException(status_code=404, detail="project_not_found")


# --- cycles ---------------------------------------------------------------


class CycleInput(BaseModel):
    name: str | None = Field(default="", max_length=120)
    start_date: str = Field(min_length=1)
    end_date: str = Field(min_length=1)


@router.get("/{project_id}/cycles")
def list_cycles(project_id: int, company_id: int = Depends(require_company)) -> list[dict]:
    _own(project_id, company_id)
    return [asdict(c) for c in cycle_repo.list_for_project(project_id)]


@router.post("/{project_id}/cycles", status_code=201)
def create_cycle(project_id: int, payload: CycleInput,
                 company_id: int = Depends(require_company)) -> dict:
    _own(project_id, company_id)
    if payload.end_date < payload.start_date:
        raise HTTPException(status_code=400, detail="end_before_start")
    c = cycle_repo.create(
        project_id, name=payload.name or "",
        start_date=payload.start_date, end_date=payload.end_date,
    )
    return asdict(c)


@router.delete("/{project_id}/cycles/{cycle_id}", status_code=204)
def delete_cycle(project_id: int, cycle_id: int,
                 company_id: int = Depends(require_company)) -> None:
    _own(project_id, company_id)
    if not cycle_repo.delete(project_id, cycle_id):
        raise HTTPException(status_code=404, detail="not_found")


# --- insights -------------------------------------------------------------


@router.get("/{project_id}/insights")
def insights(project_id: int, company_id: int = Depends(require_company)) -> dict:
    _own(project_id, company_id)
    return insights_repo.for_project(project_id)


# --- saved views ----------------------------------------------------------


class SavedViewInput(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    payload: dict = Field(default_factory=dict)


@router.get("/{project_id}/views")
def list_views(project_id: int,
               user: user_repo.User = Depends(require_user),
               company_id: int = Depends(require_company)) -> list[dict]:
    _own(project_id, company_id)
    return [asdict(v) for v in views_repo.list_for(user.id, project_id)]


@router.post("/{project_id}/views", status_code=201)
def create_view(project_id: int, payload: SavedViewInput,
                user: user_repo.User = Depends(require_user),
                company_id: int = Depends(require_company)) -> dict:
    _own(project_id, company_id)
    v = views_repo.create(user.id, project_id, payload.name, payload.payload)
    return asdict(v)


@router.delete("/{project_id}/views/{view_id}", status_code=204)
def delete_view(project_id: int, view_id: int,
                user: user_repo.User = Depends(require_user),
                company_id: int = Depends(require_company)) -> None:
    _own(project_id, company_id)
    if not views_repo.delete(user.id, project_id, view_id):
        raise HTTPException(status_code=404, detail="not_found")


# --- templates ------------------------------------------------------------


class TemplateInput(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    title: str = Field(min_length=1, max_length=280)
    body: str | None = Field(default="", max_length=20_000)
    priority: str | None = "med"
    estimate: int | None = Field(default=None, ge=1, le=13)


@router.get("/{project_id}/templates")
def list_templates(project_id: int, company_id: int = Depends(require_company)) -> list[dict]:
    _own(project_id, company_id)
    return [asdict(t) for t in templates_repo.list_for_project(project_id)]


@router.post("/{project_id}/templates", status_code=201)
def create_template(project_id: int, payload: TemplateInput,
                    company_id: int = Depends(require_company)) -> dict:
    _own(project_id, company_id)
    priority = payload.priority or "med"
    if priority not in ("urgent", "high", "med", "low"):
        raise HTTPException(status_code=400, detail="invalid_priority")
    t = templates_repo.create(
        project_id, name=payload.name, title=payload.title,
        body=payload.body or "",
        priority=priority,  # type: ignore[arg-type]
        estimate=payload.estimate,
    )
    return asdict(t)


@router.delete("/{project_id}/templates/{template_id}", status_code=204)
def delete_template(project_id: int, template_id: int,
                    company_id: int = Depends(require_company)) -> None:
    _own(project_id, company_id)
    if not templates_repo.delete(project_id, template_id):
        raise HTTPException(status_code=404, detail="not_found")
