"""/api/auth — signup / login / logout / me.

Ported from apps/api/src/routes/auth.ts. In v0.1's default single-user mode
the login + signup endpoints exist mostly for back-compat with the React
frontend; ``ATLAS_DASH_REQUIRE_LOGIN=1`` flips on real password checks
(planned Day 12). Today we accept any credentials and bind to the default
local user.
"""

from __future__ import annotations

from fastapi import APIRouter, Cookie, Depends, Response
from pydantic import BaseModel, Field

from atlas.dash.auth import (
    COOKIE_NAME,
    create_session,
    destroy_session,
    require_user,
    user_from_session,
)
from atlas.repos import seed as seed_repo
from atlas.repos import user as user_repo


router = APIRouter(prefix="/api/auth", tags=["auth"])


class Credentials(BaseModel):
    # Plain str rather than `EmailStr` so we don't pull in `email-validator`
    # for what is effectively a placeholder in v0.1 single-user mode.
    # Day 12 wires real auth — that's where strict validation belongs.
    email: str = Field(min_length=3, max_length=200)
    password: str = Field(min_length=8)


@router.post("/signup")
def signup(creds: Credentials, response: Response) -> dict:
    """v0.1 single-user mode: silently returns the local user. Day 12 wires
    real password hashing + uniqueness checks."""
    user = user_repo.find_by_email(str(creds.email)) or user_repo.ensure_default()
    seed_repo.seed_if_empty(user.id)
    sid = create_session(user.id)
    response.set_cookie(COOKIE_NAME, sid, httponly=True, samesite="lax")
    response.status_code = 201
    return {"id": user.id, "email": user.email}


@router.post("/login")
def login(creds: Credentials, response: Response) -> dict:
    user = user_repo.find_by_email(str(creds.email)) or user_repo.ensure_default()
    seed_repo.seed_if_empty(user.id)
    sid = create_session(user.id)
    response.set_cookie(COOKIE_NAME, sid, httponly=True, samesite="lax")
    return {"id": user.id, "email": user.email}


@router.post("/logout")
def logout(response: Response, sid: str | None = Cookie(default=None, alias=COOKIE_NAME)) -> Response:
    if sid:
        destroy_session(sid)
    response.delete_cookie(COOKIE_NAME)
    response.status_code = 204
    return response


@router.get("/me")
def me(user: user_repo.User = Depends(require_user)) -> dict:
    """Auto-creates the default user + session on first hit so the React
    frontend has someone to be without a signup roundtrip."""
    seed_repo.seed_if_empty(user.id)
    return {
        "id": user.id,
        "email": user.email,
        "active_company_id": user.active_company_id,
    }
