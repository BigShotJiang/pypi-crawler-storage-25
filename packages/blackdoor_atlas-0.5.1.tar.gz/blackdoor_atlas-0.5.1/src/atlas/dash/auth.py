"""Auth glue for the FastAPI dashboard.

Day 8-10 keeps the CLI's "always-default-user" mode as the v0.1 default —
the dashboard is local-only, so we don't need passwords yet. If
``ATLAS_DASH_REQUIRE_LOGIN=1`` is set we switch on real login (Day 12+
work; the route stubs are here so the React frontend keeps booting).

Session cookies use the same ``sid`` name the old Express server set so
the React frontend keeps working without code changes.
"""

from __future__ import annotations

import secrets

from fastapi import Cookie, Depends, HTTPException, Response

from atlas.db.connection import connect
from atlas.repos import company as company_repo
from atlas.repos import seed as seed_repo
from atlas.repos import user as user_repo


COOKIE_NAME = "sid"


# --- session helpers (single-table token store) ---------------------------


def create_session(user_id: int) -> str:
    """Allocate a fresh session token. Mirrors the TS UserRepo.createSession.
    Sessions never expire server-side in v0.1; cookies are HttpOnly + SameSite
    Lax so XSS / CSRF surface is minimal."""
    cnx = connect()
    sid = secrets.token_hex(32)
    cnx.execute("INSERT INTO sessions (id, user_id) VALUES (?, ?)", (sid, user_id))
    cnx.commit()
    return sid


def destroy_session(sid: str) -> None:
    cnx = connect()
    cnx.execute("DELETE FROM sessions WHERE id = ?", (sid,))
    cnx.commit()


def user_from_session(sid: str | None) -> user_repo.User | None:
    if not sid:
        return None
    row = connect().execute(
        """
        SELECT u.id AS id, u.email AS email, u.created_at AS created_at,
               u.active_company_id AS active_company_id
          FROM sessions s JOIN users u ON u.id = s.user_id
         WHERE s.id = ?
        """,
        (sid,),
    ).fetchone()
    if row is None:
        return None
    return user_repo.User(
        id=row["id"], email=row["email"],
        created_at=row["created_at"], active_company_id=row["active_company_id"],
    )


# --- FastAPI dependencies --------------------------------------------------


async def require_user(
    response: Response,
    sid: str | None = Cookie(default=None, alias=COOKIE_NAME),
) -> user_repo.User:
    """Resolve the request's user. In single-user mode (the default) we
    auto-create + auto-login the default user so the dashboard works
    without a signup flow.

    When ``ATLAS_DASH_REQUIRE_LOGIN=1`` is set, a missing or stale cookie
    yields 401 and the client must POST /api/auth/login first.
    """
    import os

    user = user_from_session(sid)
    if user is not None:
        return user

    if os.environ.get("ATLAS_DASH_REQUIRE_LOGIN") == "1":
        raise HTTPException(status_code=401, detail="unauthorized")

    # Single-user / local-only mode: ensure_default + seed + auto-issue session.
    user = user_repo.ensure_default()
    seed_repo.seed_if_empty(user.id)
    new_sid = create_session(user.id)
    response.set_cookie(COOKIE_NAME, new_sid, httponly=True, samesite="lax")
    return user


async def require_company(user: user_repo.User = Depends(require_user)) -> int:
    """Resolve the user's active workspace. 404 if they have none — the
    `require_user` dep seeded one on first call, so this only fires if a
    test deliberately wiped the DB mid-request."""
    cid = company_repo.resolve_active_for_user(user.id)
    if cid is None:
        raise HTTPException(status_code=404, detail="no_active_workspace")
    return cid
