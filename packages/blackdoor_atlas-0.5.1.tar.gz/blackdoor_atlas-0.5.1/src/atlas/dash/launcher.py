"""`atlas dash` launcher.

Spawns ``uvicorn atlas.dash.server:create_app --factory`` in the background,
polls /healthz until it responds, opens the user's default browser, and
returns. The server's PID lands in ``~/.atlas/dash.pid`` so ``atlas stop``
can take it down.

Loopback-only by default. Override with ATLAS_DASH_HOST / ATLAS_DASH_PORT
when you need to expose it (e.g. inside a container or tunnel).
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser


DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 41821


def _state_dir() -> str:
    return os.environ.get("ATLAS_HOME") or os.path.expanduser("~/.atlas")


def _pid_file() -> str:
    return os.path.join(_state_dir(), "dash.pid")


def _config() -> tuple[str, int]:
    host = os.environ.get("ATLAS_DASH_HOST", DEFAULT_HOST)
    try:
        port = int(os.environ.get("ATLAS_DASH_PORT", str(DEFAULT_PORT)))
    except ValueError:
        port = DEFAULT_PORT
    return host, port


# --- start / stop / status -------------------------------------------------


def start(open_browser: bool = True) -> int:
    """Spawn the dashboard. Returns a shell exit code.

    Two paths:

      - **Frozen (PyInstaller binary)** — uvicorn runs in-process, blocking,
        until Ctrl-C. The user's terminal is "the server". This is the
        normal CLI-server posture (django runserver, rails server, etc.).
      - **Pipx install** — uvicorn runs as a detached subprocess. The CLI
        returns immediately and `atlas stop` tears it down later.
    """
    host, port = _config()
    base_url = f"http://{host}:{port}"

    # Already healthy? Just open the browser.
    if _is_healthy(base_url):
        print(f"[ok] dashboard already running at {base_url}")
        if open_browser:
            webbrowser.open(base_url)
        return 0

    os.makedirs(_state_dir(), exist_ok=True)

    if getattr(sys, "frozen", False):
        return _start_in_process(host, port, base_url, open_browser)
    return _start_subprocess(host, port, base_url, open_browser)


def _start_in_process(host: str, port: int, base_url: str, open_browser: bool) -> int:
    """In-process uvicorn — for the PyInstaller binary where we can't
    re-exec the interpreter. Blocks until Ctrl-C."""
    import threading

    # Open the browser shortly after the server should be up. We don't
    # block on /healthz here because uvicorn.run() doesn't return until
    # shutdown — instead, fire a one-shot timer.
    def _open_when_ready() -> None:
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if _is_healthy(base_url):
                print(f"[ok] dashboard ready at {base_url}")
                if open_browser:
                    try:
                        webbrowser.open(base_url, new=2)
                    except Exception:  # noqa: BLE001
                        pass
                return
            time.sleep(0.25)
        print(f"[warn] dashboard did not become healthy within 30s")

    threading.Thread(target=_open_when_ready, daemon=True).start()

    import uvicorn
    from atlas.dash.server import create_app

    print(f"[..] starting dashboard at {base_url}  (Ctrl-C to stop)")
    try:
        uvicorn.run(create_app(), host=host, port=port, log_level="warning")
    except KeyboardInterrupt:
        print("\n[ok] dashboard stopped")
    return 0


def _start_subprocess(host: str, port: int, base_url: str, open_browser: bool) -> int:
    """Detached subprocess uvicorn — for pip/pipx installs. Returns once
    healthz responds; ``atlas stop`` tears it down later."""
    log_path = os.path.join(_state_dir(), "dash.log")
    cmd = [
        sys.executable, "-m", "uvicorn",
        "atlas.dash.server:create_app",
        "--factory",
        "--host", host,
        "--port", str(port),
        "--log-level", "warning",
    ]
    with open(log_path, "ab") as log:
        proc = subprocess.Popen(  # noqa: S603 — fixed command + args
            cmd,
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

    with open(_pid_file(), "w", encoding="utf-8") as f:
        json.dump({"pid": proc.pid, "host": host, "port": port}, f)

    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            print(f"[err] dashboard process exited early — see {log_path}")
            return 1
        if _is_healthy(base_url):
            print(f"[ok] dashboard ready at {base_url}  (pid {proc.pid})")
            if open_browser:
                try:
                    webbrowser.open(base_url, new=2)
                except Exception as exc:  # noqa: BLE001
                    print(f"[warn] couldn't open browser: {exc}")
            return 0
        time.sleep(0.25)

    print(f"[err] dashboard did not become healthy within 30s — see {log_path}")
    return 1


def stop() -> int:
    """Tear down the running dashboard, if any."""
    path = _pid_file()
    if not os.path.exists(path):
        print("[ok] dashboard not running")
        return 0
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        data = {}
    pid = int(data.get("pid", 0))
    if pid > 0:
        try:
            os.kill(pid, signal.SIGTERM)
            print(f"[ok] sent SIGTERM to pid {pid}")
        except ProcessLookupError:
            print(f"[ok] pid {pid} no longer running")
        except PermissionError:
            print(f"[err] permission denied killing pid {pid}")
            return 1
    try:
        os.unlink(path)
    except OSError:
        pass
    return 0


def status() -> dict:
    """Return current dashboard state — used by `atlas status` and tests."""
    host, port = _config()
    base_url = f"http://{host}:{port}"
    return {
        "url": base_url,
        "healthy": _is_healthy(base_url),
        "pid_file": _pid_file(),
    }


# --- helpers ---------------------------------------------------------------


def _is_healthy(base_url: str) -> bool:
    try:
        with urllib.request.urlopen(f"{base_url}/healthz", timeout=1) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, OSError):
        return False
