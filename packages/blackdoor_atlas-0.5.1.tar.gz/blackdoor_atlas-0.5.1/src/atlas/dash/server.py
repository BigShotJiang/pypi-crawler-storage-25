"""FastAPI app factory.

``create_app()`` builds and returns the dashboard's ASGI app. ``atlas dash``
(Day 12) runs it under uvicorn. Tests can also import the app directly
and drive it with TestClient — no need to spin up a real server.

Routes are mounted at /api/<name>; the React frontend lives at /<static>
(populated when ``apps/web`` has been built — see ``static_dir()``).

The dashboard is loopback-only by default — that's the same posture as
the legacy Express server. Override with ATLAS_DASH_HOST.
"""

from __future__ import annotations

import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from atlas import __version__


def create_app() -> FastAPI:
    app = FastAPI(
        title="ATLAS dashboard",
        version=__version__,
        # Hide /docs and /redoc in v0.1 — the dashboard is loopback-only;
        # the React frontend talks to /api directly so the auto-docs add
        # surface area without benefit.
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )

    # Loopback-only by default — same as the legacy Express middleware. CORS
    # is permissive within localhost so a Vite dev server on :5173 can still
    # talk to the API on :41821 during frontend hacking.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            "http://localhost:41822",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Lazy import the route modules so `from atlas.dash.server import create_app`
    # doesn't pay the SDK-import tax until someone actually starts the server.
    from atlas.dash.routes import agent as agent_route
    from atlas.dash.routes import auth as auth_route
    from atlas.dash.routes import companies as companies_route
    from atlas.dash.routes import cycles as cycles_route
    from atlas.dash.routes import projects as projects_route
    from atlas.dash.routes import tasks as tasks_route

    app.include_router(auth_route.router)
    app.include_router(companies_route.router)
    app.include_router(projects_route.router)
    app.include_router(tasks_route.router)
    app.include_router(cycles_route.router)
    app.include_router(agent_route.router)

    @app.get("/healthz")
    def healthz() -> dict:
        return {"ok": True, "version": __version__}

    # Static frontend — only mounted if a build exists. Until apps/web is
    # built (`npm run build`) and copied / symlinked under static_dir(),
    # the dashboard returns 404 on / and the user opens the API root
    # at /healthz.
    static = static_dir()
    if static and os.path.isdir(static):
        app.mount("/", StaticFiles(directory=static, html=True), name="frontend")
    else:
        @app.get("/")
        def root_placeholder() -> JSONResponse:
            return JSONResponse({
                "ok": True,
                "message": (
                    "ATLAS dashboard API is running. Build the frontend "
                    "(`cd apps/web && npm run build`) then symlink "
                    "apps/web/dist into src/atlas/dash/static/."
                ),
            })

    return app


def static_dir() -> str:
    """Resolve where the React build lives. Honors ATLAS_DASH_STATIC for
    development overrides; defaults to the in-package ``static/`` directory
    that Day 13's release workflow populates from ``apps/web/dist``."""
    override = os.environ.get("ATLAS_DASH_STATIC")
    if override:
        return override
    return os.path.join(os.path.dirname(__file__), "static")
