"""SQLite layer — schema, connection, migrations.

Lands Day 5-7. The DB lives at ~/.atlas/data.sqlite (WAL mode) and is the
single source of truth for workspaces, projects, issues, cycles, memberships,
saved views, templates, agent sessions, etc.

Schema is ported 1:1 from apps/api/src/db.ts so the existing React frontend
keeps working when Day 8-10 swaps the API to FastAPI.
"""
