"""DDL + idempotent migrations.

Ported from apps/api/src/db.ts. Same table shape so the eventual FastAPI
dashboard can share this exact DB file with no schema divergence.

Migrations are run unconditionally on first connect — every statement uses
``CREATE TABLE IF NOT EXISTS`` and ``ALTER TABLE … ADD COLUMN`` is gated
on a PRAGMA table_info() check, so re-running the init is cheap and safe.
"""

from __future__ import annotations

import sqlite3


_DDL = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '#5b8def',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'todo',
  priority TEXT NOT NULL DEFAULT 'med',
  assignee TEXT NOT NULL DEFAULT '',
  due_date TEXT,
  sort_index INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at TEXT
);

CREATE TABLE IF NOT EXISTS labels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#6b7280',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(project_id, name)
);

CREATE TABLE IF NOT EXISTS task_labels (
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  label_id INTEGER NOT NULL REFERENCES labels(id) ON DELETE CASCADE,
  PRIMARY KEY (task_id, label_id)
);

CREATE TABLE IF NOT EXISTS subtasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  done INTEGER NOT NULL DEFAULT 0,
  sort_index INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  author TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  payload TEXT NOT NULL DEFAULT '{}',
  actor TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cycles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  number INTEGER NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'upcoming',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(project_id, number)
);

CREATE TABLE IF NOT EXISTS reactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  comment_id INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
  author TEXT NOT NULL,
  emoji TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(comment_id, author, emoji)
);

CREATE TABLE IF NOT EXISTS saved_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  payload TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  priority TEXT NOT NULL DEFAULT 'med',
  estimate INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  key TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '#5e6ad2',
  description TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS company_members (
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member',
  joined_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (company_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_project_status ON tasks(project_id, status);
CREATE INDEX IF NOT EXISTS idx_labels_project ON labels(project_id);
CREATE INDEX IF NOT EXISTS idx_subtasks_task ON subtasks(task_id);
CREATE INDEX IF NOT EXISTS idx_comments_task ON comments(task_id);
CREATE INDEX IF NOT EXISTS idx_activity_task ON activity(task_id);
CREATE INDEX IF NOT EXISTS idx_cycles_project ON cycles(project_id);
CREATE INDEX IF NOT EXISTS idx_reactions_comment ON reactions(comment_id);
CREATE INDEX IF NOT EXISTS idx_savedviews_user ON saved_views(user_id, project_id);
CREATE INDEX IF NOT EXISTS idx_templates_project ON templates(project_id);
CREATE INDEX IF NOT EXISTS idx_company_members_user ON company_members(user_id);
CREATE INDEX IF NOT EXISTS idx_company_members_company ON company_members(company_id);
"""


def init_schema(cnx: sqlite3.Connection) -> None:
    """Create tables + run idempotent migrations. Safe to call repeatedly."""
    cnx.executescript(_DDL)
    _add_columns(cnx)
    _backfill(cnx)
    cnx.commit()


def _columns(cnx: sqlite3.Connection, table: str) -> set[str]:
    return {r["name"] for r in cnx.execute(f"PRAGMA table_info({table})").fetchall()}


def _ensure_column(cnx: sqlite3.Connection, table: str, name: str, ddl: str) -> None:
    if name not in _columns(cnx, table):
        cnx.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")


def _add_columns(cnx: sqlite3.Connection) -> None:
    """Idempotent column additions — mirrors the TS db.ts ensureColumn calls."""
    _ensure_column(cnx, "projects", "key", "TEXT NOT NULL DEFAULT ''")
    _ensure_column(cnx, "tasks", "task_number", "INTEGER NOT NULL DEFAULT 0")
    _ensure_column(cnx, "tasks", "estimate", "INTEGER")
    _ensure_column(cnx, "tasks", "parent_id", "INTEGER REFERENCES tasks(id) ON DELETE CASCADE")
    _ensure_column(cnx, "tasks", "cycle_id", "INTEGER REFERENCES cycles(id) ON DELETE SET NULL")
    _ensure_column(cnx, "projects", "company_id", "INTEGER REFERENCES companies(id) ON DELETE CASCADE")
    _ensure_column(cnx, "users", "active_company_id", "INTEGER REFERENCES companies(id) ON DELETE SET NULL")


def _backfill(cnx: sqlite3.Connection) -> None:
    """Backfill steps that produce a usable DB after a fresh ALTER. Same
    set the TS migration ran, kept here for parity when an old TS-built DB
    is opened by the Python CLI."""
    # Map legacy 'doing' tasks onto the new 'started' state.
    cnx.execute("UPDATE tasks SET status = 'started' WHERE status = 'doing'")

    # Give every key-less project a derived 3-letter key.
    cnx.execute("""
        UPDATE projects
           SET key = SUBSTR(UPPER(REPLACE(name, ' ', '')), 1, 3) || CAST(id AS TEXT)
         WHERE key = '' OR key IS NULL
    """)

    # Number tasks that arrived before task_number existed.
    rows = cnx.execute(
        "SELECT id, project_id FROM tasks WHERE task_number = 0 ORDER BY project_id, id",
    ).fetchall()
    if rows:
        counters: dict[int, int] = {}
        upd = "UPDATE tasks SET task_number = ? WHERE id = ?"
        for row in rows:
            pid = row["project_id"]
            counters[pid] = counters.get(pid, 0) + 1
            cnx.execute(upd, (counters[pid], row["id"]))
