"""Shared SQLite connection.

The CLI agent (Python) and the eventual FastAPI dashboard (Day 8-10) both
open the same file at ``~/.atlas/data.sqlite`` in WAL mode. WAL allows a
single writer + many readers concurrently across processes, so the agent
saving an issue update doesn't block the dashboard's render.

We use a per-thread connection cache. Python's stdlib ``sqlite3`` requires
connections to be used on the thread they were created on by default, and
the REPL spawns a worker thread per agent turn (see cli/repl.py), so we
need to be careful here. Each thread that asks for the DB gets its own
connection object — they all point at the same file, WAL handles the rest.

Schema migrations run lazily on first ``connect()`` call so importing the
repos doesn't touch disk until the user actually opens a workspace.
"""

from __future__ import annotations

import os
import sqlite3
import threading


_LOCK = threading.Lock()
_INITIALIZED = False
_LOCAL = threading.local()


def db_path() -> str:
    """Resolve the workspace DB path. Honors ATLAS_HOME for tests."""
    home = os.environ.get("ATLAS_HOME") or os.path.expanduser("~/.atlas")
    return os.path.join(home, "data.sqlite")


def _ensure_dir() -> None:
    os.makedirs(os.path.dirname(db_path()), exist_ok=True)


def _open() -> sqlite3.Connection:
    _ensure_dir()
    cnx = sqlite3.connect(db_path(), timeout=15.0, check_same_thread=False)
    cnx.row_factory = sqlite3.Row
    cnx.execute("PRAGMA journal_mode = WAL")
    cnx.execute("PRAGMA foreign_keys = ON")
    cnx.execute("PRAGMA synchronous = NORMAL")  # safe under WAL, much faster than FULL
    return cnx


def connect() -> sqlite3.Connection:
    """Get a connection for the current thread. Lazily runs migrations on
    first call across the whole process."""
    global _INITIALIZED
    cnx = getattr(_LOCAL, "cnx", None)
    if cnx is None:
        cnx = _open()
        _LOCAL.cnx = cnx
    if not _INITIALIZED:
        with _LOCK:
            if not _INITIALIZED:
                from atlas.db.schema import init_schema  # local import to avoid cycle
                init_schema(cnx)
                _INITIALIZED = True
    return cnx


def close_thread() -> None:
    """Close the connection associated with the current thread, if any.
    Called by the REPL worker thread on exit so connections don't leak."""
    cnx = getattr(_LOCAL, "cnx", None)
    if cnx is not None:
        try:
            cnx.close()
        finally:
            _LOCAL.cnx = None


def reset_for_tests() -> None:
    """Test-only helper. Closes every cached connection and forces the
    next ``connect()`` to re-init the schema. Used by tests that point
    ATLAS_HOME at a tmpdir and expect a fresh DB."""
    global _INITIALIZED
    with _LOCK:
        _INITIALIZED = False
        close_thread()
