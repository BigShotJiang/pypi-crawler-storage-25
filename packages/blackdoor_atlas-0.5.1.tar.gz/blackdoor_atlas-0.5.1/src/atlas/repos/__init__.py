"""Repository layer — typed Python access to the SQLite tables.

Lands Day 5-7. One module per domain entity, ported 1:1 from
apps/api/src/repos/*. Routes and the agent's PM tools call into these;
no module outside this directory should execute SQL.

  company.py     project.py    task.py
  cycle.py       user.py       memory.py
  session.py     saved_view.py template.py
  insights.py    seed.py
"""
