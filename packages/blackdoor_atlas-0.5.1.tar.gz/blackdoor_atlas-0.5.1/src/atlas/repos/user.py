"""Users.

The CLI is single-user (whoever is logged into the OS). Day 8-10's dashboard
will have a real signup/login flow against the same schema. For the CLI we
auto-create a default user keyed off the OS account email if `git config
user.email` is set, otherwise `local@atlas`.
"""

from __future__ import annotations

import getpass
import subprocess
from dataclasses import dataclass

from atlas.db.connection import connect


@dataclass
class User:
    id: int
    email: str
    created_at: str
    active_company_id: int | None


def find_by_email(email: str) -> User | None:
    row = connect().execute(
        "SELECT id, email, created_at, active_company_id FROM users WHERE email = ?",
        (email,),
    ).fetchone()
    return _from_row(row)


def find_by_id(user_id: int) -> User | None:
    row = connect().execute(
        "SELECT id, email, created_at, active_company_id FROM users WHERE id = ?",
        (user_id,),
    ).fetchone()
    return _from_row(row)


def set_active_company(user_id: int, company_id: int | None) -> None:
    cnx = connect()
    cnx.execute("UPDATE users SET active_company_id = ? WHERE id = ?", (company_id, user_id))
    cnx.commit()


def ensure_default() -> User:
    """Return the CLI's default user, creating one on first call.

    Email comes from `git config --global user.email` when set, falling
    back to `<os-user>@local.atlas`. The password hash is empty — the CLI
    doesn't authenticate; Day 8-10's dashboard adds a real flow.
    """
    email = _detect_email()
    existing = find_by_email(email)
    if existing:
        return existing
    cnx = connect()
    cur = cnx.execute(
        "INSERT INTO users (email, password_hash) VALUES (?, '')",
        (email,),
    )
    cnx.commit()
    new_id = cur.lastrowid
    assert new_id is not None
    fresh = find_by_id(new_id)
    assert fresh is not None
    return fresh


# --- helpers ---------------------------------------------------------------


def _detect_email() -> str:
    try:
        proc = subprocess.run(  # noqa: S603 — fixed binary path
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
        email = (proc.stdout or "").strip()
        if email and "@" in email:
            return email
    except (OSError, subprocess.TimeoutExpired):
        pass
    return f"{getpass.getuser()}@local.atlas"


def _from_row(row) -> User | None:  # type: ignore[no-untyped-def]
    if row is None:
        return None
    return User(
        id=row["id"],
        email=row["email"],
        created_at=row["created_at"],
        active_company_id=row["active_company_id"],
    )
