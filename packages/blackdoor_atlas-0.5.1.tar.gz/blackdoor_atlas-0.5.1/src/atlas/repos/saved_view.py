"""Saved views — Linear-style stored query bundles.

Per-user, per-project. The `payload` is a free-form JSON blob the frontend
shapes (filter set, group_by, sort, etc.). The repo treats it as opaque.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from atlas.db.connection import connect


@dataclass
class SavedView:
    id: int
    user_id: int
    project_id: int | None
    name: str
    payload: dict
    created_at: str


_COLS = "id, user_id, project_id, name, payload, created_at"


def list_for(user_id: int, project_id: int) -> list[SavedView]:
    rows = connect().execute(
        f"""
        SELECT {_COLS} FROM saved_views
         WHERE user_id = ? AND project_id = ?
         ORDER BY id DESC
        """,
        (user_id, project_id),
    ).fetchall()
    return [_from_row(r) for r in rows]


def create(user_id: int, project_id: int, name: str, payload: dict) -> SavedView:
    cnx = connect()
    cur = cnx.execute(
        "INSERT INTO saved_views (user_id, project_id, name, payload) VALUES (?, ?, ?, ?)",
        (user_id, project_id, name, json.dumps(payload)),
    )
    cnx.commit()
    return find_by_id(cur.lastrowid)  # type: ignore[arg-type]


def find_by_id(view_id: int) -> SavedView | None:
    row = connect().execute(
        f"SELECT {_COLS} FROM saved_views WHERE id = ?",
        (view_id,),
    ).fetchone()
    return _from_row(row) if row else None


def delete(user_id: int, project_id: int, view_id: int) -> bool:
    cnx = connect()
    cur = cnx.execute(
        "DELETE FROM saved_views WHERE id = ? AND user_id = ? AND project_id = ?",
        (view_id, user_id, project_id),
    )
    cnx.commit()
    return cur.rowcount > 0


def _from_row(row) -> SavedView:  # type: ignore[no-untyped-def]
    payload = row["payload"]
    try:
        payload = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except json.JSONDecodeError:
        payload = {}
    return SavedView(
        id=row["id"], user_id=row["user_id"], project_id=row["project_id"],
        name=row["name"], payload=payload, created_at=row["created_at"],
    )
