"""Tasks (Linear-style issues) + the things that hang off them.

Ported from apps/api/src/repos/TaskRepo.ts. This module is intentionally
the chunkiest of the repo layer — every PM operation lives here:

  - tasks themselves (CRUD, listing, search, ownership checks)
  - labels attached to tasks (separate from project label catalog)
  - subtasks (the inline checklist inside a task)
  - comments + reactions (Day 8-10 hooks the dashboard at these)
  - activity log (audit trail for each task)
  - children (Linear-style sub-issues)

The agent's PM tools (list_tasks, create_task, update_task) consume a
small slice; the FastAPI dashboard consumes the rest.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Literal

from atlas.db.connection import connect


TaskStatus = Literal["backlog", "todo", "started", "review", "done", "cancelled"]
TaskPriority = Literal["urgent", "high", "med", "low"]


@dataclass
class Task:
    id: int
    project_id: int
    title: str
    body: str
    status: TaskStatus
    priority: TaskPriority
    assignee: str
    due_date: str | None
    sort_index: int
    task_number: int
    estimate: int | None
    parent_id: int | None
    cycle_id: int | None
    created_at: str
    completed_at: str | None


@dataclass
class Subtask:
    id: int
    task_id: int
    title: str
    done: int
    sort_index: int
    created_at: str


@dataclass
class ChildIssue:
    id: int
    task_number: int
    title: str
    status: TaskStatus
    priority: TaskPriority
    estimate: int | None


@dataclass
class TaskWithRels(Task):
    project_key: str = ""
    project_name: str = ""
    project_color: str = ""
    key: str = ""                            # e.g. "LAU-7"
    labels: list[dict] = field(default_factory=list)
    subtasks: list[Subtask] = field(default_factory=list)
    children: list[ChildIssue] = field(default_factory=list)


# --- column lists ----------------------------------------------------------


_TASK_COLS = """
  t.id, t.project_id, t.title, t.body, t.status, t.priority, t.assignee,
  t.due_date, t.sort_index, t.task_number, t.estimate, t.parent_id,
  t.cycle_id, t.created_at, t.completed_at,
  p.key AS project_key, p.name AS project_name, p.color AS project_color
"""


# --- enrichment + helpers --------------------------------------------------


def _enrich(row) -> TaskWithRels:  # type: ignore[no-untyped-def]
    """Convert a SELECT row from `tasks t JOIN projects p` into the wire shape."""
    tid = row["id"]
    base = TaskWithRels(
        id=tid, project_id=row["project_id"], title=row["title"], body=row["body"],
        status=row["status"], priority=row["priority"], assignee=row["assignee"],
        due_date=row["due_date"], sort_index=row["sort_index"],
        task_number=row["task_number"], estimate=row["estimate"],
        parent_id=row["parent_id"], cycle_id=row["cycle_id"],
        created_at=row["created_at"], completed_at=row["completed_at"],
        project_key=row["project_key"], project_name=row["project_name"],
        project_color=row["project_color"],
        key=f"{row['project_key']}-{row['task_number']}",
        labels=list_labels(tid),
        subtasks=list_subtasks(tid),
        children=list_children(tid),
    )
    return base


def list_labels(task_id: int) -> list[dict]:
    rows = connect().execute(
        """
        SELECT l.id, l.project_id, l.name, l.color, l.created_at
          FROM labels l JOIN task_labels tl ON tl.label_id = l.id
         WHERE tl.task_id = ? ORDER BY l.name
        """,
        (task_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def list_subtasks(task_id: int) -> list[Subtask]:
    rows = connect().execute(
        """
        SELECT id, task_id, title, done, sort_index, created_at
          FROM subtasks WHERE task_id = ?
         ORDER BY sort_index, id
        """,
        (task_id,),
    ).fetchall()
    return [Subtask(id=r["id"], task_id=r["task_id"], title=r["title"], done=r["done"],
                    sort_index=r["sort_index"], created_at=r["created_at"]) for r in rows]


def list_children(task_id: int) -> list[ChildIssue]:
    rows = connect().execute(
        """
        SELECT id, task_number, title, status, priority, estimate
          FROM tasks
         WHERE parent_id = ?
         ORDER BY task_number
        """,
        (task_id,),
    ).fetchall()
    return [ChildIssue(id=r["id"], task_number=r["task_number"], title=r["title"],
                        status=r["status"], priority=r["priority"],
                        estimate=r["estimate"]) for r in rows]


# --- workspace-scoped lookups ---------------------------------------------


def find_for_company(task_id: int, company_id: int) -> TaskWithRels | None:
    row = connect().execute(
        f"""
        SELECT {_TASK_COLS} FROM tasks t JOIN projects p ON p.id = t.project_id
         WHERE t.id = ? AND p.company_id = ?
        """,
        (task_id, company_id),
    ).fetchone()
    return _enrich(row) if row else None


def workspace_check(task_id: int, company_id: int) -> dict | None:
    """Cheap existence + status check — no enrichment. Used by the agent
    tools when they only need to confirm the task lives in this workspace."""
    row = connect().execute(
        """
        SELECT t.id, t.project_id, t.status
          FROM tasks t JOIN projects p ON p.id = t.project_id
         WHERE t.id = ? AND p.company_id = ?
        """,
        (task_id, company_id),
    ).fetchone()
    return dict(row) if row else None


# --- listing + search ------------------------------------------------------


def list_in_project(project_id: int, *, cycle_id: int | str | None = None,
                    parent_id: int | str | None = None) -> list[TaskWithRels]:
    where = ["t.project_id = ?"]
    args: list[object] = [project_id]
    if cycle_id == "none":
        where.append("t.cycle_id IS NULL")
    elif isinstance(cycle_id, int):
        where.append("t.cycle_id = ?")
        args.append(cycle_id)
    if parent_id == "none":
        where.append("t.parent_id IS NULL")
    elif isinstance(parent_id, int):
        where.append("t.parent_id = ?")
        args.append(parent_id)
    rows = connect().execute(
        f"""
        SELECT {_TASK_COLS} FROM tasks t JOIN projects p ON p.id = t.project_id
         WHERE {' AND '.join(where)}
         ORDER BY t.status, t.sort_index, t.id
        """,
        args,
    ).fetchall()
    return [_enrich(r) for r in rows]


def inbox_for(company_id: int) -> dict:
    """Open tasks + recently-completed tasks across the whole workspace."""
    open_rows = connect().execute(
        f"""
        SELECT {_TASK_COLS} FROM tasks t JOIN projects p ON p.id = t.project_id
         WHERE p.company_id = ? AND t.status IN ('backlog', 'todo', 'started', 'review')
         ORDER BY
           CASE t.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
           (t.due_date IS NULL), t.due_date, t.created_at
        """,
        (company_id,),
    ).fetchall()
    recent_rows = connect().execute(
        f"""
        SELECT {_TASK_COLS} FROM tasks t JOIN projects p ON p.id = t.project_id
         WHERE p.company_id = ? AND t.status = 'done'
           AND t.completed_at > datetime('now', '-7 days')
         ORDER BY t.completed_at DESC
         LIMIT 10
        """,
        (company_id,),
    ).fetchall()
    return {"open": [_enrich(r) for r in open_rows],
            "recent_done": [_enrich(r) for r in recent_rows]}


# --- create / update / delete ---------------------------------------------


def create(*, project_id: int, title: str, body: str = "",
           status: TaskStatus = "todo", priority: TaskPriority = "med",
           assignee: str = "", due_date: str | None = None,
           estimate: int | None = None, parent_id: int | None = None,
           cycle_id: int | None = None) -> TaskWithRels:
    cnx = connect()
    sort_row = cnx.execute(
        "SELECT COALESCE(MAX(sort_index), -1) AS max_sort FROM tasks WHERE project_id = ? AND status = ?",
        (project_id, status),
    ).fetchone()
    num_row = cnx.execute(
        "SELECT COALESCE(MAX(task_number), 0) AS n FROM tasks WHERE project_id = ?",
        (project_id,),
    ).fetchone()
    cur = cnx.execute(
        """
        INSERT INTO tasks (project_id, title, body, status, priority, assignee,
                           due_date, sort_index, task_number, estimate, parent_id, cycle_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (project_id, title, body, status, priority, assignee, due_date,
         sort_row["max_sort"] + 1, num_row["n"] + 1, estimate, parent_id, cycle_id),
    )
    cnx.commit()
    new_id = cur.lastrowid
    assert new_id is not None
    out = _find_unchecked(new_id)
    assert out is not None
    return out


def update(task_id: int, **patch: object) -> TaskWithRels | None:
    """Patch any subset of: title, body, status, priority, assignee,
    due_date, estimate, parent_id, cycle_id. Unknown keys are ignored."""
    fields: list[str] = []
    values: list[object] = []
    for col in ("title", "body", "status", "priority", "assignee",
                "due_date", "estimate", "parent_id", "cycle_id"):
        if col in patch:
            fields.append(f"{col} = ?"); values.append(patch[col])
    if fields:
        values.append(task_id)
        cnx = connect()
        cnx.execute(f"UPDATE tasks SET {', '.join(fields)} WHERE id = ?", values)
        cnx.commit()
    return _find_unchecked(task_id)


def set_completed_at(task_id: int, value: str | None) -> None:
    cnx = connect()
    cnx.execute("UPDATE tasks SET completed_at = ? WHERE id = ?", (value, task_id))
    cnx.commit()


def delete(task_id: int, company_id: int) -> bool:
    cnx = connect()
    cur = cnx.execute(
        """
        DELETE FROM tasks
         WHERE id = ?
           AND project_id IN (SELECT id FROM projects WHERE company_id = ?)
        """,
        (task_id, company_id),
    )
    cnx.commit()
    return cur.rowcount > 0


def reorder(project_id: int, status: TaskStatus, ordered_ids: list[int]) -> None:
    """Set ``sort_index`` for each id in the given order. Other tasks in the
    column keep their relative order, just shifted past these."""
    if not ordered_ids:
        return
    cnx = connect()
    for index, tid in enumerate(ordered_ids):
        cnx.execute(
            "UPDATE tasks SET sort_index = ? WHERE id = ? AND project_id = ? AND status = ?",
            (index, tid, project_id, status),
        )
    cnx.commit()


# --- labels on tasks -------------------------------------------------------


def attach_label(task_id: int, label_id: int) -> None:
    cnx = connect()
    cnx.execute(
        "INSERT OR IGNORE INTO task_labels (task_id, label_id) VALUES (?, ?)",
        (task_id, label_id),
    )
    cnx.commit()


def detach_label(task_id: int, label_id: int) -> None:
    cnx = connect()
    cnx.execute(
        "DELETE FROM task_labels WHERE task_id = ? AND label_id = ?",
        (task_id, label_id),
    )
    cnx.commit()


# --- activity log ----------------------------------------------------------


def log_activity(task_id: int, kind: str, actor: str, payload: dict | None = None) -> None:
    cnx = connect()
    cnx.execute(
        "INSERT INTO activity (task_id, kind, actor, payload) VALUES (?, ?, ?, ?)",
        (task_id, kind, actor, json.dumps(payload or {})),
    )
    cnx.commit()


# --- helpers ---------------------------------------------------------------


def _find_unchecked(task_id: int) -> TaskWithRels | None:
    row = connect().execute(
        f"SELECT {_TASK_COLS} FROM tasks t JOIN projects p ON p.id = t.project_id WHERE t.id = ?",
        (task_id,),
    ).fetchone()
    return _enrich(row) if row else None
