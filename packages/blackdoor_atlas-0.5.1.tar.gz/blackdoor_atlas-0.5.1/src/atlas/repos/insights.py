"""Project-level insights — what the dashboard's "Insights" tab renders.

Pure aggregation queries; no mutation. Ported from
apps/api/src/repos/InsightsRepo.ts.
"""

from __future__ import annotations

from atlas.db.connection import connect


def for_project(project_id: int) -> dict:
    """Return a flat bundle the React frontend can render without further
    aggregation: counts by status, priority, assignee, plus a daily
    completion sparkline (last 30 days)."""
    cnx = connect()
    by_status = [
        {"status": r["status"], "n": r["n"]}
        for r in cnx.execute(
            "SELECT status, COUNT(*) AS n FROM tasks WHERE project_id = ? GROUP BY status",
            (project_id,),
        ).fetchall()
    ]
    by_priority = [
        {"priority": r["priority"], "n": r["n"]}
        for r in cnx.execute(
            "SELECT priority, COUNT(*) AS n FROM tasks WHERE project_id = ? GROUP BY priority",
            (project_id,),
        ).fetchall()
    ]
    by_assignee = [
        {"assignee": r["assignee"] or "unassigned", "n": r["n"]}
        for r in cnx.execute(
            """
            SELECT COALESCE(NULLIF(assignee, ''), 'unassigned') AS assignee, COUNT(*) AS n
              FROM tasks WHERE project_id = ? GROUP BY assignee ORDER BY n DESC LIMIT 10
            """,
            (project_id,),
        ).fetchall()
    ]
    completion = [
        {"day": r["day"], "n": r["n"]}
        for r in cnx.execute(
            """
            SELECT SUBSTR(completed_at, 1, 10) AS day, COUNT(*) AS n
              FROM tasks
             WHERE project_id = ? AND status = 'done' AND completed_at IS NOT NULL
               AND completed_at > datetime('now', '-30 days')
             GROUP BY day ORDER BY day
            """,
            (project_id,),
        ).fetchall()
    ]
    return {
        "byStatus": by_status,
        "byPriority": by_priority,
        "byAssignee": by_assignee,
        "completion": completion,
    }
