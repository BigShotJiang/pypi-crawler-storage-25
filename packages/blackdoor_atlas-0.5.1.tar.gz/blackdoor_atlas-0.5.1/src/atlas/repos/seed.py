"""First-run seed.

When a fresh user has no workspaces, drop two of them in:

  - **Personal** — empty, where the user will do real work
  - **Demo Co** — pre-populated with two projects (Launchpad, Internal),
    cycles, labels, and ~20 issues so the dashboard + agent tools have
    something interesting to show off without the user having to type
    issues in by hand

Ported from apps/api/src/repos/SeedRepo.ts. Trimmed slightly — the TS
version had a richer issue list; we keep ~half here to land Day 5-7 faster.
Day 11 polish pass can flesh it out.
"""

from __future__ import annotations

import datetime as _dt

from atlas.db.connection import connect
from atlas.repos import company as company_repo
from atlas.repos import project as project_repo
from atlas.repos import task as task_repo


def seed_if_empty(user_id: int) -> bool:
    """Returns True if anything was created. No-op once the user already
    has at least one workspace."""
    row = connect().execute(
        "SELECT COUNT(*) AS n FROM company_members WHERE user_id = ?",
        (user_id,),
    ).fetchone()
    if row and row["n"] > 0:
        return False
    _run(user_id)
    return True


def _run(user_id: int) -> None:
    # Personal workspace — empty.
    company_repo.create(
        owner_id=user_id, name="Personal", color="#5e6ad2",
        description="Your private workspace.",
    )

    # Demo Co — show off the platform.
    demo = company_repo.create(
        owner_id=user_id, name="Demo Co", color="#22c55e",
        description="Demo workspace — explore the board, hotkeys, cycles, and AI agent.",
    )
    company_repo.set_active_for_user(user_id, demo.id)

    now = _dt.date.today()
    completed_iso = _dt.datetime.utcnow().isoformat(timespec="seconds") + "Z"

    # --- Launchpad project ---
    launchpad = project_repo.create(
        user_id=user_id, company_id=demo.id, name="Launchpad",
        description="Public beta. Polish onboarding, lock down billing, ship the marketing site.",
        color="#5e6ad2",
    )
    labels = {
        l.name: project_repo.create_label(launchpad.id, l.name, l.color)
        for l in [
            _LabelSpec("bug",     "#ef4444"),
            _LabelSpec("feature", "#3b82f6"),
            _LabelSpec("design",  "#a855f7"),
            _LabelSpec("infra",   "#10b981"),
            _LabelSpec("docs",    "#f59e0b"),
        ]
    }

    for spec in _LAUNCHPAD_ISSUES:
        t = task_repo.create(
            project_id=launchpad.id,
            title=spec.title, body=spec.body,
            status=spec.status, priority=spec.priority,
            assignee=spec.assignee, estimate=spec.estimate,
        )
        if spec.status in ("done", "cancelled"):
            task_repo.set_completed_at(t.id, completed_iso)
        for name in spec.labels:
            label = labels.get(name)
            if label:
                task_repo.attach_label(t.id, label.id)

    # --- Internal project ---
    internal = project_repo.create(
        user_id=user_id, company_id=demo.id, name="Internal",
        description="Ops, on-call, and quality of life for the team.",
        color="#22c55e",
    )
    int_labels = {
        l.name: project_repo.create_label(internal.id, l.name, l.color)
        for l in [
            _LabelSpec("oncall",  "#dc2626"),
            _LabelSpec("tooling", "#0ea5e9"),
            _LabelSpec("meeting", "#a3a3a3"),
        ]
    }
    for spec in _INTERNAL_ISSUES:
        t = task_repo.create(
            project_id=internal.id,
            title=spec.title, body=spec.body,
            status=spec.status, priority=spec.priority,
            assignee=spec.assignee, estimate=spec.estimate,
        )
        if spec.status in ("done", "cancelled"):
            task_repo.set_completed_at(t.id, completed_iso)
        for name in spec.labels:
            label = int_labels.get(name)
            if label:
                task_repo.attach_label(t.id, label.id)

    _ = now  # cycles + cycle assignment will land in the Day 5-7 follow-up


# --- spec types ------------------------------------------------------------


from dataclasses import dataclass, field  # noqa: E402  (local-to-this-file dataclasses)


@dataclass
class _LabelSpec:
    name: str
    color: str


@dataclass
class _IssueSpec:
    title: str
    status: str
    priority: str
    body: str = ""
    estimate: int | None = None
    assignee: str = ""
    labels: list[str] = field(default_factory=list)


_LAUNCHPAD_ISSUES: list[_IssueSpec] = [
    _IssueSpec(
        title="Onboarding empty-state lands on a useful page",
        status="started", priority="high", estimate=3, assignee="me",
        labels=["feature", "design"],
        body="A new account currently lands on an empty Inbox. Seed a demo workspace.",
    ),
    _IssueSpec(
        title="Billing portal: handle expired card retries",
        status="todo", priority="urgent", estimate=5, assignee="drew",
        labels=["bug", "feature"],
    ),
    _IssueSpec(
        title="Drag card across columns updates status optimistically",
        status="review", priority="med", estimate=2, assignee="mira",
        labels=["feature"],
    ),
    _IssueSpec(
        title="Refactor TaskRow to share a row primitive with Inbox",
        status="started", priority="low", estimate=2, assignee="me",
        labels=["design"],
    ),
    _IssueSpec(
        title="Inline title edit with `e` (Linear parity)",
        status="backlog", priority="med", estimate=2, labels=["feature"],
    ),
    _IssueSpec(
        title="Cycle picker: rotate cycles with Shift+C",
        status="done", priority="med", estimate=1, assignee="me",
        labels=["feature"],
    ),
    _IssueSpec(
        title="Migration runner: idempotent column adds",
        status="done", priority="high", estimate=5, assignee="ivan",
        labels=["infra"],
    ),
    _IssueSpec(
        title="Hero portrait is too dark on the marketing site",
        status="cancelled", priority="low", assignee="drew",
        labels=["design", "bug"],
        body="Decided not to ship the hero shot at launch.",
    ),
    _IssueSpec(
        title="SSO: error states for invalid SAML cert",
        status="backlog", priority="med", estimate=3,
        labels=["feature", "infra"],
    ),
    _IssueSpec(
        title="Docs: update ATLAS.md with the bring-your-own-model table",
        status="todo", priority="med", estimate=1, assignee="me",
        labels=["docs"],
    ),
]

_INTERNAL_ISSUES: list[_IssueSpec] = [
    _IssueSpec(
        title="Rotate Anthropic API key (90-day cadence)",
        status="todo", priority="high", estimate=1, assignee="me",
        labels=["oncall"],
    ),
    _IssueSpec(
        title="Weekly bug triage — Wednesdays 10am",
        status="started", priority="med", assignee="drew",
        labels=["meeting"],
    ),
    _IssueSpec(
        title="Bring up a staging clone of the prod DB",
        status="backlog", priority="med", estimate=5,
        labels=["tooling"],
    ),
    _IssueSpec(
        title="Postmortem: 03-29 deploy outage",
        status="done", priority="urgent", estimate=3, assignee="ivan",
        labels=["oncall"],
    ),
    _IssueSpec(
        title="Add Slack notification on long-running tasks",
        status="review", priority="low", estimate=2, assignee="sasha",
        labels=["tooling"],
    ),
]
