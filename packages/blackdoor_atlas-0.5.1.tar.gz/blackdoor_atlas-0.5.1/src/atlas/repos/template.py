"""Task templates — project-scoped reusable issue presets."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from atlas.db.connection import connect


TaskPriority = Literal["urgent", "high", "med", "low"]


@dataclass
class Template:
    id: int
    project_id: int
    name: str
    title: str
    body: str
    priority: TaskPriority
    estimate: int | None
    created_at: str


_COLS = "id, project_id, name, title, body, priority, estimate, created_at"


def list_for_project(project_id: int) -> list[Template]:
    rows = connect().execute(
        f"SELECT {_COLS} FROM templates WHERE project_id = ? ORDER BY name",
        (project_id,),
    ).fetchall()
    return [_from_row(r) for r in rows]


def create(project_id: int, *, name: str, title: str, body: str = "",
           priority: TaskPriority = "med", estimate: int | None = None) -> Template:
    cnx = connect()
    cur = cnx.execute(
        "INSERT INTO templates (project_id, name, title, body, priority, estimate) VALUES (?, ?, ?, ?, ?, ?)",
        (project_id, name, title, body, priority, estimate),
    )
    cnx.commit()
    return find_by_id(cur.lastrowid)  # type: ignore[arg-type]


def find_by_id(template_id: int) -> Template | None:
    row = connect().execute(
        f"SELECT {_COLS} FROM templates WHERE id = ?",
        (template_id,),
    ).fetchone()
    return _from_row(row) if row else None


def delete(project_id: int, template_id: int) -> bool:
    cnx = connect()
    cur = cnx.execute(
        "DELETE FROM templates WHERE id = ? AND project_id = ?",
        (template_id, project_id),
    )
    cnx.commit()
    return cur.rowcount > 0


def _from_row(row) -> Template:  # type: ignore[no-untyped-def]
    return Template(
        id=row["id"], project_id=row["project_id"], name=row["name"],
        title=row["title"], body=row["body"], priority=row["priority"],
        estimate=row["estimate"], created_at=row["created_at"],
    )
