"""Companies (workspaces).

Ported from apps/api/src/repos/CompanyRepo.ts. A user belongs to many
companies via ``company_members``; the user's ``active_company_id`` points
at the workspace they're currently viewing.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Literal

from atlas.db.connection import connect


Role = Literal["owner", "admin", "member"]


@dataclass
class Company:
    id: int
    name: str
    key: str
    color: str
    description: str
    created_at: str


@dataclass
class CompanyWithMeta(Company):
    role: Role
    member_count: int
    project_count: int
    is_active: bool


def derive_key(name: str) -> str:
    cleaned = "".join(c for c in name if c.isalpha()).upper()
    return (cleaned[:3] or "WRK").ljust(3, "X")


def unique_key(base: str) -> str:
    rows = connect().execute("SELECT key FROM companies").fetchall()
    taken = {r["key"] for r in rows}
    if base not in taken:
        return base
    for i in range(2, 1000):
        candidate = f"{base}{i}"[:4]
        if candidate not in taken:
            return candidate
    return f"{base}{random.randint(0, 999)}"


def find_by_id(company_id: int) -> Company | None:
    row = connect().execute(
        "SELECT id, name, key, color, description, created_at FROM companies WHERE id = ?",
        (company_id,),
    ).fetchone()
    return _from_row(row) if row else None


def list_for_user(user_id: int, active_id: int | None) -> list[CompanyWithMeta]:
    rows = connect().execute(
        """
        SELECT c.id, c.name, c.key, c.color, c.description, c.created_at,
               cm.role AS role,
               (SELECT COUNT(*) FROM company_members WHERE company_id = c.id) AS member_count,
               (SELECT COUNT(*) FROM projects WHERE company_id = c.id) AS project_count
          FROM companies c
          JOIN company_members cm ON cm.company_id = c.id
         WHERE cm.user_id = ?
         ORDER BY c.created_at ASC
        """,
        (user_id,),
    ).fetchall()
    return [
        CompanyWithMeta(
            id=r["id"], name=r["name"], key=r["key"], color=r["color"],
            description=r["description"], created_at=r["created_at"],
            role=r["role"], member_count=r["member_count"],
            project_count=r["project_count"], is_active=(r["id"] == active_id),
        )
        for r in rows
    ]


def create(*, name: str, owner_id: int, color: str = "#5e6ad2", description: str = "") -> Company:
    cnx = connect()
    key = unique_key(derive_key(name))
    cur = cnx.execute(
        "INSERT INTO companies (name, key, color, description) VALUES (?, ?, ?, ?)",
        (name.strip(), key, color, description),
    )
    cid = cur.lastrowid
    assert cid is not None
    cnx.execute(
        "INSERT INTO company_members (company_id, user_id, role) VALUES (?, ?, 'owner')",
        (cid, owner_id),
    )
    cnx.commit()
    fresh = find_by_id(cid)
    assert fresh is not None
    return fresh


def update(company_id: int, *, name: str | None = None, color: str | None = None,
           description: str | None = None) -> Company | None:
    fields: list[str] = []
    values: list[object] = []
    if name is not None:
        fields.append("name = ?"); values.append(name)
    if color is not None:
        fields.append("color = ?"); values.append(color)
    if description is not None:
        fields.append("description = ?"); values.append(description)
    if not fields:
        return find_by_id(company_id)
    values.append(company_id)
    cnx = connect()
    cnx.execute(f"UPDATE companies SET {', '.join(fields)} WHERE id = ?", values)
    cnx.commit()
    return find_by_id(company_id)


def delete(company_id: int) -> bool:
    cnx = connect()
    cur = cnx.execute("DELETE FROM companies WHERE id = ?", (company_id,))
    cnx.commit()
    return cur.rowcount > 0


# --- membership ------------------------------------------------------------


def is_member(company_id: int, user_id: int) -> bool:
    row = connect().execute(
        "SELECT 1 FROM company_members WHERE company_id = ? AND user_id = ?",
        (company_id, user_id),
    ).fetchone()
    return row is not None


def role_of(company_id: int, user_id: int) -> Role | None:
    row = connect().execute(
        "SELECT role FROM company_members WHERE company_id = ? AND user_id = ?",
        (company_id, user_id),
    ).fetchone()
    return row["role"] if row else None


def add_member(company_id: int, user_id: int, role: Role = "member") -> None:
    cnx = connect()
    cnx.execute(
        "INSERT OR IGNORE INTO company_members (company_id, user_id, role) VALUES (?, ?, ?)",
        (company_id, user_id, role),
    )
    cnx.commit()


# --- active workspace ------------------------------------------------------


def set_active_for_user(user_id: int, company_id: int) -> None:
    cnx = connect()
    cnx.execute("UPDATE users SET active_company_id = ? WHERE id = ?", (company_id, user_id))
    cnx.commit()


def resolve_active_for_user(user_id: int) -> int | None:
    """Read users.active_company_id; self-heal to the first membership if
    the stored id no longer points at a valid workspace."""
    row = connect().execute(
        """
        SELECT u.active_company_id AS active,
               (SELECT cm.company_id
                  FROM company_members cm
                 WHERE cm.user_id = u.id
                 ORDER BY cm.joined_at LIMIT 1) AS fallback
          FROM users u WHERE u.id = ?
        """,
        (user_id,),
    ).fetchone()
    if row is None:
        return None
    active = row["active"]
    if active is not None and is_member(active, user_id):
        return active
    if row["fallback"] is not None:
        set_active_for_user(user_id, row["fallback"])
        return row["fallback"]
    return None


# --- helpers ---------------------------------------------------------------


def _from_row(row) -> Company:  # type: ignore[no-untyped-def]
    return Company(
        id=row["id"], name=row["name"], key=row["key"],
        color=row["color"], description=row["description"],
        created_at=row["created_at"],
    )
