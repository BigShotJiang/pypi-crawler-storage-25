"""Cycles — Linear-style time-boxed iterations.

Ported from apps/api/src/repos/CycleRepo.ts. A cycle is owned by one
project; per-project ``number`` is monotonic and used in the UI as the
human-readable identifier (e.g. "Cycle 7").
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from atlas.db.connection import connect


CycleStatus = Literal["upcoming", "active", "completed"]


@dataclass
class Cycle:
    id: int
    project_id: int
    number: int
    name: str
    start_date: str
    end_date: str
    status: CycleStatus
    created_at: str


@dataclass
class CycleWithCounts(Cycle):
    task_count: int
    done_count: int


_COLS = "id, project_id, number, name, start_date, end_date, status, created_at"


def find_by_id(cycle_id: int) -> Cycle | None:
    row = connect().execute(
        f"SELECT {_COLS} FROM cycles WHERE id = ?", (cycle_id,),
    ).fetchone()
    return _from_row(row) if row else None


def list_for_project(project_id: int) -> list[CycleWithCounts]:
    rows = connect().execute(
        f"""
        SELECT {_COLS},
               (SELECT COUNT(*) FROM tasks t WHERE t.cycle_id = c.id) AS task_count,
               (SELECT COUNT(*) FROM tasks t WHERE t.cycle_id = c.id AND t.status = 'done') AS done_count
          FROM cycles c
         WHERE project_id = ?
         ORDER BY start_date DESC, number DESC
        """,
        (project_id,),
    ).fetchall()
    return [
        CycleWithCounts(
            id=r["id"], project_id=r["project_id"], number=r["number"], name=r["name"],
            start_date=r["start_date"], end_date=r["end_date"], status=r["status"],
            created_at=r["created_at"], task_count=r["task_count"], done_count=r["done_count"],
        )
        for r in rows
    ]


def belongs_to_project(cycle_id: int, project_id: int) -> bool:
    row = connect().execute(
        "SELECT 1 FROM cycles WHERE id = ? AND project_id = ?",
        (cycle_id, project_id),
    ).fetchone()
    return row is not None


def create(project_id: int, *, name: str = "", start_date: str, end_date: str) -> Cycle:
    cnx = connect()
    row = cnx.execute(
        "SELECT COALESCE(MAX(number), 0) AS n FROM cycles WHERE project_id = ?",
        (project_id,),
    ).fetchone()
    cur = cnx.execute(
        "INSERT INTO cycles (project_id, number, name, start_date, end_date) VALUES (?, ?, ?, ?, ?)",
        (project_id, row["n"] + 1, name, start_date, end_date),
    )
    cnx.commit()
    return find_by_id(cur.lastrowid)  # type: ignore[arg-type]


def set_status(cycle_id: int, status: CycleStatus) -> None:
    cnx = connect()
    cnx.execute("UPDATE cycles SET status = ? WHERE id = ?", (status, cycle_id))
    cnx.commit()


def delete(project_id: int, cycle_id: int) -> bool:
    cnx = connect()
    cur = cnx.execute(
        "DELETE FROM cycles WHERE id = ? AND project_id = ?",
        (cycle_id, project_id),
    )
    cnx.commit()
    return cur.rowcount > 0


def _from_row(row) -> Cycle:  # type: ignore[no-untyped-def]
    return Cycle(
        id=row["id"], project_id=row["project_id"], number=row["number"], name=row["name"],
        start_date=row["start_date"], end_date=row["end_date"], status=row["status"],
        created_at=row["created_at"],
    )
