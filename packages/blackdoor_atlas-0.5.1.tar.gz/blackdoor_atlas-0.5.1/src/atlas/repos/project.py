"""Projects + labels.

Ported from apps/api/src/repos/ProjectRepo.ts. Labels live with projects
because labels are a project-scoped enum.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from atlas.db.connection import connect


ProjectStatus = Literal["active", "paused", "archived"]


@dataclass
class Project:
    id: int
    user_id: int
    company_id: int | None
    name: str
    description: str
    color: str
    status: ProjectStatus
    key: str
    created_at: str


@dataclass
class ProjectWithCounts(Project):
    task_count: int
    done_count: int


@dataclass
class Label:
    id: int
    project_id: int
    name: str
    color: str
    created_at: str


# --- keys ------------------------------------------------------------------


def derive_key(name: str) -> str:
    cleaned = "".join(c for c in name if c.isalpha()).upper()
    return (cleaned[:3] or "PRJ").ljust(3, "X")


def unique_key(company_id: int, base: str) -> str:
    rows = connect().execute(
        "SELECT key FROM projects WHERE company_id = ?", (company_id,),
    ).fetchall()
    taken = {r["key"] for r in rows}
    if base not in taken:
        return base
    for i in range(2, 1000):
        candidate = f"{base}{i}"[:4]
        if candidate not in taken:
            return candidate
    return base


# --- CRUD ------------------------------------------------------------------


_COLS = "id, user_id, company_id, name, description, color, status, key, created_at"


def list_for_company(company_id: int) -> list[ProjectWithCounts]:
    rows = connect().execute(
        f"""
        SELECT {_COLS},
               (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) AS task_count,
               (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'done') AS done_count
          FROM projects p
         WHERE p.company_id = ?
         ORDER BY p.created_at ASC
        """,
        (company_id,),
    ).fetchall()
    return [_with_counts(r) for r in rows]


def find_by_id(project_id: int) -> Project | None:
    row = connect().execute(
        f"SELECT {_COLS} FROM projects WHERE id = ?", (project_id,),
    ).fetchone()
    return _project(row) if row else None


def find_for_company(project_id: int, company_id: int) -> Project | None:
    row = connect().execute(
        f"SELECT {_COLS} FROM projects WHERE id = ? AND company_id = ?",
        (project_id, company_id),
    ).fetchone()
    return _project(row) if row else None


def create(*, user_id: int, company_id: int, name: str, description: str = "",
           color: str = "#5b8def", status: ProjectStatus = "active") -> Project:
    cnx = connect()
    key = unique_key(company_id, derive_key(name))
    cur = cnx.execute(
        """
        INSERT INTO projects (user_id, company_id, name, description, color, status, key)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (user_id, company_id, name, description, color, status, key),
    )
    cnx.commit()
    pid = cur.lastrowid
    assert pid is not None
    fresh = find_by_id(pid)
    assert fresh is not None
    return fresh


def update(project_id: int, *, name: str | None = None, description: str | None = None,
           color: str | None = None, status: ProjectStatus | None = None) -> Project | None:
    fields: list[str] = []
    values: list[object] = []
    for col, val in (("name", name), ("description", description), ("color", color), ("status", status)):
        if val is not None:
            fields.append(f"{col} = ?"); values.append(val)
    if not fields:
        return find_by_id(project_id)
    values.append(project_id)
    cnx = connect()
    cnx.execute(f"UPDATE projects SET {', '.join(fields)} WHERE id = ?", values)
    cnx.commit()
    return find_by_id(project_id)


def delete(project_id: int, company_id: int) -> bool:
    cnx = connect()
    cur = cnx.execute(
        "DELETE FROM projects WHERE id = ? AND company_id = ?",
        (project_id, company_id),
    )
    cnx.commit()
    return cur.rowcount > 0


# --- labels ----------------------------------------------------------------


def list_labels(project_id: int) -> list[Label]:
    rows = connect().execute(
        "SELECT id, project_id, name, color, created_at FROM labels WHERE project_id = ? ORDER BY name",
        (project_id,),
    ).fetchall()
    return [Label(id=r["id"], project_id=r["project_id"], name=r["name"],
                  color=r["color"], created_at=r["created_at"]) for r in rows]


def create_label(project_id: int, name: str, color: str = "#6b7280") -> Label:
    cnx = connect()
    cur = cnx.execute(
        "INSERT INTO labels (project_id, name, color) VALUES (?, ?, ?)",
        (project_id, name.strip(), color),
    )
    cnx.commit()
    row = cnx.execute(
        "SELECT id, project_id, name, color, created_at FROM labels WHERE id = ?",
        (cur.lastrowid,),
    ).fetchone()
    return Label(id=row["id"], project_id=row["project_id"], name=row["name"],
                 color=row["color"], created_at=row["created_at"])


def delete_label(project_id: int, label_id: int) -> bool:
    cnx = connect()
    cur = cnx.execute(
        "DELETE FROM labels WHERE id = ? AND project_id = ?",
        (label_id, project_id),
    )
    cnx.commit()
    return cur.rowcount > 0


# --- helpers ---------------------------------------------------------------


def _project(row) -> Project:  # type: ignore[no-untyped-def]
    return Project(
        id=row["id"], user_id=row["user_id"], company_id=row["company_id"],
        name=row["name"], description=row["description"], color=row["color"],
        status=row["status"], key=row["key"], created_at=row["created_at"],
    )


def _with_counts(row) -> ProjectWithCounts:  # type: ignore[no-untyped-def]
    return ProjectWithCounts(
        id=row["id"], user_id=row["user_id"], company_id=row["company_id"],
        name=row["name"], description=row["description"], color=row["color"],
        status=row["status"], key=row["key"], created_at=row["created_at"],
        task_count=row["task_count"], done_count=row["done_count"],
    )
