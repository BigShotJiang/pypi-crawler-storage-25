"""Allow `python -m atlas` to behave the same as the `atlas` console script.

Useful for development before the entry point is installed (or when running
inside a virtualenv that's not on PATH).
"""

from atlas.cli.main import run

if __name__ == "__main__":
    raise SystemExit(run())
