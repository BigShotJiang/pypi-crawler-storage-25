"""`atlas uninstall` — remove ATLAS state + its dependencies.

Python packaging has no uninstall hook (pip / pipx don't run our code
when the package is removed). So we expose this as a subcommand the
user runs *before* `pipx uninstall blackdoor-atlas`.

Walks the user through, asking before each step:

  1. Remove ~/.atlas/data.sqlite (workspaces / issues / cycles)
  2. Remove ~/.atlas/config.json (provider keys, settings)
  3. Remove ~/.atlas/sessions/  (chat transcripts)
  4. Remove Ollama models that ATLAS pulled (per-model y/N)
  5. Remove Ollama itself, if ATLAS installed it (brew uninstall ollama / etc.)
  6. Tell the user to run `pipx uninstall blackdoor-atlas`

Each step keys off `_installed_by_atlas` markers in config.json so we
only offer to remove things we ourselves installed.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys

from atlas.cli import theme
from atlas.config import settings as settings_mod


def run() -> int:
    """Interactive uninstall. Returns a shell exit code."""

    print()
    print(f"  {theme.accent('atlas')} — uninstall")
    print()
    print(theme.dim("  This walks through removing ATLAS's local state and any"))
    print(theme.dim("  dependencies (Ollama + models) that ATLAS installed for you."))
    print(theme.dim("  Nothing is removed without an explicit y on each step."))
    print()

    # Snapshot what we installed BEFORE config.json gets removed.
    try:
        s = settings_mod.load()
        ollama_ours = bool(s._extras.get("_ollama_installed_by_atlas"))
        models_ours = list(s._extras.get("_models_installed_by_atlas", []))
    except OSError:
        ollama_ours = False
        models_ours = []

    home = os.environ.get("ATLAS_HOME") or os.path.expanduser("~/.atlas")
    data_sqlite = os.path.join(home, "data.sqlite")
    config_json = os.path.join(home, "config.json")
    sessions_dir = os.path.join(home, "sessions")

    if _confirm(f"Remove your workspace database ({data_sqlite})?"):
        _rm_quiet(data_sqlite)
        _rm_quiet(data_sqlite + "-wal")
        _rm_quiet(data_sqlite + "-shm")
        print(theme.green("    ✓ workspace db removed"))

    if _confirm(f"Remove saved provider keys + settings ({config_json})?"):
        _rm_quiet(config_json)
        print(theme.green("    ✓ config removed"))

    if _confirm(f"Remove chat session transcripts ({sessions_dir})?"):
        _rm_tree_quiet(sessions_dir)
        print(theme.green("    ✓ sessions removed"))

    # Ollama models — ask per-model so the user can keep some.
    if models_ours:
        print()
        print(f"  ATLAS pulled these Ollama models for you: {', '.join(models_ours)}")
        if _confirm("Remove all of them?"):
            for m in models_ours:
                rc = subprocess.call(["ollama", "rm", m])
                if rc == 0:
                    print(theme.green(f"    ✓ removed {m}"))
                else:
                    print(theme.yellow(f"    ⚠ couldn't remove {m} (exit {rc})"))

    # Ollama itself — only if WE installed it.
    if ollama_ours:
        print()
        if _confirm("Remove Ollama itself (you installed it through `atlas init`)?"):
            rc = _uninstall_ollama()
            if rc == 0:
                print(theme.green("    ✓ Ollama uninstalled"))
            else:
                print(theme.yellow(f"    ⚠ uninstall exited {rc}. Run manually: see Ollama docs."))

    print()
    print(theme.bold("  One last step:"))
    print(theme.dim("  ATLAS itself is still installed via pipx. Run:"))
    print()
    print("      pipx uninstall blackdoor-atlas")
    print()
    print(theme.dim("  (Python packaging doesn't let us trigger this from inside the package."))
    print(theme.dim("   It's a one-line manual step.)"))
    print()
    return 0


def _confirm(prompt: str) -> bool:
    """Arrow-key Y/N dialog when interactive, numbered fallback otherwise.
    Defaults to NO — uninstall is destructive, so a misplaced Enter
    shouldn't accidentally wipe state."""
    import sys
    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            from prompt_toolkit.shortcuts import yes_no_dialog
            result = yes_no_dialog(title="atlas uninstall", text=prompt).run()
            return bool(result) if result is not None else False
        except Exception:  # noqa: BLE001
            pass
    try:
        ans = input(f"  {prompt} [y/N]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return ans in ("y", "yes")


def _rm_quiet(path: str) -> None:
    try:
        os.unlink(path)
    except FileNotFoundError:
        pass
    except OSError as e:
        print(theme.yellow(f"    ⚠ couldn't remove {path}: {e}"))


def _rm_tree_quiet(path: str) -> None:
    try:
        shutil.rmtree(path)
    except FileNotFoundError:
        pass
    except OSError as e:
        print(theme.yellow(f"    ⚠ couldn't remove {path}: {e}"))


def _uninstall_ollama() -> int:
    """Platform-specific Ollama removal. Mirrors how `atlas init`
    installed it — `brew uninstall` on Brew-on-macOS, the install
    script's idempotent reverse for Linux, manual for Windows."""
    if sys.platform == "darwin" and shutil.which("brew"):
        return subprocess.call(["brew", "uninstall", "ollama"])
    if sys.platform.startswith("linux"):
        # Ollama's install.sh writes /usr/local/bin/ollama + a systemd unit.
        # Removing them safely needs sudo; we just stop the service + drop
        # the binary + the systemd unit if present.
        rc = subprocess.call(["sh", "-c",
                              "sudo systemctl stop ollama 2>/dev/null; "
                              "sudo systemctl disable ollama 2>/dev/null; "
                              "sudo rm -f /etc/systemd/system/ollama.service "
                              "/usr/local/bin/ollama"])
        return rc
    if sys.platform.startswith("win"):
        print(theme.dim("    Windows: use Settings → Apps → Ollama → Uninstall"))
        return 0
    return 1
