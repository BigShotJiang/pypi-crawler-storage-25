"""Splash screen rendered at REPL start.

Hero ATLAS wordmark (Size 2 — 8-row ANSI Shadow lettering, gradient
cyan→magenta) plus an info block showing what's loaded and how to begin.

Animations (TTY only, suppress via NO_COLOR or ATLAS_NO_SPLASH_ANIM=1):
  - row-by-row reveal of the wordmark (50ms per row, ~400ms total)
  - info block prints after a short beat so the eye lands on the logo first

Layout:
  ┌────────────────────────────────────────────────┐
  │  <gradient ATLAS wordmark, 8 rows>             │
  │                                                 │
  │  ★  <provider> / <model>                       │
  │  ⌂  <cwd>                                      │
  │                                                 │
  │  ↻  resume last session  (20m ago · "…")       │  (if any)
  │                                                 │
  │  Try:                                           │
  │       "…"                                       │
  │       "…"                                       │
  │       "…"                                       │
  │                                                 │
  │  /help · /init · /resume · /quit                │
  └────────────────────────────────────────────────┘

Two public entrypoints:
  - `print_splash(ctx)` — the live TTY path with gradient + animation.
  - `render_splash(ctx)` — plain-text rendering used by tests and any
    environment where `rich` is unimportable.

`SplashContext` is preserved verbatim so `repl.py` doesn't need to change.
"""

from __future__ import annotations

import os
import shutil
import sys
import time
from dataclasses import dataclass

from atlas import __version__  # noqa: F401 — used in plain render footer
from atlas.cli import theme


@dataclass(frozen=True)
class SplashContext:
    """Information surfaced under the wordmark on launch."""

    cwd: str
    workspace: str          # active company / workspace name
    provider: str           # e.g. "anthropic" — empty string when missing
    model: str              # e.g. "claude-opus-4-7"
    mode: str = "code"      # code | ask | plan
    scope: str = "scoped"   # scoped | workspace | unbound


# --- wordmarks ----------------------------------------------------------

# Size 2 — 8 rows tall, ~42 cols wide. ANSI Shadow base font, with two
# extra "filler" rows inserted (one above and one below the crossbar) to
# double the vertical presence vs. the standard 6-row figlet output.
_WORDMARK_HERO = [
    " █████╗ ████████╗██╗      █████╗ ███████╗",
    "██╔══██╗╚══██╔══╝██║     ██╔══██╗██╔════╝",
    "██║  ██║   ██║   ██║     ██║  ██║██║     ",
    "███████║   ██║   ██║     ███████║███████╗",
    "██╔══██║   ██║   ██║     ██╔══██║╚════██║",
    "██║  ██║   ██║   ██║     ██║  ██║     ██║",
    "██║  ██║   ██║   ███████╗██║  ██║███████║",
    "╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚══════╝",
]

# Size 1 — 6 rows, ~42 cols. Used when the terminal is shorter than
# _HERO_MIN_HEIGHT rows so the info block doesn't get pushed off-screen.
_WORDMARK_COMPACT = [
    " █████╗ ████████╗██╗      █████╗ ███████╗",
    "██╔══██╗╚══██╔══╝██║     ██╔══██╗██╔════╝",
    "███████║   ██║   ██║     ███████║███████╗",
    "██╔══██║   ██║   ██║     ██╔══██║╚════██║",
    "██║  ██║   ██║   ███████╗██║  ██║███████║",
    "╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚══════╝",
]

# Vertical gradient — cyan → indigo → violet → magenta, sampled once per
# row. Eight stops for the hero size, six for the compact fallback.
_GRADIENT_HERO = [
    "#7afdfd", "#5fcfff", "#5f9fff", "#7f8fff",
    "#9f7fff", "#bf7fff", "#df7fbf", "#ff7f9f",
]
_GRADIENT_COMPACT = [
    "#7afdfd", "#5fafff", "#7f8fff",
    "#a07fff", "#cf7fcf", "#ff7f9f",
]

_HERO_MIN_HEIGHT = 22  # rows; below this we use the compact wordmark
_ROW_REVEAL_DELAY = 0.05   # seconds between wordmark rows during animation
_POST_LOGO_PAUSE = 0.08    # short beat between logo and info block


# --- public API ---------------------------------------------------------


def print_splash(ctx: SplashContext) -> None:
    """TTY entrypoint. Renders the gradient wordmark with a row-by-row
    reveal, then prints the info block beneath it.

    Non-TTY / NO_COLOR / ATLAS_NO_SPLASH_ANIM=1 → static (no sleeps).
    rich unimportable → falls back to plain `render_splash` text."""

    is_tty = sys.stdout.isatty()
    animate = (
        is_tty
        and os.environ.get("NO_COLOR") is None
        and os.environ.get("ATLAS_NO_SPLASH_ANIM") not in ("1", "true")
    )

    try:
        from rich.console import Console
        from rich.text import Text
    except ImportError:
        print(render_splash(ctx))
        return

    console = Console()
    term_h = shutil.get_terminal_size((80, 24)).lines
    rows = _WORDMARK_HERO if term_h >= _HERO_MIN_HEIGHT else _WORDMARK_COMPACT
    palette = _GRADIENT_HERO if rows is _WORDMARK_HERO else _GRADIENT_COMPACT

    print()
    for row, color in zip(rows, palette):
        console.print(Text("  " + row, style=f"bold {color}"))
        if animate:
            time.sleep(_ROW_REVEAL_DELAY)

    if animate:
        time.sleep(_POST_LOGO_PAUSE)

    print()
    _print_info_block(console, ctx)


def render_splash(ctx: SplashContext) -> str:
    """Plain-text rendering (no rich, no animation). Returns a multi-line
    string. Kept for tests and degraded environments."""

    lines = [""]
    for row in _WORDMARK_HERO:
        lines.append("  " + theme.accent(row))
    lines.append("")
    lines.append(f"  ★  {_provider_label(ctx)}")
    lines.append(f"  ⌂  {_friendly_cwd(ctx.cwd)}")
    resume = _last_session_summary()
    if resume:
        lines.append("")
        lines.append(f"  ↻  resume last session  {theme.dim(resume)}")
    lines.append("")
    lines.append(f"  {theme.dim('Try:')}")
    for s in _STARTER_PROMPTS:
        lines.append(f'      {theme.dim(chr(0x201C))}{s}{theme.dim(chr(0x201D))}')
    lines.append("")
    lines.append(f"  {theme.dim('/help · /init · /resume · /quit')}")
    lines.append("")
    return "\n".join(lines)


# --- info block ---------------------------------------------------------


def _print_info_block(console, ctx: SplashContext) -> None:
    """Static info beneath the wordmark — model, cwd, resume hint,
    starter prompts, slash-command footer."""
    from rich.text import Text

    # Model (provider/model)
    model_line = Text("  ", style="")
    model_line.append("★  ", style="bold yellow")
    if ctx.provider and ctx.model:
        model_line.append(ctx.provider, style="dim")
        model_line.append(" / ", style="dim")
        model_line.append(ctx.model, style="bold white")
    elif ctx.provider:
        model_line.append(ctx.provider, style="bold white")
    else:
        model_line.append("no provider configured — run /init", style="yellow")
    console.print(model_line)

    # Workspace (the folder the user spawned ATLAS in)
    cwd_line = Text("  ", style="")
    cwd_line.append("⌂  ", style="bold cyan")
    cwd_line.append(_friendly_cwd(ctx.cwd), style="cyan")
    console.print(cwd_line)

    # Resume hint (best-effort — silent if no prior sessions)
    resume = _last_session_summary()
    if resume:
        console.print()
        r = Text("  ", style="")
        r.append("↻  ", style="bold green")
        r.append("resume last session  ", style="green")
        r.append(resume, style="dim italic")
        console.print(r)

    # Starter prompts
    console.print()
    console.print(Text("  Try:", style="dim"))
    for s in _STARTER_PROMPTS:
        line = Text("      ", style="")
        line.append("“", style="dim")
        line.append(s, style="white")
        line.append("”", style="dim")
        console.print(line)

    # Footer
    console.print()
    console.print(Text("  /help · /init · /resume · /quit", style="dim"))
    console.print()


# --- helpers ------------------------------------------------------------


_STARTER_PROMPTS = (
    "what changed in this folder recently?",
    "explain this codebase",
    "open a task in my workspace",
)


def _provider_label(ctx: SplashContext) -> str:
    if ctx.provider and ctx.model:
        return f"{ctx.provider} / {ctx.model}"
    if ctx.provider:
        return ctx.provider
    return "no provider configured — run /init"


def _friendly_cwd(path: str) -> str:
    """Tilde-shorten + ellipsize so the path reads as a quick label."""
    home = os.path.expanduser("~")
    if path == home:
        return "~"
    if path.startswith(home + os.sep):
        path = "~" + path[len(home):]
    if len(path) > 60:
        path = "…" + path[-59:]
    return path


def _last_session_summary() -> str:
    """One-line "resumable" hint built from the sessions index. Empty
    string when no prior session exists or the index is unreadable."""
    try:
        from atlas.agent import sessions as sessions_mod
        recent = sessions_mod.list_recent(limit=1)
    except Exception:  # noqa: BLE001
        return ""
    if not recent:
        return ""
    r = recent[0]
    first = (r.get("first_user") or "").strip().replace("\n", " ")
    if len(first) > 40:
        first = first[:39] + "…"
    age = _ago(r.get("updated_at"))
    if first and age:
        return f"({age} · “{first}”)"
    if age:
        return f"({age})"
    if first:
        return f"(“{first}”)"
    return ""


def _ago(iso: str | None) -> str:
    """Short relative age (e.g. "20m ago") from an ISO-8601 timestamp."""
    if not iso:
        return ""
    try:
        import datetime as _dt
        when = _dt.datetime.fromisoformat(iso.replace("Z", "+00:00"))
        now = _dt.datetime.now(when.tzinfo) if when.tzinfo else _dt.datetime.now()
        secs = int((now - when).total_seconds())
    except Exception:  # noqa: BLE001
        return ""
    if secs < 60:
        return "just now"
    if secs < 3600:
        return f"{secs // 60}m ago"
    if secs < 86400:
        return f"{secs // 3600}h ago"
    return f"{secs // 86400}d ago"
