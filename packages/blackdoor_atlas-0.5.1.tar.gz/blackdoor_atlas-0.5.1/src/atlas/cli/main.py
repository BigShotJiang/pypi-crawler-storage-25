"""`atlas` console-script entry point.

Day 1 surface:

  atlas               → REPL in cwd
  atlas chat          → same (alias)
  atlas version       → print version
  atlas --help|-h     → usage
  atlas init          → placeholder (Day 11 wires the real setup wizard)
  atlas dash          → placeholder (Day 12 spawns the FastAPI dashboard)
  atlas stop          → placeholder (Day 12 stops the dashboard)
  atlas config …      → placeholder (Day 11)

Argument parsing stays hand-rolled — argparse would be heavier than the
surface needs, and the dispatch table here is easier to grep when adding
subcommands.
"""

from __future__ import annotations

import os
import sys

from atlas import __version__
from atlas.cli import theme
from atlas.cli.repl import ReplState, run_repl


def run(argv: list[str] | None = None) -> int:
    """Entry point. Returns a shell exit code."""
    args = list(argv if argv is not None else sys.argv[1:])

    if not args or args[0] == "chat":
        return _cmd_chat()

    head = args[0]
    tail = args[1:]

    if head in ("-h", "--help", "help"):
        _print_usage()
        return 0
    if head in ("-V", "--version", "version"):
        print(f"atlas {__version__}")
        return 0
    if head == "init":
        rc = _cmd_init()
        # After a successful setup, drop straight into the REPL — saves
        # the user from typing `atlas` again. On failure (rc != 0) we
        # exit so the error is visible without a second screen of output.
        if rc == 0:
            return _cmd_chat()
        return rc
    if head == "uninstall":
        from atlas.cli import uninstall
        return uninstall.run()
    if head == "dash":
        from atlas.dash import launcher
        return launcher.start(open_browser=("--no-browser" not in tail))
    if head == "stop":
        from atlas.dash import launcher
        return launcher.stop()
    if head == "config":
        return _cmd_config(tail)
    if head == "resume":
        return _cmd_resume(tail)
    if head == "workspace":
        return _cmd_workspace(tail)
    if head == "project":
        return _cmd_project(tail)

    print(theme.red(f"unknown command: atlas {head}"))
    print(theme.dim("run `atlas --help` for the list"))
    return 2


def _cmd_chat() -> int:
    state = ReplState(cwd=os.getcwd())
    return run_repl(state)


def _cmd_init() -> int:
    """Interactive first-run wizard. Idempotent — re-run any time to
    change provider, swap keys, or pull a different Ollama model."""
    from atlas.cli import wizard
    return wizard.run()


def _cmd_config(tail: list[str]) -> int:
    """`atlas config [get|set|list] [key] [value]`."""
    from atlas.config import settings as settings_mod

    if not tail or tail[0] == "list":
        s = settings_mod.load()
        import dataclasses
        for f in dataclasses.fields(s):
            if f.name.startswith("_"):
                continue
            print(f"  {f.name}: {getattr(s, f.name)!r}")
        for k, v in s._extras.items():
            print(f"  {k}: {v!r}")
        return 0

    op = tail[0]
    if op == "get":
        if len(tail) < 2:
            print(theme.red("  usage: atlas config get <key>"))
            return 2
        val = settings_mod.get_key(tail[1])
        if val is None:
            print(theme.dim(f"  {tail[1]} = (unset)"))
        else:
            print(f"  {tail[1]} = {val!r}")
        return 0

    if op == "set":
        if len(tail) < 3:
            print(theme.red("  usage: atlas config set <key> <value>"))
            return 2
        settings_mod.set_key(tail[1], tail[2])
        print(theme.dim(f"  {tail[1]} = {tail[2]!r}  (saved to {settings_mod.config_path()})"))
        return 0

    print(theme.red(f"  unknown config command: {op}"))
    return 2


def _cmd_workspace(tail: list[str]) -> int:
    """`atlas workspace ls` and `atlas workspace switch <name>`."""
    from atlas.repos import company as company_repo
    from atlas.repos import seed as seed_repo
    from atlas.repos import user as user_repo

    user = user_repo.ensure_default()
    seed_repo.seed_if_empty(user.id)

    if not tail or tail[0] == "ls":
        active = company_repo.resolve_active_for_user(user.id)
        rows = company_repo.list_for_user(user.id, active)
        if not rows:
            print(theme.dim("  (no workspaces — run `atlas init`)"))
            return 0
        for c in rows:
            mark = theme.green("●") if c.is_active else theme.dim("○")
            line = f"  {mark}  {theme.bold(c.name)}  {theme.dim(f'[{c.key}] · {c.project_count} projects')}"
            print(line)
        return 0

    if tail[0] == "switch":
        if len(tail) < 2:
            print(theme.red("  usage: atlas workspace switch <name>"))
            return 2
        name = " ".join(tail[1:])
        rows = company_repo.list_for_user(user.id, None)
        match = next((c for c in rows if c.name.lower() == name.lower()), None)
        if match is None:
            print(theme.red(f"  workspace {name!r} not found"))
            return 1
        company_repo.set_active_for_user(user.id, match.id)
        print(theme.dim(f"  switched to {match.name}"))
        return 0

    print(theme.red(f"  unknown workspace command: {tail[0]}"))
    return 2


def _cmd_project(tail: list[str]) -> int:
    """`atlas project ls` — projects in the active workspace."""
    from atlas.repos import company as company_repo
    from atlas.repos import project as project_repo
    from atlas.repos import seed as seed_repo
    from atlas.repos import user as user_repo

    user = user_repo.ensure_default()
    seed_repo.seed_if_empty(user.id)

    if tail and tail[0] not in ("ls", ""):
        print(theme.red(f"  unknown project command: {tail[0]}"))
        return 2

    cid = company_repo.resolve_active_for_user(user.id)
    if cid is None:
        print(theme.dim("  (no active workspace)"))
        return 0
    rows = project_repo.list_for_company(cid)
    if not rows:
        print(theme.dim("  (no projects in active workspace)"))
        return 0
    for p in rows:
        print(f"  {theme.accent(p.key)}  {theme.bold(p.name)}  "
              + theme.dim(f"{p.done_count}/{p.task_count} done · {p.status}"))
    return 0


def _cmd_resume(tail: list[str]) -> int:
    """`atlas resume <session-id>` — reload an earlier transcript and drop
    into the REPL with it. `atlas resume` (no id) lists recent sessions."""
    from atlas.agent import sessions as sessions_mod

    if not tail:
        rows = sessions_mod.list_recent(limit=15)
        if not rows:
            print(theme.dim("  (no prior sessions)"))
            return 0
        print(theme.bold("Recent sessions:"))
        for i, r in enumerate(rows, start=1):
            when = (r.get("updated_at") or r.get("created_at") or "")[:19].replace("T", " ")
            prov = f"{r.get('provider', '')}/{r.get('model', '')}"
            first = (r.get("first_user") or "").replace("\n", " ").strip()[:80]
            print(f"  {i}. {theme.accent(r['session_id'])}  {theme.dim(when)}  {theme.dim(prov)}")
            if first:
                print(theme.dim(f"     {first}"))
        print()
        print(theme.dim("  resume with `atlas resume <session-id>`"))
        return 0

    sid = tail[0]
    stored = sessions_mod.load(sid)
    if stored is None:
        print(theme.red(f"  session {sid} not found"))
        return 1
    state = ReplState(
        cwd=os.getcwd(),
        messages=list(stored.messages),
        session_id=stored.id,
        session_created_at=stored.created_at,
    )
    print(theme.dim(f"  resumed session {stored.id}  ·  {len(stored.messages)} messages"))
    return run_repl(state)


def _placeholder(name: str, plan: str) -> int:
    print(theme.yellow(f"  atlas {name}  —  not yet implemented"))
    print(theme.dim(f"  {plan}"))
    return 0


def _print_usage() -> None:
    print(f"""\
{theme.accent('atlas')} — a terminal AI harness with a built-in project workspace

USAGE
  atlas                 start the REPL in the current directory
  atlas chat            alias for the above
  atlas init            first-run setup (provider keys, defaults)
  atlas dash            launch the web dashboard
  atlas stop            stop the dashboard
  atlas config get|set <key> [<value>]
  atlas resume <session-id>
  atlas workspace ls|switch <name>
  atlas project ls|switch <name>
  atlas uninstall       interactive cleanup before `pipx uninstall blackdoor-atlas`
  atlas version
  atlas --help

Settings live in ~/.atlas/.  Project-local overrides via AGENTS.md /
CLAUDE.md / ATLAS.md in the current directory.

Built on Day 1 of the v0.1 migration — most commands above are placeholders.""")
