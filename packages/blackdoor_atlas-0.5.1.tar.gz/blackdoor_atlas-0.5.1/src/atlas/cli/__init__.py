"""CLI surface for ATLAS.

`atlas.cli.main:run` is the entry point installed by pyproject.toml. It
parses `argv`, dispatches subcommands, and launches the REPL when no
subcommand is given.

Day 1 keeps the surface small:

  atlas              # REPL in cwd (placeholder; agent runtime lands Day 2-4)
  atlas version      # print version
  atlas --help       # usage
  atlas init         # placeholder; full setup wizard lands Day 11
  atlas dash         # placeholder; spawns dashboard on Day 12

Everything is stdlib-only on Day 1 so `pipx install -e .` is friction-free.
prompt_toolkit + rich move in on Day 5 when we polish the REPL.
"""
