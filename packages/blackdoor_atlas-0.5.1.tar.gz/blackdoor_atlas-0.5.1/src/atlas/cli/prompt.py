"""prompt_toolkit-backed REPL input layer.

Replaces stdlib `input()` so we can:

  - bind **Shift+Tab** to cycle the scope (scoped → workspace → unbound)
  - render a **live bottom toolbar** showing provider / model / workspace /
    mode / scope without redrawing on every line
  - get proper history (arrow keys, Ctrl+R reverse-search)
  - **slash-command popup** — typing `/` opens a Claude-Code/Codex-style
    autocompletion menu showing every available `/command` with its
    description, navigable with arrow keys
  - allow Ctrl+J for multi-line, Enter to submit

Falls back to plain stdlib input when prompt_toolkit isn't importable
(should never happen in v0.1 since it's a hard dep, but keeps the smoke
test runnable in stripped environments).
"""

from __future__ import annotations

import os
from typing import Callable

from atlas.cli import theme


# Metadata for the `/` popup. Single source of truth — repl.py reads from
# this to render `/help`, and the completer reads it to show descriptions.
# Keep entries in the order you want them displayed (the completer
# preserves order).
SLASH_COMMANDS: list[tuple[str, str]] = [
    ("help",     "show this list"),
    ("init",     "re-run the setup wizard"),
    ("model",    "switch the active model"),
    ("provider", "switch the active provider"),
    ("mode",     "ask | code | plan — switch agent mode"),
    ("scope",    "scoped | workspace | unbound — set filesystem scope"),
    ("status",   "show provider, workspace, mode, scope"),
    ("reset",    "start a new conversation (clears scope too)"),
    ("version",  "print ATLAS version"),
    ("quit",     "leave the REPL"),
]


def make_session(*, history_path: str, status: Callable[[], str], on_mode_cycle: Callable[[], None]):
    """Build a prompt_toolkit PromptSession ready for `session.prompt(...)`.

    ``status`` is a zero-arg callable that returns the current bottom-toolbar
    text — it gets re-invoked on every redraw, so updating the underlying
    state (mode, scope, etc.) and pressing any key refreshes the bar.

    ``on_mode_cycle`` fires when the user hits Shift+Tab — it should rotate
    the active mode (code → ask → plan → code). The bottom toolbar prints
    "(shift+tab to cycle)" next to the mode label, so this binding is what
    makes that promise true. Scope cycling is now a slash command (`/scope`)
    instead of a hotkey.
    """
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.completion import Completer, Completion
        from prompt_toolkit.formatted_text import ANSI
        from prompt_toolkit.history import FileHistory
        from prompt_toolkit.key_binding import KeyBindings
    except ImportError:
        return None

    class SlashCompleter(Completer):
        """When the line starts with `/`, show every slash command in a
        popup menu. Identical UX to Claude Code / Codex: type `/`, see
        the list, arrow-select, Enter to insert."""

        def get_completions(self, document, _complete_event):  # noqa: ANN001
            text = document.text_before_cursor
            # Only show completions when the prompt buffer is a single
            # slash-prefixed word (i.e. user is in the middle of picking
            # a command). After they've typed an argument, get out of
            # the way.
            if not text.startswith("/") or " " in text:
                return
            partial = text[1:].lower()
            for name, blurb in SLASH_COMMANDS:
                if name.startswith(partial):
                    yield Completion(
                        text=f"/{name}",
                        start_position=-len(text),  # replace from the `/`
                        display=f"/{name}",
                        display_meta=blurb,
                    )

    bindings = KeyBindings()

    @bindings.add("s-tab")
    def _(event) -> None:  # noqa: ANN001 — prompt_toolkit hands its own event
        on_mode_cycle()
        event.app.invalidate()

    @bindings.add("/")
    def _open_slash_popup(event) -> None:  # noqa: ANN001
        """When the user types `/` at the start of the line, immediately
        pop the completion menu so they don't have to also hit Tab.
        Mirrors Claude Code's UX where `/` is the trigger."""
        buf = event.app.current_buffer
        buf.insert_text("/")
        if buf.document.text == "/":
            buf.start_completion(select_first=False)

    # History — wrap so a permission error doesn't crash the REPL.
    try:
        os.makedirs(os.path.dirname(history_path), exist_ok=True)
        history = FileHistory(history_path)
    except OSError:
        history = None

    session = PromptSession(
        history=history,
        key_bindings=bindings,
        bottom_toolbar=lambda: ANSI(status()),
        # Claude-Code-style prompt: a single ` ❯ ` chevron (matches their
        # `figures.pointer`), no "atlas" branding on every line — the splash
        # already established that. References: openclaude's
        # PromptInputFooterSuggestions.tsx uses `figures.pointer` for the same
        # selection-arrow glyph.
        message=ANSI(theme.dim(" ❯ ")),
        completer=SlashCompleter(),
        complete_while_typing=True,
    )
    return session
