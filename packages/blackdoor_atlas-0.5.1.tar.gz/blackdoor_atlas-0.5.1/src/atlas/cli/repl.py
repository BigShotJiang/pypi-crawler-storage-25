"""REPL loop.

Day 1 shipped the shell (splash + slash commands + echo placeholder).
Day 2 wires the agent runtime in — real streaming chat, tool calls,
permission prompts. Day 11 will add the bottom status line and Shift+Tab
scope toggle.
"""

from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field

import datetime as _dt

from atlas.agent import sessions as sessions_mod
from atlas.agent.permissions import Decision, decide
from atlas.agent.providers import select_provider
from atlas.agent.runner import RunOptions, run_agent
from atlas.agent.types import AgentEvent, ChatMessage, Provider
from atlas.cli import theme
from atlas.cli.prompt import SLASH_COMMANDS, make_session
from atlas.cli.render import TurnRenderer
from atlas.cli.splash import SplashContext, print_splash
from atlas.config import settings as settings_mod
from atlas.repos import company as company_repo
from atlas.repos import seed as seed_repo
from atlas.repos import user as user_repo


_SCOPE_ORDER = ("scoped", "workspace", "unbound")
# Mode cycle for Shift+Tab. Matches the order shown in the bottom-toolbar
# label ("code → ask → plan → code"). Slash command `/mode <name>` still
# lets users jump directly.
_MODE_ORDER = ("code", "ask", "plan")


@dataclass
class ReplState:
    """Mutable per-session state. Lives only in memory on Day 2 — Day 11
    wires this to ~/.atlas/config.json so settings survive restarts."""

    cwd: str
    workspace: str = "(none)"
    workspace_id: int | None = None
    user_id: int | None = None
    mode: str = "code"           # code | ask | plan
    scope: str = "scoped"        # scoped | workspace | unbound
    scope_files: list[str] = field(default_factory=list)
    # Conversation history (mutated by the agent loop in place).
    messages: list[ChatMessage] = field(default_factory=list)
    provider: Provider | None = None
    # Set when a session is loaded with `atlas resume <id>` or auto-created
    # on first user turn. Used by save-after-turn so the transcript is
    # searchable later via `session_search`.
    session_id: str | None = None
    session_created_at: str = ""

    @property
    def provider_id(self) -> str:
        return self.provider.id if self.provider else ""

    @property
    def model(self) -> str:
        return self.provider.model if self.provider else ""


def run_repl(state: ReplState) -> int:
    """Block on input until the user quits. Returns a shell exit code."""

    # First-run: if the user has never been through the wizard, run it
    # before dropping into chat. Otherwise their first interaction would
    # be a Mock-provider echo — which is what the wizard exists to prevent.
    s = settings_mod.load()
    if not s.onboarded:
        from atlas.cli import wizard
        rc = wizard.run()
        # If the wizard bailed (Ctrl-C, key validation failed), still drop
        # into chat — the REPL is otherwise functional with the mock fallback.
        if rc not in (0, None):
            print(theme.dim("  continuing into chat with the mock provider"))

    _hydrate_from_settings(state)
    if state.provider is None:
        state.provider = select_provider()
    _ensure_workspace(state)
    print_splash(_splash_context(state))

    history_path = os.path.expanduser("~/.atlas/history")
    session = make_session(
        history_path=history_path,
        status=lambda: _status_line(state),
        on_mode_cycle=lambda: _cycle_mode(state),
    )
    if session is None:
        # prompt_toolkit unavailable (extremely degraded env). Fall back to
        # stdlib `input()` so the REPL is at least usable.
        return _run_basic_loop(state)

    while True:
        try:
            _print_separator()
            line = session.prompt()
        except EOFError:
            print()
            return 0
        except KeyboardInterrupt:
            # Ctrl-C clears the line and re-prompts (bash / claude code behavior).
            continue

        line = line.strip()
        if not line:
            continue

        if line.startswith("/"):
            cmd, _, arg = line[1:].partition(" ")
            action = _dispatch_slash(cmd, arg.strip(), state)
            if action == "quit":
                _persist_settings(state)
                return 0
            continue

        if state.provider is None:
            print(theme.red("  no provider available — run `atlas init` to configure one."))
            print(theme.dim("  for now: set ATLAS_PROVIDER=mock for offline testing."))
            continue

        _run_one_turn(state, line)
        _persist_settings(state)


def _run_basic_loop(state: ReplState) -> int:
    """Stdlib-only fallback used when prompt_toolkit is missing. Same
    semantics, just no bottom toolbar / no Shift+Tab key binding."""
    _maybe_enable_readline()
    while True:
        try:
            line = input(_prompt())
        except EOFError:
            print()
            return 0
        except KeyboardInterrupt:
            print()
            continue
        line = line.strip()
        if not line:
            continue
        if line.startswith("/"):
            cmd, _, arg = line[1:].partition(" ")
            action = _dispatch_slash(cmd, arg.strip(), state)
            if action == "quit":
                return 0
            continue
        if state.provider is None:
            print(theme.red("  no provider available"))
            continue
        _run_one_turn(state, line)


# ---------- settings + status line ----------------------------------------


def _hydrate_from_settings(state: ReplState) -> None:
    """Pull persisted defaults out of ~/.atlas/config.json on launch."""
    s = settings_mod.load()
    state.mode = s.mode
    state.scope = s.scope


def _persist_settings(state: ReplState) -> None:
    """Save the things that should survive a restart. Best-effort —
    permission errors don't kill the REPL."""
    try:
        s = settings_mod.load()
        s.mode = state.mode  # type: ignore[assignment]
        s.scope = state.scope  # type: ignore[assignment]
        s.last_workspace_id = state.workspace_id
        s.last_session_id = state.session_id
        settings_mod.save(s)
    except OSError:
        pass


# Per-mode glyph + 256-color code. Modelled on Claude Code's permission-mode
# treatment in references/openclaude/src/utils/permissions/PermissionMode.ts:
#   acceptEdits  → "▶▶" autoAccept color   (orange — most active)
#   plan         → PAUSE ICON planMode      (blue — paused/thinking)
#   default      → no symbol, text color    (neutral)
# Our modes aren't permission modes (yet), but the visual language still maps
# cleanly: code = active/working = orange ▶▶, ask = quiet = dim grey, plan =
# planning = blue ⏸.
_MODE_GLYPH = {
    "code": ("▶▶", "208"),  # orange — active/working
    "ask":  ("?",  "244"),  # grey — read-only
    "plan": ("⏸",  "33"),   # blue — planning, matches Claude's plan mode
}


def _status_line(state: ReplState) -> str:
    """Bottom toolbar in Claude-Code style: mode glyph + name + cycle hint +
    a handful of shortcut reminders. The full state (provider/model/cwd/org)
    used to crowd this line and duplicate the splash — it's now reachable via
    `/status` when needed.

    Format matches Claude Code's PromptInputFooterLeftSide pattern:
        `<glyph> <mode> mode on  (shift+tab to cycle)  ·  /help  ·  esc to interrupt`
    """
    glyph, color = _MODE_GLYPH.get(state.mode, ("▶▶", "208"))
    # Mode label: colored glyph + bold "<mode> mode on". 38;5;N is 256-color FG;
    # 1 is bold; we close with a single 0 reset so the rest of the line picks
    # up dim styling from `theme.dim()`.
    mode_part = f"\x1b[38;5;{color};1m{glyph} {state.mode} mode on\x1b[0m"
    return (
        f"  {mode_part}  "
        f"{theme.dim('(shift+tab to cycle)')}  "
        f"{theme.dim('·')}  {theme.dim('/help')}  "
        f"{theme.dim('·')}  {theme.dim('esc to interrupt')}"
    )


def _print_separator() -> None:
    """Dim hairline between transcript and the next prompt — Claude-Code-style
    visual break so the input field reads as its own region. Width matches
    the terminal so it spans cleanly; falls back to 80 if we can't detect."""
    import shutil
    width = shutil.get_terminal_size((80, 24)).columns
    print(theme.dim("─" * width))


def _friendly_cwd(path: str) -> str:
    """Tilde-shorten + ellipsize the cwd for the status line.
    Long paths chew up the bottom toolbar and crowd out the other fields,
    so we keep it to ~30 chars by dropping middle segments."""
    home = os.path.expanduser("~")
    if path.startswith(home):
        path = "~" + path[len(home):]
    if len(path) <= 30:
        return path
    # Keep the leading "~/" (or "/") and the last 2 segments.
    head, _, tail = path.partition(os.sep)
    segments = tail.split(os.sep)
    if len(segments) <= 2:
        return path
    return f"{head}{os.sep}…{os.sep}{os.sep.join(segments[-2:])}"


def _scope_glyph(scope: str) -> str:
    return {"scoped": "⌂", "workspace": "◆", "unbound": "⚠"}.get(scope, "·")


def _cycle_mode(state: ReplState) -> None:
    """Shift+Tab handler. Rotates through code → ask → plan → code.

    The bottom toolbar prints "(shift+tab to cycle)" next to the mode label,
    so this binding is what makes that promise true. Filesystem scope still
    cycles via the `/scope` slash command — it's a less frequently changed
    setting and doesn't deserve top-level keyboard real estate."""
    try:
        idx = _MODE_ORDER.index(state.mode)
    except ValueError:
        idx = -1
    state.mode = _MODE_ORDER[(idx + 1) % len(_MODE_ORDER)]


# ---------- workspace bootstrap -------------------------------------------


def _ensure_workspace(state: ReplState) -> None:
    """First-run wiring: get a default user, seed Personal + Demo Co if
    the user has none, and resolve the active workspace into ``state``.

    Silently degrades if the DB can't be opened (sandboxed env): the REPL
    still works, just without PM tools.
    """
    try:
        user = user_repo.ensure_default()
        state.user_id = user.id
        seed_repo.seed_if_empty(user.id)
        cid = company_repo.resolve_active_for_user(user.id)
        state.workspace_id = cid
        if cid is not None:
            c = company_repo.find_by_id(cid)
            if c is not None:
                state.workspace = c.name
    except Exception as e:  # noqa: BLE001 — best-effort, never abort the REPL
        # Surface the failure once at startup so the user can fix it,
        # but don't take the REPL down.
        print(theme.yellow(f"  (workspace unavailable: {e})"))


# ---------- one chat turn -------------------------------------------------

def _run_one_turn(state: ReplState, user_text: str) -> None:
    """Send `user_text` to the agent, render streamed events, and append the
    final transcript to `state.messages`."""

    assert state.provider is not None
    state.messages.append({"role": "user", "content": user_text})

    cancel = [False]
    renderer = TurnRenderer()
    renderer.start_turn()

    def on_event(e: AgentEvent) -> None:
        # Permission prompts need stdin attention and can't share screen
        # real estate with the live spinner. Handle them in the main
        # thread's view of things — the renderer pauses Live, the prompt
        # runs synchronously, the next event resumes the spinner.
        if e.get("type") == "permission_required":
            renderer.on_event(e)  # pauses Live
            token = e.get("token", "")  # type: ignore[arg-type]
            preview = e.get("preview", e.get("tool", "?"))  # type: ignore[arg-type]
            _prompt_permission(token, preview)
            return
        renderer.on_event(e)

    opts = RunOptions(
        provider=state.provider,
        messages=state.messages,
        scope_root=state.cwd,
        workspace_name=state.workspace if state.workspace != "(none)" else None,
        user_id=state.user_id,
        company_id=state.workspace_id,
        mode=state.mode,  # type: ignore[arg-type]
        scope_files=list(state.scope_files),
        cancel=cancel,
    )

    # Run on a background thread so the main thread can intercept Ctrl-C
    # and flip the cancel flag without leaving the runner blocked on a
    # provider call. The thread updates `state.messages` in place.
    err_box: dict[str, str] = {}
    def _drive() -> None:
        try:
            run_agent(opts, on_event)
        except Exception as e:  # noqa: BLE001
            err_box["err"] = str(e)

    worker = threading.Thread(target=_drive, daemon=True)
    worker.start()
    try:
        worker.join()
    except KeyboardInterrupt:
        cancel[0] = True
        worker.join(timeout=5)
        renderer.on_event({"type": "error", "message": "aborted by user"})

    if "err" in err_box:
        renderer.on_event({"type": "error", "message": f"agent error: {err_box['err']}"})

    # Stop Live, print the summary rule, and add a trailing newline so
    # the prompt is visually separated from the assistant's turn.
    renderer.close()
    print()

    # Persist the session to ~/.atlas/sessions/. Saves after every turn so
    # crashing mid-session doesn't lose the transcript — same approach the
    # legacy ./app script took.
    _save_session(state)


def _save_session(state: ReplState) -> None:
    if state.session_id is None:
        state.session_id = sessions_mod.new_session_id()
        state.session_created_at = _dt.datetime.utcnow().isoformat(timespec="seconds") + "Z"
    try:
        sessions_mod.save(sessions_mod.StoredSession(
            id=state.session_id,
            created_at=state.session_created_at,
            updated_at=_dt.datetime.utcnow().isoformat(timespec="seconds") + "Z",
            provider=state.provider_id,
            model=state.model,
            messages=list(state.messages),
        ))
    except OSError:
        # Sandboxed env or write failure — silent. The conversation still
        # lives in memory for the rest of the REPL session.
        pass


def _prompt_permission(token: str, preview: str) -> None:
    """Render the permission preview, read y/N/m from the user, and post the
    decision back through the in-process registry."""
    print()
    lines = preview.split("\n")
    print(theme.yellow("  ⚠ ") + theme.bold(lines[0]))
    for raw in lines[1:]:
        stripped = raw.lstrip()
        if stripped.startswith("+"):
            print(theme.green(raw))
        elif stripped.startswith("-"):
            print(theme.red(raw))
        elif stripped.startswith("$ "):
            print(theme.bold(raw))
        else:
            print(theme.dim(raw))

    print(theme.dim("    allow? [y/N/m=deny with message] "), end="", flush=True)
    try:
        resp = input("").strip().lower()
    except (EOFError, KeyboardInterrupt):
        resp = "n"

    if resp in ("y", "yes"):
        decide(token, Decision(allow=True))
        print(theme.green("    ✓ allowed"))
    elif resp.startswith("m"):
        msg = input(theme.dim("    deny message: ")).strip() or "user declined"
        decide(token, Decision(allow=False, message=msg))
        print(theme.red(f"    ✗ denied — {msg}"))
    else:
        decide(token, Decision(allow=False, message="user declined"))
        print(theme.red("    ✗ denied"))


def _format_tool_input(name: str, input_: dict) -> str:
    """Legacy alias preserved in case external code imports it. The
    canonical version lives in `render._summarize_tool_input`."""
    from atlas.cli.render import _summarize_tool_input
    return _summarize_tool_input(name, input_)


# ---------- slash commands -------------------------------------------------

def _dispatch_slash(cmd: str, arg: str, state: ReplState) -> str | None:
    """Returns the literal string 'quit' to terminate the loop, otherwise None."""
    handler = _SLASH_COMMANDS.get(cmd)
    if not handler:
        print(theme.yellow(f"  unknown command: /{cmd}. /help for the list."))
        return None
    return handler(arg, state)


def _cmd_help(_arg: str, _state: ReplState) -> None:
    """Render `/help` from the same SLASH_COMMANDS metadata the `/` popup
    uses — guarantees the menu and the help text never drift."""
    print()
    print(theme.bold("  Slash commands:"))
    print()
    for name, blurb in SLASH_COMMANDS:
        print(f"  {theme.accent('/' + name):<14}  {theme.dim(blurb)}")
    print()
    print(theme.dim("  Tip: type `/` at the prompt to open the same list with arrow-key selection."))


def _cmd_quit(_arg: str, _state: ReplState) -> str:
    return "quit"


def _cmd_mode(arg: str, state: ReplState) -> None:
    if arg in ("ask", "code", "plan"):
        state.mode = arg
        print(theme.dim(f"  mode = {arg}"))
    else:
        print(theme.yellow("  usage: /mode ask|code|plan"))


def _cmd_scope(arg: str, state: ReplState) -> None:
    if arg in ("scoped", "workspace", "unbound"):
        state.scope = arg
        print(theme.dim(f"  scope = {arg}"))
    else:
        print(theme.yellow("  usage: /scope scoped|workspace|unbound (or press Shift+Tab)"))


def _cmd_status(_arg: str, state: ReplState) -> None:
    # Quick one-liner — Day 11's bottom status line will render this on every
    # turn. For now it's a manual command for visibility.
    print(theme.dim(
        f"  cwd={state.cwd}\n"
        f"  workspace={state.workspace} · provider={state.provider_id or '(none)'}/"
        f"{state.model or '(none)'}\n"
        f"  mode={state.mode} · scope={state.scope}",
    ))


def _cmd_reset(_arg: str, state: ReplState) -> None:
    state.messages.clear()
    state.scope_files.clear()
    print(theme.dim("  (new conversation; scope cleared)"))


def _cmd_version(_arg: str, _state: ReplState) -> None:
    from atlas import __version__
    print(f"  atlas {__version__}")


def _cmd_init(_arg: str, state: ReplState) -> None:
    """Re-run the wizard from inside the REPL. Reloads provider/model
    from the freshly-saved config so the change takes effect immediately
    without needing to /quit + restart."""
    from atlas.cli import wizard
    wizard.run()
    # Re-hydrate from the freshly-saved config and re-select the provider.
    _hydrate_from_settings(state)
    state.provider = select_provider()
    print(theme.dim(
        f"  provider = {state.provider_id or '(none)'}  ·  model = {state.model or '(none)'}"
    ))


def _cmd_model(arg: str, state: ReplState) -> None:
    """Switch the active model.

    `/model <name>`    — direct switch (saved + active immediately)
    `/model`           — interactive picker (Ollama → catalog, others → prompt)
    """
    name = arg.strip()
    if not name:
        name = _pick_model_interactive(state) or ""
    if not name:
        return
    try:
        from atlas.config import settings as settings_mod
        s = settings_mod.load()
        s.model = name
        settings_mod.save(s)
    except OSError as exc:
        print(theme.red(f"  ✗ couldn't save: {exc}"))
        return
    # Rebuild the provider so the in-process Provider instance picks up
    # the new model. Cheap — just a constructor call.
    state.provider = select_provider()
    print(theme.dim(f"  model = {state.model}"))


def _cmd_provider(arg: str, state: ReplState) -> None:
    """Switch the active provider.

    `/provider <id>`   — direct switch
    `/provider`        — opens the wizard (provider menu)
    """
    name = arg.strip().lower()
    if not name:
        _cmd_init("", state)
        return
    valid = {"anthropic", "openai", "ollama", "claude-oauth", "mock"}
    if name not in valid:
        print(theme.yellow(
            f"  unknown provider {name!r}. Valid: {', '.join(sorted(valid))}\n"
            f"  Use `/init` to walk through setup interactively."
        ))
        return
    try:
        from atlas.config import settings as settings_mod
        s = settings_mod.load()
        s.provider = name
        settings_mod.save(s)
    except OSError as exc:
        print(theme.red(f"  ✗ couldn't save: {exc}"))
        return
    state.provider = select_provider()
    if state.provider is None or state.provider.id != name:
        print(theme.yellow(
            f"  Switched to {name!r} but it's not configured. Run `/init` to add a key."
        ))
        return
    print(theme.dim(f"  provider = {state.provider_id}/{state.model}"))


def _pick_model_interactive(state: ReplState) -> str | None:
    """Provider-aware interactive picker. For Ollama, show the catalog
    (RAM-guarded). For paid providers, just prompt for a name."""
    if state.provider_id == "ollama":
        from atlas.cli import wizard
        return wizard._pull_from_catalog()  # noqa: SLF001 — same module, intentional
    print(theme.dim(
        f"  Current model: {state.model or '(unset)'}\n"
        f"  Provider: {state.provider_id or '(unset)'}"
    ))
    name = input("  New model id (Enter to cancel): ").strip()
    return name or None


_SLASH_COMMANDS = {
    "help": _cmd_help,
    "?":    _cmd_help,
    "quit": _cmd_quit,
    "exit": _cmd_quit,
    "q":    _cmd_quit,
    "mode": _cmd_mode,
    "scope": _cmd_scope,
    "status": _cmd_status,
    "version": _cmd_version,
    "reset": _cmd_reset,
    "new":   _cmd_reset,
    "init":     _cmd_init,
    "model":    _cmd_model,
    "provider": _cmd_provider,
}


# `_HELP_TEXT` removed in v0.2.1 — `_cmd_help` now renders from
# `atlas.cli.prompt.SLASH_COMMANDS` so the `/` popup and `/help` share
# one source of truth. Adding a new slash command: register the handler
# in `_SLASH_COMMANDS` here, add the metadata tuple in `prompt.py`.


# ---------- prompt + helpers -----------------------------------------------

def _prompt() -> str:
    # `theme.accent` returns ANSI codes when stdout is a TTY. When we wire
    # readline to it, we need to mark the escape codes so the cursor math
    # for line wrapping stays right — readline interprets \001…\002 around
    # zero-width sequences. The simplest portable solution: only colorize
    # the prompt when readline is NOT in use, otherwise plain text.
    return theme.accent("atlas") + " > "


def _splash_context(state: ReplState) -> SplashContext:
    return SplashContext(
        cwd=state.cwd,
        workspace=state.workspace,
        provider=state.provider_id,
        model=state.model,
        mode=state.mode,
        scope=state.scope,
    )


def _maybe_enable_readline() -> None:
    """Try to wire stdlib `readline` for history + line editing.

    Best-effort: macOS Full Disk Access can cause an OSError on the history
    file path; if anything fails we silently fall back to vanilla `input()`.
    """
    try:
        import atexit
        import readline
    except ImportError:
        return

    history_dir = os.path.expanduser("~/.atlas")
    history_path = os.path.join(history_dir, "history")
    try:
        os.makedirs(history_dir, exist_ok=True)
        if os.path.exists(history_path):
            readline.read_history_file(history_path)
    except OSError:
        # Sandboxed env or permission denied — silently continue.
        return

    readline.set_history_length(1000)

    def _save_history() -> None:
        try:
            readline.write_history_file(history_path)
        except OSError:
            pass

    atexit.register(_save_history)
