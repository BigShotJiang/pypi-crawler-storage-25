"""First-run setup wizard.

Walks the user from zero to a verified AI connection. Render uses
`rich` for panels + progress; logic stays line-by-line so it works
under piped stdin (tests, CI).

Flow:

  1. Menu — Anthropic / OpenAI / Ollama / Mock / Skip
  2. For paid providers: detect env var first, fall back to paste,
     validate via `models.list()`, save to ~/.atlas/config.json chmod 600
  3. For Ollama: detect binary (offer auto-install), check daemon
     (offer to start), present RAM-aware model picker, pull selected
  4. Verification: send a tiny round-trip, show response + latency
  5. Persist and exit

Invoked from `atlas init` (idempotent) or auto-fired on first launch
when `settings.onboarded == False`.
"""

from __future__ import annotations

import getpass
import importlib.resources
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request

from atlas.config import settings as settings_mod


def _console():
    """Lazy import so `atlas --help` doesn't pay the rich-import cost."""
    from rich.console import Console
    return Console()


_OLLAMA_HEALTH_URL = "http://localhost:11434/api/tags"
_OLLAMA_STARTUP_TIMEOUT_S = 12.0

# Refuse models that exceed this fraction of total system RAM. Per user
# guidance: 0.9 — be permissive (some quantizations punch above their
# weight) but block obviously-unrunnable picks.
_RAM_HARD_CAP = 0.9


# --- entry point -----------------------------------------------------------


def run() -> int:
    """Run the wizard interactively. Returns a shell exit code."""
    con = _console()
    from rich.panel import Panel

    con.print()
    con.print(Panel.fit(
        "[bold cyan]atlas[/] — first-time setup\n\n"
        "[dim]Connect ATLAS to an AI provider. Re-run any time with\n"
        "`atlas init` or `atlas config set …`.[/]",
        border_style="cyan",
    ))

    choice = _pick(
        title="atlas — first-time setup",
        text="How would you like to use ATLAS?",
        options=[
            ("anthropic", "Anthropic API key       (Claude — most powerful)"),
            ("openai",    "OpenAI API key          (GPT-4o, GPT-5, etc.)"),
            ("ollama",    "Ollama (local)          (free, runs on your machine)"),
            ("mock",      "Mock (offline)          (echoes input; testing only)"),
            ("skip",      "Skip — configure later  (REPL falls back to mock)"),
        ],
        default="ollama",
    )
    if choice is None:
        choice = "skip"

    if choice == "anthropic":
        return _flow_anthropic()
    if choice == "openai":
        return _flow_openai()
    if choice == "ollama":
        return _flow_ollama()
    if choice == "mock":
        return _save({"provider": "mock", "model": "mock-1", "onboarded": True},
                     summary="Using the offline mock provider.",
                     skip_verify=True)
    return _save({"onboarded": True},
                 summary="Skipped. Run `atlas init` later to connect a provider.",
                 skip_verify=True)


# --- paid-provider flows ---------------------------------------------------


def _flow_anthropic() -> int:
    con = _console()
    con.print()
    con.print("[dim]  Get a key at https://console.anthropic.com/settings/keys[/]")
    con.print("[dim]  (your billing plan controls costs; ATLAS just calls the API)[/]")
    con.print()

    key = _resolve_api_key("Anthropic", "ANTHROPIC_API_KEY", "sk-ant-...")
    if not key:
        return 1

    con.print("[dim]  Testing the key...[/]")
    ok, detail = _test_anthropic(key)
    if not ok:
        con.print(f"  [red]✗ rejected: {detail}[/]")
        con.print("[dim]    Double-check the key (it should start with `sk-ant-`)[/]")
        return 1
    con.print(f"  [green]✓ {detail}[/]")

    default_model = "claude-opus-4-7"
    model = _ask(f"Default model (Enter = {default_model})") or default_model

    rc = _save({
        "provider": "anthropic",
        "model": model,
        "api_keys": {"anthropic": key},
        "onboarded": True,
    }, summary=f"Anthropic provider configured ({model}).")
    if rc != 0:
        return rc
    return _verify("anthropic", model)


def _flow_openai() -> int:
    con = _console()
    con.print()
    con.print("[dim]  Get a key at https://platform.openai.com/api-keys[/]")
    con.print()

    key = _resolve_api_key("OpenAI", "OPENAI_API_KEY", "sk-...")
    if not key:
        return 1

    con.print("[dim]  Testing the key...[/]")
    ok, detail = _test_openai(key)
    if not ok:
        con.print(f"  [red]✗ rejected: {detail}[/]")
        return 1
    con.print(f"  [green]✓ {detail}[/]")

    default_model = "gpt-4o-mini"
    model = _ask(f"Default model (Enter = {default_model})") or default_model

    rc = _save({
        "provider": "openai",
        "model": model,
        "api_keys": {"openai": key},
        "openai_base_url": "",
        "onboarded": True,
    }, summary=f"OpenAI provider configured ({model}).")
    if rc != 0:
        return rc
    return _verify("openai", model)


# --- Ollama flow -----------------------------------------------------------


def _flow_ollama() -> int:
    con = _console()
    con.print()

    path = shutil.which("ollama")
    if path is None:
        rc = _offer_install_ollama()
        if rc != 0:
            return rc
        path = shutil.which("ollama")
        if path is None:
            con.print("  [red]Ollama still not on PATH. Open a new terminal and re-run `atlas init`.[/]")
            return 1
    con.print(f"  [green]✓[/] Ollama binary at [dim]{path}[/]")

    if not _ollama_healthy():
        con.print("[dim]  Daemon isn't running — starting it now...[/]")
        _start_ollama_silent()
        deadline = time.monotonic() + _OLLAMA_STARTUP_TIMEOUT_S
        while time.monotonic() < deadline:
            if _ollama_healthy():
                break
            time.sleep(0.5)
        if not _ollama_healthy():
            con.print("  [red]✗ Daemon didn't come up within 12s. Try `ollama serve` manually.[/]")
            return 1
    con.print("  [green]✓[/] Daemon healthy at localhost:11434")

    installed = _ollama_list_models()
    if installed:
        model = _pick_installed(installed)
    else:
        con.print()
        con.print("  [yellow]No models installed yet.[/] Pick one to pull:")
        model = _pull_from_catalog()

    if model is None:
        return 1

    rc = _save({
        "provider": "ollama",
        "model": model,
        "openai_base_url": "http://localhost:11434/v1",
        "api_keys": {},
        "onboarded": True,
    }, summary=f"Ollama provider configured ({model}).")
    if rc != 0:
        return rc
    return _verify("ollama", model)


def _pick_installed(installed: list[str]) -> str | None:
    options = [(m, m) for m in installed]
    options.append(("__pull__", "Pull a new model…"))
    choice = _pick(
        title="Installed Ollama models",
        text="Pick one to use, or pull a new one.",
        options=options,
        default=installed[0] if installed else "__pull__",
    )
    if choice is None:
        return None
    if choice == "__pull__":
        return _pull_from_catalog()
    return choice


# --- catalog + RAM guard ---------------------------------------------------


def _load_catalog() -> tuple[list[dict], int | None]:
    """Returns (models, default_idx). Reads src/atlas/cli/models.json
    bundled in the wheel — refreshed weekly by the GH Action."""
    try:
        text = (
            importlib.resources.files("atlas.cli")
            .joinpath("models.json")
            .read_text(encoding="utf-8")
        )
        data = json.loads(text)
    except Exception:  # noqa: BLE001
        return [], None
    models = data.get("models")
    if not isinstance(models, list):
        return [], None
    default_idx = next(
        (i for i, m in enumerate(models) if m.get("default") is True),
        None,
    )
    return models, default_idx


def _total_ram_bytes() -> int:
    try:
        import psutil
        return int(psutil.virtual_memory().total)
    except Exception:  # noqa: BLE001
        return 64 * 1_000_000_000  # fall back generous so we don't false-positive refuse


def _pull_from_catalog() -> str | None:
    con = _console()
    models, default_idx = _load_catalog()
    if not models:
        con.print("  [red]model catalog missing or unreadable[/]")
        return None

    total_ram = _total_ram_bytes()
    cap = int(total_ram * _RAM_HARD_CAP)
    ram_gb = total_ram / 1_000_000_000
    cap_gb = cap / 1_000_000_000

    con.print()
    con.print(
        f"  Your machine: [bold]{ram_gb:.1f} GB[/] system memory. "
        f"[dim]Refusing models > {cap_gb:.1f} GB.[/]"
    )

    # Build option list with tier-grouped labels. Each model's label
    # encodes its id + size + blurb in a fixed-width column layout so
    # the radiolist columns align. Too-big models stay in the list
    # (so the user can see they exist) but are tagged ✗ and refused
    # on selection.
    name_width = max(len(m["id"]) for m in models)
    size_width = max(len(m["size_human"]) for m in models)
    options: list[tuple[str, str]] = []
    rejected: set[str] = set()
    last_tier: str | None = None
    default_value: str | None = None

    for i, m in enumerate(models):
        tier = m.get("tier", "mid")
        if tier != last_tier:
            options.append((f"__sep_{tier}__", f"── {_tier_label(tier)} ──"))
            last_tier = tier

        too_big = m["size_bytes"] > cap
        if too_big:
            rejected.add(m["id"])
            label = (
                f"✗ {m['id']:<{name_width}}  {m['size_human']:>{size_width}}  "
                f"{m['blurb']}  (too big for {ram_gb:.0f} GB)"
            )
        else:
            star = "★ " if i == default_idx else "  "
            label = (
                f"{star}{m['id']:<{name_width}}  {m['size_human']:>{size_width}}  {m['blurb']}"
            )
        options.append((m["id"], label))
        if i == default_idx and default_value is None:
            default_value = m["id"]

    options.append(("__custom__", "  Type a custom model name…"))

    choice = _pick(
        title="Pick a model to pull",
        text=f"{ram_gb:.1f} GB system RAM · refusing > {cap_gb:.1f} GB",
        options=options,
        default=default_value,
    )
    if choice is None:
        return None
    # Separators are not selectable values, but radiolist may return them
    # if the user navigates onto one. Reject and prompt again would be
    # ideal; for v0.2 we just treat as cancel.
    if choice.startswith("__sep_"):
        return None

    if choice == "__custom__":
        name = _ask("Model name (e.g. `llama3.1:8b`)").strip()
        if not name:
            con.print("[dim]  no model name entered — aborting[/]")
            return None
        return _pull_with_progress(name)

    if choice in rejected:
        con.print(
            f"  [red]✗ {choice} exceeds your {ram_gb:.1f} GB cap. Pick a smaller one.[/]"
        )
        return None

    return _pull_with_progress(choice)


def _pull_with_progress(model: str) -> str | None:
    """Run `ollama pull <model>` and let it print its own progress bar.
    Also records the model under `_models_installed_by_atlas` in settings
    so the future `atlas uninstall` command knows it's safe to remove."""
    con = _console()
    con.print()
    con.print(f"[dim]  Pulling [bold]{model}[/][dim] — this may take several minutes.[/]")
    con.print()
    rc = subprocess.call(["ollama", "pull", model])
    if rc != 0:
        con.print(f"  [red]✗ pull failed (exit {rc}).[/]")
        return None
    con.print(f"  [green]✓ {model} ready[/]")

    try:
        s = settings_mod.load()
        installed: list[str] = list(s._extras.get("_models_installed_by_atlas", []))
        if model not in installed:
            installed.append(model)
        s._extras["_models_installed_by_atlas"] = installed
        settings_mod.save(s)
    except OSError:
        pass

    return model


def _tier_label(tier: str) -> str:
    return {
        "tiny": "Tiny — runs on anything",
        "mid": "Mid — the 8B sweet spot",
        "reasoning": "Reasoning — chain-of-thought",
        "heavy": "Heavy — real RAM requirements",
    }.get(tier, tier.title())


# --- Ollama install --------------------------------------------------------


def _offer_install_ollama() -> int:
    """Detect platform, propose an install command, ask y/N, run it.
    Marks `_ollama_installed_by_atlas = true` in settings on success so
    `atlas uninstall` knows it's safe to remove."""
    con = _console()
    con.print("[dim]  Ollama isn't installed on this machine.[/]")
    con.print()

    if sys.platform == "darwin":
        if shutil.which("brew"):
            cmd = ["brew", "install", "ollama"]
            label = "brew install ollama"
            duration = "~30 seconds on Apple Silicon"
        else:
            con.print("  Two ways to install Ollama on macOS:")
            con.print("[dim]    1. Download https://ollama.com/download (drag .app to /Applications)[/]")
            con.print("[dim]    2. `brew install ollama` (install Homebrew first)[/]")
            con.print()
            con.print("[dim]  Re-run `atlas init` once Ollama is on your PATH.[/]")
            return 1
    elif sys.platform.startswith("linux"):
        cmd = ["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"]
        label = "curl -fsSL https://ollama.com/install.sh | sh"
        duration = "~30 seconds plus daemon registration"
    elif sys.platform.startswith("win"):
        con.print("  On Windows install via:")
        con.print("[dim]    https://ollama.com/download/OllamaSetup.exe[/]")
        con.print()
        con.print("[dim]  Run it, then re-run `atlas init`.[/]")
        return 1
    else:
        con.print(f"[dim]  Unsupported platform: {sys.platform}[/]")
        return 1

    con.print(f"  About to run: [bold]{label}[/]")
    con.print(f"[dim]  ({duration})[/]")
    if not _yes(
        title="Install Ollama",
        text=f"Run `{label}`?\n\n{duration}",
        default=True,
    ):
        con.print("[dim]  Skipped. Install Ollama manually then re-run `atlas init`.[/]")
        return 1

    con.print()
    rc = subprocess.call(cmd)
    if rc != 0:
        con.print(f"  [red]✗ install exited {rc}.[/]")
        return 1
    con.print("  [green]✓ Ollama installed[/]")

    try:
        s = settings_mod.load()
        s._extras["_ollama_installed_by_atlas"] = True
        settings_mod.save(s)
    except OSError:
        pass
    return 0


# --- verification turn -----------------------------------------------------


def _verify(provider_id: str, model: str) -> int:
    """Send a tiny round-trip to confirm the saved config actually works.
    Best-effort — failures print a warning but don't roll back the save."""
    con = _console()
    con.print()
    con.print(f"[dim]  Testing {provider_id}/{model}...[/]")

    from atlas.agent.providers import select_provider
    from atlas.agent.runner import RunOptions, run_agent

    p = select_provider()
    if p is None or p.id == "mock":
        con.print("  [yellow]⚠ couldn't load the configured provider — try `atlas init` again[/]")
        return 0

    start = time.monotonic()
    text_buf: list[str] = []

    def emit(e):
        if e.get("type") == "text_delta":
            text_buf.append(e.get("text", ""))

    try:
        run_agent(
            RunOptions(
                provider=p,
                messages=[{"role": "user", "content": "Reply with just the word OK."}],
                scope_root=os.getcwd(),
                confirm=False,
                max_iterations=1,
                user_id=None,
                company_id=None,
            ),
            emit,
        )
    except Exception as e:  # noqa: BLE001
        con.print(f"  [yellow]⚠ verify failed: {e}[/]")
        con.print("[dim]    Saved anyway — re-run `atlas init` if this is a config problem.[/]")
        return 0

    elapsed = time.monotonic() - start
    reply = "".join(text_buf).strip()
    if not reply:
        con.print("  [yellow]⚠ no response received — config saved but unverified[/]")
        return 0

    snippet = reply if len(reply) <= 60 else reply[:60] + "…"
    con.print(f"  [green]✓ online[/] [dim]({elapsed:.1f}s · reply: {snippet!r})[/]")
    return 0


# --- I/O helpers -----------------------------------------------------------


def _resolve_api_key(label: str, env_var: str, placeholder: str) -> str:
    """Get an API key. Prefer an existing env var (offer to use it),
    fall back to a no-echo paste. Returns "" on cancel."""
    con = _console()
    env_value = (os.environ.get(env_var) or "").strip()
    if env_value:
        masked = env_value[:7] + "…" + env_value[-3:] if len(env_value) > 12 else "***"
        con.print(f"  Found [bold]{env_var}[/] in your shell: [dim]{masked}[/]")
        if _yes(title="Use existing key", text=f"Use {env_var} from your shell?", default=True):
            return env_value
        con.print("[dim]  OK — paste a different key.[/]")
    return _ask_secret(f"Paste your {label} key ({placeholder})")


def _yes(*, title: str, text: str, default: bool = True) -> bool:
    """Arrow-key Yes / No when interactive; numbered fallback otherwise.
    `default` is what an empty Enter or a cancelled dialog returns."""
    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            from prompt_toolkit.shortcuts import yes_no_dialog
            result = yes_no_dialog(title=title, text=text).run()
            return bool(result) if result is not None else default
        except Exception:  # noqa: BLE001
            pass
    suffix = "[Y/n]" if default else "[y/N]"
    raw = (_ask(f"{text} {suffix}") or "").strip().lower()
    if not raw:
        return default
    return raw in ("y", "yes")


def _pick(
    *,
    title: str,
    text: str,
    options: list[tuple[str, str]],
    default: str | None = None,
) -> str | None:
    """Arrow-key picker when stdin/stdout are both real TTYs; falls back
    to a numbered prompt when piped (CI tests, scripted installs).

    Returns the value of the picked option, or None on cancel.

    Why both modes: prompt_toolkit's full-screen dialog mode requires a
    real terminal — it'll error or hang under piped stdin. Falling back
    to numbered input keeps the wizard scriptable from `printf …| atlas`
    and from CI smoke tests.
    """
    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            from prompt_toolkit.shortcuts import radiolist_dialog
            return radiolist_dialog(
                title=title,
                text=text,
                values=options,
                default=default,
                ok_text="Select",
                cancel_text="Skip",
            ).run()
        except Exception:  # noqa: BLE001 — degrade gracefully on weird ttys
            pass

    # Piped fallback — numbered list.
    con = _console()
    con.print()
    if title:
        con.print(f"  [bold]{title}[/]")
    if text:
        con.print(f"  [dim]{text}[/]")
    con.print()

    # Hide separator entries from the numbered fallback — they're purely
    # visual scaffolding in the interactive picker.
    pickable = [(v, label) for v, label in options if not v.startswith("__sep_")]

    default_idx: int | None = None
    for i, (val, label) in enumerate(pickable, start=1):
        marker = "▶" if val == default else " "
        if val == default:
            default_idx = i
            con.print(f"  {marker} [bold]{i}. {label}[/]")
        else:
            con.print(f"  {marker} [bold]{i}.[/] {label}")
    con.print()

    default_hint = f" (Enter = {default_idx})" if default_idx else ""
    raw = _ask(f"Pick [1-{len(pickable)}]{default_hint}")
    if not raw and default_idx:
        return pickable[default_idx - 1][0]
    try:
        idx = int(raw) - 1
        return pickable[idx][0]
    except (ValueError, IndexError):
        con.print(f"  [red]invalid choice: {raw!r}[/]")
        return None


def _ask(prompt: str) -> str:
    try:
        return input(f"  {prompt}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ""


def _ask_secret(prompt: str) -> str:
    try:
        return (getpass.getpass(f"  {prompt}: ") or "").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ""
    except Exception:  # noqa: BLE001
        return _ask(prompt)


def _save(patch: dict, *, summary: str, skip_verify: bool = False) -> int:
    con = _console()
    s = settings_mod.load()
    for k, v in patch.items():
        if k == "api_keys":
            merged = dict(s.api_keys)
            merged.update(v)
            s.api_keys = merged
        else:
            setattr(s, k, v)
    try:
        settings_mod.save(s)
    except OSError as e:
        con.print(f"  [red]✗ couldn't write config: {e}[/]")
        return 1
    con.print()
    con.print(f"  [green]✓ {summary}[/]")
    con.print(f"[dim]    saved to {settings_mod.config_path()}[/]")
    if skip_verify:
        con.print()
    return 0


# --- provider key validation ----------------------------------------------


def _test_anthropic(key: str) -> tuple[bool, str]:
    try:
        from anthropic import Anthropic  # type: ignore[import-not-found]
    except ImportError:
        return True, "anthropic SDK missing — saved without validation"
    try:
        client = Anthropic(api_key=key)
        models = list(client.models.list(limit=1))
        return True, f"authenticated ({models[0].id} visible)" if models else "authenticated"
    except Exception as e:  # noqa: BLE001
        return False, _short_err(e)


def _test_openai(key: str) -> tuple[bool, str]:
    try:
        from openai import OpenAI  # type: ignore[import-not-found]
    except ImportError:
        return True, "openai SDK missing — saved without validation"
    try:
        client = OpenAI(api_key=key)
        page = client.models.list()
        first = next(iter(page), None)
        return True, f"authenticated ({first.id} visible)" if first else "authenticated"
    except Exception as e:  # noqa: BLE001
        return False, _short_err(e)


def _short_err(e: Exception) -> str:
    msg = str(e)
    return msg if len(msg) <= 200 else msg[:197] + "..."


# --- Ollama helpers --------------------------------------------------------


def _ollama_healthy() -> bool:
    try:
        with urllib.request.urlopen(_OLLAMA_HEALTH_URL, timeout=0.8) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, OSError, TimeoutError):
        return False


def _start_ollama_silent() -> None:
    devnull = subprocess.DEVNULL
    try:
        subprocess.Popen(
            ["ollama", "serve"],
            stdin=devnull, stdout=devnull, stderr=devnull,
            start_new_session=True,
        )
    except OSError:
        pass


def _ollama_list_models() -> list[str]:
    try:
        with urllib.request.urlopen(_OLLAMA_HEALTH_URL, timeout=2) as resp:
            body = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, OSError, ValueError):
        return []
    models = body.get("models")
    if not isinstance(models, list):
        return []
    return sorted(m["name"] for m in models if isinstance(m, dict) and isinstance(m.get("name"), str))
