"""Minimal ANSI color helpers — stdlib only.

Day 1's REPL output uses raw ANSI escapes. Day 5 swaps in `rich` for the
polish pass (status line styling, gradient logo, syntax-highlighted diffs).
Until then, this module is the single source of truth for color codes so
disable-when-not-a-TTY logic only lives in one place.

Honors NO_COLOR (https://no-color.org) and isatty so piping `atlas` into
`less` or a log file produces clean text.
"""

from __future__ import annotations

import os
import sys

# Resolve once at import time. Tests can monkeypatch `_USE_COLOR` directly.
_USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def _wrap(code: str, text: str) -> str:
    if not _USE_COLOR:
        return text
    return f"\x1b[{code}m{text}\x1b[0m"


def bold(text: str) -> str:
    return _wrap("1", text)


def dim(text: str) -> str:
    return _wrap("2", text)


def italic(text: str) -> str:
    return _wrap("3", text)


def underline(text: str) -> str:
    return _wrap("4", text)


# Named colors — short list, brand-aligned.
def red(text: str) -> str:
    return _wrap("31", text)


def green(text: str) -> str:
    return _wrap("32", text)


def yellow(text: str) -> str:
    return _wrap("33", text)


def blue(text: str) -> str:
    return _wrap("34", text)


def magenta(text: str) -> str:
    return _wrap("35", text)


def cyan(text: str) -> str:
    return _wrap("36", text)


# Brand accent — used for the wordmark and the status-line "atlas" prefix.
# A bold cyan reads well on both dark and light terminals.
def accent(text: str) -> str:
    return _wrap("1;36", text)
