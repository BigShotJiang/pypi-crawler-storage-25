"""Chat-turn renderer.

Owns what the user sees while the agent is generating a turn:

  - **Live activity line** while the model is silent (`✻ Thinking… 4.2s`)
    or running a tool (`✻ Running read_file… 6.1s`). Driven by the
    `heartbeat` events the runner emits every 3s.
  - **Tool call cards** — each tool gets a small framed panel showing
    the verb + summarised input, then a `✓ result` line below.
  - **Streamed text** flows below; spinner gets out of the way.
  - **Thinking content** is wrapped in a labelled, dimmed section.
  - **End-of-turn summary rule** — elapsed time + tool count + tokens.

Falls back to a plain print-each-event mode under non-TTY stdout (CI,
tests, piped input) so the smoke tests still see deterministic output.

Threading: `on_event` is called from the worker thread that drives the
runner. `rich.live.Live.update()` is thread-safe; `console.print()`
while a Live is active is the supported pattern (rich reflows the live
region above the printed line). We don't need our own lock.
"""

from __future__ import annotations

import sys
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TurnRenderer:
    """One instance per turn. Build, call ``start_turn()``, feed
    ``on_event(...)`` events, then ``close()`` when the runner returns."""

    # Whether to use the rich live mode. False for piped stdout / CI.
    simple: bool = field(default_factory=lambda: not sys.stdout.isatty())

    # Internal state ----------------------------------------------------
    _start: float = 0.0
    _verb: str = "Thinking"
    _tool_count: int = 0
    _streaming_text: bool = False
    _streaming_thinking: bool = False
    _tool_started_at: dict[str, float] = field(default_factory=dict)
    _usage: dict[str, int] = field(default_factory=dict)
    _live: Any = None
    _console: Any = None

    # --- lifecycle -----------------------------------------------------

    def start_turn(self) -> None:
        from rich.console import Console
        self._console = Console()
        self._start = time.monotonic()
        self._start_live()

    def close(self) -> None:
        """Called by the caller after run_agent returns (or aborts)."""
        self._stop_live()
        # Always force a newline before the summary rule. In simple mode
        # we wrote text deltas via raw sys.stdout.write, which leaves the
        # cursor mid-line — rich.Console doesn't track that, so its rule
        # would otherwise render starting mid-text.
        print()
        self._render_summary()

    # --- event entry point --------------------------------------------

    def on_event(self, event: dict) -> None:
        if self.simple:
            self._simple_render(event)
            return

        kind = event.get("type")
        if kind == "heartbeat":
            if self._live is not None and not self._streaming_text and not self._streaming_thinking:
                self._live.update(self._spinner_renderable())
            return

        if kind == "text_delta":
            self._on_text_delta(event)
            return

        if kind == "thinking_delta":
            self._on_thinking_delta(event)
            return

        if kind == "tool_use":
            self._on_tool_use(event)
            return

        if kind == "tool_result":
            self._on_tool_result(event)
            return

        if kind == "permission_required":
            # The REPL's prompt logic handles the y/N inline; we just
            # stop the live region so the prompt isn't fighting it for
            # cursor real estate. The next event after the user decides
            # will restart the spinner.
            self._stop_live()
            self._streaming_text = False
            self._streaming_thinking = False
            return

        if kind == "error":
            self._stop_live()
            self._console.print(f"  [red]✗ {event.get('message', '')}[/]")
            return

        if kind == "usage":
            for k, v in event.items():
                if k != "type" and isinstance(v, int):
                    self._usage[k] = v
            return

        if kind == "done":
            self._stop_live()
            return

        # `started`, `message_stop`: silent.

    # --- per-event handlers -------------------------------------------

    def _on_text_delta(self, event: dict) -> None:
        text = event.get("text", "")
        if not text:
            return
        if not self._streaming_text:
            self._stop_live()
            if self._streaming_thinking:
                # Close out the thinking block before response starts
                self._console.print()
                self._console.print()
                self._streaming_thinking = False
            self._streaming_text = True
        # markup=False keeps `[…]` in model output from being parsed as rich tags
        self._console.print(text, end="", markup=False, highlight=False, soft_wrap=True)

    def _on_thinking_delta(self, event: dict) -> None:
        text = event.get("text", "")
        if not text:
            return
        if not self._streaming_thinking:
            self._stop_live()
            self._console.print()
            self._console.print("  [dim italic]── Thinking ──[/]")
            self._streaming_thinking = True
        self._console.print(
            f"[dim italic]{text}[/]",
            end="", markup=True, highlight=False, soft_wrap=True,
        )

    def _on_tool_use(self, event: dict) -> None:
        # If we were mid-stream, end the line first.
        if self._streaming_text or self._streaming_thinking:
            self._console.print()
            self._streaming_text = False
            self._streaming_thinking = False
        self._stop_live()
        self._tool_count += 1
        self._tool_started_at[event["id"]] = time.monotonic()
        self._render_tool_card(event)
        self._verb = f"Running {event['name']}"
        self._start_live()

    def _on_tool_result(self, event: dict) -> None:
        self._stop_live()
        elapsed = time.monotonic() - self._tool_started_at.get(event["id"], time.monotonic())
        self._render_tool_result(event, elapsed)
        self._verb = "Thinking"
        self._start_live()

    # --- rendering helpers --------------------------------------------

    def _spinner_renderable(self):
        from rich.text import Text
        elapsed = time.monotonic() - self._start
        # Claude-Code-style activity indicator: orange `*` + verb + elapsed,
        # esc hint to the right. Orange (#ff8c00 ≈ ansi 208) reads as
        # "agent is working" without competing with the brand accent cyan
        # used elsewhere in the splash and tool cards.
        return Text.assemble(
            ("  * ", "bold dark_orange"),
            (self._verb + "…", "dark_orange"),
            (f"  {elapsed:.1f}s", "dim"),
            ("    [esc to interrupt]", "dim"),
        )

    def _render_tool_card(self, event: dict) -> None:
        from rich.panel import Panel
        from rich.text import Text
        name = event.get("name", "")
        input_ = event.get("input", {})
        summary = _summarize_tool_input(name, input_)
        body = Text(summary, style="dim")
        self._console.print(Panel(
            body,
            title=f"[bold cyan]⏵ {name}[/]",
            title_align="left",
            border_style="cyan",
            padding=(0, 1),
            expand=False,
        ))

    def _render_tool_result(self, event: dict, elapsed: float) -> None:
        is_err = bool(event.get("is_error"))
        content = str(event.get("content", ""))
        lines = content.split("\n")
        first_line = lines[0][:80] if lines else ""
        more = len(lines) - 1
        glyph = "[red]✗[/]" if is_err else "[green]✓[/]"
        suffix = f"  [dim](+{more} lines)[/]" if more > 0 else ""
        time_str = f"  [dim]{elapsed:.1f}s[/]" if elapsed > 0.05 else ""
        # Two-space indent so it visually nests under the tool card.
        safe = first_line.replace("[", r"\[")
        self._console.print(f"  {glyph} {safe}{suffix}{time_str}")

    def _render_summary(self) -> None:
        elapsed = time.monotonic() - self._start
        parts = [f"Done in {elapsed:.1f}s"]
        if self._tool_count:
            parts.append(f"{self._tool_count} tool{'' if self._tool_count == 1 else 's'}")
        out = self._usage.get("output_tokens")
        if out:
            parts.append(f"~{out} tokens out")
        if self._console is not None:
            self._console.rule(" · ".join(parts), style="dim", align="left")

    # --- Live management ----------------------------------------------

    def _start_live(self) -> None:
        if self.simple or self._live is not None:
            return
        if self._streaming_text or self._streaming_thinking:
            return
        from rich.live import Live
        self._live = Live(
            self._spinner_renderable(),
            console=self._console,
            refresh_per_second=8,
            transient=True,
        )
        self._live.start()

    def _stop_live(self) -> None:
        if self._live is not None:
            try:
                self._live.stop()
            except Exception:  # noqa: BLE001
                pass
            self._live = None

    # --- piped/CI fallback --------------------------------------------

    def _simple_render(self, event: dict) -> None:
        """Plain-text rendering for non-TTY contexts. Each event prints
        one or two lines, no in-place updates. Keeps CI deterministic."""
        kind = event.get("type")
        if kind == "text_delta":
            sys.stdout.write(event.get("text", ""))
            sys.stdout.flush()
        elif kind == "thinking_delta":
            sys.stdout.write(event.get("text", ""))
            sys.stdout.flush()
        elif kind == "tool_use":
            self._tool_count += 1
            name = event.get("name", "")
            summary = _summarize_tool_input(name, event.get("input", {}))
            print(f"\n  ⏵ {name}  {summary}")
        elif kind == "tool_result":
            content = str(event.get("content", ""))
            first = content.split("\n")[0][:120]
            mark = "✗" if event.get("is_error") else "✓"
            print(f"  {mark} {first}")
        elif kind == "error":
            print(f"  ! {event.get('message', '')}")
        elif kind == "usage":
            for k, v in event.items():
                if k != "type" and isinstance(v, int):
                    self._usage[k] = v


# --- shared helper (used by both rendering paths) ------------------------


def _summarize_tool_input(name: str, input_: dict) -> str:
    """One-line preview of a tool call. Mirrors the runner's
    `_summarize_tool_input` so the spinner verb and the renderer agree."""
    if name in ("list_dir", "read_file"):
        return str(input_.get("path", "") or ".")
    if name == "write_file":
        return f"{input_.get('path', '')}  ({len(str(input_.get('content', '')))} bytes)"
    if name == "edit_file":
        find = str(input_.get("find", "")).replace("\n", " ")[:40]
        return f"{input_.get('path', '')}  find={find!r}"
    if name == "search":
        pat = str(input_.get("pattern", ""))
        path = str(input_.get("path", "."))
        return f"{pat}  in {path}"
    if name == "run_command":
        cmd = str(input_.get("command", ""))
        return cmd if len(cmd) <= 80 else cmd[:80] + "…"
    if name in ("list_projects", "list_tasks", "create_task", "update_task"):
        parts = [f"{k}={v}" for k, v in list(input_.items())[:3]]
        return f"({', '.join(parts)})" if parts else "(no args)"
    keys = list(input_.keys())[:2]
    return f"({', '.join(keys)})"
