"""OpenClaude action_required gate — in-process permission registry.

Ported from apps/api/src/agent/permissions.ts. When the runner needs the
user's OK before running a sensitive tool (write_file, edit_file,
run_command), it parks on a token and emits a `permission_required` event.
Two ways the park resolves:

  1. CLI mode: the REPL renders the preview, reads y/N from the user, and
     calls `decide(token, …)` directly in the same process.

  2. HTTP mode (Day 8-10): the FastAPI route emits the SSE event, the web
     client POSTs to /api/agent/permission with the matching token, that
     route handler calls `decide(token, …)`.

Auto-deny after 2 minutes so a vanished client can't hang the runner
forever.

The TS version used promises + setTimeout. Python's equivalent: a thread
that calls `event.wait(timeout)` and reads the decision out of a small
dict the resolver writes to. Synchronous from the caller's point of view,
which matches the Provider protocol's sync `iterate()`.
"""

from __future__ import annotations

import secrets
import threading
from dataclasses import dataclass


@dataclass
class Decision:
    allow: bool
    message: str = ""


@dataclass
class _Pending:
    decision: Decision | None
    ready: threading.Event
    timer: threading.Timer
    tool: str
    tool_use_id: str


_TTL_S = 120.0
_lock = threading.Lock()
_pending: dict[str, _Pending] = {}


def await_decision(tool: str, tool_use_id: str) -> tuple[str, "PendingDecision"]:
    """Register a new pending decision. Returns `(token, handle)` where the
    handle blocks (with timeout) on `.wait()` and returns the `Decision`."""

    token = "perm-" + secrets.token_hex(8)
    pending = _Pending(
        decision=None,
        ready=threading.Event(),
        timer=None,  # type: ignore[assignment]
        tool=tool,
        tool_use_id=tool_use_id,
    )

    def _expire() -> None:
        # Auto-deny if nobody decided in time.
        with _lock:
            if _pending.get(token) is pending and pending.decision is None:
                pending.decision = Decision(allow=False, message="timed out (no decision in 2 min)")
                _pending.pop(token, None)
                pending.ready.set()

    pending.timer = threading.Timer(_TTL_S, _expire)
    pending.timer.daemon = True
    pending.timer.start()

    with _lock:
        _pending[token] = pending

    return token, PendingDecision(token=token, pending=pending)


def decide(token: str, decision: Decision) -> bool:
    """Resolve a pending decision. Returns True if the token existed.
    Idempotent: a second call for the same token is a silent no-op."""

    with _lock:
        pending = _pending.pop(token, None)
        if pending is None:
            return False
        if pending.decision is not None:
            return False
        pending.decision = decision
    pending.timer.cancel()
    pending.ready.set()
    return True


def deny_all(reason: str) -> None:
    """Force-deny every outstanding permission (e.g. on client disconnect)."""
    with _lock:
        items = list(_pending.items())
        _pending.clear()
    for _token, pending in items:
        if pending.decision is None:
            pending.decision = Decision(allow=False, message=reason)
        pending.timer.cancel()
        pending.ready.set()


class PendingDecision:
    """Caller-side handle. `wait()` blocks until the user decides or the
    TTL expires; in both cases it returns a `Decision`."""

    def __init__(self, token: str, pending: _Pending) -> None:
        self.token = token
        self._pending = pending

    def wait(self) -> Decision:
        self._pending.ready.wait()
        # decision is guaranteed set when ready fires.
        assert self._pending.decision is not None
        return self._pending.decision
