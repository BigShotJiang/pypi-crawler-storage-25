"""Agent runner.

Drives the manual agentic loop: ask the provider for one turn, execute any
tool calls it requested, append the results to the message list, ask again,
repeat until the model stops requesting tools (or we hit the iteration cap).

Ported from apps/api/src/agent/runner.ts. The key differences:
  - synchronous (the Provider protocol is sync; SSE wrapping is Day 8-10)
  - `cancel` is a list[bool] flag the caller can flip mid-run (closest sync
    equivalent of `AbortSignal`)
  - permissions use a thread-blocking `pending.wait()` instead of `await`

Modes (aider-style):
  - `code`  (default) — full tool set, agent may edit + run
  - `ask`              — read-only; write tools stripped + refused
  - `plan`             — read-only + an editorial directive to draft a numbered plan first
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Literal

from atlas.agent.permissions import Decision, await_decision
from atlas.agent.system_prompt import load_system_prompt
from atlas.agent.tools import (
    SENSITIVE_TOOLS,
    WRITE_TOOLS,
    ToolContext,
    build_tool_defs,
    run_tool,
)
from atlas.agent.types import (
    AgentEvent,
    AssistantBlock,
    ChatMessage,
    EventEmitter,
    Provider,
    ProviderRequest,
    ToolDef,
)


AgentMode = Literal["code", "ask", "plan"]


@dataclass
class RunOptions:
    """Everything the runner needs to drive one user turn through completion."""

    provider: Provider
    messages: list[ChatMessage]
    scope_root: str
    workspace_name: str | None = None
    user_id: int | None = None
    company_id: int | None = None
    mode: AgentMode = "code"
    thinking: bool = False
    effort: Literal["low", "medium", "high", "xhigh", "max"] | None = None
    max_iterations: int = 10
    # OpenClaude action_required gate. CLI mode keeps it on by default; the
    # web AI panel currently runs with it off and adds a per-tool review
    # bar instead. Day 11 wires it to the Shift+Tab scope cycle.
    confirm: bool = True
    # Paths the user explicitly /add'd into scope. Day 11 surfaces this in
    # the system prompt; for Day 2 it's just stored and forwarded.
    scope_files: list[str] = field(default_factory=list)
    # Mutable flag the caller can flip to abort mid-run (Ctrl-C in the REPL).
    cancel: list[bool] = field(default_factory=lambda: [False])


def run_agent(opts: RunOptions, on_event: EventEmitter) -> None:
    """Run the agent loop. Emits events through `on_event` and mutates
    `opts.messages` in place so the caller sees the final transcript."""

    ctx = ToolContext(root=opts.scope_root, user_id=opts.user_id, company_id=opts.company_id)
    all_tools = build_tool_defs(ctx)
    tools: list[ToolDef] = (
        all_tools if opts.mode == "code"
        else [t for t in all_tools if t["name"] not in WRITE_TOOLS]
    )

    system = _decorate_system(
        load_system_prompt(scope_root=opts.scope_root, workspace=opts.workspace_name),
        opts.mode,
        opts.scope_files,
    )

    on_event({"type": "started", "provider": opts.provider.id, "model": opts.provider.model})

    for _ in range(opts.max_iterations):
        if opts.cancel and opts.cancel[0]:
            on_event({"type": "error", "message": "aborted by client"})
            on_event({"type": "done"})
            return

        try:
            result = opts.provider.iterate(
                ProviderRequest(
                    system=system,
                    tools=tools,
                    messages=opts.messages,
                    thinking=opts.thinking,
                    effort=opts.effort,
                    cancel=opts.cancel,
                ),
                on_event,
            )
        except Exception as e:  # noqa: BLE001 — provider failures surface as agent errors
            on_event({"type": "error", "message": str(e)})
            on_event({"type": "done"})
            return

        opts.messages.append({"role": "assistant", "content": list(result.assistant)})

        if result.stop_reason != "tool_use":
            on_event({"type": "message_stop", "stop_reason": result.stop_reason})
            on_event({"type": "done"})
            return

        # Execute every tool_use block in turn. Per-tool gating + execution.
        for block in result.assistant:
            if block.get("type") != "tool_use":
                continue
            name = block["name"]
            block_id = block["id"]
            input_ = block["input"]

            # Belt-and-suspenders refusal if the model invents a write tool
            # name we don't expose in this mode.
            if opts.mode != "code" and name in WRITE_TOOLS:
                content = (
                    f"ERROR: write tool {name!r} is not available in {opts.mode} mode. "
                    f"Switch to /mode code in the REPL and ask again."
                )
                on_event({"type": "tool_result", "id": block_id, "name": name, "content": content, "is_error": True})
                opts.messages.append({"role": "tool", "tool_use_id": block_id, "content": content, "is_error": True})
                continue

            # OpenClaude action_required gate. CLI mode keeps confirm on.
            if opts.confirm and name in SENSITIVE_TOOLS:
                token, pending = await_decision(tool=name, tool_use_id=block_id)
                on_event({
                    "type": "permission_required",
                    "token": token,
                    "tool_use_id": block_id,
                    "tool": name,
                    "input": input_,
                    "preview": _summarize_tool_input(name, input_),
                })
                decision: Decision = pending.wait()
                if not decision.allow:
                    content = f"ERROR: user denied ({decision.message or 'no reason given'})"
                    on_event({"type": "tool_result", "id": block_id, "name": name, "content": content, "is_error": True})
                    opts.messages.append({"role": "tool", "tool_use_id": block_id, "content": content, "is_error": True})
                    continue

            # Actually run the tool.
            content, is_error = run_tool(name, input_, ctx)
            on_event({"type": "tool_result", "id": block_id, "name": name, "content": content, "is_error": is_error})
            opts.messages.append({"role": "tool", "tool_use_id": block_id, "content": content, "is_error": is_error})

    on_event({"type": "error", "message": f"reached max iterations ({opts.max_iterations})"})
    on_event({"type": "done"})


# --- helpers ---------------------------------------------------------------


def _decorate_system(base: str, mode: AgentMode, scope_files: Iterable[str]) -> str:
    """Append mode-specific directives + explicit file scope to the prompt."""
    lines = [base]
    if mode == "ask":
        lines.extend([
            "",
            "## MODE: ask",
            "You are read-only. You can search the repo, list directories, read files, and discuss approach.",
            "You CANNOT write files, edit files, run shell commands, or modify project data.",
            "When the user wants you to actually do something, tell them to switch with `/mode code`.",
        ])
    elif mode == "plan":
        lines.extend([
            "",
            "## MODE: plan",
            "Draft a concrete, numbered plan first. Use only read-only tools to gather context.",
            "Do NOT make any changes. End with: 'Reply `go` to execute, or `/mode code` to take over manually.'",
        ])
    files = list(scope_files)
    if files:
        lines.extend([
            "",
            "## Files in explicit scope",
            "The user has added these files to the chat. Treat them as the canonical surface for this turn:",
            *[f"  - {p}" for p in files],
            "You may still read outside this list when necessary, but prefer these for edits and primary reasoning.",
        ])
    return "\n".join(lines)


def _summarize_tool_input(name: str, input_: dict) -> str:
    """One-line preview shown in the permission prompt. Plandex-style diff
    preview lives in apps/api's runner.ts; for Day 2 we keep this minimal
    and add the diff in a follow-up (Day 11 polish pass)."""
    if name == "write_file":
        p = input_.get("path", "")
        size = len(str(input_.get("content", "")))
        return f"write_file({p}, {size} bytes)"
    if name == "edit_file":
        p = input_.get("path", "")
        find = str(input_.get("find", "")).replace("\n", " ")[:40]
        return f"edit_file({p}, find={find!r}{'…' if len(find) >= 40 else ''})"
    if name == "run_command":
        cmd = str(input_.get("command", ""))[:80]
        return f"run_command({cmd}{'…' if len(cmd) >= 80 else ''})"
    keys = list(input_.keys())[:2]
    return f"{name}({', '.join(keys)})"
