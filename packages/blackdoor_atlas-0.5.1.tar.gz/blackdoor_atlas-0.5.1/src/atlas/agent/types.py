"""Provider-agnostic agent types.

Ported 1:1 from apps/api/src/agent/types.ts. The wire shape stays identical
so the FastAPI route on Day 8-10 can re-emit these as SSE without further
marshalling, and the existing React frontend keeps working unchanged.

We use TypedDicts for the discriminated unions because dataclasses can't
cleanly express "either-or with different fields"; the runtime cost is the
same and downstream code can `match` on the `type` key.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Protocol, TypedDict

# --- tool definitions ------------------------------------------------------


class ToolInputSchema(TypedDict, total=False):
    type: Literal["object"]
    properties: dict[str, Any]
    required: list[str]
    additionalProperties: bool


class ToolDef(TypedDict):
    name: str
    description: str
    input_schema: ToolInputSchema


# --- messages (wire shape into the provider) ------------------------------


class TextBlock(TypedDict):
    type: Literal["text"]
    text: str


class ToolUseBlock(TypedDict):
    type: Literal["tool_use"]
    id: str
    name: str
    input: dict[str, Any]


AssistantBlock = TextBlock | ToolUseBlock


class UserMessage(TypedDict):
    role: Literal["user"]
    content: str


class AssistantMessage(TypedDict):
    role: Literal["assistant"]
    content: list[AssistantBlock]


class ToolMessage(TypedDict, total=False):
    role: Literal["tool"]
    tool_use_id: str
    content: str
    is_error: bool


ChatMessage = UserMessage | AssistantMessage | ToolMessage


# --- events out of the runner ---------------------------------------------
# Each event is JSON-serializable and identical to the TypeScript types so
# Day 8-10's FastAPI SSE route can re-emit them verbatim.

class StartedEvent(TypedDict):
    type: Literal["started"]
    provider: str
    model: str


class TextDeltaEvent(TypedDict):
    type: Literal["text_delta"]
    text: str


class ThinkingDeltaEvent(TypedDict):
    type: Literal["thinking_delta"]
    text: str


class ToolUseEvent(TypedDict):
    type: Literal["tool_use"]
    id: str
    name: str
    input: dict[str, Any]


class ToolResultEvent(TypedDict):
    type: Literal["tool_result"]
    id: str
    name: str
    content: str
    is_error: bool


class MessageStopEvent(TypedDict):
    type: Literal["message_stop"]
    stop_reason: str


class UsageEvent(TypedDict, total=False):
    type: Literal["usage"]
    input_tokens: int
    output_tokens: int
    cache_read_input_tokens: int
    cache_creation_input_tokens: int


class HeartbeatEvent(TypedDict):
    type: Literal["heartbeat"]
    idle_s: int
    elapsed_s: int


class PermissionRequiredEvent(TypedDict):
    type: Literal["permission_required"]
    token: str
    tool_use_id: str
    tool: str
    input: dict[str, Any]
    preview: str


class ErrorEvent(TypedDict):
    type: Literal["error"]
    message: str


class DoneEvent(TypedDict):
    type: Literal["done"]


AgentEvent = (
    StartedEvent
    | TextDeltaEvent
    | ThinkingDeltaEvent
    | ToolUseEvent
    | ToolResultEvent
    | MessageStopEvent
    | UsageEvent
    | HeartbeatEvent
    | PermissionRequiredEvent
    | ErrorEvent
    | DoneEvent
)


# --- provider protocol ----------------------------------------------------


@dataclass
class ProviderRequest:
    system: str
    tools: list[ToolDef]
    messages: list[ChatMessage]
    thinking: bool = False
    effort: Literal["low", "medium", "high", "xhigh", "max"] | None = None
    # Set by the caller; provider should check periodically and abort if true.
    # Day 1 keeps it dead-simple — a mutable bool wrapped in a list. Day 11
    # may upgrade to anyio's CancelScope when we add SSE streaming over HTTP.
    cancel: list[bool] = field(default_factory=lambda: [False])


@dataclass
class Usage:
    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_read_input_tokens: int | None = None
    cache_creation_input_tokens: int | None = None


@dataclass
class ProviderIterationResult:
    """One provider turn's output. The runner inspects `stop_reason` to
    decide whether to execute the produced tool calls and loop again, or
    return to the caller."""

    assistant: list[AssistantBlock]
    stop_reason: Literal["end_turn", "tool_use", "max_tokens", "refusal", "other"]
    usage: Usage | None = None


# Callable[[AgentEvent], None] — the runner threads one of these through
# every provider call so deltas reach the UI as they arrive.
EventEmitter = Callable[[AgentEvent], None]


class Provider(Protocol):
    """The runner sees providers only through this. Mock, Anthropic,
    OpenAI-compatible, Claude OAuth all conform."""

    id: str       # e.g. "anthropic", "openai-compatible", "ollama", "mock"
    model: str    # active model id

    def iterate(
        self,
        req: ProviderRequest,
        on_event: EventEmitter,
    ) -> ProviderIterationResult:
        """Run one model turn. Emit incremental events; return the assembled
        result.

        Synchronous by design on Day 2-4. Day 8-10's HTTP-side SSE route
        wraps this in a background thread so the FastAPI handler stays
        async. CLI mode calls this directly — no event loop needed.
        """
        ...


@dataclass
class ProviderInfo:
    id: str
    label: str
    model: str
    ready: bool
    reason: str | None = None
