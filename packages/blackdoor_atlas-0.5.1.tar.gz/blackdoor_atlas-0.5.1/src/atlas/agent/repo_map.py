"""Aider-style repo map.

Walks the scope root, extracts a compact symbol list per source file
(exports, top-level functions, classes, types, constants), and renders a
tree the agent can read instead of repeatedly `list_dir`'ing the same
directories.

Ported from apps/api/src/agent/repoMap.ts. We do something cruder than
aider's tree-sitter pipeline — regex on line prefixes — which is good
enough for TS/TSX/JS/Python in a workspace of this size and adds zero
new runtime deps.

Each file's symbol list is capped at 10 entries; the whole tree is capped
at ~6KB chars (~1.5K tokens of English). A 30s in-memory cache means
repeated reads within the same agent turn cost nothing.

Kind tags (one char): f=function, c=class, t=type/interface, x=const, d=def.
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field


@dataclass
class FileEntry:
    rel: str
    symbols: list[str] = field(default_factory=list)


@dataclass
class RepoMapData:
    generated_at: float
    total_files: int
    groups: list[tuple[str, list[FileEntry]]]


_CACHE: dict[str, tuple[float, RepoMapData, str]] = {}  # keyed by root
_CACHE_TTL_S = 30.0

_SKIP_DIRS = frozenset({
    "node_modules", ".git", ".venv", ".agent", "dist", "build", ".vite",
    ".next", "__pycache__", "coverage", ".turbo", ".cache",
    # Pathological roots — keep walks bounded when someone hands us /.
    "Library", "Applications", "System", "private", "var", "tmp",
    "proc", "sys", "dev",
})
_SKIP_SUFFIXES = (".tsbuildinfo", ".log", ".lock", ".map", ".min.js")
_EXTS = frozenset({"ts", "tsx", "js", "jsx", "py", "mjs", "cjs"})
_MAX_SYMBOLS = 10
_TOKEN_BUDGET_CHARS = 6000
_MAX_DEPTH = 10           # safety net — abort recursion past this
_MAX_FILES_TOTAL = 4000   # safety net — abort once we've scanned this many

_TS_REGEXES = [
    (re.compile(r"^export\s+(?:async\s+)?function\s+([A-Za-z_][\w]*)"), "f"),
    (re.compile(r"^export\s+class\s+([A-Za-z_][\w]*)"), "c"),
    (re.compile(r"^export\s+interface\s+([A-Za-z_][\w]*)"), "t"),
    (re.compile(r"^export\s+type\s+([A-Za-z_][\w]*)"), "t"),
    (re.compile(r"^export\s+const\s+([A-Za-z_][\w]*)\s*[:=]"), "x"),
    (re.compile(r"^export\s+default\s+(?:function|class)\s+([A-Za-z_][\w]*)"), "f"),
    (re.compile(r"^(?:async\s+)?function\s+([A-Za-z_][\w]*)"), "f"),
    (re.compile(r"^class\s+([A-Za-z_][\w]*)"), "c"),
]

_PY_REGEXES = [
    (re.compile(r"^class\s+([A-Za-z_][\w]*)"), "c"),
    (re.compile(r"^(?:async\s+)?def\s+([A-Za-z_][\w]*)"), "d"),
]


def repo_map_data(root: str) -> RepoMapData:
    """Structured form for UI consumers. Cached per-root."""
    cached = _CACHE.get(root)
    if cached and time.monotonic() - cached[0] < _CACHE_TTL_S:
        return cached[1]
    entries: list[FileEntry] = []
    _walk(root, "", entries, depth=0)
    groups = _group(entries)
    data = RepoMapData(
        generated_at=time.time(),
        total_files=len(entries),
        groups=groups,
    )
    _CACHE[root] = (time.monotonic(), data, _format(groups, len(entries)))
    return data


def repo_map(root: str) -> str:
    """Formatted text for inlining into the system prompt. Cached per-root."""
    repo_map_data(root)  # populate cache
    return _CACHE[root][2]


def invalidate(root: str | None = None) -> None:
    """Force a refresh. Called by write_file / edit_file on success."""
    if root is None:
        _CACHE.clear()
    else:
        _CACHE.pop(root, None)


# --- walk + extract --------------------------------------------------------


def _walk(abs_dir: str, rel_dir: str, out: list[FileEntry], *, depth: int) -> None:
    if depth > _MAX_DEPTH or len(out) >= _MAX_FILES_TOTAL:
        return
    try:
        names = sorted(os.listdir(abs_dir))
    except OSError:
        return
    for name in names:
        if name.startswith(".") and name != ".gitignore":
            continue
        if name in _SKIP_DIRS:
            continue
        abs_path = os.path.join(abs_dir, name)
        rel = f"{rel_dir}/{name}" if rel_dir else name
        try:
            st = os.stat(abs_path)
        except OSError:
            continue
        if os.path.isdir(abs_path):
            _walk(abs_path, rel, out, depth=depth + 1)
            if len(out) >= _MAX_FILES_TOTAL:
                return
            continue
        if not os.path.isfile(abs_path):
            continue
        if any(name.endswith(s) for s in _SKIP_SUFFIXES):
            continue
        if st.st_size > 500_000:
            continue
        ext = name.rpartition(".")[-1]
        if ext not in _EXTS:
            continue
        symbols = _extract(abs_path, ext)
        if symbols:
            out.append(FileEntry(rel=rel, symbols=symbols))


def _extract(abs_path: str, ext: str) -> list[str]:
    try:
        with open(abs_path, encoding="utf-8") as f:
            body = f.read()
    except (OSError, UnicodeDecodeError):
        return []
    regexes = _PY_REGEXES if ext == "py" else _TS_REGEXES
    out: list[str] = []
    seen: set[str] = set()
    for line in body.split("\n"):
        if len(out) >= _MAX_SYMBOLS:
            break
        trimmed = line.lstrip()
        if len(trimmed) > 200:
            continue
        for rx, kind in regexes:
            m = rx.match(trimmed)
            if m:
                name = m.group(1)
                if name in seen:
                    break
                seen.add(name)
                out.append(f"{kind} {name}")
                break
    return out


# --- group + format --------------------------------------------------------


def _group(entries: list[FileEntry]) -> list[tuple[str, list[FileEntry]]]:
    groups: dict[str, list[FileEntry]] = {}
    for e in entries:
        top = e.rel.split("/", 1)[0]
        groups.setdefault(top, []).append(e)

    def _rank(k: str) -> int:
        if k in ("apps", "harness", "src"):
            return 0
        if k == "tests":
            return 2
        return 1

    return sorted(groups.items(), key=lambda kv: (_rank(kv[0]), kv[0]))


def _format(groups: list[tuple[str, list[FileEntry]]], total: int) -> str:
    out: list[str] = []
    char_count = 0
    for top, files in groups:
        section: list[str] = [f"├─ {top}/"]
        for f in files:
            section.append(f"│  {f.rel}: {', '.join(f.symbols)}")
        section_str = "\n".join(section)
        if char_count + len(section_str) > _TOKEN_BUDGET_CHARS:
            shown = sum(1 for line in out if ":" in line)
            out.append(f"({total - shown} more files truncated for budget)")
            break
        out.append(section_str)
        char_count += len(section_str)
    return "\n".join(out)
