# Agent runtime — local conventions

Read this when working under `src/atlas/agent/`. The root
[`AGENTS.md`](../../../AGENTS.md) still applies.

## What lives here

- `runner.py` — the iterate loop. Mode filter, permission gate, cancel.
- `types.py` — `AgentEvent`, `ChatMessage`, `Provider` protocol.
  Wire-compatible with the legacy TS server. Adding new event types is
  fine; **renaming or removing existing ones is a breaking change**.
- `tools.py` — every tool the agent can call. Static (filesystem,
  shell, memory, sessions) + workspace-scoped (PM tools).
- `providers/` — one file per provider. They all conform to the
  `Provider` protocol in `types.py`.
- `memory.py`, `sessions.py`, `repo_map.py`, `permissions.py`,
  `system_prompt.py` — supporting modules.

## Adding a new provider

1. New file at `providers/<name>.py`.
2. Define a class that conforms to the `Provider` protocol:
   - `id: str` — short identifier (`"anthropic"`, `"openai"`, etc.)
   - `model: str` — active model id
   - `iterate(self, req: ProviderRequest, on_event: EventEmitter) -> ProviderIterationResult`
3. In `iterate()`: emit incremental events via `on_event(...)`; return
   the assembled `ProviderIterationResult` with the final assistant
   blocks + a stop reason.
4. Register in `providers/__init__.py`:
   - Add to `list_providers()` with `ProviderInfo(id, label, model, ready, reason)`
   - Add the auto-select branch in `select_provider()` and the
     `ATLAS_PROVIDER=...` force path
5. If the provider needs a credential:
   - Add it to `~/.atlas/config.json` via `settings.api_keys[<name>]`
   - Read env first (e.g. `OPENAI_API_KEY`), saved key as fallback
   - Update `cli/wizard.py` with a setup flow + `models.list()`-style
     auth validation
6. Smoke test: `ATLAS_PROVIDER=<name> printf 'hi\n/quit\n' | atlas`

## Wire-format invariants

- The `AgentEvent` union shape ships unchanged between Python (this
  runtime) and the legacy TS server's SSE format. The FastAPI dashboard
  re-emits these events verbatim — don't reshape them.
- Tool `input_schema` is JSON-Schema-ish; both Anthropic
  (`input_schema`) and OpenAI (`function.parameters`) accept the same
  shape. Use the existing tool defs as the model.
- Tool result `content` is a string. Errors set `is_error=True` and
  prefix with `"ERROR:"` so models see a consistent marker regardless
  of provider.

## The permission gate

Sensitive tools (`write_file`, `edit_file`, `run_command`,
`create_task`, `update_task`) MUST go through
`permissions.await_decision()` before executing. The runner enforces
this when `opts.confirm` is true (default in CLI mode).

If you're adding a new tool that mutates state or runs arbitrary code,
add it to both `SENSITIVE_TOOLS` and `WRITE_TOOLS` in `tools.py`.

## The mock provider is the spec

When in doubt about expected behavior, read `providers/mock.py`. It's
the smallest faithful implementation of the protocol and exercises
every code path the runner depends on. Anything the mock does, every
real provider should do the same way.

## Tests

Provider tests go in `tests/agent/test_<provider>.py`. At minimum, the
test should:

- Construct the provider with a mock or recorded client
- Run one `iterate()` and assert the event sequence
- Test the auth-fallback chain (env > saved key > error)
