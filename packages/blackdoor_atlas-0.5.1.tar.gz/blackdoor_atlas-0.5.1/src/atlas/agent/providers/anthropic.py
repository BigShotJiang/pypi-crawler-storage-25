"""Anthropic provider — streams one model turn via the official SDK.

Ported from apps/api/src/agent/providers/anthropic.ts. Uses:
  - `client.messages.stream(...)` for SSE-style event iteration
  - adaptive thinking (`{type: "adaptive", display: "summarized"}`) when
    the caller opts in — only meaningful on Opus 4.6+/4.7
  - effort via `output_config={"effort": ...}` for Opus-tier models
  - prompt caching on the system prompt (`cache_control: ephemeral`)
"""

from __future__ import annotations

import json
import os
from typing import Any

from atlas.agent.types import (
    AgentEvent,
    AssistantBlock,
    ChatMessage,
    EventEmitter,
    ProviderIterationResult,
    ProviderRequest,
    TextBlock,
    ToolUseBlock,
    Usage,
)

DEFAULT_MODEL = "claude-opus-4-7"
MAX_TOKENS = 16_000


def _saved_key() -> str:
    """Read the saved Anthropic key from ~/.atlas/config.json. Empty if
    none. The env var takes precedence; this is the fallback for users who
    completed the first-run wizard but don't export the key in their shell."""
    try:
        from atlas.config import settings as settings_mod
        return (settings_mod.load().api_keys.get("anthropic") or "").strip()
    except Exception:  # noqa: BLE001 — config issues never break the import
        return ""


def is_configured() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY") or _saved_key())


class AnthropicProvider:
    id = "anthropic"

    def __init__(self, model: str | None = None, *, client: Any = None) -> None:
        # Lazy import — keeps `atlas --help` fast and lets the offline mock
        # path stay importable when `anthropic` isn't installed.
        from anthropic import Anthropic  # type: ignore[import-not-found]

        from atlas.config import settings as settings_mod
        s = settings_mod.load()
        self.model = model or s.model or os.environ.get("ATLAS_MODEL") or DEFAULT_MODEL

        if client is not None:
            self._client = client
        else:
            # Prefer env (so dev workflows keep working), fall back to saved key.
            api_key = os.environ.get("ANTHROPIC_API_KEY") or _saved_key()
            self._client = Anthropic(api_key=api_key) if api_key else Anthropic()

    def iterate(
        self,
        req: ProviderRequest,
        on_event: EventEmitter,
    ) -> ProviderIterationResult:
        tools_param = [
            {
                "name": t["name"],
                "description": t["description"],
                "input_schema": t["input_schema"],
            }
            for t in req.tools
        ]

        messages_param = _to_anthropic_messages(req.messages)

        params: dict[str, Any] = {
            "model": self.model,
            "max_tokens": MAX_TOKENS,
            "system": [
                {
                    "type": "text",
                    "text": req.system,
                    "cache_control": {"type": "ephemeral"},
                },
            ],
            "tools": tools_param,
            "messages": messages_param,
        }

        # Adaptive thinking is Opus 4.6+ / 4.7. `display: summarized` keeps
        # progress visible during otherwise-silent reasoning windows.
        if req.thinking:
            params["thinking"] = {"type": "adaptive", "display": "summarized"}
        if req.effort:
            params["output_config"] = {"effort": req.effort}

        blocks: list[AssistantBlock] = []
        tool_use_json = ""  # accumulator for input_json_delta fragments
        active_tool_block: ToolUseBlock | None = None
        stop_reason: str = "other"
        usage = Usage()

        with self._client.messages.stream(**params) as stream:
            for event in stream:
                # Cancellation: check the caller's flag every event so a
                # Ctrl-C in the REPL stops the upstream within ~one delta.
                if req.cancel and req.cancel[0]:
                    try:
                        stream.close()
                    except Exception:  # noqa: BLE001 — close is best-effort
                        pass
                    break

                kind = getattr(event, "type", None)

                if kind == "content_block_start":
                    cb = getattr(event, "content_block", None)
                    cb_type = getattr(cb, "type", None) if cb is not None else None
                    if cb_type == "text":
                        text_block: TextBlock = {"type": "text", "text": ""}
                        blocks.append(text_block)
                    elif cb_type == "tool_use":
                        active_tool_block = {
                            "type": "tool_use",
                            "id": getattr(cb, "id", "") or "",
                            "name": getattr(cb, "name", "") or "",
                            "input": {},
                        }
                        blocks.append(active_tool_block)
                        tool_use_json = ""

                elif kind == "content_block_delta":
                    delta = getattr(event, "delta", None)
                    d_type = getattr(delta, "type", None) if delta is not None else None
                    if d_type == "text_delta":
                        text = getattr(delta, "text", "") or ""
                        last = blocks[-1] if blocks else None
                        if last and last["type"] == "text":
                            last["text"] += text
                        on_event({"type": "text_delta", "text": text})
                    elif d_type == "thinking_delta":
                        thinking = getattr(delta, "thinking", "") or ""
                        on_event({"type": "thinking_delta", "text": thinking})
                    elif d_type == "input_json_delta":
                        tool_use_json += getattr(delta, "partial_json", "") or ""

                elif kind == "content_block_stop":
                    if active_tool_block is not None:
                        try:
                            active_tool_block["input"] = json.loads(tool_use_json or "{}")
                        except json.JSONDecodeError:
                            active_tool_block["input"] = {}
                        on_event({
                            "type": "tool_use",
                            "id": active_tool_block["id"],
                            "name": active_tool_block["name"],
                            "input": active_tool_block["input"],
                        })
                        active_tool_block = None
                        tool_use_json = ""

                elif kind == "message_delta":
                    delta = getattr(event, "delta", None)
                    sr = getattr(delta, "stop_reason", None) if delta is not None else None
                    if sr:
                        stop_reason = _normalize_stop(sr)
                    u = getattr(event, "usage", None)
                    if u is not None:
                        _accumulate_usage(usage, u)

                elif kind == "message_stop":
                    msg = getattr(event, "message", None)
                    u = getattr(msg, "usage", None) if msg is not None else None
                    if u is not None:
                        _accumulate_usage(usage, u)

        if any(v is not None for v in (usage.input_tokens, usage.output_tokens)):
            on_event({
                "type": "usage",
                **{k: v for k, v in usage.__dict__.items() if v is not None},
            })
        on_event({"type": "message_stop", "stop_reason": stop_reason})
        return ProviderIterationResult(
            assistant=blocks,
            stop_reason=stop_reason,  # type: ignore[arg-type]
            usage=usage if any(v is not None for v in usage.__dict__.values()) else None,
        )


# --- helpers ---------------------------------------------------------------


def _to_anthropic_messages(messages: list[ChatMessage]) -> list[dict[str, Any]]:
    """Re-shape our normalized ChatMessage list into Anthropic's wire format.

    Tool results travel as a user message with `tool_result` content blocks;
    consecutive tool results must collapse into one user message, mirroring
    the TS reference implementation.
    """
    out: list[dict[str, Any]] = []
    pending_tool_results: list[dict[str, Any]] = []

    def flush() -> None:
        nonlocal pending_tool_results
        if pending_tool_results:
            out.append({"role": "user", "content": pending_tool_results})
            pending_tool_results = []

    for m in messages:
        role = m.get("role")
        if role == "tool":
            pending_tool_results.append({
                "type": "tool_result",
                "tool_use_id": m.get("tool_use_id", ""),
                "content": m.get("content", ""),
                "is_error": bool(m.get("is_error", False)),
            })
        elif role == "user":
            flush()
            out.append({"role": "user", "content": m["content"]})
        else:  # assistant
            flush()
            out.append({"role": "assistant", "content": list(m["content"])})

    flush()
    return out


def _normalize_stop(s: str) -> str:
    if s in ("end_turn", "tool_use", "max_tokens", "refusal"):
        return s
    return "other"


def _accumulate_usage(target: Usage, src: Any) -> None:
    for field in ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"):
        value = getattr(src, field, None)
        if value is not None:
            setattr(target, field, value)
