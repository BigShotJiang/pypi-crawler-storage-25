"""Provider registry + selector.

`list_providers()` returns metadata for the splash, `atlas init` wizard,
and the dashboard UI. `select_provider()` picks the first ready one based
on env config — Anthropic > Claude OAuth > OpenAI-compatible > Mock.

Env vars that influence selection:

  ATLAS_PROVIDER     force a specific id ("anthropic" | "openai-compatible"
                     | "ollama" | "claude-oauth" | "mock")
  ATLAS_MODEL        override the default model for the chosen provider
  ANTHROPIC_API_KEY  enables anthropic
  OPENAI_API_KEY     enables openai
  ATLAS_OPENAI_BASE_URL  switches OpenAI-compat to Ollama / LM Studio / etc.
  OPENAI_BASE_URL    (legacy alias for ATLAS_OPENAI_BASE_URL)

`select_provider()` returns None when nothing is configured — the REPL
shows a clear "run `atlas init`" hint in that case.
"""

from __future__ import annotations

import os

from atlas.agent.providers import anthropic as anthropic_mod
from atlas.agent.providers import claude_oauth as claude_oauth_mod
from atlas.agent.providers import openai_compatible as openai_mod
from atlas.agent.providers.mock import MockProvider
from atlas.agent.types import Provider, ProviderInfo


def list_providers() -> list[ProviderInfo]:
    """Snapshot of every known provider + its readiness."""
    items: list[ProviderInfo] = []

    items.append(ProviderInfo(
        id="anthropic",
        label="Anthropic API",
        model=os.environ.get("ATLAS_MODEL") or anthropic_mod.DEFAULT_MODEL,
        ready=anthropic_mod.is_configured(),
        reason=None if anthropic_mod.is_configured() else "Set ANTHROPIC_API_KEY",
    ))

    claude_ready, claude_reason = claude_oauth_mod.claude_oauth_status()
    items.append(ProviderInfo(
        id="claude-oauth",
        label="Claude Pro / Max (OAuth)",
        model=os.environ.get("ATLAS_MODEL") or "claude-opus-4-7",
        ready=claude_ready,
        reason=claude_reason,
    ))

    openai_kind = openai_mod.detect_kind()
    items.append(ProviderInfo(
        id="ollama" if openai_kind == "ollama" else "openai" if openai_kind == "openai" else "openai-compatible",
        label=_openai_label(openai_kind),
        model=os.environ.get("ATLAS_MODEL")
              or openai_mod._DEFAULT_MODEL_BY_KIND.get(openai_kind, "gpt-4o-mini"),
        ready=openai_mod.is_configured(),
        reason=None if openai_mod.is_configured() else (
            "Set OPENAI_API_KEY, or point ATLAS_OPENAI_BASE_URL at Ollama / LM Studio"
        ),
    ))

    items.append(ProviderInfo(
        id="mock",
        label="Mock (offline)",
        model="mock-1",
        ready=True,
        reason="Always available. Echoes input.",
    ))

    return items


def select_provider() -> Provider | None:
    """Pick the best available provider. Precedence:
      1. ``ATLAS_PROVIDER`` env var (developer override)
      2. ``provider`` field in ~/.atlas/config.json (set by the wizard)
      3. Auto-detect: Anthropic > Claude OAuth > OpenAI-compatible
      4. Mock fallback so the REPL still boots
    """
    forced = (os.environ.get("ATLAS_PROVIDER") or "").lower()
    if not forced:
        try:
            from atlas.config import settings as settings_mod
            forced = (settings_mod.load().provider or "").lower()
        except Exception:  # noqa: BLE001
            forced = ""

    if forced == "mock":
        return MockProvider()
    if forced == "anthropic":
        return _try(_make_anthropic)
    if forced in ("claude-oauth", "claude_oauth", "claude-code"):
        return _try(_make_claude_oauth)
    if forced in ("openai", "ollama", "openai-compatible"):
        return _try(_make_openai)

    # Auto-select. Order: Anthropic API > Claude OAuth > OpenAI-compatible > Mock fallback.
    if anthropic_mod.is_configured():
        prov = _try(_make_anthropic)
        if prov is not None:
            return prov
    if claude_oauth_mod.is_configured():
        prov = _try(_make_claude_oauth)
        if prov is not None:
            return prov
    if openai_mod.is_configured():
        prov = _try(_make_openai)
        if prov is not None:
            return prov

    # Last resort: mock so the REPL still boots. The first-run wizard will
    # have offered real setup before we get here.
    return MockProvider()


# --- factories -------------------------------------------------------------


def _make_anthropic() -> Provider:
    return anthropic_mod.AnthropicProvider()


def _make_claude_oauth() -> Provider:
    return claude_oauth_mod.ClaudeOAuthProvider()


def _make_openai() -> Provider:
    return openai_mod.OpenAICompatibleProvider()


def _try(factory):  # type: ignore[no-untyped-def]
    """Run a factory but swallow ImportError + RuntimeError so a missing
    SDK or missing creds quietly falls through to the next candidate."""
    try:
        return factory()
    except (ImportError, RuntimeError):
        return None


def _openai_label(kind: str) -> str:
    return {
        "ollama": "Ollama (local)",
        "openai": "OpenAI API",
        "openai-compatible": "OpenAI-compatible endpoint",
        "none": "OpenAI / Ollama / LM Studio",
    }.get(kind, "OpenAI / Ollama / LM Studio")
