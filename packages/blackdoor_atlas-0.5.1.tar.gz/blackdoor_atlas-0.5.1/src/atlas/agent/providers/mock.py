"""Offline mock provider.

Ported from apps/api/src/agent/providers/mock.ts. Useful when:

  - smoke-testing the runner without an API key
  - writing unit tests that need deterministic agent behavior
  - dogfooding the REPL plumbing before real providers are wired

Behavior is intentionally dumb: streams the user's last message back as
`text_delta` events one character at a time, then ends the turn. Doesn't
exercise tools — the runner-level tool tests use a separate fixture.
"""

from __future__ import annotations

import time

from atlas.agent.types import (
    AssistantBlock,
    EventEmitter,
    ProviderIterationResult,
    ProviderRequest,
    TextBlock,
)


class MockProvider:
    id = "mock"
    model = "mock-1"

    def iterate(
        self,
        req: ProviderRequest,
        on_event: EventEmitter,
    ) -> ProviderIterationResult:
        # Pull out the most recent user message — that's what we echo.
        last_user_text = ""
        for m in reversed(req.messages):
            if m.get("role") == "user":
                content = m.get("content", "")
                if isinstance(content, str):
                    last_user_text = content
                break

        reply = f"[mock] You said: {last_user_text or '(nothing)'}"

        # Stream a few characters at a time so the REPL sees real-feeling
        # deltas. The sleep is small enough that tests still finish fast.
        chunk = 8
        for i in range(0, len(reply), chunk):
            if req.cancel and req.cancel[0]:
                break
            on_event({"type": "text_delta", "text": reply[i : i + chunk]})
            time.sleep(0.01)

        block: TextBlock = {"type": "text", "text": reply}
        blocks: list[AssistantBlock] = [block]
        return ProviderIterationResult(assistant=blocks, stop_reason="end_turn")
