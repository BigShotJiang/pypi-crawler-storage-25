"""Claude Code OAuth provider — reuses the access token Claude Code already
stored on the user's machine. No separate API key required.

Ported from apps/api/src/agent/providers/claudeOAuth.ts.

Storage layers we probe:
  - macOS Keychain entry  service="Claude Code-credentials", account=$USER
  - ~/.claude/.credentials.json  (Linux + manual setup; some installs)
  - ~/.claude/credentials.json   (older variant)

The credential JSON looks like::

    {"claudeAiOauth": {"accessToken": "sk-ant-oat01-...", "refreshToken": "...",
                       "expiresAt": 1234567890123, "scopes": [...], "subscriptionType": "max"}}

We hand the access token to the Anthropic SDK as `auth_token`, which sends
it as `Authorization: Bearer …` instead of `x-api-key`. Tokens expire (~1h);
we don't refresh in v0.1 — on 401, we surface "run `claude` to refresh".
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Any

from atlas.agent.providers.anthropic import AnthropicProvider


@dataclass
class _ClaudeCreds:
    access_token: str
    refresh_token: str | None
    expires_at: int | None  # epoch ms
    source: str             # "keychain" | "file"


_CACHE: dict[str, Any] = {"value": None, "read_at": 0.0}
_CACHE_TTL_S = 60.0


def read_claude_oauth() -> _ClaudeCreds | None:
    """Return cached credentials if fresh, otherwise re-probe."""
    if _CACHE["value"] and time.monotonic() - _CACHE["read_at"] < _CACHE_TTL_S:
        return _CACHE["value"]

    creds = _probe_keychain() or _probe_file()
    _CACHE["value"] = creds
    _CACHE["read_at"] = time.monotonic()
    return creds


def claude_oauth_status() -> tuple[bool, str | None]:
    """`(ready, reason)`. Reason is a one-line actionable hint shown by
    `atlas init` and the dashboard UI when ready is False."""
    if sys.platform != "darwin":
        creds = read_claude_oauth()
        if creds:
            return True, None
        return False, (
            "No Claude Code credentials found. macOS Keychain auto-detect is "
            "currently the supported path."
        )

    creds = read_claude_oauth()
    if not creds:
        return False, (
            "Run `claude` once to sign in (stores creds in macOS Keychain). "
            "First request will prompt to allow access."
        )
    if creds.expires_at and creds.expires_at < time.time() * 1000:
        return False, "Claude Code token has expired. Run `claude` to refresh."
    return True, None


def is_configured() -> bool:
    ready, _ = claude_oauth_status()
    return ready


# --- probes ----------------------------------------------------------------


def _probe_keychain() -> _ClaudeCreds | None:
    if sys.platform != "darwin":
        return None
    try:
        proc = subprocess.run(  # noqa: S603 — `security` is a fixed system path
            ["/usr/bin/security", "find-generic-password", "-s", "Claude Code-credentials", "-w"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if proc.returncode != 0:
        return None
    raw = (proc.stdout or "").strip()
    parsed = _parse_creds(raw)
    if not parsed:
        return None
    parsed.source = "keychain"
    return parsed


def _probe_file() -> _ClaudeCreds | None:
    home = os.path.expanduser("~")
    for candidate in (
        os.path.join(home, ".claude", ".credentials.json"),
        os.path.join(home, ".claude", "credentials.json"),
    ):
        if not os.path.exists(candidate):
            continue
        try:
            with open(candidate, encoding="utf-8") as f:
                parsed = _parse_creds(f.read())
        except OSError:
            continue
        if parsed:
            parsed.source = "file"
            return parsed
    return None


def _parse_creds(raw: str) -> _ClaudeCreds | None:
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError:
        return None
    block = obj.get("claudeAiOauth") or obj.get("ClaudeAiOauth") or obj
    if not isinstance(block, dict):
        return None
    access = block.get("accessToken") or block.get("access_token") or ""
    if not access:
        return None
    return _ClaudeCreds(
        access_token=str(access),
        refresh_token=block.get("refreshToken") or block.get("refresh_token"),
        expires_at=block.get("expiresAt") or block.get("expires_at"),
        source="",
    )


# --- provider --------------------------------------------------------------


class ClaudeOAuthProvider(AnthropicProvider):
    """Subclass of AnthropicProvider that builds the SDK client with the
    user's OAuth bearer token instead of an API key."""

    id = "claude-oauth"

    def __init__(self) -> None:
        from anthropic import Anthropic  # type: ignore[import-not-found]

        creds = read_claude_oauth()
        if creds is None:
            raise RuntimeError("Claude Code OAuth credentials not found")

        client = Anthropic(
            auth_token=creds.access_token,
            default_headers={
                # Claude Code identifies itself this way; some routes 403 without it.
                "anthropic-beta": "oauth-2025-04-20",
            },
        )
        super().__init__(model=os.environ.get("ATLAS_MODEL"), client=client)
