"""OpenAI-compatible provider — one provider for everything that speaks
the OpenAI Chat Completions wire.

Ported from apps/api/src/agent/providers/openaiCompatible.ts. Covers:

  - **OpenAI** itself  (OPENAI_API_KEY set)
  - **Ollama**         (ATLAS_OPENAI_BASE_URL=http://localhost:11434/v1)
  - **LM Studio**      (ATLAS_OPENAI_BASE_URL=http://localhost:1234/v1)
  - **vLLM**, Mistral, Together, OpenRouter, Anyscale, Groq, Fireworks, …

Uses the official `openai` Python SDK with a custom `base_url` rather than
hand-rolling SSE — keeps the code small and benefits from the SDK's tool-
call assembly logic.

Reasoning models (Qwen3, DeepSeek-R1, Ollama "thinking" wrappers) stream
chain-of-thought in `delta.reasoning` or `delta.reasoning_content`. We
forward that through the same `thinking_delta` channel Anthropic uses,
so the REPL renderer has one code path.
"""

from __future__ import annotations

import json
import os
from typing import Any

from atlas.agent.types import (
    AssistantBlock,
    ChatMessage,
    EventEmitter,
    ProviderIterationResult,
    ProviderRequest,
    TextBlock,
    ToolUseBlock,
)


def _saved_openai_key() -> str:
    try:
        from atlas.config import settings as settings_mod
        return (settings_mod.load().api_keys.get("openai") or "").strip()
    except Exception:  # noqa: BLE001
        return ""


def _saved_base_url() -> str:
    try:
        from atlas.config import settings as settings_mod
        return (settings_mod.load().openai_base_url or "").strip()
    except Exception:  # noqa: BLE001
        return ""


def detect_kind() -> str:
    """Returns 'openai' | 'ollama' | 'openai-compatible' | 'none'."""
    base = (
        os.environ.get("ATLAS_OPENAI_BASE_URL")
        or os.environ.get("OPENAI_BASE_URL")
        or _saved_base_url()
        or ""
    ).lower()
    if not base:
        return "openai" if (os.environ.get("OPENAI_API_KEY") or _saved_openai_key()) else "none"
    if "11434" in base:
        return "ollama"
    if "openai.com" in base:
        return "openai"
    return "openai-compatible"


def is_configured() -> bool:
    kind = detect_kind()
    if kind == "none":
        return False
    if kind == "openai":
        return bool(os.environ.get("OPENAI_API_KEY") or _saved_openai_key())
    return True


_DEFAULT_MODEL_BY_KIND: dict[str, str] = {
    "openai": "gpt-4o-mini",
    "ollama": "llama3.1",
    "openai-compatible": "gpt-4o-mini",
}


class OpenAICompatibleProvider:
    """Single class for OpenAI / Ollama / LM Studio / etc. `id` is set from
    `detect_kind()` so the REPL shows "ollama" or "openai" rather than the
    generic "openai-compatible" when we can tell."""

    def __init__(self, model: str | None = None) -> None:
        from openai import OpenAI  # type: ignore[import-not-found]

        from atlas.config import settings as settings_mod
        s = settings_mod.load()

        kind = detect_kind()
        self.id = "ollama" if kind == "ollama" else "openai" if kind == "openai" else "openai-compatible"
        self.model = (
            model
            or s.model
            or os.environ.get("ATLAS_MODEL")
            or _DEFAULT_MODEL_BY_KIND.get(self.id, "gpt-4o-mini")
        )

        base_url = (
            os.environ.get("ATLAS_OPENAI_BASE_URL")
            or os.environ.get("OPENAI_BASE_URL")
            or _saved_base_url()
            or None
        )
        # Ollama ignores api_key but the OpenAI SDK requires one. Prefer env,
        # fall back to wizard-saved key, fall back to placeholder.
        api_key = (
            os.environ.get("OPENAI_API_KEY")
            or _saved_openai_key()
            or "ollama"
        )
        self._client = OpenAI(api_key=api_key, base_url=base_url) if base_url else OpenAI(api_key=api_key)

    def iterate(
        self,
        req: ProviderRequest,
        on_event: EventEmitter,
    ) -> ProviderIterationResult:
        tools_param: list[dict[str, Any]] = [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t["description"],
                    "parameters": t["input_schema"],
                },
            }
            for t in req.tools
        ]

        messages_param = _to_openai_messages(req.system, req.messages)

        kwargs: dict[str, Any] = {
            "model": self.model,
            "stream": True,
            "messages": messages_param,
        }
        if tools_param:
            kwargs["tools"] = tools_param
            kwargs["tool_choice"] = "auto"

        text_buf = ""
        # Map index → partial tool call. Deltas arrive interleaved by index.
        tool_buf: dict[int, dict[str, str]] = {}
        stop: str = "other"
        emitted_tool_use_ids: set[str] = set()

        stream = self._client.chat.completions.create(**kwargs)
        try:
            for chunk in stream:
                if req.cancel and req.cancel[0]:
                    try:
                        stream.response.close()  # type: ignore[attr-defined]
                    except Exception:  # noqa: BLE001
                        pass
                    break
                if not chunk.choices:
                    continue
                choice = chunk.choices[0]
                delta = getattr(choice, "delta", None)
                if delta is None:
                    continue

                content = getattr(delta, "content", None)
                if content:
                    text_buf += content
                    on_event({"type": "text_delta", "text": content})

                # Reasoning models — DeepSeek-R1, Qwen3-thinking, Ollama
                # think-wrapper. Both names appear depending on server.
                reasoning = getattr(delta, "reasoning", None) or getattr(delta, "reasoning_content", None)
                if reasoning:
                    on_event({"type": "thinking_delta", "text": reasoning})

                tcs = getattr(delta, "tool_calls", None)
                if tcs:
                    for tc in tcs:
                        idx = getattr(tc, "index", 0) or 0
                        existing = tool_buf.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                        tc_id = getattr(tc, "id", None)
                        if tc_id:
                            existing["id"] = tc_id
                        fn = getattr(tc, "function", None)
                        if fn is not None:
                            name = getattr(fn, "name", None)
                            if name:
                                existing["name"] = name
                            args = getattr(fn, "arguments", None)
                            if args:
                                existing["arguments"] += args

                finish = getattr(choice, "finish_reason", None)
                if finish:
                    stop = _map_finish(finish)
        finally:
            try:
                stream.close()
            except Exception:  # noqa: BLE001
                pass

        blocks: list[AssistantBlock] = []
        if text_buf:
            text_block: TextBlock = {"type": "text", "text": text_buf}
            blocks.append(text_block)

        for idx in sorted(tool_buf.keys()):
            tc = tool_buf[idx]
            if not tc["name"]:
                continue
            try:
                input_ = json.loads(tc["arguments"]) if tc["arguments"] else {}
            except json.JSONDecodeError:
                input_ = {"_raw": tc["arguments"]}
            tool_id = tc["id"] or f"call_{idx:08x}"
            tool_block: ToolUseBlock = {
                "type": "tool_use",
                "id": tool_id,
                "name": tc["name"],
                "input": input_,
            }
            blocks.append(tool_block)
            if tool_id not in emitted_tool_use_ids:
                on_event({"type": "tool_use", "id": tool_id, "name": tc["name"], "input": input_})
                emitted_tool_use_ids.add(tool_id)

        on_event({"type": "message_stop", "stop_reason": stop})
        return ProviderIterationResult(assistant=blocks, stop_reason=stop)  # type: ignore[arg-type]


# --- helpers ---------------------------------------------------------------


def _to_openai_messages(system: str, messages: list[ChatMessage]) -> list[dict[str, Any]]:
    """Convert our normalized ChatMessage list into OpenAI's chat shape.
    Assistant turns split into a text content + `tool_calls` array."""
    out: list[dict[str, Any]] = [{"role": "system", "content": system}]
    for m in messages:
        role = m.get("role")
        if role == "user":
            out.append({"role": "user", "content": m["content"]})
        elif role == "tool":
            out.append({
                "role": "tool",
                "tool_call_id": m.get("tool_use_id", ""),
                "content": m.get("content", ""),
            })
        else:
            # Assistant — split into text + tool_calls.
            text = "".join(b["text"] for b in m["content"] if b.get("type") == "text")
            tool_calls = [
                {
                    "id": b["id"],
                    "type": "function",
                    "function": {
                        "name": b["name"],
                        "arguments": json.dumps(b.get("input", {})),
                    },
                }
                for b in m["content"]
                if b.get("type") == "tool_use"
            ]
            entry: dict[str, Any] = {"role": "assistant", "content": text or None}
            if tool_calls:
                entry["tool_calls"] = tool_calls
            out.append(entry)
    return out


def _map_finish(s: str) -> str:
    if s == "tool_calls":
        return "tool_use"
    if s == "stop":
        return "end_turn"
    if s == "length":
        return "max_tokens"
    return "other"
