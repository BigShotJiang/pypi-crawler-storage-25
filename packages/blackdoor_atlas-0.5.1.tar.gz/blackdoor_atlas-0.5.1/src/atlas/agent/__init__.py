"""Agent runtime — the Python port of apps/api/src/agent/*.

Lands Day 2-4. Modules:

  runner.py          # event loop, tool dispatch, streaming events out
  tools.py           # read_file, write_file, edit_file, search, run_command, …
  providers/         # anthropic, openai, ollama, claude_oauth, mock
  system_prompt.py   # context cascade — global ATLAS.md → per-project files
  repo_map.py        # aider-style tree of symbols in cwd
  memory.py          # bounded ~/.atlas/memory.md + user.md, Hermes pattern
  permissions.py     # OpenClaude action_required gate, parked promises
  sessions.py        # FTS5 over ~/.atlas/sessions/*.json
"""
