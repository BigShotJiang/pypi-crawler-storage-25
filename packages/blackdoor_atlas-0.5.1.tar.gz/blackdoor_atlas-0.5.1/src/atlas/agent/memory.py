"""Hermes-style two-layer memory.

Two bounded files under `~/.atlas/`:

  memory.md  — agent-authored notes about the environment, conventions
  user.md    — user preferences, communication style

The "frozen snapshot" pattern: writes persist to disk immediately, but
`read()` returns the contents that were on disk at the start of the
current session. The runner captures the snapshot once per turn and folds
it into the system prompt, so the prefix-cache stays hot across turns.

Limits match Hermes' published guidance (~800 / ~500 tokens of English).
We enforce them on write so a runaway agent can't bloat the system prompt.

Ported from apps/api/src/repos/MemoryRepo.ts. The wire-shape of `add` /
`replace` / `remove` matches the TS version so the `memory` tool def
works across both languages.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


_MEM_LIMIT = 2200    # ~800 tokens of English
_USER_LIMIT = 1375   # ~500 tokens

_MEM_HEADER = """\
# Agent memory

Persistent notes for the agent. The contents of this file are injected into
the system prompt at session start. Entries should be terse, durable facts
about this repository / environment / conventions — not transient state.
"""

_USER_HEADER = """\
# User profile

Persistent notes about the user. Communication style, preferences,
expectations. Loaded into the system prompt at session start.
"""


def _root() -> str:
    return os.path.expanduser("~/.atlas")


def _path(which: str) -> str:
    return os.path.join(_root(), f"{which}.md")


def _header_for(which: str) -> str:
    return _MEM_HEADER if which == "memory" else _USER_HEADER


def _limit_for(which: str) -> int:
    return _MEM_LIMIT if which == "memory" else _USER_LIMIT


def _ensure_dir() -> None:
    os.makedirs(_root(), exist_ok=True)


def _read_or_seed(which: str) -> str:
    p = _path(which)
    if not os.path.exists(p):
        _ensure_dir()
        with open(p, "w", encoding="utf-8") as f:
            f.write(_header_for(which))
        return _header_for(which)
    with open(p, encoding="utf-8") as f:
        return f.read()


def _truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    # Cut on a newline boundary near the limit so a heading isn't sliced mid-line.
    cut = text.rfind("\n", 0, limit)
    if cut < limit - 200:
        cut = limit
    return text[:cut] + "\n…[truncated]\n"


@dataclass
class MemorySnapshot:
    """The two memory files as a single immutable bundle. The runner reads
    one of these at the start of each turn and folds it into the system
    prompt."""

    memory: str
    user: str


def read() -> MemorySnapshot:
    """Snapshot of (memory, user) as they are on disk right now. Idempotent
    — silently seeds the files with their headers on first read."""
    return MemorySnapshot(memory=_read_or_seed("memory"), user=_read_or_seed("user"))


def write(which: str, body: str) -> None:
    """Replace one file wholesale. Enforces the size cap."""
    _ensure_dir()
    safe = _truncate(body, _limit_for(which))
    with open(_path(which), "w", encoding="utf-8") as f:
        f.write(safe)


@dataclass
class AddResult:
    added: bool
    reason: str = ""


def add(which: str, entry: str) -> AddResult:
    """Append a bullet under the existing content. Idempotent — duplicate
    entries are silently skipped so a re-run doesn't double the memory."""
    trimmed = entry.strip()
    if not trimmed:
        return AddResult(added=False, reason="empty")
    cur = _read_or_seed(which)
    bullet = trimmed if trimmed.startswith("- ") else f"- {trimmed}"
    if bullet in cur:
        return AddResult(added=False, reason="duplicate")
    next_ = cur.rstrip() + "\n" + bullet + "\n"
    write(which, next_)
    return AddResult(added=True)


@dataclass
class ReplaceResult:
    changed: bool
    matches: int


def replace(which: str, find: str, replace_with: str) -> ReplaceResult:
    """Replace the first occurrence of `find`. Refuses if the substring
    appears more than once (caller should be more specific)."""
    cur = _read_or_seed(which)
    matches = cur.count(find)
    if matches == 0:
        return ReplaceResult(changed=False, matches=0)
    if matches > 1:
        return ReplaceResult(changed=False, matches=matches)
    write(which, cur.replace(find, replace_with, 1))
    return ReplaceResult(changed=True, matches=1)


@dataclass
class RemoveResult:
    removed: int


def remove(which: str, find: str) -> RemoveResult:
    """Strip every occurrence of `find` from the file."""
    cur = _read_or_seed(which)
    matches = cur.count(find)
    if matches == 0:
        return RemoveResult(removed=0)
    write(which, cur.replace(find, ""))
    return RemoveResult(removed=matches)
