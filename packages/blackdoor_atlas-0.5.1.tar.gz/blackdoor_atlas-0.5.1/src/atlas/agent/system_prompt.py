"""System prompt builder + context cascade.

Composes one system prompt from, in order:

  1. The base harness prompt (this file)
  2. `~/.atlas/ATLAS.md`            — user's cross-project work style
  3. `~/.atlas/memory.md` snapshot  — agent's durable notes
  4. `~/.atlas/user.md` snapshot    — agent's user-profile notes
  5. cwd: `AGENTS.md` → `CLAUDE.md` → `ATLAS.md` (project-local)
  6. Repo map of cwd

The memory layer is a *frozen snapshot* — captured once per turn and
folded into the prompt so its bytes don't shift between provider calls.
Tool-side writes (via the `memory` tool) persist immediately but only
appear in the prompt next session, keeping the prefix cache hot.

Day 11 polish pass may add token-budget accounting; for now we cap the
repo map at ~6KB chars and trust the user to keep their ATLAS.md tidy.
"""

from __future__ import annotations

import os

from atlas.agent import memory as memory_mod
from atlas.agent import repo_map as repo_map_mod


_BASE = """\
You are ATLAS, a terminal AI harness with a built-in project workspace. You
help the user manage agents and work alongside humans in one place.

You have tools for reading the filesystem, searching, editing files, and
running shell commands. Use them. Don't ask permission to read — just read.
Sensitive tools (write_file, edit_file, run_command) are gated by a
permission prompt; the user will see what you're about to do and approve.

Be concise. Lead with the answer; explain only when the user asks. Use
paths relative to the current scope root. When the user asks "where is X"
or "what does Y do", search first, then summarize.
"""


def load_system_prompt(
    *,
    scope_root: str,
    workspace: str | None = None,
    include_memory: bool = True,
    include_repo_map: bool = True,
    extras: list[str] | None = None,
) -> str:
    """Compose the full prompt for one turn."""
    sections: list[str] = [_BASE, "", "## Environment",
                           f"- scope root: {scope_root}"]
    if workspace:
        sections.append(f"- active workspace: {workspace}")
    sections.append(f"- platform: {os.name}")

    # 2. Global ATLAS.md — user's cross-project work style.
    global_atlas = _read_or_empty(os.path.expanduser("~/.atlas/ATLAS.md"))
    if global_atlas:
        sections.extend(["", "## Your global ATLAS.md (~/.atlas/ATLAS.md)",
                         "How the user works across all projects:", "",
                         global_atlas])

    # 3–4. Memory snapshots (frozen at turn start).
    if include_memory:
        snap = memory_mod.read()
        if snap.memory.strip() and snap.memory.strip() != _MEMORY_HEADER_TRIM:
            sections.extend(["", "## Agent memory (~/.atlas/memory.md)", snap.memory])
        if snap.user.strip() and snap.user.strip() != _USER_HEADER_TRIM:
            sections.extend(["", "## User profile (~/.atlas/user.md)", snap.user])

    # 5. Per-project context — first file present in cwd wins, all are
    #    appended if multiple exist (some teams ship more than one).
    for fname in ("AGENTS.md", "CLAUDE.md", "ATLAS.md"):
        local = _read_or_empty(os.path.join(scope_root, fname))
        if local:
            sections.extend(["", f"## Project context ({fname})", local])

    # 6. Repo map.
    if include_repo_map:
        tree = repo_map_mod.repo_map(scope_root)
        if tree:
            sections.extend(["", "## Repo map (top-level symbols in scope root)", tree])

    if extras:
        for block in extras:
            sections.extend(["", block])

    return "\n".join(sections)


# Sentinel strings to detect "memory is just the seeded header, nothing
# actually written yet" — skip those blocks to keep the prompt tight.
_MEMORY_HEADER_TRIM = memory_mod._MEM_HEADER.strip()  # noqa: SLF001 — read-only access
_USER_HEADER_TRIM = memory_mod._USER_HEADER.strip()   # noqa: SLF001


def _read_or_empty(path: str) -> str:
    """Read a file if it exists; return empty string if missing / unreadable.
    Quiet by design — a missing AGENTS.md isn't an error."""
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    except (OSError, UnicodeDecodeError):
        return ""
