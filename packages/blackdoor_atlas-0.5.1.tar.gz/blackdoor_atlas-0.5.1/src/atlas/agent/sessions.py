"""Session persistence + FTS5 search.

Two responsibilities:

  1. **Persist** each REPL session as a JSON file under
     `~/.atlas/sessions/<id>.json` so it can be resumed with
     `atlas resume <id>`. Writes are atomic (write-then-rename).

  2. **Search** prior session transcripts via FTS5 ("have we worked on X
     before?"). The index lives in `~/.atlas/sessions.sqlite` for Day 2-4;
     when Day 5-7 lands the unified workspace DB at `~/.atlas/data.sqlite`,
     this gets folded into it as the `agent_sessions` + `agent_sessions_fts`
     tables.

Ported from apps/api/src/repos/SessionsRepo.ts. Same FTS5 schema, same
intent-only indexing (skip tool inputs + tool results — they're noisy and
crowd out the real signal).
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import sqlite3
import tempfile
from dataclasses import asdict, dataclass, field
from typing import Any

from atlas.agent.types import ChatMessage


# --- paths -----------------------------------------------------------------


def _root() -> str:
    return os.path.expanduser("~/.atlas")


def _sessions_dir() -> str:
    return os.path.join(_root(), "sessions")


def _db_path() -> str:
    return os.path.join(_root(), "sessions.sqlite")


# --- file persistence ------------------------------------------------------


@dataclass
class StoredSession:
    id: str
    created_at: str
    updated_at: str
    provider: str
    model: str
    messages: list[ChatMessage] = field(default_factory=list)


def new_session_id() -> str:
    """UTC timestamp + short random suffix. Matches the TS format."""
    import secrets
    now = _dt.datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    return f"{now}-{secrets.token_hex(3)}"


def save(session: StoredSession) -> str:
    """Atomically write `~/.atlas/sessions/<id>.json`. Returns the path."""
    os.makedirs(_sessions_dir(), exist_ok=True)
    target = os.path.join(_sessions_dir(), f"{session.id}.json")
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=_sessions_dir())
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(asdict(session), f, indent=2)
        os.replace(tmp, target)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return target


def load(session_id: str) -> StoredSession | None:
    """Read a session back from disk. Returns None if missing or malformed."""
    path = os.path.join(_sessions_dir(), f"{session_id}.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    return StoredSession(
        id=str(data.get("id", session_id)),
        created_at=str(data.get("created_at", "")),
        updated_at=str(data.get("updated_at", "")),
        provider=str(data.get("provider", "")),
        model=str(data.get("model", "")),
        messages=list(data.get("messages", [])),
    )


def list_recent(limit: int = 10) -> list[dict[str, Any]]:
    """Lightweight metadata listing — used by `atlas resume` without an id
    and by the `/sessions` REPL command. Reads file mtimes; no DB needed."""
    _ensure_index()
    rows = _conn().execute(
        """
        SELECT session_id, path, created_at, updated_at, provider, model,
               first_user, message_count
          FROM agent_sessions
         ORDER BY mtime_ms DESC
         LIMIT ?
        """,
        (max(1, min(50, limit)),),
    ).fetchall()
    return [
        {
            "session_id": r[0],
            "path": r[1],
            "created_at": r[2],
            "updated_at": r[3],
            "provider": r[4],
            "model": r[5],
            "first_user": r[6],
            "message_count": r[7],
        }
        for r in rows
    ]


# --- FTS5 index -----------------------------------------------------------


def _conn() -> sqlite3.Connection:
    """Open (and cache) the index DB. WAL mode so future cross-process
    reads (the dashboard, Day 8-10) don't block writes."""
    cnx = sqlite3.connect(_db_path())
    cnx.execute("PRAGMA journal_mode = WAL")
    cnx.execute("PRAGMA foreign_keys = ON")
    return cnx


def _ensure_index() -> None:
    """Create tables + sync with disk. Cheap when nothing changed."""
    os.makedirs(_root(), exist_ok=True)
    cnx = _conn()
    try:
        cnx.executescript(
            """
            CREATE TABLE IF NOT EXISTS agent_sessions (
              id            INTEGER PRIMARY KEY AUTOINCREMENT,
              session_id    TEXT NOT NULL UNIQUE,
              path          TEXT NOT NULL,
              created_at    TEXT NOT NULL DEFAULT '',
              updated_at    TEXT NOT NULL DEFAULT '',
              provider      TEXT NOT NULL DEFAULT '',
              model         TEXT NOT NULL DEFAULT '',
              first_user    TEXT NOT NULL DEFAULT '',
              message_count INTEGER NOT NULL DEFAULT 0,
              mtime_ms      INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_agent_sessions_mtime
              ON agent_sessions(mtime_ms DESC);
            """,
        )
        # FTS5 may not be compiled in everywhere — Python's wheel for sqlite3
        # is usually built with it on macOS/Linux, but guard so a missing
        # tokenizer doesn't break the rest of `atlas`.
        try:
            cnx.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS agent_sessions_fts "
                "USING fts5(text, tokenize='porter unicode61')",
            )
        except sqlite3.OperationalError:
            # FTS5 absent — search will be a no-op. Best-effort.
            pass
        cnx.commit()
        _reindex(cnx)
    finally:
        cnx.close()


def _reindex(cnx: sqlite3.Connection) -> None:
    """Walk the sessions dir; insert/update rows where mtime advanced."""
    dir_ = _sessions_dir()
    if not os.path.isdir(dir_):
        return
    on_disk: set[str] = set()
    for name in os.listdir(dir_):
        if not name.endswith(".json"):
            continue
        sid = name[:-5]
        on_disk.add(sid)
        abs_path = os.path.join(dir_, name)
        try:
            mtime_ms = int(os.path.getmtime(abs_path) * 1000)
        except OSError:
            continue
        row = cnx.execute(
            "SELECT id, mtime_ms FROM agent_sessions WHERE session_id = ?",
            (sid,),
        ).fetchone()
        if row and row[1] == mtime_ms:
            continue
        parsed = _parse_session(abs_path)
        if parsed is None:
            continue
        cnx.execute(
            """
            INSERT INTO agent_sessions
              (session_id, path, created_at, updated_at, provider, model,
               first_user, message_count, mtime_ms)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id) DO UPDATE SET
              path=excluded.path, created_at=excluded.created_at,
              updated_at=excluded.updated_at, provider=excluded.provider,
              model=excluded.model, first_user=excluded.first_user,
              message_count=excluded.message_count, mtime_ms=excluded.mtime_ms
            """,
            (sid, os.path.relpath(abs_path, _root()), parsed["created_at"], parsed["updated_at"],
             parsed["provider"], parsed["model"], parsed["first_user"],
             parsed["message_count"], mtime_ms),
        )
        row_id = cnx.execute(
            "SELECT id FROM agent_sessions WHERE session_id = ?", (sid,),
        ).fetchone()[0]
        try:
            cnx.execute("DELETE FROM agent_sessions_fts WHERE rowid = ?", (row_id,))
            cnx.execute(
                "INSERT INTO agent_sessions_fts (rowid, text) VALUES (?, ?)",
                (row_id, parsed["text"]),
            )
        except sqlite3.OperationalError:
            # FTS5 not available — silently skip; metadata still indexed.
            pass

    # Garbage-collect sessions whose file vanished.
    rows = cnx.execute("SELECT id, session_id FROM agent_sessions").fetchall()
    for row_id, sid in rows:
        if sid in on_disk:
            continue
        try:
            cnx.execute("DELETE FROM agent_sessions_fts WHERE rowid = ?", (row_id,))
        except sqlite3.OperationalError:
            pass
        cnx.execute("DELETE FROM agent_sessions WHERE id = ?", (row_id,))
    cnx.commit()


def _parse_session(abs_path: str) -> dict[str, Any] | None:
    """Pull the FTS-relevant bits out of a session JSON. Intent-only: skip
    tool inputs + tool outputs (noisy file listings / stderr — they crowd
    out the real signal a human is searching for)."""
    try:
        with open(abs_path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    messages = data.get("messages")
    if not isinstance(messages, list):
        return None
    parts: list[str] = []
    first_user = ""
    for m in messages:
        if m.get("role") == "user" and isinstance(m.get("content"), str):
            if not first_user:
                first_user = m["content"]
            parts.append(m["content"])
        elif m.get("role") == "assistant" and isinstance(m.get("content"), list):
            for block in m["content"]:
                if block.get("type") == "text" and isinstance(block.get("text"), str):
                    parts.append(block["text"])
    return {
        "session_id": str(data.get("id", "")),
        "created_at": str(data.get("created_at", "")),
        "updated_at": str(data.get("updated_at", "")),
        "provider": str(data.get("provider", "")),
        "model": str(data.get("model", "")),
        "first_user": first_user[:200],
        "text": "\n\n".join(parts),
        "message_count": len(messages),
    }


# --- search ---------------------------------------------------------------


def search(query: str, limit: int = 10) -> list[dict[str, Any]]:
    """FTS5 search across prior sessions. Returns ranked snippets.

    Query is passed verbatim to FTS5 — callers can use the syntax:
    bare terms (AND), `"exact phrase"`, `term*` (prefix), OR, NOT.
    """
    q = query.strip()
    if not q:
        return []
    _ensure_index()
    cnx = _conn()
    try:
        try:
            rows = cnx.execute(
                """
                SELECT s.session_id, s.path, s.created_at, s.updated_at,
                       s.provider, s.model, s.first_user, s.message_count,
                       snippet(agent_sessions_fts, 0, '<<', '>>', '…', 12) AS snippet,
                       bm25(agent_sessions_fts) AS rank
                  FROM agent_sessions_fts
                  JOIN agent_sessions s ON s.id = agent_sessions_fts.rowid
                 WHERE agent_sessions_fts MATCH ?
                 ORDER BY rank ASC
                 LIMIT ?
                """,
                (q, max(1, min(50, limit))),
            ).fetchall()
        except sqlite3.OperationalError as e:
            raise RuntimeError(f"session_search: invalid FTS5 query: {e}") from e
        return [
            {
                "session_id": r[0],
                "path": r[1],
                "created_at": r[2],
                "updated_at": r[3],
                "provider": r[4],
                "model": r[5],
                "first_user": r[6],
                "message_count": r[7],
                "snippet": r[8],
                "rank": r[9],
            }
            for r in rows
        ]
    finally:
        cnx.close()
