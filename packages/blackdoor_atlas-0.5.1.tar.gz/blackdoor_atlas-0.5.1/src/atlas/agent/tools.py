"""Filesystem + shell tools.

Ported from apps/api/src/agent/tools.ts. Each tool has a JSON-schema input
shape (sent to the provider so the model knows how to call it) and a
`run(input, ctx)` that returns a string result.

Day 2 covers the *static* tools — repo-scoped, no user context required:
list_dir, read_file, write_file, edit_file, search, run_command.

Memory, sessions, repo_map, and the PM tools (list_projects, list_tasks,
create_task, update_task) move in once the repos exist (Day 5-7).

Path safety: every path-taking tool calls `_safe_join(rel, root)` which
prevents escapes via `..` or absolute paths. The `root` is whatever the
agent's scope policy says — cwd by default; the workspace SQLite dir in
`workspace` mode; the whole filesystem only in `unbound` mode (Day 11).
"""

from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass
from typing import Any, Callable

from atlas.agent import memory as memory_mod
from atlas.agent import repo_map as repo_map_mod
from atlas.agent import sessions as sessions_mod
from atlas.agent.types import ToolDef


# --- context ---------------------------------------------------------------


@dataclass
class ToolContext:
    """Per-invocation context. `root` is the filesystem boundary; tools
    refuse to read or write outside it. `user_id` and `company_id` plug
    the PM tools into the active workspace (populated Day 5-7)."""

    root: str
    user_id: int | None = None
    company_id: int | None = None


# --- registry --------------------------------------------------------------


ToolHandler = Callable[[dict[str, Any], ToolContext], str]


@dataclass
class ToolImpl:
    definition: ToolDef
    run: ToolHandler


# --- path safety + helpers -------------------------------------------------


def _safe_join(rel: str, root: str) -> str:
    """Resolve `rel` against `root`; raise if it escapes. Mirrors the TS
    `safeJoin` in apps/api/src/agent/tools.ts."""
    rel = rel or "."
    abs_path = os.path.realpath(os.path.join(root, rel))
    root_real = os.path.realpath(root)
    if not (abs_path == root_real or abs_path.startswith(root_real + os.sep)):
        raise ValueError(f"path escapes scope root: {rel}")
    return abs_path


def _maybe_truncate(body: str, limit: int = 200_000) -> str:
    if len(body) <= limit:
        return body
    return f"{body[:limit]}\n…[truncated {len(body) - limit} bytes]"


# --- list_dir --------------------------------------------------------------


def _list_dir(input_: dict[str, Any], ctx: ToolContext) -> str:
    target = _safe_join(str(input_.get("path", ".")), ctx.root)
    try:
        entries = sorted(os.listdir(target))
    except OSError as e:
        return f"ERROR: {e.strerror}: {input_.get('path')!r}"
    out: list[str] = []
    for name in entries:
        if name.startswith(".git") or name in ("node_modules", ".venv"):
            continue
        full = os.path.join(target, name)
        try:
            st = os.stat(full)
        except OSError:
            continue
        kind = "dir" if os.path.isdir(full) else "file" if os.path.isfile(full) else "other"
        suffix = "/" if kind == "dir" else ""
        out.append(f"{kind:<5} {st.st_size:>8} {name}{suffix}")
    return "\n".join(out) if out else "(empty)"


# --- read_file -------------------------------------------------------------


def _read_file(input_: dict[str, Any], ctx: ToolContext) -> str:
    target = _safe_join(str(input_["path"]), ctx.root)
    try:
        with open(target, encoding="utf-8") as f:
            return _maybe_truncate(f.read())
    except OSError as e:
        return f"ERROR: {e.strerror}: {input_['path']!r}"
    except UnicodeDecodeError:
        return f"ERROR: not a UTF-8 text file: {input_['path']!r}"


# --- write_file ------------------------------------------------------------


def _write_file(input_: dict[str, Any], ctx: ToolContext) -> str:
    target = _safe_join(str(input_["path"]), ctx.root)
    content = str(input_.get("content", ""))
    os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
    with open(target, "w", encoding="utf-8") as f:
        f.write(content)
    repo_map_mod.invalidate(ctx.root)
    rel = os.path.relpath(target, ctx.root)
    return f"wrote {rel} ({len(content)} bytes)"


# --- edit_file -------------------------------------------------------------


def _edit_file(input_: dict[str, Any], ctx: ToolContext) -> str:
    target = _safe_join(str(input_["path"]), ctx.root)
    find = str(input_["find"])
    replace = str(input_.get("replace", ""))
    try:
        with open(target, encoding="utf-8") as f:
            body = f.read()
    except OSError as e:
        return f"ERROR: {e.strerror}: {input_['path']!r}"

    first = body.find(find)
    if first == -1:
        return f"ERROR: find string not found in {input_['path']!r}"
    if body.find(find, first + 1) != -1:
        return f"ERROR: find string appears more than once in {input_['path']!r}; use write_file or provide more context"
    new = body[:first] + replace + body[first + len(find):]
    with open(target, "w", encoding="utf-8") as f:
        f.write(new)
    repo_map_mod.invalidate(ctx.root)
    rel = os.path.relpath(target, ctx.root)
    return f"edited {rel} (−{len(find)} +{len(replace)} bytes)"


# --- search ----------------------------------------------------------------


def _search(input_: dict[str, Any], ctx: ToolContext) -> str:
    """Regex search across the scope root, capped at 80 hits."""
    pattern = str(input_["pattern"])
    where_rel = str(input_.get("path", "."))
    where = _safe_join(where_rel, ctx.root)
    try:
        rx = re.compile(pattern)
    except re.error as e:
        return f"ERROR: invalid regex: {e}"

    hits: list[str] = []
    skip_dirs = {".git", "node_modules", ".venv", "dist", ".agent", "__pycache__"}
    file_exts = {".ts", ".tsx", ".js", ".py", ".md", ".yaml", ".yml", ".json", ".toml"}
    truncated = False

    for root, dirs, files in os.walk(where):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for name in files:
            if not any(name.endswith(ext) for ext in file_exts):
                continue
            path = os.path.join(root, name)
            try:
                with open(path, encoding="utf-8") as f:
                    for lineno, line in enumerate(f, start=1):
                        if rx.search(line):
                            rel = os.path.relpath(path, ctx.root)
                            hits.append(f"{rel}:{lineno}:{line.rstrip()}")
                            if len(hits) >= 80:
                                truncated = True
                                break
            except (OSError, UnicodeDecodeError):
                continue
            if truncated:
                break
        if truncated:
            break

    if not hits:
        return "(no matches)"
    suffix = f"\n…[capped at 80 — more matches exist]" if truncated else ""
    return "\n".join(hits) + suffix


# --- run_command -----------------------------------------------------------


def _run_command(input_: dict[str, Any], ctx: ToolContext) -> str:
    cmd = str(input_["command"])
    try:
        proc = subprocess.run(  # noqa: S602 — by design: the model said to run this
            ["/bin/sh", "-c", cmd],
            cwd=ctx.root,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired as e:
        return "\n".join([
            f"$ {cmd}",
            f"--- stdout ---\n{e.stdout or ''}",
            f"--- stderr ---\n{e.stderr or ''}",
            "(killed — exceeded 30s)",
        ])
    except OSError as e:
        return f"ERROR: failed to spawn shell: {e}"

    parts = [f"$ {cmd}"]
    if proc.stdout:
        parts.append(f"--- stdout ---\n{proc.stdout}")
    if proc.stderr:
        parts.append(f"--- stderr ---\n{proc.stderr}")
    parts.append(f"(exit {proc.returncode})")
    return "\n".join(parts)


# --- tool defs (the wire shape sent to the provider) ----------------------


_LIST_DIR: ToolImpl = ToolImpl(
    definition={
        "name": "list_dir",
        "description": "List the entries of a directory (relative to the scope root). Use this to discover paths before reading or editing.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path relative to the scope root. Use '.' for root."},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    run=_list_dir,
)

_READ_FILE: ToolImpl = ToolImpl(
    definition={
        "name": "read_file",
        "description": "Read a UTF-8 text file relative to the scope root. Returns at most ~200KB; longer files are truncated with a marker.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    run=_read_file,
)

_WRITE_FILE: ToolImpl = ToolImpl(
    definition={
        "name": "write_file",
        "description": "Write a UTF-8 text file relative to the scope root. Creates parent directories. Overwrites existing files. Sensitive — gated by permission prompt in CLI mode.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string", "description": "Full file contents."},
            },
            "required": ["path", "content"],
            "additionalProperties": False,
        },
    },
    run=_write_file,
)

_EDIT_FILE: ToolImpl = ToolImpl(
    definition={
        "name": "edit_file",
        "description": "Replace the first exact occurrence of `find` with `replace` in `path`. `find` must match exactly and appear exactly once. Sensitive — gated.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "find": {"type": "string"},
                "replace": {"type": "string"},
            },
            "required": ["path", "find", "replace"],
            "additionalProperties": False,
        },
    },
    run=_edit_file,
)

_SEARCH: ToolImpl = ToolImpl(
    definition={
        "name": "search",
        "description": "Regex search across the scope root. Returns up to 80 matching lines (path:line:content). Use this to locate symbols, error messages, or call sites.",
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Regex pattern (Python `re` flavor)."},
                "path": {"type": "string", "description": "Subdirectory to search. Defaults to scope root."},
            },
            "required": ["pattern"],
            "additionalProperties": False,
        },
    },
    run=_search,
)

_RUN_COMMAND: ToolImpl = ToolImpl(
    definition={
        "name": "run_command",
        "description": "Run a shell command inside the scope root. 30s timeout. Sensitive — gated. Do not start long-running servers.",
        "input_schema": {
            "type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"],
            "additionalProperties": False,
        },
    },
    run=_run_command,
)


# --- memory (Hermes-style persistent notes) -------------------------------


def _memory(input_: dict[str, Any], _ctx: ToolContext) -> str:
    action = str(input_.get("action", ""))
    which = "user" if input_.get("target") == "user" else "memory"
    target_path = "~/.atlas/" + which + ".md"

    if action == "read":
        snap = memory_mod.read()
        body = snap.user if which == "user" else snap.memory
        return f"--- {target_path} ---\n{body}"
    if action == "add":
        r = memory_mod.add(which, str(input_.get("entry", "")))
        return f"added to {target_path}" if r.added else f"skipped ({r.reason})"
    if action == "replace":
        r = memory_mod.replace(which, str(input_.get("find", "")), str(input_.get("replace", "")))
        if not r.changed and r.matches == 0:
            return f"ERROR: `find` not found in {target_path}"
        if not r.changed and r.matches > 1:
            return f"ERROR: `find` matches {r.matches} times in {target_path} — be more specific"
        return f"replaced in {target_path}"
    if action == "remove":
        r = memory_mod.remove(which, str(input_.get("find", "")))
        if r.removed == 0:
            return f"ERROR: `find` not found in {target_path}"
        return f"removed {r.removed} occurrence(s) from {target_path}"
    return f"ERROR: unknown action {action!r} (use read | add | replace | remove)"


_MEMORY: ToolImpl = ToolImpl(
    definition={
        "name": "memory",
        "description": (
            "Read or write the agent's persistent memory. Two files: "
            "`memory` (notes about this repo / environment / conventions) and "
            "`user` (preferences and communication style). Use sparingly — only "
            "for *durable* facts you want to recall next session. Writes appear in "
            "the system prompt next session (frozen-snapshot pattern). "
            "Actions: read | add | replace | remove."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "description": "read | add | replace | remove"},
                "target": {"type": "string", "description": "memory | user (default: memory)"},
                "entry": {"type": "string", "description": "For add: the line to add. Bullet prefix optional."},
                "find": {"type": "string", "description": "For replace/remove: substring to match."},
                "replace": {"type": "string", "description": "For replace: substring to insert."},
            },
            "required": ["action"],
            "additionalProperties": False,
        },
    },
    run=_memory,
)


# --- session_search (Hermes FTS5 over prior sessions) ---------------------


def _session_search(input_: dict[str, Any], _ctx: ToolContext) -> str:
    q = str(input_.get("query", "")).strip()
    if not q:
        return "ERROR: query is required"
    limit_raw = input_.get("limit", 10)
    try:
        limit = max(1, min(50, int(limit_raw)))
    except (TypeError, ValueError):
        limit = 10
    try:
        hits = sessions_mod.search(q, limit=limit)
    except RuntimeError as e:
        return f"ERROR: {e}"
    if not hits:
        return "(no matches across prior sessions)"
    lines: list[str] = []
    for i, h in enumerate(hits, start=1):
        when = (h.get("updated_at") or h.get("created_at") or "")[:19].replace("T", " ")
        head = f"{i}. {h['session_id']}  {when}  {h.get('provider', '')}/{h.get('model', '')}  ({h.get('message_count', 0)} msgs)"
        first = h.get("first_user", "")
        if first:
            first = " ".join(first.split())[:120]
        snip = h.get("snippet", "")
        snip = " ".join(snip.split())[:200] if snip else ""
        block = [head]
        if first:
            block.append(f"   first: {first}")
        if snip:
            block.append(f"   match: {snip}")
        block.append(f"   file:  {h.get('path', '')}")
        lines.append("\n".join(block))
    return "\n\n".join(lines)


_SESSION_SEARCH: ToolImpl = ToolImpl(
    definition={
        "name": "session_search",
        "description": (
            "Full-text search across the agent's prior session transcripts under "
            "~/.atlas/sessions/. Use this when the user references 'last time', "
            "'previous session', 'earlier conversation', or to recall what was "
            "discussed before. Supports FTS5 syntax: bare terms are ANDed, "
            "\"exact phrase\" for phrases, term* for prefix, OR / NOT."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "FTS5 query. Examples: `permission gate`, `\"linear sidebar\"`, `cycle* NOT done`.",
                },
                "limit": {"type": "number", "description": "Max results (1–50, default 10)."},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    },
    run=_session_search,
)


_STATIC: list[ToolImpl] = [
    _LIST_DIR, _READ_FILE, _WRITE_FILE, _EDIT_FILE, _SEARCH, _RUN_COMMAND,
    _MEMORY, _SESSION_SEARCH,
]


# --- PM tools (workspace-scoped — only registered when ctx has a workspace)


def _pm_list_projects(_input: dict[str, Any], ctx: ToolContext) -> str:
    if ctx.company_id is None:
        return "ERROR: no active workspace"
    from atlas.repos import project as project_repo
    rows = project_repo.list_for_company(ctx.company_id)
    if not rows:
        return "(no projects)"
    return "\n".join(
        f"#{p.id}  [{p.status}]  {p.name}  ({p.done_count}/{p.task_count} done)"
        for p in rows
    )


def _pm_list_tasks(input_: dict[str, Any], ctx: ToolContext) -> str:
    if ctx.company_id is None:
        return "ERROR: no active workspace"
    from atlas.repos import project as project_repo
    from atlas.repos import task as task_repo
    pid_raw = input_.get("project_id")
    try:
        pid = int(pid_raw)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return "ERROR: project_id must be an integer"
    if project_repo.find_for_company(pid, ctx.company_id) is None:
        return f"ERROR: project {pid} not found in active workspace"
    rows = task_repo.list_in_project(pid)
    if not rows:
        return "(no tasks)"
    return "\n".join(
        f"#{t.id}  [{t.status}/{t.priority}]  {t.title}"
        + (f"  @{t.assignee}" if t.assignee else "")
        + (f"  due {t.due_date}" if t.due_date else "")
        for t in rows
    )


def _pm_create_task(input_: dict[str, Any], ctx: ToolContext) -> str:
    if ctx.company_id is None:
        return "ERROR: no active workspace"
    from atlas.repos import project as project_repo
    from atlas.repos import task as task_repo
    pid_raw = input_.get("project_id")
    try:
        pid = int(pid_raw)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return "ERROR: project_id must be an integer"
    if project_repo.find_for_company(pid, ctx.company_id) is None:
        return f"ERROR: project {pid} not found in active workspace"
    title = str(input_.get("title", "")).strip()
    if not title:
        return "ERROR: title is required"
    priority = str(input_.get("priority", "med"))
    if priority not in ("urgent", "high", "med", "low"):
        priority = "med"
    status = str(input_.get("status", "todo"))
    if status not in ("backlog", "todo", "started", "review", "done", "cancelled"):
        status = "todo"
    t = task_repo.create(
        project_id=pid,
        title=title[:280],
        body=str(input_.get("body", "")),
        status=status,  # type: ignore[arg-type]
        priority=priority,  # type: ignore[arg-type]
    )
    return f'created task #{t.id} "{t.title}" in project {pid} ({status}/{priority})'


def _pm_update_task(input_: dict[str, Any], ctx: ToolContext) -> str:
    if ctx.company_id is None:
        return "ERROR: no active workspace"
    from atlas.repos import task as task_repo
    id_raw = input_.get("id")
    try:
        tid = int(id_raw)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return "ERROR: id must be an integer"
    existing = task_repo.workspace_check(tid, ctx.company_id)
    if existing is None:
        return f"ERROR: task {tid} not found in active workspace"
    patch: dict[str, object] = {}
    for k in ("title", "body", "status", "priority", "assignee"):
        if k in input_:
            patch[k] = str(input_[k])
    if not patch:
        return f"(no-op; task {tid} unchanged)"
    task_repo.update(tid, **patch)
    # Mirror the TS side: on a status -> done transition, set completed_at.
    if "status" in patch and patch["status"] != existing.get("status"):
        from datetime import datetime, timezone
        task_repo.set_completed_at(
            tid,
            datetime.now(timezone.utc).isoformat(timespec="seconds")
            if patch["status"] == "done" else None,
        )
    return f"updated task #{tid}: {', '.join(patch.keys())}"


_PM_TOOLS: list[ToolImpl] = [
    ToolImpl(
        definition={
            "name": "list_projects",
            "description": "List projects in the active workspace. Use before suggesting work — match by name to find ids.",
            "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
        },
        run=_pm_list_projects,
    ),
    ToolImpl(
        definition={
            "name": "list_tasks",
            "description": "List tasks for one project (workspace-scoped). Returns id, status, priority, title, assignee.",
            "input_schema": {
                "type": "object",
                "properties": {"project_id": {"type": "number", "description": "From list_projects."}},
                "required": ["project_id"],
                "additionalProperties": False,
            },
        },
        run=_pm_list_tasks,
    ),
    ToolImpl(
        definition={
            "name": "create_task",
            "description": "Create a task in a project. Returns the new task id. Sensitive — gated.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "project_id": {"type": "number"},
                    "title": {"type": "string", "description": "Imperative, ≤280 chars."},
                    "body": {"type": "string"},
                    "priority": {"type": "string", "description": "urgent | high | med | low"},
                    "status": {"type": "string", "description": "backlog | todo | started | review | done | cancelled"},
                },
                "required": ["project_id", "title"],
                "additionalProperties": False,
            },
        },
        run=_pm_create_task,
    ),
    ToolImpl(
        definition={
            "name": "update_task",
            "description": "Update one task: status, priority, title, body, or assignee. Sensitive — gated.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "id": {"type": "number"},
                    "title": {"type": "string"},
                    "body": {"type": "string"},
                    "status": {"type": "string"},
                    "priority": {"type": "string"},
                    "assignee": {"type": "string"},
                },
                "required": ["id"],
                "additionalProperties": False,
            },
        },
        run=_pm_update_task,
    ),
]


# --- registry surface ------------------------------------------------------


# Tools that mutate state OR run arbitrary code. These are the ones the
# permission gate covers. Mirrors apps/api/src/agent/runner.ts SENSITIVE_TOOLS.
SENSITIVE_TOOLS: frozenset[str] = frozenset({
    "write_file", "edit_file", "run_command",
    "create_task", "update_task",
})

# Tools stripped in `ask` and `plan` modes — they would mutate state.
WRITE_TOOLS: frozenset[str] = frozenset({
    "write_file", "edit_file", "run_command",
    "create_task", "update_task",
})


def _active(ctx: ToolContext) -> list[ToolImpl]:
    """Tools available given the context. PM tools require a workspace."""
    tools = list(_STATIC)
    if ctx.company_id is not None:
        tools.extend(_PM_TOOLS)
    return tools


def build_tool_defs(ctx: ToolContext) -> list[ToolDef]:
    """Tool list for the active context. Mode-filtering happens in the
    runner (it strips WRITE_TOOLS when mode != 'code')."""
    return [t.definition for t in _active(ctx)]


def run_tool(name: str, input_: dict[str, Any], ctx: ToolContext) -> tuple[str, bool]:
    """Returns (content, is_error). `is_error` is True if the result string
    starts with the `ERROR:` sentinel — matches the TS convention so the
    provider sees consistent error markers regardless of language."""
    impl = next((t for t in _active(ctx) if t.definition["name"] == name), None)
    if impl is None:
        return f"ERROR: unknown tool {name}", True
    try:
        content = impl.run(input_, ctx)
    except Exception as e:  # noqa: BLE001 — surface any tool failure as a tool result
        return f"ERROR: {e}", True
    return content, content.startswith("ERROR:")
