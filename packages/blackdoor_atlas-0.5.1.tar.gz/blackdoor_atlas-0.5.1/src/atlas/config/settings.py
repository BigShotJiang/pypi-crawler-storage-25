"""Persistent settings at ``~/.atlas/config.json``.

Single small JSON file — same posture as Claude Code's
``~/.claude/settings.json``. Atomic write (write-then-rename) so a crash
mid-save can't corrupt the file.

Schema is forgiving: unknown keys round-trip, missing keys take defaults.
That keeps forward-compat trivial when v0.2 adds new fields.
"""

from __future__ import annotations

import dataclasses
import json
import os
import tempfile
from dataclasses import dataclass, field
from typing import Any, Literal


_SCHEMA_VERSION = 1


def config_path() -> str:
    home = os.environ.get("ATLAS_HOME") or os.path.expanduser("~/.atlas")
    return os.path.join(home, "config.json")


@dataclass
class Settings:
    """The persisted shape of ~/.atlas/config.json.

    ``provider`` / ``model`` are user-friendly overrides — the same values
    you'd pass via ATLAS_PROVIDER / ATLAS_MODEL on the command line. They
    feed into the splash and the bottom status line; the agent runtime
    still falls back to env vars when these are empty.

    ``api_keys`` holds saved credentials per provider. The file is written
    with mode 0600 so other local accounts can't read it. v0.2 may move
    this to the system keychain on macOS / Windows.
    """

    schema_version: int = _SCHEMA_VERSION
    provider: str = ""                                # "" = auto-select
    model: str = ""                                   # "" = provider default
    api_keys: dict[str, str] = field(default_factory=dict)
    # Custom OpenAI-compatible endpoint URL (Ollama / LM Studio / vLLM / etc.).
    openai_base_url: str = ""
    mode: Literal["code", "ask", "plan"] = "code"
    scope: Literal["scoped", "workspace", "unbound"] = "scoped"
    effort: Literal["low", "medium", "high", "xhigh", "max"] = "high"
    thinking: bool = False
    confirm: bool = True                              # OpenClaude action_required gate
    last_workspace_id: int | None = None
    last_session_id: str | None = None
    # Tracks whether the first-run wizard has been completed. False on a
    # fresh install — the REPL uses this to decide whether to launch the
    # setup flow on first invocation.
    onboarded: bool = False
    # Carries any unknown keys forward so a v0.2 setting set by a newer
    # build doesn't disappear when an older `atlas` reads + writes the file.
    _extras: dict[str, Any] = field(default_factory=dict, repr=False)


# --- I/O -------------------------------------------------------------------


def load() -> Settings:
    """Read the config file. Returns defaults when the file doesn't exist
    or is malformed — never raises (the REPL must boot even with a broken
    config)."""
    path = config_path()
    try:
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
    except (OSError, json.JSONDecodeError):
        return Settings()
    if not isinstance(raw, dict):
        return Settings()
    s = Settings()
    known = {f.name for f in dataclasses.fields(s) if f.name != "_extras"}
    for k, v in raw.items():
        if k in known:
            try:
                setattr(s, k, v)
            except (TypeError, ValueError):
                pass
        elif not k.startswith("_"):
            s._extras[k] = v
    return s


def save(settings: Settings) -> None:
    """Atomic write: temp file in the target dir, rename into place.

    The file may contain API keys — chmod 600 the result so other local
    accounts on a multi-user box can't read it.
    """
    path = config_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)

    payload: dict[str, Any] = dataclasses.asdict(settings)
    payload.pop("_extras", None)
    payload.update(settings._extras)

    fd, tmp = tempfile.mkstemp(prefix=".config-", dir=os.path.dirname(path))
    try:
        os.chmod(tmp, 0o600)  # set perms BEFORE writing the secret
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


# --- get / set helpers -----------------------------------------------------


def get_key(key: str) -> Any:
    """`atlas config get <key>` — dotted-path lookup over the dataclass +
    extras. Unknown keys return None rather than raise."""
    s = load()
    parts = key.split(".")
    cur: Any = dataclasses.asdict(s)
    cur.pop("_extras", None)
    cur.update(s._extras)
    for p in parts:
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return None
    return cur


def set_key(key: str, value: Any) -> Settings:
    """`atlas config set <key> <value>` — coerces ``value`` against the
    known field types when possible, otherwise stores it under ``_extras``."""
    s = load()
    parts = key.split(".")
    known = {f.name: f.type for f in dataclasses.fields(s) if f.name != "_extras"}

    if len(parts) == 1 and parts[0] in known:
        setattr(s, parts[0], _coerce(value, known[parts[0]]))
    else:
        # Nested + unknown — stuff under _extras as plain dicts.
        cur = s._extras
        for p in parts[:-1]:
            cur = cur.setdefault(p, {})
        cur[parts[-1]] = value

    save(s)
    return s


def _coerce(value: Any, type_hint: Any) -> Any:
    """Best-effort scalar coercion. CLI args come in as strings — this
    turns ``"true"`` into True for bool fields, ``"42"`` into 42 for int
    fields, etc. Falls through unchanged for everything else."""
    if isinstance(value, str):
        if type_hint in (bool, "bool"):
            return value.lower() in ("1", "true", "yes", "on")
        if type_hint in (int, "int") or type_hint == "int | None":
            try:
                return int(value)
            except ValueError:
                return value
    return value
