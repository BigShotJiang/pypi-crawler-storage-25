"""Config + context cascade.

Lands Day 11:

  settings.py   # read/write ~/.atlas/config.json — provider keys, defaults
  context.py    # build the system prompt's context cascade:
                #   1. harness base prompt
                #   2. ~/.atlas/ATLAS.md   (user's cross-project work style)
                #   3. ~/.atlas/memory.md + user.md
                #   4. cwd AGENTS.md → CLAUDE.md → ATLAS.md (project-local)
                #   5. repo map of cwd
"""
