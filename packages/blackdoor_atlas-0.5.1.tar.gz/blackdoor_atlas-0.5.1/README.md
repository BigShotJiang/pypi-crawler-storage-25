# ATLAS

**A terminal AI harness with a built-in project workspace.**

*Shift the world. Reach beyond yourself.*

ATLAS is a chat-first agent CLI in the spirit of Claude Code, Codex, hermes,
and aider — but with a real project management workspace baked in, so humans
manage AI agents and work alongside each other in one place.

```
       ◯
      ╱│╲              ATLAS
     ╱ │ ╲             ─────
    ─ ─┴─ ─            shift the world · reach beyond yourself
```

## Install

```sh
pipx install blackdoor-atlas    # Python 3.11+
atlas
```

Or grab a single-file binary from the [latest release](https://github.com/ryderderder/atlas-cli/releases):

```sh
# macOS arm64 example
curl -L -o atlas https://github.com/ryderderder/atlas-cli/releases/latest/download/atlas-macos-arm64
chmod +x atlas
sudo mv atlas /usr/local/bin/
```

Or via Homebrew (once published):

```sh
brew tap ryderderder/atlas-cli
brew install atlas-cli
```

## Use

From any directory:

```sh
atlas                  # chat REPL, picks up cwd as project context
atlas init             # check provider readiness
atlas dash             # launch the web dashboard at localhost:41821
atlas workspace ls     # list workspaces
atlas project ls       # list projects in the active workspace
atlas resume           # resume a prior session
atlas config get|set   # tweak persisted settings
```

State lives in `~/.atlas/`:

```
~/.atlas/
  data.sqlite      # workspaces, projects, issues, cycles
  config.json      # provider keys, defaults, last workspace
  ATLAS.md         # your cross-project work style (auto-loaded)
  memory.md        # agent's durable notes
  user.md          # agent's user-profile notes
  sessions/        # per-session transcripts
```

## Context cascade

When you start a chat ATLAS folds these into the system prompt, in order:

1. The base harness prompt
2. `~/.atlas/ATLAS.md` — *your* cross-project work style
3. `~/.atlas/memory.md` and `user.md` — agent memory
4. Whichever of `AGENTS.md` / `CLAUDE.md` / `ATLAS.md` exists in `cwd`
5. A symbol-map of `cwd` (aider-style)

Drop an `ATLAS.md` next to a project to give the agent project-specific
context. The format is whatever you want — it's just markdown.

## Providers

Auto-selected in this order; override with `ATLAS_PROVIDER`:

| Provider                      | Enabled by                                         |
|-------------------------------|-----------------------------------------------------|
| Anthropic API                 | `ANTHROPIC_API_KEY=...`                            |
| Claude Pro / Max (OAuth)      | Run `claude` once (uses your macOS Keychain creds) |
| OpenAI                        | `OPENAI_API_KEY=...`                               |
| Ollama / LM Studio / vLLM     | `ATLAS_OPENAI_BASE_URL=http://localhost:11434/v1`  |
| Mock (offline)                | Always available — `ATLAS_PROVIDER=mock`           |

`ATLAS_MODEL=claude-opus-4-7` (or whatever your provider serves) sets the
model. `atlas init` prints what's configured and what's missing.

## The dashboard

`atlas dash` spawns a local FastAPI server with the same `/api/*`
endpoints the agent talks to, plus the React workspace UI bundled in:

- Linear-style board / list / drawer / cycles / insights
- Workspace switcher, multi-workspace membership
- Live SSE chat stream with tool-call inspector
- OpenClaude-style permission gate with Plandex-flavored diff preview

Loopback-only by default. Override host/port with `ATLAS_DASH_HOST`,
`ATLAS_DASH_PORT`.

## Build from source

```sh
git clone https://github.com/ryderderder/atlas-cli
cd atlas-cli
make bootstrap        # installs deps + frontend toolchain
make smoke            # quick install + run check
make release          # build wheel + single-file binary
```

See `CHANGELOG.md` for what shipped in each release.

## License

[Apache 2.0](LICENSE).
