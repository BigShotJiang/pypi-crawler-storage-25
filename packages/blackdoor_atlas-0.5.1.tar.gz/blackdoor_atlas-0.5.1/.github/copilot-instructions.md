# GitHub Copilot instructions for ATLAS

The full rules live in [`AGENTS.md`](../AGENTS.md). What follows is the
TL;DR Copilot needs to see in this file specifically.

## Five non-negotiables

1. Branch off `master`, open a PR — never push direct.
2. Conventional commits: `feat: …`, `fix: …`, `chore: …`, `ci: …`,
   `docs: …`, `refactor: …`, `test: …`. One change per commit.
3. Don't bump `pyproject.toml`'s `version` or
   `src/atlas/__init__.py`'s `__version__`. release-please owns both.
4. `make smoke` passes before opening the PR.
5. The PR template's checklist isn't decorative.

## Project shape

- Python CLI at `src/atlas/`
- Bundled FastAPI dashboard at `src/atlas/dash/`
- Legacy Node + React at `apps/` (slated for removal in v0.2)
- Subdir `AGENTS.md` files contain local invariants — read those when
  working in `src/atlas/agent/` or `src/atlas/dash/`

## When in doubt

Read `AGENTS.md` at the repo root, then the closest `AGENTS.md` to the
file you're touching.
