<!--
  Thanks for the PR. The checklist below is the non-negotiable subset of
  AGENTS.md's rules — each item is here because we've been bitten by
  skipping it. If something doesn't apply, say so in the line.
-->

## Summary

<!-- One paragraph. What did you change? Why? -->

## Type of change

<!-- Pick one. Matches the conventional-commit prefix in your commits. -->

- [ ] `feat` — new user-facing capability
- [ ] `fix` — bug fix
- [ ] `chore` — internal cleanup; no user-facing change
- [ ] `ci` — CI / release infra
- [ ] `docs` — documentation only
- [ ] `refactor` — restructure without behavior change
- [ ] `test` — tests only
- [ ] `perf` — performance only

## Checklist

- [ ] Every commit message starts with a conventional prefix
      (`feat:`, `fix:`, `chore:`, …)
- [ ] One logical change per commit (squash later if needed)
- [ ] `make smoke` passes locally
- [ ] No edits to `pyproject.toml`'s `version` or
      `src/atlas/__init__.py`'s `__version__`
      (release-please owns both)
- [ ] No new secrets committed (`.env*` stays in `.gitignore`)
- [ ] If this changes user-facing behavior: docs / README / wizard
      copy updated
- [ ] If this changes a subdir's invariants: the local `AGENTS.md`
      was updated

## Related

<!-- Closes #123. References #456. Or "n/a". -->
