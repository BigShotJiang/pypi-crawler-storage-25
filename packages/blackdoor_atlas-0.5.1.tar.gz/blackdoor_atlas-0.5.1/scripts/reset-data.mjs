// Reset the dogfood SQLite database. Used as a Playwright globalSetup.
import { existsSync, rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(here, '..', 'apps', 'api', 'data.sqlite');
const journalPath = `${dbPath}-journal`;
const walPath = `${dbPath}-wal`;
const shmPath = `${dbPath}-shm`;

for (const p of [dbPath, journalPath, walPath, shmPath]) {
  if (existsSync(p)) {
    rmSync(p, { force: true });
    // eslint-disable-next-line no-console
    console.log('reset-data: removed', path.relative(process.cwd(), p));
  }
}

export default async function globalSetup(): Promise<void> {
  // Imported by Playwright; runs once before all tests.
}
