#!/usr/bin/env python3
"""Refresh src/atlas/cli/models.json from packaging/models.yaml.

Reads the curated list (which entries should be in the wizard) and for
each one hits the Ollama registry to get the current download size.
Writes the result as JSON the wizard reads at runtime.

Run locally:    python3 scripts/refresh-models.py
Run in CI:      `.github/workflows/refresh-models.yml` (weekly cron)

The cron action runs this then opens a PR if `models.json` changed.
Humans approve. Sizes drift as Ollama republishes quantizations; this
keeps the wizard's "X GB" annotations accurate without manual edits.

Registry API reference:
  GET https://registry.ollama.ai/v2/library/<name>/manifests/<tag>
  → JSON manifest with `layers[]`, each with a `size` field in bytes.
    Total download size = sum of layer sizes.
"""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml  # type: ignore[import-not-found]
except ImportError:
    sys.stderr.write("error: PyYAML is required. Install with: pip install pyyaml\n")
    sys.exit(2)


ROOT = Path(__file__).resolve().parent.parent
SOURCE_YAML = ROOT / "packaging" / "models.yaml"
TARGET_JSON = ROOT / "src" / "atlas" / "cli" / "models.json"

REGISTRY = "https://registry.ollama.ai/v2/library/{name}/manifests/{tag}"
ACCEPT = "application/vnd.docker.distribution.manifest.v2+json"


def fetch_size_bytes(model_id: str) -> int:
    """Sum the layer sizes from the Ollama registry manifest. Returns -1
    on any error so the caller can decide whether to fail or fall back."""
    name, _, tag = model_id.partition(":")
    if not tag:
        tag = "latest"
    url = REGISTRY.format(name=name, tag=tag)
    req = urllib.request.Request(url, headers={"Accept": ACCEPT})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as e:
        sys.stderr.write(f"  ! couldn't fetch {model_id}: {e}\n")
        return -1
    layers = body.get("layers")
    if not isinstance(layers, list):
        return -1
    total = 0
    for layer in layers:
        s = layer.get("size")
        if isinstance(s, int):
            total += s
    return total


def format_size(bytes_count: int) -> str:
    """Human-readable size — what the wizard renders. e.g. '4.7 GB'."""
    if bytes_count < 0:
        return "?"
    gb = bytes_count / 1_000_000_000  # binary GiB or decimal GB — Ollama itself uses decimal in UI
    if gb >= 10:
        return f"{gb:.0f} GB"
    return f"{gb:.1f} GB"


def main() -> int:
    with open(SOURCE_YAML, encoding="utf-8") as f:
        spec = yaml.safe_load(f)
    if not isinstance(spec, dict) or not isinstance(spec.get("models"), list):
        sys.stderr.write(f"error: malformed {SOURCE_YAML}\n")
        return 2

    out: list[dict] = []
    defaults = 0
    for entry in spec["models"]:
        model_id = entry["id"]
        sys.stderr.write(f"  fetching {model_id} ...\n")
        size_bytes = fetch_size_bytes(model_id)
        is_default = bool(entry.get("default", False))
        if is_default:
            defaults += 1
        out.append({
            "id": model_id,
            "size_bytes": size_bytes,
            "size_human": format_size(size_bytes),
            "blurb": entry["blurb"],
            "tier": entry.get("tier", "mid"),
            "default": is_default,
        })

    if defaults != 1:
        sys.stderr.write(
            f"error: exactly one entry must have `default: true`. Got {defaults}.\n"
        )
        return 2

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": "ollama registry via scripts/refresh-models.py",
        "models": out,
    }

    TARGET_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(TARGET_JSON, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
        f.write("\n")
    sys.stderr.write(f"  ✓ wrote {TARGET_JSON.relative_to(ROOT)} ({len(out)} models)\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
