// Seeds a demo workspace via the local HTTP API for visual screenshots.
// Run with: node scripts/seed-demo.mjs

const BASE = process.env.API_BASE ?? 'http://localhost:41821';
const EMAIL = 'demo@example.com';
const PASSWORD = 'Password123!';

let cookie = '';

async function request(path, init = {}) {
  const headers = { 'Content-Type': 'application/json', ...(init.headers ?? {}) };
  if (cookie) headers.Cookie = cookie;
  const r = await fetch(`${BASE}${path}`, { ...init, headers });
  const setCookie = r.headers.get('set-cookie');
  if (setCookie) cookie = setCookie.split(';')[0];
  if (!r.ok && r.status !== 204) {
    throw new Error(`${init.method ?? 'GET'} ${path} -> ${r.status} ${await r.text()}`);
  }
  return r.status === 204 ? null : await r.json();
}

async function main() {
  // Try signup, fall through to login if email is taken.
  try {
    await request('/api/auth/signup', { method: 'POST', body: JSON.stringify({ email: EMAIL, password: PASSWORD }) });
  } catch (e) {
    if (!String(e).includes('409')) throw e;
    await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: EMAIL, password: PASSWORD }) });
  }

  const proj = await request('/api/projects', {
    method: 'POST',
    body: JSON.stringify({ name: 'Launch v2', description: 'Ship the new app', color: '#5e6ad2' }),
  });

  // Labels
  const labels = [];
  for (const [name, color] of [['frontend', '#5e6ad2'], ['bug', '#dc2626'], ['design', '#10b981']]) {
    labels.push(await request(`/api/projects/${proj.id}/labels`, { method: 'POST', body: JSON.stringify({ name, color }) }));
  }

  // 8 issues across all statuses
  const issues = [
    ['Triage inbound bugs',    'low',    'backlog',  1],
    ['Define empty state copy','med',    'todo',     2],
    ['Wire drag and drop',     'urgent', 'started',  5],
    ['Refactor Express router','high',   'started',  8],
    ['PR-1024 review',         'high',   'review',   3],
    ['Add command palette',    'med',    'done',     3],
    ['Ship MVP banner',        'low',    'done',     2],
    ['Old icon set',           'low',    'cancelled',1],
  ];
  const created = [];
  for (const [title, priority, status, estimate] of issues) {
    const t = await request('/api/tasks', {
      method: 'POST',
      body: JSON.stringify({ project_id: proj.id, title, priority, status, estimate }),
    });
    await request(`/api/tasks/${t.id}/labels/${labels[0].id}`, { method: 'POST' });
    created.push(t);
  }

  // Cycle (active today)
  const now = new Date();
  const startD = new Date(now.getTime() - 3 * 86_400_000).toISOString().slice(0, 10);
  const endD = new Date(now.getTime() + 11 * 86_400_000).toISOString().slice(0, 10);
  await request(`/api/projects/${proj.id}/cycles`, { method: 'POST', body: JSON.stringify({ name: 'Sprint 1', start_date: startD, end_date: endD }) });

  // Drawer fixture
  const parent = created.find((t) => /drag/i.test(t.title));
  if (parent) {
    await request('/api/tasks', { method: 'POST', body: JSON.stringify({ project_id: proj.id, parent_id: parent.id, title: 'Mock the DnD events', priority: 'med', estimate: 2 }) });
    await request('/api/tasks', { method: 'POST', body: JSON.stringify({ project_id: proj.id, parent_id: parent.id, title: 'Add column drop zones', priority: 'high', estimate: 3, status: 'done' }) });
    await request(`/api/tasks/${parent.id}/subtasks`, { method: 'POST', body: JSON.stringify({ title: 'Investigate HTML5 dnd events' }) });
    const s = await request(`/api/tasks/${parent.id}/subtasks`, { method: 'POST', body: JSON.stringify({ title: 'Add column drag-over highlight' }) });
    await request(`/api/tasks/${parent.id}/subtasks/${s.id}`, { method: 'PATCH', body: JSON.stringify({ done: true }) });
    const body = [
      '### Design notes',
      '',
      'Use **drop zones** on each column header. See [Linear](https://linear.app) for the reference behavior.',
      '',
      '```ts',
      'function onDrop(e: DragEvent) { ... }',
      '```',
      '',
      '- top border highlight when hovering',
      '- snap card with `border-top-color`',
    ].join('\n');
    const c = await request(`/api/tasks/${parent.id}/comments`, { method: 'POST', body: JSON.stringify({ body }) });
    await request(`/api/tasks/${parent.id}/comments/${c.id}/reactions`, { method: 'POST', body: JSON.stringify({ emoji: '🚀' }) });
    await request(`/api/tasks/${parent.id}/comments/${c.id}/reactions`, { method: 'POST', body: JSON.stringify({ emoji: '👍' }) });
  }

  console.log(`seeded project ${proj.key} (id=${proj.id}) with ${created.length} issues`);
}

main().catch((e) => { console.error(e); process.exit(1); });
