# Security policy

ATLAS is a local-first tool — it runs on your machine, against your
provider keys, and stores its state in `~/.atlas/`. We take the following
seriously:

- **API key storage.** `~/.atlas/config.json` is the only place keys are
  written, with mode 0600 enforced on every save. Bug: anything that writes
  keys somewhere else, or leaves them at a wider permission.
- **Tool execution.** `write_file`, `edit_file`, and `run_command` are
  gated by an interactive permission prompt (OpenClaude-style
  `permission_required` event). Bug: any path that bypasses the gate, or
  any tool that mutates state without being in the `SENSITIVE_TOOLS` set.
- **Dashboard exposure.** `atlas dash` binds loopback-only by default.
  Bug: any default that exposes the server to the LAN.

## Reporting

Email **ryder.wolf@pm.me** with the subject `[atlas security]`. Please
include:

- the version (`atlas version`)
- the platform (`uname -a` or Windows build number)
- a minimal reproduction
- your assessment of severity (low / medium / high / critical)

We'll acknowledge within 72 hours. Public disclosure happens once a fix
is shipped (or 90 days from your report, whichever comes first).

## Supported versions

| Version | Supported |
|---------|-----------|
| `0.1.x` | ✓ — current release line |
| `< 0.1` | ✗ — pre-release prototypes |

## Out of scope

- Issues that require the attacker to already have shell access on the
  user's machine
- Provider-side billing abuse (route concerns to the provider's
  security team — Anthropic / OpenAI / etc.)
