# Agent instructions for ATLAS

Whether you're a human, Claude Code, Cursor, GitHub Copilot, or ATLAS
itself, read this before writing code in this repo.

This file is the single source of truth. `CLAUDE.md`, `.cursor/rules/`,
and `.github/copilot-instructions.md` all defer to this file.

---

## TL;DR — five non-negotiables

1. **Branch off `master`. Open a PR. Never push direct.**
   Branch protection rejects direct pushes; even if it didn't, the
   review step catches mistakes our tests don't.

2. **Conventional commits.** Every commit message starts with one of:
   `feat:`, `fix:`, `chore:`, `ci:`, `docs:`, `refactor:`, `test:`,
   `style:`, `perf:`, `build:`, `revert:`. One logical change per commit.

3. **Don't bump version by hand.** `pyproject.toml`'s `version` field
   and `src/atlas/__init__.py`'s `__version__` are owned by
   `release-please`. It reads conventional commits and bumps both.
   Manual edits to either will be overwritten.

4. **`make smoke` passes before opening the PR.** Catches the
   five-second mistakes before they consume reviewer attention.

5. **The PR template's checklist isn't decorative.** Each line is a
   real gate.

---

## What ATLAS is

ATLAS is a terminal AI harness with a built-in project workspace —
chat-first agent CLI in the spirit of Claude Code / Codex / aider, but
with a Linear-style PMS baked in so humans can manage agents and work
alongside each other in one place.

Shipped surfaces:
- `atlas` — the chat REPL (any cwd)
- `atlas dash` — FastAPI server + React dashboard at `localhost:41821`
- Shared SQLite at `~/.atlas/data.sqlite` for workspaces / issues / cycles

---

## Where things live

```
.
├── src/atlas/                    # the v0.1+ Python package
│   ├── cli/                      # REPL, slash commands, wizard, splash
│   ├── agent/                    # provider runtime, tools, runner
│   ├── repos/                    # SQLite repository layer
│   ├── db/                       # schema + connection
│   ├── dash/                     # FastAPI server + React static
│   └── config/                   # settings + context cascade
├── apps/api/                     # legacy Node Express server (v0.2 removes)
├── apps/web/                     # legacy React frontend (now bundled via dash/)
├── packaging/                    # PyInstaller spec, Homebrew formula
├── .github/                      # workflows, templates, instructions
└── tests/                        # pytest
```

---

## The dev loop

```sh
make bootstrap        # one-time: install python + node deps
make smoke            # quick install + 5-line smoke regression
make build            # rebuild React frontend, copy into src/atlas/dash/static
make wheel            # build pipx-installable wheel
make binary           # PyInstaller standalone (20MB)
```

For everyday work: `./app dev` still launches the legacy Node stack at
`:41821` (API) + `:41822` (web). The Python stack runs via
`pipx install -e . && atlas` or `atlas dash`.

---

## How to add a thing

Each subdirectory has its own AGENTS.md with the local invariants and
step-by-step. Find the closest one to the file you're touching:

- New agent provider, tool, or runtime change → [`src/atlas/agent/AGENTS.md`](src/atlas/agent/AGENTS.md)
- New dashboard route or schema change → [`src/atlas/dash/AGENTS.md`](src/atlas/dash/AGENTS.md)
- New PM repo (DB entity) → cover under `src/atlas/repos/AGENTS.md` (lands when there's a non-obvious case)

Claude Code, Cursor, and ATLAS itself walk the tree from cwd up, so
opening a file under `src/atlas/agent/` pulls in *both* the root
AGENTS.md and the local one automatically.

---

## The PR workflow

```sh
git switch -c feat/short-slug        # or fix/, chore/, docs/, etc.
# edit, edit, edit
git commit -m "feat: one-line summary"
git push -u origin feat/short-slug
gh pr create                          # uses the template
# wait for CI green
gh pr merge --squash                  # or merge via UI
```

CI requires:
- `commitlint` — all commits in the PR pass conventional-commit rules
- `release` (smoke build) — wheel builds, binary builds
- `publish-pypi` (smoke build, not actually publishing on non-tag pushes)

---

## The release flow

You never tag manually. `release-please` watches `master`, reads
commits since the last release, and opens a **"Release PR"** that:

- bumps `pyproject.toml`'s `version`
- bumps `src/atlas/__init__.py`'s `__version__`
- writes new entries to `CHANGELOG.md`

When you merge the Release PR, release-please creates the git tag,
which fires:

- `release.yml` → builds binaries for 4 platforms, attaches them
- `publish.yml` → publishes the wheel to PyPI as `blackdoor-atlas`

A `feat:` commit triggers a minor bump. `fix:` triggers a patch bump.
`feat!:` or `BREAKING CHANGE:` in the body triggers a major bump.
`chore:`, `docs:`, `ci:`, etc. don't trigger releases on their own —
they ride along with the next `feat`/`fix`.

---

## What never to do

- **Push directly to `master`.** Branch protection rejects it; if it
  didn't, your reviewer would.
- **Bump `pyproject.toml` or `__init__.py` version by hand.**
  release-please owns them.
- **Tag manually.** release-please's Release PR does it.
- **Skip the PR template checklist.** Each item is there because we
  got bitten by skipping it once already.
- **Commit secrets.** `~/.atlas/config.json` is the *only* place API
  keys live, and it's chmod 600. `.env*` is in `.gitignore` — keep it
  that way.
- **Commit build artifacts.** `dist/`, `build/`, `src/atlas/dash/static/`,
  `node_modules/`, `*.egg-info/` are all `.gitignore`d. If you find
  yourself adding `git add -f` you're probably wrong.

---

## See also

- [`CONTRIBUTING.md`](CONTRIBUTING.md) — dev environment, debugging, tests
- [`SECURITY.md`](SECURITY.md) — vulnerability reporting
- [`CHANGELOG.md`](CHANGELOG.md) — release-please owns it; never edit by hand
- [`packaging/`](packaging/) — PyInstaller spec, Homebrew formula
