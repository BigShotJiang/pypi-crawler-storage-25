# Architecture

The harness is a single LangGraph runner with tool nodes for terminal, file
operations, git, and Playwright. Specialized subagents (planner/coder/reviewer/
qa) can be added later without changing the contract.

## Package layout

```
harness/
  cli.py                      # entry point: build / inspect / plan / resume / report
  orchestrator/
    graph.py                  # builds the LangGraph state graph
    state.py                  # State TypedDict + reducers
    checkpointer.py           # SQLite checkpointer wrapper
    interrupts.py             # approval interrupt helpers
  nodes/
    ingest.py                 # ingest_goal
    contract.py               # read_repo_contract
    inspect.py                # inspect_workspace
    bootstrap.py              # bootstrap_environment
    plan.py                   # plan_build
    execute.py                # execute_task
    validate_static.py        # run_static_validation
    test_unit.py              # run_unit_tests
    test_integration.py       # run_integration_tests
    test_browser.py           # run_browser_validation
    triage.py                 # triage_failures
    patch.py                  # generate_patch + apply_patch
    retest.py                 # retest after a patch
    approval.py               # request_approval (interrupt)
    finalize.py               # finalize_artifacts
    commit.py                 # commit_changes
    report.py                 # emit_report
  tools/
    terminal.py               # subprocess executor + command log
    files.py                  # safe file IO + patch reports
    git.py                    # branch-level git wrapper
    playwright_driver.py      # Playwright Test driver + MCP client wrapper
  io/
    workflow_loader.py        # YAML workflow loader
    schemas.py                # JSONSchema validators
    reports.py                # markdown/JSON report writers
```

## Graph

```
ingest_goal
  -> read_repo_contract
  -> inspect_workspace
  -> bootstrap_environment
  -> plan_build
  -> execute_task ┐
       ├── run_static_validation
       ├── run_unit_tests
       ├── run_integration_tests
       └── run_browser_validation
              ├── pass  -> next task or finalize_artifacts
              └── fail  -> triage_failures
                            -> generate_patch
                            -> apply_patch
                            -> retest
                                  ├── pass -> back to execute_task
                                  └── budget exhausted -> request_approval
  -> request_approval (when policy-gated)
  -> finalize_artifacts -> commit_changes -> emit_report
```

## State

See `agent/schemas/state.schema.json`. The graph is checkpointed to
`.agent/state/checkpoints.sqlite` so `resume` works after an interrupt or
crash.

## Tool boundaries

- The terminal executor writes a JSONL log line for every command. It captures
  cwd, env subset (redacted), argv, exit code, stdout/stderr paths, duration.
- The file layer is the only writer to the workspace inside the harness; every
  write produces a patch report at `.agent/reports/patch-<timestamp>.md`.
- The git wrapper rejects push/force-push/tag without an approved request.
- The Playwright driver prefers MCP if `.agent/state/mcp.json` lists a
  `playwright` server; otherwise it invokes the Playwright Test runner via
  subprocess and captures traces and screenshots into `.agent/artifacts/`.

## Hooks

Hooks are local automations triggered by graph events; see
`agent/workflows/default-build.yaml` for the wiring and `harness/orchestrator/graph.py`
for the dispatch. Recommended:

- on_file_change: focused lint/typecheck of the changed file's package.
- on_task_complete: write a patch report.
- on_test_failure: invoke `triage_failures`.
- on_service_start: register the health endpoint in `state.services`.
- on_browser_failure: capture screenshot + trace + DOM snapshot.
