# Product spec — dogfood app

The dogfood scenario exercises the harness end to end. The product is a small
full-stack app with one auth flow, one CRUD resource, and one dashboard page.

## Functional requirements

- A user can register with email + password.
- A user can log in and is issued a session cookie.
- An authenticated user can create, list, edit, and delete `notes`
  (`{ id, title, body, created_at }`).
- An authenticated user can view a dashboard page showing their note count.

## Non-functional requirements

- API and web both run locally on a single `npm run dev` invocation at the repo
  root.
- Data persists across restarts in `apps/api/data.sqlite`.
- All routes are typed end to end.
- The site is keyboard-navigable: every interactive control has an accessible
  name so Playwright can act through accessibility snapshots.

## Routes

Frontend (Vite + React):

- `/` — landing page with link to signup or dashboard.
- `/signup` — email/password form.
- `/login` — email/password form.
- `/dashboard` — note count, link to notes.
- `/notes` — list, create, edit, delete.

Backend (Express + better-sqlite3):

- `POST /auth/signup`
- `POST /auth/login`
- `POST /auth/logout`
- `GET  /auth/me`
- `GET  /notes`
- `POST /notes`
- `PATCH /notes/:id`
- `DELETE /notes/:id`
- `GET  /healthz`

## Critical flows

See `tests/browser/critical-flows.yaml`:

1. `landing-page-smoke` — landing renders with welcome and `Get started` link.
2. `signup-flow` — register a fresh email, land on dashboard.
3. `notes-crud` — create a note, edit its title, delete it.
