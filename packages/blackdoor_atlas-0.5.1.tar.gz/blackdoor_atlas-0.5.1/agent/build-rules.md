# Build rules

## Planning rules

- Tasks must be independently verifiable.
- Every task must include a validation method (commands or flow IDs).
- Every task must declare artifacts it changes.
- Large tasks must be decomposed before execution.
- A task that touches the data plane must be paired with a rollback procedure.

## Coding rules

1. Read relevant spec files before editing.
2. Inspect existing code; understand the shape before patching it.
3. Determine the minimal viable patch — no incidental refactors.
4. Edit files through `harness.io.files.write_with_patch_report` so a report is
   written.
5. Run the narrowest validation first (the failing unit test, the focused lint).
6. Expand to broader validation only after narrow validation passes.
7. Record a patch report at `.agent/reports/patch-<timestamp>.md` with: intent,
   files changed, commands run, results, remaining risks.

## Validation rules

Layered:

- **Static**: lint, typecheck, format check, build check.
- **Runtime**: service boot, health endpoints, database connectivity, API smoke.
- **Browser**: critical journeys from `tests/browser/critical-flows.yaml` via
  Playwright. Evidence stored under `.agent/artifacts/`.

## Repair loop

When validation fails:

1. Classify the failure (env/config, missing dep, type mismatch, runtime
   exception, browser selector/flow, state bug, async timing, infra not ready).
2. Identify the nearest relevant files (smallest blast radius).
3. Generate a minimal patch.
4. Apply the patch.
5. Re-run the narrowest failing test first.
6. Re-run the dependent broader tests.
7. If the retry budget for this task is exceeded, escalate via
   `request_approval` with a precise blocking report. Do not loop forever.

## Retry budget

Each task carries a budget. Default values (see
`agent/schemas/state.schema.json` for ground truth):

- `static`: 3 attempts.
- `unit`: 5 attempts.
- `integration`: 4 attempts.
- `browser`: 4 attempts.
- `bootstrap`: 2 attempts per dependency.

When a budget is exhausted, the failing task is moved to `failed_tasks` and the
graph routes to `request_approval`.

## Hygiene rules

- Never use `git push`, force-push, or tag creation without an approval entry.
- Never commit `.env*`, secrets, credentials, or files under
  `.agent/artifacts/screenshots/` unless explicitly added.
- Always update `agent/memory/decisions.md` when making a non-obvious choice and
  `agent/memory/recurring-failures.md` when the same failure pattern appears
  twice.
