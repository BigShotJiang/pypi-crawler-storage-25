# Recurring failures

This file collects failure patterns the harness has seen more than once so the
triage node can match new failures to known fixes.

Entries follow this shape:

```
## <pattern slug>
- Symptoms:
- Classification:
- Known fix:
- Source patches:
```

(Empty on first run; the harness appends as it learns.)
