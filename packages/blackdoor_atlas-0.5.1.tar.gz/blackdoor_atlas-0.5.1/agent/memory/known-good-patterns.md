# Known-good patterns

## Express + better-sqlite3 setup

- Open the DB once at module load.
- Run `CREATE TABLE IF NOT EXISTS` migrations on boot.
- Use prepared statements; do not template SQL strings.

## Vite + React + typed fetch client

- Co-locate the fetch wrapper at `apps/web/src/api.ts`.
- Type API responses with `zod` schemas; reuse those types in the API.

## Playwright in accessibility-snapshot mode

- Prefer `page.getByRole(...)` and `page.getByLabel(...)` over CSS.
- Avoid `waitForTimeout`; wait on a role, text, or URL instead.
- Capture a trace per flow with `test.use({ trace: 'on-first-retry' })`.
