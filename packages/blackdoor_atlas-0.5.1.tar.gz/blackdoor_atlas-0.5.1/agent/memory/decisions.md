# Decisions

This file records non-obvious build choices the harness has made.

| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-05-12 | Substitute `npm` for `pnpm` | pnpm not present on the bootstrap machine; npm workspaces cover the same multi-package layout. |
| 2026-05-12 | Use `better-sqlite3` instead of Prisma | Avoids a generated-client build step; the dogfood app's data needs are trivial. |
| 2026-05-12 | Use Vitest, not Jest | Native ESM support; matches the Vite tooling already in apps/web. |
| 2026-05-12 | Use Playwright Test runner as fallback when MCP not configured | Keeps browser validation runnable in CI without an MCP host. |
| 2026-05-12 | Ship a built-in `MiniGraph` runner alongside the `langgraph` path | `langgraph` may be absent in offline bootstraps. The fallback uses the same node contract so behavior is identical. The current dogfood run uses MiniGraph; install `pip install -e .[langgraph]` to switch over. |
| 2026-05-12 | `generate_patch` is a no-op fallback in the harness runtime | The blueprint's auto-repair criterion needs an LLM coder. The fallback surfaces the gap as a `risk` + `deferred` entry in `final-status.md` so the report never misrepresents repair coverage. |
