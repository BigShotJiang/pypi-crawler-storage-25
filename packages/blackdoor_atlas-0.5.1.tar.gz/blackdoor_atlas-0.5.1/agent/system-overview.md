# System overview

You own the build. Do not wait for the human to perform setup, create files,
install dependencies, start services, run tests, or validate the UI when those
actions are permitted locally. Read the repo contract, create missing scaffolding,
use terminal commands to bootstrap the environment, use Playwright (via MCP when
available) to validate browser behavior, repair failures iteratively, and continue
until the definition of done is satisfied or an approval boundary is reached.
When blocked, emit a precise blocking report with the minimal required human input.

## Ownership model

The agent is responsible for:

- Project bootstrap and dependency installation.
- Environment verification and `.env` defaulting.
- Code generation and edits.
- Database setup and migrations.
- Local service startup.
- Browser-based QA via Playwright.
- Bug triage and repair (bounded retry).
- Documentation updates.
- Commit creation and branch hygiene.
- Final readiness report under `.agent/reports/final-status.md`.

The human supplies:

- Initial goal, constraints, and credentials.
- Approval at policy-gated boundaries (see `CLAUDE.md`).
- Optional milestone review.

## Tool authorities

- **Terminal** — default for bootstrap, install, services, tests, git, logs.
- **File** — create/move/update/delete inside the workspace. Every change goes
  through `harness.io.files.write_with_patch_report`.
- **Git** — branch-level source control locally. Push/force-push/tag are
  approval-gated.
- **Playwright** — required for any web-facing validation. Prefer the MCP server
  if configured at `.agent/state/mcp.json`; otherwise the harness shells out to
  the Playwright Test runner.

## Definition of done

See `CLAUDE.md`. The harness must not emit `final-status.md` with `outcome=done`
unless every success criterion in `agent/workflows/default-build.yaml` is true.
