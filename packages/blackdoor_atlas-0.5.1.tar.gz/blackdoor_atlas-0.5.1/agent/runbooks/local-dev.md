# Local dev runbook

## Prereqs

- Node 20+ (tested on 25).
- Python 3.11+ (tested on 3.14).
- `uv` for Python dependency management.

## Install

```bash
uv sync                    # Python harness deps from pyproject.toml
npm install                # workspace install for apps/web and apps/api
npx playwright install     # browsers for browser validation
```

`./app dev` will run `npm install` itself on first launch when `node_modules/`
is missing, so for a fresh clone the install above is optional.

## Start

```bash
./app                      # default — starts API on :41821 and Web on :41822 together
./app dev                  # same as above; explicit form
./app stop                 # kill leftover dev processes
./app status               # show health of API + Web

npm run dev                # equivalent low-level entry point (concurrently)
```

`./app` prints `READY  web=http://localhost:41822  api=http://localhost:41821/healthz`
once both services have responded. The API serves `/healthz` and the Vite
dev server proxies `/api/*` and `/healthz` to it.

## Tests

```bash
npm run lint               # eslint across workspaces
npm run typecheck          # tsc -b
npm run test               # unit tests (vitest)
npm run test:e2e           # browser tests (playwright)
```

## Database

`apps/api/data.sqlite` is created on first boot by `apps/api/src/db.ts`. Reset:

```bash
rm -f apps/api/data.sqlite && npm --workspace apps/api run dev
```

## Harness

```bash
python -m harness.cli inspect
python -m harness.cli build --goal "Build the dogfood CRUD app"
python -m harness.cli resume        # after an approval
python -m harness.cli report
```
