# Rollback runbook

## Local rollback

If a local build is wedged:

```bash
rm -rf .agent/state/checkpoints.sqlite   # forget checkpoints (loses interrupt state)
git stash push --include-untracked       # park current changes
git checkout main                        # return to known-good
```

Only use destructive flags after confirming with a human.

## Data rollback

`apps/api/data.sqlite` is local-only and can be removed:

```bash
mv apps/api/data.sqlite apps/api/data.sqlite.bak.$(date +%s)
```

The API recreates the schema on next boot.

## Deploy rollback

A deploy rollback follows the same approval gate as deploy. Add the entry to
`.agent/state/approvals.jsonl` with `action: rollback_production` before
running `python -m harness.cli resume`.
