# Deployment runbook

Deployment is approval-gated. The harness never deploys without an entry in
`.agent/state/approvals.jsonl` whose `action` equals `deploy_production` and
whose `status` is `approved`.

## Manual approval flow

1. The agent reaches the `request_approval` node with action `deploy_production`.
2. LangGraph interrupts and the harness writes a pending entry under
   `.agent/state/approvals.jsonl`.
3. A human reviewer appends `{ "id": "<id>", "status": "approved" }` (or
   `rejected`) to the same file.
4. The operator runs `python -m harness.cli resume`.

## Pre-flight checks

Before deploy_production may be approved:

- `npm run lint`, `npm run typecheck`, `npm run test`, `npm run test:e2e` all
  pass in the current branch.
- `.agent/reports/final-status.md` exists and lists no open `Risks`.
- Last commit on the deploy branch is the one being deployed.

## Deploy command (placeholder)

The harness ships without a real deploy target. Wire it under
`scripts/deploy.sh` and reference it here; until then, the deployment path is
intentionally a no-op that records the approval and exits.
