# Plan

_Run goal:_ Build the dogfood CRUD app

## E1 — Scaffold dogfood app
- **T1** Verify dogfood scaffold exists  
  - validation: `check:apps_exist`

## E2 — Validate dogfood app
- **T2** Static checks pass  
  - validation: `npm run lint, npm run typecheck`
- **T3** Unit tests pass  
  - validation: `npm run test`
- **T4** Integration smoke  
  - validation: `smoke:api_health`
- **T5** Critical browser flows  
  - validation: `browser:landing-page-smoke, browser:signup-flow, browser:notes-crud`
