# Autonomous Agent Build Blueprint

This blueprint defines a fully agent-owned software-building system. The agent does not merely assist a human operator; it owns planning, environment setup, implementation, testing, browser automation, validation, repair, and delivery. LangGraph is the primary orchestration layer because it supports persistence, interrupts, and resumable stateful workflows, while Playwright MCP supplies browser automation through structured accessibility snapshots rather than screenshots or pixel guessing.[cite:145][cite:193][cite:203]

The design assumes a coding agent can use terminal commands, file editing, Git, test runners, package managers, and browser automation. The resulting system turns a repository into an executable harness in which the agent can read layered instructions, create files, run commands, open web apps, inspect UIs, repair issues, and continue until the build definition is satisfied.[cite:201][cite:204][cite:197]

## Core principle

The agent has ownership of the build. Human input is optional and should be required only for explicit approval boundaries such as irreversible external side effects, credential entry, or policy-gated production actions. LangGraph persistence and interrupt patterns make that pause-and-resume model reliable instead of prompt-fragile.[cite:145][cite:193]

## System objective

Build a local-first autonomous software factory with these properties:

- Accept a product brief or repo goal.
- Materialize its own workspace, dependencies, and config.
- Read repo instructions from layered markdown files.
- Plan work into tasks, subtasks, and checkpoints.
- Execute implementation with terminal and file tools.
- Use Playwright to validate browser-based behavior end-to-end.[cite:197][cite:203]
- Run tests, linters, and static checks.
- Inspect failures, patch code, and retry.
- Produce artifacts, commit history, logs, and status summaries.
- Request human approval only for high-risk actions via interrupt nodes.[cite:145][cite:195]

## Architecture choice

### Primary framework

Use LangGraph as the backbone. LangGraph provides durable execution state, checkpointing, human-in-the-loop interrupts, and resumable workflows, which are crucial when an agent may spend many steps planning, coding, testing, and repairing a build.[cite:145][cite:193]

### Browser automation

Use Playwright MCP as the browser-action layer. It exposes structured browser tools through MCP, operates on the page accessibility tree, and supports navigation, clicking, typing, screenshots, tracing, video, and more, which is a strong fit for an autonomous agent that must verify UI behavior without manual control.[cite:197][cite:203]

### Repo memory and instruction layer

Use a root `CLAUDE.md`-style contract plus nested directory-level instruction files. Claude Code documents `CLAUDE.md` as persistent project instructions, and its extension model separates always-on context, on-demand workflows, external tools via MCP, and automation hooks.[cite:201][cite:204]

### Optional multi-agent expansion

Do not start with a full multi-agent architecture. First ship a strong single-runner harness with specialized nodes. Later, if needed, add isolated subagents for planning, coding, review, and QA using the same contract model.[cite:201]

## Ownership model

The agent is responsible for:

- Project bootstrap.
- Dependency installation.
- Environment verification.
- Code generation and edits.
- Database setup and migrations.
- Local app startup.
- Browser testing.
- Bug triage and repair.
- Documentation updates.
- Commit creation and branch hygiene.
- Final readiness report.

The human is responsible only for:

- Supplying initial intent, constraints, and credentials.
- Approving guarded actions when policy requires it.
- Optionally reviewing milestones.

## Repo contract

Every autonomous build repo should contain the following structure.

```text
repo/
  CLAUDE.md
  agent/
    system-overview.md
    build-rules.md
    product-spec.md
    architecture.md
    runbooks/
      local-dev.md
      deployment.md
      rollback.md
    workflows/
      default-build.yaml
      bugfix.yaml
      release.yaml
    prompts/
      planner.md
      coder.md
      reviewer.md
      qa.md
    schemas/
      state.schema.json
      task.schema.json
      patch.schema.json
      test-report.schema.json
    memory/
      decisions.md
      recurring-failures.md
      known-good-patterns.md
  apps/
  packages/
  scripts/
  tests/
  .agent/
    state/
    logs/
    artifacts/
    plans/
    reports/
```

### Root instruction file

`CLAUDE.md` should stay concise and route the agent to specialized files. Claude Code guidance emphasizes using `CLAUDE.md` for persistent instructions and pointing to more specific files rather than overloading one monolithic document.[cite:201][cite:204]

Recommended contents:

- Mission of the repo.
- Stack overview.
- Non-negotiable constraints.
- Where detailed docs live.
- How to run tests, lint, typecheck, and dev servers.
- Which actions are approval-gated.
- Definition of done.

## Tool authorities

The agent should treat tools as first-class execution channels, not optional helpers.

### Terminal authority

The terminal is the default tool for:

- Bootstrapping repo state.
- Installing dependencies.
- Running generators.
- Starting services.
- Running tests.
- Using Git.
- Inspecting logs.
- Repairing config.
- Running database commands.

Examples:

```bash
pnpm install
pnpm typecheck
pnpm test
pnpm dev
python -m pytest
uv sync
alembic upgrade head
docker compose up -d
ps aux | grep node
lsof -i :3000
```

### Playwright authority

Playwright MCP is mandatory for any web-facing system because it gives the agent reliable browser automation through structured accessibility snapshots and can run across MCP-compatible clients.[cite:197][cite:203]

Use Playwright for:

- Opening local app URLs.
- Authenticating through forms.
- Clicking through flows.
- Verifying text, buttons, dialogs, tables, and empty states.
- Taking screenshots and traces.
- Reproducing UI bugs.
- Running smoke and regression workflows.

### File authority

The agent may create, move, update, or delete files inside the workspace according to policy. All edits should be logged in patch reports.

### Git authority

The agent owns branch-level source control unless restricted.

Allowed actions:

- `git checkout -b feature/...`
- `git status`
- `git add -A`
- `git commit -m ...`
- `git diff`

Approval-gated by default:

- `git push`
- force-push
- tag creation
- merge to protected branches

## LangGraph execution model

### State object

The graph state should be durable and explicit.

```json
{
  "run_id": "string",
  "goal": "string",
  "repo_root": "string",
  "stack": {
    "frontend": "string",
    "backend": "string",
    "database": "string"
  },
  "task_queue": [],
  "active_task": null,
  "completed_tasks": [],
  "failed_tasks": [],
  "artifacts": [],
  "services": {},
  "test_results": [],
  "ui_results": [],
  "patch_history": [],
  "risks": [],
  "approval_requests": [],
  "decision_log": [],
  "retry_budget": {},
  "status": "planning"
}
```

### Required graph nodes

1. `ingest_goal`
2. `read_repo_contract`
3. `inspect_workspace`
4. `bootstrap_environment`
5. `plan_build`
6. `execute_task`
7. `run_static_validation`
8. `run_unit_tests`
9. `run_integration_tests`
10. `run_browser_validation`
11. `triage_failures`
12. `generate_patch`
13. `apply_patch`
14. `retest`
15. `request_approval`
16. `finalize_artifacts`
17. `commit_changes`
18. `emit_report`

### Graph transitions

```text
ingest_goal
  -> read_repo_contract
  -> inspect_workspace
  -> bootstrap_environment
  -> plan_build
  -> execute_task
  -> run_static_validation
  -> run_unit_tests
  -> run_integration_tests
  -> run_browser_validation
    -> if pass: next task or finalize_artifacts
    -> if fail: triage_failures -> generate_patch -> apply_patch -> retest
  -> request_approval when action is policy-gated
  -> commit_changes
  -> emit_report
```

### Interrupt boundaries

Use LangGraph interrupts for:

- Production deploy.
- Real payment execution.
- External email sending.
- Deleting production data.
- Writing secrets to external systems.
- Opening a PR against a protected repository.

LangChain’s human-in-the-loop guidance explicitly supports interrupt-based approval flows, persisted state, and logged decisions.[cite:145][cite:195]

## Autonomous bootstrap procedure

The agent must be able to set the system up from zero.

### Step 1: inspect machine and repo

```bash
pwd
ls -la
git status || true
node -v || true
pnpm -v || true
python --version || true
uv --version || true
docker --version || true
playwright --version || true
```

Capture the output into `.agent/reports/environment-check.md`.

### Step 2: infer or create project scaffold

If repo exists:
- Read `package.json`, `pyproject.toml`, `docker-compose.yml`, `README.md`, `CLAUDE.md`, and `agent/workflows/default-build.yaml` if present.

If repo does not exist:
- Create scaffold according to product spec.
- Generate `CLAUDE.md`, `agent/` docs, scripts, and base app directories.

### Step 3: install dependencies

Examples:

```bash
pnpm install
pnpm exec playwright install
uv sync
pip install -r requirements.txt
```

### Step 4: set up environment files

The agent should:
- Copy `.env.example` to `.env.local` when safe.
- Fill non-secret defaults.
- Mark unresolved secrets as blocked inputs.
- Never invent credentials.

### Step 5: initialize data plane

Examples:

```bash
docker compose up -d postgres redis
pnpm prisma migrate dev
alembic upgrade head
pnpm db:seed
```

### Step 6: start local services

The agent should start required services in background-managed processes and record PIDs, ports, and health endpoints.

Examples:

```bash
pnpm dev > .agent/logs/frontend.log 2>&1 &
uvicorn app.main:app --reload > .agent/logs/backend.log 2>&1 &
```

### Step 7: verify readiness

Read logs, ping local URLs, and confirm service health before beginning browser validation.

## Playwright setup contract

The system should configure Playwright MCP as a required external tool for browser work. Playwright MCP supports navigation, filling forms, clicking controls, mocking APIs, screenshots, tracing, and connection to existing browsers or channels such as Chrome through CDP.[cite:197][cite:203][cite:206]

### Standard MCP config

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest"]
    }
  }
}
```

### Alternative config for existing browser session

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest", "--cdp-endpoint=chrome"]
    }
  }
}
```

This channel-based mode is useful when the agent needs to reuse a logged-in browser or existing session context.[cite:206]

## Build workflow file

A workflow file should tell the agent exactly how to execute a build from brief to delivery.

Example `agent/workflows/default-build.yaml`:

```yaml
name: default-build
objective: Build the product to a working local state and verify through tests and browser automation.
entrypoint: ingest_goal
approval_gates:
  - deploy_production
  - send_external_email
  - write_external_secrets
success_criteria:
  - all_required_files_exist
  - lint_passes
  - typecheck_passes
  - unit_tests_pass
  - critical_browser_flows_pass
  - report_emitted
steps:
  - read_repo_contract
  - inspect_workspace
  - bootstrap_environment
  - plan_build
  - execute_task
  - run_static_validation
  - run_unit_tests
  - run_integration_tests
  - run_browser_validation
  - triage_failures
  - generate_patch
  - apply_patch
  - retest
  - finalize_artifacts
  - commit_changes
  - emit_report
```

## Planning contract

The planner node converts the goal into a machine-executable plan.

### Planning output schema

```json
{
  "epics": [
    {
      "id": "E1",
      "title": "Bootstrap app shell",
      "tasks": [
        {
          "id": "T1",
          "title": "Create frontend scaffold",
          "depends_on": [],
          "definition_of_done": [
            "App boots locally",
            "Health route responds"
          ],
          "validation": [
            "pnpm lint",
            "pnpm test",
            "browser smoke"
          ]
        }
      ]
    }
  ]
}
```

### Planning rules

- Tasks must be independently verifiable.
- Every task must include a validation method.
- Every task must declare artifacts it changes.
- Large tasks must be decomposed before execution.

## Coding contract

The coder node should follow this loop:

1. Read relevant spec files.
2. Inspect existing code.
3. Determine minimal viable patch.
4. Edit files.
5. Run narrow validation first.
6. Expand to broader validation.
7. Record patch report.

Patch reports go to `.agent/reports/patch-<timestamp>.md` and should include:

- Intent.
- Files changed.
- Commands run.
- Results.
- Remaining risks.

## Validation contract

Validation should occur in layers.

### Static checks

- Lint.
- Typecheck.
- Formatting check.
- Build check.

### Runtime checks

- Service boot.
- Health endpoints.
- Database connectivity.
- API smoke tests.

### Browser checks

Playwright should verify at least:

- App loads.
- Primary nav renders.
- Critical form flow works.
- Success and failure states render.
- No blocking console/runtime errors in the core journey.

Playwright MCP is suitable here because it lets the model navigate and interact via accessibility snapshots and structured element references.[cite:197][cite:203]

## Repair loop

When validation fails, the agent should not jump into broad rewrites. Use a disciplined triage loop.

1. Classify failure.
2. Identify nearest relevant files.
3. Generate a minimal patch.
4. Apply patch.
5. Re-run the narrowest failing test first.
6. Re-run dependent broader tests.
7. Stop if retry budget exceeded and escalate.

### Failure classes

- Environment/config failure.
- Missing dependency.
- Type/schema mismatch.
- Runtime exception.
- Browser selector or UI flow failure.
- State management bug.
- Async timing issue.
- Infra/service not ready.

## Browser-driven autonomous QA

For every web app build, define critical journeys in machine-readable form.

Example `tests/browser/critical-flows.yaml`:

```yaml
flows:
  - id: landing-page-smoke
    start_url: http://localhost:3000
    steps:
      - assert_text: "Welcome"
      - click_role:
          role: link
          name: "Get started"
      - assert_url_contains: "/signup"
  - id: signup-flow
    start_url: http://localhost:3000/signup
    steps:
      - fill_label:
          label: "Email"
          value: "test@example.com"
      - fill_label:
          label: "Password"
          value: "Password123!"
      - click_role:
          role: button
          name: "Create account"
      - assert_text: "Account created"
```

The agent should translate these into Playwright actions or MCP tool invocations, capture outcomes, and store evidence in `.agent/artifacts/browser/`.

## Hooks and automation triggers

Claude Code’s extension model documents hooks as lifecycle-triggered automation that can run scripts, prompts, subagents, or HTTP requests, making them a useful analogy for harness triggers.[cite:201]

Recommended local harness hooks:

- On file change: run focused lint/typecheck.
- On task completion: write patch report.
- On test failure: invoke triage node.
- On service start: register health endpoint.
- On browser failure: capture screenshot, trace, and DOM snapshot.

## Safety policy

Autonomy does not mean unlimited permissions.

### Safe-by-default allowed actions

- Read/write workspace files.
- Run local package managers.
- Start and stop local services.
- Run local tests.
- Use local browser automation.
- Create local branches and commits.

### Approval-required actions

- Access production infrastructure.
- Use paid third-party APIs beyond configured limit.
- Send external communications.
- Delete non-local data.
- Push to protected remotes.
- Deploy to customer-facing environments.

### Secret handling rules

- Read secrets only from approved env files or secret managers.
- Never fabricate secret values.
- Redact secrets in logs and reports.
- Keep logs under `.agent/logs/` with filtered output.

## Observability

The harness should create its own audit trail.

Required outputs:

- `.agent/reports/environment-check.md`
- `.agent/reports/plan.md`
- `.agent/reports/task-status.json`
- `.agent/reports/test-summary.md`
- `.agent/reports/browser-summary.md`
- `.agent/reports/final-status.md`
- `.agent/logs/*.log`
- `.agent/artifacts/screenshots/*`
- `.agent/artifacts/traces/*`

## Definition of done

The build is complete only when:

- Required files and services exist.
- Local setup is reproducible from documented commands.
- Static checks pass.
- Unit and integration tests pass, or approved exceptions are documented.
- Critical browser flows pass with evidence.
- Open risks are listed.
- Final status report is emitted.
- Changes are committed locally.

## Final status report template

```md
# Final status

## Goal
<original goal>

## Outcome
- Completed:
- Blocked:
- Deferred:

## Environment
- Frontend URL:
- Backend URL:
- Database:

## Validation
- Lint:
- Typecheck:
- Unit tests:
- Integration tests:
- Browser flows:

## Artifacts
- Screenshots:
- Traces:
- Logs:

## Risks
- 

## Next action
- 
```

## Build order for an implementation agent

An implementation agent building this harness should follow this exact order:

1. Create repo scaffolding and instruction files.
2. Implement LangGraph state schema and graph skeleton.
3. Implement terminal executor and command logging.
4. Implement file mutation layer and patch reports.
5. Implement workflow loader and YAML plan parsing.
6. Implement environment bootstrap node.
7. Implement test runner abstraction.
8. Implement Playwright MCP integration for browser validation.[cite:197][cite:203]
9. Implement retry and repair loop.
10. Implement approval interrupts using LangGraph persistence.[cite:145][cite:193]
11. Implement reporting and artifact storage.
12. Run end-to-end self-hosted dogfood test on a sample app.

## Recommended dogfood scenario

Use the harness to build a small full-stack sample app from scratch:

- Next.js or Vite frontend.
- Python or Node backend.
- SQLite or Postgres database.
- One auth flow.
- One CRUD resource.
- One dashboard page.
- One Playwright smoke suite.

The harness passes the dogfood test only if it can:

- Scaffold the app.
- Install dependencies.
- Start services.
- Run migrations.
- Open the browser.
- Create a test account.
- Complete the CRUD flow.
- Fix at least one induced bug automatically.

## Direct instruction block for the agent

Use the following operational mandate inside the system prompt or root instruction file:

> You own the build. Do not wait for the human to perform setup, create files, install dependencies, start services, run tests, or validate the UI when those actions are permitted locally. Read the repo contract, create missing scaffolding, use terminal commands to bootstrap the environment, use Playwright MCP to validate browser behavior, repair failures iteratively, and continue until the definition of done is satisfied or an approval boundary is reached. When blocked, emit a precise blocking report with the minimal required human input.

## Practical recommendation

For this project, keep the architecture centered on one autonomous LangGraph-driven build runner with tool nodes for terminal, file operations, Git, and Playwright. That gets the ownership model right first. Add specialized subagents only after the single-runner harness proves it can bootstrap, build, test, and repair a real app end to end.[cite:193][cite:201][cite:203]
