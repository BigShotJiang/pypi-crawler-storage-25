# Changelog

All notable changes to ATLAS are recorded here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versioning is [SemVer](https://semver.org/).

## [0.5.1](https://github.com/ryderderder/atlas-cli/compare/v0.5.0...v0.5.1) (2026-05-13)


### Bug fixes

* **repl:** shift+tab now cycles mode, matching the toolbar label ([#14](https://github.com/ryderderder/atlas-cli/issues/14)) ([a86a5ac](https://github.com/ryderderder/atlas-cli/commit/a86a5ac44174e153ef186b4bd7b28de3f0cef2f0))

## [0.5.0](https://github.com/ryderderder/atlas-cli/compare/v0.4.1...v0.5.0) (2026-05-13)


### Features

* **repl:** Claude-Code-style bottom chrome, separator, prompt prefix ([#12](https://github.com/ryderderder/atlas-cli/issues/12)) ([4d3aa87](https://github.com/ryderderder/atlas-cli/commit/4d3aa8742137dbb7082a28e5d4e9a9778df3c17c))

## [0.4.1](https://github.com/ryderderder/atlas-cli/compare/v0.4.0...v0.4.1) (2026-05-13)


### Bug fixes

* **prompt:** drop filter=None from slash-popup binding ([#9](https://github.com/ryderderder/atlas-cli/issues/9)) ([#10](https://github.com/ryderderder/atlas-cli/issues/10)) ([13ddd7f](https://github.com/ryderderder/atlas-cli/commit/13ddd7fc84fde12b0a1c44fc3ec38c3e49d3e60a))

## [0.4.0](https://github.com/ryderderder/atlas-cli/compare/v0.3.0...v0.4.0) (2026-05-13)


### Features

* **splash:** hero ATLAS wordmark with gradient + animated reveal ([#6](https://github.com/ryderderder/atlas-cli/issues/6)) ([2c41991](https://github.com/ryderderder/atlas-cli/commit/2c419914a664cf4db9e63df8ea670661ef9c93d2))

## [0.3.0](https://github.com/ryderderder/atlas-cli/compare/v0.2.0...v0.3.0) (2026-05-13)


### Features

* **repl:** live spinner, tool cards, thinking blocks, end-of-turn summary ([#4](https://github.com/ryderderder/atlas-cli/issues/4)) ([88e6073](https://github.com/ryderderder/atlas-cli/commit/88e60736a6566e901b4d5256c4ca8d8711cc1f18))
* **wizard:** arrow-key navigation + slash-command popup ([#3](https://github.com/ryderderder/atlas-cli/issues/3)) ([d943e1c](https://github.com/ryderderder/atlas-cli/commit/d943e1c368087de38b798e1d12e1d109bdb8158a))

## [0.2.0](https://github.com/ryderderder/atlas-cli/compare/v0.1.5...v0.2.0) (2026-05-13)


### Features

* **cli:** /init /model /provider slash commands ([9956dc9](https://github.com/ryderderder/atlas-cli/commit/9956dc908596370af53381033e3b16d22e7f6deb))
* **cli:** atlas uninstall — interactive cleanup before pipx uninstall ([f611ff8](https://github.com/ryderderder/atlas-cli/commit/f611ff834bf93808f0f2cdff74a7c1be88999e3f))
* richer installer — live catalog, RAM guard, env reuse, slash commands, uninstall ([9a8946d](https://github.com/ryderderder/atlas-cli/commit/9a8946da5dd37656b1c70def186ee5af07125fda))
* **wizard:** richer installer — live catalog, RAM guard, env reuse, verify ([9e317b8](https://github.com/ryderderder/atlas-cli/commit/9e317b8204f7f73b4a1f8844f32b25e932aee9c2))

## [Unreleased]

_Working toward `v0.2`. Tracked work:_

- Drop the legacy TypeScript backend now that the Python port is at parity.
- Subtasks / comments / reactions / activity routes in FastAPI (CLI already has them).
- File-history journal exposed in the dashboard task drawer (Claw-style).
- Plandex-style sandbox mode: stage agent writes, batched approval.

---

## [0.1.0] — 2026-05-13

Initial public release. A terminal AI harness with a built-in
project workspace; install via `pipx install blackdoor-atlas` or grab a single-file
binary from the GitHub Release.

### Added

- **CLI** — `atlas` command. Splash, slash commands, history, session
  resume, scope toggle via Shift+Tab, polished bottom status line.
- **Agent runtime** — Python port of the dogfood TypeScript runner:
  - Providers: Anthropic, OpenAI / Ollama / LM Studio / vLLM /
    OpenRouter / Together, Claude OAuth (macOS Keychain), Mock.
  - Tools: `list_dir`, `read_file`, `write_file`, `edit_file`, `search`,
    `run_command`, `memory`, `session_search`, and workspace-scoped
    `list_projects`, `list_tasks`, `create_task`, `update_task`.
  - OpenClaude-style `permission_required` gate with REPL `y/N/m` prompt
    and a Plandex-flavored diff preview.
  - Hermes-style frozen memory snapshots (`memory.md` + `user.md`).
  - FTS5 search across prior session transcripts (`session_search` tool).
  - Aider-style repo map.
- **PM workspace** — multi-tenant Linear-style PMS in `~/.atlas/data.sqlite`:
  workspaces / projects / issues / cycles / labels / templates / saved views,
  with auto-seeded Personal + Demo Co on first run.
- **Web dashboard** — `atlas dash` spawns a FastAPI server with the same
  JSON contracts as the TS prototype; ships the React board / list / drawer
  embedded in the wheel and the standalone binary.
- **Context cascade** — system prompt fold-in order: harness base →
  `~/.atlas/ATLAS.md` → memory + user → cwd `AGENTS.md` / `CLAUDE.md` /
  `ATLAS.md` → repo map.
- **Settings** — `~/.atlas/config.json` (atomic writes), `atlas init`
  provider wizard, `atlas config get|set|list`.
- **Distribution** — wheel for `pipx`, single-file PyInstaller binary,
  GitHub Actions release workflow for macOS arm64 / x86_64, linux x86_64,
  windows; Homebrew formula template.

### Notes

- The legacy Node `apps/api` + React `apps/web` stack is retained in-tree
  for reference and continues to work via `./app dev`, but ATLAS itself
  no longer depends on it. v0.2 removes them.

[Unreleased]: https://github.com/ryderderder/atlas-cli/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/ryderderder/atlas-cli/releases/tag/v0.1.0
