# Homebrew formula for ATLAS.
#
# Goes in a separate tap repo: github.com/<user>/homebrew-atlas
# Install path: `brew tap <user>/atlas && brew install atlas-cli`
#
# Day 14 publishes v0.1.0; that release URL + sha256 plug in below before
# pushing the formula to the tap repo. The placeholder values let `brew
# audit` pass against the file shape, but actual install requires the
# real values.

class AtlasCli < Formula
  desc "Terminal AI harness with a built-in project workspace"
  homepage "https://github.com/ryderderder/atlas-cli"
  license "Apache-2.0"
  version "0.1.0"

  if Hardware::CPU.arm?
    url "https://github.com/ryderderder/atlas-cli/releases/download/v#{version}/atlas-macos-arm64"
    sha256 "TODO_SHA256_ARM64"
  else
    url "https://github.com/ryderderder/atlas-cli/releases/download/v#{version}/atlas-macos-x86_64"
    sha256 "TODO_SHA256_X86_64"
  end

  def install
    binary = Hardware::CPU.arm? ? "atlas-macos-arm64" : "atlas-macos-x86_64"
    bin.install binary => "atlas"
  end

  test do
    # Sanity — version banner without booting providers.
    assert_match "atlas 0.1", shell_output("#{bin}/atlas version")
  end
end
