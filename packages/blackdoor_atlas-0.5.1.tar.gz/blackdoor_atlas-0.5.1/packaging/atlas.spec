# PyInstaller spec for the standalone `atlas` binary.
#
# Run via:   pyinstaller --noconfirm packaging/atlas.spec
# Output:    dist/atlas  (single-file, no Python install required)
#
# Key choices:
#   - `--onefile`-style: everything zipped into one executable. Slightly
#     slower cold start than a directory bundle but the user only needs to
#     drop one file on PATH.
#   - `collect_submodules` on every dynamically-imported provider SDK so
#     the lazy `from anthropic import Anthropic` calls inside our provider
#     classes don't trip a missing-module error at runtime.
#   - The React static build is added via `datas` so the dashboard has a
#     frontend to serve.

# -*- mode: python ; coding: utf-8 -*-

import os
from PyInstaller.utils.hooks import collect_submodules, collect_data_files


# Project root resolved against the spec file's location so `pyinstaller
# packaging/atlas.spec` works from anywhere.
ROOT = os.path.abspath(os.path.join(os.path.dirname(SPEC), os.pardir))


# --- hidden imports --------------------------------------------------------
# PyInstaller's static analysis misses anything imported inside a function
# body or via `importlib`. The provider SDKs all do dynamic registration of
# their submodules, so we pull in the whole tree.
hiddenimports = []
for pkg in ("anthropic", "openai", "httpx", "uvicorn", "uvicorn.workers",
            "uvicorn.protocols", "uvicorn.protocols.http",
            "uvicorn.protocols.websockets", "uvicorn.lifespan",
            "uvicorn.loops", "fastapi", "starlette", "sse_starlette",
            "pydantic", "pydantic_core", "prompt_toolkit"):
    try:
        hiddenimports.extend(collect_submodules(pkg))
    except Exception:
        pass


# --- bundled data files ---------------------------------------------------
# React build → bundled at runtime under sys._MEIPASS/atlas/dash/static.
datas = []
static_src = os.path.join(ROOT, "src", "atlas", "dash", "static")
if os.path.isdir(static_src):
    datas.append((static_src, "atlas/dash/static"))


a = Analysis(
    [os.path.join(ROOT, "src", "atlas", "__main__.py")],
    pathex=[os.path.join(ROOT, "src")],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Trim some heavy optional deps that aren't on our import path.
        # If a provider needs something here at runtime, drop it from this
        # list and rebuild.
        "tkinter", "matplotlib", "PIL", "numpy", "scipy", "pandas",
    ],
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="atlas",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
