# ATLAS — Claude Code instructions

The authoritative rules live in [`AGENTS.md`](AGENTS.md). Claude Code
includes that file directly via the line below.

@AGENTS.md
