//! Resilient wrappers for `ChatModel`. Wraps any provider with retry + jittered
//! exponential backoff via the `backon` crate.
//!
//! # What gets retried
//!
//! - `Error::RateLimited` (429) — retried, honors the upstream `retry_after_ms`
//!   when present.
//! - `Error::Timeout` — retried.
//! - `Error::Provider(s)` where `s` matches a 5xx status pattern — retried.
//!
//! Everything else (bad request, parse error, invalid input, tool failure,
//! cancellation) is treated as terminal and returned to the caller without
//! retries — replays would just waste tokens / propagate the bug.
//!
//! # Streaming
//!
//! `stream()` is NOT retried (token streams can't restart cleanly mid-stream).
//! For streaming retries, capture the failure at the consumer layer and re-call.

use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use backon::{ExponentialBuilder, Retryable};
use litgraph_core::model::ChatStream;
use litgraph_core::{
    hedged_call, Bulkhead, ChatModel, ChatOptions, ChatResponse, CircuitBreaker, CircuitCallError,
    ContentPart, Counter, Embeddings, Error, Gauge, Histogram, KeyedMutex, Message,
    MetricsRegistry, PiiScrubber, RateLimiter, Result, Singleflight,
};
use tracing::{debug, warn};

#[derive(Debug, Clone)]
pub struct RetryConfig {
    pub min_delay: Duration,
    pub max_delay: Duration,
    pub factor: f32,
    pub max_times: usize,
    /// If true, jitter the delay (recommended in production to avoid thundering herds).
    pub jitter: bool,
}

impl Default for RetryConfig {
    fn default() -> Self {
        Self {
            min_delay: Duration::from_millis(200),
            max_delay: Duration::from_secs(30),
            factor: 2.0,
            max_times: 5,
            jitter: true,
        }
    }
}

impl RetryConfig {
    fn to_builder(&self) -> ExponentialBuilder {
        let mut b = ExponentialBuilder::default()
            .with_min_delay(self.min_delay)
            .with_max_delay(self.max_delay)
            .with_factor(self.factor)
            .with_max_times(self.max_times);
        if self.jitter { b = b.with_jitter(); }
        b
    }
}

/// Classify an `Error` as transient (retry) vs terminal (give up).
fn is_transient(e: &Error) -> bool {
    match e {
        Error::RateLimited { .. } => true,
        Error::Timeout => true,
        Error::Provider(msg) => {
            // Match common 5xx / connection-reset patterns. Conservative: only
            // retry when we're confident the upstream might be at fault.
            let m = msg.to_ascii_lowercase();
            m.contains("500 ")
                || m.contains("502 ")
                || m.contains("503 ")
                || m.contains("504 ")
                || m.contains("connection reset")
                || m.contains("connection closed")
                || m.contains("connect error")
                || m.contains("send: ")  // reqwest send failure pre-status
        }
        _ => false,
    }
}

pub struct RetryingChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub cfg: RetryConfig,
}

impl RetryingChatModel {
    pub fn new(inner: Arc<dyn ChatModel>, cfg: RetryConfig) -> Self {
        Self { inner, cfg }
    }
}

#[async_trait]
impl ChatModel for RetryingChatModel {
    fn name(&self) -> &str { self.inner.name() }

    async fn invoke(&self, messages: Vec<Message>, opts: &ChatOptions) -> Result<ChatResponse> {
        let inner = self.inner.clone();
        let backoff = self.cfg.to_builder();
        let messages = messages;
        let result = (|| {
            let inner = inner.clone();
            let messages = messages.clone();
            let opts = opts.clone();
            async move { inner.invoke(messages, &opts).await }
        })
        .retry(&backoff)
        .when(|e: &Error| {
            let retry = is_transient(e);
            if retry {
                debug!(error = %e, "retrying transient error");
            } else {
                warn!(error = %e, "terminal error — not retrying");
            }
            retry
        })
        .await;
        result
    }

    async fn stream(&self, messages: Vec<Message>, opts: &ChatOptions) -> Result<ChatStream> {
        // Don't retry streams. See module doc.
        self.inner.stream(messages, opts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Rate limiting
// ─────────────────────────────────────────────────────────────────────────────

/// Token-bucket rate limit config — two knobs only:
/// `requests_per_minute` (steady-state rate) and `burst` (max bucket capacity,
/// i.e. how much credit accumulates during idle periods). For a strict
/// non-bursty limit, set `burst = 1`.
#[derive(Debug, Clone, Copy)]
pub struct RateLimitConfig {
    pub requests_per_minute: u32,
    pub burst: u32,
}

impl RateLimitConfig {
    pub fn per_minute(rpm: u32) -> Self {
        Self { requests_per_minute: rpm, burst: rpm.max(1) }
    }
    pub fn with_burst(mut self, b: u32) -> Self {
        self.burst = b.max(1);
        self
    }
}

struct BucketState {
    tokens: f64,
    last_refill: std::time::Instant,
}

/// Provider-agnostic token-bucket rate limiter. Each `invoke` / `stream` call
/// acquires one token; if the bucket is empty, the caller awaits until enough
/// time has passed for the next token to refill. Acquisitions are serialized
/// via a `tokio::sync::Mutex` so concurrent invokes form a fair queue.
pub struct RateLimitedChatModel {
    pub inner: Arc<dyn ChatModel>,
    refill_per_sec: f64,
    capacity: f64,
    state: tokio::sync::Mutex<BucketState>,
}

impl RateLimitedChatModel {
    pub fn new(inner: Arc<dyn ChatModel>, cfg: RateLimitConfig) -> Self {
        let refill_per_sec = (cfg.requests_per_minute as f64) / 60.0;
        let capacity = cfg.burst as f64;
        Self {
            inner,
            refill_per_sec,
            capacity,
            state: tokio::sync::Mutex::new(BucketState {
                tokens: capacity,           // start full so the first call is immediate
                last_refill: std::time::Instant::now(),
            }),
        }
    }

    async fn acquire(&self) {
        if self.refill_per_sec <= 0.0 {
            return; // rate limit = ∞ => no-op
        }
        let mut state = self.state.lock().await;
        let now = std::time::Instant::now();
        let elapsed = now.duration_since(state.last_refill).as_secs_f64();
        state.tokens = (state.tokens + elapsed * self.refill_per_sec).min(self.capacity);
        state.last_refill = now;
        if state.tokens >= 1.0 {
            state.tokens -= 1.0;
            return;
        }
        // Hold the lock across the sleep so the queue is FIFO.
        let deficit = 1.0 - state.tokens;
        let wait = Duration::from_secs_f64(deficit / self.refill_per_sec);
        tokio::time::sleep(wait).await;
        state.tokens = 0.0;
        state.last_refill = std::time::Instant::now();
    }
}

#[async_trait]
impl ChatModel for RateLimitedChatModel {
    fn name(&self) -> &str { self.inner.name() }

    async fn invoke(&self, messages: Vec<Message>, opts: &ChatOptions) -> Result<ChatResponse> {
        self.acquire().await;
        self.inner.invoke(messages, opts).await
    }

    async fn stream(&self, messages: Vec<Message>, opts: &ChatOptions) -> Result<ChatStream> {
        self.acquire().await;
        self.inner.stream(messages, opts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Cross-provider fallback
// ─────────────────────────────────────────────────────────────────────────────

/// Chat model wrapper that tries a chain of inner models in order. On
/// transient failure (rate-limit / timeout / 5xx) — or any error if
/// `fall_through_on_all` is true — moves to the next model. The LAST
/// model's error is propagated to the caller.
///
/// LangChain `Runnable.with_fallbacks([backup1, backup2])` parity. Real
/// prod patterns:
/// - **Provider failover**: GPT-4 primary, Claude backup, Gemini tertiary.
///   When OpenAI has an outage, requests transparently route to Anthropic.
/// - **Cost shedding**: GPT-4 primary, GPT-3.5 backup. On rate-limit,
///   degrade to the cheaper model rather than block the user.
/// - **Region failover**: us-east primary, us-west backup. On region
///   outage, re-route within minutes.
///
/// # When to use vs `RetryingChatModel`
///
/// - `RetryingChatModel`: same provider, retry transient errors with
///   exponential backoff. Use for "OpenAI 429s — try again in 500ms".
/// - `FallbackChatModel`: DIFFERENT provider, immediate switch. Use for
///   "OpenAI is down — try Anthropic right now". Compose them: wrap
///   each inner provider in `RetryingChatModel`, then wrap the chain in
///   `FallbackChatModel`.
///
/// # Streaming
///
/// `stream()` only tries the FIRST inner model — token streams can't
/// gracefully fail-over mid-stream once the first chunk arrives. For
/// streaming with fallback, capture the failure pre-stream-start at the
/// consumer layer and re-call.
pub struct FallbackChatModel {
    /// Ordered list of providers. First is primary; rest are backups.
    pub inners: Vec<Arc<dyn ChatModel>>,
    /// If true, fall through on ANY error (not just transient ones).
    /// Default false — preserves the "bad request → fail fast" semantics
    /// of `RetryingChatModel`.
    pub fall_through_on_all: bool,
}

impl FallbackChatModel {
    /// Build a fallback chain. Panics if `inners` is empty (a chain with
    /// no providers can't satisfy any request).
    pub fn new(inners: Vec<Arc<dyn ChatModel>>) -> Self {
        assert!(
            !inners.is_empty(),
            "FallbackChatModel: chain must have at least one model"
        );
        Self {
            inners,
            fall_through_on_all: false,
        }
    }

    /// Configure to fall through on every error (4xx and parse failures
    /// included). Use when the backup providers are TRULY equivalent
    /// substitutes; default `false` is safer because a malformed request
    /// against provider A will likely fail the same way against provider B.
    pub fn fall_through_on_all(mut self) -> Self {
        self.fall_through_on_all = true;
        self
    }
}

#[async_trait]
impl ChatModel for FallbackChatModel {
    fn name(&self) -> &str {
        // Names of every backed model would be churn; use a stable label.
        "fallback"
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let last_idx = self.inners.len() - 1;
        let mut last_err: Option<Error> = None;
        for (i, inner) in self.inners.iter().enumerate() {
            match inner.invoke(messages.clone(), opts).await {
                Ok(resp) => {
                    if i > 0 {
                        debug!(
                            primary_failed = %last_err.as_ref().map(|e| e.to_string()).unwrap_or_default(),
                            fallback_idx = i,
                            "fallback succeeded"
                        );
                    }
                    return Ok(resp);
                }
                Err(e) => {
                    let should_fall = self.fall_through_on_all || is_transient(&e);
                    if i == last_idx || !should_fall {
                        // Last model failed OR error is terminal — propagate.
                        warn!(model_idx = i, error = %e, "FallbackChatModel exhausted or terminal");
                        return Err(e);
                    }
                    debug!(model_idx = i, error = %e, "FallbackChatModel falling through");
                    last_err = Some(e);
                }
            }
        }
        unreachable!("loop returns or sets last_err on every iteration");
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // Only first model. See module doc.
        self.inners[0].stream(messages, opts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RaceChatModel — concurrent invoke, first-success-wins
// ─────────────────────────────────────────────────────────────────────────────

/// Invokes N inner `ChatModel`s **concurrently**, returns the first one
/// that succeeds. Outstanding invocations are aborted as soon as a
/// winner emerges.
///
/// Use this when latency matters more than cost: paying for N parallel
/// requests buys you `min(t_1, .., t_N)` end-to-end. Typical patterns:
///
/// - Multi-region failover where the request hedges across regions
///   instead of waiting for one to time out.
/// - Latency-critical paths backed by both a fast cheap model and a
///   slow strong model — race them and take whichever finishes first.
/// - Cross-provider speculative serving (OpenAI + Anthropic +
///   Bedrock) for tail-latency reduction.
///
/// # Cost model
///
/// All N requests are *issued*. Cancellation aborts the in-flight
/// future, but providers have already begun processing — most bill for
/// any tokens generated before the connection closes. Budget for
/// `cost_floor ≈ N × p50_inference_cost` even though latency is `p_min`.
///
/// # Failure
///
/// Returns `Ok` as soon as **any** inner returns `Ok`. Returns `Err`
/// only if **every** inner fails — error message aggregates all
/// failures (newline-separated) so the caller can debug.
///
/// # Streaming
///
/// `stream()` falls through to `inners[0]`. Racing token streams is
/// possible (race for first chunk, then commit) but inviting in
/// practice — providers' first chunks vary wildly in latency and
/// quality, and switching mid-stream is impossible. Consumers who
/// need it can race `invoke()` calls themselves.
///
/// # Composition
///
/// `Race(Retry(A), Retry(B))` is the typical shape — let each branch
/// handle its own transient errors, race the steady-state outcomes.
/// Avoid `Race(Race(A,B), C)` — flatten the chain into a single
/// `Race(A, B, C)` so cancellation works across the whole set.
///
/// ```ignore
/// use std::sync::Arc;
/// use litgraph_resilience::RaceChatModel;
/// let race = RaceChatModel::new(vec![openai_arc, anthropic_arc, bedrock_arc]);
/// // First to return wins; the other two are aborted.
/// let resp = race.invoke(messages, &opts).await?;
/// ```
pub struct RaceChatModel {
    pub inners: Vec<Arc<dyn ChatModel>>,
}

impl RaceChatModel {
    /// Build a race set. Panics if `inners` is empty (a race with no
    /// runners can't yield a winner).
    pub fn new(inners: Vec<Arc<dyn ChatModel>>) -> Self {
        assert!(
            !inners.is_empty(),
            "RaceChatModel: need at least one inner model",
        );
        Self { inners }
    }
}

#[async_trait]
impl ChatModel for RaceChatModel {
    fn name(&self) -> &str {
        "race"
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        use tokio::task::JoinSet;

        // Single-inner shortcut keeps the spawn-overhead off the hot
        // path for users who probe with a one-element race.
        if self.inners.len() == 1 {
            return self.inners[0].invoke(messages, opts).await;
        }

        let mut set: JoinSet<Result<ChatResponse>> = JoinSet::new();
        for inner in self.inners.iter() {
            let inner = inner.clone();
            let msgs = messages.clone();
            let opts = opts.clone();
            set.spawn(async move { inner.invoke(msgs, &opts).await });
        }

        let mut errors: Vec<String> = Vec::with_capacity(self.inners.len());
        while let Some(joined) = set.join_next().await {
            match joined {
                Ok(Ok(resp)) => {
                    // Winner — abort everything else and return.
                    set.abort_all();
                    return Ok(resp);
                }
                Ok(Err(e)) => errors.push(e.to_string()),
                Err(e) => errors.push(format!("task join: {e}")),
            }
        }
        Err(Error::other(format!(
            "RaceChatModel: all {} inners failed:\n  - {}",
            self.inners.len(),
            errors.join("\n  - "),
        )))
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // Mid-stream switching is unworkable. See module doc.
        self.inners[0].stream(messages, opts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TimeoutChatModel — per-invocation deadline wrapper
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any `ChatModel` so each `invoke` call must complete within
/// `timeout`. On timeout, returns `Error::Timeout`; the inner future
/// is cancelled (`tokio::time::timeout` drops it, releasing whatever
/// HTTP connection / parse state it held).
///
/// # Why this exists
///
/// Mirrors `litgraph_tools_utils::TimeoutTool` but for the chat-model
/// side. Real production patterns:
///
/// - **SLA enforcement**: an interactive UI can't wait 60s for a
///   pathological model response — wrap the call with a 10s deadline
///   and let `RetryingChatModel` (with backoff) or `FallbackChatModel`
///   pick a different provider.
/// - **Circuit-breaker preconditions**: pair with a counter that
///   trips when N timeouts hit in a window.
/// - **Budgeted batches**: prevent a single slow request from
///   dragging out a `batch_concurrent` (iter 182) call.
///
/// # Parallelism
///
/// `tokio::time::timeout` runs the inner future and a timer future
/// **concurrently** under a `select!`-style poller. First to complete
/// wins. Distinct from iter 184's `RaceChatModel` (which races N
/// inner futures via `JoinSet`+`abort_all`); here the "competitor"
/// is a deadline timer, not another provider.
///
/// # Streaming
///
/// `stream()` is **not** wrapped — once chunks start arriving the
/// per-call deadline is meaningless (you'd need a per-chunk deadline
/// instead). Stream consumers should run their own per-chunk
/// `tokio::time::timeout` if they need that.
pub struct TimeoutChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub timeout: Duration,
}

impl TimeoutChatModel {
    pub fn new(inner: Arc<dyn ChatModel>, timeout: Duration) -> Self {
        Self { inner, timeout }
    }
}

#[async_trait]
impl ChatModel for TimeoutChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        match tokio::time::timeout(self.timeout, self.inner.invoke(messages, opts)).await {
            Ok(r) => r,
            Err(_) => Err(Error::Timeout),
        }
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // Per-call timeout doesn't compose cleanly with token streams;
        // pass through. See module doc.
        self.inner.stream(messages, opts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CircuitBreakerChatModel — fail-fast wrapper backed by iter-243 primitive
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any [`ChatModel`] with a [`CircuitBreaker`] so persistent
/// upstream failures stop bleeding load against a sick service.
///
/// Distinct from [`RetryingChatModel`]: that retries individual
/// transient errors (right when failures are momentary). When an
/// upstream is *down*, retrying just hammers it harder. The
/// breaker stops calls cold for a cooldown window, gives the
/// upstream room to heal, and emits an `Error::Provider("circuit
/// breaker open")` from waiting callers so they can fall through
/// (e.g. via [`FallbackChatModel`]) immediately.
///
/// # Composition
///
/// Stacks naturally with the existing wrapper toolkit. A common
/// prod chain — outer to inner:
///
/// 1. `CircuitBreakerChatModel` — fail-fast on persistent outage
/// 2. `FallbackChatModel` — switch provider on circuit-open
/// 3. `RetryingChatModel` — retry the *primary* on transient errors
/// 4. `RateLimitedChatModel` — local rate cap
/// 5. real provider
///
/// # Streaming
///
/// `stream()` is wrapped at the **handshake**: if the breaker is
/// open, returns `Error::Provider("circuit breaker open")` without
/// invoking the inner stream. If the inner `stream()` returns Ok,
/// the breaker records success and the caller drives the stream
/// normally — mid-stream failures are not visible to the breaker
/// (consumer's responsibility). This matches the breaker's
/// admission-control semantics.
pub struct CircuitBreakerChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub breaker: Arc<CircuitBreaker>,
}

impl CircuitBreakerChatModel {
    pub fn new(inner: Arc<dyn ChatModel>, breaker: Arc<CircuitBreaker>) -> Self {
        Self { inner, breaker }
    }
}

#[async_trait]
impl ChatModel for CircuitBreakerChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let inner = self.inner.clone();
        let opts = opts.clone();
        let r = self
            .breaker
            .call(move || async move { inner.invoke(messages, &opts).await })
            .await;
        match r {
            Ok(resp) => Ok(resp),
            Err(CircuitCallError::CircuitOpen) => {
                Err(Error::Provider("circuit breaker open".into()))
            }
            Err(CircuitCallError::Inner(e)) => Err(e),
        }
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        let inner = self.inner.clone();
        let opts = opts.clone();
        let r = self
            .breaker
            .call(move || async move { inner.stream(messages, &opts).await })
            .await;
        match r {
            Ok(s) => Ok(s),
            Err(CircuitCallError::CircuitOpen) => {
                Err(Error::Provider("circuit breaker open".into()))
            }
            Err(CircuitCallError::Inner(e)) => Err(e),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-invocation token budget
// ─────────────────────────────────────────────────────────────────────────────

/// Chat-model wrapper that enforces a token-count budget per invocation.
/// Two modes:
///
/// - **Strict (default)**: messages exceeding the budget → `Error::InvalidInput`.
///   Caller must trim / summarize upstream. Fails fast, predictable cost.
/// - **Auto-trim**: call `.auto_trim()` to enable — the wrapper uses
///   [`litgraph_tokenizers::trim_messages`] to drop oldest non-system
///   messages until under budget, then forwards. System messages are
///   ALWAYS preserved (they carry the persona / task). Last message
///   always preserved too (the user's actual query).
///
/// # Why
///
/// Long conversations silently balloon token cost. Without a budget,
/// a support chatbot that never forgets can rack up $100 LLM bills on
/// a single session. This wrapper makes the cap explicit.
///
/// # Model-specific token counts
///
/// The tokenizer used by [`trim_messages`] is picked by the inner
/// model's `name()`. Providers whose name contains "gpt" use tiktoken's
/// cl100k/o200k; others fall back to `tiktoken-rs` cl100k estimate.
/// Non-GPT-named models may be off by 5–15% — this is a best-effort
/// estimator, not a billing oracle.
///
/// # Composition
///
/// Safe to stack with other wrappers: `Retry(Budget(inner))` is fine,
/// as is `Budget(Retry(inner))`. Typical order: budget innermost
/// (trim ONCE per logical invocation, then retry with the same trimmed
/// message set on transient errors).
///
/// ```ignore
/// use litgraph_resilience::{RetryingChatModel, RetryConfig, TokenBudgetChatModel};
/// let budgeted = TokenBudgetChatModel::new(inner, 4096).auto_trim();
/// let retrying = RetryingChatModel::new(Arc::new(budgeted), RetryConfig::default());
/// ```
pub struct TokenBudgetChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub max_tokens: usize,
    pub auto_trim: bool,
}

impl TokenBudgetChatModel {
    /// Build in strict mode. Use [`.auto_trim()`] to switch to auto-trimming.
    pub fn new(inner: Arc<dyn ChatModel>, max_tokens: usize) -> Self {
        Self {
            inner,
            max_tokens,
            auto_trim: false,
        }
    }

    /// Enable auto-trimming mode.
    pub fn auto_trim(mut self) -> Self {
        self.auto_trim = true;
        self
    }
}

#[async_trait]
impl ChatModel for TokenBudgetChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let cost = litgraph_tokenizers::count_message_tokens(self.inner.name(), &messages);
        if cost <= self.max_tokens {
            return self.inner.invoke(messages, opts).await;
        }
        if !self.auto_trim {
            return Err(Error::invalid(format!(
                "TokenBudgetChatModel: messages use ~{} tokens, budget is {}. \
                 Trim upstream or enable .auto_trim().",
                cost, self.max_tokens
            )));
        }
        // Auto-trim mode: drop oldest non-system until under budget.
        let trimmed = litgraph_tokenizers::trim_messages(
            self.inner.name(),
            &messages,
            self.max_tokens,
        );
        tracing::debug!(
            model = self.inner.name(),
            input = messages.len(),
            kept = trimmed.len(),
            budget = self.max_tokens,
            "TokenBudgetChatModel auto-trimmed history"
        );
        self.inner.invoke(trimmed, opts).await
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // Same budget logic on the streaming path.
        let cost = litgraph_tokenizers::count_message_tokens(self.inner.name(), &messages);
        if cost <= self.max_tokens {
            return self.inner.stream(messages, opts).await;
        }
        if !self.auto_trim {
            return Err(Error::invalid(format!(
                "TokenBudgetChatModel: messages use ~{} tokens, budget is {}.",
                cost, self.max_tokens
            )));
        }
        let trimmed = litgraph_tokenizers::trim_messages(
            self.inner.name(),
            &messages,
            self.max_tokens,
        );
        self.inner.stream(trimmed, opts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Cross-provider Embeddings fallback
// ─────────────────────────────────────────────────────────────────────────────

/// Parallel to `FallbackChatModel` but for the `Embeddings` trait. Tries
/// providers in order; on transient failure (rate-limit / timeout / 5xx)
/// routes to the next. Last provider's error propagates.
///
/// # Dimension invariant
///
/// ALL inner providers must produce same-dimension vectors. Silently
/// switching from a 1536-dim embedder to a 768-dim one would corrupt
/// your vector index. `new()` validates this at construction and panics
/// (programmer error — catches the config bug at startup, not 10k docs
/// into production). For same-family models (all OpenAI small variants,
/// for example), dimensions match naturally.
///
/// # When to use
///
/// - **Provider failover**: OpenAI embed primary, Voyage backup. When
///   OpenAI has an outage, embedding calls transparently route.
/// - **Cost shedding**: expensive flagship primary, cheap small backup
///   for non-critical batch embed.
/// - **Regional failover**: us-east primary, us-west backup.
///
/// Each variant MUST produce the same dim — OpenAI `text-embedding-3-small`
/// (1536) ↔ Voyage `voyage-3-lite` (512) → don't mix. Use same-family
/// models or pad downstream.
pub struct FallbackEmbeddings {
    pub inners: Vec<Arc<dyn Embeddings>>,
    pub fall_through_on_all: bool,
    /// Cached at construction; all inners agree on this.
    dim: usize,
    name_label: String,
}

impl FallbackEmbeddings {
    /// Build a fallback chain. Panics if `inners` is empty or if any
    /// two inners disagree on `dimensions()`.
    pub fn new(inners: Vec<Arc<dyn Embeddings>>) -> Self {
        assert!(
            !inners.is_empty(),
            "FallbackEmbeddings: chain must have at least one provider"
        );
        let dim = inners[0].dimensions();
        for (i, e) in inners.iter().enumerate().skip(1) {
            assert_eq!(
                e.dimensions(),
                dim,
                "FallbackEmbeddings: inner #{} has dim {} but inner #0 has dim {} — \
                 silent dimension mismatch would corrupt your vector index",
                i,
                e.dimensions(),
                dim
            );
        }
        let labels: Vec<String> = inners.iter().map(|e| e.name().to_string()).collect();
        Self {
            inners,
            fall_through_on_all: false,
            dim,
            name_label: format!("fallback({})", labels.join(", ")),
        }
    }

    /// Fall through on EVERY error, not just transient. Default is
    /// conservative — 4xx errors (malformed input) will fail the same way
    /// on a backup provider, so we fail fast.
    pub fn fall_through_on_all(mut self) -> Self {
        self.fall_through_on_all = true;
        self
    }
}

#[async_trait]
impl Embeddings for FallbackEmbeddings {
    fn name(&self) -> &str {
        &self.name_label
    }

    fn dimensions(&self) -> usize {
        self.dim
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let last_idx = self.inners.len() - 1;
        let mut last_err: Option<Error> = None;
        for (i, inner) in self.inners.iter().enumerate() {
            match inner.embed_query(text).await {
                Ok(v) => {
                    if i > 0 {
                        debug!(
                            fallback_idx = i,
                            "FallbackEmbeddings.embed_query recovered on backup"
                        );
                    }
                    return Ok(v);
                }
                Err(e) => {
                    let should_fall = self.fall_through_on_all || is_transient(&e);
                    if i == last_idx || !should_fall {
                        warn!(
                            provider_idx = i,
                            error = %e,
                            "FallbackEmbeddings.embed_query exhausted or terminal"
                        );
                        return Err(e);
                    }
                    debug!(
                        provider_idx = i,
                        error = %e,
                        "FallbackEmbeddings.embed_query falling through"
                    );
                    last_err = Some(e);
                }
            }
        }
        Err(last_err.unwrap_or_else(|| Error::other("FallbackEmbeddings.embed_query: no result")))
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let last_idx = self.inners.len() - 1;
        let mut last_err: Option<Error> = None;
        for (i, inner) in self.inners.iter().enumerate() {
            match inner.embed_documents(texts).await {
                Ok(v) => {
                    if i > 0 {
                        debug!(
                            fallback_idx = i,
                            n_texts = texts.len(),
                            "FallbackEmbeddings.embed_documents recovered on backup"
                        );
                    }
                    return Ok(v);
                }
                Err(e) => {
                    let should_fall = self.fall_through_on_all || is_transient(&e);
                    if i == last_idx || !should_fall {
                        return Err(e);
                    }
                    last_err = Some(e);
                }
            }
        }
        Err(last_err.unwrap_or_else(|| {
            Error::other("FallbackEmbeddings.embed_documents: no result")
        }))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RaceEmbeddings — concurrent N-provider race, first-success-wins
// ─────────────────────────────────────────────────────────────────────────────

/// Embeddings analogue of [`RaceChatModel`]: invokes every inner
/// `Embeddings` provider concurrently, returns the first successful
/// result, aborts the others.
///
/// # Why use this over `FallbackEmbeddings`
///
/// `FallbackEmbeddings` is **sequential** — try A, on failure try B
/// (cost-min, but pays A's full latency before B even starts).
/// `RaceEmbeddings` is **concurrent** — issue A, B, C at the same
/// instant, take whoever returns first (latency-min, pays for all
/// requests but cuts the p95).
///
/// Typical patterns:
/// - Hedge a remote provider (OpenAI / Voyage / Cohere) against a
///   local fastembed cross-encoder. Local usually wins on warm
///   cache; remote wins when local hits CPU pressure.
/// - Multi-region embedding: us-east + eu-west, race for whichever
///   is closer to the caller's pod.
/// - Tail-latency reduction on the embed-query critical path —
///   `embed_query` blocks every retrieval, so shaving 50ms off p95
///   compounds over a session.
///
/// # Cost
///
/// All N providers are *issued* — most bill for tokens generated
/// before the connection closes. Budget `cost_floor ≈ N × p50_cost`
/// even though latency is `p_min`.
///
/// # Dimensions
///
/// All inners must agree on `dimensions()` — checked at construction
/// (panic). Race semantics on the result mean a 1536-dim winner this
/// call vs a 512-dim winner next call would silently corrupt your
/// vector index, so we forbid the configuration outright.
pub struct RaceEmbeddings {
    pub inners: Vec<Arc<dyn Embeddings>>,
    dim: usize,
    name_label: String,
}

impl RaceEmbeddings {
    /// Build a race set. Panics if `inners` is empty or any two
    /// inners disagree on `dimensions()`.
    pub fn new(inners: Vec<Arc<dyn Embeddings>>) -> Self {
        assert!(
            !inners.is_empty(),
            "RaceEmbeddings: need at least one inner provider",
        );
        let dim = inners[0].dimensions();
        for (i, e) in inners.iter().enumerate().skip(1) {
            assert_eq!(
                e.dimensions(),
                dim,
                "RaceEmbeddings: inner #{} has dim {} but inner #0 has dim {} — \
                 race semantics + dim mismatch would silently corrupt the vector index",
                i,
                e.dimensions(),
                dim,
            );
        }
        let labels: Vec<String> = inners.iter().map(|e| e.name().to_string()).collect();
        Self {
            inners,
            dim,
            name_label: format!("race({})", labels.join(", ")),
        }
    }
}

#[async_trait]
impl Embeddings for RaceEmbeddings {
    fn name(&self) -> &str {
        &self.name_label
    }
    fn dimensions(&self) -> usize {
        self.dim
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        use tokio::task::JoinSet;

        if self.inners.len() == 1 {
            return self.inners[0].embed_query(text).await;
        }

        let mut set: JoinSet<Result<Vec<f32>>> = JoinSet::new();
        for inner in self.inners.iter() {
            let inner = inner.clone();
            let text = text.to_string();
            set.spawn(async move { inner.embed_query(&text).await });
        }

        let mut errors: Vec<String> = Vec::with_capacity(self.inners.len());
        while let Some(joined) = set.join_next().await {
            match joined {
                Ok(Ok(v)) => {
                    set.abort_all();
                    return Ok(v);
                }
                Ok(Err(e)) => errors.push(e.to_string()),
                Err(e) => errors.push(format!("task join: {e}")),
            }
        }
        Err(Error::other(format!(
            "RaceEmbeddings.embed_query: all {} inners failed:\n  - {}",
            self.inners.len(),
            errors.join("\n  - "),
        )))
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        use tokio::task::JoinSet;

        if self.inners.len() == 1 {
            return self.inners[0].embed_documents(texts).await;
        }

        let mut set: JoinSet<Result<Vec<Vec<f32>>>> = JoinSet::new();
        for inner in self.inners.iter() {
            let inner = inner.clone();
            let owned: Vec<String> = texts.to_vec();
            set.spawn(async move { inner.embed_documents(&owned).await });
        }

        let mut errors: Vec<String> = Vec::with_capacity(self.inners.len());
        while let Some(joined) = set.join_next().await {
            match joined {
                Ok(Ok(v)) => {
                    set.abort_all();
                    return Ok(v);
                }
                Ok(Err(e)) => errors.push(e.to_string()),
                Err(e) => errors.push(format!("task join: {e}")),
            }
        }
        Err(Error::other(format!(
            "RaceEmbeddings.embed_documents: all {} inners failed:\n  - {}",
            self.inners.len(),
            errors.join("\n  - "),
        )))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TimeoutEmbeddings — per-invocation deadline wrapper
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any `Embeddings` so each `embed_query` / `embed_documents`
/// must complete within `timeout`. On timeout, returns
/// `Error::Timeout`; the inner future is cancelled.
///
/// Embeddings analogue of `TimeoutChatModel`. Real prod use cases:
///
/// - **Tail-latency cap on the embed-query critical path** — every
///   retrieval blocks on this call; if a slow provider stalls,
///   trip and let `RetryingEmbeddings` / `FallbackEmbeddings`
///   pick up.
/// - **Bounded `embed_documents_concurrent`** — wrap the inner
///   provider so a single hung chunk doesn't drag out a 10k-text
///   ingestion.
///
/// `tokio::time::timeout` runs the inner + a timer concurrently —
/// same primitive as `TimeoutChatModel`, just over the embeddings
/// trait.
pub struct TimeoutEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    pub timeout: Duration,
}

impl TimeoutEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>, timeout: Duration) -> Self {
        Self { inner, timeout }
    }
}

#[async_trait]
impl Embeddings for TimeoutEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        match tokio::time::timeout(self.timeout, self.inner.embed_query(text)).await {
            Ok(r) => r,
            Err(_) => Err(Error::Timeout),
        }
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        match tokio::time::timeout(self.timeout, self.inner.embed_documents(texts)).await {
            Ok(r) => r,
            Err(_) => Err(Error::Timeout),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Embeddings retry + rate-limit wrappers
// ─────────────────────────────────────────────────────────────────────────────

/// Retry wrapper for `Embeddings`. Same retry semantics as
/// `RetryingChatModel` — exponential backoff on transient failures
/// (rate-limit / timeout / 5xx), terminal errors (4xx, parse) propagate.
///
/// Applies to BOTH `embed_query` and `embed_documents`. `embed_documents`
/// retries the whole batch on failure — do NOT retry per-element since
/// that masks provider-side partial failures. If you need per-element
/// resilience, chunk before calling.
pub struct RetryingEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    pub cfg: RetryConfig,
}

impl RetryingEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>, cfg: RetryConfig) -> Self {
        Self { inner, cfg }
    }
}

#[async_trait]
impl Embeddings for RetryingEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let inner = self.inner.clone();
        let backoff = self.cfg.to_builder();
        let text = text.to_string();
        (|| {
            let inner = inner.clone();
            let text = text.clone();
            async move { inner.embed_query(&text).await }
        })
        .retry(&backoff)
        .when(|e: &Error| {
            let retry = is_transient(e);
            if retry {
                debug!(error = %e, "RetryingEmbeddings.embed_query retry");
            } else {
                warn!(error = %e, "RetryingEmbeddings.embed_query terminal");
            }
            retry
        })
        .await
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let inner = self.inner.clone();
        let backoff = self.cfg.to_builder();
        let texts = texts.to_vec();
        (|| {
            let inner = inner.clone();
            let texts = texts.clone();
            async move { inner.embed_documents(&texts).await }
        })
        .retry(&backoff)
        .when(|e: &Error| is_transient(e))
        .await
    }
}

/// Token-bucket rate limiter for `Embeddings`. Same semantics as
/// `RateLimitedChatModel` — one token per call, refills at
/// `requests_per_minute` rate, `burst` bucket capacity.
///
/// NOTE: the bucket counts CALLS not texts. A single `embed_documents`
/// batch of 100 texts consumes one token (most providers bill per call,
/// not per text, so this matches cost semantics). If your provider rate-
/// limits per-text, chunk upstream and wrap each chunk separately.
pub struct RateLimitedEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    refill_per_sec: f64,
    capacity: f64,
    state: tokio::sync::Mutex<BucketState>,
}

impl RateLimitedEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>, cfg: RateLimitConfig) -> Self {
        let refill_per_sec = (cfg.requests_per_minute as f64) / 60.0;
        let capacity = cfg.burst as f64;
        Self {
            inner,
            refill_per_sec,
            capacity,
            state: tokio::sync::Mutex::new(BucketState {
                tokens: capacity,
                last_refill: std::time::Instant::now(),
            }),
        }
    }

    async fn acquire(&self) {
        if self.refill_per_sec <= 0.0 {
            return;
        }
        let mut state = self.state.lock().await;
        let now = std::time::Instant::now();
        let elapsed = now.duration_since(state.last_refill).as_secs_f64();
        state.tokens = (state.tokens + elapsed * self.refill_per_sec).min(self.capacity);
        state.last_refill = now;
        if state.tokens >= 1.0 {
            state.tokens -= 1.0;
            return;
        }
        let deficit = 1.0 - state.tokens;
        let wait = Duration::from_secs_f64(deficit / self.refill_per_sec);
        tokio::time::sleep(wait).await;
        state.tokens = 0.0;
        state.last_refill = std::time::Instant::now();
    }
}

#[async_trait]
impl Embeddings for RateLimitedEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        self.acquire().await;
        self.inner.embed_query(text).await
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        self.acquire().await;
        self.inner.embed_documents(texts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SingleflightTool — request-coalescing wrapper for Tool::run
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any [`litgraph_core::tool::Tool`] so concurrent calls
/// with identical args share ONE upstream `run`. Bridges the
/// iter-252 [`Singleflight`] primitive into the tool family —
/// closes the request-coalescing matrix across chat (intentionally
/// not coalesced), embed (iter 253), and tool (this iter).
///
/// # Hash key
///
/// blake3 over canonical JSON of `args` (same hash function as
/// iter 256 `tool_args_hash`). Identical args → identical hash
/// → coalesced call.
///
/// # Error handling
///
/// Errors broadcast as `Arc<String>` (the inner `Error`'s
/// `to_string()`) — same lossy-by-design tradeoff as
/// `SingleflightEmbeddings`. Variant info collapses to
/// `Error::Provider(s)` on the caller side.
///
/// # Real prod use
///
/// - **Idempotent expensive lookups**: `lookup_user("alice")`
///   called 10× concurrently from different agent steps → 1
///   DB round-trip.
/// - **Hot search query coalescing**: a popular search-tool
///   query embedded by 50 concurrent eval rows → 1 SerpAPI call.
/// - **Stable function tools**: tools whose output is a pure
///   function of args benefit; tools with side effects MUST
///   NOT be coalesced (would deduplicate the side effects).
///
/// # When NOT to coalesce
///
/// Tools with side effects (writes, sends, mutations) must NOT
/// be wrapped — coalescing collapses N intent-distinct calls
/// into one execution. Use only for idempotent reads /
/// pure-function tools.
pub struct SingleflightTool {
    pub inner: Arc<dyn litgraph_core::tool::Tool>,
    sf: Arc<Singleflight<String, Arc<std::result::Result<serde_json::Value, String>>>>,
}

impl SingleflightTool {
    pub fn new(inner: Arc<dyn litgraph_core::tool::Tool>) -> Self {
        Self {
            inner,
            sf: Arc::new(Singleflight::new()),
        }
    }
}

#[async_trait]
impl litgraph_core::tool::Tool for SingleflightTool {
    fn schema(&self) -> litgraph_core::tool::ToolSchema {
        self.inner.schema()
    }

    async fn run(
        &self,
        args: serde_json::Value,
    ) -> Result<serde_json::Value> {
        let key = blake3::hash(
            serde_json::to_string(&args).unwrap_or_default().as_bytes(),
        )
        .to_hex()
        .to_string();
        let inner = self.inner.clone();
        let args_for_compute = args.clone();
        let r = self
            .sf
            .get_or_compute(key, move || async move {
                let res = inner.run(args_for_compute).await;
                Arc::new(match res {
                    Ok(v) => Ok(v),
                    Err(e) => Err(e.to_string()),
                })
            })
            .await;
        match &*r {
            Ok(v) => Ok(v.clone()),
            Err(s) => Err(Error::Provider(s.clone())),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CachedEmbeddings — exact-match TTL cache for embedding results
// ─────────────────────────────────────────────────────────────────────────────

/// One cache entry: vector + insertion time (for TTL).
struct CachedEmbedQueryEntry {
    vec: Vec<f32>,
    inserted_at: std::time::Instant,
}

struct CachedEmbedDocumentsEntry {
    vecs: Vec<Vec<f32>>,
    inserted_at: std::time::Instant,
}

/// Wrap any [`Embeddings`] with an exact-match string-key cache.
/// Distinct from iter-253 `SingleflightEmbeddings`: that
/// coalesces *concurrent* identical calls (same text arriving at
/// the same time share one HTTP call). `CachedEmbeddings` caches
/// *across* calls — once a query is embedded, subsequent calls
/// with the exact same query string skip the upstream entirely
/// until the entry expires or is evicted.
///
/// Real prod use:
/// - Popular search queries embedded once per cache window.
/// - Repeated agent runs over the same query corpus during
///   eval / development.
/// - Pre-warming cache from a known-popular query list at
///   startup.
///
/// # Knobs
///
/// - `with_max_entries(n)` — LRU cap (per-method: query and
///   documents have separate caps but share the bound). Default
///   1000.
/// - `with_ttl(d)` — entries expire after `d`. Default `None`
///   (cache forever; useful when the embedding model is fixed).
///
/// # Composition
///
/// Stack on top of `SingleflightEmbeddings` for the full "cache
/// + dedup-concurrent" stack:
///
/// ```ignore
/// let inner = Arc::new(real_embeddings);
/// let dedup = Arc::new(SingleflightEmbeddings::new(inner));
/// let cached = Arc::new(CachedEmbeddings::new(dedup));
/// ```
///
/// Order matters: cache outside, dedup inside. Cache hits skip
/// even the dedup step; cache misses go through dedup so
/// concurrent misses still coalesce.
pub struct CachedEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    pub max_entries: usize,
    pub ttl: Option<Duration>,
    query_cache: parking_lot::Mutex<Vec<(String, CachedEmbedQueryEntry)>>,
    doc_cache: parking_lot::Mutex<Vec<(Vec<String>, CachedEmbedDocumentsEntry)>>,
}

impl CachedEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>) -> Self {
        Self {
            inner,
            max_entries: 1000,
            ttl: None,
            query_cache: parking_lot::Mutex::new(Vec::new()),
            doc_cache: parking_lot::Mutex::new(Vec::new()),
        }
    }

    pub fn with_max_entries(mut self, n: usize) -> Self {
        self.max_entries = n.max(1);
        self
    }

    pub fn with_ttl(mut self, ttl: Duration) -> Self {
        self.ttl = Some(ttl);
        self
    }

    /// Approximate query-cache size (for telemetry / tests).
    pub fn query_cache_len(&self) -> usize {
        self.query_cache.lock().len()
    }

    /// Drop all cached entries.
    pub fn clear(&self) {
        self.query_cache.lock().clear();
        self.doc_cache.lock().clear();
    }
}

#[async_trait]
impl Embeddings for CachedEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let now = std::time::Instant::now();
        // Lookup phase.
        {
            let mut cache = self.query_cache.lock();
            if let Some(ttl) = self.ttl {
                cache.retain(|(_, e)| now.duration_since(e.inserted_at) <= ttl);
            }
            if let Some((_, entry)) = cache.iter().find(|(k, _)| k == text) {
                return Ok(entry.vec.clone());
            }
        }
        // Miss — call inner.
        let vec = self.inner.embed_query(text).await?;
        // Insert.
        {
            let mut cache = self.query_cache.lock();
            cache.push((
                text.to_string(),
                CachedEmbedQueryEntry {
                    vec: vec.clone(),
                    inserted_at: now,
                },
            ));
            while cache.len() > self.max_entries {
                cache.remove(0);
            }
        }
        Ok(vec)
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let now = std::time::Instant::now();
        // Lookup phase.
        {
            let mut cache = self.doc_cache.lock();
            if let Some(ttl) = self.ttl {
                cache.retain(|(_, e)| now.duration_since(e.inserted_at) <= ttl);
            }
            if let Some((_, entry)) = cache.iter().find(|(k, _)| k.as_slice() == texts) {
                return Ok(entry.vecs.clone());
            }
        }
        let vecs = self.inner.embed_documents(texts).await?;
        {
            let mut cache = self.doc_cache.lock();
            cache.push((
                texts.to_vec(),
                CachedEmbedDocumentsEntry {
                    vecs: vecs.clone(),
                    inserted_at: now,
                },
            ));
            while cache.len() > self.max_entries {
                cache.remove(0);
            }
        }
        Ok(vecs)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SingleflightEmbeddings — request-coalescing wrapper for embed_query
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any [`Embeddings`] so concurrent identical `embed_query`
/// calls share ONE upstream HTTP call. Bridges the iter-252
/// [`Singleflight`] primitive into the embeddings family.
///
/// # Why embed_query, not embed_documents
///
/// Embedding queries are repeated often (the same user query
/// from many threads, the same system-prompt prefix from many
/// agents). Coalescing them is high-value. Multi-doc batches in
/// `embed_documents` are typically distinct per call (a chunked
/// indexer's chunks differ batch-to-batch); coalescing them is
/// rare-win and would require a hashable key over `Vec<String>`.
/// `embed_documents` passes through unchanged.
///
/// # Error handling
///
/// Errors broadcast as `Arc<String>` (the original `Error`'s
/// `to_string()`) — the variant info (`RateLimited`,
/// `Timeout`, `InvalidInput`, etc.) collapses to
/// `Error::Provider(s)` on the caller side. This is lossy by
/// design: `Error` isn't `Clone`, and the alternative (running
/// each follower's compute when leader fails) defeats the whole
/// purpose of coalescing under a flapping upstream. Callers who
/// need exact error variants should not coalesce.
///
/// # Real prod use
///
/// - **System-prompt cache priming**: 50 agents start; each
///   embeds the same long system prompt. One HTTP call.
/// - **Hot query dedup**: a popular search query gets embedded
///   100×/sec from different threads. One call per unique query
///   per Singleflight window.
/// - **Eval harness deduplication**: golden-set runner
///   evaluates the same query against many retrievers; the
///   query embedding only needs computing once.
pub struct SingleflightEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    sf: Arc<Singleflight<String, Arc<std::result::Result<Vec<f32>, String>>>>,
}

impl SingleflightEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>) -> Self {
        Self {
            inner,
            sf: Arc::new(Singleflight::new()),
        }
    }
}

#[async_trait]
impl Embeddings for SingleflightEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let inner = self.inner.clone();
        let text_owned = text.to_string();
        let r = self
            .sf
            .get_or_compute(text.to_string(), move || async move {
                let res = inner.embed_query(&text_owned).await;
                Arc::new(match res {
                    Ok(v) => Ok(v),
                    Err(e) => Err(e.to_string()),
                })
            })
            .await;
        match &*r {
            Ok(v) => Ok(v.clone()),
            Err(s) => Err(Error::Provider(s.clone())),
        }
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        // Pass-through (see doc above).
        self.inner.embed_documents(texts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RecordingChatModel + ReplayingChatModel — VCR-style test cassettes
// ─────────────────────────────────────────────────────────────────────────────

/// One captured request/response pair. Hash key is computed from
/// canonical JSON of `(messages, opts)`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct CassetteExchange {
    pub request_hash: String,
    pub messages: Vec<Message>,
    pub opts: ChatOptions,
    pub response: ChatResponse,
}

/// Persistable record of LLM interactions. Round-trips via
/// `serde_json` so cassettes can live in a `tests/` directory
/// next to the test file.
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct Cassette {
    #[serde(default = "default_version")]
    pub version: u32,
    pub exchanges: Vec<CassetteExchange>,
}

fn default_version() -> u32 {
    1
}

impl Cassette {
    /// Load a cassette from a JSON file. Convenience wrapper around
    /// `std::fs::read_to_string` + `serde_json::from_str`. Errors
    /// surface as `Error::Other(...)`.
    pub fn load_from_file(path: impl AsRef<std::path::Path>) -> Result<Self> {
        let path = path.as_ref();
        let s = std::fs::read_to_string(path)
            .map_err(|e| Error::other(format!("read cassette {path:?}: {e}")))?;
        serde_json::from_str(&s)
            .map_err(|e| Error::other(format!("parse cassette {path:?}: {e}")))
    }

    /// Save a cassette as pretty JSON. Creates parent directory if
    /// needed.
    pub fn save_to_file(&self, path: impl AsRef<std::path::Path>) -> Result<()> {
        let path = path.as_ref();
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                std::fs::create_dir_all(parent).map_err(|e| {
                    Error::other(format!("mkdir {parent:?}: {e}"))
                })?;
            }
        }
        let s = serde_json::to_string_pretty(self)
            .map_err(|e| Error::other(format!("serialize cassette: {e}")))?;
        std::fs::write(path, s)
            .map_err(|e| Error::other(format!("write cassette {path:?}: {e}")))?;
        Ok(())
    }
}

/// Compute a deterministic hash of a `(messages, opts)` request.
/// Uses canonical JSON (no field ordering, no whitespace) over
/// blake3 → hex string.
pub fn exchange_hash(messages: &[Message], opts: &ChatOptions) -> String {
    // serde_json::to_string is stable for our types because the
    // structs use `#[derive(Serialize)]` with deterministic field
    // order. There are no `HashMap` fields in messages or opts.
    let req = serde_json::json!({ "messages": messages, "opts": opts });
    let s = serde_json::to_string(&req).unwrap_or_default();
    let h = blake3::hash(s.as_bytes());
    h.to_hex().to_string()
}

/// Wrap any [`ChatModel`] to record every `invoke` call into a
/// shared [`Cassette`]. Use during a real-traffic test run; serialize
/// the cassette to disk; replay in CI via [`ReplayingChatModel`].
///
/// VCR-style determinism for agent tests — no API calls in CI, no
/// flaky stochastic outputs, no quota burn for golden-set
/// regression tests.
///
/// # Streaming
///
/// `stream()` is NOT recorded — token streams aren't replayable
/// in a useful way without preserving inter-chunk timing. Stream
/// calls pass through to inner. Tests that want streaming
/// determinism should use [`ReplayingChatModel`] in invoke-mode
/// and manually re-emit a synthetic stream.
pub struct RecordingChatModel {
    pub inner: Arc<dyn ChatModel>,
    cassette: Arc<parking_lot::Mutex<Cassette>>,
}

impl RecordingChatModel {
    pub fn new(
        inner: Arc<dyn ChatModel>,
        cassette: Arc<parking_lot::Mutex<Cassette>>,
    ) -> Self {
        Self { inner, cassette }
    }
}

#[async_trait]
impl ChatModel for RecordingChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let response = self.inner.invoke(messages.clone(), opts).await?;
        let request_hash = exchange_hash(&messages, opts);
        let exchange = CassetteExchange {
            request_hash,
            messages,
            opts: opts.clone(),
            response: response.clone(),
        };
        self.cassette.lock().exchanges.push(exchange);
        Ok(response)
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // See doc — streams pass through unrecorded.
        self.inner.stream(messages, opts).await
    }
}

/// Replay recorded LLM interactions from a [`Cassette`]. Lookup
/// is by request hash — exact match on canonical JSON of
/// `(messages, opts)`.
///
/// On miss: returns `Error::Provider("no recorded response for
/// hash <…>")` if no `passthrough` is set, or invokes
/// `passthrough` (typically the live model) otherwise. The
/// passthrough branch is useful for "record-then-replay-with-
/// gap-fill" workflows.
pub struct ReplayingChatModel {
    pub cassette: Cassette,
    pub passthrough: Option<Arc<dyn ChatModel>>,
}

impl ReplayingChatModel {
    pub fn new(cassette: Cassette, passthrough: Option<Arc<dyn ChatModel>>) -> Self {
        Self {
            cassette,
            passthrough,
        }
    }
}

#[async_trait]
impl ChatModel for ReplayingChatModel {
    fn name(&self) -> &str {
        "replaying"
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let hash = exchange_hash(&messages, opts);
        if let Some(ex) = self
            .cassette
            .exchanges
            .iter()
            .find(|e| e.request_hash == hash)
        {
            return Ok(ex.response.clone());
        }
        if let Some(pt) = &self.passthrough {
            return pt.invoke(messages, opts).await;
        }
        Err(Error::Provider(format!(
            "no recorded response for hash {hash}",
        )))
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // Streaming replay isn't supported (see RecordingChatModel
        // doc). Defer to passthrough or error.
        if let Some(pt) = &self.passthrough {
            return pt.stream(messages, opts).await;
        }
        Err(Error::Provider(
            "ReplayingChatModel does not support stream() without passthrough".into(),
        ))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Tool record/replay — VCR-style for the tool axis
// ─────────────────────────────────────────────────────────────────────────────

/// One captured tool call. Hash key: blake3 over canonical JSON
/// of `args`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ToolExchange {
    pub request_hash: String,
    pub tool_name: String,
    pub args: serde_json::Value,
    pub response: serde_json::Value,
}

/// Persistable record of `Tool::run` calls. Same load/save shape
/// as [`Cassette`] / [`EmbedCassette`].
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct ToolCassette {
    #[serde(default = "default_version")]
    pub version: u32,
    pub exchanges: Vec<ToolExchange>,
}

impl ToolCassette {
    pub fn load_from_file(path: impl AsRef<std::path::Path>) -> Result<Self> {
        let path = path.as_ref();
        let s = std::fs::read_to_string(path)
            .map_err(|e| Error::other(format!("read tool cassette {path:?}: {e}")))?;
        serde_json::from_str(&s)
            .map_err(|e| Error::other(format!("parse tool cassette {path:?}: {e}")))
    }

    pub fn save_to_file(&self, path: impl AsRef<std::path::Path>) -> Result<()> {
        let path = path.as_ref();
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                std::fs::create_dir_all(parent).map_err(|e| {
                    Error::other(format!("mkdir {parent:?}: {e}"))
                })?;
            }
        }
        let s = serde_json::to_string_pretty(self)
            .map_err(|e| Error::other(format!("serialize tool cassette: {e}")))?;
        std::fs::write(path, s)
            .map_err(|e| Error::other(format!("write tool cassette {path:?}: {e}")))?;
        Ok(())
    }
}

/// blake3 over canonical JSON of `args` for tool exchange keys.
pub fn tool_args_hash(args: &serde_json::Value) -> String {
    let s = serde_json::to_string(args).unwrap_or_default();
    blake3::hash(s.as_bytes()).to_hex().to_string()
}

/// Wrap any [`litgraph_core::tool::Tool`] to record every `run`
/// call into a shared [`ToolCassette`]. Closes the third axis of
/// the record/replay matrix (after iters 254 chat and 255 embed).
///
/// Real prod use: agent integration tests with deterministic
/// tool side effects. Record real tool runs against a staging
/// API; replay in CI without hitting the real service.
pub struct RecordingTool {
    pub inner: Arc<dyn litgraph_core::tool::Tool>,
    cassette: Arc<parking_lot::Mutex<ToolCassette>>,
}

impl RecordingTool {
    pub fn new(
        inner: Arc<dyn litgraph_core::tool::Tool>,
        cassette: Arc<parking_lot::Mutex<ToolCassette>>,
    ) -> Self {
        Self { inner, cassette }
    }
}

#[async_trait]
impl litgraph_core::tool::Tool for RecordingTool {
    fn schema(&self) -> litgraph_core::tool::ToolSchema {
        self.inner.schema()
    }

    async fn run(&self, args: serde_json::Value) -> Result<serde_json::Value> {
        let response = self.inner.run(args.clone()).await?;
        let exchange = ToolExchange {
            request_hash: tool_args_hash(&args),
            tool_name: self.inner.name(),
            args,
            response: response.clone(),
        };
        self.cassette.lock().exchanges.push(exchange);
        Ok(response)
    }
}

/// Replay recorded tool runs from a [`ToolCassette`]. Matches by
/// args hash. On miss: returns an error or falls through to
/// `passthrough` if set. Schema is inherited from `passthrough`
/// when present, otherwise a synthesized schema with the
/// configured `name` and an empty parameters object — sufficient
/// to satisfy callers that only need the cassette's responses.
pub struct ReplayingTool {
    pub cassette: ToolCassette,
    pub passthrough: Option<Arc<dyn litgraph_core::tool::Tool>>,
    pub name: String,
    pub description: String,
}

impl ReplayingTool {
    pub fn new(
        cassette: ToolCassette,
        passthrough: Option<Arc<dyn litgraph_core::tool::Tool>>,
    ) -> Self {
        Self {
            cassette,
            passthrough,
            name: "replaying-tool".into(),
            description: "Replay-only tool backed by a ToolCassette".into(),
        }
    }

    /// Override the tool's reported name (controls the synthesized
    /// schema when no passthrough is configured).
    pub fn with_name(mut self, name: impl Into<String>) -> Self {
        self.name = name.into();
        self
    }

    /// Override the tool's reported description.
    pub fn with_description(mut self, description: impl Into<String>) -> Self {
        self.description = description.into();
        self
    }
}

#[async_trait]
impl litgraph_core::tool::Tool for ReplayingTool {
    fn schema(&self) -> litgraph_core::tool::ToolSchema {
        if let Some(pt) = &self.passthrough {
            return pt.schema();
        }
        litgraph_core::tool::ToolSchema {
            name: self.name.clone(),
            description: self.description.clone(),
            parameters: serde_json::json!({"type": "object", "properties": {}}),
        }
    }

    async fn run(&self, args: serde_json::Value) -> Result<serde_json::Value> {
        let hash = tool_args_hash(&args);
        if let Some(ex) = self
            .cassette
            .exchanges
            .iter()
            .find(|e| e.request_hash == hash)
        {
            return Ok(ex.response.clone());
        }
        if let Some(pt) = &self.passthrough {
            return pt.run(args).await;
        }
        Err(Error::Provider(format!(
            "no recorded tool response for hash {hash}",
        )))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Embeddings record/replay — VCR-style for the embed axis
// ─────────────────────────────────────────────────────────────────────────────

/// One captured embed call. The two variants correspond to the
/// two `Embeddings` trait methods.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum EmbedExchange {
    Query {
        request_hash: String,
        text: String,
        response: Vec<f32>,
    },
    Documents {
        request_hash: String,
        texts: Vec<String>,
        response: Vec<Vec<f32>>,
    },
}

/// Persistable record of `embed_query` / `embed_documents` calls.
/// Same load/save shape as [`Cassette`].
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct EmbedCassette {
    #[serde(default = "default_version")]
    pub version: u32,
    pub exchanges: Vec<EmbedExchange>,
}

impl EmbedCassette {
    pub fn load_from_file(path: impl AsRef<std::path::Path>) -> Result<Self> {
        let path = path.as_ref();
        let s = std::fs::read_to_string(path)
            .map_err(|e| Error::other(format!("read embed cassette {path:?}: {e}")))?;
        serde_json::from_str(&s)
            .map_err(|e| Error::other(format!("parse embed cassette {path:?}: {e}")))
    }

    pub fn save_to_file(&self, path: impl AsRef<std::path::Path>) -> Result<()> {
        let path = path.as_ref();
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                std::fs::create_dir_all(parent).map_err(|e| {
                    Error::other(format!("mkdir {parent:?}: {e}"))
                })?;
            }
        }
        let s = serde_json::to_string_pretty(self)
            .map_err(|e| Error::other(format!("serialize embed cassette: {e}")))?;
        std::fs::write(path, s)
            .map_err(|e| Error::other(format!("write embed cassette {path:?}: {e}")))?;
        Ok(())
    }
}

/// blake3 over `text` for `embed_query` exchange keys.
pub fn embed_query_hash(text: &str) -> String {
    blake3::hash(text.as_bytes()).to_hex().to_string()
}

/// blake3 over canonical JSON of `texts` for `embed_documents`
/// exchange keys.
pub fn embed_documents_hash(texts: &[String]) -> String {
    let s = serde_json::to_string(texts).unwrap_or_default();
    blake3::hash(s.as_bytes()).to_hex().to_string()
}

/// Wrap any [`Embeddings`] to record every `embed_query` /
/// `embed_documents` call into a shared [`EmbedCassette`].
pub struct RecordingEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    cassette: Arc<parking_lot::Mutex<EmbedCassette>>,
}

impl RecordingEmbeddings {
    pub fn new(
        inner: Arc<dyn Embeddings>,
        cassette: Arc<parking_lot::Mutex<EmbedCassette>>,
    ) -> Self {
        Self { inner, cassette }
    }
}

#[async_trait]
impl Embeddings for RecordingEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let response = self.inner.embed_query(text).await?;
        let exchange = EmbedExchange::Query {
            request_hash: embed_query_hash(text),
            text: text.to_owned(),
            response: response.clone(),
        };
        self.cassette.lock().exchanges.push(exchange);
        Ok(response)
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let response = self.inner.embed_documents(texts).await?;
        let exchange = EmbedExchange::Documents {
            request_hash: embed_documents_hash(texts),
            texts: texts.to_vec(),
            response: response.clone(),
        };
        self.cassette.lock().exchanges.push(exchange);
        Ok(response)
    }
}

/// Replay recorded embedding interactions. Like
/// [`ReplayingChatModel`]: hash lookup, optional passthrough on
/// miss. `dimensions()` defaults to whatever the first
/// `Documents` / `Query` exchange returns; if the cassette is
/// empty it returns 0 (caller should pass through to a live
/// embedder if dimensions matter pre-recording).
pub struct ReplayingEmbeddings {
    pub cassette: EmbedCassette,
    pub passthrough: Option<Arc<dyn Embeddings>>,
    pub name: String,
}

impl ReplayingEmbeddings {
    pub fn new(
        cassette: EmbedCassette,
        passthrough: Option<Arc<dyn Embeddings>>,
    ) -> Self {
        Self {
            cassette,
            passthrough,
            name: "replaying-embed".into(),
        }
    }

    fn first_dim(&self) -> usize {
        self.cassette.exchanges.iter().find_map(|e| match e {
            EmbedExchange::Query { response, .. } => Some(response.len()),
            EmbedExchange::Documents { response, .. } => {
                response.first().map(|v| v.len())
            }
        }).unwrap_or(0)
    }
}

#[async_trait]
impl Embeddings for ReplayingEmbeddings {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimensions(&self) -> usize {
        if let Some(pt) = &self.passthrough {
            return pt.dimensions();
        }
        self.first_dim()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let hash = embed_query_hash(text);
        for ex in &self.cassette.exchanges {
            if let EmbedExchange::Query {
                request_hash,
                response,
                ..
            } = ex
            {
                if request_hash == &hash {
                    return Ok(response.clone());
                }
            }
        }
        if let Some(pt) = &self.passthrough {
            return pt.embed_query(text).await;
        }
        Err(Error::Provider(format!(
            "no recorded embed_query response for hash {hash}",
        )))
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let hash = embed_documents_hash(texts);
        for ex in &self.cassette.exchanges {
            if let EmbedExchange::Documents {
                request_hash,
                response,
                ..
            } = ex
            {
                if request_hash == &hash {
                    return Ok(response.clone());
                }
            }
        }
        if let Some(pt) = &self.passthrough {
            return pt.embed_documents(texts).await;
        }
        Err(Error::Provider(format!(
            "no recorded embed_documents response for hash {hash}",
        )))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// HedgedChatModel — tail-latency mitigation via delayed-backup race
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap two [`ChatModel`]s so each call goes to `primary` first;
/// if primary hasn't finished within `hedge_delay`, also issue
/// the same call to `backup` and return whichever finishes first.
/// Bridges the iter-250 [`hedged_call`] combinator into the chat
/// family.
///
/// # Distinct from `RaceChatModel`
///
/// `RaceChatModel` (iter 184) issues to both providers
/// simultaneously — every call doubles cost. Hedge only pays
/// the second-call cost when primary is slow, which is the
/// right trade-off for tail-latency mitigation where the
/// median is fine and you only want to insure against the p99.
///
/// # Real prod use
///
/// - **LLM tail latency**: provider with 500ms p50 / 30s p99 —
///   set `hedge_delay = 2s`; calls under 2s use only primary,
///   slow tail covered by backup.
/// - **Multi-region failover**: primary in us-east-1, backup
///   in us-west-2 — hedge after 1s.
/// - **Replica hedging**: same provider, two API keys;
///   distributes load + insures against per-key throttling.
///
/// # Streaming
///
/// `stream()` is NOT hedged — token streams can't be cleanly
/// raced (chunks can't be merged or chosen between mid-stream).
/// Stream calls pass through to `primary` only. Callers needing
/// stream tail-latency mitigation should run their own
/// per-chunk timeout + restart-on-different-provider logic.
pub struct HedgedChatModel {
    pub primary: Arc<dyn ChatModel>,
    pub backup: Arc<dyn ChatModel>,
    pub hedge_delay: Duration,
}

impl HedgedChatModel {
    pub fn new(
        primary: Arc<dyn ChatModel>,
        backup: Arc<dyn ChatModel>,
        hedge_delay: Duration,
    ) -> Self {
        Self {
            primary,
            backup,
            hedge_delay,
        }
    }
}

#[async_trait]
impl ChatModel for HedgedChatModel {
    fn name(&self) -> &str {
        self.primary.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let primary = self.primary.clone();
        let backup = self.backup.clone();
        let messages_p = messages.clone();
        let opts_p = opts.clone();
        let opts_b = opts.clone();
        hedged_call(
            move || async move { primary.invoke(messages_p, &opts_p).await },
            move || async move { backup.invoke(messages, &opts_b).await },
            self.hedge_delay,
        )
        .await
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // Streams aren't hedged (see doc above). Pass through to primary.
        self.primary.stream(messages, opts).await
    }
}

/// Embed-axis sibling. Hedges both `embed_query` and
/// `embed_documents` against the backup embedder. Backup is
/// only invoked when the primary call exceeds `hedge_delay`.
pub struct HedgedEmbeddings {
    pub primary: Arc<dyn Embeddings>,
    pub backup: Arc<dyn Embeddings>,
    pub hedge_delay: Duration,
}

impl HedgedEmbeddings {
    pub fn new(
        primary: Arc<dyn Embeddings>,
        backup: Arc<dyn Embeddings>,
        hedge_delay: Duration,
    ) -> Self {
        Self {
            primary,
            backup,
            hedge_delay,
        }
    }
}

#[async_trait]
impl Embeddings for HedgedEmbeddings {
    fn name(&self) -> &str {
        self.primary.name()
    }
    fn dimensions(&self) -> usize {
        self.primary.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let primary = self.primary.clone();
        let backup = self.backup.clone();
        let text_p = text.to_owned();
        let text_b = text.to_owned();
        hedged_call(
            move || async move { primary.embed_query(&text_p).await },
            move || async move { backup.embed_query(&text_b).await },
            self.hedge_delay,
        )
        .await
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let primary = self.primary.clone();
        let backup = self.backup.clone();
        let texts_p = texts.to_vec();
        let texts_b = texts.to_vec();
        hedged_call(
            move || async move { primary.embed_documents(&texts_p).await },
            move || async move { backup.embed_documents(&texts_b).await },
            self.hedge_delay,
        )
        .await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// BulkheadChatModel — concurrent-call cap with rejection
// ─────────────────────────────────────────────────────────────────────────────

/// How an over-cap caller is handled when the [`Bulkhead`] is
/// saturated.
#[derive(Debug, Clone)]
pub enum BulkheadMode {
    /// Reject immediately. The call returns
    /// `Error::RateLimited { retry_after_ms: None }` so existing
    /// retry / fallback wrappers treat it as transient.
    Reject,
    /// Block up to `Duration` for a slot, then reject.
    WaitUpTo(Duration),
}

/// Wrap any [`ChatModel`] so concurrent calls share a [`Bulkhead`]
/// budget. Bridges the iter-248 primitive into the resilience
/// family.
///
/// # Why this exists
///
/// Many provider APIs (and self-hosted GPU servers) handle a
/// fixed number of concurrent requests gracefully and queue
/// the rest indefinitely. Indefinite queueing is the wrong
/// failure mode for an interactive UI — the user wants either
/// a fast answer or a fast "this provider is hot, switching
/// to a backup." `BulkheadChatModel` enforces the cap and
/// rejects with `Error::RateLimited`.
///
/// Composition: `Error::RateLimited` is what the existing
/// `is_transient` classifier matches, so:
/// - `RetryingChatModel` outer retries with backoff (slot may
///   open).
/// - `FallbackChatModel` outer switches to a backup provider.
/// - Both interactions just work, no extra wiring.
///
/// # Sharing across wrappers
///
/// Pass the same `Arc<Bulkhead>` to multiple
/// `BulkheadChatModel` wrappers to enforce one cap across many
/// model variants. Realistic prod pattern: gpt-4 / gpt-4o-mini /
/// gpt-4-turbo on one OpenAI key share a 10-concurrent budget.
///
/// # Streaming
///
/// `stream()` enters the bulkhead at the handshake. The slot
/// releases when this method returns (the caller drives the
/// stream itself). For per-stream-lifetime exclusion, hold the
/// guard externally around the `stream` + `drain` cycle.
pub struct BulkheadChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub bulkhead: Arc<Bulkhead>,
    pub mode: BulkheadMode,
}

impl BulkheadChatModel {
    pub fn new(
        inner: Arc<dyn ChatModel>,
        bulkhead: Arc<Bulkhead>,
        mode: BulkheadMode,
    ) -> Self {
        Self {
            inner,
            bulkhead,
            mode,
        }
    }

    async fn enter(&self) -> Option<litgraph_core::BulkheadGuard> {
        match self.mode {
            BulkheadMode::Reject => self.bulkhead.try_enter(),
            BulkheadMode::WaitUpTo(d) => self.bulkhead.enter_with_timeout(d).await,
        }
    }
}

#[async_trait]
impl ChatModel for BulkheadChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let _guard = match self.enter().await {
            Some(g) => g,
            None => return Err(Error::RateLimited { retry_after_ms: None }),
        };
        self.inner.invoke(messages, opts).await
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        let _guard = match self.enter().await {
            Some(g) => g,
            None => return Err(Error::RateLimited { retry_after_ms: None }),
        };
        self.inner.stream(messages, opts).await
    }
}

/// Embed-axis sibling. Same shared-budget + reject-or-wait
/// semantics; one Bulkhead can span both `embed_query` and
/// `embed_documents`, and (when the same `Arc<Bulkhead>` is
/// passed) across chat + embed wrappers.
pub struct BulkheadEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    pub bulkhead: Arc<Bulkhead>,
    pub mode: BulkheadMode,
}

impl BulkheadEmbeddings {
    pub fn new(
        inner: Arc<dyn Embeddings>,
        bulkhead: Arc<Bulkhead>,
        mode: BulkheadMode,
    ) -> Self {
        Self {
            inner,
            bulkhead,
            mode,
        }
    }

    async fn enter(&self) -> Option<litgraph_core::BulkheadGuard> {
        match self.mode {
            BulkheadMode::Reject => self.bulkhead.try_enter(),
            BulkheadMode::WaitUpTo(d) => self.bulkhead.enter_with_timeout(d).await,
        }
    }
}

#[async_trait]
impl Embeddings for BulkheadEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let _guard = match self.enter().await {
            Some(g) => g,
            None => return Err(Error::RateLimited { retry_after_ms: None }),
        };
        self.inner.embed_query(text).await
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let _guard = match self.enter().await {
            Some(g) => g,
            None => return Err(Error::RateLimited { retry_after_ms: None }),
        };
        self.inner.embed_documents(texts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MetricsChatModel + MetricsEmbeddings — auto-instrumentation wrappers
// ─────────────────────────────────────────────────────────────────────────────

/// Default histogram buckets in seconds. Geometric-ish spread
/// covering the typical LLM/embed latency range from 5ms to 30s.
pub const DEFAULT_LATENCY_BUCKETS_SECS: &[f64] = &[
    0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0,
];

/// Pre-resolved metric handles so the hot path is pure atomic
/// ops (no HashMap lookup).
struct MetricsHandles {
    invocations: Arc<Counter>,
    errors: Arc<Counter>,
    in_flight: Arc<Gauge>,
    latency: Arc<Histogram>,
}

/// RAII guard that decrements the in-flight gauge on drop. This
/// makes the gauge correct even if the inner future panics or is
/// cancelled mid-await.
struct InFlightGuard {
    gauge: Arc<Gauge>,
}

impl Drop for InFlightGuard {
    fn drop(&mut self) {
        self.gauge.dec();
    }
}

fn resolve_handles(
    registry: &MetricsRegistry,
    prefix: &str,
    buckets: &[f64],
) -> MetricsHandles {
    MetricsHandles {
        invocations: registry.counter(&format!("{prefix}_invocations_total")),
        errors: registry.counter(&format!("{prefix}_errors_total")),
        in_flight: registry.gauge(&format!("{prefix}_in_flight")),
        latency: registry.histogram(
            &format!("{prefix}_latency_seconds"),
            buckets,
        ),
    }
}

/// Wrap any [`ChatModel`] with auto-instrumentation against an
/// iter-260 [`MetricsRegistry`]. Bumps the standard four
/// metrics on every `invoke`:
///
/// - `<prefix>_invocations_total` — counter, every call.
/// - `<prefix>_errors_total` — counter, calls that returned `Err`.
/// - `<prefix>_in_flight` — gauge, current concurrent calls
///   (incremented on entry, decremented on exit via RAII guard
///   so it stays correct under cancellation/panic).
/// - `<prefix>_latency_seconds` — histogram of `Instant::elapsed`
///   across the inner call.
///
/// Default prefix: `"chat"`. Override with `with_prefix`.
/// Default histogram buckets: [`DEFAULT_LATENCY_BUCKETS_SECS`].
/// Override with `with_buckets`.
///
/// Metric handles are resolved once at construction via the
/// registry's get-or-create lookup, so the hot path is pure
/// atomic ops — no HashMap lookup per call.
///
/// # Streaming
///
/// `stream()` records the same metrics at the **handshake**:
/// invocations / errors / latency reflect the time until
/// `stream()` returns its outer Result, not the time the inner
/// stream takes to drain. In-flight is incremented before
/// handshake and decremented before stream() returns —
/// per-token timing is the consumer's responsibility (typical
/// patten: caller wraps `s.next()` with its own timing).
pub struct MetricsChatModel {
    pub inner: Arc<dyn ChatModel>,
    handles: MetricsHandles,
}

impl MetricsChatModel {
    pub fn new(inner: Arc<dyn ChatModel>, registry: &MetricsRegistry) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, "chat", DEFAULT_LATENCY_BUCKETS_SECS),
        }
    }

    pub fn with_prefix(
        inner: Arc<dyn ChatModel>,
        registry: &MetricsRegistry,
        prefix: &str,
    ) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, prefix, DEFAULT_LATENCY_BUCKETS_SECS),
        }
    }

    pub fn with_buckets(
        inner: Arc<dyn ChatModel>,
        registry: &MetricsRegistry,
        prefix: &str,
        buckets: &[f64],
    ) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, prefix, buckets),
        }
    }
}

#[async_trait]
impl ChatModel for MetricsChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        self.handles.invocations.inc();
        self.handles.in_flight.inc();
        let _guard = InFlightGuard {
            gauge: self.handles.in_flight.clone(),
        };
        let started = std::time::Instant::now();
        let r = self.inner.invoke(messages, opts).await;
        self.handles
            .latency
            .observe(started.elapsed().as_secs_f64());
        if r.is_err() {
            self.handles.errors.inc();
        }
        r
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        self.handles.invocations.inc();
        self.handles.in_flight.inc();
        let _guard = InFlightGuard {
            gauge: self.handles.in_flight.clone(),
        };
        let started = std::time::Instant::now();
        let r = self.inner.stream(messages, opts).await;
        self.handles
            .latency
            .observe(started.elapsed().as_secs_f64());
        if r.is_err() {
            self.handles.errors.inc();
        }
        r
    }
}

/// Embed-axis sibling. Same four-metric instrumentation; default
/// prefix is `"embed"`. Both `embed_query` and `embed_documents`
/// share the metrics — distinguish in caller code if you need
/// per-method breakdown.
pub struct MetricsEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    handles: MetricsHandles,
}

impl MetricsEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>, registry: &MetricsRegistry) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, "embed", DEFAULT_LATENCY_BUCKETS_SECS),
        }
    }

    pub fn with_prefix(
        inner: Arc<dyn Embeddings>,
        registry: &MetricsRegistry,
        prefix: &str,
    ) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, prefix, DEFAULT_LATENCY_BUCKETS_SECS),
        }
    }

    pub fn with_buckets(
        inner: Arc<dyn Embeddings>,
        registry: &MetricsRegistry,
        prefix: &str,
        buckets: &[f64],
    ) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, prefix, buckets),
        }
    }
}

#[async_trait]
impl Embeddings for MetricsEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        self.handles.invocations.inc();
        self.handles.in_flight.inc();
        let _guard = InFlightGuard {
            gauge: self.handles.in_flight.clone(),
        };
        let started = std::time::Instant::now();
        let r = self.inner.embed_query(text).await;
        self.handles
            .latency
            .observe(started.elapsed().as_secs_f64());
        if r.is_err() {
            self.handles.errors.inc();
        }
        r
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        self.handles.invocations.inc();
        self.handles.in_flight.inc();
        let _guard = InFlightGuard {
            gauge: self.handles.in_flight.clone(),
        };
        let started = std::time::Instant::now();
        let r = self.inner.embed_documents(texts).await;
        self.handles
            .latency
            .observe(started.elapsed().as_secs_f64());
        if r.is_err() {
            self.handles.errors.inc();
        }
        r
    }
}

/// Wrap any [`litgraph_core::tool::Tool`] with auto-instrumentation
/// against an iter-260 [`MetricsRegistry`]. Same four metrics as
/// [`MetricsChatModel`] / [`MetricsEmbeddings`]: `<prefix>_invocations_total`,
/// `<prefix>_errors_total`, `<prefix>_in_flight`, `<prefix>_latency_seconds`.
///
/// Default prefix is the tool's own name (from its schema), with
/// disallowed characters sanitized to `_`. So a tool named `"http.get"`
/// produces metrics under `http_get_*`. Override with `with_prefix`
/// for explicit per-call-site labeling.
///
/// Metric handles are pre-resolved at construction so the hot path is
/// pure atomic ops — same design as iter 261.
///
/// Per-tool metrics are especially valuable for agent debugging: agents
/// make many tool calls per session, and knowing which tools fail /
/// are slow / are hot is the first thing you want from a `/metrics`
/// dashboard.
pub struct MetricsTool {
    pub inner: Arc<dyn litgraph_core::tool::Tool>,
    handles: MetricsHandles,
}

impl MetricsTool {
    pub fn new(
        inner: Arc<dyn litgraph_core::tool::Tool>,
        registry: &MetricsRegistry,
    ) -> Self {
        let prefix = sanitize_metric_prefix(&inner.name());
        Self {
            inner,
            handles: resolve_handles(registry, &prefix, DEFAULT_LATENCY_BUCKETS_SECS),
        }
    }

    pub fn with_prefix(
        inner: Arc<dyn litgraph_core::tool::Tool>,
        registry: &MetricsRegistry,
        prefix: &str,
    ) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, prefix, DEFAULT_LATENCY_BUCKETS_SECS),
        }
    }

    pub fn with_buckets(
        inner: Arc<dyn litgraph_core::tool::Tool>,
        registry: &MetricsRegistry,
        prefix: &str,
        buckets: &[f64],
    ) -> Self {
        Self {
            inner,
            handles: resolve_handles(registry, prefix, buckets),
        }
    }
}

#[async_trait]
impl litgraph_core::tool::Tool for MetricsTool {
    fn schema(&self) -> litgraph_core::tool::ToolSchema {
        self.inner.schema()
    }

    async fn run(
        &self,
        args: serde_json::Value,
    ) -> Result<serde_json::Value> {
        self.handles.invocations.inc();
        self.handles.in_flight.inc();
        let _guard = InFlightGuard {
            gauge: self.handles.in_flight.clone(),
        };
        let started = std::time::Instant::now();
        let r = self.inner.run(args).await;
        self.handles
            .latency
            .observe(started.elapsed().as_secs_f64());
        if r.is_err() {
            self.handles.errors.inc();
        }
        r
    }
}

/// Sanitize a tool name into a Prometheus-compatible metric prefix.
/// Mirrors the rules used by `MetricsRegistry::to_prometheus` so the
/// same allowed-character set applies. Returns "tool" if the input
/// produces an empty result (defensive default).
fn sanitize_metric_prefix(name: &str) -> String {
    let mut out = String::with_capacity(name.len());
    for (i, c) in name.chars().enumerate() {
        let ok = if i == 0 {
            c.is_ascii_alphabetic() || c == '_'
        } else {
            c.is_ascii_alphanumeric() || c == '_' || c == ':'
        };
        out.push(if ok { c } else { '_' });
    }
    if out.is_empty() {
        "tool".into()
    } else {
        out
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// KeyedSerializedChatModel — per-key step lock for stateful agents
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any [`ChatModel`] so calls sharing the same key serialize
/// against each other; calls with different keys run in parallel.
/// Bridges the iter-241 [`KeyedMutex`] primitive into the
/// resilience family.
///
/// # Why this exists
///
/// A stateful agent's ReAct loop reads-then-writes shared
/// conversation state per `thread_id`. Two concurrent steps for
/// the same thread interleave their reads/writes and corrupt the
/// state. A single global mutex fixes correctness but serializes
/// EVERYONE — a thousand different threads run one-at-a-time.
///
/// `KeyedSerializedChatModel` lifts the per-thread ReAct-step lock
/// into the model wrapper layer: same `thread_id` queues, different
/// `thread_id`s run concurrently.
///
/// # Key extraction
///
/// The constructor takes a `key_fn: impl Fn(&[Message],
/// &ChatOptions) -> Option<String>`. Returning `None` means "no
/// serialization for this call" (passes through). Typical
/// extractor: `|_, opts| opts.metadata.get("thread_id").cloned()`.
///
/// `String` is fixed as the key type — most prod keys (thread IDs,
/// user IDs, document IDs) stringify naturally and dyn-trait
/// fungibility is more important than generic-K flexibility here.
///
/// # Streaming
///
/// `stream()` acquires the lock, calls the inner `stream()`, and
/// IMPORTANTLY drops the lock when this method returns — NOT
/// when the stream finishes. The caller drives the stream after
/// the handshake, so the lock must release at handshake to allow
/// other same-key calls to queue. If you need per-step exclusion
/// across the whole stream lifetime, hold the lock externally
/// around the `stream` + `drain` cycle.
pub struct KeyedSerializedChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub registry: Arc<KeyedMutex<String>>,
    key_fn: Arc<dyn Fn(&[Message], &ChatOptions) -> Option<String> + Send + Sync>,
}

impl KeyedSerializedChatModel {
    pub fn new<F>(
        inner: Arc<dyn ChatModel>,
        registry: Arc<KeyedMutex<String>>,
        key_fn: F,
    ) -> Self
    where
        F: Fn(&[Message], &ChatOptions) -> Option<String> + Send + Sync + 'static,
    {
        Self {
            inner,
            registry,
            key_fn: Arc::new(key_fn),
        }
    }
}

#[async_trait]
impl ChatModel for KeyedSerializedChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let key = (self.key_fn)(&messages, opts);
        if let Some(k) = key {
            let _guard = self.registry.lock(k).await;
            self.inner.invoke(messages, opts).await
        } else {
            self.inner.invoke(messages, opts).await
        }
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        let key = (self.key_fn)(&messages, opts);
        if let Some(k) = key {
            // Hold the lock only for the handshake (see doc above).
            let _guard = self.registry.lock(k).await;
            self.inner.stream(messages, opts).await
        } else {
            self.inner.stream(messages, opts).await
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SharedRateLimitedChatModel — one bucket, many wrapped models
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any [`ChatModel`] so each call charges against a SHARED
/// [`RateLimiter`] (iter 242). Distinct from
/// [`RateLimitedChatModel`] which owns its own bucket: this
/// takes an `Arc<RateLimiter>` so multiple wrapped models can
/// charge against ONE budget.
///
/// # Why this exists
///
/// One provider API key typically has ONE quota (TPM/RPM) shared
/// across every model variant served by that key. The realistic
/// prod pattern: a router that dispatches to gpt-4, gpt-4-turbo,
/// gpt-4o-mini based on heuristics — all three calls draw from
/// the same key's TPM. With per-model `RateLimitedChatModel`
/// each variant has its own bucket and the aggregate exceeds
/// the real budget. With this wrapper they all charge against
/// one shared `RateLimiter`.
///
/// Per-call weight is fixed at 1 token (one request charge) by
/// default. For weight-by-tokens-estimate use cases, wrap with
/// a custom adapter or call `limiter.acquire(estimate).await`
/// directly upstream. We pick 1-token-per-request as the
/// minimum-surprise default.
///
/// # Streaming
///
/// `stream()` charges 1 token at handshake, same as `invoke`.
/// Mid-stream tokens don't deduct further.
pub struct SharedRateLimitedChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub limiter: Arc<RateLimiter>,
}

impl SharedRateLimitedChatModel {
    pub fn new(inner: Arc<dyn ChatModel>, limiter: Arc<RateLimiter>) -> Self {
        Self { inner, limiter }
    }
}

#[async_trait]
impl ChatModel for SharedRateLimitedChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        self.limiter.acquire(1).await;
        self.inner.invoke(messages, opts).await
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        self.limiter.acquire(1).await;
        self.inner.stream(messages, opts).await
    }
}

/// Embed-axis sibling. Both `embed_query` and `embed_documents`
/// charge 1 token per call against the shared bucket. For
/// chunked-embedding pipelines, charge once per chunk (not per
/// document) by sizing your bucket accordingly — `RateLimiter`
/// is request-count agnostic.
pub struct SharedRateLimitedEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    pub limiter: Arc<RateLimiter>,
}

impl SharedRateLimitedEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>, limiter: Arc<RateLimiter>) -> Self {
        Self { inner, limiter }
    }
}

#[async_trait]
impl Embeddings for SharedRateLimitedEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        self.limiter.acquire(1).await;
        self.inner.embed_query(text).await
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        self.limiter.acquire(1).await;
        self.inner.embed_documents(texts).await
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CircuitBreakerEmbeddings — embed-side mirror of CircuitBreakerChatModel
// ─────────────────────────────────────────────────────────────────────────────

/// Wrap any [`Embeddings`] with a [`CircuitBreaker`] so persistent
/// upstream failures stop bleeding load against a sick service.
/// Embed-axis mirror of [`CircuitBreakerChatModel`].
///
/// Same composition story: stack with [`FallbackEmbeddings`] so
/// circuit-open routes immediately to the secondary embedder.
/// Both `embed_query` and `embed_documents` admission-gate
/// through the breaker; one shared breaker covers both call
/// shapes so a flapping query path also opens the breaker for
/// document indexing (and vice-versa).
pub struct CircuitBreakerEmbeddings {
    pub inner: Arc<dyn Embeddings>,
    pub breaker: Arc<CircuitBreaker>,
}

impl CircuitBreakerEmbeddings {
    pub fn new(inner: Arc<dyn Embeddings>, breaker: Arc<CircuitBreaker>) -> Self {
        Self { inner, breaker }
    }
}

#[async_trait]
impl Embeddings for CircuitBreakerEmbeddings {
    fn name(&self) -> &str {
        self.inner.name()
    }
    fn dimensions(&self) -> usize {
        self.inner.dimensions()
    }

    async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
        let inner = self.inner.clone();
        let text = text.to_owned();
        let r = self
            .breaker
            .call(move || async move { inner.embed_query(&text).await })
            .await;
        match r {
            Ok(v) => Ok(v),
            Err(CircuitCallError::CircuitOpen) => {
                Err(Error::Provider("circuit breaker open".into()))
            }
            Err(CircuitCallError::Inner(e)) => Err(e),
        }
    }

    async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
        let inner = self.inner.clone();
        let texts = texts.to_vec();
        let r = self
            .breaker
            .call(move || async move { inner.embed_documents(&texts).await })
            .await;
        match r {
            Ok(v) => Ok(v),
            Err(CircuitCallError::CircuitOpen) => {
                Err(Error::Provider("circuit breaker open".into()))
            }
            Err(CircuitCallError::Inner(e)) => Err(e),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PII scrubbing chat wrapper
// ─────────────────────────────────────────────────────────────────────────────

/// Chat-model wrapper that redacts PII before sending prompts to the
/// inner provider and (optionally) redacts PII from the response text.
///
/// # Why
///
/// - **GDPR / CCPA** — sending raw user emails / phones / SSNs to a
///   third-party LLM vendor without a DPA is an audit finding.
/// - **Prompt-injection hygiene** — AWS keys and JWTs inadvertently
///   pasted by users get scrubbed before the model sees them; reduces
///   exfiltration blast radius.
/// - **Observability safety** — if this wrapper sits between the user
///   and the provider, downstream logging / tracing sees redacted
///   prompts, not raw PII.
///
/// # Default behavior
///
/// - `scrub_inputs = true` — redact outgoing user + system messages.
///   Assistant / tool messages are NOT touched (they came from the
///   model or tool, and re-scrubbing would corrupt agent traces).
/// - `scrub_outputs = false` — leave LLM responses as-is. Real-world
///   LLMs rarely leak PII (they didn't see it); output-scrubbing is
///   off by default to avoid mangling code blocks that contain
///   email-like or IP-like strings. Opt in with `.with_output_scrubbing()`
///   for strict environments.
/// - `scrub_system = false` — system prompts are operator-written and
///   usually contain no real PII. Off by default; opt in if you inject
///   user data into system messages.
///
/// # Note on streaming
///
/// `stream()` currently scrubs inputs but does NOT scrub token deltas.
/// Token-by-token scrubbing would require a streaming PII parser that
/// handles span boundaries — out of scope here. Full-string output
/// scrubbing still works at the final `Done` event if the consumer
/// reassembles the response and passes it through `PiiScrubber::scrub`.
///
/// # Composition
///
/// Stack with other wrappers freely: `Retry(Budget(Scrub(inner)))` is
/// typical — scrub innermost so retries don't re-scrub (CPU waste) and
/// the budget + retry counts apply to the scrubbed payload.
pub struct PiiScrubbingChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub scrubber: Arc<PiiScrubber>,
    pub scrub_inputs: bool,
    pub scrub_system: bool,
    pub scrub_outputs: bool,
}

impl PiiScrubbingChatModel {
    /// Build with the default PiiScrubber (all iter-129 detectors).
    pub fn new(inner: Arc<dyn ChatModel>) -> Self {
        Self {
            inner,
            scrubber: Arc::new(PiiScrubber::new()),
            scrub_inputs: true,
            scrub_system: false,
            scrub_outputs: false,
        }
    }

    /// Build with a caller-provided scrubber (e.g. with custom patterns
    /// or `.without_luhn()` for test environments).
    pub fn with_scrubber(mut self, scrubber: Arc<PiiScrubber>) -> Self {
        self.scrubber = scrubber;
        self
    }

    pub fn with_output_scrubbing(mut self) -> Self {
        self.scrub_outputs = true;
        self
    }

    pub fn with_system_scrubbing(mut self) -> Self {
        self.scrub_system = true;
        self
    }

    pub fn scrub_inputs(mut self, on: bool) -> Self {
        self.scrub_inputs = on;
        self
    }

    /// Scrub a Message's text content IN PLACE. Non-text ContentParts
    /// (images, audio) are untouched — we only mask string PII.
    /// Returns the new Message.
    fn scrub_message(&self, m: &Message) -> Message {
        use litgraph_core::Role;
        // Skip roles where scrubbing is off or doesn't make sense.
        let should_scrub = match m.role {
            Role::User => self.scrub_inputs,
            Role::System => self.scrub_inputs && self.scrub_system,
            // Assistant / Tool messages preserve the model's / tool's output.
            Role::Assistant | Role::Tool => false,
        };
        if !should_scrub {
            return m.clone();
        }
        let new_parts: Vec<ContentPart> = m
            .content
            .iter()
            .map(|p| match p {
                ContentPart::Text { text } => {
                    let scrubbed = self.scrubber.scrub(text).scrubbed;
                    ContentPart::Text { text: scrubbed }
                }
                other => other.clone(),
            })
            .collect();
        Message {
            role: m.role,
            content: new_parts,
            tool_calls: m.tool_calls.clone(),
            tool_call_id: m.tool_call_id.clone(),
            name: m.name.clone(),
            cache: m.cache,
        }
    }

    fn scrub_all(&self, messages: Vec<Message>) -> Vec<Message> {
        if !self.scrub_inputs {
            return messages;
        }
        messages.iter().map(|m| self.scrub_message(m)).collect()
    }

    fn scrub_response_text(&self, mut resp: ChatResponse) -> ChatResponse {
        if !self.scrub_outputs {
            return resp;
        }
        let new_parts: Vec<ContentPart> = resp
            .message
            .content
            .into_iter()
            .map(|p| match p {
                ContentPart::Text { text } => {
                    let scrubbed = self.scrubber.scrub(&text).scrubbed;
                    ContentPart::Text { text: scrubbed }
                }
                other => other,
            })
            .collect();
        resp.message.content = new_parts;
        resp
    }
}

#[async_trait]
impl ChatModel for PiiScrubbingChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let scrubbed = self.scrub_all(messages);
        let resp = self.inner.invoke(scrubbed, opts).await?;
        Ok(self.scrub_response_text(resp))
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // Scrub inputs but pass stream through as-is (token-delta
        // scrubbing is out of scope — see the module doc).
        let scrubbed = self.scrub_all(messages);
        self.inner.stream(scrubbed, opts).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use litgraph_core::model::{ChatStream, FinishReason, TokenUsage};
    use litgraph_core::tool::Tool as _;
    use litgraph_core::{ContentPart, Message, Role};
    use std::sync::atomic::{AtomicU32, Ordering};

    /// Errors first N calls, then succeeds.
    struct FlakyModel {
        fails_remaining: AtomicU32,
        kind: ErrKind,
    }

    enum ErrKind {
        RateLimited,
        Provider5xx,
        BadRequest,
    }

    #[async_trait]
    impl ChatModel for FlakyModel {
        fn name(&self) -> &str { "flaky" }
        async fn invoke(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatResponse> {
            let n = self.fails_remaining.load(Ordering::SeqCst);
            if n > 0 {
                self.fails_remaining.fetch_sub(1, Ordering::SeqCst);
                return Err(match self.kind {
                    ErrKind::RateLimited => Error::RateLimited { retry_after_ms: None },
                    ErrKind::Provider5xx => Error::provider("502 bad gateway"),
                    ErrKind::BadRequest  => Error::invalid("bad request"),
                });
            }
            Ok(ChatResponse {
                message: Message {
                    role: Role::Assistant,
                    content: vec![ContentPart::Text { text: "ok".into() }],
                    tool_calls: vec![], tool_call_id: None, name: None, cache: false,
                },
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "flaky".into(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    fn quick_cfg() -> RetryConfig {
        RetryConfig { min_delay: Duration::from_millis(1), max_delay: Duration::from_millis(10),
                      factor: 2.0, max_times: 5, jitter: false }
    }

    #[tokio::test]
    async fn retries_rate_limited_then_succeeds() {
        let inner: Arc<dyn ChatModel> = Arc::new(FlakyModel {
            fails_remaining: AtomicU32::new(2), kind: ErrKind::RateLimited,
        });
        let r = RetryingChatModel::new(inner, quick_cfg());
        let resp = r.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "ok");
    }

    #[tokio::test]
    async fn retries_5xx_then_succeeds() {
        let inner: Arc<dyn ChatModel> = Arc::new(FlakyModel {
            fails_remaining: AtomicU32::new(3), kind: ErrKind::Provider5xx,
        });
        let r = RetryingChatModel::new(inner, quick_cfg());
        let resp = r.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "ok");
    }

    #[tokio::test]
    async fn does_not_retry_bad_request() {
        let inner: Arc<dyn ChatModel> = Arc::new(FlakyModel {
            fails_remaining: AtomicU32::new(10), kind: ErrKind::BadRequest,
        });
        let r = RetryingChatModel::new(inner, quick_cfg());
        let err = r.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap_err();
        assert!(matches!(err, Error::InvalidInput(_)));
    }

    #[tokio::test]
    async fn gives_up_after_max_attempts() {
        let inner: Arc<dyn ChatModel> = Arc::new(FlakyModel {
            fails_remaining: AtomicU32::new(100), kind: ErrKind::RateLimited,
        });
        let r = RetryingChatModel::new(inner, quick_cfg());
        let err = r.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap_err();
        assert!(matches!(err, Error::RateLimited { .. }));
    }

    /// Always-succeeds model that counts how many times it was hit.
    struct CountingModel { calls: AtomicU32 }

    #[async_trait]
    impl ChatModel for CountingModel {
        fn name(&self) -> &str { "count" }
        async fn invoke(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatResponse> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            Ok(ChatResponse {
                message: Message {
                    role: Role::Assistant,
                    content: vec![ContentPart::Text { text: "ok".into() }],
                    tool_calls: vec![], tool_call_id: None, name: None, cache: false,
                },
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "count".into(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test(start_paused = true)]
    async fn rate_limiter_serves_burst_immediately_then_throttles() {
        let inner: Arc<dyn ChatModel> = Arc::new(CountingModel { calls: AtomicU32::new(0) });
        // 60 RPM = 1 RPS, burst of 3.
        let r = RateLimitedChatModel::new(inner.clone(),
            RateLimitConfig::per_minute(60).with_burst(3));
        let start = tokio::time::Instant::now();
        // Burst of 3 should drain immediately.
        for _ in 0..3 {
            r.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap();
        }
        assert!(start.elapsed() < Duration::from_millis(50),
            "burst should be near-instant, took {:?}", start.elapsed());
        // 4th call must wait ~1s for the next refill.
        r.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap();
        let elapsed = start.elapsed();
        assert!(elapsed >= Duration::from_millis(990) && elapsed < Duration::from_millis(1500),
            "4th call should wait ~1s, took {:?}", elapsed);
    }

    #[tokio::test(start_paused = true)]
    async fn rate_limiter_steady_state_matches_configured_rate() {
        let inner: Arc<dyn ChatModel> = Arc::new(CountingModel { calls: AtomicU32::new(0) });
        // 120 RPM = 2 RPS, no burst (=1) → strict 1-every-500ms cadence.
        let r = RateLimitedChatModel::new(inner.clone(),
            RateLimitConfig::per_minute(120).with_burst(1));
        let start = tokio::time::Instant::now();
        // 4 calls @ 2 RPS w/ burst=1 → first instant, then 500/1000/1500ms.
        for _ in 0..4 {
            r.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap();
        }
        let total = start.elapsed();
        assert!(total >= Duration::from_millis(1490) && total < Duration::from_millis(2000),
            "4 calls @ 2 RPS should take ~1.5s, took {:?}", total);
    }

    // ---- FallbackChatModel tests ----------------------------------------

    /// Deterministic model that records its name on every call and either
    /// errors or returns success based on the constructor.
    struct CannedModel {
        label: &'static str,
        result: CannedResult,
        called: AtomicU32,
    }

    enum CannedResult {
        Ok,
        RateLimited,
        Provider5xx,
        BadRequest,
    }

    #[async_trait]
    impl ChatModel for CannedModel {
        fn name(&self) -> &str {
            self.label
        }
        async fn invoke(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatResponse> {
            self.called.fetch_add(1, Ordering::SeqCst);
            match self.result {
                CannedResult::Ok => Ok(ChatResponse {
                    message: Message::assistant(self.label.to_string()),
                    finish_reason: FinishReason::Stop,
                    usage: TokenUsage::default(),
                    model: self.label.to_string(),
                }),
                CannedResult::RateLimited => Err(Error::RateLimited { retry_after_ms: None }),
                CannedResult::Provider5xx => Err(Error::provider("503 service unavailable")),
                CannedResult::BadRequest => Err(Error::invalid("malformed prompt")),
            }
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    fn canned(label: &'static str, result: CannedResult) -> Arc<CannedModel> {
        Arc::new(CannedModel {
            label,
            result,
            called: AtomicU32::new(0),
        })
    }

    #[tokio::test]
    async fn fallback_uses_primary_when_it_succeeds() {
        let primary = canned("primary", CannedResult::Ok);
        let backup = canned("backup", CannedResult::Ok);
        let chain = FallbackChatModel::new(vec![
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
        ]);
        let resp = chain.invoke(vec![], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "primary");
        assert_eq!(primary.called.load(Ordering::SeqCst), 1);
        assert_eq!(backup.called.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn fallback_falls_through_on_rate_limit() {
        let primary = canned("primary", CannedResult::RateLimited);
        let backup = canned("backup", CannedResult::Ok);
        let chain = FallbackChatModel::new(vec![
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
        ]);
        let resp = chain.invoke(vec![], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "backup");
        assert_eq!(primary.called.load(Ordering::SeqCst), 1);
        assert_eq!(backup.called.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn fallback_falls_through_on_5xx() {
        let primary = canned("primary", CannedResult::Provider5xx);
        let backup = canned("backup", CannedResult::Ok);
        let chain = FallbackChatModel::new(vec![
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
        ]);
        let resp = chain.invoke(vec![], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "backup");
    }

    #[tokio::test]
    async fn fallback_propagates_terminal_error_by_default() {
        // Bad request — same prompt would fail on backup too. Default is
        // fail-fast (don't waste tokens trying provider B).
        let primary = canned("primary", CannedResult::BadRequest);
        let backup = canned("backup", CannedResult::Ok);
        let chain = FallbackChatModel::new(vec![
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
        ]);
        let err = chain.invoke(vec![], &ChatOptions::default()).await.unwrap_err();
        assert!(matches!(err, Error::InvalidInput(_)));
        assert_eq!(primary.called.load(Ordering::SeqCst), 1);
        assert_eq!(backup.called.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn fallback_with_fall_through_on_all_tries_backup_on_terminal_too() {
        let primary = canned("primary", CannedResult::BadRequest);
        let backup = canned("backup", CannedResult::Ok);
        let chain = FallbackChatModel::new(vec![
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
        ])
        .fall_through_on_all();
        let resp = chain.invoke(vec![], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "backup");
        assert_eq!(primary.called.load(Ordering::SeqCst), 1);
        assert_eq!(backup.called.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn fallback_propagates_last_error_when_all_models_fail() {
        let p = canned("p", CannedResult::RateLimited);
        let b1 = canned("b1", CannedResult::Provider5xx);
        let b2 = canned("b2", CannedResult::RateLimited);
        let chain = FallbackChatModel::new(vec![
            p.clone() as Arc<dyn ChatModel>,
            b1.clone() as Arc<dyn ChatModel>,
            b2.clone() as Arc<dyn ChatModel>,
        ]);
        let err = chain.invoke(vec![], &ChatOptions::default()).await.unwrap_err();
        // Last error (b2's RateLimited) is what surfaces.
        assert!(matches!(err, Error::RateLimited { .. }));
        assert_eq!(p.called.load(Ordering::SeqCst), 1);
        assert_eq!(b1.called.load(Ordering::SeqCst), 1);
        assert_eq!(b2.called.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn fallback_walks_chain_until_one_succeeds() {
        let p = canned("p", CannedResult::RateLimited);
        let b1 = canned("b1", CannedResult::Provider5xx);
        let b2 = canned("b2", CannedResult::Ok);
        let chain = FallbackChatModel::new(vec![
            p.clone() as Arc<dyn ChatModel>,
            b1.clone() as Arc<dyn ChatModel>,
            b2.clone() as Arc<dyn ChatModel>,
        ]);
        let resp = chain.invoke(vec![], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "b2");
        assert_eq!(p.called.load(Ordering::SeqCst), 1);
        assert_eq!(b1.called.load(Ordering::SeqCst), 1);
        assert_eq!(b2.called.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    #[should_panic(expected = "chain must have at least one model")]
    async fn fallback_panics_on_empty_chain() {
        let _ = FallbackChatModel::new(vec![]);
    }

    // ---- RaceChatModel tests ----------------------------------------------

    /// Sleeps `delay_ms` then either returns a labelled response or errors.
    struct DelayedModel {
        label: &'static str,
        delay_ms: u64,
        succeed: bool,
        invocations: Arc<std::sync::atomic::AtomicUsize>,
    }

    #[async_trait]
    impl ChatModel for DelayedModel {
        fn name(&self) -> &str {
            self.label
        }
        async fn invoke(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatResponse> {
            self.invocations
                .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            if self.succeed {
                Ok(ChatResponse {
                    message: Message {
                        role: Role::Assistant,
                        content: vec![ContentPart::Text {
                            text: self.label.into(),
                        }],
                        tool_calls: vec![],
                        tool_call_id: None,
                        name: None,
                        cache: false,
                    },
                    finish_reason: FinishReason::Stop,
                    usage: TokenUsage::default(),
                    model: self.label.into(),
                })
            } else {
                Err(Error::provider(format!("{} failed", self.label)))
            }
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    fn arc_dm(
        label: &'static str,
        delay_ms: u64,
        succeed: bool,
    ) -> (Arc<dyn ChatModel>, Arc<std::sync::atomic::AtomicUsize>) {
        let count = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let m = DelayedModel {
            label,
            delay_ms,
            succeed,
            invocations: count.clone(),
        };
        (Arc::new(m), count)
    }

    #[tokio::test]
    #[should_panic(expected = "at least one inner model")]
    async fn race_panics_on_empty() {
        let _ = RaceChatModel::new(vec![]);
    }

    #[tokio::test]
    async fn race_returns_first_winner() {
        // A finishes in 5ms, B in 50ms — A must win.
        let (a, _) = arc_dm("a", 5, true);
        let (b, _) = arc_dm("b", 50, true);
        let race = RaceChatModel::new(vec![a, b]);
        let resp = race
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(resp.model, "a");
        assert_eq!(resp.message.text_content(), "a");
    }

    #[tokio::test]
    async fn race_falls_through_failures() {
        // A fails immediately, B succeeds slowly — B is the answer.
        let (a, _) = arc_dm("a", 1, false);
        let (b, _) = arc_dm("b", 10, true);
        let race = RaceChatModel::new(vec![a, b]);
        let resp = race
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(resp.model, "b");
    }

    #[tokio::test]
    async fn race_aggregates_when_all_fail() {
        let (a, _) = arc_dm("a", 1, false);
        let (b, _) = arc_dm("b", 2, false);
        let (c, _) = arc_dm("c", 3, false);
        let race = RaceChatModel::new(vec![a, b, c]);
        let err = race
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap_err();
        let s = format!("{err}");
        assert!(s.contains("all 3 inners failed"), "got: {s}");
        assert!(s.contains("a failed"));
        assert!(s.contains("b failed"));
        assert!(s.contains("c failed"));
    }

    #[tokio::test]
    async fn race_single_inner_passes_through() {
        let (a, count) = arc_dm("a", 0, true);
        let race = RaceChatModel::new(vec![a]);
        let _ = race
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(count.load(std::sync::atomic::Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn race_aborts_losers_after_winner() {
        // A finishes in 5ms; B sleeps 500ms. After A wins, B's task
        // should be aborted — measured by the wall-clock total being
        // closer to A's 5ms than B's 500ms.
        let (a, _) = arc_dm("a", 5, true);
        let (b, _) = arc_dm("b", 500, true);
        let race = RaceChatModel::new(vec![a, b]);
        let started = std::time::Instant::now();
        let _ = race
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        let elapsed_ms = started.elapsed().as_millis() as u64;
        // Allow generous slack for CI variance, but B's 500ms must NOT
        // dominate.
        assert!(
            elapsed_ms < 200,
            "elapsed {elapsed_ms}ms — losers were not aborted",
        );
    }

    // ---- TimeoutChatModel tests ----------------------------------------

    /// Sleeps `delay_ms` then returns a fixed response.
    struct SlowChat {
        delay_ms: u64,
    }

    #[async_trait]
    impl ChatModel for SlowChat {
        fn name(&self) -> &str {
            "slow-chat"
        }
        async fn invoke(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatResponse> {
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            Ok(ChatResponse {
                message: Message {
                    role: Role::Assistant,
                    content: vec![ContentPart::Text { text: "ok".into() }],
                    tool_calls: vec![],
                    tool_call_id: None,
                    name: None,
                    cache: false,
                },
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "slow-chat".into(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test]
    async fn timeout_chat_passes_through_when_under_deadline() {
        let inner: Arc<dyn ChatModel> = Arc::new(SlowChat { delay_ms: 5 });
        let t = TimeoutChatModel::new(inner, Duration::from_millis(100));
        let r = t
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(r.message.text_content(), "ok");
    }

    #[tokio::test]
    async fn timeout_chat_returns_timeout_error_when_inner_too_slow() {
        let inner: Arc<dyn ChatModel> = Arc::new(SlowChat { delay_ms: 200 });
        let t = TimeoutChatModel::new(inner, Duration::from_millis(20));
        let err = t
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap_err();
        assert!(matches!(err, Error::Timeout), "got: {err:?}");
    }

    #[tokio::test]
    async fn timeout_chat_aborts_inner_when_it_times_out() {
        // Wall-clock for the timeout call should be ~20ms even though
        // the inner sleeps 500ms — `tokio::time::timeout` drops the
        // inner future on timeout, releasing the sleep.
        let inner: Arc<dyn ChatModel> = Arc::new(SlowChat { delay_ms: 500 });
        let t = TimeoutChatModel::new(inner, Duration::from_millis(20));
        let started = std::time::Instant::now();
        let _ = t
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await;
        let elapsed = started.elapsed().as_millis() as u64;
        assert!(
            elapsed < 200,
            "elapsed {elapsed}ms — inner future was not dropped on timeout",
        );
    }

    #[tokio::test]
    async fn timeout_chat_preserves_inner_name() {
        let inner: Arc<dyn ChatModel> = Arc::new(SlowChat { delay_ms: 0 });
        let t = TimeoutChatModel::new(inner, Duration::from_millis(100));
        assert_eq!(t.name(), "slow-chat");
    }

    // ---- TimeoutEmbeddings tests ---------------------------------------

    struct SlowEmbed {
        delay_ms: u64,
        dim: usize,
    }

    #[async_trait]
    impl Embeddings for SlowEmbed {
        fn name(&self) -> &str {
            "slow-embed"
        }
        fn dimensions(&self) -> usize {
            self.dim
        }
        async fn embed_query(&self, _text: &str) -> Result<Vec<f32>> {
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            Ok(vec![0.1; self.dim])
        }
        async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            Ok(vec![vec![0.1; self.dim]; texts.len()])
        }
    }

    #[tokio::test]
    async fn timeout_embed_query_under_deadline_passes_through() {
        let inner: Arc<dyn Embeddings> = Arc::new(SlowEmbed { delay_ms: 5, dim: 4 });
        let t = TimeoutEmbeddings::new(inner, Duration::from_millis(100));
        let v = t.embed_query("hi").await.unwrap();
        assert_eq!(v.len(), 4);
    }

    #[tokio::test]
    async fn timeout_embed_query_over_deadline_errors() {
        let inner: Arc<dyn Embeddings> = Arc::new(SlowEmbed { delay_ms: 200, dim: 4 });
        let t = TimeoutEmbeddings::new(inner, Duration::from_millis(20));
        let err = t.embed_query("hi").await.unwrap_err();
        assert!(matches!(err, Error::Timeout), "got: {err:?}");
    }

    #[tokio::test]
    async fn timeout_embed_documents_over_deadline_errors() {
        let inner: Arc<dyn Embeddings> = Arc::new(SlowEmbed { delay_ms: 200, dim: 4 });
        let t = TimeoutEmbeddings::new(inner, Duration::from_millis(20));
        let err = t
            .embed_documents(&["a".into(), "b".into()])
            .await
            .unwrap_err();
        assert!(matches!(err, Error::Timeout));
    }

    #[tokio::test]
    async fn timeout_embed_preserves_dimensions() {
        let inner: Arc<dyn Embeddings> = Arc::new(SlowEmbed { delay_ms: 0, dim: 7 });
        let t = TimeoutEmbeddings::new(inner, Duration::from_millis(100));
        assert_eq!(t.dimensions(), 7);
    }

    // ---- TokenBudgetChatModel tests -----------------------------------

    /// Captures `messages.len()` + `system message count` of each invoke call.
    struct CapturingChat {
        last_msg_count: std::sync::atomic::AtomicUsize,
        last_sys_count: std::sync::atomic::AtomicUsize,
    }

    impl CapturingChat {
        fn new() -> Arc<Self> {
            Arc::new(Self {
                last_msg_count: std::sync::atomic::AtomicUsize::new(0),
                last_sys_count: std::sync::atomic::AtomicUsize::new(0),
            })
        }
    }

    #[async_trait]
    impl ChatModel for CapturingChat {
        fn name(&self) -> &str {
            "gpt-4o-mini"
        }
        async fn invoke(
            &self,
            messages: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatResponse> {
            self.last_msg_count
                .store(messages.len(), Ordering::SeqCst);
            self.last_sys_count.store(
                messages
                    .iter()
                    .filter(|m| matches!(m.role, Role::System))
                    .count(),
                Ordering::SeqCst,
            );
            Ok(ChatResponse {
                message: Message::assistant("ok"),
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "gpt-4o-mini".into(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    fn long_history(n: usize) -> Vec<Message> {
        let mut out = vec![Message::system("You are helpful.")];
        for i in 0..n {
            out.push(Message::user(format!(
                "message {i} with some filler text to inflate token count"
            )));
            out.push(Message::assistant(format!(
                "response {i} with more filler to inflate tokens"
            )));
        }
        out
    }

    #[tokio::test]
    async fn budget_auto_trim_reduces_history_when_over() {
        let inner = CapturingChat::new();
        let budget = TokenBudgetChatModel::new(inner.clone() as Arc<dyn ChatModel>, 50)
            .auto_trim();
        let msgs = long_history(20); // ~41 messages total
        budget.invoke(msgs.clone(), &ChatOptions::default()).await.unwrap();
        let sent = inner.last_msg_count.load(Ordering::SeqCst);
        assert!(sent < msgs.len(), "expected trim: sent={sent}, input={}", msgs.len());
        // System message preserved.
        assert_eq!(inner.last_sys_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn budget_under_cap_passes_through_unchanged() {
        let inner = CapturingChat::new();
        let budget = TokenBudgetChatModel::new(inner.clone() as Arc<dyn ChatModel>, 10_000)
            .auto_trim();
        let msgs = vec![
            Message::system("be brief"),
            Message::user("hi"),
        ];
        budget.invoke(msgs.clone(), &ChatOptions::default()).await.unwrap();
        assert_eq!(inner.last_msg_count.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn budget_strict_mode_errors_on_overflow() {
        let inner = CapturingChat::new();
        let budget = TokenBudgetChatModel::new(inner.clone() as Arc<dyn ChatModel>, 50);
        // strict mode (default — auto_trim NOT called)
        let msgs = long_history(20);
        let err = budget
            .invoke(msgs, &ChatOptions::default())
            .await
            .unwrap_err();
        assert!(matches!(err, Error::InvalidInput(_)));
        let msg = format!("{err}");
        assert!(msg.contains("budget"));
        // Inner model never called.
        assert_eq!(inner.last_msg_count.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn budget_strict_mode_under_cap_succeeds() {
        let inner = CapturingChat::new();
        let budget = TokenBudgetChatModel::new(inner.clone() as Arc<dyn ChatModel>, 10_000);
        let msgs = vec![Message::user("hi")];
        budget.invoke(msgs, &ChatOptions::default()).await.unwrap();
        assert_eq!(inner.last_msg_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn budget_preserves_system_message_even_under_tight_cap() {
        let inner = CapturingChat::new();
        let budget = TokenBudgetChatModel::new(inner.clone() as Arc<dyn ChatModel>, 20)
            .auto_trim();
        let msgs = long_history(30);
        budget.invoke(msgs, &ChatOptions::default()).await.unwrap();
        // System message always retained by trim_messages.
        assert_eq!(inner.last_sys_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn budget_proxies_name_from_inner() {
        let inner = CapturingChat::new();
        let budget = TokenBudgetChatModel::new(inner as Arc<dyn ChatModel>, 100);
        assert_eq!(budget.name(), "gpt-4o-mini");
    }

    // ---- FallbackEmbeddings tests --------------------------------------

    struct CannedEmbed {
        label: &'static str,
        dim: usize,
        result: CannedEmbedResult,
        call_count: AtomicU32,
    }

    #[derive(Clone)]
    enum CannedEmbedResult {
        Ok,
        RateLimited,
        Provider5xx,
        BadRequest,
    }

    #[async_trait]
    impl Embeddings for CannedEmbed {
        fn name(&self) -> &str {
            self.label
        }
        fn dimensions(&self) -> usize {
            self.dim
        }
        async fn embed_query(&self, _text: &str) -> Result<Vec<f32>> {
            self.call_count.fetch_add(1, Ordering::SeqCst);
            match self.result {
                CannedEmbedResult::Ok => Ok(vec![0.1; self.dim]),
                CannedEmbedResult::RateLimited => {
                    Err(Error::RateLimited { retry_after_ms: None })
                }
                CannedEmbedResult::Provider5xx => {
                    Err(Error::provider("503 service unavailable"))
                }
                CannedEmbedResult::BadRequest => Err(Error::invalid("malformed input")),
            }
        }
        async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
            self.call_count.fetch_add(1, Ordering::SeqCst);
            match self.result {
                CannedEmbedResult::Ok => Ok(vec![vec![0.1; self.dim]; texts.len()]),
                CannedEmbedResult::RateLimited => {
                    Err(Error::RateLimited { retry_after_ms: None })
                }
                CannedEmbedResult::Provider5xx => {
                    Err(Error::provider("502 bad gateway"))
                }
                CannedEmbedResult::BadRequest => Err(Error::invalid("malformed batch")),
            }
        }
    }

    fn embed(label: &'static str, dim: usize, r: CannedEmbedResult) -> Arc<CannedEmbed> {
        Arc::new(CannedEmbed {
            label,
            dim,
            result: r,
            call_count: AtomicU32::new(0),
        })
    }

    #[tokio::test]
    async fn fallback_embed_primary_succeeds_no_backup_called() {
        let primary = embed("primary", 1536, CannedEmbedResult::Ok);
        let backup = embed("backup", 1536, CannedEmbedResult::Ok);
        let chain = FallbackEmbeddings::new(vec![
            primary.clone() as Arc<dyn Embeddings>,
            backup.clone() as Arc<dyn Embeddings>,
        ]);
        let v = chain.embed_query("hi").await.unwrap();
        assert_eq!(v.len(), 1536);
        assert_eq!(primary.call_count.load(Ordering::SeqCst), 1);
        assert_eq!(backup.call_count.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn fallback_embed_rate_limit_falls_through() {
        let primary = embed("primary", 512, CannedEmbedResult::RateLimited);
        let backup = embed("backup", 512, CannedEmbedResult::Ok);
        let chain = FallbackEmbeddings::new(vec![
            primary.clone() as Arc<dyn Embeddings>,
            backup.clone() as Arc<dyn Embeddings>,
        ]);
        let v = chain.embed_query("hi").await.unwrap();
        assert_eq!(v.len(), 512);
        assert_eq!(primary.call_count.load(Ordering::SeqCst), 1);
        assert_eq!(backup.call_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn fallback_embed_5xx_falls_through() {
        let primary = embed("p", 768, CannedEmbedResult::Provider5xx);
        let backup = embed("b", 768, CannedEmbedResult::Ok);
        let chain = FallbackEmbeddings::new(vec![
            primary.clone() as Arc<dyn Embeddings>,
            backup as Arc<dyn Embeddings>,
        ]);
        chain.embed_query("hi").await.unwrap();
    }

    #[tokio::test]
    async fn fallback_embed_terminal_error_propagates_by_default() {
        // Bad request would fail on backup too → fail-fast by default.
        let primary = embed("p", 1024, CannedEmbedResult::BadRequest);
        let backup = embed("b", 1024, CannedEmbedResult::Ok);
        let chain = FallbackEmbeddings::new(vec![
            primary.clone() as Arc<dyn Embeddings>,
            backup.clone() as Arc<dyn Embeddings>,
        ]);
        let err = chain.embed_query("hi").await.unwrap_err();
        assert!(matches!(err, Error::InvalidInput(_)));
        assert_eq!(backup.call_count.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn fallback_embed_fall_through_on_all_bypasses_terminal_check() {
        let primary = embed("p", 1024, CannedEmbedResult::BadRequest);
        let backup = embed("b", 1024, CannedEmbedResult::Ok);
        let chain = FallbackEmbeddings::new(vec![
            primary.clone() as Arc<dyn Embeddings>,
            backup.clone() as Arc<dyn Embeddings>,
        ])
        .fall_through_on_all();
        chain.embed_query("hi").await.unwrap();
        assert_eq!(backup.call_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn fallback_embed_exhausted_surfaces_last_error() {
        let p1 = embed("p1", 1536, CannedEmbedResult::RateLimited);
        let p2 = embed("p2", 1536, CannedEmbedResult::Provider5xx);
        let p3 = embed("p3", 1536, CannedEmbedResult::RateLimited);
        let chain = FallbackEmbeddings::new(vec![
            p1.clone() as Arc<dyn Embeddings>,
            p2.clone() as Arc<dyn Embeddings>,
            p3.clone() as Arc<dyn Embeddings>,
        ]);
        let err = chain.embed_query("hi").await.unwrap_err();
        // Last-error wins (p3's RateLimited).
        assert!(matches!(err, Error::RateLimited { .. }));
        assert_eq!(p1.call_count.load(Ordering::SeqCst), 1);
        assert_eq!(p2.call_count.load(Ordering::SeqCst), 1);
        assert_eq!(p3.call_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn fallback_embed_documents_path_also_falls_through() {
        let primary = embed("p", 256, CannedEmbedResult::RateLimited);
        let backup = embed("b", 256, CannedEmbedResult::Ok);
        let chain = FallbackEmbeddings::new(vec![
            primary.clone() as Arc<dyn Embeddings>,
            backup.clone() as Arc<dyn Embeddings>,
        ]);
        let vecs = chain
            .embed_documents(&["a".into(), "b".into(), "c".into()])
            .await
            .unwrap();
        assert_eq!(vecs.len(), 3);
        assert_eq!(vecs[0].len(), 256);
        assert_eq!(primary.call_count.load(Ordering::SeqCst), 1);
        assert_eq!(backup.call_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn fallback_embed_exposes_shared_dimensions() {
        let chain = FallbackEmbeddings::new(vec![
            embed("p", 1024, CannedEmbedResult::Ok) as Arc<dyn Embeddings>,
            embed("b", 1024, CannedEmbedResult::Ok) as Arc<dyn Embeddings>,
        ]);
        assert_eq!(chain.dimensions(), 1024);
        assert!(chain.name().contains("p"));
        assert!(chain.name().contains("b"));
    }

    #[tokio::test]
    #[should_panic(expected = "must have at least one provider")]
    async fn fallback_embed_empty_chain_panics() {
        let _ = FallbackEmbeddings::new(vec![]);
    }

    #[tokio::test]
    #[should_panic(expected = "silent dimension mismatch")]
    async fn fallback_embed_dim_mismatch_panics_at_construction() {
        // 1536 vs 768 → would silently corrupt a vector index. Refuse.
        let _ = FallbackEmbeddings::new(vec![
            embed("p", 1536, CannedEmbedResult::Ok) as Arc<dyn Embeddings>,
            embed("b", 768, CannedEmbedResult::Ok) as Arc<dyn Embeddings>,
        ]);
    }

    // ---- RaceEmbeddings tests ------------------------------------------

    /// Embed provider that sleeps `delay_ms` then either returns a
    /// `dim`-vector of `marker` floats or errors. Lets us pin which
    /// inner wins a race deterministically.
    struct DelayedEmbed {
        label: &'static str,
        dim: usize,
        delay_ms: u64,
        marker: f32,
        succeed: bool,
    }

    #[async_trait]
    impl Embeddings for DelayedEmbed {
        fn name(&self) -> &str {
            self.label
        }
        fn dimensions(&self) -> usize {
            self.dim
        }
        async fn embed_query(&self, _text: &str) -> Result<Vec<f32>> {
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            if self.succeed {
                Ok(vec![self.marker; self.dim])
            } else {
                Err(Error::provider(format!("{} failed", self.label)))
            }
        }
        async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            if self.succeed {
                Ok(vec![vec![self.marker; self.dim]; texts.len()])
            } else {
                Err(Error::provider(format!("{} failed", self.label)))
            }
        }
    }

    fn delayed(
        label: &'static str,
        dim: usize,
        delay_ms: u64,
        marker: f32,
        succeed: bool,
    ) -> Arc<dyn Embeddings> {
        Arc::new(DelayedEmbed {
            label,
            dim,
            delay_ms,
            marker,
            succeed,
        })
    }

    #[tokio::test]
    #[should_panic(expected = "at least one inner provider")]
    async fn race_embed_panics_on_empty() {
        let _ = RaceEmbeddings::new(vec![]);
    }

    #[tokio::test]
    #[should_panic(expected = "dim mismatch")]
    async fn race_embed_panics_on_dim_mismatch() {
        let a = delayed("a", 1536, 1, 0.1, true);
        let b = delayed("b", 768, 1, 0.2, true);
        let _ = RaceEmbeddings::new(vec![a, b]);
    }

    #[tokio::test]
    async fn race_embed_query_returns_first_winner() {
        // a finishes in 5ms, b in 50ms — a wins, marker=0.42 ↦ all 1536 dims = 0.42
        let a = delayed("a", 4, 5, 0.42, true);
        let b = delayed("b", 4, 50, 0.99, true);
        let race = RaceEmbeddings::new(vec![a, b]);
        let out = race.embed_query("hi").await.unwrap();
        assert_eq!(out, vec![0.42; 4]);
    }

    #[tokio::test]
    async fn race_embed_query_falls_through_failures() {
        // a fails fast, b succeeds slowly → b's vector is the result.
        let a = delayed("a", 4, 1, 0.0, false);
        let b = delayed("b", 4, 10, 0.5, true);
        let race = RaceEmbeddings::new(vec![a, b]);
        let out = race.embed_query("q").await.unwrap();
        assert_eq!(out, vec![0.5; 4]);
    }

    #[tokio::test]
    async fn race_embed_query_aggregates_when_all_fail() {
        let a = delayed("a", 4, 1, 0.0, false);
        let b = delayed("b", 4, 2, 0.0, false);
        let race = RaceEmbeddings::new(vec![a, b]);
        let err = race.embed_query("q").await.unwrap_err();
        let s = format!("{err}");
        assert!(s.contains("all 2 inners failed"), "got: {s}");
        assert!(s.contains("a failed"));
        assert!(s.contains("b failed"));
    }

    #[tokio::test]
    async fn race_embed_documents_returns_first_winner() {
        let a = delayed("a", 4, 5, 0.42, true);
        let b = delayed("b", 4, 50, 0.99, true);
        let race = RaceEmbeddings::new(vec![a, b]);
        let out = race
            .embed_documents(&["hi".into(), "there".into()])
            .await
            .unwrap();
        assert_eq!(out.len(), 2);
        assert_eq!(out[0], vec![0.42; 4]);
        assert_eq!(out[1], vec![0.42; 4]);
    }

    #[tokio::test]
    async fn race_embed_single_inner_passes_through() {
        let a = delayed("only", 4, 0, 0.7, true);
        let race = RaceEmbeddings::new(vec![a]);
        let out = race.embed_query("q").await.unwrap();
        assert_eq!(out, vec![0.7; 4]);
    }

    #[tokio::test]
    async fn race_embed_aborts_losers_after_winner() {
        // a wins in 5ms, b sleeps 500ms — total wall-clock should be
        // closer to 5ms than 500ms.
        let a = delayed("a", 4, 5, 0.42, true);
        let b = delayed("b", 4, 500, 0.99, true);
        let race = RaceEmbeddings::new(vec![a, b]);
        let started = std::time::Instant::now();
        let _ = race.embed_query("q").await.unwrap();
        let elapsed_ms = started.elapsed().as_millis() as u64;
        assert!(
            elapsed_ms < 200,
            "elapsed {elapsed_ms}ms — losers were not aborted",
        );
    }

    #[tokio::test]
    async fn race_embed_name_includes_all_inners() {
        let a = delayed("openai", 4, 0, 0.0, true);
        let b = delayed("voyage", 4, 0, 0.0, true);
        let race = RaceEmbeddings::new(vec![a, b]);
        assert!(race.name().contains("openai"));
        assert!(race.name().contains("voyage"));
        assert!(race.name().starts_with("race("));
    }

    // ---- RetryingEmbeddings tests --------------------------------------

    /// Embed provider that fails the first N calls (transient) then succeeds.
    struct FlakyEmbed {
        fails_remaining: AtomicU32,
        kind: EmbedFlakyKind,
        dim: usize,
        total_calls: AtomicU32,
    }

    enum EmbedFlakyKind {
        RateLimited,
        Provider5xx,
        BadRequest,
    }

    #[async_trait]
    impl Embeddings for FlakyEmbed {
        fn name(&self) -> &str {
            "flaky-embed"
        }
        fn dimensions(&self) -> usize {
            self.dim
        }
        async fn embed_query(&self, _text: &str) -> Result<Vec<f32>> {
            self.total_calls.fetch_add(1, Ordering::SeqCst);
            let n = self.fails_remaining.load(Ordering::SeqCst);
            if n > 0 {
                self.fails_remaining.fetch_sub(1, Ordering::SeqCst);
                return Err(match self.kind {
                    EmbedFlakyKind::RateLimited => {
                        Error::RateLimited { retry_after_ms: None }
                    }
                    EmbedFlakyKind::Provider5xx => Error::provider("502 bad gateway"),
                    EmbedFlakyKind::BadRequest => Error::invalid("bad request"),
                });
            }
            Ok(vec![0.1; self.dim])
        }
        async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
            self.total_calls.fetch_add(1, Ordering::SeqCst);
            let n = self.fails_remaining.load(Ordering::SeqCst);
            if n > 0 {
                self.fails_remaining.fetch_sub(1, Ordering::SeqCst);
                return Err(match self.kind {
                    EmbedFlakyKind::RateLimited => {
                        Error::RateLimited { retry_after_ms: None }
                    }
                    EmbedFlakyKind::Provider5xx => Error::provider("503 service unavailable"),
                    EmbedFlakyKind::BadRequest => Error::invalid("malformed batch"),
                });
            }
            Ok(vec![vec![0.1; self.dim]; texts.len()])
        }
    }

    fn flaky_embed(fails: u32, kind: EmbedFlakyKind, dim: usize) -> Arc<FlakyEmbed> {
        Arc::new(FlakyEmbed {
            fails_remaining: AtomicU32::new(fails),
            kind,
            dim,
            total_calls: AtomicU32::new(0),
        })
    }

    fn fast_retry() -> RetryConfig {
        RetryConfig {
            min_delay: Duration::from_millis(1),
            max_delay: Duration::from_millis(5),
            factor: 2.0,
            max_times: 5,
            jitter: false,
        }
    }

    #[tokio::test]
    async fn retry_embed_recovers_from_rate_limit() {
        let flaky = flaky_embed(2, EmbedFlakyKind::RateLimited, 512);
        let r = RetryingEmbeddings::new(flaky.clone() as Arc<dyn Embeddings>, fast_retry());
        let v = r.embed_query("hi").await.unwrap();
        assert_eq!(v.len(), 512);
        assert_eq!(flaky.total_calls.load(Ordering::SeqCst), 3);
    }

    #[tokio::test]
    async fn retry_embed_recovers_from_5xx() {
        let flaky = flaky_embed(1, EmbedFlakyKind::Provider5xx, 256);
        let r = RetryingEmbeddings::new(flaky.clone() as Arc<dyn Embeddings>, fast_retry());
        r.embed_query("hi").await.unwrap();
        assert_eq!(flaky.total_calls.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn retry_embed_gives_up_after_max_attempts() {
        let flaky = flaky_embed(99, EmbedFlakyKind::RateLimited, 128);
        let r = RetryingEmbeddings::new(
            flaky.clone() as Arc<dyn Embeddings>,
            RetryConfig {
                min_delay: Duration::from_millis(1),
                max_delay: Duration::from_millis(2),
                factor: 1.5,
                max_times: 2,
                jitter: false,
            },
        );
        let err = r.embed_query("hi").await.unwrap_err();
        assert!(matches!(err, Error::RateLimited { .. }));
        // initial + 2 retries = 3 attempts total
        assert_eq!(flaky.total_calls.load(Ordering::SeqCst), 3);
    }

    #[tokio::test]
    async fn retry_embed_terminal_bad_request_does_not_retry() {
        let flaky = flaky_embed(99, EmbedFlakyKind::BadRequest, 512);
        let r = RetryingEmbeddings::new(flaky.clone() as Arc<dyn Embeddings>, fast_retry());
        let err = r.embed_query("hi").await.unwrap_err();
        assert!(matches!(err, Error::InvalidInput(_)));
        // 1 attempt only — no retries on terminal error
        assert_eq!(flaky.total_calls.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn retry_embed_documents_path_also_retries() {
        let flaky = flaky_embed(1, EmbedFlakyKind::Provider5xx, 256);
        let r = RetryingEmbeddings::new(flaky.clone() as Arc<dyn Embeddings>, fast_retry());
        let v = r
            .embed_documents(&["a".into(), "b".into(), "c".into()])
            .await
            .unwrap();
        assert_eq!(v.len(), 3);
        assert_eq!(v[0].len(), 256);
        assert_eq!(flaky.total_calls.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn retry_embed_exposes_inner_dim_and_name() {
        let flaky = flaky_embed(0, EmbedFlakyKind::RateLimited, 1024);
        let r = RetryingEmbeddings::new(flaky as Arc<dyn Embeddings>, fast_retry());
        assert_eq!(r.dimensions(), 1024);
        assert_eq!(r.name(), "flaky-embed");
    }

    // ---- RateLimitedEmbeddings tests -----------------------------------

    struct CountingEmbed {
        calls: AtomicU32,
        dim: usize,
    }

    #[async_trait]
    impl Embeddings for CountingEmbed {
        fn name(&self) -> &str {
            "counting-embed"
        }
        fn dimensions(&self) -> usize {
            self.dim
        }
        async fn embed_query(&self, _t: &str) -> Result<Vec<f32>> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            Ok(vec![0.0; self.dim])
        }
        async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            Ok(vec![vec![0.0; self.dim]; texts.len()])
        }
    }

    #[tokio::test]
    async fn ratelimit_embed_steady_state_matches_configured_rate() {
        let inner: Arc<dyn Embeddings> = Arc::new(CountingEmbed {
            calls: AtomicU32::new(0),
            dim: 128,
        });
        // 120 RPM = 2 RPS, burst=1 → strict 1-every-500ms cadence.
        let r = RateLimitedEmbeddings::new(
            inner,
            RateLimitConfig::per_minute(120).with_burst(1),
        );
        let start = tokio::time::Instant::now();
        for _ in 0..4 {
            r.embed_query("hi").await.unwrap();
        }
        let total = start.elapsed();
        assert!(
            total >= Duration::from_millis(1490) && total < Duration::from_millis(2000),
            "4 calls @ 2 RPS w/ burst=1 should take ~1.5s, took {:?}",
            total
        );
    }

    #[tokio::test]
    async fn ratelimit_embed_burst_serves_immediately_then_throttles() {
        let inner: Arc<dyn Embeddings> = Arc::new(CountingEmbed {
            calls: AtomicU32::new(0),
            dim: 512,
        });
        // 60 RPM = 1 RPS, burst=3 → 3 instant, 4th waits ~1s.
        let r = RateLimitedEmbeddings::new(
            inner,
            RateLimitConfig::per_minute(60).with_burst(3),
        );
        let start = tokio::time::Instant::now();
        for _ in 0..3 {
            r.embed_query("hi").await.unwrap();
        }
        // Burst absorbed instantly.
        assert!(start.elapsed() < Duration::from_millis(100));
        // 4th call throttles.
        r.embed_query("hi").await.unwrap();
        assert!(start.elapsed() >= Duration::from_millis(900));
    }

    #[tokio::test]
    async fn ratelimit_embed_batch_counts_as_one_token() {
        // embed_documents with 100 texts consumes ONE token (providers
        // bill per call, not per text).
        let inner: Arc<dyn Embeddings> = Arc::new(CountingEmbed {
            calls: AtomicU32::new(0),
            dim: 256,
        });
        let r = RateLimitedEmbeddings::new(
            inner,
            RateLimitConfig::per_minute(60).with_burst(1),
        );
        let big_batch: Vec<String> = (0..100).map(|i| format!("text_{i}")).collect();
        // First call — uses the single burst token immediately.
        let start = tokio::time::Instant::now();
        r.embed_documents(&big_batch).await.unwrap();
        assert!(start.elapsed() < Duration::from_millis(100));
        // Second call — must wait ~1s (1 RPS steady).
        r.embed_documents(&big_batch).await.unwrap();
        assert!(start.elapsed() >= Duration::from_millis(900));
    }

    #[tokio::test]
    async fn ratelimit_embed_exposes_inner_dim() {
        let inner: Arc<dyn Embeddings> = Arc::new(CountingEmbed {
            calls: AtomicU32::new(0),
            dim: 1536,
        });
        let r = RateLimitedEmbeddings::new(inner, RateLimitConfig::per_minute(1000));
        assert_eq!(r.dimensions(), 1536);
    }

    // ---- PiiScrubbingChatModel tests -----------------------------------

    /// Chat model that captures the messages it was called with, returning
    /// a canned response.
    struct CapturingChatPii {
        seen: std::sync::Mutex<Vec<Vec<Message>>>,
        canned_response: String,
    }

    impl CapturingChatPii {
        fn new(canned: &str) -> Arc<Self> {
            Arc::new(Self {
                seen: std::sync::Mutex::new(Vec::new()),
                canned_response: canned.to_string(),
            })
        }
    }

    #[async_trait]
    impl ChatModel for CapturingChatPii {
        fn name(&self) -> &str {
            "capturing-pii"
        }
        async fn invoke(
            &self,
            messages: Vec<Message>,
            _opts: &ChatOptions,
        ) -> Result<ChatResponse> {
            self.seen.lock().unwrap().push(messages);
            Ok(ChatResponse {
                message: Message::assistant(self.canned_response.clone()),
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "capturing-pii".into(),
            })
        }
        async fn stream(
            &self,
            _messages: Vec<Message>,
            _opts: &ChatOptions,
        ) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test]
    async fn pii_scrub_redacts_user_message_before_invoke() {
        let inner = CapturingChatPii::new("ok");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>);
        let msgs = vec![
            Message::user("email me at alice@example.com for details"),
        ];
        scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        let seen = &inner.seen.lock().unwrap()[0];
        let user_text = seen[0].text_content();
        assert!(user_text.contains("<EMAIL>"));
        assert!(!user_text.contains("alice@example.com"));
    }

    #[tokio::test]
    async fn pii_scrub_leaves_assistant_messages_untouched() {
        let inner = CapturingChatPii::new("ok");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>);
        // Assistant messages in the history (prior turn) should NOT be
        // re-scrubbed — they came from the model, agent-trace integrity.
        let msgs = vec![
            Message::user("tell me about bob@example.com"),
            Message::assistant("Here's what I know about bob@example.com — he ..."),
            Message::user("continue"),
        ];
        scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        let seen = &inner.seen.lock().unwrap()[0];
        // User messages scrubbed.
        assert!(seen[0].text_content().contains("<EMAIL>"));
        assert!(!seen[0].text_content().contains("bob@example.com"));
        // Assistant message UNTOUCHED.
        assert!(seen[1].text_content().contains("bob@example.com"));
        // Last user message scrubbed (no PII, passes through).
        assert_eq!(seen[2].text_content(), "continue");
    }

    #[tokio::test]
    async fn pii_scrub_system_off_by_default() {
        let inner = CapturingChatPii::new("ok");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>);
        let msgs = vec![
            Message::system("operator@corp.com is the admin"),
            Message::user("hi"),
        ];
        scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        let seen = &inner.seen.lock().unwrap()[0];
        // System message unchanged — operator prompts are trusted.
        assert!(seen[0].text_content().contains("operator@corp.com"));
    }

    #[tokio::test]
    async fn pii_scrub_system_opt_in_scrubs_operator_prompt_too() {
        let inner = CapturingChatPii::new("ok");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>)
            .with_system_scrubbing();
        let msgs = vec![
            Message::system("admin is operator@corp.com"),
            Message::user("hi"),
        ];
        scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        let seen = &inner.seen.lock().unwrap()[0];
        assert!(seen[0].text_content().contains("<EMAIL>"));
    }

    #[tokio::test]
    async fn pii_scrub_output_off_by_default() {
        // Model returns response containing what looks like PII. Default
        // behavior: don't mangle the LLM's output.
        let inner = CapturingChatPii::new("Contact alice@example.com for support.");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>);
        let msgs = vec![Message::user("who to contact")];
        let resp = scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        assert!(resp.message.text_content().contains("alice@example.com"));
    }

    #[tokio::test]
    async fn pii_scrub_output_opt_in_scrubs_response_text() {
        let inner = CapturingChatPii::new("Contact alice@example.com for support.");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>)
            .with_output_scrubbing();
        let msgs = vec![Message::user("who to contact")];
        let resp = scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        let text = resp.message.text_content();
        assert!(text.contains("<EMAIL>"));
        assert!(!text.contains("alice@example.com"));
    }

    #[tokio::test]
    async fn pii_scrub_inputs_false_passes_everything_through() {
        let inner = CapturingChatPii::new("ok");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>)
            .scrub_inputs(false);
        let msgs = vec![Message::user("email alice@example.com now")];
        scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        let seen = &inner.seen.lock().unwrap()[0];
        // Scrubbing off → email preserved.
        assert!(seen[0].text_content().contains("alice@example.com"));
    }

    #[tokio::test]
    async fn pii_scrub_with_custom_scrubber_respects_custom_patterns() {
        use regex::Regex;
        // Operator adds an internal INTERNAL_ID pattern on top of defaults.
        let custom = PiiScrubber::new().with_patterns(vec![(
            "INTERNAL_ID".to_string(),
            Regex::new(r"\bINT-\d{4}\b").unwrap(),
        )]);
        let inner = CapturingChatPii::new("ok");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>)
            .with_scrubber(Arc::new(custom));
        let msgs = vec![Message::user("issue INT-1234 filed by alice@example.com")];
        scrub.invoke(msgs, &ChatOptions::default()).await.unwrap();
        let seen = &inner.seen.lock().unwrap()[0];
        let text = seen[0].text_content();
        assert!(text.contains("<INTERNAL_ID>"));
        assert!(text.contains("<EMAIL>"));
    }

    #[tokio::test]
    async fn pii_scrub_name_proxy_from_inner() {
        let inner = CapturingChatPii::new("x");
        let scrub = PiiScrubbingChatModel::new(inner as Arc<dyn ChatModel>);
        assert_eq!(scrub.name(), "capturing-pii");
    }

    #[tokio::test]
    async fn pii_scrub_preserves_tool_calls_and_metadata_fields() {
        use litgraph_core::tool::ToolCall;
        let inner = CapturingChatPii::new("x");
        let scrub = PiiScrubbingChatModel::new(inner.clone() as Arc<dyn ChatModel>);
        // User message with tool_calls attached (rare in user role, but
        // test that the shape is preserved on assistant messages too).
        let msg = Message {
            role: Role::Assistant,
            content: vec![ContentPart::Text {
                text: "bob@example.com assistant response".into(),
            }],
            tool_calls: vec![ToolCall {
                id: "c1".into(),
                name: "look_up".into(),
                arguments: serde_json::json!({"email": "bob@example.com"}),
            }],
            tool_call_id: Some("prior".into()),
            name: Some("asst".into()),
            cache: true,
        };
        scrub
            .invoke(vec![msg.clone()], &ChatOptions::default())
            .await
            .unwrap();
        let seen = &inner.seen.lock().unwrap()[0];
        let kept = &seen[0];
        // Assistant-role → not scrubbed, so email in text is preserved.
        assert!(kept.text_content().contains("bob@example.com"));
        // Tool-calls, tool_call_id, name, cache all round-tripped.
        assert_eq!(kept.tool_calls.len(), 1);
        assert_eq!(kept.tool_calls[0].id, "c1");
        assert_eq!(kept.tool_call_id.as_deref(), Some("prior"));
        assert_eq!(kept.name.as_deref(), Some("asst"));
        assert!(kept.cache);
    }

    // ---- CircuitBreakerChatModel tests ----------------------------------

    /// Always errs with provider("502 ...") so the breaker counts every call
    /// as a failure. Counts invocations so we can verify the breaker
    /// short-circuits without invoking inner.
    struct AlwaysFailModel {
        seen: AtomicU32,
    }

    #[async_trait]
    impl ChatModel for AlwaysFailModel {
        fn name(&self) -> &str {
            "always-fail"
        }
        async fn invoke(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatResponse> {
            self.seen.fetch_add(1, Ordering::SeqCst);
            Err(Error::provider("502 sick upstream"))
        }
        async fn stream(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatStream> {
            self.seen.fetch_add(1, Ordering::SeqCst);
            Err(Error::provider("502 sick upstream"))
        }
    }

    #[tokio::test]
    async fn circuit_breaker_passes_through_inner_errors_until_threshold() {
        let inner = Arc::new(AlwaysFailModel {
            seen: AtomicU32::new(0),
        });
        let breaker = Arc::new(CircuitBreaker::new(3, Duration::from_secs(60)));
        let cb = CircuitBreakerChatModel::new(
            inner.clone() as Arc<dyn ChatModel>,
            breaker.clone(),
        );
        // Two failures: should be passed-through provider errors.
        for _ in 0..2 {
            let err = cb
                .invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await
                .unwrap_err();
            assert!(
                matches!(err, Error::Provider(ref m) if m.contains("502")),
                "expected pass-through, got {err:?}",
            );
        }
        assert_eq!(inner.seen.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn circuit_breaker_short_circuits_after_threshold() {
        let inner = Arc::new(AlwaysFailModel {
            seen: AtomicU32::new(0),
        });
        let breaker = Arc::new(CircuitBreaker::new(2, Duration::from_secs(60)));
        let cb = CircuitBreakerChatModel::new(
            inner.clone() as Arc<dyn ChatModel>,
            breaker.clone(),
        );
        // Trip the breaker.
        for _ in 0..2 {
            let _ = cb
                .invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await;
        }
        // Subsequent calls fail-fast WITHOUT invoking inner.
        for _ in 0..3 {
            let err = cb
                .invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await
                .unwrap_err();
            assert!(
                matches!(err, Error::Provider(ref m) if m.contains("circuit breaker open")),
                "expected circuit-open error, got {err:?}",
            );
        }
        assert_eq!(
            inner.seen.load(Ordering::SeqCst),
            2,
            "inner was invoked while breaker was open",
        );
    }

    #[tokio::test]
    async fn circuit_breaker_streams_also_short_circuit() {
        let inner = Arc::new(AlwaysFailModel {
            seen: AtomicU32::new(0),
        });
        let breaker = Arc::new(CircuitBreaker::new(1, Duration::from_secs(60)));
        let cb = CircuitBreakerChatModel::new(
            inner.clone() as Arc<dyn ChatModel>,
            breaker.clone(),
        );
        // First stream() error trips it.
        let _ = cb
            .stream(vec![Message::user("hi")], &ChatOptions::default())
            .await;
        let baseline = inner.seen.load(Ordering::SeqCst);
        // Now stream() must fail-fast.
        let r = cb
            .stream(vec![Message::user("hi")], &ChatOptions::default())
            .await;
        match r {
            Ok(_) => panic!("stream should have failed-fast"),
            Err(Error::Provider(m)) => {
                assert!(m.contains("circuit breaker open"), "got: {m}")
            }
            Err(other) => panic!("expected circuit-open error, got {other:?}"),
        }
        assert_eq!(
            inner.seen.load(Ordering::SeqCst),
            baseline,
            "stream invoked inner despite open breaker",
        );
    }

    /// Always-succeeds model for closed-path test.
    struct AlwaysOkModel;

    #[async_trait]
    impl ChatModel for AlwaysOkModel {
        fn name(&self) -> &str {
            "always-ok"
        }
        async fn invoke(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatResponse> {
            Ok(ChatResponse {
                message: Message {
                    role: Role::Assistant,
                    content: vec![ContentPart::Text { text: "hi".into() }],
                    tool_calls: vec![],
                    tool_call_id: None,
                    name: None,
                    cache: false,
                },
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "always-ok".into(),
            })
        }
        async fn stream(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test]
    async fn circuit_breaker_closed_passes_successes_through() {
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let breaker = Arc::new(CircuitBreaker::new(2, Duration::from_secs(60)));
        let cb = CircuitBreakerChatModel::new(inner, breaker);
        for _ in 0..5 {
            let resp = cb
                .invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await
                .unwrap();
            assert_eq!(resp.message.text_content(), "hi");
        }
    }

    #[tokio::test]
    async fn circuit_breaker_name_proxies_inner() {
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let breaker = Arc::new(CircuitBreaker::new(2, Duration::from_secs(60)));
        let cb = CircuitBreakerChatModel::new(inner, breaker);
        assert_eq!(cb.name(), "always-ok");
    }

    // ---- CircuitBreakerEmbeddings tests ---------------------------------

    #[tokio::test]
    async fn circuit_breaker_embeddings_short_circuits_after_threshold() {
        // u32::MAX fails => effectively always-fail; lets us observe
        // that inner is NOT invoked while the breaker is open.
        let inner = flaky_embed(u32::MAX, EmbedFlakyKind::Provider5xx, 4);
        let breaker = Arc::new(CircuitBreaker::new(2, Duration::from_secs(60)));
        let cb = CircuitBreakerEmbeddings::new(
            inner.clone() as Arc<dyn Embeddings>,
            breaker,
        );
        // Two failures pass through and trip the breaker.
        for _ in 0..2 {
            let err = cb.embed_query("hi").await.unwrap_err();
            assert!(matches!(err, Error::Provider(ref m) if m.contains("502")));
        }
        let baseline = inner.total_calls.load(Ordering::SeqCst);
        // Subsequent calls fail-fast WITHOUT invoking inner.
        for _ in 0..3 {
            let err = cb.embed_query("hi").await.unwrap_err();
            assert!(matches!(err, Error::Provider(ref m) if m.contains("circuit breaker open")));
        }
        // embed_documents path also short-circuits via the SAME breaker.
        let err = cb
            .embed_documents(&["a".into(), "b".into()])
            .await
            .unwrap_err();
        assert!(matches!(err, Error::Provider(ref m) if m.contains("circuit breaker open")));
        assert_eq!(
            inner.total_calls.load(Ordering::SeqCst),
            baseline,
            "inner was invoked while breaker was open",
        );
    }

    #[tokio::test]
    async fn circuit_breaker_embeddings_closed_passes_successes() {
        // Zero fails => always succeeds; verifies the closed path.
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 3);
        let breaker = Arc::new(CircuitBreaker::new(2, Duration::from_secs(60)));
        let cb = CircuitBreakerEmbeddings::new(
            inner as Arc<dyn Embeddings>,
            breaker,
        );
        let v = cb.embed_query("hi").await.unwrap();
        assert_eq!(v.len(), 3);
        let docs = cb
            .embed_documents(&["a".into(), "b".into()])
            .await
            .unwrap();
        assert_eq!(docs.len(), 2);
        assert_eq!(docs[0].len(), 3);
    }

    #[tokio::test]
    async fn circuit_breaker_embeddings_query_failures_open_breaker_for_documents() {
        // One shared breaker spans both call shapes: a flapping
        // embed_query path opens the breaker so a subsequent
        // embed_documents call also fails fast.
        let inner = flaky_embed(u32::MAX, EmbedFlakyKind::Provider5xx, 2);
        let breaker = Arc::new(CircuitBreaker::new(2, Duration::from_secs(60)));
        let cb = CircuitBreakerEmbeddings::new(
            inner.clone() as Arc<dyn Embeddings>,
            breaker,
        );
        for _ in 0..2 {
            let _ = cb.embed_query("hi").await;
        }
        let baseline = inner.total_calls.load(Ordering::SeqCst);
        let err = cb
            .embed_documents(&["a".into()])
            .await
            .unwrap_err();
        assert!(matches!(err, Error::Provider(ref m) if m.contains("circuit breaker open")));
        assert_eq!(
            inner.total_calls.load(Ordering::SeqCst),
            baseline,
            "embed_documents invoked inner despite the query path opening the breaker",
        );
    }

    #[tokio::test]
    async fn circuit_breaker_embeddings_dimensions_proxy_inner() {
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 7);
        let breaker = Arc::new(CircuitBreaker::new(2, Duration::from_secs(60)));
        let cb = CircuitBreakerEmbeddings::new(
            inner as Arc<dyn Embeddings>,
            breaker,
        );
        assert_eq!(cb.dimensions(), 7);
        assert_eq!(cb.name(), "flaky-embed");
    }

    // ---- SharedRateLimited{Chat,Embed} tests ---------------------------

    #[tokio::test]
    async fn shared_rate_limit_two_chat_models_share_one_budget() {
        // Bucket: capacity 2, refill 50/sec ≈ 20ms/token. Two distinct
        // wrapped models share the limiter. Four total calls (2 per
        // model) must take >= 2 * 20ms = 40ms (the 3rd and 4th wait).
        let limiter = Arc::new(RateLimiter::new(2, 50));
        let m1: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let m2: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let s1 = Arc::new(SharedRateLimitedChatModel::new(m1, limiter.clone()));
        let s2 = Arc::new(SharedRateLimitedChatModel::new(m2, limiter.clone()));
        let started = std::time::Instant::now();
        let mut handles = Vec::new();
        for _ in 0..2 {
            let s = s1.clone();
            handles.push(tokio::spawn(async move {
                s.invoke(vec![Message::user("hi")], &ChatOptions::default()).await
            }));
        }
        for _ in 0..2 {
            let s = s2.clone();
            handles.push(tokio::spawn(async move {
                s.invoke(vec![Message::user("hi")], &ChatOptions::default()).await
            }));
        }
        for h in handles {
            h.await.unwrap().unwrap();
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed >= Duration::from_millis(30),
            "shared budget didn't throttle: {elapsed:?}",
        );
    }

    #[tokio::test]
    async fn shared_rate_limit_chat_serves_burst_immediately() {
        // Capacity 4, refill 1/sec. Bursting 4 calls must NOT block.
        let limiter = Arc::new(RateLimiter::new(4, 1));
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let s = Arc::new(SharedRateLimitedChatModel::new(inner, limiter));
        let started = std::time::Instant::now();
        for _ in 0..4 {
            s.invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await
                .unwrap();
        }
        let elapsed = started.elapsed();
        assert!(
            elapsed < Duration::from_millis(50),
            "burst was throttled: {elapsed:?}",
        );
    }

    #[tokio::test]
    async fn shared_rate_limit_embed_query_and_documents_share_budget() {
        // Bucket: capacity 1, refill 50/sec. Three calls
        // (embed_query, embed_documents, embed_query) on the same
        // wrapper must take >= 2 * 20ms.
        let limiter = Arc::new(RateLimiter::new(1, 50));
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 3);
        let s = Arc::new(SharedRateLimitedEmbeddings::new(
            inner as Arc<dyn Embeddings>,
            limiter,
        ));
        let started = std::time::Instant::now();
        s.embed_query("a").await.unwrap();
        s.embed_documents(&["x".into()]).await.unwrap();
        s.embed_query("b").await.unwrap();
        let elapsed = started.elapsed();
        assert!(
            elapsed >= Duration::from_millis(20),
            "shared embed budget didn't throttle: {elapsed:?}",
        );
    }

    #[tokio::test]
    async fn shared_rate_limit_chat_name_proxies_inner() {
        let limiter = Arc::new(RateLimiter::new(10, 10));
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let s = SharedRateLimitedChatModel::new(inner, limiter);
        assert_eq!(s.name(), "always-ok");
    }

    #[tokio::test]
    async fn shared_rate_limit_embed_dimensions_proxy_inner() {
        let limiter = Arc::new(RateLimiter::new(10, 10));
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 5);
        let s = SharedRateLimitedEmbeddings::new(
            inner as Arc<dyn Embeddings>,
            limiter,
        );
        assert_eq!(s.dimensions(), 5);
        assert_eq!(s.name(), "flaky-embed");
    }

    // ---- KeyedSerializedChatModel tests --------------------------------

    /// Sleeps `delay_ms` per call and tracks peak concurrent calls.
    /// Lets keyed-mutex tests verify same-key serialization vs
    /// different-key parallelism.
    struct DelayChatModel {
        delay_ms: u64,
        in_flight: Arc<std::sync::atomic::AtomicUsize>,
        peak: Arc<std::sync::atomic::AtomicUsize>,
    }

    #[async_trait]
    impl ChatModel for DelayChatModel {
        fn name(&self) -> &str {
            "delay-chat"
        }
        async fn invoke(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatResponse> {
            let now = self.in_flight.fetch_add(1, Ordering::SeqCst) + 1;
            let mut p = self.peak.load(Ordering::SeqCst);
            while now > p {
                match self.peak.compare_exchange(
                    p,
                    now,
                    Ordering::SeqCst,
                    Ordering::SeqCst,
                ) {
                    Ok(_) => break,
                    Err(actual) => p = actual,
                }
            }
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            self.in_flight.fetch_sub(1, Ordering::SeqCst);
            Ok(ChatResponse {
                message: Message {
                    role: Role::Assistant,
                    content: vec![ContentPart::Text { text: "ok".into() }],
                    tool_calls: vec![],
                    tool_call_id: None,
                    name: None,
                    cache: false,
                },
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "delay-chat".into(),
            })
        }
        async fn stream(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    fn key_from_first_user_text(
        msgs: &[Message],
        _opts: &ChatOptions,
    ) -> Option<String> {
        msgs.iter()
            .find(|m| m.role == Role::User)
            .map(|m| m.text_content().to_string())
    }

    #[tokio::test]
    async fn keyed_serialized_same_key_serializes() {
        use std::sync::atomic::AtomicUsize;
        let in_flight = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let inner: Arc<dyn ChatModel> = Arc::new(DelayChatModel {
            delay_ms: 20,
            in_flight: in_flight.clone(),
            peak: peak.clone(),
        });
        let registry = Arc::new(KeyedMutex::<String>::new());
        let cm = Arc::new(KeyedSerializedChatModel::new(
            inner,
            registry,
            key_from_first_user_text,
        ));
        let mut handles = Vec::new();
        for _ in 0..5 {
            let cm = cm.clone();
            handles.push(tokio::spawn(async move {
                cm.invoke(
                    vec![Message::user("user_a")],
                    &ChatOptions::default(),
                )
                .await
            }));
        }
        for h in handles {
            h.await.unwrap().unwrap();
        }
        assert_eq!(
            peak.load(Ordering::SeqCst),
            1,
            "same-key didn't serialize",
        );
    }

    #[tokio::test]
    async fn keyed_serialized_different_keys_run_in_parallel() {
        use std::sync::atomic::AtomicUsize;
        let in_flight = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let inner: Arc<dyn ChatModel> = Arc::new(DelayChatModel {
            delay_ms: 30,
            in_flight: in_flight.clone(),
            peak: peak.clone(),
        });
        let registry = Arc::new(KeyedMutex::<String>::new());
        let cm = Arc::new(KeyedSerializedChatModel::new(
            inner,
            registry,
            key_from_first_user_text,
        ));
        let mut handles = Vec::new();
        for i in 0..5 {
            let cm = cm.clone();
            handles.push(tokio::spawn(async move {
                cm.invoke(
                    vec![Message::user(format!("thread_{i}"))],
                    &ChatOptions::default(),
                )
                .await
            }));
        }
        for h in handles {
            h.await.unwrap().unwrap();
        }
        assert!(
            peak.load(Ordering::SeqCst) >= 2,
            "different keys never ran concurrently",
        );
    }

    #[tokio::test]
    async fn keyed_serialized_none_key_passes_through() {
        // key_fn returns None → no lock is acquired; calls run
        // fully concurrently regardless of arguments.
        use std::sync::atomic::AtomicUsize;
        let in_flight = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let inner: Arc<dyn ChatModel> = Arc::new(DelayChatModel {
            delay_ms: 25,
            in_flight: in_flight.clone(),
            peak: peak.clone(),
        });
        let registry = Arc::new(KeyedMutex::<String>::new());
        let cm = Arc::new(KeyedSerializedChatModel::new(
            inner,
            registry,
            |_msgs, _opts| None,
        ));
        let mut handles = Vec::new();
        for _ in 0..4 {
            let cm = cm.clone();
            handles.push(tokio::spawn(async move {
                cm.invoke(
                    vec![Message::user("any")],
                    &ChatOptions::default(),
                )
                .await
            }));
        }
        for h in handles {
            h.await.unwrap().unwrap();
        }
        assert!(
            peak.load(Ordering::SeqCst) >= 2,
            "None key still serialized: peak {}",
            peak.load(Ordering::SeqCst),
        );
    }

    #[tokio::test]
    async fn keyed_serialized_name_proxies_inner() {
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let registry = Arc::new(KeyedMutex::<String>::new());
        let cm = KeyedSerializedChatModel::new(
            inner,
            registry,
            |_, _| Some("k".into()),
        );
        assert_eq!(cm.name(), "always-ok");
    }

    // ---- BulkheadChatModel / BulkheadEmbeddings tests -------------------

    #[tokio::test]
    async fn bulkhead_chat_rejects_with_rate_limited_when_at_cap() {
        use std::sync::atomic::AtomicUsize;
        let in_flight = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let inner: Arc<dyn ChatModel> = Arc::new(DelayChatModel {
            delay_ms: 30,
            in_flight: in_flight.clone(),
            peak: peak.clone(),
        });
        let bulkhead = Arc::new(Bulkhead::new(2));
        let cm = Arc::new(BulkheadChatModel::new(
            inner,
            bulkhead.clone(),
            BulkheadMode::Reject,
        ));
        // 5 concurrent calls: 2 should succeed, 3 should reject.
        let mut handles = Vec::new();
        for _ in 0..5 {
            let cm = cm.clone();
            handles.push(tokio::spawn(async move {
                cm.invoke(
                    vec![Message::user("hi")],
                    &ChatOptions::default(),
                )
                .await
            }));
        }
        let mut oks = 0;
        let mut rate_limited = 0;
        for h in handles {
            match h.await.unwrap() {
                Ok(_) => oks += 1,
                Err(Error::RateLimited { .. }) => rate_limited += 1,
                Err(e) => panic!("unexpected error: {e:?}"),
            }
        }
        // Cap=2 → at most 2 concurrent in-flight. Some calls finish
        // before others start, so up to 5 may succeed depending on
        // scheduling — but rejected_count must reflect actual rejects.
        assert!(oks >= 2, "fewer than cap calls succeeded: {oks}");
        assert!(
            rate_limited >= 1,
            "expected at least one rejection: rate_limited={rate_limited}",
        );
        assert_eq!(rate_limited as u64, bulkhead.rejected_count());
        assert!(
            peak.load(std::sync::atomic::Ordering::SeqCst) <= 2,
            "peak in_flight exceeded cap",
        );
    }

    #[tokio::test]
    async fn bulkhead_chat_wait_mode_blocks_then_succeeds() {
        use std::sync::atomic::AtomicUsize;
        let in_flight = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let inner: Arc<dyn ChatModel> = Arc::new(DelayChatModel {
            delay_ms: 20,
            in_flight: in_flight.clone(),
            peak: peak.clone(),
        });
        let bulkhead = Arc::new(Bulkhead::new(1));
        let cm = Arc::new(BulkheadChatModel::new(
            inner,
            bulkhead.clone(),
            BulkheadMode::WaitUpTo(Duration::from_millis(100)),
        ));
        // 3 concurrent calls under cap=1 with 20ms delay each.
        // wait window 100ms is enough for all to succeed.
        let mut handles = Vec::new();
        for _ in 0..3 {
            let cm = cm.clone();
            handles.push(tokio::spawn(async move {
                cm.invoke(
                    vec![Message::user("hi")],
                    &ChatOptions::default(),
                )
                .await
            }));
        }
        for h in handles {
            h.await.unwrap().unwrap();
        }
        // Strict cap=1 → peak in_flight must be 1.
        assert_eq!(peak.load(std::sync::atomic::Ordering::SeqCst), 1);
        // Within window, no rejects.
        assert_eq!(bulkhead.rejected_count(), 0);
    }

    #[tokio::test]
    async fn bulkhead_chat_wait_mode_rejects_after_deadline() {
        use std::sync::atomic::AtomicUsize;
        let in_flight = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let inner: Arc<dyn ChatModel> = Arc::new(DelayChatModel {
            delay_ms: 100, // long-held slot
            in_flight: in_flight.clone(),
            peak: peak.clone(),
        });
        let bulkhead = Arc::new(Bulkhead::new(1));
        let cm = Arc::new(BulkheadChatModel::new(
            inner,
            bulkhead.clone(),
            BulkheadMode::WaitUpTo(Duration::from_millis(15)),
        ));
        // First call holds the slot 100ms.
        let cm1 = cm.clone();
        let h1 = tokio::spawn(async move {
            cm1.invoke(
                vec![Message::user("hi")],
                &ChatOptions::default(),
            )
            .await
        });
        // Give it a beat to enter.
        tokio::time::sleep(Duration::from_millis(5)).await;
        // Second call: waits 15ms, then rejects.
        let r = cm
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await;
        assert!(matches!(r, Err(Error::RateLimited { .. })));
        h1.await.unwrap().unwrap();
        assert_eq!(bulkhead.rejected_count(), 1);
    }

    #[tokio::test]
    async fn bulkhead_chat_succeeds_when_under_cap() {
        let bulkhead = Arc::new(Bulkhead::new(5));
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let cm = BulkheadChatModel::new(inner, bulkhead.clone(), BulkheadMode::Reject);
        for _ in 0..5 {
            cm.invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await
                .unwrap();
        }
        assert_eq!(bulkhead.rejected_count(), 0);
    }

    #[tokio::test]
    async fn bulkhead_embed_rejects_when_at_cap() {
        let bulkhead = Arc::new(Bulkhead::new(1));
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 3);
        let cm = Arc::new(BulkheadEmbeddings::new(
            inner as Arc<dyn Embeddings>,
            bulkhead.clone(),
            BulkheadMode::Reject,
        ));
        // Hold a slot via try_enter directly so we can verify the
        // wrapper rejects under cap.
        let _held = bulkhead.try_enter().unwrap();
        let r = cm.embed_query("hi").await;
        assert!(matches!(r, Err(Error::RateLimited { .. })));
        let r = cm.embed_documents(&["a".into()]).await;
        assert!(matches!(r, Err(Error::RateLimited { .. })));
        assert_eq!(bulkhead.rejected_count(), 2);
    }

    #[tokio::test]
    async fn bulkhead_chat_and_embed_share_one_budget() {
        // One Bulkhead spans both axes.
        let bulkhead = Arc::new(Bulkhead::new(1));
        let chat: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let embed = flaky_embed(0, EmbedFlakyKind::Provider5xx, 3);
        let cm = BulkheadChatModel::new(
            chat,
            bulkhead.clone(),
            BulkheadMode::Reject,
        );
        let em = BulkheadEmbeddings::new(
            embed as Arc<dyn Embeddings>,
            bulkhead.clone(),
            BulkheadMode::Reject,
        );
        // Hold the slot.
        let _held = bulkhead.try_enter().unwrap();
        // Both axes reject because the shared bulkhead is full.
        let r1 = cm
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await;
        let r2 = em.embed_query("hi").await;
        assert!(matches!(r1, Err(Error::RateLimited { .. })));
        assert!(matches!(r2, Err(Error::RateLimited { .. })));
        assert_eq!(bulkhead.rejected_count(), 2);
    }

    #[tokio::test]
    async fn bulkhead_chat_name_proxies_inner() {
        let bulkhead = Arc::new(Bulkhead::new(5));
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let cm = BulkheadChatModel::new(inner, bulkhead, BulkheadMode::Reject);
        assert_eq!(cm.name(), "always-ok");
    }

    // ---- HedgedChatModel / HedgedEmbeddings tests ----------------------

    /// Returns a fixed text after `delay_ms`. Counts invocations so
    /// tests can assert whether backup was actually invoked.
    struct LabeledDelayChat {
        delay_ms: u64,
        label: String,
        seen: AtomicU32,
    }

    #[async_trait]
    impl ChatModel for LabeledDelayChat {
        fn name(&self) -> &str {
            "labeled-delay-chat"
        }
        async fn invoke(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatResponse> {
            self.seen.fetch_add(1, Ordering::SeqCst);
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            Ok(ChatResponse {
                message: Message {
                    role: Role::Assistant,
                    content: vec![ContentPart::Text {
                        text: self.label.clone(),
                    }],
                    tool_calls: vec![],
                    tool_call_id: None,
                    name: None,
                    cache: false,
                },
                finish_reason: FinishReason::Stop,
                usage: TokenUsage::default(),
                model: "labeled-delay-chat".into(),
            })
        }
        async fn stream(
            &self,
            _m: Vec<Message>,
            _o: &ChatOptions,
        ) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test]
    async fn hedged_chat_primary_wins_when_fast_no_backup_invoked() {
        let primary = Arc::new(LabeledDelayChat {
            delay_ms: 10,
            label: "PRIMARY".into(),
            seen: AtomicU32::new(0),
        });
        let backup = Arc::new(LabeledDelayChat {
            delay_ms: 10,
            label: "BACKUP".into(),
            seen: AtomicU32::new(0),
        });
        let hc = HedgedChatModel::new(
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
            Duration::from_millis(50),
        );
        let resp = hc
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(resp.message.text_content(), "PRIMARY");
        assert_eq!(primary.seen.load(Ordering::SeqCst), 1);
        // Backup never even invoked.
        assert_eq!(backup.seen.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn hedged_chat_backup_wins_when_primary_slow() {
        let primary = Arc::new(LabeledDelayChat {
            delay_ms: 100,
            label: "PRIMARY".into(),
            seen: AtomicU32::new(0),
        });
        let backup = Arc::new(LabeledDelayChat {
            delay_ms: 10,
            label: "BACKUP".into(),
            seen: AtomicU32::new(0),
        });
        let hc = HedgedChatModel::new(
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
            Duration::from_millis(20),
        );
        let resp = hc
            .invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        // Primary started at 0ms, finishes at 100ms.
        // Backup started at 20ms, finishes at 30ms → wins.
        assert_eq!(resp.message.text_content(), "BACKUP");
        assert_eq!(primary.seen.load(Ordering::SeqCst), 1);
        assert_eq!(backup.seen.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn hedged_chat_stream_passes_through_to_primary_only() {
        // stream() is documented as primary-only. Use a model that
        // panics on stream so we'd notice if backup was hit.
        struct StreamCounter {
            seen: AtomicU32,
            text: String,
        }
        #[async_trait]
        impl ChatModel for StreamCounter {
            fn name(&self) -> &str {
                "stream-counter"
            }
            async fn invoke(
                &self,
                _m: Vec<Message>,
                _o: &ChatOptions,
            ) -> Result<ChatResponse> {
                Ok(ChatResponse {
                    message: Message {
                        role: Role::Assistant,
                        content: vec![ContentPart::Text {
                            text: self.text.clone(),
                        }],
                        tool_calls: vec![],
                        tool_call_id: None,
                        name: None,
                        cache: false,
                    },
                    finish_reason: FinishReason::Stop,
                    usage: TokenUsage::default(),
                    model: "stream-counter".into(),
                })
            }
            async fn stream(
                &self,
                _m: Vec<Message>,
                _o: &ChatOptions,
            ) -> Result<ChatStream> {
                self.seen.fetch_add(1, Ordering::SeqCst);
                Err(Error::other("stream not implemented for test"))
            }
        }
        let primary = Arc::new(StreamCounter {
            seen: AtomicU32::new(0),
            text: "P".into(),
        });
        let backup = Arc::new(StreamCounter {
            seen: AtomicU32::new(0),
            text: "B".into(),
        });
        let hc = HedgedChatModel::new(
            primary.clone() as Arc<dyn ChatModel>,
            backup.clone() as Arc<dyn ChatModel>,
            Duration::from_millis(0),
        );
        let _ = hc
            .stream(vec![Message::user("hi")], &ChatOptions::default())
            .await;
        // Stream hit primary exactly once; backup not touched.
        assert_eq!(primary.seen.load(Ordering::SeqCst), 1);
        assert_eq!(backup.seen.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn hedged_chat_name_proxies_primary() {
        let primary: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let backup: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let hc = HedgedChatModel::new(primary, backup, Duration::from_millis(50));
        assert_eq!(hc.name(), "always-ok");
    }

    #[tokio::test]
    async fn hedged_embed_primary_wins_when_fast() {
        // Re-use FlakyEmbed with fails=0 (always succeeds) and a
        // wall-clock delay shim. Simplest: make a delayed dummy embedder.
        struct DelayEmbed {
            delay_ms: u64,
            tag: f32,
            seen: AtomicU32,
        }
        #[async_trait]
        impl Embeddings for DelayEmbed {
            fn name(&self) -> &str {
                "delay-embed"
            }
            fn dimensions(&self) -> usize {
                3
            }
            async fn embed_query(&self, _t: &str) -> Result<Vec<f32>> {
                self.seen.fetch_add(1, Ordering::SeqCst);
                tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
                Ok(vec![self.tag; 3])
            }
            async fn embed_documents(
                &self,
                texts: &[String],
            ) -> Result<Vec<Vec<f32>>> {
                self.seen.fetch_add(1, Ordering::SeqCst);
                tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
                Ok(vec![vec![self.tag; 3]; texts.len()])
            }
        }
        let primary = Arc::new(DelayEmbed {
            delay_ms: 5,
            tag: 1.0,
            seen: AtomicU32::new(0),
        });
        let backup = Arc::new(DelayEmbed {
            delay_ms: 5,
            tag: 9.0,
            seen: AtomicU32::new(0),
        });
        let he = HedgedEmbeddings::new(
            primary.clone() as Arc<dyn Embeddings>,
            backup.clone() as Arc<dyn Embeddings>,
            Duration::from_millis(50),
        );
        let v = he.embed_query("hi").await.unwrap();
        assert_eq!(v[0], 1.0);
        assert_eq!(backup.seen.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn hedged_embed_backup_wins_when_primary_slow() {
        struct DelayEmbed {
            delay_ms: u64,
            tag: f32,
            seen: AtomicU32,
        }
        #[async_trait]
        impl Embeddings for DelayEmbed {
            fn name(&self) -> &str {
                "delay-embed"
            }
            fn dimensions(&self) -> usize {
                2
            }
            async fn embed_query(&self, _t: &str) -> Result<Vec<f32>> {
                self.seen.fetch_add(1, Ordering::SeqCst);
                tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
                Ok(vec![self.tag; 2])
            }
            async fn embed_documents(
                &self,
                texts: &[String],
            ) -> Result<Vec<Vec<f32>>> {
                self.seen.fetch_add(1, Ordering::SeqCst);
                tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
                Ok(vec![vec![self.tag; 2]; texts.len()])
            }
        }
        let primary = Arc::new(DelayEmbed {
            delay_ms: 100,
            tag: 1.0,
            seen: AtomicU32::new(0),
        });
        let backup = Arc::new(DelayEmbed {
            delay_ms: 5,
            tag: 9.0,
            seen: AtomicU32::new(0),
        });
        let he = HedgedEmbeddings::new(
            primary.clone() as Arc<dyn Embeddings>,
            backup.clone() as Arc<dyn Embeddings>,
            Duration::from_millis(20),
        );
        let docs = he.embed_documents(&["a".into(), "b".into()]).await.unwrap();
        // Backup wins, returning tag=9.0.
        assert_eq!(docs[0][0], 9.0);
        assert_eq!(primary.seen.load(Ordering::SeqCst), 1);
        assert_eq!(backup.seen.load(Ordering::SeqCst), 1);
    }

    // ---- RecordingChatModel / ReplayingChatModel tests -----------------

    #[tokio::test]
    async fn record_then_replay_round_trip() {
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let cassette = Arc::new(parking_lot::Mutex::new(Cassette::default()));
        let recorder = RecordingChatModel::new(inner, cassette.clone());
        // Make 3 calls with different inputs.
        recorder
            .invoke(vec![Message::user("a")], &ChatOptions::default())
            .await
            .unwrap();
        recorder
            .invoke(vec![Message::user("b")], &ChatOptions::default())
            .await
            .unwrap();
        recorder
            .invoke(vec![Message::user("a")], &ChatOptions::default())
            .await
            .unwrap();
        let snap = cassette.lock().clone();
        assert_eq!(snap.exchanges.len(), 3);
        // Now replay using the cassette.
        let player = ReplayingChatModel::new(snap, None);
        let r1 = player
            .invoke(vec![Message::user("a")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(r1.message.text_content(), "hi"); // AlwaysOkModel returns "hi"
        // Same input replayed twice — should hit twice.
        let r2 = player
            .invoke(vec![Message::user("a")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(r2.message.text_content(), "hi");
    }

    #[tokio::test]
    async fn replay_miss_returns_error_when_no_passthrough() {
        let cassette = Cassette::default();
        let player = ReplayingChatModel::new(cassette, None);
        let r = player
            .invoke(vec![Message::user("nope")], &ChatOptions::default())
            .await;
        match r {
            Err(Error::Provider(msg)) => {
                assert!(msg.contains("no recorded response"));
            }
            other => panic!("expected Provider error, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn replay_miss_falls_through_to_passthrough() {
        let cassette = Cassette::default();
        let live: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let player = ReplayingChatModel::new(cassette, Some(live));
        let r = player
            .invoke(vec![Message::user("anything")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(r.message.text_content(), "hi");
    }

    #[tokio::test]
    async fn cassette_serializes_to_json_round_trip() {
        // Round-trip via JSON to verify the cassette is portable.
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let cass = Arc::new(parking_lot::Mutex::new(Cassette::default()));
        let recorder = RecordingChatModel::new(inner, cass.clone());
        recorder
            .invoke(vec![Message::user("hello")], &ChatOptions::default())
            .await
            .unwrap();
        let snap = cass.lock().clone();
        let s = serde_json::to_string(&snap).unwrap();
        let restored: Cassette = serde_json::from_str(&s).unwrap();
        assert_eq!(restored.exchanges.len(), 1);
        // Replay using the restored cassette.
        let player = ReplayingChatModel::new(restored, None);
        let r = player
            .invoke(vec![Message::user("hello")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(r.message.text_content(), "hi");
    }

    #[tokio::test]
    async fn request_hash_is_deterministic_across_orderings() {
        // Two requests with semantically-identical canonical JSON
        // must hash the same regardless of HashMap iteration order
        // for opts (response_format etc). AlwaysOkModel ignores opts
        // anyway, so the test verifies the hash function via direct
        // comparison.
        let m1 = vec![Message::user("hi")];
        let m2 = vec![Message::user("hi")];
        let opts = ChatOptions {
            temperature: Some(0.7),
            ..Default::default()
        };
        let h1 = exchange_hash(&m1, &opts);
        let h2 = exchange_hash(&m2, &opts);
        assert_eq!(h1, h2);
        let opts2 = ChatOptions {
            temperature: Some(0.5),
            ..Default::default()
        };
        let h3 = exchange_hash(&m1, &opts2);
        assert_ne!(h1, h3);
    }

    // ---- SingleflightEmbeddings tests ----------------------------------

    /// Counts inner calls per text. Lets tests verify dedup happened.
    struct SfCountingEmbed {
        delay_ms: u64,
        seen: AtomicU32,
        dim: usize,
    }

    #[async_trait]
    impl Embeddings for SfCountingEmbed {
        fn name(&self) -> &str {
            "sf-counting-embed"
        }
        fn dimensions(&self) -> usize {
            self.dim
        }
        async fn embed_query(&self, text: &str) -> Result<Vec<f32>> {
            self.seen.fetch_add(1, Ordering::SeqCst);
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            // Embedding is deterministic from text length so we can
            // verify followers got the leader's actual value.
            Ok(vec![text.len() as f32; self.dim])
        }
        async fn embed_documents(&self, texts: &[String]) -> Result<Vec<Vec<f32>>> {
            self.seen.fetch_add(1, Ordering::SeqCst);
            Ok(vec![vec![0.0; self.dim]; texts.len()])
        }
    }

    #[tokio::test]
    async fn singleflight_concurrent_same_query_one_inner_call() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 30,
            seen: AtomicU32::new(0),
            dim: 4,
        });
        let sf = Arc::new(SingleflightEmbeddings::new(
            inner.clone() as Arc<dyn Embeddings>,
        ));
        let mut handles = Vec::new();
        for _ in 0..10 {
            let sf = sf.clone();
            handles.push(tokio::spawn(async move {
                sf.embed_query("same query").await
            }));
        }
        for h in handles {
            let v = h.await.unwrap().unwrap();
            // All callers got the leader's deterministic value.
            assert_eq!(v, vec!["same query".len() as f32; 4]);
        }
        assert_eq!(
            inner.seen.load(Ordering::SeqCst),
            1,
            "inner.embed_query ran more than once",
        );
    }

    #[tokio::test]
    async fn singleflight_different_queries_run_independently() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 5,
            seen: AtomicU32::new(0),
            dim: 3,
        });
        let sf = Arc::new(SingleflightEmbeddings::new(
            inner.clone() as Arc<dyn Embeddings>,
        ));
        let mut handles = Vec::new();
        for q in ["a", "bb", "ccc", "dddd"] {
            let sf = sf.clone();
            handles.push(tokio::spawn(async move {
                sf.embed_query(q).await
            }));
        }
        for h in handles {
            let _ = h.await.unwrap().unwrap();
        }
        assert_eq!(inner.seen.load(Ordering::SeqCst), 4);
    }

    #[tokio::test]
    async fn singleflight_embed_documents_passes_through() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 2,
        });
        let sf = SingleflightEmbeddings::new(inner.clone() as Arc<dyn Embeddings>);
        let _ = sf.embed_documents(&["a".into(), "b".into()]).await.unwrap();
        let _ = sf.embed_documents(&["a".into(), "b".into()]).await.unwrap();
        // Pass-through, no dedup.
        assert_eq!(inner.seen.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn singleflight_propagates_errors_as_provider_error() {
        // FlakyEmbed with 1 fail then OK; first call gets the
        // 502 error, second call past the in-flight window starts
        // fresh and succeeds.
        let inner = flaky_embed(1, EmbedFlakyKind::Provider5xx, 3);
        let sf = SingleflightEmbeddings::new(inner.clone() as Arc<dyn Embeddings>);
        let r1 = sf.embed_query("q").await;
        // Error variant collapses to Error::Provider(...) on the
        // singleflight path (lossy-by-design).
        match r1 {
            Err(Error::Provider(s)) => {
                assert!(s.contains("502") || s.contains("provider"));
            }
            other => panic!("expected Provider error, got {other:?}"),
        }
        // Next call: in-flight window closed, fresh compute, succeeds.
        let r2 = sf.embed_query("q").await;
        assert!(r2.is_ok());
    }

    #[tokio::test]
    async fn singleflight_name_and_dimensions_proxy_inner() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 7,
        });
        let sf = SingleflightEmbeddings::new(inner as Arc<dyn Embeddings>);
        assert_eq!(sf.name(), "sf-counting-embed");
        assert_eq!(sf.dimensions(), 7);
    }

    // ---- Cassette file IO + Embeddings record/replay tests --------------

    #[tokio::test]
    async fn cassette_save_and_load_round_trip_through_disk() {
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let cass = Arc::new(parking_lot::Mutex::new(Cassette::default()));
        let recorder = RecordingChatModel::new(inner, cass.clone());
        recorder
            .invoke(vec![Message::user("disk-test")], &ChatOptions::default())
            .await
            .unwrap();
        let snap = cass.lock().clone();
        let tmp = tempfile::NamedTempFile::new().unwrap();
        let path = tmp.path().to_path_buf();
        snap.save_to_file(&path).unwrap();
        let restored = Cassette::load_from_file(&path).unwrap();
        assert_eq!(restored.exchanges.len(), 1);
        let player = ReplayingChatModel::new(restored, None);
        let r = player
            .invoke(vec![Message::user("disk-test")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(r.message.text_content(), "hi");
    }

    #[tokio::test]
    async fn cassette_save_creates_parent_directory() {
        let cass = Cassette::default();
        let tmp = tempfile::tempdir().unwrap();
        let nested = tmp.path().join("a").join("b").join("c.json");
        cass.save_to_file(&nested).unwrap();
        assert!(nested.exists());
    }

    #[tokio::test]
    async fn embed_record_then_replay_round_trip() {
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 4);
        let cass = Arc::new(parking_lot::Mutex::new(EmbedCassette::default()));
        let recorder =
            RecordingEmbeddings::new(inner.clone() as Arc<dyn Embeddings>, cass.clone());
        // Record both embed_query and embed_documents.
        recorder.embed_query("hello").await.unwrap();
        recorder
            .embed_documents(&["a".into(), "b".into()])
            .await
            .unwrap();
        recorder.embed_query("world").await.unwrap();
        let snap = cass.lock().clone();
        assert_eq!(snap.exchanges.len(), 3);
        // Replay via the cassette.
        let player = ReplayingEmbeddings::new(snap, None);
        let v1 = player.embed_query("hello").await.unwrap();
        assert_eq!(v1.len(), 4); // FlakyEmbed dim
        let v2 = player.embed_query("world").await.unwrap();
        assert_eq!(v2.len(), 4);
        let docs = player
            .embed_documents(&["a".into(), "b".into()])
            .await
            .unwrap();
        assert_eq!(docs.len(), 2);
    }

    #[tokio::test]
    async fn embed_replay_miss_returns_error_when_no_passthrough() {
        let cass = EmbedCassette::default();
        let player = ReplayingEmbeddings::new(cass, None);
        let r = player.embed_query("nope").await;
        match r {
            Err(Error::Provider(msg)) => {
                assert!(msg.contains("no recorded embed_query"));
            }
            other => panic!("expected Provider error, got {other:?}"),
        }
        let r2 = player.embed_documents(&["x".into()]).await;
        match r2 {
            Err(Error::Provider(msg)) => {
                assert!(msg.contains("no recorded embed_documents"));
            }
            other => panic!("expected Provider error, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn embed_replay_miss_falls_through_to_passthrough() {
        let cass = EmbedCassette::default();
        let live = flaky_embed(0, EmbedFlakyKind::Provider5xx, 5);
        let player =
            ReplayingEmbeddings::new(cass, Some(live as Arc<dyn Embeddings>));
        let v = player.embed_query("anything").await.unwrap();
        assert_eq!(v.len(), 5);
    }

    #[tokio::test]
    async fn embed_replay_dimensions_proxy_or_first_exchange() {
        // Without passthrough: dimensions from the first exchange.
        let mut cass = EmbedCassette::default();
        cass.exchanges.push(EmbedExchange::Query {
            request_hash: embed_query_hash("x"),
            text: "x".into(),
            response: vec![0.0; 11],
        });
        let player = ReplayingEmbeddings::new(cass, None);
        assert_eq!(player.dimensions(), 11);

        // With passthrough: dimensions delegated.
        let live = flaky_embed(0, EmbedFlakyKind::Provider5xx, 13);
        let player2 = ReplayingEmbeddings::new(
            EmbedCassette::default(),
            Some(live as Arc<dyn Embeddings>),
        );
        assert_eq!(player2.dimensions(), 13);
    }

    #[tokio::test]
    async fn embed_cassette_save_and_load_through_disk() {
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 3);
        let cass = Arc::new(parking_lot::Mutex::new(EmbedCassette::default()));
        let recorder =
            RecordingEmbeddings::new(inner as Arc<dyn Embeddings>, cass.clone());
        recorder.embed_query("disk-text").await.unwrap();
        let snap = cass.lock().clone();
        let tmp = tempfile::NamedTempFile::new().unwrap();
        snap.save_to_file(tmp.path()).unwrap();
        let restored = EmbedCassette::load_from_file(tmp.path()).unwrap();
        let player = ReplayingEmbeddings::new(restored, None);
        let v = player.embed_query("disk-text").await.unwrap();
        assert_eq!(v.len(), 3);
    }

    #[tokio::test]
    async fn embed_query_hash_is_deterministic() {
        assert_eq!(embed_query_hash("a"), embed_query_hash("a"));
        assert_ne!(embed_query_hash("a"), embed_query_hash("b"));
    }

    // ---- MetricsChatModel / MetricsEmbeddings tests --------------------

    #[tokio::test]
    async fn metrics_chat_records_invocations_and_latency() {
        let registry = MetricsRegistry::new();
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let mc = MetricsChatModel::new(inner, &registry);
        for _ in 0..3 {
            mc.invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await
                .unwrap();
        }
        assert_eq!(registry.counter("chat_invocations_total").get(), 3);
        assert_eq!(registry.counter("chat_errors_total").get(), 0);
        // in_flight should be 0 after all calls return.
        assert_eq!(registry.gauge("chat_in_flight").get(), 0);
        // Latency histogram observed 3 times.
        assert_eq!(
            registry.histogram("chat_latency_seconds", DEFAULT_LATENCY_BUCKETS_SECS).count(),
            3,
        );
    }

    #[tokio::test]
    async fn metrics_chat_counts_errors() {
        let registry = MetricsRegistry::new();
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysFailModel {
            seen: AtomicU32::new(0),
        });
        let mc = MetricsChatModel::new(inner, &registry);
        for _ in 0..4 {
            let _ = mc
                .invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await;
        }
        assert_eq!(registry.counter("chat_invocations_total").get(), 4);
        assert_eq!(registry.counter("chat_errors_total").get(), 4);
    }

    #[tokio::test]
    async fn metrics_chat_in_flight_gauge_tracks_concurrent_calls() {
        use std::sync::atomic::AtomicUsize;
        let registry = Arc::new(MetricsRegistry::new());
        let in_flight = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let inner: Arc<dyn ChatModel> = Arc::new(DelayChatModel {
            delay_ms: 30,
            in_flight: in_flight.clone(),
            peak: peak.clone(),
        });
        let mc = Arc::new(MetricsChatModel::new(inner, registry.as_ref()));
        // Spawn 3 concurrent invokes; capture the gauge mid-flight.
        let mut handles = Vec::new();
        for _ in 0..3 {
            let mc = mc.clone();
            handles.push(tokio::spawn(async move {
                mc.invoke(vec![Message::user("hi")], &ChatOptions::default())
                    .await
            }));
        }
        // Sample mid-flight.
        tokio::time::sleep(Duration::from_millis(10)).await;
        let mid = registry.gauge("chat_in_flight").get();
        for h in handles {
            h.await.unwrap().unwrap();
        }
        // Some workers were in flight at sample time.
        assert!(mid >= 1, "in_flight gauge never observed concurrent work");
        // After all complete, gauge is back to 0.
        assert_eq!(registry.gauge("chat_in_flight").get(), 0);
    }

    #[tokio::test]
    async fn metrics_chat_with_prefix_uses_custom_name() {
        let registry = MetricsRegistry::new();
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let mc = MetricsChatModel::with_prefix(inner, &registry, "openai_gpt4");
        mc.invoke(vec![Message::user("hi")], &ChatOptions::default())
            .await
            .unwrap();
        assert_eq!(registry.counter("openai_gpt4_invocations_total").get(), 1);
        // Default chat_* counters should NOT be created.
        let prom = registry.to_prometheus();
        assert!(prom.contains("openai_gpt4_invocations_total 1"));
        assert!(!prom.contains("\nchat_invocations_total "));
    }

    #[tokio::test]
    async fn metrics_chat_name_proxies_inner() {
        let registry = MetricsRegistry::new();
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysOkModel);
        let mc = MetricsChatModel::new(inner, &registry);
        assert_eq!(mc.name(), "always-ok");
    }

    #[tokio::test]
    async fn metrics_embed_records_both_methods() {
        let registry = MetricsRegistry::new();
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 4);
        let me = MetricsEmbeddings::new(inner as Arc<dyn Embeddings>, &registry);
        me.embed_query("hi").await.unwrap();
        me.embed_documents(&["a".into(), "b".into()]).await.unwrap();
        assert_eq!(registry.counter("embed_invocations_total").get(), 2);
        assert_eq!(registry.counter("embed_errors_total").get(), 0);
    }

    #[tokio::test]
    async fn metrics_embed_dimensions_proxy_inner() {
        let registry = MetricsRegistry::new();
        let inner = flaky_embed(0, EmbedFlakyKind::Provider5xx, 9);
        let me = MetricsEmbeddings::new(inner as Arc<dyn Embeddings>, &registry);
        assert_eq!(me.dimensions(), 9);
        assert_eq!(me.name(), "flaky-embed");
    }

    // ---- SingleflightTool tests ----------------------------------------

    /// Slow echo tool: sleeps `delay_ms` then echoes args. Counts
    /// inner invocations so tests verify dedup happened.
    struct SlowEchoTool {
        seen: AtomicU32,
        delay_ms: u64,
    }

    #[async_trait]
    impl litgraph_core::tool::Tool for SlowEchoTool {
        fn schema(&self) -> litgraph_core::tool::ToolSchema {
            litgraph_core::tool::ToolSchema {
                name: "slow_echo".into(),
                description: "echo with delay".into(),
                parameters: serde_json::json!({"type":"object"}),
            }
        }
        async fn run(
            &self,
            args: serde_json::Value,
        ) -> Result<serde_json::Value> {
            self.seen.fetch_add(1, Ordering::SeqCst);
            tokio::time::sleep(Duration::from_millis(self.delay_ms)).await;
            Ok(serde_json::json!({"echo": args}))
        }
    }

    #[tokio::test]
    async fn singleflight_tool_concurrent_same_args_one_call() {
        let inner = Arc::new(SlowEchoTool {
            seen: AtomicU32::new(0),
            delay_ms: 30,
        });
        let sf = Arc::new(SingleflightTool::new(
            inner.clone() as Arc<dyn litgraph_core::tool::Tool>,
        ));
        let mut handles = Vec::new();
        for _ in 0..10 {
            let sf = sf.clone();
            handles.push(tokio::spawn(async move {
                sf.run(serde_json::json!({"key": "shared"})).await
            }));
        }
        for h in handles {
            let v = h.await.unwrap().unwrap();
            assert_eq!(v, serde_json::json!({"echo": {"key": "shared"}}));
        }
        // Single inner call despite 10 concurrent identical args.
        assert_eq!(
            inner.seen.load(Ordering::SeqCst),
            1,
            "inner ran more than once",
        );
    }

    #[tokio::test]
    async fn singleflight_tool_different_args_run_independently() {
        let inner = Arc::new(SlowEchoTool {
            seen: AtomicU32::new(0),
            delay_ms: 5,
        });
        let sf = Arc::new(SingleflightTool::new(
            inner.clone() as Arc<dyn litgraph_core::tool::Tool>,
        ));
        let mut handles = Vec::new();
        for i in 0..5 {
            let sf = sf.clone();
            handles.push(tokio::spawn(async move {
                sf.run(serde_json::json!({"i": i})).await
            }));
        }
        for h in handles {
            let _ = h.await.unwrap().unwrap();
        }
        assert_eq!(inner.seen.load(Ordering::SeqCst), 5);
    }

    #[tokio::test]
    async fn singleflight_tool_propagates_errors_as_provider_error() {
        let inner: Arc<dyn litgraph_core::tool::Tool> = Arc::new(AlwaysFailTool);
        let sf = SingleflightTool::new(inner);
        let r = sf.run(serde_json::json!({"q": "bad"})).await;
        match r {
            Err(Error::Provider(msg)) => {
                assert!(msg.contains("synthetic"));
            }
            other => panic!("expected Provider error, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn singleflight_tool_window_closes_after_completion() {
        // First call runs compute; second call after the in-flight
        // window closes runs compute again.
        let inner = Arc::new(SlowEchoTool {
            seen: AtomicU32::new(0),
            delay_ms: 0,
        });
        let sf = SingleflightTool::new(
            inner.clone() as Arc<dyn litgraph_core::tool::Tool>,
        );
        let _ = sf.run(serde_json::json!({"q": "a"})).await.unwrap();
        let _ = sf.run(serde_json::json!({"q": "a"})).await.unwrap();
        // Both calls ran independently — coalescing only inside an
        // in-flight window.
        assert_eq!(inner.seen.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn singleflight_tool_schema_proxies_inner() {
        let inner: Arc<dyn litgraph_core::tool::Tool> = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let sf = SingleflightTool::new(inner);
        assert_eq!(sf.schema().name, "echo");
    }

    #[tokio::test]
    async fn metrics_tool_records_invocations_and_errors() {
        let registry = MetricsRegistry::new();
        let inner = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let mt = MetricsTool::new(
            inner as Arc<dyn litgraph_core::tool::Tool>,
            &registry,
        );
        // Tool name is "echo" → prefix sanitizes to "echo".
        for _ in 0..3 {
            mt.run(serde_json::json!({"x": 1})).await.unwrap();
        }
        assert_eq!(registry.counter("echo_invocations_total").get(), 3);
        assert_eq!(registry.counter("echo_errors_total").get(), 0);
        assert_eq!(registry.gauge("echo_in_flight").get(), 0);
        assert_eq!(
            registry
                .histogram("echo_latency_seconds", DEFAULT_LATENCY_BUCKETS_SECS)
                .count(),
            3,
        );
    }

    /// Always-fails tool to verify error counter and in_flight RAII guard.
    struct AlwaysFailTool;

    #[async_trait]
    impl litgraph_core::tool::Tool for AlwaysFailTool {
        fn schema(&self) -> litgraph_core::tool::ToolSchema {
            litgraph_core::tool::ToolSchema {
                name: "fail".into(),
                description: "always fails".into(),
                parameters: serde_json::json!({"type":"object"}),
            }
        }
        async fn run(
            &self,
            _args: serde_json::Value,
        ) -> Result<serde_json::Value> {
            Err(Error::other("synthetic"))
        }
    }

    #[tokio::test]
    async fn metrics_tool_counts_errors_and_decs_gauge() {
        let registry = MetricsRegistry::new();
        let inner: Arc<dyn litgraph_core::tool::Tool> = Arc::new(AlwaysFailTool);
        let mt = MetricsTool::new(inner, &registry);
        for _ in 0..4 {
            let _ = mt.run(serde_json::json!({})).await;
        }
        assert_eq!(registry.counter("fail_invocations_total").get(), 4);
        assert_eq!(registry.counter("fail_errors_total").get(), 4);
        // RAII guard decremented on every error path.
        assert_eq!(registry.gauge("fail_in_flight").get(), 0);
    }

    #[tokio::test]
    async fn metrics_tool_with_prefix_uses_custom_name() {
        let registry = MetricsRegistry::new();
        let inner = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let mt = MetricsTool::with_prefix(
            inner as Arc<dyn litgraph_core::tool::Tool>,
            &registry,
            "google_search",
        );
        mt.run(serde_json::json!({"q": "test"})).await.unwrap();
        assert_eq!(registry.counter("google_search_invocations_total").get(), 1);
        // Default echo_* metric should NOT be present.
        let prom = registry.to_prometheus();
        assert!(prom.contains("google_search_invocations_total 1"));
        assert!(!prom.contains("\necho_invocations_total "));
    }

    #[tokio::test]
    async fn metrics_tool_sanitizes_tool_name_for_prefix() {
        // A tool named with a dot (`http.get`) should produce metrics
        // under `http_get_*` — Prometheus disallows dots in names.
        struct DottedTool;
        #[async_trait]
        impl litgraph_core::tool::Tool for DottedTool {
            fn schema(&self) -> litgraph_core::tool::ToolSchema {
                litgraph_core::tool::ToolSchema {
                    name: "http.get".into(),
                    description: String::new(),
                    parameters: serde_json::json!({"type":"object"}),
                }
            }
            async fn run(
                &self,
                _args: serde_json::Value,
            ) -> Result<serde_json::Value> {
                Ok(serde_json::json!({}))
            }
        }
        let registry = MetricsRegistry::new();
        let mt = MetricsTool::new(
            Arc::new(DottedTool) as Arc<dyn litgraph_core::tool::Tool>,
            &registry,
        );
        mt.run(serde_json::json!({})).await.unwrap();
        assert_eq!(registry.counter("http_get_invocations_total").get(), 1);
    }

    #[tokio::test]
    async fn metrics_tool_schema_proxies_inner() {
        let registry = MetricsRegistry::new();
        let inner: Arc<dyn litgraph_core::tool::Tool> = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let mt = MetricsTool::new(inner, &registry);
        assert_eq!(mt.schema().name, "echo");
    }

    #[tokio::test]
    async fn metrics_chat_in_flight_decrements_on_error_path() {
        let registry = MetricsRegistry::new();
        let inner: Arc<dyn ChatModel> = Arc::new(AlwaysFailModel {
            seen: AtomicU32::new(0),
        });
        let mc = MetricsChatModel::new(inner, &registry);
        // 5 errors back-to-back; gauge must end at 0 (RAII guard
        // decs even on error).
        for _ in 0..5 {
            let _ = mc
                .invoke(vec![Message::user("hi")], &ChatOptions::default())
                .await;
        }
        assert_eq!(registry.gauge("chat_in_flight").get(), 0);
    }

    #[tokio::test]
    async fn embed_documents_hash_distinguishes_order() {
        // Order matters: ["a","b"] != ["b","a"]. This is intentional —
        // embed_documents returns aligned vectors so order is part of
        // the request semantically.
        let h1 = embed_documents_hash(&["a".into(), "b".into()]);
        let h2 = embed_documents_hash(&["b".into(), "a".into()]);
        assert_ne!(h1, h2);
    }

    // ---- Tool record/replay tests --------------------------------------

    /// Echo tool: returns args under {"echo": ...}. Counts invocations.
    struct EchoTool {
        seen: AtomicU32,
    }

    #[async_trait]
    impl litgraph_core::tool::Tool for EchoTool {
        fn schema(&self) -> litgraph_core::tool::ToolSchema {
            litgraph_core::tool::ToolSchema {
                name: "echo".into(),
                description: "Echo args".into(),
                parameters: serde_json::json!({"type": "object"}),
            }
        }
        async fn run(
            &self,
            args: serde_json::Value,
        ) -> Result<serde_json::Value> {
            self.seen.fetch_add(1, Ordering::SeqCst);
            Ok(serde_json::json!({"echo": args}))
        }
    }

    #[tokio::test]
    async fn tool_record_then_replay_round_trip() {
        let inner = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let cass = Arc::new(parking_lot::Mutex::new(ToolCassette::default()));
        let recorder = RecordingTool::new(
            inner.clone() as Arc<dyn litgraph_core::tool::Tool>,
            cass.clone(),
        );
        // Record 3 calls.
        let r1 = recorder.run(serde_json::json!({"x": 1})).await.unwrap();
        let _ = recorder.run(serde_json::json!({"x": 2})).await.unwrap();
        let _ = recorder.run(serde_json::json!({"x": 1})).await.unwrap();
        assert_eq!(r1, serde_json::json!({"echo": {"x": 1}}));
        let snap = cass.lock().clone();
        assert_eq!(snap.exchanges.len(), 3);
        assert_eq!(inner.seen.load(Ordering::SeqCst), 3);
        // Replay.
        let player = ReplayingTool::new(snap, None);
        let r1b = player.run(serde_json::json!({"x": 1})).await.unwrap();
        assert_eq!(r1b, serde_json::json!({"echo": {"x": 1}}));
        let r2b = player.run(serde_json::json!({"x": 2})).await.unwrap();
        assert_eq!(r2b, serde_json::json!({"echo": {"x": 2}}));
        // Replay didn't bump inner.seen.
        assert_eq!(inner.seen.load(Ordering::SeqCst), 3);
    }

    #[tokio::test]
    async fn tool_replay_miss_returns_error_when_no_passthrough() {
        let cass = ToolCassette::default();
        let player = ReplayingTool::new(cass, None);
        let r = player.run(serde_json::json!({"q": "nope"})).await;
        match r {
            Err(Error::Provider(msg)) => {
                assert!(msg.contains("no recorded tool response"));
            }
            other => panic!("expected Provider error, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn tool_replay_miss_falls_through_to_passthrough() {
        let cass = ToolCassette::default();
        let live = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let player = ReplayingTool::new(
            cass,
            Some(live.clone() as Arc<dyn litgraph_core::tool::Tool>),
        );
        let r = player.run(serde_json::json!({"x": 7})).await.unwrap();
        assert_eq!(r, serde_json::json!({"echo": {"x": 7}}));
        assert_eq!(live.seen.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn tool_cassette_save_and_load_through_disk() {
        let inner = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let cass = Arc::new(parking_lot::Mutex::new(ToolCassette::default()));
        let recorder = RecordingTool::new(
            inner as Arc<dyn litgraph_core::tool::Tool>,
            cass.clone(),
        );
        recorder
            .run(serde_json::json!({"disk": "test"}))
            .await
            .unwrap();
        let snap = cass.lock().clone();
        let tmp = tempfile::NamedTempFile::new().unwrap();
        snap.save_to_file(tmp.path()).unwrap();
        let restored = ToolCassette::load_from_file(tmp.path()).unwrap();
        let player = ReplayingTool::new(restored, None);
        let r = player
            .run(serde_json::json!({"disk": "test"}))
            .await
            .unwrap();
        assert_eq!(r, serde_json::json!({"echo": {"disk": "test"}}));
    }

    #[tokio::test]
    async fn tool_args_hash_is_deterministic() {
        let h1 = tool_args_hash(&serde_json::json!({"x": 1, "y": 2}));
        let h2 = tool_args_hash(&serde_json::json!({"x": 1, "y": 2}));
        assert_eq!(h1, h2);
        let h3 = tool_args_hash(&serde_json::json!({"x": 1, "y": 3}));
        assert_ne!(h1, h3);
    }

    #[tokio::test]
    async fn tool_replay_schema_synthesized_when_no_passthrough() {
        let cass = ToolCassette::default();
        let player = ReplayingTool::new(cass, None)
            .with_name("custom_tool")
            .with_description("desc");
        let s = player.schema();
        assert_eq!(s.name, "custom_tool");
        assert_eq!(s.description, "desc");
        assert!(s.parameters.is_object());
    }

    #[tokio::test]
    async fn tool_replay_schema_proxied_to_passthrough() {
        let live = Arc::new(EchoTool {
            seen: AtomicU32::new(0),
        });
        let cass = ToolCassette::default();
        let player = ReplayingTool::new(
            cass,
            Some(live as Arc<dyn litgraph_core::tool::Tool>),
        );
        let s = player.schema();
        assert_eq!(s.name, "echo");
    }

    // ---- CachedEmbeddings tests ----------------------------------------

    #[tokio::test]
    async fn cached_embed_same_query_hits_cache() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 4,
        });
        let cached = CachedEmbeddings::new(inner.clone() as Arc<dyn Embeddings>);
        let v1 = cached.embed_query("hello").await.unwrap();
        let v2 = cached.embed_query("hello").await.unwrap();
        assert_eq!(v1, v2);
        // Inner called once; second call hit cache.
        assert_eq!(inner.seen.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn cached_embed_different_query_misses_cache() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 3,
        });
        let cached = CachedEmbeddings::new(inner.clone() as Arc<dyn Embeddings>);
        cached.embed_query("first").await.unwrap();
        cached.embed_query("second").await.unwrap();
        cached.embed_query("third").await.unwrap();
        assert_eq!(inner.seen.load(Ordering::SeqCst), 3);
    }

    #[tokio::test]
    async fn cached_embed_documents_caches_by_full_vec() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 2,
        });
        let cached = CachedEmbeddings::new(inner.clone() as Arc<dyn Embeddings>);
        cached
            .embed_documents(&["a".into(), "b".into()])
            .await
            .unwrap();
        cached
            .embed_documents(&["a".into(), "b".into()])
            .await
            .unwrap();
        // Same Vec → cache hit.
        assert_eq!(inner.seen.load(Ordering::SeqCst), 1);
        // Different Vec ordering → cache miss (Vec equality is
        // ordered).
        cached
            .embed_documents(&["b".into(), "a".into()])
            .await
            .unwrap();
        assert_eq!(inner.seen.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn cached_embed_query_and_documents_separate_caches() {
        // embed_query "x" doesn't satisfy embed_documents(["x"]).
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 2,
        });
        let cached = CachedEmbeddings::new(inner.clone() as Arc<dyn Embeddings>);
        cached.embed_query("x").await.unwrap();
        cached.embed_documents(&["x".into()]).await.unwrap();
        assert_eq!(inner.seen.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn cached_embed_ttl_expires_old_entries() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 2,
        });
        let cached = CachedEmbeddings::new(inner.clone() as Arc<dyn Embeddings>)
            .with_ttl(Duration::from_millis(20));
        cached.embed_query("q").await.unwrap();
        tokio::time::sleep(Duration::from_millis(40)).await;
        cached.embed_query("q").await.unwrap();
        assert_eq!(inner.seen.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn cached_embed_max_entries_evicts_oldest() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 2,
        });
        let cached = CachedEmbeddings::new(inner.clone() as Arc<dyn Embeddings>)
            .with_max_entries(2);
        cached.embed_query("a").await.unwrap();
        cached.embed_query("b").await.unwrap();
        cached.embed_query("c").await.unwrap();
        assert_eq!(cached.query_cache_len(), 2);
        // "a" was evicted; re-querying it misses cache.
        let baseline = inner.seen.load(Ordering::SeqCst);
        cached.embed_query("a").await.unwrap();
        assert_eq!(inner.seen.load(Ordering::SeqCst), baseline + 1);
    }

    #[tokio::test]
    async fn cached_embed_clear_drops_all() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 2,
        });
        let cached = CachedEmbeddings::new(inner.clone() as Arc<dyn Embeddings>);
        cached.embed_query("q").await.unwrap();
        cached.clear();
        cached.embed_query("q").await.unwrap();
        assert_eq!(inner.seen.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn cached_embed_dimensions_proxy_inner() {
        let inner = Arc::new(SfCountingEmbed {
            delay_ms: 0,
            seen: AtomicU32::new(0),
            dim: 9,
        });
        let cached = CachedEmbeddings::new(inner as Arc<dyn Embeddings>);
        assert_eq!(cached.dimensions(), 9);
        assert_eq!(cached.name(), "sf-counting-embed");
    }
}

// =============================================================================
// PromptCachingChatModel — auto-mark messages as Anthropic prompt-cache breakpoints.
// =============================================================================

/// Wrap any `ChatModel` to auto-set `Message.cache = true` on messages matching
/// a policy before forwarding. Anthropic (and Bedrock-on-Anthropic) providers
/// read the flag and attach `cache_control: {"type":"ephemeral"}` to the
/// message's last content block; other providers ignore it, so stacking is safe.
///
/// # Why
///
/// Anthropic's prompt cache discounts cached input tokens to ~0.1× (writes are
/// 1.25×). For agents with stable system prompts or long pinned context
/// (RAG docs, tool specs, style guides), a single cache hit can cut input
/// cost by 80–90%. The wrapper sidesteps having to flag `.cached()` at every
/// call site — declare the policy once on construction.
///
/// # Policy knobs
///
/// - `cache_system=true` (default) — mark the first System message.
/// - `cache_last_user_over=Some(N)` — mark the LAST User message if its text
///   exceeds N bytes (typical long-context-pinned-in-user pattern).
/// - `extra_indices` — manual: mark specific message indices. Overrides other
///   policies if set (advanced use).
///
/// Anthropic allows up to 4 breakpoints per request — the wrapper doesn't
/// enforce this cap (provider surfaces the error); keep policies minimal.
///
/// ```rust,ignore
/// use litgraph_resilience::PromptCachingChatModel;
/// let chat = PromptCachingChatModel::new(inner)
///     .cache_last_user_if_over(4096);  // cache system + long user
/// ```
pub struct PromptCachingChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub cache_system: bool,
    pub cache_last_user_over: Option<usize>,
    pub extra_indices: Vec<usize>,
}

impl PromptCachingChatModel {
    /// Default policy: cache the system message only. Most common pattern
    /// (stable system prompt across many turns).
    pub fn new(inner: Arc<dyn ChatModel>) -> Self {
        Self {
            inner,
            cache_system: true,
            cache_last_user_over: None,
            extra_indices: Vec::new(),
        }
    }

    /// Disable system-message caching. Use when the system prompt varies
    /// per-call and only user-side context is worth caching.
    pub fn without_system(mut self) -> Self {
        self.cache_system = false;
        self
    }

    /// Also mark the LAST User message as a cache breakpoint if its text
    /// content exceeds `bytes`. Threshold guards against caching short
    /// user turns (cache writes cost ~1.25× — pointless for small inputs).
    pub fn cache_last_user_if_over(mut self, bytes: usize) -> Self {
        self.cache_last_user_over = Some(bytes);
        self
    }

    /// Manually mark message indices as cache breakpoints. Indices out of
    /// range are silently ignored.
    pub fn cache_indices(mut self, indices: Vec<usize>) -> Self {
        self.extra_indices = indices;
        self
    }

    fn apply_policy(&self, mut messages: Vec<Message>) -> Vec<Message> {
        use litgraph_core::Role;

        if self.cache_system {
            if let Some(first_sys) = messages.iter_mut().find(|m| matches!(m.role, Role::System)) {
                first_sys.cache = true;
            }
        }

        if let Some(threshold) = self.cache_last_user_over {
            if let Some(last_user) = messages
                .iter_mut()
                .rev()
                .find(|m| matches!(m.role, Role::User))
            {
                if last_user.text_content().len() > threshold {
                    last_user.cache = true;
                }
            }
        }

        for &idx in &self.extra_indices {
            if let Some(m) = messages.get_mut(idx) {
                m.cache = true;
            }
        }

        messages
    }
}

#[async_trait]
impl ChatModel for PromptCachingChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        self.inner.invoke(self.apply_policy(messages), opts).await
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        self.inner.stream(self.apply_policy(messages), opts).await
    }
}

#[cfg(test)]
mod prompt_cache_tests {
    use super::*;
    use async_trait::async_trait;
    use litgraph_core::model::{ChatStream, FinishReason, TokenUsage};
    use litgraph_core::{ChatResponse, Message};
    use std::sync::Mutex;

    /// Records messages seen on invoke; returns a canned reply.
    struct SpyModel {
        seen: Mutex<Vec<Vec<Message>>>,
    }

    impl SpyModel {
        fn new() -> Arc<Self> {
            Arc::new(Self { seen: Mutex::new(Vec::new()) })
        }
    }

    #[async_trait]
    impl ChatModel for SpyModel {
        fn name(&self) -> &str { "spy" }
        async fn invoke(
            &self,
            messages: Vec<Message>,
            _opts: &ChatOptions,
        ) -> Result<ChatResponse> {
            self.seen.lock().unwrap().push(messages);
            Ok(ChatResponse {
                message: Message::assistant("ok"),
                finish_reason: FinishReason::Stop,
                usage: TokenUsage { prompt: 1, completion: 1, total: 2, cache_creation: 0, cache_read: 0 },
                model: "spy".into(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test]
    async fn default_caches_system_only() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone());
        chat.invoke(
            vec![
                Message::system("you are helpful"),
                Message::user("hi"),
            ],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(seen[0].cache, "system should be cached");
        assert!(!seen[1].cache, "user should NOT be cached");
    }

    #[tokio::test]
    async fn without_system_leaves_system_alone() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone()).without_system();
        chat.invoke(
            vec![
                Message::system("you are helpful"),
                Message::user("hi"),
            ],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(!seen[0].cache);
        assert!(!seen[1].cache);
    }

    #[tokio::test]
    async fn cache_last_user_only_if_over_threshold() {
        let spy = SpyModel::new();
        let long_ctx = "x".repeat(5000);
        let chat = PromptCachingChatModel::new(spy.clone())
            .cache_last_user_if_over(4096);
        chat.invoke(
            vec![
                Message::system("sys"),
                Message::user("hi"),              // short — NOT cached
                Message::assistant("hello"),
                Message::user(long_ctx.clone()),  // long — cached
            ],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(seen[0].cache);   // system (default on)
        assert!(!seen[1].cache);  // short user
        assert!(!seen[2].cache);  // assistant not touched
        assert!(seen[3].cache);   // long user
    }

    #[tokio::test]
    async fn short_user_not_cached_even_with_policy() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone())
            .cache_last_user_if_over(4096);
        chat.invoke(
            vec![
                Message::system("sys"),
                Message::user("short"),
            ],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(seen[0].cache);   // system
        assert!(!seen[1].cache);  // user too short
    }

    #[tokio::test]
    async fn extra_indices_marks_specific_messages() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone())
            .without_system()
            .cache_indices(vec![1, 3]);
        chat.invoke(
            vec![
                Message::system("sys"),
                Message::user("first"),
                Message::assistant("a"),
                Message::user("second"),
            ],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(!seen[0].cache);
        assert!(seen[1].cache);
        assert!(!seen[2].cache);
        assert!(seen[3].cache);
    }

    #[tokio::test]
    async fn no_system_message_still_works() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone());
        chat.invoke(
            vec![Message::user("hi")],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(!seen[0].cache);  // no system to cache; nothing crashes
    }

    #[tokio::test]
    async fn out_of_range_indices_ignored() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone())
            .without_system()
            .cache_indices(vec![99, 100]);
        chat.invoke(
            vec![Message::user("hi")],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(!seen[0].cache);
    }

    #[tokio::test]
    async fn caches_first_system_only_when_multiple() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone());
        chat.invoke(
            vec![
                Message::system("first sys"),
                Message::system("second sys"),
                Message::user("hi"),
            ],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(seen[0].cache);
        assert!(!seen[1].cache, "only FIRST system marked");
    }

    #[tokio::test]
    async fn preserves_existing_cache_flag() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy.clone()).without_system();
        let pre_cached = Message::user("big ctx").cached();
        chat.invoke(
            vec![pre_cached],
            &ChatOptions::default(),
        ).await.unwrap();
        let seen = &spy.seen.lock().unwrap()[0];
        assert!(seen[0].cache, "policy never clears existing cache flags");
    }

    #[tokio::test]
    async fn name_delegates_to_inner() {
        let spy = SpyModel::new();
        let chat = PromptCachingChatModel::new(spy);
        assert_eq!(chat.name(), "spy");
    }
}

// =============================================================================
// CostCappedChatModel — hard USD cap per cumulative spend.
// =============================================================================

use litgraph_core::TokenUsage;
use litgraph_observability::cost::{ModelPrice, PriceSheet};
use parking_lot::Mutex as PlMutex;

/// Wrap any `ChatModel` with a hard USD cap on cumulative spend. Once the
/// running total crosses `max_usd`, subsequent `invoke`/`stream` calls fail
/// with `Error::InvalidInput` — before any request reaches the provider.
/// The failing call doesn't burn tokens.
///
/// # Why
///
/// Token budget (iter 130) caps the SIZE of any one call. Rate limit (iter 94)
/// caps the RATE of calls. Neither bounds cumulative $ — an agent stuck in a
/// tool-call loop can burn through a month's budget in minutes. CostCap is
/// the floor-level safety on dollar spend: declare a ceiling, get an error
/// instead of a bill.
///
/// # How the math works
///
/// On each successful invoke, cost is computed from `ChatResponse.usage` +
/// `PriceSheet::lookup(response.model)`:
/// - `prompt_tokens × prompt_per_mtok / 1M`
/// - `completion_tokens × completion_per_mtok / 1M`
/// - `cache_creation_tokens × prompt_per_mtok × 1.25 / 1M`  (Anthropic write)
/// - `cache_read_tokens × prompt_per_mtok × 0.10 / 1M`     (Anthropic read)
///
/// If the model isn't in the price sheet, the call adds 0 to the total — the
/// cap silently doesn't enforce for unpriced models. This is a deliberate
/// fail-open: an unrecognized custom model shouldn't halt the caller's pipeline.
/// The caller can pass a custom `PriceSheet` that includes their model to opt in.
///
/// Streams: cost is tallied from the `ChatStreamEvent::Done` final usage (which
/// the wrapper lets flow through verbatim — no reordering). Error variants on
/// the stream path are NOT charged.
///
/// # Thread safety
///
/// Running total guarded by a `parking_lot::Mutex<f64>`. Two concurrent
/// invokes against the same CostCap might both observe the total below cap
/// and both succeed — there's a small race window between the pre-check and
/// post-update. This is acceptable: over-shoot is bounded by (N_concurrent ×
/// cost_per_call), which for typical cap budgets is a rounding error. Tighter
/// pre-reservation would require estimating cost pre-call (impossible without
/// tokenizing + guessing completion length), which would silently over-reject.
///
/// ```rust,ignore
/// use litgraph_resilience::CostCappedChatModel;
/// use litgraph_observability::cost::default_prices;
/// let guarded = CostCappedChatModel::new(inner, default_prices(), 5.00);  // $5 cap
/// match guarded.invoke(msgs, &opts).await {
///     Ok(r) => { /* normal path */ }
///     Err(e) if e.to_string().contains("cost cap") => { /* over budget */ }
///     Err(e) => { /* other provider error */ }
/// }
/// ```
pub struct CostCappedChatModel {
    pub inner: Arc<dyn ChatModel>,
    prices: PriceSheet,
    max_usd: f64,
    total_usd: Arc<PlMutex<f64>>,
}

impl CostCappedChatModel {
    pub fn new(inner: Arc<dyn ChatModel>, prices: PriceSheet, max_usd: f64) -> Self {
        Self {
            inner,
            prices,
            max_usd: max_usd.max(0.0),
            total_usd: Arc::new(PlMutex::new(0.0)),
        }
    }

    /// Current cumulative spend in USD.
    pub fn total_usd(&self) -> f64 {
        *self.total_usd.lock()
    }

    /// Remaining budget (max_usd − total_usd, clamped at 0).
    pub fn remaining_usd(&self) -> f64 {
        (self.max_usd - self.total_usd()).max(0.0)
    }

    /// Reset the running counter (e.g. at midnight UTC for daily budgets).
    pub fn reset(&self) {
        *self.total_usd.lock() = 0.0;
    }

    /// Calculate the USD cost of a single response given its usage + model.
    /// Public for callers who want to replay the accounting manually.
    pub fn cost_of(&self, usage: &TokenUsage, model: &str) -> f64 {
        let Some(ModelPrice { prompt_per_mtok, completion_per_mtok }) = self.prices.lookup(model)
        else {
            return 0.0;
        };
        let mtok = 1_000_000.0;
        let prompt_cost = usage.prompt as f64 * prompt_per_mtok / mtok;
        let completion_cost = usage.completion as f64 * completion_per_mtok / mtok;
        // Anthropic cache pricing: creation = 1.25× prompt, read = 0.10× prompt.
        let cache_write_cost = usage.cache_creation as f64 * prompt_per_mtok * 1.25 / mtok;
        let cache_read_cost = usage.cache_read as f64 * prompt_per_mtok * 0.10 / mtok;
        prompt_cost + completion_cost + cache_write_cost + cache_read_cost
    }
}

#[async_trait]
impl ChatModel for CostCappedChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        // Pre-check: already over cap? reject before hitting the provider.
        {
            let total = *self.total_usd.lock();
            if total >= self.max_usd {
                return Err(Error::invalid(format!(
                    "CostCappedChatModel: cost cap exceeded (${:.4} used, ${:.4} limit)",
                    total, self.max_usd
                )));
            }
        }
        let resp = self.inner.invoke(messages, opts).await?;
        let cost = self.cost_of(&resp.usage, &resp.model);
        *self.total_usd.lock() += cost;
        tracing::debug!(
            model = %resp.model,
            call_usd = cost,
            total_usd = *self.total_usd.lock(),
            cap_usd = self.max_usd,
            "CostCappedChatModel charged"
        );
        Ok(resp)
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        {
            let total = *self.total_usd.lock();
            if total >= self.max_usd {
                return Err(Error::invalid(format!(
                    "CostCappedChatModel: cost cap exceeded (${:.4} used, ${:.4} limit)",
                    total, self.max_usd
                )));
            }
        }
        // Wrap the inner stream so the terminal Done event updates the total.
        // Don't attempt mid-stream termination if the user crosses the cap
        // during a single long stream — they're already mid-response and the
        // bill is already committed; just let it land and charge.
        let inner_stream = self.inner.stream(messages, opts).await?;
        let total = self.total_usd.clone();
        let prices = self.prices.clone();
        use futures_util::StreamExt;
        let mapped = inner_stream.map(move |event| {
            if let Ok(litgraph_core::model::ChatStreamEvent::Done { response }) = &event {
                if let Some(ModelPrice { prompt_per_mtok, completion_per_mtok }) =
                    prices.lookup(&response.model)
                {
                    let usage = &response.usage;
                    let mtok = 1_000_000.0;
                    let cost = usage.prompt as f64 * prompt_per_mtok / mtok
                        + usage.completion as f64 * completion_per_mtok / mtok
                        + usage.cache_creation as f64 * prompt_per_mtok * 1.25 / mtok
                        + usage.cache_read as f64 * prompt_per_mtok * 0.10 / mtok;
                    *total.lock() += cost;
                }
            }
            event
        });
        Ok(Box::pin(mapped))
    }
}

#[cfg(test)]
mod cost_cap_tests {
    use super::*;
    use async_trait::async_trait;
    use litgraph_core::model::{ChatStream, FinishReason, TokenUsage};
    use litgraph_core::{ChatResponse, Message};
    use litgraph_observability::cost::{ModelPrice, PriceSheet};

    struct FixedCostModel {
        usage: TokenUsage,
        model: String,
    }

    #[async_trait]
    impl ChatModel for FixedCostModel {
        fn name(&self) -> &str { "fixed" }
        async fn invoke(
            &self,
            _messages: Vec<Message>,
            _opts: &ChatOptions,
        ) -> Result<ChatResponse> {
            Ok(ChatResponse {
                message: Message::assistant("ok"),
                finish_reason: FinishReason::Stop,
                usage: self.usage,
                model: self.model.clone(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    fn prices_gpt4o() -> PriceSheet {
        let mut s = PriceSheet::new();
        // gpt-4o: $2.50/Mtok prompt, $10.00/Mtok completion.
        s.set("gpt-4o", ModelPrice { prompt_per_mtok: 2.50, completion_per_mtok: 10.00 });
        s
    }

    #[tokio::test]
    async fn passes_through_under_cap() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 1_000, completion: 500, total: 1_500, cache_creation: 0, cache_read: 0 },
            model: "gpt-4o".into(),
        });
        // $0.0025 + $0.005 = $0.0075 per call
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 1.00);
        chat.invoke(vec![Message::user("hi")], &ChatOptions::default()).await.unwrap();
        let t = chat.total_usd();
        assert!((t - 0.0075).abs() < 1e-9, "expected ~$0.0075, got {t}");
    }

    #[tokio::test]
    async fn rejects_after_cumulative_over_cap() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 100_000, completion: 50_000, total: 150_000, cache_creation: 0, cache_read: 0 },
            model: "gpt-4o".into(),
        });
        // $0.25 + $0.50 = $0.75 per call; cap $1.00 → call 1 ok, call 2 reject.
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 1.00);
        let r1 = chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await;
        assert!(r1.is_ok());
        // At $0.75 < $1.00 so next call is ALLOWED (pre-check only guards >=).
        let r2 = chat.invoke(vec![Message::user("b")], &ChatOptions::default()).await;
        assert!(r2.is_ok(), "second call pre-checks at $0.75 < $1.00");
        // Now at $1.50 > cap. Third call must be rejected.
        let r3 = chat.invoke(vec![Message::user("c")], &ChatOptions::default()).await;
        let err = r3.unwrap_err();
        assert!(err.to_string().contains("cost cap exceeded"),
                "unexpected: {err}");
    }

    #[tokio::test]
    async fn unpriced_model_charges_zero() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 1_000_000, completion: 1_000_000, total: 2_000_000, cache_creation: 0, cache_read: 0 },
            model: "custom-internal-model".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 0.01);
        // Call succeeds — no price for "custom-internal-model" in sheet.
        let r = chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await;
        assert!(r.is_ok());
        assert_eq!(chat.total_usd(), 0.0);
    }

    #[tokio::test]
    async fn cache_creation_charged_at_1_25x_prompt() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 0, completion: 0, total: 0, cache_creation: 1_000_000, cache_read: 0 },
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 10.0);
        chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await.unwrap();
        // 1M cache_creation × $2.50 × 1.25 = $3.125
        assert!((chat.total_usd() - 3.125).abs() < 1e-9);
    }

    #[tokio::test]
    async fn cache_read_charged_at_0_10x_prompt() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 0, completion: 0, total: 0, cache_creation: 0, cache_read: 1_000_000 },
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 10.0);
        chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await.unwrap();
        // 1M cache_read × $2.50 × 0.10 = $0.25
        assert!((chat.total_usd() - 0.25).abs() < 1e-9);
    }

    #[tokio::test]
    async fn remaining_usd_decreases_with_spend() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 100_000, completion: 0, total: 100_000, cache_creation: 0, cache_read: 0 },
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 1.00);
        assert!((chat.remaining_usd() - 1.00).abs() < 1e-9);
        chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await.unwrap();
        // $0.25 spent, $0.75 remaining.
        assert!((chat.remaining_usd() - 0.75).abs() < 1e-9);
    }

    #[tokio::test]
    async fn reset_returns_total_to_zero() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 100_000, completion: 50_000, total: 150_000, cache_creation: 0, cache_read: 0 },
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 10.00);
        chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await.unwrap();
        assert!(chat.total_usd() > 0.0);
        chat.reset();
        assert_eq!(chat.total_usd(), 0.0);
        assert!((chat.remaining_usd() - 10.00).abs() < 1e-9);
    }

    #[tokio::test]
    async fn zero_cap_rejects_all_requests() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage::default(),
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 0.0);
        // total = $0, cap = $0, pre-check `0 >= 0` → reject.
        let r = chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await;
        assert!(r.is_err());
        assert!(r.unwrap_err().to_string().contains("cost cap exceeded"));
    }

    #[tokio::test]
    async fn negative_cap_clamps_to_zero() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage::default(),
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), -5.0);
        // Negative cap is clamped to $0 at construction.
        let r = chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await;
        assert!(r.is_err(), "negative cap treated as $0 — all calls rejected");
    }

    #[tokio::test]
    async fn cost_of_helper_matches_invoke_accounting() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage { prompt: 500_000, completion: 200_000, total: 700_000, cache_creation: 0, cache_read: 0 },
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 10.0);
        let expected = chat.cost_of(
            &TokenUsage { prompt: 500_000, completion: 200_000, total: 700_000, cache_creation: 0, cache_read: 0 },
            "gpt-4o",
        );
        chat.invoke(vec![Message::user("a")], &ChatOptions::default()).await.unwrap();
        assert!((chat.total_usd() - expected).abs() < 1e-9);
    }

    #[tokio::test]
    async fn name_delegates_to_inner() {
        let inner = Arc::new(FixedCostModel {
            usage: TokenUsage::default(),
            model: "gpt-4o".into(),
        });
        let chat = CostCappedChatModel::new(inner, prices_gpt4o(), 1.0);
        assert_eq!(chat.name(), "fixed");
    }
}

// =============================================================================
// SelfConsistencyChatModel — N-sample majority vote (Wang et al 2022).
// =============================================================================

use std::collections::HashMap;

/// Picks the winner from N sampled responses. Return the INDEX of the
/// winning response (caller uses it to select the full ChatResponse). If
/// the voter returns `None` — no majority / all invalid — the wrapper
/// falls back to returning the first sample.
pub type ConsistencyVoter =
    Arc<dyn Fn(&[ChatResponse]) -> Option<usize> + Send + Sync>;

/// Self-consistency wrapper: sample the model `samples` times at elevated
/// temperature, then pick the majority answer via `voter`. Classic
/// Chain-of-Thought reasoning technique from Wang et al 2022 — for math,
/// code, and multi-step reasoning, N=5 at T=0.7 often lifts accuracy
/// 5–20% over greedy decoding. Costs N× tokens per question.
///
/// # How voting works
///
/// Default voter: normalize each response's text (trim + lowercase +
/// collapse whitespace) and pick the most-common. Ties broken by first
/// occurrence. For structured tasks, pass a custom `voter` that extracts
/// the answer field (e.g. last number in the text, or the JSON field)
/// before counting — raw-text majority over a 500-token reasoning chain
/// will never converge, but majority over extracted answers will.
///
/// # Parallelism
///
/// N samples run concurrently via `tokio::JoinSet`. On a typical provider
/// with an async HTTP pool, 5 parallel samples take ~1× the wall-clock of
/// 1 sample (I/O-bound). CPU-bound models or strict rate-limits will
/// serialize; stack with `RateLimitedChatModel` when needed.
///
/// # Streaming
///
/// `stream()` delegates to a single sample (no streaming fan-out — there's
/// no meaningful way to stream N parallel samples and vote). Callers who
/// want vote-then-stream should do it in two phases upstream.
///
/// ```rust,ignore
/// use litgraph_resilience::SelfConsistencyChatModel;
/// let voter_chat = SelfConsistencyChatModel::new(inner, 5).with_temperature(0.7);
/// let resp = voter_chat.invoke(msgs, &opts).await?;
/// // `resp.usage` includes summed tokens across all 5 samples.
/// ```
pub struct SelfConsistencyChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub samples: usize,
    pub sample_temperature: f32,
    voter: ConsistencyVoter,
}

impl SelfConsistencyChatModel {
    /// Default voter (text-majority). `samples` is clamped to at least 1.
    pub fn new(inner: Arc<dyn ChatModel>, samples: usize) -> Self {
        Self {
            inner,
            samples: samples.max(1),
            sample_temperature: 0.7,
            voter: default_text_voter(),
        }
    }

    /// Override the sampling temperature (default 0.7 — per the paper's
    /// sweet spot for reasoning diversity without incoherence).
    pub fn with_temperature(mut self, t: f32) -> Self {
        self.sample_temperature = t;
        self
    }

    /// Custom voter — e.g. extract the last integer from each response
    /// and pick the majority. Receives all N responses, returns the index
    /// of the winner. If `None`, wrapper falls back to the first sample.
    pub fn with_voter(mut self, voter: ConsistencyVoter) -> Self {
        self.voter = voter;
        self
    }
}

/// Default voter: normalize text (trim + lowercase + collapse whitespace)
/// and return the index of the response whose normalized text appears most.
pub fn default_text_voter() -> ConsistencyVoter {
    Arc::new(|responses: &[ChatResponse]| {
        if responses.is_empty() {
            return None;
        }
        let normalized: Vec<String> = responses
            .iter()
            .map(|r| normalize_for_vote(&r.message.text_content()))
            .collect();
        // Count occurrences; keep first-seen tie-breaker.
        let mut counts: HashMap<&str, usize> = HashMap::new();
        for n in &normalized {
            *counts.entry(n.as_str()).or_insert(0) += 1;
        }
        let (best_text, _) = counts.iter().max_by_key(|(_, c)| *c)?;
        // Return index of the FIRST response whose normalized text matches.
        normalized.iter().position(|n| n == *best_text)
    })
}

fn normalize_for_vote(s: &str) -> String {
    s.trim()
        .to_lowercase()
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
}

/// Build a voter that extracts a field per response via `extract` and picks
/// the majority value. `extract` returns `None` for responses where the
/// field is missing — those are excluded from the vote.
pub fn extracted_field_voter<F>(extract: F) -> ConsistencyVoter
where
    F: Fn(&ChatResponse) -> Option<String> + Send + Sync + 'static,
{
    let extract = Arc::new(extract);
    Arc::new(move |responses: &[ChatResponse]| {
        if responses.is_empty() {
            return None;
        }
        let extracted: Vec<Option<String>> =
            responses.iter().map(|r| extract(r)).collect();
        let mut counts: HashMap<&str, usize> = HashMap::new();
        for e in &extracted {
            if let Some(v) = e {
                *counts.entry(v.as_str()).or_insert(0) += 1;
            }
        }
        let (best, _) = counts.iter().max_by_key(|(_, c)| *c)?;
        extracted
            .iter()
            .position(|e| e.as_deref() == Some(*best))
    })
}

#[async_trait]
impl ChatModel for SelfConsistencyChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        // Sample N times in parallel. Override temperature on the cloned
        // opts so the caller's preferred temperature doesn't squash
        // sampling diversity. Keep all other opts (max_tokens, tools, etc).
        let mut sample_opts = opts.clone();
        sample_opts.temperature = Some(self.sample_temperature);

        // Spawn N parallel samples and preserve their spawn order in the
        // result vec (join_all yields results in the SAME order as the
        // input futures — critical for deterministic tie-break below).
        let futures: Vec<_> = (0..self.samples)
            .map(|_| {
                let inner = self.inner.clone();
                let msgs = messages.clone();
                let o = sample_opts.clone();
                async move { inner.invoke(msgs, &o).await }
            })
            .collect();
        let results = futures_util::future::join_all(futures).await;

        let mut samples: Vec<ChatResponse> = Vec::with_capacity(self.samples);
        let mut first_err: Option<Error> = None;
        for res in results {
            match res {
                Ok(r) => samples.push(r),
                Err(e) => {
                    if first_err.is_none() {
                        first_err = Some(e);
                    }
                }
            }
        }
        if samples.is_empty() {
            // All N samples failed — bubble up the first error.
            return Err(first_err.unwrap_or_else(|| {
                Error::other("SelfConsistencyChatModel: all samples failed")
            }));
        }

        // Pick the winner. Voter returning None → fall through to first.
        let winner_idx = (self.voter)(&samples).unwrap_or(0);
        let mut winner = samples
            .get(winner_idx)
            .cloned()
            .unwrap_or_else(|| samples[0].clone());

        // Sum usage across ALL samples so the caller's cost tracker sees
        // the full fan-out cost — critical for CostCapped composition.
        let mut summed = TokenUsage::default();
        for s in &samples {
            summed.prompt += s.usage.prompt;
            summed.completion += s.usage.completion;
            summed.total += s.usage.total;
            summed.cache_creation += s.usage.cache_creation;
            summed.cache_read += s.usage.cache_read;
        }
        winner.usage = summed;
        Ok(winner)
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // No fan-out on streams — delegate to a single sample.
        self.inner.stream(messages, opts).await
    }
}

#[cfg(test)]
mod self_consistency_tests {
    use super::*;
    use async_trait::async_trait;
    use litgraph_core::model::{ChatStream, FinishReason, TokenUsage};
    use litgraph_core::{ChatResponse, Message};
    use std::sync::atomic::{AtomicUsize, Ordering};

    /// Returns a scripted sequence of responses — one per call.
    struct ScriptedModel {
        texts: Vec<&'static str>,
        idx: AtomicUsize,
    }

    impl ScriptedModel {
        fn new(texts: Vec<&'static str>) -> Arc<Self> {
            Arc::new(Self { texts, idx: AtomicUsize::new(0) })
        }
    }

    #[async_trait]
    impl ChatModel for ScriptedModel {
        fn name(&self) -> &str { "scripted" }
        async fn invoke(
            &self,
            _messages: Vec<Message>,
            _opts: &ChatOptions,
        ) -> Result<ChatResponse> {
            let i = self.idx.fetch_add(1, Ordering::SeqCst) % self.texts.len();
            Ok(ChatResponse {
                message: Message::assistant(self.texts[i]),
                finish_reason: FinishReason::Stop,
                usage: TokenUsage { prompt: 10, completion: 5, total: 15, cache_creation: 0, cache_read: 0 },
                model: "scripted".into(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test]
    async fn picks_majority_text() {
        // 3 "42" + 2 "41" → majority "42".
        let inner = ScriptedModel::new(vec!["42", "41", "42", "41", "42"]);
        let chat = SelfConsistencyChatModel::new(inner, 5);
        let resp = chat.invoke(vec![Message::user("2+40")], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "42");
    }

    #[tokio::test]
    async fn summed_usage_across_samples() {
        let inner = ScriptedModel::new(vec!["a", "a", "a"]);
        let chat = SelfConsistencyChatModel::new(inner, 3);
        let resp = chat.invoke(vec![Message::user("x")], &ChatOptions::default()).await.unwrap();
        // Each sample uses 10+5=15. N=3 → 30 prompt + 15 completion = 45 total.
        assert_eq!(resp.usage.prompt, 30);
        assert_eq!(resp.usage.completion, 15);
        assert_eq!(resp.usage.total, 45);
    }

    #[tokio::test]
    async fn sample_temperature_overrides_caller_temp() {
        struct TempCapture {
            seen: std::sync::Mutex<Vec<f32>>,
        }
        #[async_trait]
        impl ChatModel for TempCapture {
            fn name(&self) -> &str { "tc" }
            async fn invoke(&self, _m: Vec<Message>, opts: &ChatOptions) -> Result<ChatResponse> {
                self.seen.lock().unwrap().push(opts.temperature.unwrap_or(0.0));
                Ok(ChatResponse {
                    message: Message::assistant("ok"),
                    finish_reason: FinishReason::Stop,
                    usage: TokenUsage::default(),
                    model: "tc".into(),
                })
            }
            async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> { unimplemented!() }
        }
        let inner = Arc::new(TempCapture { seen: std::sync::Mutex::new(vec![]) });
        let chat = SelfConsistencyChatModel::new(inner.clone(), 3).with_temperature(0.9);
        chat.invoke(
            vec![Message::user("q")],
            &ChatOptions { temperature: Some(0.0), ..Default::default() },
        ).await.unwrap();
        let seen = inner.seen.lock().unwrap();
        assert_eq!(seen.len(), 3);
        for t in seen.iter() {
            assert!((t - 0.9).abs() < 1e-6, "expected 0.9, got {t}");
        }
    }

    #[tokio::test]
    async fn tie_winner_is_one_of_the_tied_majority() {
        // 2-2-1 tie between "a" and "b". Which wins depends on which
        // finishes first in the parallel race — both are valid majority
        // picks. The test asserts the winner is NOT the minority ("c").
        let inner = ScriptedModel::new(vec!["a", "b", "a", "b", "c"]);
        let chat = SelfConsistencyChatModel::new(inner, 5);
        let resp = chat.invoke(vec![Message::user("x")], &ChatOptions::default()).await.unwrap();
        let winner = resp.message.text_content();
        assert!(winner == "a" || winner == "b", "winner was {winner}, expected tied majority");
    }

    #[tokio::test]
    async fn custom_voter_extracts_last_number() {
        // Reasoning chains — raw majority would never converge; but
        // last-number-extract majority picks 42.
        let inner = ScriptedModel::new(vec![
            "Let me think... so the answer is 42.",
            "After calculation, I get 42.",
            "Maybe 17? No, 42.",
            "The solution is 41 oh wait, 42.",
            "I believe it's 42.",
        ]);
        let voter = extracted_field_voter(|r| {
            let text = r.message.text_content();
            text.split_whitespace()
                .filter_map(|w| w.trim_end_matches('.').parse::<i64>().ok())
                .last()
                .map(|n| n.to_string())
        });
        let chat = SelfConsistencyChatModel::new(inner, 5).with_voter(voter);
        let resp = chat.invoke(vec![Message::user("q")], &ChatOptions::default()).await.unwrap();
        // Winner must be one of the responses ending with "42".
        assert!(resp.message.text_content().ends_with("42.") || resp.message.text_content().ends_with("42"));
    }

    #[tokio::test]
    async fn all_samples_fail_returns_first_error() {
        struct AllFail;
        #[async_trait]
        impl ChatModel for AllFail {
            fn name(&self) -> &str { "fail" }
            async fn invoke(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatResponse> {
                Err(Error::provider("upstream dead"))
            }
            async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> { unimplemented!() }
        }
        let chat = SelfConsistencyChatModel::new(Arc::new(AllFail), 3);
        let err = chat.invoke(vec![Message::user("q")], &ChatOptions::default()).await.unwrap_err();
        assert!(err.to_string().contains("upstream dead"));
    }

    #[tokio::test]
    async fn partial_sample_failure_still_votes() {
        // 5 samples, some fail — voter runs on the successful ones.
        struct FlakyScripted {
            texts: Vec<Option<&'static str>>,
            idx: AtomicUsize,
        }
        #[async_trait]
        impl ChatModel for FlakyScripted {
            fn name(&self) -> &str { "flaky" }
            async fn invoke(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatResponse> {
                let i = self.idx.fetch_add(1, Ordering::SeqCst) % self.texts.len();
                match self.texts[i] {
                    Some(t) => Ok(ChatResponse {
                        message: Message::assistant(t),
                        finish_reason: FinishReason::Stop,
                        usage: TokenUsage::default(),
                        model: "flaky".into(),
                    }),
                    None => Err(Error::Timeout),
                }
            }
            async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> { unimplemented!() }
        }
        let inner = Arc::new(FlakyScripted {
            texts: vec![Some("42"), None, Some("42"), None, Some("42")],
            idx: AtomicUsize::new(0),
        });
        let chat = SelfConsistencyChatModel::new(inner, 5);
        let resp = chat.invoke(vec![Message::user("q")], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "42");
    }

    #[tokio::test]
    async fn samples_one_passes_through_as_single_call() {
        let inner = ScriptedModel::new(vec!["one"]);
        let chat = SelfConsistencyChatModel::new(inner, 1);
        let resp = chat.invoke(vec![Message::user("q")], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "one");
        assert_eq!(resp.usage.total, 15);
    }

    #[tokio::test]
    async fn zero_samples_clamps_to_one() {
        let inner = ScriptedModel::new(vec!["only"]);
        let chat = SelfConsistencyChatModel::new(inner, 0);
        assert_eq!(chat.samples, 1);
        let resp = chat.invoke(vec![Message::user("q")], &ChatOptions::default()).await.unwrap();
        assert_eq!(resp.message.text_content(), "only");
    }

    #[tokio::test]
    async fn normalize_for_vote_collapses_whitespace_and_case() {
        assert_eq!(normalize_for_vote("  Hello   World  "), "hello world");
        assert_eq!(normalize_for_vote("Hello  World"), normalize_for_vote("HELLO WORLD"));
    }

    #[tokio::test]
    async fn name_delegates_to_inner() {
        let inner = ScriptedModel::new(vec!["x"]);
        let chat = SelfConsistencyChatModel::new(inner, 3);
        assert_eq!(chat.name(), "scripted");
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CachedChatModel — live LLM-response cache for production cost reduction
// ─────────────────────────────────────────────────────────────────────────────

/// Cache entry for [`CachedChatModel`].
#[derive(Clone)]
struct CachedChatEntry {
    response: ChatResponse,
    inserted_at: std::time::Instant,
}

/// Wrap any [`ChatModel`] with an in-memory response cache keyed
/// by canonical hash of `(messages, ChatOptions)`.
///
/// # Distinct from neighboring primitives
///
/// - **`RecordingChatModel` / `ReplayingChatModel`** (iter 254) are
///   for *test workflows* — record once, replay forever in CI.
///   `CachedChatModel` is for *production* — cache hits skip the
///   provider call to save tokens / latency, with an LRU cap and
///   optional TTL so the cache doesn't grow unbounded.
/// - **`PromptCachingChatModel`** (iter 136) controls Anthropic's
///   *server-side* prompt cache via cache_control headers — that
///   reduces input-token cost on the provider side. This caches
///   the entire response *client-side* — zero provider call on hit.
///   The two compose: even with prompt caching enabled upstream,
///   client-side caching is still a win because identical requests
///   skip the network roundtrip entirely.
/// - **`SingleflightChatModel`** doesn't exist (we have it for
///   tools/embeddings/retrievers). If we add it, it'd coalesce
///   *concurrent* identical calls; this caches *across* calls.
///   The two compose: cache-outside / dedup-inside.
///
/// # When this is a win
///
/// - Eval harnesses that re-run the same dataset against the same
///   model multiple times (parameter sweeps, scorer iteration).
/// - Agents over a fixed FAQ where users phrase the same question
///   identically (verbatim — for fuzzy matches use a semantic
///   layer; this is exact-key only).
/// - Demo / dev environments where the same prompt is replayed
///   while iterating on downstream UI / parsing logic.
/// - Multi-stage agent loops where the same upstream call gets
///   re-invoked due to retry / control-flow restart — cache short-
///   circuits the redundant work.
///
/// # When this is NOT a win
///
/// - Stochastic-output workflows (high temperature, creative
///   generation) — cache-hit rate is near zero because each call
///   has slightly different opts metadata or message wording.
/// - Long-tail prompts where each user query is unique. The cache
///   just adds memory pressure without earning hits.
///
/// # Streaming
///
/// `stream()` is NOT cached — token streams can't be replayed in
/// a useful way without preserving inter-chunk timing, and the
/// caller of `stream()` typically wants the streaming UX (otherwise
/// they'd call `invoke()`). Stream calls pass through to inner.
/// Tests verifying cache behavior should use `invoke()`.
///
/// # Hash determinism
///
/// Cache key uses [`exchange_hash`], the same blake3-over-canonical-
/// JSON function as the cassette infrastructure. Reusing it ensures
/// the cache and the cassette agree on what counts as "the same
/// request" — same hash function, same canonicalization rules.
pub struct CachedChatModel {
    pub inner: Arc<dyn ChatModel>,
    pub max_entries: usize,
    pub ttl: Option<Duration>,
    cache: parking_lot::Mutex<Vec<(String, CachedChatEntry)>>,
}

impl CachedChatModel {
    pub fn new(inner: Arc<dyn ChatModel>) -> Self {
        Self {
            inner,
            max_entries: 1000,
            ttl: None,
            cache: parking_lot::Mutex::new(Vec::new()),
        }
    }

    pub fn with_max_entries(mut self, n: usize) -> Self {
        self.max_entries = n.max(1);
        self
    }

    pub fn with_ttl(mut self, ttl: Duration) -> Self {
        self.ttl = Some(ttl);
        self
    }

    /// Approximate cache size — for telemetry / tests.
    pub fn cache_len(&self) -> usize {
        self.cache.lock().len()
    }

    /// Drop all cached entries.
    pub fn clear(&self) {
        self.cache.lock().clear();
    }
}

#[async_trait]
impl ChatModel for CachedChatModel {
    fn name(&self) -> &str {
        self.inner.name()
    }

    async fn invoke(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatResponse> {
        let key = exchange_hash(&messages, opts);
        let now = std::time::Instant::now();
        // Lookup phase. Sweep TTL-expired entries while holding lock.
        {
            let mut cache = self.cache.lock();
            if let Some(ttl) = self.ttl {
                cache.retain(|(_, e)| now.duration_since(e.inserted_at) <= ttl);
            }
            if let Some((_, entry)) = cache.iter().find(|(k, _)| k == &key) {
                debug!(target: "litgraph_resilience::cached_chat", "cache hit");
                return Ok(entry.response.clone());
            }
        }
        // Miss — call inner.
        let response = self.inner.invoke(messages, opts).await?;
        // Insert + evict.
        {
            let mut cache = self.cache.lock();
            cache.push((
                key,
                CachedChatEntry {
                    response: response.clone(),
                    inserted_at: now,
                },
            ));
            while cache.len() > self.max_entries {
                cache.remove(0);
            }
        }
        Ok(response)
    }

    async fn stream(
        &self,
        messages: Vec<Message>,
        opts: &ChatOptions,
    ) -> Result<ChatStream> {
        // See module doc — streams pass through uncached.
        self.inner.stream(messages, opts).await
    }
}

#[cfg(test)]
mod cached_chat_tests {
    use super::*;
    use async_trait::async_trait;
    use litgraph_core::model::{ChatStream, FinishReason, TokenUsage};
    use litgraph_core::{ChatResponse, Message};
    use std::sync::atomic::{AtomicUsize, Ordering};

    /// Records call count + returns "resp-N" where N is the call index.
    struct CountingModel {
        calls: AtomicUsize,
    }

    impl CountingModel {
        fn new() -> Arc<Self> {
            Arc::new(Self {
                calls: AtomicUsize::new(0),
            })
        }
        fn calls(&self) -> usize {
            self.calls.load(Ordering::SeqCst)
        }
    }

    #[async_trait]
    impl ChatModel for CountingModel {
        fn name(&self) -> &str {
            "counting"
        }
        async fn invoke(
            &self,
            _messages: Vec<Message>,
            _opts: &ChatOptions,
        ) -> Result<ChatResponse> {
            let n = self.calls.fetch_add(1, Ordering::SeqCst);
            Ok(ChatResponse {
                message: Message::assistant(format!("resp-{n}")),
                finish_reason: FinishReason::Stop,
                usage: TokenUsage {
                    prompt: 10,
                    completion: 5,
                    total: 15,
                    cache_creation: 0,
                    cache_read: 0,
                },
                model: "counting".into(),
            })
        }
        async fn stream(&self, _m: Vec<Message>, _o: &ChatOptions) -> Result<ChatStream> {
            unimplemented!()
        }
    }

    #[tokio::test]
    async fn identical_calls_hit_cache() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner.clone());
        let opts = ChatOptions::default();
        let msgs = vec![Message::user("hello")];

        let r1 = cached.invoke(msgs.clone(), &opts).await.unwrap();
        let r2 = cached.invoke(msgs.clone(), &opts).await.unwrap();
        let r3 = cached.invoke(msgs, &opts).await.unwrap();

        // Inner saw exactly one call; subsequent two were cache hits.
        assert_eq!(inner.calls(), 1);
        // All three responses are byte-identical (the cached value).
        assert_eq!(r1.message.text_content(), "resp-0");
        assert_eq!(r2.message.text_content(), "resp-0");
        assert_eq!(r3.message.text_content(), "resp-0");
        assert_eq!(cached.cache_len(), 1);
    }

    #[tokio::test]
    async fn different_messages_miss_cache() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner.clone());
        let opts = ChatOptions::default();

        cached
            .invoke(vec![Message::user("a")], &opts)
            .await
            .unwrap();
        cached
            .invoke(vec![Message::user("b")], &opts)
            .await
            .unwrap();
        cached
            .invoke(vec![Message::user("c")], &opts)
            .await
            .unwrap();

        assert_eq!(inner.calls(), 3);
        assert_eq!(cached.cache_len(), 3);
    }

    #[tokio::test]
    async fn different_opts_miss_cache() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner.clone());
        let msgs = vec![Message::user("same")];

        let mut o1 = ChatOptions::default();
        o1.temperature = Some(0.0);
        let mut o2 = ChatOptions::default();
        o2.temperature = Some(0.7);

        cached.invoke(msgs.clone(), &o1).await.unwrap();
        cached.invoke(msgs.clone(), &o2).await.unwrap();
        // Same opts as o1 — cache hit.
        cached.invoke(msgs, &o1).await.unwrap();

        // Two distinct opt fingerprints → two inner calls; the third was a hit.
        assert_eq!(inner.calls(), 2);
    }

    #[tokio::test]
    async fn lru_eviction_caps_size() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner.clone()).with_max_entries(2);
        let opts = ChatOptions::default();

        cached
            .invoke(vec![Message::user("a")], &opts)
            .await
            .unwrap();
        cached
            .invoke(vec![Message::user("b")], &opts)
            .await
            .unwrap();
        cached
            .invoke(vec![Message::user("c")], &opts)
            .await
            .unwrap();

        // Only the two most-recent entries remain; "a" was evicted.
        assert_eq!(cached.cache_len(), 2);
        // Now re-invoking "a" misses (it was evicted) → 4th inner call.
        cached
            .invoke(vec![Message::user("a")], &opts)
            .await
            .unwrap();
        assert_eq!(inner.calls(), 4);
    }

    #[tokio::test]
    async fn ttl_expires_entries() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner.clone()).with_ttl(Duration::from_millis(50));
        let opts = ChatOptions::default();
        let msgs = vec![Message::user("ephemeral")];

        cached.invoke(msgs.clone(), &opts).await.unwrap();
        // Within TTL — cache hit.
        cached.invoke(msgs.clone(), &opts).await.unwrap();
        assert_eq!(inner.calls(), 1);

        tokio::time::sleep(Duration::from_millis(80)).await;
        // After TTL — entry expired, re-invokes inner.
        cached.invoke(msgs, &opts).await.unwrap();
        assert_eq!(inner.calls(), 2);
    }

    #[tokio::test]
    async fn clear_drops_all_entries() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner.clone());
        let opts = ChatOptions::default();

        cached
            .invoke(vec![Message::user("x")], &opts)
            .await
            .unwrap();
        cached
            .invoke(vec![Message::user("y")], &opts)
            .await
            .unwrap();
        assert_eq!(cached.cache_len(), 2);

        cached.clear();
        assert_eq!(cached.cache_len(), 0);

        // Post-clear: previously-cached call is now a miss.
        cached
            .invoke(vec![Message::user("x")], &opts)
            .await
            .unwrap();
        assert_eq!(inner.calls(), 3);
    }

    #[tokio::test]
    async fn name_delegates_to_inner() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner);
        assert_eq!(cached.name(), "counting");
    }

    #[tokio::test]
    async fn with_max_entries_zero_clamps_to_one() {
        let inner = CountingModel::new();
        let cached = CachedChatModel::new(inner).with_max_entries(0);
        assert_eq!(cached.max_entries, 1);
    }
}
