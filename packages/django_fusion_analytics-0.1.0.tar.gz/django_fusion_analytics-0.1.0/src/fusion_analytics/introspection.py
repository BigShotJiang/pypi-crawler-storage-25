from django.db import models

FIELD_TYPE_MAP = {
    models.AutoField: "integer",
    models.BigAutoField: "integer",
    models.SmallAutoField: "integer",
    models.IntegerField: "integer",
    models.SmallIntegerField: "integer",
    models.BigIntegerField: "integer",
    models.PositiveIntegerField: "integer",
    models.PositiveSmallIntegerField: "integer",
    models.PositiveBigIntegerField: "integer",
    models.FloatField: "float",
    models.DecimalField: "decimal",
    models.CharField: "string",
    models.TextField: "string",
    models.SlugField: "string",
    models.EmailField: "string",
    models.URLField: "string",
    models.UUIDField: "string",
    models.BooleanField: "boolean",
    models.NullBooleanField: "boolean",
    models.DateField: "date",
    models.DateTimeField: "datetime",
    models.TimeField: "time",
    models.DurationField: "duration",
    models.FileField: "string",
    models.FilePathField: "string",
    models.IPAddressField: "string",
    models.GenericIPAddressField: "string",
    models.JSONField: "json",
    models.BinaryField: "binary",
}

NUMERIC_TYPES = {"integer", "float", "decimal"}
TEMPORAL_TYPES = {"date", "datetime", "time"}

OPERATORS_BY_TYPE = {
    "string": ["exact", "iexact", "icontains", "istartswith", "iendswith"],
    "integer": ["exact", "gt", "gte", "lt", "lte", "range"],
    "float": ["exact", "gt", "gte", "lt", "lte", "range"],
    "decimal": ["exact", "gt", "gte", "lt", "lte", "range"],
    "boolean": ["exact"],
    "date": ["exact", "gt", "gte", "lt", "lte", "range"],
    "datetime": ["exact", "gt", "gte", "lt", "lte", "range"],
    "time": ["exact", "gt", "gte", "lt", "lte"],
    "duration": ["exact", "gt", "gte", "lt", "lte"],
    "json": [],
    "binary": [],
}

WIDGET_BY_TYPE = {
    "string": "text",
    "integer": "number",
    "float": "number",
    "decimal": "number",
    "boolean": "boolean",
    "date": "date",
    "datetime": "datetime",
    "time": "time",
    "duration": "text",
    "json": "text",
    "binary": "text",
}


def _get_field_type(field):
    for cls in type(field).__mro__:
        if cls in FIELD_TYPE_MAP:
            return FIELD_TYPE_MAP[cls]
    return "string"


def _get_widget(field, field_type):
    if field.choices:
        return "select"
    return WIDGET_BY_TYPE.get(field_type, "text")


def _get_aggregations(field_type):
    if field_type in NUMERIC_TYPES:
        return ["sum", "avg", "count", "min", "max"]
    if field_type in TEMPORAL_TYPES:
        return ["count", "min", "max"]
    return ["count"]


def _get_choices(field):
    if not field.choices:
        return None
    return [{"value": str(k), "label": str(v)} for k, v in field.choices]


def _build_field_info(field, prefix=""):
    name = f"{prefix}{field.name}" if prefix else field.name
    field_type = _get_field_type(field)
    info = {
        "name": name,
        "verbose_name": str(field.verbose_name),
        "type": field_type,
        "operators": OPERATORS_BY_TYPE.get(field_type, []),
        "aggregations": _get_aggregations(field_type),
        "widget": _get_widget(field, field_type),
    }
    choices = _get_choices(field)
    if choices:
        info["choices"] = choices
    return info


def _discover_fields(model, prefix="", depth=0, max_depth=2):
    fields = []
    for field in model._meta.get_fields():
        if field.is_relation:
            # Only traverse ForeignKey and OneToOneField (concrete forward relations)
            if (
                depth < max_depth
                and field.concrete
                and hasattr(field, "related_model")
                and field.related_model
            ):
                related_prefix = f"{prefix}{field.name}__"
                fields.extend(
                    _discover_fields(
                        field.related_model, related_prefix, depth + 1, max_depth
                    )
                )
        elif field.concrete:
            fields.append(_build_field_info(field, prefix))
    return fields


def get_schema(config):
    model = config.model
    max_depth = getattr(config, "max_depth", 2)

    if config.fields:
        field_infos = []
        for field_path in config.fields:
            field = _resolve_field(model, field_path)
            field_infos.append(_build_field_info_from_path(model, field_path, field))
        fields = field_infos
    else:
        fields = _discover_fields(model, max_depth=max_depth)

    return {
        "label": model._meta.label_lower,
        "verbose_name": str(model._meta.verbose_name),
        "verbose_name_plural": str(model._meta.verbose_name_plural),
        "fields": fields,
    }


def _resolve_field(model, field_path):
    parts = field_path.split("__")
    current_model = model
    for part in parts[:-1]:
        field = current_model._meta.get_field(part)
        current_model = field.related_model
    return current_model._meta.get_field(parts[-1])


def _build_field_info_from_path(model, field_path, field):
    field_type = _get_field_type(field)
    info = {
        "name": field_path,
        "verbose_name": str(field.verbose_name),
        "type": field_type,
        "operators": OPERATORS_BY_TYPE.get(field_type, []),
        "aggregations": _get_aggregations(field_type),
        "widget": _get_widget(field, field_type),
    }
    choices = _get_choices(field)
    if choices:
        info["choices"] = choices
    return info
