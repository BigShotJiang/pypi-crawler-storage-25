from django.db.models import Avg, Count, Max, Min, Sum

from fusion_analytics.introspection import get_schema

AGG_FUNCTIONS = {
    "sum": Sum,
    "avg": Avg,
    "count": Count,
    "min": Min,
    "max": Max,
}


def validate_query(query, site):
    errors = []

    model_label = query.get("model", "")
    try:
        config = site.get_config(model_label)
    except KeyError:
        return [f"Model '{model_label}' is not registered"]

    schema = get_schema(config)
    valid_fields = {f["name"]: f for f in schema["fields"]}

    for field_name in query.get("fields", []):
        if field_name not in valid_fields:
            errors.append(f"Field '{field_name}' is not available on {model_label}")

    for f in query.get("filters", []):
        field_name = f.get("field", "")
        operator = f.get("operator", "")
        if field_name not in valid_fields:
            errors.append(
                f"Filter field '{field_name}' is not available on {model_label}"
            )
        elif operator not in valid_fields[field_name]["operators"]:
            errors.append(
                f"Operator '{operator}' is not valid for field '{field_name}'"
            )

    for agg in query.get("aggregations", []):
        field_name = agg.get("field", "")
        func = agg.get("function", "")
        if field_name not in valid_fields:
            errors.append(
                f"Aggregation field '{field_name}' is not available on {model_label}"
            )
        elif func not in valid_fields[field_name]["aggregations"]:
            errors.append(
                f"Aggregation function '{func}' is not valid for field '{field_name}'"
            )

    for field_name in query.get("group_by", []):
        if field_name not in valid_fields:
            errors.append(
                f"Group by field '{field_name}' is not available on {model_label}"
            )

    return errors


def execute_query(query, site):
    config = site.get_config(query["model"])
    qs = config.model.objects.all()

    for f in query.get("filters", []):
        lookup = f"{f['field']}__{f['operator']}"
        qs = qs.filter(**{lookup: f["value"]})

    group_by = query.get("group_by", [])
    aggregations = query.get("aggregations", [])
    fields = query.get("fields", [])

    if group_by or aggregations:
        if group_by:
            qs = qs.values(*group_by)
        elif not fields:
            qs = qs.values()

        annotations = {}
        for agg in aggregations:
            agg_func = AGG_FUNCTIONS[agg["function"]]
            key = f"{agg['field']}__{agg['function']}"
            annotations[key] = agg_func(agg["field"])

        if annotations:
            qs = qs.annotate(**annotations)

        if not group_by and not fields:
            qs = qs.aggregate(**annotations)
            return [qs]
    elif fields:
        qs = qs.values(*fields)

    for order_field in query.get("order_by", []):
        qs = qs.order_by(order_field)

    limit = query.get("limit")
    if limit:
        qs = qs[:limit]

    return list(qs)
