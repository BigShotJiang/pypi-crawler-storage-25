function queryBuilder() {
    return {
        selectedModel: '',
        schema: null,
        selectedFields: [],
        filters: [],
        aggregations: [],
        groupBy: [],
        orderBy: '',
        limit: null,
        saveDialog: false,
        saveName: '',
        chartType: 'bar',
        chartXField: '',
        chartYField: '',

        async loadSchema() {
            if (!this.selectedModel) {
                this.schema = null;
                return;
            }
            this.selectedFields = [];
            this.filters = [];
            this.aggregations = [];
            this.groupBy = [];
            this.orderBy = '';

            const resp = await fetch(this.url('schema/'), {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'X-CSRFToken': this.csrf()},
                body: JSON.stringify({model: this.selectedModel})
            });
            if (resp.ok) {
                this.schema = await resp.json();
            }
        },

        getOperators(fieldName) {
            if (!this.schema || !fieldName) return [];
            const field = this.schema.fields.find(f => f.name === fieldName);
            return field ? field.operators : [];
        },

        getAggregations(fieldName) {
            if (!this.schema || !fieldName) return [];
            const field = this.schema.fields.find(f => f.name === fieldName);
            return field ? field.aggregations : [];
        },

        allResultFields() {
            const fields = [...this.selectedFields, ...this.groupBy];
            for (const agg of this.aggregations) {
                if (agg.field && agg.function) {
                    fields.push(agg.field + '__' + agg.function);
                }
            }
            return fields;
        },

        buildQuery() {
            const query = {
                model: this.selectedModel,
                fields: this.selectedFields,
            };
            const activeFilters = this.filters.filter(f => f.field && f.operator && f.value);
            if (activeFilters.length) query.filters = activeFilters;
            const activeAggs = this.aggregations.filter(a => a.field && a.function);
            if (activeAggs.length) query.aggregations = activeAggs;
            if (this.groupBy.length) query.group_by = this.groupBy;
            if (this.orderBy) query.order_by = [this.orderBy];
            if (this.limit) query.limit = parseInt(this.limit);
            return query;
        },

        async runQuery() {
            const query = this.buildQuery();
            const resp = await fetch(this.url('execute/'), {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'X-CSRFToken': this.csrf()},
                body: JSON.stringify(query)
            });
            const html = await resp.text();
            document.getElementById('results-container').innerHTML = html;
            document.getElementById('chart-container').innerHTML = '';
        },

        async showChart() {
            const query = this.buildQuery();
            const resultFields = this.allResultFields();
            const payload = {
                query: query,
                chart: {
                    type: this.chartType || 'bar',
                    x_field: this.chartXField || resultFields[0] || '',
                    y_field: this.chartYField || resultFields[resultFields.length - 1] || '',
                }
            };
            const resp = await fetch(this.url('chart/'), {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'X-CSRFToken': this.csrf()},
                body: JSON.stringify(payload)
            });
            const html = await resp.text();
            document.getElementById('chart-container').innerHTML = html;
            // re-evaluate scripts in the inserted HTML
            const scripts = document.getElementById('chart-container').querySelectorAll('script');
            scripts.forEach(s => {
                const ns = document.createElement('script');
                ns.textContent = s.textContent;
                s.parentNode.replaceChild(ns, s);
            });
        },

        async doSave() {
            const payload = {
                name: this.saveName,
                query_config: this.buildQuery(),
                chart_config: {
                    type: this.chartType,
                    x_field: this.chartXField,
                    y_field: this.chartYField,
                }
            };
            const resp = await fetch(this.url('queries/save/'), {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'X-CSRFToken': this.csrf()},
                body: JSON.stringify(payload)
            });
            if (resp.ok) {
                this.saveDialog = false;
                this.saveName = '';
            }
        },

        url(path) {
            const base = document.querySelector('[data-analytics-base]');
            const prefix = base ? base.dataset.analyticsBase : '/analytics/';
            return prefix + path;
        },

        csrf() {
            const cookie = document.cookie.split(';').find(c => c.trim().startsWith('csrftoken='));
            return cookie ? cookie.split('=')[1] : '';
        }
    };
}
