class ModelAnalytics:
    model = None
    fields = None
    max_depth = 2


class AnalyticsSite:
    def __init__(self):
        self._registry = {}

    def register(self, analytics_cls):
        if not getattr(analytics_cls, "model", None):
            raise ValueError(f"{analytics_cls.__name__} must define a model attribute")

        label = analytics_cls.model._meta.label_lower
        if label in self._registry:
            raise ValueError(f"{label} is already registered")

        self._registry[label] = analytics_cls()
        return analytics_cls

    def get_config(self, label):
        return self._registry[label]

    def get_models(self):
        return [
            {
                "label": label,
                "verbose_name": config.model._meta.verbose_name,
                "verbose_name_plural": config.model._meta.verbose_name_plural,
            }
            for label, config in self._registry.items()
        ]


site = AnalyticsSite()
