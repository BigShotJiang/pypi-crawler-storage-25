from django.urls import path

from fusion_analytics import views

app_name = "fusion_analytics"

urlpatterns = [
    path("", views.query_builder, name="query_builder"),
    path("schema/", views.schema_view, name="schema"),
    path("execute/", views.execute_view, name="execute"),
    path("chart/", views.chart_view, name="chart"),
    path("queries/", views.list_queries, name="list_queries"),
    path("queries/save/", views.save_query, name="save_query"),
    path("queries/<uuid:query_id>/", views.load_query, name="load_query"),
]
