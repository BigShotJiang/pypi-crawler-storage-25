from django.apps import AppConfig
from django.utils.module_loading import autodiscover_modules


class FusionAnalyticsConfig(AppConfig):
    name = "fusion_analytics"
    verbose_name = "Fusion Analytics"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self):
        autodiscover_modules("analytics")
