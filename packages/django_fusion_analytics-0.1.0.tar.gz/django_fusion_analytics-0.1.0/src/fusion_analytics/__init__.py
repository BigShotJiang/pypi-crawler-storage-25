default_app_config = "fusion_analytics.apps.FusionAnalyticsConfig"
