import json

from django.http import JsonResponse
from django.template.response import TemplateResponse

from fusion_analytics.introspection import get_schema
from fusion_analytics.models import SavedQuery
from fusion_analytics.query_engine import execute_query, validate_query
from fusion_analytics.registry import site as default_site


def query_builder(request, site=None):
    site = site or default_site
    models = site.get_models()
    return TemplateResponse(
        request,
        "fusion_analytics/query_builder.html",
        {"models": models},
    )


def schema_view(request, site=None):
    site = site or default_site
    data = json.loads(request.body)
    model_label = data.get("model", "")
    try:
        config = site.get_config(model_label)
    except KeyError:
        return JsonResponse(
            {"error": f"Model '{model_label}' not registered"}, status=400
        )

    schema = get_schema(config)
    return JsonResponse(schema)


def execute_view(request, site=None):
    site = site or default_site
    query = json.loads(request.body)

    errors = validate_query(query, site)
    if errors:
        return JsonResponse({"errors": errors}, status=400)

    results = execute_query(query, site)
    columns = query.get("fields", []) + query.get("group_by", [])
    for agg in query.get("aggregations", []):
        columns.append(f"{agg['field']}__{agg['function']}")

    return TemplateResponse(
        request,
        "fusion_analytics/partials/results_table.html",
        {"columns": columns, "results": results},
    )


def chart_view(request, site=None):
    site = site or default_site
    data = json.loads(request.body)
    query = data["query"]
    chart_config = data["chart"]

    errors = validate_query(query, site)
    if errors:
        return JsonResponse({"errors": errors}, status=400)

    results = execute_query(query, site)

    x_field = chart_config.get("x_field", "")
    y_field = chart_config.get("y_field", "")
    chart_type = chart_config.get("type", "bar")

    x_data = [str(r.get(x_field, "")) for r in results]
    y_data = [float(r.get(y_field, 0)) for r in results]

    echart_option = {
        "xAxis": {"type": "category", "data": x_data},
        "yAxis": {"type": "value"},
        "series": [{"type": chart_type, "data": y_data}],
        "tooltip": {"trigger": "axis"},
    }

    return TemplateResponse(
        request,
        "fusion_analytics/partials/chart.html",
        {"echart_option": json.dumps(echart_option), "chart_config": chart_config},
    )


def save_query(request):
    data = json.loads(request.body)
    sq = SavedQuery.objects.create(
        name=data["name"],
        description=data.get("description", ""),
        query_config=data["query_config"],
        chart_config=data.get("chart_config"),
        created_by=request.user,
    )
    return JsonResponse(
        {"id": str(sq.pk), "name": sq.name},
        status=201,
    )


def list_queries(request):
    queries = SavedQuery.objects.filter(created_by=request.user)
    return TemplateResponse(
        request,
        "fusion_analytics/saved_queries.html",
        {"queries": queries},
    )


def load_query(request, query_id):
    sq = SavedQuery.objects.get(pk=query_id, created_by=request.user)
    return JsonResponse(
        {
            "id": str(sq.pk),
            "name": sq.name,
            "description": sq.description,
            "query_config": sq.query_config,
            "chart_config": sq.chart_config,
        }
    )
