# Changelog

<!--next-version-placeholder-->

## v0.7.0 (2026-04-22)

### Feature

* Implement ggogle cpp benchmarks ([`d26f902`](https://github.com/louischereau/Hadronis/commit/d26f90282680afeea5ea4f060f67b374e39f320d))
* Add unit tests ([`cd9d66e`](https://github.com/louischereau/Hadronis/commit/cd9d66ea1742f3692acba4586c5f57fdbe9505d9))
* Add tests ([`e9285ad`](https://github.com/louischereau/Hadronis/commit/e9285ad1da58bd79938edf07f562a445beab9e46))
* Test with 1 thread ([`a382159`](https://github.com/louischereau/Hadronis/commit/a382159b43a906c7845884fe5d0616d983cb12f6))
* Enhance PaiNNMessage structure and optimize forward method for performance ([`273f98d`](https://github.com/louischereau/Hadronis/commit/273f98ddfe596e83d61dc45f0efa55966b3d006f))
* Refactor Engine and PaINN classes for improved predict method and add test fixtures ([`d72f6ce`](https://github.com/louischereau/Hadronis/commit/d72f6ceca6dbb2b733c525e9f5d38cc40854d8de))
* Add safetensors implementation and update test suite for PaiNN ([`b593031`](https://github.com/louischereau/Hadronis/commit/b593031d99301d6b4806f24553fbfcb24549cb12))
* Refactor PaiNN classes and update message handling in tests ([`96ed317`](https://github.com/louischereau/Hadronis/commit/96ed31786f5c14936a06dbc9b968702365232449))
* Implement painn model ([`e1fbd6a`](https://github.com/louischereau/Hadronis/commit/e1fbd6a88cc0446ff8a6251a7ee0817bfadb9453))

### Fix

* Exclude benchmarks from C++ static analysis in clang-tidy step ([`9d8ddc1`](https://github.com/louischereau/Hadronis/commit/9d8ddc19f307fc958bfa9ab5fff762b78883b6e3))
* Tests ([`ba6c2d6`](https://github.com/louischereau/Hadronis/commit/ba6c2d65db7866019744a4d3f60a7a6ab6cca837))
