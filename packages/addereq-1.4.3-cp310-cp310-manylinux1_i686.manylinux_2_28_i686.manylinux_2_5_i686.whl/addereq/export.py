import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import json
try:
    from .logger_config import fetching_logger as logger
except ImportError:
    import logging
    logger = logging.getLogger("export")

def to_qzad(df, metadata=None):
    """
    将带有元数据的 Pandas DataFrame 转换为 QZAD (Qianzhao Arrow Data) 格式。
    
    Args:
        df (pd.DataFrame): 包含监测数据的 DataFrame。
        metadata (dict, optional): 附加的元数据字典。
        
    Returns:
        pa.Table: 包含数据和元数据的 Arrow Table (QZAD 格式)。
    """
    try:
        table = pa.Table.from_pandas(df)
        
        # 基础 QZAD 元数据
        qzad_base_meta = {
            'format_name': 'QZAD',
            'format_version': '1.0.0'
        }
        # 处理传入的元数据
        if metadata:
            # 将字典中的所有项转换为 JSON 字符串并进行编码
            decoded_metadata = {k: json.dumps(v).encode('utf-8') for k, v in metadata.items()}
            qzad_base_meta.update(decoded_metadata)
        else:
            # 如果没有额外元数据，也要编码基础信息
            qzad_base_meta = {k: v.encode('utf-8') if isinstance(v, str) else json.dumps(v).encode('utf-8') 
                             for k, v in qzad_base_meta.items()}
            
        # 现有的 schema 元数据（包含 pandas 的索引信息等）
        existing_metadata = table.schema.metadata or {}
        
        # 合并元数据
        merged_metadata = {**existing_metadata, **qzad_base_meta}
        
        # 创建带有新元数据的 Table
        table = table.replace_schema_metadata(merged_metadata)
            
        return table
    except Exception as e:
        logger.error(f"转换 Arrow Table 失败: {str(e)}")
        raise

def export_qzad(df, file_path, metadata=None):
    """
    将数据导出为 QZAD 格式 (基于 Parquet 存储)。
    
    Args:
        df (pd.DataFrame): 数据。
        file_path (str): 保存路径。
        metadata (dict, optional): 元数据。
    """
    table = to_qzad(df, metadata)
    pq.write_table(table, file_path)
    logger.info(f"数据已导出至 {file_path} (QZAD 格式)")

def export_to_feather(df, file_path, metadata=None):
    """
    将数据导出为 Feather 格式，包含元数据。
    """
    table = to_qzad(df, metadata)
    # 对于 Feather 格式，我们可以直接写入
    import pyarrow.feather as feather
    feather.write_feather(table, file_path)
    logger.info(f"数据已导出至 {file_path}")
