from __future__ import annotations

import os

from celery import Celery
from endoreg_db.utils.paths import DJANGO_SETTINGS_MODULE

os.environ.setdefault("DJANGO_SETTINGS_MODULE", DJANGO_SETTINGS_MODULE)

app = Celery("endoreg_db")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()
