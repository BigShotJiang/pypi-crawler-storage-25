"""`SendblueChannel` -- webhook-style iMessage channel for Zeno.

Owns the HTTP inbound plumbing (Starlette router + uvicorn server), the
outbound REST client, and the bounded queue that bridges push-style webhook
events into Zeno's pull-style `receive()` iterator. Outbound routing uses
`OutgoingMessage.reply_to_thread_key`, which the turn worker's StreamBuffer
populates automatically from the inbound `IncomingMessage.thread_key`.

Lifecycle:
  * `start()` builds the httpx client + SendblueClient, wires the router,
    and runs uvicorn in a background task. Binding to port 0 is supported
    for tests via the `bound_port` property.
  * `stop()` asks uvicorn to exit, awaits the serve task, closes the httpx
    client, and drains any still-running fire-and-forget typing tasks.
  * Both are idempotent.

Testing seams:
  * `_transport` -- optional `httpx.MockTransport` injected into the
    `AsyncClient` so tests can observe outbound requests without a
    network.
  * `_base_url` -- override Sendblue's base URL (also exercised by tests).
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass, field

import httpx
import uvicorn
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities
from zeno.channels.sendblue.client import SendblueClient, SendblueError
from zeno.channels.sendblue.router import build_router

_log = logging.getLogger("zeno.channels.sendblue")

_DEFAULT_BASE_URL = "https://api.sendblue.com"
_QUEUE_MAX = 64


class ChannelError(RuntimeError):
    """Raised on Sendblue channel lifecycle or transport errors."""


@dataclass
class SendblueChannel:
    """Sendblue/iMessage channel. Implements `zeno.channels.protocol.Channel`."""

    api_key_id: str
    api_secret: str
    from_number: str
    signing_secret: str
    allowed_numbers: tuple[str, ...]
    host: str = "127.0.0.1"
    port: int = 8080
    webhook_path: str = "/webhook"
    name: str = "sendblue"

    _transport: httpx.MockTransport | None = None
    _base_url: str = _DEFAULT_BASE_URL

    _capabilities: Capabilities = field(
        default_factory=lambda: Capabilities(
            supports_images=True,
            supports_typing=True,
            supports_streaming=False,
            supports_threading=False,
        ),
        init=False,
        repr=False,
    )

    _queue: asyncio.Queue[IncomingMessage] = field(init=False, repr=False)
    _http: httpx.AsyncClient | None = field(default=None, init=False, repr=False)
    _client: SendblueClient | None = field(default=None, init=False, repr=False)
    _server: uvicorn.Server | None = field(default=None, init=False, repr=False)
    _serve_task: asyncio.Task[None] | None = field(default=None, init=False, repr=False)
    _started: bool = field(default=False, init=False, repr=False)
    _stopped: bool = field(default=False, init=False, repr=False)

    def __post_init__(self) -> None:
        self._queue = asyncio.Queue(maxsize=_QUEUE_MAX)

    @property
    def capabilities(self) -> Capabilities:
        return self._capabilities

    @property
    def bound_port(self) -> int:
        """Actual port uvicorn bound to (useful when `port=0`)."""
        if self._server is None or not self._server.servers:
            raise ChannelError("SendblueChannel: bound_port before start()")
        sockets = self._server.servers[0].sockets
        if not sockets:
            raise ChannelError("SendblueChannel: no bound sockets")
        return int(sockets[0].getsockname()[1])

    async def start(self) -> None:
        if self._started:
            return
        if not self.allowed_numbers:
            raise ValueError("SendblueChannel: allowed_numbers must be non-empty")

        self._http = httpx.AsyncClient(
            transport=self._transport,
            base_url=self._base_url,
        )
        self._client = SendblueClient(
            http=self._http,
            api_key_id=self.api_key_id,
            api_secret=self.api_secret,
            from_number=self.from_number,
            base_url=self._base_url,
        )
        router = build_router(
            queue=self._queue,
            sendblue=self._client,
            signing_secret=self.signing_secret,
            allowed_numbers=self.allowed_numbers,
            webhook_path=self.webhook_path,
        )

        config = uvicorn.Config(
            app=router,
            host=self.host,
            port=self.port,
            log_level="warning",
            access_log=False,
            lifespan="off",
        )
        self._server = uvicorn.Server(config)
        self._serve_task = asyncio.create_task(self._server.serve())

        while not self._server.started:
            await asyncio.sleep(0.01)

        self._started = True
        self._stopped = False
        _log.info(
            "SendblueChannel started host=%s port=%d path=%s",
            self.host,
            self.bound_port,
            self.webhook_path,
        )

    async def stop(self) -> None:
        if self._stopped or not self._started:
            self._stopped = True
            return
        self._stopped = True

        if self._server is not None:
            self._server.should_exit = True
        if self._serve_task is not None:
            try:
                await asyncio.wait_for(self._serve_task, timeout=5.0)
            except TimeoutError:
                self._serve_task.cancel()
        if self._http is not None:
            await self._http.aclose()

    async def send(self, message: OutgoingMessage) -> None:
        if self._stopped or not self._started:
            raise ChannelError("SendblueChannel: send() before start() or after stop()")
        if not message.reply_to_thread_key:
            raise ChannelError("SendblueChannel: send() requires reply_to_thread_key (recipient)")
        assert self._client is not None  # guarded by _started

        media_url: str | None = None
        if message.attachments:
            for att in message.attachments:
                if att.kind == "image" and att.url:
                    media_url = att.url
                    break

        try:
            await self._client.send_message(
                to=message.reply_to_thread_key,
                content=message.text or "",
                media_url=media_url,
            )
        except SendblueError as exc:
            raise ChannelError(str(exc)) from exc

    async def inbound_put(self, message: IncomingMessage) -> None:
        """Enqueue a synthetic message onto the receive() path.

        Used by zeno-scheduler to inject proactive messages without a real
        webhook delivery.
        """
        await self._queue.put(message)

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        while not self._stopped:
            try:
                msg = await asyncio.wait_for(self._queue.get(), timeout=0.5)
            except TimeoutError:
                continue
            yield msg
