"""Thin httpx wrapper over Sendblue's REST API.

Two endpoints only:
  - `/api/send-message` — body `{number, from_number, content}` with
    optional `media_url`. Raises `SendblueError` on non-2xx.
  - `/api/send-typing-indicator` — body `{number, from_number}`.
    Best-effort: failures are logged at WARNING, never raised.

The client does NOT own its `httpx.AsyncClient`; the channel creates and
closes the client alongside the rest of its lifecycle. No internal retry —
Zeno's `on_send_failure` policy handles that at the core layer.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

_log = logging.getLogger("zeno.channels.sendblue")

_SEND_PATH = "/api/send-message"
_TYPING_PATH = "/api/send-typing-indicator"
_MAX_CONTENT_LEN = 18_996


class SendblueError(RuntimeError):
    """Raised when the Sendblue API returns a non-2xx or the transport fails."""


class SendblueClient:
    """Low-level Sendblue REST client. Owned and lifecycled by the channel."""

    def __init__(
        self,
        *,
        http: httpx.AsyncClient,
        api_key_id: str,
        api_secret: str,
        from_number: str,
        base_url: str = "https://api.sendblue.com",
    ) -> None:
        self._http = http
        self._from_number = from_number
        self._base_url = base_url.rstrip("/")
        self._headers: dict[str, str] = {
            "sb-api-key-id": api_key_id,
            "sb-api-secret-key": api_secret,
            "content-type": "application/json",
        }

    async def send_message(
        self,
        *,
        to: str,
        content: str = "",
        media_url: str | None = None,
    ) -> None:
        """POST a text (optionally + image) message to Sendblue."""
        if len(content) > _MAX_CONTENT_LEN:
            _log.warning(
                "event=content_truncated original_len=%d max_len=%d",
                len(content),
                _MAX_CONTENT_LEN,
            )
            content = content[: _MAX_CONTENT_LEN - 1] + "…"

        body: dict[str, Any] = {
            "number": to,
            "from_number": self._from_number,
            "content": content,
        }
        if media_url is not None:
            body["media_url"] = media_url

        url = f"{self._base_url}{_SEND_PATH}"
        try:
            resp = await self._http.post(url, json=body, headers=self._headers)
        except httpx.HTTPError as exc:
            raise SendblueError(f"sendblue transport error: {exc}") from exc

        if resp.status_code >= 400:
            raise SendblueError(
                f"sendblue send-message failed: status={resp.status_code} body={resp.text[:500]!r}"
            )

    async def send_typing(self, *, to: str) -> None:
        """Best-effort typing indicator. Never raises."""
        body = {"number": to, "from_number": self._from_number}
        url = f"{self._base_url}{_TYPING_PATH}"
        try:
            resp = await self._http.post(url, json=body, headers=self._headers)
        except httpx.HTTPError as exc:
            _log.warning("event=typing_transport_error error=%s", exc)
            return

        if resp.status_code >= 400:
            _log.warning(
                "event=typing_rejected status=%d body=%s",
                resp.status_code,
                resp.text[:200],
            )
