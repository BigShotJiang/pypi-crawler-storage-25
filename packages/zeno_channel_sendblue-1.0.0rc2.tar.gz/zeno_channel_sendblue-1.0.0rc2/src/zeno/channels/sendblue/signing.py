"""Sendblue webhook signature verification.

Sendblue signs webhooks by echoing the configured shared secret verbatim
in the `sb-signing-secret` request header — there is no HMAC of the body.
We compare the header against the configured secret with
`hmac.compare_digest` for timing safety.

The algorithm matches Helios's production channel
(`assistant/security/auth.py::timing_safe_equal`). If Sendblue ever moves
to a body-HMAC scheme, this module is the single call site to update.
"""

from __future__ import annotations

import hmac


def verify(header_value: str | None, secret: str) -> bool:
    """Return True iff the request header matches the configured secret."""
    if header_value is None:
        return False
    return hmac.compare_digest(header_value.encode("utf-8"), secret.encode("utf-8"))
