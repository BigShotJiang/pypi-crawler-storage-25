"""Sendblue webhook payload parsing.

Pure translation from Sendblue's JSON body into a Zeno `IncomingMessage`,
or a `RejectionReason` sentinel when the payload must be dropped at the
channel boundary. The router maps each rejection reason to a 200 OK + log
and never surfaces the payload to core.

Payload shape (from Helios's field-tested integration):

    {
      "from_number": "+31600000000",   # sender E.164
      "content":     "text body",      # may be empty with media
      "message_handle": "msg_abc",     # Sendblue's opaque id
      "service":     "iMessage",       # or "SMS"
      "media_url":   "" | "https://…"  # single string
    }

Group messages (`group_id` non-null) are out of scope for v1 and rejected.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from zeno.channels.messages import Attachment, IncomingMessage

_E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")


class RejectionReason(StrEnum):
    """Why the router dropped a webhook payload."""

    NON_IMESSAGE_SERVICE = "non_imessage_service"
    GROUP_MESSAGE = "group_message"
    INVALID_SENDER = "invalid_sender"
    EMPTY = "empty"


def parse_inbound(payload: dict[str, Any]) -> IncomingMessage | RejectionReason:
    """Translate a Sendblue webhook body into an `IncomingMessage` or rejection."""
    if str(payload.get("service", "")).strip() != "iMessage":
        return RejectionReason.NON_IMESSAGE_SERVICE

    if payload.get("group_id") is not None:
        return RejectionReason.GROUP_MESSAGE

    from_number = payload.get("from_number")
    if not from_number or not isinstance(from_number, str):
        return RejectionReason.EMPTY
    if not _E164_RE.match(from_number):
        return RejectionReason.INVALID_SENDER

    content = str(payload.get("content") or "")
    media_url = str(payload.get("media_url") or "").strip()

    if not content and not media_url:
        return RejectionReason.EMPTY

    attachments = [Attachment(kind="image", url=media_url)] if media_url else []

    return IncomingMessage(
        user_id=from_number,
        text=content,
        received_at=datetime.now(UTC),
        thread_key=None,
        attachments=attachments,
    )
