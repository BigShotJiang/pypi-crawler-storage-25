"""Starlette router backing `SendblueChannel`'s webhook.

One POST route: verify signature -> parse payload -> drop rejections with
a 200 + log -> stamp `thread_key = from_number` so the turn worker routes
the reply back -> fire-and-forget typing indicator -> enqueue to the
channel's bounded queue (with timeout to avoid blocking Sendblue when the
queue is saturated).

Response policy (matches Helios):
  * 401 only when the signature is missing/wrong -- every other rejection
    returns 200 so Sendblue does not retry and so the 401 audit signal
    stays meaningful.

The router is a pure factory; it owns no state beyond what the caller
passes in. Lifecycle (uvicorn, httpx client) lives on the channel.
"""

from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
from collections.abc import Iterable

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route
from zeno.channels.messages import IncomingMessage
from zeno.channels.sendblue.client import SendblueClient
from zeno.channels.sendblue.parsing import RejectionReason, parse_inbound
from zeno.channels.sendblue.signing import verify

_log = logging.getLogger("zeno.channels.sendblue")

_SIGNATURE_HEADER = "sb-signing-secret"


def build_router(
    *,
    queue: asyncio.Queue[IncomingMessage],
    sendblue: SendblueClient,
    signing_secret: str,
    allowed_numbers: Iterable[str],
    webhook_path: str = "/webhook",
    enqueue_timeout: float = 1.0,
) -> Starlette:
    """Build the Starlette app that receives Sendblue webhooks."""
    allow_set = frozenset(allowed_numbers)

    async def handle(request: Request) -> Response:
        if not verify(request.headers.get(_SIGNATURE_HEADER), signing_secret):
            _log.warning("event=bad_signature path=%s", request.url.path)
            return Response(status_code=401)

        try:
            raw = await request.body()
            payload = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            _log.warning("event=malformed_json")
            return Response(status_code=200)

        if not isinstance(payload, dict):
            _log.warning("event=malformed_json kind=not_object")
            return Response(status_code=200)

        result = parse_inbound(payload)
        if isinstance(result, RejectionReason):
            _log.warning("event=%s", result.value)
            return Response(status_code=200)

        if result.user_id not in allow_set:
            _log.warning("event=sender_rejected user_id=%s", result.user_id)
            return Response(status_code=200)

        incoming = dataclasses.replace(result, thread_key=result.user_id)

        asyncio.create_task(sendblue.send_typing(to=incoming.user_id))

        try:
            await asyncio.wait_for(queue.put(incoming), timeout=enqueue_timeout)
        except TimeoutError:
            _log.warning(
                "event=queue_full user_id=%s qsize=%d",
                incoming.user_id,
                queue.qsize(),
            )
            return Response(status_code=200)

        return Response(status_code=200)

    return Starlette(routes=[Route(webhook_path, handle, methods=["POST"])])
