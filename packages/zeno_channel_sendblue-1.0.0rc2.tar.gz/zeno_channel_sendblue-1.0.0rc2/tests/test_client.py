"""Tests for `SendblueClient` — the thin REST wrapper over Sendblue's API."""

from __future__ import annotations

import json
import logging

import httpx
import pytest
from zeno.channels.sendblue.client import SendblueClient, SendblueError


def _transport(handler: httpx.MockTransport) -> httpx.AsyncClient:  # helper type
    return httpx.AsyncClient(transport=handler, base_url="https://api.sendblue.com")


def _client(transport: httpx.MockTransport) -> SendblueClient:
    http = _transport(transport)
    return SendblueClient(
        http=http,
        api_key_id="kid",
        api_secret="sec",
        from_number="+15550001111",
        base_url="https://api.sendblue.com",
    )


async def test_send_message_posts_body_and_auth_headers() -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["method"] = request.method
        captured["headers"] = dict(request.headers)
        captured["body"] = json.loads(request.content)
        return httpx.Response(200, json={"status": "QUEUED"})

    client = _client(httpx.MockTransport(handle))
    await client.send_message(to="+31600000000", content="hi")

    assert captured["url"] == "https://api.sendblue.com/api/send-message"
    assert captured["method"] == "POST"
    headers = captured["headers"]
    assert isinstance(headers, dict)
    assert headers["sb-api-key-id"] == "kid"
    assert headers["sb-api-secret-key"] == "sec"
    assert captured["body"] == {
        "number": "+31600000000",
        "from_number": "+15550001111",
        "content": "hi",
    }


async def test_send_message_includes_media_url_when_set() -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return httpx.Response(200)

    client = _client(httpx.MockTransport(handle))
    await client.send_message(
        to="+31600000000",
        content="look",
        media_url="https://cdn.example/a.jpg",
    )
    assert captured["body"] == {
        "number": "+31600000000",
        "from_number": "+15550001111",
        "content": "look",
        "media_url": "https://cdn.example/a.jpg",
    }


async def test_send_message_omits_media_when_none() -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return httpx.Response(200)

    client = _client(httpx.MockTransport(handle))
    await client.send_message(to="+31600000000", content="hi", media_url=None)
    assert "media_url" not in captured["body"]  # type: ignore[operator]


async def test_send_message_truncates_overlong_content(
    caplog: pytest.LogCaptureFixture,
) -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return httpx.Response(200)

    client = _client(httpx.MockTransport(handle))
    long_content = "a" * 20000

    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        await client.send_message(to="+31600000000", content=long_content)

    body = captured["body"]
    assert isinstance(body, dict)
    sent = body["content"]
    assert isinstance(sent, str)
    assert len(sent) == 18996
    assert sent.endswith("…")
    assert any("truncated" in r.message for r in caplog.records)


async def test_send_message_raises_on_4xx() -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        return httpx.Response(400, json={"error": "bad number"})

    client = _client(httpx.MockTransport(handle))
    with pytest.raises(SendblueError) as excinfo:
        await client.send_message(to="+31600000000", content="hi")
    assert "400" in str(excinfo.value)


async def test_send_message_raises_on_5xx() -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, text="try later")

    client = _client(httpx.MockTransport(handle))
    with pytest.raises(SendblueError):
        await client.send_message(to="+31600000000", content="hi")


async def test_send_message_wraps_connect_error() -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("unreachable", request=request)

    client = _client(httpx.MockTransport(handle))
    with pytest.raises(SendblueError):
        await client.send_message(to="+31600000000", content="hi")


async def test_send_typing_posts_to_typing_endpoint() -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content)
        return httpx.Response(200)

    client = _client(httpx.MockTransport(handle))
    await client.send_typing(to="+31600000000")

    assert captured["url"] == "https://api.sendblue.com/api/send-typing-indicator"
    assert captured["body"] == {
        "number": "+31600000000",
        "from_number": "+15550001111",
    }


async def test_send_typing_swallows_errors(caplog: pytest.LogCaptureFixture) -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        return httpx.Response(400, text="no route")

    client = _client(httpx.MockTransport(handle))
    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        await client.send_typing(to="+31600000000")  # must NOT raise
    assert any("typing" in r.message.lower() for r in caplog.records)


async def test_send_typing_swallows_transport_errors(
    caplog: pytest.LogCaptureFixture,
) -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom", request=request)

    client = _client(httpx.MockTransport(handle))
    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        await client.send_typing(to="+31600000000")  # must NOT raise
    assert any("typing" in r.message.lower() for r in caplog.records)
