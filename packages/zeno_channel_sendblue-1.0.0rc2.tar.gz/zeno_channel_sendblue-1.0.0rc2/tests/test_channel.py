"""End-to-end tests for SendblueChannel — live uvicorn + real HTTP."""

from __future__ import annotations

import asyncio
import json
from typing import Any

import httpx
import pytest
from zeno.channels.messages import OutgoingMessage
from zeno.channels.protocol import Channel
from zeno.channels.sendblue.channel import ChannelError, SendblueChannel


def _payload(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "from_number": "+31600000000",
        "content": "hi there",
        "message_handle": "msg_xyz",
        "service": "iMessage",
        "media_url": "",
    }
    base.update(overrides)
    return base


def _make_channel(
    *,
    transport: httpx.MockTransport,
    allowed: tuple[str, ...] = ("+31600000000",),
) -> SendblueChannel:
    return SendblueChannel(
        api_key_id="kid",
        api_secret="sec",
        from_number="+15550001111",
        signing_secret="shared-secret",
        allowed_numbers=allowed,
        host="127.0.0.1",
        port=0,
        webhook_path="/webhook",
        _transport=transport,
        _base_url="https://api.sendblue.com",
    )


def test_sendblue_channel_satisfies_protocol() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    assert isinstance(ch, Channel)


async def test_start_requires_non_empty_allowlist() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport, allowed=())
    with pytest.raises(ValueError):
        await ch.start()


async def test_start_stop_idempotent() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    await ch.start()
    await ch.start()  # no-op second call
    await ch.stop()
    await ch.stop()  # no-op second call


async def test_inbound_webhook_yields_incoming_message() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        port = ch.bound_port
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"http://127.0.0.1:{port}/webhook",
                headers={"sb-signing-secret": "shared-secret"},
                json=_payload(),
            )
        assert resp.status_code == 200

        async def _first_message() -> Any:
            async for msg in ch.receive():
                return msg
            return None

        msg = await asyncio.wait_for(_first_message(), timeout=2.0)
        assert msg is not None
        assert msg.user_id == "+31600000000"
        assert msg.text == "hi there"
        assert msg.thread_key == "+31600000000"
    finally:
        await ch.stop()


async def test_send_posts_to_sendblue() -> None:
    captured: dict[str, Any] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content)
        return httpx.Response(200)

    transport = httpx.MockTransport(handle)
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        await ch.send(OutgoingMessage(text="hello back", reply_to_thread_key="+31600000000"))
    finally:
        await ch.stop()

    assert captured["url"] == "https://api.sendblue.com/api/send-message"
    assert captured["body"]["number"] == "+31600000000"
    assert captured["body"]["content"] == "hello back"


async def test_send_requires_reply_to_thread_key() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        with pytest.raises(ChannelError):
            await ch.send(OutgoingMessage(text="no recipient"))
    finally:
        await ch.stop()


async def test_send_after_stop_raises() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    await ch.start()
    await ch.stop()
    with pytest.raises(ChannelError):
        await ch.send(OutgoingMessage(text="hi", reply_to_thread_key="+31600000000"))


async def test_send_wraps_sendblue_error_as_channel_error() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(500, text="boom"))
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        with pytest.raises(ChannelError):
            await ch.send(OutgoingMessage(text="hi", reply_to_thread_key="+31600000000"))
    finally:
        await ch.stop()


async def test_capabilities_advertises_images_and_typing() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    caps = ch.capabilities
    assert caps.supports_images is True
    assert caps.supports_typing is True
    assert caps.supports_streaming is False
    assert caps.supports_threading is False
