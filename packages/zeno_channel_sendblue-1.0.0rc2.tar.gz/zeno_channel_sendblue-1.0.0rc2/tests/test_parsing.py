"""Tests for Sendblue webhook payload parsing."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from zeno.channels.messages import Attachment, IncomingMessage
from zeno.channels.sendblue.parsing import RejectionReason, parse_inbound

FIXTURES = Path(__file__).parent / "fixtures"


def _load(name: str) -> dict[str, Any]:
    data: dict[str, Any] = json.loads((FIXTURES / name).read_text())
    return data


def _with(base: dict[str, Any], **overrides: Any) -> dict[str, Any]:
    merged = dict(base)
    merged.update(overrides)
    return merged


def test_parse_text_inbound_happy_path() -> None:
    result = parse_inbound(_load("sendblue_text_inbound.json"))
    assert isinstance(result, IncomingMessage)
    assert result.user_id == "+31600000000"
    assert result.text == "What's the weather?"
    assert result.thread_key is None
    assert result.attachments == []


def test_parse_image_inbound_happy_path() -> None:
    result = parse_inbound(_load("sendblue_image_inbound.json"))
    assert isinstance(result, IncomingMessage)
    assert result.user_id == "+31600000000"
    assert result.text == ""
    assert result.attachments == [Attachment(kind="image", url="https://cdn.example/a.jpg")]


def test_parse_empty_content_with_media_accepted() -> None:
    """Caption-less image still yields an IncomingMessage."""
    payload = _with(_load("sendblue_image_inbound.json"), content="")
    result = parse_inbound(payload)
    assert isinstance(result, IncomingMessage)
    assert result.text == ""
    assert len(result.attachments) == 1


def test_parse_invalid_e164_rejected() -> None:
    payload = _with(_load("sendblue_text_inbound.json"), from_number="+1-555-CALL-ME")
    assert parse_inbound(payload) is RejectionReason.INVALID_SENDER


def test_parse_sms_rejected() -> None:
    result = parse_inbound(_load("sendblue_sms_inbound.json"))
    assert result is RejectionReason.NON_IMESSAGE_SERVICE


def test_parse_group_rejected() -> None:
    payload = _with(_load("sendblue_text_inbound.json"), group_id="group_xyz")
    assert parse_inbound(payload) is RejectionReason.GROUP_MESSAGE


def test_parse_missing_from_number_rejected() -> None:
    payload = _load("sendblue_text_inbound.json")
    del payload["from_number"]
    assert parse_inbound(payload) is RejectionReason.EMPTY


def test_parse_missing_content_and_media_rejected() -> None:
    payload = _with(_load("sendblue_text_inbound.json"), content="", media_url="")
    assert parse_inbound(payload) is RejectionReason.EMPTY


def test_parse_null_group_id_accepted() -> None:
    """Sendblue sends `group_id: null` for 1:1 threads — must not reject."""
    payload = _with(_load("sendblue_text_inbound.json"), group_id=None)
    assert isinstance(parse_inbound(payload), IncomingMessage)


def test_parse_missing_service_rejected() -> None:
    """A payload without a service field shouldn't slip through as iMessage."""
    payload = _load("sendblue_text_inbound.json")
    del payload["service"]
    assert parse_inbound(payload) is RejectionReason.NON_IMESSAGE_SERVICE


@pytest.mark.parametrize("media_url", [None, ""])
def test_parse_nil_media_url_produces_no_attachment(media_url: str | None) -> None:
    payload = _with(_load("sendblue_text_inbound.json"), media_url=media_url)
    result = parse_inbound(payload)
    assert isinstance(result, IncomingMessage)
    assert result.attachments == []
