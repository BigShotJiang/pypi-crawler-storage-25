"""Tests for the Starlette router that backs SendblueChannel's webhook."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx
import pytest
from starlette.testclient import TestClient
from zeno.channels.messages import IncomingMessage
from zeno.channels.sendblue.client import SendblueClient
from zeno.channels.sendblue.router import build_router

SECRET = "webhook-shared-secret"
ALLOWED = frozenset({"+31600000000"})

Setup = tuple[TestClient, asyncio.Queue[IncomingMessage], list[httpx.Request]]


def _payload(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "from_number": "+31600000000",
        "content": "What's the weather?",
        "message_handle": "msg_abc123",
        "service": "iMessage",
        "media_url": "",
    }
    base.update(overrides)
    return base


@pytest.fixture
def setup() -> Setup:
    queue: asyncio.Queue[IncomingMessage] = asyncio.Queue(maxsize=64)
    sent_requests: list[httpx.Request] = []

    def handle(request: httpx.Request) -> httpx.Response:
        sent_requests.append(request)
        return httpx.Response(200)

    http = httpx.AsyncClient(
        transport=httpx.MockTransport(handle),
        base_url="https://api.sendblue.com",
    )
    sendblue = SendblueClient(
        http=http,
        api_key_id="kid",
        api_secret="sec",
        from_number="+15550001111",
    )
    router = build_router(
        queue=queue,
        sendblue=sendblue,
        signing_secret=SECRET,
        allowed_numbers=ALLOWED,
        webhook_path="/webhook",
    )
    client = TestClient(router)
    return client, queue, sent_requests


def test_valid_signature_text_payload_enqueues(setup: Setup) -> None:
    client, queue, _sent = setup
    r = client.post(
        "/webhook",
        headers={"sb-signing-secret": SECRET},
        json=_payload(),
    )
    assert r.status_code == 200
    msg = queue.get_nowait()
    assert msg.user_id == "+31600000000"
    assert msg.text == "What's the weather?"
    assert msg.thread_key == "+31600000000"


def test_bad_signature_returns_401(setup: Setup) -> None:
    client, queue, _sent = setup
    r = client.post(
        "/webhook",
        headers={"sb-signing-secret": "nope"},
        json=_payload(),
    )
    assert r.status_code == 401
    assert queue.empty()


def test_missing_signature_returns_401(setup: Setup) -> None:
    client, queue, _sent = setup
    r = client.post("/webhook", json=_payload())
    assert r.status_code == 401
    assert queue.empty()


def test_sms_service_dropped_200(setup: Setup, caplog: pytest.LogCaptureFixture) -> None:
    client, queue, _sent = setup
    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        r = client.post(
            "/webhook",
            headers={"sb-signing-secret": SECRET},
            json=_payload(service="SMS"),
        )
    assert r.status_code == 200
    assert queue.empty()
    assert any("non_imessage" in rec.message for rec in caplog.records)


def test_non_allowlisted_sender_dropped_200(setup: Setup, caplog: pytest.LogCaptureFixture) -> None:
    client, queue, _sent = setup
    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        r = client.post(
            "/webhook",
            headers={"sb-signing-secret": SECRET},
            json=_payload(from_number="+19999999999"),
        )
    assert r.status_code == 200
    assert queue.empty()
    assert any("sender_rejected" in rec.message for rec in caplog.records)


def test_group_message_dropped_200(setup: Setup, caplog: pytest.LogCaptureFixture) -> None:
    client, queue, _sent = setup
    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        r = client.post(
            "/webhook",
            headers={"sb-signing-secret": SECRET},
            json=_payload(group_id="group_xyz"),
        )
    assert r.status_code == 200
    assert queue.empty()
    assert any("group_message" in rec.message for rec in caplog.records)


def test_malformed_json_returns_200(setup: Setup, caplog: pytest.LogCaptureFixture) -> None:
    client, queue, _sent = setup
    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        r = client.post(
            "/webhook",
            headers={
                "sb-signing-secret": SECRET,
                "content-type": "application/json",
            },
            content=b"{not json",
        )
    assert r.status_code == 200
    assert queue.empty()
    assert any("malformed_json" in rec.message for rec in caplog.records)


def test_image_payload_enqueues_attachment(setup: Setup) -> None:
    client, queue, _sent = setup
    r = client.post(
        "/webhook",
        headers={"sb-signing-secret": SECRET},
        json=_payload(media_url="https://cdn.example/a.jpg"),
    )
    assert r.status_code == 200
    msg = queue.get_nowait()
    assert len(msg.attachments) == 1
    assert msg.attachments[0].url == "https://cdn.example/a.jpg"


def test_valid_payload_fires_typing_indicator(setup: Setup) -> None:
    client, _queue, sent = setup
    r = client.post(
        "/webhook",
        headers={"sb-signing-secret": SECRET},
        json=_payload(),
    )
    assert r.status_code == 200
    # Starlette TestClient runs the handler in a sync wrapper; the
    # fire-and-forget typing task is scheduled on the event loop and
    # completes before the request returns because TestClient awaits
    # the handler coroutine fully.
    typing_urls = [str(req.url) for req in sent if "typing" in str(req.url)]
    assert any("send-typing-indicator" in u for u in typing_urls)


def test_queue_full_drops_message(caplog: pytest.LogCaptureFixture) -> None:
    queue: asyncio.Queue[IncomingMessage] = asyncio.Queue(maxsize=1)
    sent: list[httpx.Request] = []

    def handle(request: httpx.Request) -> httpx.Response:
        sent.append(request)
        return httpx.Response(200)

    http = httpx.AsyncClient(
        transport=httpx.MockTransport(handle),
        base_url="https://api.sendblue.com",
    )
    sendblue = SendblueClient(http=http, api_key_id="k", api_secret="s", from_number="+15550001111")
    router = build_router(
        queue=queue,
        sendblue=sendblue,
        signing_secret=SECRET,
        allowed_numbers=ALLOWED,
        webhook_path="/webhook",
        enqueue_timeout=0.05,
    )
    client = TestClient(router)

    r1 = client.post("/webhook", headers={"sb-signing-secret": SECRET}, json=_payload())
    assert r1.status_code == 200
    assert queue.qsize() == 1

    with caplog.at_level(logging.WARNING, logger="zeno.channels.sendblue"):
        r2 = client.post(
            "/webhook",
            headers={"sb-signing-secret": SECRET},
            json=_payload(content="second"),
        )
    assert r2.status_code == 200
    assert queue.qsize() == 1
    assert any("queue_full" in rec.message for rec in caplog.records)
