"""Test fixtures for zeno-channel-sendblue.

Uvicorn's `Server.capture_signals` installs SIGINT/SIGTERM handlers on
the main thread when `Server.serve()` starts. Between sequential test
cases this clobbers pytest's own signal handling and can produce spooky
"main loop never exits" behavior. For the test environment we no-op it.

Note: `capture_signals` is used as a context manager inside `serve()`,
so the replacement must itself be a CM (hence `contextmanager`).
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager

import pytest
import uvicorn


@contextmanager
def _null_cm(self: uvicorn.Server) -> Iterator[None]:
    yield


@pytest.fixture(autouse=True)
def _no_signal_capture(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(uvicorn.Server, "capture_signals", _null_cm)
