"""Tests for Sendblue shared-secret signature verification."""

from __future__ import annotations

from zeno.channels.sendblue.signing import verify


def test_valid_secret_returns_true() -> None:
    assert verify("correct-secret", "correct-secret") is True


def test_wrong_secret_returns_false() -> None:
    assert verify("wrong", "correct-secret") is False


def test_none_header_returns_false() -> None:
    assert verify(None, "correct-secret") is False


def test_empty_header_returns_false() -> None:
    assert verify("", "correct-secret") is False


def test_prefix_match_returns_false() -> None:
    """Guards against naive startswith-style comparisons."""
    assert verify("correct-secret-extra", "correct-secret") is False


def test_unicode_safe() -> None:
    assert verify("séсret-🔒", "séсret-🔒") is True
    assert verify("séсret-🔒", "different") is False
