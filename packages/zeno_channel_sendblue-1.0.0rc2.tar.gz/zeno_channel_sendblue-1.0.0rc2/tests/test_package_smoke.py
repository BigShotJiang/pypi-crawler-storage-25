"""Package-scaffold smoke tests for zeno-channel-sendblue."""

from __future__ import annotations

import importlib.metadata

from zeno.channels.protocol import Channel
from zeno.channels.sendblue.channel import SendblueChannel


def _channel() -> SendblueChannel:
    return SendblueChannel(
        api_key_id="kid",
        api_secret="sec",
        from_number="+15550001111",
        signing_secret="s",
        allowed_numbers=("+31600000000",),
    )


def test_sendblue_channel_is_importable() -> None:
    """The class imports cleanly and advertises its name."""
    assert _channel().name == "sendblue"


def test_sendblue_channel_registers_entry_point() -> None:
    """The `zeno.channels` entry-point group exposes `sendblue`."""
    eps = importlib.metadata.entry_points(group="zeno.channels")
    names = {ep.name for ep in eps}
    assert "sendblue" in names
    sendblue_ep = next(ep for ep in eps if ep.name == "sendblue")
    assert sendblue_ep.value == "zeno.channels.sendblue.channel:SendblueChannel"


def test_sendblue_channel_satisfies_channel_protocol() -> None:
    """Runtime structural check — `SendblueChannel` satisfies `Channel`."""
    assert isinstance(_channel(), Channel)
