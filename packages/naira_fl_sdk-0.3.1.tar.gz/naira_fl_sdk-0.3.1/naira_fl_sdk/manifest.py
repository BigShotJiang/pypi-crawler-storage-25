"""Pydantic models for model.yaml manifest parsing and validation."""

import re
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


NAME_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")

ALLOWED_METRIC_TYPES = {"float", "int"}
ALLOWED_METRIC_FORMATS = {"number", "percentage", "duration"}
ALLOWED_AGGREGATES = {"weighted_avg", "sum", "mean", "harmonic_mean", "max", "min"}


class MetricDef(BaseModel):
    """Definition of a single metric reported by a trainer."""

    name: str
    display_name: Optional[str] = None
    type: str = "float"
    format: str = "number"
    aggregate: str = "weighted_avg"
    group: Optional[str] = None
    primary: bool = False

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str) -> str:
        if v not in ALLOWED_METRIC_TYPES:
            raise ValueError(f"metric type must be one of {ALLOWED_METRIC_TYPES}, got: '{v}'")
        return v

    @field_validator("format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        if v not in ALLOWED_METRIC_FORMATS:
            raise ValueError(f"metric format must be one of {ALLOWED_METRIC_FORMATS}, got: '{v}'")
        return v

    @field_validator("aggregate")
    @classmethod
    def validate_aggregate(cls, v: str) -> str:
        if v not in ALLOWED_AGGREGATES:
            raise ValueError(f"metric aggregate must be one of {ALLOWED_AGGREGATES}, got: '{v}'")
        return v


class MetricsSchema(BaseModel):
    """Schema describing all metrics reported by a trainer across training phases."""

    train: List[MetricDef] = Field(default_factory=list)
    validate: List[MetricDef] = Field(default_factory=list)
    test: List[MetricDef] = Field(default_factory=list)


class DataFile(BaseModel):
    name: str
    description: str = ""


class DataSpec(BaseModel):
    description: str = ""
    required_files: List[DataFile] = Field(default_factory=list)
    optional_files: List[DataFile] = Field(default_factory=list)


class HyperparameterDef(BaseModel):
    default: Any
    type: str = "float"
    description: str = ""


class ModelSpec(BaseModel):
    file: str = "model.py"
    class_name: str = Field(..., alias="class")

    model_config = {"populate_by_name": True}


class TrainerSpec(BaseModel):
    file: str = "trainer.py"


class ModelManifest(BaseModel):
    """Parsed and validated model.yaml manifest."""

    name: str
    description: str
    framework: str = "pytorch"

    model: ModelSpec
    trainer: TrainerSpec

    requirements: List[str] = Field(default_factory=list)
    data: Optional[DataSpec] = None
    hyperparameters: Dict[str, HyperparameterDef] = Field(default_factory=dict)
    metrics: MetricsSchema

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not NAME_PATTERN.match(v):
            raise ValueError(
                f"Model name must match {NAME_PATTERN.pattern}, got: '{v}'"
            )
        return v

    @field_validator("framework")
    @classmethod
    def validate_framework(cls, v: str) -> str:
        allowed = {"pytorch", "tensorflow"}
        if v not in allowed:
            raise ValueError(f"framework must be one of {allowed}, got: '{v}'")
        return v

    def get_hyperparams_defaults(self) -> Dict[str, Any]:
        """Return dict of hyperparameter name -> default value."""
        return {k: v.default for k, v in self.hyperparameters.items()}



def _find_manifest_path(directory: str) -> str:
    """Find model.yaml in a directory."""
    from pathlib import Path

    p = Path(directory) / "model.yaml"
    if p.exists():
        return str(p)
    raise FileNotFoundError(f"model.yaml not found in {directory}")


def parse_manifest(yaml_text: str) -> ModelManifest:
    """Parse a model.yaml string into a validated ModelManifest."""
    import yaml

    data = yaml.safe_load(yaml_text)
    if not isinstance(data, dict):
        raise ValueError("model.yaml must be a YAML mapping")
    # Strip legacy fields that may still exist in old manifests
    data.pop("strategy", None)
    data.pop("fl_config", None)
    return ModelManifest(**data)


def parse_manifest_file(path: str) -> ModelManifest:
    """Parse a model.yaml file into a validated ModelManifest."""
    with open(path) as f:
        return parse_manifest(f.read())
