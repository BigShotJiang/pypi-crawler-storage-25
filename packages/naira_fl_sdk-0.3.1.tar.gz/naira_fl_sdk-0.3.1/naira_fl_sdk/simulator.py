"""Local FL simulation runner - tests trainer logic without NVFlare."""

import importlib.util
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from .manifest import ModelManifest, parse_manifest_file, _find_manifest_path


def _import_module_from_file(module_name: str, file_path: Path):
    """Dynamically import a Python module from a file path."""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def run_simulation(
    template_dir: str,
    data_path: Optional[str] = None,
    num_rounds: int = 2,
    hyperparams_overrides: Optional[Dict[str, Any]] = None,
) -> None:
    """Run a local FL simulation using the model profile's trainer.

    Args:
        template_dir: Path to model profile directory containing model.yaml.
        data_path: Path to data directory. Falls back to template_dir if None.
        num_rounds: Number of simulated FL rounds.
        hyperparams_overrides: Override hyperparameter defaults.
    """
    tdir = Path(template_dir).resolve()
    manifest_path = _find_manifest_path(str(tdir))
    manifest = parse_manifest_file(manifest_path)

    effective_data_path = data_path or str(tdir)

    # Build hyperparams
    hyperparams = manifest.get_hyperparams_defaults()
    if hyperparams_overrides:
        hyperparams.update(hyperparams_overrides)

    # Add template dir to sys.path so imports work
    if str(tdir) not in sys.path:
        sys.path.insert(0, str(tdir))

    # Import trainer module
    trainer_file = tdir / manifest.trainer.file
    if not trainer_file.exists():
        raise FileNotFoundError(f"Trainer file not found: {trainer_file}")

    trainer_module = _import_module_from_file("_fl_trainer", trainer_file)

    # Find FLTrainer subclass
    from .trainer import FLTrainer

    trainer_cls = None
    for attr_name in dir(trainer_module):
        attr = getattr(trainer_module, attr_name)
        if (
            isinstance(attr, type)
            and issubclass(attr, FLTrainer)
            and attr is not FLTrainer
        ):
            trainer_cls = attr
            break

    if trainer_cls is None:
        raise ValueError(
            f"No FLTrainer subclass found in {manifest.trainer.file}"
        )

    # Instantiate trainer
    trainer = trainer_cls()

    # Run data validation first
    print(f"Validating data at: {effective_data_path}")
    result = trainer.validate_data(effective_data_path, hyperparams)
    if result.warnings:
        for w in result.warnings:
            print(f"  WARN: {w}")
    if not result.valid:
        print("Data validation FAILED:")
        for e in result.errors:
            print(f"  ERROR: {e}")
        raise SystemExit(1)
    print("Data validation PASSED\n")

    # Setup and run
    print(f"Setting up trainer: {trainer_cls.__name__}")
    print(f"Data path: {effective_data_path}")
    print(f"Hyperparams: {hyperparams}")
    trainer.setup(effective_data_path, hyperparams)

    model = trainer.get_model()
    print(f"Model: {model.__class__.__name__}")
    print(f"Running {num_rounds} rounds...\n")

    for round_num in range(1, num_rounds + 1):
        print(f"--- Round {round_num}/{num_rounds} ---")

        train_metrics = trainer.train(model)
        print(f"  [train]    {train_metrics}")

        val_metrics = trainer.validate(model)
        if val_metrics:
            print(f"  [validate] {val_metrics}")
        else:
            print("  [validate] (no validation data)")

        print()

    # Run test() if trainer has a non-empty implementation
    test_metrics = trainer.test(model)
    if test_metrics:
        print(f"--- Test ---")
        print(f"  [test]     {test_metrics}")
        print()

    print("Simulation complete.")
