"""Naira FL SDK - Federated Learning model profile development kit."""

__version__ = "0.3.1"

from .trainer import FLTrainer, ValidationResult
from .manifest import ModelManifest

__all__ = ["FLTrainer", "ValidationResult", "ModelManifest", "__version__"]
