import boto3
import logging
from datetime import datetime, timedelta, timezone

logger = logging.getLogger(__name__)

class AgAuditor:
    """
    Antigravity Lite - Glue Cost & FinOps Auditor
    ========================================
    Herramienta de auditoría financiera y operativa para AWS Glue.
    Evalúa si estás pagando sobrecostos masivos en la nube debido a bucles infinitos 
    o configuraciones de RAM infladas para encubrir fallos del Catalyst Optimizer.
    """
    
    @staticmethod
    def get_dpu_price(region: str) -> float:
        # Standard AWS Glue DPU per hour cost
        return 0.44 

    @classmethod
    def run_aws_audit(cls, region="us-east-1", dias_analisis=7):
        print(f"\n🔍 [ANTIGRAVITY LITE] Iniciando Auditoría FinOps (Región: {region})...")
        print(f"Analizando métricas de los últimos {dias_analisis} días...\n")
        
        try:
            glue_client = boto3.client('glue', region_name=region)
            cw_client = boto3.client('cloudwatch', region_name=region)
            glue_client.get_jobs(MaxResults=1)
        except Exception as e:
            print("❌ Error de Autenticación AWS. Verifique sus credenciales Boto3.")
            return

        tiempo_limite = datetime.now(timezone.utc) - timedelta(days=dias_analisis)
        
        jobs = []
        paginator = glue_client.get_paginator('get_jobs')
        for page in paginator.paginate():
            for job in page.get('Jobs', []):
                jobs.append(job['Name'])
                
        if not jobs:
            print("No se encontraron Jobs de AWS Glue desplegados.")
            return
            
        print(f"📡 Se descubrieron {len(jobs)} Jobs. Calculando desperdicio (DPUs)...\n")
        
        costo_dpu_hora = cls.get_dpu_price(region)
        resultados = []
        
        print(f"{'NOMBRE DEL JOB':<35} | {'WORKER TYPE':<12} | {'DPUs':<6} | {'MAX RAM %':<12} | {'GASTO EST. (7d)'}")
        print("-" * 90)

        for job_name in jobs:
            runs_validos = 0
            total_horas_ejecucion = 0
            dpus_reales_promedio = 0
            ultimo_worker_type = "N/A"
            
            runs_paginator = glue_client.get_paginator('get_job_runs')
            try:
                for page in runs_paginator.paginate(JobName=job_name):
                    for run in page.get('JobRuns', []):
                        if run.get('StartedOn', datetime.min.replace(tzinfo=timezone.utc)) < tiempo_limite:
                            continue
                        
                        runs_validos += 1
                        
                        if 'CompletedOn' in run and 'StartedOn' in run:
                            duracion_segundos = (run['CompletedOn'] - run['StartedOn']).total_seconds()
                            total_horas_ejecucion += (duracion_segundos / 3600.0)
                            
                        worker_type = run.get('WorkerType', 'G.1X')
                        num_workers = run.get('NumberOfWorkers', run.get('MaxCapacity', 2))
                        
                        peso_dpu = {'Standard': 1, 'G.1X': 1, 'G.2X': 2, 'G.4X': 4, 'G.8X': 8, 'Z.2X': 2}
                        dpus_reales = num_workers * peso_dpu.get(worker_type, 1)
                        
                        dpus_reales_promedio = dpus_reales
                        ultimo_worker_type = worker_type
                        
            except Exception:
                continue 
                
            if runs_validos == 0:
                continue
                
            max_memory_percent = 0.0
            try:
                metric_response = cw_client.get_metric_statistics(
                    Namespace='Glue',
                    MetricName='glue.driver.jvm.heap.usage', 
                    Dimensions=[
                        {'Name': 'JobName', 'Value': job_name},
                        {'Name': 'Type', 'Value': 'gauge'}
                    ],
                    StartTime=tiempo_limite,
                    EndTime=datetime.now(timezone.utc),
                    Period=3600,
                    Statistics=['Maximum']
                )
                datapoints = metric_response.get('Datapoints', [])
                if datapoints:
                    max_memory_percent = max([dp['Maximum'] for dp in datapoints]) * 100
            except Exception:
                pass 
                
            gasto_total = total_horas_ejecucion * dpus_reales_promedio * costo_dpu_hora
            
            if gasto_total > 0:
                resultados.append({
                    "nombre": job_name,
                    "runs": runs_validos,
                    "dpus": dpus_reales_promedio,
                    "worker_type": ultimo_worker_type,
                    "memoria": max_memory_percent,
                    "gasto": gasto_total
                })
                
        resultados = sorted(resultados, key=lambda x: x["gasto"], reverse=True)
        
        total_desperdicio = 0
        for res in resultados[:10]:
            mem_str = f"{res['memoria']:.1f}%" if res['memoria'] > 0 else "N/A"
            
            if res['memoria'] > 85.0 or res['worker_type'] in ['G.4X', 'G.8X']:
                total_desperdicio += (res['gasto'] * 0.6)
                mem_str += " ⚠️ RIESGO AST"
                
            print(f"{res['nombre']:<35} | {res['worker_type']:<12} | {res['dpus']:<6.1f} | {mem_str:<12} | ${res['gasto']:,.2f}")
            
        print("-" * 90)
        print(f"\n🚨 REPORTE DE FUGA DE CAPITAL AWS:")
        print(f"Estás perdiendo un estimado de: ${total_desperdicio * 4:,.2f} USD al mes pagando instancias gigantes.")
        
        print("\n=========================================================================================")
        print("¿Tu script se ahoga con Wide Dataframes y tienes que pagar más RAM?")
        print("El Catalyst Optimizer de Spark es el culpable. No pagues más en AWS Glue.")
        print("Descarga la licencia B2B de 'Antigravity Pro' para obtener el 'DataFrameChunker' matemático.")
        print("Corta tu factura de G.4X a G.1X hoy mismo contactando al Arquitecto de Datos.")
        print("Más información: linkedin.com/in/tu-perfil-aqui")
        print("=========================================================================================\n")
