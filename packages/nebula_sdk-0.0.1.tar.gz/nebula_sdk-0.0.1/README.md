# nebula-sdk

Official Python SDK for [Nebula](https://trynebula.ai).

This release (`0.0.1`) is a **name-reservation placeholder**. The real SDK
will be published here in an upcoming release at a synchronized version
shared with `@nebula-ai/sdk` on npm.

Until then, install the existing SDK:

```bash
pip install nebula-client
```

## Links

- Homepage: https://trynebula.ai
- Documentation: https://docs.trynebula.ai
- Source: https://github.com/nebula-agi/nebula-sdks
