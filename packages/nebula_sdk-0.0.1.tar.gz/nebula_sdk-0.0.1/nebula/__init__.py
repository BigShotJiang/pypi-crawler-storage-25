"""Nebula SDK — name reservation placeholder.

The real SDK will be published here shortly. In the meantime, use
``nebula-client`` on PyPI.
"""

__version__ = "0.0.1"
