# Rubkey - Rubika Bot API Library

> **Official Rubika Channel:** [@library_rubkey](https://rubika.ir/library_rubkey)

Rubika Bot API library - Simple and powerful bot framework for Rubika messenger

## Source Code

For source code of the Rubkey library, visit the GitHub page:

[https://github.com/codetansarian/Source-code-of-the-Rubkey-library](https://github.com/codetansarian/Source-code-of-the-Rubkey-library)

## Features

- Send text messages with Chat Keypad and Inline Keypad
- Send polls
- Send files (image, video, file, voice, music, gif)
- Chat Keypad with button types: Simple, AskMyPhoneNumber, Textbox, File, GalleryImage, GalleryVideo, CameraImage, CameraVideo, Audio, RecordAudio, Barcode
- Inline Keypad with auto-updating data (counter, stats, etc.)
- Textbox button with SingleLine/MultiLine and String/Number keypad
- Admin system with ADMIN_ID and ADMIN_PASSWORD
- Admin-specific commands, buttons, and keypads
- Ban system with ban/unban users
- Edit and delete messages
- Edit message with Inline Keypad update
- Edit and remove Chat Keypad
- Forward messages
- Message handlers for commands, buttons, and all messages
- Command and message filters with regex
- Rate limiting to prevent spam
- Cache system for faster responses
- Error handling with automatic retry (exponential backoff)
- Analytics for tracking user behavior
- Session management with auto offset saving
- User session storage (JSON)
- SQLite database for messages and users
- Async bot support (asyncio + aiohttp)
- Webhook support (aiohttp async server)
- Contact and file receiving from users
- Built-in user counter (total_users, user_ids)
- Group support with GroupBot and GroupHandlers
- Group-specific commands, messages, and buttons
- Group data storage
- Get group info (title, chat_id, type)
- QR/Barcode scanning

## Methods

- `send_message(chat_id, text, keypad=None, inline_keypad=None, reply_to=None)` — Send text message
- `edit_message(chat_id, message_id, text, inline_keypad=None)` — Edit message with optional Inline Keypad
- `delete_message(chat_id, message_id)` — Delete message
- `send_poll(chat_id, question, options)` — Send poll
- `forward_message(from_chat_id, to_chat_id, message_id)` — Forward message
- `get_chat(chat_id)` — Get chat information
- `get_me()` — Get bot information
- `remove_keypad(chat_id)` — Remove Chat Keypad
- `edit_chat_keypad(chat_id, keypad)` — Edit Chat Keypad
- `set_commands(commands)` — Set bot commands
- `delete_commands()` — Delete all commands
- `get_updates(limit=10)` — Get updates
- `poll_updates(limit=10, sleep=1)` — Continuous updates generator
- `run()` — Start bot polling

## Webhook

- `set_webhook(url)` — Set webhook URL
- `delete_webhook()` — Delete webhook
- `get_webhook_info()` — Get webhook information
- `WebhookServer(bot, host="0.0.0.0", port=5000)` — Create aiohttp webhook server
- `server.run()` — Start webhook server
- `server.run_in_thread()` — Start webhook server in background thread

## Ban System

- `ban_user(user_id)` — Ban a user
- `unban_user(user_id)` — Unban a user
- `admin_ban(msg, user_id)` — Ban user by admin only
- `banned_users` — Set of banned user IDs

## Analytics

- `get_analytics(user_id=None)` — Get analytics for a user or all users
- `set_rate_limit(max_per_second=5, window=1)` — Set rate limit
- `set_cache_ttl(ttl)` — Set cache TTL in seconds

## File Methods (SendFile)

- `SendFile(bot)` — Create file sender
- `sendfile.request_send_file(file_type="Image")` — Request upload URL
- `sendfile.upload_file(upload_url, file_path)` — Upload file to server
- `sendfile.send_file(chat_id, file_id, text="")` — Send file to chat

## Handlers

- `@bot.command("name", pattern=None)` — Handle specific command with optional regex
- `@bot.on_message(pattern=None)` — Handle all messages with optional regex
- `@bot.on_button("button_id")` — Handle button clicks (Chat Keypad)

## Admin System

- `bot.ADMIN_ID` — Set admin by sender_id or chat_id
- `bot.ADMIN_PASSWORD` — Set admin by password
- `@bot.admin_command("name")` — Admin-only command
- `@bot.admin_on_message()` — Handle all admin messages
- `@bot.admin_on_button("button_id")` — Handle admin button clicks

## Group System

- `GroupBot(token, session_file=None)` — Create group-compatible bot
- `bot.set_group_handlers(handlers)` — Set group handlers
- `bot.get_group_info(chat_id)` — Get group info (title, chat_id, type)
- `GroupHandlers()` — Create group handlers

### Group Handlers

- `handlers.command("name", group_only=True)` — Command for group or both
- `handlers.on_message(group_only=True)` — Message handler for group or both
- `handlers.on_button("button_id", group_only=True)` — Button handler for group or both
- `handlers.set_data(group_id, key, value)` — Store group-specific data
- `handlers.get_data(group_id, key, default=None)` — Get group-specific data

### group_info Object

- `group_info['title']` — Group title
- `group_info['chat_id']` — Group ID
- `group_info['type']` — Chat type (Group)
- `group_info` is `None` in private chat

## Session

- `Session(session_file="session.json")` — Create session storage
- `session.set(user_id, key, value)` — Store user data
- `session.get(user_id, key, default=None)` — Get user data
- `session.delete(user_id, key=None)` — Delete user data
- `session.clear()` — Clear all session data

## Database (SQLite)

- `Database(db_path="rubkey.db")` — Create database connection
- `database.init()` — Initialize database tables
- `database.save_message(message_id, chat_id, sender_id, text, time)` — Save message
- `database.save_user(user_id, first_name, last_name, username, phone)` — Save user
- `database.get_messages(chat_id=None, limit=50)` — Get messages
- `database.get_user(user_id)` — Get user information

## Async Bot

- `AsyncBot(token, session_file=None)` — Create async bot
- `await bot.run()` — Start async bot polling
- `await bot.send_message(chat_id, text, ...)` — Send message async
- `@bot.command("name")` — Handle command async
- `@bot.on_message()` — Handle messages async

## Keypad Classes

- `Keypad(resize=True, one_time=False)` — Create Chat Keypad
- `keypad.add_row(*buttons)` — Add button row
- `KeyButton(button_id, text, button_type="Simple")` — Create Chat Keypad button
- `TextboxButton(button_id, text, type_line="SingleLine", type_keypad="String", place_holder="", title="")` — Create Textbox button
- `FileButton(button_id, text, file_type="File")` — Create file picker button
- `BarcodeButton(button_id, text)` — Create barcode scanner button
- `InlineKeypad()` — Create Inline Keypad
- `inline_keypad.add_row(*buttons)` — Add button row
- `InlineButton(button_id, text, button_type="Simple")` — Create Inline Keypad button

## Message Object

- `msg.text` — Message text
- `msg.chat_id` — Chat ID
- `msg.message_id` — Message ID
- `msg.sender_id` — Sender ID
- `msg.time` — Message time
- `msg.is_edited` — Edit status
- `msg.button_id` — Clicked button ID
- `msg.contact` — Contact information
- `msg.file` — File information (file_id, file_name, size)
- `msg.poll` — Poll information
- `msg.aux_data` — Auxiliary data
- `msg.reply_to_message_id` — Reply message ID
- `msg.reply(text, keypad=None, inline_keypad=None)` — Reply to message
- `msg.edit(text, inline_keypad=None)` — Edit message with optional Inline Keypad
- `msg.delete()` — Delete messaget.send_message("chat_id", "Choose an option:", chat_keypad=keypad, chat_keypad_type="New")
```

Remove chat keypad

```python
from rubkey import Rubkey

bot = Rubkey("YOUR_BOT_TOKEN")
bot.remove_chat_keypad("chat_id")
```

API Reference

Rubkey Class

Method Description
get_me() Get bot information
get_updates(limit=10) Get new updates
poll_updates(limit=10, sleep=1) Generator for continuous polling
send_message() Send text message with optional keypad and metadata
send_poll() Send poll
send_location() Send location
send_contact() Send contact
send_file() Send file
request_send_file(file_type) Get upload URL for file
upload_file(upload_url, file_path) Upload file to server
get_file(file_id) Get file download URL
get_chat(chat_id) Get chat information
delete_message(chat_id, message_id) Delete message
edit_message_text(chat_id, message_id, text) Edit message text
edit_message_keypad(chat_id, message_id, inline_keypad) Edit message keypad
forward_message(from_chat_id, to_chat_id, message_id) Forward message
ban_chat_member(chat_id, user_id) Ban user from group
unban_chat_member(chat_id, user_id) Unban user from group
set_commands(commands) Set bot commands
edit_chat_keypad(chat_id, chat_keypad, chat_keypad_type) Edit chat keypad
remove_chat_keypad(chat_id) Remove chat keypad
update_bot_endpoints(url, endpoint_type) Update webhook endpoints

License

MIT License (c) 2026 taha ansarianpour