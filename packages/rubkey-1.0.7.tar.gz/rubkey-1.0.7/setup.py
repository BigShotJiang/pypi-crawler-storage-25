from setuptools import setup, find_packages

try:
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()
except UnicodeDecodeError:
    with open("README.md", "r", encoding="utf-8", errors="ignore") as f:
        long_description = f.read()
except:
    long_description = ""

setup(
    name="rubkey",
    version="1.0.7",
    description="Rubika Bot API library - Simple and powerful bot framework for Rubika messenger",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/codetansarian",
    author="taha ansarianpour",
    author_email="codetansarian@gmail.com",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "requests>=2.20.0",
        "aiosqlite>=0.17.0",
        "aiohttp>=3.8.0",
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="rubika bot rubkey messenger api group file barcode ban async webhook",
)