class Message:
    def __init__(self, data, bot=None):
        self._data = data
        self._bot = bot
        self.chat_id = data.get("chat_id", "")
        self.text = data.get("text", "")
        self.message_id = data.get("message_id", "")
        self.sender_id = data.get("sender_id", "")
        self.time = data.get("time", 0)
        self.is_edited = data.get("is_edited", False)
        self.poll = data.get("poll")
        self.contact = data.get("contact_message")
        self.file = data.get("file")
        self.aux_data = data.get("aux_data", {})
        self.reply_to_message_id = data.get("reply_to_message_id", "")
    @property
    def button_id(self):
        return self.aux_data.get("button_id", "") if self.aux_data else ""
    def reply(self, text, keypad=None, inline_keypad=None):
        if self._bot:
            result = self._bot.send_message(self.chat_id, text, keypad=keypad, inline_keypad=inline_keypad, reply_to=self.message_id)
            result["chat_id"] = self.chat_id
            return Message(result, bot=self._bot)
    def edit(self, text, inline_keypad=None):
        if self._bot:
            return self._bot.edit_message(self.chat_id, self.message_id, text, inline_keypad=inline_keypad)
    def delete(self):
        if self._bot:
            return self._bot.delete_message(self.chat_id, self.message_id)
    def __repr__(self):
        return f"<Message id={self.message_id} text='{str(self.text)[:30]}'>"