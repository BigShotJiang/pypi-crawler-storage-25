from ..bot import Bot
from ..types import Message

class GroupBot(Bot):
    def __init__(self, token, session_file=None):
        super().__init__(token, session_file)
        self.group_handlers = None
        self.group_info = {}
    
    def set_group_handlers(self, handlers):
        self.group_handlers = handlers
    
    def _is_group(self, chat_id):
        return chat_id.startswith("g")
    
    def get_group_info(self, chat_id):
        if chat_id in self.group_info:
            return self.group_info[chat_id]
        result = self._api("getChat", {"chat_id": chat_id})
        data = result.get("data", result)
        chat = data.get("chat", data)
        info = {
            "chat_id": chat.get("chat_id", chat_id),
            "title": chat.get("title", "بدون نام"),
            "type": chat.get("chat_type", "Group")
        }
        self.group_info[chat_id] = info
        return info
    
    def _process_message(self, msg_data):
        msg = Message(msg_data, bot=self)
        text = (msg.text or "").strip()
        button_id = msg.button_id
        chat_id = msg.chat_id
        is_group = self._is_group(chat_id)
        if self.group_handlers:
            if is_group:
                if button_id and button_id in self.group_handlers.group_buttons:
                    btn = self.group_handlers.group_buttons[button_id]
                    btn["func"](msg, self.get_group_info(chat_id))
                    return
                if text.startswith("/"):
                    cmd = text[1:].split()[0]
                    if cmd in self.group_handlers.group_commands:
                        cmd_info = self.group_handlers.group_commands[cmd]
                        cmd_info["func"](msg, self.get_group_info(chat_id))
                        return
                if text in self.group_handlers.group_commands:
                    cmd_info = self.group_handlers.group_commands[text]
                    cmd_info["func"](msg, self.get_group_info(chat_id))
                    return
                if self.group_handlers.group_messages:
                    self.group_handlers.group_messages["func"](msg, self.get_group_info(chat_id))
                    return
            if not is_group:
                if text.startswith("/"):
                    cmd = text[1:].split()[0]
                    if cmd in self.group_handlers.group_commands:
                        cmd_info = self.group_handlers.group_commands[cmd]
                        if not cmd_info.get("group_only", True):
                            cmd_info["func"](msg, None)
                            return
                if text in self.group_handlers.group_commands:
                    cmd_info = self.group_handlers.group_commands[text]
                    if not cmd_info.get("group_only", True):
                        cmd_info["func"](msg, None)
                        return
                if self.group_handlers.group_messages:
                    if not self.group_handlers.group_messages.get("group_only", True):
                        self.group_handlers.group_messages["func"](msg, None)
                        return
        super()._process_message(msg_data)