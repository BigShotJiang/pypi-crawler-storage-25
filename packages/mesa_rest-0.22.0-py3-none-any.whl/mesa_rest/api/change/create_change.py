from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_change_body import CreateChangeBody
from ...models.create_change_response_201 import CreateChangeResponse201
from ...models.create_change_response_400 import CreateChangeResponse400
from ...models.create_change_response_401 import CreateChangeResponse401
from ...models.create_change_response_403 import CreateChangeResponse403
from ...models.create_change_response_404 import CreateChangeResponse404
from ...models.create_change_response_406 import CreateChangeResponse406
from ...models.create_change_response_409 import CreateChangeResponse409
from ...models.create_change_response_500 import CreateChangeResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    *,
    body: CreateChangeBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/{org}/{repo}/changes".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500 | None:
    if response.status_code == 201:
        response_201 = CreateChangeResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = CreateChangeResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = CreateChangeResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = CreateChangeResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = CreateChangeResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = CreateChangeResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = CreateChangeResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = CreateChangeResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChangeBody,

) -> Response[CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500]:
    """ Create change

     Create a new change on top of an existing base change, optionally applying initial file operations.
    File content must be base64-encoded.

    Args:
        org (str):
        repo (str):
        body (CreateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChangeBody,

) -> CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500 | None:
    """ Create change

     Create a new change on top of an existing base change, optionally applying initial file operations.
    File content must be base64-encoded.

    Args:
        org (str):
        repo (str):
        body (CreateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChangeBody,

) -> Response[CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500]:
    """ Create change

     Create a new change on top of an existing base change, optionally applying initial file operations.
    File content must be base64-encoded.

    Args:
        org (str):
        repo (str):
        body (CreateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChangeBody,

) -> CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500 | None:
    """ Create change

     Create a new change on top of an existing base change, optionally applying initial file operations.
    File content must be base64-encoded.

    Args:
        org (str):
        repo (str):
        body (CreateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateChangeResponse201 | CreateChangeResponse400 | CreateChangeResponse401 | CreateChangeResponse403 | CreateChangeResponse404 | CreateChangeResponse406 | CreateChangeResponse409 | CreateChangeResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    )).parsed
