from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_changes_response_200 import ListChangesResponse200
from ...models.list_changes_response_400 import ListChangesResponse400
from ...models.list_changes_response_401 import ListChangesResponse401
from ...models.list_changes_response_403 import ListChangesResponse403
from ...models.list_changes_response_404 import ListChangesResponse404
from ...models.list_changes_response_406 import ListChangesResponse406
from ...models.list_changes_response_409 import ListChangesResponse409
from ...models.list_changes_response_500 import ListChangesResponse500
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    *,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    bookmark: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["cursor"] = cursor

    params["limit"] = limit

    params["bookmark"] = bookmark


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/{repo}/changes".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500 | None:
    if response.status_code == 200:
        response_200 = ListChangesResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ListChangesResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ListChangesResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = ListChangesResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ListChangesResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = ListChangesResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = ListChangesResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = ListChangesResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    bookmark: str | Unset = UNSET,

) -> Response[ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500]:
    """ List changes

     List current reachable changes for a repository bookmark

    Args:
        org (str):
        repo (str):
        cursor (str | Unset):
        limit (int | Unset):
        bookmark (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
cursor=cursor,
limit=limit,
bookmark=bookmark,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    bookmark: str | Unset = UNSET,

) -> ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500 | None:
    """ List changes

     List current reachable changes for a repository bookmark

    Args:
        org (str):
        repo (str):
        cursor (str | Unset):
        limit (int | Unset):
        bookmark (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
client=client,
cursor=cursor,
limit=limit,
bookmark=bookmark,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    bookmark: str | Unset = UNSET,

) -> Response[ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500]:
    """ List changes

     List current reachable changes for a repository bookmark

    Args:
        org (str):
        repo (str):
        cursor (str | Unset):
        limit (int | Unset):
        bookmark (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
cursor=cursor,
limit=limit,
bookmark=bookmark,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    bookmark: str | Unset = UNSET,

) -> ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500 | None:
    """ List changes

     List current reachable changes for a repository bookmark

    Args:
        org (str):
        repo (str):
        cursor (str | Unset):
        limit (int | Unset):
        bookmark (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListChangesResponse200 | ListChangesResponse400 | ListChangesResponse401 | ListChangesResponse403 | ListChangesResponse404 | ListChangesResponse406 | ListChangesResponse409 | ListChangesResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
client=client,
cursor=cursor,
limit=limit,
bookmark=bookmark,

    )).parsed
