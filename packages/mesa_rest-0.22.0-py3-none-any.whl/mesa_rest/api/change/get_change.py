from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_change_response_200 import GetChangeResponse200
from ...models.get_change_response_400 import GetChangeResponse400
from ...models.get_change_response_401 import GetChangeResponse401
from ...models.get_change_response_403 import GetChangeResponse403
from ...models.get_change_response_404 import GetChangeResponse404
from ...models.get_change_response_406 import GetChangeResponse406
from ...models.get_change_response_409 import GetChangeResponse409
from ...models.get_change_response_500 import GetChangeResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    change_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/{repo}/changes/{change_id}".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),change_id=quote(str(change_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500 | None:
    if response.status_code == 200:
        response_200 = GetChangeResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = GetChangeResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = GetChangeResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = GetChangeResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = GetChangeResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = GetChangeResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = GetChangeResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = GetChangeResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500]:
    """ Get change

     Retrieve a specific change by its JJ change id

    Args:
        org (str):
        repo (str):
        change_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
change_id=change_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500 | None:
    """ Get change

     Retrieve a specific change by its JJ change id

    Args:
        org (str):
        repo (str):
        change_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
change_id=change_id,
client=client,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500]:
    """ Get change

     Retrieve a specific change by its JJ change id

    Args:
        org (str):
        repo (str):
        change_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
change_id=change_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500 | None:
    """ Get change

     Retrieve a specific change by its JJ change id

    Args:
        org (str):
        repo (str):
        change_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetChangeResponse200 | GetChangeResponse400 | GetChangeResponse401 | GetChangeResponse403 | GetChangeResponse404 | GetChangeResponse406 | GetChangeResponse409 | GetChangeResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
change_id=change_id,
client=client,

    )).parsed
