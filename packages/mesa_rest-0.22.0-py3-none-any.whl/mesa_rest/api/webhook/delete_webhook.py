from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_webhook_response_200 import DeleteWebhookResponse200
from ...models.delete_webhook_response_400 import DeleteWebhookResponse400
from ...models.delete_webhook_response_401 import DeleteWebhookResponse401
from ...models.delete_webhook_response_403 import DeleteWebhookResponse403
from ...models.delete_webhook_response_404 import DeleteWebhookResponse404
from ...models.delete_webhook_response_406 import DeleteWebhookResponse406
from ...models.delete_webhook_response_409 import DeleteWebhookResponse409
from ...models.delete_webhook_response_500 import DeleteWebhookResponse500
from typing import cast



def _get_kwargs(
    org: str,
    webhook_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/{org}/webhooks/{webhook_id}".format(org=quote(str(org), safe=""),webhook_id=quote(str(webhook_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500 | None:
    if response.status_code == 200:
        response_200 = DeleteWebhookResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = DeleteWebhookResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = DeleteWebhookResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = DeleteWebhookResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = DeleteWebhookResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = DeleteWebhookResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = DeleteWebhookResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = DeleteWebhookResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500]:
    """ Delete webhook

     Delete a webhook from the organization

    Args:
        org (str):
        webhook_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_id=webhook_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500 | None:
    """ Delete webhook

     Delete a webhook from the organization

    Args:
        org (str):
        webhook_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500
     """


    return sync_detailed(
        org=org,
webhook_id=webhook_id,
client=client,

    ).parsed

async def asyncio_detailed(
    org: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500]:
    """ Delete webhook

     Delete a webhook from the organization

    Args:
        org (str):
        webhook_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_id=webhook_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500 | None:
    """ Delete webhook

     Delete a webhook from the organization

    Args:
        org (str):
        webhook_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteWebhookResponse200 | DeleteWebhookResponse400 | DeleteWebhookResponse401 | DeleteWebhookResponse403 | DeleteWebhookResponse404 | DeleteWebhookResponse406 | DeleteWebhookResponse409 | DeleteWebhookResponse500
     """


    return (await asyncio_detailed(
        org=org,
webhook_id=webhook_id,
client=client,

    )).parsed
