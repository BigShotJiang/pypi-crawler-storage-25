from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_webhooks_response_200 import ListWebhooksResponse200
from ...models.list_webhooks_response_400 import ListWebhooksResponse400
from ...models.list_webhooks_response_401 import ListWebhooksResponse401
from ...models.list_webhooks_response_403 import ListWebhooksResponse403
from ...models.list_webhooks_response_404 import ListWebhooksResponse404
from ...models.list_webhooks_response_406 import ListWebhooksResponse406
from ...models.list_webhooks_response_409 import ListWebhooksResponse409
from ...models.list_webhooks_response_500 import ListWebhooksResponse500
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    org: str,
    *,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["cursor"] = cursor

    params["limit"] = limit


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/webhooks".format(org=quote(str(org), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500 | None:
    if response.status_code == 200:
        response_200 = ListWebhooksResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ListWebhooksResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ListWebhooksResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = ListWebhooksResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ListWebhooksResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = ListWebhooksResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = ListWebhooksResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = ListWebhooksResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> Response[ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500]:
    """ List webhooks

     List webhooks for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500 | None:
    """ List webhooks

     List webhooks for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500
     """


    return sync_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> Response[ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500]:
    """ List webhooks

     List webhooks for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500 | None:
    """ List webhooks

     List webhooks for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListWebhooksResponse200 | ListWebhooksResponse400 | ListWebhooksResponse401 | ListWebhooksResponse403 | ListWebhooksResponse404 | ListWebhooksResponse406 | ListWebhooksResponse409 | ListWebhooksResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,

    )).parsed
