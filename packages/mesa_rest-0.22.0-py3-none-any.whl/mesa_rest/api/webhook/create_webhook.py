from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_webhook_body import CreateWebhookBody
from ...models.create_webhook_response_201 import CreateWebhookResponse201
from ...models.create_webhook_response_400 import CreateWebhookResponse400
from ...models.create_webhook_response_401 import CreateWebhookResponse401
from ...models.create_webhook_response_403 import CreateWebhookResponse403
from ...models.create_webhook_response_404 import CreateWebhookResponse404
from ...models.create_webhook_response_406 import CreateWebhookResponse406
from ...models.create_webhook_response_409 import CreateWebhookResponse409
from ...models.create_webhook_response_500 import CreateWebhookResponse500
from typing import cast



def _get_kwargs(
    org: str,
    *,
    body: CreateWebhookBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/{org}/webhooks".format(org=quote(str(org), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500 | None:
    if response.status_code == 201:
        response_201 = CreateWebhookResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = CreateWebhookResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = CreateWebhookResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = CreateWebhookResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = CreateWebhookResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = CreateWebhookResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = CreateWebhookResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = CreateWebhookResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookBody,

) -> Response[CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500]:
    """ Create webhook

     Create a webhook for the organization

    Args:
        org (str):
        body (CreateWebhookBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookBody,

) -> CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500 | None:
    """ Create webhook

     Create a webhook for the organization

    Args:
        org (str):
        body (CreateWebhookBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500
     """


    return sync_detailed(
        org=org,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookBody,

) -> Response[CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500]:
    """ Create webhook

     Create a webhook for the organization

    Args:
        org (str):
        body (CreateWebhookBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookBody,

) -> CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500 | None:
    """ Create webhook

     Create a webhook for the organization

    Args:
        org (str):
        body (CreateWebhookBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateWebhookResponse201 | CreateWebhookResponse400 | CreateWebhookResponse401 | CreateWebhookResponse403 | CreateWebhookResponse404 | CreateWebhookResponse406 | CreateWebhookResponse409 | CreateWebhookResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
body=body,

    )).parsed
