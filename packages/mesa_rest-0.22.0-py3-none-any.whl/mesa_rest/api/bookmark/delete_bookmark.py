from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_bookmark_response_200 import DeleteBookmarkResponse200
from ...models.delete_bookmark_response_400 import DeleteBookmarkResponse400
from ...models.delete_bookmark_response_401 import DeleteBookmarkResponse401
from ...models.delete_bookmark_response_403 import DeleteBookmarkResponse403
from ...models.delete_bookmark_response_404 import DeleteBookmarkResponse404
from ...models.delete_bookmark_response_406 import DeleteBookmarkResponse406
from ...models.delete_bookmark_response_409 import DeleteBookmarkResponse409
from ...models.delete_bookmark_response_500 import DeleteBookmarkResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    bookmark: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/{org}/{repo}/bookmarks/{bookmark}".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),bookmark=quote(str(bookmark), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500 | None:
    if response.status_code == 200:
        response_200 = DeleteBookmarkResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = DeleteBookmarkResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = DeleteBookmarkResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = DeleteBookmarkResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = DeleteBookmarkResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = DeleteBookmarkResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = DeleteBookmarkResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = DeleteBookmarkResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500]:
    """ Delete bookmark

     Delete a bookmark from a repository

    Args:
        org (str):
        repo (str):
        bookmark (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
bookmark=bookmark,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500 | None:
    """ Delete bookmark

     Delete a bookmark from a repository

    Args:
        org (str):
        repo (str):
        bookmark (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
bookmark=bookmark,
client=client,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500]:
    """ Delete bookmark

     Delete a bookmark from a repository

    Args:
        org (str):
        repo (str):
        bookmark (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
bookmark=bookmark,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500 | None:
    """ Delete bookmark

     Delete a bookmark from a repository

    Args:
        org (str):
        repo (str):
        bookmark (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteBookmarkResponse200 | DeleteBookmarkResponse400 | DeleteBookmarkResponse401 | DeleteBookmarkResponse403 | DeleteBookmarkResponse404 | DeleteBookmarkResponse406 | DeleteBookmarkResponse409 | DeleteBookmarkResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
bookmark=bookmark,
client=client,

    )).parsed
