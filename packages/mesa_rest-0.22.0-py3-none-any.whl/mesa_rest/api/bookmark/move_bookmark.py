from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.move_bookmark_body import MoveBookmarkBody
from ...models.move_bookmark_response_200 import MoveBookmarkResponse200
from ...models.move_bookmark_response_400 import MoveBookmarkResponse400
from ...models.move_bookmark_response_401 import MoveBookmarkResponse401
from ...models.move_bookmark_response_403 import MoveBookmarkResponse403
from ...models.move_bookmark_response_404 import MoveBookmarkResponse404
from ...models.move_bookmark_response_406 import MoveBookmarkResponse406
from ...models.move_bookmark_response_409 import MoveBookmarkResponse409
from ...models.move_bookmark_response_500 import MoveBookmarkResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    bookmark: str,
    *,
    body: MoveBookmarkBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/{org}/{repo}/bookmarks/{bookmark}".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),bookmark=quote(str(bookmark), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500 | None:
    if response.status_code == 200:
        response_200 = MoveBookmarkResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = MoveBookmarkResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = MoveBookmarkResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = MoveBookmarkResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = MoveBookmarkResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = MoveBookmarkResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = MoveBookmarkResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = MoveBookmarkResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveBookmarkBody,

) -> Response[MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500]:
    """ Move bookmark

     Move an existing bookmark to a different change

    Args:
        org (str):
        repo (str):
        bookmark (str):
        body (MoveBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
bookmark=bookmark,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveBookmarkBody,

) -> MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500 | None:
    """ Move bookmark

     Move an existing bookmark to a different change

    Args:
        org (str):
        repo (str):
        bookmark (str):
        body (MoveBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
bookmark=bookmark,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveBookmarkBody,

) -> Response[MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500]:
    """ Move bookmark

     Move an existing bookmark to a different change

    Args:
        org (str):
        repo (str):
        bookmark (str):
        body (MoveBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
bookmark=bookmark,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    bookmark: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveBookmarkBody,

) -> MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500 | None:
    """ Move bookmark

     Move an existing bookmark to a different change

    Args:
        org (str):
        repo (str):
        bookmark (str):
        body (MoveBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MoveBookmarkResponse200 | MoveBookmarkResponse400 | MoveBookmarkResponse401 | MoveBookmarkResponse403 | MoveBookmarkResponse404 | MoveBookmarkResponse406 | MoveBookmarkResponse409 | MoveBookmarkResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
bookmark=bookmark,
client=client,
body=body,

    )).parsed
