from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_bookmark_body import CreateBookmarkBody
from ...models.create_bookmark_response_201 import CreateBookmarkResponse201
from ...models.create_bookmark_response_400 import CreateBookmarkResponse400
from ...models.create_bookmark_response_401 import CreateBookmarkResponse401
from ...models.create_bookmark_response_403 import CreateBookmarkResponse403
from ...models.create_bookmark_response_404 import CreateBookmarkResponse404
from ...models.create_bookmark_response_406 import CreateBookmarkResponse406
from ...models.create_bookmark_response_409 import CreateBookmarkResponse409
from ...models.create_bookmark_response_500 import CreateBookmarkResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    *,
    body: CreateBookmarkBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/{org}/{repo}/bookmarks".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500 | None:
    if response.status_code == 201:
        response_201 = CreateBookmarkResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = CreateBookmarkResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = CreateBookmarkResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = CreateBookmarkResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = CreateBookmarkResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = CreateBookmarkResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = CreateBookmarkResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = CreateBookmarkResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBookmarkBody,

) -> Response[CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500]:
    """ Create bookmark

     Create a new bookmark from an existing change id

    Args:
        org (str):
        repo (str):
        body (CreateBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBookmarkBody,

) -> CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500 | None:
    """ Create bookmark

     Create a new bookmark from an existing change id

    Args:
        org (str):
        repo (str):
        body (CreateBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBookmarkBody,

) -> Response[CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500]:
    """ Create bookmark

     Create a new bookmark from an existing change id

    Args:
        org (str):
        repo (str):
        body (CreateBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBookmarkBody,

) -> CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500 | None:
    """ Create bookmark

     Create a new bookmark from an existing change id

    Args:
        org (str):
        repo (str):
        body (CreateBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateBookmarkResponse201 | CreateBookmarkResponse400 | CreateBookmarkResponse401 | CreateBookmarkResponse403 | CreateBookmarkResponse404 | CreateBookmarkResponse406 | CreateBookmarkResponse409 | CreateBookmarkResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    )).parsed
