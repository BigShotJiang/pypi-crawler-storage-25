from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.merge_bookmark_body import MergeBookmarkBody
from ...models.merge_bookmark_response_200 import MergeBookmarkResponse200
from ...models.merge_bookmark_response_400 import MergeBookmarkResponse400
from ...models.merge_bookmark_response_401 import MergeBookmarkResponse401
from ...models.merge_bookmark_response_403 import MergeBookmarkResponse403
from ...models.merge_bookmark_response_404 import MergeBookmarkResponse404
from ...models.merge_bookmark_response_406 import MergeBookmarkResponse406
from ...models.merge_bookmark_response_409 import MergeBookmarkResponse409
from ...models.merge_bookmark_response_500 import MergeBookmarkResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    *,
    body: MergeBookmarkBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/{org}/{repo}/bookmarks/merge".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500 | None:
    if response.status_code == 200:
        response_200 = MergeBookmarkResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = MergeBookmarkResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = MergeBookmarkResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = MergeBookmarkResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = MergeBookmarkResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = MergeBookmarkResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = MergeBookmarkResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = MergeBookmarkResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: MergeBookmarkBody,

) -> Response[MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500]:
    """ Merge bookmarks

     Merge the source bookmark into the target bookmark. The target bookmark is advanced to the merge
    result.

    Args:
        org (str):
        repo (str):
        body (MergeBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: MergeBookmarkBody,

) -> MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500 | None:
    """ Merge bookmarks

     Merge the source bookmark into the target bookmark. The target bookmark is advanced to the merge
    result.

    Args:
        org (str):
        repo (str):
        body (MergeBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: MergeBookmarkBody,

) -> Response[MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500]:
    """ Merge bookmarks

     Merge the source bookmark into the target bookmark. The target bookmark is advanced to the merge
    result.

    Args:
        org (str):
        repo (str):
        body (MergeBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: MergeBookmarkBody,

) -> MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500 | None:
    """ Merge bookmarks

     Merge the source bookmark into the target bookmark. The target bookmark is advanced to the merge
    result.

    Args:
        org (str):
        repo (str):
        body (MergeBookmarkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MergeBookmarkResponse200 | MergeBookmarkResponse400 | MergeBookmarkResponse401 | MergeBookmarkResponse403 | MergeBookmarkResponse404 | MergeBookmarkResponse406 | MergeBookmarkResponse409 | MergeBookmarkResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    )).parsed
