from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.update_api_key_body import UpdateApiKeyBody
from ...models.update_api_key_response_200 import UpdateApiKeyResponse200
from ...models.update_api_key_response_400 import UpdateApiKeyResponse400
from ...models.update_api_key_response_401 import UpdateApiKeyResponse401
from ...models.update_api_key_response_403 import UpdateApiKeyResponse403
from ...models.update_api_key_response_404 import UpdateApiKeyResponse404
from ...models.update_api_key_response_406 import UpdateApiKeyResponse406
from ...models.update_api_key_response_409 import UpdateApiKeyResponse409
from ...models.update_api_key_response_500 import UpdateApiKeyResponse500
from typing import cast



def _get_kwargs(
    org: str,
    id: str,
    *,
    body: UpdateApiKeyBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/{org}/api-keys/{id}".format(org=quote(str(org), safe=""),id=quote(str(id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500 | None:
    if response.status_code == 200:
        response_200 = UpdateApiKeyResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = UpdateApiKeyResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = UpdateApiKeyResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = UpdateApiKeyResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = UpdateApiKeyResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = UpdateApiKeyResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = UpdateApiKeyResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = UpdateApiKeyResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateApiKeyBody,

) -> Response[UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500]:
    """ Update API key tags

     Add, update, or remove tags on an API key. Set a tag value to null to remove it.

    Args:
        org (str):
        id (str):
        body (UpdateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateApiKeyBody,

) -> UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500 | None:
    """ Update API key tags

     Add, update, or remove tags on an API key. Set a tag value to null to remove it.

    Args:
        org (str):
        id (str):
        body (UpdateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500
     """


    return sync_detailed(
        org=org,
id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateApiKeyBody,

) -> Response[UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500]:
    """ Update API key tags

     Add, update, or remove tags on an API key. Set a tag value to null to remove it.

    Args:
        org (str):
        id (str):
        body (UpdateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateApiKeyBody,

) -> UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500 | None:
    """ Update API key tags

     Add, update, or remove tags on an API key. Set a tag value to null to remove it.

    Args:
        org (str):
        id (str):
        body (UpdateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateApiKeyResponse200 | UpdateApiKeyResponse400 | UpdateApiKeyResponse401 | UpdateApiKeyResponse403 | UpdateApiKeyResponse404 | UpdateApiKeyResponse406 | UpdateApiKeyResponse409 | UpdateApiKeyResponse500
     """


    return (await asyncio_detailed(
        org=org,
id=id,
client=client,
body=body,

    )).parsed
