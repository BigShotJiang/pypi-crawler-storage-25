from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_api_keys_response_200 import ListApiKeysResponse200
from ...models.list_api_keys_response_400 import ListApiKeysResponse400
from ...models.list_api_keys_response_401 import ListApiKeysResponse401
from ...models.list_api_keys_response_403 import ListApiKeysResponse403
from ...models.list_api_keys_response_404 import ListApiKeysResponse404
from ...models.list_api_keys_response_406 import ListApiKeysResponse406
from ...models.list_api_keys_response_409 import ListApiKeysResponse409
from ...models.list_api_keys_response_500 import ListApiKeysResponse500
from ...models.list_api_keys_scope import ListApiKeysScope
from ...models.list_api_keys_status import ListApiKeysStatus
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    org: str,
    *,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    query: str | Unset = UNSET,
    status: ListApiKeysStatus | Unset = ListApiKeysStatus.ALL,
    scope: ListApiKeysScope | Unset = UNSET,
    repo_id: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["cursor"] = cursor

    params["limit"] = limit

    params["query"] = query

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    json_scope: str | Unset = UNSET
    if not isinstance(scope, Unset):
        json_scope = scope.value

    params["scope"] = json_scope

    params["repo_id"] = repo_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/api-keys".format(org=quote(str(org), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500 | None:
    if response.status_code == 200:
        response_200 = ListApiKeysResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ListApiKeysResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ListApiKeysResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = ListApiKeysResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ListApiKeysResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = ListApiKeysResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = ListApiKeysResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = ListApiKeysResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    query: str | Unset = UNSET,
    status: ListApiKeysStatus | Unset = ListApiKeysStatus.ALL,
    scope: ListApiKeysScope | Unset = UNSET,
    repo_id: str | Unset = UNSET,

) -> Response[ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500]:
    """ List API keys

     List all API keys for the organization (key values are not returned)

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        query (str | Unset):
        status (ListApiKeysStatus | Unset):  Default: ListApiKeysStatus.ALL.
        scope (ListApiKeysScope | Unset):
        repo_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,
query=query,
status=status,
scope=scope,
repo_id=repo_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    query: str | Unset = UNSET,
    status: ListApiKeysStatus | Unset = ListApiKeysStatus.ALL,
    scope: ListApiKeysScope | Unset = UNSET,
    repo_id: str | Unset = UNSET,

) -> ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500 | None:
    """ List API keys

     List all API keys for the organization (key values are not returned)

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        query (str | Unset):
        status (ListApiKeysStatus | Unset):  Default: ListApiKeysStatus.ALL.
        scope (ListApiKeysScope | Unset):
        repo_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500
     """


    return sync_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,
query=query,
status=status,
scope=scope,
repo_id=repo_id,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    query: str | Unset = UNSET,
    status: ListApiKeysStatus | Unset = ListApiKeysStatus.ALL,
    scope: ListApiKeysScope | Unset = UNSET,
    repo_id: str | Unset = UNSET,

) -> Response[ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500]:
    """ List API keys

     List all API keys for the organization (key values are not returned)

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        query (str | Unset):
        status (ListApiKeysStatus | Unset):  Default: ListApiKeysStatus.ALL.
        scope (ListApiKeysScope | Unset):
        repo_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,
query=query,
status=status,
scope=scope,
repo_id=repo_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    query: str | Unset = UNSET,
    status: ListApiKeysStatus | Unset = ListApiKeysStatus.ALL,
    scope: ListApiKeysScope | Unset = UNSET,
    repo_id: str | Unset = UNSET,

) -> ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500 | None:
    """ List API keys

     List all API keys for the organization (key values are not returned)

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        query (str | Unset):
        status (ListApiKeysStatus | Unset):  Default: ListApiKeysStatus.ALL.
        scope (ListApiKeysScope | Unset):
        repo_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListApiKeysResponse200 | ListApiKeysResponse400 | ListApiKeysResponse401 | ListApiKeysResponse403 | ListApiKeysResponse404 | ListApiKeysResponse406 | ListApiKeysResponse409 | ListApiKeysResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,
query=query,
status=status,
scope=scope,
repo_id=repo_id,

    )).parsed
