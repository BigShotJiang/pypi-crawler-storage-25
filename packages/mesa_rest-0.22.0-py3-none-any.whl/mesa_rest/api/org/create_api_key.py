from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_api_key_body import CreateApiKeyBody
from ...models.create_api_key_response_201 import CreateApiKeyResponse201
from ...models.create_api_key_response_400 import CreateApiKeyResponse400
from ...models.create_api_key_response_401 import CreateApiKeyResponse401
from ...models.create_api_key_response_403 import CreateApiKeyResponse403
from ...models.create_api_key_response_404 import CreateApiKeyResponse404
from ...models.create_api_key_response_406 import CreateApiKeyResponse406
from ...models.create_api_key_response_409 import CreateApiKeyResponse409
from ...models.create_api_key_response_500 import CreateApiKeyResponse500
from typing import cast



def _get_kwargs(
    org: str,
    *,
    body: CreateApiKeyBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/{org}/api-keys".format(org=quote(str(org), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500 | None:
    if response.status_code == 201:
        response_201 = CreateApiKeyResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = CreateApiKeyResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = CreateApiKeyResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = CreateApiKeyResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = CreateApiKeyResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = CreateApiKeyResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = CreateApiKeyResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = CreateApiKeyResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyBody,

) -> Response[CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500]:
    """ Create API key

     Create a new API key for programmatic access

    Args:
        org (str):
        body (CreateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyBody,

) -> CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500 | None:
    """ Create API key

     Create a new API key for programmatic access

    Args:
        org (str):
        body (CreateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500
     """


    return sync_detailed(
        org=org,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyBody,

) -> Response[CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500]:
    """ Create API key

     Create a new API key for programmatic access

    Args:
        org (str):
        body (CreateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyBody,

) -> CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500 | None:
    """ Create API key

     Create a new API key for programmatic access

    Args:
        org (str):
        body (CreateApiKeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateApiKeyResponse201 | CreateApiKeyResponse400 | CreateApiKeyResponse401 | CreateApiKeyResponse403 | CreateApiKeyResponse404 | CreateApiKeyResponse406 | CreateApiKeyResponse409 | CreateApiKeyResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
body=body,

    )).parsed
