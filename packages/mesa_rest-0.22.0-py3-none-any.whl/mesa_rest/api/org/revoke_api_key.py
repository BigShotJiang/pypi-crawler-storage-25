from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.revoke_api_key_response_200 import RevokeApiKeyResponse200
from ...models.revoke_api_key_response_400 import RevokeApiKeyResponse400
from ...models.revoke_api_key_response_401 import RevokeApiKeyResponse401
from ...models.revoke_api_key_response_403 import RevokeApiKeyResponse403
from ...models.revoke_api_key_response_404 import RevokeApiKeyResponse404
from ...models.revoke_api_key_response_406 import RevokeApiKeyResponse406
from ...models.revoke_api_key_response_409 import RevokeApiKeyResponse409
from ...models.revoke_api_key_response_500 import RevokeApiKeyResponse500
from typing import cast



def _get_kwargs(
    org: str,
    id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/{org}/api-keys/{id}".format(org=quote(str(org), safe=""),id=quote(str(id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500 | None:
    if response.status_code == 200:
        response_200 = RevokeApiKeyResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = RevokeApiKeyResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = RevokeApiKeyResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = RevokeApiKeyResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = RevokeApiKeyResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = RevokeApiKeyResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = RevokeApiKeyResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = RevokeApiKeyResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500]:
    """ Revoke API key

     Revoke an API key by its ID

    Args:
        org (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
id=id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,

) -> RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500 | None:
    """ Revoke API key

     Revoke an API key by its ID

    Args:
        org (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500
     """


    return sync_detailed(
        org=org,
id=id,
client=client,

    ).parsed

async def asyncio_detailed(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500]:
    """ Revoke API key

     Revoke an API key by its ID

    Args:
        org (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
id=id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,

) -> RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500 | None:
    """ Revoke API key

     Revoke an API key by its ID

    Args:
        org (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeApiKeyResponse200 | RevokeApiKeyResponse400 | RevokeApiKeyResponse401 | RevokeApiKeyResponse403 | RevokeApiKeyResponse404 | RevokeApiKeyResponse406 | RevokeApiKeyResponse409 | RevokeApiKeyResponse500
     """


    return (await asyncio_detailed(
        org=org,
id=id,
client=client,

    )).parsed
