from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.whoami_response_200 import WhoamiResponse200
from ...models.whoami_response_400 import WhoamiResponse400
from ...models.whoami_response_401 import WhoamiResponse401
from ...models.whoami_response_403 import WhoamiResponse403
from ...models.whoami_response_404 import WhoamiResponse404
from ...models.whoami_response_406 import WhoamiResponse406
from ...models.whoami_response_409 import WhoamiResponse409
from ...models.whoami_response_500 import WhoamiResponse500
from typing import cast



def _get_kwargs(
    
) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/whoami",
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500 | None:
    if response.status_code == 200:
        response_200 = WhoamiResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = WhoamiResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = WhoamiResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = WhoamiResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = WhoamiResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = WhoamiResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = WhoamiResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = WhoamiResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500]:
    """ Get caller identity

     Get the authenticated organization, effective scopes, and API key metadata

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500]
     """


    kwargs = _get_kwargs(
        
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,

) -> WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500 | None:
    """ Get caller identity

     Get the authenticated organization, effective scopes, and API key metadata

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500
     """


    return sync_detailed(
        client=client,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500]:
    """ Get caller identity

     Get the authenticated organization, effective scopes, and API key metadata

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500]
     """


    kwargs = _get_kwargs(
        
    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,

) -> WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500 | None:
    """ Get caller identity

     Get the authenticated organization, effective scopes, and API key metadata

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WhoamiResponse200 | WhoamiResponse400 | WhoamiResponse401 | WhoamiResponse403 | WhoamiResponse404 | WhoamiResponse406 | WhoamiResponse409 | WhoamiResponse500
     """


    return (await asyncio_detailed(
        client=client,

    )).parsed
