from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.update_repo_body import UpdateRepoBody
from ...models.update_repo_response_200 import UpdateRepoResponse200
from ...models.update_repo_response_400 import UpdateRepoResponse400
from ...models.update_repo_response_401 import UpdateRepoResponse401
from ...models.update_repo_response_403 import UpdateRepoResponse403
from ...models.update_repo_response_404 import UpdateRepoResponse404
from ...models.update_repo_response_406 import UpdateRepoResponse406
from ...models.update_repo_response_409 import UpdateRepoResponse409
from ...models.update_repo_response_500 import UpdateRepoResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    *,
    body: UpdateRepoBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/{org}/{repo}".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500 | None:
    if response.status_code == 200:
        response_200 = UpdateRepoResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = UpdateRepoResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = UpdateRepoResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = UpdateRepoResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = UpdateRepoResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = UpdateRepoResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = UpdateRepoResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = UpdateRepoResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateRepoBody,

) -> Response[UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500]:
    """ Update repository

     Update repository name, default bookmark, or tags. Tags are patched: omitted keys are unchanged,
    string values add or update a tag, and null values remove a tag.

    Args:
        org (str):
        repo (str):
        body (UpdateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateRepoBody,

) -> UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500 | None:
    """ Update repository

     Update repository name, default bookmark, or tags. Tags are patched: omitted keys are unchanged,
    string values add or update a tag, and null values remove a tag.

    Args:
        org (str):
        repo (str):
        body (UpdateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateRepoBody,

) -> Response[UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500]:
    """ Update repository

     Update repository name, default bookmark, or tags. Tags are patched: omitted keys are unchanged,
    string values add or update a tag, and null values remove a tag.

    Args:
        org (str):
        repo (str):
        body (UpdateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateRepoBody,

) -> UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500 | None:
    """ Update repository

     Update repository name, default bookmark, or tags. Tags are patched: omitted keys are unchanged,
    string values add or update a tag, and null values remove a tag.

    Args:
        org (str):
        repo (str):
        body (UpdateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateRepoResponse200 | UpdateRepoResponse400 | UpdateRepoResponse401 | UpdateRepoResponse403 | UpdateRepoResponse404 | UpdateRepoResponse406 | UpdateRepoResponse409 | UpdateRepoResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
client=client,
body=body,

    )).parsed
