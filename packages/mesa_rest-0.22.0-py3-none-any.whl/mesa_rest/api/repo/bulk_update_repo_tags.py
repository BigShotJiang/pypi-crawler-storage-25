from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.bulk_update_repo_tags_body import BulkUpdateRepoTagsBody
from ...models.bulk_update_repo_tags_response_200 import BulkUpdateRepoTagsResponse200
from ...models.bulk_update_repo_tags_response_400 import BulkUpdateRepoTagsResponse400
from ...models.bulk_update_repo_tags_response_401 import BulkUpdateRepoTagsResponse401
from ...models.bulk_update_repo_tags_response_403 import BulkUpdateRepoTagsResponse403
from ...models.bulk_update_repo_tags_response_404 import BulkUpdateRepoTagsResponse404
from ...models.bulk_update_repo_tags_response_406 import BulkUpdateRepoTagsResponse406
from ...models.bulk_update_repo_tags_response_409 import BulkUpdateRepoTagsResponse409
from ...models.bulk_update_repo_tags_response_500 import BulkUpdateRepoTagsResponse500
from typing import cast



def _get_kwargs(
    org: str,
    *,
    body: BulkUpdateRepoTagsBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/{org}/repos/tags".format(org=quote(str(org), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500 | None:
    if response.status_code == 200:
        response_200 = BulkUpdateRepoTagsResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = BulkUpdateRepoTagsResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = BulkUpdateRepoTagsResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = BulkUpdateRepoTagsResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = BulkUpdateRepoTagsResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = BulkUpdateRepoTagsResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = BulkUpdateRepoTagsResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = BulkUpdateRepoTagsResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: BulkUpdateRepoTagsBody,

) -> Response[BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500]:
    """ Bulk update tags

     Bulk set or remove a tag across repositories. This operation is idempotent.

    Args:
        org (str):
        body (BulkUpdateRepoTagsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: BulkUpdateRepoTagsBody,

) -> BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500 | None:
    """ Bulk update tags

     Bulk set or remove a tag across repositories. This operation is idempotent.

    Args:
        org (str):
        body (BulkUpdateRepoTagsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500
     """


    return sync_detailed(
        org=org,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: BulkUpdateRepoTagsBody,

) -> Response[BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500]:
    """ Bulk update tags

     Bulk set or remove a tag across repositories. This operation is idempotent.

    Args:
        org (str):
        body (BulkUpdateRepoTagsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: BulkUpdateRepoTagsBody,

) -> BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500 | None:
    """ Bulk update tags

     Bulk set or remove a tag across repositories. This operation is idempotent.

    Args:
        org (str):
        body (BulkUpdateRepoTagsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BulkUpdateRepoTagsResponse200 | BulkUpdateRepoTagsResponse400 | BulkUpdateRepoTagsResponse401 | BulkUpdateRepoTagsResponse403 | BulkUpdateRepoTagsResponse404 | BulkUpdateRepoTagsResponse406 | BulkUpdateRepoTagsResponse409 | BulkUpdateRepoTagsResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
body=body,

    )).parsed
