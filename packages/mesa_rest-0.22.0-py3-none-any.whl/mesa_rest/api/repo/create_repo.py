from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_repo_body import CreateRepoBody
from ...models.create_repo_response_201 import CreateRepoResponse201
from ...models.create_repo_response_400 import CreateRepoResponse400
from ...models.create_repo_response_401 import CreateRepoResponse401
from ...models.create_repo_response_403 import CreateRepoResponse403
from ...models.create_repo_response_404 import CreateRepoResponse404
from ...models.create_repo_response_406 import CreateRepoResponse406
from ...models.create_repo_response_409 import CreateRepoResponse409
from ...models.create_repo_response_500 import CreateRepoResponse500
from typing import cast



def _get_kwargs(
    org: str,
    *,
    body: CreateRepoBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/{org}/repos".format(org=quote(str(org), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500 | None:
    if response.status_code == 201:
        response_201 = CreateRepoResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = CreateRepoResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = CreateRepoResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = CreateRepoResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = CreateRepoResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = CreateRepoResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = CreateRepoResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = CreateRepoResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateRepoBody,

) -> Response[CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500]:
    """ Create repository

     Create a new repository in the organization

    Args:
        org (str):
        body (CreateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateRepoBody,

) -> CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500 | None:
    """ Create repository

     Create a new repository in the organization

    Args:
        org (str):
        body (CreateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500
     """


    return sync_detailed(
        org=org,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateRepoBody,

) -> Response[CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500]:
    """ Create repository

     Create a new repository in the organization

    Args:
        org (str):
        body (CreateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateRepoBody,

) -> CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500 | None:
    """ Create repository

     Create a new repository in the organization

    Args:
        org (str):
        body (CreateRepoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateRepoResponse201 | CreateRepoResponse400 | CreateRepoResponse401 | CreateRepoResponse403 | CreateRepoResponse404 | CreateRepoResponse406 | CreateRepoResponse409 | CreateRepoResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
body=body,

    )).parsed
