from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_repos_response_200 import ListReposResponse200
from ...models.list_repos_response_400 import ListReposResponse400
from ...models.list_repos_response_401 import ListReposResponse401
from ...models.list_repos_response_403 import ListReposResponse403
from ...models.list_repos_response_404 import ListReposResponse404
from ...models.list_repos_response_406 import ListReposResponse406
from ...models.list_repos_response_409 import ListReposResponse409
from ...models.list_repos_response_500 import ListReposResponse500
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    org: str,
    *,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    tags: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["cursor"] = cursor

    params["limit"] = limit

    params["tags"] = tags


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/repos".format(org=quote(str(org), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500 | None:
    if response.status_code == 200:
        response_200 = ListReposResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ListReposResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ListReposResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = ListReposResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ListReposResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = ListReposResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = ListReposResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = ListReposResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    tags: str | Unset = UNSET,

) -> Response[ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500]:
    """ List repositories

     List repositories in the organization using cursor pagination

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        tags (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,
tags=tags,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    tags: str | Unset = UNSET,

) -> ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500 | None:
    """ List repositories

     List repositories in the organization using cursor pagination

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        tags (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500
     """


    return sync_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,
tags=tags,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    tags: str | Unset = UNSET,

) -> Response[ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500]:
    """ List repositories

     List repositories in the organization using cursor pagination

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        tags (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,
tags=tags,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    tags: str | Unset = UNSET,

) -> ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500 | None:
    """ List repositories

     List repositories in the organization using cursor pagination

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):
        tags (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListReposResponse200 | ListReposResponse400 | ListReposResponse401 | ListReposResponse403 | ListReposResponse404 | ListReposResponse406 | ListReposResponse409 | ListReposResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,
tags=tags,

    )).parsed
