from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_repo_response_200 import DeleteRepoResponse200
from ...models.delete_repo_response_400 import DeleteRepoResponse400
from ...models.delete_repo_response_401 import DeleteRepoResponse401
from ...models.delete_repo_response_403 import DeleteRepoResponse403
from ...models.delete_repo_response_404 import DeleteRepoResponse404
from ...models.delete_repo_response_406 import DeleteRepoResponse406
from ...models.delete_repo_response_409 import DeleteRepoResponse409
from ...models.delete_repo_response_500 import DeleteRepoResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/{org}/{repo}".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500 | None:
    if response.status_code == 200:
        response_200 = DeleteRepoResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = DeleteRepoResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = DeleteRepoResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = DeleteRepoResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = DeleteRepoResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = DeleteRepoResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = DeleteRepoResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = DeleteRepoResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500]:
    """ Delete repository

     Permanently delete a repository and all its data

    Args:
        org (str):
        repo (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500 | None:
    """ Delete repository

     Permanently delete a repository and all its data

    Args:
        org (str):
        repo (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
client=client,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500]:
    """ Delete repository

     Permanently delete a repository and all its data

    Args:
        org (str):
        repo (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500 | None:
    """ Delete repository

     Permanently delete a repository and all its data

    Args:
        org (str):
        repo (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteRepoResponse200 | DeleteRepoResponse400 | DeleteRepoResponse401 | DeleteRepoResponse403 | DeleteRepoResponse404 | DeleteRepoResponse406 | DeleteRepoResponse409 | DeleteRepoResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
client=client,

    )).parsed
