from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.list_api_keys_response_200_api_keys_item import ListApiKeysResponse200ApiKeysItem





T = TypeVar("T", bound="ListApiKeysResponse200")



@_attrs_define
class ListApiKeysResponse200:
    """ 
        Attributes:
            next_cursor (None | str): Cursor for the next page, or null when no more results remain
            has_more (bool): Whether another page of results is available
            api_keys (list[ListApiKeysResponse200ApiKeysItem]):
     """

    next_cursor: None | str
    has_more: bool
    api_keys: list[ListApiKeysResponse200ApiKeysItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.list_api_keys_response_200_api_keys_item import ListApiKeysResponse200ApiKeysItem
        next_cursor: None | str
        next_cursor = self.next_cursor

        has_more = self.has_more

        api_keys = []
        for api_keys_item_data in self.api_keys:
            api_keys_item = api_keys_item_data.to_dict()
            api_keys.append(api_keys_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "next_cursor": next_cursor,
            "has_more": has_more,
            "api_keys": api_keys,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_api_keys_response_200_api_keys_item import ListApiKeysResponse200ApiKeysItem
        d = dict(src_dict)
        def _parse_next_cursor(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        next_cursor = _parse_next_cursor(d.pop("next_cursor"))


        has_more = d.pop("has_more")

        api_keys = []
        _api_keys = d.pop("api_keys")
        for api_keys_item_data in (_api_keys):
            api_keys_item = ListApiKeysResponse200ApiKeysItem.from_dict(api_keys_item_data)



            api_keys.append(api_keys_item)


        list_api_keys_response_200 = cls(
            next_cursor=next_cursor,
            has_more=has_more,
            api_keys=api_keys,
        )


        list_api_keys_response_200.additional_properties = d
        return list_api_keys_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
