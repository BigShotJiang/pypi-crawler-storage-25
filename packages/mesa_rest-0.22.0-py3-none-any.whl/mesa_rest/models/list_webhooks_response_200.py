from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.list_webhooks_response_200_webhooks_item import ListWebhooksResponse200WebhooksItem





T = TypeVar("T", bound="ListWebhooksResponse200")



@_attrs_define
class ListWebhooksResponse200:
    """ 
        Attributes:
            next_cursor (None | str): Cursor for the next page, or null when no more results remain
            has_more (bool): Whether another page of results is available
            webhooks (list[ListWebhooksResponse200WebhooksItem]):
     """

    next_cursor: None | str
    has_more: bool
    webhooks: list[ListWebhooksResponse200WebhooksItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.list_webhooks_response_200_webhooks_item import ListWebhooksResponse200WebhooksItem
        next_cursor: None | str
        next_cursor = self.next_cursor

        has_more = self.has_more

        webhooks = []
        for webhooks_item_data in self.webhooks:
            webhooks_item = webhooks_item_data.to_dict()
            webhooks.append(webhooks_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "next_cursor": next_cursor,
            "has_more": has_more,
            "webhooks": webhooks,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_webhooks_response_200_webhooks_item import ListWebhooksResponse200WebhooksItem
        d = dict(src_dict)
        def _parse_next_cursor(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        next_cursor = _parse_next_cursor(d.pop("next_cursor"))


        has_more = d.pop("has_more")

        webhooks = []
        _webhooks = d.pop("webhooks")
        for webhooks_item_data in (_webhooks):
            webhooks_item = ListWebhooksResponse200WebhooksItem.from_dict(webhooks_item_data)



            webhooks.append(webhooks_item)


        list_webhooks_response_200 = cls(
            next_cursor=next_cursor,
            has_more=has_more,
            webhooks=webhooks,
        )


        list_webhooks_response_200.additional_properties = d
        return list_webhooks_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
