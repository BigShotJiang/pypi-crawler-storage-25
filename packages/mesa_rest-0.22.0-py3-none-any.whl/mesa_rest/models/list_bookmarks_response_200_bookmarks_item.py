from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ListBookmarksResponse200BookmarksItem")



@_attrs_define
class ListBookmarksResponse200BookmarksItem:
    """ 
        Attributes:
            name (str):
            change_id (str): Change id the bookmark points to. When a bookmark points at the empty tree this is the virtual
                root change id (zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz).
            is_default (bool):
     """

    name: str
    change_id: str
    is_default: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        change_id = self.change_id

        is_default = self.is_default


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "change_id": change_id,
            "is_default": is_default,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        change_id = d.pop("change_id")

        is_default = d.pop("is_default")

        list_bookmarks_response_200_bookmarks_item = cls(
            name=name,
            change_id=change_id,
            is_default=is_default,
        )


        list_bookmarks_response_200_bookmarks_item.additional_properties = d
        return list_bookmarks_response_200_bookmarks_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
