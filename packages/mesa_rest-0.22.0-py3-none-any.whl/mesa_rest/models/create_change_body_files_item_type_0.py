from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_change_body_files_item_type_0_mode import CreateChangeBodyFilesItemType0Mode
from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="CreateChangeBodyFilesItemType0")



@_attrs_define
class CreateChangeBodyFilesItemType0:
    """ 
        Attributes:
            path (str):
            content (str):
            encoding (Literal['base64'] | Unset):  Default: 'base64'.
            action (Literal['upsert'] | Unset):
            mode (CreateChangeBodyFilesItemType0Mode | Unset):
     """

    path: str
    content: str
    encoding: Literal['base64'] | Unset = 'base64'
    action: Literal['upsert'] | Unset = UNSET
    mode: CreateChangeBodyFilesItemType0Mode | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        path = self.path

        content = self.content

        encoding = self.encoding

        action = self.action

        mode: str | Unset = UNSET
        if not isinstance(self.mode, Unset):
            mode = self.mode.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "path": path,
            "content": content,
        })
        if encoding is not UNSET:
            field_dict["encoding"] = encoding
        if action is not UNSET:
            field_dict["action"] = action
        if mode is not UNSET:
            field_dict["mode"] = mode

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        path = d.pop("path")

        content = d.pop("content")

        encoding = cast(Literal['base64'] | Unset , d.pop("encoding", UNSET))
        if encoding != 'base64'and not isinstance(encoding, Unset):
            raise ValueError(f"encoding must match const 'base64', got '{encoding}'")

        action = cast(Literal['upsert'] | Unset , d.pop("action", UNSET))
        if action != 'upsert'and not isinstance(action, Unset):
            raise ValueError(f"action must match const 'upsert', got '{action}'")

        _mode = d.pop("mode", UNSET)
        mode: CreateChangeBodyFilesItemType0Mode | Unset
        if isinstance(_mode,  Unset):
            mode = UNSET
        else:
            mode = CreateChangeBodyFilesItemType0Mode(_mode)




        create_change_body_files_item_type_0 = cls(
            path=path,
            content=content,
            encoding=encoding,
            action=action,
            mode=mode,
        )


        create_change_body_files_item_type_0.additional_properties = d
        return create_change_body_files_item_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
