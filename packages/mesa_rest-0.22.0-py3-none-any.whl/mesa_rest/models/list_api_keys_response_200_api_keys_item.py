from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.list_api_keys_response_200_api_keys_item_metadata_type_0 import ListApiKeysResponse200ApiKeysItemMetadataType0
  from ..models.list_api_keys_response_200_api_keys_item_tags import ListApiKeysResponse200ApiKeysItemTags





T = TypeVar("T", bound="ListApiKeysResponse200ApiKeysItem")



@_attrs_define
class ListApiKeysResponse200ApiKeysItem:
    """ 
        Attributes:
            id (str):
            name (None | str):
            scopes (list[str]):
            repo_ids (list[str] | None):
            metadata (ListApiKeysResponse200ApiKeysItemMetadataType0 | None):
            tags (ListApiKeysResponse200ApiKeysItemTags):
            last_used_at (datetime.datetime | None):
            expires_at (datetime.datetime | None):
            revoked_at (datetime.datetime | None):
            created_at (datetime.datetime):
     """

    id: str
    name: None | str
    scopes: list[str]
    repo_ids: list[str] | None
    metadata: ListApiKeysResponse200ApiKeysItemMetadataType0 | None
    tags: ListApiKeysResponse200ApiKeysItemTags
    last_used_at: datetime.datetime | None
    expires_at: datetime.datetime | None
    revoked_at: datetime.datetime | None
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.list_api_keys_response_200_api_keys_item_metadata_type_0 import ListApiKeysResponse200ApiKeysItemMetadataType0
        from ..models.list_api_keys_response_200_api_keys_item_tags import ListApiKeysResponse200ApiKeysItemTags
        id = self.id

        name: None | str
        name = self.name

        scopes = self.scopes



        repo_ids: list[str] | None
        if isinstance(self.repo_ids, list):
            repo_ids = self.repo_ids


        else:
            repo_ids = self.repo_ids

        metadata: dict[str, Any] | None
        if isinstance(self.metadata, ListApiKeysResponse200ApiKeysItemMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        tags = self.tags.to_dict()

        last_used_at: None | str
        if isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        expires_at: None | str
        if isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        revoked_at: None | str
        if isinstance(self.revoked_at, datetime.datetime):
            revoked_at = self.revoked_at.isoformat()
        else:
            revoked_at = self.revoked_at

        created_at = self.created_at.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "scopes": scopes,
            "repo_ids": repo_ids,
            "metadata": metadata,
            "tags": tags,
            "last_used_at": last_used_at,
            "expires_at": expires_at,
            "revoked_at": revoked_at,
            "created_at": created_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_api_keys_response_200_api_keys_item_metadata_type_0 import ListApiKeysResponse200ApiKeysItemMetadataType0
        from ..models.list_api_keys_response_200_api_keys_item_tags import ListApiKeysResponse200ApiKeysItemTags
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        name = _parse_name(d.pop("name"))


        scopes = cast(list[str], d.pop("scopes"))


        def _parse_repo_ids(data: object) -> list[str] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                repo_ids_type_0 = cast(list[str], data)

                return repo_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None, data)

        repo_ids = _parse_repo_ids(d.pop("repo_ids"))


        def _parse_metadata(data: object) -> ListApiKeysResponse200ApiKeysItemMetadataType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = ListApiKeysResponse200ApiKeysItemMetadataType0.from_dict(data)



                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ListApiKeysResponse200ApiKeysItemMetadataType0 | None, data)

        metadata = _parse_metadata(d.pop("metadata"))


        tags = ListApiKeysResponse200ApiKeysItemTags.from_dict(d.pop("tags"))




        def _parse_last_used_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = isoparse(data)



                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at"))


        def _parse_expires_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)



                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        expires_at = _parse_expires_at(d.pop("expires_at"))


        def _parse_revoked_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                revoked_at_type_0 = isoparse(data)



                return revoked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        revoked_at = _parse_revoked_at(d.pop("revoked_at"))


        created_at = isoparse(d.pop("created_at"))




        list_api_keys_response_200_api_keys_item = cls(
            id=id,
            name=name,
            scopes=scopes,
            repo_ids=repo_ids,
            metadata=metadata,
            tags=tags,
            last_used_at=last_used_at,
            expires_at=expires_at,
            revoked_at=revoked_at,
            created_at=created_at,
        )


        list_api_keys_response_200_api_keys_item.additional_properties = d
        return list_api_keys_response_200_api_keys_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
