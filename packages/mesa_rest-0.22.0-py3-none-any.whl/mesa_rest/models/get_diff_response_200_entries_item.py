from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_diff_response_200_entries_item_omitted_reason_type_0 import GetDiffResponse200EntriesItemOmittedReasonType0
from ..models.get_diff_response_200_entries_item_status import GetDiffResponse200EntriesItemStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.get_diff_response_200_entries_item_hunks_type_0_item import GetDiffResponse200EntriesItemHunksType0Item





T = TypeVar("T", bound="GetDiffResponse200EntriesItem")



@_attrs_define
class GetDiffResponse200EntriesItem:
    """ 
        Attributes:
            path (str):
            status (GetDiffResponse200EntriesItemStatus): How the entry changed between the base and head changes
            old_path (None | str):
            omitted_reason (GetDiffResponse200EntriesItemOmittedReasonType0 | None): Why textual hunk data is unavailable
                for this changed entry: binary content, entry too large, or omitted because the diff hit file limits
            hunks (list[GetDiffResponse200EntriesItemHunksType0Item] | None): Structured textual diff hunks, or null when
                omitted_reason is set
            size_bytes (float | Unset): Approximate size in bytes of the changed entry content, not the textual diff
     """

    path: str
    status: GetDiffResponse200EntriesItemStatus
    old_path: None | str
    omitted_reason: GetDiffResponse200EntriesItemOmittedReasonType0 | None
    hunks: list[GetDiffResponse200EntriesItemHunksType0Item] | None
    size_bytes: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_diff_response_200_entries_item_hunks_type_0_item import GetDiffResponse200EntriesItemHunksType0Item
        path = self.path

        status = self.status.value

        old_path: None | str
        old_path = self.old_path

        omitted_reason: None | str
        if isinstance(self.omitted_reason, GetDiffResponse200EntriesItemOmittedReasonType0):
            omitted_reason = self.omitted_reason.value
        else:
            omitted_reason = self.omitted_reason

        hunks: list[dict[str, Any]] | None
        if isinstance(self.hunks, list):
            hunks = []
            for hunks_type_0_item_data in self.hunks:
                hunks_type_0_item = hunks_type_0_item_data.to_dict()
                hunks.append(hunks_type_0_item)


        else:
            hunks = self.hunks

        size_bytes = self.size_bytes


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "path": path,
            "status": status,
            "old_path": old_path,
            "omitted_reason": omitted_reason,
            "hunks": hunks,
        })
        if size_bytes is not UNSET:
            field_dict["size_bytes"] = size_bytes

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_diff_response_200_entries_item_hunks_type_0_item import GetDiffResponse200EntriesItemHunksType0Item
        d = dict(src_dict)
        path = d.pop("path")

        status = GetDiffResponse200EntriesItemStatus(d.pop("status"))




        def _parse_old_path(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        old_path = _parse_old_path(d.pop("old_path"))


        def _parse_omitted_reason(data: object) -> GetDiffResponse200EntriesItemOmittedReasonType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                omitted_reason_type_0 = GetDiffResponse200EntriesItemOmittedReasonType0(data)



                return omitted_reason_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetDiffResponse200EntriesItemOmittedReasonType0 | None, data)

        omitted_reason = _parse_omitted_reason(d.pop("omitted_reason"))


        def _parse_hunks(data: object) -> list[GetDiffResponse200EntriesItemHunksType0Item] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                hunks_type_0 = []
                _hunks_type_0 = data
                for hunks_type_0_item_data in (_hunks_type_0):
                    hunks_type_0_item = GetDiffResponse200EntriesItemHunksType0Item.from_dict(hunks_type_0_item_data)



                    hunks_type_0.append(hunks_type_0_item)

                return hunks_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[GetDiffResponse200EntriesItemHunksType0Item] | None, data)

        hunks = _parse_hunks(d.pop("hunks"))


        size_bytes = d.pop("size_bytes", UNSET)

        get_diff_response_200_entries_item = cls(
            path=path,
            status=status,
            old_path=old_path,
            omitted_reason=omitted_reason,
            hunks=hunks,
            size_bytes=size_bytes,
        )


        get_diff_response_200_entries_item.additional_properties = d
        return get_diff_response_200_entries_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
