from enum import Enum

class GetDiffResponse200EntriesItemHunksType0ItemLinesItemKind(str, Enum):
    ADDED = "added"
    ANNOTATION = "annotation"
    CONTEXT = "context"
    DELETED = "deleted"

    def __str__(self) -> str:
        return str(self.value)
