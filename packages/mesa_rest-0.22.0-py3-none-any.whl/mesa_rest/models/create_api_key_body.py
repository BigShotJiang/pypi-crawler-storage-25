from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_api_key_body_scopes_item import CreateApiKeyBodyScopesItem
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_api_key_body_tags import CreateApiKeyBodyTags





T = TypeVar("T", bound="CreateApiKeyBody")



@_attrs_define
class CreateApiKeyBody:
    """ 
        Attributes:
            name (str | Unset):
            scopes (list[CreateApiKeyBodyScopesItem] | Unset):
            repo_ids (list[str] | Unset):
            expires_in_seconds (int | Unset): Expiration time in seconds. Must be between 100 and 31536000 (365 days).
            tags (CreateApiKeyBodyTags | Unset):
     """

    name: str | Unset = UNSET
    scopes: list[CreateApiKeyBodyScopesItem] | Unset = UNSET
    repo_ids: list[str] | Unset = UNSET
    expires_in_seconds: int | Unset = UNSET
    tags: CreateApiKeyBodyTags | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_api_key_body_tags import CreateApiKeyBodyTags
        name = self.name

        scopes: list[str] | Unset = UNSET
        if not isinstance(self.scopes, Unset):
            scopes = []
            for scopes_item_data in self.scopes:
                scopes_item = scopes_item_data.value
                scopes.append(scopes_item)



        repo_ids: list[str] | Unset = UNSET
        if not isinstance(self.repo_ids, Unset):
            repo_ids = self.repo_ids



        expires_in_seconds = self.expires_in_seconds

        tags: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if scopes is not UNSET:
            field_dict["scopes"] = scopes
        if repo_ids is not UNSET:
            field_dict["repo_ids"] = repo_ids
        if expires_in_seconds is not UNSET:
            field_dict["expires_in_seconds"] = expires_in_seconds
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_api_key_body_tags import CreateApiKeyBodyTags
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        _scopes = d.pop("scopes", UNSET)
        scopes: list[CreateApiKeyBodyScopesItem] | Unset = UNSET
        if _scopes is not UNSET:
            scopes = []
            for scopes_item_data in _scopes:
                scopes_item = CreateApiKeyBodyScopesItem(scopes_item_data)



                scopes.append(scopes_item)


        repo_ids = cast(list[str], d.pop("repo_ids", UNSET))


        expires_in_seconds = d.pop("expires_in_seconds", UNSET)

        _tags = d.pop("tags", UNSET)
        tags: CreateApiKeyBodyTags | Unset
        if isinstance(_tags,  Unset):
            tags = UNSET
        else:
            tags = CreateApiKeyBodyTags.from_dict(_tags)




        create_api_key_body = cls(
            name=name,
            scopes=scopes,
            repo_ids=repo_ids,
            expires_in_seconds=expires_in_seconds,
            tags=tags,
        )


        create_api_key_body.additional_properties = d
        return create_api_key_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
