from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_repo_body_tags import CreateRepoBodyTags





T = TypeVar("T", bound="CreateRepoBody")



@_attrs_define
class CreateRepoBody:
    """ 
        Attributes:
            name (str | Unset):
            default_bookmark (str | Unset):  Default: 'main'.
            tags (CreateRepoBodyTags | Unset):
     """

    name: str | Unset = UNSET
    default_bookmark: str | Unset = 'main'
    tags: CreateRepoBodyTags | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_repo_body_tags import CreateRepoBodyTags
        name = self.name

        default_bookmark = self.default_bookmark

        tags: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if default_bookmark is not UNSET:
            field_dict["default_bookmark"] = default_bookmark
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_repo_body_tags import CreateRepoBodyTags
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        default_bookmark = d.pop("default_bookmark", UNSET)

        _tags = d.pop("tags", UNSET)
        tags: CreateRepoBodyTags | Unset
        if isinstance(_tags,  Unset):
            tags = UNSET
        else:
            tags = CreateRepoBodyTags.from_dict(_tags)




        create_repo_body = cls(
            name=name,
            default_bookmark=default_bookmark,
            tags=tags,
        )


        create_repo_body.additional_properties = d
        return create_repo_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
