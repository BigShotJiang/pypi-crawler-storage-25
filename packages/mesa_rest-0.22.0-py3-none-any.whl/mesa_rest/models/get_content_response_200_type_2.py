from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.get_content_response_200_type_2_entries_item_type_0 import GetContentResponse200Type2EntriesItemType0
  from ..models.get_content_response_200_type_2_entries_item_type_1 import GetContentResponse200Type2EntriesItemType1
  from ..models.get_content_response_200_type_2_entries_item_type_2 import GetContentResponse200Type2EntriesItemType2





T = TypeVar("T", bound="GetContentResponse200Type2")



@_attrs_define
class GetContentResponse200Type2:
    """ 
        Attributes:
            type_ (Literal['dir']):
            name (str):
            path (str):
            sha (str):
            child_count (int): Number of direct children in this directory
            entries (list[GetContentResponse200Type2EntriesItemType0 | GetContentResponse200Type2EntriesItemType1 |
                GetContentResponse200Type2EntriesItemType2]):
     """

    type_: Literal['dir']
    name: str
    path: str
    sha: str
    child_count: int
    entries: list[GetContentResponse200Type2EntriesItemType0 | GetContentResponse200Type2EntriesItemType1 | GetContentResponse200Type2EntriesItemType2]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_content_response_200_type_2_entries_item_type_2 import GetContentResponse200Type2EntriesItemType2
        from ..models.get_content_response_200_type_2_entries_item_type_1 import GetContentResponse200Type2EntriesItemType1
        from ..models.get_content_response_200_type_2_entries_item_type_0 import GetContentResponse200Type2EntriesItemType0
        type_ = self.type_

        name = self.name

        path = self.path

        sha = self.sha

        child_count = self.child_count

        entries = []
        for entries_item_data in self.entries:
            entries_item: dict[str, Any]
            if isinstance(entries_item_data, GetContentResponse200Type2EntriesItemType0):
                entries_item = entries_item_data.to_dict()
            elif isinstance(entries_item_data, GetContentResponse200Type2EntriesItemType1):
                entries_item = entries_item_data.to_dict()
            else:
                entries_item = entries_item_data.to_dict()

            entries.append(entries_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "name": name,
            "path": path,
            "sha": sha,
            "child_count": child_count,
            "entries": entries,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_content_response_200_type_2_entries_item_type_0 import GetContentResponse200Type2EntriesItemType0
        from ..models.get_content_response_200_type_2_entries_item_type_1 import GetContentResponse200Type2EntriesItemType1
        from ..models.get_content_response_200_type_2_entries_item_type_2 import GetContentResponse200Type2EntriesItemType2
        d = dict(src_dict)
        type_ = cast(Literal['dir'] , d.pop("type"))
        if type_ != 'dir':
            raise ValueError(f"type must match const 'dir', got '{type_}'")

        name = d.pop("name")

        path = d.pop("path")

        sha = d.pop("sha")

        child_count = d.pop("child_count")

        entries = []
        _entries = d.pop("entries")
        for entries_item_data in (_entries):
            def _parse_entries_item(data: object) -> GetContentResponse200Type2EntriesItemType0 | GetContentResponse200Type2EntriesItemType1 | GetContentResponse200Type2EntriesItemType2:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    entries_item_type_0 = GetContentResponse200Type2EntriesItemType0.from_dict(data)



                    return entries_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    entries_item_type_1 = GetContentResponse200Type2EntriesItemType1.from_dict(data)



                    return entries_item_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                entries_item_type_2 = GetContentResponse200Type2EntriesItemType2.from_dict(data)



                return entries_item_type_2

            entries_item = _parse_entries_item(entries_item_data)

            entries.append(entries_item)


        get_content_response_200_type_2 = cls(
            type_=type_,
            name=name,
            path=path,
            sha=sha,
            child_count=child_count,
            entries=entries,
        )


        get_content_response_200_type_2.additional_properties = d
        return get_content_response_200_type_2

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
