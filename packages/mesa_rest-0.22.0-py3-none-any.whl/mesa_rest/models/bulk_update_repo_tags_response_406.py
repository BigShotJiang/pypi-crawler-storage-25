from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.bulk_update_repo_tags_response_406_error import BulkUpdateRepoTagsResponse406Error





T = TypeVar("T", bound="BulkUpdateRepoTagsResponse406")



@_attrs_define
class BulkUpdateRepoTagsResponse406:
    """ 
        Attributes:
            error (BulkUpdateRepoTagsResponse406Error):
     """

    error: BulkUpdateRepoTagsResponse406Error
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.bulk_update_repo_tags_response_406_error import BulkUpdateRepoTagsResponse406Error
        error = self.error.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "error": error,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.bulk_update_repo_tags_response_406_error import BulkUpdateRepoTagsResponse406Error
        d = dict(src_dict)
        error = BulkUpdateRepoTagsResponse406Error.from_dict(d.pop("error"))




        bulk_update_repo_tags_response_406 = cls(
            error=error,
        )


        bulk_update_repo_tags_response_406.additional_properties = d
        return bulk_update_repo_tags_response_406

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
