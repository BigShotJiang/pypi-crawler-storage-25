from enum import Enum

class GetDiffResponse200EntriesItemStatus(str, Enum):
    ADDED = "added"
    DELETED = "deleted"
    MODIFIED = "modified"
    RENAMED = "renamed"

    def __str__(self) -> str:
        return str(self.value)
