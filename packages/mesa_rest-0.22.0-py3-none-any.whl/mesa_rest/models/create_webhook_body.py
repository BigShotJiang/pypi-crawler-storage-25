from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_webhook_body_events_item import CreateWebhookBodyEventsItem
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateWebhookBody")



@_attrs_define
class CreateWebhookBody:
    """ 
        Attributes:
            url (str):
            events (list[CreateWebhookBodyEventsItem] | Unset):
            repo_ids (list[str] | Unset):
            secret (str | Unset):
     """

    url: str
    events: list[CreateWebhookBodyEventsItem] | Unset = UNSET
    repo_ids: list[str] | Unset = UNSET
    secret: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        url = self.url

        events: list[str] | Unset = UNSET
        if not isinstance(self.events, Unset):
            events = []
            for events_item_data in self.events:
                events_item = events_item_data.value
                events.append(events_item)



        repo_ids: list[str] | Unset = UNSET
        if not isinstance(self.repo_ids, Unset):
            repo_ids = self.repo_ids



        secret = self.secret


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "url": url,
        })
        if events is not UNSET:
            field_dict["events"] = events
        if repo_ids is not UNSET:
            field_dict["repo_ids"] = repo_ids
        if secret is not UNSET:
            field_dict["secret"] = secret

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        url = d.pop("url")

        _events = d.pop("events", UNSET)
        events: list[CreateWebhookBodyEventsItem] | Unset = UNSET
        if _events is not UNSET:
            events = []
            for events_item_data in _events:
                events_item = CreateWebhookBodyEventsItem(events_item_data)



                events.append(events_item)


        repo_ids = cast(list[str], d.pop("repo_ids", UNSET))


        secret = d.pop("secret", UNSET)

        create_webhook_body = cls(
            url=url,
            events=events,
            repo_ids=repo_ids,
            secret=secret,
        )


        create_webhook_body.additional_properties = d
        return create_webhook_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
