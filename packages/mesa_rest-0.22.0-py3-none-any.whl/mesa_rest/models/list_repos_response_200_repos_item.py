from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.list_repos_response_200_repos_item_tags import ListReposResponse200ReposItemTags





T = TypeVar("T", bound="ListReposResponse200ReposItem")



@_attrs_define
class ListReposResponse200ReposItem:
    """ 
        Attributes:
            id (str):
            org (str):
            name (str):
            default_bookmark (str):
            head_change_id (str): Current change id at the default bookmark tip. On empty repositories this is the virtual
                root change id (zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz).
            created_at (datetime.datetime):
            tags (ListReposResponse200ReposItemTags):
     """

    id: str
    org: str
    name: str
    default_bookmark: str
    head_change_id: str
    created_at: datetime.datetime
    tags: ListReposResponse200ReposItemTags
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.list_repos_response_200_repos_item_tags import ListReposResponse200ReposItemTags
        id = self.id

        org = self.org

        name = self.name

        default_bookmark = self.default_bookmark

        head_change_id = self.head_change_id

        created_at = self.created_at.isoformat()

        tags = self.tags.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org": org,
            "name": name,
            "default_bookmark": default_bookmark,
            "head_change_id": head_change_id,
            "created_at": created_at,
            "tags": tags,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_repos_response_200_repos_item_tags import ListReposResponse200ReposItemTags
        d = dict(src_dict)
        id = d.pop("id")

        org = d.pop("org")

        name = d.pop("name")

        default_bookmark = d.pop("default_bookmark")

        head_change_id = d.pop("head_change_id")

        created_at = isoparse(d.pop("created_at"))




        tags = ListReposResponse200ReposItemTags.from_dict(d.pop("tags"))




        list_repos_response_200_repos_item = cls(
            id=id,
            org=org,
            name=name,
            default_bookmark=default_bookmark,
            head_change_id=head_change_id,
            created_at=created_at,
            tags=tags,
        )


        list_repos_response_200_repos_item.additional_properties = d
        return list_repos_response_200_repos_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
