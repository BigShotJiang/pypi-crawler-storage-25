from enum import Enum

class GetDiffResponse200EntriesItemOmittedReasonType0(str, Enum):
    BINARY = "binary"
    FILE_LIMIT = "file_limit"
    TOO_LARGE = "too_large"

    def __str__(self) -> str:
        return str(self.value)
