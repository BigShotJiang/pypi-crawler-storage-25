from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.list_changes_response_200_changes_item import ListChangesResponse200ChangesItem





T = TypeVar("T", bound="ListChangesResponse200")



@_attrs_define
class ListChangesResponse200:
    """ 
        Attributes:
            next_cursor (None | str): Cursor for the next page, or null when no more results remain
            has_more (bool): Whether another page of results is available
            changes (list[ListChangesResponse200ChangesItem]):
     """

    next_cursor: None | str
    has_more: bool
    changes: list[ListChangesResponse200ChangesItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.list_changes_response_200_changes_item import ListChangesResponse200ChangesItem
        next_cursor: None | str
        next_cursor = self.next_cursor

        has_more = self.has_more

        changes = []
        for changes_item_data in self.changes:
            changes_item = changes_item_data.to_dict()
            changes.append(changes_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "next_cursor": next_cursor,
            "has_more": has_more,
            "changes": changes,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_changes_response_200_changes_item import ListChangesResponse200ChangesItem
        d = dict(src_dict)
        def _parse_next_cursor(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        next_cursor = _parse_next_cursor(d.pop("next_cursor"))


        has_more = d.pop("has_more")

        changes = []
        _changes = d.pop("changes")
        for changes_item_data in (_changes):
            changes_item = ListChangesResponse200ChangesItem.from_dict(changes_item_data)



            changes.append(changes_item)


        list_changes_response_200 = cls(
            next_cursor=next_cursor,
            has_more=has_more,
            changes=changes,
        )


        list_changes_response_200.additional_properties = d
        return list_changes_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
