"""Silver/gold transform engine — parse, discover, order, and execute SQL transforms."""

from __future__ import annotations

import graphlib
import logging
import string
from dataclasses import dataclass, field
from pathlib import Path

import duckdb

logger = logging.getLogger(__name__)

VALID_SCHEMAS = {"silver", "gold"}


@dataclass
class TransformMeta:
    """Metadata parsed from a .sql transform file."""

    name: str
    schema: str  # "silver" or "gold"
    sql: str
    depends_on: list[str] = field(default_factory=list)
    materialized: bool = False
    fact_table: str | None = None
    path: Path = field(default_factory=lambda: Path())

    @property
    def qualified_name(self) -> str:
        return f"{self.schema}.{self.name}"


@dataclass
class TransformResult:
    """Result of executing a single transform."""

    name: str
    schema: str
    type: str  # "view" or "table"
    status: str  # "success" or "error"
    error: str | None = None


def parse_transform_file(path: Path) -> TransformMeta:
    """Parse a .sql file into TransformMeta.

    Header comment lines with ``-- depends_on: X`` and ``-- materialized: true``
    are extracted as metadata. Everything else is treated as the SQL SELECT body.
    """
    text = path.read_text()
    lines = text.splitlines()

    depends_on: list[str] = []
    materialized = False
    sql_lines: list[str] = []

    fact_table: str | None = None

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("-- depends_on:"):
            dep = stripped.removeprefix("-- depends_on:").strip()
            if dep:
                depends_on.append(dep)
        elif stripped == "-- materialized: true":
            materialized = True
        elif stripped.startswith("-- fact_table:"):
            fact_table = stripped.removeprefix("-- fact_table:").strip() or None
        else:
            sql_lines.append(line)

    # Strip leading/trailing blank lines from SQL body
    sql = "\n".join(sql_lines).strip()

    name = path.stem  # sales_invoice.sql -> sales_invoice
    schema = path.parent.name  # transforms/silver/ -> silver

    if schema not in VALID_SCHEMAS:
        raise ValueError(
            f"Transform '{path}' is in directory '{schema}', "
            f"expected one of {sorted(VALID_SCHEMAS)}"
        )

    return TransformMeta(
        name=name,
        schema=schema,
        sql=sql,
        depends_on=depends_on,
        materialized=materialized,
        fact_table=fact_table,
        path=path,
    )


def discover_transforms(config_dir: Path) -> list[TransformMeta]:
    """Scan transforms/silver/*.sql and transforms/gold/*.sql under config_dir.

    Returns empty list if the transforms directory does not exist.
    """
    transforms_dir = config_dir / "transforms"
    if not transforms_dir.is_dir():
        return []

    results: list[TransformMeta] = []
    for schema_name in ("silver", "gold"):
        schema_dir = transforms_dir / schema_name
        if not schema_dir.is_dir():
            continue
        for sql_file in sorted(schema_dir.glob("*.sql")):
            results.append(parse_transform_file(sql_file))

    return results


def build_execution_order(transforms: list[TransformMeta]) -> list[TransformMeta]:
    """Topological sort of transforms based on depends_on declarations.

    Dependencies on non-transform schemas (e.g. ``bronze.*``) are treated as
    external and silently ignored — they exist in the extraction layer, not the
    transform layer.  Dependencies on ``silver.*`` or ``gold.*`` that cannot be
    resolved to a discovered transform raise ValueError.  Lets
    graphlib.CycleError propagate on cycles.
    """
    by_name: dict[str, TransformMeta] = {t.qualified_name: t for t in transforms}

    # Validate transform-layer dependencies exist; skip external ones (bronze, etc.)
    for t in transforms:
        for dep in t.depends_on:
            dep_schema = dep.split(".")[0] if "." in dep else ""
            if dep_schema in VALID_SCHEMAS and dep not in by_name:
                raise ValueError(
                    f"Transform '{t.qualified_name}' depends on '{dep}', "
                    f"which was not found among discovered transforms. "
                    f"Known: {sorted(by_name)}"
                )

    # Build dependency graph: node -> set of predecessors (transform-layer only)
    graph: dict[str, set[str]] = {}
    for t in transforms:
        graph[t.qualified_name] = {
            dep for dep in t.depends_on if dep.split(".")[0] in VALID_SCHEMAS
        }

    sorter = graphlib.TopologicalSorter(graph)
    ordered_names = list(sorter.static_order())
    return [by_name[name] for name in ordered_names]


def execute_transforms(
    con: duckdb.DuckDBPyConnection,
    transforms: list[TransformMeta],
    variables: dict[str, str] | None = None,
    force_views: bool = False,
) -> list[TransformResult]:
    """Execute an already-sorted list of transforms against a DuckDB connection.

    Silver transforms become VIEWs. Gold transforms become VIEWs by default,
    or TABLEs when ``materialized=True`` (unless ``force_views=True``,
    which creates everything as VIEWs — used in dev/test mode).
    """
    results: list[TransformResult] = []
    subs = variables or {}

    for t in transforms:
        sql = string.Template(t.sql).safe_substitute(subs)

        if t.materialized and t.schema == "gold" and not force_views:
            # DROP existing VIEW — CREATE OR REPLACE TABLE can't replace a VIEW
            try:
                con.execute(f"DROP VIEW IF EXISTS {t.schema}.{t.name}")
            except duckdb.CatalogException:
                pass  # object exists but isn't a VIEW — TABLE replace handles it
            ddl = f"CREATE OR REPLACE TABLE {t.schema}.{t.name} AS {sql}"
            obj_type = "table"
        else:
            # DROP existing TABLE — CREATE OR REPLACE VIEW can't replace a TABLE
            try:
                con.execute(f"DROP TABLE IF EXISTS {t.schema}.{t.name}")
            except duckdb.CatalogException:
                pass  # object exists but isn't a TABLE — VIEW replace handles it
            ddl = f"CREATE OR REPLACE VIEW {t.schema}.{t.name} AS {sql}"
            obj_type = "view"

        try:
            con.execute(ddl)
            results.append(
                TransformResult(
                    name=t.name,
                    schema=t.schema,
                    type=obj_type,
                    status="success",
                )
            )
            logger.info("Created %s %s.%s", obj_type, t.schema, t.name)
        except Exception as e:
            error_msg = str(e)
            results.append(
                TransformResult(
                    name=t.name,
                    schema=t.schema,
                    type=obj_type,
                    status="error",
                    error=error_msg,
                )
            )
            logger.error(
                "Failed to create %s %s.%s: %s", obj_type, t.schema, t.name, error_msg
            )

    return results


def check_join_health(
    con: duckdb.DuckDBPyConnection,
    transform: TransformMeta,
) -> str | None:
    """Compare gold table row count against its declared fact table.

    Returns a warning message if counts differ, None if healthy.
    Requires ``-- fact_table: silver.X`` comment in the gold SQL file.
    """
    if not transform.fact_table:
        return None

    try:
        gold_count = con.execute(
            f"SELECT COUNT(*) FROM {transform.qualified_name}"
        ).fetchone()[0]
        fact_count = con.execute(
            f"SELECT COUNT(*) FROM {transform.fact_table}"
        ).fetchone()[0]
    except Exception as e:
        return f"Join health check failed for {transform.qualified_name}: {e}"

    if gold_count == fact_count:
        return None

    diff = gold_count - fact_count
    if diff > 0:
        return (
            f"JOIN INFLATION: {transform.qualified_name} has {gold_count:,} rows "
            f"but fact table {transform.fact_table} has {fact_count:,} rows "
            f"(+{diff:,} extra). Check for duplicate keys in dimension tables."
        )
    return (
        f"JOIN LOSS: {transform.qualified_name} has {gold_count:,} rows "
        f"but fact table {transform.fact_table} has {fact_count:,} rows "
        f"({diff:,} missing). Check for INNER JOINs or missing dimension matches."
    )


def rebuild_materialized_gold(
    con: duckdb.DuckDBPyConnection,
    transforms: list[TransformMeta],
    variables: dict[str, str] | None = None,
) -> list[TransformResult]:
    """Re-execute only materialized gold transforms as TABLEs.

    Called after extraction to refresh gold tables with latest data.
    Runs join health checks for transforms with ``-- fact_table:`` declared.
    """
    mat_gold = [t for t in transforms if t.schema == "gold" and t.materialized]
    if not mat_gold:
        return []
    results = execute_transforms(con, mat_gold, variables)

    for t in mat_gold:
        warning = check_join_health(con, t)
        if warning:
            logger.warning(warning)

    return results
