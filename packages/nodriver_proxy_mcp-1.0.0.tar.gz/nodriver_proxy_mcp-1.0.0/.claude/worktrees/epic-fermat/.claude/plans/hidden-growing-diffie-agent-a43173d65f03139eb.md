# Dashboard Refactoring Plan
See conversation for details.
