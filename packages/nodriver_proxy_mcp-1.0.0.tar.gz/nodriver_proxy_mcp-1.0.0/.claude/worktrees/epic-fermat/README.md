<p align="center">
  <h1 align="center">nodriver-proxy-mcp</h1>
  <p align="center">
    <strong>Give your AI agent a browser, a proxy, and a Python sandbox.</strong><br/>
    It navigates like a human, intercepts like Burp, and codes its own exploits on the fly.
  </p>
  <p align="center">
    <a href="https://python.org"><img src="https://img.shields.io/badge/python-3.10+-3776AB.svg?logo=python&logoColor=white" alt="Python 3.10+"></a>
    <a href="https://modelcontextprotocol.io"><img src="https://img.shields.io/badge/MCP-Compatible-8A2BE2" alt="MCP"></a>
    <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-yellow.svg" alt="MIT License"></a>
  </p>
</p>

**[한국어](README_ko.md)**

---

## Why this exists

Existing security MCP servers give the AI read-only access to traffic. This one gives full control: the agent opens a browser that **passes Cloudflare**, captures every request through a **MITM proxy**, and when the built-in tools aren't enough, it **writes and runs its own Python** to chain everything together.

```
"Scan target.com for IDOR vulnerabilities"

  1. Agent starts proxy + browser
  2. Navigates to login page, types credentials, clicks submit
  3. Captures the auth flow, extracts the JWT
  4. Replays API requests with different user IDs
  5. Writes a Python script to automate the full IDOR check
  6. Reports which endpoints are vulnerable
```

No human touches the keyboard. The agent does it all through 39 MCP tools.

---

## How it works

```text
AI Agent <--> FastMCP (stdio) --+--> mitmproxy (:8082) <--> Target
                                |
                                +--> Chrome (nodriver, CDP) --> mitmproxy
                                |
                                +--> Python sandbox (NdpSDK) --> mitmproxy
                                |
                                +--> SQLite (traffic archive)
                                |
                                +--> Streamlit dashboard (:8501)
```

Four modules, one stdio pipe:

| Module | Tools | What it does |
|--------|-------|-------------|
| **Proxy** | 18 | Intercept, record, replay, fuzz, and manipulate HTTP/HTTPS traffic |
| **Browser** | 20 | Automate Chrome with bot-detection bypass, DOM analysis, and real-time CDP Fetch interception |
| **Code-mode** | 1 | Execute AI-generated Python in a resource-limited sandbox with full access to all other tools via `NdpSDK` |
| **Dashboard** | - | Streamlit UI for traffic timeline, flow inspection, and session monitoring |

---

## Quick start

### 1. Install

Requires Python 3.10+ and [uv](https://github.com/astral-sh/uv).

```bash
git clone https://github.com/BobongKu/nodriver-proxy-mcp.git
cd nodriver-proxy-mcp
```

### 2. Add to your AI agent

**Claude Code** (`settings.json` or `.claude/settings.local.json`):

```json
{
  "mcpServers": {
    "nodriver-proxy-mcp": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/nodriver-proxy-mcp", "nodriver-proxy-mcp"]
    }
  }
}
```

**Cursor / other MCP clients** (`mcp_config.json`):

```json
{
  "mcpServers": {
    "nodriver-proxy-mcp": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/nodriver-proxy-mcp", "nodriver-proxy-mcp"]
    }
  }
}
```

> Avoid `uvx` — it creates an ephemeral environment that can't install runtime dependencies for code-mode.

### 3. Use it

Just tell your AI agent what to do. The tools are self-descriptive — the agent picks the right ones automatically.

---

## What the agent can do

### Recon: browse like a human, capture everything

The browser passes Cloudflare, DataDome, and other bot detection out of the box. Every request flows through the proxy and gets logged to SQLite.

```
manage_proxy(action="start")
browser_open(proxy_port=8082)
browser_go(url="https://target.com/login")
browser_type(selector="#email", text="admin@target.com")
browser_click(selector="#login-btn")

get_traffic_summary()           --> login flow captured
detect_auth_pattern()           --> "JWT detected in Authorization header"
browser_get_storage()           --> localStorage tokens the proxy can't see
browser_get_dom()               --> forms, hidden inputs, CSRF tokens, data-* attributes
```

### Intercept: modify requests before they leave the browser

Two layers of interception — choose based on what you need:

| Layer | Latency | Scope | Best for |
|-------|---------|-------|----------|
| **CDP Fetch** (`browser_intercept_*`) | Instant | Browser requests only | Header injection, response tampering, CSP bypass testing |
| **mitmproxy** (`add_interception_rule`) | ~5s cache | All traffic | System-wide rules, upstream chaining to Burp |

```
# CDP Fetch: instant, browser-level
browser_intercept_request(url_pattern=".*api.*", action="inject_header", key="X-Admin", value="true")
browser_go(url="https://target.com/api/admin")      # request has X-Admin header

# mitmproxy: system-wide, works with any HTTP client
add_interception_rule(url_pattern=".*api.*", action="inject_header", key="X-Test", value="1")
```

### Replay: extract, template, resend

Extract tokens from captured traffic, save them as variables, and reuse them with `{{placeholder}}` substitution.

```
extract_session_variable(flow_id="abc", regex="Bearer ([\\w.-]+)", name="jwt")
list_session_variables()        --> {"jwt": "eyJhbG..."}

replay_flow(flow_id="def")      # {{jwt}} in headers/body auto-replaced
replay_flow(flow_id="def", replacements=[{"regex": "user_id=1", "replacement": "user_id=2"}])
```

### Fuzz: automated anomaly detection

```
fuzz_endpoint(
    flow_id="abc",
    payloads=["' OR 1=1--", "<script>alert(1)</script>", "{{jwt}}", "../../../etc/passwd"],
    target_pattern="FUZZ"
)
# --> Measures baseline, detects status code / length / latency / error anomalies
```

### Code-mode: when tools aren't enough, write new ones

The agent writes Python that has programmatic access to every other tool via `NdpSDK`. This is where the real power is — race conditions, blind SQLi extraction, multi-step exploit chains.

```python
execute_security_code(script_content="""
from nodriver_proxy_mcp.sdk import NdpSDK
import asyncio

async def idor_scan():
    sdk = NdpSDK()

    # Get the base request
    flows = await sdk.search_traffic(query="/api/users/")
    base = flows['flows'][0]

    # Try 50 user IDs
    for uid in range(1, 51):
        result = await sdk.replay_flow(
            base['id'],
            replacements=[{"regex": r"/users/\\d+", "replacement": f"/users/{uid}"}]
        )
        if result['status_code'] == 200:
            print(f"[!] IDOR: /users/{uid} accessible")

asyncio.run(idor_scan())
""", approved=True)
```

Resource limits are enforced: 256MB memory (Windows Job Object / Unix rlimit), 60s CPU time, 32KB output cap.

---

## All 39 tools

### Proxy (18)

| Tool | Purpose |
|------|---------|
| `manage_proxy` | Start/stop mitmproxy. Chain to Burp via `upstream`. GUI via `ui=True`. |
| `proxy_status` | Check running state, port, PID |
| `set_scope` | Limit recording to specific domains |
| `get_traffic_summary` | Paginated flow list |
| `inspect_flow` | Full request/response with headers and body |
| `search_traffic` | Filter by keyword, domain, method, status code |
| `extract_from_flow` | Pull values via JSONPath, regex, or CSS selectors |
| `extract_session_variable` | Save a value for `{{placeholder}}` reuse |
| `list_session_variables` | Show all extracted variables |
| `generate_curl` | Export a flow as a curl command |
| `replay_flow` | Resend with regex replacements + `{{var}}` substitution |
| `send_raw_request` | Craft arbitrary HTTP requests (SSRF-protected) |
| `add_interception_rule` | Live traffic manipulation: inject headers, replace body, block |
| `list_interception_rules` | Show active rules |
| `remove_interception_rule` | Delete a rule by ID |
| `detect_auth_pattern` | Auto-detect JWT, Bearer, API key, session cookie, CSRF, OAuth2 |
| `fuzz_endpoint` | Multi-threaded fuzzing with baseline anomaly detection |
| `clear_traffic` | Wipe the traffic database |

### Browser (20)

| Tool | Purpose |
|------|---------|
| `browser_open` / `browser_close` | Launch or kill a Chrome session (headless by default) |
| `browser_list_sessions` | Active sessions with PID, ports, uptime |
| `browser_list_tabs` | Tabs in a session |
| `browser_go` / `browser_back` | Navigate, wait for page load |
| `browser_click` | Click by CSS selector or text content |
| `browser_type` | Type into inputs (supports payload injection) |
| `browser_get_dom` | Security-focused DOM extraction: forms, scripts, iframes, comments, event handlers, `data-*` attributes |
| `browser_get_text` | Text content from a selector |
| `browser_get_storage` | Dump localStorage + sessionStorage |
| `browser_get_console` | JS console output with level filtering |
| `browser_screenshot` | Capture as PNG |
| `browser_set_cookie` | Set cookies via CDP (supports httpOnly) |
| `browser_js` | Execute arbitrary JavaScript |
| `browser_wait` | Wait for element/text (SPA/AJAX support) |
| `browser_intercept_request` | CDP Fetch: inject headers, modify URL, block outgoing requests |
| `browser_intercept_response` | CDP Fetch: replace response body, block responses |
| `browser_intercept_disable` | Turn off all CDP Fetch interception |
| `browser_list_intercept_rules` | Show active CDP Fetch rules |

### Code-mode (1)

| Tool | Purpose |
|------|---------|
| `execute_security_code` | Run AI-generated Python with `NdpSDK` access to all 38 other tools. Sandboxed with resource limits. |

---

## Architecture

```mermaid
graph TD
    Agent["AI Agent"] <-->|"stdio (JSON-RPC)"| MCP["FastMCP Server"]

    subgraph "nodriver-proxy-mcp"
        direction TB
        Proxy["Proxy Core<br/>mitmproxy :8082"]
        Browser["CDP Browser<br/>nodriver (anti-bot)"]
        Fetch["CDP Fetch API<br/>Request/Response hooks"]
        CodeMode["Code-mode Sandbox<br/>NdpSDK"]
        Dashboard["Streamlit Dashboard<br/>:8501"]
    end

    Target[("Target")]
    DB[("SQLite<br/>traffic.db")]

    MCP --> Proxy
    MCP --> Browser
    MCP --> CodeMode

    Browser --> Fetch
    Fetch -.->|modify in-flight| Browser

    Proxy <-->|HTTP/HTTPS| Target
    Browser -->|routed through| Proxy
    CodeMode -->|routed through| Proxy

    Proxy --> DB
    Dashboard -->|read-only| DB
```

### Process model

Each component runs as an independent process with automatic cleanup:

| Process | Lifecycle | Cleanup mechanism |
|---------|-----------|-------------------|
| **mitmproxy** | Subprocess of MCP server | Watchdog thread monitors parent PID |
| **Chrome** (per session) | Subprocess via `BrowserDaemon` | Health check every 2s + SIGTERM/atexit handler |
| **Code-mode scripts** | Subprocess with resource limits | Windows Job Object (`KILL_ON_JOB_CLOSE`) / Unix `killpg` |
| **Port conflicts** | Resolved on proxy start | Cross-platform: `netstat`+`taskkill` (Win) / `lsof`+`fuser` (Unix) |

---

## Dashboard

```bash
uv run nodriver-proxy-dashboard
# Opens at http://localhost:8501
```

| Page | What it shows |
|------|--------------|
| **Traffic** | Real-time flow table with filters (domain, method, status, keyword) and auto-refresh |
| **Flow Detail** | Request/response viewer with syntax highlighting + curl export |
| **Rules** | Manage interception rules, view session variables |
| **Sessions** | Browser session cards with live screenshots and DOM tree |
| **Proxy Control** | Start/stop proxy, set scope, clear traffic |

---

## Burp Suite integration

Use `upstream` to chain mitmproxy through Burp for manual analysis alongside AI automation:

```
manage_proxy(action="start", upstream="localhost:8080")
```

Traffic flows: `Chrome --> mitmproxy (:8082) --> Burp Suite (:8080) --> Target`

Both tools see the same traffic. The AI automates; you analyze in Burp when you need to.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Port already in use | `manage_proxy(port=XXXX)` or the server auto-kills orphaned processes on start |
| Browser won't launch | Install Chrome/Chromium. `nodriver` requires a real Chrome binary. |
| SSL certificate errors | Trust the mitmproxy CA: `~/.mitmproxy/mitmproxy-ca-cert.pem` |
| Tools not showing after update | Restart your Claude Code / Cursor session to reload the MCP server |
| `uvx` fails | Don't use `uvx`. Clone the repo and use `uv run --directory` instead. |

---

## License

MIT
