import asyncio
import sys
import os

async def main():
    import tempfile
    
    script_content = 'import sys\nprint("Hello from python script")'
    fd, path = tempfile.mkstemp(suffix=".py", prefix="mcp_sandbox_")
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write(script_content)

    print(f"Executing: {sys.executable} {path}")
    import subprocess
    kwargs = dict(
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        env=os.environ.copy()
    )
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        
    result = await asyncio.create_subprocess_exec(
        sys.executable, path,
        **kwargs
    )
    
    stdout_chunks = []
    try:
        async with asyncio.timeout(10):
            while True:
                line = await result.stdout.readline()
                if not line:
                    break
                stdout_chunks.append(line.decode(errors="replace"))
        await result.wait()
    except asyncio.TimeoutError:
        print("Timeout hit!")
        result.kill()
        
    final_out = "".join(stdout_chunks)
    print("Output:")
    print(final_out)
    
    os.remove(path)

asyncio.run(main())
