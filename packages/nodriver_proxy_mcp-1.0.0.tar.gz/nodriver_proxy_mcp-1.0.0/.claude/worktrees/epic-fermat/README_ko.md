<p align="center">
  <h1 align="center">nodriver-proxy-mcp</h1>
  <p align="center">
    <strong>AI 에이전트에게 브라우저, 프록시, Python 샌드박스를 줘보세요.</strong><br/>
    사람처럼 브라우징하고, Burp처럼 가로채고, 필요한 공격 코드는 직접 짭니다.
  </p>
  <p align="center">
    <a href="https://python.org"><img src="https://img.shields.io/badge/python-3.10+-3776AB.svg?logo=python&logoColor=white" alt="Python 3.10+"></a>
    <a href="https://modelcontextprotocol.io"><img src="https://img.shields.io/badge/MCP-Compatible-8A2BE2" alt="MCP"></a>
    <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-yellow.svg" alt="MIT License"></a>
  </p>
</p>

**[English](README.md)**

---

## 왜 만들었나

기존 보안 MCP 서버는 AI에게 트래픽을 **읽기만** 하게 합니다. 이 도구는 **완전한 제어권**을 줍니다: 에이전트가 **Cloudflare를 우회하는 브라우저**를 열고, 모든 요청을 **MITM 프록시**로 캡처하고, 내장 도구로 부족하면 **Python을 직접 짜서 실행**합니다.

```
"target.com에서 IDOR 취약점을 찾아줘"

  1. 에이전트가 프록시 + 브라우저 시작
  2. 로그인 페이지로 이동, 인증 정보 입력, 제출
  3. 인증 플로우를 캡처하고 JWT 추출
  4. 다른 사용자 ID로 API 요청을 재전송
  5. Python 스크립트를 작성해 전체 IDOR 체크 자동화
  6. 취약한 엔드포인트 리포트
```

사람이 키보드를 만질 필요가 없습니다. 에이전트가 39개 MCP 도구로 전부 처리합니다.

---

## 동작 방식

```text
AI 에이전트 <--> FastMCP (stdio) --+--> mitmproxy (:8082) <--> 타겟
                                   |
                                   +--> Chrome (nodriver, CDP) --> mitmproxy
                                   |
                                   +--> Python 샌드박스 (NdpSDK) --> mitmproxy
                                   |
                                   +--> SQLite (트래픽 아카이브)
                                   |
                                   +--> Streamlit 대시보드 (:8501)
```

네 개 모듈, 하나의 stdio 파이프:

| 모듈 | 도구 수 | 하는 일 |
|------|---------|---------|
| **프록시** | 18 | HTTP/HTTPS 트래픽 인터셉트, 기록, 재전송, 퍼징, 조작 |
| **브라우저** | 20 | 봇 탐지 우회 Chrome 자동화, DOM 분석, CDP Fetch 실시간 인터셉트 |
| **코드 모드** | 1 | 리소스 제한 샌드박스에서 AI가 생성한 Python 실행. `NdpSDK`로 모든 도구 접근 |
| **대시보드** | - | 트래픽 타임라인, 플로우 분석, 세션 모니터링을 위한 Streamlit UI |

---

## 빠른 시작

### 1. 설치

Python 3.10 이상, [uv](https://github.com/astral-sh/uv) 필요.

```bash
git clone https://github.com/BobongKu/nodriver-proxy-mcp.git
cd nodriver-proxy-mcp
```

### 2. AI 에이전트에 등록

**Claude Code** (`settings.json` 또는 `.claude/settings.local.json`):

```json
{
  "mcpServers": {
    "nodriver-proxy-mcp": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/nodriver-proxy-mcp", "nodriver-proxy-mcp"]
    }
  }
}
```

**Cursor / 기타 MCP 클라이언트** (`mcp_config.json`):

```json
{
  "mcpServers": {
    "nodriver-proxy-mcp": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/nodriver-proxy-mcp", "nodriver-proxy-mcp"]
    }
  }
}
```

> `uvx`는 사용하지 마세요 — 코드 모드의 런타임 의존성 설치가 안 됩니다.

### 3. 사용

AI 에이전트에게 하고 싶은 걸 말하면 됩니다. 도구 설명이 충분해서 에이전트가 알아서 선택합니다.

---

## 에이전트가 할 수 있는 것

### 정찰: 사람처럼 브라우징하고, 모든 것을 캡처

브라우저가 Cloudflare, DataDome 등 봇 탐지를 기본으로 우회합니다. 모든 요청이 프록시를 거쳐 SQLite에 기록됩니다.

```
manage_proxy(action="start")
browser_open(proxy_port=8082)
browser_go(url="https://target.com/login")
browser_type(selector="#email", text="admin@target.com")
browser_click(selector="#login-btn")

get_traffic_summary()           --> 로그인 플로우 캡처 완료
detect_auth_pattern()           --> "Authorization 헤더에서 JWT 감지"
browser_get_storage()           --> 프록시가 볼 수 없는 localStorage 토큰
browser_get_dom()               --> 폼, 히든 인풋, CSRF 토큰, data-* 속성
```

### 인터셉트: 요청이 브라우저를 떠나기 전에 수정

두 레이어의 인터셉트 — 필요에 따라 선택:

| 레이어 | 지연 | 범위 | 적합한 용도 |
|--------|------|------|------------|
| **CDP Fetch** (`browser_intercept_*`) | 즉시 | 브라우저 요청만 | 헤더 주입, 응답 변조, CSP 우회 테스트 |
| **mitmproxy** (`add_interception_rule`) | ~5초 캐시 | 모든 트래픽 | 시스템 전체 규칙, Burp 체이닝 |

```
# CDP Fetch: 즉각적, 브라우저 레벨
browser_intercept_request(url_pattern=".*api.*", action="inject_header", key="X-Admin", value="true")
browser_go(url="https://target.com/api/admin")      # X-Admin 헤더가 포함된 요청

# mitmproxy: 시스템 전체, 모든 HTTP 클라이언트에 적용
add_interception_rule(url_pattern=".*api.*", action="inject_header", key="X-Test", value="1")
```

### 리플레이: 추출, 템플릿, 재전송

캡처된 트래픽에서 토큰을 추출하고, 변수로 저장해서 `{{placeholder}}`로 자동 치환합니다.

```
extract_session_variable(flow_id="abc", regex="Bearer ([\\w.-]+)", name="jwt")
list_session_variables()        --> {"jwt": "eyJhbG..."}

replay_flow(flow_id="def")      # 헤더/바디의 {{jwt}}가 자동 치환
replay_flow(flow_id="def", replacements=[{"regex": "user_id=1", "replacement": "user_id=2"}])
```

### 퍼징: 자동 이상 탐지

```
fuzz_endpoint(
    flow_id="abc",
    payloads=["' OR 1=1--", "<script>alert(1)</script>", "{{jwt}}", "../../../etc/passwd"],
    target_pattern="FUZZ"
)
# --> 베이스라인 측정 후 상태코드 / 길이 / 지연시간 / 에러 이상 탐지
```

### 코드 모드: 도구가 부족하면 직접 만든다

에이전트가 Python을 작성하면 `NdpSDK`를 통해 모든 도구에 프로그래밍 방식으로 접근합니다. Race condition, Blind SQLi 추출, 다단계 익스플로잇 체이닝 같은 복잡한 시나리오에 적합합니다.

```python
execute_security_code(script_content="""
from nodriver_proxy_mcp.sdk import NdpSDK
import asyncio

async def idor_scan():
    sdk = NdpSDK()

    # 기본 요청 가져오기
    flows = await sdk.search_traffic(query="/api/users/")
    base = flows['flows'][0]

    # 50개 사용자 ID 시도
    for uid in range(1, 51):
        result = await sdk.replay_flow(
            base['id'],
            replacements=[{"regex": r"/users/\\d+", "replacement": f"/users/{uid}"}]
        )
        if result['status_code'] == 200:
            print(f"[!] IDOR: /users/{uid} 접근 가능")

asyncio.run(idor_scan())
""", approved=True)
```

리소스 제한 적용: 256MB 메모리 (Windows Job Object / Unix rlimit), 60초 CPU 시간, 32KB 출력 상한.

---

## 전체 39개 도구

### 프록시 (18)

| 도구 | 용도 |
|------|------|
| `manage_proxy` | 프록시 시작/중지. `upstream`으로 Burp 체이닝. `ui=True`로 GUI. |
| `proxy_status` | 실행 상태, 포트, PID 확인 |
| `set_scope` | 캡처 대상 도메인 제한 |
| `get_traffic_summary` | 페이지네이션된 플로우 목록 |
| `inspect_flow` | 전체 요청/응답 (헤더 + 바디) |
| `search_traffic` | 키워드, 도메인, 메서드, 상태코드 필터 검색 |
| `extract_from_flow` | JSONPath, regex, CSS 셀렉터로 값 추출 |
| `extract_session_variable` | `{{placeholder}}` 재사용을 위한 값 저장 |
| `list_session_variables` | 추출된 모든 변수 조회 |
| `generate_curl` | 플로우를 curl 명령으로 내보내기 |
| `replay_flow` | regex 치환 + `{{var}}` 자동 대입으로 재전송 |
| `send_raw_request` | 원시 HTTP 요청 직접 전송 (SSRF 차단 내장) |
| `add_interception_rule` | 실시간 트래픽 조작: 헤더 주입, 바디 치환, 차단 |
| `list_interception_rules` | 활성 규칙 조회 |
| `remove_interception_rule` | ID로 규칙 삭제 |
| `detect_auth_pattern` | JWT, Bearer, API key, 세션 쿠키, CSRF, OAuth2 자동 감지 |
| `fuzz_endpoint` | 멀티스레드 퍼징 + 베이스라인 이상 탐지 |
| `clear_traffic` | 트래픽 DB 초기화 |

### 브라우저 (20)

| 도구 | 용도 |
|------|------|
| `browser_open` / `browser_close` | Chrome 세션 시작/종료 (기본 headless) |
| `browser_list_sessions` | 활성 세션 목록 (PID, 포트, 가동시간) |
| `browser_list_tabs` | 세션 내 탭 목록 |
| `browser_go` / `browser_back` | 네비게이션, 페이지 로드 대기 |
| `browser_click` | CSS 셀렉터 또는 텍스트로 클릭 |
| `browser_type` | 입력 필드에 텍스트 입력 (페이로드 주입 가능) |
| `browser_get_dom` | 보안 중심 DOM 추출: 폼, 스크립트, iframe, 주석, 이벤트 핸들러, `data-*` 속성 |
| `browser_get_text` | 셀렉터의 텍스트 콘텐츠 |
| `browser_get_storage` | localStorage + sessionStorage 덤프 |
| `browser_get_console` | JS 콘솔 출력 (레벨 필터링) |
| `browser_screenshot` | PNG 캡처 |
| `browser_set_cookie` | CDP로 쿠키 설정 (httpOnly 지원) |
| `browser_js` | 임의 JavaScript 실행 |
| `browser_wait` | 요소/텍스트 대기 (SPA/AJAX) |
| `browser_intercept_request` | CDP Fetch: 요청 헤더 주입, URL 변경, 차단 |
| `browser_intercept_response` | CDP Fetch: 응답 바디 치환, 차단 |
| `browser_intercept_disable` | CDP Fetch 인터셉트 전체 해제 |
| `browser_list_intercept_rules` | 활성 CDP Fetch 규칙 조회 |

### 코드 모드 (1)

| 도구 | 용도 |
|------|------|
| `execute_security_code` | `NdpSDK`로 38개 도구에 접근하는 AI 생성 Python 실행. 리소스 제한 샌드박스. |

---

## 아키텍처

```mermaid
graph TD
    Agent["AI 에이전트"] <-->|"stdio (JSON-RPC)"| MCP["FastMCP 서버"]

    subgraph "nodriver-proxy-mcp"
        direction TB
        Proxy["프록시 코어<br/>mitmproxy :8082"]
        Browser["CDP 브라우저<br/>nodriver (봇 탐지 우회)"]
        Fetch["CDP Fetch API<br/>요청/응답 훅"]
        CodeMode["코드 모드 샌드박스<br/>NdpSDK"]
        Dashboard["Streamlit 대시보드<br/>:8501"]
    end

    Target[("타겟")]
    DB[("SQLite<br/>traffic.db")]

    MCP --> Proxy
    MCP --> Browser
    MCP --> CodeMode

    Browser --> Fetch
    Fetch -.->|"실시간 수정"| Browser

    Proxy <-->|HTTP/HTTPS| Target
    Browser -->|"프록시 경유"| Proxy
    CodeMode -->|"프록시 경유"| Proxy

    Proxy --> DB
    Dashboard -->|"읽기 전용"| DB
```

### 프로세스 모델

각 컴포넌트가 독립 프로세스로 실행되며 자동 정리됩니다:

| 프로세스 | 수명 | 정리 메커니즘 |
|---------|------|-------------|
| **mitmproxy** | MCP 서버의 자식 프로세스 | Watchdog 스레드가 부모 PID 감시 |
| **Chrome** (세션당) | `BrowserDaemon` 자식 프로세스 | 2초마다 헬스체크 + SIGTERM/atexit 핸들러 |
| **코드 모드 스크립트** | 리소스 제한 자식 프로세스 | Windows Job Object (`KILL_ON_JOB_CLOSE`) / Unix `killpg` |
| **포트 충돌** | 프록시 시작 시 해결 | 크로스 플랫폼: `netstat`+`taskkill` (Win) / `lsof`+`fuser` (Unix) |

---

## 대시보드

```bash
uv run nodriver-proxy-dashboard
# http://localhost:8501 에서 열림
```

| 페이지 | 내용 |
|--------|------|
| **Traffic** | 실시간 플로우 테이블 + 필터 (도메인, 메서드, 상태, 키워드) + 자동 갱신 |
| **Flow Detail** | 요청/응답 뷰어 (구문 강조) + curl 내보내기 |
| **Rules** | 인터셉트 규칙 관리, 세션 변수 확인 |
| **Sessions** | 브라우저 세션 카드 + 실시간 스크린샷 + DOM 트리 |
| **Proxy Control** | 프록시 시작/중지, 스코프 설정, 트래픽 초기화 |

---

## Burp Suite 연동

`upstream`으로 mitmproxy를 Burp에 체이닝해서 AI 자동화와 수동 분석을 동시에 할 수 있습니다:

```
manage_proxy(action="start", upstream="localhost:8080")
```

트래픽 흐름: `Chrome --> mitmproxy (:8082) --> Burp Suite (:8080) --> 타겟`

양쪽 도구가 같은 트래픽을 봅니다. AI가 자동화하고, 정밀 분석이 필요할 때 Burp에서 확인합니다.

---

## 문제 해결

| 문제 | 해결 |
|------|------|
| 포트 사용 중 | `manage_proxy(port=XXXX)` 또는 서버가 시작 시 고아 프로세스 자동 정리 |
| 브라우저 실행 실패 | Chrome/Chromium 설치 필요. `nodriver`는 실제 Chrome 바이너리가 필요합니다. |
| SSL 인증서 에러 | mitmproxy CA 신뢰 등록: `~/.mitmproxy/mitmproxy-ca-cert.pem` |
| 업데이트 후 도구 안 보임 | Claude Code / Cursor 세션 재시작으로 MCP 서버 리로드 |
| `uvx` 실패 | `uvx` 대신 레포 클론 후 `uv run --directory` 사용 |

---

## 라이선스

MIT
