"""Proxy MCP tools — 18 tools for traffic inspection, replay, fuzzing, rule management, and session variables.

All tools are registered via register_proxy_tools(mcp) in main.py.
"""

import json
import re
import time
import uuid
import logging
from typing import Optional

from ..proxy.recorder import traffic_db
from ..proxy.scope import scope_manager
from ..proxy.controller import proxy_manager

logger = logging.getLogger(__name__)


def _proxy_url() -> str | None:
    """Return the proxy URL if proxy is running, else None."""
    if proxy_manager.running:
        return f"http://127.0.0.1:{proxy_manager.port}"
    return None


def register_proxy_tools(mcp):
    """Register all 18 proxy tools with the FastMCP server."""

    # ── Lifecycle ──

    @mcp.tool()
    async def manage_proxy(action: str, port: int = 8082, ui: bool = False, upstream: str = "") -> str:
        """Proxy Lifecycle Manager.
        Controls the background Mitmproxy daemon instance.
        Args:
            action: start or stop
            port: Port to listen on (default 8082)
            ui: If true, opens mitmweb (Web GUI) on port 8081. Else runs headless mitmdump.
            upstream: Upstream proxy address (e.g. "localhost:8080" for Burp Suite). If provided, all traffic is forwarded to this upstream proxy.
        """
        if action == "start":
            result = proxy_manager.start(port=port, ui=ui, upstream=upstream)
        elif action == "stop":
            result = proxy_manager.stop()
        else:
            result = {"error": f"Unknown action: {action}. Use 'start' or 'stop'."}
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def set_scope(allowed_domains: list[str]) -> str:
        """Set the proxy scope. Only traffic to these domains will be recorded.
        Static assets (.jpg, .css, .woff, etc.) and OPTIONS requests are always ignored.
        Args:
            allowed_domains: List of domains to record, e.g. ["target.com", "api.target.com"]. Empty list = record all.
        """
        scope_manager.set_domains(allowed_domains)
        return json.dumps(scope_manager.to_dict(), indent=2)

    @mcp.tool()
    async def proxy_status() -> str:
        """Get the current proxy status (running, port, pid)."""
        if proxy_manager.running:
            return json.dumps({
                "status": "running",
                "port": proxy_manager.port,
                "pid": proxy_manager._proc.pid if proxy_manager._proc else None,
            }, indent=2)
        return json.dumps({"status": "not_running"})

    # ── Traffic Read ──

    @mcp.tool()
    async def get_traffic_summary(limit: int = 20, offset: int = 0) -> str:
        """Get a paginated summary of captured HTTP traffic.
        Returns flow IDs, URLs, methods, status codes, latency. Use inspect_flow for details.
        Args:
            limit: Max flows to return (default 20)
            offset: Skip this many flows (for pagination)
        """
        result = traffic_db.get_summary(limit=limit, offset=offset)
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def inspect_flow(flow_id: str, include: list[str] = None) -> str:
        """Get detailed information about a specific HTTP flow.
        Default returns metadata only (saves tokens). Add fields to include for more detail.
        Args:
            flow_id: The flow ID from get_traffic_summary
            include: Fields to include. Options: metadata (default), requestHeaders, requestBody, responseHeaders, responseBody
        """
        if include is None:
            include = ["metadata"]
        result = traffic_db.get_detail(flow_id, include=include)
        if not result:
            return json.dumps({"error": f"Flow {flow_id} not found"})
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def search_traffic(
        query: str = None,
        domain: str = None,
        method: str = None,
        status_code: int = None,
        limit: int = 50,
    ) -> str:
        """Search captured traffic by keyword, domain, method, or status code.
        Args:
            query: Search in URL, request body, and response body
            domain: Filter by domain
            method: Filter by HTTP method (GET, POST, etc.)
            status_code: Filter by response status code
            limit: Max results (default 50)
        """
        results = traffic_db.search(
            query=query, domain=domain, method=method,
            status_code=status_code, limit=limit,
        )
        return json.dumps({"total": len(results), "flows": results}, indent=2)

    @mcp.tool()
    async def extract_from_flow(
        flow_id: str,
        json_path: str = None,
        css_selector: str = None,
        regex: str = None,
    ) -> str:
        """Extract specific data from a flow's response body.
        Use exactly one extractor: json_path, css_selector, or regex.
        Args:
            flow_id: The flow ID
            json_path: JSONPath expression (e.g. $.data.users[0].id)
            css_selector: CSS selector for HTML (e.g. input[name=csrf])
            regex: Regex pattern with capture groups (e.g. token: "([^"]+)")
        """
        detail = traffic_db.get_detail(flow_id, include=["metadata"])
        if not detail:
            return json.dumps({"error": f"Flow {flow_id} not found"})

        # Use untruncated body for accurate extraction
        body = traffic_db.get_raw_body(flow_id, "response_body") or ""
        matches = []

        if json_path:
            try:
                from jsonpath_ng import parse as jp_parse
                expr = jp_parse(json_path)
                data = json.loads(body)
                matches = [str(m.value) for m in expr.find(data)]
            except Exception as e:
                return json.dumps({"error": f"JSONPath error: {e}"})

        elif css_selector:
            try:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(body, "lxml")
                elements = soup.select(css_selector)
                for el in elements:
                    if el.get("value"):
                        matches.append(el["value"])
                    elif el.string:
                        matches.append(el.string.strip())
                    else:
                        matches.append(el.get_text(strip=True)[:200])
            except Exception as e:
                return json.dumps({"error": f"CSS selector error: {e}"})

        elif regex:
            try:
                found = re.findall(regex, body)
                matches = [str(m) for m in found]
            except Exception as e:
                return json.dumps({"error": f"Regex error: {e}"})

        return json.dumps({
            "flow_id": flow_id,
            "extractor": "json_path" if json_path else "css_selector" if css_selector else "regex",
            "expression": json_path or css_selector or regex,
            "matches": matches[:20],
        }, indent=2)

    @mcp.tool()
    async def clear_traffic() -> str:
        """Clear all captured traffic from the database."""
        count = traffic_db.clear()
        return json.dumps({"cleared": count, "status": "ok"})

    @mcp.tool()
    async def generate_curl(flow_id: str) -> str:
        """Generate a curl command for a captured flow. Useful for exporting to terminal or Burp Suite.
        Args:
            flow_id: The flow ID to generate curl for
        """
        cmd = traffic_db.generate_curl(flow_id)
        if not cmd:
            return json.dumps({"error": f"Flow {flow_id} not found"})
        return json.dumps({"flow_id": flow_id, "curl": cmd}, indent=2)

    # ── Replay & Raw Send ──

    @mcp.tool()
    async def replay_flow(
        flow_id: str,
        replacements: list[dict] = None,
        follow_redirects: bool = True,
    ) -> str:
        """Replay a captured flow with optional regex-based modifications.
        Like Burp Repeater: take an existing request, modify parts with regex, and resend.
        Args:
            flow_id: The flow to replay
            replacements: List of {regex: str, replacement: str} for partial modification
            follow_redirects: Follow HTTP redirects (default true)
        """
        import httpx

        flow = traffic_db.get_flow_for_replay(flow_id)
        if not flow:
            return json.dumps({"error": f"Flow {flow_id} not found"})

        # Apply regex replacements to the raw request
        url = flow["url"]
        headers = flow["headers"].copy()
        body = flow["body"]

        # Substitute session variables: {{varname}} → saved value
        session_vars = traffic_db.get_all_session_vars()
        if session_vars:
            for var_name, var_value in session_vars.items():
                placeholder = "{{" + var_name + "}}"
                url = url.replace(placeholder, var_value)
                if body:
                    body = body.replace(placeholder, var_value)
                headers = {k: v.replace(placeholder, var_value) for k, v in headers.items()}

        if replacements:
            for r in replacements:
                pattern = r.get("regex", "")
                repl = r.get("replacement", "")
                url = re.sub(pattern, repl, url)
                body = re.sub(pattern, repl, body) if body else body
                headers = {
                    k: re.sub(pattern, repl, v)
                    for k, v in headers.items()
                }

        # Remove hop-by-hop headers (case-insensitive)
        hop_by_hop = {"host", "content-length", "transfer-encoding"}
        headers = {k: v for k, v in headers.items() if k.lower() not in hop_by_hop}

        start = time.monotonic()
        try:
            async with httpx.AsyncClient(verify=False, follow_redirects=follow_redirects, proxy=_proxy_url()) as client:
                resp = await client.request(
                    method=flow["method"],
                    url=url,
                    headers=headers,
                    content=body.encode() if body else None,
                    timeout=30,
                )
            latency = int((time.monotonic() - start) * 1000)

            resp_body = resp.text
            return json.dumps({
                "status_code": resp.status_code,
                "latency_ms": latency,
                "headers": dict(resp.headers),
                "body": resp_body[:10000],
                "body_truncated": len(resp_body) > 10000,
                "applied_replacements": len(replacements or []),
            }, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def send_raw_request(
        raw: str,
        host: str = None,
        port: int = None,
        tls: bool = True,
        follow_redirects: bool = True,
        approved: bool = False,
    ) -> str:
        """Send a raw HTTP request directly (no proxy needed).
        Like Burp's "Send to Repeater" — construct any request including multipart file uploads.
        Args:
            raw: Complete raw HTTP request (method, headers, body)
            host: Target host (overrides Host header if provided)
            port: Target port (default: 443 for TLS, 80 for plain)
            tls: Use HTTPS (default true)
            follow_redirects: Follow redirects (default true)
            approved: MUST be set to true if the human user has explicitly approved this potentially destructive action.
        """
        if not approved:
            return json.dumps({"error": "HITL Gateway: Sending raw HTTP requests may include destructive payloads. Obtain explicit user approval, then call again with approved=true."})
            
        import httpx

        lines = raw.strip().split("\n")
        if not lines:
            return json.dumps({"error": "Empty request"})

        # Parse request line
        first_line = lines[0].strip()
        parts = first_line.split(" ", 2)
        if len(parts) < 2:
            return json.dumps({"error": f"Invalid request line: {first_line}"})

        method = parts[0]
        path = parts[1]

        # Parse headers and body
        headers = {}
        body_start = None
        for i, line in enumerate(lines[1:], 1):
            stripped = line.strip()
            if stripped == "":
                body_start = i + 1
                break
            if ": " in stripped:
                key, value = stripped.split(": ", 1)
                headers[key] = value

        body = "\n".join(lines[body_start:]) if body_start and body_start < len(lines) else None

        # Determine host
        if not host:
            host = headers.get("Host", headers.get("host", ""))
        if not host:
            return json.dumps({"error": "Host is required"})

        # SSRF Protection
        import ipaddress
        clean_host = host.split(":")[0]  # strip port if present
        try:
            ip = ipaddress.ip_address(clean_host)
            if ip.is_loopback or ip.is_private or ip.is_reserved:
                return json.dumps({"error": f"HITL SSRF Blocked: Cannot target private/loopback IP ({clean_host}). Action denied."})
        except ValueError:
            if clean_host.lower() in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
                return json.dumps({"error": "HITL SSRF Blocked: Cannot target local network host. Action denied."})

        # Build URL
        scheme = "https" if tls else "http"
        actual_port = port or (443 if tls else 80)
        if (tls and actual_port == 443) or (not tls and actual_port == 80):
            url = f"{scheme}://{host}{path}"
        else:
            url = f"{scheme}://{host}:{actual_port}{path}"

        # Remove hop-by-hop (case-insensitive)
        hop_by_hop = {"host", "content-length", "transfer-encoding"}
        headers = {k: v for k, v in headers.items() if k.lower() not in hop_by_hop}

        start = time.monotonic()
        try:
            async with httpx.AsyncClient(verify=False, follow_redirects=follow_redirects, proxy=_proxy_url()) as client:
                resp = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    content=body.encode() if body else None,
                    timeout=30,
                )
            latency = int((time.monotonic() - start) * 1000)

            resp_body = resp.text
            return json.dumps({
                "status_code": resp.status_code,
                "latency_ms": latency,
                "headers": dict(resp.headers),
                "body": resp_body[:10000],
                "body_truncated": len(resp_body) > 10000,
            }, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    # ── Interception Rules ──

    @mcp.tool()
    async def add_interception_rule(
        url_pattern: str,
        action: str,
        resource_type: str = "request",
        key: str = None,
        value: str = None,
        search_pattern: str = None,
        method: str = None,
    ) -> str:
        """Add a dynamic traffic interception rule to the proxy.
        Rules modify traffic in real-time as it passes through the proxy.
        Args:
            url_pattern: Regex pattern to match URLs
            action: inject_header, replace_body, or block
            resource_type: request or response (default: request)
            key: Header name (for inject_header)
            value: Header value (for inject_header) or replacement text (for replace_body)
            search_pattern: Regex to find in body (for replace_body)
            method: Only match this HTTP method (optional)
        """
        rule_id = f"r-{uuid.uuid4().hex[:8]}"
        traffic_db.add_rule(
            rule_id,
            url_pattern=url_pattern,
            action_type=action,
            resource_type=resource_type,
            key=key,
            value=value,
            search_pattern=search_pattern,
            method=method,
        )
        return json.dumps({"rule_id": rule_id, "active": True})

    @mcp.tool()
    async def remove_interception_rule(rule_id: str) -> str:
        """Remove an active interception rule by ID.
        Args:
            rule_id: The rule ID to remove (e.g. "r-abc12345")
        """
        removed = traffic_db.remove_rule(rule_id)
        if removed:
            return json.dumps({"status": "removed", "rule_id": rule_id})
        return json.dumps({"error": f"Rule {rule_id} not found"})

    @mcp.tool()
    async def list_interception_rules() -> str:
        """List all active interception rules."""
        rules = traffic_db.get_active_rules()
        return json.dumps({"total": len(rules), "rules": rules}, indent=2)

    # ── Session Variables ──

    @mcp.tool()
    async def extract_session_variable(
        flow_id: str,
        regex: str,
        name: str,
        source: str = "response_body",
    ) -> str:
        """Extract a value from a flow and save it as a session variable.
        Session variables can be referenced in replay_flow replacements as {{name}}.
        Args:
            flow_id: The flow to extract from
            regex: Regex with one capture group
            name: Variable name to save as
            source: Where to extract from: response_body, response_header, request_header, request_body
        """
        detail = traffic_db.get_detail(flow_id, include=["metadata"])
        if not detail:
            return json.dumps({"error": f"Flow {flow_id} not found"})

        # Use untruncated data for accurate extraction
        raw = traffic_db.get_raw_body(flow_id, source) or ""
        if source in ("response_header", "request_header"):
            # Headers are stored as JSON, already a string
            text = raw
        else:
            text = raw

        match = re.search(regex, text)
        if not match:
            return json.dumps({"error": f"Pattern not found: {regex}"})

        value = match.group(1) if match.lastindex else match.group(0)
        traffic_db.set_session_var(name, value, flow_id)
        return json.dumps({"name": name, "value": value, "source": source})

    @mcp.tool()
    async def list_session_variables() -> str:
        """List all extracted session variables. These can be used in replay_flow as {{name}} placeholders."""
        variables = traffic_db.get_all_session_vars()
        return json.dumps({"total": len(variables), "variables": variables}, indent=2)

    # ── Auth Detection ──

    @mcp.tool()
    async def detect_auth_pattern(flow_ids: str = None) -> str:
        """Analyze traffic flows to detect authentication patterns.
        Detects: JWT, Bearer tokens, API keys, session cookies, CSRF tokens, Basic auth, OAuth2.
        Args:
            flow_ids: Comma-separated flow IDs to analyze (optional, default: all recent)
        """
        if flow_ids:
            ids = [fid.strip() for fid in flow_ids.split(",")]
            flows = []
            for fid in ids:
                detail = traffic_db.get_detail(fid, include=["requestHeaders"])
                if detail:
                    flows.append({
                        "id": detail["id"],
                        "url": detail["url"],
                        "headers": detail.get("request", {}).get("headers", {}),
                    })
        else:
            # Single query instead of N+1
            flows = traffic_db.get_headers_batch(limit=100)

        auth_signals = {
            "jwt": {"detected": False, "signals": [], "flows": []},
            "bearer_token": {"detected": False, "signals": [], "flows": []},
            "api_key": {"detected": False, "signals": [], "flows": []},
            "session_cookie": {"detected": False, "signals": [], "flows": []},
            "csrf": {"detected": False, "signals": [], "flows": []},
            "basic_auth": {"detected": False, "signals": [], "flows": []},
            "oauth2": {"detected": False, "signals": [], "flows": []},
        }

        for f in flows:
            headers = f.get("headers", {})
            fid = f["id"]

            auth_header = headers.get("Authorization", headers.get("authorization", ""))

            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
                auth_signals["bearer_token"]["detected"] = True
                auth_signals["bearer_token"]["flows"].append(fid)
                if token.count(".") == 2:
                    auth_signals["jwt"]["detected"] = True
                    auth_signals["jwt"]["signals"].append("Bearer token is JWT format (3-part dot)")
                    auth_signals["jwt"]["flows"].append(fid)

            if auth_header.startswith("Basic "):
                auth_signals["basic_auth"]["detected"] = True
                auth_signals["basic_auth"]["flows"].append(fid)

            for h, v in headers.items():
                h_lower = h.lower()
                if any(k in h_lower for k in ["x-api-key", "api-key", "apikey", "x-auth-token"]):
                    auth_signals["api_key"]["detected"] = True
                    auth_signals["api_key"]["signals"].append(f"Header: {h}")
                    auth_signals["api_key"]["flows"].append(fid)
                if any(c in h_lower for c in ["csrf", "xsrf", "x-csrf", "x-xsrf"]):
                    auth_signals["csrf"]["detected"] = True
                    auth_signals["csrf"]["signals"].append(f"CSRF header: {h}")
                    auth_signals["csrf"]["flows"].append(fid)

            cookie_header = headers.get("Cookie", headers.get("cookie", ""))
            if cookie_header:
                for cookie in cookie_header.split(";"):
                    c_name = cookie.strip().split("=")[0].lower() if "=" in cookie else ""
                    if any(s in c_name for s in ["session", "sid", "sess", "auth", "phpsessid"]):
                        auth_signals["session_cookie"]["detected"] = True
                        auth_signals["session_cookie"]["signals"].append(f"Cookie: {c_name}")
                        auth_signals["session_cookie"]["flows"].append(fid)

            url_lower = f.get("url", "").lower()
            if any(p in url_lower for p in ["/oauth", "/token", "/authorize", "/auth/callback"]):
                auth_signals["oauth2"]["detected"] = True
                auth_signals["oauth2"]["signals"].append(f"OAuth endpoint: {url_lower}")
                auth_signals["oauth2"]["flows"].append(fid)

        # Deduplicate
        for key in auth_signals:
            auth_signals[key]["flows"] = list(set(auth_signals[key]["flows"]))[:5]
            auth_signals[key]["signals"] = list(set(auth_signals[key]["signals"]))

        detected = [k for k, v in auth_signals.items() if v["detected"]]
        return json.dumps({"detected_auth_types": detected, "details": auth_signals}, indent=2)

    # ── Fuzzing ──

    @mcp.tool()
    async def fuzz_endpoint(
        flow_id: str,
        payloads: list[str],
        target_pattern: str = "FUZZ",
        concurrency: int = 5,
        approved: bool = False,
    ) -> str:
        """Inject a list of payloads into a HTTP request to find vulnerabilities (Fuzzing).
        Replaces the target_pattern (default 'FUZZ') in the URL, Headers, and Body with each payload.
        Automatically measures a baseline and detects anomalies (Status Code, Latency, Content Length, Errors).
        Args:
            flow_id: The base flow to modify and resend. It must contain the target_pattern.
            payloads: List of strings (payloads) to inject.
            target_pattern: The string to replace in the request (default "FUZZ").
            concurrency: Number of concurrent requests to make (default 5).
            approved: MUST be set to true if the human user has explicitly approved this potentially destructive action.
        """
        if not approved:
            return json.dumps({"error": "HITL Gateway: Fuzzing sends high-volume traffic with potentially destructive payloads to the target server. Obtain explicit user approval, then call again with approved=true."})
            
        from .fuzzer import run_fuzz
        
        result = await run_fuzz(
            flow_id=flow_id,
            payloads=payloads,
            target_pattern=target_pattern,
            concurrency=concurrency
        )
        return json.dumps(result, indent=2)
