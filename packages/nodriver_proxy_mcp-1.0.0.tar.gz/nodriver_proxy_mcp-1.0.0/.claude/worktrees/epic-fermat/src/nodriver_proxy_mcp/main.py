"""Nodriver Proxy MCP Server — 39 tools for autonomous pentesting.

Architecture:
  - Code-Mode (1): AI writes Python scripts executed in isolated subprocess
  - Proxy (18): Traffic capture, inspection, replay, fuzzing, rules, session vars via mitmproxy
  - Browser (20): CDP-based Chrome automation via nodriver (anti-bot bypass) + Fetch interception
  - Dashboard: Streamlit-based real-time monitoring UI (separate process)
"""

import logging
from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("nodriver_proxy_mcp")

# Create FastMCP server
mcp = FastMCP(
    "nodriver-proxy-mcp",
    instructions=(
        "39-tool MCP server for autonomous web security testing. "
        "Combines headless proxy (mitmproxy, 18 tools), browser automation (nodriver CDP, 20 tools), "
        "Code-mode (AI-driven Python sandbox, 1 tool).\n\n"
        "## Tool Usage Strategy\n"
        "1. **Autonomous Tool Selection**: You have access to granular tool commands AND a full `execute_security_code` Native Sandbox. "
        "It is fundamentally up to your (the LLM's) judgment to choose the right approach. For simple interactions, use individual tools. "
        "If you detect the need for race conditions, heavy looping (e.g., Blind SQLi), or PoC generation, transition to Code-Mode.\n"
        "2. **Code-Mode for Encoding**: When URL encoding/decoding chains are involved "
        "(double encoding, path traversal, etc.), ALWAYS use code-mode to calculate and verify "
        "with assert statements. Never do multi-layer encoding math in your head.\n"
        "3. **Browser for Recon**: Use browser tools for initial reconnaissance, DOM inspection, "
        "and screenshot capture. Use browser_intercept_request/response for real-time CDP Fetch interception. "
        "Switch to code-mode once the attack vector is identified.\n"
        "4. **Proxy for Traffic Analysis**: Start proxy early to passively capture traffic. "
        "Use search_traffic/inspect_flow to understand API patterns before scripting the exploit. "
        "Use proxy_status to check if the proxy is running. Use list_session_variables to review extracted tokens.\n"
        "5. **Individual Tools for Precision**: Use send_raw_request or replay_flow only when "
        "you need byte-level control over a single request that code-mode can't handle. "
        "replay_flow supports {{varname}} session variable placeholders."
    ),
)

# ── Register all tool modules ──

from nodriver_proxy_mcp.proxy.tools import register_proxy_tools
from nodriver_proxy_mcp.browser.tools import register_browser_tools
from nodriver_proxy_mcp.codemode.tools import register_codemode_tools

register_proxy_tools(mcp)       # 18 tools
register_browser_tools(mcp)     # 20 tools
register_codemode_tools(mcp)     #  1 tool

logger.info("Registered tools: Proxy(18) + Browser(20) + Code-mode(1) = 39")


def main():
    """Entry point for the MCP server."""
    import atexit
    from nodriver_proxy_mcp.proxy.controller import proxy_manager
    from nodriver_proxy_mcp.browser.session_manager import session_manager

    def cleanup():
        """Ensure all child processes are killed on exit."""
        logger.info("Cleaning up zombie processes...")
        try:
            proxy_manager.stop()
        except Exception: pass
        try:
            session_manager.close() # Closes all sessions
        except Exception: pass

    atexit.register(cleanup)

    logger.info("Starting Nodriver Proxy MCP Server v4.0.0")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
