"""Browser MCP tools — 20 tools for browser automation and security testing.

All tools use the SessionManager to communicate with BrowserDaemon processes.
"""

import json
import logging

from ..browser.session_manager import session_manager

logger = logging.getLogger(__name__)


def register_browser_tools(mcp):
    """Register all 20 browser tools with the FastMCP server."""

    # ── Session Management ──

    @mcp.tool()
    async def browser_open(
        session_name: str = "default",
        proxy_port: int = 8082,
        headless: bool = True,
    ) -> str:
        """Open a new browser session (Chrome via CDP with anti-bot bypass).
        Each session is an independent Chrome instance. Use proxy_port to route traffic through mitmproxy.
        Multiple sessions can run simultaneously (e.g. "victim" and "attacker" for IDOR testing).
        Args:
            session_name: Name for this session (default: "default")
            proxy_port: Route all traffic through mitmproxy on this port
            headless: Run headless (default true)
        """
        result = session_manager.open(
            session_name=session_name,
            proxy_port=proxy_port,
            headless=headless,
        )
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_close(session_name: str = "default") -> str:
        """Close a browser session and terminate Chrome.
        Args:
            session_name: Session to close (default: "default")
        """
        result = session_manager.close(session_name)
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_list_sessions() -> str:
        """List all active browser sessions with their status and uptime."""
        sessions = session_manager.list_sessions()
        return json.dumps({"sessions": sessions}, indent=2)


    @mcp.tool()
    async def browser_list_tabs(session_name: str = "default") -> str:
        """List all open tabs in a browser session.
        Args:
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "list_tabs")
        return json.dumps(result, indent=2)

    # ── Navigation ──

    @mcp.tool()
    async def browser_go(
        url: str,
        session_name: str = "default",
        tab_id: str = None,
        wait_for: str = None,
    ) -> str:
        """Navigate to a URL. Waits for page load. Returns page title and any JS dialogs.
        Args:
            url: URL to navigate to
            session_name: Browser session to use
            wait_for: CSS selector to wait for after navigation (for SPA)
        """
        result = await session_manager.send(session_name, "go", {
            "tab_id": tab_id,
            "url": url,
            "wait_for": wait_for,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_back(session_name: str = "default", tab_id: str = None) -> str:
        """Navigate back in browser history.
        Args:
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "back", {"tab_id": tab_id})
        return json.dumps(result, indent=2)

    # ── Page State (client-side only — things proxy can't see) ──

    @mcp.tool()
    async def browser_get_dom(
        selector: str = "body",
        max_depth: int = 4,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Get security-relevant DOM structure. Automatically extracts forms (action, method, inputs, CSRF tokens),
        links, script sources, iframes, meta tags, HTML comments, event handlers, data-* attributes,
        and a simplified DOM tree. This is what the proxy CANNOT see.
        Args:
            selector: Root element to analyze (default: body)
            max_depth: DOM tree depth limit (default: 4)
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "get_dom", {
            "tab_id": tab_id,
            "selector": selector,
            "max_depth": max_depth,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_get_text(
        selector: str,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Get text content of a specific element.
        Args:
            selector: CSS selector
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "get_text", {
            "tab_id": tab_id,
            "selector": selector,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_get_storage(
        storage_type: str = "both",
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Read browser localStorage and/or sessionStorage. Use this to find JWT tokens,
        API keys, or sensitive data stored client-side. Proxy CANNOT see this data.
        Args:
            storage_type: "local", "session", or "both" (default: "both")
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "get_storage", {
            "tab_id": tab_id,
            "storage_type": storage_type,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_get_console(
        level: str = "all",
        clear: bool = False,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Get JavaScript console output. Look for error messages that reveal stack traces,
        internal API URLs, or debug information. Proxy CANNOT see JS console.
        Args:
            level: Filter by level: "all", "error", "warning" (default: "all")
            clear: Clear the console buffer after reading
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "get_console", {
            "tab_id": tab_id,
            "level": level,
            "clear": clear,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_screenshot(
        selector: str = None,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Take a screenshot of the current page. Useful for verifying bot challenges,
        CAPTCHA pages, or visual confirmation of state.
        Args:
            selector: CSS selector to capture (optional, captures full page if omitted)
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "screenshot", {
            "tab_id": tab_id,
            "selector": selector,
        })
        return json.dumps(result, indent=2)

    # ── Interaction ──

    @mcp.tool()
    async def browser_click(
        selector: str = None,
        text: str = None,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Click an element. Returns any JS dialogs triggered (XSS alert detection).
        Use either CSS selector or text content to find the element.
        Args:
            selector: CSS selector to click
            text: Text content to find and click (uses best_match)
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "click", {
            "tab_id": tab_id,
            "selector": selector,
            "text": text,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_type(
        selector: str,
        text: str,
        clear: bool = True,
        press_enter: bool = False,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Type text into an input field. Use for login forms, search fields, payload injection.
        Args:
            selector: CSS selector for the input element
            text: Text to type (can include XSS/SQLi payloads)
            clear: Clear existing content first (default true)
            press_enter: Press Enter after typing (default false)
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "type", {
            "tab_id": tab_id,
            "selector": selector,
            "text": text,
            "clear": clear,
            "press_enter": press_enter,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_set_cookie(
        name: str,
        value: str,
        domain: str = None,
        path: str = "/",
        http_only: bool = False,
        secure: bool = False,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Set a cookie in the browser via CDP. Can set httpOnly cookies (unlike document.cookie).
        Use for IDOR testing: inject another user's session cookie.
        Args:
            name: Cookie name
            value: Cookie value
            domain: Cookie domain (default: current page domain)
            path: Cookie path (default: /)
            http_only: Set HttpOnly flag
            secure: Set Secure flag
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "set_cookie", {
            "tab_id": tab_id,
            "name": name,
            "value": value,
            "domain": domain,
            "path": path,
            "http_only": http_only,
            "secure": secure,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_js(
        expression: str,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Execute JavaScript in the browser. Use for CSRF token extraction, DOM-based XSS testing,
        fetch API hooking, event listener inspection, or any client-side analysis.
        Args:
            expression: JavaScript expression to evaluate
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "js", {
            "tab_id": tab_id,
            "expression": expression,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_wait(
        selector: str = None,
        text: str = None,
        timeout: int = 10,
        session_name: str = "default",
        tab_id: str = None,
    ) -> str:
        """Wait for an element to appear. Use for SPA loading, AJAX completion, or dynamic content.
        Args:
            selector: CSS selector to wait for
            text: Text content to wait for
            timeout: Max wait time in seconds (default: 10)
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "wait", {
            "tab_id": tab_id,
            "selector": selector,
            "text": text,
            "timeout": timeout,
        })
        return json.dumps(result, indent=2)

    # ── CDP Fetch Interception ──

    @mcp.tool()
    async def browser_intercept_request(
        url_pattern: str,
        action: str,
        key: str = None,
        value: str = None,
        session_name: str = "default",
    ) -> str:
        """Intercept and modify outgoing browser requests in real-time via CDP Fetch API.
        Unlike proxy interception rules (which have 5s cache delay), this applies instantly
        at the browser level before the request leaves Chrome.
        Args:
            url_pattern: Regex pattern to match request URLs
            action: inject_header, modify_url, or block
            key: Header name (for inject_header)
            value: Header value (for inject_header) or new URL (for modify_url)
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "add_intercept_rule", {
            "url_pattern": url_pattern,
            "action": action,
            "stage": "request",
            "key": key,
            "value": value,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_intercept_response(
        url_pattern: str,
        action: str,
        search_pattern: str = None,
        value: str = None,
        session_name: str = "default",
    ) -> str:
        """Intercept and modify browser responses in real-time via CDP Fetch API.
        Useful for testing CSP bypass, response tampering, or injecting payloads into responses.
        Args:
            url_pattern: Regex pattern to match request URLs
            action: replace_body or block
            search_pattern: Regex to find in response body (for replace_body)
            value: Replacement text (for replace_body)
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "add_intercept_rule", {
            "url_pattern": url_pattern,
            "action": action,
            "stage": "response",
            "search_pattern": search_pattern,
            "value": value,
        })
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_intercept_disable(session_name: str = "default") -> str:
        """Disable all CDP Fetch interception and clear all rules for this browser session.
        Args:
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "disable_intercept")
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def browser_list_intercept_rules(session_name: str = "default") -> str:
        """List all active CDP Fetch interception rules for this browser session.
        Args:
            session_name: Browser session to use
        """
        result = await session_manager.send(session_name, "list_intercept_rules")
        return json.dumps(result, indent=2)

