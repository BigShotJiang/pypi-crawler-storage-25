import asyncio
import json
import os
from nodriver_proxy_mcp.sdk import NdpSDK

async def main():
    sdk = NdpSDK()
    
    print("=== [STEP 1] Proxy Management Test ===")
    # 프록시 시작 시도
    proxy_res = await sdk.manage_proxy("start", port=8082)
    print(f"Proxy Start Result: {proxy_res}")
    
    print("\n=== [STEP 2] Browser Session Test ===")
    # 브라우저 세션 오픈 (프록시 8082 경유)
    browser_res = await sdk.browser_open(session_name="verification", proxy_port=8082, headless=True)
    print(f"Browser Open Result: {browser_res}")
    
    print("\n=== [STEP 3] Navigation and DOM Analysis ===")
    # example.com 이동
    nav_res = await sdk.browser_go("https://example.com", session_name="verification")
    print(f"Navigation Title: {nav_res.get('result', {}).get('title')}")
    
    # DOM 정보 추출 (16개 브라우저 도구 중 하나)
    dom_res = await sdk.browser_get_dom(session_name="verification")
    print(f"DOM Links Count: {len(dom_res.get('links', []))}")
    
    print("\n=== [STEP 4] Traffic Analysis (Proxy DB) ===")
    # 방금 발생한 트래픽 검색 (13개 프록시 도구 중 하나)
    traffic_res = await sdk.search_traffic(domain="example.com")
    print(f"Found example.com flows: {traffic_res.get('total', 0)}")
    
    if traffic_res.get('flows'):
        flow_id = traffic_res['flows'][0]['id']
        detail = await sdk.inspect_flow(flow_id)
        print(f"Flow ID: {flow_id}, Method: {detail.get('method')}")
    
    print("\n=== [STEP 5] Cleanup ===")
    # 세션 종료
    await sdk.browser_close("verification")
    print("Verification Completed.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
