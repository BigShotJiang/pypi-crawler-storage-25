# ComplianceRuleSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The rule ID. | 
**name** | **str** | The rule name. | 

## Example

```python
from arthur_client.api_bindings.models.compliance_rule_summary import ComplianceRuleSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceRuleSummary from a JSON string
compliance_rule_summary_instance = ComplianceRuleSummary.from_json(json)
# print the JSON string representation of the object
print(ComplianceRuleSummary.to_json())

# convert the object into a dict
compliance_rule_summary_dict = compliance_rule_summary_instance.to_dict()
# create an instance of ComplianceRuleSummary from a dict
compliance_rule_summary_from_dict = ComplianceRuleSummary.from_dict(compliance_rule_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


