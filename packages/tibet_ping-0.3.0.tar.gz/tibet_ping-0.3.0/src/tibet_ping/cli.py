"""
tibet-ping CLI — protocol + transport + MUX diagnostics in one tool.

Usage:
    tibet-ping <target>                 Ping a JIS DID (proto only)
    tibet-ping <ip-address>             Legacy ping (easter egg)
    tibet-ping demo                     Run proto demo
    tibet-ping listen [--port] [--did]  Start node, listen for pings
    tibet-ping send <did> <addr> <intent>   Send ping over UDP
    tibet-ping discover [--port] [--did]    Broadcast LAN discovery
    tibet-ping net-demo                 Run two-node transport demo
    tibet-ping mux <host:port>          ClusterMux diagnostics (RTT, bench, verify)
    tibet-ping stack [--mux ...]        Full TIBET stack health check
"""

import sys
import time
import random
import re

from . import __version__
from .node import PingNode
from .proto import PingType, PingDecision


# ── Easter Egg ───────────────────────────────────────────────

LIONEL_RICHIE_IPS = [
    "88.33.294.66",   # Not even a valid IP. Legend.
    "127.0.0.1",
    "0.0.0.0",
]

LEGACY_PAYLOADS = [
    '"Hello, is it me you\'re looking for?"',
    '"I\'ve been alone with you inside my mind"',
    '"You\'re once, twice, three times a lady"',
    '"Oh what a feeling, when we\'re dancing on the ceiling"',
    '"All night long (All night)"',
    '"Cause I wonder where you route, and I wonder what you do"',
    '"Are you somewhere feeling lonely, is someone pinging you?"',
    '"Tell me how to sync the state, for I haven\'t got a clue"',
    '"But let me start by saying... DROP PACKET. Who are you?"',
]

LEGACY_WARNINGS = [
    "Warning: Legacy ping rejected by TIBET-verify.",
    "Warning: No JIS identity. No intent. No trust. Just vibes.",
    "Warning: This packet has zero provenance. The CISO is crying.",
    "Warning: ICMP has no ERACHTER. Why are you even pinging?",
    "Warning: Nonce missing. Replay attack trivial. Lionel approves.",
]


def _is_ip_address(target: str) -> bool:
    """Check if target looks like an IP address (even invalid ones)."""
    return bool(re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', target))


def _easter_egg_legacy_ping(target: str) -> None:
    """Fake ICMP ping output with Lionel Richie wisdom."""
    print(f"PING {target} ({target}): 56 data bytes")

    for seq in range(4):
        time.sleep(0.3 + random.random() * 0.4)
        ttl = random.choice([52, 54, 56, 58, 60, 62, 64])
        ms = round(8 + random.random() * 30, 1)
        payload = random.choice(LEGACY_PAYLOADS)
        print(f"76 bytes from {target}: icmp_seq={seq} ttl={ttl} time={ms} ms")
        print(f'  Payload: {payload}')

    print()
    print(random.choice(LEGACY_WARNINGS))
    print("Upgrade to cryptographically verified intent:")
    print("  pip install tibet-ping")
    print("  https://pypi.org/project/tibet-ping/")
    print()
    print("  from tibet_ping import PingNode")
    print('  node = PingNode("jis:your:device")')
    print('  node.ping("jis:target:device", intent="hello", purpose="Actually useful")')


# ── Proto-only commands ──────────────────────────────────────

def _cmd_ping(target: str) -> None:
    """Ping a JIS DID (proto layer — creates packet, no transport)."""
    node = PingNode("jis:cli:local")
    pkt = node.ping(
        target=target,
        intent="discover",
        purpose="CLI ping",
    )
    print(f"TIBET-PING {target}")
    print(f"  Packet:  {pkt.packet_id}")
    print(f"  Intent:  {pkt.intent}")
    print(f"  Nonce:   {pkt.nonce[:16]}...")
    print(f"  Type:    {pkt.ping_type.value}")
    print()
    print("Use 'tibet-ping send' to send over UDP transport.")


def _cmd_demo() -> None:
    """Run the proto-level demo scenario."""
    from .airlock import AirlockRule, AirlockZone

    print("=" * 60)
    print(f"  tibet-ping v{__version__} — Protocol Demo")
    print("=" * 60)
    print()

    hub = PingNode("jis:home:hub")
    sensor = PingNode("jis:home:sensor_temp")
    stranger = PingNode("jis:evil:lockpicker")

    hub.set_trust("jis:home:sensor_temp", 0.9)

    # Test 1: Trusted
    pkt = sensor.ping("jis:home:hub", "temperature.report", "Reading", payload={"celsius": 21.5})
    resp = hub.receive(pkt)
    print(f"[1] Trusted sensor -> hub:  {resp.decision.value} ({resp.airlock_zone})")

    # Test 2: Stranger
    pkt = stranger.ping("jis:home:hub", "door.unlock", "Let me in")
    resp = hub.receive(pkt)
    print(f"[2] Stranger -> hub:        {resp.decision.value} ({resp.airlock_zone})")

    # Test 3: Replay
    pkt = sensor.ping("jis:home:hub", "temp.read", "Again")
    hub.receive(pkt)
    resp = hub.receive(pkt)
    print(f"[3] Replay attack:          {resp.decision.value} ({resp.payload.get('reason', '')})")

    # Test 4: Vouch
    hub.vouch(["jis:home:s1"], my_trust=0.9, vouch_factor=0.8)
    s1 = PingNode("jis:home:s1")
    pkt = s1.ping("jis:home:hub", "smoke.alert", "Smoke!")
    resp = hub.receive(pkt)
    print(f"[4] Vouched device -> hub:  {resp.decision.value} (trust: {resp.trust_score:.2f})")

    # Test 5: Beacon
    hub.beacon_handler.auto_vouch_rules = [{"name": "Sensors", "device_type": "sensor"}]
    new = PingNode("jis:home:new")
    b = new.broadcast_beacon(device_type="sensor")
    br = hub.handle_beacon(b)
    print(f"[5] Beacon auto-vouch:      {br.decision}")

    print()
    print("All systems nominal. No Lionel Richies were harmed.")


# ── Transport commands ───────────────────────────────────────

def _cmd_listen(args) -> None:
    """Start node, listen for incoming pings over UDP."""
    import asyncio
    from .transport.udp import TransportConfig, DEFAULT_PORT
    from .transport.iot_node import IoTNode

    port = getattr(args, 'port', DEFAULT_PORT)
    did = getattr(args, 'did', 'jis:iot:node')

    async def _run():
        config = TransportConfig(bind_port=port)
        node = IoTNode(did, config=config)
        await node.start()
        print(f"Listening on :{port} as {did}")
        print("Press Ctrl+C to stop")
        try:
            await asyncio.Event().wait()
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass
        finally:
            await node.stop()

    asyncio.run(_run())


def _cmd_send(args) -> None:
    """Send a ping to a target over UDP."""
    import asyncio
    from .transport.udp import TransportConfig
    from .transport.iot_node import IoTNode

    host, port_str = args.addr.rsplit(":", 1)
    target_addr = (host, int(port_str))

    async def _run():
        config = TransportConfig(bind_port=args.port)
        node = IoTNode(args.my_did, config=config)
        await node.start()

        print(f"Sending ping to {args.did} at {args.addr}")
        print(f"  intent: {args.intent}")
        print(f"  purpose: {args.purpose}")

        try:
            response = await node.send_ping(
                target=args.did,
                addr=target_addr,
                intent=args.intent,
                purpose=args.purpose,
            )
            if response:
                print(f"\nResponse: {response.decision.value}")
                print(f"  zone: {response.airlock_zone}")
                print(f"  trust: {response.trust_score}")
                if response.payload:
                    print(f"  payload: {response.payload}")
            else:
                print("\nNo response (timeout)")
        finally:
            await node.stop()

    asyncio.run(_run())


def _cmd_discover(args) -> None:
    """Broadcast LAN discovery."""
    import asyncio
    from .transport.udp import TransportConfig, DEFAULT_PORT
    from .transport.iot_node import IoTNode

    port = getattr(args, 'port', DEFAULT_PORT)
    did = getattr(args, 'did', 'jis:iot:node')
    timeout = getattr(args, 'timeout', 5.0)

    async def _run():
        config = TransportConfig(bind_port=port)
        node = IoTNode(did, config=config)

        discovered: list[str] = []

        async def on_found(did_found: str, addr: tuple, resp: object) -> None:
            discovered.append(f"{did_found} at {addr[0]}:{addr[1]}")
            print(f"  Found: {did_found} at {addr[0]}:{addr[1]}")

        node.discovery.on_discovered(on_found)
        await node.start()

        print(f"Broadcasting discovery as {did}...")
        await node.discovery.broadcast_discover()

        print(f"Listening for {timeout}s...")
        await asyncio.sleep(timeout)

        await node.stop()
        print(f"\nDiscovered {len(discovered)} peer(s)")

    asyncio.run(_run())


def _cmd_net_demo() -> None:
    """Demo: two nodes on localhost, ping back and forth over UDP."""
    import asyncio
    from .transport.udp import TransportConfig
    from .transport.iot_node import IoTNode

    async def _run():
        print("=" * 60)
        print(f"  tibet-ping v{__version__} — Transport Demo")
        print("=" * 60)
        print()

        config_a = TransportConfig(bind_port=17150)
        config_b = TransportConfig(bind_port=17151)

        node_a = IoTNode("jis:demo:hub", config=config_a, heartbeat_interval=300, discovery_interval=300)
        node_b = IoTNode("jis:demo:sensor", config=config_b, heartbeat_interval=300, discovery_interval=300)

        node_a.set_trust("jis:demo:sensor", 0.9)

        await node_a.start()
        await node_b.start()

        print(f"Node A (hub):    {node_a.device_did} on :17150")
        print(f"Node B (sensor): {node_b.device_did} on :17151")
        print()

        # Sensor pings hub
        print("1. Sensor -> Hub: temperature.report")
        response = await node_b.send_ping(
            target="jis:demo:hub",
            addr=("127.0.0.1", 17150),
            intent="temperature.report",
            purpose="Demo temperature reading",
            payload={"celsius": 21.5},
        )

        if response:
            print(f"   Response: {response.decision.value} (zone: {response.airlock_zone})")
            print(f"   Trust: {response.trust_score}")
        else:
            print("   No response (timeout)")

        print()

        # Unknown node pings hub
        config_c = TransportConfig(bind_port=17152)
        node_c = IoTNode("jis:demo:unknown", config=config_c, heartbeat_interval=300, discovery_interval=300)
        await node_c.start()

        print("2. Unknown -> Hub: door.unlock (should be ROOD)")
        response = await node_c.send_ping(
            target="jis:demo:hub",
            addr=("127.0.0.1", 17150),
            intent="door.unlock",
            purpose="Unauthorized access attempt",
            timeout=3.0,
        )

        if response:
            print(f"   Response: {response.decision.value}")
        else:
            print("   No response (silent drop -- ROOD)")

        print()
        print("Hub stats:", node_a.stats()["peers"])

        await node_a.stop()
        await node_b.stop()
        await node_c.stop()
        print("\n=== Demo complete ===")

    asyncio.run(_run())


# ── MUX Diagnostics ─────────────────────────────────────────

def _cmd_mux(args) -> None:
    """ClusterMux diagnostics — RTT, throughput bench, integrity verify."""
    import asyncio
    import json
    import hashlib

    endpoint = args.endpoint
    bench_blocks = getattr(args, 'bench', 0)
    verify = getattr(args, 'verify', False)

    async def _run():
        print(f"tibet-ping mux {endpoint}")
        print(f"{'=' * 56}")

        # ── Step 1: TCP connect + RTT ──
        t0 = time.time()
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(*_parse_host_port(endpoint)),
                timeout=5.0,
            )
        except (ConnectionRefusedError, OSError) as e:
            print(f"  FAIL: Cannot connect to {endpoint}")
            print(f"  Error: {e}")
            print(f"\n  Is the RAM RAID server running?")
            print(f"  Start with: tibet-dgx serve --bind {endpoint}")
            return
        except asyncio.TimeoutError:
            print(f"  FAIL: Connection timeout to {endpoint}")
            print(f"  Check: firewall, port, network route")
            return

        connect_ms = (time.time() - t0) * 1000
        print(f"  TCP connect:    {connect_ms:.1f}ms")

        # MUX echo ping — send small block, measure RTT from response
        # ClusterMux uses length-prefixed binary frames
        # We do 5 sequential TCP connect + first-byte tests for RTT
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        rtts = []
        for i in range(5):
            try:
                t1 = time.time()
                r, w = await asyncio.wait_for(
                    asyncio.open_connection(*_parse_host_port(endpoint)),
                    timeout=3.0,
                )
                rtt_us = int((time.time() - t1) * 1_000_000)
                rtts.append(rtt_us)
                w.close()
                try:
                    await w.wait_closed()
                except Exception:
                    pass
            except Exception:
                rtts.append(-1)

        valid_rtts = [r for r in rtts if r >= 0]
        if valid_rtts:
            valid_rtts.sort()
            print(f"  MUX RTT:        min={valid_rtts[0]}µs, median={valid_rtts[len(valid_rtts)//2]}µs, max={valid_rtts[-1]}µs")
            print(f"  Pings:          {len(valid_rtts)}/5 OK")
        else:
            print(f"  MUX RTT:        all 5 connect attempts failed")
            print(f"  Server may be overloaded or dropping connections")

        # ── Step 2: Throughput bench ──
        if bench_blocks > 0:
            print(f"\n  Benchmark: {bench_blocks} × 2MB blocks")
            try:
                reader2, writer2 = await asyncio.wait_for(
                    asyncio.open_connection(*_parse_host_port(endpoint)),
                    timeout=5.0,
                )
                block_size = 2 * 1024 * 1024
                test_data = bytes(range(256)) * (block_size // 256)
                test_hash = hashlib.sha256(test_data).hexdigest()

                # Store
                t2 = time.time()
                for i in range(bench_blocks):
                    store_frame = json.dumps({
                        "type": "Store",
                        "channel_id": i + 1,
                        "block_index": i,
                        "from_aint": "tibet-ping.aint",
                        "content_hash": test_hash,
                        "ed25519_seal": "bench",
                        "raw_size": block_size,
                        "bus_seq": i,
                    }).encode()
                    store_len = len(store_frame).to_bytes(4, 'big')
                    writer2.write(store_len + store_frame)
                    await writer2.drain()

                    # Send payload
                    payload_len = len(test_data).to_bytes(4, 'big')
                    writer2.write(payload_len + test_data)
                    await writer2.drain()

                    # Read response
                    resp_len_bytes = await asyncio.wait_for(reader2.readexactly(4), timeout=10.0)
                    resp_len = int.from_bytes(resp_len_bytes, 'big')
                    await asyncio.wait_for(reader2.readexactly(resp_len), timeout=10.0)

                store_s = time.time() - t2
                store_mbps = (bench_blocks * block_size) / 1_000_000 / max(store_s, 0.001)
                print(f"  Store:          {bench_blocks} blocks in {store_s:.2f}s ({store_mbps:.0f} MB/s)")

                writer2.close()
                try:
                    await writer2.wait_closed()
                except Exception:
                    pass
            except Exception as e:
                print(f"  Bench failed: {e}")
                print(f"  (MUX bench requires tibet-dgx serve or ram-raid-cluster-demo server)")

        # ── Step 3: Integrity verify ──
        if verify:
            print(f"\n  Integrity: store → fetch → SHA-256 verify")
            try:
                reader3, writer3 = await asyncio.wait_for(
                    asyncio.open_connection(*_parse_host_port(endpoint)),
                    timeout=5.0,
                )
                test_block = b"tibet-ping integrity test " + str(time.time()).encode()
                test_block = test_block.ljust(4096, b'\x00')
                expected_hash = hashlib.sha256(test_block).hexdigest()
                print(f"  Block size:     {len(test_block)} bytes")
                print(f"  Expected SHA:   {expected_hash[:32]}...")
                print(f"  Status:         store → fetch → verify pipeline ready")
                print(f"  (Full verify requires MUX protocol — use tibet-dgx bench for now)")

                writer3.close()
                try:
                    await writer3.wait_closed()
                except Exception:
                    pass
            except Exception as e:
                print(f"  Verify failed: {e}")

        # ── Summary ──
        print(f"\n{'=' * 56}")
        status = "REACHABLE" if valid_rtts else "TCP OK, MUX UNKNOWN"
        print(f"  {endpoint}: {status}")
        if valid_rtts:
            avg_ms = sum(valid_rtts) / len(valid_rtts) / 1000
            print(f"  Avg RTT: {avg_ms:.2f}ms")

    asyncio.run(_run())


def _cmd_stack(args) -> None:
    """Full TIBET stack health check — MUX, AINS, I-Poll, local services."""
    import asyncio
    import json

    mux_endpoint = getattr(args, 'mux', None)
    ains_url = getattr(args, 'ains', 'http://localhost:8000/api/ains')
    ipoll_url = getattr(args, 'ipoll', 'http://localhost:8000/api/ipoll')

    print("tibet-ping stack — TIBET Health Check")
    print("=" * 56)
    results = {}

    # ── AINS ──
    print("\n  [AINS] AInternet Name Service")
    try:
        import urllib.request
        t0 = time.time()
        resp = urllib.request.urlopen(f"{ains_url}/list", timeout=5)
        data = json.loads(resp.read())
        ms = (time.time() - t0) * 1000
        domains = len(data) if isinstance(data, list) else len(data.get('domains', data.get('agents', [])))
        print(f"    Status:   OK ({ms:.0f}ms)")
        print(f"    Domains:  {domains} registered")
        results['ains'] = 'OK'
    except Exception as e:
        print(f"    Status:   FAIL ({e})")
        results['ains'] = 'FAIL'

    # ── I-Poll ──
    print("\n  [I-Poll] AI Messaging")
    try:
        t0 = time.time()
        resp = urllib.request.urlopen(f"{ipoll_url}/status", timeout=5)
        data = json.loads(resp.read())
        ms = (time.time() - t0) * 1000
        print(f"    Status:   OK ({ms:.0f}ms)")
        if isinstance(data, dict):
            for k in ['total_messages', 'agents', 'uptime']:
                if k in data:
                    print(f"    {k}: {data[k]}")
        results['ipoll'] = 'OK'
    except Exception as e:
        print(f"    Status:   FAIL ({e})")
        results['ipoll'] = 'FAIL'

    # ── Brain API ──
    print("\n  [Brain API] Central Nervous System")
    try:
        t0 = time.time()
        resp = urllib.request.urlopen("http://localhost:8000/", timeout=5)
        ms = (time.time() - t0) * 1000
        code = resp.getcode()
        print(f"    Status:   OK ({ms:.0f}ms, HTTP {code})")
        results['brain'] = 'OK'
    except Exception as e:
        print(f"    Status:   FAIL ({e})")
        results['brain'] = 'FAIL'

    # ── MUX (optional) ──
    if mux_endpoint:
        print(f"\n  [MUX] ClusterMux Transport ({mux_endpoint})")
        try:
            async def _mux_check():
                t0 = time.time()
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(*_parse_host_port(mux_endpoint)),
                    timeout=5.0,
                )
                ms = (time.time() - t0) * 1000
                writer.close()
                try:
                    await writer.wait_closed()
                except Exception:
                    pass
                return ms

            ms = asyncio.run(_mux_check())
            print(f"    Status:   OK ({ms:.1f}ms connect)")
            results['mux'] = 'OK'
        except Exception as e:
            print(f"    Status:   FAIL ({e})")
            results['mux'] = 'FAIL'

    # ── Ollama (P520) ──
    print("\n  [Ollama] LLM Backend")
    for name, host in [("localhost", "localhost:11434"), ("P520", "192.168.4.85:11434")]:
        try:
            t0 = time.time()
            resp = urllib.request.urlopen(f"http://{host}/api/tags", timeout=3)
            data = json.loads(resp.read())
            ms = (time.time() - t0) * 1000
            models = len(data.get('models', []))
            print(f"    {name:12s} OK ({ms:.0f}ms, {models} models)")
            results[f'ollama_{name}'] = 'OK'
        except Exception:
            print(f"    {name:12s} UNREACHABLE")
            results[f'ollama_{name}'] = 'FAIL'

    # ── Summary ──
    ok = sum(1 for v in results.values() if v == 'OK')
    total = len(results)
    print(f"\n{'=' * 56}")
    print(f"  {ok}/{total} services healthy")

    if ok == total:
        print("  All systems nominal. T-T-T-TIBET and the checks!")
    else:
        failed = [k for k, v in results.items() if v == 'FAIL']
        print(f"  Down: {', '.join(failed)}")


def _parse_host_port(endpoint: str) -> tuple:
    """Parse host:port string."""
    parts = endpoint.rsplit(":", 1)
    return (parts[0], int(parts[1]))


# ── Main entry point ─────────────────────────────────────────

def _usage() -> None:
    print(f"tibet-ping v{__version__}")
    print()
    print("Protocol commands:")
    print("  tibet-ping <jis:did>             Ping a JIS device (proto only)")
    print("  tibet-ping <ip-address>          Legacy ping (easter egg)")
    print("  tibet-ping demo                  Run protocol demo")
    print()
    print("Transport commands:")
    print("  tibet-ping listen [options]      Start node, listen for pings")
    print("    --port PORT                    UDP port (default: 7150)")
    print("    --did DID                      Device DID (default: jis:iot:node)")
    print()
    print("  tibet-ping send <did> <host:port> <intent> [options]")
    print("    --purpose PURPOSE              Purpose description")
    print("    --port PORT                    Local bind port (0=random)")
    print("    --my-did DID                   Our device DID")
    print()
    print("  tibet-ping discover [options]    Broadcast LAN discovery")
    print("    --port PORT                    UDP port (default: 7150)")
    print("    --did DID                      Device DID")
    print("    --timeout SECS                 Listen timeout (default: 5)")
    print()
    print("  tibet-ping net-demo              Run two-node transport demo")
    print()
    print("MUX diagnostics:")
    print("  tibet-ping mux <host:port>              ClusterMux RTT + connection test")
    print("    --bench N                              Throughput benchmark (N × 2MB blocks)")
    print("    --verify                               SHA-256 integrity roundtrip")
    print()
    print("Stack health:")
    print("  tibet-ping stack                         Full TIBET stack health check")
    print("    --mux <host:port>                      Include ClusterMux in check")
    print()
    print("Examples:")
    print('  tibet-ping jis:home:hub')
    print('  tibet-ping 88.33.294.66')
    print('  tibet-ping listen --did jis:my:hub')
    print('  tibet-ping send jis:hub 192.168.1.10:7150 temperature.report')
    print('  tibet-ping discover --timeout 10')
    print('  tibet-ping mux 10.0.100.1:4432')
    print('  tibet-ping mux 10.0.100.1:4432 --bench 50')
    print('  tibet-ping stack --mux 10.0.100.1:4432')


def main() -> None:
    """CLI entry point."""
    import argparse

    # If no args or simple usage, use the lightweight path
    args = sys.argv[1:]

    if not args or args[0] in ("--help", "-h"):
        _usage()
        return

    command = args[0]

    # Simple commands (no argparse needed)
    if command == "demo":
        _cmd_demo()
        return
    elif _is_ip_address(command):
        _easter_egg_legacy_ping(command)
        return
    elif command not in ("listen", "send", "discover", "net-demo", "mux", "stack"):
        # Treat as JIS DID ping
        _cmd_ping(command)
        return

    # Transport commands — use argparse
    parser = argparse.ArgumentParser(prog="tibet-ping", add_help=False)
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command")

    # listen
    p_listen = sub.add_parser("listen")
    p_listen.add_argument("--port", type=int, default=7150)
    p_listen.add_argument("--did", default="jis:iot:node")

    # send
    p_send = sub.add_parser("send")
    p_send.add_argument("did")
    p_send.add_argument("addr")
    p_send.add_argument("intent")
    p_send.add_argument("--purpose", default="CLI ping")
    p_send.add_argument("--port", type=int, default=0)
    p_send.add_argument("--my-did", default="jis:iot:cli", dest="my_did")

    # discover
    p_disc = sub.add_parser("discover")
    p_disc.add_argument("--port", type=int, default=7150)
    p_disc.add_argument("--did", default="jis:iot:node")
    p_disc.add_argument("--timeout", type=float, default=5.0)

    # net-demo
    sub.add_parser("net-demo")

    # mux
    p_mux = sub.add_parser("mux")
    p_mux.add_argument("endpoint", help="ClusterMux endpoint (host:port)")
    p_mux.add_argument("--bench", type=int, default=0, help="Throughput benchmark (N blocks)")
    p_mux.add_argument("--verify", action="store_true", help="SHA-256 integrity check")

    # stack
    p_stack = sub.add_parser("stack")
    p_stack.add_argument("--mux", default=None, help="ClusterMux endpoint to include")
    p_stack.add_argument("--ains", default="http://localhost:8000/api/ains", help="AINS base URL")
    p_stack.add_argument("--ipoll", default="http://localhost:8000/api/ipoll", help="I-Poll base URL")

    parsed = parser.parse_args(args)

    if parsed.verbose:
        import logging
        logging.basicConfig(level=logging.DEBUG, format="%(name)s %(message)s")

    if parsed.command == "listen":
        _cmd_listen(parsed)
    elif parsed.command == "send":
        _cmd_send(parsed)
    elif parsed.command == "discover":
        _cmd_discover(parsed)
    elif parsed.command == "net-demo":
        _cmd_net_demo()
    elif parsed.command == "mux":
        _cmd_mux(parsed)
    elif parsed.command == "stack":
        _cmd_stack(parsed)


if __name__ == "__main__":
    main()
