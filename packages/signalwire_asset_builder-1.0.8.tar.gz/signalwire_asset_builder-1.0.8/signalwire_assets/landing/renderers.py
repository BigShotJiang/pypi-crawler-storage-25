"""
Section renderers for landing pages.

Each ``_render_*`` function accepts a section dict (and optionally a CTA HTML
string) and returns an HTML fragment.  The ``SECTION_RENDERERS`` dict maps
section type names to their renderer.
"""

import html as html_mod
import os
import re

# ---------------------------------------------------------------------------
# Font Awesome Pro SVG icons (inline, currentColor)
# ---------------------------------------------------------------------------

def _load_icon(name):
    """Load an SVG icon from the bundled assets, strip comments, add sizing."""
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "icons", f"{name}.svg")
    if not os.path.exists(p):
        # Try the design dir icons
        p2 = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "design", "icons_svg", f"{name}.svg")
        if os.path.exists(p2):
            p = p2
        else:
            return ""
    with open(p) as f:
        svg = f.read()
    # Strip XML comments
    svg = re.sub(r'<!--.*?-->', '', svg)
    # Add width/height for consistent inline sizing
    svg = svg.replace('<svg ', '<svg width="1em" height="1em" ', 1)
    return svg.strip()

_ICON_CHECK = _load_icon("circle-check")
_ICON_XMARK = _load_icon("circle-xmark")
_ICON_INFO = _load_icon("circle-info")
_ICON_WARN = _load_icon("triangle-exclamation")
_ICON_DANGER = _load_icon("octagon-exclamation")
_ICON_SUCCESS = _load_icon("circle-check")
_ICON_CHECKMARK = _load_icon("check")

try:
    from pygments import highlight as _pygments_highlight
    from pygments.lexers import get_lexer_by_name, TextLexer
    from pygments.formatters import HtmlFormatter
    _HAS_PYGMENTS = True
except ImportError:
    _HAS_PYGMENTS = False


# ---------------------------------------------------------------------------
# Inline helpers
# ---------------------------------------------------------------------------

def _esc(text):
    """HTML-escape *text*."""
    return html_mod.escape(str(text))


def _inline(text):
    """Process inline markdown: links, bold, code. Returns HTML-safe string."""
    t = html_mod.escape(str(text))
    # Links: [text](url) — must process before bold since links may contain bold
    t = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', t)
    # Bold: **text**
    t = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
    # Inline code: `text`
    t = re.sub(r'`(.+?)`', r'<code>\1</code>', t)
    return t


def _highlight_code(code, language):
    """Syntax highlight code using Pygments, mapped to DTCG token classes.
    Falls back to escaped plain text if Pygments unavailable."""
    if not _HAS_PYGMENTS or not language:
        return html_mod.escape(code)
    try:
        lexer = get_lexer_by_name(language, stripall=True)
    except Exception:
        return html_mod.escape(code)
    formatter = HtmlFormatter(nowrap=True, classprefix="hl-")
    return _pygments_highlight(code, lexer, formatter)


# ---------------------------------------------------------------------------
# Partner logos
# ---------------------------------------------------------------------------

_PARTNER_LOGOS = [
    {"name": "Samsung", "file": "logo_Samsung.svg"},
    {"name": "Audi", "file": "logo_Audi.svg"},
    {"name": "T-Mobile", "file": "logo_T-Mobile.svg"},
    {"name": "Deutsche Telekom", "file": "logo_Deutsche_Telekom.svg", "height": "60px"},
    {"name": "Sprinklr", "file": "logo_Sprinklr.svg"},
    {"name": "Filevine", "file": "logo_Filevine.svg"},
    {"name": "Phoenix Children's", "file": "logo_Phoenix_Childrens.svg"},
    {"name": "Textline", "file": "logo_Textline.svg"},
    {"name": "Replicant", "file": "logo_Replicant.svg"},
    {"name": "Growthzilla", "file": "logo_Growthzilla.svg"},
    {"name": "Prompt.io", "file": "logo_Prompt_IO.svg"},
    {"name": "Vultik", "file": "logo_Vultik.svg"},
    {"name": "McFarland Clinic", "file": "logo_McFarland_Clinic.svg"},
]

_LOGO_SVG_CACHE = {}


def _load_bundled_logo(filename):
    """Load a partner logo SVG from the bundled assets."""
    if filename in _LOGO_SVG_CACHE:
        return _LOGO_SVG_CACHE[filename]
    from importlib import resources as _pkg_resources
    try:
        ref = _pkg_resources.files("signalwire_assets").joinpath("assets", "logos", filename)
        svg = ref.read_text(encoding="utf-8").strip()
        # Normalize <svg\n to <svg so class injection works
        svg = re.sub(r'<svg\s', '<svg ', svg)
        _LOGO_SVG_CACHE[filename] = svg
        return svg
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------

def _render_hero(s, cta_html):
    headline = _esc(s.get("headline", ""))
    subtitle = _esc(s.get("subtitle", ""))
    eyebrow = s.get("eyebrow", "")
    # Wrap last phrase in <em> for emphasis color if headline has a colon or comma
    if ":" in headline:
        parts = headline.split(":", 1)
        headline = f'{parts[0]}: <em>{parts[1].strip()}</em>'
    eyebrow_html = f'<div class="lp-hero__eyebrow">{_esc(eyebrow)}</div>' if eyebrow else ""
    return f"""<section class="lp-hero">
  <div class="lp-container">
    {eyebrow_html}
    <h1 class="lp-hero__title">{headline}</h1>
    <p class="lp-hero__subtitle">{subtitle}</p>
    {cta_html if s.get("cta", True) else ""}
  </div>
</section>"""


def _render_features(s):
    title = _esc(s.get("title", ""))
    eyebrow = s.get("eyebrow", "")
    items = s.get("items", [])
    cards = ""
    for i, item in enumerate(items):
        icon = _esc(item.get("icon", ""))
        label = _esc(item.get("title", ""))
        desc = _inline(item.get("desc", ""))
        icon_html = f'<div class="lp-feature__icon">{icon}</div>' if icon else ""
        delay = f" lp-reveal-d{min(i, 4)}" if i > 0 else ""
        cards += f"""<div class="lp-feature lp-reveal{delay}">
      {icon_html}
      <h3 class="lp-feature__title">{label}</h3>
      <p class="lp-feature__desc">{desc}</p>
    </div>"""
    eyebrow_html = f'<div class="lp-section__eyebrow">{_esc(eyebrow)}</div>' if eyebrow else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {eyebrow_html}
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-features-grid">{cards}</div>
  </div>
</section>"""


def _render_comparison(s):
    title = _esc(s.get("title", ""))
    columns = s.get("columns", [])
    cols_html = ""
    for col in columns:
        label = _esc(col.get("label", ""))
        style = col.get("style", "neutral")
        items = col.get("items", [])
        marker = (_ICON_XMARK or "&#x2717;") if style == "negative" else (_ICON_CHECK or "&#x2713;")
        li_class = "negative" if style == "negative" else "positive"
        items_html = "".join(f'<li class="lp-compare__item lp-compare__item--{li_class}"><span class="lp-compare__marker">{marker}</span> {_esc(i)}</li>' for i in items)
        col_class = f"lp-compare__col lp-compare__col--{style}"
        cols_html += f"""<div class="{col_class}">
      <h3 class="lp-compare__label">{label}</h3>
      <ul class="lp-compare__list">{items_html}</ul>
    </div>"""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-compare">{cols_html}</div>
  </div>
</section>"""


def _render_stats(s):
    title = s.get("title", "")
    items = s.get("items", [])
    stats = ""
    for i, item in enumerate(items):
        val = _esc(item.get("value", ""))
        label = _esc(item.get("label", ""))
        delay = f" lp-reveal-d{min(i, 4)}" if i > 0 else ""
        stats += f'<div class="lp-stat lp-reveal{delay}"><div class="lp-stat__value">{val}</div><div class="lp-stat__label">{label}</div></div>'
    title_html = f'<h2 class="lp-section__title">{_esc(title)}</h2>' if title else ""
    return f"""<section class="lp-section lp-section--stats">
  <div class="lp-container">
    {title_html}
    <div class="lp-stats-row">{stats}</div>
  </div>
</section>"""


_COPY_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>'


def _render_code(s):
    title = _esc(s.get("title", ""))
    lang = s.get("language", "")
    code = _highlight_code(s.get("code", ""), lang)
    lang_label = _esc(lang)
    desc = s.get("desc", "")
    desc_html = f'<p class="lp-code__desc">{_esc(desc)}</p>' if desc else ""
    filename = f'{lang_label}' if lang_label else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    {desc_html}
    <div class="lp-terminal">
      <div class="lp-terminal__bar">
        <div class="lp-terminal__dot"></div>
        <div class="lp-terminal__dot"></div>
        <div class="lp-terminal__dot"></div>
        <span class="lp-terminal__title">{filename}</span>
        <button class="lp-terminal__copy" onclick="lpCopyTerminal(this)">{_COPY_SVG}</button>
      </div>
      <pre class="lp-terminal__body"><code>{code}</code></pre>
    </div>
  </div>
</section>"""


def _render_testimonial(s):
    quote = _inline(s.get("quote", ""))
    name = _esc(s.get("name", ""))
    role = _esc(s.get("role", ""))
    return f"""<section class="lp-section">
  <div class="lp-container">
    <blockquote class="lp-testimonial">
      <p class="lp-testimonial__quote">{quote}</p>
      <footer class="lp-testimonial__attr">
        <strong>{name}</strong>{f", {role}" if role else ""}
      </footer>
    </blockquote>
  </div>
</section>"""


def _render_logos(s):
    title = _esc(s.get("title", "Trusted by"))
    items = ""
    for l in _PARTNER_LOGOS:
        alt = _esc(l["name"])
        h = l.get("height", "")
        style = f' style="max-height:{h}"' if h else ""
        svg = _load_bundled_logo(l["file"])
        if svg:
            svg = svg.replace('<svg ', f'<svg class="lp-logo-img" role="img" aria-label="{alt}"{style} ', 1)
            items += svg
        else:
            items += f'<span class="lp-logo-name">{alt}</span>'
    track = f'{items}{items}'
    return f"""<section class="lp-section lp-section--logos">
  <div class="lp-container">
    <p class="lp-logos__title">{title}</p>
  </div>
  <div class="lp-marquee"><div class="lp-marquee__track">{track}</div></div>
</section>"""


def _render_steps(s):
    title = _esc(s.get("title", ""))
    items = s.get("items", [])
    steps = ""
    for i, item in enumerate(items):
        label = _esc(item.get("label", ""))
        desc = _esc(item.get("desc", ""))
        delay = f" lp-reveal-d{min(i, 4)}" if i > 0 else ""
        steps += f"""<div class="lp-step lp-reveal{delay}">
      <div class="lp-step__number">{i + 1}</div>
      <div class="lp-step__content">
        <h3 class="lp-step__label">{label}</h3>
        <p class="lp-step__desc">{desc}</p>
      </div>
    </div>"""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-steps">{steps}</div>
  </div>
</section>"""


def _render_faq(s):
    title = _esc(s.get("title", "FAQ"))
    items = s.get("items", [])
    faqs = ""
    for item in items:
        q = _esc(item.get("q", ""))
        a = _esc(item.get("a", ""))
        faqs += f"""<details class="lp-faq__item">
      <summary class="lp-faq__q">{q}</summary>
      <p class="lp-faq__a">{a}</p>
    </details>"""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-faq">{faqs}</div>
  </div>
</section>"""


def _render_text(s):
    """Generic text section with title + paragraphs."""
    title = _esc(s.get("title", ""))
    body = s.get("body", [])
    if isinstance(body, str):
        body = [body]
    paras = "".join(f"<p>{_inline(p)}</p>" for p in body)
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    {paras}
  </div>
</section>"""


def _render_table(s):
    """Data table with styled header and hover rows."""
    title = _esc(s.get("title", ""))
    headers = s.get("headers", [])
    rows = s.get("rows", [])
    th = "".join(f"<th>{_esc(h)}</th>" for h in headers)
    tbody = ""
    for row in rows:
        cells = "".join(f'<td>{_inline(c)}</td>' for c in row)
        tbody += f"<tr>{cells}</tr>"
    title_html = f'<h2 class="lp-section__title">{title}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-table-wrap">
      <table class="lp-table">
        <thead><tr>{th}</tr></thead>
        <tbody>{tbody}</tbody>
      </table>
    </div>
  </div>
</section>"""


def _render_callout(s):
    """Colored callout box: info, warn, danger, success."""
    ctype = s.get("style", "info")
    text = _inline(s.get("text", ""))
    title = s.get("title", "")
    icons = {
        "info": _ICON_INFO or "&#x1F4A1;",
        "warn": _ICON_WARN or "&#x26A0;&#xFE0F;",
        "danger": _ICON_DANGER or "&#x1F6A8;",
        "success": _ICON_SUCCESS or "&#x2705;",
    }
    icon = icons.get(ctype, "")
    title_html = f'<strong>{_esc(title)}</strong> ' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <div class="lp-callout lp-callout--{_esc(ctype)}">
      <span class="lp-callout__icon">{icon}</span>
      <div class="lp-callout__body">{title_html}{text}</div>
    </div>
  </div>
</section>
</div>"""


def _render_badges(s):
    """Row of badge pills."""
    items = s.get("items", [])
    colors = ["fuchsia", "blue", "turquoise", "gold", "neutral"]
    badges = ""
    for i, item in enumerate(items):
        text = _esc(item if isinstance(item, str) else item.get("text", ""))
        color = item.get("color", colors[i % len(colors)]) if isinstance(item, dict) else colors[i % len(colors)]
        badges += f'<span class="lp-badge lp-badge--{_esc(color)}">{text}</span>'
    return f"""<section class="lp-section" style="padding:1rem 0">
  <div class="lp-container">
    <div class="lp-badge-row">{badges}</div>
  </div>
</section>"""


def _render_tabs(s):
    """Tabbed code examples inside a terminal window."""
    title = _esc(s.get("title", ""))
    tabs = s.get("tabs", [])
    group = f"tg{abs(hash(title)) % 99999}"
    tab_btns = ""
    panels = ""
    for i, tab in enumerate(tabs):
        label = _esc(tab.get("label", f"Tab {i+1}"))
        lang = tab.get("language", "")
        code = _highlight_code(tab.get("code", ""), lang)
        active = " lp-tab--active" if i == 0 else ""
        show = "" if i == 0 else " style=\"display:none\""
        tab_btns += f'<button class="lp-tab__btn{active}" data-tab="{group}-{i}" onclick="lpTab(this)">{label}</button>'
        panels += f'<div class="lp-tab__panel" id="{group}-{i}"{show}><pre class="lp-terminal__body"><button class="lp-terminal__copy" onclick="lpCopyTerminal(this)" style="position:absolute;top:0.5rem;right:0.75rem">{_COPY_SVG}</button><code>{code}</code></pre></div>'
    title_html = f'<h2 class="lp-section__title">{title}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-terminal">
      <div class="lp-terminal__bar">
        <div class="lp-terminal__dot"></div>
        <div class="lp-terminal__dot"></div>
        <div class="lp-terminal__dot"></div>
        <div class="lp-terminal__tabs">{tab_btns}</div>
      </div>
      {panels}
    </div>
  </div>
</section>"""


def _render_pricing(s):
    """Pricing tier cards in a row."""
    title = _esc(s.get("title", ""))
    tiers = s.get("tiers", [])
    cards = ""
    for i, tier in enumerate(tiers):
        name = _esc(tier.get("name", ""))
        price = _esc(tier.get("price", ""))
        unit = _esc(tier.get("unit", ""))
        desc = _esc(tier.get("desc", ""))
        features = tier.get("features", [])
        featured = tier.get("featured", False)
        cta_text = _esc(tier.get("cta", "Get Started"))
        cta_url = tier.get("url", "#")

        _check = _ICON_CHECKMARK or "&#x2713;"
        feat_html = "".join(f'<li class="lp-pricing__feat"><span class="lp-pricing__check">{_check}</span> {_inline(f)}</li>' for f in features)
        featured_class = " lp-pricing__card--featured" if featured else ""
        badge_html = '<span class="lp-badge lp-badge--fuchsia" style="margin-bottom:1rem;display:inline-block">Popular</span>' if featured else ""
        btn_class = "lp-btn lp-btn--primary" if featured else "lp-btn lp-btn--secondary"

        cards += f"""<div class="lp-pricing__card{featured_class}">
      {badge_html}
      <h3 class="lp-pricing__name">{name}</h3>
      <div class="lp-pricing__price">{price}<span class="lp-pricing__unit">{unit}</span></div>
      <p class="lp-pricing__desc">{desc}</p>
      <ul class="lp-pricing__feats">{feat_html}</ul>
      <a href="{cta_url}" class="{btn_class}" style="width:100%;justify-content:center;margin-top:auto">{cta_text}</a>
    </div>"""
    title_html = f'<h2 class="lp-section__title" style="text-align:center">{title}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-pricing">{cards}</div>
  </div>
</section>"""


def _render_links(s):
    """Row of link cards."""
    title = s.get("title", "")
    items = s.get("items", [])
    links = ""
    for item in items:
        text = _esc(item.get("text", ""))
        url = item.get("url", "#")
        desc = item.get("desc", "")
        desc_html = f'<p class="lp-link-card__desc">{_esc(desc)}</p>' if desc else ""
        links += f"""<a href="{url}" class="lp-link-card">
      <span class="lp-link-card__text">{text}</span>
      {desc_html}
      <span class="lp-link-card__arrow">&rarr;</span>
    </a>"""
    title_html = f'<h2 class="lp-section__title">{_esc(title)}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-links-grid">{links}</div>
  </div>
</section>"""


def _render_cta(s, cta_html):
    headline = _esc(s.get("headline", "Ready to build?"))
    subtitle = s.get("subtitle", "")
    sub_html = f'<p class="lp-cta__subtitle">{_esc(subtitle)}</p>' if subtitle else ""
    return f"""<section class="lp-section lp-section--cta">
  <div class="lp-container lp-cta">
    <h2 class="lp-cta__title">{headline}</h2>
    {sub_html}
    {cta_html}
  </div>
</section>"""


# ---------------------------------------------------------------------------
# Renderer dispatch table
# ---------------------------------------------------------------------------

def _render_swatches(s):
    """Color palette specimen grid."""
    title = _esc(s.get("title", ""))
    groups = s.get("groups", [])
    html = ""
    for group in groups:
        group_label = _esc(group.get("label", ""))
        label_html = f'<h4 class="lp-swatches__label">{group_label}</h4>' if group_label else ""
        swatches = ""
        for swatch in group.get("colors", []):
            name = _esc(swatch.get("name", ""))
            value = _esc(swatch.get("value", ""))
            dark = "lp-swatch--dark" if swatch.get("dark", False) else ""
            swatches += f'<div class="lp-swatch {dark}"><div class="lp-swatch__color" style="background:{value}"></div><div class="lp-swatch__name">{name}</div><div class="lp-swatch__hex">{value}</div></div>'
        html += f'{label_html}<div class="lp-swatch-row">{swatches}</div>'
    title_html = f'<h2 class="lp-section__title">{_esc(title)}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    {html}
  </div>
</section>"""


def _render_anatomy(s):
    """Label/value definition pairs for design specifications."""
    title = _esc(s.get("title", ""))
    items = s.get("items", [])
    rows = ""
    for item in items:
        label = _esc(item.get("label", ""))
        value = _inline(item.get("value", ""))
        rows += f'<div class="lp-anatomy__label">{label}</div><div class="lp-anatomy__value">{value}</div>'
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{_esc(title)}</h2>
    <div class="lp-anatomy">{rows}</div>
  </div>
</section>"""


def _compile_d2(source):
    """Compile D2 source to SVG. Tries native binary, then Node.js WASM, then fallback."""
    import subprocess, tempfile, os
    from importlib import resources as _pkg

    # Try native d2 binary
    for d2_path in [os.path.expanduser("~/.local/bin/d2"), "d2"]:
        try:
            with tempfile.NamedTemporaryFile(suffix=".d2", mode="w", delete=False) as f:
                f.write(source)
                d2_file = f.name
            svg_file = d2_file.replace(".d2", ".svg")
            result = subprocess.run(
                [d2_path, "--dark-theme", "200", "-t", "200", d2_file, svg_file],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0 and os.path.exists(svg_file):
                with open(svg_file) as f:
                    svg = f.read()
                os.unlink(d2_file)
                os.unlink(svg_file)
                return svg
            os.unlink(d2_file)
            if os.path.exists(svg_file):
                os.unlink(svg_file)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            try:
                os.unlink(d2_file)
            except Exception:
                pass
            continue

    # Try Node.js WASM renderer
    try:
        js_ref = _pkg.files("signalwire_assets").joinpath("assets", "d2_render.js")
        js_path = str(js_ref)
        result = subprocess.run(
            ["node", js_path],
            input=source, capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return None


def _render_diagram(s):
    """D2 diagram rendered to inline SVG."""
    title = _esc(s.get("title", ""))
    d2_source = s.get("d2", "")
    desc = s.get("desc", "")
    desc_html = f'<p style="color:var(--role-body-text);margin-bottom:1.5rem;max-width:65ch">{_esc(desc)}</p>' if desc else ""

    svg = _compile_d2(d2_source)
    if svg:
        content = f'<div class="lp-diagram">{svg}</div>'
    else:
        # Fallback: show D2 source as code block
        code = _highlight_code(d2_source, "")
        content = f'<div class="lp-terminal"><div class="lp-terminal__bar"><div class="lp-terminal__dot"></div><div class="lp-terminal__dot"></div><div class="lp-terminal__dot"></div><span class="lp-terminal__title">diagram.d2</span></div><pre class="lp-terminal__body"><code>{_esc(d2_source)}</code></pre></div>'

    title_html = f'<h2 class="lp-section__title">{title}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    {desc_html}
    {content}
  </div>
</section>"""


SECTION_RENDERERS = {
    "hero": lambda s, cta: _render_hero(s, cta),
    "features": lambda s, cta: _render_features(s),
    "comparison": lambda s, cta: _render_comparison(s),
    "stats": lambda s, cta: _render_stats(s),
    "code": lambda s, cta: _render_code(s),
    "testimonial": lambda s, cta: _render_testimonial(s),
    "logos": lambda s, cta: _render_logos(s),
    "steps": lambda s, cta: _render_steps(s),
    "faq": lambda s, cta: _render_faq(s),
    "text": lambda s, cta: _render_text(s),
    "table": lambda s, cta: _render_table(s),
    "callout": lambda s, cta: _render_callout(s),
    "badges": lambda s, cta: _render_badges(s),
    "tabs": lambda s, cta: _render_tabs(s),
    "pricing": lambda s, cta: _render_pricing(s),
    "links": lambda s, cta: _render_links(s),
    "swatches": lambda s, cta: _render_swatches(s),
    "anatomy": lambda s, cta: _render_anatomy(s),
    "diagram": lambda s, cta: _render_diagram(s),
    "cta": lambda s, cta: _render_cta(s, cta),
}
