class Validator:
  def validate(self) -> None:
    ...

