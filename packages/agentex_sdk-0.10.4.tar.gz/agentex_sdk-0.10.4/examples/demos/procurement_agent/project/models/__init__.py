"""Procurement agent models module."""
