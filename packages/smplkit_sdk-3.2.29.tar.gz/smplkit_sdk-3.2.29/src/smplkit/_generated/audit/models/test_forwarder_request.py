from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, TYPE_CHECKING

from attrs import define as _attrs_define

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.http_header import HttpHeader


T = TypeVar("T", bound="TestForwarderRequest")


@_attrs_define
class TestForwarderRequest:
    """Plain-JSON body for the test_forwarder execute action.

    Mirrors the encrypted ``ForwarderHttp`` shape with one addition —
    ``timeout_ms``, capped server-side.

        Attributes:
            url (str):
            method (str | Unset):  Default: 'POST'.
            headers (list[HttpHeader] | Unset):
            body (None | str | Unset):
            success_status (str | Unset):  Default: '2xx'.
            timeout_ms (int | None | Unset):
    """

    url: str
    method: str | Unset = "POST"
    headers: list[HttpHeader] | Unset = UNSET
    body: None | str | Unset = UNSET
    success_status: str | Unset = "2xx"
    timeout_ms: int | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        url = self.url

        method = self.method

        headers: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.headers, Unset):
            headers = []
            for headers_item_data in self.headers:
                headers_item = headers_item_data.to_dict()
                headers.append(headers_item)

        body: None | str | Unset
        if isinstance(self.body, Unset):
            body = UNSET
        else:
            body = self.body

        success_status = self.success_status

        timeout_ms: int | None | Unset
        if isinstance(self.timeout_ms, Unset):
            timeout_ms = UNSET
        else:
            timeout_ms = self.timeout_ms

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "url": url,
            }
        )
        if method is not UNSET:
            field_dict["method"] = method
        if headers is not UNSET:
            field_dict["headers"] = headers
        if body is not UNSET:
            field_dict["body"] = body
        if success_status is not UNSET:
            field_dict["success_status"] = success_status
        if timeout_ms is not UNSET:
            field_dict["timeout_ms"] = timeout_ms

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.http_header import HttpHeader

        d = dict(src_dict)
        url = d.pop("url")

        method = d.pop("method", UNSET)

        _headers = d.pop("headers", UNSET)
        headers: list[HttpHeader] | Unset = UNSET
        if _headers is not UNSET:
            headers = []
            for headers_item_data in _headers:
                headers_item = HttpHeader.from_dict(headers_item_data)

                headers.append(headers_item)

        def _parse_body(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        body = _parse_body(d.pop("body", UNSET))

        success_status = d.pop("success_status", UNSET)

        def _parse_timeout_ms(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timeout_ms = _parse_timeout_ms(d.pop("timeout_ms", UNSET))

        test_forwarder_request = cls(
            url=url,
            method=method,
            headers=headers,
            body=body,
            success_status=success_status,
            timeout_ms=timeout_ms,
        )

        return test_forwarder_request
