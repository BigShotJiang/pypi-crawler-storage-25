from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response
from ... import errors

from ...models.wipe_request import WipeRequest
from ...models.wipe_response import WipeResponse


def _get_kwargs(
    *,
    body: WipeRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/functions/wipe/actions/execute",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> WipeResponse | None:
    if response.status_code == 200:
        response_200 = WipeResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[WipeResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: WipeRequest,
) -> Response[WipeResponse]:
    """Execute Wipe

     Delete every audit-database row scoped to the authenticated account.

    Returns the per-table row counts that were deleted along with the
    completion timestamp. The action is atomic within the audit
    database — either every account-scoped row is gone, or none is.
    The body is required to be ``{}``; no parameters are accepted.

    Args:
        body (WipeRequest): Empty body — the action requires no parameters.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WipeResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: WipeRequest,
) -> WipeResponse | None:
    """Execute Wipe

     Delete every audit-database row scoped to the authenticated account.

    Returns the per-table row counts that were deleted along with the
    completion timestamp. The action is atomic within the audit
    database — either every account-scoped row is gone, or none is.
    The body is required to be ``{}``; no parameters are accepted.

    Args:
        body (WipeRequest): Empty body — the action requires no parameters.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WipeResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: WipeRequest,
) -> Response[WipeResponse]:
    """Execute Wipe

     Delete every audit-database row scoped to the authenticated account.

    Returns the per-table row counts that were deleted along with the
    completion timestamp. The action is atomic within the audit
    database — either every account-scoped row is gone, or none is.
    The body is required to be ``{}``; no parameters are accepted.

    Args:
        body (WipeRequest): Empty body — the action requires no parameters.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WipeResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: WipeRequest,
) -> WipeResponse | None:
    """Execute Wipe

     Delete every audit-database row scoped to the authenticated account.

    Returns the per-table row counts that were deleted along with the
    completion timestamp. The action is atomic within the audit
    database — either every account-scoped row is gone, or none is.
    The body is required to be ``{}``; no parameters are accepted.

    Args:
        body (WipeRequest): Empty body — the action requires no parameters.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WipeResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
