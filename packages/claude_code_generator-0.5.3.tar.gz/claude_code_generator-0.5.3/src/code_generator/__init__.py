"""code-generator: orchestrator CLI for end-to-end project generation."""

__version__ = "0.5.3"
