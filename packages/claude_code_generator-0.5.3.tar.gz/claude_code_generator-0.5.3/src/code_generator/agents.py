"""Tech-stack detector and agent selection matrix (requirements.md §7).

Parses the ``## Tech Stack`` section of a requirements file and returns
an :class:`AgentSelection` dataclass describing which agents and skills
to activate for the project.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path


@dataclass(frozen=True)
class AgentSelection:
    """Immutable record of chosen agents and skills for a project.

    Attributes:
        primary: Tuple of primary agent names to assign as implementers.
        support: Tuple of support/advisory agent names.
        skills: Tuple of skill names to auto-load.
    """

    primary: tuple[str, ...]
    support: tuple[str, ...]
    skills: tuple[str, ...]


# ---------------------------------------------------------------------------
# Fallback / defaults
# ---------------------------------------------------------------------------

_GENERIC_FALLBACK = AgentSelection(
    primary=("python-pro",),
    support=(),
    skills=("solid-principles",),
)

# ---------------------------------------------------------------------------
# Matrix definitions — ordered from most-specific to least-specific
# ---------------------------------------------------------------------------

_ANGULAR_FASTAPI = AgentSelection(
    primary=("frontend-developer", "python-pro", "fastapi-expert-agent"),
    support=("ui-ux-designer", "supabase-connection-expert"),
    skills=("solid-principles", "python-expert"),
)

_ANGULAR_ONLY = AgentSelection(
    primary=("frontend-developer",),
    support=("ui-ux-designer",),
    skills=("solid-principles",),
)

_FASTAPI = AgentSelection(
    primary=("python-pro", "fastapi-expert-agent"),
    support=("supabase-connection-expert",),
    skills=("solid-principles", "python-expert"),
)

_BAML = AgentSelection(
    primary=("baml-expert-agent", "python-pro"),
    support=(),
    skills=("solid-principles",),
)

_PYTHON_CLI = AgentSelection(
    primary=("python-pro",),
    support=(),
    skills=("solid-principles", "python-expert"),
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def _extract_tech_stack_block(text: str) -> str:
    """Return the text between ``## Tech Stack`` and the next ``## `` heading.

    Args:
        text: Full content of a requirements file.

    Returns:
        Lowercased content of the Tech Stack section, or an empty string
        when the section is absent.
    """
    marker = "## tech stack"
    lower = text.lower()
    start = lower.find(marker)
    if start == -1:
        return ""

    block_start = start + len(marker)
    # Find the next level-2 heading after the marker.
    next_heading = lower.find("\n## ", block_start)
    block = lower[block_start:] if next_heading == -1 else lower[block_start:next_heading]

    return block


def detect(requirements_path: Path) -> AgentSelection:
    """Parse a requirements file and return the matching AgentSelection.

    Detection follows the §7 matrix in requirements.md.  Full-stack
    combos are checked before single-stack patterns.  Falls back to the
    generic ``python-pro`` + ``solid-principles`` selection when the file
    is missing or no keyword matches.

    Args:
        requirements_path: Path to a ``requirements.md`` file (need not exist).

    Returns:
        The most-specific :class:`AgentSelection` that matches the stack,
        or the generic fallback when no match is found.
    """
    if not requirements_path.exists():
        return _GENERIC_FALLBACK

    text = requirements_path.read_text(encoding="utf-8")
    block = _extract_tech_stack_block(text)

    if not block:
        return _GENERIC_FALLBACK

    has_angular = "angular" in block or " ng " in block or " ng," in block
    has_fastapi = "fastapi" in block or "python api" in block

    if has_angular and has_fastapi:
        return _ANGULAR_FASTAPI

    if has_angular:
        return _ANGULAR_ONLY

    if has_fastapi:
        return _FASTAPI

    if "baml" in block or "llm function" in block:
        return _BAML

    if "typer" in block or "click" in block or "python cli" in block:
        return _PYTHON_CLI

    return _GENERIC_FALLBACK
