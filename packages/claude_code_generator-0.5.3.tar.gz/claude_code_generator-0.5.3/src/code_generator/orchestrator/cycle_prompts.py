"""Per-cycle specialized prompt generation.

After Phase 0 populates ``state.cycles`` the orchestrator calls
:func:`generate_cycle_prompts` once to materialise one specialized markdown
prompt per cycle under ``.code-generator/cycles_prompts/<requirements_hash>/``.

Each per-cycle file gives the downstream planning session (Phase 1) the
cycle's concrete objective together with the overall project vision and
pointers to preceding/following cycles, so milestones do not become
context-free silos.

The generator is idempotent: when every ``cycle_<id>.md`` file already
exists for the current hash, the function is a no-op, which makes
``--continue`` safe.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.state import CycleState

if TYPE_CHECKING:
    import logging

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import State


_SPECIALIZER_DEFAULT_MODEL = "claude-opus-4-7"
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama — #219.


class CyclePromptGenerationError(RuntimeError):
    """Raised when the cycle-specializer prompt cannot produce a valid output.

    The caller (Phase 0) catches this and falls back to inlining the raw
    requirements into Phase 1's volatile context.
    """


def cycles_prompts_dir(project_dir: Path, requirements_hash: str) -> Path:
    """Return the directory that holds per-cycle specialized prompts.

    Args:
        project_dir: Project root (the same path used for ``state.json``).
        requirements_hash: SHA-256 hex digest of the canonical requirements.

    Returns:
        ``<project_dir>/.code-generator/cycles_prompts/<requirements_hash>/``.
    """
    return project_dir / ".code-generator" / "cycles_prompts" / requirements_hash


def _cycle_file(project_dir: Path, requirements_hash: str, cycle_id: int) -> Path:
    return cycles_prompts_dir(project_dir, requirements_hash) / f"cycle_{cycle_id}.md"


def is_generated(
    project_dir: Path,
    requirements_hash: str,
    cycle_ids: list[int],
) -> bool:
    """Return True when every ``cycle_<id>.md`` already exists for this hash.

    An empty ``cycle_ids`` list returns ``True`` — there is nothing to generate.

    Args:
        project_dir: Project root directory.
        requirements_hash: SHA-256 hex digest of the canonical requirements.
        cycle_ids: IDs of the cycles that must have a generated prompt.
    """
    folder = cycles_prompts_dir(project_dir, requirements_hash)
    if not folder.is_dir():
        return False
    return all(_cycle_file(project_dir, requirements_hash, cid).is_file() for cid in cycle_ids)


def load_cycle_prompt(project_dir: Path, requirements_hash: str, cycle_id: int) -> str:
    """Read a previously-generated per-cycle prompt.

    Args:
        project_dir: Project root directory.
        requirements_hash: SHA-256 hex digest of the canonical requirements.
        cycle_id: Cycle id whose specialized prompt is requested.

    Returns:
        The raw markdown contents, suitable for verbatim injection into the
        Phase 1 prompt's volatile-context block.

    Raises:
        FileNotFoundError: When the file is missing (the caller must handle
            the fallback path — typically inlining the raw requirements).
    """
    path = _cycle_file(project_dir, requirements_hash, cycle_id)
    return path.read_text(encoding="utf-8")


def _cycles_as_json(state: State) -> str:
    """Serialize full cycles in *state* to a JSON string for prompt injection."""
    cycles: list[dict[str, Any]] = []
    for cycle in state.cycles:
        if not isinstance(cycle, CycleState):
            continue
        cycles.append(
            {
                "id": cycle.id,
                "name": cycle.name,
                "milestone_title": cycle.milestone_title,
                "scope": cycle.scope,
                "depends_on": list(cycle.depends_on),
            }
        )
    return json.dumps(cycles, indent=2)


def _atomic_write(path: Path, content: str) -> None:
    """Write *content* to *path* via a sibling ``.tmp`` file + os.replace.

    Mirrors the pattern used by :func:`code_generator.state.save_state`.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, path)


def _parse_specializer_output(text: str, expected_ids: list[int]) -> dict[int, str]:
    """Extract the ``{"cycle_N": "..."}`` JSON object from *text*.

    Tolerates prose wrapping the JSON (the model occasionally adds a fenced
    code block even under strict instructions). The first ``{`` and last
    ``}`` delimit the candidate JSON object.

    Args:
        text: Raw text returned by the specializer call.
        expected_ids: The cycle IDs that must appear as ``cycle_<id>`` keys.

    Returns:
        Mapping of cycle id → markdown briefing.

    Raises:
        CyclePromptGenerationError: On parse failure, on missing keys, or on
            non-string values.
    """
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise CyclePromptGenerationError("no JSON object found in specializer output")
    try:
        raw = json.loads(text[start : end + 1])
    except json.JSONDecodeError as exc:
        raise CyclePromptGenerationError(f"specializer output is not valid JSON: {exc}") from exc
    if not isinstance(raw, dict):
        raise CyclePromptGenerationError(
            f"specializer output is not a JSON object (got {type(raw).__name__})"
        )

    out: dict[int, str] = {}
    for cid in expected_ids:
        key = f"cycle_{cid}"
        value = raw.get(key)
        if not isinstance(value, str) or not value.strip():
            raise CyclePromptGenerationError(f"specializer output missing or empty key {key!r}")
        out[cid] = value
    return out


async def generate_cycle_prompts(
    project_dir: Path,
    state: State,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Generate one specialized markdown prompt per cycle in *state*.

    Single Opus 4.7 call emits ``{"cycle_1": "...", ...}``; each value is
    written atomically to ``.code-generator/cycles_prompts/<hash>/cycle_<id>.md``.

    The call is skipped entirely when every target file already exists for
    the current ``state.requirements_hash`` — this is what makes
    ``--continue`` a no-op on the second run.

    Args:
        project_dir: Project root directory.
        state: Root state (must have ``requirements_hash`` set and
            ``cycles`` populated by Phase 0).
        runner_module: Runner module from ``get_runner()``.
        logger: Phase logger (typically the Phase 0 logger).
        max_turns: Optional debugging override; production callers leave ``None``.
        effective_model: Optional Ollama tag override. When ``None`` the call
            uses ``claude-opus-4-7``.

    Raises:
        CyclePromptGenerationError: On any failure — no partial files are left
            behind (each file is written via ``tmp → os.replace`` only after
            the JSON has been fully parsed).
    """
    if state.requirements_hash is None:
        raise CyclePromptGenerationError(
            "state.requirements_hash is unset — cannot generate specialized prompts"
        )

    cycle_ids = [c.id for c in state.cycles if isinstance(c, CycleState)]
    if not cycle_ids:
        logger.info("cycle-prompts: no cycles to specialize — skipping.")
        return

    if is_generated(project_dir, state.requirements_hash, cycle_ids):
        logger.info(
            "cycle-prompts: %d per-cycle prompts already exist at %s — skipping generation.",
            len(cycle_ids),
            cycles_prompts_dir(project_dir, state.requirements_hash),
        )
        return

    requirements_path = project_dir / ".code-generator" / "requirements.md"
    requirements_content = requirements_path.read_text(encoding="utf-8")
    cycles_json = _cycles_as_json(state)

    prompt = load_prompt(
        "prompt-cycle-specializer.md",
        REQUIREMENTS_CONTENT=requirements_content,
        CYCLES_JSON=cycles_json,
    )

    model = effective_model or _SPECIALIZER_DEFAULT_MODEL
    options = make_agent_options(
        model=model,
        allowed_tools=["Agent", "Read"],
        cwd=str(project_dir),
        **max_turns_kwargs(max_turns),
    )

    state_path = project_dir / ".code-generator" / "state.json"
    logger.info(
        "cycle-prompts: generating %d specialized prompts (model=%s).", len(cycle_ids), model
    )
    result = await rate_limit.main_loop(
        runner_module,
        prompt,
        options,
        state_path=state_path,
        logger=logger,
    )

    briefings = _parse_specializer_output(result.text, cycle_ids)

    for cid in cycle_ids:
        _atomic_write(
            _cycle_file(project_dir, state.requirements_hash, cid),
            briefings[cid],
        )
    logger.info(
        "cycle-prompts: wrote %d files under %s.",
        len(cycle_ids),
        cycles_prompts_dir(project_dir, state.requirements_hash),
    )
