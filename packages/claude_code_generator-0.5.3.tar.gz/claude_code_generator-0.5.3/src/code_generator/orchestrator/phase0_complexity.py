"""Phase 0 — Complexity analysis and single vs. multi-cycle decision.

Uses Opus 4.7 to analyse the requirements file and populate
``state.mode`` and ``state.cycles``.

Non-negotiable #8: model is hard-coded to ``claude-opus-4-7``.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ValidationError

from code_generator import effort as _effort
from code_generator import memory as _memory
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.orchestrator import cycle_prompts as _cycle_prompts
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.types import Phase0SchemaError, TokenUsage

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import State

# How many times to re-prompt when JSON is unparseable before falling back.
_MAX_JSON_RETRIES = 2


# ---------------------------------------------------------------------------
# Pydantic schema models for Phase 0 output
# ---------------------------------------------------------------------------


class EffortHintSchema(BaseModel):
    """Advisory effort hint emitted by Phase 0 for a class of issues."""

    scope_keyword: str
    effort: Literal["low", "medium", "high"]


class CyclePlan(BaseModel):
    """Schema for a single cycle in the Phase 0 multi-cycle decomposition."""

    id: int
    name: str
    milestone_title: str
    depends_on: list[int] = []
    scope: str
    estimated_issues: int | None = None
    effort_hints: list[EffortHintSchema] = []


class Phase0Output(BaseModel):
    """Validated schema for the complete Phase 0 JSON output."""

    mode: Literal["single", "multi-cycle"]
    cycles: list[CyclePlan] = []
    reason: str = ""
    effort_hints: list[EffortHintSchema] = []


def parse_phase0_output(raw: dict[str, Any]) -> Phase0Output:
    """Validate *raw* against :class:`Phase0Output` schema.

    Args:
        raw: Parsed JSON dict from the Phase 0 model response.

    Returns:
        A validated :class:`Phase0Output` instance.

    Raises:
        Phase0SchemaError: When *raw* does not conform to the schema.
    """
    try:
        return Phase0Output.model_validate(raw)
    except ValidationError as exc:
        raise Phase0SchemaError(str(exc), raw) from exc


def parse_raw_cycle_plan(raw: list[dict[str, Any]]) -> list[CyclePlan]:
    """Validate a list of raw cycle dicts against :class:`CyclePlan` schema.

    Args:
        raw: List of raw cycle dicts from the Phase 0 model response.

    Returns:
        A list of validated :class:`CyclePlan` instances.

    Raises:
        Phase0SchemaError: When any entry does not conform to :class:`CyclePlan`.
    """
    plans: list[CyclePlan] = []
    for entry in raw:
        try:
            plans.append(CyclePlan.model_validate(entry))
        except ValidationError as exc:
            raise Phase0SchemaError(str(exc), entry) from exc
    return plans


def _parse_json(text: str) -> dict[str, Any] | None:
    """Extract and parse the first JSON object from *text*.

    Args:
        text: Raw text that may contain prose around a JSON object.

    Returns:
        Parsed dict or ``None`` when no valid JSON object is found.
    """
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        return None
    try:
        return json.loads(text[start : end + 1])  # type: ignore[no-any-return]
    except json.JSONDecodeError:
        return None


def _apply_result(state: State, output: Phase0Output, effective_model: str | None = None) -> None:
    """Write validated phase-0 output into *state* in place.

    Args:
        state: The state object to mutate.
        output: Validated :class:`Phase0Output` instance.
        effective_model: Ollama model tag to stamp on new cycles (``None``
            on the Anthropic Max path).
    """
    state.mode = output.mode  # type: ignore[assignment]

    if output.cycles:
        state.cycles = [
            _state.CycleState(
                id=cycle.id,
                name=cycle.name,
                milestone_number=None,
                milestone_title=cycle.milestone_title,
                status="open",
                phase=0,
                issues=[],
                commit_sha=None,
                depends_on=cycle.depends_on,
                scope=cycle.scope,
                effort_hints=[
                    _state.EffortHint(
                        scope_keyword=h.scope_keyword,
                        effort=h.effort,
                    )
                    for h in cycle.effort_hints
                ],
                ollama_model=effective_model,
            )
            for cycle in output.cycles
        ]

    state.effort_hints = [
        _state.EffortHint(scope_keyword=h.scope_keyword, effort=h.effort)
        for h in output.effort_hints
    ]


_PHASE0_DEFAULT_MODEL = "claude-opus-4-7"
# CLAUDE.md invariant #8 fixes this model per phase for the Anthropic Max path.
# Overridden via ``effective_model`` on the Ollama codepath — see issue #219.


async def _run_phase0_prompt(
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> tuple[dict[str, Any] | None, TokenUsage]:
    """Run the Phase 0 prompt and return the parsed JSON data with accumulated usage.

    Retries up to ``_MAX_JSON_RETRIES`` times when JSON parsing fails.
    Token usage is accumulated across all retry attempts.

    Args:
        project_dir: Project root directory (used for state path and cwd).
        runner_module: Runner module for executing the prompt.
        logger: Phase logger.

    Returns:
        A ``(data, usage)`` tuple where ``data`` is the parsed dict (or ``None``
        after all retries are exhausted) and ``usage`` is the accumulated
        :class:`~code_generator.runner.types.TokenUsage` across all attempts.
    """
    state_path = project_dir / ".code-generator" / "state.json"
    memories_dir = project_dir / ".code-generator" / "memories"
    repo_map = _memory.read_cycle_repomap(memories_dir)
    prompt = load_prompt("prompt-phase-0-complexity.md", REPO_MAP=repo_map)

    model = effective_model or _PHASE0_DEFAULT_MODEL
    effort_level = _effort.resolve_effort(phase=0, complexity="", issue_labels=[], retry_count=0)
    _effort.validate_effort(effort_level, model)

    options = make_agent_options(
        model=model,
        effort=effort_level,
        allowed_tools=["Agent", "Read", "Glob", "Grep"],
        cwd=str(project_dir),
        **max_turns_kwargs(max_turns),
    )

    total_usage = TokenUsage()

    for attempt in range(_MAX_JSON_RETRIES + 1):
        result = await rate_limit.main_loop(
            runner_module,
            prompt,
            options,
            state_path=state_path,
            logger=logger,
        )
        total_usage += result.usage

        data = _parse_json(result.text)
        if data is not None:
            return data, total_usage

        logger.warning(
            "Phase 0: JSON parse failed (attempt %d/%d). Text: %.200s",
            attempt + 1,
            _MAX_JSON_RETRIES + 1,
            result.text,
        )
        if attempt < _MAX_JSON_RETRIES:
            prompt = "Return ONLY valid JSON, no prose. " + prompt

    return None, total_usage


async def run(
    state: State,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> State:
    """Execute phase 0: complexity analysis.

    Loads the phase-0 prompt, runs it via the rate-limit main loop,
    parses JSON from the response, and writes ``mode`` and ``cycles``
    into *state*.

    If JSON parsing fails twice the response is re-prompted. After
    ``_MAX_JSON_RETRIES`` failures the mode falls back to ``"single"``
    and an ERROR is logged.

    Args:
        state: Current state (mutated in place and returned).
        project_dir: The project root directory (cwd for the SDK).
        runner_module: The runner module returned by ``get_runner()``.
        logger: Optional phase logger; one is created when omitted.

    Returns:
        The mutated state with ``mode`` and ``cycles`` populated.
    """
    if logger is None:
        logger = setup_phase_logger("phase0", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"

    data, usage = await _run_phase0_prompt(
        project_dir,
        runner_module=runner_module,
        logger=logger,
        max_turns=max_turns,
        effective_model=effective_model,
    )

    state.token_usage["phase0"] = usage
    log_phase_usage(logger, 0, usage)

    if data is not None:
        output = parse_phase0_output(data)
        _apply_result(state, output, effective_model=effective_model)
        logger.info("Phase 0: mode=%s, cycles=%d", state.mode, len(state.cycles))
        _state.save_state(state_path, state)
        if state.mode == "multi-cycle" and state.cycles:
            try:
                await _cycle_prompts.generate_cycle_prompts(
                    project_dir,
                    state,
                    runner_module=runner_module,
                    logger=logger,
                    max_turns=max_turns,
                    effective_model=effective_model,
                )
            except _cycle_prompts.CyclePromptGenerationError as exc:
                logger.warning(
                    "cycle-prompts: generation failed (%s); "
                    "Phase 1 will fall back to raw requirements.",
                    exc,
                )
        return state

    # All retries exhausted — safe fallback.
    logger.error(
        "Phase 0: JSON parsing failed after %d retries. Falling back to single mode.",
        _MAX_JSON_RETRIES,
    )
    state.mode = "single"  # type: ignore[assignment]
    _state.save_state(state_path, state)
    return state


async def get_raw_cycle_plan(
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> list[dict[str, Any]] | None:
    """Run Phase 0 and return raw cycle data without mutating state.

    Used by delta planning so the caller can decide whether to apply or merge
    the result with existing completed cycles.  Unlike :func:`run`, this
    function never writes to ``state`` — it is the caller's responsibility to
    merge the returned cycles via :func:`~code_generator.state.append_new_cycles`.

    Args:
        project_dir: Project root directory.
        runner_module: Runner module for executing the prompt.
        logger: Optional phase logger; one is created when omitted.

    Returns:
        List of raw cycle dicts from Phase 0, or ``None`` when JSON parsing
        fails after all retries (caller must treat ``None`` as an abort signal).
    """
    if logger is None:
        logger = setup_phase_logger("phase0", project_dir)

    data, _usage = await _run_phase0_prompt(
        project_dir,
        runner_module=runner_module,
        logger=logger,
        max_turns=max_turns,
        effective_model=effective_model,
    )
    if data is None:
        logger.error(
            "Phase 0: JSON parsing failed during delta planning. Aborting delta.",
        )
        return None

    output = parse_phase0_output(data)
    raw_cycles = [cycle.model_dump() for cycle in output.cycles]
    return raw_cycles
