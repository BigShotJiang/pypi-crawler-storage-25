# Prompt — Phase 7: Commit message generation

**Model:** `claude-opus-4-7`
**Tools:** `Read`, `Bash`

---

## Prompt

Output only the commit message — no preamble, no explanation, no markdown fence. The very first character must be the commit type.

### Format

```
<type>(<scope>): <summary, ≤70 chars, imperative, lowercase, no period>

- <why, not what — max 3 bullets>

Closed issues: #1, #2
```

`<scope>` is the cycle name (multi-cycle only). Omit for single-cycle.

### Conventional Commits types

`feat` · `fix` · `refactor` · `test` · `docs` · `chore` · `perf` · `build` · `ci` · `style` · `revert`

### Instructions

> **Any character before the commit type is a bug.**
> The very first character of your output must be the commit type.

### Wrong vs Right

~~I have enough context now. Here is the message.~~

~~feat: add thing~~

```
feat: add thing
```

### Steps

1. Review **Staged changes** in `## Volatile Context`.
2. Read **Issues closed** in `## Volatile Context`.
3. Pick the type, write the message, output it — nothing else.

### Summary rules

- Imperative present tense: `"add user auth"`, not `"added"` or `"adds"`
- Lowercase (except proper nouns) · no trailing period · ≤ 70 characters
- Body: up to 3 bullets · explain the **why**, not the **what** (the diff shows the what)
- Leave a blank line between the summary, body, and `Closed issues` footer

### Examples

```
feat: add user authentication with JWT

- JWT tokens issued on login with 1h expiry
- refresh tokens stored in HttpOnly cookies
- password hashing with argon2

Closed issues: #1, #2, #3
```

```
feat(database-layer): add user and session models

- repository pattern keeps ORM out of domain layer
- Alembic migrations for initial schema

Closed issues: #4, #5
```

```
fix: handle empty DataFrame in optimizer

- return None instead of raising TypeError on empty input

Closed issues: #42
```

### Constraints

- English only — even if `requirements.md` is in another language.
- Do not run `git commit` — the orchestrator handles that.
- The staged diff is already in `## Volatile Context`; do not run `git diff` commands.

---

## Volatile Context

- **Cycle name:** {CYCLE_NAME}
- **Issues closed:** {ISSUES_CLOSED}

### Staged diff stat (`git diff --cached --stat`)

```
{STAGED_DIFF_STAT}
```

### Staged files (`git diff --cached --name-only`)

```
{STAGED_FILES}
```
