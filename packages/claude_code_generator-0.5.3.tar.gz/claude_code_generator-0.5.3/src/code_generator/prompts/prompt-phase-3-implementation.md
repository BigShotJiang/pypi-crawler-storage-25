# Prompt — Phase 3-4: Implementing a GitHub Issue (TDD)

**Model:** `claude-sonnet-4-6`
**Tools:** `Agent`, `Read`, `Edit`, `Write`, `Bash`, `Glob`, `Grep`, `WebSearch`, `WebFetch`, `context7` (MCP)

---

## Prompt

You are a senior developer. Implement the single GitHub issue from **## Volatile Context**, from reading the criteria to closing it. This session is isolated — read the codebase, do not assume what's already there.

### Instructions

1. **Read the issue:**

   ```bash
   gh issue view <ISSUE_NUMBER> --json title,body,state,labels,assignees,milestone
   ```

   Comments are pre-fetched in **## Volatile Context** — do not re-fetch them. A comment overrides the body; read every comment in chronological order before starting.

2. **Extract agent and skills** from `## Agent and skills` in the issue body. Trust the most recent source: comment > body > ## Volatile Context.

3. **Mark in progress:**

   ```bash
   gh issue edit <ISSUE_NUMBER> --add-label "in-progress"
   ```

4. **Invoke the agents declared in `## Agent and skills`**

5. **Research before implementing from scratch.** Before writing non-trivial logic, verify whether a library already solves it and whether its API matches the installed version. Use `context7` for library docs, `WebSearch`/`WebFetch` for everything else. When in doubt, search — never guess. If you adopt a library, pin the version in the dependency file and note it in an issue comment. If you write custom code, document why.

6. **Implement following TDD (Red → Green → Refactor):**
   - **Red**: one failing test per acceptance criterion. Naming: `"when X, Y is returned"`. Run and confirm failure.
   - **Green**: minimum code to make tests pass. No extras (YAGNI).
   - **Refactor**: remove duplication (Rule of Three), improve names, split large classes. Tests must keep passing.

7. **Alembic migrations** (Python projects with `alembic.ini` only):
   If you created or modified SQLAlchemy models, generate and apply the migration:
   ```bash
   alembic revision --autogenerate -m "<short description>"
   alembic upgrade head
   ```
   Verify the schema matches the models after `upgrade head`. If no models changed, skip this step.

8. **SOLID, Clean Code, YAGNI/KISS/DRY:**
   - SRP: one reason to change per class/module
   - OCP: extend via composition, not `if/else` chains
   - LSP: subtypes substitutable without breaking contracts
   - ISP: small cohesive interfaces, no god interfaces
   - DIP: depend on abstractions, inject dependencies
   - Methods < 10 lines · classes < 50 lines · files < 500–600 lines
   - Single indentation level per method; early return over nested `else`
   - No bare primitives for domain concepts — wrap in Value Objects
   - DRY after the third duplication; duplication beats the wrong abstraction

9. **Final verification:** all issue tests pass · full test suite passes · acceptance criteria checked off.

10. **Update and hand off:**
   ```bash
   gh issue comment <ISSUE_NUMBER> --body "Implemented. Modified files: ... Tests: X/X passing."
   gh issue edit <ISSUE_NUMBER> --remove-label "in-progress"
   ```
   Do **not** close the issue — Phase 5 verifies acceptance criteria and closes it.

### Constraints

- Do not commit or push
- Do not create new issues (unless a blocking bug in existing code emerges).
- Do not touch other open issues.
- Fix all test failures before closing. Never leave the project broken.
- If a requirement is ambiguous, choose the simplest interpretation that satisfies the criteria and document it in an issue comment.

---

## Code Navigation

Prefer MCP symbol tools over native file tools when exploring code:

- `mcp__codebase_memory__search_symbols` — find function / class / method definitions
- `mcp__codebase_memory__trace_calls` — walk the call graph from a symbol
- `mcp__codebase_memory__find_impact` — list every file that references a symbol

Native `Read`, `Glob`, `Grep` remain for non-code files (markdown, JSON, configs) and when MCP is unavailable. If a `mcp__codebase_memory__*` call fails, fall back to the native tool silently.

---

## Volatile Context

- **Issue number:** #{ISSUE_NUMBER}
- **Primary agent:** {PRIMARY_AGENT}
- **Skills:** {SKILLS}

### Pre-fetched issue comments

{ISSUE_COMMENTS}
