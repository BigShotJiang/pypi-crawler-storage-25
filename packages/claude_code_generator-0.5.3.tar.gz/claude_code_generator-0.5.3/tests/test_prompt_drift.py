"""Tests for §17: prompt-hash + SDK-version drift detection.

Covers:
- compute_all_prompt_hashes: returns deterministic {filename: sha256_hex} dict
- detect_sdk_version: reads claude_agent_sdk.__version__ or returns None
- warn_on_prompt_or_sdk_drift: pure comparator, returns list of warning strings
- cycle_loop: populates prompt_hashes + sdk_version at cycle start
- --continue: emits WARNINGs on mismatch without aborting
- 0.2.x state.json (missing fields): no WARNING on fresh --continue
"""

from __future__ import annotations

import hashlib
import importlib.resources
from pathlib import Path
from unittest.mock import MagicMock, patch

from code_generator.env import detect_sdk_version
from code_generator.prompts.hashes import compute_all_prompt_hashes
from code_generator.state import State, warn_on_prompt_or_sdk_drift

# ---------------------------------------------------------------------------
# compute_all_prompt_hashes
# ---------------------------------------------------------------------------


class TestComputeAllPromptHashes:
    def test_returns_dict_with_md_filenames_as_keys(self) -> None:
        """compute_all_prompt_hashes returns a dict keyed by .md filenames."""
        hashes = compute_all_prompt_hashes()

        assert isinstance(hashes, dict)
        assert len(hashes) > 0
        for filename in hashes:
            assert filename.endswith(".md"), f"Expected .md file, got: {filename}"

    def test_values_are_lowercase_sha256_hex_strings(self) -> None:
        """Each value is a 64-character lowercase hex string (SHA-256)."""
        hashes = compute_all_prompt_hashes()

        for filename, digest in hashes.items():
            assert len(digest) == 64, f"{filename}: expected 64 chars, got {len(digest)}"
            assert digest == digest.lower(), f"{filename}: expected lowercase hex"
            int(digest, 16)  # raises ValueError if not valid hex

    def test_hashes_are_deterministic(self) -> None:
        """Two calls return identical results."""
        first = compute_all_prompt_hashes()
        second = compute_all_prompt_hashes()

        assert first == second

    def test_covers_all_registered_md_files(self) -> None:
        """Every .md file registered in PLACEHOLDER_SPEC is included."""
        from code_generator.prompts import PLACEHOLDER_SPEC

        hashes = compute_all_prompt_hashes()
        for filename in PLACEHOLDER_SPEC:
            assert filename in hashes, f"Missing hash for registered prompt: {filename}"

    def test_hashes_are_computed_from_bytes_not_decoded_text(self) -> None:
        """Hash of the first .md file matches manually computed SHA-256 of its bytes."""
        hashes = compute_all_prompt_hashes()
        first_filename = next(iter(hashes))

        raw_bytes = (
            importlib.resources.files("code_generator.prompts")
            .joinpath(first_filename)
            .read_bytes()
        )
        expected = hashlib.sha256(raw_bytes).hexdigest()

        assert hashes[first_filename] == expected


# ---------------------------------------------------------------------------
# detect_sdk_version
# ---------------------------------------------------------------------------


class TestDetectSdkVersion:
    def test_returns_version_string_when_sdk_installed(self) -> None:
        """detect_sdk_version returns the installed SDK version string."""
        version = detect_sdk_version()

        # claude_agent_sdk is installed in this environment
        assert version is not None
        assert isinstance(version, str)
        assert len(version) > 0

    def test_returns_none_when_sdk_not_importable(self) -> None:
        """detect_sdk_version returns None when claude_agent_sdk cannot be imported."""
        with patch.dict("sys.modules", {"claude_agent_sdk": None}):
            result = detect_sdk_version()

        assert result is None

    def test_returns_none_when_version_attribute_missing(self) -> None:
        """detect_sdk_version returns None when __version__ attribute is absent."""
        mock_sdk = MagicMock(spec=[])  # no __version__ attribute
        with patch.dict("sys.modules", {"claude_agent_sdk": mock_sdk}):
            result = detect_sdk_version()

        assert result is None


# ---------------------------------------------------------------------------
# warn_on_prompt_or_sdk_drift
# ---------------------------------------------------------------------------


def _make_state(
    prompt_hashes: dict[str, str] | None = None,
    sdk_version: str | None = None,
) -> State:
    from code_generator.state import load_state

    state = load_state(Path("/nonexistent/state.json"))
    state.prompt_hashes = prompt_hashes or {}
    state.sdk_version = sdk_version
    return state


class TestWarnOnPromptOrSdkDrift:
    def test_no_warnings_when_hashes_and_version_match(self) -> None:
        """Returns empty list when everything matches stored values."""
        hashes = {"prompt-phase-1-planning.md": "abc123"}
        state = _make_state(prompt_hashes=hashes, sdk_version="0.1.0")

        warnings = warn_on_prompt_or_sdk_drift(state, hashes, "0.1.0")

        assert warnings == []

    def test_warning_for_changed_prompt_file(self) -> None:
        """Returns WARNING with exact filename when a prompt hash differs."""
        filename = "prompt-phase-3-implementation.md"
        stored = {filename: "deadbeef" * 8}
        current = {filename: "cafebabe" * 8}
        state = _make_state(prompt_hashes=stored)

        warnings = warn_on_prompt_or_sdk_drift(state, current, None)

        assert len(warnings) == 1
        assert filename in warnings[0]
        assert "changed since cycle start" in warnings[0]

    def test_warning_message_includes_exact_filename(self) -> None:
        """WARNING message includes the exact changed filename."""
        filename = "prompt-phase-7-commit.md"
        stored = {filename: "aaa" * 21 + "aa"}
        current = {filename: "bbb" * 21 + "bb"}
        state = _make_state(prompt_hashes=stored)

        warnings = warn_on_prompt_or_sdk_drift(state, current, None)

        assert any(filename in w for w in warnings)

    def test_warning_for_sdk_version_change(self) -> None:
        """Returns WARNING when sdk_version differs from stored value."""
        state = _make_state(sdk_version="0.1.0")

        warnings = warn_on_prompt_or_sdk_drift(state, {}, "0.2.0")

        assert len(warnings) == 1
        assert "0.1.0" in warnings[0]
        assert "0.2.0" in warnings[0]

    def test_no_warning_when_stored_prompt_hashes_empty(self) -> None:
        """No prompt WARNING when stored hashes are empty (0.2.x state)."""
        current = {"prompt-phase-1-planning.md": "abc123"}
        state = _make_state(prompt_hashes={})

        warnings = warn_on_prompt_or_sdk_drift(state, current, None)

        assert not any("changed since cycle start" in w for w in warnings)

    def test_no_warning_when_stored_sdk_version_is_none(self) -> None:
        """No SDK WARNING when stored sdk_version is None (0.2.x state)."""
        state = _make_state(sdk_version=None)

        warnings = warn_on_prompt_or_sdk_drift(state, {}, "0.2.0")

        assert not any("SDK version" in w for w in warnings)

    def test_multiple_changed_prompts_produce_multiple_warnings(self) -> None:
        """One WARNING per changed prompt file."""
        stored = {
            "prompt-phase-1-planning.md": "aaa" * 21 + "aa",
            "prompt-phase-2-batch-review.md": "bbb" * 21 + "bb",
        }
        current = {
            "prompt-phase-1-planning.md": "ccc" * 21 + "cc",
            "prompt-phase-2-batch-review.md": "ddd" * 21 + "dd",
        }
        state = _make_state(prompt_hashes=stored)

        warnings = warn_on_prompt_or_sdk_drift(state, current, None)

        assert len(warnings) == 2

    def test_returns_only_strings(self) -> None:
        """All returned warnings are plain strings."""
        state = _make_state(prompt_hashes={"a.md": "x" * 64}, sdk_version="0.1.0")
        current = {"a.md": "y" * 64}

        warnings = warn_on_prompt_or_sdk_drift(state, current, "0.2.0")

        for w in warnings:
            assert isinstance(w, str)


# ---------------------------------------------------------------------------
# Round-trip: populate at cycle start, save/load preserves values
# ---------------------------------------------------------------------------


class TestPopulateAtCycleStart:
    def test_fresh_cycle_populates_prompt_hashes_and_sdk_version(self, tmp_path: Path) -> None:
        """populate_cycle_start_fields fills both fields and save/load round-trips."""
        from code_generator.orchestrator.cycle_loop import populate_cycle_start_fields
        from code_generator.state import load_state, save_state

        state_path = tmp_path / "state.json"
        state = load_state(state_path)

        populate_cycle_start_fields(state, state_path)

        # Fields are populated in memory
        assert len(state.prompt_hashes) > 0
        # SDK version is optional: None is valid when SDK is absent at runtime.
        _ = state.sdk_version

        # Round-trip through save/load preserves exact values
        save_state(state_path, state)
        loaded = load_state(state_path)

        assert loaded.prompt_hashes == state.prompt_hashes
        assert loaded.sdk_version == state.sdk_version

    def test_populate_does_not_clear_existing_fields_unnecessarily(self, tmp_path: Path) -> None:
        """populate_cycle_start_fields overwrites with fresh values (idempotent)."""
        from code_generator.orchestrator.cycle_loop import populate_cycle_start_fields
        from code_generator.state import load_state

        state_path = tmp_path / "state.json"
        state = load_state(state_path)

        populate_cycle_start_fields(state, state_path)
        first_hashes = dict(state.prompt_hashes)

        populate_cycle_start_fields(state, state_path)

        assert state.prompt_hashes == first_hashes
