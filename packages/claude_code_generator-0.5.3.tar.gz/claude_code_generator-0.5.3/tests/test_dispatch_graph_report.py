"""Tests for ``commands._dispatch._compute_and_persist_graph_report``.

Graphify's shell CLI only supports maintenance — the full LLM-driven build
runs through the ``/graphify`` slash-command inside an AI assistant.  Our
orchestrator therefore:

- writes the fallback sentinel and emits a one-time setup hint when
  ``graphify-out/graph.json`` does not exist (user must seed via the
  slash-command first);
- runs ``graphify update .`` (AST-only refresh, no LLM cost) when the
  graph already exists.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

from code_generator.commands import _dispatch
from code_generator.memory import REPOMAP_FALLBACK

if TYPE_CHECKING:
    import pytest


def _logger() -> logging.Logger:
    return logging.getLogger("test-graph-report")


def _read_persisted(project_dir: Path) -> str:
    target = project_dir / ".code-generator" / "memories" / "cycle-repo-map.md"
    return target.read_text(encoding="utf-8") if target.exists() else ""


def _seed_graph(project_dir: Path) -> Path:
    """Pre-create ``graphify-out/graph.json`` so subprocess paths run."""
    graphify_out = project_dir / "graphify-out"
    graphify_out.mkdir(parents=True, exist_ok=True)
    (graphify_out / "graph.json").write_text("{}", encoding="utf-8")
    (graphify_out / "GRAPH_REPORT.md").write_text("# seed report\n", encoding="utf-8")
    return graphify_out


class TestGraphReportBuild:
    """Behaviour of _compute_and_persist_graph_report under each branch."""

    def test_no_graph_seed_writes_fallback_and_emits_setup_hint(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """When graph.json doesn't exist, write fallback + emit `/graphify .` hint, no subprocess."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        called: list[object] = []

        def _fake_run(*a: object, **k: object) -> subprocess.CompletedProcess[bytes]:
            called.append(a)
            raise AssertionError("subprocess.run must not be called when graph.json is missing")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        with caplog.at_level("INFO"):
            _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert called == []
        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK
        messages = [r.getMessage() for r in caplog.records]
        assert any("/graphify" in m for m in messages), (
            "must emit a hint telling the user to seed via /graphify"
        )

    def test_seeded_graph_runs_update_subcommand(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When graph.json exists, run `graphify update .` (AST-only refresh)."""
        report_dir = tmp_path / "graphify-out"
        report_dir.mkdir(parents=True)
        (report_dir / "graph.json").write_text("{}", encoding="utf-8")
        (report_dir / "GRAPH_REPORT.md").write_text("# old report\n", encoding="utf-8")

        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        commands_seen: list[list[str]] = []

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            commands_seen.append(cmd)
            (report_dir / "GRAPH_REPORT.md").write_text("# updated report\n", encoding="utf-8")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert commands_seen == [["graphify", "update", "."]], (
            f"expected `graphify update .`; got {commands_seen}"
        )
        assert _read_persisted(tmp_path) == "# updated report\n"

    def test_binary_missing_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When `graphify` is not on PATH, write the fallback string and return."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: None)

        called = []

        def _fake_run(*a: object, **k: object) -> subprocess.CompletedProcess[bytes]:
            called.append(a)
            raise AssertionError("subprocess.run must not be called when binary is missing")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert called == []
        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_timeout_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A `TimeoutExpired` from the update subprocess writes the fallback."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            raise subprocess.TimeoutExpired(cmd=cmd, timeout=600)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_called_process_error_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Non-zero exit from the update subprocess writes the fallback."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            raise subprocess.CalledProcessError(returncode=2, cmd=cmd, stderr=b"boom")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_failure_logs_graphify_stderr(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """On non-zero exit, graphify's stderr must appear in the log warning."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        stderr_msg = b"Error: corrupted graph.json"

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            raise subprocess.CalledProcessError(returncode=1, cmd=cmd, stderr=stderr_msg)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        with caplog.at_level("WARNING"):
            _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert any("corrupted graph.json" in w for w in warnings), (
            f"stderr from graphify must be in the log warning. Got: {warnings}"
        )

    def test_missing_report_after_success_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If graphify exits 0 but the report file is missing, write fallback."""
        graphify_out = _seed_graph(tmp_path)
        # Remove the seed report so the read fails after success.
        (graphify_out / "GRAPH_REPORT.md").unlink()

        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            # Exit 0 but don't (re)create the report file.
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_no_env_argument_passed_to_subprocess(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Graphify must inherit the parent env (no `env=` arg)."""
        graphify_out = _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        captured_kwargs: dict[str, object] = {}

        def _fake_run(cmd: list[str], **kwargs: object) -> subprocess.CompletedProcess[bytes]:
            captured_kwargs.update(kwargs)
            (graphify_out / "GRAPH_REPORT.md").write_text("ok\n", encoding="utf-8")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert "env" not in captured_kwargs, (
            "graphify subprocess must inherit parent env (no `env=` arg)"
        )

    def test_oserror_when_invoking_graphify_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """An OSError from subprocess.run (e.g., permission denied) writes fallback."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            raise PermissionError("denied")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK
