"""Tests for code_generator.orchestrator.phase3_4_implement."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import agents as _agents
from code_generator import state as _state
from code_generator.gh import GhError
from code_generator.orchestrator import phase3_4_implement
from code_generator.repo_info import RepoInfo
from code_generator.runner.sdk_runner import RunResult
from code_generator.runner.soft_reset import SoftResetResult
from code_generator.runner.types import MaxTurnsExceeded, OverageAbort, RateLimitHit, TokenUsage

_DUMMY_RESET = SoftResetResult(boundary_prefix="", context_management={})

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state_with_issues(tmp_path: Path, numbers: list[int]) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    st.issues = [_state.IssueState(number=n, status="open", agent="python-pro") for n in numbers]
    st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase3_4Run:
    @pytest.mark.asyncio
    async def test_closes_issues_on_success(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert all(i.status == "closed" for i in state.issues)

    @pytest.mark.asyncio
    async def test_skips_already_closed_issues(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(number=1, status="closed", agent="python-pro"),
            _state.IssueState(number=2, status="open", agent="python-pro"),
        ]
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        _state.save_state(state_dir / "state.json", st)

        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 2, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 1  # Only issue #2 processed.

    @pytest.mark.asyncio
    async def test_retries_on_failure_then_closes(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("Temporary failure")
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert state.issues[0].status == "closed"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_leaves_issue_open_after_all_retries(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            raise RuntimeError("always fails")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=2,
            )

        assert state.issues[0].status == "open"

    @pytest.mark.asyncio
    async def test_session_id_cleared_before_each_issue(self, tmp_path: Path) -> None:
        """Non-negotiable #6: session_id must be None before each issue run."""
        state = _make_state_with_issues(tmp_path, [1, 2])
        state.session_id = "old-session"
        session_ids_at_call_time = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            # Read state from file at call time.
            st = _state.load_state(state_path)
            session_ids_at_call_time.append(st.session_id)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert all(sid is None for sid in session_ids_at_call_time)

    @pytest.mark.asyncio
    async def test_uses_sonnet_model(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-sonnet-4-6"

    @pytest.mark.asyncio
    async def test_uses_cycle_issues_in_multi_cycle(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=1,
            issues=[_state.IssueState(number=77, status="open", agent="python-pro")],
            commit_sha=None,
        )
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        _state.save_state(state_dir / "state.json", st)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 77, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert cycle.issues[0].status == "closed"

    @pytest.mark.asyncio
    async def test_retry_prompt_contains_error_message(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        prompts_seen = []
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            prompts_seen.append(prompt)
            if call_count < 2:
                raise RuntimeError("disk full")
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        # The second prompt should contain the error text.
        assert "disk full" in prompts_seen[1]

class TestEffortWiring:
    @pytest.mark.asyncio
    async def test_effort_high_when_issue_has_complexity_high_label(self, tmp_path: Path) -> None:
        """When an issue has complexity:high label, effort=high is set on options."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(
                number=1,
                status="open",
                agent="python-pro",
                labels=["complexity:high", "area:api"],
            )
        ]
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        _state.save_state(state_dir / "state.json", st)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert hasattr(captured_options[0], "effort")
        assert captured_options[0].effort == "high"

    @pytest.mark.asyncio
    async def test_effort_medium_when_no_complexity_label(self, tmp_path: Path) -> None:
        """When no complexity:high label, effort=medium is set on options."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(
                number=1,
                status="open",
                agent="python-pro",
                labels=["area:api", "priority:high"],
            )
        ]
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        _state.save_state(state_dir / "state.json", st)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert hasattr(captured_options[0], "effort")
        assert captured_options[0].effort == "medium"

    @pytest.mark.asyncio
    async def test_validate_effort_called_before_make_agent_options(self, tmp_path: Path) -> None:
        """validate_effort raises before the SDK call when effort/model combo is invalid."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [_state.IssueState(number=1, status="open", agent="python-pro", labels=[])]
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        _state.save_state(state_dir / "state.json", st)

        # Patch resolve_effort to return "max" — invalid with Sonnet model.
        with (
            patch.object(phase3_4_implement._effort, "resolve_effort", return_value="max"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
            pytest.raises(ValueError, match="max"),
        ):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    def test_find_effort_hint_returns_matching_hint(self) -> None:
        """_find_effort_hint() returns EffortLevel from a hint whose scope_keyword is in a label."""
        hints = [
            _state.EffortHint(scope_keyword="database", effort="high"),
            _state.EffortHint(scope_keyword="simple crud", effort="low"),
        ]
        result = phase3_4_implement._find_effort_hint(hints, ["area:database", "priority:low"])
        assert result == "high"

    def test_find_effort_hint_returns_none_when_no_match(self) -> None:
        """_find_effort_hint() returns None when no hint matches any label."""
        hints = [_state.EffortHint(scope_keyword="authentication", effort="high")]
        result = phase3_4_implement._find_effort_hint(hints, ["area:api", "priority:low"])
        assert result is None

    def test_find_effort_hint_returns_none_for_empty_hints(self) -> None:
        """_find_effort_hint() returns None gracefully when hints list is empty."""
        result = phase3_4_implement._find_effort_hint([], ["area:api"])
        assert result is None


class TestDefaultSkills:
    def test_returns_comma_joined_skills_from_agents_detect(self, tmp_path: Path) -> None:
        """_default_skills() returns a comma-joined string of detected skills."""
        req_dir = tmp_path / ".code-generator"
        req_dir.mkdir(parents=True)
        req_path = req_dir / "requirements.md"
        req_path.write_text("# Requirements\nsome content")

        fake_selection = _agents.AgentSelection(
            primary=("python-pro",),
            support=(),
            skills=("solid-principles", "python-expert"),
        )

        with patch.object(phase3_4_implement._agents, "detect", return_value=fake_selection):
            result = phase3_4_implement._default_skills(tmp_path)

        assert result == "solid-principles,python-expert"


class TestIssueCommentsInjection:
    @pytest.mark.asyncio
    async def test_prompt_contains_comments_section_when_issue_has_comments(
        self, tmp_path: Path
    ) -> None:
        """A fake issue with comments produces a prompt with ## Pre-fetched Issue Comments section."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        fake_comments = [
            {"author": {"login": "alice"}, "createdAt": "2026-01-01T00:00:00Z", "body": "LGTM"},
            {
                "author": {"login": "bob"},
                "createdAt": "2026-01-02T00:00:00Z",
                "body": "Please add tests.",
            },
        ]

        with (
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": fake_comments},
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        prompt = captured_prompts[0]
        assert "## Pre-fetched Issue Comments" in prompt
        assert "LGTM" in prompt
        assert "Please add tests." in prompt

    @pytest.mark.asyncio
    async def test_prompt_excludes_comments_section_when_issue_has_no_comments(
        self, tmp_path: Path
    ) -> None:
        """A fake issue with no comments produces a prompt without ## Pre-fetched Issue Comments header."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": []},
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert "## Pre-fetched Issue Comments" not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_gh_error_on_view_issue_continues_with_empty_comments(
        self, tmp_path: Path
    ) -> None:
        """GhError from view_issue logs a warning and continues with empty comments."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                side_effect=GhError(1, "network error"),
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # Should not crash, issue marked closed, no ## Pre-fetched Issue Comments in prompt
        assert state.issues[0].status == "closed"
        assert len(captured_prompts) == 1
        assert "## Pre-fetched Issue Comments" not in captured_prompts[0]


# ---------------------------------------------------------------------------
# Tests for extracted helper functions (issue #86)
# ---------------------------------------------------------------------------


class TestBuildPrompt:
    def test_first_attempt_returns_base_prompt(self) -> None:
        """_build_prompt returns the base prompt unmodified on attempt 0."""
        issue = _state.IssueState(number=42, status="open", agent="python-pro")

        with patch.object(
            phase3_4_implement,
            "load_prompt",
            return_value="BASE PROMPT",
        ):
            result = phase3_4_implement._build_prompt(
                issue=issue,
                skills="solid-principles",
                comments_section="",
                attempt=0,
                last_err="",
            )

        assert result == "BASE PROMPT"

    def test_retry_attempt_appends_error_context(self) -> None:
        """_build_prompt appends the previous error message on attempt > 0."""
        issue = _state.IssueState(number=42, status="open", agent="python-pro")

        with patch.object(
            phase3_4_implement,
            "load_prompt",
            return_value="BASE PROMPT",
        ):
            result = phase3_4_implement._build_prompt(
                issue=issue,
                skills="solid-principles",
                comments_section="",
                attempt=1,
                last_err="disk full",
            )

        assert "BASE PROMPT" in result
        assert "disk full" in result
        assert "Be more explicit this time" in result

    def test_passes_issue_number_and_agent_to_load_prompt(self) -> None:
        """_build_prompt forwards issue number and agent to load_prompt."""
        issue = _state.IssueState(number=99, status="open", agent="frontend-developer")
        captured_kwargs: list[dict] = []

        def fake_load_prompt(name: str, **kwargs: object) -> str:
            captured_kwargs.append(kwargs)
            return "PROMPT"

        with patch.object(phase3_4_implement, "load_prompt", side_effect=fake_load_prompt):
            phase3_4_implement._build_prompt(
                issue=issue,
                skills="solid-principles,python-expert",
                comments_section="some comments",
                attempt=0,
                last_err="",
            )

        assert captured_kwargs[0]["ISSUE_NUMBER"] == "99"
        assert captured_kwargs[0]["PRIMARY_AGENT"] == "frontend-developer"
        assert captured_kwargs[0]["SKILLS"] == "solid-principles,python-expert"
        assert captured_kwargs[0]["ISSUE_COMMENTS"] == "some comments"


class TestResolveIssueEffort:
    def test_returns_high_when_complexity_high_label(self) -> None:
        """_resolve_issue_effort returns 'high' for a complexity:high label."""
        issue = _state.IssueState(
            number=1, status="open", agent="python-pro", labels=["complexity:high"]
        )
        effort_hints: list[_state.EffortHint] = []

        result = phase3_4_implement._resolve_issue_effort(
            issue, effort_hints, attempt=0, complexity="single"
        )

        assert result == "high"

    def test_returns_medium_when_no_complexity_label(self) -> None:
        """_resolve_issue_effort returns 'medium' when no complexity label."""
        issue = _state.IssueState(number=1, status="open", agent="python-pro", labels=["area:api"])
        effort_hints: list[_state.EffortHint] = []

        result = phase3_4_implement._resolve_issue_effort(
            issue, effort_hints, attempt=0, complexity="single"
        )

        assert result == "medium"

    def test_raises_when_invalid_effort_model_combo(self) -> None:
        """_resolve_issue_effort raises ValueError for invalid effort/model combos."""
        issue = _state.IssueState(number=1, status="open", agent="python-pro", labels=[])
        effort_hints: list[_state.EffortHint] = []

        with (
            patch.object(phase3_4_implement._effort, "resolve_effort", return_value="max"),
            pytest.raises(ValueError, match="max"),
        ):
            phase3_4_implement._resolve_issue_effort(
                issue, effort_hints, attempt=0, complexity="single"
            )


class TestImplementSingleIssue:
    @pytest.mark.asyncio
    async def test_returns_true_on_success(self, tmp_path: Path) -> None:
        """_implement_single_issue returns True when the run succeeds."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            success, _usage, _wall = await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert success is True

    @pytest.mark.asyncio
    async def test_returns_false_after_all_retries_exhausted(self, tmp_path: Path) -> None:
        """_implement_single_issue returns False when all retries fail."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def always_fails(runner, prompt, options, *, state_path, logger, **kw):
            raise RuntimeError("always fails")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=always_fails),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            success, _usage, _wall = await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=2,
            )

        assert success is False

    @pytest.mark.asyncio
    async def test_clears_session_id_before_each_attempt(self, tmp_path: Path) -> None:
        """_implement_single_issue clears session_id before every attempt."""
        state = _make_state_with_issues(tmp_path, [1])
        state.session_id = "stale-session"
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"
        session_ids_seen: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            st = _state.load_state(state_path)
            session_ids_seen.append(st.session_id)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=1,
            )  # return value not checked here — only session_ids matter

        assert all(sid is None for sid in session_ids_seen)

    @pytest.mark.asyncio
    async def test_overage_abort_propagates_through_retry_loop(self, tmp_path: Path) -> None:
        """OverageAbort must escape _implement_single_issue, never be swallowed."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def raises_overage(runner, prompt, options, *, state_path, logger, **kw):
            raise OverageAbort("overage active")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_overage),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
            pytest.raises(OverageAbort),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

    @pytest.mark.asyncio
    async def test_rate_limit_hit_propagates_through_retry_loop(self, tmp_path: Path) -> None:
        """RateLimitHit must escape _implement_single_issue, never be swallowed."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def raises_rate_limit(runner, prompt, options, *, state_path, logger, **kw):
            raise RateLimitHit(resets_at=999999, rate_limit_type="test")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_rate_limit),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
            pytest.raises(RateLimitHit),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )


class TestMaxTurnsExceededFailFast:
    """ACs 1-4: MaxTurnsExceeded fail-fast in the Phase 3/4 retry loop."""

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_short_circuits_retry_loop(self, tmp_path: Path) -> None:
        """AC1: MaxTurnsExceeded on first attempt exits loop after 1 attempt, returns failure."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"
        call_count = 0

        async def raises_max_turns(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            raise MaxTurnsExceeded("agent loop exhausted max_turns budget")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_max_turns),
            patch.object(phase3_4_implement._gh, "add_label", return_value=None),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 42, "comments": []}
            ),
        ):
            success, _usage, _wall = await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert success is False
        assert call_count == 1  # Must not retry.

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_on_issue_n_does_not_abort_cycle(self, tmp_path: Path) -> None:
        """AC2: After MaxTurnsExceeded on issue #1, issue #2 is still processed normally."""
        state = _make_state_with_issues(tmp_path, [1, 2])
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise MaxTurnsExceeded("max_turns hit on issue #1")
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "add_label", return_value=None),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert state.issues[0].status == "open"  # MaxTurnsExceeded → left open
        assert state.issues[1].status == "closed"  # Next issue processed normally
        assert call_count == 2  # Issue #2 was reached after issue #1 failed

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_adds_needs_manual_review_label(self, tmp_path: Path) -> None:
        """AC3: needs-manual-review label is added to the issue via gh.add_label."""
        state = _make_state_with_issues(tmp_path, [42])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"
        add_label_calls: list[tuple] = []

        async def raises_max_turns(runner, prompt, options, *, state_path, logger, **kw):
            raise MaxTurnsExceeded("exhausted")

        def fake_add_label(repo: object, issue_number: int, label: str) -> None:
            add_label_calls.append((issue_number, label))

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_max_turns),
            patch.object(phase3_4_implement._gh, "add_label", side_effect=fake_add_label),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 42, "comments": []}
            ),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert (42, "needs-manual-review") in add_label_calls

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_logs_error_with_max_turns_ceiling_and_attempt(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC4: ERROR log contains 'max_turns ceiling' and the attempt count."""
        state = _make_state_with_issues(tmp_path, [7])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def raises_max_turns(runner, prompt, options, *, state_path, logger, **kw):
            raise MaxTurnsExceeded("budget exhausted")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_max_turns),
            patch.object(phase3_4_implement._gh, "add_label", return_value=None),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 7, "comments": []}
            ),
            caplog.at_level(logging.ERROR),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        error_msgs = [m for m in caplog.messages if "max_turns ceiling" in m]
        assert len(error_msgs) >= 1
        # The log message must contain the attempt count (1/3).
        assert any("1" in m and "3" in m for m in error_msgs)


class TestPhase3_4TokenAccumulation:
    """ACs 12-13: per-issue + phase-total accumulation in Phase 3/4."""

    @pytest.mark.asyncio
    async def test_retried_issue_accumulates_tokens_from_all_attempts(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC 12: 2 issues (second requires 2 attempts) → per-issue total includes both attempts."""
        state = _make_state_with_issues(tmp_path, [1, 2])

        usage_issue1 = TokenUsage(input=100, output=10, cache_read=20, cache_write=2)
        # Issue 2: attempt 1 fails (exception, zero tokens), attempt 2 succeeds
        usage_issue2_attempt2 = TokenUsage(input=50, output=5, cache_read=10, cache_write=1)

        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # Issue 1, attempt 1: success
                return RunResult(text="", session_id=None, usage=usage_issue1)
            if call_count == 2:
                # Issue 2, attempt 1: fails (exception path → zero tokens in issue_total)
                raise RuntimeError("attempt 1 failed")
            # Issue 2, attempt 2: success
            return RunResult(text="", session_id=None, usage=usage_issue2_attempt2)

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": []},
            ),
            caplog.at_level(logging.INFO),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        # Both issues processed
        assert all(i.status == "closed" for i in state.issues)

        # 2 per-issue token log lines (one per issue)
        per_issue_msgs = [m for m in caplog.messages if "tokens: in=" in m]
        assert len(per_issue_msgs) == 2, f"Expected 2 per-issue lines, got: {per_issue_msgs}"

        # Phase total = issue1 usage + issue2 attempt2 usage (attempt1 raised, zero tokens)
        expected_total = TokenUsage(input=150, output=15, cache_read=30, cache_write=3)
        assert state.token_usage.get("phase3_4") == expected_total

        # Phase-complete line emitted
        complete_msgs = [m for m in caplog.messages if "3/4 complete:" in m]
        assert len(complete_msgs) == 1

    @pytest.mark.asyncio
    async def test_failed_issue_zero_tokens_included_in_phase_total(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC 13: fully-failed issue contributes zero tokens; phase total = successful issues only."""
        state = _make_state_with_issues(tmp_path, [1, 2])
        # Issue 1 fails all retries; issue 2 succeeds
        usage_issue2 = TokenUsage(input=200, output=20, cache_read=40, cache_write=4)
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            # First 2 calls belong to issue 1 (max_retries=2): always fail
            if call_count <= 2:
                raise RuntimeError("issue 1 always fails")
            return RunResult(text="", session_id=None, usage=usage_issue2)

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": []},
            ),
            caplog.at_level(logging.INFO),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=2,
            )

        # Issue 1 still open, issue 2 closed
        assert state.issues[0].status == "open"
        assert state.issues[1].status == "closed"

        # 2 per-issue token lines (one per issue, even the failed one)
        per_issue_msgs = [m for m in caplog.messages if "tokens: in=" in m]
        assert len(per_issue_msgs) == 2, f"Expected 2 per-issue lines, got: {per_issue_msgs}"

        # Phase total = issue2 usage only (issue1 contributed zero — no RunResult from exceptions)
        assert state.token_usage.get("phase3_4") == usage_issue2

        # Phase-complete line still emitted
        complete_msgs = [m for m in caplog.messages if "3/4 complete:" in m]
        assert len(complete_msgs) == 1


# ---------------------------------------------------------------------------
# MCP wiring tests (issue #177)
# ---------------------------------------------------------------------------


class TestPhase3_4McpWiring:
    """Phase 3/4 must wire build_mcp_servers into make_agent_options (issue #177)."""

    _FAKE_MCP_SERVERS = {"codebase_memory": {"type": "stdio", "command": "/bin/cm"}}

    @pytest.mark.asyncio
    async def test_mcp_servers_in_options_when_build_returns_dict(self, tmp_path: Path) -> None:
        """When build_mcp_servers returns a dict, options.mcp_servers equals that dict
        and allowed_tools contains the mcp__codebase_memory__* wildcard entry."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
            patch(
                "code_generator.orchestrator.phase3_4_implement.build_mcp_servers",
                return_value=self._FAKE_MCP_SERVERS,
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) >= 1
        opts = captured_options[0]
        assert opts.mcp_servers == self._FAKE_MCP_SERVERS
        assert "mcp__codebase_memory__*" in opts.allowed_tools

    @pytest.mark.asyncio
    async def test_mcp_servers_none_when_build_returns_none(self, tmp_path: Path) -> None:
        """When build_mcp_servers returns None, options.mcp_servers is None and
        allowed_tools has no mcp__ entries."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
            patch(
                "code_generator.orchestrator.phase3_4_implement.build_mcp_servers",
                return_value=None,
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) >= 1
        opts = captured_options[0]
        assert opts.mcp_servers is None
        assert not any("mcp__" in t for t in opts.allowed_tools)

    @pytest.mark.asyncio
    async def test_build_mcp_servers_called_once_per_phase_run(self, tmp_path: Path) -> None:
        """build_mcp_servers must be called exactly once per phase run, not once per issue."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
            patch(
                "code_generator.orchestrator.phase3_4_implement.build_mcp_servers",
                return_value=None,
            ) as mock_build,
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_build.assert_called_once_with(tmp_path)


# ---------------------------------------------------------------------------
# Tests for cached-or-fetch comments (issue #180)
# ---------------------------------------------------------------------------


class TestPhase3_4CommentCaching:
    """Phase 3/4 must use IssueState.comments cache; live-fetch only when None."""

    @pytest.mark.asyncio
    async def test_cached_comments_skips_live_fetch(self, tmp_path: Path) -> None:
        """When issue.comments is not None, fetch_formatted_comments is NOT called."""
        state = _make_state_with_issues(tmp_path, [1])
        state.issues[0].comments = "## Pre-fetched Issue Comments\n\nalice: LGTM"

        fetch_calls: list[int] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator._comments.fetch_formatted_comments",
                side_effect=lambda *a, **kw: fetch_calls.append(1) or "SHOULD NOT APPEAR",
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert fetch_calls == [], "fetch_formatted_comments must not be called when cache hit"

    @pytest.mark.asyncio
    async def test_cached_comments_appear_in_prompt(self, tmp_path: Path) -> None:
        """When issue.comments is cached, the cached text is injected into the prompt."""
        state = _make_state_with_issues(tmp_path, [1])
        state.issues[0].comments = "## Pre-fetched Issue Comments\n\nalice: cached-text"

        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator._comments.fetch_formatted_comments",
                return_value="LIVE-FETCH-SHOULD-NOT-APPEAR",
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert "cached-text" in captured_prompts[0]
        assert "LIVE-FETCH-SHOULD-NOT-APPEAR" not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_none_comments_calls_live_fetch(self, tmp_path: Path) -> None:
        """When issue.comments is None, fetch_formatted_comments IS called."""
        state = _make_state_with_issues(tmp_path, [1])
        # comments defaults to None

        fetch_calls: list[int] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator._comments.fetch_formatted_comments",
                side_effect=lambda *a, **kw: fetch_calls.append(1) or "",
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(fetch_calls) == 1, "fetch_formatted_comments must be called when cache is None"

    @pytest.mark.asyncio
    async def test_none_comments_persists_fetched_value(self, tmp_path: Path) -> None:
        """When issue.comments is None and fetch succeeds, result is persisted to IssueState."""
        state = _make_state_with_issues(tmp_path, [1])
        # comments defaults to None

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator._comments.fetch_formatted_comments",
                return_value="## Pre-fetched Issue Comments\n\nalice: fresh-fetch",
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert state.issues[0].comments == "## Pre-fetched Issue Comments\n\nalice: fresh-fetch"


# ---------------------------------------------------------------------------
# Tests for shared-client wiring (issue #184)
# ---------------------------------------------------------------------------


class TestPhase3_4SharedClient:
    """Phase 3/4 shared-client routing: run_with_shared_client + soft_reset (issue #184)."""

    @staticmethod
    def _make_fake_shared_client():
        """Return a minimal duck-typed shared client."""

        class FakeClient:
            async def query(self, prompt: str) -> None:
                pass

        return FakeClient()

    @pytest.mark.asyncio
    async def test_shared_mode_3_issues_uses_run_with_shared_client_3_times(
        self, tmp_path: Path
    ) -> None:
        """AC: shared-mode 3-issue cycle → 3 run_with_shared_client() calls."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        client = self._make_fake_shared_client()
        shared_client_calls: list[int] = []

        async def fake_run_with_shared_client(c, prompt, options, *, logger, state_path, **kw):
            shared_client_calls.append(1)
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase3_4_implement._sdk_runner.run_with_shared_client",
                side_effect=fake_run_with_shared_client,
            ),
            patch(
                "code_generator.orchestrator.phase3_4_implement._soft_reset_context",
                return_value=_DUMMY_RESET,
            ),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=client,
            )

        assert len(shared_client_calls) == 3

    @pytest.mark.asyncio
    async def test_shared_mode_3_issues_calls_soft_reset_2_times(self, tmp_path: Path) -> None:
        """AC: shared-mode 3-issue cycle → 2 soft_reset_context() calls."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        client = self._make_fake_shared_client()
        soft_reset_calls: list[int] = []

        async def fake_soft_reset(c, issue_number, memories_dir):
            soft_reset_calls.append(issue_number)
            return _DUMMY_RESET

        async def fake_run_with_shared_client(c, prompt, options, *, logger, state_path, **kw):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase3_4_implement._sdk_runner.run_with_shared_client",
                side_effect=fake_run_with_shared_client,
            ),
            patch(
                "code_generator.orchestrator.phase3_4_implement._soft_reset_context",
                side_effect=fake_soft_reset,
            ),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=client,
            )

        # 3 issues → 2 resets (between 1→2 and 2→3, not before issue 1)
        assert len(soft_reset_calls) == 2
        assert soft_reset_calls == [2, 3]

    @pytest.mark.asyncio
    async def test_shared_mode_context_management_enabled_on_each_call(
        self, tmp_path: Path
    ) -> None:
        """AC: context_management_enabled=True on every run_with_shared_client() call."""
        state = _make_state_with_issues(tmp_path, [1, 2])
        client = self._make_fake_shared_client()
        captured_options: list = []

        async def fake_run_with_shared_client(c, prompt, options, *, logger, state_path, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase3_4_implement._sdk_runner.run_with_shared_client",
                side_effect=fake_run_with_shared_client,
            ),
            patch(
                "code_generator.orchestrator.phase3_4_implement._soft_reset_context",
                return_value=_DUMMY_RESET,
            ),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=client,
            )

        assert len(captured_options) == 2
        for opts in captured_options:
            assert getattr(opts, "context_management", None) is not None, (
                "context_management must be set (context_management_enabled=True)"
            )

    @pytest.mark.asyncio
    async def test_fresh_mode_3_issues_uses_runner_run_3_times(self, tmp_path: Path) -> None:
        """AC: fresh-mode 3-issue cycle → 3 rate_limit.main_loop calls, 0 run_with_shared_client."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        main_loop_calls: list[int] = []
        shared_client_calls: list[int] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            main_loop_calls.append(1)
            return _make_run_result()

        async def fake_run_with_shared_client(c, prompt, options, *, logger, state_path, **kw):
            shared_client_calls.append(1)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch(
                "code_generator.orchestrator.phase3_4_implement._sdk_runner.run_with_shared_client",
                side_effect=fake_run_with_shared_client,
            ),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            # No shared_client → fresh mode
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(main_loop_calls) == 3
        assert len(shared_client_calls) == 0

    @pytest.mark.asyncio
    async def test_fresh_mode_context_management_enabled(self, tmp_path: Path) -> None:
        """AC: fresh-mode also uses context_management_enabled=True (regression guard)."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) == 1
        assert getattr(captured_options[0], "context_management", None) is not None, (
            "context_management must be set in fresh mode too"
        )

    @pytest.mark.asyncio
    async def test_soft_reset_not_called_in_fresh_mode(self, tmp_path: Path) -> None:
        """soft_reset_context must NOT be called when shared_client is None."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        soft_reset_calls: list[int] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        async def fake_soft_reset(c, issue_number, memories_dir):
            soft_reset_calls.append(issue_number)
            return _DUMMY_RESET

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch(
                "code_generator.orchestrator.phase3_4_implement._soft_reset_context",
                side_effect=fake_soft_reset,
            ),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert soft_reset_calls == []


# ---------------------------------------------------------------------------
# Tests for compaction / context-edit handling (issue #184)
# ---------------------------------------------------------------------------


class TestPhase3_4CompactionHandling:
    """Compaction / ContextEditResult message handling in sdk_runner._drain_messages."""

    @pytest.mark.asyncio
    async def test_context_edit_message_logged_and_loop_continues(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC: ContextEditResult mid-stream → logged as 'context edit triggered', loop continues."""
        from code_generator.runner.sdk_runner import run_with_shared_client
        from code_generator.runner.types import RunResult

        class FakeTextBlock:
            def __init__(self, text: str) -> None:
                self.text = text

        class FakeAssistantMessage:
            def __init__(self, text: str) -> None:
                self.content = [FakeTextBlock(text)]
                self.model = "claude-sonnet-4-6"

        class FakeContextEditMessage:
            """Duck-typed compaction / context-edit intermediate message."""

            freed_tokens = 4500
            type = "context_edit"
            # Deliberately no model, content, session_id, is_error, rate_limit_info

        class FakeResultMessage:
            session_id = "sess-compaction"
            is_error = False
            subtype = "success"
            stop_reason = "end_turn"
            num_turns = 3
            usage = {
                "input_tokens": 50,
                "output_tokens": 10,
                "cache_read_input_tokens": 0,
                "cache_creation_input_tokens": 0,
            }

        from unittest.mock import MagicMock as _MagicMock

        messages = [
            FakeAssistantMessage("before compaction"),
            FakeContextEditMessage(),
            FakeAssistantMessage("after compaction"),
            FakeResultMessage(),
        ]

        class FakeClient:
            async def query(self, _prompt: str) -> None:
                pass

            async def receive_messages(self):
                for msg in messages:
                    yield msg

        client = FakeClient()
        opts = _MagicMock()
        opts.model = "claude-sonnet-4-6"
        opts.effort = None
        opts.max_turns = 80
        state_path = tmp_path / "state.json"
        logger = logging.getLogger("test.compaction")

        with caplog.at_level(logging.INFO):
            result = await run_with_shared_client(
                client, "prompt", opts, logger=logger, state_path=state_path
            )

        # Loop continued past the compaction message and completed normally.
        assert isinstance(result, RunResult)
        assert "before compaction" in result.text
        assert "after compaction" in result.text

        # Log line emitted with correct format.
        compaction_logs = [m for m in caplog.messages if "context edit triggered" in m]
        assert len(compaction_logs) >= 1
        assert "context_edit" in compaction_logs[0]
        assert "4500" in compaction_logs[0]

    @pytest.mark.asyncio
    async def test_compaction_log_line_format_type_and_freed_tokens(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC: compaction log line contains 'type=<type>' and 'freed_tokens=<n>'."""
        from unittest.mock import MagicMock as _MagicMock

        from code_generator.runner.sdk_runner import run_with_shared_client

        class FakeTextBlock:
            def __init__(self, text: str) -> None:
                self.text = text

        class FakeAssistantMessage:
            def __init__(self) -> None:
                self.content = [FakeTextBlock("done")]
                self.model = "claude-sonnet-4-6"

        class FakeCompactionMsg:
            freed_tokens = 12345
            type = "compact_result"

        class FakeResultMessage:
            session_id = "s"
            is_error = False
            subtype = "success"
            stop_reason = "end_turn"
            num_turns = 1
            usage = {
                "input_tokens": 10,
                "output_tokens": 2,
                "cache_read_input_tokens": 0,
                "cache_creation_input_tokens": 0,
            }

        messages = [FakeAssistantMessage(), FakeCompactionMsg(), FakeResultMessage()]

        class FakeClient:
            async def query(self, _prompt: str) -> None:
                pass

            async def receive_messages(self):
                for msg in messages:
                    yield msg

        opts = _MagicMock()
        opts.model = "claude-sonnet-4-6"
        opts.effort = None
        opts.max_turns = 80

        with caplog.at_level(logging.INFO):
            await run_with_shared_client(
                FakeClient(),
                "prompt",
                opts,
                logger=logging.getLogger("test.compaction.format"),
                state_path=tmp_path / "state.json",
            )

        compaction_logs = [m for m in caplog.messages if "context edit triggered" in m]
        assert len(compaction_logs) == 1
        log_line = compaction_logs[0]
        assert "compact_result" in log_line
        assert "12345" in log_line
