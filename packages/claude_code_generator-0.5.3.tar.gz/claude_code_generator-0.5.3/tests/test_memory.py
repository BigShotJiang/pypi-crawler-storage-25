"""Tests for src/code_generator/memory.py — atomic write primitives.

Test strategy: Red → Green → Refactor (TDD).
Each acceptance criterion from issue #154 has at least one dedicated test.
"""

import threading
from pathlib import Path

import pytest

from code_generator.memory import (
    REPOMAP_FALLBACK,
    append_memory_file,
    clear_memory_file,
    overwrite_memory_file,
    read_cycle_repomap,
    read_memory_file,
    write_memory_file,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mem_dir(tmp_path: Path) -> Path:
    """Return a fresh temp directory to serve as memories_dir."""
    return tmp_path / "memories"


# ---------------------------------------------------------------------------
# Basic write / overwrite / append / clear
# ---------------------------------------------------------------------------


def test_write_creates_file(mem_dir: Path) -> None:
    """write_memory_file creates the file with the given content."""
    write_memory_file(mem_dir, "current-issue.md", "hello")
    assert (mem_dir / "current-issue.md").read_text(encoding="utf-8") == "hello"


def test_overwrite_replaces_content(mem_dir: Path) -> None:
    """overwrite_memory_file replaces existing content atomically."""
    write_memory_file(mem_dir, "current-issue.md", "old content")
    overwrite_memory_file(mem_dir, "current-issue.md", "new content")
    assert (mem_dir / "current-issue.md").read_text(encoding="utf-8") == "new content"


def test_append_preserves_prior_content(mem_dir: Path) -> None:
    """append_memory_file concatenates to existing content."""
    write_memory_file(mem_dir, "cycle-summary.md", "line1\n")
    append_memory_file(mem_dir, "cycle-summary.md", "line2\n")
    assert (mem_dir / "cycle-summary.md").read_text(encoding="utf-8") == "line1\nline2\n"


def test_append_creates_file_when_absent(mem_dir: Path) -> None:
    """append_memory_file works on a non-existent file (starts from empty)."""
    append_memory_file(mem_dir, "new-file.md", "only line\n")
    assert (mem_dir / "new-file.md").read_text(encoding="utf-8") == "only line\n"


def test_clear_empties_file(mem_dir: Path) -> None:
    """clear_memory_file leaves the file empty."""
    write_memory_file(mem_dir, "current-issue.md", "some content")
    clear_memory_file(mem_dir, "current-issue.md")
    assert (mem_dir / "current-issue.md").read_text(encoding="utf-8") == ""


# ---------------------------------------------------------------------------
# Path traversal rejection
# ---------------------------------------------------------------------------


def test_traversal_dotdot_rejected(mem_dir: Path) -> None:
    """relpath containing '../' raises ValueError."""
    with pytest.raises(ValueError, match="escapes memories_dir"):
        write_memory_file(mem_dir, "../etc/passwd", "bad")


def test_absolute_path_rejected(mem_dir: Path) -> None:
    """An absolute relpath raises ValueError."""
    with pytest.raises(ValueError, match="escapes memories_dir"):
        write_memory_file(mem_dir, "/etc/passwd", "bad")


def test_symlink_escape_rejected(mem_dir: Path, tmp_path: Path) -> None:
    """A symlink pointing outside memories_dir raises ValueError on resolve."""
    mem_dir.mkdir(parents=True, exist_ok=True)
    outside = tmp_path / "outside.md"
    outside.write_text("secret", encoding="utf-8")
    link = mem_dir / "link.md"
    link.symlink_to(outside)

    with pytest.raises(ValueError, match="escapes memories_dir"):
        write_memory_file(mem_dir, "link.md", "injected")


# ---------------------------------------------------------------------------
# mkdir idempotency
# ---------------------------------------------------------------------------


def test_mkdir_idempotent_when_dir_exists(mem_dir: Path) -> None:
    """Writing twice does not raise even though memories_dir already exists."""
    write_memory_file(mem_dir, "file.md", "first")
    write_memory_file(mem_dir, "file.md", "second")  # must not raise
    assert (mem_dir / "file.md").read_text(encoding="utf-8") == "second"


def test_mkdir_creates_missing_dir(tmp_path: Path) -> None:
    """memories_dir is created automatically if it doesn't exist."""
    mem_dir = tmp_path / "deep" / "memories"
    assert not mem_dir.exists()
    write_memory_file(mem_dir, "file.md", "content")
    assert mem_dir.is_dir()
    assert (mem_dir / "file.md").read_text(encoding="utf-8") == "content"


# ---------------------------------------------------------------------------
# Concurrent-write safety
# ---------------------------------------------------------------------------


def test_concurrent_appends_no_partial_writes(mem_dir: Path) -> None:
    """Two threads appending the same file produce no partial writes.

    The atomic-replace guarantee means at worst one write overwrites the other
    cleanly — no interleaved/partial content is ever visible.
    """
    target_relpath = "shared.md"
    errors: list[Exception] = []

    def append_lines(label: str, count: int) -> None:
        try:
            for i in range(count):
                append_memory_file(mem_dir, target_relpath, f"{label}-{i}\n")
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    t1 = threading.Thread(target=append_lines, args=("A", 20))
    t2 = threading.Thread(target=append_lines, args=("B", 20))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    assert not errors, f"Thread raised: {errors}"

    content = (mem_dir / target_relpath).read_text(encoding="utf-8")
    lines = [ln for ln in content.splitlines() if ln]
    # Each line must be a complete, un-interleaved label-N entry.
    for line in lines:
        parts = line.split("-")
        assert len(parts) == 2, f"Partial/corrupt line: {line!r}"
        assert parts[0] in ("A", "B"), f"Unknown label in line: {line!r}"
        assert parts[1].isdigit(), f"Non-integer index in line: {line!r}"


# ---------------------------------------------------------------------------
# UTF-8 encoding
# ---------------------------------------------------------------------------


def test_utf8_roundtrip(mem_dir: Path) -> None:
    """Non-ASCII content is preserved correctly."""
    content = "Héllo wörld — 日本語\n"
    write_memory_file(mem_dir, "unicode.md", content)
    assert (mem_dir / "unicode.md").read_text(encoding="utf-8") == content


# ---------------------------------------------------------------------------
# read_memory_file
# ---------------------------------------------------------------------------


def test_read_memory_file_returns_content_when_file_exists(mem_dir: Path) -> None:
    """read_memory_file returns the stored content when the file exists."""
    write_memory_file(mem_dir, "notes.md", "hello world")
    assert read_memory_file(mem_dir, "notes.md") == "hello world"


def test_read_memory_file_returns_empty_string_when_absent(mem_dir: Path) -> None:
    """read_memory_file returns '' when the file does not exist (no exception)."""
    result = read_memory_file(mem_dir, "nonexistent.md")
    assert result == ""


def test_read_memory_file_rejects_path_traversal(mem_dir: Path) -> None:
    """read_memory_file raises ValueError on directory-traversal relpath."""
    with pytest.raises(ValueError, match="escapes memories_dir"):
        read_memory_file(mem_dir, "../secret.md")


def test_read_memory_file_utf8_roundtrip(mem_dir: Path) -> None:
    """read_memory_file preserves non-ASCII content correctly."""
    content = "Héllo — 日本語\n"
    write_memory_file(mem_dir, "unicode.md", content)
    assert read_memory_file(mem_dir, "unicode.md") == content


# ---------------------------------------------------------------------------
# read_cycle_repomap
# ---------------------------------------------------------------------------


def test_read_cycle_repomap_returns_content_when_file_exists(mem_dir: Path) -> None:
    """read_cycle_repomap returns file content when cycle-repo-map.md exists."""
    write_memory_file(mem_dir, "cycle-repo-map.md", "file.py::MyClass\n")
    result = read_cycle_repomap(mem_dir)
    assert result == "file.py::MyClass\n"


def test_read_cycle_repomap_returns_fallback_when_file_missing(mem_dir: Path) -> None:
    """read_cycle_repomap returns REPOMAP_FALLBACK when cycle-repo-map.md is absent."""
    # mem_dir does not exist yet
    result = read_cycle_repomap(mem_dir)
    assert result == REPOMAP_FALLBACK


def test_read_cycle_repomap_returns_fallback_when_file_empty(mem_dir: Path) -> None:
    """read_cycle_repomap returns REPOMAP_FALLBACK when cycle-repo-map.md is empty."""
    write_memory_file(mem_dir, "cycle-repo-map.md", "")
    result = read_cycle_repomap(mem_dir)
    assert result == REPOMAP_FALLBACK


def test_read_cycle_repomap_returns_fallback_when_file_whitespace_only(mem_dir: Path) -> None:
    """read_cycle_repomap returns fallback for whitespace-only content."""
    write_memory_file(mem_dir, "cycle-repo-map.md", "   \n  ")
    result = read_cycle_repomap(mem_dir)
    assert result == REPOMAP_FALLBACK


def test_repomap_fallback_constant_matches_expected_string() -> None:
    """REPOMAP_FALLBACK equals the canonical sentinel string."""
    assert REPOMAP_FALLBACK == (
        "(graphify report unavailable — rely on feature-dev:code-explorer or MCP tools)"
    )
