"""Tests for code_generator.orchestrator.phase5_closure."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase5_closure
from code_generator.orchestrator.phase5_closure import FixResult
from code_generator.repo_info import RepoInfo
from code_generator.runner.sdk_runner import RunResult

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state(tmp_path: Path, issues: list[_state.IssueState] | None = None) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    if issues:
        st.issues = issues
    st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase5PostSessionListIssuesFields:
    """The post-session gh.list_issues call must only request number+labels fields."""

    @pytest.mark.asyncio
    async def test_post_session_list_issues_uses_number_and_labels_fields(
        self, tmp_path: Path
    ) -> None:
        state = _make_state(tmp_path)
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(
                phase5_closure.gh,
                "list_issues",
                side_effect=[[], []],  # pre-fetch, then post-session
            ) as mock_list,
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_list.call_count == 2
        post_session_call = mock_list.call_args_list[1]
        assert post_session_call.kwargs.get("fields") == ["number", "labels"]

    @pytest.mark.asyncio
    async def test_pre_fetch_list_issues_uses_number_and_title_fields(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(
                phase5_closure.gh,
                "list_issues",
                side_effect=[[], []],  # pre-fetch, then post-session
            ) as mock_list,
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        pre_fetch_call = mock_list.call_args_list[0]
        assert pre_fetch_call.kwargs.get("fields") == ["number", "title"]


class TestPhase5Run:
    @pytest.mark.asyncio
    async def test_returns_empty_fix_result_when_no_new_issues(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
        ):
            result = await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert isinstance(result, FixResult)
        assert result.new_issues == []

    @pytest.mark.asyncio
    async def test_detects_new_fix_issues(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )

        new_raw = [{"number": 2, "title": "fix: something", "state": "open", "labels": []}]

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=new_raw),
        ):
            result = await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(result.new_issues) == 1
        assert result.new_issues[0].number == 2

    @pytest.mark.asyncio
    async def test_appends_new_issues_to_state(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )

        new_raw = [{"number": 10, "title": "fix: bug", "state": "open", "labels": []}]

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=new_raw),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert any(i.number == 10 for i in state.issues)

    @pytest.mark.asyncio
    async def test_uses_cycle_issues_in_multi_cycle(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=5,
            issues=[_state.IssueState(number=5, status="closed", agent="python-pro")],
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)

        new_raw = [{"number": 20, "title": "fix: x", "state": "open", "labels": []}]

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=new_raw),
        ):
            result = await phase5_closure.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert any(i.number == 20 for i in cycle.issues)
        assert result.new_issues[0].number == 20

    @pytest.mark.asyncio
    async def test_uses_opus_model(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None
        options = mock_loop.call_args.args[2]
        assert options.model == "claude-opus-4-7"

    @pytest.mark.asyncio
    async def test_multiple_fix_issues_all_appended_to_state(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )

        new_raw = [
            {"number": 10, "title": "fix: alpha", "state": "open", "labels": []},
            {"number": 11, "title": "fix: beta", "state": "open", "labels": []},
            {"number": 12, "title": "fix: gamma", "state": "open", "labels": []},
        ]

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=new_raw),
        ):
            result = await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(result.new_issues) == 3
        new_numbers = {i.number for i in result.new_issues}
        assert new_numbers == {10, 11, 12}
        state_numbers = {i.number for i in state.issues}
        assert {10, 11, 12}.issubset(state_numbers)

    @pytest.mark.asyncio
    async def test_multiple_fix_issues_all_appended_to_cycle(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=5,
            issues=[_state.IssueState(number=5, status="closed", agent="python-pro")],
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)

        new_raw = [
            {"number": 30, "title": "fix: one", "state": "open", "labels": []},
            {"number": 31, "title": "fix: two", "state": "open", "labels": []},
            {"number": 32, "title": "fix: three", "state": "open", "labels": []},
        ]

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=new_raw),
        ):
            result = await phase5_closure.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(result.new_issues) == 3
        new_numbers = {i.number for i in result.new_issues}
        assert new_numbers == {30, 31, 32}
        cycle_numbers = {i.number for i in cycle.issues}
        assert {30, 31, 32}.issubset(cycle_numbers)

    @pytest.mark.asyncio
    async def test_gh_error_on_list_issues_returns_empty_fix_result(self, tmp_path: Path) -> None:
        from code_generator.gh import GhError

        state = _make_state(tmp_path)

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", side_effect=GhError(1, "network error")),
        ):
            result = await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result.new_issues == []


class TestFetchOpenIssuesWithComments:
    """Unit tests for the _fetch_open_issues_with_comments private helper."""

    def test_returns_empty_string_when_no_open_issues(self) -> None:
        logger = logging.getLogger("test")
        with patch.object(phase5_closure.gh, "list_issues", return_value=[]):
            result = phase5_closure._fetch_open_issues_with_comments(None, None, logger)
        assert result == ""

    def test_returns_empty_string_on_list_issues_gh_error(self) -> None:
        from code_generator.gh import GhError

        logger = logging.getLogger("test")
        with patch.object(
            phase5_closure.gh, "list_issues", side_effect=GhError(1, "network error")
        ):
            result = phase5_closure._fetch_open_issues_with_comments(None, None, logger)
        assert result == ""

    def test_formats_issues_with_comments(self) -> None:
        logger = logging.getLogger("test")
        raw_issues = [{"number": 5, "title": "fix: something", "state": "open"}]
        full_issue = {
            "number": 5,
            "title": "fix: something",
            "body": "body text",
            "comments": [
                {"author": {"login": "alice"}, "createdAt": "2026-01-01T00:00:00Z", "body": "LGTM"}
            ],
        }
        with (
            patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues),
            patch.object(phase5_closure.gh, "view_issue", return_value=full_issue),
        ):
            result = phase5_closure._fetch_open_issues_with_comments(None, None, logger)

        assert "Issue #5" in result
        assert "fix: something" in result
        assert "## Pre-fetched Issue Comments" in result
        assert "alice" in result

    def test_view_issue_error_handled_gracefully(self) -> None:
        from code_generator.gh import GhError

        logger = logging.getLogger("test")
        raw_issues = [{"number": 3, "title": "feat: x", "state": "open"}]
        with (
            patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues),
            patch.object(phase5_closure.gh, "view_issue", side_effect=GhError(1, "not found")),
        ):
            result = phase5_closure._fetch_open_issues_with_comments(None, None, logger)

        # Should still include the issue header even without comments
        assert "Issue #3" in result

    def test_uses_milestone_filter(self) -> None:
        logger = logging.getLogger("test")
        repo = RepoInfo(host="github.com", owner="acme", name="proj")
        with patch.object(phase5_closure.gh, "list_issues", return_value=[]) as mock_list:
            phase5_closure._fetch_open_issues_with_comments(repo, "Sprint 1", logger)
        mock_list.assert_called_once_with(
            repo, milestone="Sprint 1", state="open", fields=["number", "title"]
        )

    def test_list_issues_called_with_number_and_title_fields_only(self) -> None:
        """_fetch_open_issues_with_comments requests only number+title fields (YAGNI)."""
        logger = logging.getLogger("test")
        with patch.object(phase5_closure.gh, "list_issues", return_value=[]) as mock_list:
            phase5_closure._fetch_open_issues_with_comments(None, None, logger)
        mock_list.assert_called_once_with(
            None, milestone=None, state="open", fields=["number", "title"]
        )

    def test_multiple_issues_separated_by_divider(self) -> None:
        logger = logging.getLogger("test")
        raw_issues = [
            {"number": 1, "title": "first", "state": "open"},
            {"number": 2, "title": "second", "state": "open"},
        ]
        with (
            patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues),
            patch.object(
                phase5_closure.gh, "view_issue", return_value={"number": 1, "comments": []}
            ),
        ):
            result = phase5_closure._fetch_open_issues_with_comments(None, None, logger)

        assert "Issue #1" in result
        assert "Issue #2" in result
        assert "---" in result


class TestPhase5PromptContainsOpenIssues:
    """Regression tests: prompt must include pre-fetched issue comments."""

    @pytest.mark.asyncio
    async def test_prompt_contains_issue_comments_section(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        mock_loop = AsyncMock(return_value=_make_run_result())

        raw_issues = [{"number": 7, "title": "feat: thing", "state": "open"}]
        full_issue = {
            "number": 7,
            "title": "feat: thing",
            "body": "",
            "comments": [
                {"author": {"login": "bob"}, "createdAt": "2026-01-02T00:00:00Z", "body": "Done!"}
            ],
        }

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(
                phase5_closure.gh,
                "list_issues",
                side_effect=[raw_issues, []],  # pre-fetch, then post-session
            ),
            patch.object(phase5_closure.gh, "view_issue", return_value=full_issue),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None, "main_loop was never called"
        prompt = mock_loop.call_args.args[1]
        assert "## Pre-fetched Issue Comments" in prompt
        assert "bob" in prompt
        assert "Issue #7" in prompt

    @pytest.mark.asyncio
    async def test_prompt_has_no_issues_section_when_none_exist(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(
                phase5_closure.gh,
                "list_issues",
                return_value=[],  # both pre-fetch and post-session
            ),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None, "main_loop was never called"
        prompt = mock_loop.call_args.args[1]
        # No issues means the placeholder renders as empty string or "no issues" text
        assert "OPEN_ISSUES_WITH_COMMENTS" not in prompt


class TestFixIssueLabelsPopulated:
    """Fix issues created by phase5 must carry their GitHub labels."""

    @pytest.mark.asyncio
    async def test_fix_issue_carries_complexity_high_label(self, tmp_path: Path) -> None:
        """When gh returns a fix issue with complexity:high, the IssueState must include it."""
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )
        new_raw = [
            {
                "number": 5,
                "title": "fix: hard thing",
                "state": "open",
                "labels": [{"name": "complexity:high"}, {"name": "phase:fix"}],
            }
        ]

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=new_raw),
        ):
            result = await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(result.new_issues) == 1
        issue_state = result.new_issues[0]
        assert "complexity:high" in issue_state.labels
        assert "phase:fix" in issue_state.labels

    @pytest.mark.asyncio
    async def test_fix_issue_with_no_labels_gets_empty_labels(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )
        new_raw = [{"number": 6, "title": "fix: simple", "state": "open", "labels": []}]

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=new_raw),
        ):
            result = await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result.new_issues[0].labels == []


class TestDiffBasedReview:
    """Unit tests for the fetch_diff_since_base helper and Phase 5 integration."""

    # ------------------------------------------------------------------
    # fetch_diff_since_base unit tests
    # ------------------------------------------------------------------

    def test_returns_empty_string_when_base_commit_is_none(self, tmp_path: Path) -> None:
        logger = logging.getLogger("test")
        result = phase5_closure.fetch_diff_since_base(None, tmp_path, logger)
        assert result == ""

    def test_returns_diff_output_when_base_commit_provided(self, tmp_path: Path) -> None:
        logger = logging.getLogger("test")
        stat_output = " foo.py | 2 +-\n 1 file changed"
        diff_output = "diff --git a/foo.py b/foo.py\n+added line"

        with patch.object(
            phase5_closure.git_ops,
            "git_diff",
            side_effect=[stat_output, diff_output],
        ):
            result = phase5_closure.fetch_diff_since_base("abc123", tmp_path, logger)

        assert stat_output in result
        assert diff_output in result

    def test_truncates_diff_exceeding_20kb(self, tmp_path: Path) -> None:
        logger = logging.getLogger("test")
        large_diff = "x" * (21 * 1024)  # 21KB > 20KB cap

        with patch.object(
            phase5_closure.git_ops,
            "git_diff",
            side_effect=["stat line", large_diff],
        ):
            result = phase5_closure.fetch_diff_since_base("abc123", tmp_path, logger)

        assert "truncated" in result.lower()
        assert len(result.encode()) < 100 * 1024  # sanity: well under 100KB

    def test_returns_empty_string_and_logs_warning_on_git_error(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        logger = logging.getLogger("test_git_error")
        with (
            caplog.at_level(logging.WARNING, logger="test_git_error"),
            patch.object(
                phase5_closure.git_ops,
                "git_diff",
                side_effect=phase5_closure.git_ops.GitError(128, "fatal: bad revision"),
            ),
        ):
            result = phase5_closure.fetch_diff_since_base("abc123", tmp_path, logger)

        assert result == ""
        assert any("diff" in rec.message.lower() for rec in caplog.records)

    # ------------------------------------------------------------------
    # Phase 5 run() integration: DIFF_SINCE_BASE in prompt
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_prompt_contains_diff_when_base_commit_set_in_state(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        state.base_commit = "deadbeef"
        mock_loop = AsyncMock(return_value=_make_run_result())
        diff_content = "diff --git a/foo.py b/foo.py\n+new line"

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch.object(
                phase5_closure.git_ops,
                "git_diff",
                side_effect=["stat summary", diff_content],
            ),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None, "main_loop was never called"
        prompt = mock_loop.call_args.args[1]
        assert diff_content in prompt
        assert "stat summary" in prompt

    @pytest.mark.asyncio
    async def test_prompt_has_empty_diff_section_when_base_commit_is_none(
        self, tmp_path: Path
    ) -> None:
        state = _make_state(tmp_path)
        state.base_commit = None
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None, "main_loop was never called"
        prompt = mock_loop.call_args.args[1]
        assert "DIFF_SINCE_BASE" not in prompt

    @pytest.mark.asyncio
    async def test_uses_cycle_base_commit_in_multi_cycle_mode(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=5,
            issues=[],
            commit_sha=None,
            base_commit="cycle_base_sha",
        )
        _state.save_state(state_dir / "state.json", st)
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch.object(
                phase5_closure.git_ops,
                "git_diff",
                side_effect=["cycle stat", "cycle diff body"],
            ),
        ):
            await phase5_closure.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None, "main_loop was never called"
        prompt = mock_loop.call_args.args[1]
        assert "cycle diff body" in prompt


class TestFetchDiffSinceBaseTruncation:
    """Acceptance criteria: diff >20KB → marker present + WARNING logged; ≤20KB → neither."""

    def test_diff_exceeding_20kb_has_truncation_marker(self, tmp_path: Path) -> None:
        logger = logging.getLogger("test_diff_marker")
        large_diff = "x" * (21 * 1024)

        with patch.object(
            phase5_closure.git_ops,
            "git_diff",
            side_effect=["stat line", large_diff],
        ):
            result = phase5_closure.fetch_diff_since_base("abc123", tmp_path, logger)

        assert "truncated" in result.lower(), "Truncation marker must appear in result"

    def test_diff_exceeding_20kb_logs_warning_with_byte_counts(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        logger = logging.getLogger("test_diff_warning")
        large_diff = "x" * (21 * 1024)

        with (
            caplog.at_level(logging.WARNING, logger="test_diff_warning"),
            patch.object(
                phase5_closure.git_ops,
                "git_diff",
                side_effect=["stat line", large_diff],
            ),
        ):
            phase5_closure.fetch_diff_since_base("abc123", tmp_path, logger)

        warning_messages = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
        assert any(
            "phase5: diff truncated" in msg and "bytes" in msg for msg in warning_messages
        ), (
            f"Expected 'phase5: diff truncated from N bytes to M bytes' warning, got: {warning_messages}"
        )

    def test_diff_within_20kb_has_no_truncation_marker(self, tmp_path: Path) -> None:
        logger = logging.getLogger("test_diff_no_trunc")
        small_diff = "x" * (10 * 1024)

        with patch.object(
            phase5_closure.git_ops,
            "git_diff",
            side_effect=["stat line", small_diff],
        ):
            result = phase5_closure.fetch_diff_since_base("abc123", tmp_path, logger)

        assert "truncated" not in result.lower(), "No truncation marker for small diff"

    def test_diff_within_20kb_logs_no_warning(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        logger = logging.getLogger("test_diff_no_warn")
        small_diff = "x" * (10 * 1024)

        with (
            caplog.at_level(logging.WARNING, logger="test_diff_no_warn"),
            patch.object(
                phase5_closure.git_ops,
                "git_diff",
                side_effect=["stat line", small_diff],
            ),
        ):
            phase5_closure.fetch_diff_since_base("abc123", tmp_path, logger)

        warning_records = [r for r in caplog.records if r.levelno == logging.WARNING]
        assert not warning_records, f"No WARNING expected for small diff; got: {warning_records}"


class TestPromptFileContainsDiffReview:
    """Verify the prompt file itself has the required Diff review content."""

    def test_prompt_file_contains_diff_review_line(self) -> None:
        from code_generator.prompts import load_prompt

        prompt = load_prompt(
            "prompt-phase-5-final-review.md",
            CYCLE_SCOPE="test scope",
            MILESTONE_TITLE="test milestone",
            OPEN_ISSUES_WITH_COMMENTS="",
            DIFF_SINCE_BASE="",
            LINT_ERRORS="",
        )
        assert "Diff review:" in prompt

    def test_prompt_file_contains_diff_since_base_section(self) -> None:
        from code_generator.prompts import load_prompt

        prompt = load_prompt(
            "prompt-phase-5-final-review.md",
            CYCLE_SCOPE="test scope",
            MILESTONE_TITLE="test milestone",
            OPEN_ISSUES_WITH_COMMENTS="",
            DIFF_SINCE_BASE="",
            LINT_ERRORS="",
        )
        assert "Pre-fetched diff since base commit" in prompt


class TestKnownNumbers:
    """Unit tests for the _known_numbers helper (no I/O, no async)."""

    def test_single_mode_uses_state_issues(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [
                _state.IssueState(number=3, status="closed", agent="python-pro"),
                _state.IssueState(number=7, status="open", agent="python-pro"),
            ],
        )
        result = phase5_closure._known_numbers(state, None)
        assert result == {3, 7}

    def test_multi_cycle_uses_cycle_issues_not_state(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=5,
            issues=[
                _state.IssueState(number=10, status="closed", agent="python-pro"),
                _state.IssueState(number=20, status="open", agent="python-pro"),
            ],
            commit_sha=None,
        )
        result = phase5_closure._known_numbers(state, cycle)
        # Must use cycle.issues, not state.issues (which has only #1).
        assert result == {10, 20}
        assert 1 not in result


# ---------------------------------------------------------------------------
# MCP wiring tests (issue #177)
# ---------------------------------------------------------------------------


class TestPhase5McpWiring:
    """Phase 5 must wire build_mcp_servers into make_agent_options (issue #177)."""

    _FAKE_MCP_SERVERS = {"codebase_memory": {"type": "stdio", "command": "/bin/cm"}}

    @pytest.mark.asyncio
    async def test_mcp_servers_in_options_when_build_returns_dict(self, tmp_path: Path) -> None:
        """When build_mcp_servers returns a dict, options.mcp_servers equals that dict
        and allowed_tools contains the mcp__codebase_memory__* wildcard entry."""
        from unittest.mock import patch

        state = _make_state(tmp_path)
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch(
                "code_generator.orchestrator.phase5_closure.build_mcp_servers",
                return_value=self._FAKE_MCP_SERVERS,
            ),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None
        options = mock_loop.call_args.args[2]
        assert options.mcp_servers == self._FAKE_MCP_SERVERS
        assert "mcp__codebase_memory__*" in options.allowed_tools

    @pytest.mark.asyncio
    async def test_mcp_servers_none_when_build_returns_none(self, tmp_path: Path) -> None:
        """When build_mcp_servers returns None, options.mcp_servers is None and
        allowed_tools has no mcp__ entries."""
        from unittest.mock import patch

        state = _make_state(tmp_path)
        mock_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch(
                "code_generator.orchestrator.phase5_closure.build_mcp_servers",
                return_value=None,
            ),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_loop.call_args is not None
        options = mock_loop.call_args.args[2]
        assert options.mcp_servers is None
        assert not any("mcp__" in t for t in options.allowed_tools)

    @pytest.mark.asyncio
    async def test_build_mcp_servers_called_once_per_phase_run(self, tmp_path: Path) -> None:
        """build_mcp_servers must be called exactly once per phase run."""
        from unittest.mock import patch

        state = _make_state(tmp_path)

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_run_result()),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch(
                "code_generator.orchestrator.phase5_closure.build_mcp_servers",
                return_value=None,
            ) as mock_build,
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_build.assert_called_once_with(tmp_path)


# ---------------------------------------------------------------------------
# Tests for cached-or-fetch comments in Phase 5 (issue #180)
# ---------------------------------------------------------------------------


class TestPhase5CommentCaching:
    """Phase 5 must use IssueState.comments cache; live-fetch only when None."""

    def _make_state_with_issues(
        self, tmp_path: Path, issues: list[_state.IssueState]
    ) -> _state.State:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = issues
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        _state.save_state(state_dir / "state.json", st)
        return st

    def test_cached_comments_skips_fetch_issue_comments(self, tmp_path: Path) -> None:
        """When IssueState.comments is set, fetch_issue_comments is NOT called."""
        logger = logging.getLogger("test")
        issues = [
            _state.IssueState(
                number=5,
                status="open",
                agent="python-pro",
                comments="## Pre-fetched Issue Comments\n\nalice: cached",
            )
        ]
        state = self._make_state_with_issues(tmp_path, issues)
        raw_issues = [{"number": 5, "title": "fix: something"}]
        fetch_calls: list[int] = []

        # Patch at _comments level since get_or_fetch_comments calls it there.
        with (
            patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues),
            patch(
                "code_generator.orchestrator._comments.fetch_issue_comments",
                side_effect=lambda *a, **kw: fetch_calls.append(1) or [],
            ),
        ):
            phase5_closure._fetch_open_issues_with_comments(
                state.repo,
                None,
                logger,
                state=state,
                cycle=None,
                state_path=tmp_path / ".code-generator" / "state.json",
            )

        assert fetch_calls == [], "fetch_issue_comments must not be called when cache hit"

    def test_cached_comments_appear_in_result(self, tmp_path: Path) -> None:
        """When IssueState.comments is cached, the cached text appears in the output."""
        logger = logging.getLogger("test")
        issues = [
            _state.IssueState(
                number=5,
                status="open",
                agent="python-pro",
                comments="## Pre-fetched Issue Comments\n\nalice: cached-content",
            )
        ]
        state = self._make_state_with_issues(tmp_path, issues)
        raw_issues = [{"number": 5, "title": "fix: something"}]

        with patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues):
            result = phase5_closure._fetch_open_issues_with_comments(
                state.repo,
                None,
                logger,
                state=state,
                cycle=None,
                state_path=tmp_path / ".code-generator" / "state.json",
            )

        assert "cached-content" in result

    def test_none_comments_calls_fetch_issue_comments(self, tmp_path: Path) -> None:
        """When IssueState.comments is None, a live fetch IS performed."""
        logger = logging.getLogger("test")
        issues = [_state.IssueState(number=5, status="open", agent="python-pro")]
        state = self._make_state_with_issues(tmp_path, issues)
        raw_issues = [{"number": 5, "title": "fix: something"}]
        fetch_calls: list[int] = []

        # Cache miss → get_or_fetch_comments → fetch_formatted_comments → fetch_issue_comments
        # All live in _comments.py, so patch there.
        with (
            patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues),
            patch(
                "code_generator.orchestrator._comments.fetch_issue_comments",
                side_effect=lambda *a, **kw: fetch_calls.append(1) or [],
            ),
        ):
            phase5_closure._fetch_open_issues_with_comments(
                state.repo,
                None,
                logger,
                state=state,
                cycle=None,
                state_path=tmp_path / ".code-generator" / "state.json",
            )

        assert len(fetch_calls) == 1

    def test_none_comments_persists_fetched_value(self, tmp_path: Path) -> None:
        """When fetch occurs for a known IssueState, result is persisted to IssueState.comments."""
        logger = logging.getLogger("test")
        issues = [_state.IssueState(number=5, status="open", agent="python-pro")]
        state = self._make_state_with_issues(tmp_path, issues)
        state_path = tmp_path / ".code-generator" / "state.json"
        raw_issues = [{"number": 5, "title": "fix: something"}]

        # Cache miss → get_or_fetch_comments → fetch_formatted_comments.
        # Return a formatted string directly to keep the test simple.
        with (
            patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues),
            patch(
                "code_generator.orchestrator._comments.fetch_formatted_comments",
                return_value="## Pre-fetched Issue Comments\n\nbob: fresh!",
            ),
        ):
            phase5_closure._fetch_open_issues_with_comments(
                state.repo, None, logger, state=state, cycle=None, state_path=state_path
            )

        assert state.issues[0].comments is not None
        assert "fresh!" in state.issues[0].comments

    def test_issue_not_in_state_fetches_without_persisting(self, tmp_path: Path) -> None:
        """Issues not in state (e.g. new fix issues) still get fetched but not persisted."""
        logger = logging.getLogger("test")
        state = self._make_state_with_issues(tmp_path, [])  # empty state
        state_path = tmp_path / ".code-generator" / "state.json"
        raw_issues = [{"number": 99, "title": "fix: new"}]

        # No IssueState match → _get_comment_text falls through to direct fetch_issue_comments
        # imported in phase5_closure from _comments.
        with (
            patch.object(phase5_closure.gh, "list_issues", return_value=raw_issues),
            patch(
                "code_generator.orchestrator.phase5_closure.fetch_issue_comments",
                return_value=[],
            ) as mock_fetch,
        ):
            result = phase5_closure._fetch_open_issues_with_comments(
                state.repo, None, logger, state=state, cycle=None, state_path=state_path
            )

        mock_fetch.assert_called_once()
        assert "Issue #99" in result


# ---------------------------------------------------------------------------
# Shared-client routing tests (issue #185)
# ---------------------------------------------------------------------------


class TestPhase5SharedClientRouting:
    """Phase 5 must route through run_with_shared_client when shared_client is set."""

    @pytest.mark.asyncio
    async def test_shared_mode_calls_run_with_shared_client_once_and_never_main_loop(
        self, tmp_path: Path
    ) -> None:
        """When shared_client is provided, run_with_shared_client() is called once and
        rate_limit.main_loop() is never called."""
        state = _make_state(tmp_path)
        mock_shared = MagicMock(name="shared_client")
        mock_shared_run = AsyncMock(return_value=_make_run_result())
        mock_main_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch(
                "code_generator.orchestrator.phase5_closure.run_with_shared_client",
                new=mock_shared_run,
            ),
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_main_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=mock_shared,
            )

        mock_shared_run.assert_called_once()
        mock_main_loop.assert_not_called()

    @pytest.mark.asyncio
    async def test_fresh_mode_calls_main_loop_once_and_never_run_with_shared_client(
        self, tmp_path: Path
    ) -> None:
        """When shared_client is None, rate_limit.main_loop() is called once and
        run_with_shared_client() is never called."""
        state = _make_state(tmp_path)
        mock_shared_run = AsyncMock(return_value=_make_run_result())
        mock_main_loop = AsyncMock(return_value=_make_run_result())

        with (
            patch(
                "code_generator.orchestrator.phase5_closure.run_with_shared_client",
                new=mock_shared_run,
            ),
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_main_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
        ):
            await phase5_closure.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=None,
            )

        mock_main_loop.assert_called_once()
        mock_shared_run.assert_not_called()
