chmod -R 777 /kwebsp
cd /kwebsp
pkill kwebsp
nohup kwebsp --host 0.0.0.0 --port 39001 --processcount 4 --timeout 3600 server -start > app/runtime/log/server.log 2>&1 &