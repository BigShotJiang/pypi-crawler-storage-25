from types import SimpleNamespace

import pandas as pd
import pytest

from megaton.start import Megaton


class _FakeSheet:
    def __init__(self):
        self._name = None
        self._data = {"config": [{"a": 1}]}
        self.deleted = []
        self.frozen = None
        self.freeze_kwargs = None
        self.resized = None
        self.gridlines = None
        self.gridline_calls = []
        self.tab_color = None
        self.tab_color_kwargs = None

    def select(self, name):
        self._name = name
        return name

    def create(self, name):
        self._name = name

    def duplicate(self, source_name, new_sheet_name):
        if source_name not in self._data:
            raise ValueError("missing source")
        self._data[new_sheet_name] = list(self._data[source_name])
        self._name = new_sheet_name
        return new_sheet_name

    def delete(self, name):
        self.deleted.append(name)
        if name in self._data:
            del self._data[name]
        if self._name == name:
            self._name = None

    def clear(self):
        self._data[self._name] = []

    def freeze(self, rows=None, cols=None, **kwargs):
        self.frozen = (rows, cols)
        self.freeze_kwargs = kwargs

    def resize_dimensions(self, **kwargs):
        self.resized = kwargs

    def set_gridlines(self, visible, **_kwargs):
        self.gridlines = visible
        self.gridline_calls.append(visible)

    def set_tab_color(self, color, **kwargs):
        self.tab_color = color
        self.tab_color_kwargs = kwargs

    @property
    def name(self):
        return self._name

    @property
    def data(self):
        return self._data.get(self._name, [])


class _FakeGS:
    def __init__(self):
        self.sheet = _FakeSheet()
        self._title = "Fake Sheet"
        self._url = "https://example.com/sheet"
        self._sheets = ["config", "CV"]

    @property
    def title(self):
        return self._title

    @property
    def url(self):
        return self._url

    @property
    def sheets(self):
        return list(self._sheets)


def _make_app_with_gs():
    app = Megaton(None, headless=True)
    app.gs = _FakeGS()
    app.state.gs_url = app.gs.url
    return app


def test_legacy_gs_client_still_available():
    app = _make_app_with_gs()
    assert app.gs.title == "Fake Sheet"
    assert "config" in app.gs.sheets
    assert app.gs.url == "https://example.com/sheet"
    assert app.gs.sheet.select("config") == "config"


def test_sheets_select_sets_state():
    app = _make_app_with_gs()
    app.sheets.select("CV")
    assert app.state.gs_sheet_name == "CV"


def test_sheet_cell_and_range_use_selected_sheet(monkeypatch):
    app = _make_app_with_gs()
    app.state.gs_sheet_name = "CV"

    called = {}

    def fake_update_cells(sheet_url, sheet_name, updates):
        called["cells"] = (sheet_url, sheet_name, updates)
        return True

    def fake_update_range(sheet_url, sheet_name, a1_range, values):
        called["range"] = (sheet_url, sheet_name, a1_range, values)
        return True

    monkeypatch.setattr(app._sheets, "update_cells", fake_update_cells)
    monkeypatch.setattr(app._sheets, "update_range", fake_update_range)

    app.sheet.cell.set("L1", "2024-01-01")
    app.sheet.range.set("L1:N1", [["2024-01-01", "2024-01-31"]])

    assert called["cells"] == (
        "https://example.com/sheet",
        "CV",
        {"L1": "2024-01-01"},
    )
    assert called["range"] == (
        "https://example.com/sheet",
        "CV",
        "L1:N1",
        [["2024-01-01", "2024-01-31"]],
    )


def test_sheet_formatting_helpers_use_selected_sheet():
    app = _make_app_with_gs()
    app.state.gs_sheet_name = "CV"

    app.sheet.gridlines.hide()
    app.sheet.gridlines.show()
    app.sheet.tab.color("#2f80ed")
    app.sheet.freeze(rows=1)
    app.sheet.resize(rows=1000, cols=20)

    assert app.gs.sheet.gridline_calls == [False, True]
    assert app.gs.sheet.gridlines is True
    assert app.gs.sheet.tab_color == "#2f80ed"
    assert app.gs.sheet.tab_color_kwargs == {
        "max_retries": None,
        "backoff_factor": None,
    }
    assert app.gs.sheet.frozen == (1, None)
    assert app.gs.sheet.freeze_kwargs == {
        "max_retries": None,
        "backoff_factor": None,
    }
    assert app.gs.sheet.resized == {
        "rows": 1000,
        "cols": 20,
        "shrink": False,
        "max_retries": None,
        "backoff_factor": None,
    }


def test_sheet_save_append_upsert_use_current_sheet(monkeypatch):
    app = _make_app_with_gs()
    app.state.gs_sheet_name = "CV"
    df = pd.DataFrame([{"a": 1}])

    called = {}

    def fake_save(sheet_name, df_in, **kwargs):
        called["save"] = (sheet_name, df_in, kwargs)

    def fake_append(sheet_name, df_in, **kwargs):
        called["append"] = (sheet_name, df_in, kwargs)

    def fake_upsert(
        sheet_url,
        sheet_name,
        df_in,
        keys,
        columns=None,
        sort_by=None,
        create_if_missing=True,
        auto_width=False,
        freeze_header=False,
        max_retries=3,
        backoff_factor=2.0,
    ):
        called["upsert"] = (
            sheet_url,
            sheet_name,
            df_in,
            keys,
            columns,
            sort_by,
            create_if_missing,
            auto_width,
            freeze_header,
            max_retries,
            backoff_factor,
        )
        return "ok"

    monkeypatch.setattr(app._sheets, "save_sheet", fake_save)
    monkeypatch.setattr(app._sheets, "append_sheet", fake_append)
    monkeypatch.setattr(app._sheets, "upsert_df", fake_upsert)

    app.sheet.save(df)
    app.sheet.append(df, auto_width=True, freeze_header=True)
    result = app.sheet.upsert(df, keys=["a"], auto_width=True, freeze_header=True)

    assert called["save"][:2] == ("CV", df)
    assert called["save"][2] == {
        "sort_by": None,
        "sort_desc": True,
        "start_row": 1,
        "auto_width": False,
        "freeze_header": False,
        "max_retries": 3,
        "backoff_factor": 2.0,
    }
    assert called["append"] == (
        "CV",
        df,
        {
            "auto_width": True,
            "freeze_header": True,
            "max_retries": 3,
            "backoff_factor": 2.0,
        },
    )
    assert result == "ok"
    assert called["upsert"] == (
        "https://example.com/sheet",
        "CV",
        df,
        ["a"],
        None,
        None,
        True,
        True,
        True,
        3,
        2.0,
    )


def test_sheet_requires_spreadsheet_and_selection():
    app = Megaton(None, headless=True)

    with pytest.raises(ValueError, match="Google Sheetsが開かれていません"):
        app.sheets.select("CV")

    app.gs = _FakeGS()
    app.state.gs_url = app.gs.url
    with pytest.raises(ValueError, match="worksheet selected"):
        app.sheet.save(pd.DataFrame())


def test_sheets_delete_clears_state_and_calls_delete():
    app = _make_app_with_gs()
    app.state.gs_sheet_name = "CV"

    app.sheets.delete("CV")

    assert app.state.gs_sheet_name is None
    assert "CV" in app.gs.sheet.deleted


def test_sheets_delete_missing_sheet_raises():
    app = _make_app_with_gs()

    with pytest.raises(ValueError, match="Sheet not found"):
        app.sheets.delete("missing")


def test_sheets_duplicate_uses_service(monkeypatch):
    app = _make_app_with_gs()
    called = {}

    def fake_duplicate(sheet_url, source_name, new_name, cell_update=None):
        called["duplicate"] = (sheet_url, source_name, new_name, cell_update)
        app.state.gs_sheet_name = new_name
        return True

    monkeypatch.setattr(app._sheets, "duplicate_sheet", fake_duplicate)

    result = app.sheets.duplicate(
        "config",
        "config_copy",
        cell_update={"cell": "B1", "value": "202402"},
    )

    assert result is True
    assert called["duplicate"] == (
        "https://example.com/sheet",
        "config",
        "config_copy",
        {"cell": "B1", "value": "202402"},
    )
    assert app.state.gs_sheet_name == "config_copy"
