from __future__ import annotations

import datetime
from typing import ClassVar

import pandas as pd

from finlab import data

__all__ = ["UKFundMarket", "UKMarket"]
from finlab.market import Market


class UKMarket(Market):
    """UK stock market (LSE)."""

    _price_table: ClassVar[str] = "uk_price"
    _adj_prefix: ClassVar[str] = "etl:uk_adj_"

    @staticmethod
    def get_freq() -> str:
        return "1d"

    @staticmethod
    def get_name() -> str:
        return "uk_stock"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("world_index:adj_close")["^FTSE"]

    @staticmethod
    def get_asset_id_to_name() -> dict[str, str]:
        try:
            from finlab.compat import resolve_id_column

            tickers = data.get("uk_tickers")
            return dict(
                zip(tickers[resolve_id_column(tickers)], tickers["name"], strict=True)
            )
        except (ImportError, KeyError, ValueError, RuntimeError):
            return {}

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        if timestamp is None:
            timestamp = self.get_price("close").index[-1]

        timestamp = self._normalize_market_timestamp(timestamp, "Europe/London")

        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("16:30:00")
        return market_close.tz_localize("Europe/London")

    @staticmethod
    def market_open_time() -> tuple[int, int]:
        return (8, 0)

    @staticmethod
    def default_fee_ratio() -> float:
        return 0.0

    @staticmethod
    def default_tax_ratio() -> float:
        return 5.0 / 1000

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone.utc


class UKFundMarket(UKMarket):
    """UK fund/ETF market using uk_fund_price data."""

    _price_table: ClassVar[str] = "uk_fund_price"
    _adj_prefix: ClassVar[str] = "etl:uk_fund_adj_"

    @staticmethod
    def get_name() -> str:
        return "uk_fund"
