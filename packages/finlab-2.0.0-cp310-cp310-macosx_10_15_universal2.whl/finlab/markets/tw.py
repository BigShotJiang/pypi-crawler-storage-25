from __future__ import annotations

import datetime
from typing import ClassVar

import pandas as pd

from finlab import data

__all__ = ["TWMarket"]
from finlab.market import Market


class TWMarket(Market):
    _categories_cache: ClassVar[pd.DataFrame | None] = None

    @classmethod
    def _get_categories(cls) -> pd.DataFrame:
        if cls._categories_cache is None:
            cls._categories_cache = data.get("security_categories")
        return cls._categories_cache

    @staticmethod
    def get_freq() -> str:
        return "1d"

    @staticmethod
    def get_name() -> str:
        return "tw_stock"

    @staticmethod
    def get_benchmark() -> pd.Series:
        return data.get("benchmark_return:發行量加權股價報酬指數").squeeze()

    @classmethod
    def get_asset_id_to_name(cls) -> dict[str, str]:
        from finlab.compat import resolve_id_column

        categories = cls._get_categories()
        _reset = categories.reset_index()
        return dict(
            zip(_reset[resolve_id_column(_reset)], categories["name"], strict=True)
        )

    @classmethod
    def get_industry(cls) -> dict[str, str]:
        from finlab.compat import resolve_id_column

        categories = cls._get_categories()
        _reset = categories.reset_index()
        return dict(
            zip(_reset[resolve_id_column(_reset)], categories["category"], strict=True)
        )

    def get_price(
        self, trade_at_price: str | pd.Series | pd.DataFrame, adj: bool = True
    ) -> pd.DataFrame:
        if isinstance(trade_at_price, pd.Series):
            return trade_at_price.to_frame()

        if isinstance(trade_at_price, pd.DataFrame):
            return trade_at_price

        if isinstance(trade_at_price, str):
            if trade_at_price == "volume":
                return data.get("price:成交股數")

            if adj:
                table_name = "etl:adj_"
                price_name = trade_at_price
            else:
                table_name = "price:"
                price_name = {
                    "open": "開盤價",
                    "close": "收盤價",
                    "high": "最高價",
                    "low": "最低價",
                }[trade_at_price]

            return data.get(f"{table_name}{price_name}")

        raise ValueError(
            "trade_at_price is not allowed (accepted types: pd.DataFrame, pd.Series, str)."
        )

    @staticmethod
    def get_market_value() -> pd.DataFrame:
        return data.get("etl:market_value")

    def market_close_at_timestamp(
        self, timestamp: pd.Timestamp | None = None
    ) -> pd.Timestamp:
        timestamp = self._normalize_market_timestamp(timestamp, "Asia/Taipei")

        # get market close time
        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta("15:00:00")
        return market_close.tz_localize("Asia/Taipei")

    @staticmethod
    def market_open_time() -> tuple[int, int]:
        return (9, 0)

    @staticmethod
    def tzinfo() -> datetime.timezone:
        return datetime.timezone(datetime.timedelta(hours=8))

    def get_reference_price(self) -> dict[str, float]:
        from finlab.compat import resolve_id_column

        ref_price = data.get("reference_price")
        return ref_price.set_index(resolve_id_column(ref_price))["收盤價"].to_dict()

    @staticmethod
    def get_odd_lot() -> int:
        return 1000

    @staticmethod
    def get_board_lot_size() -> int:
        return 1000

    @staticmethod
    def sim_datasets() -> list[str]:
        """Datasets that sim() will need, pre-fetched in parallel via data.gets()."""
        return [
            "etl:adj_close",
            "etl:adj_open",
            "etl:adj_high",
            "etl:adj_low",
            "price:收盤價",
            "price:成交股數",
            "benchmark_return:發行量加權股價報酬指數",
            "etl:is_flagged_stock",
            "etl:financial_statements_disclosure_dates",
        ]
