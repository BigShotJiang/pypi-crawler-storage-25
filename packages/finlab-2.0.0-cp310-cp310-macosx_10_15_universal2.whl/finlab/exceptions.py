"""Finlab exception hierarchy."""

__all__ = [
    "AuthError",
    "BacktestError",
    "BrokerError",
    "ConfigError",
    "DataError",
    "FinlabError",
    "PortfolioError",
]


class FinlabError(Exception):
    """Base exception for all finlab errors."""


class DataError(FinlabError):
    """Data fetching, caching, or transformation failures."""


class BacktestError(FinlabError):
    """Invalid backtest config or simulation failures."""


class BrokerError(FinlabError):
    """Broker connection, order submission, or execution failures."""


class AuthError(FinlabError):
    """Authentication or authorization failures."""


class PortfolioError(FinlabError):
    """Portfolio construction or rebalancing failures."""


class ConfigError(FinlabError):
    """Invalid configuration or missing required settings."""
