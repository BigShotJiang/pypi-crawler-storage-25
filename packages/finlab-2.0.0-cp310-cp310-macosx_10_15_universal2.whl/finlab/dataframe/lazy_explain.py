"""Human-readable formatting for lazy expression trees."""

from __future__ import annotations

from finlab.dataframe.lazy_nodes import (
    BinaryNode,
    GetitemNode,
    Node,
    RollingNode,
    ScalarNode,
    SourceNode,
    UnaryNode,
    _children,
)

_OP_SYMBOLS = {
    "__add__": "+",
    "__sub__": "-",
    "__mul__": "*",
    "__truediv__": "/",
    "__floordiv__": "//",
    "__mod__": "%",
    "__pow__": "**",
    "__gt__": ">",
    "__ge__": ">=",
    "__lt__": "<",
    "__le__": "<=",
    "__eq__": "==",
    "__ne__": "!=",
    "__and__": "&",
    "__or__": "|",
    "__xor__": "^",
}


def _depth(node: Node) -> int:
    if isinstance(node, (SourceNode, ScalarNode)):
        return 1
    return 1 + max((_depth(child) for child in _children(node)), default=0)


def explain(node: Node) -> str:
    lines: list[str] = []
    _append_explain(node, lines, indent=0)
    return "\n".join(lines)


def _append_explain(node: Node, lines: list[str], indent: int) -> None:
    prefix = "  " * indent

    if isinstance(node, SourceNode):
        rows, cols = node.data.shape
        lines.append(f"{prefix}Source {rows}x{cols}")
        return
    if isinstance(node, ScalarNode):
        lines.append(f"{prefix}Scalar({node.value})")
        return
    if isinstance(node, UnaryNode):
        lines.append(f"{prefix}.{node.method}({_fmt_args(node.args, node.kwargs)})")
        _append_explain(node.child, lines, indent + 1)
        return
    if isinstance(node, RollingNode):
        extra = _kw_suffix(node.rolling_kwargs)
        lines.append(f"{prefix}.rolling({node.window}{extra}).{node.method}()")
        _append_explain(node.child, lines, indent + 1)
        return
    if isinstance(node, BinaryNode):
        lines.append(f"{prefix}BinaryOp({_OP_SYMBOLS.get(node.op, node.op)})")
        _append_explain(node.left, lines, indent + 1)
        _append_explain(node.right, lines, indent + 1)
        return
    if isinstance(node, GetitemNode):
        lines.append(f"{prefix}GetItem")
        _append_explain(node.child, lines, indent + 1)
        if isinstance(node.key, Node):
            lines.append(f"{prefix}  key:")
            _append_explain(node.key, lines, indent + 2)
        return

    lines.append(f"{prefix}Unknown({type(node).__name__})")


def _kw_suffix(kwargs: dict) -> str:
    formatted = _fmt_args((), kwargs)
    return f", {formatted}" if formatted else ""


def _fmt_args(args: tuple, kwargs: dict) -> str:
    parts = [repr(arg) for arg in args]
    parts += [f"{key}={value!r}" for key, value in kwargs.items()]
    return ", ".join(parts)
