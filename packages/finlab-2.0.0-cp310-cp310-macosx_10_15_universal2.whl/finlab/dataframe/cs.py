"""CsAccessor — cross-sectional operations, accessed via ``df.cs.xxx``."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from finlab.dataframe.core import FinlabDataFrame


class CsAccessor:
    """Cross-sectional (per-row) transforms on a FinlabDataFrame."""

    def __init__(self, obj: FinlabDataFrame) -> None:
        self._obj = obj

    def _wrap(self, result: pd.DataFrame) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame

        return FinlabDataFrame(result, index=self._obj.index, columns=self._obj.columns)

    def rank(self) -> FinlabDataFrame:
        """跨股票百分位排名

        每列（日期）內將數值轉為百分位排名，範圍 (0, 1]。

        Returns:
            (FinlabDataFrame): 百分位排名。
        """
        return self._wrap(self._obj.rank(axis=1, pct=True))

    def winsorize(self, lower: float = 0.05, upper: float = 0.95) -> FinlabDataFrame:
        """跨股票百分位縮尾

        每列（日期）內，將低於 lower 百分位的值設為該百分位值，
        高於 upper 百分位的值設為該百分位值。

        Args:
            lower (float): 下界百分位數。預設 0.05。
            upper (float): 上界百分位數。預設 0.95。

        Returns:
            (FinlabDataFrame): 縮尾後的資料。
        """
        arr = self._obj.values.astype(float)
        result = arr.copy()

        for i in range(arr.shape[0]):
            row = arr[i]
            valid = row[~np.isnan(row)]
            if len(valid) == 0:
                continue
            lo = np.percentile(valid, lower * 100)
            hi = np.percentile(valid, upper * 100)
            result[i] = np.where(np.isnan(row), np.nan, np.clip(row, lo, hi))

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )

    def bucket(self, n: int) -> FinlabDataFrame:
        """跨股票分組

        每列（日期）內，將數值分為 n 個等分位組，回傳組別編號 1..n。

        Args:
            n (int): 分組數量。

        Returns:
            (FinlabDataFrame): 組別編號（1 = 最低，n = 最高）。
        """
        arr = self._obj.values.astype(float)
        result = np.full_like(arr, np.nan)

        for i in range(arr.shape[0]):
            row = arr[i]
            valid_mask = ~np.isnan(row)
            valid = row[valid_mask]
            if len(valid) == 0:
                continue
            ranks = pd.Series(valid).rank(method="first").values
            buckets = np.ceil(ranks / len(valid) * n).astype(int)
            result[i, valid_mask] = buckets

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )

    def zscore(self) -> FinlabDataFrame:
        """跨股票標準化

        每列（日期）內，計算 z-score：(x - mean) / std。
        若標準差為零，回傳 0。

        Returns:
            (FinlabDataFrame): 標準化後的資料。
        """
        was_nan = self._obj.isna()
        mean = self._obj.mean(axis=1)
        std = self._obj.std(axis=1)
        std = std.replace(0, np.nan)
        result = self._obj.sub(mean, axis=0).div(std, axis=0)
        result = result.where(~result.isna() | was_nan, 0.0)
        return self._wrap(result)

    def demean(self) -> FinlabDataFrame:
        """跨股票去均值

        每列（日期）內，減去該列平均值。

        Returns:
            (FinlabDataFrame): 去均值後的資料。
        """
        mean = self._obj.mean(axis=1)
        return self._wrap(self._obj.sub(mean, axis=0))
