"""Execution engine for lazy wide DataFrame expression trees."""

from __future__ import annotations

import operator
from typing import Any

import numpy as np
import pandas as pd

from finlab.backtest.helpers import generate_string_rebalance_dates
from finlab.dataframe.core import FinlabDataFrame
from finlab.dataframe.core import _top_n as _core_top_n
from finlab.dataframe.lazy_nodes import (
    BinaryNode,
    GetitemNode,
    Node,
    RollingNode,
    ScalarNode,
    SourceNode,
    UnaryNode,
    _collect_full_index,
    _collect_sources,
    _str_freq,
    _unique_source,
)

_BINARY_DISPATCH: dict[str, Any] = {
    "__add__": operator.add,
    "__sub__": operator.sub,
    "__mul__": operator.mul,
    "__truediv__": operator.truediv,
    "__floordiv__": operator.floordiv,
    "__mod__": operator.mod,
    "__pow__": operator.pow,
    "__gt__": operator.gt,
    "__ge__": operator.ge,
    "__lt__": operator.lt,
    "__le__": operator.le,
    "__eq__": operator.eq,
    "__ne__": operator.ne,
    "__and__": operator.and_,
    "__or__": operator.or_,
    "__xor__": operator.xor,
}


def collect(
    node: Node,
    dates: pd.DatetimeIndex | list | None = None,
) -> pd.DataFrame:
    """Execute at explicit dates, or all dates if *dates* is None."""
    full_index = _collect_full_index(node)

    if _is_string_index(full_index):
        result = _native_result_as_dates(node)
        if dates is not None:
            return result.reindex(pd.DatetimeIndex(dates), method="ffill")
        return result

    if dates is None:
        target_pos = np.arange(len(full_index))
    else:
        target_pos = _positions_for_dates(full_index, pd.DatetimeIndex(dates))
    return _execute(node, target_pos, full_index)


def rebalance(
    node: Node,
    freq: str = "M",
    offset: str | None = None,
    start: str | pd.Timestamp | None = None,
    end: str | pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Execute, computing only at rebalance dates."""
    full_index = _collect_full_index(node)

    if _is_string_index(full_index):
        result = _native_result_as_dates(node)
        targets = _filter_dates(
            _rebalance_dates(result.index, freq, offset), start, end
        )
        return result.reindex(targets, method="ffill")

    targets = _filter_dates(_rebalance_dates(full_index, freq, offset), start, end)
    return _execute(node, _positions_for_dates(full_index, targets), full_index)


def _positions_for_dates(full_index: pd.Index, dates: pd.DatetimeIndex) -> np.ndarray:
    """Snap *dates* to nearest previous positions in *full_index*."""
    pos = full_index.searchsorted(dates, side="right") - 1
    pos = np.clip(pos, 0, len(full_index) - 1)
    return np.unique(pos)


def _is_string_index(index: pd.Index) -> bool:
    return len(index) > 0 and isinstance(index[0], str)


def _filter_dates(
    dates: pd.DatetimeIndex,
    start: str | pd.Timestamp | None,
    end: str | pd.Timestamp | None,
) -> pd.DatetimeIndex:
    if start is not None:
        dates = dates[dates >= pd.Timestamp(start)]
    if end is not None:
        dates = dates[dates <= pd.Timestamp(end)]
    return dates


def _native_result_as_dates(node: Node, _cache: dict | None = None) -> pd.DataFrame:
    result = _execute_on_native(node, {} if _cache is None else _cache)
    if not isinstance(result, FinlabDataFrame):
        result = FinlabDataFrame(result)
    return result.index_str_to_date()


def _execute_on_native(node: Node, _cache: dict) -> pd.DataFrame:
    """Execute a string-indexed subtree on its native index."""
    sources = _collect_sources(node)
    if not sources:
        raise ValueError("No source found in subtree")
    native_index = sources[0].data.index
    native_pos = np.arange(len(native_index))
    return _execute(node, native_pos, native_index, _cache)


def _rebalance_dates(
    index: pd.Index, freq: str, offset: str | None = None
) -> pd.DatetimeIndex:
    """Build rebalance dates using the same logic as sim()."""
    dates = generate_string_rebalance_dates(
        position_start=index[0],
        present_data_date=index[-1],
        price_end=index[-1],
        resample=freq,
        resample_offset=offset,
        tz=None,
    )
    return pd.DatetimeIndex(dates)


def _expand_pos(
    target_pos: np.ndarray,
    lookback: int,
    n: int,
) -> tuple[np.ndarray, int]:
    if lookback <= 0 or len(target_pos) == 0:
        return target_pos, int(target_pos[0]) if len(target_pos) else 0
    return np.arange(n), 0


def _top_n(df: pd.DataFrame, n: int, *, largest: bool) -> pd.DataFrame:
    """Select top/bottom *n* per row, returning a plain DataFrame."""
    result = _core_top_n(df, n, largest=largest)
    if isinstance(result, FinlabDataFrame):
        result = pd.DataFrame(result)
    return result


def _is_contiguous(pos: np.ndarray) -> bool:
    return len(pos) > 0 and len(pos) == int(pos[-1]) - int(pos[0]) + 1


def _iloc(df: pd.DataFrame, pos: np.ndarray) -> pd.DataFrame:
    if _is_contiguous(pos):
        return df.iloc[int(pos[0]) : int(pos[-1]) + 1]
    return df.iloc[pos]


def _trim_pos(
    result: Any,
    target_pos: np.ndarray,
    slice_start: int,
) -> Any:
    if not isinstance(result, (pd.DataFrame, pd.Series)):
        return result
    return _iloc(result, target_pos - slice_start)


def _execute(
    node: Node,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict | None = None,
) -> Any:
    """Recursively execute the tree, computing only at *target_pos*."""
    if _cache is None:
        _cache = {}

    if len(target_pos):
        cache_key = (id(node), id(full_index), target_pos.tobytes())
        if cache_key in _cache:
            return _cache[cache_key]
    else:
        cache_key = None

    result = _execute_inner(node, target_pos, full_index, _cache)
    if cache_key is not None:
        _cache[cache_key] = result
    return result


def _execute_inner(
    node: Node,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    n = len(full_index)

    if isinstance(node, SourceNode):
        src = node.data
        if len(src) == n:
            return _iloc(src, target_pos)
        target_dates = full_index[target_pos]
        return src.reindex(target_dates, method="ffill")
    if isinstance(node, ScalarNode):
        return node.value
    if isinstance(node, UnaryNode):
        return _exec_unary(node, target_pos, full_index, _cache)
    if isinstance(node, RollingNode):
        return _exec_rolling(node, target_pos, full_index, _cache)
    if isinstance(node, BinaryNode):
        return _exec_binary(node, target_pos, full_index, _cache)
    if isinstance(node, GetitemNode):
        return _exec_getitem(node, target_pos, full_index, _cache)
    raise TypeError(f"Unknown node: {type(node).__name__}")


def _exec_unary(
    node: UnaryNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    child_pos, start = _expand_pos(target_pos, node.lookback, len(full_index))
    child_result = _execute(node.child, child_pos, full_index, _cache)
    needs_trim = node.lookback > 0

    method = node.method
    if method == "__invert__":
        result = ~child_result
    elif method == "__neg__":
        result = -child_result
    elif method == "is_largest":
        result = _top_n(child_result, node.args[0], largest=True)
    elif method == "is_smallest":
        result = _top_n(child_result, node.args[0], largest=False)
    else:
        args = _resolve_lazy_args(node.args, target_pos, full_index, _cache)
        kwargs = _resolve_lazy_kwargs(node.kwargs, target_pos, full_index, _cache)
        result = getattr(child_result, method)(*args, **kwargs)

    return _trim_pos(result, target_pos, start) if needs_trim else result


def _lazy_node(value: Any) -> Node | None:
    node = getattr(value, "_node", None)
    return node if isinstance(node, Node) else None


def _resolve_lazy_args(
    args: tuple, target_pos: np.ndarray, full_index: pd.Index, _cache: dict
) -> tuple:
    return tuple(
        _resolve_subtree(node, target_pos, full_index, _cache)
        if (node := _lazy_node(arg)) is not None
        else arg
        for arg in args
    )


def _resolve_lazy_kwargs(
    kwargs: dict, target_pos: np.ndarray, full_index: pd.Index, _cache: dict
) -> dict:
    return {
        key: _resolve_subtree(node, target_pos, full_index, _cache)
        if (node := _lazy_node(value)) is not None
        else value
        for key, value in kwargs.items()
    }


def _align_pair(
    left: pd.DataFrame, right: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if left.index.equals(right.index) and left.columns.equals(right.columns):
        return left, right
    target_idx = left.index.union(right.index)
    idx_start = max(left.index[0], right.index[0])
    target_idx = target_idx[target_idx >= idx_start]
    target_cols = left.columns.intersection(right.columns)
    return (
        left.reindex(index=target_idx, method="ffill")[target_cols],
        right.reindex(index=target_idx, method="ffill")[target_cols],
    )


def _cached_str_freq(node: Node, _cache: dict) -> str | None:
    key = ("__str_freq__", id(node))
    if key not in _cache:
        _cache[key] = _str_freq(node)
    return _cache[key]


def _cached_unique_source(node: Node, _cache: dict) -> SourceNode | None:
    key = ("__unique_src__", id(node))
    if key not in _cache:
        _cache[key] = _unique_source(node)
    return _cache[key]


def _resolve_subtree(
    node: Node,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    if _cached_str_freq(node, _cache) is not None:
        result = _native_result_as_dates(node, _cache)
        target_dates = full_index[target_pos]
        valid = target_dates[target_dates >= result.index[0]]
        return result.reindex(valid, method="ffill")

    unique_src = _cached_unique_source(node, _cache)
    if unique_src is not None:
        src_index = unique_src.data.index
        if not src_index.equals(full_index):
            target_dates = full_index[target_pos]
            valid = target_dates[target_dates >= src_index[0]]
            src_pos = _positions_for_dates(src_index, valid)
            result = _execute(node, src_pos, src_index, _cache)
            return result.reindex(valid, method="ffill")

    return _execute(node, target_pos, full_index, _cache)


def _exec_binary(
    node: BinaryNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    if _is_string_index(full_index):
        # Same-frequency string indexes: let pandas align by label (NaN for
        # missing periods) instead of ffill, which would carry stale data.
        left = _execute(node.left, target_pos, full_index, _cache)
        right = _execute(node.right, target_pos, full_index, _cache)
        return _BINARY_DISPATCH[node.op](left, right)

    left = _resolve_subtree(node.left, target_pos, full_index, _cache)
    right = _resolve_subtree(node.right, target_pos, full_index, _cache)
    if (
        isinstance(left, pd.DataFrame)
        and isinstance(right, pd.DataFrame)
        and not (left.index.equals(right.index) and left.columns.equals(right.columns))
    ):
        left, right = _align_pair(left, right)

    return _BINARY_DISPATCH[node.op](left, right)


def _exec_rolling(
    node: RollingNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    child_pos, start = _expand_pos(target_pos, node.window, len(full_index))
    child_result = _execute(node.child, child_pos, full_index, _cache)
    rolling_obj = child_result.rolling(node.window, **node.rolling_kwargs)
    result = getattr(rolling_obj, node.method)(*node.method_args, **node.method_kwargs)
    return _trim_pos(result, target_pos, start)


def _exec_getitem(
    node: GetitemNode,
    target_pos: np.ndarray,
    full_index: pd.Index,
    _cache: dict,
) -> Any:
    child = _resolve_subtree(node.child, target_pos, full_index, _cache)
    key = (
        _resolve_subtree(node.key, target_pos, full_index, _cache)
        if isinstance(node.key, Node)
        else node.key
    )

    if (
        isinstance(child, pd.DataFrame)
        and isinstance(key, pd.DataFrame)
        and not (child.index.equals(key.index) and child.columns.equals(key.columns))
    ):
        child, key = _align_pair(child, key)

    return child[key]
