"""SectorAccessor — sector-relative operations, accessed via ``df.sector.xxx``."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from collections.abc import Callable

    from finlab.dataframe.core import FinlabDataFrame


class SectorAccessor:
    """Sector-relative (within-sector per-row) transforms on a FinlabDataFrame."""

    def __init__(self, obj: FinlabDataFrame) -> None:
        self._obj = obj

    def _wrap(self, result: pd.DataFrame) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame

        return FinlabDataFrame(result, index=self._obj.index, columns=self._obj.columns)

    def _sector_map(self) -> pd.Series:
        return self._obj._get_column_categories()

    def rank(self) -> FinlabDataFrame:
        """產業內百分位排名

        每列（日期）內，在同產業股票中計算百分位排名。

        Returns:
            (FinlabDataFrame): 產業內百分位排名。
        """
        sectors = self._sector_map()
        arr = self._obj.values.astype(float)
        result = np.full_like(arr, np.nan)

        for i in range(arr.shape[0]):
            row = arr[i]
            for sector in sectors.unique():
                mask = sectors.values == sector
                vals = row[mask]
                valid = ~np.isnan(vals)
                if valid.sum() < 1:
                    continue
                ranked = pd.Series(vals[valid]).rank(pct=True).values
                idx = np.where(mask)[0]
                result[i, idx[valid]] = ranked

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )

    def winsorize(self, lower: float = 0.05, upper: float = 0.95) -> FinlabDataFrame:
        """產業內百分位縮尾

        每列（日期）內，在同產業股票中進行百分位縮尾處理。

        Args:
            lower (float): 下界百分位數。預設 0.05。
            upper (float): 上界百分位數。預設 0.95。

        Returns:
            (FinlabDataFrame): 縮尾後的資料。
        """
        sectors = self._sector_map()
        arr = self._obj.values.astype(float)
        result = arr.copy()

        for i in range(arr.shape[0]):
            row = arr[i]
            for sector in sectors.unique():
                mask = sectors.values == sector
                vals = row[mask]
                valid = vals[~np.isnan(vals)]
                if len(valid) == 0:
                    continue
                lo = np.percentile(valid, lower * 100)
                hi = np.percentile(valid, upper * 100)
                clipped = np.where(np.isnan(vals), np.nan, np.clip(vals, lo, hi))
                result[i, mask] = clipped

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )

    def bucket(self, n: int) -> FinlabDataFrame:
        """產業內分組

        每列（日期）內，在同產業股票中分為 n 個等分位組。

        Args:
            n (int): 分組數量。

        Returns:
            (FinlabDataFrame): 組別編號（1 = 最低，n = 最高）。
        """
        sectors = self._sector_map()
        arr = self._obj.values.astype(float)
        result = np.full_like(arr, np.nan)

        for i in range(arr.shape[0]):
            row = arr[i]
            for sector in sectors.unique():
                mask = sectors.values == sector
                vals = row[mask]
                valid = ~np.isnan(vals)
                n_valid = valid.sum()
                if n_valid == 0:
                    continue
                ranks = pd.Series(vals[valid]).rank(method="first").values
                buckets = np.ceil(ranks / n_valid * n).astype(int)
                idx = np.where(mask)[0]
                result[i, idx[valid]] = buckets

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )

    def zscore(self) -> FinlabDataFrame:
        """產業內標準化

        每列（日期）內，在同產業股票中計算 z-score。
        若產業內標準差為零，回傳 0。

        Returns:
            (FinlabDataFrame): 產業內標準化後的資料。
        """
        sectors = self._sector_map()
        arr = self._obj.values.astype(float)
        result = np.full_like(arr, np.nan)

        for i in range(arr.shape[0]):
            row = arr[i]
            for sector in sectors.unique():
                mask = sectors.values == sector
                vals = row[mask]
                valid = ~np.isnan(vals)
                if valid.sum() < 2:
                    if valid.sum() == 1:
                        result[i, np.where(mask)[0][valid]] = 0.0
                    continue
                m = np.nanmean(vals)
                s = np.nanstd(vals, ddof=1)
                idx = np.where(mask)[0]
                if s < 1e-10:
                    result[i, idx[valid]] = 0.0
                else:
                    result[i, idx[valid]] = (vals[valid] - m) / s

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )

    def _apply_agg(self, func: Callable[[np.ndarray], float]) -> FinlabDataFrame:
        """Apply an aggregation function within each sector per row.

        Each cell is replaced by the result of ``func`` applied to
        the non-NaN values in the same sector on the same date.
        """
        sectors = self._sector_map()
        arr = self._obj.values.astype(float)
        result = np.full_like(arr, np.nan)

        for i in range(arr.shape[0]):
            row = arr[i]
            for sector in sectors.unique():
                mask = sectors.values == sector
                vals = row[mask]
                valid = ~np.isnan(vals)
                if valid.sum() == 0:
                    continue
                agg = func(vals[valid])
                result[i, mask] = np.where(np.isnan(vals), np.nan, agg)

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )

    def mean(self) -> FinlabDataFrame:
        """產業內平均值

        每列（日期）內，將每個股票的值替換為同產業的平均值。

        Returns:
            (FinlabDataFrame): 產業內平均值。
        """
        return self._apply_agg(np.mean)

    def std(self, ddof: int = 1) -> FinlabDataFrame:
        """產業內標準差

        每列（日期）內，將每個股票的值替換為同產業的標準差。

        Args:
            ddof (int): 自由度修正。預設 1（樣本標準差）。

        Returns:
            (FinlabDataFrame): 產業內標準差。
        """
        return self._apply_agg(lambda v: np.std(v, ddof=ddof) if len(v) > 1 else 0.0)

    def median(self) -> FinlabDataFrame:
        """產業內中位數

        每列（日期）內，將每個股票的值替換為同產業的中位數。

        Returns:
            (FinlabDataFrame): 產業內中位數。
        """
        return self._apply_agg(np.median)

    def sum(self) -> FinlabDataFrame:
        """產業內總和

        每列（日期）內，將每個股票的值替換為同產業的總和。

        Returns:
            (FinlabDataFrame): 產業內總和。
        """
        return self._apply_agg(np.sum)

    def min(self) -> FinlabDataFrame:
        """產業內最小值

        每列（日期）內，將每個股票的值替換為同產業的最小值。

        Returns:
            (FinlabDataFrame): 產業內最小值。
        """
        return self._apply_agg(np.min)

    def max(self) -> FinlabDataFrame:
        """產業內最大值

        每列（日期）內，將每個股票的值替換為同產業的最大值。

        Returns:
            (FinlabDataFrame): 產業內最大值。
        """
        return self._apply_agg(np.max)

    def count(self) -> FinlabDataFrame:
        """產業內有效值數量

        每列（日期）內，將每個股票的值替換為同產業的非 NaN 數量。

        Returns:
            (FinlabDataFrame): 產業內有效值數量。
        """
        return self._apply_agg(lambda v: float(len(v)))

    def demean(self) -> FinlabDataFrame:
        """產業內去均值

        每列（日期）內，減去同產業股票的平均值。

        Returns:
            (FinlabDataFrame): 產業內去均值後的資料。
        """
        sectors = self._sector_map()
        arr = self._obj.values.astype(float)
        result = arr.copy()

        for i in range(arr.shape[0]):
            row = arr[i]
            for sector in sectors.unique():
                mask = sectors.values == sector
                vals = row[mask]
                m = np.nanmean(vals)
                if np.isnan(m):
                    continue
                result[i, mask] = np.where(np.isnan(vals), np.nan, vals - m)

        return self._wrap(
            pd.DataFrame(result, index=self._obj.index, columns=self._obj.columns)
        )
