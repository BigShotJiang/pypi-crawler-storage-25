"""Neutralization mixin for FinlabDataFrame.

Provides cross-sectional factor neutralization (single/multi-factor) and
industry neutralization via dummy-variable regression.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from finlab.dataframe.core import FinlabDataFrame


class NeutralizeMixin:
    """Factor and industry neutralization methods for FinlabDataFrame."""

    def neutralize(
        self: FinlabDataFrame,
        neutralizers: pd.DataFrame | list[pd.DataFrame] | dict[str, pd.DataFrame],
        add_const: bool = True,
    ) -> FinlabDataFrame:
        """Multi-factor cross-sectional neutralization

        Performs cross-sectional regression to neutralize factors from the data.
        The residuals from regressing self on the neutralizers are returned.

        Args:
            neutralizers: Factor(s) to neutralize against. Can be:
                - A single DataFrame
                - A list of DataFrames
                - A dict of DataFrames (keys are factor names)
            add_const (bool): Whether to add a constant term to the regression. Default True.

        Returns:
            (FinlabDataFrame): Neutralized data (regression residuals)

        Examples:
            Neutralize a factor against size:
            ```py
            from finlab import data

            factor = data.get('price_earning_ratio:本益比')
            size = data.get('fundamental_features:市值')

            neutralized = factor.neutralize(size)
            ```

            Neutralize against multiple factors using a list:
            ```py
            neutralized = factor.neutralize([size, beta])
            ```

            Neutralize against multiple factors using a dict:
            ```py
            neutralized = factor.neutralize({
                'size': size,
                'size2': size ** 2,
                'beta': beta,
            })
            ```
        """
        from finlab.dataframe.core import FinlabDataFrame as FDF

        neutralizers_dict = _normalize_neutralizers(neutralizers)

        df1 = self
        for name, df in list(neutralizers_dict.items()):
            df1, reshaped = self.reshape(df1, df)
            neutralizers_dict[name] = reshaped

        out = [
            _neutralize_row(df1, neutralizers_dict, date, add_const)
            for date in df1.index
        ]

        ret = FDF(out)
        ret.index.name = "date"
        ret.columns.name = "symbol"
        return ret

    def neutralize_industry(
        self: FinlabDataFrame,
        categories: pd.DataFrame | None = None,
        add_const: bool = True,
    ) -> FinlabDataFrame:
        """Industry neutralization using dummy variables

        Performs cross-sectional regression to neutralize industry effects from the data.
        Each stock is assigned to an industry, and the factor is regressed on industry
        dummy variables. The residuals (industry-neutral factor) are returned.

        Args:
            categories (pd.DataFrame): Optional DataFrame with 'stock_id' and 'category' columns.
                If not provided, uses `data.get('security_categories')`.
            add_const (bool): Whether to add a constant term to the regression. Default True.
                Note: When using industry dummies, adding a constant creates multicollinearity,
                so one industry dummy is automatically dropped when add_const=True.

        Returns:
            (FinlabDataFrame): Industry-neutralized data (regression residuals)

        Examples:
            Neutralize a factor against industry:
            ```py
            from finlab import data

            factor = data.get('price_earning_ratio:本益比')
            neutralized = factor.neutralize_industry()
            ```

            Using custom categories:
            ```py
            custom_cats = pd.DataFrame({
                'stock_id': ['2330', '2317', '1101'],
                'category': ['半導體', '電子', '水泥']
            })
            neutralized = factor.neutralize_industry(categories=custom_cats)
            ```
        """
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if categories is None:
            from finlab import data

            categories = data.get("security_categories")

        col_categories = _build_column_categories(categories, self.columns)
        df1 = self.index_str_to_date()

        out = [
            _neutralize_industry_row(df1, col_categories, date, add_const)
            for date in df1.index
        ]

        ret = FDF(out)
        ret.index.name = "date"
        ret.columns.name = "symbol"
        return ret


def _normalize_neutralizers(
    neutralizers: pd.DataFrame | list[pd.DataFrame] | dict[str, pd.DataFrame],
) -> dict[str, pd.DataFrame]:
    """Convert neutralizers to a uniform dict format."""
    if isinstance(neutralizers, pd.DataFrame):
        return {"factor_0": neutralizers}
    if isinstance(neutralizers, list):
        return {f"factor_{i}": df for i, df in enumerate(neutralizers)}
    return neutralizers


def _neutralize_row(
    df1: pd.DataFrame,
    neutralizers_dict: dict[str, pd.DataFrame],
    date: object,
    add_const: bool,
) -> pd.Series:
    """Compute OLS residuals for a single cross-section date."""
    y = df1.loc[date]
    X_list: list[pd.Series] = []
    mask = y.notna()
    for df in neutralizers_dict.values():
        xi = df.loc[date]
        mask &= xi.notna()
        X_list.append(xi)

    if mask.sum() < len(neutralizers_dict) + 1:
        return pd.Series(index=df1.columns, name=date)

    Y = y[mask].values.reshape(-1, 1)
    X = np.column_stack([x.loc[mask].values for x in X_list])
    if add_const:
        X = np.hstack([np.ones((X.shape[0], 1)), X])

    beta = np.linalg.lstsq(X, Y, rcond=None)[0]
    resid = (Y - X @ beta).ravel()

    s = pd.Series(index=df1.columns, name=date, dtype=float)
    s.loc[mask] = resid
    return s


def _build_column_categories(
    categories: pd.DataFrame,
    columns: pd.Index,
) -> pd.Series:
    """Build a refined symbol-to-category mapping for the given columns.

    Reuses the shared normalization logic from core._fetch_refined_categories
    but accepts an explicit categories DataFrame instead of fetching from data.
    """
    from finlab.compat import resolve_id_column

    cat_map = categories.set_index(resolve_id_column(categories))["category"].to_dict()

    # Same normalization as _fetch_refined_categories in core.py
    org_set = set(cat_map.values())
    valid_names = {o for o in org_set if isinstance(o, str) and o != "nan"}

    refine_cat: dict[str, str] = {}
    for s, c in cat_map.items():
        if c is None or c == "nan" or (isinstance(c, float) and np.isnan(c)):
            refine_cat[s] = "其他"
        elif c == "電腦及週邊":
            refine_cat[s] = "電腦及週邊設備業"
        elif c[-1] == "業" and c[:-1] in valid_names:
            refine_cat[s] = c[:-1]
        else:
            refine_cat[s] = c

    return pd.Series({col: refine_cat.get(col, "其他") for col in columns})


def _neutralize_industry_row(
    df1: pd.DataFrame,
    col_categories: pd.Series,
    date: object,
    add_const: bool,
) -> pd.Series:
    """Compute industry-neutralized residuals for a single cross-section date."""
    y = df1.loc[date]
    mask = y.notna()

    if mask.sum() < 2:
        return pd.Series(index=df1.columns, name=date, dtype=float)

    valid_cols = y[mask].index
    valid_cats = col_categories.loc[valid_cols]
    cats_in_row = valid_cats.unique()

    if len(cats_in_row) < 2:
        return pd.Series(index=df1.columns, name=date, dtype=float)

    dummy_dict: dict[str, np.ndarray] = {}
    for cat in cats_in_row:
        dummy_dict[cat] = (valid_cats == cat).astype(float).values

    X = np.column_stack(list(dummy_dict.values()))

    if add_const:
        X = X[:, 1:]  # Drop first dummy to avoid multicollinearity
        X = np.hstack([np.ones((X.shape[0], 1)), X])

    Y = y[mask].values.reshape(-1, 1)

    beta = np.linalg.lstsq(X, Y, rcond=None)[0]
    resid = (Y - X @ beta).ravel()

    s = pd.Series(index=df1.columns, name=date, dtype=float)
    s.loc[mask] = resid
    return s
