"""Industry classification mixin for FinlabDataFrame.

Provides industry-based grouping, ranking, and category mapping for
stock DataFrames.
"""

from __future__ import annotations

import ast
from collections import defaultdict
from functools import wraps
from typing import TYPE_CHECKING, Any

import pandas as pd

from finlab import config

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

    from finlab.dataframe.core import FinlabDataFrame


class _CategoryGroupBy:
    """Column-wise industry grouping compatible with pandas 3."""

    __slots__ = (
        "_categories",
        "_frame",
        "_groupby",
        "_result_adapter",
        "_wrap_group_callbacks",
    )

    _GROUP_CALLBACK_METHODS = frozenset(
        {"agg", "aggregate", "apply", "filter", "transform"}
    )

    def __init__(
        self,
        groupby_obj: Any,
        *,
        frame: FinlabDataFrame | None = None,
        categories: pd.Series | None = None,
        result_adapter: Callable | None = None,
        wrap_group_callbacks: bool = False,
    ) -> None:
        self._frame = frame
        self._categories = categories
        self._groupby = groupby_obj
        self._result_adapter = result_adapter or (lambda result: result)
        self._wrap_group_callbacks = wrap_group_callbacks

    @classmethod
    def from_frame(
        cls,
        frame: FinlabDataFrame,
        categories: pd.Series,
        *,
        result_adapter: Callable | None = None,
    ) -> _CategoryGroupBy:
        if result_adapter is None:
            from finlab.dataframe.core import FinlabDataFrame

            result_adapter = FinlabDataFrame

        return cls(
            frame.T.groupby(categories),
            frame=frame,
            categories=categories,
            result_adapter=result_adapter,
            wrap_group_callbacks=True,
        )

    @staticmethod
    def _is_group_helper(result: Any) -> bool:
        from pandas.core.groupby.groupby import GroupBy
        from pandas.core.window.rolling import BaseWindowGroupby

        return isinstance(result, (GroupBy, BaseWindowGroupby))

    def _wrap_callback(self, callback: Callable) -> Callable:
        @wraps(callback)
        def _wrapped(group: pd.DataFrame, *args: Any, **kwargs: Any) -> Any:
            result = callback(group.T, *args, **kwargs)
            if isinstance(result, pd.DataFrame):
                return result.T
            return result

        return _wrapped

    def _wrap_callback_arg(self, arg: Any) -> Any:
        if callable(arg):
            return self._wrap_callback(arg)
        if isinstance(arg, list):
            return [self._wrap_callback_arg(item) for item in arg]
        if isinstance(arg, tuple):
            return tuple(self._wrap_callback_arg(item) for item in arg)
        if isinstance(arg, dict):
            return {key: self._wrap_callback_arg(value) for key, value in arg.items()}
        return arg

    def _prepare_call(self, name: str, args: tuple, kwargs: dict) -> tuple[tuple, dict]:
        if not self._wrap_group_callbacks or name not in self._GROUP_CALLBACK_METHODS:
            return args, kwargs

        wrapped_args = tuple(self._wrap_callback_arg(arg) for arg in args)
        wrapped_kwargs = {
            key: self._wrap_callback_arg(value) for key, value in kwargs.items()
        }
        return wrapped_args, wrapped_kwargs

    def _normalize_result(self, result: Any) -> Any:
        if self._is_group_helper(result):
            return _CategoryGroupBy(
                result,
                result_adapter=self._result_adapter,
            )
        if isinstance(result, pd.DataFrame):
            result = result.T
        return self._result_adapter(result)

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._groupby, name)
        if callable(attr):

            def _wrapped(*args: Any, **kwargs: Any) -> Any:
                call_args, call_kwargs = self._prepare_call(name, args, kwargs)
                return self._normalize_result(attr(*call_args, **call_kwargs))

            return _wrapped
        return self._normalize_result(attr)

    def __getitem__(self, key: Any) -> Any:
        if self._frame is not None and self._categories is not None:
            subset = self._frame.loc[:, key]
            if isinstance(subset, pd.Series):
                subset = subset.to_frame()
            return _CategoryGroupBy.from_frame(
                subset,
                self._categories.loc[subset.columns],
                result_adapter=self._result_adapter,
            )
        return self._normalize_result(self._groupby[key])

    def __len__(self) -> int:
        return len(self._groupby)

    def __iter__(self) -> Iterator[tuple[Any, Any]]:
        for category, group in self._groupby:
            yield category, self._normalize_result(group)


class IndustryMixin:
    """Industry grouping and ranking methods for FinlabDataFrame."""

    def _get_column_categories(self: FinlabDataFrame) -> pd.Series:
        """Map each column (stock ID) to its industry category."""
        from finlab.dataframe.core import _fetch_refined_categories

        refine_cat = _fetch_refined_categories()
        return pd.Series(
            self.columns.map(lambda s: refine_cat.get(s, "其他")),
            index=self.columns,
        )

    def groupby_category(self: FinlabDataFrame) -> _CategoryGroupBy:
        """資料按產業分群

        類似 `pd.DataFrame.groupby()`的處理效果。
        Returns:
          (pd.DataFrame): data
        Examples:
          半導體平均股價淨值比時間序列
            ```py
            from finlab import data
            pe = data.get('price_earning_ratio:股價淨值比')
            pe.groupby_category().mean()['半導體'].plot()
            ```
            <img src="https://i.ibb.co/Tq2fKBp/pbmean.png" alt="pbmean">

            全球 2020 量化寬鬆加上晶片短缺，使得半導體股價淨值比衝高。
        """
        col_categories = self._get_column_categories()
        return _CategoryGroupBy.from_frame(self, col_categories)

    def industry_rank(
        self: FinlabDataFrame,
        categories: list[str] | None = None,
    ) -> pd.DataFrame:
        """計算產業 ranking 排名，0 代表產業內最低，1 代表產業內最高
        Args:
          categories (list of str): 欲考慮的產業，ex: ['貿易百貨', '雲端運算']，預設為全產業，請參考 `data.get('security_industry_themes')` 中的產業項目。
        Examples:
            本意比產業排名分數
            ```py
            from finlab import data

            pe = data.get('price_earning_ratio:本益比')
            pe_rank = pe.industry_rank()
            print(pe_rank)
            ```
        """
        market = config.get_market()
        market_name: str = market.get_name()

        if market_name in ("tw_stock", "rotc_stock"):
            return _industry_rank_tw(self, categories)

        return _industry_rank_generic(self, market, market_name, categories)

    def _rank_stocks(self: FinlabDataFrame, stock_ids: list[str]) -> pd.DataFrame:
        """Rank stocks within an industry group, returning percentile ranks per date."""
        return self[self.columns.intersection(stock_ids)].rank(axis=1, pct=True)

    @staticmethod
    def _deduplicate_ranked(ranked: pd.DataFrame) -> pd.DataFrame:
        """Average duplicate columns from multi-industry ranking, restore (dates x stocks) shape."""
        return ranked.T.groupby(level=0).mean().T


def _industry_rank_generic(
    df: FinlabDataFrame,
    market: object,
    market_name: str,
    categories: list[str] | None,
) -> pd.DataFrame:
    """Industry rank for non-TW markets using get_industry()."""
    symbol_to_industry: dict[str, str] = market.get_industry()
    if not symbol_to_industry:
        raise ValueError(
            f"industry_rank() is not supported for market '{market_name}': "
            "get_industry() returned empty. No industry classification available."
        )

    industry_to_symbols: dict[str, list[str]] = defaultdict(list)
    for sym, ind in symbol_to_industry.items():
        industry_to_symbols[ind].append(sym)

    if categories is not None:
        allowed: set[str] = set(categories)
        industry_to_symbols = {
            k: v for k, v in industry_to_symbols.items() if k in allowed
        }

    return df._deduplicate_ranked(
        pd.concat(
            (df._rank_stocks(industry_to_symbols[ind]) for ind in industry_to_symbols),
            axis=1,
        )
    )


def _industry_rank_tw(
    df: FinlabDataFrame,
    categories: list[str] | None,
) -> pd.DataFrame:
    """TW/ROTC market industry rank using security_industry_themes."""
    from finlab import data
    from finlab.compat import resolve_id_column

    themes: pd.DataFrame = (
        data.get("security_industry_themes")
        .copy()
        .assign(category=lambda df: df.category.apply(ast.literal_eval))
        .explode("category")
    )

    active_categories: list[str] | set[str] = categories or set(
        themes.category[themes.category.str.find(":") == -1]
    )

    id_col: str = resolve_id_column(themes)
    stocks_by_category: dict[str, list[str]] = {
        ind: themes[id_col][themes.category == ind].tolist()
        for ind in active_categories
    }

    return df._deduplicate_ranked(
        pd.concat(
            (df._rank_stocks(stocks_by_category[ind]) for ind in stocks_by_category),
            axis=1,
        )
    )
