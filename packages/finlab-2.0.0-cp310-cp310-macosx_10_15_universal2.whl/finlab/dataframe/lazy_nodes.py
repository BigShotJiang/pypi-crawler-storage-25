"""Expression nodes and tree helpers for lazy wide DataFrame evaluation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from finlab.dataframe.core import get_index_str_frequency

if TYPE_CHECKING:
    import pandas as pd

_NEEDS_HISTORY = 1


class Node:
    """Base of the expression tree."""


@dataclass
class SourceNode(Node):
    data: pd.DataFrame


@dataclass
class ScalarNode(Node):
    value: Any


@dataclass
class UnaryNode(Node):
    child: Node
    method: str
    args: tuple
    kwargs: dict
    lookback: int = 0


@dataclass
class RollingNode(Node):
    child: Node
    window: int
    rolling_kwargs: dict
    method: str
    method_args: tuple
    method_kwargs: dict


@dataclass
class BinaryNode(Node):
    left: Node
    right: Node
    op: str


@dataclass
class GetitemNode(Node):
    child: Node
    key: Any


def _children(node: Node) -> list[Node]:
    """Return the child nodes of *node*."""
    if isinstance(node, (UnaryNode, RollingNode)):
        return [node.child]
    if isinstance(node, BinaryNode):
        return [node.left, node.right]
    if isinstance(node, GetitemNode):
        kids = [node.child]
        if isinstance(node.key, Node):
            kids.append(node.key)
        return kids
    return []


def _walk_tree(node: Node, visitor: Any) -> None:
    """Depth-first traversal calling ``visitor(node)`` at each node."""
    visitor(node)
    for child in _children(node):
        _walk_tree(child, visitor)


def _collect_sources(node: Node) -> list[SourceNode]:
    """Return all SourceNode instances in the tree, in walk order."""
    sources: list[SourceNode] = []
    _walk_tree(node, lambda n: sources.append(n) if isinstance(n, SourceNode) else None)
    return sources


def _collect_full_index(node: Node) -> pd.Index:
    """Return the union of all source indexes in the tree.

    String-indexed sources are excluded when DatetimeIndex sources exist.
    String-only trees return their native index so callers can execute and
    convert the result after pandas operations preserve native semantics.
    """
    dt_indices: list[pd.Index] = []
    str_indices: list[pd.Index] = []
    for source in _collect_sources(node):
        if get_index_str_frequency(source.data) is None:
            dt_indices.append(source.data.index)
        else:
            str_indices.append(source.data.index)

    indices = dt_indices or str_indices
    if not indices:
        raise ValueError("No SourceNode found in the tree")
    result = indices[0]
    for idx in indices[1:]:
        result = result.union(idx)
    return result


def _str_freq(node: Node) -> str | None:
    """Return the string index frequency when all sources share it."""
    freqs = {get_index_str_frequency(source.data) for source in _collect_sources(node)}
    if None in freqs or len(freqs) != 1:
        return None
    return freqs.pop()


def _unique_source(node: Node) -> SourceNode | None:
    """Return the source if the subtree has exactly one data identity."""
    sources = _collect_sources(node)
    if not sources:
        return None
    first = sources[0]
    return first if all(s.data is first.data for s in sources) else None
