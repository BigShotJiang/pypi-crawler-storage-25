"""Index conversion mixin for FinlabDataFrame.

Handles conversion between string-format financial indices (e.g. '2022-Q1',
'2022-M01') and datetime indices, including business-day alignment and
disclosure-date lookups.
"""

from __future__ import annotations

import datetime
from typing import TYPE_CHECKING, Literal

import pandas as pd

if TYPE_CHECKING:
    from collections.abc import Iterable

    import numpy as np

    from finlab.dataframe.core import FinlabDataFrame


class IndexConversionMixin:
    """Methods for converting FinlabDataFrame indices between str and datetime."""

    def index_str_to_date(self: FinlabDataFrame) -> FinlabDataFrame:
        """財務月季報索引格式轉換

        將以下資料的索引轉換成datetime格式:

        財務季報 (ex:2022-Q1) 從文字格式轉為財報電子檔資料上傳日。

        通常使用情境為對不同週期的dataframe做reindex，常用於以公告截止日作為訊號產生日。

        Returns:
          (pd.DataFrame): data

        Examples:
            ```py
            data.get('financial_statement:現金及約當現金').index_str_to_date()
            ```
        """
        if len(self.index) == 0 or not isinstance(self.index[0], str):
            return self

        if self.index[0].find("M") != -1:
            return self._index_str_to_date_month()
        if self.index[0].find("Q") != -1:
            return _route_season_market(self)

        return self

    @staticmethod
    def to_business_day(
        date: Iterable[datetime.date | pd.Timestamp],
        close: pd.DataFrame | None = None,
    ) -> np.ndarray:
        def skip_weekend(d: datetime.date) -> datetime.date:
            add_days = {5: 2, 6: 1}
            wd = d.weekday()
            if wd in add_days:
                d += datetime.timedelta(days=add_days[wd])
            return d

        if close is None:
            from finlab import data

            close = data.get("price:收盤價")

        return (
            pd.Series(date)
            .apply(
                lambda d: (
                    skip_weekend(d)
                    if d in close.index or d < close.index[0] or d > close.index[-1]
                    else close.loc[d:].index[0]
                )
            )
            .values
        )

    def _index_date_to_str_month(self: FinlabDataFrame) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if len(self.index) == 0 or not isinstance(self.index[0], pd.Timestamp):
            return self

        index = (self.index - datetime.timedelta(days=30)).strftime("%Y-M%m")
        return FDF(self.values, index=index, columns=self.columns)

    def _index_str_to_date_month(self: FinlabDataFrame) -> FinlabDataFrame:
        return self

    def _index_to_business_day(self: FinlabDataFrame) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        index = self.to_business_day(self.index)
        ret = FDF(self.values, index=index, columns=self.columns)
        ret.index.name = "date"
        return ret

    def _index_date_to_str_season(
        self: FinlabDataFrame, postfix: str = ""
    ) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if len(self.index) == 0 or not isinstance(self.index[0], pd.Timestamp):
            return self

        if not isinstance(self.index, pd.DatetimeIndex):
            raise TypeError("Index must be a pd.DatetimeIndex")

        year = self.index.year.copy()
        if postfix:
            q = self.index.strftime("%m").astype(int).map({3: 1, 6: 2, 9: 3, 12: 4})
        else:
            q = (
                self.index.strftime("%m")
                .astype(int)
                .map({5: 1, 8: 2, 9: 2, 10: 3, 11: 3, 3: 4, 4: 4})
            )
            year -= q == 4
        index = year.astype(str) + f"{postfix}-Q" + q.astype(str)
        return FDF(self.values, index=index, columns=self.columns)

    def deadline(self: FinlabDataFrame) -> FinlabDataFrame:
        """財務索引轉換成公告截止日

        將財務季報 (ex:2022Q1) 從文字格式轉為公告截止日的datetime格式，
        通常使用情境為對不同週期的dataframe做reindex，常用於以公告截止日作為訊號產生日。
        Returns:
          (pd.DataFrame): data
        Examples:
            ```py
            data.get('financial_statement:現金及約當現金').deadline()
            data.get('monthly_revenue:當月營收').deadline()
            ```
        """
        if len(self.index) == 0 or not isinstance(self.index[0], str):
            return self

        if self.index[0].find("M") != -1:
            return self._index_str_to_date_month()
        if self.index[0].find("Q") != -1:
            return self._index_str_to_date_season(detail=False)

        raise ValueError(
            "Cannot apply deadline to dataframe. "
            "Index is not compatible. "
            "Index should be 2013-Q1 or 2013-M1."
        )

    def _index_str_to_date_season(
        self: FinlabDataFrame,
        detail: bool = True,
        market: Literal[
            "hk_stock",
            "jp_stock",
            "kr_stock",
            "tw_stock",
            "uk_stock",
            "us_stock",
            "us_stock_all",
        ] = "tw_stock",
    ) -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        datekey = _fetch_datekey(market, detail)

        intersect_cols = self.columns.intersection(datekey.columns)
        disclosure_dates = datekey.reindex(self.index)[intersect_cols].unstack()

        if not hasattr(self.columns, "name") or self.columns.name is None:
            self.columns.name = "symbol"

        col_name = self.columns.name
        unstacked = self[intersect_cols].unstack()

        if unstacked.shape != disclosure_dates.shape:
            shared_idx = unstacked.index.intersection(disclosure_dates.index)
            unstacked = unstacked.reindex(shared_idx)
            disclosure_dates = disclosure_dates.reindex(shared_idx)

        ret = pd.DataFrame(
            {
                "value": unstacked.values,
                "disclosures": disclosure_dates.values,
            },
            unstacked.index,
        )
        ret.index.names = [col_name, "date"]

        ret = (
            ret.reset_index()
            .drop_duplicates(["disclosures", col_name])
            .pivot(index="disclosures", columns=col_name, values="value")
            .pipe(_safe_ffill)
            .pipe(lambda df: df.loc[df.index.notna()])
            .pipe(FDF)
            .rename_axis("date")
        )

        if not detail:
            ret.index = self.to_business_day(ret.index)

        return _apply_truncation(ret)


def _route_season_market(df: FinlabDataFrame) -> FinlabDataFrame:
    """Dispatch index_str_to_date to the correct market for Q-format indices."""
    idx0 = df.index[0]
    market_prefixes = {
        "US-ALL": "us_stock_all",
        "US": "us_stock",
        "JP": "jp_stock",
        "HK": "hk_stock",
        "KR": "kr_stock",
        "UK": "uk_stock",
    }
    for prefix, market in market_prefixes.items():
        if idx0.find(prefix) != -1:
            return df._index_str_to_date_season(market=market)
    return df._index_str_to_date_season()


def _fetch_datekey(
    market: str,
    detail: bool,
) -> pd.DataFrame:
    """Fetch the disclosure-date or deadline DataFrame for the given market."""
    from finlab import data

    if market == "tw_stock":
        if detail:
            return data.get("etl:financial_statements_disclosure_dates").copy()
        return data.get("etl:financial_statements_deadline").copy()

    if market == "us_stock_all":
        return data.get("us_fundamental_all:datekey").copy()

    if market in ("us_stock", "jp_stock", "hk_stock", "kr_stock", "uk_stock"):
        region = market.split("_", maxsplit=1)[0]
        return data.get(f"{region}_income_statement:key_date").copy()

    raise ValueError(
        f"Unsupported market: {market}. "
        "Supported markets are 'tw_stock', 'us_stock', 'us_stock_all', "
        "'jp_stock', 'hk_stock', 'kr_stock', 'uk_stock'."
    )


def _safe_ffill(df: pd.DataFrame) -> pd.DataFrame:
    """Forward-fill that respects pandas downcasting settings."""
    has_downcasting_warning = (
        getattr(getattr(pd.options, "future", None), "no_silent_downcasting", None)
        is not None
    )
    if has_downcasting_warning:
        with pd.option_context("future.no_silent_downcasting", True):
            return df.ffill()
    return df.ffill()


def _apply_truncation(ret: pd.DataFrame) -> pd.DataFrame:
    """Apply truncation window if configured in finlab.data."""
    try:
        from finlab import data as finlab_data
    except ImportError:
        return ret

    t_start = getattr(finlab_data, "truncate_start", None)
    t_end = getattr(finlab_data, "truncate_end", None)
    if t_start is None and t_end is None:
        return ret

    start_ts = pd.to_datetime(t_start) if t_start is not None else None
    end_ts = pd.to_datetime(t_end) if t_end is not None else None

    if start_ts is not None and end_ts is not None:
        return ret.loc[(ret.index >= start_ts) & (ret.index <= end_ts)]
    if start_ts is not None:
        return ret.loc[ret.index >= start_ts]
    return ret.loc[ret.index <= end_ts]
