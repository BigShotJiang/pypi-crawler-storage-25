"""Signal generation mixin for FinlabDataFrame.

Implements trading signal methods: entry/exit detection, position holding
with rotation, stop-loss, take-profit, and trailing stops.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from finlab.dataframe.core import FinlabDataFrame


class SignalMixin:
    """Trading signal generation methods for FinlabDataFrame."""

    def is_entry(self: FinlabDataFrame) -> FinlabDataFrame:
        """進場點

        取進場訊號點，若符合條件的值則為True，反之為False。
        Returns:
          (pd.DataFrame): data
        Examples:
          策略為每日收盤價前10高，取進場點。
            ```py
            from finlab import data
            data.get('price:收盤價').is_largest(10).is_entry()
            ```
        """
        return self & ~self.shift(fill_value=False)

    def is_exit(self: FinlabDataFrame) -> FinlabDataFrame:
        """出場點

        取出場訊號點，若符合條件的值則為 True，反之為 False。
        Returns:
          (pd.DataFrame): data
        Examples:
          策略為每日收盤價前10高，取出場點。
            ```py
            from finlab import data
            data.get('price:收盤價').is_largest(10).is_exit()
            ```
        """
        return ~self & self.shift(fill_value=False)

    def entry_price(self: FinlabDataFrame, trade_at: str = "close") -> FinlabDataFrame:
        from finlab.dataframe.core import FinlabDataFrame as FDF

        signal = self.is_entry()
        from finlab import data

        adj = (
            data.get("etl:adj_close")
            if trade_at == "close"
            else data.get("etl:adj_open")
        )
        adj, signal = adj.reshape(adj.loc[signal.index[0] : signal.index[-1]], signal)
        return FDF(adj.bfill()[signal.shift(fill_value=False)].astype("float").ffill())

    def sustain(
        self: FinlabDataFrame, nwindow: int, nsatisfy: int | None = None
    ) -> FinlabDataFrame:
        """持續 N 天滿足條件

        取移動 nwindow 筆加總大於等於nsatisfy，若符合條件的值則為True，反之為False。

        Args:
          nwindow (positive-int): 設定移動窗格。
          nsatisfy (positive-int): 設定移動窗格計算後最低滿足數值。
        Returns:
          (pd.DataFrame): data
        Examples:
            收盤價是否連兩日上漲
            ```py
            from finlab import data
            data.get('price:收盤價').rise().sustain(2)
            ```
        """
        nsatisfy = nsatisfy or nwindow
        return self.rolling(nwindow).sum() >= nsatisfy

    def exit_when(self: FinlabDataFrame, exit: pd.DataFrame) -> FinlabDataFrame:
        df, exit = self.reshape(self, exit)

        df = df.fillna(False)
        exit = exit.fillna(False)

        entry_signal = df.is_entry()
        exit_signal = df.is_exit()
        exit_signal |= exit

        position = pd.DataFrame(np.nan, index=df.index, columns=df.columns)
        position[entry_signal] = 1.0
        position[exit_signal] = 0.0

        position = position.ffill()
        position = position == 1.0
        return position.fillna(False)

    def hold_until(
        self: FinlabDataFrame,
        exit: pd.DataFrame,
        nstocks_limit: int | None = None,
        stop_loss: float = -np.inf,
        take_profit: float = np.inf,
        trail_stop: float = np.inf,
        trade_at: str = "close",
        rank: pd.DataFrame | None = None,
    ) -> FinlabDataFrame:
        """訊號進出場

        這大概是所有策略撰寫中，最重要的語法糖，上述語法中 `entries` 為進場訊號，而 `exits` 是出場訊號。所以 `entries.hold_until(exits)` ，就是進場訊號為 `True` 時，買入並持有該檔股票，直到出場訊號為 `True ` 則賣出。

        <img src="https://i.ibb.co/PCt4hPd/Screen-Shot-2021-10-26-at-6-35-05-AM.png" alt="Screen-Shot-2021-10-26-at-6-35-05-AM">
        此函式有很多細部設定，可以讓你最多選擇 N 檔股票做輪動。另外，當超過 N 檔進場訊號發生，也可以按照客制化的排序，選擇優先選入的股票。最後，可以設定價格波動當輪動訊號，來增加出場的時機點。

        Args:
          exit (pd.Dataframe): 出場訊號。
          nstocks_limit (int)`: 輪動檔數上限，預設為None。
          stop_loss (float): 價格波動輪動訊號，預設為None，不生成輪動訊號。範例：0.1，代表成本價下跌 10% 時產生出場訊號。
          take_profit (float): 價格波動輪動訊號，預設為None，不生成輪動訊號。範例：0.1，代表成本價上漲 10% 時產生出場訊號。
          trail_stop (float): 移動停利訊號，預設為None，不生成輪動訊號。範例：0.1，代表從最高報酬回落 10% 時產生出場訊號。
          trade_at (str): 價格波動輪動訊號參考價，預設為'close'。可選 `close` 或 `open`。
          rank (pd.Dataframe): 當天進場訊號數量超過 nstocks_limit 時，以 rank 數值越大的股票優先進場。

        Returns:
          (pd.DataFrame): data

        Examples:
            價格 > 20 日均線入場, 價格 < 60 日均線出場，最多持有10檔，超過 10 個進場訊號，則以股價淨值比小的股票優先選入。
            ```py
            from finlab import data
            from finlab.backtest import sim

            close = data.get('price:收盤價')
            pb = data.get('price_earning_ratio:股價淨值比')

            sma20 = close.average(20)
            sma60 = close.average(60)

            entries = close > sma20
            exits = close < sma60

            #pb前10小的標的做輪動
            position = entries.hold_until(exits, nstocks_limit=10, rank=-pb)
            sim(position)
            ```
        """
        from finlab.dataframe.core import FinlabDataFrame as FDF

        if nstocks_limit is None:
            nstocks_limit = len(self.columns)

        if not isinstance(exit, FDF):
            exit = FDF(exit)
        if rank is not None and not isinstance(rank, FDF):
            rank = FDF(rank)

        self_reindex = self.index_str_to_date()
        exit_reindex = exit.index_str_to_date()
        rank_reindex = rank.index_str_to_date() if rank is not None else None

        union_index = self_reindex.index.union(exit_reindex.index)
        intersect_col = self_reindex.columns.intersection(exit_reindex.columns)

        if stop_loss != -np.inf or take_profit != np.inf or trail_stop != np.inf:
            from finlab import config

            market = config.get_market()
            price = market.get_price(trade_at, adj=True)

            union_index = union_index.union(
                price.loc[union_index[0] : union_index[-1]].index
            )
            intersect_col = intersect_col.intersection(price.columns)
        else:
            price = pd.DataFrame(index=union_index, columns=intersect_col)
            price.index = pd.to_datetime(price.index)

        if rank_reindex is not None:
            union_index = union_index.union(rank_reindex.index)
            intersect_col = intersect_col.intersection(rank_reindex.columns)

        # Keep sparse entry signals as discrete rebalance events when aligned
        # onto denser exit/rank/price timelines. After an exit, positions stay
        # out until the next sparse entry row instead of immediately re-entering
        # from a forward-filled weekly/monthly True.
        entry = (
            self_reindex.reindex(union_index)[intersect_col].astype(float).fillna(0.0)
        )

        exit = (
            exit_reindex.reindex(union_index, method="ffill")[intersect_col]
            .astype(float)
            .ffill()
            .fillna(0.0)
        )

        if price is not None:
            price = price.reindex(union_index, method="ffill")[intersect_col]

        if rank_reindex is not None:
            rank_reindex = rank_reindex.reindex(union_index, method="ffill")[
                intersect_col
            ]
        else:
            rank_reindex = pd.DataFrame(1, index=union_index, columns=intersect_col)

        rank_reindex = rank_reindex.replace([np.inf, -np.inf], np.nan)

        max_rank = rank_reindex.max().max()
        min_rank = rank_reindex.min().min()
        rank_reindex = (rank_reindex - min_rank) / (max_rank - min_rank)
        rank_reindex = rank_reindex.fillna(0)

        ret = np.zeros(entry.shape, dtype=int)
        ret = _rotate_stocks(
            ret,
            entry.astype(int).to_numpy(copy=True),
            exit.astype(int).to_numpy(copy=True),
            nstocks_limit,
            stop_loss,
            take_profit,
            trail_stop,
            price=price.to_numpy(copy=True, dtype=float),
            ranking=rank_reindex.to_numpy(copy=True),
        )
        return FDF(ret, index=entry.index, columns=entry.columns).astype(bool)


def _rotate_stocks(
    ret: np.ndarray,
    entry: np.ndarray,
    exit: np.ndarray,
    nstocks_limit: int,
    stop_loss: float = -np.inf,
    take_profit: float = np.inf,
    trail_stop: float = np.inf,
    price: np.ndarray | None = None,
    ranking: np.ndarray | None = None,
) -> np.ndarray:
    """Core stock rotation loop used by hold_until."""
    ret[0][np.argsort(entry[0], kind="stable")[-nstocks_limit:]] = 1
    ret[0][exit[0] == 1] = 0
    ret[0][entry[0] == 0] = 0

    entry_price = np.empty(entry.shape[1])
    entry_price[:] = np.nan
    max_return = np.ones(entry.shape[1])

    for i in range(1, entry.shape[0]):
        _apply_price_stops(
            ret,
            entry_price,
            max_return,
            exit,
            price,
            i,
            stop_loss,
            take_profit,
            trail_stop,
        )

        # run signal
        rank = entry[i] * ranking[i] + ret[i - 1] * 3
        rank[exit[i] == 1] = -1
        rank[(entry[i] == 0) & (ret[i - 1] == 0)] = -1

        ret[i][np.argsort(rank)[-nstocks_limit:]] = 1
        ret[i][rank == -1] = 0

    return ret


def _apply_price_stops(
    ret: np.ndarray,
    entry_price: np.ndarray,
    max_return: np.ndarray,
    exit: np.ndarray,
    price: np.ndarray | None,
    i: int,
    stop_loss: float,
    take_profit: float,
    trail_stop: float,
) -> None:
    """Apply stop-loss, take-profit, and trailing-stop logic for row *i*."""
    if stop_loss == -np.inf and take_profit == np.inf and trail_stop == np.inf:
        return

    is_entry = (ret[i - 2] == 0) if i > 1 else (ret[i - 1] == 1)
    is_waiting_for_entry = np.isnan(entry_price) & (ret[i - 1] == 1)
    is_entry |= is_waiting_for_entry

    entry_price[is_entry == 1] = price[i][is_entry == 1]
    max_return[is_entry == 1] = 1.0

    held = ret[i - 1] == 1
    returns = price[i] / entry_price
    stop = held & ((returns > 1 + abs(take_profit)) | (returns < 1 - abs(stop_loss)))

    if trail_stop != np.inf:
        max_return[:] = np.where(held, np.maximum(max_return, returns), max_return)
        stop |= held & (returns < max_return - abs(trail_stop))

    exited = (ret[i - 1] == 0) & ~np.isnan(entry_price)
    entry_price[exited] = np.nan
    max_return[exited] = 1.0

    exit[i] |= stop.astype(int)
