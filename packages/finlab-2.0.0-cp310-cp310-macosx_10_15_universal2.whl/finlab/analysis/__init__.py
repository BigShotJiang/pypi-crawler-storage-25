from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from finlab.core.report import Report
    from finlab.market import Market

__all__ = ["Analysis"]


class Analysis(ABC):
    def is_market_supported(self, market: Market) -> bool:
        """Check if market info is supported

        Returns:
          (bool): True, support. False not support.
        """
        return True

    def calculate_trade_info(self, report: Report) -> list[list[Any]]:
        """Additional trade info can be calculated easily.

        User could override this function if additional trade info is required for later anlaysis.

        Examples:

          ``` py
          from finlab.analysis import Analysis

          class SomeAnalysis(Analysis):
            def calculate_trade_info(self, report):
              return [
                ['股價淨值比', data.get('price_earning_ratio:股價淨值比'), 'entry_sig_date']
              ]

          report.run_analysis(SomeAnalysis())
          trades = report.get_trades()

          assert '股價淨值比@entry_sig_date' in trades.columns

          print(trades)
          ```
        """
        return []

    @abstractmethod
    def analyze(self, report: Report) -> Any:
        """Analyze trading report.

        One could assume self.caluclate_trade_info will be executed before self.analyze,
        so the `report.get_trades()` will contain the required trade info.
        """

    @abstractmethod
    def display(self) -> Any:
        """Display result

        When implement this function, returning Plotly figure instance is recommended.
        """
