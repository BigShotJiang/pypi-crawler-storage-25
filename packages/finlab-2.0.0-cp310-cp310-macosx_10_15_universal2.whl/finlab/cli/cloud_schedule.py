"""CLI commands for cloud-based strategy scheduling via finlab-auto-update.

Thin HTTP client that calls the Management CF and Trigger CF.
Auth uses finlab.auth.get_id_token() which handles refresh automatically.
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request
from typing import Any, Final

MANAGEMENT_CF_URL: Final[str] = (
    "https://asia-east1-fdata-299302.cloudfunctions.net/strategy-management"
)
TRIGGER_CF_URL: Final[str] = (
    "https://asia-east1-fdata-299302.cloudfunctions.net/strategy-trigger"
)


def _get_token() -> str:
    from finlab.auth import get_id_token

    token = get_id_token()
    if not token:
        print("Not logged in. Run: python -m finlab login", file=sys.stderr)
        sys.exit(1)
    return token


def _api_call(url: str, payload: dict[str, Any]) -> dict[str, Any]:
    """POST JSON to a Cloud Function with Firebase auth."""
    token = _get_token()
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "User-Agent": "finlab-cli/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            error_body = json.loads(e.read())
            msg = error_body.get("error", str(e))
        except (json.JSONDecodeError, ValueError):
            msg = str(e)
        print(f"Error ({e.code}): {msg}", file=sys.stderr)
        sys.exit(1)


def _manage(action: str, **params: Any) -> dict[str, Any]:
    return _api_call(MANAGEMENT_CF_URL, {"action": action, **params})


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------


def cmd_deploy(args: argparse.Namespace) -> None:
    """Deploy a strategy to the cloud."""
    try:
        code = args.code.read()
    finally:
        args.code.close()

    params: dict[str, Any] = {"sid": args.sid, "code": code}
    if args.time:
        params["schedule_time"] = args.time
    if args.tier:
        params["tier_id"] = args.tier

    _manage("strategy.deploy", **params)
    msg = f"Deployed '{args.sid}'"
    if args.time:
        msg += f" scheduled at {args.time}"
    print(msg)


def cmd_run(args: argparse.Namespace) -> None:
    """Trigger a manual strategy execution."""
    result = _api_call(TRIGGER_CF_URL, {"sid": args.sid})
    exec_id = result.get("exec_id", "unknown")
    print(f"Triggered '{args.sid}' — exec_id: {exec_id}")


def cmd_list(args: argparse.Namespace) -> None:
    """List all cloud strategies."""
    result = _manage("strategy.list")
    strategies = result.get("strategies", [])
    if not strategies:
        print("No strategies found.")
        return

    # Simple table output
    header = f"{'SID':<30} {'TIER':<6} {'SCHEDULE':<10} {'TYPE':<8}"
    print(header)
    print("-" * len(header))
    for s in strategies:
        sid = s.get("sid", "?")
        tier = s.get("tier_id", "-")
        schedule = s.get("schedule_time") or "-"
        code_type = s.get("code_type", "inline")
        print(f"{sid:<30} {tier:<6} {schedule:<10} {code_type:<8}")


def cmd_logs(args: argparse.Namespace) -> None:
    """Show recent execution logs for a strategy."""
    result = _manage("execution.list", sid=args.sid, limit=args.limit)
    executions = result.get("executions", [])
    if not executions:
        print(f"No executions found for '{args.sid}'.")
        return

    header = (
        f"{'EXEC_ID':<28} {'STATUS':<10} {'DURATION':<10} {'COST':<10} {'QUEUED_AT'}"
    )
    print(header)
    print("-" * len(header))
    for e in executions:
        exec_id = e.get("exec_id", "?")
        status = e.get("status", "?")
        duration = e.get("duration_s")
        duration_str = f"{duration:.1f}s" if duration is not None else "-"
        cost_data = e.get("cost")
        cost_str = f"${cost_data['usd']:.4f}" if cost_data else "-"
        queued = e.get("queued_at", "-")
        if isinstance(queued, str) and len(queued) > 19:
            queued = queued[:19]
        print(f"{exec_id:<28} {status:<10} {duration_str:<10} {cost_str:<10} {queued}")


def cmd_delete(args: argparse.Namespace) -> None:
    """Delete a cloud strategy."""
    if not args.yes:
        confirm = input(f"Delete strategy '{args.sid}' and its schedule? [y/N] ")
        if confirm.lower() != "y":
            print("Cancelled.")
            return

    _manage("strategy.delete", sid=args.sid)
    print(f"Deleted '{args.sid}'")


def cmd_status(args: argparse.Namespace) -> None:
    """Show billing and quota status."""
    result = _manage("billing.get")
    billing = result.get("billing", {})
    config = result.get("config", {})
    role_limit = result.get("role_limit", {})

    budget = role_limit.get("budget_usd", 0.0)
    used = billing.get("total_cost_usd", 0.0)
    remaining = budget - used
    allowed_tiers = role_limit.get("allowed_tiers", [])

    print(f"Budget:        ${budget:.2f}/month")
    print(f"Used:          ${used:.4f}")
    print(f"Remaining:     ${remaining:.4f}")
    print(f"Allowed tiers: {', '.join(allowed_tiers) or 'none'}")
    print(
        f"Executions:    {billing.get('execution_count', 0)} "
        f"(success: {billing.get('success_count', 0)}, "
        f"error: {billing.get('error_count', 0)}, "
        f"timeout: {billing.get('timeout_count', 0)})"
    )
    print(f"Default tier:  {config.get('tier_id', 's')}")


def register_cloud_commands(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register 'cloud' subcommand group under the main CLI."""
    cloud_parser = subparsers.add_parser(
        "cloud",
        help="Cloud strategy scheduling",
        description=(
            "Deploy and run FinLab trading strategies on the cloud. "
            "Strategies are Python scripts that use the finlab SDK to backtest "
            "and execute trading strategies. Once deployed, they can run on a "
            "daily schedule (Asia/Taipei timezone) or be triggered manually. "
            "Each execution runs in an isolated container with the finlab SDK "
            "pre-installed. Requires login first: python -m finlab login"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py --time 09:30 --tier s\n"
            "  python -m finlab cloud list\n"
            "  python -m finlab cloud run my-strat\n"
            "  python -m finlab cloud logs my-strat --limit 5\n"
            "  python -m finlab cloud status\n"
            "  python -m finlab cloud delete my-strat -y\n"
        ),
    )
    cloud_sub = cloud_parser.add_subparsers(dest="cloud_command")

    # deploy
    deploy_p = cloud_sub.add_parser(
        "deploy",
        help="Deploy a strategy to the cloud",
        description=(
            "Upload a Python strategy file and optionally set a daily schedule. "
            "The strategy code is stored server-side and executed in an isolated "
            "container with finlab SDK pre-installed. A preamble is automatically "
            "prepended that calls finlab.login() and sets up data storage. "
            "Re-deploying the same SID overwrites the previous code and settings."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py --time 09:30\n"
            "  python -m finlab cloud deploy my-strat --code strategy.py --tier m --time 14:00\n"
        ),
    )
    deploy_p.add_argument(
        "sid",
        help="Strategy ID — a unique name for this strategy (e.g. 'momentum-tw50')",
    )
    deploy_p.add_argument(
        "--code",
        type=argparse.FileType("r"),
        required=True,
        help="Path to the strategy .py file to upload",
    )
    deploy_p.add_argument(
        "--time",
        metavar="HH:MM",
        help="Daily schedule time in HH:MM format (Asia/Taipei timezone, e.g. '09:30'). "
        "Omit to deploy without a schedule (manual-only). "
        "Re-deploying without --time keeps the existing schedule unchanged.",
    )
    deploy_p.add_argument(
        "--tier",
        choices=["s", "m", "l", "xl"],
        help=(
            "Compute tier: "
            "s = 1 CPU / 2 GiB / 120s timeout, "
            "m = 2 CPU / 4 GiB / 180s, "
            "l = 4 CPU / 16 GiB / 300s, "
            "xl = 8 CPU / 32 GiB / 600s. "
            "Higher tiers require a higher plan. Default: s"
        ),
    )

    # run
    run_p = cloud_sub.add_parser(
        "run",
        help="Trigger a manual execution",
        description=(
            "Immediately queue a one-off execution of the strategy. "
            "The strategy must already be deployed. "
            "Rate-limited to 5 manual triggers per strategy per hour."
        ),
    )
    run_p.add_argument(
        "sid",
        help="Strategy ID of the deployed strategy to execute",
    )

    # list
    cloud_sub.add_parser(
        "list",
        help="List all cloud strategies",
        description=(
            "Show all deployed strategies with their SID, compute tier, "
            "schedule time, and code type (inline or zip)."
        ),
    )

    # logs
    logs_p = cloud_sub.add_parser(
        "logs",
        help="Show execution logs",
        description=(
            "Show recent executions for a strategy, newest first. "
            "Displays exec_id, status (success/error/timeout/queued/running), "
            "duration, cost in USD, and queued timestamp."
        ),
    )
    logs_p.add_argument(
        "sid",
        help="Strategy ID to show logs for",
    )
    logs_p.add_argument(
        "--limit",
        type=int,
        default=10,
        metavar="N",
        help="Number of recent executions to show (default: 10, max: 100)",
    )

    # delete
    delete_p = cloud_sub.add_parser(
        "delete",
        help="Delete a strategy",
        description=(
            "Permanently delete a deployed strategy, its code, and its schedule. "
            "Execution history is preserved for auditing. "
            "Asks for confirmation unless -y is passed."
        ),
    )
    delete_p.add_argument(
        "sid",
        help="Strategy ID to delete",
    )
    delete_p.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip the confirmation prompt",
    )

    # status
    cloud_sub.add_parser(
        "status",
        help="Show billing and quota",
        description=(
            "Show current month's billing summary: budget, amount used, "
            "remaining balance, allowed compute tiers, execution counts "
            "(success/error/timeout), and default tier setting."
        ),
    )


_CLOUD_COMMANDS = {
    "deploy": cmd_deploy,
    "run": cmd_run,
    "list": cmd_list,
    "logs": cmd_logs,
    "delete": cmd_delete,
    "status": cmd_status,
}


def dispatch_cloud(args: argparse.Namespace) -> None:
    """Dispatch a cloud subcommand."""
    handler = _CLOUD_COMMANDS.get(args.cloud_command)
    if handler:
        handler(args)
    else:
        print("Usage: python -m finlab cloud <deploy|run|list|logs|delete|status>")
        sys.exit(1)
