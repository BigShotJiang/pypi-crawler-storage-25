"""Backtest configuration and input validation.

Houses SimConfig, parameter validation, and deprecation helpers
extracted from the monolithic backtest module.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    import datetime

import pandas as pd

from finlab import config
from finlab.dataframe import FinlabDataFrame
from finlab.market import Market
from finlab.markets import get_market_by_name
from finlab.utils import check_version

from .helpers import resolve_stop_defaults


class OperationAndWeight(TypedDict):
    """Typed dict describing weights and actions from the backtest core."""

    weights: list[float]
    next_weights: list[float]
    weight_time: int
    next_weight_time: int
    actions: list[str]


@dataclass(slots=True)
class SimConfig:
    """Configuration for backtest simulation parameters.

    Groups the many sim() parameters into a single config object
    for cleaner internal passing between phases.
    """

    resample: (
        str
        | pd.DataFrame
        | pd.Series
        | pd.DatetimeIndex
        | list[datetime.datetime]
        | None
    ) = None
    resample_offset: str | None = None
    trade_at_price: str | pd.DataFrame = "close"
    position_limit: float = 1
    fee_ratio: float | None = None
    tax_ratio: float | None = None
    name: str = "未命名"
    stop_loss: float | None = None
    take_profit: float | None = None
    trail_stop: float | None = None
    touched_exit: bool = False
    retain_cost_when_rebalance: bool = False
    stop_trading_next_period: bool = True
    live_performance_start: str | None = None
    mae_mfe_window: int = 0
    mae_mfe_window_step: int = 1
    market: Market | None = None
    upload: bool | None = None
    fast_mode: bool = False
    notification_enable: bool = False
    line_access_token: str = ""

    def __post_init__(self) -> None:
        if self.upload is None:
            self.upload = (
                "FINLAB_STRATEGY_NAME" in os.environ
                or "FINLAB_FORCED_STRATEGY_NAME" in os.environ
            )


def _validate_notification_config(cfg: SimConfig) -> None:
    if cfg.notification_enable and cfg.line_access_token == "":
        raise ValueError(
            "line_access_token is required when enabling notifications. Please provide a valid token."
        )


def _normalize_position_input(
    position: pd.DataFrame | pd.Series,
) -> pd.DataFrame | pd.Series:
    if isinstance(position, FinlabDataFrame):
        return position.index_str_to_date()

    return position


def _validate_position_shape(position: pd.DataFrame | pd.Series) -> None:
    if not isinstance(position.index, pd.DatetimeIndex):
        raise TypeError("Expected the dataframe to have a DatetimeIndex")

    if isinstance(position, pd.Series) and position.name is None:
        raise ValueError(
            'Asset name not found. Please asign asset name by "position.name = \'2330\'".'
        )


def _validate_stop_and_limit_args(cfg: SimConfig) -> None:
    if (
        cfg.trail_stop is not None
        or cfg.stop_loss is not None
        or cfg.take_profit is not None
    ) and cfg.fast_mode:
        raise ValueError(
            "fast_mode cannot be used with trail_stop, stop_loss or take_profit."
        )


def _normalize_trade_at_price(cfg: SimConfig) -> None:
    _ = cfg.trade_at_price


def _normalize_resample_config(cfg: SimConfig) -> None:
    _ = cfg.resample_offset
    _ = cfg.resample


def _resolve_market_config(cfg: SimConfig) -> None:
    if cfg.market is None:
        cfg.market = config.get_market()
    elif isinstance(cfg.market, str):
        cfg.market = get_market_by_name(cfg.market)

    if not isinstance(cfg.market, Market):
        raise TypeError(
            "It seems like the market has "
            "not been specified well when using the hold_until"
            " function. Please provide the market='TW', "
            "market='US' or market=Market"
        )

    if cfg.fee_ratio is None:
        cfg.fee_ratio = cfg.market.default_fee_ratio()
    if cfg.tax_ratio is None:
        cfg.tax_ratio = cfg.market.default_tax_ratio()


def _validate_market_position_compatibility(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
) -> None:
    symbol = (
        position.columns[0] if isinstance(position, pd.DataFrame) else position.name
    )
    if not str(symbol)[0].isdigit() and cfg.market.get_name() == "tw_stock":
        raise ValueError(
            "Stock ID should be a number. Please check the stock ID in the position dataframe.\n"
            "If you are backtesting US stocks, please set market='US_STOCK'"
        )


def _build_engine_inputs(cfg: SimConfig) -> None:
    cfg.stop_loss, cfg.take_profit, cfg.trail_stop = resolve_stop_defaults(
        cfg.stop_loss,
        cfg.take_profit,
        cfg.trail_stop,
    )


def validate_sim_inputs(
    position: pd.DataFrame | pd.Series,
    cfg: SimConfig,
) -> tuple[pd.DataFrame | pd.Series, SimConfig]:
    """Validate sim parameters, resolve market/fee defaults, and check types.

    Performs version checks, validates notification config, resolves the market
    instance, fills in default fee/tax ratios, and validates position structure.
    Returns the (possibly converted) position and the updated config.
    """
    check_version()
    _validate_notification_config(cfg)
    position = _normalize_position_input(position)
    _normalize_resample_config(cfg)
    _normalize_trade_at_price(cfg)
    _validate_stop_and_limit_args(cfg)
    _validate_position_shape(position)
    _resolve_market_config(cfg)
    _validate_market_position_compatibility(position, cfg)
    _build_engine_inputs(cfg)

    return position, cfg
