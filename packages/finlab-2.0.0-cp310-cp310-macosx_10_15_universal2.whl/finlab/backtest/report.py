"""Backtest report construction and post-processing.

Handles building trades DataFrames, computing MAE/MFE metrics,
populating Report objects with weights/actions/trade metadata,
and final report assembly including upload and notification.
"""

from __future__ import annotations

import functools
import logging
import operator
import sys
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import datetime

    from finlab.market import Market

    from .config import OperationAndWeight, SimConfig

import numpy as np
import pandas as pd

from finlab.core import mae_mfe as maemfe
from finlab.core import report

logger = logging.getLogger(__name__)


def _is_pyodide_runtime() -> bool:
    return sys.platform == "emscripten"


def refine_mae_mfe(
    mae_mfe_window_step: int,
    touched_exit: bool,
    stop_loss: float,
    take_profit: float,
) -> pd.DataFrame:
    """Process raw mae_mfe data into a structured MultiIndex DataFrame."""
    if len(maemfe.mae_mfe) == 0:
        return pd.DataFrame()

    m = pd.DataFrame(maemfe.mae_mfe)
    nsets = int((m.shape[1] - 1) / 6)
    metrics = ["mae", "gmfe", "bmfe", "mdd", "pdays", "return"]

    tuples = functools.reduce(
        operator.iadd,
        [
            [
                (n, metric) if n == "exit" else (n * mae_mfe_window_step, metric)
                for metric in metrics
            ]
            for n in [*range(nsets), "exit"]
        ],
        [],
    )

    m.columns = pd.MultiIndex.from_tuples(tuples, names=["window", "metric"])
    m.index.name = "trade_index"
    m[m == -1] = np.nan

    exit_data = m.exit.copy()
    if touched_exit and len(m) > 0 and "exit" in m.columns:
        m["exit"] = (
            exit_data.assign(
                gmfe=exit_data.gmfe.clip(-abs(stop_loss), abs(take_profit))
            )
            .assign(bmfe=exit_data.bmfe.clip(-abs(stop_loss), abs(take_profit)))
            .assign(mae=exit_data.mae.clip(-abs(stop_loss), abs(take_profit)))
            .assign(mdd=exit_data.mdd.clip(-abs(stop_loss), abs(take_profit)))
        )

    return m


def build_trades_df(
    trades_raw: list[list[object]],
    tz: datetime.tzinfo | None,
    datetime_unit: str = "ns",
) -> pd.DataFrame:
    """Convert raw trade data from the Cython core into a DataFrame."""

    def convert_datetime_series(df: pd.DataFrame) -> pd.DataFrame:
        cols = ["entry_date", "exit_date", "entry_sig_date", "exit_sig_date"]
        if tz is None:
            df[cols] = df[cols].apply(lambda s: pd.to_datetime(s, unit=datetime_unit))
        else:
            df[cols] = df[cols].apply(
                lambda s: pd.to_datetime(s, unit=datetime_unit, utc=True).dt.tz_convert(
                    tz
                )
            )
        return df

    def assign_exit_nat(df: pd.DataFrame) -> pd.DataFrame:
        cols = ["exit_date", "exit_sig_date"]
        df[cols] = df[cols].loc[df.exit_index != -1]
        return df

    return (
        pd.DataFrame(
            trades_raw,
            columns=[
                "symbol",
                "entry_date",
                "exit_date",
                "entry_sig_date",
                "exit_sig_date",
                "position",
                "period",
                "entry_index",
                "exit_index",
            ],
        )
        .rename_axis("trade_index")
        .pipe(convert_datetime_series)
        .pipe(assign_exit_nat)
    )


def populate_report(
    r: report.Report,
    cfg: SimConfig,
    trades: pd.DataFrame,
    m: pd.DataFrame,
    operation_and_weight: OperationAndWeight,
    org_position_index: pd.DatetimeIndex,
    price: pd.DataFrame,
    market: Market,
) -> report.Report:
    """Attach weights, actions, trade metadata, and analyses to the report."""
    r.resample = cfg.resample
    r.stop_loss = cfg.stop_loss
    r.take_profit = cfg.take_profit
    r.trail_stop = cfg.trail_stop
    r.live_performance_start = cfg.live_performance_start
    r.mae_mfe = m
    r.trades = trades

    _attach_weights(r, operation_and_weight, org_position_index)
    _attach_actions(r, operation_and_weight)
    _map_stock_names(r, trades, market, cfg, price)
    _attach_trade_prices(r, cfg, market)
    _merge_mae_mfe_into_trades(r, trades)

    return r


def _attach_weights(
    r: report.Report,
    operation_and_weight: OperationAndWeight,
    org_position_index: pd.DatetimeIndex,
) -> None:
    """Set weights and next_weights on the report from operation data."""
    if len(operation_and_weight["weights"]) != 0:
        r.weights = pd.Series(operation_and_weight["weights"])
        r.weights.index = r.position.columns[r.weights.index]
    else:
        r.weights = pd.Series(dtype="float64")

    if len(operation_and_weight["next_weights"]) != 0:
        r.next_weights = pd.Series(operation_and_weight["next_weights"])
        r.next_weights.index = r.position.columns[r.next_weights.index]
    else:
        r.next_weights = pd.Series(dtype="float64")

    r.weights.name = org_position_index[operation_and_weight["weight_time"]]
    r.next_weights.name = org_position_index[operation_and_weight["next_weight_time"]]


def _attach_actions(
    r: report.Report,
    operation_and_weight: OperationAndWeight,
) -> None:
    """Set the actions series on the report."""
    if len(operation_and_weight["actions"]) != 0:
        r.actions = pd.Series(operation_and_weight["actions"])
        r.actions.index = r.position.columns[r.actions.index]
    else:
        r.actions = pd.Series(dtype=object)


def _map_stock_names(
    r: report.Report,
    trades: pd.DataFrame,
    market: Market,
    cfg: SimConfig,
    price: pd.DataFrame,
) -> None:
    """Map stock IDs to names/industries and handle action-based trade updates."""
    snames = market.get_asset_id_to_name()
    industry = market.get_industry()

    def f_id_to_name(sid: str) -> str:
        return f"{sid + ' ' + snames[sid] if sid in snames else sid}"

    def f_id_to_industry(sid: str) -> str:
        return industry.get(sid, "")

    if len(r.actions) != 0:
        _process_action_signals(r, trades, price)

    if len(trades) != 0:
        r.trades["industry"] = r.trades.symbol.map(f_id_to_industry)
        r.trades["symbol"] = r.trades.symbol.map(f_id_to_name)
        r.trades["stock_id"] = r.trades["symbol"]

    if hasattr(r, "actions") and len(r.actions) != 0:
        r.actions.index = r.actions.index.map(f_id_to_name)

    r.weights.index = r.weights.index.map(f_id_to_name)
    r.next_weights.index = r.next_weights.index.map(f_id_to_name)


def _process_action_signals(
    r: report.Report,
    trades: pd.DataFrame,
    price: pd.DataFrame,
) -> None:
    """Update trades based on exit/enter action signals."""
    actions = r.actions
    sell_sids = actions[actions == "exit"].index
    instant_exit_mask = (
        (actions == "sl")
        | (actions == "tp")
        | (actions == "sl_enter")
        | (actions == "tp_enter")
    )
    sell_instant_sids = actions[instant_exit_mask].index
    buy_sids = actions[actions == "enter"].index

    if len(sell_instant_sids):
        r.next_trading_date = price.index[-1]

    if len(trades):
        if set(sell_sids) - set(trades.symbol[trades.exit_sig_date.isnull()]):
            raise ValueError("Sell signals contain symbols not found in open trades")

        temp = trades.loc[trades.symbol.isin(sell_sids), "exit_sig_date"].fillna(
            r.position.index[-1]
        )
        trades.loc[trades.symbol.isin(sell_sids), "exit_sig_date"] = temp

        temp = trades.loc[
            trades.symbol.isin(sell_instant_sids), "exit_sig_date"
        ].fillna(price.index[-1])
        trades.loc[trades.symbol.isin(sell_instant_sids), "exit_sig_date"] = (
            temp.to_numpy()
        )

        r.trades = pd.concat(
            [
                r.trades,
                pd.DataFrame(
                    {
                        "symbol": buy_sids,
                        "entry_date": pd.NaT,
                        "entry_sig_date": r.position.index[-1],
                        "exit_date": pd.NaT,
                        "exit_sig_date": pd.NaT,
                    }
                ),
            ],
            ignore_index=True,
        )

        r.trades["exit_sig_date"] = pd.to_datetime(r.trades.exit_sig_date)


def _attach_trade_prices(
    r: report.Report,
    cfg: SimConfig,
    market: Market,
) -> None:
    """Add trade price and adj_close info, run liquidity analysis if applicable."""
    trade_at_price = cfg.trade_at_price
    if isinstance(trade_at_price, str):
        trade_price_data = market.get_trading_price(trade_at_price, adj=False)
    else:
        trade_price_data = trade_at_price
    r.add_trade_info("trade_price", trade_price_data, ["entry_date", "exit_date"])
    r.add_trade_info("adj_close", market.get_price("close", adj=True), ["entry_date"])

    if len(r.trades) != 0 and not cfg.fast_mode and market.get_name() == "tw_stock":
        r.run_analysis("Liquidity", display=False)


def _merge_mae_mfe_into_trades(
    r: report.Report,
    trades: pd.DataFrame,
) -> None:
    """Merge exit MAE/MFE data into the trades DataFrame."""
    if len(trades) != 0:
        current_trades = r.trades
        mae_mfe = r.mae_mfe
        exit_mae_mfe = mae_mfe["exit"].copy().drop(columns=["return"])
        r.trades = pd.concat([current_trades, exit_mae_mfe], axis=1)
        r.trades.index.name = "trade_index"
        r.calculate_current_trades()


def _upload_report(r: report.Report, name: str) -> None:
    """Upload a report and log failures that would otherwise be dropped."""
    try:
        result = r.upload(name)
    except Exception:
        logger.exception("Failed to upload backtest report '%s'", name)
        return

    if isinstance(result, dict) and result.get("status") == "error":
        logger.error(
            "Failed to upload backtest report '%s': %s",
            name,
            result.get("message", result),
        )
    elif result is False:
        logger.error("Failed to upload backtest report '%s'", name)


def build_sim_report(
    cfg: SimConfig,
    result: object,
    next_trading_date: pd.Timestamp,
    suppress_upload: bool = False,
) -> report.Report:
    """Construct the final Report object from raw simulation results.

    Creates the Report, attaches weights/actions/trades via populate_report,
    sends notifications and uploads if configured.

    Args:
        cfg: Simulation configuration.
        result: A _SimulationResult from the execution phase.
        next_trading_date: The next expected trading date.
        suppress_upload: If True, skip the upload step regardless of cfg.upload.
    """
    from .notify import line_notify

    r = report.Report(
        creturn=result.creturn,
        position=result.position,
        fee_ratio=cfg.fee_ratio,
        tax_ratio=cfg.tax_ratio,
        trade_at=cfg.trade_at_price,
        next_trading_date=next_trading_date,
        market=cfg.market,
    )

    r = populate_report(
        r,
        cfg,
        result.trades,
        result.mae_mfe,
        result.operation_and_weight,
        result.org_position_index,
        result.price,
        cfg.market,
    )

    if cfg.notification_enable:
        line_notify(r, cfg.line_access_token, name=cfg.name)

    if cfg.upload and not suppress_upload:
        if _is_pyodide_runtime():
            _upload_report(r, cfg.name)
        else:
            threading.Thread(
                target=_upload_report,
                args=(r, cfg.name),
                daemon=False,
            ).start()

    return r
