"""Line notification service for backtest results.

Provides the line_notify() function to send trading signals
and position summaries to Line chat rooms.
"""

from __future__ import annotations

import json

import pandas as pd

import finlab
from finlab.core import report  # noqa: TC001 – used at runtime in isinstance()
from finlab.utils import requests


def line_notify(
    report: report.Report | None = None,
    line_access_token: str = "",
    test: bool = False,
    name: str = "",
) -> None:
    """Send backtest position and recent trade signals to a Line chat room.

    Args:
        report: The backtest result report.
        line_access_token: Line Notify access token.
        test: If True, send a test message instead of report data.
        name: Strategy name for the notification header.
    """
    if test:
        message = "Finlab line_notify 測試成功"
    else:
        if not isinstance(report, finlab.core.report.Report):
            raise TypeError("Please provide a valid backtest report.")
        message = _format_report_message(report, name)

    _send_line_message(message, line_access_token, test)


def _format_report_message(r: report.Report, name: str) -> str:
    """Build the notification message text from report position info."""
    hold: list[str] = []
    enter: list[str] = []
    exit_: list[str] = []

    for i, p in r.position_info().items():
        if not (isinstance(p, dict) and i[:4].isdigit()):
            continue
        entry_line = f"{i}: {p['entry_date'][:10]}, {p['entry_price']!s}"
        if p["status"] == "exit" and pd.isnull(r.current_trades.loc[i].exit_date):
            hold.append(entry_line)
        if p["status"] in {"hold", "sl", "tp"}:
            hold.append(entry_line)
        if p["status"] == "enter":
            enter.append(f"{i}: {p['entry_date'][:10]}的下個交易日進場")
        if p["status"] in {"exit", "sl", "tp", "sl_enter", "tp_enter"}:
            exit_.append(f"{i}: {p['exit_date'][:10]}的下個交易日出場")

    lines = [f"目前策略{name} 進場日及進場價格："]
    lines.extend(hold)
    lines.append("------------------------------")
    lines.append("近期操作：")
    lines.append("-策略新增")
    lines.extend(enter or ["尚無"])
    lines.append("-策略移除")
    lines.extend(exit_ or ["尚無"])
    return "\n".join(lines)


def _send_line_message(message: str, token: str, is_test: bool) -> None:
    """POST the message to Line Notify API and handle test response."""
    headers = {
        "Authorization": "Bearer " + token,
        "Content-Type": "application/x-www-form-urlencoded",
    }
    r = requests.post(
        "https://notify-api.line.me/api/notify",
        headers=headers,
        params={"message": message},
    )
    if is_test:
        resp = json.loads(r.text)
        if resp["status"] == 401:
            print(f"測試失敗。{r.text}")
        elif resp["status"] == 200:
            print("測試成功，可開始使用finlab line_notify")
