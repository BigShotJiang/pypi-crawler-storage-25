from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TypedDict

__all__ = [
    "OrderEntry",
    "OrderEntryDict",
    "PortfolioConfigData",
    "PortfolioConfigDataDict",
    "PortfolioData",
    "PortfolioDataDict",
    "PositionEntry",
    "PositionEntryDict",
    "StrategyPositionData",
    "StrategyPositionDataDict",
]

from finlab.compat import normalize_position_dict


class PositionEntryDict(TypedDict, total=False):
    symbol: str
    stock_id: str
    quantity: int | float
    order_condition: str
    weight: float | None


class StrategyPositionDataDict(TypedDict, total=False):
    timestamp: str
    next_trading_time: str
    position: list[PositionEntryDict]
    allocation: float
    weight: float
    entry_at: str
    exit_at: str
    stop: list[dict[str, Any]]
    stop_loss: float | None
    take_profit: float | None
    trail_stop: float | None
    market: str
    last_market_timestamp: str | None


class PortfolioConfigDataDict(TypedDict, total=False):
    weights: dict[str, float]
    params: dict[str, Any]
    custom_position: list[PositionEntryDict]
    excluded_stock_ids: list[str]


class PortfolioDataDict(TypedDict, total=False):
    position: dict[str, StrategyPositionDataDict]
    history: dict[str, list[StrategyPositionDataDict]]
    config: PortfolioConfigDataDict
    market: str | None


@dataclass(slots=True)
class PositionEntry:
    symbol: str
    quantity: int | float
    order_condition: str
    weight: float | None = None

    @classmethod
    def from_dict(cls, data: PositionEntryDict) -> PositionEntry:
        d = normalize_position_dict(dict(data))
        return cls(
            symbol=d["symbol"],
            quantity=d["quantity"],
            order_condition=d["order_condition"],
            weight=d.get("weight"),
        )

    def to_dict(self) -> PositionEntryDict:
        ret: PositionEntryDict = {
            "symbol": self.symbol,
            "quantity": self.quantity,
            "order_condition": self.order_condition,
        }
        if self.weight is not None:
            ret["weight"] = self.weight
        return ret


class OrderEntryDict(TypedDict, total=False):
    symbol: str
    stock_id: str
    quantity: int | float
    order_condition: str


@dataclass(slots=True)
class OrderEntry:
    symbol: str
    quantity: int | float
    order_condition: str

    @classmethod
    def from_dict(cls, data: PositionEntryDict) -> OrderEntry:
        d = normalize_position_dict(dict(data))
        return cls(
            symbol=d["symbol"],
            quantity=d["quantity"],
            order_condition=d["order_condition"],
        )

    def to_dict(self) -> PositionEntryDict:
        return {
            "symbol": self.symbol,
            "quantity": self.quantity,
            "order_condition": self.order_condition,
        }


@dataclass(slots=True)
class StrategyPositionData:
    timestamp: str
    next_trading_time: str
    position: list[PositionEntry]
    allocation: float
    weight: float
    entry_at: str
    exit_at: str
    stop: list[dict[str, Any]]
    stop_loss: float | None
    take_profit: float | None
    trail_stop: float | None
    market: str
    last_market_timestamp: str | None = None

    @classmethod
    def from_dict(cls, data: StrategyPositionDataDict) -> StrategyPositionData:
        return cls(
            timestamp=data["timestamp"],
            next_trading_time=data["next_trading_time"],
            position=[PositionEntry.from_dict(p) for p in data.get("position", [])],
            allocation=data["allocation"],
            weight=data["weight"],
            entry_at=data["entry_at"],
            exit_at=data["exit_at"],
            stop=list(data.get("stop", [])),
            stop_loss=data.get("stop_loss"),
            take_profit=data.get("take_profit"),
            trail_stop=data.get("trail_stop"),
            market=data["market"],
            last_market_timestamp=data.get("last_market_timestamp"),
        )

    def to_dict(self) -> StrategyPositionDataDict:
        return {
            "timestamp": self.timestamp,
            "next_trading_time": self.next_trading_time,
            "position": [p.to_dict() for p in self.position],
            "allocation": self.allocation,
            "weight": self.weight,
            "entry_at": self.entry_at,
            "exit_at": self.exit_at,
            "stop": list(self.stop),
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "trail_stop": self.trail_stop,
            "market": self.market,
            "last_market_timestamp": self.last_market_timestamp,
        }


@dataclass(slots=True)
class PortfolioConfigData:
    weights: dict[str, float]
    params: dict[str, Any]
    custom_position: list[PositionEntry] | None = None
    excluded_stock_ids: list[str] | None = None

    @classmethod
    def from_dict(cls, data: PortfolioConfigDataDict) -> PortfolioConfigData:
        custom_position = None
        if "custom_position" in data:
            custom_position = [
                PositionEntry.from_dict(p) for p in data.get("custom_position", [])
            ]

        return cls(
            weights=dict(data.get("weights", {})),
            params=dict(data.get("params", {})),
            custom_position=custom_position,
            excluded_stock_ids=list(data["excluded_stock_ids"])
            if "excluded_stock_ids" in data
            else None,
        )

    def to_dict(self) -> PortfolioConfigDataDict:
        ret: PortfolioConfigDataDict = {
            "weights": dict(self.weights),
            "params": dict(self.params),
        }
        if self.custom_position is not None:
            ret["custom_position"] = [p.to_dict() for p in self.custom_position]
        if self.excluded_stock_ids is not None:
            ret["excluded_stock_ids"] = list(self.excluded_stock_ids)
        return ret


@dataclass(slots=True)
class PortfolioData:
    position: dict[str, StrategyPositionData]
    history: dict[str, list[StrategyPositionData]]
    config: PortfolioConfigData
    market: str | None = None

    @classmethod
    def from_dict(cls, data: PortfolioDataDict) -> PortfolioData:
        return cls(
            position={
                k: StrategyPositionData.from_dict(v)
                for k, v in data.get("position", {}).items()
            },
            history={
                k: [StrategyPositionData.from_dict(item) for item in items]
                for k, items in data.get("history", {}).items()
            },
            config=PortfolioConfigData.from_dict(data.get("config", {})),
            market=data.get("market"),
        )

    def to_dict(self) -> PortfolioDataDict:
        return {
            "position": {k: v.to_dict() for k, v in self.position.items()},
            "history": {
                k: [item.to_dict() for item in items]
                for k, items in self.history.items()
            },
            "config": self.config.to_dict(),
            "market": self.market,
        }
