"""Factor analysis toolkit -- public facade.

All public symbols are re-exported from focused submodules so that
existing ``from finlab.tools.factor_analysis import ...`` imports keep
working unchanged.

Submodules
----------
- :mod:`finlab.tools.factor_metrics`    -- IC, correlation, NDCG scoring
- :mod:`finlab.tools.factor_returns`    -- boolean factor returns & Shapley values
- :mod:`finlab.tools.factor_centrality` -- PCA-based rolling centrality
- :mod:`finlab.tools.factor_regression` -- OLS trend analysis
"""

from __future__ import annotations

# --- centrality --------------------------------------------------------------
from finlab.tools.factor_centrality import (
    calc_centrality,
)

# --- metrics -----------------------------------------------------------------
from finlab.tools.factor_metrics import (
    calc_ic,
    calc_metric,
    corr,
    ic,
    ndcg20,
    ndcg50,
    ndcg_k,
    precision_at_rank,
)

# --- regression --------------------------------------------------------------
from finlab.tools.factor_regression import (
    calc_regression_stats,
)

# --- returns / Shapley -------------------------------------------------------
from finlab.tools.factor_returns import (
    calc_factor_return,
    calc_shapley_values,
    generate_features_and_labels,
    is_boolean_series,
)

__all__ = [
    "calc_centrality",
    "calc_factor_return",
    "calc_ic",
    "calc_metric",
    "calc_regression_stats",
    "calc_shapley_values",
    "corr",
    "generate_features_and_labels",
    "ic",
    "is_boolean_series",
    "ndcg20",
    "ndcg50",
    "ndcg_k",
    "precision_at_rank",
]
