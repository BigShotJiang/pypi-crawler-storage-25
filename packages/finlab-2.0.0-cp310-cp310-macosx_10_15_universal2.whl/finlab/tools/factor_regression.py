"""Linear-regression trend analysis for time-series DataFrames."""

from __future__ import annotations

from typing import Final

import numpy as np
import pandas as pd

_EPSILON: Final[float] = 1e-15
_MIN_PERIODS: Final[int] = 6


def _regress_series(
    series: pd.Series,
    x: np.ndarray,
    scipy_stats: object,
) -> pd.Series:
    """Compute OLS statistics for a single column against a time axis.

    Args:
        series: Values to regress.
        x: Time axis (days since first observation), same length as *series*.
        scipy_stats: Pre-imported ``scipy.stats`` module (avoids per-column import).

    Returns:
        Series with keys ``slope``, ``intercept``, ``r_squared``,
        ``p_value``, ``tail_estimate``.
    """
    index = ["slope", "intercept", "r_squared", "p_value", "tail_estimate"]

    mask = series.notna().values
    y = series.values[mask].astype(np.float64)
    n = len(y)

    if n < _MIN_PERIODS:
        return pd.Series([np.nan] * 5, index=index)

    x_clean = x[mask].flatten()

    x_mean = np.mean(x_clean)
    y_mean = np.mean(y)
    x_centered = x_clean - x_mean
    y_centered = y - y_mean

    ss_xx = np.sum(x_centered**2)
    ss_xy = np.sum(x_centered * y_centered)
    ss_yy = np.sum(y_centered**2)

    if ss_xx < _EPSILON:
        return pd.Series([0.0, y_mean, 0.0, 1.0, y_mean], index=index)

    slope = ss_xy / ss_xx
    intercept = y_mean - slope * x_mean

    if ss_yy < _EPSILON:
        r_squared = 0.0
        p_value = 1.0
    else:
        y_pred = slope * x_clean + intercept
        ss_res = np.sum((y - y_pred) ** 2)
        r_squared = min(1.0, max(0.0, 1 - ss_res / ss_yy))

        p_value = _compute_p_value(slope, ss_res, ss_xx, n, scipy_stats)

    tail_estimate = slope * x_clean[-1] + intercept

    return pd.Series([slope, intercept, r_squared, p_value, tail_estimate], index=index)


def _compute_p_value(
    slope: float,
    ss_res: float,
    ss_xx: float,
    n: int,
    scipy_stats: object,
) -> float:
    """Derive the two-tailed p-value for the slope coefficient."""
    if n <= 2:
        return 1.0

    if ss_res > _EPSILON:
        mse = ss_res / (n - 2)
        se_slope = np.sqrt(mse / ss_xx)
        if se_slope > _EPSILON:
            t_stat = slope / se_slope
            return float(2 * scipy_stats.t.sf(abs(t_stat), n - 2))
        # se_slope ~ 0 means near-perfect fit
        return 0.0 if abs(slope) > _EPSILON else 1.0

    # ss_res ~ 0 means perfect fit
    return 0.0 if abs(slope) > _EPSILON else 1.0


def calc_regression_stats(
    df: pd.DataFrame,
    p_value_threshold: float = 0.05,
    r_squared_threshold: float = 0.1,
) -> pd.DataFrame:
    """Run per-column OLS regressions and classify each trend.

    Args:
        df: Time-series DataFrame with a ``DatetimeIndex``.
        p_value_threshold: Significance level for trend classification.
        r_squared_threshold: Minimum R-squared for a non-flat trend.

    Returns:
        DataFrame with columns ``slope``, ``intercept``, ``r_squared``,
        ``p_value``, ``tail_estimate``, and ``trend`` (``"up"``/``"down"``/``"flat"``).

    Raises:
        ValueError: If the DataFrame index is not a ``DatetimeIndex``.
    """
    if not isinstance(df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame index must be DatetimeIndex for trend analysis")

    valid_columns = [col for col in df.columns if df[col].notna().sum() >= _MIN_PERIODS]

    if not valid_columns:
        return pd.DataFrame(
            columns=["slope", "p_value", "r_squared", "tail_estimate", "trend"]
        )

    from scipy import stats as scipy_stats

    df_clean = df[valid_columns].copy()

    x = (
        (df_clean.index - df_clean.index[0])
        .days.values.reshape(-1, 1)
        .astype(np.float64)
    )

    stats_df = df_clean.apply(lambda s: _regress_series(s, x, scipy_stats)).T

    stats_df["trend"] = "flat"
    significant_mask = (stats_df["p_value"] < p_value_threshold) & (
        stats_df["r_squared"] > r_squared_threshold
    )
    stats_df.loc[significant_mask & (stats_df["slope"] > 0), "trend"] = "up"
    stats_df.loc[significant_mask & (stats_df["slope"] <= 0), "trend"] = "down"

    return stats_df
