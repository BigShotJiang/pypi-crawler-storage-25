"""Factor-return helpers: boolean validation, portfolio returns, Shapley values."""

from __future__ import annotations

import itertools
import logging
import math
from functools import reduce
from typing import TYPE_CHECKING

import pandas as pd
from tqdm import tqdm

from finlab.ml import feature, label

if TYPE_CHECKING:
    from collections.abc import Callable

logger = logging.getLogger(__name__)


def is_boolean_series(series: pd.Series) -> bool:
    """Check whether *series* contains only boolean-like values (including NaN).

    Handles the case where older pandas converts ``bool`` + NaN to ``float``.
    """
    if series.dtype == bool:
        return True

    non_nan_values = series.dropna()
    if len(non_nan_values) == 0:
        return True

    return non_nan_values.isin([True, False, 0, 1]).all()


def generate_features_and_labels(
    dfs: dict[str, pd.DataFrame | Callable[[], pd.DataFrame]],
    resample: str,
) -> tuple[pd.DataFrame, pd.Series]:
    """Build a feature matrix and an excess-return label vector.

    Wraps :func:`finlab.ml.feature.combine` and
    :func:`finlab.ml.label.excess_over_mean`.

    Args:
        dfs: Dict mapping factor names to DataFrames (or callables).
        resample: Resampling frequency / index passed to the ML helpers.

    Returns:
        ``(features, labels)`` tuple.
    """
    features = feature.combine(dfs, resample=resample)
    labels: pd.Series = label.excess_over_mean(index=features.index, resample=resample)
    return features, labels


def calc_factor_return(features: pd.DataFrame, labels: pd.Series) -> pd.DataFrame:
    """Compute equal-weight portfolio returns per boolean factor.

    Each column in *features* must be boolean.  For every date the mean
    label value across selected (``True``) stocks is returned.

    Args:
        features: Boolean feature DataFrame (MultiIndex: date x stock).
        labels: Excess-return labels with the same MultiIndex.

    Returns:
        DataFrame of per-period returns, one column per factor,
        starting from the first fully-populated date.

    Raises:
        ValueError: If any feature column is not boolean.
    """
    for f in features.columns:
        if not is_boolean_series(features[f]):
            raise ValueError(f"Feature {f} is not a boolean")

    def _factor_return(f: pd.Series) -> pd.Series:
        return labels.mask(~f).groupby(level=0).mean()

    factor_return = features.apply(_factor_return)
    factor_return = factor_return.dropna(axis=1, how="all")

    first_nonan = factor_return.notna().all(axis=1).pipe(lambda s: s[s]).index[0]
    return factor_return.loc[first_nonan:]


def _validate_shapley_inputs(features: pd.DataFrame, labels: pd.Series) -> None:
    """Raise ``ValueError`` if Shapley inputs are invalid."""
    if features.empty or features.shape[1] == 0:
        raise ValueError("Features DataFrame is empty or has no columns")

    if not isinstance(labels.index, pd.MultiIndex):
        raise ValueError(
            "Labels must have MultiIndex with 'datetime' and 'symbol' (or 'stock_id') levels"
        )

    for col in features.columns:
        if not is_boolean_series(features[col]):
            raise ValueError(f"Feature column '{col}' is not boolean")

    feature_dates = features.index
    label_dates = labels.index.get_level_values("datetime").unique()
    if not feature_dates.equals(label_dates):
        logger.warning("Feature and label date indices do not match exactly")


def _accumulate_combo(
    combo: tuple[str, ...],
    features: pd.DataFrame,
    labels: pd.Series,
    shapley_values: dict[str, pd.Series],
) -> None:
    """Compute the portfolio return for *combo* and distribute to each factor."""
    if len(combo) == 1:
        selected_stocks = features[combo[0]]
    else:
        selected_stocks = reduce(lambda x, y: x & y, [features[c] for c in combo])

    dt = labels.index.get_level_values("datetime")
    v = labels.mask(~selected_stocks).groupby(dt).mean().fillna(0)

    share = v / len(combo)
    for col in combo:
        if col in shapley_values:
            shapley_values[col] += share
        else:
            shapley_values[col] = share.copy()


def calc_shapley_values(features: pd.DataFrame, labels: pd.Series) -> pd.DataFrame:
    """Compute Shapley values measuring each factor's marginal contribution.

    Enumerates all 2^n subsets of factors, computes the equal-weight
    portfolio return of each subset, and distributes the return evenly
    among the factors in that subset.

    Args:
        features: Boolean feature DataFrame (MultiIndex: date x stock).
        labels: Excess-return labels with the same MultiIndex.

    Returns:
        DataFrame of Shapley values, one column per factor.

    Raises:
        ValueError: If *features* is empty, *labels* lacks a MultiIndex,
            or any feature column is not boolean.
    """
    _validate_shapley_inputs(features, labels)

    shapley_values: dict[str, pd.Series] = {}

    n_factors = len(features.columns)
    total_combinations = sum(math.comb(n_factors, i) for i in range(1, n_factors + 1))

    with tqdm(total=total_combinations, desc="Calculating Shapley values") as pbar:
        for i in range(1, n_factors + 1):
            for combo in itertools.combinations(features.columns, i):
                _accumulate_combo(combo, features, labels, shapley_values)
                pbar.update(1)

    return pd.DataFrame(shapley_values)
