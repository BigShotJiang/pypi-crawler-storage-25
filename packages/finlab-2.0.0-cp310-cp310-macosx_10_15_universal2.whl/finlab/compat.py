"""Compatibility utilities.

Provides:
- stock_id → symbol migration helpers
- Pandas version-aware resample frequency aliases
"""

from __future__ import annotations

import functools
import os
import re
from typing import TYPE_CHECKING, Any, Final

__all__ = [
    "MONTHLY_END",
    "YEARLY_END",
    "get_symbol",
    "normalize_id_column",
    "normalize_index_name",
    "normalize_position_dict",
    "param_alias",
    "resolve_id_column",
    "resolve_position_entry_symbol",
    "resolve_symbol_param",
]

if TYPE_CHECKING:
    from collections.abc import Callable

import pandas as pd

CANONICAL_NAME: Final[str] = "symbol"
LEGACY_NAME: Final[str] = "stock_id"
TYPED_STRICT_ENV_VAR: Final[str] = "FINLAB_TYPED_STRICT"

# ---------------------------------------------------------------------------
# Pandas resample frequency aliases
# ---------------------------------------------------------------------------
# Pandas >= 2.2.0 deprecated single-letter aliases ('M', 'Y', 'A') in favour
# of end-anchored names ('ME', 'YE').  These constants pick the right alias
# at import time so every call-site stays DRY.

_pd_version = tuple(
    int(re.match(r"\d+", x).group()) for x in pd.__version__.split(".")[:2]
)

MONTHLY_END: Final[str] = "ME" if _pd_version >= (2, 2) else "M"
YEARLY_END: Final[str] = "YE" if _pd_version >= (2, 2) else "Y"


# ---------------------------------------------------------------------------
# DataFrame helpers
# ---------------------------------------------------------------------------


def validate_no_dual_columns(df: pd.DataFrame) -> None:
    """Raise ``ValueError`` if *both* 'symbol' and 'stock_id' exist as columns or index levels."""
    names: set[str] = set()
    if isinstance(df.columns, pd.MultiIndex):
        names.update(df.columns.names)
    else:
        names.update(df.columns.tolist())
    if isinstance(df.index, pd.MultiIndex):
        names.update(df.index.names)
    elif df.index.name is not None:
        names.add(df.index.name)
    if CANONICAL_NAME in names and LEGACY_NAME in names:
        raise ValueError(
            f"DataFrame contains both '{CANONICAL_NAME}' and '{LEGACY_NAME}'. "
            "Please use only one identifier name."
        )


def resolve_id_column(df: pd.DataFrame) -> str:
    """Return whichever column name (``'symbol'`` or ``'stock_id'``) is present.

    Prefers ``'symbol'``.  Returns ``'symbol'`` if neither is found.
    """
    cols = set(df.columns.tolist())
    if CANONICAL_NAME in cols:
        return CANONICAL_NAME
    if LEGACY_NAME in cols:
        return LEGACY_NAME
    return CANONICAL_NAME


def normalize_id_column(df: pd.DataFrame) -> pd.DataFrame:
    """Silently rename the ``'stock_id'`` column to ``'symbol'`` if present."""
    if LEGACY_NAME in df.columns and CANONICAL_NAME not in df.columns:
        df = df.rename(columns={LEGACY_NAME: CANONICAL_NAME})
    return df


def normalize_index_name(df: pd.DataFrame) -> pd.DataFrame:
    """Silently rename the index name from ``'stock_id'`` to ``'symbol'``."""
    if isinstance(df.index, pd.MultiIndex):
        new_names = [CANONICAL_NAME if n == LEGACY_NAME else n for n in df.index.names]
        df.index.names = new_names
    elif df.index.name == LEGACY_NAME:
        df.index.name = CANONICAL_NAME
    return df


# ---------------------------------------------------------------------------
# Function parameter helpers
# ---------------------------------------------------------------------------


def resolve_symbol_param(
    symbol: str | None = None,
    stock_id: str | None = None,
) -> str | None:
    """Resolve dual kwargs — raise if both are given."""
    if symbol is not None and stock_id is not None:
        raise ValueError(
            "Cannot specify both 'symbol' and 'stock_id'. Use 'symbol' only."
        )
    return symbol if symbol is not None else stock_id


def param_alias(
    old: str = "stock_id", new: str = "symbol"
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that silently accepts the *old* kwarg name as an alias for *new*.

    If both are passed, ``ValueError`` is raised.
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if old in kwargs:
                if new in kwargs:
                    raise ValueError(
                        f"Cannot specify both '{new}' and '{old}'. Use '{new}' only."
                    )
                kwargs[new] = kwargs.pop(old)
            return fn(*args, **kwargs)

        return wrapper

    return decorator


# ---------------------------------------------------------------------------
# Dict helpers (for position dicts, order dicts, etc.)
# ---------------------------------------------------------------------------


def get_symbol(d: dict[str, Any]) -> str | None:
    """Get the identifier value from a dict that may use either key."""
    if CANONICAL_NAME in d:
        return d[CANONICAL_NAME]
    return d.get(LEGACY_NAME)


def resolve_position_entry_symbol(d: dict[str, Any]) -> str:
    """Resolve symbol from position/order-like dicts using legacy fallback semantics.

    Behavior intentionally mirrors ``d.get('symbol') or d['stock_id']``:
    - prefer a truthy ``symbol``
    - fallback to ``stock_id``
    - raise ``KeyError`` if neither is usable
    """
    symbol = d.get(CANONICAL_NAME)
    if symbol:
        return symbol
    if LEGACY_NAME in d:
        return d[LEGACY_NAME]
    raise KeyError(f"missing both '{CANONICAL_NAME}' and '{LEGACY_NAME}'")


def is_typed_strict_mode() -> bool:
    """Whether typed strict mode is enabled by environment variable."""
    raw = os.getenv(TYPED_STRICT_ENV_VAR, "")
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def normalize_position_dict(d: dict[str, Any]) -> dict[str, Any]:
    """Ensure a position dict carries **both** ``'symbol'`` and ``'stock_id'`` keys.

    If both keys exist with *different* values, ``ValueError`` is raised.
    """
    has_new = CANONICAL_NAME in d
    has_old = LEGACY_NAME in d
    if has_new and has_old:
        if d[CANONICAL_NAME] != d[LEGACY_NAME]:
            raise ValueError(
                f"Position dict has conflicting identifiers: "
                f"symbol={d[CANONICAL_NAME]!r}, stock_id={d[LEGACY_NAME]!r}"
            )
        return d
    if has_new:
        d[LEGACY_NAME] = d[CANONICAL_NAME]
    elif has_old:
        d[CANONICAL_NAME] = d[LEGACY_NAME]
    return d
