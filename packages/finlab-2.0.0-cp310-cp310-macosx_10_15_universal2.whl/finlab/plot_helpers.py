"""Pure data-shaping helpers extracted from ``finlab.plot``.

Every function in this module is a pure transformation
(DataFrame/Series in, DataFrame/Series out) with **no** plotting-library
dependency. This makes them independently testable offline.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pandas as pd

if TYPE_CHECKING:
    from collections.abc import Sequence


# ---------------------------------------------------------------------------
# Date filtering
# ---------------------------------------------------------------------------


def df_date_filter(
    df: pd.DataFrame, start: str | None = None, end: str | None = None
) -> pd.DataFrame:
    """Filter a DataFrame to rows whose index falls within [start, end].

    Args:
        df: DataFrame with a sortable index (typically DatetimeIndex).
        start: Inclusive lower bound (``None`` means no lower bound).
        end: Inclusive upper bound (``None`` means no upper bound).

    Returns:
        Filtered DataFrame.
    """
    if start:
        df = df[df.index >= start]
    if end:
        df = df[df.index <= end]
    return df


# ---------------------------------------------------------------------------
# Return / cumulative-return computations
# ---------------------------------------------------------------------------


def compute_return_ratio(prices: pd.Series) -> float:
    """Compute the simple percentage return from first to last value.

    ``(last / first - 1) * 100``, rounded to two decimals.

    Args:
        prices: A Series of prices (at least two non-NaN values).

    Returns:
        Percentage return as a float (e.g. ``12.34`` for +12.34 %).

    Raises:
        ValueError: If *prices* has fewer than two values.
    """
    prices = prices.dropna()
    if len(prices) < 2:
        raise ValueError("Need at least two non-NaN values to compute a return ratio.")
    return round(((prices.iloc[-1] / prices.iloc[0]) - 1) * 100, 2)


def compute_cumulative_returns(prices: pd.Series) -> pd.Series:
    """Normalise a price series to cumulative percentage returns from the first value.

    ``((price / price[0]) - 1) * 100``, rounded to two decimals.

    Args:
        prices: A Series of prices.

    Returns:
        Series of cumulative returns in percent.

    Raises:
        ValueError: If *prices* is empty.
    """
    if prices.empty:
        raise ValueError("Cannot compute cumulative returns from an empty Series.")
    return round(((prices / prices.iloc[0]) - 1) * 100, 2)


# ---------------------------------------------------------------------------
# OHLCV resampling
# ---------------------------------------------------------------------------


def resample_ohlcv(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    """Resample an OHLCV DataFrame to a coarser frequency.

    Expects columns ``open``, ``high``, ``low``, ``close``, ``volume``.

    Args:
        df: OHLCV DataFrame with a DatetimeIndex.
        rule: Pandas offset alias (e.g. ``"W"``, ``"M"``).

    Returns:
        Resampled OHLCV DataFrame.
    """
    return df.resample(rule).agg(
        {
            "close": "last",
            "open": "first",
            "high": "max",
            "low": "min",
            "volume": "sum",
        }
    )


# ---------------------------------------------------------------------------
# PE / PB river borders
# ---------------------------------------------------------------------------


def compute_river_borders(
    close: pd.Series,
    ratio: pd.Series,
    split_range: int = 6,
) -> pd.DataFrame:
    """Compute PE/PB river-chart border lines from price and ratio data.

    Args:
        close: Closing price series (same index as *ratio*).
        ratio: PE or PB ratio series.
        split_range: Number of river bands.

    Returns:
        DataFrame with columns ``ratio_close`` (close / ratio),
        ``close``, ``ratio``, and one column per border line
        named ``"<border_value>"`` (float formatted).
    """
    ratio = ratio.dropna()
    close = close.reindex(ratio.index)
    max_value = ratio.max()
    min_value = ratio.min()
    quan_value = (max_value - min_value) / split_range
    border_values = [
        round(min_value + quan_value * i, 2) for i in range(split_range + 1)
    ]
    ratio_close = (close / ratio).dropna()
    result = ratio_close.to_frame("ratio_close")
    result["close"] = close
    result["ratio"] = ratio
    for border in border_values:
        result[str(border)] = result["ratio_close"] * border
    return round(result, 2)


# ---------------------------------------------------------------------------
# Line-segment colour segmentation
# ---------------------------------------------------------------------------


def segment_series_by_color(
    series: pd.Series,
    default_color: str,
    h_line_ranges: Sequence[Sequence[Any]],
    v_line_ranges: Sequence[Sequence[Any]],
    resolve_color_fn: Any | None = None,
) -> list[tuple[list[Any], list[Any], str]]:
    """Split a Series into contiguous segments sharing the same colour.

    Each segment is a ``(xs, ys, colour)`` tuple suitable for plotting as a
    single trace.  Adjacent segments share one overlapping point so that
    rendered line segments connect without gaps.

    Args:
        series: Data series (index = x values, values = y values).
        default_color: Fallback colour when no range matches.
        h_line_ranges: Horizontal (y-value) colour ranges.
        v_line_ranges: Vertical (x-value) colour ranges.
        resolve_color_fn: Optional callable ``(x, y, default, h_ranges,
            v_ranges) -> colour``.  When *None* the built-in
            ``_resolve_color`` logic from ``finlab.plot`` is used.

    Returns:
        List of ``(xs, ys, colour)`` tuples.
    """
    if resolve_color_fn is None:
        from finlab.plot import _resolve_color

        resolve_color_fn = _resolve_color

    series = series.dropna()
    if series.empty:
        return []

    segments: list[tuple[list[Any], list[Any], str]] = []
    cur_xs: list[Any] = []
    cur_ys: list[Any] = []
    cur_col: str | None = None

    for i, (x, y) in enumerate(series.items()):
        new_col = resolve_color_fn(x, y, default_color, h_line_ranges, v_line_ranges)
        if cur_col is None:
            cur_col = new_col
            cur_xs.append(x)
            cur_ys.append(y)
            continue

        if new_col == cur_col:
            cur_xs.append(x)
            cur_ys.append(y)
        else:
            segments.append((cur_xs, cur_ys, cur_col))
            prev_x, prev_y = series.index[i - 1], series.iloc[i - 1]
            cur_xs = [prev_x, x]
            cur_ys = [prev_y, y]
            cur_col = new_col

    if cur_xs:
        segments.append((cur_xs, cur_ys, cur_col))

    return segments


# ---------------------------------------------------------------------------
# Strategy helpers
# ---------------------------------------------------------------------------


def compute_strategy_mean_return(returns_set: dict[str, float]) -> float:
    """Compute the arithmetic mean of a mapping of strategy returns.

    Args:
        returns_set: ``{strategy_name: return_pct, ...}``.

    Returns:
        Mean return rounded to two decimals, or ``0.0`` if *returns_set*
        is empty.
    """
    if not returns_set:
        return 0.0
    return round(sum(returns_set.values()) / len(returns_set), 2)


def build_cumulative_returns_df(
    returns_map: dict[str, pd.Series],
) -> pd.DataFrame:
    """Build a long-form DataFrame of cumulative returns for multiple strategies.

    Each input Series is normalised via :func:`compute_cumulative_returns` and
    then stacked into a three-column DataFrame ``(strategy, date, creturns)``.

    Args:
        returns_map: ``{strategy_name: price_series, ...}``.

    Returns:
        Long-form DataFrame with columns ``strategy``, ``date``, ``creturns``.
    """
    cum: dict[str, pd.Series] = {}
    for name, prices in returns_map.items():
        cum[name] = compute_cumulative_returns(prices)
    df = pd.DataFrame(cum).unstack().to_frame().reset_index()
    df.columns = ["strategy", "date", "creturns"]
    return df
