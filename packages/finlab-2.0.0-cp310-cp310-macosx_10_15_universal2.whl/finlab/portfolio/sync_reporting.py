"""Reporting helpers for ``PortfolioSyncManager`` display methods."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pandas as pd

from .sync_display import build_position_dataframe, build_strategy_info_dataframe

if TYPE_CHECKING:
    from finlab.online.order_executor import Position

__all__ = [
    "build_total_position_dataframe",
    "format_portfolio_repr",
]


def _total_allocation(data: dict[str, Any]) -> float:
    return sum(v["allocation"] for v in data["position"].values())


def build_total_position_dataframe(
    data: dict[str, Any],
    position: Position,
    ref_price: dict[str, float],
    close_price: dict[str, float],
    volume: dict[str, float],
) -> pd.DataFrame:
    return build_position_dataframe(
        position=position,
        position_data=data["position"],
        config=data["config"],
        ref_price=ref_price,
        close_price=close_price,
        volume=volume,
        total_allocation=_total_allocation(data),
    )


def format_portfolio_repr(
    data: dict[str, Any],
    position: Position,
    ref_price: dict[str, float],
    close_price: dict[str, float],
    volume: dict[str, float],
) -> str:
    pd.set_option("display.max_rows", None)
    pd.set_option("display.float_format", "{:.2f}".format)

    df = build_total_position_dataframe(data, position, ref_price, close_price, volume)

    if len(df) != 0:
        result = (
            "Estimate value "
            f"{int((df.price.astype(float) * df.quantity.astype(float) * 1000).sum())}"
        )
    else:
        result = "Position"

    total_balance = data["config"].get("params", {}).get("total_balance", 0)
    strategy_df = build_strategy_info_dataframe(data["position"], total_balance)

    result = (
        result
        + "\n\n"
        + df.to_string()
        + "\n\n\n"
        + "strategy\n\n"
        + strategy_df.to_string()
    )
    pd.reset_option("display.max_rows")
    pd.reset_option("display.float_format")
    return result
