"""Market-data helpers for ``PortfolioSyncManager`` runtime flows."""

from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import pandas as pd

from finlab.compat import resolve_position_entry_symbol
from finlab.markets import get_market_by_name
from finlab.markets.tw import TWMarket

logger = logging.getLogger(__name__)

__all__ = [
    "calc_position_value",
    "compute_existing_asset_value",
    "fetch_tw_market_snapshot",
]


def calc_position_value(
    position: list[dict[str, Any]], lot: float, price: pd.Series
) -> float:
    total = 0.0

    for entry in position:
        sid = resolve_position_entry_symbol(entry)
        if sid not in price:
            raise ValueError(f"stock {sid} not found")

        value = float(entry["quantity"]) * float(price[sid]) * lot
        if not math.isnan(value):
            total += value
        else:
            logger.warning(
                "price of %s is %s, quantity is %s",
                sid,
                price[sid],
                entry["quantity"],
            )

    return total


def compute_existing_asset_value(
    position_data: dict[str, Any],
    portfolio: dict[str, Any],
    updated_strategies: list[str],
) -> float:
    asset_value = 0.0

    for sid, info in position_data.items():
        if sid in updated_strategies:
            continue
        try:
            sid_market = (
                get_market_by_name(info.get("market")) if "market" in info else None
            )
            if sid_market is None:
                sid_market = portfolio[sid].market if sid in portfolio else TWMarket()
        except (KeyError, ValueError, RuntimeError):
            sid_market = TWMarket()

        sid_lot = sid_market.get_odd_lot()
        sid_price = sid_market.get_price("close", adj=False).ffill().iloc[-1]
        asset_value += calc_position_value(
            info["position"], lot=sid_lot, price=sid_price
        )

    return asset_value


def fetch_tw_market_snapshot() -> tuple[
    dict[str, float], dict[str, float], dict[str, float]
]:
    market = TWMarket()
    ref_price = market.get_reference_price()
    close_price = market.get_price("close", adj=False).iloc[-1].to_dict()
    volume = market.get_price("volume", adj=False).iloc[-1].to_dict()
    return ref_price, close_price, volume
