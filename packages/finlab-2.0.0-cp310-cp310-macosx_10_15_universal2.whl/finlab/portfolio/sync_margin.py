"""Margin / cash position combining logic for PortfolioSyncManager.

Extracted from portfolio_sync_manager.py so that the cross-order-condition
reconciliation can be tested and reasoned about independently.
"""

from __future__ import annotations

from finlab.compat import resolve_position_entry_symbol
from finlab.online.enums import OrderCondition
from finlab.online.order_executor import Position

__all__ = ["margin_cash_position_combine"]


def margin_cash_position_combine(acp: Position, idp: Position) -> Position:
    """Merge cash and margin-trading positions to avoid redundant orders.

    When the diff between the ideal and account positions contains
    opposing quantities for the same symbol across CASH and
    MARGIN_TRADING conditions, the opposing amounts cancel out so
    that only the net difference is traded.

    Args:
        acp: Current account position.
        idp: Ideal (target) position.

    Returns:
        Adjusted ideal position with cancelled cross-condition quantities.
    """
    diff = idp - acp

    cash = {
        resolve_position_entry_symbol(p): p.copy()
        for p in diff.position
        if p["order_condition"] == OrderCondition.CASH
    }
    margin_trading = {
        resolve_position_entry_symbol(p): p.copy()
        for p in diff.position
        if p["order_condition"] == OrderCondition.MARGIN_TRADING
    }

    for sid in cash.keys() & margin_trading.keys():
        if cash[sid]["quantity"] * margin_trading[sid]["quantity"] >= 0:
            continue

        reduce_amount = min(
            abs(cash[sid]["quantity"]), abs(margin_trading[sid]["quantity"])
        )

        if cash[sid]["quantity"] > 0:
            cash[sid]["quantity"] -= reduce_amount
            margin_trading[sid]["quantity"] += reduce_amount
        else:
            cash[sid]["quantity"] += reduce_amount
            margin_trading[sid]["quantity"] -= reduce_amount

    newdiff = [p for p in cash.values() if p["quantity"] != 0] + [
        p for p in margin_trading.values() if p["quantity"] != 0
    ]
    newdiff = Position.from_list(newdiff)
    return idp - diff + newdiff
