from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping


def _validate_dict_value(
    data: Mapping[str, Any], key: str, subkeys: Mapping[str, Any], data_name: str
) -> None:
    """Validate a dict-typed value, recursing into nested structure."""
    if not isinstance(data[key], (dict, type(None))):
        raise TypeError(
            f"Incorrect type for {data_name}['{key}']: expected dict or None, got {type(data[key])}"
        )
    if data[key] is not None:
        validate_structure(data[key], subkeys, f"{data_name}['{key}']")


def _validate_list_value(
    data: Mapping[str, Any], key: str, subkeys: list[Any], data_name: str
) -> None:
    """Validate a list-typed value, checking element types or nested dicts."""
    if not isinstance(data[key], list):
        raise TypeError(
            f"Incorrect type for {data_name}['{key}']: expected list, got {type(data[key])}"
        )
    for element in data[key]:
        if isinstance(subkeys[0], dict):
            validate_structure(element, subkeys[0], f"{data_name}['{key}']")
        elif not isinstance(element, tuple(subkeys)):
            raise TypeError(
                f"Incorrect type for elements in {data_name}['{key}']: expected {subkeys[0]}, got {type(element)}"
            )


def validate_structure(
    data: Mapping[str, Any],
    required_structure: Mapping[str, Any],
    data_name: str = "data",
) -> None:
    """
    Recursively validate the structure and types of a nested dictionary,
    including lists of types and nested dictionaries.

    Parameters:
    - data: dict, the dictionary to validate
    - required_structure: dict, the required structure and types
    - data_name: str, the name of the data (used for error messages)
    """
    for key, subkeys in required_structure.items():
        if key not in data:
            raise ValueError(f"Missing key in {data_name}: {key}")

        if isinstance(subkeys, dict):
            _validate_dict_value(data, key, subkeys, data_name)
        elif isinstance(subkeys, list):
            _validate_list_value(data, key, subkeys, data_name)
        elif not isinstance(data[key], (subkeys, type(None))):
            raise TypeError(
                f"Incorrect type for {data_name}['{key}']: expected {subkeys} or None, got {type(data[key])}"
            )
