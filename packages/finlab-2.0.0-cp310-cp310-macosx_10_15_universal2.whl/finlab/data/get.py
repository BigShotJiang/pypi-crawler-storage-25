"""Shared fetch pipeline plus ``data.get()`` single-dataset wrapper."""

from __future__ import annotations

import functools
import gc
import hashlib
import logging
import sys
from collections import OrderedDict
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, Any

import pandas as pd
from requests.exceptions import HTTPError

import finlab.dataframe
import finlab.utils

# Re-exports for backward compat: data.py imports these from get.py
from .auth import (
    _AUTH_ERRORS,  # noqa: F401
    _AUTH_URL,  # noqa: F401
    _DEFAULT_HEADERS,
    FetchMetadata,
    MetadataRequestMap,
    MetadataResultMap,
    _dataset_to_blob,  # noqa: F401
    _download_dataframe,
    _refresh_id_token,  # noqa: F401
    _resolve_auth_params,  # noqa: F401
    fetch_metadata_batch,
)
from .context import _default_context
from .freshness import (
    _get_expiry_dict,  # noqa: F401
    is_tradable,
    next_future_expiry,
    suggested_tradable_time,
)
from .market import _resolve_dataset
from .storage import CacheStorage
from .transform import (
    TABLE_INDEX_TRANSFORMERS,  # noqa: F401
    _apply_truncate_if_any,
    _mask_undisclosed_quarterly,  # noqa: F401
    _normalize_stock_columns,  # noqa: F401
    _set_dataframe_index,  # noqa: F401
    _should_mask_quarterly,
    has_index_name,  # noqa: F401
    process_data,
)
from .universe import refine_stock_id

if TYPE_CHECKING:
    import datetime

    from .progress import DownloadProgress

logger = logging.getLogger(__name__)

MetadataFetcher = Callable[
    [
        MetadataRequestMap,
    ],
    MetadataResultMap,
]

__all__ = [
    "get",
    "get_role",
    "is_tradable",
    "is_vip",
    "next_future_expiry",
    "process_data",
    "suggested_tradable_time",
]


# ---------------------------------------------------------------------------
# Finalize / cache pipeline
# ---------------------------------------------------------------------------


def _finalize(dataset: str, df: pd.DataFrame) -> pd.DataFrame:
    from .universe import universe_stocks

    ctx = _default_context
    cache_key = (
        dataset,
        id(df),
        frozenset(universe_stocks) if universe_stocks else None,
        ctx.truncate_start,
        ctx.truncate_end,
    )
    cached = ctx._finalized_cache.get(cache_key)
    if cached is not None:
        return cached

    table_name = dataset.split(":", maxsplit=1)[0]
    skip_end = _should_mask_quarterly(table_name, ctx.truncate_end)
    df = _apply_truncate_if_any(df, skip_end=skip_end)

    if not isinstance(df, finlab.dataframe.FinlabDataFrame):
        df = finlab.dataframe.FinlabDataFrame(df)
    result = refine_stock_id(dataset, df)
    ctx._finalized_cache[cache_key] = result
    return result


def hash(df: pd.DataFrame) -> str:
    return hashlib.md5(pd.util.hash_pandas_object(df, index=True).values).hexdigest()[
        :7
    ]


def _is_local_usable(dataset: str, df: pd.DataFrame | None) -> bool:
    """Return whether the local dataframe can satisfy the request immediately."""
    ctx = _default_context
    storage = ctx._storage
    time_expired = storage.get_time_expired(dataset)

    # Already loaded this session: skip server round-trip but still respect expiry
    if (
        dataset in ctx._loaded_datasets
        and time_expired
        and time_expired > CacheStorage.now()
        and df is not None
        and not df.empty
    ):
        logger.debug(f"{dataset} already loaded and not expired -> use cache")
        return True

    # Prefer local cache without checking expiry (user-set flag)
    if ctx.prefer_local_if_exists and df is not None and not df.empty:
        logger.debug(
            f"{dataset} prefer_local_if_exists enabled -> get data from local without update check"
        )
        return True

    if (
        time_expired
        and time_expired > CacheStorage.now()
        and df is not None
        and not df.empty
    ):
        logger.debug(f"{dataset} not expired -> get data from local")
        return True

    # Free user can only use historical data without merge
    return bool(ctx._role == "free" and df is not None)


_MERGE_DEDUP_COLS = ["symbol", "stock_id", "date", "\u6301\u80a1\u5206\u7d1a", "broker"]


def _merge_recent_df(df: pd.DataFrame, short_df: pd.DataFrame) -> pd.DataFrame:
    """Merge a recent delta into an existing DataFrame, deduplicating rows."""
    compare_cols = df.columns.intersection(_MERGE_DEDUP_COLS)
    return (
        pd.concat([df, short_df])
        .pipe(lambda d: d[~d.duplicated(subset=compare_cols, keep="last")])[
            short_df.columns
        ]
        .reset_index(drop=True)
    )


def _prepare_fetch(
    datasets: list[str],
    force_download: bool,
) -> tuple[Any, list[str], Any, bool]:
    """Apply shared preflight checks and resolve dataset aliases."""
    if not datasets:
        raise ValueError("at least one dataset name required")

    finlab.utils.check_version()
    ctx = _default_context
    force_download |= ctx.force_cloud_download

    if ctx.use_local_data_only and force_download:
        raise ValueError(
            "data.use_local_data_only and data.force_download cannot be both True"
        )

    resolved = [_resolve_dataset(dataset) for dataset in datasets]
    return ctx, resolved, ctx._storage, force_download


def _partition_datasets(
    resolved: list[str],
    storage: Any,
    force_download: bool,
    use_local_only: bool,
) -> tuple[
    dict[str, pd.DataFrame],
    list[str],
    list[str],
    dict[str, datetime.datetime | None],
    dict[str, pd.DataFrame | None],
]:
    """Split datasets into local hits, recent candidates, and full misses."""
    cache_hits: dict[str, pd.DataFrame] = {}
    recent_candidates: list[str] = []
    cache_misses: list[str] = []
    time_saved_map: dict[str, datetime.datetime | None] = {}
    local_frames: dict[str, pd.DataFrame | None] = {}

    if force_download:
        return (
            cache_hits,
            recent_candidates,
            list(resolved),
            time_saved_map,
            local_frames,
        )

    for dataset in resolved:
        df = storage.get_dataframe(dataset)
        local_frames[dataset] = df

        if _is_local_usable(dataset, df):
            cache_hits[dataset] = _finalize(dataset, df)
            continue

        if use_local_only:
            if df is not None and not df.empty:
                cache_hits[dataset] = _finalize(dataset, df)
                continue
            raise FileNotFoundError(
                f"**Error: {dataset} not in local storage. "
                "Set data.use_local_data_only = False to download."
            )

        if df is not None:
            recent_candidates.append(dataset)
            time_saved_map[dataset] = storage.get_time_created(dataset)
            continue

        cache_misses.append(dataset)

    return cache_hits, recent_candidates, cache_misses, time_saved_map, local_frames


def _download_result_dataframe(
    result: FetchMetadata | None,
    dataset: str,
    on_progress: Callable[[int, int], None] | None = None,
) -> pd.DataFrame:
    """Return dataframe payload from a remote fetch result."""
    if result is None:
        raise FileNotFoundError(f"**Error: {dataset} not exists")
    if result.data is not None:
        if on_progress is not None:
            on_progress(1, 1)
        return result.data

    url = result.url
    if not url:
        raise FileNotFoundError(f"**Error: {dataset} not exists")

    return _download_dataframe(url, _DEFAULT_HEADERS, on_progress=on_progress)


def _build_progress_callback(
    progress: DownloadProgress,
    dataset: str,
) -> tuple[Callable[[int, int], None], Callable[[], int]]:
    """Build per-dataset byte progress callback and final-size accessor."""
    state: dict[str, int] = {"downloaded": 0, "total": 0}

    def _on_progress(downloaded: int, total: int) -> None:
        total_effective = total if total > 0 else max(downloaded, 1)
        state["downloaded"] = downloaded
        state["total"] = total_effective
        progress.update(dataset, downloaded, total_effective)

    def _final_bytes() -> int:
        return state["total"] or state["downloaded"] or 1

    return _on_progress, _final_bytes


def _estimate_dataframe_bytes(df: pd.DataFrame) -> int:
    """Estimate display size for a downloaded dataframe."""
    try:
        return max(int(df.memory_usage(deep=True).sum()), 1)
    except (TypeError, ValueError):
        return 1


def _download_recent_delta(
    dataset: str,
    result: FetchMetadata,
    progress: DownloadProgress | None,
) -> tuple[pd.DataFrame, int | None]:
    """Download one ``.recent`` payload with optional progress updates."""
    if progress is None:
        return _download_result_dataframe(result, f"{dataset}.recent"), None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    short_df = _download_result_dataframe(
        result,
        f"{dataset}.recent",
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(short_df)
    return short_df, nbytes


def _resolve_recent_hit(
    dataset: str,
    df: pd.DataFrame,
    result: FetchMetadata,
    storage: Any,
    progress: DownloadProgress | None,
) -> pd.DataFrame | None:
    """Return finalized dataframe when recent-merge succeeds, else ``None``."""
    if result.error:
        logger.debug("Recent metadata error for %s: %s", dataset, result.error)
        return None

    # .recent may return metadata-only payload to indicate local cache is still valid.
    if result.data is None and not result.url:
        if result.expiry is not None:
            storage.set_time_expired(dataset, result.expiry)
        if progress is not None:
            progress.mark_cached(dataset)
        return _finalize(dataset, df)

    try:
        short_df, recent_nbytes = _download_recent_delta(dataset, result, progress)
        merged_df = _merge_recent_df(df, short_df)
    except HTTPError:
        logger.debug("HTTP error while downloading recent delta for %s", dataset)
        raise
    except (FileNotFoundError, KeyError, ValueError, TypeError):
        logger.debug("Failed to merge recent data for %s", dataset)
        return None

    hash_df = hash(merged_df)
    logger.debug(f"hash df: {hash_df} url: {result.hash}")
    if result.hash != hash_df or merged_df.empty:
        return None

    if progress is not None and recent_nbytes is not None:
        progress.complete(dataset, recent_nbytes)
    storage.set_dataframe(dataset, merged_df, expiry=result.expiry)
    logger.debug("get recent, is valid -> and merge recent to local data")
    return _finalize(dataset, merged_df)


def _resolve_recent_candidates(
    recent_candidates: list[str],
    time_saved_map: dict[str, datetime.datetime | None],
    storage: Any,
    local_frames: dict[str, pd.DataFrame | None],
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Try to satisfy stale local datasets through ``.recent`` fetches."""
    if not recent_candidates:
        return {}, []

    recent_requests: MetadataRequestMap = OrderedDict(
        (f"{dataset}.recent", time_saved_map.get(dataset))
        for dataset in recent_candidates
    )
    if progress is not None:
        progress.set_stage(
            "Fetching recent metadata",
            done=0,
            total=1,
        )
    result_map = metadata_fetcher(recent_requests)
    if progress is not None:
        progress.set_stage(
            "Fetching recent metadata",
            done=1,
            total=1,
        )

    if progress is not None:
        progress.set_stage(
            "Downloading recent deltas",
            done=0,
            total=len(recent_candidates),
            datasets=recent_candidates,
        )

    cache_hits: dict[str, pd.DataFrame] = {}
    full_misses: list[str] = []

    for dataset in recent_candidates:
        df = local_frames.get(dataset)
        result = result_map.get(f"{dataset}.recent")
        if result is None or df is None or df.empty:
            full_misses.append(dataset)
            continue

        recent_hit = _resolve_recent_hit(dataset, df, result, storage, progress)
        if recent_hit is None:
            full_misses.append(dataset)
            continue
        cache_hits[dataset] = recent_hit

    return cache_hits, full_misses


def _materialize_full_misses(
    cache_misses: list[str],
    storage: Any,
    metadata_fetcher: MetadataFetcher,
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full datasets for the remaining remote misses."""
    if not cache_misses:
        return {}

    gc.collect()
    request_map: MetadataRequestMap = OrderedDict(
        (dataset, None) for dataset in cache_misses
    )
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=0,
            total=1,
        )
    result_map = metadata_fetcher(request_map)
    if progress is not None:
        progress.set_stage(
            "Fetching full metadata",
            done=1,
            total=1,
        )
    target_storage = _resolve_full_miss_target_storage(storage, result_map)
    validated_results = _validate_full_miss_results(cache_misses, result_map)
    downloaded_frames = _download_full_miss_frames(
        cache_misses,
        validated_results,
        progress=progress,
    )
    return _persist_full_miss_frames(
        cache_misses,
        downloaded_frames,
        validated_results,
        target_storage,
    )


def _resolve_full_miss_target_storage(
    storage: Any,
    result_map: MetadataResultMap,
) -> Any:
    """Resolve storage backend for full misses, switching free users to cache storage."""
    if isinstance(storage, CacheStorage):
        return storage

    has_free_role = any(
        result is not None and result.role == "free" for result in result_map.values()
    )
    if not has_free_role:
        return storage

    if not isinstance(_default_context._storage, CacheStorage):
        _default_context._storage = CacheStorage()
    return _default_context._storage


def _validate_full_miss_results(
    cache_misses: list[str],
    result_map: MetadataResultMap,
) -> OrderedDict[str, FetchMetadata]:
    """Validate full-miss metadata and raise actionable per-item errors."""
    validated_results: OrderedDict[str, FetchMetadata] = OrderedDict()
    for dataset in cache_misses:
        result = result_map.get(dataset)
        if result is None:
            raise FileNotFoundError(f"**Error: {dataset} not exists")
        if result.error:
            raise RuntimeError(f"**Error: {result.error}")
        validated_results[dataset] = result
    return validated_results


@functools.lru_cache(maxsize=1)
def _use_pyodide_async_fetch() -> bool:
    """Return True when pyodide async parallel fetch is available."""
    if "pyodide" not in sys.modules:
        return False
    try:
        import importlib.util

        return importlib.util.find_spec("pyodide.http") is not None and (
            importlib.util.find_spec("pyodide.ffi") is not None
            or importlib.util.find_spec("pyodide.code") is not None
        )
    except (ImportError, ValueError):
        return False


def _download_full_miss_frames_threaded(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes via ThreadPoolExecutor."""

    max_workers = min(8, len(cache_misses))
    if max_workers <= 1:
        return _download_full_miss_frames_sequential(
            cache_misses,
            validated_results,
            progress,
        )

    downloaded_frames: dict[str, pd.DataFrame] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(
                _download_one_full_miss_frame,
                dataset,
                validated_results,
                progress,
            ): dataset
            for dataset in cache_misses
        }
        for future in as_completed(future_map):
            dataset = future_map[future]
            df, nbytes = future.result()
            downloaded_frames[dataset] = df
            if progress is not None and nbytes is not None:
                progress.complete(dataset, nbytes)
    return downloaded_frames


def _download_one_full_miss_frame(
    dataset: str,
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> tuple[pd.DataFrame, int | None]:
    """Download one full-miss dataframe and return its display byte count."""
    if progress is None:
        df = _download_result_dataframe(validated_results[dataset], dataset)
        return df, None

    on_progress, final_bytes = _build_progress_callback(progress, dataset)
    df = _download_result_dataframe(
        validated_results[dataset],
        dataset,
        on_progress=on_progress,
    )
    nbytes = final_bytes()
    if nbytes <= 1:
        nbytes = _estimate_dataframe_bytes(df)
    return df, nbytes


def _download_full_miss_frames_sequential(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes without threads or async stack switching."""
    downloaded_frames: dict[str, pd.DataFrame] = {}
    for dataset in cache_misses:
        df, nbytes = _download_one_full_miss_frame(
            dataset,
            validated_results,
            progress,
        )
        downloaded_frames[dataset] = df
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded_frames


def _is_pyodide_stack_switch_error(exc: RuntimeError) -> bool:
    """Return True for Pyodide's sync-entrypoint async bridge failure."""
    message = str(exc)
    return "Cannot stack switch" in message and "callPromising" in message


def _get_pyodide_run_sync() -> Callable[[Any], Any]:
    """Return Pyodide's async-to-sync bridge."""
    try:
        from pyodide.ffi import run_sync
    except ImportError:
        from pyodide.code import run_sync
    return run_sync


def _can_run_pyodide_sync(run_sync: Callable[[Any], Any]) -> bool:
    """Return whether Pyodide run_sync is usable from this Python entrypoint."""

    async def _noop() -> None:
        return None

    awaitable = _noop()
    try:
        run_sync(awaitable)
    except RuntimeError as exc:
        if _is_pyodide_stack_switch_error(exc):
            return False
        awaitable.close()
        raise
    return True


def _run_pyodide_sync(run_sync: Callable[[Any], Any], awaitable: Any) -> Any:
    """Run a Pyodide awaitable synchronously, closing it if the bridge rejects it."""
    try:
        return run_sync(awaitable)
    except RuntimeError as exc:
        if not _is_pyodide_stack_switch_error(exc):
            awaitable.close()
        raise


def _download_full_miss_frames(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes concurrently when beneficial."""
    if progress is not None:
        progress.set_stage(
            "Downloading full datasets",
            done=0,
            total=len(cache_misses),
            datasets=cache_misses,
        )

    if _use_pyodide_async_fetch():
        run_sync = _get_pyodide_run_sync()
        if not _can_run_pyodide_sync(run_sync):
            logger.debug(
                "Pyodide async fetch unavailable from a synchronous entrypoint; "
                "falling back to sequential download."
            )
            return _download_full_miss_frames_sequential(
                cache_misses,
                validated_results,
                progress,
            )
        return _download_full_miss_frames_pyodide(
            cache_misses, validated_results, run_sync, progress
        )

    if "pyodide" in sys.modules:
        return _download_full_miss_frames_sequential(
            cache_misses,
            validated_results,
            progress,
        )

    return _download_full_miss_frames_threaded(
        cache_misses, validated_results, progress
    )


def _download_full_miss_frames_pyodide(
    cache_misses: list[str],
    validated_results: OrderedDict[str, FetchMetadata],
    run_sync: Callable[[Any], Any],
    progress: DownloadProgress | None = None,
) -> dict[str, pd.DataFrame]:
    """Download full-miss dataframes in parallel using pyodide's async fetch."""
    import asyncio
    from io import BytesIO

    from pyodide.http import pyfetch

    semaphore = asyncio.Semaphore(8)

    async def _fetch_one(dataset: str) -> tuple[str, pd.DataFrame, int | None]:
        result = validated_results[dataset]
        if result.data is not None:
            if progress is not None:
                progress.update(dataset, 1, 1)
            return dataset, result.data, 1

        url = result.url
        if not url:
            raise FileNotFoundError(f"**Error: {dataset} not exists")

        async with semaphore:
            response = await pyfetch(url)
            raw = await response.bytes()
        nbytes = len(raw)
        if progress is not None:
            progress.update(dataset, nbytes, nbytes)
        df = pd.read_pickle(BytesIO(raw), compression="gzip")
        del raw
        return dataset, df, nbytes

    async def _fetch_all() -> list[tuple[str, pd.DataFrame, int | None]]:
        return await asyncio.gather(*[_fetch_one(ds) for ds in cache_misses])

    results = _run_pyodide_sync(run_sync, _fetch_all())

    downloaded_frames: dict[str, pd.DataFrame] = {}
    for dataset, df, nbytes in results:
        downloaded_frames[dataset] = df
        if progress is not None and nbytes is not None:
            progress.complete(dataset, nbytes)
    return downloaded_frames


def _persist_full_miss_frames(
    cache_misses: list[str],
    downloaded_frames: dict[str, pd.DataFrame],
    validated_results: OrderedDict[str, FetchMetadata],
    target_storage: Any,
) -> dict[str, pd.DataFrame]:
    """Persist downloaded full misses and return finalized cache hits."""
    cache_hits: dict[str, pd.DataFrame] = {}
    for dataset in cache_misses:
        df = downloaded_frames[dataset]
        if df.empty:
            raise RuntimeError(f"**Error: {dataset} download fail")
        result = validated_results[dataset]
        target_storage.set_dataframe(dataset, df, expiry=result.expiry)
        logger.debug(f"{dataset} downloaded full data from cloud")
        cache_hits[dataset] = _finalize(dataset, df)
    return cache_hits


def _fetch_many(
    datasets: list[str],
    force_download: bool,
    *,
    show_progress: bool = False,
) -> tuple[pd.DataFrame, ...]:
    """Fetch one or more datasets through shared cache and merge policy."""
    progress: DownloadProgress | None = None
    ctx, resolved, storage, force_download = _prepare_fetch(datasets, force_download)
    try:
        (
            cache_hits,
            recent_candidates,
            cache_misses,
            time_saved_map,
            local_frames,
        ) = _partition_datasets(
            resolved,
            storage,
            force_download,
            ctx.use_local_data_only,
        )

        pending = recent_candidates + cache_misses
        if show_progress and pending:
            from .progress import DownloadProgress

            progress = DownloadProgress(to_download=pending, cached=list(cache_hits))
            progress.start()

        if recent_candidates:
            if progress is not None:
                progress.set_stage("Fetching recent metadata")
            recent_hits, promoted_misses = _resolve_recent_candidates(
                recent_candidates,
                time_saved_map,
                storage,
                local_frames,
                fetch_metadata_batch,
                progress=progress,
            )
            cache_hits.update(recent_hits)
            cache_misses.extend(promoted_misses)

        if cache_misses:
            cache_hits.update(
                _materialize_full_misses(
                    cache_misses,
                    storage,
                    fetch_metadata_batch,
                    progress=progress,
                )
            )

        results: list[pd.DataFrame] = []
        for dataset in resolved:
            results.append(cache_hits[dataset])
            ctx._loaded_datasets.add(dataset)

        return tuple(results)
    finally:
        if progress is not None:
            progress.finish()


# ---------------------------------------------------------------------------
# Role helpers
# ---------------------------------------------------------------------------


def get_role() -> str | None:
    """Return the current user role (e.g. ``'free'`` or ``'vip'``)."""
    return _default_context._role


def is_vip() -> bool:
    """Return True if the current user is a VIP member."""
    role = _default_context._role
    return role is not None and role != "free"


# ---------------------------------------------------------------------------
# data.get() -- main entry point
# ---------------------------------------------------------------------------


def get(
    dataset: str,
    save_to_storage: bool = True,
    force_download: bool = False,
    lazy: bool = False,
) -> pd.DataFrame:
    """Download historical data.

    See https://ai.finlab.tw/database for the full data catalogue.

    Args:
        dataset: The name of dataset.
        save_to_storage: Whether to save the dataset to storage for later use.
        force_download: Whether to force download the dataset from cloud.
        lazy: Return a lazy computation wrapper after fetching the dataset.

    Returns:
        financial data as a DataFrame.
    """
    if not save_to_storage:
        logger.warning(
            "save_to_storage will be deprecated after 2024/06/01. "
            "Please use data.set_storage(CacheStorage()) to disable data saved to local storage"
        )
    result = _fetch_many([dataset], force_download)[0]
    return result.lazy() if lazy else result
