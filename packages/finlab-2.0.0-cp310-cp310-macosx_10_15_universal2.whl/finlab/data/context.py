"""DataContext singleton and module-level state management."""

from __future__ import annotations

import contextlib
from typing import Any

from .storage import CacheStorage, FileStorage

__all__ = [
    "_CONTEXT_ATTRS",
    "DataContext",
    "_default_context",
    "clear",
    "set_storage",
]


# ---------------------------------------------------------------------------
# DataContext — encapsulates all module-level mutable state
# ---------------------------------------------------------------------------


class DataContext:
    """Holds all mutable state that was previously scattered as module globals.

    A module-level singleton ``_default_context`` is the active context.
    Use ``override()`` to temporarily change values in a ``with`` block.
    """

    def __init__(self) -> None:
        self._has_print_free_user_warning: bool = False
        self._has_shown_quota_warning: bool = False
        self._role: str | None = None
        self.use_local_data_only: bool = False
        self.force_cloud_download: bool = False
        self.truncate_start: str | None = None
        self.truncate_end: str | None = None
        self.prefer_local_if_exists: bool = False
        self._storage: CacheStorage | FileStorage = FileStorage()
        self._finalized_cache: dict[tuple[str, int], object] = {}
        self._loaded_datasets: set[str] = set()
        self._last_token_type: str | None = None
        self._current_market: str | None = None

    @contextlib.contextmanager
    def override(self, **kwargs: Any):  # noqa: ANN201
        """Temporarily override context attributes, restoring on exit.

        Example::

            with _default_context.override(prefer_local_if_exists=True):
                ...
        """
        saved = {k: getattr(self, k) for k in kwargs}
        for k, v in kwargs.items():
            setattr(self, k, v)
        try:
            yield self
        finally:
            for k, v in saved.items():
                setattr(self, k, v)


_default_context = DataContext()

# Names that are proxied through __getattr__ / __setattr__ to the singleton.
_CONTEXT_ATTRS: frozenset[str] = frozenset(
    {
        "_has_print_free_user_warning",
        "_has_shown_quota_warning",
        "_role",
        "use_local_data_only",
        "force_cloud_download",
        "truncate_start",
        "truncate_end",
        "prefer_local_if_exists",
        "_storage",
        "_finalized_cache",
        "_loaded_datasets",
        "_last_token_type",
        "_current_market",
    }
)


def __getattr__(name: str) -> Any:
    """Module-level __getattr__ (PEP 562) — proxy context attrs to singleton.

    Needed for code that imports ``finlab.data.context`` directly.
    """
    if name in _CONTEXT_ATTRS:
        return getattr(_default_context, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def clear() -> None:
    """清除本地端儲存的歷史資料，並還原初始設定。
    Examples:
        ``` py
        from finlab import data
        data.clear()
        ```
    """
    ctx = _default_context
    ctx._loaded_datasets = set()
    if isinstance(ctx._storage, FileStorage):
        ctx._storage.clear()
    ctx._storage = FileStorage()


def set_storage(storage: CacheStorage | FileStorage) -> None:
    """設定本地端儲存歷史資料的方式
    假設使用 `data.get` 獲取歷史資料則，在預設情況下，程式會自動在本地複製一份，以避免重複下載大量數據。
    storage 就是用來儲存歷史資料的接口。我們提供兩種 `storage` 接口，分別是 `finlab.data.CacheStorage` (預設) 以及
    `finlab.data.FileStorage`。前者是直接存在記憶體中，後者是存在檔案中。詳情請參考 `CacheStorage` 和 `FileStorage` 來獲得更詳細的資訊。
    在預設情況下，程式會自動使用 `finlab.data.FileStorage` 並將重複索取之歷史資料存在作業系統預設「暫時資料夾」。

    Args:
        storage (data.Storage): The interface of storage

    Examples:
        欲切換成以檔案方式儲存，可以用以下之方式：

        ``` py
        from finlab import data
        data.set_storage(data.FileStorage())
        close = data.get('price:收盤價')
        ```

        可以在本地端的 `./finlab_db/price#收盤價.pickle` 中，看到下載的資料，
        可以使用 `pickle` 調閱歷史資料：
        ``` py
        import pickle
        close = pickle.load(open('finlab_db/price#收盤價.pickle', 'rb'))
        ```
    """

    _default_context._storage = storage
