"""Data freshness: ``is_tradable()``, ``next_future_expiry()``, ``suggested_tradable_time()``."""

from __future__ import annotations

import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from finlab.market import Market

from .context import _default_context
from .storage import CacheStorage, FileStorage

__all__ = [
    "is_tradable",
    "next_future_expiry",
    "suggested_tradable_time",
]


# ---------------------------------------------------------------------------
# Expiry dict
# ---------------------------------------------------------------------------


def _get_expiry_dict() -> dict[str, datetime.datetime]:
    """Get the expiry dict from current storage.

    When datasets have been loaded via get(), only return expiry entries
    for those datasets so that unrelated cached data doesn't affect
    suggested_tradable_time() / is_tradable().
    """
    ctx = _default_context
    storage = ctx._storage
    if isinstance(storage, FileStorage):
        expiry = storage._expiry
    elif isinstance(storage, CacheStorage):
        expiry = storage._cache_expiry
    else:
        return {}

    if not ctx._loaded_datasets:
        return {}

    return {k: v for k, v in expiry.items() if k in ctx._loaded_datasets}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def next_future_expiry() -> datetime.datetime | None:
    """Next future expiry time among cached datasets (UTC).

    Returns only expiry times in the future, skipping already expired data.

    Returns:
        datetime in UTC representing the next future expiry, or None if
        no future expiries exist or no data is available.
    """
    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return None

    now = datetime.datetime.now(tz=datetime.timezone.utc)

    future_expiries = [
        expiry for expiry in expiry_dict.values() if expiry is not None and expiry > now
    ]

    if not future_expiries:
        return None

    return min(future_expiries)


def suggested_tradable_time(market: Market | None = None) -> datetime.datetime | None:
    """Estimate when is_tradable() will become True.

    If already tradable, returns None.
    Otherwise:
      1. If any loaded dataset is already expired, returns latest expired
         expiry + buffer.
      2. Else (typically before today's market open), returns latest expiry
         that is still before today's open, plus buffer.

    Args:
        market: A Market instance. If None, defaults to TWMarket.

    Returns:
        datetime in UTC, or None if already tradable or no data.
    """
    from finlab.markets.tw import TWMarket

    if market is None:
        market = TWMarket()

    if is_tradable(market):
        return None

    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return None

    now = datetime.datetime.now(tz=datetime.timezone.utc)
    expired_expiries = [
        expiry
        for expiry in expiry_dict.values()
        if expiry is not None and expiry <= now
    ]

    # If data is already stale, suggest based on the latest stale expiry first.
    if expired_expiries:
        return max(expired_expiries) + datetime.timedelta(minutes=15)

    tz = market.tzinfo() or datetime.timezone(datetime.timedelta(hours=8))
    open_hour, open_minute = market.market_open_time()

    now_local = now.astimezone(tz)
    today_open_local = now_local.replace(
        hour=open_hour, minute=open_minute, second=0, microsecond=0
    )
    today_open_utc = today_open_local.astimezone(datetime.timezone.utc)

    latest_blocking_expiry = None
    for expiry in expiry_dict.values():
        if expiry is None:
            continue
        if expiry <= today_open_utc and (
            latest_blocking_expiry is None or expiry > latest_blocking_expiry
        ):
            latest_blocking_expiry = expiry

    if latest_blocking_expiry is None:
        return None

    return latest_blocking_expiry + datetime.timedelta(minutes=15)


def is_tradable(market: Market | None = None) -> bool:
    """Check if cached data is safe for trading.

    True when:
      1. All data not expired (now < expiry for all datasets)
      2. Before market open only: no more crawl updates before today's open
         (expiry > today's market open time)

    Args:
        market: A Market instance (TWMarket/USMarket). If None, defaults to TWMarket.

    Returns:
        True if data is fresh enough for trading.
    """
    from finlab.markets.tw import TWMarket

    if market is None:
        market = TWMarket()

    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return False

    now = datetime.datetime.now(tz=datetime.timezone.utc)

    tz = market.tzinfo() or datetime.timezone(datetime.timedelta(hours=8))
    open_hour, open_minute = market.market_open_time()

    now_local = now.astimezone(tz)
    today_open_local = now_local.replace(
        hour=open_hour, minute=open_minute, second=0, microsecond=0
    )
    today_open_utc = today_open_local.astimezone(datetime.timezone.utc)
    market_opened_today = now_local >= today_open_local

    for expiry in expiry_dict.values():
        if expiry is None:
            continue
        if now >= expiry:
            return False
        # If market has not opened yet, ensure there won't be more updates
        # before today's open.
        if (not market_opened_today) and expiry <= today_open_utc:
            return False

    return True
