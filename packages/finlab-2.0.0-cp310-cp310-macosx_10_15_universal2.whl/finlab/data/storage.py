from __future__ import annotations

import datetime
import gzip
import logging
import os
import pickle
import shutil
import sys
import tempfile
import threading

__all__ = ["CacheStorage", "FileStorage"]
from contextlib import contextmanager
from typing import IO, TYPE_CHECKING, Any, ClassVar

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

import pandas as pd
import requests

import finlab.utils

logger = logging.getLogger(__name__)

try:
    import fcntl
except ImportError:
    fcntl = None

try:
    import msvcrt
except ImportError:
    msvcrt = None


class CacheStorage:
    def __init__(self) -> None:
        """將歷史資料儲存於快取中

        Examples:
            欲切換成以檔案方式儲存，可以用以下之方式：

            ``` py
            from finlab import data
            data.set_storage(data.CacheStorage())
            close = data.get('price:收盤價')
            ```

            可以直接調閱快取資料：

            ``` py
            close = data._storage._cache['price:收盤價']
            ```
        """

        self._cache: dict[str, pd.DataFrame] = {}
        self._cache_time: dict[str, datetime.datetime] = {}
        self._cache_expiry: dict[str, datetime.datetime] = {}

    @staticmethod
    def now() -> datetime.datetime:
        return datetime.datetime.now(tz=datetime.timezone.utc)

    def set_dataframe(
        self, name: str, df: pd.DataFrame, expiry: datetime.datetime | None = None
    ) -> None:
        self._cache[name] = df
        self._cache_time[name] = self.now()
        self._cache_expiry[name] = expiry or self.now()

    def get_time_created(self, name: str) -> datetime.datetime | None:
        if name not in self._cache or name not in self._cache_time:
            return None

        return self._cache_time[name]

    def get_time_expired(self, name: str) -> datetime.datetime | None:
        if name in self._cache_expiry:
            return self._cache_expiry[name]

        return None

    def set_time_expired(self, name: str, expiry: datetime.datetime) -> None:
        self._cache_expiry[name] = expiry

    def get_dataframe(self, name: str) -> pd.DataFrame | None:
        # not exists
        if name not in self._cache or name not in self._cache_time:
            return None

        return self._cache[name]


class FileStorage:
    _last_reset_check_time: ClassVar[datetime.datetime | None] = (
        None  # UTC datetime of last check (shared across instances)
    )

    def __init__(self, path: str | None = None, use_cache: bool = True) -> None:
        """將歷史資料儲存於檔案中

        Args:
              path (str): 資料儲存的路徑
              use_cache (bool): 是否額外使用快取，將資料複製一份到記憶體中。

        Examples:
            欲切換成以檔案方式儲存，可以用以下之方式：

            ``` py
            from finlab import data
            data.set_storage(data.FileStorage())
            close = data.get('price:收盤價')
            ```

            可以在本地端的 `./finlab_db/price#收盤價.pickle` 中，看到下載的資料，
            可以使用 `pickle` 調閱歷史資料：
            ``` py
            import pickle
            close = pickle.load(open('finlab_db/price#收盤價.pickle', 'rb'))
            ```
        """
        if path is None:
            path = finlab.utils.get_tmp_dir()

        self._path: str = path
        self._cache: dict[str, pd.DataFrame] = {}
        self._expiry: dict[str, datetime.datetime] = {}
        self.use_cache: bool = use_cache
        self._created: dict[str, datetime.datetime] = {}
        self._save_expiry_lock: threading.RLock = threading.RLock()
        self._reset_thread: threading.Thread | None = None

        if not os.path.isdir(path):
            os.mkdir(path)

        f_expiry = os.path.join(self._path, "expiry.pkl")
        self._expiry_loaded_time: datetime.datetime = datetime.datetime.fromtimestamp(
            0, tz=datetime.timezone.utc
        )

        if os.path.isfile(f_expiry):
            with open(f_expiry, "rb") as f:
                try:
                    self._expiry = pickle.load(f)
                    self._expiry_loaded_time = datetime.datetime.fromtimestamp(
                        os.path.getmtime(f_expiry), tz=datetime.timezone.utc
                    )
                except (
                    pickle.UnpicklingError,
                    EOFError,
                    AttributeError,
                    ModuleNotFoundError,
                ):
                    self._expiry = {}

        if self._expiry:
            now = CacheStorage.now()
            if (
                FileStorage._last_reset_check_time is None
                or (now - FileStorage._last_reset_check_time).total_seconds() > 900
            ):
                FileStorage._last_reset_check_time = now
                if "pyodide" in sys.modules:
                    self._check_and_apply_reset_time()
                else:
                    self._reset_thread = threading.Thread(
                        target=self._check_and_apply_reset_time, daemon=True
                    )
                    self._reset_thread.start()

    @staticmethod
    def _lock_path(file_path: str) -> str:
        return file_path + ".lock"

    @staticmethod
    def _acquire_lock(lock_file: IO[bytes], exclusive: bool) -> None:
        if fcntl is not None:
            mode = fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH
            fcntl.flock(lock_file.fileno(), mode)
            return
        if msvcrt is not None:
            # Lock 1 byte for coarse cross-process synchronization.
            mode = msvcrt.LK_LOCK if exclusive else msvcrt.LK_RLCK
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), mode, 1)
            return

    @staticmethod
    def _release_lock(lock_file: IO[bytes]) -> None:
        if fcntl is not None:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
            return
        if msvcrt is not None:
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
            return

    @contextmanager
    def _file_lock(
        self, target_file_path: str, exclusive: bool
    ) -> Generator[None, None, None]:
        lock_path = self._lock_path(target_file_path)
        with open(lock_path, "a+b") as lock_file:
            self._acquire_lock(lock_file, exclusive=exclusive)
            try:
                yield
            finally:
                self._release_lock(lock_file)

    def _atomic_pickle_write(
        self, file_path: str, write_fn: Callable[[str], Any]
    ) -> None:
        tmp_path = None
        with self._file_lock(file_path, exclusive=True):
            try:
                fd, tmp_path = tempfile.mkstemp(
                    prefix=os.path.basename(file_path) + ".",
                    suffix=".tmp",
                    dir=self._path,
                )
                os.close(fd)
                write_fn(tmp_path)
                os.replace(tmp_path, file_path)
            finally:
                if tmp_path and os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except OSError:
                        logger.warning(
                            f"failed to remove tmp file: {tmp_path}", exc_info=True
                        )

    def _read_pickle_with_shared_lock(
        self, file_path: str
    ) -> tuple[Any, datetime.datetime | None]:
        with self._file_lock(file_path, exclusive=False):
            if not os.path.isfile(file_path):
                return None, None
            with open(file_path, "rb") as f:
                header = f.read(2)
                f.seek(0)
                if header == b"\x1f\x8b":
                    ret = pickle.load(gzip.GzipFile(fileobj=f))
                else:
                    ret = pd.read_pickle(f)
            mtime = datetime.datetime.fromtimestamp(
                os.path.getmtime(file_path), tz=datetime.timezone.utc
            )
            return ret, mtime

    def _is_reset_already_applied(self, raw_text: str) -> bool:
        """Check if this reset was already applied to the current expiry.pkl."""
        marker_path = os.path.join(self._path, "_reset_data_time.txt")
        expiry_path = os.path.join(self._path, "expiry.pkl")
        try:
            if not os.path.isfile(marker_path):
                return False
            with open(marker_path) as f:
                lines = f.read().strip().split("\n")
            if len(lines) != 2 or lines[0] != raw_text:
                return False
            current_mtime = (
                os.path.getmtime(expiry_path) if os.path.isfile(expiry_path) else 0
            )
            return float(lines[1]) == current_mtime
        except (OSError, ValueError):
            return False

    def _save_last_reset_data_time(self, raw_text: str) -> None:
        """Record reset timestamp and current expiry.pkl mtime."""
        marker_path = os.path.join(self._path, "_reset_data_time.txt")
        expiry_path = os.path.join(self._path, "expiry.pkl")
        try:
            mtime = os.path.getmtime(expiry_path) if os.path.isfile(expiry_path) else 0
            with open(marker_path, "w") as f:
                f.write(f"{raw_text}\n{mtime}")
        except OSError:
            pass  # best-effort marker; failure does not affect correctness

    def _check_and_apply_reset_time(self) -> None:
        try:
            res = finlab.utils.requests.get(
                "https://asia-east1-fdata-299302.cloudfunctions.net/data_reset_time",
                timeout=300,
            )

            if self._is_reset_already_applied(res.text):
                return

            reset_data_time = datetime.datetime.fromtimestamp(
                float(res.text), tz=datetime.timezone.utc
            )
            with self._save_expiry_lock:
                for k, _ in list(self._expiry.items()):
                    created = self.get_time_created(k)
                    if created and created < reset_data_time:
                        logger.info(
                            f" set {k} time expired since the system reset time: {reset_data_time} > created time: {created}"
                        )
                        self.set_time_expired(k, reset_data_time, save=False)
                if self.save_expiry():
                    self._save_last_reset_data_time(res.text)
        except (requests.RequestException, OSError, ValueError) as e:
            logger.warning("Failed to check data reset time: %s", e)

    def _reload_expiry_if_modified(self) -> None:
        """Reload expiry data from disk if the file has been modified by another process."""
        expiry_file = os.path.join(self._path, "expiry.pkl")
        if not os.path.isfile(expiry_file):
            return

        file_mtime = datetime.datetime.fromtimestamp(
            os.path.getmtime(expiry_file), tz=datetime.timezone.utc
        )

        if file_mtime > self._expiry_loaded_time:
            with self._save_expiry_lock:
                # Double-check after acquiring lock
                file_mtime = datetime.datetime.fromtimestamp(
                    os.path.getmtime(expiry_file), tz=datetime.timezone.utc
                )
                if file_mtime > self._expiry_loaded_time:
                    with (
                        self._file_lock(expiry_file, exclusive=False),
                        open(expiry_file, "rb") as f,
                    ):
                        self._expiry = pickle.load(f)
                    self._expiry_loaded_time = file_mtime
                    logger.debug(
                        "Reloaded expiry data from disk (modified by another process)"
                    )

    def set_dataframe(
        self, name: str, df: pd.DataFrame, expiry: datetime.datetime | None = None
    ) -> None:
        file_path = os.path.join(self._path, name.replace(":", "#") + ".pickle")
        try:
            self._atomic_pickle_write(file_path, df.to_pickle)
        except OSError as e:
            error_msg = f"{name} save dataframe fail. Path: {file_path}. Error: {e}"
            logger.warning(error_msg)
            print(f"Warning: {error_msg}")
            print(
                "Please check disk permission, available space, or filename encoding issues."
            )
            return

        # Verify the file was actually created
        if not os.path.isfile(file_path):
            error_msg = f"{name} save dataframe fail - file not created at {file_path}"
            logger.warning(error_msg)
            print(f"Warning: {error_msg}")
            return

        if self.use_cache:
            self._cache[name] = df

        self._expiry[name] = expiry or CacheStorage.now()
        self._created[name] = CacheStorage.now()
        self.save_expiry()

    def get_time_created(self, name: str) -> datetime.datetime | None:
        if name in self._created:
            return self._created[name]

        # check existence
        file_path = os.path.join(self._path, name.replace(":", "#") + ".pickle")

        if not os.path.isfile(file_path):
            return None

        return datetime.datetime.fromtimestamp(
            os.path.getmtime(file_path), tz=datetime.timezone.utc
        )

    def get_time_expired(self, name: str) -> datetime.datetime | None:
        # Reload expiry from disk if it's been modified by another process
        self._reload_expiry_if_modified()

        if name in self._expiry:
            return self._expiry[name]

        return None

    def set_time_expired(
        self, name: str, expiry: datetime.datetime, save: bool = True
    ) -> None:
        self._expiry[name] = expiry
        if save:
            self.save_expiry()

    def save_expiry(self) -> bool:
        expiry_file = os.path.join(self._path, "expiry.pkl")
        with self._save_expiry_lock:
            try:

                def write_expiry(tmp_path: str) -> None:
                    with open(tmp_path, "wb") as f:
                        pickle.dump(self._expiry, f)

                self._atomic_pickle_write(expiry_file, write_expiry)
                self._expiry_loaded_time = CacheStorage.now()
                return True
            except (OSError, pickle.PicklingError) as e:
                logger.warning(f"save expiry fail: {e}")
                return False

    def get_dataframe(self, name: str) -> pd.DataFrame | None:
        file_path = os.path.join(self._path, name.replace(":", "#") + ".pickle")

        # If we have a cached version, check if the file on disk is newer
        if name in self._cache:
            # Check if file exists on disk
            if not os.path.isfile(file_path):
                return None
            file_mtime = datetime.datetime.fromtimestamp(
                os.path.getmtime(file_path), tz=datetime.timezone.utc
            )
            cached_time = self._created.get(name)

            # If file was modified after we cached it, invalidate cache
            if cached_time and file_mtime > cached_time:
                logger.debug(
                    f"{name} file on disk is newer than cache, reloading from disk"
                )
                del self._cache[name]
            else:
                # Cache is still valid
                return self._cache[name]

        # Load from disk under shared lock to avoid partially-read pickle during writes.
        ret, file_mtime = self._read_pickle_with_shared_lock(file_path)
        if ret is None:
            return None
        if self.use_cache:
            self._cache[name] = ret
            self._created[name] = file_mtime
        return ret

    def clear(self) -> None:
        folder_path = self._path
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except OSError as e:
                print(f"Failed to delete {file_path}. Reason: {e}")

    def diagnose(self, dataset: str | None = None) -> None:
        """診斷本地儲存狀態

        Args:
            dataset (str, optional): 指定要檢查的資料集名稱，例如 'price:收盤價'。如果不指定，則列出所有本地資料。

        Examples:
            ``` py
            from finlab import data
            data._storage.diagnose()  # 列出所有本地資料
            data._storage.diagnose('price:收盤價')  # 檢查特定資料集
            ```
        """
        print(f"Storage path: {self._path}")
        print(f"Path exists: {os.path.isdir(self._path)}")

        if dataset:
            file_name = dataset.replace(":", "#") + ".pickle"
            file_path = os.path.join(self._path, file_name)
            print(f"\nDataset: {dataset}")
            print(f"Expected file: {file_path}")
            print(f"File exists: {os.path.isfile(file_path)}")
            if os.path.isfile(file_path):
                size_mb = os.path.getsize(file_path) / (1024 * 1024)
                mtime = datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
                print(f"File size: {size_mb:.2f} MB")
                print(f"Last modified: {mtime}")
            if dataset in self._expiry:
                print(f"Expiry time: {self._expiry[dataset]}")
            else:
                print("Expiry time: Not set")
            if dataset in self._cache:
                print(f"In memory cache: Yes ({len(self._cache[dataset])} rows)")
            else:
                print("In memory cache: No")
        else:
            print("\nLocal data files:")
            pickle_files = [
                f
                for f in os.listdir(self._path)
                if f.endswith(".pickle") and f != "expiry.pkl"
            ]
            if not pickle_files:
                print("  (No data files found)")
            for f in sorted(pickle_files)[:20]:  # Show first 20 files
                file_path = os.path.join(self._path, f)
                size_mb = os.path.getsize(file_path) / (1024 * 1024)
                dataset_name = f.replace("#", ":").replace(".pickle", "")
                print(f"  {dataset_name}: {size_mb:.2f} MB")
            if len(pickle_files) > 20:
                print(f"  ... and {len(pickle_files) - 20} more files")
            print(f"\nTotal: {len(pickle_files)} data files")
