"""Shared constants, type aliases, and colour utilities for the plot package."""

from __future__ import annotations

import itertools
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Final, TypeAlias

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

if TYPE_CHECKING:
    from collections.abc import Generator, Sequence

__all__ = [
    "IndicatorSpec",
    "average",
    "color_generator",
    "df_date_filter",
]

# A single indicator: DataFrame, Series, ndarray, column name, or a callable returning one of those.
IndicatorSpec: TypeAlias = (
    pd.DataFrame
    | pd.Series
    | np.ndarray
    | str
    | Callable[[pd.DataFrame], pd.DataFrame | pd.Series | np.ndarray]
)

_PLOTLY_PALETTE: Final[list[str]] = px.colors.qualitative.Plotly
_YI: Final[int] = 100_000_000  # 億


def _convert_color(c: str) -> str:
    """Map simple colour names to Plotly palette; pass through others."""
    mapping = {
        "blue": _PLOTLY_PALETTE[0],
        "red": _PLOTLY_PALETTE[1],
        "green": _PLOTLY_PALETTE[2],
        "purple": _PLOTLY_PALETTE[3],
        "orange": _PLOTLY_PALETTE[4],
        "yellow": _PLOTLY_PALETTE[4],
        "cyan": _PLOTLY_PALETTE[5],
        "pink": _PLOTLY_PALETTE[6],
        "brown": _PLOTLY_PALETTE[7],
        "grey": "lightgray",
        "gray": "lightgray",
    }
    return mapping.get(str(c).lower(), c)


def _add_last_point_marker(
    fig: go.Figure, x: pd.Timestamp, y: float, colour: str
) -> None:
    fig.add_trace(
        go.Scatter(
            x=[x],
            y=[y],
            mode="markers",
            marker={"size": 16, "color": colour, "line": {"width": 0}},
            hoverinfo="skip",
            showlegend=False,
        ),
    )
    fig.add_annotation(
        x=x,
        y=y,
        text=f"{y:.2f}",
        showarrow=False,
        xshift=10,
        font={"size": 16, "color": colour},
        xanchor="left",
        yanchor="middle",
    )


def _in_range(val: float, lower: float | None, upper: float | None) -> bool:
    """Return True if lower <= val <= upper with None = -/+inf."""
    if lower is None:
        lower = float("-inf")
    if upper is None:
        upper = float("inf")
    return lower <= val <= upper


def _resolve_color(
    x: float,
    y: float,
    default_color: str,
    h_line_ranges: list[Sequence[Any]],
    v_line_ranges: list[Sequence[Any]],
) -> str:
    """
    Decide colour for point (x,y). Later ranges override earlier ones.
    Accept formats:
        [lower, upper, color]      # full
        [threshold, color]         # lower bound only
    """
    colour = default_color

    # horizontal (y) ranges
    for rng in h_line_ranges:
        if len(rng) == 3:
            lo, hi, clr = rng
        elif len(rng) == 2:
            lo, clr = rng
            hi = None
        else:
            continue  # skip malformed
        if _in_range(y, lo, hi):
            colour = _convert_color(clr)
    # vertical (x) ranges
    for rng in v_line_ranges:
        if len(rng) == 3:
            lo, hi, clr = rng
        elif len(rng) == 2:
            lo, clr = rng
            hi = None
        else:
            continue
        if _in_range(x, lo, hi):
            colour = _convert_color(clr)
    return colour


def df_date_filter(
    df: pd.DataFrame, start: str | None = None, end: str | None = None
) -> pd.DataFrame:
    if start:
        df = df[df.index >= start]
    if end:
        df = df[df.index <= end]
    return df


def color_generator() -> Generator[str]:
    yield from itertools.cycle(px.colors.qualitative.Plotly)


def average(series: pd.Series, n: int) -> pd.Series:
    return series.rolling(n, min_periods=int(n / 2)).mean()
