"""Strategy comparison and return statistics chart classes."""

from __future__ import annotations

import operator
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from finlab import data
from finlab.compat import resolve_id_column

__all__ = [
    "StrategyReturnStats",
    "StrategySunburst",
]


class StrategySunburst:
    def __init__(self) -> None:
        """繪製策略部位旭日圖

        監控多策略。
        """
        d = data.get_strategies()
        for k, v in d.items():
            if "position" in v["positions"]:
                d[k]["positions"] = v["positions"]["position"]
        self.s_data: dict[str, Any] = d

    def process_position(self, s_name: str, s_weight: float = 1) -> pd.DataFrame:
        if s_name == "現金":
            result = pd.DataFrame(
                {"return": 0, "weight": 1, "category": "現金", "market": "現金"},
                index=["現金"],
            )
            result.index.name = "symbol"
        else:
            df = pd.DataFrame(self.s_data[s_name]["positions"])
            df = df[[c for c in df.columns if " " in c]]
            df = df.T
            df["weight"] = df["weight"].apply(
                lambda s: abs(pd.to_numeric(s, errors="coerce"))
            )
            df = df[df["weight"] > 0]
            if len(df) == 0:
                df["weight"] = 0
            df.index.name = "symbol"
            old_security_categories = data.get("security_categories").reset_index()
            security_categories = old_security_categories.copy()
            security_categories["category"] = security_categories["category"].fillna(
                "other_securities"
            )
            _id_col = resolve_id_column(security_categories)
            security_categories[_id_col] = (
                security_categories[_id_col] + " " + security_categories["name"]
            )
            security_categories = security_categories.set_index([_id_col])
            result = df.join(security_categories)

            asset_type = self.s_data[s_name]["asset_type"]
            if asset_type == "":
                asset_type = "tw_stock"
            elif asset_type == "crypto":
                category = "crypto"
                result["category"] = category

            result["market"] = asset_type
            cash = pd.DataFrame(
                {
                    "return": 0,
                    "weight": 1 - (df["weight"].sum()),
                    "category": "現金",
                    "market": "現金",
                },
                index=["現金"],
            )
            cash.index.name = "symbol"
            result = pd.concat([result, cash])

        result["s_name"] = s_name
        result["s_weight"] = s_weight
        return result

    def get_strategy_df(
        self, select_strategy: dict[str, float] | None = None
    ) -> pd.DataFrame | None:
        """獲取策略部位與分配權重後計算的資料

        Args:
          select_strategy (dict): 選擇策略名稱並設定權重，預設是抓取權策略並平分資金比例到各策略。
                                 ex:`{'低波動本益成長比':0.5,'研發魔人':0.2, '現金':0.2}`
        Returns:
            (pd.DataFrame): strategies data
        """
        if select_strategy is None:
            s_name = self.s_data.keys()
            s_num = len(s_name)
            if s_num == 0:
                return None
            s_weight = [1 / s_num] * len(s_name)
        else:
            s_name = select_strategy.keys()
            s_weight = select_strategy.values()

        all_position = pd.concat(
            [
                self.process_position(name, weight)
                for name, weight in zip(s_name, s_weight, strict=True)
            ]
        )
        all_position["weight"] *= all_position["s_weight"]
        all_position["return"] = round(all_position["return"].astype(float), 2)
        all_position["color"] = round(
            all_position["return"].clip(
                all_position["return"].min() / 2, all_position["return"].max() / 2
            ),
            2,
        )
        all_position = all_position[all_position["weight"] > 0]
        all_position = all_position.reset_index()
        all_position = all_position[all_position["s_name"] != "playground"]
        all_position["category"] = all_position["category"].fillna("other_securities")
        return all_position

    def plot(
        self,
        select_strategy: dict[str, float] | None = None,
        path: list[str] | None = None,
        color_continuous_scale: str = "RdBu_r",
    ) -> go.Figure | None:
        """繪圖

        Args:
          select_strategy (dict): 選擇策略名稱並設定權重，預設是抓取權策略並平分資金比例到各策略。
                                 ex:`{'低波動本益成長比':0.5,'研發魔人':0.2, '現金':0.2}`
          path (list): 旭日圖由裡到外的顯示路徑，預設為`['s_name', 'market', 'category', 'stock_id']`。
                       `['market', 'category','stock_id','s_name']`也是常用選項。
          color_continuous_scale (str):[顏色變化序列的樣式名稱](https://plotly.com/python/builtin-colorscales/)

        Returns:
            (plotly.graph_objects.Figure): 策略部位旭日圖
        Examples:
            ```py
            from finlab.plot import StrategySunburst

            # 實例化物件
            strategies = StrategySunburst()
            strategies.plot().show()
            strategies.plot(select_strategy={'高殖利率烏龜':0.4,'營收強勢動能瘋狗':0.25,'低波動本益成長比':0.2,'現金':0.15},path =  ['market', 'category','stock_id','s_name']).show()
            ```
        ex1:策略選到哪些標的?
        ![市值/本益比板塊圖](img/plot/sunburst1.png)

        ex2:部位被哪些策略選到，標的若被不同策略選到，可能有獨特之處喔！
        ![市值/本益比板塊圖](img/plot/sunburst2.png)
        """
        position = self.get_strategy_df(select_strategy)
        if position is None:
            return None
        position = position[
            (position["return"] != np.inf) | (position["weight"] != np.inf)
        ]
        if path is None:
            path = ["s_name", "market", "category", "stock_id"]
        return px.sunburst(
            position,
            path=path,
            values="weight",
            color="color",
            hover_data=["return"],
            color_continuous_scale=color_continuous_scale,
            color_continuous_midpoint=0,
            width=1000,
            height=800,
        )


class StrategyReturnStats:
    def __init__(
        self,
        start_date: str,
        end_date: str,
        strategy_names: list[str] | None = None,
        benchmark_return: pd.Series | None = None,
    ) -> None:
        """繪製策略報酬率統計比較圖

        監控策略群體相對對標指數的表現。

        Args:
            start_date (str): 報酬率計算開始日
            end_date (str): 報酬率計算結束日
            strategy_names (list): 用戶本人的策略集設定，填入欲納入統計的策略名稱，只限定自己的策略。ex:`['膽小貓','三頻率RSI策略', '二次創高股票',...]`，預設為全部已上傳的策略。
            benchmark_return (pandas.Series): 策略比對基準序列，預設為台股加權報酬指數。


        Examples:

            統計2022-12-31~2023-07-31的報酬率數據
            ``` py
            # 回測起始時間
            start_date = '2022-12-31'
            end_date  = '2023-07-31'

            # 選定策略範圍
            strategy_names = ['膽小貓','三頻率RSI策略', '二次創高股票', '低波動本益成長比', '合約負債建築工', '多產業價投', '小蝦米跟大鯨魚', '小資族資優生策略', '本益成長比', '營收股價雙渦輪', '現金流價值成長', '研發魔人', '股價淨值比策略', '藏獒', '高殖利率烏龜','監獄兔', '財報指標20大']

            report = StrategyReturnStats(start_date ,end_date, strategy_names)
            # 繪製策略報酬率近期報酬率長條圖
            report.plot_strategy_last_return().show()
            # 繪製策略累積報酬率時間序列
            report.plot_strategy_creturn().show()
            ```

        """
        # 回測起始時間
        self.start_date: str = start_date
        self.end_date: str = end_date

        # 選定策略範圍
        self.s_data: dict[str, Any] = data.get_strategies()
        self.strategy_names: list[str] = (
            strategy_names if strategy_names is not None else []
        )
        self.benchmark_return: pd.Series = (
            data.get("benchmark_return:發行量加權股價報酬指數")[
                "發行量加權股價報酬指數"
            ]
            if benchmark_return is None
            else benchmark_return
        )
        self.returns_set: dict[str, float] = self._get_returns_set()

    def _get_returns_set(self) -> dict[str, float]:
        """計算報酬率數據
        Returns:
            (dict): 報酬率數據，ex: `{'膽小貓': -5.98,'股價淨值比策略': -1.68,...}`
        """
        returns_set: dict[str, float] = {}
        strategy_names = (
            self.s_data.keys() if not self.strategy_names else self.strategy_names
        )
        for s_name in strategy_names:
            try:
                s_df = self.s_data[s_name]
                returns = pd.Series(
                    s_df["returns"]["value"], index=s_df["returns"]["time"]
                )
                if self.start_date:
                    returns = returns[returns.index >= self.start_date]
                if self.end_date:
                    returns = returns[returns.index <= self.end_date]
                return_value = round(
                    ((returns.iloc[-1] / returns.iloc[0]) - 1) * 100, 2
                )
                returns_set[s_name] = return_value
            except (KeyError, IndexError, ZeroDivisionError):
                pass

        return dict(sorted(returns_set.items(), key=operator.itemgetter(1)))

    def get_benchmark_return(self) -> pd.Series:
        """設定對標指數
        Returns:
            (pandas.Series): 對標指數時間序列
        """
        benchmark_return = self.benchmark_return
        return benchmark_return[
            (benchmark_return.index >= self.start_date)
            & (benchmark_return.index <= self.end_date)
        ]

    def plot_strategy_last_return(self) -> go.Figure:
        """繪製策略報酬率近期報酬率長條圖
        Returns:
            (plotly.graph_objects.Figure): 圖表物件
        ![繪製策略報酬率近期報酬率長條圖](img/plot/finlab_strategy_performance.png)
        """
        returns_set = self.returns_set
        benchmark_return = self.get_benchmark_return()
        benchmark_last_return = round(
            ((benchmark_return.iloc[-1] / benchmark_return.iloc[0]) - 1) * 100, 2
        )

        fig = go.Figure(
            go.Bar(
                x=list(returns_set.values()),
                y=list(returns_set.keys()),
                marker={
                    "color": "rgba(50, 171, 96, 0.6)",
                    "line": {"color": "rgba(50, 171, 96, 1)", "width": 3},
                },
                orientation="h",
            )
        )

        fig.add_vline(
            x=benchmark_last_return,
            line_width=3,
            line_dash="dash",
            line_color="#4a6dce",
            annotation_text=f"benchmark:{benchmark_last_return}",
            annotation_position="top left",
        )

        if returns_set:
            returns_mean = round(sum(returns_set.values()) / len(returns_set), 2)
        else:
            returns_mean = 0

        fig.add_vline(
            x=returns_mean,
            line_width=3,
            line_dash="dash",
            line_color="#aa00ff",
            annotation_font_color="#aa00ff",
            annotation_text=f"strategy_mean:{returns_mean}",
            annotation_position="bottom right",
        )

        fig.update_layout(
            title=f"FinLab Strategy Performance ({self.start_date}~{self.end_date})",
            legend={"x": 0.029, "y": 1.038, "font_size": 12},
            margin={"l": 100, "r": 20, "t": 70, "b": 70},
            paper_bgcolor="rgb(248, 248, 255)",
            plot_bgcolor="rgb(248, 248, 255)",
            xaxis_title="return(%)",
        )

        return fig

    def plot_strategy_creturn(self) -> go.Figure:
        """繪製策略累積報酬率時間序列
        Returns:
            (plotly.graph_objects.Figure): 圖表物件
        ![繪製策略累積報酬率時間序列](img/plot/finlab_strategy_creturn.png)
        """

        returns_set = self.returns_set
        benchmark_return = self.get_benchmark_return()

        sorted_s_names = list(returns_set.keys())[::-1]

        returns_set2: dict[str, pd.Series] = {}
        for s_name in sorted_s_names:
            s_df = self.s_data[s_name]
            returns = pd.Series(s_df["returns"]["value"], index=s_df["returns"]["time"])
            if self.start_date:
                returns = returns[returns.index >= self.start_date]
            if self.end_date:
                returns = returns[returns.index <= self.end_date]
            returns_set2[s_name] = round(((returns / returns.iloc[0]) - 1) * 100, 2)

        returns_df = pd.DataFrame(returns_set2).unstack().to_frame().reset_index()
        returns_df.columns = ["strategy", "date", "creturns"]
        benchmark_creturn = round(
            ((benchmark_return / benchmark_return.iloc[0]) - 1) * 100, 2
        )

        fig = px.line(returns_df, x="date", y="creturns", color="strategy")
        fig.add_trace(
            go.Scatter(
                x=benchmark_creturn.index,
                y=benchmark_creturn.values,
                fill="tonexty",
                name="benchmark",
                opacity=0.2,
                marker={
                    "color": "LightSkyBlue",
                    "opacity": 0.2,
                    "size": 20,
                    "line": {"color": "MediumPurple", "width": 2},
                },
            )
        )

        fig.update_layout(
            title=f"FinLab Strategy Creturn ({self.start_date}~{self.end_date})",
            margin={"l": 100, "r": 20, "t": 70, "b": 70},
            paper_bgcolor="rgb(248, 248, 255)",
            plot_bgcolor="rgb(248, 248, 255)",
            yaxis_title="creturn (%)",
        )

        fig.update_layout(
            yaxis_range=(
                returns_df["creturns"].min() - 0.1,
                returns_df["creturns"].max() + 0.1,
            )
        )

        return fig
