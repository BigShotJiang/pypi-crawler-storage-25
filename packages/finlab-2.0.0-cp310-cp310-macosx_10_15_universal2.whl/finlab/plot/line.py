"""Line chart functions."""

from __future__ import annotations

import itertools
from typing import TYPE_CHECKING, Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from finlab.plot._core import (
    _PLOTLY_PALETTE,
    _add_last_point_marker,
    _convert_color,
    _resolve_color,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

__all__ = [
    "plot_line",
    "plot_line_example",
    "plot_line_financial_example",
]


def _build_color_segments(
    series: pd.Series,
    default_color: str,
    h_line_color_ranges: Sequence[Sequence[Any]],
    v_line_color_ranges: Sequence[Sequence[Any]],
) -> list[tuple[list[Any], list[Any], str]]:
    """Split a series into contiguous segments by resolved line color."""
    segments: list[tuple[list[Any], list[Any], str]] = []
    cur_xs: list[Any] = []
    cur_ys: list[Any] = []
    cur_col: str | None = None

    for i, (x, y) in enumerate(series.items()):
        new_col = _resolve_color(
            x, y, default_color, h_line_color_ranges, v_line_color_ranges
        )
        if cur_col is None:
            cur_col = new_col
            cur_xs.append(x)
            cur_ys.append(y)
            continue

        if new_col == cur_col:
            cur_xs.append(x)
            cur_ys.append(y)
        else:
            segments.append((cur_xs, cur_ys, cur_col))
            prev_x, prev_y = series.index[i - 1], series.iloc[i - 1]
            cur_xs = [prev_x, x]
            cur_ys = [prev_y, y]
            cur_col = new_col

    if cur_xs:
        segments.append((cur_xs, cur_ys, cur_col))

    return segments


def _add_series_traces(
    fig: go.Figure,
    df: pd.DataFrame,
    show_legend: bool,
    h_line_color_ranges: Sequence[Sequence[Any]],
    v_line_color_ranges: Sequence[Sequence[Any]],
    useMarker: bool,
    palette_iter: Any,
) -> None:
    """Add line traces for each column in *df*, with optional color segmentation."""
    for col in df.columns:
        series = df[col].dropna()
        default_color = next(palette_iter)

        segments = _build_color_segments(
            series, default_color, h_line_color_ranges, v_line_color_ranges
        )

        for j, (xs, ys, c) in enumerate(segments):
            fig.add_trace(
                go.Scatter(
                    x=xs,
                    y=ys,
                    mode="lines",
                    line={"color": c, "width": 2},
                    name=str(col) if j == 0 else None,
                    showlegend=(j == 0 and show_legend),
                ),
                secondary_y=False,
            )

        if useMarker and len(series):
            _add_last_point_marker(
                fig, series.index[-1], series.iloc[-1], segments[-1][2]
            )


def plot_line(
    df: pd.Series | pd.DataFrame,
    benchmark: pd.Series | None = None,
    unit: str = ".2f",
    hlines: Sequence[dict[str, float | str]] | None = None,
    vlines: Sequence[dict[str, float | str]] | None = None,
    h_color_ranges: Sequence[Sequence[Any]] | None = None,
    v_color_ranges: Sequence[Sequence[Any]] | None = None,
    h_line_color_ranges: Sequence[Sequence[Any]] | None = None,
    v_line_color_ranges: Sequence[Sequence[Any]] | None = None,
    useMarker: bool = False,
    bg_color: str | None = "black",
    title: str | None = None,
    show_legend: bool = True,
) -> go.Figure:
    """
    Plots a line chart with advanced customization options.

    Features:
        - Zone-colored line segments:
            Use `h_line_color_ranges` and `v_line_color_ranges` to color line segments based on y (horizontal) or x (vertical) value ranges.
        - Guide lines:
            Add horizontal (`hlines`) and vertical (`vlines`) reference lines, with optional custom colors.
        - Colored bands:
            Highlight horizontal (`h_color_ranges`) or vertical (`v_color_ranges`) value regions with background color bands.
        - Benchmark:
            Optionally plot a benchmark series for comparison.
        - Last-point marker:
            Optionally highlight the last data point with a marker.
        - Customization:
            Set background color, legend visibility, plot title, and value formatting.

    Args:
        df (pd.Series or pd.DataFrame): Data to plot (index as x-axis).
        benchmark (pd.Series, optional): Series to plot as a benchmark.
        unit (str): Format string for y-axis values (default: ".2f").
        hlines (list of dict, optional): Horizontal guide lines.
        vlines (list of dict, optional): Vertical guide lines.
        h_color_ranges (list, optional): Horizontal colored bands.
        v_color_ranges (list, optional): Vertical colored bands.
        h_line_color_ranges (list, optional): Y-value ranges for line segment coloring.
        v_line_color_ranges (list, optional): X-value ranges for line segment coloring.
        useMarker (bool): Whether to mark the last data point.
        bg_color (str, optional): Background color.
        title (str, optional): Plot title.
        show_legend (bool): Whether to show the legend.

    Returns:
        plotly.graph_objs.Figure: The resulting plotly figure.

    Examples:
        Basic usage with a single series:
            ```python
            import pandas as pd
            from finlab.plot import plot_line

            # Simple line plot
            data = pd.Series([1, 2, 3, 4, 5], index=pd.date_range('2023-01-01', periods=5))
            fig = plot_line(data)
            fig.show()
            ```

        Advanced usage with all features:
            ```python
            import pandas as pd
            import numpy as np

            # Create sample data
            dates = pd.date_range('2023-01-01', '2023-12-31', freq='D')
            stock_a = 100 + np.cumsum(np.random.randn(len(dates)) * 0.5)
            stock_b = 95 + np.cumsum(np.random.randn(len(dates)) * 0.3)

            df = pd.DataFrame({
                'Stock A': stock_a,
                'Stock B': stock_b
            }, index=dates)

            # Benchmark data
            benchmark = pd.Series(100 + np.cumsum(np.random.randn(len(dates)) * 0.2),
                                index=dates, name='Market Index')

            # Plot example with benchmark overlay
            fig = plot_line(
                df=df,
                benchmark=benchmark,
                unit=".1f",
                hlines=[
                    {"pos": 105, "color": "red"},
                    {"pos": 95, "color": "green"}
                ],
                vlines=[
                    {"pos": "2023-06-15", "color": "blue"}
                ],
                h_color_ranges=[
                    (90, 100, "lightgreen"),
                    (110, 120, "lightcoral")
                ],
                v_color_ranges=[
                    ("2023-01-01", "2023-06-30", "lightyellow"),
                    ("2023-07-01", "2023-12-31", "lightcyan")
                ],
                h_line_color_ranges=[
                    (90, 100, "green"),
                    (110, 120, "red")
                ],
                v_line_color_ranges=[
                    ("2023-01-01", "2023-06-30", "orange"),
                    ("2023-07-01", "2023-12-31", "purple")
                ],
                useMarker=True,
                bg_color="white",
                title="Stock Performance Analysis",
                show_legend=True
            )
            fig.show()
            ```
    """

    # -- sanitise inputs ------------------------------------------------------
    if isinstance(df, pd.Series):
        df = df.to_frame()
    hlines = hlines or []
    vlines = vlines or []
    h_color_ranges = h_color_ranges or []
    v_color_ranges = v_color_ranges or []
    h_line_color_ranges = h_line_color_ranges or []
    v_line_color_ranges = v_line_color_ranges or []

    # -- scaffold -------------------------------------------------------------
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    palette_iter = itertools.cycle(_PLOTLY_PALETTE)

    # -- main series ----------------------------------------------------------
    _add_series_traces(
        fig,
        df,
        show_legend,
        h_line_color_ranges,
        v_line_color_ranges,
        useMarker,
        palette_iter,
    )

    # -- benchmark ------------------------------------------------------------
    if benchmark is not None:
        bench = benchmark.dropna()
        fig.add_trace(
            go.Scatter(
                x=bench.index,
                y=bench.values,
                mode="lines",
                line={"color": "#777777", "width": 1},
                name=str(getattr(benchmark, "name", "benchmark")),
                opacity=0.6,
                showlegend=show_legend,
            ),
            secondary_y=True,
        )

    # -- guide lines ----------------------------------------------------------
    shapes = [
        {
            "type": "line",
            "xref": "paper",
            "x0": 0,
            "x1": 1,
            "yref": "y",
            "y0": ln["pos"],
            "y1": ln["pos"],
            "line": {
                "color": _convert_color(ln["color"]),
                "width": 1,
                "dash": "dot",
            },
        }
        for ln in hlines
    ]
    shapes.extend(
        {
            "type": "line",
            "yref": "paper",
            "y0": 0,
            "y1": 1,
            "xref": "x",
            "x0": ln["pos"],
            "x1": ln["pos"],
            "line": {
                "color": _convert_color(ln["color"]),
                "width": 1,
                "dash": "dot",
            },
        }
        for ln in vlines
    )

    # coloured background bands
    for lo, hi, clr in h_color_ranges:
        shapes.append(
            {
                "type": "rect",
                "xref": "paper",
                "x0": 0,
                "x1": 1,
                "yref": "y",
                "y0": lo,
                "y1": hi,
                "fillcolor": _convert_color(clr),
                "opacity": 0.15,
                "line_width": 0,
            }
        )
    for lo, hi, clr in v_color_ranges:
        shapes.append(
            {
                "type": "rect",
                "yref": "paper",
                "y0": 0,
                "y1": 1,
                "xref": "x",
                "x0": lo,
                "x1": hi,
                "fillcolor": _convert_color(clr),
                "opacity": 0.15,
                "line_width": 0,
            }
        )

    # -- layout ---------------------------------------------------------------
    fig.update_layout(
        title={
            "text": title,
            "y": 0.9,
            "x": 0.05,
            "xanchor": "left",
            "yanchor": "top",
            "font": {"size": 18, "color": "#777777"},
        },
        template="plotly_dark",
        shapes=shapes,
        legend={"title": ""} if len(df.columns) > 1 and show_legend else None,
        margin={"t": 80, "b": 60, "l": 40, "r": 40},
        width=800,
        height=450,
        paper_bgcolor=bg_color,
        plot_bgcolor=bg_color,
        yaxis={
            "showgrid": False,
            "tickformat": unit,
            "nticks": 10,
            "zeroline": False,
            "side": "right",
            "showline": False,
        },
        xaxis={"showgrid": False, "showline": True},
        yaxis2={"visible": False},
    )
    if benchmark is not None:
        fig.update_yaxes(showgrid=False, secondary_y=True)

    return fig


def plot_line_example() -> go.Figure:
    """
    Comprehensive example demonstrating all features of plot_line function.

    This example shows how to use all parameters and features of the plot_line function:
    - Multiple data series
    - Benchmark comparison
    - Horizontal and vertical guide lines
    - Colored background bands
    - Zone-colored line segments
    - Last point markers
    - Custom styling and formatting

    Returns:
        plotly.graph_objs.Figure: Example figure with all features
    """

    import numpy as np
    import pandas as pd

    # Create sample data
    dates = pd.date_range("2023-01-01", "2023-12-31", freq="D")
    np.random.seed(42)

    # Main data series
    stock_a = 100 + np.cumsum(np.random.randn(len(dates)) * 0.5)
    stock_b = 95 + np.cumsum(np.random.randn(len(dates)) * 0.3)
    stock_c = 110 + np.cumsum(np.random.randn(len(dates)) * 0.4)

    df = pd.DataFrame(
        {"Stock A": stock_a, "Stock B": stock_b, "Stock C": stock_c}, index=dates
    )

    # Benchmark data
    benchmark = 100 + np.cumsum(np.random.randn(len(dates)) * 0.2)
    benchmark_series = pd.Series(benchmark, index=dates, name="Market Index")

    # Example with all features
    return plot_line(
        df=df,
        benchmark=benchmark_series,
        unit=".1f",  # Format y-axis values to 1 decimal place
        hlines=[  # Horizontal guide lines
            {"pos": 105, "color": "red"},
            {"pos": 95, "color": "green"},
            {"pos": 115, "color": "orange"},
        ],
        vlines=[  # Vertical guide lines
            {"pos": "2023-03-15", "color": "blue"},
            {"pos": "2023-06-15", "color": "purple"},
            {"pos": "2023-09-15", "color": "cyan"},
        ],
        h_color_ranges=[  # Horizontal colored background bands
            (90, 100, "lightgreen"),  # Green band for 90-100
            (110, 120, "lightcoral"),  # Red band for 110-120
            (100, 110, "lightblue"),  # Blue band for 100-110
        ],
        v_color_ranges=[  # Vertical colored background bands
            ("2023-01-01", "2023-03-31", "lightyellow"),  # Q1
            ("2023-04-01", "2023-06-30", "lightcyan"),  # Q2
            ("2023-07-01", "2023-09-30", "lightpink"),  # Q3
            ("2023-10-01", "2023-12-31", "lightgray"),  # Q4
        ],
        h_line_color_ranges=[  # Y-value ranges for line segment coloring
            (90, 100, "green"),  # Green line when y < 100
            (110, 120, "red"),  # Red line when y > 110
            (100, 110, "blue"),  # Blue line when 100 < y < 110
        ],
        v_line_color_ranges=[  # X-value ranges for line segment coloring
            ("2023-01-01", "2023-06-30", "orange"),  # Orange line in first half
            ("2023-07-01", "2023-12-31", "purple"),  # Purple line in second half
        ],
        useMarker=True,  # Show markers at last data points
        bg_color="white",  # White background
        title="Comprehensive Stock Performance Analysis with All Features",
        show_legend=True,  # Show legend
    )


def plot_line_financial_example() -> go.Figure:
    """
    Real-world financial example using finlab data.

    This example demonstrates plot_line with actual stock data and common
    financial analysis features like support/resistance levels and trend zones.

    Returns:
        plotly.graph_objs.Figure: Financial analysis chart
    """
    import pandas as pd

    from finlab import data

    # Get real stock data for Taiwan Semiconductor (2330)
    try:
        close_prices = data.get("price:收盤價")["2330"]
        # Get last 100 trading days
        close_prices = close_prices.tail(100)

        # Calculate moving averages as additional series
        ma_20 = close_prices.rolling(20).mean()
        ma_50 = close_prices.rolling(50).mean()

        # Create DataFrame with multiple series
        df = pd.DataFrame({"TSMC Close": close_prices, "MA 20": ma_20, "MA 50": ma_50})

        # Get market benchmark (Taiwan Weighted Index)
        benchmark = data.get("benchmark_return:發行量加權股價報酬指數")[
            "發行量加權股價報酬指數"
        ]
        benchmark = benchmark.tail(100)

        # Calculate support and resistance levels
        recent_high = close_prices.max()
        recent_low = close_prices.min()
        mid_level = (recent_high + recent_low) / 2

        # Example with financial analysis features
        return plot_line(
            df=df,
            benchmark=benchmark,
            unit=".0f",  # No decimal places for stock prices
            hlines=[  # Support and resistance levels
                {"pos": recent_high, "color": "red"},
                {"pos": recent_low, "color": "green"},
                {"pos": mid_level, "color": "orange"},
            ],
            vlines=[  # Important dates (quarterly earnings, etc.)
                {"pos": close_prices.index[-30], "color": "blue"},  # 30 days ago
                {"pos": close_prices.index[-60], "color": "purple"},  # 60 days ago
            ],
            h_color_ranges=[  # Price zones
                (recent_low, mid_level, "lightgreen"),  # Bullish zone
                (mid_level, recent_high, "lightcoral"),  # Bearish zone
            ],
            h_line_color_ranges=[  # Trend-based line coloring
                (recent_low, mid_level, "green"),  # Green when above support
                (mid_level, recent_high, "red"),  # Red when below resistance
            ],
            useMarker=True,
            bg_color="black",
            title="TSMC (2330) Stock Analysis with Technical Indicators",
            show_legend=True,
        )

    except (KeyError, ValueError, RuntimeError) as e:
        # Fallback example if data is not available
        print(f"Data not available, using fallback example: {e}")

        # Create synthetic data
        dates = pd.date_range("2023-01-01", "2023-12-31", freq="D")
        np.random.seed(42)

        stock_price = 500 + np.cumsum(np.random.randn(len(dates)) * 2)
        ma_short = pd.Series(stock_price).rolling(20).mean()
        ma_long = pd.Series(stock_price).rolling(50).mean()

        df = pd.DataFrame(
            {"Stock Price": stock_price, "MA 20": ma_short, "MA 50": ma_long},
            index=dates,
        )

        return plot_line(
            df=df,
            unit=".0f",
            hlines=[{"pos": 550, "color": "red"}, {"pos": 450, "color": "green"}],
            h_color_ranges=[(450, 500, "lightgreen"), (500, 550, "lightcoral")],
            useMarker=True,
            title="Sample Stock Analysis (Fallback Data)",
            show_legend=True,
        )
