"""Plot package -- re-exports all public names from submodules."""

from finlab.plot._core import (
    IndicatorSpec,
    average,
    color_generator,
    df_date_filter,
)
from finlab.plot.candle import plot_candles, plot_tw_stock_candles
from finlab.plot.line import plot_line, plot_line_example, plot_line_financial_example
from finlab.plot.radar import plot_tw_stock_radar
from finlab.plot.river import get_pe_river_data, plot_tw_stock_river
from finlab.plot.strategy import StrategyReturnStats, StrategySunburst
from finlab.plot.treemap import create_treemap_data, plot_tw_stock_treemap

__all__ = [
    "IndicatorSpec",
    "StrategyReturnStats",
    "StrategySunburst",
    "average",
    "color_generator",
    "create_treemap_data",
    "df_date_filter",
    "get_pe_river_data",
    "plot_candles",
    "plot_line",
    "plot_line_example",
    "plot_line_financial_example",
    "plot_tw_stock_candles",
    "plot_tw_stock_radar",
    "plot_tw_stock_river",
    "plot_tw_stock_treemap",
]
