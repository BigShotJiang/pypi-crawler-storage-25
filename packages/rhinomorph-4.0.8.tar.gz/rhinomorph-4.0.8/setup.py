from setuptools import setup, find_packages

setup(
    name='rhinoMorph',
    version='4.0.8',  # 버전 업!
    description='Morphological Analyzer for Korean',
    author='Sukjae Choi',
    author_email='lingua72@gmail.com',
    url='https://blog.naver.com/lingua/221537630069',
    license='MIT',
    # py_modules는 삭제하고 아래 packages 설정을 유지합니다.
    packages=find_packages(), 
    include_package_data=True,
    package_data={
        'rhinoMorph': [
            'lib/*', 
            'resource/*',
            'lib/**/*',
            'resource/**/*',
        ],
    },
    install_requires=['jpype1'],
    python_requires='>=3',
    zip_safe=False
)