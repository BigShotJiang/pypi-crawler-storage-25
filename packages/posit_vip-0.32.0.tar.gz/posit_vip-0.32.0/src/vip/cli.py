"""VIP command-line tools for credential management and verification."""

from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vip.config import Mode

# Buffer subtracted from the user-supplied timeout when setting the pytest
# timeout inside the K8s Job.  The Job's own deadline is set to args.timeout,
# so we give pytest a slightly shorter limit so it can finish and write results
# before Kubernetes kills the pod.
_JOB_CLEANUP_BUFFER_SECONDS = 60
_JOB_MIN_PYTEST_TIMEOUT_SECONDS = 60

# Default for ``vip verify --test-timeout``.  Generous enough for a full
# Connect suite with several content deployments (each can take 3-5 minutes
# for R package restore or Python venv creation).
DEFAULT_TEST_TIMEOUT_SECONDS = 3600

# Valid test categories. Maps every accepted spelling (hyphenated and
# underscored) to the internal pytest marker name.
VALID_CATEGORIES: dict[str, str] = {
    "prerequisites": "prerequisites",
    "connect": "connect",
    "workbench": "workbench",
    "package-manager": "package_manager",
    "package_manager": "package_manager",
    "cross-product": "cross_product",
    "cross_product": "cross_product",
    "performance": "performance",
    "security": "security",
    "config-hygiene": "config_hygiene",
    "config_hygiene": "config_hygiene",
}

# Categories that are excluded from the default ``vip verify`` run and only
# executed when the user explicitly opts in, either via ``--categories`` or
# a dedicated opt-in flag (for example ``--performance-tests``). These tests
# check VIP's own configuration rather than the Posit deployment.
_OPT_IN_CATEGORIES = frozenset({"config_hygiene", "performance"})

# Marker expression keywords that are not category names.
_MARKER_KEYWORDS = {"and", "or", "not"}

# Regex matching a complete identifier token (may contain hyphens or
# underscores).  Negative lookbehind/lookahead ensure we don't match a
# substring inside a larger token like ``_connect`` or ``1connect``.
_IDENT_RE = re.compile(r"(?<![A-Za-z0-9_-])[A-Za-z][A-Za-z0-9_-]*(?![A-Za-z0-9_-])")


def _valid_categories_message() -> str:
    """Return a comma-separated string of preferred (hyphenated) category names."""
    seen: dict[str, str] = {}
    for k, v in VALID_CATEGORIES.items():
        if v not in seen or "-" in k:
            seen[v] = k
    return ", ".join(sorted(seen.values()))


def _default_marker_expr(extra_keep: frozenset[str] = frozenset()) -> str:
    """Marker expression applied when the user doesn't pass ``--categories``.

    Excludes every opt-in category so that ``vip verify`` runs only the
    product-verification tests by default.  Pass ``extra_keep`` to re-include
    specific opt-in categories (e.g. ``frozenset({"performance"})`` when
    ``--performance-tests`` is set).
    """
    excluded = _OPT_IN_CATEGORIES - extra_keep
    return " and ".join(f"not {name}" for name in sorted(excluded))


def _extra_keep_from_args(args: argparse.Namespace) -> frozenset[str]:
    """Return the set of opt-in categories to re-include based on CLI flags.

    For example, ``--performance-tests`` adds ``"performance"`` to the set so
    that :func:`_default_marker_expr` keeps it in the expression.
    """
    extra: set[str] = set()
    if getattr(args, "performance_tests", False):
        extra.add("performance")
    return frozenset(extra)


def _normalize_categories(expr: str) -> str:
    """Validate and normalize a ``--categories`` expression.

    Accepts user-facing hyphenated names (e.g. ``package-manager``) as well
    as underscore names (``package_manager``) and translates both to the
    internal pytest marker names.  Raises :class:`SystemExit` if any
    identifier token is not a recognised category or keyword.
    """

    def _replace(match: re.Match[str]) -> str:
        word = match.group(0)
        if word in _MARKER_KEYWORDS:
            return word
        if word in VALID_CATEGORIES:
            return VALID_CATEGORIES[word]
        print(
            f"Error: unknown category '{word}'. Valid categories: {_valid_categories_message()}",
            file=sys.stderr,
        )
        sys.exit(1)

    result = _IDENT_RE.sub(_replace, expr)
    # After substitution, only whitespace and parentheses should remain
    # between identifiers.  Any leftover characters (digits, underscores
    # from malformed tokens like ``_connect`` or ``1connect``) are invalid.
    leftover = _IDENT_RE.sub("", result).replace("(", "").replace(")", "").strip()
    if leftover:
        print(
            f"Error: invalid characters in category expression: '{expr}'. "
            f"Valid categories: {_valid_categories_message()}",
            file=sys.stderr,
        )
        sys.exit(1)
    return result


def _connect_cluster(cluster_config) -> Path:
    """Generate kubeconfig and set KUBECONFIG env var. Returns the path."""
    from vip.cluster.target import validate_cluster_config

    validate_cluster_config(cluster_config)

    if cluster_config.provider == "aws":
        from vip.cluster.aws import get_eks_kubeconfig

        kubeconfig_path = get_eks_kubeconfig(
            cluster_config.name,
            cluster_config.region,
            cluster_config.profile or None,
            cluster_config.role_arn or None,
        )
    elif cluster_config.provider == "azure":
        from vip.cluster.azure import get_aks_kubeconfig

        kubeconfig_path = get_aks_kubeconfig(
            cluster_config.name,
            cluster_config.resource_group,
            cluster_config.subscription_id,
        )
    else:
        raise ValueError(f"Unknown provider: {cluster_config.provider!r}")

    os.environ["KUBECONFIG"] = str(kubeconfig_path)
    print(f"Connected to cluster: {cluster_config.name}", file=sys.stderr)
    return kubeconfig_path


def mint_connect_key(args: argparse.Namespace) -> None:
    """Launch interactive browser auth and mint a Connect API key."""
    from vip.auth import start_interactive_auth

    session = start_interactive_auth(args.url)

    if not session.api_key:
        print(json.dumps({"error": "Failed to mint API key"}), file=sys.stderr)
        sys.exit(1)

    result = {
        "api_key": session.api_key,
        "key_name": session.key_name,
    }

    print(json.dumps(result))


def connect_to_cluster(args: argparse.Namespace) -> None:
    """Generate kubeconfig for a cluster and print the path."""
    from vip.config import load_config

    config = load_config()

    if args.provider:
        config.cluster.provider = args.provider
    if args.cluster_name:
        config.cluster.name = args.cluster_name
    if args.region:
        config.cluster.region = args.region
    if args.resource_group:
        config.cluster.resource_group = args.resource_group
    if args.subscription_id:
        config.cluster.subscription_id = args.subscription_id
    if args.profile:
        config.cluster.profile = args.profile

    kubeconfig_path = _connect_cluster(config.cluster)
    print(str(kubeconfig_path))


# ---------------------------------------------------------------------------
# Config generation from CLI URL args
# ---------------------------------------------------------------------------


def _print_skip_notes(config_path: str | None) -> None:
    """Print a note for each product that is not configured."""
    from vip.config import load_config

    try:
        cfg = load_config(config_path)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    products = [
        ("Connect", cfg.connect),
        ("Workbench", cfg.workbench),
        ("Package Manager", cfg.package_manager),
    ]
    for name, pc in products:
        if not pc.is_configured:
            if not pc.enabled:
                reason = "disabled"
            else:
                reason = "no URL given"
            print(f"Note: {name} {reason} — {name} tests will not be collected.", flush=True)


def _check_credentials(
    config_path: str | None,
    *,
    interactive_auth: bool,
    categories: str | None,
) -> None:
    """Exit early when products are configured but credentials are missing.

    When *categories* is provided, only check products whose marker appears
    in the expression.  Without categories all configured products are checked.
    """
    from vip.config import load_config

    try:
        cfg = load_config(config_path)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    if interactive_auth:
        return

    has_creds = bool(cfg.auth.username and cfg.auth.password)
    needs_creds: list[str] = []

    # When a category filter is active, only enforce credential checks for
    # products that are actually selected.  We tokenize the expression and
    # check that the marker appears as a positive term (not negated by "not").
    def _category_selected(marker: str) -> bool:
        if categories is None:
            return True
        tokens = re.findall(r"\w+", categories)
        for i, tok in enumerate(tokens):
            if tok == marker and (i == 0 or tokens[i - 1] != "not"):
                return True
        return False

    # Connect tests include UI login and user-management scenarios that use
    # VIP_TEST_USERNAME/VIP_TEST_PASSWORD even when VIP_CONNECT_API_KEY is set,
    # so require credentials whenever Connect is selected (users can pass
    # --no-auth to deselect Connect tests entirely).
    if cfg.connect.is_configured and not has_creds and _category_selected("connect"):
        needs_creds.append("Connect")
    if cfg.workbench.is_configured and not has_creds and _category_selected("workbench"):
        needs_creds.append("Workbench")

    if needs_creds:
        products = " and ".join(needs_creds)
        print(
            f"\033[1mError: {products} tests selected but no credentials provided.\033[0m\n"
            "Set VIP_TEST_USERNAME and VIP_TEST_PASSWORD (optionally with --headless-auth),\n"
            "or use --interactive-auth, or --no-auth to skip tests that require "
            "authentication.",
            file=sys.stderr,
            flush=True,
        )
        sys.exit(1)


# Pytest options that consume the next argument as a directory path.
# We skip these values so they aren't mistaken for positional test targets.
_CONSUMES_DIR_VALUE = frozenset({"--rootdir", "--confcutdir", "--basetemp"})


def _has_explicit_test_targets(pytest_args: list[str]) -> bool:
    """Return True if *pytest_args* contains what looks like test paths or nodeids.

    This avoids injecting the default ``vip_tests`` path when the user already
    passed explicit targets after ``--`` (e.g. ``vip verify -- tests/foo.py``).
    Directory values consumed by known pytest options (``--rootdir``, etc.) are
    excluded so they don't trigger false-positive detection.
    """
    skip_next = False
    for arg in pytest_args:
        if skip_next:
            skip_next = False
            continue
        if arg in _CONSUMES_DIR_VALUE:
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        if "::" in arg or arg.endswith(".py") or Path(arg).is_dir():
            return True
    return False


def _generate_temp_config(args: argparse.Namespace) -> str:
    """Write a minimal vip.toml from CLI URL arguments. Returns temp file path."""
    lines = ["[general]", 'deployment_name = "Posit Team"', ""]

    if args.connect_url:
        lines.extend(["[connect]", f'url = "{args.connect_url}"', ""])
    else:
        lines.extend(["[connect]", "enabled = false", ""])

    if args.workbench_url:
        lines.extend(["[workbench]", f'url = "{args.workbench_url}"', ""])
    else:
        lines.extend(["[workbench]", "enabled = false", ""])

    if args.package_manager_url:
        lines.extend(["[package_manager]", f'url = "{args.package_manager_url}"', ""])
    else:
        lines.extend(["[package_manager]", "enabled = false", ""])

    idp = getattr(args, "idp", None)
    inherited_provider: str | None = None

    # Inherit from an existing vip.toml so ``vip verify --workbench-url ...
    # --headless-auth`` can pick up the [auth] section the user already
    # configured.  Done best-effort: a malformed vip.toml should not break a
    # URL-driven command that doesn't depend on it.
    env = os.environ.get("VIP_CONFIG")
    default_path = Path(env) if env else Path("vip.toml")
    if default_path.is_file():
        from vip.config import load_config

        try:
            existing = load_config(default_path)
        except Exception:
            existing = None
        if existing is not None:
            if not idp and existing.auth.idp:
                idp = existing.auth.idp
            if existing.auth.provider and existing.auth.provider != "password":
                inherited_provider = existing.auth.provider

    # Resolve the provider:
    # - With --idp set, the user wants IdP-based auth.  Keep an inherited
    #   IdP-class value (saml/oauth2) so specific declarations survive; but
    #   ignore inherited non-IdP providers (ldap) that would contradict the
    #   CLI intent — auth.py's flow selection keys off provider, not idp.
    # - Without --idp, just honour whatever vip.toml declared.
    _IDP_PROVIDERS = ("oidc", "saml", "oauth2")
    if idp:
        if inherited_provider in _IDP_PROVIDERS:
            auth_provider: str | None = inherited_provider
        else:
            auth_provider = "oidc"
    else:
        auth_provider = inherited_provider

    if auth_provider or idp:
        lines.append("[auth]")
        if auth_provider:
            lines.append(f'provider = "{auth_provider}"')
        if idp:
            lines.append(f'idp = "{idp}"')
        lines.append("")

    insecure = getattr(args, "insecure", False)
    ca_bundle = getattr(args, "ca_bundle", None)
    if insecure and ca_bundle:
        import warnings

        warnings.warn(
            "--insecure and --ca-bundle are both set; --insecure takes precedence "
            "and the ca-bundle path will be ignored for TLS verification.",
            stacklevel=2,
        )
    effective_ca_bundle = None if insecure else ca_bundle
    if insecure or effective_ca_bundle:
        lines.append("[tls]")
        if insecure:
            lines.append("insecure = true")
        if effective_ca_bundle:
            import json as _json

            lines.append(f"ca_bundle = {_json.dumps(str(effective_ca_bundle))}")
        lines.append("")

    with tempfile.NamedTemporaryFile(mode="w", suffix=".toml", delete=False) as f:
        f.write("\n".join(lines) + "\n")
        return f.name


# ---------------------------------------------------------------------------
# vip verify (combined local + K8s)
# ---------------------------------------------------------------------------


def _resolve_mode(args: argparse.Namespace) -> Mode:
    """Convert boolean CLI flags to a Mode enum value."""
    from vip.config import Mode

    if args.config_only:
        return Mode.config_only
    return Mode.k8s_job


def _phase_generate_config(args: argparse.Namespace) -> tuple[str, dict]:
    """Fetch PTD Site CR and return (vip_config_toml, site_cr) tuple."""
    from vip.verify.site import fetch_site_cr, generate_vip_config

    site = getattr(args, "site", "main")
    namespace = getattr(args, "namespace", "posit-team")
    name = getattr(args, "name", None) or "Posit Team"

    print(f"Fetching PTD Site CR: {site} (namespace: {namespace})")
    site_cr = fetch_site_cr(site, namespace)
    return generate_vip_config(site_cr, name), site_cr


def _phase_provision_credentials(site_cr: dict, args: argparse.Namespace) -> None:
    """Provision test credentials in the K8s cluster."""
    from vip.verify.site import _extract_connect_url, _extract_keycloak_url

    if args.interactive_auth:
        from vip.verify.credentials import mint_interactive_credentials

        connect_url = _extract_connect_url(site_cr)
        if not connect_url:
            print("Error: Connect URL not found in PTD Site CR", file=sys.stderr)
            sys.exit(1)
        site = getattr(args, "site", "main")
        namespace = getattr(args, "namespace", "posit-team")
        print("Minting credentials via interactive auth...")
        mint_interactive_credentials(connect_url, site, namespace)
    else:
        keycloak_url = _extract_keycloak_url(site_cr)
        if keycloak_url:
            from vip.verify.credentials import ensure_keycloak_test_user

            site = getattr(args, "site", "main")
            namespace = getattr(args, "namespace", "posit-team")
            admin_secret_name = f"{site}-keycloak-initial-admin"
            print(f"Ensuring Keycloak test user exists (admin secret: {admin_secret_name})")
            try:
                ensure_keycloak_test_user(
                    keycloak_url,
                    "posit",
                    "vip-test-user",
                    admin_secret_name,
                    namespace,
                )
            except Exception as e:
                print(
                    f"Warning: Could not create Keycloak test user: {e}",
                    file=sys.stderr,
                )
                print("Continuing without Keycloak credentials...", file=sys.stderr)


def run_verify(args: argparse.Namespace) -> None:
    """Run VIP tests. Handles both local and K8s modes."""
    if args.k8s or args.config_only:
        _run_verify_k8s(args)
        return

    _run_verify_local(args)


def _run_verify_local(args: argparse.Namespace) -> None:
    """Run VIP tests locally against URL args or a vip.toml config."""
    config_path = args.config
    temp_config = None

    if not config_path and (args.connect_url or args.workbench_url or args.package_manager_url):
        temp_config = _generate_temp_config(args)
        config_path = temp_config

    # Fail fast when a config file is expected but doesn't exist.
    if config_path and not Path(config_path).is_file():
        print(f"Error: config file not found: {config_path}", file=sys.stderr)
        sys.exit(1)
    if not config_path:
        # No explicit config and no URL args — check the default resolution.
        env = os.environ.get("VIP_CONFIG")
        default = Path(env) if env else Path("vip.toml")
        if not default.is_file():
            print(f"Error: config file not found: {default}", file=sys.stderr)
            print(
                "Provide a config file with --config, or pass product URLs directly "
                "(e.g. --connect-url https://connect.example.com).",
                file=sys.stderr,
            )
            sys.exit(1)
        # Pin the resolved default so pytest loads the same file the CLI
        # validated, regardless of pytest's rootdir or subprocess CWD.
        config_path = str(default.resolve())

    # Resolve explicit paths too so --vip-config always gets an absolute path.
    config_path = str(Path(config_path).resolve())

    if args.interactive_auth and args.headless_auth:
        print(
            "\033[1mError: --interactive-auth and --headless-auth are mutually exclusive.\033[0m",
            file=sys.stderr,
            flush=True,
        )
        sys.exit(1)

    if args.no_auth and args.api_auth:
        print(
            "\033[1mError: --no-auth and --api-auth are mutually exclusive.\033[0m",
            file=sys.stderr,
            flush=True,
        )
        sys.exit(1)

    # Print notes for products that are not configured so the user knows
    # upfront which categories will be skipped.
    _print_skip_notes(config_path)
    if not args.no_auth and not args.api_auth:
        _check_credentials(
            config_path,
            interactive_auth=args.interactive_auth or args.headless_auth,
            categories=args.categories,
        )

    cmd = [sys.executable, "-m", "pytest", "-v", "--no-header"]

    # Resolve the installed vip_tests package so pytest finds tests even
    # when running outside the source tree (e.g. ``pip install posit-vip``).
    # Skip when the user already passed explicit test targets after ``--``.
    if not _has_explicit_test_targets(args.pytest_args):
        from importlib.util import find_spec

        _spec = find_spec("vip_tests")
        if _spec and _spec.submodule_search_locations:
            cmd.append(_spec.submodule_search_locations[0])

    if config_path:
        cmd.append(f"--vip-config={config_path}")
    if args.report:
        cmd.append(f"--vip-report={args.report}")
    if args.interactive_auth:
        cmd.append("--interactive-auth")
    if args.headless_auth:
        cmd.append("--headless-auth")
    if args.no_auth:
        cmd.append("--no-auth")
    if args.api_auth:
        cmd.append("--api-auth")
    for ext in args.extensions or []:
        cmd.append(f"--vip-extensions={ext}")
    if args.categories:
        cmd.extend(["-m", _normalize_categories(args.categories)])
    else:
        cmd.extend(["-m", _default_marker_expr(_extra_keep_from_args(args))])
    if args.filter_expr:
        cmd.extend(["-k", args.filter_expr])

    if args.verbose:
        cmd.append("--vip-verbose")
        cmd.append("-s")
    cmd.extend(args.pytest_args)
    if args.headless_auth:
        # MFA prompting needs stdin; always append -s last so it
        # overrides any conflicting --capture args from user or verbose.
        cmd.append("-s")

    try:
        result = subprocess.run(cmd, timeout=args.test_timeout)
        sys.exit(result.returncode)
    except subprocess.TimeoutExpired:
        print(
            f"Error: tests timed out after {args.test_timeout} seconds. "
            "Increase with --test-timeout or investigate hung tests.",
            file=sys.stderr,
        )
        sys.exit(1)
    finally:
        if temp_config:
            Path(temp_config).unlink(missing_ok=True)


def _run_verify_k8s(args: argparse.Namespace) -> None:
    """K8s workflow: fetch PTD Site CR, provision credentials, run as Job."""
    from vip.config import Mode, load_config

    config = load_config()
    mode = _resolve_mode(args)
    config.validate_for_mode(mode)

    if config.cluster.is_configured:
        _connect_cluster(config.cluster)

    vip_config_toml, site_cr = _phase_generate_config(args)

    if mode == Mode.config_only:
        print(vip_config_toml)
        return

    _phase_provision_credentials(site_cr, args)
    _run_k8s_job(vip_config_toml, args)


def _run_k8s_job(vip_config_toml: str, args: argparse.Namespace) -> None:
    """Run VIP tests as a K8s Job."""
    from vip.verify.job import cleanup, create_config_map, create_job, stream_logs, wait_for_job

    namespace = getattr(args, "namespace", "posit-team")
    suffix = secrets.token_hex(4)
    job_name = f"vip-verify-{suffix}"
    cm_name = f"vip-config-{suffix}"

    try:
        print(f"Creating ConfigMap: {cm_name}")
        create_config_map(cm_name, namespace, vip_config_toml)

        print(f"Creating Job: {job_name}")
        pytest_timeout = args.timeout - _JOB_CLEANUP_BUFFER_SECONDS
        if pytest_timeout <= 0:
            import warnings

            warnings.warn(
                f"--timeout ({args.timeout}s) is too short to subtract the "
                f"{_JOB_CLEANUP_BUFFER_SECONDS}s cleanup buffer. "
                f"Using minimum pytest timeout of {_JOB_MIN_PYTEST_TIMEOUT_SECONDS}s.",
                stacklevel=2,
            )
            pytest_timeout = _JOB_MIN_PYTEST_TIMEOUT_SECONDS
        create_job(
            job_name,
            namespace,
            cm_name,
            image=args.image,
            categories=(
                _normalize_categories(args.categories)
                if args.categories
                else _default_marker_expr(_extra_keep_from_args(args))
            ),
            filter_expr=getattr(args, "filter_expr", None),
            timeout_seconds=pytest_timeout,
            verbose=getattr(args, "verbose", False),
        )

        print(f"Streaming logs from Job: {job_name}")
        stream_logs(job_name, namespace, timeout=args.timeout)

        print(f"Waiting for Job to complete: {job_name}")
        success = wait_for_job(job_name, namespace, timeout=args.timeout)

        if not success:
            print("Verification failed", file=sys.stderr)
            sys.exit(1)
        else:
            print("Verification completed successfully")
    finally:
        print(f"Cleaning up Job and ConfigMap: {job_name}, {cm_name}")
        cleanup(job_name, cm_name, namespace)


def run_report(args: argparse.Namespace) -> None:
    """Render the Quarto report from a results.json file."""
    import shutil
    import webbrowser

    results_src = Path(args.results)
    results_dest = Path("report/results.json")

    if results_src.resolve() != results_dest.resolve():
        if not results_src.exists():
            print(f"Error: results file not found: {results_src}", file=sys.stderr)
            sys.exit(1)
        shutil.copy2(results_src, results_dest)

    result = subprocess.run(["quarto", "render"], cwd="report")

    if args.open and result.returncode == 0:
        webbrowser.open(str(Path("report/_site/index.html").resolve()))

    sys.exit(result.returncode)


def run_status(args: argparse.Namespace) -> None:
    """Run preflight health checks against each configured product."""
    from vip.clients.packagemanager import PackageManagerClient
    from vip.clients.workbench import WorkbenchClient
    from vip.config import load_config

    config = load_config(args.config)

    checks = [
        ("connect", config.connect),
        ("workbench", config.workbench),
        ("package_manager", config.package_manager),
    ]

    results = []
    for name, pc in checks:
        if not pc.is_configured:
            results.append((name, "not configured", "skip"))
            continue
        try:
            if name == "connect":
                from vip.clients.connect import ConnectClient as CC

                client: CC | WorkbenchClient | PackageManagerClient = CC(
                    pc.url,
                    pc.api_key,  # type: ignore[attr-defined]
                )
            elif name == "workbench":
                client = WorkbenchClient(pc.url, pc.api_key)  # type: ignore[attr-defined]
            else:
                client = PackageManagerClient(pc.url, pc.token)  # type: ignore[attr-defined]
            status = client.health()
            state = "ok" if status < 400 else "fail"
            results.append((name, f"HTTP {status}", state))
        except Exception as e:
            results.append((name, str(e), "fail"))

    for name, detail, state in results:
        print(f"  {state.upper():4s}  {name:20s}  {detail}")

    sys.exit(0 if all(s in ("ok", "skip") for _, _, s in results) else 1)


def run_app(args: argparse.Namespace) -> None:
    """Launch the VIP Shiny app."""
    try:
        from shiny import run_app as _run_shiny  # noqa: F811
    except ImportError:
        print(
            "Error: the 'shiny' package is not installed.\nInstall with: uv sync",
            file=sys.stderr,
        )
        sys.exit(1)

    # The --config flag is not currently supported for the Shiny app.
    # Fail fast instead of silently ignoring it.
    if getattr(args, "config", None):
        print(
            "Error: the '--config' option is not supported for 'vip app' at this time.",
            file=sys.stderr,
        )
        sys.exit(2)

    _run_shiny(  # type: ignore[misc]  # shiny is an optional dep
        "vip.app.app:app",
        host=args.host,
        port=args.port,
        launch_browser=not args.no_browser,
    )


def run_install(args: argparse.Namespace) -> None:
    """Provision system packages and Playwright Chromium for VIP local mode."""
    from datetime import datetime, timezone

    from vip.install import platform as plat
    from vip.install.manifest import (
        SCHEMA_VERSION,
        Manifest,
        current_host,
        default_path,
        load,
    )
    from vip.install.packages import PackageQueryError, installed_dpkg, installed_rpm
    from vip.install.plan import build_install_plan
    from vip.install.playwright import PlaywrightInstallError, chromium_installed, default_cache_dir
    from vip.install.runner import execute_install_plan, format_install_plan

    info = plat.detect()
    manifest_path = default_path()
    manifest = load(manifest_path)

    cache_dir = default_cache_dir()

    try:
        plan = build_install_plan(
            platform_info=info,
            manifest=manifest,
            rpm_installed=installed_rpm,
            dpkg_installed=installed_dpkg,
            chromium_present=chromium_installed(cache_dir),
            playwright_cache_dir=cache_dir,
            skip_system=bool(getattr(args, "skip_system", False)),
        )

        if getattr(args, "dry_run", False):
            print(format_install_plan(plan), end="")
            return

        if manifest is None:
            now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            from vip import __version__ as vip_version

            manifest = Manifest(
                version=SCHEMA_VERSION,
                vip_version=vip_version,
                created_at=now,
                updated_at=now,
                host=current_host(),
                platform=info.family,
                platform_id=info.id,
                platform_version=info.version,
            )

        rc = execute_install_plan(plan, manifest=manifest, manifest_path=manifest_path)
    except (PlaywrightInstallError, PackageQueryError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    sys.exit(rc)


def run_uninstall(args: argparse.Namespace) -> None:
    """Reverse `vip install` using the manifest."""
    from vip.install.manifest import (
        ManifestError,
        current_host,
        default_path,
        load,
    )
    from vip.install.plan import build_uninstall_plan
    from vip.install.runner import execute_uninstall_plan

    manifest_path = default_path()
    try:
        manifest = load(manifest_path)
    except ManifestError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    if manifest is None:
        print(
            f"No {manifest_path.name} found. Nothing to uninstall, or vip was "
            "installed by a different mechanism.",
            file=sys.stderr,
        )
        sys.exit(1)

    if manifest.host != current_host() and not getattr(args, "force_host", False):
        print(
            f"Error: manifest host {manifest.host!r} does not match current host "
            f"{current_host()!r}. Pass --force-host to override.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Resolve Connect URL for chained cleanup.
    connect_url = getattr(args, "connect_url", None)
    if not connect_url:
        if sys.version_info >= (3, 11):
            import tomllib as _tomllib
        else:
            import tomli as _tomllib  # type: ignore[no-redef]

        cfg = None
        try:
            from vip.config import load_config

            cfg = load_config()
        except (_tomllib.TOMLDecodeError, ValueError) as exc:
            print(
                f"warning: failed to load vip.toml for chained cleanup: {exc}; "
                "continuing without chained Connect cleanup",
                file=sys.stderr,
            )
        if cfg and cfg.connect and cfg.connect.url:
            connect_url = cfg.connect.url

    plan = build_uninstall_plan(
        manifest=manifest,
        connect_url=connect_url,
    )

    cleanup_callable = None
    if connect_url:
        api_key = getattr(args, "api_key", None) or os.environ.get("VIP_CONNECT_API_KEY", "")

        def cleanup_callable(url: str) -> None:  # noqa: F811
            from vip.clients.connect import ConnectClient

            with ConnectClient(url, api_key) as client:
                client.cleanup_vip_content()

    rc = execute_uninstall_plan(
        plan,
        manifest_path=manifest_path,
        yes=bool(getattr(args, "yes", False)),
        cleanup_callable=cleanup_callable,
    )
    sys.exit(rc)


def run_cleanup(args: argparse.Namespace) -> None:
    """Delete VIP test credentials and resources.

    Supports two modes:

    - **Local mode** (auto-detected or ``--connect-url``): connects directly
      to a Connect server and deletes all content tagged ``_vip_test``.
    - **Cluster mode**: uses the PTD Site CR to look up credentials and runs
      the full cluster-aware cleanup (K8s secrets, etc.).

    Local mode is used when *any* of the following is true:
    - ``--connect-url`` is provided on the command line, or
    - no cluster config is present in ``vip.toml`` and a Connect URL is found
      in the config file.
    """
    from vip.config import load_config

    config = load_config()

    # Determine Connect URL and API key for local content cleanup.
    connect_url = getattr(args, "connect_url", None)
    api_key = getattr(args, "api_key", None) or os.environ.get("VIP_CONNECT_API_KEY", "")

    # Auto-detect local mode: explicit --connect-url or no cluster config.
    use_local = bool(connect_url) or not config.cluster.is_configured

    if use_local:
        # Fall back to config file values when no CLI override is supplied.
        if not connect_url and config.connect and config.connect.url:
            connect_url = config.connect.url
        if not connect_url:
            print(
                "Error: no Connect URL found. Pass --connect-url or set [connect] url in vip.toml.",
                file=sys.stderr,
            )
            sys.exit(1)

        from vip.clients.connect import ConnectClient

        print(f"Cleaning up VIP test content on Connect at {connect_url}")
        with ConnectClient(connect_url, api_key) as client:
            deleted = client.cleanup_vip_content()
        print(f"Deleted {deleted} VIP test content item(s)")
        print("Cleanup completed successfully")
        return

    # Cluster mode: requires K8s access.
    from vip.verify.credentials import cleanup_credentials
    from vip.verify.site import _extract_connect_url, fetch_site_cr

    if config.cluster.is_configured:
        _connect_cluster(config.cluster)

    site_cr = fetch_site_cr(args.site, args.namespace)
    connect_url = _extract_connect_url(site_cr)

    print(f"Cleaning up credentials for site: {args.site}")
    cleanup_credentials(args.namespace, connect_url)
    print("Cleanup completed successfully")


def main() -> None:
    """Main entry point for the VIP CLI."""
    parser = argparse.ArgumentParser(
        prog="vip", description="VIP verification and credential tools"
    )
    subparsers = parser.add_subparsers(dest="command")

    # vip auth
    auth_parser = subparsers.add_parser("auth", help="Authentication tools")
    auth_sub = auth_parser.add_subparsers(dest="auth_command")

    # vip auth mint-connect-key
    mint_parser = auth_sub.add_parser(
        "mint-connect-key",
        help="Mint a Connect API key via interactive browser login",
    )
    mint_parser.add_argument("--url", required=True, help="Connect server URL")
    mint_parser.set_defaults(func=mint_connect_key)

    # vip verify
    verify_parser = subparsers.add_parser(
        "verify",
        help="Run VIP tests against a Posit Team deployment",
        description=(
            "Run VIP tests against a Posit Team deployment.\n\n"
            "Quick start (no config file needed):\n"
            "  vip verify --connect-url https://connect.example.com\n\n"
            "A browser window opens for authentication. After login,\n"
            "tests run headlessly and the browser session is cleaned up.\n\n"
            "With an existing config file:\n"
            "  vip verify --config vip.toml --no-interactive-auth\n\n"
            "Kubernetes mode (requires posit-dev/team-operator PTD Site CR):\n"
            "  vip verify --k8s --site main --namespace posit-team\n\n"
            "Filter tests by name:\n"
            "  vip verify --connect-url https://connect.example.com --filter 'login'\n\n"
            "Any arguments after -- are passed directly to pytest:\n"
            "  vip verify --connect-url https://connect.example.com -- -x"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # URL args (no config file needed)
    url_group = verify_parser.add_argument_group("product URLs (no config file needed)")
    url_group.add_argument("--connect-url", default=None, help="Connect server URL")
    url_group.add_argument("--workbench-url", default=None, help="Workbench server URL")
    url_group.add_argument("--package-manager-url", default=None, help="Package Manager server URL")

    # TLS configuration
    tls_group = verify_parser.add_argument_group("TLS configuration")
    tls_group.add_argument(
        "--insecure",
        action="store_true",
        default=False,
        help=(
            "Disable TLS certificate verification (equivalent to curl -k). "
            "Use only in trusted environments; this silently ignores certificate errors. "
            "For Playwright browser contexts, this sets ignore_https_errors=True. "
            "Note: --ca-bundle is preferred when you have a custom CA certificate."
        ),
    )
    tls_group.add_argument(
        "--ca-bundle",
        default=None,
        metavar="PATH",
        type=Path,
        help=(
            "Path to a custom CA certificate bundle (PEM) to trust. "
            "Useful for self-signed or corporate CAs. "
            "For Playwright, sets NODE_EXTRA_CA_CERTS before launching Chromium "
            "(Chromium-level trust only; does not update the OS certificate store)."
        ),
    )

    # Config file
    verify_parser.add_argument(
        "--config",
        default=None,
        help="Path to vip.toml (default: VIP_CONFIG env var or ./vip.toml)",
    )

    # Auth
    auth_group = verify_parser.add_argument_group("authentication")
    auth_group.add_argument(
        "--idp",
        default=None,
        help='Identity provider for --headless-auth: "keycloak", "okta". '
        'Presence implies provider = "oidc" unless overridden in vip.toml.',
    )
    verify_parser.add_argument(
        "--interactive-auth",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Launch a browser for OIDC login (default: disabled, use "
        "--interactive-auth to enable)",
    )
    verify_parser.add_argument(
        "--headless-auth",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Automate login in a headless browser (OIDC/SAML/OAuth2 requires [auth] idp)",
    )
    verify_parser.add_argument(
        "--no-auth",
        action="store_true",
        default=False,
        help="Skip all tests that require authentication (Connect and Workbench)",
    )
    verify_parser.add_argument(
        "--api-auth",
        action="store_true",
        default=False,
        help="Run only API-key-authenticated tests; skip tests requiring browser credentials",
    )

    # Test selection
    verify_parser.add_argument(
        "--categories",
        default=None,
        help="Test categories as a pytest marker expression "
        "(e.g. 'connect', 'package-manager', 'workbench'). "
        "To include performance tests use --performance-tests instead.",
    )
    verify_parser.add_argument(
        "--performance-tests",
        action="store_true",
        default=False,
        help="Include performance tests in the default selection (excluded otherwise). "
        "Has no effect when --categories is also specified.",
    )
    verify_parser.add_argument(
        "-f",
        "--filter",
        default=None,
        dest="filter_expr",
        help="Filter tests by name expression, passed to pytest -k "
        "(e.g. 'test_login', 'test_login and not saml')",
    )
    verify_parser.add_argument(
        "--report",
        default="report/results.json",
        help="Write JSON results to this path for Quarto report generation"
        " (default: report/results.json)",
    )
    verify_parser.add_argument(
        "--verbose",
        action="store_true",
        default=False,
        help="Show full pytest tracebacks instead of concise error messages",
    )
    verify_parser.add_argument(
        "--extensions",
        action="append",
        default=[],
        help="Additional directories containing custom test cases (repeatable)",
    )
    verify_parser.add_argument(
        "--test-timeout",
        type=int,
        default=DEFAULT_TEST_TIMEOUT_SECONDS,
        help=(
            "Timeout in seconds for the pytest subprocess "
            f"(default: {DEFAULT_TEST_TIMEOUT_SECONDS}). "
            "A full Connect run includes content deployments that each take "
            "several minutes (R package restore, Python venv creation), so "
            "raise this further for large suites or slow servers. For "
            "per-deploy limits, set deploy_timeout under [connect] in vip.toml."
        ),
    )

    # K8s mode
    k8s_group = verify_parser.add_argument_group("Kubernetes mode")
    k8s_group.add_argument(
        "--k8s",
        action="store_true",
        default=False,
        help="Fetch config from a PTD Site CR and run tests as a K8s Job "
        "(requires posit-dev/team-operator)",
    )
    k8s_group.add_argument("--site", default="main", help="PTD Site CR name (default: main)")
    k8s_group.add_argument(
        "--namespace",
        default="posit-team",
        help="Kubernetes namespace (default: posit-team)",
    )
    k8s_group.add_argument(
        "--name",
        default=None,
        help="Deployment name for reports (default: Posit Team)",
    )
    k8s_group.add_argument(
        "--image",
        default="ghcr.io/posit-dev/vip:latest",
        help="VIP container image (default: ghcr.io/posit-dev/vip:latest)",
    )
    k8s_group.add_argument(
        "--timeout",
        type=int,
        default=900,
        help="Job timeout in seconds (default: 900)",
    )
    k8s_group.add_argument(
        "--config-only",
        action="store_true",
        default=False,
        help="Generate config from PTD Site CR and print it (no tests run)",
    )

    # Pytest passthrough
    verify_parser.add_argument(
        "pytest_args",
        nargs="*",
        default=[],
        help="Additional arguments passed to pytest (place after --)",
    )
    verify_parser.set_defaults(func=run_verify)

    # vip cleanup
    cleanup_parser = subparsers.add_parser(
        "cleanup",
        help="Delete VIP test credentials and resources",
        description=(
            "Delete VIP test credentials and resources.\n\n"
            "Local mode (auto-detected when no cluster config is present):\n"
            "  vip cleanup --connect-url https://connect.example.com\n\n"
            "Cluster mode (requires K8s access and PTD Site CR):\n"
            "  vip cleanup --site main --namespace posit-team\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    local_group = cleanup_parser.add_argument_group(
        "local mode (Connect content cleanup, no K8s required)"
    )
    local_group.add_argument(
        "--connect-url",
        default=None,
        help="Connect server URL (enables local mode; falls back to vip.toml if omitted)",
    )
    local_group.add_argument(
        "--api-key",
        default=None,
        help="Connect API key (default: VIP_CONNECT_API_KEY env var)",
    )
    cluster_group = cleanup_parser.add_argument_group("cluster mode (K8s credential cleanup)")
    cluster_group.add_argument("--site", default="main", help="PTD Site CR name (default: main)")
    cluster_group.add_argument(
        "--namespace",
        default="posit-team",
        help="Kubernetes namespace (default: posit-team)",
    )
    cleanup_parser.set_defaults(func=run_cleanup)

    # vip install
    install_parser = subparsers.add_parser(
        "install",
        help="Install system packages and Playwright Chromium",
        description=(
            "Install VIP's machine-side dependencies: Chromium runtime libraries "
            "(via dnf or apt) and Playwright's Chromium browser. "
            "Records what was installed in .vip-install.json so vip uninstall can "
            "reverse only what this command added."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    install_parser.add_argument(
        "--skip-system",
        action="store_true",
        default=False,
        help=(
            "Skip the system-package step. VIP will not record those packages in "
            ".vip-install.json, so vip uninstall will not propose removing them. "
            "Use this when you manage system packages yourself or don't have sudo."
        ),
    )
    install_parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Print the plan without executing.",
    )
    install_parser.set_defaults(func=run_install)

    # vip uninstall
    uninstall_parser = subparsers.add_parser(
        "uninstall",
        help="Reverse vip install (dry-run by default; --yes to execute)",
        description=(
            "Reverse vip install using the per-project .vip-install.json manifest. "
            "Removes the Playwright cache and manifest; prints the sudo command for "
            "any system packages vip recorded so you can remove them yourself. "
            "Always prints a dry-run plan; pass --yes to execute the user-space steps."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    uninstall_parser.add_argument("--yes", action="store_true", default=False)
    uninstall_parser.add_argument("--force-host", action="store_true", default=False)
    uninstall_parser.add_argument(
        "--connect-url",
        default=None,
        help="Connect URL for chained vip cleanup (default: config / autodetect).",
    )
    uninstall_parser.add_argument("--api-key", default=None)
    uninstall_parser.set_defaults(func=run_uninstall)

    # vip cluster
    cluster_parser = subparsers.add_parser("cluster", help="Cluster connection tools")
    cluster_sub = cluster_parser.add_subparsers(dest="cluster_command")

    # vip cluster connect
    connect_parser = cluster_sub.add_parser("connect", help="Generate kubeconfig for a cluster")
    connect_parser.add_argument("--provider", help="Cloud provider (aws or azure)")
    connect_parser.add_argument("--cluster-name", help="Cluster name")
    connect_parser.add_argument("--region", help="Cloud region (AWS)")
    connect_parser.add_argument("--resource-group", help="Resource group (Azure)")
    connect_parser.add_argument("--subscription-id", help="Subscription ID (Azure)")
    connect_parser.add_argument("--profile", help="AWS profile name")
    connect_parser.set_defaults(func=connect_to_cluster)

    # vip report
    report_parser = subparsers.add_parser(
        "report",
        help="Render the Quarto report from a results.json file",
    )
    report_parser.add_argument(
        "--results",
        default="report/results.json",
        help="Path to results.json (default: report/results.json)",
    )
    report_parser.add_argument(
        "--open",
        action="store_true",
        default=False,
        help="Open the rendered report in a browser after rendering",
    )
    report_parser.set_defaults(func=run_report)

    # vip status
    status_parser = subparsers.add_parser(
        "status",
        help="Check health endpoints for each configured product",
    )
    status_parser.add_argument(
        "--config",
        default=None,
        help="Path to vip.toml (default: VIP_CONFIG env var or ./vip.toml)",
    )
    status_parser.set_defaults(func=run_status)

    # vip app
    app_parser = subparsers.add_parser(
        "app",
        help="Launch the VIP Shiny app (graphical test runner)",
    )
    app_parser.add_argument(
        "--config",
        default=None,
        help="Path to vip.toml (passed to the app as default config)",
    )
    app_parser.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    app_parser.add_argument("--port", type=int, default=0, help="Port (default: auto)")
    app_parser.add_argument(
        "--no-browser",
        action="store_true",
        default=False,
        help="Don't open a browser window automatically",
    )
    app_parser.set_defaults(func=run_app)

    # Map command names to their parsers for context-appropriate help
    subcommand_parsers = {
        "verify": verify_parser,
        "cleanup": cleanup_parser,
        "install": install_parser,
        "uninstall": uninstall_parser,
        "auth": auth_parser,
        "cluster": cluster_parser,
        "report": report_parser,
        "status": status_parser,
        "app": app_parser,
    }

    args = parser.parse_args()
    if not hasattr(args, "func"):
        sub = subcommand_parsers.get(args.command)
        if sub:
            sub.print_help()
        else:
            parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
