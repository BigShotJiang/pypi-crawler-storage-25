"""calc_inductance.py -- unified coil inductance (vacuum + weak-coupled).

Layer 4 subprocess for the IH "Inductance" panel.  Replaces three
scoped CLIs that overlapped on workflow but differed on coil solver:

  * calc_peec_inductance.py        -> --coil-solver peec, --vol omitted
  * calc_peec_bem.py               -> --coil-solver peec, --vol present
  * calc_coil_bem_a_workpiece.py   -> --coil-solver bem-a, --vol present

Coil solver (``--coil-solver``):
  * ``peec`` : PEEC perimeter filaments + Loop-bundle solve.
               Fast (~10x BEM-A); n_peri-discretisation-limited (~3% under
               on rect cross-section at n_peri=16 vs converged BEM-A).
  * ``bem-a``: intree Weggler stabilized EFIE on HDivSurface RWG
               (Phase C.1-C.5).  Surface-current physics, n_peri-free.

Workpiece is OPTIONAL.  Without ``--vol`` the script returns only the
vacuum coil L_coil + R_coil.  With ``--vol`` it adds weak-coupled BEM-SIBC:
gauge-invariant Telegen φ·(n·B_inc) ΔL captures the workpiece's
back-reaction at the port level (coil current distribution is NOT
recomputed — that is "strong coupling", available via FEM A-V in
calc_fem_coilmesh.py).

Coupling terminology (corrected 2026-05-02):
  * **weak coupling** = back-reacted Telegen ΔL is computed; coil source
    distribution FIXED.  Default and only mode here.
  * **one-way (forward)** = only P_wp; no ΔL.  Not exposed: weak is a
    strict superset at no extra cost.
  * **strong coupling** = coil source recomputed iteratively in response
    to workpiece reflection.  Use calc_fem_coilmesh.py.

Output: JSON to stdout (calc_main contract).
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time

import numpy as np


def _detect_vol_curving_order(vol_path: str) -> int:
    """Read companion ``<vol_path>.json`` (written by Cubit's
    ``radia_export netgen``) to find the curving order baked into the
    .vol.  Returns the integer ``order`` field, or 1 if the companion
    JSON is missing / malformed (= flat, safe default).

    This is the SOURCE OF TRUTH for the workpiece BEM basis order in
    ``calc_inductance.py``: the .vol's ``curvedelements`` is fixed at
    Cubit-export time, and trying to upgrade via ``mesh.Curve(p)``
    after-the-fact silently falls back to flat without a CAD callback.
    """
    json_path = vol_path + ".json"
    if not os.path.isfile(json_path):
        return 1
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        order = int(data.get("order", 1))
        return max(1, order)
    except (OSError, ValueError, KeyError):
        return 1


HERE = os.path.dirname(os.path.abspath(__file__))
SRC_RADIA = os.path.abspath(os.path.join(HERE, ".."))
for p in (SRC_RADIA, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from calc_common import calc_main, progress  # noqa: E402


MU_0 = 4.0e-7 * math.pi
INV_4PI = 1.0 / (4.0 * math.pi)


# ======================================================================
# Coil solver: PEEC
# ======================================================================
def _solve_coil_peec(args):
    """PEEC coil layer.

    Returns a dict with:
      * L_coil [H], R_coil [Ω] at unit terminal current
      * source_type = "filament"
      * paths : list of filament polylines (m)
      * I_fil : (K,) complex per-filament current at args.current
      * t_coil_s, n_filaments
    """
    progress("PEEC", f"STEP -> perimeter filaments (n_peri={args.peec_n_peri})")
    from coil_from_cad import filaments_from_step
    from peec_bundle import build_loop_bundle_impedance, solve_loop_bundle

    omega = 2.0 * math.pi * args.frequency
    t0 = time.perf_counter()
    topo = filaments_from_step(args.coil_step,
                               sigma=args.coil_sigma,
                               n_peri=args.peec_n_peri,
                               use_coil_builder=True)
    paths = topo["filament_paths"]
    seg_of_fil = topo["seg_of_filament"]
    solver = topo["solver"]
    t_topo = time.perf_counter() - t0
    progress("PEEC", f"{len(paths)} filaments ({t_topo:.1f}s)")

    progress("PEEC", f"Loop-bundle solve @ {args.frequency:.0f} Hz")
    t0 = time.perf_counter()
    R_f, L_f = build_loop_bundle_impedance(solver, seg_of_fil)
    I_fil, V_port = solve_loop_bundle(R_f, L_f, args.frequency,
                                       I_port=args.current)
    t_peec = time.perf_counter() - t0
    Z_coil = V_port / args.current
    L_coil = Z_coil.imag / omega if omega > 0 else 0.0
    R_coil = Z_coil.real
    progress("PEEC", f"L_coil={L_coil * 1e9:.3f} nH, "
                      f"R_coil={R_coil * 1e3:.4f} mΩ ({t_peec:.1f}s)")

    return {
        "source_type": "filament",
        "L_coil": L_coil, "R_coil": R_coil,
        "paths": paths, "I_fil": I_fil,
        "n_filaments": len(paths),
        "t_coil_topology_s": t_topo,
        "t_coil_solve_s": t_peec,
    }


# ======================================================================
# Coil solver: BEM-A (intree Weggler EFIE saddle on RWG)
# ======================================================================
def _build_bema_coil_mesh(args):
    """Coil STEP -> NGSolve OCC mesh with source/sink labelling.

    Resolution order:
      1. Match face.name == args.coil_source_name / args.coil_sink_name.
      2. Auto-area fallback: 2 smallest PLANE faces, distinguished by
         |y-centroid| (matches all current test fixtures).
    """
    from netgen.occ import OCCGeometry, Glue
    from netgen.meshing import MeshingParameters
    from ngsolve import Mesh

    geo = OCCGeometry(args.coil_step)
    shape = geo.shape
    faces = list(shape.faces)
    src_idx = snk_idx = None
    for i, f in enumerate(faces):
        nm = getattr(f, "name", None)
        if nm == args.coil_source_name and src_idx is None:
            src_idx = i
        elif nm == args.coil_sink_name and snk_idx is None:
            snk_idx = i

    if src_idx is None or snk_idx is None:
        try:
            fs_sorted = sorted(enumerate(faces), key=lambda x: x[1].mass)
        except Exception as exc:
            raise ValueError(
                f"could not sort coil faces by mass: {exc}.  "
                f"Set face.name = {args.coil_source_name!r}/"
                f"{args.coil_sink_name!r} in build123d before export.")
        ca, fa = fs_sorted[0]
        cb, fb = fs_sorted[1]
        if abs(fa.center[1]) < abs(fb.center[1]):
            src_idx, snk_idx = ca, cb
        else:
            src_idx, snk_idx = cb, ca

    for i, f in enumerate(faces):
        if i == src_idx:
            f.name = "source"
        elif i == snk_idx:
            f.name = "sink"
        else:
            f.name = "body"

    ngmesh = OCCGeometry(Glue(faces)).GenerateMesh(
        mp=MeshingParameters(maxh=args.coil_maxh, curvaturesafety=1.0,
                              segmentsperedge=1))
    return Mesh(ngmesh)


def _arrays_from_bema_coil_mesh(mesh):
    """Extract verts / tris / source-mask / sink-mask arrays."""
    from ngsolve import BND
    n_v = mesh.nv
    verts = np.empty((n_v, 3), dtype=np.float64)
    for i in range(n_v):
        verts[i] = [mesh.vertices[i].point[k] for k in range(3)]
    bnd_names = list(mesh.GetBoundaries())
    src_idx = {i for i, n in enumerate(bnd_names) if n == "source"}
    snk_idx = {i for i, n in enumerate(bnd_names) if n == "sink"}
    tris, src_mask, snk_mask = [], [], []
    for el in mesh.Elements(BND):
        tris.append([int(v.nr) for v in el.vertices])
        src_mask.append(el.index in src_idx)
        snk_mask.append(el.index in snk_idx)
    return (verts, np.array(tris, dtype=np.int64),
            np.array(src_mask, dtype=bool),
            np.array(snk_mask, dtype=bool))


def _solve_coil_bem_a(args):
    """BEM-A coil layer via ngsolve.bem (Weggler EFIE saddle on HDivSurface RT0).

    Replaced the intree pure-Python assembler 2026-05-03 after benchmarks
    showed ngsolve.bem was 50-60x faster across all tested sizes.  See
    ``src/radia/bem/coil_inductance_ngsolve.py`` docstring for the full
    rationale.

    Returns a dict with:
      * L_coil [H], R_coil [Ω] at unit terminal current  (R is AC SIBC)
      * source_type = "surface"
      * coil_centroids (n_t, 3), coil_areas (n_t,), coil_J_per_tri (n_t, 3)
        -- all REAL; multiply by complex args.current downstream as needed
      * coil_residual, coil_mesh_nv, coil_mesh_n_tris
    """
    from radia.bem.coil_inductance_ngsolve import (
        compute_inductance_source_sink, compute_centroids_areas_J)

    omega = 2.0 * math.pi * args.frequency
    progress("BEMA", f"coil STEP -> mesh maxh={args.coil_maxh}")
    t0 = time.perf_counter()
    coil_mesh = _build_bema_coil_mesh(args)
    # We still extract verts/tris/masks for diagnostics + N_tris reporting.
    coil_verts, coil_tris, src_mask, snk_mask = \
        _arrays_from_bema_coil_mesh(coil_mesh)
    t_mesh = time.perf_counter() - t0
    progress("BEMA",
        f"coil nv={coil_mesh.nv} n_tris={len(coil_tris)} "
        f"src/snk={int(src_mask.sum())}/{int(snk_mask.sum())} "
        f"({t_mesh:.1f}s)")
    if int(src_mask.sum()) == 0 or int(snk_mask.sum()) == 0:
        raise RuntimeError(
            f"coil source/sink mesh empty after labelling "
            f"(src={int(src_mask.sum())}, snk={int(snk_mask.sum())}).  "
            f"Set face.name = {args.coil_source_name!r}/{args.coil_sink_name!r} "
            f"in build123d, or use a STEP whose 2 smallest PLANE faces are caps.")

    delta_skin = math.sqrt(2.0 / (omega * MU_0 * args.coil_sigma)) \
                  if omega > 0 else 1.0
    Z_s_coil_re = 1.0 / (args.coil_sigma * delta_skin) if omega > 0 else 0.0
    progress("BEMA",
        f"ngsolve.bem solve (n_tris={len(coil_tris)}, "
        f"fes_order=0, Z_s_re={Z_s_coil_re:.3e})")
    t0 = time.perf_counter()
    res = compute_inductance_source_sink(
        coil_mesh,
        source_label=args.coil_source_name,
        sink_label=args.coil_sink_name,
        fes_order=0,
        solver="lu",
        Z_s_re=Z_s_coil_re,
    )
    t_solve = time.perf_counter() - t0
    if "error" in res:
        raise RuntimeError(f"BEM-A solve failed: {res['error']}")
    L_coil = float(res["L"])
    R_coil = float(res["R"])
    residual = float(res["residual"])
    progress("BEMA",
        f"L_coil={L_coil * 1e9:.3f} nH, R_coil(SIBC)={R_coil * 1e3:.4f} mΩ "
        f"residual={residual:.2e} ({t_solve:.1f}s)")

    # Per-triangle J_s vectors at centroids (workpiece bridge prep).
    # NGSolve element-wise Integrate of gf_J components / element area.
    coil_centroids, coil_areas, coil_J_per_tri = compute_centroids_areas_J(
        coil_mesh, res["gf_J"])

    return {
        "source_type": "surface",
        "L_coil": L_coil, "R_coil": R_coil,
        "coil_centroids": coil_centroids,
        "coil_areas": coil_areas,
        "coil_J_per_tri": coil_J_per_tri,
        "coil_mesh_nv": int(coil_mesh.nv),
        "coil_mesh_n_tris": int(len(coil_tris)),
        "coil_mesh_n_src_tris": int(src_mask.sum()),
        "coil_mesh_n_snk_tris": int(snk_mask.sum()),
        "bem_a_residual": residual,
        "t_coil_topology_s": t_mesh,
        "t_coil_solve_s": t_solve,
    }


# ======================================================================
# Surface-current Biot-Savart helpers (mirror compute_phi_inc_from_surface_J
# but accept complex J -- output complex H -- for Telegen ΔL evaluation
# in the BEM-A coil case)
# ======================================================================
def _H_from_surface_J_complex(eval_pts, src_centroids, src_areas, src_J_complex):
    """Vectorised Biot-Savart H from a complex surface-current source.

    H(r) = (1/4π) Σ_t [J_t × (r - c_t)] / |r - c_t|^3 * A_t
    """
    dx = eval_pts[:, None, :] - src_centroids[None, :, :]
    r2 = np.sum(dx * dx, axis=2)
    r2 = np.maximum(r2, 1e-60)
    r3_inv = src_areas[None, :] / (r2 * np.sqrt(r2))
    cross = np.cross(src_J_complex[None, :, :], dx)
    return INV_4PI * np.sum(cross * r3_inv[..., None], axis=1)


def _delta_L_telegen_phiB_from_surface_J(
        coil_centroids, coil_areas, coil_J_complex,
        wp_centroids, wp_areas, wp_norms, wp_phi_avg, I_port):
    """Gauge-invariant Δ L_port via ∫_S φ (n · B_inc) dS, surface-J source.

    Parallel to ``radia.workpiece_surface.delta_L_telegen_phiB`` but for
    BEM-A surface-current coil.  1-point centroid quadrature for B_inc.
    """
    H_inc = _H_from_surface_J_complex(
        wp_centroids, coil_centroids, coil_areas, coil_J_complex)
    B_inc = MU_0 * H_inc
    n_dot_B = np.sum(wp_norms * B_inc, axis=1)
    integ = np.sum(wp_phi_avg * n_dot_B * wp_areas)
    Ip = complex(I_port)
    if abs(Ip) < 1e-30:
        return 0.0 + 0.0j
    return integ / (Ip * Ip)


# ======================================================================
# Workpiece weak-coupled BEM-SIBC block (shared by both coil solvers)
# ======================================================================
def _solve_workpiece_weak_coupled(args, coil_data):
    """Workpiece BEM-SIBC + Telegen ΔL using whichever coil source exists.

    Branches on coil_data["source_type"] for both phi_inc bridge and
    Telegen evaluation:
      * "filament" -> compute_phi_inc_from_filaments + delta_L_telegen_phiB
      * "surface"  -> compute_phi_inc_from_surface_J + _delta_L_telegen_phiB_from_surface_J
    """
    from ngsolve import (Mesh, BND, Integrate, CF, GridFunction,
                          InnerProduct, grad)
    from ngsolve import (specialcf as _scf, BND as _BND,
                          Integrate as _Int, CF as _CF, GridFunction as _GF)
    from surface_mesh_extract import _extract_surface_mesh_filtered
    from radia.bem_sibc_solver import (
        ScalarBIESIBCSolver, compute_phi_inc_from_filaments,
        compute_phi_inc_from_surface_J)
    from em_material import EMMaterial
    # Re-use the hole-extractor from calc_peec_bem (will be inlined when
    # calc_peec_bem is deleted in the same commit; for the transition
    # window keep importing from there until removal).
    try:
        from calc_peec_bem import _extract_bnd_only
    except ImportError:
        # Inline if calc_peec_bem.py has been deleted (Refactor C step).
        _extract_bnd_only = _extract_bnd_only_inline

    omega = 2.0 * math.pi * args.frequency

    # 1. Workpiece mesh
    progress("BEM", f"load wp surface from {os.path.basename(args.vol)}")
    t0 = time.perf_counter()
    vol_mesh = Mesh(args.vol)
    mats = set(vol_mesh.GetMaterials())
    bnds = set(vol_mesh.GetBoundaries())

    # Detect the .vol's baked-in curving order from companion .vol.json
    # (written by Cubit ``radia_export netgen``).  The .vol's
    # ``curvedelements`` section is loaded automatically by Mesh(); a
    # post-load ``mesh.Curve(p)`` would try to UPGRADE and, without a
    # CAD callback, silently fall back to flat -- so we never call it.
    # The curve order is FIXED at Cubit-export time and is not a panel
    # knob.  Capped at 2 for the Lagrange-P2 in-tree assembler (the C++
    # Tri6 geometry kernel takes 6 nodes / tri, so a curve_order=3 .vol
    # is treated as Tri6 here -- the extra mid-face / interior nodes
    # are not currently used by the SS BIE assembler).
    vol_curve_order = min(_detect_vol_curving_order(args.vol), 2)
    # Basis order is a separate, user-selectable knob (--h1-order), not
    # tied to the geometry order.  P1 + P2 supported.
    basis_order = int(args.h1_order)
    if basis_order not in (1, 2):
        raise ValueError(
            f"--h1-order must be 1 or 2 (got {basis_order}).  P3+ "
            f"basis is not implemented in the in-tree Lagrange "
            f"assembler.")
    progress("BEM",
        f"vol curve_order={vol_curve_order} "
        f"(from {os.path.basename(args.vol)}.json), "
        f"basis_order={basis_order} (--h1-order)")
    # The Lagrange-P2 path (basis_order=2) builds M, K, SL, DL all in the
    # in-tree P2 basis directly off the parent vol_mesh's curved Tri6
    # nodes; it requires a sideset bnd_label so it can filter the parent
    # mesh's BND.
    if basis_order >= 2 and args.wp_label not in bnds:
        raise ValueError(
            f"--h1-order=2 requires --wp-label to name a boundary "
            f"sideset (got {args.wp_label!r}, available BND labels: "
            f"{sorted(bnds)}).  Material-adjacency wp_label is only "
            f"supported with basis_order=1 (flat-FES path).")

    if args.wp_label in mats:
        progress("BEM", f"wp_label {args.wp_label!r} as material")
        wp_mesh, _wp_new_to_old = _extract_surface_mesh_filtered(
            vol_mesh, keep_label=args.wp_label, return_vertex_map=True)
    elif args.wp_label in bnds:
        progress("BEM", f"wp_label {args.wp_label!r} as boundary sideset")
        wp_mesh = _extract_bnd_only(vol_mesh, args.wp_label)
        _wp_new_to_old = None
    else:
        raise ValueError(
            f"wp_label {args.wp_label!r} not found in materials "
            f"({sorted(mats)}) or boundaries ({sorted(bnds)})")
    t_wp_mesh = time.perf_counter() - t0
    progress("BEM",
        f"wp nv={wp_mesh.nv} ne(BND)={wp_mesh.GetNE(BND)} ({t_wp_mesh:.1f}s)")

    # 2. Solver gating
    if args.impedance_model == "esim":
        raise NotImplementedError(
            "ESIM is not implemented in calc_inductance.  Use "
            "--impedance-model sibc.  For nonlinear BH consider "
            "calc_fem_coilmesh.py.")

    # 3. ScalarBIESIBCSolver assembly.
    #
    # Two independent knobs feed the solver:
    #   * vol_curve_order : geometry order (auto-detected from .vol.json).
    #     Forwarded as ``intree_geom_order``.
    #   * basis_order     : Lagrange basis order (user-selectable, --h1-order).
    #     Forwarded as ``order``.
    #
    # When basis_order=2 the in-tree Lagrange-P2 path bypasses NGSolve's
    # H1 hierarchical FES entirely and routes through the parent
    # ``vol_mesh`` (whose ``curvedelements`` is already loaded) plus the
    # ``bnd_label`` filter; the extracted flat ``wp_mesh`` is used only
    # for post-processing (Telegen per-element ΔL averaging).
    # When basis_order=1 we keep the existing flat-extracted wp_mesh
    # path; H1+ngsolve.bem trace integration runs on flat triangles
    # consistent with the P1 hat (curving has no benefit at P1 since the
    # basis cannot resolve geometric curvature).
    use_curved_p2 = (basis_order >= 2)
    bem_input_mesh = vol_mesh if use_curved_p2 else wp_mesh
    bem_bnd_label = args.wp_label if use_curved_p2 else None
    progress("BEM",
        f"assembly (basis_order={basis_order}, "
        f"vol_curve_order={vol_curve_order}, "
        f"backend={args.wp_bem_backend}, "
        f"input_mesh={'vol_mesh+bnd_label' if use_curved_p2 else 'wp_mesh'})")
    t0 = time.perf_counter()
    if args.wp_bem_backend == "intree-dense":
        bem = ScalarBIESIBCSolver(
            bem_input_mesh, order=basis_order, assemble_dense=True,
            use_intree_bem=True, intree_geom_order=vol_curve_order,
            intree_singular_n_q=6, intree_regular_quad_degree=7,
            bnd_label=bem_bnd_label)
    elif args.wp_bem_backend == "hacapk":
        bem = ScalarBIESIBCSolver(
            bem_input_mesh, order=basis_order, assemble_dense=True,
            use_intree_bem=True, intree_geom_order=vol_curve_order,
            intree_singular_n_q=6, intree_regular_quad_degree=7,
            use_intree_hacapk=True,
            hacapk_aca_eps=args.wp_aca_eps,
            hacapk_leaf=64, hacapk_eta=2.0,
            bnd_label=bem_bnd_label)
    else:
        raise ValueError(
            f"unknown --wp-bem-backend {args.wp_bem_backend!r}; "
            f"supported: 'hacapk' (production), 'intree-dense' (debug).")
    t_asm = time.perf_counter() - t0
    progress("BEM", f"ndof={bem.ndof} ({t_asm:.1f}s)")

    # 4. phi_inc on workpiece — branch on coil source type
    if getattr(bem, "_intree_lagrange_p2", False):
        obs = np.ascontiguousarray(bem.dof_coords)
    else:
        obs = np.array([[wp_mesh.vertices[i].point[j] for j in range(3)]
                         for i in range(wp_mesh.nv)])
    progress("BEM", f"phi_inc from coil ({coil_data['source_type']})")
    t0 = time.perf_counter()
    if coil_data["source_type"] == "filament":
        phi_inc = compute_phi_inc_from_filaments(
            obs, coil_data["paths"], coil_data["I_fil"])
    elif coil_data["source_type"] == "surface":
        # Multiply real surface J by terminal current (complex if needed).
        coil_J_complex = (complex(args.current)
                           * coil_data["coil_J_per_tri"]).astype(complex)
        phi_re = compute_phi_inc_from_surface_J(
            obs, coil_data["coil_centroids"], coil_data["coil_areas"],
            np.real(coil_J_complex))
        phi_im = compute_phi_inc_from_surface_J(
            obs, coil_data["coil_centroids"], coil_data["coil_areas"],
            np.imag(coil_J_complex))
        phi_inc = phi_re + 1j * phi_im
    else:
        raise RuntimeError(
            f"unknown coil source_type {coil_data['source_type']!r}")
    t_phi = time.perf_counter() - t0
    progress("BEM", f"phi_inc ({t_phi:.1f}s)")

    # 5. Workpiece SIBC: BIE solve
    mat_wp = EMMaterial(name="wp", sigma=args.sigma, mu_r=args.mu_r)
    delta_wp = mat_wp.skin_depth(args.frequency)
    rho_wp = 1.0 / args.sigma
    Z_s_wp = (1.0 + 1j) * rho_wp / delta_wp * math.sqrt(args.mu_r)

    progress("BEM",
        f"BIE solve Z_s={Z_s_wp:.3e} (model={args.impedance_model})")
    t0 = time.perf_counter()
    if args.wp_bem_backend == "intree-dense":
        res_bem = bem.solve(phi_inc, Z_s=Z_s_wp, omega=omega)
    else:
        res_bem = bem.solve_hacapk(
            phi_inc, Z_s=Z_s_wp, omega=omega,
            tol=args.wp_gmres_tol, maxiter=500, restart=80)
    t_bie = time.perf_counter() - t0
    info = res_bem.get("gmres_info", 0)
    progress("BEM", f"BIE ({t_bie:.1f}s, gmres info={info})")

    # 6. Workpiece scalar outputs
    A_wp = float(Integrate(CF(1), wp_mesh, VOL_or_BND=BND).real)
    P_wp = float(res_bem["P_density"] * A_wp)
    H_t_rms = float(res_bem["H_t_rms"])
    wp_dissipation_R_mOhm = 2.0 * P_wp / (args.current ** 2) * 1e3

    # 7. Telegen ΔL via φ·B form -- aggregate per-triangle wp data first.
    # Two post-proc paths:
    #   * P1 (basis_order=1): phi_vec is indexed by wp_mesh vertices;
    #     bem.fes is the wp_mesh H1 FES; use NGSolve element_wise integrals.
    #   * P2 (basis_order>=2): phi_vec is indexed by Lagrange P2 DOFs on
    #     the parent vol_mesh BND; bem.fes is None.  Build phi-at-wp-
    #     vertices by matching wp_mesh.vertices coords to solver vertex
    #     DOFs (the first n_v entries of dof_coords), then average over
    #     each flat wp_mesh triangle (corner-mean = area-weighted P1 mean).
    n_cf = _scf.normal(3)
    elem_A_int = _Int(_CF(1), wp_mesh, VOL_or_BND=_BND, element_wise=True)
    n_int = [_Int(n_cf[i], wp_mesh, VOL_or_BND=_BND, element_wise=True)
              for i in range(3)]

    if basis_order >= 2:
        # Build phi-at-wp-vertices via coordinate match.
        n_v_solver = len(bem._intree_v_global)
        solver_vert_coords = np.asarray(bem.dof_coords[:n_v_solver])
        coord_to_dof = {}
        for i in range(n_v_solver):
            key = (round(solver_vert_coords[i, 0], 12),
                   round(solver_vert_coords[i, 1], 12),
                   round(solver_vert_coords[i, 2], 12))
            coord_to_dof[key] = i
        phi_at_wp = np.zeros(wp_mesh.nv, dtype=complex)
        n_missed = 0
        for i in range(wp_mesh.nv):
            p = wp_mesh.vertices[i].point
            key = (round(p[0], 12), round(p[1], 12), round(p[2], 12))
            j = coord_to_dof.get(key)
            if j is None:
                n_missed += 1
                continue
            phi_at_wp[i] = res_bem["phi_vec"][j]
        if n_missed > 0:
            raise RuntimeError(
                f"P2 post-proc: {n_missed}/{wp_mesh.nv} wp vertices did "
                f"not match any solver vertex DOF coord.  This indicates "
                f"the extracted wp_mesh vertices and the parent vol_mesh "
                f"BND={args.wp_label!r} vertices are not coincident.")
        wp_phi_re_at_v = phi_at_wp.real
        wp_phi_im_at_v = phi_at_wp.imag
        phi_re_int = None  # not used in this branch
        phi_im_int = None
    else:
        gf_phi_re = _GF(bem.fes)
        gf_phi_re.vec.FV().NumPy()[:] = res_bem["phi_vec"].real
        gf_phi_im = _GF(bem.fes)
        gf_phi_im.vec.FV().NumPy()[:] = res_bem["phi_vec"].imag
        phi_re_int = _Int(gf_phi_re, wp_mesh, VOL_or_BND=_BND,
                           element_wise=True)
        phi_im_int = _Int(gf_phi_im, wp_mesh, VOL_or_BND=_BND,
                           element_wise=True)
        wp_phi_re_at_v = wp_phi_im_at_v = None

    wp_centroids_l, wp_areas_l, wp_norms_l, wp_phi_avg_l = [], [], [], []
    for el in wp_mesh.Elements(_BND):
        a = abs(elem_A_int[el.nr])
        if a < 1e-30:
            continue
        pts = [wp_mesh.vertices[v.nr].point for v in el.vertices]
        c = np.mean([(p[0], p[1], p[2]) for p in pts], axis=0)
        n_at_el = np.array([n_int[i][el.nr] / a for i in range(3)])
        if basis_order >= 2:
            corner_phi_re = np.array(
                [wp_phi_re_at_v[v.nr] for v in el.vertices])
            corner_phi_im = np.array(
                [wp_phi_im_at_v[v.nr] for v in el.vertices])
            phi_avg = corner_phi_re.mean() + 1j * corner_phi_im.mean()
        else:
            phi_avg = (phi_re_int[el.nr] + 1j * phi_im_int[el.nr]) / a
        wp_centroids_l.append(c); wp_areas_l.append(a)
        wp_norms_l.append(n_at_el); wp_phi_avg_l.append(phi_avg)
    wp_centroids_arr = np.asarray(wp_centroids_l, dtype=float)
    wp_areas_arr = np.asarray(wp_areas_l, dtype=float)
    wp_norms_arr = np.asarray(wp_norms_l, dtype=float)
    wp_phi_avg_arr = np.asarray(wp_phi_avg_l, dtype=complex)

    # 8. Telegen ΔL — branch again on coil source type
    if coil_data["source_type"] == "filament":
        from radia.workpiece_surface import delta_L_telegen_phiB
        delta_L_complex = delta_L_telegen_phiB(
            coil_data["paths"], coil_data["I_fil"],
            wp_centroids_arr, wp_areas_arr, wp_norms_arr, wp_phi_avg_arr,
            I_port=args.current)
    else:  # surface
        coil_J_complex = (complex(args.current)
                           * coil_data["coil_J_per_tri"]).astype(complex)
        delta_L_complex = _delta_L_telegen_phiB_from_surface_J(
            coil_data["coil_centroids"], coil_data["coil_areas"],
            coil_J_complex,
            wp_centroids_arr, wp_areas_arr, wp_norms_arr, wp_phi_avg_arr,
            I_port=args.current)
    delta_L_nH = float(delta_L_complex.real) * 1e9
    delta_R_mOhm = -float(delta_L_complex.imag) * omega * 1e3
    progress("BEM",
        f"P_wp={P_wp:.4e} W ΔL={delta_L_nH:+.3f} nH ΔR={delta_R_mOhm:+.4f} mΩ")

    # 9. Optional .msh output
    msh_file = ""
    if args.msh_output:
        try:
            from radia.gmsh_post_export import GmshPostExport
            post = GmshPostExport(wp_mesh, boundary=True)
            post.write(args.msh_output)
            msh_file = args.msh_output
            progress("BEM", f"wp .msh written: {args.msh_output}")
        except Exception as exc:
            progress("BEM", f"msh export failed: {exc}")

    return {
        "P_wp": P_wp, "H_t_rms": H_t_rms, "A_wp": A_wp,
        "delta_L_nH": delta_L_nH, "delta_R_mOhm": delta_R_mOhm,
        "wp_dissipation_R_mOhm": wp_dissipation_R_mOhm,
        "wp_mesh_nv": int(wp_mesh.nv),
        "wp_mesh_n_tris": int(wp_mesh.GetNE(BND)),
        "wp_gmres_info": int(info),
        "Z_s_wp_real": float(Z_s_wp.real),
        "Z_s_wp_imag": float(Z_s_wp.imag),
        "skin_depth_wp_mm": float(delta_wp * 1e3),
        "msh_file": msh_file,
        "t_wp_mesh_s": t_wp_mesh,
        "t_bem_assembly_s": t_asm,
        "t_phi_inc_s": t_phi,
        "t_bem_solve_s": t_bie,
    }


def _extract_bnd_only_inline(vol_mesh, bnd_label):
    """Local copy of the calc_peec_bem.py helper.

    Falls back when calc_peec_bem.py has been deleted as part of the
    same commit (Refactor C).  Walks the .vol mesh, collects BND
    elements whose ``el.index`` matches a FD with name ``bnd_label``,
    and emits a closed surface mesh with outward-oriented triangles
    (centroid-aligned for the wp-as-hole convention).
    """
    from ngsolve import Mesh, BND
    import netgen.meshing as ngm

    bnd_labels = list(vol_mesh.GetBoundaries())
    target_indices = {i for i, n in enumerate(bnd_labels) if n == bnd_label}
    if not target_indices:
        raise ValueError(
            f"Boundary label {bnd_label!r} not found in .vol.  "
            f"Available: {sorted(set(bnd_labels))}")

    ngmesh_new = ngm.Mesh(dim=3)
    ngmesh_new.Add(ngm.FaceDescriptor(bc=1, domin=1))
    ngmesh_new.SetBCName(0, bnd_label)

    used_vtx = set()
    for el in vol_mesh.Elements(BND):
        if el.index in target_indices:
            for v in el.vertices:
                used_vtx.add(v.nr)
    if not used_vtx:
        raise ValueError(
            f"No BND elements found with label {bnd_label!r}")

    old_to_new = {}
    for old in sorted(used_vtx):
        p = vol_mesh.vertices[old].point
        old_to_new[old] = ngmesh_new.Add(
            ngm.MeshPoint(ngm.Pnt(p[0], p[1], p[2])))

    coords_np = np.array([vol_mesh.vertices[v].point for v in sorted(used_vtx)])
    wp_centroid = coords_np.mean(axis=0)

    n_flipped = 0
    for el in vol_mesh.Elements(BND):
        if el.index not in target_indices:
            continue
        verts_new = [old_to_new[v.nr] for v in el.vertices]
        pts = np.array([vol_mesh.vertices[v.nr].point for v in el.vertices])
        if len(verts_new) >= 3:
            e1 = pts[1] - pts[0]; e2 = pts[2] - pts[0]
            n = np.cross(e1, e2)
            tri_center = pts.mean(axis=0)
            if np.dot(n, tri_center - wp_centroid) < 0:
                verts_new = [verts_new[0], verts_new[2], verts_new[1]]
                n_flipped += 1
        ngmesh_new.Add(ngm.Element2D(1, verts_new))
    progress("BEM",
        f"oriented {n_flipped} triangles outward from wp centroid "
        f"{list(wp_centroid)}")
    return Mesh(ngmesh_new)


# ======================================================================
# Output assembly
# ======================================================================
def _assemble_vacuum_output(args, coil_data):
    """L_coil + R_coil only (no workpiece)."""
    out = {
        "status": "ok",
        "method": f"{args.coil_solver}-vacuum",
        "coil_solver_used": args.coil_solver,
        "frequency_hz": float(args.frequency),
        "current_A": float(args.current),
        "L_coil_nH": float(coil_data["L_coil"] * 1e9),
        "R_coil_mOhm": float(coil_data["R_coil"] * 1e3),
        "t_coil_topology_s": float(coil_data["t_coil_topology_s"]),
        "t_coil_solve_s": float(coil_data["t_coil_solve_s"]),
    }
    if args.coil_solver == "peec":
        out["n_filaments"] = int(coil_data["n_filaments"])
    else:
        out["coil_mesh_nv"] = int(coil_data["coil_mesh_nv"])
        out["coil_mesh_n_tris"] = int(coil_data["coil_mesh_n_tris"])
        out["coil_mesh_n_src_tris"] = int(coil_data["coil_mesh_n_src_tris"])
        out["coil_mesh_n_snk_tris"] = int(coil_data["coil_mesh_n_snk_tris"])
        out["bem_a_residual"] = float(coil_data["bem_a_residual"])
    return out


def _assemble_full_output(args, coil_data, wp_data):
    """L_coil + R_coil + workpiece weak-coupled outputs."""
    out = _assemble_vacuum_output(args, coil_data)
    out["method"] = f"{args.coil_solver}-bem-weak"
    out["coupling_mode"] = "weak"
    out["telegen_form"] = "phi-B"
    out["L_total_nH"] = (float(coil_data["L_coil"] * 1e9)
                          + wp_data["delta_L_nH"])
    out["R_total_mOhm"] = (float(coil_data["R_coil"] * 1e3)
                            + wp_data["delta_R_mOhm"])
    out["delta_L_nH"] = wp_data["delta_L_nH"]
    out["delta_R_mOhm"] = wp_data["delta_R_mOhm"]
    out["P_wp_W"] = wp_data["P_wp"]
    out["H_t_rms_A_per_m"] = wp_data["H_t_rms"]
    out["wp_area_m2"] = wp_data["A_wp"]
    out["wp_dissipation_R_mOhm"] = wp_data["wp_dissipation_R_mOhm"]
    out["wp_mesh_nv"] = wp_data["wp_mesh_nv"]
    out["wp_mesh_n_tris"] = wp_data["wp_mesh_n_tris"]
    out["wp_gmres_info"] = wp_data["wp_gmres_info"]
    out["Z_s_wp_real"] = wp_data["Z_s_wp_real"]
    out["Z_s_wp_imag"] = wp_data["Z_s_wp_imag"]
    out["skin_depth_wp_mm"] = wp_data["skin_depth_wp_mm"]
    out["msh_file"] = wp_data["msh_file"]
    out["t_wp_mesh_s"] = wp_data["t_wp_mesh_s"]
    out["t_bem_assembly_s"] = wp_data["t_bem_assembly_s"]
    out["t_phi_inc_s"] = wp_data["t_phi_inc_s"]
    out["t_bem_solve_s"] = wp_data["t_bem_solve_s"]
    return out


# ======================================================================
# Coil viz: filament .msh + B-on-bbox / B-on-air-volume .msh
#
# Restored 2026-05-08 -- v4.25.0 unification refactor (commit 16e7e6e7)
# accidentally dropped the visualization branch from the deleted
# calc_peec_inductance.py.  The panel passes --coil-msh-output but the
# unified script silently ignored it.  open_gmsh.py auto-merges any
# sibling <stem>_filaments.msh so we just need to emit the files.
# ======================================================================
def _build_coil_bbox_mesh(filament_paths, expand=2.5, n_cells=18):
    """Generate an OCC Box mesh enclosing the coil bbox * ``expand``.

    Used for the auto-field-domain visualisation when no air-volume
    .vol is available (vacuum case) OR when the user wants a clean
    Box-shaped overlay on top of the workpiece air domain.
    """
    from netgen.occ import Box, Pnt, OCCGeometry
    from ngsolve import Mesh

    pts_list = []
    for path in filament_paths:
        arr = np.asarray(path, dtype=float)
        if arr.ndim != 3 or arr.shape[-1] != 3:
            continue
        pts_list.append(arr.reshape(-1, 3))
    if not pts_list:
        raise ValueError("_build_coil_bbox_mesh: no valid filament paths.")
    pts = np.concatenate(pts_list, axis=0)
    pmin = pts.min(axis=0)
    pmax = pts.max(axis=0)
    centre = 0.5 * (pmin + pmax)
    half = 0.5 * (pmax - pmin)
    half_exp = np.maximum(half * expand, half.max() * 0.3)
    p_lo = centre - half_exp
    p_hi = centre + half_exp
    box = Box(Pnt(float(p_lo[0]), float(p_lo[1]), float(p_lo[2])),
              Pnt(float(p_hi[0]), float(p_hi[1]), float(p_hi[2])))
    box.faces.name = "outer"
    box.solids.name = "field_domain"
    geo = OCCGeometry(box)
    maxh = float(np.max(p_hi - p_lo)) / max(n_cells, 4)
    return Mesh(geo.GenerateMesh(maxh=maxh))


def _biot_savart_B_on_vertices(mesh, filament_paths, fil_currents):
    """Vectorised Biot-Savart B at every vertex of ``mesh``.

    Returns (n_verts, 3) numpy array of B [T] using |I| (peak amplitude
    of the complex phasor) so the magnitude pattern matches the physical
    AC peak field.
    """
    from biot_savart import h_segments_batch, MU0
    verts = np.asarray([list(v.point) for v in mesh.vertices], dtype=float)
    if verts.shape[1] != 3:
        raise ValueError("_biot_savart_B_on_vertices: 3D mesh required")
    H_total = np.zeros_like(verts)
    for path, I in zip(filament_paths, fil_currents):
        segments = np.asarray(path, dtype=float)
        if segments.ndim != 3 or segments.shape[1:] != (2, 3):
            continue
        Im = float(abs(complex(I)))
        if Im < 1e-30:
            continue
        H_total += h_segments_batch(segments, verts, current=Im)
    return MU0 * H_total


def _resolve_coil_msh_path(args):
    """Decide where to write the coil viz .msh.

    Priority:
      1. ``--coil-msh-output`` (explicit)
      2. ``--msh-output`` if vacuum / coil-only (no workpiece — the wp
         surface output is NOT competing for that path)
      3. ``<msh_output_stem>_coil.msh`` sibling (with-wp case — keeps
         the wp surface at ``args.msh_output``, panel button opens
         the coil viz via gmsh_file priority and open_gmsh.py auto-
         merges the ``_filaments.msh`` sibling)

    Returns "" if no viz path can be derived (no msh-output flags).
    """
    if args.coil_msh_output:
        return args.coil_msh_output
    if not args.msh_output:
        return ""
    if args.coil_only or not args.vol:
        return args.msh_output
    base, ext = os.path.splitext(args.msh_output)
    return base + "_coil" + (ext or ".msh")


def _export_coil_msh_viz(args, coil_data):
    """Write the PEEC/coil visualization .msh files.

    Writes (when a coil viz path can be derived from ``--coil-msh-output``
    or ``--msh-output``, see ``_resolve_coil_msh_path``):
      * ``<coil_msh_path>``         : auto-bbox volume mesh + B vector
      * ``<stem>_filaments.msh``    : 1D filament polylines + |I|
        (auto-merged by open_gmsh.py as a sibling)

    Returns ``{"coil_field_msh": ..., "filament_msh": ..., "field_n_vertices": ...}``
    or empty dict on failure.  Errors are logged via ``progress`` and do
    NOT abort the inductance solve.

    PEEC-only.  The BEM-A coil path returns surface current density on
    a triangle mesh; that has its own viz route (TODO, not in scope).
    """
    if coil_data.get("source_type") != "filament":
        return {}

    out_msh = _resolve_coil_msh_path(args)
    if not out_msh:
        return {}

    paths = coil_data["paths"]
    I_fil = coil_data["I_fil"]
    base_dir = os.path.dirname(os.path.abspath(out_msh)) or "."
    stem = os.path.splitext(os.path.basename(out_msh))[0]
    os.makedirs(base_dir, exist_ok=True)

    # ---- B field on auto-bbox mesh -----------------------------------
    coil_field_msh = ""
    field_n_vertices = 0
    try:
        from ngsolve import H1, GridFunction
        from gmsh_post_export import save_vol_sol_pair, vol2msh

        t0 = time.perf_counter()
        field_mesh = _build_coil_bbox_mesh(paths)
        field_n_vertices = field_mesh.nv
        B_arr = _biot_savart_B_on_vertices(field_mesh, paths, I_fil)
        fes_B = H1(field_mesh, order=1, dim=3)
        gf_B = GridFunction(fes_B)
        gf_B.vec.FV().NumPy()[:] = B_arr.reshape(-1)

        sol_B = os.path.join(base_dir, f"{stem}_B.sol").replace("\\", "/")
        vol_B = os.path.join(base_dir, f"{stem}_field.vol").replace("\\", "/")
        save_vol_sol_pair(vol_B, sol_B, field_mesh.ngmesh, gf_B)
        vol2msh(out_msh, vol_B, [
            {"sol": sol_B, "fes": "H1", "fes_order": 1, "fes_dim": 3,
             "name": "B", "ncomp": 3},
        ])
        coil_field_msh = out_msh
        progress("VIZ", f"wrote {os.path.basename(out_msh)} "
                         f"(B field on {field_n_vertices} verts, "
                         f"{time.perf_counter()-t0:.1f}s)")
    except Exception as e:
        progress("VIZ", f"BBOX_ERROR:{type(e).__name__}: {e}")

    # ---- 1D filament polylines + |I| ---------------------------------
    filament_msh = ""
    try:
        from radia.gmsh_post_export import export_filaments_msh
        fil_msh_path = os.path.join(base_dir,
                                     f"{stem}_filaments.msh").replace("\\", "/")
        export_filaments_msh(paths, fil_msh_path, currents=I_fil,
                              label="filament")
        filament_msh = fil_msh_path
        progress("VIZ", f"wrote {os.path.basename(fil_msh_path)} "
                         f"({len(paths)} filaments + |I|)")
    except Exception as e:
        progress("VIZ", f"FIL_ERROR:{type(e).__name__}: {e}")

    return {
        "coil_field_msh": coil_field_msh,
        "filament_msh": filament_msh,
        "field_n_vertices": int(field_n_vertices),
    }


# ======================================================================
# Top-level dispatch
# ======================================================================
def run_inductance(args):
    """Top-level orchestrator.  Returns dict; calc_main wraps to JSON."""
    import radia  # noqa: F401  (DLL path setup for subprocess context)

    # Validate workpiece args if --vol given
    if args.vol:
        if args.sigma <= 0.0:
            return {"status": "error",
                    "error": "--sigma must be > 0 when --vol is provided"}
    if args.coil_only and args.vol:
        progress("INDUCT", "--coil-only: skipping workpiece despite --vol")

    # Coil layer
    if args.coil_solver == "peec":
        coil_data = _solve_coil_peec(args)
    elif args.coil_solver == "bem-a":
        coil_data = _solve_coil_bem_a(args)
    else:
        return {"status": "error",
                "error": f"unknown --coil-solver {args.coil_solver!r}"}

    # Coil viz (filament .msh + bbox B .msh).  PEEC only; BEM-A surface
    # current viz is TODO.  Failures here are non-fatal.
    viz = _export_coil_msh_viz(args, coil_data)

    # Vacuum-only branch
    if args.coil_only or not args.vol:
        out = _assemble_vacuum_output(args, coil_data)
        if viz.get("coil_field_msh"):
            out["gmsh_file"] = viz["coil_field_msh"]
            out["coil_field_msh"] = viz["coil_field_msh"]
            out["field_n_vertices"] = viz["field_n_vertices"]
        if viz.get("filament_msh"):
            out["filament_msh"] = viz["filament_msh"]
        return out

    # Weak-coupled branch
    wp_data = _solve_workpiece_weak_coupled(args, coil_data)
    out = _assemble_full_output(args, coil_data, wp_data)
    if viz.get("coil_field_msh"):
        # Promote bbox B msh to gmsh_file -- it has volumetric B vectors
        # (Air-volume B viz the user can merge interactively).  The wp
        # surface .msh remains in `msh_file` for compatibility.
        out["gmsh_file"] = viz["coil_field_msh"]
        out["coil_field_msh"] = viz["coil_field_msh"]
        out["field_n_vertices"] = viz["field_n_vertices"]
    if viz.get("filament_msh"):
        out["filament_msh"] = viz["filament_msh"]
    return out


def main():
    parser = argparse.ArgumentParser(
        description="Coil inductance (vacuum + weak-coupled BEM-SIBC). "
                    "Replaces calc_peec_inductance / calc_peec_bem / "
                    "calc_coil_bem_a_workpiece.")

    # ----- Coil geometry & solver switch -----
    parser.add_argument("--coil-step", required=True,
                        help="Coil STEP file path")
    parser.add_argument("--coil-solver", required=True,
                        choices=["peec", "bem-a"],
                        help="peec: PEEC perimeter filaments (fast). "
                             "bem-a: Weggler EFIE on RWG (accurate).")

    # ----- PEEC-specific args -----
    parser.add_argument("--peec-n-peri", type=int, default=16,
                        help="PEEC perimeter filament count (peec only)")

    # ----- BEM-A-specific args -----
    parser.add_argument("--coil-maxh", type=float, default=0.012,
                        help="BEM-A surface mesh maxh [m] (bem-a only)")
    parser.add_argument("--coil-source-name", default="source",
                        help="Coil source-cap face name (bem-a; falls back "
                             "to area-based detection if absent)")
    parser.add_argument("--coil-sink-name", default="sink",
                        help="Coil sink-cap face name (bem-a; same fallback)")
    parser.add_argument("--coil-rwg-quad-degree", type=int, default=5,
                        help="RWG regular-pair quadrature degree (bem-a)")
    parser.add_argument("--coil-rwg-singular-nq", type=int, default=6,
                        help="RWG Sauter-Schwab Duffy n_q (bem-a)")
    parser.add_argument("--coil-bem-solver", default="auto",
                        choices=["dense-lu", "hacapk-gmres", "auto"],
                        help="dense-lu (current) / hacapk-gmres (Phase C.7 future)")
    parser.add_argument("--coil-aca-eps", type=float, default=1e-10,
                        help="HACApK ACA eps for coil (bem-a, future)")
    parser.add_argument("--coil-gmres-tol", type=float, default=1e-10,
                        help="HACApK GMRES tol for coil (bem-a, future)")

    # ----- Coil material -----
    parser.add_argument("--coil-sigma", type=float, default=5.8e7,
                        help="Coil conductivity [S/m] (Cu default; mu_r=1)")

    # ----- Workpiece (optional) -----
    parser.add_argument("--vol", default="",
                        help="Workpiece .vol file (omit for vacuum L only)")
    parser.add_argument("--wp-label", default="sibc",
                        help="Workpiece label (volume material OR sideset)")
    parser.add_argument("--sigma", type=float, default=0.0,
                        help="Workpiece conductivity [S/m] (REQUIRED if --vol)")
    parser.add_argument("--mu-r", type=float, default=1.0,
                        help="Workpiece relative permeability")
    parser.add_argument("--half-thickness", type=float, default=0.01,
                        help="ESIM half-thickness [m] (unused in linear)")
    parser.add_argument("--bh-file", default="", help="ESIM BH table (WIP)")

    # ----- Workpiece BEM-SIBC solver -----
    parser.add_argument("--impedance-model", default="sibc",
                        choices=["sibc", "esim"],
                        help="sibc: linear Dowell.  esim: WIP.")
    parser.add_argument("--esim-max-iter", type=int, default=15)
    parser.add_argument("--esim-tol", type=float, default=1e-3)
    parser.add_argument("--h1-order", type=int, default=1,
                        choices=[1, 2],
                        help="Workpiece BEM Lagrange basis order "
                             "(NOT the geometry curving order, which is "
                             "auto-detected from the .vol's companion "
                             ".vol.json -- the .vol's curvedelements is "
                             "fixed at Cubit-export time and a post-load "
                             "mesh.Curve(p) silently falls back to flat). "
                             "1 = P1 hat (flat-friendly default).  "
                             "2 = Lagrange-P2 (uses curved Tri6 geometry "
                             "if the .vol has curve order >= 2, otherwise "
                             "P2 basis on flat Tri3 geometry).")
    parser.add_argument("--wp-bem-backend", default="hacapk",
                        choices=["hacapk", "intree-dense"])
    parser.add_argument("--wp-aca-eps", type=float, default=1e-10)
    parser.add_argument("--wp-gmres-tol", type=float, default=1e-10)

    # ----- Excitation -----
    parser.add_argument("--frequency", type=float, required=True,
                        help="Frequency [Hz]")
    parser.add_argument("--current", type=float, default=1.0,
                        help="Port current [A]")

    # ----- Coupling -----
    parser.add_argument("--coupling-mode", default="weak",
                        choices=["weak"],
                        help="weak: back-reacted Telegen ΔL (only mode)")
    parser.add_argument("--telegen-form", default="phi-B",
                        choices=["phi-B"],
                        help="Telegen form (only phi.B currently)")

    # ----- Output -----
    parser.add_argument("--msh-output", default="",
                        help="Workpiece .msh viz output path")
    parser.add_argument("--coil-msh-output", default="",
                        help="Coil .msh viz output path. PEEC: writes "
                             "<this>=B-on-bbox + <stem>_filaments.msh "
                             "(1D polylines + |I|).  open_gmsh.py auto-"
                             "merges the filament sibling.")
    parser.add_argument("--write-summary", action="store_true",
                        help="Add extra diagnostics in JSON")
    parser.add_argument("--coil-only", action="store_true",
                        help="Skip workpiece even if --vol given")

    # ----- Performance -----
    parser.add_argument("--n-threads", type=int, default=0,
                        help="0 = auto (TaskManager)")

    return calc_main(run_inductance, parser)


if __name__ == "__main__":
    sys.exit(main())
