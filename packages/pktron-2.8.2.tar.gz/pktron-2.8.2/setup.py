
from setuptools import setup, find_packages
setup(
    name="pktron",
    version="2.8.2",
    description="PKTron - High-Performance Quantum Circuit Simulator",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "PKTron",
    long_description_content_type="text/markdown",
    author="PKTron Team",
    license="MIT",
    packages=find_packages(),
    package_data={"pktron": ["*.py", "**/*.py"]},
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=["numpy>=1.21"],
    extras_require={
        "viz": ["matplotlib>=3.4"],
        "full": ["matplotlib>=3.4", "scipy>=1.7", "plotly>=5.0", "seaborn>=0.11"],
    },
)
