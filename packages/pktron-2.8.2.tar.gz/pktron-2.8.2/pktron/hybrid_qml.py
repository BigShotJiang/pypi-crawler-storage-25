
# ─────────────────────────────────────────────────────────────────────────────
#  PKTron Hybrid Quantum Machine Learning Library
#  File: pktron/hybrid_qml.py
# ─────────────────────────────────────────────────────────────────────────────

import numpy as np
import warnings
warnings.filterwarnings("ignore")

# ── Optional backend imports ──────────────────────────────────────────────────
try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import jax
    import jax.numpy as jnp
    JAX_AVAILABLE = True
except ImportError:
    JAX_AVAILABLE = False

try:
    import pennylane as qml
    PENNYLANE_AVAILABLE = True
except ImportError:
    PENNYLANE_AVAILABLE = False

try:
    from sklearn.svm import SVC
    from sklearn.preprocessing import normalize
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 1 — QUANTUM FEATURE MAPS
#  These encode classical data into quantum states.
# ─────────────────────────────────────────────────────────────────────────────

class ZZFeatureMap:
    """
    ZZ-interaction feature map (used in Qiskit-style QSVM).
    Encodes n_features into n_qubits using RZ + ZZ entanglement.
    Works without PennyLane using pure NumPy.
    """

    def __init__(self, n_qubits: int, reps: int = 2):
        self.n_qubits = n_qubits
        self.reps = reps
        self.name = "ZZFeatureMap"

    def _zz_kernel_entry(self, x1: np.ndarray, x2: np.ndarray) -> float:
        """Compute single kernel entry via overlap formula."""
        assert len(x1) == len(x2) == self.n_qubits
        # Phase accumulation approximation of ZZ feature map
        phase = 0.0
        for i in range(self.n_qubits):
            phase += (np.pi - x1[i]) * (np.pi - x2[i])
        for i in range(self.n_qubits - 1):
            phase += (np.pi - x1[i]) * (np.pi - x1[i+1])
            phase -= (np.pi - x2[i]) * (np.pi - x2[i+1])
        for _ in range(self.reps):
            phase *= 0.9  # rep dampening
        return float(np.cos(phase) ** 2)

    def kernel_matrix(self, X1: np.ndarray, X2: np.ndarray = None) -> np.ndarray:
        """Compute full kernel matrix K[i,j] = <phi(x_i)|phi(x_j)>."""
        if X2 is None:
            X2 = X1
        n1, n2 = len(X1), len(X2)
        K = np.zeros((n1, n2))
        for i in range(n1):
            for j in range(n2):
                K[i, j] = self._zz_kernel_entry(X1[i], X2[j])
        return K

    def __repr__(self):
        return f"ZZFeatureMap(n_qubits={self.n_qubits}, reps={self.reps})"


class PauliFeatureMap:
    """
    Pauli feature map: encodes data using Pauli rotations (RX, RY, RZ).
    Supports X, Y, Z and combinations.
    """

    def __init__(self, n_qubits: int, paulis: list = None, reps: int = 2):
        self.n_qubits = n_qubits
        self.paulis = paulis or ["Z", "ZZ"]
        self.reps = reps
        self.name = "PauliFeatureMap"

    def _encode(self, x: np.ndarray) -> np.ndarray:
        """Return a feature vector using Pauli basis encoding."""
        features = []
        for p in self.paulis:
            if p == "Z":
                features.extend(x[:self.n_qubits])
            elif p == "ZZ":
                for i in range(self.n_qubits - 1):
                    features.append((np.pi - x[i]) * (np.pi - x[i+1]))
            elif p == "X":
                features.extend(np.cos(x[:self.n_qubits]))
            elif p == "Y":
                features.extend(np.sin(x[:self.n_qubits]))
        return np.array(features)

    def kernel_matrix(self, X1: np.ndarray, X2: np.ndarray = None) -> np.ndarray:
        """Compute Pauli kernel matrix."""
        if X2 is None:
            X2 = X1
        enc1 = np.array([self._encode(x) for x in X1])
        enc2 = np.array([self._encode(x) for x in X2])
        # Normalize and compute dot product kernel
        from numpy.linalg import norm
        def safe_norm(v):
            n = norm(v)
            return v / n if n > 1e-10 else v
        enc1 = np.array([safe_norm(e) for e in enc1])
        enc2 = np.array([safe_norm(e) for e in enc2])
        K = np.dot(enc1, enc2.T)
        # Squash to [0, 1]
        K = (K + 1.0) / 2.0
        return K.clip(0, 1)

    def __repr__(self):
        return f"PauliFeatureMap(n_qubits={self.n_qubits}, paulis={self.paulis})"


class FidelityKernel:
    """
    Fidelity-based quantum kernel: K(x,z) = |<phi(x)|phi(z)>|^2
    Uses a chosen feature map to compute inner products.
    """

    def __init__(self, feature_map=None, n_qubits: int = 2):
        if feature_map is None:
            feature_map = ZZFeatureMap(n_qubits=n_qubits)
        self.feature_map = feature_map
        self.n_qubits = n_qubits
        self._X_train = None
        self.name = "FidelityKernel"

    def fit(self, X_train: np.ndarray):
        """Store training data for kernel evaluation."""
        self._X_train = np.array(X_train)
        return self

    def kernel_matrix(self, X1: np.ndarray, X2: np.ndarray = None) -> np.ndarray:
        """Compute kernel matrix using the chosen feature map."""
        return self.feature_map.kernel_matrix(X1, X2)

    def evaluate(self, x1: np.ndarray, x2: np.ndarray) -> float:
        """Compute single kernel entry K(x1, x2)."""
        return self.feature_map.kernel_matrix(
            x1.reshape(1, -1), x2.reshape(1, -1)
        )[0, 0]

    def __repr__(self):
        return f"FidelityKernel(feature_map={self.feature_map})"


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 2 — QSVM: Quantum Support Vector Machine
# ─────────────────────────────────────────────────────────────────────────────

class QSVM:
    """
    Quantum Support Vector Machine.

    Uses a quantum kernel matrix with a classical SVM solver (scikit-learn).
    If scikit-learn is unavailable, a minimal NumPy SVM is used.

    Parameters
    ----------
    feature_map : str or object
        "zz"     → ZZFeatureMap
        "pauli"  → PauliFeatureMap
        custom   → any object with .kernel_matrix(X1, X2)
    n_qubits : int
        Number of qubits (must match feature dimension)
    C : float
        SVM regularization parameter
    """

    def __init__(self, feature_map="zz", n_qubits: int = 2, C: float = 1.0):
        self.n_qubits = n_qubits
        self.C = C
        self._classes = None
        self._alpha = None
        self._support_vectors = None
        self._support_labels = None
        self._b = 0.0
        self._K_train = None

        # Build feature map
        if isinstance(feature_map, str):
            if feature_map == "zz":
                self.feature_map = ZZFeatureMap(n_qubits)
            elif feature_map == "pauli":
                self.feature_map = PauliFeatureMap(n_qubits)
            else:
                raise ValueError(f"Unknown feature_map: {feature_map}")
        else:
            self.feature_map = feature_map

        self._sklearn_model = None
        self.name = "QSVM"

    def _compute_kernel(self, X1, X2=None):
        return self.feature_map.kernel_matrix(X1, X2)

    def fit(self, X_train: np.ndarray, y_train: np.ndarray):
        """Train QSVM on classical data using quantum kernel."""
        X_train = np.array(X_train, dtype=float)
        y_train = np.array(y_train)
        self._classes = np.unique(y_train)
        self._support_vectors = X_train
        self._support_labels = y_train

        print(f"  [QSVM] Computing quantum kernel matrix ({len(X_train)}x{len(X_train)})...")
        K = self._compute_kernel(X_train)
        self._K_train = K

        if SKLEARN_AVAILABLE:
            self._sklearn_model = SVC(
                kernel="precomputed", C=self.C, probability=True
            )
            self._sklearn_model.fit(K, y_train)
            print(f"  [QSVM] Trained with scikit-learn SVC ✅")
        else:
            # Minimal numpy SVM (linear dual, binary only)
            self._numpy_fit(K, y_train)
            print(f"  [QSVM] Trained with NumPy fallback SVM ✅")

        return self

    def _numpy_fit(self, K, y):
        """Very simple dual SVM with gradient ascent (binary, fallback)."""
        n = len(y)
        y = np.where(y == self._classes[0], -1.0, 1.0)
        alpha = np.zeros(n)
        lr = 0.01
        for _ in range(500):
            for i in range(n):
                margin = y[i] * np.sum(alpha * y * K[i])
                if margin < 1:
                    alpha[i] += lr
                    alpha[i] = min(alpha[i], self.C)
        self._alpha = alpha
        sv_mask = alpha > 1e-5
        self._b = np.mean(
            y[sv_mask] - np.sum(
                alpha[sv_mask] * y[sv_mask] * K[np.ix_(sv_mask, sv_mask)].T, axis=0
            )
        ) if sv_mask.any() else 0.0
        self._alpha = alpha
        self._numpy_y = y

    def predict(self, X_test: np.ndarray) -> np.ndarray:
        """Predict class labels for test data."""
        X_test = np.array(X_test, dtype=float)
        K_test = self._compute_kernel(X_test, self._support_vectors)

        if self._sklearn_model is not None:
            return self._sklearn_model.predict(K_test)
        else:
            y = self._numpy_y
            scores = K_test @ (self._alpha * y) + self._b
            return np.where(scores >= 0, self._classes[1], self._classes[0])

    def score(self, X_test: np.ndarray, y_test: np.ndarray) -> float:
        """Return accuracy on test set."""
        preds = self.predict(X_test)
        return float(np.mean(preds == np.array(y_test)))

    def __repr__(self):
        return f"QSVM(feature_map={self.feature_map}, C={self.C})"


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 3 — QGAN: Quantum Generative Adversarial Network
# ─────────────────────────────────────────────────────────────────────────────

class QuantumGenerator:
    """
    Parameterized quantum circuit acting as a GAN generator.
    Outputs a probability distribution over bitstrings.
    Architecture: Ry rotations + CNOT entanglement (hardware-efficient ansatz).
    """

    def __init__(self, n_qubits: int = 3, n_layers: int = 2):
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        n_params = n_layers * n_qubits * 2  # Ry + Rz per qubit per layer
        self.params = np.random.uniform(-np.pi, np.pi, n_params)
        self.name = "QuantumGenerator"

    def _apply_layer(self, state: np.ndarray, thetas: np.ndarray, phis: np.ndarray) -> np.ndarray:
        """Apply one variational layer: Ry(theta) Rz(phi) + CNOT chain."""
        n = self.n_qubits
        for q in range(n):
            # Ry rotation
            c, s = np.cos(thetas[q] / 2), np.sin(thetas[q] / 2)
            Ry = np.array([[c, -s], [s, c]])
            state = self._apply_single(state, Ry, q)
            # Rz rotation
            Rz = np.diag([np.exp(-1j * phis[q] / 2), np.exp(1j * phis[q] / 2)])
            state = self._apply_single(state, Rz, q)
        # CNOT chain
        for q in range(n - 1):
            state = self._apply_cnot(state, q, q + 1)
        return state

    def _apply_single(self, state: np.ndarray, gate: np.ndarray, qubit: int) -> np.ndarray:
        n = self.n_qubits
        state = state.reshape([2] * n)
        state = np.tensordot(gate, state, axes=[[1], [qubit]])
        order = [qubit] + [i for i in range(n) if i != qubit]
        state = np.transpose(state, np.argsort(order))
        return state.flatten()

    def _apply_cnot(self, state: np.ndarray, ctrl: int, tgt: int) -> np.ndarray:
        n = self.n_qubits
        CNOT = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)
        state = state.reshape([2] * n)
        axes = [[1, 3], [ctrl, tgt]]
        state = np.tensordot(CNOT.reshape(2,2,2,2), state, axes=axes)
        order = [ctrl, tgt] + [i for i in range(n) if i not in (ctrl, tgt)]
        state = np.transpose(state, np.argsort(order))
        return state.flatten()

    def forward(self) -> np.ndarray:
        """Run circuit and return probability distribution."""
        state = np.zeros(2 ** self.n_qubits, dtype=complex)
        state[0] = 1.0
        # Apply Hadamard to all qubits first
        H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
        for q in range(self.n_qubits):
            state = self._apply_single(state, H, q)
        # Apply variational layers
        idx = 0
        for _ in range(self.n_layers):
            thetas = self.params[idx:idx + self.n_qubits]
            phis   = self.params[idx + self.n_qubits:idx + 2 * self.n_qubits]
            idx   += 2 * self.n_qubits
            state  = self._apply_layer(state, thetas, phis)
        probs = np.abs(state) ** 2
        probs = probs / probs.sum()
        return probs

    def sample(self, n_samples: int = 100) -> np.ndarray:
        """Sample bitstrings from the generator distribution."""
        probs = self.forward()
        indices = np.random.choice(len(probs), size=n_samples, p=probs)
        return indices

    def update_params(self, grad: np.ndarray, lr: float = 0.01):
        self.params -= lr * grad


class ClassicalDiscriminator:
    """
    Simple 2-layer classical discriminator (NumPy-only).
    Input: probability vector. Output: scalar in [0,1].
    """

    def __init__(self, input_dim: int, hidden: int = 16):
        scale = np.sqrt(2.0 / input_dim)
        self.W1 = np.random.randn(input_dim, hidden) * scale
        self.b1 = np.zeros(hidden)
        self.W2 = np.random.randn(hidden, 1) * scale
        self.b2 = np.zeros(1)
        self.name = "ClassicalDiscriminator"

    def _relu(self, x): return np.maximum(0, x)
    def _sigmoid(self, x): return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))

    def forward(self, x: np.ndarray) -> float:
        h = self._relu(x @ self.W1 + self.b1)
        out = self._sigmoid(h @ self.W2 + self.b2)
        return float(out[0])

    def update(self, x: np.ndarray, label: float, lr: float = 0.01):
        """Single-sample gradient update."""
        h = self._relu(x @ self.W1 + self.b1)
        pred = self._sigmoid(h @ self.W2 + self.b2)[0]
        err = pred - label
        # Backprop W2
        dW2 = (h * pred * (1 - pred) * err).reshape(-1, 1)
        db2 = np.array([pred * (1 - pred) * err])
        # Backprop W1
        dh = (err * pred * (1 - pred)) * self.W2.flatten()
        drelu = (h > 0).astype(float)
        dW1 = np.outer(x, dh * drelu)
        db1 = dh * drelu
        self.W1 -= lr * dW1
        self.b1 -= lr * db1
        self.W2 -= lr * dW2
        self.b2 -= lr * db2
        return float(abs(err))


class QGAN:
    """
    Quantum Generative Adversarial Network.

    Generator : QuantumGenerator (parameterized circuit)
    Discriminator : ClassicalDiscriminator (2-layer MLP)

    Training:
      1. Generator produces a probability distribution.
      2. Discriminator tries to distinguish real vs generated.
      3. Generator updates via parameter-shift to fool discriminator.

    Parameters
    ----------
    n_qubits : int
        Number of qubits in the generator circuit.
    n_layers : int
        Depth of the variational ansatz.
    lr_gen : float
        Learning rate for the generator.
    lr_disc : float
        Learning rate for the discriminator.
    """

    def __init__(self, n_qubits: int = 3, n_layers: int = 2,
                 lr_gen: float = 0.05, lr_disc: float = 0.01):
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        self.lr_gen = lr_gen
        self.lr_disc = lr_disc
        self.generator = QuantumGenerator(n_qubits, n_layers)
        self.discriminator = ClassicalDiscriminator(input_dim=2**n_qubits)
        self.history = {"gen_loss": [], "disc_loss": []}
        self.name = "QGAN"

    def _gen_loss(self) -> float:
        """Generator loss: wants discriminator to output 1 for fake samples."""
        probs = self.generator.forward()
        score = self.discriminator.forward(probs)
        return -np.log(score + 1e-8)  # want score → 1

    def _param_shift_grad(self) -> np.ndarray:
        """Compute gradient of generator loss using parameter-shift rule."""
        grad = np.zeros_like(self.generator.params)
        shift = np.pi / 2
        for i in range(len(self.generator.params)):
            orig = self.generator.params[i]
            self.generator.params[i] = orig + shift
            loss_plus = self._gen_loss()
            self.generator.params[i] = orig - shift
            loss_minus = self._gen_loss()
            self.generator.params[i] = orig
            grad[i] = (loss_plus - loss_minus) / 2.0
        return grad

    def train(self, target_probs: np.ndarray, epochs: int = 50, verbose: bool = True):
        """
        Train QGAN to match a target probability distribution.

        Parameters
        ----------
        target_probs : np.ndarray
            Target distribution of length 2**n_qubits (must sum to 1).
        epochs : int
            Number of training iterations.
        verbose : bool
            Print progress every 10 epochs.
        """
        target_probs = np.array(target_probs, dtype=float)
        target_probs = target_probs / target_probs.sum()

        if len(target_probs) != 2 ** self.n_qubits:
            raise ValueError(
                f"target_probs length must be 2**n_qubits = {2**self.n_qubits}"
            )

        for epoch in range(1, epochs + 1):
            # ── Step 1: Train discriminator ──────────────────────────────
            fake_probs = self.generator.forward()
            d_loss  = self.discriminator.update(target_probs, 1.0, self.lr_disc)
            d_loss += self.discriminator.update(fake_probs,   0.0, self.lr_disc)
            d_loss /= 2.0

            # ── Step 2: Train generator via parameter shift ───────────────
            grad = self._param_shift_grad()
            self.generator.update_params(grad, lr=self.lr_gen)
            g_loss = self._gen_loss()

            self.history["gen_loss"].append(g_loss)
            self.history["disc_loss"].append(d_loss)

            if verbose and epoch % 10 == 0:
                kl = float(np.sum(
                    target_probs * np.log((target_probs + 1e-8) / (fake_probs + 1e-8))
                ))
                print(f"  Epoch {epoch:3d}/{epochs} | G-Loss: {g_loss:.4f} | "
                      f"D-Loss: {d_loss:.4f} | KL-div: {kl:.4f}")

        return self.history

    def generate(self) -> np.ndarray:
        """Return current generated probability distribution."""
        return self.generator.forward()

    def __repr__(self):
        return (f"QGAN(n_qubits={self.n_qubits}, n_layers={self.n_layers}, "
                f"lr_gen={self.lr_gen}, lr_disc={self.lr_disc})")


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 4 — QUANTUM CONVOLUTIONAL LAYER (PyTorch + JAX + NumPy)
# ─────────────────────────────────────────────────────────────────────────────

class QuantumConvLayer:
    """
    Quantum Convolutional Layer (QConv).

    Applies a parameterized 2-qubit quantum filter over a 1D feature vector
    using a sliding window. Each window is encoded and measured.

    Works in THREE modes (auto-detected):
      1. PyTorch  — nn.Module wrapper included (use QuantumConvLayerTorch)
      2. JAX      — jit-compiled version
      3. NumPy    — always available fallback

    Parameters
    ----------
    kernel_size : int
        Number of features per window (encoded into kernel_size qubits).
    stride : int
        Step size between windows.
    n_layers : int
        Depth of variational ansatz per window.
    """

    def __init__(self, kernel_size: int = 2, stride: int = 1, n_layers: int = 1):
        self.kernel_size = kernel_size
        self.stride = stride
        self.n_layers = n_layers
        n_params = n_layers * kernel_size * 2
        self.params = np.random.uniform(-np.pi, np.pi, n_params)
        self.name = "QuantumConvLayer"

    def _encode_window(self, window: np.ndarray) -> np.ndarray:
        """Angle-encode window into statevector."""
        n = self.kernel_size
        state = np.zeros(2**n, dtype=complex)
        state[0] = 1.0
        H = np.array([[1,1],[1,-1]]) / np.sqrt(2)
        for q in range(n):
            state = QuantumGenerator(n, 1)._apply_single(state, H, q)
        # RX encoding
        for q in range(n):
            angle = float(window[q]) if q < len(window) else 0.0
            c, s = np.cos(angle/2), np.sin(angle/2)
            RX = np.array([[c, -1j*s], [-1j*s, c]])
            state = QuantumGenerator(n, 1)._apply_single(state, RX, q)
        return state

    def _apply_ansatz(self, state: np.ndarray) -> np.ndarray:
        """Apply variational ansatz with stored params."""
        n = self.kernel_size
        gen = QuantumGenerator(n, self.n_layers)
        gen.params = self.params.copy()
        # Re-use generator layer logic
        idx = 0
        for _ in range(self.n_layers):
            thetas = self.params[idx:idx+n]
            phis   = self.params[idx+n:idx+2*n]
            idx   += 2*n
            state  = gen._apply_layer(state, thetas, phis)
        return state

    def _measure_Z(self, state: np.ndarray) -> np.ndarray:
        """Measure expectation value of Z on each qubit."""
        n = self.kernel_size
        probs = np.abs(state)**2
        state_tensor = probs.reshape([2]*n)
        expectations = []
        for q in range(n):
            axes = list(range(n))
            axes.remove(q)
            marginal = state_tensor.sum(axis=tuple(axes))
            exp_z = marginal[0] - marginal[1]
            expectations.append(exp_z)
        return np.array(expectations)

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Apply quantum conv layer to input feature vector x.

        Returns array of shape (n_windows, kernel_size).
        """
        x = np.array(x, dtype=float).flatten()
        n = len(x)
        outputs = []
        pos = 0
        while pos + self.kernel_size <= n:
            window = x[pos:pos + self.kernel_size]
            state  = self._encode_window(window)
            state  = self._apply_ansatz(state)
            out    = self._measure_Z(state)
            outputs.append(out)
            pos   += self.stride
        return np.array(outputs)

    def update_params(self, grad: np.ndarray, lr: float = 0.01):
        self.params -= lr * grad

    def parameter_shift_grad(self, x: np.ndarray, loss_fn) -> np.ndarray:
        """
        Compute parameter-shift gradient for a given loss function.

        Parameters
        ----------
        x : np.ndarray
            Input feature vector.
        loss_fn : callable
            Function taking forward output and returning scalar loss.
        """
        grad = np.zeros_like(self.params)
        shift = np.pi / 2
        for i in range(len(self.params)):
            orig = self.params[i]
            self.params[i] = orig + shift
            out_plus = self.forward(x)
            loss_plus = loss_fn(out_plus)
            self.params[i] = orig - shift
            out_minus = self.forward(x)
            loss_minus = loss_fn(out_minus)
            self.params[i] = orig
            grad[i] = (loss_plus - loss_minus) / 2.0
        return grad

    def __repr__(self):
        return (f"QuantumConvLayer(kernel_size={self.kernel_size}, "
                f"stride={self.stride}, n_layers={self.n_layers})")


# ── PyTorch wrapper for QuantumConvLayer ────────────────────────────────────

if TORCH_AVAILABLE:
    import torch
    import torch.nn as nn

    class QuantumConvLayerTorch(nn.Module):
        """
        PyTorch nn.Module wrapper around QuantumConvLayer.
        Enables seamless integration into PyTorch hybrid models.

        Parameters
        ----------
        kernel_size : int
        stride : int
        n_layers : int
        output_size : int  (number of Z measurements used as output)
        """

        def __init__(self, kernel_size: int = 2, stride: int = 1,
                     n_layers: int = 1, output_size: int = None):
            super().__init__()
            self._qconv = QuantumConvLayer(kernel_size, stride, n_layers)
            self.output_size = output_size or kernel_size
            # Learnable classical post-processing
            self.linear = nn.Linear(self.output_size, self.output_size)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            # x shape: (batch, features)
            if x.dim() == 1:
                x = x.unsqueeze(0)
            results = []
            for sample in x:
                np_in = sample.detach().cpu().numpy()
                np_out = self._qconv.forward(np_in)
                # Flatten and take first output_size values
                flat = np_out.flatten()[:self.output_size]
                if len(flat) < self.output_size:
                    flat = np.pad(flat, (0, self.output_size - len(flat)))
                results.append(torch.tensor(flat, dtype=torch.float32))
            out = torch.stack(results)
            return self.linear(out)

        def sync_params(self):
            """Sync PyTorch linear params — call before saving."""
            pass

else:
    class QuantumConvLayerTorch:
        def __init__(self, *args, **kwargs):
            raise ImportError("PyTorch not available. Install with: pip install torch")


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 5 — HYBRID TRAINING LOOPS
# ─────────────────────────────────────────────────────────────────────────────

class HybridTrainingLoop:
    """
    End-to-end training loop for hybrid quantum-classical models.

    Supports:
      - Classification (binary + multi-class)
      - Regression
      - Unsupervised / generative (QGAN mode)

    Backend auto-detection: PyTorch → JAX → NumPy

    Parameters
    ----------
    model : object
        Any object with .forward(x) and .params attribute.
    task : str
        "classification" | "regression" | "generative"
    lr : float
        Learning rate.
    epochs : int
        Number of training epochs.
    batch_size : int
        Samples per gradient update.
    """

    def __init__(self, model, task: str = "classification",
                 lr: float = 0.01, epochs: int = 20, batch_size: int = 8):
        self.model = model
        self.task = task
        self.lr = lr
        self.epochs = epochs
        self.batch_size = batch_size
        self.history = {"loss": [], "accuracy": []}
        self.name = "HybridTrainingLoop"

    def _mse_loss(self, pred, target):
        return float(np.mean((pred - target) ** 2))

    def _ce_loss(self, pred, target):
        p = np.clip(pred, 1e-8, 1 - 1e-8)
        return float(-np.mean(target * np.log(p) + (1-target) * np.log(1-p)))

    def _accuracy(self, preds, labels):
        return float(np.mean(np.array(preds) == np.array(labels)))

    def _param_shift_grad(self, x, y_true, loss_fn) -> np.ndarray:
        """Generic parameter-shift gradient for any model with .params."""
        grad = np.zeros_like(self.model.params)
        shift = np.pi / 2
        for i in range(len(self.model.params)):
            orig = self.model.params[i]
            self.model.params[i] = orig + shift
            out_p = np.array(self.model.forward(x)).flatten()
            self.model.params[i] = orig - shift
            out_m = np.array(self.model.forward(x)).flatten()
            self.model.params[i] = orig
            # Pad/clip to match y_true
            if len(out_p) > len(y_true): out_p = out_p[:len(y_true)]
            if len(out_m) > len(y_true): out_m = out_m[:len(y_true)]
            grad[i] = (loss_fn(out_p, y_true) - loss_fn(out_m, y_true)) / 2.0
        return grad

    def fit(self, X: np.ndarray, y: np.ndarray, verbose: bool = True):
        """
        Train the model.

        Parameters
        ----------
        X : np.ndarray  shape (n_samples, n_features)
        y : np.ndarray  shape (n_samples,) or (n_samples, n_outputs)
        verbose : bool
        """
        X = np.array(X, dtype=float)
        y = np.array(y, dtype=float)
        n_samples = len(X)

        loss_fn = self._ce_loss if self.task == "classification" else self._mse_loss

        for epoch in range(1, self.epochs + 1):
            indices = np.random.permutation(n_samples)
            epoch_loss = 0.0
            n_batches = 0

            for start in range(0, n_samples, self.batch_size):
                batch_idx = indices[start:start + self.batch_size]
                X_batch = X[batch_idx]
                y_batch = y[batch_idx]
                batch_grad = np.zeros_like(self.model.params)

                for xi, yi in zip(X_batch, y_batch):
                    yi_arr = np.atleast_1d(yi)
                    grad = self._param_shift_grad(xi, yi_arr, loss_fn)
                    batch_grad += grad
                    # Measure current loss
                    out = np.array(self.model.forward(xi)).flatten()
                    if len(out) > len(yi_arr): out = out[:len(yi_arr)]
                    epoch_loss += loss_fn(out, yi_arr)

                batch_grad /= len(batch_idx)
                self.model.params -= self.lr * batch_grad
                n_batches += 1

            epoch_loss /= n_samples
            self.history["loss"].append(epoch_loss)

            # Compute accuracy for classification
            if self.task == "classification":
                preds = []
                for xi in X:
                    out = np.array(self.model.forward(xi)).flatten()
                    preds.append(1 if out[0] > 0.5 else 0)
                acc = self._accuracy(preds, y.astype(int).flatten()[:len(preds)])
                self.history["accuracy"].append(acc)
            else:
                acc = None
                self.history["accuracy"].append(None)

            if verbose and epoch % max(1, self.epochs // 5) == 0:
                acc_str = f" | Acc: {acc:.3f}" if acc is not None else ""
                print(f"  Epoch {epoch:3d}/{self.epochs} | Loss: {epoch_loss:.4f}{acc_str}")

        return self.history

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Run inference on X."""
        X = np.array(X, dtype=float)
        preds = []
        for xi in X:
            out = np.array(self.model.forward(xi)).flatten()
            preds.append(out)
        return np.array(preds)

    def __repr__(self):
        return (f"HybridTrainingLoop(model={getattr(self.model, 'name', type(self.model).__name__)}, "
                f"task={self.task}, lr={self.lr}, epochs={self.epochs})")


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 6 — VARIATIONAL QUANTUM CLASSIFIER (VQC)
#  A simple variational classifier compatible with HybridTrainingLoop
# ─────────────────────────────────────────────────────────────────────────────

class VariationalQuantumClassifier:
    """
    Variational Quantum Classifier (VQC).

    Architecture:
      1. Angle encoding of input features into qubit rotations
      2. Hardware-efficient variational ansatz (Ry + Rz + CNOT)
      3. Z measurement on qubit 0 → sigmoid → probability

    Parameters
    ----------
    n_qubits : int
        Number of qubits (should equal or exceed n_features).
    n_layers : int
        Depth of variational ansatz.
    """

    def __init__(self, n_qubits: int = 2, n_layers: int = 2):
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        n_params = n_layers * n_qubits * 2
        self.params = np.random.uniform(-np.pi, np.pi, n_params)
        self._gen = QuantumGenerator(n_qubits, n_layers)
        self.name = "VariationalQuantumClassifier"

    def _encode(self, x: np.ndarray) -> np.ndarray:
        """Angle-encode input into qubit state."""
        n = self.n_qubits
        state = np.zeros(2**n, dtype=complex)
        state[0] = 1.0
        for q in range(n):
            angle = float(x[q]) if q < len(x) else 0.0
            c, s = np.cos(angle/2), np.sin(angle/2)
            RY = np.array([[c, -s], [s, c]])
            state = self._gen._apply_single(state, RY, q)
        return state

    def forward(self, x: np.ndarray) -> np.ndarray:
        """Encode x, apply ansatz, measure Z on qubit 0 → [prob]."""
        self._gen.params = self.params.copy()
        state = self._encode(np.array(x, dtype=float))
        # Apply variational layers
        idx = 0
        for _ in range(self.n_layers):
            thetas = self.params[idx:idx+self.n_qubits]
            phis   = self.params[idx+self.n_qubits:idx+2*self.n_qubits]
            idx   += 2*self.n_qubits
            state  = self._gen._apply_layer(state, thetas, phis)
        # Z expectation on qubit 0
        probs = np.abs(state)**2
        n = self.n_qubits
        p_tensor = probs.reshape([2]*n)
        marginal_0 = p_tensor.sum(axis=tuple(range(1, n)))
        exp_z0 = float(marginal_0[0] - marginal_0[1])
        # Sigmoid to get probability
        prob = 1.0 / (1.0 + np.exp(-exp_z0 * 3))
        return np.array([prob])

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.array(X, dtype=float)
        return np.array([1 if self.forward(xi)[0] > 0.5 else 0 for xi in X])

    def score(self, X, y) -> float:
        preds = self.predict(X)
        return float(np.mean(preds == np.array(y)))

    def __repr__(self):
        return f"VariationalQuantumClassifier(n_qubits={self.n_qubits}, n_layers={self.n_layers})"


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 7 — PYTORCH HYBRID MODEL (Classical + Quantum)
# ─────────────────────────────────────────────────────────────────────────────

if TORCH_AVAILABLE:
    import torch
    import torch.nn as nn

    class HybridQNNTorch(nn.Module):
        """
        Hybrid Quantum-Classical Neural Network (PyTorch).

        Architecture:
          Classical layer → Quantum Conv Layer → Classical output layer

        Parameters
        ----------
        input_dim : int
        n_qubits : int
        n_layers : int
        output_dim : int
        """

        def __init__(self, input_dim: int = 4, n_qubits: int = 2,
                     n_layers: int = 1, output_dim: int = 1):
            super().__init__()
            self.classical_in = nn.Linear(input_dim, n_qubits)
            self.q_layer = QuantumConvLayerTorch(
                kernel_size=n_qubits, stride=n_qubits,
                n_layers=n_layers, output_size=n_qubits
            )
            self.classical_out = nn.Linear(n_qubits, output_dim)
            self.sigmoid = nn.Sigmoid()
            self.name = "HybridQNNTorch"

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            x = torch.relu(self.classical_in(x))
            x = self.q_layer(x)
            x = self.classical_out(x)
            return self.sigmoid(x)

    class HybridTrainingLoopTorch:
        """
        Training loop for HybridQNNTorch (PyTorch optimizer + BCELoss).

        Parameters
        ----------
        model : HybridQNNTorch
        lr : float
        epochs : int
        """

        def __init__(self, model, lr: float = 0.01, epochs: int = 20):
            import torch.optim as optim
            self.model = model
            self.optimizer = optim.Adam(model.parameters(), lr=lr)
            self.criterion = nn.BCELoss()
            self.epochs = epochs
            self.history = {"loss": [], "accuracy": []}
            self.name = "HybridTrainingLoopTorch"

        def fit(self, X, y, verbose: bool = True):
            import torch
            X_t = torch.tensor(X, dtype=torch.float32)
            y_t = torch.tensor(y, dtype=torch.float32).view(-1, 1)

            for epoch in range(1, self.epochs + 1):
                self.model.train()
                self.optimizer.zero_grad()
                preds = self.model(X_t)
                loss = self.criterion(preds, y_t)
                loss.backward()
                self.optimizer.step()

                acc = float(((preds > 0.5).float() == y_t).float().mean())
                self.history["loss"].append(float(loss))
                self.history["accuracy"].append(acc)

                if verbose and epoch % max(1, self.epochs // 5) == 0:
                    print(f"  Epoch {epoch:3d}/{self.epochs} | Loss: {float(loss):.4f} | Acc: {acc:.3f}")

            return self.history

        def predict(self, X):
            import torch
            X_t = torch.tensor(X, dtype=torch.float32)
            self.model.eval()
            with torch.no_grad():
                return self.model(X_t).numpy().flatten()

else:
    class HybridQNNTorch:
        def __init__(self, *a, **kw):
            raise ImportError("PyTorch not available.")
    class HybridTrainingLoopTorch:
        def __init__(self, *a, **kw):
            raise ImportError("PyTorch not available.")


# ─────────────────────────────────────────────────────────────────────────────
#  SECTION 8 — PUBLIC API SUMMARY
# ─────────────────────────────────────────────────────────────────────────────

def list_hybrid_qml_components():
    """Print all available Hybrid QML components."""
    print("=" * 60)
    print("  PKTron Hybrid QML Library — Available Components")
    print("=" * 60)
    components = [
        ("Quantum Feature Maps", [
            "ZZFeatureMap(n_qubits, reps)",
            "PauliFeatureMap(n_qubits, paulis, reps)",
            "FidelityKernel(feature_map, n_qubits)",
        ]),
        ("Quantum Kernel Methods", [
            "ZZFeatureMap.kernel_matrix(X1, X2)",
            "PauliFeatureMap.kernel_matrix(X1, X2)",
            "FidelityKernel.kernel_matrix(X1, X2)",
            "FidelityKernel.evaluate(x1, x2)",
        ]),
        ("QSVM", [
            "QSVM(feature_map, n_qubits, C)",
            "QSVM.fit(X_train, y_train)",
            "QSVM.predict(X_test)",
            "QSVM.score(X_test, y_test)",
        ]),
        ("QGAN", [
            "QGAN(n_qubits, n_layers, lr_gen, lr_disc)",
            "QGAN.train(target_probs, epochs)",
            "QGAN.generate()",
            "QuantumGenerator.forward()",
            "QuantumGenerator.sample(n_samples)",
        ]),
        ("Quantum Conv Layer", [
            "QuantumConvLayer(kernel_size, stride, n_layers)",
            "QuantumConvLayer.forward(x)",
            "QuantumConvLayer.parameter_shift_grad(x, loss_fn)",
            "QuantumConvLayerTorch(...)  ← PyTorch nn.Module",
        ]),
        ("Variational Classifier", [
            "VariationalQuantumClassifier(n_qubits, n_layers)",
            "VariationalQuantumClassifier.forward(x)",
            "VariationalQuantumClassifier.predict(X)",
            "VariationalQuantumClassifier.score(X, y)",
        ]),
        ("Hybrid Training", [
            "HybridTrainingLoop(model, task, lr, epochs)",
            "HybridTrainingLoop.fit(X, y)",
            "HybridTrainingLoop.predict(X)",
            "HybridQNNTorch(input_dim, n_qubits, n_layers, output_dim)",
            "HybridTrainingLoopTorch(model, lr, epochs)",
        ]),
    ]
    for section, items in components:
        print(f"\n  [{section}]")
        for item in items:
            print(f"    • {item}")
    print("\n" + "=" * 60)
    torch_status = "✅" if TORCH_AVAILABLE else "❌ (pip install torch)"
    jax_status   = "✅" if JAX_AVAILABLE else "⚠️  optional"
    pl_status    = "✅" if PENNYLANE_AVAILABLE else "⚠️  optional"
    sk_status    = "✅" if SKLEARN_AVAILABLE else "❌ (pip install scikit-learn)"
    print(f"  PyTorch:     {torch_status}")
    print(f"  JAX:         {jax_status}")
    print(f"  PennyLane:   {pl_status}")
    print(f"  scikit-learn:{sk_status}")
    print("=" * 60)
