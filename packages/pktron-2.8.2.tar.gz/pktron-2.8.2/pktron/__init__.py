"""PKTron - High-Performance Quantum Circuit Simulator"""

__version__ = "2.8.2"

def _try_import(statement):
    try:
        exec(statement, globals())
    except Exception:
        pass

from .quantum import QuantumCircuit
from .parameters import Parameter, ParameterVector
from .gates import h, x, y, z, s, sdg, t, tdg, rx, ry, rz, cnot, cz, cy, swap, toffoli

_try_import("from .primitives import SamplerV2, EstimatorV2, SamplerResult, EstimatorResult")
_try_import("from .backend import StatevectorSimulator, StabilizerSimulator, execute, BackendV2")
_try_import("from .simulator import AerSimulator, DensityMatrixSimulator, AerResult")
_try_import("from .noise import NoiseModel, PauliError, DepolarizingError, AmplitudeDampingError, PhaseDampingError, ThermalRelaxationError")
_try_import("from .algorithms import quantum_flip, super_quantum_dance, quantum_treasure_hunt, quantum_magic_spin, bb84_qkd, grover_search, qft, phase_estimation, shor_period_finding, vqe, qaoa, hhl")
_try_import("from .algorithms_v2 import grover, quantum_phase_estimation, amplitude_amplification, shor, ShorResult")
_try_import("from .visualization import plot_histogram, plot_histogram_interactive, plot_bloch, plot_bloch_interactive, plot_error_analysis, plot_density_matrix")
_try_import("from .ml_visualization import variational_circuit, plot_loss_landscape")
_try_import("from .midcircuit import ClassicalRegister, DynamicCircuit")
_try_import("from .tensor_network import TensorNetworkSimulator, TensorNetworkResult")
_try_import("from .gpu import GPUStatevectorSimulator, GPUDensityMatrixSimulator, GPUResult")
_try_import("from .transpiler import PassManager, UnrollerPass, CancelCommutativePass, BasisTranslationPass, RZSynthesisPass, QuantumShannonDecompositionPass, TranspilerResult")
_try_import("from .transpiler_v2 import PassManager as PassManagerV2, UnrollToffoliPass, MergeRotationsPass, CancelInversePass, BasisTranslationPass as BasisTranslationPassV2")
_try_import("from .quantum_info import Statevector, DensityMatrix, Operator, Pauli, Clifford, state_fidelity, partial_trace")
_try_import("from .quantum_info_v2 import Statevector as StatevectorV2, DensityMatrix as DensityMatrixV2, Pauli as PauliV2, state_fidelity as state_fidelity_v2, concurrence")
_try_import("from .sparse_observable import SparseObservable, AdvancedEstimatorV2, AdvancedEstimatorResult, PauliProductMeasurement")
_try_import("from .advanced_visualization import draw_circuit_text, draw_circuit_mpl, plot_city, plot_hinton, plot_bloch_multi, EnhancedResult")
_try_import("from .performance import FullGPUStatevector, FullGPUDensityMatrix, StabilizerTableau, DecisionDiagramBackend, ParallelExecutor, AutoBackend, PerformanceResult")
_try_import("from .error_mitigation import ZeroNoiseExtrapolation, ProbabilisticErrorCancellation, ReadoutErrorMitigation, MitigatedEstimatorV2, MitigationResult")
_try_import("from .error_mitigation_v2 import ZNE, PEC, REM")
_try_import("from .hybrid_ml import QuantumLayer, TFQuantumLayer, GradientEstimator, QNNClassifier")
_try_import("from .qiskit_compat import QuantumRegister, SparsePauliOp, PauliSumOp, Aer, transpile, qiskit_execute")
_try_import("from .qiskit_compat_v2 import to_qasm, from_qasm, to_qiskit, from_qiskit, SparsePauliOpV2")
_try_import("from .benchmarks import run_benchmarks")
_try_import("from .noise_v2 import BitFlipError, PhaseFlipError, DepolarizingError as DepolarizingErrorV2, AmplitudeDampingError as AmplitudeDampingErrorV2, PhaseDampingError as PhaseDampingErrorV2, NoiseModel as NoiseModelV2")
_try_import("from .measurement import ClassicalRegister as ClassicalRegisterV2, measure_all, measure_partial, measure_qubit")
_try_import("from .fast_statevector import apply_1q, apply_2q, apply_3q, rx_mat, ry_mat, rz_mat, u1_mat, u2_mat, u3_mat")
_try_import("from .ai_assistant import generate_circuit, explain_circuit")
_try_import("from .step_simulator import run_step_by_step, print_steps, plot_steps")
_try_import("from .quantum_debugger import QuantumDebugger")
_try_import("from .auto_backend import select_backend, run_auto, backend_report")
_try_import("from .ops_parser import parse_ops")
_try_import("from .density_matrix_hp import HPDensityMatrixSimulator, HPDensityMatrixResult")
_try_import("from .tensor_network_hp import ProductionMPS, AutoSimulator, MPSResult")
_try_import("from .tensor_network_v3 import SmartMPS, SmartMPSResult")
_try_import("from .gpu_primitives import GPUBatchedSampler, GPUBatchedEstimator, gpu_execute")
_try_import("from .fault_tolerant import RepetitionCode, SteaneCode, SurfaceCode, LogicalQubit")
_try_import("from .bernstein_vazirani import BernsteinVazirani, BVOracle, BVResult")
_try_import("from .simons_algorithm import SimonsAlgorithm, SimonOracle")
_try_import("from .quantum_counting import GroverOracle, QuantumCounting, AmplitudeEstimator, MonteCarloBaseline")
_try_import("from .quantum_walk import QuantumWalk, DiscreteQuantumWalk, ContinuousQuantumWalk, QuantumWalkResult, build_graph, hitting_time_analysis, plot_walk, plot_walk_animation")
_try_import("from .qgan import QGAN, QGANResult, plot_qgan")
_try_import("from .qpca import qpca_fit, QPCAResult, incremental_qpca, quantum_kernel_pca, QKernelPCAResult, quantum_randomised_svd")
_try_import("from .hhl import hhl_solve, HHLResult, variational_qls, QLSResult, quantum_conjugate_gradient, randomised_kaczmarz")
_try_import("from .hhl_full import hhl_solve as hhl_solve_full, variational_qls as variational_qls_full, quantum_conjugate_gradient as qcg_full, randomised_kaczmarz as rk_full, quantum_preconditioned_gmres")
_try_import("from .shor_full import shor_factor, ShorResult as ShorResultFull, build_qft_matrix, build_inverse_qft_matrix")
_try_import("from .hybrid_qml import ZZFeatureMap, PauliFeatureMap, FidelityKernel, QSVM, QGAN as QGAN_ML, QuantumConvLayer, VariationalQuantumClassifier, HybridTrainingLoop")
_try_import("from .differentiable_v2 import DifferentiableCircuit")
_try_import("from .docs_and_benchmarks import run_full_benchmarks")

# Sub-packages
_try_import("from .crypto.qkd import BB84Protocol, EavesdroppingDetector")
_try_import("from .finance.api import QuantumFinance")
_try_import("from .hardware.emulator import HardwareEmulator, get_emulator")
_try_import("from .plugins.plugin_manager import PluginManager, GatePlugin, BackendPlugin, AlgorithmPlugin")
_try_import("from .profiler.profiler import PerformanceProfiler, ProfileResult")
