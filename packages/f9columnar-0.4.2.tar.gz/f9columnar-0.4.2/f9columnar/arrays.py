from __future__ import annotations

import copy
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Self, overload

import awkward as ak
import numpy as np

from f9columnar.analysis.utils import find_variation_in_branch
from f9columnar.processors import Processor
from f9columnar.utils.ak_helpers import check_list_type, check_numpy_type, format_ak_array

if TYPE_CHECKING:
    from f9columnar.variations import VariationMap


@dataclass
class BaseArrays:
    array: ak.Array

    @property
    def fields(self) -> list[str]:
        return self.array.fields

    @property
    def shape(self) -> tuple[int, int]:
        return (len(self.array), len(self.fields))

    def mask(self, mask: ak.Array | np.ndarray, inplace: bool = True) -> Self:
        if inplace:
            self.array = self.array[mask]
            return self
        else:
            return self.__class__(self.array[mask])

    def _check_type(self, value: Any) -> bool:
        raise NotImplementedError

    def __getitem__(self, value: str | int | slice | ak.Array | np.ndarray) -> ak.Array | Self:
        if type(value) is str or type(value) is int or type(value) is slice:
            return self.array[value]
        elif type(value) is ak.Array or type(value) is np.ndarray:
            return self.mask(value)
        else:
            raise ValueError("Value must be a field name or an array mask!")

    def __setitem__(self, field: str, new_array: ak.Array | np.ndarray) -> Self:
        if not self._check_type(new_array):
            raise ValueError(f"Field {field} is not of the correct type!")

        self.array[field] = new_array

        return self

    def __add__(self, other: BaseArrays) -> Self:
        try:
            self.array = ak.concatenate([self.array, other.array], axis=1)
        except Exception as e:
            raise ValueError("The two arrays are not compatible for concatenation!") from e

        return self

    def __delitem__(self, field: str) -> Self:
        self.array = ak.without_field(self.array, field)
        return self

    def __len__(self) -> int:
        if isinstance(self.array, ak.Array):
            return len(self.array)
        elif isinstance(self.array, ak.Record):
            return 1
        else:
            raise ValueError("Invalid array type!")


@dataclass
class FlatArrays(BaseArrays):
    def _check_type(self, array: ak.Array | np.ndarray | Any) -> bool:
        return check_numpy_type(array)

    def __str__(self) -> str:
        return f"{self.__class__.__name__}(shape={self.shape})"


@dataclass
class JaggedArrays(BaseArrays):
    def _check_type(self, array: ak.Array | Any) -> bool:
        return check_list_type(array)

    def __str__(self) -> str:
        return f"{self.__class__.__name__}(shape={self.shape})"


class Arrays:
    def __init__(self, flat_arrays: FlatArrays | None = None, jagged_arrays: JaggedArrays | None = None) -> None:
        """This class is used to store flat and jagged arrays separately. It is used to store awkward arrays in a more
        structured way. The funconality is similar to `ak.Array` but with seperate handling of flat and jagged arrays.
        It is intended to make it easier to work with ntuples that contain both flat and jagged fields.

        Parameters
        ----------
        flat_arrays : FlatArrays
            Flat arrays.
        jagged_arrays : JaggedArrays
            Jagged arrays.

        Other Parameters
        ----------------
        flat_fields : list
            List of flat fields.
        jagged_fields : list
            List of jagged fields.
        fields : list
            List of all fields.

        Attributes
        ----------
        shape : tuple
            Shape of the arrays (number of events, number of flat array, number of jagged arrays).

        """
        self.flat_arrays: FlatArrays | None = flat_arrays
        self.jagged_arrays: JaggedArrays | None = jagged_arrays

        self.flat_fields: list[str] = []
        self.jagged_fields: list[str] = []
        self.fields: list[str] = []

        self.update_fields()

    def update_fields(self) -> Arrays:
        self.fields = []
        self.flat_fields = []
        self.jagged_fields = []

        if self.flat_arrays is not None:
            self.flat_fields = self.flat_arrays.fields
            self.fields += self.flat_fields

        if self.jagged_arrays is not None:
            self.jagged_fields = self.jagged_arrays.fields
            self.fields += self.jagged_fields

        return self

    @property
    def shape(self) -> tuple[int, int, int]:
        return (len(self), len(self.flat_fields), len(self.jagged_fields))

    def mask_flat(self, mask: ak.Array | np.ndarray) -> tuple[FlatArrays | None, JaggedArrays | None]:
        flat_masked = self.flat_arrays.mask(mask, inplace=False) if self.flat_arrays is not None else None
        jagged_masked = self.jagged_arrays.mask(mask, inplace=False) if self.jagged_arrays is not None else None
        return flat_masked, jagged_masked

    def mask_flat_inplace(self, mask: ak.Array | np.ndarray) -> Arrays:
        if self.flat_arrays is not None:
            self.flat_arrays.mask(mask, inplace=True)

        if self.jagged_arrays is not None:
            self.jagged_arrays.mask(mask, inplace=True)

        return self

    def mask_jagged(self, mask: ak.Array | np.ndarray) -> JaggedArrays | None:
        jagged_masked = self.jagged_arrays.mask(mask, inplace=False) if self.jagged_arrays is not None else None
        return jagged_masked

    def mask_jagged_inplace(self, mask: ak.Array | np.ndarray) -> Arrays:
        if self.jagged_arrays is not None:
            self.jagged_arrays.mask(mask, inplace=True)

        return self

    def _get_by_field(self, field: str) -> ak.Array:
        if self.flat_arrays is not None and field in self.flat_fields:
            return self.flat_arrays[field]
        elif self.jagged_arrays is not None and field in self.jagged_fields:
            return self.jagged_arrays[field]
        else:
            raise KeyError(f"Field {field} not found in flat or jagged fields!")

    def _get_new_sliced_arrays(self, slice_idx: int | slice) -> Arrays:
        flat_slice, jagged_slice = None, None

        if self.flat_arrays is not None:
            flat_slice = FlatArrays(self.flat_arrays[slice_idx])

        if self.jagged_arrays is not None:
            jagged_slice = JaggedArrays(self.jagged_arrays[slice_idx])

        return self.__class__(flat_arrays=flat_slice, jagged_arrays=jagged_slice)

    def _get_new_masked_arrays(self, mask: ak.Array | np.ndarray) -> Arrays:
        if self.flat_arrays is None and self.jagged_arrays is None:
            return self

        if check_numpy_type(mask):
            flat_masked, jagged_masked = self.mask_flat(mask)
        elif self.jagged_arrays is not None and check_list_type(mask):
            flat_masked, jagged_masked = self.flat_arrays, self.mask_jagged(mask)
        else:
            raise ValueError("Invalid mask type!")

        return self.__class__(flat_arrays=flat_masked, jagged_arrays=jagged_masked)

    @overload
    def __getitem__(self, value: str) -> ak.Array: ...

    @overload
    def __getitem__(self, value: int | slice) -> Arrays: ...

    @overload
    def __getitem__(self, value: ak.Array | np.ndarray) -> Arrays: ...

    def __getitem__(self, value: str | int | slice | ak.Array | np.ndarray) -> ak.Array | Arrays:
        if type(value) is str:
            return self._get_by_field(value)
        elif type(value) is int or type(value) is slice:
            return self._get_new_sliced_arrays(value)
        elif type(value) is ak.Array or type(value) is np.ndarray:
            return self._get_new_masked_arrays(value)
        else:
            raise ValueError("Value must be a field name, int, array mask or slice!")

    def __setitem__(self, field: str, new_array: ak.Array | np.ndarray) -> Arrays:
        if check_numpy_type(new_array):
            if self.flat_arrays is None:
                self.flat_arrays = FlatArrays(ak.Array({field: new_array}))
            else:
                self.flat_arrays[field] = new_array
        elif check_list_type(new_array):
            if self.jagged_arrays is None:
                self.jagged_arrays = JaggedArrays(ak.Array({field: new_array}))
            else:
                self.jagged_arrays[field] = new_array
        else:
            raise ValueError("Array is not of the correct type!")

        self.update_fields()

        return self

    def __add__(self, other: Arrays) -> Arrays:
        if self.flat_arrays is not None and other.flat_arrays is not None:
            self.flat_arrays += other.flat_arrays

        if self.flat_arrays is None and other.flat_arrays is not None:
            self.flat_arrays = other.flat_arrays

        if self.jagged_arrays is not None and other.jagged_arrays is not None:
            self.jagged_arrays += other.jagged_arrays

        if self.jagged_arrays is None and other.jagged_arrays is not None:
            self.jagged_arrays = other.jagged_arrays

        self.update_fields()

        return self

    def __delitem__(self, field: str) -> Arrays:
        if self.flat_arrays is not None and field in self.flat_fields:
            del self.flat_arrays[field]

            if len(self.flat_arrays.fields) == 0:
                self.flat_arrays = None
        elif self.jagged_arrays is not None and field in self.jagged_fields:
            del self.jagged_arrays[field]

            if len(self.jagged_arrays.fields) == 0:
                self.jagged_arrays = None
        else:
            raise KeyError(f"Field {field} not found in flat or jagged fields!")

        self.update_fields()

        return self

    def __len__(self) -> int:
        if self.flat_arrays is None and self.jagged_arrays is not None:
            return len(self.jagged_arrays)
        elif self.flat_arrays is not None and self.jagged_arrays is None:
            return len(self.flat_arrays)
        elif self.flat_arrays is not None and self.jagged_arrays is not None:
            len_flat, len_jagged = len(self.flat_arrays), len(self.jagged_arrays)
            if len_flat != len_jagged:
                raise RuntimeError("Flat and jagged arrays have different lengths!")
            else:
                return len_flat
        else:
            logging.warning("No flat or jagged arrays found!")
            return 0

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(shape={self.shape})"

    def __str__(self) -> str:
        return self.__repr__()

    @staticmethod
    def format_array(array: ak.Array, n: int | None = 10, precision: int = 3, print_output: bool = False) -> str:
        array_formatted = format_ak_array(array, n=n, precision=precision)
        if print_output:
            print(array_formatted)
            return ""
        return format_ak_array(array, n=n, precision=precision)


class GroupArrays:
    def __init__(self, group_arrays: dict[str, Arrays]) -> None:
        """A dictionary wrapper for `Arrays` objects. This class is used to store multiple `Arrays` objects.

        Parameters
        ----------
        group_arrays : dict
            Dictionary of `Arrays` objects.

        Other Parameters
        ----------------
        group_field_map : dict
            Dictionary mapping group names to fields.
        field_group_map : dict
            Dictionary mapping fields to group names.
        groups : list
            List of group names.
        fields : list
            List of all fields.

        Note
        ----
        This class is used for seperating different groups (each represented by an `Arrays` object). For example,
        groups can be used to seperate different particle types in an ntuple. Groups can be
        "electron", "muon", "jet", etc. Each group has its own `Arrays` object with flat and jagged fields.

        """
        self.group_arrays = group_arrays

        self.group_field_map: dict[str, list[str]] = {}
        self.field_group_map: dict[str, str] = {}

        self.groups: list[str] = []
        self.fields: list[str] = []

        self.update_fields()

    def update_fields(self) -> None:
        self.group_field_map, self.field_group_map = {}, {}

        for group, arrays in self.group_arrays.items():
            fields = arrays.fields
            self.group_field_map[group] = fields

            for field in fields:
                self.field_group_map[field] = group

        self.groups = list(self.group_arrays.keys())
        self.fields = list(self.field_group_map.keys())

    @property
    def shape(self) -> dict[str, tuple[int, int, int]]:
        return {group: arrays.shape for group, arrays in self.group_arrays.items()}

    def copy(self) -> GroupArrays:
        new_group_arrays = copy.copy(self.group_arrays)
        return self.__class__(group_arrays=new_group_arrays)

    def deepcopy(self, variation: str | None = None) -> GroupArrays:
        """Create a deep copy of the GroupArrays, optionally filtering by variation.

        Parameters
        ----------
        variation : str or None, optional
            If provided, only copy branches relevant to this variation:
                - "nominal": only copy branches without variation suffixes
                - Any other string: copy nominal branches and branches matching this variation
                - None: copy all branches (default behavior)

        Returns
        -------
        GroupArrays
            A deep copy of the GroupArrays with filtered branches if variation is specified.

        """
        if variation is None:
            # deep copy everything
            new_group_arrays = copy.deepcopy(self.group_arrays)
            return self.__class__(group_arrays=new_group_arrays)

        # filter branches based on variation
        new_group_arrays = {}

        for group_name, group_array in self.group_arrays.items():
            fields_to_keep = []

            for field in group_array.fields:
                field_variation = find_variation_in_branch(field)

                if variation == "nominal":
                    # keep only branches without variation suffixes
                    if field_variation is None:
                        fields_to_keep.append(field)
                else:
                    # keep nominal branches and branches matching this variation
                    if field_variation is None or field_variation == variation:
                        fields_to_keep.append(field)

            if len(fields_to_keep) == 0:
                continue

            # create filtered Arrays object for this group
            filtered_flat = None
            filtered_jagged = None

            if group_array.flat_arrays is not None:
                flat_fields = [f for f in fields_to_keep if f in group_array.flat_fields]
                if flat_fields:
                    flat_ak_array = group_array.flat_arrays.array[flat_fields]
                    filtered_flat = FlatArrays(copy.deepcopy(flat_ak_array))

            if group_array.jagged_arrays is not None:
                jagged_fields = [f for f in fields_to_keep if f in group_array.jagged_fields]
                if jagged_fields:
                    jagged_ak_array = group_array.jagged_arrays.array[jagged_fields]
                    filtered_jagged = JaggedArrays(copy.deepcopy(jagged_ak_array))

            new_group_arrays[group_name] = Arrays(flat_arrays=filtered_flat, jagged_arrays=filtered_jagged)

        return self.__class__(group_arrays=new_group_arrays)

    def __setitem__(
        self,
        value: str | tuple[str, str | None],
        new_array: Arrays | ak.Array | np.ndarray,
    ) -> GroupArrays:
        # overwrite in the case of setting entire Arrays object on the existing group
        if type(value) is str and value in self.groups and type(new_array) is Arrays:
            self.group_arrays[value] = new_array
            self.update_fields()
            return self

        if type(value) is tuple:
            group, field = value
        elif type(value) is str:
            if value in self.fields:
                group = self.field_group_map[value]
                field = value
            else:
                group, field = "other", value
        else:
            raise TypeError(f"Invalid type for {value}!")

        if field is not None and group != "other" and not field.startswith(f"{group}_"):
            field = f"{group}_{field}"

        if group in self.groups:
            if type(new_array) is Arrays:
                if field is not None:
                    raise ValueError("Field name must be None when setting Arrays object!")
                else:
                    self.group_arrays[group] = self.group_arrays[group] + new_array
            elif type(new_array) is ak.Array or type(new_array) is np.ndarray:
                arrays = self.group_arrays[group]

                if field is None:
                    raise ValueError("Field name must be provided when setting array!")

                arrays[field] = new_array
                self.group_arrays[group] = arrays
            else:
                raise TypeError(f"Invalid type for {new_array}!")
        else:
            if type(new_array) is Arrays:
                if field is not None:
                    raise ValueError("Field name must be None when setting Arrays object!")
                else:
                    self.group_arrays[group] = new_array
            elif type(new_array) is np.ndarray or type(new_array) is ak.Array:
                if field is None:
                    raise ValueError("Field name must be provided when setting array!")

                new_array = ak.Array({field: new_array})
            else:
                raise TypeError(f"Invalid type for {new_array}!")

            if type(new_array) is ak.Array or type(new_array) is np.ndarray:
                arrays_handler = ArraysHandler()
                self.group_arrays[group] = arrays_handler.make_arrays(new_array)

        self.update_fields()

        return self

    @overload
    def __getitem__(self, value: str) -> ak.Array | Arrays: ...

    @overload
    def __getitem__(self, value: tuple[str, str]) -> ak.Array: ...

    @overload
    def __getitem__(self, value: tuple[str, int | slice | ak.Array | np.ndarray]) -> GroupArrays: ...

    @overload
    def __getitem__(self, value: tuple[None, int | slice | ak.Array | np.ndarray]) -> GroupArrays: ...

    def __getitem__(
        self, value: str | None | tuple[str | None, str | int | slice | ak.Array | np.ndarray]
    ) -> ak.Array | Arrays | GroupArrays:
        if type(value) is tuple:
            value, other_value = value
        else:
            value, other_value = value, None

        if type(value) is not str and value is not None:
            raise TypeError(f"Invalid type for {value}. Should be group name, field name or None for all groups!")

        elif other_value is None:
            if value in self.groups:
                return self.group_arrays[value]
            elif value in self.fields:
                group = self.field_group_map[value]
                return self.group_arrays[group][value]
            else:
                raise KeyError(f"Group or field {value} not found!")

        elif type(other_value) is str:
            if value is None:
                raise ValueError("Field name cannot be set to all groups!")

            return self.group_arrays[value][other_value]

        elif type(other_value) is not str:
            new_group_arrays = copy.copy(self.group_arrays)

            if value is None:  # event-level change for all groups
                for group, group_arrays in self.group_arrays.items():
                    new_group_arrays[group] = group_arrays[other_value]

                return self.__class__(group_arrays=new_group_arrays)

            if value in self.groups:
                group, field = value, None
            elif value in self.fields:
                group, field = self.field_group_map[value], value
            else:
                raise KeyError(f"Group or field {value} not found!")

            if field is None:
                new_group_arrays[group] = new_group_arrays[group][other_value]
            else:
                raise ValueError("Field modification would make array irregular!")

            return self.__class__(group_arrays=new_group_arrays)

        else:
            raise TypeError(f"Invalid type for {other_value}!")

    def count_group_particles(self) -> dict[str, int]:
        groups_n: dict[str, int] = {}

        for group in self.groups:
            arrays = self.group_arrays[group]
            jagged_fields = arrays.jagged_fields

            if len(jagged_fields) == 0:
                continue

            jagged_field = jagged_fields[0]
            n_group = ak.count(arrays[jagged_field], axis=None)
            groups_n[group] = n_group

        return groups_n

    def add_varied_array(
        self,
        array: ak.Array | np.ndarray,
        branch: str,
        variation: str | None = None,
        variation_map: VariationMap | None = None,
        group: str | None = None,
    ) -> GroupArrays:
        if branch.endswith("_NOSYS"):
            postfix = ""
        elif variation == "nominal":
            postfix = "_NOSYS"
        elif variation is not None:
            postfix = f"_{variation}"
        else:
            postfix = ""

        if group is None:
            group = branch.split("_")[0]

        if variation_map is not None and variation is not None and postfix != "_NOSYS":
            if variation.split("__")[0] not in variation_map.variation_groups[group]:
                postfix = "_NOSYS"

        self.group_arrays[group][f"{branch}{postfix}"] = array
        self.update_fields()

        return self

    def __delitem__(self, value: str) -> GroupArrays:
        if value not in self.groups and value not in self.fields:
            raise KeyError(f"Group or field {value} not found!")

        if value in self.fields:
            group = self.field_group_map[value]
            del self.group_arrays[group][value]

        if value in self.groups:
            del self.group_arrays[value]

        self.update_fields()

        return self

    def __len__(self) -> int:
        len_dct = {group: len(arrays) for group, arrays in self.group_arrays.items()}
        len_lst = list(len_dct.values())

        if len(set(len_lst)) != 1:
            raise RuntimeError("Groups have different lengths!")

        return len_lst[0]

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(groups={self.shape})"

    def __str__(self) -> str:
        return self.__repr__()

    def format_array(
        self,
        *arrays_names: str,
        n: int | None = 10,
        precision: int = 3,
        print_output: bool = False,
        sep: str = "    ",
    ) -> str:
        arrays: list[ak.Array] = [self.__getitem__(name) for name in arrays_names]

        if len(arrays) == 1 and isinstance(arrays[0], (list, tuple)):
            arrays = tuple(arrays[0])  # type: ignore[assignment]

        if len(arrays) == 0:
            raise ValueError("At least one ak.Array must be provided!")

        blocks: list[list[str]] = [
            format_ak_array(arr, n=n, precision=precision, name=name).splitlines()
            for arr, name in zip(arrays, arrays_names)
        ]
        widths: list[int] = [max((len(line) for line in block), default=0) for block in blocks]
        height: int = max((len(block) for block in blocks), default=0)

        out_lines: list[str] = []
        for i in range(height):
            parts: list[str] = []
            for block, w in zip(blocks, widths, strict=False):
                line = block[i] if i < len(block) else ""
                parts.append(line.ljust(w))
            out_lines.append(sep.join(parts).rstrip())

        out = "\n".join(out_lines)
        if print_output:
            print(out)
            return ""

        return out


class ArraysHandler:
    @staticmethod
    def _get_fields(arrays: ak.Array) -> tuple[list[str], list[str], list[str]]:
        arrays_contents = arrays.type.content.contents
        arrays_fields = arrays.type.content.fields

        flat_fields, jagged_fields, other_fields = [], [], []

        for content, array_field in zip(arrays_contents, arrays_fields, strict=False):
            if isinstance(content, ak.types.NumpyType):
                flat_fields.append(array_field)
            elif isinstance(content, ak.types.ListType):
                jagged_fields.append(array_field)
            else:
                other_fields.append(array_field)

        return flat_fields, jagged_fields, other_fields

    def make_arrays(self, arrays: ak.Array) -> Arrays:
        flat_fields, jagged_fields, _ = self._get_fields(arrays)

        flat_arrays, jagged_arrays = None, None

        if len(flat_fields) != 0:
            flat_arrays = arrays[flat_fields]
            flat_arrays = FlatArrays(flat_arrays)

        if len(jagged_fields) != 0:
            jagged_arrays = arrays[jagged_fields]
            jagged_arrays = JaggedArrays(jagged_arrays)

        return Arrays(flat_arrays=flat_arrays, jagged_arrays=jagged_arrays)

    def make_array_groups(self, arrays: ak.Array, groups: list[str]) -> GroupArrays:
        fields = arrays.fields

        group_arrays_dct, all_group_fields = {}, []

        for group in groups:
            group_fields = [field for field in fields if field.startswith(f"{group}_")]
            all_group_fields += group_fields

            group_arrays = arrays[group_fields]

            if len(group_fields) == 0:
                continue

            group_arrays_dct[group] = self.make_arrays(group_arrays)

        non_group_fields = list(set(fields) - set(all_group_fields))

        if len(non_group_fields) != 0:
            non_group_arrays = arrays[non_group_fields]
            group_arrays_dct["other"] = self.make_arrays(non_group_arrays)

        return GroupArrays(group_arrays=group_arrays_dct)


class ArraysProcessor(Processor):
    def __init__(self, groups: list[str] | None = None) -> None:
        """Processor to separate flat and jagged fields into two arrays from an awkward array.

        Parameters
        ----------
        groups : list, optional
            List of group names. If provided, the arrays will be separated into groups based on the group names. If
            not provided, the arrays will be separated into flat and jagged fields.

        Note
        ----
        This will modify the input arrays. It is intended to be used as the first processor in the analysis chain in
        the case of ntuples that contain both flat and jagged fields.

        Returns
        -------
        Returned arrays `GroupArrays` if groups are provided, otherwise `Arrays` object.

        """
        super().__init__(name="arraysProcessor", disable_variations=True)
        self.groups = groups
        self.arrays_handler = ArraysHandler()

    def run(self, arrays: ak.Array) -> dict[str, Arrays | GroupArrays]:
        if self.groups is None:
            arrays = self.arrays_handler.make_arrays(arrays)
        else:
            arrays = self.arrays_handler.make_array_groups(arrays, self.groups)

        return {"arrays": arrays}


def arrays_to_ak(arrays: Arrays) -> ak.Array:
    fields: dict[str, ak.Array] = {}

    if arrays.flat_arrays is not None:
        for field in arrays.flat_arrays.fields:
            fields[field] = arrays.flat_arrays.array[field]

    if arrays.jagged_arrays is not None:
        for field in arrays.jagged_arrays.fields:
            fields[field] = arrays.jagged_arrays.array[field]

    return ak.zip(fields, depth_limit=1)


def group_arrays_to_ak(group_arrays: GroupArrays) -> ak.Array:
    group_fields: dict[str, ak.Array] = {}

    for _, arrays in group_arrays.group_arrays.items():
        if arrays.flat_arrays is not None:
            for field in arrays.flat_arrays.fields:
                group_fields[field] = arrays.flat_arrays.array[field]

        if arrays.jagged_arrays is not None:
            for field in arrays.jagged_arrays.fields:
                group_fields[field] = arrays.jagged_arrays.array[field]

    return ak.zip(group_fields, depth_limit=1)
