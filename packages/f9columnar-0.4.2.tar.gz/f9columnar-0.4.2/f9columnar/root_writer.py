from pathlib import Path

import awkward as ak
import uproot

from f9columnar.processors import Postprocessor, Processor


class RootWriterPostprocessor(Postprocessor):
    def __init__(
        self,
        output_files_path: str,
        events_per_file: int,
        save_file_prefix: str = "",
        save_node: str = "output",
        tree_name: str = "physics",
        compression_level: int = 4,
        disable: bool = False,
        prefix: str = "",
    ) -> None:
        """Postprocessor that writes awkward arrays to ROOT files, splitting across multiple files.

        Accumulates events from the processing pipeline and writes them to ROOT files
        using uproot. When the number of buffered events reaches `events_per_file`,
        the buffer is flushed to a ROOT file and a new file is started.

        Output files are named with an incrementing index:
        `{stem}_{index}{suffix}` (e.g., `output_0.root`, `output_1.root`).

        Parameters
        ----------
        output_files_path : str
            Base path for the output ROOT files.
        events_per_file : int
            Maximum number of events per ROOT file.
        save_file_prefix : str, optional
            Optional prefix for the output file names, by default "".
        save_node : str, optional
            Name of the processor node to read arrays from, by default "output".
        tree_name : str, optional
            Name of the TTree in the ROOT file, by default "physics".
        compression_level : int, optional
            ZSTD compression level (0-9), by default 1.
        disable : bool, optional
            Whether to disable this postprocessor, by default False.
        prefix : str, optional
            Optional prefix for the processor name, by default "".
        """
        super().__init__(name=f"{prefix}rootWriterPostprocessor")
        self.output_files_path = output_files_path
        self.events_per_file = int(events_per_file)
        self.save_file_prefix = save_file_prefix
        self.save_node = save_node
        self.tree_name = tree_name
        self.compression_level = compression_level
        self.disable = disable

        Path(self.output_files_path).parent.mkdir(parents=True, exist_ok=True)

        self._file_prefix: str = ""
        self._current_file_prefix: str | None = None
        self._buffer: ak.Array | None = None
        self._file_idx: int = 0

    def _get_file_path(self, idx: int) -> str:
        path = Path(self.output_files_path)

        suffix = path.suffix
        if suffix == ".root":
            return str(path.parent / f"{self.save_file_prefix}{self._file_prefix}_output_{idx}{suffix}")
        else:
            return str(path / f"{self.save_file_prefix}{self._file_prefix}_output_{idx}.root")

    def _write_root_file(self, arrays: ak.Array) -> None:
        file_path = self._get_file_path(self._file_idx)

        array_dct = {field: arrays[field] for field in arrays.fields}
        compression = uproot.ZSTD(self.compression_level)

        with uproot.recreate(file_path, compression=compression) as f:
            f.mktree(self.tree_name, array_dct)

        self._file_idx += 1

    def run(self, processors: dict[str, Processor]) -> dict[str, dict[str, Processor]]:
        if self.disable:
            return {"processors": processors}

        arrays_processor = processors[self.save_node]

        self._file_prefix = arrays_processor.reports.get("name", self.save_node)

        if self._current_file_prefix is not None and self._current_file_prefix != self._file_prefix:
            _file_prefix = self._file_prefix
            self._file_prefix = self._current_file_prefix
            self.finalize()
            self._file_idx, self._file_prefix = 0, _file_prefix

        self._current_file_prefix = self._file_prefix

        if hasattr(arrays_processor, "arrays"):
            arrays = arrays_processor.arrays
        else:
            raise AttributeError("Arrays attribute not found in the processor!")

        if arrays is None or len(arrays) == 0:
            return {"processors": processors}

        if self._buffer is None:
            self._buffer = arrays
        else:
            self._buffer = ak.concatenate([self._buffer, arrays])

        while len(self._buffer) >= self.events_per_file:
            to_write = self._buffer[: self.events_per_file]
            self._buffer = self._buffer[self.events_per_file :]
            self._write_root_file(to_write)

        return {"processors": processors}

    def finalize(self) -> None:
        if self._buffer is not None and len(self._buffer) > 0:
            self._write_root_file(self._buffer)
            self._buffer = None
