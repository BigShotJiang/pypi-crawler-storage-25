import logging

import matplotlib.pyplot as plt
import mplhep as hep
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from plothist import plot_data_model_comparison, plot_hist, plot_model

from f9columnar.analysis.config.analysis_config import PlotConfig, PlottingConfig
from f9columnar.analysis.merge_hists import MergedHistsBuilder
from f9columnar.analysis.plotting.labels import switch_on_label
from f9columnar.analysis.plotting.variables import switch_on_variable
from f9columnar.utils.loggers import get_progress


class MergedHistsPlotter:
    def __init__(self, builder: MergedHistsBuilder) -> None:
        self.builder = builder

    def plot(
        self,
        variable: str,
        datasets: list[str] | None = None,
        years: list[int] | None = None,
        campaigns: list[str] | None = None,
        plot_signals: list[str] | None = None,
        plot_config: PlotConfig | None = None,
        variation: str = "nominal",
        save_path: str | None = None,
    ) -> tuple[plt.Figure, plt.Axes, plt.Axes | None]:
        if plot_config is None:
            plot_config = PlotConfig()

        dataset_hists = self.builder.get_dataset_hists(
            variable, datasets, years, campaigns, variation, group_key=plot_config.group_key
        )

        data_hists, samples_hists, signals_hists = self.builder.merge_requested_hists(
            dataset_hists, plot_signals=plot_signals
        )
        grouped_samples_hists = self.builder.group_hists_by_dataset(samples_hists)

        mc_names, mc_hists = list(grouped_samples_hists.keys()), list(grouped_samples_hists.values())

        mc_hists_sums = np.array([h.sum().value for h in mc_hists])  # type: ignore[union-attr]
        sorted_idx = np.argsort(mc_hists_sums)

        mc_names, mc_hists = [mc_names[i] for i in sorted_idx], [mc_hists[i] for i in sorted_idx]

        self.builder.apply_hist_transformations(
            data_hists,
            mc_hists,
            signals_hists,
            hist_range=plot_config.hist_range,
            hist_bins=plot_config.hist_bins,
            hist_edges=plot_config.hist_edges,
        )

        if plot_config.mc_only:
            data_hists.clear()

        if plot_config.data_only:
            mc_names, mc_hists = [], []
            signals_hists.clear()

        has_data = True if "data" in data_hists else False
        has_mc = True if len(mc_hists) > 0 else False
        has_signal = True if len(signals_hists) > 0 else False

        if not has_data and not has_mc and not has_signal:
            raise ValueError("No data, MC, or signal histograms to plot!")

        if not has_mc and has_data and has_signal:
            raise ValueError("Cannot plot data and signal without MC samples!")

        if plot_config.use_atlas_style:
            plt.style.use(hep.style.ATLAS)

        xlabel = plot_config.xlabel if plot_config.xlabel is not None else switch_on_variable(variable).latex_name
        ylabel = plot_config.ylabel if plot_config.ylabel is not None else "Events"

        if has_mc:
            mc_labels: list[str] = []
            mc_colors: list[str] = []
            for name in mc_names:
                label = switch_on_label(name)
                mc_labels.append(label.latex_name)

                color = label.color
                if color is None:
                    color = "C" + str(len(mc_colors))
                mc_colors.append(color)

        if has_data and has_mc:
            fig, ax, ax_comparison = plot_data_model_comparison(
                data_hist=data_hists["data"],
                stacked_components=mc_hists,
                stacked_labels=mc_labels,
                stacked_colors=mc_colors,
                xlabel=xlabel,
                ylabel=ylabel,
                data_uncertainty_type="symmetrical",
            )

            ax_comparison.set_ylabel("Data / Pred.")

            if plot_config.xscale == "log":
                ax.set_xscale("log")

            ax.set_xlabel("")
            ax.xaxis.set_ticklabels([])
            ax.xaxis.set_ticks([])

            ax_comparison.set_ylim(*plot_config.comparison_ylim)

            if plot_config.comparison_hline_space is not None:
                low, high = plot_config.comparison_ylim
                step = plot_config.comparison_hline_space
                start = 1.0 - int((1.0 - low) / step) * step
                for y in np.arange(start, high + step / 2, step):
                    ax_comparison.axhline(y, color="black", linestyle=":", linewidth=0.8, alpha=0.7)

        else:
            ax_comparison = None

        if not has_data and has_mc:
            fig, ax = plot_model(
                stacked_components=mc_hists,
                stacked_labels=mc_labels,
                stacked_colors=mc_colors,
                xlabel=xlabel,
                ylabel=ylabel,
                model_sum_kwargs={"show": False},
            )

        if has_data and not has_mc:
            fig, ax = plt.subplots()
            hep.histplot(
                data_hists["data"],
                ax=ax,
                color="black",
                label="Data",
                histtype="errorbar",
            )
            ax.set_xlabel(plot_config.xlabel if plot_config.xlabel is not None else "Data")
            ax.set_ylabel(ylabel)

        if has_signal:
            if not has_mc:
                fig, ax = plt.subplots()

            for signal_name, signal_hist in signals_hists.items():
                signal_label = switch_on_label(signal_name)

                signal_name = signal_label.latex_name
                signal_color = signal_label.color

                plot_hist(
                    signal_hist,
                    ax=ax,
                    color=signal_color,
                    label=signal_name,
                    histtype="step",
                    xlabel=xlabel,
                    ylabel=ylabel,
                )

        ax.legend(loc="upper right", fontsize=10, ncol=2)

        w, h = plot_config.figsize_inch
        if ax_comparison is None:
            h *= 0.7
        fig.set_size_inches(w, h)

        if plot_config.xscale == "log":
            if ax_comparison is not None:
                ax_comparison.set_xscale("log")
            else:
                ax.set_xscale("log")

        if plot_config.yscale == "log":
            ax.set_yscale("log")

        if plot_config.xlim is not None:
            ax.set_xlim(*plot_config.xlim)

            if ax_comparison is not None:
                ax_comparison.set_xlim(*plot_config.xlim)

        if plot_config.auto_ylim:
            _, ymax = ax.get_ylim()
            if plot_config.yscale == "log":
                ax.set_ylim(0.01, ymax * 100)
            else:
                ax.set_ylim(0, ymax * 1.2)

        if plot_config.ylim is not None:
            ax.set_ylim(*plot_config.ylim)

        if campaigns is not None:
            total_luminosity = self.builder.get_total_luminosity_from_mc(campaigns)
        elif years is not None:
            total_luminosity = self.builder.get_total_luminosity_from_data(years)
        else:
            total_luminosity = None

        if plot_config.atlas_label is not None:
            hep.atlas.label(
                plot_config.atlas_label,
                data=True,
                lumi=f"{total_luminosity:.1f}" if total_luminosity is not None else None,
                com=plot_config.com,
                fontsize=11,
                ax=ax,
            )

        if plot_config.title is not None:
            title_loc = plot_config.title_loc if plot_config.title_loc is not None else "center"
            ax.set_title(plot_config.title, loc=title_loc, fontsize=16)

        if save_path is not None:
            fig.tight_layout()
            fig.savefig(save_path)

        return fig, ax, ax_comparison

    def multi_plot(
        self,
        plot_configs: dict[str, list[PlotConfig]] | PlottingConfig | None = None,
        datasets: list[str] | None = None,
        years: list[int] | None = None,
        campaigns: list[str] | None = None,
        plot_signals: list[str] | None = None,
        variation: str = "nominal",
        save_path: str | None = None,
    ) -> None:
        """Plot multiple variables with their respective configurations.

        Parameters
        ----------
        plot_configs : dict[str, list[PlotConfig]] | None, optional
            Dictionary mapping variable names to a list of PlotConfigs.
            Each PlotConfig produces one page in the PDF.
        datasets : list[str] | None, optional
            List of dataset patterns to include.
        years : list[int] | None, optional
            List of years to include for data.
        campaigns : list[str] | None, optional
            List of campaigns to include for MC.
        plot_signals : list[str] | None, optional
            List of signal names to plot.
        variation : str, default="nominal"
            Systematic variation to plot.
        save_path : str | None, optional
            Path to save PDF file with all plots. If None, plots are not saved.
        """
        if save_path is None:
            raise ValueError("save_path must be provided for multi_plot!")

        if not save_path.endswith(".pdf"):
            raise ValueError("save_path must end with .pdf!")

        if plot_configs is None:
            plot_configs = {}

        if isinstance(plot_configs, PlottingConfig):
            plot_configs = plot_configs.plotting_config

        default_plot_config = PlotConfig()

        variables = list(plot_configs.keys())

        if len(variables) == 0:
            raise ValueError("No variables defined in plotting config to plot!")

        progress = get_progress()
        progress.start()
        task = progress.add_task("Creating plots", total=len(variables))

        logging.info(f"Saving plots to {save_path}...")

        with PdfPages(save_path) as pdf:
            for variable in variables:
                configs = plot_configs.get(variable, [default_plot_config])

                for config in configs:
                    fig, _, _ = self.plot(
                        variable=variable,
                        datasets=datasets,
                        years=years,
                        campaigns=campaigns,
                        plot_signals=plot_signals,
                        plot_config=config,
                        variation=variation,
                    )

                    pdf.savefig(fig)
                    plt.close(fig)

                progress.advance(task)

        progress.stop()
