import argparse
import logging
import os

from f9columnar.analysis.config import AnalysisConfig, AnalysisConfigBuilder
from f9columnar.analysis.config.analysis_config import PlotConfig
from f9columnar.analysis.merge_hists import MergedHistsBuilder
from f9columnar.analysis.plotting.plot_merged_hists import MergedHistsPlotter
from f9columnar.utils.helpers import load_pickle
from f9columnar.utils.loggers import setup_logger


def _get_analysis_config(config_path: str) -> AnalysisConfig:
    analysis_config_builder = AnalysisConfigBuilder(config_path)
    return analysis_config_builder.build()


def main() -> None:
    setup_logger()

    parser = argparse.ArgumentParser(description="Plotting of the merged histograms.")

    parser.add_argument(
        "-c",
        "--config-path",
        dest="config_path",
        required=True,
        help="Path to the analysis configuration file (e.g., 'config/zpeak_config.yaml').",
    )
    parser.add_argument(
        "-m",
        "--merged-path",
        dest="merged_path",
        required=False,
        help="Path to the merged histograms file.",
    )
    parser.add_argument(
        "-f",
        "--fake-sample",
        dest="fake_sample",
        required=False,
        help="Path to the fake sample file.",
    )
    parser.add_argument(
        "-n",
        "--plots-name",
        dest="plots_name",
        required=False,
        help="Name of the plots to be saved.",
    )
    args = parser.parse_args()

    analysis_config = _get_analysis_config(args.config_path)

    analysis_config_builder = AnalysisConfigBuilder(args.config_path)
    analysis_config_builder.build()

    submit_dir = analysis_config.submit.submit_dir
    job_name = analysis_config.submit.job_name

    if args.merged_path is not None:
        merged_path = args.merged_path
    else:
        merged_path = os.path.join(submit_dir, job_name, "merged", f"{job_name}_merged_hists.p")

    if args.fake_sample is not None:
        fake_sample_path = args.fake_sample
    else:
        fake_sample_path = analysis_config.user_config.get("fake_sample", None)

    if args.plots_name is not None:
        plots_name = args.plots_name
    else:
        if job_name is None or job_name == "":
            raise ValueError("Job name not specified in config or as argument! Provide -n argument for plot name.")
        plots_name = job_name

    builder = MergedHistsBuilder(merged_path)
    builder.print_summary()

    if fake_sample_path is not None:
        logging.info(f"Loading fake sample from: {fake_sample_path}")
        builder.merged_hists.update(load_pickle(fake_sample_path))

    plotter = MergedHistsPlotter(builder)

    plot_save_path = os.path.join(analysis_config.common.results_path, "plots")
    os.makedirs(plot_save_path, exist_ok=True)

    plotting_config = analysis_config.plotting_config

    if plotting_config.plot_mode == "auto":
        # discover all group keys from the merged hists
        group_keys: set[str] = set()
        for dataset, group_hists in builder.merged_hists.items():
            if isinstance(group_hists, dict):
                group_keys.update(group_hists.keys())

        base_plot_configs = plotting_config.plotting_config

        for group_key in sorted(group_keys):
            # get prefix from first variable in this group (e.g. "tight" from "tight_el_eta_OS")
            prefix = None
            for ds_data in builder.merged_hists.values():
                if isinstance(ds_data, dict) and group_key in ds_data:
                    for var_data in ds_data[group_key].values():
                        if isinstance(var_data, dict) and var_data:
                            prefix = next(iter(var_data)).split("_")[0]
                            break
                    break

            if prefix is None:
                logging.warning(f"No variables found in group key: {group_key}")
                continue

            # map config var names to actual variable names with group_key set
            auto_plot_configs: dict[str, list[PlotConfig]] = {}
            for config_var_name, plot_config_list in base_plot_configs.items():
                actual_var_name = f"{prefix}_{config_var_name}"
                new_configs = []
                for pc in plot_config_list:
                    pc_dict = pc.to_dict()
                    pc_dict["group_key"] = group_key
                    new_configs.append(PlotConfig(**pc_dict))
                auto_plot_configs[actual_var_name] = new_configs

            save_path = os.path.join(plot_save_path, job_name, f"{group_key}.pdf")
            os.makedirs(os.path.dirname(save_path), exist_ok=True)

            logging.info(f"Plotting {len(auto_plot_configs)} variables for group key: {group_key}")

            plotter.multi_plot(
                plot_configs=auto_plot_configs,
                years=plotting_config.years,
                campaigns=plotting_config.campaigns,
                datasets=plotting_config.datasets,
                plot_signals=plotting_config.plot_signals,
                save_path=save_path,
            )
    else:
        # manual mode
        save_path = os.path.join(plot_save_path, job_name, f"{plots_name}.pdf")
        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        plotter.multi_plot(
            plot_configs=plotting_config,
            years=plotting_config.years,
            campaigns=plotting_config.campaigns,
            datasets=plotting_config.datasets,
            plot_signals=plotting_config.plot_signals,
            save_path=save_path,
        )


if __name__ == "__main__":
    main()
