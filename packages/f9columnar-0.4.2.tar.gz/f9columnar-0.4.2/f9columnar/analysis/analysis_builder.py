from __future__ import annotations

import copy
import glob
import inspect
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Type

import yaml

from f9columnar.analysis.common import FinalEventWeight, RunNumberProcessor, SampleInfoProcessor
from f9columnar.analysis.config import (
    AnalysisConfig,
    AnalysisConfigBuilder,
    SamplesConfig,
    SamplesConfigBuilder,
    XsecBuilder,
    XsecConfig,
)
from f9columnar.analysis.config.analysis_config import ALLOWED_CONFIG_KEYS, resolve_yaml_inserts
from f9columnar.analysis.jets import JetScaleFactors, JetSelection, PCFTbJetVeto, PCFTcJetVeto
from f9columnar.analysis.leptons import (
    BadMuonVeto,
    ElectronCrackVeto,
    ElectronScaleFactors,
    LeptonMultiplicity,
    LeptonSelection,
    MuonScaleFactors,
    TauPassMuonOLR,
    TauScaleFactors,
)
from f9columnar.analysis.regions import ElectronType, MuonType, SelectRegion, TauType
from f9columnar.analysis.trigger.lepton_trigger_cascade import TriggerCascade
from f9columnar.analysis.trigger.lepton_triggers import (
    DiLeptonCompleteTrigger,
    DiLeptonLooseTrigger,
    DiTauTrigger,
    LeptonTauTrigger,
    SingleElectronFakesTrigger,
    SingleLeptonTrigger,
    SingleMuonFakesTrigger,
)
from f9columnar.analysis.trigger.trigger_efficiency import TriggerEfficiency
from f9columnar.analysis.truth_matching import LeptonTruthMatching
from f9columnar.arrays import ArraysProcessor
from f9columnar.dataset_builder import NtupleDatasetBuilder, RootPhysicsDataset
from f9columnar.ml.hdf5_parallel_writer import Hdf5WriterProcessor as MLHdf5WriterProcessor
from f9columnar.processors import (
    CheckpointPostprocessor,
    CheckpointProcessor,
    PostprocessorsGraph,
    Processor,
    ProcessorsGraph,
)
from f9columnar.processors_collection import ProcessorsCollection
from f9columnar.root_writer import RootWriterPostprocessor
from f9columnar.run import ColumnarEventLoop
from f9columnar.submit.act_handler import ActBatchHandler
from f9columnar.utils.regex_helpers import ParsedJobDatasetInfo, extract_dataset_from_job
from f9columnar.variations import StartVariations, VariationsProcessor

ANALYSIS_PROCESSORS = {
    "RunNumberProcessor": RunNumberProcessor,
    "SampleInfoProcessor": SampleInfoProcessor,
    "FinalEventWeight": FinalEventWeight,
    "JetScaleFactors": JetScaleFactors,
    "JetSelection": JetSelection,
    "PCFTbJetVeto": PCFTbJetVeto,
    "PCFTcJetVeto": PCFTcJetVeto,
    "DiLeptonCompleteTrigger": DiLeptonCompleteTrigger,
    "DiLeptonLooseTrigger": DiLeptonLooseTrigger,
    "DiTauTrigger": DiTauTrigger,
    "SingleElectronFakesTrigger": SingleElectronFakesTrigger,
    "SingleMuonFakesTrigger": SingleMuonFakesTrigger,
    "SingleLeptonTrigger": SingleLeptonTrigger,
    "LeptonTauTrigger": LeptonTauTrigger,
    "TriggerCascade": TriggerCascade,
    "BadMuonVeto": BadMuonVeto,
    "ElectronCrackVeto": ElectronCrackVeto,
    "ElectronScaleFactors": ElectronScaleFactors,
    "LeptonMultiplicity": LeptonMultiplicity,
    "LeptonSelection": LeptonSelection,
    "MuonScaleFactors": MuonScaleFactors,
    "TauScaleFactors": TauScaleFactors,
    "TauPassMuonOLR": TauPassMuonOLR,
    "ElectronType": ElectronType,
    "MuonType": MuonType,
    "TauType": TauType,
    "SelectRegion": SelectRegion,
    "TriggerEfficiency": TriggerEfficiency,
    "LeptonTruthMatching": LeptonTruthMatching,
    "StartVariations": StartVariations,
    "VariationsProcessor": VariationsProcessor,
    "CheckpointProcessor": CheckpointProcessor,
    "ArraysProcessor": ArraysProcessor,
    "RootWriterPostprocessor": RootWriterPostprocessor,
    "MLHdf5WriterProcessor": MLHdf5WriterProcessor,
}


@dataclass
class SubgraphData:
    processors: dict[str, Processor]
    name_map: dict[str, str]
    edges: list[tuple[str, str]]
    first_node: str
    last_node: str


class AnalysisBuilder:
    def __init__(self, config: dict[str, Any] | str | Path) -> None:
        """Build analysis processor graphs from YAML configuration.

        Parses a YAML config containing graph sections with processor definitions
        and connectivity, and assembles them into a unified `ProcessorsGraph`.

        Graph sections are identified by the presence of a `chain` or `connect` key:
          - **chain sections**: Define a linear processing pipeline. Processors listed
            in the `chain` list are connected sequentially.
          - **connect section**: Defines the top-level topology linking subgraphs and
            standalone processors. Supports fan-out, fan-in, and a `postprocessors` key.

        YAML keys are resolved to processor classes via the registry
        (`ANALYSIS_PROCESSORS` + user-added classes). Prefixed keys like
        `el_SelectRegion` are resolved by stripping the prefix and passing it
        as the `prefix` constructor kwarg (if accepted). Unresolved keys default
        to `CheckpointProcessor` (useful for connector / merge nodes).

        Parameters
        ----------
        config : dict or str or Path
            Analysis config as a dict, or path to a YAML file.

        """
        if isinstance(config, (str, Path)):
            config_path = str(config)
            with open(config_path) as f:
                raw_text = f.read()
            raw_text = resolve_yaml_inserts(raw_text, config_path)
            self._config: dict[str, Any] = yaml.safe_load(raw_text)
        else:
            self._config = dict(config)

        self._registry: dict[str, type] = dict(ANALYSIS_PROCESSORS)

    @property
    def registry(self) -> dict[str, type]:
        """Currently registered processor classes (read-only copy)."""
        return dict(self._registry)

    def add_processor(self, processor_cls: type[Processor]) -> AnalysisBuilder:
        """Register a user-defined processor class."""
        self._registry[processor_cls.__name__] = processor_cls
        return self

    def add_processors(self, *processor_classes: type[Processor]) -> AnalysisBuilder:
        """Register multiple user-defined processor classes."""
        for proc_cls in processor_classes:
            self.add_processor(proc_cls)
        return self

    def _resolve_class_and_prefix(self, yaml_key: str) -> tuple[type | None, str]:
        """Resolve a YAML key to `(processor_class, prefix)`.

        Tries an exact match first, then progressively strips underscore-separated prefixes.

        e.g. (simple case): `el_SelectRegion` -> prefix `el_`, class `SelectRegion`.

        Can return:
          - `(ProcessorClass, prefix)` if a match is found
          - `(None, "")` if no match is found (caller should handle fallback)
          - `(ProcessorClass, "")` if an exact match is found (no prefix)

        """
        if yaml_key in self._registry:
            return self._registry[yaml_key], ""

        parts = yaml_key.split("_")
        for i in range(1, len(parts)):
            candidate = "_".join(parts[i:])
            if candidate in self._registry:
                prefix = "_".join(parts[:i]) + "_"
                return self._registry[candidate], prefix

        return None, ""

    def _create_processor(self, yaml_key: str, kwargs: dict[str, Any], graph_suffix: str = "") -> Processor:
        """Create a single processor instance from its YAML key and kwargs.

        This method:
          - Extracts prefix from the key and passes it to the constructor
            (as `prefix` or `name` kwarg, depending on what the class accepts).
          - Appends `graph_suffix` to `processor.name` for cross-subgraph uniqueness if needed.
          - Falls back to `CheckpointProcessor` for unknown class names.

        Name/prefix handling:
          - If no prefix is extracted, the class is instantiated with the provided kwargs without modification.
          - If the class accepts a `prefix` kwarg, the extracted prefix is passed as-is.
          - If the class accepts a `name` kwarg, the extracted prefix is prepended to the default name.
          - If the class accepts a required `name` kwarg with no default, the extracted prefix is used as the name.

        """
        proc_cls, prefix = self._resolve_class_and_prefix(yaml_key)

        if proc_cls is None:
            logging.info(f"No registered class for '{yaml_key}' - creating CheckpointProcessor")
            return CheckpointProcessor(name=f"{yaml_key}{graph_suffix}")

        kwargs = dict(kwargs)

        if prefix:
            sig = inspect.signature(proc_cls.__init__)  # type: ignore[misc]
            params = sig.parameters

            if "prefix" in params:
                kwargs.setdefault("prefix", prefix)
            elif "name" in params:
                default = params["name"].default
                if default is not inspect.Parameter.empty:
                    # e.g. trigger classes with name="fakesSingleElectronTrigger"
                    kwargs.setdefault("name", f"{prefix}{default}")
                else:
                    # e.g. CheckpointProcessor(name: str)  – required, no default
                    kwargs.setdefault("name", yaml_key)

        proc = proc_cls(**kwargs)

        if graph_suffix:
            proc.name = f"{proc.name}{graph_suffix}"
            proc._graph_identifier = graph_suffix

        return proc

    def _parse_chain_section(
        self,
        graph_name: str,
        section: dict[str, Any],
        needs_suffix: bool = False,
    ) -> SubgraphData:
        """Parse a graph section that contains a `chain` key."""
        section = dict(section)
        chain: list[str] = section.pop("chain")

        if not chain:
            raise ValueError(f"Empty chain in graph section '{graph_name}'!")

        suffix = f"__{graph_name}" if needs_suffix else ""

        processors: dict[str, Processor] = {}
        name_map: dict[str, str] = {}

        for yaml_key in chain:
            proc_kwargs = section.get(yaml_key)
            if proc_kwargs is None:
                proc_kwargs = {}

            proc = self._create_processor(yaml_key, proc_kwargs, graph_suffix=suffix)

            processors[yaml_key] = proc
            name_map[yaml_key] = proc.name

        edges = [(name_map[chain[i]], name_map[chain[i + 1]]) for i in range(len(chain) - 1)]

        return SubgraphData(
            processors=processors,
            name_map=name_map,
            edges=edges,
            first_node=name_map[chain[0]],
            last_node=name_map[chain[-1]],
        )

    @staticmethod
    def _find_root_subgraphs(
        connect: dict[str, list[str]],
        subgraph_names: set[str],
    ) -> set[str]:
        """Return subgraphs that appear only as *sources* in `connect`."""
        all_targets: set[str] = set()
        for targets in connect.values():
            if isinstance(targets, list):
                all_targets.update(t for t in targets if t in subgraph_names)
        return subgraph_names - all_targets

    def _resolve_node(
        self,
        ref: str,
        subgraphs: dict[str, SubgraphData],
        standalone: dict[str, Processor],
        *,
        as_target: bool = False,
    ) -> str:
        """Resolve a `connect` reference to a concrete processor name.

        Subgraph references resolve to *last_node* (source) or *first_node*
        (target).  Standalone processor references resolve to their `processor.name`.

        """
        if ref in subgraphs:
            sg = subgraphs[ref]
            return sg.first_node if as_target else sg.last_node

        if ref in standalone:
            return standalone[ref].name

        raise ValueError(
            f"Unknown reference '{ref}' in connect section. "
            f"Known subgraphs: {sorted(subgraphs)}. "
            f"Known standalone processors: {sorted(standalone)}."
        )

    def _build_chains_only(self, chain_sections: dict[str, dict[str, Any]]) -> tuple[ProcessorsGraph, None]:
        """Build a single `ProcessorsGraph` when there is no `connect` section."""
        if len(chain_sections) == 1:
            name, section = next(iter(chain_sections.items()))
            sg = self._parse_chain_section(name, section, needs_suffix=False)

            graph = ProcessorsGraph()
            for proc in sg.processors.values():
                graph.add(proc)

            graph.connect(sg.edges)

            return graph, None

        raise ValueError(
            f"Found {len(chain_sections)} chain sections but no 'connect' section to define how they are linked."
        )

    def build(
        self, global_attributes: dict[str, Any] | None = None
    ) -> tuple[ProcessorsGraph, PostprocessorsGraph | None]:
        """Build the full analysis graph from the loaded config.

        Returns
        -------
        tuple[ProcessorsGraph, PostprocessorsGraph | None]
            The main processing graph and an optional postprocessors graph
            (present only when the config's `connect` section includes a
            `postprocessors` key).

        """
        # classify top-level config sections
        chain_sections: dict[str, dict[str, Any]] = {}
        connect_section_name: str | None = None
        connect_section_data: dict[str, Any] | None = None

        for key, value in self._config.items():
            if not isinstance(value, dict) or key in ALLOWED_CONFIG_KEYS:
                continue

            if "chain" in value:
                chain_sections[key] = value
            elif "connect" in value:
                if connect_section_name is not None:
                    raise ValueError("Config must contain at most one 'connect' section!")
                connect_section_name = key
                connect_section_data = value
            else:
                raise ValueError(f"Top-level section '{key}' must contain either a 'chain' or 'connect' key!")

        if not chain_sections and connect_section_data is None:
            raise ValueError("No graph sections (with 'chain' or 'connect') found in config!")

        # simple case: chain(s) only, no connect
        if connect_section_data is None:
            return self._build_chains_only(chain_sections)

        # full case: subgraphs + connect topology
        main_section = dict(connect_section_data)
        connect: dict[str, list[str]] = dict(main_section.pop("connect"))

        # hanlde unused graphs (not mentioned in connect)
        _connect_included = dict(connect)
        _connect_included.pop("postprocessors", None)

        connect_included: set[str] = set()
        for _key, _targets in _connect_included.items():
            connect_included.add(_key)
            connect_included.update(_targets)

        # identify root subgraphs (don't need name suffix)
        subgraph_names = set(chain_sections.keys())
        root_graphs = self._find_root_subgraphs(connect, subgraph_names)

        if len(root_graphs & connect_included) > 1:
            logging.warning(
                f"Multiple root subgraphs detected: {root_graphs}. Ensure their processor names don't conflict."
            )

        # resolve aliased references: connect targets like "l_2L_analysis_graph"
        # that don't match a chain section are treated as prefixed aliases of
        # the base chain section "2L_analysis_graph" (prefix = "l").
        alias_map: dict[str, str] = {}  # alias_name -> base_chain_section_name
        for name in connect_included:
            if name not in chain_sections:
                for base_name in chain_sections:
                    if name.endswith(f"_{base_name}"):
                        alias_map[name] = base_name
                        break

        # parse chain subgraphs (including aliased copies)
        subgraphs: dict[str, SubgraphData] = {}
        for name, section in chain_sections.items():
            if name not in connect_included:
                continue

            needs_suffix = name not in root_graphs
            subgraphs[name] = self._parse_chain_section(name, section, needs_suffix)

        for alias_name, base_name in alias_map.items():
            section = chain_sections[base_name]
            subgraphs[alias_name] = self._parse_chain_section(alias_name, section, needs_suffix=True)

        # create standalone processors from the main/connect section
        standalone: dict[str, Processor] = {}
        postprocessor_keys: set[str] = set(connect.get("postprocessors", []))

        for yaml_key, proc_kwargs in main_section.items():
            if proc_kwargs is None:
                proc_kwargs = {}
            standalone[yaml_key] = self._create_processor(yaml_key, proc_kwargs)

        # assemble the unified ProcessorsGraph
        unified_graph = ProcessorsGraph()

        for name, sg in subgraphs.items():
            if name not in connect_included:
                continue

            for proc in sg.processors.values():
                unified_graph.add(proc)

        for yaml_key, proc in standalone.items():
            if yaml_key not in postprocessor_keys:
                unified_graph.add(proc)

        # collect all edges
        all_edges: list[tuple[str, str]] = []

        for sg in subgraphs.values():
            all_edges.extend(sg.edges)

        for source, targets in connect.items():
            if source == "postprocessors":
                continue

            source_node = self._resolve_node(source, subgraphs, standalone)

            for target in targets:
                target_node = self._resolve_node(target, subgraphs, standalone, as_target=True)
                all_edges.append((source_node, target_node))

        unified_graph.connect(all_edges)

        # assemble the PostprocessorsGraph (if any)
        postprocessors_graph: PostprocessorsGraph | None = None
        if postprocessor_keys:
            postprocessors_graph = PostprocessorsGraph()
            post_input = CheckpointPostprocessor(name="postInput")
            postprocessors_graph.add(post_input)

            post_edges: list[tuple[str, str]] = []
            for key in connect["postprocessors"]:
                proc = standalone[key]
                postprocessors_graph.add(proc)
                post_edges.append(("postInput", proc.name))

            postprocessors_graph.connect(post_edges)

        unified_graph.global_attributes = global_attributes

        return unified_graph, postprocessors_graph


class PhysicsAnalysis:
    def __init__(self, config_file: str, xsec_path: str, code_dir: str | None = None) -> None:
        """High-level interface for running a columnar physics analysis.

        Orchestrates the full analysis workflow in three steps:
        `build()` -> `initialize()` -> `run()`. Each step can also be called
        individually for finer control (e.g. to inspect configs between steps).
        Depending on `analysis_config.submit.local_run`, execution is either
        done in-process via `ColumnarEventLoop` or submitted as batch jobs via
        `ActBatchHandler`.

        Parameters
        ----------
        config_file : str
            Path to the YAML analysis configuration file.
        xsec_path : str
            Path to the directory containing cross-section files.
        code_dir : str, optional
            Directory to package for batch job submission. If `None`, the
            parent directory of the top-level calling script is used. Provide
            this explicitly when the automatic detection is unreliable.

        Methods
        -------
        build(extra_processors=None) -> PhysicsAnalysis
            Parses the config file and builds the analysis configuration, samples config, xsec config,
            and processor graphs. Optionally accepts extra processor classes to register.
        initialize() -> PhysicsAnalysis
            Initializes the analysis by setting up the event loop for local runs or the aCT
            batch handler for batch runs.
        run() -> PhysicsAnalysis
            Executes the analysis using the initialized event loop or batch handler.

        Attributes
        ----------
        config_file : str
            Path to the YAML analysis configuration file.
        xsec_path : str
            Path to the cross-section directory.
        code_dir : str or None
            Explicit code directory for batch submission, or `None` to auto-detect.
        config_name : str
            Stem of the config filename, used as a prefix for output files.
        analysis_config : AnalysisConfig or None
            Populated by `build_analysis_config()`.
        samples_config : SamplesConfig or None
            Populated by `build_samples_config()`.
        xsec_config : XsecConfig or None
            Populated by `build_xsec_config()`.
        processors_graph : ProcessorsGraph or None
            Populated by `build_analysis_graph()`.
        postprocessors_graph : PostprocessorsGraph or None
            Populated by `build_analysis_graph()`; `None` when the config contains no postprocessors.
        event_loop : ColumnarEventLoop or None
            Set by `initialize()` for local runs.
        act_handler : ActBatchHandler or None
            Set by `initialize()` for batch runs.

        Raises
        ------
        ValueError
            If `config_file` does not exist or `xsec_path` does not exist.
        RuntimeError
            If `build()` is called more than once on the same instance.

        """
        if not os.path.isfile(config_file):
            raise ValueError(f"Config file '{config_file}' does not exist!")

        if not os.path.exists(xsec_path):
            raise ValueError(f"Xsec directory '{xsec_path}' does not exist!")

        self.config_file = config_file
        self.xsec_path = xsec_path
        self.code_dir = code_dir

        self.config_name = os.path.basename(config_file).rsplit(".", 1)[0]

        self.analysis_config: AnalysisConfig | None = None
        self.samples_config: SamplesConfig | None = None
        self.xsec_config: XsecConfig | None = None

        self.processors_graph: ProcessorsGraph | None = None
        self.postprocessors_graph: PostprocessorsGraph | None = None

        self.event_loop: ColumnarEventLoop | None = None
        self.act_handler: ActBatchHandler | None = None

        self._mc_only: bool = False
        self._built: bool = False

    def build_analysis_config(self) -> AnalysisConfig:
        logging.info(f"Building analysis config from '{self.config_file}'.")

        analysis_config_builder = AnalysisConfigBuilder(self.config_file)
        self.analysis_config = analysis_config_builder.build()
        return self.analysis_config

    def build_samples_config(self) -> SamplesConfig:
        if self.analysis_config is None:
            raise ValueError("Analysis config must be built before building samples config!")

        logging.info("Building samples config.")

        rebuild_config = self.analysis_config.submit.force_rucio_db_refresh

        sample_builder = SamplesConfigBuilder(
            data_path=self.analysis_config.common.data_path,
            metadata_path=self.analysis_config.common.metadata_path,
            df_id="hists",
            force=rebuild_config,
        )
        sample_builder.build_default_config(force=rebuild_config)

        self.samples_config = sample_builder.build(
            f"{self.config_name}_samples_config",
            include_years=self.analysis_config.samples.years,
            include_mc_names=self.analysis_config.samples.datasets,
            include_campaigns=self.analysis_config.samples.campaigns,
            include_dsids=self.analysis_config.samples.dsids,
            regroup_by_dsid=self.analysis_config.samples.regroup_by_dsid,
        )
        return self.samples_config

    def build_xsec_config(self) -> XsecConfig:
        logging.info(f"Building xsec config from '{self.xsec_path}'.")

        xsec_builder = XsecBuilder(self.xsec_path)
        self.xsec_config = xsec_builder.build()
        return self.xsec_config

    def build_analysis_graph(
        self, extra_processors: list[Type[Processor]] | None = None
    ) -> tuple[ProcessorsGraph, PostprocessorsGraph | None]:
        logging.info("Building analysis graph.")

        analysis_builder = AnalysisBuilder(self.config_file)

        if extra_processors is not None:
            analysis_builder.add_processors(*extra_processors)

        self.processors_graph, self.postprocessors_graph = analysis_builder.build()
        return self.processors_graph, self.postprocessors_graph

    def build(self, extra_processors: list[Type[Processor]] | None = None) -> PhysicsAnalysis:
        if self._built:
            raise RuntimeError("build() has already been called!")

        self.build_analysis_config()
        self.build_samples_config()
        self.build_xsec_config()
        self.processors_graph, self.postprocessors_graph = self.build_analysis_graph(extra_processors)

        self._built = True
        return self

    def initialize(self) -> PhysicsAnalysis:
        if self.analysis_config is None:
            raise ValueError("Analysis config must be built before initialization!")

        if self.samples_config is None:
            raise ValueError("Samples config must be built before initialization!")

        if self.xsec_config is None:
            raise ValueError("Xsec config must be built before initialization!")

        if self.processors_graph is None:
            raise ValueError("Processors graph must be built before initialization!")

        logging.info("Initializing analysis.")

        self.processors_graph.draw(f"{self.analysis_config.common.results_path}/{self.config_name}_graph.svg")

        analysis_collection = ProcessorsCollection(
            "analysisCollection",
            nominal_only=self.analysis_config.systematics.nominal_only,
            filter_out_variations=self.analysis_config.systematics.filter_variations,
        )

        for proc in self.processors_graph.processors.values():
            analysis_collection += proc

        dataloader_kwargs = self.analysis_config.dataloader.to_dict()
        dataloader_kwargs["filter_name"] = analysis_collection.get_branch_name_filter()

        dataset_builder = NtupleDatasetBuilder(
            samples_config=self.samples_config,
            xsec_config=self.xsec_config,
            data_path=self.analysis_config.common.data_path,
            metadata_path=self.analysis_config.common.metadata_path,
            ntuple_location=self.analysis_config.submit.ntuple_location,
            max_root_files=self.analysis_config.submit.max_root_files,
            events_per_job=self.analysis_config.submit.events_per_job,
        )
        dataset_builder.build(dataloader_kwargs)

        if self.analysis_config.submit.local_run:
            mc_ntuple_datasets, data_ntuple_datasets = dataset_builder.init(self.processors_graph)

            self.event_loop = ColumnarEventLoop(
                mc_datasets=mc_ntuple_datasets if len(mc_ntuple_datasets) > 0 else None,
                data_datasets=data_ntuple_datasets if len(data_ntuple_datasets) > 0 else None,
                postprocessors_graph=self.postprocessors_graph,
                fit_postprocessors=True if self.postprocessors_graph is not None else False,
                cut_flow=self.analysis_config.common.cut_flow,
                disable_rich=self.analysis_config.common.disable_progress_bar,
                save_path=os.path.join(self.analysis_config.common.results_path, "local"),
            )
            self._mc_only = True if len(data_ntuple_datasets) == 0 and len(mc_ntuple_datasets) > 0 else False
        else:
            if self.code_dir is None:
                _start = Path(inspect.stack()[-1].filename).resolve().parent
                _current = _start
                while _current != _current.parent:
                    if (_current / "F9Columnar").is_dir():
                        break
                    _current = _current.parent
                else:
                    raise RuntimeError(
                        f"Could not find a directory containing 'F9Columnar' when walking up from {_start}. "
                        "Pass code_dir explicitly to PhysicsAnalysis."
                    )
                code_dir = str(_current)
            else:
                code_dir = self.code_dir

            self.act_handler = ActBatchHandler(
                submit_dir=self.analysis_config.submit.submit_dir,
                code_dir=code_dir,
                dataset_builder=dataset_builder,
                processors=self.processors_graph,
                dcache_user=self.analysis_config.submit.act_config.dcache_user,
                job_name=self.analysis_config.submit.job_name,
                postprocessors=self.postprocessors_graph,
                cut_flow=self.analysis_config.common.cut_flow,
                job_spec=self.analysis_config.submit.act_config.job_spec,
            )

        return self

    def merge(self, other: PhysicsAnalysis, merge_node: str, self_suffix: str, other_suffix: str) -> PhysicsAnalysis:
        """Merge another PhysicsAnalysis's processor graph at a given node.

        Both analyses must have been built before calling this method.

        Parameters
        ----------
        other : PhysicsAnalysis
            The analysis whose processor graph will be appended.
        merge_node : str
            Node in *self*'s graph after which *other*'s graph is attached.
            This should be the **original** node name (before prefixing),
            `self_suffix` is appended automatically.
        self_suffix : str
            Suffix appended to every node name in *self*'s graph.
        other_suffix : str
            Suffix appended to every node name in *other*'s graph.

        Returns
        -------
        PhysicsAnalysis
            A new instance with the merged `processors_graph`.

        Raises
        ------
        ValueError
            If either analysis has not been built.

        """
        if self.processors_graph is None:
            raise ValueError("This analysis must be built before merging!")
        if other.processors_graph is None:
            raise ValueError("The other analysis must be built before merging!")

        self_graph = self.processors_graph.change_identifier(self_suffix)
        other_graph = other.processors_graph.change_identifier(other_suffix)

        prefixed_merge_node = f"{merge_node}{self_suffix}"
        merged_graph = self_graph.extend(other_graph, prefixed_merge_node)

        merged = copy.copy(self)
        merged.processors_graph = merged_graph
        merged.event_loop = None
        merged.act_handler = None

        return merged

    def run(self) -> PhysicsAnalysis:
        if self.event_loop is not None:
            self.event_loop.run(mc_only=self._mc_only)
        elif self.act_handler is not None:
            self.act_handler.prepare()
        else:
            raise ValueError("Analysis must be initialized before running!")

        return self


class PreselectionPhysicsAnalysis:
    def __init__(
        self,
        config_file: str,
        local_job_name: str = "preselection",
        save_subdir: str | None = None,
    ) -> None:
        """High-level interface for running a columnar physics analysis on local pre-selected ntuples.

        Similar to `PhysicsAnalysis` but bypasses RUCIO/grid infrastructure and reads ROOT files
        directly from a local directory. Files are grouped by dataset and campaign using filename
        conventions and fed into the same `ColumnarEventLoop` used for normal local runs.

        The workflow is in three steps: `build()` -> `initialize()` -> `run()`.

        Parameters
        ----------
        config_file : str
            Path to the YAML analysis configuration file.
        local_job_name : str, optional
            Label passed to `ColumnarEventLoop` as `local_job_name`.
        save_subdir : str or None, optional
            Subdirectory under `results_path` where outputs are written.
            Defaults to `local_job_name` when `None`.

        Attributes
        ----------
        analysis_config : AnalysisConfig or None
            Populated by `build_analysis_config()`.
        processors_graph : ProcessorsGraph or None
            Populated by `build_analysis_graph()`.
        postprocessors_graph : PostprocessorsGraph or None
            Populated by `build_analysis_graph()`.
        event_loop : ColumnarEventLoop or None
            Set by `initialize()`.

        """
        if not os.path.isfile(config_file):
            raise ValueError(f"Config file '{config_file}' does not exist!")

        self.config_file = config_file
        self.config_name = os.path.basename(config_file).rsplit(".", 1)[0]
        self.local_job_name = local_job_name
        self.save_subdir = save_subdir if save_subdir is not None else local_job_name

        self.analysis_config: AnalysisConfig | None = None
        self.processors_graph: ProcessorsGraph | None = None
        self.postprocessors_graph: PostprocessorsGraph | None = None
        self.event_loop: ColumnarEventLoop | None = None

        self._built: bool = False

    @staticmethod
    def _make_group_files(file_list: list[str]) -> dict[ParsedJobDatasetInfo, list[str]]:
        groups: dict[ParsedJobDatasetInfo, list[str]] = {}

        for f in file_list:
            info = extract_dataset_from_job(f)
            if info:
                if info not in groups:
                    groups[info] = []

                groups[info].append(f)
            else:
                raise RuntimeError(f"Could not extract dataset info from file: {f}.")

        return groups

    def _setup_local_inputs(self, ntuple_location: str, n_debug: int | None = None) -> tuple[list, list]:
        """Discover and classify ROOT files from *ntuple_location* into MC / data datasets."""

        logging.info(f"Setting up local inputs from: {ntuple_location}")

        root_files = glob.glob(os.path.join(ntuple_location, "*.root"))

        if len(root_files) == 0:
            raise RuntimeError(f"No ROOT files found in ntuple location: {ntuple_location}!")

        grouped_files = self._make_group_files(root_files)

        mc_datasets: list[RootPhysicsDataset] = []
        data_datasets: list[RootPhysicsDataset] = []

        if self.analysis_config is None:
            raise ValueError("Analysis config must be built before setting up local inputs!")

        valid_years = set(self.analysis_config.samples.years)
        valid_campaigns = set(self.analysis_config.samples.campaigns)

        for info, files in grouped_files.items():
            if info.is_data:
                year, campaign = info.year, None
            else:
                year, campaign = info.year, info.campaign

            if info.is_data and year not in valid_years:
                logging.warning(f"Skipping data dataset '{info.dataset}' with year {year} not in config.")
                continue

            if not info.is_data and campaign not in valid_campaigns:
                logging.warning(f"Skipping MC dataset '{info.dataset}' with campaign '{campaign}' not in config.")
                continue

            if year in {15, 16, 1516, 17, 18}:
                run_name = 2
            elif year in {22, 23, 24}:
                run_name = 3
            else:
                raise RuntimeError(f"Unrecognized year '{year}' extracted from dataset '{info.dataset}'.")

            dataset = RootPhysicsDataset(
                name=info.name,
                root_files=files,
                is_data=info.is_data,
                extra_desc_dct={
                    "year": year,
                    "campaign": campaign,
                    "run_name": run_name,
                    "dsid": 999999,
                    "user": "local",
                    "sample_weight": 1.0,
                    "is_ntuples": True,
                },
            )

            if info.is_data:
                data_datasets.append(dataset)
            else:
                mc_datasets.append(dataset)

        if n_debug is not None:
            return mc_datasets[:n_debug], data_datasets[:n_debug]

        return mc_datasets, data_datasets

    def build_analysis_config(self) -> AnalysisConfig:
        logging.info(f"Building analysis config from '{self.config_file}'.")

        self.analysis_config = AnalysisConfigBuilder(self.config_file).build()
        return self.analysis_config

    def build_analysis_graph(
        self, extra_processors: list[Type[Processor]] | None = None
    ) -> tuple[ProcessorsGraph, PostprocessorsGraph | None]:
        logging.info("Building analysis graph.")

        analysis_builder = AnalysisBuilder(self.config_file)
        if extra_processors is not None:
            analysis_builder.add_processors(*extra_processors)

        self.processors_graph, self.postprocessors_graph = analysis_builder.build()

        return self.processors_graph, self.postprocessors_graph

    def build(self, extra_processors: list[Type[Processor]] | None = None) -> PreselectionPhysicsAnalysis:
        if self._built:
            raise RuntimeError("build() has already been called!")

        self.build_analysis_config()
        self.processors_graph, self.postprocessors_graph = self.build_analysis_graph(extra_processors)

        self._built = True
        return self

    def initialize(self, n_debug: int | None = None) -> PreselectionPhysicsAnalysis:
        if self.analysis_config is None:
            raise ValueError("Analysis config must be built before initialization!")

        if self.processors_graph is None:
            raise ValueError("Processors graph must be built before initialization!")

        ntuple_location = self.analysis_config.submit.ntuple_location
        if ntuple_location is None:
            ntuple_location = self.analysis_config.user_config.get("ntuple_location", None)

        if ntuple_location is None:
            raise ValueError("Ntuple location not specified! Set it in submit config or user_config.")

        mc_datasets, data_datasets = self._setup_local_inputs(ntuple_location, n_debug=n_debug)

        self.processors_graph.draw(f"{self.analysis_config.common.results_path}/{self.config_name}_graph.svg")

        analysis_collection = ProcessorsCollection(
            "preselectionAnalysisCollection",
            nominal_only=self.analysis_config.systematics.nominal_only,
            filter_out_variations=self.analysis_config.systematics.filter_variations,
        )
        for proc in self.processors_graph.processors.values():
            analysis_collection += proc

        dataloader_kwargs = self.analysis_config.dataloader.to_dict()
        dataloader_kwargs["num_workers"] = self.analysis_config.dataloader.num_workers
        dataloader_kwargs["filter_name"] = analysis_collection.get_branch_name_filter()

        for ds in mc_datasets + data_datasets:
            ds.setup_dataloader(**dataloader_kwargs)
            ds.init_dataloader(self.processors_graph)

        save_path = os.path.join(self.analysis_config.common.results_path, self.save_subdir)

        self.event_loop = ColumnarEventLoop(
            mc_datasets=mc_datasets if mc_datasets else None,
            data_datasets=data_datasets if data_datasets else None,
            postprocessors_graph=self.postprocessors_graph,
            cut_flow=self.analysis_config.common.cut_flow,
            no_plot_cut_flow=True,
            local_job_name=self.local_job_name,
            save_path=save_path,
        )
        return self

    def run(self) -> PreselectionPhysicsAnalysis:
        if self.event_loop is None:
            raise ValueError("Analysis must be initialized before running!")

        self.event_loop.run()
        return self
