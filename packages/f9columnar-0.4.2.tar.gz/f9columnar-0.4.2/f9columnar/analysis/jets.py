import awkward as ak
import numpy as np

from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor
from f9columnar.processors_collection import decorate_branches
from f9columnar.variations import vary


@decorate_branches("jet_eta")
class JetSelection(Processor):
    jet_selected: str
    jet_pt: str
    jet_eta: str

    def __init__(
        self,
        sel_jet: bool = True,
        pt_cut: float | None = None,
        n_jet: int | tuple[int, int | str] | None = None,
        forward_jets: bool = False,
        sel_tau: bool = False,
        anti_tau: bool = False,
        prefix: str = "",
    ) -> None:
        super().__init__(name=f"{prefix}jetSelection")
        self.sel_jet = sel_jet
        self.anti_tau = anti_tau
        self.pt_cut = pt_cut
        self.n_jet = self._normalize_multiplicity(n_jet) if n_jet is not None else None
        self.forward_jets = forward_jets

        if self.pt_cut is not None:
            self.pt_cut = self.pt_cut * 1000.0

        if not self.sel_jet and self.n_jet is None and self.pt_cut is None:
            raise ValueError("At least one of sel_jet, pt_cut, or n_jet must be specified!")

        self._setup_branches(sel_tau, anti_tau=anti_tau)

    @staticmethod
    def _normalize_multiplicity(n: int | tuple[int, int | str]) -> tuple[int, int | float]:
        """Convert multiplicity requirement to (min, max) tuple.

        Handles:
          - int -> (int, int)
          - tuple[int, int | str] -> (int, float) where str can be "inf"

        """
        if isinstance(n, int):
            return (n, n)

        min_val = n[0]
        if isinstance(n, tuple):
            if isinstance(n[1], str):
                if n[1].lower() == "inf":
                    max_val = float("inf")
                else:
                    raise ValueError(f"Invalid upper bound string: '{n[1]}'. Only 'inf' is allowed.")
            else:
                max_val = n[1]

            return (min_val, max_val)
        else:
            raise ValueError(f"Invalid multiplicity type: {type(n)}")

    def _setup_branches(self, sel_tau: bool, anti_tau: bool = False) -> None:
        if self.pt_cut is not None:
            self.attach_branch(("jet_pt_NOSYS", "jet_pt"), is_varied=True)

        if self.sel_jet:
            if sel_tau:
                if anti_tau:
                    jet_branch = "jet_selected_taus_anti_NOSYS"
                else:
                    jet_branch = "jet_selected_taus_NOSYS"
            else:
                jet_branch = "jet_selected_NOSYS"

            self.attach_branch((jet_branch, "jet_selected"), is_varied=True)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if not self.forward_jets:
            central_mask = np.abs(arrays["jet", self.jet_eta]) < 2.5
            arrays["jet"] = arrays["jet"][central_mask]
        else:
            valid_jets = np.abs(arrays["jet", self.jet_eta]) <= 4.5
            arrays["jet"] = arrays["jet"][valid_jets]

        if self.sel_jet:
            selected = arrays["jet"][self.jet_selected] == 1
            arrays["jet"] = arrays["jet"][selected]

        if self.pt_cut is not None:
            pt_mask = arrays["jet", self.jet_pt] >= self.pt_cut
            arrays["jet"] = arrays["jet"][pt_mask]

        if self.n_jet is not None:
            if self.sel_jet:
                n_jets = ak.num(arrays["jet"][self.jet_selected])
            else:
                n_jets = ak.num(arrays["jet"][self.jet_pt])

            min_jets, max_jets = self.n_jet
            njet_mask = (n_jets >= min_jets) & (n_jets <= max_jets)
            arrays = arrays[None, njet_mask]

        return {"arrays": arrays}


@decorate_branches(("jet_FTag_GN2v01_PCFT_quantile", "quantile"))
class PCFTbJetVeto(Processor):
    quantile: str

    def __init__(self, veto: bool = True, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}PCFTbJetVeto")
        self.veto = veto

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        has_bjet = ak.any(arrays["jet", self.quantile] >= 4, axis=-1)

        if self.veto:
            mask = ~has_bjet
        else:
            mask = has_bjet

        arrays = arrays[None, mask]

        return {"arrays": arrays}


@decorate_branches(("jet_FTag_GN2v01_PCFT_quantile", "quantile"))
class PCFTcJetVeto(Processor):
    quantile: str

    def __init__(self, veto: bool = True, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}PCFTcJetVeto")
        self.veto = veto

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        has_cjet = ak.any(
            (arrays["jet", self.quantile] >= 1) & (arrays["jet", self.quantile] <= 3),
            axis=-1,
        )

        if self.veto:
            mask = ~has_cjet
        else:
            mask = has_cjet

        arrays = arrays[None, mask]

        return {"arrays": arrays}


@decorate_branches(
    ("jet_effSF_FTag_GN2v01_PCFT_NOSYS", "jet_effSF_FTag"),
    ("weight_effSF_FTag_GN2v01_PCFT_NOSYS", "weight_effSF_FTag"),
    ("weight_effSF_JVT_NOSYS", "weight_effSF_JVT"),
    ("weight_effSF_fJVT_NOSYS", "weight_effSF_fJVT"),
)
class JetScaleFactors(Processor):
    jet_effSF_FTag: str
    weight_effSF_FTag: str
    weight_effSF_JVT: str
    weight_effSF_fJVT: str

    def __init__(self, enable_fjvt: bool = False, save_weights: bool = False, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}jetScaleFactors")
        self.enable_fjvt = enable_fjvt
        self.save_weights = save_weights

        if self.save_weights:
            self.attach_branch(("jet_total_weight_NOSYS", "jet_total_weight"), is_varied=True, is_created=True)

    def post_init(self):
        if not self.enable_fjvt:
            self.remove_branch(self.weight_effSF_fJVT)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.is_data:
            return {"arrays": arrays}

        weight_correction: ak.Array

        if self.weight_effSF_FTag in arrays.fields:
            weight_correction = arrays[self.weight_effSF_FTag]
        elif self.jet_effSF_FTag in arrays.fields:
            jet_sf = arrays["jet", self.jet_effSF_FTag]
            weight_correction = ak.prod(jet_sf, axis=-1)
        else:
            raise RuntimeError(f"Neither {self.weight_effSF_FTag} nor {self.jet_effSF_FTag} found in arrays.")

        weight_correction = weight_correction * arrays[self.weight_effSF_JVT]

        if self.enable_fjvt:
            weight_correction = weight_correction * arrays[self.weight_effSF_fJVT]

        arrays["total_weight"] = arrays["total_weight"] * weight_correction

        if self.save_weights:
            arrays.add_varied_array(
                weight_correction,
                "jet_total_weight",
                variation="nominal" if self.current_variation is None else self.current_variation,
                variation_map=self.variation_map,
            )

        return {"arrays": arrays}
