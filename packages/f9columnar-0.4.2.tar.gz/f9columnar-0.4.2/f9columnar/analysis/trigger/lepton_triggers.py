from f9columnar.analysis.trigger.triggers import Trigger, TriggerProcessor
from f9columnar.arrays import GroupArrays
from f9columnar.variations import vary


class DiLeptonLooseTrigger(TriggerProcessor):
    triggers: list[Trigger] = [
        # 2015
        Trigger(
            "HLT_2e12_lhloose_L12EM10VH",
            year=15,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu18_mu8noL1",
            year=15,
            leg1_eff="HLT_mu18",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu10",
            year=15,
            leg1_eff="HLT_mu10",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14",
            year=15,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        # 2016
        Trigger(
            "HLT_2e17_lhvloose_nod0",
            year=16,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=16,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=16,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=16,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        # 2017 - before prescale
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=171,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_nod0_L12EM15VHI",
            year=171,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e17_lhvloose_nod0_L1EM15VHI",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=171,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=171,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=171,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        # 2017 - during prescale
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=170,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=170,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=170,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=170,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        # 2017 - after prescale
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=172,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_nod0_L12EM15VHI",
            year=172,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e17_lhvloose_nod0_L1EM15VHI",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=172,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=172,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=172,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        # 2018
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=18,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_nod0_L12EM15VHI",
            year=18,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e17_lhvloose_nod0_L1EM15VHI",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=18,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=18,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=18,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        # 2022 (Run3)
        Trigger(
            "HLT_2e24_lhvloose_L12EM20VH",
            year=22,
            leg1_eff="2022_e24_lhvloose",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_L12EM15VHI",
            year=22,
            leg1_eff="2022_e17_lhvloose",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1_L1MU14FCH",
            year=22,
            leg1_eff="HLT_mu22_L1MU14FCH",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14_L12MU8F",
            year=22,
            leg1_eff="HLT_mu14_L1MU8F",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14_L1EM15VH_MU8F",
            year=22,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14_L1MU8F",
            leg1_use_eff_sf=True,
        ),
        # 2023 (Run3)
        Trigger(
            "HLT_2e24_lhvloose_L12eEM24L",
            year=23,
            leg1_eff="2023_e24_lhvloose_L1eEM24L",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_L12eEM18M",
            year=23,
            leg1_eff="2023_e17_lhvloose_L1eEM18M",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1_L1MU14FCH",
            year=23,
            leg1_eff="HLT_mu22_L1MU14FCH",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14_L12MU8F",
            year=23,
            leg1_eff="HLT_mu14_L1MU8F",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14_L1eEM18L_MU8F",
            year=23,
            leg1_eff="2023_e17_lhloose_L1eEM18L",
            leg2_eff="HLT_mu14_L1MU8F",
            leg1_use_eff_sf=True,
        ),
        # 2024 (Run3) - same as 2023
        Trigger(
            "HLT_2e24_lhvloose_L12eEM24L",
            year=24,
            leg1_eff="2023_e24_lhvloose_L1eEM24L",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_L12eEM18M",
            year=24,
            leg1_eff="2023_e17_lhvloose_L1eEM18M",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1_L1MU14FCH",
            year=24,
            leg1_eff="HLT_mu22_L1MU14FCH",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14_L12MU8F",
            year=24,
            leg1_eff="HLT_mu14_L1MU8F",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14_L1eEM18L_MU8F",
            year=24,
            leg1_eff="2023_e17_lhloose_L1eEM18L",
            leg2_eff="HLT_mu14_L1MU8F",
            leg1_use_eff_sf=True,
        ),
    ]

    def __init__(
        self,
        name: str = "diLeptonTrigger",
        el_id: str | None = None,
        el_iso: str | None = None,
        mu_reco: str | None = None,
        use_sf: bool = True,
        trigger_match: bool = True,
        prescale: bool = False,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)
        self.set_working_points(el_id=el_id, el_iso=el_iso, mu_reco=mu_reco)
        self.set_trigger_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}


class DiLeptonCompleteTrigger(TriggerProcessor):
    triggers: list[Trigger] = [
        # 2015
        Trigger(
            "HLT_2e12_lhloose_L12EM10VH",
            year=15,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu18_mu8noL1",
            year=15,
            leg1_eff="HLT_mu18",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu10",
            year=15,
            leg1_eff="HLT_mu10",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14",
            year=15,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_mu24",
            year=15,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24",
            leg1_use_eff_sf=True,
        ),
        # 2016
        Trigger(
            "HLT_2e17_lhvloose_nod0",
            year=16,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=16,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=16,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=16,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_nod0_mu24",
            year=16,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24",
            leg1_use_eff_sf=True,
        ),
        # 2017 - before prescale
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=171,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_nod0_L12EM15VHI",
            year=171,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e17_lhvloose_nod0_L1EM15VHI",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=171,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=171,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=171,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_nod0_mu24",
            year=171,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24",
            leg1_use_eff_sf=True,
        ),
        # 2017 - during prescale
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=170,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=170,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=170,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=170,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_nod0_mu24",
            year=170,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24",
            leg1_use_eff_sf=True,
        ),
        # 2017 - after prescale
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=172,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_nod0_L12EM15VHI",
            year=172,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e17_lhvloose_nod0_L1EM15VHI",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=172,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=172,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=172,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_nod0_mu24",
            year=172,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24",
            leg1_use_eff_sf=True,
        ),
        # 2018
        Trigger(
            "HLT_2e24_lhvloose_nod0",
            year=18,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e24_lhvloose_nod0_L1EM20VH",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_nod0_L12EM15VHI",
            year=18,
            leg1_eff="DI_E_2015_e12_lhloose_L1EM10VH_2016_e17_lhvloose_nod0_2017_2018_e17_lhvloose_nod0_L1EM15VHI",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1",
            year=18,
            leg1_eff="HLT_mu22",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14",
            year=18,
            leg1_eff="HLT_mu14",
        ),
        Trigger(
            "HLT_e17_lhloose_nod0_mu14",
            year=18,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_nod0_mu24",
            year=18,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24",
            leg1_use_eff_sf=True,
        ),
        # 2022 (Run3)
        Trigger(
            "HLT_2e24_lhvloose_L12EM20VH",
            year=22,
            leg1_eff="2022_e24_lhvloose",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_L12EM15VHI",
            year=22,
            leg1_eff="2022_e17_lhvloose",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1_L1MU14FCH",
            year=22,
            leg1_eff="HLT_mu22_L1MU14FCH",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14_L12MU8F",
            year=22,
            leg1_eff="HLT_mu14_L1MU8F",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14_L1EM15VH_MU8F",
            year=22,
            leg1_eff="MULTI_L_2015_e17_lhloose_2016_2018_e17_lhloose_nod0",
            leg2_eff="HLT_mu14_L1MU8F",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_mu24_L1MU14FCH",
            year=22,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24_L1MU14FCH",
            leg1_use_eff_sf=True,
        ),
        # 2023 (Run3)
        Trigger(
            "HLT_2e24_lhvloose_L12eEM24L",
            year=23,
            leg1_eff="2023_e24_lhvloose_L1eEM24L",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_L12eEM18M",
            year=23,
            leg1_eff="2023_e17_lhvloose_L1eEM18M",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1_L1MU14FCH",
            year=23,
            leg1_eff="HLT_mu22_L1MU14FCH",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14_L12MU8F",
            year=23,
            leg1_eff="HLT_mu14_L1MU8F",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14_L1eEM18L_MU8F",
            year=23,
            leg1_eff="2023_e17_lhloose_L1eEM18L",
            leg2_eff="HLT_mu14_L1MU8F",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_L1eEM5_mu24_L1MU14FCH",
            year=23,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24_L1MU14FCH",
            leg1_use_eff_sf=True,
        ),
        # 2024 (Run3) - same as 2023
        Trigger(
            "HLT_2e24_lhvloose_L12eEM24L",
            year=24,
            leg1_eff="2023_e24_lhvloose_L1eEM24L",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_2e17_lhvloose_L12eEM18M",
            year=24,
            leg1_eff="2023_e17_lhvloose_L1eEM18M",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu22_mu8noL1_L1MU14FCH",
            year=24,
            leg1_eff="HLT_mu22_L1MU14FCH",
            leg2_eff="HLT_mu8noL1",
        ),
        Trigger(
            "HLT_2mu14_L12MU8F",
            year=24,
            leg1_eff="HLT_mu14_L1MU8F",
        ),
        Trigger(
            "HLT_e17_lhloose_mu14_L1eEM18L_MU8F",
            year=24,
            leg1_eff="2023_e17_lhloose_L1eEM18L",
            leg2_eff="HLT_mu14_L1MU8F",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e7_lhmedium_L1eEM5_mu24_L1MU14FCH",
            year=24,
            leg1_eff="MULTI_L_2015_e7_lhmedium_2016_2018_e7_lhmedium_nod0",
            leg2_eff="HLT_mu24_L1MU14FCH",
            leg1_use_eff_sf=True,
        ),
    ]

    def __init__(
        self,
        name: str = "diLeptonCompleteTrigger",
        el_id: str | None = None,
        el_iso: str | None = None,
        mu_reco: str | None = None,
        use_sf: bool = True,
        trigger_match: bool = True,
        prescale: bool = False,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)
        self.set_working_points(el_id=el_id, el_iso=el_iso, mu_reco=mu_reco)
        self.set_trigger_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}


class SingleElectronFakesTrigger(TriggerProcessor):
    triggers = [
        # 2015
        Trigger("HLT_e5_lhvloose", year=15, pt_low="ptBaselineLow", pt_high="pt10", prescale=True),
        Trigger("HLT_e10_lhvloose_L1EM7", year=15, pt_low="pt10", pt_high="pt12", prescale=True),
        Trigger("HLT_e12_lhvloose_L1EM10VH", year=15, pt_low="pt12", pt_high="pt15", prescale=True),
        Trigger("HLT_e15_lhvloose_L1EM13VH", year=15, pt_low="pt15", pt_high="pt17", prescale=True),
        Trigger("HLT_e17_lhvloose", year=15, pt_low="pt17", pt_high="pt20", prescale=True),
        Trigger("HLT_e20_lhvloose", year=15, pt_low="pt20", pt_high="pt26", prescale=True),
        Trigger("HLT_e26_lhvloose_nod0_L1EM20VH", year=15, pt_low="pt26", pt_high="pt60", prescale=True),
        Trigger("HLT_e60_lhvloose_nod0", year=15, pt_low="pt60", pt_high="ptUnprescaledEl", prescale=True),
        Trigger("HLT_e200_etcut", year=15, pt_low="ptUnprescaledEl", pt_high="ptMax", prescale=True),
        # 2016
        Trigger("HLT_e5_lhvloose_nod0", year=16, pt_low="ptBaselineLow", pt_high="pt12", prescale=True),
        Trigger("HLT_e12_lhvloose_nod0_L1EM10VH", year=16, pt_low="pt12", pt_high="pt17", prescale=True),
        Trigger("HLT_e17_lhvloose_nod0", year=16, pt_low="pt17", pt_high="pt20", prescale=True),
        Trigger("HLT_e20_lhvloose_nod0", year=16, pt_low="pt20", pt_high="pt24", prescale=True),
        Trigger("HLT_e24_lhvloose_nod0_L1EM18VH", year=16, pt_low="pt24", pt_high="pt26", prescale=True),
        Trigger("HLT_e26_lhvloose_nod0_L1EM20VH", year=16, pt_low="pt26", pt_high="pt60", prescale=True),
        Trigger("HLT_e60_lhvloose_nod0", year=16, pt_low="pt60", pt_high="pt120", prescale=True),
        Trigger("HLT_e120_lhvloose_nod0", year=16, pt_low="pt120", pt_high="ptUnprescaledEl", prescale=True),
        Trigger("HLT_e300_etcut", year=16, pt_low="ptUnprescaledEl", pt_high="ptMax", prescale=True),
        # 2017
        Trigger("HLT_e5_lhvloose_nod0", year=17, pt_low="ptBaselineLow", pt_high="pt12", prescale=True),
        Trigger("HLT_e12_lhvloose_nod0_L1EM10VH", year=17, pt_low="pt12", pt_high="pt17", prescale=True),
        Trigger("HLT_e17_lhvloose_nod0", year=17, pt_low="pt17", pt_high="pt20", prescale=True),
        Trigger("HLT_e20_lhvloose_nod0", year=17, pt_low="pt20", pt_high="pt28", prescale=True),
        Trigger("HLT_e28_lhvloose_nod0_L1EM20VH", year=17, pt_low="pt28", pt_high="pt60", prescale=True),
        Trigger("HLT_e60_lhvloose_nod0", year=17, pt_low="pt60", pt_high="pt140", prescale=True),
        Trigger("HLT_e140_lhvloose_nod0", year=17, pt_low="pt140", pt_high="pt160", prescale=True),
        Trigger("HLT_e160_lhvloose_nod0", year=17, pt_low="pt160", pt_high="ptUnprescaledEl", prescale=True),
        Trigger("HLT_e300_etcut", year=17, pt_low="ptUnprescaledEl", pt_high="ptMax", prescale=True),
        # 2018
        Trigger("HLT_e5_lhvloose_nod0", year=18, pt_low="ptBaselineLow", pt_high="pt10", prescale=True),
        Trigger("HLT_e10_lhvloose_nod0_L1EM7", year=18, pt_low="pt10", pt_high="pt12", prescale=True),
        Trigger("HLT_e12_lhvloose_nod0_L1EM10VH", year=18, pt_low="pt12", pt_high="pt15", prescale=True),
        Trigger("HLT_e15_lhvloose_nod0_L1EM7", year=18, pt_low="pt15", pt_high="pt17", prescale=True),
        Trigger("HLT_e17_lhvloose_nod0", year=18, pt_low="pt17", pt_high="pt20", prescale=True),
        Trigger("HLT_e20_lhvloose_nod0", year=18, pt_low="pt20", pt_high="pt28", prescale=True),
        Trigger("HLT_e28_lhvloose_nod0_L1EM22VH", year=18, pt_low="pt28", pt_high="pt60", prescale=True),
        Trigger("HLT_e60_lhvloose_nod0", year=18, pt_low="pt60", pt_high="pt70", prescale=True),
        Trigger("HLT_e70_lhvloose_nod0", year=18, pt_low="pt70", pt_high="pt80", prescale=True),
        Trigger("HLT_e80_lhvloose_nod0", year=18, pt_low="pt80", pt_high="pt100", prescale=True),
        Trigger("HLT_e100_lhvloose_nod0", year=18, pt_low="pt100", pt_high="pt120", prescale=True),
        Trigger("HLT_e120_lhvloose_nod0", year=18, pt_low="pt120", pt_high="pt140", prescale=True),
        Trigger("HLT_e140_lhvloose_nod0", year=18, pt_low="pt140", pt_high="pt160", prescale=True),
        Trigger("HLT_e160_lhvloose_nod0", year=18, pt_low="pt160", pt_high="ptUnprescaledEl", prescale=True),
        Trigger("HLT_e300_etcut", year=18, pt_low="ptUnprescaledEl", pt_high="ptMax", prescale=True),
        # 2022
        Trigger("HLT_e10_lhvloose_L1EM7", year=22, pt_low="ptBaselineLow", pt_high="pt20", prescale=True),
        Trigger("HLT_e20_lhvloose_L1EM15VH", year=22, pt_low="pt20", pt_high="pt30", prescale=True),
        Trigger("HLT_e30_lhvloose_L1EM22VHI", year=22, pt_low="pt30", pt_high="pt40", prescale=True),
        Trigger("HLT_e40_lhvloose_L1EM22VHI", year=22, pt_low="pt40", pt_high="pt60", prescale=True),
        Trigger("HLT_e60_lhvloose_L1EM22VHI", year=22, pt_low="pt60", pt_high="pt80", prescale=True),
        Trigger("HLT_e80_lhvloose_L1EM22VHI", year=22, pt_low="pt80", pt_high="pt100", prescale=True),
        Trigger("HLT_e100_lhvloose_L1EM22VHI", year=22, pt_low="pt100", pt_high="pt120", prescale=True),
        Trigger("HLT_e120_lhvloose_L1EM22VHI", year=22, pt_low="pt120", pt_high="ptUnprescaledEl", prescale=True),
        Trigger("HLT_e300_etcut_L1eEM26M", year=22, pt_low="ptUnprescaledEl", pt_high="ptMax", prescale=True),
        # 2023
        Trigger("HLT_e10_lhvloose_L1eEM9", year=23, pt_low="ptBaselineLow", pt_high="pt20", prescale=True),
        Trigger("HLT_e20_lhvloose_L1eEM18L", year=23, pt_low="pt20", pt_high="pt30", prescale=True),
        Trigger("HLT_e30_lhvloose_L1eEM26M", year=23, pt_low="pt30", pt_high="pt40", prescale=True),
        Trigger("HLT_e40_lhvloose_L1eEM26M", year=23, pt_low="pt40", pt_high="pt60", prescale=True),
        Trigger("HLT_e60_lhvloose_L1eEM26M", year=23, pt_low="pt60", pt_high="pt80", prescale=True),
        Trigger("HLT_e80_lhvloose_L1eEM26M", year=23, pt_low="pt80", pt_high="pt100", prescale=True),
        Trigger("HLT_e100_lhvloose_L1eEM26M", year=23, pt_low="pt100", pt_high="pt120", prescale=True),
        Trigger("HLT_e120_lhvloose_L1eEM26M", year=23, pt_low="pt120", pt_high="ptUnprescaledEl", prescale=True),
        Trigger("HLT_e300_etcut_L1eEM26M", year=23, pt_low="ptUnprescaledEl", pt_high="ptMax", prescale=True),
        # 2024
        Trigger("HLT_e10_lhvloose_L1eEM9", year=24, pt_low="ptBaselineLow", pt_high="pt20", prescale=True),
        Trigger("HLT_e20_lhvloose_L1eEM18L", year=24, pt_low="pt20", pt_high="pt30", prescale=True),
        Trigger("HLT_e30_lhvloose_L1eEM26M", year=24, pt_low="pt30", pt_high="pt40", prescale=True),
        Trigger("HLT_e40_lhvloose_L1eEM26M", year=24, pt_low="pt40", pt_high="pt60", prescale=True),
        Trigger("HLT_e60_lhvloose_L1eEM26M", year=24, pt_low="pt60", pt_high="pt80", prescale=True),
        Trigger("HLT_e80_lhvloose_L1eEM26M", year=24, pt_low="pt80", pt_high="pt100", prescale=True),
        Trigger("HLT_e100_lhvloose_L1eEM26M", year=24, pt_low="pt100", pt_high="pt120", prescale=True),
        Trigger("HLT_e120_lhvloose_L1eEM26M", year=24, pt_low="pt120", pt_high="ptUnprescaledEl", prescale=True),
        Trigger("HLT_e300_etcut_L1eEM26M", year=24, pt_low="ptUnprescaledEl", pt_high="ptMax", prescale=True),
    ]

    def __init__(
        self,
        name: str = "fakesSingleElectronTrigger",
        el_id: str | None = None,
        el_iso: str | None = None,
        use_sf: bool = True,
        trigger_match: bool = True,
        prescale: bool = True,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)
        self.set_working_points(el_id=el_id, el_iso=el_iso)
        self.set_trigger_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}


class SingleMuonFakesTrigger(TriggerProcessor):
    triggers = [
        # 2015
        Trigger("HLT_mu6", year=15, pt_low="ptBaselineLow", pt_high="pt10", prescale=True),
        Trigger("HLT_mu10", year=15, pt_low="pt10", pt_high="pt14", prescale=True),
        Trigger("HLT_mu14", year=15, pt_low="pt14", pt_high="pt18", prescale=True),
        Trigger("HLT_mu18", year=15, pt_low="pt18", pt_high="pt24", prescale=True),
        Trigger("HLT_mu24", year=15, pt_low="pt24", pt_high="ptUnprescaledMu", prescale=True),
        Trigger("HLT_mu50", year=15, pt_low="ptUnprescaledMu", pt_high="ptMax", prescale=True),
        # 2016
        Trigger("HLT_mu6", year=16, pt_low="ptBaselineLow", pt_high="pt10", prescale=True),
        Trigger("HLT_mu10", year=16, pt_low="pt10", pt_high="pt14", prescale=True),
        Trigger("HLT_mu14", year=16, pt_low="pt14", pt_high="pt18", prescale=True),
        Trigger("HLT_mu18", year=16, pt_low="pt18", pt_high="pt20", prescale=True),
        Trigger("HLT_mu20", year=16, pt_low="pt20", pt_high="pt22", prescale=True),
        Trigger("HLT_mu22", year=16, pt_low="pt22", pt_high="pt24", prescale=True),
        Trigger("HLT_mu24", year=16, pt_low="pt24", pt_high="ptUnprescaledMu", prescale=True),
        Trigger("HLT_mu50", year=16, pt_low="ptUnprescaledMu", pt_high="ptMax", prescale=True),
        # 2017
        Trigger("HLT_mu6", year=17, pt_low="ptBaselineLow", pt_high="pt14", prescale=True),
        Trigger("HLT_mu14", year=17, pt_low="pt14", pt_high="pt20", prescale=True),
        Trigger("HLT_mu20", year=17, pt_low="pt20", pt_high="pt22", prescale=True),
        Trigger("HLT_mu22", year=17, pt_low="pt22", pt_high="pt24", prescale=True),
        Trigger("HLT_mu24", year=17, pt_low="pt24", pt_high="ptUnprescaledMu", prescale=True),
        Trigger("HLT_mu50", year=17, pt_low="ptUnprescaledMu", pt_high="ptMax", prescale=True),
        # 2018
        Trigger("HLT_mu6", year=18, pt_low="ptBaselineLow", pt_high="pt14", prescale=True),
        Trigger("HLT_mu14", year=18, pt_low="pt14", pt_high="pt20", prescale=True),
        Trigger("HLT_mu20", year=18, pt_low="pt20", pt_high="pt22", prescale=True),
        Trigger("HLT_mu22", year=18, pt_low="pt22", pt_high="pt24", prescale=True),
        Trigger("HLT_mu24", year=18, pt_low="pt24", pt_high="ptUnprescaledMu", prescale=True),
        Trigger("HLT_mu50", year=18, pt_low="ptUnprescaledMu", pt_high="ptMax", prescale=True),
        # 2022
        Trigger("HLT_mu10_l2mt_L1MU10BOM", year=22, pt_low="ptBaselineLow", pt_high="pt22", prescale=True),
        Trigger("HLT_mu22_L1MU14FCH", year=22, pt_low="pt22", pt_high="pt26", prescale=True),
        Trigger("HLT_mu26_L1MU14FCH", year=22, pt_low="pt26", pt_high="pt50", prescale=True),
        Trigger("HLT_mu50_L1MU14FCH", year=22, pt_low="pt50", pt_high="ptMax", prescale=True),
        # 2023
        Trigger("HLT_mu10_l2mt_L1MU10BOM", year=23, pt_low="ptBaselineLow", pt_high="pt22", prescale=True),
        Trigger("HLT_mu22_L1MU14FCH", year=23, pt_low="pt22", pt_high="pt24", prescale=True),
        Trigger("HLT_mu24_L1MU14FCH", year=23, pt_low="pt24", pt_high="pt26", prescale=True),
        Trigger("HLT_mu26_L1MU14FCH", year=23, pt_low="pt26", pt_high="pt50", prescale=True),
        Trigger("HLT_mu50_L1MU14FCH", year=23, pt_low="pt50", pt_high="ptMax", prescale=True),
        # 2024
        Trigger("HLT_mu10_l2mt_L1MU10BOM", year=24, pt_low="ptBaselineLow", pt_high="pt22", prescale=True),
        Trigger("HLT_mu22_L1MU14FCH", year=24, pt_low="pt22", pt_high="pt24", prescale=True),
        Trigger("HLT_mu24_L1MU14FCH", year=24, pt_low="pt24", pt_high="pt26", prescale=True),
        Trigger("HLT_mu26_L1MU14FCH", year=24, pt_low="pt26", pt_high="pt50", prescale=True),
        Trigger("HLT_mu50_L1MU14FCH", year=24, pt_low="pt50", pt_high="ptMax", prescale=True),
    ]

    def __init__(
        self,
        name: str = "fakesSingleMuonTrigger",
        mu_reco: str | None = None,
        use_sf: bool = True,
        trigger_match: bool = True,
        prescale: bool = True,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)
        self.set_working_points(mu_reco=mu_reco)
        self.set_trigger_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}


class SingleLeptonTrigger(TriggerProcessor):
    triggers: list[Trigger] = [
        # 2015
        Trigger(
            "HLT_e24_lhmedium_L1EM20VH",
            year=15,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e60_lhmedium",
            year=15,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e120_lhloose",
            year=15,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu20_iloose_L1MU15",
            year=15,
            leg1_eff="HLT_mu20_iloose_L1MU15_OR_HLT_mu40",
        ),
        Trigger(
            "HLT_mu40",
            year=15,
            leg1_eff="HLT_mu20_iloose_L1MU15_OR_HLT_mu40",
        ),
        # 2016
        Trigger(
            "HLT_e26_lhtight_nod0_ivarloose",
            year=16,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e60_lhmedium_nod0",
            year=16,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e140_lhloose_nod0",
            year=16,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu26_ivarmedium",
            year=16,
            leg1_eff="HLT_mu26_ivarmedium_OR_HLT_mu50",
        ),
        Trigger(
            "HLT_mu50",
            year=16,
            leg1_eff="HLT_mu26_ivarmedium_OR_HLT_mu50",
        ),
        # 2017 (same as 2016)
        Trigger(
            "HLT_e26_lhtight_nod0_ivarloose",
            year=17,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e60_lhmedium_nod0",
            year=17,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e140_lhloose_nod0",
            year=17,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu26_ivarmedium",
            year=17,
            leg1_eff="HLT_mu26_ivarmedium_OR_HLT_mu50",
        ),
        Trigger(
            "HLT_mu50",
            year=17,
            leg1_eff="HLT_mu26_ivarmedium_OR_HLT_mu50",
        ),
        # 2018 (same as 2017)
        Trigger(
            "HLT_e26_lhtight_nod0_ivarloose",
            year=18,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e60_lhmedium_nod0",
            year=18,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e140_lhloose_nod0",
            year=18,
            leg1_eff="SINGLE_E_2015_e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose_2016_2018_e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            leg1_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu26_ivarmedium",
            year=18,
            leg1_eff="HLT_mu26_ivarmedium_OR_HLT_mu50",
        ),
        Trigger(
            "HLT_mu50",
            year=18,
            leg1_eff="HLT_mu26_ivarmedium_OR_HLT_mu50",
        ),
    ]

    def __init__(
        self,
        name: str = "singleLeptonTrigger",
        el_id: str | None = None,
        el_iso: str | None = None,
        mu_reco: str | None = None,
        use_sf: bool = True,
        trigger_match: bool = True,
        prescale: bool = False,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)
        self.set_working_points(el_id=el_id, el_iso=el_iso, mu_reco=mu_reco)
        self.set_trigger_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}


class LeptonTauTrigger(TriggerProcessor):
    triggers: list[Trigger] = [
        # 2015 - electron+tau
        Trigger(
            "HLT_e17_lhmedium_nod0_tau25_medium1_tracktwo",
            year=15,
            leg1_eff="E_TAU_2015_2016_e17_lhmedium_nod0_L1EM15HI_2017_2018_e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        # 2015 - muon+tau
        Trigger(
            "HLT_mu14_tau25_medium1_tracktwo",
            year=15,
            leg1_eff="HLT_mu14",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_tau35_medium1_tracktwo",
            year=15,
            leg1_eff="HLT_mu14",
            leg2_eff="HLT_tau35_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        # 2016 - electron+tau
        Trigger(
            "HLT_e17_lhmedium_nod0_ivarloose_tau25_medium1_tracktwo",
            year=16,
            leg1_eff="E_TAU_2015_2016_e17_lhmedium_nod0_L1EM15HI_2017_2018_e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        # 2016 - muon+tau
        Trigger(
            "HLT_mu14_tau25_medium1_tracktwo",
            year=16,
            leg1_eff="HLT_mu14",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_tau35_medium1_tracktwo",
            year=16,
            leg1_eff="HLT_mu14",
            leg2_eff="HLT_tau35_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau25_medium1_tracktwo",
            year=16,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau35_medium1_tracktwo",
            year=16,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau35_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        # 2017 - electron+tau
        Trigger(
            "HLT_e17_lhmedium_nod0_ivarloose_tau25_medium1_tracktwo",
            year=17,
            leg1_eff="E_TAU_2015_2016_e17_lhmedium_nod0_L1EM15HI_2017_2018_e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e17_lhmedium_nod0_ivarloose_tau25_medium1_tracktwoEF",
            year=17,
            leg1_eff="E_TAU_2015_2016_e17_lhmedium_nod0_L1EM15HI_2017_2018_e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI",
            leg2_eff="HLT_tau25_medium1_tracktwoEF",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        # 2017 - muon+tau
        Trigger(
            "HLT_mu14_ivarloose_tau25_medium1_tracktwo",
            year=17,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau25_medium1_tracktwoEF",
            year=17,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau25_medium1_tracktwoEF",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau35_medium1_tracktwo",
            year=17,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau35_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau35_medium1_tracktwoEF",
            year=17,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau35_medium1_tracktwoEF",
            leg2_use_eff_sf=True,
        ),
        # 2018 - electron+tau
        Trigger(
            "HLT_e17_lhmedium_nod0_ivarloose_tau25_medium1_tracktwo",
            year=18,
            leg1_eff="E_TAU_2015_2016_e17_lhmedium_nod0_L1EM15HI_2017_2018_e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_e17_lhmedium_nod0_ivarloose_tau25_medium1_tracktwoEF",
            year=18,
            leg1_eff="E_TAU_2015_2016_e17_lhmedium_nod0_L1EM15HI_2017_2018_e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI",
            leg2_eff="HLT_tau25_medium1_tracktwoEF",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        # 2018 - muon+tau
        Trigger(
            "HLT_mu14_ivarloose_tau25_medium1_tracktwo",
            year=18,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau25_medium1_tracktwoEF",
            year=18,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau25_medium1_tracktwoEF",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau35_medium1_tracktwo",
            year=18,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau35_medium1_tracktwo",
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_mu14_ivarloose_tau35_medium1_tracktwoEF",
            year=18,
            leg1_eff="HLT_mu14_ivarloose",
            leg2_eff="HLT_tau35_medium1_tracktwoEF",
            leg2_use_eff_sf=True,
        ),
    ]

    def __init__(
        self,
        name: str = "leptonTauTrigger",
        el_id: str | None = None,
        el_iso: str | None = None,
        mu_reco: str | None = None,
        tau_id: str | None = None,
        use_sf: bool = False,
        trigger_match: bool = True,
        prescale: bool = False,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)
        self.set_working_points(el_id=el_id, el_iso=el_iso, mu_reco=mu_reco, tau_id=tau_id)
        self.set_trigger_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}


class DiTauTrigger(TriggerProcessor):
    triggers: list[Trigger] = [
        # 2015
        Trigger(
            "HLT_tau35_medium1_tracktwo_tau25_medium1_tracktwo_L1TAU20IM_2TAU12IM",
            year=15,
            leg1_eff="HLT_tau35_medium1_tracktwo",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        # 2016
        Trigger(
            "HLT_tau35_medium1_tracktwo_tau25_medium1_tracktwo",
            year=16,
            leg1_eff="HLT_tau35_medium1_tracktwo",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_tau80_medium1_tracktwo_L1TAU60_tau50_medium1_tracktwo_L1TAU12",
            year=16,
            leg1_eff="HLT_tau80L1TAU60_medium1_tracktwo",
            leg2_eff="HLT_tau50L1TAU12_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        # 2017
        Trigger(
            "HLT_tau35_medium1_tracktwo_tau25_medium1_tracktwo",
            year=17,
            leg1_eff="HLT_tau35_medium1_tracktwo",
            leg2_eff="HLT_tau25_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_tau80_medium1_tracktwo_L1TAU60_tau50_medium1_tracktwo_L1TAU12",
            year=17,
            leg1_eff="HLT_tau80L1TAU60_medium1_tracktwo",
            leg2_eff="HLT_tau50L1TAU12_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_tau80_medium1_tracktwo_L1TAU60_tau60_medium1_tracktwo_L1TAU40",
            year=17,
            # no tau60 L1TAU40 SF branch available in ntuples
        ),
        Trigger(
            "HLT_tau80_medium1_tracktwo_L1TAU60_tau35_medium1_tracktwo_L1TAU12IM_L1TAU60_DR_TAU20ITAU12I",
            year=17,
            leg1_eff="HLT_tau80L1TAU60_medium1_tracktwo",
            leg2_eff="HLT_tau35_medium1_tracktwo",
            leg1_use_eff_sf=True,
            leg2_use_eff_sf=True,
        ),
        Trigger(
            "HLT_tau80_medium1_tracktwoEF_L1TAU60_tau60_medium1_tracktwoEF_L1TAU40",
            year=18,
            # no tau60 L1TAU40 SF branch available in ntuples
        ),
        Trigger(
            "HLT_tau80_mediumRNN_tracktwoMVA_L1TAU60_tau60_mediumRNN_tracktwoMVA_L1TAU40",
            year=18,
            # no mediumRNN SF branches available in ntuples
        ),
    ]

    def __init__(
        self,
        name: str = "diTauTrigger",
        tau_id: str | None = None,
        use_sf: bool = False,
        trigger_match: bool = True,
        prescale: bool = False,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)
        self.set_working_points(tau_id=tau_id)
        self.set_trigger_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}
