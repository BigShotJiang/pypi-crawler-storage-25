from dataclasses import dataclass

import awkward as ak
import numpy as np

from f9columnar.analysis.trigger.trigger_lookup import TriggerLookup


@dataclass
class PtRange:
    lo: float = 0.0
    hi: float = float("inf")

    def contains(self, pt: np.ndarray) -> np.ndarray:
        """Vectorized contains check"""
        return (pt >= self.lo) & (pt < self.hi)


@dataclass
class HierarchyRule:
    pt_range: PtRange
    legs: list[str]  # ordered tight -> loose
    trigger_lookup: TriggerLookup
    leg_ids: list[int] | None = None  # integer IDs for fast lookup

    def __post_init__(self):
        """Initialize integer IDs for legs after creation."""
        if self.leg_ids is None:
            self.leg_ids = [self.trigger_lookup.get_id(leg) for leg in self.legs]

    def index(self, leg: str) -> int | None:
        try:
            return self.legs.index(leg)
        except ValueError:
            return None

    def index_by_id(self, leg_id: int) -> int | None:
        """Get index of leg by its integer ID (fast lookup)."""
        try:
            return self.leg_ids.index(leg_id)  # type: ignore[union-attr]
        except ValueError:
            return None


class TriggerHierarchy:
    def __init__(self, trigger_lookup: TriggerLookup) -> None:
        self.thresholds: dict[str, float] = {}
        self.thresholds_by_id: dict[int, float] = {}  # integer ID -> threshold (fast lookup)

        self.aliases: dict[str, list[str]] = {}
        self.rules: list[HierarchyRule] = []

        self.all_legs: set[str] = set()
        self.all_leg_ids: set[int] = set()  # integer IDs for fast membership checks

        self._lookup = trigger_lookup

    def add_threshold(self, leg: str, threshold_mev: float):
        self.thresholds[leg] = threshold_mev

        leg_id = self._lookup.get_id(leg)
        self.thresholds_by_id[leg_id] = threshold_mev

    def add_alias(self, name: str, expansion: list[str]):
        self.aliases[name] = expansion

    def add_rule(self, pt_range: PtRange, legs: list[str]):
        expanded = []
        for leg in legs:
            alias_leg = self.aliases.get(leg, [leg])
            self.all_legs.update(alias_leg)
            expanded.extend(alias_leg)

        # create rule with integer IDs
        rule = HierarchyRule(pt_range, expanded, self._lookup)
        self.rules.append(rule)

        self.all_leg_ids.update(rule.leg_ids)  # type: ignore[arg-type]

    def _np_select_leg(
        self, pt: np.ndarray, candidate_legs: list[str], select_loosest: bool = True, return_ids: bool = False
    ) -> np.ndarray:
        """Select the loosest (or tightest) trigger leg for each pt value.

        This follows the official ATLAS TrigGlobalEfficiencyCorrectionTool implementation:
          - For each pair of legs, find the first rule that contains both legs
          - Compare their positions within that rule
          - Build a ranking by counting how many legs are tighter than each leg

        """
        n = len(pt)
        n_legs = len(candidate_legs)

        # convert candidate legs to integer IDs once
        candidate_leg_ids = np.array([self._lookup.get_id(leg) for leg in candidate_legs], dtype=np.int32)

        # pre-filter legs by threshold (vectorized) - using integer ID lookup
        valid_mask = np.ones((n, n_legs), dtype=bool)
        for i, leg_id in enumerate(candidate_leg_ids):
            if leg_id in self.thresholds_by_id:
                valid_mask[:, i] = pt >= self.thresholds_by_id[leg_id]

        # build pairwise comparison matrix
        # counts[i, j] = how many legs are tighter than leg j for event i
        counts = np.zeros((n, n_legs), dtype=np.int32)

        # track which leg pairs have been compared for each event
        # compared[event_idx, leg_i, leg_j] = True if we've found a rule for this pair
        compared = np.zeros((n, n_legs, n_legs), dtype=bool)

        # process rules in order (critical for "first match" behavior)
        for rule in self.rules:
            # find events in this rule's pt range
            in_range = rule.pt_range.contains(pt)
            if not np.any(in_range):
                continue

            # for each pair of candidate legs, check if both are in this rule
            # use integer IDs for fast comparison
            for i, leg_id_i in enumerate(candidate_leg_ids):
                pos_i = rule.index_by_id(leg_id_i)
                if pos_i is None:
                    continue

                for j in range(i + 1, n_legs):
                    leg_id_j = candidate_leg_ids[j]
                    pos_j = rule.index_by_id(leg_id_j)
                    if pos_j is None:
                        continue

                    # only process events where:
                    # 1. This rule applies (in_range)
                    # 2. This pair hasn't been compared yet (~compared[:, i, j])
                    needs_comparison = in_range & ~compared[:, i, j]

                    if not np.any(needs_comparison):
                        continue

                    # mark as compared for these events (symmetric)
                    compared[needs_comparison, i, j] = True
                    compared[needs_comparison, j, i] = True

                    # update counts based on positions in this rule
                    # earlier position = tighter leg
                    if pos_i > pos_j:  # leg_i is looser (later in rule)
                        counts[needs_comparison, i] += 1
                    else:  # leg_j is looser
                        counts[needs_comparison, j] += 1

        # mask out invalid legs by setting their counts to sentinel values
        counts = np.where(valid_mask, counts, -999)

        # select based on counts
        if select_loosest:
            # loosest leg = highest count (most legs are tighter than it)
            selected_idx = np.argmax(counts, axis=1)
        else:
            # tightest leg = lowest count (fewest legs are tighter than it)
            # set invalid legs to high value so they won't be selected
            counts_tightest = np.where(valid_mask, counts, 999)
            selected_idx = np.argmin(counts_tightest, axis=1)

        # build result array, handling cases with no valid legs
        has_valid = np.any(valid_mask, axis=1)

        if return_ids:
            result = np.full(n, -1, dtype=np.int32)  # -1 = None/invalid
            result[has_valid] = candidate_leg_ids[selected_idx[has_valid]]
            return result
        else:
            result = np.empty(n, dtype=object)
            result[:] = None  # type: ignore[call-overload]
            result[has_valid] = [candidate_legs[idx] for idx in selected_idx[has_valid]]
            return result

    def _ak_select_leg(self, pt: ak.Array, candidate_legs: list[str], select_loosest: bool = True) -> ak.Array:
        flat_pt = ak.flatten(pt, axis=None)
        flat_pt_np = ak.to_numpy(flat_pt)

        # get IDs directly from _np_select_leg (much faster than converting strings)
        flat_result_ids = self._np_select_leg(flat_pt_np, candidate_legs, select_loosest, return_ids=True)

        # unflatten the IDs
        result_ids = ak.unflatten(flat_result_ids, ak.num(pt, axis=-1))

        # create masked array (-1 represents None/invalid)
        result_ids = ak.mask(result_ids, result_ids != -1, valid_when=True)

        return result_ids

    def select_leg(
        self, pt: np.ndarray | ak.Array, candidate_legs: list[str], is_gev: bool = False, select_loosest: bool = True
    ) -> np.ndarray | ak.Array:
        candidate_legs = [self._lookup.leg_aliases.get(leg, leg) for leg in candidate_legs]

        if set(candidate_legs).issubset(self.all_legs) is False:
            raise RuntimeError("Some candidate legs are not in the trigger hierarchy!")

        if is_gev:
            pt = pt * 1000.0  # convert to MeV

        if isinstance(pt, np.ndarray):
            return self._np_select_leg(pt, candidate_legs, select_loosest, return_ids=False)
        elif isinstance(pt, ak.Array):
            return self._ak_select_leg(pt, candidate_legs, select_loosest)
        else:
            raise TypeError("pt must be a numpy ndarray or an awkward Array")

    def __call__(
        self, pt: np.ndarray | ak.Array, candidate_legs: list[str], is_gev: bool = False, select_loosest: bool = True
    ) -> np.ndarray | ak.Array:
        return self.select_leg(pt, candidate_legs, is_gev, select_loosest)


def construct_trigger_hierarchies(trigger_lookup: TriggerLookup) -> TriggerHierarchy:
    hier = TriggerHierarchy(trigger_lookup)

    # ===== THRESHOLDS =====

    # muon triggers
    hier.add_threshold("mu50", 51000)
    hier.add_threshold("mu50_L1MU14FCH", 51000)
    hier.add_threshold("mu40", 41000)
    hier.add_threshold("mu26_imedium", 27000)
    hier.add_threshold("mu26_imedium_OR_mu40", 27000)
    hier.add_threshold("mu26_imedium_OR_mu50", 27000)
    hier.add_threshold("mu26_ivarmedium", 27000)
    hier.add_threshold("mu26_ivarmedium_L1MU14FCH", 27000)
    hier.add_threshold("mu26_ivarmedium_OR_mu40", 27000)
    hier.add_threshold("mu26_ivarmedium_OR_mu50", 27000)
    hier.add_threshold("mu26_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH", 27000)
    hier.add_threshold("mu24_iloose_L1MU15", 25000)
    hier.add_threshold("mu24_iloose_L1MU15_OR_mu40", 25000)
    hier.add_threshold("mu24_iloose_L1MU15_OR_mu50", 25000)
    hier.add_threshold("mu24_iloose_L1MU15_OR_mu24_iloose", 25000)
    hier.add_threshold("mu24_iloose_L1MU15_OR_mu24_iloose_OR_mu40", 25000)
    hier.add_threshold("mu24_iloose_L1MU15_OR_mu24_iloose_OR_mu50", 25000)
    hier.add_threshold("mu24_imedium", 25000)
    hier.add_threshold("mu24_imedium_OR_mu40", 25000)
    hier.add_threshold("mu24_imedium_OR_mu50", 25000)
    hier.add_threshold("mu24_ivarmedium", 25000)
    hier.add_threshold("mu24_ivarmedium_L1MU14FCH", 25000)
    hier.add_threshold("mu24_ivarmedium_OR_mu40", 25000)
    hier.add_threshold("mu24_ivarmedium_OR_mu50", 25000)
    hier.add_threshold("mu24_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH", 25000)
    hier.add_threshold("mu26", 27000)
    hier.add_threshold("mu24", 25000)
    hier.add_threshold("mu24_L1MU14FCH", 25000)
    hier.add_threshold("mu22", 23000)
    hier.add_threshold("mu22_L1MU14FCH", 23000)
    hier.add_threshold("mu20_ivarmedium_L1MU14FCH", 23000)
    hier.add_threshold("mu20_iloose_L1MU15_OR_mu50", 21000)
    hier.add_threshold("mu20_iloose_L1MU15_OR_mu40", 21000)
    hier.add_threshold("mu20_iloose_L1MU15", 21000)
    hier.add_threshold("mu20", 21000)
    hier.add_threshold("mu20_L1MU14FCH", 21000)
    hier.add_threshold("mu18", 19000)
    hier.add_threshold("mu18noL1", 18000)
    hier.add_threshold("mu15", 16000)
    hier.add_threshold("mu15noL1", 15000)
    hier.add_threshold("mu14", 15000)
    hier.add_threshold("mu14_L1MU8F", 15000)
    hier.add_threshold("mu14_ivarloose", 15000)
    hier.add_threshold("mu14_ivarloose_L1MU8F", 15000)
    hier.add_threshold("mu10", 11000)
    hier.add_threshold("mu10_L1MU8F", 11000)
    hier.add_threshold("mu10_ivarmedium_L1MU8F", 11000)
    hier.add_threshold("mu8noL1", 8000)
    hier.add_threshold("mu8noL1_FSNOSEED", 8000)
    hier.add_threshold("mu6", 7000)
    hier.add_threshold("mu6_L1MU5VF", 7000)
    hier.add_threshold("mu4", 5000)
    hier.add_threshold("mu4_L1MU3V", 5000)
    hier.add_threshold("mu4noL1", 4000)
    hier.add_threshold("mu2noL1", 2000)

    # electron triggers
    hier.add_threshold("e300_etcut_L1eEM26M", 301000)
    hier.add_threshold("e140_lhloose_nod0", 141000)
    hier.add_threshold("e140_lhloose_L1EM22VHI", 141000)
    hier.add_threshold("e140_dnnloose_nogsf_L1EM22VHI", 141000)
    hier.add_threshold("e140_lhloose_L1eEM26M", 141000)
    hier.add_threshold("e120_lhloose", 121000)
    hier.add_threshold("e60_lhmedium", 61000)
    hier.add_threshold("e60_lhmedium_nod0", 61000)
    hier.add_threshold("e60_lhmedium_L1EM22VHI", 61000)
    hier.add_threshold("e60_dnnmedium_nogsf_L1EM22VHI", 61000)
    hier.add_threshold("e60_lhmedium_L1eEM26M", 61000)
    hier.add_threshold("e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M", 27000)
    hier.add_threshold(
        "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M_OR_e300_etcut_L1eEM26M", 27000
    )
    hier.add_threshold("e26_dnntight_ivarloose_L1EM22VHI", 27000)
    hier.add_threshold(
        "e26_dnntight_ivarloose_L1EM22VHI_OR_e60_dnnmedium_nogsf_L1EM22VHI_OR_e140_dnnloose_nogsf_L1EM22VHI", 27000
    )
    hier.add_threshold("e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0", 27000)
    hier.add_threshold("e26_lhtight_ivarloose_L1EM22VHI_OR_e60_lhmedium_L1EM22VHI_OR_e140_lhloose_L1EM22VHI", 27000)
    hier.add_threshold("e26_lhtight_nod0_ivarloose", 27000)
    hier.add_threshold("e26_lhtight_ivarloose_L1EM22VHI", 27000)
    hier.add_threshold("e26_lhmedium_nod0", 27000)
    hier.add_threshold("e26_lhmedium_nod0_L1EM22VHI", 27000)
    hier.add_threshold("e26_lhmedium_L1EM22VHI", 27000)
    hier.add_threshold("e26_lhmedium_L1eEM26M", 27000)
    hier.add_threshold("e26_lhtight_ivarloose_L1eEM26M", 27000)
    hier.add_threshold("e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0", 25000)
    hier.add_threshold("e24_lhtight_nod0_ivarloose", 25000)
    hier.add_threshold("e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose", 25000)
    hier.add_threshold("e24_lhmedium_L1EM20VH", 25000)
    hier.add_threshold("e24_lhmedium_nod0_L1EM20VH", 25000)
    hier.add_threshold("e24_lhmedium_L1EM15VH", 25000)
    hier.add_threshold("e24_lhmedium_L1EM20VHI", 25000)
    hier.add_threshold("e24_lhmedium_nod0_L1EM20VHI", 25000)
    hier.add_threshold("e24_lhmedium_nod0_L1EM15VH", 25000)
    hier.add_threshold("e24_lhvloose_nod0_L1EM20VH", 25000)
    hier.add_threshold("e24_lhvloose_L1EM20VH", 25000)
    hier.add_threshold("e24_lhvloose_L1eEM24L", 25000)
    hier.add_threshold("e20_lhmedium_nod0", 21000)
    hier.add_threshold("e20_lhmedium", 21000)
    hier.add_threshold("e17_lhvloose_L1eEM18M", 19000)
    hier.add_threshold("e17_lhloose", 18000)
    hier.add_threshold("e17_lhloose_nod0", 18000)
    hier.add_threshold("e17_lhloose_L1EM15VH", 18000)
    hier.add_threshold("e17_lhloose_L1eEM18L", 18000)
    hier.add_threshold("e17_lhvloose_nod0", 18000)
    hier.add_threshold("e17_lhvloose_nod0_L1EM15VHI", 18000)
    hier.add_threshold("e17_lhvloose_L1EM15VHI", 18000)
    hier.add_threshold("e17_lhloose_nod0_L1EM15VH", 18000)
    hier.add_threshold("e17_lhmedium_nod0_L1EM15HI", 18000)
    hier.add_threshold("e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI", 18000)
    hier.add_threshold("e15_lhvloose_nod0_L1EM13VH", 16000)
    hier.add_threshold("e12_lhloose", 13000)
    hier.add_threshold("e12_lhloose_nod0", 13000)
    hier.add_threshold("e12_lhloose_L1EM10VH", 13000)
    hier.add_threshold("e12_lhloose_L12EM10VH", 13000)  # same as e12_lhloose_L1EM10VH
    hier.add_threshold("e12_lhloose_L1EM8VH", 13000)
    hier.add_threshold("e12_lhloose_L1eEM10L", 13000)
    hier.add_threshold("e12_lhvloose_nod0_L1EM10VH", 13000)
    hier.add_threshold("e12_lhvloose_L1EM10VH", 13000)
    hier.add_threshold("e12_lhvloose_L1eEM12L", 13000)
    hier.add_threshold("e10_lhloose_nod0_L1EM8VH", 11000)
    hier.add_threshold("e9_lhloose", 10000)
    hier.add_threshold("e9_lhloose_nod0", 10000)
    hier.add_threshold("e9_lhvloose", 10000)
    hier.add_threshold("e7_lhmedium_nod0", 8000)
    hier.add_threshold("e7_lhmedium", 8000)
    hier.add_threshold("e7_lhmedium_L1eEM5", 8000)

    # photon triggers
    hier.add_threshold("g300_etcut_L1eEM26M", 300000)
    hier.add_threshold("g300_etcut_L1EM22VHI", 300000)
    hier.add_threshold("g300_etcut", 300000)
    hier.add_threshold("g200_etcut", 200000)
    hier.add_threshold("g140_loose", 141000)
    hier.add_threshold("g140_loose_L1EM22VHI", 141000)
    hier.add_threshold("g140_loose_L1eEM26M", 141000)
    hier.add_threshold("g120_loose", 121000)
    hier.add_threshold("g50_loose_L1EM20VH", 51000)
    hier.add_threshold("g50_loose_L1eEM24L", 51000)
    hier.add_threshold("g35_tight_icalotight_L1EM24VHI", 36000)
    hier.add_threshold("g35_medium_L1EM20VH", 36000)
    hier.add_threshold("g35_medium_L1eEM24L", 36000)
    hier.add_threshold("g35_loose_L1EM24VHI", 36000)
    hier.add_threshold("g35_loose_L1EM22VHI", 36000)
    hier.add_threshold("g35_loose", 36000)
    hier.add_threshold("g35_loose_L1EM15", 36000)
    hier.add_threshold("g25_medium_L1EM20VH", 26000)
    hier.add_threshold("g25_medium_L1eEM24L", 26000)
    hier.add_threshold("g25_medium", 26000)
    hier.add_threshold("g25_loose", 26000)
    hier.add_threshold("g25_loose_L1EM15", 26000)
    hier.add_threshold("g22_tight_L1EM15VHI", 23000)
    hier.add_threshold("g22_tight_L1eEM18M", 23000)
    hier.add_threshold("g22_tight", 23000)
    hier.add_threshold("g20_tight_icalovloose_L1EM15VHI", 21000)
    hier.add_threshold("g20_tight_icaloloose_L1eEM18M", 21000)
    hier.add_threshold("g20_tight", 21000)
    hier.add_threshold("g20_loose", 21000)
    hier.add_threshold("g15_loose", 16000)
    hier.add_threshold("g12_loose", 13000)
    hier.add_threshold("g10_loose", 11000)

    # tau triggers
    # tau80 legs: offline threshold = (80 + 15) GeV = 95 GeV
    hier.add_threshold("tau80_medium1_tracktwo_L1TAU60", 95000)
    hier.add_threshold("tau80_medium1_tracktwoEF_L1TAU60", 95000)
    hier.add_threshold("tau80_mediumRNN_tracktwoMVA_L1TAU60", 95000)
    hier.add_threshold("tau80_mediumRNN_tracktwoMVA", 95000)
    # tau60 legs: offline threshold = (60 + 15) GeV = 75 GeV
    hier.add_threshold("tau60_medium1_tracktwo_L1TAU40", 75000)
    hier.add_threshold("tau60_medium1_tracktwoEF_L1TAU40", 75000)
    hier.add_threshold("tau60_mediumRNN_tracktwoMVA_L1TAU40", 75000)
    hier.add_threshold("tau60_mediumRNN_tracktwoMVA", 75000)
    # tau50 legs: offline threshold = (50 + 10) GeV = 60 GeV
    hier.add_threshold("tau50_medium1_tracktwo_L1TAU12", 60000)
    # tau40 legs: offline threshold = (40 + 10) GeV = 50 GeV
    hier.add_threshold("tau40_mediumRNN_tracktwoMVA", 50000)
    # tau35 legs: offline threshold = (35 + 5) GeV = 40 GeV
    hier.add_threshold("tau35_medium1_tracktwo", 40000)
    hier.add_threshold("tau35_medium1_tracktwoEF", 40000)
    hier.add_threshold("tau35_medium1_tracktwoEF_L1TAU12IM_L1TAU60_DR_TAU20ITAU12I", 40000)
    hier.add_threshold("tau35_medium1_tracktwo_L1TAU12IM_L1TAU60_DR_TAU20ITAU12I", 40000)
    hier.add_threshold("tau35_mediumRNN_tracktwoMVA", 40000)
    hier.add_threshold("tau35_mediumRNN_tracktwoMVA_L1TAU12IM_L1TAU60_DR_TAU20ITAU12I", 40000)
    # tau25 legs: offline threshold = (25 + 5) GeV = 30 GeV
    hier.add_threshold("tau25_medium1_tracktwo", 30000)
    hier.add_threshold("tau25_medium1_tracktwoEF", 30000)
    hier.add_threshold("tau25_medium1_tracktwo_L1TAU20IM_2TAU12IM", 30000)
    hier.add_threshold("tau25_medium1_tracktwo_L1DR_TAU20ITAU12I_J25", 30000)
    hier.add_threshold("tau25_medium1_tracktwoEF_L1DR_TAU20ITAU12I_J25", 30000)
    hier.add_threshold("tau25_mediumRNN_tracktwoMVA", 30000)
    hier.add_threshold("tau25_mediumRNN_tracktwoMVA_L1DR_TAU20ITAU12I_J25", 30000)
    # tau20 legs: offline threshold = (20 + 5) GeV = 25 GeV
    hier.add_threshold("tau20_mediumRNN_tracktwoMVA", 25000)

    # ===== HIERARCHY RULES =====

    # muon triggers
    hier.add_alias(
        "multi",
        [
            "mu24",
            "mu22",
            "mu20",
            "mu18",
            "mu14",
            "mu10",
            "mu6",
            "mu4",
            "mu8noL1",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu50",
            "mu40",
            "multi",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu20_iloose_L1MU15",
            "mu20_iloose_L1MU15_OR_mu50",
            "mu50",
            "mu20_iloose_L1MU15_OR_mu40",
            "mu40",
            "multi",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu26_imedium",
            "mu26_imedium_OR_mu50",
            "mu50",
            "mu26_imedium_OR_mu40",
            "mu40",
            "multi",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu26_ivarmedium",
            "mu26_ivarmedium_OR_mu50",
            "mu50",
            "mu26_ivarmedium_OR_mu40",
            "mu40",
            "multi",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu24_iloose_L1MU15",
            "mu24_iloose_L1MU15_OR_mu50",
            "mu50",
            "mu24_iloose_L1MU15_OR_mu40",
            "mu40",
            "multi",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu24_iloose_L1MU15_OR_mu24_iloose",
            "mu24_iloose_L1MU15_OR_mu24_iloose_OR_mu50",
            "mu50",
            "mu24_iloose_L1MU15_OR_mu24_iloose_OR_mu40",
            "mu40",
            "multi",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu24_imedium",
            "mu24_imedium_OR_mu50",
            "mu50",
            "mu24_imedium_OR_mu40",
            "mu40",
            "multi",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "mu24_ivarmedium",
            "mu24_ivarmedium_OR_mu50",
            "mu50",
            "mu24_ivarmedium_OR_mu40",
            "mu40",
            "multi",
        ],
    )

    # run 3 muons
    hier.add_alias(
        "muonNonIsoRun3",
        [
            "mu50_L1MU14FCH",
            "mu24_L1MU14FCH",
            "mu22_L1MU14FCH",
            "mu20_L1MU14FCH",
            "mu14_L1MU8F",
            "mu6_L1MU5VF",
            "mu4_L1MU3V",
            "mu20",
            "mu18",
            "mu8noL1_FSNOSEED",
            "mu4noL1",
            "mu2noL1",
        ],
    )
    hier.add_rule(
        PtRange(0, 52500),
        [
            "mu26_ivarmedium_L1MU14FCH",
            "mu26_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH",
            "mu24_ivarmedium_L1MU14FCH",
            "mu24_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH",
            "mu20_ivarmedium_L1MU14FCH",
            "mu10_ivarmedium_L1MU8F",
            "mu14_ivarloose_L1MU8F",
            "muonNonIsoRun3",
        ],
    )
    hier.add_rule(
        PtRange(52500),
        [
            "mu26_ivarmedium_L1MU14FCH",
            "mu24_ivarmedium_L1MU14FCH",
            "mu20_ivarmedium_L1MU14FCH",
            "mu20_ivarmedium_L1MU14FCH",
            "mu10_ivarmedium_L1MU8F",
            "mu14_ivarloose_L1MU8F",
            "mu26_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH",
            "mu24_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH",
            "muonNonIsoRun3",
        ],
    )

    # 2015 electron triggers
    hier.add_alias(
        "loose1",
        [
            "e12_lhloose_L1EM10VH",
            "e12_lhloose_L12EM10VH",
            "e120_lhloose",
        ],
    )
    hier.add_alias(
        "loose2",
        [
            "e17_lhloose",
            "e12_lhloose",
            "e9_lhloose",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e24_lhmedium_L1EM20VHI",
            "e24_lhmedium_L1EM20VH",
            "e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e24_lhmedium_L1EM20VHI",
            "e24_lhmedium_L1EM20VH",
            "e60_lhmedium",
            "e24_lhmedium_L1EM15VH",
            "e20_lhmedium",
            "e7_lhmedium",
            "loose1",
            "loose2",
        ],
    )
    hier.add_rule(
        PtRange(0, 61000),
        [
            "e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose",
            "e60_lhmedium",
            "e24_lhmedium_L1EM15VH",
            "e20_lhmedium",
            "e7_lhmedium",
            "loose1",
            "loose2",
        ],
    )
    hier.add_rule(
        PtRange(61000, 121000),
        [
            "e60_lhmedium",
            "e24_lhmedium_L1EM15VH",
            "e20_lhmedium",
            "e7_lhmedium",
            "e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose",
            "loose1",
            "loose2",
        ],
    )
    hier.add_rule(
        PtRange(121000),
        [
            "e60_lhmedium",
            "e24_lhmedium_L1EM15VH",
            "e20_lhmedium",
            "e7_lhmedium",
            "loose1",
            "e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose",
            "loose2",
        ],
    )

    # 2016-2018 electron triggers
    hier.add_alias(
        "medium",
        [
            "e26_lhmedium_nod0_L1EM22VHI",
            "e24_lhmedium_nod0_L1EM20VHI",
            "e26_lhmedium_nod0",
            "e24_lhmedium_nod0_L1EM20VH",
            "e60_lhmedium_nod0",
            "e24_lhmedium_nod0_L1EM15VH",
            "e20_lhmedium_nod0",
            "e7_lhmedium_nod0",
        ],
    )
    hier.add_alias(
        "loose1",
        [
            "e17_lhloose_nod0_L1EM15VH",
            "e10_lhloose_nod0_L1EM8VH",
            "e140_lhloose_nod0",
        ],
    )
    hier.add_alias(
        "loose2",
        [
            "e17_lhloose_nod0",
            "e12_lhloose_nod0",
            "e9_lhloose_nod0",
            "e17_lhvloose_nod0_L1EM15VHI",
            "e24_lhvloose_nod0_L1EM20VH",
            "e15_lhvloose_nod0_L1EM13VH",
            "e12_lhvloose_nod0_L1EM10VH",
            "e17_lhvloose_nod0",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e26_lhtight_nod0_ivarloose",
            "e24_lhtight_nod0_ivarloose",
            "medium",
            "loose1",
            "loose2",
        ],
    )
    hier.add_rule(
        PtRange(0, 61000),
        [
            "e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "medium",
            "loose1",
            "loose2",
        ],
    )
    hier.add_rule(
        PtRange(61000, 141000),
        [
            "medium",
            "e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "loose1",
            "loose2",
        ],
    )
    hier.add_rule(
        PtRange(141000),
        [
            "medium",
            "loose1",
            "e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "loose2",
        ],
    )

    # electron triggers 2022
    hier.add_alias(
        "looseRun3",
        [
            "e17_lhloose_L1EM15VH",
            "e12_lhloose_L1EM8VH",
            "e12_lhloose",
            "e24_lhvloose_L1EM20VH",
            "e12_lhvloose_L1EM10VH",
            "e9_lhvloose",
        ],
    )
    hier.add_alias(
        "looseRun3VHI",
        [
            "e17_lhvloose_L1EM15VHI",
            "e24_lhvloose_L1EM20VH",
            "e12_lhvloose_L1EM10VH",
            "e9_lhvloose",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e26_lhtight_ivarloose_L1EM22VHI",
            "e60_lhmedium_L1EM22VHI",
            "e26_lhmedium_L1EM22VHI",
            "e7_lhmedium",
            "e140_lhloose_L1EM22VHI",
            "looseRun3",
        ],
    )
    hier.add_rule(
        PtRange(0, 141000),
        [
            "e26_lhtight_ivarloose_L1EM22VHI_OR_e60_lhmedium_L1EM22VHI_OR_e140_lhloose_L1EM22VHI",
            "e26_lhmedium_L1EM22VHI",
            "e7_lhmedium",
            "looseRun3",
        ],
    )
    hier.add_rule(
        PtRange(141000),
        [
            "e26_lhmedium_L1EM22VHI",
            "e7_lhmedium",
            "e26_lhtight_ivarloose_L1EM22VHI_OR_e60_lhmedium_L1EM22VHI_OR_e140_lhloose_L1EM22VHI",
            "looseRun3",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e26_dnntight_ivarloose_L1EM22VHI",
            "e26_dnntight_ivarloose_L1EM22VHI_OR_e60_dnnmedium_nogsf_L1EM22VHI_OR_e140_dnnloose_nogsf_L1EM22VHI",
            "looseRun3",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e26_lhtight_ivarloose_L1EM22VHI",
            "e60_lhmedium_L1EM22VHI",
            "e26_lhmedium_L1EM22VHI",
            "e7_lhmedium",
            "e140_lhloose_L1EM22VHI",
            "looseRun3VHI",
        ],
    )
    hier.add_rule(
        PtRange(0, 141000),
        [
            "e26_lhtight_ivarloose_L1EM22VHI_OR_e60_lhmedium_L1EM22VHI_OR_e140_lhloose_L1EM22VHI",
            "e26_lhmedium_L1EM22VHI",
            "e7_lhmedium",
            "looseRun3VHI",
        ],
    )
    hier.add_rule(
        PtRange(141000),
        [
            "e26_lhmedium_L1EM22VHI",
            "e7_lhmedium",
            "e26_lhtight_ivarloose_L1EM22VHI_OR_e60_lhmedium_L1EM22VHI_OR_e140_lhloose_L1EM22VHI",
            "looseRun3VHI",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e26_dnntight_ivarloose_L1EM22VHI",
            "e26_dnntight_ivarloose_L1EM22VHI_OR_e60_dnnmedium_nogsf_L1EM22VHI_OR_e140_dnnloose_nogsf_L1EM22VHI",
            "looseRun3VHI",
        ],
    )

    # electron triggers 2023
    hier.add_rule(
        PtRange(0, 141000),
        [
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M_OR_e300_etcut_L1eEM26M",
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M",
            "e60_lhmedium_L1eEM26M",
            "e7_lhmedium",
            "e17_lhvloose_L1eEM18M",
            "e24_lhvloose_L1eEM24L",
            "e12_lhvloose_L1eEM12L",
        ],
    )
    hier.add_rule(
        PtRange(141000, 301000),
        [
            "e60_lhmedium_L1eEM26M",
            "e7_lhmedium",
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M_OR_e300_etcut_L1eEM26M",
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M",
            "e17_lhvloose_L1eEM18M",
            "e24_lhvloose_L1eEM24L",
            "e12_lhvloose_L1eEM12L",
        ],
    )
    hier.add_rule(
        PtRange(301000),
        [
            "e60_lhmedium_L1eEM26M",
            "e26_lhmedium_L1eEM26M",
            "e7_lhmedium",
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M",
            "e17_lhvloose_L1eEM18M",
            "e17_lhvloose_L1eEM18M",
            "e24_lhvloose_L1eEM24L",
            "e12_lhvloose_L1eEM12L",
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M_OR_e300_etcut_L1eEM26M",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "e26_lhtight_ivarloose_L1eEM26M",
            "e60_lhmedium_L1eEM26M",
            "e7_lhmedium",
            "e140_lhloose_L1eEM26M",
            "e300_etcut_L1eEM26M",
        ],
    )

    # photon triggers
    hier.add_rule(
        PtRange(),
        [
            "g35_tight_icalotight_L1EM24VHI",
            "g20_tight_icalovloose_L1EM15VHI",
            "g22_tight_L1EM15VHI",
            "g22_tight",
            "g20_tight",
            "g35_medium_L1EM20VH",
            "g25_medium_L1EM20VH",
            "g25_medium",
            "g35_loose_L1EM24VHI",
            "g35_loose_L1EM22VHI",
            "g50_loose_L1EM20VH",
            "g140_loose",
            "g120_loose",
            "g35_loose",
            "g25_loose",
            "g20_loose",
            "g15_loose",
            "g12_loose",
            "g10_loose",
            "g35_loose_L1EM15",
            "g25_loose_L1EM15",
        ],
    )
    hier.add_rule(
        PtRange(),
        [
            "g20_tight_icaloloose_L1eEM18M",
            "g22_tight_L1eEM18M",
            "g35_medium_L1eEM24L",
            "g25_medium_L1eEM24L",
            "g140_loose_L1eEM26M",
            "g50_loose_L1eEM24L",
        ],
    )

    return hier
