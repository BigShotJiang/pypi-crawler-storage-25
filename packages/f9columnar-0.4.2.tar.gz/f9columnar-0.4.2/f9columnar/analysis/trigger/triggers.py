import re
from abc import abstractmethod
from typing import Any

import awkward as ak
import numpy as np

from f9columnar.analysis.trigger.trigger_hierarchy import construct_trigger_hierarchies
from f9columnar.analysis.trigger.trigger_lookup import TriggerLookup
from f9columnar.analysis.utils import DATA_RUN_NUMBERS, TRIGGER_PT
from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor
from f9columnar.variations import vary


def classify_trigger(trigger_name: str) -> dict[str, Any]:
    # determine lepton type(s)
    leptons = []
    if re.search(r"\b2e\b|e\d+", trigger_name):
        leptons.append("el")
    if re.search(r"\b2mu\b|mu\d+", trigger_name):
        leptons.append("mu")
    if re.search(r"tau\d+", trigger_name):
        leptons.append("tau")

    if len(leptons) == 3:
        raise ValueError("Trigger cannot have all three lepton types!")

    if len(leptons) == 0:
        raise ValueError("Trigger must have at least one lepton type!")

    # check if dilepton
    dilepton = (
        len(leptons) > 1
        or bool(re.search(r"2(e|mu)", trigger_name))
        or len(re.findall(r"(e|mu|tau)\d+", trigger_name)) == 2
        or ("tau" in leptons and ("el" in leptons or "mu" in leptons))
    )

    # check if symmetric
    symmetric = False
    if dilepton:
        sym_el_mu = re.search(r"2(e|mu|tau)\d+", trigger_name)
        if sym_el_mu is not None:
            symmetric = True
        if len(leptons) == 1:
            leptons = [leptons[0], leptons[0]]

    # determine mixed-flavor
    mixed_flavor = None
    if dilepton and not symmetric:
        if "el" in leptons and "mu" in leptons:
            mixed_flavor = "emu"
        elif "el" in leptons and "tau" in leptons:
            mixed_flavor = "etau"
        elif "mu" in leptons and "tau" in leptons:
            mixed_flavor = "mutau"

    return {
        "leptons": leptons,
        "dilepton": dilepton,
        "symmetric": symmetric,
        "mixed_flavor": mixed_flavor,
    }


class Trigger:
    def __init__(
        self,
        name: str,
        leg1_eff: str | None = None,
        leg2_eff: str | None = None,
        leg1_use_eff_sf: bool = False,
        leg2_use_eff_sf: bool = False,
        el_id: str | None = None,
        el_iso: str | None = None,
        mu_reco: str | None = None,
        tau_id: str | None = None,
        year: int | None = None,
        run_range: tuple[int, int] | None = None,
        pt_low: float | str = 0.0,
        pt_high: float | str = np.inf,
        prescale: bool = False,
    ) -> None:
        self.name = name

        if leg1_eff is None and leg2_eff is not None:
            raise ValueError("If leg2_eff is specified, leg1_eff must also be specified!")

        self.leg1_eff = leg1_eff
        self.leg2_eff = leg2_eff
        self.leg1_use_eff_sf = leg1_use_eff_sf
        self.leg2_use_eff_sf = leg2_use_eff_sf

        self.el_id = el_id
        self.el_iso = el_iso
        self.mu_reco = mu_reco
        self.tau_id = tau_id

        self.prescale = prescale

        self.trigger_info_dct = classify_trigger(self.name)

        if self.trigger_info_dct["symmetric"] and self.leg1_eff is not None and self.leg2_eff is None:
            self.leg2_eff = self.leg1_eff

        self._set_pt_thresholds(pt_low, pt_high)
        self._set_run_range(year, run_range)
        self._set_leg_names()

        trigger_lookup = TriggerLookup()

        aliased_leg1 = trigger_lookup.leg_aliases.get(self.leg1_name, self.leg1_name)
        self.leg1_id = trigger_lookup.get_id(aliased_leg1)

        if self.leg2_name:
            aliased_leg2 = trigger_lookup.leg_aliases.get(self.leg2_name, self.leg2_name)
            self.leg2_id = trigger_lookup.get_id(aliased_leg2)
        else:
            self.leg2_id = trigger_lookup.get_id("")

        if self.trigger_info_dct["dilepton"]:
            self._trigger_branches = (
                f"trigPassed_{self.name}",
                f"trigMatched_{self.name}.first",
                f"trigMatched_{self.name}.second",
            )
        else:
            lep = self.trigger_info_dct["leptons"][0]
            self._trigger_branches = (
                f"trigPassed_{self.name}",
                f"{lep}_trigMatched_{self.name}",
                "",  # no second leg for single-lepton triggers
            )

        self._prescale_branch = f"trigPrescale_{self.name}"

    def _set_pt_thresholds(self, pt_low: float | str, pt_high: float | str) -> None:
        if type(pt_low) is float:
            low = pt_low
        elif type(pt_low) is str:
            low = TRIGGER_PT[pt_low]
        else:
            raise TypeError("pt_low must be either float or str")

        if type(pt_high) is float:
            high = pt_high
        elif type(pt_high) is str:
            high = TRIGGER_PT[pt_high]
        else:
            raise TypeError("pt_high must be either float or str")

        self._has_pt_requirement = low != 0.0 or high != np.inf

        self._pt_low, self._pt_high = low * 1e3, high * 1e3

    @property
    def pt_low(self) -> float:
        return self._pt_low

    @property
    def pt_high(self) -> float:
        return self._pt_high

    @property
    def has_pt_requirement(self) -> bool:
        return self._has_pt_requirement

    def _set_run_range(self, year: int | None, run_range: tuple[int, int] | None) -> None:
        if run_range is None and year is None:
            raise ValueError("Either run_range or year must be specified!")

        if run_range is not None and year is not None:
            raise ValueError("Only one of run_range or year should be specified!")

        _year: int | None = None

        if run_range is not None:
            for y, (low, up) in DATA_RUN_NUMBERS.items():
                if run_range[0] >= low and run_range[1] <= up:
                    _year = y
                    break

            if _year is None:
                raise ValueError(f"Run range {run_range} does not correspond to a year!")
            else:
                self._year = _year

            self._run_range = run_range

        if year is not None:
            if year not in DATA_RUN_NUMBERS:
                raise ValueError(f"Year {year} is not recognized!")

            self._run_range = DATA_RUN_NUMBERS[year]
            self._year = year

        if self._year in {170, 171, 172}:
            self._year = 17

    def _set_leg_names(self) -> None:
        split_name = self.name.split("_")[1:]
        if self.trigger_info_dct["dilepton"] and self.trigger_info_dct["symmetric"]:
            leg_name = "_".join(split_name)[1:]
            self.leg2_name, self.leg1_name = leg_name, leg_name
        elif self.trigger_info_dct["dilepton"] and not self.trigger_info_dct["symmetric"]:
            leg1_name, leg2_name = "", ""

            part_idx = 0
            for part in split_name:
                if part.startswith("e") or part.startswith("mu") or part.startswith("tau"):
                    part_idx += 1

                if part_idx == 1:
                    leg1_name += part + "_"
                else:
                    leg2_name += part + "_"

            self.leg1_name, self.leg2_name = leg1_name.rstrip("_"), leg2_name.rstrip("_")
        elif not self.trigger_info_dct["dilepton"]:
            self.leg1_name = "_".join(split_name)
            self.leg2_name = ""
        else:
            raise ValueError("Invalid trigger configuration!")

    @property
    def year(self) -> int:
        return self._year

    def get_run_range(self) -> tuple[int, int]:
        return self._run_range

    @property
    def trigger_branches(self) -> tuple[str, str, str]:
        return self._trigger_branches

    @property
    def prescale_branch(self) -> str | None:
        if self.trigger_info_dct["dilepton"]:
            raise ValueError("Prescale branches are not supported for dilepton triggers!")

        if self.prescale:
            branch = self._prescale_branch
        else:
            branch = None

        return branch

    def _get_eff_type(self, trig_obj: str, eff_type: str, n_leg: int) -> str:
        if eff_type == "data" and ((self.leg1_use_eff_sf and n_leg == 1) or (self.leg2_use_eff_sf and n_leg == 2)):
            eff_str = f"{trig_obj}_effSF_Trig"
        elif eff_type == "data":
            eff_str = f"{trig_obj}_effData_Trig"
        elif eff_type == "mc":
            eff_str = f"{trig_obj}_effMC_Trig"
        else:
            raise ValueError("eff_type must be either 'data' or 'mc'!")

        return eff_str

    def _get_el_eff(self, eff_type: str, n_leg: int = 1) -> str:
        if self.el_id is None or self.el_iso is None:
            raise ValueError("el_id and el_iso must be specified for electron triggers!")

        if self.leg1_eff is None:
            raise ValueError("leg1_eff must be specified for electron triggers!")

        eff_str = self._get_eff_type("el", eff_type, n_leg)
        eff_str += f"_{self.el_id}_{self.el_iso}_"

        if n_leg == 1:
            eff_str += self.leg1_eff
        elif n_leg == 2:
            if self.leg2_eff is None:
                raise ValueError("leg2_eff must be specified for the second electron leg!")

            eff_str += self.leg2_eff
        else:
            raise ValueError("n_leg must be either 1 or 2!")

        return eff_str

    def _get_mu_eff(self, eff_type: str, n_leg: int = 1) -> str:
        if self.mu_reco is None:
            raise ValueError("mu_reco must be specified for muon triggers!")

        if self.leg1_eff is None:
            raise ValueError("leg1_eff must be specified for muon triggers!")

        eff_str = self._get_eff_type("mu", eff_type, n_leg)
        eff_str += f"_{self.mu_reco}_"

        if n_leg == 1:
            eff_str += self.leg1_eff
        elif n_leg == 2:
            if self.leg2_eff is None:
                raise ValueError("leg2_eff must be specified for the second muon leg!")

            eff_str += self.leg2_eff
        else:
            raise ValueError("n_leg must be either 1 or 2!")

        return eff_str

    def _get_tau_eff(self, eff_type: str, n_leg: int = 1) -> str:
        if self.tau_id is None:
            raise ValueError("tau_id must be specified for tau triggers!")

        if self.leg1_eff is None:
            raise ValueError("leg1_eff must be specified for tau triggers!")

        eff_str = self._get_eff_type("tau", eff_type, n_leg)
        eff_str += f"_{self.tau_id}_"

        if n_leg == 1:
            eff_str += self.leg1_eff
        elif n_leg == 2:
            if self.leg2_eff is None:
                raise ValueError("leg2_eff must be specified for the second tau leg!")

            eff_str += self.leg2_eff
        else:
            raise ValueError("n_leg must be either 1 or 2!")

        return eff_str

    def get_single_trigger_eff(self, eff_type: str) -> str:
        is_dilepton = self.trigger_info_dct["dilepton"]
        leptons = self.trigger_info_dct["leptons"]

        if not is_dilepton and leptons[0] == "el":
            return self._get_el_eff(eff_type, n_leg=1)

        if not is_dilepton and leptons[0] == "mu":
            return self._get_mu_eff(eff_type, n_leg=1)

        if not is_dilepton and leptons[0] == "tau":
            return self._get_tau_eff(eff_type, n_leg=1)

        raise ValueError("Unsupported trigger configuration!")

    def get_di_trigger_eff(self, eff_type: str) -> tuple[str, str]:
        is_dilepton = self.trigger_info_dct["dilepton"]
        is_symmetric = self.trigger_info_dct["symmetric"]
        leptons = self.trigger_info_dct["leptons"]

        if is_symmetric and leptons[0] == "el":
            leg_eff = self._get_el_eff(eff_type, n_leg=1)
            return leg_eff, leg_eff

        if is_symmetric and leptons[0] == "mu":
            leg_eff = self._get_mu_eff(eff_type, n_leg=1)
            return leg_eff, leg_eff

        if is_dilepton and leptons == ["el", "mu"]:
            return self._get_el_eff(eff_type, n_leg=1), self._get_mu_eff(eff_type, n_leg=2)

        if is_dilepton and leptons == ["el", "el"]:
            return self._get_el_eff(eff_type, n_leg=1), self._get_el_eff(eff_type, n_leg=2)

        if is_dilepton and leptons == ["mu", "mu"]:
            return self._get_mu_eff(eff_type, n_leg=1), self._get_mu_eff(eff_type, n_leg=2)

        if is_dilepton and leptons == ["tau", "tau"]:
            return self._get_tau_eff(eff_type, n_leg=1), self._get_tau_eff(eff_type, n_leg=2)

        if is_dilepton and leptons == ["el", "tau"]:
            return self._get_el_eff(eff_type, n_leg=1), self._get_tau_eff(eff_type, n_leg=2)

        if is_dilepton and leptons == ["mu", "tau"]:
            return self._get_mu_eff(eff_type, n_leg=1), self._get_tau_eff(eff_type, n_leg=2)

        raise ValueError("Unsupported trigger configuration!")

    def get_leg_names(self) -> tuple[str, str | None]:
        if self.trigger_info_dct["dilepton"]:
            return self.leg1_name, self.leg2_name if self.leg2_name else None
        else:
            return self.leg1_name, None

    def __str__(self) -> str:
        return f"Trigger({self.name}, year={self.year}, range={self._run_range}, pt={self.has_pt_requirement})"

    def __repr__(self) -> str:
        return self.__str__()


class TriggerProcessor(Processor):
    triggers: list[Trigger]

    def __init__(
        self,
        name,
        use_sf: bool = True,
        trigger_match: bool = True,
        prescale: bool = False,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, disable_variations=disable_variations)
        if not hasattr(self, "triggers"):
            raise ValueError("TriggerProcessor subclasses must define 'triggers' attribute!")

        self.use_sf = use_sf
        self.trigger_match = trigger_match
        self.prescale = prescale

        self._check_pt_requirements()

        self.triggers_by_year = self._group_triggers_by_year()

        trigger_lookup = TriggerLookup()
        self.trigger_hierarchy = construct_trigger_hierarchies(trigger_lookup)

        self._disable_matching_triggers = {
            "HLT_mu18_mu8noL1",
            "HLT_mu22_mu8noL1",
            "HLT_e200_etcut",
            "HLT_e300_etcut",
        }

    def _check_pt_requirements(self) -> None:
        """Validate pt requirements configuration. This should only be used with single lepton preselection.

        Allowed:
          - none or all triggers should have pt requirements
          - allow only single-lepton triggers to have pt requirement (checked in run_triggers at run time)

        """
        pt_reqs = []

        for t in self.triggers:
            pt_reqs.append(t.has_pt_requirement)

        if not all(pt_reqs) and any(pt_reqs):
            raise RuntimeError("Either none or all single-lepton triggers must have pt requirements!")

    def _group_triggers_by_year(self, or_triggers: bool = False) -> dict[int, list[Trigger]]:
        triggers_by_year: dict[int, list[Trigger]] = {}
        for trigger in self.triggers:
            year = trigger.year

            if year not in triggers_by_year:
                triggers_by_year[year] = []

            triggers_by_year[year].append(trigger)

        if or_triggers:
            for year in triggers_by_year:
                merged = []
                for t in triggers_by_year[year]:
                    merged.append(t)

                triggers_by_year[year] = merged

        return triggers_by_year

    def set_working_points(
        self,
        el_id: str | None = None,
        el_iso: str | None = None,
        mu_reco: str | None = None,
        tau_id: str | None = None,
    ) -> None:
        if el_id is None and el_iso is not None:
            raise ValueError("If el_iso is specified, el_id must also be specified!")

        if el_id is not None and el_iso is None:
            raise ValueError("If el_id is specified, el_iso must also be specified!")

        if el_id is not None and el_iso is not None:
            for t in self.triggers:
                t.el_id = el_id
                t.el_iso = el_iso

        if mu_reco is not None:
            for t in self.triggers:
                t.mu_reco = mu_reco

        if tau_id is not None:
            for t in self.triggers:
                t.tau_id = tau_id

    def _get_branches_from_trigger(self, trigger: Trigger) -> set[str]:
        branches = set()

        passed, first_match, second_match = trigger.trigger_branches
        branches.add(passed)

        if self.trigger_match and trigger.trigger_info_dct["dilepton"]:
            first_match_split, second_match_split = first_match.split("."), second_match.split(".")
            branches.add(f"{first_match_split[0]}/{first_match_split[0]}.{first_match_split[1]}")
            branches.add(f"{second_match_split[0]}/{second_match_split[0]}.{second_match_split[1]}")

        if self.trigger_match and not trigger.trigger_info_dct["dilepton"]:
            branches.add(first_match)

        if self.prescale:
            prescale_branch = trigger.prescale_branch
            if prescale_branch is not None:
                branches.add(prescale_branch)
            else:
                raise ValueError("Requested prescale branches, but trigger does not support prescales!")

        if self.use_sf and trigger.leg1_eff is not None:
            is_dilepton = trigger.trigger_info_dct["dilepton"]

            if is_dilepton and trigger.leg2_eff is None:
                return branches

            eff_types = ["mc", "data"]

            for eff_type in eff_types:
                if is_dilepton:
                    leg1_eff, leg2_eff = trigger.get_di_trigger_eff(eff_type=eff_type)
                    branches.add(leg1_eff)
                    branches.add(leg2_eff)
                else:
                    eff = trigger.get_single_trigger_eff(eff_type=eff_type)
                    branches.add(eff)

        return branches

    def set_trigger_branches(self) -> None:
        branches = set()
        for t in self.triggers:
            trig_branches = self._get_branches_from_trigger(t)
            branches.update(trig_branches)

        for branch in branches:
            if "trigMatched" in branch or "trigPrescale" in branch or "trigPassed" in branch:
                is_varied = False
            else:
                is_varied = True

            self.attach_branch(branch, is_varied=is_varied)

        present_leptons = {"el": False, "mu": False, "tau": False}
        for t in self.triggers:
            for lep in t.trigger_info_dct["leptons"]:
                present_leptons[lep] = True

        for lep in present_leptons:
            if present_leptons[lep]:
                self.attach_branch((f"{lep}_pt_NOSYS", f"{lep}_pt"), is_varied=True, overwrite=True)

    def _select_pt_branch(self, lep: str) -> str:
        if lep == "el" and hasattr(self, "el_pt"):
            return self.el_pt
        elif lep == "mu" and hasattr(self, "mu_pt"):
            return self.mu_pt
        elif lep == "tau" and hasattr(self, "tau_pt"):
            return self.tau_pt
        else:
            raise RuntimeError("Invalid configuration for selecting pt branch!")

    def _validate_all_single_leptons(self, arrays: GroupArrays, trigger: Trigger, matched_mask: ak.Array) -> ak.Array:
        """Validate all matched leptons and return True if ANY passes.

        For single-lepton triggers, the trigger matching branch is a boolean
        mask per lepton (vector<bool>), not a list of indices. This method
        checks if ANY lepton that is both trigger-matched and passes the
        pT threshold exists in the event.

        Parameters
        ----------
        arrays : GroupArrays
            GroupArrays containing lepton pT and other kinematic data.
        trigger : Trigger
            Trigger object containing trigger configuration and thresholds.
        matched_mask : ak.Array
            Jagged boolean array per event, shape (n_events, var).
            True if lepton at that index is trigger-matched.
            Examples:
                [[True, False], [False, True, True], [], [True]]

        Returns
        -------
        ak.Array
            Boolean array of shape (n_events,) indicating whether ANY matched
            lepton in each event passes validation. Returns False for events
            with no matches.

        """
        lepton_type = trigger.trigger_info_dct["leptons"][0]

        pt_branch = self._select_pt_branch(lepton_type)
        pt_array = arrays[lepton_type, pt_branch]

        # matched_mask is a boolean per lepton: True if trigger-matched
        # cast to bool to handle any integer representation (0/1)
        is_matched = ak.values_astype(matched_mask, bool)

        if trigger.leg1_id in self.trigger_hierarchy.thresholds_by_id:
            threshold = self.trigger_hierarchy.thresholds_by_id[trigger.leg1_id]

            # lepton passes if it is trigger-matched AND its pT >= threshold
            passes_per_lepton = is_matched & (pt_array >= threshold)
        else:
            # no threshold defined, just require trigger match
            passes_per_lepton = is_matched

        # check if ANY lepton in each event passes
        any_passes = ak.any(passes_per_lepton, axis=-1)

        # handle events with no leptons (empty arrays)
        return ak.fill_none(any_passes, False)

    def _validate_all_trigger_pairs(
        self, arrays: GroupArrays, trigger: Trigger, first_indices: ak.Array, second_indices: ak.Array
    ) -> ak.Array:
        """Validate all trigger pairs and return True if ANY pair passes.

        For dilepton triggers, the trigger matching stores all possible lepton pairs
        that could have fired the trigger. This method validates ALL pairs and accepts
        the event if ANY valid pair exists. This ensures no efficiency loss from
        arbitrary pair ordering in the trigger matching output.

        Parameters
        ----------
        arrays : GroupArrays
            GroupArrays containing lepton pT and other kinematic data.
        trigger : Trigger
            Trigger object containing trigger configuration and thresholds.
        first_indices : ak.Array
            Jagged array of first leg lepton indices per event, shape (n_events, var).
            Example: [[0, 0, 1]] represents 3 pairs with first legs at indices 0, 0, 1.
        second_indices : ak.Array
            Jagged array of second leg lepton indices per event, shape (n_events, var).
            Example: [[1, 2, 2]] represents 3 pairs with second legs at indices 1, 2, 2.
            Together with first_indices, this represents pairs: (0,1), (0,2), (1,2).

        Returns
        -------
        ak.Array
            Boolean array of shape (n_events,) indicating whether ANY lepton pair
            in each event passes validation. Returns False for events with no matches.

        Examples
        --------
        Event with 3 electrons at pT = [25, 28, 32] GeV, trigger HLT_2e12 (threshold 27 GeV):

        first_indices  = [[0, 0, 1]]  # 3 possible pairs
        second_indices = [[1, 2, 2]]

        Pairs and validation:
        - (0, 1): pT=(25, 28) GeV, fails (25 < 27)
        - (0, 2): pT=(25, 32) GeV, fails (25 < 27)
        - (1, 2): pT=(28, 32) GeV, passes (28 >= 27)

        Result: Event accepted because at least one pair passes

        """
        is_symmetric = trigger.trigger_info_dct["symmetric"]

        if is_symmetric:
            # symmetric dilepton: same lepton type, same threshold for both legs
            lepton_type = trigger.trigger_info_dct["leptons"][0]

            pt_branch = self._select_pt_branch(lepton_type)
            pt_array = arrays[lepton_type, pt_branch]

            # check threshold for both legs
            if trigger.leg1_id in self.trigger_hierarchy.thresholds_by_id:
                threshold = self.trigger_hierarchy.thresholds_by_id[trigger.leg1_id]

                # get number of leptons per event
                n_leptons = ak.num(pt_array, axis=-1)

                # mask invalid indices: must be >= 0 AND < n_leptons
                first_valid = (first_indices >= 0) & (first_indices < n_leptons)
                second_valid = (second_indices >= 0) & (second_indices < n_leptons)

                # use ak.mask to mark invalid indices as None
                masked_first = ak.mask(first_indices, first_valid)
                masked_second = ak.mask(second_indices, second_valid)

                # get pT values (None indices produce None pT values)
                first_pt = pt_array[masked_first]
                second_pt = pt_array[masked_second]

                # check if pT passes threshold (None values become False)
                first_passes = ak.fill_none(first_pt >= threshold, False)
                second_passes = ak.fill_none(second_pt >= threshold, False)
            else:
                n_leptons = ak.num(pt_array, axis=-1)
                first_passes = (first_indices >= 0) & (first_indices < n_leptons)
                second_passes = (second_indices >= 0) & (second_indices < n_leptons)

            # check that leptons are different (prevent same lepton matching both legs)
            different_leptons = first_indices != second_indices

            # pair passes if both legs pass AND leptons are different
            pair_passes_per_event = first_passes & second_passes & different_leptons

        else:
            # asymmetric dilepton: different thresholds or lepton types
            leptons = trigger.trigger_info_dct["leptons"]

            if len(leptons) == 1:
                raise RuntimeError("Asymmetric dilepton triggers must have two lepton types!")

            first_type = leptons[0]
            second_type = leptons[1]

            # get pT arrays for both lepton types
            first_pt_branch = self._select_pt_branch(first_type)
            first_pt_array = arrays[first_type, first_pt_branch]

            second_pt_branch = self._select_pt_branch(second_type)
            second_pt_array = arrays[second_type, second_pt_branch]

            # validate first leg
            if trigger.leg1_id in self.trigger_hierarchy.thresholds_by_id:
                threshold1 = self.trigger_hierarchy.thresholds_by_id[trigger.leg1_id]

                n_first_leptons = ak.num(first_pt_array, axis=-1)
                first_valid = (first_indices >= 0) & (first_indices < n_first_leptons)

                # use ak.mask to mark invalid indices as None
                masked_first = ak.mask(first_indices, first_valid)
                first_pt = first_pt_array[masked_first]

                # check if pT passes threshold (None values become False)
                first_passes = ak.fill_none(first_pt >= threshold1, False)
            else:
                n_first_leptons = ak.num(first_pt_array, axis=-1)
                first_passes = (first_indices >= 0) & (first_indices < n_first_leptons)

            # validate second leg
            if trigger.leg2_id in self.trigger_hierarchy.thresholds_by_id:
                threshold2 = self.trigger_hierarchy.thresholds_by_id[trigger.leg2_id]

                n_second_leptons = ak.num(second_pt_array, axis=-1)
                second_valid = (second_indices >= 0) & (second_indices < n_second_leptons)

                masked_second = ak.mask(second_indices, second_valid)
                second_pt = second_pt_array[masked_second]

                second_passes = ak.fill_none(second_pt >= threshold2, False)
            else:
                n_second_leptons = ak.num(second_pt_array, axis=-1)
                second_passes = (second_indices >= 0) & (second_indices < n_second_leptons)

            # for mixed-flavor, leptons are from different collections so automatically different
            if first_type == second_type and trigger.trigger_info_dct["leptons"] != ["tau", "tau"]:
                raise RuntimeError(f"Trigger matching not supported for {trigger.name}!")
            else:
                pair_passes_per_event = first_passes & second_passes

        # check if ANY pair in each event passes
        any_pair_passes = ak.any(pair_passes_per_event, axis=-1)

        # handle events with no pairs (empty arrays)
        return ak.fill_none(any_pair_passes, False)

    def _validate_single_lepton_pt_no_matching(self, arrays: GroupArrays, trigger: Trigger) -> ak.Array:
        lepton_type = trigger.trigger_info_dct["leptons"][0]

        pt_branch = self._select_pt_branch(lepton_type)
        pt_array = arrays[lepton_type, pt_branch]

        if trigger.leg1_id in self.trigger_hierarchy.thresholds_by_id:
            threshold = self.trigger_hierarchy.thresholds_by_id[trigger.leg1_id]

            # check if ANY lepton passes threshold
            passes_threshold = pt_array >= threshold
            any_passes = ak.any(passes_threshold, axis=-1)

            return ak.fill_none(any_passes, False)
        else:
            return ak.ones_like(ak.num(pt_array, axis=-1), dtype=bool)

    def _validate_dilepton_pt_no_matching(self, arrays: GroupArrays, trigger: Trigger) -> ak.Array:
        is_symmetric = trigger.trigger_info_dct["symmetric"]

        if is_symmetric:
            lepton_type = trigger.trigger_info_dct["leptons"][0]

            pt_branch = self._select_pt_branch(lepton_type)
            pt_array = arrays[lepton_type, pt_branch]

            if trigger.leg1_id in self.trigger_hierarchy.thresholds_by_id:
                threshold = self.trigger_hierarchy.thresholds_by_id[trigger.leg1_id]

                passes_threshold = pt_array >= threshold
                n_passing = ak.sum(passes_threshold, axis=-1)

                return n_passing >= 2
            else:
                return ak.num(pt_array, axis=-1) >= 2
        else:
            leptons = trigger.trigger_info_dct["leptons"]

            if len(leptons) == 1:
                raise RuntimeError("Asymmetric dilepton triggers must have two lepton types!")

            first_type = leptons[0]
            second_type = leptons[1]

            first_pt_branch = self._select_pt_branch(first_type)
            first_pt_array = arrays[first_type, first_pt_branch]

            second_pt_branch = self._select_pt_branch(second_type)
            second_pt_array = arrays[second_type, second_pt_branch]

            if trigger.leg1_id in self.trigger_hierarchy.thresholds_by_id:
                threshold1 = self.trigger_hierarchy.thresholds_by_id[trigger.leg1_id]
                first_has_passing = ak.any(first_pt_array >= threshold1, axis=-1)
            else:
                first_has_passing = ak.num(first_pt_array, axis=-1) >= 1

            if trigger.leg2_id in self.trigger_hierarchy.thresholds_by_id:
                threshold2 = self.trigger_hierarchy.thresholds_by_id[trigger.leg2_id]
                second_has_passing = ak.any(second_pt_array >= threshold2, axis=-1)
            else:
                second_has_passing = ak.num(second_pt_array, axis=-1) >= 1

            # need at least one lepton passing threshold for each leg
            passes = ak.fill_none(first_has_passing & second_has_passing, False)

            # same-flavor asymmetric (e.g. mu22_mu8noL1): require >= 2 leptons
            # to prevent a single lepton satisfying both thresholds
            if first_type == second_type:
                passes = passes & (ak.num(first_pt_array, axis=-1) >= 2)

            return passes

    def _get_trigger_decision_mask(self, arrays: GroupArrays, trigger: Trigger) -> ak.Array:
        return arrays[trigger.trigger_branches[0]]

    def _get_valid_trigger_mask(self, arrays: GroupArrays, trigger: Trigger) -> ak.Array:
        run_number = arrays["other", "runNumber"]
        run_range = trigger.get_run_range()

        # event-level masks
        run_mask = (run_number >= run_range[0]) & (run_number < run_range[1])
        decision_mask = self._get_trigger_decision_mask(arrays, trigger)
        event_mask = run_mask & decision_mask

        apply_matching = self.trigger_match and trigger.name not in self._disable_matching_triggers

        if self.reports is None:
            raise RuntimeError("TriggerProcessor requires reports to determine run_name for prescale handling!")

        if trigger.prescale and self.reports["run_name"] == 3:
            apply_matching = False

        # apply trigger matching if enabled
        if apply_matching:
            _, first_match_branch, second_match_branch = trigger.trigger_branches

            first_match = arrays[first_match_branch]

            if trigger.trigger_info_dct["dilepton"]:
                second_match = arrays[second_match_branch]

            if trigger.trigger_info_dct["dilepton"]:
                # check if ANY pair passes validation
                validation_mask = self._validate_all_trigger_pairs(arrays, trigger, first_match, second_match)
            else:
                # validate all matched leptons, check if ANY passes
                validation_mask = self._validate_all_single_leptons(arrays, trigger, first_match)
        else:
            # no trigger matching - validate pT thresholds without requiring specific matched indices
            if trigger.trigger_info_dct["dilepton"]:
                validation_mask = self._validate_dilepton_pt_no_matching(arrays, trigger)
            else:
                validation_mask = self._validate_single_lepton_pt_no_matching(arrays, trigger)

        event_mask = event_mask & validation_mask

        return event_mask

    def _get_matching_triggers(self) -> list[Trigger]:
        processor_year = self.sample_info.get("year", None) if self.sample_info is not None else None

        if processor_year is None:
            raise RuntimeError("Sample year information is not available in trigger processor!")

        # find matching triggers for this year
        matching_triggers = []
        for year, triggers in self.triggers_by_year.items():
            if processor_year == year or (processor_year == 1516 and year in {15, 16}):
                matching_triggers.extend(triggers)

        return matching_triggers

    def run_triggers(self, arrays: GroupArrays, return_mask: bool = False) -> GroupArrays | ak.Array:
        """Apply trigger selection by OR-ing all valid triggers for the current year.

        This method:
          1. Identifies triggers matching the sample year
          2. Collects all valid trigger masks (considering pt, run ranges and trigger matching if enabled)
          3. OR-combines masks across triggers
          4. Applies final mask to arrays

        """
        matching_triggers = self._get_matching_triggers()

        if not matching_triggers:
            # no triggers found for this year, return arrays unchanged
            return arrays

        if self.is_data and self.prescale:
            prescales = np.zeros(len(arrays["other", "runNumber"]), dtype=np.float64)
        else:
            prescales = None

        # collect all individual trigger masks organized by lepton type
        trigger_masks: list[ak.Array] = []

        for trigger in matching_triggers:
            event_mask = self._get_valid_trigger_mask(arrays, trigger)

            if trigger.has_pt_requirement:
                leptons = trigger.trigger_info_dct["leptons"]
                if len(leptons) > 1:
                    raise RuntimeError("Only single lepton triggers support pt requirement!")

                pt_branch = self._select_pt_branch(leptons[0])
                pt_array = arrays[leptons[0], pt_branch]

                # accept event if ANY lepton is in range (and matched via event_mask)
                in_pt_range_per_lepton = (pt_array >= trigger.pt_low) & (pt_array < trigger.pt_high)
                any_in_range = ak.any(in_pt_range_per_lepton, axis=-1)

                # combine: event passes trigger AND at least one lepton in pt range
                mask = event_mask & ak.fill_none(any_in_range, False)
            else:
                # no pT requirement, just event-level mask
                mask = event_mask

            if prescales is not None:
                if trigger.prescale_branch is None:
                    raise RuntimeError("Requested prescales, but trigger does not support prescale branches!")

                prescale = ak.to_numpy(arrays[trigger.prescale_branch])
                prescales = np.where(mask, prescale, prescales)

            trigger_masks.append(mask)

        # OR multiple masks
        combined_mask = trigger_masks[0]
        for mask in trigger_masks[1:]:
            combined_mask = combined_mask | mask

        if return_mask:
            return combined_mask

        # apply the final mask
        arrays = arrays[None, combined_mask]

        if prescales is not None:
            arrays["weight_prescale"] = prescales[combined_mask]

        return arrays

    @abstractmethod
    def run(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        pass


class ORTrigger(TriggerProcessor):
    triggers: list[Trigger] = []

    def __init__(
        self,
        name,
        *trigger_processors: TriggerProcessor,
        use_sf: bool = True,
        trigger_match: bool = True,
        prescale: bool = False,
        disable_variations: bool = False,
    ) -> None:
        super().__init__(name, use_sf, trigger_match, prescale, disable_variations)

        for trigger_proc in trigger_processors:
            if not isinstance(trigger_proc, TriggerProcessor):
                raise ValueError("ORTrigger only accepts TriggerProcessor instances!")

            self.triggers.extend(trigger_proc.triggers)

            for branch in trigger_proc.branches:
                self.attach_branch(branch, is_varied=False, overwrite=True)

            for branch in trigger_proc.varied_branches:
                branch = branch.replace("_NOSYS", "")
                self.attach_branch(branch, is_varied=True, overwrite=True)

        self.triggers_by_year = self._group_triggers_by_year()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        arrays = self.run_triggers(arrays)
        return {"arrays": arrays}
