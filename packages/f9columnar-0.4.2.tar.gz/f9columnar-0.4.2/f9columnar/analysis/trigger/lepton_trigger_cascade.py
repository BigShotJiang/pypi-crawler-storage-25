from typing import Any

import awkward as ak
import numpy as np

from f9columnar.analysis.trigger.lepton_triggers import (
    DiLeptonCompleteTrigger,
    DiTauTrigger,
    LeptonTauTrigger,
    SingleLeptonTrigger,
)
from f9columnar.analysis.trigger.trigger_efficiency import TriggerEfficiency
from f9columnar.analysis.trigger.triggers import Trigger, TriggerProcessor
from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor
from f9columnar.variations import vary

TRIGGER_BIN = {
    "SLT": 1,
    "DLT": 2,
    "LTT": 3,
    "DTT": 4,
}


class TriggerCascade(Processor):
    el_pt: str
    mu_pt: str
    tau_pt: str

    def __init__(
        self,
        el_id: str | None = None,
        el_iso: str | None = None,
        mu_reco: str | None = None,
        tau_id: str | None = None,
        use_sf: bool = True,
        use_trig_eff_processor: bool = False,
        triggers: list[str] | None = None,
        prefix: str = "",
    ) -> None:
        """Trigger cascade implementing the strategy: SLT > DLT > LTT > DTT.

        Each event is assigned to exactly one trigger bin based on the highest-priority
        trigger it passes. Trigger scale factors are computed per cascade bin using
        the "simpler approach" — per-leg efficiency SFs multiplied together:

          - SLT: leptonTrigSF(leading trigger-matched lepton)
          - DLT: leg1_SF(leading matched lep) x leg2_SF(subleading matched lep)
          - LTT: lepLegSF(leading matched lep) x tauLegSF(leading matched tau)
          - DTT: tauTrigSF(leading matched tau0) x tauTrigSF(subleading matched tau1)

        Note
        ----
        - Electron SFs use el_effSF_Trig branches directly.
        - Muon SFs are computed as mu_effData_Trig / mu_effMC_Trig.
        - Tau SFs use tau_effSF_Trig branches directly.

        """
        super().__init__(name=f"{prefix}triggerCascade")
        self.use_sf = use_sf
        self.use_trig_eff_processor = use_trig_eff_processor

        self._full_trigger_cascade = ["SLT", "DLT", "LTT", "DTT"]
        self._reversed_full_trigger_cascade = self._full_trigger_cascade[::-1]

        self.trigger_cascade: dict[str, TriggerProcessor | None] = {"SLT": None, "DLT": None, "LTT": None, "DTT": None}
        self.eff_procs: dict[str, TriggerEfficiency] = {}

        if triggers is None:
            triggers = self._full_trigger_cascade

        for t in triggers:
            if t not in self._full_trigger_cascade:
                raise ValueError(f"Invalid trigger '{t}' in cascade! Valid options: {self._full_trigger_cascade}.")

        if "SLT" in triggers:
            slt = SingleLeptonTrigger(
                el_id=el_id,
                el_iso=el_iso,
                mu_reco=mu_reco,
                use_sf=use_sf,
                trigger_match=True,
            )
            self.trigger_cascade["SLT"] = slt

        if "DLT" in triggers:
            dlt = DiLeptonCompleteTrigger(
                el_id=el_id,
                el_iso=el_iso,
                mu_reco=mu_reco,
                use_sf=use_sf,
                trigger_match=True,
            )
            self.trigger_cascade["DLT"] = dlt

        if "LTT" in triggers:
            ltt = LeptonTauTrigger(
                el_id=el_id,
                el_iso=el_iso,
                mu_reco=mu_reco,
                tau_id=tau_id,
                use_sf=use_sf,
                trigger_match=True,
            )
            self.trigger_cascade["LTT"] = ltt

        if "DTT" in triggers:
            dtt = DiTauTrigger(
                tau_id=tau_id,
                use_sf=use_sf,
                trigger_match=True,
            )
            self.trigger_cascade["DTT"] = dtt

        self.n_triggers = len(self.trigger_cascade)

        for trigger in self.trigger_cascade.values():
            if trigger is None:
                continue

            self.attach_branches(trigger.branches, overwrite=True)
            for branch in trigger.varied_branches:
                branch = branch.replace("_NOSYS", "")
                self.attach_branch(branch, is_varied=True, overwrite=True)

        self.attach_branches(
            [
                ("el_pt_NOSYS", "el_pt"),
                ("mu_pt_NOSYS", "mu_pt"),
                ("tau_pt_NOSYS", "tau_pt"),
            ],
            is_varied=True,
            overwrite=True,
        )

        if self.use_trig_eff_processor:
            if self.trigger_cascade["SLT"] is not None:
                self.eff_procs["SLT"] = TriggerEfficiency(self.trigger_cascade["SLT"])

            if self.trigger_cascade["DLT"] is not None:
                self.eff_procs["DLT"] = TriggerEfficiency(self.trigger_cascade["DLT"])

            if self.trigger_cascade["SLT"] is None and self.trigger_cascade["DLT"] is None:
                raise ValueError("Trigger efficiency processor enabled but no SLT or DLT trigger in cascade!")

    def _get_matching_triggers(self, processor: TriggerProcessor) -> list[Trigger]:
        """Get triggers matching the current sample year."""
        processor.sample_info = self.sample_info
        return processor._get_matching_triggers()

    def _get_pt_branch(self, lep: str) -> str:
        if lep == "el":
            return self.el_pt
        elif lep == "mu":
            return self.mu_pt
        elif lep == "tau":
            return self.tau_pt
        else:
            raise ValueError(f"Invalid lepton type: {lep}")

    def _leading_pt_match(self, arrays: GroupArrays, lep: str, indices: ak.Array) -> ak.Array:
        """Select the highest-pT matched lepton from a jagged index array.

        Parameters
        ----------
        arrays : GroupArrays
            Event data arrays.
        lep : str
            Lepton type ("el", "mu", or "tau").
        indices : ak.Array
            Jagged array of matched lepton indices per event.

        Returns
        -------
        ak.Array
            Per-event index of the highest-pT matched lepton (or None).
        """
        lep_pt = arrays[lep, self._get_pt_branch(lep)]
        n_leptons = ak.num(lep_pt, axis=-1)

        valid = (indices >= 0) & (indices < n_leptons)

        masked = ak.mask(indices, valid)
        candidate_pt = lep_pt[masked]

        # fill None pT with -inf so argmax ignores invalid candidates
        candidate_pt = ak.fill_none(candidate_pt, -np.inf)
        best = ak.argmax(candidate_pt, axis=1, keepdims=True)

        return ak.firsts(masked[best])

    def _leading_subleading_pair(
        self,
        arrays: GroupArrays,
        lep: str,
        first_indices: ak.Array,
        second_indices: ak.Array,
    ) -> tuple[ak.Array, ak.Array]:
        """Select the matched pair where leg 1 is leading and leg 2 is subleading.

        For same-flavor dilepton triggers (e.g. tau-tau), the pairs are correlated
        since both legs index into the same collection. We pick the pair where
        leg 1 has the highest pT (leading), keeping the corresponding leg 2 (subleading).

        Parameters
        ----------
        arrays : GroupArrays
            Event data arrays.
        lep : str
            Lepton type (same for both legs).
        first_indices, second_indices : ak.Array
            Jagged arrays of matched lepton indices for leg 1 and leg 2.

        Returns
        -------
        tuple[ak.Array, ak.Array]
            Per-event (leading_idx, subleading_idx), or (None, None).
        """
        lep_pt = arrays[lep, self._get_pt_branch(lep)]
        n_leptons = ak.num(lep_pt, axis=-1)

        valid = (
            (first_indices >= 0) & (first_indices < n_leptons) & (second_indices >= 0) & (second_indices < n_leptons)
        )

        masked_first = ak.mask(first_indices, valid)
        masked_second = ak.mask(second_indices, valid)

        leg1_pt = ak.fill_none(lep_pt[masked_first], -np.inf)
        best = ak.argmax(leg1_pt, axis=1, keepdims=True)

        return ak.firsts(masked_first[best]), ak.firsts(masked_second[best])

    @staticmethod
    def _sf_at_index(sf_arr: ak.Array, matched_idx: ak.Array) -> np.ndarray:
        """Extract SF value at a per-event index from a jagged lepton array.

        Parameters
        ----------
        sf_arr : ak.Array
            Per-lepton SF values, shape (n_events, var_n_leptons).
        matched_idx : ak.Array
            Per-event matched lepton index (int or None).

        Returns
        -------
        np.ndarray
            Per-event SF values. 1.0 for events with no valid match.
        """
        n_events = len(sf_arr)
        valid = ~ak.is_none(matched_idx)
        safe_idx = ak.to_numpy(ak.fill_none(matched_idx, 0)).astype(int)

        max_n = int(ak.max(ak.num(sf_arr)))
        if max_n == 0:
            return np.ones(n_events)

        regular = ak.to_numpy(ak.fill_none(ak.pad_none(sf_arr, max_n, clip=True), 1.0))
        safe_idx = np.clip(safe_idx, 0, max_n - 1)

        result = regular[np.arange(n_events), safe_idx]
        result[~ak.to_numpy(valid)] = 1.0

        result[result < 0.0] = 1.0
        return result

    def _leg_trigger_sf(
        self,
        arrays: GroupArrays,
        trigger: Trigger,
        leg_n: int,
        lep: str,
        matched_idx: ak.Array,
    ) -> np.ndarray:
        """Compute per-event trigger SF for one leg of a trigger.

        Parameters
        ----------
        arrays : GroupArrays
            Event data arrays.
        trigger : Trigger
            The trigger object containing efficiency branch info.
        leg_n : int
            Leg number (1 or 2).
        lep : str
            Lepton type: "el", "mu", or "tau".
        matched_idx : ak.Array
            Per-event index of the trigger-matched lepton (int or None).

        Returns
        -------
        np.ndarray
            Per-event SF values. Returns 1.0 for events without a match.
        """

        is_dilepton = trigger.trigger_info_dct["dilepton"]
        use_eff_sf = trigger.leg1_use_eff_sf if leg_n == 1 else trigger.leg2_use_eff_sf

        if is_dilepton:
            data_branch = trigger.get_di_trigger_eff("data")[leg_n - 1]
        else:
            data_branch = trigger.get_single_trigger_eff("data")

        data_val = self._sf_at_index(arrays[lep, getattr(self, data_branch)], matched_idx)

        if use_eff_sf:
            return data_val

        # mu_effData / mu_effMC
        if is_dilepton:
            mc_branch = trigger.get_di_trigger_eff("mc")[leg_n - 1]
        else:
            mc_branch = trigger.get_single_trigger_eff("mc")

        mc_val = self._sf_at_index(arrays[lep, getattr(self, mc_branch)], matched_idx)

        return np.where(mc_val != 0, data_val / mc_val, 1.0)

    def _trigger_sf_for_event(
        self,
        arrays: GroupArrays,
        trigger: Trigger,
        run_numbers: np.ndarray,
        processor: TriggerProcessor,
    ) -> np.ndarray:
        """Compute per-event trigger SF for a single trigger path.

        Returns the per-leg product SF for events that pass this trigger
        (within its run range), and 0.0 otherwise — so that 1 - prod(1 - SF_i)
        correctly OR-combines multiple triggers.

        """
        low, high = trigger.get_run_range()
        passed = ak.to_numpy(arrays[trigger.trigger_branches[0]])
        event_mask = passed & (run_numbers >= low) & (run_numbers <= high)

        if not np.any(event_mask):
            return np.zeros(len(run_numbers))

        sub = arrays[None, event_mask]
        leptons = trigger.trigger_info_dct["leptons"]
        is_dilepton = trigger.trigger_info_dct["dilepton"]

        matching_disabled = trigger.name in processor._disable_matching_triggers

        if is_dilepton:
            _, first_match_branch, second_match_branch = trigger.trigger_branches

            if matching_disabled and leptons[0] == leptons[1]:
                # matching disabled: use pT-ordered leading/subleading
                lep_pt = sub[leptons[0], self._get_pt_branch(leptons[0])]
                n_lep = ak.num(lep_pt, axis=-1)
                has_match = n_lep >= 2

                first_idx = ak.mask(ak.zeros_like(n_lep, dtype=np.int64), has_match)
                second_idx = ak.mask(ak.ones_like(n_lep, dtype=np.int64), has_match)
            elif leptons[0] == leptons[1]:
                first_idx, second_idx = self._leading_subleading_pair(
                    sub, leptons[0], sub[first_match_branch], sub[second_match_branch]
                )
                has_match = ~ak.is_none(first_idx) & ~ak.is_none(second_idx)
            else:
                first_idx = self._leading_pt_match(sub, leptons[0], sub[first_match_branch])
                second_idx = self._leading_pt_match(sub, leptons[1], sub[second_match_branch])
                has_match = ~ak.is_none(first_idx) & ~ak.is_none(second_idx)

            sf1 = self._leg_trigger_sf(sub, trigger, leg_n=1, lep=leptons[0], matched_idx=first_idx)
            sf2 = self._leg_trigger_sf(sub, trigger, leg_n=2, lep=leptons[1], matched_idx=second_idx)

            sub_sf = np.where(ak.to_numpy(has_match), sf1 * sf2, 0.0)
        else:
            lep = leptons[0]
            _, match_branch, _ = trigger.trigger_branches

            matched_mask = sub[match_branch]
            lep_pt = sub[lep, self._get_pt_branch(lep)]

            masked_pt = ak.where(matched_mask, lep_pt, -np.inf)
            leading_matched_idx = ak.argmax(masked_pt, axis=1)

            has_match = ak.any(matched_mask, axis=1)

            sub_sf = self._leg_trigger_sf(sub, trigger, leg_n=1, lep=lep, matched_idx=leading_matched_idx)
            sub_sf = np.where(ak.to_numpy(has_match), sub_sf, 0.0)

        result = np.zeros(len(run_numbers))
        result[event_mask] = sub_sf

        return result

    def _apply_cascade_bin_sf(
        self,
        arrays: GroupArrays,
        run_numbers: np.ndarray,
        trigger_bins: np.ndarray,
        trigger_sf: np.ndarray,
        trigger_bin: int,
        processor: TriggerProcessor,
    ) -> None:
        """Compute OR-combined trigger SF for one cascade bin.

        For each trigger path in the bin, compute per-event leg SF product,
        then combine with: SF = 1 - prod(1 - SF_i).

        Triggers sharing the same SF branch names (leg1_eff, leg2_eff) use
        pre-computed OR SFs — only the first passing trigger per unique SF
        key contributes to avoid double-counting.

        Triggers with the same SF key use pre-computed OR SFs and produce
        identical SF values — take the per-event max across them (picks
        whichever trigger actually fires for each event).

        """
        bin_mask = trigger_bins == trigger_bin
        if not np.any(bin_mask):
            return None

        is_dilepton = trigger_bin != TRIGGER_BIN["SLT"]

        # OR-combine: 1 - prod(1 - SF_i), deduplicating by SF branch key.
        n = len(trigger_sf)
        sf_by_key: dict[tuple[str | None, str | None, tuple[int, int]], np.ndarray] = {}

        for t in self._get_matching_triggers(processor):
            if t.leg1_eff is None:
                continue

            if is_dilepton and t.leg2_eff is None:
                continue

            sf_key = (t.leg1_eff, t.leg2_eff, t.get_run_range())
            sf_i = self._trigger_sf_for_event(arrays, t, run_numbers, processor)

            if sf_key in sf_by_key:
                np.maximum(sf_by_key[sf_key], sf_i, out=sf_by_key[sf_key])
            else:
                sf_by_key[sf_key] = sf_i

        prod = np.ones(n)
        for sf_i in sf_by_key.values():
            prod *= 1.0 - sf_i

        combined_sf = 1.0 - prod
        has_sf = bin_mask & (combined_sf != 0.0)
        trigger_sf[has_sf] = combined_sf[has_sf]

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, Any]:
        n_events = len(arrays["other", "runNumber"])
        trigger_bins = np.zeros(n_events, dtype=np.uint8)

        # iterate in reverse priority (DTT first, SLT last) so higher-priority
        # triggers overwrite lower-priority ones in trigger_bins
        for i, trigger_key in enumerate(self._reversed_full_trigger_cascade):
            trigger = self.trigger_cascade[trigger_key]
            if trigger is None:
                continue

            trigger.reports, trigger.sample_info = self.reports, self.sample_info
            trigger_mask: ak.Array = trigger.run_triggers(arrays, return_mask=True)

            trigger_bins[trigger_mask] = self.n_triggers - i

        combined_mask = trigger_bins > 0

        arrays = arrays[None, combined_mask]
        trigger_bins = trigger_bins[combined_mask]

        trigger_sf = np.ones(len(trigger_bins), dtype=np.float64)

        if self.use_sf and not self.is_data:
            run_numbers = ak.to_numpy(arrays["other", "runNumber"])

            if self.use_trig_eff_processor:
                for trigger_key, eff_proc in self.eff_procs.items():
                    eff_proc.reports = self.reports

                    trigger_mask = trigger_bins == TRIGGER_BIN[trigger_key]

                    eff = eff_proc._run_calculate_eff_sf(arrays[None, trigger_mask], self.trigger_cascade[trigger_key])
                    trigger_sf[trigger_mask] = ak.to_numpy(eff)

            for trigger_key, trigger in self.trigger_cascade.items():
                if trigger is None:
                    continue

                has_eff_proc = self.eff_procs.get(trigger_key, None)
                if has_eff_proc is not None:
                    continue

                self._apply_cascade_bin_sf(
                    arrays,
                    run_numbers,
                    trigger_bins,
                    trigger_sf,
                    TRIGGER_BIN[trigger_key],
                    trigger,
                )

        arrays["total_weight"] = arrays["total_weight"] * trigger_sf  # type: ignore[operator]

        return {"arrays": arrays}
