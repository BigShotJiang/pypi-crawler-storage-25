import awkward as ak
import numba as nb
import numpy as np

from f9columnar.analysis.trigger.trigger_hierarchy import construct_trigger_hierarchies
from f9columnar.analysis.trigger.trigger_lookup import TriggerLookup
from f9columnar.analysis.trigger.triggers import Trigger, TriggerProcessor
from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor
from f9columnar.variations import vary


@nb.njit
def _calc_symmetric_flat(effs: np.ndarray, offsets: np.ndarray, out: np.ndarray) -> None:
    n_events = len(offsets) - 1

    for i in range(n_events):
        start = offsets[i]
        stop = offsets[i + 1]
        n = stop - start

        if n < 2:
            out[i] = 0.0
            continue

        p = 0.0
        s = 1.0

        for j in range(start, stop):
            eff = effs[j]
            p = (1.0 - eff) * p + eff * (1.0 - s)
            s *= 1.0 - eff

        out[i] = p


@nb.njit
def _calc_asymmetric_flat(effs1: np.ndarray, effs2: np.ndarray, offsets: np.ndarray, out: np.ndarray) -> None:
    n_events = len(offsets) - 1

    for i in range(n_events):
        start = offsets[i]
        stop = offsets[i + 1]
        n = stop - start

        if n < 2:
            out[i] = 0.0
            continue

        p = 0.0
        s_tau = 1.0
        s_lam = 1.0

        for j in range(start, stop):
            e_tau = effs1[j]
            e_lam = effs2[j]

            p_s_tau = 1.0 - s_tau
            p_s_lam = 1.0 - s_lam

            p = (1.0 - e_lam) * p + (e_lam - e_tau) * p_s_tau + e_tau * p_s_lam

            s_tau *= 1.0 - e_tau
            s_lam *= 1.0 - e_lam

        out[i] = p


class TriggerEfficiencyCalculator:
    """Calculate trigger efficiencies for various trigger configurations.

    Provides methods for computing trigger efficiencies for single and dilepton
    triggers, including symmetric, asymmetric, and mixed-flavor configurations.
    Implements ATLAS trigger efficiency formulas with proper handling of
    correlations and overlap corrections.

    Methods
    -------
    single_lepton_trigger
        Compute efficiency for single lepton triggers (Formula 1).
    mixed_single_lepton_triggers
        Combine electron and muon single triggers (Formula 2).
    emu_dilepton_trigger
        Compute e-mu dilepton trigger efficiency (Formula 5).
    symmetric_dilepton_trigger
        Compute symmetric dilepton trigger efficiency (Formula 6).
    asymmetric_dilepton_trigger
        Compute asymmetric dilepton trigger efficiency (Formula 7).
    e_mu_dilepton_corrected
        Apply correction term when adding e-mu triggers to same-flavor triggers.
    sym_asym_dilepton_corrected
        Combine symmetric and asymmetric triggers with overlap correction.
    compute_scale_factor
        Calculate trigger scale factor (data/MC).
    or_triggers
        Combine multiple trigger efficiencies with logical OR.

    References
    ----------
    .. [1] https://twiki.cern.ch/twiki/bin/viewauth/Atlas/TrigGlobalEfficiencyCorrectionTool
    .. [2] https://gitlab.cern.ch/atlas/athena/-/tree/main/Trigger/TrigAnalysis/TrigGlobalEfficiencyCorrection

    """

    @staticmethod
    def single_lepton_trigger(eff: ak.Array) -> ak.Array:
        """Formula (1): One e/mu trigger, n leptons

        P(T_n) = 1 - prod(1 - P(l_k))

        """
        prod_fail = ak.prod(1 - eff, axis=-1)
        return 1 - prod_fail

    @staticmethod
    def mixed_single_lepton_triggers(eff_e: ak.Array, eff_mu: ak.Array) -> ak.Array:
        """Formula (2): One e + one mu trigger, n_e + n_mu leptons

        P(T) = 1 - prod(1-P(e_k)) x prod(1-P(mu_k))

        """
        prod_fail_e = ak.prod(1 - eff_e, axis=-1)
        prod_fail_mu = ak.prod(1 - eff_mu, axis=-1)
        return 1 - prod_fail_e * prod_fail_mu

    def emu_dilepton_trigger(self, eff_e: ak.Array, eff_mu: ak.Array) -> ak.Array:
        """Formula (5): One emu trigger, n_e + n_mu leptons

        P(T) = (1 - prod(1-P(e_k))) x (1 - prod(1-P(mu_k)))

        """
        p_e = self.single_lepton_trigger(eff_e)
        p_mu = self.single_lepton_trigger(eff_mu)

        return p_e * p_mu

    @staticmethod
    def symmetric_dilepton_trigger(eff: ak.Array) -> ak.Array:
        """Formula (6): One symmetric ee/mu trigger, n leptons

        Uses recursive formula with induction:
        P(T_n) = (1-P(l_n))P(T_{n-1}) + P(l_n)(1 - prod(1-P(l_k)))

        Implementation follows the C++ tool pattern:
        p[k] = (1-e[k])*p[k-1] + e[k]*(1-s[k-1])
        s[k] = s[k-1] * (1-e[k])

        """
        eff = ak.fill_none(eff, 0.0)

        layout = ak.to_layout(eff)
        content = ak.to_numpy(layout.content, allow_missing=False)
        offsets = ak.to_numpy(layout.offsets)

        out = np.empty(len(offsets) - 1, dtype=np.float64)
        _calc_symmetric_flat(content, offsets, out)

        return ak.Array(out)

    @staticmethod
    def asymmetric_dilepton_trigger(eff_leg1: ak.Array, eff_leg2: ak.Array) -> ak.Array:
        """Formula (7): One asymmetric l trigger (e.g., mu18_mu8noL1), n leptons

        P(T_n) = (1-P(l_n^lam))P(T_{n-1})
                 + (P(l_n^lam)-P(l_n^tau)) [1 - prod_{k<n}(1-P(l_k^tau))]
                 + P(l_n^tau) [1 - prod_{k<n}(1-P(l_k^lam))]

        """
        eff_leg1 = ak.fill_none(eff_leg1, 0.0)
        eff_leg2 = ak.fill_none(eff_leg2, 0.0)

        layout1 = ak.to_layout(eff_leg1)
        layout2 = ak.to_layout(eff_leg2)

        effs1 = ak.to_numpy(layout1.content, allow_missing=False)
        effs2 = ak.to_numpy(layout2.content, allow_missing=False)
        offsets = ak.to_numpy(layout1.offsets)

        out = np.empty(len(offsets) - 1, dtype=np.float64)
        _calc_asymmetric_flat(effs1, effs2, offsets, out)

        return ak.Array(out)

    def e_mu_dilepton_corrected(
        self,
        term1: ak.Array,
        eff_e_leg: ak.Array,
        eff_mu_leg: ak.Array,
        P_ee: ak.Array | None = None,
        P_mumu: ak.Array | None = None,
    ) -> ak.Array:
        """Correction term for adding e-mu trigger to existing ee and/or mumu triggers.

        P(T) = 1 - (1-P(ee))(1-P(mumu)) + [P(ee U e_emu) - P(ee)] x [P(mumu U mu_emu) - P(mumu)]
             = term1 + term2

        The second term is the "bonus" from the emu trigger.

        Where:
          - P(ee U e_emu) = probability that ee triggers OR electrons fire emu's e-leg
          - P(mumu U mu_emu) = probability that mumu triggers OR muons fire emu's mu-leg

        """
        # P(e_emu): probability that any electron fires the emu e-leg
        P_e_emu = self.single_lepton_trigger(eff_e_leg)

        # P(mu_emu): probability that any muon fires the emu mu-leg
        P_mu_emu = self.single_lepton_trigger(eff_mu_leg)

        # P(ee U e_emu): ee triggers OR electrons fire emu e-leg
        if P_ee is not None:
            P_ee_or_e_emu = self.or_triggers(P_ee, P_e_emu)
        else:
            P_ee_or_e_emu = None

        # P(mumu U mu_emu): mumu triggers OR muons fire emu mu-leg
        if P_mumu is not None:
            P_mumu_or_mu_emu = self.or_triggers(P_mumu, P_mu_emu)
        else:
            P_mumu_or_mu_emu = None

        # term 2: bonus from emu trigger
        # only adds contribution when emu extends reach beyond existing triggers
        if P_ee_or_e_emu is not None and P_mumu_or_mu_emu is not None:
            # both ee and mumu exist: full correction term
            term2 = (P_ee_or_e_emu - P_ee) * (P_mumu_or_mu_emu - P_mumu)
        elif P_ee_or_e_emu is not None:
            # only ee exists, no mumu: emu extends ee e-coverage and adds mu-coverage
            term2 = (P_ee_or_e_emu - P_ee) * P_mu_emu
        elif P_mumu_or_mu_emu is not None:
            # only mumu exists, no ee: emu adds e-coverage and extends mumu mu-coverage
            term2 = P_e_emu * (P_mumu_or_mu_emu - P_mumu)
        else:
            raise RuntimeError("At least one of P_ee or P_mumu must be provided for e-mu correction!")

        # should be added to the overall base efficiency from ee OR mumu (term1)
        return term1 + term2

    def sym_asym_dilepton_corrected(
        self,
        eff_sym: ak.Array,
        eff_asym_tight: ak.Array,
        eff_asym_loose: ak.Array,
    ) -> ak.Array:
        """Combine symmetric + asymmetric triggers with correction for double-counting.

        Formula: P(sym OR asym) = P(sym) + P(asym) - P(sym AND asym)

        """
        P_sym = self.symmetric_dilepton_trigger(eff_sym)
        P_asym = self.asymmetric_dilepton_trigger(eff_asym_tight, eff_asym_loose)

        # calculate overlap (what gets double-counted)
        P_overlap = self.asymmetric_dilepton_trigger(eff_asym_tight, eff_sym)

        # apply inclusion-exclusion: A or B = A + B - A and B
        return P_sym + P_asym - P_overlap

    @staticmethod
    def compute_scale_factor(eff_data_trigger: ak.Array, eff_mc_trigger: ak.Array) -> ak.Array:
        """Compute the overall trigger scale factor: SF = eff_data / eff_mc."""
        # silence division by zero
        with np.errstate(divide="ignore", invalid="ignore"):
            sf = eff_data_trigger / eff_mc_trigger

        # replace nan with 0.0
        sf = ak.nan_to_num(sf, nan=0.0, posinf=0.0)

        return sf

    @staticmethod
    def or_triggers(*ps: ak.Array) -> ak.Array:
        """Combine trigger efficiencies with logical OR."""
        prod = ak.ones_like(ps[0])
        for p in ps:
            prod = prod * (1.0 - p)
        return 1.0 - prod


class TriggerEfficiency(Processor):
    def __init__(
        self,
        trigger_processor: Processor,
        allow_zero_sf: bool = True,
        save_weights: bool = False,
        prefix: str = "",
    ) -> None:
        super().__init__(name=f"{prefix}triggerEfficiency")
        self.allow_zero_sf = allow_zero_sf
        self.save_weights = save_weights
        self.trigger_processor_name = trigger_processor.name

        for branch in trigger_processor.branches:
            if "trigMatched" in branch or "trigPassed" in branch:
                continue
            self.attach_branch(branch, is_varied=False, overwrite=True)

        for branch in trigger_processor.varied_branches:
            branch = branch.replace("_NOSYS", "")
            self.attach_branch(branch, is_varied=True, overwrite=True)

        self.calculator = TriggerEfficiencyCalculator()
        trigger_lookup = TriggerLookup()
        self.hierarchy = construct_trigger_hierarchies(trigger_lookup)

        self._lepton_grouped_triggers: dict[tuple[int, int], dict[str, list[Trigger]]] | None = None

        self._branch_cache: dict[str, str] = {}

        if self.save_weights:
            self.attach_branch(("weight_trigger_NOSYS", "weight_trigger"), is_varied=True, is_created=True)

    def _get_branch_cached(self, branch_name: str) -> str:
        if branch_name not in self._branch_cache:
            self._branch_cache[branch_name] = getattr(self, branch_name)
        return self._branch_cache[branch_name]

    def _group_triggers_by_lepton(self, triggers: list[Trigger]) -> dict[tuple[int, int], dict[str, list[Trigger]]]:
        allowed = {"el", "mu", "el_el_sym", "mu_mu_sym", "el_el_asym", "mu_mu_asym", "el_mu_asym"}
        grouped: dict[str, list[Trigger]] = {}

        for trigger in triggers:
            leptons = trigger.trigger_info_dct["leptons"]
            key = "_".join(leptons)

            if trigger.trigger_info_dct["dilepton"]:
                if trigger.trigger_info_dct["symmetric"]:
                    key += "_sym"
                else:
                    key += "_asym"

            if key not in allowed:
                raise KeyError(f"Trigger lepton group '{key}' is not supported!")

            if key not in grouped:
                grouped[key] = []

            grouped[key].append(trigger)

        # validate that only single lepton triggers OR only dilepton triggers are present
        # the code does not support mixing both types
        has_single_lepton, has_dilepton = False, False
        for key, triggers in grouped.items():
            if key in {"el", "mu"}:
                has_single_lepton = True
            else:
                has_dilepton = True

        if has_single_lepton and has_dilepton:
            raise ValueError("Mixed single and dilepton triggers found in grouped triggers!")

        # group together run ranges
        run_ranges = set()
        for key, triggers in grouped.items():
            for trigger in triggers:
                run_range = trigger.get_run_range()
                run_ranges.add(run_range[0])
                run_ranges.add(run_range[1])

        run_ranges_sorted = sorted(run_ranges)

        # build run range grouped triggers
        run_range_grouped: dict[tuple[int, int], dict[str, list[Trigger]]] = {}
        for i in range(len(run_ranges_sorted) - 1):
            run_start, run_end = run_ranges_sorted[i], run_ranges_sorted[i + 1]

            for key, triggers in grouped.items():
                for trigger in triggers:
                    trigger_run_range = trigger.get_run_range()
                    if trigger_run_range[0] <= run_start and trigger_run_range[1] >= run_end:
                        range_key = (run_start, run_end)
                        if range_key not in run_range_grouped:
                            run_range_grouped[range_key] = {k: [] for k in allowed}

                        run_range_grouped[range_key][key].append(trigger)

        return run_range_grouped

    @property
    def lepton_grouped_triggers(self) -> dict[tuple[int, int], dict[str, list[Trigger]]]:
        if self._lepton_grouped_triggers is None:
            raise RuntimeError("Lepton grouped triggers have not been initialized yet!")

        return self._lepton_grouped_triggers

    def _get_trigger_processor(self) -> TriggerProcessor:
        trigger_proc = self.previous_processors.get(self.trigger_processor_name, None)

        if trigger_proc is None:
            raise RuntimeError(
                f"Trigger processor '{self.trigger_processor_name}' not found in "
                f"previous processors! Available: {list(self.previous_processors.keys())}."
            )

        if not isinstance(trigger_proc, TriggerProcessor):
            raise RuntimeError(
                f"Processor '{self.trigger_processor_name}' is not a TriggerProcessor! Got type: {type(trigger_proc)}."
            )

        return trigger_proc

    def _get_matching_triggers(self, trigger_proc: TriggerProcessor) -> list[Trigger]:
        processor_year = trigger_proc.sample_info.get("year", None) if trigger_proc.sample_info is not None else None

        if processor_year is None:
            raise RuntimeError("Sample year information is not available in trigger processor!")

        matching_triggers = []
        for year, triggers in trigger_proc.triggers_by_year.items():
            if processor_year == year or (processor_year == 1516 and year in {15, 16}):
                matching_triggers.extend(triggers)

        return matching_triggers

    @staticmethod
    def _to_valid_eff(eff: ak.Array) -> ak.Array:
        mask_invalid = eff == -1.0
        eff = ak.where(mask_invalid, 0.0, eff)
        return eff

    def _select_pt_branch(self, lep: str) -> str:
        if lep == "el" and hasattr(self, "el_pt"):
            return self.el_pt
        elif lep == "mu" and hasattr(self, "mu_pt"):
            return self.mu_pt
        elif lep == "tau" and hasattr(self, "tau_pt"):
            return self.tau_pt
        else:
            raise RuntimeError("Invalid configuration for selecting pt branch!")

    def _get_lepton_efficiencies(
        self,
        arrays: GroupArrays,
        trigger: Trigger,
        valid_mask: ak.Array,
        eff_type: str = "data",
    ) -> dict[str, ak.Array]:
        """Extract per-lepton trigger efficiencies for a specific trigger."""
        leptons = trigger.trigger_info_dct["leptons"]
        is_dilepton = trigger.trigger_info_dct["dilepton"]

        lepton_effs: dict[str, ak.Array] = {}

        leg1_sf: ak.Array
        leg2_sf: ak.Array

        eff_sf: ak.Array

        leg1_eff_data: ak.Array
        leg2_eff_data: ak.Array

        if is_dilepton:
            if len(leptons) == 1:
                leptons = [leptons[0], leptons[0]]  # symmetric dilepton

            if trigger.leg1_use_eff_sf and not trigger.leg2_use_eff_sf and eff_type == "data":
                leg1_branch_sf, leg2_branch_data = trigger.get_di_trigger_eff(eff_type="data")  # actually SF branch
                leg1_branch_mc, _ = trigger.get_di_trigger_eff(eff_type="mc")

                leg1_sf = arrays[leptons[0], self._get_branch_cached(leg1_branch_sf)][valid_mask]
                leg2_eff_data = arrays[leptons[1], self._get_branch_cached(leg2_branch_data)][valid_mask]

                leg1_eff_mc = arrays[leptons[0], self._get_branch_cached(leg1_branch_mc)][valid_mask]

                lepton_effs[f"{leptons[0]}_leg1"] = leg1_sf * leg1_eff_mc
                lepton_effs[f"{leptons[1]}_leg2"] = leg2_eff_data

            elif not trigger.leg1_use_eff_sf and trigger.leg2_use_eff_sf and eff_type == "data":
                leg1_branch_data, leg2_branch_sf = trigger.get_di_trigger_eff(eff_type="data")  # actually SF branch
                _, leg2_branch_mc = trigger.get_di_trigger_eff(eff_type="mc")

                leg1_eff_data = arrays[leptons[0], self._get_branch_cached(leg1_branch_data)][valid_mask]
                leg2_sf = arrays[leptons[1], self._get_branch_cached(leg2_branch_sf)][valid_mask]

                leg2_eff_mc = arrays[leptons[1], self._get_branch_cached(leg2_branch_mc)][valid_mask]

                lepton_effs[f"{leptons[0]}_leg1"] = leg1_eff_data
                lepton_effs[f"{leptons[1]}_leg2"] = leg2_sf * leg2_eff_mc

            elif trigger.leg1_use_eff_sf and trigger.leg2_use_eff_sf and eff_type == "data":
                leg1_branch_sf, leg2_branch_sf = trigger.get_di_trigger_eff(eff_type="data")  # actually SF branch
                leg1_branch_mc, leg2_branch_mc = trigger.get_di_trigger_eff(eff_type="mc")

                leg1_sf = arrays[leptons[0], self._get_branch_cached(leg1_branch_sf)][valid_mask]
                leg2_sf = arrays[leptons[1], self._get_branch_cached(leg2_branch_sf)][valid_mask]

                leg1_eff_mc = arrays[leptons[0], self._get_branch_cached(leg1_branch_mc)][valid_mask]
                leg2_eff_mc = arrays[leptons[1], self._get_branch_cached(leg2_branch_mc)][valid_mask]

                lepton_effs[f"{leptons[0]}_leg1"] = leg1_sf * leg1_eff_mc
                lepton_effs[f"{leptons[1]}_leg2"] = leg2_sf * leg2_eff_mc

            else:
                leg1_branch, leg2_branch = trigger.get_di_trigger_eff(eff_type=eff_type)

                leg1_eff = arrays[leptons[0], self._get_branch_cached(leg1_branch)][valid_mask]
                leg2_eff = arrays[leptons[1], self._get_branch_cached(leg2_branch)][valid_mask]

                lepton_effs[f"{leptons[0]}_leg1"] = leg1_eff
                lepton_effs[f"{leptons[1]}_leg2"] = leg2_eff
        else:
            # single lepton leg efficiency
            if trigger.leg1_use_eff_sf and eff_type == "data":
                eff_branch_sf = trigger.get_single_trigger_eff(eff_type="data")  # actually SF branch
                eff_branch_mc = trigger.get_single_trigger_eff(eff_type="mc")

                eff_sf = arrays[leptons[0], self._get_branch_cached(eff_branch_sf)][valid_mask]
                eff_mc = arrays[leptons[0], self._get_branch_cached(eff_branch_mc)][valid_mask]

                lepton_effs[leptons[0]] = eff_sf * eff_mc
            else:
                eff_branch = trigger.get_single_trigger_eff(eff_type=eff_type)

                eff = arrays[leptons[0], self._get_branch_cached(eff_branch)][valid_mask]
                lepton_effs[leptons[0]] = eff

        return lepton_effs

    def _calculate_combined_efficiencies(
        self,
        arrays: GroupArrays,
        lepton_grouped_triggers: dict[str, list[Trigger]],
        valid_mask: ak.Array,
        eff_type: str = "data",
    ) -> ak.Array:
        """Calculate combined trigger efficiencies for each lepton group.

        Algorithm:
          1. For each trigger group, use hierarchy to select optimal leg(s) based on lepton pt
          2. Build efficiency arrays using selected legs (creates "effective trigger")
          3. Apply appropriate formula to compute probability
          4. Combine groups using corrections to avoid double-counting (if needed)

        Key physics points:
          - Always select loosest/tightest leg that lepton can fire (maximizes efficiency)
          - Symmetric + asymmetric: use sym_asym_dilepton_corrected (handles overlap)
          - e-mu + same-flavor: use e_mu_dilepton_corrected (bonus from mixed trigger)
          - Electron and muon triggers are independent: OR them

        """
        # store computed efficiencies for each category
        P_el = None
        P_mu = None
        P_el_el_sym = None
        P_el_el_asym = None
        P_mu_mu_sym = None
        P_mu_mu_asym = None

        # store raw efficiencies needed for corrections
        el_sym_eff = None
        el_asym_tight_eff = None
        el_asym_loose_eff = None
        mu_sym_eff = None
        mu_asym_tight_eff = None
        mu_asym_loose_eff = None

        # store e-mu leg efficiencies for correction term
        emu_el_leg_eff = None
        emu_mu_leg_eff = None

        # process each lepton group
        for group_key, triggers in lepton_grouped_triggers.items():
            if len(triggers) == 0:
                continue

            lep_type = group_key.split("_")[0]  # "el" or "mu"

            if group_key == "el" or group_key == "mu":
                # single lepton triggers - formula (1)
                # when multiple triggers exist, we want the loosest leg each lepton can fire
                # this maximizes efficiency according to formula (3)
                legs = [t.leg1_name for t in triggers]
                pt = arrays[lep_type, self._select_pt_branch(lep_type)]

                # apply valid mask for run range
                pt = pt[valid_mask]

                # select loosest leg for each event based on pT (returns integer IDs for awkward arrays)
                loosest_leg = self.hierarchy.select_leg(pt, legs, select_loosest=True)

                # build efficiency array using selected legs (use integer IDs for fast comparison)
                h_effs = ak.zeros_like(pt, dtype=np.float64)
                for trigger in triggers:
                    mask_leg = loosest_leg == trigger.leg1_id
                    lepton_effs = self._get_lepton_efficiencies(arrays, trigger, valid_mask, eff_type=eff_type)
                    h_effs = ak.where(mask_leg, lepton_effs[lep_type], h_effs)

                h_effs = self._to_valid_eff(h_effs)

                result = self.calculator.single_lepton_trigger(h_effs)
                if group_key == "el":
                    P_el = result
                else:
                    P_mu = result

            elif group_key == "el_el_sym" or group_key == "mu_mu_sym":
                # symmetric dilepton triggers - formula (6)
                legs = [t.leg1_name for t in triggers]
                pt = arrays[lep_type, self._select_pt_branch(lep_type)]

                # apply valid mask for run range
                pt = pt[valid_mask]

                # select loosest leg for each event (returns integer IDs for awkward arrays)
                loosest_leg = self.hierarchy.select_leg(pt, legs, select_loosest=True)

                # build efficiency array using integer IDs for fast comparison
                h_effs = ak.zeros_like(pt, dtype=np.float64)
                for trigger in triggers:
                    mask_leg = loosest_leg == trigger.leg1_id
                    lepton_effs = self._get_lepton_efficiencies(arrays, trigger, valid_mask, eff_type=eff_type)
                    h_effs = ak.where(mask_leg, lepton_effs[f"{lep_type}_leg1"], h_effs)

                h_effs = self._to_valid_eff(h_effs)

                result = self.calculator.symmetric_dilepton_trigger(h_effs)
                if group_key == "el_el_sym":
                    P_el_el_sym = result
                    el_sym_eff = h_effs
                else:
                    P_mu_mu_sym = result
                    mu_sym_eff = h_effs

            elif group_key == "el_el_asym" or group_key == "mu_mu_asym":
                # asymmetric dilepton triggers - formula (7)
                legs1 = [t.leg1_name for t in triggers]
                legs2 = [t.leg2_name for t in triggers]
                all_legs = legs1 + legs2  # combine both pools

                pt = arrays[lep_type, self._select_pt_branch(lep_type)]

                # apply valid mask for run range
                pt = pt[valid_mask]

                # select loosest and tightest across ALL legs for each lepton (returns integer IDs)
                h_loosest = self.hierarchy.select_leg(pt, all_legs, select_loosest=True)
                h_tightest = self.hierarchy.select_leg(pt, all_legs, select_loosest=False)

                loosest_effs = ak.zeros_like(pt, dtype=np.float64)
                tightest_effs = ak.zeros_like(pt, dtype=np.float64)

                for trigger in triggers:
                    lepton_effs = self._get_lepton_efficiencies(arrays, trigger, valid_mask, eff_type=eff_type)

                    # check if leg1 is selected as loosest or tightest
                    mask_leg1_loosest = h_loosest == trigger.leg1_id
                    mask_leg1_tightest = h_tightest == trigger.leg1_id
                    loosest_effs = ak.where(mask_leg1_loosest, lepton_effs[f"{lep_type}_leg1"], loosest_effs)
                    tightest_effs = ak.where(mask_leg1_tightest, lepton_effs[f"{lep_type}_leg1"], tightest_effs)

                    # check if leg2 is selected as loosest or tightest
                    mask_leg2_loosest = h_loosest == trigger.leg2_id
                    mask_leg2_tightest = h_tightest == trigger.leg2_id
                    loosest_effs = ak.where(mask_leg2_loosest, lepton_effs[f"{lep_type}_leg2"], loosest_effs)
                    tightest_effs = ak.where(mask_leg2_tightest, lepton_effs[f"{lep_type}_leg2"], tightest_effs)

                single_leg_mask = h_loosest == h_tightest
                tightest_effs = ak.where(single_leg_mask, 0.0, tightest_effs)

                tightest_effs = self._to_valid_eff(tightest_effs)
                loosest_effs = self._to_valid_eff(loosest_effs)

                result = self.calculator.asymmetric_dilepton_trigger(tightest_effs, loosest_effs)

                if group_key == "el_el_asym":
                    P_el_el_asym = result
                    el_asym_tight_eff = tightest_effs
                    el_asym_loose_eff = loosest_effs
                else:
                    P_mu_mu_asym = result
                    mu_asym_tight_eff = tightest_effs
                    mu_asym_loose_eff = loosest_effs

            elif group_key == "el_mu_asym":
                # mixed e-mu triggers - formula (5)
                legs1 = [t.leg1_name for t in triggers]  # electron legs
                legs2 = [t.leg2_name for t in triggers]  # muon legs

                pt_el = arrays["el", self._select_pt_branch("el")]
                pt_mu = arrays["mu", self._select_pt_branch("mu")]

                # apply valid mask for run range
                pt_el = pt_el[valid_mask]
                pt_mu = pt_mu[valid_mask]

                # select loosest legs for each lepton type (returns integer IDs)
                h1_loosest = self.hierarchy.select_leg(pt_el, legs1, select_loosest=True)
                h2_loosest = self.hierarchy.select_leg(pt_mu, legs2, select_loosest=True)

                h1_el_effs = ak.zeros_like(pt_el, dtype=np.float64)
                h2_mu_effs = ak.zeros_like(pt_mu, dtype=np.float64)
                for trigger in triggers:
                    lepton_effs = self._get_lepton_efficiencies(arrays, trigger, valid_mask, eff_type=eff_type)

                    mask_leg1 = h1_loosest == trigger.leg1_id
                    h1_el_effs = ak.where(mask_leg1, lepton_effs["el_leg1"], h1_el_effs)

                    mask_leg2 = h2_loosest == trigger.leg2_id
                    h2_mu_effs = ak.where(mask_leg2, lepton_effs["mu_leg2"], h2_mu_effs)

                h1_el_effs = self._to_valid_eff(h1_el_effs)
                h2_mu_effs = self._to_valid_eff(h2_mu_effs)

                # store for e-mu correction term
                emu_el_leg_eff = h1_el_effs
                emu_mu_leg_eff = h2_mu_effs

        # combine symmetric and asymmetric dilepton triggers using proper correction
        P_el_el = None
        P_mu_mu = None

        if P_el_el_sym is not None and P_el_el_asym is not None:
            # both sym and asym electron triggers - use correction formula
            P_el_el = self.calculator.sym_asym_dilepton_corrected(
                eff_sym=el_sym_eff, eff_asym_tight=el_asym_tight_eff, eff_asym_loose=el_asym_loose_eff
            )
        elif P_el_el_sym is not None:
            P_el_el = P_el_el_sym
        elif P_el_el_asym is not None:
            P_el_el = P_el_el_asym

        if P_mu_mu_sym is not None and P_mu_mu_asym is not None:
            # both sym and asym muon triggers - use correction formula
            P_mu_mu = self.calculator.sym_asym_dilepton_corrected(
                eff_sym=mu_sym_eff, eff_asym_tight=mu_asym_tight_eff, eff_asym_loose=mu_asym_loose_eff
            )
        elif P_mu_mu_sym is not None:
            P_mu_mu = P_mu_mu_sym
        elif P_mu_mu_asym is not None:
            P_mu_mu = P_mu_mu_asym

        # combine single-lepton and dilepton triggers within each flavor
        P_el_total = None
        P_mu_total = None

        if P_el is not None or P_el_el is not None:
            if P_el is not None and P_el_el is not None:
                P_el_total = self.calculator.or_triggers(P_el, P_el_el)  # rough estimate (not supported)
            else:
                P_el_total = P_el if P_el is not None else P_el_el

        if P_mu is not None or P_mu_mu is not None:
            if P_mu is not None and P_mu_mu is not None:
                P_mu_total = self.calculator.or_triggers(P_mu, P_mu_mu)  # rough estimate (not supported)
            else:
                P_mu_total = P_mu if P_mu is not None else P_mu_mu

        # combine all triggers properly
        # case 1: only same-flavor triggers (el and/or mu)
        if emu_el_leg_eff is None and emu_mu_leg_eff is None:
            if P_el_total is not None and P_mu_total is not None:
                # formula (2): e and mu triggers independent
                final_result = self.calculator.or_triggers(P_el_total, P_mu_total)
            elif P_el_total is not None:
                final_result = P_el_total
            elif P_mu_total is not None:
                final_result = P_mu_total
            else:
                final_result = None
        # case 2: e-mu trigger present
        elif emu_el_leg_eff is not None and emu_mu_leg_eff is not None:
            # only e-mu trigger, no same-flavor triggers
            if P_el_total is None and P_mu_total is None:
                # formula (5): direct e-mu efficiency
                final_result = self.calculator.emu_dilepton_trigger(emu_el_leg_eff, emu_mu_leg_eff)

            # e-mu with same-flavor triggers - use correction formula (11 or 14)
            else:
                # start with base: 1 - (1-P_el)(1-P_mu)
                if P_el_total is not None and P_mu_total is not None:
                    base = self.calculator.or_triggers(P_el_total, P_mu_total)
                elif P_el_total is not None:
                    base = P_el_total
                else:
                    base = P_mu_total

                # add correction term from e-mu trigger
                final_result = self.calculator.e_mu_dilepton_corrected(
                    term1=base,  # OR part
                    eff_e_leg=emu_el_leg_eff,
                    eff_mu_leg=emu_mu_leg_eff,
                    P_ee=P_el_total,  # full electron efficiency (single + dilepton)
                    P_mumu=P_mu_total,  # full muon efficiency (single + dimuon)
                )
        else:
            raise RuntimeError("Invalid state in combining trigger efficiencies!")

        return final_result

    def _run_calculate_efficiencies(self, arrays: GroupArrays, eff_type: str) -> ak.Array:
        run_number: ak.Array = arrays["other", "runNumber"]

        eff_result_np = np.zeros(len(run_number), dtype=np.float64)

        for run_range, lepton_grouped_triggers in self.lepton_grouped_triggers.items():
            run_range_mask = (run_number >= run_range[0]) & (run_number < run_range[1])

            eff = self._calculate_combined_efficiencies(
                arrays,
                lepton_grouped_triggers,
                valid_mask=run_range_mask,
                eff_type=eff_type,
            )

            run_range_mask_np = ak.to_numpy(run_range_mask)
            eff_np = ak.to_numpy(eff)

            eff_result_np[run_range_mask_np] = eff_np

        return ak.Array(eff_result_np)

    def _run_calculate_eff_sf(self, arrays: GroupArrays, trigger_proc: TriggerProcessor | None = None) -> ak.Array:
        # get trigger processor and configuration
        if self._lepton_grouped_triggers is None:
            if trigger_proc is None:
                trigger_proc = self._get_trigger_processor()

            matching_triggers = self._get_matching_triggers(trigger_proc)
            self._lepton_grouped_triggers = self._group_triggers_by_lepton(matching_triggers)

        if len(self.lepton_grouped_triggers) == 0:
            # no triggers for this year - set all to 1.0
            eff_data = ak.ones_like(arrays["other", "runNumber"], dtype=np.float64)
            eff_mc = ak.ones_like(arrays["other", "runNumber"], dtype=np.float64)
        else:
            # calculate merged efficiencies
            eff_data = self._run_calculate_efficiencies(arrays, eff_type="data")
            eff_mc = self._run_calculate_efficiencies(arrays, eff_type="mc")

        eff_sf = self.calculator.compute_scale_factor(eff_data, eff_mc)

        if not self.allow_zero_sf:
            eff_sf = ak.where(eff_sf == 0.0, 1.0, eff_sf)

        return eff_sf

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays] | ak.Array:
        if self.is_data:
            return {"arrays": arrays}

        eff_sf = self._run_calculate_eff_sf(arrays)
        arrays["total_weight"] = arrays["total_weight"] * eff_sf

        if self.save_weights:
            arrays.add_varied_array(
                eff_sf,
                "weight_trigger",
                variation="nominal" if self.current_variation is None else self.current_variation,
                variation_map=self.variation_map,
            )

        return {"arrays": arrays}
