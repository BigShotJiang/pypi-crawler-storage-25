import logging
import os
import re
from dataclasses import asdict, dataclass

import pandas as pd

from f9columnar.analysis.config.samples import DatasetHandler
from f9columnar.analysis.rucio.rucio_db import RucioDB
from f9columnar.utils.helpers import dump_yaml, load_yaml
from f9columnar.utils.regex_helpers import extract_campaign_from_file


@dataclass
class SamplesConfig:
    data: list[str]
    mc: dict[str, list[int]]

    def __str__(self) -> str:
        return f"SamplesConfig(data={self.data}, MC={list(self.mc.keys())})"

    def __repr__(self) -> str:
        return self.__str__()


def load_samples_config(config_path: str, config_name: str) -> SamplesConfig:
    yaml_path = f"{config_path}/{config_name}.yaml"

    if not os.path.exists(yaml_path):
        raise FileNotFoundError(f"{yaml_path} does not exist!")

    return SamplesConfig(**load_yaml(yaml_path))


class SamplesConfigBuilder:
    def __init__(
        self,
        data_path: str | None = None,
        metadata_path: str | None = None,
        df_id: str = "hists",
        force: bool = False,
        dump_to_yaml: bool = True,
        hists_dir: str = "hists",
    ) -> None:
        """Builder class for creating and managing sample configurations.

        This class facilitates the generation of YAML configuration files that define
        data and MC samples for analysis. It supports filtering samples by year,
        campaign, dataset name, and DSID.

        Parameters
        ----------
        data_path : str or None, optional
            Path to the data directory. If None, uses COLUMNAR_DATA_PATH
            environment variable.
        metadata_path : str or None, optional
            Path to the metadata directory. If None, uses data_path.
        df_id : str, default="hists"
            Identifier for the DataFrame to load from RucioDB.
        force : bool, default=False
            If True, forces regeneration of the DataFrame even if cached.
        dump_to_yaml : bool, default=True
            If True, saves generated configurations to YAML files.
        hists_dir : str, default="hists"
            Directory name for histogram files.

        Attributes
        ----------
        data_path : str
            Path to the directory containing sample data and configs.
        rucio_db : DataFrame
            Pandas DataFrame containing sample metadata from RucioDB.

        Raises
        ------
        ValueError
            If data_path is None and COLUMNAR_DATA_PATH environment
            variable is not set.

        Methods
        -------
        build_default_config(force=False)
            Creates a default configuration with all available samples.
        load_default_config()
            Loads the default configuration from disk.
        build(new_config_name, include_years=None, include_mc_names=None,
                           include_campaigns=None, include_dsids=None)
            Creates a filtered configuration based on inclusion criteria.
        """
        if data_path is None:
            env_data_path = os.environ.get("COLUMNAR_DATA_PATH", None)

            if env_data_path is None:
                raise ValueError("COLUMNAR_DATA_PATH environment variable not set!")

            self.data_path = env_data_path
        else:
            self.data_path = data_path

        self.metadata_path = metadata_path if metadata_path is not None else self.data_path

        self.dump_to_yaml = dump_to_yaml

        self.rucio_db = RucioDB(self.data_path, self.metadata_path).to_dataframe(df_id, force, hists_dir)
        self.default_config: SamplesConfig | None = None

    def load_default_config(self) -> SamplesConfig:
        return load_samples_config(self.data_path, "default_samples_config")

    def build_default_config(self, force: bool = False) -> SamplesConfig:
        yaml_path = f"{self.data_path}/default_samples_config.yaml"

        if os.path.exists(yaml_path):
            logging.info("Default config already exists.")

            if not force:
                self.default_config = self.load_default_config()
                return self.default_config

        logging.info("Generating default samples config.")

        data_selection = self.rucio_db[self.rucio_db["is_data"] == True]
        data = data_selection["dataset_name"].unique()
        data = sorted(data.tolist())

        mc_selection = self.rucio_db[self.rucio_db["is_data"] == False]
        mc = mc_selection["dataset_name"].unique()
        mc = sorted(mc.tolist())

        mc_dsids = {}
        for mc_name in mc:
            dsids = mc_selection[mc_selection["dataset_name"] == mc_name]["dsid"].unique()
            mc_dsids[mc_name] = sorted(dsids.astype(int).tolist())

        self.default_config = SamplesConfig(data=data, mc=mc_dsids)

        if self.dump_to_yaml:
            yaml_dct = {"data": data, "mc": mc_dsids}
            dump_yaml(yaml_dct, yaml_path)

        return self.default_config

    @staticmethod
    def _match_mc_name(datasets: list[str], mc_name: str) -> bool:
        match_name = mc_name.split("_MC")[0]
        for dataset in datasets:
            if dataset == match_name:
                return True
        return False

    def build(
        self,
        new_config_name: str,
        include_years: list[int] | None = None,
        include_mc_names: list[str] | None = None,
        include_campaigns: list[str] | None = None,
        include_dsids: list[int] | None = None,
        regroup_by_dsid: dict[str, list[int]] | None = None,
        sample_datasets: dict[str, list[str]] | None = None,
    ) -> SamplesConfig:
        if include_years is not None and len(include_years) == 0:
            include_years = None

        if include_mc_names is not None and len(include_mc_names) == 0:
            include_mc_names = None

        if include_campaigns is not None and len(include_campaigns) == 0:
            include_campaigns = None

        if include_dsids is not None and len(include_dsids) == 0:
            include_dsids = None

        if self.default_config is None:
            default_config = self.load_default_config()
        else:
            default_config = self.default_config

        if include_years is None:
            filtered_data = default_config.data
        else:
            filtered_data = [
                data_year for data_year in default_config.data if any(str(year) in data_year for year in include_years)
            ]

        if include_mc_names is not None:
            ds_handler = DatasetHandler(sample_datasets=sample_datasets)

            include_samples = []
            for mc_name in include_mc_names:
                samples_ds = ds_handler.samples_from_dataset(mc_name)
                include_samples.extend(samples_ds.samples)
                include_samples.append(mc_name)
        else:
            include_samples = None

        if include_samples is not None:
            include_samples = list(set(include_samples))

        if include_campaigns is None and include_samples is None and include_dsids is None:
            filtered_mc = default_config.mc
        else:
            filtered_mc = {}
            for mc_name, dsids in default_config.mc.items():
                include_this_campaign = include_campaigns is None
                include_this_name = include_samples is None
                include_this_dsid = include_dsids is None

                # check campaign filter
                if include_campaigns is not None:
                    include_this_campaign = any(campaign in mc_name for campaign in include_campaigns)

                # check MC name filter
                if include_samples is not None:
                    include_this_name = self._match_mc_name(include_samples, mc_name)

                # check DSID filter
                if include_dsids is not None:
                    include_this_dsid = any(dsid in dsids for dsid in include_dsids)

                # include only if all active filters pass
                if include_this_campaign and include_this_name and include_this_dsid:
                    filtered_mc[mc_name] = dsids

        if len(filtered_data) == 0 and len(filtered_mc) == 0:
            raise ValueError("No samples selected with the given selection criteria!")

        if regroup_by_dsid is not None:
            new_grouped_samples: dict[str, list[int]] = {}
            for new_group_name, new_group_dsids in regroup_by_dsid.items():
                if "MC" in new_group_name:
                    raise ValueError("New group names should not contain 'MC'!")

                for mc_name, dsids in filtered_mc.items():
                    for dsid in new_group_dsids:
                        if dsid in dsids:
                            filtered_mc[mc_name].remove(dsid)

                            new_group_name_full = new_group_name + "_MC" + mc_name.split("MC")[-1]

                            if new_group_name_full not in new_grouped_samples:
                                new_grouped_samples[new_group_name_full] = []

                            new_grouped_samples[new_group_name_full].append(dsid)

            for new_group_name_full, new_group_dsids in new_grouped_samples.items():
                filtered_mc[new_group_name_full] = new_group_dsids

        for mc_name, dsids in filtered_mc.copy().items():
            if len(dsids) == 0:
                logging.info(f"Removing MC sample {mc_name} with no DSIDs left after filtering.")
                del filtered_mc[mc_name]

        new_config = SamplesConfig(data=filtered_data, mc=filtered_mc)

        if self.dump_to_yaml:
            new_yaml_path = f"{self.data_path}/{new_config_name}.yaml"
            dump_yaml(asdict(new_config), new_yaml_path)

        return new_config


def apply_sample_config_selection(samples_config: SamplesConfig, rucio_df: pd.DataFrame) -> pd.DataFrame:
    dfs: list[pd.DataFrame] = []

    for data_name in samples_config.data:
        data_selection = rucio_df[rucio_df["dataset_name"] == data_name]
        dfs.append(data_selection)

    for mc_name, dsids in samples_config.mc.items():
        campaign = extract_campaign_from_file(mc_name)

        for dsid in dsids:
            dsid_campaign_selection = rucio_df[(rucio_df["dsid"] == dsid) & (rucio_df["campaign"] == campaign)]

            dataset_names = dsid_campaign_selection["dataset_name"].unique()

            if len(dataset_names) == 0 or len(dataset_names) > 1:
                raise ValueError(f"DSID {dsid} with campaign {campaign} has invalid dataset names: {dataset_names}!")

            dataset_name = dataset_names[0]

            if dataset_name != mc_name:
                dsid_campaign_selection = dsid_campaign_selection.copy()
                dsid_campaign_selection["dataset_name"] = mc_name
                logging.info(f"Updated dataset {dataset_name} to {mc_name} for DSID {dsid}.")

            dfs.append(dsid_campaign_selection)

    new_rucio_df = pd.concat(dfs)
    new_rucio_df.reset_index(drop=True, inplace=True)

    return new_rucio_df
