import logging
import os
import re
from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np
import yaml

from f9columnar.analysis.utils import VALID_VARIATIONS
from f9columnar.submit.act_driver import ACT_CLUSTERS


def _find_yaml_files(dir: str) -> list[str]:
    """Recursively find all YAML files in a directory and its subdirectories."""
    yaml_files = []
    for root, _, files in os.walk(dir):
        for file in sorted(files):
            if file.endswith((".yaml", ".yml")):
                yaml_files.append(os.path.join(root, file))
    return yaml_files


def _resolve_yaml_variables(text: str) -> str:
    """Resolve `${var}` references in raw YAML text.

    Variables are defined as top-level `key: value` pairs.  A later value may
    reference an earlier key with `${key}`.  Resolution is performed on the
    raw text *before* YAML parsing so that anchors/aliases still work normally.

    """
    variables: dict[str, str] = {}
    result_lines: list[str] = []

    for line in text.splitlines(keepends=True):
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            # detect simple "key: value" or "key: &anchor value" definitions
            m = re.match(r"^(\w+)\s*:\s*(?:&\S+\s+)?(.+)$", stripped)
            if m:
                value = m.group(2).strip()
                # only store if the value doesn't itself contain unresolved refs
                if "${" not in value:
                    variables[m.group(1)] = value

        # substitute ${var} references in the current line
        def _replace(match: re.Match) -> str:
            name = match.group(1)
            if name not in variables:
                raise KeyError(
                    f"Undefined variable '${{{name}}}' in YAML. Available variables: {sorted(variables.keys())}"
                )
            return variables[name]

        line = re.sub(r"\$\{(\w+)\}", _replace, line)
        result_lines.append(line)

    return "".join(result_lines)


def resolve_yaml_inserts(text: str, config_path: str) -> str:
    """Replace a list-style `insert:` block with the raw text of the referenced YAML files.

    Parameters
    ----------
    text : str
        Raw YAML text that may contain an `insert:` block.
    config_path : str
        Path to the YAML file being loaded.  Used to determine the search
        directory and to exclude the file itself from matches.

    Returns
    -------
    str
        The YAML text with the `insert:` block replaced by the contents of
        the referenced files.
    """

    config_dir = os.path.dirname(os.path.abspath(config_path))
    main_config_abs = os.path.abspath(config_path)

    available_files = _find_yaml_files(config_dir)
    available_files = [f for f in available_files if os.path.abspath(f) != main_config_abs]

    name_to_path: dict[str, str] = {}
    for fpath in available_files:
        stem = os.path.splitext(os.path.basename(fpath))[0]
        name_to_path[stem] = fpath

    lines = text.splitlines(keepends=True)
    result_lines: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        list_header = re.match(r"^insert\s*:\s*$", stripped)
        if list_header:
            i += 1
            names: list[str] = []
            while i < len(lines):
                item_line = lines[i]
                item_stripped = item_line.strip()

                if item_stripped == "" or item_stripped.startswith("#"):
                    i += 1
                    continue

                item_match = re.match(r"^\s+-\s*(\S+)\s*$", item_line)
                if item_match:
                    names.append(item_match.group(1))
                    i += 1
                else:
                    break

            for name in names:
                if name not in name_to_path:
                    raise FileNotFoundError(
                        f"Insert config '{name}' not found. "
                        f"Available configs in '{config_dir}': {sorted(name_to_path.keys())}"
                    )

                with open(name_to_path[name]) as f:
                    result_lines.append(f.read())
                    if not result_lines[-1].endswith("\n"):
                        result_lines.append("\n")

            continue

        result_lines.append(line)
        i += 1

    merged = "".join(result_lines)
    return _resolve_yaml_variables(merged)


ALLOWED_CONFIG_KEYS = {
    "user",
    "user_config",
    "common",
    "common_config",
    "samples",
    "dataloader",
    "submit",
    "systematics",
    "sys",
    "plotting",
    "plotting_config",
    "insert",
}


@dataclass
class BaseConfig:
    @classmethod
    def required(self) -> set[str]:
        return set()

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items()}


@dataclass
class UserConfig(BaseConfig):
    def __setattr__(self, name: str, value: Any) -> None:
        super().__setattr__(name, value)

    def get(self, name: str, default: Any = None) -> Any:
        return getattr(self, name, default)

    def __getattr__(self, name: str) -> Any:
        raise AttributeError(name)


@dataclass
class CommonConfig(BaseConfig):
    results_path: str = ""
    data_path: str = ""
    metadata_path: str = ""
    cut_flow: bool = False
    no_plot_cut_flow: bool = False
    disable_progress_bar: bool = False
    root_files: dict[str, list[str]] = field(default_factory=dict)
    truth_mctc: bool = True
    truth_mctc_charge_flip_fallback: bool = False
    truth_mode: str = "Nominal"

    @classmethod
    def required(self) -> set[str]:
        return {"results_path", "data_path"}

    def __post_init__(self) -> None:
        os.makedirs(self.results_path, exist_ok=True)
        os.makedirs(self.data_path, exist_ok=True)


@dataclass
class SamplesConfig(BaseConfig):
    years: list[int] = field(default_factory=list)
    campaigns: list[str] = field(default_factory=list)
    datasets: list[str] = field(default_factory=list)
    dsids: list[int] = field(default_factory=list)
    regroup_by_dsid: dict[str, list[int]] | None = None

    def __post_init__(self) -> None:
        self.datasets = [str(ds) for ds in self.datasets]


@dataclass
class DataLoaderConfig(BaseConfig):
    step_size: int = -1
    key: str = ""
    num_workers: int = 1
    prefetch_factor: int = 2
    pin_memory: bool = False

    @classmethod
    def required(self) -> set[str]:
        return {"step_size", "key"}


@dataclass
class ActConfig(BaseConfig):
    clusters: list[str] = field(default_factory=list)
    dcache_user: str = ""
    cpu_time: int = 30
    wall_time: int = 30
    memory: int = 2000
    thread_count: int = 1
    max_resub: int = 3
    refresh_time: int = 5

    def __post_init__(self) -> None:
        for cluster in self.clusters:
            if cluster not in ACT_CLUSTERS:
                raise ValueError(f"Invalid aCT cluster name: {cluster}. Must be one of {list(ACT_CLUSTERS.keys())}!")

    @property
    def job_spec(self) -> dict[str, Any]:
        return {
            "cpu_time": self.cpu_time,
            "wall_time": self.wall_time,
            "memory": self.memory,
            "thread_count": self.thread_count,
        }


@dataclass
class SubmitConfig(BaseConfig):
    local_run: bool = True
    job_name: str = ""
    submit_dir: str = ""
    test_files: list[str] = field(default_factory=list)
    dataset_scope: str | None = None
    ntuple_location: str | None = None
    force_rucio_db_refresh: bool = False
    max_root_files: int | None = None
    events_per_job: int | None = None
    act_config: ActConfig = field(default_factory=ActConfig)
    disable: bool = True

    def __post_init__(self) -> None:
        if not self.local_run and not self.disable:
            logging.info("Running in submit mode, setting Ntuple location to 'rucio'.")
            self.ntuple_location = "rucio"

            if self.job_name == "":
                raise ValueError("Job name must be specified when running in submit mode!")

            if self.submit_dir == "":
                raise ValueError("Submit directory must be specified when running in submit mode!")

            if self.act_config.dcache_user == "":
                raise ValueError("dcache_user must be specified in act_config when running in submit mode!")

        if self.ntuple_location is not None and self.ntuple_location != "rucio":
            os.makedirs(self.ntuple_location, exist_ok=True)


@dataclass
class SystematicsConfig(BaseConfig):
    nominal_only: bool = False
    filter_variations: list[str] | None = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.filter_variations is None:
            self.filter_variations = []

        if len(self.filter_variations) > 0:
            for var in self.filter_variations:
                if var not in VALID_VARIATIONS:
                    raise ValueError(f"Invalid variation to filter: {var}. Must be one of {VALID_VARIATIONS}!")


@dataclass
class PlotConfig(BaseConfig):
    yscale: str = "log"
    xscale: str = "lin"
    use_atlas_style: bool = True
    atlas_label: str | None = "Internal"
    figsize_inch: tuple[float, float] = (7, 7)
    auto_ylim: bool = True
    ylim: tuple[float | None, float | None] | None = None
    xlim: tuple[float | None, float | None] | None = None
    comparison_ylim: tuple[float, float] = (0.5, 1.5)
    comparison_hline_space: float | None = 0.2
    com: float | None = 13.0
    hist_bins: int | None = None
    hist_range: tuple[float, float] | None = None
    hist_edges: list[float] | np.ndarray | None = None
    xlabel: str | None = None
    ylabel: str | None = None
    title: str | None = None
    title_loc: str | None = None
    mc_only: bool = False
    data_only: bool = False
    group_key: str | None = None

    def __post_init__(self):
        if self.hist_bins is not None and self.hist_edges is not None:
            raise ValueError("Cannot specify both hist_bins and hist_edges in PlotConfig!")

        if self.mc_only and self.data_only:
            raise ValueError("Cannot set both mc_only and data_only in PlotConfig!")

        if self.xscale not in {"lin", "log"}:
            raise ValueError(f"Invalid xscale: {self.xscale}. Must be 'lin' or 'log'!")

        if self.yscale not in {"lin", "log"}:
            raise ValueError(f"Invalid yscale: {self.yscale}. Must be 'lin' or 'log'!")

        if self.ylim is not None:
            low, high = self.ylim
            if low is not None:
                low = float(low)
            if high is not None:
                high = float(high)
            self.ylim = (low, high)

        env_atlas_label = os.environ.get("COLUMNAR_ATLAS_LABEL", None)
        self.atlas_label = self.atlas_label if self.atlas_label is not None else env_atlas_label


@dataclass
class PlottingConfig(BaseConfig):
    plotting_config: dict[str, list[PlotConfig]] = field(default_factory=dict)
    years: list[int] | None = None
    campaigns: list[str] | None = None
    datasets: list[str] | None = None
    plot_signals: list[str] | None = None
    variation: str = "nominal"
    plot_mode: str = "manual"

    def __post_init__(self) -> None:
        self._plotting_variables = set(self.plotting_config.keys())

    @property
    def plotting_variables(self) -> set[str]:
        return self._plotting_variables


@dataclass
class AnalysisConfig:
    user_config: UserConfig = field(default_factory=UserConfig)
    common: CommonConfig = field(default_factory=CommonConfig)
    samples: SamplesConfig = field(default_factory=SamplesConfig)
    dataloader: DataLoaderConfig = field(default_factory=DataLoaderConfig)
    submit: SubmitConfig = field(default_factory=SubmitConfig)
    systematics: SystematicsConfig = field(default_factory=SystematicsConfig)
    plotting_config: PlottingConfig = field(default_factory=PlottingConfig)

    def __str__(self) -> str:
        output = ["Analysis Configuration", "=" * 50, ""]
        output.append(f"Common: results_path={self.common.results_path}")
        output.append(
            f"DataLoader: step_size={self.dataloader.step_size}, "
            f"key={self.dataloader.key}, "
            f"num_workers={self.dataloader.num_workers}"
        )
        return "\n".join(output)

    def __repr__(self):
        return f"AnalysisConfig(regions={list(self.regions.keys())})"


class AnalysisConfigBuilder:
    def __init__(self, config_path: str | None = None):
        if config_path is None:
            config_path = os.environ.get("COLUMNAR_CONFIG_PATH", None)
            if config_path is None:
                raise ValueError("No configuration path provided and COLUMNAR_CONFIG_PATH is not set!")

        self.config_path = config_path

    def _load_yaml(self) -> dict[str, Any]:
        with open(self.config_path) as f:
            raw_text = f.read()
        raw_text = resolve_yaml_inserts(raw_text, self.config_path)
        raw_config = yaml.safe_load(raw_text)
        return raw_config

    def _check_valid_keys(self, config_dict: dict[str, Any], check_conf: type[BaseConfig]) -> None:
        allowed_keys = set(check_conf.__dataclass_fields__.keys())
        for key in config_dict.keys():
            if key not in allowed_keys:
                raise ValueError(f"Invalid key in config: {key}. Allowed keys are: {allowed_keys}.")

    def _report_missing_keys(self, config_dict: dict[str, Any], check_conf: type[BaseConfig]) -> None:
        for key in check_conf.required():
            if key not in config_dict:
                raise ValueError(f"Missing required key in config: {key} for {check_conf.__name__}!")

    def _check_config(self, config_dict: dict[str, Any], check_conf: type[BaseConfig]) -> None:
        self._check_valid_keys(config_dict, check_conf)
        self._report_missing_keys(config_dict, check_conf)

    def _build_user_config(self, raw_config: dict[str, Any]) -> UserConfig:
        user_dct = raw_config.get("user", raw_config.get("user_config", {}))

        if len(user_dct) == 0:
            return UserConfig()

        user_config = UserConfig()

        for k, v in user_dct.items():
            setattr(user_config, k, v)

        return user_config

    def _build_common_config(self, raw_config: dict[str, Any]) -> CommonConfig:
        common_dct = raw_config.get("common", raw_config.get("common_config"))

        if common_dct is None:
            raise ValueError("Common configuration not found in config file!")

        self._check_config(common_dct, CommonConfig)

        return CommonConfig(
            results_path=common_dct["results_path"],
            data_path=common_dct["data_path"],
            metadata_path=common_dct.get("metadata_path", common_dct["data_path"]),
            cut_flow=common_dct.get("cut_flow", False),
            no_plot_cut_flow=common_dct.get("no_plot_cut_flow", False),
            disable_progress_bar=common_dct.get("disable_progress_bar", False),
            root_files=common_dct.get("root_files", {}),
            truth_mctc=common_dct.get("truth_mctc", True),
            truth_mctc_charge_flip_fallback=common_dct.get("truth_mctc_charge_flip_fallback", False),
            truth_mode=common_dct.get("truth_mode", "Nominal"),
        )

    def _build_samples_config(self, raw_config: dict[str, Any]) -> SamplesConfig:
        samples_dct = raw_config.get("samples", raw_config.get("samples_config", {}))

        self._check_config(samples_dct, SamplesConfig)

        return SamplesConfig(
            years=samples_dct.get("years", []),
            campaigns=samples_dct.get("campaigns", []),
            datasets=samples_dct.get("datasets", []),
            dsids=samples_dct.get("dsids", []),
            regroup_by_dsid=samples_dct.get("regroup_by_dsid", None),
        )

    def _build_dataloader_config(self, raw_config: dict[str, Any]) -> DataLoaderConfig:
        dataloader_dct = raw_config.get("dataloader", raw_config.get("dataloader_config"))

        if dataloader_dct is None:
            raise ValueError("DataLoader configuration not found in config file!")

        self._check_config(dataloader_dct, DataLoaderConfig)

        return DataLoaderConfig(
            step_size=dataloader_dct["step_size"],
            key=dataloader_dct["key"],
            num_workers=dataloader_dct.get("num_workers", 1),
            prefetch_factor=dataloader_dct.get("prefetch_factor", 2),
            pin_memory=dataloader_dct.get("pin_memory", False),
        )

    def _build_submit_config(self, raw_config: dict[str, Any]) -> SubmitConfig:
        submit_dct = raw_config.get("submit", raw_config.get("submit_config", {}))

        if len(submit_dct) == 0:
            return SubmitConfig()

        self._check_config(submit_dct, SubmitConfig)

        if "act" in submit_dct or "act_config" in submit_dct:
            act_dct = submit_dct.get("act", submit_dct.get("act_config", {}))
            submit_dct["act_config"] = ActConfig(
                clusters=act_dct.get("clusters", list(ACT_CLUSTERS.keys())),
                dcache_user=act_dct.get("dcache_user", ""),
                cpu_time=act_dct.get("cpu_time", 30),
                wall_time=act_dct.get("wall_time", 30),
                memory=act_dct.get("memory", 2000),
                thread_count=act_dct.get("thread_count", 1),
                max_resub=act_dct.get("max_resub", 3),
                refresh_time=act_dct.get("refresh_time", 5),
            )

        events_per_job = submit_dct.get("events_per_job", None)
        if events_per_job is not None:
            events_per_job = int(events_per_job)

        return SubmitConfig(
            local_run=submit_dct.get("local_run", True),
            job_name=submit_dct.get("job_name", ""),
            submit_dir=submit_dct.get("submit_dir", ""),
            test_files=submit_dct.get("test_files", []),
            dataset_scope=submit_dct.get("dataset_scope", None),
            ntuple_location=submit_dct.get("ntuple_location", None),
            force_rucio_db_refresh=submit_dct.get("force_rucio_db_refresh", False),
            max_root_files=submit_dct.get("max_root_files", None),
            events_per_job=events_per_job,
            act_config=submit_dct.get("act_config", ActConfig()),
            disable=submit_dct.get("disable", False),
        )

    def _build_systematic_config(self, config_dict: dict[str, Any]) -> SystematicsConfig:
        sys_dct = config_dict.get("systematics", config_dict.get("sys", {}))

        self._check_config(sys_dct, SystematicsConfig)

        return SystematicsConfig(
            nominal_only=sys_dct.get("nominal_only", True),
            filter_variations=sys_dct.get("filter_variations", []),
        )

    def _build_plotting_config(self, config_dict: dict[str, Any]) -> PlottingConfig:
        plotting_dct = config_dict.get("plotting", config_dict.get("plotting_config", {}))

        plotting_config: dict[str, list[PlotConfig]] = {}
        for name, plot_dct in plotting_dct.items():
            if name in {"years", "campaigns", "plot_mode", "datasets", "plot_signals", "variation"}:
                continue

            if all(isinstance(v, dict) for v in plot_dct.values()):
                plotting_config[name] = [PlotConfig(**sub) for sub in plot_dct.values()]
            else:
                plotting_config[name] = [PlotConfig(**plot_dct)]

            for plot_conf in plotting_config[name]:
                self._check_config(plot_conf.to_dict(), PlotConfig)

        return PlottingConfig(
            plotting_config,
            years=plotting_dct.get("years", None),
            campaigns=plotting_dct.get("campaigns", None),
            datasets=plotting_dct.get("datasets", None),
            plot_signals=plotting_dct.get("plot_signals", None),
            variation=plotting_dct.get("variation", "nominal"),
            plot_mode=plotting_dct.get("plot_mode", "manual"),
        )

    def build(self) -> AnalysisConfig:
        raw_config = self._load_yaml()

        user_config = self._build_user_config(raw_config)
        common_config = self._build_common_config(raw_config)
        samples_config = self._build_samples_config(raw_config)
        dataloader_config = self._build_dataloader_config(raw_config)
        systematics_config = self._build_systematic_config(raw_config)
        submit_config = self._build_submit_config(raw_config)
        plotting_config = self._build_plotting_config(raw_config)

        if not submit_config.local_run and not submit_config.disable:
            num_workers = submit_config.act_config.thread_count
            dataloader_config.num_workers = num_workers if num_workers > 1 else 0

        return AnalysisConfig(
            user_config=user_config,
            common=common_config,
            samples=samples_config,
            dataloader=dataloader_config,
            systematics=systematics_config,
            submit=submit_config,
            plotting_config=plotting_config,
        )
