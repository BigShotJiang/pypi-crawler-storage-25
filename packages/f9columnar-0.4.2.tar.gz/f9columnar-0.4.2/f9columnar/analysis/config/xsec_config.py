import glob
import logging
import os
from dataclasses import dataclass
from typing import Self

import pandas as pd

from f9columnar.utils.helpers import load_json


@dataclass
class XsecConfig:
    run2_xsec: dict[int, float] | None = None
    run3_xsec: dict[int, float] | None = None

    def get(self, run: str, dsid: int) -> float:
        if run.lower() == "run2":
            if self.run2_xsec is None:
                raise ValueError("Run 2 cross section data is not available!")
            return self.run2_xsec[dsid]
        elif run.lower() == "run3":
            if self.run3_xsec is None:
                raise ValueError("Run 3 cross section data is not available!")
            return self.run3_xsec[dsid]
        else:
            raise ValueError(f"Unrecognized run: {run}!")

    def to_dict(self) -> dict[str, dict[int, float] | None]:
        return {
            "run2_xsec": self.run2_xsec,
            "run3_xsec": self.run3_xsec,
        }

    def from_dict(self, dct: dict[str, dict[int, float] | None]) -> Self:
        self.run2_xsec = dct.get("run2_xsec", None)
        self.run3_xsec = dct.get("run3_xsec", None)
        return self

    def __str__(self) -> str:
        run2_str = "available" if self.run2_xsec else "not available"
        run3_str = "available" if self.run3_xsec else "not available"

        return f"XsecConfig(run2_xsec={run2_str}, run3_xsec={run3_str})"

    def __repr__(self) -> str:
        return self.__str__()


class XsecBuilder:
    def __init__(self, xsec_folder: str) -> None:
        xsec_files = glob.glob(os.path.join(xsec_folder, "xsec_*.json"))

        if len(xsec_files) == 0:
            raise FileNotFoundError(f"No cross section JSON files found in {xsec_folder}!")

        self.run2_xsec_file, self.run3_xsec_file = None, None

        for xsec_file in xsec_files:
            if "run2" in xsec_file.lower():
                self.run2_xsec_file = xsec_file
            elif "run3" in xsec_file.lower():
                self.run3_xsec_file = xsec_file
            else:
                logging.warning(f"Unrecognized xsec file: {xsec_file}. Skipping...")

    def build(self) -> XsecConfig:
        if self.run2_xsec_file is None and self.run3_xsec_file is None:
            raise ValueError("No cross section files available to read!")

        if self.run2_xsec_file:
            run2_xsec = load_json(self.run2_xsec_file)
            run2_xsec = {int(k): float(v) for k, v in run2_xsec.items()}
        else:
            run2_xsec = None

        if self.run3_xsec_file:
            run3_xsec = load_json(self.run3_xsec_file)
            run3_xsec = {int(k): float(v) for k, v in run3_xsec.items()}
        else:
            run3_xsec = None

        return XsecConfig(run2_xsec=run2_xsec, run3_xsec=run3_xsec)


class PMGXsecDB:
    def __init__(
        self,
        pmg_mc: str,
        path_to_pmg_file: str,
        names: list[str] | None = None,
        add_effective_xsec: bool = True,
        add_br: bool = True,
        correct_higher_order: bool = True,
    ) -> None:
        if pmg_mc not in {"mc16", "mc21"}:
            raise ValueError(f"PMG cross section database for '{pmg_mc}' is not available.")

        self.path = os.path.join(path_to_pmg_file, f"PMGxsecDB_{pmg_mc}.txt")
        self.add_effective_xsec = add_effective_xsec
        self.add_br = add_br
        self.correct_higher_order = correct_higher_order

        if names is None:
            self.names = [
                "dataset_number",
                "physics_short",
                "crossSection",
                "genFiltEff",
                "kFactor",
                "relUncertUP",
                "relUncertDOWN",
                "generator_name",
                "etag",
            ]
        else:
            self.names = names

        self.xsec_db: pd.DataFrame | None = None

    def read_xsec(self) -> pd.DataFrame:
        xsec_db = pd.read_csv(
            self.path,
            header=None,
            delimiter=r"\s+",
            names=self.names,
            engine="python",
        )

        self.xsec_db = xsec_db

        if self.add_br and "branchingratio" not in [name.lower() for name in self.names]:
            self.xsec_db["branchingRatio"] = 1.0

        if self.correct_higher_order:
            logging.warning("Correcting higher order cross sections.")
            self._higher_order_cross_sections()

        if self.add_effective_xsec:
            self._calculate_effective_xsec()

        return self.xsec_db

    def _higher_order_cross_sections(self) -> Self:
        """https://twiki.cern.ch/twiki/bin/viewauth/AtlasProtected/PmgWeakBosonProcesses#Higher_order_cross_sections"""

        Z_to_ll = ["Sh_2211_Zee", "Sh_2211_Zmumu", "Sh_2211_Ztautau", "Sh_2211_Ztt"]
        W_to_lnu = ["Sh_2211_Wenu", "Sh_2211_Wmunu", "Sh_2211_Wtaunu"]

        if self.xsec_db is None:
            raise ValueError("Cross section database is not loaded!")

        idx_Z_to_ll = self.xsec_db["physics_short"].str.contains("|".join(Z_to_ll))
        idx_W_to_lnu = self.xsec_db["physics_short"].str.contains("|".join(W_to_lnu))

        self.xsec_db.loc[idx_Z_to_ll, ["kFactor"]] = 0.95
        self.xsec_db.loc[idx_W_to_lnu, ["kFactor"]] = 0.95

        return self

    def _calculate_effective_xsec(self) -> Self:
        if self.xsec_db is None:
            raise ValueError("Cross section database is not loaded!")

        self.xsec_db["effectiveCrossSection"] = (
            self.xsec_db["crossSection"]
            * self.xsec_db["branchingRatio"]
            * self.xsec_db["genFiltEff"]
            * self.xsec_db["kFactor"]
        )
        return self

    def slim(self, dsids: list[int], overwrite: bool = False, save: str | None = None) -> Self:
        if self.xsec_db is None:
            raise ValueError("Cross section database is not loaded!")

        slim_xsec_db = self.xsec_db[self.xsec_db["dataset_number"].isin(dsids)]

        if overwrite:
            self.xsec_db = slim_xsec_db

        if save:
            logging.info(f"Saving slimmed xsec db to {save}.")
            slim_xsec_db.to_csv(save, sep=" ", index=False, header=False)

        return self

    def __call__(self) -> pd.DataFrame:
        if self.xsec_db is None:
            raise ValueError("Cross section database is not loaded!")

        return self.read_xsec()
