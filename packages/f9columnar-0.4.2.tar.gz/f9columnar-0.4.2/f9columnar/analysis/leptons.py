from typing import Any

import awkward as ak
import numpy as np

from f9columnar.analysis.utils import ELECTRON_PDGID, MUON_PDGID, TAU_PDGID
from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor
from f9columnar.processors_collection import decorate_branches
from f9columnar.variations import vary


class SelectionProcessor(Processor):
    def __init__(self, name: str, anti_tau: bool = False, disable_variations: bool = False) -> None:
        super().__init__(name=name, disable_variations=disable_variations)
        self.anti_tau = anti_tau

        self.sel_el: bool
        self.sel_mu: bool
        self.sel_tau: bool

        self.el_selected: str
        self.mu_selected: str
        self.tau_selected: str

    def setup_selected_branches(
        self,
        sel_el: bool | None = None,
        sel_mu: bool | None = None,
        sel_tau: bool | None = None,
        add_tau_sel_branch: bool = False,
    ) -> None:
        if sel_el is not None:
            self.sel_el = sel_el

        if sel_mu is not None:
            self.sel_mu = sel_mu

        if sel_tau is not None:
            self.sel_tau = sel_tau

        if self.sel_el:
            if self.sel_tau:
                if self.anti_tau:
                    el_branch = "el_selected_taus_anti_NOSYS"
                else:
                    el_branch = "el_selected_taus_NOSYS"
            else:
                el_branch = "el_selected_NOSYS"

            self.attach_branch((el_branch, "el_selected"), is_varied=True, overwrite=True)

        if self.sel_mu:
            if self.sel_tau:
                if self.anti_tau:
                    mu_branch = "mu_selected_taus_anti_NOSYS"
                else:
                    mu_branch = "mu_selected_taus_NOSYS"
            else:
                mu_branch = "mu_selected_NOSYS"

            self.attach_branch((mu_branch, "mu_selected"), is_varied=True, overwrite=True)

        if self.sel_tau or add_tau_sel_branch:
            if self.anti_tau:
                tau_branch = "tau_selected_anti_NOSYS"
            else:
                tau_branch = "tau_selected_NOSYS"

            self.attach_branch((tau_branch, "tau_selected"), is_varied=True, overwrite=True)

    def run(self, arrays: Any) -> dict[str, Any]:
        return {"arrays": arrays}


@decorate_branches("mu_eta")
class LeptonSelection(SelectionProcessor):
    el_pt: str
    el_eta: str
    mu_pt: str
    mu_eta: str
    mu_is_high_pt: str
    is_high_pt_flag: str
    tau_pt: str

    def __init__(
        self,
        sel_el: bool = False,
        sel_mu: bool = False,
        sel_tau: bool = False,
        el_pt_cut: float | None = None,
        mu_pt_cut: float | None = None,
        tau_pt_cut: float | None = None,
        mu_high_pt_threshold: float | None = None,
        use_calo_cluster_eta: bool = False,
        anti_tau: bool = False,
        prefix: str = "",
    ) -> None:
        super().__init__(name=f"{prefix}leptonSelection", anti_tau=anti_tau)

        self.sel_el, self.sel_mu, self.sel_tau = sel_el, sel_mu, sel_tau
        self.el_pt_cut, self.mu_pt_cut, self.tau_pt_cut = el_pt_cut, mu_pt_cut, tau_pt_cut
        self.mu_high_pt_threshold = mu_high_pt_threshold

        if self.el_pt_cut is not None:
            self.el_pt_cut = self.el_pt_cut * 1000.0

        if self.mu_pt_cut is not None:
            self.mu_pt_cut = self.mu_pt_cut * 1000.0

        if self.tau_pt_cut is not None:
            self.tau_pt_cut = self.tau_pt_cut * 1000.0

        if self.mu_high_pt_threshold is not None:
            self.mu_high_pt_threshold = self.mu_high_pt_threshold * 1000.0

        if self.sel_el and el_pt_cut is not None:
            self.attach_branch(("el_pt_NOSYS", "el_pt"), is_varied=True)

        if self.sel_mu and mu_pt_cut is not None:
            self.attach_branch(("mu_pt_NOSYS", "mu_pt"), is_varied=True)

        if self.sel_mu and self.mu_high_pt_threshold is not None:
            self.attach_branch(("mu_HighPt_NOSYS", "mu_is_high_pt"), is_varied=True)
            self.attach_branch(("mu_is_high_pt_flag_NOSYS", "is_high_pt_flag"), is_varied=True, is_created=True)

        if self.sel_tau and tau_pt_cut is not None:
            self.attach_branch(("tau_pt_NOSYS", "tau_pt"), is_varied=True)

        if use_calo_cluster_eta:
            self.attach_branch(("el_caloCluster_eta", "el_eta"), is_varied=False)
        else:
            self.attach_branch("el_eta", is_varied=False)

        self.setup_selected_branches()

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.sel_el:
            el = arrays["el"]
            mask = el[self.el_selected] == 1
            if self.el_pt_cut is not None:
                mask = mask & (el[self.el_pt] >= self.el_pt_cut)

            mask = mask & (np.abs(el[self.el_eta]) <= 2.47)
            arrays["el"] = el[mask]

        if self.sel_mu:
            mu = arrays["mu"]
            mask = mu[self.mu_selected] == 1
            if self.mu_pt_cut is not None:
                mask = mask & (mu[self.mu_pt] >= self.mu_pt_cut)

            mask = mask & (np.abs(mu[self.mu_eta]) <= 2.5)

            if self.mu_high_pt_threshold is not None:
                above_threshold = mu[self.mu_pt] >= self.mu_high_pt_threshold
                # muons below the threshold are always kept
                # but muons above it must pass the HighPt reconstruction quality
                mask = mask & ~(above_threshold & (mu[self.mu_is_high_pt] == 0))

            arrays["mu"] = mu[mask]

            if self.mu_high_pt_threshold is not None:
                filtered_mu = arrays["mu"]
                is_high_pt = (filtered_mu[self.mu_pt] >= self.mu_high_pt_threshold) & (
                    filtered_mu[self.mu_is_high_pt] == 1
                )
                arrays.add_varied_array(
                    is_high_pt,
                    "mu_is_high_pt_flag",
                    variation="nominal" if self.current_variation is None else self.current_variation,
                    variation_map=self.variation_map,
                )

        if self.sel_tau:
            tau = arrays["tau"]
            mask = tau[self.tau_selected] == 1
            if self.tau_pt_cut is not None:
                mask = mask & (tau[self.tau_pt] >= self.tau_pt_cut)
            arrays["tau"] = tau[mask]

        return {"arrays": arrays}


class LeptonMultiplicity(SelectionProcessor):
    def __init__(
        self,
        n_el: int | tuple[int, int | str] | None = None,
        n_mu: int | tuple[int, int | str] | None = None,
        n_tau: int | tuple[int, int | str] | None = None,
        n_total: int | tuple[int, int | str] | None = None,
        sel_tau: bool = False,
        prefix: str = "",
    ) -> None:
        super().__init__(name=f"{prefix}leptonMultiplicity")
        self.n_total = self._normalize_multiplicity(n_total) if n_total is not None else None

        if n_tau is not None:
            sel_tau = True

        _n_el = self._normalize_multiplicity(n_el)
        _n_mu = self._normalize_multiplicity(n_mu)
        _n_tau = self._normalize_multiplicity(n_tau, default=0 if not sel_tau else None)

        self._validate_requirements(_n_el, _n_mu, _n_tau, self.n_total)

        self.requirement: dict[int, tuple[int, int | float]] = {
            ELECTRON_PDGID: _n_el,
            MUON_PDGID: _n_mu,
            TAU_PDGID: _n_tau,
        }

        self.skip_lepton_counts = self._should_skip_lepton_counts(_n_el, _n_mu, _n_tau, self.n_total)

        self.setup_selected_branches(sel_el=True, sel_mu=True, sel_tau=sel_tau, add_tau_sel_branch=True)

    @staticmethod
    def _normalize_multiplicity(
        n: int | tuple[int, int | str] | None, default: int | None = None
    ) -> tuple[int, int | float]:
        """Convert multiplicity requirement to (min, max) tuple.

        Handles:
          - None -> (0, inf) or (default, default)
          - int -> (int, int)
          - tuple[int, int | str] -> (int, float) where str can be "inf"

        """
        if n is None:
            if default is None:
                return (0, float("inf"))
            else:
                return (default, default)

        if isinstance(n, int):
            return (n, n)

        min_val = n[0]
        if isinstance(n[1], str):
            if n[1].lower() == "inf":
                max_val = float("inf")
            else:
                raise ValueError(f"Invalid upper bound string: '{n[1]}'. Only 'inf' is allowed!")
        elif isinstance(n[1], int):
            max_val = n[1]
        else:
            raise TypeError(f"Upper bound must be int or 'inf' string, got {type(n[1])}!")

        if not isinstance(min_val, int):
            raise TypeError(f"Lower bound must be int, got {type(min_val)}!")

        return (min_val, max_val)

    def _validate_requirements(
        self,
        n_el: tuple[int, int | float],
        n_mu: tuple[int, int | float],
        n_tau: tuple[int, int | float],
        n_total: tuple[int, int | float] | None,
    ) -> None:
        """Validate that requirements are consistent."""
        all_unbounded = n_el[1] == float("inf") and n_mu[1] == float("inf") and n_tau[1] == float("inf")

        if all_unbounded and n_total is None:
            raise ValueError("At least one lepton multiplicity upper bound or total lepton count must be specified!")

        min_leptons = n_el[0] + n_mu[0] + n_tau[0]
        max_total = n_total[1] if n_total is not None else float("inf")

        if min_leptons > max_total:
            raise ValueError(f"Minimum lepton counts ({min_leptons}) exceed maximum total lepton count ({max_total})!")

    @staticmethod
    def _should_skip_lepton_counts(
        n_el: tuple[int, int | float],
        n_mu: tuple[int, int | float],
        n_tau: tuple[int, int | float],
        n_total: tuple[int, int | float] | None,
    ) -> bool:
        all_unbounded = n_el[1] == float("inf") and n_mu[1] == float("inf") and n_tau[1] == float("inf")
        return all_unbounded and n_total is not None

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        all_parts = [
            ak.ones_like(arrays["el"][self.el_selected]) * ELECTRON_PDGID,
            ak.ones_like(arrays["mu"][self.mu_selected]) * MUON_PDGID,
            ak.ones_like(arrays["tau"][self.tau_selected]) * TAU_PDGID,
        ]
        parts = ak.concatenate(all_parts, axis=1)

        mask = ak.ones_like(ak.num(parts, axis=1), dtype=bool)

        if not self.skip_lepton_counts:
            for pdgid, (min_count, max_count) in self.requirement.items():
                counts = ak.sum(parts == pdgid, axis=1)
                mask = mask & (counts >= min_count) & (counts <= max_count)

        if self.n_total is not None:
            total_counts = ak.num(parts, axis=1)
            min_total, max_total = self.n_total
            mask = mask & (total_counts >= min_total) & (total_counts <= max_total)

        arrays = arrays[None, mask]
        return {"arrays": arrays}


class BadMuonVeto(Processor):
    bad_muon: str
    bad_muon_high_pt: str
    is_high_pt_flag: str

    def __init__(self, quality_wp: str, use_mu_high_pt_threshold: bool = False, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}badMuonVeto")
        quality_wps = {
            "Medium": "mu_isBadMuon_Medium_NOSYS",
            "HighPt": "mu_isBadMuon_HighPt_NOSYS",
        }

        if quality_wp not in quality_wps:
            raise ValueError(f"Unknown quality WP: {quality_wp}.")

        self.attach_branch((quality_wps[quality_wp], "bad_muon"), is_varied=True)

        if use_mu_high_pt_threshold and quality_wp != "HighPt":
            self.attach_branch(("mu_isBadMuon_HighPt_NOSYS", "bad_muon_high_pt"), is_varied=True)
            self.attach_branch(("mu_is_high_pt_flag_NOSYS", "is_high_pt_flag"), is_varied=True)
            self.hybrid = True
        else:
            self.hybrid = False

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.hybrid:
            is_high_pt = arrays["mu", self.is_high_pt_flag]
            is_bad = ak.where(is_high_pt, arrays["mu", self.bad_muon_high_pt], arrays["mu", self.bad_muon])
        else:
            is_bad = arrays["mu", self.bad_muon]

        has_bad_muon = ak.any(is_bad, axis=1)
        arrays = arrays[None, ~has_bad_muon]

        return {"arrays": arrays}


class ElectronCrackVeto(Processor):
    el_eta: str

    def __init__(self, use_calo_cluster_eta: bool = False, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}electronCrackVeto")

        if use_calo_cluster_eta:
            self.attach_branch(("el_caloCluster_eta", "el_eta"), is_varied=False)
        else:
            self.attach_branch("el_eta", is_varied=False)

    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        abs_el_eta = np.abs(arrays["el", self.el_eta])
        in_crack = (abs_el_eta > 1.37) & (abs_el_eta < 1.52)

        has_crack_electron = ak.any(in_crack, axis=1)
        arrays = arrays[None, ~has_crack_electron]

        return {"arrays": arrays}


class ElectronScaleFactors(Processor):
    iso_sf: str
    pid_sf: str
    reco_sf: str
    charge_flip_sf: str

    def __init__(
        self, lh_wp: str, iso_wp: str, charge_flip: bool = False, save_weights: bool = False, prefix: str = ""
    ) -> None:
        super().__init__(name=f"{prefix}electronScaleFactor")
        if lh_wp not in {"Medium", "Tight"}:
            raise ValueError(f"Unknown likelihood WP: {lh_wp}.")

        if iso_wp not in {"Loose_VarRad", "Tight_VarRad"}:
            raise ValueError(f"Unknown isolation WP: {iso_wp}.")

        self.attach_branch((f"el_effSF_Isol_{lh_wp}_{iso_wp}_NOSYS", "iso_sf"), is_varied=True)
        self.attach_branch((f"el_effSF_PID_{lh_wp}_NOSYS", "pid_sf"), is_varied=True)
        self.attach_branch(("el_effSF_Reco_NOSYS", "reco_sf"), is_varied=True)

        self.charge_flip = charge_flip
        self.save_weights = save_weights

        if self.charge_flip:
            self.attach_branch((f"el_effSF_Chflip_{lh_wp}_{iso_wp}_NOSYS", "charge_flip_sf"), is_varied=True)

        if self.save_weights:
            self.attach_branch(("el_total_weight_NOSYS", "el_total_weight"), is_varied=True, is_created=True)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.is_data:
            return {"arrays": arrays}

        sf_iso = arrays["el", self.iso_sf]
        sf_pid = arrays["el", self.pid_sf]
        sf_reco = arrays["el", self.reco_sf]

        if self.charge_flip:
            sf_charge_flip = arrays["el", self.charge_flip_sf]
            total_sf = ak.prod(sf_iso * sf_pid * sf_reco * sf_charge_flip, axis=-1)
        else:
            total_sf = ak.prod(sf_iso * sf_pid * sf_reco, axis=-1)

        arrays["total_weight"] = arrays["total_weight"] * total_sf

        if self.save_weights:
            arrays.add_varied_array(
                total_sf,
                "el_total_weight",
                variation="nominal" if self.current_variation is None else self.current_variation,
                variation_map=self.variation_map,
            )

        return {"arrays": arrays}


class MuonScaleFactors(Processor):
    reco_high_pt_sf: str
    bad_muon_high_pt_sf: str
    reco_sf: str
    iso_sf: str
    ttva_sf: str
    is_high_pt_flag: str

    def __init__(
        self,
        quality_wp: str,
        iso_wp: str,
        use_mu_high_pt_threshold: bool = False,
        save_weights: bool = False,
        prefix: str = "",
    ) -> None:
        super().__init__(name=f"{prefix}muonScaleFactor")
        if quality_wp not in {"Medium", "HighPt"}:
            raise ValueError(f"Unknown quality WP: {quality_wp}.")

        if iso_wp not in {"Loose_VarRad", "Tight_VarRad", "PflowLoose_VarRad", "PflowTight_VarRad"}:
            raise ValueError(f"Unknown isolation WP: {iso_wp}.")

        if quality_wp == "HighPt":
            self.attach_branch(("mu_effSF_Reco_HighPt_NOSYS", "reco_high_pt_sf"), is_varied=True)
            self.attach_branch(("mu_effSF_BadMuonVeto_HighPt_NOSYS", "bad_muon_high_pt_sf"), is_varied=True)
            self.mode = "high_pt"
        elif use_mu_high_pt_threshold:
            self.attach_branch((f"mu_effSF_Reco_{quality_wp}_NOSYS", "reco_sf"), is_varied=True)
            self.attach_branch(("mu_effSF_Reco_HighPt_NOSYS", "reco_high_pt_sf"), is_varied=True)
            self.attach_branch(("mu_effSF_BadMuonVeto_HighPt_NOSYS", "bad_muon_high_pt_sf"), is_varied=True)
            self.attach_branch(("mu_is_high_pt_flag_NOSYS", "is_high_pt_flag"), is_varied=True)
            self.mode = "hybrid"
        else:
            self.attach_branch((f"mu_effSF_Reco_{quality_wp}_NOSYS", "reco_sf"), is_varied=True)
            self.mode = "standard"

        self.save_weights = save_weights

        self.attach_branch((f"mu_effSF_Isol_{iso_wp}_NOSYS", "iso_sf"), is_varied=True)
        self.attach_branch(("mu_effSF_TTVA_NOSYS", "ttva_sf"), is_varied=True)

        if self.save_weights:
            self.attach_branch(("mu_total_weight_NOSYS", "mu_total_weight"), is_varied=True, is_created=True)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.is_data:
            return {"arrays": arrays}

        if self.mode == "high_pt":
            sf_reco = arrays["mu", self.reco_high_pt_sf] * arrays["mu", self.bad_muon_high_pt_sf]
        elif self.mode == "hybrid":
            is_high_pt = arrays["mu", self.is_high_pt_flag]
            sf_reco = ak.where(
                is_high_pt,
                arrays["mu", self.reco_high_pt_sf] * arrays["mu", self.bad_muon_high_pt_sf],
                arrays["mu", self.reco_sf],
            )
        else:
            sf_reco = arrays["mu", self.reco_sf]

        sf_iso = arrays["mu", self.iso_sf]
        sf_ttva = arrays["mu", self.ttva_sf]

        total_sf = ak.prod(sf_iso * sf_reco * sf_ttva, axis=-1)

        arrays["total_weight"] = arrays["total_weight"] * total_sf

        if self.save_weights:
            arrays.add_varied_array(
                total_sf,
                "mu_total_weight",
                variation="nominal" if self.current_variation is None else self.current_variation,
                variation_map=self.variation_map,
            )

        return {"arrays": arrays}


@decorate_branches(("tau_passTATTauMuonOLR", "tau_pass_mu_olr"))
class TauPassMuonOLR(Processor):
    tau_pass_mu_olr: str

    def __init__(self, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}tauPassMuonOLR", disable_variations=True)

    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        mask = arrays["tau", self.tau_pass_mu_olr] == 1
        arrays["tau"] = arrays["tau"][mask]

        return {"arrays": arrays}


class TauScaleFactors(Processor):
    reco_sf: str
    id_sf: str
    eveto_sf: str

    def __init__(
        self,
        id_wp: str,
        use_eveto: bool = False,
        eveto_true_tau: bool = True,
        save_weights: bool = False,
        prefix: str = "",
    ) -> None:
        """Apply tau scale factors (Reco x ID x eVeto) to event weight.

        Parameters
        ----------
        id_wp : str
            Tau ID working point. Options are "Loose", "Medium", and "Tight".
        use_eveto : bool, optional
            Apply electron veto scale factor. Default is False.
        eveto_true_tau : bool, optional
            Use eVetoTrueTau SF (for true taus in signal regions) when True,
            or eVeto SF (for fake taus) when False. Default is True.
        save_weights : bool, optional
            Save per-tau total SF as a branch. Default is False.
        prefix : str, optional
            Prefix for the processor name, by default "".

        """
        super().__init__(name=f"{prefix}tauScaleFactor")
        if id_wp not in {"Loose", "Medium", "Tight"}:
            raise ValueError(f"Unknown tau ID WP: {id_wp}.")

        self.attach_branch(("tau_effSF_Reco_NOSYS", "reco_sf"), is_varied=True)
        self.attach_branch((f"tau_effSF_ID_{id_wp}_NOSYS", "id_sf"), is_varied=True)

        self.use_eveto = use_eveto
        self.save_weights = save_weights

        if self.use_eveto:
            eveto_prefix = "eVetoTrueTau" if eveto_true_tau else "eVeto"
            self.attach_branch((f"tau_effSF_{eveto_prefix}_{id_wp}_NOSYS", "eveto_sf"), is_varied=True)

        if self.save_weights:
            self.attach_branch(("tau_total_weight_NOSYS", "tau_total_weight"), is_varied=True, is_created=True)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.is_data:
            return {"arrays": arrays}

        sf_reco = arrays["tau", self.reco_sf]
        sf_id = arrays["tau", self.id_sf]

        if self.use_eveto:
            sf_eveto = arrays["tau", self.eveto_sf]
            total_sf = ak.prod(sf_reco * sf_id * sf_eveto, axis=-1)
        else:
            total_sf = ak.prod(sf_reco * sf_id, axis=-1)

        arrays["total_weight"] = arrays["total_weight"] * total_sf

        if self.save_weights:
            arrays.add_varied_array(
                total_sf,
                "tau_total_weight",
                variation="nominal" if self.current_variation is None else self.current_variation,
                variation_map=self.variation_map,
            )

        return {"arrays": arrays}
