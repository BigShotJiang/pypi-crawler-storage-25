import re

import numpy as np

VALID_BRANCH_GROUPS = {"el", "mu", "tau", "jet", "met", "weight"}
VALID_VARIATIONS = {"EG", "MUON", "TAUS", "JET", "MET", "EL_EFF", "MUON_EFF", "FT_EFF", "GEN", "extrapolation"}
VALID_VARIATIONS_SORTED = sorted(VALID_VARIATIONS, key=len, reverse=True)
VALID_VARIATIONS_PATTERN = rf"_({'|'.join(map(re.escape, VALID_VARIATIONS))})_(.*?)__"

TRIGGER_PT: dict[str, float] = {
    "ptBaseline": 30.0,
    "ptBaselineLow": 10.0,
    "pt10": 11.0,
    "pt12": 13.0,
    "pt14": 15.0,
    "pt15": 16.0,
    "pt17": 18.0,
    "pt18": 19.0,
    "pt20": 21.0,
    "pt22": 23.0,
    "pt24": 25.0,
    "pt26": 27.0,
    "pt28": 29.0,
    "pt30": 31.0,
    "pt40": 42.0,
    "pt50": 53.0,
    "pt60": 65.0,
    "pt70": 75.0,
    "pt80": 85.0,
    "pt100": 105.0,
    "pt120": 126.0,
    "pt140": 147.0,
    "pt160": 168.0,
    "ptUnprescaledEl": 315.0,
    "ptUnprescaledMu": 53.0,
    "ptMax": np.inf,
}

DATA_RUN_NUMBERS: dict[int, tuple[int, int]] = {
    15: (0, 290000),
    16: (290000, 324000),
    1516: (0, 324000),
    17: (324000, 348000),
    171: (324000, 326834),
    170: (326834, 328394),
    172: (328394, 348000),
    18: (348000, 410000),
    22: (410000, 448000),
    23: (448000, 470000),
    24: (470000, 490000),
    25: (490000, 999999),
}

ELECTRON_PDGID = 11
MUON_PDGID = 13
TAU_PDGID = 15

ELECTRON_MASS_GEV = 0.510998 / 1000.0
MUON_MASS_GEV = 105.6583715 / 1000.0
TAU_MASS_GEV = 1776.86 / 1000.0

LUMINOSITY_MAP = {
    "MC16a": 3244.54 + 33402.2,
    "MC16d": 44630.6,
    "MC16e": 58791.6,
    "MC23a": 26328.8,
    "MC23d": 25204.3,
    "MC23e": 109400.0,
}

LUMINOSITY_DATA_MAP = {
    15: 3244.54,
    16: 33402.2,
    17: 44630.6,
    18: 58791.6,
    22: 26328.8,
    23: 25204.3,
    24: 109400.0,
}


def find_variation_in_branch(branch: str) -> str | None:
    match = re.search(VALID_VARIATIONS_PATTERN, branch)

    if match:
        variation, payload = match.groups()
        result = f"{variation}_{payload}"
    else:
        result = None

    return result


def get_luminosity(campaign: str | None = None, year: int | None = None) -> float:
    if year is not None:
        if year not in LUMINOSITY_DATA_MAP:
            raise ValueError(f"Luminosity for year {year} is not defined!")

        return LUMINOSITY_DATA_MAP[year]

    match campaign:
        case "MC20a":
            campaign = "MC16a"
        case "MC20d":
            campaign = "MC16d"
        case "MC20e":
            campaign = "MC16e"
        case _:
            pass

    if campaign not in LUMINOSITY_MAP:
        raise ValueError(f"Luminosity for campaign {campaign} is not defined!")

    return LUMINOSITY_MAP[campaign]


def get_year_from_campaign(campaign: str) -> int:
    match campaign:
        case "MC20a":
            year = 1516
        case "MC20d":
            year = 17
        case "MC20e":
            year = 18
        case "MC23a":
            year = 22
        case "MC23d":
            year = 23
        case "MC23e":
            year = 24
        case _:
            raise RuntimeError(f"Unknown campaign: {campaign}!")

    return year


def get_campaign_from_year(year: int) -> str:
    match year:
        case 15:
            campaign = "MC20a"
        case 16:
            campaign = "MC20a"
        case 1516:
            campaign = "MC20a"
        case 17:
            campaign = "MC20d"
        case 18:
            campaign = "MC20e"
        case 22:
            campaign = "MC23a"
        case 23:
            campaign = "MC23d"
        case 24:
            campaign = "MC23e"
        case _:
            raise RuntimeError(f"Unknown year: {year}!")

    return campaign
