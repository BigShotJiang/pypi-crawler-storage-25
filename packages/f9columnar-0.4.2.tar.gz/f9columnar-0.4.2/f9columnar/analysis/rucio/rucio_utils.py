import logging
import os
import re
import subprocess
from glob import glob
from io import StringIO

import pandas as pd
import uproot

from f9columnar.analysis.rucio.clean_metadata import clean_metadata_root_files
from f9columnar.utils.helpers import dump_json, load_json
from f9columnar.utils.loggers import get_progress


class RucioHandler:
    def __init__(
        self,
        data_path: str | None = None,
        metadata_path: str | None = None,
        dataset_scope: str | None = None,
    ) -> None:
        """Handler for managing Rucio data downloads and operations.

        This class provides utilities for downloading and managing datasets from Rucio,
        including histogram files and datasets from specific RSEs (Rucio Storage Elements).

        Parameters
        ----------
        data_path : str or None, optional
            Path where data will be stored. If None, uses the COLUMNAR_DATA_PATH
            environment variable. Default is None.
        metadata_path : str or None, optional
            Path where metadata will be stored. If None, uses the same path as data_path. Default is None.
        dataset_scope : str or None, optional
            Rucio sample identifier string. If None, uses the COLUMNAR_RUCIO_DATASET_SCOPE
            environment variable. Default is None.

        Attributes
        ----------
        data_path : str
            Path where data is stored.
        dataset_scope : str
            Rucio sample identifier string.

        Methods
        -------
        get_hists_dids()
            Retrieve histogram dataset identifiers (DIDs) from Rucio.
        get_hists()
            Download histogram files from Rucio (metadata).
        make_rse_files(rse="SIGNET_LOCALGROUPDISK")
            Create a list of datasets available on a specific RSE.
        get_replicas(rse="SIGNET_LOCALGROUPDISK")
            Retrieve file replicas for datasets from a specific RSE.
        download_from_file_list(file_lst, dir_name)
            Download files from Rucio based on a provided list.

        Note
        ----
        From inside a virtual environment, ensure Rucio is set up with
        `setupATLAS` and `lsetup rucio` commands.

        Raises
        ------
        ValueError
            If required environment variables are not set when parameters are None.
        """
        if data_path is None:
            env_data_path = os.environ.get("COLUMNAR_DATA_PATH", None)

            if env_data_path is None:
                raise ValueError("COLUMNAR_DATA_PATH environment variable not set!")

            self.data_path = env_data_path
        else:
            self.data_path = data_path

        self.metadata_path = metadata_path if metadata_path is not None else self.data_path

        if dataset_scope is None:
            env_dataset_scope = os.environ.get("COLUMNAR_RUCIO_DATASET_SCOPE", None)

            if env_dataset_scope is None:
                raise ValueError("COLUMNAR_RUCIO_DATASET_SCOPE environment variable not set!")

            self.dataset_scope = env_dataset_scope
        else:
            self.dataset_scope = dataset_scope

        os.makedirs(self.data_path, exist_ok=True)

    def get_hists_dids(self) -> list[str]:
        hists_path = f"{self.metadata_path}/hists"
        os.makedirs(hists_path, exist_ok=True)

        dids_file_path = f"{hists_path}/hists_dids.txt"

        if not os.path.exists(dids_file_path):
            logging.info("Generating hists DIDs file using Rucio.")

            with open(dids_file_path, "w") as f:
                result = subprocess.run(
                    [
                        "rucio",
                        "ls",
                        f"{self.dataset_scope}.*_hist",
                    ],
                    capture_output=True,
                    text=True,
                )

                if result.returncode != 0:
                    raise RuntimeError(f"Rucio ls command failed: {result.stderr}")

                f.write(result.stdout)
        else:
            logging.info("Hists DIDs already exist.")

        with open(dids_file_path, "r") as f:
            dids_file = f.readlines()

        pattern = r"\buser\.[^\s|]+"

        dids = []
        for line in dids_file:
            match = re.search(pattern, line)

            if match:
                dids.append(match.group())

        if len(dids) == 0:
            raise ValueError("No hists DIDs found!")

        return dids

    def get_hists(self, overwrite: bool = False, clean_patterns: list[str] | None = None) -> list[str]:
        hists_path = f"{self.metadata_path}/hists"

        hists_dirs = glob(f"{hists_path}/*/", recursive=True)

        if len(hists_dirs) > 0 and not overwrite:
            logging.info("Hists metadata already downloaded.")
            return hists_dirs

        _ = self.get_hists_dids()

        logging.info("Downloading hists metadata from Rucio.")
        result = subprocess.run(
            [
                "rucio",
                "download",
                "--dir",
                hists_path,
                f"{self.dataset_scope}.*_hist",
            ],
            capture_output=False,
            text=True,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Rucio download command failed: {result.stderr}")

        hists_dirs = glob(f"{hists_path}/*/", recursive=True)

        if len(hists_dirs) == 0:
            raise ValueError("No hists downloaded!")

        if clean_patterns is not None:
            logging.info("Cleaning metadata root files.")
            clean_metadata_root_files(hists_path, clean_patterns)

        return hists_dirs

    def make_rse_files(self, rse: str = "SIGNET_LOCALGROUPDISK") -> list[str]:
        rse_file_path = f"{self.metadata_path}/rse_files.txt"

        if not os.path.exists(rse_file_path):
            logging.info("Generating RSE files list using Rucio.")

            with open(rse_file_path, "w") as f:
                result = subprocess.run(
                    [
                        "rucio",
                        "list-datasets-rse",
                        rse,
                    ],
                    capture_output=True,
                    text=True,
                )

                if result.returncode != 0:
                    raise RuntimeError(f"Rucio list-datasets-rse command failed: {result.stderr}")

                f.write(result.stdout)
        else:
            logging.info("RSE files list already exists.")

        with open(rse_file_path, "r") as f:
            rse_files = f.readlines()

        return rse_files

    def get_replicas(self, rse: str = "SIGNET_LOCALGROUPDISK") -> pd.DataFrame:
        if os.path.exists(f"{self.metadata_path}/rucio_replicas.csv"):
            logging.info("Rucio replicas file already exists.")
            return pd.read_csv(f"{self.metadata_path}/rucio_replicas.csv")

        hists_dirs = self.get_hists()

        dids = []
        for hist_dir in hists_dirs:
            dids.append(hist_dir.split("/")[-2].replace("_hist", "_tree"))

        rucio_command_func = lambda did: [
            "rucio",
            "list-file-replicas",
            did,
            "--rse",
            rse,
        ]

        progress = get_progress()
        progress.start()
        task = progress.add_task("[cyan]Processing DIDs...", total=len(dids))

        dfs = []
        for did in dids:
            rucio_command = rucio_command_func(did)
            result = subprocess.run(rucio_command, capture_output=True, text=True)

            if result.returncode != 0:
                raise RuntimeError(f"Rucio command failed for {did}: {result.stderr}")

            if not result.stdout.strip():
                logging.info(f"Empty output for {did}.")
                continue

            output = result.stdout
            output_split = output.splitlines()

            header = output_split[1].replace(" ", "")[1:-1].split("|")
            header = [h.lower() for h in header]

            output_split = [line.strip("|") for line in output_split]

            table = "\n".join(output_split[3:-1]).replace(" ", "")

            df = pd.read_csv(StringIO(table), delimiter=r"|", names=header)

            df[["rse", "replica"]] = df["rse:replica"].str.split(":", n=1, expand=True)
            df = df.drop("rse:replica", axis=1)

            dfs.append(df)

            progress.advance(task)

        progress.stop()

        full_df = pd.concat(dfs, ignore_index=True)
        full_df.to_csv(f"{self.metadata_path}/rucio_replicas.csv", index=False)

        return full_df

    def download_from_file_list(self, file_lst: list[str], files_path: str | None) -> list[str] | None:
        if files_path is None:
            files_path = f"{self.data_path}/test_files"
            os.makedirs(files_path, exist_ok=True)

        present_files = glob(f"{files_path}/*")
        for f in present_files:
            base_f = os.path.basename(f)
            if base_f in file_lst:
                file_lst.remove(base_f)

        if len(file_lst) == 0:
            logging.info("All files already downloaded.")
            return None

        logging.info(f"Downloading {len(file_lst)} files from Rucio.")
        result = subprocess.run(
            ["rucio", "download"]
            + file_lst
            + [
                "--no-subdir",
                "--dir",
                files_path,
            ],
            capture_output=False,
            text=True,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Rucio download command failed: {result.stderr}")

        return file_lst

    def get_events_per_file(self) -> dict[str, int]:
        file_path = f"{self.metadata_path}/events_per_file.json"

        if os.path.exists(file_path):
            logging.info("Events per file data already exists.")
            return load_json(file_path)["n_events"]

        hists_dirs = self.get_hists()

        logging.info("Getting events per file from histogram metadata.")

        progress = get_progress()
        progress.start()
        task = progress.add_task("Counting events per file", total=len(hists_dirs))

        events_per_file: dict[str, int] = {}
        for hist_dir in hists_dirs:
            root_files = glob(f"{hist_dir}/*.tree_metadata.root", recursive=True)
            subtask = progress.add_task("Reading root files", total=len(root_files))

            for root_file in root_files:
                with uproot.open(root_file) as f:
                    has_event_count = False
                    for k in f.keys():
                        if "EventLoop_EventCount" in k:
                            events_per_file[root_file] = int(f[k].values()[-1])
                            has_event_count = True
                            break

                    if not has_event_count:
                        logging.warning(f"Setting event count to 0 for {root_file}. No EventLoop_EventCount found.")
                        events_per_file[root_file] = 0

                progress.advance(subtask)

            progress.remove_task(subtask)
            progress.advance(task)

        progress.stop()

        dump_json({"n_events": events_per_file}, f"{self.metadata_path}/events_per_file.json")

        return events_per_file


def make_rucio_url(user: str, file: str) -> str:
    """Make a rucio URL for batch processing.

    Example
    -------
    rucio://rucio-lb-prod.cern.ch/replicas/user.jedebevc/user.jedebevc.00278912.physics_Main.r9264_p3083_p5314.39484806._000035.tree.root

    Parameters
    ----------
    user : str
        Rucio user.
    file : str
        Root file.

    Returns
    -------
    str
        URL for rucio file.
    """
    base_url = "rucio://rucio-lb-prod.cern.ch/replicas"
    return f"{base_url}/user.{user}/{file}"
