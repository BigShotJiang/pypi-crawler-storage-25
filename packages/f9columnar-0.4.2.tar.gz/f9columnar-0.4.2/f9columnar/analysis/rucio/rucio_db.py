import copy
import logging
import os
from dataclasses import dataclass
from glob import glob
from typing import Any, Self

import numpy as np
import pandas as pd
import uproot

from f9columnar.utils.helpers import load_json
from f9columnar.utils.loggers import get_progress
from f9columnar.utils.regex_helpers import (
    extract_campaign_from_file,
    extract_dsid_from_file,
    extract_user_from_file,
    extract_year_from_file,
)


@dataclass
class HistDataFile:
    file_path: str
    year: int
    is_data: bool = True
    n_events: int = 0

    def __post_init__(self) -> None:
        self._file_name = self.file_path.split("/")[-1].split(".")[3]
        self._full_file_name = ".".join(self.file_path.split("/")[-1].split(".")[:-2])

    @property
    def file_name(self) -> str:
        return self._file_name

    @property
    def full_file_name(self) -> str:
        return self._full_file_name

    def as_dict(self) -> dict[str, Any]:
        return {
            "file_name": self.file_name,
            "full_file_name": self.full_file_name,
            "year": self.year,
            "is_data": self.is_data,
            "n_events": self.n_events,
        }

    def __str__(self) -> str:
        return f"HistDataFile(name={self.file_name}, year={self.year})"


@dataclass
class HistMCFile:
    file_path: str
    dsid: int
    campaign: str
    is_data: bool = False
    n_events: int = 0

    def _get_sow(self) -> dict[str, float]:
        with uproot.open(self.file_path) as root_file:
            weight_key = None
            for k in root_file.keys():
                if "CutBookkeeper" in k and "NOSYS" in k:  # TODO: handle theory systematics
                    weight_key = k
                    break

            if weight_key is None:
                raise ValueError(f"No CutBookkeeper found in {self.file_path}!")

            labels = root_file[weight_key].axis(0).labels()
            values = root_file[weight_key].values()

        return dict(zip(labels, values))

    def __post_init__(self) -> None:
        self._file_name = self.file_path.split("/")[-1].split(".")[3]
        self._full_file_name = ".".join(self.file_path.split("/")[-1].split(".")[:-2])

        sow_dct = self._get_sow()

        self._initial_events = sow_dct["Initial events"]
        self._initial_sow = sow_dct["Initial sum of weights"]
        self._initial_sow_sq = sow_dct["Initial sum of weights squared"]

    @property
    def file_name(self) -> str:
        return self._file_name

    @property
    def full_file_name(self) -> str:
        return self._full_file_name

    @property
    def initial_events(self) -> int:
        return int(self._initial_events)

    @property
    def initial_sow(self) -> float:
        return self._initial_sow

    @property
    def initial_sow_sq(self) -> float:
        return self._initial_sow_sq

    def as_dict(self) -> dict[str, Any]:
        return {
            "file_name": self.file_name,
            "full_file_name": self.full_file_name,
            "dsid": self.dsid,
            "campaign": self.campaign,
            "initial_events": self.initial_events,
            "initial_sow": self.initial_sow,
            "initial_sow_sq": self.initial_sow_sq,
            "is_data": self.is_data,
            "n_events": self.n_events,
        }

    def __str__(self) -> str:
        return f"HistMCFile(name={self.file_name}, dsid={self.dsid}, campaign={self.campaign})"


@dataclass
class RucioHistDataset:
    dataset_path: str

    def __post_init__(self) -> None:
        self._dataset_name: str | None = None
        self._full_dataset_name: str | None = None
        self._version: str | None = None
        self._user: str | None = None
        self._data: list[HistDataFile | HistMCFile] = []

    def _setup_hist_files(self, data_file: str, n_events_dct: dict[str, int], ignore_files: set[str] | None) -> None:
        dsid = extract_dsid_from_file(data_file)
        campaign = extract_campaign_from_file(data_file)
        year = extract_year_from_file(data_file)

        n_events = n_events_dct.get(data_file, 0)

        h: HistDataFile | HistMCFile

        if dsid is None:
            if year is None:
                raise ValueError("Could not extract year from data file!")

            h = HistDataFile(file_path=data_file, year=year, n_events=n_events)
        else:
            if campaign is None:
                raise ValueError("Could not extract campaign from MC file!")

            h = HistMCFile(file_path=data_file, dsid=dsid, campaign=campaign, n_events=n_events)

        if ignore_files is not None:
            for ignore_file in ignore_files:
                if ignore_file == h.full_file_name:
                    logging.info(f"Ignoring file {ignore_file} as it is in the ignore list.")
                    return None

        self._data.append(h)

    def setup_hist(self, n_events_dct: dict[str, int] | None = None, ignore_files: set[str] | None = None) -> None:
        if n_events_dct is None:
            n_events_dct = {}

        self._full_dataset_name = ".".join(self.dataset_path.split("/")[-2].split(".")[:-1])
        self._dataset_name = self._full_dataset_name.split(".")[-1]
        self._version = self.dataset_path.split("/")[-2].split(".")[-1].split("_")[0]

        _user = extract_user_from_file(self.dataset_path)

        if _user is None:
            raise ValueError("Could not extract user from dataset path!")

        self._user = _user
        self._full_dataset_name += f".{self._version}"

        data_files = glob(f"{self.dataset_path}/*.tree_metadata.root")

        if len(data_files) == 0:
            raise ValueError("No data files found in dataset path!")

        with get_progress(transient=True) as progress:
            task = progress.add_task(f"Setting up {self._full_dataset_name.split('.')[-2]}", total=len(data_files))
            for data_file in data_files:
                self._setup_hist_files(data_file, n_events_dct, ignore_files)
                progress.advance(task)

    @property
    def dataset_name(self) -> str:
        if self._dataset_name is None:
            raise ValueError("Dataset not yet set up. Call setup_hist() first.")

        return self._dataset_name

    @property
    def full_dataset_name(self) -> str:
        if self._full_dataset_name is None:
            raise ValueError("Dataset not yet set up. Call setup_hist() first.")

        return self._full_dataset_name

    @property
    def version(self) -> str:
        if self._version is None:
            raise ValueError("Dataset not yet set up. Call setup_hist() first.")

        return self._version

    @property
    def user(self) -> str:
        if self._user is None:
            raise ValueError("Dataset not yet set up. Call setup_hist() first.")

        return self._user

    @property
    def data(self) -> list[HistDataFile | HistMCFile]:
        if len(self._data) == 0:
            raise ValueError("Dataset not yet set up. Call setup_hist() first.")

        return self._data

    def as_dict(self) -> dict[str, Any]:
        return {
            "dataset_name": self.dataset_name,
            "full_dataset_name": self.full_dataset_name,
            "version": self.version,
            "user": self.user,
            "data": self.data,
        }

    def __len__(self) -> int:
        return len(self._data)

    def __str__(self) -> str:
        return f"RucioHistDataset(name={self.dataset_name}, version={self.version}, num. datasets={len(self)})"


class RucioDB:
    def __init__(
        self,
        data_path: str | None = None,
        metadata_path: str | None = None,
        latest: bool = True,
        merge: bool = True,
        add_n_events: bool = True,
    ) -> None:
        """A database manager for Rucio histogram datasets (metadata).

        This class handles the discovery, parsing, and organization of ROOT histogram files
        that are used as metadata stored in a Rucio-like directory structure. It extracts
        metadata from file paths, reads sum-of-weights information from MC files, and provides
        a pandas DataFrame interface for querying the dataset collection.

        The class supports both data and MC files, automatically detecting the type based
        on the presence of DSID (dataset ID) in the file path. For MC files, it extracts
        additional metadata including campaign information and initial sum of weights from
        CutBookkeeper histograms.

        Parameters
        ----------
        data_path : str or None, optional
            Path to the root directory containing histogram datasets. If None, the path
            is read from the COLUMNAR_DATA_PATH environment variable. Default is None.
        metadata_path : str or None, optional
            Path to the directory containing metadata files. If None, uses data_path. Default is None.
        latest : bool, optional
            If True, only keeps the latest version of each dataset when multiple versions
            exist. Versions are determined lexicographically. Default is True.
        merge : bool, optional
            If True, merges initial sum of weights (sow) values across files with the same
            DSID and campaign, aggregating the statistics. Default is True.
        add_n_events : bool, optional
            If True, includes the initial number of events from files in the database.
            Default is True. Reads the events_per_file.json if available.

        Attributes
        ----------
        data_path : str
            The root directory path where histogram datasets are stored.
        merge : bool
            Whether to merge sum of weights across files.
        latest : bool
            Whether to keep only the latest version of each dataset.
        datasets : list[RucioHistDataset]
            List of parsed RucioHistDataset objects.
        rucio_db : pd.DataFrame or None
            DataFrame representation of the database, populated after calling to_dataframe().

        Methods
        -------
        to_dataframe(df_id='hists', force=False, hists_dir='hists', save=True)
            Builds or loads the Rucio database as a pandas DataFrame.

        Raises
        ------
        ValueError
            If data_path is None and COLUMNAR_DATA_PATH environment variable is not set.

        """
        if data_path is None:
            env_data_path = os.environ.get("COLUMNAR_DATA_PATH", None)

            if env_data_path is None:
                raise ValueError("COLUMNAR_DATA_PATH environment variable not set!")

            self.data_path = env_data_path
        else:
            self.data_path = data_path

        self.metadata_path = metadata_path if metadata_path is not None else self.data_path

        self.latest = latest
        self.merge = merge
        self.add_n_events = add_n_events

        self.ignore_files: set[str] | None = self._get_ignored_files()

        self.datasets: list[RucioHistDataset] = []

    def _get_ignored_files(self) -> set[str] | None:
        ignore_txt = f"{self.metadata_path}/ignore_files.txt"
        if not os.path.exists(ignore_txt):
            return None

        with open(ignore_txt, "r") as f:
            ignore_lst = [line.strip() for line in f if line.strip()]

        return set(ignore_lst)

    def _build_hists(self, hists_dir: str = "hists") -> Self:
        hists_path = f"{self.metadata_path}/{hists_dir}"
        hists_dirs = glob(f"{hists_path}/*/", recursive=True)

        if self.add_n_events:
            logging.info("Loading number of events.")
            n_events_dct = load_json(f"{self.metadata_path}/events_per_file.json")["n_events"]
        else:
            n_events_dct = None

        if self.ignore_files is not None:
            logging.info(f"Found ignore_files.txt with {len(self.ignore_files)} entries.")

        for dataset_path in hists_dirs:
            ds = RucioHistDataset(dataset_path=dataset_path)
            ds.setup_hist(n_events_dct=n_events_dct, ignore_files=self.ignore_files)
            self.datasets.append(ds)

        return self

    @staticmethod
    def _merge_initial_sow(df: pd.DataFrame) -> pd.DataFrame:
        logging.info("Merging initial sum of weights values.")

        merged_df = copy.deepcopy(df)

        dsids = merged_df["dsid"].unique()
        dsids = [dsid for dsid in dsids if not pd.isnull(dsid)]

        campaigns = merged_df["campaign"].unique()
        campaigns = [c for c in campaigns if not pd.isnull(c)]

        for dsid in dsids:
            for campaign in campaigns:
                sel = (merged_df["dsid"] == dsid) & (merged_df["campaign"] == campaign)

                sum_initial_sow = merged_df[sel]["initial_sow"].sum()
                sum_initial_sow_sq = merged_df[sel]["initial_sow_sq"].sum()

                merged_df.loc[sel, "initial_sow"] = sum_initial_sow
                merged_df.loc[sel, "initial_sow_sq"] = sum_initial_sow_sq

        return merged_df

    def to_dataframe(
        self, df_id: str = "hists", force: bool = False, hists_dir: str = "hists", save: bool = True
    ) -> pd.DataFrame:
        csv_path = f"{self.data_path}/rucio_{df_id}_df.csv"

        if not force and os.path.exists(csv_path):
            rucio_df = pd.read_csv(csv_path)
            rucio_df = rucio_df.replace({"NULL": np.nan})
            return rucio_df

        logging.info(f"Building Rucio DB from Rucio hists datasets using {self.metadata_path} metadata.")
        self._build_hists(hists_dir=hists_dir)

        df_lst = []
        for rucio_hist_dataset in self.datasets:
            dataset_dct = rucio_hist_dataset.as_dict()
            dataset_data_mc = dataset_dct.pop("data")

            for data_mc_dataset in dataset_data_mc:
                data_dct = data_mc_dataset.as_dict()
                data_dct.pop("file_path", None)
                df_lst.append({**dataset_dct, **data_dct})

        rucio_df = pd.DataFrame(df_lst)

        if self.latest:
            dataset_names, dfs = rucio_df["dataset_name"].unique(), []

            for dataset_name in dataset_names:
                versions = rucio_df[rucio_df["dataset_name"] == dataset_name]["version"].unique()
                keep_version = versions[-1]
                dfs.append(rucio_df[(rucio_df["dataset_name"] == dataset_name) & (rucio_df["version"] == keep_version)])

            rucio_df = pd.concat(dfs)

        if self.merge:
            rucio_df = self._merge_initial_sow(rucio_df)

        if save:
            rucio_df.to_csv(csv_path, index=False, sep=",", na_rep="NULL")
            logging.info(f"Rucio DB saved to {csv_path}.")

        return rucio_df

    def __len__(self) -> int:
        return len(self.datasets)

    def __call__(self, *args, **kwargs) -> pd.DataFrame:
        return self.to_dataframe(*args, **kwargs)
