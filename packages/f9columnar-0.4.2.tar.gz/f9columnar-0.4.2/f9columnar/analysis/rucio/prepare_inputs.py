import argparse
import logging

from f9columnar.analysis.config.analysis_config import AnalysisConfigBuilder
from f9columnar.analysis.rucio import RucioHandler
from f9columnar.utils.loggers import setup_logger


def main() -> None:
    setup_logger()

    parser = argparse.ArgumentParser(description="Prepare inputs for analysis. Use with SetupATLAS and lsetup rucio.")
    parser.add_argument(
        "-c",
        "--config",
        dest="config_path",
        required=True,
        help="Path to the analysis configuration YAML. The file should be located in the config directory.",
    )
    parser.add_argument(
        "-m",
        "--download-metadata",
        dest="download_metadata",
        required=False,
        default=False,
        action="store_true",
        help="Flag to download metadata histogram files from Rucio.",
    )
    parser.add_argument(
        "-t",
        "--download-test-files",
        dest="download_test_files",
        required=False,
        default=False,
        action="store_true",
        help="Flag to download test files from Rucio.",
    )
    parser.add_argument(
        "-s",
        "--skip-hists-download",
        dest="skip_hists_download",
        required=False,
        default=False,
        action="store_true",
        help="Flag to skip downloading histogram metadata files from Rucio.",
    )
    args = parser.parse_args()

    analysis_config_builder = AnalysisConfigBuilder(args.config_path)
    analysis_config = analysis_config_builder.build()

    dataset_scope = analysis_config.submit.dataset_scope

    if dataset_scope is None:
        raise ValueError("Dataset scope is not specified in the analysis configuration.")

    if "," in dataset_scope:
        dataset_scopes = [scope.strip() for scope in dataset_scope.split(",")]
    else:
        dataset_scopes = [dataset_scope]

    logging.info(f"Using dataset scopes: {dataset_scopes}.")

    rucio_handlers: list[RucioHandler] = []
    for scope in dataset_scopes:
        handler = RucioHandler(
            data_path=analysis_config.common.data_path,
            metadata_path=analysis_config.common.metadata_path,
            dataset_scope=scope,
        )
        rucio_handlers.append(handler)

    if args.download_metadata:
        if not args.skip_hists_download:
            for rucio_handler in rucio_handlers:
                rucio_handler.get_hists(overwrite=True, clean_patterns=None)

        rucio_handlers[0].get_events_per_file()

    if args.download_test_files:
        if not analysis_config.submit.local_run:
            raise ValueError("Downloading test files is only allowed for local runs!")

        test_files = analysis_config.submit.test_files
        if not test_files:
            raise ValueError("No test files specified in the analysis configuration!")

        logging.info(f"Downloading test files to {analysis_config.submit.ntuple_location}.")
        rucio_handlers[0].download_from_file_list(test_files, files_path=analysis_config.submit.ntuple_location)


if __name__ == "__main__":
    main()
