import glob
import logging
import os
import re
import shutil
import tarfile
from dataclasses import dataclass
from pathlib import Path

import hist

from f9columnar.histograms import resolve_combine_saved_hists
from f9columnar.utils.cut_flow import CutFlow, TimeFlow
from f9columnar.utils.helpers import dump_pickle, load_json
from f9columnar.utils.loggers import get_progress
from f9columnar.utils.regex_helpers import extract_process_name


@dataclass
class ProcessDirectory:
    process_name: str

    def __post_init__(self) -> None:
        self._files: list[str] = []

    def add_files(self, files_path: str) -> None:
        extracted_files = glob.glob(f"{files_path}/out/*")
        self._files.extend(extracted_files)

    def get_hists(self) -> list[str]:
        return [f for f in self._files if f.endswith("_hists.p")]

    def get_json_files(self) -> tuple[list[str], bool]:
        alternative_location = False
        json_files = [f for f in self._files if f.endswith(".json")]

        if len(json_files) == 0:
            alternative_location = True
            other_json_dir = Path(self._files[0]).parents[3]
            json_files = [str(f) for f in other_json_dir.glob("*.json")]

        return json_files, alternative_location

    def get_cut_flow(self) -> tuple[list[str], list[str], bool]:
        json_files, alternative_location = self.get_json_files()

        cut_flow_files, time_flow_files = [], []
        for f in json_files:
            if os.path.basename(f).startswith("cut_flow_"):
                cut_flow_files.append(f)
            elif os.path.basename(f).startswith("time_flow_"):
                time_flow_files.append(f)
            else:
                continue

        return cut_flow_files, time_flow_files, alternative_location


class ActMerger:
    def __init__(self, submit_dir: str, job_name: str, cleanup: bool = False, atlas_label: str | None = None) -> None:
        job_submit_dir = os.path.join(submit_dir, job_name)

        self.job_name = job_name
        self.cleanup = cleanup

        self.output_dir = os.path.join(job_submit_dir, "out")

        self.merged_dir = os.path.join(job_submit_dir, "merged")
        os.makedirs(self.merged_dir, exist_ok=True)

        env_atlas_label = os.environ.get("COLUMNAR_ATLAS_LABEL", None)
        self.atlas_label = atlas_label if atlas_label is not None else env_atlas_label

        if not os.path.exists(self.output_dir):
            raise ValueError(f"Output directory {self.output_dir} does not exist!")

        self.root_files_dir = os.path.join(self.output_dir, "root_files")
        os.makedirs(self.root_files_dir, exist_ok=True)

    def _extract_tar(self, file_path: str, output_dir: str) -> bool:
        try:
            with tarfile.open(file_path, "r:gz") as tar:
                tar.extractall(path=output_dir)
        except Exception:
            return False

        return True

    def _search_process_name(self, dir_name: str) -> str:
        result = extract_process_name(dir_name, self.job_name)
        if result == "unknown":
            raise ValueError(f"Could not find job name in directory name {dir_name}!")
        return result

    def _merge_hists(self, grouped_by_process: dict[str, ProcessDirectory]) -> None:
        merged_hists_by_process: dict[str, dict[str, dict[str, dict[str, hist.Hist]]]] = {}

        for process_name, process_dir in grouped_by_process.items():
            hists_files = process_dir.get_hists()
            if len(hists_files) == 0:
                continue

            merged_hists_by_process[process_name] = resolve_combine_saved_hists(files=hists_files)

        if len(merged_hists_by_process) == 0:
            logging.warning("No histograms found to merge.")
        else:
            merged_hists_path = os.path.join(self.merged_dir, f"{self.job_name}_merged_hists.p")
            dump_pickle(merged_hists_path, merged_hists_by_process)
            logging.info(f"Merged histograms saved to {merged_hists_path}.")

    def _merge_cut_flow(self, grouped_by_process: dict[str, ProcessDirectory], per_sample: bool = False) -> None:
        total_merged_cut_flow = CutFlow(self.merged_dir, atlas_label=self.atlas_label)
        total_merged_time_flow = TimeFlow(self.merged_dir, atlas_label=self.atlas_label)

        total_mc_n_events, total_mc_combined_time = 0, 0.0
        total_data_n_events, total_data_combined_time = 0, 0.0

        skip_plotting = True
        for process_name, process_dir in grouped_by_process.items():
            cut_flow_files, time_flow_files, alternative_location = process_dir.get_cut_flow()

            if len(cut_flow_files) == 0 and len(time_flow_files) == 0:
                continue
            else:
                skip_plotting = False

            if per_sample:
                merged_cut_flow = CutFlow(self.merged_dir, atlas_label=self.atlas_label)
                merged_time_flow = TimeFlow(self.merged_dir, atlas_label=self.atlas_label)

            n_mc_events, combined_mc_time = 0, 0.0
            n_data_events, combined_data_time = 0, 0.0

            for cut_flow_file in cut_flow_files:
                is_data = "data" in os.path.basename(cut_flow_file).lower()
                cut_flow_dct = load_json(cut_flow_file)["cut_flow"]

                if per_sample:
                    merged_cut_flow.update_from_dict(cut_flow_dct, is_data)

                total_merged_cut_flow.update_from_dict(cut_flow_dct, is_data)

            for time_flow_file in time_flow_files:
                is_data = "data" in os.path.basename(time_flow_file).lower()
                time_dct = load_json(time_flow_file)
                time_flow_dct = time_dct["time_flow"]
                n_workers = time_dct.get("n_workers", 1)

                if is_data:
                    n_data_events += time_dct["n_events"]
                    combined_data_time += time_dct["combined_time"]
                else:
                    n_mc_events += time_dct["n_events"]
                    combined_mc_time += time_dct["combined_time"]

                if per_sample:
                    merged_time_flow.update_from_dict(time_flow_dct, is_data, n_workers=n_workers)

                total_merged_time_flow.update_from_dict(time_flow_dct, is_data, n_workers=n_workers)

            if per_sample:
                for is_data in [False, True]:
                    merged_cut_flow.plot(is_data, dataset_name=process_name, disable_dump=True)
                    merged_time_flow.plot(
                        is_data,
                        dataset_name=process_name,
                        n_events=n_data_events if is_data else n_mc_events,
                        combined_time=combined_data_time if is_data else combined_mc_time,
                        disable_dump=True,
                    )

            total_data_n_events += n_data_events
            total_data_combined_time += combined_data_time

            total_mc_n_events += n_mc_events
            total_mc_combined_time += combined_mc_time

            if alternative_location:
                break

        if skip_plotting:
            logging.info("No cut flow or time flow data found to merge.")
            return None

        for is_data in [False, True]:
            total_merged_cut_flow.plot(is_data, dataset_name="total", disable_dump=True)
            total_merged_time_flow.plot(
                is_data,
                dataset_name="total",
                n_events=total_data_n_events if is_data else total_mc_n_events,
                combined_time=total_data_combined_time if is_data else total_mc_combined_time,
                disable_dump=True,
            )

    def _group_output_root_files(self, grouped_by_process: dict[str, ProcessDirectory]) -> None:
        root_dir = Path(self.root_files_dir)
        root_dir.mkdir(parents=True, exist_ok=True)

        moved_root_files = 0
        with get_progress() as progress:
            task = progress.add_task("Grouping ROOT files", total=len(grouped_by_process))
            for process_dir in grouped_by_process.values():
                root_files = [Path(f) for f in process_dir._files if f.endswith(".root")]

                for root_file in root_files:
                    dest_file = root_dir / f"{root_file.parent.parts[-2]}_{root_file.name}"
                    shutil.move(str(root_file), str(dest_file))
                    moved_root_files += 1

                progress.advance(task)

        logging.info(f"Moved {moved_root_files} ROOT files to {self.root_files_dir}.")

    def merge(self) -> None:
        dirs = []
        for entry in os.scandir(self.output_dir):
            has_tar = os.path.exists(os.path.join(entry.path, "out.tar.gz"))
            has_out = os.path.isdir(os.path.join(entry.path, "out"))
            if entry.is_dir() and (has_tar or has_out):
                dirs.append(entry.path)

        if len(dirs) == 0:
            raise ValueError(f"No output directories found in {self.output_dir}!")

        logging.info(f"Found {len(dirs)} output directories.")

        grouped_by_process: dict[str, ProcessDirectory] = {}

        with get_progress() as progress:
            task = progress.add_task("Checking output directories", total=len(dirs))
            for out_dir in dirs:
                if not os.path.isdir(os.path.join(out_dir, "out")):
                    valid = self._extract_tar(os.path.join(out_dir, "out.tar.gz"), out_dir)
                    if not valid:
                        logging.warning(f"Failed to extract {os.path.join(out_dir, 'out.tar.gz')}. Skipping...")
                        continue

                process_name = self._search_process_name(out_dir)

                if process_name not in grouped_by_process:
                    grouped_by_process[process_name] = ProcessDirectory(process_name)

                grouped_by_process[process_name].add_files(out_dir)
                progress.advance(task)

        logging.info("Starting to merge outputs...")

        self._merge_hists(grouped_by_process)
        self._merge_cut_flow(grouped_by_process)
        self._group_output_root_files(grouped_by_process)

        if self.cleanup:
            logging.info("Cleaning up extracted output directories...")
            for out_dir in dirs:
                if os.path.isdir(os.path.join(out_dir, "out")):
                    shutil.rmtree(os.path.join(out_dir, "out"))
