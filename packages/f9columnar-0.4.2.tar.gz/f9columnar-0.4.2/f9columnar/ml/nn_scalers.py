from __future__ import annotations

from abc import abstractmethod

import torch
import torch.nn as nn

from f9columnar.ml.scalers import CategoricalFeatureScaler, NumerCategDatasetScaler, NumericalFeatureScaler
from f9columnar.utils.data_containers import ColumnSelection
from f9columnar.utils.helpers import INVALID_CATEG_TOKEN

SUPPORTED_NN_SCALERS = {"standard", "minmax", "logit", "standard_logit", "categorical"}


class NNFeatureScaler(nn.Module):
    """Base class for wrapping NumericalFeatureScaler statistics in a torch nn.Module."""

    def __init__(self, scaler: NumericalFeatureScaler) -> None:
        super().__init__()
        if not scaler.is_fitted:
            raise ValueError("Scaler must be fitted before wrapping in an nn.Module!")

    @abstractmethod
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        pass

    @abstractmethod
    def inverse(self, x: torch.Tensor) -> torch.Tensor:
        pass


class NNStandardScaler(NNFeatureScaler):
    """Wraps a fitted NumericalFeatureScaler with StandardScaler in a torch nn.Module.

    Registers mean and scale as non-trainable buffers so they move with
    the model across devices and are included in state_dict.

    Applies: X_scaled = (X - mean) / scale

    """

    mean: torch.Tensor
    scale: torch.Tensor

    def __init__(self, scaler: NumericalFeatureScaler) -> None:
        super().__init__(scaler)

        sklearn_scaler = scaler.scaler
        if not hasattr(sklearn_scaler, "mean_") or not hasattr(sklearn_scaler, "scale_"):
            raise ValueError("Underlying sklearn scaler does not have mean_/scale_ attributes (not a StandardScaler?).")

        self.register_buffer("mean", torch.tensor(sklearn_scaler.mean_, dtype=torch.float32))
        self.register_buffer("scale", torch.tensor(sklearn_scaler.scale_, dtype=torch.float32))

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return (x - self.mean) / self.scale

    @torch.no_grad()
    def inverse(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.scale + self.mean


class NNMinMaxScaler(NNFeatureScaler):
    """Wraps a fitted NumericalFeatureScaler with MinMaxScaler in a torch nn.Module.

    Registers the following as non-trainable buffers:
        - data_min: minimum value observed in the training data per feature.
        - data_range: (data_max - data_min) per feature, i.e. the span of the training data.
        - feature_min: desired lower bound of the output range (from sklearn's feature_range parameter).
        - feature_range: desired span of the output range (feature_max - feature_min).

    Applies: X_scaled = (X - data_min) / data_range * feature_range + feature_min

    """

    data_min: torch.Tensor
    data_range: torch.Tensor
    feature_min: torch.Tensor
    feature_range: torch.Tensor

    def __init__(self, scaler: NumericalFeatureScaler) -> None:
        super().__init__(scaler)

        sklearn_scaler = scaler.scaler
        if not hasattr(sklearn_scaler, "data_min_") or not hasattr(sklearn_scaler, "data_range_"):
            raise ValueError(
                "Underlying sklearn scaler does not have data_min_/data_range_ attributes (not a MinMaxScaler?)."
            )

        self.register_buffer("data_min", torch.tensor(sklearn_scaler.data_min_, dtype=torch.float32))
        self.register_buffer("data_range", torch.tensor(sklearn_scaler.data_range_, dtype=torch.float32))
        self.register_buffer("feature_min", torch.tensor(sklearn_scaler.feature_range[0], dtype=torch.float32))
        self.register_buffer(
            "feature_range",
            torch.tensor(sklearn_scaler.feature_range[1] - sklearn_scaler.feature_range[0], dtype=torch.float32),
        )

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return (x - self.data_min) / self.data_range * self.feature_range + self.feature_min

    @torch.no_grad()
    def inverse(self, x: torch.Tensor) -> torch.Tensor:
        return (x - self.feature_min) / self.feature_range * self.data_range + self.data_min


class NNLogitScaler(NNFeatureScaler):
    """Wraps a fitted NumericalFeatureScaler with Pipeline(MinMaxScaler, LogitTransform) in a torch nn.Module.

    Applies: X_scaled = logit(clamp(minmax(X)))
        where minmax(X) = (X - data_min) / data_range, clamped to [0, 1]
        and   logit(x)  = log(x' / (1 - x'))  with x' = x * (1 - alpha) + 0.5 * alpha

    The clamp prevents float32 rounding from pushing MinMax output outside [0, 1],
    which would cause logit to produce NaN or extreme values.

    """

    data_min: torch.Tensor
    data_range: torch.Tensor

    def __init__(self, scaler: NumericalFeatureScaler) -> None:
        super().__init__(scaler)

        pipeline = scaler.scaler
        minmax_scaler = pipeline.named_steps["minmax"]
        logit_step = pipeline.named_steps["logit"]

        self.register_buffer("data_min", torch.tensor(minmax_scaler.data_min_, dtype=torch.float32))
        self.register_buffer("data_range", torch.tensor(minmax_scaler.data_range_, dtype=torch.float32))
        self.alpha = logit_step.alpha

    def _minmax_forward(self, x: torch.Tensor) -> torch.Tensor:
        return ((x - self.data_min) / self.data_range).clamp(0.0, 1.0)

    def _minmax_inverse(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.data_range + self.data_min

    def _logit(self, x: torch.Tensor) -> torch.Tensor:
        x = x * (1 - self.alpha) + 0.5 * self.alpha
        return torch.log(x / (1 - x))

    def _logistic(self, x: torch.Tensor) -> torch.Tensor:
        x = (x - 0.5 * self.alpha) / (1 - self.alpha)
        return 1 / (1 + torch.exp(-x))

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self._logit(self._minmax_forward(x))

    @torch.no_grad()
    def inverse(self, x: torch.Tensor) -> torch.Tensor:
        return self._minmax_inverse(self._logistic(x))


class NNStandardLogitScaler(NNLogitScaler):
    """Wraps a fitted NumericalFeatureScaler with Pipeline(MinMaxScaler, LogitTransform, StandardScaler).

    Applies: X_scaled = standard(logit(clamp(minmax(X))))

    """

    mean: torch.Tensor
    scale: torch.Tensor

    def __init__(self, scaler: NumericalFeatureScaler) -> None:
        # bypass NNLogitScaler.__init__ since pipeline step names differ
        NNFeatureScaler.__init__(self, scaler)

        pipeline = scaler.scaler
        minmax_scaler = pipeline.named_steps["sigmoid transform"]
        logit_step = pipeline.named_steps["logit transform"]
        standard_scaler = pipeline.named_steps["normal transform"]

        self.register_buffer("data_min", torch.tensor(minmax_scaler.data_min_, dtype=torch.float32))
        self.register_buffer("data_range", torch.tensor(minmax_scaler.data_range_, dtype=torch.float32))
        self.alpha = logit_step.alpha
        self.register_buffer("mean", torch.tensor(standard_scaler.mean_, dtype=torch.float32))
        self.register_buffer("scale", torch.tensor(standard_scaler.scale_, dtype=torch.float32))

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return (self._logit(self._minmax_forward(x)) - self.mean) / self.scale

    @torch.no_grad()
    def inverse(self, x: torch.Tensor) -> torch.Tensor:
        return self._minmax_inverse(self._logistic(x * self.scale + self.mean))


class NNCategoricalScaler(nn.Module):
    """Wraps a fitted CategoricalFeatureScaler in a torch nn.Module.

    For each column, stores the original category values as a buffer (category_keys).
    Forward maps original category values to sequential indices.
    Inverse maps indices back to original category values.
    Preserves invalid_categ_token (-2147483648) in both directions.

    """

    invalid_categ_token: int = int(INVALID_CATEG_TOKEN)
    float_invalid_categ_token: float = float(INVALID_CATEG_TOKEN)

    category_keys: torch.Tensor
    n_categories: torch.Tensor

    def __init__(self, scaler: CategoricalFeatureScaler) -> None:
        super().__init__()
        if not scaler.is_fitted:
            raise ValueError("Scaler must be fitted before wrapping in an nn.Module!")

        n_columns = len(scaler.categories)
        max_cats = max(len(d) for d in scaler.categories)

        # category_keys[col, idx] = original float value for that index
        keys = torch.full((n_columns, max_cats), fill_value=float("nan"), dtype=torch.float32)
        n_cats = torch.zeros(n_columns, dtype=torch.long)

        for col, cat_dict in enumerate(scaler.categories):
            for orig_val, idx in cat_dict.items():
                keys[col, idx] = orig_val
            n_cats[col] = len(cat_dict)

        self.register_buffer("category_keys", keys)
        self.register_buffer("n_categories", n_cats)

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Map original category values to indices. Returns a long tensor."""
        out = torch.full(x.shape, self.invalid_categ_token, dtype=torch.long, device=x.device)

        for col in range(x.shape[-1]):
            x_col = x[..., col]
            keys = self.category_keys[col]  # NaN-padded beyond valid categories

            invalid_mask = x_col == self.invalid_categ_token

            # (... , n_cats) broadcast comparison — NaN padding never matches
            matches = x_col.unsqueeze(-1) == keys
            matched_any = matches.any(dim=-1)
            indices = matches.to(torch.long).argmax(dim=-1)

            indices[~matched_any | invalid_mask] = self.invalid_categ_token
            out[..., col] = indices

        return out

    @torch.no_grad()
    def inverse(self, x: torch.Tensor) -> torch.Tensor:
        """Map indices back to original category values. Returns a float tensor."""
        max_cat = self.category_keys.shape[-1] - 1
        out = torch.full(x.shape, self.float_invalid_categ_token, dtype=torch.float32, device=x.device)

        for col in range(x.shape[-1]):
            x_col = x[..., col].long()
            keys = self.category_keys[col]

            valid_mask = x_col != self.invalid_categ_token
            safe_indices = x_col.clamp(0, max_cat)
            out[..., col] = keys[safe_indices]
            out[..., col][~valid_mask] = self.float_invalid_categ_token

        return out


class NNDatasetScaler(nn.Module):
    def __init__(self, scaler_util: NumerCategDatasetScaler, selection: ColumnSelection) -> None:
        """Composite scaler that wraps per-dataset (events, electrons, jets, …) scalers as a single nn.Module.

        Each dataset in the ColumnSelection has its own numerical and categorical scaler.
        This module applies the correct scaler to the correct feature columns of each dataset.

        Parameters
        ----------
        scaler_util : NumerCategDatasetScaler
            Pre-fitted scaler utility containing per-dataset sklearn-based scalers.
        selection : ColumnSelection
            Column selection mapping dataset names to their column specifications.

        """
        super().__init__()

        # ensure "events" is first, remaining follow selection order
        all_keys = list(selection.keys())
        if "events" in all_keys:
            all_keys.remove("events")
            all_keys.insert(0, "events")

        self.dataset_names = all_keys

        self.numer_scalers = nn.ModuleDict()
        self.categ_scalers = nn.ModuleDict()

        self.pad_values: dict[str, float | None] = {}

        for name in self.dataset_names:
            ds_col = selection[name]

            self.pad_values[name] = ds_col.pad_value
            self.register_buffer(f"{name}_numer_idx", torch.tensor(ds_col.offset_numer_columns_idx, dtype=torch.long))
            self.register_buffer(f"{name}_categ_idx", torch.tensor(ds_col.offset_categ_columns_idx, dtype=torch.long))

            numer_scaler = scaler_util.numer_feature_scaler_dct.get(name)
            categ_scaler = scaler_util.categ_feature_scaler_dct.get(name)

            if numer_scaler is not None:
                nn_cls = self._select_nn_scaler(numer_scaler.scaler_type)
                self.numer_scalers[name] = nn_cls(numer_scaler)

            if categ_scaler is not None:
                self.categ_scalers[name] = NNCategoricalScaler(categ_scaler)

        self.numer_scaling_enabled = not scaler_util.disable_numer_scaling
        self.categ_scaling_enabled = not scaler_util.disable_categ_scaling

    @staticmethod
    def _select_nn_scaler(scaler_type: str | None) -> type[nn.Module]:
        if scaler_type == "standard":
            return NNStandardScaler
        elif scaler_type == "minmax":
            return NNMinMaxScaler
        elif scaler_type == "logit":
            return NNLogitScaler
        elif scaler_type == "standard_logit":
            return NNStandardLogitScaler
        elif scaler_type == "categorical":
            return NNCategoricalScaler
        else:
            raise ValueError(f"Unsupported scaler type: {scaler_type}! Supported types: {SUPPORTED_NN_SCALERS}.")

    def _padding_mask(self, x: torch.Tensor, pad_value: float) -> torch.Tensor:
        """Return a boolean mask that is True for non-padded rows (all features != pad_value)."""
        return ~(x == pad_value).all(dim=-1)

    def _apply_scaler(
        self,
        x: torch.Tensor,
        dataset_name: str,
        inverse: bool = False,
    ) -> torch.Tensor:
        numer_idx: torch.Tensor = getattr(self, f"{dataset_name}_numer_idx")
        categ_idx: torch.Tensor = getattr(self, f"{dataset_name}_categ_idx")

        pad_value = self.pad_values[dataset_name]

        # compute padding mask before modifications
        # pad_mask: True = valid (non-padded), broadcastable over features
        pad_mask: torch.Tensor | None = None
        if pad_value is not None:
            pad_mask = self._padding_mask(x, pad_value).unsqueeze(-1)

        # use out-of-place scatter to avoid in-place indexed assignment for ONNX
        if dataset_name in self.numer_scalers and numer_idx.numel() > 0:
            if inverse:
                scaled_numer = self.numer_scalers[dataset_name].inverse(x[..., numer_idx])  # type: ignore[operator]
            else:
                scaled_numer = self.numer_scalers[dataset_name](x[..., numer_idx])

            scaled_numer = torch.nan_to_num(scaled_numer, nan=0.0)  # NaN flag invalid rows

            idx_expanded = numer_idx.expand(*x.shape[:-1], -1)
            x = x.scatter(-1, idx_expanded, scaled_numer)

        if dataset_name in self.categ_scalers and categ_idx.numel() > 0:
            if inverse:
                scaled_categ = self.categ_scalers[dataset_name].inverse(x[..., categ_idx]).to(x.dtype)  # type: ignore[operator]
            else:
                scaled_categ = self.categ_scalers[dataset_name](x[..., categ_idx]).to(x.dtype)

            idx_expanded = categ_idx.expand(*x.shape[:-1], -1)
            x = x.scatter(-1, idx_expanded, scaled_categ)

        # restore padded rows
        if pad_mask is not None:
            x = torch.where(pad_mask, x, pad_value)  # type: ignore[arg-type]

        return x

    @torch.no_grad()
    def forward(
        self,
        X_events: torch.Tensor | None,
        Xs: list[torch.Tensor] | None,
    ) -> tuple[torch.Tensor | None, list[torch.Tensor] | None]:
        X_events_scaled: torch.Tensor | None = None
        if X_events is not None:
            X_events_scaled = self._apply_scaler(X_events, self.dataset_names[0])

        Xs_scaled: list[torch.Tensor] | None = None
        if Xs is not None:
            Xs_scaled = []
            for i, X_obj in enumerate(Xs):
                Xs_scaled.append(self._apply_scaler(X_obj, self.dataset_names[i + 1]))

        return X_events_scaled, Xs_scaled

    @torch.no_grad()
    def inverse(
        self,
        X_events: torch.Tensor | None,
        Xs: list[torch.Tensor] | None,
    ) -> tuple[torch.Tensor | None, list[torch.Tensor] | None]:
        X_events_inv: torch.Tensor | None = None
        if X_events is not None:
            X_events_inv = self._apply_scaler(X_events, self.dataset_names[0], inverse=True)

        Xs_inv: list[torch.Tensor] | None = None
        if Xs is not None:
            Xs_inv = []
            for i, X_obj in enumerate(Xs):
                Xs_inv.append(self._apply_scaler(X_obj, self.dataset_names[i + 1], inverse=True))

        return X_events_inv, Xs_inv
