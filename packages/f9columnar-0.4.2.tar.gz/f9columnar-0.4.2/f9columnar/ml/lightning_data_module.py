import logging
from typing import Any, Callable

try:
    import lightning as L
except ImportError:
    raise ImportError("Lightning is not installed. Please install lightning to use LightningHdf5DataModule.")

from torch.utils.data import DataLoader

from f9columnar.hdf5_dataloader import Hdf5Iterator, StackedDatasets, get_hdf5_dataloader
from f9columnar.utils.data_containers import ColumnSelection, WeightedDatasetBatch


class LightningHdf5DataModule(L.LightningDataModule):
    def __init__(
        self,
        name: str,
        files: str | list[str],
        column_names: list[str],
        stage_split_piles: dict[str, list[int] | int],
        step_size: int | None = None,
        shuffle: bool = False,
        setup_fn: Callable[[StackedDatasets, Hdf5Iterator], WeightedDatasetBatch | None] | None = None,
        collate_fn: Callable[[tuple[WeightedDatasetBatch, dict[str, Any]]], Any] | None = None,
        dataset_kwargs: dict[str, Any] | None = None,
        dataloader_kwargs: dict[str, Any] | None = None,
    ) -> None:
        """Lightning DataModule for HDF5 datasets.

        Parameters
        ----------
        name : str
            Display name for the dataloader (used in logging).
        files : str or list of str
            Path(s) to HDF5 file(s).
        column_names : list of str
            List of column names to load from the HDF5 files.
        stage_split_piles : dict of str to list of int or int
            Mapping of stage name ("train", "val", "test") to pile indices used for splitting the data.
        shuffle : bool, optional
            Whether to shuffle the data. Default is False.
        step_size : int or None, optional
            Step size for iterating through the dataset. If None, the entire dataset is used as a single batch.
        setup_fn : callable or None, optional
            Pile-level transform that converts `StackedDatasets` into `WeightedDatasetBatch`.
            Defaults to `default_setup_fn`.
        collate_fn : callable or None, optional
            Custom collate function for the DataLoader.
        dataset_kwargs : dict or None, optional
            Keyword arguments passed to the dataset constructor.
        dataloader_kwargs : dict or None, optional
            Keyword arguments passed to the DataLoader constructor. Per-stage batch sizes can be set
            by prefixing the stage name, e.g. `val_batch_size` or `test_batch_size`.
            The default `batch_size` is used for any stage without an explicit override.

        """
        super().__init__()
        self.dl_name = name
        self.files = files
        self.column_names = column_names
        self.stage_split_piles = stage_split_piles
        self.shuffle = shuffle
        self.step_size = step_size
        self.setup_fn = setup_fn
        self.collate_fn = collate_fn
        self.dataset_kwargs = dataset_kwargs
        self.dl_kwargs = dataloader_kwargs

        self._selection: ColumnSelection | None = None

    @property
    def selection(self) -> ColumnSelection:
        if self._selection is None:
            raise ValueError("DataModule not yet setup, selection is not available!")
        return self._selection

    def _get_dataloader(self, stage: str) -> DataLoader:
        logging.info(f"[green]Creating dataloader for stage: {stage}.[/green]")

        dl_kwargs = dict(self.dl_kwargs) if self.dl_kwargs is not None else None

        if dl_kwargs is not None:
            stage_batch_size = dl_kwargs.pop(f"{stage}_batch_size", None)

            if stage_batch_size is not None:
                dl_kwargs["batch_size"] = stage_batch_size

            for key in [k for k in dl_kwargs if k.endswith("_batch_size")]:
                dl_kwargs.pop(key)

        ds_kwargs = dict(self.dataset_kwargs) if self.dataset_kwargs is not None else {}
        ds_kwargs["shuffle"] = self.shuffle

        if stage != "train":
            logging.info("Disabling shuffling for non-training stage.")
            ds_kwargs["shuffle"] = False

        dl, self._selection, _ = get_hdf5_dataloader(
            f"{stage} - {self.dl_name}",
            self.files,
            self.column_names,
            step_size=self.step_size,
            stage_split_piles=self.stage_split_piles,
            stage=stage,
            setup_fn=self.setup_fn,
            collate_fn=self.collate_fn,
            dataset_kwargs=ds_kwargs,
            dataloader_kwargs=dl_kwargs,
        )
        return dl

    def train_dataloader(self) -> DataLoader:
        return self._get_dataloader("train")

    def val_dataloader(self) -> DataLoader:
        return self._get_dataloader("val")

    def test_dataloader(self) -> DataLoader:
        return self._get_dataloader("test")
