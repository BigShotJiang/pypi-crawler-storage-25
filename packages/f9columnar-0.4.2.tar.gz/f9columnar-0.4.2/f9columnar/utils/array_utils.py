import numpy as np
import torch
from numpy.lib import recfunctions


def column_stack_structured_array(structured_array: np.ndarray, fields: list[str] | None = None) -> np.ndarray:
    if fields is None:
        fields = list(structured_array.dtype.names)  # type: ignore[arg-type]

    selected_columns = structured_array[fields]

    return recfunctions.structured_to_unstructured(selected_columns, dtype=np.float32)


def padding_mask(X: np.ndarray, pad_value: float | None) -> np.ndarray | None:
    if pad_value is None:
        return None

    return ~(X == pad_value).all(axis=1)


def pack_arrays(mask: np.ndarray, *arrays: np.ndarray) -> tuple[np.ndarray, tuple[np.ndarray, ...]]:
    """Pack arrays based on the provided mask.

    Parameters
    ----------
    mask : np.ndarray
        Boolean mask indicating valid entries. Shape (B, N).
    *arrays : np.ndarray
        Arrays to be packed. Each array should have shape (B, N, ..., F).

    Returns
    -------
    cu_seqlens : np.ndarray
        Cumulative sequence lengths. Shape (B+1,).
    packed_arrays : tuple[np.ndarray, ...]
        Packed arrays with shape (total_valid_entries, ..., F).
    """
    if mask.dtype != np.bool_:
        raise ValueError(f"Mask must be of boolean type, but got {mask.dtype}.")

    packed_arrays = []
    for array in arrays:
        if array.ndim < 2:
            raise ValueError(f"Each array must be at least 2-dimensional, but got shape {array.shape}.")

        batch_size, length = array.shape[:2]
        if mask.shape[0] != batch_size or mask.shape[1] != length:
            raise ValueError(
                f"Mask shape {mask.shape} must match array shape {array.shape} in the first two dimensions."
            )

        packed_arrays.append(array[mask])

    cu_seqlens = np.zeros(mask.shape[0] + 1, dtype=np.int32)
    np.cumsum(mask.sum(axis=1), out=cu_seqlens[1:])

    return cu_seqlens, tuple(packed_arrays)


def unpack_arrays(
    cu_seqlens: np.ndarray, *arrays: np.ndarray, max_length: int | None = None
) -> tuple[np.ndarray, tuple[np.ndarray, ...]]:
    """Unpack arrays based on the provided cumulative sequence lengths.

    Parameters
    ----------
    cu_seqlens : np.ndarray
        Cumulative sequence lengths. Shape (B+1,).
    *arrays : np.ndarray
        Arrays to be unpacked. Each array should have
        shape (total_valid_entries, F).
    max_length : int or None, optional
        Maximum length to pad the sequences to. If None, uses the
        maximum sequence length in the batch.

    Returns
    -------
    mask : np.ndarray
        Boolean mask indicating valid entries. Shape (B, N).
    batched_arrays : tuple[np.ndarray, ...]
        Unpacked arrays with shape (B, N, ..., F).
    """
    seq_lengths = np.diff(cu_seqlens)

    if max_length is None:
        max_length = int(seq_lengths.max())

    batch_size = len(cu_seqlens) - 1
    mask = np.arange(max_length)[np.newaxis, :] < seq_lengths[:, np.newaxis]

    batched_arrays = []
    for array in arrays:
        feature_like_dims = array.shape[1:]
        batched_array = np.zeros(
            (batch_size, max_length, *feature_like_dims),
            dtype=array.dtype,
        )
        batched_array[mask] = array
        batched_arrays.append(batched_array)

    return mask, tuple(batched_arrays)


def pack_array(mask: np.ndarray, array: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Convenience wrapper around `pack_arrays` for a single array."""
    cu_seqlens, (packed_array,) = pack_arrays(mask, array)
    return cu_seqlens, packed_array


def unpack_array(
    cu_seqlens: np.ndarray, array: np.ndarray, *, max_length: int | None = None
) -> tuple[np.ndarray, np.ndarray]:
    """Convenience wrapper around `unpack_arrays` for a single array."""
    mask, (batched_array,) = unpack_arrays(cu_seqlens, array, max_length=max_length)
    return mask, batched_array


def pack_tensors(mask: torch.Tensor, *tensors: torch.Tensor) -> tuple[torch.Tensor, tuple[torch.Tensor, ...]]:
    """Pack tensors based on the provided mask.

    Parameters
    ----------
    mask : torch.Tensor
        Boolean mask indicating valid entries. Shape (B, N).
    *tensors : torch.Tensor
        Tensors to be packed. Each tensor should have shape (B, N, ..., F).

    Returns
    -------
    cu_seqlens : torch.Tensor
        Cumulative sequence lengths. Shape (B+1,).
    packed_tensors : tuple[torch.Tensor, ...]
        Packed tensors with shape (total_valid_entries, ..., F).
    """
    if mask.dtype != torch.bool:
        raise ValueError(f"Mask must be of boolean type, but got {mask.dtype}.")

    packed_tensors = []
    for tensor in tensors:
        if len(tensor.shape) < 2:
            raise ValueError(f"Each tensor must be 2-dimensional, but got one-dimensional shape {tensor.shape}.")

        batch_size, length, *_ = tensor.shape
        if mask.shape[0] != batch_size or mask.shape[1] != length:
            raise ValueError(
                f"Mask shape {mask.shape} must match tensor shape {tensor.shape} in the first two dimensions."
            )

        packed_tensor = tensor[mask]
        packed_tensors.append(packed_tensor)

    cu_seqlens = torch.cumsum(
        torch.cat([torch.zeros(1, device=mask.device, dtype=torch.int32), mask.sum(dim=1)], dim=0), dim=0
    )

    return cu_seqlens, tuple(packed_tensors)


def pack_tensor(mask: torch.Tensor, tensor: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Convenience wrapper around `pack_tensors` for a single tensor."""
    cu_seqlens, (packed_tensor,) = pack_tensors(mask, tensor)
    return cu_seqlens, packed_tensor


def unpack_tensors(
    cu_seqlens: torch.Tensor, *tensors: torch.Tensor, max_length: int | None = None
) -> tuple[torch.Tensor, tuple[torch.Tensor, ...]]:
    """Unpack tensors based on the provided cumulative sequence lengths.

    Parameters
    ----------
    cu_seqlens : torch.Tensor
        Cumulative sequence lengths. Shape (B+1,).
    *tensors : torch.Tensor
        Tensors to be unpacked. Each tensor should have
        shape (total_valid_entries, F).
    max_length : int or None, optional
        Maximum length to pad the sequences to. If None, uses the
        maximum sequence length in the batch.

    Returns
    -------
    mask : torch.Tensor
        Boolean mask indicating valid entries. Shape (B, N).
    batched_tensors : tuple[torch.Tensor, ...]
        Unpacked tensors with shape (B, N, ..., F).
    """
    seq_lengths = torch.diff(cu_seqlens)

    if max_length is None:
        max_length = int(seq_lengths.max().item())

    batch_size = len(cu_seqlens) - 1
    mask = torch.arange(max_length, device=cu_seqlens.device).unsqueeze(0) < seq_lengths.unsqueeze(1)

    batched_tensors = []
    for tensor in tensors:
        feature_like_dims = tensor.shape[1:]
        batched_tensor = torch.zeros(
            (batch_size, max_length, *feature_like_dims),
            device=tensor.device,
            dtype=tensor.dtype,
        )
        batched_tensor[mask] = tensor
        batched_tensors.append(batched_tensor)

    return mask, tuple(batched_tensors)


def unpack_tensor(
    cu_seqlens: torch.Tensor, tensor: torch.Tensor, *, max_length: int | None = None
) -> tuple[torch.Tensor, torch.Tensor]:
    """Convenience wrapper around `unpack_tensors` for a single tensor."""
    mask, (batched_tensor,) = unpack_tensors(cu_seqlens, tensor, max_length=max_length)
    return mask, batched_tensor


def make_packed_batch(
    indices: np.ndarray | slice, cu_seqlens: np.ndarray, packed: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Select a batch of events from a packed array using cumulative lengths.

    Parameters
    ----------
    indices : np.ndarray | slice
        Event indices to select. Shape (B,), or a slice for contiguous ranges.
    cu_seqlens : np.ndarray
        Cumulative sequence lengths for the full dataset. Shape (N+1,).
    packed : np.ndarray
        Packed (flattened) data. Shape (total_entries, ...).

    Returns
    -------
    batch_cu_seqlens : np.ndarray
        Cumulative sequence lengths for the batch, starting at 0. Shape (B+1,).
    batch_packed : np.ndarray
        Packed data for the selected events. Shape (batch_total_entries, ...).

    Note
    ----
    When `indices` is a contiguous slice (step=1), a fast path is used
    that slices `cu_seqlens` and `packed` directly in O(1) without
    building gather indices. Non-unit-step slices fall back to the general
    array path.

    Example
    -------
    - Events 10 through 19: `make_packed_batch(slice(10, 20), cu_seqlens, packed)`
    - First 10 events: `make_packed_batch(slice(0, 10), cu_seqlens, packed)`
    - All events: `make_packed_batch(slice(None), cu_seqlens, packed)`
    - Every 10th event from 0 to 99: `make_packed_batch(slice(0, 100, 10), cu_seqlens, packed)`

    """
    if isinstance(indices, slice):
        start, stop, step = indices.indices(len(cu_seqlens) - 1)
        if step != 1:
            return make_packed_batch(np.arange(start, stop, step), cu_seqlens, packed)

        # fast path: contiguous slice — just slice cu_seqlens and packed directly
        batch_cu_seqlens = cu_seqlens[start : stop + 1] - cu_seqlens[start]
        batch_packed = packed[cu_seqlens[start] : cu_seqlens[stop]]
        return batch_cu_seqlens, batch_packed

    starts = cu_seqlens[indices]
    ends = cu_seqlens[indices + 1]
    lengths = ends - starts

    batch_cu_seqlens = np.empty(len(indices) + 1, dtype=cu_seqlens.dtype)
    batch_cu_seqlens[0] = 0
    np.cumsum(lengths, out=batch_cu_seqlens[1:])

    # fully vectorized gather: build flat indices without loops
    total = int(batch_cu_seqlens[-1])
    offsets = np.repeat(starts - batch_cu_seqlens[:-1], lengths)
    flat_indices = np.arange(total) + offsets
    batch_packed = packed[flat_indices]

    return batch_cu_seqlens, batch_packed


def shuffle_packed_array(
    cu_seqlens: np.ndarray, packed: np.ndarray, rng: np.random.Generator | None = None
) -> tuple[np.ndarray, np.ndarray]:
    """Randomly shuffle events in a packed array.

    Parameters
    ----------
    cu_seqlens : np.ndarray
        Cumulative sequence lengths. Shape (N+1,).
    packed : np.ndarray
        Packed (flattened) data. Shape (total_entries, ...).
    rng : np.random.Generator or None, optional
        Random generator. If None, uses the default.

    Returns
    -------
    shuffled_cu_seqlens : np.ndarray
        Cumulative sequence lengths after shuffling. Shape (N+1,).
    shuffled_packed : np.ndarray
        Packed data in shuffled event order. Shape (total_entries, ...).
    """
    if rng is None:
        rng = np.random.default_rng()

    n_events = len(cu_seqlens) - 1
    perm = rng.permutation(n_events)
    return make_packed_batch(perm, cu_seqlens, packed)
