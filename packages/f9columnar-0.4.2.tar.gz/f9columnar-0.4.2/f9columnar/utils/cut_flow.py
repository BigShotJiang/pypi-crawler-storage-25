import logging
import os
from typing import Self

import matplotlib.pyplot as plt
import mplhep as hep
from matplotlib.backends.backend_pdf import PdfPages

from f9columnar.processors import Processor
from f9columnar.utils.helpers import dump_json


def _dynamic_figsize(n_bars: int, max_label_len: int, n_rows: int = 1) -> tuple[float, float]:
    width = max(10.0, n_bars * 0.55)
    plot_height = 2.0 * n_rows
    label_space = max_label_len * 0.12
    height = plot_height + label_space
    return (width, height)


def _font_scale(fig: plt.Figure) -> float:
    return max(0.5, min(1.5, fig.get_figwidth() / 10.0))


class TimeFlow:
    def __init__(self, save_path: str | None = None, atlas_label: str | None = None) -> None:
        if save_path is None:
            save_path = os.environ.get("COLUMNAR_CUT_FLOW_SAVE_PATH", None)

        if save_path is None:
            raise ValueError("No save path provided for TimeFlow!")

        self.save_path = save_path

        env_atlas_label = os.environ.get("COLUMNAR_ATLAS_LABEL", None)
        self.atlas_label = atlas_label if atlas_label is not None else env_atlas_label

        os.makedirs(self.save_path, exist_ok=True)

        self.mc_counts: dict[str, float] = {}
        self.data_counts: dict[str, float] = {}

        self._n_mc_updates = 0
        self._n_data_updates = 0

    def update(self, fitted_processors: dict[str, Processor], is_data: bool) -> None:
        acc_dct = self.data_counts if is_data else self.mc_counts

        for proc_name, proc in fitted_processors.items():
            if proc_name not in acc_dct:
                acc_dct[proc_name] = 0.0

            acc_dct[proc_name] += proc.delta_time

        if is_data:
            self._n_data_updates += 1
        else:
            self._n_mc_updates += 1

    def update_from_dict(self, time_dct: dict[str, float], is_data: bool, n_workers: int = 1) -> None:
        acc_dct = self.data_counts if is_data else self.mc_counts

        for proc_name, delta_time in time_dct.items():
            if proc_name not in acc_dct:
                acc_dct[proc_name] = 0.0

            acc_dct[proc_name] += delta_time

        if is_data:
            self._n_data_updates += n_workers
        else:
            self._n_mc_updates += n_workers

    def reset(self, update_only: bool = False) -> Self:
        self._n_mc_updates = 0
        self._n_data_updates = 0

        if update_only:
            return self

        self.mc_counts = {}
        self.data_counts = {}

        return self

    def _plot(self, is_data: bool, pdf: PdfPages, n_events: int, combined_time: float) -> None:
        acc_dct = self.data_counts if is_data else self.mc_counts
        label = "Data" if is_data else "MC"

        sorted_items = sorted(acc_dct.items(), key=lambda x: x[1], reverse=True)

        n_updates = self._n_data_updates if is_data else self._n_mc_updates

        proc_names = [name for name, _ in sorted_items]
        times = [t / n_updates for _, t in sorted_items]

        n_procs = len(proc_names)
        max_label_len = max(len(p) for p in proc_names)

        fig, ax = plt.subplots(figsize=_dynamic_figsize(n_procs, max_label_len))

        s = _font_scale(fig)

        ax.bar(proc_names, times, color="steelblue")

        ax.set_ylabel("Average processing time [s]", fontsize=11 * s)
        ax.set_xlabel("Processor", fontsize=11 * s)

        ax.set_title(f"Time Flow ({label})", fontsize=12 * s, pad=6)

        ax.tick_params(axis="x", rotation=45, labelsize=9 * s)
        ax.tick_params(axis="y", labelsize=9 * s)

        ax.yaxis.get_offset_text().set_fontsize(9 * s)

        for tick in ax.get_xticklabels():
            tick.set_ha("right")  # type: ignore[attr-defined]

        for i, t in enumerate(times):
            ax.text(i, t, f"{t:.3f}", ha="center", va="bottom", fontsize=7 * s)

        total_time = sum(times)

        events_per_second = n_events / (total_time * n_updates)
        combined_per_second = n_events / combined_time

        ax.text(
            0.98,
            0.95,
            f"Per worker processing time: {total_time:.2f} s, {events_per_second:.2f} ev/s",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=10 * s,
            color="k",
        )
        ax.text(
            0.98,
            0.90,
            f"All workers total time (processing + I/O): {combined_time:.2f} s, {combined_per_second:.2f} ev/s",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=10 * s,
            color="k",
        )

        xlim = ax.get_xlim()
        ax.set_xlim(xlim[0] - 0.5, xlim[1] + 0.5)

        if self.atlas_label is not None:
            fig.canvas.draw()
            hep.atlas.label(llabel=self.atlas_label, rlabel="", fontsize=11 * s, loc=0, ax=ax)

        pdf.savefig(fig, bbox_inches="tight")

        ax.set_yscale("log")
        pdf.savefig(fig, bbox_inches="tight")

        plt.close(fig)

    def plot(
        self,
        is_data: bool,
        dataset_name: str,
        n_events: int,
        combined_time: float,
        only_dump: bool = False,
        disable_dump: bool = False,
    ) -> Self:
        label = "Data" if is_data else "MC"

        if not disable_dump:
            n_workers = self._n_data_updates if is_data else self._n_mc_updates
            dump_json(
                {
                    "n_events": n_events,
                    "combined_time": combined_time,
                    "n_workers": n_workers,
                    "time_flow": self.data_counts if is_data else self.mc_counts,
                },
                os.path.join(self.save_path, f"time_flow_{dataset_name}_{label.lower()}.json"),
            )

            if only_dump:
                return self

        save_path = os.path.join(self.save_path, f"time_flow_{dataset_name}_{label.lower()}.pdf")

        logging.info(f"Plotting time flow for {dataset_name} {label}...")
        with PdfPages(save_path) as pdf:
            self._plot(is_data, pdf, n_events, combined_time)

        return self


class CutFlow:
    def __init__(self, save_path: str | None = None, atlas_label: str | None = None) -> None:
        if save_path is None:
            save_path = os.environ.get("COLUMNAR_CUT_FLOW_SAVE_PATH", None)

        if save_path is None:
            raise ValueError("No save path provided for TimeFlow!")

        self.save_path = save_path

        env_atlas_label = os.environ.get("COLUMNAR_ATLAS_LABEL", None)
        self.atlas_label = atlas_label if atlas_label is not None else env_atlas_label

        os.makedirs(self.save_path, exist_ok=True)

        # keys: group -> variation -> processor -> (start_n, end_n)
        self.mc_counts: dict[str, dict[str, dict[str, tuple[int, int]]]] = {}
        self.data_counts: dict[str, dict[str, dict[str, tuple[int, int]]]] = {}

    def update(self, fitted_processors: dict[str, Processor], is_data: bool) -> None:
        acc_dct = self.data_counts if is_data else self.mc_counts

        for proc_name, proc in fitted_processors.items():
            if not proc.has_event_count:
                continue

            for group, var_dict in proc.delta_n.items():
                if group not in acc_dct:
                    acc_dct[group] = {}

                for variation, (start_n, end_n) in var_dict.items():
                    start_n, end_n = int(start_n), int(end_n)

                    if variation not in acc_dct[group]:
                        acc_dct[group][variation] = {}

                    if proc_name not in acc_dct[group][variation]:
                        acc_dct[group][variation][proc_name] = (0, 0)

                    total_start, total_end = acc_dct[group][variation][proc_name]
                    acc_dct[group][variation][proc_name] = (total_start + start_n, total_end + end_n)

    def update_from_dict(self, cut_dct: dict[str, dict[str, dict[str, tuple[int, int]]]], is_data: bool) -> None:
        acc_dct = self.data_counts if is_data else self.mc_counts

        for group, var_dict in cut_dct.items():
            if group not in acc_dct:
                acc_dct[group] = {}

            for variation, proc_dict in var_dict.items():
                if variation not in acc_dct[group]:
                    acc_dct[group][variation] = {}

                for proc_name, (start_n, end_n) in proc_dict.items():
                    start_n, end_n = int(start_n), int(end_n)

                    if proc_name not in acc_dct[group][variation]:
                        acc_dct[group][variation][proc_name] = (0, 0)

                    total_start, total_end = acc_dct[group][variation][proc_name]
                    acc_dct[group][variation][proc_name] = (total_start + start_n, total_end + end_n)

    def reset(self) -> Self:
        self.mc_counts = {}
        self.data_counts = {}
        return self

    def _plot_by_processor(self, is_data: bool, pdf: PdfPages) -> None:
        acc_dct = self.data_counts if is_data else self.mc_counts
        label = "Data" if is_data else "MC"

        for group, group_dct in acc_dct.items():
            all_processors: list[str] = []
            for processors in group_dct.values():
                for proc in processors.keys():
                    if proc not in all_processors:
                        all_processors.append(proc)

            for proc in all_processors:
                variation_names: list[str] = []
                starts: list[int] = []
                ends: list[int] = []
                efficiencies: list[float] = []

                group_dct = dict(sorted(group_dct.items()))

                for variation, processors in group_dct.items():
                    if proc not in processors:
                        continue

                    start_n, end_n = processors[proc]
                    variation_names.append(variation)
                    starts.append(start_n)
                    ends.append(end_n)
                    efficiencies.append(end_n / start_n if start_n > 0 else 0.0)

                if not variation_names:
                    continue

                # find nominal variation
                nominal_idx = None
                for i, var_name in enumerate(variation_names):
                    if var_name.lower() == "nominal" or "nominal" in var_name.lower():
                        nominal_idx = i
                        break

                removed = [s - e for s, e in zip(starts, ends)]

                n_bars = len(variation_names)
                max_label_len = max(len(v) for v in variation_names)

                fig, (ax1, ax2) = plt.subplots(
                    nrows=2,
                    ncols=1,
                    figsize=_dynamic_figsize(n_bars, max_label_len, n_rows=2),
                    height_ratios=[2, 1],
                )
                s = _font_scale(fig)

                # top plot - cut flow by variation
                ax1.bar(variation_names, ends, label="End events", color="steelblue")
                ax1.bar(variation_names, removed, bottom=ends, label="Cut events", color="indianred")

                y_max = max(starts)
                if y_max > 0:
                    ax1.set_ylim(0, y_max * 1.15)

                ax1.set_ylabel("Number of events", fontsize=11 * s)
                ax1.set_title(f"Cut Flow - {group} / Processor: {proc} ({label})", fontsize=12 * s, pad=6)

                ax1.tick_params(axis="x", labelbottom=False)
                ax1.tick_params(axis="y", labelsize=9 * s)

                ax1.yaxis.get_offset_text().set_fontsize(9 * s)

                for i, (st, eff) in enumerate(zip(starts, efficiencies)):
                    ax1.text(
                        i,
                        st * 0.5,
                        f"{eff:.1%}",
                        ha="center",
                        va="center",
                        fontsize=7 * s,
                        color="white",
                        rotation=90.0,
                        weight="bold",
                    )

                ax1.legend(fontsize=9 * s)

                xlim = ax1.get_xlim()
                ax1.set_xlim(xlim[0] - 0.5, xlim[1] + 0.5)

                # bottom plot - absolute change vs nominal
                if nominal_idx is not None:
                    nominal_end = ends[nominal_idx]
                    absolute_changes = []
                    for end in ends:
                        abs_change = end - nominal_end
                        absolute_changes.append(abs_change)

                    colors = ["red" if ac < 0 else "green" if ac > 0 else "gray" for ac in absolute_changes]

                    ax2.bar(variation_names, absolute_changes, color=colors, alpha=0.7)

                    ax2.axhline(y=0, color="black", linestyle="-", linewidth=0.8)
                    ax2.set_ylabel("Absolute change", fontsize=11 * s)
                    ax2.set_xlabel("Variation", fontsize=11 * s)

                    ax2.tick_params(axis="x", rotation=45, labelsize=9 * s)
                    ax2.tick_params(axis="y", labelsize=9 * s)
                    for tick in ax2.get_xticklabels():
                        tick.set_ha("right")  # type: ignore[attr-defined]

                    if absolute_changes:
                        y_min = min(absolute_changes)
                        y_max = max(absolute_changes)
                        y_range = y_max - y_min
                        if y_range > 0:
                            ax2.set_ylim(y_min - 0.075 * y_range, y_max + 0.075 * y_range)
                        else:
                            ax2.set_ylim(-10, 10)

                    for i, ac in enumerate(absolute_changes):
                        va = "bottom" if ac >= 0 else "top"
                        ax2.text(i, ac, f"{ac:+.0f}", ha="center", va=va, fontsize=6 * s)

                    xlim = ax2.get_xlim()
                    ax2.set_xlim(xlim[0] - 0.5, xlim[1] + 0.5)
                else:
                    ax2.text(
                        0.5,
                        0.5,
                        "No nominal variation found",
                        ha="center",
                        va="center",
                        transform=ax2.transAxes,
                        fontsize=10 * s,
                    )

                    ax2.set_xlabel("Variation", fontsize=11 * s)
                    ax2.tick_params(axis="x", rotation=45, labelsize=9 * s)
                    ax2.tick_params(axis="y", labelsize=9 * s)
                    for tick in ax2.get_xticklabels():
                        tick.set_ha("right")  # type: ignore[attr-defined]

                if self.atlas_label is not None:
                    fig.canvas.draw()
                    hep.atlas.label(llabel=self.atlas_label, rlabel="", fontsize=11 * s, loc=0, ax=ax1)

                pdf.savefig(fig, bbox_inches="tight")
                plt.close(fig)

    def _plot_by_variation_single(
        self,
        group: str,
        variation: str,
        label: str,
        proc_names: list[str],
        starts: list[int],
        ends: list[int],
        efficiencies: list[float],
        log_scale: bool,
        pdf: PdfPages,
    ) -> None:
        # for log scale, filter out processors where both start and end are zero
        if log_scale:
            filtered = [
                (p, s, e, eff) for p, s, e, eff in zip(proc_names, starts, ends, efficiencies) if s > 0 or e > 0
            ]

            if not filtered:
                return None

            proc_names = [x[0] for x in filtered]
            starts = [x[1] for x in filtered]
            ends = [x[2] for x in filtered]
            efficiencies = [x[3] for x in filtered]

        removed = [s - e for s, e in zip(starts, ends)]

        n_procs = len(proc_names)
        max_label_len = max(len(p) for p in proc_names)

        fig, ax = plt.subplots(figsize=_dynamic_figsize(n_procs, max_label_len))

        s = _font_scale(fig)

        ax.bar(proc_names, ends, label="End events", color="steelblue")
        ax.bar(proc_names, removed, bottom=ends, label="Cut events", color="indianred")

        if log_scale:
            ax.set_yscale("log")
            positive_vals = [v for v in starts + ends if v > 0]
            if positive_vals:
                ax.set_ylim(min(positive_vals) * 0.3, max(positive_vals) * 5.0)
        else:
            y_max = max(starts)
            if y_max > 0:
                ax.set_ylim(0, y_max * 1.15)

        title_suffix = " [log]" if log_scale else ""
        ax.set_ylabel("Number of events", fontsize=11 * s)
        ax.set_xlabel("Processor", fontsize=11 * s)
        ax.set_title(
            f"Cut Flow - {group} / Variation: {variation} ({label}){title_suffix}",
            fontsize=12 * s,
            pad=6,
        )

        ax.tick_params(axis="x", rotation=45, labelsize=9 * s)
        ax.tick_params(axis="y", labelsize=9 * s)

        ax.yaxis.get_offset_text().set_fontsize(9 * s)

        for tick in ax.get_xticklabels():
            tick.set_ha("right")  # type: ignore[attr-defined]

        for i, (st, eff) in enumerate(zip(starts, efficiencies)):
            ax.text(
                i,
                st * 0.5,
                f"{eff:.1%}",
                ha="center",
                va="center",
                fontsize=7 * s,
                color="white",
                rotation=90,
                weight="bold",
            )

        ax.legend(fontsize=9 * s)

        xlim = ax.get_xlim()
        ax.set_xlim(xlim[0] - 0.5, xlim[1] + 0.5)

        if self.atlas_label is not None:
            fig.canvas.draw()
            hep.atlas.label(llabel=self.atlas_label, rlabel="", fontsize=11 * s, loc=0, ax=ax)

        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)

    def _plot_by_variation(self, is_data: bool, pdf: PdfPages) -> None:
        acc_dct = self.data_counts if is_data else self.mc_counts
        label = "Data" if is_data else "MC"

        for group, group_dct in acc_dct.items():
            group_dct = dict(sorted(group_dct.items()))
            for variation, delta_n_dct in group_dct.items():
                proc_names: list[str] = []
                starts: list[int] = []
                ends: list[int] = []
                efficiencies: list[float] = []

                for proc_name, (start_n, end_n) in delta_n_dct.items():
                    proc_names.append(proc_name)
                    starts.append(start_n)
                    ends.append(end_n)
                    efficiencies.append(end_n / start_n if start_n > 0 else 0.0)

                self._plot_by_variation_single(
                    group, variation, label, proc_names, starts, ends, efficiencies, log_scale=False, pdf=pdf
                )
                self._plot_by_variation_single(
                    group, variation, label, proc_names, starts, ends, efficiencies, log_scale=True, pdf=pdf
                )

    def plot(
        self,
        is_data: bool,
        dataset_name: str,
        only_dump: bool = False,
        disable_dump: bool = False,
        plot_by_processor: bool = False,
        plot_by_variation: bool = True,
    ) -> Self:
        label = "Data" if is_data else "MC"

        if not disable_dump:
            dump_json(
                {"cut_flow": self.data_counts if is_data else self.mc_counts},
                os.path.join(self.save_path, f"cut_flow_{dataset_name}_{label.lower()}.json"),
            )

            if only_dump:
                return self

        variation_save_path = os.path.join(self.save_path, f"cut_flow_by_variation_{dataset_name}_{label.lower()}.pdf")
        processor_save_path = os.path.join(self.save_path, f"cut_flow_by_processor_{dataset_name}_{label.lower()}.pdf")

        logging.info(f"Plotting cut flow for {dataset_name} {label}...")
        if plot_by_processor:
            with PdfPages(processor_save_path) as pdf:
                self._plot_by_processor(is_data, pdf)

        if plot_by_variation:
            with PdfPages(variation_save_path) as pdf:
                self._plot_by_variation(is_data, pdf)

        return self
