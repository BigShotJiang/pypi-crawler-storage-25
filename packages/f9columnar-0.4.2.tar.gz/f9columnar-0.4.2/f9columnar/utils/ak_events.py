from pathlib import Path
from typing import Any, Mapping, TypedDict

import awkward as ak
import numpy as np
import uproot


class DistSpec(TypedDict):
    dist_type: str
    params: Mapping[str, Any]


JaggedSpec = dict[str, dict[str, DistSpec]]
FlatSpec = dict[str, DistSpec]


class AwkwardEventGenerator:
    def __init__(
        self,
        n_events: int = 100000,
        min_particles: int = 0,
        max_particles: int = 10,
        random_seed: int | None = None,
    ) -> None:
        """Initialize the particle distribution generator.

        Parameters
        ----------
        n_events : int, optional
            Number of events to generate, by default 100000.
        min_particles : int, optional
            Minimum number of particles per event, by default 2.
        max_particles : int, optional
            Maximum number of particles per event, by default 20.
        random_seed : int | None, optional
            Random seed for reproducibility, by default None.
        """
        self.n_events = n_events
        self.min_particles = min_particles
        self.max_particles = max_particles
        self.random_seed = random_seed

        if random_seed is not None:
            np.random.seed(random_seed)

        self._n_particles_per_event: ak.Array
        self._total_particles: int

    def _generate_event_structure(self) -> None:
        weights = np.exp(-0.5 * np.arange(self.max_particles - self.min_particles + 1))
        probabilities = weights / np.sum(weights)

        particle_counts = np.random.choice(
            np.arange(self.min_particles, self.max_particles + 1),
            size=self.n_events,
            p=probabilities,
        )

        self._n_particles_per_event = particle_counts
        self._total_particles = int(np.sum(self._n_particles_per_event))

    def _uniform_dist(
        self, low: float = 0.0, high: float = 1.0, is_flat: bool = True, as_int: bool = False
    ) -> ak.Array:
        """Generate an awkward array of uniformly distributed values.

        Parameters
        ----------
        low : float, optional
            Lower bound of the uniform distribution, by default -1.0.
        high : float, optional
            Upper bound of the uniform distribution, by default 1.0.

        Returns
        -------
        ak.Array
            Awkward array of uniformly distributed values for each event.
        """
        if is_flat:
            uniform_flat = np.random.uniform(low, high, self.n_events)

            if as_int:
                uniform_flat = uniform_flat.astype(np.int64)

            return uniform_flat

        uniform_flat = np.random.uniform(low, high, self._total_particles)

        if as_int:
            uniform_flat = uniform_flat.astype(np.int64)

        return ak.unflatten(uniform_flat, self._n_particles_per_event)

    def _normal_dist(self, mean: float = 0.0, stddev: float = 1.0, is_flat: bool = True) -> ak.Array:
        """Generate an awkward array of normally distributed values.

        Parameters
        ----------
        mean : float, optional
            Mean of the normal distribution, by default 0.0.
        stddev : float, optional
            Standard deviation of the normal distribution, by default 1.0.

        Returns
        -------
        ak.Array
            Awkward array of normally distributed values for each event.
        """
        if is_flat:
            return np.random.normal(mean, stddev, self.n_events)

        normal_flat = np.random.normal(mean, stddev, self._total_particles)

        return ak.unflatten(normal_flat, self._n_particles_per_event)

    def _exp_dist(self, scale: float = 1.0, is_flat: bool = True) -> ak.Array:
        """Generate an awkward array of exponentially distributed values.

        Parameters
        ----------
        scale : float, optional
            Scale parameter (1/lambda) of the exponential distribution, by default 1.0.

        Returns
        -------
        ak.Array
            Awkward array of exponentially distributed values for each event.
        """
        if is_flat:
            return np.random.exponential(scale, self.n_events)

        exp_flat = np.random.exponential(scale, self._total_particles)

        return ak.unflatten(exp_flat, self._n_particles_per_event)

    def _pt_dist(self, pt_min: float = 1000.0, pt_max: float = 500000.0, n: float = 6.0) -> ak.Array:
        """Generate an awkward array of transverse momentum (pt) values.

        Uses a power-law distribution which better matches QCD jet production and typical collider physics.

        Parameters
        ----------
        pt_min : float, optional
            Minimum pt value, by default 50000.0.
        pt_max : float, optional
            Maximum pt value, by default 500000.0.
        n : float, optional
            Power-law exponent, by default 6.0.

        Returns
        -------
        ak.Array
            Awkward array of pt values for each event.
        """

        u = np.random.uniform(0, 1, self._total_particles)
        pt_flat = (pt_min ** (1 - n) + u * (pt_max ** (1 - n) - pt_min ** (1 - n))) ** (1 / (1 - n))

        return ak.unflatten(pt_flat, self._n_particles_per_event)

    def _phi_dist(self) -> ak.Array:
        """Generate an awkward array of phi (azimuthal angle) values.

        Phi is uniformly distributed between -pi and pi.

        Returns
        -------
        ak.Array
            Awkward array of phi values (in radians) for each event.
        """
        phi_flat = np.random.uniform(-np.pi, np.pi, self._total_particles)

        return ak.unflatten(phi_flat, self._n_particles_per_event)

    def _eta_dist(self, eta_center: float = 0.0, eta_width: float = 2.5) -> ak.Array:
        """Generate an awkward array of pseudorapidity (eta) values.

        Parameters
        ----------
        eta_center : float, optional
            Center of eta distribution, by default 0.0.
        eta_width : float, optional
            Standard deviation and maximum |eta| range, by default 2.5.

        Returns
        -------
        ak.Array
            Awkward array of eta values for each event.
        """
        # eta follows approximately Gaussian distribution
        eta_flat = np.random.normal(eta_center, eta_width / 2.5, self._total_particles)

        # clip to detector acceptance range
        eta_flat = np.clip(eta_flat, -eta_width, eta_width)

        return ak.unflatten(eta_flat, self._n_particles_per_event)

    def from_spec_to_dict(
        self, flat_spec: FlatSpec | None = None, jagged_spec: JaggedSpec | None = None, zip_fields: bool = True
    ) -> dict[str, np.ndarray | ak.Array]:
        """Generate an awkward array based on the provided specifications.

        Parameters
        ----------
        flat_spec : FlatSpec | None, optional
            Specification for flat fields, by default None.
        jagged_spec : JaggedSpec | None, optional
            Specification for jagged fields, by default None.

        Returns
        -------
        ak.Array
            Awkward array generated based on the specifications.
        """

        arrays_dct: dict[str, np.ndarray | ak.Array] = {}

        if flat_spec is not None:
            for name, spec in flat_spec.items():
                dist_type = spec["dist_type"]
                params = spec.get("params", {})

                if name in arrays_dct:
                    raise ValueError(f"Duplicate field name in flat spec: {name}")

                if dist_type == "uniform":
                    arrays_dct[name] = self._uniform_dist(is_flat=True, **params)
                elif dist_type == "normal":
                    arrays_dct[name] = self._normal_dist(is_flat=True, **params)
                elif dist_type == "exp":
                    arrays_dct[name] = self._exp_dist(is_flat=True, **params)
                else:
                    raise ValueError(f"Unsupported field name in flat spec: {name}")

        if jagged_spec is not None:
            for obj_name, fields in jagged_spec.items():
                self._generate_event_structure()

                obj_fields: dict[str, ak.Array] = {}

                if zip_fields:
                    obj_dct = obj_fields
                else:
                    obj_dct = arrays_dct

                for field_name, spec in fields.items():
                    dist_type = spec["dist_type"]
                    params = spec.get("params", {})

                    if zip_fields:
                        key = field_name
                    else:
                        key = f"{obj_name}_{field_name}"

                    if key in arrays_dct:
                        raise ValueError(f"Duplicate key in jagged spec: {key}")

                    if dist_type == "pt":
                        obj_dct[key] = self._pt_dist(**params)
                    elif dist_type == "eta":
                        obj_dct[key] = self._eta_dist(**params)
                    elif dist_type == "phi":
                        obj_dct[key] = self._phi_dist()
                    elif dist_type == "uniform":
                        obj_dct[key] = self._uniform_dist(**params)
                    elif dist_type == "normal":
                        obj_dct[key] = self._normal_dist(**params)
                    elif dist_type == "exp":
                        obj_dct[key] = self._exp_dist(**params)
                    else:
                        raise ValueError(f"Unsupported field name in jagged spec: {field_name}")

                if zip_fields:
                    arrays_dct[obj_name] = ak.zip(obj_fields)

        return arrays_dct

    def from_spec_to_array(self, flat_spec: FlatSpec | None = None, jagged_spec: JaggedSpec | None = None) -> ak.Array:
        """Generate an awkward array based on the provided specifications."""
        return ak.zip(
            self.from_spec_to_dict(
                flat_spec=flat_spec,
                jagged_spec=jagged_spec,
                zip_fields=False,
            ),
            depth_limit=1,
        )

    def to_root(
        self,
        array_dct: dict[str, np.ndarray | ak.Array],
        file_path: str,
        tree_name: str = "physics",
        compression_level: int = 1,
        n_splits: int = 1,
    ) -> None:
        """Write the awkward array to ROOT file(s).

        Parameters
        ----------
        array : ak.Array
            The awkward array to write to ROOT file.
        file_path : str
            Output ROOT file name (e.g., "output.root"). If n_splits > 1,
            files will be named with pattern: "output_part1.root", "output_part2.root", etc.
        tree_name : str, optional
            Name of the TTree in the ROOT file, by default "physics".
        compression_level : int, optional
            Compression level (0-9), by default 1.
        n_splits : int, optional
            Number of files to split the array into, by default 1.
        """

        if n_splits < 1:
            raise ValueError("n_splits must be at least 1")

        n_events = len(array_dct[next(iter(array_dct))])

        compression = uproot.ZLIB(compression_level)

        if n_splits == 1:
            with uproot.recreate(file_path, compression=compression) as f:
                f.mktree(tree_name, array_dct)
        else:
            events_per_file = n_events // n_splits

            path = Path(file_path)
            stem, suffix, parent = path.stem, path.suffix, path.parent

            for i in range(n_splits):
                start_idx = i * events_per_file
                end_idx = (i + 1) * events_per_file if i < n_splits - 1 else n_events

                array_slice = {key: arr[start_idx:end_idx] for key, arr in array_dct.items()}

                output_filename = parent / f"{stem}_part{i}{suffix}"

                with uproot.recreate(str(output_filename), compression=compression) as f:
                    f.mktree(tree_name, array_slice)
