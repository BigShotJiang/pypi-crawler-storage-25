from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

import numpy as np
import torch

from f9columnar.utils.helpers import dump_json

BatchType = tuple[torch.Tensor | None, ...]
WeightedBatchType = tuple[*BatchType, dict[str, Any]]
FullWeightedBatchType = tuple[dict[str, BatchType], dict[str, Any]]


@dataclass(slots=True, eq=False)
class DatasetColumn:
    """Container representing the columns of a dataset in an HDF5 file."""

    column_name: str
    all_columns: list[str]
    used_columns: list[str]
    extra_columns: list[str]
    numer_columns: list[str]
    categ_columns: list[str]
    numer_columns_idx: np.ndarray
    categ_columns_idx: np.ndarray
    shape: tuple[int, ...]
    pad_value: float | None
    labels: dict[str, int] | None

    offset_used_columns: list[str] = field(init=False)
    offset_numer_columns_idx: np.ndarray = field(init=False)
    offset_categ_columns_idx: np.ndarray = field(init=False)

    has_numer_columns: bool = field(init=False)
    has_categ_columns: bool = field(init=False)

    n_objects: int = field(init=False)

    def __post_init__(self) -> None:
        self.offset_used_columns = self.numer_columns + self.categ_columns

        self.offset_numer_columns_idx = np.arange(len(self.numer_columns_idx))
        self.offset_categ_columns_idx = np.arange(
            len(self.numer_columns_idx), len(self.numer_columns_idx) + len(self.categ_columns_idx)
        )

        self.has_numer_columns = len(self.numer_columns) > 0
        self.has_categ_columns = len(self.categ_columns) > 0

        if len(self.shape) == 2:
            self.n_objects = 1
        else:
            self.n_objects = self.shape[1]

    def __repr__(self) -> str:
        return f"{self.column_name}Column(all_columns={len(self.all_columns)}, used_columns={len(self.used_columns)})"

    def __str__(self) -> str:
        s = f"{self.column_name}Column(all_columns={len(self.all_columns)}, used_columns={len(self.used_columns)}, "
        s += f"extra_columns={len(self.extra_columns)}, numer_columns={len(self.numer_columns)}, "
        s += f"categ_columns={len(self.categ_columns)})"
        return s

    def to_dict(self) -> dict[str, Any]:
        return {
            "column_name": self.column_name,
            "all_columns": self.all_columns,
            "used_columns": self.used_columns,
            "extra_columns": self.extra_columns,
            "numer_columns": self.numer_columns,
            "categ_columns": self.categ_columns,
            "numer_columns_idx": self.numer_columns_idx.tolist(),
            "categ_columns_idx": self.categ_columns_idx.tolist(),
            "shape": self.shape,
            "pad_value": self.pad_value,
            "offset_used_columns": self.offset_used_columns,
            "offset_numer_columns_idx": self.offset_numer_columns_idx.tolist(),
            "offset_categ_columns_idx": self.offset_categ_columns_idx.tolist(),
            "has_numer_columns": self.has_numer_columns,
            "has_categ_columns": self.has_categ_columns,
            "n_objects": self.n_objects,
        }

    def to_json(self, output_file: str) -> None:
        return dump_json(self.to_dict(), output_file)


@dataclass(frozen=True, slots=True, eq=False)
class ColumnSelection:
    """Container for selected columns from multiple datasets in HDF5 files."""

    _selection: dict[str, DatasetColumn] = field(default_factory=dict)

    def keys(self) -> list[str]:
        return list(self._selection.keys())

    def __len__(self) -> int:
        return len(self._selection)

    def __setitem__(self, dataset_name: str, dataset_column: DatasetColumn) -> None:
        self._selection[dataset_name] = dataset_column

    def __getitem__(self, dataset_name: str) -> Any:
        return self._selection[dataset_name]

    def __contains__(self, dataset_name: str) -> bool:
        return dataset_name in self._selection

    def __repr__(self) -> str:
        columns_repr = ", ".join([f"{k}: {v.__repr__()}" for k, v in self._selection.items()])
        return f"ColumnSelection({columns_repr})"

    def __str__(self) -> str:
        columns_str = ", ".join([f"{k}: {v.__str__()}" for k, v in self._selection.items()])
        return f"ColumnSelection({columns_str})"

    def items(self) -> Iterable[tuple[str, DatasetColumn]]:
        return self._selection.items()

    def to_dict(self) -> dict[str, Any]:
        return {k: v.to_dict() for k, v in self._selection.items()}

    def to_json(self, output_file: str) -> None:
        return dump_json(self.to_dict(), output_file)


@dataclass(frozen=True, slots=True, repr=False, eq=False)
class StackedDataset:
    """Container for a stacked dataset created from a structured array.

    Attributes
    ----------
    X : np.ndarray
        Feature matrix, typically a 2D or 3D numpy array. If 2D, it is assumed to be of shape (n_samples, n_features).
        If 3D, it is assumed to be of shape (n_samples, n_objects, n_features).
    categ_idx : np.ndarray | None, optional
        Indices of categorical features in the last dimension of X, by default None.
    numer_idx : np.ndarray | None, optional
        Indices of numerical features in the last dimension of X, by default None.
    extra : dict[str, np.ndarray] | None, optional
        Additional data associated with the dataset, such as weights or labels, by default None.
        The keys of the dictionary should be strings, and the values should be numpy arrays.
        If provided, this data can be accessed using the `get_extra` method.
    """

    X: np.ndarray
    categ_idx: np.ndarray | None = None
    numer_idx: np.ndarray | None = None
    extra: dict[str, np.ndarray] | None = field(default_factory=dict)

    @property
    def features(self) -> np.ndarray:
        return self.X

    @property
    def is_empty(self) -> bool:
        return self.X.shape[0] == 0

    @property
    def numer_features(self) -> np.ndarray | None:
        if self.numer_idx is None:
            return None

        return self.X[..., self.numer_idx]

    @property
    def categ_features(self) -> np.ndarray | None:
        if self.categ_idx is None:
            return None

        return self.X[..., self.categ_idx]

    def get_extra(self, name: str, default: Any | None = None) -> np.ndarray | None:
        if self.extra is None or name not in self.extra:
            return default

        return self.extra[name]


@dataclass(frozen=True, slots=True, repr=False, eq=False)
class StackedDatasets:
    """Collection of stacked datasets.

    This class allows you to store multiple `StackedDataset` instances, each identified by a unique key (string).
    You can access datasets by their keys, add new datasets, and retrieve the list of available datasets.

    Attributes
    ----------
    _datasets : dict[str, StackedDataset]
        A dictionary that maps dataset names (keys) to their corresponding `StackedDataset` instances (values).
    """

    _datasets: dict[str, StackedDataset] = field(default_factory=dict)

    def keys(self) -> list[str]:
        return list(self._datasets.keys())

    def __setitem__(self, key: str, value: StackedDataset) -> None:
        if not isinstance(value, StackedDataset):
            raise TypeError(f"Value must be an instance of StackedDataset, got {type(value)} instead.")

        self._datasets[key] = value

    def __getitem__(self, item: str) -> StackedDataset:
        return self._datasets[item]

    def get(self, item: str, default: Any | None = None) -> StackedDataset | None:
        if item not in self._datasets:
            return default

        return self._datasets[item]

    def __len__(self) -> int:
        return len(self._datasets)

    def __iter__(self):
        return iter(self._datasets.values())

    def items(self) -> Iterable[tuple[str, StackedDataset]]:
        return self._datasets.items()

    def __repr__(self) -> str:
        return f"StackedDatasets({self.keys()})"

    def __str__(self) -> str:
        return f"StackedDatasets with datasets: {self.keys()}"


class WeightedBatch:
    """Container for a weighted batch of data.

    All parameters can be either numpy arrays or PyTorch tensors. If numpy arrays are provided, they will be
    converted to PyTorch tensors.

    `X` is the required feature tensor. `y`, `w`, and `y_aux` are standard optional fields.
    Additional tensors can be passed as keyword arguments and accessed as attributes (e.g., `batch.x1`).

    Parameters
    ----------
    X : np.ndarray | torch.Tensor
        Feature matrix (required).
    y : np.ndarray | torch.Tensor | None
        Labels for the data.
    w : np.ndarray | torch.Tensor | None
        Weights for the data.
    y_aux : np.ndarray | torch.Tensor | None
        Auxiliary labels for the data, e.g., signal type or label type.
    culens : np.ndarray | torch.Tensor | None
        Cumulative sequence lengths for variable-length data.
    **extra : np.ndarray | torch.Tensor | None
        Additional named tensors (e.g., x1, x2). Accessible as attributes.
    """

    def __init__(
        self,
        X: np.ndarray | torch.Tensor,
        y: np.ndarray | torch.Tensor | None = None,
        w: np.ndarray | torch.Tensor | None = None,
        y_aux: np.ndarray | torch.Tensor | None = None,
        culens: np.ndarray | torch.Tensor | None = None,
        **extra: np.ndarray | torch.Tensor | None,
    ) -> None:
        if isinstance(X, np.ndarray):
            self.X = torch.from_numpy(X)
        else:
            self.X = X

        self.y = self._to_tensor(y)
        self.w = self._to_tensor(w)
        self.y_aux = self._to_tensor(y_aux)
        self.culens = self._to_tensor(culens)

        self._extra_keys: tuple[str, ...] = tuple(extra.keys())
        for k, v in extra.items():
            setattr(self, k, self._to_tensor(v))

        n_samples = self.X.shape[0]
        for name, val in self._iter_optional():
            if val is not None and val.shape[0] != n_samples:
                raise RuntimeError(f"X and {name} must have the same first dimension!")

    @staticmethod
    def _to_tensor(val: np.ndarray | torch.Tensor | None) -> torch.Tensor | None:
        if isinstance(val, np.ndarray):
            return torch.from_numpy(val)
        return val

    def _iter_optional(self) -> Iterable[tuple[str, torch.Tensor | None]]:
        """Iterate over all optional tensor fields (fixed + extra)."""
        yield "y", self.y
        yield "w", self.w
        yield "y_aux", self.y_aux
        for name in self._extra_keys:
            yield name, getattr(self, name)

    def _iter_all(self) -> Iterable[tuple[str, torch.Tensor | None]]:
        """Iterate over all tensor fields including X."""
        yield "X", self.X
        yield from self._iter_optional()

    @property
    def extra_keys(self) -> tuple[str, ...]:
        return self._extra_keys

    @property
    def feature_shape(self) -> tuple[int, ...]:
        return tuple(self.X.shape)

    def make_batch(self) -> tuple[torch.Tensor | None, ...]:
        batch = tuple(val for _, val in self._iter_all())
        if self.culens is not None:
            batch = batch + (self.culens,)
        return batch

    def _apply(self, indexer: np.ndarray | torch.Tensor | slice) -> WeightedBatch:
        if isinstance(indexer, np.ndarray):
            indexer = torch.from_numpy(indexer)

        if self.culens is not None:
            return self._apply_varlen(indexer, self.culens)

        kwargs: dict[str, Any] = {}
        for name, val in self._iter_all():
            kwargs[name] = val[indexer] if val is not None else None

        return self.__class__(**kwargs)  # type: ignore[arg-type]

    def _apply_varlen(
        self, indexer: np.ndarray | torch.Tensor | slice, culens: np.ndarray | torch.Tensor
    ) -> WeightedBatch:
        # slice event-level fields (y, w, y_aux, extras) normally
        kwargs: dict[str, Any] = {}
        for name, val in self._iter_optional():
            kwargs[name] = val[indexer] if val is not None else None

        # culens has N+1 entries for N events, extend the indexer to include the end boundary
        if isinstance(indexer, slice):
            start, stop, step = indexer.indices(len(culens) - 1)
            culens_indexer = slice(start, stop + 1, step)
        else:
            raise NotImplementedError("Varlen batching only supports slice indexing.")

        sub_culens = culens[culens_indexer]
        packed_start, packed_stop = int(sub_culens[0]), int(sub_culens[-1])
        kwargs["X"] = self.X[packed_start:packed_stop]
        kwargs["culens"] = sub_culens - sub_culens[0]

        return self.__class__(**kwargs)  # type: ignore[arg-type]

    def mask(self, mask: np.ndarray | torch.Tensor) -> WeightedBatch:
        return self._apply(mask)

    def __len__(self) -> int:
        return self.X.shape[0]

    def __getitem__(self, value: slice) -> WeightedBatch:
        return self._apply(value)


@dataclass(frozen=True, slots=True, repr=False, eq=False)
class WeightedDatasetBatch:
    """Collection of weighted batches.

    This class allows you to store multiple `WeightedBatch` instances, each identified by a unique key (string).
    You can access batches by their keys, add new batches, and retrieve the list of available batches.

    Attributes
    ----------
    _datasets : dict[str, WeightedBatch]
        A dictionary that maps dataset names (keys) to their corresponding `WeightedBatch` instances (values).
    """

    _datasets: dict[str, WeightedBatch] = field(default_factory=dict)

    def __setitem__(self, key: str, value: WeightedBatch) -> None:
        self._datasets[key] = value

    def __getitem__(self, args: str | tuple[str, slice]) -> WeightedBatch:
        if type(args) is str:
            return self._datasets[args]
        elif type(args) is tuple and len(args) == 2:
            return self._datasets[args[0]][args[1]]
        else:
            raise ValueError(f"Invalid arguments for __getitem__: {args}")

    def __len__(self) -> int:
        return len(self._datasets)

    def keys(self) -> list[str]:
        return list(self._datasets.keys())

    @property
    def feature_shape(self):
        return {k: v.X.shape for k, v in self._datasets.items()}

    @property
    def dim(self) -> int:
        if len(self._datasets) == 0:
            raise RuntimeError("No datasets in WeightedDatasetBatch to determine dimension.")

        shapes = [v.X.shape[0] for v in self._datasets.values()]

        if len(set(shapes)) == 1:
            return shapes[0]

        # varlen: datasets have different first dims, use event-level (no culens) dataset
        for v in self._datasets.values():
            if v.culens is None:
                return v.X.shape[0]

        raise RuntimeError("All datasets in WeightedDatasetBatch must have the same first dimension.")

    def mask(self, mask: np.ndarray | torch.Tensor, dataset: str | None = None) -> WeightedDatasetBatch:
        if isinstance(mask, np.ndarray):
            mask = torch.from_numpy(mask)

        _masked_datasets = {}
        for key, w_batch in self._datasets.items():
            if dataset is None or key == dataset:
                _masked_datasets[key] = w_batch.mask(mask)
            else:
                _masked_datasets[key] = w_batch

        return self.__class__(_masked_datasets)

    def make_batch(self) -> dict[str, BatchType]:
        batch = {}
        for key, ds_batch in self._datasets.items():
            batch[key] = ds_batch.make_batch()
        return batch

    def __repr__(self) -> str:
        return f"WeightedDatasetBatch({self.keys()})"

    def __str__(self) -> str:
        return f"WeightedDatasetBatch with datasets: {self.keys()}"
