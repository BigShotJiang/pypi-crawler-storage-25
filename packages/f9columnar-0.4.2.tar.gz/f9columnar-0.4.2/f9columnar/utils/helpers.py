import datetime
import json
import logging
import os
import pickle
import tarfile
import time
from pathlib import Path
from typing import Any, Callable, Literal

import dill
import hist
import numpy as np
import requests
import uproot
import yaml
from matplotlib import rc
from tqdm import tqdm
from uncertainties import unumpy
from uproot.exceptions import KeyInFileError

INVALID_CATEG_TOKEN = np.iinfo(np.int32).min  # -2147483648


def load_pickle(name: str) -> Any:
    with open(name, "rb") as f:
        data = dill.load(f)
    return data


def dump_pickle(name: str, data: Any, recurse: bool = False, pickle_fallback: bool = False) -> None:
    if pickle_fallback:
        with open(name, "wb") as f:
            pickle.dump(data, f)

        return None

    if recurse:
        dill.settings["recurse"] = True

    with open(name, "wb") as f:
        dill.dump(data, f)


def load_json(path: str) -> dict:
    with open(path, "r") as f:
        dct = json.load(f)
    return dct


def dump_json(dct: dict, path: str, indent: int = 2) -> None:
    with open(path, "w") as f:
        json.dump(dct, f, indent=indent)


def load_yaml(file_path: str) -> dict[str, Any]:
    with open(file_path, "r") as f:
        try:
            dct = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise RuntimeError(f"Error while loading yaml file {file_path}: {exc}")

    return dct


def dump_yaml(dct: dict, file_path: str, indent: int = 2, **kwargs: Any) -> None:
    class CustomDumper(yaml.Dumper):
        def increase_indent(self, flow: bool = False, indentless: bool = False) -> None:
            return super().increase_indent(flow, False)

    with open(file_path, "w") as f:
        yaml.dump(dct, f, Dumper=CustomDumper, default_flow_style=False, indent=indent, **kwargs)


def get_ms_time() -> int:
    return time.time_ns() // 1_000_000


def get_ms_datetime() -> datetime.datetime:
    ms_time = get_ms_time()
    return datetime.datetime.fromtimestamp(int(ms_time) // 1000)


def get_file_size(file_path: str, convert_to: str = "gb") -> float:
    byte_size = os.path.getsize(file_path)

    if convert_to.lower() == "gb":
        return byte_size / 1024 / 1024 / 1024
    elif convert_to.lower() == "mb":
        return byte_size / 1024 / 1024
    elif convert_to.lower() == "kb":
        return byte_size / 1024
    else:
        return byte_size


def get_act_run() -> None:
    run_file_names = ["act_run.py", "act_run.sh"]

    for run_file in run_file_names:
        file_path = f"{os.path.dirname(os.path.abspath(__file__))}/../submit/{run_file}"
        os.system(f"cp {file_path} .")


def open_root_file(
    file_path: str, key: str = "physics", branches: list[str] | None = None, to_arrays: bool = True
) -> Any:
    with uproot.open(file_path) as f:
        f_data = f[key]

    if to_arrays:
        return f_data.arrays(branches if branches else f_data.keys())
    else:
        return f_data


def get_num_entries(file_path: str, key: str = "physics") -> int:
    try:
        with uproot.open(file_path) as f:
            f_data = f[key]
            num_entries = f_data.num_entries
        return num_entries
    except KeyInFileError:
        logging.error(f"Key {key} not found in file {file_path}!")
        return 0


def hist_to_unumpy(h: hist.Hist, std: bool = True, flatten: bool = False, zero_to_nan: bool = False) -> unumpy.uarray:
    if flatten:
        values, err = h.values().flatten(), h.variances()
    else:
        values, err = h.values(), h.variances()

    if err is None:
        err = np.zeros_like(values)

    if flatten:
        err = err.flatten()

    if zero_to_nan:
        values[np.where(values == 0.0)[0]] = np.nan
        err[np.where(err == 0.0)[0]] = np.nan

    if std:
        err = np.sqrt(err)

    return unumpy.uarray(values, err)


def split_by_chunk(total: int, chunk_size: int) -> list[int]:
    """Split a number into chunks of a given size."""
    n_full_chunks = total // chunk_size
    remainder = total % chunk_size

    result = [chunk_size] * n_full_chunks
    if remainder > 0:
        result.append(remainder)

    return result


def handle_plot_exception(func: Callable[..., Any]) -> Callable[..., Any | None]:
    """Decorator to handle all exceptions in plotting functions."""

    def wrapper(*args: Any, **kwargs: Any) -> Any | None:
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logging.warning(f"Plotting of {func.__name__} failed with exception: {e}")
            return None

    return wrapper


def set_default_font_family() -> None:
    """Set the matplotlib default font family to Latin Modern sans."""
    rc("font", **{"family": "serif", "serif": ["Latin Modern sans"]})


def url_download(url: str, data_dir: str, fname: str | None = None, chunk_size: int = 1024) -> str:
    """Downloads file from url to data_dir.

    Parameters
    ----------
    url : str
        URL of file to download.
    data_dir : str
        Downloaded in this directory (needs to exist).
    fname : str, optional
        File name, by default None.
    chunk_size : int, optional
        Chunk size for downloading, by default 1024

    Returns
    -------
    File name of downloaded file.

    References
    ----------
    .. [1] https://gist.github.com/yanqd0/c13ed29e29432e3cf3e7c38467f42f51

    """
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)

    if fname is None:
        fname = data_dir + url.split("/")[-1]
    else:
        fname = data_dir + fname

    if Path(fname).is_file() is not True:
        logging.info(f"Started downloading from {url} ...")

        resp = requests.get(url, stream=True)
        total = int(resp.headers.get("content-length", 0))

        with (
            open(fname, "wb") as file,
            tqdm(desc=fname, total=total, unit="iB", unit_scale=True, unit_divisor=1024) as bar,
        ):
            for data in resp.iter_content(chunk_size=chunk_size):
                size = file.write(data)
                bar.update(size)
    else:
        logging.info(f"Already downloaded {fname}!")

    return fname


def create_tar_file(
    source_dir: str | Path,
    output_tar: str | Path,
    exclude: list[str] | None = None,
    compression: Literal["", "gz", "bz2", "xz"] = "gz",
) -> None:
    """Create a tar archive from a directory, excluding specified files/directories.

    Parameters
    ----------
    source_dir : str or Path
        Path to the directory to archive.
    output_tar : str or Path
        Path for the output tar file. If compression is specified, appropriate
        extension (.tar.gz, .tar.bz2, .tar.xz) should be included.
    exclude : list of str, optional
        List of file or directory names to exclude from the archive. Names are
        matched against any part of the relative path. For example, if
        "__pycache__" is in the exclude list, all __pycache__ directories at
        any level will be excluded. Default is None (no exclusions).
    compression : {"", "gz", "bz2", "xz"}, default "gz"
        Compression algorithm to use.

    Notes
    -----
    The exclusion mechanism checks each component of a file's path. If any
    component matches a name in the exclude list, the entire path is excluded.
    This means that specifying "temp" will exclude:
        - A file named "temp" in the root directory
        - A directory named "temp" anywhere in the tree
        - All contents within any "temp" directory

    Returns
    -------
    None

    """
    source_path = Path(source_dir)
    output_path = Path(output_tar)

    exclude_set = set(exclude or [])

    mode: Literal["w", "w:gz", "w:bz2", "w:xz"]
    if compression == "":
        mode = "w"
    elif compression == "gz":
        mode = "w:gz"
    elif compression == "bz2":
        mode = "w:bz2"
    else:
        mode = "w:xz"

    def filter_func(tarinfo: tarfile.TarInfo) -> tarfile.TarInfo | None:
        rel_path = Path(tarinfo.name).relative_to(source_path.name)

        for part in rel_path.parts:
            if part in exclude_set:
                return None

        return tarinfo

    with tarfile.open(str(output_path), mode) as tar:
        tar.add(str(source_path), arcname=source_path.name, filter=filter_func)
