from __future__ import annotations

import copy
import glob
import os
import re
from dataclasses import dataclass
from typing import Any

import awkward as ak
import numpy as np
from hist import Hist, loc, rebin
from hist.axis import Regular, Variable
from hist.storage import Double, Weight

from f9columnar.processors import Processor
from f9columnar.utils.helpers import dump_pickle, load_pickle


@dataclass
class Hist1d:
    """Dataclass for a 1D histogram. Wraps the hist.Hist object.

    Parameters
    ----------
    name : str
        Name of the histogram.
    nbins : int, optional
        Number of bins.
    lower : float, optional
        Lower edge of the histogram.
    upper : float, optional
        Upper edge of the histogram.
    bins : list | np.ndarray, optional
        Custom bin edges.
    storage : str, optional
        Storage type. Options: "double", "weight". Used for weights and uncertainties. See [1].
    underflow : bool, optional
        Include underflow bin.
    overflow : bool, optional
        Include overflow bin.
    log : bool, optional
        Logarithmic binning. If True, nbins, lower, and upper are needed.
    hist : hist.Hist
        Histogram object. Assigned in post init.

    Note
    ----
    - If bins is provided, nbins, lower, and upper are ignored.
    - If bins is not provided, nbins, lower, and upper are required.

    References
    ----------
    .. [1] https://hist.readthedocs.io/en/latest/user-guide/storages.html

    """

    name: str
    nbins: int | None = None
    lower: float | None = None
    upper: float | None = None
    bins: list | np.ndarray | None = None
    storage: str = "double"
    underflow: bool = False
    overflow: bool = False
    log: bool = False

    def _get_regular_binning(self) -> Regular | Variable:
        if self.nbins is None or self.lower is None or self.upper is None:
            raise ValueError("Provide nbins, lower, and upper.")

        binning: Regular | Variable

        if self.log:
            bins = np.logspace(np.log(self.lower), np.log(self.upper), self.nbins, base=np.e)
            binning = Variable(
                bins,
                name=self.name,
                underflow=self.underflow,
                overflow=self.overflow,
            )
        else:
            binning = Regular(
                self.nbins,
                self.lower,
                self.upper,
                name=self.name,
                underflow=self.underflow,
                overflow=self.overflow,
            )

        return binning

    def _get_variable_binning(self) -> Variable:
        if self.bins is None:
            raise ValueError("Provide bins.")

        return Variable(
            self.bins,
            name=self.name,
            underflow=self.underflow,
            overflow=self.overflow,
        )

    def _get_storage(self) -> Double | Weight:
        if self.storage.lower() == "double":
            return Double()
        elif self.storage.lower() == "weight":
            return Weight()
        else:
            raise NotImplementedError(f"Storage type {self.storage} not implemented!")

    def _get_hist(self) -> Hist:
        storage = self._get_storage()

        binning: Regular | Variable

        if self.bins is not None:
            binning = self._get_variable_binning()
        elif self.nbins is not None and self.lower is not None and self.upper is not None:
            binning = self._get_regular_binning()
        else:
            raise ValueError("Please provide either nbins, lower, and upper or bins.")

        return Hist(binning, name=self.name, storage=storage)

    def __post_init__(self) -> None:
        self.hist: Hist = self._get_hist()


@dataclass
class HistNd:
    """Dataclass for an N-dimensional histogram. Wraps the hist.Hist object.

    Parameters
    ----------
    name : str
        Name of the histogram.
    hists1d : List[Hist1d]
        List of 1D histograms to build the N-dimensional histogram.
    hist : hist.Hist
        Histogram object. Assigned in post init.
    """

    name: str
    hists1d: list[Hist1d]

    def _get_hist(self) -> Hist:
        axes, _storage = [], []
        for hist1d in self.hists1d:
            axes.append(hist1d.hist.axes[hist1d.name])
            _storage.append(hist1d.storage)

        _storage = list(set(_storage))

        if not len(_storage) == 1:
            raise ValueError("Storage types must be the same for all 1D histograms.")

        storage_type = _storage[0]

        storage: Double | Weight

        if storage_type.lower() == "double":
            storage = Double()
        elif storage_type.lower() == "weight":
            storage = Weight()
        else:
            raise NotImplementedError(f"Storage type {storage_type} not implemented!")

        return Hist(*axes, name=self.name, storage=storage)

    def __post_init__(self) -> None:
        self.hist = self._get_hist()


class HistsCollection:
    def __init__(self) -> None:
        """Histogram collection for managing multiple histograms with variations.

        Attributes
        ----------
        _hists_collection : dict[str, dict[str, Hist]]
            Dictionary to store histograms with variations.
        _hists_metadata : dict[str, Any]
            Dictionary to store metadata for histograms with variations.

        """
        self._hists_collection: dict[str, dict[str, Hist]] = {}
        self._hists_metadata: dict[str, Any] | None = None

    def add_hist(self, quantity: str, hist_obj: Hist, variation: str = "nominal") -> HistsCollection:
        if variation not in self._hists_collection:
            self._hists_collection[variation] = {}

        self._hists_collection[variation][quantity] = hist_obj

        return self

    def add_metadata(self, metadata: dict[str, Any], update: bool = True) -> HistsCollection:
        if not isinstance(metadata, dict):
            raise TypeError("Metadata must be a dictionary!")

        if self._hists_metadata is None:
            self._hists_metadata = metadata
            return self

        if update:
            self._hists_metadata.update(metadata)

        return self

    def _fill_variation_check(self, quantity: str, variation: str) -> None:
        if variation not in self._hists_collection:
            self._hists_collection[variation] = {}

            if quantity not in self._hists_collection["nominal"]:
                raise KeyError(f"Histogram nominal {quantity} not found in collection for variation {variation}!")

            base_hist = copy.deepcopy(self._hists_collection["nominal"][quantity]).reset()
            self._hists_collection[variation][quantity] = base_hist

    def fill_1d(
        self,
        quantity: str,
        data: ak.Array | np.ndarray,
        weight: ak.Array | np.ndarray | None = None,
        variation: str = "nominal",
    ) -> HistsCollection:
        self._fill_variation_check(quantity, variation)

        self._hists_collection[variation][quantity].fill(data, weight=weight)

        return self

    def fill_Nd(
        self,
        quantity: str,
        data_lst: list[ak.Array | np.ndarray],
        weight: ak.Array | np.ndarray | None = None,
        variation: str = "nominal",
    ) -> HistsCollection:
        self._fill_variation_check(quantity, variation)

        self._hists_collection[variation][quantity].fill(*data_lst, weight=weight)

        return self

    def reset(self) -> HistsCollection:
        for variation_hists in self._hists_collection.values():
            for h in variation_hists.values():
                h.reset()

        return self

    def get_hist(self, hist_name: str, variation: str = "nominal") -> Hist:
        return self._hists_collection[variation][hist_name]

    def get_hist_quantities(self, variation: str = "nominal") -> list[str]:
        return list(self._hists_collection[variation].keys())

    def get_hist_info(self, quantity: str, variation: str = "nominal") -> dict[str, np.ndarray]:
        return {
            "egdes": self._hists_collection[variation][quantity].axes[quantity].edges,
            "centers": self._hists_collection[variation][quantity].axes[quantity].centers,
            "widths": self._hists_collection[variation][quantity].axes[quantity].widths,
        }

    def get_hist_values(self, quantity: str, variation: str = "nominal") -> dict[str, np.ndarray | None]:
        return {
            "values": self._hists_collection[variation][quantity].values(),
            "variances": self._hists_collection[variation][quantity].variances(),
        }

    def get_metadata(self) -> dict[str, Any] | None:
        return self._hists_metadata

    def save_hists(self, file_path: str) -> None:
        save_dct = {"hists": self._hists_collection, "metadata": self._hists_metadata}
        dump_pickle(file_path, save_dct, pickle_fallback=True)


class HistogramProcessor(Processor):
    def __init__(self, prefix: str = "") -> None:
        """Histogram processor for making and filling histograms.

        Parameters
        ----------
        prefix : str, optional
            Prefix for the processor name.

        References
        ----------
        .. [1] https://hist.readthedocs.io/en/latest/user-guide/quickstart.html
        .. [2] https://mplhep.readthedocs.io/en/latest/api.html
        .. [3] https://hsf-training.github.io/analysis-essentials/advanced-python/40Histograms.html

        """
        super().__init__(name=f"{prefix}Histogram" if prefix else "histogram")
        self.hists_collection = HistsCollection()

        self._attached_hist_branches = False

    def _run(self, *args: Any, copy_inputs: bool = True, **kwargs: Any) -> Processor:
        self._attach_hist_branches()
        return super()._run(*args, copy_inputs=copy_inputs, **kwargs)

    def _attach_hist_branches(self) -> None:
        """Important: hist name must be the same as the alias used in previous processors."""

        if self._attached_hist_branches:
            return None

        hist_branches = self.get_hist_names()

        to_attach, to_attach_varied = set(), set()
        for proc in self.previous_processors.values():
            for br in proc.aliases:
                if br in hist_branches:
                    to_attach.add(br)

            for br in proc.varied_aliases:
                if br in hist_branches:
                    to_attach_varied.add(br)

        self.attach_branches(list(to_attach), is_varied=False, overwrite=True)
        self.attach_branches(list(to_attach_varied), is_varied=True, overwrite=True)

        self._attached_hist_branches = True

    def make_hist1d(
        self,
        quantity: str,
        nbins: int | None = None,
        lower: float | None = None,
        upper: float | None = None,
        bins: list | np.ndarray | None = None,
        underflow: bool = False,
        overflow: bool = False,
        log: bool = False,
        hist_kwargs_dct: dict | None = None,
        storage_type: str = "weight",
        return_hist1d: bool = False,
    ) -> Hist1d | HistogramProcessor:
        """Make a 1D histogram object and store it in the hists dictionary.

        Parameters
        ----------
        quantity : str
            Name of the 1D histogram.
        hist_kwargs_dct : dict, optional
            Dictionary for building the 1D histogram.
        storage_type : str, optional
            Storage type, by default "weight".
        return_hist1d : bool, optional
            Return the Hist1d dataclass object.

        Warning
        -------
        Unity weights are automatically added for data histograms.

        """
        if hist_kwargs_dct is not None:
            hist1d = Hist1d(quantity, storage=storage_type, **hist_kwargs_dct)
        else:
            hist1d = Hist1d(quantity, nbins, lower, upper, bins, storage_type, underflow, overflow, log)

        if return_hist1d:
            return hist1d

        self.hists_collection.add_hist(quantity, hist1d.hist, variation="nominal")

        return self

    def make_histNd(
        self,
        quantity: str,
        hist1d_kwargs_dcts: dict,
        storage_type: str = "weight",
    ) -> HistogramProcessor:
        """Make an N-dimensional histogram object and store it in the hists dictionary.

        Parameters
        ----------
        quantity : str
            Name of the N-dimensional histogram.
        hist1d_kwargs_dcts : dict
            Dictionary of 1D histogram kwargs for building the N-dimensional histogram.
        storage_type : str, optional
            Storage type, by default "weight".

        """
        hists1d = []
        for hist1d_name, hist_kwargs_dct in hist1d_kwargs_dcts.items():
            hist1d = self.make_hist1d(
                hist1d_name,
                storage_type=storage_type,
                hist_kwargs_dct=hist_kwargs_dct,
                return_hist1d=True,
            )

            if type(hist1d) is not Hist1d:
                raise TypeError("hist1d must be a Hist1d object!")

            hists1d.append(hist1d)

        histNd = HistNd(quantity, hists1d)
        self.hists_collection.add_hist(quantity, histNd.hist, variation="nominal")

        return self

    def fill_hist1d(
        self,
        quantity: str,
        data: ak.Array | np.ndarray,
        weight: ak.Array | np.ndarray | None = None,
        variation: str | None = "nominal",
    ) -> HistogramProcessor:
        """Fill a 1D histogram with data and weight. Optionally store metadata."""

        if variation is None:
            variation = "nominal"

        self.hists_collection.fill_1d(quantity, data, weight=weight, variation=variation)
        return self

    def fill_histNd(
        self,
        quantity: str,
        data_lst: list[ak.Array | np.ndarray],
        weight: ak.Array | np.ndarray = None,
        variation: str | None = "nominal",
    ) -> HistogramProcessor:
        """Fill an N-dimensional histogram with data and weight. Optionally store metadata."""

        if variation is None:
            variation = "nominal"

        self.hists_collection.fill_Nd(quantity, data_lst, weight=weight, variation=variation)
        return self

    def add_metadata(self, metadata: dict[str, Any] | None, update: bool = False) -> HistogramProcessor:
        """Add metadata to the histogram collection."""
        if metadata is None:
            return self

        self.hists_collection.add_metadata(metadata, update=update)
        return self

    def get_hist(self, quantity: str, variation: str = "nominal") -> Hist:
        return self.hists_collection.get_hist(quantity, variation=variation)

    def get_hist_names(self, variation: str = "nominal") -> list[str]:
        return self.hists_collection.get_hist_quantities(variation=variation)

    def get_hist_info(self, quantity: str, variation: str = "nominal") -> dict[str, np.ndarray]:
        return self.hists_collection.get_hist_info(quantity, variation=variation)

    def get_hist_values(self, quantity: str, variation: str = "nominal") -> dict[str, np.ndarray | None]:
        return self.hists_collection.get_hist_values(quantity, variation=variation)

    def get_metadata(self) -> dict[str, Any] | None:
        return self.hists_collection.get_metadata()

    def __getitem__(self, hist_name: str) -> Hist:
        return self.get_hist(hist_name)

    def save(self, save_path: str, save_name: str) -> None:
        file_path = f"{save_path}/{save_name}_hists.p"
        self.hists_collection.save_hists(file_path)

    def finalize(self) -> None:
        self.delta_time, self.delta_n = 0.0, {}
        self.hists_collection.reset()


def _match_edge(e: float, edges: np.ndarray) -> int:
    if np.isinf(e):
        idx = np.flatnonzero(np.isinf(edges) & (np.sign(edges) == np.sign(e)))
        return int(idx[0])
    return int(np.argmin(np.abs(edges - e)))


def rebin_axis(h: Hist, axis_name: str, new_edges: np.ndarray | list[float]) -> Hist:
    """Rebin an N-dimensional hist.Hist along a single axis to new bin edges.

    If new edges are a subset of the existing edges, bins are merged exactly.
    Otherwise, bin contents are redistributed using fractional overlap, assuming
    a uniform distribution within each original bin.

    Parameters
    ----------
    h : hist.Hist
        Input histogram (any number of dimensions).
    axis_name : str
        Name of the axis to rebin.
    new_edges : array-like
        New bin edges.

    Returns
    -------
    hist.Hist
        Rebinned histogram.

    """
    if isinstance(new_edges, list):
        new_edges = [np.inf if str(e).lower() == "inf" else e for e in new_edges]

    new_edges = np.asarray(new_edges, dtype=np.float64)
    old_edges = h.axes[axis_name].edges
    n_old = len(old_edges) - 1
    n_new = len(new_edges) - 1

    # check if new edges are a subset of old edges (fast path)
    edges_aligned = all(np.any(np.isclose(old_edges, e)) for e in new_edges)

    rebin_ax_idx = list(h.axes).index(h.axes[axis_name])

    new_axes = []
    for ax in h.axes:
        if ax.name == axis_name:
            new_axes.append(
                Variable(new_edges, name=ax.name, underflow=ax.traits.underflow, overflow=ax.traits.overflow)
            )
        else:
            new_axes.append(ax)

    new_h = Hist(*new_axes, storage=h.storage_type())

    old_view = h.view(flow=False)
    new_view = new_h.view(flow=False)

    # check if the view is a structured array (e.g. Weight storage has "value" and "variance" fields)
    is_structured = old_view.dtype.names is not None

    if edges_aligned:
        new_indices = np.array([_match_edge(e, old_edges) for e in new_edges])

        for i in range(n_new):
            lo, hi = new_indices[i], new_indices[i + 1]
            src = [slice(None)] * len(h.axes)
            src[rebin_ax_idx] = slice(lo, hi)

            dst = [slice(None)] * len(h.axes)
            dst[rebin_ax_idx] = i  # type: ignore[call-overload]

            new_view[tuple(dst)] = old_view[tuple(src)].sum(axis=rebin_ax_idx)
    else:
        # general case: fractional overlap redistribution
        old_widths = np.diff(old_edges)

        for i in range(n_new):
            new_lo, new_hi = new_edges[i], new_edges[i + 1]

            dst = [slice(None)] * len(h.axes)
            dst[rebin_ax_idx] = i  # type: ignore[call-overload]

            for j in range(n_old):
                old_lo, old_hi = old_edges[j], old_edges[j + 1]
                overlap = max(0.0, min(old_hi, new_hi) - max(old_lo, new_lo))

                if overlap == 0.0:
                    continue

                frac = 1.0 if np.isinf(old_widths[j]) else overlap / old_widths[j]

                src = [slice(None)] * len(h.axes)
                src[rebin_ax_idx] = j  # type: ignore[call-overload]

                src_val = old_view[tuple(src)]

                if is_structured:
                    for field in old_view.dtype.names:  # type: ignore[union-attr]
                        new_view[field][tuple(dst)] += src_val[field] * frac  # type: ignore[index]
                else:
                    new_view[tuple(dst)] += src_val * frac

    return new_h


def rebin_axis_by_n(h: Hist, axis_name: str, n_bins: int) -> Hist:
    """Rebin an N-dimensional hist.Hist along a single axis by merging bins to reach approximately n_bins.

    Parameters
    ----------
    h : Hist
        Input histogram (any number of dimensions).
    axis_name : str
        Name of the axis to rebin.
    n_bins : int
        Target number of bins. The actual number may differ slightly
        since only integer rebin factors are supported.

    Returns
    -------
    Hist
        Rebinned histogram.

    """
    current_n_bins = len(h.axes[axis_name].edges) - 1
    factor = max(1, current_n_bins // n_bins)

    return Hist(h[{axis_name: slice(None, None, rebin(factor))}])  # type: ignore[arg-type]


def slice_axis(h: Hist, axis_name: str, low: float, high: float) -> Hist:
    """Slice an N-dimensional hist.Hist along a single axis to a new range.

    Parameters
    ----------
    h : Hist
        Input histogram (any number of dimensions).
    axis_name : str
        Name of the axis to slice.
    low : float
        New lower edge (must coincide with an existing bin edge).
    high : float
        New upper edge (must coincide with an existing bin edge).

    Returns
    -------
    Hist
        Sliced histogram.

    """
    return Hist(h[{axis_name: slice(loc(low), loc(high))}])  # type: ignore[arg-type]


def combine_saved_hists(
    files: list[str] | None = None,
    process_name: str | None = None,
    save_dir: str | None = None,
) -> dict[str, dict[str, Hist]]:
    """Combine histogram files by summing histograms with matching variation and variable names.

    Parameters
    ----------
    files : list[str], optional
        Explicit list of pickle file paths to combine. If provided, `process_name`
        and `save_dir` are ignored.
    process_name : str, optional
        Process name used to glob files under `save_dir`. Required when `files` is None.
    save_dir : str, optional
        Directory to search for histogram files. Required when `files` is None.

    Returns
    -------
    dict[str, dict[str, Hist]]
        Nested dictionary of `{variation: {variable: Hist}}` with all matching
        histograms summed together.

    Raises
    ------
    ValueError
        If `files` is None and `process_name` or `save_dir` are not provided.
    RuntimeError
        If no files are found or provided.

    """
    if files is None:
        if process_name is None:
            raise ValueError("Provide process_name when using save_dir!")

        if save_dir is None:
            raise ValueError("Provide save_dir when using process_name!")

        files = glob.glob(os.path.join(save_dir, f"*_{process_name}_hists.p"))

    if files is None:
        raise RuntimeError("Either save_dir or files must be provided!")

    merged_hists: dict[str, dict[str, Hist]] = {}

    for hist_path in files:
        pickled_hists = load_pickle(hist_path)["hists"]

        for variation, variable_hists_dct in pickled_hists.items():
            if variation not in merged_hists:
                merged_hists[variation] = {}

            for variable, hist in variable_hists_dct.items():
                if variable not in merged_hists[variation]:
                    merged_hists[variation][variable] = hist
                else:
                    merged_hists[variation][variable] += hist

    return merged_hists


def _get_group_key(filepath: str) -> str:
    basename = os.path.basename(filepath)

    if basename.startswith("ds_"):
        return "ds"

    match = re.search(r"__(.+?)_ds", basename)
    if match:
        return match.group(1)

    match = re.search(r"^(.+?)_ds", basename)
    if match:
        return match.group(1)

    raise RuntimeError(f"Could not extract a valid group key from filename {filepath}!")


def resolve_combine_saved_hists(
    files: list[str] | None = None,
    process_name: str | None = None,
    save_dir: str | None = None,
) -> dict[str, dict[str, dict[str, Hist]]]:
    """Group histogram files by a key extracted from their filenames, then combine each group.

    The group key is the substring between `__` and `_ds` in the filename
    (e.g. `mu_loose` from `proc_histogram__mu_loose_ds_diboson_MC20e_id_0_hists.p`).
    If `__` is absent the full filename stem is used as the key. Files sharing
    the same key are merged via :func:`combine_saved_hists`.

    Parameters
    ----------
    files : list[str], optional
        Explicit list of pickle file paths to resolve and combine. If provided,
        `process_name` and `save_dir` are ignored.
    process_name : str, optional
        Process name used to glob files under `save_dir`. Required when `files` is None.
    save_dir : str, optional
        Directory to search for histogram files. Required when `files` is None.

    Returns
    -------
    dict[str, dict[str, dict[str, Hist]]]
        Nested dictionary of `{group_key: {variation: {variable: Hist}}}` with
        histograms summed within each group.

    Raises
    ------
    ValueError
        If `files` is None and `process_name` or `save_dir` are not provided.
    RuntimeError
        If no files are found or provided.

    """
    if files is None:
        if process_name is None:
            raise ValueError("Provide process_name when using save_dir!")

        if save_dir is None:
            raise ValueError("Provide save_dir when using process_name!")

        files = glob.glob(os.path.join(save_dir, f"*_{process_name}_hists.p"))

    if not files:
        raise RuntimeError("Either save_dir or files must be provided!")

    grouped: dict[str, list[str]] = {}
    for f in files:
        key = _get_group_key(f)
        grouped.setdefault(key, []).append(f)

    return {key: combine_saved_hists(files=group_files) for key, group_files in grouped.items()}
