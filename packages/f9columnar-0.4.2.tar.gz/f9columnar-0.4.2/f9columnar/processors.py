from __future__ import annotations

import copy
import os
import time
from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass
from functools import cached_property, reduce, wraps
from typing import Any, Callable, Self

import awkward as ak
import networkx as nx
import numpy as np

from f9columnar.analysis.utils import VALID_BRANCH_GROUPS
from f9columnar.utils.draw_graph import draw_graph
from f9columnar.utils.helpers import handle_plot_exception


class ProcessorsGraph:
    def __init__(
        self,
        prune_results: bool = True,
        global_attributes: dict[str, Any] | None = None,
        identifier: str | dict[str, str] = "",
        prune_last_node: bool = True,
    ) -> None:
        """Directed Acyclic Graph (DAG) composer for data processing pipelines.

        ProcessorsGraph orchestrates the execution of processor nodes in a dependency-aware
        manner. Each processor receives the results of its predecessors as inputs, enabling
        complex data transformation pipelines with automatic dependency resolution and
        optional memory management through result pruning.

        The graph ensures processors execute in topologically sorted order, guaranteeing
        that all dependencies are satisfied before a processor runs. This enables both
        linear chains and complex branching/merging patterns in data processing workflows.

        Parameters
        ----------
        prune_results : bool, optional
            If True, automatically removes processor results from memory once all dependent
            nodes have been executed, by default True. This reduces memory footprint for large
            pipelines at the cost of not being able to access pruned results later.
        global_attributes : dict[str, Any], optional
            Dictionary of attributes to inject into all processors during execution, by default None.
            Useful for passing shared configuration or state across the entire pipeline.
        identifier : str or dict[str, str], optional
            Suffix to append to processor names, by default "". Can be:
              - str: Same suffix applied to all processor names
              - dict: Processor-specific suffixes mapping processor names to their identifiers
            Enables running multiple instances of the same processor graph with unique names.
        prune_last_node : bool, optional
            If True, prunes the results of the last node in the graph as well, by default True.
            Useful when the final output is not needed and does not need to be retained in memory.

        Attributes
        ----------
        processors : dict[str, Processor]
            Registry of all processor instances in the graph, keyed by processor name.
        processors_edges : list[tuple[str, str]]
            List of directed edges connecting processors, where each tuple is (parent, child).
        graph : networkx.DiGraph
            Underlying NetworkX directed graph structure storing nodes and edges.
        topo_sorted : list[str]
            Topologically sorted list of processor names defining execution order.

        Methods
        -------
        add(*processors)
            Register processor nodes in the graph.
        connect(processor_edges=None)
            Define dependencies between processors via edges.
        chain()
            Connect all processors in linear sequence based on addition order.
        extend(other_graph, extend_node)
            Append another graph after a specified node.
        insert(other_graph, insert_node)
            Inject another graph between a node and its successors.
        split_graph_at_node(split_node)
            Partition the graph into predecessor and successor subgraphs at a node.
        fit(arrays, reports, event_iterator_worker, **kwargs)
            Execute all processors in topological order and return results.
        style_graph(fillcolor)
            Apply visual styling to graph nodes for visualization.
        draw(file_path, fontsize=10, jupyter=False, **kwargs)
            Render and save graph visualization to file.

        """
        self.prune_results = prune_results
        self.global_attributes = global_attributes
        self.identifier = identifier
        self.prune_last_node = prune_last_node

        self.processors: dict[str, Processor] = {}
        self.processors_edges: list[tuple[str, str]] = []
        self.graph = nx.DiGraph()
        self.topo_sorted: list[str] = []

        self._node_predecessors: dict[str, list[str]] = {}
        self._node_successors: dict[str, list[str]] = {}
        self._dependencies: dict[str, set[str]] = {}

        self._worker_id: int = -1

        self._pruning_cache: dict[int, set[str]] = {}
        self._last_nodes_cache: list[str] = []
        self._has_pruning_cache = False

    def __getitem__(self, name: str) -> Processor:
        return self.processors[name]

    @property
    def last_node(self) -> str | list[str]:
        nodes = [node for node in self.graph.nodes() if self.graph.out_degree(node) == 0]
        if len(nodes) == 1:
            return nodes[0]
        else:
            return nodes

    def add(self, *processors: Processor) -> ProcessorsGraph:
        for processor in processors:
            if processor.name not in self.processors:
                if type(self.identifier) is dict:
                    identifier = self.identifier.get(processor.name, "")
                else:
                    identifier = self.identifier  # type: ignore[assignment]

                name = f"{processor.name}{identifier}"
                self.processors[name] = processor
                processor.name = name

                if identifier:
                    processor._graph_identifier = str(identifier)
            else:
                raise ValueError(f"Node {processor.name} already exists. Node names must be unique!")

            if self.global_attributes is not None and processor.name in self.global_attributes:
                raise RuntimeError(f"Node {processor.name} already exists in global!")

        return self

    def change_identifier(self, new_identifier: str | dict[str, str]) -> ProcessorsGraph:
        new_graph = ProcessorsGraph(
            prune_results=self.prune_results,
            global_attributes=self.global_attributes,
            identifier=new_identifier,
            prune_last_node=self.prune_last_node,
        )

        new_graph.add(*self.processors.values())
        new_graph.connect(self.processors_edges)

        return new_graph

    def __add__(self, other: Any) -> ProcessorsGraph:
        if type(other) is list:
            return self.add(*other)
        else:
            return self.add(other)

    def connect(self, processor_edges: list[tuple[str, str]] | None = None):
        if self.identifier != "" and processor_edges is not None:
            for i, edge in enumerate(processor_edges):
                if type(self.identifier) is dict:
                    parent_id = self.identifier.get(edge[0], "")
                    child_id = self.identifier.get(edge[1], "")
                    processor_edges[i] = (f"{edge[0]}{parent_id}", f"{edge[1]}{child_id}")
                else:
                    processor_edges[i] = (f"{edge[0]}{self.identifier}", f"{edge[1]}{self.identifier}")

        if processor_edges is None:
            if self.processors_edges is None:
                raise ValueError("No edges to connect processors!")

            processor_edges = self.processors_edges
        else:
            if len(self.processors_edges) != 0:
                self.processors_edges += processor_edges
            else:
                self.processors_edges = processor_edges

        for edge in processor_edges:
            parent, child = edge[0], edge[1]

            if parent not in self.graph:
                self.graph.add_node(parent)

            if child not in self.graph:
                self.graph.add_node(child)

            self.graph.add_edge(parent, child)

        if not nx.is_directed_acyclic_graph(self.graph):
            raise ValueError("Graph is not a DAG!")

        self.topo_sorted = list(nx.topological_sort(self.graph))

        self._node_predecessors = {name: list(self.graph.predecessors(name)) for name in self.topo_sorted}
        self._node_successors = {name: list(self.graph.successors(name)) for name in self.topo_sorted}
        self._dependencies = {name: set(self._node_successors[name]) for name in self.topo_sorted}

        return self

    def chain(self) -> ProcessorsGraph:
        processor_names = [name for name in self.processors.keys()]

        chain = []
        for i in range(1, len(processor_names)):
            chain.append((processor_names[i - 1], processor_names[i]))

        self.processors_edges += chain
        self.connect()

        return self

    def _validate_nodes(self, other_graph: ProcessorsGraph) -> bool:
        self_names = [name for name in self.processors.keys()]
        other_names = [name for name in other_graph.processors.keys()]

        for self_name in self_names:
            if self_name in other_names:
                raise ValueError(f"Found duplicate node {self_name} graphs. Node names must be unique!")

        return True

    def _extend_edges(self, other_graph: ProcessorsGraph, extend_node: str) -> list[tuple[str, str]]:
        self._validate_nodes(other_graph)

        self_edges, other_edges = self.processors_edges, other_graph.processors_edges

        extend_idx = []
        for i, edge in enumerate(self_edges):
            if edge[1] == extend_node:
                extend_idx.append(i)

        if len(extend_idx) != 1:
            raise ValueError(f"Found {len(extend_idx)} extendable nodes in graph. Must be exactly 1!")

        _extend_idx = extend_idx[0]

        new_edges = copy.deepcopy(self_edges)
        new_edges.insert(_extend_idx + 1, (self_edges[_extend_idx][1], other_edges[0][0]))
        new_edges[_extend_idx + 2 : _extend_idx + 2] = other_edges

        return new_edges

    def extend(self, other_graph, extend_node) -> ProcessorsGraph:
        new_edges = self._extend_edges(other_graph, extend_node)
        new_graph = self.__class__(prune_results=self.prune_results, prune_last_node=self.prune_last_node)

        new_graph.add(*self.processors.values(), *other_graph.processors.values())
        new_graph.connect(new_edges)

        return new_graph

    def _insert_edges(self, other_graph: ProcessorsGraph, insert_node: str) -> list[tuple[str, str]]:
        self._validate_nodes(other_graph)

        self_edges, other_edges = self.processors_edges, other_graph.processors_edges

        last_node = self.last_node

        if type(last_node) is str:
            last_node = [last_node]
        elif type(last_node) is list:
            last_node = last_node
        else:
            raise TypeError(f"Unsupported type {type(last_node)} for last_node.")

        if insert_node in last_node:
            raise ValueError(f"Cannot insert at node {insert_node}!")

        insert_idx = []
        for i, edge in enumerate(self_edges):
            if edge[0] == insert_node:
                insert_idx.append(i)

        if len(insert_idx) != 1:
            raise ValueError(f"Found {len(insert_idx)} insertable nodes in graph. Must be exactly 1!")

        _insert_idx = insert_idx[0]

        new_edges = copy.deepcopy(self_edges)

        left_edges, right_edges = self_edges[:_insert_idx], self_edges[_insert_idx + 1 :]

        new_node_in = (new_edges[_insert_idx][0], other_edges[0][0])
        new_node_out = (other_edges[-1][1], new_edges[_insert_idx][1])

        to_insert = [new_node_in] + other_edges + [new_node_out]

        new_edges = left_edges + to_insert + right_edges

        return new_edges

    def insert(self, other_graph: ProcessorsGraph, insert_node: str) -> ProcessorsGraph:
        new_edges = self._insert_edges(other_graph, insert_node)
        new_graph = self.__class__(prune_results=self.prune_results, prune_last_node=self.prune_last_node)

        new_graph.add(*self.processors.values(), *other_graph.processors.values())
        new_graph.connect(new_edges)

        return new_graph

    def split_graph_at_node(
        self,
        split_node: str,
        first_id: str = "",
        second_id: str = "",
        add_split_node_to_first: bool = False,
        add_split_node_to_second: bool = True,
    ) -> tuple[ProcessorsGraph, ProcessorsGraph]:
        if split_node not in self.graph.nodes:
            raise ValueError(f"Node {split_node} not found in graph!")

        first_graph = ProcessorsGraph(
            prune_results=self.prune_results,
            global_attributes=self.global_attributes,
            identifier=first_id,
            prune_last_node=self.prune_last_node,
        )
        second_graph = ProcessorsGraph(
            prune_results=self.prune_results,
            global_attributes=self.global_attributes,
            identifier=second_id,
            prune_last_node=self.prune_last_node,
        )

        first_nodes, second_nodes = set(), set()

        for node in nx.algorithms.dag.ancestors(self.graph, split_node):
            first_nodes.add(node)

        if add_split_node_to_first:
            first_nodes.add(split_node)

        for node in nx.algorithms.dag.descendants(self.graph, split_node):
            second_nodes.add(node)

        if add_split_node_to_second:
            second_nodes.add(split_node)

        for node in first_nodes:
            first_graph.add(self.processors[node])

        for node in second_nodes:
            second_graph.add(self.processors[node])

        first_edges, second_edges = [], []

        for edge in self.graph.edges:
            if edge[0] in first_nodes and edge[1] in first_nodes:
                first_edges.append(edge)
            if edge[0] in second_nodes and edge[1] in second_nodes:
                second_edges.append(edge)

        first_graph.connect(first_edges)
        second_graph.connect(second_edges)

        return first_graph, second_graph

    def _allow_copy_inputs(self, node: str, previous_nodes: set[str]) -> bool:
        for pred in self._node_predecessors[node]:
            for sibling in self._node_successors[pred]:
                if sibling != node and sibling not in previous_nodes:
                    return True
        return False

    def _build_pruning_cache(self) -> None:
        previous_nodes: set[str] = set()
        already_pruned: set[str] = set()

        for i, node in enumerate(self.topo_sorted):
            previous_nodes.add(node)

            nodes_to_prune: set[str] = set()

            for prune_node, prune_node_dependencies in self._dependencies.items():
                if len(prune_node_dependencies) == 0:
                    continue

                if prune_node_dependencies.issubset(previous_nodes):
                    nodes_to_prune.add(prune_node)

            self._pruning_cache[i] = nodes_to_prune - already_pruned
            already_pruned.update(nodes_to_prune)

        if self.prune_last_node:
            last_node = self.last_node
            if isinstance(last_node, str):
                self._last_nodes_cache = [last_node]
            elif isinstance(last_node, list):
                self._last_nodes_cache = last_node
            else:
                raise TypeError(f"Unsupported type {type(last_node)} for last_node.")

        self._has_pruning_cache = True

    def fit(self, *args: Any, **kwargs: Any) -> Self:
        if self.prune_results and not self._has_pruning_cache:
            self._build_pruning_cache()

        previous_nodes: set[str] = set()

        for i, node in enumerate(self.topo_sorted):
            processor = self.processors[node]

            processor.previous_processors = {name: self.processors[name] for name in previous_nodes}
            previous_nodes.add(processor.name)

            if self.global_attributes is not None:
                global_keys = set(self.global_attributes.keys())
                processor_keys = set(processor.__dict__.keys())

                global_processor_keys = global_keys.intersection(processor_keys)

                for key in global_processor_keys:
                    setattr(processor, key, self.global_attributes[key])
            else:
                global_processor_keys = set()

            if i == 0:
                processor._run(*args, copy_inputs=False, **kwargs)
            else:
                inputs = [self.processors[name]._results for name in self._node_predecessors[node]]
                input_args: list[Any] = list(filter(None, inputs))

                copy_inputs = self._allow_copy_inputs(node, previous_nodes)

                if len(input_args) == 0:
                    processor._run(*inputs, copy_inputs=copy_inputs)
                else:
                    input_kwargs = reduce(lambda a, b: {**a, **b}, input_args)
                    processor._run(copy_inputs=copy_inputs, **input_kwargs)

                if self.prune_results:
                    for prune_node in self._pruning_cache[i]:
                        if self.processors[prune_node]._results is not None:
                            self.processors[prune_node]._results = None

            for key in global_processor_keys:
                setattr(processor, key, None)

        if self.prune_results and self.prune_last_node:
            for node in self._last_nodes_cache:
                self.processors[node]._results = None

        return self

    def style_graph(self, fillcolor: str, identifier: str | None = None) -> ProcessorsGraph:
        for node in self.graph.nodes:
            if identifier is None or node.endswith(identifier):
                self.graph.nodes[node]["fillcolor"] = fillcolor
                self.graph.nodes[node]["style"] = "filled"

        return self

    @handle_plot_exception
    def draw(self, file_path: str, fontsize: float = 10.0, jupyter: bool = False, **kwargs: Any) -> str:
        return draw_graph(self.graph, self.processors, file_path, fontsize=fontsize, jupyter=jupyter, **kwargs)

    def set_worker_id(self, worker_id: int) -> None:
        self._worker_id = worker_id

    @property
    def worker_id(self) -> int:
        return self._worker_id

    def __str__(self) -> str:
        str_output = "Processors Graph:\n"

        for edge in self.graph.edges():
            str_output += f"{edge[0]} -> {edge[1]}\n"

        return str_output[:-1]

    def __repr__(self) -> str:
        return self.__str__()


@dataclass
class BranchInfo:
    name: str
    alias: str
    is_varied: bool
    variation: str | None = None
    added_by_processor: bool = False


class BranchCollection:
    def __init__(self) -> None:
        self._branches: dict[str, BranchInfo] = {}
        self._alias_to_branch: dict[str, str] = {}

        self._present_branch_groups: set[str] = set()
        self._varied_branch_groups: set[str] = set()

        self._added_by_processor: dict[str, bool] = {}

    def _invalidate_cache(self) -> None:
        for attr in [
            "branches",
            "aliases",
            "varied_branches",
            "varied_aliases",
            "branches_by_processor",
            "aliases_by_processor",
        ]:
            if attr in self.__dict__:
                self.__dict__.pop(attr)

    def _add_to_varied_branch_groups(self) -> None:
        self._present_branch_groups = set()
        self._varied_branch_groups = set()

        for branch, branch_info in self._branches.items():
            is_varied = branch_info.is_varied

            if branch.startswith("weight_mc"):
                self._present_branch_groups.add("gen")
                if is_varied:
                    self._varied_branch_groups.add("gen")
                continue

            for group in VALID_BRANCH_GROUPS:
                if branch.startswith(group):
                    self._present_branch_groups.add(group)
                    if is_varied:
                        self._varied_branch_groups.add(group)
                    break

    def add(
        self,
        branch: str | tuple[str, str],
        processor: Processor | None = None,
        is_varied: bool = False,
        overwrite: bool = False,
        added_by_processor: bool = False,
    ) -> BranchCollection:
        if type(branch) is str:
            branch_name, alias = branch, branch
        elif type(branch) is tuple:
            branch_name, alias = branch
        else:
            raise TypeError(f"Unsupported type {type(branch)} for branch!")

        if is_varied:
            if not branch_name.endswith("_NOSYS"):
                branch_name += "_NOSYS"
        else:
            if branch_name.endswith("_NOSYS"):
                raise ValueError(f"Nominal branch {branch_name} cannot end with _NOSYS!")

        if branch_name in self._branches and not overwrite:
            raise ValueError(f"Branch {branch_name} already exists in branches collection!")

        if alias in self._alias_to_branch and not overwrite:
            raise ValueError(f"Alias {alias} already exists in branches collection!")

        self._branches[branch_name] = BranchInfo(
            name=branch_name,
            alias=alias,
            is_varied=is_varied,
            added_by_processor=added_by_processor,
        )
        self._alias_to_branch[alias] = branch_name

        if processor is not None:
            setattr(processor, alias, branch_name)

        self._added_by_processor[branch_name] = added_by_processor
        self._added_by_processor[alias] = added_by_processor

        self._invalidate_cache()
        self._add_to_varied_branch_groups()

        return self

    def remove(self, branch: str, processor: Processor | None = None) -> BranchCollection:
        if branch in self._branches:
            alias = self._branches[branch].alias
            del self._branches[branch]
            del self._alias_to_branch[alias]

            self._added_by_processor.pop(branch, None)
            self._added_by_processor.pop(alias, None)

            if processor is not None and hasattr(processor, alias):
                delattr(processor, alias)
        elif branch in self._alias_to_branch:
            branch_name = self._alias_to_branch[branch]
            del self._branches[branch_name]
            del self._alias_to_branch[branch]

            self._added_by_processor.pop(branch_name, None)
            self._added_by_processor.pop(branch, None)

            if processor is not None and hasattr(processor, branch):
                delattr(processor, branch)
        else:
            raise ValueError(f"Branch {branch} not found in branches collection!")

        self._invalidate_cache()
        self._add_to_varied_branch_groups()

        return self

    def get(self, branch: str) -> BranchInfo:
        if branch in self._branches:
            return self._branches[branch]
        elif branch in self._alias_to_branch:
            branch_name = self._alias_to_branch[branch]
            return self._branches[branch_name]
        else:
            raise ValueError(f"Branch {branch} not found in branches collection!")

    def set_variation(self, branch: str, variation: str | None, processor: Processor | None = None) -> BranchCollection:
        branch_info = self.get(branch)

        branch_info.variation = variation

        if processor is not None:
            if variation is None:
                setattr(processor, branch_info.alias, branch_info.name)
            else:
                varied_branch_name = branch_info.name.replace("_NOSYS", f"_{variation}")
                setattr(processor, branch_info.alias, varied_branch_name)

        return self

    @cached_property
    def branches(self) -> list[str]:
        return [br_info.name for br_info in self._branches.values() if not br_info.is_varied]

    @cached_property
    def aliases(self) -> list[str]:
        return [br_info.alias for br_info in self._branches.values() if not br_info.is_varied]

    @cached_property
    def varied_branches(self) -> list[str]:
        return [br_info.name for br_info in self._branches.values() if br_info.is_varied]

    @cached_property
    def varied_aliases(self) -> list[str]:
        return [br_info.alias for br_info in self._branches.values() if br_info.is_varied]

    @cached_property
    def branches_by_processor(self) -> set[str]:
        return {br_info.name for br_info in self._branches.values() if br_info.added_by_processor}

    @cached_property
    def aliases_by_processor(self) -> set[str]:
        return {br_info.alias for br_info in self._branches.values() if br_info.added_by_processor}

    @property
    def branch_groups(self) -> set[str]:
        return self._present_branch_groups

    @property
    def varied_branch_groups(self) -> set[str]:
        return self._varied_branch_groups

    def is_added_by_processor(self, branch_or_alias: str) -> bool:
        return self._added_by_processor.get(branch_or_alias, False)


class Processor(ABC):
    def __init__(
        self,
        name: str,
        disable_variations: bool = False,
        input_files: list[str] | None = None,
        output_files_path: str | None = None,
    ) -> None:
        """Abstract base class for processing nodes in a ProcessorsGraph pipeline.

        Processor defines the interface and common functionality for all data processing
        nodes that can be composed into a directed acyclic graph (DAG). Each processor
        receives inputs from its predecessors, transforms the data via its `run` method,
        and passes results to successor nodes.

        All custom processors must inherit from this class and implement the abstract `run` method.

        Parameters
        ----------
        name : str
            Unique identifier for this processor instance. Must be unique within a
            ProcessorsGraph. The name is used for dependency resolution and result
            tracking throughout the pipeline.
        disable_variations : bool
            If True, this processor will not participate in systematic variation
            propagation, by default False. Useful for processors that should only run
            on nominal data or whose operations are variation-agnostic (e.g., metadata extraction).
        input_files : list[str] or None
            Optional list of input file paths that this processor requires. Can be used to specify
            resources needed during processing, by default None.
        output_files_path : str or None
            Optional directory path where this processor should save its outputs.

        Attributes
        ----------
        worker_id : int or None
            Worker process identifier assigned by the data loader in multiprocessing contexts.
        previous_processors : dict[str, Processor]
            Dictionary mapping names to processor instances that are direct predecessors
            in the DAG. Populated automatically by ProcessorsGraph during execution.
            Enables accessing upstream results and metadata.
        delta_time : float
            Execution time in seconds measured for all `run` invocation. Updated
            automatically by the `_run` wrapper method.
        delta_n : dict[str, dict[str, tuple[int, int]]]
            Dictionary recording the number of events before and after processing
            for this processor. Keys are groups and variation names (or "nominal"), and values
            are tuples of (start_n, end_n). Managed automatically by the count_events decorator
            or by vary decorator when variations are applied.
        branch_collection : BranchCollection
            Manager for data branches that this processor operates on or produces.
            Supports both nominal branches and systematic variations with
            _NOSYS suffix conventions.
        current_variation : str or None
            Name of the systematic variation currently being applied. None when processing
            nominal data.
        is_valid_group_variation : bool
            Flag indicating whether the current systematic variation is valid for
            this processor's branch groups. Used to skip invalid variations. Set in
            vary decorator. By default True.
        _results : dict[str, Any] or None
            Cached results produced by the most recent run invocation. Managed internally
            by ProcessorsGraph and may be pruned.

        Methods
        -------
        run(*args, **kwargs)
            Abstract method defining the processor's transformation logic. Must be
            implemented by subclasses. Should return a dictionary mapping argument
            names to output values for downstream processors.
        post_init()
            Optional initialization hook called after the processor's constructor.
            Useful for setting up derived attributes or complex state.
        attach_branch(branch, is_varied=False, overwrite=False, is_created=False)
            Register a data branch that this processor handles. Branches can be
            nominal or systematic variations.
        attach_branches(branches, is_varied=False)
            Convenience method to register multiple branches at once.
        set_current_variation(variation)
            Set the active systematic variation name for this processor.
        vary_branch(branch, variation)
            Apply a specific variation to a registered branch, transforming its
            name from the _NOSYS format to the variation-specific form.
        reset_branch_variation(branch)
            Reset a branch back to its nominal _NOSYS form.
        is_processor_branch(branch)
            Check whether a branch was added by this processor.
        remove_branch(branch)
            Unregister a branch from this processor's collection.
        is_branch_varied(branch)
            Check whether a branch is registered as a systematic variation.
        set_event_count(start_n, end_n)
            Record the number of events before and after this processor's execution.
            Use count_events decorator to automatically set these values.
        finalize()
            Finalization hook called after after the full graph execution complete.
            Can be overridden to implement custom cleanup or result persistence logic.
        save(*args, **kwargs)
            Optional hook for persisting processor results. Called after the full
            graph execution completes. Override to implement custom save logic.
            Can be overridden by subclasses to implement custom save logic.

        Properties
        ----------
        branches : list[str]
            Names of all nominal (non-varied) branches managed by this processor.
        aliases : list[str]
            Aliases of all nominal branches for convenient attribute access.
        varied_branches : list[str]
            Names of all systematic variation branches (ending in _NOSYS or specific
            variation suffixes).
        varied_aliases : list[str]
            Aliases of all systematic variation branches.
        has_event_count : bool
            True if both start_n and end_n have been set for this processor.
        reports : dict[str, Any] or None
            Metadata reports from upstream "input" processor.
        is_data : bool
            True if processing data (as opposed to MC). Retrieved from upstream "input" processor.
        sample_info : dict[str, Any] or None
            Sample metadata from upstream "sampleInfo" processor.
        variation_map : Any or None
            Mapping of systematic variations from upstream "variations" processor.
        nominal_only : bool
            True if only nominal (non-varied) processing should occur. Retrieved
            from upstream "variations" processor, defaults to True if unavailable.
        varied_branch_groups : set[str]
            Set of branch group prefixes (e.g., "el", "mu", "jet") that have registered systematic
            variations in this processor's branch collection.
        branches_by_processor : set[str]
            Set of branch names that were added by this processor.
        aliases_by_processor : set[str]
            Set of branch aliases that were added by this processor.

        Notes
        -----
        - The `run` method receives outputs from predecessor nodes as keyword arguments
        - Input arguments are automatically deep-copied if necessary to prevent side effects
        - Processors are executed sequentially in topological order by ProcessorsGraph
        - The _results attribute is managed internally and may be pruned to save memory
        - Branch names ending in _NOSYS are templates for systematic variations

        """
        self.name = name
        self.disable_variations = disable_variations
        self.input_files = input_files if input_files is not None else []
        self.output_files_path = output_files_path if output_files_path is not None else ""

        self.worker_id: int | None = None
        self.previous_processors: dict[str, Processor] = {}

        self.delta_time: float = 0.0
        self.delta_n: dict[str, dict[str, tuple[int, int]]] = {}

        self._results: dict[str, Any] | None = None

        self.branch_collection = BranchCollection()
        self.current_variation: str | None = None

        self._graph_identifier: str = ""
        self._skip_auto_count = False

    def __init_subclass__(cls, *args: Any, **kwargs: Any) -> None:
        super().__init_subclass__(*args, **kwargs)

        if hasattr(cls, "run") and not getattr(cls, "_skip_auto_count", False):
            if not hasattr(cls.run, "_applied_vary_decorator"):
                setattr(cls, "run", count_events(cls.run))

    def _run(self, *args: Any, copy_inputs: bool = True, **kwargs: Any) -> Processor:
        """Internal execution wrapper for the processor.

        This method wraps the user-implemented `run` method to provide common
        execution behavior, including optional deep-copying of inputs, execution
        time measurement, and result caching. It is invoked by ProcessorsGraph
        during graph execution and should not be called directly by users.

        Parameters
        ----------
        *args : Any
            Positional inputs passed to the processor. Typically outputs from
            predecessor processors.
        copy_inputs : bool, optional
            If True (default), all positional and keyword inputs are deep-copied
            before being passed to `run` to prevent unintended side effects
            between processors. Automatically determined by ProcessorsGraph based on
            graph structure to ensure data integrity.
        **kwargs : Any
            Keyword inputs passed to the processor, usually keyed by upstream
            processor names.

        Returns
        -------
        Processor
            The processor instance itself, allowing for method chaining.

        Side Effects
        ------------
        - Stores the dictionary returned by `run` in the internal `_results` attribute
        - Updates `delta_time` with the wall-clock execution time in seconds

        Notes
        -----
        - Subclasses should implement `run`, NOT override `_run`
        - Input deep-copying may have performance implications for large objects

        """
        start_time = time.time()

        if copy_inputs:
            args, kwargs = copy.deepcopy(args), copy.deepcopy(kwargs)

        self._results = self.run(*args, **kwargs)
        self.delta_time += time.time() - start_time

        return self

    @abstractmethod
    def run(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        """Needs to be implemented by every processor object. Must return a dictionary with keys for argument names!"""
        pass

    def post_init(self) -> None:
        pass

    def set_input_files_path(self, base_file_path: str) -> None:
        self.input_files = [os.path.join(base_file_path, os.path.basename(f)) for f in self.input_files]

    def set_output_files_path(self, output_files_path: str) -> None:
        self.output_files_path = output_files_path

    def attach_branch(
        self, branch: tuple[str, str] | str, is_varied: bool = False, overwrite: bool = False, is_created: bool = False
    ) -> None:
        self.branch_collection.add(
            branch, processor=self, is_varied=is_varied, overwrite=overwrite, added_by_processor=is_created
        )

    def attach_branches(
        self, branches: Sequence[tuple[str, str] | str], is_varied: bool = False, overwrite: bool = False
    ) -> None:
        for branch in branches:
            self.attach_branch(branch, is_varied=is_varied, overwrite=overwrite)

    def set_current_variation(self, variation: str) -> None:
        self.current_variation = variation

    def vary_branch(self, branch: str, variation: str) -> None:
        self.branch_collection.set_variation(branch, variation, processor=self)

    def reset_branch_variation(self, branch: str) -> None:
        self.branch_collection.set_variation(branch, None, processor=self)

    def is_processor_branch(self, branch: str) -> bool:
        return self.branch_collection.is_added_by_processor(branch)

    def remove_branch(self, branch: str) -> None:
        self.branch_collection.remove(branch, processor=self)

    def is_branch_varied(self, branch: str) -> bool:
        branch_info = self.branch_collection.get(branch)
        return branch_info.is_varied

    def set_event_count(self, start_n: int, end_n: int, group: str = "event") -> None:
        variation = "nominal" if self.current_variation is None else self.current_variation

        if group not in self.delta_n:
            self.delta_n[group] = {}

        if variation not in self.delta_n[group]:
            self.delta_n[group][variation] = (start_n, end_n)
        else:
            prev_start_n, prev_end_n = self.delta_n[group][variation]
            self.delta_n[group][variation] = (prev_start_n + start_n, prev_end_n + end_n)

    def finalize(self) -> None:
        """Finalize the processor, executed after fitting the ProcessorsGraph."""
        self.delta_time, self.delta_n = 0.0, {}

    def save(self, save_path: str, save_name: str) -> None:
        """Save results of the processor, executed after fitting the ProcessorsGraph."""
        pass

    @property
    def branches(self) -> list[str]:
        return self.branch_collection.branches

    @property
    def aliases(self) -> list[str]:
        return self.branch_collection.aliases

    @property
    def varied_branches(self) -> list[str]:
        return self.branch_collection.varied_branches

    @property
    def varied_aliases(self) -> list[str]:
        return self.branch_collection.varied_aliases

    @property
    def varied_branch_groups(self) -> set[str]:
        return self.branch_collection.varied_branch_groups

    @property
    def branches_by_processor(self) -> set[str]:
        return self.branch_collection.branches_by_processor

    @property
    def aliases_by_processor(self) -> set[str]:
        return self.branch_collection.aliases_by_processor

    @property
    def has_event_count(self) -> bool:
        return len(self.delta_n) > 0

    @property
    def reports(self) -> dict[str, Any]:
        if hasattr(self, "_reports_override"):
            return self._reports_override

        prev_proc = self.previous_processors

        if "input" in prev_proc:
            return prev_proc["input"]._reports  # type: ignore[attr-defined]
        else:
            return {}

    @reports.setter
    def reports(self, value: dict[str, Any]) -> None:
        self._reports_override = value

    @property
    def is_data(self) -> bool:
        prev_proc = self.previous_processors

        if "input" in prev_proc:
            return prev_proc["input"]._is_data  # type: ignore[attr-defined]
        else:
            return False

    @property
    def sample_info(self) -> dict[str, Any]:
        if hasattr(self, "_sample_info_override"):
            return self._sample_info_override

        prev_proc = self.previous_processors

        if "sampleInfo" in prev_proc:
            return prev_proc["sampleInfo"]._sample_info  # type: ignore[attr-defined]
        else:
            return {}

    @sample_info.setter
    def sample_info(self, value: dict[str, Any]) -> None:
        self._sample_info_override = value

    @property
    def variation_map(self) -> Any | None:
        prev_proc = self.previous_processors

        if "variations" in prev_proc:
            return prev_proc["variations"]._variation_map  # type: ignore[attr-defined]
        else:
            return None

    @property
    def nominal_only(self) -> bool:
        prev_proc = self.previous_processors

        if "variations" in prev_proc:
            return prev_proc["variations"]._nominal_only  # type: ignore[attr-defined]
        else:
            return True


def count_events(func: Callable | None = None, *, disable: bool = False) -> Callable:
    """Decorator to automatically count events before and after processor run.

    Wraps a Processor's run method to track the number of events entering
    and exiting. Calls set_event_count with start_n and end_n using len().

    Warning
    -------
    Should NOT be used by a user. It is automatically applied to all Processor run methods
    unless the vary decorator is applied. Disabling can be done by setting the environment
    variable COLUMNAR_DISABLE_CUT_FLOW=1.

    Note
    ----
    Not compatible with the vary decorator. The vary decorator already handles
    event counting for each variation.

    """

    def decorator(func: Callable) -> Callable:
        if disable or os.environ.get("COLUMNAR_DISABLE_CUT_FLOW", "0") == "1":
            return func

        @wraps(func)
        def wrapper(obj: Processor, *args: Any, **kwargs: Any) -> dict[str, Any]:
            try:
                if args:
                    input_arrays = args[0]
                else:
                    input_arrays = kwargs["arrays"]

                start_event_n = len(input_arrays)
                groups = getattr(input_arrays, "groups", None)

                if groups is not None:
                    start_groups_n = input_arrays.count_group_particles()

            except Exception:
                return func(obj, *args, **kwargs)

            result = func(obj, *args, **kwargs)

            if "arrays" not in result or len(result) != 1:
                return result

            if result["arrays"] is None:
                return result

            obj.set_event_count(start_event_n, len(result["arrays"]), group="event")

            if groups is not None and hasattr(result["arrays"], "count_group_particles"):
                end_groups_n = result["arrays"].count_group_particles()
                for group in groups:
                    if group not in start_groups_n or group not in end_groups_n:
                        continue

                    if group == "other":
                        continue

                    obj.set_event_count(start_groups_n[group], end_groups_n[group], group=group)

            return result

        return wrapper

    if func is not None and callable(func):
        return decorator(func)

    return decorator


class CheckpointProcessor(Processor):
    def __init__(self, name: str, save_arrays: bool = False) -> None:
        """Checkpoint processor that acts as input/output node for the ProcessorsGraph. Also used to save arrays at nodes.

        Parameters
        ----------
        name : str
            Name of the processor.
        save_arrays : bool
            Flag to save arrays at this node.

        Other parameters
        ----------------
        reports : dict
            Reports returned by the iterator.
        n_events : int
            Number of events in the arrays.
        arrays : ak.Array or np.ndarray
            Arrays at this node.

        """
        super().__init__(name, disable_variations=True)
        self.save_arrays = save_arrays

        self.arrays: ak.Array | np.ndarray | None = None
        self._reports: dict[str, Any] | None = None
        self._is_data: bool = False
        self.n_events: int | None = None

    def run(
        self, arrays: ak.Array | np.ndarray, reports: dict[str, Any] | None = None
    ) -> dict[str, ak.Array | np.ndarray]:
        self._reports = reports

        if self._reports is not None:
            self._is_data = self._reports.get("is_data", False)

        self.n_events = len(arrays)

        if self.save_arrays:
            self.arrays = arrays

        return {"arrays": arrays}

    @property
    def is_data(self) -> bool:
        return self._is_data


class PostprocessorsGraph(ProcessorsGraph):
    def __init__(self) -> None:
        """Postprocessors graph to process the results of the processors.

        Note
        ----
        Takes the fitted processors dictionary returned by the ProcessorsGraph and processes it. The key difference is
        that the PostprocessorsGraph does not copy its processors allowing for the accumulation of results in each
        postprocessor. This is useful for plotting and saving results. Note that this does not allow for
        multiprocessing.

        """
        super().__init__()

    def fit(self, input_processors: dict[str, Processor], *args: Any, **kwargs: Any) -> Self:
        return super().fit(input_processors, *args, **kwargs)


class Postprocessor(Processor):
    _skip_auto_count = True

    def __init__(self, name: str, save_path: str | None = None) -> None:
        """Postprocessor base class. All postprocessors should inherit from this class.

        Parameters
        ----------
        name : str
            Name of the postprocessor.
        save_path : str, optional
            Path with file name to save the postprocessor results in the save method, by default None.
        """
        super().__init__(name, disable_variations=True)

        if save_path is not None:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)

        self.save_path = save_path


class CheckpointPostprocessor(Postprocessor):
    def __init__(self, name: str, save_input_processors: bool = False) -> None:
        """Checkpoint postprocessor."""
        super().__init__(name)
        self.save_input_processors = save_input_processors

        self.input_processors: list[dict[str, Processor]] = []
        self._is_data: bool = False

    def run(self, processors: dict[str, Processor], is_data: bool = False) -> dict[str, dict[str, Processor]]:
        if self.save_input_processors:
            self.input_processors.append(processors)

        self._is_data = is_data

        return {"processors": processors}

    @property
    def is_data(self) -> bool:
        return self._is_data
