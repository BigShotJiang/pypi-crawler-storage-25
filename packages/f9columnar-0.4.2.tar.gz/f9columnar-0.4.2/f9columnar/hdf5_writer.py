import json
import logging
import multiprocessing
import os
from collections import deque
from typing import Any

import awkward as ak
import h5py
import numpy as np

from f9columnar.processors import Processor
from f9columnar.utils.ak_helpers import ak_pack
from f9columnar.utils.helpers import INVALID_CATEG_TOKEN


def sanitize_invalid(array: np.ndarray, target_dtype: np.dtype | None) -> np.ndarray:
    if np.issubdtype(array.dtype, np.floating):
        invalid_mask = ~np.isfinite(array)
        if invalid_mask.any():
            if target_dtype is not None and np.issubdtype(target_dtype, np.integer):
                array = np.where(invalid_mask, INVALID_CATEG_TOKEN, array)
            else:
                array = np.where(invalid_mask, np.nan, array)

    return array


class ArraysHdf5Writer:
    def __init__(self, file_path: str) -> None:
        """HDF5 data writer utility class for writting awkward arrays to HDF5 file.

        Parameters
        ----------
        file_path : str
            Path to the created HDF5 file.

        References
        ----------
        .. [1] https://docs.h5py.org/en/stable/high/group.html#h5py.Group.create_dataset
        .. [2] https://docs.h5py.org/en/stable/high/dataset.html
        .. [3] https://pythonforthelab.com/blog/how-to-use-hdf5-files-in-python/

        """
        super().__init__()
        self.file_path = file_path

        self._write_handle: h5py.File | None = None

    def create_datasets(
        self,
        dataset_names: str | list[str],
        mode: str = "w",
        shape: tuple | None = None,
        chunks: bool | tuple | None = None,
        maxshape: tuple | None = None,
        dtype: str | np.dtype = "float32",
        compression: str | None = "lzf",
        compression_opts: int | None = None,
    ) -> None:
        if maxshape is not None and shape is None:
            raise RuntimeError("Shape must be provided if maxshape is provided!")

        if type(dataset_names) is str:
            dataset_names = [dataset_names]

        if chunks in {None, False} and (maxshape is not None or compression is not None):
            chunks = True

        with h5py.File(self.file_path, mode) as f:
            for dataset_name in dataset_names:
                dataset_name_split = dataset_name.split("/")

                f_obj = f
                for i, group in enumerate(dataset_name_split):
                    if i == len(dataset_name_split) - 1:
                        f_obj.create_dataset(
                            group,
                            shape=shape,
                            chunks=chunks,
                            maxshape=maxshape,
                            dtype=dtype,
                            compression=compression,
                            compression_opts=compression_opts,
                        )
                    elif i == 0:
                        if group not in f_obj:
                            g = f.create_group(group)
                            f_obj = g
                        else:
                            f_obj = f_obj[group]
                    else:
                        g = g.create_group(group)
                        f_obj = g

    def add_data(
        self,
        data_dct: dict[str, np.ndarray],
        dataset_name: str,
        idx: tuple[int, int],
        resize: tuple | None = None,
    ) -> None:
        with h5py.File(self.file_path, "a") as f:
            dataset = f[dataset_name]

            if resize:
                dataset.resize(resize)

            start, end = idx
            for column_name, column_data in data_dct.items():
                dataset[column_name, start:end] = column_data

    def add_array(
        self,
        data: np.ndarray,
        dataset_name: str,
        idx: tuple[int, int],
        resize: tuple | None = None,
    ) -> None:
        with h5py.File(self.file_path, "a") as f:
            dataset = f[dataset_name]

            if resize:
                dataset.resize(resize)

            start, end = idx
            dataset[start:end] = data

    def add_metadata(self, metadata_dct: dict[str, Any], group_name: str | None = None) -> None:
        with h5py.File(self.file_path, "a") as f:
            if group_name is not None:
                group = f[group_name]
            else:
                group = f

            group.create_dataset("metadata", data=json.dumps(metadata_dct))

    def get_metadata(self, group_name: str | None = None) -> dict[str, Any]:
        if group_name is None:
            group_name = "metadata"
        else:
            group_name = f"{group_name}/metadata"

        with h5py.File(self.file_path, "r") as f:
            metadata = json.loads(f[group_name][()])

        return metadata

    def get_keys(self) -> list[str]:
        with h5py.File(self.file_path, "r") as f:
            keys = list(f.keys())

        return keys


class Hdf5WriterProcessor(Processor):
    _skip_auto_count = True

    def __init__(
        self,
        output_files_path: str,
        name: str = "hdf5WriterProcessor",
        flat_column_names: list[str] | None = None,
        jagged_column_names: dict[str, list[str]] | None = None,
        default_chunk_shape: int = 1024,
        custom_chunk_shape_dct: dict[str, int] | None = None,
        max_lengths: dict[str, int] | int = 10,
        pad_values: dict[str, float] | float | None = 0.0,
        n_piles: int | None = None,
        pile_assignment: str = "random",
        enforce_dtypes: dict[str, str] | None = None,
        full_metadata: bool = True,
        max_workers: int | None = None,
        append: bool = False,
        varlen: bool = False,
        **hdf5_kwargs,
    ) -> None:
        """HDF5 writer for physics objects. It supports both flat and jagged arrays.

        Parameters
        ----------
        output_files_path : str
            Path to the output HDF5 files.
        postprocessor_name : str, optional
            Name of the postprocessor to use in the graph. Default is "hdf5WriterProcessor".
        flat_column_names : list[str] | None, optional
            List of flat column names to be saved in the HDF5 file. If None, jagged_column_names must be provided.
        jagged_column_names : dict[str, list[str]] | None, optional
            Dictionary of jagged column names to be saved in the HDF5 file. The keys are the names of the physics
            objects (e.g. electrons, jets, etc.), and the values are lists of column names for each physics object.
            If None, flat_column_names must be provided.
        chunk_shape : int, optional
            Number of events to be saved in each chunk. This is used to split the data into chunks for writing.
        custom_chunk_shape_dct : dict[str, int] | None, optional
            Dictionary of custom chunk shapes for each physics process. The keys are the names of the physics
            processes, and the values are the chunk shapes. If None, default_chunk_shape will be used for all processes.
        max_lengths : dict[str, int] | int, optional
            Maximum length of the jagged arrays. If an int is provided, it will be used for all jagged arrays.
            If a dictionary is provided, the keys must match the keys in jagged_column_names and the values are the
            maximum lengths for each jagged array.
        pad_values : dict[str, float] | float | None, optional
            Values to pad the jagged arrays with. If a float is provided, it will be used for all jagged arrays.
            If a dictionary is provided, the keys must match the keys in jagged_column_names and the values are the
            pad values for each jagged array. If None, no padding will be applied and the resulting arrays will be
            numpy masked arrays.
        n_piles : int | None, optional
            Number of piles to split the data into. If None, the data will be saved in a single dataset.
        pile_assignment : str, optional
            Method of assigning data to piles. Can be 'deque' or 'random'. If 'deque', the data will be assigned to
            piles in a double-ended queue fashion. If 'random', the data will be assigned to piles randomly.
        enforce_dtypes : dict[str, str] | None, optional
            Dictionary of dtypes to enforce for each column. The keys are the column names and the values are the dtypes.
            If None, the dtypes will be inferred from the arrays.
        full_metadata : bool, optional
            If True, full metadata will be saved in the HDF5 file. If False, reduced metadata will be saved.
        max_workers : int, optional
            Number of workers to use for writing the data. Default is 1.
        append : bool, optional
            If True, data will be appended to existing datasets if the file already exists. If False (default),
            existing datasets will be overwritten.
        varlen : bool, optional
            If True, jagged arrays will be saved as packed arrays with an additional dataset for the sequence lengths.
            If False (default), jagged arrays will be saved as padded arrays with a fixed maximum length.
        **hdf5_kwargs : Any
            Additional keyword arguments to be passed to the h5py.File.create_dataset method.
        """
        super().__init__(name=name)
        if flat_column_names is not None and len(flat_column_names) == 0:
            logging.warning("flat_column_names is an empty list, no flat arrays will be saved.")
            flat_column_names = None

        if jagged_column_names is not None and len(jagged_column_names) == 0:
            logging.warning("jagged_column_names is an empty dictionary, no jagged arrays will be saved.")
            jagged_column_names = None

        if flat_column_names is None and jagged_column_names is None:
            raise ValueError("At least one of flat_column_names or jagged_column_names must be provided.")

        if enforce_dtypes is not None:
            logging.info(f"Enforcing types: {enforce_dtypes}.")

        if full_metadata:
            logging.info("Full metadata enabled.")
        else:
            logging.info("Reduced metadata enabled.")

        if ".hdf5" in output_files_path.lower():
            raise ValueError("output_files_path should be a directory, not a file path!")

        os.makedirs(output_files_path, exist_ok=True)
        self.output_files_path = output_files_path

        self.chunk_shape = default_chunk_shape
        self.custom_chunk_shape_dct = custom_chunk_shape_dct

        if max_workers == 0 or max_workers is None:
            self.max_workers = 1
        elif max_workers == -1:
            self.max_workers = multiprocessing.cpu_count()
        else:
            self.max_workers = max_workers

        if n_piles is None:
            self.n_piles = self.max_workers
        else:
            self.n_piles = n_piles

        self.pile_assignment = pile_assignment
        self.enforce_dtypes = enforce_dtypes
        self.full_metadata = full_metadata
        self.append = append
        self.varlen = varlen

        self.hdf5_kwargs = hdf5_kwargs

        self.object_info_dct: dict[str, dict[str, int]] = {}
        self.object_piles_info_dct: dict[str, dict[int, dict[str, int]]] = {}

        self.object_column_names_dct: dict[str, list[str]] = {}

        self.pad_values: dict[str, float] | None = None
        self.max_lengths: dict[str, int] = {}

        self.writers: list[ArraysHdf5Writer] = []

        if flat_column_names is not None:
            self.write_flat = True
            self.object_column_names_dct["events"] = flat_column_names
        else:
            self.write_flat = False

        if jagged_column_names is not None:
            self.write_jagged = True

            if not varlen:
                self._set_max_lengths(jagged_column_names, max_lengths)
                self._set_pad_values(jagged_column_names, pad_values)

            for physics_object_name, physics_object_column_names in jagged_column_names.items():
                self.object_column_names_dct[physics_object_name] = physics_object_column_names
        else:
            self.write_jagged = False

        self.flat_column_names, self.jagged_column_names = flat_column_names, jagged_column_names

        self._pile_deque: deque[int] | None = None

        self._has_piles_lst = False
        self._created_datasets = False
        self._current_pile_idx = 0

        self._worker_id: int
        self._current_dataset_name: str
        self._piles_lst: list[int]

    def _setup_piles_lst(self, worker_id: int) -> None:
        if self._has_piles_lst:
            return None

        piles_lst_split = np.array_split([i for i in range(self.n_piles)], self.max_workers)
        self._piles_lst = [int(i) for i in piles_lst_split[worker_id]]

        if self.pile_assignment == "deque":
            self._pile_deque = deque(range(len(self._piles_lst)))

        self._worker_id = worker_id
        self._has_piles_lst = True

    def _set_max_lengths(self, jagged_column_names: dict[str, list[str]], max_lengths: dict[str, int] | int) -> None:
        if type(max_lengths) is int:
            self.max_lengths = {column_name: max_lengths for column_name in jagged_column_names.keys()}
        elif type(max_lengths) is dict:
            self.max_lengths = max_lengths
        else:
            raise TypeError("max_lengths must be an int or a dictionary with column names as keys.")

    def _set_pad_values(
        self, jagged_column_names: dict[str, list[str]], pad_values: dict[str, float] | float | None
    ) -> None:
        if pad_values is None:
            self.pad_values = None
        elif type(pad_values) is float:
            self.pad_values = {column_name: pad_values for column_name in jagged_column_names.keys()}
        elif type(pad_values) is dict:
            self.pad_values = pad_values
        else:
            raise TypeError("pad_values must be a float, None or a dictionary with column names as keys.")

    def _make_metadata(self, events_metadata: dict[str, Any], jagged_metadata: dict[str, Any]) -> dict[str, Any]:
        metadata = events_metadata | jagged_metadata

        if not self.full_metadata:
            metadata = {}

        metadata["pad_values"] = self.pad_values
        metadata["varlen"] = self.varlen

        return metadata

    @staticmethod
    def _get_primitive_from_type(type_obj: Any) -> Any:
        """Traverse the awkward type hierarchy to find the innermost primitive dtype.

        Handles both flat (N * dtype) and jagged (N * var * dtype) layouts.
        """
        content = type_obj.content
        while not hasattr(content, "primitive"):
            content = content.content
        return content.primitive

    def _get_flat_dtypes(self, arrays: ak.Array) -> np.dtype:
        dtypes_dct: dict[str, Any] = {"names": [], "formats": []}

        if self.flat_column_names is None:
            raise RuntimeError("Flat column names must be provided for flat arrays!")

        for column_name in self.flat_column_names:
            if column_name not in arrays.fields:
                raise RuntimeError(f"Column {column_name} not found in arrays!")

            dtypes_dct["names"].append(column_name)

            if self.enforce_dtypes is not None and column_name in self.enforce_dtypes:
                dtypes_dct["formats"].append(self.enforce_dtypes[column_name])
            else:
                dtypes_dct["formats"].append(self._get_primitive_from_type(ak.type(arrays[column_name])))

        return np.dtype(dtypes_dct)  # type: ignore

    def _get_jagged_dtypes(self, arrays: ak.Array) -> dict[str, np.dtype]:
        dtypes_dct: dict[str, np.dtype] = {}

        if self.jagged_column_names is None:
            raise RuntimeError("Jagged column names must be provided for jagged arrays!")

        for physics_object_name, physics_object_column_names in self.jagged_column_names.items():
            dct: dict[str, list[str]] = {"names": [], "formats": []}

            for column_name in physics_object_column_names:
                if column_name not in arrays.fields:
                    raise RuntimeError(f"Column {column_name} not found in arrays!")

                dct["names"].append(column_name)

                if self.enforce_dtypes is not None and column_name in self.enforce_dtypes:
                    dct["formats"].append(self.enforce_dtypes[column_name])
                else:
                    dct["formats"].append(self._get_primitive_from_type(ak.type(arrays[column_name])))

            dtypes_dct[physics_object_name] = np.dtype(dct)  # type: ignore

        return dtypes_dct

    def _create_events_datasets(self, dtype: np.dtype) -> dict[str, Any]:
        if self.flat_column_names is None:
            raise RuntimeError("Flat column names must be provided for event datasets!")

        writers: list[ArraysHdf5Writer] = []
        metadata: dict[str, Any] = {}

        for i in self._piles_lst:
            file_name = os.path.join(self.output_files_path, f"p{i}.hdf5")
            writers.append(ArraysHdf5Writer(file_name))

        self.object_piles_info_dct["events"] = {}

        for p, w in zip(self._piles_lst, writers):
            if self.append and os.path.isfile(w.file_path):
                with h5py.File(w.file_path, "r") as f:
                    existing_size = f["events"].shape[0]

                self.object_piles_info_dct["events"][p] = {
                    "current_idx": existing_size,
                    "current_shape": existing_size,
                }
            else:
                w.create_datasets(
                    dataset_names=["events"],
                    mode="w",
                    shape=(0,),
                    chunks=(self.chunk_shape,),
                    maxshape=(None,),
                    dtype=dtype,
                    **self.hdf5_kwargs,
                )
                self.object_piles_info_dct["events"][p] = {
                    "current_idx": 0,
                    "current_shape": 0,
                }
                self._writers_with_new_datasets.add(w.file_path)

        metadata["events_columns"] = self.flat_column_names

        self.object_column_names_dct["events"] = self.flat_column_names

        self.writers = writers

        return metadata

    def _create_jagged_datasets(self, dtype: dict[str, np.dtype]) -> dict[str, Any]:
        if self.jagged_column_names is None:
            raise RuntimeError("Jagged column names must be provided for jagged datasets!")

        metadata: dict[str, Any] = {}

        if len(self.writers) == 0:
            has_writers = False
            writers: list[ArraysHdf5Writer] = []
        else:
            has_writers = True
            writers = self.writers

        for i, (physics_object_name, physics_object_column_names) in enumerate(self.jagged_column_names.items()):
            if i == 0 and not has_writers:
                for p in self._piles_lst:
                    file_name = os.path.join(self.output_files_path, f"p{p}.hdf5")
                    writers.append(ArraysHdf5Writer(file_name))

            physics_object_dtype = dtype[physics_object_name]

            self.object_piles_info_dct[physics_object_name] = {}

            culens_name = f"{physics_object_name}_culens"

            for p, w in zip(self._piles_lst, writers):
                file_exists = self.append and os.path.isfile(w.file_path)
                if file_exists:
                    with h5py.File(w.file_path, "r") as f:
                        dataset_exists = physics_object_name in f
                else:
                    dataset_exists = False

                if dataset_exists:
                    with h5py.File(w.file_path, "r") as f:
                        existing_size = f[physics_object_name].shape[0]

                    pile_info: dict[str, int] = {
                        "current_idx": existing_size,
                        "current_shape": existing_size,
                    }

                    if self.varlen:
                        with h5py.File(w.file_path, "r") as f:
                            existing_culens_size = f[culens_name].shape[0]
                        pile_info["packed_current_idx"] = existing_size
                        pile_info["packed_current_shape"] = existing_size
                        pile_info["culens_current_idx"] = existing_culens_size
                        pile_info["culens_current_shape"] = existing_culens_size

                    self.object_piles_info_dct[physics_object_name][p] = pile_info
                else:
                    mode = "a" if has_writers or i != 0 else "w"

                    if self.varlen:
                        w.create_datasets(
                            dataset_names=[physics_object_name],
                            mode=mode,
                            shape=(0,),
                            chunks=(self.chunk_shape,),
                            maxshape=(None,),
                            dtype=physics_object_dtype,
                            **self.hdf5_kwargs,
                        )
                        w.create_datasets(
                            dataset_names=[culens_name],
                            mode="a",
                            shape=(1,),
                            chunks=(self.chunk_shape,),
                            maxshape=(None,),
                            dtype="int64",
                            **self.hdf5_kwargs,
                        )
                        # Write the leading zero of the cumulative index
                        w.add_array(np.zeros(1, dtype=np.int64), culens_name, idx=(0, 1))
                        self.object_piles_info_dct[physics_object_name][p] = {
                            "current_idx": 0,
                            "current_shape": 0,
                            "packed_current_idx": 0,
                            "packed_current_shape": 0,
                            "culens_current_idx": 1,
                            "culens_current_shape": 1,
                        }
                    else:
                        max_length = self.max_lengths[physics_object_name]
                        w.create_datasets(
                            dataset_names=[physics_object_name],
                            mode=mode,
                            shape=(0, max_length),
                            chunks=(self.chunk_shape, max_length),
                            maxshape=(None, max_length),
                            dtype=physics_object_dtype,
                            **self.hdf5_kwargs,
                        )
                        self.object_piles_info_dct[physics_object_name][p] = {
                            "current_idx": 0,
                            "current_shape": 0,
                        }

                    self._writers_with_new_datasets.add(w.file_path)

            metadata[f"{physics_object_name}_columns"] = physics_object_column_names

            self.object_column_names_dct[physics_object_name] = physics_object_column_names

        if not has_writers:
            self.writers = writers

        return metadata

    def _get_flat_arrays(self, arrays: ak.Array, column_names: list[str]) -> list[np.ndarray]:
        save_arrays = []

        for column_name in column_names:
            if column_name not in arrays.fields:
                raise RuntimeError(f"Column {column_name} not found in arrays!")

            column = ak.to_numpy(arrays[column_name])

            target_dtype = None
            if self.enforce_dtypes is not None and column_name in self.enforce_dtypes:
                target_dtype = np.dtype(self.enforce_dtypes[column_name])

            column = sanitize_invalid(column, target_dtype)

            if target_dtype is not None:
                column = column.astype(target_dtype)

            save_arrays.append(column)

        return save_arrays

    def _get_jagged_arrays(self, arrays: ak.Array, column_names: list[str]) -> list[np.ndarray]:
        save_arrays = []

        for column_name in column_names:
            if column_name not in arrays.fields:
                raise RuntimeError(f"Column {column_name} not found in arrays!")

            column_matrix = arrays[column_name]
            elements_type = str(ak.type(column_matrix)).split("*")[-1].strip()
            column_matrix = ak.pad_none(column_matrix, self.max_lengths[self._current_dataset_name], clip=True)

            if self.pad_values is not None:
                pad_value = self.pad_values[self._current_dataset_name]
                column_matrix = ak.fill_none(column_matrix, getattr(np, elements_type)(pad_value))

            column_matrix = ak.to_numpy(column_matrix)

            target_dtype = None
            if self.enforce_dtypes is not None and column_name in self.enforce_dtypes:
                target_dtype = np.dtype(self.enforce_dtypes[column_name])

            column_matrix = sanitize_invalid(column_matrix, target_dtype)

            if target_dtype is not None:
                column_matrix = column_matrix.astype(target_dtype)

            save_arrays.append(column_matrix)

        return save_arrays

    def _get_jagged_arrays_varlen(
        self, arrays: ak.Array, column_names: list[str]
    ) -> tuple[list[np.ndarray], np.ndarray]:
        packed_arrays = []
        cu_seqlens: np.ndarray | None = None

        for column_name in column_names:
            if column_name not in arrays.fields:
                raise RuntimeError(f"Column {column_name} not found in arrays!")

            column = arrays[column_name]
            offsets, packed = ak_pack(column)

            if cu_seqlens is None:
                cu_seqlens = offsets.astype(np.int64)

            target_dtype = None
            if self.enforce_dtypes is not None and column_name in self.enforce_dtypes:
                target_dtype = np.dtype(self.enforce_dtypes[column_name])

            packed = sanitize_invalid(packed, target_dtype)

            if target_dtype is not None:
                packed = packed.astype(target_dtype)

            packed_arrays.append(packed)

        if cu_seqlens is None:
            raise RuntimeError("No columns found for varlen packing!")

        return packed_arrays, cu_seqlens

    def _get_deque_pile_idx(self) -> int:
        if self.pile_assignment == "deque":
            if self._pile_deque is None:
                raise RuntimeError("Pile deque is not initialized!")

            idx = self._pile_deque[0]
            self._pile_deque.rotate(-1)
            return idx
        else:
            raise RuntimeError(f"Pile assignment method {self.pile_assignment} not recognized!")

    def set_current_idx(self, value: int) -> None:
        self.object_piles_info_dct[self._current_dataset_name][self.current_pile_idx]["current_idx"] = value
        return None

    def set_current_shape(self, value: int) -> None:
        self.object_piles_info_dct[self._current_dataset_name][self.current_pile_idx]["current_shape"] = value
        return None

    def set_current_pile_idx(self, value: int) -> None:
        self._current_pile_idx = self._piles_lst[value]
        return None

    @property
    def current_idx(self) -> int:
        return self.object_piles_info_dct[self._current_dataset_name][self.current_pile_idx]["current_idx"]

    @property
    def current_shape(self) -> int:
        return self.object_piles_info_dct[self._current_dataset_name][self.current_pile_idx]["current_shape"]

    @property
    def current_pile_idx(self) -> int:
        return self._current_pile_idx

    def _write_object_arrays(
        self,
        arrays: ak.Array,
        dataset_name: str,
        column_names: list[str],
        pile_idx_lst: list[int],
        custom_chunk_shape: int | None = None,
        is_flat: bool = True,
    ) -> None:
        self._current_dataset_name = dataset_name

        if not self._created_datasets:
            self._writers_with_new_datasets: set[str] = set()

            if self.write_flat:
                flat_dtypes = self._get_flat_dtypes(arrays)
                events_metadata = self._create_events_datasets(flat_dtypes)
            else:
                events_metadata = {}

            if self.write_jagged:
                jagged_dtypes = self._get_jagged_dtypes(arrays)
                jagged_metadata = self._create_jagged_datasets(jagged_dtypes)
            else:
                jagged_metadata = {}

            for w in self.writers:
                if w.file_path in self._writers_with_new_datasets:
                    metadata = self._make_metadata(events_metadata, jagged_metadata)
                    w.add_metadata(metadata)

            self._created_datasets = True

        is_varlen = not is_flat and self.varlen

        if is_flat:
            save_arrays = self._get_flat_arrays(arrays, column_names)
        elif is_varlen:
            save_arrays, cu_seqlens = self._get_jagged_arrays_varlen(arrays, column_names)
        else:
            save_arrays = self._get_jagged_arrays(arrays, column_names)

        save_arrays_idx = np.arange(len(arrays))

        _chunk_shape = custom_chunk_shape if custom_chunk_shape is not None else self.chunk_shape
        array_chunks = (len(arrays) + _chunk_shape - 1) // _chunk_shape

        chunk_save_arrays_idx = np.array_split(save_arrays_idx, array_chunks)

        for i, chunk_array_idx in enumerate(chunk_save_arrays_idx):
            if len(chunk_array_idx) == 0:
                continue

            real_idx = pile_idx_lst[i]
            self.set_current_pile_idx(real_idx)

            writer = self.writers[real_idx]
            pile_info = self.object_piles_info_dct[self._current_dataset_name][self.current_pile_idx]

            if is_varlen:
                packed_start = int(cu_seqlens[chunk_array_idx[0]])
                packed_end = int(cu_seqlens[chunk_array_idx[-1] + 1])
                n_packed = packed_end - packed_start

                # write culens (cumulative offsets rebased to pile packed position, skip leading entry)
                culens_name = f"{self._current_dataset_name}_culens"

                chunk_culens = cu_seqlens[chunk_array_idx[0] + 1 : chunk_array_idx[-1] + 2].astype(np.int64)
                pile_packed_offset = pile_info["packed_current_idx"] - packed_start
                chunk_culens = chunk_culens + pile_packed_offset

                cl_start = pile_info["culens_current_idx"]
                cl_stop = cl_start + len(chunk_culens)
                cl_resize = None
                if cl_stop > pile_info["culens_current_shape"]:
                    cl_resize = (cl_stop,)
                    pile_info["culens_current_shape"] = cl_stop

                pile_info["culens_current_idx"] = cl_stop
                writer.add_array(chunk_culens, culens_name, idx=(cl_start, cl_stop), resize=cl_resize)

                # write packed data
                pk_start = pile_info["packed_current_idx"]
                pk_stop = pk_start + n_packed
                pk_resize = None
                if pk_stop > pile_info["packed_current_shape"]:
                    pk_resize = (pk_stop,)
                    pile_info["packed_current_shape"] = pk_stop

                pile_info["packed_current_idx"] = pk_stop

                chunk_arrays_dct: dict[str, np.ndarray] = {}
                for column_name, save_array in zip(column_names, save_arrays):
                    chunk_arrays_dct[column_name] = save_array[packed_start:packed_end]

                writer.add_data(chunk_arrays_dct, self._current_dataset_name, idx=(pk_start, pk_stop), resize=pk_resize)
            else:
                n_chunk = len(chunk_array_idx)

                start_idx = self.current_idx
                stop_idx = start_idx + n_chunk

                self.set_current_idx(stop_idx)

                resize: tuple[int, ...] | None = None

                if self.current_idx > self.current_shape:
                    if is_flat:
                        resize = (stop_idx,)
                    else:
                        resize = (stop_idx, self.max_lengths[self._current_dataset_name])

                    self.set_current_shape(stop_idx)

                chunk_arrays_dct = {}
                for column_name, save_array in zip(column_names, save_arrays):
                    chunk_arrays_dct[column_name] = save_array[chunk_array_idx]

                writer.add_data(chunk_arrays_dct, self._current_dataset_name, idx=(start_idx, stop_idx), resize=resize)

    def run(self, arrays: ak.Array | None) -> dict[str, ak.Array | None]:
        if arrays is None or len(arrays) == 0:
            return {"arrays": arrays}

        worker_id = self.reports["worker_id"]  # type: ignore[index]
        self._setup_piles_lst(worker_id)

        custom_chunk_shape: int | None = None

        if self.custom_chunk_shape_dct is not None:
            for k in self.custom_chunk_shape_dct.keys():
                if k in self.reports["file"]:  # type: ignore[index]
                    custom_chunk_shape = self.custom_chunk_shape_dct[k]
                    break

        _chunk_shape = custom_chunk_shape if custom_chunk_shape is not None else self.chunk_shape
        n_add_iters = (len(arrays) + _chunk_shape - 1) // _chunk_shape

        if self.pile_assignment == "random":
            pile_idx_lst = np.random.randint(0, len(self._piles_lst), size=n_add_iters).tolist()
        else:
            pile_idx_lst = [self._get_deque_pile_idx() for _ in range(n_add_iters)]

        for physics_object_name, physics_object_column_names in self.object_column_names_dct.items():
            self._write_object_arrays(
                arrays,
                dataset_name=physics_object_name,
                column_names=physics_object_column_names,
                pile_idx_lst=pile_idx_lst,
                custom_chunk_shape=custom_chunk_shape,
                is_flat=(physics_object_name == "events"),
            )

        return {"arrays": arrays}
