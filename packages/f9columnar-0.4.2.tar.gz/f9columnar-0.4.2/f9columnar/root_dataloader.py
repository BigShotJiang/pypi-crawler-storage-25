from __future__ import annotations

import copy
import logging
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Iterator

import awkward as ak
import numpy as np
import pandas as pd
import torch
import uproot
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from torch import multiprocessing
from torch.utils.data import DataLoader, IterableDataset
from uproot.exceptions import KeyInFileError

from f9columnar.processors import ProcessorsGraph
from f9columnar.utils.helpers import get_file_size


@dataclass
class RootFile:
    file_name: str
    key: str

    file_size: float = 0.0
    num_entries: int = 0
    tree: uproot.TTree = None

    def __post_init__(self) -> None:
        if not os.path.exists(self.file_name):
            raise RuntimeError(f"File {self.file_name} does not exist.")

        if not os.path.isfile(self.file_name):
            raise RuntimeError(f"{self.file_name} is not a file.")

        if not self.file_name.endswith(".root"):
            raise ValueError(f"File {self.file_name} is not a ROOT file.")

        self.file_size = get_file_size(self.file_name)

        self.file_name = f"{self.file_name}:{self.key}"

    def open_metadata(self) -> RootFile:
        with uproot.open(self.file_name, object_cache=None, array_cache=None) as root_file:
            self.num_entries = root_file.num_entries
        return self

    def open(self) -> RootFile:
        self.tree = uproot.open(self.file_name)
        self.num_entries = self.tree.num_entries
        return self

    def close(self) -> RootFile:
        self.tree.close()
        return self


@dataclass
class RootFiles:
    file_names: list[str]
    key: str | list[str]
    file_entry_ranges: dict[str, tuple[int, int]] | None = None

    files_dct: dict[str, RootFile] = field(default_factory=dict)

    file_size_dct: dict[str, float] = field(default_factory=dict)
    num_entries_dct: dict[str, int] = field(default_factory=dict)
    entry_ranges_dct: dict[str, tuple[int, int]] = field(default_factory=dict)

    total_file_size: float = 0.0
    total_num_entries: int = 0

    def load(self) -> RootFiles:
        for i, file_name in enumerate(self.file_names):
            if type(self.key) is list:
                root_file = RootFile(file_name, self.key[i])
            elif type(self.key) is str:
                root_file = RootFile(file_name, self.key)
            else:
                raise ValueError(f"Key {self.key} is not a valid type.")

            try:
                root_file = root_file.open_metadata()
            except KeyInFileError:
                logging.warning(f"Key {self.key} not found in file {os.path.basename(file_name)}. Skipping...")
                continue

            self.files_dct[file_name] = root_file
            self.file_size_dct[file_name] = root_file.file_size

            total_entries = root_file.num_entries

            # apply custom entry ranges if specified
            if self.file_entry_ranges is not None and file_name in self.file_entry_ranges:
                start, stop = self.file_entry_ranges[file_name]

                # validate file entry ranges
                if stop > total_entries:
                    logging.warning(
                        f"Stop entry {stop} for file {os.path.basename(file_name)} exceeds "
                        f"total entries ({total_entries}). Skipping..."
                    )
                    stop = total_entries
                if start >= stop:
                    logging.warning(
                        f"Start entry {start} must be less than stop entry {stop} "
                        f"for file {os.path.basename(file_name)}. Skipping..."
                    )
                    continue

                num_entries = stop - start
                self.entry_ranges_dct[file_name] = (start, stop)
            else:
                num_entries = total_entries
                self.entry_ranges_dct[file_name] = (0, total_entries)

            if num_entries == 0:
                logging.warning(f"File {os.path.basename(file_name)} has zero entries. Skipping...")
                continue

            self.num_entries_dct[file_name] = num_entries

            self.total_file_size += root_file.file_size
            self.total_num_entries += num_entries

        if self.total_num_entries == 0:
            raise RuntimeError("No valid ROOT files with entries found!")

        return self

    def __getitem__(self, file_name: str) -> RootFile:
        return self.files_dct[file_name]


class UprootIteratorsDfMaker:
    def __init__(
        self,
        name: str,
        files: list[str],
        key: str | list[str],
        step_size: int,
        num_workers: int,
        prepare_num_workers: int | None = None,
        file_entry_ranges: dict[str, tuple[int, int]] | None = None,
    ) -> None:
        self.name = name
        self.files, self.key = files, key
        self.num_workers = num_workers
        self.step_size = step_size
        self.file_entry_ranges = file_entry_ranges

        if prepare_num_workers is None:
            self.prepare_num_workers = min(len(files), num_workers)
        else:
            self.prepare_num_workers = prepare_num_workers

        self.total_num_entries = 0
        self.all_num_entries_dct: dict[str, int] = {}
        self.entry_ranges_dct: dict[str, tuple[int, int]] = {}

    def _log_info(self, total_files_size: float, total_num_entries: int) -> None:
        console = Console()

        table = Table(show_header=False, box=None, padding=(0, 1))
        table.add_column(style="cyan bold", no_wrap=True)
        table.add_column(style="green", no_wrap=True)

        table.add_row("Name:", self.name)
        table.add_row("Number of ROOT files:", str(len(self.files)))
        table.add_row("Total size:", f"{total_files_size:.3f} GB")
        table.add_row("Total number of entries:", f"{total_num_entries:,}")

        panel = Panel.fit(table, title="[bold blue]Dataset Summary[/bold blue]", border_style="blue", padding=(1, 2))

        console.print(panel)

    @staticmethod
    def _run_get_root_files(
        files_lst: list[str],
        key: str | list[str],
        file_entry_ranges: dict[str, tuple[int, int]] | None = None,
    ) -> RootFiles:
        return RootFiles(files_lst, key, file_entry_ranges=file_entry_ranges).load()

    def _join_root_files(self, root_files: list[RootFiles]) -> RootFiles:
        combined_files, combined_file_size_dct, combined_num_entries_dct = {}, {}, {}
        combined_entry_ranges_dct = {}

        total_file_size, total_num_entries = 0.0, 0

        for root_file in root_files:
            combined_files.update(root_file.files_dct)
            combined_file_size_dct.update(root_file.file_size_dct)
            combined_num_entries_dct.update(root_file.num_entries_dct)
            combined_entry_ranges_dct.update(root_file.entry_ranges_dct)

            total_file_size += root_file.total_file_size
            total_num_entries += root_file.total_num_entries

        return RootFiles(
            list(combined_files.keys()),
            key=self.key,
            file_entry_ranges=self.file_entry_ranges,
            files_dct=combined_files,
            file_size_dct=combined_file_size_dct,
            num_entries_dct=combined_num_entries_dct,
            entry_ranges_dct=combined_entry_ranges_dct,
            total_file_size=total_file_size,
            total_num_entries=total_num_entries,
        )

    def _split(self) -> list[dict[str, list[int]]]:
        logging.info("Preparing ROOT files (this may take a while).")

        jobs_idx_split = np.array_split(np.arange(len(self.files)), self.prepare_num_workers)

        if self.prepare_num_workers <= 1:
            logging.info("Using single-threaded preparation of ROOT files.")
            root_files_results = [self._run_get_root_files(self.files, self.key, self.file_entry_ranges)]
        else:
            logging.info(f"Using {self.prepare_num_workers} workers for parallel preparation of ROOT files.")
            with ProcessPoolExecutor(max_workers=self.prepare_num_workers) as executor:
                futures = []
                for job_idx in jobs_idx_split:
                    files_lst = [self.files[i] for i in job_idx]
                    futures.append(
                        executor.submit(
                            self._run_get_root_files,
                            files_lst,
                            self.key,
                            self.file_entry_ranges,
                        )
                    )

            root_files_results = []
            for future in futures:
                root_files_results.append(future.result())

        root_files = self._join_root_files(root_files_results)

        self._log_info(root_files.total_file_size, root_files.total_num_entries)

        total_num_entries = root_files.total_num_entries
        self.total_num_entries = total_num_entries
        self.entry_ranges_dct = root_files.entry_ranges_dct

        # how many entries each worker will process
        splits = [total_num_entries // self.num_workers] * self.num_workers
        splits[-1] += total_num_entries % self.num_workers

        self.all_num_entries_dct = root_files.num_entries_dct
        num_entries_dct = copy.deepcopy(root_files.num_entries_dct)

        # keep track of the start and stop entries for each root file
        root_files_start_dct: dict[str, int] = {root_file: 0 for root_file in self.files}

        split_result: list[dict[str, list[int]]] = [{} for _ in range(len(splits))]

        done = []
        for i, split in enumerate(splits):
            total = 0
            for root_file, num_entries in num_entries_dct.items():
                if root_file in done:
                    continue

                # get the relative start within the custom range
                entry_start_relative = root_files_start_dct[root_file]

                # get the absolute start from the custom range
                absolute_range_start = self.entry_ranges_dct[root_file][0]

                # calculate absolute entry positions
                entry_start_absolute = absolute_range_start + entry_start_relative

                total += num_entries

                if total <= split:
                    entry_stop_absolute = self.entry_ranges_dct[root_file][1]
                    split_result[i][root_file] = [entry_start_absolute, entry_stop_absolute]
                    done.append(root_file)

                    if total == split:
                        break
                    else:
                        continue

                if total > split:
                    delta = num_entries - (total - split)
                    entry_stop_absolute = entry_start_absolute + delta
                    split_result[i][root_file] = [entry_start_absolute, entry_stop_absolute]
                    root_files_start_dct[root_file] += delta
                    num_entries_dct[root_file] -= delta
                    break

        return split_result

    def make(self) -> pd.DataFrame:
        split_result = self._split()

        worker_df: dict[str, list] = {"worker_id": [], "file": [], "start": [], "stop": [], "step_size": []}

        check_total = 0
        for i, result_dct in enumerate(split_result):
            for root_file, start_stop in result_dct.items():
                entry_start, entry_stop = start_stop
                check_total += entry_stop - entry_start

                delta_entry = entry_stop - entry_start

                if delta_entry == 0:
                    continue

                range_start, range_stop = self.entry_ranges_dct[root_file]
                num_entries = range_stop - range_start

                if self.step_size > delta_entry:
                    step_size = delta_entry
                elif self.step_size > num_entries:
                    step_size = num_entries
                else:
                    step_size = self.step_size

                worker_df["worker_id"].append(i)
                worker_df["file"].append(f"{root_file}:{self.key}")
                worker_df["start"].append(entry_start)
                worker_df["stop"].append(entry_stop)
                worker_df["step_size"].append(step_size)

        if check_total != self.total_num_entries:
            raise ValueError("Total number of entries does not match.")

        return pd.DataFrame(worker_df)


class RootLoaderIterator:
    def __init__(
        self,
        name: str,
        iterators_df: pd.DataFrame,
        processors: list[Callable[[ak.Array, dict], tuple[ak.Array, dict]]] | ProcessorsGraph | None = None,
        filter_name: Callable[[str], bool] | None = None,
        root_files_desc_dct: dict[str, dict[str, Any]] | None = None,
        cache_factor: float = 1.0,
    ) -> None:
        self.name = name
        self.iterators_df = iterators_df
        self.processors = processors
        self.filter_name = filter_name
        self.root_files_desc_dct = root_files_desc_dct

        self.cache_factor = cache_factor

        self.iterator: Iterator
        self.tree: uproot.TTree

        self.current_df_idx, self.current_iterator_idx = 0, 0

    def _make_uproot_iterator(self, df: pd.Series) -> tuple[Iterator, uproot.TTree]:
        tree = uproot.open(
            df["file"],
            object_cache=int(100 * self.cache_factor),
            array_cache=f"{int(100 * self.cache_factor)} MB",
        )

        iterator = tree.iterate(
            library="ak",
            report=True,
            step_size=df["step_size"],
            filter_name=self.filter_name,
            entry_start=df["start"],
            entry_stop=df["stop"],
        )

        return iterator, tree

    def _iterate_df(self) -> None:
        df = self.iterators_df.iloc[self.current_iterator_idx]
        self.iterator, self.tree = self._make_uproot_iterator(df)
        self.current_df_idx += 1

    def _run_processors(self, arrays: ak.Array, reports: dict) -> tuple[ak.Array, dict] | ProcessorsGraph:
        if self.processors is None:
            return arrays, reports
        elif type(self.processors) is list:
            for proc in self.processors:
                arrays, reports = proc(arrays, reports)
            return arrays, reports
        elif type(self.processors) is ProcessorsGraph:
            self.processors.set_worker_id(reports["worker_id"])
            return self.processors.fit(arrays, reports)
        else:
            raise ValueError(f"Processors {self.processors} is not a valid type.")

    def _make_report(self, reports: Any) -> dict:
        file_path = reports._source._file._file_path
        file_name = os.path.basename(file_path)
        start, stop = reports._tree_entry_start, reports._tree_entry_stop

        reports = {
            "name": self.name,
            "worker_id": self.iterators_df.iloc[self.current_iterator_idx]["worker_id"],
            "file_path": file_path,
            "file": file_name,
            "start": start,
            "stop": stop,
        }

        if self.root_files_desc_dct is not None:
            base_root_file = file_name.replace(".tree.root", "").replace(".tree_metadata.root", "")
            reports = reports | self.root_files_desc_dct[base_root_file]

        return reports

    def __iter__(self) -> RootLoaderIterator:
        return self

    def __next__(self) -> tuple[ak.Array, dict] | ProcessorsGraph:
        if len(self.iterators_df) == 0:
            raise StopIteration

        try:
            if self.current_df_idx == self.current_iterator_idx:
                self._iterate_df()

            arrays, reports = next(self.iterator)

        except StopIteration:
            self.tree.close()
            self.current_iterator_idx += 1

            if self.current_iterator_idx == len(self.iterators_df):
                raise StopIteration

            if self.current_df_idx == self.current_iterator_idx:
                self._iterate_df()

            arrays, reports = next(self.iterator)

        reports = self._make_report(reports)

        processors_return = self._run_processors(arrays, reports)

        return processors_return


class RootIterableDataset(IterableDataset):
    def __init__(
        self,
        name: str,
        worker_iterators_df: pd.DataFrame,
        processors: list[Callable[[ak.Array, dict], tuple[ak.Array, dict]]] | ProcessorsGraph | None = None,
        filter_name: Callable[[str], bool] | None = None,
        root_files_desc_dct: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        self.name = name
        self.worker_iterators_df = worker_iterators_df
        self.processors = processors
        self.filter_name = filter_name
        self.root_files_desc_dct = root_files_desc_dct

    def __iter__(self) -> RootLoaderIterator:
        worker_info = torch.utils.data.get_worker_info()

        if worker_info is None:
            worker_id = 0
        else:
            worker_id = worker_info.id

        iterators_df = self.worker_iterators_df[self.worker_iterators_df["worker_id"] == worker_id].copy()

        return RootLoaderIterator(
            self.name,
            iterators_df,
            processors=self.processors,
            filter_name=self.filter_name,
            root_files_desc_dct=self.root_files_desc_dct,
        )


def get_root_dataloader(
    name: str,
    files: list[str],
    key: str,
    step_size: int,
    num_workers: int,
    processors: list[Callable[[ak.Array, dict], tuple[ak.Array, dict]]] | ProcessorsGraph | None = None,
    filter_name: Callable[[str], bool] | None = None,
    root_files_desc_dct: dict[str, dict[str, Any]] | None = None,
    cached_worker_iterators_df: pd.DataFrame | None = None,
    file_entry_ranges: dict[str, tuple[int, int]] | None = None,
    dataloader_kwargs: dict[str, Any] | None = None,
) -> tuple[DataLoader, int, pd.DataFrame]:
    """Create a PyTorch DataLoader for reading ROOT files with parallel processing.

    This function sets up an efficient data loading pipeline for ROOT files using
    uproot iterators and PyTorch's DataLoader. It automatically distributes the
    workload across multiple workers, handles file splitting, and supports custom
    data processing pipelines.

    Parameters
    ----------
    name : str
        Name identifier for the dataset. Used for logging and identification in
        metadata reports.
    files : list of str
        List of ROOT file paths to load. Files must exist and end with '.root'.
    key : str
        Name of the TTree within the ROOT files to read (e.g., 'Events', 'Tree').
    step_size : int
        Number of entries to load per iteration batch. Larger values use more
        memory but may be more efficient. This is the chunk size for uproot's
        iterate() method.
    num_workers : int
        Number of parallel worker processes for data loading. Use -1 to
        automatically use all available CPU cores, 0 for single-threaded mode
        (useful for debugging), or a positive integer for a specific number of
        workers.
    processors : list of callable or ProcessorsGraph, optional
        Data processing pipeline to apply to each batch. Can be either:
        - A list of functions with signature: (ak.Array, dict) -> (ak.Array, dict)
        - A ProcessorsGraph object for more complex processing workflows
        Default is None (no processing).
    filter_name : callable, optional
        Function to filter which branches/columns to load from the ROOT file.
        Signature: (str) -> bool. Should return True to include a branch.
        Default is None (load all branches).
    root_files_desc_dct : dict, optional
        Dictionary mapping base file names (without extensions) to metadata
        dictionaries. This metadata is merged into the reports for each batch.
        Useful for storing per-file metadata. Default is None.
    cached_worker_iterators_df : pd.DataFrame, optional
        Pre-computed DataFrame specifying worker assignments and file ranges.
        If provided, skips the file preparation phase. Useful for running the
        same configuration multiple times. Default is None (compute from scratch).
    file_entry_ranges : dict[str, tuple[int, int]], optional
        Dictionary mapping file paths to (start, stop) entry ranges to load only
        specific portions of files. Ranges are inclusive of start, exclusive of
        stop (Python slice convention). Files not in this dictionary will be
        loaded entirely. Example: {"file1.root": (0, 1000), "file2.root": (500, 1500)}
        Default is None (load entire files).
    dataloader_kwargs : dict, optional
        Additional keyword arguments to pass to PyTorch's DataLoader constructor.
        Common options include 'prefetch_factor', etc.
        Default is None (use DataLoader defaults).

    Returns
    -------
    dataloader : torch.utils.data.DataLoader
        Configured PyTorch DataLoader that yields batches of (arrays, metadata)
        tuples or ProcessorsGraph objects (if processors are used).
    total_num_entries : int
        Total number of entries across all files (within specified ranges if
        file_entry_ranges is provided). Returns -1 if cached_worker_iterators_df
        is used.
    worker_iterators_df : pd.DataFrame
        DataFrame describing the work distribution across workers. Columns include:
        - 'worker_id': Worker process identifier
        - 'file': Full file path with key
        - 'start': Starting entry index
        - 'stop': Stopping entry index
        - 'step_size': Chunk size for this file segment

    Notes
    -----
    - The function uses ProcessPoolExecutor for parallel file metadata extraction
      during initialization, which can take some time for large file sets.
    - Files with zero entries (or zero entries in the specified range) are
      automatically skipped with a warning.
    - When num_workers=0, the DataLoader runs in single-threaded mode.
    - The persistent_workers flag is automatically set based on num_workers to
      avoid recreating worker processes between epochs.

    """
    if num_workers == -1:
        num_workers = multiprocessing.cpu_count()

    if num_workers == 0:
        single_threaded = True
        num_workers = 1
    else:
        single_threaded = False

    if cached_worker_iterators_df is None:
        df_maker = UprootIteratorsDfMaker(
            name,
            files,
            key,
            step_size,
            num_workers,
            file_entry_ranges=file_entry_ranges,
        )
        worker_iterators_df = df_maker.make()
    else:
        df_maker = None
        worker_iterators_df = cached_worker_iterators_df

    if df_maker is not None:
        total_num_entries = df_maker.total_num_entries
    else:
        total_num_entries = -1

    root_iterable_dataset = RootIterableDataset(
        name,
        worker_iterators_df,
        processors=processors,
        filter_name=filter_name,
        root_files_desc_dct=root_files_desc_dct,
    )

    if dataloader_kwargs is None:
        dataloader_kwargs = {}

    if single_threaded:
        num_workers = 0
        logging.info(f"Using single-threaded DataLoader, setting num_workers to {num_workers}.")

    if num_workers == 0:
        dataloader_kwargs.pop("prefetch_factor", None)

    root_dataloader = DataLoader(
        root_iterable_dataset,
        batch_size=None,
        num_workers=num_workers,
        persistent_workers=True if num_workers > 0 else False,
        **dataloader_kwargs,
    )

    return root_dataloader, total_num_entries, worker_iterators_df
