from __future__ import annotations

import copy
import glob
import logging
import os
from itertools import product
from typing import Any, Callable, Type

import h5py
import numpy as np
import pandas as pd
import torch
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from torch import multiprocessing
from torch.utils.data import DataLoader, IterableDataset

from f9columnar.ml.imbalanced_sampler import ImbalancedSampler
from f9columnar.ml.scalers import NumerCategDatasetScaler
from f9columnar.processors import ProcessorsGraph
from f9columnar.utils.array_utils import column_stack_structured_array, make_packed_batch
from f9columnar.utils.data_containers import (
    FullWeightedBatchType,
    StackedDataset,
    StackedDatasets,
    WeightedBatch,
    WeightedBatchType,
    WeightedDatasetBatch,
)
from f9columnar.utils.hdf5_dataloader_helpers import ColumnSelection, get_column_selection, get_hdf5_metadata
from f9columnar.utils.helpers import get_file_size


class Hdf5Iterator:
    def __init__(
        self,
        file: str,
        dataset_names: list[str],
        start_entry: int,
        stop_entry: int,
        step_size: int | None = None,
        is_varlen: bool = False,
        setup_fn: Callable[[StackedDatasets, Hdf5Iterator], WeightedDatasetBatch | None] | None = None,
        dataset_kwargs: dict[str, Any] | None = None,
    ) -> None:
        self.file = file
        self.dataset_names = dataset_names
        self.stop_entry = stop_entry
        self.is_varlen = is_varlen

        # default setup
        self.step_size = self.stop_entry - start_entry if step_size is None else step_size
        self.setup_fn = setup_fn if setup_fn is not None else default_setup_fn
        self.dataset_kwargs = dataset_kwargs if dataset_kwargs is not None else {}

        # piles and dataset name parsing
        split_file = self.file.split(":")
        self.file, self.pile_name = split_file[0], split_file[1]

        # handle and index setup
        self.handle = h5py.File(self.file, "r")

        self._current_start_entry = start_entry
        self._current_stop_entry = min(start_entry + self.step_size, self.stop_entry)

        self.total, self.current = 0, 0

        # batch setup
        self.batch_size = self.dataset_kwargs.get("batch_size", None)

        if self.batch_size is None:
            self.batch_size = self.step_size

        self.drop_last = self.dataset_kwargs.get("drop_last", False)

        # setup imbalanced class sampling
        self.imbalanced_sampler: ImbalancedSampler | None

        self.used_imbalanced_sampler = self.dataset_kwargs.get("imbalanced_sampler", None)

        if self.used_imbalanced_sampler is not None:
            imbalanced_sampler_kwargs = self.dataset_kwargs.get("imbalanced_sampler_kwargs", {})
            self.imbalanced_sampler = ImbalancedSampler(
                self.used_imbalanced_sampler,
                imbalanced_sampler_kwargs,
                class_labels=self.dataset_kwargs.get("class_labels", None),
            )
        else:
            self.imbalanced_sampler = None

        # setup column selection
        self.selection: ColumnSelection = self.dataset_kwargs["selection"]

        # feature scaling setup
        self.dataset_scaler = NumerCategDatasetScaler(
            selection=self.selection,
            numer_scaler_type=self.dataset_kwargs.get("numer_scaler_type", None),
            categ_scaler_type=self.dataset_kwargs.get("categ_scaler_type", None),
            scaler_path=self.dataset_kwargs.get("scaler_path", None),
            extra_hash=self.dataset_kwargs.get("scalers_extra_hash", ""),
        )

        # remove unnecessary dataset kwargs for lighter reports
        self._filter_dataset_kwargs()

        # internal data types
        self.weighted_dataset_batch: WeightedDatasetBatch

    def _filter_dataset_kwargs(self, add_types: list[Type[Any]] | None = None) -> None:
        allowed_types = [int, float, str, bool, list, tuple, dict]

        if add_types is not None:
            allowed_types = allowed_types + add_types

        _dataset_kwargs: dict[str, Any] = {}

        for kw_name, kw_value in self.dataset_kwargs.items():
            for allow_type in allowed_types:
                if isinstance(kw_value, allow_type):
                    _dataset_kwargs[kw_name] = kw_value
                    break

        self.dataset_kwargs = _dataset_kwargs

    def _split_and_feature_scale(
        self, dataset_arrays_dct: dict[str, np.ndarray], dataset_culens_dct: dict[str, np.ndarray | None]
    ) -> StackedDatasets:
        stacked_datasets = StackedDatasets()

        for dataset_name, arrays in dataset_arrays_dct.items():
            numer_names = self.selection[dataset_name].numer_columns
            categ_names = self.selection[dataset_name].categ_columns

            extra: dict[str, Any] = {}

            extra_names = self.selection[dataset_name].extra_columns
            if len(extra_names) != 0:
                extra = {name: arrays[name].copy() for name in extra_names}

            if len(numer_names) != 0:
                X_numer_dataset_stack = column_stack_structured_array(arrays, numer_names)
                numer_shape = X_numer_dataset_stack.shape
            else:
                X_numer_dataset_stack = None

            if len(categ_names) != 0:
                X_categ_dataset_stack = column_stack_structured_array(arrays, categ_names)
                categ_shape = X_categ_dataset_stack.shape
            else:
                X_categ_dataset_stack = None

            X_numer_dataset_stack, X_categ_dataset_stack = self.dataset_scaler.scale(
                X_numer_dataset_stack, X_categ_dataset_stack, dataset_name
            )

            if X_numer_dataset_stack is not None and X_categ_dataset_stack is not None:
                X_dataset_stack = np.concatenate([X_numer_dataset_stack, X_categ_dataset_stack], axis=-1)
                numer_idx = np.arange(numer_shape[-1])
                categ_idx = np.arange(numer_shape[-1], numer_shape[-1] + categ_shape[-1])

            elif X_numer_dataset_stack is not None:
                X_dataset_stack = X_numer_dataset_stack
                categ_idx, numer_idx = None, np.arange(numer_shape[-1])

            elif X_categ_dataset_stack is not None:
                X_dataset_stack = X_categ_dataset_stack
                categ_idx, numer_idx = np.arange(categ_shape[-1]), None

            else:
                X_dataset_stack = np.array([])
                categ_idx, numer_idx = None, None

            extra["culens"] = dataset_culens_dct[dataset_name]

            stacked_datasets[dataset_name] = StackedDataset(
                X=X_dataset_stack,
                categ_idx=categ_idx,
                numer_idx=numer_idx,
                extra=extra,
            )

        return stacked_datasets

    def _get_dataset_array(self, dataset_name: str) -> np.ndarray:
        dataset = self.handle[dataset_name]
        load_columns = self.selection[dataset_name].used_columns

        slc = slice(self._current_start_entry, self._current_stop_entry)
        arrays = dataset.fields(load_columns)[slc]

        return arrays

    def _get_dataset_varlen_array(self, dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
        dataset = self.handle[dataset_name]
        load_columns = self.selection[dataset_name].used_columns

        cu_seqlens = self.handle[f"{dataset_name}_culens"][self._current_start_entry : self._current_stop_entry + 1]

        packed_slc = slice(int(cu_seqlens[0]), int(cu_seqlens[-1]))
        arrays = dataset.fields(load_columns)[packed_slc]

        cu_seqlens = cu_seqlens - cu_seqlens[0]

        return arrays, cu_seqlens

    def _on_next(self) -> bool:
        dataset_arrays_dct: dict[str, np.ndarray] = {}
        dataset_culens_dct: dict[str, np.ndarray | None] = {}

        for dataset_name in self.dataset_names:
            if self.is_varlen and dataset_name != "events":
                array, cu_seqlens = self._get_dataset_varlen_array(dataset_name)
            else:
                array, cu_seqlens = self._get_dataset_array(dataset_name), None

            dataset_arrays_dct[dataset_name] = array
            dataset_culens_dct[dataset_name] = cu_seqlens

        stacked_datasets = self._split_and_feature_scale(dataset_arrays_dct, dataset_culens_dct)

        setup_fn_return = self.setup_fn(stacked_datasets, self)

        if setup_fn_return is None:
            return False

        self.weighted_dataset_batch = setup_fn_return

        if set(self.dataset_names) != set(self.weighted_dataset_batch.keys()):
            logging.critical(f"Expected: {self.dataset_names}, have: {self.weighted_dataset_batch.keys()}!")
            raise RuntimeError("Dataset names mismatch!")

        self.total = self.weighted_dataset_batch.dim

        if self.batch_size > self.total:
            self.batch_size = self.total

        return True

    def _advance_step(self) -> bool:
        self._current_start_entry = self._current_stop_entry
        self._current_stop_entry = min(self._current_start_entry + self.step_size, self.stop_entry)
        self.current = 0
        return self._on_next()

    def _make_report(self) -> dict[str, Any]:
        report = {
            "file": self.file,
            "dataset_names": self.dataset_names,
            "step_size": self.step_size,
            "start": self._current_start_entry,
            "stop": self._current_stop_entry,
            "pile_name": self.pile_name,
            "batch_current": self.current,
            "batch_total": self.total,
            "batch_size": self.batch_size,
            "drop_last": self.drop_last,
            "used_imbalanced_sampler": self.used_imbalanced_sampler,
            "numer_feature_scaler_dct": self.dataset_scaler.numer_feature_scaler_dct,
            "categ_feature_scaler_dct": self.dataset_scaler.categ_feature_scaler_dct,
        }
        return report | self.dataset_kwargs

    def close(self) -> None:
        self.handle.close()

    def __iter__(self) -> Hdf5Iterator:
        return self

    def __next__(self) -> tuple[WeightedDatasetBatch, dict[str, Any]]:
        if self.current == 0:
            start_status = self._on_next()
            if not start_status:
                raise StopIteration

        if self.current == self.total:
            if self._current_stop_entry < self.stop_entry:
                if not self._advance_step():
                    self.close()
                    raise StopIteration
            else:
                self.close()
                raise StopIteration

        next_current = self.current + self.batch_size
        if next_current >= self.total:
            next_current = self.total

        if self.drop_last:
            if next_current - self.current < self.batch_size:
                self.close()
                raise StopIteration

        iter_weighted_dataset_batch = WeightedDatasetBatch()

        for ds_name in self.weighted_dataset_batch.keys():
            iter_weighted_dataset_batch[ds_name] = self.weighted_dataset_batch[ds_name, self.current : next_current]

        self.current = next_current

        reports = self._make_report()

        return iter_weighted_dataset_batch, reports


class Hdf5IteratorDfMaker:
    def __init__(
        self,
        name: str,
        hdf5_files_metadata: dict[str, dict[str, Any]],
        step_size: int | None,
        num_workers: int,
        shape: tuple[int, ...],
    ) -> None:
        self.name = name
        self.hdf5_files_metadata = hdf5_files_metadata
        self.step_size = step_size
        self.num_workers = num_workers
        self.shape = shape

        self.total_num_entries = shape[0]
        self.all_num_entries_dct: dict[str, int] = {}

    def _log_info(self) -> None:
        all_hdf5_files = list(self.hdf5_files_metadata.keys())
        hdf5_files = set([f.split(":")[0] for f in all_hdf5_files])

        total_files_size = sum([get_file_size(file) for file in hdf5_files])

        console = Console()

        table = Table(show_header=False, box=None, padding=(0, 1))
        table.add_column(style="cyan bold", no_wrap=True)
        table.add_column(style="green", no_wrap=True)

        table.add_row("Name:", self.name)
        table.add_row("Number of HDF5 files:", str(len(hdf5_files)))
        table.add_row("Total size:", f"{total_files_size:.3f} GB")
        table.add_row("Total number of entries:", f"{self.total_num_entries:,}")

        panel = Panel.fit(table, title="[bold blue]Dataset Summary[/bold blue]", border_style="blue", padding=(1, 2))

        console.print(panel)

    def _split(self) -> list[dict[str, list[int]]]:
        self._log_info()

        # how many entries each worker will process
        splits = [self.total_num_entries // self.num_workers] * self.num_workers
        splits[-1] += self.total_num_entries % self.num_workers

        self.all_num_entries_dct = {file: metadata["shape"][0] for file, metadata in self.hdf5_files_metadata.items()}
        num_entries_dct = copy.deepcopy(self.all_num_entries_dct)

        # keep track of the start and stop entries for each hdf5 file
        hdf5_files_start_dct: dict[str, int] = {file: 0 for file in self.hdf5_files_metadata.keys()}

        result: list[dict[str, list[int]]] = [{} for _ in range(len(splits))]

        done = []
        for i, split in enumerate(splits):
            total = 0
            for hdf5_file, num_entries in num_entries_dct.items():
                if hdf5_file in done:
                    continue

                start_entry = hdf5_files_start_dct[hdf5_file]

                total += num_entries

                if total <= split:
                    result[i][hdf5_file] = [start_entry, self.all_num_entries_dct[hdf5_file]]
                    done.append(hdf5_file)

                    if total == split:
                        break
                    else:
                        continue

                if total > split:
                    delta = num_entries - (total - split)
                    result[i][hdf5_file] = [start_entry, start_entry + delta]
                    hdf5_files_start_dct[hdf5_file] += delta
                    num_entries_dct[hdf5_file] -= delta
                    break

        return result

    def make(self) -> pd.DataFrame:
        split_result = self._split()

        worker_df: dict[str, list] = {"worker_id": [], "file": [], "start": [], "stop": [], "step_size": []}

        check_total = 0
        for i, result_dct in enumerate(split_result):
            for hdf5_file, start_stop in result_dct.items():
                entry_start, entry_stop = start_stop
                check_total += entry_stop - entry_start

                delta_entry = entry_stop - entry_start

                if self.step_size is None:
                    step_size = delta_entry
                else:
                    num_entries = self.all_num_entries_dct[hdf5_file]

                    if self.step_size > delta_entry:
                        step_size = delta_entry
                    elif self.step_size > num_entries:
                        step_size = num_entries
                    else:
                        step_size = self.step_size

                worker_df["worker_id"].append(i)
                worker_df["file"].append(hdf5_file)
                worker_df["start"].append(entry_start)
                worker_df["stop"].append(entry_stop)
                worker_df["step_size"].append(step_size)

        if check_total != self.total_num_entries:
            raise ValueError("Total number of entries does not match.")

        return pd.DataFrame(worker_df)


class Hdf5LoaderIterator:
    def __init__(
        self,
        name: str,
        dataset_names: list[str],
        iterators_df: pd.DataFrame,
        worker_id: int,
        is_varlen: bool = False,
        processors: list[Callable[[Any, dict], tuple[Any, dict]]] | ProcessorsGraph | None = None,
        setup_fn: Callable[[StackedDatasets, Hdf5Iterator], WeightedDatasetBatch | None] | None = None,
        dataset_kwargs: dict[str, Any] | None = None,
    ) -> None:
        self.name = name
        self.dataset_names = dataset_names
        self.iterators_df = iterators_df
        self.worker_id = worker_id
        self.is_varlen = is_varlen
        self.processors = processors
        self.setup_fn = setup_fn
        self.dataset_kwargs = dataset_kwargs

        self._current_df_idx, self._current_iterator_idx = 0, 0

        self.iterator: Hdf5Iterator

    def _make_hdf5_iterator(self, df: pd.Series) -> Hdf5Iterator:
        iterator = Hdf5Iterator(
            df["file"],
            self.dataset_names,
            start_entry=df["start"],
            stop_entry=df["stop"],
            step_size=df["step_size"],
            is_varlen=self.is_varlen,
            dataset_kwargs=self.dataset_kwargs,
            setup_fn=self.setup_fn,
        )

        return iterator

    def _iterate_df(self) -> None:
        df = self.iterators_df.iloc[self._current_iterator_idx]
        self.iterator = self._make_hdf5_iterator(df)
        self._current_df_idx += 1

    def _run_processors(self, arrays_obj: Any, reports: dict[str, Any]) -> tuple[Any, dict] | ProcessorsGraph:
        if self.processors is None:
            return arrays_obj, reports
        elif type(self.processors) is list:
            arrays = arrays_obj
            for proc in self.processors:
                arrays, reports = proc(arrays, reports)
            return arrays, reports
        elif type(self.processors) is ProcessorsGraph:
            return self.processors.fit(arrays_obj, reports)
        else:
            raise ValueError(f"Processors {self.processors} is not a valid type.")

    def _make_report(self, reports: Any) -> dict:
        reports = {"name": self.name, "worker_id": self.worker_id} | reports
        return reports

    def __iter__(self) -> Hdf5LoaderIterator:
        return self

    def __next__(self) -> tuple[Any, dict] | ProcessorsGraph:
        try:
            if self._current_df_idx == self._current_iterator_idx:
                self._iterate_df()

            arrays, reports = next(self.iterator)

        except StopIteration:
            self.iterator.close()
            self._current_iterator_idx += 1

            if self._current_iterator_idx == len(self.iterators_df):
                raise StopIteration

            if self._current_df_idx == self._current_iterator_idx:
                self._iterate_df()

            arrays, reports = next(self.iterator)

        reports = self._make_report(reports)

        processors_return = self._run_processors(arrays, reports)

        return processors_return


class Hdf5IterableDataset(IterableDataset):
    def __init__(
        self,
        name: str,
        files: str | list[str],
        dataset_names: list[str],
        step_size: int | None,
        num_workers: int,
        stage_split_piles: dict[str, list[int] | int] | None = None,
        stage: str | None = None,
        processors: list[Callable[[Any, dict], tuple[Any, dict]]] | ProcessorsGraph | None = None,
        setup_fn: Callable[[StackedDatasets, Hdf5Iterator], WeightedDatasetBatch | None] | None = None,
        dataset_kwargs: dict[str, Any] | None = None,
    ) -> None:
        """Iterable dataset for loading HDF5 files in structured array format.

        Parameters
        ----------
        name : str
            Name of the dataset, used for logging and debugging.
        files : list[str]
            List of HDF5 files to load. Can also be a wildcard string (e.g., "data/*") to load multiple
            files matching the pattern.
        dataset_names : list[str]
            List of dataset names to load from the HDF5 files.
        num_workers : int
            Number of workers to use for loading the data. If -1, will use all available CPU cores.
        stage_split_piles : dict[str, list[int] | int] | None, optional
            Dictionary containing the stage split piles. The keys are the stage names and the values are either
            lists of integers representing the indices of the piles to use for each stage, or integers representing
            the number of piles to use for each stage. If None, no stage split piles will be used. By default None.
        stage : str | None, optional
            The stage to use for loading the data. If None, will load all data. If provided, will load only the data
            for the specified stage. This is used in conjunction with `stage_split_piles` to load only the data for
            the specified stage. If `stage_split_piles` is provided, this parameter must also be set. By default None.
        processors : list[Callable[[Any, dict], tuple[Any, dict]]] | ProcessorsGraph | None, optional
            List of processors to apply per batch yield. Each processor should be a callable that
            takes a WeightedDatasetBatch and a dictionary of reports, and returns a tuple of the processed
            batch and the updated reports. If a ProcessorsGraph is provided, it will be used to process the data.
            If None, no processors will be applied. By default None.
        """
        super().__init__()
        if (stage is None) != (stage_split_piles is None):
            raise ValueError("stage and stage_split_piles must be set together.")

        if type(files) is str and files.endswith("*"):
            files = glob.glob(f"{files}.hdf5")
            logging.info(f"Wildcard found {len(files)} hdf5 files.")

        if type(files) is not list:
            raise TypeError("Files must be a wildcard * string or a list of strings!")

        if len(files) == 0:
            raise RuntimeError("No HDF5 files found!")

        self.files = files
        self.name = name
        self.dataset_names = dataset_names
        self.step_size = step_size
        self.processors = processors
        self.setup_fn = setup_fn
        self.dataset_kwargs = dataset_kwargs

        if num_workers == -1:
            self.num_workers = multiprocessing.cpu_count()
        else:
            self.num_workers = num_workers

        self.stage_idx: list[int] | None = None
        self.total_stage_split: int = 0

        if stage_split_piles is not None:
            if isinstance(stage_split_piles[list(stage_split_piles.keys())[0]], int):
                self.stage_idx, self.total_stage_split = self._get_stage_split_piles_from_int(stage_split_piles, stage)  # type: ignore[arg-type]
            else:
                logging.info("Using custom stage split piles.")
                self.stage_idx, self.total_stage_split = self._get_stage_split_piles_from_lst(stage_split_piles, stage)  # type: ignore[arg-type]

        self.metadata = self._setup_piles()
        self.shape = self._get_total_shape()

        self.worker_iterators_df = self._get_df_iterators()

        self.is_varlen = get_hdf5_metadata(self.files[0]).get("varlen", False)
        if self.is_varlen:
            logging.info("Packed variable-length dataset detected.")

    def _get_stage_split_piles_from_lst(
        self, stage_split_piles: dict[str, list[int]], stage: str
    ) -> tuple[list[int], int]:
        valid_idx = list(stage_split_piles[stage])
        return valid_idx, len(valid_idx)

    def _get_stage_split_piles_from_int(self, stage_split_piles: dict[str, int], stage: str) -> tuple[list[int], int]:
        _split_n_piles, current_idx = {}, 0

        for k in stage_split_piles.keys():
            _split_n_piles[k] = [i for i in range(current_idx, current_idx + stage_split_piles[k])]
            current_idx += stage_split_piles[k]

        valid_idx = _split_n_piles[stage]

        return valid_idx, sum([len(v) for v in _split_n_piles.values()])

    @staticmethod
    def _get_keys(file_path: str) -> list[str]:
        with h5py.File(file_path, "r") as f:
            keys = list(f.keys())

        return keys

    @staticmethod
    def _get_pile_shape(file_path: str, dataset_name: str) -> tuple[int, int]:
        with h5py.File(file_path, "r") as f:
            obj = f[dataset_name]
            shape = obj.shape

        return shape

    def _setup_piles(self) -> dict[str, dict[str, Any]]:
        piles_metadata: dict[str, dict[str, Any]] = {}

        for file, dataset_name in product(self.files, self.dataset_names):
            if dataset_name not in self._get_keys(file):
                logging.warning(f"Dataset {dataset_name} not found in {file}. Skipping!")
                continue

            pile_name = os.path.basename(file).split(".")[0]
            pile_idx = int(pile_name[1:])
            pile_key = f"{file}:p{pile_idx}"

            if self.stage_idx is not None and pile_idx not in self.stage_idx:
                continue

            if file not in piles_metadata:
                piles_metadata[pile_key] = {}

            piles_metadata[pile_key]["shape"] = self._get_pile_shape(file, dataset_name)

        return piles_metadata

    def _get_total_shape(self) -> tuple[int, ...]:
        total_shapes: dict[int, list[int]] = {}

        for _, metadata_shape in enumerate(self.metadata.values()):
            shape = metadata_shape["shape"]

            for i, s in enumerate(shape):
                if i not in total_shapes:
                    total_shapes[i] = []

                total_shapes[i].append(s)

        total_shape = []
        for i, v in total_shapes.items():
            if i == 0:
                total_shape.append(sum(v))
            else:
                total_shape += list(set(v))

        return tuple(total_shape)

    def _get_df_iterators(self) -> pd.DataFrame:
        df = Hdf5IteratorDfMaker(
            self.name,
            self.metadata,
            self.step_size,
            self.num_workers,
            self.shape,
        ).make()

        return df

    def __iter__(self) -> Hdf5LoaderIterator:
        worker_info = torch.utils.data.get_worker_info()

        if worker_info is None:
            worker_id = 0
        else:
            worker_id = worker_info.id

        iterators_df = self.worker_iterators_df[self.worker_iterators_df["worker_id"] == worker_id].copy()

        if len(iterators_df) == 0:
            raise StopIteration

        return Hdf5LoaderIterator(
            self.name,
            self.dataset_names,
            iterators_df,
            worker_id,
            self.is_varlen,
            self.processors,
            setup_fn=self.setup_fn,
            dataset_kwargs=self.dataset_kwargs,
        )


def default_collate_fn(batch: Any) -> Any:
    return batch


def events_collate_fn(batch: tuple[WeightedDatasetBatch, dict[str, Any]]) -> WeightedBatchType:
    ds, reports = batch[0]["events"], batch[1]

    numer_feature_scaler_dct = reports.pop("numer_feature_scaler_dct")
    categ_feature_scaler_dct = reports.pop("categ_feature_scaler_dct")

    reports["numer_scaler"] = numer_feature_scaler_dct["events"]
    reports["categ_scaler"] = categ_feature_scaler_dct["events"]

    return ds.X, ds.y, ds.w, ds.y_aux, reports


def full_collate_fn(batch: tuple[WeightedDatasetBatch, dict[str, Any]]) -> FullWeightedBatchType:
    datasets_batch, reports = batch[0].make_batch(), batch[1]
    return datasets_batch, reports


def remap_labels_lookup(y: np.ndarray, max_label: int, remap_labels: dict[int, int]) -> tuple[np.ndarray, np.ndarray]:
    lookup = np.full(max_label + 1, -1)

    for old_label, new_label in remap_labels.items():
        lookup[old_label] = new_label

    y = lookup[y]

    mask_unmapped = y != -1

    return y[mask_unmapped], mask_unmapped


def default_setup_fn(stacked_datasets: StackedDatasets, ml_iterator: Hdf5Iterator) -> WeightedDatasetBatch | None:
    """Pile-level transform (raw arrays -> structured batch)."""
    weighted_datase_batch = WeightedDatasetBatch()

    dataset_keys = stacked_datasets.keys()
    if "events" in dataset_keys:
        dataset_keys.remove("events")
        dataset_keys.insert(0, "events")

    shuffle = ml_iterator.dataset_kwargs.get("shuffle", False)

    mask_unmapped: np.ndarray | None = None
    shuffle_idx: np.ndarray | None = None

    for ds_name in dataset_keys:
        ds = stacked_datasets[ds_name]

        X = ds.X.astype(np.float32) if not ds.is_empty else None
        y = ds.get_extra("label_type", None)
        w = ds.get_extra("weights", None)
        culens = ds.get_extra("culens", None)

        if culens is not None:
            culens = culens.astype(np.int32)

        if y is not None:
            remap_labels: dict[int, int] | None = ml_iterator.dataset_kwargs.get("remap_labels", None)
            if remap_labels is not None:
                max_label = ml_iterator.dataset_kwargs["max_label"]
                y, mask_unmapped = remap_labels_lookup(y, max_label, remap_labels)

            if y.shape[0] == 0:
                return None

        if mask_unmapped is not None:
            if w is not None:
                w = w[mask_unmapped]

            if culens is not None and X is not None:
                # build particle-level mask from event-level mask using culens
                lengths = np.diff(culens)
                kept_lengths = lengths[mask_unmapped]

                particle_mask = np.zeros(int(culens[-1]), dtype=bool)
                for i in np.where(mask_unmapped)[0]:
                    particle_mask[int(culens[i]) : int(culens[i + 1])] = True

                X = X[particle_mask]
                culens = np.concatenate([[0], np.cumsum(kept_lengths)])
            elif X is not None:
                X = X[mask_unmapped]

        if X is None:
            n_samples = y.shape[0] if y is not None else (w.shape[0] if w is not None else 0)
            X = np.empty((n_samples, 0), dtype=np.float32)

        if shuffle:
            # compute shuffle_idx once from the events dataset, reuse for all others
            if shuffle_idx is None:
                n_events = y.shape[0] if y is not None else X.shape[0]
                shuffle_idx = np.random.permutation(n_events)

            if culens is not None:
                culens, X = make_packed_batch(shuffle_idx, culens, X)
            else:
                X = X[shuffle_idx]

            if y is not None:
                y = y[shuffle_idx]
            if w is not None:
                w = w[shuffle_idx]

        weighted_datase_batch[ds_name] = WeightedBatch(X, y, w, y_aux=None, culens=culens)

    return weighted_datase_batch


def get_hdf5_dataloader(
    name: str,
    files: str | list[str],
    column_names: list[str],
    step_size: int | None = None,
    num_workers: int | None = None,
    stage_split_piles: dict[str, list[int] | int] | None = None,
    stage: str | None = None,
    setup_fn: Callable[[StackedDatasets, Hdf5Iterator], WeightedDatasetBatch | None] | None = None,
    collate_fn: Callable[[tuple[WeightedDatasetBatch, dict[str, Any]]], Any] | None = None,
    processors: list[Callable[[Any, dict], tuple[Any, dict]]] | ProcessorsGraph | None = None,
    dataset_kwargs: dict[str, Any] | None = None,
    dataloader_kwargs: dict[str, Any] | None = None,
) -> tuple[DataLoader, ColumnSelection, int]:
    """Create an HDF5 DataLoader with column selection and optional stage splitting.

    Parameters
    ----------
    name : str
        Identifier for this dataloader instance.
    files : str or list of str
        Path(s) to HDF5 file(s).
    column_names : list of str
        Columns to load from each dataset.
    step_size : int or None, optional
        Number of entries to load into memory per step. Batches of size `batch_size`
        are then yielded from each step. If None, all entries from a file are loaded at once.
    num_workers : int or None, optional
        Number of worker processes. Use -1 for all CPUs, None defaults to 0
        (single process).
    stage_split_piles : dict or None, optional
        Mapping of stage names to pile indices (or count) for splitting data
        across stages.
    stage : str or None, optional
        Which stage to load when using `stage_split_piles`.
    collate_fn : callable or None, optional
        Required callable to collate batches from the iterable dataset.
    processors : list of callable, ProcessorsGraph, or None, optional
        Processing pipeline applied per batch yield on the WeightedDatasetBatch.
    setup_fn : callable or None, optional
        Pile-level transform that converts `StackedDatasets` into `WeightedDatasetBatch`.
        Defaults to `default_setup_fn`.
    dataset_kwargs : dict or None, optional
        Extra kwargs forwarded to `Hdf5IterableDataset` (e.g. batch_size).
    dataloader_kwargs : dict or None, optional
        Extra kwargs forwarded to `torch.utils.data.DataLoader` (e.g. num_workers, prefetch_factor).

    Returns
    -------
    dataloader : DataLoader
        The configured HDF5-backed DataLoader.
    selection : ColumnSelection
        The resolved column selection mapping.
    n_samples : int
        Total number of samples across all selected piles.
    """
    selection = get_column_selection(files, column_names)

    if dataset_kwargs is None:
        dataset_kwargs = {}

    if type(dataset_kwargs) is not dict:
        raise TypeError(f"dataset_kwargs must be a dict, got {type(dataset_kwargs)} instead.")

    dataset_kwargs["selection"] = selection

    if dataloader_kwargs is not None:
        if "batch_size" not in dataset_kwargs and "batch_size" in dataloader_kwargs:
            dataset_kwargs["batch_size"] = dataloader_kwargs.pop("batch_size")
            logging.info(f"Set batch size to {dataset_kwargs['batch_size']}.")

    if dataloader_kwargs is None:
        dataloader_kwargs = {}

    if num_workers is None and "num_workers" in dataloader_kwargs:
        num_workers = dataloader_kwargs["num_workers"]

    if num_workers == -1:
        num_workers = multiprocessing.cpu_count()
        dataloader_kwargs["num_workers"] = num_workers

    if num_workers is None:
        num_workers = 0
        dataloader_kwargs["num_workers"] = 0
        logging.info("num_workers is set to 0, using single process for loading data.")

    if "num_workers" not in dataloader_kwargs:
        dataloader_kwargs["num_workers"] = num_workers

    logging.info(f"Using {num_workers} workers for loading data.")

    dataset_names = selection.keys()

    hdf5_dataset = Hdf5IterableDataset(
        name,
        files,
        dataset_names,
        step_size=step_size,
        num_workers=num_workers if num_workers > 0 else 1,
        stage_split_piles=stage_split_piles,
        stage=stage,
        processors=processors,
        setup_fn=setup_fn,
        dataset_kwargs=dataset_kwargs,
    )

    if collate_fn is None:
        collate_fn = default_collate_fn

    dataloader_kwargs.pop("batch_size", None)

    hdf5_dataloader = DataLoader(
        hdf5_dataset,
        batch_size=None,
        collate_fn=collate_fn,  # type: ignore[arg-type]
        persistent_workers=True if num_workers > 0 else False,
        **dataloader_kwargs,
    )

    return hdf5_dataloader, selection, hdf5_dataset.shape[0]
