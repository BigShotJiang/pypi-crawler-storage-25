from marshmallow import (
    Schema,
    fields,
    validate,
)


class ConferencePlannerResourceSchema(Schema):
    not_blank = validate.Length(min=1, error="Field cannot be blank")

    id = fields.Integer(dump_only=True)
    user_id = fields.String(required=True, validate=not_blank)
    meeting_id = fields.Integer(required=True)
    planner_name = fields.String(required=True, validate=not_blank)
    description = fields.String(allow_none=True)
    explorer_payload = fields.String(allow_none=True)
    ag_grid_state = fields.String(allow_none=True)
    artifact_count = fields.Integer()
    version = fields.Integer()
    is_deleted = fields.Boolean(allow_none=True)
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)
