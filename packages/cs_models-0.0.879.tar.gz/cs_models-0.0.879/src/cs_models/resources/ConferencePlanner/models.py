from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    Boolean,
    ForeignKey,
    Text,
    Index,
)

from ...database import Base


class ConferencePlannerModel(Base):
    __tablename__ = 'conference_planners'

    id = Column(Integer, primary_key=True)
    user_id = Column(String(128), nullable=False, index=True)
    meeting_id = Column(
        Integer,
        ForeignKey('meetings.id'),
        nullable=False,
    )
    planner_name = Column(String(191), nullable=False)
    description = Column(Text, nullable=True)
    explorer_payload = Column(Text, nullable=True)
    ag_grid_state = Column(Text, nullable=True)
    artifact_count = Column(Integer, nullable=False, default=0)
    version = Column(Integer, nullable=False, default=1)
    is_deleted = Column(Boolean, nullable=True)
    created_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
    )
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_conference_planners_user_updated', 'user_id', 'updated_at'),
        Index('idx_conference_planners_meeting_updated', 'meeting_id', 'updated_at'),
    )
