from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
)

from ...database import Base


class MindgramOAuthTransactionModel(Base):
    __tablename__ = "mindgram_oauth_transactions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    state = Column(String(255), nullable=False, unique=True)
    provider = Column(String(32), nullable=False)
    user_id = Column(String(128), nullable=False)
    redirect_uri = Column(String(255), nullable=False)
    status = Column(String(32), nullable=False)
    expires_at = Column(DateTime, nullable=False)
    consumed_at = Column(DateTime, nullable=True)
    error_code = Column(String(64), nullable=True)
    created_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
    )
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )
