from marshmallow import (
    Schema,
    fields,
    pre_load,
)

from ...utils.utils import pre_load_date_fields


class MindgramOAuthTransactionResourceSchema(Schema):
    id = fields.Integer(dump_only=True)
    state = fields.String(required=True)
    provider = fields.String(required=True)
    user_id = fields.String(required=True)
    redirect_uri = fields.String(required=True)
    status = fields.String(required=True)
    expires_at = fields.DateTime(required=True)
    consumed_at = fields.DateTime(allow_none=True)
    error_code = fields.String(allow_none=True)
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)

    @pre_load
    def convert_string_to_datetime(self, in_data, **kwargs):
        date_fields = ["expires_at", "consumed_at"]

        in_data = pre_load_date_fields(
            in_data,
            date_fields,
            date_format="%Y%m%dT%H%M%S",
        )
        return in_data
