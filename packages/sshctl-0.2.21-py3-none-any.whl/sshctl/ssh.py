from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

import paramiko

from .model import Server


def _expand_path(p: Optional[str]) -> Optional[str]:
    if not p:
        return None
    return str(Path(os.path.expanduser(p)).expanduser())


def run_ssh(server: Optional[Server]) -> int:
    """使用 Paramiko SSH 连接（不依赖 sshpass / ~/.ssh/config）。

    优先使用 password，其次 identity_file。
    """

    if not server:
        raise SystemExit("找不到服务器记录（请先 list 确认编号，或先 add 添加）。")

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    connect_kwargs = {
        "hostname": server.host,
        "port": server.port,
        "username": server.user,
        "timeout": 10,
    }

    if server.password:
        connect_kwargs["password"] = server.password
    elif server.identity_file:
        key_path = _expand_path(server.identity_file)
        if key_path:
            connect_kwargs["key_filename"] = key_path

    try:
        client.connect(**connect_kwargs)
    except Exception as e:
        print(f"[ERROR] 连接失败 {server.user}@{server.host}:{server.port} — {e}", file=sys.stderr)
        return 1

    # 进入交互式 shell
    channel = client.invoke_shell()
    channel.interactive()
    client.close()
    return 0