from __future__ import annotations

import argparse
import os
import sys
import ipaddress
import re
from dataclasses import replace
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
from rich import box


# ---- argparse 中文化（帮助信息/错误信息更友好） ----
_ZH_MAP = {
    "usage: ": "用法：",
    "positional arguments": "位置参数",
    "options": "可选参数",
    "optional arguments": "可选参数",
    "show this help message and exit": "显示帮助并退出",
    "the following arguments are required: %s": "以下参数是必填的：%s",
    "invalid choice: %r (choose from %s)": "无效选项：%r（可选：%s）",
    "unrecognized arguments: %s": "无法识别的参数：%s",
    "expected one argument": "需要 1 个参数",
    "expected at least one argument": "至少需要 1 个参数",
}

# argparse 在 import 时把 gettext.gettext 绑定到 argparse._
# 这里做一个轻量的翻译覆盖，让帮助/报错信息更偏中文。
argparse._ = lambda s: _ZH_MAP.get(s, s)  # type: ignore[attr-defined]

from . import __version__
from .db import get_conn, init_db, reindex_server_ids
from .repo import (
    create_server,
    delete_server_by_name,
    get_server_by_id,
    get_server_by_name,
    list_servers,
    search_servers,
    update_server_by_name,
)

# ⚠️ 说明：sshctl 可以保存登录密码（明文）到数据库 password 字段（不安全）。
# 但注意：你在 ssh 自己弹出的 password 提示里输入的内容，程序无法截获。
# 所以如果想“输入一次并保存”，需要在 sshctl 连接前由 sshctl 主动询问密码。
from .ssh import run_ssh

console = Console()


def _validate_port(p: str) -> int:
    try:
        v = int(p)
    except ValueError:
        raise argparse.ArgumentTypeError("port 必须是整数")
    if not (1 <= v <= 65535):
        raise argparse.ArgumentTypeError("port 必须在 1-65535")
    return v


def _validate_host(h: str) -> str:
    """校验 host：必须是 IPv4/IPv6（按你的要求：不接受域名）。"""

    raw = (h or "").strip()
    if not raw:
        raise argparse.ArgumentTypeError("host 不能为空")
    if any(ch.isspace() for ch in raw):
        raise argparse.ArgumentTypeError("host 不能包含空格")

    # 允许用户粘贴 [IPv6] 形式，这里去掉中括号
    unwrapped = raw[1:-1] if raw.startswith("[") and raw.endswith("]") else raw

    try:
        ipaddress.ip_address(unwrapped)
        return unwrapped
    except ValueError:
        raise argparse.ArgumentTypeError("host 必须是 IP（不支持域名）")


def _ask_port(default: int = 22) -> int:
    while True:
        raw = Prompt.ask("port", default=str(default)).strip()
        try:
            return _validate_port(raw)
        except argparse.ArgumentTypeError as e:
            console.print(f"[red]{e}[/red]")


def _ask_host(default: Optional[str] = None) -> str:
    while True:
        raw = _ask_required("host（IP 或域名）", default=default)
        try:
            return _validate_host(raw)
        except argparse.ArgumentTypeError as e:
            console.print(f"[red]{e}[/red]")


def _ask_optional(label: str, default: Optional[str] = None) -> Optional[str]:
    # default 为空时不显示 "()"，避免提示看起来很怪
    d = (default or "").strip()
    raw = Prompt.ask(label, default=d, show_default=bool(d))
    raw = raw.strip()
    return raw or None


def _ask_required(label: str, default: Optional[str] = None) -> str:
    d = (default or "").strip()
    while True:
        raw = Prompt.ask(label, default=d, show_default=bool(d)).strip()
        if raw:
            return raw
        console.print("[red]不能为空[/red]")


def _render_servers(rows) -> None:
    # box=box.SQUARE：更“方正”；padding/collapse_padding 让边框更紧凑、更对齐
    # 如果你的终端/字体对 box drawing 字符支持不好，仍然会有错位：可改成 box=box.ASCII 最稳。
    table = Table(
        title="sshctl servers",
        title_justify="center",
        box=box.SQUARE,
        padding=(0, 1),
        pad_edge=False,
        collapse_padding=True,
        show_lines=True,  # 多条记录之间显示横线分隔
    )

    # 你要求“第一列显示 id”，并且所有列居中显示
    table.add_column("id", justify="center", style="bold", no_wrap=True)
    table.add_column("name", justify="center", style="bold", no_wrap=True)
    table.add_column("host", justify="center", no_wrap=True)
    table.add_column("user", justify="center", no_wrap=True)
    table.add_column("port", justify="center", no_wrap=True)
    table.add_column("password", justify="center")

    def mask_pw(s) -> str:
        # 永远不显示明文，只显示是否已设置
        return "已设置" if getattr(s, "has_password", False) else ""

    for s in rows:
        table.add_row(
            str(s.id),
            s.name,
            s.host,
            s.user,
            str(s.port),
            mask_pw(s),
        )

    console.print(table)


def _ask_select_server(rows) -> str:
    """让用户用 id 选择（更稳定，不受排序影响）。

    返回：用户输入的 target（可能是 id，也可能是 name）
    """
    if not rows:
        return _ask_required("请输入要连接的 id 或 name")

    ids = {s.id for s in rows}

    while True:
        raw = Prompt.ask("请输入要连接的 [id]（回车则改为手动输入 name）", default="", show_default=False).strip()
        if raw == "":
            return _ask_required("请输入要连接的 name")
        if raw.isdigit() and int(raw) in ids:
            return raw
        # 允许直接输入 name 作为兜底
        if raw:
            return raw


def cmd_init(args: argparse.Namespace) -> int:
    with get_conn(args.db) as conn:
        init_db(conn)
    console.print("✅ 初始化完成")
    
    # 检查 sshpass 是否安装，macOS 用户需要 brew install sshpass
    try:
        result = exec("command -v sshpass", host="host", timeout=10)
        if result.returncode != 0:
            # 检查是否是 macOS
            uname_result = exec("uname -s", host="host", timeout=10)
            if uname_result.stdout.strip() == "Darwin":
                console.print("\n[yellow]⚠️  检测到您在 macOS 上运行，但未安装 sshpass。[/yellow]")
                console.print("[yellow]请运行以下命令安装：[/yellow]")
                console.print("[cyan]brew install sshpass[/cyan]")
                console.print("[yellow]安装完成后，请重新运行 sshctl init。[/yellow]")
    except Exception:
        # 如果 exec 失败，不中断初始化流程，仅提示
        pass
    
    return 0


def cmd_add(args: argparse.Namespace) -> int:
    # add 默认就是“向导模式”：按提示逐项填写
    # 如需纯参数模式（脚本化），用 --no-wizard
    wizard = not bool(getattr(args, "no_wizard", False))

    name = args.name
    host = args.host
    port = args.port
    user = args.user
    identity_file = args.identity_file
    note = args.note
    password = args.password

    if wizard or not name:
        name = _ask_required("name（别名，唯一）", default=name)
    if wizard or not host:
        host = _ask_host(default=host)
    else:
        try:
            host = _validate_host(host)
        except argparse.ArgumentTypeError as e:
            console.print(f"[red]{e}[/red]")
            return 1
    if wizard or port is None:
        port = _ask_port(default=(port or 22))
    if wizard or not user:
        user = _ask_required("user", default=(user or "root"))
    
    # 无论是否 wizard，都不再主动询问 identity_file 和 note
    # 它们仅作为命令行参数保留，不参与交互式流程
    if wizard:
        password = Prompt.ask(
            "password（登录密码，可空；不回显；保存到 DB 用于后续自动登录）",
            password=True,
            default="",
            show_default=False,
        ).strip() or None
    else:
        # 非 wizard 模式：如果用户没传 password，也直接用 None，不提示
        # 因为非 wizard 模式要求用户自己传参，不交互
        pass

    # 确保不从 args 传入的 identity_file 和 note 触发任何交互
    # 它们只是被原样传入 create_server，但不触发 Prompt.ask

    with get_conn(args.db) as conn:
        init_db(conn)
        s = create_server(
            conn,
            name=name,
            host=host,
            port=port,
            user=user,
            identity_file=identity_file,
            note=note,
            password=password,
        )
        # 按你的需求：新增后也重排一次，保证 id 从 1 连续
        reindex_server_ids(conn)

    console.print(f"✅ 已添加：{s.name} -> {s.user}@{s.host}:{s.port}")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    export_add = bool(getattr(args, "export_add", False))
    export_add_one = bool(getattr(args, "export_add_one", False))

    with get_conn(args.db) as conn:
        init_db(conn)
        rows = list_servers(conn)

    if export_add or export_add_one:
        # 生成可复制的一次性导入命令：把当前 DB 的所有服务器导出为 sshctl add --no-wizard ...
        # ⚠️ 注意：password 会以明文出现在命令里；请只在可信环境使用。
        def sh_single_quote(x: str) -> str:
            # POSIX shell 单引号转义：' 变成 '\''
            return "'" + x.replace("'", "'\\''") + "'"

        cmds: list[str] = []
        for s in rows:
            pw = (getattr(s, "password", None) or "")
            pw_part = f" --password {sh_single_quote(pw)}" if pw else ""

            cmd = (
                "sshctl add --no-wizard"
                f" --name {sh_single_quote(s.name)}"
                f" --host {sh_single_quote(s.host)}"
                f" --user {sh_single_quote(s.user)}"
                f" --port {int(s.port)}"
                f"{pw_part}"
            )
            cmds.append(cmd)

        if export_add_one:
            # 串成“一条命令”，便于一键复制粘贴执行
            # 形如：cmd1 && \
            #       cmd2 && \
            #       cmd3
            print(" && \\\n".join(cmds))
        else:
            for c in cmds:
                print(c)

        return 0

    _render_servers(rows)
    return 0


def cmd_search(args: argparse.Namespace) -> int:
    with get_conn(args.db) as conn:
        init_db(conn)
        rows = search_servers(conn, args.query)
    _render_servers(rows)
    return 0


def cmd_del(args: argparse.Namespace) -> int:
    with get_conn(args.db) as conn:
        init_db(conn)
        rows = list_servers(conn)

        target = args.target

        # 支持：del 123（按 id 删除）
        if target.isdigit():
            server_id = int(target)
            s = get_server_by_id(conn, server_id)
            if not s:
                console.print(f"⚠️ 未找到 id：{server_id}")
                return 1
            n = delete_server_by_name(conn, s.name)
            if n:
                # 按你的需求：删除后重排 id
                reindex_server_ids(conn)
                console.print(f"✅ 已删除：id={server_id} -> {s.name}（已重新编号）")
                return 0
            console.print(f"⚠️ 未找到：id={server_id} -> {s.name}")
            return 1

        # del hkk（按 name 删除）
        n = delete_server_by_name(conn, target)

    if n:
        console.print(f"✅ 已删除：{target}")
        return 0
    console.print(f"⚠️ 未找到：{target}")
    return 1


def _resolve_target_to_name(conn, target: str) -> Optional[str]:
    rows = list_servers(conn)
    if target.isdigit():
        server_id = int(target)
        s = get_server_by_id(conn, server_id)
        return s.name if s else None
    return target


def cmd_edit(args: argparse.Namespace) -> int:
    wizard = bool(getattr(args, "wizard", False))

    with get_conn(args.db) as conn:
        init_db(conn)

        name = _resolve_target_to_name(conn, args.target)
        if not name:
            console.print(f"⚠️ 未找到：{args.target}（请先 list 确认 id）")
            return 1

        existing = get_server_by_name(conn, name)
        if not existing:
            console.print(f"⚠️ 未找到：{name}")
            return 1

        host = args.host
        if host is not None:
            try:
                host = _validate_host(host)
            except argparse.ArgumentTypeError as e:
                console.print(f"[red]{e}[/red]")
                return 1
        port = args.port
        user = args.user
        identity_file = args.identity_file
        note = args.note
        password = args.password

        # wizard 模式：按提示逐项确认/修改；否则仅修改你传入的字段
        if wizard:
            host = _ask_host(default=(host or existing.host))
            port = _ask_port(default=(port if port is not None else existing.port))
            user = _ask_required("user", default=(user or existing.user))
            identity_file = _ask_optional(
                "identity_file（私钥路径，可空）",
                default=(identity_file if identity_file is not None else (existing.identity_file or "")),
            )
            password = Prompt.ask(
                "password（登录密码；留空表示不修改；输入 '-' 表示清空）",
                password=True,
                default="",
                show_default=False,
            ).strip() or None
            note = _ask_optional(
                "note（备注，可空）",
                default=(note if note is not None else (existing.note or "")),
            )

        if password is not None:
            if password == "-":
                password = ""

        s = update_server_by_name(
            conn,
            name,
            host=host,
            port=port,
            user=user,
            identity_file=identity_file,
            note=note,
            password=password,
        )

    assert s is not None
    console.print(f"✅ 已更新：{s.name} -> {s.user}@{s.host}:{s.port}")
    return 0


def cmd_ssh(args: argparse.Namespace) -> int:
    target = getattr(args, "target", None)
    no_save_password = bool(getattr(args, "no_save_password", False))

    with get_conn(args.db) as conn:
        init_db(conn)

        rows = list_servers(conn)

        # 不传参数：进入选择模式（按 id 更稳定）
        if not target:
            if rows:
                console.print("\n当前数据库中的服务器：")
                _render_servers(rows)
                target = _ask_select_server(rows)
            else:
                console.print("\n数据库里还没有服务器记录。请先 add 添加服务器。")
                return 1

        # 传了 target：支持 id 或 name
        server = None
        if target.isdigit():
            server_id = int(target)
            server = get_server_by_id(conn, server_id)
            if not server:
                console.print(f"[red]未找到 id：{server_id}[/red]")
                return 1
        else:
            server = get_server_by_name(conn, target)

        if not server:
            console.print(f"[red]未找到：{target}[/red]")
            return 1

        # 重要说明：无法截获你在 ssh 自己弹出来的 password 提示里输入的密码。
        # 如果想“输入一次并保存到 DB”，必须由 sshctl 在连接前主动询问密码。
        pw_to_save: Optional[str] = None
        if not server.has_password:
            pw = Prompt.ask(
                "该服务器未保存密码，请输入登录密码（不会回显；留空则改为手动输入）",
                password=True,
                default="",
                show_default=False,
            ).strip()

            if pw:
                # 临时使用该密码进行本次连接（通过 sshpass）
                server = replace(server, password=pw)

                if not no_save_password:
                    # 默认：保存到 DB（按你的需求）
                    pw_to_save = pw

    # 连接（可能会进入交互 session，直到你退出）
    rc = run_ssh(server)

    # 仅当 ssh 正常退出且需要保存时才写入 DB
    if pw_to_save:
        if rc == 0:
            with get_conn(args.db) as conn:
                init_db(conn)
                update_server_by_name(conn, server.name, password=pw_to_save)
            console.print("✅ 已保存密码到数据库（list 中不会显示明文）")
        else:
            console.print("⚠️ 本次连接未成功结束（或认证失败），未保存密码。")

    return rc


def _find_subparsers_action(parser: argparse.ArgumentParser) -> Optional[argparse._SubParsersAction]:
    for a in parser._actions:
        if isinstance(a, argparse._SubParsersAction):
            return a
    return None


def cmd_help(args: argparse.Namespace) -> int:
    parser = build_parser()

    topic = getattr(args, "topic", None)
    if not topic:
        console.print(parser.format_help())
        console.print("\n用法示例：sshctl help add / sshctl help ssh")
        return 0

    sub_action = _find_subparsers_action(parser)
    if not sub_action or topic not in sub_action.choices:
        console.print(f"⚠️ 未知命令：{topic}\n")
        console.print(parser.format_help())
        return 1

    console.print(sub_action.choices[topic].format_help())
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="sshctl",
        description=(
            "用途：\n"
            "  sshctl：用 SQLite 管理 SSH 服务器清单，并一键 ssh 连接（不读取 ~/.ssh/config）\n"
            "\n"
            "保存字段（每台服务器一条记录）：\n"
            "  - name（别名，唯一）\n"
            "  - host(IP) / user / port（可选）\n"
            "  - password（可选：明文写入 DB；list 不显示明文）\n"
            "\n"
            "常用（交互式）：\n"
            "  1) sshctl init\n"
            "  2) sshctl add\n"
            "  3) sshctl list\n"
            "  4) sshctl ssh <id>\n"
            "\n"
            "常用（一次性命令添加）：\n"
            "  sshctl add --no-wizard --name xxx --host 1.2.3.4 --user root --port 22 --password '你的密码'\n"
            "\n"
            "迁移到其他电脑（导出一整块可一次复制执行的命令）：\n"
            "  sshctl list --export-add-one\n"
            "\n"
            "提示：sshctl ssh <id> 如果该条未保存 password，会提示输入并默认保存（明文，谨慎使用）。\n"
            "查看子命令帮助：sshctl help add / sshctl help ssh / sshctl help list"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("--version", action="version", version=f"sshctl {__version__}")
    # 把 --version 的默认英文 help 改成中文
    for a in p._actions:
        if getattr(a, "option_strings", None) and "--version" in a.option_strings:
            a.help = "显示版本并退出"
            break
    p.add_argument(
        "--db",
        type=Path,
        default=None,
        help="自定义数据库路径（默认：~/.local/share/sshctl/servers.db；兼容旧路径 sshctl）",
    )

    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("help", help="显示帮助（也可用 -h/--help）")
    sp.add_argument("topic", nargs="?", default=None, help="子命令名，例如 add/list/ssh/edit")
    sp.set_defaults(func=cmd_help)

    sp = sub.add_parser("init", help="初始化数据库")
    sp.set_defaults(func=cmd_init)

    sp = sub.add_parser("add", help="添加服务器（默认进入向导；按提示逐项填写）")
    sp.add_argument(
        "--no-wizard",
        action="store_true",
        help="不进入向导，完全使用命令行参数（适合脚本/熟练用户）",
    )
    sp.add_argument("--name", required=False, help="别名（唯一）")
    sp.add_argument("--host", required=False, help="IP 或域名")
    sp.add_argument("--port", type=_validate_port, default=None)
    sp.add_argument("--user", default=None)
    # identity_file 和 note 已从向导中移除，仅保留为高级命令行参数
    sp.add_argument("--identity-file", default=None, help="[高级] 私钥路径（仅限命令行模式，不用于向导）")
    sp.add_argument("--password", default=None, help="登录密码（不推荐明文传参；建议用 --wizard 输入）")
    sp.add_argument("--note", default=None, help="[高级] 备注（仅限命令行模式，不用于向导）")
    sp.set_defaults(func=cmd_add)

    sp = sub.add_parser("list", help="列出所有服务器")
    sp.add_argument(
        "--export-add",
        action="store_true",
        help="导出为可复制的一次性添加命令（sshctl add --no-wizard ...），用于迁移到其他电脑（会包含明文 password）",
    )
    sp.add_argument(
        "--export-add-one",
        action="store_true",
        help="把所有 add 命令用 ' && \' 换行串成一条命令，复制一次即可执行",
    )
    sp.set_defaults(func=cmd_list)

    sp = sub.add_parser("search", help="按关键字搜索（name/host/user/note）")
    sp.add_argument("query")
    sp.set_defaults(func=cmd_search)

    sp = sub.add_parser("del", help="删除服务器（支持用 id 或 name）")
    sp.add_argument("target", help="服务器 id 或 name")
    sp.set_defaults(func=cmd_del)

    sp = sub.add_parser("edit", help="修改服务器（支持用 id 或 name；支持交互式提示）")
    sp.add_argument("target", help="服务器 id 或 name")
    sp.add_argument("--wizard", action="store_true", help="进入交互式向导，按提示逐项修改")
    sp.add_argument("--host", default=None)
    sp.add_argument("--port", type=_validate_port, default=None)
    sp.add_argument("--user", default=None)
    sp.add_argument("--identity-file", default=None)
    sp.add_argument("--password", default=None, help="登录密码（留空不修改；传 '-' 表示清空）")
    sp.add_argument("--note", default=None)
    sp.set_defaults(func=cmd_edit)

    sp = sub.add_parser(
        "ssh",
        help="连接服务器：仅使用数据库记录（不读取 ~/.ssh/config；可用 id 或 name）",
    )
    sp.add_argument("target", nargs="?", default=None, help="服务器 id 或 name（不填则进入选择模式）")
    sp.add_argument(
        "--no-save-password",
        action="store_true",
        help="当该服务器未保存密码时，不自动保存到数据库（默认会保存）",
    )
    sp.set_defaults(func=cmd_ssh)

    return p


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()

    # 约定：如果只输入 sshctl（不带任何参数），等同于 sshctl -h
    # argparse 默认会报“缺少子命令”，这里主动改成显示帮助。
    if argv is None:
        argv = sys.argv[1:]
    if len(argv) == 0:
        parser.print_help()
        return 0

    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
