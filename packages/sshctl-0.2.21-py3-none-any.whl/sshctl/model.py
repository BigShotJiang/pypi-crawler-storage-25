from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Server:
    id: int
    name: str
    host: str
    port: int
    user: str
    identity_file: Optional[str]
    note: Optional[str]

    # 明文保存的 SSH 密码（可选）。
    # 注意：sshctl 不会在 list 中显示明文密码。
    password: Optional[str] = None

    @property
    def has_password(self) -> bool:
        return bool(self.password)
