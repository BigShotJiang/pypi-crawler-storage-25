from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional

APP_NAME = "sshctl"
LEGACY_APP_NAME = "sshcli"  # 仅用于兼容旧数据库路径


def default_db_path() -> Path:
    """默认数据库路径。

    新默认：~/.local/share/sshctl/servers.db
    兼容：如果旧路径 ~/.local/share/sshctl/servers.db 已存在且新路径不存在，则继续使用旧路径。
    """

    base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))

    new_path = base / APP_NAME / "servers.db"
    legacy_path = base / LEGACY_APP_NAME / "servers.db"

    if (not new_path.exists()) and legacy_path.exists():
        return legacy_path

    return new_path


def connect(db_path: Optional[Path] = None) -> sqlite3.Connection:
    path = Path(db_path) if db_path else default_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def get_conn(db_path: Optional[Path] = None) -> Iterator[sqlite3.Connection]:
    conn = connect(db_path)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(conn: sqlite3.Connection) -> None:
    # schema
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS servers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            host TEXT NOT NULL,
            port INTEGER NOT NULL DEFAULT 22,
            user TEXT NOT NULL DEFAULT 'root',
            identity_file TEXT,
            note TEXT,

            -- 明文保存的密码（可选；不建议在多人机器/共享环境使用）
            password TEXT,

            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """
    )

    # 兼容老库：如果是旧表结构，补齐新增列（不会丢数据）
    cols = {r[1] for r in conn.execute("PRAGMA table_info(servers)").fetchall()}
    if "password" not in cols:
        conn.execute("ALTER TABLE servers ADD COLUMN password TEXT")

    conn.execute(
        """
        CREATE TRIGGER IF NOT EXISTS trg_servers_updated_at
        AFTER UPDATE ON servers
        FOR EACH ROW
        BEGIN
            UPDATE servers SET updated_at = datetime('now') WHERE id = OLD.id;
        END;
        """
    )


def reindex_server_ids(conn: sqlite3.Connection) -> None:
    """把 servers.id 重新编号为 1..N（按当前 id 升序）。

    说明：
    - SQLite 的 AUTOINCREMENT/自增策略不会因为你删除记录就“回收”编号，所以会出现 id 从 2/3 开始。
    - 你希望 id 永远从 1 开始且删除后无空洞，这里就对主键做重排。
    - ⚠️ 注意：重排会改变已有记录的 id，所以如果你把 id 记在别处（脚本/文档），会失效。
    """

    rows = conn.execute("SELECT id FROM servers ORDER BY id").fetchall()
    old_ids = [int(r[0]) for r in rows]

    # 先临时改成负数，避免主键冲突
    for old in old_ids:
        conn.execute("UPDATE servers SET id = ? WHERE id = ?", (-old, old))

    # 再按顺序写回 1..N
    for new_id, old in enumerate(old_ids, start=1):
        conn.execute("UPDATE servers SET id = ? WHERE id = ?", (new_id, -old))

    # 同步 sqlite_sequence（若存在），避免下一次插入跳号
    seq_exists = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='sqlite_sequence'"
    ).fetchone()

    if seq_exists is not None:
        n = len(old_ids)
        if n == 0:
            conn.execute("DELETE FROM sqlite_sequence WHERE name = 'servers'")
        else:
            updated = conn.execute(
                "UPDATE sqlite_sequence SET seq = ? WHERE name = 'servers'", (n,)
            ).rowcount
            if updated == 0:
                conn.execute("INSERT INTO sqlite_sequence(name, seq) VALUES('servers', ?)", (n,))
