from caronashow.poc.v1 import groups_pb2 as _groups_pb2
from caronashow.poc.v1 import points_pb2 as _points_pb2
from caronashow.poc.v1 import routes_pb2 as _routes_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Dataset(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DATASET_UNSPECIFIED: _ClassVar[Dataset]
    DATASET_ATLANTA_10: _ClassVar[Dataset]
    DATASET_ATLANTA_25: _ClassVar[Dataset]
    DATASET_ATLANTA_50: _ClassVar[Dataset]
DATASET_UNSPECIFIED: Dataset
DATASET_ATLANTA_10: Dataset
DATASET_ATLANTA_25: Dataset
DATASET_ATLANTA_50: Dataset

class GetMapPointsRequest(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: Dataset
    def __init__(self, dataset: _Optional[_Union[Dataset, str]] = ...) -> None: ...

class GetMapPointsResponse(_message.Message):
    __slots__ = ("passengers", "drivers", "organization")
    PASSENGERS_FIELD_NUMBER: _ClassVar[int]
    DRIVERS_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_FIELD_NUMBER: _ClassVar[int]
    passengers: _containers.RepeatedCompositeFieldContainer[_points_pb2.PassengerPoint]
    drivers: _containers.RepeatedCompositeFieldContainer[_points_pb2.DriverPoint]
    organization: _points_pb2.OrganizationPoint
    def __init__(self, passengers: _Optional[_Iterable[_Union[_points_pb2.PassengerPoint, _Mapping]]] = ..., drivers: _Optional[_Iterable[_Union[_points_pb2.DriverPoint, _Mapping]]] = ..., organization: _Optional[_Union[_points_pb2.OrganizationPoint, _Mapping]] = ...) -> None: ...

class GetDirectRoutesRequest(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: Dataset
    def __init__(self, dataset: _Optional[_Union[Dataset, str]] = ...) -> None: ...

class GetDirectRoutesResponse(_message.Message):
    __slots__ = ("routes",)
    ROUTES_FIELD_NUMBER: _ClassVar[int]
    routes: _containers.RepeatedCompositeFieldContainer[_routes_pb2.DirectRoute]
    def __init__(self, routes: _Optional[_Iterable[_Union[_routes_pb2.DirectRoute, _Mapping]]] = ...) -> None: ...

class GetMapPointGroupsRequest(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: Dataset
    def __init__(self, dataset: _Optional[_Union[Dataset, str]] = ...) -> None: ...

class GetMapPointGroupsResponse(_message.Message):
    __slots__ = ("groups",)
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    groups: _containers.RepeatedCompositeFieldContainer[_groups_pb2.MatchGroup]
    def __init__(self, groups: _Optional[_Iterable[_Union[_groups_pb2.MatchGroup, _Mapping]]] = ...) -> None: ...

class GetOptimizedRoutesRequest(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: Dataset
    def __init__(self, dataset: _Optional[_Union[Dataset, str]] = ...) -> None: ...

class GetOptimizedRoutesResponse(_message.Message):
    __slots__ = ("routes",)
    ROUTES_FIELD_NUMBER: _ClassVar[int]
    routes: _containers.RepeatedCompositeFieldContainer[_routes_pb2.DirectRoute]
    def __init__(self, routes: _Optional[_Iterable[_Union[_routes_pb2.DirectRoute, _Mapping]]] = ...) -> None: ...
