"""
Version information for the application_sdk package.
"""

__version__ = "3.3.0"
