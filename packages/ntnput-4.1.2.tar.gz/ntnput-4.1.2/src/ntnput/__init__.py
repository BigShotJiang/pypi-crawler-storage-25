# +-------------------------------------+
# |         ~ Author : Xenely ~         |
# +=====================================+
# | GitHub: https://github.com/Xenely14 |
# | Discord: xenely                     |
# +-------------------------------------+

import time
import random
import typing
import ctypes
import contextlib

# Local imports
from . import misc

# ==-------------------------------------------------------------------== #
# Global and static variables, constants                                  #
# ==-------------------------------------------------------------------== #
LEFT_DOWN = 0x02
LEFT_UP = 0x04
RIGHT_DOWN = 0x10
RIGHT_UP = 0x08
MIDDLE_DOWN = 0x20
MIDDLE_UP = 0x40

KEY_DOWN = 0x00
KEY_UP = 0x02

# Syscall wrapper
syscall_wrapper = misc.DirectSyscallWrapper()

# English layout keycodes
en_layout_keycodes = {
    "q": 0x51, "w": 0x57, "e": 0x45, "r": 0x52,
    "t": 0x54, "y": 0x59, "u": 0x55, "i": 0x49,
    "o": 0x4F, "p": 0x50, "a": 0x41, "s": 0x53,
    "d": 0x44, "f": 0x46, "g": 0x47, "h": 0x48,
    "j": 0x4A, "k": 0x4B, "l": 0x4C, "z": 0x5A,
    "x": 0x58, "c": 0x43, "v": 0x56, "b": 0x42,
    "n": 0x4E, "m": 0x4D

}

# Russian layout keycodes
ru_layout_keycodes = {
    "ё": 0xC0, "й": 0x51, "ц": 0x57, "у": 0x45,
    "к": 0x52, "е": 0x54, "н": 0x59, "г": 0x55,
    "ш": 0x49, "щ": 0x4F, "з": 0x50, "х": 0xDB,
    "ъ": 0xDD, "ф": 0x41, "ы": 0x53, "в": 0x44,
    "а": 0x46, "п": 0x47, "р": 0x48, "о": 0x4A,
    "л": 0x4B, "д": 0x4C, "ж": 0xBA, "э": 0xDE,
    "я": 0x5A, "ч": 0x58, "с": 0x43, "м": 0x56,
    "и": 0x42, "т": 0x4E, "ь": 0x4D, "б": 0xBC,
    "ю": 0xBE
}

# Special non-shifted characters keycodes
universal_chars_nonshift_keycodes = {
    "tab": 0x09, "alt": 0x12, "win": 0x5B, "end": 0x23,
    "esc": 0x1B, "home": 0x24, "ctrl": 0x11, "caps": 0x14,
    "space": 0x20, "pause": 0x13, "insert": 0x2D, "delete": 0x2E,
    "enter": 0x0D, "shift": 0x10, "print": 0x9A, "scroll": 0x91,
    "pageup": 0x21, "pagedown": 0x22,

    # Numlock keys
    "num0": 0x60, "num1": 0x61, "num2": 0x62, "num3": 0x63,
    "num4": 0x64, "num5": 0x65, "num6": 0x66, "num7": 0x67,
    "num8": 0x68, "num9": 0x69, "num*": 0x6A, "num+": 0x6B,
    "num-": 0x6D, "num.": 0x6E, "num/": 0x6F, "numlock": 0x90,

    # Functional keys
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73,
    "f5": 0x74, "f6": 0x75, "f7": 0x76, "f8": 0x77,
    "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,

    # Digits keys
    "0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33,
    "4": 0x34, "5": 0x35, "6": 0x36, "7": 0x37,
    "8": 0x38, "9": 0x39,

    # Arrow keyc
    "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,

    # Misc keys
    "-": 0xBD, "=": 0xBB, "\\": 0xDC, " ": 0x20,
}

# Special shifted english layout characters keycodes
en_chars_shifted_keycodes = {
    '"': 0xDE, "<": 0xBC, ">": 0xBE, "?": 0xBF,
    "{": 0xDB, "}": 0xDD, "~": 0xC0, ":": 0xBA,
    "|": 0xDC, "!": 0x31, "@": 0x32, "#": 0x33,
    "$": 0x34, "%": 0x35, "^": 0x36, "&": 0x37,
    "*": 0x38, "(": 0x39, ")": 0x30, "_": 0xBD,
    "+": 0xBB,
}

# Special non-shifted english layout characters keycodes
en_chars_nonshifted_keycodes = {
    "'": 0xDE, ",": 0xBC, ".": 0xBE, "/": 0xBF,
    "[": 0xDB, "]": 0xDD, "`": 0xC0, ";": 0xBA,
}

# Keycodes dict
keycodes = {}

# Filling keycodes with letters
keycodes |= {key: {"code": value, "layout": "ru", "is_capital": False} for key, value in ru_layout_keycodes.items()}
keycodes |= {key: {"code": value, "layout": "en", "is_capital": False} for key, value in en_layout_keycodes.items()}

# Filling keycodes with upper letters
keycodes |= {key.upper(): value.copy() | {"is_capital": True} for key, value in keycodes.items() if len(key) == 1 and key.upper() != key}

# Saving letters dict
letters = keycodes.copy()

# Filling keycodes with special chars
keycodes |= {key: {"code": value, "layout": "en", "is_capital": True} for key, value in en_chars_shifted_keycodes.items()}
keycodes |= {key: {"code": value, "layout": "en", "is_capital": False} for key, value in en_chars_nonshifted_keycodes.items()}
keycodes |= {key: {"code": value, "layout": None, "is_capital": False} for key, value in universal_chars_nonshift_keycodes.items()}


# ==-------------------------------------------------------------------== #
# С-structures                                                            #
# ==-------------------------------------------------------------------== #
class DevMod(ctypes.Structure):
    """Structure containing information about display."""

    _fields_ = [
        ("dmDeviceName", ctypes.c_wchar * 32),
        ("dmSpecVersion", ctypes.c_ushort),
        ("dmDriverVersion", ctypes.c_ushort),
        ("dmSize", ctypes.c_ushort),
        ("dmDriverExtra", ctypes.c_ushort),
        ("dmFields", ctypes.c_ulong),
        ("dmPositionX", ctypes.c_long),
        ("dmPositionY", ctypes.c_long),
        ("dmDisplayOrientation", ctypes.c_ulong),
        ("dmDisplayFixedOutput", ctypes.c_ulong),
        ("dmColor", ctypes.c_short),
        ("dmDuplex", ctypes.c_short),
        ("dmYResolution", ctypes.c_short),
        ("dmTTOption", ctypes.c_short),
        ("dmCollate", ctypes.c_short),
        ("dmFormName", ctypes.c_wchar * 32),
        ("dmLogPixels", ctypes.c_ushort),
        ("dmBitsPerPel", ctypes.c_ulong),
        ("dmPelsWidth", ctypes.c_ulong),
        ("dmPelsHeight", ctypes.c_ulong),
    ]


class InjectInputMouseInfo(ctypes.Structure):
    """Structure containing information about mouse input injection."""

    _fields_ = [
        ("x_direction", ctypes.c_int),
        ("y_direction", ctypes.c_int),
        ("mouse_data", ctypes.c_uint),
        ("mouse_options", ctypes.c_int),
        ("time_offset_in_miliseconds", ctypes.c_uint),
        ("extra_info", ctypes.c_void_p),
    ]


class InjectInputKeyboardInfo(ctypes.Structure):
    """Structure containing information about keyboard input injection."""

    _fields_ = [
        ("vk_code", ctypes.c_ushort),
        ("scan_code", ctypes.c_ushort),
        ("dw_flags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("extra_info", ctypes.c_void_p),
    ]


class Point(ctypes.Structure):
    """Structure containing information about 2D point."""

    _fields_ = [
        ("x", ctypes.c_long),
        ("y", ctypes.c_long),
    ]


# ==-------------------------------------------------------------------== #
# Wrapped syscall functions                                               #
# ==-------------------------------------------------------------------== #
_NtUserInjectMouseInput = syscall_wrapper.wrap("NtUserInjectMouseInput", result_type=ctypes.c_ulong, arguments_types=[ctypes.POINTER(InjectInputMouseInfo), ctypes.c_int], search_module=b"win32u.dll")
_NtUserInjectKeyboardInput = syscall_wrapper.wrap("NtUserInjectKeyboardInput", result_type=ctypes.c_ulong, arguments_types=[ctypes.POINTER(InjectInputKeyboardInfo), ctypes.c_int], search_module=b"win32u.dll")


# ==-------------------------------------------------------------------== #
# Functions                                                               #
# ==-------------------------------------------------------------------== #
def wind_mouse_wrap(start_x: int, start_y: int, destination_x: int, destination_y: int, callback: typing.Callable[[int, int], None], wind_power: float = 3, wind_gravity: float = 10, wind_max_speed: float = 15, wind_fade_length: float = 18) -> None:
    """Wrap `WindMouse` alghoritm, calls given callback, passing position to move to it."""

    # Values used to generate more natural wind variation
    sqrt3 = 3 ** 0.3
    sqrt5 = 5 ** 0.5

    # Current X, Y cursor position
    current_x = start_x
    current_y = start_y

    # Wind and velocity offsets
    wind_x = wind_y = 0.0
    velocity_x = velocity_y = 0.0

    while True:

        # Vector to destination
        delta_x = destination_x - current_x
        delta_y = destination_y - current_y

        # Distance to destination
        distance = (delta_x ** 2 + delta_y ** 2) ** 0.5

        # Reached destination (close enough)
        if distance < 1:
            break

        # Limit wind strength by current distance
        wind_magnitude = min(wind_power, distance)

        # If far from target more chaotic wind
        if distance >= wind_fade_length:

            wind_x = wind_x / sqrt3 + (random.random() * 2 - 1) * wind_magnitude / sqrt5
            wind_y = wind_y / sqrt3 + (random.random() * 2 - 1) * wind_magnitude / sqrt5

        # If close to target wind decays quickly
        else:

            wind_x /= sqrt3
            wind_y /= sqrt3

            # If max step speed is too low - give it a small random boost
            if wind_max_speed < 3:
                wind_max_speed = random.random() * 3 + 3

            else:
                wind_max_speed /= sqrt5

        # Gravity pulls towards the target
        velocity_x += wind_x + wind_gravity * delta_x / distance
        velocity_y += wind_y + wind_gravity * delta_y / distance

        # Limit overall movement speed
        velocity_magnitude = (velocity_x ** 2 + velocity_y ** 2) ** 0.5

        # Limit overall movement speed
        if velocity_magnitude > wind_max_speed:

            # Clip speed to magnitude
            clip_speed = wind_max_speed / 2 + random.random() * wind_max_speed / 2

            # Normalize velocity vector
            velocity_x = (velocity_x / velocity_magnitude) * clip_speed
            velocity_y = (velocity_y / velocity_magnitude) * clip_speed

        # Update current position
        current_x += velocity_x
        current_y += velocity_y

        # Round to integer pixels (what will actually be sent to the system)
        move_x = round(current_x)
        move_y = round(current_y)

        # Call callback only when the integer coordinate actually changes
        if move_x != int(current_x - velocity_x) or move_y != int(current_y - velocity_y):
            callback(move_x, move_y)

    # Final corecting move
    callback(destination_x, destination_y)


def change_keyboard_layout(language_code_or_id: str | int, delay: int | float) -> None:
    """Changes keyboard layout using passed language code or ID."""

    # Language keycodes IDs
    language_codes = {
        "en": 0x409,
        "ru": 0x419
    }

    # If code was passes as an argument
    if isinstance(language_code_or_id, str):

        # If keycode is unknown
        if (language_code := language_codes.get(language_code_or_id.lower().strip())) is None:
            raise Exception("Unable to find code for `%s` language, use language ID instead" % language_code_or_id)

        # Set up language ID
        language_code_or_id = language_code

    # Getting thread of active window
    current_thread = ctypes.windll.user32.GetWindowThreadProcessId(current_hwid := ctypes.windll.user32.GetForegroundWindow(), None)

    # If required language already set
    if ctypes.windll.user32.GetKeyboardLayout(current_thread) & 0xFFFF == language_code_or_id:
        return

    # Change keybord layout
    if not ctypes.windll.user32.PostMessageA(current_hwid, 0x50, 0, language_code_or_id):
        raise Exception("Unable to change keybord layout using `0x%s` code" % hex(language_code_or_id)[2:])

    # Change layout delay
    time.sleep(delay)


# ==-------------------------------------------------------------------== #
# Classes                                                                 #
# ==-------------------------------------------------------------------== #
class InputController:
    """Class to manipulate mouse and keyboard using wrapped syscalls functions."""

    # ==-------------------------------------------------------------------== #
    # Public methods                                                          #
    # ==-------------------------------------------------------------------== #
    def __init__(
            self,
            keyboard_layout_delay: int | float = 0.05,
            keyboard_clicks_delay: int | float | tuple[int | float, int | float] = (0.01, 0.02),

            mouse_spread: tuple[int, int] = (3, 3),
            mouse_moves_delay: int | float | tuple[int | float, int | float] = (0.04, 0.05),
            mouse_clicks_delay: int | float | tuple[int | float, int | float] = (0.01, 0.02),

            mouse_wind_moves_delay: int | float | tuple[int | float, int | float] = (0.0006, 0.0008),
            mouse_wind_moves_post_delay: int | float | tuple[int | float, int | float] = (0.04, 0.05),

            wind_power: int | float = 3,
            wind_gravity: int | float = 10,
            wind_max_speed: int | float = 10,
            wind_fade_length: int | float = 15,
    ) -> None:
        """Creates instance to manipulate mouse and keyboard using warpped syscall functions."""

        # Save initializer arguments as attributes
        self.keyboard_layout_delay = keyboard_layout_delay
        self.keyboard_clicks_delay = keyboard_clicks_delay

        self.mouse_spread = mouse_spread
        self.mouse_moves_delay = mouse_moves_delay
        self.mouse_clicks_delay = mouse_clicks_delay

        self.mouse_wind_moves_delay = mouse_wind_moves_delay
        self.mouse_wind_moves_post_delay = mouse_wind_moves_post_delay

        self.wind_power = wind_power
        self.wind_gravity = wind_gravity
        self.wind_max_speed = wind_max_speed
        self.wind_fade_length = wind_fade_length

        # Set DPI awareness to prevent position missmatch due window scaling
        ctypes.windll.shcore.SetProcessDpiAwareness(1)

    def get_mouse_position(self) -> tuple[int, int]:
        """Gets mouse absolute current position."""

        # Get current mouse position and save it into pointer
        if not (ctypes.windll.user32.GetCursorPos(ctypes.byref(point := Point()))):
            raise Exception("Unable to retrieve current mouse position")

        return point.x, point.y

    def mouse_move(self, x: int, y: int, x_spread: int | None = None, y_spread: int | None = None, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Moves mouse relative to it's current position using wrapped syscall `NtUserInjectMouseInput` function."""

        # Get mouse spread
        mouse_spread = [item for item in self.mouse_spread]

        # If override spraed defined
        if x_spread is not None:
            mouse_spread[0] = x_spread

        if y_spread is not None:
            mouse_spread[1] = y_spread

        # Retrieve mouse spread
        mouse_spread = self.__get_spread(mouse_spread)

        # Moving mouse
        _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(x_direction=x + mouse_spread[0], y_direction=y + mouse_spread[1])), 1)

        # Post move delay
        time.sleep(self.__get_delay(delay if delay is not None else self.mouse_moves_delay))

    def mouse_move_to(self, x: int, y: int, x_spread: int | None = None, y_spread: int | None = None, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Moves mouse by absolute coordinate position using wrapped syscall `NtUserInjectMouseInput` function."""

        # If unable to retrieve display information
        if not ctypes.windll.user32.EnumDisplaySettingsW(None, 0xFFFFFFFF, ctypes.byref(devmode := DevMod(
            dmSize=ctypes.sizeof(DevMod),
            dmField=0x00040000 | 0x00080000,
        ))):
            raise Exception("Unable to retrieve physical display resolution")

        # Get mouse spread
        mouse_spread = [item for item in self.mouse_spread]

        # If override spraed defined
        if x_spread is not None:
            mouse_spread[0] = x_spread

        if y_spread is not None:
            mouse_spread[1] = y_spread

        # Retrieve mouse spread
        mouse_spread = self.__get_spread(mouse_spread)

        # Normalizing coordinates
        normalized_x = int(((x + mouse_spread[0]) * 65_536) / devmode.dmPelsWidth)
        normalized_y = int(((y + mouse_spread[1]) * 65_536) / devmode.dmPelsHeight)

        # Moving mouse
        _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(x_direction=normalized_x, y_direction=normalized_y, mouse_options=0x8000 | 0x0001)), 1)

        # Post move delay
        time.sleep(self.__get_delay(delay if delay is not None else self.mouse_moves_delay))

    def mouse_wind_move(self, x: int, y: int, x_spread: int | None = None, y_spread: int | None = None, delay: int | float | tuple[int | float, int | float] | None = None, **wind_kwargs: int | float) -> None:
        """Moves mouse relative to it's current position using wrapped syscall `NtUserInjectMouseInput` function and `WindMouse` alghoritm for humanization."""

        # Get mouse position
        current_mouse_position = self.get_mouse_position()

        # Get mouse spread
        mouse_spread = [item for item in self.mouse_spread]

        # If override spraed defined
        if x_spread is not None:
            mouse_spread[0] = x_spread

        if y_spread is not None:
            mouse_spread[1] = y_spread

        # Retrieve mouse spread
        mouse_spread = self.__get_spread(mouse_spread)

        # Get destination mouse position
        destination_position = [
            x + current_mouse_position[0] + mouse_spread[0],
            y + current_mouse_position[1] + mouse_spread[1],
        ]

        # Moving mouse using `WindMouse` wrapper
        wind_mouse_wrap(
            *current_mouse_position,
            *destination_position,
            lambda x, y: self.mouse_move_to(x, y, x_spread=0, y_spread=0, delay=self.__get_delay(delay if delay is not None else self.mouse_wind_moves_delay)),
            **{
                key: value for key, value in self.__dict__.items()
                if key.startswith("wind")
            } | wind_kwargs
        )

        # Post move delay
        time.sleep(self.__get_delay(delay if delay is not None else self.mouse_wind_moves_post_delay))

    def mouse_wind_move_to(self, x: int, y: int, x_spread: int | None = None, y_spread: int | None = None, delay: int | float | tuple[int | float, int | float] | None = None, **wind_kwargs: int | float) -> None:
        """Moves mouse by absolute coordinate position using wrapped syscall `NtUserInjectMouseInput` function and `WindMouse` alghoritm for humanization."""

        # Get mouse spread
        mouse_spread = [item for item in self.mouse_spread]

        # If override spraed defined
        if x_spread is not None:
            mouse_spread[0] = x_spread

        if y_spread is not None:
            mouse_spread[1] = y_spread

        # Retrieve mouse spread
        mouse_spread = self.__get_spread(mouse_spread)

        # Get destination mouse position
        destination_position = [
            x + mouse_spread[0],
            y + mouse_spread[1],
        ]

        # Moving mouse using `WindMouse` wrapper
        wind_mouse_wrap(
            *self.get_mouse_position(),
            *destination_position,
            lambda x, y: self.mouse_move_to(x, y, x_spread=0, y_spread=0, delay=self.__get_delay(delay if delay is not None else self.mouse_wind_moves_delay)),
            **{
                key: value for key, value in self.__dict__.items()
                if key.startswith("wind")
            } | wind_kwargs
        )

        # Post move delay
        time.sleep(self.__get_delay(delay if delay is not None else self.mouse_wind_moves_post_delay))

    def mouse_click(self, button: typing.Literal["left", "right", "middle"] = "left", delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Clicks mouse using wrapped syscall `NtUserInjectMouseInput` function."""

        # If button literal is not allowed
        if button not in (allowed_literals := typing.get_args(self.mouse_click.__annotations__["button"])):
            raise Exception("Button literal is invalid, expected one of: `%s`" % ", ".join(allowed_literals))

        # Clicking mouse
        match button:

            case "left": _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(mouse_options=LEFT_DOWN)), 1)
            case "right": _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(mouse_options=RIGHT_DOWN)), 1)
            case "middle": _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(mouse_options=MIDDLE_DOWN)), 1)

        # Post click delay
        time.sleep(self.__get_delay(delay if delay is not None else self.mouse_clicks_delay))

    def mouse_release(self, button: typing.Literal["left", "right", "middle"] = "left", delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Releases mouse using wrapped syscall `NtUserInjectMouseInput` function."""

        # If button literal is not allowed
        if button not in (allowed_literals := typing.get_args(self.mouse_release.__annotations__["button"])):
            raise Exception("Button literal is invalid, expected one of: `%s`" % ", ".join(allowed_literals))

        # Releasing mouse
        match button:

            case "left": _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(mouse_options=LEFT_UP)), 1)
            case "right": _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(mouse_options=RIGHT_UP)), 1)
            case "middle": _NtUserInjectMouseInput(ctypes.byref(InjectInputMouseInfo(mouse_options=MIDDLE_UP)), 1)

        # Post release delay
        time.sleep(self.__get_delay(delay if delay is not None else self.mouse_clicks_delay))

    def mouse_click_and_release(self, button: typing.Literal["left", "right", "middle"] = "left", times: int = 1, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Clicks mouse and releases after given delay time passed in milliseconds using wrapped syscall `NtUserInjectMouseInput` function."""

        # If times is invalid
        if times < 1:
            return

        # If button literal is not allowed
        if button not in (allowed_literals := typing.get_args(self.mouse_release.__annotations__["button"])):
            raise Exception("Button literal is invalid, expected one of: `%s`" % ", ".join(allowed_literals))

        # Click given times
        for _ in range(times):

            # Mouse clicking and releasing
            self.mouse_click(button, delay=self.__get_delay(delay if delay is not None else self.mouse_clicks_delay)), self.mouse_release(button, delay=0)

    def keyboard_press(self, key: str, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Presses keyboard key using wrapped syscall `NtUserInjectKeyboardInput` function."""

        # If key is not string
        if not isinstance(key, str):
            return

        # If key is invalid
        if (key_info := keycodes.get(key.lower())) is None:
            return

        # Pressing keyboard key
        _NtUserInjectKeyboardInput(ctypes.byref(InjectInputKeyboardInfo(vk_code=key_info["code"], dw_flags=KEY_DOWN)), 1)

        # Post press delay
        time.sleep(self.__get_delay(delay if delay is not None else self.keyboard_clicks_delay))

    def keyboard_release(self, key: str, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Releases keyboard key using wrapped syscall `NtUserInjectKeyboardInput` function."""

        # If key is not string
        if not isinstance(key, str):
            return

        # If key is invalid
        if (key_info := keycodes.get(key.lower())) is None:
            return

        # Releasing keyboard key
        _NtUserInjectKeyboardInput(ctypes.byref(InjectInputKeyboardInfo(vk_code=key_info["code"], dw_flags=KEY_UP)), 1)

        # Post release delay
        time.sleep(self.__get_delay(delay if delay is not None else self.keyboard_clicks_delay))

    def keyboard_press_and_release(self, key: str, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Presses keyboard key and releases after given delay time passed in milliseconds using wrapped syscall `NtUserInjectKeyboardInput` function."""

        # Keyboard pressing and releasing
        self.keyboard_press(key, delay=self.__get_delay(delay if delay is not None else self.keyboard_clicks_delay)), self.keyboard_release(key, delay=0)

    def keyboard_type(self, text: str, layout_delay: int | float | None = None, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Types text using keyboard per-char keys press and releasing."""

        # Iterating every char and type it
        for key in text:

            # If key is invalid
            if (key_info := {key: value for key, value in keycodes.items() if len(key) == 1}.get(key)) is None:
                continue

            # Change keyboard layout if needed
            if (keyboard_layout := key_info.get("layout")) is not None:
                change_keyboard_layout(keyboard_layout, delay=self.__get_delay(layout_delay if layout_delay is not None else self.keyboard_layout_delay))

            # Flags to chech if shift required
            caps_is_on = ctypes.windll.user32.GetKeyState(keycodes["caps"]["code"])

            # If key is letter
            if key in letters:
                shift_required = (key_info["is_capital"] and not caps_is_on & 0x0001 != 0) or (not key_info["is_capital"] and caps_is_on)

            else:
                shift_required = key in en_chars_shifted_keycodes

            # Press and release the key with `Shift` if needed
            with self.keyboard_hold("shift" if shift_required else None, delay=self.__get_delay(delay if delay is not None else self.keyboard_clicks_delay)):
                self.keyboard_press_and_release(key, delay=self.__get_delay(delay if delay is not None else self.keyboard_clicks_delay))

    def keyboard_hotkey(self, *keys: str, delay: int | float | tuple[int | float, int | float] | None = None) -> None:
        """Press many keyboard keys and once."""

        # Hotkey activation
        with self.keyboard_hold(*keys, delay=self.__get_delay(delay if delay is not None else self.keyboard_clicks_delay)):
            pass

    @contextlib.contextmanager
    def mouse_hold(self, *buttons: typing.Literal["left", "right", "middle"], delay: int | float | tuple[int | float, int | float] | None = None) -> typing.Generator[None, typing.Any, typing.Any]:
        """Hold mouse buttons until context manager exit."""

        # Button pressing
        for button in buttons:
            self.mouse_click(button, delay=self.__get_delay(delay if delay is not None else self.mouse_clicks_delay))

        # Context exiting
        yield

        # Button releasing
        for button in buttons:
            self.mouse_release(button, delay=0)

    @contextlib.contextmanager
    def keyboard_hold(self, *keys: str, delay: int | float | tuple[int | float, int | float] | None = None) -> typing.Generator[None, typing.Any, typing.Any]:
        """Hold keyboard keys until context manager exit."""

        # Keys pressing
        for key in keys:
            self.keyboard_press(key, delay=self.__get_delay(delay if delay is not None else self.keyboard_clicks_delay))

        # Context exiting
        yield

        # Keys releasing
        for key in keys:
            self.keyboard_release(key, delay=0)

    # ==-------------------------------------------------------------------== #
    # Private methods                                                         #
    # ==-------------------------------------------------------------------== #
    @staticmethod
    def __get_spread(spread: tuple[int, int]) -> tuple[int, int]:
        """Gets spread value."""

        # Resolve spread value based on value type
        match spread:

            # If spread is a allowed range of random values
            case (int(), int()) | [int(), int()]:

                return random.randint(-abs(spread[0]), abs(spread[0])), random.randint(-abs(spread[1]), abs(spread[1]))
            # If spraed is invalid value
            case _:
                raise Exception("Unable to retrieve spread from `%s` value" % spread)

    @staticmethod
    def __get_delay(delay: int | float | tuple[int | float, int | float]) -> int | float:
        """Gets delay value."""

        # Resolve delay value based on value type
        match delay:

            # If delay is hardly defined
            case int() | float():
                return delay

            # If delay is a allowed range of random values
            case (int() | float(), int() | float()):
                return random.uniform(*[abs(item) for item in delay])

            # If delay is invalid value
            case _:
                raise Exception("Unable to retrieve delay from `%s` value" % delay)
