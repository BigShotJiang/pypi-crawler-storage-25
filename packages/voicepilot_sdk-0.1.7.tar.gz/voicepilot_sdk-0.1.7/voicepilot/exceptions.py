from typing import Optional

class VoicePilotError(Exception):
    """Base exception for all VoicePilot SDK errors."""
    pass

class AuthenticationError(VoicePilotError):
    """Raised when the API key is missing or invalid (401)."""
    pass

class ValidationError(VoicePilotError):
    """Raised when client-side or server-side validation fails (422/400)."""
    def __init__(self, message: str, detail: Optional[dict] = None):
        super().__init__(message)
        self.detail = detail

class RateLimitError(VoicePilotError):
    """Raised when the rate limit is exceeded (429)."""
    def __init__(self, message: str, retry_after: Optional[int] = None):
        super().__init__(message)
        self.retry_after = retry_after

class APIError(VoicePilotError):
    """Raised for server-side errors (5xx)."""
    def __init__(self, message: str, status_code: int):
        super().__init__(f"API Error {status_code}: {message}")
        self.status_code = status_code

class NetworkError(VoicePilotError):
    """Raised when the network connection fails."""
    pass
