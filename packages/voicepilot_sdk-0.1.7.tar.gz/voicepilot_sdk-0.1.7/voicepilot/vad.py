import os
import torch
from typing import Optional, Union, List
import numpy as np

class VoiceActivityDetector:
    """
    A robust Voice Activity Detector (VAD) based on the Silero VAD model.
    
    Requires 'silero-vad' and 'onnxruntime' or 'torch' to be installed.
    Ideally used to filter local audio before sending to the VoicePilot STT.
    """

    def __init__(self, threshold: float = 0.5, sampling_rate: int = 16000):
        """
        Initialize the VAD.
        
        Args:
            threshold (float): Speech probability threshold [0, 1].
            sampling_rate (int): Audio sampling rate (8000 or 16000).
        """
        self.threshold = threshold
        self.sampling_rate = sampling_rate
        self.model = None
        self.get_speech_timestamps = None
        self.collect_chunks = None
        self.read_audio = None
        self.save_audio = None
        self.init_to_avg = None
        self._initialized = False

    def _init_model(self):
        """Lazy load the Silero model."""
        if self._initialized:
            return

        try:
            # Use torch.hub to download/load the model
            model, utils = torch.hub.load(
                repo_or_dir='snakers4/silero-vad',
                model='silero_vad',
                force_reload=False,
                onnx=True
            )
            self.model = model
            self.get_speech_timestamps, self.collect_chunks, self.read_audio, self.save_audio, self.init_to_avg = utils
            self._initialized = True
        except Exception as e:
            raise RuntimeError(f"Failed to initialize Silero VAD: {e}. Ensure 'torch' and 'onnxruntime' are installed.")

    def is_speech(self, audio_chunk: Union[np.ndarray, bytes, torch.Tensor]) -> bool:
        """
        Check if a chunk of audio contains speech.
        
        Args:
            audio_chunk: Audio data as numpy array, bytes (INT16), or torch Tensor.
            
        Returns:
            bool: True if speech probability > threshold.
        """
        self._init_model()

        # Convert to float32 tensor
        if isinstance(audio_chunk, bytes):
            audio_chunk = np.frombuffer(audio_chunk, dtype=np.int16).astype(np.float32) / 32768.0
        
        if isinstance(audio_chunk, np.ndarray):
            audio_chunk = torch.from_numpy(audio_chunk)

        if len(audio_chunk.shape) == 1:
            audio_chunk = audio_chunk.unsqueeze(0)

        with torch.no_grad():
            speech_prob = self.model(audio_chunk, self.sampling_rate).item()
        
        return speech_prob > self.threshold

    def get_speech_segments(self, audio: Union[str, np.ndarray, torch.Tensor]) -> List[dict]:
        """
        Find all speech segments in an audio file or array.
        
        Args:
            audio: Local path to audio file or audio data.
            
        Returns:
            List[dict]: List of segments with 'start' and 'end' in samples.
        """
        self._init_model()
        
        if isinstance(audio, str):
            audio = self.read_audio(audio, sampling_rate=self.sampling_rate)
        
        return self.get_speech_timestamps(audio, self.model, sampling_rate=self.sampling_rate)
