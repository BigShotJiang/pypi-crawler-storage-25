from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class TTSResponse:
    audio_base64: str
    text: str
    voice: str

@dataclass
class STTResponse:
    transcript: str
    confidence: float

@dataclass
class Agent:
    id: str
    name: str
    system_prompt: str

@dataclass
class ConversationResponse:
    reply_text: str
    audio_base64: Optional[str]
    provider: str
    history: List[dict]

@dataclass
class WSMessage:
    """
    Standardized WebSocket message matching the VoicePilot event schema.

    Attributes:
        id: Unique event identifier (e.g., "evt_abc123")
        type: Event type (e.g., "agent.response", "transcript.final")
        speaker: Message originator — "user", "agent", or "system"
        text: Text content of the message
        turn_id: Groups user + agent exchanges into a single turn
        timestamp: ISO-8601 UTC timestamp
        is_final: Whether this is a finalized transcript or interim
        confidence: STT confidence score (0.0 - 1.0)
        source: Transcript source — "browser" or "deepgram"
        latency_ms: Time taken by the LLM to generate a response
        llm_provider: Which LLM was used (e.g., "gemini", "openai")
        tts_provider: Which TTS engine was used (e.g., "sarvam")
        audio_base64: Base64-encoded audio data
        error: Error message, if any
    """
    type: str
    id: str = ""
    speaker: str = ""
    text: Optional[str] = None
    turn_id: str = ""
    timestamp: str = ""
    is_final: bool = True
    confidence: Optional[float] = None
    source: Optional[str] = None
    latency_ms: Optional[int] = None
    llm_provider: Optional[str] = None
    tts_provider: Optional[str] = None
    audio_base64: Optional[str] = None
    error: Optional[str] = None

@dataclass
class SessionToken:
    """
    A short-lived session token for browser-safe WebSocket connections.

    Attributes:
        token: The session token string (prefix: sess_)
        expires_in: TTL in seconds
        expires_at: Unix timestamp when the token expires
    """
    token: str
    expires_in: int
    expires_at: float

