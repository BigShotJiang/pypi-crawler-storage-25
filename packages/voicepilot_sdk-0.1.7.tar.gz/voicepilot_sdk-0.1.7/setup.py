from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="voicepilot_sdk",
    version="0.1.7",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "urllib3>=1.26.0",
        "websocket-client>=1.3.0",
        "silero-vad>=5.1.0",
        "onnxruntime>=1.15.0",
        "torch>=2.0.0",
    ],
    extras_require={
        "dev": ["pytest", "responses"],
    },
    python_requires=">=3.8",
    author="VoicePilot Team",
    author_email="support@intelligens.app",
    description="Official Python SDK for high-fidelity voice and conversational AI.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://voice.intelligens.app",
    project_urls={
        "Homepage": "https://voice.intelligens.app",
        "Source": "https://github.com/voicepilot/voicepilot-python",
        "Bug Tracker": "https://github.com/voicepilot/voicepilot-python/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Multimedia :: Sound/Audio :: Speech",
    ],
)
