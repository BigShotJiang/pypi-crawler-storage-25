﻿"""Pipeline stage helpers."""
