import argparse
import json
import os
from datetime import datetime
from tracellm import load_pricing

TRACE_FILE = os.path.join(os.path.dirname(__file__), '..', 'trace.txt')

Running_total = {"Model" : None , "Calls" : 0 , "Tokens" : 0 , "Cost" : 0}

parser = argparse.ArgumentParser()
parser.add_argument("-S" , "--Status" , help = "Based on what status do filter" , choices = ["success" , "failed"])
parser.add_argument("-L" , "--Latency" , help = "Based on what latency do filter")
parser.add_argument("-M" , "--Model" , help = "Based on what model do filter")
parser.add_argument("-E" , "--Error" , help = "Based on what type of Error do filter")
parser.add_argument("-T" , "--Time" , help = "Based on what time do filter")
parser.add_argument("-C" , "--Cost" , help = "Calculates the token cost , use word 'Summary' for cost summary")
args = parser.parse_args()

def parse_time_input(s):
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise ValueError(f"Time format not recognised: {s}")
conditions = []
if args.Status:
    conditions.append(lambda t : t.get('Status') == args.Status)
if args.Latency:
    conditions.append(lambda t : t.get('Latency') >= float(args.Latency))
if args.Model:
    conditions.append(lambda t : t.get('Model') == args.Model)
if args.Error:
    conditions.append(lambda t : t.get('Error Type' , None) == args.Error)
if args.Time:
    query_time = parse_time_input(args.Time)
    conditions.append(
        lambda t, qt=query_time: datetime.strptime(
            t.get('Timestamp', ''), "%Y-%m-%d %H:%M:%S"
        ) >= qt
    )
if conditions != []:
    with open(TRACE_FILE , 'r') as trace_file:
        for line in trace_file:
            trace = json.loads(line)
            if all(condition(trace) for condition in conditions):
                print("\n--- Trace ---")
                for key, value in trace.items():
                    print(f"  {key}: {value}")
                print("-------------")
            
if args.Cost:
    pricing = load_pricing()
    total_calls = 0
    total_tokens = 0
    total_cost = 0
    model_breakdown = {}
    if args.Cost != 'Summary':
        C_or_S = 'Cost'
    else:
        C_or_S = 'Summary'
    with open(TRACE_FILE , 'r') as f:
        for line in f:
            trace = json.loads(line)
            if 'Tokens used' not in trace:
                continue
            T_used = trace['Tokens used']
            if trace['Model'] not in pricing:
                print(f"Model :{trace['Model']} is not stored.\nPlease config the pricing file and add the model ")
                continue
            cost = T_used * pricing[trace['Model']] / 1000000
            if C_or_S == 'Cost':
                print(f"Model : {trace['Model']}")
                print(f"Tokens Used : {T_used}")
                print(f"Cost : {cost}")
                print("---------------------\n")
            else:
                total_cost += cost
                total_calls += 1
                total_tokens += trace['Tokens used']
                if trace['Model'] in model_breakdown:
                    model_breakdown[trace['Model']]['Total Calls'] += 1
                    model_breakdown[trace['Model']]['Total Tokens'] += trace['Tokens used']
                    model_breakdown[trace['Model']]['Total Cost'] += cost
                else:
                    model_breakdown[trace['Model']] = {}
                    model_breakdown[trace['Model']] = {
                        'Total Calls' : 1,
                        'Total Tokens' : trace['Tokens used'],
                        'Total Cost' : cost
                    }
        if C_or_S == 'Summary':
            print("\n=== Cost Summary ===")
            for model, data in model_breakdown.items():
                print(f"\n  {model}")
                print(f"    Calls  : {data['Total Calls']}")
                print(f"    Tokens : {data['Total Tokens']}")
                print(f"    Cost   : ${data['Total Cost']:.6f}")
                print("====================")
            print(f"\n     Total calls made : {total_calls}")
            print(f"     Total Tokens used : {total_tokens}")
            print(f"     Total cost: ${total_cost:.6f}")
            print("====================")
                



