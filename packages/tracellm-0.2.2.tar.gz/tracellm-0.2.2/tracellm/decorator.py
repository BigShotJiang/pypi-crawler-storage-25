from .tracer import Tracer
import inspect

def trace(func):
    def wrapper(*args , **kwargs):
        sig = inspect.signature(func)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        all_args = bound.arguments
        model = all_args.get('model','unknown')
        prompt = "unknown"
        for val in all_args.values():
            if isinstance(val , list) and len(val) > 0:
                if isinstance(val[0] , dict) and "content" in val[0]:
                    prompt = val[0]['content']
                    break
        tracer_object = Tracer()
        tracer_object.start_trace(model , prompt )
        try:
            result = func(*args , **kwargs)
            tracer_object.model = result.model
            tracer_object.end_trace(result)
            return result
        except Exception as e:
            tracer_object.record_error(type(e).__name__ , str(e))
            raise
    return wrapper