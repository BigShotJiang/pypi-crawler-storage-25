import os
import json
Pricing = {
    "gpt-oss-20B (low)": 0.0675,
    "gpt-oss-20B (high)": 1.25,
    "Gemini 3.1 Pro Preview": 1.15,
    "GPT-5.4 (xhigh)": 12.50,
    "GPT-5.3 Codex (xhigh)": 11.50,
    "Claude Opus 4.6 (max)": 11.25,
    "Mercury 2": 0.04,
    "Qwen3.5 0.8B": 0.02,
    "Granite 4.0 H Small": 0.03,
    "Granite 3.3 8B": 0.04,
    "DeepSeek R1 Distill Qwen 32B": 0.09,
    "NVIDIA Nemotron 3 Nano": 0.03,
    "Gemma 3n E4B": 0.03,
    "Qwen3.5 2B": 0.04,
    "Llama 4 Scout": 0.05,
    "Grok 4.20 Beta 0309": 0.45,
    "Gemini 2.0 Pro Experimental": 1.10,
    "llama-3.1-8b-instant": 0.05
}

user_home = os.path.expanduser('~')
config_dirc = os.path.join(user_home , '.tracellm')
personal_dict = os.path.join(config_dirc , 'pricing.json')
def load_pricing():
    if os.path.exists(personal_dict):
        with open(personal_dict , 'r') as f:
            return json.load(f)
    else:
        return Pricing
    
