import datetime
import importlib
from collections.abc import Iterable
from typing import Any

from sentry_protos.taskbroker.v1.taskbroker_pb2 import TaskActivation

from taskbroker_client.constants import DEFAULT_PROCESSING_DEADLINE
from taskbroker_client.imports import import_string
from taskbroker_client.metrics import MetricsBackend
from taskbroker_client.registry import ExternalNamespace, TaskNamespace, TaskRegistry
from taskbroker_client.retry import Retry
from taskbroker_client.router import TaskRouter
from taskbroker_client.task import Task
from taskbroker_client.types import AtMostOnceStore, ContextHook, ProducerFactory


class TaskbrokerApp:
    """
    Container for an application's task setup and configuration.
    """

    def __init__(
        self,
        name: str,
        producer_factory: ProducerFactory,
        router_class: str | TaskRouter = "taskbroker_client.router.DefaultRouter",
        metrics_class: str | MetricsBackend = "taskbroker_client.metrics.NoOpMetricsBackend",
        at_most_once_store: AtMostOnceStore | None = None,
        context_hooks: list[ContextHook] | None = None,
    ) -> None:
        self.name = name
        self.metrics = self._build_metrics(metrics_class)
        self.context_hooks: list[ContextHook] = context_hooks if context_hooks is not None else []
        self._config = {
            "rpc_secret": None,
            "grpc_config": None,
            "at_most_once_timeout": None,
        }
        self._modules: Iterable[str] = []
        self._taskregistry = TaskRegistry(
            application=name,
            producer_factory=producer_factory,
            router=self._build_router(router_class),
            metrics=self.metrics,
            context_hooks=self.context_hooks,
        )
        self.at_most_once_store(at_most_once_store)

    def _build_router(self, router_name: str | TaskRouter) -> TaskRouter:
        if isinstance(router_name, str):
            router_class = import_string(router_name)
            router = router_class()
        else:
            router = router_name
        assert hasattr(router, "route_namespace")

        return router

    def _build_metrics(self, backend_name: str | MetricsBackend) -> MetricsBackend:
        if isinstance(backend_name, str):
            metrics_class = import_string(backend_name)
            return metrics_class()
        return backend_name

    @property
    def taskregistry(self) -> TaskRegistry:
        """Get the TaskRegistry instance from this app"""
        return self._taskregistry

    @property
    def config(self) -> dict[str, Any]:
        """Get the config data"""
        return self._config

    def set_config(self, config: dict[str, Any]) -> None:
        """Update configuration data"""
        for key, value in config.items():
            if key in self._config:
                self._config[key] = value

    def create_namespace(
        self,
        name: str,
        *,
        retry: Retry | None = None,
        expires: int | datetime.timedelta | None = None,
        processing_deadline_duration: int = DEFAULT_PROCESSING_DEADLINE,
        app_feature: str | None = None,
    ) -> TaskNamespace:
        """
        Create a task namespace.

        Namespaces are mapped onto topics through the configured router allowing
        infrastructure to be scaled based on a region's requirements.

        Namespaces can define default behavior for tasks defined within a namespace.
        """
        return self._taskregistry.create_namespace(
            name=name,
            retry=retry,
            expires=expires,
            processing_deadline_duration=processing_deadline_duration,
            app_feature=app_feature,
        )

    def create_external_namespace(
        self,
        name: str,
        application: str,
        *,
        retry: Retry | None = None,
        expires: int | datetime.timedelta | None = None,
        processing_deadline_duration: int = DEFAULT_PROCESSING_DEADLINE,
    ) -> ExternalNamespace:
        """
        Create a namespace for tasks belonging to an external (target) application.

        Tasks registered in external namespaces are routed using the host application's
        task router. When routing is required for an external namespace the namespace
        name sent to the router will be in the form of `{application}:{namespace_name}`
        """
        return self._taskregistry.create_external_namespace(
            name=name,
            application=application,
            retry=retry,
            expires=expires,
            processing_deadline_duration=processing_deadline_duration,
        )

    def get_task(self, namespace: str, task: str) -> Task[Any, Any]:
        """Fetch a task by namespace and name."""
        return self._taskregistry.get(namespace).get(task)

    def get_namespace(self, namespace: str) -> TaskNamespace:
        """Fetch a task by namespace and name."""
        return self._taskregistry.get(namespace)

    def set_modules(self, modules: Iterable[str]) -> None:
        """
        Set the list of modules containing tasks to be loaded by workers and schedulers.
        """
        self._modules = modules

    def load_modules(self) -> None:
        """Load all of the configured modules"""
        for mod in self._modules:
            __import__(mod)

    def at_most_once_store(self, backend: AtMostOnceStore | None) -> None:
        """
        Set the backend store for `at_most_once` tasks.
        The storage implementation should support atomic operations
        to avoid races with at_most_once tasks.
        """
        self._at_most_once_store = backend

    def should_attempt_at_most_once(self, activation: TaskActivation) -> bool:
        if not self._at_most_once_store:
            return True
        key = get_at_most_once_key(activation.namespace, activation.taskname, activation.id)
        return self._at_most_once_store.add(
            key, "1", timeout=self._config["at_most_once_timeout"] or 60
        )


def get_at_most_once_key(namespace: str, taskname: str, task_id: str) -> str:
    # tw:amo -> taskworker:at_most_once
    return f"tw:amo:{namespace}:{taskname}:{task_id}"


def import_app(app_module: str) -> TaskbrokerApp:
    """
    Resolve an application path like `acme.worker.runtime:app`
    into the `app` symbol defined in the module.
    """
    module_name, name = app_module.split(":")
    module = importlib.import_module(module_name)
    return getattr(module, name)
