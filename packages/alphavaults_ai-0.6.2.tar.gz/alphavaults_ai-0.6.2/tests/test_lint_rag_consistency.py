from pathlib import Path
import networkx as nx
from alphavaults.lint import check_rag_consistency, InconsistencyReport


class _FS:
    def __init__(self, g, nodes): self._g = g; self._n = nodes
    def load_nodes(self): return self._n
    def load_edges(self): return []
    def load_graph(self): return self._g


def test_consistency_reports_missing_files_in_vault(tmp_path):
    vault = tmp_path
    (vault / "a.md").write_text("A\n", encoding="utf-8")
    (vault / "b.md").write_text("B\n", encoding="utf-8")

    from alphavaults.contracts import WikiNode
    nodes = [WikiNode(id="a", path=Path("a.md"), title="A", tags=(),
                      body_hash="h", embedding_id=None, updated_at="2026-04-21")]
    g = nx.MultiDiGraph(); g.add_node("a")
    rep = check_rag_consistency(vault, _FS(g, nodes))
    assert rep.vault_file_count == 2
    assert rep.indexed_node_count == 1
    assert "b.md" in rep.missing_from_index
