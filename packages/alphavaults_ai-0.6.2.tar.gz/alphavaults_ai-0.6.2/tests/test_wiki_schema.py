import pytest
from pathlib import Path
from alphavaults.contracts import WikiNode, WikiEdge, EdgeKind, HARD_EDGE_KINDS


def test_wiki_node_is_frozen():
    n = WikiNode(id="a", path=Path("a.md"), title="A", tags=(),
                 body_hash="h", embedding_id=None, updated_at="2026-04-21")
    with pytest.raises(Exception):
        n.title = "B"  # type: ignore[misc]


def test_wiki_edge_default_weight():
    e = WikiEdge(source="a", target="b", kind="wikilink", weight=1.0)
    assert e.weight == 1.0


def test_hard_edge_kinds_membership():
    assert "wikilink" in HARD_EDGE_KINDS
    assert "frontmatter_ref" in HARD_EDGE_KINDS
    assert "rag_similarity" not in HARD_EDGE_KINDS


def test_edge_kind_literal_accepts_known_values():
    assert isinstance(HARD_EDGE_KINDS, frozenset)
    assert all(isinstance(k, str) for k in HARD_EDGE_KINDS)
