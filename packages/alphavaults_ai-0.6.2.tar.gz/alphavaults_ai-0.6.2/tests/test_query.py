from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from alphavaults.index import index_markdown  # noqa: E402
from alphavaults.query import _extract_wiki_excerpt, query  # noqa: E402
from alphavaults.search import search as bm25_search  # noqa: E402


class QueryBudgetTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.wiki_dir = self.root / "wiki"
        self.wiki_dir.mkdir(parents=True, exist_ok=True)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def _write_wiki(self, rel_path: str, content: str) -> None:
        path = self.wiki_dir / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_extract_wiki_excerpt_prefers_relevant_section(self) -> None:
        content = (
            "# AlphaMate Notes\n\n"
            + ("도입부 설명입니다.\n" * 40)
            + "## Ledger Cutover\nAlphaMate Ledger v2 cutover strategy and migration notes.\n"
            + ("후속 설명입니다.\n" * 20)
        )

        excerpt = _extract_wiki_excerpt(content, "AlphaMate Ledger v2 cutover", 240)

        self.assertIn("Ledger Cutover", excerpt)
        self.assertIn("cutover strategy", excerpt)
        self.assertTrue(excerpt.startswith("...") or excerpt.startswith("## Ledger Cutover"))
        self.assertLessEqual(len(excerpt), 260)

    def test_query_caps_graph_and_wiki_context_for_broad_query(self) -> None:
        self._write_wiki(
            "alphamate-ledger.md",
            (
                "# AlphaMate Ledger v2\n\n"
                + ("일반 설명 문단입니다.\n" * 60)
                + "## 핵심 전환\nAlphaMate Ledger v2 PWA to React Native migration details.\n"
                + ("추가 설명 문단입니다.\n" * 80)
            ),
        )
        self._write_wiki(
            "alphamate-overview.md",
            "# AlphaMate Overview\n\nAlphaMate structure summary and dashboard notes.\n",
        )
        index_markdown(self.wiki_dir, self.root / "search_index.json")

        nodes = []
        links = []
        for i in range(60):
            nodes.append({"id": f"claude/AlphaMate/node_{i}", "label": f"AlphaMate Ledger node {i}"})
        for i in range(59):
            links.append(
                {
                    "source": f"claude/AlphaMate/node_{i}",
                    "target": f"claude/AlphaMate/node_{i + 1}",
                    "relation": "contains",
                }
            )
        graph = {
            "nodes": nodes,
            "links": links,
            "communities": {"c1": [node["id"] for node in nodes]},
        }
        (self.root / "graph.json").write_text(json.dumps(graph, ensure_ascii=False), encoding="utf-8")

        result = query("AlphaMate Ledger v2", self.root, budget=800)

        self.assertGreater(result["graph_context"]["matched_nodes_total"], len(result["graph_context"]["matched_nodes"]))
        self.assertLessEqual(len(result["graph_context"]["matched_nodes"]), 12)
        self.assertLessEqual(len(result["graph_context"]["edges"]), 13)
        self.assertLessEqual(len(result["wiki_context"]), 3200)
        self.assertLessEqual(result["tokens_used"], 900)
        self.assertIn("AlphaMate Ledger v2", result["wiki_context"])

    def test_search_prefers_title_and_path_match_for_query(self) -> None:
        self._write_wiki(
            "alphamate-cutover-note.md",
            "# AlphaMate cutover note\n\nAlphaMate cutover note and migration summary.\n",
        )
        self._write_wiki(
            "alphaedge-비교.md",
            (
                "# AlphaEdge 비교\n\n"
                + ("AlphaMate onboarding migration note comparison 문장입니다.\n" * 40)
            ),
        )
        self._write_wiki("misc.md", "# Misc\n\nirrelevant document\n")
        index_markdown(self.wiki_dir, self.root / "search_index.json")

        results = bm25_search("AlphaMate cutover note", self.root / "search_index.json", top_k=3)

        self.assertGreaterEqual(len(results), 1)
        self.assertEqual(results[0]["path"], "alphamate-cutover-note.md")


if __name__ == "__main__":
    unittest.main()
