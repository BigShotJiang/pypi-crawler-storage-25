"""LLMwiki V1 regression — opt-in (@pytest.mark.slow).

Run:
    pytest -m slow tests/test_eval_llmwiki_regression.py -v

Spec threshold (Part B Phase 2):
- Overall top-3 hit ≥ 70%
- Korean top-3 hit ≥ 67%

Vault path: env var `ALPHAVAULTS_LLMWIKI` (default `D:/Obsidian Vault/나의 제2의 뇌`).
Pre-built ingest dir: env var `ALPHAVAULTS_LLMWIKI_OUT` (skips ingest if set
and contains `search_index.json`).
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

from alphavaults.pipeline import run_documents
from alphavaults.query import query as avq_query


DEFAULT_VAULT = Path(os.environ.get(
    "ALPHAVAULTS_LLMWIKI",
    r"D:/Obsidian Vault/나의 제2의 뇌",
))
ANSWERS = Path(__file__).resolve().parent / "fixtures" / "llmwiki_known_answers.json"


def _normpath(p: str) -> str:
    return p.replace("\\", "/").lower()


def _hit(paths, expected, top_k=3):
    wanted = [_normpath(e) for e in expected]
    head = [_normpath(p) for p in paths[:top_k]]
    return any(any(e in p for e in wanted) for p in head)


@pytest.fixture(scope="module")
def ingested_out():
    if not DEFAULT_VAULT.exists():
        pytest.skip(f"LLMwiki vault not available: {DEFAULT_VAULT}")

    reuse = os.environ.get("ALPHAVAULTS_LLMWIKI_OUT")
    if reuse and (Path(reuse) / "search_index.json").exists():
        yield Path(reuse)
        return

    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        run_documents(DEFAULT_VAULT, out)
        yield out


@pytest.fixture(scope="module")
def questions():
    if not ANSWERS.exists():
        pytest.skip(f"known_answers missing: {ANSWERS}")
    return json.loads(ANSWERS.read_text(encoding="utf-8"))["questions"]


def _measure(ingested_out, questions, lang_filter=None):
    if lang_filter:
        questions = [q for q in questions if q["lang"] == lang_filter]
    if not questions:
        pytest.skip(f"no questions matching lang={lang_filter}")
    hits = 0
    for q in questions:
        r = avq_query(q["question"], ingested_out, mode="hybrid", budget=2000)
        paths = [sr.get("path", "") for sr in r.get("search_results", [])]
        if _hit(paths, q["expected_chunk_ids"]):
            hits += 1
    return hits, len(questions)


@pytest.mark.slow
def test_llmwiki_overall_top3_hit_at_least_70pct(ingested_out, questions):
    hits, total = _measure(ingested_out, questions)
    assert hits / total >= 0.70, (
        f"overall top-3 hit {hits}/{total} = {hits / total * 100:.1f}% < 70%"
    )


@pytest.mark.slow
def test_llmwiki_korean_top3_hit_at_least_67pct(ingested_out, questions):
    hits, total = _measure(ingested_out, questions, lang_filter="ko")
    assert hits / total >= 0.67, (
        f"korean top-3 hit {hits}/{total} = {hits / total * 100:.1f}% < 67%"
    )
