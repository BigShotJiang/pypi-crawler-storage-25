"""Tests for wiki.py automatic frontmatter generation and preservation."""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import networkx as nx

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from alphavaults.wiki import (  # noqa: E402
    _build_auto_fields,
    _merge_with_existing,
    _parse_frontmatter_lines,
    _render_frontmatter,
    _split_frontmatter,
    generate_wiki,
    update_wiki,
)


def _make_graph() -> nx.DiGraph:
    G = nx.DiGraph()
    G.add_node("a", label="Alpha", source_file="a.md")
    G.add_node("b", label="Beta", source_file="b.md")
    G.add_node("c", label="Gamma", source_file="c.md")
    G.add_edge("a", "b", relation="links_to", confidence="EXTRACTED")
    G.add_edge("b", "c", relation="references", confidence="EXTRACTED")
    return G


def test_split_frontmatter_no_fm():
    fm, body = _split_frontmatter("# heading\nbody\n")
    assert fm == ""
    assert body == "# heading\nbody\n"


def test_split_frontmatter_present():
    content = "---\nkey: value\nother: x\n---\n# body\n"
    fm, body = _split_frontmatter(content)
    assert "key: value" in fm
    assert body == "# body\n"


def test_parse_frontmatter_lines():
    fm = "domain(분야): wiki\ntype(유형): 인덱스\nnodes: 30"
    parsed = _parse_frontmatter_lines(fm)
    assert parsed["domain(분야)"] == "wiki"
    assert parsed["type(유형)"] == "인덱스"
    assert parsed["nodes"] == "30"


def test_render_frontmatter_round_trip():
    fields = {"domain(분야)": "wiki", "nodes": "5"}
    rendered = _render_frontmatter(fields)
    assert rendered.startswith("---\n")
    assert "domain(분야): wiki" in rendered
    assert rendered.endswith("---\n")


def test_build_auto_fields_includes_bilingual_keys():
    fields = _build_auto_fields(page_type="커뮤니티", nodes=10, cohesion=0.42)
    assert fields["domain(분야)"] == "wiki"
    assert fields["type(유형)"] == "커뮤니티"
    assert fields["status(상태)"] == "자동생성"
    assert fields["source(출처)"] == "alphavaults_compiled"
    assert fields["nodes"] == "10"
    assert fields["cohesion"] == "0.42"
    assert "last_compiled" in fields


def test_merge_preserves_user_fields_overwrites_auto():
    existing = "---\ndomain(분야): wiki\nstatus(상태): 정리완료\nlast_compiled: 1900-01-01 00:00:00\nnodes: 1\n---\n# body\n"
    auto = _build_auto_fields(page_type="커뮤니티", nodes=99, cohesion=0.7)
    merged = _merge_with_existing(existing, auto)
    assert merged["status(상태)"] == "정리완료"
    assert merged["last_compiled"] != "1900-01-01 00:00:00"
    assert merged["nodes"] == "99"
    assert merged["cohesion"] == "0.70"


def test_generate_wiki_writes_frontmatter():
    G = _make_graph()
    communities = {0: ["a", "b"], 1: ["c"]}
    labels = {0: "Cluster 0", 1: "Cluster 1"}
    cohesion = {0: 0.8, 1: 0.5}
    with tempfile.TemporaryDirectory() as tmp:
        out_dir = Path(tmp)
        n = generate_wiki(G, communities, labels, out_dir, cohesion)
        assert n >= 1
        index = (out_dir / "wiki" / "INDEX.md").read_text(encoding="utf-8")
        assert index.startswith("---\n")
        assert "type(유형): 인덱스" in index
        assert "source(출처): alphavaults_compiled" in index
        assert "# Knowledge Wiki" in index

        cluster_page = (out_dir / "wiki" / "cluster-0.md").read_text(encoding="utf-8")
        assert cluster_page.startswith("---\n")
        assert "type(유형): 커뮤니티" in cluster_page
        assert "cohesion: 0.80" in cluster_page


def test_generate_wiki_preserves_user_status_on_rewrite():
    G = _make_graph()
    communities = {0: ["a", "b"]}
    labels = {0: "Cluster 0"}
    with tempfile.TemporaryDirectory() as tmp:
        out_dir = Path(tmp)
        wiki_dir = out_dir / "wiki"
        wiki_dir.mkdir(parents=True)
        # Pre-existing page with user-set status
        seeded = "---\nstatus(상태): 정리완료\ndomain(분야): wiki\n---\n# old body\n"
        (wiki_dir / "cluster-0.md").write_text(seeded, encoding="utf-8")

        generate_wiki(G, communities, labels, out_dir, {0: 0.6})
        page = (wiki_dir / "cluster-0.md").read_text(encoding="utf-8")
        assert "status(상태): 정리완료" in page  # user field preserved
        assert "type(유형): 커뮤니티" in page  # new auto field added


def test_update_wiki_preserves_user_notes_and_user_frontmatter():
    G = _make_graph()
    with tempfile.TemporaryDirectory() as tmp:
        out_dir = Path(tmp)
        wiki_dir = out_dir / "wiki"
        wiki_dir.mkdir(parents=True)
        # Seed a page with user fm + user-notes section
        seeded = (
            "---\nstatus(상태): 검토중\n---\n"
            "# Old Title\nold body\n"
            "<!-- user-notes -->\n사용자가 추가한 메모\n"
        )
        # The slug for our test depends on _community_label; we'll use a known one
        # by pre-running update which calls cluster()
        from alphavaults.cluster import cluster as do_cluster
        comms = do_cluster(G)
        from alphavaults.wiki import _community_label, _slugify
        any_cid = next(iter(comms))
        lbl = _community_label(G, comms[any_cid])
        slug = _slugify(lbl)
        (wiki_dir / f"{slug}.md").write_text(seeded, encoding="utf-8")

        update_wiki(G, list(G.nodes()), out_dir)
        result = (wiki_dir / f"{slug}.md").read_text(encoding="utf-8")
        assert "status(상태): 검토중" in result
        assert "사용자가 추가한 메모" in result
        assert "type(유형): 커뮤니티" in result
