"""v0.6.2 sweep — update_index() 가드/시그니처 정합 회귀.

M1: tokenizer mismatch → ValueError (혼합 인덱스 차단).
m3: ignore_matchers 파라미터 + OSError/UnicodeDecodeError 보호 (index_markdown 시그니처 정합).
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from alphavaults.index import index_markdown, update_index
from alphavaults.tokenizers import RegexTokenizer, get_tokenizer


def _write(p: Path, body: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body, encoding="utf-8")


def test_update_index_raises_on_tokenizer_mismatch(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    index_path = tmp_path / "index.json"
    _write(docs_dir / "a.md", "# Alpha\n팩터 분석 페이지")

    n = index_markdown(docs_dir, index_path)
    assert n == 1

    class FakeKiwi(RegexTokenizer):
        name = "kiwi"

    with pytest.raises(ValueError, match="Tokenizer mismatch"):
        update_index(docs_dir, index_path, tokenizer=FakeKiwi())


def test_update_index_allows_matching_tokenizer(tmp_path: Path) -> None:
    docs_dir = tmp_path / "docs"
    index_path = tmp_path / "index.json"
    _write(docs_dir / "a.md", "# Alpha\nbody body body")

    index_markdown(docs_dir, index_path)
    # Same tokenizer name — should succeed
    out = update_index(docs_dir, index_path, tokenizer=RegexTokenizer())
    assert out == 0  # nothing changed


def test_update_index_empty_index_accepts_any_tokenizer(tmp_path: Path) -> None:
    """If the index doesn't exist or is empty, mismatch guard is bypassed."""
    docs_dir = tmp_path / "docs"
    index_path = tmp_path / "index.json"
    _write(docs_dir / "a.md", "# Alpha\nbody body body")

    class FakeKiwi(RegexTokenizer):
        name = "kiwi"

    out = update_index(docs_dir, index_path, tokenizer=FakeKiwi())
    assert out == 1
    payload = json.loads(index_path.read_text(encoding="utf-8"))
    assert payload["tokenizer"] == "kiwi"


def test_update_index_respects_ignore_matchers(tmp_path: Path) -> None:
    """m3: ignore_matchers parameter mirrors index_markdown — both at indexing
    new files and at pruning existing entries."""
    docs_dir = tmp_path / "docs"
    index_path = tmp_path / "index.json"
    _write(docs_dir / "keep.md", "# Keep\nbody body body")
    _write(docs_dir / ".trash" / "junk.md", "# Junk\nbody body body")

    def matcher(rel: str) -> bool:
        return rel.startswith(".trash/")

    n = index_markdown(docs_dir, index_path, ignore_matchers=[matcher])
    assert n == 1
    payload = json.loads(index_path.read_text(encoding="utf-8"))
    assert "keep.md" in payload["docs"]
    assert all(".trash" not in p for p in payload["docs"])

    # Edit keep.md and re-run incremental update with matcher — .trash/ stays out
    _write(docs_dir / "keep.md", "# Keep updated\nnew body body")
    _write(docs_dir / ".trash" / "later.md", "# Later\nbody body body")
    out = update_index(docs_dir, index_path, ignore_matchers=[matcher])
    assert out == 1
    payload = json.loads(index_path.read_text(encoding="utf-8"))
    assert "keep.md" in payload["docs"]
    assert all(".trash" not in p for p in payload["docs"])


def test_update_index_skips_unreadable_files(tmp_path: Path, monkeypatch) -> None:
    """m3: a single OSError/UnicodeDecodeError must not crash the incremental
    update. Mirrors index_markdown's defensive read."""
    docs_dir = tmp_path / "docs"
    index_path = tmp_path / "index.json"
    _write(docs_dir / "good.md", "# Good\nbody body body")
    bad = docs_dir / "bad.md"
    bad.write_bytes(b"\xff\xfe\xfd not utf-8 \xff")

    real_read = Path.read_text

    def maybe_raise(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        if self.name == "bad.md":
            raise UnicodeDecodeError("utf-8", b"\xff", 0, 1, "bad")
        return real_read(self, *args, **kwargs)

    # First build a clean index without the bad file present
    bad_backup = bad.read_bytes()
    bad.unlink()
    index_markdown(docs_dir, index_path)
    bad.write_bytes(bad_backup)

    monkeypatch.setattr(Path, "read_text", maybe_raise)

    # Should not crash; bad.md silently skipped, good.md unchanged
    out = update_index(docs_dir, index_path)
    assert out == 0
