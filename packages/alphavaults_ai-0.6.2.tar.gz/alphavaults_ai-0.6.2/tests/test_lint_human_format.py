from alphavaults.cli import _print_lint_human


def test_human_report_shows_sections(capsys):
    _print_lint_human({
        "orphans": ["a", "b"],
        "broken_links": [{"source": "wiki/x.md", "target": "missing", "line": 42}],
        "rag_consistency": {
            "vault_files": 10, "indexed_nodes": 8,
            "missing_from_index": ["c.md", "d.md"], "orphaned_in_index": [],
        },
    })
    captured = capsys.readouterr().out
    assert "orphans" in captured.lower()
    assert "broken" in captured.lower()
    assert "c.md" in captured
