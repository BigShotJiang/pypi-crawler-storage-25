from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from alphavaults import review  # noqa: E402


class ReviewFormattingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        (self.root / "raw").mkdir(parents=True, exist_ok=True)
        (self.root / "wiki" / "개발").mkdir(parents=True, exist_ok=True)
        (self.root / "wiki" / "일반").mkdir(parents=True, exist_ok=True)
        (self.root / "output" / "alphavaults" / "review").mkdir(parents=True, exist_ok=True)
        self._orig_get_llmwiki_root = review.get_llmwiki_root
        self._orig_get_review_dir = review.get_review_dir
        review.get_llmwiki_root = lambda: self.root
        review.get_review_dir = lambda: self.root / "output" / "alphavaults" / "review"
        review._NOTE_INDEX_CACHE.clear()
        review._NOTE_TITLE_CACHE.clear()

    def tearDown(self) -> None:
        review.get_llmwiki_root = self._orig_get_llmwiki_root
        review.get_review_dir = self._orig_get_review_dir
        self.temp_dir.cleanup()

    def _write(self, rel_path: str, content: str) -> Path:
        path = self.root / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        review._NOTE_INDEX_CACHE.clear()
        review._NOTE_TITLE_CACHE.clear()
        return path

    def test_render_raw_candidate_document_uses_korean_tags_and_safe_links(self) -> None:
        self._write("wiki/개발/바이브코딩.md", "# 바이브코딩\n")
        self._write("wiki/개발/claude-생태계-가이드.md", "# Claude 생태계 가이드\n")

        raw_content = """---
tags: [claude, cowork, obsidian]
type: research
---

# Claude Code & Cowork 마스터 가이드

### 주제 : #앤트로픽 #generator

### 메모
- [[00. LLM Wiki/raw/dev/텔레봇 에이전트의 이중인격]]
- [[바이브코딩]]
"""

        rendered = review._render_raw_candidate_document(
            self.root,
            title="Claude Code & Cowork 마스터 가이드",
            category="개발",
            source_rel="raw/claude-guide.md",
            raw_content=raw_content,
            target_path="wiki/개발/claude-code-cowork-마스터-가이드.md",
        )

        self.assertIn("  - 개발", rendered)
        self.assertIn("  - 리서치", rendered)
        self.assertIn("  - 클로드", rendered)
        self.assertIn("  - 코워크", rendered)
        self.assertIn("[[바이브코딩]]", rendered)
        self.assertIn("[[claude-생태계-가이드|Claude 생태계 가이드]]", rendered)
        self.assertNotIn("[[00. LLM Wiki/raw", rendered)
        self.assertNotIn("[[INDEX]]", rendered)

    def test_normalize_automation_docs_rewrites_existing_bad_format(self) -> None:
        self._write("wiki/개발/바이브코딩.md", "# 바이브코딩\n")
        raw_path = self._write(
            "raw/dev/테스트-노트.md",
            """### 날짜 : 2026-04-13

### 주제 : #옵시디언 #claude
----
### 메모
옵시디언에서 [[바이브코딩]]과 연결되는 노트.
### 연결문서
- [[00. LLM Wiki/raw/dev/다른 문서]]
""",
        )
        wiki_path = self._write(
            "wiki/개발/테스트-노트.md",
            f"""---
coverage: low
automation: alphavaults
review_status: approved
---

# 테스트 노트

## 원본 핵심
### 주제 : #옵시디언 #claude
- [[INDEX]]

## Sources
- {raw_path.relative_to(self.root).as_posix()}
""",
        )

        result = review.normalize_automation_docs(self.root, write=True)

        self.assertEqual(result["scanned"], 1)
        self.assertEqual(result["updated"], 1)
        normalized = wiki_path.read_text(encoding="utf-8")
        self.assertIn("## 한줄 요약", normalized)
        self.assertIn("## AlphaVaults 근거", normalized)
        self.assertIn("  - 옵시디언", normalized)
        self.assertIn("  - 클로드", normalized)
        self.assertNotIn("[[INDEX]]", normalized)
        self.assertNotIn("[[00. LLM Wiki/raw", normalized)

    def test_render_wiki_curated_document_adds_frontmatter_tags_and_related_links(self) -> None:
        self._write("wiki/일반/옵시디언-사용법.md", "# 옵시디언 사용법\n")
        note_path = self._write(
            "wiki/개발/노트와-링크.md",
            """# 노트와 링크

[coverage: medium]
[last_compiled: 2026-04-07]

## 요약
옵시디언에서 노트 간 연결과 백링크를 정리한 문서.
""",
        )

        rendered, rationale = review._render_wiki_curated_document(self.root, note_path)

        self.assertIsNotNone(rendered)
        assert rendered is not None
        self.assertIn("domain: 개발", rendered)
        self.assertIn("type: 정리", rendered)
        self.assertIn("last_curated:", rendered)
        self.assertIn("  - 개발", rendered)
        self.assertIn("  - 정리", rendered)
        self.assertIn("  - 옵시디언", rendered)
        self.assertIn("  - 그래프", rendered)
        self.assertIn("## 관련 문서", rendered)
        self.assertIn("[[옵시디언-사용법|옵시디언 사용법]]", rendered)
        self.assertNotIn("[coverage: medium]", rendered)
        self.assertEqual(rationale["stage"], "observe -> infer -> propose")

    def test_wiki_curation_candidates_skip_unchanged_documents_after_backfill(self) -> None:
        note_path = self._write(
            "wiki/개발/바이브코딩.md",
            """# 바이브코딩

## 요약
에이전트 작업 흐름을 정리한 문서.
""",
        )

        first = review._wiki_curation_candidates(self.root, set(), backfill=True, limit=0)
        second = review._wiki_curation_candidates(self.root, set(), backfill=False, limit=0)

        self.assertEqual(len(first), 1)
        self.assertEqual(first[0]["target_path"], "wiki/개발/바이브코딩.md")
        self.assertEqual(second, [])
        state = json.loads((review.get_review_dir() / "runtime" / "curation_state.json").read_text(encoding="utf-8"))
        self.assertIn("wiki/개발/바이브코딩.md", state["files"])
        self.assertEqual(state["files"]["wiki/개발/바이브코딩.md"]["hash"], review._hash_text(note_path.read_text(encoding="utf-8")))

    def test_apply_approved_updates_existing_wiki_note_when_hash_matches(self) -> None:
        note_path = self._write(
            "wiki/개발/바이브코딩.md",
            """# 바이브코딩

## 요약
작업 흐름을 정리한 문서.
""",
        )
        new_content, _ = review._render_wiki_curated_document(self.root, note_path)
        assert new_content is not None

        batch_id = "2099-01-01"
        batch_dir = review.get_review_dir() / batch_id
        batch_dir.mkdir(parents=True, exist_ok=True)
        batch = {
            "batch_id": batch_id,
            "created_at": review._now(),
            "rules_path": str(self.root / "RULES.md"),
            "rules_ok": True,
            "items": [
                {
                    "id": "curate-test",
                    "kind": "wiki-curation",
                    "title": "바이브코딩",
                    "status": "approved",
                    "risk": "low",
                    "apply_mode": "update",
                    "target_path": "wiki/개발/바이브코딩.md",
                    "source_paths": ["wiki/개발/바이브코딩.md"],
                    "observed_hash": review._hash_text(note_path.read_text(encoding="utf-8")),
                    "rationale": "테스트",
                    "content": new_content,
                }
            ],
        }
        (batch_dir / "batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2), encoding="utf-8")

        original_run_git = review._run_git

        def fake_run_git(root: Path, args: list[str], check: bool = True):
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

        review._run_git = fake_run_git
        try:
            result = review.apply_approved(batch_id=batch_id, notify_slack=False)
        finally:
            review._run_git = original_run_git

        self.assertEqual(result["applied"], 1)
        updated = note_path.read_text(encoding="utf-8")
        self.assertIn("last_curated:", updated)
        self.assertIn("tags:", updated)
        saved_batch = json.loads((batch_dir / "batch.json").read_text(encoding="utf-8"))
        self.assertEqual(saved_batch["items"][0]["status"], "applied")

    def test_generate_review_batch_includes_update_patch_for_existing_wiki_note(self) -> None:
        self._write(
            "wiki/개발/바이브코딩.md",
            """# 바이브코딩

## 요약
에이전트 작업 흐름을 정리한 문서.
""",
        )

        batch = review.generate_review_batch(limit=0, notify=False, force=True, backfill_wiki=True, wiki_limit=0)

        kinds = {item["kind"] for item in batch["items"]}
        self.assertIn("wiki-curation", kinds)
        self.assertIn("project-digest", kinds)

        curation_item = next(item for item in batch["items"] if item["kind"] == "wiki-curation")
        patch_path = self.root / curation_item["patch_path"]
        patch_text = patch_path.read_text(encoding="utf-8")

        self.assertEqual(curation_item["apply_mode"], "update")
        self.assertIn("--- a/wiki/개발/바이브코딩.md", patch_text)
        self.assertIn("+++ b/wiki/개발/바이브코딩.md", patch_text)

    def test_slack_blocks_include_item_checkboxes_and_bulk_actions(self) -> None:
        batch = {
            "batch_id": "2099-01-01",
            "rules_ok": True,
            "items": [
                {"id": "a1", "title": "문서 A", "status": "pending", "kind": "wiki-curation", "target_path": "wiki/개발/a.md", "rationale": "정리", "content": "# A\n"},
                {"id": "a2", "title": "문서 B", "status": "pending", "kind": "wiki-curation", "target_path": "wiki/개발/b.md", "rationale": "정리", "content": "# B\n"},
            ],
        }

        blocks = review._slack_blocks(batch)
        item_checkboxes = [
            block for block in blocks
            if block.get("type") == "section" and block.get("accessory", {}).get("type") == "checkboxes"
        ]
        bulk_buttons = [
            element
            for block in blocks if block.get("type") == "actions"
            for element in block.get("elements", [])
            if str(element.get("action_id", "")).startswith("alphavaults_bulk_")
        ]

        self.assertTrue(item_checkboxes)
        self.assertIn("alphavaults_select_all", [block.get("accessory", {}).get("action_id") for block in item_checkboxes])
        self.assertIn("alphavaults_select_a1", [block.get("accessory", {}).get("action_id") for block in item_checkboxes])
        self.assertTrue(bulk_buttons)
        values = {button["value"] for button in bulk_buttons}
        self.assertIn("2099-01-01|bulk|approve", values)
        self.assertIn("2099-01-01|bulk|hold", values)
        self.assertIn("2099-01-01|bulk|reject", values)

    def test_selected_bulk_item_ids_reads_item_state_values(self) -> None:
        payload = {
            "state": {
                "values": {
                    "block-1": {
                        "alphavaults_select_a1": {
                            "type": "checkboxes",
                            "selected_options": [
                                {"value": "a1"},
                            ],
                        }
                    },
                    "block-2": {
                        "alphavaults_select_a2": {
                            "type": "checkboxes",
                            "selected_options": [
                                {"value": "a2"},
                            ],
                        }
                    },
                }
            }
        }

        selected = review._selected_bulk_item_ids(payload)

        self.assertEqual(selected, ["a1", "a2"])

    def test_selected_bulk_item_ids_uses_select_all_when_enabled(self) -> None:
        payload = {
            "state": {
                "values": {
                    "control": {
                        "alphavaults_select_all": {
                            "type": "checkboxes",
                            "selected_options": [{"value": "all"}],
                        }
                    }
                }
            }
        }
        batch = {
            "items": [
                {"id": "a1", "status": "pending"},
                {"id": "a2", "status": "applied"},
                {"id": "a3", "status": "pending"},
            ]
        }

        selected = review._selected_bulk_item_ids(payload, batch=batch)

        self.assertEqual(selected, ["a1", "a3"])


class FrontmatterParsingTests(unittest.TestCase):
    def test_parses_plain_english_keys(self) -> None:
        text = (
            "---\n"
            "type: fleeting\n"
            "status: inbox\n"
            "tags:\n"
            "  - inbox\n"
            "  - zettel\n"
            "---\n"
            "body text\n"
        )
        meta, body = review._parse_frontmatter(text)
        self.assertEqual(meta["type"], "fleeting")
        self.assertEqual(meta["status"], "inbox")
        self.assertEqual(meta["tags"], ["inbox", "zettel"])
        self.assertEqual(body.strip(), "body text")

    def test_parses_bilingual_keys(self) -> None:
        text = (
            "---\n"
            "type(유형): fleeting\n"
            "status(상태): inbox\n"
            "created(생성일): 2026-04-19\n"
            "domain(분야):\n"
            "  - dev\n"
            "tags:\n"
            "  - inbox\n"
            "---\n"
            "body\n"
        )
        meta, body = review._parse_frontmatter(text)
        self.assertEqual(meta["type"], "fleeting")
        self.assertEqual(meta["status"], "inbox")
        self.assertEqual(meta["created"], "2026-04-19")
        self.assertEqual(meta["domain"], ["dev"])
        self.assertEqual(meta["tags"], ["inbox"])

    def test_mixed_keys_both_accepted(self) -> None:
        text = (
            "---\n"
            "type(유형): decision\n"
            "status: active\n"
            "source(출처): manual\n"
            "---\n"
        )
        meta, _body = review._parse_frontmatter(text)
        self.assertEqual(meta["type"], "decision")
        self.assertEqual(meta["status"], "active")
        self.assertEqual(meta["source"], "manual")


class AppendLogTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_append_log_includes_machine_prefix_and_utf8(self) -> None:
        import os

        os.environ["ALPHAVAULTS_MACHINE"] = "TESTBOX"
        try:
            review._append_log(self.root, "한글 메시지 테스트")
            review._append_log(self.root, "두번째 항목")
        finally:
            os.environ.pop("ALPHAVAULTS_MACHINE", None)

        raw = (self.root / "log.md").read_bytes()
        text = raw.decode("utf-8")
        self.assertIn("[TESTBOX]", text)
        self.assertIn("한글 메시지 테스트", text)
        self.assertIn("두번째 항목", text)
        # No mojibake: 한글 byte 시퀀스가 정상 디코드되어야 함
        self.assertNotIn("?", text.replace("?", ""))  # text doesn't lose chars

    def test_append_log_atomic_appends_do_not_truncate(self) -> None:
        for i in range(5):
            review._append_log(self.root, f"항목 {i}")
        text = (self.root / "log.md").read_text(encoding="utf-8")
        for i in range(5):
            self.assertIn(f"항목 {i}", text)


if __name__ == "__main__":
    unittest.main()
