"""Benchmark regression guard for tests/benchmark/.

Always asserts the AV systems hit their v0.6.0 baselines on the 50Q fixture:

    av-current:    Recall@5 >= 0.92  (v0.6.0 Track A regex measured 0.930)
    av-bm25-only:  Recall@5 >= 0.90  (v0.6.0 measured 0.920, no Track A effect)
    av-current(kiwi): opt-in threshold 0.94 (v0.6.0 Track B measured 0.980)

The rag-baseline check is opt-in. It runs only if `sentence-transformers` and
`qdrant-client` are installed (i.e. `pip install -e ".[benchmark]"`), so CI runs
without optional deps still pass.

The kiwi check is opt-in via `pip install -e ".[korean]"` AND env var
`ALPHAVAULTS_TOKENIZER=kiwi` (or `pytest tests/test_eval_rag_comparison.py
-k kiwi`). It is skipped on CI machines without kiwipiepy.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

from tests.benchmark import av_runner, rag_baseline


VAULT = Path(__file__).resolve().parent / "fixtures" / "vault"
FIXTURE = Path(__file__).resolve().parent / "benchmark" / "fixtures" / "queries_50.json"

AV_CURRENT_R5_FLOOR = 0.92  # v0.6.0 Track A: regex + rerank, measured 0.930
AV_BM25_R5_FLOOR = 0.90  # v0.6.0 measured 0.920 (no Track A effect on bm25-only)
AV_CURRENT_KIWI_R5_FLOOR = 0.94  # v0.6.0 Track B: kiwi + rerank, measured 0.980
RAG_R5_FLOOR = 0.55  # NEWIT reported 0.74 on ko-only PKM; conservative floor here


@pytest.fixture(scope="module")
def questions() -> list[dict]:
    if not FIXTURE.exists():
        pytest.skip(f"benchmark fixture missing: {FIXTURE}")
    return json.loads(FIXTURE.read_text(encoding="utf-8"))["questions"]


@pytest.fixture(scope="module")
def av_index():
    if not VAULT.exists():
        pytest.skip(f"fixture vault missing: {VAULT}")
    with tempfile.TemporaryDirectory() as tmp:
        out_dir = Path(tmp)
        index_path = av_runner.build_index(VAULT, out_dir)
        yield {"out_dir": out_dir, "index_path": index_path}


def _recall_at_5(retrievals: list[tuple[list[str], list[str]]]) -> float:
    if not retrievals:
        return 0.0
    return sum(av_runner.recall_at_k(r, e, 5) for r, e in retrievals) / len(retrievals)


def test_av_current_recall_at_5_above_floor(questions, av_index):
    retrievals = [
        (av_runner.run_av_current(q["question"], av_index["out_dir"])[0], q["expected_paths"])
        for q in questions
    ]
    r5 = _recall_at_5(retrievals)
    assert r5 >= AV_CURRENT_R5_FLOOR, (
        f"av-current R@5 = {r5:.3f} < {AV_CURRENT_R5_FLOOR} "
        "(v0.6.0 Track A regex measured 0.930 — investigate regression)"
    )


def test_av_bm25_only_recall_at_5_above_floor(questions, av_index):
    retrievals = [
        (av_runner.run_av_bm25_only(q["question"], av_index["index_path"])[0], q["expected_paths"])
        for q in questions
    ]
    r5 = _recall_at_5(retrievals)
    assert r5 >= AV_BM25_R5_FLOOR, (
        f"av-bm25-only R@5 = {r5:.3f} < {AV_BM25_R5_FLOOR} "
        "(v0.6.0 measured 0.920 — investigate regression)"
    )


@pytest.mark.skipif(
    os.environ.get("ALPHAVAULTS_TOKENIZER", "").lower() != "kiwi",
    reason="kiwi mode opt-in: set ALPHAVAULTS_TOKENIZER=kiwi (and install kiwipiepy)",
)
def test_av_current_kiwi_recall_at_5_above_floor(questions, av_index):
    """v0.6.0 Track B opt-in: ko 격차 정조준. 측정 0.980 >= 0.94 floor."""
    retrievals = [
        (av_runner.run_av_current(q["question"], av_index["out_dir"])[0], q["expected_paths"])
        for q in questions
    ]
    r5 = _recall_at_5(retrievals)
    assert r5 >= AV_CURRENT_KIWI_R5_FLOOR, (
        f"av-current(kiwi) R@5 = {r5:.3f} < {AV_CURRENT_KIWI_R5_FLOOR} "
        "(v0.6.0 Track B measured 0.980 — investigate kiwi regression)"
    )


def test_av_exact_keyword_perfect(questions, av_index):
    """exact_keyword queries should be a perfect 1.0 — they target literal page tokens."""
    exact_qs = [q for q in questions if q["query_type"] == "exact_keyword"]
    retrievals = [
        (av_runner.run_av_bm25_only(q["question"], av_index["index_path"])[0], q["expected_paths"])
        for q in exact_qs
    ]
    r5 = _recall_at_5(retrievals)
    assert r5 == 1.0, (
        f"exact_keyword R@5 = {r5:.3f} != 1.0 "
        "(BM25 must match literal page-title tokens; check tokenizer or fixture)"
    )


@pytest.mark.skipif(
    not rag_baseline.deps_available(),
    reason='RAG deps missing — install with `pip install -e ".[benchmark]"`',
)
def test_rag_baseline_recall_at_5_above_floor(questions):
    """Opt-in: requires sentence-transformers + qdrant-client. Slow (BGE-M3 load)."""
    rag_index = rag_baseline.RAGBaselineIndex()
    rag_index.index_vault(VAULT)
    retrievals = [
        (rag_index.query(q["question"])[0], q["expected_paths"]) for q in questions
    ]
    r5 = _recall_at_5(retrievals)
    assert r5 >= RAG_R5_FLOOR, (
        f"rag-baseline R@5 = {r5:.3f} < {RAG_R5_FLOOR} "
        "(NEWIT reported 0.74 on ko-only PKM corpus)"
    )
