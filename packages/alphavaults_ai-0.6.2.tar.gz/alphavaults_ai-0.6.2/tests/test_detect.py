"""Tests for SKIP_DIRS in detect module — regression for .trash noise."""

import os
import tempfile
from pathlib import Path

from alphavaults.detect import SKIP_DIRS, detect


def test_skip_dirs_includes_trash():
    """`.trash` must be skipped (Obsidian/wiki noise)."""
    assert ".trash" in SKIP_DIRS


def test_skip_dirs_includes_baseline():
    """Smoke check: critical baseline entries still present."""
    for name in {"node_modules", ".git", ".venv", "__pycache__", "dist"}:
        assert name in SKIP_DIRS


def test_detect_skips_trash_directory():
    """A .trash subdir with .md files must NOT contribute to detected files."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)

        kept_dir = root / "wiki"
        kept_dir.mkdir()
        (kept_dir / "kept.md").write_text("real content here")

        trash_dir = root / ".trash"
        trash_dir.mkdir()
        (trash_dir / "noise1.md").write_text("trash 1")
        (trash_dir / "noise2.md").write_text("trash 2")

        result = detect(root)
        docs = result["files"]["document"]

        assert any(p.endswith("kept.md") for p in docs)
        assert not any(".trash" in p for p in docs), f"Found .trash files in result: {docs}"
        assert result["total_files"] == 1
