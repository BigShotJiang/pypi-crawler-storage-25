"""Regression tests for IGNORE_PATTERNS wiring in the E안 fast-path.

Smoke test on the production LLMwiki vault (2026-04-23) crashed because
run_documents/index_markdown did not apply contracts.IGNORE_PATTERNS. A
`.history/wiki/INDEX.md` file raised PermissionError mid-walk, and nested
`output/` directories were indexed as if they were real knowledge.
"""

from __future__ import annotations

import json
from pathlib import Path

from alphavaults.contracts import IgnorePattern, to_pathlib_matcher
from alphavaults.index import index_markdown
from alphavaults.pipeline import run_documents


def _write(p: Path, content: str = "# x\n") -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")


def test_to_pathlib_matcher_matches_nested_output_directory():
    pat = IgnorePattern("output/", "glob", frozenset({"rag"}))
    match = to_pathlib_matcher(pat)
    assert match("output/foo.md") is True
    assert match("00. 지식 위키/output/alphavaults/global/wiki.md") is True
    # Component match, not substring: a file literally named output-... is kept.
    assert match("wiki/output-is-good.md") is False


def test_to_pathlib_matcher_matches_nested_history_directory():
    pat = IgnorePattern(".history/", "glob", frozenset({"rag"}))
    match = to_pathlib_matcher(pat)
    assert match(".history/wiki/INDEX.md") is True
    assert match("some/nested/.history/old.md") is True
    assert match("wiki/history-notes.md") is False


def test_run_documents_filters_nested_output_sync_conflict_history(tmp_path):
    vault = tmp_path / "vault"
    # real knowledge (2 files, cross-linked)
    _write(vault / "wiki" / "alpha.md", "# Alpha\n\nSee [[bravo]].\n")
    _write(vault / "wiki" / "bravo.md", "# Bravo\n\nBack to [[alpha]].\n")
    # nested output — production shape: `<subvault>/output/...`
    _write(vault / "00. 지식 위키" / "output" / "alphavaults" / "global" / "noise.md")
    # sync-conflict filename
    _write(vault / "wiki" / "alpha.sync-conflict-20260422-ABCDEF.md")
    # .history dir (also in detect.SKIP_DIRS, belt + suspenders)
    _write(vault / ".history" / "wiki" / "old.md")
    # .obsidian internals
    _write(vault / ".obsidian" / "templates" / "internal.md")
    # .trash — Obsidian trash bin (LLMwiki 스모크에서 17 docs 노이즈로 발견, 2026-04-25)
    _write(vault / ".trash" / "deleted-note.md")

    stats = run_documents(vault, tmp_path / "out")

    assert stats["doc_files"] == 2, (
        f"expected only 2 real docs to survive the filter; got {stats['doc_files']}"
    )

    idx = json.loads((tmp_path / "out" / "search_index.json").read_text(encoding="utf-8"))
    keys = {k.replace("\\", "/") for k in idx["docs"].keys()}
    assert not any("output" in k.split("/") for k in keys), f"output/ leaked: {keys}"
    assert not any("sync-conflict" in k for k in keys), f"sync-conflict leaked: {keys}"
    assert not any(".history" in k.split("/") for k in keys), f".history leaked: {keys}"
    assert not any(".obsidian" in k.split("/") for k in keys), f".obsidian leaked: {keys}"
    assert not any(".trash" in k.split("/") for k in keys), f".trash leaked: {keys}"


def test_index_markdown_skips_files_with_invalid_utf8(tmp_path):
    (tmp_path / "good.md").write_text("# Good\n", encoding="utf-8")
    (tmp_path / "bad.md").write_bytes(b"\xff\xfe\x00\x00not valid utf-8 \x80\x81")

    n = index_markdown(tmp_path, tmp_path / "idx.json")

    assert n == 1
    idx = json.loads((tmp_path / "idx.json").read_text(encoding="utf-8"))
    assert set(idx["docs"].keys()) == {"good.md"}


def test_index_markdown_respects_ignore_matchers(tmp_path):
    _write(tmp_path / "wiki" / "keep.md")
    _write(tmp_path / "output" / "alphavaults" / "drop.md")

    pat = IgnorePattern("output/", "glob", frozenset({"rag"}))
    matcher = to_pathlib_matcher(pat)

    n = index_markdown(tmp_path, tmp_path / "idx.json", ignore_matchers=[matcher])

    assert n == 1
    idx = json.loads((tmp_path / "idx.json").read_text(encoding="utf-8"))
    assert set(idx["docs"].keys()) == {str(Path("wiki") / "keep.md")}
