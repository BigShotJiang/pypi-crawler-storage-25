"""Tests for git-backed wiki version management (v0.4.0).

Each test runs in a throw-away directory that is initialized as a fresh git
repo so `commit_batch` / `list_snapshots` / `restore_snapshot` can exercise
real git commands. A minimal user.email/user.name is configured per-repo so
commits succeed on machines without global git identity.
"""

from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from alphavaults import history  # noqa: E402


def _git(root: Path, *args: str, input_text: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", "-C", str(root), *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        input=input_text,
        check=False,
    )


class GitBackedHistoryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "wiki" / "개발").mkdir(parents=True)
        (self.root / "raw").mkdir(parents=True)

        # Init a local repo so git commands succeed.
        _git(self.root, "init", "-q", "-b", "master")
        _git(self.root, "config", "user.email", "test@local")
        _git(self.root, "config", "user.name", "Test")
        _git(self.root, "config", "commit.gpgsign", "false")
        # An initial commit so HEAD exists (commit_batch expects it).
        (self.root / "README.md").write_text("init\n", encoding="utf-8")
        _git(self.root, "add", "README.md")
        _git(self.root, "commit", "-q", "-m", "init")

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _write(self, rel: str, body: str) -> Path:
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body, encoding="utf-8")
        return p

    # ---------- snapshot_before_write (no-op) ----------

    def test_snapshot_before_write_is_noop(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        self.assertIsNone(history.snapshot_before_write(target, self.root))
        # No .history/ directory should have been created.
        self.assertFalse((self.root / ".history").exists())

    def test_snapshot_disabled_returns_none(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        self.assertIsNone(
            history.snapshot_before_write(target, self.root, enabled=False)
        )

    # ---------- commit_batch ----------

    def test_commit_batch_creates_commit(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        sha = history.commit_batch(
            self.root, [target], "apply_approved 2026-04-19-batch-01"
        )
        self.assertIsNotNone(sha)
        self.assertEqual(len(sha), 40)

        log = _git(self.root, "log", "-1", "--format=%s").stdout.strip()
        self.assertIn("apply_approved", log)
        self.assertIn("(1 files)", log)

    def test_commit_batch_with_no_changes_returns_none(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        history.commit_batch(self.root, [target], "first")
        # Calling again with no modifications → nothing to commit.
        self.assertIsNone(history.commit_batch(self.root, [target], "second"))

    def test_commit_batch_empty_paths_returns_none(self) -> None:
        self.assertIsNone(history.commit_batch(self.root, [], "op"))

    def test_commit_batch_not_a_repo_returns_none(self) -> None:
        other = Path(tempfile.mkdtemp())
        try:
            (other / "x.md").write_text("x", encoding="utf-8")
            self.assertIsNone(
                history.commit_batch(other, [other / "x.md"], "op")
            )
        finally:
            import shutil
            shutil.rmtree(other, ignore_errors=True)

    # ---------- list_snapshots ----------

    def test_list_snapshots_returns_commits_newest_first(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        history.commit_batch(self.root, [target], "first commit")
        target.write_text("v2", encoding="utf-8")
        history.commit_batch(self.root, [target], "second commit")

        snaps = history.list_snapshots(target, self.root)
        self.assertEqual(len(snaps), 2)
        self.assertIn("second", snaps[0]["subject"])
        self.assertIn("first", snaps[1]["subject"])
        for s in snaps:
            self.assertIn("timestamp", s)
            self.assertIn("sha", s)
            self.assertEqual(len(s["sha"]), 40)

    def test_list_snapshots_empty_for_untracked_file(self) -> None:
        target = self._write("wiki/개발/never_committed.md", "v1")
        self.assertEqual(history.list_snapshots(target, self.root), [])

    # ---------- restore_snapshot ----------

    def test_restore_snapshot_by_sha_rewrites_and_commits(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        sha_v1 = history.commit_batch(self.root, [target], "first")
        target.write_text("v2", encoding="utf-8")
        history.commit_batch(self.root, [target], "second")

        history.restore_snapshot(target, self.root, sha_v1)
        self.assertEqual(target.read_text(encoding="utf-8"), "v1")

        snaps = history.list_snapshots(target, self.root)
        self.assertEqual(len(snaps), 3)
        self.assertIn("restore", snaps[0]["subject"])

    def test_restore_snapshot_missing_ref_raises(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        history.commit_batch(self.root, [target], "first")
        with self.assertRaises(FileNotFoundError):
            history.restore_snapshot(target, self.root, "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef")

    # ---------- prune_history ----------

    def test_prune_history_runs_gc_non_destructively(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        history.commit_batch(self.root, [target], "first")
        target.write_text("v2", encoding="utf-8")
        history.commit_batch(self.root, [target], "second")

        before = len(history.list_snapshots(target, self.root))
        result = history.prune_history(self.root)
        after = len(history.list_snapshots(target, self.root))

        self.assertIn("packed_objects", result)
        self.assertEqual(before, after)  # gc never drops reachable history

    def test_prune_dry_run_is_readonly(self) -> None:
        target = self._write("wiki/개발/a.md", "v1")
        history.commit_batch(self.root, [target], "first")
        result = history.prune_history(self.root, dry_run=True)
        self.assertEqual(result["would_remove"], 0)
        self.assertIn("packed_objects", result)

    # ---------- path helpers ----------

    def test_is_wiki_path_accepts_wiki_subdirs(self) -> None:
        self.assertTrue(history.is_wiki_path(self.root / "wiki" / "a.md", self.root))
        self.assertTrue(
            history.is_wiki_path(self.root / "wiki" / "개발" / "a.md", self.root)
        )

    def test_is_wiki_path_rejects_non_wiki(self) -> None:
        self.assertFalse(history.is_wiki_path(self.root / "raw" / "x.md", self.root))
        self.assertFalse(
            history.is_wiki_path(
                self.root / ".history" / "wiki" / "a.md" / "2026.md", self.root
            )
        )


class ReviewCowHookTests(unittest.TestCase):
    """_cow_snapshot is a backwards-compat no-op under git mode — it must not raise."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "wiki" / "개발").mkdir(parents=True)

        from alphavaults import review

        self.review = review

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_cow_snapshot_is_safe_noop_for_wiki_file(self) -> None:
        target = self.root / "wiki" / "개발" / "a.md"
        target.write_text("v1", encoding="utf-8")
        # Should not raise; _cow_snapshot swallows OSError and snapshot_before_write
        # is now a no-op.
        self.review._cow_snapshot(target, self.root)
        self.assertFalse((self.root / ".history").exists())

    def test_cow_snapshot_is_safe_noop_for_non_wiki(self) -> None:
        target = self.root / "raw" / "x.md"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("v1", encoding="utf-8")
        self.review._cow_snapshot(target, self.root)
        self.assertFalse((self.root / ".history").exists())


if __name__ == "__main__":
    unittest.main()
