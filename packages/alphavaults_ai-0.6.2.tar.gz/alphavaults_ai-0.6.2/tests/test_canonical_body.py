from alphavaults.contracts import canonical_body


def test_crlf_normalizes_to_lf():
    a = canonical_body("line1\r\nline2\r\n")
    b = canonical_body("line1\nline2\n")
    assert a == b


def test_cr_only_normalizes_to_lf():
    assert canonical_body("line1\rline2\r") == canonical_body("line1\nline2\n")


def test_trailing_whitespace_stripped_per_line():
    a = canonical_body("hello   \nworld\t\n")
    b = canonical_body("hello\nworld\n")
    assert a == b


def test_frontmatter_removed():
    with_fm = "---\ntitle: A\n---\nbody\n"
    without_fm = "body\n"
    assert canonical_body(with_fm) == canonical_body(without_fm)


def test_empty_input_yields_empty():
    assert canonical_body("") == ""


def test_file_ending_newline_normalized_single():
    a = canonical_body("hello\n\n\n")
    b = canonical_body("hello\n")
    assert a == b
