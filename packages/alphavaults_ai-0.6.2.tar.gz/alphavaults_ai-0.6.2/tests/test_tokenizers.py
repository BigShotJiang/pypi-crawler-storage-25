"""Tokenizer abstraction unit tests (v0.6.0 Track B)."""
from __future__ import annotations

import pytest

from alphavaults.tokenizers import (
    KiwiTokenizer,
    RegexTokenizer,
    get_default_tokenizer,
    get_tokenizer,
)


class TestRegexTokenizer:
    def test_short_english_dropped(self):
        out = RegexTokenizer().tokenize("a is the cat")
        assert "a" not in out and "is" not in out
        assert "the" in out and "cat" in out

    def test_korean_kept(self):
        out = RegexTokenizer().tokenize("모멘텀 팩터")
        assert "모멘텀" in out
        assert "팩터" in out

    def test_punctuation_stripped(self):
        out = RegexTokenizer().tokenize("hello, world!")
        assert out == ["hello", "world"]

    def test_lowercased(self):
        out = RegexTokenizer().tokenize("BM25 ALGORITHM")
        assert "bm25" in out
        assert "algorithm" in out

    def test_name(self):
        assert RegexTokenizer().name == "regex"


class TestKiwiTokenizer:
    def test_extracts_nouns_and_drops_particles(self):
        pytest.importorskip("kiwipiepy")
        tok = KiwiTokenizer()
        out = tok.tokenize("모멘텀 팩터를 측정하는 방법")
        # 알려진 표제어는 단일 토큰으로 추출
        assert "모멘텀" in out
        assert "측정" in out
        assert "방법" in out
        # 조사 결합형 + 단독 조사는 제거
        assert "팩터를" not in out
        assert "를" not in out
        # "팩터" 같은 신조어/외래어 합성명사는 kiwi 가 단음절 NNG 로 분해할
        # 수 있다 (e.g. ["팩", "터"]). 인덱스/쿼리 양쪽이 동일 토큰화기를
        # 거치므로 BM25 매칭은 보장된다 — 분해 자체를 회귀로 보지 않음.
        assert any(t in out for t in ("팩터", "팩"))

    def test_keeps_english_via_regex_fallback(self):
        pytest.importorskip("kiwipiepy")
        tok = KiwiTokenizer()
        out = tok.tokenize("BM25 algorithm with 모멘텀")
        assert "bm25" in out
        assert "algorithm" in out
        assert "모멘텀" in out

    def test_dedupe(self):
        pytest.importorskip("kiwipiepy")
        tok = KiwiTokenizer()
        out = tok.tokenize("모멘텀 모멘텀 모멘텀")
        assert out.count("모멘텀") == 1

    def test_empty_input(self):
        pytest.importorskip("kiwipiepy")
        tok = KiwiTokenizer()
        assert tok.tokenize("") == []

    def test_name(self):
        pytest.importorskip("kiwipiepy")
        assert KiwiTokenizer().name == "kiwi"

    def test_import_error_clear(self, monkeypatch):
        import builtins

        from alphavaults.tokenizers import _reset_cache_for_tests
        _reset_cache_for_tests()

        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "kiwipiepy":
                raise ImportError("simulated missing kiwipiepy")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", fake_import)
        with pytest.raises(ImportError, match="kiwipiepy"):
            KiwiTokenizer()
        _reset_cache_for_tests()


class TestDefaultSelection:
    def test_default_regex(self, monkeypatch):
        monkeypatch.delenv("ALPHAVAULTS_TOKENIZER", raising=False)
        assert get_default_tokenizer().name == "regex"

    def test_env_kiwi(self, monkeypatch):
        pytest.importorskip("kiwipiepy")
        monkeypatch.setenv("ALPHAVAULTS_TOKENIZER", "kiwi")
        assert get_default_tokenizer().name == "kiwi"

    def test_unknown_raises(self):
        with pytest.raises(ValueError):
            get_tokenizer("morphology")

    def test_get_tokenizer_regex(self):
        assert get_tokenizer("regex").name == "regex"
