import json
import pytest
from pathlib import Path
from alphavaults.obsidian import backup_files, restore_file, UUIDMismatchError


def _seed_vault(tmp_path: Path) -> Path:
    obs = tmp_path / ".obsidian"
    obs.mkdir(parents=True, exist_ok=True)
    (obs / "app.json").write_text('{"userIgnoreFilters": []}', encoding="utf-8")
    (obs / "graph.json").write_text('{"search": ""}', encoding="utf-8")
    return tmp_path


def test_backup_creates_uuid_file(tmp_path):
    vault = _seed_vault(tmp_path)
    backup_files(vault)
    vid = (vault / ".obsidian" / "backups" / ".vault_id")
    assert vid.exists()
    uuid = vid.read_text(encoding="utf-8").strip()
    assert len(uuid) >= 8


def test_backup_is_deterministic_per_vault(tmp_path):
    vault = _seed_vault(tmp_path)
    backup_files(vault)
    uuid1 = (vault / ".obsidian" / "backups" / ".vault_id").read_text(encoding="utf-8")
    backup_files(vault)
    uuid2 = (vault / ".obsidian" / "backups" / ".vault_id").read_text(encoding="utf-8")
    assert uuid1 == uuid2


def test_restore_refuses_cross_vault(tmp_path):
    v1 = tmp_path / "v1"; _seed_vault(v1)
    v2 = tmp_path / "v2"; _seed_vault(v2)
    backup_files(v1)
    backup_files(v2)
    v1_bak = next((v1 / ".obsidian" / "backups").glob("app.json.bak-*"))
    with pytest.raises(UUIDMismatchError):
        restore_file(v2, v1_bak, force=False)


def test_restore_force_bypasses_uuid_check(tmp_path):
    v1 = tmp_path / "v1"; _seed_vault(v1)
    v2 = tmp_path / "v2"; _seed_vault(v2)
    backup_files(v1)
    backup_files(v2)
    v1_bak = next((v1 / ".obsidian" / "backups").glob("app.json.bak-*"))
    restore_file(v2, v1_bak, force=True)
