"""Graph-aware rerank tests for query(mode='rerank').

v0.6.0 spec §3.1 #1 — `query.py` 의 `top_k` 파라미터 + 그래프-aware
rerank 분기 검증.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from alphavaults.pipeline import run_documents
from alphavaults.query import (
    _filestem_to_node_ids,
    _graph_proximity,
    _path_proximity_score,
    query,
)


VAULT = Path("tests/fixtures/vault")


@pytest.fixture(scope="module")
def ingested_out():
    """Ingest the standard fixture once for the whole module."""
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        run_documents(VAULT, out)
        yield out


def test_top_k_caps_search_results(ingested_out):
    r3 = query("alpha factor", ingested_out, mode="rerank", top_k=3)
    r10 = query("alpha factor", ingested_out, mode="rerank", top_k=10)
    assert len(r3["search_results"]) <= 3
    assert len(r10["search_results"]) <= 10
    assert len(r10["search_results"]) >= len(r3["search_results"])


def test_default_mode_is_rerank(ingested_out):
    """v0.6.0 default mode = 'rerank' — explicit-mode call should match."""
    r_default = query("momentum factor", ingested_out, top_k=5)
    r_rerank = query("momentum factor", ingested_out, mode="rerank", top_k=5)
    paths_default = [sr["path"] for sr in r_default["search_results"]]
    paths_rerank = [sr["path"] for sr in r_rerank["search_results"]]
    assert paths_default == paths_rerank


def test_rerank_preserves_search_result_keys(ingested_out):
    r = query("momentum factor", ingested_out, mode="rerank", top_k=5)
    for sr in r["search_results"]:
        assert "path" in sr
        assert "title" in sr
        assert "score" in sr
        assert "_graph_proximity" in sr


def test_rerank_boosts_graph_connected_paths(ingested_out):
    """Paths whose stem matches a question-relevant graph node should get
    higher score than the same path under a non-rerank mode (where the
    BM25 score is untouched)."""
    r_rerank = query("momentum factor", ingested_out, mode="rerank", top_k=5)
    r_bfs = query("momentum factor", ingested_out, mode="bfs", top_k=5)
    bfs_score = {sr["path"]: sr["score"] for sr in r_bfs["search_results"]}
    boosted_any = False
    for sr in r_rerank["search_results"]:
        base = bfs_score.get(sr["path"])
        if base is None:
            continue
        if sr.get("_graph_proximity", 0) > 0:
            assert sr["score"] >= base, (
                f"rerank should not lower score for {sr['path']}: "
                f"rerank={sr['score']} vs bfs={base}"
            )
            if sr["score"] > base:
                boosted_any = True
    assert boosted_any, "expected at least one graph-connected hit to be boosted"


def test_legacy_modes_unaffected(ingested_out):
    """mode='bfs'/'dfs'/'hybrid' must keep v0.5.0 behavior — search_results
    score should match raw BM25 (no rerank applied)."""
    from alphavaults.search import search as bm25_search

    raw = bm25_search("momentum factor", ingested_out / "search_index.json", top_k=5)
    raw_score = {r["path"]: r["score"] for r in raw}

    for mode in ("bfs", "dfs", "hybrid"):
        r = query("momentum factor", ingested_out, mode=mode, top_k=5)
        for sr in r["search_results"]:
            base = raw_score.get(sr["path"])
            if base is None:
                continue
            assert sr["score"] == base, f"mode={mode} altered {sr['path']} score"
            assert "_graph_proximity" not in sr


def test_filestem_to_node_ids_basic():
    graph = {
        "nodes": [
            {"id": "ko_alpha_h1", "source_file": "tests\\fixtures\\vault\\wiki\\ko-alpha.md"},
            {"id": "ko_alpha_h2", "source_file": "tests/fixtures/vault/wiki/ko-alpha.md"},
            {"id": "stray", "source_file": ""},
        ]
    }
    out = _filestem_to_node_ids(graph)
    assert out["ko-alpha"] == ["ko_alpha_h1", "ko_alpha_h2"]
    assert "" not in out


def test_graph_proximity_distances():
    graph = {
        "nodes": [{"id": n} for n in ("a", "b", "c", "d")],
        "links": [
            {"source": "a", "target": "b"},
            {"source": "b", "target": "c"},
            {"source": "c", "target": "d"},
        ],
    }
    dist = _graph_proximity(graph, ["a"], depth=2)
    assert dist["a"] == 0
    assert dist["b"] == 1
    assert dist["c"] == 2
    # depth=2 reaches at most 2 hops
    assert "d" not in dist


def test_path_proximity_score_uses_best_node():
    stem_index = {"foo": ["foo_a", "foo_b"]}
    proximity = {"foo_a": 2, "foo_b": 0}
    # 1/(1+0) > 1/(1+2)
    assert _path_proximity_score("wiki/foo.md", stem_index, proximity) == 1.0


def test_path_proximity_score_missing_returns_zero():
    assert _path_proximity_score("wiki/foo.md", {}, {}) == 0.0
    assert _path_proximity_score("", {"foo": ["x"]}, {"x": 0}) == 0.0
