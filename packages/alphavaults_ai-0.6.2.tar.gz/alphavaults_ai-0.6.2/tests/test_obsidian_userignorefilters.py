import json
from pathlib import Path
from alphavaults.obsidian import merge_user_ignore_filters


def test_merge_preserves_existing_and_adds_new(tmp_path):
    app = {"userIgnoreFilters": ["/custom/"]}
    merged = merge_user_ignore_filters(app)
    assert "/custom/" in merged["userIgnoreFilters"]
    from alphavaults.contracts import patterns_for, to_obsidian_filter
    for p in patterns_for("obsidian"):
        assert to_obsidian_filter(p) in merged["userIgnoreFilters"]


def test_merge_is_idempotent():
    app = {"userIgnoreFilters": []}
    m1 = merge_user_ignore_filters(app)
    m2 = merge_user_ignore_filters(m1)
    assert sorted(m1["userIgnoreFilters"]) == sorted(m2["userIgnoreFilters"])


def test_output_filter_is_present_after_merge_v3_regression():
    app = {}
    m = merge_user_ignore_filters(app)
    joined = " ".join(m["userIgnoreFilters"])
    assert "output" in joined, "v3 spec §5.3: output/ must be in userIgnoreFilters"
