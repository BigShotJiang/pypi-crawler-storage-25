from pathlib import Path
import networkx as nx
from alphavaults.lint import check_broken_wikilinks, BrokenLinkReport


class _FS:
    def __init__(self, g): self._g = g
    def load_nodes(self): return []
    def load_edges(self): return []
    def load_graph(self): return self._g


def test_broken_wikilink_detected(tmp_path):
    vault = tmp_path
    (vault / "a.md").write_text("see [[b]]\n", encoding="utf-8")
    g = nx.MultiDiGraph(); g.add_node("a")
    reps = check_broken_wikilinks(vault, _FS(g))
    assert any(r.target == "b" for r in reps)


def test_valid_wikilink_not_reported(tmp_path):
    vault = tmp_path
    (vault / "a.md").write_text("see [[b]]\n", encoding="utf-8")
    (vault / "b.md").write_text("b body\n", encoding="utf-8")
    g = nx.MultiDiGraph(); g.add_node("a"); g.add_node("b")
    reps = check_broken_wikilinks(vault, _FS(g))
    assert not any(r.target == "b" for r in reps)
