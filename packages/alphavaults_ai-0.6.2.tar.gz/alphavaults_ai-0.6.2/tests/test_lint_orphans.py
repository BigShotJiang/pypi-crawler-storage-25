import networkx as nx
from alphavaults.lint import check_orphans, OrphanReport


class _FakeStorage:
    def __init__(self, graph):
        self._g = graph
    def load_nodes(self): return []
    def load_edges(self): return []
    def load_graph(self): return self._g


def test_check_orphans_flags_isolated_node():
    g = nx.MultiDiGraph()
    g.add_node("a")
    g.add_node("b"); g.add_node("c")
    g.add_edge("b", "c", kind="wikilink")
    reports = check_orphans(_FakeStorage(g))
    ids = [r.node_id for r in reports]
    assert "a" in ids
    assert "b" not in ids and "c" not in ids


def test_check_orphans_regression_incoming_only_b1():
    g = nx.MultiDiGraph()
    g.add_node("a"); g.add_node("b")
    g.add_edge("b", "a", kind="wikilink")
    reports = check_orphans(_FakeStorage(g))
    assert not any(r.node_id == "a" for r in reports)


def test_orphan_report_has_node_id_field():
    g = nx.MultiDiGraph(); g.add_node("solo")
    reports = check_orphans(_FakeStorage(g))
    assert reports and isinstance(reports[0], OrphanReport)
    assert reports[0].node_id == "solo"
