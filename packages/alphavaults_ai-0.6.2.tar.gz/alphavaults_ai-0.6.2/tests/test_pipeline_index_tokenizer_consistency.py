"""v0.6.2 sweep M1-family — pipeline 의 인덱스 append 헬퍼들이 index 헤더의
토크나이저를 존중하는지 회귀.

pipeline._index_source_docs / ingest._update_search_index_for_ingested /
query._update_search_index_for_query 세 곳 모두 dead `_tokenize` (regex-only)
shim 을 쓰던 버그를 잡았으므로, 헤더가 'kiwi' 로 표기된 인덱스에 append 할 때
가짜 KiwiTokenizer 가 호출되는지로 확인한다 (실제 kiwipiepy 의존 회피).
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from alphavaults.index import index_markdown
from alphavaults.tokenizers import RegexTokenizer, _TOKENIZER_CACHE


class StubKiwi(RegexTokenizer):
    """Regex behaviour with name='kiwi' — purely a probe for header dispatch."""

    name = "kiwi"
    calls = 0

    def tokenize(self, text):  # type: ignore[override]
        StubKiwi.calls += 1
        return super().tokenize(text)


@pytest.fixture
def stub_kiwi(monkeypatch):
    StubKiwi.calls = 0
    # Pre-seed the tokenizer cache so get_tokenizer('kiwi') returns the stub
    # without importing kiwipiepy.
    monkeypatch.setitem(_TOKENIZER_CACHE, "kiwi", StubKiwi())
    yield StubKiwi


def _seed_kiwi_index(tmp_path: Path) -> tuple[Path, Path]:
    docs_dir = tmp_path / "docs"
    index_path = tmp_path / "index.json"
    docs_dir.mkdir()
    (docs_dir / "seed.md").write_text("# Seed\nbody body body", encoding="utf-8")
    # Build a regex index then mutate the header to 'kiwi' so the helpers under
    # test see a kiwi-flagged index without invoking real kiwipiepy.
    index_markdown(docs_dir, index_path)
    payload = json.loads(index_path.read_text(encoding="utf-8"))
    payload["tokenizer"] = "kiwi"
    index_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return docs_dir, index_path


def test_index_source_docs_uses_header_tokenizer(tmp_path: Path, stub_kiwi):
    from alphavaults.pipeline import _index_source_docs

    docs_dir, index_path = _seed_kiwi_index(tmp_path)
    (docs_dir / "extra.md").write_text("# Extra\nadditional body", encoding="utf-8")
    _index_source_docs(docs_dir, ["extra.md"], index_path)

    assert stub_kiwi.calls >= 1, "header was 'kiwi' but regex shim was used instead"


def test_update_search_index_for_ingested_uses_header_tokenizer(tmp_path: Path, stub_kiwi):
    from alphavaults.ingest import _update_search_index_for_ingested

    docs_dir, index_path = _seed_kiwi_index(tmp_path)
    wiki_dir = tmp_path / "wiki"
    ingested = wiki_dir / "ingested"
    ingested.mkdir(parents=True)
    (ingested / "page.md").write_text("# Page\nfresh body", encoding="utf-8")

    # The helper resolves index_path = output_dir/search_index.json. Mirror that.
    output_dir = tmp_path / "out"
    output_dir.mkdir()
    (output_dir / "search_index.json").write_bytes(index_path.read_bytes())

    _update_search_index_for_ingested(wiki_dir, output_dir)
    assert stub_kiwi.calls >= 1


def test_update_search_index_for_query_uses_header_tokenizer(tmp_path: Path, stub_kiwi):
    from alphavaults.query import _update_search_index_for_query

    docs_dir, index_path = _seed_kiwi_index(tmp_path)
    output_dir = tmp_path / "out"
    output_dir.mkdir()
    wiki_dir = output_dir / "wiki"
    wiki_dir.mkdir()
    (output_dir / "search_index.json").write_bytes(index_path.read_bytes())

    saved = wiki_dir / "saved.md"
    saved.write_text("# Saved\nbody body body", encoding="utf-8")
    _update_search_index_for_query(saved, output_dir)
    assert stub_kiwi.calls >= 1
