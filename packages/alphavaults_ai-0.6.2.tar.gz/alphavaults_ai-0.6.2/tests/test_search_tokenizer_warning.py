"""v0.6.2 sweep M2 — search() 시점 토크나이저 의도 mismatch 경고.

ALPHAVAULTS_TOKENIZER 환경변수 의도가 인덱스 헤더 토크나이저와 다를 때
사용자가 silently 다른 토큰화 결과를 받지 않도록 UserWarning 발생.
"""
from __future__ import annotations

import warnings
from pathlib import Path

from alphavaults.index import index_markdown
from alphavaults.search import search


def _write(p: Path, body: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body, encoding="utf-8")


def _seed(tmp_path: Path) -> Path:
    docs_dir = tmp_path / "docs"
    index_path = tmp_path / "index.json"
    # Multiple docs so IDF stays positive for typical query terms.
    _write(docs_dir / "a.md", "# Alpha\nfactor analysis page")
    _write(docs_dir / "b.md", "# Beta\ndifferent body keywords entirely")
    _write(docs_dir / "c.md", "# Gamma\nthird unrelated content section")
    _write(docs_dir / "d.md", "# Delta\nfourth distinct material example")
    index_markdown(docs_dir, index_path)
    return index_path


def test_search_warns_when_env_pref_differs(tmp_path: Path, monkeypatch) -> None:
    index_path = _seed(tmp_path)  # regex header
    monkeypatch.setenv("ALPHAVAULTS_TOKENIZER", "kiwi")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        search("factor", index_path)
        messages = [str(w.message) for w in caught if issubclass(w.category, UserWarning)]

    assert any("ALPHAVAULTS_TOKENIZER='kiwi'" in m and "regex" in m for m in messages), (
        f"expected env-mismatch UserWarning, got: {messages}"
    )


def test_search_no_warning_when_env_matches(tmp_path: Path, monkeypatch) -> None:
    index_path = _seed(tmp_path)
    monkeypatch.setenv("ALPHAVAULTS_TOKENIZER", "regex")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        search("factor", index_path)
        env_msgs = [
            str(w.message)
            for w in caught
            if issubclass(w.category, UserWarning) and "ALPHAVAULTS_TOKENIZER" in str(w.message)
        ]
    assert env_msgs == []


def test_search_no_warning_when_env_unset(tmp_path: Path, monkeypatch) -> None:
    index_path = _seed(tmp_path)
    monkeypatch.delenv("ALPHAVAULTS_TOKENIZER", raising=False)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        search("factor", index_path)
        env_msgs = [
            str(w.message)
            for w in caught
            if issubclass(w.category, UserWarning) and "ALPHAVAULTS_TOKENIZER" in str(w.message)
        ]
    assert env_msgs == []


def test_search_no_warning_on_empty_index(tmp_path: Path, monkeypatch) -> None:
    """No docs → nothing to query, mismatch warning suppressed."""
    index_path = tmp_path / "index.json"
    monkeypatch.setenv("ALPHAVAULTS_TOKENIZER", "kiwi")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        results = search("anything", index_path)
        env_msgs = [
            str(w.message)
            for w in caught
            if issubclass(w.category, UserWarning) and "ALPHAVAULTS_TOKENIZER" in str(w.message)
        ]
    assert results == []
    assert env_msgs == []
