import json
from pathlib import Path
from alphavaults.obsidian import apply_patch


def _seed(tmp_path: Path):
    obs = tmp_path / ".obsidian"
    obs.mkdir()
    (obs / "app.json").write_text('{"userIgnoreFilters": []}', encoding="utf-8")
    (obs / "graph.json").write_text('{"search": "", "hideUnresolved": false}',
                                    encoding="utf-8")
    return tmp_path


def test_apply_patch_updates_both_files(tmp_path):
    vault = _seed(tmp_path)
    apply_patch(vault, dry_run=False)
    app = json.loads((vault / ".obsidian" / "app.json").read_text(encoding="utf-8"))
    graph = json.loads((vault / ".obsidian" / "graph.json").read_text(encoding="utf-8"))
    assert any("output" in f for f in app["userIgnoreFilters"])
    assert graph["hideUnresolved"] is True


def test_apply_patch_is_idempotent(tmp_path):
    vault = _seed(tmp_path)
    apply_patch(vault, dry_run=False)
    before_app = (vault / ".obsidian" / "app.json").read_text(encoding="utf-8")
    before_graph = (vault / ".obsidian" / "graph.json").read_text(encoding="utf-8")
    apply_patch(vault, dry_run=False)
    after_app = (vault / ".obsidian" / "app.json").read_text(encoding="utf-8")
    after_graph = (vault / ".obsidian" / "graph.json").read_text(encoding="utf-8")
    assert before_app == after_app
    assert before_graph == after_graph


def test_apply_patch_dry_run_does_not_write(tmp_path):
    vault = _seed(tmp_path)
    before = (vault / ".obsidian" / "app.json").read_text(encoding="utf-8")
    report = apply_patch(vault, dry_run=True)
    after = (vault / ".obsidian" / "app.json").read_text(encoding="utf-8")
    assert before == after
    assert report["dry_run"] is True
    assert report["would_change"]


def test_apply_patch_creates_backup_when_writing(tmp_path):
    vault = _seed(tmp_path)
    apply_patch(vault, dry_run=False)
    backups = list((vault / ".obsidian" / "backups").glob("app.json.bak-*"))
    assert len(backups) >= 1
