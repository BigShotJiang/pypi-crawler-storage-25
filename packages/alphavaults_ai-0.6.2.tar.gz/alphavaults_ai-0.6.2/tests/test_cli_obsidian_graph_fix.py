import json
import subprocess
import sys
from pathlib import Path


def _av(*args, cwd=None):
    return subprocess.run(
        [sys.executable, "-m", "alphavaults", *args],
        capture_output=True, text=True, cwd=cwd,
    )


def _seed(tmp_path: Path) -> Path:
    obs = tmp_path / ".obsidian"
    obs.mkdir(parents=True, exist_ok=True)
    (obs / "app.json").write_text('{}', encoding="utf-8")
    (obs / "graph.json").write_text('{}', encoding="utf-8")
    return tmp_path


def test_help_exists():
    r = _av("obsidian-graph-fix", "--help")
    assert r.returncode == 0
    out = r.stdout + r.stderr
    assert "--dry-run" in out
    assert "--vault" in out


def test_dry_run_does_not_modify(tmp_path):
    vault = _seed(tmp_path)
    before = (vault / ".obsidian" / "app.json").read_text(encoding="utf-8")
    r = _av("obsidian-graph-fix", "--vault", str(vault), "--dry-run")
    after = (vault / ".obsidian" / "app.json").read_text(encoding="utf-8")
    assert before == after
    assert r.returncode == 0


def test_actual_run_modifies_and_creates_backup(tmp_path):
    vault = _seed(tmp_path)
    r = _av("obsidian-graph-fix", "--vault", str(vault))
    assert r.returncode == 0
    backups = list((vault / ".obsidian" / "backups").glob("app.json.bak-*"))
    assert len(backups) >= 1
    app = json.loads((vault / ".obsidian" / "app.json").read_text(encoding="utf-8"))
    assert any("output" in f for f in app["userIgnoreFilters"])


def test_restore_cross_vault_rejected(tmp_path):
    v1 = _seed(tmp_path / "v1")
    v2 = _seed(tmp_path / "v2")
    # Apply patch to v1 (creates backup + UUID)
    _av("obsidian-graph-fix", "--vault", str(v1))
    # Try to restore v1's backup into v2 without --force
    v1_bak = next((v1 / ".obsidian" / "backups").glob("app.json.bak-*"))
    # v2 needs a UUID first so the mismatch can be detected
    _av("obsidian-graph-fix", "--vault", str(v2))
    r = _av("obsidian-graph-fix", "--vault", str(v2), "--restore", str(v1_bak))
    assert r.returncode != 0
    out = r.stdout + r.stderr
    assert "REJECT" in out.upper() or "mismatch" in out.lower()
