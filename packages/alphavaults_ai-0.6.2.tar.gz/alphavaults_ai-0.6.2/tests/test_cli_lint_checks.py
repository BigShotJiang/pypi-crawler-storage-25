import json
import subprocess
import sys


def _av(*args):
    return subprocess.run([sys.executable, "-m", "alphavaults", *args],
                          capture_output=True, text=True)


def test_lint_help_lists_new_flags():
    r = _av("lint", "--help")
    out = r.stdout + r.stderr
    assert "--check" in out
    assert "--json" in out


def test_lint_check_orphans_json_parses(tmp_path):
    # Even with empty vault + empty storage, --check orphans --json should emit JSON
    r = _av("lint", "--check", "orphans", "--json", "--vault", str(tmp_path))
    assert r.returncode in (0, 1)
    data = json.loads(r.stdout)
    assert "orphans" in data


def test_lint_check_all_json_parses(tmp_path):
    (tmp_path / "a.md").write_text("a\n", encoding="utf-8")
    r = _av("lint", "--check", "all", "--json", "--vault", str(tmp_path))
    assert r.returncode in (0, 1)
    data = json.loads(r.stdout)
    assert "orphans" in data
    assert "broken_links" in data
    assert "rag_consistency" in data


def test_lint_without_check_still_works_legacy(tmp_path):
    # Existing behavior: `alphavaults lint <path>` should NOT crash even on empty dir.
    # It may error internally, but the subparser must accept it.
    r = _av("lint", str(tmp_path))
    # Legacy exit codes vary; just confirm the subparser accepts no --check.
    assert r.returncode in (0, 1, 2)
