from alphavaults.obsidian import merge_graph_defaults


def test_merge_graph_defaults_sets_hide_unresolved():
    assert merge_graph_defaults({})["hideUnresolved"] is True


def test_merge_graph_defaults_preserves_user_custom():
    m = merge_graph_defaults({"search": "tag:#custom"})
    assert m["search"] == "tag:#custom"
    assert m["hideUnresolved"] is True


def test_merge_graph_defaults_hides_attachments():
    m = merge_graph_defaults({})
    assert m["showAttachments"] is False
