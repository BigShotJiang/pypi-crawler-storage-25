"""Tokenizer abstraction for AlphaVaults BM25 layer.

Default: RegexTokenizer (v0.5.0 호환).
Opt-in: KiwiTokenizer (한국어 형태소 분석, kiwipiepy 의존).

사용:
    from alphavaults.tokenizers import RegexTokenizer, KiwiTokenizer
    tok = RegexTokenizer()  # 기본
    tok = KiwiTokenizer()   # 선택 (kiwipiepy 설치 필요)

환경변수 `ALPHAVAULTS_TOKENIZER=kiwi` 로 기본값을 KiwiTokenizer 로 전환.
"""
from __future__ import annotations

import os
import re
from typing import Protocol


def _is_cjk(char: str) -> bool:
    """Check if a character is CJK (Chinese/Japanese/Korean)."""
    cp = ord(char)
    return (
        (0x3000 <= cp <= 0x9FFF)
        or (0xAC00 <= cp <= 0xD7AF)  # Hangul Syllables
        or (0xF900 <= cp <= 0xFAFF)
    )


class Tokenizer(Protocol):
    """Minimal tokenizer interface used by index/search/query layers."""

    name: str

    def tokenize(self, text: str) -> list[str]: ...


class RegexTokenizer:
    """v0.5.0 호환 정규식 토크나이저.

    - 구두점 제거, 공백 분할
    - 영어 토큰: len > 2 만 유지
    - CJK 토큰: 모든 길이 유지 (1자도 의미 있음)
    """

    name = "regex"

    def tokenize(self, text: str) -> list[str]:
        cleaned = re.sub(r"[^\w\s]", " ", text.lower())
        tokens: list[str] = []
        for t in cleaned.split():
            if not t:
                continue
            has_cjk = any(_is_cjk(c) for c in t)
            if has_cjk or len(t) > 2:
                tokens.append(t)
        return tokens


class KiwiTokenizer:
    """한국어 형태소 분석 토크나이저 (kiwipiepy).

    - 명사 (NNG/NNP/NNB), 외국어 (SL), 한자 (SH), 숫자 (SN), 동사 (VV),
      형용사 (VA) 어간만 유지.
    - 조사 (JKO/JKS/JKB 등), 어미 (EF/ETM 등), 부호 (SP/SS) 등은 drop.
    - 영어 단어는 Kiwi 가 SL 로 잡지만 모든 토큰화기에서 균일한 처리를
      위해 RegexTokenizer fallback 결과와 합집합.
    """

    name = "kiwi"
    _KEEP_POS = frozenset({"NNG", "NNP", "NNB", "SL", "SH", "SN", "VV", "VA"})

    def __init__(self) -> None:
        try:
            from kiwipiepy import Kiwi  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(
                "KiwiTokenizer requires kiwipiepy. "
                "Install with: pip install 'alphavaults-ai[korean]' "
                "(or pip install kiwipiepy)"
            ) from exc
        self._kiwi = Kiwi()
        self._regex = RegexTokenizer()

    def tokenize(self, text: str) -> list[str]:
        tokens: list[str] = []
        seen: set[str] = set()
        try:
            analyzed = self._kiwi.tokenize(text)
        except Exception:
            return self._regex.tokenize(text)

        for token in analyzed:
            if token.tag not in self._KEEP_POS:
                continue
            form = token.form.lower()
            if not form:
                continue
            has_cjk = any(_is_cjk(c) for c in form)
            if not (has_cjk or len(form) > 2):
                continue
            if form not in seen:
                seen.add(form)
                tokens.append(form)

        for t in self._regex.tokenize(text):
            if not any(_is_cjk(c) for c in t) and t not in seen:
                seen.add(t)
                tokens.append(t)
        return tokens


_TOKENIZER_CACHE: dict[str, Tokenizer] = {}


def get_tokenizer(name: str) -> Tokenizer:
    """Return a cached Tokenizer by canonical name.

    Kiwi model loading is heavy (~1–2s); caching avoids re-loading on every
    `search()` call. Cache is per-process — safe for the read-only Tokenizer
    contract.
    """
    key = (name or "regex").lower()
    if key not in ("regex", "kiwi"):
        raise ValueError(f"unknown tokenizer: {name!r}")
    cached = _TOKENIZER_CACHE.get(key)
    if cached is not None:
        return cached
    if key == "kiwi":
        cached = KiwiTokenizer()
    else:
        cached = RegexTokenizer()
    _TOKENIZER_CACHE[key] = cached
    return cached


def get_default_tokenizer() -> Tokenizer:
    """Return the tokenizer chosen by `ALPHAVAULTS_TOKENIZER` env var."""
    return get_tokenizer(os.environ.get("ALPHAVAULTS_TOKENIZER", "regex"))


def _reset_cache_for_tests() -> None:
    """Test-only: drop cached tokenizers (used by monkeypatch paths)."""
    _TOKENIZER_CACHE.clear()
