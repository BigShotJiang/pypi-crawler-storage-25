"""RULES.md validation for AlphaVaults and LLMwiki automation."""

from __future__ import annotations

from pathlib import Path

from alphavaults.config import get_rules_path

REQUIRED_SECTIONS = [
    "# LLMwiki + AlphaVaults RULES",
    "## Runtime Priority",
    "## Directory Roles",
    "## Graph Hygiene",
    "## Automation Boundaries",
    "## Agent Curation",
    "## Agentic Tagging Policy",
    "## Backfill And Incremental Policy",
    "## Auto-Promotion Criteria",
    "## Hold Criteria",
    "## Sources Policy",
    "## Slack Approval",
    "## Git Recovery",
    "## Conflict Handling",
]

FORBIDDEN_PHRASES = [
    "항상 무승인",
    "무조건 wiki/에 직접 쓰기",
    "raw/ 원본 수정 허용",
    "output/alphavaults/global 을 wiki로 복사",
    "빈도 기반 기계 태깅 허용",
    "본문 전체 재작성 허용",
]


def check_rules(path: Path | None = None) -> dict:
    """Validate the canonical RULES.md file.

    Returns:
        Dict with ok, path, missing_sections, forbidden_phrases, warnings.
    """
    rules_path = Path(path) if path else get_rules_path()
    result = {
        "ok": False,
        "path": str(rules_path),
        "missing_sections": [],
        "forbidden_phrases": [],
        "warnings": [],
    }

    if not rules_path.exists():
        result["warnings"].append("RULES.md does not exist.")
        result["missing_sections"] = REQUIRED_SECTIONS[:]
        return result

    content = rules_path.read_text(encoding="utf-8", errors="ignore")
    for section in REQUIRED_SECTIONS:
        if section not in content:
            result["missing_sections"].append(section)

    lowered = content.lower()
    for phrase in FORBIDDEN_PHRASES:
        if phrase.lower() in lowered:
            result["forbidden_phrases"].append(phrase)

    if "승인" not in content or "Slack" not in content:
        result["warnings"].append("Slack approval policy is not explicit enough.")
    if "git commit" not in lowered:
        result["warnings"].append("Git commit recovery policy is not explicit enough.")
    if "sync-conflict" not in lowered:
        result["warnings"].append("Syncthing sync-conflict hold rule is not explicit enough.")
    if "3~6" not in content and "3-6" not in content:
        result["warnings"].append("Tag count guideline (3~6, max 8) is not explicit enough.")
    if "한국어" not in content:
        result["warnings"].append("Korean-first tagging and linking policy is not explicit enough.")
    if "백필" not in content or "증분" not in content:
        result["warnings"].append("Backfill/incremental curation policy is not explicit enough.")
    if "본문 대규모 재작성" not in content:
        result["warnings"].append("Safe write boundary for curator edits is not explicit enough.")

    result["ok"] = not result["missing_sections"] and not result["forbidden_phrases"]
    return result


def default_rules_content() -> str:
    """Return the default canonical RULES.md content."""
    return """# LLMwiki + AlphaVaults RULES

이 파일은 Claude Code, Codex, AlphaVaults 자동화, LLMwiki 컴파일러가 공유하는 최상위 운영 규칙이다. 하위 `CLAUDE.md`, `AGENTS.md`, hook, review batch 규칙은 이 파일과 충돌하면 안 된다.

## Runtime Priority

- Primary runtime: Claude Code.
- Secondary runtime: Codex.
- Claude 계정 리밋, 비용, 장애 상황에서는 Codex가 같은 규칙을 따른다.
- 모든 LLMwiki/AlphaVaults 작업은 먼저 이 파일을 읽은 것으로 간주한다.

## Directory Roles

- `raw/`: 사람이 던진 원본, 자동 저장 원본, 외부 입력의 보존 영역이다. 원본은 수정하지 않는다.
- `wiki/`: 승인된 최종 지식 영역이다. 자동화는 Slack 승인 후에만 수정한다.
- `output/alphavaults/global/`: AlphaVaults 전역 관측 산출물이다. 사람이 다듬는 최종 지식이 아니다.
- `output/alphavaults/review/`: 자동 분류, 자동 작성, Slack 승인 대기, patch 기록 영역이다.
- `log.md`: append-only 작업 기록이다.

## Graph Hygiene

- Obsidian 그래프는 사람 지식 레이어를 보는 용도다.
- `output/alphavaults/global/` 와 `output/alphavaults/review/` 는 그래프에서 기본적으로 숨긴다.
- 기계 산출물의 `[[index]]`, `INDEX.md`, raw 경로 위키링크는 사람 지식 그래프에 섞지 않는다.
- 그래프에 남길 링크는 `wiki/` 문서끼리의 의미 있는 연결만 허용한다.

## Automation Boundaries

- AlphaVaults는 모든 프로젝트 파일과 LLMwiki raw 메모를 관측할 수 있다.
- 자동화는 review batch를 만들 수 있다.
- 자동화는 Slack 승인 없는 `wiki/` 변경을 금지한다.
- 자동화는 `raw/` 원본 수정을 금지한다.
- 자동화는 `output/alphavaults/global/` 내용을 `wiki/`로 복붙하지 않는다.
- 자동화는 근거를 요약하고 Sources로 연결한다.

## Agent Curation

- AlphaVaults는 이번 단계에서 `문서 재작성기`가 아니라 `문서 큐레이터`다.
- 에이전트는 문서의 목적, 기능, 결정, 사용 맥락을 직접 읽고 태그와 링크를 제안한다.
- 허용 수정 범위는 frontmatter, 태그, 관련 링크, 문서 형식 보정, 아주 짧은 요약 보강까지다.
- 본문 대규모 재작성, 새 허브 문서 대량 생성, 공격적 요약 재편집은 금지한다.
- review 항목에는 왜 이 태그와 링크를 붙였는지 짧은 근거를 남긴다.

## Agentic Tagging Policy

- 태그는 고정 사전형이 아니라 RULES 경계 안에서 자율 태깅한다.
- 태그는 문서를 읽고 맥락 태그 3~6개를 우선 제안하고, 최대 8개를 넘기지 않는다.
- 태그 축은 `domain`, `type`, `핵심 대상`, `프로젝트/맥락` 순으로 잡는다.
- 흔한 일반어, 빈도 기반 기계 태깅, 한 문서 과다 태깅은 금지한다.
- 비슷한 태그가 이미 있으면 신규 생성보다 기존 표현 재사용을 우선한다.
- 태그와 링크 이름은 한국어를 기본으로 하고, 영어는 고유명사나 기술명일 때만 유지한다.

## Backfill And Incremental Policy

- 초기 1회는 기존 `wiki/` 전체를 백필 대상으로 본다.
- 이후에는 변경 문서만 증분 처리한다.
- 변경 없는 문서는 재처리를 최소화한다.
- reject 된 문서는 원문을 유지하고, 문서 내용이 바뀔 때만 다시 큐레이션 후보가 될 수 있다.
- hold 된 문서는 다음 batch로 이월하되, 원문을 직접 수정하지 않는다.

## Auto-Promotion Criteria

다음 조건을 모두 만족하면 자동 승격 후보로 만든다.

- 재사용 가능한 지식이다.
- 기존 `wiki/` 문서와 연결 가능하다.
- 출처가 `raw/`, AlphaVaults global output, 프로젝트 파일 중 하나로 추적 가능하다.
- 프로젝트, 결정, 구조, 운영 규칙, 반복 작업 지식 중 하나에 해당한다.
- 단순 로그가 아니라 이후 작업자가 다시 참고할 가치가 있다.

## Hold Criteria

다음 조건 중 하나라도 있으면 자동 적용하지 말고 `Hold` 상태로 둔다.

- 기존 `wiki/` 내용과 충돌한다.
- 출처가 불명확하다.
- 민감정보, 토큰, 계정, 개인 연락처가 포함될 가능성이 있다.
- 코드 변경 지시와 지식 정리가 섞여 있다.
- `sync-conflict` 파일이 감지된다.
- Git working tree에 예상 외 변경이 있다.
- patch가 clean apply 되지 않는다.

## Sources Policy

- 최종 `wiki/` 문서 하단에는 `## Sources` 섹션을 둔다.
- AlphaVaults 근거는 `AlphaVaults:` 접두사를 붙인다.
- raw 원본은 상대 경로로 기록한다.
- 프로젝트 파일은 root alias를 포함해 `claude/...` 또는 `codex/...`로 기록한다.
- 출처가 불충분한 내용은 추론으로 명시하거나 보류한다.

## Slack Approval

- Slack은 승인 표면이다.
- 버튼은 `Approve`, `Reject`, `Hold` 세 가지다.
- 승인자는 설정된 Slack user id 목록에 포함된 사용자만 가능하다.
- `Approve`는 적용 대기 상태를 만든다.
- `Reject`는 후보를 폐기한다.
- `Hold`는 다음 리뷰로 넘긴다.
- Slack signing secret 검증 실패, 오래된 timestamp, 승인자 불일치 요청은 거부한다.

## Git Recovery

- Git 저장소 범위는 이 `00. 지식 위키` 폴더로 제한한다.
- 별도 백업 폴더는 만들지 않는다.
- 적용 전 patch 파일을 남긴다.
- 적용 후 즉시 git commit을 만든다.
- commit message는 `AlphaVaults review: <batch-id> <item-id>` 형식을 따른다.
- 문제가 생기면 Git revert로 되돌린다.

## Conflict Handling

- Syncthing `.git` 동기화는 금지한다.
- `.stignore`에는 `.git`이 포함되어야 한다.
- `*.sync-conflict-*` 파일이 발견되면 자동 적용을 보류한다.
- Git working tree가 더러우면 자동 적용을 보류한다. 단, 현재 적용 대상 patch와 log 변경만 예상되는 경우는 예외다.
- 실패한 적용은 `apply.log`에 남기고 Slack에 실패 알림을 보낸다.
"""
