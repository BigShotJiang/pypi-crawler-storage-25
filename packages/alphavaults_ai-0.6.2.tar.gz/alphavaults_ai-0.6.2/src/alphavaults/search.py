"""Search layer — BM25 search (local, zero tokens)."""

from __future__ import annotations

import math
import os
import warnings
from collections import Counter
from pathlib import Path

from .index import index_markdown, load_index
from .tokenizers import RegexTokenizer, _is_cjk, get_tokenizer


# Backwards-compat shim: existing callers (or third-party tests) that imported
# `alphavaults.search._tokenize` keep working with the regex behaviour.
_DEFAULT_REGEX_TOKENIZER = RegexTokenizer()


def _tokenize(text: str) -> list[str]:
    """Regex tokenization (kept for legacy callers — use Tokenizer instances)."""
    return _DEFAULT_REGEX_TOKENIZER.tokenize(text)


def _snippet(content_tokens: list[str], query_tokens: set[str], width: int = 30) -> str:
    """Build a snippet around the first matching token.

    Joins tokens back to text, finds first query match position,
    returns +-width chars around it. Falls back to first 100 chars.
    """
    text = " ".join(content_tokens)
    for qt in query_tokens:
        pos = text.find(qt)
        if pos >= 0:
            start = max(0, pos - width)
            end = min(len(text), pos + len(qt) + width)
            prefix = "..." if start > 0 else ""
            suffix = "..." if end < len(text) else ""
            return prefix + text[start:end] + suffix
    # No match — first 100 chars
    return text[:100] + ("..." if len(text) > 100 else "")


def _field_boost(tokens: list[str], query_token: str, exact_weight: float, fuzzy_weight: float) -> float:
    """Return a field-specific score boost for exact or fuzzy token matches."""
    if query_token in tokens:
        return exact_weight
    if any(_is_cjk(c) for c in query_token):
        for token in tokens:
            if token.startswith(query_token) or query_token in token:
                return fuzzy_weight
    return 0.0


def search(query: str, index_path: Path, top_k: int = 5) -> list[dict]:
    """BM25 search over a markdown index.

    Args:
        query: Search query string.
        index_path: Path to the search index JSON.
        top_k: Number of top results to return.

    Returns:
        List of dicts: [{path, title, score, snippet, headings}, ...].
    """
    index_path = Path(index_path)
    index_data = load_index(index_path)
    docs = index_data.get("docs", {})
    idf = index_data.get("idf", {})
    tokenizer_name = index_data.get("tokenizer", "regex")
    env_pref = os.environ.get("ALPHAVAULTS_TOKENIZER", "").strip().lower()
    if env_pref and env_pref != tokenizer_name and docs:
        warnings.warn(
            f"ALPHAVAULTS_TOKENIZER={env_pref!r} but index at {index_path} was "
            f"built with {tokenizer_name!r}. Query uses the index's tokenizer "
            f"({tokenizer_name!r}); rebuild the index to switch tokenizers.",
            UserWarning,
            stacklevel=2,
        )
    tokenizer = get_tokenizer(tokenizer_name)
    cjk_fuzzy_enabled = tokenizer_name == "regex"

    if not docs:
        return []

    query_tokens = tokenizer.tokenize(query)
    if not query_tokens:
        return []
    query_lower = query.lower().strip()
    direct_terms = [token for token in query_tokens if len(token) >= 3]

    # BM25 parameters
    k1 = 1.5
    b = 0.75

    # Average document length
    doc_lengths = {path: len(doc["tokens"]) for path, doc in docs.items()}
    avgdl = sum(doc_lengths.values()) / len(doc_lengths) if doc_lengths else 1.0

    results = []

    for path, doc in docs.items():
        tokens = doc["tokens"]
        dl = len(tokens)
        if dl == 0:
            continue

        title_tokens = tokenizer.tokenize(doc.get("title", ""))
        heading_tokens = tokenizer.tokenize(" ".join(doc.get("headings", [])))
        path_tokens = tokenizer.tokenize(path.replace("/", " ").replace("\\", " "))

        tf_counts = Counter(tokens)
        score = 0.0
        coverage = 0
        title_path_hits = 0
        direct_term_hits = 0

        for qt in query_tokens:
            # Exact match first
            tf = tf_counts.get(qt, 0)
            idf_val = idf.get(qt)
            matched = tf > 0

            # CJK fuzzy: only meaningful for regex-tokenized indexes.
            # Kiwi-mode indexes already split into morphemes, so substring
            # matching would over-match (e.g. "팩" inside "팩스").
            if cjk_fuzzy_enabled and tf == 0 and any(_is_cjk(c) for c in qt):
                for doc_token, count in tf_counts.items():
                    if doc_token.startswith(qt) or qt in doc_token:
                        tf += count
                        matched = True
                        if idf_val is None:
                            idf_val = idf.get(doc_token)

            title_boost = _field_boost(title_tokens, qt, exact_weight=2.5, fuzzy_weight=2.0)
            heading_boost = _field_boost(heading_tokens, qt, exact_weight=1.5, fuzzy_weight=1.0)
            path_boost = _field_boost(path_tokens, qt, exact_weight=1.0, fuzzy_weight=0.75)
            if matched or title_boost or heading_boost or path_boost:
                coverage += 1
            if title_boost or path_boost:
                title_path_hits += 1

            if tf == 0 or idf_val is None:
                continue
            numerator = tf * (k1 + 1)
            denominator = tf + k1 * (1 - b + b * dl / avgdl)
            score += idf_val * numerator / denominator
            score += idf_val * title_boost
            score += idf_val * heading_boost
            score += idf_val * path_boost

        title_lower = doc.get("title", "").lower()
        path_lower = path.lower()
        if query_lower and query_lower in title_lower:
            score += 6.0
        if query_lower and any(query_lower in heading.lower() for heading in doc.get("headings", [])):
            score += 3.0
        if query_lower and query_lower in path_lower:
            score += 2.0
        for term in direct_terms:
            if term in title_lower or term in path_lower:
                direct_term_hits += 1
        score += direct_term_hits * 4.0

        if score > 0:
            results.append({
                "path": path,
                "title": doc["title"],
                "score": round(score, 4),
                "snippet": _snippet(tokens, set(query_tokens)),
                "headings": doc.get("headings", []),
                "_coverage": coverage,
                "_title_path_hits": title_path_hits,
                "_direct_term_hits": direct_term_hits,
            })

    # Sort by token coverage first, then title/path direct hits, then score.
    results.sort(
        key=lambda r: (r["_direct_term_hits"], r["_coverage"], r["_title_path_hits"], r["score"]),
        reverse=True,
    )

    trimmed = results[:top_k]
    for result in trimmed:
        result.pop("_coverage", None)
        result.pop("_title_path_hits", None)
        result.pop("_direct_term_hits", None)
    return trimmed


def build_index(docs_dir: Path, index_path: Path) -> int:
    """Index all markdown files (wrapper for index.index_markdown).

    Args:
        docs_dir: Directory containing markdown files to index.
        index_path: Path to write the search index.

    Returns:
        Number of documents indexed.
    """
    return index_markdown(Path(docs_dir), Path(index_path))
