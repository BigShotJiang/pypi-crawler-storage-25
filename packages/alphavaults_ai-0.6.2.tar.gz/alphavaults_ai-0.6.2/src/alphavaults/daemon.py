"""Cross-platform daemon for automatic AlphaVaults updates.

Supports:
- macOS: launchd (LaunchAgents)
- Windows: Task Scheduler (schtasks)
- Linux: systemd user service
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path

from alphavaults.branding import (
    APP_NAME,
    DAEMON_LABEL,
    DAEMON_TASK_NAME,
    SYSTEMD_SERVICE_NAME,
)
from alphavaults.config import get_global_output_dir
from alphavaults.global_ import normalize_roots

LABEL = DAEMON_LABEL
TASK_NAME = DAEMON_TASK_NAME


def _detect_os() -> str:
    """Detect OS: 'macos', 'windows', or 'linux'."""
    system = platform.system()
    if system == "Darwin":
        return "macos"
    elif system == "Windows":
        return "windows"
    elif system == "Linux":
        return "linux"
    else:
        return "linux"  # fallback


# ---------------------------------------------------------------------------
# macOS — launchd
# ---------------------------------------------------------------------------

_MACOS_PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{LABEL}.plist"

_MACOS_PLIST = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" \
"http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{python}</string>
        <string>-m</string>
        <string>alphavaults.daemon</string>
        <string>run</string>
        <string>--configured</string>
    </array>
    <key>StartInterval</key>
    <integer>{interval}</integer>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log}</string>
    <key>StandardErrorPath</key>
    <string>{err}</string>
</dict>
</plist>
"""


def _macos_install(roots: list[dict], interval: int, output_dir: Path) -> bool:
    plist = _MACOS_PLIST.format(
        label=LABEL,
        python=sys.executable,
        interval=interval,
        log=str(output_dir / "daemon.log"),
        err=str(output_dir / "daemon.err"),
    )
    _MACOS_PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    _MACOS_PLIST_PATH.write_text(plist, encoding="utf-8")
    try:
        subprocess.run(["launchctl", "load", str(_MACOS_PLIST_PATH)],
                        capture_output=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return _MACOS_PLIST_PATH.exists()


def _macos_uninstall() -> bool:
    if not _MACOS_PLIST_PATH.exists():
        return True
    try:
        subprocess.run(["launchctl", "unload", str(_MACOS_PLIST_PATH)],
                        capture_output=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    try:
        _MACOS_PLIST_PATH.unlink()
    except OSError:
        return False
    return not _MACOS_PLIST_PATH.exists()


def _macos_status() -> dict:
    status = {"installed": _MACOS_PLIST_PATH.exists(), "running": False,
              "config_path": str(_MACOS_PLIST_PATH)}
    if status["installed"]:
        try:
            r = subprocess.run(["launchctl", "list", LABEL],
                               capture_output=True, text=True, timeout=5)
            status["running"] = r.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    return status


# ---------------------------------------------------------------------------
# Windows — Task Scheduler
# ---------------------------------------------------------------------------

def _win_task_exists() -> bool:
    try:
        r = subprocess.run(
            ["schtasks", "/Query", "/TN", TASK_NAME],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
        )
        return r.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _windows_install(roots: list[dict], interval: int, output_dir: Path) -> bool:
    python = sys.executable
    log_path = output_dir / "daemon.log"

    # schtasks interval is in minutes (minimum 1)
    minutes = max(1, interval // 60)

    # Create a wrapper script that schtasks will execute
    wrapper = output_dir / "alphavaults_daemon.bat"
    wrapper.write_text(
        f'@echo off\r\n'
        f'"{python}" -m alphavaults.daemon run --configured >> "{log_path}" 2>&1\r\n',
        encoding="utf-8",
    )

    # Remove existing task if any
    if _win_task_exists():
        try:
            subprocess.run(["schtasks", "/Delete", "/TN", TASK_NAME, "/F"],
                           capture_output=True, timeout=10)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    try:
        r = subprocess.run(
            [
                "schtasks", "/Create",
                "/TN", TASK_NAME,
                "/TR", f'"{wrapper}"',
                "/SC", "MINUTE",
                "/MO", str(minutes),
                "/F",  # force overwrite
            ],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15,
        )
        return r.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _windows_uninstall() -> bool:
    if not _win_task_exists():
        return True
    try:
        r = subprocess.run(
            ["schtasks", "/Delete", "/TN", TASK_NAME, "/F"],
            capture_output=True, timeout=10,
        )
        # Clean up wrapper
        wrapper = get_global_output_dir() / "alphavaults_daemon.bat"
        if wrapper.exists():
            wrapper.unlink()
        return r.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _windows_status() -> dict:
    installed = _win_task_exists()
    running = False
    if installed:
        try:
            r = subprocess.run(
                ["schtasks", "/Query", "/TN", TASK_NAME, "/FO", "LIST"],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
            )
            running = "Running" in (r.stdout or "")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    return {"installed": installed, "running": running}


# ---------------------------------------------------------------------------
# Linux — systemd user service
# ---------------------------------------------------------------------------

_SYSTEMD_DIR = Path.home() / ".config" / "systemd" / "user"
_SERVICE_NAME = SYSTEMD_SERVICE_NAME
_SERVICE_PATH = _SYSTEMD_DIR / f"{_SERVICE_NAME}.service"
_TIMER_PATH = _SYSTEMD_DIR / f"{_SERVICE_NAME}.timer"

_SYSTEMD_SERVICE = """\
[Unit]
Description=AlphaVaults Knowledge Base Auto-Update

[Service]
Type=oneshot
ExecStart={python} -m alphavaults.daemon run --configured
StandardOutput=append:{log}
StandardError=append:{err}

[Install]
WantedBy=default.target
"""

_SYSTEMD_TIMER = """\
[Unit]
Description=AlphaVaults periodic update timer

[Timer]
OnBootSec=60
OnUnitActiveSec={interval}s
Persistent=true

[Install]
WantedBy=timers.target
"""


def _linux_install(roots: list[dict], interval: int, output_dir: Path) -> bool:
    _SYSTEMD_DIR.mkdir(parents=True, exist_ok=True)

    service = _SYSTEMD_SERVICE.format(
        python=sys.executable,
        log=str(output_dir / "daemon.log"),
        err=str(output_dir / "daemon.err"),
    )
    timer = _SYSTEMD_TIMER.format(interval=interval)

    _SERVICE_PATH.write_text(service, encoding="utf-8")
    _TIMER_PATH.write_text(timer, encoding="utf-8")

    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"],
                        capture_output=True, timeout=10)
        subprocess.run(["systemctl", "--user", "enable", "--now", f"{_SERVICE_NAME}.timer"],
                        capture_output=True, timeout=10)
        return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        # systemd not available — files created but not activated
        return _SERVICE_PATH.exists()


def _linux_uninstall() -> bool:
    try:
        subprocess.run(["systemctl", "--user", "disable", "--now", f"{_SERVICE_NAME}.timer"],
                        capture_output=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    for p in [_SERVICE_PATH, _TIMER_PATH]:
        if p.exists():
            try:
                p.unlink()
            except OSError:
                return False

    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"],
                        capture_output=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return not _SERVICE_PATH.exists()


def _linux_status() -> dict:
    installed = _TIMER_PATH.exists()
    running = False
    if installed:
        try:
            r = subprocess.run(
                ["systemctl", "--user", "is-active", f"{_SERVICE_NAME}.timer"],
                capture_output=True, text=True, timeout=5,
            )
            running = r.stdout.strip() == "active"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    return {"installed": installed, "running": running}


# ---------------------------------------------------------------------------
# Public API — auto-dispatches by OS
# ---------------------------------------------------------------------------

def install_daemon(roots=None, interval: int = 3600) -> bool:
    """Install platform-appropriate daemon for periodic AlphaVaults updates.

    Args:
        roots: Root directories to watch for projects. Defaults to configured roots.
        interval: Seconds between runs (default 3600 = 1 hour).

    Returns:
        True if daemon was installed successfully.
    """
    root_entries = normalize_roots(roots)
    output_dir = get_global_output_dir()
    output_dir.mkdir(parents=True, exist_ok=True)

    os_type = _detect_os()
    if os_type == "macos":
        return _macos_install(root_entries, interval, output_dir)
    elif os_type == "windows":
        return _windows_install(root_entries, interval, output_dir)
    elif os_type == "linux":
        return _linux_install(root_entries, interval, output_dir)
    return False


def uninstall_daemon() -> bool:
    """Remove the daemon for the current platform.

    Returns:
        True if successfully removed.
    """
    os_type = _detect_os()
    if os_type == "macos":
        return _macos_uninstall()
    elif os_type == "windows":
        return _windows_uninstall()
    elif os_type == "linux":
        return _linux_uninstall()
    return False


def daemon_status() -> dict:
    """Check daemon status for the current platform.

    Returns:
        Dict with keys: installed, running, os, last_log_line, mechanism.
    """
    os_type = _detect_os()

    mechanism_map = {
        "macos": "launchd",
        "windows": "Task Scheduler",
        "linux": "systemd",
    }

    if os_type == "macos":
        status = _macos_status()
    elif os_type == "windows":
        status = _windows_status()
    elif os_type == "linux":
        status = _linux_status()
    else:
        status = {"installed": False, "running": False}

    status["os"] = os_type
    status["mechanism"] = mechanism_map.get(os_type, "unknown")

    # Last log line (cross-platform)
    log_path = get_global_output_dir() / "daemon.log"
    status["last_log_line"] = ""
    if log_path.exists():
        try:
            content = log_path.read_text(encoding="utf-8", errors="ignore")
            lines = content.strip().split("\n")
            if lines:
                status["last_log_line"] = lines[-1]
        except OSError:
            pass

    return status


# ---------------------------------------------------------------------------
# Entry point for daemon execution
# ---------------------------------------------------------------------------

def _run_daemon(root_args: list[str] | None = None) -> None:
    """Entry point: run global incremental update."""
    from datetime import datetime, timezone
    from alphavaults.global_ import run_global_incremental

    roots = None if not root_args or root_args == ["--configured"] else root_args
    output_dir = get_global_output_dir()

    timestamp = datetime.now(timezone.utc).isoformat()
    try:
        result = run_global_incremental(roots, output_dir)
        try:
            from alphavaults.review import generate_review_batch
            review = generate_review_batch(notify=True)
            result["review_batch"] = review.get("batch_id")
            result["review_items"] = len(review.get("items", []))
            if review.get("bridge", {}).get("enabled"):
                result["telebot_bridge"] = {
                    "found": review["bridge"].get("found", 0),
                    "written": review["bridge"].get("written", 0),
                    "updated": review["bridge"].get("updated", 0),
                    "unchanged": review["bridge"].get("unchanged", 0),
                }
            if review.get("slack"):
                result["slack"] = review["slack"]
        except Exception as review_error:  # noqa: BLE001 - daemon must keep logging
            result["review_error"] = str(review_error)
        print(f"[{timestamp}] {APP_NAME} daemon: {result}")
    except Exception as e:
        print(f"[{timestamp}] {APP_NAME} daemon error: {e}")


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "run":
        _run_daemon(sys.argv[2:])
    else:
        print("Usage: python -m alphavaults.daemon run [--configured|root_path ...]")
        sys.exit(1)
