"""Bridge legacy AlphaMate Telebot Obsidian captures into the current LLMwiki raw queue."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
import re

from alphavaults.config import (
    get_telebot_bridge_dir,
    get_telebot_legacy_root,
    get_telebot_sync_days,
)

_DAY_RE = re.compile(r"^(?P<day>\d{4}-\d{2}-\d{2})\b")


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def _yaml_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _extract_scalar(text: str, key: str) -> str | None:
    prefix = f"- {key}:"
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix):
            return stripped[len(prefix) :].strip().strip("`")
    return None


def _extract_section_bullets(text: str, heading: str, limit: int) -> list[str]:
    lines = text.splitlines()
    capture = False
    bullets: list[str] = []
    target = f"## {heading}"
    for line in lines:
        stripped = line.rstrip()
        if stripped == target:
            capture = True
            continue
        if capture and stripped.startswith("## "):
            break
        if capture and stripped.lstrip().startswith("- "):
            bullets.append(stripped.strip())
            if len(bullets) >= limit:
                break
    return bullets


def _recent_outbox_files(outbox_dir: Path, limit: int = 8) -> list[Path]:
    if not outbox_dir.exists():
        return []
    return sorted(
        outbox_dir.glob("*.md"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )[:limit]


def _prefer_legacy_wiki(current: Path, challenger: Path) -> Path:
    current_name = current.name
    challenger_name = challenger.name
    current_auto = "AlphaMate 자동수집" in current_name
    challenger_auto = "AlphaMate 자동수집" in challenger_name
    if challenger_auto and not current_auto:
        return challenger
    if current_auto and not challenger_auto:
        return current
    return challenger if challenger.stat().st_mtime >= current.stat().st_mtime else current


def _bridge_note(
    day: str,
    legacy_root: Path,
    legacy_wiki: Path,
    legacy_raw_md: Path,
    legacy_raw_jsonl: Path,
    outbox_dir: Path,
) -> str:
    wiki_text = _read_text(legacy_wiki)
    event_count = _extract_scalar(wiki_text, "event_count") or "unknown"
    success_count = _extract_scalar(wiki_text, "success_count") or "unknown"
    attention_count = _extract_scalar(wiki_text, "attention_count") or "unknown"

    source_summary = _extract_section_bullets(wiki_text, "소스별 요약", limit=10)
    job_summary = _extract_section_bullets(wiki_text, "작업별 요약", limit=12)
    outbox_files = _recent_outbox_files(outbox_dir, limit=8)

    lines = [
        "---",
        "type: auto_capture",
        "status: inbox",
        "review: needed",
        "source: alphamate_telebot",
        "automation: alphavaults",
        f"legacy_day: {day}",
        f"legacy_root: {_yaml_quote(str(legacy_root))}",
        f"legacy_wiki: {_yaml_quote(str(legacy_wiki))}",
        f"legacy_raw_md: {_yaml_quote(str(legacy_raw_md))}",
        f"legacy_raw_jsonl: {_yaml_quote(str(legacy_raw_jsonl))}",
        f"generated_at: {_yaml_quote(datetime.now().astimezone().isoformat(timespec='seconds'))}",
        "---",
        "",
        f"# AlphaMate 텔레그램 자동수집 브리지 {day}",
        "",
        "## 요약",
        "기존 AlphaMate Telebot 자동수집 파이프라인이 별도 Obsidian 경로에 기록한 일일 결과를 현재 LLMwiki 승인 흐름으로 연결한 bridge 노트다.",
        "",
        "## 수집 현황",
        f"- event_count: {event_count}",
        f"- success_count: {success_count}",
        f"- attention_count: {attention_count}",
        "",
        "## 소스별 요약",
    ]

    if source_summary:
        lines.extend(source_summary)
    else:
        lines.append("- legacy wiki에 소스 요약이 아직 없다.")

    lines.extend(["", "## 작업별 요약"])
    if job_summary:
        lines.extend(job_summary)
    else:
        lines.append("- legacy wiki에 작업별 요약이 아직 없다.")

    lines.extend(["", "## 최근 Telegram 산출물"])
    lines.append(f"- outbox_count: {len(list(outbox_dir.glob('*.md'))) if outbox_dir.exists() else 0}")
    if outbox_files:
        for path in outbox_files:
            stamp = datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat(timespec="seconds")
            lines.append(f"- `{path.name}` ({stamp})")
    else:
        lines.append("- telegram_outbox 산출물이 아직 없다.")

    lines.extend([
        "",
        "## Sources",
        f"- legacy wiki: `{legacy_wiki}`",
        f"- legacy raw markdown: `{legacy_raw_md}`",
        f"- legacy raw jsonl: `{legacy_raw_jsonl}`",
        f"- legacy telegram outbox: `{outbox_dir}`",
    ])
    return "\n".join(lines).rstrip() + "\n"


def sync_telebot_bridge(
    days: int | None = None,
    legacy_root: Path | None = None,
    bridge_dir: Path | None = None,
) -> dict:
    """Sync recent legacy AlphaMate Telebot daily notes into the current raw queue."""
    legacy_root = Path(legacy_root or get_telebot_legacy_root())
    bridge_dir = Path(bridge_dir or get_telebot_bridge_dir())
    days = max(1, int(days or get_telebot_sync_days()))

    result = {
        "legacy_root": str(legacy_root),
        "bridge_dir": str(bridge_dir),
        "days": days,
        "found": 0,
        "written": 0,
        "updated": 0,
        "unchanged": 0,
        "files": [],
    }

    wiki_dir = legacy_root / "wiki"
    raw_dir = legacy_root / "raw"
    if not wiki_dir.exists():
        result["error"] = "legacy wiki directory not found"
        return result

    cutoff = date.today() - timedelta(days=days - 1)
    candidates_by_day: dict[str, Path] = {}
    for legacy_wiki in sorted(wiki_dir.glob("*.md")):
        match = _DAY_RE.match(legacy_wiki.stem)
        if not match:
            continue
        day = match.group("day")
        try:
            day_value = date.fromisoformat(day)
        except ValueError:
            continue
        if day_value < cutoff:
            continue
        previous = candidates_by_day.get(day)
        candidates_by_day[day] = _prefer_legacy_wiki(previous, legacy_wiki) if previous else legacy_wiki

    candidates = sorted(candidates_by_day.items())

    bridge_dir.mkdir(parents=True, exist_ok=True)
    result["found"] = len(candidates)

    for day, legacy_wiki in candidates:
        legacy_raw_md = raw_dir / f"{day}.md"
        legacy_raw_jsonl = raw_dir / f"{day}.jsonl"
        outbox_dir = raw_dir / "telegram_outbox" / day
        bridge_path = bridge_dir / f"{day} AlphaMate 텔레그램 자동수집 브리지.md"
        content = _bridge_note(day, legacy_root, legacy_wiki, legacy_raw_md, legacy_raw_jsonl, outbox_dir)

        previous = bridge_path.read_text(encoding="utf-8", errors="ignore") if bridge_path.exists() else None
        if previous == content:
            result["unchanged"] += 1
        else:
            bridge_path.write_text(content, encoding="utf-8", newline="\n")
            if previous is None:
                result["written"] += 1
            else:
                result["updated"] += 1
        result["files"].append(str(bridge_path))

    return result
