"""Pipeline orchestrator: detect -> extract -> graph -> wiki -> index."""

from __future__ import annotations

import json
from pathlib import Path

from alphavaults.compile import compile
from alphavaults.index import index_markdown, update_index
from alphavaults.detect import detect
from alphavaults.extract import extract_ast, extract_document_structure
from alphavaults.build import build_graph
from alphavaults.cluster import cluster, score_cohesion
from alphavaults.wiki import generate_wiki, _community_label
from alphavaults.export import export_json, export_html
from alphavaults.report import generate_report
from alphavaults.cache import get_dirty_files, update_cache
from alphavaults.branding import LOCAL_OUTPUT_DIR


def run(source_dir: Path, output_dir: Path = None, **kwargs) -> dict:
    """Full pipeline orchestrator.

    Args:
        source_dir: Root directory of the project.
        output_dir: Directory for AlphaVaults output (default: source_dir/alphavaults-out).
        **kwargs: Additional options passed to sub-steps.

    Returns:
        Dict with stats: {nodes, edges, communities, wiki_pages, index_docs, total_words}.
    """
    source_dir = Path(source_dir)
    if output_dir is None:
        output_dir = source_dir / LOCAL_OUTPUT_DIR
    output_dir = Path(output_dir)

    # Run compile (detect -> extract -> graph -> cluster -> wiki -> export)
    result = compile(source_dir, output_dir, **kwargs)

    # Detect again to get doc files (compile doesn't expose detection)
    detection = detect(source_dir)

    # Build search index on wiki pages + source documents
    wiki_dir = output_dir / "wiki"
    index_path = output_dir / "search_index.json"
    index_docs = 0
    if wiki_dir.exists():
        index_docs = index_markdown(wiki_dir, index_path)

    # Also index source .md documents for better search coverage
    doc_files = detection["files"].get("document", [])
    if doc_files:
        _index_source_docs(source_dir, doc_files, index_path)
        index_docs += len(doc_files)

    result["index_docs"] = index_docs
    return result


def _index_source_docs(source_dir: Path, doc_files: list[str], index_path: Path) -> None:
    """Append source .md documents to the existing search index.

    Uses the existing index header's tokenizer so kiwi-mode indexes stay
    coherent (regex tokens mixed into a kiwi index would silently degrade
    retrieval).
    """
    from alphavaults.index import load_index, _extract_title, _extract_headings, _hash_content, _compute_idf
    from alphavaults.tokenizers import get_tokenizer
    import json

    index_data = load_index(index_path)
    docs = index_data.get("docs", {})
    tokenizer = get_tokenizer(index_data.get("tokenizer", "regex"))

    for rel_path in doc_files:
        full_path = source_dir / rel_path
        if not full_path.exists():
            continue
        try:
            content = full_path.read_text(encoding="utf-8", errors="ignore")
        except (OSError, IOError):
            continue
        key = f"source/{rel_path}"
        docs[key] = {
            "title": _extract_title(content) or Path(rel_path).stem,
            "headings": _extract_headings(content),
            "tokens": tokenizer.tokenize(content),
            "hash": _hash_content(content),
        }

    index_data["docs"] = docs
    index_data["doc_count"] = len(docs)
    index_data["idf"] = _compute_idf(docs)
    index_path.write_text(json.dumps(index_data, ensure_ascii=False, indent=2), encoding="utf-8")


def run_documents(
    vault_dir: Path,
    output_dir: Path | None = None,
    tokenizer=None,
) -> dict:
    """E안 fast-path for .md-only vaults (no code, no LLM).

    Skips tree-sitter AST extraction; goes straight through:
    detect → extract_document_structure → build_graph → cluster →
    wiki generation → BM25 index over the original .md files.

    Args:
        vault_dir: Vault root with markdown files (Obsidian-style, wikilinks ok).
        output_dir: Output dir (default: vault_dir/alphavaults-out).
        tokenizer: Optional Tokenizer instance for the BM25 index. Default
            falls back to `ALPHAVAULTS_TOKENIZER` env (regex/kiwi).

    Returns:
        {doc_files, nodes, edges, communities, wiki_pages, index_docs,
         ingest_seconds}.
    """
    import time

    vault_dir = Path(vault_dir)
    if output_dir is None:
        output_dir = vault_dir / LOCAL_OUTPUT_DIR
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    from alphavaults.contracts import patterns_for, to_pathlib_matcher

    rag_matchers = [to_pathlib_matcher(p) for p in patterns_for("rag")]

    def _ignored(rel: str) -> bool:
        norm = rel.replace("\\", "/")
        return any(m(norm) for m in rag_matchers)

    t0 = time.time()
    detection = detect(vault_dir)
    all_doc_rel = detection["files"].get("document", [])
    doc_rel_paths = [r for r in all_doc_rel if not _ignored(r)]
    doc_paths = [vault_dir / rel for rel in doc_rel_paths]

    extraction = extract_document_structure(doc_paths)
    G = build_graph(extraction)
    communities = cluster(G)
    cohesion = score_cohesion(G, communities)
    labels = {cid: _community_label(G, members) for cid, members in communities.items()}

    wiki_pages = generate_wiki(G, communities, labels, output_dir, cohesion=cohesion)
    export_json(G, communities, output_dir / "graph.json")
    export_html(G, communities, labels, output_dir / "graph.html")

    # Index the *original* vault markdown so BM25 results reference vault paths
    # that callers (and known_answers.json) expect (e.g. "wiki/ko-alpha.md").
    index_path = output_dir / "search_index.json"
    index_docs = index_markdown(
        vault_dir,
        index_path,
        ignore_matchers=rag_matchers,
        tokenizer=tokenizer,
    )

    elapsed = time.time() - t0
    return {
        "doc_files": len(doc_rel_paths),
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "communities": len(communities),
        "wiki_pages": wiki_pages,
        "index_docs": index_docs,
        "ingest_seconds": round(elapsed, 3),
    }


def run_incremental(source_dir: Path, output_dir: Path = None) -> dict:
    """Incremental pipeline: only process changed files.

    Args:
        source_dir: Root directory of the project.
        output_dir: Directory for AlphaVaults output.

    Returns:
        Dict with stats: {changed, nodes, edges, communities, wiki_pages, index_docs}
        or {changed: 0} if nothing changed.
    """
    source_dir = Path(source_dir)
    if output_dir is None:
        output_dir = source_dir / LOCAL_OUTPUT_DIR
    output_dir = Path(output_dir)

    # If output doesn't exist yet, run full pipeline
    graph_path = output_dir / "graph.json"
    if not graph_path.exists():
        return run(source_dir, output_dir)

    # Detect files
    detection = detect(source_dir)
    code_files = [source_dir / f for f in detection["files"].get("code", [])]
    doc_files = [source_dir / f for f in detection["files"].get("document", [])]

    # Check which files changed (code + documents)
    dirty_code = get_dirty_files(code_files, output_dir)
    dirty_docs = get_dirty_files(doc_files, output_dir)
    dirty_files = dirty_code + dirty_docs

    if not dirty_files:
        return {"changed": 0}

    # Extract AST for dirty code files, document structure for dirty doc files
    from alphavaults.extract import extract_document_structure
    code_extraction = extract_ast(dirty_code) if dirty_code else {"nodes": [], "edges": []}
    doc_extraction = extract_document_structure(dirty_docs) if dirty_docs else {"nodes": [], "edges": []}
    extraction = {
        "nodes": code_extraction["nodes"] + doc_extraction["nodes"],
        "edges": code_extraction["edges"] + doc_extraction["edges"],
    }

    # Load existing graph data
    existing_data = json.loads(graph_path.read_text(encoding="utf-8"))
    existing_nodes = {n["id"]: n for n in existing_data.get("nodes", [])}
    existing_links = existing_data.get("links", [])

    # Remove stale nodes from dirty files, then add new/updated ones
    dirty_sources = {str(f) for f in dirty_files}
    existing_nodes = {
        nid: n for nid, n in existing_nodes.items()
        if n.get("source_file") not in dirty_sources
    }
    for node in extraction["nodes"]:
        existing_nodes[node["id"]] = node

    # For edges, remove old edges from dirty files
    kept_links = [
        link for link in existing_links
        if link.get("source_file") not in dirty_sources
    ]
    # Add new edges
    for edge in extraction["edges"]:
        kept_links.append({
            "source": edge["source"],
            "target": edge["target"],
            "relation": edge.get("relation", ""),
            "confidence": edge.get("confidence", ""),
            "confidence_score": edge.get("confidence_score", 1.0),
            "source_file": edge.get("source_file", ""),
            "weight": edge.get("weight", 1.0),
        })

    # Rebuild graph from merged data
    merged_extraction = {
        "nodes": list(existing_nodes.values()),
        "edges": kept_links,
    }
    G = build_graph(merged_extraction)

    # Re-cluster
    communities = cluster(G)
    cohesion = score_cohesion(G, communities)
    labels = {}
    for cid, members in communities.items():
        labels[cid] = _community_label(G, members)

    # Regenerate wiki
    wiki_pages = generate_wiki(G, communities, labels, output_dir, cohesion=cohesion)

    # Re-export
    export_json(G, communities, output_dir / "graph.json")
    export_html(G, communities, labels, output_dir / "graph.html")

    # Update search index
    wiki_dir = output_dir / "wiki"
    index_path = output_dir / "search_index.json"
    index_docs = 0
    if wiki_dir.exists():
        index_docs = update_index(wiki_dir, index_path)

    # Update cache for processed files
    for f in dirty_files:
        update_cache(f, output_dir)

    return {
        "changed": len(dirty_files),
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "communities": len(communities),
        "wiki_pages": wiki_pages,
        "index_docs": index_docs,
    }
