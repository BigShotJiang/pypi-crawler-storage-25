"""Allow running alphavaults as a module: python3 -m alphavaults"""
from alphavaults.cli import main

main()
