"""CLI entry point for AlphaVaults."""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

from alphavaults import __version__
from alphavaults.branding import (
    APP_NAME,
    CLI_NAME,
    DAEMON_LABEL,
    LOCAL_OUTPUT_DIR,
    SKILL_NAME,
)
from alphavaults.config import get_global_output_dir


def cmd_install(args) -> None:
    """alphavaults install — AI tool detection + integration + skill registration + git hook."""
    from alphavaults.hooks import install_git_hook
    from alphavaults.integrations import detect_ai_tools, install_all_integrations, AI_TOOLS

    project_root = Path(args.path).resolve()

    # 1. Detect AI tools
    print("Detecting AI tools...")
    detected = detect_ai_tools(project_root)
    detected_names = {t["name"] for t in detected}
    for tool in AI_TOOLS:
        if tool["name"] in detected_names:
            # Find the detected_file for this tool
            det = next(t for t in detected if t["name"] == tool["name"])
            print(f"  \u2713 {tool['name']} ({det['detected_file']} found)")
        else:
            print(f"  \u2717 {tool['name']} (not detected)")

    # 2. Install integrations
    print("\nInstalling integrations...")
    if detected:
        integration_results = install_all_integrations(project_root)
        for r in integration_results:
            if r["status"] == "installed":
                # Find the rules_file for this tool
                tool = next(t for t in AI_TOOLS if t["name"] == r["name"])
                print(f"  \u2713 {r['name']} \u2014 {tool['rules_file']} updated")
            elif r["status"] == "already_exists":
                print(f"  \u2713 {r['name']} \u2014 already configured (skip)")
            else:
                print(f"  \u2717 {r['name']} \u2014 {r['status']}")

    # 3. Copy SKILL.md to ~/.claude/skills/alphavaults/
    skill_src = Path(__file__).parent.parent.parent / "skill" / "SKILL.md"
    skill_dst_dir = Path.home() / ".claude" / "skills" / SKILL_NAME
    if skill_src.exists():
        skill_dst_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(skill_src, skill_dst_dir / "SKILL.md")
        print(f"  \u2713 Claude Code \u2014 Skill registered (~/.claude/skills/{SKILL_NAME}/)")
    else:
        print("  \u2717 Skill: SKILL.md not found (skip)")

    # 4. Install git hook if in a git repo
    if (project_root / ".git").exists():
        ok = install_git_hook(project_root)
        if ok:
            print(f"  \u2713 Git hook \u2014 post-commit installed")
        else:
            print(f"  \u2717 Git hook \u2014 installation failed")
    else:
        print(f"  \u2717 Git hook \u2014 not a git repo (skip)")

    # 5. Install auto-context prompt hook
    from alphavaults.hooks import install_prompt_hook
    if install_prompt_hook():
        print(f"  \u2713 Auto-context hook \u2014 installed (AI auto-queries {APP_NAME})")
    else:
        print(f"  \u2717 Auto-context hook \u2014 installation failed")

    # 6. Install daemon (auto-update every 5 min) unless --no-daemon
    if not getattr(args, "no_daemon", False):
        from alphavaults.daemon import install_daemon, daemon_status
        status = daemon_status()
        if status.get("installed") and status.get("running"):
            print(f"  \u2713 Daemon \u2014 already running (skip)")
        else:
            success = install_daemon()
            if success:
                print(f"  \u2713 Daemon \u2014 installed (auto-updates hourly)")
            else:
                print(f"  \u2717 Daemon \u2014 installation failed")
    else:
        print(f"  \u2014 Daemon \u2014 skipped (--no-daemon)")

    print(f"\n{APP_NAME} is ready. Run `{CLI_NAME} ingest .` to build your knowledge base.")


def cmd_query(args) -> None:
    """alphavaults query "question" — 3-layer query."""
    from alphavaults.query import query

    if getattr(args, "use_global", False):
        output_dir = get_global_output_dir()
    elif hasattr(args, "output_dir") and args.output_dir:
        output_dir = Path(args.output_dir)
    else:
        output_dir = Path(LOCAL_OUTPUT_DIR)

    if not output_dir.exists():
        print(f"No {APP_NAME} data found at {output_dir}. Run `{CLI_NAME} ingest .` or `/{SKILL_NAME} .` first.")
        sys.exit(1)

    result = query(args.question, output_dir, mode=args.mode, budget=args.budget)

    # Format output
    print(f"\n=== Search Results (0 tokens) ===")
    if result["search_results"]:
        for i, sr in enumerate(result["search_results"], 1):
            print(f"  {i}. [{sr['title']}] (score: {sr['score']:.2f})")
            print(f"     {sr['snippet'][:80]}")
    else:
        print("  (no results)")

    print(f"\n=== Graph Context ===")
    gc = result["graph_context"]
    if gc["matched_nodes"]:
        print(f"  Matched: {', '.join(gc['matched_nodes'][:10])}")
        matched_total = gc.get("matched_nodes_total", len(gc["matched_nodes"]))
        shown_matches = min(10, len(gc["matched_nodes"]))
        if matched_total > shown_matches:
            print(f"  ... and {matched_total - shown_matches} more")
    else:
        print("  (no matching nodes)")

    if gc["neighbors"]:
        # Show a few neighbor relationships
        for edge in gc["edges"][:5]:
            src = edge.get("source", "?")
            tgt = edge.get("target", "?")
            rel = edge.get("relation", "->")
            print(f"  {src} --{rel}--> {tgt}")
        if len(gc["edges"]) > 5:
            print(f"  ... and {len(gc['edges']) - 5} more edges")

    tokens = result["tokens_used"]
    wiki_len = len(result["wiki_context"])
    print(f"\n=== Wiki Context (est. ~{tokens} tokens) ===")
    if wiki_len > 0:
        # Show first 500 chars
        preview = result["wiki_context"][:500]
        if wiki_len > 500:
            preview += f"\n... ({wiki_len - 500} more chars)"
        print(preview)
    else:
        print("  (no wiki context)")

    print(f"\nTotal tokens used: {tokens}")


def cmd_ingest(args) -> None:
    """alphavaults ingest <path|url> — add new source and run incremental update."""
    source = args.path

    # Check if it's a URL
    if source.startswith("http://") or source.startswith("https://"):
        from alphavaults.ingest import ingest
        output_dir = Path(LOCAL_OUTPUT_DIR)
        print(f"Ingesting URL: {source}")
        result = ingest(source, output_dir)
        print(f"Result: {result}")
        return

    source_path = Path(source).resolve()
    output_dir = Path(LOCAL_OUTPUT_DIR)

    if not source_path.exists():
        print(f"Error: {source_path} does not exist.")
        sys.exit(1)

    # Check if it's a non-code file (document, pdf, etc.)
    ext = source_path.suffix.lower()
    if source_path.is_file() and ext in (".md", ".txt", ".rst", ".pdf"):
        from alphavaults.ingest import ingest_file
        print(f"Ingesting file: {source_path}")
        result = ingest_file(source_path, output_dir)
        print(f"Result: {result}")
        return

    # E안 fast path: .md-only vault, skip tree-sitter AST extraction.
    if getattr(args, "docs_only", False):
        from alphavaults.pipeline import run_documents
        print(f"Ingesting (docs-only, E안 fast path): {source_path}")
        result = run_documents(source_path, output_dir)
        print(f"Result: {result}")
        return

    from alphavaults.pipeline import run_incremental
    print(f"Ingesting: {source_path}")
    result = run_incremental(source_path, output_dir)
    print(f"Result: {result}")


def _print_lint_human(out: dict) -> None:
    """v0.5.0 human-readable lint report."""
    if "orphans" in out:
        ns = out["orphans"]
        print(f"[orphans] {len(ns)}개 고아 노트")
        for n in ns[:50]:
            print(f"  - {n}")
        if len(ns) > 50:
            print(f"  ... +{len(ns) - 50} more")
        print()
    if "broken_links" in out:
        bl = out["broken_links"]
        print(f"[broken-links] {len(bl)}개 깨진 wikilink")
        for b in bl[:50]:
            print(f"  - {b['source']} → [[{b['target']}]] (line {b['line']})")
        print()
    if "rag_consistency" in out:
        rc = out["rag_consistency"]
        print("[rag-consistency] 그래프와 vault 파일 불일치")
        print(f"  - indexed nodes:   {rc['indexed_nodes']}")
        print(f"  - vault .md files: {rc['vault_files']}")
        if rc.get("missing_from_index"):
            print(f"  - missing from index ({len(rc['missing_from_index'])}):")
            for m in rc["missing_from_index"][:20]:
                print(f"      {m}")


def _cmd_lint_checks(args) -> None:
    """v0.5.0 RAG-aware lint checks."""
    import json as _json
    from pathlib import Path as _Path

    from alphavaults.lint import (
        check_orphans,
        check_broken_wikilinks,
        check_rag_consistency,
    )

    vault = _Path(args.vault) if args.vault else _Path.cwd()
    storage_dir = _Path.home() / "alphavaults" / "rag_storage"
    try:
        from alphavaults.rag.storage import LightRAGStorage  # noqa: placeholder
        storage = LightRAGStorage(storage_dir)
    except Exception:
        storage = None

    checks = set((args.check or "").split(","))
    if "all" in checks:
        checks = {"orphans", "broken-links", "rag-consistency"}

    out: dict = {}
    if storage is None:
        # No rag_storage yet — emit empty-but-valid report
        if "orphans" in checks:
            out["orphans"] = []
        if "broken-links" in checks:
            out["broken_links"] = []
        if "rag-consistency" in checks:
            out["rag_consistency"] = {
                "vault_files": 0, "indexed_nodes": 0,
                "missing_from_index": [], "orphaned_in_index": [],
            }
    else:
        if "orphans" in checks:
            out["orphans"] = [r.node_id for r in check_orphans(storage)]
        if "broken-links" in checks:
            out["broken_links"] = [
                {"source": str(r.source_file), "target": r.target, "line": r.line}
                for r in check_broken_wikilinks(vault, storage)
            ]
        if "rag-consistency" in checks:
            rc = check_rag_consistency(vault, storage)
            out["rag_consistency"] = {
                "vault_files": rc.vault_file_count,
                "indexed_nodes": rc.indexed_node_count,
                "missing_from_index": rc.missing_from_index,
                "orphaned_in_index": rc.orphaned_in_index,
            }

    if args.json:
        print(_json.dumps(out, ensure_ascii=False, indent=2))
    else:
        _print_lint_human(out)

    has_issue = bool(out.get("orphans")) or bool(out.get("broken_links")) \
        or bool(out.get("rag_consistency", {}).get("missing_from_index"))
    if has_issue:
        sys.exit(1)


def cmd_lint(args) -> None:
    """alphavaults lint — wiki + graph consistency check. v0.5.0: --check flags."""
    if getattr(args, "check", None):
        _cmd_lint_checks(args)
        return

    # Legacy v0.4 path (unchanged)
    from alphavaults.lint import lint_wiki, lint_graph

    output_dir = Path(args.path)
    wiki_dir = output_dir / "wiki"
    graph_path = output_dir / "graph.json"

    if not output_dir.exists():
        print(f"No {APP_NAME} data found at {output_dir}. Run `{CLI_NAME} ingest .` or `/{SKILL_NAME} .` first.")
        sys.exit(1)

    print("=== Wiki Lint ===")
    wiki_result = lint_wiki(wiki_dir, graph_path)
    print(f"  Total pages: {wiki_result['total_pages']}")
    print(f"  Broken links: {len(wiki_result['broken_links'])}")
    if wiki_result["broken_links"][:5]:
        for bl in wiki_result["broken_links"][:5]:
            print(f"    - {bl['file']}: [[{bl['link']}]]")
        if len(wiki_result["broken_links"]) > 5:
            print(f"    ... and {len(wiki_result['broken_links']) - 5} more")
    print(f"  Orphan pages: {len(wiki_result['orphan_pages'])}")
    if wiki_result["orphan_pages"][:5]:
        for op in wiki_result["orphan_pages"][:5]:
            print(f"    - {op}")

    print("\n=== Graph Lint ===")
    graph_result = lint_graph(graph_path)
    print(f"  Total nodes: {graph_result['total_nodes']}")
    print(f"  Total edges: {graph_result['total_edges']}")
    print(f"  Isolated nodes: {len(graph_result['isolated_nodes'])}")
    print(f"  Ambiguous edges: {graph_result['ambiguous_edges']}")


def cmd_config(args) -> None:
    """alphavaults config — manage configuration."""
    from alphavaults.config import get as get_config, get_display_config, set as set_config

    action = args.config_action
    legacy_value = args.value if args.value is not None else args.key

    if action == "show":
        cfg = get_display_config()
        print(f"=== {APP_NAME} Configuration ===")
        for k, v in cfg.items():
            print(f"  {k}: {v}")
        return

    if action == "get":
        if not args.key:
            print("config get requires <key>")
            sys.exit(1)
        print(f"{args.key}: {get_config(args.key)}")
        return

    if action == "set":
        if not args.key:
            print("config set requires <key> <value>")
            sys.exit(1)
        value = args.value
        if value in ("null", "None"):
            parsed = None
        elif value in ("true", "false"):
            parsed = value == "true"
        elif args.key == "slack_approver_user_ids":
            parsed = [v.strip() for v in value.split(",") if v.strip()]
        elif args.key in {"review_server_port", "telebot_sync_days"}:
            parsed = int(value)
        else:
            parsed = value
        set_config(args.key, parsed)
        print(f"{args.key} set to: {parsed}")
        return

    if action == "llm":
        if not legacy_value:
            print(f"llm_endpoint: {get_config('llm_endpoint')}")
        else:
            set_config("llm_endpoint", legacy_value)
            print(f"llm_endpoint set to: {legacy_value}")
        return

    if action == "auto-approve":
        if not legacy_value:
            print(f"auto_approve_api: {get_config('auto_approve_api')}")
        else:
            val = legacy_value.lower() in ("true", "1", "yes")
            set_config("auto_approve_api", val)
            print(f"auto_approve_api set to: {val}")
        return

    if action == "provider":
        if not legacy_value:
            print(f"preferred_provider: {get_config('preferred_provider')}")
        else:
            set_config("preferred_provider", legacy_value)
            print(f"preferred_provider set to: {legacy_value}")
        return

    if action == "ollama-host":
        if not legacy_value:
            print(f"ollama_host: {get_config('ollama_host')}")
        else:
            set_config("ollama_host", legacy_value)
            print(f"ollama_host set to: {legacy_value}")
        return

    if action == "llm-model":
        if not legacy_value:
            print(f"llm_model: {get_config('llm_model')}")
        else:
            set_config("llm_model", legacy_value)
            print(f"llm_model set to: {legacy_value}")
        return

    print(f"Unknown config action: {action}")


def cmd_status(args) -> None:
    """alphavaults status — show current AlphaVaults status."""
    import os

    output_dir = Path(LOCAL_OUTPUT_DIR)
    if not output_dir.exists():
        print(f"No {APP_NAME} data found. Run `{CLI_NAME} ingest .` or `/{SKILL_NAME} .` first.")
        return

    graph_path = output_dir / "graph.json"
    wiki_dir = output_dir / "wiki"
    index_path = output_dir / "search_index.json"

    print(f"=== {APP_NAME} Status ===")

    if graph_path.exists():
        data = json.loads(graph_path.read_text(encoding="utf-8"))
        nodes = len(data.get("nodes", []))
        edges = len(data.get("links", []))
        communities = len(data.get("communities", {}))
        mtime = os.path.getmtime(graph_path)
        from datetime import datetime
        last_updated = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
        print(f"  Graph: {nodes} nodes, {edges} edges, {communities} communities")
        print(f"  Last updated: {last_updated}")
    else:
        print("  Graph: not built")

    if wiki_dir.exists():
        wiki_pages = len(list(wiki_dir.glob("*.md")))
        print(f"  Wiki: {wiki_pages} pages")
    else:
        print("  Wiki: not built")

    if index_path.exists():
        idx = json.loads(index_path.read_text(encoding="utf-8"))
        doc_count = idx.get("doc_count", 0)
        print(f"  Search index: {doc_count} documents")
    else:
        print("  Search index: not built")


def cmd_watch(args) -> None:
    """alphavaults watch — start file watcher."""
    from alphavaults.watch import watch

    source_dir = Path(args.path).resolve()
    output_dir = source_dir / LOCAL_OUTPUT_DIR

    watch(source_dir, output_dir, debounce=5)


def cmd_update(args) -> None:
    """alphavaults update — run incremental pipeline (for git hook)."""
    from alphavaults.pipeline import run_incremental

    source_dir = Path(".").resolve()
    output_dir = Path(LOCAL_OUTPUT_DIR)

    if not output_dir.exists():
        if not getattr(args, "quiet", False):
            print(f"No {APP_NAME} data found. Skipping update.")
        return

    result = run_incremental(source_dir, output_dir)
    if not getattr(args, "quiet", False):
        print(f"{APP_NAME} update: {result}")


def cmd_mark_dirty(args) -> None:
    """alphavaults mark-dirty <path> — mark file as needing re-extraction."""
    from alphavaults.hooks import mark_dirty

    file_path = Path(args.file_path).resolve()
    output_dir = Path(LOCAL_OUTPUT_DIR)
    mark_dirty(file_path, output_dir)


def cmd_flush(args) -> None:
    """alphavaults flush — process all dirty files."""
    from alphavaults.hooks import flush

    output_dir = Path(LOCAL_OUTPUT_DIR)
    result = flush(output_dir)
    print(f"Flush result: {result}")


def cmd_global(args) -> None:
    """alphavaults global [roots...] — global multi-project pipeline."""
    from alphavaults.discover import discover_projects
    from alphavaults.global_ import normalize_roots

    roots = normalize_roots(args.roots or None)
    output_dir = Path(args.output_dir) if args.output_dir else get_global_output_dir()

    if args.discover:
        # Just list discovered projects
        total = 0
        for entry in roots:
            projects = discover_projects(entry["path"])
            total += len(projects)
            print(f"Discovering projects in {entry['alias']}:{entry['path']}...")
            print(f"Found {len(projects)} projects:")
            for p in projects:
                print(f"  {entry['alias']}/{p['name']:20s} {p['type']:20s} {p['path']}")
        print(f"Total projects: {total}")
        return

    # Full global build
    from alphavaults.global_ import run_global

    print("Discovering projects in:")
    for entry in roots:
        print(f"  {entry['alias']}: {entry['path']}")
    result = run_global(roots, output_dir)
    print(f"Found {result['projects']} projects.")
    print(f"\nGlobal graph: {result['total_nodes']} nodes, {result['total_edges']} edges, "
          f"{result['cross_project_edges']} cross-project links")
    print(f"Wiki: {output_dir}/wiki/ ({result['wiki_pages']} pages)")
    print(f"Search index: {output_dir}/search_index.json ({result['index_docs']} docs)")

    if args.daemon:
        from alphavaults.daemon import install_daemon
        success = install_daemon(roots)
        if success:
            print(f"\nDaemon installed: {DAEMON_LABEL}")
            print(f"  Interval: 3600s (1 hour)")
            print(f"  Log: {output_dir}/daemon.log")
        else:
            print("\nDaemon installation failed.")


def cmd_daemon(args) -> None:
    """alphavaults daemon status/stop/log — manage AlphaVaults daemon."""
    from alphavaults.daemon import daemon_status, uninstall_daemon

    action = args.action

    if action == "status":
        status = daemon_status()
        print(f"Installed: {status['installed']}")
        print(f"Running: {status['running']}")
        print(f"Mechanism: {status.get('mechanism', 'unknown')}")
        if status.get('config_path'):
            print(f"Config: {status['config_path']}")
        if status.get('last_log_line'):
            print(f"Last log: {status['last_log_line']}")

    elif action == "stop":
        success = uninstall_daemon()
        print(f"Daemon stopped: {success}")

    elif action == "log":
        log_path = get_global_output_dir() / "daemon.log"
        if log_path.exists():
            content = log_path.read_text(encoding="utf-8", errors="ignore")
            lines = content.strip().split("\n")
            # Show last 20 lines
            for line in lines[-20:]:
                print(line)
        else:
            print("No daemon log found.")

    else:
        print(f"Unknown daemon action: {action}")
        sys.exit(1)


def cmd_rules(args) -> None:
    """alphavaults rules check — validate canonical RULES.md."""
    from alphavaults.rules import check_rules

    if args.rules_action != "check":
        print(f"Unknown rules action: {args.rules_action}")
        sys.exit(1)

    result = check_rules(Path(args.path) if args.path else None)
    print(f"RULES.md: {result['path']}")
    print(f"OK: {result['ok']}")
    if result["missing_sections"]:
        print("Missing sections:")
        for section in result["missing_sections"]:
            print(f"  - {section}")
    if result["forbidden_phrases"]:
        print("Forbidden phrases:")
        for phrase in result["forbidden_phrases"]:
            print(f"  - {phrase}")
    if result["warnings"]:
        print("Warnings:")
        for warning in result["warnings"]:
            print(f"  - {warning}")
    if not result["ok"]:
        sys.exit(1)


def cmd_review(args) -> None:
    """alphavaults review — manage Slack-approved LLMwiki review batches."""
    from alphavaults.review import (
        apply_approved,
        batch_status,
        generate_review_batch,
        normalize_automation_docs,
        send_slack_review,
        serve_review,
        set_item_decision,
    )

    action = args.review_action

    if action == "generate":
        batch = generate_review_batch(
            limit=args.limit,
            notify=args.notify,
            force=args.force,
            backfill_wiki=args.backfill_wiki,
            wiki_limit=args.wiki_limit,
        )
        print(f"Generated review batch: {batch['batch_id']}")
        print(f"Items: {len(batch['items'])}")
        print(f"RULES OK: {batch['rules_ok']}")
        if batch.get("skipped"):
            print(f"Skipped: {batch['skipped']}")
        print(f"Path: {Path(args.review_dir) if args.review_dir else 'configured review_dir'}")
        if batch.get("slack"):
            print(f"Slack: {batch['slack']}")
        return

    if action == "status":
        status = batch_status(args.batch)
        print(f"Batch: {status['batch_id']}")
        print(f"Exists: {status['exists']}")
        print(f"Counts: {status['counts']}")
        for item in status["items"][:20]:
            print(f"  - {item['id']} [{item['status']}] {item['title']} -> {item['target_path']}")
        if len(status["items"]) > 20:
            print(f"  ... and {len(status['items']) - 20} more")
        return

    if action == "decide":
        item = set_item_decision(args.batch, args.item, args.decision, user_id="cli")
        print(f"{item['id']}: {item['status']}")
        return

    if action == "apply":
        if not args.approved:
            print("Refusing to apply without --approved.")
            sys.exit(1)
        result = apply_approved(args.batch)
        print(f"Applied: {result['applied']}")
        print(f"Failed: {result['failed']}")
        print(f"Held: {result['held']}")
        for error in result["errors"]:
            print(f"  - {error}")
        if result["failed"]:
            sys.exit(1)
        return

    if action == "notify":
        result = send_slack_review(args.batch)
        print(f"Slack notify: {result}")
        return

    if action == "normalize":
        result = normalize_automation_docs(write=not args.dry_run)
        print(f"Scanned: {result['scanned']}")
        print(f"Updated: {result['updated']}")
        if result["skipped"]:
            print("Skipped:")
            for line in result["skipped"][:20]:
                print(f"  - {line}")
        return

    if action == "serve":
        serve_review(host=args.host, port=args.port)
        return

    print(f"Unknown review action: {action}")
    sys.exit(1)


def cmd_history(args) -> None:
    """alphavaults history — git-backed version control for wiki/ files (v0.4.0)."""
    from alphavaults.config import get_llmwiki_root
    from alphavaults.history import (
        commit_batch,
        list_snapshots,
        prune_history,
        restore_snapshot,
    )

    action = args.history_action
    root = Path(args.root).resolve() if args.root else get_llmwiki_root()

    if action in {"list", "restore"} and not args.path:
        print(f"`history {action}` requires a wiki file path.")
        sys.exit(1)

    if action == "list":
        target = Path(args.path).resolve()
        snaps = list_snapshots(target, root)
        if not snaps:
            print(f"No commits for {target}")
            return
        rel = target.relative_to(root) if target.is_relative_to(root) else target
        print(f"Commits for {rel}:")
        for snap in snaps:
            ts = snap["timestamp"]
            sha = snap["sha"][:8]
            subject = snap["subject"]
            print(f"  {ts}  {sha}  {subject}")
        return

    if action == "restore":
        if not args.at:
            print("Missing --at TIMESTAMP|SHA (use `history list` to pick one).")
            sys.exit(1)
        target = Path(args.path).resolve()
        restored = restore_snapshot(target, root, args.at)
        print(f"Restored {restored} from {args.at}")
        return

    if action == "prune":
        result = prune_history(root, dry_run=args.dry_run)
        if args.dry_run:
            print(
                f"Would run `git gc` (non-destructive). "
                f"Currently packed objects: {result.get('packed_objects', 0)}"
            )
        else:
            print(
                f"Ran `git gc`. Packed objects after gc: {result.get('packed_objects', 0)}"
            )
        return

    if action == "commit":
        if not args.paths:
            print("`history commit` requires one or more paths.")
            sys.exit(1)
        targets = [Path(p).resolve() for p in args.paths]
        operation = args.message or "manual"
        sha = commit_batch(root, targets, operation=operation)
        if sha is None:
            print("Nothing to commit (no changes or not a git repo).")
            return
        print(f"Committed: {sha[:8]}  ({len(targets)} paths)")
        return

    if action == "log":
        import subprocess
        result = subprocess.run(
            ["git", "-C", str(root), "log", "--oneline", "-n", str(args.limit or 20)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            print(f"git log failed: {result.stderr.strip()}")
            sys.exit(1)
        sys.stdout.write(result.stdout)
        return

    print(f"Unknown history action: {action}")
    sys.exit(1)


def cmd_bridge(args) -> None:
    """alphavaults bridge telebot-sync — sync legacy external sources into raw/."""
    from alphavaults.telebot_bridge import sync_telebot_bridge

    action = args.bridge_action
    if action != "telebot-sync":
        print(f"Unknown bridge action: {action}")
        sys.exit(1)

    result = sync_telebot_bridge(
        days=args.days,
        legacy_root=Path(args.legacy_root) if args.legacy_root else None,
        bridge_dir=Path(args.bridge_dir) if args.bridge_dir else None,
    )
    print("AlphaVaults bridge sync")
    print(f"  legacy_root: {result['legacy_root']}")
    print(f"  bridge_dir: {result['bridge_dir']}")
    print(f"  days: {result['days']}")
    print(f"  found: {result['found']}")
    print(f"  written: {result['written']}")
    print(f"  updated: {result['updated']}")
    print(f"  unchanged: {result['unchanged']}")
    if result.get("error"):
        print(f"  error: {result['error']}")
    if result.get("files"):
        print("  files:")
        for path in result["files"]:
            print(f"    - {path}")


def cmd_obsidian_graph_fix(args: "argparse.Namespace") -> None:
    """Handler for `alphavaults obsidian-graph-fix`."""
    import json as _json
    from pathlib import Path as _Path
    from datetime import datetime as _dt, timedelta as _td

    from alphavaults.obsidian import (
        apply_patch,
        resolve_vault_path,
        restore_file,
        UUIDMismatchError,
        VaultNotFoundError,
    )

    try:
        vault = resolve_vault_path(_Path(args.vault) if args.vault else _Path.cwd())
    except VaultNotFoundError as e:
        print(f"vault not found: {e}")
        sys.exit(2)

    if args.restore:
        try:
            restore_file(vault, _Path(args.restore), force=args.force)
            print(f"restored from {args.restore}")
            return
        except UUIDMismatchError as e:
            print(f"REJECTED: {e}. Use --force to override.")
            sys.exit(1)

    if args.prune_backups:
        cutoff = _dt.utcnow() - _td(days=30)
        d = vault / ".obsidian" / "backups"
        removed = 0
        if d.exists():
            for f in d.glob("*.bak-*"):
                if _dt.utcfromtimestamp(f.stat().st_mtime) < cutoff:
                    f.unlink()
                    meta = f.with_suffix(f.suffix + ".meta.json")
                    if meta.exists():
                        meta.unlink()
                    removed += 1
        print(f"pruned: {removed} backup(s) older than 30 days")
        return

    report = apply_patch(vault, dry_run=args.dry_run)
    print(_json.dumps(report, indent=2, ensure_ascii=False))


def main() -> None:
    """CLI entry point. Subcommands: install, query, ingest, lint, status, watch, global, daemon."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except AttributeError:
            pass

    parser = argparse.ArgumentParser(
        prog=CLI_NAME,
        description=f"{APP_NAME} - unified knowledge management: Search + Graph + Wiki",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"{CLI_NAME} {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # install
    sub_install = subparsers.add_parser("install", help=f"Install hooks and initialize {APP_NAME} in a project")
    sub_install.add_argument("path", nargs="?", default=".", help="Project root path")
    sub_install.add_argument("--no-daemon", action="store_true", help="Skip daemon installation")

    # query
    sub_query = subparsers.add_parser("query", help="Query the knowledge graph")
    sub_query.add_argument("question", help="Question to answer")
    sub_query.add_argument("--mode", default="bfs", choices=["bfs", "dfs", "hybrid"], help="Traversal mode")
    sub_query.add_argument("--budget", type=int, default=2000, help="Token budget")
    sub_query.add_argument("--output-dir", default=None, help=f"{APP_NAME} output directory")
    sub_query.add_argument("--global", dest="use_global", action="store_true", help="Use configured global index")

    # ingest
    sub_ingest = subparsers.add_parser("ingest", help="Ingest files into the knowledge graph")
    sub_ingest.add_argument("path", nargs="?", default=".", help="Directory to ingest")
    sub_ingest.add_argument("--incremental", action="store_true", help="Only process changed files")
    sub_ingest.add_argument(
        "--docs-only", action="store_true",
        help="E안 fast path: skip tree-sitter AST, .md-only ingest (20 docs ~0.1s)",
    )

    # lint
    sub_lint = subparsers.add_parser("lint", help="Check wiki consistency")
    sub_lint.add_argument("path", nargs="?", default=str(get_global_output_dir()), help="Wiki output directory")
    sub_lint.add_argument("--check", default=None,
                          help="Comma list: orphans,broken-links,rag-consistency,all (v0.5.0)")
    sub_lint.add_argument("--json", action="store_true",
                          help="Emit JSON output (v0.5.0)")
    sub_lint.add_argument("--vault", type=str, default=None,
                          help="Vault path for RAG-aware checks (v0.5.0)")

    # status
    sub_status = subparsers.add_parser("status", help=f"Show {APP_NAME} status for current project")

    # watch
    sub_watch = subparsers.add_parser("watch", help="Watch for file changes and auto-update")
    sub_watch.add_argument("path", nargs="?", default=".", help="Directory to watch")

    # update (for git hook)
    sub_update = subparsers.add_parser("update", help="Run incremental update (git hook)")
    sub_update.add_argument("--quiet", action="store_true", help="Suppress output")

    # mark-dirty (for Claude Code hook)
    sub_mark_dirty = subparsers.add_parser("mark-dirty", help="Mark a file as dirty")
    sub_mark_dirty.add_argument("file_path", help="File path to mark as dirty")

    # flush (for Claude Code hook)
    sub_flush = subparsers.add_parser("flush", help="Process all dirty files")

    # global
    sub_global = subparsers.add_parser("global", help="Global multi-project pipeline")
    sub_global.add_argument("roots", nargs="*", help="Root directories to scan for projects")
    sub_global.add_argument("--output-dir", default=None, help="Global AlphaVaults output directory")
    sub_global.add_argument("--discover", action="store_true", help="Just list discovered projects")
    sub_global.add_argument("--daemon", action="store_true", help="Build + install platform daemon")

    # config
    sub_config = subparsers.add_parser("config", help=f"Manage {APP_NAME} configuration")
    sub_config.add_argument("config_action", choices=["llm", "auto-approve", "provider", "ollama-host", "llm-model", "show", "get", "set"], help="Config action")
    sub_config.add_argument("key", nargs="?", default=None, help="Config key for get/set")
    sub_config.add_argument("value", nargs="?", default=None, help="Value to set")

    # daemon
    sub_daemon = subparsers.add_parser("daemon", help=f"Manage {APP_NAME} daemon")
    sub_daemon.add_argument("action", choices=["status", "stop", "log"], help="Daemon action")

    # rules
    sub_rules = subparsers.add_parser("rules", help="Validate canonical RULES.md")
    sub_rules.add_argument("rules_action", choices=["check"], help="Rules action")
    sub_rules.add_argument("--path", default=None, help="Override RULES.md path")

    # review
    sub_review = subparsers.add_parser("review", help="Manage review batches and Slack approval")
    sub_review.add_argument("review_action", choices=["generate", "status", "decide", "apply", "notify", "normalize", "serve"], help="Review action")
    sub_review.add_argument("--batch", default=None, help="Review batch id (YYYY-MM-DD)")
    sub_review.add_argument("--item", default=None, help="Review item id")
    sub_review.add_argument("--decision", choices=["approve", "reject", "hold"], default=None, help="Decision for review decide")
    sub_review.add_argument("--approved", action="store_true", help="Apply approved items only")
    sub_review.add_argument("--dry-run", action="store_true", help="Preview normalization without writing files")
    sub_review.add_argument("--limit", type=int, default=20, help="Max raw notes to include")
    sub_review.add_argument("--backfill-wiki", action="store_true", help="Treat wiki 전체를 백필 대상으로 생성")
    sub_review.add_argument("--wiki-limit", type=int, default=0, help="Max wiki curation items to include (0 = no limit)")
    sub_review.add_argument("--notify", action="store_true", help="Send Slack notification after generate")
    sub_review.add_argument("--force", action="store_true", help="Regenerate an existing daily batch")
    sub_review.add_argument("--host", default="127.0.0.1", help="Review server host")
    sub_review.add_argument("--port", type=int, default=None, help="Review server port")
    sub_review.add_argument("--review-dir", default=None, help=argparse.SUPPRESS)

    # history (v0.4.0: git-backed)
    sub_history = subparsers.add_parser(
        "history",
        help="Git-backed version control for wiki/ files",
    )
    sub_history.add_argument(
        "history_action",
        choices=["list", "restore", "prune", "commit", "log"],
        help="History action",
    )
    sub_history.add_argument(
        "path", nargs="?", default=None, help="Wiki file (list/restore)"
    )
    sub_history.add_argument(
        "paths", nargs="*", default=None, help="Paths for commit action"
    )
    sub_history.add_argument(
        "--at", default=None, help="Timestamp or SHA for restore"
    )
    sub_history.add_argument(
        "--message", "-m", default=None, help="Commit: operation label"
    )
    sub_history.add_argument(
        "--limit", type=int, default=20, help="Log: number of commits to show"
    )
    sub_history.add_argument("--root", default=None, help="Override LLMwiki root")
    sub_history.add_argument(
        "--dry-run", action="store_true", help="Prune: preview git gc without running it"
    )
    # v0.3.0 compat (deprecated, no-op):
    sub_history.add_argument(
        "--max-age-days", type=int, default=None, help=argparse.SUPPRESS
    )
    sub_history.add_argument(
        "--max-per-file", type=int, default=None, help=argparse.SUPPRESS
    )

    # bridge
    sub_bridge = subparsers.add_parser("bridge", help="Sync legacy external sources into LLMwiki raw")
    sub_bridge.add_argument("bridge_action", choices=["telebot-sync"], help="Bridge action")
    sub_bridge.add_argument("--days", type=int, default=None, help="Recent days to sync from legacy Telebot notes")
    sub_bridge.add_argument("--legacy-root", default=None, help="Override legacy Telebot Obsidian root")
    sub_bridge.add_argument("--bridge-dir", default=None, help="Override bridge output directory")

    # obsidian-graph-fix
    sub_ogf = subparsers.add_parser(
        "obsidian-graph-fix",
        help="Patch .obsidian/app.json + graph.json for link integrity",
    )
    sub_ogf.add_argument("--vault", type=str, default=None,
                          help="Vault path (default: CWD)")
    sub_ogf.add_argument("--dry-run", action="store_true",
                          help="Preview changes without writing")
    sub_ogf.add_argument("--restore", type=str, default=None,
                          help="Path to backup file to restore")
    sub_ogf.add_argument("--force", action="store_true",
                          help="Bypass UUID check when restoring")
    sub_ogf.add_argument("--prune-backups", action="store_true",
                          help="Delete backups older than 30 days")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "install": cmd_install,
        "query": cmd_query,
        "ingest": cmd_ingest,
        "lint": cmd_lint,
        "status": cmd_status,
        "watch": cmd_watch,
        "update": cmd_update,
        "mark-dirty": cmd_mark_dirty,
        "flush": cmd_flush,
        "config": cmd_config,
        "global": cmd_global,
        "daemon": cmd_daemon,
        "rules": cmd_rules,
        "review": cmd_review,
        "history": cmd_history,
        "bridge": cmd_bridge,
        "obsidian-graph-fix": cmd_obsidian_graph_fix,
    }

    handler = commands.get(args.command)
    if handler:
        handler(args)
    else:
        print(f"{CLI_NAME} {args.command}: not yet implemented")
        sys.exit(1)


if __name__ == "__main__":
    main()
