"""Global pipeline: discover projects -> per-project pipeline -> merge -> unified output."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from alphavaults.config import get_global_output_dir, get_global_roots
from alphavaults.discover import discover_projects


def _slug(value: str) -> str:
    """Return a filesystem and graph-id friendly alias."""
    cleaned = "".join(ch if ch.isalnum() or ch in ("-", "_") else "-" for ch in value.strip())
    cleaned = "-".join(part for part in cleaned.split("-") if part)
    return cleaned or "root"


def normalize_roots(roots=None) -> list[dict]:
    """Normalize root inputs into [{'alias', 'path'}] dictionaries."""
    if roots is None:
        roots = get_global_roots()

    if isinstance(roots, (str, Path)):
        roots = [{"alias": Path(roots).name, "path": str(roots)}]

    configured = {
        str(Path(r["path"]).resolve()).lower(): r["alias"]
        for r in get_global_roots()
        if r.get("path")
    }

    normalized: list[dict] = []
    used_aliases: set[str] = set()
    for i, root in enumerate(roots):
        if isinstance(root, (str, Path)):
            path = Path(root).resolve()
            alias = configured.get(str(path).lower()) or path.name or f"root{i + 1}"
        else:
            path = Path(str(root.get("path", ""))).resolve()
            alias = str(root.get("alias") or configured.get(str(path).lower()) or path.name or f"root{i + 1}")

        alias = _slug(alias)
        base_alias = alias
        suffix = 2
        while alias in used_aliases:
            alias = f"{base_alias}-{suffix}"
            suffix += 1
        used_aliases.add(alias)
        normalized.append({"alias": alias, "path": path})

    return normalized


def _project_key(root_alias: str, project_name: str) -> str:
    return f"{root_alias}/{project_name}"


def run_global(roots=None, output_dir: Path = None, max_depth: int = 4) -> dict:
    """Discover projects under roots, run per-project pipelines, and merge them.

    Args:
        roots: One root path or many root entries. Defaults to configured roots.
        output_dir: Global output directory (default: configured Obsidian output).
        max_depth: Max BFS depth for project discovery.

    Returns:
        Dict with stats: projects, total_nodes, total_edges, cross_project_edges,
                         wiki_pages, index_docs.
    """
    from alphavaults.pipeline import run as pipeline_run
    from alphavaults.build import build_graph
    from alphavaults.cluster import cluster, score_cohesion
    from alphavaults.wiki import generate_wiki, _community_label
    from alphavaults.export import export_json, export_html
    from alphavaults.index import index_markdown

    if output_dir is None:
        output_dir = get_global_output_dir()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    root_entries = normalize_roots(roots)

    # 1. Discover projects
    projects = []
    for entry in root_entries:
        discovered = discover_projects(entry["path"], max_depth)
        for project in discovered:
            project = dict(project)
            project["root_alias"] = entry["alias"]
            project["root_path"] = entry["path"]
            project["key"] = _project_key(entry["alias"], project["name"])
            projects.append(project)

    if not projects:
        return {
            "projects": 0, "total_nodes": 0, "total_edges": 0,
            "cross_project_edges": 0, "wiki_pages": 0, "index_docs": 0,
        }

    # 2. Run pipeline on each project
    project_results = []
    all_nodes = []
    all_edges = []

    for proj in projects:
        proj_output = output_dir / proj["root_alias"] / proj["name"]
        try:
            result = pipeline_run(proj["path"], proj_output)
        except Exception as e:
            result = {"nodes": 0, "edges": 0, "communities": 0, "wiki_pages": 0}

        # Load project graph
        graph_path = proj_output / "graph.json"
        proj_nodes = 0
        proj_edges = 0
        if graph_path.exists():
            try:
                gdata = json.loads(graph_path.read_text(encoding="utf-8"))
                raw_nodes = gdata.get("nodes", [])
                raw_links = gdata.get("links", [])

                # Prefix node IDs with root alias and project name.
                for node in raw_nodes:
                    node["id"] = f"{proj['key']}/{node['id']}"
                    node["project"] = proj["key"]
                    node["project_name"] = proj["name"]
                    node["root_alias"] = proj["root_alias"]
                    all_nodes.append(node)

                # Prefix edge endpoints
                for link in raw_links:
                    link["source"] = f"{proj['key']}/{link['source']}"
                    link["target"] = f"{proj['key']}/{link['target']}"
                    link["project"] = proj["key"]
                    link["project_name"] = proj["name"]
                    link["root_alias"] = proj["root_alias"]
                    all_edges.append(link)

                proj_nodes = len(raw_nodes)
                proj_edges = len(raw_links)
            except (json.JSONDecodeError, OSError):
                pass

        project_results.append({
            "key": proj["key"],
            "name": proj["name"],
            "root_alias": proj["root_alias"],
            "root_path": str(proj["root_path"]),
            "path": str(proj["path"]),
            "type": proj["type"],
            "nodes": proj_nodes,
            "edges": proj_edges,
        })

    # 3. Add cross-project edges (shares_name_with)
    # Group nodes by their base name (without project prefix)
    from collections import defaultdict
    name_to_nodes: dict[str, list[str]] = defaultdict(list)
    for node in all_nodes:
        # Extract base name: root/project/file_entity -> entity part
        full_id = node["id"]
        parts = full_id.split("/", 2)
        base = parts[2] if len(parts) >= 3 else full_id
        # Use the node label or the last part of the ID
        label = node.get("label", base)
        name_to_nodes[label].append(full_id)

    # Filter out generic/noisy labels that create meaningless cross-project edges
    GENERIC_LABELS = {
        "Props", "props", "default", "index", "main", "App", "app",
        "config", "Config", "utils", "helpers", "types", "constants",
        "styles", "theme", "Layout", "layout", "Root", "root",
        "Home", "home", "Header", "header", "Footer", "footer",
        "Button", "button", "Modal", "modal", "Error", "error",
        "Loading", "loading", "Container", "container",
        "module", "Module", "init", "__init__",
    }

    cross_edges = 0
    for label, node_ids in name_to_nodes.items():
        if len(node_ids) < 2:
            continue
        # Skip generic labels
        if label in GENERIC_LABELS or len(label) <= 3:
            continue
        # Get unique projects
        projects_set = set()
        for nid in node_ids:
            parts = nid.split("/", 2)
            proj_name = "/".join(parts[:2]) if len(parts) >= 2 else nid
            projects_set.add(proj_name)
        if len(projects_set) < 2:
            continue
        # Add edges between nodes from different projects
        for i in range(len(node_ids)):
            for j in range(i + 1, len(node_ids)):
                parts1 = node_ids[i].split("/", 2)
                parts2 = node_ids[j].split("/", 2)
                p1 = "/".join(parts1[:2]) if len(parts1) >= 2 else node_ids[i]
                p2 = "/".join(parts2[:2]) if len(parts2) >= 2 else node_ids[j]
                if p1 != p2:
                    all_edges.append({
                        "source": node_ids[i],
                        "target": node_ids[j],
                        "relation": "shares_name_with",
                        "confidence": "INFERRED",
                        "confidence_score": 0.6,
                        "weight": 0.5,
                    })
                    cross_edges += 1

    # 4. Build unified graph
    merged = {"nodes": all_nodes, "edges": all_edges}
    G = build_graph(merged)

    # 5. Cluster + wiki + export
    communities = cluster(G)
    cohesion = score_cohesion(G, communities)
    labels = {}
    for cid, members in communities.items():
        labels[cid] = _community_label(G, members)

    wiki_pages = generate_wiki(G, communities, labels, output_dir, cohesion=cohesion)
    export_json(G, communities, output_dir / "graph.json")
    export_html(G, communities, labels, output_dir / "graph.html")

    # 6. Build unified search index
    wiki_dir = output_dir / "wiki"
    index_path = output_dir / "search_index.json"
    index_docs = 0
    if wiki_dir.exists():
        index_docs = index_markdown(wiki_dir, index_path)

    # 6b. Also index Claude Code memory files if they exist
    from alphavaults.pipeline import _index_source_docs
    memory_patterns = [
        Path.home() / ".claude" / "projects",
    ]
    for mem_root in memory_patterns:
        if mem_root.exists():
            for memory_dir in mem_root.rglob("memory"):
                if memory_dir.is_dir():
                    md_files = [str(f.relative_to(memory_dir)) for f in memory_dir.glob("*.md")]
                    if md_files:
                        _index_source_docs(memory_dir, md_files, index_path)
                        index_docs += len(md_files)

    # 7. Save projects manifest
    manifest = {
        "roots": [
            {"alias": entry["alias"], "path": str(entry["path"])}
            for entry in root_entries
        ],
        "output_dir": str(output_dir),
        "discovered_at": datetime.now(timezone.utc).isoformat(),
        "projects": project_results,
    }
    (output_dir / "projects.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    return {
        "projects": len(projects),
        "total_nodes": G.number_of_nodes(),
        "total_edges": G.number_of_edges(),
        "cross_project_edges": cross_edges,
        "wiki_pages": wiki_pages,
        "index_docs": index_docs,
    }


def run_global_incremental(roots=None, output_dir: Path = None) -> dict:
    """Refresh the configured global index.

    Args:
        roots: One root path or many root entries. Defaults to configured roots.
        output_dir: Global output directory (default: configured Obsidian output).

    Returns:
        Dict with update stats.
    """
    if output_dir is None:
        output_dir = get_global_output_dir()
    output_dir = Path(output_dir)
    result = run_global(roots, output_dir)
    result["mode"] = "full-refresh"
    return result
