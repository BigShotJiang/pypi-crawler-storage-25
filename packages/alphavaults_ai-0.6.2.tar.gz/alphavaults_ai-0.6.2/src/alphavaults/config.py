"""User settings management — ~/.alphavaults/config.json."""

from __future__ import annotations

import json
from pathlib import Path

from alphavaults.branding import (
    DEFAULT_TELEBOT_SYNC_DAYS,
    DEFAULT_GLOBAL_ROOTS,
    GLOBAL_OUTPUT_DIR,
    LEGACY_TELEBOT_OBSIDIAN_ROOT,
    LLMWIKI_REVIEW_DIR,
    LLMWIKI_ROOT,
    LLMWIKI_RULES_PATH,
    LLMWIKI_TELEBOT_BRIDGE_DIR,
    OBSIDIAN_GLOBAL_OUTPUT_DIR,
)

_CONFIG_DIR = Path.home() / GLOBAL_OUTPUT_DIR
_CONFIG_FILE = _CONFIG_DIR / "config.json"

_DEFAULTS = {
    "global_output_dir": OBSIDIAN_GLOBAL_OUTPUT_DIR,
    "global_roots": DEFAULT_GLOBAL_ROOTS,
    "rules_path": LLMWIKI_RULES_PATH,
    "llmwiki_root": LLMWIKI_ROOT,
    "review_dir": LLMWIKI_REVIEW_DIR,
    "slack_channel_id": None,
    "slack_approver_user_ids": [],
    "slack_signing_secret": None,
    "slack_bot_token": None,
    "review_server_port": 8877,
    "telebot_bridge_enabled": False,
    "telebot_legacy_root": LEGACY_TELEBOT_OBSIDIAN_ROOT,
    "telebot_bridge_dir": LLMWIKI_TELEBOT_BRIDGE_DIR,
    "telebot_sync_days": DEFAULT_TELEBOT_SYNC_DAYS,
    "llm_endpoint": None,
    "auto_approve_api": False,
    "max_tokens_per_file": 4000,
    "preferred_provider": None,
    "llm_model": None,
    "ollama_host": None,
    "history_enabled": True,
    "history_max_age_days": 90,
    "history_max_per_file": 20,
}

_SECRET_KEYS = {"slack_signing_secret", "slack_bot_token"}


def load_config() -> dict:
    """Load config from ~/.alphavaults/config.json, merging with defaults."""
    if _CONFIG_FILE.exists():
        try:
            with open(_CONFIG_FILE, "r", encoding="utf-8") as f:
                user_cfg = json.load(f)
            merged = {**_DEFAULTS, **user_cfg}
            return merged
        except (json.JSONDecodeError, OSError):
            pass
    return dict(_DEFAULTS)


def save_config(config: dict) -> None:
    """Save config to ~/.alphavaults/config.json."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def get(key: str, default=None):
    """Get a single config value."""
    cfg = load_config()
    return cfg.get(key, default)


def redact_value(key: str, value):
    """Return a CLI-safe representation of config values."""
    if key not in _SECRET_KEYS or value in (None, "", []):
        return value
    text = str(value)
    if len(text) <= 8:
        return "*" * len(text)
    return f"{text[:4]}...{text[-4:]}"


def get_display_config() -> dict:
    """Return config values with secrets redacted for terminal display."""
    cfg = load_config()
    return {key: redact_value(key, value) for key, value in cfg.items()}


def set(key: str, value) -> None:
    """Set a single config value and persist."""
    cfg = load_config()
    cfg[key] = value
    save_config(cfg)


def get_global_output_dir() -> Path:
    """Return the configured global AlphaVaults output directory."""
    return Path(get("global_output_dir", OBSIDIAN_GLOBAL_OUTPUT_DIR))


def get_global_roots() -> list[dict]:
    """Return configured global roots as [{'alias', 'path'}] dictionaries."""
    roots = get("global_roots", DEFAULT_GLOBAL_ROOTS)
    normalized: list[dict] = []
    for i, root in enumerate(roots):
        if isinstance(root, str):
            path = root
            alias = Path(root).name or f"root{i + 1}"
        else:
            path = str(root.get("path", ""))
            alias = str(root.get("alias") or Path(path).name or f"root{i + 1}")
        if path:
            normalized.append({"alias": alias, "path": path})
    return normalized


def get_rules_path() -> Path:
    """Return the configured canonical RULES.md path."""
    return Path(get("rules_path", LLMWIKI_RULES_PATH))


def get_llmwiki_root() -> Path:
    """Return the configured LLMwiki root directory."""
    return Path(get("llmwiki_root", LLMWIKI_ROOT))


def get_review_dir() -> Path:
    """Return the configured AlphaVaults review queue directory."""
    return Path(get("review_dir", LLMWIKI_REVIEW_DIR))


def get_telebot_legacy_root() -> Path:
    """Return the configured legacy AlphaMate Telebot Obsidian root."""
    return Path(get("telebot_legacy_root", LEGACY_TELEBOT_OBSIDIAN_ROOT))


def get_telebot_bridge_dir() -> Path:
    """Return the configured bridge directory for legacy Telebot captures."""
    return Path(get("telebot_bridge_dir", LLMWIKI_TELEBOT_BRIDGE_DIR))


def get_telebot_sync_days() -> int:
    """Return how many recent days to sync from the legacy Telebot pipeline."""
    value = get("telebot_sync_days", DEFAULT_TELEBOT_SYNC_DAYS)
    try:
        return max(1, int(value))
    except (TypeError, ValueError):
        return DEFAULT_TELEBOT_SYNC_DAYS
