"""AlphaVaults package and user-facing naming constants."""

APP_NAME = "AlphaVaults"
CLI_NAME = "alphavaults"
PACKAGE_NAME = "alphavaults-ai"

LOCAL_OUTPUT_DIR = "alphavaults-out"
GLOBAL_OUTPUT_DIR = ".alphavaults"
OBSIDIAN_GLOBAL_OUTPUT_DIR = (
    r"D:\Obsidian Vault\나의 제2의 뇌\00. 지식 위키\output\alphavaults\global"
)
LLMWIKI_ROOT = r"D:\Obsidian Vault\나의 제2의 뇌\00. 지식 위키"
LLMWIKI_RULES_PATH = rf"{LLMWIKI_ROOT}\RULES.md"
LLMWIKI_REVIEW_DIR = rf"{LLMWIKI_ROOT}\output\alphavaults\review"
LEGACY_TELEBOT_OBSIDIAN_ROOT = (
    r"C:\Users\sudol\Documents\Obsidian Vault\나의 제2의 뇌\투자\주식\AlphaMate"
)
LLMWIKI_TELEBOT_BRIDGE_DIR = rf"{LLMWIKI_ROOT}\raw\external\alphamate-telebot"
DEFAULT_TELEBOT_SYNC_DAYS = 7

DEFAULT_GLOBAL_ROOTS = [
    {"alias": "claude", "path": r"D:\Vibe Coding"},
    {"alias": "codex", "path": r"D:\VibeCoding(codex)"},
]

SKILL_NAME = "alphavaults"
CONTEXT_TAG = "alphavaults-context"

CACHE_FILENAME = ".alphavaults_hashes.json"
DIRTY_FILENAME = ".alphavaults_dirty.json"

DAEMON_LABEL = "com.alphavaults.watcher"
DAEMON_TASK_NAME = "AlphaVaultsWatcher"
SYSTEMD_SERVICE_NAME = "alphavaults-watcher"
