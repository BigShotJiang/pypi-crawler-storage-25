"""Git-backed version management for wiki files (v0.4.0).

Replaces the v0.3.0 ``.history/{rel}/{timestamp}.md`` copy-on-write scheme. The
LLMwiki root (``00. 지식 위키/``) is now a git repository, and every write that
used to produce a snapshot is replaced by a batch ``git commit``.

Public API (shape preserved for backwards compatibility):

- ``snapshot_before_write`` — no-op returning ``None``. Retained so callers that
  already invoke it keep working; actual snapshotting happens via
  ``commit_batch`` after the batch of writes completes.
- ``commit_batch`` — stage+commit a list of paths with a structured message.
- ``list_snapshots`` — ``git log`` for a given path, newest first.
- ``restore_snapshot`` — find the commit at/before the given timestamp,
  ``git show`` the path from that commit, write it back to the working tree,
  then commit the restore so the rollback itself is a traceable event.
- ``prune_history`` — ``git gc`` (non-destructive; git keeps history by default).

Timestamps remain in the ``YYYY-MM-DD-HHMMSS`` format used by v0.3.0 so CLI
UX and tests do not change.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

HISTORY_DIR = ".history"
WIKI_DIR = "wiki"

DEFAULT_MAX_AGE_DAYS = 90
DEFAULT_MAX_PER_FILE = 20

_TS_FMT = "%Y-%m-%d-%H%M%S"


def _now_ts() -> str:
    return datetime.now().strftime(_TS_FMT)


def _resolve(path: Path | str) -> Path:
    return Path(path).resolve()


def _rel_to_root(path: Path, root: Path) -> Path | None:
    try:
        return _resolve(path).relative_to(_resolve(root))
    except ValueError:
        return None


def is_wiki_path(path: Path | str, root: Path | str) -> bool:
    """Return True when *path* is a wiki file eligible for commit tracking."""
    rel = _rel_to_root(Path(path), Path(root))
    if rel is None:
        return False
    parts = rel.parts
    if not parts:
        return False
    if parts[0] == HISTORY_DIR:
        return False
    return parts[0] == WIKI_DIR


def _run_git(
    root: Path | str,
    args: list[str],
    *,
    check: bool = False,
    input_text: str | None = None,
) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", "-C", str(_resolve(Path(root))), *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        input=input_text,
        check=check,
    )


def _is_git_repo(root: Path | str) -> bool:
    result = _run_git(root, ["rev-parse", "--is-inside-work-tree"])
    return result.returncode == 0 and result.stdout.strip() == "true"


def snapshot_before_write(
    path: Path | str,
    root: Path | str,
    *,
    enabled: bool = True,
    _now: str | None = None,
) -> Path | None:
    """No-op under git mode; kept for backwards compatibility."""
    return None


def commit_batch(
    root: Path | str,
    paths: list[Path | str],
    operation: str,
    *,
    message_extra: str = "",
    _now: str | None = None,
) -> str | None:
    """Stage *paths* and commit them with a batch message.

    Returns the resulting commit SHA, or ``None`` when:
      - root is not a git repo,
      - no paths were supplied, or
      - nothing was actually changed (empty diff).
    """
    root_p = Path(root)
    if not _is_git_repo(root_p):
        return None
    if not paths:
        return None

    rel_args: list[str] = []
    for p in paths:
        rel = _rel_to_root(Path(p), root_p)
        if rel is None:
            continue
        rel_args.append(str(rel).replace("\\", "/"))
    if not rel_args:
        return None

    add = _run_git(root_p, ["add", "--", *rel_args])
    if add.returncode != 0:
        return None

    status = _run_git(root_p, ["status", "--porcelain", "--", *rel_args])
    if status.returncode != 0 or not status.stdout.strip():
        return None

    ts = _now or _now_ts()
    subject = f"auto: {operation} at {ts} ({len(rel_args)} files)"
    body_lines = ["Files:", *(f"- {r}" for r in rel_args)]
    if message_extra:
        body_lines.extend(["", message_extra.strip()])
    message = subject + "\n\n" + "\n".join(body_lines) + "\n"

    commit = _run_git(root_p, ["commit", "-F", "-"], input_text=message)
    if commit.returncode != 0:
        return None

    head = _run_git(root_p, ["rev-parse", "HEAD"])
    if head.returncode != 0:
        return None
    return head.stdout.strip() or None


@dataclass(frozen=True)
class Snapshot:
    timestamp: str
    sha: str
    subject: str
    mtime: float

    def as_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "sha": self.sha,
            "subject": self.subject,
            "mtime": self.mtime,
            "path": self.sha,
            "size": 0,
        }


def list_snapshots(path: Path | str, root: Path | str) -> list[dict]:
    """Return commits that touched *path*, newest-first.

    Each entry has: ``timestamp`` (YYYY-MM-DD-HHMMSS), ``sha``, ``subject``,
    ``mtime`` (unix seconds), plus ``path``/``size`` kept for backwards
    compatibility with the v0.3.0 dict shape (``path`` now holds the SHA and
    ``size`` is always 0 — git blobs don't expose size cheaply via log).
    """
    root_p = Path(root)
    if not _is_git_repo(root_p):
        return []
    rel = _rel_to_root(Path(path), root_p)
    if rel is None:
        return []
    rel_str = str(rel).replace("\\", "/")

    log = _run_git(
        root_p,
        ["log", "--format=%H|%ct|%s", "--", rel_str],
    )
    if log.returncode != 0 or not log.stdout:
        return []

    snaps: list[Snapshot] = []
    for line in log.stdout.splitlines():
        parts = line.split("|", 2)
        if len(parts) != 3:
            continue
        sha, unix_ts, subject = parts
        try:
            mtime = float(unix_ts)
            ts = datetime.fromtimestamp(mtime).strftime(_TS_FMT)
        except ValueError:
            continue
        snaps.append(Snapshot(timestamp=ts, sha=sha, subject=subject, mtime=mtime))

    return [s.as_dict() for s in snaps]


def _find_commit_at_or_before(
    root: Path,
    rel_path: str,
    target_ts: str,
) -> str | None:
    try:
        target_dt = datetime.strptime(target_ts, _TS_FMT)
    except ValueError:
        return None
    before_iso = target_dt.strftime("%Y-%m-%dT%H:%M:%S")
    log = _run_git(
        root,
        [
            "log",
            "--format=%H|%ct",
            f"--before={before_iso}",
            "-n",
            "1",
            "--",
            rel_path,
        ],
    )
    if log.returncode != 0 or not log.stdout.strip():
        return None
    first = log.stdout.strip().splitlines()[0]
    sha = first.split("|", 1)[0].strip()
    return sha or None


def restore_snapshot(
    path: Path | str,
    root: Path | str,
    timestamp: str,
    *,
    _now: str | None = None,
) -> Path:
    """Restore *path* from the commit at/before *timestamp* and commit the rollback.

    *timestamp* can be either a canonical ``YYYY-MM-DD-HHMMSS`` string (as
    returned by ``list_snapshots``) or a full git SHA (40 hex chars; short
    SHAs are also accepted).
    """
    root_p = Path(root)
    target_abs = _resolve(Path(path))
    if not _is_git_repo(root_p):
        raise FileNotFoundError(f"Not a git repo: {root_p}")

    rel = _rel_to_root(target_abs, root_p)
    if rel is None:
        raise ValueError(f"path {target_abs} not under root {root_p}")
    rel_str = str(rel).replace("\\", "/")

    sha: str | None
    if len(timestamp) >= 7 and all(c in "0123456789abcdef" for c in timestamp.lower()):
        verify = _run_git(root_p, ["rev-parse", "--verify", f"{timestamp}^{{commit}}"])
        sha = verify.stdout.strip() if verify.returncode == 0 else None
    else:
        sha = _find_commit_at_or_before(root_p, rel_str, timestamp)
    if not sha:
        raise FileNotFoundError(
            f"No commit found at/before {timestamp} for {rel_str}"
        )

    show = _run_git(root_p, ["show", f"{sha}:{rel_str}"])
    if show.returncode != 0:
        raise FileNotFoundError(
            f"git show {sha}:{rel_str} failed: {show.stderr.strip()}"
        )

    target_abs.parent.mkdir(parents=True, exist_ok=True)
    target_abs.write_text(show.stdout, encoding="utf-8")

    commit_batch(
        root_p,
        [target_abs],
        operation=f"restore {rel_str} from {sha[:8]} ({timestamp})",
        _now=_now,
    )
    return target_abs


def prune_history(
    root: Path | str,
    *,
    max_age_days: int = DEFAULT_MAX_AGE_DAYS,
    max_per_file: int = DEFAULT_MAX_PER_FILE,
    dry_run: bool = False,
) -> dict:
    """Run ``git gc`` to repack loose objects. Non-destructive.

    ``max_age_days`` / ``max_per_file`` are retained in the signature for
    backwards compatibility with v0.3.0 callers but are ignored — git keeps
    full history by default. Use ``git gc --prune=<date>`` manually if the
    user really wants to expire unreachable objects.
    """
    root_p = Path(root)
    if not _is_git_repo(root_p):
        return {"removed": 0, "targets": 0, "packed_objects": 0}

    if dry_run:
        count = _run_git(root_p, ["count-objects", "-v"])
        packed = 0
        if count.returncode == 0:
            for line in count.stdout.splitlines():
                if line.startswith("in-pack:"):
                    try:
                        packed = int(line.split(":", 1)[1].strip())
                    except ValueError:
                        pass
                    break
        return {
            "would_remove": 0,
            "targets": 0,
            "packed_objects": packed,
            "files": [],
        }

    _run_git(root_p, ["gc", "--auto"])
    count = _run_git(root_p, ["count-objects", "-v"])
    packed = 0
    if count.returncode == 0:
        for line in count.stdout.splitlines():
            if line.startswith("in-pack:"):
                try:
                    packed = int(line.split(":", 1)[1].strip())
                except ValueError:
                    pass
                break
    return {"removed": 0, "targets": 0, "packed_objects": packed}
