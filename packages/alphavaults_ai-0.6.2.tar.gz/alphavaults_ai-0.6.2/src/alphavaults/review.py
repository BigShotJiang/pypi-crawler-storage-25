"""Review queue, Slack approval, and Git-backed LLMwiki application."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from difflib import unified_diff
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any

if sys.platform == "win32":
    import msvcrt

    def _file_lock(fp) -> None:
        try:
            msvcrt.locking(fp.fileno(), msvcrt.LK_LOCK, 1)
        except OSError:
            pass

    def _file_unlock(fp) -> None:
        try:
            msvcrt.locking(fp.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
else:
    import fcntl

    def _file_lock(fp) -> None:
        try:
            fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
        except OSError:
            pass

    def _file_unlock(fp) -> None:
        try:
            fcntl.flock(fp.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass


def _machine_id() -> str:
    return os.environ.get("ALPHAVAULTS_MACHINE") or socket.gethostname() or "unknown"

from alphavaults.config import (
    get as get_config,
    get_global_output_dir,
    get_llmwiki_root,
    get_review_dir,
)
from alphavaults.history import prune_history, snapshot_before_write
from alphavaults.rules import check_rules

_NOTE_INDEX_CACHE: dict[str, dict[str, Path]] = {}
_NOTE_TITLE_CACHE: dict[tuple[str, str], str] = {}
_CURATION_STATE_FILE = "curation_state.json"


def _cow_snapshot(target: Path, root: Path) -> None:
    """Best-effort copy-on-write snapshot. Never fails the caller."""
    if not get_config("history_enabled", True):
        return
    try:
        snapshot_before_write(target, root)
    except OSError:
        pass

_TAG_BLOCKLIST = {
    "노트",
    "문서",
    "내용",
    "요약",
    "정리문서",
    "정보",
    "자료",
    "프로젝트",
    "파일",
    "기능",
    "구현",
    "개요",
    "메모장",
}

_TAG_ALIASES = {
    "ai": "AI",
    "agent": "에이전트",
    "agents": "에이전트",
    "alphamate": "알파메이트",
    "alphaedge": "알파엣지",
    "alphavaults": "알파볼츠",
    "autonomous coding": "자율코딩",
    "autonomous-coding": "자율코딩",
    "claude": "클로드",
    "claude code": "클로드 코드",
    "claude-code": "클로드 코드",
    "codex": "코덱스",
    "cowork": "코워크",
    "dashboard": "대시보드",
    "decision": "결정",
    "evaluator": "평가기",
    "guide": "가이드",
    "harness": "하네스",
    "heatcoach": "히트코치",
    "infra": "인프라",
    "mcp": "MCP",
    "memo": "메모",
    "obsidian": "옵시디언",
    "openssh": "OpenSSH",
    "orchestrator": "오케스트레이터",
    "planner": "플래너",
    "plugin": "플러그인",
    "plugins": "플러그인",
    "pwa": "PWA",
    "railway": "Railway",
    "react native": "React Native",
    "react-native": "React Native",
    "research": "리서치",
    "skill": "스킬",
    "skills": "스킬",
    "slack": "슬랙",
    "ssh": "SSH",
    "supabase": "Supabase",
    "telegram": "텔레그램",
    "telebot": "텔레봇",
    "ultrathink": "UltraThink",
    "windows": "윈도우",
}

_TYPE_ALIASES = {
    "decision": "결정",
    "guide": "가이드",
    "manual": "가이드",
    "memo": "메모",
    "note": "메모",
    "research": "리서치",
    "digest": "관측",
    "summary": "정리",
}

_CONTEXT_TAG_RULES: list[tuple[tuple[str, ...], str]] = [
    (("자동화", "automation", "daemon", "hook"), "자동화"),
    (("승인", "approve", "approval", "review"), "승인흐름"),
    (("검색", "query", "search", "index", "인덱스"), "검색"),
    (("graph", "그래프", "wikilink", "백링크"), "그래프"),
    (("아키텍처", "architecture", "설계"), "구조설계"),
    (("workflow", "워크플로우", "운영"), "운영흐름"),
    (("playwright", "qa", "e2e", "test automation", "테스트 자동화"), "테스트자동화"),
    (("ssh", "openssh", "원격 접속", "원격접속"), "원격접속"),
    (("slack", "알림", "notification"), "알림"),
    (("obsidian", "wiki", "노트", "지식관리", "제텔카스텐"), "지식관리"),
    (("보안", "security", "권한", "rls"), "보안"),
    (("전환", "migration", "migrate"), "전환전략"),
    (("parser", "파싱", "import", "수집"), "데이터수집"),
    (("briefing", "브리핑", "보고서"), "브리핑"),
    (("screen", "screener", "스크리너"), "스크리닝"),
]

_KEYWORD_TAG_RULES: list[tuple[tuple[str, ...], str]] = [
    (("alphamate", "알파메이트"), "알파메이트"),
    (("alphaedge", "알파엣지"), "알파엣지"),
    (("alphavaults", "알파볼츠"), "알파볼츠"),
    (("claude code", "claude-code", "클로드 코드"), "클로드 코드"),
    (("claude", "클로드"), "클로드"),
    (("codex", "코덱스"), "코덱스"),
    (("cowork", "코워크"), "코워크"),
    (("obsidian", "옵시디언"), "옵시디언"),
    (("slack", "슬랙"), "슬랙"),
    (("ssh", "openssh"), "SSH"),
    (("windows", "윈도우"), "윈도우"),
    (("heatcoach", "히트코치", "난방"), "히트코치"),
    (("telebot", "telegram", "텔레그램", "텔레봇"), "텔레봇"),
    (("harness", "하네스"), "하네스"),
    (("ultrathink",), "UltraThink"),
    (("agent", "agents", "에이전트"), "에이전트"),
    (("dashboard", "대시보드"), "대시보드"),
    (("ledger", "가계부"), "가계부"),
    (("investment", "invest", "투자", "종목", "기업", "산업", "etf"), "투자"),
    (("infra", "네트워크"), "인프라"),
    (("mcp",), "MCP"),
]

_RELATED_LINK_RULES: list[tuple[tuple[str, ...], tuple[str, ...]]] = [
    (("옵시디언", "obsidian", "마크다운", "백링크", "태그"), ("옵시디언-사용법",)),
    (("바이브코딩", "vibe coding", "vibecoding"), ("바이브코딩",)),
    (("에이전트", "agent", "orchestrator"), ("에이전트-아키텍처",)),
    (("하네스", "harness", "ultrathink"), ("하네스-오케스트레이터", "에이전트-아키텍처")),
    (("claude", "클로드", "cowork", "코워크"), ("claude-생태계-가이드",)),
    (("system design", "시스템 설계"), ("claude-시스템-설계",)),
    (("workflow", "워크플로우"), ("claude-워크플로우",)),
    (("mcp", "plugin", "plugins", "skill", "skills", "확장 도구"), ("claude-확장-도구",)),
    (("alphamate", "알파메이트", "dashboard", "대시보드"), ("alphamate-대시보드",)),
    (("ledger", "가계부"), ("alphamate-ledger-v2", "2026-04-09-ledger-v2-전환결정")),
    (("heatcoach", "히트코치", "난방"), ("heatcoach",)),
    (("ssh", "openssh", "윈도우"), ("windows-ssh-쌍방연결",)),
    (("telebot", "telegram", "텔레봇", "텔레그램"), ("텔레봇-에이전트",)),
    (("smart screener", "스마트 스크리너", "투자"), ("스마트-스크리너",)),
]

_CURATED_NOTE_PROFILES: dict[str, dict[str, Any]] = {
    "raw/2026-04-08-claude-master-guide.md": {
        "note_type": "가이드",
        "summary": "Claude Code와 Cowork 생태계, 시스템 설계, 확장 도구, 워크플로우를 장별로 묶어 둔 마스터 가이드.",
        "tags": ["개발", "가이드", "클로드", "코워크", "생태계", "운영흐름"],
        "related": [
            "claude-생태계-가이드",
            "claude-시스템-설계",
            "claude-확장-도구",
            "claude-워크플로우",
        ],
    },
    "raw/2026-04-10-ssh-3way-setup.md": {
        "note_type": "가이드",
        "summary": "Desktop, A8, G3 세 Windows 머신 사이에 SSH 키 기반 쌍방 접속을 구성한 운영 가이드.",
        "tags": ["개발", "가이드", "원격접속", "SSH", "윈도우", "인프라"],
        "related": ["windows-ssh-쌍방연결"],
    },
    "raw/2026-04-10-alphamate-ledger-v2.md": {
        "note_type": "결정",
        "summary": "AlphaMate Household PWA를 React Native + Supabase + Railway 구조로 전환한 제품·기술 결정 문서.",
        "tags": ["개발", "결정", "알파메이트", "가계부", "전환전략", "모바일앱"],
        "related": [
            "alphamate-ledger-v2",
            "2026-04-09-ledger-v2-전환결정",
            "alphamate-대시보드",
        ],
    },
    "raw/dev/AlphaMate 대시보드 v4.md": {
        "note_type": "기획",
        "summary": "AlphaMate 투자 대시보드 v4의 화면 구조, 메뉴 체계, 브리핑·스크리닝 흐름을 잡아 둔 기획 초안.",
        "tags": ["투자", "기획", "알파메이트", "대시보드", "브리핑", "스크리닝"],
        "related": ["alphamate-대시보드", "스마트-스크리너", "스모킹-다트"],
        "body_override": "\n".join([
            "### 문서 성격",
            "- AlphaMate 투자 대시보드 v4의 전체 화면 구조와 메뉴 체계를 정리한 기획 메모다.",
            "- 핵심 축은 `오늘의 브리핑`, `시장 읽기`, `후보 찾기`, `종목 깊게 보기`, `운영/시스템`이다.",
            "",
            "### 핵심 목적",
            "- 투자 아이디어 탐색부터 리스크 진단, 브리핑, 운영 알림까지 하나의 대시보드 흐름으로 묶는다.",
            "- `스마트 스크리너`와 `스모킹 다트`를 전략 메뉴 안의 실전 분석 모듈로 연결한다.",
            "- Claude 기반 브리핑, DART 피드, 리스크 배지, 스케줄러 상태를 한 화면 체계로 정리한다.",
            "",
            "### 주요 구성",
            "- 매일: 오늘의 브리핑",
            "- 시장: 시장 읽기",
            "- 전략: 후보 찾기, 종목 깊게 보기, 4개국 테마 스크리너, Peer 비교, ETF 전략",
            "- 운영: 감시/알림, 보고서 발행, 운영/시스템",
        ]),
    },
    "raw/dev/스마트 스크리너.md": {
        "note_type": "가이드",
        "summary": "투자 테마 키워드 하나로 뉴스, IB 의견, 수혜 구조, 국내외 수혜주를 묶어 주는 글로벌 인사이트 기능 설명.",
        "tags": ["투자", "가이드", "스크리닝", "글로벌리서치", "알파메이트", "대시보드"],
        "related": ["alphamate-대시보드", "스모킹-다트"],
    },
    "raw/invest/스모킹 다트.md": {
        "note_type": "레퍼런스",
        "summary": "투자 대시보드의 재무 건강 진단 설계에 참고한 외부 벤치마크 레퍼런스.",
        "tags": ["투자", "레퍼런스", "벤치마크", "재무분석", "대시보드", "알파메이트"],
        "related": ["alphamate-대시보드", "스마트-스크리너"],
        "body_override": "\n".join([
            "### 문서 성격",
            "- 외부 레퍼런스 링크를 기록한 짧은 메모다.",
            "- AlphaMate 대시보드의 재무 건강 진단과 리스크 배지 설계 참고용이다.",
            "",
            "### 참고 링크",
            "- https://m.blog.naver.com/gunbaram/224224425713",
        ]),
    },
    "raw/dev/앤트로픽이 공개한 프로젝트 구현시 실패하지 않는 방법.md": {
        "note_type": "메모",
        "summary": "Generator-Evaluator 분리와 스프린트 계약으로 구현 실패율을 낮추는 설계 메모.",
        "tags": ["개발", "메모", "설계원칙", "에이전트", "생성기", "평가기"],
        "related": ["에이전트-아키텍처", "하네스-오케스트레이터", "텔레봇-에이전트"],
    },
    "raw/2026-04-08-harness-v1-v2-설계.md": {
        "note_type": "결정",
        "summary": "Harness v1에서 UltraThink v2로 확장되며 실행, 계획, 검증 계층을 어떻게 분리·통합했는지 정리한 설계 진화 문서.",
        "tags": ["개발", "결정", "하네스", "UltraThink", "자율코딩", "구조설계"],
        "related": ["하네스-오케스트레이터", "에이전트-아키텍처", "claude-생태계-가이드"],
    },
}


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def _hash_text(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def _agent_state_path() -> Path:
    return get_review_dir() / "runtime" / _CURATION_STATE_FILE


def _load_agent_state() -> dict[str, Any]:
    state = _load_json(_agent_state_path(), {})
    if not isinstance(state, dict):
        return {"files": {}}
    files = state.get("files")
    if not isinstance(files, dict):
        state["files"] = {}
    return state


def _save_agent_state(state: dict[str, Any]) -> None:
    state.setdefault("files", {})
    state["updated_at"] = _now()
    _write_json(_agent_state_path(), state)


def _slug(value: str, fallback: str = "note") -> str:
    value = value.strip().lower()
    value = re.sub(r"[\\/:*?\"<>|]+", " ", value)
    value = re.sub(r"\s+", "-", value)
    value = "".join(ch for ch in value if ch.isalnum() or ch in "-_가-힣")
    value = re.sub(r"-{2,}", "-", value).strip("-_")
    return value[:80] or fallback


def _read_text(path: Path, limit: int | None = None) -> str:
    text = path.read_text(encoding="utf-8", errors="ignore")
    return text[:limit] if limit else text


def _strip_frontmatter(text: str) -> str:
    if not text.startswith("---"):
        return text
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return text
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            return "\n".join(lines[idx + 1 :]).lstrip()
    return text


def _excerpt(text: str, limit: int = 1800) -> str:
    text = text.strip()
    if len(text) <= limit:
        return text
    snippet = text[:limit].rstrip()
    cut = max(snippet.rfind("\n\n"), snippet.rfind(". "), snippet.rfind("! "), snippet.rfind("? "))
    if cut >= max(200, limit // 3):
        snippet = snippet[:cut].rstrip()
    return snippet + "\n\n[... 이하 원문은 Sources의 raw 노트에서 계속 확인 ...]"


def _balance_code_fences(text: str) -> str:
    if text.count("```") % 2:
        return text.rstrip() + "\n```"
    return text


def _trim_blank_lines(lines: list[str]) -> list[str]:
    trimmed: list[str] = []
    blank = False
    for line in lines:
        if line.strip():
            trimmed.append(line.rstrip())
            blank = False
            continue
        if trimmed and not blank:
            trimmed.append("")
        blank = True
    while trimmed and not trimmed[-1].strip():
        trimmed.pop()
    return trimmed


def _parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---"):
        return {}, text
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text

    end_idx = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_idx = idx
            break
    if end_idx is None:
        return {}, text

    data: dict[str, Any] = {}
    current_list_key: str | None = None
    for raw_line in lines[1:end_idx]:
        if current_list_key and re.match(r"^\s*-\s+", raw_line):
            item = re.sub(r"^\s*-\s+", "", raw_line).strip()
            if item:
                data.setdefault(current_list_key, []).append(item)
            continue

        current_list_key = None
        match = re.match(r"^\s*([A-Za-z0-9_-]+)(?:\([^)]*\))?\s*:\s*(.*?)\s*$", raw_line)
        if not match:
            continue

        key, value = match.groups()
        if not value:
            data[key] = []
            current_list_key = key
            continue
        if value.startswith("[") and value.endswith("]"):
            items = [part.strip().strip("'\"") for part in value[1:-1].split(",")]
            data[key] = [item for item in items if item]
            continue
        data[key] = value.strip().strip("'\"")

    body = "\n".join(lines[end_idx + 1 :]).lstrip()
    return data, body


def _wiki_note_index(root: Path) -> dict[str, Path]:
    key = str(root.resolve())
    cached = _NOTE_INDEX_CACHE.get(key)
    if cached is not None:
        return cached

    index: dict[str, Path] = {}
    wiki_dir = root / "wiki"
    if wiki_dir.exists():
        for md_file in wiki_dir.rglob("*.md"):
            index.setdefault(md_file.stem, md_file)
    _NOTE_INDEX_CACHE[key] = index
    return index


def _note_path(root: Path, stem: str) -> Path | None:
    return _wiki_note_index(root).get(stem)


def _note_title(root: Path, stem: str) -> str:
    cache_key = (str(root.resolve()), stem)
    cached = _NOTE_TITLE_CACHE.get(cache_key)
    if cached is not None:
        return cached
    note_path = _note_path(root, stem)
    if not note_path:
        return stem
    title = _title_from_markdown(note_path, _read_text(note_path, 4000))
    _NOTE_TITLE_CACHE[cache_key] = title
    return title


def _canonical_tag(token: str) -> str | None:
    clean = token.strip().strip("#").strip("[](){}").strip("'\"")
    clean = re.sub(r"\s+", " ", clean)
    if not clean:
        return None

    lower = clean.lower().replace("_", " ").replace("-", " ")
    lower = re.sub(r"\s+", " ", lower).strip()
    if lower in _TAG_ALIASES:
        return _TAG_ALIASES[lower]
    if clean in {"AI", "MCP", "SSH", "UI", "UX", "RLS"}:
        return clean
    if re.search(r"[가-힣]", clean):
        return clean
    return None


def _derive_note_type(title: str, content: str, metadata: dict[str, Any], category: str) -> str:
    raw_type = str(metadata.get("type", "")).strip().lower()
    if raw_type in _TYPE_ALIASES:
        return _TYPE_ALIASES[raw_type]

    text = f"{title}\n{content}".lower()
    if category == "결정" or any(word in text for word in ["결정", "decision", "전환", "adr"]):
        return "결정"
    if any(word in text for word in ["가이드", "사용법", "manual", "how to", "워크플로우"]):
        return "가이드"
    if any(word in text for word in ["메모", "아이디어", "note", "notes"]):
        return "메모"
    if any(word in text for word in ["리서치", "연구", "벤치마크", "research"]):
        return "리서치"
    return "정리"


def _derive_tags(title: str, content: str, metadata: dict[str, Any], category: str, note_type: str) -> list[str]:
    tags: list[str] = []

    def add_tag(value: str | None) -> None:
        canonical = _canonical_tag(value or "")
        if canonical and canonical not in tags:
            tags.append(canonical)

    add_tag(category)
    add_tag(note_type)

    lowered = f"{title}\n{content}".lower()
    context_tags: list[str] = []
    for keywords, tag in _CONTEXT_TAG_RULES:
        if any(keyword in lowered for keyword in keywords):
            if tag not in context_tags:
                context_tags.append(tag)
    for tag in context_tags[:2]:
        add_tag(tag)

    raw_tags = metadata.get("tags", [])
    if isinstance(raw_tags, str):
        raw_tags = [raw_tags]
    for raw_tag in raw_tags:
        add_tag(str(raw_tag))

    for hashtag in re.findall(r"#([A-Za-z0-9_가-힣+-]+)", content):
        add_tag(hashtag)

    for keywords, tag in _KEYWORD_TAG_RULES:
        if any(keyword in lowered for keyword in keywords):
            add_tag(tag)

    return tags[:6]


def _normalize_wikilinks(text: str, root: Path) -> str:
    def _embed_repl(match: re.Match[str]) -> str:
        inner = match.group(1).strip()
        return f"`{Path(inner).name or inner}`"

    def _wikilink_repl(match: re.Match[str]) -> str:
        inner = match.group(1).strip()
        target = inner
        alias = ""
        if "|" in inner:
            target, alias = inner.split("|", 1)
            target = target.strip()
            alias = alias.strip()

        anchor = ""
        if "#" in target:
            target, anchor = target.split("#", 1)
            target = target.strip()
            anchor = anchor.strip()

        if "/" in target or re.search(r"\.[A-Za-z0-9]{1,5}$", target):
            display = alias or Path(target).stem or Path(target).name or target
            return display

        stem = Path(target).stem or target
        note_path = _note_path(root, stem)
        if not note_path:
            return alias or stem

        display = alias or _note_title(root, stem)
        target_expr = stem if not anchor else f"{stem}#{anchor}"
        if display == stem:
            return f"[[{target_expr}]]"
        return f"[[{target_expr}|{display}]]"

    text = re.sub(r"!\[\[([^\]]+)\]\]", _embed_repl, text)
    return re.sub(r"\[\[([^\]]+)\]\]", _wikilink_repl, text)


def _normalize_raw_body(content: str, root: Path, title: str) -> tuple[dict[str, Any], str]:
    metadata, body = _parse_frontmatter(content)
    lines: list[str] = []
    skip_section: str | None = None

    for raw_line in body.splitlines():
        stripped = raw_line.strip()

        if skip_section:
            if stripped.startswith(("## ", "### ", "# ")):
                skip_section = None
            elif stripped:
                continue
            else:
                continue

        if stripped.startswith("### 날짜"):
            date_value = stripped.split(":", 1)[1].strip() if ":" in stripped else ""
            if date_value and "created" not in metadata:
                metadata["created"] = date_value
            continue
        if stripped.startswith("### 주제"):
            topic_text = stripped.split(":", 1)[1].strip() if ":" in stripped else ""
            topic_tags = re.findall(r"#([A-Za-z0-9_가-힣+-]+)", topic_text)
            if topic_tags:
                existing = metadata.get("tags", [])
                if isinstance(existing, str):
                    existing = [existing]
                metadata["tags"] = [*existing, *topic_tags]
            continue
        if stripped.startswith(("### 출처", "### Sources")):
            skip_section = "sources"
            continue
        if stripped.startswith("### 연결문서"):
            skip_section = "links"
            continue
        if stripped in {"---", "----"}:
            if lines and lines[-1]:
                lines.append("")
            continue
        if re.match(r"^(source|created|tags|type):", stripped):
            continue
        if stripped.startswith("# "):
            heading = _normalize_heading_title(stripped[2:])
            if heading and heading == _normalize_heading_title(title):
                continue

        lines.append(_normalize_wikilinks(raw_line.rstrip(), root))

    cleaned = "\n".join(_trim_blank_lines(lines)).strip()
    return metadata, cleaned


def _summary_from_body(title: str, body: str) -> str:
    parts: list[str] = []
    for raw_line in body.splitlines():
        stripped = raw_line.strip()
        if not stripped or stripped.startswith(("#", "```", "|")):
            continue
        if stripped.startswith("- "):
            stripped = stripped[2:].strip()
        if stripped.startswith(">"):
            stripped = stripped[1:].strip()
        if re.match(r"^[가-힣A-Za-z /&+-]+:\s+\S+", stripped) and len(stripped) < 80:
            continue
        parts.append(stripped)
        if len(" ".join(parts)) >= 220:
            break
    summary = re.sub(r"\s+", " ", " ".join(parts)).strip()
    if not summary:
        summary = f"{title} 관련 정리 문서."
    truncated = summary[:220].rstrip(" .,")
    return truncated + ("..." if len(summary) > 220 else "")


def _related_links(root: Path, title: str, content: str, current_stem: str | None = None) -> list[str]:
    lowered = f"{title}\n{content}".lower()
    links: list[str] = []
    for keywords, stems in _RELATED_LINK_RULES:
        if not any(keyword in lowered for keyword in keywords):
            continue
        for stem in stems:
            if stem == current_stem:
                continue
            if not _note_path(root, stem):
                continue
            note_title = _note_title(root, stem)
            link = f"[[{stem}]]" if note_title == stem else f"[[{stem}|{note_title}]]"
            if link not in links:
                links.append(link)
    return links[:5]


def _render_frontmatter(
    *,
    category: str,
    note_type: str,
    source_kind: str,
    coverage: str,
    tags: list[str],
) -> str:
    lines = [
        "---",
        f"domain: {category}",
        f"type: {note_type}",
        "status: 정리완료",
        f"source: {source_kind}",
        "automation: alphavaults",
        "review_status: 승인됨",
        f"coverage: {coverage}",
        f"last_compiled: {_today()}",
        "tags:",
    ]
    lines.extend(f"  - {tag}" for tag in tags)
    lines.append("---")
    return "\n".join(lines)


def _render_metadata_frontmatter(metadata: dict[str, Any]) -> str:
    preferred_order = [
        "domain",
        "type",
        "status",
        "source",
        "automation",
        "review_status",
        "coverage",
        "last_compiled",
        "last_curated",
        "tags",
    ]
    keys = [key for key in preferred_order if key in metadata]
    keys.extend(sorted(key for key in metadata if key not in keys))

    lines = ["---"]
    for key in keys:
        value = metadata.get(key)
        if value in (None, "", []):
            continue
        if isinstance(value, list):
            lines.append(f"{key}:")
            for item in value:
                lines.append(f"  - {item}")
            continue
        lines.append(f"{key}: {value}")
    lines.append("---")
    return "\n".join(lines)


def _extract_legacy_metadata(body: str) -> tuple[dict[str, str], str]:
    metadata: dict[str, str] = {}
    cleaned: list[str] = []
    seen_substantive = False
    meta_window = 0

    for raw_line in body.splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        if not stripped:
            cleaned.append("")
            continue
        if stripped.startswith("# "):
            cleaned.append(stripped)
            continue
        if not seen_substantive and meta_window < 12:
            match = re.match(r"^\[(?P<key>[A-Za-z0-9_-]+):\s*(?P<value>.+?)\]$", stripped)
            if match:
                metadata[match.group("key").lower()] = match.group("value").strip()
                meta_window += 1
                continue
        meta_window += 1
        if not stripped.startswith("## "):
            seen_substantive = True
        cleaned.append(line)

    return metadata, "\n".join(_trim_blank_lines(cleaned)).strip() + ("\n" if body.endswith("\n") else "")


def _wiki_domain(note_path: Path, root: Path) -> str:
    try:
        rel_parts = note_path.relative_to(root / "wiki").parts
    except ValueError:
        return note_path.parent.name if note_path.parent.name else "일반"
    if len(rel_parts) <= 1:
        return "일반"
    return rel_parts[0]


def _path_context_tags(note_path: Path, root: Path) -> list[str]:
    tags: list[str] = []
    try:
        rel_parts = note_path.relative_to(root / "wiki").parts[:-1]
    except ValueError:
        rel_parts = note_path.parts[:-1]
    for part in rel_parts[1:]:
        canonical = _canonical_tag(part)
        if canonical and canonical not in tags and canonical not in _TAG_BLOCKLIST:
            tags.append(canonical)
    return tags


def _subject_tags(title: str) -> list[str]:
    tags: list[str] = []
    simple_title = title.strip()
    candidates: list[str] = []
    if simple_title and len(simple_title) <= 18 and " " not in simple_title and not re.search(r"[|:()]", simple_title):
        candidates.append(simple_title)
    for pattern in (r"^(?:기업|산업|프로젝트)-(.+)$",):
        match = re.match(pattern, title.strip())
        if not match:
            continue
        candidates.extend(group.strip() for group in match.groups() if group.strip())
    for candidate in candidates:
        canonical = _canonical_tag(candidate)
        if canonical and canonical not in tags and canonical not in _TAG_BLOCKLIST:
            tags.append(canonical)
    return tags


def _merge_tags(*tag_groups: list[str], minimum: int = 3, maximum: int = 6) -> list[str]:
    merged: list[str] = []
    for group in tag_groups:
        for raw_tag in group:
            canonical = _canonical_tag(raw_tag)
            if not canonical or canonical in _TAG_BLOCKLIST or canonical in merged:
                continue
            merged.append(canonical)
    if len(merged) < minimum:
        return merged
    return merged[:maximum]


def _existing_related_links(text: str) -> list[str]:
    lines = text.splitlines()
    collecting = False
    links: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped == "## 관련 문서":
            collecting = True
            continue
        if collecting and stripped.startswith("## "):
            break
        if collecting and stripped.startswith("- "):
            value = stripped[2:].strip()
            if value and value not in links:
                links.append(value)
    return links


def _normalize_related_entries(root: Path, related: list[str]) -> list[str]:
    normalized: list[str] = []
    for entry in related:
        for inner in re.findall(r"\[\[([^\]]+)\]\]", entry):
            target = inner.split("|", 1)[0].split("#", 1)[0].strip()
            if not target or "/" in target:
                continue
            link = _format_link(root, Path(target).stem)
            if link and link not in normalized:
                normalized.append(link)
    return normalized


def _replace_section(text: str, heading: str, lines: list[str]) -> str:
    pattern = re.compile(rf"(^## {re.escape(heading)}\n.*?)(?=^## |\Z)", re.MULTILINE | re.DOTALL)
    replacement = f"## {heading}\n" + "\n".join(lines).rstrip() + "\n\n"
    if pattern.search(text):
        return pattern.sub(replacement, text, count=1)
    stripped = text.rstrip() + "\n\n"
    return stripped + replacement


def _infer_coverage(body: str, existing: str | None = None) -> str:
    if existing:
        return existing
    length = len(body.strip())
    if length >= 3500:
        return "high"
    if length >= 1200:
        return "medium"
    return "low"


def _body_without_reference_sections(body: str) -> str:
    pattern = re.compile(r"^## (관련 문서|AlphaVaults 근거|Sources)\n.*?(?=^## |\Z)", re.MULTILINE | re.DOTALL)
    cleaned = pattern.sub("", body)
    return "\n".join(_trim_blank_lines(cleaned.splitlines()))


def _render_wiki_curated_document(root: Path, note_path: Path) -> tuple[str | None, dict[str, Any]]:
    original = _read_text(note_path)
    frontmatter, body = _parse_frontmatter(original)
    legacy_meta, body = _extract_legacy_metadata(body)
    current_stem = note_path.stem
    title = _title_from_markdown(note_path, body)
    inference_body = _body_without_reference_sections(body)
    domain = str(frontmatter.get("domain") or legacy_meta.get("domain") or _wiki_domain(note_path, root))
    note_type = str(frontmatter.get("type") or legacy_meta.get("type") or _derive_note_type(title, inference_body, frontmatter, domain))
    existing_tags = frontmatter.get("tags", [])
    if isinstance(existing_tags, str):
        existing_tags = [existing_tags]
    inferred_tags = _derive_tags(title, inference_body, frontmatter, domain, note_type)
    tags = _merge_tags(
        [domain, note_type],
        _path_context_tags(note_path, root),
        list(existing_tags),
        _subject_tags(title),
        inferred_tags,
    )
    related = _normalize_related_entries(root, _existing_related_links(body))
    for link in _related_links(root, title, inference_body, current_stem=current_stem):
        if link not in related:
            related.append(link)
    related = related[:6]

    metadata: dict[str, Any] = dict(frontmatter)
    metadata["domain"] = domain
    metadata["type"] = note_type
    metadata["status"] = str(frontmatter.get("status") or "정리완료")
    metadata["source"] = str(frontmatter.get("source") or ("raw" if any(path.startswith("raw/") for path in _extract_source_paths(original)) else "manual"))
    metadata["coverage"] = _infer_coverage(body, str(frontmatter.get("coverage") or legacy_meta.get("coverage") or "").strip() or None)
    metadata["last_curated"] = _today()
    if "last_compiled" in frontmatter or "last_compiled" in legacy_meta:
        metadata["last_compiled"] = str(frontmatter.get("last_compiled") or legacy_meta.get("last_compiled"))
    metadata["tags"] = tags

    rendered = _render_metadata_frontmatter(metadata)
    curated_body = body.rstrip() + "\n"
    if related:
        curated_body = _replace_section(curated_body, "관련 문서", [f"- {link}" for link in related])
    new_content = rendered + "\n\n" + curated_body.lstrip()
    new_content = "\n".join(_trim_blank_lines(new_content.splitlines())) + "\n"

    rationale = {
        "stage": "observe -> infer -> propose",
        "why_tags": f"domain/type, 폴더 맥락, 문서 제목, 기존 태그를 합쳐 {len(tags)}개 태그로 정리",
        "why_links": "기존 관련 문서를 보존하고, 실제로 존재하는 wiki 문서만 보강",
        "summary": "frontmatter, 태그, 관련 문서 섹션을 안전 범위에서 정리",
    }
    if new_content == original:
        return None, rationale
    return new_content, rationale

def _render_raw_candidate_document(
    root: Path,
    *,
    title: str,
    category: str,
    source_rel: str,
    raw_content: str,
    target_path: str,
) -> str:
    metadata, clean_body = _normalize_raw_body(raw_content, root, title)
    profile = _curated_profile(source_rel, target_path)
    note_type = str(profile.get("note_type") or _derive_note_type(title, clean_body, metadata, category))
    tags = list(profile.get("tags") or _derive_tags(title, clean_body, metadata, category, note_type))
    summary = str(profile.get("summary") or _summary_from_body(title, clean_body))
    related = []
    if profile.get("related"):
        related = [link for stem in profile["related"] if (link := _format_link(root, stem))]
    if not related:
        related = _related_links(root, title, clean_body, current_stem=Path(target_path).stem)
    excerpt = str(profile.get("body_override") or _balance_code_fences(_excerpt(clean_body, limit=2200)))

    sections = [
        _render_frontmatter(category=category, note_type=note_type, source_kind="raw", coverage="low", tags=tags),
        "",
        f"# {title}",
        "",
        "## 한줄 요약",
        summary,
        "",
        "## 핵심 내용",
        excerpt or "핵심 내용이 아직 비어 있다.",
    ]
    if related:
        sections.extend([
            "",
            "## 관련 문서",
            *(f"- {link}" for link in related),
        ])
    sections.extend([
        "",
        "## AlphaVaults 근거",
        f"- {source_rel}",
    ])
    return "\n".join(sections).rstrip() + "\n"


def _render_project_digest_document(root: Path, target_path: str) -> str:
    profile = _curated_profile("output/alphavaults/global/projects.json", target_path)
    global_dir = get_global_output_dir()
    projects = _load_json(global_dir / "projects.json", {}).get("projects", [])
    index = _load_json(global_dir / "search_index.json", {})
    docs = index.get("docs", {})

    project_lines = []
    for project in projects[:80]:
        key = project.get("key", project.get("name", "unknown"))
        project_lines.append(
            f"- `{key}`: {project.get('nodes', 0)}개 노드, {project.get('edges', 0)}개 링크, {project.get('path', '')}"
        )
    if not project_lines:
        project_lines.append("- 전역 프로젝트 manifest가 아직 없다. `alphavaults global` 실행이 필요하다.")

    related = []
    if profile.get("related"):
        related = [link for stem in profile["related"] if (link := _format_link(root, stem))]
    if not related:
        related = _related_links(root, f"AlphaVaults 자동 관측 {_today()}", "alphavaults global obsidian wiki", current_stem=Path(target_path).stem)
    frontmatter = _render_frontmatter(
        category="일반",
        note_type=str(profile.get("note_type") or "관측"),
        source_kind="alphavaults-global",
        coverage="low",
        tags=list(profile.get("tags") or ["일반", "관측", "알파볼츠", "프로젝트관측", "옵시디언"]),
    )
    sections = [
        frontmatter,
        "",
        f"# AlphaVaults 자동 관측 {_today()}",
        "",
        "## 한줄 요약",
        str(profile.get("summary") or "AlphaVaults가 전역 프로젝트와 파일 인덱스를 관측해 오늘의 구조 변화를 정리한 일일 기준 문서다."),
        "",
        "## 프로젝트 현황",
        *project_lines,
        "",
        "## 인덱스 현황",
        f"- 검색 문서 수: {len(docs)}",
        f"- 전역 출력 경로: `{global_dir}`",
        "",
        "## 다음 체크",
        "- [ ] 프로젝트별 핵심 결정 문서를 다시 연결할 것",
        "- [ ] `claude/`와 `codex/`의 중복 프로젝트 차이를 확인할 것",
        "- [ ] raw 메모와 프로젝트 근거를 함께 엮을 것",
    ]
    if related:
        sections.extend([
            "",
            "## 관련 문서",
            *(f"- {link}" for link in related),
        ])
    sections.extend([
        "",
        "## AlphaVaults 근거",
        "- output/alphavaults/global/projects.json",
        "- output/alphavaults/global/search_index.json",
    ])
    return "\n".join(sections).rstrip() + "\n"


def _extract_source_paths(text: str) -> list[str]:
    lines = text.splitlines()
    collecting = False
    sources: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped in {"## AlphaVaults 근거", "## Sources"}:
            collecting = True
            continue
        if collecting and stripped.startswith("## "):
            break
        if collecting and stripped.startswith("- "):
            source = stripped[2:].strip().strip("`")
            source = re.sub(r"^AlphaVaults:\s*", "", source)
            if source:
                sources.append(source)
    return sources


def _format_link(root: Path, stem: str) -> str | None:
    if not _note_path(root, stem):
        return None
    note_title = _note_title(root, stem)
    return f"[[{stem}]]" if note_title == stem else f"[[{stem}|{note_title}]]"


def _curated_profile(source_rel: str, target_path: str) -> dict[str, Any]:
    profile = _CURATED_NOTE_PROFILES.get(source_rel, {}).copy()
    if profile:
        return profile
    if "output/alphavaults/global/" in source_rel or Path(target_path).stem.startswith("alphavaults-자동-관측-"):
        return {
            "note_type": "관측",
            "summary": "AlphaVaults가 전역 프로젝트와 파일 인덱스를 관측해 오늘의 구조 변화를 정리한 일일 기준 문서다.",
            "tags": ["일반", "관측", "알파볼츠", "프로젝트관측", "옵시디언"],
            "related": ["옵시디언-사용법", "바이브코딩"],
        }
    return {}


def _load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _server_log(message: str) -> None:
    """Append a diagnostic line to the review server log."""
    log_path = get_review_dir() / "server.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as f:
        f.write(f"[{_now()}] {message}\n")


def _normalize_heading_title(text: str) -> str:
    title = re.sub(r"\s+", " ", text.strip())
    if not title:
        return ""
    tokens = title.split()
    non_tag_tokens = [token for token in tokens if not token.startswith("#")]
    if non_tag_tokens:
        title = " ".join(non_tag_tokens)
    return title.strip(" -:\t")


def _is_placeholder_title(title: str) -> bool:
    normalized = title.strip().lower()
    if not normalized:
        return True
    if re.fullmatch(r"(heading|헤딩|title|제목)\s*\d*", normalized):
        return True
    return all(token.startswith("#") for token in normalized.split())


def _title_from_markdown(path: Path, content: str) -> str:
    for line in content.splitlines():
        match = re.match(r"^\s*#{1,3}\s+(.+?)\s*$", line)
        if not match:
            continue
        title = _normalize_heading_title(match.group(1))
        if not title or _is_placeholder_title(title):
            continue
        return title
    return path.stem


def _item_preview(item: dict, limit: int = 220, multiline: bool = False) -> str:
    text = item.get("content", "")
    if "## 핵심 내용" in text:
        text = text.split("## 핵심 내용", 1)[1]
    elif "## 원본 핵심" in text:
        text = text.split("## 원본 핵심", 1)[1]
    else:
        text = _strip_frontmatter(text)

    lines: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line in {"---", "## 요약", "## 한줄 요약", "## 원본 핵심", "## 핵심 내용", "## 관련 문서"}:
            continue
        if line.startswith("## AlphaVaults 근거") or line.startswith("## Sources"):
            break
        if line.startswith("# "):
            continue
        if line.startswith("## "):
            continue
        if line.startswith("- [[INDEX]]"):
            continue
        if line.startswith("- raw/") or line.startswith("- AlphaVaults:"):
            continue
        if line.startswith("이 문서는 `raw/` 원본을 바탕으로 AlphaVaults가 자동 승격 후보로 만든 초안이다."):
            continue
        lines.append(line)

    text = ("\n".join(lines) if multiline else " ".join(lines)).strip()
    text = re.sub(r"!\[\[([^\]]+)\]\]", r"[임베드] \1", text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", text)

    def _wikilink_repl(match: re.Match[str]) -> str:
        inner = match.group(1).strip()
        if "|" in inner:
            target, alias = inner.split("|", 1)
            return alias.strip() or Path(target.strip()).name or target.strip()
        if "#" in inner:
            target, anchor = inner.split("#", 1)
            base = Path(target.strip()).name or target.strip()
            return f"{base} > {anchor.strip()}"
        return Path(inner).name or inner

    text = re.sub(r"\[\[([^\]]+)\]\]", _wikilink_repl, text)
    text = re.sub(r"[ \t]+", " ", text)
    if not multiline:
        text = re.sub(r"\s+", " ", text)
    if len(text) > limit:
        text = text[:limit].rstrip() + "..."
    return text or "미리보기 가능한 본문이 아직 없습니다."


def _item_source_markdown(item: dict, limit: int = 2400) -> str:
    text = item.get("content", "")
    if "## 핵심 내용" in text:
        text = text.split("## 핵심 내용", 1)[1]
    elif "## 원본 핵심" in text:
        text = text.split("## 원본 핵심", 1)[1]
    else:
        text = _strip_frontmatter(text)

    lines: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        if stripped.startswith("## 관련 문서") or stripped.startswith("## AlphaVaults 근거") or stripped.startswith("## Sources"):
            break
        if not lines and not stripped:
            continue
        lines.append(line)

    markdown = "\n".join(lines).strip()
    if len(markdown) > limit:
        markdown = markdown[:limit].rstrip() + "\n..."
    return markdown or "(원문이 비어 있습니다.)"


def _classify_wiki_dir(title: str, content: str) -> str:
    text = f"{title}\n{content}".lower()
    if any(k in text for k in ["alphamate", "alphaedge", "heatcoach", "code", "dev", "claude", "codex", "개발"]):
        return "개발"
    if any(k in text for k in ["투자", "stock", "alphaedge", "market", "기업", "산업", "매크로"]):
        return "투자"
    if any(k in text for k in ["결정", "decision", "adr"]):
        return "결정"
    return "일반"


def _relative_to_root(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def _new_file_patch(rel_path: str, content: str) -> str:
    lines = content.splitlines()
    patch = [
        f"diff --git a/{rel_path} b/{rel_path}",
        "new file mode 100644",
        "index 0000000..0000000",
        "--- /dev/null",
        f"+++ b/{rel_path}",
        f"@@ -0,0 +1,{len(lines)} @@",
    ]
    patch.extend(f"+{line}" for line in lines)
    return "\n".join(patch) + "\n"


def _update_file_patch(rel_path: str, before: str, after: str) -> str:
    diff = unified_diff(
        before.splitlines(),
        after.splitlines(),
        fromfile=f"a/{rel_path}",
        tofile=f"b/{rel_path}",
        lineterm="",
    )
    return "\n".join(diff) + "\n"


def _item_patch(item: dict, root: Path) -> str:
    if item.get("apply_mode") == "update":
        current_text = _read_text(root / item["target_path"])
        return _update_file_patch(item["target_path"], current_text, item["content"])
    return _new_file_patch(item["target_path"], item["content"])


def _batch_dir(batch_id: str | None = None) -> Path:
    return get_review_dir() / (batch_id or _today())


def _batch_path(batch_id: str | None = None) -> Path:
    return _batch_dir(batch_id) / "batch.json"


def _load_batch(batch_id: str | None = None) -> dict:
    return _load_json(_batch_path(batch_id), {})


def _save_batch(batch: dict) -> None:
    _write_json(_batch_path(batch["batch_id"]), batch)


def _raw_candidates(root: Path, existing_targets: set[str], limit: int) -> list[dict]:
    raw_dir = root / "raw"
    candidates: list[dict] = []
    if not raw_dir.exists():
        return candidates

    raw_files = sorted(raw_dir.rglob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    for raw_file in raw_files[:limit]:
        if "sync-conflict" in raw_file.name.lower():
            continue
        content = _read_text(raw_file, 4000)
        title = _title_from_markdown(raw_file, content)
        _, raw_body = _parse_frontmatter(content)
        category = _classify_wiki_dir(title, raw_body)
        slug = _slug(title, raw_file.stem)
        rel_target = f"wiki/{category}/{slug}.md"
        suffix = 2
        while rel_target in existing_targets or (root / rel_target).exists():
            rel_target = f"wiki/{category}/{slug}-{suffix}.md"
            suffix += 1
        existing_targets.add(rel_target)

        source_rel = _relative_to_root(raw_file, root)
        body = _render_raw_candidate_document(
            root,
            title=title,
            category=category,
            source_rel=source_rel,
            raw_content=content,
            target_path=rel_target,
        )
        item_id = "raw-" + hashlib.sha1(source_rel.encode("utf-8")).hexdigest()[:12]
        candidates.append({
            "id": item_id,
            "kind": "raw-promotion",
            "title": title,
            "status": "pending",
            "risk": "medium",
            "target_path": rel_target,
            "source_paths": [source_rel],
            "rationale": "raw 원본을 승인 지식 후보로 승격",
            "content": body,
        })
    return candidates


def _wiki_curation_candidates(
    root: Path,
    existing_targets: set[str],
    *,
    backfill: bool,
    limit: int = 0,
) -> list[dict]:
    wiki_dir = root / "wiki"
    if not wiki_dir.exists():
        return []

    state = _load_agent_state()
    files_state = state.setdefault("files", {})
    candidates: list[dict] = []
    scanned = 0

    for note_path in sorted(wiki_dir.rglob("*.md")):
        rel_target = _relative_to_root(note_path, root)
        if "sync-conflict" in note_path.name.lower():
            continue
        if note_path.name.upper() == "INDEX.MD":
            continue
        if rel_target in existing_targets:
            continue

        current_text = _read_text(note_path)
        current_hash = _hash_text(current_text)
        state_entry = files_state.get(rel_target, {})
        if not backfill and state_entry.get("hash") == current_hash:
            continue

        new_content, rationale = _render_wiki_curated_document(root, note_path)
        scanned += 1
        files_state[rel_target] = {
            "hash": current_hash,
            "last_seen_at": _now(),
            "last_status": state_entry.get("last_status", "observed"),
        }
        if not new_content:
            continue

        title = _title_from_markdown(note_path, current_text)
        item_id = "curate-" + hashlib.sha1(rel_target.encode("utf-8")).hexdigest()[:12]
        candidates.append({
            "id": item_id,
            "kind": "wiki-curation",
            "title": title,
            "status": "pending",
            "risk": "low",
            "apply_mode": "update",
            "target_path": rel_target,
            "source_paths": _extract_source_paths(current_text) or [rel_target],
            "observed_hash": current_hash,
            "rationale": "기존 wiki 문서를 읽고 맥락 태그, 관련 링크, frontmatter를 보강",
            "agent": rationale,
            "content": new_content,
        })
        existing_targets.add(rel_target)
        if limit and len(candidates) >= limit:
            break

    state["last_scan_at"] = _now()
    state["last_scan_count"] = scanned
    _save_agent_state(state)
    return candidates


def _project_digest_candidate(root: Path, existing_targets: set[str]) -> dict:
    rel_target = f"wiki/일반/alphavaults-자동-관측-{_today()}.md"
    suffix = 2
    while rel_target in existing_targets or (root / rel_target).exists():
        rel_target = f"wiki/일반/alphavaults-자동-관측-{_today()}-{suffix}.md"
        suffix += 1
    existing_targets.add(rel_target)
    body = _render_project_digest_document(root, rel_target)
    return {
        "id": "digest-" + _today(),
        "kind": "project-digest",
        "title": f"AlphaVaults 자동 관측 {_today()}",
        "status": "pending",
        "risk": "low",
        "target_path": rel_target,
        "source_paths": [
            "output/alphavaults/global/projects.json",
            "output/alphavaults/global/search_index.json",
        ],
        "rationale": "모든 프로젝트와 파일 인덱스의 일일 관측 digest",
        "content": body,
    }


def _build_review_items(
    root: Path,
    limit: int,
    existing_targets: set[str] | None = None,
    *,
    wiki_backfill: bool = False,
    wiki_limit: int = 0,
) -> list[dict]:
    targets = set(existing_targets or set())
    items = [_project_digest_candidate(root, targets)]
    items.extend(_wiki_curation_candidates(root, targets, backfill=wiki_backfill, limit=wiki_limit))
    items.extend(_raw_candidates(root, targets, limit=limit))
    return items


def _ensure_unique_target_path(item: dict, existing_targets: set[str], root: Path) -> None:
    rel_target = item["target_path"]
    target = Path(rel_target)
    suffix = target.suffix or ".md"
    stem = target.stem
    parent = target.parent
    counter = 2
    while rel_target in existing_targets or (root / rel_target).exists():
        rel_target = str(parent / f"{stem}-{counter}{suffix}").replace("\\", "/")
        counter += 1
    item["target_path"] = rel_target
    existing_targets.add(rel_target)


def _write_batch_markdown(batch: dict) -> None:
    lines = [
        f"# AlphaVaults Review Batch {batch['batch_id']}",
        "",
        f"- Created: {batch['created_at']}",
        f"- RULES: `{batch['rules_path']}`",
        f"- Items: {len(batch['items'])}",
        "",
        "## Items",
        "",
    ]
    for item in batch["items"]:
        value_base = f"{batch['batch_id']}|{item['id']}"
        lines.extend([
            f"### {item['title']}",
            f"- id: `{item['id']}`",
            f"- status: `{item['status']}`",
            f"- risk: `{item['risk']}`",
            f"- apply_mode: `{item.get('apply_mode', 'create')}`",
            f"- target: `{item['target_path']}`",
            f"- rationale: {item['rationale']}",
            f"- Slack values: `{value_base}|approve`, `{value_base}|reject`, `{value_base}|hold`",
        ])
        agent = item.get("agent") or {}
        if agent:
            if agent.get("stage"):
                lines.append(f"- agent: {agent['stage']}")
            if agent.get("why_tags"):
                lines.append(f"- why_tags: {agent['why_tags']}")
            if agent.get("why_links"):
                lines.append(f"- why_links: {agent['why_links']}")
        lines.append("")
    (_batch_dir(batch["batch_id"]) / "batch.md").write_text("\n".join(lines), encoding="utf-8")


def generate_review_batch(
    limit: int = 20,
    notify: bool = False,
    force: bool = False,
    *,
    backfill_wiki: bool = False,
    wiki_limit: int = 0,
) -> dict:
    """Generate a review batch without touching wiki/."""
    root = get_llmwiki_root()
    wiki_backfill = backfill_wiki or not _agent_state_path().exists()
    bridge_enabled = bool(get_config("telebot_bridge_enabled", False))
    bridge_result = {"enabled": bridge_enabled}
    if bridge_enabled:
        from alphavaults.telebot_bridge import sync_telebot_bridge

        bridge_result = sync_telebot_bridge()
    review_dir = _batch_dir()
    patches_dir = review_dir / "patches"
    existing = _load_batch(_today())
    if existing and not force:
        existing_ids = {item.get("id") for item in existing.get("items", [])}
        existing_targets = {item.get("target_path") for item in existing.get("items", []) if item.get("target_path")}
        candidate_items = _build_review_items(
            root,
            limit=limit,
            wiki_backfill=wiki_backfill,
            wiki_limit=wiki_limit,
        )
        candidate_by_id = {item["id"]: item for item in candidate_items}
        refreshed = 0
        patches_dir.mkdir(parents=True, exist_ok=True)

        for item in existing.get("items", []):
            candidate = candidate_by_id.get(item.get("id"))
            if not candidate or item.get("status") == "applied":
                continue
            mutable_fields = (
                "title",
                "risk",
                "target_path",
                "source_paths",
                "rationale",
                "content",
                "apply_mode",
                "observed_hash",
                "agent",
            )
            changed = any(item.get(field) != candidate.get(field) for field in mutable_fields)
            if not changed:
                continue
            previous_status = item.get("status")
            previous_decided_at = item.get("decided_at")
            previous_decided_by = item.get("decided_by")
            previous_error = item.get("error")
            item.update(candidate)
            item["status"] = previous_status
            if previous_decided_at:
                item["decided_at"] = previous_decided_at
            if previous_decided_by:
                item["decided_by"] = previous_decided_by
            if previous_error:
                item["error"] = previous_error
            patch_path = patches_dir / f"{item['id']}.patch"
            patch_path.write_text(_item_patch(item, root), encoding="utf-8")
            item["patch_path"] = _relative_to_root(patch_path, root)
            refreshed += 1

        new_items = [item for item in candidate_items if item.get("id") not in existing_ids]
        if new_items:
            for item in new_items:
                if item.get("apply_mode") != "update":
                    _ensure_unique_target_path(item, existing_targets, root)
                patch_path = patches_dir / f"{item['id']}.patch"
                patch_path.write_text(_item_patch(item, root), encoding="utf-8")
                item["patch_path"] = _relative_to_root(patch_path, root)
            existing.setdefault("items", []).extend(new_items)
        if new_items or refreshed:
            existing["updated_at"] = _now()
            existing["bridge"] = bridge_result
            existing.pop("skipped", None)
            _save_batch(existing)
            _write_batch_markdown(existing)
            if existing.get("slack") or existing.get("slack_message"):
                existing["slack_refresh"] = update_slack_review(existing["batch_id"])
            elif notify:
                existing["slack"] = send_slack_review(existing["batch_id"])
            _save_batch(existing)
            if new_items:
                existing["merged"] = len(new_items)
            if refreshed:
                existing["refreshed"] = refreshed
            return existing
        if notify and not existing.get("slack"):
            existing["slack"] = send_slack_review(existing["batch_id"])
            _save_batch(existing)
        existing["bridge"] = bridge_result
        existing["skipped"] = "batch already exists"
        return existing
    review_dir.mkdir(parents=True, exist_ok=True)
    patches_dir.mkdir(parents=True, exist_ok=True)

    rules_result = check_rules()
    items = _build_review_items(
        root,
        limit=limit,
        wiki_backfill=wiki_backfill,
        wiki_limit=wiki_limit,
    )

    for item in items:
        patch_path = patches_dir / f"{item['id']}.patch"
        patch_path.write_text(_item_patch(item, root), encoding="utf-8")
        item["patch_path"] = _relative_to_root(patch_path, root)

    batch = {
        "batch_id": _today(),
        "created_at": _now(),
        "rules_path": str(get_config("rules_path")),
        "rules_ok": rules_result["ok"],
        "bridge": bridge_result,
        "items": items,
    }
    _save_batch(batch)
    _write_batch_markdown(batch)

    if notify:
        batch["slack"] = send_slack_review(batch["batch_id"])
        _save_batch(batch)
    return batch


def batch_status(batch_id: str | None = None) -> dict:
    """Return summary for a review batch."""
    batch = _load_batch(batch_id)
    counts: dict[str, int] = {}
    for item in batch.get("items", []):
        counts[item.get("status", "unknown")] = counts.get(item.get("status", "unknown"), 0) + 1
    return {
        "batch_id": batch.get("batch_id", batch_id or _today()),
        "exists": bool(batch),
        "counts": counts,
        "items": batch.get("items", []),
    }


def normalize_automation_docs(root: Path | None = None, write: bool = True) -> dict:
    """Re-render existing AlphaVaults automation wiki notes using current formatting rules."""
    root = root or get_llmwiki_root()
    wiki_dir = root / "wiki"
    if not wiki_dir.exists():
        return {"scanned": 0, "updated": 0, "skipped": []}

    scanned = 0
    updated = 0
    skipped: list[str] = []

    for note_path in sorted(wiki_dir.rglob("*.md")):
        text = _read_text(note_path)
        if "automation: alphavaults" not in text:
            continue

        scanned += 1
        rel_target = _relative_to_root(note_path, root)
        title = _title_from_markdown(note_path, text)
        source_paths = _extract_source_paths(text)
        new_content = None

        raw_source = next((path for path in source_paths if path.startswith("raw/")), None)
        if raw_source:
            raw_path = root / raw_source
            if raw_path.exists():
                category = note_path.parent.name
                new_content = _render_raw_candidate_document(
                    root,
                    title=title,
                    category=category,
                    source_rel=raw_source,
                    raw_content=_read_text(raw_path, 6000),
                    target_path=rel_target,
                )
            else:
                skipped.append(f"{rel_target}: missing source `{raw_source}`")
                continue
        elif any("output/alphavaults/global" in path for path in source_paths):
            new_content = _render_project_digest_document(root, rel_target)
        else:
            skipped.append(f"{rel_target}: no supported source paths")
            continue

        if new_content == text:
            continue
        if write:
            _cow_snapshot(note_path, root)
            note_path.write_text(new_content, encoding="utf-8")
        updated += 1

    return {"scanned": scanned, "updated": updated, "skipped": skipped}


def _record_curation_state(item: dict, *, status: str, content: str | None = None) -> None:
    if item.get("kind") != "wiki-curation":
        return
    state = _load_agent_state()
    files = state.setdefault("files", {})
    rel_target = item.get("target_path")
    if not rel_target:
        return
    entry = files.get(rel_target, {})
    entry["hash"] = _hash_text(content if content is not None else item.get("content", ""))
    entry["last_status"] = status
    entry["last_item_id"] = item.get("id")
    entry["last_updated_at"] = _now()
    files[rel_target] = entry
    _save_agent_state(state)


def _set_items_decision(batch: dict, item_ids: list[str], decision: str, user_id: str | None = None) -> list[dict]:
    if decision not in {"approve", "reject", "hold"}:
        raise ValueError(f"Unknown decision: {decision}")

    status_map = {"approve": "approved", "reject": "rejected", "hold": "held"}
    wanted = set(item_ids)
    updated: list[dict] = []

    for item in batch.get("items", []):
        if item.get("id") not in wanted:
            continue
        item["status"] = status_map[decision]
        item["decided_at"] = _now()
        if user_id:
            item["decided_by"] = user_id
        if decision in {"reject", "hold"}:
            target_path = get_llmwiki_root() / item["target_path"] if item.get("target_path") else None
            if item.get("kind") == "wiki-curation" and target_path and target_path.exists():
                _record_curation_state(item, status=status_map[decision], content=_read_text(target_path))
        updated.append(item)

    if not updated:
        raise KeyError(f"Review item not found: {', '.join(item_ids)}")

    _save_batch(batch)
    _write_batch_markdown(batch)
    return updated


def set_items_decision(batch_id: str, item_ids: list[str], decision: str, user_id: str | None = None) -> list[dict]:
    batch = _load_batch(batch_id)
    if not batch:
        raise FileNotFoundError(f"Review batch not found: {batch_id}")
    return _set_items_decision(batch, item_ids, decision, user_id=user_id)


def set_item_decision(batch_id: str, item_id: str, decision: str, user_id: str | None = None) -> dict:
    """Set item decision from Slack or CLI."""
    return set_items_decision(batch_id, [item_id], decision, user_id=user_id)[0]


def _run_git(root: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args],
        cwd=root,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=60,
        check=check,
    )


def ensure_git_repo(root: Path | None = None) -> None:
    """Ensure the LLMwiki root is a local git repository."""
    root = root or get_llmwiki_root()
    if not (root / ".git").exists():
        _run_git(root, ["init"])
    _run_git(root, ["config", "user.name", "AlphaVaults"], check=False)
    _run_git(root, ["config", "user.email", "alphavaults@local"], check=False)


def sync_conflicts(root: Path | None = None) -> list[str]:
    root = root or get_llmwiki_root()
    if (root / ".git").exists():
        status = _run_git(root, ["status", "--porcelain"], check=False).stdout.splitlines()
        return [
            line[3:].replace("\\", "/")
            for line in status
            if len(line) > 3 and "sync-conflict" in line[3:].lower()
        ]
    conflicts = []
    for path in root.rglob("*"):
        if path.is_file() and "sync-conflict" in path.name.lower():
            conflicts.append(_relative_to_root(path, root))
    return conflicts


def _unexpected_dirty(root: Path) -> list[str]:
    status = _run_git(root, ["status", "--porcelain", "--untracked-files=all"], check=False).stdout.splitlines()
    unexpected = []
    allowed_prefixes = (
        "?? output/alphavaults/review/",
        " M output/alphavaults/review/",
        "M  output/alphavaults/review/",
        "A  output/alphavaults/review/",
        "AM output/alphavaults/review/",
    )
    for line in status:
        path = line[3:].replace("\\", "/") if len(line) > 3 else line
        raw = line.replace("\\", "/")
        if raw.startswith(allowed_prefixes):
            continue
        if path in {".gitignore", ".stignore"}:
            continue
        unexpected.append(raw)
    return unexpected


def _append_log(root: Path, message: str) -> Path:
    log_path = root / "log.md"
    machine = _machine_id()
    entry = (
        f"\n## [{_today()}] [{machine}] review | AlphaVaults 자동 적용\n"
        f"- {message}\n"
    ).encode("utf-8")
    with open(log_path, "ab") as f:
        _file_lock(f)
        try:
            f.write(entry)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        finally:
            _file_unlock(f)
    return log_path


def apply_approved(batch_id: str | None = None, notify_slack: bool = False) -> dict:
    """Apply approved review items to wiki/ and commit the result."""
    root = get_llmwiki_root()
    ensure_git_repo(root)
    batch = _load_batch(batch_id)
    if not batch:
        return {"applied": 0, "failed": 0, "held": 0, "errors": ["No review batch found."]}

    apply_log = _batch_dir(batch["batch_id"]) / "apply.log"
    errors: list[str] = []
    applied: list[dict] = []

    conflicts = sync_conflicts(root)
    if conflicts:
        msg = f"Hold: sync-conflict files detected: {conflicts[:5]}"
        apply_log.write_text(msg + "\n", encoding="utf-8")
        if notify_slack:
            send_slack_result(f"AlphaVaults apply hold for {batch_id or _today()}: {msg}")
        return {"applied": 0, "failed": 0, "held": len(batch.get("items", [])), "errors": [msg]}

    dirty = _unexpected_dirty(root)
    if dirty:
        msg = f"Hold: unexpected git working tree changes: {dirty[:10]}"
        apply_log.write_text(msg + "\n", encoding="utf-8")
        if notify_slack:
            send_slack_result(f"AlphaVaults apply hold for {batch_id or _today()}: {msg}")
        return {"applied": 0, "failed": 0, "held": len(batch.get("items", [])), "errors": [msg]}

    for item in batch.get("items", []):
        if item.get("status") != "approved":
            continue
        target = root / item["target_path"]
        try:
            if item.get("apply_mode") == "update":
                if not target.exists():
                    raise FileNotFoundError(f"Target missing for update: {item['target_path']}")
                existing = target.read_text(encoding="utf-8", errors="ignore")
                observed_hash = item.get("observed_hash")
                if observed_hash and _hash_text(existing) != observed_hash:
                    raise RuntimeError(f"Observed hash mismatch for {item['target_path']}; 문서가 review 이후 변경되었다.")
                if existing != item["content"]:
                    _cow_snapshot(target, root)
                    target.write_text(item["content"], encoding="utf-8")
                _record_curation_state(item, status="applied", content=item["content"])
            else:
                if target.exists():
                    existing = target.read_text(encoding="utf-8", errors="ignore")
                    if existing != item["content"]:
                        raise FileExistsError(f"Target already exists with different content: {item['target_path']}")
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(item["content"], encoding="utf-8")
            item["status"] = "applied"
            item["applied_at"] = _now()
            applied.append(item)
        except Exception as exc:  # noqa: BLE001 - persist exact failure in review queue
            item["status"] = "failed"
            item["error"] = str(exc)
            errors.append(f"{item['id']}: {exc}")

    if applied:
        log_path = _append_log(
            root,
            f"{batch['batch_id']} batch에서 {len(applied)}개 항목을 wiki/에 반영했다.",
        )
        _save_batch(batch)
        _write_batch_markdown(batch)

        add_paths = [item["target_path"] for item in applied]
        add_paths.extend([
            _relative_to_root(_batch_path(batch["batch_id"]), root),
            _relative_to_root(_batch_dir(batch["batch_id"]) / "batch.md", root),
            _relative_to_root(_batch_dir(batch["batch_id"]) / "patches", root),
            _relative_to_root(apply_log, root),
            _relative_to_root(log_path, root),
        ])
        _run_git(root, ["add", "--", *add_paths], check=False)
        commit_msg = f"AlphaVaults review: {batch['batch_id']} ({len(applied)} items)"
        commit = _run_git(root, ["commit", "-m", commit_msg], check=False)
        if commit.returncode != 0:
            errors.append(commit.stderr.strip() or commit.stdout.strip() or "git commit failed")

        if get_config("history_enabled", True):
            try:
                prune_history(
                    root,
                    max_age_days=int(get_config("history_max_age_days", 90) or 90),
                    max_per_file=int(get_config("history_max_per_file", 20) or 20),
                )
            except (OSError, ValueError):
                pass

    if not applied and not errors:
        result = {"applied": 0, "failed": 0, "held": 0, "errors": []}
        if notify_slack:
            send_slack_result(f"AlphaVaults apply skipped for {batch_id or _today()}: 승인된 항목이 없다.")
        return result

    apply_lines = [
        f"[{_now()}] applied={len(applied)} failed={len(errors)}",
        *errors,
    ]
    apply_log.write_text("\n".join(apply_lines) + "\n", encoding="utf-8")
    _save_batch(batch)
    result = {"applied": len(applied), "failed": len(errors), "held": 0, "errors": errors}
    update_slack_review(batch["batch_id"])
    if notify_slack:
        if errors:
            send_slack_result(
                f"AlphaVaults apply completed with errors for {batch_id or _today()}: applied={result['applied']} failed={result['failed']}"
            )
        else:
            send_slack_result(
                f"AlphaVaults apply succeeded for {batch_id or _today()}: applied={result['applied']} failed=0"
            )
    return result


def verify_slack_signature(raw_body: bytes, headers: dict[str, str], signing_secret: str | None = None) -> bool:
    """Verify Slack request signature."""
    secret = signing_secret or get_config("slack_signing_secret")
    if not secret:
        return False
    timestamp = headers.get("X-Slack-Request-Timestamp") or headers.get("x-slack-request-timestamp")
    signature = headers.get("X-Slack-Signature") or headers.get("x-slack-signature")
    if not timestamp or not signature:
        return False
    try:
        ts = int(timestamp)
    except ValueError:
        return False
    if abs(time.time() - ts) > 60 * 5:
        return False
    base = f"v0:{timestamp}:".encode("utf-8") + raw_body
    expected = "v0=" + hmac.new(secret.encode("utf-8"), base, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def _status_summary(item: dict) -> str:
    status = item.get("status", "unknown")
    parts = [f"*Status:* `{status}`"]
    if item.get("decided_by"):
        parts.append(f"*By:* <@{item['decided_by']}>")
    if item.get("decided_at"):
        parts.append(f"*At:* `{item['decided_at']}`")
    if item.get("applied_at"):
        parts.append(f"*Applied:* `{item['applied_at']}`")
    if item.get("error"):
        parts.append(f"*Error:* `{item['error']}`")
    return "  ".join(parts)


def _displayed_pending_items(batch: dict, limit: int = 20) -> list[dict]:
    return [item for item in batch.get("items", []) if item.get("status") == "pending"][:limit]


def _truncate_plain_text(text: str, limit: int = 60) -> str:
    clean = re.sub(r"\s+", " ", text).strip()
    if len(clean) > limit:
        return clean[: limit - 1].rstrip() + "…"
    return clean or "무제목"


def _bulk_action_elements(batch: dict, *, suffix: str = "") -> list[dict]:
    suffix = suffix or "main"
    return [
        {
            "type": "button",
            "text": {"type": "plain_text", "text": "선택 승인"},
            "style": "primary",
            "value": f"{batch['batch_id']}|bulk|approve",
            "action_id": f"alphavaults_bulk_approve_{suffix}",
            "confirm": {
                "title": {"type": "plain_text", "text": "선택 항목 승인"},
                "text": {"type": "mrkdwn", "text": "체크한 항목만 한 번에 승인하고 적용 대기 상태로 전환한다."},
                "confirm": {"type": "plain_text", "text": "승인"},
                "deny": {"type": "plain_text", "text": "취소"},
            },
        },
        {
            "type": "button",
            "text": {"type": "plain_text", "text": "선택 보류"},
            "value": f"{batch['batch_id']}|bulk|hold",
            "action_id": f"alphavaults_bulk_hold_{suffix}",
        },
        {
            "type": "button",
            "text": {"type": "plain_text", "text": "선택 폐기"},
            "style": "danger",
            "value": f"{batch['batch_id']}|bulk|reject",
            "action_id": f"alphavaults_bulk_reject_{suffix}",
            "confirm": {
                "title": {"type": "plain_text", "text": "선택 항목 폐기"},
                "text": {"type": "mrkdwn", "text": "체크한 항목만 폐기 상태로 바꾼다."},
                "confirm": {"type": "plain_text", "text": "폐기"},
                "deny": {"type": "plain_text", "text": "취소"},
            },
        },
    ]


def _bulk_control_blocks(batch: dict) -> list[dict]:
    pending = _displayed_pending_items(batch)
    if len(pending) < 2:
        return []

    return [
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": "각 항목 옆 체크박스로 선택하고 아래 버튼으로 일괄 처리한다. `전체 선택`은 현재 Slack 메시지에 표시된 pending 항목만 대상으로 한다.",
                }
            ],
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "*일괄 선택*\n`전체 선택`을 켜면 현재 보이는 pending 항목 전체를 대상으로 한다.",
            },
            "accessory": {
                "type": "checkboxes",
                "action_id": "alphavaults_select_all",
                "options": [
                    {
                        "text": {"type": "plain_text", "text": "전체 선택"},
                        "value": "all",
                    }
                ],
            },
        },
        {
            "type": "actions",
            "elements": _bulk_action_elements(batch, suffix="top"),
        },
    ]


def _bulk_footer_blocks(batch: dict) -> list[dict]:
    if len(_displayed_pending_items(batch)) < 2:
        return []
    return [
        {
            "type": "actions",
            "elements": _bulk_action_elements(batch, suffix="bottom"),
        }
    ]


def _bulk_select_all_enabled(payload: dict) -> bool:
    state_values = payload.get("state", {}).get("values", {})
    for block_value in state_values.values():
        if not isinstance(block_value, dict):
            continue
        for action_id, action_state in block_value.items():
            if action_id != "alphavaults_select_all":
                continue
            return bool(action_state.get("selected_options"))
    return False


def _selected_bulk_item_ids(payload: dict, batch: dict | None = None) -> list[str]:
    if batch and _bulk_select_all_enabled(payload):
        return [item["id"] for item in _displayed_pending_items(batch)]

    state_values = payload.get("state", {}).get("values", {})
    selected: list[str] = []
    for block_value in state_values.values():
        if not isinstance(block_value, dict):
            continue
        for action_id, action_state in block_value.items():
            if not str(action_id).startswith("alphavaults_select_") or action_id == "alphavaults_select_all":
                continue
            for option in action_state.get("selected_options", []):
                value = option.get("value")
                if value and value not in selected:
                    selected.append(value)
    return selected


def _selection_accessory(item: dict) -> dict:
    return {
        "type": "checkboxes",
        "action_id": f"alphavaults_select_{item['id']}",
        "options": [
            {
                "text": {"type": "plain_text", "text": "선택"},
                "value": item["id"],
            }
        ],
    }


def open_preview_modal(batch_id: str, item_id: str, trigger_id: str | None) -> dict:
    """Open a Slack modal with the candidate preview."""
    if not trigger_id:
        return {"opened": False, "reason": "missing trigger_id"}

    batch = _load_batch(batch_id)
    if not batch:
        return {"opened": False, "reason": "review batch not found"}

    item = next((entry for entry in batch.get("items", []) if entry.get("id") == item_id), None)
    if not item:
        return {"opened": False, "reason": "review item not found"}

    preview = _item_preview(item, limit=2200, multiline=True).replace("```", "'''")
    raw_markdown = _item_source_markdown(item, limit=2200).replace("```", "'''")
    sources = item.get("source_paths") or []
    sources_text = "\n".join(f"- `{source}`" for source in sources[:10]) if sources else "- (없음)"

    view = {
        "type": "modal",
        "callback_id": "alphavaults_preview",
        "title": {"type": "plain_text", "text": "내용 미리보기"},
        "close": {"type": "plain_text", "text": "닫기"},
        "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": (
                        f"*{item['title']}*\n"
                        f"`{item['status']}` -> `{item['target_path']}`\n"
                        f"{item['rationale']}"
                    ),
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*읽기용 미리보기*\n{preview}",
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*원문 Markdown*\n```{raw_markdown}```",
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Sources*\n{sources_text}",
                },
            },
        ],
    }
    result = _slack_api("views.open", {"trigger_id": trigger_id, "view": view})
    return {"opened": bool(result.get("ok")), "response": result}


def _slack_blocks(batch: dict) -> list[dict]:
    counts: dict[str, int] = {}
    for item in batch.get("items", []):
        status = item.get("status", "unknown")
        counts[status] = counts.get(status, 0) + 1

    count_text = ", ".join(f"{key}={value}" for key, value in sorted(counts.items())) or "no items"
    blocks: list[dict] = [
        {"type": "header", "text": {"type": "plain_text", "text": f"AlphaVaults Review {batch['batch_id']}"}},
        {"type": "section", "text": {"type": "mrkdwn", "text": f"*Items:* {len(batch.get('items', []))}  *RULES ok:* {batch.get('rules_ok')}  *Counts:* {count_text}"}},
    ]
    blocks.extend(_bulk_control_blocks(batch))
    for item in batch.get("items", [])[:20]:
        value_base = f"{batch['batch_id']}|{item['id']}"
        preview = _item_preview(item, limit=180)
        section = {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (
                    f"*{item['title']}*\n"
                    f"`{item['kind']}` -> `{item['target_path']}`\n"
                    f"{item['rationale']}\n"
                    f"> {preview}\n"
                    f"{_status_summary(item)}"
                ),
            },
        }
        if item.get("status") == "pending":
            section["accessory"] = _selection_accessory(item)
        blocks.append(section)
        if item.get("status") == "pending":
            blocks.append({
                "type": "actions",
                "elements": [
                    {"type": "button", "text": {"type": "plain_text", "text": "내용 보기"}, "value": f"{value_base}|preview", "action_id": f"alphavaults_preview_{item['id']}"},
                    {"type": "button", "text": {"type": "plain_text", "text": "승인"}, "style": "primary", "value": f"{value_base}|approve", "action_id": f"alphavaults_approve_{item['id']}"},
                    {"type": "button", "text": {"type": "plain_text", "text": "폐기"}, "style": "danger", "value": f"{value_base}|reject", "action_id": f"alphavaults_reject_{item['id']}"},
                    {"type": "button", "text": {"type": "plain_text", "text": "보류"}, "value": f"{value_base}|hold", "action_id": f"alphavaults_hold_{item['id']}"},
                ],
            })
    hidden = max(0, len(batch.get("items", [])) - 20)
    if hidden:
        blocks.append({
            "type": "context",
            "elements": [
                {"type": "mrkdwn", "text": f"Slack에는 처음 20개만 표시된다. 나머지 {hidden}개 항목의 근거는 batch.md에서 확인한다."}
            ],
        })
    blocks.extend(_bulk_footer_blocks(batch))
    return blocks


def _slack_api(method: str, payload: dict) -> dict:
    token = get_config("slack_bot_token")
    req = urllib.request.Request(
        f"https://slack.com/api/{method}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as response:  # noqa: S310 - Slack API endpoint is fixed
        return json.loads(response.read().decode("utf-8"))


def _slack_message_ref(batch: dict, payload: dict | None = None) -> tuple[str | None, str | None]:
    message = batch.get("slack_message", {})
    channel = message.get("channel")
    ts = message.get("ts")
    if channel and ts:
        return channel, ts
    response = batch.get("slack", {}).get("response", {})
    channel = response.get("channel") or channel
    ts = response.get("ts") or ts
    if payload:
        channel = payload.get("channel", {}).get("id") or payload.get("container", {}).get("channel_id") or channel
        ts = payload.get("container", {}).get("message_ts") or payload.get("message", {}).get("ts") or ts
    return channel, ts


def update_slack_review(batch_id: str | None = None, payload: dict | None = None) -> dict:
    """Refresh the posted Slack review message to reflect current status."""
    batch = _load_batch(batch_id)
    if not batch:
        return {"updated": False, "reason": "review batch not found"}
    channel, ts = _slack_message_ref(batch, payload)
    if not channel or not ts:
        return {"updated": False, "reason": "slack message reference not found"}

    batch["slack_message"] = {"channel": channel, "ts": ts}
    _save_batch(batch)
    result = _slack_api(
        "chat.update",
        {
            "channel": channel,
            "ts": ts,
            "text": f"AlphaVaults Review {batch['batch_id']}",
            "blocks": _slack_blocks(batch),
        },
    )
    return {"updated": bool(result.get("ok")), "response": result}


def send_slack_review(batch_id: str | None = None) -> dict:
    """Send review batch to Slack if Slack config is complete."""
    token = get_config("slack_bot_token")
    channel = get_config("slack_channel_id")
    if not token or not channel:
        return {"sent": False, "reason": "slack_bot_token or slack_channel_id is not configured"}
    batch = _load_batch(batch_id)
    if not batch:
        return {"sent": False, "reason": "review batch not found"}
    payload = {
        "channel": channel,
        "text": f"AlphaVaults Review {batch['batch_id']}",
        "blocks": _slack_blocks(batch),
    }
    result = _slack_api("chat.postMessage", payload)
    return {
        "sent": bool(result.get("ok")),
        "response": result,
        "message": {"channel": result.get("channel"), "ts": result.get("ts")},
    }


def send_slack_result(text: str) -> dict:
    """Send a plain status update to the configured Slack channel."""
    channel = get_config("slack_channel_id")
    token = get_config("slack_bot_token")
    if not token or not channel:
        return {"sent": False, "reason": "slack_bot_token or slack_channel_id is not configured"}
    payload = {"channel": channel, "text": text}
    result = _slack_api("chat.postMessage", payload)
    return {"sent": bool(result.get("ok")), "response": result}


def handle_slack_payload(payload: dict, apply_async: bool = False) -> dict:
    """Handle an already verified Slack interactive payload."""
    user_id = payload.get("user", {}).get("id")
    approvers = get_config("slack_approver_user_ids") or []
    if not approvers or user_id not in approvers:
        return {"ok": False, "error": "unauthorized_user", "user_id": user_id}

    actions = payload.get("actions", [])
    if not actions:
        return {"ok": False, "error": "missing_action"}
    action = actions[0]
    action_id = action.get("action_id", "")
    if str(action_id).startswith("alphavaults_select_") or action.get("type") == "checkboxes":
        return {"ok": True, "decision": "selection-changed"}

    value = action.get("value", "")
    parts = value.split("|")
    if len(parts) == 3 and parts[1] == "bulk" and parts[2] in {"approve", "hold", "reject"}:
        batch_id = parts[0]
        batch = _load_batch(batch_id)
        if not batch:
            return {"ok": False, "error": "review batch not found"}
        decision = parts[2]
        selected_ids = _selected_bulk_item_ids(payload, batch=batch)
        if not selected_ids:
            return {"ok": True, "decision": f"bulk-{decision}", "selected": 0, "message": "no_selection"}
        updated_items = set_items_decision(batch_id, selected_ids, decision, user_id=user_id)
        update_result = update_slack_review(batch_id, payload=payload)
        apply_result: dict | None = None
        if decision == "approve" and apply_async:
            def _apply_bulk_in_background() -> None:
                result = apply_approved(batch_id, notify_slack=True)
                if result["failed"]:
                    send_slack_result(
                        f"AlphaVaults bulk apply failed for {batch_id}: applied={result['applied']} failed={result['failed']} held={result['held']}"
                    )

            threading.Thread(target=_apply_bulk_in_background, daemon=True).start()
            apply_result = {"scheduled": True}
        elif decision == "approve":
            apply_result = apply_approved(batch_id)
        return {
            "ok": True,
            "decision": f"bulk-{decision}",
            "selected": len(updated_items),
            "items": [item["id"] for item in updated_items],
            "apply": apply_result,
            "slack_update": update_result,
        }
    if len(parts) != 3:
        return {"ok": False, "error": "invalid_action_value"}
    batch_id, item_id, decision = parts
    if decision == "preview":
        preview_result = open_preview_modal(batch_id, item_id, payload.get("trigger_id"))
        return {"ok": bool(preview_result.get("opened")), "decision": decision, "preview": preview_result}
    item = set_item_decision(batch_id, item_id, decision, user_id=user_id)
    update_result = update_slack_review(batch_id, payload=payload)
    apply_result: dict | None = None
    if decision == "approve":
        if apply_async:
            def _apply_in_background() -> None:
                result = apply_approved(batch_id, notify_slack=True)
                if result["failed"]:
                    send_slack_result(
                        f"AlphaVaults apply failed for {batch_id}: applied={result['applied']} failed={result['failed']} held={result['held']}"
                    )

            threading.Thread(target=_apply_in_background, daemon=True).start()
            apply_result = {"scheduled": True}
        else:
            apply_result = apply_approved(batch_id)
    return {"ok": True, "decision": decision, "item": item, "apply": apply_result, "slack_update": update_result}


class _ReviewHandler(BaseHTTPRequestHandler):
    def do_POST(self) -> None:  # noqa: N802 - stdlib hook name
        if self.path != "/slack/actions":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(length)
        headers = {k: v for k, v in self.headers.items()}
        if not verify_slack_signature(raw_body, headers):
            self.send_response(403)
            self.end_headers()
            self.wfile.write(b"invalid slack signature")
            return
        form = urllib.parse.parse_qs(raw_body.decode("utf-8"))
        payload_raw = form.get("payload", ["{}"])[0]
        try:
            payload = json.loads(payload_raw)
            result = handle_slack_payload(payload, apply_async=True)
            status = 200 if result.get("ok") else 403
        except Exception as exc:  # noqa: BLE001 - return controlled server error
            result = {"ok": False, "error": str(exc)}
            status = 500
            _server_log(f"ERROR {self.path}: {type(exc).__name__}: {exc}")
        body = json.dumps(result, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: Any) -> None:
        _server_log(fmt % args)


def serve_review(host: str = "127.0.0.1", port: int | None = None) -> None:
    """Run local Slack action receiver."""
    port = int(port or get_config("review_server_port", 8877))
    server = HTTPServer((host, port), _ReviewHandler)
    print(f"AlphaVaults review server listening on http://{host}:{port}/slack/actions")
    server.serve_forever()
