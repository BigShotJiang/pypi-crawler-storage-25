"""End-to-end test: kernel + Hypha service + artifacts + remote code execution."""

import os
import json
import pytest
from dotenv import load_dotenv

from safe_colab_cli.kernel import SandboxKernel
from safe_colab_cli.service import register_service

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"), override=True)

SERVER_URL = os.environ.get("HYPHA_SERVER_URL", "https://hypha.aicell.io")
WORKSPACE = os.environ.get("HYPHA_WORKSPACE", "safe-colab")
TOKEN = os.environ.get("HYPHA_TOKEN")


@pytest.fixture
async def kernel():
    k = SandboxKernel()
    await k.start()
    yield k
    await k.stop()


@pytest.mark.asyncio
@pytest.mark.skipif(not TOKEN, reason="HYPHA_TOKEN not set")
async def test_e2e_full_workflow(kernel, tmp_path):
    """Full end-to-end with two-service architecture (agent + dashboard)."""
    work_dir = str(tmp_path / "workspace")
    os.makedirs(work_dir, exist_ok=True)
    data_dir = str(tmp_path / "data")
    os.makedirs(data_dir, exist_ok=True)
    with open(os.path.join(data_dir, "test.csv"), "w") as f:
        f.write("name,value\nAlice,42\nBob,17\n")

    server, agent_svc, instructions, service_url, dashboard_url = await register_service(
        server_url=SERVER_URL, workspace=WORKSPACE, token=TOKEN,
        kernel=kernel, data_dir=data_dir, work_dir=work_dir,
    )

    assert agent_svc is not None
    assert "/services/" in service_url  # Agent uses /services/
    assert "/apps/" in dashboard_url    # Dashboard uses /apps/
    assert "get_skill_md" in instructions
    print(f"\nAgent:     {service_url}")
    print(f"Dashboard: {dashboard_url}")

    # Connect as remote agent
    from hypha_rpc import connect_to_server as connect
    remote = await connect({"server_url": SERVER_URL, "workspace": WORKSPACE, "token": TOKEN})
    svc = await remote.get_service(agent_svc["id"])

    # Agent service tests (generic type — returns plain dicts)
    result = await svc.run_code("print('Hello!')")
    assert result["stdout"].strip() == "Hello!"
    print("T1 run_code: pass")

    result = await svc.run_code("2 ** 10")
    assert result["result"] == "1024"
    print("T2 expression: pass")

    result = await svc.run_code("raise ValueError('test')")
    assert result["error"]["ename"] == "ValueError"
    print("T3 error: pass")

    await svc.run_code("x = 42")
    result = await svc.run_code("print(x)")
    assert result["stdout"].strip() == "42"
    print("T4 persistence: pass")

    result = await svc.execute_command(f"ls {data_dir}")
    assert "test.csv" in result["stdout"]
    print("T5 execute_command: pass")

    code = f'open("{work_dir}/out.txt","w").write("ok"); print("saved")'
    result = await svc.run_code(code)
    assert "saved" in result["stdout"]
    print("T6 file write: pass")

    result = await svc.upload_file(f"{work_dir}/out.txt")
    assert "url" in result
    print("T7 upload_file: pass")

    files = await svc.list_shared_files()
    print(f"T8 list_shared_files: {len(files)} files")

    skill = await svc.get_skill_md()
    assert "run_code" in skill
    assert service_url in skill
    print("T9 get_skill_md: pass")

    result = await svc.upload_file("/etc/passwd")
    assert "error" in result
    print("T10 upload security: pass")

    print("\nAll e2e tests passed!")
