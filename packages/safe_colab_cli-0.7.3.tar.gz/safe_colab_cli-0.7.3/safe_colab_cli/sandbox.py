"""Sandbox backends for isolating the Jupyter kernel process.

Two backends:
1. nono: Uses `nono run` CLI to wrap the kernel subprocess (macOS/Linux)
2. docker: Runs kernel in a Docker container with volume mounts

The parent process (safe-colab CLI) is never sandboxed — only the kernel is.
"""

import os
import sys
import shutil
import subprocess
import logging

logger = logging.getLogger("safe_colab_cli.sandbox")

# Docker image for fallback
DEFAULT_DOCKER_IMAGE = os.environ.get(
    "SAFE_COLAB_DOCKER_IMAGE", "jupyter/base-notebook:python-3.11"
)


def detect_backend() -> str:
    """Auto-detect the best available sandbox backend.

    Returns: 'nono', 'docker', or 'none'
    """
    if _nono_available():
        return "nono"
    if _docker_available():
        return "docker"
    return "none"


def _find_nono() -> str | None:
    """Find the nono binary, checking PATH and known locations."""
    # Check PATH first
    path = shutil.which("nono")
    if path:
        return path
    # Check known install locations (svamp auto-installs here)
    candidates = [
        os.path.expanduser("~/.svamp/tools/bin/nono"),
        "/usr/local/bin/nono",
        os.path.expanduser("~/.local/bin/nono"),
    ]
    for candidate in candidates:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _nono_available() -> bool:
    """Check if nono CLI is available and platform is supported."""
    nono = _find_nono()
    if not nono:
        return False
    try:
        result = subprocess.run(
            [nono, "--version"], capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def _nono_supports_flag(flag: str) -> bool:
    """Check if the installed nono version supports a specific flag."""
    nono = _find_nono()
    if not nono:
        return False
    try:
        result = subprocess.run(
            [nono, "run", "--help"], capture_output=True, text=True, timeout=5
        )
        return flag in result.stdout
    except Exception:
        return False


def _docker_available() -> bool:
    """Check if Docker is available."""
    if not shutil.which("docker"):
        return False
    try:
        result = subprocess.run(
            ["docker", "info"], capture_output=True, text=True, timeout=10
        )
        return result.returncode == 0
    except Exception:
        return False


def build_nono_kernel_argv(
    original_argv: list[str],
    data_dir: str | None,
    work_dir: str,
) -> list[str]:
    """Wrap kernel argv with nono sandbox.

    Returns new argv that runs the kernel inside nono.

    Example: ['python', '-m', 'ipykernel_launcher', '-f', '{connection_file}']
    becomes: ['nono', 'run', '--allow', '/work', '--read', '/data', ...
              '--', 'python', '-m', 'ipykernel_launcher', '-f', '{connection_file}']
    """
    nono_bin = _find_nono() or "nono"
    # Set workdir to resolved work_dir path (macOS /var → /private/var symlinks)
    resolved_work = os.path.realpath(os.path.abspath(work_dir))
    nono_cmd = [nono_bin, "run", "-s"]

    # Add optional flags only if the nono version supports them
    if _nono_supports_flag("--trust-override"):
        nono_cmd.append("--trust-override")
    if _nono_supports_flag("--workdir"):
        nono_cmd.extend(["--workdir", resolved_work])
    if _nono_supports_flag("--allow-cwd"):
        nono_cmd.append("--allow-cwd")

    # Work dir: read-write (already allowed via --allow-cwd + --workdir)
    # But add it explicitly too in case CWD isn't fully propagated
    nono_cmd.extend(["--allow", resolved_work])

    # Data dir: read-only
    if data_dir:
        nono_cmd.extend(["--read", os.path.realpath(os.path.abspath(data_dir))])

    # Python venv/prefix needs --allow (execute permission for python binary)
    allowed_exec = set()
    for p in [sys.prefix, sys.exec_prefix]:
        if p and os.path.isdir(p):
            allowed_exec.add(os.path.realpath(p))
    if hasattr(sys, "base_prefix") and sys.base_prefix and os.path.isdir(sys.base_prefix):
        allowed_exec.add(os.path.realpath(sys.base_prefix))

    for p in sorted(allowed_exec):
        nono_cmd.extend(["--allow", p])

    # Other Python paths: read-only
    allowed_read = set()
    for p in sys.path:
        if p and os.path.isdir(p):
            rp = os.path.realpath(p)
            if not any(rp.startswith(ep) for ep in allowed_exec):
                allowed_read.add(rp)

    # Standard system paths — only libraries, NOT /etc (contains passwords)
    for p in ["/usr/lib", "/usr/local/lib", "/usr/share", "/Library"]:
        if os.path.isdir(p):
            allowed_read.add(p)

    for p in sorted(allowed_read):
        nono_cmd.extend(["--read", p])

    # /tmp (resolves to /private/tmp on macOS) for ZMQ sockets, connection files
    nono_cmd.extend(["--allow", os.path.realpath("/tmp")])

    # Jupyter runtime/config dirs (needed for connection files and kernel specs)
    try:
        from jupyter_core.paths import jupyter_runtime_dir, jupyter_data_dir
        runtime_dir = jupyter_runtime_dir()
        if os.path.isdir(runtime_dir):
            nono_cmd.extend(["--allow", runtime_dir])  # RW for connection files
        data_dir_jupyter = jupyter_data_dir()
        if os.path.isdir(data_dir_jupyter):
            nono_cmd.extend(["--read", data_dir_jupyter])
    except ImportError:
        pass

    home = os.path.expanduser("~")
    jupyter_dir = os.path.join(home, ".local", "share", "jupyter")
    if os.path.isdir(jupyter_dir):
        nono_cmd.extend(["--read", jupyter_dir])
    ipython_dir = os.path.join(home, ".ipython")
    if os.path.isdir(ipython_dir):
        nono_cmd.extend(["--read", ipython_dir])
    # macOS specific jupyter paths
    lib_jupyter = os.path.join(home, "Library", "Jupyter")
    if os.path.isdir(lib_jupyter):
        nono_cmd.extend(["--allow", lib_jupyter])

    # Separator + original command
    nono_cmd.append("--")
    nono_cmd.extend(original_argv)

    return nono_cmd


def build_docker_run_args(
    data_dir: str | None,
    work_dir: str,
    connection_file: str,
    image: str = None,
) -> list[str]:
    """Build docker run arguments for a sandboxed kernel.

    The kernel runs inside Docker; we mount:
    - data_dir as /data (read-only)
    - work_dir as /workspace (read-write)
    - connection_file's directory for ZMQ communication

    Returns: full docker run command as a list.
    """
    image = image or DEFAULT_DOCKER_IMAGE

    cmd = [
        "docker", "run", "--rm",
        "--network", "host",  # Share host network for ZMQ kernel communication
        "--user", f"{os.getuid()}:{os.getgid()}",  # Run as current user
        "--name", f"safe-colab-kernel-{os.getpid()}",
    ]

    # Mount working directory
    abs_work = os.path.abspath(work_dir)
    cmd.extend(["-v", f"{abs_work}:/workspace"])
    cmd.extend(["-w", "/workspace"])

    # Mount data directory (read-only)
    if data_dir:
        abs_data = os.path.abspath(data_dir)
        cmd.extend(["-v", f"{abs_data}:/data:ro"])

    # Mount connection file directory for ZMQ
    conn_dir = os.path.dirname(os.path.abspath(connection_file))
    cmd.extend(["-v", f"{conn_dir}:{conn_dir}"])

    # Resource limits
    cmd.extend(["--memory", "4g"])
    cmd.extend(["--cpus", "2"])

    cmd.append(image)

    # Run ipykernel
    cmd.extend([
        "python", "-m", "ipykernel_launcher", "-f", connection_file,
    ])

    return cmd


def verify_nono_sandbox(data_dir: str | None, work_dir: str) -> dict:
    """Verify nono sandbox actually works by running a test.

    Returns dict with 'ok' bool and 'details' string.
    """
    test_script = f"""
import os, sys
results = []

# Test 1: Can read work_dir
try:
    os.listdir("{work_dir}")
    results.append("work_dir_read: OK")
except Exception as e:
    results.append(f"work_dir_read: FAIL {{e}}")

# Test 2: Can write work_dir
try:
    test_file = os.path.join("{work_dir}", ".sandbox_test")
    with open(test_file, "w") as f:
        f.write("test")
    os.remove(test_file)
    results.append("work_dir_write: OK")
except Exception as e:
    results.append(f"work_dir_write: FAIL {{e}}")

# Test 3: Cannot read /etc/passwd
try:
    with open("/etc/passwd") as f:
        f.read(10)
    results.append("etc_passwd_blocked: FAIL (could read)")
except Exception:
    results.append("etc_passwd_blocked: OK")

# Test 4: Cannot write outside
try:
    with open("/var/tmp/safe_colab_test", "w") as f:
        f.write("x")
    os.remove("/var/tmp/safe_colab_test")
    results.append("write_outside_blocked: FAIL (could write)")
except Exception:
    results.append("write_outside_blocked: OK")

print("\\n".join(results))
"""

    nono_bin = _find_nono() or "nono"
    nono_cmd = [nono_bin, "run", "-s",
                "--allow", os.path.abspath(work_dir),
                "--allow", "/tmp"]

    if data_dir:
        nono_cmd.extend(["--read", os.path.abspath(data_dir)])

    # Allow python
    for p in [sys.prefix, sys.exec_prefix]:
        if p and os.path.isdir(p):
            nono_cmd.extend(["--read", os.path.realpath(p)])
    if hasattr(sys, "base_prefix") and sys.base_prefix:
        nono_cmd.extend(["--read", os.path.realpath(sys.base_prefix)])

    for p in sys.path:
        if p and os.path.isdir(p):
            nono_cmd.extend(["--read", os.path.realpath(p)])

    nono_cmd.extend(["--", sys.executable, "-c", test_script])

    try:
        result = subprocess.run(
            nono_cmd, capture_output=True, text=True, timeout=15
        )
        output = result.stdout.strip()
        lines = output.split("\n")
        all_ok = all("OK" in line for line in lines if line.strip())
        return {
            "ok": all_ok,
            "details": output,
            "stderr": result.stderr.strip() if result.stderr else "",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "details": "Verification timed out"}
    except Exception as e:
        return {"ok": False, "details": f"Verification failed: {e}"}
