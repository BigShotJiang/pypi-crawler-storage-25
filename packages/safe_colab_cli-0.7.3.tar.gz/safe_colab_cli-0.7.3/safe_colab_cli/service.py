"""Hypha service registration - exposes code execution, shell commands, and file sharing."""

import os
import secrets
import asyncio
import subprocess
import json
from hypha_rpc import connect_to_server

from .artifacts import SessionArtifactManager


def _build_service_url(server_url: str, service_id: str) -> str:
    """Build the HTTP service URL for functions-type services.

    Uses /apps/ path (not /services/) because service type is "functions".
    """
    base = server_url.rstrip("/")
    parts = service_id.split("/", 1)
    if len(parts) == 2:
        workspace, svc_part = parts
        if ":" in svc_part:
            svc_name = svc_part.split(":", 1)[1]
        else:
            svc_name = svc_part
        return f"{base}/{workspace}/apps/{svc_name}"
    return f"{base}/apps/{service_id}"


def _extract_caller(context: dict = None) -> str:
    """Extract caller identification from Hypha RPC context."""
    if not context:
        return "unknown"
    # Hypha context may contain user info, workspace, client_id
    user = context.get("user", {})
    if isinstance(user, dict):
        return user.get("email") or user.get("id") or str(user)
    return str(context.get("from", "unknown"))


def _load_data_readme(data_dir: str) -> str:
    """Load README.md from the data directory if it exists.

    This file is the sensitivity contract between the data owner and the system.
    It describes the dataset, its structure, and the sensitivity policy.
    """
    if not data_dir or data_dir == "(none)":
        return ""
    for name in ["README.md", "readme.md", "README.txt", "readme.txt"]:
        path = os.path.join(data_dir, name)
        if os.path.isfile(path):
            try:
                with open(path, "r") as f:
                    return f.read()
            except Exception:
                pass
    return ""


def _build_skill_md(service_url: str, data_dir: str, work_dir: str, data_readme: str = "") -> str:
    """Build the agent skill document in SKILL.md format (agentskills.io spec).

    Contains:
    1. YAML frontmatter (name, description)
    2. Dataset documentation from README.md (sensitivity contract)
    3. Endpoint reference (run_code, execute_command, etc.)
    4. Quick start examples
    """
    # Build the dataset/sensitivity section from README.md
    dataset_section = ""
    if data_readme:
        dataset_section = f"""
## Dataset Documentation

The data owner has provided the following documentation and sensitivity policy.
**You MUST follow the sensitivity policy strictly.** A guardian agent enforces it
and will block code that violates these rules.

{data_readme}

---
"""
    else:
        dataset_section = """
## Dataset Documentation

No README.md found in the data directory. Ask the data owner for documentation
about the dataset structure and sensitivity policy.

---
"""

    return f"""\
---
name: safe-colab-session
description: >
  Remote sandboxed Python environment for analyzing sensitive data.
  Execute code, install packages, and share results — all via HTTP.
  A guardian agent validates all code against the data owner's sensitivity policy.
---

# Safe Colab Session

You have access to a sandboxed Python environment on a remote machine.
The service URL acts as a secret — no additional token is needed.

**Service URL:** `{service_url}`
{dataset_section}
## Endpoints

### `run_code(code: str) -> dict`
Execute Python code in a persistent Jupyter kernel. Variables persist across calls.
```bash
curl -s -X POST "$SERVICE_URL/run_code" \\
  -H "Content-Type: application/json" \\
  -d '{{"code": "print(42)"}}'
```
Returns: `{{"stdout": "...", "stderr": "...", "result": "...", "error": null | {{"ename": "...", "evalue": "..."}}}}`

### `execute_command(command: str, timeout: int = 60) -> dict`
Run shell commands (pip install, ls, cat, etc.).
```bash
curl -s -X POST "$SERVICE_URL/execute_command" \\
  -H "Content-Type: application/json" \\
  -d '{{"command": "pip install scikit-learn"}}'
```
Returns: `{{"stdout": "...", "stderr": "...", "returncode": 0}}`

### `upload_file(file_path: str) -> dict`
Upload a file to the shared artifact store. Returns a presigned download URL.
```bash
curl -s -X POST "$SERVICE_URL/upload_file" \\
  -H "Content-Type: application/json" \\
  -d '{{"file_path": "{work_dir}/results.csv"}}'
```
Returns: `{{"url": "https://...", "remote_path": "results.csv"}}`

### `list_shared_files() -> list`
List all uploaded session files.

## Environment

- **Data directory** (read-only): `{data_dir}`
- **Working directory** (read-write): `{work_dir}`
- Full Python 3 with pip — install via `execute_command("pip install <pkg>")`
- Kernel state persists across `run_code` calls (like Jupyter cells)
- Share files via `upload_file()` → returns download URL
- All operations are audited

## Quick Start

```bash
SERVICE_URL="{service_url}"

# 1. List data files
curl -s -X POST "$SERVICE_URL/execute_command" -H "Content-Type: application/json" \\
  -d '{{"command": "ls -la {data_dir}"}}'

# 2. Install packages
curl -s -X POST "$SERVICE_URL/execute_command" -H "Content-Type: application/json" \\
  -d '{{"command": "pip install pandas"}}'

# 3. Run analysis
curl -s -X POST "$SERVICE_URL/run_code" -H "Content-Type: application/json" \\
  -d '{{"code": "import pandas as pd; df = pd.read_csv(\\\"{data_dir}/patient_health.csv\\\"); print(df.shape)"}}'

# 4. Upload results
curl -s -X POST "$SERVICE_URL/upload_file" -H "Content-Type: application/json" \\
  -d '{{"file_path": "{work_dir}/output.csv"}}'
```

## Rules

- Follow the sensitivity policy in the dataset documentation above
- Do NOT access files outside the data and working directories
- A guardian agent validates code before execution and output before return
- Large outputs are truncated to 50KB
- Execution timeout: 120 seconds per cell
"""


def _build_short_instructions(service_url: str, dashboard_url: str) -> str:
    """Build the short terminal instructions."""
    return f"""\
Share this with your AI agent (no credentials needed):

  curl -s {service_url}/get_skill_md
"""


async def register_service(
    server_url: str,
    workspace: str,
    token: str,
    kernel,
    data_dir: str,
    work_dir: str,
    session_id: str = None,
    guardian=None,
    event_logger=None,
):
    """Connect to Hypha and register the code execution service.

    Returns (server, service_info, agent_instructions, service_url).
    """
    if session_id is None:
        session_id = secrets.token_hex(16)

    # Load the data owner's README.md (sensitivity contract)
    data_readme = _load_data_readme(data_dir)
    if data_readme:
        print(f"[data] Loaded README.md from data directory ({len(data_readme)} chars)")
        # Guardian gets ONLY the dataset description/sensitivity policy
        if guardian:
            guardian.dataset_description = data_readme
    else:
        print(f"[data] No README.md found in data directory")
        print(f"[data] Tip: Add a README.md to {data_dir} with dataset description and sensitivity policy")

    server = await connect_to_server({
        "server_url": server_url,
        "workspace": workspace,
        "token": token,
    })
    actual_workspace = (
        server.config.get("workspace", workspace)
        if hasattr(server.config, "get")
        else getattr(server.config, "workspace", workspace)
    )
    print(f"[hypha] Connected to {server_url}, workspace: {actual_workspace}")

    # Initialize artifact manager
    artifact_mgr = None
    try:
        am_service = await server.get_service("public/artifact-manager")
        artifact_mgr = SessionArtifactManager(am_service, session_id, actual_workspace)
        await artifact_mgr.initialize()
        print(f"[hypha] Session artifact created for file sharing and audit logging")
    except Exception as e:
        print(f"[hypha] Warning: Artifact manager not available ({e}). File sharing disabled.")

    # ── Endpoint: run_code ──
    async def run_code(code: str, context: dict = None) -> dict:
        """Execute Python code in the sandboxed Jupyter kernel.
        Variables and imports persist across calls.
        Code is validated by a guardian agent if configured."""
        import time as _time
        caller = _extract_caller(context)
        if event_logger:
            event_logger.code_submitted(code)

        # Pre-execution security check
        if guardian:
            t0 = _time.time()
            check = await guardian.check_code(code)
            dur = _time.time() - t0
            if "error" in check:
                if event_logger:
                    event_logger.security_blocked("code", check["error"])
                return {"stdout": "", "stderr": "", "result": None,
                        "error": {"ename": "SecurityError", "evalue": check["error"], "traceback": []},
                        "display_data": [], "security": check}
            if not check.get("is_safe", True):
                if event_logger:
                    event_logger.code_security_check(False, check.get("reason", ""), dur)
                    event_logger.security_blocked("code", check.get("reason", "Unsafe code"))
                return {"stdout": "", "stderr": "", "result": None,
                        "error": {"ename": "SecurityError", "evalue": f"Code blocked: {check.get('reason', 'unsafe')}", "traceback": []},
                        "display_data": [], "security": check}
            if event_logger:
                event_logger.code_security_check(True, check.get("reason", ""), dur)

        # Execute
        t0 = _time.time()
        result = await kernel.execute(code)
        exec_dur = _time.time() - t0
        max_len = 50000
        for key in ("stdout", "stderr"):
            if result[key] and len(result[key]) > max_len:
                result[key] = result[key][:max_len] + "\n... (truncated)"

        if event_logger:
            event_logger.code_executed(len(result.get("stdout", "")), len(result.get("stderr", "")),
                                       result.get("error") is not None, exec_dur)

        # Post-execution output security check
        if guardian and result.get("error") is None:
            output_text = (result.get("stdout", "") + "\n" + str(result.get("result", ""))).strip()
            if output_text:
                t0 = _time.time()
                out_check = await guardian.check_output(code, output_text)
                dur = _time.time() - t0
                if "error" not in out_check and not out_check.get("is_safe", True):
                    if event_logger:
                        event_logger.output_security_check(False, out_check.get("reason", ""), dur)
                        event_logger.security_blocked("output", out_check.get("reason", "Unsafe output"))
                    return {"stdout": "[Output blocked by security agent]", "stderr": "", "result": None,
                            "error": {"ename": "SecurityError", "evalue": f"Output blocked: {out_check.get('reason', 'unsafe')}", "traceback": []},
                            "display_data": [], "security": out_check}
                if event_logger and "error" not in out_check:
                    event_logger.output_security_check(True, out_check.get("reason", ""), dur)

        if artifact_mgr:
            try:
                await artifact_mgr.log_code_execution(code, result)
            except Exception:
                pass
        return result

    # ── Endpoint: execute_command ──
    import sys
    _cmd_env = os.environ.copy()
    _venv_bin = os.path.dirname(sys.executable)
    _cmd_env["PATH"] = _venv_bin + os.pathsep + _cmd_env.get("PATH", "")
    _cmd_env["VIRTUAL_ENV"] = os.path.dirname(_venv_bin)

    MAX_CMD_TIMEOUT = 300  # Hard cap: 5 minutes

    async def execute_command(command: str, timeout: int = 60, context: dict = None) -> dict:
        """Execute a shell command in the working directory."""
        import time as _time
        timeout = min(timeout, MAX_CMD_TIMEOUT)
        if event_logger:
            event_logger.command_submitted(command)

        t0 = _time.time()
        try:
            proc = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.run(
                    command, shell=True, capture_output=True, text=True,
                    timeout=timeout, cwd=work_dir, env=_cmd_env,
                ),
            )
            result = {"stdout": proc.stdout, "stderr": proc.stderr, "returncode": proc.returncode}
            max_len = 50000
            for key in ("stdout", "stderr"):
                if len(result[key]) > max_len:
                    result[key] = result[key][:max_len] + "\n... (truncated)"
        except subprocess.TimeoutExpired:
            result = {"stdout": "", "stderr": f"Command timed out after {timeout}s", "returncode": -1}

        dur = _time.time() - t0
        if event_logger:
            event_logger.command_executed(result.get("returncode", -1), dur)
        if artifact_mgr:
            try:
                await artifact_mgr.log_command_execution(command, result)
            except Exception:
                pass
        return result

    # ── Endpoint: upload_file ──
    async def upload_file(file_path: str, remote_name: str = None, context: dict = None) -> dict:
        """Upload a file from the working directory to the shared artifact store.
        Uses realpath to prevent symlink escape attacks.
        If guardian is active, file content is audited before upload."""
        if artifact_mgr is None:
            return {"error": "Artifact manager not available. File sharing is disabled."}

        # Resolve symlinks to prevent path traversal attacks
        real_path = os.path.realpath(file_path)
        real_work = os.path.realpath(work_dir)
        allowed = real_path.startswith(real_work + os.sep) or real_path == real_work
        if data_dir and data_dir != "(none)":
            real_data = os.path.realpath(data_dir)
            allowed = allowed or real_path.startswith(real_data + os.sep) or real_path == real_data
        if not allowed:
            if event_logger:
                event_logger.security_blocked("upload", f"Path outside allowed dirs: {file_path}")
            return {"error": f"Access denied: file must be within work_dir or data_dir (symlinks resolved)"}
        if not os.path.exists(real_path):
            return {"error": f"File not found: {file_path}"}

        # Guardian audit: check file content for sensitive data before upload
        if guardian:
            import time as _time
            try:
                # Read a preview of the file for audit (first 10KB for text files)
                file_size = os.path.getsize(real_path)
                preview = ""
                try:
                    with open(real_path, "r") as f:
                        preview = f.read(10000)
                except (UnicodeDecodeError, ValueError):
                    preview = f"[Binary file, {file_size} bytes]"

                t0 = _time.time()
                check = await guardian.check_output(
                    f"# File upload: {os.path.basename(real_path)} ({file_size} bytes)",
                    preview,
                )
                dur = _time.time() - t0
                if "error" not in check and not check.get("is_safe", True):
                    if event_logger:
                        event_logger.security_blocked("upload", check.get("reason", "Unsafe file content"))
                    return {"error": f"Upload blocked: {check.get('reason', 'file content not safe')}"}
                if event_logger and "error" not in check:
                    event_logger.output_security_check(True, f"upload {os.path.basename(real_path)}: {check.get('reason', '')[:60]}", dur)
            except Exception as e:
                pass  # Guardian failure should not block uploads

        if remote_name is None:
            remote_name = os.path.basename(real_path)
        try:
            url = await artifact_mgr.upload_file(real_path, remote_name)
            if event_logger:
                event_logger.file_uploaded(file_path, url)
            return {"url": url, "remote_path": remote_name}
        except Exception as e:
            return {"error": f"Upload failed: {str(e)}"}

    # ── Endpoint: list_shared_files ──
    async def list_shared_files(context: dict = None) -> list:
        """List all files uploaded to the session artifact store."""
        if artifact_mgr is None:
            return []
        try:
            return await artifact_mgr.list_files()
        except Exception:
            return []

    # ── Two services: agent (generic RPC) + dashboard (functions HTTP) ──
    agent_id = f"safe-colab-{secrets.token_hex(16)}"
    dash_id = f"safe-colab-dash-{secrets.token_hex(8)}"
    base_url = server_url.rstrip("/")
    _skill_text = None
    _index_html = None

    async def get_skill_md(context: dict = None) -> str:
        """Get the full agent skill document (SKILL.md format)."""
        return _skill_text or "Service not fully initialized yet."

    # 1. Agent service (generic) — for run_code, execute_command, etc.
    agent_svc = await server.register_service({
        "id": agent_id,
        "name": "Safe Colab Sandbox",
        "type": "generic",
        "description": "Sandboxed Python environment for safe remote code execution",
        "config": {"visibility": "unlisted", "require_context": True, "run_in_executor": True},
        "run_code": run_code,
        "execute_command": execute_command,
        "upload_file": upload_file,
        "list_shared_files": list_shared_files,
        "get_skill_md": get_skill_md,
    })

    def _extract_svc_name(svc_info, fallback):
        sid = svc_info.get("id", fallback) if isinstance(svc_info, dict) else fallback
        parts = sid.split("/", 1)
        if len(parts) == 2:
            svc_part = parts[1]
            return parts[0], svc_part.split(":", 1)[1] if ":" in svc_part else svc_part
        return "", sid

    ws, agent_name = _extract_svc_name(agent_svc, agent_id)
    service_url = f"{base_url}/{ws}/services/{agent_name}"

    _skill_text = _build_skill_md(service_url=service_url, data_dir=data_dir, work_dir=work_dir, data_readme=data_readme)

    # 2. Dashboard service (functions) — for web UI
    async def get_logs(offset=0, limit=50, *args, **kwargs) -> dict:
        offset = int(str(offset)) if offset else 0
        limit = int(str(limit)) if limit else 50
        entries, total = [], 0
        if event_logger:
            try:
                log_file = event_logger.log_dir / "session.log.jsonl"
                if log_file.exists():
                    lines = log_file.read_text().strip().split("\n")
                    total = len(lines)
                    entries = [json.loads(l) for l in lines[offset:offset + limit] if l.strip()]
            except Exception:
                pass
        return {"status": 200, "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"entries": entries, "next_offset": offset + len(entries), "total": total})}

    async def index(*args, **kwargs) -> dict:
        return {"status": 200, "headers": {"Content-Type": "text/html; charset=utf-8"},
                "body": _index_html or "<h1>Loading...</h1>"}

    async def skill_md_http(*args, **kwargs) -> dict:
        return {"status": 200, "headers": {"Content-Type": "text/markdown; charset=utf-8"},
                "body": _skill_text or "Not initialized."}

    dash_svc = await server.register_service({
        "id": dash_id,
        "name": "Safe Colab Dashboard",
        "type": "functions",
        "description": "Dashboard for safe-colab session",
        "config": {"visibility": "unlisted", "require_context": True, "run_in_executor": True},
        "index": index,
        "get_logs": get_logs,
        "get_skill_md": skill_md_http,
    })

    _, dash_name = _extract_svc_name(dash_svc, dash_id)
    dashboard_url = f"{base_url}/{ws}/apps/{dash_name}/"

    # Build dashboard HTML
    from .auth import extract_email_from_token as _extract_email
    from datetime import datetime, timezone
    user_email = _extract_email(token) or "unknown"
    started_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    template_path = os.path.join(os.path.dirname(__file__), "dashboard.html")
    with open(template_path) as f:
        tpl = f.read()
    sensitivity_html = data_readme.replace("\n", "<br>") if data_readme else "<em>No README.md found.</em>"
    # Dashboard uses its own /apps/ URL for get_logs polling
    dash_api_url = f"{base_url}/{ws}/apps/{dash_name}"
    _index_html = (
        tpl
        .replace("{{SESSION_ID_SHORT}}", session_id[:8])
        .replace("{{USER_EMAIL}}", user_email)
        .replace("{{STARTED_AT}}", started_at)
        .replace("{{SERVICE_URL}}", dash_api_url)
        .replace("{{DATA_DIR}}", data_dir)
        .replace("{{WORK_DIR}}", work_dir)
        .replace("{{SANDBOX}}", "enabled" if guardian else "none")
        .replace("{{GUARDIAN}}", guardian.endpoint_url if guardian else "(disabled)")
        .replace("{{LOG_DIR}}", str(event_logger.log_dir) if event_logger else "(none)")
        .replace("{{SENSITIVITY_POLICY}}", sensitivity_html)
    )

    instructions = _build_short_instructions(service_url, dashboard_url)

    print(f"[hypha] Agent service:  {service_url}")
    print(f"[hypha] Dashboard:      {dashboard_url}")
    return server, agent_svc, instructions, service_url, dashboard_url
