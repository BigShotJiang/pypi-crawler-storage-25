# archiet-microcodegen

> **Archiet's core algorithm in one file.** PRD text → manifest → genome → rendered Flask app → ZIP, in <700 LOC, with zero imports from `app.*`, `agents.*`, or templates. Pure stdlib. No LLM calls.

Inspired by Karpathy's `microgpt.py` philosophy: *this file is the complete algorithm; everything else in Archiet is just efficiency on top.*

## Install

```bash
pip install archiet-microcodegen
```

## Use

```bash
archiet-microcodegen path/to/prd.md --out ./out/
```

Or pipe to a ZIP:

```bash
archiet-microcodegen path/to/prd.md > app.zip
```

As a library:

```python
from archiet_microcodegen import microcodegen

prd_text = open("prd.md").read()
zip_bytes = microcodegen(prd_text)
```

## What you get

The generated output is a working Flask + Postgres CRUD app with:

- JWT-cookie auth (register / login / logout / me) — never localStorage
- Full CRUD per extracted entity (list / create / get / update / delete)
- Per-tenant row scoping (no `Query.all()` data leaks across users)
- JSON error handlers, CORS scoped to `FRONTEND_URL`, per-ZIP random secrets
- A single-page HTML demo at `/` that lets you exercise every entity from a browser
- A `docker-compose.yml` with healthcheck-gated Postgres startup
- A `Dockerfile` ready for Cloud Run / Fly / Railway

The whole algorithm runs in four stages:

1. **`parse_prd(text) → manifest`** — regex extraction of entities, fields, user stories, integrations
2. **`manifest_to_genome(manifest) → genome`** — maps to the canonical IR Archiet uses internally
3. **`render_genome(genome) → {path: content}`** — `string.Template`-based Flask rendering
4. **`pack(files) → bytes`** — stdlib `zipfile`

## Why this exists

This isn't the production Archiet pipeline — it's the **spec**. The full platform (https://archiet.com) adds:

- LLM-powered PRD extraction (chunked, overlap+dedup)
- 12+ stack renderers (Flask, FastAPI, Django, NestJS, Laravel, Go, Java, Rails, .NET, Tauri+Rust, Salesforce, SAP CAP, Dynamics)
- Capability emission, frontend (Next.js / Expo), stub-filling, quality scoring, delivery gates
- Cross-stack parity enforcement and verification

But none of that changes the **core algorithm**. If a bug doesn't reproduce in `microcodegen`, it's in an efficiency layer, not the spec. If a new top-level genome key isn't in `microcodegen`, the genome doesn't have that key yet.

## What's NOT included

- No LLM calls (the deterministic zone — see CLAUDE.md `LLM-BOUNDARY`)
- No frontend, no mobile, no payment integration, no rate limiting, no audit logging
- No Alembic migrations (uses `db.create_all` on first boot)
- No multi-stack output (Flask only; that's the algorithmic baseline)

For the full platform, see https://archiet.com.

## License

MIT. See [LICENSE](https://github.com/aniekanasuquookono-web/archiet/blob/main/LICENSE).

## Links

- Source: https://github.com/aniekanasuquookono-web/archiet/blob/main/scripts/microcodegen.py
- Issues: https://github.com/aniekanasuquookono-web/archiet/issues
- Full platform: https://archiet.com
