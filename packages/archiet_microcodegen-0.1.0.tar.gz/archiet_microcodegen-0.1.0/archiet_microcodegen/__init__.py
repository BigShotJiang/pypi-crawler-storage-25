"""archiet-microcodegen — Archiet's core algorithm in one file.

PRD text -> manifest -> genome -> rendered Flask app -> ZIP bytes.

This package is a thin, pip-installable wrapper around `scripts/microcodegen.py`
from the Archiet repository. The source file is the spec; the package metadata
exists so developers can `pip install archiet-microcodegen` and hack on it.

Public API mirrors the source file:

    from archiet_microcodegen import microcodegen, parse_prd, manifest_to_genome
    from archiet_microcodegen import render_genome, pack, main

CLI:

    archiet-microcodegen path/to/prd.md > app.zip
    archiet-microcodegen path/to/prd.md --out ./out/

Constraints (see CLAUDE.md MICROCODEGEN RULE):
  - Pure stdlib; zero app.* / agents.* / templates/ imports
  - Hard ceiling: <700 LOC for the core algorithm
  - No LLM calls; deterministic regex extraction only
"""

from __future__ import annotations

from archiet_microcodegen._core import (
    main,
    manifest_to_genome,
    microcodegen,
    pack,
    parse_prd,
    render_genome,
)

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "main",
    "manifest_to_genome",
    "microcodegen",
    "pack",
    "parse_prd",
    "render_genome",
]
