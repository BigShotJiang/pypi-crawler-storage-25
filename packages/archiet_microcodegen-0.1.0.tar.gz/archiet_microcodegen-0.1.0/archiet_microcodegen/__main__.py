"""Allow `python -m archiet_microcodegen` invocation."""

from __future__ import annotations

import sys

from archiet_microcodegen import main


if __name__ == "__main__":
    sys.exit(main())
