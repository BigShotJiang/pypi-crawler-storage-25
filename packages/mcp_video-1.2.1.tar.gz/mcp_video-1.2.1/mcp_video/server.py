"""mcp-video MCP server — exposes video editing tools for AI agents."""

from __future__ import annotations

from .server_app import _error_result as _error_result
from .server_app import _result as _result
from .server_app import mcp as mcp
from .server_resources import (
    templates_resource as templates_resource,
    video_audio_resource as video_audio_resource,
    video_info_resource as video_info_resource,
    video_preview_resource as video_preview_resource,
)
from .server_tools_basic import (
    VALID_XFADE_TRANSITIONS as VALID_XFADE_TRANSITIONS,
    video_add_audio as video_add_audio,
    video_add_text as video_add_text,
    video_convert as video_convert,
    video_info as video_info,
    video_merge as video_merge,
    video_resize as video_resize,
    video_speed as video_speed,
    video_trim as video_trim,
)
from .server_tools_media import (
    video_crop as video_crop,
    video_edit as video_edit,
    video_export as video_export,
    video_extract_audio as video_extract_audio,
    video_fade as video_fade,
    video_preview as video_preview,
    video_rotate as video_rotate,
    video_storyboard as video_storyboard,
    video_subtitles as video_subtitles,
    video_thumbnail as video_thumbnail,
    video_watermark as video_watermark,
)
from .server_tools_advanced import (
    video_apply_mask as video_apply_mask,
    video_audio_waveform as video_audio_waveform,
    video_batch as video_batch,
    video_blur as video_blur,
    video_chroma_key as video_chroma_key,
    video_color_grade as video_color_grade,
    video_compare_quality as video_compare_quality,
    video_create_from_images as video_create_from_images,
    video_detect_scenes as video_detect_scenes,
    video_export_frames as video_export_frames,
    video_extract_frame as video_extract_frame,
    video_filter as video_filter,
    video_generate_subtitles as video_generate_subtitles,
    video_normalize_audio as video_normalize_audio,
    video_overlay as video_overlay,
    video_read_metadata as video_read_metadata,
    video_reverse as video_reverse,
    video_split_screen as video_split_screen,
    video_stabilize as video_stabilize,
    video_write_metadata as video_write_metadata,
)
from .server_tools_image import (
    image_analyze_product as image_analyze_product,
    image_extract_colors as image_extract_colors,
    image_generate_palette as image_generate_palette,
)
from .server_tools_remotion import (
    remotion_compositions as remotion_compositions,
    remotion_create_project as remotion_create_project,
    remotion_render as remotion_render,
    remotion_scaffold_template as remotion_scaffold_template,
    remotion_still as remotion_still,
    remotion_studio as remotion_studio,
    remotion_to_mcpvideo as remotion_to_mcpvideo,
    remotion_validate as remotion_validate,
)
from .server_tools_audio import (
    audio_compose as audio_compose,
    audio_effects as audio_effects,
    audio_preset as audio_preset,
    audio_sequence as audio_sequence,
    audio_synthesize as audio_synthesize,
    video_add_generated_audio as video_add_generated_audio,
    video_audio_spatial as video_audio_spatial,
)
from .server_tools_effects import (
    effect_chromatic_aberration as effect_chromatic_aberration,
    effect_glow as effect_glow,
    effect_noise as effect_noise,
    effect_scanlines as effect_scanlines,
    effect_vignette as effect_vignette,
    transition_glitch as transition_glitch,
    transition_morph as transition_morph,
    transition_pixelate as transition_pixelate,
    video_auto_chapters as video_auto_chapters,
    video_info_detailed as video_info_detailed,
    video_layout_grid as video_layout_grid,
    video_layout_pip as video_layout_pip,
    video_mograph_count as video_mograph_count,
    video_mograph_progress as video_mograph_progress,
    video_text_animated as video_text_animated,
    video_text_subtitles as video_text_subtitles,
)
from .server_tools_ai import (
    video_ai_color_grade as video_ai_color_grade,
    video_ai_remove_silence as video_ai_remove_silence,
    video_ai_scene_detect as video_ai_scene_detect,
    video_ai_stem_separation as video_ai_stem_separation,
    video_ai_transcribe as video_ai_transcribe,
    video_ai_upscale as video_ai_upscale,
    video_analyze as video_analyze,
    video_design_quality_check as video_design_quality_check,
    video_fix_design_issues as video_fix_design_issues,
    video_quality_check as video_quality_check,
)
