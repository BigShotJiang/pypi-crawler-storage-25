import sys
import os
import datetime
import re
import math

import yaml
import numpy as np
import matplotlib.pyplot as plt
from urllib.request import urlopen

from json import load as json_load
from json import dump as json_dump
from polygenic.version import __version__ as version
from polygenic.tools.utils import expand_path

from polygenic.data.data_accessor import DataAccessor
from polygenic.data.vcf_accessor import VcfAccessor
from polygenic.model.model import Model, SeqqlOperator
from polygenic.error.polygenic_exception import PolygenicException

def run(args):

    ### get models
    models = {}
    for model in args.model:
        model_path = expand_path(model)
        model_name = os.path.basename(model_path)
        model_info = {"path": model_path, "name": model_name}
        models[model_info["path"]] = model_info
    
    if not model_info:
        raise PolygenicException("No models were defined. Exiting.")

    ### get sample data
    vcf_accessor = VcfAccessor(expand_path(args.vcf))
    sample_names = vcf_accessor.get_sample_names()
    if "sample_name" in args and not args.sample_name is None:
        sample_names = [args.sample_name]

    ### get reference data 
    af_accessor = VcfAccessor(expand_path(args.af)) if args.af else None

    ### get parameters
    parameters = {}
    if "parameters" in args and not args.parameters is None:
        with open(args.parameters) as parameters_json:
            parameters = json_load(parameters_json)

    if hasattr(args, 'no_ref_fallback') and args.no_ref_fallback:
        parameters['ref_fallback'] = False
    if hasattr(args, 'top_n') and args.top_n is not None:
        parameters['top_n'] = args.top_n

    for sample_name in sample_names:

        if args.merge_outputs:
            if args.merge_as_array:
                results_representations = []
            else:
                results_representations = {}
        for model_path, model_desc in models.items():
            if ".yml" in model_path:
                # Per-model override: YAML can declare `no_ref_fallback: true` at the top
                # to force ./.-stays-missing for this model regardless of the global flag.
                # Used by cyp2c19-pharmvar-5.1.8.yml to avoid the CYP2C19*38 collapse.
                model_params = dict(parameters)
                with open(expand_path(model_path)) as yml:
                    raw_yaml = yaml.safe_load(yml)
                if isinstance(raw_yaml, dict) and raw_yaml.get('no_ref_fallback'):
                    model_params['ref_fallback'] = False
                data_accessor = DataAccessor(
                    genotypes = vcf_accessor,
                    allele_frequencies =  af_accessor,
                    sample_name = sample_name,
                    model_name = model_desc["name"],
                    af_field_name = args.af_field,
                    parameters = model_params)
                model = SeqqlOperator.fromYaml(model_path)
                model.compute(data_accessor)
                if "description" not in model.result:
                    model.result["description"] = {}
                model.result["description"]["sample_name"] = sample_name
                model.result["description"]["model_name"] = model_desc["name"].replace('.yml', '')
                if "score_model" in model.result:
                    if "description" in model.result:
                        if "parameters" in model.result["description"]:
                            if "percentiles" in model.result["description"]["parameters"]:
                                model.result["score_model"]["adjusted_score"] = float(model.result["score_model"]["score"]) - float(model.result["description"]["parameters"]["percentiles"]["50"])
            # output file name 
            appendix = "-" + args.output_name_appendix if args.output_name_appendix else ""
            output_path = os.path.join(expand_path(args.output_directory), f'{sample_name}-{model_desc["name"]}{appendix}-result.json').replace('.yml', '')
            if args.merge_outputs:
                if args.merge_as_array:
                    results_representations.append({
                        "file_name": model_desc["name"],
                        "result": model.refine_results()
                    })
                else:
                    results_representations[model_desc["name"]] = model.refine_results()
            else:
                with open(output_path, 'w') as f:
                    results = model.refine_results()
                    json_dump(results, f, indent=2)
                with open(output_path.replace('.json', '.yml'), 'w') as f:
                    yaml.dump(results, f, indent=2)
                if args.print:
                    json_dump(model.refine_results(), sys.stdout, indent=2)

            results = model.refine_results()
            description = results["description"]
            if "parameters" in description:
                parameters = description["parameters"]
                if "percentiles" in parameters:
                    percentiles = parameters["percentiles"]
                    percentile_values = sorted([float(v) for v in percentiles.values()])
                    if results["description"]["args"]["type"] == "Beta":
                        if results["description"]["args"]["mean"]:
                            mean = float(results["description"]["args"]["mean"])
                            percentile_values = [float(v) + mean for v in percentiles.values()]
                            median = float(percentiles['50'])
                    else:
                        percentile_values = [float(v) for v in percentiles.values()]
                        median = float(percentiles['50'])
                        percentile_values = [value - median for value in percentile_values]
                        #percentile_values = [math.exp(float(v)) for v in percentiles.values()]
                        #p = 0.5 if results["description"]["args"]["prevalence"] is None else float(results["description"]["args"]["prevalence"])
                        #percentile_values = [p * value / (1 - p + (p * value)) for value in percentile_values]


                    # Create bin edges (you can adjust the number of bins as needed)
                    num_bins = 20
                    bin_edges = np.linspace(min(percentile_values), max(percentile_values), num_bins + 1)

                    # Calculate frequencies
                    hist, _ = np.histogram(percentile_values, bins=bin_edges)

                    # Plot the histogram
                    fig, ax = plt.subplots(figsize=(6, 4))
                    n, bins, patches = ax.hist(percentile_values, bins=bin_edges, edgecolor='white', color='#4D4D4D', linewidth=1)

                    # Specify the point to highlight (for example, the median)
                    if results["description"]["args"]["type"] == "Beta":
                        point_to_highlight = float(results["description"]["args"]["mean"]) + float(model.result["score_model"]["adjusted_score"])
                    else:
                        point_to_highlight = float(model.result["score_model"]["adjusted_score"]) # Median

                    # Find the bin where the point falls
                    bin_index = np.digitize(point_to_highlight, bins) - 1
                    if bin_index < 0:
                        bin_index = 0
                    elif bin_index >= num_bins:
                        bin_index = num_bins - 1

                    # Calculate arrow position
                    arrow_x = point_to_highlight
                    arrow_y = n[bin_index] + max(n) * 0.1  # Slightly above the bar

                    # Add arrow and annotation
                    ax.annotate(f'Patient', 
                                xy=(arrow_x, n[bin_index]), 
                                xytext=(arrow_x, arrow_y),
                                arrowprops=dict(color='#f77f00', shrink=0.05),
                                horizontalalignment='center')
                    # if beta:
                    if results["description"]["args"]["type"] == "Beta":
                        plt.xlabel("Predicted " + results["description"]["args"]["units"] + " distribution in population" if "units" in results["description"]["args"] else "")
                    else:
                        xticks = plt.gca().get_xticks()
                        new_labels = [math.exp(float(v)) for v in xticks]
                        p = 0.5 if results["description"]["args"]["prevalence"] is None else float(results["description"]["args"]["prevalence"])
                        new_labels = [value / (1 - p + (p * value)) for value in new_labels]
                        new_labels = [f'{(tick):.1f}' for tick in new_labels]
                        plt.gca().set_xticklabels(new_labels)
                        plt.xlabel("Predicted risk distribution in population")
                    plt.ylabel('Frequency [%]')
                    plt.grid(True, alpha=0.3)

                    plt.savefig(output_path.replace('.json', '-hist.png').replace('.yml', '-hist.png'))

    #         with open("polygenic/templates/pgscompute-model.md") as markdown_file:
    #             # read the file as a single string
    #             template = markdown_file.read()
    #             # fill with jinja2
    #             #print(results["description"]["info"])
    #             markdown = markdown + "\n" + jinja2.Template(template).render(results = results, distplot = output_path.replace('.json', '-hist.png').replace('.yml', '-hist.png'))

    #     # write markdown string to file named after sample id
    #     with open(args.output_directory + "/" + sample_name + ".md", 'w') as f:
    #         f.write(markdown)

    #     pattern = r'(#{1,6}\s.+?)\n(\|.+?\|)'
    #     markdown = re.sub(pattern, r'\1\n\n\2', markdown)
    #     html = md.markdown(markdown, extensions=['extra', 'tables'])

    #     # Fetch the Google Font CSS
    #     font_url = "https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap"
    #     font_css = urlopen(font_url).read().decode('utf-8')

    #     # Define CSS with the Google Font
    #     css_content = f"""
    # {font_css}
    # body {{
    #     font-family: 'Roboto', sans-serif;
    #     font-size: 12px;
    #     line-height: 1.6;
    # }}
    # h1, h2, h3, h4, h5, h6 {{
    #     font-family: 'Roboto', sans-serif;
    #     font-weight: 700;
    # }}
    # table {{
    #     border-collapse: collapse;
    #     width: 100%;
    #     margin-bottom: 1em;
    #     font-size: 0.9em;
    # }}
    # th, td {{
    #     border: 1px solid #ddd;
    #     padding: 8px;
    #     text-align: left;
    # }}
    # th {{
    #     background-color: #f2f2f2;
    #     font-weight: bold;
    # }}
    # """

    #     # Wrap the HTML content with basic structure and CSS
    #     full_html = f"""
    # <!DOCTYPE html>
    # <html>
    # <head>
    #     <meta charset="utf-8">
    #     <style>
    #     {css_content}
    #     </style>
    # </head>
    # <body>
    # {html}
    # </body>
    # </html>
    # """

    #     # Convert HTML to PDF
    #     HTML(string=full_html, base_url=args.output_directory).write_pdf(args.output_directory + "/" + sample_name + ".pdf")
        if args.merge_outputs:
            output_path = os.path.join(expand_path(args.output_directory), f'{sample_name}{appendix}-result.json')
            with open(output_path, 'w') as f:
                json_dump(results_representations, f, indent=2)
            with open(output_path.replace('.json', '.yml'), 'w') as f:
                yaml.dump(results_representations, f, indent=2)
            if args.print:
                json_dump(results_representations, sys.stdout, indent=2)