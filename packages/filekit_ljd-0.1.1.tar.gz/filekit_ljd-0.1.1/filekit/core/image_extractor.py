"""Image extraction from Excel files."""

from __future__ import annotations
from pathlib import Path
from typing import Dict
from dataclasses import dataclass, field
import hashlib
import zipfile
import openpyxl
from openpyxl.worksheet.drawing import Drawing


@dataclass
class ImageExtractionStats:
    """Estadísticas de extracción de imágenes."""
    total_sheets: int = 0
    total_images: int = 0
    duplicates_skipped: int = 0
    sheets_converted: int = 0
    sheets_processed: Dict[str, int] = field(default_factory=dict)


class ImageExtractor:
    """Extrae imágenes de archivos Excel."""

    def __init__(self, excel_path: str | Path, output_dir: str | Path):
        self.excel_path = Path(excel_path)
        self.output_dir = Path(output_dir)
        self.stats = ImageExtractionStats()
        self._extracted_hashes: set = set()

    def extract_all(self) -> ImageExtractionStats:
        """Extrae todas las imágenes del Excel."""
        if not self.excel_path.exists():
            raise FileNotFoundError("Archivo no encontrado: {}".format(self.excel_path))

        self.output_dir.mkdir(parents=True, exist_ok=True)

        wb = openpyxl.load_workbook(self.excel_path, data_only=False)
        self.stats.total_sheets = len(wb.sheetnames)

        self._print_header()

        # Extraer imágenes del ZIP interno
        self._extract_images_from_zip()

        # Procesar hojas
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            image_count = len(list(self._get_sheet_images(ws)))
            self.stats.sheets_processed[sheet_name] = image_count

            try:
                if image_count > 0:
                    print("  {}: Extrayendo {} imagen(es)... [OK]".format(
                        sheet_name, image_count))
                else:
                    print("  {}: Extrayendo Sin imagenes".format(sheet_name))
            except UnicodeEncodeError:
                if image_count > 0:
                    print("  [Sheet]: Extrayendo {} imagen(es)... [OK]".format(image_count))
                else:
                    print("  [Sheet]: Extrayendo Sin imagenes")

        self._print_sheet_conversion_header()
        self.stats.sheets_converted = self._count_convertible_sheets(wb)
        self._print_sheet_conversion_summary(wb)

        wb.close()
        return self.stats

    def _extract_images_from_zip(self) -> None:
        """Extrae imágenes del archivo ZIP interno del Excel."""
        try:
            with zipfile.ZipFile(self.excel_path, 'r') as xlsx:
                for file_info in xlsx.filelist:
                    if 'xl/media/' in file_info.filename:
                        try:
                            image_data = xlsx.read(file_info.filename)
                            if not self._is_duplicate(image_data):
                                filename = Path(file_info.filename).name
                                filepath = self.output_dir / filename
                                filepath.write_bytes(image_data)
                                self.stats.total_images += 1
                            else:
                                self.stats.duplicates_skipped += 1
                        except Exception as e:
                            print("Error extracting image {}: {}".format(file_info.filename, e))
        except Exception as e:
            print("Error opening Excel file as ZIP: {}".format(e))

    def _get_sheet_images(self, ws):
        """Genera referencias a imágenes en la hoja."""
        images = []
        if hasattr(ws, '_images') and ws._images:
            for img in ws._images:
                if img:
                    images.append(img)
        return images

    def _is_duplicate(self, blob: bytes) -> bool:
        """Verifica si es duplicada."""
        img_hash = hashlib.md5(blob).hexdigest()
        if img_hash in self._extracted_hashes:
            return True
        self._extracted_hashes.add(img_hash)
        return False

    def _print_header(self):
        """Imprime encabezado."""
        print("")
        print("EXTRAYENDO IMAGENES")
        print("-" * 60)
        print("Procesando {} hoja(s)...\n".format(self.stats.total_sheets))

    def _print_sheet_conversion_header(self):
        """Imprime encabezado de conversión."""
        print("")
        print("CONVIRTIENDO HOJAS A PNG")
        print("-" * 60)

    def _count_convertible_sheets(self, wb) -> int:
        """Cuenta hojas convertibles."""
        exclude = ["BOM", "Tools list"]
        return len([s for s in wb.sheetnames if s not in exclude])

    def _print_sheet_conversion_summary(self, wb):
        """Imprime resumen de conversión."""
        exclude = ["BOM", "Tools list"]
        for sheet_name in wb.sheetnames:
            if sheet_name not in exclude:
                print("  {}: Procesado".format(sheet_name))


def extract_images(excel_path: str | Path, output_dir: str | Path) -> ImageExtractionStats:
    """Extrae imágenes de un Excel."""
    extractor = ImageExtractor(excel_path, output_dir)
    return extractor.extract_all()
