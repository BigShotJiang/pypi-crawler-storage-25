"""FileObject - wrapper for a found file path with copy/move operations."""

import shutil
from pathlib import Path
from typing import Optional


class FileObject:
    """Represents a found file with chainable copy/move operations.

    Examples:
        file = find.manpower_budget().in_path(r"C:\\origin")
        backup = file.copy(r"C:\\backup")
        moved = file.move(r"C:\\archive")
    """

    def __init__(self, path):
        if path is None:
            self.path = None
        elif isinstance(path, str):
            self.path = path
        else:
            self.path = str(path)

    def __str__(self) -> str:
        return self.path or ""

    def __repr__(self) -> str:
        return f"FileObject({self.path!r})"

    def __bool__(self) -> bool:
        return self.path is not None

    def copy(self, destination: str) -> "FileObject":
        """Copy file to destination folder and return a new FileObject pointing to the copy."""
        if not self.path:
            return FileObject(None)
        src = Path(self.path)
        dest = Path(destination)
        dest.mkdir(parents=True, exist_ok=True)
        dest_file = dest / src.name
        shutil.copy2(str(src), str(dest_file))
        return FileObject(str(dest_file))

    def move(self, destination: str) -> "FileObject":
        """Move file to destination folder and return a new FileObject pointing to the new location."""
        if not self.path:
            return FileObject(None)
        src = Path(self.path)
        dest = Path(destination)
        dest.mkdir(parents=True, exist_ok=True)
        dest_file = dest / src.name
        shutil.move(str(src), str(dest_file))
        return FileObject(str(dest_file))
