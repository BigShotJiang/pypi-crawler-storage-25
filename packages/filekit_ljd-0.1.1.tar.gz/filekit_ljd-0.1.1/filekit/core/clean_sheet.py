"""
clean_sheet.py - Limpiar y aplanar archivos Excel
==================================================

Responsabilidad:
  Dado un archivo Excel, expande merged cells y crea una hoja "Datos_Limpios"
  con datos normalizados sin formato adicional.

Características:
  - Apertura segura de archivos protegidos (sanitización de SheetProtection)
  - Expansión segura de merged cells
  - Copia datos a nueva hoja limpia sin formateo
  - Manejo robusto de errores comunes
  - Retorna DataFrame de pandas para análisis
"""

from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
import io
import re
import zipfile

import openpyxl
import pandas as pd
from tqdm import tqdm


# ═════════════════════════════════════════════════════════════════════════════
# Constantes
# ═════════════════════════════════════════════════════════════════════════════
HOJA_LIMPIA = "Datos_Limpios"

# Atributos válidos de <sheetProtection> reconocidos por openpyxl
_ATTRS_SHEET_PROTECTION = {
    "sheet", "objects", "scenarios", "formatCells", "formatColumns",
    "formatRows", "insertColumns", "insertRows", "insertHyperlinks",
    "deleteColumns", "deleteRows", "selectLockedCells", "selectUnlockedCells",
    "sort", "autoFilter", "pivotTables",
    "password", "algorithmName", "hashValue", "saltValue", "spinCount",
}


# ═════════════════════════════════════════════════════════════════════════════
# Funciones de utilidad para manejo seguro de Excel
# ═════════════════════════════════════════════════════════════════════════════

def sanitizar_xlsx(ruta: Path) -> io.BytesIO:
    """
    Limpia atributos XML desconocidos de <sheetProtection> en memoria.
    Devuelve un BytesIO listo para openpyxl; el archivo original no se modifica.

    Necesario cuando openpyxl lanza:
        TypeError: SheetProtection.__init__() got an unexpected keyword argument
    """
    buf = io.BytesIO()
    patron = re.compile(r"<sheetProtection\b[^/]*/?>")

    def _limpiar(tag: str) -> str:
        """Elimina atributos que openpyxl no reconoce de <sheetProtection>."""
        def _filtro(m: re.Match) -> str:
            return m.group(0) if m.group(1) in _ATTRS_SHEET_PROTECTION else ""
        return re.sub(r'\s+([\w:]+)=["\'][^"\']*["\']', _filtro, tag)

    try:
        with zipfile.ZipFile(ruta, "r") as zin, \
             zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = zin.read(item.filename)
                if re.match(r"xl/worksheets/.*\.xml$", item.filename):
                    try:
                        texto = data.decode("utf-8", errors="replace")
                        texto = patron.sub(lambda m: _limpiar(m.group(0)), texto)
                        data = texto.encode("utf-8")
                    except Exception:
                        pass
                zout.writestr(item, data)
        buf.seek(0)
        return buf
    except Exception as e:
        raise RuntimeError(f"Error sanitizando archivo Excel: {e}")


def abrir_wb_seguro(ruta: Path) -> openpyxl.Workbook:
    """
    Abre un workbook openpyxl con fallback automático a sanitización XML.
    Usar cuando el archivo puede contener atributos <sheetProtection> desconocidos.
    """
    try:
        return openpyxl.load_workbook(ruta)
    except TypeError as e:
        if "SheetProtection" in str(e):
            try:
                return openpyxl.load_workbook(sanitizar_xlsx(ruta))
            except Exception:
                raise RuntimeError(f"No se pudo abrir archivo incluso después de sanitizar: {e}")
        raise


# ═════════════════════════════════════════════════════════════════════════════
# Clase principal
# ═════════════════════════════════════════════════════════════════════════════
@dataclass
class CleanSheetProcessor:
    """
    Procesa archivos Excel expandiendo merged cells sin formateo adicional.

    Uso básico:
        processor = CleanSheetProcessor("archivo.xlsx")
        df = processor.ejecutar()

    Crear archivo nuevo (solo hoja limpia):
        processor = CleanSheetProcessor("archivo.xlsx")
        df = processor.ejecutar(output_path="salida.xlsx")

    Pasos individuales:
        processor.abrir()
        processor.aplanar_merged_cells()
        processor.guardar()
    """

    ruta: str | Path = None
    nombre_hoja_origen: str = "Sheet1"

    # estado interno
    _wb: openpyxl.Workbook = field(init=False, default=None)
    _ws_origen: object = field(init=False, default=None)
    _ws_limpia: object = field(init=False, default=None)
    _max_row: int = field(init=False, default=0)
    _max_col: int = field(init=False, default=0)

    def __post_init__(self):
        if self.ruta is not None:
            self.ruta = Path(self.ruta)

    # ══════════════════════════════════════════════════════════════════════════
    # APERTURA ROBUSTA
    # ══════════════════════════════════════════════════════════════════════════

    def abrir(self):
        """Abre el workbook de forma segura y valida la hoja origen."""
        try:
            self._wb = abrir_wb_seguro(self.ruta)
        except Exception as exc:
            raise RuntimeError(f"Error al abrir {self.ruta}: {exc}")

        # Intentar con "Sheet1" si el nombre indicado no existe
        if self.nombre_hoja_origen not in self._wb.sheetnames:
            alternativas = [s for s in self._wb.sheetnames
                            if "sheet" in s.lower() or s == self._wb.sheetnames[0]]
            if alternativas:
                self.nombre_hoja_origen = alternativas[0]
            else:
                raise ValueError(
                    f"Hoja '{self.nombre_hoja_origen}' no encontrada.\n"
                    f"Hojas disponibles: {self._wb.sheetnames}"
                )

        self._ws_origen = self._wb[self.nombre_hoja_origen]
        self._max_row = self._ws_origen.max_row
        self._max_col = self._ws_origen.max_column

    def guardar(self, ruta_salida: Optional[str | Path] = None):
        """
        Guarda el workbook.

        Args:
            ruta_salida: Si se especifica, crea un nuevo archivo con SOLO la hoja Datos_Limpios.
                        Si es None, sobrescribe el archivo original con todas las hojas.
        """
        try:
            if ruta_salida:
                # Crear nuevo workbook con solo la hoja Datos_Limpios
                wb_nuevo = openpyxl.Workbook()
                ws_nueva = wb_nuevo.active
                ws_nueva.title = HOJA_LIMPIA

                # Copiar datos (sin estilos)
                ws_origen = self._ws_limpia
                for r in range(1, ws_origen.max_row + 1):
                    for c in range(1, ws_origen.max_column + 1):
                        try:
                            ws_nueva.cell(r, c).value = ws_origen.cell(r, c).value
                        except Exception:
                            ws_nueva.cell(r, c).value = None

                destino = Path(ruta_salida)
                wb_nuevo.save(destino)
            else:
                # Sobrescribir archivo original
                destino = self.ruta
                self._wb.save(destino)
        except Exception as exc:
            raise RuntimeError(f"Error guardando {destino}: {exc}")

    # ══════════════════════════════════════════════════════════════════════════
    # APLANAR MERGED CELLS
    # ══════════════════════════════════════════════════════════════════════════

    def aplanar_merged_cells(self):
        """
        Crea HOJA_LIMPIA expandiendo merged cells de forma robusta.
        Solo copia datos, sin formateo.

        Maneja:
          - Merged cells desprotegidas
          - Merged cells vacías
          - Rango de celdas grandes
          - Errores de lectura de celdas individuales
        """
        if self._wb is None:
            self.abrir()

        ws_src = self._ws_origen

        # Eliminar hoja limpia si existe
        if HOJA_LIMPIA in self._wb.sheetnames:
            del self._wb[HOJA_LIMPIA]

        ws_dst = self._wb.create_sheet(HOJA_LIMPIA)

        # ── Construir mapa de merged cells ────────────────────────────────────
        expand: dict[tuple[int, int], object] = {}
        try:
            if ws_src.merged_cells is not None:
                for rng in ws_src.merged_cells.ranges:
                    try:
                        val = ws_src.cell(rng.min_row, rng.min_col).value
                        for r in range(rng.min_row, rng.max_row + 1):
                            for c in range(rng.min_col, rng.max_col + 1):
                                expand[(r, c)] = val
                    except Exception:
                        pass
        except Exception:
            pass

        # ── Copiar celdas (expandidas y normales) con barra de progreso ──────
        total_celdas = self._max_row * self._max_col
        descripcion = "Aplanando celdas"

        with tqdm(total=total_celdas, desc=descripcion, unit="cell", disable=total_celdas < 10000) as pbar:
            for r in range(1, self._max_row + 1):
                for c in range(1, self._max_col + 1):
                    try:
                        if (r, c) in expand:
                            val = expand[(r, c)]
                        else:
                            val = ws_src.cell(r, c).value
                        ws_dst.cell(r, c).value = val
                    except Exception:
                        ws_dst.cell(r, c).value = None
                    pbar.update(1)

        self._ws_limpia = ws_dst

    # ══════════════════════════════════════════════════════════════════════════
    # EXPORTAR A PANDAS
    # ══════════════════════════════════════════════════════════════════════════

    def obtener_dataframe(self) -> pd.DataFrame:
        """
        Retorna la hoja limpia como DataFrame de pandas.
        Primera fila se usa como encabezados.

        Maneja:
          - Filas y columnas vacías
          - Valores None o no serializables
          - Encoding de caracteres especiales
        """
        if self._ws_limpia is None:
            self.aplanar_merged_cells()

        ws = self._ws_limpia
        datos = []

        # Primera fila: encabezados (con sanitización)
        encabezados = []
        for c in range(1, ws.max_column + 1):
            try:
                val = ws.cell(1, c).value
                encabezados.append(str(val).strip() if val is not None else f"Col_{c}")
            except Exception:
                encabezados.append(f"Col_{c}")

        # Resto de filas: datos con barra de progreso
        num_filas = max(0, ws.max_row - 1)
        with tqdm(total=num_filas, desc="Leyendo datos", unit="row", disable=num_filas < 1000) as pbar:
            for r in range(2, ws.max_row + 1):
                fila = []
                for c in range(1, ws.max_column + 1):
                    try:
                        val = ws.cell(r, c).value
                        fila.append(val)
                    except Exception:
                        fila.append(None)
                datos.append(fila)
                pbar.update(1)

        if not datos:
            return pd.DataFrame(columns=encabezados)

        return pd.DataFrame(datos, columns=encabezados)

    # ══════════════════════════════════════════════════════════════════════════
    # TODO-EN-UNO
    # ══════════════════════════════════════════════════════════════════════════

    def ejecutar(self, output_path: Optional[str | Path] = None) -> pd.DataFrame:
        """
        Ejecuta todo el pipeline: abrir → aplanar → guardar → retornar DataFrame

        Args:
            output_path: Ruta donde guardar resultado.
                        - None: sobrescribe archivo original (todas las hojas)
                        - especificado: crea nuevo archivo con SOLO Datos_Limpios

        Returns:
            pd.DataFrame: Datos de la hoja limpia
        """
        self.abrir()
        self.aplanar_merged_cells()

        if output_path:
            self.guardar(output_path)

        return self.obtener_dataframe()


# ═════════════════════════════════════════════════════════════════════════════
# FUNCIÓN DE CONVENIENCIA
# ═════════════════════════════════════════════════════════════════════════════

def clean_sheet(
    archivo: str | Path,
    nombre_hoja: str = "Sheet1",
    output_path: Optional[str | Path] = None,
) -> pd.DataFrame:
    """
    Procesa un archivo Excel expandiendo merged cells sin formateo adicional.

    CARACTERÍSTICAS:
      ✓ Manejo automático de archivos protegidos (SheetProtection)
      ✓ Expansión segura de merged cells
      ✓ Eliminación de formateo innecesario
      ✓ Manejo robusto de errores de lectura
      ✓ Exportación a pandas DataFrame

    Args:
        archivo: Ruta del archivo Excel a procesar
        nombre_hoja: Nombre de la hoja a procesar (default: "Sheet1")
        output_path: Ruta donde guardar el resultado.
                    - Si None: sobrescribe el archivo original (manteniendo todas las hojas)
                    - Si especificado: crea nuevo archivo con SOLO la hoja Datos_Limpios

    Returns:
        pd.DataFrame: Datos de la hoja limpia como DataFrame

    Raises:
        RuntimeError: Si el archivo no puede abrirse o procesarse
        ValueError: Si la hoja especificada no existe

    Ejemplo:
        # Sobrescribir archivo original
        df = clean_sheet("datos.xlsx")

        # Crear archivo nuevo con solo hoja limpia
        df = clean_sheet("datos.xlsx", output_path="datos_limpios.xlsx")

        # Con hoja específica
        df = clean_sheet("datos.xlsx", nombre_hoja="Datos_Planos", output_path="salida.xlsx")
    """
    processor = CleanSheetProcessor(
        ruta=archivo,
        nombre_hoja_origen=nombre_hoja,
    )
    return processor.ejecutar(output_path)


# ═════════════════════════════════════════════════════════════════════════════
# EJECUCIÓN DIRECTA
# ═════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import sys

    if len(sys.argv) >= 2:
        archivo = sys.argv[1]
        output = sys.argv[2] if len(sys.argv) >= 3 else None
        hoja = sys.argv[3] if len(sys.argv) >= 4 else "Sheet1"

        try:
            df = clean_sheet(archivo, nombre_hoja=hoja, output_path=output)
            print(f"\n✓ Procesado exitosamente: {archivo}")
            print(f"  Hoja origen: {hoja}")
            print(f"  Filas: {len(df)}, Columnas: {len(df.columns)}")
            if output:
                print(f"  Guardado en: {output}")
            print(f"\nEncabezados detectados:")
            for i, col in enumerate(df.columns, 1):
                print(f"  {i}. {col}")
        except Exception as e:
            print(f"\n✗ Error: {e}")
            sys.exit(1)
    else:
        print("Uso: python clean_sheet.py <archivo.xlsx> [salida.xlsx] [nombre_hoja]")
        print("\nEjemplos:")
        print("  python clean_sheet.py datos.xlsx")
        print("  python clean_sheet.py datos.xlsx salida.xlsx")
        print("  python clean_sheet.py datos.xlsx salida.xlsx 'Datos_Planos'")
