"""Document Processing Hub - File search and document processing."""

from .finder.simple import find
from .operations.simple import ops

__version__ = "0.5.6"
__all__ = ["find", "ops"]
