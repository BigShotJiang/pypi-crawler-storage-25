"""ops API - document processing operations."""

from pathlib import Path
from typing import Optional, Union

import pandas as pd

from ..core.file import FileObject


class _OpsNamespace:
    """Namespace object exposing processing operations.

    Usage:
        from documentprocessinghub import find, ops

        file = find.manpower_budget()
        df = ops.clean_sheet(file, sheet="Sheet1", output=r"C:\\result.xlsx")
    """

    def clean_sheet(
        self,
        file: Union[FileObject, str, Path],
        sheet: str = "Sheet1",
        output: Optional[Union[str, Path]] = None,
    ) -> pd.DataFrame:
        """Process an Excel file by expanding merged cells.

        Args:
            file: FileObject, string path, or Path to the Excel file.
            sheet: Name of the sheet to process.
            output: Optional output path for the cleaned file.

        Returns:
            pd.DataFrame with the processed data.
        """
        from ..core.clean_sheet import CleanSheetProcessor

        path = str(file)
        processor_obj = CleanSheetProcessor(
            ruta=path,
            nombre_hoja_origen=sheet,
        )
        return processor_obj.ejecutar(output_path=output)

    def extract_images(
        self,
        file: Union[FileObject, str, Path],
        output_dir: Union[str, Path],
    ) -> dict:
        """Extract images from a PDF file.

        Args:
            file: FileObject, string path, or Path to the PDF file.
            output_dir: Directory where extracted images will be saved.

        Returns:
            dict with extraction statistics.
        """
        from ..core.image_extractor import ImageExtractor

        path = str(file)
        extractor = ImageExtractor(path, output_dir)
        stats = extractor.extract_all()

        self._print_summary(stats)
        return self._stats_to_dict(stats)

    def _print_summary(self, stats) -> None:
        """Imprime un resumen de las estadísticas."""
        print("\n" + "=" * 60)
        print("RESUMEN DE RESULTADOS")
        print("=" * 60)
        status = "SUCCESS" if stats.total_images > 0 else "COMPLETED"
        print("Estado: {}".format(status))
        print("Imagenes extraidas: {}".format(stats.total_images))
        print("Hojas convertidas: {}".format(stats.total_sheets))
        print("Duplicadas omitidas: {}".format(stats.duplicates_skipped))

    def _stats_to_dict(self, stats) -> dict:
        """Convierte estadísticas a diccionario."""
        return {
            "total_images": stats.total_images,
            "total_sheets": stats.total_sheets,
            "duplicates_skipped": stats.duplicates_skipped,
            "sheets_processed": stats.sheets_processed,
        }


ops = _OpsNamespace()
