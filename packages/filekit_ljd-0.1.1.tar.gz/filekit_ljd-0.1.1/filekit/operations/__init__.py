"""Operations subpackage - document processing operations."""
