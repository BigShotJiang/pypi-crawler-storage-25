"""find API - locates files by type using predefined paths."""

from typing import Optional

from ..fileSelector import find_in_folder
from ..paths_config import DEFAULT_PATHS
from ..core.file import FileObject


def _find_in_predefined(file_type: str) -> Optional[str]:
    if file_type not in DEFAULT_PATHS:
        return None
    for folder_path in DEFAULT_PATHS[file_type]:
        try:
            result = find_in_folder(folder_path, file_type)
            if result:
                return result
        except (FileNotFoundError, PermissionError, ValueError):
            continue
    return None


class _FindNamespace:
    """Namespace exposing one method per supported file type.

    Each method searches predefined paths from paths_config.py and returns
    a FileObject ready for copy/move/processing.

    Usage:
        from documentprocessinghub import find, ops

        file = find.manpower_budget()
        backup = file.copy(r"C:\\Backup")
        df = ops.clean_sheet(file, sheet="Sheet1", output=r"C:\\result.xlsx")
    """

    def manpower_budget(self) -> FileObject:
        return FileObject(_find_in_predefined("MANPOWER_BUDGET"))

    def manpower_documents(self) -> FileObject:
        return FileObject(_find_in_predefined("MANPOWER_DOCUMENTS"))

    def manpower(self) -> FileObject:
        return FileObject(_find_in_predefined("MANPOWER"))

    def zj(self) -> FileObject:
        return FileObject(_find_in_predefined("ZJ"))

    def real_time_production(self) -> FileObject:
        return FileObject(_find_in_predefined("REAL_TIME_PRODUCTION"))


find = _FindNamespace()
