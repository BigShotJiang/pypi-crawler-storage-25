"""Finder subpackage - fluent file-search API."""
