import requests
import os
def getname(url):
    return url.split("/")[-1]
class Downloader:
    def __init__(self,url):
        self.url = url
    def download(self,path:str=""):
        r = requests.get(self.url)
        with open(os.path.join(path,getname(self.url)),"wb") as f:
            f.write(r.content)
    def cdownload(self,filename:str):
        r = requests.get(self.url)
        with open(filename,"wb") as f:
            f.write(r.content)