class util:
    class array:
        def lencheck(lisa:list,number:int,maximo:bool=True):
            if maximo:
                return len(lisa) <= maximo
            else:
                return len(lisa) >= maximo