import smtplib
import mimetypes
from email.message import EmailMessage

class Pygmail:
    def __init__(self, fro, passwd, to, sub, body):
        self.fro = fro
        self.passwd = passwd
        self.to = to
        self.msg = EmailMessage()
        self.msg['Subject'] = sub
        self.msg['From'] = fro
        self.msg['To'] = to
        self.msg.set_content(body)

    def addfile(self, caminho_arquivo):
        # 1. Identifica o tipo do arquivo (pdf, png, etc)
        mime_type, _ = mimetypes.guess_type(caminho_arquivo)
        maintype, subtype = mime_type.split('/')

        # 2. Lê o arquivo em modo binário ('rb') e anexa
        with open(caminho_arquivo, 'rb') as f:
            dados = f.read()
            self.msg.add_attachment(
                dados,
                maintype=maintype,
                subtype=subtype,
                filename=caminho_arquivo
            )

    def enviar(self):
        with smtplib.SMTP_SSL('://gmail.com', 465) as smtp:
            smtp.login(self.fro, self.passwd)
            smtp.send_message(self.msg)
            print("E-mail enviado com sucesso!")

# --- Exemplo de Uso ---
# mail = Pygmail("seu@gmail.com", "sua_senha", "destino@gmail.com", "Assunto", "Corpo")
# mail.addfile("relatorio.pdf")
# mail.enviar()