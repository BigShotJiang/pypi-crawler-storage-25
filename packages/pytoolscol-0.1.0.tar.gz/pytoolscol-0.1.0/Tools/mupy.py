from pydub import AudioSegment
import simpleaudio as sa
import pygame
import pygame.mixer as audia
import pygame
class audio:
    @staticmethod
    def stopall():
        sa.stop_all() 
class player3:
    def __init__(self,file):
        audia.init()
        
        self.file = file
        audia.music.load(file)
    def play(self):
        audia.music.play()
    def stop(self):
        audia.music.stop()
    def pause(self):
        audia.music.pause()
    def unpause(self):
        audia.music.unpause()
    def change(self,file):
        self.file = file
        audia.music.unload()
        audia.music.load(self.file)
    def unload(self):
        audia.music.unload()
class player2:
    def __init__(self,file):
        audia.init()
        self.player = audia.Sound(file)
    def play(self):
        self.player.play()
    def stop(self):
        self.player.stop()
    def pause(self):
        audia.pause()
    def unpause(self):
        audia.unpause()
class player:
    def __init__(self, file):
        AudioSegment.converter = r"C:\ffmpeg\ffmpeg-2026-04-01-git-eedf8f0165-full_build\bin\ffmpeg.exe"
        AudioSegment.ffprobe = r"C:\ffmpeg\ffmpeg-2026-04-01-git-eedf8f0165-full_build\bin\ffprobe.exe"
        self.file = file
        self.audio = AudioSegment.from_file(file)

        self.pos = 0  # posição em ms
        self.play_obj = None

        self.paused = False

    def _play_from_pos(self):
        segment = self.audio[self.pos:]

        wave_obj = sa.WaveObject(
            segment.raw_data,
            num_channels=segment.channels,
            bytes_per_sample=segment.sample_width,
            sample_rate=segment.frame_rate
        )

        self.play_obj = wave_obj.play()

    def play(self):
        
        self.pos = 0
        self.paused = False
        self._play_from_pos()
    
    def pause(self):
        if self.play_obj and self.play_obj.is_playing():
            # calcula tempo atual
            self.pos += int(self.play_obj.get_time() * 1000)
            self.play_obj.stop()
            self.paused = True

    def resume(self):
        if self.paused:
            self.paused = False
            self._play_from_pos()

    def stop(self):
        if self.play_obj:
            self.play_obj.stop()
        self.pos = 0
        self.paused = False

    def ispaused(self):
        return self.paused

    def switchpr(self):
        if self.paused:
            self.resume()
        else:
            if self.play_obj and self.play_obj.is_playing():
                self.pause()
            else:
                self.play()