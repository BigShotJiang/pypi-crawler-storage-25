"""
internet.py - Extract internet-related patterns from text.

Extractors:
    - emails
    - urls
    - domains
    - ipv4_addresses
    - ipv6_addresses
    - slugs
"""

import re

# ───────────────────────────── patterns ─────────────────────────────

_EMAIL = re.compile(
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
    re.IGNORECASE,
)

_URL = re.compile(
    r"https?://"                        # scheme
    r"(?:[a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,}"  # host
    r"(?::\d{1,5})?"                    # optional port
    r"(?:/[^\s]*)?",                    # optional path/query
    re.IGNORECASE,
)

_DOMAIN = re.compile(
    r"\b(?:[a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,}\b",
    re.IGNORECASE,
)

_IPV4 = re.compile(
    r"\b"
    r"(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
    r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)"
    r"\b"
)

_IPV6 = re.compile(
    r"\b"
    r"(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}"        # full
    r"|(?:[0-9a-fA-F]{1,4}:){1,7}:"                      # trailing ::
    r"|:(?::[0-9a-fA-F]{1,4}){1,7}"                      # leading ::
    r"|::(?:ffff(?::0{1,4})?:)?"                          # ::ffff:
    r"(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
    r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)"
    r"\b",
    re.IGNORECASE,
)

_SLUG = re.compile(
    r"\b[a-z0-9]+(?:-[a-z0-9]+)+\b"
)

# ───────────────────────────── extractors ────────────────────────────

def emails(text: str) -> list[str]:
    """Extract all email addresses from text."""
    return _EMAIL.findall(text)


def urls(text: str) -> list[str]:
    """Extract all HTTP/HTTPS URLs from text."""
    return _URL.findall(text)


def domains(text: str) -> list[str]:
    """
    Extract all domain names from text.
    Note: this is intentionally broad — it will also match
    domains inside URLs and emails. Filter downstream if needed.
    """
    return _DOMAIN.findall(text)


def ipv4_addresses(text: str) -> list[str]:
    """Extract all valid IPv4 addresses from text."""
    return _IPV4.findall(text)


def ipv6_addresses(text: str) -> list[str]:
    """Extract all IPv6 addresses from text."""
    return _IPV6.findall(text)


def slugs(text: str) -> list[str]:
    """Extract URL slugs (e.g. 'my-blog-post') from text."""
    return _SLUG.findall(text)