"""CLI test configuration."""

import pytest
from typer.testing import CliRunner


@pytest.fixture(autouse=True)
def _no_color(monkeypatch: pytest.MonkeyPatch) -> None:
    """Disable Rich ANSI formatting so test assertions work on plain text."""
    monkeypatch.setenv("NO_COLOR", "1")


@pytest.fixture
def runner() -> CliRunner:
    """Typer CLI test runner."""
    return CliRunner()
