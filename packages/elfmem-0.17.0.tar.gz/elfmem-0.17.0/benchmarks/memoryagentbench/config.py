"""Configuration for the MemoryAgentBench benchmark harness."""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class MABenchConfig:
    """All tuneable parameters for a MemoryAgentBench benchmark run.

    USE WHEN: Configuring a benchmark run.
    DON'T USE WHEN: You need runtime state — this is pure config.
    COST: Zero (dataclass).
    RETURNS: Frozen configuration object.
    NEXT: Pass to the runner.
    """

    output_dir: Path = Path("benchmarks/memoryagentbench/results")
    lm_studio_base_url: str = "http://localhost:1234/v1"

    # Which competencies to run (None = all)
    competencies: list[str] | None = None

    # Which sub-datasets to run within selected competencies (None = all)
    sources: list[str] | None = None

    # elfmem settings
    elfmem_llm_model: str = "google/gemma-4-26b-a4b"
    elfmem_embedding_model: str = "text-embedding-nomic-embed-text-v1.5"
    elfmem_embedding_dimensions: int = 768
    # top_k controls how many blocks are returned after contradiction suppression.
    # hybrid_retrieve oversamples by 2× before suppression, so with 18 total
    # blocks and top_k=10, all 18 enter suppression — full coverage. Setting
    # top_k=20 ensures all post-suppression blocks (~13) reach the context.
    top_k: int = 20
    inbox_threshold: int = 50
    search_window_hours: float = 10000.0
    # Contradiction detection prefilter. Only pairs with cosine similarity above
    # this threshold are sent to the LLM for contradiction checking. Real
    # contradictions (same entity, different claims) have similarity >0.80.
    # 0.75 keeps all true contradictions while cutting spurious pairs 10×.
    contradiction_similarity_prefilter: float = 0.75
    chunk_size: int = 256  # words per chunk (~350 tokens, fits in 4096 context)
    consolidate_every_n_chunks: int = 10

    # Answer generation
    answer_model: str = "google/gemma-4-26b-a4b"
    answer_max_tokens: int = 100

    # Model context window — must match LM Studio's Context Length setting.
    # Gemma 4 26B-A4B supports up to 262144 tokens, but the loaded context
    # depends on your GPU offload and VRAM. Check Model Settings → Context Length
    # in LM Studio and set this to match (default load is often 4096 with partial
    # GPU offload; increase in LM Studio first, then update this value).
    context_window_tokens: int = 4096

    # Execution
    max_examples: int | None = None
    resume: bool = False
