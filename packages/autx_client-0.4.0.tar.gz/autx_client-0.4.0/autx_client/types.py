"""AUTX API response types."""

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class ProxyResponse:
    """Response from a proxy request."""
    content: bytes
    status_code: int
    content_type: str
    headers: dict[str, str] = field(default_factory=dict)
    request_id: str = ""
    latency_ms: int = 0
    agent_ticker: str = ""

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    @property
    def json(self) -> Any:
        import json
        return json.loads(self.content)


@dataclass
class OrderResponse:
    """Response from creating an order."""
    id: str
    agent_id: str
    status: str
    amount_paid: float
    platform_fee: float
    created_at: str


@dataclass
class OrderResult:
    """Result of a completed order."""
    id: str
    status: str
    output_hash: str | None = None
    output_text: str | None = None
    completed_at: str | None = None


@dataclass
class CheckoutResponse:
    """Response from creating a Stripe checkout session."""
    checkout_url: str
    session_id: str


@dataclass
class OrderListItem:
    """Order in a list response."""
    id: str
    agent_id: str
    agent_name: str | None
    agent_ticker: str | None
    status: str
    amount_paid: float
    platform_fee: float
    payment_method: str | None
    created_at: str
    completed_at: str | None = None


@dataclass
class TickerCheckResult:
    """Result of a ticker availability check."""
    available: bool
    ticker: str


@dataclass
class NameCheckResult:
    """Result of a name availability check."""
    available: bool
    name: str


# --- Credits & Streaming ---

@dataclass
class CreditBalance:
    """Current credit balance for the authenticated user."""
    available_usdc: float
    reserved_usdc: float
    expires_at: str | None
    last_deposit_at: str | None
    last_withdrawal_at: str | None


@dataclass
class CreditTransaction:
    """A single credit ledger entry."""
    id: str
    type: str  # deposit, withdrawal, consume, refund
    amount: float
    session_id: str | None
    order_id: str | None
    tx_hash: str | None
    created_at: str


@dataclass
class SessionInfo:
    """Metadata returned after WebSocket auth for a chat session."""
    session_id: str
    agent_id: str
    agent_name: str
    agent_ticker: str
    service_price: float
    credits_reserved: float


@dataclass
class StreamChunk:
    """A single streamed text chunk from an agent."""
    data: str


@dataclass
class StreamDone:
    """Terminal message from a streaming completion."""
    order_id: str
    output_hash: str


@dataclass
class BillingUpdate:
    """Billing event received mid-stream."""
    amount_charged: float
    platform_fee: float


# --- Agent Manifest ---

@dataclass
class ManifestInput:
    """Agent manifest input configuration."""
    type: str = "text"
    accepts_files: bool = False
    file_types: list[str] = field(default_factory=list)
    max_size_bytes: int = 10_485_760

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ManifestOutput:
    """Agent manifest output configuration."""
    type: str = "json"
    produces_files: bool = False
    content_types: list[str] = field(default_factory=lambda: ["application/json"])
    max_size_bytes: int = 52_428_800

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgentManifest:
    """Agent capability manifest."""
    input: ManifestInput = field(default_factory=ManifestInput)
    output: ManifestOutput = field(default_factory=ManifestOutput)
    supports_sessions: bool = False
    session_price_per_message: float | None = None
    session_minimum_messages: int = 5
    session_max_duration_minutes: int = 240
    chat_response_path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"input": self.input.to_dict(), "output": self.output.to_dict()}
        d["supports_sessions"] = self.supports_sessions
        d["session_minimum_messages"] = self.session_minimum_messages
        d["session_max_duration_minutes"] = self.session_max_duration_minutes
        if self.session_price_per_message is not None:
            d["session_price_per_message"] = self.session_price_per_message
        if self.chat_response_path is not None:
            d["chat_response_path"] = self.chat_response_path
        return d


# --- Agent Profile ---

@dataclass
class AgentProfileData:
    """Agent profile for marketplace listing."""
    tagline: str
    capabilities: list[str] = field(default_factory=list)
    use_cases: list[str] = field(default_factory=list)
    output_description: str | None = None
    best_for: str | None = None
    limitations: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


# --- Agent Responses ---

@dataclass
class AgentResponse:
    """Full agent response from create operations (includes endpoint_url)."""
    id: str
    owner_id: str | None
    name: str
    ticker: str
    endpoint_url: str
    description: str | None
    category: str | None
    service_price: float
    auth_tier: str
    provider: str | None
    provider_key_configured: bool
    status: str
    uptime_pct: float
    success_rate: float
    total_revenue: float
    total_requests: int
    created_at: str
    contract_address: str | None = None
    dividend_splitter_address: str | None = None
    agent_token_address: str | None = None
    manifest: dict[str, Any] | None = None
    profile: dict[str, Any] | None = None
    image_url: str | None = None


@dataclass
class AgentListItem:
    """Public agent view (no endpoint_url)."""
    id: str
    owner_id: str | None
    name: str
    ticker: str
    description: str | None
    category: str | None
    service_price: float
    auth_tier: str
    provider: str | None
    provider_key_configured: bool
    status: str
    uptime_pct: float
    success_rate: float
    total_revenue: float
    total_requests: int
    created_at: str
    contract_address: str | None = None
    dividend_splitter_address: str | None = None
    agent_token_address: str | None = None
    manifest: dict[str, Any] | None = None
    profile: dict[str, Any] | None = None
    image_url: str | None = None


# --- Parsers ---

def _parse_agent_response(data: dict[str, Any]) -> AgentResponse:
    return AgentResponse(
        id=str(data["id"]),
        owner_id=str(data["owner_id"]) if data.get("owner_id") else None,
        name=data["name"],
        ticker=data["ticker"],
        endpoint_url=data["endpoint_url"],
        description=data.get("description"),
        category=data.get("category"),
        service_price=float(data["service_price"]),
        auth_tier=data["auth_tier"],
        provider=data.get("provider"),
        provider_key_configured=data.get("provider_key_configured", False),
        status=data["status"],
        uptime_pct=float(data.get("uptime_pct", 0)),
        success_rate=float(data.get("success_rate", 0)),
        total_revenue=float(data.get("total_revenue", 0)),
        total_requests=data.get("total_requests", 0),
        created_at=str(data["created_at"]),
        contract_address=data.get("contract_address"),
        dividend_splitter_address=data.get("dividend_splitter_address"),
        agent_token_address=data.get("agent_token_address"),
        manifest=data.get("manifest"),
        profile=data.get("profile"),
        image_url=data.get("image_url"),
    )


def _parse_agent_list_item(data: dict[str, Any]) -> AgentListItem:
    return AgentListItem(
        id=str(data["id"]),
        owner_id=str(data["owner_id"]) if data.get("owner_id") else None,
        name=data["name"],
        ticker=data["ticker"],
        description=data.get("description"),
        category=data.get("category"),
        service_price=float(data["service_price"]),
        auth_tier=data["auth_tier"],
        provider=data.get("provider"),
        provider_key_configured=data.get("provider_key_configured", False),
        status=data["status"],
        uptime_pct=float(data.get("uptime_pct", 0)),
        success_rate=float(data.get("success_rate", 0)),
        total_revenue=float(data.get("total_revenue", 0)),
        total_requests=data.get("total_requests", 0),
        created_at=str(data["created_at"]),
        contract_address=data.get("contract_address"),
        dividend_splitter_address=data.get("dividend_splitter_address"),
        agent_token_address=data.get("agent_token_address"),
        manifest=data.get("manifest"),
        profile=data.get("profile"),
        image_url=data.get("image_url"),
    )


def _parse_order_list_item(data: dict[str, Any]) -> OrderListItem:
    return OrderListItem(
        id=str(data["id"]),
        agent_id=str(data["agent_id"]),
        agent_name=data.get("agent_name"),
        agent_ticker=data.get("agent_ticker"),
        status=data["status"],
        amount_paid=float(data.get("amount_paid", 0)),
        platform_fee=float(data.get("platform_fee", 0)),
        payment_method=data.get("payment_method"),
        created_at=str(data["created_at"]),
        completed_at=str(data["completed_at"]) if data.get("completed_at") else None,
    )
