"""AUTX Python Client — programmatic access to the AUTX gateway."""

from __future__ import annotations

import json
import time
from typing import Any, AsyncGenerator, BinaryIO

import httpx

from autx_client.types import (
    AgentListItem,
    AgentManifest,
    AgentProfileData,
    AgentResponse,
    BillingUpdate,
    CheckoutResponse,
    CreditBalance,
    CreditTransaction,
    NameCheckResult,
    OrderListItem,
    OrderResponse,
    OrderResult,
    ProxyResponse,
    SessionInfo,
    StreamChunk,
    StreamDone,
    TickerCheckResult,
    _parse_agent_list_item,
    _parse_agent_response,
    _parse_order_list_item,
)

DEFAULT_BASE_URL = "https://app-autx-api-prod.azurewebsites.net/api/v1"
DEFAULT_TIMEOUT = 120
MAX_RETRIES = 3
RETRY_BACKOFF = 1.0


class AutxClient:
    """Synchronous AUTX API client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ):
        if not api_key.startswith("autx_live_"):
            raise ValueError("API key must start with 'autx_live_'")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Make a request with retry logic."""
        url = f"{self.base_url}{path}"
        last_exc = None
        for attempt in range(self.max_retries):
            try:
                with httpx.Client(timeout=self.timeout) as client:
                    resp = client.request(method, url, headers=self._headers(), **kwargs)
                    if resp.status_code == 429:
                        retry_after = int(resp.headers.get("Retry-After", "5"))
                        time.sleep(retry_after)
                        continue
                    return resp
            except httpx.TimeoutException as e:
                last_exc = e
                time.sleep(RETRY_BACKOFF * (attempt + 1))
            except httpx.HTTPError as e:
                last_exc = e
                break
        raise last_exc or RuntimeError("Request failed after retries")

    # --- Buyer methods ---

    def proxy(self, ticker_or_id: str, prompt: str | None = None, body: dict | None = None) -> ProxyResponse:
        """Send a request through the AUTX proxy (free, no billing).

        Args:
            ticker_or_id: Agent ticker or UUID
            prompt: Text prompt (convenience — wraps in {"prompt": prompt})
            body: Raw JSON body to forward (overrides prompt if both given)
        """
        json_body = body or {"prompt": prompt}
        resp = self._request("POST", f"/proxy/{ticker_or_id}", json=json_body)
        resp.raise_for_status()
        return ProxyResponse(
            content=resp.content,
            status_code=resp.status_code,
            content_type=resp.headers.get("content-type", ""),
            headers=dict(resp.headers),
            request_id=resp.headers.get("x-autx-request-id", ""),
            latency_ms=int(resp.headers.get("x-autx-latency-ms", "0")),
            agent_ticker=resp.headers.get("x-autx-agent", ""),
        )

    def order(
        self,
        agent_id: str,
        prompt: str,
        payment_method: str = "stripe",
        files: list[tuple[str, BinaryIO]] | None = None,
    ) -> OrderResponse:
        """Create a paid service order.

        Args:
            agent_id: Agent UUID
            prompt: Text prompt
            payment_method: "stripe" or "usdc"
            files: Optional list of (filename, file_object) tuples for multipart
        """
        if files:
            multipart = [
                ("agent_id", (None, agent_id)),
                ("prompt", (None, prompt)),
                ("payment_method", (None, payment_method)),
            ]
            for fname, fobj in files:
                multipart.append(("files", (fname, fobj, "application/octet-stream")))
            resp = self._request("POST", "/orders/multipart", files=multipart)
        else:
            resp = self._request("POST", "/orders/", json={
                "agent_id": agent_id,
                "prompt": prompt,
                "payment_method": payment_method,
            })
        resp.raise_for_status()
        data = resp.json()
        return OrderResponse(
            id=data["id"],
            agent_id=data["agent_id"],
            status=data["status"],
            amount_paid=data["amount_paid"],
            platform_fee=data["platform_fee"],
            created_at=data["created_at"],
        )

    def get_order(self, order_id: str) -> OrderResult:
        """Get the result of a completed order."""
        resp = self._request("GET", f"/orders/{order_id}")
        resp.raise_for_status()
        data = resp.json()
        return OrderResult(
            id=data["id"],
            status=data["status"],
            output_hash=data.get("output_hash"),
            output_text=data.get("output_text"),
            completed_at=data.get("completed_at"),
        )

    def list_agents(
        self,
        category: str | None = None,
        sort: str = "revenue",
        limit: int | None = None,
        offset: int | None = None,
        search: str | None = None,
        status: str | None = None,
    ) -> list[AgentListItem]:
        """List available agents."""
        params: dict[str, str] = {"sort": sort}
        if category:
            params["category"] = category
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        if search:
            params["search"] = search
        if status:
            params["status"] = status
        resp = self._request("GET", "/agents/", params=params)
        resp.raise_for_status()
        return [_parse_agent_list_item(a) for a in resp.json()]

    def get_agent(self, agent_id: str) -> AgentListItem:
        """Get an agent by UUID."""
        resp = self._request("GET", f"/agents/{agent_id}")
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    def get_agent_by_ticker(self, ticker: str) -> AgentListItem:
        """Get an agent by ticker symbol."""
        resp = self._request("GET", f"/agents/ticker/{ticker}")
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    def check_ticker(self, ticker: str) -> TickerCheckResult:
        """Check if a ticker is available."""
        resp = self._request("GET", f"/agents/check-ticker/{ticker}")
        resp.raise_for_status()
        data = resp.json()
        return TickerCheckResult(available=data["available"], ticker=ticker)

    def check_name(self, name: str) -> NameCheckResult:
        """Check if an agent name is available."""
        resp = self._request("GET", f"/agents/check-name/{name}")
        resp.raise_for_status()
        data = resp.json()
        return NameCheckResult(available=data["available"], name=name)

    def list_orders(
        self,
        agent_id: str | None = None,
        status: str | None = None,
    ) -> list[OrderListItem]:
        """List your orders with optional filters."""
        params: dict[str, str] = {}
        if agent_id:
            params["agent_id"] = agent_id
        if status:
            params["status"] = status
        resp = self._request("GET", "/orders/", params=params)
        resp.raise_for_status()
        return [_parse_order_list_item(o) for o in resp.json()]

    # --- Publisher methods ---

    def create_agent(
        self,
        name: str,
        ticker: str,
        endpoint_url: str,
        *,
        description: str | None = None,
        category: str | None = None,
        service_price: float = 5.0,
        auth_tier: str = "jwt_default",
        provider: str | None = None,
        provider_api_key: str | None = None,
        manifest: AgentManifest | dict | None = None,
        profile: AgentProfileData | dict | None = None,
        stripe_session_id: str | None = None,
        tx_hash: str | None = None,
        deployer_address: str | None = None,
    ) -> AgentResponse:
        """Register a new agent on the AUTX marketplace.

        Requires an API key with scope 'agents' and verified email.
        """
        body: dict[str, Any] = {
            "name": name,
            "ticker": ticker,
            "endpoint_url": endpoint_url,
            "service_price": service_price,
            "auth_tier": auth_tier,
        }
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if provider is not None:
            body["provider"] = provider
        if provider_api_key is not None:
            body["provider_api_key"] = provider_api_key
        if manifest is not None:
            body["manifest"] = manifest.to_dict() if isinstance(manifest, AgentManifest) else manifest
        if profile is not None:
            body["profile"] = profile.to_dict() if isinstance(profile, AgentProfileData) else profile
        if stripe_session_id is not None:
            body["stripe_session_id"] = stripe_session_id
        if tx_hash is not None:
            body["tx_hash"] = tx_hash
        if deployer_address is not None:
            body["deployer_address"] = deployer_address
        resp = self._request("POST", "/agents/", json=body)
        resp.raise_for_status()
        return _parse_agent_response(resp.json())

    def list_my_agents(self) -> list[AgentListItem]:
        """List all agents owned by the authenticated user."""
        resp = self._request("GET", "/agents/mine")
        resp.raise_for_status()
        return [_parse_agent_list_item(a) for a in resp.json()]

    def update_agent(
        self,
        agent_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        category: str | None = None,
        service_price: float | None = None,
        status: str | None = None,
        endpoint_url: str | None = None,
        auth_tier: str | None = None,
        provider: str | None = None,
        profile: AgentProfileData | dict | None = None,
        manifest: AgentManifest | dict | None = None,
    ) -> AgentListItem:
        """Update an agent you own. Only provided fields are changed."""
        body: dict[str, Any] = {}
        for key, val in [
            ("name", name), ("description", description), ("category", category),
            ("service_price", service_price), ("status", status),
            ("endpoint_url", endpoint_url), ("auth_tier", auth_tier),
            ("provider", provider),
        ]:
            if val is not None:
                body[key] = val
        if profile is not None:
            body["profile"] = profile.to_dict() if isinstance(profile, AgentProfileData) else profile
        if manifest is not None:
            body["manifest"] = manifest.to_dict() if isinstance(manifest, AgentManifest) else manifest
        if not body:
            raise ValueError("At least one field must be provided for update")
        resp = self._request("PATCH", f"/agents/{agent_id}", json=body)
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    def update_provider_key(
        self,
        agent_id: str,
        api_key: str,
        provider: str | None = None,
    ) -> AgentListItem:
        """Rotate the provider API key for an agent you own."""
        body: dict[str, Any] = {"api_key": api_key}
        if provider is not None:
            body["provider"] = provider
        resp = self._request("PUT", f"/agents/{agent_id}/provider-key", json=body)
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    def delete_agent(self, agent_id: str) -> None:
        """Delete/delist an agent you own."""
        resp = self._request("DELETE", f"/agents/{agent_id}")
        resp.raise_for_status()

    def upload_agent_image(self, agent_id: str, image_path: str) -> AgentListItem:
        """Upload or replace an agent's profile image."""
        import os
        content_type = "image/jpeg"
        ext = os.path.splitext(image_path)[1].lower()
        if ext == ".png":
            content_type = "image/png"
        elif ext == ".webp":
            content_type = "image/webp"
        with open(image_path, "rb") as f:
            resp = self._request(
                "POST",
                f"/agents/{agent_id}/image",
                files={"file": (os.path.basename(image_path), f, content_type)},
            )
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    def delete_agent_image(self, agent_id: str) -> None:
        """Remove an agent's profile image."""
        resp = self._request("DELETE", f"/agents/{agent_id}/image")
        resp.raise_for_status()

    def create_checkout(
        self,
        type: str,
        success_url: str,
        cancel_url: str,
        *,
        agent_id: str | None = None,
        agent_name: str | None = None,
    ) -> CheckoutResponse:
        """Create a Stripe checkout session for agent launch or service purchase.

        Args:
            type: "launch" or "service"
            success_url: URL to redirect after successful payment
            cancel_url: URL to redirect if payment is cancelled
            agent_id: Agent UUID (required for type="service")
            agent_name: Agent name (optional, for type="launch")
        """
        body: dict[str, Any] = {
            "type": type,
            "success_url": success_url,
            "cancel_url": cancel_url,
        }
        if agent_id is not None:
            body["agent_id"] = agent_id
        if agent_name is not None:
            body["agent_name"] = agent_name
        resp = self._request("POST", "/payments/create-checkout", json=body)
        resp.raise_for_status()
        data = resp.json()
        return CheckoutResponse(checkout_url=data["checkout_url"], session_id=data["session_id"])

    def reserve_agent(
        self,
        name: str,
        ticker: str,
        endpoint_url: str,
        *,
        description: str | None = None,
        category: str | None = None,
        service_price: float = 5.0,
        auth_tier: str = "jwt_default",
        provider: str | None = None,
        provider_api_key: str | None = None,
        manifest: AgentManifest | dict | None = None,
        profile: AgentProfileData | dict | None = None,
        stripe_session_id: str | None = None,
    ) -> AgentResponse:
        """Reserve a ticker before on-chain deployment (3-phase launch step 1)."""
        body: dict[str, Any] = {
            "name": name,
            "ticker": ticker,
            "endpoint_url": endpoint_url,
            "service_price": service_price,
            "auth_tier": auth_tier,
        }
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if provider is not None:
            body["provider"] = provider
        if provider_api_key is not None:
            body["provider_api_key"] = provider_api_key
        if manifest is not None:
            body["manifest"] = manifest.to_dict() if isinstance(manifest, AgentManifest) else manifest
        if profile is not None:
            body["profile"] = profile.to_dict() if isinstance(profile, AgentProfileData) else profile
        if stripe_session_id is not None:
            body["stripe_session_id"] = stripe_session_id
        resp = self._request("POST", "/agents/reserve/", json=body)
        resp.raise_for_status()
        return _parse_agent_response(resp.json())

    def activate_agent(self, agent_id: str, tx_hash: str, deployer_address: str) -> AgentResponse:
        """Activate a pending agent after on-chain deployment (3-phase launch step 3)."""
        resp = self._request("POST", f"/agents/{agent_id}/activate/", json={
            "tx_hash": tx_hash,
            "deployer_address": deployer_address,
        })
        resp.raise_for_status()
        return _parse_agent_response(resp.json())

    def cancel_reservation(self, agent_id: str) -> None:
        """Cancel a pending agent reservation."""
        resp = self._request("DELETE", f"/agents/{agent_id}/reservation/")
        resp.raise_for_status()

    # --- Session REST methods ---

    def list_sessions(self, status: str | None = None) -> list[dict]:
        """List your chat sessions."""
        params: dict[str, str] = {}
        if status:
            params["status"] = status
        resp = self._request("GET", "/sessions", params=params)
        resp.raise_for_status()
        return resp.json()

    def get_session(self, session_id: str) -> dict:
        """Get a specific session."""
        resp = self._request("GET", f"/sessions/{session_id}")
        resp.raise_for_status()
        return resp.json()

    def close_session(self, session_id: str) -> dict:
        """Close an active session."""
        resp = self._request("DELETE", f"/sessions/{session_id}")
        resp.raise_for_status()
        return resp.json()

    # --- Credits ---
    # Note: streaming and chat sessions require the async client (AutxAsyncClient).

    def _parse_credit_balance(self, data: dict[str, Any]) -> CreditBalance:
        return CreditBalance(
            available_usdc=float(data["available_usdc"]),
            reserved_usdc=float(data["reserved_usdc"]),
            expires_at=data.get("expires_at"),
            last_deposit_at=data.get("last_deposit_at"),
            last_withdrawal_at=data.get("last_withdrawal_at"),
        )

    def _parse_credit_transaction(self, data: dict[str, Any]) -> CreditTransaction:
        return CreditTransaction(
            id=str(data["id"]),
            type=data["type"],
            amount=float(data["amount"]),
            session_id=data.get("session_id"),
            order_id=data.get("order_id"),
            tx_hash=data.get("tx_hash"),
            created_at=str(data["created_at"]),
        )

    def get_credit_balance(self) -> CreditBalance:
        """Get your current credit balance."""
        resp = self._request("GET", "/credits/balance")
        resp.raise_for_status()
        return self._parse_credit_balance(resp.json())

    def deposit_test_credits(self) -> CreditBalance:
        """Deposit test credits (dev/sandbox only)."""
        resp = self._request("POST", "/credits/deposit-test")
        resp.raise_for_status()
        return self._parse_credit_balance(resp.json())

    def withdraw_credits(self, amount: float) -> CreditBalance:
        """Withdraw credits. Returns updated balance."""
        resp = self._request("POST", "/credits/withdraw", json={"amount": amount})
        resp.raise_for_status()
        return self._parse_credit_balance(resp.json())

    def list_credit_transactions(self, limit: int = 50) -> list[CreditTransaction]:
        """List credit ledger transactions."""
        resp = self._request("GET", "/credits/transactions", params={"limit": limit})
        resp.raise_for_status()
        return [self._parse_credit_transaction(t) for t in resp.json()]


class AutxAsyncClient:
    """Async AUTX API client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ):
        if not api_key.startswith("autx_live_"):
            raise ValueError("API key must start with 'autx_live_'")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}

    async def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        import asyncio
        url = f"{self.base_url}{path}"
        last_exc = None
        for attempt in range(self.max_retries):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    resp = await client.request(method, url, headers=self._headers(), **kwargs)
                    if resp.status_code == 429:
                        retry_after = int(resp.headers.get("Retry-After", "5"))
                        await asyncio.sleep(retry_after)
                        continue
                    return resp
            except httpx.TimeoutException as e:
                last_exc = e
                await asyncio.sleep(RETRY_BACKOFF * (attempt + 1))
            except httpx.HTTPError as e:
                last_exc = e
                break
        raise last_exc or RuntimeError("Request failed after retries")

    # --- Buyer methods ---

    async def proxy(self, ticker_or_id: str, prompt: str | None = None, body: dict | None = None) -> ProxyResponse:
        json_body = body or {"prompt": prompt}
        resp = await self._request("POST", f"/proxy/{ticker_or_id}", json=json_body)
        resp.raise_for_status()
        return ProxyResponse(
            content=resp.content,
            status_code=resp.status_code,
            content_type=resp.headers.get("content-type", ""),
            headers=dict(resp.headers),
            request_id=resp.headers.get("x-autx-request-id", ""),
            latency_ms=int(resp.headers.get("x-autx-latency-ms", "0")),
            agent_ticker=resp.headers.get("x-autx-agent", ""),
        )

    async def order(
        self,
        agent_id: str,
        prompt: str,
        payment_method: str = "stripe",
        files: list[tuple[str, bytes]] | None = None,
    ) -> OrderResponse:
        if files:
            multipart = [
                ("agent_id", (None, agent_id)),
                ("prompt", (None, prompt)),
                ("payment_method", (None, payment_method)),
            ]
            for fname, content in files:
                multipart.append(("files", (fname, content, "application/octet-stream")))
            resp = await self._request("POST", "/orders/multipart", files=multipart)
        else:
            resp = await self._request("POST", "/orders/", json={
                "agent_id": agent_id,
                "prompt": prompt,
                "payment_method": payment_method,
            })
        resp.raise_for_status()
        data = resp.json()
        return OrderResponse(
            id=data["id"],
            agent_id=data["agent_id"],
            status=data["status"],
            amount_paid=data["amount_paid"],
            platform_fee=data["platform_fee"],
            created_at=data["created_at"],
        )

    async def get_order(self, order_id: str) -> OrderResult:
        resp = await self._request("GET", f"/orders/{order_id}")
        resp.raise_for_status()
        data = resp.json()
        return OrderResult(
            id=data["id"],
            status=data["status"],
            output_hash=data.get("output_hash"),
            output_text=data.get("output_text"),
            completed_at=data.get("completed_at"),
        )

    async def list_agents(
        self,
        category: str | None = None,
        sort: str = "revenue",
        limit: int | None = None,
        offset: int | None = None,
        search: str | None = None,
        status: str | None = None,
    ) -> list[AgentListItem]:
        params: dict[str, str] = {"sort": sort}
        if category:
            params["category"] = category
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        if search:
            params["search"] = search
        if status:
            params["status"] = status
        resp = await self._request("GET", "/agents/", params=params)
        resp.raise_for_status()
        return [_parse_agent_list_item(a) for a in resp.json()]

    async def get_agent(self, agent_id: str) -> AgentListItem:
        """Get an agent by UUID."""
        resp = await self._request("GET", f"/agents/{agent_id}")
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    async def get_agent_by_ticker(self, ticker: str) -> AgentListItem:
        """Get an agent by ticker symbol."""
        resp = await self._request("GET", f"/agents/ticker/{ticker}")
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    async def check_ticker(self, ticker: str) -> TickerCheckResult:
        """Check if a ticker is available."""
        resp = await self._request("GET", f"/agents/check-ticker/{ticker}")
        resp.raise_for_status()
        data = resp.json()
        return TickerCheckResult(available=data["available"], ticker=ticker)

    async def check_name(self, name: str) -> NameCheckResult:
        """Check if an agent name is available."""
        resp = await self._request("GET", f"/agents/check-name/{name}")
        resp.raise_for_status()
        data = resp.json()
        return NameCheckResult(available=data["available"], name=name)

    async def list_orders(
        self,
        agent_id: str | None = None,
        status: str | None = None,
    ) -> list[OrderListItem]:
        """List your orders with optional filters."""
        params: dict[str, str] = {}
        if agent_id:
            params["agent_id"] = agent_id
        if status:
            params["status"] = status
        resp = await self._request("GET", "/orders/", params=params)
        resp.raise_for_status()
        return [_parse_order_list_item(o) for o in resp.json()]

    # --- Publisher methods ---

    async def create_agent(
        self,
        name: str,
        ticker: str,
        endpoint_url: str,
        *,
        description: str | None = None,
        category: str | None = None,
        service_price: float = 5.0,
        auth_tier: str = "jwt_default",
        provider: str | None = None,
        provider_api_key: str | None = None,
        manifest: AgentManifest | dict | None = None,
        profile: AgentProfileData | dict | None = None,
        stripe_session_id: str | None = None,
        tx_hash: str | None = None,
        deployer_address: str | None = None,
    ) -> AgentResponse:
        """Register a new agent on the AUTX marketplace."""
        body: dict[str, Any] = {
            "name": name,
            "ticker": ticker,
            "endpoint_url": endpoint_url,
            "service_price": service_price,
            "auth_tier": auth_tier,
        }
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if provider is not None:
            body["provider"] = provider
        if provider_api_key is not None:
            body["provider_api_key"] = provider_api_key
        if manifest is not None:
            body["manifest"] = manifest.to_dict() if isinstance(manifest, AgentManifest) else manifest
        if profile is not None:
            body["profile"] = profile.to_dict() if isinstance(profile, AgentProfileData) else profile
        if stripe_session_id is not None:
            body["stripe_session_id"] = stripe_session_id
        if tx_hash is not None:
            body["tx_hash"] = tx_hash
        if deployer_address is not None:
            body["deployer_address"] = deployer_address
        resp = await self._request("POST", "/agents/", json=body)
        resp.raise_for_status()
        return _parse_agent_response(resp.json())

    async def list_my_agents(self) -> list[AgentListItem]:
        """List all agents owned by the authenticated user."""
        resp = await self._request("GET", "/agents/mine")
        resp.raise_for_status()
        return [_parse_agent_list_item(a) for a in resp.json()]

    async def update_agent(
        self,
        agent_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        category: str | None = None,
        service_price: float | None = None,
        status: str | None = None,
        endpoint_url: str | None = None,
        auth_tier: str | None = None,
        provider: str | None = None,
        profile: AgentProfileData | dict | None = None,
        manifest: AgentManifest | dict | None = None,
    ) -> AgentListItem:
        """Update an agent you own. Only provided fields are changed."""
        body: dict[str, Any] = {}
        for key, val in [
            ("name", name), ("description", description), ("category", category),
            ("service_price", service_price), ("status", status),
            ("endpoint_url", endpoint_url), ("auth_tier", auth_tier),
            ("provider", provider),
        ]:
            if val is not None:
                body[key] = val
        if profile is not None:
            body["profile"] = profile.to_dict() if isinstance(profile, AgentProfileData) else profile
        if manifest is not None:
            body["manifest"] = manifest.to_dict() if isinstance(manifest, AgentManifest) else manifest
        if not body:
            raise ValueError("At least one field must be provided for update")
        resp = await self._request("PATCH", f"/agents/{agent_id}", json=body)
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    async def update_provider_key(
        self,
        agent_id: str,
        api_key: str,
        provider: str | None = None,
    ) -> AgentListItem:
        """Rotate the provider API key for an agent you own."""
        body: dict[str, Any] = {"api_key": api_key}
        if provider is not None:
            body["provider"] = provider
        resp = await self._request("PUT", f"/agents/{agent_id}/provider-key", json=body)
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    async def delete_agent(self, agent_id: str) -> None:
        """Delete/delist an agent you own."""
        resp = await self._request("DELETE", f"/agents/{agent_id}")
        resp.raise_for_status()

    async def upload_agent_image(self, agent_id: str, image_data: bytes, filename: str = "image.jpg") -> AgentListItem:
        """Upload or replace an agent's profile image."""
        content_type = "image/jpeg"
        if filename.endswith(".png"):
            content_type = "image/png"
        elif filename.endswith(".webp"):
            content_type = "image/webp"
        resp = await self._request(
            "POST",
            f"/agents/{agent_id}/image",
            files={"file": (filename, image_data, content_type)},
        )
        resp.raise_for_status()
        return _parse_agent_list_item(resp.json())

    async def delete_agent_image(self, agent_id: str) -> None:
        """Remove an agent's profile image."""
        resp = await self._request("DELETE", f"/agents/{agent_id}/image")
        resp.raise_for_status()

    async def create_checkout(
        self,
        type: str,
        success_url: str,
        cancel_url: str,
        *,
        agent_id: str | None = None,
        agent_name: str | None = None,
    ) -> CheckoutResponse:
        """Create a Stripe checkout session for agent launch or service purchase.

        Args:
            type: "launch" or "service"
            success_url: URL to redirect after successful payment
            cancel_url: URL to redirect if payment is cancelled
            agent_id: Agent UUID (required for type="service")
            agent_name: Agent name (optional, for type="launch")
        """
        body: dict[str, Any] = {
            "type": type,
            "success_url": success_url,
            "cancel_url": cancel_url,
        }
        if agent_id is not None:
            body["agent_id"] = agent_id
        if agent_name is not None:
            body["agent_name"] = agent_name
        resp = await self._request("POST", "/payments/create-checkout", json=body)
        resp.raise_for_status()
        data = resp.json()
        return CheckoutResponse(checkout_url=data["checkout_url"], session_id=data["session_id"])

    async def reserve_agent(
        self,
        name: str,
        ticker: str,
        endpoint_url: str,
        *,
        description: str | None = None,
        category: str | None = None,
        service_price: float = 5.0,
        auth_tier: str = "jwt_default",
        provider: str | None = None,
        provider_api_key: str | None = None,
        manifest: AgentManifest | dict | None = None,
        profile: AgentProfileData | dict | None = None,
        stripe_session_id: str | None = None,
    ) -> AgentResponse:
        """Reserve a ticker before on-chain deployment (3-phase launch step 1)."""
        body: dict[str, Any] = {
            "name": name,
            "ticker": ticker,
            "endpoint_url": endpoint_url,
            "service_price": service_price,
            "auth_tier": auth_tier,
        }
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if provider is not None:
            body["provider"] = provider
        if provider_api_key is not None:
            body["provider_api_key"] = provider_api_key
        if manifest is not None:
            body["manifest"] = manifest.to_dict() if isinstance(manifest, AgentManifest) else manifest
        if profile is not None:
            body["profile"] = profile.to_dict() if isinstance(profile, AgentProfileData) else profile
        if stripe_session_id is not None:
            body["stripe_session_id"] = stripe_session_id
        resp = await self._request("POST", "/agents/reserve/", json=body)
        resp.raise_for_status()
        return _parse_agent_response(resp.json())

    async def activate_agent(self, agent_id: str, tx_hash: str, deployer_address: str) -> AgentResponse:
        """Activate a pending agent after on-chain deployment (3-phase launch step 3)."""
        resp = await self._request("POST", f"/agents/{agent_id}/activate/", json={
            "tx_hash": tx_hash,
            "deployer_address": deployer_address,
        })
        resp.raise_for_status()
        return _parse_agent_response(resp.json())

    async def cancel_reservation(self, agent_id: str) -> None:
        """Cancel a pending agent reservation."""
        resp = await self._request("DELETE", f"/agents/{agent_id}/reservation/")
        resp.raise_for_status()

    # --- Session REST methods ---

    async def list_sessions(self, status: str | None = None) -> list[dict]:
        """List your chat sessions."""
        params: dict[str, str] = {}
        if status:
            params["status"] = status
        resp = await self._request("GET", "/sessions", params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_session(self, session_id: str) -> dict:
        """Get a specific session."""
        resp = await self._request("GET", f"/sessions/{session_id}")
        resp.raise_for_status()
        return resp.json()

    async def close_session(self, session_id: str) -> dict:
        """Close an active session."""
        resp = await self._request("DELETE", f"/sessions/{session_id}")
        resp.raise_for_status()
        return resp.json()

    # --- Streaming ---

    def _ws_url(self) -> str:
        """Convert the HTTP base URL to a WebSocket base URL."""
        return self.base_url.replace("https://", "wss://").replace("http://", "ws://")

    async def stream(self, ticker_or_id: str, prompt: str) -> AsyncGenerator[str, None]:
        """Stream a single completion over WebSocket. Yields text chunks.

        Args:
            ticker_or_id: Agent ticker symbol or UUID.
            prompt: Text prompt to send.

        Yields:
            Decoded text chunks as they arrive from the agent.

        Raises:
            Exception: If authentication fails or the agent returns an error.
        """
        import websockets

        ws_url = f"{self._ws_url()}/ws/agent/{ticker_or_id}"
        async with websockets.connect(ws_url) as ws:
            await ws.send(json.dumps({"type": "auth", "token": f"Bearer {self.api_key}"}))
            session_msg = json.loads(await ws.recv())
            if session_msg.get("type") == "error":
                raise Exception(session_msg.get("message", "Auth failed"))

            await ws.send(json.dumps({"type": "message", "prompt": prompt}))

            while True:
                raw = await ws.recv()
                msg = json.loads(raw)
                if msg["type"] == "chunk":
                    yield msg["data"]
                elif msg["type"] == "done":
                    break
                elif msg["type"] == "error":
                    raise Exception(msg.get("message", "Stream error"))
                # heartbeat and billing messages are silently skipped

            await ws.send(json.dumps({"type": "close"}))

    def session(self, ticker_or_id: str) -> "_AsyncChatSessionContext":
        """Open a multi-turn chat session over WebSocket.

        Usage::

            async with client.session("MYAGENT") as chat:
                async for chunk in chat.message("Hello"):
                    print(chunk, end="", flush=True)
                async for chunk in chat.message("Follow-up question"):
                    print(chunk, end="", flush=True)

        Args:
            ticker_or_id: Agent ticker symbol or UUID.

        Returns:
            Async context manager that yields an AsyncChatSession.
        """
        return _AsyncChatSessionContext(self, ticker_or_id)

    # --- Credits ---

    def _parse_credit_balance(self, data: dict[str, Any]) -> CreditBalance:
        return CreditBalance(
            available_usdc=float(data["available_usdc"]),
            reserved_usdc=float(data["reserved_usdc"]),
            expires_at=data.get("expires_at"),
            last_deposit_at=data.get("last_deposit_at"),
            last_withdrawal_at=data.get("last_withdrawal_at"),
        )

    def _parse_credit_transaction(self, data: dict[str, Any]) -> CreditTransaction:
        return CreditTransaction(
            id=str(data["id"]),
            type=data["type"],
            amount=float(data["amount"]),
            session_id=data.get("session_id"),
            order_id=data.get("order_id"),
            tx_hash=data.get("tx_hash"),
            created_at=str(data["created_at"]),
        )

    async def get_credit_balance(self) -> CreditBalance:
        """Get your current credit balance."""
        resp = await self._request("GET", "/credits/balance")
        resp.raise_for_status()
        return self._parse_credit_balance(resp.json())

    async def deposit_test_credits(self) -> CreditBalance:
        """Deposit test credits (dev/sandbox only)."""
        resp = await self._request("POST", "/credits/deposit-test")
        resp.raise_for_status()
        return self._parse_credit_balance(resp.json())

    async def withdraw_credits(self, amount: float) -> CreditBalance:
        """Withdraw credits. Returns updated balance."""
        resp = await self._request("POST", "/credits/withdraw", json={"amount": amount})
        resp.raise_for_status()
        return self._parse_credit_balance(resp.json())

    async def list_credit_transactions(self, limit: int = 50) -> list[CreditTransaction]:
        """List credit ledger transactions."""
        resp = await self._request("GET", "/credits/transactions", params={"limit": limit})
        resp.raise_for_status()
        return [self._parse_credit_transaction(t) for t in resp.json()]


class AsyncChatSession:
    """Multi-turn chat session over a persistent WebSocket connection.

    Obtain via ``async with client.session("TICKER") as chat:``.
    Do not instantiate directly.
    """

    def __init__(self, ws: Any, session_info: SessionInfo):
        self._ws = ws
        self.info = session_info

    async def message(self, prompt: str) -> AsyncGenerator[str, None]:
        """Send a message and yield streamed response chunks.

        Args:
            prompt: Text to send to the agent.

        Yields:
            Decoded text chunks as they arrive.

        Raises:
            Exception: If the agent returns an error message.
        """
        await self._ws.send(json.dumps({"type": "message", "prompt": prompt}))
        while True:
            raw = await self._ws.recv()
            msg = json.loads(raw)
            if msg["type"] == "chunk":
                yield msg["data"]
            elif msg["type"] == "done":
                break
            elif msg["type"] == "error":
                raise Exception(msg.get("message", "Stream error"))
            # heartbeat and billing messages are silently skipped

    async def close(self) -> None:
        """Gracefully close the WebSocket session."""
        await self._ws.send(json.dumps({"type": "close"}))
        await self._ws.close()


class _AsyncChatSessionContext:
    """Internal async context manager returned by ``AutxAsyncClient.session()``."""

    def __init__(self, client: AutxAsyncClient, ticker_or_id: str):
        self._client = client
        self._ticker_or_id = ticker_or_id
        self._ws = None
        self._chat: AsyncChatSession | None = None

    async def __aenter__(self) -> AsyncChatSession:
        import websockets

        ws_url = f"{self._client._ws_url()}/ws/agent/{self._ticker_or_id}"
        self._ws = await websockets.connect(ws_url)
        await self._ws.send(json.dumps({"type": "auth", "token": f"Bearer {self._client.api_key}"}))
        session_msg = json.loads(await self._ws.recv())
        if session_msg.get("type") == "error":
            await self._ws.close()
            raise Exception(session_msg.get("message", "Auth failed"))

        info = SessionInfo(
            session_id=session_msg.get("session_id", ""),
            agent_id=session_msg.get("agent_id", ""),
            agent_name=session_msg.get("agent_name", ""),
            agent_ticker=session_msg.get("agent_ticker", ""),
            service_price=float(session_msg.get("service_price", 0)),
            credits_reserved=float(session_msg.get("credits_reserved", 0)),
        )
        self._chat = AsyncChatSession(self._ws, info)
        return self._chat

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._chat is not None:
            try:
                await self._chat.close()
            except Exception:
                pass
        elif self._ws is not None:
            try:
                await self._ws.close()
            except Exception:
                pass
