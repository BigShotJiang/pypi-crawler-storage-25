"""DiagnosePrReport assembly + JSON serialisation.

Week 1 skeleton: trivial ship-or-probe verdict from a flat
`affected_trace_ids` set.

Week 2 (this version): real verdict from
`shadow.diagnose_pr.risk.classify_verdict`, taking a list of
`TraceDiagnosis` directly so the per-trace state (worst_axis,
first_divergence, policy_violations) flows through to the JSON.

The Week 1 entry point — `build_report(... affected_trace_ids=)` —
is preserved so existing callers (and tests) keep working. The new
Week 2 entry point is `build_report(... diagnoses=)`.
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import asdict

from shadow.diagnose_pr import SCHEMA_VERSION
from shadow.diagnose_pr.loaders import LoadedTrace
from shadow.diagnose_pr.models import (
    CauseEstimate,
    ConfigDelta,
    DiagnosePrReport,
    TraceDiagnosis,
)
from shadow.diagnose_pr.risk import classify_verdict

_LOW_POWER_THRESHOLD = 30


def build_report(
    *,
    traces: list[LoadedTrace],
    deltas: list[ConfigDelta],
    diagnoses: list[TraceDiagnosis] | None = None,
    affected_trace_ids: set[str] | None = None,
    new_policy_violations: int = 0,
    worst_policy_rule: str | None = None,
    has_dangerous_violation: bool = False,
    has_severe_axis: bool = False,
    top_causes: list[CauseEstimate] | None = None,
    dominant_cause: CauseEstimate | None = None,
    suggested_fix: str | None = None,
    extra_flags: list[str] | None = None,
) -> DiagnosePrReport:
    """Assemble a DiagnosePrReport.

    Two call modes for the per-trace state:

      * Week 2+ path: pass `diagnoses=[TraceDiagnosis, ...]` already
        carrying per-trace `affected`, `worst_axis`, etc. The
        verdict is computed from those + the policy/axis flags.

      * Week 1 path: pass `affected_trace_ids={...}`. We build
        skeleton TraceDiagnosis entries (no per-trace detail) so
        the JSON shape is uniform.

    Week 3 adds three new optional kwargs — `top_causes`,
    `dominant_cause`, `suggested_fix` — populated by
    `shadow.diagnose_pr.attribution`. When omitted, all three stay
    at v0.1 defaults (empty list / None / None).

    Exactly one of `diagnoses` / `affected_trace_ids` must be
    supplied; passing both raises a ValueError.
    """
    del deltas  # caller pre-extracted; we don't store deltas in the report

    if diagnoses is not None and affected_trace_ids is not None:
        raise ValueError("pass exactly one of `diagnoses` or `affected_trace_ids`")

    if diagnoses is None:
        ids = affected_trace_ids or set()
        diagnoses = [
            TraceDiagnosis(
                trace_id=t.trace_id,
                affected=t.trace_id in ids,
                risk=0.0,
                worst_axis=None,
                first_divergence=None,
                policy_violations=[],
            )
            for t in traces
        ]

    total = len(traces)
    affected_trace_set = {d.trace_id for d in diagnoses if d.affected}
    affected = len(affected_trace_set)
    blast_radius = (affected / total) if total > 0 else 0.0

    verdict = classify_verdict(
        affected=affected,
        total=total,
        has_dangerous_violation=has_dangerous_violation,
        has_severe_axis=has_severe_axis,
    )

    flags: list[str] = []
    if 0 < total < _LOW_POWER_THRESHOLD:
        flags.append("low_power")
    if extra_flags:
        # De-dupe while preserving order; extra flags come after
        # the structural ones so the renderer can rank them.
        for f in extra_flags:
            if f not in flags:
                flags.append(f)

    return DiagnosePrReport(
        schema_version=SCHEMA_VERSION,
        verdict=verdict,
        total_traces=total,
        affected_traces=affected,
        blast_radius=blast_radius,
        dominant_cause=dominant_cause,
        top_causes=list(top_causes) if top_causes else [],
        trace_diagnoses=diagnoses,
        affected_trace_ids=sorted(affected_trace_set),
        new_policy_violations=new_policy_violations,
        worst_policy_rule=worst_policy_rule,
        suggested_fix=suggested_fix,
        flags=flags,
    )


def to_json(report: DiagnosePrReport, *, indent: int = 2) -> str:
    """Serialise a report with sorted keys (so PR-side diffs are
    minimal) and the requested indent.

    Adds two top-level boolean fields that mirror the most-consequential
    entries in `flags`: `is_synthetic` (true when the run used
    `--backend mock`) and `low_statistical_power` (true when the sample
    is too small for stable CIs). Both are derivable from `flags`, but
    machine consumers (CI pipelines, dashboards) shouldn't have to
    string-match a list — a top-level boolean is the right shape for
    "do I treat this verdict as authoritative?" decisions.
    """
    payload = asdict(report)
    flags = payload.get("flags") or []
    payload["is_synthetic"] = "synthetic_mock" in flags
    payload["low_statistical_power"] = "low_power" in flags
    return json.dumps(payload, sort_keys=True, indent=indent, ensure_ascii=False)


def report_from_traces_and_deltas(
    traces: list[LoadedTrace],
    deltas: list[ConfigDelta],
    *,
    affected: Iterable[str] = (),
) -> DiagnosePrReport:
    """Convenience wrapper used by the Week 1 skeleton CLI. Accepts
    an iterable of trace ids for the affected set."""
    return build_report(
        traces=traces,
        deltas=deltas,
        affected_trace_ids=set(affected),
    )


__all__ = [
    "build_report",
    "report_from_traces_and_deltas",
    "to_json",
]
