# simplibs

This package serves as the **namespace root** for the `simplibs` ecosystem.

It does not contain any code of its own. Its purpose is to reserve the
`simplibs` namespace on PyPI, so that all ecosystem packages can be
imported under a unified `simplibs.*` prefix.

## Installation

Install individual packages based on what you need:
```bash
pip install simplibs-exception
pip install simplibs-signature
```

Then import them together under one roof:
```python
from simplibs.exception import SimpleException
from simplibs.signature import SimpleSignature
```

## About the Simple ecosystem

The **simplibs** ecosystem is a collection of small, self-contained Python
libraries. Each one solves exactly one thing — but all of them share a common
philosophy:

**Dyslexia-friendly** — minimise mental load. Atomise code into self-contained
units, name files after the logic they contain, write explanations that describe
*why* — not just *what*.

**Programmer's zen** — nothing should be missing and nothing should be
superfluous. The journey is the destination: code should be fully understood;
better to go slowly and correctly than quickly and with mistakes. The
crystallisation approach — not perfection on the first try, but gradual
refinement towards it.

**Defensive style** — anticipate all possible failure modes so that only safe
paths remain. Never raise unexpected errors; degrade gracefully.

**Minimalism** — find the path to the goal in as few steps as possible, but
leave nothing out. Each file has one responsibility.

**Code as craft** — code should be pleasant to look at and evoke a sense of
harmony. Treat code as a small work of art — like a carpenter carving a
sculpture. Optimise for the user: everything should make sense without having
to study the documentation at length.

These are aspirations — a sense of direction. And that is exactly what the
note about the journey becoming the destination is all about. 🙂

---

*Individual packages are covered by tests across all modules — unit tests and
integration tests alike. Tests are part of each repository and serve as living
documentation of the expected behaviour.*