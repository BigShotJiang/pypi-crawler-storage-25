"""Command-line interface for pytola."""

from __future__ import annotations

import argparse
import logging

from . import __version__

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)


def parse_args() -> tuple[argparse.Namespace, argparse.ArgumentParser]:
    parser = argparse.ArgumentParser(description="Pytola CLI")
    parser.add_argument("--version", "-v", action="version", version=f"Pytola CLI {__version__}", help="Show version")
    return parser.parse_args(), parser


def main() -> None:
    """Run entry point for the command-line interface.

    Command-line interface for pytola

    Examples
    --------
    cli [options] <arguments>
    """
    _, parser = parse_args()

    parser.print_help()
