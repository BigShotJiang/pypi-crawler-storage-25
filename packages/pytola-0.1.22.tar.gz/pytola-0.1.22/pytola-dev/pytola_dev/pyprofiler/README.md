# PyProfiler

非侵入式 Python 代码性能分析工具，生成 HTML 报告。

## 功能特性

- **非侵入式分析**：无需修改目标代码即可收集性能数据
- **HTML 报告**：生成美观的交互式 HTML 报告
- **灵活运行**：支持脚本和模块两种运行方式
- **加载已有数据**：可加载 `.prof`/`.pstats` 文件生成报告
- **自定义排序**：支持按总时间、累计时间、调用次数排序
- **调用关系展示**：显示函数的调用者和被调用者信息

## 安装

```bash
pip install pyprofiler
```

## 使用方法

### 分析 Python 脚本

```bash
pyprofiler run script.py
pyprofiler run script.py arg1 arg2
```

### 分析 Python 模块

```bash
pyprofiler run -m json.tool --help
pyprofiler run -m http.server 8000
```

### 加载已有的性能数据文件

```bash
pyprofiler load profile.prof
```

### 常用选项

```bash
# 指定输出文件
pyprofiler run script.py -o report.html

# 只显示前 N 个热点函数
pyprofiler run script.py --top 20

# 按累计耗时排序
pyprofiler run script.py --sort-by cumtime

# 不自动打开浏览器
pyprofiler run script.py --no-open

# 启用调试日志
pyprofiler run script.py --debug
```

## 输出示例

运行后会生成 HTML 报告，包含：

- **总体统计**：总调用次数、非递归调用次数、总运行时间、唯一函数数量
- **热点函数排行**：按指定字段排序的函数性能排行榜
- **时间分布柱状图**：可视化展示各函数的时间占用比例
- **详细函数列表**：所有函数的完整性能数据
- **调用关系**：每个函数的调用者和被调用者信息

## 技术栈

- Python 3.8+
- cProfile (内置)
- pstats (内置)
- Jinja2 (模板引擎)

## 命令行接口

```text
pyprofiler run script.py [args...]     运行并分析 Python 脚本
pyprofiler run -m module [args...]     运行并分析 Python 模块
pyprofiler load file.prof              加载已有的性能数据文件

通用选项:
  -o, --output         输出 HTML 文件路径 (默认：profile_report.html)
  --no-open           生成后不自动打开浏览器
  --top N             函数排行表显示前 N 个 (默认：50)
  --sort-by FIELD     默认排序字段 (tottime/cumtime/calls)
  --debug             启用调试日志
```

## 许可证

MIT License
