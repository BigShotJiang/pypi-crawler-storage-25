from generic_llm_memorizer.llm_memorizer import LLMMemorizer


def test_init_from_memory():
    # Create an async lambda that returns a coroutine
    async def mock_llm_call(user_id, system_prompt, Fact):
        return Fact()

    memorizer = LLMMemorizer(
        user_id="user_123",
        session_id="session_123",
        llm_call=mock_llm_call,
    )

    assert memorizer.user_id == "user_123"
    assert memorizer.session_id == "session_123"
    print(memorizer.memory)
    assert len(memorizer.memory.facts) >= 0
    assert memorizer.memory.user.user_id == "user_123"


if __name__ == "__main__":
    test_init_from_memory()
