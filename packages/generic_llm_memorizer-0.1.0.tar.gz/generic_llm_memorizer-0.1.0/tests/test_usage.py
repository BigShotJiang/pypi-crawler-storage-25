"""
Example usage of the generic llm_call function with Pydantic models.
"""

from typing import Type, TypeVar

from pydantic import BaseModel

from generic_llm_memorizer.conversation import Conversation

# Import our models
from generic_llm_memorizer.memory import Memory, Summary

# Define a generic type variable bounded by BaseModel
T = TypeVar("T", bound=BaseModel)


def example_llm_call(prompt: str, model_class: Type[T]) -> T:
    """
    Example implementation of a generic LLM call function.

    In a real implementation, this would call an actual LLM API
    and parse the response into the specified Pydantic model.

    Args:
        prompt: The prompt to send to the LLM
        model_class: The Pydantic model class to parse the response into

    Returns:
        An instance of the specified model_class
    """
    # This is a mock implementation - in reality you would call an LLM API here
    print(f"Calling LLM with prompt: {prompt}")

    # Mock responses based on the expected model type
    if model_class == Summary:
        mock_response = {"content": "This is a mock summary of the conversation."}
    elif model_class == Memory:
        mock_response = {
            "user": {
                "user_id": "user_123",
                "name": "John Doe",
                "preferences": [],
            },
            "facts": [
                {
                    "content": "John Doe is a software engineer",
                    "kind": "professional",
                    "timestamp": "2023-01-01T10:00:00Z",
                    "validity": "forever",
                }
            ],
        }
    else:
        # For any other Pydantic model, return a generic mock response
        mock_response = {}

    # Parse and return the response as the specified model type
    return model_class(**mock_response)


def test_main():
    # Create a conversation
    conversation = Conversation(
        session_id="s434", system_prompt="You are a helpful assistant"
    )

    # Add some messages
    conversation.add_user_message(
        "Hello, my name is John Doe and I'm a software engineer"
    )
    conversation.add_assistant_message(
        "Nice to meet you John! How can I help you today?"
    )
    conversation.add_user_message("Can you tell me what you know about me?")

    # Example 1: Using llm_call with Summary model
    summary = example_llm_call(
        "Summarize this conversation: " + str(conversation.to_dict()), Summary
    )
    print(f"Summary: {summary.content}")

    # Example 2: Using llm_call with Memory model
    memory = example_llm_call(
        "Extract facts from this conversation: " + str(conversation.to_dict()), Memory
    )
    print(f"Memory with {len(memory.facts)} facts:")
    for fact in memory.facts:
        print(f"  - {fact.content} ({fact.kind})")
        assert fact.content is not None
    assert len(memory.facts) == 1


if __name__ == "__main__":
    test_main()
