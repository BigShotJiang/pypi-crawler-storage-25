from time import time
from typing import TypeVar

import pytest
from pydantic import BaseModel
from pydantic_ai.agent import Agent

from generic_llm_memorizer.conversation import Conversation, Message
from generic_llm_memorizer.llm_memorizer import LLMMemorizer
from tests.llms import GEMMA4, MINIMAX_CLOUD, NEMOTRON, QWEN35_CLOUD

T = TypeVar("T", bound=BaseModel)


async def build_llm_call(agent: Agent):

    async def func(prompt: str, system_prompt: str, response_model: type[T]) -> T:
        @agent.system_prompt
        def get_system_prompt() -> str:
            return system_prompt

        res = await agent.run(user_prompt=prompt, output_type=response_model)
        return res.output

    return func


@pytest.mark.asyncio
async def test_with_agent():
    agent = Agent(model=QWEN35_CLOUD, retries=5)
    llm_call = await build_llm_call(agent)
    conversation = Conversation(session_id="s66")
    conversation.add_messages(
        [
            Message(content="Quelle est la météo en Italie en juillet ?", role="user"),
            Message(
                content="""En juillet, l'Italie connaît généralement un climat très chaud et sec. C'est le cœur de l'été, avec des températures élevées surtout dans le sud et les plaines,
    tandis que les zones montagneuses comme les Alpes et les Apennins restent plus fraîches et tempérées.""",
                role="assistant",
            ),
            Message(
                content="""Est-ce qu'il y a beaucoup de pluie à cette période ?""",
                role="user",
            ),
            Message(
                content="""Non, juillet est l'un des mois les plus secs de l'année en Italie. Bien que des orages occasionnels puissent survenir, particulièrement dans le nord ou en
    montagne, la majorité du pays bénéficie d'un ensoleillement maximal.""",
                role="assistant",
            ),
        ]
    )
    # conversation.add_messages(
    #     [
    #         Message(
    #             role="user",
    #             content="Bonjour ! J'ai besoin de l'aide d'un expert pour planifier un grand voyage. C'est une aventure qui doit être parfaite.",
    #         ),
    #         Message(
    #             role="assistant",
    #             content="Bonjour ! Je serais ravi de vous aider à organiser votre aventure. Pour commencer, pouvez-vous me donner une idée de la destination et des dates approximatives ?",
    #         ),
    #         Message(
    #             role="user",
    #             content="On pense aller en Italie, spécifiquement dans le centre. Nous prévoyons d'y être pendant 8 jours, idéalement à la fin de l'automne.",
    #         ),
    #         Message(
    #             content="""L'Italie est un excellent choix pour cette saison ! L'automne y est magnifique. Avez-vous déjà une idée des villes spécifiques que vous aimeriez voir, ou des centres
    #         d'intérêt (art, nature, gastronomie, histoire) ?""",
    #             role="assistant",
    #         ),
    #         Message(
    #             role="user",
    #             content="""Nos centres d'intérêt sont surtout l'histoire et la gastronomie. On rêve de visiter Rome et peut-être Florence, mais est-ce qu'on peut en faire plusieurs villes sans que
    # ça soit trop de transport ?""",
    #         ),
    #         Message(
    #             content="""C'est tout à fait faisable ! Rome et Florence sont un duo classique et complémentaire. Entre les deux, vous aurez un mélange parfait d'histoire antique et de Renaissance.
    #         Est-ce que vous avez une idée du budget approximatif pour ce voyage ?""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""Nous avons un budget moyen à élevé. On préfère être dans des hébergements de bonne qualité, mais on est flexibles si ça fait gagner du temps. On voyage en groupe de
    #         quatre adultes.""",
    #             role="user",
    #         ),
    #         Message(
    #             content="""Parfait. Pour optimiser le temps, je suggère de dédier 4 jours pleins à Rome et 4 jours pleins à Florence, en y ajoutant un jour de transit ou d'excursion au milieu,
    #         comme Orvieto ou Sienne. Qu'en pensez-vous ?""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""Ça sonne bien. Passer par Sienne, c'est une excellente idée pour casser le rythme ! Donc, l'itinéraire serait : Rome -> Sienne (ou autre) -> Florence. Est-ce que ça
    #             implique beaucoup de trains ? Je ne suis pas très à l'aise avec les longs trajets.""",
    #             role="user",
    #         ),
    #         Message(
    #             content="""Les trains à grande vitesse en Italie (Trenitalia ou Italo) sont très efficaces, rapides et souvent très agréables. Le trajet Rome-Sienne-Florence est gérable en une
    #             journée. Préférez-vous un transfert privé entre les villes pour plus de confort, même si cela coûte plus cher ?""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""Non, les trains nous iront bien. On est plutôt aventuriers et on veut s'imprégner de l'atmosphère locale. Par contre, niveau logement, on aimerait être dans des quartiers
    #                 piétonniers ou calmes le soir.""",
    #             role="user",
    #         ),
    #         Message(
    #             content="""Compris. Pour les quartiers, je recommande Trastevere à Rome pour l'ambiance et le centre historique de Florence (Oltrarno) pour une ambiance plus artisanale et calme.
    #                 Maintenant, parlons activités spécifiques. Pour Rome, qu'est-ce qui est incontournable pour un amateur d'histoire ?""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""Le Colisée, bien sûr, c'est un must. Mais on aimerait aussi voir des sites moins touristiques, genre des musées ou des quartiers résidentiels qui montrent la vie romaine
    #                 passée.""",
    #             role="user",
    #         ),
    #         Message(
    #             content="""Je vous recommande fortement les Musées du Vatican (y compris la Chapelle Sixtine), et pourquoi pas une promenade dans le quartier du Mont Palatin, qui est souvent moins
    #                 bondé et offre des vues superbes. Pour Florence, en plus de la Galerie des Médicis, je suggère une visite des ateliers d'artisans de la maroquinerie. Ça combine art et savoir-faire
    #                 local.""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""Ça me plaît beaucoup ! Et pour la gastronomie ? On rêve de déguster des plats typiques, mais sans tomber dans les pièges à touristes. Avez-vous des adresses ou des types
    #                 d'expériences à me suggérer ?""",
    #             role="user",
    #         ),
    #         Message(
    #             content="""Absolument. À Rome, cherchez les 'trattorias' dans le Trastevere, pas dans les places principales. Essayez les plats à base de pâtes cacio e pepe ou carbonara. À
    #                 Florence, un cours de cuisine axé sur la cuisine toscane est une expérience mémorable. Et pour le vin, les Chianti Classico sont incontournables.""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""C'est très utile ! Et pour une petite touche de folie ou de changement, est-ce qu'on pourrait faire une excursion d'une journée vers la côte, même si on est dans
    #         l'arrière-pays ? Genre vers l'Adriatique ?""",
    #             role="user",
    #         ),
    #         Message(
    #             content="""Cela est possible, mais cela ajouterait beaucoup de temps de transport et décalerait l'objectif gastronomique. Si vous souhaitez absolument une touche côtière, il serait
    #                 plus logique de commencer par la côte Amalfitaine et de couper une partie de Rome pour cette étape. Sinon, je suggère de maximiser l'expérience italienne en restant concentré sur
    #                 l'intérieur, ce qui rendra le voyage plus fluide.""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""D'accord, vous avez raison. L'itinéraire Rome-Sienne-Florence est le meilleur compromis. Pour finir, pourriez-vous me préparer une ébauche d'emploi du temps jour par jour
    #                 en incluant ces suggestions ? Cela nous aiderait beaucoup pour la réservation.""",
    #             role="user",
    #         ),
    #         Message(
    #             content="""Avec plaisir. Je vous prépare un tableau détaillé qui couvre l'arrivée, les visites historiques, les moments gourmands, et les transferts entre les villes. Voulez-vous
    #                 que je mette en avant les heures de pointe pour vous aider à planifier vos déplacements ?""",
    #             role="assistant",
    #         ),
    #         Message(
    #             content="""Oui, s'il vous plaît. Ça nous aiderait énormément à éviter la foule et les transports saturés. Merci beaucoup ! C'est beaucoup plus clair maintenant.""",
    #             role="user",
    #         ),
    #     ]
    # )

    llm_memorizer = LLMMemorizer(
        user_id="user_123",
        session_id="session_123",
        llm_call=llm_call,
    )
    llm_memorizer.current_conversation.add_messages(conversation.get_messages())

    start = time()
    memory, summary = await llm_memorizer.consolidate()
    print("============ summary =============")
    print(summary)
    print("============ memory user =============")
    print(memory.user)
    print("============ memory facts =============")
    for i, fact in enumerate(memory.facts):
        print(f"Fact number {i + 1}:")
        print(fact)
    print(f"Time taken: {time() - start} in seconds")


if __name__ == "__main__":
    import asyncio

    asyncio.run(test_with_agent())
