"""
Complete example showing how to use the generic llm_call function with Pydantic models.
"""

from typing import TypeVar

import pytest
from pydantic import BaseModel

from generic_llm_memorizer.conversation import Conversation
from generic_llm_memorizer.llm_memorizer import LLMMemorizer

# Import our models
from generic_llm_memorizer.memory import Memory, Summary

# Define a generic type variable bounded by BaseModel
T = TypeVar("T", bound=BaseModel)


async def example_build_llm_call():

    async def func(prompt: str, system_prompt: str, response_model: type[T]) -> T:
        if response_model == Summary:
            mock_response = {"content": "This is a mock summary of the conversation."}
        elif response_model == Memory:
            mock_response = {
                "user": {
                    "user_id": "user_123",
                    "name": "John Doe",
                    "preferences": [],
                },
                "facts": [
                    {
                        "content": "John Doe is a software engineer",
                        "kind": "professional",
                        "timestamp": "2023-01-01T10:00:00Z",
                        "validity": "forever",
                    }
                ],
            }
        else:
            # For any other Pydantic model, return a generic mock response
            mock_response = {}

        # Parse and return the response as the specified model type
        return response_model(**mock_response)

    return func


@pytest.mark.asyncio
async def test_main():
    # Create a conversation
    conversation = Conversation(
        session_id="s432", system_prompt="You are a helpful assistant"
    )

    # Add some messages
    conversation.add_user_message(
        "Hello, my name is John Doe and I'm a software engineer"
    )
    conversation.add_assistant_message(
        "Nice to meet you John! How can I help you today?"
    )
    conversation.add_user_message("Can you tell me what you know about me?")

    example_llm_call = await example_build_llm_call()
    # Example 1: Using llm_call with Summary model
    summary = await example_llm_call(
        "Summarize this conversation: " + str(conversation.to_dict()), "", Summary
    )
    print(f"Summary: {summary.content}")

    # Example 2: Using llm_call with Memory model
    memory = await example_llm_call(
        "Extract facts from this conversation: " + str(conversation.to_dict()),
        "",
        Memory,
    )
    print(f"Memory with {len(memory.facts)} facts:")
    for fact in memory.facts:
        print(f"  - {fact.content} ({fact.kind})")

    # Example 3: Using with LLMMemorizer
    memorizer = LLMMemorizer(
        user_id="user_123",
        session_id="session_123",
        llm_call=example_llm_call,
    )

    # Extract facts using the memorizer
    extracted_memory = await memorizer._extract_facts()
    print(f"\nExtracted memory with {len(extracted_memory.facts)} facts:")
    for fact in extracted_memory.facts:
        print(f"  - {fact.content} ({fact.kind})")

    # Generate summary using the memorizer
    generated_summary = await memorizer._summarize()
    print(f"\nGenerated summary: {generated_summary}")


if __name__ == "__main__":
    import asyncio

    asyncio.run(test_main())
