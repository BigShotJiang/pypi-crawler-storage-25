"""
Conversation management for LLM interactions.
Provides classes and functions to manage LLM conversation history and context.
"""

import json
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class Message:
    """Represents a single message in a conversation."""

    role: str  # "user", "assistant", "system", etc.
    content: str
    timestamp: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()
        if self.metadata is None:
            self.metadata = {}


class Conversation:
    """Manages a conversation with an LLM."""

    def __init__(self, session_id: str, system_prompt: Optional[str] = None):
        self.session_id = session_id
        self.messages: List[Message] = []

        if system_prompt:
            self.add_message("system", system_prompt)

    def add_message(
        self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None
    ) -> Message:
        """Add a message to the conversation."""
        message = Message(role=role, content=content, metadata=metadata)
        self.messages.append(message)
        return message

    def add_messages(self, messages: List[Message]) -> None:
        """Add multiple messages to the conversation."""
        self.messages.extend(messages)

    def insert_summary(self, summary: str) -> None:
        """Insert a summary message into the conversation."""
        return self.messages.insert(0, Message(role="assistant", content=summary))

    def add_user_message(
        self, content: str, metadata: Optional[Dict[str, Any]] = None
    ) -> Message:
        """Add a user message to the conversation."""
        return self.add_message("user", content, metadata)

    def add_assistant_message(
        self, content: str, metadata: Optional[Dict[str, Any]] = None
    ) -> Message:
        """Add an assistant message to the conversation."""
        return self.add_message("assistant", content, metadata)

    def get_messages(self) -> List[Message]:
        """Get all messages in the conversation."""
        return self.messages.copy()

    def get_recent_messages(self, count: int) -> List[Message]:
        """Get the most recent messages."""
        return (
            self.messages[-count:]
            if count <= len(self.messages)
            else self.messages.copy()
        )

    def keep_recent_messages(self, count: int):
        """Keep only the most recent messages."""
        if count < 0:
            raise ValueError("Count must be non-negative")
        self.messages = self.messages[-count:]

    def delete_old_messages(self, count: int):
        """Delete the oldest messages from the conversation."""
        if count < 0:
            raise ValueError("Count must be non-negative")
        self.messages = self.messages[count:]

    def clear(self):
        """Clear all messages from the conversation."""
        self.messages.clear()

    def to_dict(self) -> Dict[str, Any]:
        """Convert conversation to dictionary format."""
        return {
            "session_id": self.session_id,
            "messages": [asdict(msg) for msg in self.messages],
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert conversation to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, session_id: str, data: List[Dict[str, Any]]) -> "Conversation":
        """Create a conversation from dictionary data."""
        conversation = cls(session_id=session_id)
        conversation.messages = [Message(**msg_dict) for msg_dict in data]
        return conversation

    @classmethod
    def from_json(cls, json_str: str) -> "Conversation":
        """Create a conversation from JSON string."""
        data = json.loads(json_str)
        return cls.from_dict(data["session_id"], data["messages"])

    def __len__(self) -> int:
        return len(self.messages)

    def __iter__(self):
        return iter(self.messages)


def format_conversation_for_prompt(conversation: Conversation) -> List[Dict[str, str]]:
    """
    Format conversation for use with LLM APIs that expect a list of message dicts.

    Args:
        conversation: Conversation object to format

    Returns:
        List of dictionaries with 'role' and 'content' keys
    """
    return [
        {"role": msg.role, "content": msg.content}
        for msg in conversation.get_messages()
    ]


def extract_last_user_message(conversation: Conversation) -> Optional[str]:
    """
    Extract the last user message from a conversation.

    Args:
        conversation: Conversation object

    Returns:
        Content of the last user message, or None if no user messages exist
    """
    for msg in reversed(conversation.messages):
        if msg.role == "user":
            return msg.content
    return None


def extract_last_assistant_message(conversation: Conversation) -> Optional[str]:
    """
    Extract the last assistant message from a conversation.

    Args:
        conversation: Conversation object

    Returns:
        Content of the last assistant message, or None if no assistant messages exist
    """
    for msg in reversed(conversation.messages):
        if msg.role == "assistant":
            return msg.content
    return None
