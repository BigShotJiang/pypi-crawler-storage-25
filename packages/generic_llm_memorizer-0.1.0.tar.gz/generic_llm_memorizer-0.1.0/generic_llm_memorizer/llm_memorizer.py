import uuid
from typing import Callable, Coroutine, List, Optional, Type, TypeVar, cast

from pydantic import BaseModel
from pydantic.json_schema import os

from generic_llm_memorizer.conversation import Conversation, Message
from generic_llm_memorizer.memory import (
    Concept,
    ConceptGraph,
    Fact,
    Memory,
    Summary,
    User,
)

# Type générique pour notre fonction llm_call
T = TypeVar("T", bound=BaseModel)

MEMORIES_FOLDER = "./memories"

MEMORIZE_SYSTEM_PROMPT = """
Tu es un agent qui mémorise les informations importantes d'une conversation.
Attention à ne garder que les informations les plus pertinentes, qui peuvent resservir plus tard pour d'autres conversations.
Ne garde pas les détails des échanges, mais les points clés.

Ces points clés seront stockés dans des Facts.

Il faudra que tu qualifies ces faits suivants différentes catégories que tu définiras au fur et à mesure.

"""


class LLMMemorizer:
    def __init__(
        self,
        user_id: str,
        llm_call: Callable[
            [str, str, Type[BaseModel]], Coroutine[None, None, BaseModel]
        ],
        session_id: Optional[str] = None,
    ):
        self.user_id = user_id
        if session_id is None:
            session_id = "session_" + str(uuid.uuid4())
        self.session_id = session_id
        self.llm_call = llm_call
        self.knowledge_graph = ConceptGraph(concepts=[])

        save_path = MEMORIES_FOLDER + "/" + self.user_id
        os.makedirs(save_path, exist_ok=True)

        if os.path.exists(save_path + "/knowledge_graph.json"):
            with open(save_path + "/knowledge_graph.json", "r") as f:
                self.knowledge_graph = ConceptGraph.model_validate_json(f.read())
        else:
            self.knowledge_graph = ConceptGraph(concepts=[])

        if os.path.exists(save_path + "/memory.json"):
            with open(save_path + "/memory.json", "r") as f:
                self.memory = Memory.model_validate_json(f.read())
        else:
            self.memory = Memory(facts=[], user=User(user_id=user_id))

        if os.path.exists(save_path + "/" + session_id + "/conversation.json"):
            with open(save_path + "/" + session_id + "/conversation.json", "r") as f:
                self.current_conversation = Conversation.from_json(f.read())
        else:
            self.current_conversation = Conversation(
                session_id=session_id, system_prompt=""
            )

        # self.conversation = conversation
        # self.memory = Memory(facts=[], user=User(user_id=user_id))
        self.system_prompt = MEMORIZE_SYSTEM_PROMPT

    async def persist(self) -> None:
        save_path = MEMORIES_FOLDER + "/" + self.user_id
        os.makedirs(save_path + "/" + self.session_id, exist_ok=True)
        # Save memory
        with open(save_path + "/memory.json", "w") as f:
            f.write(self.memory.model_dump_json(indent=2))
        # Save conversation
        with open(save_path + "/" + self.session_id + "/conversation.json", "w") as f:
            f.write(self.current_conversation.to_json())

        with open(save_path + "/knowledge_graph.json", "w") as f:
            f.write(self.knowledge_graph.model_dump_json(indent=2))

    def are_concepts_equal(self, c1: Concept, c2: Concept) -> bool:
        """Check if two concepts are equal based on their subject, predicate and object."""
        return (
            c1.subject == c2.subject
            and c1.predicate == c2.predicate
            and c1.object == c2.object
        )

    async def _merge_knowledge_graph(self, other_concept_graph: ConceptGraph):
        merged_knowledge_graph = self.knowledge_graph.model_copy()
        for concept in other_concept_graph.concepts:
            if not any(
                self.are_concepts_equal(concept, c)
                for c in merged_knowledge_graph.concepts
            ):
                merged_knowledge_graph.concepts.append(concept)

        self.knowledge_graph = merged_knowledge_graph
        return merged_knowledge_graph

    async def _build_knowledge_graph(
        self, summary: str, facts: List[Fact]
    ) -> ConceptGraph:
        res = ConceptGraph(concepts=[])
        prompt = f"""
            Given a summary of a conversation as context :
                {summary}

            Extract from the folowing facts, main concepts :
                {facts}

            From the extracted concepts, create links representing relationships
            between concepts.
            At the end you must have concepts and their relationships.
        """
        try:
            res = await self.llm_call(prompt, self.system_prompt, ConceptGraph)
        except Exception as e:
            print("Error extracting concepts", e)

        res = cast(ConceptGraph, res)
        res = await self._merge_knowledge_graph(res)
        return res

    async def _summarize(self) -> str:
        messages = self.current_conversation.get_messages()
        prompt = f"""
        Summarize the following conversation:

            {messages}

        Keep the summary concise and to the point.
        """
        try:
            summary = cast(
                Summary, await self.llm_call(prompt, self.system_prompt, Summary)
            )
            self.current_conversation.keep_recent_messages(10)
            self.current_conversation.insert_summary(summary.content)
            return summary.content
        except Exception as e:
            print(f"Error summarizing: {e}")
            return ""

    async def _extract_user_profile(self, batch: List[Message]) -> User:
        prompt = f"""
            Try gathering information about the user's profile from the following conversation:

                {batch}


            Here is the current profile you have, from where you can start:

                {self.memory.user}


            Return the updated profile so far, including any new information you've gathered.


        """
        try:
            result = await self.llm_call(prompt, self.system_prompt, User)
            user = cast(User, result)
            self.memory.user = user
        except Exception as e:
            print(f"Error extracting facts: {e}")
        finally:
            return self.memory.user

    async def _extract_facts(self) -> Memory:
        facts: List[Fact] = []
        messages = self.current_conversation.get_messages()

        # Process messages in batches of 10
        batch_size = 10
        for i in range(0, len(messages), batch_size):
            batch = messages[i : i + batch_size]
            prompt = f"""
            Read the following messages:

                {batch}

            Given the already extracted facts:

                {facts}

            Only add new facts that are not already present.

            Keep the facts concise and to the point.
            Extract only facts that are relevant.
            A fact is relevant if:
                - it allows to enrich the user profile
                - it is not trivial
                - it is not a trivial repetition of an existing fact
            Give a fact a timestamp representing when it was extracted and a duration validity
            that is an estimation of how long the fact is valid.
            Don't touch to the user profile (User object of Memory).
            """
            try:
                result = await self.llm_call(prompt, self.system_prompt, Memory)
                await self._extract_user_profile(batch)
                print(self.memory.user)
                memory = cast(Memory, result)
                print("new facts: ", len(memory.facts))
                facts.extend(memory.facts)
            except Exception as e:
                print(f"Error extracting facts: {e}")
        self.memory.facts.extend(facts)
        return self.memory

    async def consolidate(self) -> tuple[Memory, str]:

        memo = await self._extract_facts()
        summary = await self._summarize()
        await self._build_knowledge_graph(summary, memo.facts)
        await self.persist()
        return self.memory, summary
