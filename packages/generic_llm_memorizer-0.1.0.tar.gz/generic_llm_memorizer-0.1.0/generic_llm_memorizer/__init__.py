"""
Generic LLM Memorizer - LLM Conversation Management Library
"""

from .conversation import Conversation, Message, format_conversation_for_prompt, extract_last_user_message, extract_last_assistant_message

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    "Conversation",
    "Message",
    "format_conversation_for_prompt",
    "extract_last_user_message",
    "extract_last_assistant_message"
]