from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class Validity(str, Enum):
    FOREVER = "forever"
    ONE_DAY = "one_day"
    ONE_WEEK = "one_week"
    ONE_MONTH = "one_month"
    ONE_YEAR = "one_year"


class Fact(BaseModel):
    """
    A fact extracted from a conversation.
    A fact is an information of a certain kind, extracted at a given timestamp, with a duration validity.
    """

    content: str = Field(
        description="an important fact text extracted from a conversation (i.e. a user's name, a location, a bithdate, etc.)",
        max_length=500,
    )
    kind: str = Field(
        description="the kind of fact (i.e. a political fact, a geographical fact, a human fact, etc.). It must be one word.",
        max_length=30,
    )
    timestamp: datetime = Field(
        description="the timestamp when the fact was extracted from the conversation"
    )
    duration_validity: Validity = Field(
        description="an estimated validity duration of the fact. It can be forever, one day, one week, one month, or one year. Depends on the context and the relevance of the information.",
        default=Validity.ONE_MONTH,
    )


class Entity(BaseModel):
    """Entity object identified by its name"""

    name: str = Field(
        description="name of the entity, unique in the Knowledge Graph. Must be a single word."
    )
    type: str = Field(
        description="type of ntity, i.e. its nature, its scope of application"
    )
    # subClassOf: Optional[str] = Field(description="name of the higher level concept")
    # causedBy: Optional[str] = Field(description="name of the concept that uses this concept")


class Concept(BaseModel):
    """A Concept representation as a RDF Triple (subject) -- predicate --> [object]
    For instance: (the sky) -- has the  --> [color blue])
    """

    subject: Entity = Field(description="main subject of the concept, i.e. main entity")
    predicate: Entity = Field(
        description="main verb of the concept, i.e. main attribution"
    )
    object: Entity = Field(
        description="value of the concept, i.e. main value in regards with the attribution"
    )


class ConceptGraph(BaseModel):
    """Graph of concepts."""

    concepts: List[Concept] = Field(
        description="List of concepts (i.e. subject -- predicate --> object)",
        default=[],
    )


class User(BaseModel):
    user_id: str = Field(description="the unique identifier of the user")
    first_name: Optional[str] = Field(
        description="the first name of the user", default=None
    )
    last_name: Optional[str] = Field(
        description="the last name of the user", default=None
    )
    age: Optional[int] = Field(description="the age of the user", default=None)
    genre: Optional[str] = Field(
        description="the genre of the user (i.e. male, female, non-binary, etc.)",
        default=None,
    )
    hobbies: List[str] = Field(description="the hobbies of the user", default=[])
    main_occupation: Optional[str] = Field(
        description="the main profession or occupation of the user", default=None
    )


class Memory(BaseModel):
    """
    A memory built from a conversation.
    """

    user: User = Field(
        description="The user interacting with the system. Some information may be missing but could be inferred from the conversation."
    )
    facts: list[Fact] = Field(
        description="a list of important facts extracted from a conversation"
    )


class Summary(BaseModel):
    content: str = Field(
        description="a concise summary of the conversation",
        max_length=2000,
    )
