def main():
    """Entry point for the generic-llm-memorizer library."""
    print("Hello from generic-llm-memorizer!")
    print("This is a library for managing LLM conversations.")
    print("Use 'from generic_llm_memorizer import Conversation' to get started.")


if __name__ == "__main__":
    main()
