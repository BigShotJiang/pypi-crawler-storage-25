from __future__ import annotations

from enum import (
    Enum,
)
from functools import cached_property
from typing import TYPE_CHECKING, NamedTuple

from networkx import DiGraph

from blends.syntax.node_attributes import VALID_SYNTAX_ATTRIBUTES

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator, Mapping
    from pathlib import Path

    from blends.ast.node_attributes_types import AstNodeAttrs
    from blends.edge_attributes_types import EdgeAttrs
    from blends.stack.attributes_types import StackNodeAttrs
    from blends.syntax.models import FileStructData
    from blends.syntax.node_attributes_types import SyntaxNodeAttrs


class Language(Enum):
    CSHARP = "c_sharp"
    DART = "dart"
    GO = "go"
    HCL = "hcl"
    JAVA = "java"
    JAVASCRIPT = "javascript"
    JSON = "json"
    KOTLIN = "kotlin"
    NOT_SUPPORTED = "not_supported"
    PHP = "php"
    PYTHON = "python"
    RUBY = "ruby"
    SCALA = "scala"
    SWIFT = "swift"
    TYPESCRIPT = "tsx"
    YAML = "yaml"


LANGUAGE_TO_EXTENSIONS: dict[Language, tuple[str, ...]] = {
    Language.CSHARP: (".cs",),
    Language.DART: (".dart",),
    Language.GO: (".go",),
    Language.HCL: (".hcl", ".tf"),
    Language.JAVA: (".java",),
    Language.JAVASCRIPT: (".js", ".jsx"),
    Language.JSON: (".json",),
    Language.KOTLIN: (".kt", ".ktm", ".kts"),
    Language.PHP: (".php",),
    Language.PYTHON: (".py",),
    Language.RUBY: (".rb",),
    Language.SCALA: (".scala",),
    Language.SWIFT: (".swift",),
    Language.TYPESCRIPT: (".ts", ".tsx"),
    Language.YAML: (".yaml", ".yml"),
}

EXTENSION_TO_LANGUAGE: dict[str, Language] = {
    ext: lang for lang, exts in LANGUAGE_TO_EXTENSIONS.items() for ext in exts
}


def decide_language(path: str) -> Language:
    file_extension = "." + path.rsplit(".", maxsplit=1)[-1]
    return EXTENSION_TO_LANGUAGE.get(file_extension, Language.NOT_SUPPORTED)


SUPPORTED_MULTIFILE = {
    Language.JAVA,
}


class Content(NamedTuple):
    content_bytes: bytes
    content_str: str
    language: Language
    path: Path


class CustomParser(NamedTuple):
    validator: Callable[[Content], bool]
    parser: Callable[[Content], Content | None]


NId = int


if TYPE_CHECKING:

    class BaseGraph(DiGraph[NId]):
        def __getitem__(self, n: NId) -> Mapping[NId, EdgeAttrs]: ...  # type: ignore[override]  # noqa: D105
        @property
        def adj(self) -> Mapping[NId, Mapping[NId, EdgeAttrs]]: ...  # type: ignore[override]
        @property
        def pred(self) -> Mapping[NId, Mapping[NId, EdgeAttrs]]: ...  # type: ignore[override]
        def get_edge_data(self, u: NId, v: NId, default: object = None) -> EdgeAttrs: ...  # type: ignore[override]

    class AstNodeView(Mapping[NId, AstNodeAttrs]):
        def __init__(self, graph: BaseGraph) -> None: ...
        def __getitem__(self, n: NId) -> AstNodeAttrs: ...  # noqa: D105
        def __len__(self) -> int: ...  # noqa: D105
        def __iter__(self) -> Iterator[NId]: ...  # noqa: D105

    class SyntaxNodeView(Mapping[NId, SyntaxNodeAttrs]):
        def __init__(self, graph: BaseGraph) -> None: ...
        def __getitem__(self, n: NId) -> SyntaxNodeAttrs: ...  # noqa: D105
        def __len__(self) -> int: ...  # noqa: D105
        def __iter__(self) -> Iterator[NId]: ...  # noqa: D105

    class StackNodeView(Mapping[NId, StackNodeAttrs]):
        def __init__(self, graph: BaseGraph) -> None: ...
        def __getitem__(self, n: NId) -> StackNodeAttrs: ...  # noqa: D105
        def __len__(self) -> int: ...  # noqa: D105
        def __iter__(self) -> Iterator[NId]: ...  # noqa: D105

else:
    from networkx.classes.reportviews import NodeView

    class BaseGraph(DiGraph): ...

    class AstNodeView(NodeView): ...

    class SyntaxNodeView(NodeView): ...

    class StackNodeView(NodeView): ...


class Graph(BaseGraph):
    def __init__(self) -> None:
        super().__init__()
        self.nodes_by_type: dict[str, list[NId]] = {}

    def add_node(self, node_for_adding: NId, **attr: object) -> None:
        super().add_node(node_for_adding, **attr)
        if label_type := attr.get("label_type"):
            self.nodes_by_type.setdefault(str(label_type), []).append(node_for_adding)

    def update_node(self, node_id: NId, attributes: dict[str, object]) -> None:
        self.nodes[node_id].update(attributes)  # type: ignore[typeddict-item]

    @cached_property
    def nodes(self) -> AstNodeView:  # type: ignore[override]
        return AstNodeView(self)


class StackGraph(Graph):
    @cached_property
    def nodes(self) -> StackNodeView:  # type: ignore[override]
        return StackNodeView(self)


class SyntaxGraph(Graph):
    def __init__(self) -> None:
        super().__init__()
        self.symbol_index: dict[str, dict[NId, list[NId]]] = {}
        self.scope_parent: dict[NId, NId] = {}

    def add_node(self, node_for_adding: NId, **attr: object) -> None:
        invalid_keys = attr.keys() - VALID_SYNTAX_ATTRIBUTES
        if invalid_keys:
            msg = f"Invalid node attribute keys: {invalid_keys!r}"
            raise ValueError(msg)
        super().add_node(node_for_adding, **attr)

    def update_node(self, node_id: NId, attributes: dict[str, object]) -> None:
        invalid_keys = attributes.keys() - VALID_SYNTAX_ATTRIBUTES
        if invalid_keys:
            msg = f"Invalid node attribute keys: {invalid_keys!r}"
            raise ValueError(msg)
        super().update_node(node_id, attributes)

    def update_node_attribute(self, node_id: NId, key: str, value: object) -> None:
        if key not in VALID_SYNTAX_ATTRIBUTES:
            msg = f"Invalid node attribute key: {key!r}"
            raise ValueError(msg)
        self.nodes[node_id][key] = value  # type: ignore[literal-required]

    def finalize_symbol_index(self) -> None:
        """Reverse all symbol definition lists so most recent is at index 0."""
        for scope_defs in self.symbol_index.values():
            for def_list in scope_defs.values():
                def_list.reverse()

    @cached_property
    def nodes(self) -> SyntaxNodeView:  # type: ignore[override]
        return SyntaxNodeView(self)


class GraphSet(NamedTuple):
    ast_graph: Graph | None
    syntax_graph: SyntaxGraph | None
    stack_graph: StackGraph | None = None


class GraphShard(NamedTuple):
    path: str
    graph: Graph
    syntax_graph: SyntaxGraph
    content_as_str: str
    file_size: int


class GraphDB(NamedTuple):
    context: dict[Language, dict[str, dict[str, dict[str, FileStructData]]]]
    shards: dict[str, GraphShard]
    properties: dict[str, dict[str, str]] = {}  # noqa: RUF012

    def get_path_shard(self, path: str) -> GraphShard | None:
        return self.shards.get(path)
