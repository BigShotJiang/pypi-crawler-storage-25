"""Search strategies package."""
