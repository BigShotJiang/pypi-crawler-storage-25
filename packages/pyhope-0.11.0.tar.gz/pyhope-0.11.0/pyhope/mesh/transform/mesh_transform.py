#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of PyHOPE
#
# Copyright (c) 2024 Numerics Research Group, University of Stuttgart, Prof. Andrea Beck
#
# PyHOPE is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# PyHOPE is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# PyHOPE. If not, see <http://www.gnu.org/licenses/>.

# ==================================================================================================================================
# Mesh generation library
# ==================================================================================================================================
# ----------------------------------------------------------------------------------------------------------------------------------
# Standard libraries
# ----------------------------------------------------------------------------------------------------------------------------------
from __future__ import annotations
from typing import Final
from typing import cast
# ----------------------------------------------------------------------------------------------------------------------------------
# Third-party libraries
# ----------------------------------------------------------------------------------------------------------------------------------
import numpy as np
# ----------------------------------------------------------------------------------------------------------------------------------
# Typing libraries
# ----------------------------------------------------------------------------------------------------------------------------------
import typing
if typing.TYPE_CHECKING:
    import numpy.typing as npt
# ----------------------------------------------------------------------------------------------------------------------------------
# Local imports
# ----------------------------------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------------------------------
# Local definitions
# ----------------------------------------------------------------------------------------------------------------------------------
# ==================================================================================================================================


def CalcStretching(nZones: int, zone: int, nElems: npt.NDArray, lEdges: npt.NDArray) -> npt.NDArray:
    """ Calculate the stretching parameter for meshing the current zone
    """
    # Local imports ----------------------------------------
    import pyhope.mesh.mesh_vars as mesh_vars
    import pyhope.output.output as hopout
    from pyhope.readintools.readintools import CountOption, GetRealArray
    # ------------------------------------------------------

    # Check if mesh is scaled
    nl0     = CountOption('l0')
    nFactor = CountOption('Factor')

    conditions = {(0     , 0     ): 'constant',     # Non-stretched element arrangement
                  (0     , nZones): 'factor',       # Stretched element arrangement based on factor
                  (nZones, 0     ): 'ratio',        # Stretched element arrangement based on ratio
                  (nZones, nZones): 'combination'   # Stretched element arrangement with a combination of l0 and factor
                 }

    stretchingType = conditions.get((nl0, nFactor))

    if stretchingType == 'combination':
        print(hopout.warn('Both l0 and a stretching factor are provided. ' +
                          'The number of elements will be adapted to account for both parameters.'))
    if stretchingType is None:
        hopout.error('Streching parameters not defined properly. Check whether l0 and/or Factor are defined nZone-times.',
                     traceback=True)

    # Calculate the stretching parameter for meshing the current zone
    stretchingHandlers = {
            'constant':    lambda: ([1., 1., 1.], None, None),                         # noqa: E272
            'factor':      lambda: (GetRealArray('Factor', number=zone), None, None),  # noqa: E272
            'ratio':       lambda: (None,                                              # noqa: E272
                                    GetRealArray('l0'    , number=zone),
                                    np.divide(lEdges, np.abs(GetRealArray('l0', number=zone)),
                                              out=np.zeros_like(lEdges), where=GetRealArray('l0', number=zone) != 0)),
            'combination': lambda: (GetRealArray('Factor', number=zone),
                                    GetRealArray('l0'    , number=zone),
                                    np.divide(lEdges, np.abs(GetRealArray('l0', number=zone)),
                                              out=np.zeros_like(lEdges), where=GetRealArray('l0', number=zone) != 0))
    }

    handler = stretchingHandlers.get(stretchingType)
    progFac, l0, dx = handler() if handler else (np.array(()), np.array(()), np.array(()))

    if stretchingType == 'combination':
        if progFac is None or l0 is None or dx is None:
            hopout.error(f'Missing parameter {[n for (s, n) in zip((progFac, l0, dx), ("factor", "l0", "dx"), strict=True) if s is None]}, exiting...')  # noqa: E501

        for iDim in range(3):
            if np.isclose(progFac[iDim], 0., atol=mesh_vars.tolInternal):
                continue  # Skip if factor is zero, (nElem, l0) given, factor calculated later

            progFac[iDim] = (np.abs(progFac[iDim]))**(np.sign(progFac[iDim]*l0[iDim]))

            if np.isclose(progFac[iDim], 1., atol=mesh_vars.tolInternal):
                continue  # Skip if factor is one, no stretching

            # Calculate the number of elements in the current zone
            nElems[iDim] = max(1, np.rint(np.log(1.-dx[iDim]*(1.-progFac[iDim])) / np.log(progFac[iDim])))
        print(hopout.warn(f'nElems in zone {zone} have been updated to ({nElems[0]}, {nElems[1]},{nElems[2]}).'))

    # Calculate the required factor from ratio or combination input
    if stretchingType in {'ratio', 'combination'}:
        if progFac is None or l0 is None or dx is None:
            hopout.error(f'Missing parameter {[n for (s, n) in zip((progFac, l0, dx), ("factor", "l0", "dx"), strict=True) if s is None]}, exiting...')  # noqa: E501

        print(hopout.warn(hopout.Colors.WARN + '─'*(46-16) + hopout.Colors.END))
        for iDim in range(3):
            if nElems[iDim] == 1 or dx[iDim] == 0:
                progFac[iDim] = 1.
                continue
            if nElems[iDim] == 2:
                progFac[iDim] = dx[iDim] - 1.
                continue

            # Start value for Newton iteration
            progFac[iDim] = dx[iDim] / nElems[iDim]

            if np.isclose(progFac[iDim], 1., atol=mesh_vars.tolInternal):
                continue  # Skip iteration if equidistant case

            # Newton iteration
            iter = 0
            while iter < 1000:
                F  = progFac[iDim]**nElems[iDim] + dx[iDim]*(1.-progFac[iDim]) - 1.
                df = nElems[iDim]*progFac[iDim]**(nElems[iDim]-1) - dx[iDim]

                if np.isclose(F, 0., atol=mesh_vars.tolInternal) or np.isclose(df/F, 0., atol=mesh_vars.tolInternal):
                    break

                progFac[iDim] -= F / df
                iter          += 1

            if iter == 1000:
                hopout.error('Newton iteration for computing the stretching function has failed.', traceback=True)

            progFac[iDim] = progFac[iDim]**np.sign(l0[iDim])
            print(hopout.warn(f'New stretching factor [dir {iDim}]: {progFac[iDim]}'))

        print(hopout.warn(hopout.Colors.WARN + '─'*(46-16) + hopout.Colors.END))

    if np.any(progFac == 0):
        hopout.error('Stretching factor = 0 is invalid, exiting...')

    # Return stretching factor
    return cast(np.ndarray, progFac)


def TransformMesh() -> None:
    # Local imports ----------------------------------------
    import pyhope.mesh.mesh_vars as mesh_vars
    import pyhope.output.output as hopout
    from pyhope.common.common_template import LoadTemplate
    from pyhope.mesh.mesh_vars import mesh
    from pyhope.readintools.readintools import CountOption
    from pyhope.readintools.readintools import GetReal, GetRealArray, GetStr
    # ------------------------------------------------------

    nMeshScale = CountOption('meshScale')
    nMeshTrans = CountOption('meshTrans')
    nMeshRot   = (CountOption('meshRot')+CountOption('meshRot3D'))

    # Read in the mesh post-deformation flag
    meshPostDeform = GetStr('MeshPostDeform') if CountOption('MeshPostDeform') != 0 else 'none'

    # Leave if no transformation is required
    if all(x == 0 for x in [nMeshScale, nMeshTrans, nMeshRot]) and meshPostDeform == 'none':
        return None

    # Start with basic transformations
    hopout.separator()
    hopout.info('TRANSFORM MESH...')
    hopout.sep()

    hopout.routine('Performing basic transformations')
    hopout.sep()

    # Get scaling factor for mesh
    meshScale: Final[            np.float64 ] = np.float64(GetReal('meshScale'))

    # Get translation vector for mesh
    meshTrans: Final[npt.NDArray[np.float64]] = GetRealArray('meshTrans')

    # Get rotation matrix for mesh
    meshRot3D: Final[npt.NDArray[np.float64]] = GetRealArray('meshRot3D')
    meshRotC:  Final[npt.NDArray[np.float64]] = GetRealArray('meshRotCenter')

    if not np.array_equal(meshRot3D, [0.0, 0.0, 0.0]):
        a = meshRot3D[0]*np.pi/180
        b = meshRot3D[1]*np.pi/180
        c = meshRot3D[2]*np.pi/180
        meshRot       =  np.zeros((3, 3))
        meshRot[0, 0] =  np.cos(a)*np.cos(b)
        meshRot[0, 1] =  np.cos(a)*np.sin(b)*np.sin(c)-np.sin(a)*np.cos(c)
        meshRot[0, 2] =  np.cos(a)*np.sin(b)*np.cos(c)+np.sin(a)*np.cos(c)
        meshRot[1, 0] =  np.sin(a)*np.cos(b)
        meshRot[1, 1] =  np.sin(a)*np.sin(b)*np.sin(c)+np.cos(a)*np.cos(c)
        meshRot[1, 2] =  np.sin(a)*np.sin(b)*np.cos(c)-np.cos(a)*np.sin(c)
        meshRot[2, 0] = -np.sin(b)
        meshRot[2, 1] =  np.cos(b)*np.sin(c)
        meshRot[2, 2] =  np.cos(b)*np.cos(c)
    else:
        meshRot   = GetRealArray('meshRot')
        meshRot   = np.array(meshRot).reshape(3, 3)

    # Scale mesh
    if meshScale != 1.0:
        mesh.points *= meshScale
        for vv in mesh_vars.vvs:
            vv['Dir'] *= meshScale

    # Rotate mesh
    if not np.array_equal(meshRot, ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))):
        mesh.points = meshRotC + (mesh.points-meshRotC) @ meshRot

    # Translate mesh
    if not np.array_equal(meshTrans, (0.0, 0.0, 0.0)):
        mesh.points += meshTrans

    # Exit routine if no further advanced transformation is required
    if meshPostDeform == 'none':
        hopout.sep()
        hopout.info('TRANSFORM MESH DONE!')
        return None

    # Continue with advanced transformations
    hopout.sep()
    hopout.routine('Performing advanced transformations')
    hopout.routine(f'  Template: {meshPostDeform}')

    # Setup the transformation
    transformModule = LoadTemplate(meshPostDeform.strip().lower(), __file__, 'Post transformation')

    # Perform actual post-deformation
    mesh.points = transformModule.PostDeform(mesh.points)

    # Flag mortar rebuild if performing advanced transformation
    mesh_vars.hasMortarsInterzone = True

    hopout.sep()
    hopout.info('TRANSFORM MESH DONE!')
