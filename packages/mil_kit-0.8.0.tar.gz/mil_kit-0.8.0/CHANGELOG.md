# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.8.0] - 2026-4-18

- Add distribution information to MIL files.

## [0.7.0] - 2026-4-4

- Support uncertain species indication in MIL files marked with suffix '?'.

## [0.6.1] - 2026-3-15

- Clean corner radius value in watermark feature.

## [0.6.0] - 2026-3-14

- Add support to prepare MIL files for MDD website.

## [0.5.1] - 2026-2-28

- Fix text wrapping for long watermarks.

## [0.5.0] - 2026-2-28

- Add watermark feature.

## [0.4.5] - 2025-12-24

- Add limit option to restrict number of processed files.
- Create a failed directory only if there are failed files to copy.
- Add more details to logging output.
- Fix max resolution handling in batch processing.

## [0.4.4] - 2025-12-24

- Fix version number extraction when installed as a package.

## [0.4.3] - 2025-12-24

- Fix missing dependencies.

## [0.4.2] - 2025-12-24

- Fix version number parsing.

## [0.4.1] - 2025-12-24

- Fix max resolution option parsing in CLI.

## [0.4.0]

- Add support to set max resolution.

## [v0.3.0] - 2025-12-22

- Fix version numbers.
- Add support for processing all PSD layers.

## [v0.2.0] - 2025-12-22

- Add parallel support.

## [v0.1.1] - 2025-12-22

- Fix entry points.

## [v0.1.0] - 2025-12-22

- Add test code.
- Add progress bar.
