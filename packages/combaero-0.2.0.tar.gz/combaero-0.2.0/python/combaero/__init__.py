"""Public Python API for the combaero package.

This module re-exports selected functions from the compiled _core extension.
It is written to work both when running from the source tree and when
combaero is installed as a wheel.
"""

from importlib import import_module

try:  # Python 3.8+
    from importlib.metadata import PackageNotFoundError
    from importlib.metadata import version as _pkg_version
except ModuleNotFoundError:  # pragma: no cover - very old Python
    from importlib_metadata import PackageNotFoundError
    from importlib_metadata import version as _pkg_version  # type: ignore[import-not-found]


def _load_version() -> str:
    """Return the installed distribution version, or a safe fallback.

    When running from a source tree without an installed wheel, the
    distribution metadata may not be available; in that case we expose a
    placeholder string instead of raising.
    """

    try:
        return _pkg_version("combaero")
    except PackageNotFoundError:
        return "0.0.0+local"


__version__: str = _load_version()


try:
    # Preferred: local extension in the same package (installed wheel or
    # in-tree build where _core was successfully built next to this file).
    from ._core import (
        AcousticMedium,
        AcousticMode,
        AcousticProperties,
        AirProperties,
        AnnularDuctGeometry,
        AnnularMode,
        BlochMode,
        BoundaryCondition,
        CanAnnularGeometry,
        Cd_from_zeta,
        Cd_orifice,
        Cd_rounded_entry,
        Cd_sharp_thin_plate,
        Cd_thick_plate,
        CdCorrelation,
        CorrelationValidity,
        CorrelationResult,
        CombustionMethod,
        CombustionState,
        CompleteState,
        CompressibleFlowSolution,
        EquilibriumResult,
        FannoSolution,
        FannoStation,
        IncompressibleFlowSolution,
        LinerCavity,
        LinerFlowState,
        LinerOrificeGeometry,
        NozzleSolution,
        NozzleStation,
        OrificeFlowResult,
        OrificeGeometry,
        OrificeState,
        OrificeResult,
        ChannelSolverResult,
        MixtureState,
        MomentumChamberResult,
        AreaChangeResult,
        AreaChangeElementResult,
        State,
        Stream,
        Registry,
        ThermoState,
        ThrustResult,
        TransferMatrix,
        TransportState,
        UnitInfo,
        absorption_from_impedance_norm,
        acoustic_impedance,
        acoustic_properties,
        adiabatic_T_wgs,
        adiabatic_wall_temperature,
        air_properties,
        all_units,
        annular_area,
        annular_duct_eigenmodes,
        annular_duct_modes_analytical,
        annulus_axial_modes,
        annulus_azimuthal_modes,
        annulus_modes,
        axial_mode_downstream,
        axial_mode_split,
        axial_mode_upstream,
        bandwidth,
        bernoulli_P2,
        bernoulli_v2,
        beta_from_diameters,
        bilger_stoich_mixture_fraction_mass,
        bilger_Z_from_equivalence_ratio_mass,
        bulk_T_from_edge_T_and_q,
        calc_T_from_cp,
        calc_T_from_h,
        calc_T_from_h_mass,
        calc_T_from_s,
        calc_T_from_s_mass,
        calc_T_from_u,
        calc_T_from_u_mass,
        calc_T_from_sv_mass,
        calc_T_from_sh_mass,
        dh_dT,
        ds_dT,
        dcp_dT,
        can_annular_eigenmodes,
        capacity_ratio,
        channel_dimpled,
        channel_impingement,
        channel_pin_fin,
        channel_ribbed,
        channel_smooth,
        ChannelResult,
        WallCouplingResult,
        closest_mode,
        combustion_equilibrium,
        combustion_state,
        combustion_state_from_streams,
        common_name,
        complete_combustion,
        complete_combustion_isothermal,
        complete_combustion_to_CO2_H2O,
        complete_combustion_to_CO2_H2O_with_fraction,
        complete_state,
        convert_to_dry_fractions,
        cooled_wall_heat_flux,
        cp,
        cp_mass,
        critical_pressure_ratio,
        cv,
        cv_mass,
        damping_ratio,
        channel_flow,
        channel_flow_rough,
        fanno_channel,
        fanno_channel_rough,
        density,
        dewpoint,
        dry_air,
        dimple_friction_multiplier,
        dimple_nusselt_enhancement,
        dT_edge_dq,
        dT_edge_dT_bulk,
        dT_edge_dT_cold,
        dT_edge_dT_hot,
        dynamic_pressure,
        effective_viscothermal_layer,
        effectiveness_counterflow,
        effectiveness_parallelflow,
        effusion_discharge_coefficient,
        effusion_effectiveness,
        equivalence_ratio,
        equivalence_ratio_from_bilger_Z_mass,
        equivalence_ratio_mass,
        equivalence_ratio_mole,
        expansibility_factor,
        fanno_max_length,
        # Nozzle flow is already channel-like
        film_cooling_effectiveness,
        film_cooling_effectiveness_avg,
        film_cooling_multirow_sellers,
        formula,
        formula_to_name,
        frequency_from_strouhal,
        frequency_from_wavelength,
        friction_colebrook,
        friction_haaland,
        friction_petukhov,
        friction_serghides,
        fuel_lhv_mass,
        fuel_lhv_molar,
        get_units,
        h,
        h_mass,
        half_wave_frequency,
        has_units,
        heat_flux,
        heat_flux_from_T_at_depth,
        heat_flux_from_T_at_edge,
        heat_rate,
        heat_rate_from_effectiveness,
        heat_transfer_area,
        heat_transfer_dT,
        helmholtz_frequency,
        helmholtz_Q,
        htc_from_nusselt,
        humid_air_composition,
        humid_air_density,
        humid_air_enthalpy,
        humid_air_enthalpy_nasa9,
        humidity_ratio,
        HumidAir,
        hydraulic_diameter,
        hydraulic_diameter_annulus,
        hydraulic_diameter_rect,
        impingement_nusselt,
        input_units,
        is_whistling_risk,
        isentropic_expansion_coefficient,
        k_aluminum_6061,
        k_haynes230,
        k_inconel718,
        k_stainless_steel_316,
        k_tbc_ysz,
        kinematic_viscosity,
        kinetic_energy,
        liner_2dof_serial_absorption,
        liner_2dof_serial_impedance_norm,
        liner_sdof_absorption,
        liner_sdof_impedance_norm,
        list_functions_with_units,
        list_materials,
        get_material_conductivity,
        lmtd,
        lmtd_counterflow,
        lmtd_parallelflow,
        mach_from_pressure_ratio,
        mach_number,
        mass_flux_isentropic,
        MassStream,
        mass_to_mole,
        min_mode_separation,
        mix,
        mixture_h,
        modes_in_range,
        molar_volume,
        mole_to_mass,
        mwmix,
        name_to_formula,
        normalize_fractions,
        nozzle_cd,
        nozzle_flow,
        nozzle_thrust,
        nozzle_thrust_cd,
        ntu,
        num_species,
        species_name,
        species_index_from_name,
        species_molar_mass,
        species_molar_mass_from_name,
        nusselt_dittus_boelter,
        nusselt_gnielinski,
        nusselt_petukhov,
        nusselt_sieder_tate,
        orifice_area,
        orifice_area_from_beta,
        orifice_Cd_from_K,
        orifice_Cd_from_measurement,
        orifice_dP,
        orifice_dP_Cd,
        orifice_flow,
        orifice_flow_state,
        orifice_flow_thermo,
        orifice_impedance_with_flow,
        orifice_K_from_Cd,
        orifice_mdot,
        orifice_mdot_Cd,
        orifice_Q,
        orifice_Re_d_from_mdot,
        orifice_thickness_correction,
        orifice_velocity,
        orifice_velocity_from_mdot,
        output_units,
        overall_htc,
        overall_htc_wall,
        overall_htc_wall_multilayer,
        oxygen_required_per_kg_fuel,
        oxygen_required_per_kg_mixture,
        oxygen_required_per_mol_fuel,
        oxygen_required_per_mol_mixture,
        particle_velocity,
        P0_from_static,
        P_from_stagnation,
        peclet,
        pin_fin_friction,
        pin_fin_nusselt,
        prandtl,
        pressure_loss,
        quarter_wave_frequency,
        quarter_wave_resonator_tmm,
        recovery_factor,
        reforming_equilibrium,
        reforming_equilibrium_adiabatic,
        relative_humidity_from_dewpoint,
        residence_time,
        residence_time_annulus,
        residence_time_can_annular,
        residence_time_mdot,
        residence_time_mdot_can_annular,
        residence_time_tube,
        reynolds,
        rib_enhancement_factor,
        rib_enhancement_factor_high_re,
        rib_friction_multiplier,
        rib_friction_multiplier_high_re,
        thermal_performance_factor,
        s,
        s_mass,
        saturation_vapor_pressure,
        get_warning_handler,
        is_well_behaved,
        set_equivalence_ratio_mass,
        set_warning_handler,
        set_equivalence_ratio_mole,
        set_fuel_stream_for_CO2,
        set_fuel_stream_for_CO2_dry,
        set_fuel_stream_for_O2,
        set_fuel_stream_for_O2_dry,
        set_fuel_stream_for_phi,
        set_fuel_stream_for_Tad,
        set_oxidizer_stream_for_CO2,
        set_oxidizer_stream_for_CO2_dry,
        set_oxidizer_stream_for_O2,
        set_oxidizer_stream_for_O2_dry,
        set_oxidizer_stream_for_Tad,
        smr_wgs_equilibrium,
        smr_wgs_equilibrium_adiabatic,  # deprecated: use reforming_equilibrium
        solve_A_eff_from_mdot,
        solve_orifice_mdot,
        solve_P0_from_mdot,
        solve_P_back_from_mdot,
        sound_pressure_level,
        space_velocity,
        specific_gas_constant,
        speed_of_sound,
        standard_dry_air_composition,  # deprecated: use species.dry_air
        stokes_layer,
        strouhal,
        sweep_liner_2dof_serial_absorption,
        sweep_liner_sdof_absorption,
        T0_from_static,
        T0_from_static_v,
        T_adiabatic_wall,
        T_adiabatic_wall_mach,
        T_from_stagnation,
        thermal_conductivity,
        thermal_diffusivity,
        thermal_layer,
        thermal_resistance,
        thermal_resistance_wall,
        thermo_state,
        to_acoustic_geometry,
        transport_state,
        tube_axial_modes,
        tube_Q,
        u,
        u_mass,
        vapor_pressure,
        velocity_from_pressure_loss,
        velocity_from_q,
        viscosity,
        wall_temperature_profile,
        water_vapor_mole_fraction,
        wavelength,
        wet_bulb_temperature,
        wgs_equilibrium,
        wgs_equilibrium_adiabatic,
        zeta_from_Cd,
        geometry,
        h0_from_static,
        v_from_h0,
        sharp_area_change,
        conical_area_change,
        # Channel/circular functions
        htc_circular_channel,
        nusselt_circular_channel,
        channel_dP,
        channel_dP_mdot,
        channel_velocity,
        channel_mdot,
        channel_pressure_drop,
        pressure_drop_channel,
        circular_area,
        cylinder_volume,
        channel_roughness,
        standard_channel_roughness,
    )

    molar_mass = mwmix
    Tube = geometry.Tube
    Annulus = geometry.Annulus
    CanAnnularFlowGeometry = geometry.CanAnnularFlowGeometry
except (ModuleNotFoundError, ImportError) as e:
    print(f"DEBUG: Import failed with {type(e).__name__}: {e}")
    # Fallback: attempt to import from an installed combaero package that
    # already has _core available, then re-export the symbols.
    _core = import_module("combaero._core")
    mixture_h = _core.mixture_h
    adiabatic_T_wgs = _core.adiabatic_T_wgs
    cp = _core.cp
    cp_mass = _core.cp_mass
    h = _core.h
    h_mass = _core.h_mass
    s = _core.s
    s_mass = _core.s_mass
    cv = _core.cv
    cv_mass = _core.cv_mass
    density = _core.density
    specific_gas_constant = _core.specific_gas_constant
    isentropic_expansion_coefficient = _core.isentropic_expansion_coefficient
    speed_of_sound = _core.speed_of_sound
    molar_mass = _core.mwmix
    molar_volume = _core.molar_volume
    viscosity = _core.viscosity
    thermal_conductivity = _core.thermal_conductivity
    pin_fin_nusselt = _core.pin_fin_nusselt
    prandtl = _core.prandtl
    thermal_diffusivity = _core.thermal_diffusivity
    reynolds = _core.reynolds
    peclet = _core.peclet
    mole_to_mass = _core.mole_to_mass
    mass_to_mole = _core.mass_to_mole
    normalize_fractions = _core.normalize_fractions
    convert_to_dry_fractions = _core.convert_to_dry_fractions
    equivalence_ratio_mole = _core.equivalence_ratio_mole
    equivalence_ratio = _core.equivalence_ratio
    equivalence_ratio_mole = _core.equivalence_ratio_mole
    equivalence_ratio_mass = _core.equivalence_ratio_mass
    set_equivalence_ratio_mass = _core.set_equivalence_ratio_mass
    bilger_stoich_mixture_fraction_mass = _core.bilger_stoich_mixture_fraction_mass
    bilger_Z_from_equivalence_ratio_mass = _core.bilger_Z_from_equivalence_ratio_mass
    equivalence_ratio_from_bilger_Z_mass = _core.equivalence_ratio_from_bilger_Z_mass
    expansibility_factor = _core.expansibility_factor
    solve_orifice_mdot = _core.solve_orifice_mdot
    dry_air = _core.dry_air
    humid_air_composition = _core.humid_air_composition
    humid_air_density = _core.humid_air_density
    humid_air_enthalpy = _core.humid_air_enthalpy
    humid_air_enthalpy_nasa9 = _core.humid_air_enthalpy_nasa9
    humidity_ratio = _core.humidity_ratio
    HumidAir = _core.HumidAir
    saturation_vapor_pressure = _core.saturation_vapor_pressure
    vapor_pressure = _core.vapor_pressure
    water_vapor_mole_fraction = _core.water_vapor_mole_fraction
    wet_bulb_temperature = _core.wet_bulb_temperature
    dewpoint = _core.dewpoint
    relative_humidity_from_dewpoint = _core.relative_humidity_from_dewpoint
    formula_to_name = _core.formula_to_name
    name_to_formula = _core.name_to_formula
    common_name = _core.common_name
    formula = _core.formula
    calc_T_from_h = _core.calc_T_from_h
    calc_T_from_h_mass = _core.calc_T_from_h_mass
    calc_T_from_s = _core.calc_T_from_s
    calc_T_from_s_mass = _core.calc_T_from_s_mass
    calc_T_from_cp = _core.calc_T_from_cp
    calc_T_from_u = _core.calc_T_from_u
    calc_T_from_u_mass = _core.calc_T_from_u_mass
    calc_T_from_sv_mass = _core.calc_T_from_sv_mass
    calc_T_from_sh_mass = _core.calc_T_from_sh_mass
    dh_dT = _core.dh_dT
    ds_dT = _core.ds_dT
    dcp_dT = _core.dcp_dT
    num_species = _core.num_species
    species_name = _core.species_name
    species_index_from_name = _core.species_index_from_name
    species_molar_mass = _core.species_molar_mass
    species_molar_mass_from_name = _core.species_molar_mass_from_name
    oxygen_required_per_mol_fuel = _core.oxygen_required_per_mol_fuel
    oxygen_required_per_kg_fuel = _core.oxygen_required_per_kg_fuel
    oxygen_required_per_mol_mixture = _core.oxygen_required_per_mol_mixture
    oxygen_required_per_kg_mixture = _core.oxygen_required_per_kg_mixture
    fuel_lhv_molar = _core.fuel_lhv_molar
    fuel_lhv_mass = _core.fuel_lhv_mass
    complete_combustion_to_CO2_H2O = _core.complete_combustion_to_CO2_H2O
    complete_combustion_to_CO2_H2O_with_fraction = (
        _core.complete_combustion_to_CO2_H2O_with_fraction
    )
    # State-based API
    MixtureState = _core.MixtureState
    State = _core.State
    Stream = _core.Stream
    Registry = _core.Registry
    mix = _core.mix
    # Inverse solvers - find fuel stream
    set_fuel_stream_for_Tad = _core.set_fuel_stream_for_Tad
    set_fuel_stream_for_O2 = _core.set_fuel_stream_for_O2
    set_fuel_stream_for_O2_dry = _core.set_fuel_stream_for_O2_dry
    set_fuel_stream_for_CO2 = _core.set_fuel_stream_for_CO2
    set_fuel_stream_for_CO2_dry = _core.set_fuel_stream_for_CO2_dry
    # Inverse solvers - find oxidizer stream
    set_oxidizer_stream_for_Tad = _core.set_oxidizer_stream_for_Tad
    set_oxidizer_stream_for_O2 = _core.set_oxidizer_stream_for_O2
    set_oxidizer_stream_for_O2_dry = _core.set_oxidizer_stream_for_O2_dry
    set_oxidizer_stream_for_CO2 = _core.set_oxidizer_stream_for_CO2
    set_oxidizer_stream_for_CO2_dry = _core.set_oxidizer_stream_for_CO2_dry
    CombustionMethod = _core.CombustionMethod
    CombustionState = _core.CombustionState
    complete_combustion = _core.complete_combustion
    complete_combustion_isothermal = _core.complete_combustion_isothermal
    wgs_equilibrium = _core.wgs_equilibrium
    wgs_equilibrium_adiabatic = _core.wgs_equilibrium_adiabatic
    smr_wgs_equilibrium = _core.smr_wgs_equilibrium
    smr_wgs_equilibrium_adiabatic = _core.smr_wgs_equilibrium_adiabatic
    reforming_equilibrium = _core.reforming_equilibrium
    reforming_equilibrium_adiabatic = _core.reforming_equilibrium_adiabatic
    combustion_equilibrium = _core.combustion_equilibrium
    sharp_area_change = _core.sharp_area_change
    conical_area_change = _core.conical_area_change
    AreaChangeResult = _core.AreaChangeResult

    AreaChangeElementResult = _core.AreaChangeElementResult
    # Compressible flow
    CompressibleFlowSolution = _core.CompressibleFlowSolution
    NozzleStation = _core.NozzleStation
    NozzleSolution = _core.NozzleSolution
    FannoStation = _core.FannoStation
    FannoSolution = _core.FannoSolution
    IncompressibleFlowSolution = _core.IncompressibleFlowSolution
    nozzle_flow = _core.nozzle_flow
    solve_A_eff_from_mdot = _core.solve_A_eff_from_mdot
    solve_P_back_from_mdot = _core.solve_P_back_from_mdot
    solve_P0_from_mdot = _core.solve_P0_from_mdot
    critical_pressure_ratio = _core.critical_pressure_ratio
    mach_from_pressure_ratio = _core.mach_from_pressure_ratio
    mach_number = _core.mach_number
    mass_flux_isentropic = _core.mass_flux_isentropic
    nozzle_cd = _core.nozzle_cd
    fanno_max_length = _core.fanno_max_length
    # Thrust
    ThrustResult = _core.ThrustResult
    nozzle_thrust = _core.nozzle_thrust
    nozzle_thrust_cd = _core.nozzle_thrust_cd
    # Friction
    friction_haaland = _core.friction_haaland
    friction_serghides = _core.friction_serghides
    friction_colebrook = _core.friction_colebrook
    friction_petukhov = _core.friction_petukhov
    # Heat transfer
    nusselt_dittus_boelter = _core.nusselt_dittus_boelter
    nusselt_gnielinski = _core.nusselt_gnielinski
    nusselt_sieder_tate = _core.nusselt_sieder_tate
    nusselt_petukhov = _core.nusselt_petukhov
    htc_from_nusselt = _core.htc_from_nusselt
    overall_htc = _core.overall_htc
    overall_htc_wall = _core.overall_htc_wall
    overall_htc_wall_multilayer = _core.overall_htc_wall_multilayer
    thermal_resistance = _core.thermal_resistance
    thermal_resistance_wall = _core.thermal_resistance_wall
    lmtd = _core.lmtd
    lmtd_counterflow = _core.lmtd_counterflow
    lmtd_parallelflow = _core.lmtd_parallelflow
    heat_rate = _core.heat_rate
    heat_flux = _core.heat_flux
    heat_transfer_area = _core.heat_transfer_area
    heat_transfer_dT = _core.heat_transfer_dT
    wall_temperature_profile = _core.wall_temperature_profile

    ntu = _core.ntu
    capacity_ratio = _core.capacity_ratio
    effectiveness_counterflow = _core.effectiveness_counterflow
    effectiveness_parallelflow = _core.effectiveness_parallelflow
    heat_rate_from_effectiveness = _core.heat_rate_from_effectiveness
    heat_flux_from_T_at_edge = _core.heat_flux_from_T_at_edge
    heat_flux_from_T_at_depth = _core.heat_flux_from_T_at_depth
    bulk_T_from_edge_T_and_q = _core.bulk_T_from_edge_T_and_q
    dT_edge_dT_hot = _core.dT_edge_dT_hot
    dT_edge_dT_cold = _core.dT_edge_dT_cold
    dT_edge_dT_bulk = _core.dT_edge_dT_bulk
    dT_edge_dq = _core.dT_edge_dq
    # Acoustics
    Tube = _core.geometry.Tube
    Annulus = _core.geometry.Annulus
    CanAnnularFlowGeometry = _core.geometry.CanAnnularFlowGeometry
    BoundaryCondition = _core.BoundaryCondition
    AcousticMode = _core.AcousticMode
    to_acoustic_geometry = _core.to_acoustic_geometry
    tube_axial_modes = _core.tube_axial_modes
    annulus_axial_modes = _core.annulus_axial_modes
    annulus_azimuthal_modes = _core.annulus_azimuthal_modes
    annulus_modes = _core.annulus_modes
    modes_in_range = _core.modes_in_range
    closest_mode = _core.closest_mode
    min_mode_separation = _core.min_mode_separation
    # Mean flow correction
    axial_mode_upstream = _core.axial_mode_upstream
    axial_mode_downstream = _core.axial_mode_downstream
    axial_mode_split = _core.axial_mode_split
    # Helmholtz resonator
    helmholtz_frequency = _core.helmholtz_frequency
    # Strouhal
    strouhal = _core.strouhal
    frequency_from_strouhal = _core.frequency_from_strouhal
    # Convenience
    quarter_wave_frequency = _core.quarter_wave_frequency
    half_wave_frequency = _core.half_wave_frequency
    # Viscothermal
    stokes_layer = _core.stokes_layer
    thermal_layer = _core.thermal_layer
    effective_viscothermal_layer = _core.effective_viscothermal_layer
    # Quality factor
    helmholtz_Q = _core.helmholtz_Q
    tube_Q = _core.tube_Q
    damping_ratio = _core.damping_ratio
    bandwidth = _core.bandwidth
    # Acoustic properties
    AcousticProperties = _core.AcousticProperties
    acoustic_properties = _core.acoustic_properties
    wavelength = _core.wavelength
    frequency_from_wavelength = _core.frequency_from_wavelength
    acoustic_impedance = _core.acoustic_impedance
    sound_pressure_level = _core.sound_pressure_level
    particle_velocity = _core.particle_velocity
    # Residence time
    residence_time = _core.residence_time
    residence_time_tube = _core.residence_time_tube
    residence_time_annulus = _core.residence_time_annulus
    residence_time_can_annular = _core.residence_time_can_annular
    residence_time_mdot = _core.residence_time_mdot
    residence_time_mdot_can_annular = _core.residence_time_mdot_can_annular
    space_velocity = _core.space_velocity
    # Incompressible flow
    bernoulli_P2 = _core.bernoulli_P2
    bernoulli_v2 = _core.bernoulli_v2
    orifice_mdot = _core.orifice_mdot
    orifice_Q = _core.orifice_Q
    orifice_velocity = _core.orifice_velocity
    orifice_area = _core.orifice_area
    orifice_dP = _core.orifice_dP
    channel_dP = _core.channel_dP
    channel_dP_mdot = _core.channel_dP_mdot
    channel_velocity = _core.channel_velocity
    channel_mdot = _core.channel_mdot
    channel_pressure_drop = _core.channel_pressure_drop
    pressure_drop_channel = _core.channel_pressure_drop
    dynamic_pressure = _core.dynamic_pressure
    velocity_from_q = _core.velocity_from_q
    hydraulic_diameter = _core.hydraulic_diameter
    hydraulic_diameter_rect = _core.hydraulic_diameter_rect
    hydraulic_diameter_annulus = _core.hydraulic_diameter_annulus
    channel_area = _core.circular_area
    channel_volume = _core.cylinder_volume
    channel_roughness = _core.channel_roughness
    standard_channel_roughness = _core.standard_channel_roughness
    annular_area = _core.annular_area
    # Orifice Cd correlations
    OrificeGeometry = _core.OrificeGeometry
    OrificeState = _core.OrificeState
    CdCorrelation = _core.CdCorrelation
    CorrelationValidity = _core.CorrelationValidity
    CorrelationResult = _core.CorrelationResult
    Cd_sharp_thin_plate = _core.Cd_sharp_thin_plate
    Cd_thick_plate = _core.Cd_thick_plate
    Cd_rounded_entry = _core.Cd_rounded_entry
    Cd_orifice = _core.Cd_orifice
    orifice_mdot_Cd = _core.orifice_mdot_Cd
    orifice_dP_Cd = _core.orifice_dP_Cd
    orifice_Cd_from_measurement = _core.orifice_Cd_from_measurement
    orifice_K_from_Cd = _core.orifice_K_from_Cd
    orifice_Cd_from_K = _core.orifice_Cd_from_K
    orifice_thickness_correction = _core.orifice_thickness_correction
    # Orifice flow utilities
    OrificeFlowResult = _core.OrificeFlowResult
    orifice_flow = _core.orifice_flow
    orifice_flow_state = _core.orifice_flow_state
    orifice_velocity_from_mdot = _core.orifice_velocity_from_mdot
    orifice_area_from_beta = _core.orifice_area_from_beta
    beta_from_diameters = _core.beta_from_diameters
    orifice_Re_d_from_mdot = _core.orifice_Re_d_from_mdot
    # Units query API
    UnitInfo = _core.UnitInfo
    get_units = _core.get_units
    input_units = _core.input_units
    output_units = _core.output_units
    has_units = _core.has_units
    list_functions_with_units = _core.list_functions_with_units
    all_units = _core.all_units
    # Channel flow (HTC + pressure drop)
    ChannelResult = _core.ChannelResult
    channel_smooth = _core.channel_smooth
    channel_ribbed = _core.channel_ribbed
    channel_dimpled = _core.channel_dimpled
    channel_pin_fin = _core.channel_pin_fin
    channel_impingement = _core.channel_impingement
    pin_fin_friction = _core.pin_fin_friction
    geometry = _core.geometry

    htc_circular_channel = _core.htc_circular_channel
    nusselt_circular_channel = _core.nusselt_circular_channel
    sharp_area_change = _core.sharp_area_change
    conical_area_change = _core.conical_area_change
    AreaChangeResult = _core.AreaChangeResult

    AreaChangeElementResult = _core.AreaChangeElementResult

# Terminology aliases - always available
try:
    htc_channel = htc_circular_channel
    nusselt_channel = nusselt_circular_channel
    pressure_drop_channel = channel_pressure_drop
    channel_area = circular_area
    channel_volume = cylinder_volume
except NameError:
    # Fallback for complex loading scenarios or missing core extension
    pass

# Submodule imports - always available regardless of _core load path.
from . import compressible, heat_transfer, incompressible, network, species, _solver_tools
from ._flow_solution import FlowSolution


# ---------------------------------------------------------------------------
# suppress_warnings context manager
# ---------------------------------------------------------------------------
from collections.abc import Generator
from contextlib import contextmanager


@contextmanager
def suppress_warnings() -> Generator[None, None, None]:
    """Context manager that silences all combaero correlation warnings.

    Useful for batch solver runs where out-of-range extrapolation warnings
    would flood the output.  The original handler is restored on exit.

    Example::

        with combaero.suppress_warnings():
            result = solver.run()
    """
    try:
        original = get_warning_handler()
    except Exception:
        original = None
    try:
        set_warning_handler(lambda msg: None)
        yield
    finally:
        if original is not None:
            set_warning_handler(original)
        else:
            set_warning_handler(None)


__all__ = [
    "FlowSolution",
    "compressible",
    "geometry",
    "heat_transfer",
    "incompressible",
    "network",
    "species",
    "_solver_tools",
    # Core Constants
    "cp",
    "cp_mass",
    "h",
    "h_mass",
    "s",
    "s_mass",
    "u_mass",
    "cv",
    "cv_mass",
    "u",
    "u_mass",
    "density",
    "specific_gas_constant",
    "isentropic_expansion_coefficient",
    "speed_of_sound",
    "molar_volume",
    "viscosity",
    "thermal_conductivity",
    "kinematic_viscosity",
    "prandtl",
    "thermal_diffusivity",
    "reynolds",
    "peclet",
    "mole_to_mass",
    "mass_to_mole",
    "normalize_fractions",
    "convert_to_dry_fractions",
    "equivalence_ratio_mole",
    "equivalence_ratio",
    "equivalence_ratio_mole",
    "equivalence_ratio_mass",
    "set_equivalence_ratio_mass",
    "equivalence_ratio_from_bilger_Z_mass",
    "bilger_stoich_mixture_fraction_mass",
    "bilger_Z_from_equivalence_ratio_mass",
    "expansibility_factor",
    "solve_orifice_mdot",
    "dry_air",
    "humid_air_composition",
    "humid_air_density",
    "humid_air_enthalpy",
    "humid_air_enthalpy_nasa9",
    "humidity_ratio",
    "saturation_vapor_pressure",
    "vapor_pressure",
    "water_vapor_mole_fraction",
    "wet_bulb_temperature",
    "dewpoint",
    "relative_humidity_from_dewpoint",
    "formula_to_name",
    "name_to_formula",
    "common_name",
    "formula",
    "calc_T_from_h",
    "calc_T_from_h_mass",
    "calc_T_from_s",
    "calc_T_from_s_mass",
    "calc_T_from_cp",
    "calc_T_from_u",
    "calc_T_from_u_mass",
    "calc_T_from_sv_mass",
    "calc_T_from_sh_mass",
    "oxygen_required_per_mol_fuel",
    "oxygen_required_per_kg_fuel",
    "oxygen_required_per_mol_mixture",
    "oxygen_required_per_kg_mixture",
    "fuel_lhv_molar",
    "fuel_lhv_mass",
    "complete_combustion_to_CO2_H2O",
    "complete_combustion_to_CO2_H2O_with_fraction",
    # State-based API
    "State",
    "MixtureState",
    "Stream",
    "HumidAir",
    "AirProperties",
    "air_properties",
    "ThermoState",
    "thermo_state",
    "TransportState",
    "transport_state",
    "CompleteState",
    "complete_state",
    "EquilibriumResult",
    "CombustionMethod",
    "CombustionState",
    "combustion_state",
    "combustion_state_from_streams",
    "mix",
    # Materials database
    "k_inconel718",
    "k_haynes230",
    "k_stainless_steel_316",
    "k_aluminum_6061",
    "k_tbc_ysz",
    "list_materials",
    # Advanced cooling correlations
    "rib_enhancement_factor",
    "rib_enhancement_factor_high_re",
    "rib_friction_multiplier",
    "rib_friction_multiplier_high_re",
    "thermal_performance_factor",
    "impingement_nusselt",
    "film_cooling_effectiveness",
    "film_cooling_effectiveness_avg",
    "film_cooling_multirow_sellers",
    "effusion_effectiveness",
    "effusion_discharge_coefficient",
    "pin_fin_nusselt",
    "pin_fin_friction",
    "dimple_nusselt_enhancement",
    "dimple_friction_multiplier",
    "adiabatic_wall_temperature",
    "cooled_wall_heat_flux",
    # Channel flow (HTC + pressure drop)
    "ChannelResult",
    "channel_smooth",
    "channel_ribbed",
    "channel_dimpled",
    "channel_pin_fin",
    "channel_impingement",
    "heat_transfer",
    # Inverse solvers - find fuel stream
    "set_fuel_stream_for_Tad",
    "set_fuel_stream_for_phi",
    "set_fuel_stream_for_O2",
    "set_fuel_stream_for_O2_dry",
    "set_fuel_stream_for_CO2",
    "set_fuel_stream_for_CO2_dry",
    # Inverse solvers - find oxidizer stream
    "set_oxidizer_stream_for_Tad",
    "set_oxidizer_stream_for_O2",
    "set_oxidizer_stream_for_O2_dry",
    "set_oxidizer_stream_for_CO2",
    "set_oxidizer_stream_for_CO2_dry",
    "complete_combustion",
    "complete_combustion_isothermal",
    "wgs_equilibrium",
    "wgs_equilibrium_adiabatic",
    "reforming_equilibrium",
    "reforming_equilibrium_adiabatic",
    "combustion_equilibrium",
    # Compressible flow
    "CompressibleFlowSolution",
    "NozzleStation",
    "NozzleSolution",
    "FannoStation",
    "FannoSolution",
    "nozzle_flow",
    "solve_A_eff_from_mdot",
    "solve_P_back_from_mdot",
    "solve_P0_from_mdot",
    "critical_pressure_ratio",
    "mach_from_pressure_ratio",
    "mass_flux_isentropic",
    "nozzle_cd",
    "fanno_max_length",
    # Thrust
    "ThrustResult",
    "nozzle_thrust",
    "nozzle_thrust_cd",
    # Friction
    "friction_haaland",
    "friction_serghides",
    "friction_colebrook",
    "friction_petukhov",
    "is_whistling_risk",
    "num_species",
    "species_name",
    "species_index_from_name",
    "species_molar_mass",
    "species_molar_mass_from_name",
    # Heat transfer
    "nusselt_dittus_boelter",
    "nusselt_gnielinski",
    "nusselt_sieder_tate",
    "nusselt_petukhov",
    "nusselt_circular_channel",
    "nusselt_channel",
    "htc_from_nusselt",
    "htc_circular_channel",
    "htc_channel",
    "orifice_impedance_with_flow",
    "quarter_wave_resonator_tmm",
    "TransferMatrix",
    "CanAnnularGeometry",
    "BlochMode",
    "can_annular_eigenmodes",
    "AnnularDuctGeometry",
    "AnnularMode",
    "annular_duct_eigenmodes",
    "annular_duct_modes_analytical",
    "AcousticMedium",
    "LinerOrificeGeometry",
    "LinerFlowState",
    "LinerCavity",
    "absorption_from_impedance_norm",
    "liner_sdof_impedance_norm",
    "liner_sdof_absorption",
    "sweep_liner_sdof_absorption",
    "liner_2dof_serial_impedance_norm",
    "liner_2dof_serial_absorption",
    "sweep_liner_2dof_serial_absorption",
    "overall_htc",
    "overall_htc_wall",
    "overall_htc_wall_multilayer",
    "thermal_resistance",
    "thermal_resistance_wall",
    "lmtd",
    "lmtd_counterflow",
    "lmtd_parallelflow",
    "heat_rate",
    "heat_flux",
    "heat_transfer_area",
    "heat_transfer_dT",
    "wall_temperature_profile",
    "ntu",
    "capacity_ratio",
    "effectiveness_counterflow",
    "effectiveness_parallelflow",
    "heat_rate_from_effectiveness",
    "heat_flux_from_T_at_edge",
    "heat_flux_from_T_at_depth",
    "bulk_T_from_edge_T_and_q",
    "dT_edge_dT_hot",
    "dT_edge_dT_cold",
    "dT_edge_dT_bulk",
    "dT_edge_dq",
    # Acoustics
    "Tube",
    "Annulus",
    "CanAnnularFlowGeometry",
    "BoundaryCondition",
    "AcousticMode",
    "to_acoustic_geometry",
    "tube_axial_modes",
    "annulus_axial_modes",
    "annulus_azimuthal_modes",
    "annulus_modes",
    "modes_in_range",
    "closest_mode",
    "min_mode_separation",
    # Mean flow correction
    "axial_mode_upstream",
    "axial_mode_downstream",
    "axial_mode_split",
    # Helmholtz resonator
    "helmholtz_frequency",
    # Strouhal
    "strouhal",
    "frequency_from_strouhal",
    # Convenience
    "quarter_wave_frequency",
    "half_wave_frequency",
    # Viscothermal
    "stokes_layer",
    "thermal_layer",
    "effective_viscothermal_layer",
    # Quality factor
    "helmholtz_Q",
    "tube_Q",
    "damping_ratio",
    "bandwidth",
    # Acoustic properties
    "AcousticProperties",
    "acoustic_properties",
    "wavelength",
    "frequency_from_wavelength",
    "acoustic_impedance",
    "sound_pressure_level",
    "particle_velocity",
    # Residence time
    "residence_time",
    "residence_time_tube",
    "residence_time_annulus",
    "residence_time_can_annular",
    "residence_time_mdot",
    "residence_time_mdot_can_annular",
    "space_velocity",
    # Incompressible flow
    "bernoulli_P2",
    "bernoulli_v2",
    "orifice_mdot",
    "orifice_Q",
    "orifice_velocity",
    "orifice_area",
    "orifice_dP",
    "channel_dP",
    "channel_dP_mdot",
    "channel_velocity",
    "channel_mdot",
    "channel_pressure_drop",
    "pressure_drop_channel",
    "channel_area",
    "channel_volume",
    "channel_roughness",
    "standard_channel_roughness",
    "circular_area",
    "cylinder_volume",
    "dynamic_pressure",
    # Orifice Cd correlations
    "OrificeGeometry",
    "OrificeState",
    "CdCorrelation",
    "CorrelationValidity",
    "CorrelationResult",
    "Cd_sharp_thin_plate",
    "Cd_thick_plate",
    "Cd_rounded_entry",
    "Cd_orifice",
    "orifice_mdot_Cd",
    "orifice_dP_Cd",
    "orifice_Cd_from_measurement",
    "orifice_K_from_Cd",
    "orifice_Cd_from_K",
    "orifice_thickness_correction",
    # Orifice flow utilities
    "OrificeFlowResult",
    "orifice_flow",
    "orifice_flow_state",
    "orifice_velocity_from_mdot",
    "orifice_area_from_beta",
    "beta_from_diameters",
    "orifice_Re_d_from_mdot",
    # Units query API
    "UnitInfo",
    "get_units",
    "input_units",
    "output_units",
    "has_units",
    "list_functions_with_units",
    "all_units",
    "sharp_area_change",
    "conical_area_change",
    "AreaChangeResult",
    "AreaChangeElementResult",
    "__version__",
]
