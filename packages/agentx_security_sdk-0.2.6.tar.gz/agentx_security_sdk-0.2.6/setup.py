import os
from setuptools import setup, find_packages

# Safely read README.md if it exists, otherwise use a default string
long_description = "The self-healing exception handler for autonomous AI agents."
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()

setup(
    name="agentx-security-sdk",
    version="0.2.6",
    author="AgentX Core Team", 
    author_email="founders@agentx-core.com",
    description="The self-healing exception handler for autonomous AI agents.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/vdalal/semantic-gateway", 
    packages=find_packages(include=["agentx_sdk", "agentx_sdk.*"]),
    install_requires=[
        "requests>=2.25.0",
    ],
    # 💡 THE observabilty entrypoint mapping hook
    entry_points={
        'console_scripts': [
            'agentx=agentx_sdk.cli:main',
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License", 
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
