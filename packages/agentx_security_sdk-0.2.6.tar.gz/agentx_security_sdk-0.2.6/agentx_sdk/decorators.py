import os
import json
import atexit
import time
import functools
import uuid
from posthog import poll_interval
import requests
import re
from contextvars import ContextVar

from .client import AgentXClient
from .db import init_db, log_intercept, get_lifetime_stats, log_self_correction

_client = AgentXClient()

# Initialize the local SQLite DB on startup
init_db()

# --- 0. THE TRACE ID CONTEXT ---
trace_id_var: ContextVar[str] = ContextVar("trace_id", default="")

def start_secure_session():
    """Call this at the top of your agent script to group logs into a single session."""
    session_id = str(uuid.uuid4())
    trace_id_var.set(session_id)
    return session_id

# --- NEW: CIRCUIT BREAKER EXCEPTION ---
class AgentXCircuitBreakerTripped(Exception):
    """Raised when an agent is caught in an infinite apology loop."""
    pass

# --- 1. THE SESSION TRACKER & EXIT SUMMARY ---
_session_stats = {
    "start_time": time.time(),
    "total_calls": 0,
    "intercepts": 0,
    "critical_blocks": 0,
    "self_corrections": 0,
    "last_call_was_challenge": False,  # <-- Tracks the cognitive pivot state
    "consecutive_strikes": {}, # <-- Tracks strikes per function
    "circuit_breakers_tripped": 0
}

def _print_agentx_summary():
    """Fires automatically when the developer's script ends or crashes."""
    
    # Only print if we actually did something this session to avoid terminal spam
    if _session_stats["total_calls"] == 0 and _session_stats["intercepts"] == 0:
        return
        
    duration = round(time.time() - _session_stats["start_time"], 2)
    session_tokens = _session_stats["intercepts"] * 1500
    session_time = _session_stats["intercepts"] * 5
    
    # Calculate the Hero Metric: Self-Correction Rate
    scr = 0
    if _session_stats["intercepts"] > 0:
        scr = round((_session_stats["self_corrections"] / _session_stats["intercepts"]) * 100, 1)
    
    # Circuit breaker trips
    cb_trips = _session_stats.get("circuit_breakers_tripped", 0)
    
    # Calculate hypothetical savings (e.g., preventing 10 loop iterations)
    loop_tokens_saved = cb_trips * 15000 
    loop_time_saved = cb_trips * 50

    # Fetch historical data
    try:
        history = get_lifetime_stats()
        if not history:
            raise ValueError("No history")
    except Exception:
        # Fallback if the local DB is fresh or errors out
        history = {
            "total_intercepts": _session_stats["intercepts"],
            "total_critical": _session_stats["critical_blocks"],
            "total_tokens": session_tokens,
            "total_time": session_time,
            "top_offender": None
        }
        
    print("\n" + "═"*60)
    print(f" 🛡️  AgentX Session Summary (Trace: {trace_id_var.get() or 'N/A'})")
    print("═"*60)
    print(f" ⏱️  Uptime:                {duration} seconds")
    print(f" 🛠️  Tools Monitored:       {_session_stats['total_calls']}")
    print("─"*60)
    
    # The Action-Oriented UI
        
    # 1. Calculate Session Recovery Rate
    session_recovery_rate = 0.0
    if _session_stats["intercepts"] > 0:
        session_recovery_rate = (_session_stats["self_corrections"] / _session_stats["intercepts"]) * 100

    # 2. Calculate Cumulative Recovery Rate
    cumulative_recovery_rate = 0.0
    if history['total_intercepts'] > 0:
        cumulative_recovery_rate = (history.get('total_self_corrections', 0) / history['total_intercepts']) * 100

    # 3. Print the aligned matrix
    print(f" 🛑 Intercepts:            {_session_stats['intercepts']:<3} |  Cumulative: {history['total_intercepts']}")
    print(f" 💥 Critical Blocks:       {_session_stats['critical_blocks']:<3} |  Cumulative: {history['total_critical']}")
        
    # --- CIRCUIT BREAKER METRICS ---
    if cb_trips > 0:
        print(f" 🔌 Breakers Tripped:      {cb_trips:<3} |  Loop Savings: ~{loop_tokens_saved} tokens")
        # Add the loop savings to BOTH the session stats and the cumulative stats
        session_tokens += loop_tokens_saved
        session_time += loop_time_saved
        history['total_tokens'] += loop_tokens_saved
        history['total_time'] += loop_time_saved

    print(f" 🔄 Self-Corrections:      {_session_stats['self_corrections']:<3} |  Cumulative: {history.get('total_self_corrections', 0)}")
    print(f" 📈 Recovery Rate:         {session_recovery_rate:<3.1f}% |  Cumulative: {cumulative_recovery_rate:.1f}%")
    print(f" 💰 Tokens Saved:         ~{session_tokens:<3} |  Cumulative: ~{history['total_tokens']}")
    print(f" ⏳ Time Saved:           ~{session_time}s  |  Cumulative: ~{history['total_time']}s")
    
    # The 5+ Block Threshold for the Health Report
    if history.get('total_intercepts', 0) >= 5 and history.get('top_offender'):
        print("═"*60)
        print(" 🩺 AGENT HEALTH INSIGHT")
        print("─"*60)
        print(f" ⚠️  Top Offender: '{history['top_offender']}'")
        print(" 💡 Tip: Consider refining your agent's system prompt to avoid this.")
        
    print("═"*60 + "\n")

atexit.register(_print_agentx_summary)
# --------------------------

# --- NEW: STANDALONE EVALUATOR (Solves the Latency Trap) ---
def _local_standalone_evaluate(query: str, cot: str):
    """Evaluates intent locally using AST for speed, and Gemini for semantics."""
    
    # ⚡ FAST PATH: AST Parsing (~2ms latency)
    try:
        import sqlglot
        parsed = sqlglot.parse_one(query)
        # If it's just a SELECT, mathematically it cannot be a destructive write.
        if parsed.key == "select":
            return {"status": "ALLOWED"}
    except ImportError:
        print("⚠️ [AgentX] Warning: 'sqlglot' not installed. AST Fast-Path disabled.")
    except Exception:
        # Not SQL, or invalid SQL. Fall through to the LLM semantic check.
        pass

    # 🧠 SLOW PATH: Local Semantic Eval (~400ms latency)
    gemini_key = os.environ.get("GEMINI_API_KEY")
    if not gemini_key:
        raise ValueError("AgentX Standalone Mode requires GEMINI_API_KEY to evaluate non-read intents.")
    
    from google import genai
    client = genai.Client(api_key=gemini_key)
    prompt = f"Does the intent '{cot}' to run '{query}' represent a DESTRUCTIVE_WRITE? Reply exactly with YES or NO."
    
    try:
        llm_res = client.models.generate_content(model='gemini-2.5-flash', contents=prompt).text
        if "YES" in llm_res.upper():
             return {
                "error": "AgentX Policy Violation",
                "policy_id": "POL-LOC-001",
                "policy_triggered": "Mass Destructive Intent",
                "challenge": "You are attempting a destructive action. Revise to a SAFE_WRITE or READ."
            }
        return {"status": "ALLOWED"}
    except Exception as e:
        return {"error": "Local Eval Failed", "message": str(e)}


# --- THE EGRESS SCRUBBER (Zero-Knowledge DLP) ---
def _scrub_pii(data, pii_targets):
    """
    Recursively traverses dicts, lists, and strings to redact PII locally.
    Guarantees raw data never leaves the developer's VPC.
    """
    if not pii_targets or not data:
        return data

    # Simple regex dictionary for MVP (We will replace this with Presidio locally later)
    regex_map = {
        "EMAIL": r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+',
        "PHONE": r'(\+\d{1,2}\s?)?1?\-?\.?\s?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}'
    }

    if isinstance(data, str):
        scrubbed_string = data
        for target in pii_targets:
            target_upper = target.upper()
            if target_upper in regex_map:
                scrubbed_string = re.sub(regex_map[target_upper], f"[REDACTED_{target_upper}]", scrubbed_string)
        return scrubbed_string

    elif isinstance(data, dict):
        return {k: _scrub_pii(v, pii_targets) for k, v in data.items()}
    
    elif isinstance(data, list):
        return [_scrub_pii(item, pii_targets) for item in data]
    
    return data

def agentx_protect(agent_id: str, extract_query_func=None, extract_cot_func=None):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _session_stats["total_calls"] += 1
            func_name = func.__name__ # <-- Grab the function name

            # --- NEW: INITIALIZE & CHECK STRIKES ---
            if func_name not in _session_stats["consecutive_strikes"]:
                _session_stats["consecutive_strikes"][func_name] = 0

            if _session_stats["consecutive_strikes"][func_name] >= 3:
                _session_stats["circuit_breakers_tripped"] += 1  # <-- Log the trip
                raise AgentXCircuitBreakerTripped(
                    f"AgentX killed the run. Agent failed to self-correct on '{func_name}' 3 times in a row. "
                    f"Halting to prevent token drain."
                )
            
            # --- TRACE ID LOGIC ---
            current_trace_id = trace_id_var.get()
            if not current_trace_id:
                # Auto-start a session if the developer forgot to call start_secure_session()
                current_trace_id = start_secure_session()
            
            # =========================================================
            # 🛡️ HARDENED REFLECTIVE INGESTION CONTRACT
            # =========================================================
            # Replacing the fragile assignments with reflective parsing.
            # This captures the true function execution signature text values
            # even when the agent loops alter the structure on retry turns.
            # =========================================================
            try:
                # Dynamically serialize arguments into a standardized call trace string
                arg_str = ", ".join([f"'{a}'" if isinstance(a, str) else str(a) for a in args])
                kwarg_str = ", ".join([f"{k}='{v}'" if isinstance(v, str) else f"{k}={v}" for k, v in kwargs.items()])
                combined_args = ", ".join(filter(None, [arg_str, kwarg_str]))
                
                # Check custom extractor first, but catch structural '()' failures on turn-2
                query = extract_query_func(*args, **kwargs) if extract_query_func else None
                if not query or query == "()" or "unknown" in str(query).lower():
                    query = f"{func_name}({combined_args})"
            except Exception:
                query = f"{func_name}({str(args)})"
                
            try:
                chain_of_thought = extract_cot_func(*args, **kwargs) if extract_cot_func else None
                if not chain_of_thought or chain_of_thought in ["", "Implicit tool call"]:
                    chain_of_thought = f"Autonomous self-correction sequence verified for tool: '{func_name}'"
            except Exception:
                chain_of_thought = "Implicit tool call execution thread context trace."

            receipt_id = kwargs.get("receipt_id", None)

            print(f"\n🛡️ [AgentX SDK] Intercepting tool call to '{func.__name__}'...")

            # =========================================================
            # OPTION 1: THE LIVE FASTAPI WEDGE CALL
            # =========================================================
            eval_res = _client.evaluate_intent(
                agent_id=agent_id, 
                query=query, 
                chain_of_thought=chain_of_thought,
                receipt_id=receipt_id,
                trace_id=current_trace_id
            )

            status = eval_res.get("status") if isinstance(eval_res, dict) else None

            # 1. Check for the Unified Gateway's Block Signal
            if isinstance(eval_res, dict) and eval_res.get("error") == "AgentX Policy Violation":
                _session_stats["intercepts"] += 1
                _session_stats["consecutive_strikes"][func_name] += 1
                
                # +++ SENSOR: Track that we challenged the agent
                _session_stats["last_call_was_challenge"] = True
                
                actual_policy_id = eval_res.get("policy_id", "POL-UNKNOWN") 
                policy_name = eval_res.get("policy_triggered", "Unknown Policy")
                challenge_text = eval_res.get("challenge", "Policy violation detected. Please revise your intent.")
                returned_receipt_id = eval_res.get("receipt_id", "no-receipt")
                
                critical_policies = [
                    "Mass Destructive Intent", 
                    "Database Isolation", 
                    "Secrets and PII Exfiltration", 
                    "Out-of-Bounds Execution"
                ]
                
                if policy_name in critical_policies:
                    _session_stats["critical_blocks"] += 1

                log_intercept(func.__name__, actual_policy_id, policy_name, "CHALLENGED")

                print(f"🛑 [AgentX SDK] Policy '{policy_name}' violated. Returning challenge instruction string.")
                
                # ⚡ THE SURGICAL FIX B INSERTION LAYER:
                # Instead of dumping a data dictionary, return a structured instructional warning string.
                # Standard agent framework loop environments channel this raw text straight back as a system 
                # Observation token, forcing the model's inner monologue to self-correct naturally.
                return (
                    f"🚨 [AgentX Security Block] Action intercepted by runtime policy: '{policy_name}'. "
                    f"Challenge/Constraint: {challenge_text} "
                    f"System Instruction: Your request has been blocked. Analyze this security barrier, "
                    f"adjust your parameters payload to be safe, change your execution query path, "
                    f"and retry your tool execution turn immediately."
                )

            # 2. Check for the Escalation Handoff (The HITL Polling Loop)
            elif isinstance(eval_res, dict) and eval_res.get("status") == "ESCALATED":
                receipt_id = eval_res.get("receipt_id")
                print(f"\n🚨 [AgentX SDK] Task suspended. Request escalated to Human SOC.")
                print(f"⏳ [AgentX SDK] Polling for human decision (Receipt: {receipt_id})...")
                
                api_key = os.environ.get("AGENTX_API_KEY")
                headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
                
                max_poll_seconds = 120 # 2-minute max wait
                poll_interval = 3
                elapsed = 0
                
                # The Polling Loop
                while elapsed < max_poll_seconds:
                    time.sleep(poll_interval)
                    elapsed += poll_interval
    
                    try:
                        status_check = requests.get(
                            f"{_client.gateway_url}/v1/status/{receipt_id}",
                            headers=headers,
                            timeout=2.0
                        )
                        if status_check.status_code == 200:
                            current_status = status_check.json().get("status")
                            
                            if current_status == "APPROVED":
                                print(f"\n✅ [AgentX SDK] Human SOC APPROVED the override!")
                                # Reset state, this wasn't a self-correction, human bypassed it.
                                _session_stats["last_call_was_challenge"] = False 
                                return func(*args, **kwargs)
                                
                            elif current_status == "DENIED":
                                print(f"\n❌ [AgentX SDK] Human SOC DENIED the override.")
                                return json.dumps({
                                    "error": "AgentX Human Override Denied",
                                    "instruction": "The SOC analyst explicitly denied this action. You must find an alternative path or fail the task."
                                })
                                
                        elif status_check.status_code == 401:
                            print(f"\n❌ [AgentX SDK] Auth Error: Gateway rejected polling request.")
                            return json.dumps({"error": "Unauthorized Polling"})
                            
                    except requests.exceptions.RequestException as e:
                        print(f"⚠️ Ignore transient network drops. Keep trying. Polling error: {e}")
                        
                if elapsed >= max_poll_seconds:
                    print("⚠️ [AgentX SDK] SOC Polling Timeout reached. Failing safe.")
                    return "AgentX Error: Timeout waiting for SOC approval. Aborting action."

            # 3. Check for the "Success" path
            elif isinstance(eval_res, dict) and eval_res.get("status") in ["success", "ALLOWED"]:
                print(f"✅ [AgentX SDK] Intent safe. Executing '{func.__name__}'.")

                # Reset metrics
                _session_stats["consecutive_strikes"][func_name] = 0
                
                # +++ SENSOR: Check if this was a successful recovery!
                if _session_stats.get("last_call_was_challenge"):
                    _session_stats["self_corrections"] += 1
                    _session_stats["last_call_was_challenge"] = False
                    log_self_correction(trace_id_var.get(), agent_id, func_name)
                    
                # Fix: Actually execute the function instead of returning the Gateway's JSON
                # --- 1. LOCAL EXECUTION (Gateway is completely out of the loop) ---
                raw_result = func(*args, **kwargs)

                # --- 2. EGRESS SCRUBBING (Zero-Knowledge DLP) ---
                # We look for the instructions sent down by the Gateway
                pii_targets = eval_res.get("pii_targets_to_scrub", [])

                if pii_targets:
                    print(f"🧹 [AgentX SDK] Local DLP Active. Scrubbing {pii_targets} from output...")
                    return _scrub_pii(raw_result, pii_targets)
                
                # If no PII targets were flagged by the Gateway, return the raw result safely
                return raw_result

            # 4. Handle actual Gateway crashes
            else:
                error_detail = eval_res.get("message") if isinstance(eval_res, dict) else "Unknown Connection Error"
                return f"AgentX System Error: {error_detail}"
                
        return wrapper
    return decorator