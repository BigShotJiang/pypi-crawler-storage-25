import os
import sys
import requests

GATEWAY_URL = os.environ.get("AGENTX_GATEWAY_URL", "http://localhost:8000")

def main():
    """AgentX Local Policy Inspection and Telemetry Verification CLI."""
    print("=" * 75)
    print("🛡️  AGENTX LOCAL OBSERVABILITY ENGINE")
    print("=" * 75)
    
    # 🛑 MITIGATION: Extract the developer's API key to pass container middleware checks
    api_key = os.environ.get("AGENTX_API_KEY")
    if not api_key:
        print("❌ Error: AGENTX_API_KEY is missing from your terminal session environment.")
        print("   Please export your active key before querying the edge node:")
        print("   set AGENTX_API_KEY=your_key_here (Windows)")
        print("   export AGENTX_API_KEY=your_key_here (Linux/Mac)")
        print("=" * 75)
        sys.exit(1)

    headers = {
        "Authorization": f"Bearer {api_key}"
    }
    
    # 1. Probe the local container endpoints with authorization headers
    try:
        telemetry_res = requests.get(f"{GATEWAY_URL}/v1/telemetry", headers=headers, timeout=2.0)
        policy_res = requests.get(f"{GATEWAY_URL}/v1/debug/policies", headers=headers, timeout=2.0)
    except requests.exceptions.ConnectionError:
        print(f"❌ Error: Unable to communicate with the AgentX Gateway at {GATEWAY_URL}")
        print("   -> Is your Docker gateway container up and healthy? (`docker ps`)")
        print("=" * 75)
        sys.exit(1)

    # Clean debugging: If it still fails, let's show the developer the EXACT status codes
    if telemetry_res.status_code != 200 or policy_res.status_code != 200:
        print(f"❌ Error: Gateway contract validation failed.")
        print(f"   -> /v1/telemetry status: {telemetry_res.status_code}")
        print(f"   -> /v1/debug/policies status: {policy_res.status_code}")
        print("=" * 75)
        sys.exit(1)

    telemetry = telemetry_res.json().get("mission_control", {})
    policies_data = policy_res.json()
    
    # 2. Render Live Container Metrics Standardized with SDK nomenclature
    print("\n📊 CONTAINER TELEMETRY ENGINE (CURRENT LIFECYCLE):")
    print(f"  🛑 Total Intercepts:        {telemetry.get('total_intercepts', 0)}")
    print(f"  🧠 Socratic Challenges:     {telemetry.get('socratic_nudges_issued', 0)}")
    print(f"  🚨 Human Escalations (HITL): {telemetry.get('human_escalations_required', 0)}")
    print(f"  🔄 Self-Corrections (Pivots):{telemetry.get('successful_agent_pivots', 0)}")
    print(f"  📈 Recovery Rate:           {telemetry.get('agent_self_correction_rate_percent', 0.0)}%")
    print(f"  🎛️  Neural Sensitivity:      {policies_data.get('neural_threshold', 0.30)}")
    print(f"  ☁️  Control Plane Target:    {policies_data.get('control_plane_url')}")
    
    # 3. Render In-Memory Policy Layout Matrix
    print("\n🛡️  ARMED POLICY ENGINE MATRIX:")
    print(f" {'Policy Name / Definition':<32} | {'Target Action':<22} | {'Status':<8}")
    print(" " + "-" * 71)
    
    policies = policies_data.get("policies", [])
    if not policies:
        print("  ⚠️ No active policies found in gateway RAM cache.")
    else:
        for policy in policies:
            name = policy.get("name", "Unnamed Rule")
            action = policy.get("target_action", "Neural Intercept")
            
            if len(name) > 31:
                name = name[:28] + "..."
            print(f"  {name:<31} | {action:<22} | ARMED")
            
    print("\n💡 Developer Tip: Adjust threshold settings dynamically by configuring the")
    print("   `AGENTX_NEURAL_THRESHOLD` environment variable in your deployment layout.")
    print("=" * 75)

if __name__ == "__main__":
    main()