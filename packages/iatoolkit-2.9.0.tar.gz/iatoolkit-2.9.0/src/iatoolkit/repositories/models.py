# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit
#
# IAToolkit is open source software.

from sqlalchemy import Column, Integer, BigInteger, String, DateTime, Enum, Text, JSON, Boolean, ForeignKey, Table, MetaData
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import relationship, class_mapper
from sqlalchemy.sql import func
from sqlalchemy import UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from datetime import datetime
from pgvector.sqlalchemy import Vector
import enum


# Canonical ORM schema for the platform tables.
# SQLite tests translate this schema to None at engine level.
ORM_SCHEMA = "iatoolkit"


# base class for the ORM
class Base(DeclarativeBase):
    metadata = MetaData(schema=ORM_SCHEMA)


class DocumentStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    ACTIVE = "active"
    FAILED = "failed"


class PromptExecutionMode(str, enum.Enum):
    CONVERSATIONAL = "conversational"
    AGENTIC = "agentic"


class PromptResourceType(str, enum.Enum):
    SQL_SOURCE = "sql_source"
    RAG_COLLECTION = "rag_collection"


class MemoryItemType(str, enum.Enum):
    CHAT_USER_MESSAGE = "chat_user_message"
    CHAT_ASSISTANT_MESSAGE = "chat_assistant_message"
    NOTE = "note"
    LINK = "link"
    FILE = "file"
    IMAGE = "image"


class MemoryItemStatus(str, enum.Enum):
    PENDING = "pending"
    COMPILED = "compiled"
    FAILED = "failed"


class MemoryCaptureStatus(str, enum.Enum):
    PENDING = "pending"
    COMPILED = "compiled"
    FAILED = "failed"


# Cross-database JSON type:
# - PostgreSQL: JSONB (for jsonb operators/functions/indexing)
# - SQLite/others (tests): JSON
JSON_NATIVE = JSON().with_variant(JSONB, "postgresql")


# relation table for many-to-many relationship between companies and users
user_company = Table('iat_user_company',
                     Base.metadata,
                    Column('user_id', Integer,
                           ForeignKey(f'{ORM_SCHEMA}.iat_users.id', ondelete='CASCADE'),
                                primary_key=True),
                     Column('company_id', Integer,
                            ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',ondelete='CASCADE'),
                                primary_key=True),
                     Column('role', String, nullable=True, default='user'),
                     Column('created_at', DateTime, default=datetime.now)
                     )

class ApiKey(Base):
    """Represents an API key for a company to authenticate against the system."""
    __tablename__ = 'iat_api_keys'

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id', ondelete='CASCADE'), nullable=False)
    key_name = Column(String, nullable=False)
    key = Column(String, unique=True, nullable=False, index=True) # La API Key en sí
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.now)
    last_used_at = Column(DateTime, nullable=True) # Opcional: para rastrear uso

    company = relationship("Company", back_populates="api_keys")


class Company(Base):
    """Represents a company or tenant in the multi-tenant system."""
    __tablename__ = 'iat_companies'

    id = Column(Integer, primary_key=True, autoincrement=True)
    short_name = Column(String, nullable=False, unique=True, index=True)
    name = Column(String, nullable=False)
    is_active = Column(Boolean, nullable=False, default=True, index=True)
    runtime_mode = Column(String(32), nullable=False, default='static', index=True)

    parameters = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.now)

    documents = relationship("Document",
                             back_populates="company",
                             cascade="all, delete-orphan",
                             lazy='dynamic')
    tools = relationship("Tool",
                           back_populates="company",
                           cascade="all, delete-orphan")
    vsdocs = relationship("VSDoc",
                          back_populates="company",
                          cascade="all, delete-orphan")
    vsimages = relationship("VSImage",
                        back_populates="company",
                        cascade="all, delete-orphan")
    llm_queries = relationship("LLMQuery",
                               back_populates="company",
                               cascade="all, delete-orphan")
    users = relationship("User",
                         secondary=user_company,
                         back_populates="companies")
    api_keys = relationship("ApiKey",
                            back_populates="company",
                            cascade="all, delete-orphan")

    feedbacks = relationship("UserFeedback",
                               back_populates="company",
                               cascade="all, delete-orphan")
    prompts = relationship("Prompt",
                             back_populates="company",
                             cascade="all, delete-orphan")
    collection_types = relationship(
        "CollectionType",
        back_populates="company",
        cascade="all, delete-orphan"
    )
    sql_sources = relationship(
        "SqlSource",
        back_populates="company",
        cascade="all, delete-orphan",
    )
    sql_datasets = relationship(
        "SqlDataset",
        back_populates="company",
        cascade="all, delete-orphan",
    )
    mcp_personal_access_tokens = relationship(
        "McpPersonalAccessToken",
        back_populates="company",
        cascade="all, delete-orphan",
    )
    memory_items = relationship(
        "MemoryItem",
        back_populates="company",
        cascade="all, delete-orphan",
    )
    memory_captures = relationship(
        "MemoryCapture",
        back_populates="company",
        cascade="all, delete-orphan",
    )
    memory_pages = relationship(
        "MemoryPage",
        back_populates="company",
        cascade="all, delete-orphan",
    )


    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}

# users with rights to use this app
class User(Base):
    """Represents an IAToolkit user who can be associated with multiple companies."""
    __tablename__ = 'iat_users'

    id = Column(Integer, primary_key=True, autoincrement=True)
    email = Column(String, unique=True, nullable=False)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.now)
    password = Column(String, nullable=True)
    auth_method = Column(String(16), nullable=False, default='local', index=True)
    google_sub = Column(String, unique=True, nullable=True, index=True)
    google_email = Column(String, nullable=True)
    google_email_verified = Column(Boolean, nullable=False, default=False)
    google_linked_at = Column(DateTime, nullable=True)
    verified = Column(Boolean, nullable=False, default=False)
    preferred_language = Column(String, nullable=True)
    verification_url = Column(String, nullable=True)
    temp_code = Column(String, nullable=True)

    companies = relationship(
        "Company",
        secondary=user_company,
        back_populates="users",
        cascade="all",
        passive_deletes=True,
        lazy='dynamic'
    )

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'created_at': str(self.created_at),
            'auth_method': self.auth_method,
            'verified': self.verified,
            'companies': [company.to_dict() for company in self.companies]
        }

class Tool(Base):
    """Represents a custom or system function that the LLM can call (tool)."""
    __tablename__ = 'iat_tools'

    # Execution types
    TYPE_SYSTEM = 'SYSTEM'
    TYPE_NATIVE = 'NATIVE'       # executed by company class in Python
    TYPE_INFERENCE = 'INFERENCE' # executed by InferenceService
    TYPE_HTTP = 'HTTP'           # executed by HttpToolService

    # source of the definition (Source of Truth)
    SOURCE_SYSTEM = 'SYSTEM'
    SOURCE_YAML = 'YAML'         # defined in company.yaml
    SOURCE_USER = 'USER'         # defined via GUI/API
    SOURCE_PACK = 'PACK'         # materialized by enterprise control-plane

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer,
                        ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',ondelete='CASCADE'),
                        nullable=True)
    name = Column(String, nullable=False)
    tool_type = Column(String, default=TYPE_NATIVE, nullable=False)
    source = Column(String, default=SOURCE_YAML, nullable=False)

    description = Column(Text, nullable=False)
    parameters = Column(JSON, nullable=False)
    execution_config = Column(JSON_NATIVE, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)

    company = relationship('Company', back_populates='tools')

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class CollectionType(Base):
    """Defines the available document collections/categories for a company."""
    __tablename__ = 'iat_collection_types'

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id', ondelete='CASCADE'), nullable=False)
    name = Column(String, nullable=False)  # e.g., "Contracts", "Manuals"
    parser_provider = Column(String, nullable=True)

    # description - optional for the LLM to understand what's inside'
    description = Column(Text, nullable=True)

    __table_args__ = (UniqueConstraint('company_id', 'name', name='uix_company_collection_name'),)

    company = relationship("Company", back_populates="collection_types")
    documents = relationship("Document", back_populates="collection_type")

class Document(Base):
    """Represents a file or document uploaded by a company for context."""
    __tablename__ = 'iat_documents'

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',
                    ondelete='CASCADE'), nullable=False)
    collection_type_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_collection_types.id', ondelete='SET NULL'), nullable=True)

    user_identifier = Column(String, nullable=True)
    filename = Column(String, nullable=False, index=True)
    status = Column(Enum(DocumentStatus), default=DocumentStatus.PENDING, nullable=False)
    meta = Column(JSON_NATIVE, nullable=True)
    created_at = Column(DateTime, default=datetime.now)

    # Stores the path in the cloud storage (S3/GCS)
    storage_key = Column(String, index=True, nullable=True)

    # For feedback if OCR or embedding fails
    error_message = Column(Text, nullable=True)

    # Hash column for deduplication (SHA-256 hex digest)
    hash = Column(String(64), index=True, nullable=True)

    company = relationship("Company", back_populates="documents")
    collection_type = relationship("CollectionType", back_populates="documents")

    document_images = relationship("DocumentImage",
                                   back_populates="document",
                                   cascade="all, delete-orphan")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}

    @property
    def description(self):
        collection_type = self.collection_type.name if self.collection_type else None
        return f"Document ID {self.id}: {self.filename} ({collection_type})"


class DocumentImage(Base):
    """Represents an image extracted from a document or an uploaded standalone image.."""
    __tablename__ = 'iat_document_images'

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_documents.id', ondelete='CASCADE'), nullable=False)

    page = Column(Integer, nullable=True)
    image_index = Column(Integer, nullable=True)
    storage_key = Column(String, index=True, nullable=True)
    meta = Column(JSON_NATIVE, nullable=True)
    created_at = Column(DateTime, default=datetime.now)

    document = relationship("Document", back_populates="document_images")
    vsimage = relationship("VSImage",
                           uselist=False,
                           back_populates="document_image",
                           cascade="all, delete-orphan")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class MemoryItem(Base):
    """Represents a raw user capture stored in Memoria."""
    __tablename__ = "iat_memory_items"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_companies.id", ondelete="CASCADE"), nullable=False)
    capture_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_memory_captures.id", ondelete="CASCADE"), nullable=True, index=True)
    user_identifier = Column(String, nullable=False, index=True)
    item_type = Column(Enum(MemoryItemType), nullable=False, default=MemoryItemType.NOTE)
    status = Column(Enum(MemoryItemStatus), nullable=False, default=MemoryItemStatus.PENDING)
    title = Column(String, nullable=True)
    content_text = Column(Text, nullable=True)
    source_url = Column(Text, nullable=True)
    filename = Column(String, nullable=True)
    mime_type = Column(String, nullable=True)
    storage_key = Column(String, nullable=True, index=True)
    source_meta = Column(JSON_NATIVE, nullable=True)
    compile_error = Column(Text, nullable=True)
    last_compiled_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now, nullable=False)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now, nullable=False)

    company = relationship("Company", back_populates="memory_items")
    capture = relationship("MemoryCapture", back_populates="items")
    page_links = relationship(
        "MemoryPageSource",
        back_populates="memory_item",
        cascade="all, delete-orphan",
    )

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class MemoryPage(Base):
    """Represents a compiled wiki page for a user's Memoria."""
    __tablename__ = "iat_memory_pages"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_companies.id", ondelete="CASCADE"), nullable=False)
    user_identifier = Column(String, nullable=False, index=True)
    title = Column(String, nullable=False)
    slug = Column(String, nullable=False)
    summary = Column(Text, nullable=True)
    wiki_path = Column(String, nullable=False)
    last_compiled_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now, nullable=False)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now, nullable=False)

    __table_args__ = (
        UniqueConstraint("company_id", "user_identifier", "slug", name="uix_memory_page_company_user_slug"),
    )

    company = relationship("Company", back_populates="memory_pages")
    sources = relationship(
        "MemoryPageSource",
        back_populates="memory_page",
        cascade="all, delete-orphan",
    )

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class MemoryCapture(Base):
    """Represents one explicit user save action in Memoria."""
    __tablename__ = "iat_memory_captures"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_companies.id", ondelete="CASCADE"), nullable=False)
    user_identifier = Column(String, nullable=False, index=True)
    title = Column(String, nullable=True)
    status = Column(Enum(MemoryCaptureStatus), nullable=False, default=MemoryCaptureStatus.PENDING)
    meta = Column(JSON_NATIVE, nullable=True)
    compile_error = Column(Text, nullable=True)
    last_compiled_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now, nullable=False)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now, nullable=False)

    company = relationship("Company", back_populates="memory_captures")
    items = relationship(
        "MemoryItem",
        back_populates="capture",
        cascade="all, delete-orphan",
        order_by="MemoryItem.created_at.asc()",
    )

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class MemoryPageSource(Base):
    """Links raw memory items to compiled pages."""
    __tablename__ = "iat_memory_page_sources"

    id = Column(Integer, primary_key=True, autoincrement=True)
    memory_page_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_memory_pages.id", ondelete="CASCADE"), nullable=False)
    memory_item_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_memory_items.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, default=datetime.now, nullable=False)

    __table_args__ = (
        UniqueConstraint("memory_page_id", "memory_item_id", name="uix_memory_page_source_unique"),
    )

    memory_page = relationship("MemoryPage", back_populates="sources")
    memory_item = relationship("MemoryItem", back_populates="page_links")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class LLMQuery(Base):
    """Logs a query made to the LLM, including input, output, and metadata."""
    __tablename__ = 'iat_queries'

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',
                            ondelete='CASCADE'), nullable=False)
    user_identifier = Column(String, nullable=False)
    query = Column(Text, nullable=False)
    output = Column(Text, nullable=False)
    response = Column(JSON, nullable=True, default={})
    valid_response = Column(Boolean, nullable=False, default=False)
    function_calls = Column(JSON, nullable=True, default={})
    stats = Column(JSON, default={})
    answer_time = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)
    task_id = Column(Integer, default=None, nullable=True)

    company = relationship("Company", back_populates="llm_queries")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class VSDoc(Base):
    """Stores a text chunk and its corresponding vector embedding for similarity search."""
    __tablename__ = "iat_vsdocs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',
                    ondelete='CASCADE'), nullable=False)
    document_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_documents.id',
                        ondelete='CASCADE'), nullable=False)
    text = Column(Text, nullable=False)
    meta = Column(JSON_NATIVE, nullable=True)

    # the size of this vector is dynamic to support multiple models
    # (e.g. OpenAI=1536, HuggingFace=384, etc.)
    embedding = Column(Vector, nullable=False)
    company = relationship("Company", back_populates="vsdocs")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}

class VSImage(Base):
    """Stores the vector embedding for an image document for visual similarity search."""
    __tablename__ = "iat_vsimages"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',
                                            ondelete='CASCADE'), nullable=False)
    document_image_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_document_images.id',
                                                   ondelete='CASCADE'), nullable=False)

    # Vector dimension depends on the multimodal model (e.g., CLIP uses 512 or 768)
    embedding = Column(Vector, nullable=False)

    company = relationship("Company", back_populates="vsimages")
    document_image = relationship("DocumentImage", back_populates="vsimage")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class UserFeedback(Base):
    """Stores feedback and ratings submitted by users for specific interactions."""
    __tablename__ = 'iat_feedback'

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',
                                            ondelete='CASCADE'), nullable=False)
    user_identifier = Column(String, default='', nullable=True)
    message = Column(Text, nullable=False)
    rating = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.now)

    company = relationship("Company", back_populates="feedbacks")


class PromptCategory(Base):
    """Represents a category to group and organize prompts."""
    __tablename__ = 'iat_prompt_categories'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    order = Column(Integer, nullable=False, default=0)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id', ondelete='CASCADE'), nullable=False)

    prompts = relationship(
        "Prompt",
        back_populates="category",
        order_by="Prompt.order",
        passive_deletes=True,
    )

    def __repr__(self):
        return f"<PromptCategory(name='{self.name}', order={self.order})>"


class Prompt(Base):
    """Represents a user-defined prompt template for the LLM."""
    __tablename__ = 'iat_prompt'

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_companies.id',
                                            ondelete='CASCADE'), nullable=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=False)
    filename = Column(String, nullable=False)
    active = Column(Boolean, default=True)
    visible_in_chat = Column(Boolean, default=True, nullable=False)
    execution_mode = Column(String, default=PromptExecutionMode.CONVERSATIONAL.value, nullable=False)
    order = Column(Integer, nullable=True, default=0)
    category_id = Column(Integer, ForeignKey(f'{ORM_SCHEMA}.iat_prompt_categories.id', ondelete='SET NULL'), nullable=True)
    custom_fields = Column(JSON, nullable=False, default=[])
    output_schema = Column(JSON, nullable=True, default=None)
    output_schema_yaml = Column(Text, nullable=True, default=None)
    output_schema_mode = Column(String, nullable=False, default="best_effort")
    output_response_mode = Column(String, nullable=False, default="chat_compatible")
    attachment_mode = Column(String, nullable=False, default="extracted_only")
    attachment_parser_provider = Column(String, nullable=False, default="basic")
    attachment_fallback = Column(String, nullable=False, default="extract")
    llm_model = Column(String, nullable=True, default=None)
    llm_request_options = Column(JSON_NATIVE, nullable=False, default=dict)
    tool_policy = Column(JSON_NATIVE, nullable=False, default=dict)
    created_at = Column(DateTime, default=datetime.now)

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}

    company = relationship("Company", back_populates="prompts")
    category = relationship("PromptCategory", back_populates="prompts")
    resource_bindings = relationship(
        "PromptResourceBinding",
        back_populates="prompt",
        cascade="all, delete-orphan",
        order_by="PromptResourceBinding.binding_order",
    )


class PromptResourceBinding(Base):
    __tablename__ = "iat_prompt_resource_bindings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    prompt_id = Column(
        Integer,
        ForeignKey(f"{ORM_SCHEMA}.iat_prompt.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    resource_type = Column(String(32), nullable=False, index=True)
    resource_key = Column(String(255), nullable=False)
    binding_order = Column(Integer, nullable=False, default=0)
    metadata_json = Column(JSON_NATIVE, nullable=False, default=dict)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    updated_by = Column(String(100), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "prompt_id",
            "resource_type",
            "resource_key",
            name="uix_prompt_resource_binding_resource_key",
        ),
    )

    prompt = relationship("Prompt", back_populates="resource_bindings")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class SqlSource(Base):
    """
    Canonical SQL source catalog per company.
    Runtime SQL registration is resolved from this table (not directly from YAML).
    """
    __tablename__ = "iat_sql_sources"

    SOURCE_YAML = "YAML"
    SOURCE_USER = "USER"

    CONNECTION_DIRECT = "direct"
    CONNECTION_BRIDGE = "bridge"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_companies.id", ondelete="CASCADE"), nullable=False)

    database = Column(String, nullable=False)
    connection_type = Column(String(32), nullable=False, default=CONNECTION_DIRECT)
    connection_string_env = Column(String, nullable=True)
    schema = Column(String, nullable=False, default="public")
    description = Column(Text, nullable=True)
    bridge_id = Column(String, nullable=True)

    source = Column(String(16), nullable=False, default=SOURCE_YAML)
    is_active = Column(Boolean, nullable=False, default=True)

    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

    __table_args__ = (
        UniqueConstraint("company_id", "database", name="uix_company_sql_source_database"),
    )

    company = relationship("Company", back_populates="sql_sources")
    sql_datasets = relationship("SqlDataset", back_populates="sql_source", cascade="all, delete-orphan")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class SqlDataset(Base):
    """
    Reusable SQL dataset definitions for pipelines and other batch features.
    A dataset references a SQL connection and defines how to select rows.
    """
    __tablename__ = "iat_sql_datasets"

    QUERY_MODE_TABLE_VIEW = "table_view"
    QUERY_MODE_SQL_QUERY = "sql_query"

    SOURCE_USER = "USER"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_companies.id", ondelete="CASCADE"), nullable=False)
    sql_source_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_sql_sources.id", ondelete="CASCADE"), nullable=False)

    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    query_mode = Column(String(32), nullable=False, default=QUERY_MODE_TABLE_VIEW)
    table_name = Column(String, nullable=True)
    query_sql = Column(Text, nullable=True)
    primary_key = Column(String, nullable=False)
    selected_columns = Column(JSON_NATIVE, nullable=False, default=list)
    filter_sql = Column(Text, nullable=True)
    order_by_sql = Column(Text, nullable=True)
    limit_rows = Column(Integer, nullable=True)

    source = Column(String(16), nullable=False, default=SOURCE_USER)
    is_active = Column(Boolean, nullable=False, default=True)

    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

    __table_args__ = (
        UniqueConstraint("company_id", "name", name="uix_company_sql_dataset_name"),
    )

    company = relationship("Company", back_populates="sql_datasets")
    sql_source = relationship("SqlSource", back_populates="sql_datasets")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class McpPersonalAccessToken(Base):
    __tablename__ = "iat_mcp_personal_access_tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_id = Column(Integer, ForeignKey(f"{ORM_SCHEMA}.iat_companies.id", ondelete="CASCADE"), nullable=False, index=True)
    user_identifier = Column(String, nullable=False, index=True)
    name = Column(String, nullable=False)
    token_hash = Column(String(64), nullable=False, unique=True, index=True)
    created_at = Column(DateTime, default=datetime.now, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    revoked_at = Column(DateTime, nullable=True)
    last_used_at = Column(DateTime, nullable=True)

    __table_args__ = (
        UniqueConstraint("company_id", "user_identifier", "name", name="uix_mcp_pat_company_user_name"),
    )

    company = relationship("Company", back_populates="mcp_personal_access_tokens")

    def to_dict(self):
        return {column.key: getattr(self, column.key) for column in class_mapper(self.__class__).columns}


class AccessLog(Base):
    # Modelo ORM para registrar cada intento de acceso a la plataforma.
    __tablename__ = 'iat_access_log'

    id = Column(BigInteger, primary_key=True, autoincrement=True)

    timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False, index=True)
    company_short_name = Column(String, nullable=False, index=True)
    user_identifier = Column(String, index=True)

    # Cómo y el Resultado
    auth_type = Column(String, nullable=False) # 'local', 'external_api', 'redeem_token', etc.
    outcome = Column(String, nullable=False)   # 'success' o 'failure'
    reason_code = Column(String)               # Causa de fallo, ej: 'INVALID_CREDENTIALS'

    # Contexto de la Petición
    source_ip = Column(String, nullable=False)
    user_agent_hash = Column(String)           # Hash corto del User-Agent
    request_path = Column(String, nullable=False)

    def __repr__(self):
        return (f"<AccessLog(id={self.id}, company='{self.company_short_name}', "
                f"user='{self.user_identifier}', outcome='{self.outcome}')>")
