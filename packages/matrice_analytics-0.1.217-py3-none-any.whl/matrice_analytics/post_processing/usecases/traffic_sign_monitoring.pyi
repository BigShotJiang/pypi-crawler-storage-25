"""Auto-generated stub for module: traffic_sign_monitoring."""
from typing import Any, Dict, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, AlertConfig
from ..utils import filter_by_confidence, apply_category_mapping, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker

# Classes
class TrafficSignMonitoringConfig:
    # Configuration for traffic sign monitoring use case.

    ...
class TrafficSignMonitoringUseCase:
    def __init__(self: Any) -> None: ...

    CATEGORY_DISPLAY: Dict[Any, Any]

    def get_total_counts(self: Any) -> Any:
        """
        Return total unique track_id count for each category.
        """
        ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any:
        """
        Main entry point for traffic sign post-processing.
        Applies category mapping, smoothing, counting, alerting, and summary generation.
        """
        ...

