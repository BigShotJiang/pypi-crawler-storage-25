from typing import Any, Dict, List, Optional, Set, Tuple, Union
from dataclasses import dataclass, replace
import copy
import logging
import os
import re
import threading
import time
from datetime import datetime, timezone

from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import PeopleCountingConfig, ZoneConfig, AlertConfig
from ..utils import (
    apply_category_mapping,
    match_results_structure,
    bbox_smoothing,
    BBoxSmoothingConfig,
    BBoxSmoothingTracker,
    calculate_iou,
)
from ..utils.geometry_utils import point_in_polygon, get_bbox_bottom25_center


@dataclass
class HazardZoneEntryConfig(PeopleCountingConfig):
    """
    Configuration for Hazard Zone Entry use case.
    """

    zone_config: Optional[ZoneConfig] = None

    # IMPORTANT: flicker / FN control
    min_inside_frames: int = 3  # default fallback

    exit_grace_frames: int = 3

    def __post_init__(self) -> None:
        """Convert zone_config and alert_config from raw dicts to dataclass instances.

        When the config is loaded from a JSON file, nested objects arrive as plain
        dicts.  This ensures they are always proper dataclass instances before any
        validation or processing runs.
        """
        if isinstance(self.zone_config, dict):
            self.zone_config = ZoneConfig(**self.zone_config)
        if isinstance(self.alert_config, dict):
            self.alert_config = AlertConfig(**self.alert_config)

    def validate(self) -> List[str]:
        errors = super().validate()

        if self.min_inside_frames < 1:
            errors.append("min_inside_frames must be >= 1")

        if self.zone_config:
            errors.extend(self.zone_config.validate())

        if self.alert_config:
            errors.extend(self.alert_config.validate())

        return errors


class _DeploymentIdHelper(BaseProcessor):
    """Minimal BaseProcessor subclass only to use extract_deployment_ids from base (no logic duplication)."""

    def __init__(self) -> None:
        super().__init__("deployment_id_helper")

    def process(
        self, data: Any, _config: ConfigProtocol, context: Optional[ProcessingContext] = None
    ) -> ProcessingResult:
        _ = (_config,)
        return self.create_result(data or {}, context=context)


class PostProcessingConfigClient:
    """
    Wrapper for Matrice post-processing config: session, stream identifiers,
    REST fetch by app deployment, and config filtering by camera_id.
    """

    def __init__(
        self,
        session: Optional[Any] = None,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        account_number: Optional[str] = None,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        self.logger = logger or logging.getLogger(__name__)
        self._session: Optional[Any] = session
        self._access_key = access_key or os.getenv("MATRICE_ACCESS_KEY_ID", "")
        self._secret_key = secret_key or os.getenv("MATRICE_SECRET_ACCESS_KEY", "")
        self._account_number = account_number or os.getenv("MATRICE_ACCOUNT_NUMBER", "") or ""

        if self._session is None and (self._access_key and self._secret_key):
            try:
                from matrice_common.session import Session

                self._session = Session(
                    access_key=self._access_key,
                    secret_key=self._secret_key,
                    account_number=self._account_number,
                )
                self.logger.info("Initialized Matrice session for post-processing config client")
            except Exception as exc:
                self.logger.error(
                    "Failed to initialize Matrice session for post-processing config client: %s",
                    exc,
                    exc_info=True,
                )
                self._session = None
        elif self._session is not None:
            self._access_key = getattr(self._session, "access_key", None) or self._access_key
            self._secret_key = getattr(self._session, "secret_key", None) or self._secret_key
        elif not self._access_key or not self._secret_key:
            self.logger.warning(
                "Missing Matrice credentials; cannot initialize session for post-processing config client"
            )

        self._config_by_camera: Dict[str, Dict[str, Any]] = {}
        self._deployment_id_helper = _DeploymentIdHelper()

    @property
    def session(self) -> Any:
        """Return the matrice_common Session (read-only)."""
        if self._session is None:
            raise RuntimeError("Session not initialized")
        return self._session

    def _to_pixel(self, normalized: Any, dimension_size: int) -> int:
        """Convert a single normalized value (0–1) to integer pixel coordinate."""
        try:
            return int(round(float(normalized) * dimension_size))
        except (TypeError, ValueError):
            return 0

    def _denormalize_points(self, points: Any, width: int, height: int) -> List[List[int]]:
        """Convert a list of [x_norm, y_norm] to [[x_px, y_px], ...]."""
        result: List[List[int]] = []
        if not isinstance(points, list):
            return result
        for pt in points:
            if not isinstance(pt, (list, tuple)) or len(pt) < 2:
                continue
            result.append(
                [
                    self._to_pixel(pt[0], width),
                    self._to_pixel(pt[1], height),
                ]
            )
        return result

    def _denormalize_zone_config(self, zone_config: Dict[str, Any], width: int, height: int) -> Dict[str, Any]:
        """Convert zone_config lines and zones from normalized to integer pixel coords."""
        out: Dict[str, Any] = copy.deepcopy(zone_config)
        lines = out.get("lines") or {}
        zones = out.get("zones") or {}
        if isinstance(lines, dict):
            out["lines"] = {
                name: self._denormalize_points(pts, width, height)
                for name, pts in lines.items()
                if isinstance(pts, list)
            }
        if isinstance(zones, dict):
            out["zones"] = {
                name: self._denormalize_points(pts, width, height)
                for name, pts in zones.items()
                if isinstance(pts, list)
            }
        return out

    def get_stream_identifiers(self, stream_info: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        """Return camera_id, application_id, and app_deployment_id from stream_info."""
        result: Dict[str, str] = {
            "camera_id": "",
            "application_id": "",
            "app_deployment_id": "",
        }
        if not stream_info or not isinstance(stream_info, dict):
            return result

        deployment = self._deployment_id_helper.extract_deployment_ids(stream_info)
        result["application_id"] = (deployment.get("application_id") or "").strip()
        result["app_deployment_id"] = (deployment.get("app_deployment_id") or "").strip()

        def _to_str(value: Any) -> str:
            if value is None:
                return ""
            if isinstance(value, str):
                return value.strip()
            if isinstance(value, (int, float)):
                return str(value)
            if isinstance(value, dict):
                return ""
            if isinstance(value, (list, tuple, set)):
                for item in value:
                    s = _to_str(item)
                    if s:
                        return s
                return ""
            try:
                return str(value).strip()
            except Exception:
                return ""

        def _dict_get_str(d: Any, *keys: str) -> str:
            if not isinstance(d, dict):
                return ""
            for k in keys:
                val = _to_str(d.get(k))
                if val:
                    return val
            return ""

        def _extract_camera_id_from_topic(topic_val: Any) -> str:
            topic = _to_str(topic_val)
            if not topic:
                return ""
            for suffix in ("_input_topic", "_input-topic"):
                if topic.endswith(suffix):
                    return topic[: -len(suffix)].strip()
            for marker in ("_input_topic", "_input-topic"):
                if marker in topic:
                    return topic.split(marker)[0].strip()
            return ""

        def _extract_camera_id_from_frame_id(frame_id_val: Any) -> str:
            fid = _to_str(frame_id_val)
            if not fid or not fid.startswith("legacy_"):
                return ""
            parts = fid.split("_")
            if len(parts) >= 3:
                candidate = parts[1].strip()
                if candidate and re.fullmatch(r"[0-9a-f]{8,}", candidate, re.IGNORECASE):
                    return candidate
            return ""

        input_settings = stream_info.get("input_settings") or {}
        if not isinstance(input_settings, dict):
            input_settings = {}

        camera_info_root = stream_info.get("camera_info") or {}
        if not isinstance(camera_info_root, dict):
            camera_info_root = {}

        camera_info_input_settings = input_settings.get("camera_info") or {}
        if not isinstance(camera_info_input_settings, dict):
            camera_info_input_settings = {}

        input_stream = input_settings.get("input_stream") or {}
        if not isinstance(input_stream, dict):
            input_stream = {}

        camera_info_input_stream = input_stream.get("camera_info") or {}
        if not isinstance(camera_info_input_stream, dict):
            camera_info_input_stream = {}

        input_streams = stream_info.get("input_streams") or []
        input_stream_candidates: List[Dict[str, Any]] = []
        if isinstance(input_streams, list):
            for item in input_streams:
                if not isinstance(item, dict):
                    continue
                inner = item.get("input_stream", item)
                if not isinstance(inner, dict):
                    continue
                input_stream_candidates.append(inner)

        def _camera_id_from_camera_info(ci: Dict[str, Any]) -> str:
            return _dict_get_str(ci, "camera_id", "cameraId", "_id", "id")

        topic_camera_id = _extract_camera_id_from_topic(stream_info.get("topic")) or _extract_camera_id_from_topic(
            input_settings.get("topic")
        )
        if not topic_camera_id:
            topics_val = stream_info.get("topics")
            if isinstance(topics_val, (list, tuple, set)):
                for t in topics_val:
                    topic_camera_id = _extract_camera_id_from_topic(t)
                    if topic_camera_id:
                        break

        if topic_camera_id:
            result["camera_id"] = topic_camera_id
        if not result["camera_id"]:
            result["camera_id"] = (
                _dict_get_str(stream_info, "camera_id", "cameraId")
                or _dict_get_str(input_settings, "camera_id", "cameraId")
                or _camera_id_from_camera_info(camera_info_root)
                or _camera_id_from_camera_info(camera_info_input_settings)
                or _camera_id_from_camera_info(camera_info_input_stream)
            )
            if not result["camera_id"]:
                for candidate in input_stream_candidates:
                    result["camera_id"] = _dict_get_str(candidate, "camera_id", "cameraId", "_id", "id")
                    if result["camera_id"]:
                        break
            if not result["camera_id"]:
                result["camera_id"] = topic_camera_id or ""
        if not result["camera_id"]:
            result["camera_id"] = _extract_camera_id_from_frame_id(stream_info.get("frame_id"))

        if result["camera_id"] and not isinstance(result["camera_id"], str):
            result["camera_id"] = str(result["camera_id"])
        return result

    def get_post_processing_configs_by_app_deployment(
        self,
        app_deployment_id: str,
    ) -> Tuple[Optional[List[Dict[str, Any]]], Optional[str], Optional[str]]:
        """Fetch all post-processing configs for an app deployment via Matrice API."""
        from matrice_common.rpc import RPC

        rpc = RPC(
            access_key=self._access_key,
            secret_key=self._secret_key,
        )
        path = f"/v1/inference/post_processing_configs/by_app_deployment/{app_deployment_id}"

        try:
            response = rpc.get(path)
            if isinstance(response, dict) and response.get("success"):
                return (
                    response.get("data", []),
                    None,
                    response.get("message", "Success"),
                )
            err = response.get("message", "Unknown error") if isinstance(response, dict) else str(response)
            return None, err, None
        except Exception as e:
            self.logger.exception("get_post_processing_configs_by_app_deployment failed")
            return None, str(e), None

    def filter_configs_by_camera_id(
        self,
        configs: List[Dict[str, Any]],
        camera_id: str,
    ) -> List[Dict[str, Any]]:
        """Filter config documents to those containing config for the given camera_id."""
        if not camera_id or not configs:
            return []
        out = []
        for doc in configs:
            post = doc.get("postProcessing") or {}
            if isinstance(post, dict) and camera_id in post:
                out.append(doc)
        return out

    def get_config_for_camera(self, camera_id: str) -> Optional[Dict[str, Any]]:
        """Return cached post-processing config for a camera."""
        if not camera_id:
            return None
        return self._config_by_camera.get(str(camera_id))

    def set_config_cache_from_api(self, configs: List[Dict[str, Any]]) -> None:
        """Populate the config cache from a list of configs (e.g. from REST API)."""
        for doc in configs or []:
            post = doc.get("postProcessing") or {}
            if not isinstance(post, dict):
                continue
            for cid, cam_cfg in post.items():
                if not cid:
                    continue
                cid = str(cid)
                self._config_by_camera[cid] = {
                    "_id": doc.get("_id"),
                    "_idCamera": doc.get("_idCamera"),
                    "_idApplication": doc.get("_idApplication"),
                    "_idAppDeployment": doc.get("_idAppDeployment"),
                    "postProcessing": {cid: cam_cfg},
                    "createdAt": doc.get("createdAt"),
                    "updatedAt": doc.get("updatedAt"),
                }
        self.logger.info("Config cache updated from API: %d camera(s)", len(self._config_by_camera))

    def get_resolution(self, camera_id: str) -> Tuple[Optional[int], Optional[int]]:
        """Get frame width and height for a camera by its ID."""
        try:
            from matrice.camera_management import CameraManagement
        except ImportError:
            self.logger.warning("matrice.camera_management not available; install py_matrice for get_resolution")
            return (None, None)
        try:
            camera_mgmt = CameraManagement(self.session)
            all_cameras, fetch_error, _ = camera_mgmt.get_camera_streams_by_account()
            if fetch_error or not all_cameras:
                self.logger.warning("get_resolution: fetch_error=%s or no cameras", fetch_error)
                return (None, None)
            for cam in all_cameras:
                cid = cam.get("id") or cam.get("_id")
                if cid != camera_id:
                    continue
                settings = cam.get("customStreamSettings") or {}
                if not isinstance(settings, dict):
                    return (None, None)
                w = settings.get("width")
                h = settings.get("height")
                if w is not None and h is not None:
                    return (int(w), int(h))
                return (None, None)
            self.logger.warning("get_resolution: camera_id %s not found", camera_id)
            return (None, None)
        except Exception:
            self.logger.exception("get_resolution failed for camera_id=%s", camera_id)
            return (None, None)

    def denormalize_config(
        self,
        config: Union[Dict[str, Any], List[Dict[str, Any]]],
        width: int,
        height: int,
    ) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """Convert normalized (0–1) line/zone coordinates to integer pixel coordinates."""
        if isinstance(config, list):
            return [self.denormalize_config(doc, width, height) for doc in config]
        if not isinstance(config, dict):
            return config
        out = copy.deepcopy(config)
        post = out.get("postProcessing") or {}
        if not isinstance(post, dict):
            return out
        for cid, cam_cfg in list(post.items()):
            if not isinstance(cam_cfg, dict):
                continue
            zone_cfg = cam_cfg.get("zone_config")
            if isinstance(zone_cfg, dict):
                post[cid] = {**cam_cfg, "zone_config": self._denormalize_zone_config(zone_cfg, width, height)}
        return out


_GEOMETRY_RETRY_INTERVAL = 30  # Seconds between background retry attempts when API fails


class HazardZoneEntryUseCase(BaseProcessor):
    """hazard zone entry alert use case with zone analysis and alerting."""

    def __init__(self):
        """Initialize people counting use case."""
        super().__init__("hazard_zone_entry")
        self.category = "general"
        self.CASE_TYPE: Optional[str] = "hazard_zone_entry"
        self.CASE_VERSION: Optional[str] = "1.3"

        # Track ID storage for total count calculation
        self._total_track_ids = set()  # Store all unique track IDs seen across calls
        self._current_frame_track_ids = set()  # Store track IDs from current frame
        self._total_count = 0  # Cached total count
        self._last_update_time = time.time()  # Track when last updated

        # Zone-based tracking storage
        self._zone_current_track_ids = {}  # zone_name -> set of current track IDs in zone
        self._zone_total_track_ids = {}  # zone_name -> set of all track IDs that have been in zone
        self._zone_current_counts = {}  # zone_name -> current count in zone
        self._zone_total_counts = {}  # zone_name -> total count that have been in zone

        # Frame counter for tracking total frames processed
        self._total_frame_counter = 0  # Total frames processed across all calls

        # Global frame offset for video chunk processing
        self._global_frame_offset = 0  # Offset to add to local frame IDs for global frame numbering
        self._frames_in_current_chunk = 0  # Number of frames in current chunk

        # Initialize smoothing tracker
        self.smoothing_tracker = None

        # Track start time for "TOTAL SINCE" calculation
        self._tracking_start_time = None

        # zone_name -> track_id -> consecutive_inside_frames
        self._zone_inside_frames: Dict[str, Dict[Any, int]] = {}

        # zone_name -> track_ids that already triggered alert
        self._zone_alerted_tracks: Dict[str, Set[Any]] = {}

        self._zone_outside_frames: Dict[str, Dict[Any, int]] = {}

        # --------------------------------------------------------------------- #
        # Tracking aliasing structures to merge fragmented IDs                   #
        # --------------------------------------------------------------------- #
        # Maps raw tracker IDs generated by ByteTrack to a stable canonical ID
        # that represents a real-world person. This helps avoid double counting
        # when the tracker loses a target temporarily and assigns a new ID.
        self._track_aliases: Dict[Any, Any] = {}

        # Stores metadata about each canonical track such as its last seen
        # bounding box, last update timestamp and all raw IDs that have been
        # merged into it.
        self._canonical_tracks: Dict[Any, Dict[str, Any]] = {}

        # IoU threshold above which two bounding boxes are considered the same
        # person for alias merging. Tuned for people (robust CCTV scenarios).
        # Using a moderate IoU to handle jitter and perspective changes.
        self._track_merge_iou_threshold: float = 0.3

        # Merge window in seconds (people typically move slowly; shorter window
        # reduces accidental merges across cuts).
        self._track_merge_time_window: float = 3.0

        self._ascending_alert_list: List[int] = []
        self.current_incident_end_timestamp: str = "N/A"

        self.start_timer = None

        # Maintain last frame presence for consecutive confirmation logic
        self._last_frame_track_ids: Set[Any] = set()

        # Advanced tracking for single-frame detections
        self.tracker = None
        self._min_confirm_frames: int = 3  # require 3 consecutive frames before counting as unique
        self._consecutive_track_frames: Dict[Any, int] = {}

        # Config client and resolved geometry cache for API-based zone resolution
        self._config_client: Optional[PostProcessingConfigClient] = None
        self._resolved_geometry_cache: Optional[HazardZoneEntryConfig] = None
        self._geometry_thread: Optional[threading.Thread] = None
        # Set to True after the first frame attempts zone resolution (success or fall-through)
        self._zone_resolution_attempted: bool = False

    # ------------------------------------------------------------------ #
    # API geometry resolution (zones from UI via PostProcessingConfigClient)
    # ------------------------------------------------------------------ #

    def set_config_client(self, client: Optional[PostProcessingConfigClient]) -> None:
        """Set the PostProcessingConfigClient used to resolve zones from API (by_app_deployment, camera_id)."""
        self._config_client = client

    def _start_geometry_resolver(self, config: "HazardZoneEntryConfig", stream_info: Dict[str, Any]) -> None:
        """Spawn a daemon thread that resolves zone geometry from the API.

        On success the cache is updated and the thread exits.
        On failure it retries every ``_GEOMETRY_RETRY_INTERVAL`` seconds.
        Never blocks the calling (frame-processing) thread.
        """
        if self._geometry_thread is not None:
            return  # already running

        def _resolver():
            while True:
                try:
                    result = self._resolve_geometry_from_api(config, stream_info)
                    if result is not None:
                        self._resolved_geometry_cache = result
                        self.logger.info("HazardZoneEntry: zone geometry resolved from API (background thread)")
                        return  # done
                    self.logger.info(
                        "HazardZoneEntry: API geometry returned None, retrying in %ds",
                        _GEOMETRY_RETRY_INTERVAL,
                    )
                except Exception as exc:
                    self.logger.warning("HazardZoneEntry: background geometry resolve error: %s", exc)
                time.sleep(_GEOMETRY_RETRY_INTERVAL)

        t = threading.Thread(target=_resolver, daemon=True, name="hazard-zone-geometry-resolver")
        self._geometry_thread = t
        t.start()
        self.logger.info("HazardZoneEntry: started background zone geometry resolver thread")

    def _resolve_geometry_from_api(
        self,
        config: "HazardZoneEntryConfig",
        stream_info: Optional[Dict[str, Any]],
    ) -> Optional["HazardZoneEntryConfig"]:
        """Resolve zone_config from PostProcessingConfigClient flow.

        Uses: get_stream_identifiers -> get_post_processing_configs_by_app_deployment ->
        filter_configs_by_camera_id -> get_resolution -> denormalize_config -> extract zones.
        Maps all zones from zone_config.zones into a ZoneConfig and returns a new config.
        Returns a new config with zone_config filled, or None if unavailable.

        Config client is resolved in order:
        (1) set_config_client(), (2) stream_info["config_client"] if provided,
        (3) lazy-creation from MATRICE_ACCESS_KEY_ID / MATRICE_SECRET_ACCESS_KEY / MATRICE_ACCOUNT_NUMBER.
        """
        client = self._config_client or (stream_info.get("config_client") if stream_info else None)
        if not client and stream_info:
            try:
                client = PostProcessingConfigClient(logger=self.logger)
                if getattr(client, "_session", None) is None:
                    self.logger.info(
                        "HazardZoneEntry: _resolve_geometry_from_api skipped (no config_client; set "
                        "MATRICE_ACCESS_KEY_ID, MATRICE_SECRET_ACCESS_KEY, MATRICE_ACCOUNT_NUMBER "
                        "or call set_config_client() for API zone geometry resolution)"
                    )
                    return None
                self._config_client = client
            except Exception as e:
                self.logger.warning(
                    "HazardZoneEntry: _resolve_geometry_from_api could not create config client from env: %s", e
                )
                return None

        if not stream_info:
            self.logger.info("HazardZoneEntry: _resolve_geometry_from_api skipped (no stream_info)")
            return None
        if not client:
            self.logger.info(
                "HazardZoneEntry: _resolve_geometry_from_api skipped (no config_client; set "
                "MATRICE_* env or call set_config_client() for API zone geometry resolution)"
            )
            return None

        ids = client.get_stream_identifiers(stream_info)
        app_deployment_id = ids.get("app_deployment_id") or ""
        camera_id = ids.get("camera_id") or ""
        self.logger.info(
            "HazardZoneEntry: _resolve_geometry_from_api app_deployment_id=%s camera_id=%s",
            app_deployment_id or "(empty)",
            camera_id or "(empty)",
        )

        if not app_deployment_id or not camera_id:
            self.logger.info("_resolve_geometry_from_api: returning None (missing app_deployment_id or camera_id)")
            return None

        configs, err, _ = client.get_post_processing_configs_by_app_deployment(app_deployment_id)
        if err or not configs:
            self.logger.info(
                "_resolve_geometry_from_api: returning None "
                "(get_post_processing_configs_by_app_deployment: err=%r, configs count=%s)",
                err,
                len(configs) if configs else 0,
            )
            return None

        self.logger.info("_resolve_geometry_from_api: configs=%r", configs)

        filtered = client.filter_configs_by_camera_id(configs, camera_id)
        if not filtered:
            self.logger.info(
                "_resolve_geometry_from_api: returning None "
                "(filter_configs_by_camera_id: no config for camera_id=%s)",
                camera_id,
            )
            return None

        doc = filtered[0]
        width, height = client.get_resolution(camera_id)
        if width is None or height is None:
            self.logger.info(
                "_resolve_geometry_from_api: returning None " "(get_resolution: width=%r, height=%r for camera_id=%s)",
                width,
                height,
                camera_id,
            )
            return None

        self.logger.info("_resolve_geometry_from_api: width=%r, height=%r", width, height)

        doc_px = client.denormalize_config(doc, width, height)
        post = doc_px.get("postProcessing") or {}
        cam_cfg = post.get(camera_id) or {}
        zone_config_raw = cam_cfg.get("zone_config") or {}
        zones_px = zone_config_raw.get("zones") or {}

        if not isinstance(zones_px, dict) or not zones_px:
            self.logger.info(
                "_resolve_geometry_from_api: returning None " "(no zones found in zone_config for camera_id=%s)",
                camera_id,
            )
            return None

        self.logger.info("_resolve_geometry_from_api: zones_px=%r", zones_px)

        # Build ZoneConfig from pixel-coordinate zones
        # zones_px: {zone_name: [[x, y], [x, y], ...], ...}
        zones_dict = {name: [list(pt) for pt in points] for name, points in zones_px.items()}
        new_zone_config = ZoneConfig(zones=zones_dict)

        self.logger.info(
            "HazardZoneEntry: resolved %d zone(s) from API: %s",
            len(zones_dict),
            list(zones_dict.keys()),
        )
        return replace(config, zone_config=new_zone_config)

    def process(
        self,
        data: Any,
        config: ConfigProtocol,
        context: Optional[ProcessingContext] = None,
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> ProcessingResult:
        """Process a single frame of detections and return agg_summary with hazard zone alerts.

        Args:
            data: Raw model output for one frame — either a flat list of detections
                  or a frame-keyed dict (``{"0": [...]}``) from which the first
                  frame's detections are extracted.
            config: HazardZoneEntryConfig instance.
            context: Optional processing context.
            stream_info: Optional stream metadata (used for frame number and API zone resolution).

        Returns:
            ProcessingResult with ``agg_summary`` keyed by the current frame number.
        """
        processing_start = time.time()
        self.logger.info("HazardZoneEntry.process: stream_info=%s", stream_info)

        try:
            if not isinstance(config, HazardZoneEntryConfig):
                return self.create_error_result(
                    "Invalid configuration type for hazard zone entry (expected HazardZoneEntryConfig)",
                    usecase=self.name,
                    category=self.category,
                    context=context,
                )

            if context is None:
                context = ProcessingContext()

            # ------------------------------------------------------------------ #
            # Resolve zone geometry from UI/API exactly once (first frame, blocking).
            # On success : cache the result; all future frames use UI zones.
            # On failure : start a daemon background thread that retries every
            #              _GEOMETRY_RETRY_INTERVAL seconds without blocking
            #              frame processing.  Until the thread succeeds, frames
            #              use the zone_config supplied in the user config file.
            # ------------------------------------------------------------------ #
            if not self._zone_resolution_attempted:
                self._zone_resolution_attempted = True
                if stream_info:
                    self.logger.info(
                        "HazardZoneEntry: attempting zone geometry resolution from API (first frame, blocking)"
                    )
                    try:
                        resolved = self._resolve_geometry_from_api(config, stream_info)
                        if resolved is not None:
                            self._resolved_geometry_cache = resolved
                            self.logger.info("HazardZoneEntry: zone geometry resolved from API and cached")
                        else:
                            self.logger.warning(
                                "HazardZoneEntry: API returned no zone config on first frame; "
                                "starting background retry thread (retrying every %ds). "
                                "Using zone_config from user config file until resolved.",
                                _GEOMETRY_RETRY_INTERVAL,
                            )
                            self._start_geometry_resolver(config, stream_info)
                    except Exception as exc:
                        self.logger.warning(
                            "HazardZoneEntry: zone geometry resolution raised on first frame (%s); "
                            "starting background retry thread (retrying every %ds). "
                            "Using zone_config from user config file until resolved.",
                            exc,
                            _GEOMETRY_RETRY_INTERVAL,
                        )
                        self._start_geometry_resolver(config, stream_info)
                else:
                    self.logger.info(
                        "HazardZoneEntry: no stream_info on first frame; " "using zone_config from user config file"
                    )

            # Use API-resolved zone geometry if available; otherwise keep user config as-is
            if self._resolved_geometry_cache is not None:
                config = self._resolved_geometry_cache
                self.logger.debug("HazardZoneEntry: using API-resolved zone geometry")

            context.input_format = match_results_structure(data)
            context.confidence_threshold = config.confidence_threshold

            # --- Normalize incoming data to a flat list of detections (single frame) ---
            if isinstance(data, list):
                processed_data = data
            elif isinstance(data, dict):
                # Frame-keyed dict — extract the first frame's detections only
                processed_data = []
                for _key, value in data.items():
                    if isinstance(value, list):
                        processed_data = value
                        break
            else:
                processed_data = []

            self._total_frame_counter += 1

            # --- Determine frame number ---
            frame_number: Any = None
            if stream_info:
                input_settings = stream_info.get("input_settings", {}) or {}
                start_frame = input_settings.get("start_frame")
                end_frame = input_settings.get("end_frame")
                if start_frame is not None and end_frame is not None and start_frame == end_frame:
                    frame_number = start_frame
            if frame_number is None:
                frame_number = self._total_frame_counter

            # --- Run all analytics for this single frame ---
            alerts, incidents_list, tracking_stats_list, business_analytics_list, summary_list = (
                self._process_frame_detections(processed_data, config, str(frame_number), stream_info)
            )

            incidents = incidents_list[0] if incidents_list else {}
            tracking_stats = tracking_stats_list[0] if tracking_stats_list else {}
            business_analytics = business_analytics_list[0] if business_analytics_list else {}
            summary = summary_list[0] if summary_list else {}

            agg_summary = {
                str(frame_number): {
                    "incidents": incidents,
                    "tracking_stats": tracking_stats,
                    "business_analytics": business_analytics,
                    "alerts": alerts,
                    "human_text": summary,
                }
            }

            context.mark_completed()

            proc_ms = (time.time() - processing_start) * 1000.0
            self.logger.debug("HazardZoneEntry: frame %s processed in %.1f ms", frame_number, proc_ms)

            return self.create_result(
                data={"agg_summary": agg_summary}, usecase=self.name, category=self.category, context=context
            )

        except Exception as e:
            self.logger.error("HazardZoneEntry.process failed: %s", e, exc_info=True)
            if context:
                context.mark_completed()
            return self.create_error_result(
                str(e), type(e).__name__, usecase=self.name, category=self.category, context=context
            )

    def _process_frame_detections(
        self,
        frame_data: Any,
        config: HazardZoneEntryConfig,
        frame_id: str,
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> tuple:
        """Process detections from a single frame and return standardized components."""

        # Convert frame_data to list if it's not already
        if isinstance(frame_data, list):
            frame_detections = frame_data
        else:
            # Handle other formats as needed
            frame_detections = []

        # Step 1: Apply confidence filtering to this frame
        if config.confidence_threshold is not None:
            frame_detections = [d for d in frame_detections if d.get("confidence", 0) >= config.confidence_threshold]

        # Step 2: Apply category mapping if provided
        if config.index_to_category:
            frame_detections = apply_category_mapping(frame_detections, config.index_to_category)

        # Step 3: Filter to person categories
        if config.person_categories:
            frame_detections = [d for d in frame_detections if d.get("category") in config.person_categories]
        if config.target_categories:
            frame_detections = [d for d in frame_detections if d.get("category") in config.target_categories]
            self.logger.debug("Applied category filtering")

        # Step 4: Track single-frame detections using AdvancedTracker to obtain stable track_ids
        # Always apply when tracking is enabled in single-frame path
        needs_tracking = bool(config.enable_tracking)
        if self.tracker is None and needs_tracking:
            try:
                from ..advanced_tracker import AdvancedTracker
                from ..advanced_tracker.config import TrackerConfig

                # Configure tracker thresholds suitable for people
                try:
                    fps = int(stream_info.get("input_settings", {}).get("original_fps", 30)) if stream_info else 30
                    if fps <= 0:
                        fps = 30
                except Exception:
                    fps = 30
                tracker_config = TrackerConfig(
                    track_high_thresh=0.4,
                    track_low_thresh=0.05,
                    new_track_thresh=0.3,
                    match_thresh=0.8,
                    track_buffer=int(3 * fps),
                    max_time_lost=int(3 * fps),
                    frame_rate=fps,
                )
                # Keep defaults for confidence thresholds; AdvancedTracker handles activation
                self.tracker = AdvancedTracker(tracker_config)
                self.logger.info("Initialized AdvancedTracker for People Counting (single-frame)")
            except Exception as e:
                self.logger.warning(f"AdvancedTracker init failed, falling back to IoU aliasing: {e}")

        tracked_detections = frame_detections
        if self.tracker is not None and needs_tracking:
            try:
                tracked_detections = self.tracker.update(frame_detections)
            except Exception as e:
                self.logger.warning(f"AdvancedTracker update failed, using raw detections: {e}")
                tracked_detections = frame_detections

        # Step 4: Create counting summary for this frame
        counting_summary = {
            "total_objects": len(tracked_detections),
            "detections": tracked_detections,
            "categories": {},
        }

        # Count by category
        for detection in tracked_detections:
            category = detection.get("category", "unknown")
            counting_summary["categories"][category] = counting_summary["categories"].get(category, 0) + 1

        # Step 4.5: Always update tracking state BEFORE zone enhancements so detections have track_ids
        self._update_tracking_state(counting_summary)

        # Step 5: Zone analysis for this frame
        # Only analyse zones when the user has configured them (via config file or UI).
        # No default fallback zone is applied — if zone_config is absent, zone analysis is skipped.
        resolved_zones: Dict[str, Any] = (
            config.zone_config.zones if config.zone_config and config.zone_config.zones else {}
        )

        if not resolved_zones:
            self.logger.debug("HazardZoneEntry: no zones configured for frame %s; skipping zone analysis", frame_id)

        zone_analysis: Dict[str, Any] = {zone_name: {} for zone_name in resolved_zones}

        if resolved_zones:

            # Convert single frame to format expected by count_objects_in_zones
            # frame_data = frame_detections #[frame_detections]
            # zone_analysis = count_objects_in_zones(frame_data, config.zone_config.zones)
            # Update zone tracking with current frame data (now detections have canonical track_ids)
            enhanced_zone_analysis = self._update_zone_tracking(zone_analysis, counting_summary["detections"], config)
            # Merge enhanced zone analysis with original zone analysis
            for zone_name, enhanced_data in enhanced_zone_analysis.items():
                zone_analysis[zone_name] = enhanced_data

        # Step 5: Generate insights and alerts for this frame
        alerts = self._check_alerts(counting_summary, zone_analysis, config, frame_id)

        # Step 6: Generate summary and standardized agg_summary components for this frame
        incidents = self._generate_incidents(counting_summary, zone_analysis, alerts, config, frame_id, stream_info)
        # incidents = []
        tracking_stats = self._generate_tracking_stats(
            counting_summary, zone_analysis, config, frame_id=frame_id, alerts=alerts, stream_info=stream_info
        )
        business_analytics = self._generate_business_analytics(
            counting_summary, zone_analysis, config, frame_id, stream_info, is_empty=True
        )
        summary = self._generate_summary(counting_summary, incidents, tracking_stats, business_analytics, alerts)

        # Return standardized components as tuple
        return alerts, incidents, tracking_stats, business_analytics, summary

    def _generate_incidents(
        self,
        counting_summary: Dict,
        _zone_analysis: Dict,
        alerts: List,
        config: HazardZoneEntryConfig,
        frame_id: str,
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> List[Dict]:
        """Generate standardized incidents for the agg_summary structure."""

        _ = (_zone_analysis,)
        camera_info = self.get_camera_info_from_stream(stream_info)
        incidents = []
        total_people = counting_summary.get("total_objects", 0)
        current_timestamp = self._get_current_timestamp_str(stream_info, frame_id=frame_id)
        self._ascending_alert_list = (
            self._ascending_alert_list[-900:] if len(self._ascending_alert_list) > 900 else self._ascending_alert_list
        )

        alert_settings = []
        if config.alert_config and hasattr(config.alert_config, "alert_type"):
            alert_settings.append(
                {
                    "alert_type": (
                        getattr(config.alert_config, "alert_type", ["Default"])
                        if hasattr(config.alert_config, "alert_type")
                        else ["Default"]
                    ),
                    "incident_category": self.CASE_TYPE,
                    "threshold_level": (
                        config.alert_config.count_thresholds if hasattr(config.alert_config, "count_thresholds") else {}
                    ),
                    "ascending": True,
                    "settings": {
                        t: v
                        for t, v in zip(
                            getattr(config.alert_config, "alert_type", ["Default"]),
                            getattr(config.alert_config, "alert_value", ["JSON"]),
                        )
                    },
                }
            )

        if total_people > 0:
            # Determine event level based on thresholds
            start_timestamp = self._get_start_timestamp_str(stream_info)
            self._debug_stream_timing("start_timestamp", start_timestamp)
            if start_timestamp and self.current_incident_end_timestamp == "N/A":
                self.current_incident_end_timestamp = "Incident still active"
            elif start_timestamp and self.current_incident_end_timestamp == "Incident still active":
                if len(self._ascending_alert_list) >= 15 and sum(self._ascending_alert_list[-15:]) / 15 < 1.5:
                    self.current_incident_end_timestamp = current_timestamp
            elif (
                self.current_incident_end_timestamp != "Incident still active"
                and self.current_incident_end_timestamp != "N/A"
            ):
                self.current_incident_end_timestamp = "N/A"

            if (
                config.alert_config
                and hasattr(config.alert_config, "count_thresholds")
                and config.alert_config.count_thresholds
            ):
                threshold = config.alert_config.count_thresholds.get("all", 10)
                intensity = min(10.0, (total_people / threshold) * 10)

                if intensity >= 9:
                    level = "critical"
                    self._ascending_alert_list.append(3)
                elif intensity >= 7:
                    level = "significant"
                    self._ascending_alert_list.append(2)
                elif intensity >= 5:
                    level = "medium"
                    self._ascending_alert_list.append(1)
                else:
                    level = "low"
                    self._ascending_alert_list.append(0)
            else:
                if total_people > 30:
                    level = "critical"
                    self._ascending_alert_list.append(3)
                elif total_people > 25:
                    level = "significant"
                    self._ascending_alert_list.append(2)
                elif total_people > 15:
                    level = "medium"
                    self._ascending_alert_list.append(1)
                else:
                    level = "low"
                    self._ascending_alert_list.append(0)

            # Generate human text in new format
            human_text_lines = [f"INCIDENTS DETECTED @ {current_timestamp}:"]
            human_text_lines.append(f"\tSeverity Level: {(self.CASE_TYPE,level)}")
            human_text = "\n".join(human_text_lines)

            # Main people counting incident
            event = self.create_incident(
                incident_id=self.CASE_TYPE + "_" + str(frame_id),
                incident_type=self.CASE_TYPE,
                severity_level=level,
                human_text=human_text,
                camera_info=camera_info,
                alerts=alerts,
                alert_settings=alert_settings,
                start_time=start_timestamp,
                end_time=self.current_incident_end_timestamp,
                level_settings={"low": 1, "medium": 3, "significant": 4, "critical": 7},
            )
            incidents.append(event)
        else:
            self._ascending_alert_list.append(0)
            incidents.append({})

        return incidents

    def _generate_tracking_stats(
        self,
        counting_summary: Dict,
        zone_analysis: Dict,
        config: HazardZoneEntryConfig,
        frame_id: str,
        alerts: Any = [],
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> List[Dict]:
        """Generate tracking stats using standardized methods."""

        total_people = counting_summary.get("total_objects", 0)

        # Get total count from cached tracking state
        total_unique_count = self.get_total_count()
        current_frame_count = self.get_current_frame_count()

        # Get camera info using standardized method
        camera_info = self.get_camera_info_from_stream(stream_info)

        # Build total_counts using standardized method
        total_counts = []
        per_category_total = {}

        for category in config.person_categories or ["person"]:
            # Always use scene-wide unique count
            category_total_count = total_unique_count

            if category_total_count > 0:
                total_counts.append(self.create_count_object(category, category_total_count))
                per_category_total[category] = category_total_count

        # Build current_counts using standardized method
        current_counts = []
        per_category_current = {}

        for category in config.person_categories or ["person"]:
            # Always use scene-wide current count
            category_current_count = current_frame_count

            if category_current_count > 0 or total_people > 0:  # Include even if 0 when there are people
                current_counts.append(self.create_count_object(category, category_current_count))
                per_category_current[category] = category_current_count

        # Prepare detections using standardized method (without confidence and track_id)
        detections = []
        for detection in counting_summary.get("detections", []):
            bbox = detection.get("bounding_box", {})
            category = detection.get("category", "person")
            # Include segmentation if available (like in eg.json)
            if detection.get("masks"):
                segmentation = detection.get("masks", [])
                detection_obj = self.create_detection_object(category, bbox, segmentation=segmentation)
            elif detection.get("segmentation"):
                segmentation = detection.get("segmentation")
                detection_obj = self.create_detection_object(category, bbox, segmentation=segmentation)
            elif detection.get("mask"):
                segmentation = detection.get("mask")
                detection_obj = self.create_detection_object(category, bbox, segmentation=segmentation)
            else:
                detection_obj = self.create_detection_object(category, bbox)
            detections.append(detection_obj)

        # Build alerts and alert_settings arrays
        alert_settings = []
        if config.alert_config and hasattr(config.alert_config, "alert_type"):
            alert_settings.append(
                {
                    "alert_type": (
                        getattr(config.alert_config, "alert_type", ["Default"])
                        if hasattr(config.alert_config, "alert_type")
                        else ["Default"]
                    ),
                    "incident_category": self.CASE_TYPE,
                    "threshold_level": (
                        config.alert_config.count_thresholds if hasattr(config.alert_config, "count_thresholds") else {}
                    ),
                    "ascending": True,
                    "settings": {
                        t: v
                        for t, v in zip(
                            getattr(config.alert_config, "alert_type", ["Default"]),
                            getattr(config.alert_config, "alert_value", ["JSON"]),
                        )
                    },
                }
            )
        if zone_analysis:
            human_text_lines = []
            current_timestamp = self._get_current_timestamp_str(stream_info, frame_id=frame_id)
            start_timestamp = self._get_start_timestamp_str(stream_info)
            self._debug_stream_timing("start_timestamp", start_timestamp)
            human_text_lines.append(f"CURRENT FRAME @ {current_timestamp}:")
            human_text_lines.append(f"\t- People Detected: {total_people}")
            for zone_name, zone_data in zone_analysis.items():
                zone_current = zone_data.get("current_count", 0)
                human_text_lines.append(f"\t- {zone_name}: {zone_current}")
            human_text_lines.append("")
            human_text_lines.append(f"TOTAL SINCE @ {start_timestamp}:")

            for zone_name, zone_data in zone_analysis.items():
                zone_total = zone_data.get("total_count", 0)
                human_text_lines.append(f"\t- {zone_name}: {zone_total}")

            if total_unique_count > 0:
                human_text_lines.append(f"\t- Total unique people in the scene: {total_unique_count}")
            if alerts:
                for alert in alerts:
                    human_text_lines.append(f"Alerts: {alert.get('settings', {})} sent @ {current_timestamp}")
            else:
                human_text_lines.append("Alerts: None")
            human_text = "\n".join(human_text_lines)
        else:
            human_text = self._generate_human_text_for_tracking(
                total_people, total_unique_count, config, frame_id, alerts, stream_info
            )

        # Create high precision timestamps for input_timestamp and reset_timestamp
        high_precision_start_timestamp = self._get_current_timestamp_str(stream_info, precision=True, frame_id=frame_id)
        high_precision_reset_timestamp = self._get_start_timestamp_str(stream_info, precision=True)
        # Create tracking_stat using standardized method
        tracking_stat = self.create_tracking_stats(
            total_counts,
            current_counts,
            detections,
            human_text,
            camera_info,
            alerts,
            alert_settings,
            start_time=high_precision_start_timestamp,
            reset_time=high_precision_reset_timestamp,
        )

        # Append per-zone occupancy so consumers (test scripts, dashboards) can read
        # zone counts directly from tracking_stats without parsing human_text.
        if zone_analysis:
            tracking_stat["zone_stats"] = [
                {
                    "zone_name": zone_name,
                    "current_count": zone_data.get("current_count", 0),
                    "total_count": zone_data.get("total_count", 0),
                    "current_track_ids": zone_data.get("current_track_ids", []),
                    "total_track_ids": zone_data.get("total_track_ids", []),
                }
                for zone_name, zone_data in zone_analysis.items()
            ]

        return [tracking_stat]

    def _generate_human_text_for_tracking(
        self,
        total_people: int,
        total_unique_count: int,
        _config: HazardZoneEntryConfig,
        frame_id: str,
        alerts: Any = [],
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Generate human-readable text for tracking stats in old format."""

        _ = (_config,)
        human_text_lines = []
        current_timestamp = self._get_current_timestamp_str(stream_info, precision=True, frame_id=frame_id)
        start_timestamp = self._get_start_timestamp_str(stream_info, precision=True)
        self._debug_stream_timing("start_timestamp", start_timestamp)

        human_text_lines.append(f"CURRENT FRAME @ {current_timestamp}:")
        human_text_lines.append(f"\t- People Detected: {total_people}")

        human_text_lines.append("")
        # if total_unique_count > 0:
        human_text_lines.append(f"TOTAL SINCE @ {start_timestamp}:")
        human_text_lines.append(f"\t- Total unique people count: {total_unique_count}")

        self.logger.debug("human_text_lines: %s", human_text_lines)

        if alerts:
            for alert in alerts:
                human_text_lines.append(f"Alerts: {alert.get('settings', {})} sent @ {current_timestamp}")
        else:
            human_text_lines.append("Alerts: None")

        return "\n".join(human_text_lines)

    def _check_alerts(
        self, counting_summary: Dict, _zone_analysis: Dict, config: HazardZoneEntryConfig, frame_id: str
    ) -> List[Dict]:
        """Check for alert conditions and generate alerts."""
        _ = (_zone_analysis,)

        def get_trend(data, lookback=900, threshold=0.6):
            """
            Determine if the trend is ascending or descending based on actual value progression.
            Now works with values 0,1,2,3 (not just binary).
            """
            window = data[-lookback:] if len(data) >= lookback else data
            if len(window) < 2:
                return True  # not enough data to determine trend
            increasing = 0
            total = 0
            for i in range(1, len(window)):
                if window[i] >= window[i - 1]:
                    increasing += 1
                total += 1
            ratio = increasing / total
            if ratio >= threshold:
                return True
            elif ratio <= (1 - threshold):
                return False
            return None

        alerts = []

        if not config.alert_config:
            return alerts

        total_people = counting_summary.get("total_objects", 0)

        # ✅ Hazard zone ENTRY alerts (event-driven)
        for det in counting_summary.get("detections", []):
            evt = det.get("_hazard_entry_event")
            if not evt:
                continue

            alerts.append(
                {
                    "alert_type": config.alert_config.alert_type,
                    "alert_id": f"hazard_entry_{evt['zone_name']}_{evt['track_id']}_{frame_id}",
                    "incident_category": self.CASE_TYPE,
                    "threshold_level": "entry",
                    "ascending": True,
                    "settings": {
                        t: v
                        for t, v in zip(
                            getattr(config.alert_config, "alert_type", ["Default"]),
                            getattr(config.alert_config, "alert_value", ["JSON"]),
                        )
                    },
                }
            )
            self._zone_alerted_tracks[evt["zone_name"]].add(evt["track_id"])
            det.pop("_hazard_entry_event", None)

        # Count threshold alerts
        if hasattr(config.alert_config, "count_thresholds") and config.alert_config.count_thresholds:

            for category, threshold in config.alert_config.count_thresholds.items():
                if category == "all" and total_people >= threshold:

                    alerts.append(
                        {
                            "alert_type": (
                                getattr(config.alert_config, "alert_type", ["Default"])
                                if hasattr(config.alert_config, "alert_type")
                                else ["Default"]
                            ),
                            "alert_id": "alert_" + category + "_" + frame_id,
                            "incident_category": self.CASE_TYPE,
                            "threshold_level": threshold,
                            "ascending": get_trend(self._ascending_alert_list, lookback=900, threshold=0.8),
                            "settings": {
                                t: v
                                for t, v in zip(
                                    getattr(config.alert_config, "alert_type", ["Default"]),
                                    getattr(config.alert_config, "alert_value", ["JSON"]),
                                )
                            },
                        }
                    )
                elif category in counting_summary.get("categories", {}):
                    count = counting_summary["categories"][category]

                    if count >= threshold:
                        alerts.append(
                            {
                                "alert_type": (
                                    getattr(config.alert_config, "alert_type", ["Default"])
                                    if hasattr(config.alert_config, "alert_type")
                                    else ["Default"]
                                ),
                                "alert_id": "alert_" + category + "_" + frame_id,
                                "incident_category": self.CASE_TYPE,
                                "threshold_level": threshold,
                                "ascending": get_trend(self._ascending_alert_list, lookback=900, threshold=0.8),
                                "settings": {
                                    t: v
                                    for t, v in zip(
                                        getattr(config.alert_config, "alert_type", ["Default"]),
                                        getattr(config.alert_config, "alert_value", ["JSON"]),
                                    )
                                },
                            }
                        )
        else:
            pass

        return alerts

    def _generate_business_analytics(
        self,
        counting_summary: Dict,
        zone_analysis: Dict,
        config: HazardZoneEntryConfig,
        frame_id: str,
        stream_info: Optional[Dict[str, Any]] = None,
        is_empty=False,
    ) -> List[Dict]:
        """Generate standardized business analytics for the agg_summary structure."""
        if is_empty:
            return []
        business_analytics = []

        total_people = counting_summary.get("total_objects", 0)

        # Get camera info using standardized method
        camera_info = self.get_camera_info_from_stream(stream_info)

        if total_people > 0 or config.enable_analytics:
            # Calculate analytics statistics
            analytics_stats = {
                "people_count": total_people,
                "unique_people_count": self.get_total_count(),
                "current_frame_count": self.get_current_frame_count(),
            }

            # Add zone analytics if available
            if zone_analysis:
                zone_stats = {}
                for zone_name, zone_count in zone_analysis.items():
                    zone_total = zone_count.get("current_count", 0)
                    zone_stats[f"{zone_name}_occupancy"] = zone_total
                analytics_stats.update(zone_stats)

            # Generate human text for analytics
            current_timestamp = self._get_current_timestamp_str(stream_info, frame_id=frame_id)
            start_timestamp = self._get_start_timestamp_str(stream_info)
            self._debug_stream_timing("start_timestamp", start_timestamp)

            analytics_human_text = self.generate_analytics_human_text(
                "hazard_zone_analytics", analytics_stats, current_timestamp, start_timestamp
            )

            # Create business analytics using standardized method
            analytics = self.create_business_analytics(
                "people_counting_analytics", analytics_stats, analytics_human_text, camera_info
            )
            business_analytics.append(analytics)

        return business_analytics

    def _generate_summary(
        self, _summary: dict, incidents: List, tracking_stats: List, business_analytics: List, _alerts: List
    ) -> List[str]:
        """
        Generate a human_text string for the tracking_stat, incident, business analytics and alerts.
        """
        _ = (_alerts, _summary)
        lines = []
        lines.append("Application Name: " + self.CASE_TYPE)
        lines.append("Application Version: " + self.CASE_VERSION)
        if len(incidents) > 0:
            lines.append("Incidents: " + f"\n\t{incidents[0].get('human_text', 'No incidents detected')}")
        if len(tracking_stats) > 0:
            lines.append(
                "Tracking Statistics: " + f"\t{tracking_stats[0].get('human_text', 'No tracking statistics detected')}"
            )
        if len(business_analytics) > 0:
            lines.append(
                "Business Analytics: "
                + f"\t{business_analytics[0].get('human_text', 'No business analytics detected')}"
            )

        if len(incidents) == 0 and len(tracking_stats) == 0 and len(business_analytics) == 0:
            lines.append("Summary: " + "No Summary Data")

        return ["\n".join(lines)]

    def _calculate_metrics(
        self, counting_summary: Dict, zone_analysis: Dict, config: HazardZoneEntryConfig, context: ProcessingContext
    ) -> Dict[str, Any]:
        """Calculate detailed metrics for analytics."""
        total_people = counting_summary.get("total_objects", 0)

        metrics = {
            "total_people": total_people,
            "processing_time": context.processing_time or 0.0,
            "input_format": context.input_format.value,
            "confidence_threshold": config.confidence_threshold,
            "zones_analyzed": len(zone_analysis),
            "detection_rate": 0.0,
            "coverage_percentage": 0.0,
        }

        # Calculate detection rate
        if config.time_window_minutes and config.time_window_minutes > 0:
            metrics["detection_rate"] = (total_people / config.time_window_minutes) * 60

        # Calculate zone coverage
        if zone_analysis and total_people > 0:
            people_in_zones = 0
            for zone_counts in zone_analysis.values():
                if isinstance(zone_counts, dict):
                    for v in zone_counts.values():
                        if isinstance(v, int):
                            people_in_zones += v
                        elif isinstance(v, list):
                            people_in_zones += len(v)
                elif isinstance(zone_counts, list):
                    people_in_zones += len(zone_counts)
                elif isinstance(zone_counts, int):
                    people_in_zones += zone_counts
            metrics["coverage_percentage"] = (people_in_zones / total_people) * 100

        # Unique tracking metrics
        if config.enable_unique_counting:
            unique_count = self._count_unique_tracks(counting_summary, config)
            if unique_count is not None:
                metrics["unique_people"] = unique_count
                metrics["tracking_efficiency"] = (unique_count / total_people) * 100 if total_people > 0 else 0

        # Per-zone metrics
        if zone_analysis:
            zone_metrics = {}
            for zone_name, zone_counts in zone_analysis.items():
                # Robustly sum counts, handling dicts with int or list values
                if isinstance(zone_counts, dict):
                    zone_total = 0
                    for v in zone_counts.values():
                        if isinstance(v, int):
                            zone_total += v
                        elif isinstance(v, list):
                            zone_total += len(v)
                elif isinstance(zone_counts, list):
                    zone_total = len(zone_counts)
                elif isinstance(zone_counts, int):
                    zone_total = zone_counts
                else:
                    zone_total = 0
                zone_metrics[zone_name] = {
                    "count": zone_total,
                    "percentage": (zone_total / total_people) * 100 if total_people > 0 else 0,
                }
            metrics["zone_metrics"] = zone_metrics

        return metrics

    def _extract_predictions(self, data: Any) -> List[Dict[str, Any]]:
        """Extract predictions from processed data for API compatibility."""
        predictions = []

        try:
            if isinstance(data, list):
                # Detection format
                for item in data:
                    prediction = self._normalize_prediction(item)
                    if prediction:
                        predictions.append(prediction)

            elif isinstance(data, dict):
                # Frame-based or tracking format
                for frame_id, items in data.items():
                    if isinstance(items, list):
                        for item in items:
                            prediction = self._normalize_prediction(item)
                            if prediction:
                                prediction["frame_id"] = frame_id
                                predictions.append(prediction)

        except Exception as e:
            self.logger.warning(f"Failed to extract predictions: {str(e)}")

        return predictions

    def _normalize_prediction(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize a single prediction item."""
        if not isinstance(item, dict):
            return {}

        return {
            "category": item.get("category", item.get("class", "unknown")),
            "confidence": item.get("confidence", item.get("score", 0.0)),
            "bounding_box": item.get("bounding_box", item.get("bbox", {})),
            "track_id": item.get("track_id"),
        }

    def _get_detections_with_confidence(self, counting_summary: Dict) -> List[Dict]:
        """Extract detection items with confidence scores."""
        return counting_summary.get("detections", [])

    def _count_unique_tracks(self, _counting_summary: Dict, config: HazardZoneEntryConfig = None) -> Optional[int]:
        """Count unique tracks if tracking is enabled."""
        # Always update tracking state regardless of enable_unique_counting setting
        # self._update_tracking_state(counting_summary)

        # Only return the count if unique counting is enabled
        _ = (_counting_summary,)
        if config and config.enable_unique_counting:
            return self._total_count if self._total_count > 0 else None
        else:
            return None

    def _update_tracking_state(self, counting_summary: Dict) -> None:
        """Update tracking state with current frame data with 3-frame confirmation.

        Behavior:
        - Prefer tracker-provided track_id when available (from AdvancedTracker).
        - Otherwise use IoU-based canonical aliasing with tight person-specific thresholds.
        - Only add a canonical_id to cumulative total after it appears in 3 consecutive frames.
        - Cumulative totals never decrease.
        """
        detections = self._get_detections_with_confidence(counting_summary)

        if not detections:
            # If no detections this frame, decay consecutive counters softly rather than clearing,
            # so brief detector dropouts don't reset confirmation progress.
            for tid in list(self._consecutive_track_frames.keys()):
                self._consecutive_track_frames[tid] = max(0, self._consecutive_track_frames[tid] - 1)
            self._current_frame_track_ids = set()
            self._last_update_time = time.time()
            return

        current_frame_tracks: Set[Any] = set()

        ephemeral_seq = 0
        for detection in detections:
            raw_track_id = detection.get("track_id")
            bbox = detection.get("bounding_box", detection.get("bbox"))
            if not bbox:
                continue

            # If no tracker id yet, generate ephemeral then alias-merge by IoU
            if raw_track_id is None:
                raw_track_id = self._generate_ephemeral_track_id(bbox, ephemeral_seq)
                ephemeral_seq += 1

            canonical_id = self._merge_or_register_track(raw_track_id, bbox)
            detection["track_id"] = canonical_id
            current_frame_tracks.add(canonical_id)

        # Update consecutive presence counts for confirmation
        updated_consecutive: Dict[Any, int] = {}
        for tid in current_frame_tracks:
            prev = self._consecutive_track_frames.get(tid, 0)
            updated_consecutive[tid] = min(self._min_confirm_frames, prev + 1)
        # carry over decayed counts for those not seen this frame (bounded by 0)
        for tid, prev in self._consecutive_track_frames.items():
            if tid not in updated_consecutive:
                updated_consecutive[tid] = max(0, prev - 1)
        self._consecutive_track_frames = updated_consecutive

        # Promote confirmed tracks to cumulative unique set
        for tid, count in self._consecutive_track_frames.items():
            if count >= self._min_confirm_frames:
                if tid not in self._total_track_ids:
                    self._total_track_ids.add(tid)

        # Overwrite current-frame set
        self._current_frame_track_ids = current_frame_tracks
        self._last_update_time = time.time()

        # Cumulative total never decreases
        self._total_count = len(self._total_track_ids)

    def _generate_ephemeral_track_id(self, bbox: Any, seq: int) -> str:
        """Create a short-lived raw track id for detections without a track_id.

        Combines a coarse hash of the bbox geometry with a per-call sequence and
        a millisecond timestamp, so the same person across adjacent frames will
        still be merged to the same canonical track via IoU and time window,
        while avoiding long-lived ID collisions across distant calls.
        """
        try:
            # Normalize bbox to xyxy list for hashing
            if isinstance(bbox, dict):
                if "x1" in bbox:
                    xyxy = [bbox.get("x1"), bbox.get("y1"), bbox.get("x2"), bbox.get("y2")]
                elif "xmin" in bbox:
                    xyxy = [bbox.get("xmin"), bbox.get("ymin"), bbox.get("xmax"), bbox.get("ymax")]
                else:
                    values = list(bbox.values())
                    xyxy = values[:4] if len(values) >= 4 else []
            elif isinstance(bbox, list):
                xyxy = bbox[:4]
            else:
                xyxy = []

            if len(xyxy) < 4:
                xyxy = [0, 0, 0, 0]

            x1, y1, x2, y2 = xyxy
            # Coarse-quantize geometry to stabilize hash across minor jitter
            cx = int(round((float(x1) + float(x2)) / 2.0))
            cy = int(round((float(y1) + float(y2)) / 2.0))
            w = int(round(abs(float(x2) - float(x1))))
            h = int(round(abs(float(y2) - float(y1))))
            geom_token = f"{cx}_{cy}_{w}_{h}"
        except Exception:
            geom_token = "0_0_0_0"

        ms = int(time.time() * 1000)
        return f"tmp_{ms}_{seq}_{abs(hash(geom_token)) % 1000003}"

    def get_total_count(self) -> int:
        """Get the total count of unique people tracked across all calls."""
        return self._total_count

    def get_current_frame_count(self) -> int:
        """Get the count of people in the current frame."""
        return len(self._current_frame_track_ids)

    def get_total_frames_processed(self) -> int:
        """Get the total number of frames processed across all calls."""
        return self._total_frame_counter

    def set_global_frame_offset(self, offset: int) -> None:
        """Set the global frame offset for video chunk processing."""
        self._global_frame_offset = offset
        self.logger.info(f"Global frame offset set to: {offset}")

    def get_global_frame_offset(self) -> int:
        """Get the current global frame offset."""
        return self._global_frame_offset

    def update_global_frame_offset(self, frames_in_chunk: int) -> None:
        """Update global frame offset after processing a chunk."""
        old_offset = self._global_frame_offset
        self._global_frame_offset += frames_in_chunk
        self.logger.info(
            f"Global frame offset updated: {old_offset} -> {self._global_frame_offset} (added {frames_in_chunk} frames)"
        )

    def get_global_frame_id(self, local_frame_id: str) -> str:
        """Convert local frame ID to global frame ID."""
        try:
            # Try to convert local_frame_id to integer
            local_frame_num = int(local_frame_id)
            global_frame_num = local_frame_num  # + self._global_frame_offset
            return str(global_frame_num)
        except (ValueError, TypeError):
            # If local_frame_id is not a number (e.g., timestamp), return as is
            return local_frame_id

    def get_track_ids_info(self) -> Dict[str, Any]:
        """Get detailed information about track IDs."""
        return {
            "total_count": self._total_count,
            "current_frame_count": len(self._current_frame_track_ids),
            "total_unique_track_ids": len(self._total_track_ids),
            "current_frame_track_ids": list(self._current_frame_track_ids),
            "last_update_time": self._last_update_time,
            "total_frames_processed": self._total_frame_counter,
        }

    def get_tracking_debug_info(self) -> Dict[str, Any]:
        """Get detailed debugging information about tracking state."""
        return {
            "total_track_ids": list(self._total_track_ids),
            "current_frame_track_ids": list(self._current_frame_track_ids),
            "total_count": self._total_count,
            "current_frame_count": len(self._current_frame_track_ids),
            "total_frames_processed": self._total_frame_counter,
            "last_update_time": self._last_update_time,
            "zone_current_track_ids": {zone: list(tracks) for zone, tracks in self._zone_current_track_ids.items()},
            "zone_total_track_ids": {zone: list(tracks) for zone, tracks in self._zone_total_track_ids.items()},
            "zone_current_counts": self._zone_current_counts.copy(),
            "zone_total_counts": self._zone_total_counts.copy(),
            "global_frame_offset": self._global_frame_offset,
            "frames_in_current_chunk": self._frames_in_current_chunk,
        }

    def get_frame_info(self) -> Dict[str, Any]:
        """Get detailed information about frame processing and global frame offset."""
        return {
            "global_frame_offset": self._global_frame_offset,
            "total_frames_processed": self._total_frame_counter,
            "frames_in_current_chunk": self._frames_in_current_chunk,
            "next_global_frame": self._global_frame_offset + self._frames_in_current_chunk,
        }

    def reset_tracking_state(self) -> None:
        """
          WARNING: This completely resets ALL tracking data including cumulative totals!

        This should ONLY be used when:
        - Starting a completely new tracking session
        - Switching to a different video/stream
        - Manual reset requested by user

        For clearing expired/stale tracks, use clear_current_frame_tracking() instead.
        """
        self._total_track_ids.clear()
        self._current_frame_track_ids.clear()
        self._total_count = 0
        self._last_update_time = time.time()

        # Clear zone tracking data
        self._zone_current_track_ids.clear()
        self._zone_total_track_ids.clear()
        self._zone_current_counts.clear()
        self._zone_total_counts.clear()
        self._zone_alerted_tracks.clear()
        self._zone_inside_frames.clear()
        self._zone_outside_frames.clear()

        # Reset frame counter and global frame offset
        self._total_frame_counter = 0
        self._global_frame_offset = 0
        self._frames_in_current_chunk = 0

        # Clear aliasing information
        self._canonical_tracks.clear()
        self._track_aliases.clear()
        self._tracking_start_time = None

        self.logger.warning(
            " FULL tracking state reset - all track IDs, zone data, frame counter, and global frame offset cleared. Cumulative totals lost!"
        )

    def clear_current_frame_tracking(self) -> int:
        """
        MANUAL USE ONLY: Clear only current frame tracking data while preserving cumulative totals.

         This method is NOT called automatically anywhere in the code.

        This is the SAFE method to use for manual clearing of stale/expired current frame data.
        The cumulative total (self._total_count) is always preserved.

        In streaming scenarios, you typically don't need to call this at all.

        Returns:
            Number of current frame tracks cleared
        """
        old_current_count = len(self._current_frame_track_ids)
        self._current_frame_track_ids.clear()

        # Clear current zone tracking (but keep total zone tracking)
        cleared_zone_tracks = 0
        for zone_name in list(self._zone_current_track_ids.keys()):
            cleared_zone_tracks += len(self._zone_current_track_ids[zone_name])
            self._zone_current_track_ids[zone_name].clear()
            self._zone_current_counts[zone_name] = 0

        # Update timestamp
        self._last_update_time = time.time()

        self.logger.info(
            f"Cleared {old_current_count} current frame tracks and {cleared_zone_tracks} zone current tracks. Cumulative total preserved: {self._total_count}"
        )
        return old_current_count

    def reset_frame_counter(self) -> None:
        """Reset only the frame counter."""
        old_count = self._total_frame_counter
        self._total_frame_counter = 0
        self.logger.info(f"Frame counter reset from {old_count} to 0")

    def clear_expired_tracks(self, max_age_seconds: float = 300.0) -> int:
        """
        MANUAL USE ONLY: Clear current frame tracking data if no updates for a while.

          This method is NOT called automatically anywhere in the code.
        It's provided as a utility function for manual cleanup if needed.

        In streaming scenarios, you typically don't need to call this at all.
        The cumulative total should keep growing as new unique people are detected.

        This method only clears current frame tracking data while preserving
        the cumulative total count. The cumulative total should never decrease.

        Args:
            max_age_seconds: Maximum age in seconds before clearing current frame tracks

        Returns:
            Number of current frame tracks cleared
        """
        current_time = time.time()
        if current_time - self._last_update_time > max_age_seconds:
            # Use the safe method that preserves cumulative totals
            cleared_count = self.clear_current_frame_tracking()
            self.logger.info(
                f"Manual cleanup: cleared {cleared_count} expired current frame tracks (age > {max_age_seconds}s)"
            )
            return cleared_count
        return 0

    def _update_zone_tracking(
        self, zone_analysis: Dict[str, Dict[str, int]], detections: List[Dict], config: HazardZoneEntryConfig
    ) -> Dict[str, Dict[str, Any]]:
        """
        Update zone tracking with current frame data.

        Args:
            zone_analysis: Current zone analysis results
            detections: List of detections with track IDs
            config: People counting configuration with zone polygons

        Returns:
            Enhanced zone analysis with tracking information
        """

        if config.zone_config and config.zone_config.zones:
            zones = config.zone_config.zones
        else:
            # No zones configured — nothing to track
            return {}

        enhanced_zone_analysis = {}

        # Get current frame track IDs in each zone
        current_frame_zone_tracks = {}

        # Initialize zone tracking for all zones
        for zone_name in zones.keys():
            current_frame_zone_tracks[zone_name] = set()
            if zone_name not in self._zone_total_track_ids:
                self._zone_total_track_ids[zone_name] = set()

            if zone_name not in self._zone_alerted_tracks:
                self._zone_alerted_tracks[zone_name] = set()

            if zone_name not in self._zone_inside_frames:
                self._zone_inside_frames[zone_name] = {}

            if zone_name not in self._zone_outside_frames:
                self._zone_outside_frames[zone_name] = {}

        # Check each detection against each zone
        for detection in detections:
            track_id = detection.get("track_id")
            if track_id is None:
                continue

            # Get detection bbox
            bbox = detection.get("bounding_box", detection.get("bbox"))
            if not bbox:
                continue

            # Get detection center point
            center_point = get_bbox_bottom25_center(bbox)
            # get_bbox_center(bbox)

            # Check which zone this detection is in using actual zone polygons
            for zone_name, zone_polygon in zones.items():
                # Convert polygon points to tuples for point_in_polygon function
                # zone_polygon format: [[x1, y1], [x2, y2], [x3, y3], ...]
                polygon_points = [(point[0], point[1]) for point in zone_polygon]

                # Check if detection center is inside the zone polygon using ray casting algorithm

                if point_in_polygon(center_point, polygon_points):
                    current_frame_zone_tracks[zone_name].add(track_id)

                    prev = self._zone_inside_frames[zone_name].get(track_id, 0)
                    self._zone_inside_frames[zone_name][track_id] = prev + 1
                    self._zone_outside_frames[zone_name].pop(track_id, None)

                    inside_count = self._zone_inside_frames[zone_name][track_id]

                    if (
                        inside_count == config.min_inside_frames
                        and track_id not in self._zone_alerted_tracks[zone_name]
                    ):
                        detection["_hazard_entry_event"] = {"zone_name": zone_name, "track_id": track_id}

                else:
                    outside = self._zone_outside_frames[zone_name].get(track_id, 0) + 1
                    self._zone_outside_frames[zone_name][track_id] = outside

                    if outside >= config.exit_grace_frames and track_id not in current_frame_zone_tracks[zone_name]:

                        self._zone_inside_frames[zone_name].pop(track_id, None)
                        self._zone_outside_frames[zone_name].pop(track_id, None)
                        self._zone_alerted_tracks[zone_name].discard(track_id)

        # Update zone tracking for each zone
        for zone_name, zone_counts in zone_analysis.items():
            # Get current frame tracks for this zone
            current_tracks = current_frame_zone_tracks.get(zone_name, set())

            # Update current zone tracks
            self._zone_current_track_ids[zone_name] = current_tracks

            # Update total zone tracks (accumulate all track IDs that have been in this zone)
            self._zone_total_track_ids[zone_name].update(current_tracks)

            # Update counts
            self._zone_current_counts[zone_name] = len(current_tracks)
            self._zone_total_counts[zone_name] = len(self._zone_total_track_ids[zone_name])

            # Create enhanced zone analysis
            enhanced_zone_analysis[zone_name] = {
                "current_count": self._zone_current_counts[zone_name],
                "total_count": self._zone_total_counts[zone_name],
                "current_track_ids": list(current_tracks),
                "total_track_ids": list(self._zone_total_track_ids[zone_name]),
                "original_counts": zone_counts,  # Preserve original zone counts
            }

        return enhanced_zone_analysis

    def get_zone_tracking_info(self) -> Dict[str, Dict[str, Any]]:
        """Get detailed zone tracking information."""
        return {
            zone_name: {
                "current_count": self._zone_current_counts.get(zone_name, 0),
                "total_count": self._zone_total_counts.get(zone_name, 0),
                "current_track_ids": list(self._zone_current_track_ids.get(zone_name, set())),
                "total_track_ids": list(self._zone_total_track_ids.get(zone_name, set())),
            }
            for zone_name in set(self._zone_current_counts.keys()) | set(self._zone_total_counts.keys())
        }

    def get_zone_current_count(self, zone_name: str) -> int:
        """Get current count of people in a specific zone."""
        return self._zone_current_counts.get(zone_name, 0)

    def get_zone_total_count(self, zone_name: str) -> int:
        """Get total count of people who have been in a specific zone."""
        return self._zone_total_counts.get(zone_name, 0)

    def get_all_zone_counts(self) -> Dict[str, Dict[str, int]]:
        """Get current and total counts for all zones."""
        return {
            zone_name: {
                "current": self._zone_current_counts.get(zone_name, 0),
                "total": self._zone_total_counts.get(zone_name, 0),
            }
            for zone_name in set(self._zone_current_counts.keys()) | set(self._zone_total_counts.keys())
        }

    def _format_timestamp_for_stream(self, timestamp: float) -> str:
        """Format timestamp for streams (YYYY:MM:DD HH:MM:SS format)."""
        dt = datetime.fromtimestamp(float(timestamp), tz=timezone.utc)
        return dt.strftime("%Y:%m:%d %H:%M:%S")

    def _format_timestamp_for_video(self, timestamp: float) -> str:
        """Format timestamp for video chunks (HH:MM:SS.ms format)."""
        hours = int(timestamp // 3600)
        minutes = int((timestamp % 3600) // 60)
        seconds = round(float(timestamp % 60), 2)
        return f"{hours:02d}:{minutes:02d}:{seconds:.1f}"

    def _get_current_timestamp_str(
        self, stream_info: Optional[Dict[str, Any]], precision=False, frame_id: Optional[str] = None
    ) -> str:
        """Get formatted current timestamp based on stream type."""

        if not stream_info:
            return "00:00:00.00"
        if precision:
            if stream_info.get("input_settings", {}).get("start_frame", "na") != "na":
                if frame_id:
                    start_time = int(frame_id) / stream_info.get("input_settings", {}).get("original_fps", 30)
                else:
                    start_time = stream_info.get("input_settings", {}).get("start_frame", 30) / stream_info.get(
                        "input_settings", {}
                    ).get("original_fps", 30)
                stream_time_str = self._format_timestamp_for_video(start_time)
                self._debug_stream_timing("stream_time_str", stream_time_str)
                return self._format_timestamp(stream_info.get("input_settings", {}).get("stream_time", "NA"))
            else:
                return datetime.now(timezone.utc).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")

        if stream_info.get("input_settings", {}).get("start_frame", "na") != "na":
            if frame_id:
                start_time = int(frame_id) / stream_info.get("input_settings", {}).get("original_fps", 30)
            else:
                start_time = stream_info.get("input_settings", {}).get("start_frame", 30) / stream_info.get(
                    "input_settings", {}
                ).get("original_fps", 30)

            stream_time_str = self._format_timestamp_for_video(start_time)

            self._debug_stream_timing("stream_time_str", stream_time_str)
            return self._format_timestamp(stream_info.get("input_settings", {}).get("stream_time", "NA"))
        else:
            stream_time_str = stream_info.get("input_settings", {}).get("stream_info", {}).get("stream_time", "")
            if stream_time_str:
                try:
                    timestamp_str = stream_time_str.replace(" UTC", "")
                    dt = datetime.strptime(timestamp_str, "%Y-%m-%d-%H:%M:%S.%f")
                    timestamp = dt.replace(tzinfo=timezone.utc).timestamp()
                    return self._format_timestamp_for_stream(timestamp)
                except Exception:
                    return self._format_timestamp_for_stream(time.time())
            else:
                return self._format_timestamp_for_stream(time.time())

    def _get_start_timestamp_str(self, stream_info: Optional[Dict[str, Any]], precision=False) -> str:
        """Get formatted start timestamp for 'TOTAL SINCE' based on stream type."""
        if not stream_info:
            return "00:00:00"

        if precision:
            if self.start_timer is None:
                self.start_timer = stream_info.get("input_settings", {}).get(
                    "stream_time", datetime.now(timezone.utc).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")
                )
                return self._format_timestamp(self.start_timer)
            elif stream_info.get("input_settings", {}).get("start_frame", "na") == 1:
                self.start_timer = stream_info.get("input_settings", {}).get(
                    "stream_time", datetime.now(timezone.utc).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")
                )
                return self._format_timestamp(self.start_timer)
            else:
                return self._format_timestamp(self.start_timer)

        if self.start_timer is None:
            self.start_timer = stream_info.get("input_settings", {}).get(
                "stream_time", datetime.now(timezone.utc).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")
            )
            return self._format_timestamp(self.start_timer)
        elif stream_info.get("input_settings", {}).get("start_frame", "na") == 1:
            self.start_timer = stream_info.get("input_settings", {}).get(
                "stream_time", datetime.now(timezone.utc).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")
            )
            return self._format_timestamp(self.start_timer)

        else:
            if self.start_timer is not None:
                return self._format_timestamp(self.start_timer)

            if self._tracking_start_time is None:
                stream_time_str = stream_info.get("input_settings", {}).get("stream_info", {}).get("stream_time", "")
                if stream_time_str:
                    try:
                        timestamp_str = stream_time_str.replace(" UTC", "")
                        dt = datetime.strptime(timestamp_str, "%Y-%m-%d-%H:%M:%S.%f")
                        self._tracking_start_time = dt.replace(tzinfo=timezone.utc).timestamp()
                    except Exception:
                        self._tracking_start_time = time.time()
                else:
                    self._tracking_start_time = time.time()

            dt = datetime.fromtimestamp(self._tracking_start_time, tz=timezone.utc)
            dt = dt.replace(minute=0, second=0, microsecond=0)
            return dt.strftime("%Y:%m:%d %H:%M:%S")

    def _extract_frame_id_from_tracking(self, frame_detections: List[Dict], frame_key: str) -> str:
        """Extract frame ID from tracking data."""
        # Priority 1: Check if detections have frame information
        if frame_detections and len(frame_detections) > 0:
            first_detection = frame_detections[0]
            if "frame" in first_detection:
                return str(first_detection["frame"])
            elif "frame_id" in first_detection:
                return str(first_detection["frame_id"])
        # Priority 2: Use frame_key from input data
        return str(frame_key)

    def _robust_zone_total(self, zone_count):
        """Helper method to robustly calculate zone total."""
        if isinstance(zone_count, dict):
            total = 0
            for v in zone_count.values():
                if isinstance(v, int):
                    total += v
                elif isinstance(v, list):
                    total += len(v)
            return total
        elif isinstance(zone_count, list):
            return len(zone_count)
        elif isinstance(zone_count, int):
            return zone_count
        else:
            return 0

    # --------------------------------------------------------------------- #
    # Private helpers for canonical track aliasing                          #
    # --------------------------------------------------------------------- #

    def _compute_iou(self, box1: Any, box2: Any) -> float:
        """Compute IoU between two bounding boxes that may be either list or dict.
        Falls back to geometry_utils.calculate_iou when both boxes are dicts.
        """
        # Handle dict format directly with calculate_iou (supports many keys)
        if isinstance(box1, dict) and isinstance(box2, dict):
            return calculate_iou(box1, box2)

        # Helper to convert bbox (dict or list) to a list [x1,y1,x2,y2]
        def _bbox_to_list(bbox):
            if bbox is None:
                return []
            if isinstance(bbox, list):
                return bbox[:4] if len(bbox) >= 4 else []
            if isinstance(bbox, dict):
                if "xmin" in bbox:
                    return [bbox["xmin"], bbox["ymin"], bbox["xmax"], bbox["ymax"]]
                if "x1" in bbox:
                    return [bbox["x1"], bbox["y1"], bbox["x2"], bbox["y2"]]
                # Fallback: take first four values in insertion order
                values = list(bbox.values())
                return values[:4] if len(values) >= 4 else []
            # Unsupported type
            return []

        list1 = _bbox_to_list(box1)
        list2 = _bbox_to_list(box2)

        if len(list1) < 4 or len(list2) < 4:
            return 0.0

        x1_min, y1_min, x1_max, y1_max = list1
        x2_min, y2_min, x2_max, y2_max = list2

        # Ensure correct ordering of coordinates
        x1_min, x1_max = min(x1_min, x1_max), max(x1_min, x1_max)
        y1_min, y1_max = min(y1_min, y1_max), max(y1_min, y1_max)
        x2_min, x2_max = min(x2_min, x2_max), max(x2_min, x2_max)
        y2_min, y2_max = min(y2_min, y2_max), max(y2_min, y2_max)

        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)

        inter_w = max(0.0, inter_x_max - inter_x_min)
        inter_h = max(0.0, inter_y_max - inter_y_min)
        inter_area = inter_w * inter_h

        area1 = (x1_max - x1_min) * (y1_max - y1_min)
        area2 = (x2_max - x2_min) * (y2_max - y2_min)
        union_area = area1 + area2 - inter_area

        return (inter_area / union_area) if union_area > 0 else 0.0

    def _get_canonical_id(self, raw_id: Any) -> Any:
        """Return the canonical ID for a raw tracker-generated ID."""
        return self._track_aliases.get(raw_id, raw_id)

    def _merge_or_register_track(self, raw_id: Any, bbox: List[float]) -> Any:
        """Merge the raw track into an existing canonical track if possible,
        otherwise register it as a new canonical track. Returns the canonical
        ID to use for counting.
        """
        now = time.time()

        # Fast path: raw_id already mapped
        if raw_id in self._track_aliases:
            canonical_id = self._track_aliases[raw_id]
            track_info = self._canonical_tracks.get(canonical_id)
            if track_info is not None:
                track_info["last_bbox"] = bbox
                track_info["last_update"] = now
                track_info["raw_ids"].add(raw_id)
            return canonical_id

        # Attempt to merge with an existing canonical track
        for canonical_id, info in self._canonical_tracks.items():
            # Only consider recently updated tracks to avoid stale matches
            if now - info["last_update"] > self._track_merge_time_window:
                continue

            iou = self._compute_iou(bbox, info["last_bbox"])
            if iou >= self._track_merge_iou_threshold:
                # Merge raw_id into canonical track
                self._track_aliases[raw_id] = canonical_id
                info["last_bbox"] = bbox
                info["last_update"] = now
                info["raw_ids"].add(raw_id)
                self.logger.debug(f"Merged raw track {raw_id} into canonical track {canonical_id} (IoU={iou:.2f})")
                return canonical_id

        # No match found – create a new canonical track
        canonical_id = raw_id
        self._track_aliases[raw_id] = canonical_id
        self._canonical_tracks[canonical_id] = {
            "last_bbox": bbox,
            "last_update": now,
            "raw_ids": {raw_id},
        }
        self.logger.debug(f"Registered new canonical track {canonical_id}")
        return canonical_id

    def _format_timestamp(self, timestamp: Any) -> str:
        """Format a timestamp so that exactly two digits follow the decimal point (milliseconds).

        The input can be either:
        1. A numeric Unix timestamp (``float`` / ``int``) – it will first be converted to a
           string in the format ``YYYY-MM-DD-HH:MM:SS.ffffff UTC``.
        2. A string already following the same layout.

        The returned value preserves the overall format of the input but truncates or pads
        the fractional seconds portion to **exactly two digits**.

        Example
        -------
        >>> self._format_timestamp("2025-08-19-04:22:47.187574 UTC")
        '2025-08-19-04:22:47.18 UTC'
        """

        # Convert numeric timestamps to the expected string representation first
        if isinstance(timestamp, (int, float)):
            timestamp = datetime.fromtimestamp(timestamp, timezone.utc).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")

        # Ensure we are working with a string from here on
        if not isinstance(timestamp, str):
            return str(timestamp)

        # If there is no fractional component, simply return the original string
        if "." not in timestamp:
            return timestamp

        # Split out the main portion (up to the decimal point)
        main_part, fractional_and_suffix = timestamp.split(".", 1)

        # Separate fractional digits from the suffix (typically ' UTC')
        if " " in fractional_and_suffix:
            fractional_part, suffix = fractional_and_suffix.split(" ", 1)
            suffix = " " + suffix  # Re-attach the space removed by split
        else:
            fractional_part, suffix = fractional_and_suffix, ""

        # Guarantee exactly two digits for the fractional part
        fractional_part = (fractional_part + "00")[:2]

        return f"{main_part}.{fractional_part}{suffix}"

    def _get_tracking_start_time(self) -> str:
        """Get the tracking start time, formatted as a string."""
        if self._tracking_start_time is None:
            return "N/A"
        return self._format_timestamp(self._tracking_start_time)

    def _set_tracking_start_time(self) -> None:
        """Set the tracking start time to the current time."""
        self._tracking_start_time = time.time()

    def get_config_schema(self) -> Dict[str, Any]:
        """Get configuration schema for people counting."""
        return {
            "type": "object",
            "properties": {
                "confidence_threshold": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                    "default": 0.5,
                    "description": "Minimum confidence threshold for detections",
                },
                "enable_tracking": {
                    "type": "boolean",
                    "default": False,
                    "description": "Enable tracking for unique counting",
                },
                "zone_config": {
                    "type": "object",
                    "properties": {
                        "zones": {
                            "type": "object",
                            "additionalProperties": {
                                "type": "array",
                                "items": {"type": "array", "items": {"type": "number"}, "minItems": 2, "maxItems": 2},
                                "minItems": 3,
                            },
                            "description": "Zone definitions as polygons",
                        },
                        "zone_confidence_thresholds": {
                            "type": "object",
                            "additionalProperties": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                            "description": "Per-zone confidence thresholds",
                        },
                    },
                },
                "person_categories": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": ["person", "people"],
                    "description": "Category names that represent people",
                },
                "target_categories": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": ["person", "people"],
                    "description": "Category names that represent people",
                },
                "enable_unique_counting": {
                    "type": "boolean",
                    "default": True,
                    "description": "Enable unique people counting using tracking",
                },
                "time_window_minutes": {
                    "type": "integer",
                    "minimum": 1,
                    "default": 60,
                    "description": "Time window for counting analysis in minutes",
                },
                "alert_config": {
                    "type": "object",
                    "properties": {
                        "count_thresholds": {
                            "type": "object",
                            "additionalProperties": {"type": "integer", "minimum": 1},
                            "description": "Count thresholds for alerts",
                        },
                        "occupancy_thresholds": {
                            "type": "object",
                            "additionalProperties": {"type": "integer", "minimum": 1},
                            "description": "Zone occupancy thresholds for alerts",
                        },
                        "alert_type": {
                            "type": "array",
                            "items": {"type": "string"},
                            "default": ["Default"],
                            "description": "To pass the type of alert. EG: email, sms, etc.",
                        },
                        "alert_value": {
                            "type": "array",
                            "items": {"type": "string"},
                            "default": ["JSON"],
                            "description": "Alert value to pass the value based on type. EG: email id if type is email.",
                        },
                        "alert_incident_category": {
                            "type": "array",
                            "items": {"type": "string"},
                            "default": ["Incident Detection Alert"],
                            "description": "Group and name the Alert category Type",
                        },
                    },
                },
            },
            "required": ["confidence_threshold"],
            "additionalProperties": False,
        }

    def create_default_config(self, **overrides) -> HazardZoneEntryConfig:
        """Create default configuration with optional overrides."""
        defaults = {
            "category": self.category,
            "usecase": self.name,
            "confidence_threshold": 0.5,
            "enable_tracking": True,
            "enable_analytics": True,
            "enable_unique_counting": True,
            "time_window_minutes": 60,
            "person_categories": ["person", "people"],
            "target_categories": ["person", "people", "human", "man", "woman", "male", "female"],
        }
        defaults.update(overrides)
        return HazardZoneEntryConfig(**defaults)

    def _apply_smoothing(self, data: Any, config: HazardZoneEntryConfig) -> Any:
        """Apply smoothing to tracking data if enabled."""
        if self.smoothing_tracker is None:
            smoothing_config = BBoxSmoothingConfig(
                smoothing_algorithm=config.smoothing_algorithm,
                window_size=config.smoothing_window_size,
                cooldown_frames=config.smoothing_cooldown_frames,
                confidence_threshold=config.confidence_threshold or 0.5,
                confidence_range_factor=config.smoothing_confidence_range_factor,
                enable_smoothing=True,
            )
            self.smoothing_tracker = BBoxSmoothingTracker(smoothing_config)

        smoothed_data = bbox_smoothing(data, self.smoothing_tracker.config, self.smoothing_tracker)
        self.logger.debug("Applied bbox smoothing to tracking results")
        return smoothed_data
