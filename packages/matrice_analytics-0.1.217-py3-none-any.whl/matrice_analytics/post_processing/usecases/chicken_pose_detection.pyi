"""Auto-generated stub for module: chicken_pose_detection."""
from typing import Any, Dict, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, AlertConfig
from ..utils import filter_by_confidence, apply_category_mapping, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker

# Classes
class ChickenPoseDetectionConfig:
    # Configuration for Chicken Pose Detection use case.

    ...
class ChickenPoseDetectionUseCase:
    def __init__(self: Any) -> None: ...

    CATEGORY_DISPLAY: Dict[Any, Any]

    def get_total_pose_counts(self: Any) -> Any: ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any: ...

    def reset_all_tracking(self: Any) -> None: ...

    def reset_pose_tracking(self: Any) -> None: ...

    def reset_tracker(self: Any) -> None: ...

