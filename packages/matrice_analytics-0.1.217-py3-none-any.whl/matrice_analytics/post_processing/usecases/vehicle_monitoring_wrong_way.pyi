"""Auto-generated stub for module: vehicle_monitoring_wrong_way."""
from typing import Any, Dict, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, AlertConfig
from ..utils import filter_by_confidence, apply_category_mapping, count_objects_in_zones, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker
from ..utils.geometry_utils import point_in_polygon, get_bbox_bottom25_center
from ..utils.wrong_way_tracker import WrongWayDetectionTracker

# Classes
class VehicleMonitoringWrongWayConfig:
    # Configuration for wrong-way vehicle detection use case.

    ...
class VehicleMonitoringWrongWayUseCase:
    def __init__(self: Any) -> None: ...

    CATEGORY_DISPLAY: Dict[Any, Any]

    def get_total_counts(self: Any) -> Any:
        """
        Get total counts per category.
        """
        ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any: ...

