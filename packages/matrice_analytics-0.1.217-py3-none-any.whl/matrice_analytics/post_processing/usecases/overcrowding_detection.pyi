"""Auto-generated stub for module: overcrowding_detection."""
from typing import Any, Dict, List, Optional

from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, ZoneConfig, AlertConfig
from ..utils import filter_by_confidence, apply_category_mapping, point_in_polygon

# Classes
class OvercrowdingDetectionConfig:
    def validate(self: Any) -> List[str]: ...

class OvercrowdingDetectionUseCase:
    def __init__(self: Any) -> None: ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any: ...

