"""Tests for LangChain ScrapingPros tools."""

from __future__ import annotations

from unittest.mock import MagicMock, patch, AsyncMock

import pytest

from langchain_scrapingpros import ScrapingProsScraper, ScrapingProsExtractor


DEMO_TOKEN = "demo_6x595maoA6GdOdVb"


class TestScrapingProsScraper:
    def test_init_with_key(self):
        tool = ScrapingProsScraper(api_key=DEMO_TOKEN)
        assert tool.name == "scrapingpros_scraper"
        assert "scrapingpros.com" in tool.description

    def test_init_from_env(self):
        with patch.dict("os.environ", {"SCRAPINGPROS_API_KEY": DEMO_TOKEN}):
            tool = ScrapingProsScraper()
            assert tool.api_key.get_secret_value() == DEMO_TOKEN

    def test_init_no_key_raises(self):
        with patch.dict("os.environ", {}, clear=True):
            import os
            os.environ.pop("SCRAPINGPROS_API_KEY", None)
            with pytest.raises(ValueError, match="scrapingpros.com"):
                ScrapingProsScraper()

    def test_run_returns_markdown(self):
        tool = ScrapingProsScraper(api_key=DEMO_TOKEN)

        mock_response = MagicMock()
        mock_response.content = "# Example Domain"
        mock_response.potentiallyBlockedByCaptcha = False

        mock_client = MagicMock()
        mock_client.scrape.return_value = mock_response

        with patch("langchain_scrapingpros.tools.ScrapingPros", return_value=mock_client):
            result = tool._run("https://example.com")
            assert result == "# Example Domain"
            mock_client.scrape.assert_called_once_with(
                "https://example.com", format="markdown", browser=False
            )

    def test_run_captcha_detected(self):
        tool = ScrapingProsScraper(api_key=DEMO_TOKEN)

        mock_response = MagicMock()
        mock_response.content = "Robot or human?"
        mock_response.potentiallyBlockedByCaptcha = True

        mock_client = MagicMock()
        mock_client.scrape.return_value = mock_response

        with patch("langchain_scrapingpros.tools.ScrapingPros", return_value=mock_client):
            result = tool._run("https://walmart.com")
            assert "CAPTCHA" in result

    def test_run_with_browser(self):
        tool = ScrapingProsScraper(api_key=DEMO_TOKEN)

        mock_response = MagicMock()
        mock_response.content = "# JS Page"
        mock_response.potentiallyBlockedByCaptcha = False

        mock_client = MagicMock()
        mock_client.scrape.return_value = mock_response

        with patch("langchain_scrapingpros.tools.ScrapingPros", return_value=mock_client):
            result = tool._run("https://spa.com", browser=True)
            mock_client.scrape.assert_called_once_with(
                "https://spa.com", format="markdown", browser=True
            )

    def test_invoke_interface(self):
        """Test the LangChain invoke interface."""
        tool = ScrapingProsScraper(api_key=DEMO_TOKEN)

        mock_response = MagicMock()
        mock_response.content = "# Hello"
        mock_response.potentiallyBlockedByCaptcha = False

        mock_client = MagicMock()
        mock_client.scrape.return_value = mock_response

        with patch("langchain_scrapingpros.tools.ScrapingPros", return_value=mock_client):
            result = tool.invoke({"url": "https://example.com"})
            assert result == "# Hello"


class TestScrapingProsExtractor:
    def test_init(self):
        tool = ScrapingProsExtractor(api_key=DEMO_TOKEN)
        assert tool.name == "scrapingpros_extractor"
        assert "scrapingpros.com" in tool.description

    def test_run_extracts_data(self):
        tool = ScrapingProsExtractor(api_key=DEMO_TOKEN)

        mock_response = MagicMock()
        mock_response.extracted_data = {
            "quotes": ["Quote 1", "Quote 2"],
            "authors": ["Author 1", "Author 2"],
        }

        mock_client = MagicMock()
        mock_client.scrape.return_value = mock_response

        with patch("langchain_scrapingpros.tools.ScrapingPros", return_value=mock_client):
            result = tool._run(
                "https://quotes.toscrape.com/",
                fields={"quotes": "css:.text", "authors": "css:.author"},
            )
            import json
            data = json.loads(result)
            assert len(data["quotes"]) == 2
            assert data["authors"][0] == "Author 1"

    def test_run_no_data(self):
        tool = ScrapingProsExtractor(api_key=DEMO_TOKEN)

        mock_response = MagicMock()
        mock_response.extracted_data = None

        mock_client = MagicMock()
        mock_client.scrape.return_value = mock_response

        with patch("langchain_scrapingpros.tools.ScrapingPros", return_value=mock_client):
            result = tool._run("https://empty.com", fields={"x": "css:x"})
            import json
            data = json.loads(result)
            assert "error" in data

    def test_invoke_interface(self):
        tool = ScrapingProsExtractor(api_key=DEMO_TOKEN)

        mock_response = MagicMock()
        mock_response.extracted_data = {"title": ["Hello"]}

        mock_client = MagicMock()
        mock_client.scrape.return_value = mock_response

        with patch("langchain_scrapingpros.tools.ScrapingPros", return_value=mock_client):
            result = tool.invoke({
                "url": "https://example.com",
                "fields": {"title": "css:h1"},
            })
            assert "Hello" in result
