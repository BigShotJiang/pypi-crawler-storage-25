"""LangChain integration for Scraping Pros (https://scrapingpros.com).

Provides tools for AI agents to scrape web pages, extract structured
data, and download files using the Scraping Pros API.

Example:
    >>> from langchain_scrapingpros import ScrapingProsScraper
    >>> tool = ScrapingProsScraper()
    >>> result = tool.invoke({"url": "https://example.com"})
"""

__version__ = "0.1.1"

from langchain_scrapingpros.tools import (
    ScrapingProsExtractor,
    ScrapingProsScraper,
)

__all__ = [
    "ScrapingProsScraper",
    "ScrapingProsExtractor",
]
