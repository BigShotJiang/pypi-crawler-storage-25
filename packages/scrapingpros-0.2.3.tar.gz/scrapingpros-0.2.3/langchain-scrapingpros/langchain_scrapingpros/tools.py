"""LangChain tools for Scraping Pros (https://scrapingpros.com).

Two tools for AI agents:

- **ScrapingProsScraper** — scrape a URL and return clean text (ideal for RAG)
- **ScrapingProsExtractor** — extract structured data using CSS/XPath selectors
"""

from __future__ import annotations

import json
from typing import Any, Type

from langchain_core.callbacks import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from langchain_core.tools import BaseTool, ToolException
from pydantic import BaseModel, Field, SecretStr, model_validator

from scrapingpros import ScrapingPros, AsyncScrapingPros, ScrapingProsError


# ---------------------------------------------------------------------------
# Input schemas
# ---------------------------------------------------------------------------

class ScrapeInput(BaseModel):
    """Input for the ScrapingProsScraper tool."""

    url: str = Field(description="The URL of the web page to scrape.")
    browser: bool = Field(
        default=False,
        description="Set to true for JavaScript-heavy or anti-bot protected sites.",
    )


class ExtractInput(BaseModel):
    """Input for the ScrapingProsExtractor tool."""

    url: str = Field(description="The URL to extract data from.")
    fields: dict[str, str] = Field(
        description=(
            'A mapping of field names to CSS selectors. '
            'Example: {"title": "css:h1", "prices": "css:.price"}'
        ),
    )
    browser: bool = Field(
        default=False,
        description="Set to true for JavaScript-heavy sites.",
    )


# ---------------------------------------------------------------------------
# Scraper tool
# ---------------------------------------------------------------------------

class ScrapingProsScraper(BaseTool):
    """Scrape a web page and return clean markdown text.

    Uses the `Scraping Pros API <https://scrapingpros.com>`_ with automatic
    proxy rotation and optional headless browser rendering.

    The output is clean markdown (scripts, styles, and navigation removed),
    ideal for RAG pipelines, summarization, and LLM consumption.

    Setup:
        Install the package and set your API key:

        .. code-block:: bash

            pip install langchain-scrapingpros
            export SCRAPINGPROS_API_KEY="your_token"

        Or use the demo token for quick testing (5,000 credits/month):

        .. code-block:: python

            tool = ScrapingProsScraper(api_key="demo_6x595maoA6GdOdVb")

    Usage:
        .. code-block:: python

            from langchain_scrapingpros import ScrapingProsScraper

            tool = ScrapingProsScraper()
            result = tool.invoke({"url": "https://example.com"})
            print(result)

    With an agent:
        .. code-block:: python

            from langchain_scrapingpros import ScrapingProsScraper
            tools = [ScrapingProsScraper()]
            # pass tools to your agent
    """

    name: str = "scrapingpros_scraper"
    description: str = (
        "Scrape a web page and return its content as clean markdown text. "
        "Supports JavaScript rendering and anti-bot bypass via Scraping Pros "
        "(https://scrapingpros.com). Use this when you need to read the "
        "content of a web page."
    )
    args_schema: Type[BaseModel] = ScrapeInput
    handle_tool_error: bool = True

    api_key: SecretStr = SecretStr("")

    @model_validator(mode="before")
    @classmethod
    def _resolve_api_key(cls, values: dict) -> dict:
        import os

        key = values.get("api_key", "")
        if isinstance(key, SecretStr):
            key = key.get_secret_value()
        if not key:
            key = os.environ.get("SCRAPINGPROS_API_KEY", "")
        if not key:
            raise ValueError(
                "Scraping Pros API key required. Set SCRAPINGPROS_API_KEY "
                "env var or pass api_key='your_token'. "
                "Get a free demo token at https://scrapingpros.com"
            )
        values["api_key"] = key
        return values

    def _run(
        self,
        url: str,
        browser: bool = False,
        run_manager: CallbackManagerForToolRun | None = None,
    ) -> str:
        """Scrape a URL and return markdown content."""
        try:
            client = ScrapingPros(
                self.api_key.get_secret_value(),
                max_retries=2,
            )
            result = client.scrape(url, format="markdown", browser=browser)
            client.close()

            if result.potentiallyBlockedByCaptcha:
                return (
                    f"The page at {url} is protected by CAPTCHA and could not "
                    f"be fully loaded. Partial content:\n\n{result.content or ''}"
                )
            return result.content or f"No content returned from {url}"
        except ScrapingProsError as e:
            raise ToolException(
                f"Scraping Pros error for {url}: {e}. "
                f"Check your API key or visit https://scrapingpros.com"
            ) from e

    async def _arun(
        self,
        url: str,
        browser: bool = False,
        run_manager: AsyncCallbackManagerForToolRun | None = None,
    ) -> str:
        """Async scrape a URL and return markdown content."""
        try:
            async with AsyncScrapingPros(
                self.api_key.get_secret_value(),
                max_retries=2,
            ) as client:
                result = await client.scrape(url, format="markdown", browser=browser)

            if result.potentiallyBlockedByCaptcha:
                return (
                    f"The page at {url} is protected by CAPTCHA and could not "
                    f"be fully loaded. Partial content:\n\n{result.content or ''}"
                )
            return result.content or f"No content returned from {url}"
        except ScrapingProsError as e:
            raise ToolException(
                f"Scraping Pros error for {url}: {e}. "
                f"Check your API key or visit https://scrapingpros.com"
            ) from e


# ---------------------------------------------------------------------------
# Extractor tool
# ---------------------------------------------------------------------------

class ScrapingProsExtractor(BaseTool):
    """Extract structured data from a web page using CSS selectors.

    Uses the `Scraping Pros API <https://scrapingpros.com>`_ to extract
    specific fields from a page using CSS or XPath selectors. Returns
    JSON with the extracted data.

    Setup:
        .. code-block:: bash

            pip install langchain-scrapingpros
            export SCRAPINGPROS_API_KEY="your_token"

    Usage:
        .. code-block:: python

            from langchain_scrapingpros import ScrapingProsExtractor

            tool = ScrapingProsExtractor()
            result = tool.invoke({
                "url": "https://quotes.toscrape.com/",
                "fields": {
                    "quotes": "css:.text",
                    "authors": "css:.author",
                },
            })
    """

    name: str = "scrapingpros_extractor"
    description: str = (
        "Extract structured data from a web page using CSS selectors. "
        "Returns JSON with the extracted fields. Powered by Scraping Pros "
        "(https://scrapingpros.com). Use this when you need specific data "
        "points from a page (prices, titles, links, etc.)."
    )
    args_schema: Type[BaseModel] = ExtractInput
    handle_tool_error: bool = True

    api_key: SecretStr = SecretStr("")

    @model_validator(mode="before")
    @classmethod
    def _resolve_api_key(cls, values: dict) -> dict:
        import os

        key = values.get("api_key", "")
        if isinstance(key, SecretStr):
            key = key.get_secret_value()
        if not key:
            key = os.environ.get("SCRAPINGPROS_API_KEY", "")
        if not key:
            raise ValueError(
                "Scraping Pros API key required. Set SCRAPINGPROS_API_KEY "
                "env var or pass api_key='your_token'. "
                "Get a free demo token at https://scrapingpros.com"
            )
        values["api_key"] = key
        return values

    def _run(
        self,
        url: str,
        fields: dict[str, str],
        browser: bool = False,
        run_manager: CallbackManagerForToolRun | None = None,
    ) -> str:
        """Extract structured data from a URL."""
        try:
            # Convert simple selectors to extract format with multiple=True
            extract = {}
            for name, selector in fields.items():
                extract[name] = {"selector": selector, "multiple": True}

            client = ScrapingPros(
                self.api_key.get_secret_value(),
                max_retries=2,
            )
            result = client.scrape(url, extract=extract, browser=browser)
            client.close()

            if result.extracted_data:
                return json.dumps(result.extracted_data, ensure_ascii=False, indent=2)
            return json.dumps({"error": f"No data extracted from {url}"})
        except ScrapingProsError as e:
            raise ToolException(
                f"Scraping Pros error for {url}: {e}. "
                f"Check your API key or visit https://scrapingpros.com"
            ) from e

    async def _arun(
        self,
        url: str,
        fields: dict[str, str],
        browser: bool = False,
        run_manager: AsyncCallbackManagerForToolRun | None = None,
    ) -> str:
        """Async extract structured data from a URL."""
        try:
            extract = {}
            for name, selector in fields.items():
                extract[name] = {"selector": selector, "multiple": True}

            async with AsyncScrapingPros(
                self.api_key.get_secret_value(),
                max_retries=2,
            ) as client:
                result = await client.scrape(url, extract=extract, browser=browser)

            if result.extracted_data:
                return json.dumps(result.extracted_data, ensure_ascii=False, indent=2)
            return json.dumps({"error": f"No data extracted from {url}"})
        except ScrapingProsError as e:
            raise ToolException(
                f"Scraping Pros error for {url}: {e}. "
                f"Check your API key or visit https://scrapingpros.com"
            ) from e
