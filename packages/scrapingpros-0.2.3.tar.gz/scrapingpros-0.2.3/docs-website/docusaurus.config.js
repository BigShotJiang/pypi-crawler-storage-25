import {themes as prismThemes} from 'prism-react-renderer';

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'ScrapingPros',
  tagline: 'Web Scraping for Everyone',
  favicon: 'img/icon.webp',

  // Future flags, see https://docusaurus.io/docs/api/docusaurus-config#future
  future: {
    v4: true, // Improve compatibility with the upcoming Docusaurus v4
  },

  // Set the production url of your site here
  url: 'https://your-docusaurus-site.example.com',
  // Set the /<baseUrl>/ pathname under which your site is served
  // For GitHub pages deployment, it is often '/<projectName>/'
  baseUrl: '/',

  onBrokenLinks: 'warn',

  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: './sidebars.js'
        },
        theme: {
          customCss: './src/css/custom.css',
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      // Replace with your project's social card
      image: 'img/docusaurus-social-card.jpg',
      colorMode: {
        respectPrefersColorScheme: true,
      },
      navbar: {
        title: 'Scraping Pros API',
        logo: {
          alt: 'Scraping Pros Logo',
          src: 'img/icon.webp',
        },
        items: [
          {
            type: 'docSidebar',
            sidebarId: 'docsSidebar',
            position: 'left',
            label: 'Docs',
          },
          {
            type: 'docSidebar',
            sidebarId: 'apiReferenceSidebar',
            position: 'left',
            label: 'API Reference',
          },
          {
            to: '/docs/documentation/Python%20SDK/quickstart',
            position: 'left',
            label: 'Python SDK',
          },
          {
            href: 'https://api.scrapingpros.com/llms-full.txt',
            label: 'API Reference (AI)',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'dark',
        links: [
          {
            title: 'Docs',
            items: [
              {
                label: 'Documentation',
                to: '/docs/documentation/intro',
              },
              {
                label: 'API Reference',
                to: '/docs/apiReference/intro',
              },
              {
                label: 'Python SDK',
                to: '/docs/documentation/Python%20SDK/quickstart',
              },
            ],
          },
          {
            title: 'Community',
            items: [
              {
                  label: 'Scraping Pros Site',
                  href: 'https://scrapingpros.com/',
              },
              {
                label: 'Instagram',
                href: 'https://www.instagram.com/scrapingpros/',
              },
              {
                label: 'LinkedIn',
                href: 'https://www.linkedin.com/company/scrapingpros/',
              },
            ],
          },
          {
            title: 'More',
            items: [
              {
                label: 'API Swagger',
                href: 'https://api.scrapingpros.com/docs',
              },
              {
                label: 'API for AI Agents (llms.txt)',
                href: 'https://api.scrapingpros.com/llms.txt',
              },
              {
                label: 'OpenAPI Spec',
                href: 'https://api.scrapingpros.com/openapi.json',
              },
              {
                label: 'PyPI',
                href: 'https://pypi.org/project/scrapingpros/',
              },
            ],
          },
        ],
        copyright: `Copyright \u00A9 ${new Date().getFullYear()} Scraping Pros. API v1.1.0`,
      },
      prism: {
        theme: prismThemes.github,
        darkTheme: prismThemes.dracula,
        additionalLanguages: ['bash', 'python'],
      },
    }),
};

export default config;
