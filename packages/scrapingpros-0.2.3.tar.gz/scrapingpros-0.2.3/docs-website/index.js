import React from 'react';
import Layout from '@theme/Layout';
import Head from '@docusaurus/Head';

const JSON_LD = {
  "@context": "https://schema.org",
  "@type": "WebAPI",
  "name": "Scraping Pros API",
  "description": "Professional web scraping API with anti-bot bypass, browser rendering, proxy rotation across 200+ countries, CAPTCHA detection, and AI-ready output (markdown, MCP server). Works on sites protected by Cloudflare, DataDome, Akamai, and PerimeterX.",
  "url": "https://api.scrapingpros.com",
  "documentationUrl": "https://docs.scrapingpros.com",
  "provider": {
    "@type": "Organization",
    "name": "Scraping Pros",
    "url": "https://scrapingpros.com"
  },
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "USD",
    "description": "Free tier: 1,000 credits/month. Demo token available for instant access without signup."
  },
  "applicationCategory": "WebAPI",
  "operatingSystem": "Any",
  "keywords": "web scraping api, python sdk, anti-bot bypass, captcha solving, proxy rotation, browser rendering, ai scraping, mcp server, data extraction"
};

const FEATURES = [
  {
    title: "Works where others fail",
    description: "Multi-engine anti-detection bypasses Cloudflare, DataDome, Akamai, and PerimeterX. Three browser modes (light, heavy, stealth) for different protection levels. Auto-retry with different IP/fingerprint on blocks.",
    icon: "\u{1F6E1}\u{FE0F}",
  },
  {
    title: "Built for AI workflows",
    description: "Clean markdown output for LLM consumption. MCP server for Claude, GPT, and Cursor. Structured data extraction with CSS/XPath. JavaScript execution for internal API access. Anti-injection protection on all scraped content.",
    icon: "\u{1F916}",
  },
  {
    title: "Global scale, instant access",
    description: "950+ proxies across 200+ countries. Geo-targeted scraping for price monitoring, market research, and competitive intelligence. Try it now with our demo token \u2014 no signup required.",
    icon: "\u{1F30D}",
  },
];

const INTEGRATIONS = [
  { name: "Python SDK", href: "/docs/documentation/Python%20SDK/quickstart", desc: "pip install scrapingpros", highlight: true },
  { name: "MCP Server", href: "https://api.scrapingpros.com/llms-full.txt#mcp-server", desc: "For AI agents" },
  { name: "Swagger UI", href: "https://api.scrapingpros.com/docs", desc: "Interactive docs" },
  { name: "OpenAPI Spec", href: "https://api.scrapingpros.com/openapi.json", desc: "Machine-readable" },
  { name: "llms.txt", href: "https://api.scrapingpros.com/llms.txt", desc: "AI discovery" },
];

function Hero() {
  return (
    <div style={{
      background: "linear-gradient(135deg, #0061FF 0%, #2ea3f2 50%, #60EFFF 100%)",
      padding: "80px 20px 60px",
      textAlign: "center",
      color: "white",
    }}>
      <img
        src={require('@site/static/img/scrapingpros-logo-banner.png').default}
        alt="Scraping Pros"
        style={{ maxWidth: 320, marginBottom: 30 }}
      />
      <h1 style={{
        fontSize: "2.4rem",
        fontWeight: 600,
        marginBottom: 16,
        lineHeight: 1.2,
      }}>
        Extract data from any website, at scale
      </h1>
      <p style={{
        fontSize: "1.15rem",
        maxWidth: 680,
        margin: "0 auto 32px",
        opacity: 0.92,
        lineHeight: 1.6,
      }}>
        We handle anti-bot protection, browser rendering, proxy rotation, and CAPTCHA detection — so your team can focus on the data that drives decisions.
      </p>
      <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
        <a href="/docs/documentation/Python%20SDK/quickstart" style={btnPrimary}>
          Python SDK
        </a>
        <a href="/docs/documentation/Getting%20Started/guia_inicial" style={btnSecondary}>
          Getting Started
        </a>
        <a href="https://api.scrapingpros.com/docs" style={btnSecondary}>
          API Reference
        </a>
      </div>
    </div>
  );
}

function FeatureCards() {
  return (
    <div style={{
      maxWidth: 1080,
      margin: "0 auto",
      padding: "60px 20px",
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
      gap: 32,
    }}>
      {FEATURES.map((f, i) => (
        <div key={i} style={{
          background: "white",
          borderRadius: 12,
          padding: "36px 28px",
          boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
          border: "1px solid #eee",
        }}>
          <div style={{ fontSize: "2rem", marginBottom: 12 }}>{f.icon}</div>
          <h3 style={{ fontSize: "1.2rem", fontWeight: 600, marginBottom: 10, color: "#333" }}>
            {f.title}
          </h3>
          <p style={{ color: "#666", lineHeight: 1.6, fontSize: "0.95rem", marginBottom: 0 }}>
            {f.description}
          </p>
        </div>
      ))}
    </div>
  );
}

function QuickStart() {
  return (
    <div style={{
      background: "#f8f9fb",
      padding: "60px 20px",
    }}>
      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        <h2 style={{ textAlign: "center", fontSize: "1.6rem", fontWeight: 600, color: "#333", marginBottom: 8 }}>
          Try it now — no signup required
        </h2>
        <p style={{ textAlign: "center", color: "#666", marginBottom: 28, fontSize: "1rem" }}>
          Use our demo token to scrape any website instantly. 5,000 credits/month, all features included.
        </p>
        <div style={{
          background: "#1e1e1e",
          borderRadius: 10,
          padding: "24px 28px",
          color: "#d4d4d4",
          fontFamily: "'Courier New', monospace",
          fontSize: "0.85rem",
          lineHeight: 1.7,
          overflowX: "auto",
        }}>
          <div style={{ color: "#6a9955" }}>{"# Install the Python SDK"}</div>
          <div><span style={{ color: "#dcdcaa" }}>pip</span>{" install scrapingpros"}</div>
          <div style={{ height: 8 }}></div>
          <div style={{ color: "#6a9955" }}>{"# Scrape a single URL"}</div>
          <div><span style={{ color: "#c586c0" }}>from</span>{" scrapingpros "}<span style={{ color: "#c586c0" }}>import</span>{" ScrapingPros"}</div>
          <div>{"client = ScrapingPros("}<span style={{ color: "#ce9178" }}>"demo_6x595maoA6GdOdVb"</span>{")"}</div>
          <div>{"result = client.scrape("}<span style={{ color: "#ce9178" }}>"https://example.com"</span>{", format="}<span style={{ color: "#ce9178" }}>"markdown"</span>{")"}</div>
          <div style={{ height: 8 }}></div>
          <div style={{ color: "#6a9955" }}>{"# Scrape 100 URLs concurrently — handles throttling automatically"}</div>
          <div>{"results = client.scrape_many(urls, format="}<span style={{ color: "#ce9178" }}>"markdown"</span>{", browser="}<span style={{ color: "#569cd6" }}>True</span>{")"}</div>
        </div>
        <div style={{
          display: "flex",
          gap: 20,
          justifyContent: "center",
          marginTop: 28,
          flexWrap: "wrap",
        }}>
          <Stat value="200+" label="proxy countries" />
          <Stat value="950+" label="active proxies" />
          <Stat value="~2s" label="avg response" />
          <Stat value="5,000" label="free credits/mo" />
        </div>
      </div>
    </div>
  );
}

function Stat({ value, label }) {
  return (
    <div style={{ textAlign: "center" }}>
      <div style={{ fontSize: "1.5rem", fontWeight: 700, color: "#2ea3f2" }}>{value}</div>
      <div style={{ fontSize: "0.8rem", color: "#888", textTransform: "uppercase", letterSpacing: 1 }}>{label}</div>
    </div>
  );
}

function Integrations() {
  return (
    <div style={{
      maxWidth: 1080,
      margin: "0 auto",
      padding: "50px 20px 60px",
      textAlign: "center",
    }}>
      <h2 style={{ fontSize: "1.4rem", fontWeight: 600, color: "#333", marginBottom: 8 }}>
        Integrate in minutes
      </h2>
      <p style={{ color: "#666", marginBottom: 28, fontSize: "0.95rem" }}>
        REST API, MCP server for AI agents, Python SDK, OpenAPI spec — pick your path.
      </p>
      <div style={{
        display: "flex",
        gap: 16,
        justifyContent: "center",
        flexWrap: "wrap",
      }}>
        {INTEGRATIONS.map((int, i) => (
          <a key={i} href={int.href} style={{
            display: "inline-block",
            padding: "14px 24px",
            borderRadius: 8,
            border: int.highlight ? "2px solid #0061FF" : "1px solid #ddd",
            color: int.highlight ? "#0061FF" : "#333",
            textDecoration: "none",
            transition: "all 0.2s",
            background: "white",
          }}>
            <div style={{ fontWeight: 600, fontSize: "0.95rem" }}>{int.name}</div>
            <div style={{ fontSize: "0.78rem", color: int.highlight ? "#0061FF" : "#888" }}>{int.desc}</div>
          </a>
        ))}
      </div>
    </div>
  );
}

const btnPrimary = {
  display: "inline-block",
  padding: "14px 32px",
  background: "white",
  color: "#0061FF",
  borderRadius: 6,
  fontWeight: 600,
  fontSize: "1rem",
  textDecoration: "none",
  border: "2px solid white",
  transition: "all 0.2s",
};

const btnSecondary = {
  display: "inline-block",
  padding: "14px 32px",
  background: "transparent",
  color: "white",
  borderRadius: 6,
  fontWeight: 600,
  fontSize: "1rem",
  textDecoration: "none",
  border: "2px solid rgba(255,255,255,0.6)",
  transition: "all 0.2s",
};

export default function Home() {
  return (
    <Layout title="Scraping Pros API" description="Professional web scraping API with anti-bot bypass, browser rendering, proxy rotation, and AI-ready output. Python SDK available.">
      <Head>
        <script type="application/ld+json">{JSON.stringify(JSON_LD)}</script>
      </Head>
      <main>
        <Hero />
        <FeatureCards />
        <QuickStart />
        <Integrations />
      </main>
    </Layout>
  );
}
