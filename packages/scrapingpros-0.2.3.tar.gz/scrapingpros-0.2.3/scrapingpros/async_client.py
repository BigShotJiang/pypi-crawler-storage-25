"""Asynchronous client for the Scraping Pros API.

Example:
    >>> import asyncio
    >>> from scrapingpros import AsyncScrapingPros
    >>> async def main():
    ...     async with AsyncScrapingPros("your_token") as client:
    ...         result = await client.scrape("https://example.com")
    ...         print(result.html[:50])
    >>> asyncio.run(main())  # doctest: +SKIP
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Literal

import httpx

from scrapingpros._base import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    RateLimitInfo,
    RetryConfig,
    _is_quota_error,
    logger,
    map_error,
    parse_rate_limit_headers,
    resolve_token,
)
from scrapingpros.exceptions import ConnectionError, RateLimitError, TimeoutError
from scrapingpros.models import (
    Action,
    CollectionPublic,
    DownloadResponse,
    HttpMethod,
    JobExecutionListPublic,
    NewCollectionResponse,
    BillingResponse,
    ClientMetricsResponse,
    ProxyCountriesResponse,
    ProxyRequestCountryResponse,
    ProxyStatusResponse,
    RunPublic,
    ScrapeRequest,
    ScrapeResponse,
    UseProxy,
    ViabilityRunPublic,
    NetworkCaptureConfig,
)


class AsyncScrapingPros:
    """Asynchronous Python client for the Scraping Pros API.

    Example:
        >>> async with AsyncScrapingPros("your_token") as client:
        ...     result = await client.scrape("https://example.com")
        ...     print(result.html[:50])  # doctest: +SKIP

    Args:
        token: Your API token. Falls back to the ``SP_TOKEN`` env var.
            Use ``"demo_6x595maoA6GdOdVb"`` for quick testing
            (5,000 credits/month, 30 req/min).
        base_url: API base URL. Defaults to ``https://api.scrapingpros.com``.
        timeout: Request timeout in seconds. Defaults to 120.
        max_retries: Max automatic retries on 429. Defaults to 3.
    """

    def __init__(
        self,
        token: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._token = resolve_token(token)
        self._base_url = base_url.rstrip("/")
        self._retry = RetryConfig(max_retries=max_retries)
        self._last_rate_limit = RateLimitInfo()
        self._plan_max_concurrent: int | None = None
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
            limits=httpx.Limits(
                max_connections=200,
                max_keepalive_connections=100,
            ),
        )

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncScrapingPros:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    @property
    def rate_limit_remaining(self) -> int | None:
        """Remaining requests in the current rate-limit window."""
        return self._last_rate_limit.rate_limit_remaining

    @property
    def quota_remaining(self) -> int | str | None:
        """Remaining requests in the monthly quota."""
        return self._last_rate_limit.quota_remaining

    @property
    def credits_charged(self) -> int | None:
        """Credits charged for the last API call."""
        return self._last_rate_limit.credits_charged

    async def _detect_max_concurrent(self) -> int:
        """Detect max concurrent jobs from the plan. Caches result."""
        if self._plan_max_concurrent is not None:
            return self._plan_max_concurrent

        default = 5
        try:
            quota_limit = self._last_rate_limit.quota_limit
            rate_limit = self._last_rate_limit.rate_limit_limit

            if quota_limit is None and rate_limit is None:
                self._plan_max_concurrent = default
                return default

            plans_data = await self.plans()
            for plan in plans_data.get("plans", []):
                if plan.get("credits_monthly") == quota_limit:
                    self._plan_max_concurrent = plan.get("max_concurrent_jobs", default)
                    return self._plan_max_concurrent

            if rate_limit and rate_limit > 0:
                self._plan_max_concurrent = min(max(5, rate_limit // 6), 100)
                return self._plan_max_concurrent

            self._plan_max_concurrent = default
        except Exception:
            self._plan_max_concurrent = default

        return self._plan_max_concurrent

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Send an HTTP request with automatic retry on 429 and 5xx."""
        last_exc: Exception | None = None
        for attempt in range(self._retry.max_retries + 1):
            try:
                resp = await self._http.request(method, path, **kwargs)
            except httpx.HTTPError as exc:
                raise ConnectionError(
                    f"Could not connect to {self._base_url}: {exc}"
                ) from exc

            self._last_rate_limit = parse_rate_limit_headers(
                dict(resp.headers),
            )

            if resp.status_code < 400:
                return resp

            # Quota exceeded — don't retry, it won't help
            if resp.status_code == 429 and _is_quota_error(resp.text):
                raise map_error(resp.status_code, resp.text, dict(resp.headers))

            # Retryable: 429 (rate limit) and 5xx (server errors)
            is_retryable = resp.status_code == 429 or resp.status_code >= 500
            if is_retryable and attempt < self._retry.max_retries:
                retry_after_raw = resp.headers.get("retry-after")
                retry_after: float | None = None
                if retry_after_raw:
                    try:
                        retry_after = float(retry_after_raw)
                    except (ValueError, TypeError):
                        pass
                delay = self._retry.delay_for_attempt(attempt, retry_after)
                logger.warning(
                    "Request %s %s returned %d, retrying in %.1fs (attempt %d/%d)",
                    method, path, resp.status_code, delay,
                    attempt + 1, self._retry.max_retries,
                )
                await asyncio.sleep(delay)
                last_exc = map_error(resp.status_code, resp.text, dict(resp.headers))
                continue

            raise map_error(resp.status_code, resp.text, dict(resp.headers))

        if last_exc is not None:
            raise last_exc
        raise map_error(resp.status_code, resp.text, dict(resp.headers))  # pragma: no cover

    # -- Sync endpoints -----------------------------------------------------

    async def scrape(
        self,
        url: str,
        *,
        format: Literal["html", "markdown"] = "html",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        screenshot: bool = False,
        actions: list[Action] | None = None,
        language: str = "",
        http_method: HttpMethod | None = None,
        headers: dict[str, str] | None = None,
        window_size: str = "",
        cookies: dict[str, Any] | None = None,
        extract: dict[str, str | dict[str, Any]] | None = None,
        network_capture: NetworkCaptureConfig | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
    ) -> ScrapeResponse:
        """Scrape a single URL.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     result = await client.scrape("https://example.com", format="markdown")
            ...     print(result.markdown)  # doctest: +SKIP
        """
        req = ScrapeRequest(
            url=url,
            format=format,
            browser=browser,
            browser_type=browser_type,
            use_proxy=use_proxy,
            screenshot=screenshot,
            actions=actions,
            language=language,
            http_method=http_method,
            headers=headers,
            window_size=window_size,
            cookies=cookies,
            extract=extract,
            network_capture=network_capture,
            retry_on_block=retry_on_block,
            block_resources=block_resources,
            block_requests=block_requests,
        )
        extra_kwargs: dict[str, Any] = {}
        if retry_on_block:
            extra_kwargs["timeout"] = max(self._http.timeout.read or 120, 300)

        resp = await self._request(
            "POST",
            "/v1/sync/scrape",
            json=req.model_dump(exclude_none=True, exclude_defaults=False),
            **extra_kwargs,
        )
        return ScrapeResponse.model_validate(resp.json())

    async def scrape_many(
        self,
        urls: list[str],
        *,
        max_concurrent: int | None = None,
        format: Literal["html", "markdown"] = "markdown",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        extract: dict[str, str | dict[str, Any]] | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
    ) -> list[ScrapeResponse | Exception]:
        """Scrape multiple URLs concurrently with automatic throttling.

        Uses an ``asyncio.Semaphore`` to limit concurrency. Returns
        results in the same order as input URLs.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     results = await client.scrape_many([
            ...         "https://example.com",
            ...         "https://quotes.toscrape.com/",
            ...     ])  # doctest: +SKIP
        """
        if max_concurrent is None:
            max_concurrent = await self._detect_max_concurrent()

        semaphore = asyncio.Semaphore(max_concurrent)

        async def _scrape_one(index: int, url: str) -> tuple[int, ScrapeResponse | Exception]:
            async with semaphore:
                try:
                    resp = await self.scrape(
                        url,
                        format=format,
                        browser=browser,
                        browser_type=browser_type,
                        use_proxy=use_proxy,
                        extract=extract,
                        retry_on_block=retry_on_block,
                        block_resources=block_resources,
                        block_requests=block_requests,
                    )
                    return index, resp
                except Exception as e:
                    return index, e

        tasks = [_scrape_one(i, url) for i, url in enumerate(urls)]
        raw_results = await asyncio.gather(*tasks)

        results: list[ScrapeResponse | Exception] = [None] * len(urls)  # type: ignore
        for idx, result in raw_results:
            results[idx] = result
        return results

    async def download(
        self,
        url: str,
        *,
        use_proxy: UseProxy = None,
    ) -> DownloadResponse:
        """Download a file and return its content as base64.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     result = await client.download("https://example.com/file.pdf")  # doctest: +SKIP
        """
        body: dict[str, Any] = {"url": url}
        if use_proxy is not None:
            body["use_proxy"] = use_proxy if isinstance(use_proxy, str) else use_proxy.model_dump()
        resp = await self._request("POST", "/v1/sync/download", json=body)
        return DownloadResponse.model_validate(resp.json())

    # -- Collections --------------------------------------------------------

    async def create_collection(
        self,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
        *,
        callback_url: str | None = None,
    ) -> NewCollectionResponse:
        """Create a new collection for async batch processing.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     col = await client.create_collection("batch", [
            ...         {"url": "https://example.com/1"},
            ...     ])  # doctest: +SKIP
        """
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        if callback_url is not None:
            body["callback_url"] = callback_url
        resp = await self._request("POST", "/v1/async/collections", json=body)
        return NewCollectionResponse.model_validate(resp.json())

    async def list_collections(self) -> list[CollectionPublic]:
        """List all collections."""
        resp = await self._request("GET", "/v1/async/collections")
        return [CollectionPublic.model_validate(c) for c in resp.json()]

    async def get_collection(self, collection_id: str) -> CollectionPublic:
        """Get a specific collection by ID."""
        resp = await self._request("GET", f"/v1/async/collections/{collection_id}")
        return CollectionPublic.model_validate(resp.json())

    async def update_collection(
        self,
        collection_id: str,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
    ) -> NewCollectionResponse:
        """Update an existing collection."""
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        resp = await self._request(
            "PUT",
            f"/v1/async/collections/{collection_id}",
            json=body,
        )
        return NewCollectionResponse.model_validate(resp.json())

    # -- Runs ---------------------------------------------------------------

    async def create_run(self, collection_id: str) -> RunPublic:
        """Start a run for a collection."""
        resp = await self._request(
            "POST",
            f"/v1/async/collections/{collection_id}/run",
        )
        return RunPublic.model_validate(resp.json())

    async def get_run(self, collection_id: str, run_id: str) -> RunPublic:
        """Get the status of a run."""
        resp = await self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}",
        )
        return RunPublic.model_validate(resp.json())

    async def get_run_jobs(
        self,
        collection_id: str,
        run_id: str,
    ) -> JobExecutionListPublic:
        """Get detailed job executions for a run."""
        resp = await self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs",
        )
        return JobExecutionListPublic.model_validate(resp.json())

    async def run_and_wait(
        self,
        collection_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
    ) -> RunPublic:
        """Create a run and poll until it completes.

        Raises:
            TimeoutError: If the run does not complete within *timeout*.
        """
        run = await self.create_run(collection_id)
        start = time.monotonic()
        while True:
            run = await self.get_run(collection_id, run.run_id)
            if run.status in ("completed", "failed", "cancelled"):
                return run
            if time.monotonic() - start > timeout:
                raise TimeoutError(
                    f"Run {run.run_id} did not complete within {timeout}s"
                )
            await asyncio.sleep(poll_interval)

    # -- Viability test -----------------------------------------------------

    async def create_viability_test(
        self,
        urls: list[str],
        *,
        depth: Literal["quick", "standard", "full"] = "full",
        actions: list[Action] | None = None,
    ) -> ViabilityRunPublic:
        """Submit URLs for viability analysis."""
        body: dict[str, Any] = {"urls": urls, "depth": depth}
        if actions is not None:
            body["actions"] = [a.model_dump() for a in actions]
        resp = await self._request("POST", "/v1/async/viability-test", json=body)
        return ViabilityRunPublic.model_validate(resp.json())

    async def get_viability_test(self, run_id: str) -> ViabilityRunPublic:
        """Poll the status and results of a viability test."""
        resp = await self._request("GET", f"/v1/async/viability-test/{run_id}")
        return ViabilityRunPublic.model_validate(resp.json())

    async def get_job_result(
        self,
        collection_id: str,
        run_id: str,
        job_id: str,
    ) -> ScrapeResponse:
        """Get the full scrape result for a specific job.

        Results are available for 24 hours after job completion.
        """
        resp = await self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs/{job_id}/result",
        )
        return ScrapeResponse.model_validate(resp.json())

    async def delete_collection(self, collection_id: str) -> None:
        """Delete a collection and its associated jobs."""
        await self._request("DELETE", f"/v1/async/collections/{collection_id}")

    # -- Proxy --------------------------------------------------------------

    async def list_proxy_countries(self) -> ProxyCountriesResponse:
        """List all 200+ countries available for geo-targeted scraping."""
        resp = await self._request("GET", "/v1/proxy/countries")
        return ProxyCountriesResponse.model_validate(resp.json())

    async def request_proxy_country(
        self,
        country_code: str,
        *,
        reason: str = "",
    ) -> ProxyRequestCountryResponse:
        """Request access to a country-specific proxy."""
        resp = await self._request(
            "POST",
            "/v1/proxy/request-country",
            json={"country_code": country_code, "reason": reason},
        )
        return ProxyRequestCountryResponse.model_validate(resp.json())

    async def proxy_status(self) -> ProxyStatusResponse:
        """Check your country proxy approvals."""
        resp = await self._request("GET", "/v1/proxy/status")
        return ProxyStatusResponse.model_validate(resp.json())

    # -- Plans --------------------------------------------------------------

    async def plans(self) -> Any:
        """List all available plans with pricing, credits, and features."""
        resp = await self._request("GET", "/v1/plans")
        return resp.json()

    # -- Billing & Metrics --------------------------------------------------

    async def billing(self, *, month: str = "", detail: str = "") -> BillingResponse:
        """Get billing summary."""
        params: dict[str, str] = {}
        if month:
            params["month"] = month
        if detail:
            params["detail"] = detail
        resp = await self._request("GET", "/v1/sync/billing", params=params)
        return BillingResponse.model_validate(resp.json())

    async def metrics(self, *, date: str = "", metric: str = "") -> Any:
        """Get API metrics."""
        params: dict[str, str] = {}
        if date:
            params["date"] = date
        if metric:
            params["metric"] = metric
        resp = await self._request("GET", "/v1/sync/metrics", params=params)
        return resp.json()

    async def client_metrics(
        self,
        *,
        date: str = "",
        hourly: bool = False,
        detail: str = "",
    ) -> ClientMetricsResponse:
        """Get your usage metrics."""
        params: dict[str, Any] = {}
        if date:
            params["date"] = date
        if hourly:
            params["hourly"] = "true"
        if detail:
            params["detail"] = detail
        resp = await self._request("GET", "/v1/sync/client-metrics", params=params)
        return ClientMetricsResponse.model_validate(resp.json())

    # -- Health -------------------------------------------------------------

    async def health(self) -> Any:
        """Check API health status."""
        resp = await self._request("GET", "/v1/health")
        return resp.json()
