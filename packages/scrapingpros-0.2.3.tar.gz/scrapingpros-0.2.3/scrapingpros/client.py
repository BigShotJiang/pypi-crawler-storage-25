"""Synchronous client for the Scraping Pros API.

Example:
    >>> from scrapingpros import ScrapingPros
    >>> client = ScrapingPros("your_token")
    >>> result = client.scrape("https://example.com")
    >>> print(result.html[:50])
    '<!doctype html>...'
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Literal

import httpx

from scrapingpros._base import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    RateLimitInfo,
    RetryConfig,
    _is_quota_error,
    logger,
    map_error,
    parse_rate_limit_headers,
    resolve_token,
)
from scrapingpros.exceptions import ConnectionError, RateLimitError, TimeoutError
from scrapingpros.models import (
    Action,
    CollectionPublic,
    DownloadResponse,
    HttpMethod,
    JobExecutionListPublic,
    NewCollectionResponse,
    BillingResponse,
    ClientMetricsResponse,
    ProxyCountriesResponse,
    ProxyRequestCountryResponse,
    ProxyStatusResponse,
    RunPublic,
    ScrapeRequest,
    ScrapeResponse,
    UseProxy,
    ViabilityRunPublic,
    NetworkCaptureConfig,
)


class ScrapingPros:
    """Synchronous Python client for the Scraping Pros API.

    The simplest way to start scraping:

    Example:
        >>> client = ScrapingPros("demo_6x595maoA6GdOdVb")
        >>> result = client.scrape("https://example.com")
        >>> print(result.html[:50])
        '<!doctype html>...'

        >>> # Or use the SP_TOKEN environment variable:
        >>> client = ScrapingPros()

    Args:
        token: Your API token. Falls back to the ``SP_TOKEN`` env var.
            Use ``"demo_6x595maoA6GdOdVb"`` for quick testing
            (5,000 credits/month, 30 req/min).
        base_url: API base URL. Defaults to ``https://api.scrapingpros.com``.
        timeout: Request timeout in seconds. Defaults to 120.
        max_retries: Max automatic retries on 429. Defaults to 3.
    """

    def __init__(
        self,
        token: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._token = resolve_token(token)
        self._base_url = base_url.rstrip("/")
        self._retry = RetryConfig(max_retries=max_retries)
        self._last_rate_limit = RateLimitInfo()
        self._plan_max_concurrent: int | None = None  # lazy-loaded from /v1/plans
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
            limits=httpx.Limits(
                max_connections=200,
                max_keepalive_connections=100,
            ),
        )

    # -- Lifecycle ----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> ScrapingPros:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # -- Rate limit properties ----------------------------------------------

    @property
    def rate_limit_remaining(self) -> int | None:
        """Remaining requests in the current rate-limit window.

        Updated after every API call. ``None`` until the first call.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.scrape("https://example.com")  # doctest: +SKIP
            >>> print(client.rate_limit_remaining)
            185
        """
        return self._last_rate_limit.rate_limit_remaining

    @property
    def quota_remaining(self) -> int | str | None:
        """Remaining requests in the monthly quota.

        Can be an ``int``, the string ``"unlimited"``, or ``None``
        until the first API call.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.scrape("https://example.com")  # doctest: +SKIP
            >>> print(client.quota_remaining)
            8477
        """
        return self._last_rate_limit.quota_remaining

    @property
    def credits_charged(self) -> int | None:
        """Credits charged for the last API call.

        1 for simple requests, 5 for browser requests, 0 for refunded
        infrastructure errors.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.scrape("https://example.com", browser=True)  # doctest: +SKIP
            >>> print(client.credits_charged)
            5
        """
        return self._last_rate_limit.credits_charged

    def _detect_max_concurrent(self) -> int:
        """Detect max concurrent jobs from the plan.

        Calls ``/v1/plans`` once and matches ``quota_limit`` from response
        headers to find the user's plan. For Enterprise or custom plans
        that don't match, estimates from rate limit headers. Caches result.
        """
        if self._plan_max_concurrent is not None:
            return self._plan_max_concurrent

        default = 5
        try:
            quota_limit = self._last_rate_limit.quota_limit
            rate_limit = self._last_rate_limit.rate_limit_limit

            if quota_limit is None and rate_limit is None:
                self._plan_max_concurrent = default
                return default

            # Try to match a known plan
            plans_data = self.plans()
            for plan in plans_data.get("plans", []):
                if plan.get("credits_monthly") == quota_limit:
                    self._plan_max_concurrent = plan.get("max_concurrent_jobs", default)
                    logger.info(
                        "Detected plan '%s' — max concurrent: %d",
                        plan.get("display_name"), self._plan_max_concurrent,
                    )
                    return self._plan_max_concurrent

            # Enterprise / custom plan — estimate from rate limit
            # Use rate_limit / 6 as a safe concurrent count
            # (assumes ~10s avg request time, leaving headroom)
            if rate_limit and rate_limit > 0:
                estimated = max(5, rate_limit // 6)
                self._plan_max_concurrent = min(estimated, 100)
                logger.info(
                    "Custom/Enterprise plan (rate=%d/min) — max concurrent: %d",
                    rate_limit, self._plan_max_concurrent,
                )
                return self._plan_max_concurrent

            self._plan_max_concurrent = default
        except Exception:
            self._plan_max_concurrent = default

        return self._plan_max_concurrent

    # -- Internal request with retry ----------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Send an HTTP request with automatic retry on 429 and 5xx."""
        last_exc: Exception | None = None
        for attempt in range(self._retry.max_retries + 1):
            try:
                resp = self._http.request(method, path, **kwargs)
            except httpx.HTTPError as exc:
                raise ConnectionError(
                    f"Could not connect to {self._base_url}: {exc}"
                ) from exc

            # Update rate-limit tracking from every response
            self._last_rate_limit = parse_rate_limit_headers(
                dict(resp.headers),
            )

            if resp.status_code < 400:
                return resp

            # Quota exceeded — don't retry, it won't help
            if resp.status_code == 429 and _is_quota_error(resp.text):
                raise map_error(resp.status_code, resp.text, dict(resp.headers))

            # Retryable: 429 (rate limit) and 5xx (server errors)
            is_retryable = resp.status_code == 429 or resp.status_code >= 500
            if is_retryable and attempt < self._retry.max_retries:
                retry_after_raw = resp.headers.get("retry-after")
                retry_after: float | None = None
                if retry_after_raw:
                    try:
                        retry_after = float(retry_after_raw)
                    except (ValueError, TypeError):
                        pass
                delay = self._retry.delay_for_attempt(attempt, retry_after)
                logger.warning(
                    "Request %s %s returned %d, retrying in %.1fs (attempt %d/%d)",
                    method, path, resp.status_code, delay,
                    attempt + 1, self._retry.max_retries,
                )
                time.sleep(delay)
                last_exc = map_error(resp.status_code, resp.text, dict(resp.headers))
                continue

            raise map_error(resp.status_code, resp.text, dict(resp.headers))

        # All retries exhausted
        if last_exc is not None:
            raise last_exc
        raise map_error(resp.status_code, resp.text, dict(resp.headers))  # pragma: no cover

    # -----------------------------------------------------------------------
    # Sync endpoints
    # -----------------------------------------------------------------------

    def scrape(
        self,
        url: str,
        *,
        format: Literal["html", "markdown"] = "html",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        screenshot: bool = False,
        actions: list[Action] | None = None,
        language: str = "",
        http_method: HttpMethod | None = None,
        headers: dict[str, str] | None = None,
        window_size: str = "",
        cookies: dict[str, Any] | None = None,
        extract: dict[str, str | dict[str, Any]] | None = None,
        network_capture: NetworkCaptureConfig | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
    ) -> ScrapeResponse:
        """Scrape a single URL.

        Args:
            url: The URL to scrape (http/https).
            format: Output format — ``"html"`` (default) or ``"markdown"``.
            browser: Enable headless browser rendering.
            browser_type: ``"heavy"`` (default, anti-detection), ``"light"`` (fast),
                or ``"stealth"`` (maximum anti-detection for hard sites).
            use_proxy: Proxy config — ``"any"`` (default), ``None`` for no proxy,
                a country code, or :class:`ProxyConfig`.
            screenshot: Capture a full-page screenshot (requires ``browser=True``).
            actions: Browser automation steps (click, input, etc.).
            language: Accept-Language header and browser locale.
            http_method: Override HTTP method (GET/POST with payload).
            headers: Custom HTTP headers for the request.
            window_size: Viewport — ``"desktop"``, ``"mobile"``, or ``"any"``.
            cookies: Cookies to set before loading the page.
            extract: CSS/XPath selectors for structured data extraction.
            network_capture: Capture network requests (requires ``browser=True``).
            retry_on_block: Auto-retry up to 3 times with different IP/fingerprint
                on CAPTCHA or 403. Only charges credits on the successful attempt.
            block_resources: Resource types to block (requires ``browser=True``).
                Valid types: ``"image"``, ``"stylesheet"``, ``"font"``, ``"media"``,
                ``"script"``, ``"xhr"``, ``"fetch"``, etc.
            block_requests: URL substrings to block (case-insensitive, requires
                ``browser=True``). For trackers, analytics, ads.

        Returns:
            :class:`ScrapeResponse` with ``html``, ``markdown``, ``extracted_data``, etc.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> result = client.scrape("https://example.com", format="markdown")
            >>> print(result.markdown)  # doctest: +SKIP
            '# Example Domain ...'
        """
        req = ScrapeRequest(
            url=url,
            format=format,
            browser=browser,
            browser_type=browser_type,
            use_proxy=use_proxy,
            screenshot=screenshot,
            actions=actions,
            language=language,
            http_method=http_method,
            headers=headers,
            window_size=window_size,
            cookies=cookies,
            extract=extract,
            network_capture=network_capture,
            retry_on_block=retry_on_block,
            block_resources=block_resources,
            block_requests=block_requests,
        )
        # retry_on_block makes the server do up to 3 internal retries,
        # so we need a longer timeout for that request
        extra_kwargs: dict[str, Any] = {}
        if retry_on_block:
            extra_kwargs["timeout"] = max(self._http.timeout.read or 120, 300)

        resp = self._request(
            "POST",
            "/v1/sync/scrape",
            json=req.model_dump(exclude_none=True, exclude_defaults=False),
            **extra_kwargs,
        )
        return ScrapeResponse.model_validate(resp.json())

    def scrape_many(
        self,
        urls: list[str],
        *,
        max_concurrent: int | None = None,
        format: Literal["html", "markdown"] = "markdown",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        extract: dict[str, str | dict[str, Any]] | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
    ) -> list[ScrapeResponse | Exception]:
        """Scrape multiple URLs concurrently with automatic throttling.

        Limits concurrency to ``max_concurrent`` requests at a time to
        avoid hitting rate limits. Returns results in the same order
        as the input URLs. Failed requests return the exception instead
        of raising.

        Args:
            urls: List of URLs to scrape.
            max_concurrent: Max parallel requests. Auto-detected from your
                plan if ``None`` (reads ``max_concurrent_jobs`` from ``/v1/plans``).
            format: Output format for all URLs.
            browser: Enable browser rendering for all URLs.
            browser_type: Browser type for all URLs.
            use_proxy: Proxy config for all URLs.
            extract: CSS/XPath selectors for all URLs.
            retry_on_block: Auto-retry on CAPTCHA/403 for all URLs.

        Returns:
            List of :class:`ScrapeResponse` or ``Exception`` for each URL,
            in the same order as input.

        Example:
            >>> client = ScrapingPros("demo_6x595maoA6GdOdVb")
            >>> results = client.scrape_many([
            ...     "https://example.com",
            ...     "https://quotes.toscrape.com/",
            ... ])  # doctest: +SKIP
            >>> for url, result in zip(urls, results):
            ...     if isinstance(result, Exception):
            ...         print(f"FAILED: {url} — {result}")
            ...     else:
            ...         print(f"OK: {url} — {len(result.content or '')} chars")
        """
        if max_concurrent is None:
            max_concurrent = self._detect_max_concurrent()

        results: list[ScrapeResponse | Exception] = [None] * len(urls)  # type: ignore

        def _scrape_one(index: int, url: str) -> tuple[int, ScrapeResponse | Exception]:
            try:
                resp = self.scrape(
                    url,
                    format=format,
                    browser=browser,
                    browser_type=browser_type,
                    use_proxy=use_proxy,
                    extract=extract,
                    retry_on_block=retry_on_block,
                    block_resources=block_resources,
                    block_requests=block_requests,
                )
                return index, resp
            except Exception as e:
                return index, e

        with ThreadPoolExecutor(max_workers=max_concurrent) as pool:
            futures = [
                pool.submit(_scrape_one, i, url)
                for i, url in enumerate(urls)
            ]
            for future in as_completed(futures):
                idx, result = future.result()
                results[idx] = result

        return results

    def download(
        self,
        url: str,
        *,
        use_proxy: UseProxy = None,
    ) -> DownloadResponse:
        """Download a file and return its content as base64.

        Args:
            url: Direct link to the file (PDF, image, etc.).
            use_proxy: Proxy config — ``None``, ``"any"``, a country code, or :class:`ProxyConfig`.

        Returns:
            :class:`DownloadResponse` with ``content`` (base64), ``contentType``, etc.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> result = client.download("https://example.com/report.pdf")  # doctest: +SKIP
            >>> print(result.contentType)
            'application/pdf'
        """
        body: dict[str, Any] = {"url": url}
        if use_proxy is not None:
            body["use_proxy"] = use_proxy if isinstance(use_proxy, str) else use_proxy.model_dump()
        resp = self._request("POST", "/v1/sync/download", json=body)
        return DownloadResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Collections
    # -----------------------------------------------------------------------

    def create_collection(
        self,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
        *,
        callback_url: str | None = None,
    ) -> NewCollectionResponse:
        """Create a new collection for async batch processing.

        Args:
            name: Collection name.
            requests: List of scrape requests. Accepts :class:`ScrapeRequest`
                objects or plain dicts with the same structure.
            callback_url: Webhook URL to receive a POST when runs complete.
                The POST is signed with HMAC-SHA256 (``X-SP-Signature`` header).

        Returns:
            :class:`NewCollectionResponse` with the collection ``id``.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> col = client.create_collection("my-batch", [
            ...     {"url": "https://example.com/1"},
            ...     {"url": "https://example.com/2"},
            ... ])  # doctest: +SKIP
            >>> print(col.id)
            'abc-123'
        """
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        if callback_url is not None:
            body["callback_url"] = callback_url
        resp = self._request("POST", "/v1/async/collections", json=body)
        return NewCollectionResponse.model_validate(resp.json())

    def list_collections(self) -> list[CollectionPublic]:
        """List all collections.

        Returns:
            List of :class:`CollectionPublic` objects.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> collections = client.list_collections()  # doctest: +SKIP
            >>> for col in collections:
            ...     print(col.name)
        """
        resp = self._request("GET", "/v1/async/collections")
        return [CollectionPublic.model_validate(c) for c in resp.json()]

    def get_collection(self, collection_id: str) -> CollectionPublic:
        """Get a specific collection by ID.

        Args:
            collection_id: The collection UUID.

        Returns:
            :class:`CollectionPublic` with ``id`` and ``name``.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> col = client.get_collection("abc-123")  # doctest: +SKIP
            >>> print(col.name)
        """
        resp = self._request("GET", f"/v1/async/collections/{collection_id}")
        return CollectionPublic.model_validate(resp.json())

    def update_collection(
        self,
        collection_id: str,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
    ) -> NewCollectionResponse:
        """Update an existing collection.

        Args:
            collection_id: The collection UUID.
            name: New collection name.
            requests: New list of scrape requests (replaces existing).

        Returns:
            :class:`NewCollectionResponse`.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.update_collection("abc-123", "updated-name")  # doctest: +SKIP
        """
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        resp = self._request(
            "PUT",
            f"/v1/async/collections/{collection_id}",
            json=body,
        )
        return NewCollectionResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Runs
    # -----------------------------------------------------------------------

    def create_run(self, collection_id: str) -> RunPublic:
        """Start a run for a collection.

        Args:
            collection_id: The collection UUID to run.

        Returns:
            :class:`RunPublic` with ``run_id`` and initial status.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.create_run("abc-123")  # doctest: +SKIP
            >>> print(run.run_id)
        """
        resp = self._request(
            "POST",
            f"/v1/async/collections/{collection_id}/run",
        )
        return RunPublic.model_validate(resp.json())

    def get_run(self, collection_id: str, run_id: str) -> RunPublic:
        """Get the status of a run.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.

        Returns:
            :class:`RunPublic` with status, counts, and failed jobs.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.get_run("col-123", "run-456")  # doctest: +SKIP
            >>> print(run.status)
            'completed'
        """
        resp = self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}",
        )
        return RunPublic.model_validate(resp.json())

    def get_run_jobs(
        self,
        collection_id: str,
        run_id: str,
    ) -> JobExecutionListPublic:
        """Get detailed job executions for a run.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.

        Returns:
            :class:`JobExecutionListPublic` with individual job statuses.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> jobs = client.get_run_jobs("col-123", "run-456")  # doctest: +SKIP
            >>> for job in jobs.items:
            ...     print(job.status)
        """
        resp = self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs",
        )
        return JobExecutionListPublic.model_validate(resp.json())

    def run_and_wait(
        self,
        collection_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
    ) -> RunPublic:
        """Create a run and poll until it completes.

        Args:
            collection_id: The collection UUID to run.
            poll_interval: Seconds between status checks. Defaults to 2.
            timeout: Max seconds to wait. Defaults to 300.

        Returns:
            :class:`RunPublic` with final status and results.

        Raises:
            TimeoutError: If the run does not complete within *timeout*.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.run_and_wait("col-123", timeout=60)  # doctest: +SKIP
            >>> print(f"Done: {run.success_requests}/{run.total_requests}")
        """
        run = self.create_run(collection_id)
        start = time.monotonic()
        while True:
            run = self.get_run(collection_id, run.run_id)
            if run.status in ("completed", "failed", "cancelled"):
                return run
            if time.monotonic() - start > timeout:
                raise TimeoutError(
                    f"Run {run.run_id} did not complete within {timeout}s"
                )
            time.sleep(poll_interval)

    # -----------------------------------------------------------------------
    # Viability test
    # -----------------------------------------------------------------------

    def create_viability_test(
        self,
        urls: list[str],
        *,
        depth: Literal["quick", "standard", "full"] = "full",
        actions: list[Action] | None = None,
    ) -> ViabilityRunPublic:
        """Submit URLs for viability analysis.

        Tests each URL with multiple scraping modes (simple, proxy, browser)
        to find what works. Early-exits when a mode succeeds to save credits.

        Args:
            urls: List of URLs to analyze.
            depth: How many modes to test.
                ``"quick"`` — simple HTTP only (1 credit/URL).
                ``"standard"`` — simple + proxy + browser (up to 7 credits/URL).
                ``"full"`` — all modes including browser+proxy (up to 12 credits/URL).
            actions: Optional browser actions to test.

        Returns:
            :class:`ViabilityRunPublic` with ``run_id``. Poll with
            :meth:`get_viability_test` for results.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> test = client.create_viability_test(
            ...     ["https://example.com", "https://hard-site.com"],
            ...     depth="standard",
            ... )  # doctest: +SKIP
        """
        body: dict[str, Any] = {"urls": urls, "depth": depth}
        if actions is not None:
            body["actions"] = [a.model_dump() for a in actions]
        resp = self._request("POST", "/v1/async/viability-test", json=body)
        return ViabilityRunPublic.model_validate(resp.json())

    def get_viability_test(self, run_id: str) -> ViabilityRunPublic:
        """Poll the status and results of a viability test.

        Args:
            run_id: The viability test run ID.

        Returns:
            :class:`ViabilityRunPublic` with ``results`` when completed.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> result = client.get_viability_test("vt-123")  # doctest: +SKIP
            >>> if result.status == "completed":
            ...     for r in result.results:
            ...         print(r.recommended_strategy)
        """
        resp = self._request("GET", f"/v1/async/viability-test/{run_id}")
        return ViabilityRunPublic.model_validate(resp.json())

    def get_job_result(
        self,
        collection_id: str,
        run_id: str,
        job_id: str,
    ) -> ScrapeResponse:
        """Get the full scrape result for a specific job.

        Returns the HTML/markdown, extracted data, screenshot, etc.
        Results are available for 24 hours after job completion.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.
            job_id: The job UUID.

        Returns:
            :class:`ScrapeResponse` with the full scrape result.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.run_and_wait("col-123")  # doctest: +SKIP
            >>> for job_id in run.job_ids:
            ...     result = client.get_job_result("col-123", run.run_id, job_id)
            ...     print(result.content)
        """
        resp = self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs/{job_id}/result",
        )
        return ScrapeResponse.model_validate(resp.json())

    def delete_collection(self, collection_id: str) -> None:
        """Delete a collection and its associated jobs.

        Runs that were already executed are not affected.

        Args:
            collection_id: The collection UUID.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.delete_collection("col-123")  # doctest: +SKIP
        """
        self._request("DELETE", f"/v1/async/collections/{collection_id}")

    # -----------------------------------------------------------------------
    # Proxy
    # -----------------------------------------------------------------------

    def list_proxy_countries(self) -> ProxyCountriesResponse:
        """List all 200+ countries available for geo-targeted scraping.

        Returns:
            :class:`ProxyCountriesResponse` with ISO country codes.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> resp = client.list_proxy_countries()  # doctest: +SKIP
            >>> print(resp.countries[:5])
            ['AD', 'AE', 'AF', 'AG', 'AI']
        """
        resp = self._request("GET", "/v1/proxy/countries")
        return ProxyCountriesResponse.model_validate(resp.json())

    def request_proxy_country(
        self,
        country_code: str,
        *,
        reason: str = "",
    ) -> ProxyRequestCountryResponse:
        """Request access to a country-specific proxy.

        Access requires admin approval. Once approved, use
        ``use_proxy="XX"`` in scrape calls.

        Args:
            country_code: ISO country code (e.g. ``"US"``, ``"BR"``).
            reason: Why you need this country's proxies.

        Returns:
            :class:`ProxyRequestCountryResponse` with approval status.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> resp = client.request_proxy_country("US", reason="Need US pricing")  # doctest: +SKIP
            >>> print(resp.status)  # "pending" or "already_approved"
        """
        resp = self._request(
            "POST",
            "/v1/proxy/request-country",
            json={"country_code": country_code, "reason": reason},
        )
        return ProxyRequestCountryResponse.model_validate(resp.json())

    def proxy_status(self) -> ProxyStatusResponse:
        """Check your country proxy approvals.

        Returns:
            :class:`ProxyStatusResponse` with approved and pending countries.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> status = client.proxy_status()  # doctest: +SKIP
            >>> print(status.approved_countries)
        """
        resp = self._request("GET", "/v1/proxy/status")
        return ProxyStatusResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Plans
    # -----------------------------------------------------------------------

    def plans(self) -> Any:
        """List all available plans with pricing, credits, and features.

        Public endpoint — no authentication required.

        **Credit system:** 1 simple request = 1 credit,
        1 browser request = 5 credits. Anti-bot protection and proxy
        rotation are included at no extra cost. Credits are NOT consumed
        for requests that fail due to infrastructure errors.

        Returns:
            API response with plan details.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> plans = client.plans()  # doctest: +SKIP
        """
        resp = self._request("GET", "/v1/plans")
        return resp.json()

    # -----------------------------------------------------------------------
    # Billing & Metrics
    # -----------------------------------------------------------------------

    def billing(self, *, month: str = "", detail: str = "") -> BillingResponse:
        """Get billing summary for the current or specified month.

        Args:
            month: Month in ``YYYY-MM`` format. Defaults to current month.
            detail: Pass ``"urls"`` for per-domain breakdown.

        Returns:
            :class:`BillingResponse` with request counts, credits, and breakdown.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> bill = client.billing(month="2026-04")  # doctest: +SKIP
            >>> print(bill.month)
        """
        params: dict[str, str] = {}
        if month:
            params["month"] = month
        if detail:
            params["detail"] = detail
        resp = self._request("GET", "/v1/sync/billing", params=params)
        return BillingResponse.model_validate(resp.json())

    def metrics(self, *, date: str = "", metric: str = "") -> Any:
        """Get API metrics (admin-level view).

        Args:
            date: ``YYYY-MM-DD`` or ``YYYY-MM-DD:YYYY-MM-DD`` range.
            metric: Filter — ``url``, ``proxy``, ``api_codes``, etc.

        Returns:
            API response with metrics data.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> m = client.metrics(date="2026-04-01")  # doctest: +SKIP
        """
        params: dict[str, str] = {}
        if date:
            params["date"] = date
        if metric:
            params["metric"] = metric
        resp = self._request("GET", "/v1/sync/metrics", params=params)
        return resp.json()

    def client_metrics(
        self,
        *,
        date: str = "",
        hourly: bool = False,
        detail: str = "",
    ) -> ClientMetricsResponse:
        """Get your usage metrics.

        Args:
            date: ``YYYY-MM-DD``, ``YYYY-MM-DD:YYYY-MM-DD``, or ``YYYY-MM``.
            hourly: Include per-hour breakdown (single-day only).
            detail: Pass ``"urls"`` for per-domain breakdown.

        Returns:
            :class:`ClientMetricsResponse` with usage data.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> m = client.client_metrics(date="2026-04")  # doctest: +SKIP
        """
        params: dict[str, Any] = {}
        if date:
            params["date"] = date
        if hourly:
            params["hourly"] = "true"
        if detail:
            params["detail"] = detail
        resp = self._request("GET", "/v1/sync/client-metrics", params=params)
        return ClientMetricsResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Health
    # -----------------------------------------------------------------------

    def health(self) -> Any:
        """Check API health status (no auth required).

        Returns:
            API response with health status.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> h = client.health()  # doctest: +SKIP
        """
        resp = self._request("GET", "/v1/health")
        return resp.json()
