"""Exception hierarchy for the Scraping Pros SDK.

Every exception includes a helpful message that suggests the corrective
action, making it easier for both humans and AI coding assistants to
handle errors correctly.

Example:
    >>> from scrapingpros import ScrapingPros, AuthenticationError
    >>> try:
    ...     client = ScrapingPros("invalid-token")
    ...     client.scrape("https://example.com")
    ... except AuthenticationError as e:
    ...     print(e.status_code)  # 401
"""

from __future__ import annotations


class ScrapingProsError(Exception):
    """Base exception for all Scraping Pros SDK errors.

    Attributes:
        message: Human-readable error description.

    Example:
        >>> from scrapingpros.exceptions import ScrapingProsError
        >>> isinstance(AuthenticationError(401, "bad token"), ScrapingProsError)
        True
    """

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class APIError(ScrapingProsError):
    """Raised when the API returns an error HTTP response.

    This is the parent for all HTTP-related errors. It carries the
    status code and the raw detail from the server.

    Attributes:
        status_code: The HTTP status code returned by the API.
        detail: The raw error detail from the server response.

    Example:
        >>> err = APIError(500, "Internal Server Error")
        >>> err.status_code
        500
    """

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class AuthenticationError(APIError):
    """Raised on HTTP 401 — invalid or missing API token.

    To get started quickly, use the demo token ``demo_6x595maoA6GdOdVb``
    (5,000 credits/month, 30 req/min). For higher limits, contact
    the Scraping Pros team for a dedicated token.

    Example:
        >>> err = AuthenticationError(401, "Invalid token")
        >>> err.status_code
        401
    """

    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(
            status_code,
            f"{detail}. Verify your token or set the SP_TOKEN environment variable. "
            f"For quick testing, use the demo token: demo_6x595maoA6GdOdVb",
        )


class CountryProxyNotApproved(APIError):
    """Raised on HTTP 403 — country proxy access not yet approved.

    Request access with ``client.request_proxy_country(country_code)``.

    Example:
        >>> err = CountryProxyNotApproved(403, "Country proxy BR not approved")
        >>> err.status_code
        403
    """

    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(
            status_code,
            f"{detail}. Request access via client.request_proxy_country().",
        )


class URLBlockedError(APIError):
    """Raised on HTTP 422 when the URL is blocked by SSRF protection.

    Only public ``http://`` and ``https://`` URLs are allowed.

    Example:
        >>> err = URLBlockedError(422, "URL blocked")
        >>> err.status_code
        422
    """

    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(
            status_code,
            f"{detail}. Only public http/https URLs are allowed.",
        )


class ValidationError(APIError):
    """Raised on HTTP 422 for invalid request parameters.

    Check the ``detail`` attribute for field-level validation errors.

    Example:
        >>> err = ValidationError(422, "Field 'url' is required")
        >>> "url" in err.detail
        True
    """


class RateLimitError(APIError):
    """Raised on HTTP 429 when the rate limit is exceeded.

    The SDK automatically retries with exponential backoff before
    raising this error. If you see this, all retries were exhausted.

    Attributes:
        retry_after: Seconds to wait before retrying, from the
            ``Retry-After`` response header. May be ``None``.

    Example:
        >>> err = RateLimitError(429, "Rate limit exceeded", retry_after=30)
        >>> err.retry_after
        30
    """

    def __init__(
        self,
        status_code: int,
        detail: str,
        *,
        retry_after: float | None = None,
    ) -> None:
        self.retry_after = retry_after
        suffix = f" Retry after {retry_after}s." if retry_after else ""
        super().__init__(status_code, f"{detail}.{suffix}")


class QuotaExceededError(APIError):
    """Raised on HTTP 429 when the monthly quota is exhausted.

    Unlike ``RateLimitError``, retrying will not help — the quota
    resets at the start of the next billing month.

    Scraping Pros offers 4 plans with increasing limits:

    - **Free** — limited requests for evaluation
    - **Starter** — for small projects
    - **Pro** — for production workloads
    - **Enterprise** — unlimited, dedicated support

    Check your current usage with ``client.billing()`` and contact the
    Scraping Pros team to upgrade your plan.

    Example:
        >>> err = QuotaExceededError(429, "Monthly quota exceeded")
        >>> err.status_code
        429
    """

    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(
            status_code,
            f"{detail}. Check usage with client.billing(). "
            f"To increase your quota, upgrade your plan — "
            f"contact the Scraping Pros team.",
        )


class ConnectionError(ScrapingProsError):
    """Raised when the SDK cannot connect to the API.

    This wraps underlying network errors (DNS failure, connection
    refused, read timeout, etc.) so you only need to catch
    :class:`ScrapingProsError` for all SDK errors.

    Example:
        >>> err = ConnectionError("Connection refused")
        >>> "refused" in err.message
        True
    """


class TimeoutError(ScrapingProsError):
    """Raised when a request or polling operation times out.

    This is **not** an HTTP error — it means the SDK gave up waiting
    for a response or for an async run to complete.

    Example:
        >>> err = TimeoutError("Run abc123 did not complete within 300s")
        >>> "abc123" in err.message
        True
    """
