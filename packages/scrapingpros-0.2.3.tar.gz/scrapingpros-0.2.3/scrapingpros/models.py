"""Pydantic v2 models for the Scraping Pros API.

All models match the OpenAPI spec at ``/openapi.json`` exactly.
Field names use the same casing as the API (camelCase where the API
uses it) so serialization round-trips cleanly.

Example:
    >>> from scrapingpros.models import ScrapeRequest
    >>> req = ScrapeRequest(url="https://example.com", format="markdown")
    >>> req.model_dump(exclude_none=True)
    {'url': 'https://example.com', 'format': 'markdown'}
"""

from __future__ import annotations

from typing import Any, Literal, Union

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

class ClickAction(BaseModel):
    """Click an element on the page.

    Example:
        >>> action = ClickAction(selector="css:button.submit")
        >>> action.type
        'click'
    """

    type: Literal["click"] = "click"
    selector: str
    wait_for_navigation: bool = False
    optional: bool = False


class InputAction(BaseModel):
    """Type text into a form field.

    Example:
        >>> action = InputAction(selector="css:#search", text="python")
        >>> action.type
        'input'
    """

    type: Literal["input"] = "input"
    selector: str
    text: str


class SelectAction(BaseModel):
    """Select an option from a dropdown.

    Example:
        >>> action = SelectAction(selector="css:#country", value="US")
        >>> action.type
        'select'
    """

    type: Literal["select"] = "select"
    selector: str
    value: str


class KeyPressAction(BaseModel):
    """Press a keyboard key.

    Example:
        >>> action = KeyPressAction(key="Enter")
        >>> action.type
        'key-press'
    """

    type: Literal["key-press"] = "key-press"
    key: str


class WaitForSelectorAction(BaseModel):
    """Wait for an element to appear on the page.

    Example:
        >>> action = WaitForSelectorAction(selector="css:.results", time=5000)
        >>> action.type
        'wait-for-selector'
    """

    type: Literal["wait-for-selector"] = "wait-for-selector"
    selector: str
    time: int


class WaitForTimeoutAction(BaseModel):
    """Wait a fixed number of milliseconds.

    Example:
        >>> action = WaitForTimeoutAction(time=2000)
        >>> action.type
        'wait-for-timeout'
    """

    type: Literal["wait-for-timeout"] = "wait-for-timeout"
    time: int


class EvaluateAction(BaseModel):
    """Execute JavaScript in the browser page context.

    Example:
        >>> action = EvaluateAction(script="document.title")
        >>> action.type
        'evaluate'
    """

    type: Literal["evaluate"] = "evaluate"
    script: str
    timeout: int | None = 30000


class CollectAction(BaseModel):
    """Extract data from the current page during a while loop.

    The ``extract`` dict uses the same format as the top-level
    ``extract`` parameter on :class:`ScrapeRequest`.

    Example:
        >>> action = CollectAction(extract={"titles": {"selector": "css:h2", "multiple": True}})
        >>> action.type
        'collect'
    """

    type: Literal["collect"] = "collect"
    extract: dict[str, str | dict[str, Any]]


# ---------------------------------------------------------------------------
# Conditions (for While loops)
# ---------------------------------------------------------------------------

class SelectorVisibleCondition(BaseModel):
    """Condition: loop while a CSS selector is visible.

    Example:
        >>> cond = SelectorVisibleCondition(selector="css:.next-page")
        >>> cond.type
        'selector-visible'
    """

    type: Literal["selector-visible"] = "selector-visible"
    selector: str


class SelectorInvisibleCondition(BaseModel):
    """Condition: loop while a CSS selector is not visible.

    Example:
        >>> cond = SelectorInvisibleCondition(selector="css:.loading")
        >>> cond.type
        'selector-invisible'
    """

    type: Literal["selector-invisible"] = "selector-invisible"
    selector: str


WhileCondition = Union[SelectorVisibleCondition, SelectorInvisibleCondition]

InnerAction = Union[
    ClickAction,
    InputAction,
    SelectAction,
    KeyPressAction,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    EvaluateAction,
    CollectAction,
]


class WhileControl(BaseModel):
    """Loop that performs actions while a condition is met.

    Example:
        >>> loop = WhileControl(
        ...     condition=SelectorVisibleCondition(selector="css:.next"),
        ...     actions=[ClickAction(selector="css:.next", wait_for_navigation=True)],
        ...     max_iterations=10,
        ... )
        >>> loop.type
        'while'
    """

    type: Literal["while"] = "while"
    condition: WhileCondition
    actions: list[InnerAction]
    max_iterations: int = 20


Action = Union[
    WhileControl,
    ClickAction,
    InputAction,
    SelectAction,
    KeyPressAction,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    EvaluateAction,
    CollectAction,
]


# ---------------------------------------------------------------------------
# HTTP Method
# ---------------------------------------------------------------------------

class MethodGET(BaseModel):
    """HTTP GET method for ``http_method`` parameter.

    Example:
        >>> m = MethodGET()
        >>> m.method
        'get'
    """

    method: Literal["get"] = "get"


class MethodPOST(BaseModel):
    """HTTP POST method with optional payload.

    Example:
        >>> m = MethodPOST(payload={"key": "value"})
        >>> m.method
        'post'
    """

    method: Literal["post"] = "post"
    payload: dict[str, Any] | None = None


HttpMethod = Union[MethodGET, MethodPOST]


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

class ProxyConfig(BaseModel):
    """Advanced proxy configuration with retry settings.

    For simple usage, pass a string like ``"any"`` or ``"US"``
    directly to the ``use_proxy`` parameter instead.

    Example:
        >>> cfg = ProxyConfig(proxy="US", max_retries=5)
        >>> cfg.proxy
        'US'
    """

    proxy: str = "any"
    max_retries: int = 3
    delay_seconds: int = 1
    backoff_factor: int = 2


UseProxy = Union[ProxyConfig, str, None]
"""Type for the ``use_proxy`` parameter.

- ``None`` — no proxy (default)
- ``"any"`` — automatic proxy rotation
- ``"US"`` — country-specific proxy (requires approval)
- :class:`ProxyConfig` — advanced proxy with retry settings
"""


# ---------------------------------------------------------------------------
# Network Capture
# ---------------------------------------------------------------------------

class NetworkCaptureConfig(BaseModel):
    """Configuration for capturing network requests during browser scrape.

    Requires ``browser=True``.

    Example:
        >>> cfg = NetworkCaptureConfig(resource_types=["xhr", "fetch"])
        >>> cfg.resource_types
        ['xhr', 'fetch']
    """

    resource_types: list[str] | None = None
    listen_after_load_ms: int | None = None


# ---------------------------------------------------------------------------
# Scrape Request / Response
# ---------------------------------------------------------------------------

class ScrapeRequest(BaseModel):
    """Request model for ``POST /v1/sync/scrape``.

    Example:
        >>> req = ScrapeRequest(url="https://example.com", format="markdown", browser=True)
        >>> req.model_dump(exclude_none=True)
        {'url': 'https://example.com', 'format': 'markdown', 'browser': True}

        >>> # Auto-prepends https:// if missing
        >>> req = ScrapeRequest(url="example.com")
        >>> req.url
        'https://example.com'
    """

    url: str

    @field_validator("url")
    @classmethod
    def _validate_url(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("URL cannot be empty")
        if not v.startswith(("http://", "https://")):
            v = f"https://{v}"
        return v
    format: Literal["html", "markdown"] = "html"
    browser: bool = False
    browser_type: Literal["light", "heavy", "stealth"] = "light"
    use_proxy: UseProxy = None
    screenshot: bool = False
    actions: list[Action] | None = None
    language: str = ""
    http_method: HttpMethod | None = None
    headers: dict[str, str] | None = None
    window_size: str = ""
    cookies: dict[str, Any] | None = None
    extract: dict[str, str | dict[str, Any]] | None = None
    network_capture: NetworkCaptureConfig | None = None
    retry_on_block: bool = False
    block_resources: list[str] | None = None
    block_requests: list[str] | None = None


class ScrapeGuidance(BaseModel):
    """Guidance included in every scrape response.

    Tells you why a request failed, what to do next, and when to stop.

    Example:
        >>> g = ScrapeGuidance(success=True)
        >>> g.success
        True
        >>> g = ScrapeGuidance(
        ...     success=False, error_type="captcha", error_provider="cloudflare",
        ...     next_steps=["Try with browser=true"],
        ...     suggested_request={"url": "https://x.com", "browser": True},
        ... )
        >>> g.error_type
        'captcha'
    """

    success: bool = False
    error_type: str | None = None
    error_provider: str | None = None
    credits_charged: int | None = None
    credits_refunded: bool | None = None
    next_steps: list[str] = Field(default_factory=list)
    suggested_request: dict[str, Any] | None = None
    stop_reason: str | None = None


class ScrapeResponse(BaseModel):
    """Response model for ``POST /v1/sync/scrape``.

    When ``format="html"``, the ``html`` field contains raw HTML and
    ``markdown`` is ``None``. When ``format="markdown"``, it is reversed.

    Example:
        >>> resp = ScrapeResponse(message="OK", html="<h1>Hello</h1>", statusCode=200)
        >>> resp.statusCode
        200
    """

    html: str | None = None
    markdown: str | None = None
    statusCode: int | None = None
    message: str
    screenshot: str | None = None
    executionTime: float | None = None
    extracted_data: dict[str, Any] | None = None
    evaluate_results: list[Any] | None = None
    network_requests: list[dict[str, Any]] | None = None
    potentiallyBlockedByCaptcha: bool | None = None
    timings: dict[str, Any] | None = None
    guidance: ScrapeGuidance | None = None

    @property
    def content(self) -> str | None:
        """The page content — returns markdown if available, otherwise html.

        This is a convenience property so you don't need to check which
        format was requested.

        Example:
            >>> resp = ScrapeResponse(message="OK", markdown="# Hello")
            >>> resp.content
            '# Hello'
            >>> resp = ScrapeResponse(message="OK", html="<h1>Hello</h1>")
            >>> resp.content
            '<h1>Hello</h1>'
        """
        return self.markdown if self.markdown is not None else self.html


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

class DownloadRequest(BaseModel):
    """Request model for ``POST /v1/sync/download``.

    Example:
        >>> req = DownloadRequest(url="https://example.com/file.pdf")
        >>> req.url
        'https://example.com/file.pdf'
    """

    url: str

    @field_validator("url")
    @classmethod
    def _validate_url(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("URL cannot be empty")
        if not v.startswith(("http://", "https://")):
            v = f"https://{v}"
        return v
    use_proxy: UseProxy = None


class DownloadResponse(BaseModel):
    """Response model for ``POST /v1/sync/download``.

    The ``content`` field contains the file as a base64-encoded string.

    Example:
        >>> resp = DownloadResponse(statusCode=200, message="OK", contentType="application/pdf")
        >>> resp.contentType
        'application/pdf'
    """

    content: str | None = None
    contentType: str | None = None
    statusCode: int
    message: str
    executionTime: float | None = None


# ---------------------------------------------------------------------------
# Collections
# ---------------------------------------------------------------------------

class CollectionPublic(BaseModel):
    """A scraping collection (list of URLs to process as a batch).

    Example:
        >>> col = CollectionPublic(id="abc-123", name="my-batch")
        >>> col.name
        'my-batch'
    """

    id: str
    name: str


class NewCollectionResponse(BaseModel):
    """Response after creating or updating a collection.

    Example:
        >>> resp = NewCollectionResponse(id="abc", name="batch", message="Created")
        >>> resp.message
        'Created'
    """

    id: str | None = None
    name: str | None = None
    message: str
    duplicates_skipped: int = 0


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------

class FailedJobPublic(BaseModel):
    """Details about a failed job in a run.

    Example:
        >>> job = FailedJobPublic(job_id="j1", url="https://fail.com", status="failed")
        >>> job.status
        'failed'
    """

    job_id: str
    url: str
    error: str | None = None
    status: str


class RunPublic(BaseModel):
    """Status and results of an async batch run.

    Example:
        >>> run = RunPublic(run_id="r1", collection_id="c1", status="completed")
        >>> run.status
        'completed'
    """

    run_id: str
    status: str = "in_progress"
    total_requests: int = 0
    success_requests: int = 0
    failed_requests: int = 0
    timeout_requests: int = 0
    collection_id: str
    failed_jobs: list[FailedJobPublic] = Field(default_factory=list)
    job_ids: list[str] = Field(default_factory=list)
    callback_url: str | None = None
    callback_status: str | None = None


class JobExecutionPublic(BaseModel):
    """Detailed execution info for a single job in a run.

    Example:
        >>> job = JobExecutionPublic(
        ...     job_public_id="j1", run_public_id="r1",
        ...     collection_id="c1", status="completed",
        ... )
        >>> job.status
        'completed'
    """

    job_public_id: str
    run_public_id: str
    collection_id: str
    status: Literal["processing", "completed", "failed", "timeout"]
    status_code: int | None = None
    message: str | None = None
    execution_time_sec: float | None = None


class JobExecutionListPublic(BaseModel):
    """List of job executions for a run.

    Example:
        >>> lst = JobExecutionListPublic(items=[])
        >>> len(lst.items)
        0
    """

    items: list[JobExecutionPublic]


# ---------------------------------------------------------------------------
# Viability Test
# ---------------------------------------------------------------------------

class ViabilityTestRequest(BaseModel):
    """Request model for ``POST /v1/async/viability-test``.

    Example:
        >>> req = ViabilityTestRequest(urls=["https://example.com"], depth="full")
        >>> req.depth
        'full'
    """

    urls: list[str]
    depth: Literal["quick", "standard", "full"] = "full"
    actions: list[Action] | None = None


class ViabilityModeResult(BaseModel):
    """Result of testing a single scraping mode on a URL.

    Keyed by mode name in the ``modes_tested`` dict (e.g. ``"simple"``,
    ``"browser_proxy"``).

    Example:
        >>> m = ViabilityModeResult(success=True, time_ms=2500, credits=5)
        >>> m.success
        True
    """

    success: bool = False
    blocked: bool = False
    captcha_type: str | None = None
    time_ms: int | None = None
    credits: int = 0
    error: str | None = None


class UrlViabilityResult(BaseModel):
    """Analysis result for a single URL from a viability test.

    Example:
        >>> r = UrlViabilityResult(
        ...     url="https://example.com", captcha_detected=False,
        ...     captcha_providers=[], javascript_detected=False,
        ...     javascript_required=False, browser_confidence=0.1,
        ...     content_type="text/html", rate_limited=False,
        ...     soft_block=False, retry_after=None, login_wall=False,
        ...     status_code=200, redirect_chain=[], protection_signals={},
        ...     api_detected=False, api_endpoints=[], graphql_detected=False,
        ...     api_auth_required=False, cloudflare_level="none",
        ...     can_use_simple_request=True, can_use_extract_html=True,
        ...     can_use_browser=True, recommended_strategy="simple",
        ...     proxy_recommended=False, proxy_type="none",
        ... )
        >>> r.recommended_strategy
        'simple'
    """

    url: str
    captcha_detected: bool
    captcha_providers: list[str]
    javascript_detected: bool
    javascript_required: bool
    browser_confidence: float
    content_type: str
    rate_limited: bool
    soft_block: bool
    retry_after: int | None
    login_wall: bool
    status_code: int
    redirect_chain: list[str]
    protection_signals: dict[str, str]
    api_detected: bool
    api_endpoints: list[str]
    graphql_detected: bool
    api_auth_required: bool
    cloudflare_level: str
    can_use_simple_request: bool
    can_use_extract_html: bool
    can_use_browser: bool
    recommended_strategy: str
    suggested_action: str | None = None
    blocked_by: list[str] | None = None
    difficulty: Literal["easy", "medium", "hard"] | None = None
    suggested_params: dict[str, Any] | None = None
    proxy_recommended: bool
    proxy_type: str
    modes_tested: dict[str, ViabilityModeResult] | None = None
    best_mode: str | None = None
    total_credits_used: int | None = None


class ViabilityRunPublic(BaseModel):
    """Status and results of a viability test run.

    Example:
        >>> run = ViabilityRunPublic(run_id="v1", status="completed", total_urls=1)
        >>> run.status
        'completed'
    """

    run_id: str
    status: str
    total_urls: int
    completed_urls: int = 0
    depth: str | None = None
    results: list[UrlViabilityResult] | None = None


# ---------------------------------------------------------------------------
# Proxy Endpoints
# ---------------------------------------------------------------------------

class CountryRequest(BaseModel):
    """Request model for ``POST /v1/proxy/request-country``.

    Example:
        >>> req = CountryRequest(country_code="US", reason="Need US pricing")
        >>> req.country_code
        'US'
    """

    country_code: str
    reason: str = ""


# ---------------------------------------------------------------------------
# Proxy Responses (typed)
# ---------------------------------------------------------------------------

class ProxyCountriesResponse(BaseModel):
    """Response from ``GET /v1/proxy/countries``.

    Example:
        >>> resp = ProxyCountriesResponse(countries=["US", "BR", "AR"])
        >>> "US" in resp.countries
        True
    """

    countries: list[str]
    error: str | None = None


class ProxyRequestCountryResponse(BaseModel):
    """Response from ``POST /v1/proxy/request-country``.

    Example:
        >>> resp = ProxyRequestCountryResponse(status="pending", country_code="US", message="Request submitted")
        >>> resp.status
        'pending'
    """

    status: str
    country_code: str
    message: str


class ProxyStatusResponse(BaseModel):
    """Response from ``GET /v1/proxy/status``.

    Example:
        >>> resp = ProxyStatusResponse(client_id="c1", approved_countries=["US"], pending_countries=["BR"])
        >>> "US" in resp.approved_countries
        True
    """

    client_id: str
    approved_countries: list[str]
    pending_countries: list[str]
    error: str | None = None


# ---------------------------------------------------------------------------
# Billing & Metrics Responses (typed)
# ---------------------------------------------------------------------------

class BillingCredits(BaseModel):
    """Credit breakdown in a billing response.

    Example:
        >>> c = BillingCredits(simple=100, browser=50, total=350)
        >>> c.total
        350
    """

    simple: int = 0
    browser: int = 0
    total: int = 0


class BillingClientData(BaseModel):
    """Billing data for a single client.

    Example:
        >>> d = BillingClientData(total_requests=10, total_success=9)
        >>> d.total_success
        9
    """

    simple_success: int = 0
    simple_failed: int = 0
    simple_total: int = 0
    browser_success: int = 0
    browser_failed: int = 0
    browser_total: int = 0
    total_requests: int = 0
    total_success: int = 0
    total_failed: int = 0
    credits: BillingCredits | None = None
    by_url: dict[str, Any] | None = None


class CreditSystemInfo(BaseModel):
    """Credit multipliers for request types.

    Example:
        >>> info = CreditSystemInfo(simple_request=1, browser_request=5)
        >>> info.browser_request
        5
    """

    simple_request: int = 1
    browser_request: int = 5


class BillingResponse(BaseModel):
    """Response from ``GET /v1/sync/billing``.

    Example:
        >>> resp = BillingResponse(month="2026-04", clients={}, credit_system=CreditSystemInfo())
        >>> resp.month
        '2026-04'
    """

    month: str
    clients: dict[str, BillingClientData]
    credit_system: CreditSystemInfo


class ClientMetricsResponse(BaseModel):
    """Response from ``GET /v1/sync/client-metrics``.

    Example:
        >>> resp = ClientMetricsResponse()
        >>> resp.date is None
        True
    """

    date: str | None = None
    scrape_type: dict[str, Any] | None = None
    url: dict[str, Any] | None = None
    hourly: dict[str, Any] | None = None
