"""Scraping Pros Python SDK.

Example:
    >>> from scrapingpros import ScrapingPros
    >>> client = ScrapingPros("your_token")
    >>> result = client.scrape("https://example.com")
    >>> print(result.html[:50])  # doctest: +SKIP
    '<!doctype html>...'
"""

from scrapingpros._base import DEMO_TOKEN
from scrapingpros._version import __version__
from scrapingpros.async_client import AsyncScrapingPros
from scrapingpros.client import ScrapingPros
from scrapingpros.exceptions import (
    APIError,
    AuthenticationError,
    ConnectionError,
    CountryProxyNotApproved,
    QuotaExceededError,
    RateLimitError,
    ScrapingProsError,
    TimeoutError,
    URLBlockedError,
    ValidationError,
)
from scrapingpros.models import (
    Action,
    BillingClientData,
    BillingCredits,
    BillingResponse,
    ClickAction,
    ClientMetricsResponse,
    CollectAction,
    CollectionPublic,
    CountryRequest,
    CreditSystemInfo,
    ProxyCountriesResponse,
    ProxyRequestCountryResponse,
    ProxyStatusResponse,
    DownloadRequest,
    DownloadResponse,
    EvaluateAction,
    FailedJobPublic,
    InputAction,
    JobExecutionListPublic,
    JobExecutionPublic,
    KeyPressAction,
    MethodGET,
    MethodPOST,
    NetworkCaptureConfig,
    NewCollectionResponse,
    ProxyConfig,
    RunPublic,
    ScrapeGuidance,
    ScrapeRequest,
    ScrapeResponse,
    SelectAction,
    SelectorInvisibleCondition,
    SelectorVisibleCondition,
    UrlViabilityResult,
    ViabilityRunPublic,
    ViabilityModeResult,
    ViabilityTestRequest,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    WhileControl,
)

__all__ = [
    # Version
    "__version__",
    # Clients
    "ScrapingPros",
    "AsyncScrapingPros",
    # Demo
    "DEMO_TOKEN",
    # Exceptions
    "ScrapingProsError",
    "APIError",
    "AuthenticationError",
    "ConnectionError",
    "CountryProxyNotApproved",
    "URLBlockedError",
    "ValidationError",
    "RateLimitError",
    "QuotaExceededError",
    "TimeoutError",
    # Models — Request/Response
    "ScrapeGuidance",
    "ScrapeRequest",
    "ScrapeResponse",
    "DownloadRequest",
    "DownloadResponse",
    # Models — Actions
    "Action",
    "ClickAction",
    "InputAction",
    "SelectAction",
    "KeyPressAction",
    "WaitForSelectorAction",
    "WaitForTimeoutAction",
    "EvaluateAction",
    "CollectAction",
    "WhileControl",
    "SelectorVisibleCondition",
    "SelectorInvisibleCondition",
    # Models — Config
    "ProxyConfig",
    "NetworkCaptureConfig",
    "MethodGET",
    "MethodPOST",
    # Models — Collections/Runs
    "CollectionPublic",
    "NewCollectionResponse",
    "RunPublic",
    "FailedJobPublic",
    "JobExecutionPublic",
    "JobExecutionListPublic",
    # Models — Viability
    "ViabilityTestRequest",
    "ViabilityRunPublic",
    "ViabilityModeResult",
    "UrlViabilityResult",
    # Models — Proxy
    "CountryRequest",
    "ProxyCountriesResponse",
    "ProxyRequestCountryResponse",
    "ProxyStatusResponse",
    # Models — Billing/Metrics
    "BillingResponse",
    "BillingClientData",
    "BillingCredits",
    "CreditSystemInfo",
    "ClientMetricsResponse",
]
