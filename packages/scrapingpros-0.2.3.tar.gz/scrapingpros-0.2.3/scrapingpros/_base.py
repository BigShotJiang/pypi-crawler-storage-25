"""Shared logic for sync and async clients.

Contains error mapping, rate-limit header parsing, and retry
configuration used by both :class:`ScrapingPros` and
:class:`AsyncScrapingPros`.
"""

from __future__ import annotations

import logging
import os
import random
from dataclasses import dataclass, field

logger = logging.getLogger("scrapingpros")

from scrapingpros.exceptions import (
    APIError,
    AuthenticationError,
    ConnectionError,
    CountryProxyNotApproved,
    QuotaExceededError,
    RateLimitError,
    ScrapingProsError,
    URLBlockedError,
    ValidationError,
)

DEFAULT_BASE_URL = "https://api.scrapingpros.com"
DEFAULT_TIMEOUT = 120.0
DEFAULT_MAX_RETRIES = 3
SP_TOKEN_ENV_VAR = "SP_TOKEN"
DEMO_TOKEN = "demo_6x595maoA6GdOdVb"


def resolve_token(token: str | None) -> str:
    """Return *token* if given, else read ``SP_TOKEN`` from the environment.

    Raises:
        AuthenticationError: If no token is provided and the env var is unset.
    """
    if token is not None:
        if not token.strip():
            raise AuthenticationError(401, "API token cannot be empty")
        return token
    env_token = os.environ.get(SP_TOKEN_ENV_VAR)
    if env_token and env_token.strip():
        return env_token
    raise AuthenticationError(
        401,
        f"No API token provided. Pass it as the first argument or set the {SP_TOKEN_ENV_VAR} environment variable",
    )


# ---------------------------------------------------------------------------
# Rate-limit header parsing
# ---------------------------------------------------------------------------

@dataclass
class RateLimitInfo:
    """Parsed rate-limit and quota headers from an API response.

    All fields are ``None`` when the corresponding header is absent.
    """

    rate_limit_limit: int | None = None
    rate_limit_remaining: int | None = None
    rate_limit_reset: int | None = None
    quota_limit: int | None = None
    quota_used: int | None = None
    quota_remaining: int | str | None = None  # can be "unlimited"
    credits_charged: int | None = None


def parse_rate_limit_headers(headers: dict[str, str] | None) -> RateLimitInfo:
    """Extract ``X-RateLimit-*`` and ``X-Quota-*`` headers into a typed object."""
    if headers is None:
        return RateLimitInfo()

    # Normalize to lowercase keys since httpx lowercases headers
    lower_headers = {k.lower(): v for k, v in headers.items()}

    def _int_or_none(key: str) -> int | None:
        val = lower_headers.get(key.lower())
        if val is None:
            return None
        try:
            return int(val)
        except (ValueError, TypeError):
            return None

    quota_remaining_raw = lower_headers.get("x-quota-remaining")
    if quota_remaining_raw == "unlimited":
        quota_remaining: int | str | None = "unlimited"
    else:
        quota_remaining = _int_or_none("X-Quota-Remaining")

    return RateLimitInfo(
        rate_limit_limit=_int_or_none("X-RateLimit-Limit"),
        rate_limit_remaining=_int_or_none("X-RateLimit-Remaining"),
        rate_limit_reset=_int_or_none("X-RateLimit-Reset"),
        quota_limit=_int_or_none("X-Quota-Limit"),
        quota_used=_int_or_none("X-Quota-Used"),
        quota_remaining=quota_remaining,
        credits_charged=_int_or_none("X-Credits-Charged"),
    )


# ---------------------------------------------------------------------------
# Error mapping
# ---------------------------------------------------------------------------

def _extract_message(detail: str) -> str:
    """Try to extract the 'message' field from a JSON error response."""
    try:
        import json
        data = json.loads(detail)
        if isinstance(data, dict) and "message" in data:
            return data["message"]
    except (json.JSONDecodeError, TypeError):
        pass
    return detail


def _is_ssrf_error(detail: str) -> bool:
    """Heuristic: does the error look like an SSRF block?"""
    lower = detail.lower()
    return "ssrf" in lower or "url blocked" in lower or "blocked url" in lower


def _is_quota_error(detail: str) -> bool:
    lower = detail.lower()
    return "quota" in lower


def map_error(
    status_code: int,
    detail: str,
    headers: dict[str, str] | None = None,
) -> ScrapingProsError:
    """Map an HTTP error response to the appropriate SDK exception."""
    detail = _extract_message(detail)

    if status_code == 401:
        return AuthenticationError(status_code, detail)

    if status_code == 403:
        return CountryProxyNotApproved(status_code, detail)

    if status_code == 422:
        if _is_ssrf_error(detail):
            return URLBlockedError(status_code, detail)
        return ValidationError(status_code, detail)

    if status_code == 429:
        retry_after: float | None = None
        if headers:
            # httpx lowercases header names
            lower_h = {k.lower(): v for k, v in headers.items()}
            raw = lower_h.get("retry-after")
            if raw is not None:
                try:
                    retry_after = float(raw)
                except (ValueError, TypeError):
                    pass

        if _is_quota_error(detail):
            return QuotaExceededError(status_code, detail)
        return RateLimitError(status_code, detail, retry_after=retry_after)

    return APIError(status_code, detail)


# ---------------------------------------------------------------------------
# Retry configuration
# ---------------------------------------------------------------------------

@dataclass
class RetryConfig:
    """Settings for automatic retry on retryable responses (429, 5xx)."""

    max_retries: int = DEFAULT_MAX_RETRIES
    backoff_base: float = 0.5
    max_backoff: float = 60.0

    def delay_for_attempt(self, attempt: int, retry_after: float | None = None) -> float:
        """Calculate the delay in seconds before the next retry.

        Uses the ``Retry-After`` header value when present; otherwise
        falls back to exponential backoff with jitter:
        ``backoff_base * 2^attempt * random(0.75, 1.0)``.
        """
        if retry_after is not None and retry_after > 0:
            base = min(retry_after, self.max_backoff)
        else:
            base = min(self.backoff_base * (2 ** attempt), self.max_backoff)
        # Jitter: ±25% to prevent thundering herd
        return base * random.uniform(0.75, 1.0)
