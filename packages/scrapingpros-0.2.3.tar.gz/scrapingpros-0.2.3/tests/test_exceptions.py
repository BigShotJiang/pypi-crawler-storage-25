"""Tests for the scrapingpros exception hierarchy."""

from __future__ import annotations

import pytest

from scrapingpros.exceptions import (
    APIError,
    AuthenticationError,
    CountryProxyNotApproved,
    QuotaExceededError,
    RateLimitError,
    ScrapingProsError,
    TimeoutError,
    URLBlockedError,
    ValidationError,
)


class TestScrapingProsError:
    def test_base_error(self):
        err = ScrapingProsError("something went wrong")
        assert err.message == "something went wrong"
        assert str(err) == "something went wrong"

    def test_is_exception(self):
        assert issubclass(ScrapingProsError, Exception)


class TestAPIError:
    def test_stores_status_and_detail(self):
        err = APIError(500, "Internal Server Error")
        assert err.status_code == 500
        assert err.detail == "Internal Server Error"
        assert "500" in str(err)

    def test_inherits_from_base(self):
        err = APIError(500, "fail")
        assert isinstance(err, ScrapingProsError)


class TestAuthenticationError:
    def test_status_code(self):
        err = AuthenticationError(401, "Invalid token")
        assert err.status_code == 401

    def test_suggests_fix(self):
        err = AuthenticationError(401, "Invalid token")
        assert "SP_TOKEN" in str(err)

    def test_inherits(self):
        err = AuthenticationError(401, "x")
        assert isinstance(err, APIError)
        assert isinstance(err, ScrapingProsError)


class TestCountryProxyNotApproved:
    def test_status_code(self):
        err = CountryProxyNotApproved(403, "Country proxy BR not approved")
        assert err.status_code == 403

    def test_suggests_fix(self):
        err = CountryProxyNotApproved(403, "Not approved")
        assert "request_proxy_country" in str(err)


class TestURLBlockedError:
    def test_status_code(self):
        err = URLBlockedError(422, "URL blocked by SSRF policy")
        assert err.status_code == 422

    def test_suggests_fix(self):
        err = URLBlockedError(422, "blocked")
        assert "public http/https" in str(err)


class TestValidationError:
    def test_basic(self):
        err = ValidationError(422, "Field 'url' is required")
        assert err.status_code == 422
        assert "url" in err.detail


class TestRateLimitError:
    def test_without_retry_after(self):
        err = RateLimitError(429, "Rate limit exceeded")
        assert err.status_code == 429
        assert err.retry_after is None

    def test_with_retry_after(self):
        err = RateLimitError(429, "Rate limit exceeded", retry_after=30)
        assert err.retry_after == 30
        assert "30" in str(err)

    def test_inherits(self):
        err = RateLimitError(429, "x")
        assert isinstance(err, APIError)


class TestQuotaExceededError:
    def test_basic(self):
        err = QuotaExceededError(429, "Monthly quota exceeded")
        assert err.status_code == 429

    def test_suggests_billing(self):
        err = QuotaExceededError(429, "quota")
        assert "billing" in str(err)


class TestTimeoutError:
    def test_basic(self):
        err = TimeoutError("Run abc did not complete within 300s")
        assert "abc" in err.message
        assert "300s" in str(err)

    def test_inherits_from_base_not_api(self):
        err = TimeoutError("timeout")
        assert isinstance(err, ScrapingProsError)
        assert not isinstance(err, APIError)


class TestExceptionHierarchy:
    """Verify the full inheritance tree matches the design."""

    @pytest.mark.parametrize(
        "exc_class",
        [
            AuthenticationError,
            CountryProxyNotApproved,
            URLBlockedError,
            ValidationError,
            RateLimitError,
            QuotaExceededError,
        ],
    )
    def test_api_errors_inherit_from_api_error(self, exc_class):
        assert issubclass(exc_class, APIError)
        assert issubclass(exc_class, ScrapingProsError)

    def test_timeout_not_api_error(self):
        assert issubclass(TimeoutError, ScrapingProsError)
        assert not issubclass(TimeoutError, APIError)

    def test_catch_all_with_base(self):
        """All SDK exceptions are catchable with ScrapingProsError."""
        exceptions = [
            AuthenticationError(401, "x"),
            CountryProxyNotApproved(403, "x"),
            URLBlockedError(422, "x"),
            ValidationError(422, "x"),
            RateLimitError(429, "x"),
            QuotaExceededError(429, "x"),
            APIError(500, "x"),
            TimeoutError("x"),
        ]
        for exc in exceptions:
            assert isinstance(exc, ScrapingProsError)
