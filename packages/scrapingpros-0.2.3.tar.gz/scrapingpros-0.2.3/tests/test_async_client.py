"""Unit tests for the async AsyncScrapingPros client (mocked HTTP)."""

from __future__ import annotations

import pytest
import httpx
from pytest_httpx import HTTPXMock

from scrapingpros.async_client import AsyncScrapingPros
from scrapingpros.exceptions import AuthenticationError, RateLimitError

BASE = "https://mock-api.scrapingpros.com"
TOKEN = "test-token"


@pytest.fixture
async def client():
    c = AsyncScrapingPros(TOKEN, base_url=BASE)
    yield c
    await c.close()


class TestAsyncScrape:
    @pytest.mark.asyncio
    async def test_simple_html(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>Hello</h1>", "statusCode": 200, "message": "OK"},
        )
        result = await client.scrape("https://example.com")
        assert result.html == "<h1>Hello</h1>"

    @pytest.mark.asyncio
    async def test_markdown(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"markdown": "# Hello", "statusCode": 200, "message": "OK"},
        )
        result = await client.scrape("https://example.com", format="markdown")
        assert result.markdown == "# Hello"


class TestAsyncDownload:
    @pytest.mark.asyncio
    async def test_basic(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/download",
            json={
                "content": "base64data",
                "contentType": "application/pdf",
                "statusCode": 200,
                "message": "OK",
            },
        )
        result = await client.download("https://example.com/file.pdf")
        assert result.content == "base64data"


class TestAsyncCollections:
    @pytest.mark.asyncio
    async def test_create(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections",
            json={"id": "c1", "name": "batch", "message": "Created"},
        )
        col = await client.create_collection("batch")
        assert col.id == "c1"

    @pytest.mark.asyncio
    async def test_list(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections",
            json=[{"id": "c1", "name": "batch"}],
        )
        cols = await client.list_collections()
        assert len(cols) == 1


class TestAsyncRuns:
    @pytest.mark.asyncio
    async def test_create_run(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/run",
            json={"run_id": "r1", "collection_id": "c1", "status": "in_progress"},
        )
        run = await client.create_run("c1")
        assert run.run_id == "r1"

    @pytest.mark.asyncio
    async def test_run_and_wait(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/run",
            json={"run_id": "r1", "collection_id": "c1", "status": "in_progress"},
        )
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/runs/r1",
            json={"run_id": "r1", "collection_id": "c1", "status": "completed", "total_requests": 2, "success_requests": 2},
        )
        run = await client.run_and_wait("c1", poll_interval=0.01, timeout=5)
        assert run.status == "completed"


class TestAsyncNewFeatures:
    @pytest.mark.asyncio
    async def test_stealth_browser_type(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        await client.scrape("https://example.com", browser=True, browser_type="stealth")
        body = httpx_mock.get_requests()[0].content.decode()
        assert '"browser_type": "stealth"' in body or '"browser_type":"stealth"' in body

    @pytest.mark.asyncio
    async def test_block_resources(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        await client.scrape("https://example.com", browser=True, block_resources=["image", "font"])
        body = httpx_mock.get_requests()[0].content.decode()
        assert "block_resources" in body
        assert "image" in body

    @pytest.mark.asyncio
    async def test_block_requests(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        await client.scrape("https://example.com", browser=True, block_requests=["analytics"])
        body = httpx_mock.get_requests()[0].content.decode()
        assert "block_requests" in body
        assert "analytics" in body

    @pytest.mark.asyncio
    async def test_default_browser_type_is_light(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        await client.scrape("https://example.com", browser=True)
        body = httpx_mock.get_requests()[0].content.decode()
        assert '"browser_type": "light"' in body or '"browser_type":"light"' in body


class TestAsyncScrapeMany:
    @pytest.mark.asyncio
    async def test_scrape_many(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        for i in range(3):
            httpx_mock.add_response(
                url=f"{BASE}/v1/sync/scrape",
                json={"markdown": f"# Page {i}", "statusCode": 200, "message": "OK"},
            )
        results = await client.scrape_many(
            ["https://example.com/1", "https://example.com/2", "https://example.com/3"],
            max_concurrent=2,
        )
        assert len(results) == 3
        assert all(not isinstance(r, Exception) for r in results)


class TestAsyncErrorHandling:
    @pytest.mark.asyncio
    async def test_401(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=401,
            text="Invalid token",
        )
        with pytest.raises(AuthenticationError):
            await client.scrape("https://example.com")

    @pytest.mark.asyncio
    async def test_429_retry(self, httpx_mock: HTTPXMock):
        c = AsyncScrapingPros(TOKEN, base_url=BASE, max_retries=2)
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=429,
            text="Rate limit",
            headers={"Retry-After": "0"},
        )
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        result = await c.scrape("https://example.com")
        assert result.html == "<h1>OK</h1>"
        await c.close()


class TestAsyncContextManager:
    @pytest.mark.asyncio
    async def test_async_with(self, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>Hi</h1>", "statusCode": 200, "message": "OK"},
        )
        async with AsyncScrapingPros(TOKEN, base_url=BASE) as client:
            result = await client.scrape("https://example.com")
            assert result.html == "<h1>Hi</h1>"


class TestAsyncRateLimitProperties:
    @pytest.mark.asyncio
    async def test_updated(self, httpx_mock: HTTPXMock, client: AsyncScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>Hi</h1>", "statusCode": 200, "message": "OK"},
            headers={"X-RateLimit-Remaining": "100", "X-Quota-Remaining": "5000"},
        )
        await client.scrape("https://example.com")
        assert client.rate_limit_remaining == 100
        assert client.quota_remaining == 5000
