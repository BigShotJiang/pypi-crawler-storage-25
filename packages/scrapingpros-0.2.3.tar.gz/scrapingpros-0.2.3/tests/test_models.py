"""Tests for Pydantic models — serialization, defaults, and validation."""

from __future__ import annotations

import pytest

from scrapingpros.models import (
    ClickAction,
    CollectAction,
    CollectionPublic,
    CountryRequest,
    DownloadRequest,
    DownloadResponse,
    EvaluateAction,
    FailedJobPublic,
    InputAction,
    JobExecutionListPublic,
    JobExecutionPublic,
    KeyPressAction,
    MethodGET,
    MethodPOST,
    NetworkCaptureConfig,
    NewCollectionResponse,
    ProxyConfig,
    RunPublic,
    ScrapeRequest,
    ScrapeResponse,
    SelectAction,
    SelectorInvisibleCondition,
    SelectorVisibleCondition,
    UrlViabilityResult,
    ViabilityRunPublic,
    ViabilityTestRequest,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    WhileControl,
)


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

class TestClickAction:
    def test_defaults(self):
        a = ClickAction(selector="css:button")
        assert a.type == "click"
        assert a.wait_for_navigation is False
        assert a.optional is False

    def test_with_options(self):
        a = ClickAction(selector="css:a", wait_for_navigation=True, optional=True)
        assert a.wait_for_navigation is True
        assert a.optional is True

    def test_serialization(self):
        data = ClickAction(selector="css:x").model_dump()
        assert data["type"] == "click"
        assert data["selector"] == "css:x"


class TestInputAction:
    def test_basic(self):
        a = InputAction(selector="css:#q", text="hello")
        assert a.type == "input"
        assert a.text == "hello"


class TestSelectAction:
    def test_basic(self):
        a = SelectAction(selector="css:#lang", value="en")
        assert a.type == "select"
        assert a.value == "en"


class TestKeyPressAction:
    def test_basic(self):
        a = KeyPressAction(key="Enter")
        assert a.type == "key-press"
        assert a.key == "Enter"


class TestWaitForSelectorAction:
    def test_basic(self):
        a = WaitForSelectorAction(selector="css:.loaded", time=5000)
        assert a.type == "wait-for-selector"
        assert a.time == 5000


class TestWaitForTimeoutAction:
    def test_basic(self):
        a = WaitForTimeoutAction(time=2000)
        assert a.type == "wait-for-timeout"


class TestEvaluateAction:
    def test_defaults(self):
        a = EvaluateAction(script="document.title")
        assert a.type == "evaluate"
        assert a.timeout == 30000

    def test_custom_timeout(self):
        a = EvaluateAction(script="1+1", timeout=5000)
        assert a.timeout == 5000


class TestCollectAction:
    def test_basic(self):
        a = CollectAction(extract={"titles": {"selector": "css:h2", "multiple": True}})
        assert a.type == "collect"
        assert "titles" in a.extract


class TestWhileControl:
    def test_basic_loop(self):
        loop = WhileControl(
            condition=SelectorVisibleCondition(selector="css:.next"),
            actions=[ClickAction(selector="css:.next", wait_for_navigation=True)],
        )
        assert loop.type == "while"
        assert loop.max_iterations == 20
        assert len(loop.actions) == 1

    def test_custom_max_iterations(self):
        loop = WhileControl(
            condition=SelectorInvisibleCondition(selector="css:.gone"),
            actions=[WaitForTimeoutAction(time=100)],
            max_iterations=5,
        )
        assert loop.max_iterations == 5


# ---------------------------------------------------------------------------
# HTTP Method
# ---------------------------------------------------------------------------

class TestHttpMethod:
    def test_get(self):
        m = MethodGET()
        assert m.method == "get"

    def test_post_without_payload(self):
        m = MethodPOST()
        assert m.method == "post"
        assert m.payload is None

    def test_post_with_payload(self):
        m = MethodPOST(payload={"key": "val"})
        assert m.payload == {"key": "val"}


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

class TestProxyConfig:
    def test_defaults(self):
        p = ProxyConfig()
        assert p.proxy == "any"
        assert p.max_retries == 3
        assert p.delay_seconds == 1
        assert p.backoff_factor == 2

    def test_custom(self):
        p = ProxyConfig(proxy="US", max_retries=5)
        assert p.proxy == "US"


# ---------------------------------------------------------------------------
# Network Capture
# ---------------------------------------------------------------------------

class TestNetworkCaptureConfig:
    def test_defaults(self):
        cfg = NetworkCaptureConfig()
        assert cfg.resource_types is None
        assert cfg.listen_after_load_ms is None

    def test_with_types(self):
        cfg = NetworkCaptureConfig(resource_types=["xhr", "fetch"], listen_after_load_ms=5000)
        assert cfg.resource_types == ["xhr", "fetch"]


# ---------------------------------------------------------------------------
# ScrapeRequest
# ---------------------------------------------------------------------------

class TestScrapeRequest:
    def test_minimal(self):
        req = ScrapeRequest(url="https://example.com")
        assert req.url == "https://example.com"
        assert req.format == "html"
        assert req.browser is False
        assert req.browser_type == "light"

    def test_markdown_format(self):
        req = ScrapeRequest(url="https://example.com", format="markdown")
        assert req.format == "markdown"

    def test_auto_prepend_https(self):
        req = ScrapeRequest(url="example.com")
        assert req.url == "https://example.com"

    def test_http_preserved(self):
        req = ScrapeRequest(url="http://example.com")
        assert req.url == "http://example.com"

    def test_empty_url_raises(self):
        with pytest.raises(Exception):
            ScrapeRequest(url="")

    def test_whitespace_url_raises(self):
        with pytest.raises(Exception):
            ScrapeRequest(url="   ")

    def test_full_request(self):
        req = ScrapeRequest(
            url="https://example.com",
            format="markdown",
            browser=True,
            browser_type="light",
            use_proxy="US",
            screenshot=True,
            actions=[ClickAction(selector="css:button")],
            extract={"title": "css:h1"},
            network_capture=NetworkCaptureConfig(resource_types=["xhr"]),
        )
        assert req.browser is True
        assert req.browser_type == "light"
        assert req.use_proxy == "US"
        assert len(req.actions) == 1

    def test_serialization_excludes_none(self):
        req = ScrapeRequest(url="https://example.com")
        data = req.model_dump(exclude_none=True)
        assert "url" in data
        assert "actions" not in data
        assert "extract" not in data

    def test_proxy_config_object(self):
        req = ScrapeRequest(url="https://x.com", use_proxy=ProxyConfig(proxy="BR"))
        assert isinstance(req.use_proxy, ProxyConfig)

    def test_browser_type_stealth(self):
        req = ScrapeRequest(url="https://example.com", browser=True, browser_type="stealth")
        assert req.browser_type == "stealth"
        data = req.model_dump(exclude_none=True)
        assert data["browser_type"] == "stealth"

    def test_block_resources(self):
        req = ScrapeRequest(
            url="https://example.com",
            browser=True,
            block_resources=["image", "font", "media"],
        )
        assert req.block_resources == ["image", "font", "media"]
        data = req.model_dump(exclude_none=True)
        assert data["block_resources"] == ["image", "font", "media"]

    def test_block_requests(self):
        req = ScrapeRequest(
            url="https://example.com",
            browser=True,
            block_requests=["google-analytics", "doubleclick"],
        )
        assert req.block_requests == ["google-analytics", "doubleclick"]

    def test_block_resources_none_excluded(self):
        req = ScrapeRequest(url="https://example.com")
        data = req.model_dump(exclude_none=True)
        assert "block_resources" not in data
        assert "block_requests" not in data

    def test_default_browser_type_is_light(self):
        req = ScrapeRequest(url="https://example.com", browser=True)
        assert req.browser_type == "light"

    def test_full_request_with_blocking(self):
        req = ScrapeRequest(
            url="https://example.com",
            browser=True,
            browser_type="stealth",
            block_resources=["image", "stylesheet"],
            block_requests=["analytics", "tracker"],
            retry_on_block=True,
        )
        assert req.browser_type == "stealth"
        assert req.block_resources == ["image", "stylesheet"]
        assert req.block_requests == ["analytics", "tracker"]
        assert req.retry_on_block is True


# ---------------------------------------------------------------------------
# ScrapeResponse
# ---------------------------------------------------------------------------

class TestScrapeResponse:
    def test_html_response(self):
        resp = ScrapeResponse(html="<h1>Hi</h1>", statusCode=200, message="OK")
        assert resp.html == "<h1>Hi</h1>"
        assert resp.markdown is None

    def test_markdown_response(self):
        resp = ScrapeResponse(markdown="# Hi", statusCode=200, message="OK")
        assert resp.markdown == "# Hi"
        assert resp.html is None

    def test_content_returns_markdown_when_available(self):
        resp = ScrapeResponse(message="OK", markdown="# Hello", html=None)
        assert resp.content == "# Hello"

    def test_content_returns_html_when_no_markdown(self):
        resp = ScrapeResponse(message="OK", html="<h1>Hello</h1>", markdown=None)
        assert resp.content == "<h1>Hello</h1>"

    def test_content_prefers_markdown(self):
        resp = ScrapeResponse(message="OK", html="<h1>Hi</h1>", markdown="# Hi")
        assert resp.content == "# Hi"

    def test_content_returns_none_when_empty(self):
        resp = ScrapeResponse(message="OK")
        assert resp.content is None

    def test_full_response(self):
        resp = ScrapeResponse(
            html="<h1>Hi</h1>",
            statusCode=200,
            message="OK",
            executionTime=1.5,
            extracted_data={"title": "Hi"},
            evaluate_results=["result1"],
            network_requests=[{"url": "https://api.com"}],
            potentiallyBlockedByCaptcha=False,
            timings={"queue_wait_ms": 10},
        )
        assert resp.executionTime == 1.5
        assert resp.potentiallyBlockedByCaptcha is False
        assert resp.timings["queue_wait_ms"] == 10


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

class TestDownloadRequest:
    def test_minimal(self):
        req = DownloadRequest(url="https://example.com/file.pdf")
        assert req.use_proxy is None

    def test_with_proxy(self):
        req = DownloadRequest(url="https://x.com/f.pdf", use_proxy="any")
        assert req.use_proxy == "any"


class TestDownloadResponse:
    def test_basic(self):
        resp = DownloadResponse(
            content="base64data",
            contentType="application/pdf",
            statusCode=200,
            message="OK",
        )
        assert resp.content == "base64data"
        assert resp.contentType == "application/pdf"


# ---------------------------------------------------------------------------
# Collections
# ---------------------------------------------------------------------------

class TestCollectionPublic:
    def test_basic(self):
        col = CollectionPublic(id="abc", name="my-batch")
        assert col.id == "abc"
        assert col.name == "my-batch"


class TestNewCollectionResponse:
    def test_basic(self):
        resp = NewCollectionResponse(id="abc", name="batch", message="Created")
        assert resp.duplicates_skipped == 0

    def test_with_duplicates(self):
        resp = NewCollectionResponse(message="Created", duplicates_skipped=3)
        assert resp.duplicates_skipped == 3


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------

class TestRunPublic:
    def test_defaults(self):
        run = RunPublic(run_id="r1", collection_id="c1")
        assert run.status == "in_progress"
        assert run.total_requests == 0
        assert run.failed_jobs == []

    def test_completed(self):
        run = RunPublic(
            run_id="r1",
            collection_id="c1",
            status="completed",
            total_requests=10,
            success_requests=8,
            failed_requests=2,
            failed_jobs=[
                FailedJobPublic(job_id="j1", url="https://fail.com", status="failed", error="timeout"),
            ],
        )
        assert run.success_requests == 8
        assert len(run.failed_jobs) == 1
        assert run.failed_jobs[0].error == "timeout"


class TestJobExecutionPublic:
    def test_basic(self):
        job = JobExecutionPublic(
            job_public_id="j1",
            run_public_id="r1",
            collection_id="c1",
            status="completed",
            status_code=200,
        )
        assert job.status == "completed"


class TestJobExecutionListPublic:
    def test_empty(self):
        lst = JobExecutionListPublic(items=[])
        assert len(lst.items) == 0


# ---------------------------------------------------------------------------
# Viability
# ---------------------------------------------------------------------------

class TestViabilityTestRequest:
    def test_basic(self):
        req = ViabilityTestRequest(urls=["https://example.com"])
        assert len(req.urls) == 1
        assert req.actions is None

    def test_with_actions(self):
        req = ViabilityTestRequest(
            urls=["https://example.com"],
            actions=[ClickAction(selector="css:button")],
        )
        assert len(req.actions) == 1


class TestUrlViabilityResult:
    def test_basic(self):
        r = UrlViabilityResult(
            url="https://example.com",
            captcha_detected=False,
            captcha_providers=[],
            javascript_detected=True,
            javascript_required=False,
            browser_confidence=0.3,
            content_type="text/html",
            rate_limited=False,
            soft_block=False,
            retry_after=None,
            login_wall=False,
            status_code=200,
            redirect_chain=[],
            protection_signals={},
            api_detected=False,
            api_endpoints=[],
            graphql_detected=False,
            api_auth_required=False,
            cloudflare_level="none",
            can_use_simple_request=True,
            can_use_extract_html=True,
            can_use_browser=True,
            recommended_strategy="simple",
            proxy_recommended=False,
            proxy_type="none",
        )
        assert r.recommended_strategy == "simple"
        assert r.javascript_detected is True


class TestViabilityRunPublic:
    def test_in_progress(self):
        run = ViabilityRunPublic(run_id="v1", status="in_progress", total_urls=3)
        assert run.completed_urls == 0
        assert run.results is None

    def test_completed(self):
        run = ViabilityRunPublic(run_id="v1", status="completed", total_urls=1, results=[])
        assert run.status == "completed"


# ---------------------------------------------------------------------------
# Proxy Endpoint Models
# ---------------------------------------------------------------------------

class TestCountryRequest:
    def test_defaults(self):
        req = CountryRequest(country_code="US")
        assert req.reason == ""

    def test_with_reason(self):
        req = CountryRequest(country_code="BR", reason="Need BR pricing")
        assert req.reason == "Need BR pricing"
