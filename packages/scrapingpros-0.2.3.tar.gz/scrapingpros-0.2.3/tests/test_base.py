"""Tests for shared base logic: error mapping, header parsing, retry config."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from scrapingpros._base import (
    RateLimitInfo,
    RetryConfig,
    map_error,
    parse_rate_limit_headers,
    resolve_token,
)
from scrapingpros.exceptions import (
    APIError,
    AuthenticationError,
    CountryProxyNotApproved,
    QuotaExceededError,
    RateLimitError,
    URLBlockedError,
    ValidationError,
)


# ---------------------------------------------------------------------------
# resolve_token
# ---------------------------------------------------------------------------

class TestResolveToken:
    def test_explicit_token(self):
        assert resolve_token("my-token") == "my-token"

    def test_env_var_fallback(self):
        with patch.dict(os.environ, {"SP_TOKEN": "env-token"}):
            assert resolve_token(None) == "env-token"

    def test_explicit_takes_precedence(self):
        with patch.dict(os.environ, {"SP_TOKEN": "env-token"}):
            assert resolve_token("explicit") == "explicit"

    def test_no_token_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("SP_TOKEN", None)
            with pytest.raises(AuthenticationError) as exc_info:
                resolve_token(None)
            assert "SP_TOKEN" in str(exc_info.value)

    def test_empty_string_raises(self):
        with pytest.raises(AuthenticationError):
            resolve_token("")

    def test_whitespace_only_raises(self):
        with pytest.raises(AuthenticationError):
            resolve_token("   ")

    def test_empty_env_var_raises(self):
        with patch.dict(os.environ, {"SP_TOKEN": ""}):
            with pytest.raises(AuthenticationError):
                resolve_token(None)

    def test_whitespace_env_var_raises(self):
        with patch.dict(os.environ, {"SP_TOKEN": "  "}):
            with pytest.raises(AuthenticationError):
                resolve_token(None)


# ---------------------------------------------------------------------------
# parse_rate_limit_headers
# ---------------------------------------------------------------------------

class TestParseRateLimitHeaders:
    def test_none_headers(self):
        info = parse_rate_limit_headers(None)
        assert info.rate_limit_remaining is None
        assert info.quota_remaining is None

    def test_full_headers(self):
        headers = {
            "X-RateLimit-Limit": "200",
            "X-RateLimit-Remaining": "185",
            "X-RateLimit-Reset": "1775401200",
            "X-Quota-Limit": "0",
            "X-Quota-Used": "1523",
            "X-Quota-Remaining": "8477",
        }
        info = parse_rate_limit_headers(headers)
        assert info.rate_limit_limit == 200
        assert info.rate_limit_remaining == 185
        assert info.rate_limit_reset == 1775401200
        assert info.quota_limit == 0
        assert info.quota_used == 1523
        assert info.quota_remaining == 8477

    def test_unlimited_quota(self):
        headers = {"X-Quota-Remaining": "unlimited"}
        info = parse_rate_limit_headers(headers)
        assert info.quota_remaining == "unlimited"

    def test_missing_headers(self):
        info = parse_rate_limit_headers({})
        assert info.rate_limit_limit is None

    def test_invalid_values(self):
        headers = {"X-RateLimit-Limit": "not-a-number"}
        info = parse_rate_limit_headers(headers)
        assert info.rate_limit_limit is None


# ---------------------------------------------------------------------------
# map_error
# ---------------------------------------------------------------------------

class TestMapError:
    def test_401(self):
        err = map_error(401, "Invalid token")
        assert isinstance(err, AuthenticationError)
        assert err.status_code == 401

    def test_403(self):
        err = map_error(403, "Country proxy not approved")
        assert isinstance(err, CountryProxyNotApproved)

    def test_422_ssrf(self):
        err = map_error(422, "URL blocked by SSRF protection")
        assert isinstance(err, URLBlockedError)

    def test_422_ssrf_lowercase(self):
        err = map_error(422, "blocked url detected")
        assert isinstance(err, URLBlockedError)

    def test_422_validation(self):
        err = map_error(422, "Field 'url' is required")
        assert isinstance(err, ValidationError)

    def test_429_rate_limit(self):
        err = map_error(429, "Rate limit exceeded", headers={"Retry-After": "30"})
        assert isinstance(err, RateLimitError)
        assert err.retry_after == 30

    def test_429_rate_limit_no_header(self):
        err = map_error(429, "Too many requests")
        assert isinstance(err, RateLimitError)
        assert err.retry_after is None

    def test_429_quota(self):
        err = map_error(429, "Monthly quota exceeded")
        assert isinstance(err, QuotaExceededError)

    def test_500(self):
        err = map_error(500, "Internal Server Error")
        assert isinstance(err, APIError)
        assert err.status_code == 500

    def test_502(self):
        err = map_error(502, "Bad Gateway")
        assert isinstance(err, APIError)


# ---------------------------------------------------------------------------
# RetryConfig
# ---------------------------------------------------------------------------

class TestRetryConfig:
    def test_defaults(self):
        cfg = RetryConfig()
        assert cfg.max_retries == 3
        assert cfg.backoff_base == 0.5
        assert cfg.max_backoff == 60.0

    def test_delay_exponential_backoff_with_jitter(self):
        cfg = RetryConfig(backoff_base=1.0)
        # With jitter (0.75-1.0), delay at attempt 0 should be 0.75-1.0
        delay = cfg.delay_for_attempt(0)
        assert 0.75 <= delay <= 1.0

        delay = cfg.delay_for_attempt(1)
        assert 1.5 <= delay <= 2.0  # 2.0 * [0.75, 1.0]

    def test_delay_capped_at_max(self):
        cfg = RetryConfig(backoff_base=1.0, max_backoff=5.0)
        delay = cfg.delay_for_attempt(10)
        assert delay <= 5.0

    def test_retry_after_takes_precedence(self):
        cfg = RetryConfig()
        delay = cfg.delay_for_attempt(0, retry_after=15)
        assert 11.25 <= delay <= 15.0  # 15 * [0.75, 1.0]

    def test_retry_after_capped(self):
        cfg = RetryConfig(max_backoff=10.0)
        delay = cfg.delay_for_attempt(0, retry_after=30)
        assert delay <= 10.0

    def test_retry_after_zero_falls_back(self):
        cfg = RetryConfig(backoff_base=2.0)
        delay = cfg.delay_for_attempt(1, retry_after=0)
        assert 3.0 <= delay <= 4.0  # 4.0 * [0.75, 1.0]
