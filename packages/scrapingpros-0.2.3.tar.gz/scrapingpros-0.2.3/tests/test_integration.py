"""Integration tests against the real Scraping Pros API.

These tests are SKIPPED unless the SP_TOKEN environment variable is set.

Run manually:
    SP_TOKEN=your_token pytest tests/test_integration.py -v
"""

from __future__ import annotations

import os

import pytest

from scrapingpros import ScrapingPros, AsyncScrapingPros

SP_TOKEN = os.environ.get("SP_TOKEN")
SP_FREE_TOKEN = os.environ.get("SP_FREE_TOKEN")

skip_no_token = pytest.mark.skipif(
    SP_TOKEN is None,
    reason="SP_TOKEN not set — skipping integration tests",
)


@pytest.fixture
def client():
    c = ScrapingPros(SP_TOKEN)
    yield c
    c.close()


@pytest.fixture
async def async_client():
    c = AsyncScrapingPros(SP_TOKEN)
    yield c
    await c.close()


# ---------------------------------------------------------------------------
# Health (no auth required, always runs if token available)
# ---------------------------------------------------------------------------

@skip_no_token
class TestHealth:
    def test_health(self, client: ScrapingPros):
        result = client.health()
        assert "status" in result or isinstance(result, dict)


# ---------------------------------------------------------------------------
# Sync Scrape
# ---------------------------------------------------------------------------

@skip_no_token
class TestScrapeIntegration:
    def test_html(self, client: ScrapingPros):
        result = client.scrape("https://example.com")
        assert result.statusCode == 200
        assert result.html is not None
        assert "Example Domain" in result.html

    def test_markdown(self, client: ScrapingPros):
        result = client.scrape("https://example.com", format="markdown")
        assert result.statusCode == 200
        assert result.markdown is not None
        assert "Example Domain" in result.markdown
        assert result.html is None

    def test_extraction(self, client: ScrapingPros):
        result = client.scrape(
            "https://example.com",
            extract={"title": "css:h1"},
        )
        assert result.extracted_data is not None
        assert "title" in result.extracted_data

    def test_browser(self, client: ScrapingPros):
        result = client.scrape("https://example.com", browser=True)
        assert result.statusCode == 200
        assert result.html is not None

    def test_rate_limit_headers_populated(self, client: ScrapingPros):
        client.scrape("https://example.com")
        # After a call, rate limit info should be populated
        assert client.rate_limit_remaining is not None or client.quota_remaining is not None


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

@skip_no_token
class TestDownloadIntegration:
    def test_download_pdf(self, client: ScrapingPros):
        # Use a real file URL; example.com is HTML, not a downloadable file
        result = client.download(
            "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"
        )
        assert result.statusCode == 200
        assert result.contentType is not None


# ---------------------------------------------------------------------------
# Billing / Metrics
# ---------------------------------------------------------------------------

@skip_no_token
class TestBillingIntegration:
    def test_billing(self, client: ScrapingPros):
        result = client.billing()
        assert result.month is not None
        assert result.credit_system is not None

    def test_client_metrics(self, client: ScrapingPros):
        result = client.client_metrics()
        assert result is not None


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@skip_no_token
class TestProxyIntegration:
    def test_list_countries(self, client: ScrapingPros):
        result = client.list_proxy_countries()
        assert result is not None

    def test_proxy_status(self, client: ScrapingPros):
        result = client.proxy_status()
        assert result is not None


# ---------------------------------------------------------------------------
# Guidance
# ---------------------------------------------------------------------------

@skip_no_token
class TestGuidanceIntegration:
    def test_guidance_present_on_success(self, client: ScrapingPros):
        result = client.scrape("https://example.com")
        assert result.guidance is not None
        assert result.guidance.success is True
        assert result.guidance.credits_charged is not None

    def test_guidance_on_browser(self, client: ScrapingPros):
        result = client.scrape("https://example.com", browser=True)
        assert result.guidance is not None
        assert result.guidance.success is True


# ---------------------------------------------------------------------------
# New Features: stealth, blocking, scrape_many
# ---------------------------------------------------------------------------

@skip_no_token
class TestNewFeaturesIntegration:
    def test_browser_type_light_default(self, client: ScrapingPros):
        result = client.scrape("https://example.com", browser=True)
        assert result.statusCode == 200
        assert result.html is not None

    def test_browser_type_stealth(self, client: ScrapingPros):
        result = client.scrape("https://example.com", browser=True, browser_type="stealth")
        assert result.statusCode == 200
        assert result.html is not None

    def test_block_resources(self, client: ScrapingPros):
        result = client.scrape(
            "https://example.com",
            browser=True,
            block_resources=["image", "font", "media"],
        )
        assert result.statusCode == 200

    def test_block_requests(self, client: ScrapingPros):
        result = client.scrape(
            "https://example.com",
            browser=True,
            block_requests=["google-analytics", "doubleclick"],
        )
        assert result.statusCode == 200

    def test_scrape_many(self, client: ScrapingPros):
        urls = ["https://example.com", "https://quotes.toscrape.com/"]
        results = client.scrape_many(urls, format="markdown", max_concurrent=2)
        assert len(results) == 2
        assert all(not isinstance(r, Exception) for r in results)
        for r in results:
            assert r.content is not None
            assert len(r.content) > 50


# ---------------------------------------------------------------------------
# Async Client
# ---------------------------------------------------------------------------

@skip_no_token
class TestAsyncIntegration:
    @pytest.mark.asyncio
    async def test_scrape(self, async_client: AsyncScrapingPros):
        result = await async_client.scrape("https://example.com")
        assert result.statusCode == 200
        assert "Example Domain" in result.html

    @pytest.mark.asyncio
    async def test_markdown(self, async_client: AsyncScrapingPros):
        result = await async_client.scrape("https://example.com", format="markdown")
        assert "Example Domain" in result.markdown
