"""Unit tests for the sync ScrapingPros client (mocked HTTP)."""

from __future__ import annotations

import pytest
import httpx
from pytest_httpx import HTTPXMock

from scrapingpros.client import ScrapingPros
from scrapingpros.exceptions import (
    AuthenticationError,
    ConnectionError,
    RateLimitError,
    URLBlockedError,
    ValidationError,
    APIError,
    QuotaExceededError,
)

BASE = "https://mock-api.scrapingpros.com"
TOKEN = "test-token"


@pytest.fixture
def client():
    c = ScrapingPros(TOKEN, base_url=BASE)
    yield c
    c.close()


# ---------------------------------------------------------------------------
# Scrape
# ---------------------------------------------------------------------------

class TestScrape:
    def test_simple_html(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>Hello</h1>", "statusCode": 200, "message": "OK"},
        )
        result = client.scrape("https://example.com")
        assert result.html == "<h1>Hello</h1>"
        assert result.statusCode == 200
        assert result.markdown is None

    def test_markdown_format(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"markdown": "# Hello", "statusCode": 200, "message": "OK"},
        )
        result = client.scrape("https://example.com", format="markdown")
        assert result.markdown == "# Hello"
        assert result.html is None

    def test_with_browser(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>JS</h1>", "statusCode": 200, "message": "OK"},
        )
        result = client.scrape("https://spa.com", browser=True, browser_type="light")
        assert result.html is not None

        # Verify the request body
        request = httpx_mock.get_requests()[0]
        body = request.content.decode()
        assert '"browser": true' in body or '"browser":true' in body

    def test_with_extraction(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={
                "html": "<h1>Hi</h1>",
                "statusCode": 200,
                "message": "OK",
                "extracted_data": {"title": "Hi"},
            },
        )
        result = client.scrape(
            "https://example.com",
            extract={"title": "css:h1"},
        )
        assert result.extracted_data == {"title": "Hi"}

    def test_full_response_fields(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={
                "html": "<h1>Hi</h1>",
                "statusCode": 200,
                "message": "OK",
                "executionTime": 1.5,
                "potentiallyBlockedByCaptcha": False,
                "timings": {"queue_wait_ms": 10},
                "evaluate_results": ["title"],
                "network_requests": [{"url": "https://api.com"}],
            },
        )
        result = client.scrape("https://example.com")
        assert result.executionTime == 1.5
        assert result.potentiallyBlockedByCaptcha is False
        assert result.timings["queue_wait_ms"] == 10

    def test_stealth_browser_type(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        client.scrape("https://example.com", browser=True, browser_type="stealth")
        body = httpx_mock.get_requests()[0].content.decode()
        assert '"browser_type": "stealth"' in body or '"browser_type":"stealth"' in body

    def test_block_resources(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        client.scrape(
            "https://example.com",
            browser=True,
            block_resources=["image", "font", "media"],
        )
        body = httpx_mock.get_requests()[0].content.decode()
        assert "block_resources" in body
        assert "image" in body
        assert "font" in body

    def test_block_requests(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        client.scrape(
            "https://example.com",
            browser=True,
            block_requests=["google-analytics", "doubleclick"],
        )
        body = httpx_mock.get_requests()[0].content.decode()
        assert "block_requests" in body
        assert "google-analytics" in body

    def test_block_params_excluded_when_none(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        client.scrape("https://example.com")
        body = httpx_mock.get_requests()[0].content.decode()
        assert "block_resources" not in body
        assert "block_requests" not in body

    def test_default_browser_type_is_light(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        client.scrape("https://example.com", browser=True)
        body = httpx_mock.get_requests()[0].content.decode()
        assert '"browser_type": "light"' in body or '"browser_type":"light"' in body

    def test_guidance_in_response(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={
                "html": None,
                "statusCode": 403,
                "message": "Blocked",
                "guidance": {
                    "success": False,
                    "error_type": "captcha",
                    "error_provider": "cloudflare",
                    "credits_charged": 0,
                    "credits_refunded": True,
                    "next_steps": ["Try with browser=true"],
                    "suggested_request": {"url": "https://example.com", "browser": True},
                    "stop_reason": None,
                },
            },
        )
        result = client.scrape("https://example.com")
        assert result.guidance is not None
        assert result.guidance.success is False
        assert result.guidance.error_type == "captcha"
        assert result.guidance.error_provider == "cloudflare"
        assert result.guidance.credits_refunded is True
        assert result.guidance.next_steps == ["Try with browser=true"]
        assert result.guidance.suggested_request == {"url": "https://example.com", "browser": True}


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

class TestScrapeMany:
    def test_scrape_many_returns_ordered(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        for i in range(3):
            httpx_mock.add_response(
                url=f"{BASE}/v1/sync/scrape",
                json={"html": f"<h1>Page {i}</h1>", "statusCode": 200, "message": "OK"},
            )
        results = client.scrape_many(
            ["https://example.com/1", "https://example.com/2", "https://example.com/3"],
            max_concurrent=2,
            format="html",
        )
        assert len(results) == 3
        assert all(not isinstance(r, Exception) for r in results)

    def test_scrape_many_handles_errors(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=401,
            text="Invalid token",
        )
        results = client.scrape_many(
            ["https://example.com/1", "https://example.com/2"],
            max_concurrent=1,
            format="html",
        )
        assert len(results) == 2
        # One should be a response, one should be an exception
        types = {type(r).__name__ for r in results}
        assert "ScrapeResponse" in types or "AuthenticationError" in types


class TestDownload:
    def test_basic(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/download",
            json={
                "content": "base64data",
                "contentType": "application/pdf",
                "statusCode": 200,
                "message": "OK",
            },
        )
        result = client.download("https://example.com/file.pdf")
        assert result.content == "base64data"
        assert result.contentType == "application/pdf"


# ---------------------------------------------------------------------------
# Collections
# ---------------------------------------------------------------------------

class TestCollections:
    def test_create(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections",
            json={"id": "c1", "name": "batch", "message": "Created"},
        )
        col = client.create_collection("batch", [{"url": "https://example.com"}])
        assert col.id == "c1"

    def test_list(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections",
            json=[{"id": "c1", "name": "batch1"}, {"id": "c2", "name": "batch2"}],
        )
        cols = client.list_collections()
        assert len(cols) == 2
        assert cols[0].name == "batch1"

    def test_get(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1",
            json={"id": "c1", "name": "batch"},
        )
        col = client.get_collection("c1")
        assert col.id == "c1"

    def test_update(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1",
            json={"id": "c1", "name": "updated", "message": "Updated"},
        )
        col = client.update_collection("c1", "updated")
        assert col.name == "updated"


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------

class TestRuns:
    def test_create_run(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/run",
            json={
                "run_id": "r1",
                "collection_id": "c1",
                "status": "in_progress",
            },
        )
        run = client.create_run("c1")
        assert run.run_id == "r1"
        assert run.status == "in_progress"

    def test_get_run(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/runs/r1",
            json={
                "run_id": "r1",
                "collection_id": "c1",
                "status": "completed",
                "total_requests": 5,
                "success_requests": 4,
                "failed_requests": 1,
            },
        )
        run = client.get_run("c1", "r1")
        assert run.status == "completed"
        assert run.success_requests == 4

    def test_get_run_jobs(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/runs/r1/jobs",
            json={
                "items": [
                    {
                        "job_public_id": "j1",
                        "run_public_id": "r1",
                        "collection_id": "c1",
                        "status": "completed",
                        "status_code": 200,
                    }
                ]
            },
        )
        jobs = client.get_run_jobs("c1", "r1")
        assert len(jobs.items) == 1
        assert jobs.items[0].status == "completed"

    def test_run_and_wait(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        # First: create_run
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/run",
            json={"run_id": "r1", "collection_id": "c1", "status": "in_progress"},
        )
        # Second: get_run (still in progress)
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/runs/r1",
            json={"run_id": "r1", "collection_id": "c1", "status": "in_progress"},
        )
        # Third: get_run (completed)
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/runs/r1",
            json={
                "run_id": "r1",
                "collection_id": "c1",
                "status": "completed",
                "total_requests": 2,
                "success_requests": 2,
            },
        )
        run = client.run_and_wait("c1", poll_interval=0.01, timeout=5)
        assert run.status == "completed"
        assert run.success_requests == 2


# ---------------------------------------------------------------------------
# Viability Test
# ---------------------------------------------------------------------------

class TestViabilityTest:
    def test_create(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/viability-test",
            json={"run_id": "vt1", "status": "in_progress", "total_urls": 1},
        )
        test = client.create_viability_test(["https://example.com"])
        assert test.run_id == "vt1"

    def test_get(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/viability-test/vt1",
            json={
                "run_id": "vt1",
                "status": "completed",
                "total_urls": 1,
                "completed_urls": 1,
                "results": [],
            },
        )
        result = client.get_viability_test("vt1")
        assert result.status == "completed"


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

class TestProxy:
    def test_list_countries(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/proxy/countries",
            json={"countries": ["US", "BR", "AR"]},
        )
        result = client.list_proxy_countries()
        assert "US" in result.countries
        assert len(result.countries) == 3

    def test_request_country(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/proxy/request-country",
            json={"status": "pending", "country_code": "US", "message": "Request submitted"},
        )
        result = client.request_proxy_country("US", reason="testing")
        assert result.status == "pending"
        assert result.country_code == "US"

    def test_proxy_status(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/proxy/status",
            json={"client_id": "c1", "approved_countries": ["US"], "pending_countries": ["BR"]},
        )
        result = client.proxy_status()
        assert "US" in result.approved_countries
        assert "BR" in result.pending_countries


# ---------------------------------------------------------------------------
# Billing & Metrics
# ---------------------------------------------------------------------------

class TestPlans:
    def test_plans(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/plans",
            json={"plans": [{"name": "free", "credits": 500}]},
        )
        result = client.plans()
        assert "plans" in result


class TestDeleteCollection:
    def test_delete(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1",
            method="DELETE",
            json={},
        )
        client.delete_collection("c1")
        assert len(httpx_mock.get_requests()) == 1
        assert httpx_mock.get_requests()[0].method == "DELETE"


class TestGetJobResult:
    def test_get_result(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/runs/r1/jobs/j1/result",
            json={"html": "<h1>Product</h1>", "statusCode": 200, "message": "OK"},
        )
        result = client.get_job_result("c1", "r1", "j1")
        assert result.html == "<h1>Product</h1>"
        assert result.statusCode == 200


class TestBillingMetrics:
    def test_billing(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=httpx.URL(f"{BASE}/v1/sync/billing", params={"month": "2026-04"}),
            json={
                "month": "2026-04",
                "clients": {
                    "test-client": {
                        "simple_success": 80,
                        "browser_success": 20,
                        "total_requests": 100,
                        "credits": {"simple": 80, "browser": 100, "total": 180},
                    }
                },
                "credit_system": {"simple_request": 1, "browser_request": 5},
            },
        )
        result = client.billing(month="2026-04")
        assert result.month == "2026-04"
        assert result.clients["test-client"].total_requests == 100
        assert result.clients["test-client"].credits.total == 180
        assert result.credit_system.browser_request == 5

    def test_metrics(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/metrics",
            json={"data": []},
        )
        result = client.metrics()
        assert "data" in result

    def test_client_metrics(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=httpx.URL(f"{BASE}/v1/sync/client-metrics", params={"date": "2026-04"}),
            json={"date": "2026-04", "scrape_type": {"simple": 40, "browser": 10}},
        )
        result = client.client_metrics(date="2026-04")
        assert result.date == "2026-04"
        assert result.scrape_type["simple"] == 40


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

class TestHealth:
    def test_health(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/health",
            json={"status": "ok"},
        )
        result = client.health()
        assert result["status"] == "ok"


# ---------------------------------------------------------------------------
# Error Handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_401_raises_auth_error(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=401,
            text="Invalid token",
        )
        with pytest.raises(AuthenticationError) as exc_info:
            client.scrape("https://example.com")
        assert exc_info.value.status_code == 401

    def test_422_ssrf_raises(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=422,
            text="URL blocked by SSRF protection",
        )
        with pytest.raises(URLBlockedError):
            client.scrape("http://localhost:6379")

    def test_422_validation_raises(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=422,
            text="Invalid parameters",
        )
        with pytest.raises(ValidationError):
            client.scrape("https://example.com")

    def test_empty_url_raises_client_side(self, client: ScrapingPros):
        with pytest.raises(Exception, match="URL cannot be empty"):
            client.scrape("")

    def test_500_raises_after_retries(self, httpx_mock: HTTPXMock):
        """500 retries then raises after all attempts exhausted."""
        c = ScrapingPros(TOKEN, base_url=BASE, max_retries=1)
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=500,
            text="Internal Server Error",
        )
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=500,
            text="Internal Server Error",
        )
        with pytest.raises(APIError) as exc_info:
            c.scrape("https://example.com")
        assert exc_info.value.status_code == 500
        c.close()


# ---------------------------------------------------------------------------
# Retry Logic
# ---------------------------------------------------------------------------

class TestRetryLogic:
    def test_429_retries_then_succeeds(self, httpx_mock: HTTPXMock):
        c = ScrapingPros(TOKEN, base_url=BASE, max_retries=2)
        # First: 429
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=429,
            text="Rate limit exceeded",
            headers={"Retry-After": "0"},
        )
        # Second: success
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        result = c.scrape("https://example.com")
        assert result.html == "<h1>OK</h1>"
        assert len(httpx_mock.get_requests()) == 2
        c.close()

    def test_429_exhausts_retries(self, httpx_mock: HTTPXMock):
        c = ScrapingPros(TOKEN, base_url=BASE, max_retries=1)
        # Two 429s (exceeds max_retries=1)
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=429,
            text="Rate limit exceeded",
            headers={"Retry-After": "0"},
        )
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=429,
            text="Rate limit exceeded",
            headers={"Retry-After": "0"},
        )
        with pytest.raises(RateLimitError):
            c.scrape("https://example.com")
        c.close()

    def test_quota_exceeded_no_retry(self, httpx_mock: HTTPXMock):
        """Quota errors should raise immediately without retrying."""
        c = ScrapingPros(TOKEN, base_url=BASE, max_retries=3)
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=429,
            text="Monthly quota exceeded",
        )
        with pytest.raises(QuotaExceededError):
            c.scrape("https://example.com")
        # Only 1 request should have been made (no retries)
        assert len(httpx_mock.get_requests()) == 1
        c.close()

    def test_500_retries_then_succeeds(self, httpx_mock: HTTPXMock):
        """Server errors (5xx) should be retried automatically."""
        c = ScrapingPros(TOKEN, base_url=BASE, max_retries=2)
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            status_code=500,
            text="Internal Server Error",
        )
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>OK</h1>", "statusCode": 200, "message": "OK"},
        )
        result = c.scrape("https://example.com")
        assert result.html == "<h1>OK</h1>"
        assert len(httpx_mock.get_requests()) == 2
        c.close()

    def test_connection_error_wrapped(self, httpx_mock: HTTPXMock):
        """Network errors should be wrapped in ConnectionError."""
        c = ScrapingPros(TOKEN, base_url=BASE, max_retries=0)
        httpx_mock.add_exception(
            httpx.ConnectError("Connection refused"),
            url=f"{BASE}/v1/sync/scrape",
        )
        with pytest.raises(ConnectionError) as exc_info:
            c.scrape("https://example.com")
        assert "Connection refused" in str(exc_info.value)
        c.close()


# ---------------------------------------------------------------------------
# Rate Limit Properties
# ---------------------------------------------------------------------------

class TestRateLimitProperties:
    def test_initial_none(self):
        c = ScrapingPros(TOKEN, base_url=BASE)
        assert c.rate_limit_remaining is None
        assert c.quota_remaining is None
        c.close()

    def test_updated_after_call(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>Hi</h1>", "statusCode": 200, "message": "OK"},
            headers={
                "X-RateLimit-Remaining": "185",
                "X-Quota-Remaining": "8477",
            },
        )
        client.scrape("https://example.com")
        assert client.rate_limit_remaining == 185
        assert client.quota_remaining == 8477


# ---------------------------------------------------------------------------
# Context Manager
# ---------------------------------------------------------------------------

class TestContextManager:
    def test_with_statement(self, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            url=f"{BASE}/v1/sync/scrape",
            json={"html": "<h1>Hi</h1>", "statusCode": 200, "message": "OK"},
        )
        with ScrapingPros(TOKEN, base_url=BASE) as client:
            result = client.scrape("https://example.com")
            assert result.html == "<h1>Hi</h1>"
