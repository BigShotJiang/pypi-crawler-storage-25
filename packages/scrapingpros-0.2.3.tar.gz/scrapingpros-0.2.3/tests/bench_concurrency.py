"""Benchmark: sequential vs scrape_many at different concurrency levels.

Runs all 5 tests in parallel threads so results come in as they finish.

Usage:
    python tests/bench_concurrency.py TOKEN
"""

import sys
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from scrapingpros import ScrapingPros

URLS = [
    "https://example.com",
    "https://news.ycombinator.com",
    "https://quotes.toscrape.com/",
    "https://httpbin.org/html",
    "https://jsonplaceholder.typicode.com/posts",
    "https://en.wikipedia.org/wiki/Web_scraping",
    "https://www.python.org",
    "https://docs.python.org/3/",
    "https://www.rust-lang.org",
    "https://go.dev",
    "https://en.wikipedia.org/wiki/Python_(programming_language)",
    "https://en.wikipedia.org/wiki/JavaScript",
    "https://en.wikipedia.org/wiki/Rust_(programming_language)",
    "https://en.wikipedia.org/wiki/Go_(programming_language)",
    "https://en.wikipedia.org/wiki/TypeScript",
    "https://en.wikipedia.org/wiki/Java_(programming_language)",
    "https://en.wikipedia.org/wiki/C_Sharp_(programming_language)",
    "https://en.wikipedia.org/wiki/Ruby_(programming_language)",
    "https://en.wikipedia.org/wiki/PHP",
    "https://en.wikipedia.org/wiki/Swift_(programming_language)",
    "https://quotes.toscrape.com/page/2/",
    "https://quotes.toscrape.com/page/3/",
    "https://quotes.toscrape.com/page/4/",
    "https://quotes.toscrape.com/page/5/",
    "https://quotes.toscrape.com/page/6/",
    "https://quotes.toscrape.com/page/7/",
    "https://quotes.toscrape.com/page/8/",
    "https://quotes.toscrape.com/page/9/",
    "https://quotes.toscrape.com/page/10/",
    "https://quotes.toscrape.com/tag/love/",
    "https://httpbin.org/get",
    "https://httpbin.org/ip",
    "https://httpbin.org/user-agent",
    "https://httpbin.org/headers",
    "https://httpbin.org/response-headers?Content-Type=text/plain",
    "https://jsonplaceholder.typicode.com/users",
    "https://jsonplaceholder.typicode.com/comments",
    "https://jsonplaceholder.typicode.com/albums",
    "https://jsonplaceholder.typicode.com/todos",
    "https://jsonplaceholder.typicode.com/photos",
    "https://en.wikipedia.org/wiki/Kotlin_(programming_language)",
    "https://en.wikipedia.org/wiki/Scala_(programming_language)",
    "https://en.wikipedia.org/wiki/Haskell_(programming_language)",
    "https://en.wikipedia.org/wiki/Perl",
    "https://en.wikipedia.org/wiki/Lua_(programming_language)",
    "https://en.wikipedia.org/wiki/Julia_(programming_language)",
    "https://en.wikipedia.org/wiki/Elixir_(programming_language)",
    "https://en.wikipedia.org/wiki/Dart_(programming_language)",
    "https://en.wikipedia.org/wiki/R_(programming_language)",
    "https://en.wikipedia.org/wiki/MATLAB",
]

# Thread-safe print
_print_lock = threading.Lock()
_global_start = None


def log(tag, msg):
    elapsed = time.time() - _global_start
    with _print_lock:
        print("[%6.1fs] [%-12s] %s" % (elapsed, tag, msg))
        sys.stdout.flush()


def run_sequential(token):
    """Sequential: one request at a time."""
    tag = "seq"
    log(tag, "Starting — 50 URLs, 1 at a time")
    client = ScrapingPros(token)
    start = time.time()
    ok = 0
    err = 0
    for i, url in enumerate(URLS):
        try:
            r = client.scrape(url, format="markdown", browser=True)
            if len(r.content or "") > 100:
                ok += 1
                status = "OK"
            else:
                err += 1
                status = "THIN"
        except Exception as e:
            err += 1
            status = "ERR"
        if (i + 1) % 10 == 0:
            log(tag, "%d/50 done (%d OK, %d err)" % (i + 1, ok, err))
    elapsed = time.time() - start
    client.close()
    log(tag, "FINISHED — %d/50 OK, %d errors, %.1fs" % (ok, err, elapsed))
    return "sequential", elapsed, ok, err


def run_parallel(token, concurrency):
    """scrape_many with explicit max_concurrent."""
    tag = "par-%d" % concurrency
    log(tag, "Starting — 50 URLs, %d concurrent" % concurrency)
    client = ScrapingPros(token)
    start = time.time()
    results = client.scrape_many(URLS, format="markdown", browser=True, max_concurrent=concurrency)
    elapsed = time.time() - start
    ok = 0
    err = 0
    for r in results:
        if isinstance(r, Exception):
            err += 1
        elif len(getattr(r, "content", None) or "") > 100:
            ok += 1
        else:
            err += 1
    client.close()
    log(tag, "FINISHED — %d/50 OK, %d errors, %.1fs" % (ok, err, elapsed))
    return "parallel_%d" % concurrency, elapsed, ok, err


def main():
    global _global_start

    if len(sys.argv) < 2:
        print("Usage: python tests/bench_concurrency.py TOKEN")
        sys.exit(1)

    token = sys.argv[1]

    print("=" * 65)
    print("  CONCURRENCY BENCHMARK")
    print("  50 URLs | browser=True | use_proxy=any")
    print("  Tests: sequential, parallel x5, x10, x25, x50")
    print("  All running simultaneously — results stream as they finish")
    print("=" * 65)
    print()
    sys.stdout.flush()

    _global_start = time.time()
    results = {}

    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {
            pool.submit(run_sequential, token): "sequential",
            pool.submit(run_parallel, token, 5): "parallel_5",
            pool.submit(run_parallel, token, 10): "parallel_10",
            pool.submit(run_parallel, token, 25): "parallel_25",
            pool.submit(run_parallel, token, 50): "parallel_50",
        }

        for future in as_completed(futures):
            try:
                label, elapsed, ok, err = future.result()
                results[label] = (elapsed, ok, err)
            except Exception as e:
                name = futures[future]
                log(name, "FAILED — %s" % e)

    total_elapsed = time.time() - _global_start

    # Summary table
    seq_time = results.get("sequential", (1, 0, 0))[0]
    print()
    print("=" * 65)
    print("  RESULTS SUMMARY (total wall time: %.1fs)" % total_elapsed)
    print("=" * 65)
    print("  %-20s %10s %10s %8s %8s" % ("Mode", "Time", "Speedup", "OK", "Errors"))
    print("  " + "-" * 61)
    for label in ["sequential", "parallel_5", "parallel_10", "parallel_25", "parallel_50"]:
        if label in results:
            t, ok, err = results[label]
            speedup = seq_time / t if t > 0 else 0
            print("  %-20s %9.1fs %9.1fx %7d %7d" % (label, t, speedup, ok, err))
    print("=" * 65)


if __name__ == "__main__":
    main()
