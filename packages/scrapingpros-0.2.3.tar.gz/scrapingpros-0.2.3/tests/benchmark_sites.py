"""Benchmark 50 sites across difficulty levels.

Usage:
    python tests/benchmark_sites.py [--mode standard|browser|viability]

Tests scraping success rate, timing, and CAPTCHA detection across
sites categorized by expected difficulty.
"""

import argparse
import csv
import json
import sys
import time
from datetime import datetime

from scrapingpros import ScrapingPros, DEMO_TOKEN


SITES = {
    # --- EASY: No protection, static HTML ---
    "easy": [
        ("https://example.com", "Example.com"),
        ("https://news.ycombinator.com", "Hacker News"),
        ("https://quotes.toscrape.com/", "Quotes Test"),
        ("https://httpbin.org/html", "httpbin"),
        ("https://jsonplaceholder.typicode.com/posts", "JSONPlaceholder"),
        ("https://en.wikipedia.org/wiki/Web_scraping", "Wikipedia"),
        ("https://www.python.org", "Python.org"),
        ("https://docs.python.org/3/", "Python Docs"),
        ("https://www.rust-lang.org", "Rust-lang"),
        ("https://go.dev", "Go.dev"),
    ],
    # --- MEDIUM: Some protection, JS-heavy, or soft blocks ---
    "medium": [
        ("https://www.imdb.com/chart/top/", "IMDb Top 250"),
        ("https://www.rottentomatoes.com/browse/movies_at_home/sort:popular", "RottenTomatoes"),
        ("https://github.com/trending", "GitHub Trending"),
        ("https://stackoverflow.com/questions", "StackOverflow"),
        ("https://www.reddit.com/r/programming/", "Reddit Programming"),
        ("https://www.craigslist.org/about/sites", "Craigslist"),
        ("https://www.yelp.com/search?find_desc=restaurants&find_loc=New+York", "Yelp"),
        ("https://www.glassdoor.com/Job/python-developer-jobs-SRCH_KO0,16.htm", "Glassdoor"),
        ("https://www.tripadvisor.com/Hotels-g60763-New_York_City_New_York-Hotels.html", "TripAdvisor"),
        ("https://www.etsy.com/search?q=handmade", "Etsy"),
        ("https://www.goodreads.com/list/show/1.Best_Books_Ever", "Goodreads"),
        ("https://www.allrecipes.com/recipes/", "AllRecipes"),
        ("https://www.weather.com/weather/today/l/40.71,-74.01", "Weather.com"),
        ("https://www.bbc.com/news", "BBC News"),
        ("https://www.reuters.com", "Reuters"),
    ],
    # --- HARD: Strong anti-bot, CAPTCHA, headless detection ---
    "hard": [
        ("https://www.amazon.com/s?k=laptop", "Amazon Search"),
        ("https://www.walmart.com/browse/electronics/3944", "Walmart"),
        ("https://www.ebay.com/sch/i.html?_nkw=laptop", "eBay Search"),
        ("https://www.target.com/c/laptops/-/N-q3s2g", "Target"),
        ("https://www.bestbuy.com/site/searchpage.jsp?st=laptop", "BestBuy"),
        ("https://www.linkedin.com/jobs/search/?keywords=python", "LinkedIn Jobs"),
        ("https://www.indeed.com/jobs?q=python+developer", "Indeed"),
        ("https://www.zillow.com/homes/for_sale/", "Zillow"),
        ("https://www.booking.com/searchresults.html?ss=New+York", "Booking.com"),
        ("https://www.nytimes.com", "NY Times"),
        ("https://www.nike.com/w/mens-shoes-nik1zy7ok", "Nike"),
        ("https://www.zara.com/us/en/man-shoes-l769.html", "Zara"),
        ("https://www.airbnb.com/s/New-York/homes", "Airbnb"),
        ("https://www.expedia.com/Hotel-Search?destination=New+York", "Expedia"),
        ("https://www.homedepot.com/s/drill", "Home Depot"),
        ("https://www.costco.com/laptops.html", "Costco"),
        ("https://www.nordstrom.com/browse/men/clothing", "Nordstrom"),
        ("https://www.wayfair.com/furniture/sb0/sofas-c413892.html", "Wayfair"),
        ("https://www.instagram.com/explore/", "Instagram"),
        ("https://twitter.com/explore", "X/Twitter"),
        ("https://www.tiktok.com/explore", "TikTok"),
        ("https://www.facebook.com/marketplace/", "Facebook Marketplace"),
        ("https://www.ups.com/track", "UPS Tracking"),
        ("https://www.fedex.com/en-us/tracking.html", "FedEx Tracking"),
        ("https://www.google.com/maps/search/restaurants+near+me", "Google Maps"),
    ],
}


def run_standard_test(client: ScrapingPros, sites: list) -> list[dict]:
    """Test sites with standard mode (simple HTTP + proxy)."""
    results = []
    for url, label in sites:
        try:
            start = time.time()
            r = client.scrape(url, browser=False)
            elapsed = time.time() - start
            results.append({
                "url": url,
                "label": label,
                "mode": "standard",
                "time_s": round(elapsed, 1),
                "status": "BLOCKED" if r.potentiallyBlockedByCaptcha else ("OK" if len(r.content or "") > 500 else "THIN"),
                "captcha": bool(r.potentiallyBlockedByCaptcha),
                "content_len": len(r.content or ""),
                "credits": client.credits_charged or 0,
                "status_code": r.statusCode,
                "error": None,
            })
        except Exception as e:
            elapsed = time.time() - start
            results.append({
                "url": url,
                "label": label,
                "mode": "standard",
                "time_s": round(elapsed, 1),
                "status": "ERROR",
                "captcha": False,
                "content_len": 0,
                "credits": 0,
                "status_code": None,
                "error": f"{type(e).__name__}: {str(e)[:60]}",
            })
        # Print as we go
        r = results[-1]
        print(f"  {r['status']:8s} {r['time_s']:5.1f}s {r['label']:25s} {r['content_len']:>7}c {r['credits']}cr")
    return results


def run_browser_test(client: ScrapingPros, sites: list) -> list[dict]:
    """Test sites with browser + retry_on_block."""
    results = []
    for url, label in sites:
        try:
            start = time.time()
            r = client.scrape(url, browser=True, retry_on_block=True)
            elapsed = time.time() - start
            results.append({
                "url": url,
                "label": label,
                "mode": "browser+retry",
                "time_s": round(elapsed, 1),
                "status": "BLOCKED" if r.potentiallyBlockedByCaptcha else ("OK" if len(r.content or "") > 500 else "THIN"),
                "captcha": bool(r.potentiallyBlockedByCaptcha),
                "content_len": len(r.content or ""),
                "credits": client.credits_charged or 0,
                "status_code": r.statusCode,
                "error": None,
            })
        except Exception as e:
            elapsed = time.time() - start
            results.append({
                "url": url,
                "label": label,
                "mode": "browser+retry",
                "time_s": round(elapsed, 1),
                "status": "ERROR",
                "captcha": False,
                "content_len": 0,
                "credits": 0,
                "status_code": None,
                "error": f"{type(e).__name__}: {str(e)[:60]}",
            })
        r = results[-1]
        print(f"  {r['status']:8s} {r['time_s']:5.1f}s {r['label']:25s} {r['content_len']:>7}c {r['credits']}cr")
    return results


def run_stealth_test(client: ScrapingPros, sites: list) -> list[dict]:
    """Test sites with stealth browser + blocking + retry_on_block."""
    results = []
    for url, label in sites:
        try:
            start = time.time()
            r = client.scrape(
                url,
                browser=True,
                browser_type="stealth",
                retry_on_block=True,
                block_resources=["image", "font", "media"],
                block_requests=["google-analytics", "doubleclick", "googlesyndication",
                                "googletagmanager", "facebook.net", "connect.facebook"],
            )
            elapsed = time.time() - start
            results.append({
                "url": url,
                "label": label,
                "mode": "stealth+block",
                "time_s": round(elapsed, 1),
                "status": "BLOCKED" if r.potentiallyBlockedByCaptcha else ("OK" if len(r.content or "") > 500 else "THIN"),
                "captcha": bool(r.potentiallyBlockedByCaptcha),
                "content_len": len(r.content or ""),
                "credits": client.credits_charged or 0,
                "status_code": r.statusCode,
                "error": None,
            })
        except Exception as e:
            elapsed = time.time() - start
            results.append({
                "url": url,
                "label": label,
                "mode": "stealth+block",
                "time_s": round(elapsed, 1),
                "status": "ERROR",
                "captcha": False,
                "content_len": 0,
                "credits": 0,
                "status_code": None,
                "error": f"{type(e).__name__}: {str(e)[:60]}",
            })
        r = results[-1]
        print(f"  {r['status']:8s} {r['time_s']:5.1f}s {r['label']:25s} {r['content_len']:>7}c {r['credits']}cr")
    return results


def main():
    parser = argparse.ArgumentParser(description="Benchmark scraping across 50 sites")
    parser.add_argument("--mode", choices=["standard", "browser", "stealth", "both", "all"], default="standard",
                        help="Test mode: standard (simple HTTP), browser (+retry_on_block), or both")
    parser.add_argument("--difficulty", choices=["easy", "medium", "hard", "all"], default="all",
                        help="Which difficulty category to test")
    args = parser.parse_args()

    client = ScrapingPros(DEMO_TOKEN)
    print(f"ScrapingPros Benchmark — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"Mode: {args.mode}, Difficulty: {args.difficulty}")
    print(f"Quota: {client.quota_remaining or 'unknown'}")
    print()

    # Select sites
    if args.difficulty == "all":
        categories = ["easy", "medium", "hard"]
    else:
        categories = [args.difficulty]

    all_results = []

    for cat in categories:
        sites = SITES[cat]
        print(f"=== {cat.upper()} ({len(sites)} sites) ===")

        if args.mode in ("standard", "both", "all"):
            print(f"\n-- Standard mode --")
            all_results.extend(run_standard_test(client, sites))

        if args.mode in ("browser", "both", "all"):
            print(f"\n-- Browser + retry_on_block --")
            all_results.extend(run_browser_test(client, sites))

        if args.mode in ("stealth", "all"):
            print(f"\n-- Stealth + blocking + retry_on_block --")
            all_results.extend(run_stealth_test(client, sites))

        print()

    # Summary
    print(f"\n{'='*60}")
    print(f"SUMMARY")
    print(f"{'='*60}")
    ok = sum(1 for r in all_results if r["status"] == "OK")
    blocked = sum(1 for r in all_results if r["status"] == "BLOCKED")
    errors = sum(1 for r in all_results if r["status"] == "ERROR")
    thin = sum(1 for r in all_results if r["status"] == "THIN")
    total_credits = sum(r["credits"] for r in all_results)
    avg_time = sum(r["time_s"] for r in all_results) / len(all_results) if all_results else 0
    print(f"Total: {len(all_results)} tests")
    print(f"OK: {ok} | BLOCKED: {blocked} | ERROR: {errors} | THIN: {thin}")
    print(f"Success rate: {ok/len(all_results)*100:.0f}%")
    print(f"Credits used: {total_credits}")
    print(f"Avg time: {avg_time:.1f}s")
    print(f"Quota remaining: {client.quota_remaining}")

    # Save CSV
    filename = f"benchmark_{args.mode}_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_results[0].keys())
        writer.writeheader()
        writer.writerows(all_results)
    print(f"\nSaved to {filename}")

    client.close()


if __name__ == "__main__":
    main()
