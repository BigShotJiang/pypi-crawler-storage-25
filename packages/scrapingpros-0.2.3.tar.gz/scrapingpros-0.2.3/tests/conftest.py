"""Shared test fixtures for scrapingpros SDK tests."""

from __future__ import annotations

import pytest


FAKE_TOKEN = "test-token-for-unit-tests"
MOCK_BASE_URL = "https://mock-api.scrapingpros.com"


@pytest.fixture
def fake_token() -> str:
    return FAKE_TOKEN


@pytest.fixture
def mock_base_url() -> str:
    return MOCK_BASE_URL
