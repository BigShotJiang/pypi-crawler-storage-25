"""Simple HTML scrape — the most basic usage of the SDK."""

from scrapingpros import ScrapingPros

client = ScrapingPros("demo_6x595maoA6GdOdVb")  # or set SP_TOKEN env var

result = client.scrape("https://example.com")
print(f"Status: {result.statusCode}")
print(f"HTML length: {len(result.html)} chars")
print(result.html[:200])
