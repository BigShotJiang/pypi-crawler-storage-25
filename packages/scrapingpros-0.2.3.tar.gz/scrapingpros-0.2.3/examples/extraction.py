"""Structured data extraction using CSS selectors."""

from scrapingpros import ScrapingPros

client = ScrapingPros("demo_6x595maoA6GdOdVb")

result = client.scrape(
    "https://quotes.toscrape.com/",
    extract={
        "title": "css:h1",
        "quotes": {"selector": "css:.text", "multiple": True},
        "authors": {"selector": "css:.author", "multiple": True},
    },
)

print("Extracted data:")
for key, value in result.extracted_data.items():
    print(f"  {key}: {value}")
