"""Get clean markdown output — ideal for AI/LLM consumption."""

from scrapingpros import ScrapingPros

client = ScrapingPros("demo_6x595maoA6GdOdVb")

result = client.scrape("https://example.com", format="markdown")
print(result.markdown)
