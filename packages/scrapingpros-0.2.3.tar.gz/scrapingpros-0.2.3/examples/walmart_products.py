"""Real-world example: scrape Walmart product listings.

Demonstrates the recommended workflow for scraping protected sites:
1. Run a viability test to understand the target
2. Choose the right strategy based on results
3. Handle CAPTCHA detection gracefully

Usage:
    python examples/walmart_products.py
"""

import csv
import time
from scrapingpros import ScrapingPros, DEMO_TOKEN

client = ScrapingPros(DEMO_TOKEN)

URL = "https://www.walmart.com/browse/electronics/laptop-computers/3944_3951_1089430_132960"

# -----------------------------------------------------------------------
# Step 1: Viability test — understand the target before scraping
# -----------------------------------------------------------------------
print("Step 1: Running viability test...")
test = client.create_viability_test([URL])

for _ in range(30):
    result = client.get_viability_test(test.run_id)
    if result.status == "completed":
        break
    time.sleep(2)

if result.results:
    site = result.results[0]
    print(f"  Strategy: {site.recommended_strategy}")
    print(f"  CAPTCHA: {site.captcha_detected} {site.captcha_providers}")
    print(f"  Browser needed: {site.javascript_required}")
    print(f"  Proxy recommended: {site.proxy_recommended}")

    if site.captcha_detected:
        print(f"\n  ⚠ Site uses {', '.join(site.captcha_providers) or 'unknown'} CAPTCHA protection.")
        print("  The API will attempt to bypass it, but success is not guaranteed.")
        print("  For guaranteed access, contact Scraping Pros for enterprise solutions.")

# -----------------------------------------------------------------------
# Step 2: Scrape with browser + proxy (best chance against anti-bot)
# -----------------------------------------------------------------------
print("\nStep 2: Scraping with browser + proxy...")
r = client.scrape(
    URL,
    browser=True,
    extract={
        "product_names": {
            "selector": "css:span[data-automation-id='product-title']",
            "multiple": True,
        },
        "prices": {
            "selector": "css:[data-automation-id='product-price'] .f2",
            "multiple": True,
        },
    },
)

print(f"  Status: {r.statusCode}")
print(f"  Execution time: {r.executionTime}s")
print(f"  Quota remaining: {client.quota_remaining}")

# -----------------------------------------------------------------------
# Step 3: Handle results — including CAPTCHA scenarios
# -----------------------------------------------------------------------
if r.potentiallyBlockedByCaptcha:
    print(f"\n  ⚠ CAPTCHA detected — the page returned a challenge instead of products.")
    print("  What you can do:")
    print("    1. Retry — anti-bot bypass succeeds more often with multiple attempts")
    print("    2. Try browser_type='light' instead of 'heavy'")
    print("    3. Contact Scraping Pros for CAPTCHA-solving on this specific site")
    print(f"\n  Page title from HTML: {r.content[:100] if r.content else 'empty'}")

elif r.extracted_data and r.extracted_data.get("product_names"):
    names = r.extracted_data["product_names"]
    prices = r.extracted_data.get("prices", [])

    print(f"\n  Found {len(names)} products!")
    for i, name in enumerate(names[:10]):
        price = prices[i] if i < len(prices) else "N/A"
        print(f"    {i+1}. {name[:55]:55s} {price}")

    # Save to CSV
    with open("walmart_laptops.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["name", "price"])
        for name, price in zip(names, prices):
            writer.writerow([name, price])
    print(f"\n  Saved {len(names)} products to walmart_laptops.csv")

else:
    print("\n  No products extracted.")
    print("  The page loaded but the CSS selectors didn't match.")
    print("  Try using format='markdown' to see the page content:")
    print("    r = client.scrape(url, browser=True, format='markdown')")

client.close()
