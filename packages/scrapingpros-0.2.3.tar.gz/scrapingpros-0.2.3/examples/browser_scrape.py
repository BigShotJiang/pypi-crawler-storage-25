"""Browser rendering for JavaScript-heavy sites."""

from scrapingpros import ScrapingPros

client = ScrapingPros("demo_6x595maoA6GdOdVb")

# Enable headless browser for JS-rendered content
result = client.scrape(
    "https://example.com",
    browser=True,
    browser_type="heavy",  # "heavy" = Camoufox (anti-detection), "light" = Chromium
    use_proxy="any",
)

print(f"Status: {result.statusCode}")
print(f"Blocked by CAPTCHA: {result.potentiallyBlockedByCaptcha}")
if result.timings:
    print(f"Browser launch: {result.timings.get('browser_launch_ms')}ms")
