"""Async batch processing with collections and runs."""

from scrapingpros import ScrapingPros

client = ScrapingPros("demo_6x595maoA6GdOdVb")

# Create a collection of URLs
collection = client.create_collection("product-pages", [
    {"url": "https://example.com/page/1"},
    {"url": "https://example.com/page/2"},
    {"url": "https://example.com/page/3"},
])
print(f"Collection created: {collection.id}")

# Run and wait for completion
run = client.run_and_wait(collection.id, timeout=120)
print(f"Status: {run.status}")
print(f"Success: {run.success_requests}/{run.total_requests}")
print(f"Failed: {run.failed_requests}")

# Check failed jobs
for job in run.failed_jobs:
    print(f"  Failed: {job.url} — {job.error}")
