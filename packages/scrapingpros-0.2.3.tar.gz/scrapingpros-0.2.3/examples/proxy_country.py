"""Geo-targeted scraping with country-specific proxies."""

from scrapingpros import ScrapingPros

client = ScrapingPros("demo_6x595maoA6GdOdVb")

# List available proxy countries
countries = client.list_proxy_countries()
print("Available countries:", countries)

# Request access to a country (requires admin approval)
# client.request_proxy_country("US", reason="Need US pricing data")

# Once approved, use the country code in scrape calls
result = client.scrape(
    "https://example.com",
    use_proxy="any",  # or "US" once approved
)
print(f"Status: {result.statusCode}")
