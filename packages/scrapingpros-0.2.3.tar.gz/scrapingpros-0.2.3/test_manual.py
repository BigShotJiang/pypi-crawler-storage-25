"""Manual test script — run this to verify the SDK works end-to-end.

Usage:
    python test_manual.py

Uses the demo token by default. Set SP_TOKEN for your own token.
"""

import asyncio
from scrapingpros import ScrapingPros, AsyncScrapingPros, DEMO_TOKEN


def divider(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def test_sync():
    client = ScrapingPros(DEMO_TOKEN)

    # --- Simple HTML ---
    divider("1. Simple HTML scrape")
    r = client.scrape("https://example.com")
    print(f"   Status: {r.statusCode}")
    print(f"   HTML: {len(r.html)} chars")
    print(f"   Content: {r.content[:60]}...")

    # --- Markdown ---
    divider("2. Markdown output")
    r = client.scrape("https://example.com", format="markdown")
    print(f"   Markdown: {r.content[:80]}...")

    # --- URL auto-fix ---
    divider("3. URL without https:// (auto-prepended)")
    r = client.scrape("example.com")
    print(f"   Status: {r.statusCode} (URL fixed automatically)")

    # --- Extraction ---
    divider("4. Data extraction")
    r = client.scrape(
        "https://quotes.toscrape.com/",
        extract={
            "quotes": {"selector": "css:.text", "multiple": True},
            "authors": {"selector": "css:.author", "multiple": True},
        },
    )
    print(f"   Quotes: {len(r.extracted_data['quotes'])}")
    print(f"   First: {r.extracted_data['quotes'][0][:50]}...")
    print(f"   Author: {r.extracted_data['authors'][0]}")

    # --- Browser ---
    divider("5. Browser rendering")
    r = client.scrape("https://example.com", browser=True, use_proxy="any")
    print(f"   Status: {r.statusCode}")
    print(f"   CAPTCHA blocked: {r.potentiallyBlockedByCaptcha}")

    # --- Rate limits ---
    divider("6. Rate limit & quota tracking")
    print(f"   Rate limit remaining: {client.rate_limit_remaining}")
    print(f"   Quota remaining: {client.quota_remaining}")

    # --- Billing ---
    divider("7. Billing")
    b = client.billing()
    print(f"   Month: {b.get('month', '?')}")

    # --- Health ---
    divider("8. Health check")
    h = client.health()
    print(f"   Status: {h.get('status', '?')}")

    # --- Proxy ---
    divider("9. Proxy countries")
    countries = client.list_proxy_countries()
    print(f"   Response: {str(countries)[:100]}...")

    client.close()


async def test_async():
    divider("10. Async client")
    async with AsyncScrapingPros(DEMO_TOKEN) as client:
        r = await client.scrape("https://example.com", format="markdown")
        print(f"   Async markdown: {r.content[:60]}...")
        print(f"   Quota remaining: {client.quota_remaining}")


def test_error_handling():
    divider("11. Error handling")

    # Empty token
    try:
        ScrapingPros("")
    except Exception as e:
        print(f"   Empty token: {type(e).__name__}: {e}")

    # Empty URL
    try:
        client = ScrapingPros(DEMO_TOKEN)
        client.scrape("")
    except Exception as e:
        print(f"   Empty URL: {type(e).__name__}: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    print("ScrapingPros SDK — Manual Test")
    print(f"Using demo token: {DEMO_TOKEN}")

    test_sync()
    asyncio.run(test_async())
    test_error_handling()

    divider("ALL TESTS PASSED")
