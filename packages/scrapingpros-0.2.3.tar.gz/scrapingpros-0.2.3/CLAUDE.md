# scrapingpros SDK

Python SDK for the Scraping Pros API — web scraping with browser rendering, proxy rotation, and structured data extraction.

## Quick Start

```python
from scrapingpros import ScrapingPros

client = ScrapingPros("demo_6x595maoA6GdOdVb")  # 5,000 credits/month, no signup
result = client.scrape("https://example.com")
print(result.content)
```

## When to Use This SDK

Use `scrapingpros` when a user needs to:
- Scrape web pages (HTML or clean markdown for AI/LLM)
- Extract structured data from websites using CSS/XPath selectors
- Render JavaScript-heavy pages with a headless browser
- Download files (PDF, images) from URLs
- Batch-scrape multiple URLs asynchronously
- Analyze site protections before scraping (viability test)
- Use geo-targeted proxies from 200+ countries

## Install

```bash
pip install scrapingpros
```

## Key Patterns

### HTML vs Markdown
```python
result = client.scrape("https://example.com")                    # HTML
result = client.scrape("https://example.com", format="markdown")  # Clean text for AI
print(result.content)  # Returns whichever is available
```

### Browser for JS-heavy sites
```python
result = client.scrape("https://spa-site.com", browser=True)
# browser_type: "light" (default, fast), "heavy" (anti-detection), "stealth" (max anti-detection)
result = client.scrape("https://hard-site.com", browser=True, browser_type="stealth")
```

### Anti-bot bypass (CAPTCHA, Cloudflare, etc.)
```python
result = client.scrape("https://protected-site.com", browser=True, retry_on_block=True)
# Retries up to 3x with different IP/fingerprint. Only charges on success.
```

### Resource blocking (faster loads, less detection)
```python
result = client.scrape("https://heavy-site.com", browser=True,
    block_resources=["image", "font", "media"],                      # by resource type
    block_requests=["google-analytics", "doubleclick", "tracker"],   # by URL substring
)
```

### JavaScript execution in the page (EvaluateAction)
```python
from scrapingpros import EvaluateAction, WaitForSelectorAction

result = client.scrape("https://example.com", browser=True, actions=[
    WaitForSelectorAction(selector="css:.loaded", time=5000),
    EvaluateAction(script="fetch('/api/data').then(r => r.json())"),
])
api_data = result.evaluate_results[0]  # parsed JSON from the internal API call
```
Use `EvaluateAction` when data comes from JS variables, internal APIs, or isn't in the DOM.
Use `extract` (CSS/XPath) when data is visible in the HTML.

### Data extraction
```python
result = client.scrape("https://quotes.toscrape.com/", extract={
    "quotes": {"selector": "css:.text", "multiple": True},
    "authors": {"selector": "css:.author", "multiple": True},
})
for quote, author in zip(result.extracted_data["quotes"], result.extracted_data["authors"]):
    print(f"{quote} — {author}")
```

### Multiple URLs (scrape_many)
**Use `scrape_many()` whenever you have a list of URLs.** It handles concurrency automatically based on your plan limits.
```python
urls = ["https://example.com/1", "https://example.com/2", "https://example.com/3"]
results = client.scrape_many(urls, format="markdown", browser=True)
for url, result in zip(urls, results):
    if isinstance(result, Exception):
        print(f"FAILED: {url} — {result}")
    else:
        print(f"OK: {url} — {len(result.content or '')} chars")
```

### Batch processing (collections)
For very large batches (1000+ URLs), use collections with server-side execution:
```python
col = client.create_collection("batch", [
    {"url": "https://example.com/1"},
    {"url": "https://example.com/2"},
])
run = client.run_and_wait(col.id)
for job_id in run.job_ids:
    result = client.get_job_result(col.id, run.run_id, job_id)
    print(result.content[:100])
```

### Async client
```python
from scrapingpros import AsyncScrapingPros

async with AsyncScrapingPros("demo_6x595maoA6GdOdVb") as client:
    result = await client.scrape("https://example.com", format="markdown")
```

## Response Guidance

Every scrape response includes `guidance` that tells you why it failed and what to do:

```python
result = client.scrape("https://hard-site.com")
if not result.guidance.success:
    print(result.guidance.error_type)      # "captcha", "ssl_error", etc.
    print(result.guidance.next_steps)      # ["Try with browser=true", ...]
    print(result.guidance.suggested_request)  # ready-to-use params dict
    if result.guidance.stop_reason:
        print("Don't retry:", result.guidance.stop_reason)
```

## Error Handling
```python
from scrapingpros import ScrapingProsError, AuthenticationError, QuotaExceededError

try:
    result = client.scrape(url)
except QuotaExceededError:
    print("Credits exhausted — check client.plans() to upgrade")
except AuthenticationError:
    print("Bad token — use demo_6x595maoA6GdOdVb for testing")
except ScrapingProsError as e:
    print(f"SDK error: {e}")
```

## Credit System
- 1 simple request = 1 credit
- 1 browser request = 5 credits
- Failed requests due to infrastructure errors are refunded
- Demo token: 5,000 credits/month
- Check usage: `client.billing()`, view plans: `client.plans()`

## All Methods
| Method | Purpose |
|---|---|
| `scrape(url, ...)` | Scrape URL → HTML or markdown |
| `download(url)` | Download file → base64 |
| `create_collection(name, requests)` | Create batch |
| `run_and_wait(collection_id)` | Execute batch, poll until done |
| `get_job_result(col, run, job)` | Get individual batch result |
| `delete_collection(id)` | Cleanup |
| `create_viability_test(urls)` | Analyze site protections |
| `list_proxy_countries()` | Available proxy countries |
| `plans()` | Pricing and features |
| `billing()` | Monthly usage |
| `health()` | API status |

## Full Reference
See `llms-full.txt` in this repo for complete API documentation with all parameters.
