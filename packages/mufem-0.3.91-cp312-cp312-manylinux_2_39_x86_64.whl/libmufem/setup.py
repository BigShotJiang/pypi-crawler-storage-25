import os
import subprocess
from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.dist import Distribution
from wheel.bdist_wheel import bdist_wheel


def strip_symbols(filepath):
    subprocess.run(["strip", "--strip-unneeded", filepath], check=True)


class BinaryDistribution(Distribution):
    """Force a platform tag (linux_x86_64) without binding to a Python ABI."""
    def has_ext_modules(self):
        return True


class PyAgnosticWheel(bdist_wheel):
    """Tag the wheel py3-none-<plat>: no specific Python ABI is required
    because libmufem.so contains no Python symbols."""
    def get_tag(self):
        _, _, plat = super().get_tag()
        return ("py3", "none", plat)


class CustomBuildPy(build_py):
    def run(self):
        super().run()

        lib_dir = os.path.join(self.build_lib, "libmufem", "lib")
        # Third-party libs sit next to libmufem.so under libmufem/lib/.
        # rpath = $ORIGIN points back at the same directory so they can
        # resolve each other (e.g. libhypre needs libmpi).
        if os.path.exists(lib_dir):
            for f in os.listdir(lib_dir):
                fp = os.path.join(lib_dir, f)
                if not os.path.isfile(fp):
                    continue
                if f.endswith(".a"):
                    os.remove(fp)
                elif f.endswith(".so") or ".so." in f:
                    subprocess.run(
                        ["patchelf", "--set-rpath", "$ORIGIN", fp], check=True
                    )
                    strip_symbols(fp)

        # libmufem.so is one level up; it needs to find third-party libs in
        # the lib/ subdir at runtime.
        engine = os.path.join(self.build_lib, "libmufem", "libmufem.so")
        if os.path.exists(engine):
            subprocess.run(
                ["patchelf", "--set-rpath", "$ORIGIN/lib", engine], check=True
            )
            strip_symbols(engine)


version = os.getenv("GIT_TAG", "0.0.0")

setup(
    name="libmufem",
    version=version,
    description="Native engine library for mufem — interpreter-independent.",
    long_description=(
        "libmufem ships the μfem C++ engine as a shared library plus its "
        "third-party runtime dependencies (MFEM, MPI, hypre, …). It is "
        "consumed by the `mufem` package, which provides the Python "
        "bindings; `mufem` declares an exact-version dependency on this "
        "package. Each released `mufem-X.Y.Z` requires `libmufem==X.Y.Z`."
    ),
    long_description_content_type="text/plain",
    author="Raiden Numerics LLC",
    author_email="mufem@raiden-numerics.com",
    packages=["libmufem"],
    package_data={
        "libmufem": [
            "__init__.py",
            "libmufem.so",
            "lib/**/*",
            "share/**/*",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: Other/Proprietary License",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    distclass=BinaryDistribution,
    cmdclass={
        "build_py": CustomBuildPy,
        "bdist_wheel": PyAgnosticWheel,
    },
)
