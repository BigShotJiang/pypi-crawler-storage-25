"""libmufem — native engine library and third-party deps for mufem.

`import libmufem` preloads the engine and its third-party shared libraries
with the dlopen flags the runtime needs. The bindings in the `mufem`
package import this module first so symbols are already available when
mufem.so is loaded.
"""

import os
import ctypes


_package_dir = os.path.dirname(__file__)
_lib_dir = os.path.join(_package_dir, "lib")

# Open MPI looks here for plugins (BTL/MTL components, etc.).
os.environ.setdefault("OPAL_PREFIX", _package_dir)

_loaded_libs = {}

if os.path.isdir(_lib_dir):
    for so_file in sorted(os.listdir(_lib_dir)):
        if not (so_file.endswith(".so") or ".so." in so_file):
            continue
        # libmfem is loaded RTLD_LOCAL below — a global load triggers a
        # crash at interpreter shutdown (mfem static-state teardown).
        if "mfem" in so_file:
            continue
        so_path = os.path.join(_lib_dir, so_file)
        try:
            _loaded_libs[so_file] = ctypes.CDLL(so_path, mode=ctypes.RTLD_GLOBAL)
        except OSError as e:
            print(f"Warning: Could not load {so_path}: {e}")

_mfem_so = os.path.join(_lib_dir, "libmfem.so")
if os.path.exists(_mfem_so):
    _loaded_libs["libmfem.so"] = ctypes.CDLL(_mfem_so, mode=ctypes.RTLD_LOCAL)

_engine_so = os.path.join(_package_dir, "libmufem.so")
if os.path.exists(_engine_so):
    _loaded_libs["libmufem.so"] = ctypes.CDLL(_engine_so, mode=ctypes.RTLD_GLOBAL)
