import mufem
from mufem import Bnd, Vol
from mufem.thermal import (
    SolidTemperatureMaterial,
    SolidTemperatureModel,
    TemperatureCondition,
)

# Setup Problem:
sim = mufem.Simulation.New(
    name="Test case",
    mesh_path="geometry.nm2",
)

steady_runner = mufem.SteadyRunner(total_iterations=3)
sim.set_runner(steady_runner)

# Model:
thermal_model = SolidTemperatureModel(marker=1 @ Vol)
sim.get_model_manager().add_model(thermal_model)

# Material:
gold_material = SolidTemperatureMaterial(
    name="Gold",
    marker=1 @ Vol,
    thermal_conductivity=237.0,
    specific_heat_capacity=129.0,
    density=19320.0,
)
thermal_model.add_materials([gold_material])

# Boundary conditions:
bc_T300 = TemperatureCondition(
    name="Temperature = 300K",
    marker=5 @ Bnd,
    temperature=300,
)
bc_T400 = TemperatureCondition(
    name="Temperature = 400K",
    marker=6 @ Bnd,
    temperature=400,
)
thermal_model.add_conditions([bc_T300, bc_T400])

sim.run()
