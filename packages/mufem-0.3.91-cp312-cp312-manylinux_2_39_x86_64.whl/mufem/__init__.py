"""mufem — Python bindings for the μfem finite-element framework.

The native engine and its third-party dependencies are shipped separately
in the `libmufem` package (declared as an exact-version install_requires).
Importing it here triggers ctypes preloading of the engine and its
runtime deps so symbols are visible when mufem.so loads.
"""

import os
import sys
import importlib.util

import libmufem  # noqa: F401  side-effect import: ctypes-preload engine + deps

_package_dir = os.path.dirname(__file__)
_mufem_so = os.path.join(_package_dir, "mufem.so")
if not os.path.exists(_mufem_so):
    raise ImportError(f"Could not find {_mufem_so}")

_spec = importlib.util.spec_from_file_location("mufem", _mufem_so)
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)

# Replace the package object with the .so module so `import mufem` exposes
# the C extension's surface directly (matches the pre-split behavior).
sys.modules["mufem"] = _mod
