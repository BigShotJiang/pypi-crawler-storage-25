# 作者: Assassin
# version: 0.4.21
"""
Mcode — interactive AI coding agent CLI.
Usage: python3 run.py [--project <name>]

Type /help inside the REPL for the full command list.
Esc+Enter for multiline input. @path to attach a file.
"""
import fnmatch
import os
import re
import sys
import threading
import time

_HISTORY_FILE = os.path.expanduser("~/.mcode/history")

sys.path.insert(0, os.path.dirname(__file__))
from control.brain import Brain
from control.fmt import p_dim, p_info, p_warn, p_ok, cyan, dim, bold, fmt_prompt_tag


_HELP = """
Slash commands:
  /quit  /exit                      Exit the agent
  /end                              End session (save to memory, keep verbatim tail)
  /rewind [N]                       Rewind session: pick a turn, clear conversation and/or restore files
  /context [path]                   Export full context (core+project+recent memory + session history) to file or stdout

  /project list                     List all projects
  /project delete <name>            Delete a project (glob patterns supported)
  /project rename [<old>] <new>     Rename a project (defaults to current)
  /project workdir [path]           Set work_dir for current project (shell commands run here)

  /memory                           Show core memory, project memory, and open tasks
  /tasks                            List all tasks
  /tasks done <id>                  Mark task as done
  /tasks cancel <id>                Cancel a task
  /tasks del <id>                   Hard-delete a task from the store
  /memory compact                   Condense bloated memory entries (removes duplicates via LLM)
  /memory set <key> <value>         Write a core memory entry (default dim: communication)
  /memory set <key> <value> --dim <dim>  Write with specific dimension
  /memory del <key>                 Delete a core memory entry
  /memory pin <key>                 Pin an entry (stability=999, never forgets)
  /memory set <key> <value> --project   Write/correct a project memory entry (key = dimension name)
  /memory del <key> --project       Delete a project memory entry

!<command>                         Run shell command directly (bypasses LLM, still safety-checked)
  @<path>                           Attach a file's contents to your message (e.g. @src/main.py)

  /tools                            List all loaded tools
  /model [name]                     Show or switch the LLM model at runtime
  /btw <question>                   Quick one-shot question (no memory, no tools)
  /template [example]               Show auto-mode task prompt template
  /safety [on|off]                  Toggle safety module (off = bypass ALL checks, DANGEROUS)
  /auto [on|off]                    Toggle auto mode (no prompts, hard boundaries)
  /auto whitelist                   Show current whitelist
  /auto whitelist add <cmd>         Add command to whitelist
  /auto whitelist remove <cmd>      Remove command from whitelist
  /auto whitelist reset             Reset to default whitelist

  /status                           Show current settings
  /help                             Show this help
""".strip()


def _ask(prompt_str: str) -> str:
    """Prompt for input using prompt_toolkit to avoid terminal glitches."""
    from prompt_toolkit import prompt as _pt_prompt
    try:
        return _pt_prompt(prompt_str).strip()
    except (EOFError, KeyboardInterrupt):
        return ""


def _toggle(current: bool, arg: str, name: str) -> bool:
    if arg in ("on", "1", "true"):
        new = True
    elif arg in ("off", "0", "false"):
        new = False
    else:
        new = not current
    state = "ON" if new else "OFF"
    print(f"[{name}] {state}")
    return new



def cmd_memory(brain: Brain, args: str = ""):
    """Show or edit core/project memory."""
    parts = args.split(None, 1)
    sub = parts[0].lower() if parts else ""
    rest = parts[1] if len(parts) > 1 else ""

    # --project flag routes set/del to project_memory instead of core_memory
    use_project = "--project" in rest
    if use_project:
        rest = rest.replace("--project", "").strip()

    cm = brain.memory.core_memory
    pm = getattr(brain, "project_memory", None)

    # --- subcommands ---
    if sub == "set":
        if use_project:
            if not pm:
                print("  No project memory configured for this project.")
                return
            kv = rest.split(None, 1)
            if len(kv) < 2:
                print("Usage: /memory set <key> <value> --project")
                return
            key, value = kv[0], kv[1]
            dim = key  # project memory keys equal dimension names
            if key not in pm.dimensions:
                dims = ", ".join(pm.dimensions)
                print(f"  Unknown key '{key}'. Valid keys: {dims}")
                return
            pm.set(key, value, dimension=dim)
            print(f"  Set [project/{key}]: {value}")
            return
        dim = "interaction_style"
        if "--dim" in rest:
            rest, _, dim_part = rest.partition("--dim")
            dim = dim_part.strip()
            rest = rest.strip()
        kv = rest.split(None, 1)
        if len(kv) < 2:
            print("Usage: /memory set <key> <value> [--dim <dimension>]")
            return
        key, value = kv[0], kv[1]
        cm.set(key, value, dimension=dim)
        print(f"  Set [{dim}] {key}: {value}")
        return

    if sub == "del":
        key = rest.strip()
        if not key:
            print("Usage: /memory del <key> [--project]")
            return
        if use_project:
            if not pm:
                print("  No project memory configured for this project.")
                return
            deleted = pm.delete(key)
            print(f"  {'Deleted from project memory' if deleted else 'Key not found'}: {key}")
        else:
            deleted = cm.delete(key)
            print(f"  {'Deleted' if deleted else 'Key not found'}: {key}")
        return

    if sub == "compact":
        cm = brain.memory.core_memory
        print("  Compacting bloated memory entries...")
        keys = cm.compact(threshold=200)
        if keys:
            print(f"  Compacted {len(keys)} entry(ies): {', '.join(keys)}")
        else:
            print("  All entries are within size limits.")
        return

    if sub == "pin":
        key = rest.strip()
        if not key:
            print("Usage: /memory pin <key>")
            return
        entries = cm.get_all_with_scores()
        meta = next((e for e in entries if e["key"] == key), None)
        if not meta:
            print(f"  Key not found: {key}")
            return
        cm.set(key, meta["value"], dimension=meta.get("dimension", "communication"), stability=999.0)
        print(f"  Pinned: {key}  (stability=999, never forgets)")
        return

    # --- default: show all ---
    core_entries = cm.get_all_with_scores() if cm else []
    print("\n[Core Memory]")
    if not core_entries:
        print("  (empty)")
    else:
        by_dim: dict[str, list] = {}
        for e in core_entries:
            by_dim.setdefault(e.get("dimension", "?"), []).append(e)
        for dim, items in sorted(by_dim.items()):
            print(f"  [{dim}]")
            for e in items:
                days = (time.time() - e["updated_at"]) / 86400
                pin = " 📌" if e["stability"] >= 999 else ""
                print(f"    {e['value']}")
                print(f"      score={e['score']:.2f}  updated={days:.1f}d ago{pin}")

    pm = getattr(brain, "project_memory", None)
    project = brain.projects.current_project
    print(f"\n[Project Memory — {project}]")
    if not pm:
        print("  (not configured)")
    else:
        proj_entries = pm.get_all_with_scores()
        if not proj_entries:
            print("  (empty)")
        else:
            by_dim2: dict[str, list] = {}
            for e in proj_entries:
                by_dim2.setdefault(e.get("dimension", "?"), []).append(e)
            for dim, items in sorted(by_dim2.items()):
                print(f"  [{dim}]")
                for e in items:
                    days = (time.time() - e["updated_at"]) / 86400
                    print(f"    {e['value']}")
                    print(f"      score={e['score']:.2f}  updated={days:.1f}d ago")

    tasks = getattr(brain, "tasks", None)
    print(f"\n[Tasks — {project}]")
    if tasks:
        open_tasks = tasks.open_tasks()
        done_tasks = tasks.list("done")
        if not open_tasks and not done_tasks:
            print("  (no tasks)")
        for t in open_tasks:
            print(f"  #{t['id']} [open]  {t['title']}")
            if t.get("description"):
                print(f"           {t['description']}")
            print(f"           created: {t['created_at']}")
        for t in done_tasks[-5:]:  # show last 5 done
            print(f"  #{t['id']} [done]  {t['title']}  ({t['done_at']})")
    else:
        print("  (not configured)")
    print()



def cmd_tasks(brain: Brain, args: str = ""):
    """Manage tasks directly without going through the LLM."""
    tasks = getattr(brain, "tasks", None)
    if not tasks:
        print("  Task store not available.")
        return
    parts = args.split(None, 1)
    sub = parts[0].lower() if parts else ""
    rest = parts[1].strip() if len(parts) > 1 else ""

    if sub == "done" and rest.isdigit():
        t = tasks.done(int(rest))
        print(f"  Marked done: #{rest} {t['title'] if t else '(not found)'}")
    elif sub == "cancel" and rest.isdigit():
        t = tasks.cancel(int(rest))
        print(f"  Cancelled: #{rest} {t['title'] if t else '(not found)'}")
    elif sub == "del" and rest.isdigit():
        # Hard delete via direct file manipulation
        all_tasks = tasks._load()
        before = len(all_tasks)
        all_tasks = [t for t in all_tasks if t["id"] != int(rest)]
        tasks._save(all_tasks)
        if len(all_tasks) < before:
            print(f"  Deleted task #{rest}.")
        else:
            print(f"  Task #{rest} not found.")
    else:
        # Default: list all
        all_tasks = tasks.list()
        if not all_tasks:
            print("  (no tasks)")
            return
        for t in all_tasks:
            desc = f"  {t['description'][:60]}" if t.get("description") else ""
            print(f"  #{t['id']} [{t['status']}]  {t['title']}{desc}")
        print(f"\n  Usage: /tasks done <id> | /tasks cancel <id> | /tasks del <id>")


def _show_recent_turns(brain: Brain, n: int = 3):
    """Print a brief summary of the last N turns in the current project."""
    turns = brain.memory.list_turns()
    if not turns:
        p_dim("  (no conversation history)")
        return
    recent = turns[-n:]
    p_dim(f"  --- last {len(recent)} turn(s) ---")
    for t in recent:
        u = t["user"].replace("\n", " ")[:80]
        a = t["assistant"].replace("\n", " ")[:80] if t["assistant"] else ""
        p_dim(f"  You:   {u}")
        if a:
            p_dim(f"  Agent: {a}")


def _rewind_clear_project(brain: Brain):
    """Optionally clear project memory and tasks after rewinding to turn 0."""
    ans = _ask("Also clear project memory and tasks? [y/N]: ").strip().lower()
    if ans == "y":
        n_recent = brain.memory.recent_memory.clear()
        pm = getattr(brain, "project_memory", None)
        n_facts = pm.clear() if pm else 0
        tasks = getattr(brain, "tasks", None)
        if tasks:
            all_tasks = tasks.list()
            for t in all_tasks:
                tasks.cancel(t["id"])
            n_tasks = len(all_tasks)
        else:
            n_tasks = 0
        print(f"Cleared: {n_recent} session summary(s), {n_facts} project fact(s), {n_tasks} task(s).")


def _do_rewind(brain: Brain, idx: int):
    """Rewind conversation to turn idx and handle side effects."""
    try:
        brain.memory.rewind_to(idx)
    except IndexError as e:
        print(f"Error: {e}")
        return
    if idx == 0:
        print("Conversation cleared.")
        _rewind_clear_project(brain)
    else:
        remaining = brain.memory.list_turns()
        print(f"Rewound to turn [{idx}]. Session now has {len(remaining)} turn(s).")


def cmd_show_context(brain: Brain, arg: str = ""):
    """Export the full current context to a file or print to stdout."""
    import json
    from datetime import datetime

    out_path = arg.strip() or ""

    lines: list[str] = []
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines.append(f"# mcode context snapshot — {now}\n")

    # 1. Core memory
    lines.append("## Core Memory")
    cm = brain.memory.core_memory
    entries = cm.get_all()
    if entries:
        for e in entries:
            lines.append(f"  [{e.get('dim', '')}] {e.get('key', '')}: {e.get('value', '')}")
    else:
        lines.append("  (empty)")
    lines.append("")

    # 2. Project memory
    lines.append("## Project Memory")
    pm = brain.project_memory
    if pm:
        s = pm.to_context_string().strip()
        lines.append(s if s else "  (empty)")
    else:
        lines.append("  (none)")
    lines.append("")

    # 3. Recent memory (injected sessions)
    lines.append("## Recent Memory (injected sessions)")
    rm_entries = brain.memory.recent_memory.get_entries_for_context()
    if rm_entries:
        for entry in rm_entries:
            lines.append(entry)
            lines.append("---")
    else:
        lines.append("  (empty)")
    lines.append("")

    # 4. Current session history
    lines.append("## Current Session History")
    history = brain.memory._history
    if history:
        turn = 0
        i = 0
        while i < len(history):
            msg = history[i]
            if msg.get("_is_summary"):
                lines.append(f"[compressed summary]\n{msg.get('content', '')}")
                i += 1
                continue
            role = msg.get("role", "")
            if role == "user":
                turn += 1
                content = msg.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"
                    )
                lines.append(f"[Turn {turn}] User: {content}")
            elif role == "assistant":
                content = msg.get("content", "")
                if isinstance(content, list):
                    parts = []
                    for p in content:
                        if not isinstance(p, dict):
                            continue
                        t = p.get("type", "")
                        if t == "text":
                            parts.append(p.get("text", ""))
                        elif t == "tool_use":
                            parts.append(f"[tool: {p.get('name', '?')}({p.get('input', {})})]")
                        elif t == "thinking":
                            pass  # skip internal thinking blocks
                    content = " ".join(parts)
                if content:
                    lines.append(f"[Turn {turn}] Assistant: {content}")
            i += 1
    else:
        lines.append("  (empty)")
    lines.append("")

    output = "\n".join(lines)

    if out_path:
        try:
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(output)
            p_ok(f"  Context exported to {out_path}  ({len(output):,} chars)")
        except OSError as e:
            print(f"  Error writing file: {e}")
    else:
        print(output)


def cmd_rewind(brain: Brain, arg: str = ""):
    """Rewind the session: pick a turn, then clear conversation and/or restore files."""
    # /rewind N — direct conversation rewind to turn N
    if arg.isdigit():
        _do_rewind(brain, int(arg))
        return

    turns = brain.memory.list_turns()
    runs = brain.audit.runs_with_backups(project=brain.projects.current_project)

    # Map turn_idx → merged {orig: backup_path} for that turn
    turn_files: dict[int, dict[str, str]] = {}
    for run in runs:
        tidx = run.get("turn_idx", -1)
        if tidx >= 0:
            turn_files.setdefault(tidx, {}).update(run["available_backups"])
    all_files: dict[str, str] = {}
    for run in runs:
        all_files.update(run["available_backups"])

    if not turns and not runs:
        print("Nothing to rewind (no conversation turns, no file backups).")
        return

    max_turn = turns[-1]["index"] if turns else 0
    print(f"\nCurrent session turns:")
    file_note = f"  ({len(all_files)} backed-up file(s))" if all_files else ""
    print(f"  [0] Clear entire session{file_note}")
    for t in turns:
        tidx = t["index"]
        files = turn_files.get(tidx, {})
        file_tag = "  [file]" if files else ""
        print(f"  [{tidx}] {t['user'].replace(chr(10), ' ')[:65]}{file_tag}")
        for f in files:
            print(f"       {f}")

    choice = _ask(f"\nSelect turn to rewind to [0–{max_turn}] (or Enter to cancel): ")
    if not choice.isdigit():
        print("Cancelled.")
        return

    target = int(choice)
    if target > max_turn:
        print(f"Invalid turn (max {max_turn}).")
        return

    target_files = all_files if target == 0 else turn_files.get(target, {})
    has_conv = bool(turns)
    has_files = bool(target_files)

    print("\nWhat to clear?")
    if has_conv and has_files:
        print("  [1] Conversation + files")
        print("  [2] Conversation only")
        print("  [3] Files only")
    elif has_conv:
        print("  [1] Conversation")
    elif has_files:
        print("  [1] Files")
    print("  [0] Cancel")
    action = _ask("Choice: ").strip()

    do_conv = do_files = False
    if has_conv and has_files:
        if action == "1":   do_conv = do_files = True
        elif action == "2": do_conv = True
        elif action == "3": do_files = True
        else: print("Cancelled."); return
    elif has_conv:
        if action == "1": do_conv = True
        else: print("Cancelled."); return
    elif has_files:
        if action == "1": do_files = True
        else: print("Cancelled."); return

    if do_files:
        from safety.backup import restore_backup
        for orig, bp in target_files.items():
            print(f"  {'Restored' if restore_backup(bp) else 'Failed'}: {orig}")
    if do_conv:
        _do_rewind(brain, target)

    print("Done.")





def cmd_project(brain: Brain, args: str):
    parts = args.split(None, 2)
    if not parts:
        print("Usage: /project list|delete|rename|workdir")
        return
    sub = parts[0].lower()
    try:
        if sub == "list":
    
            projects = brain.projects.list_projects()
            print("\nProjects:")
            for p in projects:
                marker = " ◀" if p["name"] == brain.projects.current_project else ""
                wd = f"  [{p['work_dir']}]" if p["work_dir"] else ""
                auto = " (auto)" if p["auto"] else ""
                print(f"  {p['name']}{marker}{wd}{auto}")
        elif sub == "delete":
            pattern = parts[1]
            all_names = [p["name"] for p in brain.projects.list_projects()]
            matches = [n for n in all_names if fnmatch.fnmatch(n, pattern)]
            if not matches:
                print(f"No projects match: {pattern}")
            else:
                if len(matches) == 1:
                    print(f"Delete project: {matches[0]}")
                else:
                    print(f"Will delete {len(matches)} projects:")
                    for n in matches:
                        print(f"  - {n}")
                confirm = _ask("Confirm? [y/N] ❯ ").lower()
                if confirm in ("y", "yes"):
                    deleted, skipped = [], []
                    for n in matches:
                        try:
                            brain.projects.delete_project(n)
                            deleted.append(n)
                        except ValueError as e:
                            skipped.append(f"{n} ({e})")
                    if deleted:
                        print(f"Deleted: {', '.join(deleted)}")
                    if skipped:
                        print(f"Skipped: {', '.join(skipped)}")
                else:
                    print("Cancelled.")
        elif sub == "rename":
            if len(parts) == 2:
                old = brain.projects.current_project
                new = parts[1]
            else:
                old, new = parts[1], parts[2]
            brain.projects.rename_project(old, new)
            # If current project was renamed, refresh memory's db_path
            if brain.projects.current_project == new:
                brain._reinit_memory()
            print(f"Renamed: {old} → {new}")
        elif sub == "workdir":
            if len(parts) > 1 and parts[1].lower() == "clear":
                brain.projects.set_work_dir(None)
                print("work_dir cleared.")
            elif len(parts) > 1:
                new_wd = parts[1]
                brain.projects.set_work_dir(new_wd)
                print(f"work_dir set to: {new_wd}")
            else:
                wd = brain.projects.work_dir
                print(f"work_dir: {wd or '(not set)'}")
                print("  /project workdir <path>   set · /project workdir clear   unset")
        else:
            print(f"Unknown subcommand: {sub}")
    except (IndexError, KeyError):
        print(f"Missing argument for /project {sub}")
    except Exception as e:
        print(f"Error: {e}")



_AUTO_TEMPLATE = """\
# Auto-mode task template  (/auto on  to enable)
# ─────────────────────────────────────────────────
# Task: <一句话描述目标>
#
# Context:
#   - work_dir: <项目根目录，已在 /project workdir 设置>
#   - Language / framework: <语言/框架>
#   - Entry point: <主文件或命令>
#
# Acceptance criteria (done when ALL true):
#   1. <具体可验证的完成标准>
#   2. <例如：pytest 全部通过>
#   3. <例如：文件 X 存在且内容包含 Y>
#
# Constraints:
#   - Do NOT modify: <不能动的文件>
#   - Preserve existing tests
#
# Verify by running: <验证命令，例如 pytest / cargo test / npm test>
"""

_AUTO_TEMPLATE_EXAMPLE = """\
# 示例：给已有 Flask 项目加一个健康检查接口
# ─────────────────────────────────────────────────
Task: 在 app.py 里新增 GET /health 接口，返回 {"status": "ok"}

Context:
  - work_dir: /home/user/myapp
  - Language / framework: Python 3.11, Flask 2.x
  - Entry point: app.py

Acceptance criteria:
  1. GET /health 返回 200 和 {"status": "ok"}
  2. 不影响现有路由和测试
  3. pytest tests/ 全部通过

Constraints:
  - Do NOT modify: requirements.txt, Dockerfile

Verify by running: pytest tests/ -v
"""


def _cmd_template(arg: str):
    """Print auto-mode task template."""
    from control.fmt import cyan, dim
    if arg in ("example", "ex"):
        print(cyan("\n── Auto-mode task example ──"))
        print(_AUTO_TEMPLATE_EXAMPLE)
    else:
        print(cyan("\n── Auto-mode task template ──"))
        print(_AUTO_TEMPLATE)
        print(dim("  tip: /template example  shows a filled-in example"))
    print()


def _cmd_btw(brain: Brain, question: str):
    """One-shot question: no memory, no tools, no project side-effects."""
    from control.fmt import dim
    if not question:
        print("  Usage: /btw <question>")
        return

    messages = [{"role": "user", "content": question}]

    import sys, threading
    _stop = threading.Event()

    def _spin():
        frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        i = 0
        while not _stop.is_set():
            sys.stdout.write(f"\r  {frames[i % len(frames)]}  thinking…")
            sys.stdout.flush()
            _stop.wait(0.1)
            i += 1
        sys.stdout.write("\r\033[K")
        sys.stdout.flush()

    t = threading.Thread(target=_spin, daemon=True)
    t.start()

    chunks: list[str] = []
    try:
        for chunk in brain.llm.stream(messages, max_tokens=2000):
            if not _stop.is_set():
                _stop.set()
                t.join()
            chunks.append(chunk)
            sys.stdout.write(chunk)
            sys.stdout.flush()
    except KeyboardInterrupt:
        pass
    finally:
        if not _stop.is_set():
            _stop.set()
        t.join()

    if chunks:
        print()


def _cmd_safety(brain: Brain, arg: str):
    """Toggle safety bypass. Requires explicit confirmation when disabling."""
    from control.fmt import red, yellow, green, dim, p_ok

    if arg in ("on", ""):
        # Restore safety
        if not brain.bypass_safety:
            print("  Safety module is already ON.")
            return
        brain.bypass_safety = False
        p_ok("  Safety module restored.")
        return

    if arg == "off":
        if brain.bypass_safety:
            print("  Safety module is already OFF (bypassed).")
            return
        print(red("\n  ⚠️   WARNING — SAFETY BYPASS"))
        print(yellow("  ─" * 32))
        print(yellow("  All safety checks will be DISABLED."))
        print(yellow("  The agent can read/write/execute ANYWHERE"))
        print(yellow("  with full privileges of the current user."))
        print(yellow("  ─" * 32))
        print(red("  FOR EXPERIMENTAL ENVIRONMENTS ONLY."))
        print(red("  ANY CONSEQUENCES ARE YOUR RESPONSIBILITY."))
        print(yellow("  ─" * 32))
        try:
            raw = _ask("  Type 'yes' to confirm, anything else to cancel: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            raw = ""
        if raw != "yes":
            print(dim("  Cancelled."))
            return
        brain.bypass_safety = True
        print(red("  ⚡  Safety bypassed. You are on your own."))
        return

    print(f"  Usage: /safety on | /safety off")


def _cmd_auto(brain: Brain, args: str):
    """Manage auto mode and whitelist."""
    from safety.safety import DEFAULT_AUTO_WHITELIST
    from control.fmt import p_ok, p_info, cyan, dim, green, red

    parts = args.split(None, 2)
    sub = parts[0].lower() if parts else ""

    # /auto [on|off] or bare /auto → toggle
    if sub in ("on", "off", ""):
        if sub == "on":
            new = True
        elif sub == "off":
            new = False
        else:
            new = not brain.auto_mode
        brain.auto_mode = new
        brain._agent_cfg["auto_mode"] = new
        brain._save_agent_cfg()
        state = green("AUTO") if new else dim("HUMAN")
        print(f"  mode → {state}")
        if new:
            wl = brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST
            print(dim(f"  whitelist: {len(wl)} commands  (/auto whitelist to view)"))
        return

    if sub == "whitelist":
        sub2 = parts[1].lower() if len(parts) > 1 else "list"

        if sub2 == "list" or sub2 == "":
            wl = brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST
            source = "custom" if "auto_whitelist" in brain._agent_cfg else "default"
            print(f"\n  Whitelist ({source}, {len(wl)} entries):")
            for entry in sorted(wl):
                print(f"    {entry}")
            print()

        elif sub2 == "add":
            cmd_entry = parts[2].strip() if len(parts) > 2 else ""
            if not cmd_entry:
                print("  Usage: /auto whitelist add <command>")
                return
            wl = list(brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST)
            if cmd_entry in wl:
                print(f"  already in whitelist: {cmd_entry}")
                return
            wl.append(cmd_entry)
            brain._agent_cfg["auto_whitelist"] = wl
            brain._save_agent_cfg()
            p_ok(f"  added: {cmd_entry}")

        elif sub2 == "remove":
            cmd_entry = parts[2].strip() if len(parts) > 2 else ""
            if not cmd_entry:
                print("  Usage: /auto whitelist remove <command>")
                return
            wl = list(brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST)
            if cmd_entry not in wl:
                print(f"  not in whitelist: {cmd_entry}")
                return
            wl.remove(cmd_entry)
            brain._agent_cfg["auto_whitelist"] = wl
            brain._save_agent_cfg()
            p_ok(f"  removed: {cmd_entry}")

        elif sub2 == "reset":
            if "auto_whitelist" in brain._agent_cfg:
                del brain._agent_cfg["auto_whitelist"]
                brain._save_agent_cfg()
            p_ok("  whitelist reset to default")

        else:
            print(f"  Unknown: /auto whitelist {sub2}")
        return

    print(f"  Unknown: /auto {sub}  (try /auto on|off|whitelist)")


def handle_slash(cmd: str, brain: Brain) -> bool:
    """
    Handle a /command. Returns handled.
    Raises SystemExit on /quit.
    """
    parts = cmd[1:].split(None, 1)
    name = parts[0].lower()
    arg_raw = parts[1] if len(parts) > 1 else ""
    arg = arg_raw.lower()

    if name in ("quit", "exit"):
        if not getattr(brain, "_session_ended", False):
            brain.end_session()
            brain._session_ended = True
        raise SystemExit(0)

    if name == "end":
        brain.end_session()
        brain._session_ended = True
        print("[session ended]")

    elif name == "help":
        print(_HELP)

    elif name == "rewind":
        cmd_rewind(brain, arg)

    elif name == "context":
        cmd_show_context(brain, arg_raw)

    elif name == "project":
        cmd_project(brain, arg_raw)

    elif name == "memory":
        cmd_memory(brain, arg_raw)

    elif name == "tasks":
        cmd_tasks(brain, arg_raw)

    elif name == "btw":
        _cmd_btw(brain, arg_raw)

    elif name == "template":
        _cmd_template(arg)

    elif name == "safety":
        _cmd_safety(brain, arg)

    elif name == "auto":
        _cmd_auto(brain, arg_raw)

    elif name == "parallel":
        pass  # parallel execution removed (agentic loop handles sequencing)

    elif name == "model":
        if not arg_raw:
            active = brain._agent_cfg.get("active_model", "")
            print(f"  active: {active}  ({brain.llm.model})")
            models = brain.list_models()
            if models:
                print("  available:")
                for alias, prof in models.items():
                    marker = " ◀" if alias == active else ""
                    print(f"    {alias}{marker}  — {prof.get('model', '')}  [{prof.get('provider', 'openai')}]")
            print("  usage: /model <alias>")
        else:
            alias = arg_raw.strip()
            try:
                brain.switch_model(alias)
                p_ok(f"  model → {alias}  ({brain.llm.model})")
            except KeyError as e:
                print(f"  {e}")
                print(f"  available: {', '.join(brain.list_models())}")

    elif name == "tools":
        tools = brain.registry.list()
        print(f"\n  {len(tools)} tool(s) loaded:")
        for t in tools:
            print(f"  • {t.name:20s} {t.description.splitlines()[0]}")
        print()

    elif name == "status":
        p = brain.projects.current_project
        wd = brain.projects.work_dir or "(not set)"
        mode = "AUTO" if brain.auto_mode else "HUMAN"
        safety = "⚡ BYPASSED" if brain.bypass_safety else "ON"
        print(
            f"  project:   {p}\n"
            f"  work_dir:  {wd}\n"
            f"  model:     {brain.llm.model}\n"
            f"  mode:      {mode}\n"
            f"  safety:    {safety}\n"
        )

    else:
        print(f"Unknown command: /{name}  (type /help for list)")

    return True


def _print_logo(brain: "Brain"):
    from control.fmt import cyan, dim
    logo = r"""  __  __               _
 |  \/  | ___ ___   __| | ___
 | |\/| |/ __/ _ \ / _` |/ _ \
 | |  | | (_| (_) | (_| |  __/
 |_|  |_|\___\___/ \__,_|\___|"""
    width = os.get_terminal_size().columns if sys.stdout.isatty() else 72
    border = cyan("─" * width)
    project = brain.projects.current_project
    active = brain._agent_cfg.get("active_model", "")
    model_str = f"{active}  ({brain.llm.model})" if active else brain.llm.model
    print()
    print(border)
    print(cyan(logo))
    print(border)
    print("  Mcode  —  Your local AI coding agent")
    print(dim("  › /help for commands"))
    print(dim(f"  › Project: {project}  —  /project rename <name> to name this session"))
    print(dim(f"  › Model:   {model_str}  —  /model to switch"))
    print(border)
    print()


_IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.tiff', '.tif'}
_PDF_EXTS   = {'.pdf'}
_EXCEL_EXTS = {'.xlsx', '.xls'}

# Matches @"path with spaces", @'path with spaces', or @plain/path
# Group 1: double-quoted, Group 2: single-quoted, Group 3: unquoted (no whitespace)
_AT_FILE_RE = re.compile(r'@(?:"([^"]+)"|\'([^\']+)\'|([\w./~\\][^\s,;!?]*))')


def _extract_image_blocks(text: str, work_dir: str) -> tuple[str, list[dict], list[str]]:
    """
    Find @path references to image files. Remove them from text and return
    (cleaned_text, image_url_blocks, filenames) for building a multimodal content list.
    Non-image @paths are left in text for _expand_at_files to handle.
    """
    import base64, mimetypes
    image_refs: set[str] = set()
    image_blocks: list[dict] = []
    filenames: list[str] = []

    for m in _AT_FILE_RE.finditer(text):
        raw = m.group(1) or m.group(2) or m.group(3)
        path = os.path.expanduser(raw)
        if not os.path.isabs(path):
            path = os.path.join(work_dir, path)
        path = os.path.normpath(path)
        if not os.path.isfile(path):
            continue
        if os.path.splitext(path)[1].lower() not in _IMAGE_EXTS:
            continue
        try:
            mime = mimetypes.guess_type(path)[0] or "image/png"
            with open(path, "rb") as f:
                data = base64.b64encode(f.read()).decode()
            image_blocks.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}})
            image_refs.add(raw)
            filenames.append(os.path.basename(path))
            p_dim(f"  🖼  image: {raw}")
        except OSError as e:
            p_warn(f"@{raw}: cannot read image ({e}), skipped")

    if not image_refs:
        return text, [], []

    clean = _AT_FILE_RE.sub(
        lambda m: "" if (m.group(1) or m.group(2) or m.group(3)) in image_refs else m.group(0),
        text
    ).strip()
    return clean, image_blocks, filenames


def _expand_at_files(text: str, work_dir: str) -> str:
    """Replace @path references with file contents inline.
    Binary formats (PDF, Excel) are represented as tool-call hints rather
    than inlined bytes.
    """
    attachments = []
    for m in _AT_FILE_RE.finditer(text):
        raw = m.group(1) or m.group(2) or m.group(3)
        path = os.path.expanduser(raw)
        if not os.path.isabs(path):
            path = os.path.join(work_dir, path)
        path = os.path.normpath(path)
        if not os.path.isfile(path):
            p_warn(f"@{raw}: file not found, skipped")
            continue
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext in _PDF_EXTS:
                content = f"[PDF file attached: {path}]\nUse the pdf_read tool with path=\"{path}\" to read this file."
                attachments.append((raw, path, content))
                p_dim(f"  📄 pdf: {raw}")
            elif ext in _EXCEL_EXTS:
                content = f"[Spreadsheet attached: {path}]\nUse the excel_read tool with path=\"{path}\" to read this file."
                attachments.append((raw, path, content))
                p_dim(f"  📊 spreadsheet: {raw}")
            else:
                _MAX_AT_CHARS = 200_000
                with open(path, encoding="utf-8") as _f:
                    content = _f.read(_MAX_AT_CHARS)
                if len(content) == _MAX_AT_CHARS:
                    content += f"\n... [truncated at {_MAX_AT_CHARS:,} chars — use file_read for full content]"
                attachments.append((raw, path, content))
                p_dim(f"  📎 attached: {raw} ({len(content):,} chars)")
        except UnicodeDecodeError:
            p_warn(f"@{raw}: binary file cannot be inlined, skipped")
        except OSError as e:
            p_warn(f"@{raw}: cannot read ({e}), skipped")

    if not attachments:
        return text

    # Strip @mentions from original text, append file blocks at end
    attached_raws = {r for r, _, _ in attachments}
    clean = _AT_FILE_RE.sub(
        lambda m: "" if (m.group(1) or m.group(2) or m.group(3)) in attached_raws else m.group(0),
        text
    ).strip()
    blocks = "\n\n".join(
        f"--- @{raw} ({path}) ---\n{content}\n---"
        for raw, path, content in attachments
    )
    return f"{clean}\n\n{blocks}"


def _divider():
    from control.fmt import cyan
    width = os.get_terminal_size().columns if sys.stdout.isatty() else 72
    print(cyan("─" * width))


def _normalize_blank_lines(text: str) -> str:
    """Remove excessive blank lines (keep at most 1 blank line)."""
    import re
    # Replace 2+ consecutive newlines with a single newline
    return re.sub(r'\n{3,}', '\n\n', text)


def _render_markdown(text: str):
    """Render markdown with rich if available, else plain print."""
    # First normalize blank lines
    text = _normalize_blank_lines(text)
    try:
        from rich.console import Console
        from rich.markdown import Markdown
        Console().print(Markdown(text))
    except Exception:
        print(text)


def _run_shell_direct(brain: Brain, cmd: str):
    """Execute a shell command directly, bypassing the LLM. Output is shown to user only."""
    from control.planner import Task
    import safety.safety as _safety
    from safety.policy import is_always_allowed, remember_always, get_allowed_paths
    from control.fmt import red, yellow, cyan, dim

    if not cmd:
        return

    task = Task(id=1, tool="shell_exec", args={"command": cmd},
                description=cmd, depends_on=[])

    # Safety check
    work_dir = brain.projects.work_dir
    result = _safety.check(task, work_dir=work_dir,
                           allowed_paths=get_allowed_paths())

    if result.violation:
        print(red(f"🛑  BLOCKED  {result.reason}"))
        return

    if result.backup_paths:
        print(dim(f"💾  backup → {', '.join(result.backup_paths)}"))

    if result.requires_confirmation:
        op = result.operation_class
        if not (op and is_always_allowed(op)):
            print(yellow(f"⚠️   {result.reason}"))
            if result.can_always:
                raw = _ask("    Proceed? [y]es  [n]o  [a]lways ❯ ").lower()
            else:
                raw = _ask("    Proceed? [y]es  [n]o ❯ ").lower()
            if raw in ("a", "always") and result.can_always:
                remember_always(op)
                print(cyan(f"📌  policy saved: always allow [{op}]"))
            elif raw not in ("y", "yes"):
                print(red("🚫  cancelled"))
                return

    # Backup
    if result.backup_paths:
        from safety.backup import backup_files
        backup_files(result.backup_paths)

    # Execute — pass through stdin/stdout/stderr directly so interactive
    # commands (python, node, etc.) work normally in the terminal.
    import subprocess as _sp
    from tools.shell import _wrap_command, _popen_session_kwargs
    cwd = work_dir or os.getcwd()
    _args, _use_shell = _wrap_command(cmd)
    try:
        proc = _sp.Popen(_args, shell=_use_shell, cwd=cwd, **_popen_session_kwargs())
        proc.wait()
        if proc.returncode != 0:
            print(dim(f"  [exit {proc.returncode}]"))
    except KeyboardInterrupt:
        proc.kill()
        print()


def _run_with_output(brain: Brain, user_input: str):
    """Run one turn: stderr spinner during thinking, then render with dividers."""
    _stop = threading.Event()
    _frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    _fi = [0]

    def _spin():
        while not _stop.wait(0.1):
            sys.stderr.write(f"\r  {_frames[_fi[0] % len(_frames)]}  thinking…")
            sys.stderr.flush()
            _fi[0] += 1
        sys.stderr.write("\r\033[K")
        sys.stderr.flush()

    brain._spinner_stop = _stop
    t = threading.Thread(target=_spin, daemon=True)
    t.start()

    chunks: list[str] = []
    try:
        for chunk in brain.stream_run(user_input):
            if not _stop.is_set():
                _stop.set()
            chunks.append(chunk)
    except KeyboardInterrupt:
        _stop.set()
        t.join(timeout=1)
        raise
    finally:
        _stop.set()
        t.join(timeout=1)

    full = "".join(chunks)

    # ── Render ─────────────────────────────────────────────────────────────
    _divider()
    if full.strip():
        full = _normalize_blank_lines(full)
        if brain._last_was_action:
            # Action path: already has ANSI coloring, just print
            print(full)
        else:
            # Discussion path: render as markdown
            _render_markdown(full)
    # else: streaming already printed to stdout — just show dividers

    # ── Direct confirmation for staged resource operations ──────────────────
    # Bypass the LLM for confirmation so hallucination is impossible.
    if hasattr(brain, "resources"):
        _mgr = brain.resources
        _reg = _mgr._pending
        _del = _mgr._pending_delete
        if _reg or _del:
            _parts = []
            if _reg:
                _parts.append(f"登记 {len(_reg)} 个文件")
            if _del:
                _parts.append(f"删除 {len(_del)} 条记录")
            try:
                _answer = input(f"\n确认{' / '.join(_parts)}？[y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                _answer = ""
            if _answer in ("y", "yes", "确认", "是", "ok", "好的"):
                _result = _mgr.commit_pending()
                if _result["registered"]:
                    for _r in _result["registered"]:
                        print(p_ok(f"  ✓ 已登记 [{_r['scope']}] {_r['name']}  →  {_r['path']}"))
                if _result["deleted"]:
                    for _r in _result["deleted"]:
                        print(dim(f"  ✗ 已删除 [{_r['scope']}] {_r['name']}  →  {_r['path']}"))
            else:
                _mgr._pending = []
                _mgr._pending_delete = []
                print(dim("  已取消。"))

    _divider()
    print()


_TOP_CMDS = [
    "/quit", "/exit", "/end", "/help", "/status", "/tools",
    "/rewind", "/context",
    "/btw", "/template", "/safety", "/auto",
    "/model", "/project", "/memory", "/tasks",
]
_SUB_CMDS = {
    "project": ["list", "delete", "rename", "workdir"],
    "memory": ["set", "del", "pin"],
}
_TOGGLE_VALS = ["on", "off"]
_TOGGLE_CMDS = {"safety", "auto"}


def _make_session(brain: "Brain"):
    """Build a prompt_toolkit PromptSession with completer and status bar."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.styles import Style, DynamicStyle
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.filters import has_focus
    from prompt_toolkit.keys import Keys

    _STYLE_BASE = {
        "bottom-toolbar":         "bg:#1c1c1e #636366",
        "bottom-toolbar.divider": "bg:#1c1c1e #3a3a3c",
        "bottom-toolbar.project": "bg:#1c1c1e #5ac8fa bold",
        "bottom-toolbar.path":    "bg:#1c1c1e #8e8e93",
        "bottom-toolbar.tokens":  "bg:#1c1c1e #34c759",
        "bottom-toolbar.dry":     "bg:#1c1c1e #ffd60a",
    }

    def _make_style():
        try:
            from prompt_toolkit.application import get_app
            shell_mode = get_app().current_buffer.text.startswith("!")
        except Exception:
            shell_mode = False
        extra = {"": "bg:#3a0000"} if shell_mode else {}
        return Style.from_dict({**_STYLE_BASE, **extra})

    style = DynamicStyle(_make_style)

    class _Completer(Completer):
        def get_completions(self, document, complete_event):
            text = document.text_before_cursor

            # @file completion: triggered when last word starts with @
            words = text.split()
            if words:
                last = words[-1]
                if last.startswith("@"):
                    raw = last[1:]
                    path = os.path.expanduser(raw) if raw else ""
                    work_dir = brain.projects.work_dir or os.getcwd()
                    base = path if os.path.isabs(path) else os.path.join(work_dir, path)
                    # List directory or complete partial name
                    if path.endswith("/") or not path:
                        dir_path = base
                        prefix = ""
                    else:
                        dir_path = os.path.dirname(base) or work_dir
                        prefix = os.path.basename(base)
                    try:
                        entries = sorted(os.listdir(dir_path))
                    except OSError:
                        entries = []
                    for entry in entries:
                        if entry.startswith("."):
                            continue
                        if entry.lower().startswith(prefix.lower()):
                            full = os.path.join(dir_path, entry)
                            suffix = "/" if os.path.isdir(full) else ""
                            completion = entry[len(prefix):] + suffix
                            display = entry + suffix
                            yield Completion(completion, display=display)
                    return

            if not text.startswith("/"):
                return
            parts = text.split()
            trailing = text.endswith(" ")

            if not parts or (len(parts) == 1 and not trailing):
                prefix = parts[0] if parts else "/"
                for cmd in _TOP_CMDS:
                    if cmd.startswith(prefix):
                        yield Completion(cmd[len(prefix):], display=cmd)

            elif len(parts) == 1 and trailing:
                cmd = parts[0].lstrip("/")
                if cmd == "model":
                    for alias in brain.list_models():
                        yield Completion(alias)
                else:
                    opts = _SUB_CMDS.get(cmd, _TOGGLE_VALS if cmd in _TOGGLE_CMDS else [])
                    for o in opts:
                        yield Completion(o)

            elif len(parts) == 2 and not trailing:
                cmd = parts[0].lstrip("/")
                prefix = parts[1]
                if cmd == "model":
                    for alias in brain.list_models():
                        if alias.startswith(prefix):
                            yield Completion(alias[len(prefix):], display=alias)
                else:
                    opts = _SUB_CMDS.get(cmd, _TOGGLE_VALS if cmd in _TOGGLE_CMDS else [])
                    for o in opts:
                        if o.startswith(prefix):
                            yield Completion(o[len(prefix):], display=o)

            elif (parts[0] == "/project" and len(parts) >= 2
                  and parts[1] == "switch"):
                prefix = parts[2] if len(parts) == 3 and not trailing else ""
                try:
                    for p in brain.projects.list_projects():
                        if p["name"].startswith(prefix):
                            yield Completion(p["name"][len(prefix):],
                                             display=p["name"])
                except Exception:
                    pass

    def _toolbar():
        import shutil
        from tools.shell import get_bg_processes
        width = shutil.get_terminal_size((80, 24)).columns
        project = brain.projects.current_project
        wd = brain.projects.work_dir or ""
        home = os.path.expanduser("~")
        if wd:
            wd = wd.replace(home, "~")
        tokens = getattr(brain.memory, "_last_context_tokens", 0)
        tok_str = f"{tokens:,} tokens" if tokens else "0 tokens"
        compress_count = getattr(brain.memory, "_compress_count", 0)
        compress_part = (f" <bottom-toolbar.dry>[compressed×{compress_count}]</bottom-toolbar.dry>"
                         f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if compress_count else ""

        active = brain._agent_cfg.get("active_model", "") or brain.llm.model
        divider = "─" * width
        wd_part = (f" <bottom-toolbar.path>{wd}</bottom-toolbar.path>"
                   f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if wd else ""
        auto_part = (f" <bottom-toolbar.dry>AUTO</bottom-toolbar.dry>"
                     f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if brain.auto_mode else ""
        bypass_part = (f" <bottom-toolbar.dry>⚡UNSAFE</bottom-toolbar.dry>"
                       f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if brain.bypass_safety else ""
        _n_bg = len(get_bg_processes())
        shell_part = (f" <bottom-toolbar.dry>{_n_bg} shell</bottom-toolbar.dry>"
                      f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if _n_bg else ""

        return HTML(
            f"<bottom-toolbar.divider>{divider}</bottom-toolbar.divider>\n"
            f" <bottom-toolbar.project>{project}</bottom-toolbar.project>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f" <bottom-toolbar.path>{active}</bottom-toolbar.path>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f"{wd_part}{auto_part}{bypass_part}{compress_part}{shell_part}"
            f" <bottom-toolbar.tokens>{tok_str}</bottom-toolbar.tokens>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f" <bottom-toolbar.path>Esc+↵ newline · Ctrl+C cancel</bottom-toolbar.path> "
        )

    # Key bindings: Enter submits, Escape+Enter / Alt+Enter inserts newline
    kb = KeyBindings()

    @kb.add("enter")
    def _submit(event):
        event.current_buffer.validate_and_handle()

    @kb.add("escape", "enter")
    def _newline(event):
        event.current_buffer.insert_text("\n")

    @kb.add("c-j")  # Ctrl+J also inserts newline (classic Unix)
    def _newline_cj(event):
        event.current_buffer.insert_text("\n")

    @kb.add("escape", "up")  # Alt+↑ history previous (multiline mode)
    def _hist_prev(event):
        event.current_buffer.history_backward()

    @kb.add("escape", "down")  # Alt+↓ history next (multiline mode)
    def _hist_next(event):
        event.current_buffer.history_forward()

    session = PromptSession(
        history=FileHistory(_HISTORY_FILE),
        completer=_Completer(),
        complete_while_typing=False,
        bottom_toolbar=_toolbar,
        style=style,
        refresh_interval=1.0,
        multiline=True,
        key_bindings=kb,
        prompt_continuation=lambda width, line_number, is_soft_wrap: "  ",
    )
    return session


def main():
    import argparse
    import logging
    from control.project_manager import is_auto_named

    parser = argparse.ArgumentParser()
    parser.add_argument("--project", "-p", default=None,
                        help="Switch to a named project instead of creating a new auto session")
    parser.add_argument("--version", "-V", action="store_true",
                        help="Show version and exit")
    args = parser.parse_args()

    if args.version:
        try:
            from importlib.metadata import version
            print(version("memocode"))
        except Exception:
            print("0.5.3")
        return

    import tempfile
    from logging.handlers import RotatingFileHandler

    _log_fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")

    # INFO → ~/.mcode/chatmem.log  (persistent operational log)
    _info_log_path = os.path.expanduser("~/.mcode/chatmem.log")
    os.makedirs(os.path.dirname(_info_log_path), exist_ok=True)
    _info_handler = logging.FileHandler(_info_log_path, encoding="utf-8")
    _info_handler.setLevel(logging.INFO)
    _info_handler.setFormatter(_log_fmt)

    # DEBUG → {tempdir}/mcode_debug.log  (rotating, 1 MB × 3, ephemeral)
    _debug_log_path = os.path.join(tempfile.gettempdir(), "mcode_debug.log")
    _debug_handler = RotatingFileHandler(
        _debug_log_path, maxBytes=1024 * 1024, backupCount=3, encoding="utf-8"
    )
    _debug_handler.setLevel(logging.DEBUG)
    _debug_handler.setFormatter(_log_fmt)

    _chatmem_logger = logging.getLogger("chatmem")
    _chatmem_logger.addHandler(_info_handler)
    _chatmem_logger.addHandler(_debug_handler)
    _chatmem_logger.setLevel(logging.DEBUG)

    try:
        brain = Brain(project=args.project or None)
    except RuntimeError as e:
        from control.fmt import yellow, dim
        print(yellow(f"\n  ✗  {e}"))
        print()
        print("  Quick setup:")
        print("    1. Edit ~/.mcode/agent.json and set 'active_model'")
        print("    2. Add your model config under 'models' (see README for examples)")
        print("    3. Export the required API key, e.g.:")
        print(dim("         export MINIMAX_API_KEY=your_key_here"))
        print()
        raise SystemExit(1)
    session = _make_session(brain)

    # Ensure end_session() is called even on Ctrl+C / SIGTERM / unexpected exit
    import atexit, signal as _signal

    def _on_exit():
        if not getattr(brain, "_session_ended", False):
            try:
                brain.end_session()
            except (Exception, KeyboardInterrupt, SystemExit):
                pass

    atexit.register(_on_exit)
    def _on_sigterm(*_):
        _on_exit()
        raise SystemExit(0)

    try:
        _signal.signal(_signal.SIGTERM, _on_sigterm)
    except (OSError, ValueError):
        pass  # not in main thread

    # Clean up stale auto-named projects first
    stale = brain.projects.cleanup_stale()
    if stale:
        p_dim(f"[cleanup] removed {len(stale)} stale session(s): {', '.join(stale)}")

    # Start in a named project or create a fresh auto-named one
    if args.project:
        try:
            brain.switch_project(args.project)
            p_info(f"[project] {args.project}")
        except FileNotFoundError:
            brain.projects.new_project(args.project)
            brain.switch_project(args.project)
            p_info(f"[project] created: {args.project}")
    else:
        # Resume the last project if it exists; create a new auto-named one only on first run
        cur = brain.projects.current_project
        from control.project_manager import is_auto_named, DEFAULT_PROJECT
        if cur == DEFAULT_PROJECT:
            # First-ever run: replace the placeholder "default" with a real auto session
            auto_name = brain.projects.new_auto_project()
            brain.switch_project(auto_name)
        # else: keep current project — resume last session automatically

    _print_logo(brain)
    p_dim(f"  [debug log] {_debug_log_path}")
    _show_recent_turns(brain)

    # Process pending sessions synchronously so recent_memory is complete before first turn
    _pending_count = len(brain.memory.load_pending_sessions())
    if _pending_count:
        import threading as _threading
        _sync_stop = _threading.Event()
        def _sync_spin():
            frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
            i = 0
            while not _sync_stop.is_set():
                sys.stdout.write(f"\r  {frames[i % len(frames)]}  同步记忆中...")
                sys.stdout.flush()
                _sync_stop.wait(0.1)
                i += 1
            sys.stdout.write("\r\033[K")
            sys.stdout.flush()
        _spin_t = _threading.Thread(target=_sync_spin, daemon=True)
        _spin_t.start()
        brain.process_pending_sessions(blocking=True)
        _sync_stop.set()
        _spin_t.join()
        p_dim(f"  [memory] synced {_pending_count} session(s)")
    else:
        brain.process_pending_sessions(blocking=True)

    # Resource registry sync (already running in background thread)
    n_res = len(brain.resources.list_all())
    if n_res:
        print(cyan(f"[Background Sync] Checking {n_res} resource(s) for changes..."))

    # Open task reminder
    _open_tasks = brain.tasks.open_tasks() if hasattr(brain, "tasks") else []
    if _open_tasks:
        print(cyan(f"[Tasks] {len(_open_tasks)} open task(s) — /memory to view"))

    _had_conversation = False
    _divider()
    while True:
        try:
            user_input = session.prompt("❯ ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye.")
            break

        if not user_input:
            continue

        # Multiline input: first line may be slash command — only use first line for that check
        first_line = user_input.splitlines()[0].strip()

        _divider()

        if first_line.startswith("/"):
            try:
                handle_slash(first_line, brain)
            except SystemExit:
                break
            print()
            continue

        if first_line.startswith("!"):
            _run_shell_direct(brain, first_line[1:].strip())
            print()
            continue

        # If user types a bare tool name, expand to an explicit call directive
        # so the model doesn't confuse it with a query and hallucinate results.
        _bare = first_line.strip().lower().replace("-", "_")
        if _bare in {t.name for t in brain.registry.list()}:
            user_input = f"Call the {first_line.strip()} tool now and show me the result."


        _had_conversation = True
        brain._session_ended = False  # new turn — reset flag
        user_input, _img_blocks, _img_names = _extract_image_blocks(user_input, brain.projects.work_dir)
        user_input = _expand_at_files(user_input, brain.projects.work_dir)
        if _img_blocks:
            _img_note = "  ".join(f"[image: {n}]" for n in _img_names)
            _text_with_note = f"{_img_note}\n{user_input}".strip()
            user_content: "str | list" = [{"type": "text", "text": _text_with_note}] + _img_blocks
        else:
            user_content = user_input
        try:
            _run_with_output(brain, user_content)
        except KeyboardInterrupt:
            _divider()
            print()
        except Exception as e:
            from control.fmt import red
            import traceback
            logging.getLogger("chatmem").debug(
                "Unhandled exception:\n%s", traceback.format_exc()
            )
            _divider()
            print(red(f"  ✗  {type(e).__name__}: {e}"))
            traceback.print_exc()
            _divider()
            print()

    if not getattr(brain, "_session_ended", False):
        try:
            brain.end_session()
        except (KeyboardInterrupt, Exception):
            pass

    # Hint to rename if it was an auto-named session with actual content
    p = brain.projects.current_project
    if _had_conversation and is_auto_named(p):
        p_info(f"[tip] save this session: /project rename {p} <name>")


if __name__ == "__main__":
    main()
