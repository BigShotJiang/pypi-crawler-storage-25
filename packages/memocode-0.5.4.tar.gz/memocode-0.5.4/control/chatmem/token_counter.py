"""
Token counting for LLM messages.
Used internally to measure context size and trigger compression.

Chinese character ratio: per MiniMax/Kimi official docs, 1600 Chinese chars ≈ 1000 tokens
(0.625 tokens/char). tiktoken cl100k_base assumes ~1 token/char for Chinese, causing ~1.6×
overestimation. We correct for this by detecting Chinese characters and applying the
official ratio.
"""

from typing import Any


# Tokens per character factors based on official provider documentation.
# Chinese (U+4E00–U+9FFF): MiniMax/Kimi docs: 1600 chars ≈ 1000 tokens → 0.625 tokens/char
# Non-Chinese printable: ~0.25 tokens/char (4 ASCII chars ≈ 1 token, standard heuristic)
_CHINESE_TPС = 0.625
_OTHER_TPC   = 0.25


def count_tokens(text: str, model: str = "") -> int:
    """Count tokens in a plain text string using a character-based heuristic.

    Applies separate rates for Chinese characters (0.625 tokens/char) vs. other
    content (0.25 tokens/char), matching MiniMax/Kimi/GLM tokenizer behaviour.
    """
    if not text:
        return 0
    chinese = sum(1 for c in text if "\u4e00" <= c <= "\u9fff")
    other = len(text) - chinese
    return max(1, int(chinese * _CHINESE_TPС + other * _OTHER_TPC))


def count_message_tokens(message: dict[str, Any], model: str = "") -> int:
    """Count tokens for a single message dict. Includes per-message overhead (~4 tokens)."""
    content = message.get("content", "")
    if isinstance(content, list):
        text = " ".join(
            part.get("text", "") for part in content if isinstance(part, dict)
        )
    else:
        text = str(content) if content else ""
    return count_tokens(text) + 4  # role + content separators


def count_messages_tokens(
    messages: list[dict[str, Any]], model: str = ""
) -> int:
    """Count total tokens for a list of messages (full conversation)."""
    total = sum(count_message_tokens(m) for m in messages)
    total += 3  # conversation-level overhead
    return total
