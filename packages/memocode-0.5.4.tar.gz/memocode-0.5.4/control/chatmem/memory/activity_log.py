"""
Activity log: append-only per-turn record with timestamps.
Answers "what did we do on date X" accurately — no BM25, no LLM inference.
Each row: timestamp + user_msg (truncated) + assistant_preview.
"""

import sqlite3
import time
from datetime import datetime


_USER_MSG_MAX = 200
_ASST_PREVIEW_MAX = 200


class ActivityLog:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    turn_id INTEGER NOT NULL,
                    user_msg TEXT NOT NULL,
                    assistant_preview TEXT,
                    created_at REAL NOT NULL
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_al_time ON activity_log(created_at)"
            )

    def add(self, turn_id: int, user_msg: str, assistant_preview: str = ""):
        """Record one turn. Called at end of each turn."""
        user_trunc = user_msg[:_USER_MSG_MAX]
        asst_trunc = assistant_preview[:_ASST_PREVIEW_MAX]
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO activity_log (turn_id, user_msg, assistant_preview, created_at) VALUES (?, ?, ?, ?)",
                (turn_id, user_trunc, asst_trunc, time.time()),
            )

    def recent(self, limit: int = 15) -> list[dict]:
        """Return the most recent N entries, newest first."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT turn_id, user_msg, assistant_preview, created_at "
                "FROM activity_log ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {
                "turn_id": r["turn_id"],
                "user_msg": r["user_msg"],
                "assistant_preview": r["assistant_preview"],
                "time": datetime.fromtimestamp(r["created_at"]).strftime("%H:%M"),
                "date": datetime.fromtimestamp(r["created_at"]).strftime("%Y-%m-%d"),
            }
            for r in rows
        ]

    def query(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[dict]:
        """
        Return activity entries within the date range.
        start_date / end_date: "YYYY-MM-DD". Both inclusive.
        If neither is given, returns today's entries.
        """
        today = datetime.now().strftime("%Y-%m-%d")
        sd = start_date or today
        ed = end_date or today

        try:
            ts_start = datetime.strptime(sd, "%Y-%m-%d").replace(
                hour=0, minute=0, second=0
            ).timestamp()
        except ValueError:
            ts_start = 0.0
        try:
            ts_end = datetime.strptime(ed, "%Y-%m-%d").replace(
                hour=23, minute=59, second=59
            ).timestamp()
        except ValueError:
            ts_end = time.time()

        with self._conn() as conn:
            rows = conn.execute(
                "SELECT turn_id, user_msg, assistant_preview, created_at "
                "FROM activity_log WHERE created_at >= ? AND created_at <= ? "
                "ORDER BY created_at ASC",
                (ts_start, ts_end),
            ).fetchall()

        return [
            {
                "turn_id": r["turn_id"],
                "user_msg": r["user_msg"],
                "assistant_preview": r["assistant_preview"],
                "time": datetime.fromtimestamp(r["created_at"]).strftime("%H:%M"),
                "date": datetime.fromtimestamp(r["created_at"]).strftime("%Y-%m-%d"),
            }
            for r in rows
        ]
