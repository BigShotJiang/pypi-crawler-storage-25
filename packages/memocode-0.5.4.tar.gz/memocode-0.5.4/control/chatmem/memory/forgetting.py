"""
Forgetting mechanism (Ebbinghaus-inspired) for core memory and recent memory.
Manages decay scores so stale/unused entries fade over time.
"""

import math
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .core_memory import CoreMemory
    from .recent_memory import RecentMemory


def compute_score(
    created_at: float,
    stability: float,
    last_accessed_at: float | None = None,
) -> float:
    now = time.time()
    reference_time = last_accessed_at if last_accessed_at else created_at
    days_elapsed = (now - reference_time) / 86400.0
    return min(math.exp(-days_elapsed / stability), 1.0)


class ForgettingManager:
    """
    Runs decay updates for core memory and recent memory.
    Call run_decay() periodically (every N turns).
    """

    def __init__(self, core_memory: "CoreMemory", recent_memory: "RecentMemory | None" = None):
        self.core = core_memory
        self.recent = recent_memory

    def run_decay(self):
        # Core memory decay
        entries = self.core.get_all_with_scores()
        for entry in entries:
            new_score = compute_score(
                created_at=entry["created_at"],
                stability=entry["stability"],
                last_accessed_at=entry.get("updated_at"),
            )
            self.core.update_score(entry["key"], new_score)

        # Recent memory decay
        if self.recent:
            entries = self.recent.get_all_with_scores()
            for entry in entries:
                new_score = compute_score(
                    created_at=entry["created_at"],
                    stability=entry.get("stability", 21.0),
                    last_accessed_at=entry.get("last_accessed_at"),
                )
                self.recent.update_score(entry["id"], new_score)
