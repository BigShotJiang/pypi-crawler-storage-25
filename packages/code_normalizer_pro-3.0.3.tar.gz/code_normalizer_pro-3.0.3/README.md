# code-normalizer-pro

A CLI tool that normalizes encoding, line endings, and whitespace across a codebase.

## Install

pip install code-normalizer-pro

## Usage

code-normalizer-pro . --dry-run -e .py
