from enum import StrEnum
from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from nexo.types.string import ListOfStrs


class IdentifierType(StrEnum):
    ID = "id"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]

    @property
    def column(self) -> str:
        return self.value


class Trigger(StrEnum):
    MANUAL = "manual"
    MESSAGE = "message"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


TriggerT = TypeVar("TriggerT", bound=Trigger)
OptTrigger = Trigger | None
OptTriggerT = TypeVar("OptTriggerT", bound=OptTrigger)


class TriggerMixin(BaseModel, Generic[OptTriggerT]):
    trigger: Annotated[OptTriggerT, Field(..., description="Trigger")]
