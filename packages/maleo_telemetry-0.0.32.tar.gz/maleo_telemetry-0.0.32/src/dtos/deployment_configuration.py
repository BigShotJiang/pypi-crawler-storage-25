import json
from pydantic import BaseModel, Field
from typing import Annotated, Generic
from uuid import UUID
from nexo.enums.service import ServiceType, FullServiceTypeMixin
from nexo.enums.status import DataStatus, SimpleDataStatusMixin
from nexo.schemas.mixins.identity import UUIDId
from nexo.types.string import ListOfStrs, OptListOfStrs, ManyStrs
from ..enums.deployment_configuration import (
    IdentifierType,
    Restart,
    OptRestartT,
    RestartMixin,
)
from ..mixins.common import ServiceKey
from ..mixins.deployment_configuration import (
    RegistryUrl,
    Tag,
    Volumes,
    Extra,
    Targets,
    IsAutoDeploy,
)
from ..types.deployment_configuration import IdentifierValueType


class RunArgs(
    Extra[OptListOfStrs],
    Volumes[OptListOfStrs],
    RestartMixin[OptRestartT],
    Generic[OptRestartT],
):
    volumes: Annotated[
        OptListOfStrs, Field(None, description="Volumes", min_length=1)
    ] = None
    extra: Annotated[OptListOfStrs, Field(None, description="Extra", min_length=1)] = (
        None
    )


class RunArgsMixin(BaseModel, Generic[OptRestartT]):
    args: Annotated[
        RunArgs[OptRestartT], Field(..., description="Docker run arguments")
    ]


class DeploymentConfigurationDTO(
    IsAutoDeploy[bool],
    Targets[ListOfStrs],
    RunArgs[Restart],
    Tag[str],
    RegistryUrl[str],
    FullServiceTypeMixin[ServiceType],
    ServiceKey[str],
    SimpleDataStatusMixin[DataStatus],
    UUIDId[UUID],
):
    @property
    def _identifiers(self) -> tuple[tuple[IdentifierType, IdentifierValueType], ...]:
        return (
            (IdentifierType.ID, str(self.id)),
            (IdentifierType.SERVICE_KEY, self.service_key),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )
