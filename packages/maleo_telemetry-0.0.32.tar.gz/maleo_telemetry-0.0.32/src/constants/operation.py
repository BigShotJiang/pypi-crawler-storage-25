from nexo.schemas.resource import Resource, ResourceIdentifier

OPERATION_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(key="operation", name="Operation", slug="operations")
    ],
    details=None,
)
