from nexo.schemas.resource import Resource, ResourceIdentifier

DEPLOYMENT_CONFIGURATION_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="deployment_configuration",
            name="Deployment Configuration",
            slug="deployment-configurations",
        )
    ],
    details=None,
)
