from pydantic import Field
from typing import Annotated, Literal, Self, overload
from uuid import UUID
from nexo.enums.service import OptListOfServiceTypes, FullServiceTypesMixin
from nexo.enums.status import (
    ListOfDataStatuses,
    FULL_DATA_STATUSES,
)
from nexo.schemas.mixins.filter import ListOfRangeFilters, convert as convert_filter
from nexo.schemas.mixins.identity import (
    UUIDId,
    UUIDIds,
)
from nexo.schemas.mixins.sort import ListOfSortColumns, convert as convert_sort
from nexo.schemas.pagination import Limit
from nexo.schemas.parameter import (
    ReadSingleParameter as BaseReadSingleParameter,
    ReadPaginatedMultipleParameter,
)
from nexo.types.dict import StrToAnyDict
from nexo.types.string import OptStr, OptListOfStrs
from nexo.types.uuid import OptListOfUUIDs
from ..dtos.deployment import TriggerDTO
from ..dtos.deployment_configuration import RunArgs
from ..enums.deployment_configuration import Restart
from ..enums.deployment import IdentifierType
from ..mixins.common import ServiceKeys, Service
from ..mixins.deployment_configuration import (
    ConfigurationIds,
    RegistryUrl,
    Tag,
    Target,
    DeploymentConfigurationIdentifier,
)
from ..mixins.deployment import DeploymentIdentifier
from ..types.deployment import IdentifierValueType


class CreateParameter(
    Target[str],
    DeploymentConfigurationIdentifier,
):
    @property
    def configuration_identifier(self) -> DeploymentConfigurationIdentifier:
        return DeploymentConfigurationIdentifier.model_validate(self.model_dump())


class ReadMultipleParameter(
    ReadPaginatedMultipleParameter,
    FullServiceTypesMixin[OptListOfServiceTypes],
    ServiceKeys[OptListOfStrs],
    ConfigurationIds[OptListOfUUIDs],
    UUIDIds[OptListOfUUIDs],
):
    ids: Annotated[OptListOfUUIDs, Field(None, description="Ids")] = None
    configuration_ids: Annotated[
        OptListOfUUIDs, Field(None, description="Configuration's IDs", min_length=1)
    ] = None
    service_keys: Annotated[
        OptListOfStrs, Field(None, description="Service's Keys")
    ] = None
    service_types: Annotated[
        OptListOfServiceTypes, Field(None, description="Service Types")
    ] = None

    @classmethod
    def new(
        cls,
        ids: OptListOfUUIDs = None,
        range_filters: ListOfRangeFilters = ListOfRangeFilters(),
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        configuration_ids: OptListOfUUIDs = None,
        service_keys: OptListOfStrs = None,
        service_types: OptListOfServiceTypes = None,
        search: OptStr = None,
        sort_columns: ListOfSortColumns = ListOfSortColumns(),
        page: int = 1,
        limit: Limit = Limit.LIM_10,
        use_cache: bool = True,
    ) -> Self:
        return cls(
            ids=ids,
            configuration_ids=configuration_ids,
            service_keys=service_keys,
            service_types=service_types,
            range_filters=range_filters,
            statuses=statuses,
            search=search,
            sort_columns=sort_columns,
            page=page,
            limit=limit,
            use_cache=use_cache,
        )

    @property
    def _query_param_fields(self) -> set[str]:
        return {
            "ids",
            "statuses",
            "configuration_ids",
            "service_keys",
            "service_types",
            "search",
            "page",
            "limit",
            "use_cache",
        }

    def to_query_params(self) -> StrToAnyDict:
        params = self.model_dump(
            mode="json", include=self._query_param_fields, exclude_none=True
        )
        params["filters"] = convert_filter(self.range_filters)
        params["sorts"] = convert_sort(self.sort_columns)
        params = {k: v for k, v in params.items()}
        return params


class ReadSingleParameter(BaseReadSingleParameter[DeploymentIdentifier]):
    @classmethod
    def from_identifier(
        cls,
        identifier: DeploymentIdentifier,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls(identifier=identifier, statuses=statuses, use_cache=use_cache)

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: UUID,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls(
            identifier=DeploymentIdentifier(
                type=identifier_type, value=identifier_value
            ),
            statuses=statuses,
            use_cache=use_cache,
        )

    def to_query_params(self) -> StrToAnyDict:
        return self.model_dump(
            mode="json", include={"statuses", "use_cache"}, exclude_none=True
        )


class DeploymentSchema(
    TriggerDTO,
    Target[str],
    RunArgs[Restart],
    Tag[str],
    RegistryUrl[str],
    Service,
    UUIDId[UUID],
):
    pass
