import json
from datetime import datetime
from google.cloud.pubsub_v1.subscriber.message import Message
from pydantic import Field
from typing import Annotated, Self
from uuid import UUID
from nexo.infra.resource.enums import Status
from nexo.infra.resource.schemas import Usage
from nexo.schemas.mixins.identity import UUIDId
from nexo.schemas.mixins.timestamp import CreationTimestamp
from ..mixins.common import MessageInfo, ApplicationContext


class CreateParameter(
    ApplicationContext,
    MessageInfo,
):
    measured_at: Annotated[datetime, Field(..., description="Measured at timestamp")]
    status: Annotated[Status, Field(..., description="Aggregate status")]
    usage: Annotated[Usage, Field(..., description="Resource usage")]

    @classmethod
    def from_message(cls, message: Message) -> Self:
        return cls.model_validate(
            {
                **json.loads(message.data.decode("utf-8")),
                **message.attributes,
                "message_id": message.message_id,
                "published_at": message.publish_time,
            }
        )


class ResourceMeasurementSchema(
    CreateParameter,
    CreationTimestamp,
    UUIDId[UUID],
):
    pass
