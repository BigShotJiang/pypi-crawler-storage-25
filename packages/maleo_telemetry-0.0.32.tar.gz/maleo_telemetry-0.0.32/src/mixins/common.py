from datetime import datetime
from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from maleo.identity.schemas.service import StandardServiceSchema
from nexo.enums.environment import Environment, EnvironmentMixin
from nexo.types.datetime import OptDatetimeT
from nexo.types.string import OptStrT, OptListOfStrsT


class MessageId(BaseModel, Generic[OptStrT]):
    message_id: Annotated[OptStrT, Field(..., description="Message's ID")]


class MessageIds(BaseModel, Generic[OptListOfStrsT]):
    message_ids: Annotated[
        OptListOfStrsT, Field(..., description="Message's IDs", min_length=1)
    ]


MessageT = TypeVar("MessageT", bound=BaseModel | None)


class Message(BaseModel, Generic[MessageT]):
    message: Annotated[MessageT, Field(..., description="Message")]


class PublishedAt(BaseModel, Generic[OptDatetimeT]):
    published_at: Annotated[OptDatetimeT, Field(..., description="Published At")]


class MessageInfo(PublishedAt[datetime], MessageId[str]):
    pass


class InstanceId(BaseModel):
    instance_id: Annotated[str, Field(..., description="Instance's ID")]


class InstanceIds(BaseModel, Generic[OptListOfStrsT]):
    instance_ids: Annotated[
        OptListOfStrsT, Field(..., description="Instance's IDs", min_length=1)
    ]


class ServiceKey(BaseModel, Generic[OptStrT]):
    service_key: Annotated[OptStrT, Field(..., description="Service's Key")]


class ServiceKeys(BaseModel, Generic[OptListOfStrsT]):
    service_keys: Annotated[
        OptListOfStrsT, Field(..., description="Service's Keys", min_length=1)
    ]


class Service(BaseModel):
    service: Annotated[StandardServiceSchema, Field(..., description="Service")]


class ApplicationContext(
    ServiceKey[str],
    EnvironmentMixin[Environment],
    InstanceId,
):
    pass
