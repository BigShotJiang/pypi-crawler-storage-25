from pydantic import BaseModel, Field
from typing import Annotated, Generic, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from nexo.schemas.operation.enums import (
    ResourceOperationType,
    ResourceOperationTypeT,
    OptResourceOperationReadType,
    OptResourceOperationUpdateType,
    OptResourceOperationDataUpdateType,
    OptResourceOperationStatusUpdateType,
    SystemOperationType,
    WebSocketOperationType,
)
from nexo.types.dict import OptStrToAnyDict
from nexo.types.enum import StrEnumT
from nexo.types.uuid import OptUUIDT, OptListOfUUIDsT
from ..enums.operation import IdentifierType
from ..types.operation import IdentifierValueType


class CustomnId(BaseModel, Generic[OptUUIDT]):
    id_: Annotated[
        OptUUIDT, Field(..., description="Operation's ID", validation_alias="id")
    ]


class CustomnIds(BaseModel, Generic[OptListOfUUIDsT]):
    ids_: Annotated[
        OptListOfUUIDsT, Field(..., description="Operation's IDs", min_length=1)
    ]


class BaseOperationAction(BaseModel, Generic[StrEnumT]):
    type: Annotated[StrEnumT, Field(..., description="Action's type")]


class SimpleOperationAction(BaseOperationAction[StrEnumT], Generic[StrEnumT]):
    details: Annotated[OptStrToAnyDict, Field(None, description="Action's details")] = (
        None
    )


class ResourceOperationAction(
    BaseOperationAction[ResourceOperationTypeT], Generic[ResourceOperationTypeT]
):
    pass


class CreateResourceOperationAction(
    ResourceOperationAction[Literal[ResourceOperationType.CREATE]]
):
    type: Literal[ResourceOperationType.CREATE] = ResourceOperationType.CREATE


class ReadResourceOperationAction(
    ResourceOperationAction[Literal[ResourceOperationType.READ]]
):
    type: Literal[ResourceOperationType.READ] = ResourceOperationType.READ
    read_type: Annotated[
        OptResourceOperationReadType,
        Field(None, description="Read type (optional)"),
    ] = None


class UpdateResourceOperationAction(
    ResourceOperationAction[Literal[ResourceOperationType.UPDATE]]
):
    type: Literal[ResourceOperationType.UPDATE] = ResourceOperationType.UPDATE
    update_type: Annotated[
        OptResourceOperationUpdateType,
        Field(None, description="Update type (optional)"),
    ] = None
    data_update_type: Annotated[
        OptResourceOperationDataUpdateType,
        Field(None, description="Data update type (optional)"),
    ] = None
    status_update_type: Annotated[
        OptResourceOperationStatusUpdateType,
        Field(None, description="Status update type (optional)"),
    ] = None


class DeleteResourceOperationAction(
    ResourceOperationAction[Literal[ResourceOperationType.DELETE]]
):
    type: Literal[ResourceOperationType.DELETE] = ResourceOperationType.DELETE


AnyResourceOperationAction = (
    CreateResourceOperationAction
    | ReadResourceOperationAction
    | UpdateResourceOperationAction
    | DeleteResourceOperationAction
)


class SystemOperationAction(SimpleOperationAction[SystemOperationType]):
    pass


class WebSocketOperationAction(SimpleOperationAction[WebSocketOperationType]):
    pass


AnyOperationAction = (
    AnyResourceOperationAction | SystemOperationAction | WebSocketOperationAction
)


class OperationActionMixin(BaseModel):
    action: Annotated[AnyOperationAction, Field(..., description="Operation's Action")]


class OperationIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdOperationIdentifier(Identifier[Literal[IdentifierType.ID], UUID]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID


class MessageIdOperationIdentifier(Identifier[Literal[IdentifierType.MESSAGE_ID], str]):
    type: Annotated[
        Literal[IdentifierType.MESSAGE_ID],
        Field(IdentifierType.MESSAGE_ID, description="Identifier's type"),
    ] = IdentifierType.MESSAGE_ID
    value: Annotated[str, Field(..., description="Identifier's value")]


AnyOperationIdentifier = (
    OperationIdentifier | IdOperationIdentifier | MessageIdOperationIdentifier
)


def is_id_identifier(
    identifier: AnyOperationIdentifier,
) -> TypeGuard[IdOperationIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, UUID)


def is_message_id_identifier(
    identifier: AnyOperationIdentifier,
) -> TypeGuard[MessageIdOperationIdentifier]:
    return identifier.type is IdentifierType.MESSAGE_ID and isinstance(
        identifier.value, str
    )
