from nexo.schemas.mixins.identity import Identifier
from ..enums.deployment import IdentifierType
from ..types.deployment import IdentifierValueType


class DeploymentIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value
