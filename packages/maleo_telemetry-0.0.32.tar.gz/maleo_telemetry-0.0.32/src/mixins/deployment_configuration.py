from pydantic import BaseModel, Field
from typing import Annotated, Generic, Literal, TypeGuard, TypeVar
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from nexo.types.boolean import OptBoolT
from nexo.types.string import OptStrT, OptListOfStrsT
from nexo.types.uuid import OptUUID, OptListOfUUIDs
from ..enums.deployment_configuration import IdentifierType
from ..types.deployment_configuration import IdentifierValueType

ConfigurationIdT = TypeVar("ConfigurationIdT", bound=OptUUID)


class ConfigurationId(BaseModel, Generic[ConfigurationIdT]):
    configuration_id: Annotated[
        ConfigurationIdT, Field(..., description="Configuration's ID")
    ]


ConfigurationIdsT = TypeVar("ConfigurationIdsT", bound=OptListOfUUIDs)


class ConfigurationIds(BaseModel, Generic[ConfigurationIdsT]):
    configuration_ids: Annotated[
        ConfigurationIdsT, Field(..., description="Configuration's IDs", min_length=1)
    ]


class Registry(BaseModel, Generic[OptStrT]):
    registry: Annotated[OptStrT, Field(..., description="Registry")]


class RegistryUrl(BaseModel, Generic[OptStrT]):
    registry_url: Annotated[OptStrT, Field(..., description="Registry URL")]


class Tag(BaseModel, Generic[OptStrT]):
    tag: Annotated[OptStrT, Field(..., description="Tag")]


class Volumes(BaseModel, Generic[OptListOfStrsT]):
    volumes: Annotated[OptListOfStrsT, Field(..., description="Volumes", min_length=1)]


class Extra(BaseModel, Generic[OptListOfStrsT]):
    extra: Annotated[OptListOfStrsT, Field(..., description="Extra", min_length=1)]


class Target(BaseModel, Generic[OptStrT]):
    target: Annotated[OptStrT, Field(..., description="Target")]


class Targets(BaseModel, Generic[OptListOfStrsT]):
    targets: Annotated[OptListOfStrsT, Field(..., description="Targets", min_length=1)]


class IsAutoDeploy(BaseModel, Generic[OptBoolT]):
    is_auto_deploy: Annotated[
        OptBoolT, Field(..., description="Whether is auto deploy")
    ]


class DeploymentConfigurationIdentifier(
    Identifier[IdentifierType, IdentifierValueType]
):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdDeploymentConfigurationIdentifier(Identifier[Literal[IdentifierType.ID], UUID]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID


class ServiceKeyDeploymentConfigurationIdentifier(
    Identifier[Literal[IdentifierType.SERVICE_KEY], str]
):
    type: Annotated[
        Literal[IdentifierType.SERVICE_KEY],
        Field(IdentifierType.SERVICE_KEY, description="Identifier's type"),
    ] = IdentifierType.SERVICE_KEY


AnyDeploymentConfigurationIdentifier = (
    DeploymentConfigurationIdentifier
    | IdDeploymentConfigurationIdentifier
    | ServiceKeyDeploymentConfigurationIdentifier
)


def is_id_identifier(
    identifier: AnyDeploymentConfigurationIdentifier,
) -> TypeGuard[IdDeploymentConfigurationIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, UUID)


def is_service_key_identifier(
    identifier: AnyDeploymentConfigurationIdentifier,
) -> TypeGuard[ServiceKeyDeploymentConfigurationIdentifier]:
    return identifier.type is IdentifierType.SERVICE_KEY and isinstance(
        identifier.value, str
    )
