"""DVSense Python SDK for DVSLume and DVSync cameras."""

__version__ = "0.1.0"
