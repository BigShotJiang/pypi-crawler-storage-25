from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.config_list_response import ConfigListResponse
from ...types import Unset


def _get_kwargs(
    *,
    filterparent: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_filterparent: None | str | Unset
    if isinstance(filterparent, Unset):
        json_filterparent = UNSET
    else:
        json_filterparent = filterparent
    params["filter[parent]"] = json_filterparent

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/configs",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ConfigListResponse | None:
    if response.status_code == 200:
        response_200 = ConfigListResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ConfigListResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    filterparent: None | str | Unset = UNSET,
) -> Response[ConfigListResponse]:
    """List Configs

     List all configurations for the authenticated account.

    Args:
        filterparent (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConfigListResponse]
    """

    kwargs = _get_kwargs(
        filterparent=filterparent,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    filterparent: None | str | Unset = UNSET,
) -> ConfigListResponse | None:
    """List Configs

     List all configurations for the authenticated account.

    Args:
        filterparent (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConfigListResponse
    """

    return sync_detailed(
        client=client,
        filterparent=filterparent,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    filterparent: None | str | Unset = UNSET,
) -> Response[ConfigListResponse]:
    """List Configs

     List all configurations for the authenticated account.

    Args:
        filterparent (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConfigListResponse]
    """

    kwargs = _get_kwargs(
        filterparent=filterparent,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    filterparent: None | str | Unset = UNSET,
) -> ConfigListResponse | None:
    """List Configs

     List all configurations for the authenticated account.

    Args:
        filterparent (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConfigListResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            filterparent=filterparent,
        )
    ).parsed
