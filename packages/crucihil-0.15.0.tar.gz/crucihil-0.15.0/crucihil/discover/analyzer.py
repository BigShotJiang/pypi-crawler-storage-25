"""SWC static analysis + AI signal matching.

analyze_component — extract the signal interface contract of a C/C++ software
component by combining tree-sitter identifier extraction across source files and
dependency headers with AI fuzzy matching against one or more DBC signal corpora.

Signals are never referenced by their DBC name in real firmware — they live behind
shim layers (AUTOSAR RTE, COM module, custom HAL). The AI maps shim identifiers to
DBC signals using semantic reasoning, returning per-match confidence scores so
engineers can review uncertain matches before they enter the test suite.

Requires the 'analyze' optional extra:
    pip install 'crucihil[analyze]'
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

from crucihil.discover.ai_client import AIClient, detect_provider
from crucihil.hal.bse.loader import load_dbc

# ---------------------------------------------------------------------------
# C/C++ noise filter — identifiers that are never signal-related
# ---------------------------------------------------------------------------

_NOISE: frozenset[str] = frozenset({
    # C keywords
    "auto", "break", "case", "char", "const", "continue", "default", "do",
    "double", "else", "enum", "extern", "float", "for", "goto", "if",
    "inline", "int", "long", "register", "restrict", "return", "short",
    "signed", "sizeof", "static", "struct", "switch", "typedef", "union",
    "unsigned", "void", "volatile", "while",
    # C++ keywords
    "bool", "catch", "class", "constexpr", "delete", "explicit", "export",
    "false", "friend", "namespace", "new", "nullptr", "operator", "override",
    "private", "protected", "public", "template", "this", "throw", "true",
    "try", "typename", "using", "virtual", "final",
    # Common stdlib functions
    "printf", "fprintf", "sprintf", "snprintf", "vsnprintf",
    "malloc", "calloc", "realloc", "free",
    "memset", "memcpy", "memmove", "memcmp",
    "strlen", "strcpy", "strncpy", "strcat", "strcmp", "strncmp",
    "assert", "abort", "exit", "NULL",
    # AUTOSAR / MISRA primitive types (not signal names)
    "uint8", "sint8", "uint16", "sint16", "uint32", "sint32", "float32",
    "uint8_t", "sint8_t", "uint16_t", "sint16_t", "uint32_t", "sint32_t",
    "int8_t", "int16_t", "int32_t", "int64_t", "uint64_t",
    "size_t", "ssize_t", "ptrdiff_t",
    "Std_ReturnType", "E_OK", "E_NOT_OK",
    # Very common local variable names unlikely to be signal identifiers
    "value", "result", "status", "error", "index", "count", "size",
    "data", "temp", "flag", "init", "main", "type", "mode", "state",
})

# ---------------------------------------------------------------------------
# AI system prompt — stored here, passed to AIClient at call time
# ---------------------------------------------------------------------------

_SIGNAL_MATCH_SYSTEM_PROMPT = """\
You are a CruciHiL signal analyzer for automotive firmware.

TASK: Match identifiers extracted from C/C++ source code to DBC signal names.

CONTEXT:
- DBC signals use the format MessageName.SignalName
- In real firmware, signals are NEVER referenced by their DBC name directly.
  They are accessed through shim layers:
    AUTOSAR RTE:  Rte_Read_<Port>_<Signal>(), Rte_Write_<Port>_<Signal>()
    COM module:   Com_ReceiveSignal(COM_SIG_X, &val), Com_SendSignal(COM_SIG_X, &val)
    Enum IDs:     COM_SIG_ENGINE_RPM → mapped to EngineData.RPM in a header
    Custom HAL:   get_engine_rpm(), HAL_CAN_ReadEngineSpeed(), set_brake_pressure()

DIRECTION RULES:
  Read / Receive / Get / Input  → INPUT  (signal consumed by the SWC)
  Write / Send / Set / Output   → OUTPUT (signal produced by the SWC)
  Ambiguous enum IDs            → infer from context or mark as INPUT

OUTPUT: Return ONLY valid JSON. No markdown fences. No explanation. No trailing text.
{
  "inputs":  [
    {"signal": "MessageName.SignalName", "dbc": "path/to/file.dbc",
     "interface": "CAN", "matched_identifier": "Rte_Read_EC_ThrottleCmd",
     "confidence": 0.92}
  ],
  "outputs": [ ...same structure... ],
  "unmatched_identifiers": ["identifiers", "with", "no", "confident", "match"]
}

CONFIDENCE GUIDELINES:
  0.90 – 1.00: Unmistakable match (e.g. Rte_Read_EC_EngineRPM → EngineData.RPM)
  0.70 – 0.89: Strong semantic match with minor naming variation
  0.50 – 0.69: Plausible but ambiguous — include with caution
  < 0.50: Omit entirely — do not guess

Each identifier should appear at most once across inputs + outputs combined.
If an enum ID like COM_SIG_ENGINE_RPM maps to a signal, the enum name is the
matched_identifier and the DBC signal is the match.
"""

# ---------------------------------------------------------------------------
# File collection
# ---------------------------------------------------------------------------

_SOURCE_EXTENSIONS = frozenset({
    ".c", ".cpp", ".cc", ".cxx", ".ino", ".h", ".hpp",
})

_CPP_EXTENSIONS = frozenset({".cpp", ".cc", ".cxx", ".ino", ".hpp"})


def _collect_source_files(path: str) -> list[Path]:
    """Return all C/C++ source files under path (file or directory)."""
    p = Path(path)
    if not p.exists():
        raise ValueError(f"Source path does not exist: {path}")
    if p.is_file():
        return [p]
    files: list[Path] = []
    for ext in _SOURCE_EXTENSIONS:
        files.extend(p.rglob(f"*{ext}"))
    return sorted(set(files))


# ---------------------------------------------------------------------------
# Signal corpus loading
# ---------------------------------------------------------------------------

def _infer_interface(dbc_key: str) -> str:
    """Infer interface type from a rig TOML [rig.definitions] key name."""
    prefix = dbc_key.removesuffix("_dbc").upper()
    return {
        "CAN":      "CAN",
        "ETH":      "ETH",
        "ETHERNET": "ETH",
        "LIN":      "LIN",
        "FLEXRAY":  "FlexRay",
        "FR":       "FlexRay",
        "SOMEIP":   "SOME/IP",
        "SOMEIP":   "SOME/IP",
    }.get(prefix, prefix or "unknown")


def _load_signal_corpus(
    dbc_paths: list[str] | None,
    rig_toml_path: str | None,
) -> list[dict]:
    """Load all signals from DBCs, tagged with source path and interface type.

    Sources are merged and deduplicated by resolved absolute path. TOML-discovered
    DBCs are processed first (interface type inferred from key name), then explicit
    dbc_paths are appended if not already present.
    """
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]  # Python < 3.11

    # ordered dict: resolved_path → interface label (insertion order = priority)
    seen: dict[str, str] = {}

    if rig_toml_path:
        with open(rig_toml_path, "rb") as f:
            data = tomllib.load(f)
        defs = data.get("rig", {}).get("definitions", {})
        for key, val in defs.items():
            if key.endswith("_dbc") and isinstance(val, str):
                resolved = str(Path(val).resolve())
                if resolved not in seen:
                    seen[resolved] = _infer_interface(key)

    for p in (dbc_paths or []):
        resolved = str(Path(p).resolve())
        if resolved not in seen:
            seen[resolved] = "unknown"

    corpus: list[dict] = []
    for resolved_path, iface in seen.items():
        db = load_dbc(resolved_path)
        for msg in db.messages:
            for sig in msg.signals:
                corpus.append({
                    "signal":    f"{msg.name}.{sig.name}",
                    "dbc":       resolved_path,
                    "interface": iface,
                })
    return corpus


# ---------------------------------------------------------------------------
# Identifier extraction via tree-sitter
# ---------------------------------------------------------------------------

def _extract_identifiers(files: list[Path]) -> set[str]:
    """Parse C/C++ source files and return all unique identifiers.

    Uses tree-sitter (optional extra). Collects identifier, field_identifier,
    and type_identifier AST nodes — a broad sweep that lets the AI filter by
    relevance rather than requiring exact pattern matching here.

    Raises RuntimeError if tree-sitter is not installed.
    """
    try:
        import tree_sitter_c as _tsc
        import tree_sitter_cpp as _tscpp
        from tree_sitter import Language, Parser
    except ImportError as exc:
        raise RuntimeError(
            f"tree-sitter not installed ({exc}). "
            "Install with: pip install 'crucihil[analyze]'"
        ) from exc

    _C_LANG   = Language(_tsc.language())
    _CPP_LANG = Language(_tscpp.language())
    _COLLECT  = frozenset({"identifier", "field_identifier", "type_identifier"})

    def _walk(node, out: set[str]) -> None:
        if node.type in _COLLECT and node.child_count == 0:
            out.add(node.text.decode("utf-8", errors="replace"))
        for child in node.children:
            _walk(child, out)

    identifiers: set[str] = set()
    for f in files:
        lang = _CPP_LANG if f.suffix.lower() in _CPP_EXTENSIONS else _C_LANG
        parser = Parser(lang)
        try:
            src = f.read_bytes()
        except OSError:
            continue
        tree = parser.parse(src)
        _walk(tree.root_node, identifiers)

    return identifiers


def _filter_identifiers(raw: set[str]) -> list[str]:
    """Remove noise and return identifiers sorted longest-first.

    Longer names are more likely to be meaningful shim identifiers
    (e.g. Rte_Read_EC_ThrottleCmd) rather than local variables.
    Capped at 500 to stay within AI context budget.
    """
    filtered = [
        s for s in raw
        if len(s) >= 4
        and s not in _NOISE
        and not s.isdigit()
        and not s.startswith("__")
    ]
    filtered.sort(key=len, reverse=True)
    return filtered[:500]


# ---------------------------------------------------------------------------
# AI prompt building and response parsing
# ---------------------------------------------------------------------------

def _build_match_prompt(
    component_name: str,
    identifiers: list[str],
    corpus: list[dict],
) -> str:
    corpus_lines = "\n".join(
        f"  {e['signal']}  [{e['dbc']}, {e['interface']}]"
        for e in corpus
    )
    id_list = ", ".join(identifiers)
    dbc_count = len({e["dbc"] for e in corpus})
    return (
        f"Component: {component_name}\n\n"
        f"Extracted identifiers:\n{id_list}\n\n"
        f"Signal corpus ({len(corpus)} signals across {dbc_count} DBC file(s)):\n"
        f"{corpus_lines}\n\n"
        "Match identifiers to signals. Classify each as input or output."
    )


def _strip_json_fences(text: str) -> str:
    """Extract the outermost JSON object from AI response text.

    Handles markdown fences, preamble text, and postamble text — all of which
    Claude occasionally adds despite "return only JSON" instructions.
    """
    text = text.strip()
    # Strip markdown fences first
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    text = text.strip()
    # Extract the outermost {...} block in case there is still preamble/postamble
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        return text[start : end + 1]
    return text


def _parse_ai_response(response_text: str, corpus: list[dict]) -> dict:
    """Parse AI JSON response, enrich with review_required, build summary."""
    corpus_index = {e["signal"]: e for e in corpus}

    try:
        data = json.loads(_strip_json_fences(response_text))
    except (json.JSONDecodeError, ValueError):
        return {
            "parse_error":           "AI response was not valid JSON",
            "raw_response":          response_text[:500],
            "inputs":                [],
            "outputs":               [],
            "unmatched_identifiers": [],
            "confidence_summary":    {"high": 0, "medium": 0, "low": 0},
            "review_required_count": 0,
        }

    def _enrich(matches: list) -> list:
        enriched = []
        for m in matches:
            if not isinstance(m, dict):
                continue
            confidence = float(m.get("confidence", 0.0))
            sig = m.get("signal", "")
            src = corpus_index.get(sig, {})
            enriched.append({
                "signal":             sig,
                "dbc":                m.get("dbc") or src.get("dbc", ""),
                "interface":          m.get("interface") or src.get("interface", "unknown"),
                "matched_identifier": m.get("matched_identifier", ""),
                "confidence":         round(confidence, 3),
                "review_required":    confidence < 0.85,
            })
        return enriched

    def _dedup(matches: list) -> list:
        """Keep the highest-confidence match per signal.

        The AI may match the same signal via multiple shim paths (e.g. both
        Rte_Read_BC_BrakeDemandVal and COM_SIG_BRAKE_DEMAND_VAL → BrakeDemand.Value).
        Only the best match is kept so each signal appears exactly once.
        """
        best: dict[str, dict] = {}
        for m in matches:
            sig = m["signal"]
            if sig not in best or m["confidence"] > best[sig]["confidence"]:
                best[sig] = m
        return list(best.values())

    inputs  = _dedup(_enrich(data.get("inputs",  [])))
    outputs = _dedup(_enrich(data.get("outputs", [])))

    all_matches = inputs + outputs
    summary: dict[str, int] = {"high": 0, "medium": 0, "low": 0}
    for m in all_matches:
        c = m["confidence"]
        if c >= 0.85:
            summary["high"] += 1
        elif c >= 0.60:
            summary["medium"] += 1
        else:
            summary["low"] += 1

    return {
        "inputs":                inputs,
        "outputs":               outputs,
        "unmatched_identifiers": data.get("unmatched_identifiers", []),
        "confidence_summary":    summary,
        "review_required_count": sum(1 for m in all_matches if m["review_required"]),
    }


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def analyze_component(
    source_path: str,
    component_name: str,
    dbc_paths: list[str] | None = None,
    rig_toml_path: str | None = None,
    dependencies: list[str] | None = None,
    ai_provider: str | None = None,
) -> dict:
    """Extract the signal interface contract of a C/C++ SWC.

    Combines tree-sitter identifier extraction across source + dependency files
    with AI fuzzy matching against a DBC signal corpus. Signals are matched by
    semantic similarity — not by exact name — because in real firmware they are
    accessed via shim layers (AUTOSAR RTE, COM module, custom HAL).

    Returns a dict with inputs, outputs, unmatched identifiers, and per-match
    confidence scores. When no AI key is available, returns the raw extracted
    identifiers and corpus size so the engineer can inspect manually.

    Requires the 'analyze' optional extra:
        pip install 'crucihil[analyze]'

    Args:
        source_path:    File or directory containing the SWC source.
        component_name: Label for this component in the output.
        dbc_paths:      One or more DBC files to build the signal corpus from.
                        Supports any interface (CAN, ETH, LIN) in DBC format.
        rig_toml_path:  Rig TOML path — auto-discovers DBCs from [rig.definitions]
                        and infers interface type from key name (can_dbc → CAN,
                        eth_dbc → ETH). Merged with explicit dbc_paths.
        dependencies:   Shim header dirs or other SWC paths to also parse.
                        Identifiers from these files are included in the AI prompt,
                        which is essential when signal names live in the shim layer
                        (e.g. rte/ headers) rather than the SWC source itself.
        ai_provider:    'anthropic', 'openai', or 'gemini'. Auto-detected from
                        env vars if None (ANTHROPIC_API_KEY, OPENAI_API_KEY,
                        GOOGLE_API_KEY).
    """
    # ── Collect files ──────────────────────────────────────────────────────────
    try:
        primary_files = _collect_source_files(source_path)
    except ValueError as exc:
        return {"error": str(exc), "component": component_name}

    dep_files: list[Path] = []
    for dep in (dependencies or []):
        try:
            dep_files.extend(_collect_source_files(dep))
        except ValueError as exc:
            return {"error": str(exc), "component": component_name}

    all_files = primary_files + dep_files

    # ── Build signal corpus ────────────────────────────────────────────────────
    if not dbc_paths and not rig_toml_path:
        return {
            "error":     "Provide at least one dbc_path or a rig_toml_path.",
            "component": component_name,
        }

    try:
        corpus = _load_signal_corpus(dbc_paths, rig_toml_path)
    except Exception as exc:
        return {"error": f"Failed to load signal corpus: {exc}", "component": component_name}

    if not corpus:
        return {"error": "No signals found in provided DBCs.", "component": component_name}

    # ── Extract identifiers ────────────────────────────────────────────────────
    try:
        raw_ids = _extract_identifiers(all_files)
    except RuntimeError as exc:
        return {"error": str(exc), "component": component_name}

    identifiers = _filter_identifiers(raw_ids)

    # ── Resolve AI provider ────────────────────────────────────────────────────
    provider_info: tuple[str, str] | None = None
    if ai_provider:
        _env_map = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai":    "OPENAI_API_KEY",
            "gemini":    "GOOGLE_API_KEY",
        }
        key = os.environ.get(_env_map.get(ai_provider, ""), "")
        if key:
            provider_info = (ai_provider, key)
    else:
        provider_info = detect_provider()

    if not provider_info:
        return {
            "component":              component_name,
            "identifiers_extracted":  identifiers,
            "signal_corpus_size":     len(corpus),
            "files_analyzed":         len(all_files),
            "note": (
                "No AI key found — signal matching skipped. "
                "Set ANTHROPIC_API_KEY, OPENAI_API_KEY, or GOOGLE_API_KEY."
            ),
        }

    # ── AI matching ────────────────────────────────────────────────────────────
    prompt = _build_match_prompt(component_name, identifiers, corpus)
    try:
        client = AIClient(
            provider_info[0],
            provider_info[1],
            system_prompt=_SIGNAL_MATCH_SYSTEM_PROMPT,
            max_tokens=4096,
        )
        response = client.complete(prompt)
    except Exception as exc:
        return {
            "error":                 f"AI call failed: {exc}",
            "component":             component_name,
            "identifiers_extracted": identifiers,
            "signal_corpus_size":    len(corpus),
        }

    result = _parse_ai_response(response, corpus)
    result["component"]              = component_name
    result["files_analyzed"]         = len(all_files)
    result["identifiers_extracted"]  = len(identifiers)
    result["signal_corpus_size"]     = len(corpus)
    return result


__all__ = ["analyze_component"]
