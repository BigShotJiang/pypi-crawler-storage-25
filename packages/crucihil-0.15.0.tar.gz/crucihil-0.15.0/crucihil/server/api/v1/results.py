"""Result read and batch sync endpoints.

GET  /api/v1/results — list results (includes tags/suite_types/priority from extra_meta).
GET  /api/v1/results/{result_id} — single result with full signals/logs.
POST /api/v1/results/sync — batch upsert from agent (idempotent).
"""

from __future__ import annotations

import json
import time
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from crucihil.server.api.deps import get_any_authenticated, get_current_rig, get_db
from crucihil.server.models.result import TestResultRow
from crucihil.server.models.rig import RigRow
from crucihil.server.models.run import TestRunRow
from crucihil.server.services.result_sync import (
    batch_upsert_results,
    recompute_run_counts,
    upsert_run,
)

router = APIRouter(prefix="/results", tags=["results"])


class ResultSummary(BaseModel):
    id: int
    test_id: str
    run_id: str
    suite_name: str
    status: str
    duration: float
    started_at: float
    completed_at: float
    error_message: str | None = None
    tags: list[str] = []
    suite_types: list[str] = []
    priority: str | None = None


class ResultDetail(ResultSummary):
    errors: list[Any]
    logs: list[Any]
    signals: dict[str, Any]
    extra_meta: dict[str, Any]


class SyncRequest(BaseModel):
    run_id: str
    rig_name: str
    suite_name: str
    started_at: float
    triggered_by: str | None = None
    results: list[dict[str, Any]]


class SyncResponse(BaseModel):
    inserted: int
    run_id: str


def _to_summary(row: TestResultRow) -> ResultSummary:
    errors: list[str] = json.loads(row.errors or "[]")
    meta: dict[str, Any] = json.loads(row.extra_meta or "{}")
    return ResultSummary(
        id=row.id,
        test_id=row.test_id,
        run_id=row.run_id,
        suite_name=row.suite_name,
        status=row.status,
        duration=row.duration,
        started_at=row.started_at,
        completed_at=row.completed_at,
        error_message=errors[0] if errors else None,
        tags=meta.get("tags") or [],
        suite_types=meta.get("suite_types") or [],
        priority=meta.get("priority"),
    )


def _to_detail(row: TestResultRow) -> ResultDetail:
    errors: list[str] = json.loads(row.errors or "[]")
    meta: dict[str, Any] = json.loads(row.extra_meta or "{}")
    return ResultDetail(
        id=row.id,
        test_id=row.test_id,
        run_id=row.run_id,
        suite_name=row.suite_name,
        status=row.status,
        duration=row.duration,
        started_at=row.started_at,
        completed_at=row.completed_at,
        error_message=errors[0] if errors else None,
        tags=meta.get("tags") or [],
        suite_types=meta.get("suite_types") or [],
        priority=meta.get("priority"),
        errors=json.loads(row.errors or "[]"),
        logs=json.loads(row.logs or "[]"),
        signals=json.loads(row.signals or "{}"),
        extra_meta=meta,
    )


def _user_org_id(auth: dict) -> str | None:
    if auth.get("type") == "user":
        return auth.get("org_id")
    return None


@router.get("", response_model=list[ResultSummary])
def list_results(
    db: Annotated[Session, Depends(get_db)],
    auth: Annotated[dict, Depends(get_any_authenticated)],
    run_id: str | None = Query(None),
    suite_name: str | None = Query(None),
    result_status: str | None = Query(None, alias="status"),
    limit: int = Query(100, le=1000),
) -> list[ResultSummary]:
    stmt = select(TestResultRow).order_by(TestResultRow.started_at.asc()).limit(limit)
    org_id = _user_org_id(auth)
    if org_id:
        stmt = (
            stmt.join(TestRunRow, TestResultRow.run_id == TestRunRow.id)
                .join(RigRow, TestRunRow.rig_id == RigRow.id)
                .where((RigRow.org_id == org_id) | (RigRow.org_id == None))  # noqa: E711
        )
    if run_id:
        stmt = stmt.where(TestResultRow.run_id == run_id)
    if suite_name:
        stmt = stmt.where(TestResultRow.suite_name == suite_name)
    if result_status:
        stmt = stmt.where(TestResultRow.status == result_status)
    rows = db.execute(stmt).scalars().all()
    return [_to_summary(r) for r in rows]


@router.get("/{result_id}", response_model=ResultDetail)
def get_result(
    result_id: int,
    db: Annotated[Session, Depends(get_db)],
    auth: Annotated[dict, Depends(get_any_authenticated)],
) -> ResultDetail:
    row = db.get(TestResultRow, result_id)
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Result not found")
    org_id = _user_org_id(auth)
    if org_id:
        run = db.get(TestRunRow, row.run_id)
        if run:
            rig = db.get(RigRow, run.rig_id)
            if rig and rig.org_id and rig.org_id != org_id:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Result not found")
    return _to_detail(row)


@router.post("/sync", response_model=SyncResponse)
def sync_results(
    body: SyncRequest,
    db: Annotated[Session, Depends(get_db)],
    auth_rig: Annotated[RigRow, Depends(get_current_rig)],
) -> SyncResponse:
    """Batch upsert results from the agent.

    Idempotent: replaying the full local SQLite cache never creates duplicates.
    Creates the test_runs row if it doesn't exist yet.
    """
    upsert_run(
        db,
        run_id=body.run_id,
        rig_id=auth_rig.id,
        suite_name=body.suite_name,
        started_at=body.started_at,
        triggered_by=body.triggered_by,
    )
    inserted = batch_upsert_results(db, run_id=body.run_id, results=body.results)
    recompute_run_counts(db, body.run_id)
    db.commit()
    return SyncResponse(inserted=inserted, run_id=body.run_id)
