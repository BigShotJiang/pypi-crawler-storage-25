"""OAuth 2.1 + PKCE authorization server endpoints.

GET  /.well-known/oauth-authorization-server  — discovery document (RFC 8414)
POST /oauth/register                          — dynamic client registration (RFC 7591)
GET  /oauth/authorize                         — login + consent form
POST /oauth/authorize                         — process login, issue auth code
POST /oauth/token                             — PKCE code exchange → JWT access token
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import secrets
import time
import uuid
from typing import Annotated
from urllib.parse import urlencode, urlparse

from fastapi import APIRouter, Depends, Form, HTTPException, Query, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from crucihil.server.api.deps import get_db
from crucihil.server.config import get_settings
from crucihil.server.models.oauth import OAuthClientRow, OAuthCodeRow
from crucihil.server.models.org import OrgRow
from crucihil.server.models.user import UserRow
from crucihil.server.services.auth import (
    issue_user_jwt,
    verify_password,
)

router = APIRouter(prefix="/oauth", tags=["oauth"])

# ── Constants ─────────────────────────────────────────────────────────────────

SUPPORTED_SCOPES = {"crucihil"}
CODE_TTL_SECONDS = 600       # 10 minutes
FORM_TOKEN_TTL   = 120       # 2 minutes
MAX_REDIRECT_URIS = 10

# RFC 7636 §4.1 — verifier character set and length
_VERIFIER_RE = re.compile(r'^[A-Za-z0-9._~-]{43,128}$')

# ── In-memory CSRF form token store (single-use, short-lived) ─────────────────
# Keyed by SHA256(form_token). Value: (expiry_float, oauth_params_hash)
_form_tokens: dict[str, tuple[float, str]] = {}

# ── Rate limiter (mirrors auth.py pattern) ────────────────────────────────────
_login_attempts: dict[str, list[float]] = {}
_RATE_WINDOW = 60
_RATE_MAX    = 5

_DUMMY_HASH: str | None = None


def _get_dummy_hash() -> str:
    global _DUMMY_HASH
    from crucihil.server.services.auth import hash_password
    if _DUMMY_HASH is None:
        _DUMMY_HASH = hash_password("crucihil-oauth-dummy-noenum")
    return _DUMMY_HASH


def _check_rate_limit(email: str) -> None:
    now = time.time()
    key = email.lower()
    _login_attempts[key] = [t for t in _login_attempts.get(key, []) if now - t < _RATE_WINDOW]
    if len(_login_attempts[key]) >= _RATE_MAX:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many login attempts. Try again in a minute.",
        )
    _login_attempts[key].append(now)


# ── PKCE helpers ──────────────────────────────────────────────────────────────

def _pkce_challenge_from_verifier(verifier: str) -> str:
    """Compute S256 code_challenge from verifier."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def _verify_pkce(verifier: str, stored_challenge: str) -> bool:
    """Constant-time PKCE S256 verification."""
    if not _VERIFIER_RE.match(verifier):
        return False
    computed = _pkce_challenge_from_verifier(verifier)
    return hmac.compare_digest(computed, stored_challenge)


# ── Code helpers ──────────────────────────────────────────────────────────────

def _hash_code(raw_code: str) -> str:
    return hashlib.sha256(raw_code.encode()).hexdigest()


# ── Redirect URI validation ───────────────────────────────────────────────────

def _is_valid_redirect_uri(uri: str) -> bool:
    """Accept HTTPS URIs and localhost HTTP/custom-scheme URIs for dev."""
    try:
        p = urlparse(uri)
    except Exception:
        return False
    if p.scheme == "https":
        return bool(p.netloc)
    # Allow localhost for local dev
    if p.scheme == "http" and p.hostname in ("localhost", "127.0.0.1"):
        return True
    # Allow custom schemes (mobile apps)
    if p.scheme and "." in p.scheme:
        return True
    return False


def _redirect_uri_registered(uri: str, client: OAuthClientRow) -> bool:
    """Exact string match only — no normalization, no wildcards."""
    try:
        registered = json.loads(client.redirect_uris)
    except (json.JSONDecodeError, TypeError):
        return False
    return uri in registered


# ── Form CSRF helpers ─────────────────────────────────────────────────────────

def _oauth_params_hash(client_id: str, redirect_uri: str, state: str, code_challenge: str) -> str:
    data = f"{client_id}:{redirect_uri}:{state}:{code_challenge}"
    return hashlib.sha256(data.encode()).hexdigest()


def _issue_form_token(params_hash: str) -> str:
    raw = secrets.token_urlsafe(16)
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    _form_tokens[token_hash] = (time.time() + FORM_TOKEN_TTL, params_hash)
    return raw


def _consume_form_token(raw: str, params_hash: str) -> bool:
    """Verify and immediately delete the form token. Returns True if valid."""
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    entry = _form_tokens.get(token_hash)
    if entry is None:
        return False
    expiry, stored_params_hash = entry
    del _form_tokens[token_hash]  # always delete — single use
    if time.time() > expiry:
        return False
    return hmac.compare_digest(stored_params_hash, params_hash)


# ── HTML login form ───────────────────────────────────────────────────────────

def _render_login_form(
    client_name: str,
    client_id: str,
    redirect_uri: str,
    state: str,
    code_challenge: str,
    scope: str,
    form_token: str,
    error: str | None = None,
) -> str:
    err_html = ""
    if error:
        err_html = f'<div class="error">{error}</div>'

    def h(v: str) -> str:
        return (v.replace("&", "&amp;")
                 .replace('"', "&quot;")
                 .replace("<", "&lt;")
                 .replace(">", "&gt;"))

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in to CruciHiL</title>
<style>
  *,*::before,*::after{{box-sizing:border-box}}
  body{{margin:0;background:#0f172a;color:#e2e8f0;font-family:Inter,system-ui,sans-serif;
        display:flex;min-height:100vh;align-items:center;justify-content:center}}
  .card{{background:#1e293b;border:1px solid #334155;border-radius:12px;padding:36px 40px;
         width:100%;max-width:400px}}
  .logo{{text-align:center;margin-bottom:24px}}
  .logo span{{font-size:1.4rem;font-weight:700;color:#38bdf8}}
  h1{{margin:0 0 4px;font-size:1.15rem;font-weight:600;text-align:center}}
  .subtitle{{text-align:center;color:#94a3b8;font-size:0.875rem;margin-bottom:28px}}
  .client{{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:10px 14px;
           margin-bottom:24px;font-size:0.875rem;color:#94a3b8}}
  .client strong{{color:#e2e8f0}}
  label{{display:block;font-size:0.8rem;color:#94a3b8;margin-bottom:6px}}
  input[type=email],input[type=password]{{
    display:block;width:100%;padding:10px 12px;background:#0f172a;
    border:1px solid #334155;border-radius:6px;color:#e2e8f0;font-size:0.9rem;
    outline:none;transition:border-color .15s}}
  input:focus{{border-color:#38bdf8}}
  .field{{margin-bottom:16px}}
  button{{display:block;width:100%;padding:11px;background:#0ea5e9;border:none;
          border-radius:6px;color:#fff;font-size:0.95rem;font-weight:600;
          cursor:pointer;transition:background .15s}}
  button:hover{{background:#0284c7}}
  .error{{background:#450a0a;border:1px solid #991b1b;color:#fca5a5;
          border-radius:6px;padding:10px 14px;font-size:0.85rem;margin-bottom:16px}}
  .scope{{font-size:0.8rem;color:#64748b;text-align:center;margin-top:20px}}
</style>
</head>
<body>
<div class="card">
  <div class="logo"><span>CruciHiL</span></div>
  <h1>Authorize access</h1>
  <p class="subtitle">Sign in to grant access to your rigs and test runs</p>
  <div class="client">
    <strong>{h(client_name or client_id)}</strong> is requesting access to your CruciHiL account.
  </div>
  {err_html}
  <form method="post" action="/oauth/authorize">
    <input type="hidden" name="client_id"            value="{h(client_id)}">
    <input type="hidden" name="redirect_uri"         value="{h(redirect_uri)}">
    <input type="hidden" name="state"                value="{h(state)}">
    <input type="hidden" name="code_challenge"       value="{h(code_challenge)}">
    <input type="hidden" name="scope"                value="{h(scope)}">
    <input type="hidden" name="form_token"           value="{h(form_token)}">
    <div class="field">
      <label for="email">Email address</label>
      <input type="email" id="email" name="email" required autofocus
             placeholder="you@example.com">
    </div>
    <div class="field">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required
             placeholder="••••••••">
    </div>
    <button type="submit">Sign in &amp; Authorize</button>
  </form>
  <p class="scope">Access granted: <strong>crucihil</strong> (rigs, runs, results)</p>
</div>
</body>
</html>"""


# ── Schemas ───────────────────────────────────────────────────────────────────

class ClientRegistrationRequest(BaseModel):
    client_name: str | None = None
    redirect_uris: list[str]
    grant_types: list[str] = ["authorization_code"]
    response_types: list[str] = ["code"]


class ClientRegistrationResponse(BaseModel):
    client_id: str
    client_name: str | None
    redirect_uris: list[str]
    grant_types: list[str]


# ── Discovery ─────────────────────────────────────────────────────────────────

discovery_router = APIRouter(tags=["oauth"])


@discovery_router.get("/.well-known/oauth-authorization-server")
def oauth_discovery() -> JSONResponse:
    """RFC 8414 OAuth 2.0 Authorization Server Metadata."""
    settings = get_settings()
    base = settings.CRUCIHIL_SERVER_URL.rstrip("/")
    return JSONResponse({
        "issuer":                              base,
        "authorization_endpoint":             f"{base}/oauth/authorize",
        "token_endpoint":                     f"{base}/oauth/token",
        "registration_endpoint":              f"{base}/oauth/register",
        "scopes_supported":                   ["crucihil"],
        "response_types_supported":           ["code"],
        "grant_types_supported":              ["authorization_code"],
        "code_challenge_methods_supported":   ["S256"],
        "require_pkce":                       True,
        "token_endpoint_auth_methods_supported": ["none"],
    })


# ── Client registration (RFC 7591) ────────────────────────────────────────────

@router.post("/register", response_model=ClientRegistrationResponse,
             status_code=status.HTTP_201_CREATED)
def register_client(
    body: ClientRegistrationRequest,
    db: Annotated[Session, Depends(get_db)],
) -> ClientRegistrationResponse:
    """Dynamic client registration. Public clients only (no client_secret)."""
    if not body.redirect_uris:
        raise HTTPException(status_code=400, detail="redirect_uris is required")
    if len(body.redirect_uris) > MAX_REDIRECT_URIS:
        raise HTTPException(status_code=400, detail=f"Maximum {MAX_REDIRECT_URIS} redirect_uris")
    for uri in body.redirect_uris:
        if not _is_valid_redirect_uri(uri):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid redirect_uri: {uri!r}. Must be HTTPS (or localhost for dev).",
            )

    client_id = str(uuid.uuid4())
    row = OAuthClientRow(
        client_id=client_id,
        client_name=body.client_name,
        redirect_uris=json.dumps(body.redirect_uris),
        grant_types=json.dumps(body.grant_types),
        created_at=time.time(),
    )
    db.add(row)
    db.commit()
    return ClientRegistrationResponse(
        client_id=client_id,
        client_name=body.client_name,
        redirect_uris=body.redirect_uris,
        grant_types=body.grant_types,
    )


# ── Authorization endpoint ────────────────────────────────────────────────────

def _error_redirect(redirect_uri: str, error: str, state: str) -> RedirectResponse:
    params = urlencode({"error": error, "state": state})
    return RedirectResponse(url=f"{redirect_uri}?{params}", status_code=302)


def _validate_authorize_params(
    client_id: str,
    redirect_uri: str,
    response_type: str,
    code_challenge_method: str,
    scope: str,
    db: Session,
) -> OAuthClientRow:
    """Validate all GET /authorize params. Returns the OAuthClientRow or raises HTTPException."""
    client = db.get(OAuthClientRow, client_id)
    if client is None:
        raise HTTPException(status_code=400, detail="Unknown client_id")
    if not _redirect_uri_registered(redirect_uri, client):
        raise HTTPException(status_code=400, detail="redirect_uri not registered for this client")
    if response_type != "code":
        raise HTTPException(status_code=400, detail="response_type must be 'code'")
    if code_challenge_method != "S256":
        raise HTTPException(status_code=400, detail="Only code_challenge_method=S256 is supported")
    requested_scopes = set(scope.split()) if scope else set()
    if not requested_scopes.issubset(SUPPORTED_SCOPES):
        raise HTTPException(status_code=400, detail=f"Unsupported scope(s): {requested_scopes - SUPPORTED_SCOPES}")
    return client


@router.get("/authorize", response_class=HTMLResponse)
def authorize_get(
    db: Annotated[Session, Depends(get_db)],
    client_id: str = Query(...),
    redirect_uri: str = Query(...),
    response_type: str = Query(...),
    state: str = Query(...),
    code_challenge: str = Query(...),
    code_challenge_method: str = Query("S256"),
    scope: str = Query("crucihil"),
) -> HTMLResponse:
    """Render the login + consent form."""
    client = _validate_authorize_params(
        client_id, redirect_uri, response_type,
        code_challenge_method, scope, db,
    )
    form_token = _issue_form_token(
        _oauth_params_hash(client_id, redirect_uri, state, code_challenge)
    )
    return HTMLResponse(_render_login_form(
        client_name=client.client_name or client_id,
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
        code_challenge=code_challenge,
        scope=scope,
        form_token=form_token,
    ))


@router.post("/authorize")
def authorize_post(
    db: Annotated[Session, Depends(get_db)],
    client_id: str      = Form(...),
    redirect_uri: str   = Form(...),
    state: str          = Form(...),
    code_challenge: str = Form(...),
    scope: str          = Form("crucihil"),
    form_token: str     = Form(...),
    email: str          = Form(...),
    password: str       = Form(...),
) -> RedirectResponse:
    """Process login form, issue authorization code, redirect back to client."""
    # ── 1. CSRF form token check ──────────────────────────────────────────────
    params_hash = _oauth_params_hash(client_id, redirect_uri, state, code_challenge)
    if not _consume_form_token(form_token, params_hash):
        raise HTTPException(status_code=400, detail="Invalid or expired form token")

    # ── 2. Re-validate OAuth params ───────────────────────────────────────────
    client = db.get(OAuthClientRow, client_id)
    if client is None or not _redirect_uri_registered(redirect_uri, client):
        raise HTTPException(status_code=400, detail="Invalid client or redirect_uri")

    # ── 3. Authenticate user (rate-limited, constant-time) ───────────────────
    email_norm = email.lower().strip()
    _check_rate_limit(email_norm)

    user = db.execute(
        select(UserRow).where(UserRow.email == email_norm)
    ).scalar_one_or_none()

    if user is None or user.password_hash is None:
        verify_password(password, _get_dummy_hash())  # constant-time dummy
        # Re-render form with error — issue new form token
        new_token = _issue_form_token(params_hash)
        return HTMLResponse(
            _render_login_form(
                client_name=client.client_name or client_id,
                client_id=client_id,
                redirect_uri=redirect_uri,
                state=state,
                code_challenge=code_challenge,
                scope=scope,
                form_token=new_token,
                error="Invalid email or password.",
            ),
            status_code=200,
        )

    if not verify_password(password, user.password_hash):
        new_token = _issue_form_token(params_hash)
        return HTMLResponse(
            _render_login_form(
                client_name=client.client_name or client_id,
                client_id=client_id,
                redirect_uri=redirect_uri,
                state=state,
                code_challenge=code_challenge,
                scope=scope,
                form_token=new_token,
                error="Invalid email or password.",
            ),
            status_code=200,
        )

    # ── 4. Purge stale codes for this user before inserting a new one ─────────
    db.execute(
        delete(OAuthCodeRow).where(
            OAuthCodeRow.user_id == user.id,
            (OAuthCodeRow.expires_at < time.time()) | (OAuthCodeRow.used == True),  # noqa: E712
        )
    )

    # ── 5. Generate auth code (256-bit entropy), store hash ───────────────────
    raw_code = secrets.token_urlsafe(32)
    db.add(OAuthCodeRow(
        code_hash=_hash_code(raw_code),
        user_id=user.id,
        org_id=user.org_id,
        client_id=client_id,
        redirect_uri=redirect_uri,
        scopes=json.dumps(list(set(scope.split()) & SUPPORTED_SCOPES)),
        code_challenge=code_challenge,
        code_challenge_method="S256",
        expires_at=time.time() + CODE_TTL_SECONDS,
    ))
    db.commit()

    params = urlencode({"code": raw_code, "state": state})
    return RedirectResponse(url=f"{redirect_uri}?{params}", status_code=302)


# ── Token endpoint ────────────────────────────────────────────────────────────

@router.post("/token")
def token(
    db: Annotated[Session, Depends(get_db)],
    grant_type: str    = Form(...),
    code: str          = Form(...),
    redirect_uri: str  = Form(...),
    client_id: str     = Form(...),
    code_verifier: str = Form(...),
) -> JSONResponse:
    """Exchange authorization code + PKCE verifier for a JWT access token."""
    settings = get_settings()

    if grant_type != "authorization_code":
        return JSONResponse({"error": "unsupported_grant_type"}, status_code=400)

    # ── 1. Look up code by hash ───────────────────────────────────────────────
    code_row = db.execute(
        select(OAuthCodeRow).where(OAuthCodeRow.code_hash == _hash_code(code))
    ).scalar_one_or_none()

    if code_row is None:
        return JSONResponse({"error": "invalid_grant", "error_description": "Code not found"}, status_code=400)

    # ── 2. Validate code state ────────────────────────────────────────────────
    if code_row.used:
        return JSONResponse({"error": "invalid_grant", "error_description": "Code already used"}, status_code=400)

    if time.time() > code_row.expires_at:
        return JSONResponse({"error": "invalid_grant", "error_description": "Code expired"}, status_code=400)

    if code_row.client_id != client_id:
        return JSONResponse({"error": "invalid_grant", "error_description": "client_id mismatch"}, status_code=400)

    # Exact redirect_uri match (required by OAuth 2.1)
    if code_row.redirect_uri != redirect_uri:
        return JSONResponse({"error": "invalid_grant", "error_description": "redirect_uri mismatch"}, status_code=400)

    # ── 3. PKCE S256 verification (constant-time) ─────────────────────────────
    if not _verify_pkce(code_verifier, code_row.code_challenge):
        return JSONResponse({"error": "invalid_grant", "error_description": "PKCE verification failed"}, status_code=400)

    # ── 4. Mark code as used (single-use) ─────────────────────────────────────
    code_row.used = True
    db.commit()

    # ── 5. Look up user + org, issue JWT ──────────────────────────────────────
    user = db.get(UserRow, code_row.user_id)
    if user is None:
        return JSONResponse({"error": "server_error", "error_description": "User not found"}, status_code=500)

    org = db.get(OrgRow, code_row.org_id)
    org_slug = org.slug if org else ""

    token_data = issue_user_jwt(
        user_id=user.id,
        org_id=code_row.org_id,
        org_slug=org_slug,
        role=user.role,
    )

    return JSONResponse({
        "access_token": token_data["access_token"],
        "token_type":   "bearer",
        "expires_in":   settings.JWT_EXPIRY_SECONDS,
    })
