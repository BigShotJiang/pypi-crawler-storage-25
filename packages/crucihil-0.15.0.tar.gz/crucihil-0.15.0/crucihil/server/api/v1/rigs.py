"""Rig management endpoints.

GET    /api/v1/rigs                              — list all rigs (any authenticated JWT)
GET    /api/v1/rigs/{rig_name}                   — single rig detail (any authenticated JWT)
POST   /api/v1/rigs                              — register a rig (admin JWT or REGISTRATION_TOKEN)
DELETE /api/v1/rigs/{rig_name}                   — delete a rig (admin only)
POST   /api/v1/rigs/{rig_name}/viewers           — create viewer API key (admin only)
DELETE /api/v1/rigs/{rig_name}/viewers/{viewer_id} — revoke viewer key (admin only)
"""

from __future__ import annotations

import json
import secrets
import time
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from crucihil.server.api.deps import (
    get_admin_principal,
    get_any_authenticated,
    get_db,
)
from crucihil.server.config import get_settings
from crucihil.server.models.rig import RigRow
from crucihil.server.models.viewer_key import ViewerKeyRow
from crucihil.server.services.auth import (
    decode_jwt,
    generate_api_key,
    generate_viewer_key,
    hash_api_key,
)

router = APIRouter(prefix="/rigs", tags=["rigs"])


# ── Pydantic schemas ───────────────────────────────────────────────────────────

class RigCreate(BaseModel):
    name: str
    extra_meta: dict = {}


class RigDetail(BaseModel):
    id: str
    name: str
    role: str
    connected: bool
    last_seen_at: float | None
    version: str | None
    created_at: float
    extra_meta: dict


class RigRegisterResponse(BaseModel):
    rig: RigDetail
    api_key: str  # shown once — store it in the rig TOML and .env


class ViewerCreate(BaseModel):
    name: str


class ViewerKeyResponse(BaseModel):
    viewer_id: int
    name: str
    viewer_key: str  # shown once — cannot be recovered
    role: str = "viewer"


def _to_detail(row: RigRow) -> RigDetail:
    return RigDetail(
        id=row.id,
        name=row.name,
        role=row.role,
        connected=row.connected,
        last_seen_at=row.last_seen_at,
        version=row.version,
        created_at=row.created_at,
        extra_meta=json.loads(row.extra_meta or "{}"),
    )


# ── Auth helper: accept REGISTRATION_TOKEN or admin JWT for rig creation ──────

def _require_rig_create(request: Request, db: Session = Depends(get_db)) -> None:
    """Allow rig creation via the static REGISTRATION_TOKEN (setup.sh bootstrap)
    OR any valid admin JWT — user JWT (type='user', role='admin') or rig JWT
    (type='rig', role='admin'). Both result in an admin-role rig being created.
    """
    from jose import JWTError
    from crucihil.server.models.user import UserRow

    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED, "Missing Bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = auth_header[7:]
    settings = get_settings()

    # Path 1: static bootstrap token (setup.sh / .env)
    if secrets.compare_digest(token, settings.REGISTRATION_TOKEN):
        return

    # Path 2: admin JWT (user or rig)
    try:
        payload = decode_jwt(token)
    except (JWTError, Exception):
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED, "Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if payload.get("role", "viewer") != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Admin role required")

    token_type = payload.get("type", "rig")
    if token_type == "user":
        if db.get(UserRow, payload.get("sub")) is None:
            raise HTTPException(
                status.HTTP_401_UNAUTHORIZED, "User not found",
                headers={"WWW-Authenticate": "Bearer"},
            )
    else:
        rig_id = payload.get("rig_id")
        if not rig_id or db.get(RigRow, rig_id) is None:
            raise HTTPException(
                status.HTTP_401_UNAUTHORIZED, "Rig not found",
                headers={"WWW-Authenticate": "Bearer"},
            )


# ── Endpoints ──────────────────────────────────────────────────────────────────

def _user_org_id(auth: dict) -> str | None:
    """Return org_id only for user-type tokens; None otherwise (rig/viewer tokens not scoped)."""
    if auth.get("type") == "user":
        return auth.get("org_id")
    return None


@router.get("", response_model=list[RigDetail])
def list_rigs(
    db: Annotated[Session, Depends(get_db)],
    auth: Annotated[dict, Depends(get_any_authenticated)],
) -> list[RigDetail]:
    query = select(RigRow).order_by(RigRow.created_at.desc())
    org_id = _user_org_id(auth)
    if org_id:
        query = query.where((RigRow.org_id == org_id) | (RigRow.org_id == None))  # noqa: E711
    rows = db.execute(query).scalars().all()
    return [_to_detail(r) for r in rows]


@router.get("/{rig_name}", response_model=RigDetail)
def get_rig(
    rig_name: str,
    db: Annotated[Session, Depends(get_db)],
    auth: Annotated[dict, Depends(get_any_authenticated)],
) -> RigDetail:
    row = db.execute(select(RigRow).where(RigRow.name == rig_name)).scalar_one_or_none()
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Rig not found")
    org_id = _user_org_id(auth)
    if org_id and row.org_id and row.org_id != org_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Rig not found")
    return _to_detail(row)


@router.post("", response_model=RigRegisterResponse, status_code=status.HTTP_201_CREATED)
def register_rig(
    request: Request,
    body: RigCreate,
    db: Annotated[Session, Depends(get_db)],
) -> RigRegisterResponse:
    """Register a new rig. Requires admin JWT or the static REGISTRATION_TOKEN."""
    _require_rig_create(request, db)

    existing = db.execute(select(RigRow).where(RigRow.name == body.name)).scalar_one_or_none()
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Rig name already registered")

    # Assign rig to the caller's org when registering with a user JWT
    org_id: str | None = None
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        try:
            payload = decode_jwt(auth_header[7:])
            if payload.get("type") == "user":
                org_id = payload.get("org_id")
        except Exception:
            pass

    raw_key = generate_api_key()
    row = RigRow(
        name=body.name,
        api_key_hash=hash_api_key(raw_key),
        role="admin",
        org_id=org_id,
        created_at=time.time(),
        extra_meta=json.dumps(body.extra_meta),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return RigRegisterResponse(rig=_to_detail(row), api_key=raw_key)


@router.delete("/{rig_name}", status_code=status.HTTP_204_NO_CONTENT)
def delete_rig(
    rig_name: str,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_admin_principal)],
) -> None:
    """Delete a rig and all its runs/results (cascade). Requires admin."""
    row = db.execute(select(RigRow).where(RigRow.name == rig_name)).scalar_one_or_none()
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Rig not found")
    db.delete(row)
    db.commit()


@router.post("/{rig_name}/viewers", response_model=ViewerKeyResponse,
             status_code=status.HTTP_201_CREATED)
def create_viewer_key(
    rig_name: str,
    body: ViewerCreate,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_admin_principal)],
) -> ViewerKeyResponse:
    """Create a read-only viewer API key for a rig. Requires admin. Key shown once."""
    rig = db.execute(select(RigRow).where(RigRow.name == rig_name)).scalar_one_or_none()
    if rig is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Rig not found")

    raw_key = generate_viewer_key()
    vk = ViewerKeyRow(
        rig_id=rig.id,
        name=body.name,
        api_key_hash=hash_api_key(raw_key),
        created_at=time.time(),
    )
    db.add(vk)
    db.commit()
    db.refresh(vk)
    return ViewerKeyResponse(viewer_id=vk.id, name=vk.name, viewer_key=raw_key)


@router.delete("/{rig_name}/viewers/{viewer_id}", status_code=status.HTTP_204_NO_CONTENT)
def revoke_viewer_key(
    rig_name: str,
    viewer_id: int,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_admin_principal)],
) -> None:
    """Revoke a viewer key. Revoked keys are rejected at /auth/token. Requires admin."""
    rig = db.execute(select(RigRow).where(RigRow.name == rig_name)).scalar_one_or_none()
    if rig is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Rig not found")

    vk = db.get(ViewerKeyRow, viewer_id)
    if vk is None or vk.rig_id != rig.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Viewer key not found")

    vk.revoked = True
    db.commit()
