"""Server configuration loaded from environment variables / .env file."""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql://crucihil:crucihil@localhost/crucihil"
    SECRET_KEY: str = "CHANGE_ME_generate_32_random_bytes_hex"
    REGISTRATION_TOKEN: str = "CHANGE_ME_generate_32_random_bytes_hex"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRY_SECONDS: int = 3600
    ALLOWED_ORIGINS: list[str] = ["*"]

    # Invite email delivery (Resend). Leave blank to log invite URLs to stdout.
    RESEND_API_KEY: str = ""
    RESEND_FROM: str = "onboarding@crucihil.io"
    # Public base URL used to build invite links, e.g. https://app.crucihil.io
    APP_URL: str = "http://localhost:5173"
    # Public base URL of this control plane — used as OAuth issuer
    CRUCIHIL_SERVER_URL: str = "http://localhost:8000"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


__all__ = ["Settings", "get_settings"]
