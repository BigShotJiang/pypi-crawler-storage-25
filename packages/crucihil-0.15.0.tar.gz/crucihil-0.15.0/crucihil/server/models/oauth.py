"""OAuth 2.1 models — dynamic clients and authorization codes."""

from __future__ import annotations

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from crucihil.server.models.base import Base


class OAuthClientRow(Base):
    __tablename__ = "oauth_clients"

    client_id: Mapped[str]    = mapped_column(String(64), primary_key=True)
    client_name: Mapped[str | None] = mapped_column(String(256), nullable=True)
    redirect_uris: Mapped[str] = mapped_column(Text, nullable=False)   # JSON array
    grant_types: Mapped[str]  = mapped_column(Text, nullable=False, default='["authorization_code"]')
    created_at: Mapped[float] = mapped_column(Float, nullable=False)


class OAuthCodeRow(Base):
    __tablename__ = "oauth_codes"

    id: Mapped[int]            = mapped_column(Integer, primary_key=True, autoincrement=True)
    # SHA256(raw_code) stored as hex — raw code never persisted
    code_hash: Mapped[str]     = mapped_column(String(64), unique=True, nullable=False, index=True)
    user_id: Mapped[str]       = mapped_column(
        String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    org_id: Mapped[str]        = mapped_column(String(36), nullable=False)
    client_id: Mapped[str]     = mapped_column(
        String(64), ForeignKey("oauth_clients.client_id", ondelete="CASCADE"), nullable=False
    )
    redirect_uri: Mapped[str]  = mapped_column(Text, nullable=False)
    scopes: Mapped[str]        = mapped_column(Text, nullable=False, default='["crucihil"]')
    # PKCE — only S256 accepted
    code_challenge: Mapped[str]        = mapped_column(String(256), nullable=False)
    code_challenge_method: Mapped[str] = mapped_column(String(8), nullable=False, default="S256")
    expires_at: Mapped[float]  = mapped_column(Float, nullable=False)
    used: Mapped[bool]         = mapped_column(Boolean, nullable=False, default=False)
