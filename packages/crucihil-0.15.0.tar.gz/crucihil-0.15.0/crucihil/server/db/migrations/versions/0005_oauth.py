"""Add oauth_clients and oauth_codes tables for OAuth 2.1 + PKCE support.

Revision ID: 0005
Revises: 0004
Create Date: 2026-05-10
"""

from alembic import op
import sqlalchemy as sa

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "oauth_clients",
        sa.Column("client_id",    sa.String(64),  primary_key=True, nullable=False),
        sa.Column("client_name",  sa.String(256), nullable=True),
        sa.Column("redirect_uris", sa.Text,       nullable=False),
        sa.Column("grant_types",  sa.Text,        nullable=False),
        sa.Column("created_at",   sa.Float,       nullable=False),
    )

    op.create_table(
        "oauth_codes",
        sa.Column("id",                   sa.Integer,    primary_key=True, autoincrement=True),
        sa.Column("code_hash",            sa.String(64), nullable=False, unique=True),
        sa.Column("user_id",              sa.String(36), sa.ForeignKey("users.id",          ondelete="CASCADE"), nullable=False),
        sa.Column("org_id",               sa.String(36), nullable=False),
        sa.Column("client_id",            sa.String(64), sa.ForeignKey("oauth_clients.client_id", ondelete="CASCADE"), nullable=False),
        sa.Column("redirect_uri",         sa.Text,       nullable=False),
        sa.Column("scopes",               sa.Text,       nullable=False),
        sa.Column("code_challenge",       sa.String(256), nullable=False),
        sa.Column("code_challenge_method", sa.String(8), nullable=False),
        sa.Column("expires_at",           sa.Float,      nullable=False),
        sa.Column("used",                 sa.Boolean,    nullable=False, server_default="false"),
    )
    op.create_index("ix_oauth_codes_code_hash", "oauth_codes", ["code_hash"], unique=True)


def downgrade() -> None:
    op.drop_index("ix_oauth_codes_code_hash", table_name="oauth_codes")
    op.drop_table("oauth_codes")
    op.drop_table("oauth_clients")
