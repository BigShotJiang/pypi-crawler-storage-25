"""Authentication service: API key hashing, password hashing, JWT issue/verify.

API keys are SHA-256 hashed before storage — shown once, never retrievable.
Passwords are bcrypt-hashed via passlib.
Invite tokens are URL-safe random bytes; only the SHA-256 hash is stored.
JWTs are HS256, 1-hour expiry. Three token types:
  type="user"   — human login (sub=user_id, org_id, role)
  type="rig"    — rig agent / MCP (sub=rig_name, rig_id, org_id)
  type="viewer" — CI read-only key (sub=rig_name, rig_id, org_id, role="viewer")
"""

from __future__ import annotations

import hashlib
import secrets
import time
from typing import Any

import bcrypt as _bcrypt
from jose import JWTError, jwt

from crucihil.server.config import get_settings

_KEY_PREFIX = "crucihil-rig-"
_VIEWER_KEY_PREFIX = "crucihil-viewer-"
_BCRYPT_ROUNDS = 12


# ── API keys ───────────────────────────────────────────────────────────────────

def generate_api_key() -> str:
    return _KEY_PREFIX + secrets.token_hex(24)


def generate_viewer_key() -> str:
    return _VIEWER_KEY_PREFIX + secrets.token_hex(24)


def hash_api_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def verify_api_key(raw_key: str, stored_hash: str) -> bool:
    return secrets.compare_digest(hash_api_key(raw_key), stored_hash)


# ── Passwords ──────────────────────────────────────────────────────────────────

def hash_password(plain: str) -> str:
    return _bcrypt.hashpw(plain.encode(), _bcrypt.gensalt(rounds=_BCRYPT_ROUNDS)).decode()


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return _bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception:
        return False


# ── Invite tokens ──────────────────────────────────────────────────────────────

def generate_invite_token() -> str:
    """Return a 256-bit URL-safe token (shown once to the inviter via email link)."""
    return secrets.token_urlsafe(32)


def hash_invite_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode()).hexdigest()


# ── Password-reset tokens ──────────────────────────────────────────────────────

def generate_password_reset_token() -> str:
    """Return a 256-bit URL-safe token for password reset (sent once via email link)."""
    return secrets.token_urlsafe(32)


def hash_password_reset_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode()).hexdigest()


# ── JWTs ───────────────────────────────────────────────────────────────────────

def _encode(payload: dict[str, Any]) -> dict[str, Any]:
    settings = get_settings()
    token = jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)
    return {"access_token": token, "token_type": "bearer", "expires_in": settings.JWT_EXPIRY_SECONDS}


def issue_user_jwt(*, user_id: str, org_id: str, org_slug: str, role: str) -> dict[str, Any]:
    """Issue a JWT for a human user (type='user')."""
    settings = get_settings()
    now = int(time.time())
    return _encode({
        "iss": settings.CRUCIHIL_SERVER_URL.rstrip("/"),
        "sub": user_id,
        "org_id": org_id,
        "org_slug": org_slug,
        "role": role,
        "type": "user",
        "iat": now,
        "exp": now + settings.JWT_EXPIRY_SECONDS,
    })


def issue_rig_jwt(*, rig_name: str, rig_id: str, org_id: str | None) -> dict[str, Any]:
    """Issue a JWT for a rig agent or MCP client (type='rig', role='admin').

    Rig agents always have admin-level access to their own endpoints.
    role='admin' is kept in the payload so get_admin_rig() continues to work.
    """
    settings = get_settings()
    now = int(time.time())
    payload: dict[str, Any] = {
        "sub": rig_name,
        "rig_id": rig_id,
        "role": "admin",
        "type": "rig",
        "iat": now,
        "exp": now + settings.JWT_EXPIRY_SECONDS,
    }
    if org_id:
        payload["org_id"] = org_id
    return _encode(payload)


def issue_viewer_jwt(*, rig_name: str, rig_id: str, org_id: str | None) -> dict[str, Any]:
    """Issue a read-only JWT for a CI viewer key (type='viewer')."""
    settings = get_settings()
    now = int(time.time())
    payload: dict[str, Any] = {
        "sub": rig_name,
        "rig_id": rig_id,
        "role": "viewer",
        "type": "viewer",
        "iat": now,
        "exp": now + settings.JWT_EXPIRY_SECONDS,
    }
    if org_id:
        payload["org_id"] = org_id
    return _encode(payload)


def issue_jwt(rig_name: str, rig_id: str, *, role: str = "admin") -> dict[str, Any]:
    """Backward-compatible wrapper used by existing call sites and test fixtures.

    org_id is omitted here; callers that need it (e.g. POST /auth/token after
    the user-auth migration) should call issue_rig_jwt / issue_viewer_jwt directly.
    """
    if role == "viewer":
        return issue_viewer_jwt(rig_name=rig_name, rig_id=rig_id, org_id=None)
    return issue_rig_jwt(rig_name=rig_name, rig_id=rig_id, org_id=None)


def decode_jwt(token: str) -> dict[str, Any]:
    """Decode and verify a JWT. Raises jose.JWTError if invalid or expired."""
    settings = get_settings()
    return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])


__all__ = [
    "generate_api_key",
    "generate_viewer_key",
    "hash_api_key",
    "verify_api_key",
    "hash_password",
    "verify_password",
    "generate_invite_token",
    "hash_invite_token",
    "generate_password_reset_token",
    "hash_password_reset_token",
    "issue_user_jwt",
    "issue_rig_jwt",
    "issue_viewer_jwt",
    "issue_jwt",
    "decode_jwt",
]
