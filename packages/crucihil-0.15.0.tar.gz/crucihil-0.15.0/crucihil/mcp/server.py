"""CruciHiL MCP server.

A standalone FastMCP process that exposes CruciHiL capabilities to any
MCP-compatible AI client (Claude, Copilot, Cursor).

Start with:
    python -m crucihil.mcp.server

Environment variables:
    CRUCIHIL_BASE_URL    — HTTP(S) base URL of the control plane (required)
    CRUCIHIL_API_KEY     — API key for global client (required when OAuth disabled)

OAuth mode (all three required to enable):
    SECRET_KEY           — HS256 shared secret matching the control plane
    MCP_SERVER_URL       — Public URL of this MCP server
    CRUCIHIL_BASE_URL    — Also used as the OAuth authorization server issuer
"""

from __future__ import annotations

import os

from fastmcp import FastMCP

from crucihil.mcp.tools.rigs import get_rig_config, list_rigs, register_rig
from crucihil.mcp.tools.results import describe_failure, get_results, get_signal_trace
from crucihil.mcp.tools.runs import cancel_run, get_run_summary, list_runs, run_test_suite
from crucihil.mcp.tools.analyzer import analyze_component
from crucihil.mcp.tools.signals import list_signals
from crucihil.mcp.tools.suites import generate_test_suite, list_tests

_INSTRUCTIONS = (
    "CruciHiL is a Hardware-in-the-Loop testing platform. "
    "Use these tools to query rig state, run test suites, analyze failures, and scaffold new tests. "
    "Start with list_rigs to see available rigs, then list_runs to see recent runs. "
    "For failure analysis, call describe_failure — it returns all context in one call. "
    "To onboard a new rig: call register_rig to get an API key, then instruct the user to run "
    "'crucihil discover' on the bench machine to generate the rig TOML. "
    "To scaffold a new test suite: call generate_test_suite with a description. "
    "To map a firmware SWC to its DBC signal interface: call analyze_component — it extracts "
    "identifiers from C/C++ source via tree-sitter and uses AI to fuzzy-match them to DBC signals."
)


def _build_auth(base_url: str, secret_key: str, mcp_server_url: str):
    from fastmcp.server.auth import RemoteAuthProvider, JWTVerifier
    from pydantic import AnyHttpUrl

    jwt_verifier = JWTVerifier(
        public_key=secret_key,
        algorithm="HS256",
        issuer=base_url,
    )
    return RemoteAuthProvider(
        token_verifier=jwt_verifier,
        authorization_servers=[AnyHttpUrl(base_url)],
        base_url=mcp_server_url,
        scopes_supported=["crucihil"],
        resource_name="CruciHiL",
    )


def _make_mcp() -> FastMCP:
    base_url    = os.environ.get("CRUCIHIL_BASE_URL", "").rstrip("/")
    secret_key  = os.environ.get("SECRET_KEY", "")
    mcp_url     = os.environ.get("MCP_SERVER_URL", "").rstrip("/")

    auth = None
    if base_url and secret_key and mcp_url:
        auth = _build_auth(base_url, secret_key, mcp_url)

    return FastMCP(name="CruciHiL", instructions=_INSTRUCTIONS, auth=auth)


mcp = _make_mcp()

mcp.add_tool(list_rigs)
mcp.add_tool(get_rig_config)
mcp.add_tool(register_rig)
mcp.add_tool(list_runs)
mcp.add_tool(get_run_summary)
mcp.add_tool(run_test_suite)
mcp.add_tool(cancel_run)
mcp.add_tool(get_results)
mcp.add_tool(get_signal_trace)
mcp.add_tool(describe_failure)
mcp.add_tool(list_signals)
mcp.add_tool(list_tests)
mcp.add_tool(generate_test_suite)
mcp.add_tool(analyze_component)

if __name__ == "__main__":
    from crucihil.mcp.client import init_client

    base_url    = os.environ.get("CRUCIHIL_BASE_URL", "")
    api_key     = os.environ.get("CRUCIHIL_API_KEY", "")
    secret_key  = os.environ.get("SECRET_KEY", "")
    transport   = os.environ.get("CRUCIHIL_MCP_TRANSPORT", "stdio")

    if not base_url:
        raise SystemExit("CRUCIHIL_BASE_URL environment variable is required")

    oauth_active = bool(secret_key and os.environ.get("MCP_SERVER_URL"))
    if not oauth_active and not api_key:
        raise SystemExit(
            "CRUCIHIL_API_KEY is required when OAuth is not configured "
            "(set SECRET_KEY + MCP_SERVER_URL to enable OAuth mode)"
        )

    init_client(base_url=base_url, api_key=api_key or None)

    if transport == "sse":
        mcp.run(transport="sse", host="0.0.0.0", port=8001)
    else:
        mcp.run()
