"""MCP tools for test result inspection.

get_results      — list test results for a run (with optional status filter)
get_signal_trace — extract signal samples from one or more tests in a run
describe_failure — single-call failure context: errors + logs + signals (the strategic tool)
"""

from __future__ import annotations

import httpx

from crucihil.mcp.client import get_client, get_request_client

_MAX_SIGNAL_SAMPLES = 100
_MAX_SIGNALS_IN_DESCRIBE = 5
_MAX_RESULTS_FOR_TRACE = 5


async def get_results(run_id: str, status: str | None = None) -> list[dict]:
    """List test results for a run, optionally filtered by status.

    Args:
        run_id: The UUID of the run.
        status: Optional filter — one of "pass", "fail", "blocked", "error", "skip".
    """
    client = get_request_client()
    try:
        results = await client.list_results(run_id=run_id, status=status, limit=200)
    except httpx.HTTPStatusError as exc:
        return [{"error": f"API error {exc.response.status_code}", "run_id": run_id}]
    return [
        {
            "test_id": r["test_id"],
            "run_id": r["run_id"],
            "suite_name": r["suite_name"],
            "status": r["status"],
            "duration": r["duration"],
            "started_at": r["started_at"],
            "completed_at": r["completed_at"],
        }
        for r in results
    ]


def _truncate_signal(samples: list, signal_name: str) -> tuple[list, bool, int]:
    """Return (truncated_samples, was_truncated, total_count)."""
    total = len(samples)
    if total > _MAX_SIGNAL_SAMPLES:
        return samples[:_MAX_SIGNAL_SAMPLES], True, total
    return samples, False, total


async def get_signal_trace(run_id: str, signal_name: str) -> dict:
    """Extract signal samples for a specific signal across tests in a run.

    Searches up to the 5 most recent test results in the run. Returns per-test
    samples, truncated to 100 samples per test.

    Args:
        run_id:      The UUID of the run.
        signal_name: Signal name as stored in test results (e.g. "EngineData.RPM").
    """
    client = get_request_client()
    try:
        summaries = await client.list_results(run_id=run_id, limit=_MAX_RESULTS_FOR_TRACE)
    except httpx.HTTPStatusError as exc:
        return {"error": f"API error {exc.response.status_code}", "run_id": run_id}

    tests_with_signal = []
    for summary in summaries:
        detail = await client.get_result_detail(summary["id"])
        if detail is None:
            continue
        signals = detail.get("signals", {})
        if signal_name not in signals:
            continue
        raw_samples = signals[signal_name]
        if not isinstance(raw_samples, list):
            continue
        truncated_samples, was_truncated, total = _truncate_signal(raw_samples, signal_name)
        entry = {
            "test_id": detail["test_id"],
            "samples": truncated_samples,
            "total_samples": total,
            "truncated": was_truncated,
        }
        tests_with_signal.append(entry)

    found = len(tests_with_signal) > 0
    note = None
    if found and any(t["truncated"] for t in tests_with_signal):
        note = (
            f"Samples truncated to {_MAX_SIGNAL_SAMPLES} per test. "
            f"Full trace available via run_id={run_id}."
        )
    if not found and len(summaries) == _MAX_RESULTS_FOR_TRACE:
        note = (
            f"Signal '{signal_name}' not found in the first {_MAX_RESULTS_FOR_TRACE} results. "
            "There may be more results not searched."
        )

    return {
        "run_id": run_id,
        "signal_name": signal_name,
        "found": found,
        "tests": tests_with_signal,
        "note": note,
    }


async def describe_failure(run_id: str, test_id: str) -> dict:
    """Get complete failure context for one test in one run.

    Combines run metadata, error messages, log output, and signal traces into
    a single response suitable for AI root-cause analysis.

    Signal traces are truncated to 100 samples for the 5 most-recorded signals.
    All raw data is returned — the AI performs the analysis.

    Args:
        run_id:  The UUID of the run.
        test_id: The test ID as declared in the YAML manifest.
    """
    client = get_request_client()

    # 1. Run context
    try:
        run = await client.get_run(run_id)
    except httpx.HTTPStatusError as exc:
        return {"error": f"API error {exc.response.status_code}", "run_id": run_id}
    if run is None:
        return {"error": "run not found", "run_id": run_id}

    # 2. Find the result for this test_id
    try:
        summaries = await client.list_results(run_id=run_id, limit=200)
    except httpx.HTTPStatusError as exc:
        return {"error": f"API error {exc.response.status_code}", "run_id": run_id}

    match = next((r for r in summaries if r["test_id"] == test_id), None)
    if match is None:
        return {
            "error": "test not found in run",
            "run_id": run_id,
            "test_id": test_id,
        }

    # 3. Full result detail
    detail = await client.get_result_detail(match["id"])
    if detail is None:
        return {"error": "result detail not found", "run_id": run_id, "test_id": test_id}

    # Build signal context
    signals: dict = detail.get("signals", {}) or {}
    captured_signal_names = list(signals.keys())
    signal_traces: dict[str, list] = {}
    signal_note = None
    shown_signals = captured_signal_names[:_MAX_SIGNALS_IN_DESCRIBE]
    truncated_count = 0
    for sname in shown_signals:
        raw = signals[sname]
        if isinstance(raw, list):
            trunc, was_trunc, _ = _truncate_signal(raw, sname)
            signal_traces[sname] = trunc
            if was_trunc:
                truncated_count += 1
    if truncated_count > 0 or len(captured_signal_names) > _MAX_SIGNALS_IN_DESCRIBE:
        parts = []
        if len(captured_signal_names) > _MAX_SIGNALS_IN_DESCRIBE:
            parts.append(
                f"showing {_MAX_SIGNALS_IN_DESCRIBE} of {len(captured_signal_names)} signals"
            )
        if truncated_count > 0:
            parts.append(f"first {_MAX_SIGNAL_SAMPLES} samples each")
        signal_note = "; ".join(parts) + f". Full trace in run_id={run_id}."

    # Run-level context
    total = run["total"]
    pass_rate = run["passed"] / total if total > 0 else 0.0
    duration_s = None
    if detail.get("completed_at") and detail.get("started_at"):
        duration_s = round(detail["completed_at"] - detail["started_at"], 3)

    errors = detail.get("errors", []) or []
    logs = detail.get("logs", []) or []

    return {
        # Identity
        "run_id": run_id,
        "test_id": test_id,
        "suite_name": run["suite_name"],
        "rig_id": run["rig_id"],
        "triggered_by": run.get("triggered_by"),
        # Timing
        "started_at": detail.get("started_at"),
        "completed_at": detail.get("completed_at"),
        "duration_s": duration_s,
        "run_started_at": run["started_at"],
        # Status
        "status": detail["status"],
        # Failure details — raw, for LLM consumption
        "errors": errors,
        "error_count": len(errors),
        "logs": logs,
        "log_count": len(logs),
        # Signal context
        "captured_signals": captured_signal_names,
        "signal_traces": signal_traces,
        "signal_note": signal_note,
        # Run-level context
        "pass_rate_in_run": round(pass_rate, 4),
        "run_status": run["status"],
        "total_failures_in_run": run["failed"] + run["errored"],
    }


__all__ = ["get_results", "get_signal_trace", "describe_failure"]
