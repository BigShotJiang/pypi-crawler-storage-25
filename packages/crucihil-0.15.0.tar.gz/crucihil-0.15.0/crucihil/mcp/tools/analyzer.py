"""MCP tool: analyze_component — SWC static analysis + AI signal matching.

Thin async wrapper around crucihil.discover.analyzer.analyze_component.
Requires the 'analyze' optional extra (tree-sitter).
"""

from __future__ import annotations


async def analyze_component(
    source_path: str,
    component_name: str,
    dbc_paths: list[str] | None = None,
    rig_toml_path: str | None = None,
    dependencies: list[str] | None = None,
    ai_provider: str | None = None,
) -> dict:
    """Extract the signal interface contract of a C/C++ software component.

    Parses source files with tree-sitter to extract identifiers, then uses AI
    fuzzy matching to map shim-layer identifiers (AUTOSAR RTE, COM module, custom
    HAL) to DBC signal names. Returns per-match confidence scores so engineers can
    review uncertain matches before they enter the test suite.

    Requires the 'analyze' optional extra:
        pip install 'crucihil[analyze]'

    Args:
        source_path:    Path to a .c/.cpp/.h file or a directory of source files.
        component_name: Label for this component in the output (e.g. "BrakeController").
        dbc_paths:      One or more DBC file paths. Supports any interface encoded in
                        DBC format (CAN, ETH, LIN, FlexRay).
        rig_toml_path:  Rig TOML — auto-discovers DBCs from [rig.definitions] and
                        infers interface type from key name (can_dbc → CAN, eth_dbc → ETH).
                        Merged with explicit dbc_paths; TOML-discovered DBCs take priority.
        dependencies:   Shim header directories or other SWC paths to also parse.
                        Identifiers from these files are included so the AI can match
                        signal names that live in the shim layer, not the SWC itself.
        ai_provider:    'anthropic', 'openai', or 'gemini'. Auto-detected from env vars
                        (ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_API_KEY) if None.
    """
    from crucihil.discover.analyzer import analyze_component as _analyze
    return _analyze(
        source_path=source_path,
        component_name=component_name,
        dbc_paths=dbc_paths,
        rig_toml_path=rig_toml_path,
        dependencies=dependencies,
        ai_provider=ai_provider,
    )
