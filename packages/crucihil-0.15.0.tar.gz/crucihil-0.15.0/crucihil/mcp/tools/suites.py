"""MCP tools for local test suite inspection and AI-assisted generation.

list_tests         — parse a YAML suite manifest and return test metadata.
generate_test_suite — scaffold YAML + Python stubs, optionally AI-generated.
"""

from __future__ import annotations

import os
import re

from crucihil.agent.manifest.loader import load_suite
from crucihil.hal.bse.loader import load_dbc
from crucihil.hal.models.exceptions import ConfigurationError

_TEST_GEN_SYSTEM_PROMPT = """\
You are a CruciHiL test engineer. Generate async Python HiL test functions.

RULES:
1. Each function: `async def test_<name>(rig: Rig) -> None`.
2. Use the CruciHiL rig API appropriate to each context item:
   - CAN signals:    rig.can.expect / rig.can.send / rig.sim.set / rig.sim.start_scheduling
   - Fault tests:    async with rig.fault.inject(rig.fault.can_dropout(...)):
   - Power/GPIO:     Leave as commented TODOs — no rig.power namespace exists yet
   - Sensor/camera/GPS/GNSS: Leave as descriptive assert stubs with clear TODO comments
     explaining what the engineer should wire up (e.g. "TODO: read from rig.udp or custom backend")
   - Integration flows: Combine rig calls with asyncio.sleep for timing
3. Assert with: `assert result.passed, result.fail_msg` for rig.can.expect calls.
   For non-rig assertions use: `assert <condition>, "<failure message>"`
4. No hardware details in test code (no interface names, IPs, CAN bus names).
5. Use context item names as-is. Do not invent new signal names.
6. Output ONLY the function bodies. No imports. Start with `async def test_`.
7. One function per context item concept. Keep each function focused and short.
8. For context items outside the rig.can API, write a clear TODO comment instead of
   leaving a bare pass. The engineer must know exactly what to fill in.
"""


async def list_tests(suite_path: str) -> dict:
    """Parse a YAML suite manifest and return metadata for every test.

    Returns the suite name, description, version, and per-test metadata
    including enabled status, tags, priority, timeout, and dependencies.
    Does not execute any tests.

    Args:
        suite_path: Path to the YAML manifest (e.g. "tests/suites/engine_validation.yaml").
    """
    try:
        suite = load_suite(suite_path)
    except ConfigurationError as exc:
        return {"error": str(exc), "suite_path": suite_path}
    except Exception as exc:
        return {"error": f"Failed to load suite: {exc}", "suite_path": suite_path}

    tests = [
        {
            "id": t.id,
            "name": t.name,
            "enabled": t.enabled,
            "skip_reason": t.skip_reason,
            "priority": t.priority,
            "tags": t.tags,
            "suite_types": t.suite_types,
            "hw_variants": t.hw_variants,
            "timeout": t.timeout,
            "depends_on": t.depends_on,
            "requirements": t.requirements,
            "ticket": t.ticket,
        }
        for t in suite.tests
    ]

    enabled_count = sum(1 for t in suite.tests if t.enabled)

    return {
        "suite_name": suite.suite.name,
        "description": suite.suite.description,
        "version": suite.suite.version,
        "suite_path": suite_path,
        "test_count": len(tests),
        "enabled_count": enabled_count,
        "tests": tests,
    }


def _extract_dbc_context(dbc_path: str) -> list[str]:
    """Return every MessageName.SignalName pair from a DBC file."""
    db = load_dbc(dbc_path)
    items = []
    for msg in db.messages:
        for sig in msg.signals:
            items.append(f"{msg.name}.{sig.name}")
    return items


def _extract_toml_context(rig_toml_path: str) -> list[str]:
    """Return hardware capability context from a rig TOML (no interface names — R1)."""
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # Python < 3.11
    with open(rig_toml_path, "rb") as f:
        data = tomllib.load(f)
    items = []
    rig = data.get("rig", {})
    for ecu_key, ecu_cfg in rig.get("ecus", {}).items():
        name = ecu_cfg.get("name", ecu_key) if isinstance(ecu_cfg, dict) else ecu_key
        items.append(f"ECU: {name}")
    for rail_name in rig.get("power", {}):
        items.append(f"power rail: {rail_name}")
    if "gpio" in rig:
        items.append("GPIO available")
    return items


def _build_test_gen_message(suite_name: str, description: str, rig_name: str, context_items: list[str]) -> str:
    return (
        f"Suite: {suite_name}\n"
        f"Description: {description}\n"
        f"Target rig: {rig_name}\n"
        f"Test context: {', '.join(context_items)}\n\n"
        "Generate async test functions. For each context item, write a function that "
        "covers presence/range/fault or whatever is appropriate for that item type."
    )


def _get_ai_provider_info(ai_provider: str | None) -> tuple[str, str] | None:
    """Return (provider, api_key) respecting ai_provider override or env auto-detect."""
    from crucihil.discover.ai_client import detect_provider
    if ai_provider is not None:
        _env_map = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "gemini": "GOOGLE_API_KEY",
        }
        key = os.environ.get(_env_map.get(ai_provider, ""), "")
        return (ai_provider, key) if key else None
    return detect_provider()


async def generate_test_suite(
    suite_name: str,
    description: str,
    rig_name: str = "Virtual_Sim",
    output_dir: str = "tests/suites",
    context_items: list[str] | None = None,
    rig_toml_path: str | None = None,
    dbc_path: str | None = None,
    ai_provider: str | None = None,
) -> dict:
    """Scaffold a YAML suite manifest and matching Python test stubs, then write them to disk.

    When context is available (from dbc_path, rig_toml_path, or context_items) and an AI
    API key is present in the environment (ANTHROPIC_API_KEY, OPENAI_API_KEY, or GOOGLE_API_KEY),
    the Python stubs are AI-generated with real assertions. Otherwise static placeholder stubs
    are written.

    Context is built from three optional sources, merged in this order:
      1. dbc_path — every MessageName.SignalName pair extracted from the DBC (exact names,
         no hallucination). Requires cantools-readable .dbc file.
      2. rig_toml_path — hardware capabilities (ECU names, power rails, GPIO presence).
         Interface names and IPs are never extracted (R1).
      3. context_items — manual additions: fault scenarios, integration flows, sensor feeds,
         or any plain description the DBC/TOML can't express.

    context_items is intentionally broad — it can contain any mix of:
      - CAN signal names:        "EngineData.RPM", "BrakePressure.Value"
      - Camera / sensor feeds:   "camera_front.fps", "lidar.point_cloud_rate"
      - GPS / GNSS:              "gps.latitude", "gnss.fix_quality"
      - Power modes / rails:     "power_mode: sleep/active/standby", "12v_rail voltage"
      - Fault scenarios:         "can_dropout on EngineData", "power glitch recovery"
      - Integration flows:       "ECU startup sequence", "shutdown and drain cycle"
      - Any plain description:   "verify camera latency under 50ms"

    Args:
        suite_name:      Snake-case name for the suite (e.g. "brake_validation").
        description:     One-sentence description of what the suite validates.
        rig_name:        Hardware variant to target (default "Virtual_Sim").
        output_dir:      Directory to write both files (default "tests/suites").
        context_items:   Optional manual context items merged on top of auto-extracted ones.
        rig_toml_path:   Optional path to a rig TOML — auto-extracts ECU/power/GPIO context.
        dbc_path:        Optional path to a DBC file — auto-extracts all signal names.
        ai_provider:     AI provider override ('anthropic', 'openai', 'gemini').
                         Auto-detected from env if None.
    """
    from pathlib import Path
    from crucihil.discover.ai_client import AIClient

    safe_name = re.sub(r"[^a-z0-9_]", "_", suite_name.lower()).strip("_")
    module_path = f"{output_dir.replace('/', '.')}.{safe_name}"

    # ── Auto-context extraction ────────────────────────────────────────────────
    auto_ctx: list[str] = []
    if dbc_path:
        try:
            auto_ctx.extend(_extract_dbc_context(dbc_path))
        except Exception as exc:
            return {"error": f"Failed to read DBC: {exc}", "suite_name": safe_name}
    if rig_toml_path:
        try:
            auto_ctx.extend(_extract_toml_context(rig_toml_path))
        except Exception as exc:
            return {"error": f"Failed to read rig TOML: {exc}", "suite_name": safe_name}
    all_context = auto_ctx + (context_items or [])

    # ── AI generation ──────────────────────────────────────────────────────────
    py_body: str | None = None
    if all_context:
        provider_info = _get_ai_provider_info(ai_provider)
        if provider_info:
            try:
                client = AIClient(provider_info[0], provider_info[1])
                py_body = client.complete(
                    _build_test_gen_message(safe_name, description, rig_name, all_context)
                )
            except Exception:
                py_body = None  # fall back to static template silently

    # ── Build YAML ─────────────────────────────────────────────────────────────
    if py_body:
        fn_names = re.findall(r"^async def (test_\w+)", py_body, re.MULTILINE)
    else:
        fn_names = [f"test_{safe_name}_basic"]

    test_entries = []
    for fn in fn_names:
        test_id = fn.removeprefix("test_")
        test_name = test_id.replace("_", " ")
        test_entries.append(
            f"  - id: {test_id}\n"
            f'    name: "{test_name}"\n'
            f"    suite_types: [smoke, regression]\n"
            f"    priority: high\n"
            f"    tags: [todo]\n"
            f"    requirements: []\n"
            f"    module: {module_path}\n"
            f"    function: {fn}\n"
        )

    yaml_content = f"""\
# {output_dir}/{safe_name}.yaml
# CruciHiL suite manifest v2 — {description}
#
# Run against virtual rig:
#   crucihil run --suite {output_dir}/{safe_name}.yaml --rig rigs/virtual.toml

suite:
  name: {safe_name}
  version: "1.0.0"
  description: "{description}"

hardware:
  required:
    - can0
  optional:
    - eth0

definitions:
  can_dbc: "defs/vehicle_can.dbc"

defaults:
  hw_variants: [{rig_name}]
  suite_types: [smoke, regression]
  timeout: 10.0
  enabled: true

tests:

{"".join(test_entries)}
  # Add more tests below — copy the block above and change id/name/function.
"""

    # ── Build Python ───────────────────────────────────────────────────────────
    py_header = f'''\
"""Test functions for the {safe_name} suite.

Generated by CruciHiL MCP — fill in assertions below.
Run with:
  crucihil run --suite {output_dir}/{safe_name}.yaml --rig rigs/virtual.toml
"""

from __future__ import annotations

import asyncio

from crucihil.hal.rig import Rig

'''

    if py_body:
        py_content = py_header + py_body + "\n"
    else:
        py_content = py_header + f'''\
async def test_{safe_name}_basic(rig: Rig) -> None:
    """TODO: {description}"""
    # Example: send a CAN message and assert a signal responds
    #
    # await rig.can.send(message="MyMessage", fields={{"Signal": 1.0}})
    # result = await rig.can.expect(
    #     signal="MyMessage.Signal",
    #     condition=lambda v: v == 1.0,
    #     timeout=2.0,
    # )
    # assert result.passed, result.fail_msg
    pass  # TODO: implement
'''

    out_path = Path(output_dir)
    yaml_path = out_path / f"{safe_name}.yaml"
    py_path = out_path / f"{safe_name}.py"

    try:
        out_path.mkdir(parents=True, exist_ok=True)
        yaml_path.write_text(yaml_content, encoding="utf-8")
        py_path.write_text(py_content, encoding="utf-8")
    except OSError as exc:
        return {"error": f"Could not write files: {exc}", "suite_name": safe_name}

    return {
        "suite_name": safe_name,
        "yaml_path": str(yaml_path),
        "py_path": str(py_path),
        "module_path": module_path,
        "yaml_content": yaml_content,
        "py_content": py_content,
        "auto_context_count": len(auto_ctx),
        "context_items_used": all_context,
        "next_steps": [
            f"Edit {py_path} — replace the pass stub with real assertions.",
            f"Run against the virtual rig to verify the scaffold works:",
            f"  crucihil run --suite {yaml_path} --rig rigs/virtual.toml",
            f"Add more test IDs to {yaml_path} and matching functions to {py_path}.",
        ],
    }


__all__ = ["list_tests", "generate_test_suite"]
