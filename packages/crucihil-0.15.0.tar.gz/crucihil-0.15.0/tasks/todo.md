# CruciHiL — Active Task Plan

## Phase 0 — Foundation ✅ COMPLETE

**Goal:** one real test running end-to-end against virtual simulation  
**Status:** All items shipped and verified. 98 tests passing.

### Completed items

- [x] HAL module structure + backend ABCs (`crucihil/hal/backends/base.py`)
- [x] Virtual backends: CAN, SOME/IP Events/Fields, DoIP, Power, GPIO (`crucihil/hal/backends/virtual/`)
- [x] BSE: DBC loader, Signal Store, Message Scheduler, Transport Router (`crucihil/hal/bse/`)
- [x] Exception hierarchy (`crucihil/hal/models/exceptions.py`)
- [x] Rig TOML config loader with Pydantic validation (`crucihil/hal/config/`)
- [x] Namespaces: `rig.can`, `rig.sim`, `rig.fault` (`crucihil/hal/namespaces/`)
- [x] Result models: `TestResult`, `ExpectResult`, `FaultDescriptor` (`crucihil/hal/models/results.py`)
- [x] Rig top-level fixture (`crucihil/hal/rig.py`)
- [x] Vehicle CAN DBC + virtual rig TOML (`defs/vehicle_can.dbc`, `rigs/virtual.toml`)
- [x] YAML v2 manifest schema + loader (`crucihil/agent/manifest/`)
- [x] Test runner: 6-step lifecycle, filtering, depends_on (`crucihil/agent/runner/`)
- [x] JUnit XML reporter (`crucihil/agent/reporter/junit.py`)
- [x] CLI: `crucihil run` + `crucihil version` (`crucihil/cli/main.py`)
- [x] Sample test suite + plain test functions (`tests/suites/`)
- [x] 98 unit + integration tests all passing

### Key architectural decisions locked in Phase 0

- FaultDescriptor pattern (R4) — fault methods return descriptors, not coroutines
- Signal Store built once from DBC at startup (R2) — never inside decode loop
- `frame_idx` monotonic int as CAN join key — never timestamp (R7)
- `base_dir = Path.cwd()` for DBC path resolution (project root, not TOML location)
- tomllib compat shim: `try: import tomllib / except ImportError: import tomli as tomllib`
- pytest-asyncio strict mode configured in `pyproject.toml`
- `requires-python = ">=3.10"` (running 3.10.12 in `.venv`)

---

## Phase 1 — MVP ✅ COMPLETE

**Goal:** one real engineer running real tests on real hardware  
**Status:** All items shipped. 129 tests passing (98 original + 31 new Phase 1 tests).

### Completed items

- [x] SocketCAN backend (`crucihil/hal/backends/socketcan/can.py`) — real CAN via Linux SocketCAN
  - Uses python-can with asyncio receive loop via `run_in_executor`
  - `block_arb_id` / `unblock_arb_id` for CAN dropout fault injection
- [x] PEAK CAN backend (`crucihil/hal/backends/peak/can.py`) — PCAN-USB adapters
  - Lazy import, fails gracefully with BackendError if pcan not installed
- [x] vsomeip wrapper backend (`crucihil/hal/backends/vsomeip/someip.py`)
  - Lazy import, fails gracefully if vsomeip bindings not installed
  - Events + Fields only (Methods deferred to Phase 2)
- [x] python-doip real backend (`crucihil/hal/backends/python_doip/doip.py`)
  - Uses `doipclient` library (lazy import, BackendError if not installed)
- [x] Backend registry updated — all real backends registered, custom module path support
  - Dotted `"module.path:ClassName"` syntax falls through to `importlib`
- [x] CAN dropout fault injection wired for all backends with `block_arb_id`
  - VirtualCANBackend and SocketCANBackend both support it
  - FaultNamespace detects `hasattr(backend, "block_arb_id")` — backend-agnostic
- [x] `rig.ecu` namespace with `flash()` via DoIP UDS 0x34/0x36/0x37
  - `crucihil/hal/namespaces/ecu.py` — ECUProxy + ECUNamespace
  - UDS RequestDownload / TransferData / RequestTransferExit sequence
  - `reset()` convenience method (0x11 ECUReset)
  - DoIP backends now connected at rig.connect() time (0x0E00 tester address)
- [x] HTML reporter (`crucihil/agent/reporter/html.py`)
  - Self-contained, zero external dependencies, all CSS/JS inlined
  - Pass rate badge, per-test expandable detail, sortable table
  - `crucihil run --html <path>` flag added to CLI
- [x] Local SQLite result cache (`crucihil/agent/cache/cache.py`)
  - SQLAlchemy ORM, 30-day pruning, write/query/close lifecycle
- [x] `crucihil agent start` command + `crucihil/agent/agent.py`
  - Persistent daemon — loads rig, opens cache, WebSocket client stub
  - Local-only mode when no `--cloud` URL given
- [x] `crucihil init` wizard (`crucihil/agent/init/wizard.py`)
  - Auto-detects CAN interfaces via `ip link show type can`
  - Prompts for Ethernet, power backend, DBC path
  - Validates generated TOML before writing
- [x] `[rig.udp]` + `[rig.uds]` TOML sections
  - Pydantic schema: `UDPInterfaceConfig`, `UDSConfig`
  - ABCs: `AbstractUDPBackend`, `AbstractUDSBackend` in `base.py`
  - Virtual stubs: `virtual/udp.py`, `virtual/uds.py`
  - Registry entries: `"virtual_udp"`, `"virtual_uds"`
- [x] JSON Schema for rig TOML + YAML manifest
  - `schemas/rig_config.schema.json` — generated from Pydantic RigConfig
  - `schemas/suite_manifest.schema.json` — hand-authored from dataclass spec
- [x] 31 new Phase 1 integration tests, all passing

### Phase 1 definition of done — status

- [ ] At least one real engineer (not the author) runs `crucihil run` against a physical ECU
- [x] SocketCAN, DoIP, and PEAK backends pass their own integration tests (mocked/simulated)
- [x] `crucihil agent start` connects to a stub cloud endpoint without crashing
- [x] SQLite cache writes a result row after every test
- [x] `crucihil init` produces a valid TOML that loads without ConfigurationError

---

## Phase 2 — Platform (Weeks 20–40)

**Goal:** web dashboard, cloud control plane, first paying customer.  
**Current status:** All tracks complete except first paid customer (417 tests).

### Step 1 — FastAPI control plane + PostgreSQL ✅ COMPLETE

- [x] `crucihil/server/config.py` — pydantic-settings (DATABASE_URL, SECRET_KEY, JWT params)
- [x] `crucihil/server/models/` — ORM models: RigRow, TestRunRow, TestResultRow
- [x] `crucihil/server/db/session.py` — engine factory, `set_engine`/`reset_engine` for tests
- [x] `alembic.ini` + `crucihil/server/db/migrations/versions/0001_initial.py`
- [x] `crucihil/server/services/auth.py` — API key hash (SHA-256), JWT (HS256)
- [x] `crucihil/server/services/result_sync.py` — upsert_run, batch_upsert (ON CONFLICT DO NOTHING), finalize_run
- [x] `crucihil/server/api/v1/` — auth, rigs, runs, results routers + router aggregator
- [x] `crucihil/server/api/ws/agent.py` — WS /ws/agent, agent_hello + result handlers
- [x] `crucihil/server/main.py` — FastAPI app factory with CORS and lifespan
- [x] 44 new tests (unit + integration) — SQLite StaticPool, no real PostgreSQL needed in CI
- [x] Total: 173 tests passing

### Step 2 — WebSocket agent ↔ cloud protocol ✅ COMPLETE

- [x] Replace WebSocket stub in `crucihil/agent/agent.py` with full protocol
  - JWT auth on connect: `POST /api/v1/auth/token` on startup, store token
  - Result streaming: `on_result()` callback sends `{"type": "result", ...}` after every test
  - Offline sync flush: on (re)connect, batch-POST SQLite cache via `/api/v1/results/sync`
  - JWT refresh: renew 5 min before expiry (background `_auth_loop` task)
  - Heartbeat: `{"type": "ping"}` every 30s (`_heartbeat_loop` task)
- [x] `crucihil/agent/cache/sync.py` — `flush_unsynced()` helper (reads cache, groups by run_id, POSTs, marks synced)
- [x] `crucihil/agent/cache/cache.py` — `synced_at` column, `query_unsynced()`, `mark_synced()`
- [x] `crucihil/hal/config/schema.py` — `CloudConfig` model, `cloud: CloudConfig | None` on `RigConfig`
- [x] `crucihil/agent/runner/runner.py` — `on_result` callback parameter on `run_suite()`
- [x] `crucihil/server/api/ws/agent.py` — `ping` handler updates `last_seen_at`
- [x] `crucihil/cli/main.py` — removed `--cloud` flag; cloud config comes from `[rig.cloud]` TOML section
- [x] 34 new tests (unit/agent + integration/agent) — 207 total passing

### Step 3 — MCP server ✅ COMPLETE

- [x] `crucihil/mcp/server.py` — FastMCP 3.x server, 11 tools registered, starts via `python -m crucihil.mcp.server`
- [x] `crucihil/mcp/client.py` — httpx async client with JWT cache + auto-refresh
- [x] `crucihil/mcp/tools/rigs.py` — `list_rigs`, `get_rig_config`
- [x] `crucihil/mcp/tools/runs.py` — `list_runs`, `get_run_summary`, `run_test_suite`, `cancel_run`
- [x] `crucihil/mcp/tools/results.py` — `get_results`, `get_signal_trace`, `describe_failure`
- [x] `crucihil/mcp/tools/signals.py` — `list_signals` (cantools DBC parse, local filesystem)
- [x] `crucihil/mcp/tools/suites.py` — `list_tests` (YAML manifest parse, local filesystem)
- [x] `crucihil/server/api/v1/runs.py` — added `POST /api/v1/runs` (create queued run + WS push)
- [x] `crucihil/server/api/ws/agent.py` — connection registry + `push_to_agent()` for server→agent push
- [x] 42 new tests — 249 total passing
- Config: `CRUCIHIL_BASE_URL` + `CRUCIHIL_API_KEY` env vars

### Step 4 — Docker Compose self-hosting stack ✅ COMPLETE

- [x] `Dockerfile.server` — multi-stage build (base: system+pip deps; app: crucihil/ + alembic.ini)
- [x] `Dockerfile.mcp` — same base; CMD: `python -m crucihil.mcp.server`
- [x] `Dockerfile.agent` — same base; CMD: `crucihil agent --rig /rigs/virtual.toml`
- [x] `docker-compose.yml` — db (postgres:16), server (port 8000), mcp (port 8001), agent (profile: agent)
- [x] `docker-compose.override.yml` — dev overrides: source mounts, uvicorn --reload, db port exposed
- [x] `.env.example` — all required vars documented
- [x] `crucihil/mcp/server.py` — `CRUCIHIL_MCP_TRANSPORT` env var: `stdio` (default) or `sse`
- [x] README self-hosting section — full bootstrap flow documented
- [x] All 249 tests still passing (no server code changes)

### Step 5 — React dashboard ✅ COMPLETE

- [x] `dashboard/` — React 18 + TypeScript strict + Vite 5; `vite build` passes zero TS errors
- [x] 7 pages: Login, Dashboard, Rigs, RigDetail, Runs, RunDetail, Settings
- [x] Auth: API key → JWT in localStorage; Axios interceptor + 401 redirect; session-expired banner
- [x] React Query polling: 15s on dashboard, 5s on active runs, stops on terminal status
- [x] `useRunStream` hook: WebSocket `/ws/viewer?token=…&run_id=…` for live results; silent fallback
- [x] `StatusBadge` (pass/fail/blocked/skip/queued/running with animations)
- [x] `RigOnlineIndicator` using `differenceInSeconds` against 90s threshold
- [x] Run cancellation button (calls `POST /api/v1/runs/{id}/cancel`)
- [x] Progress bar on RunDetailPage — live update via WS
- [x] Loading skeletons + error states on all pages
- [x] `Dockerfile.dashboard` + `docker-compose.override.yml` dashboard service
- [x] `dashboard/vercel.json` SPA routing config
- [x] `fly.server.toml` / `fly.mcp.toml` — Fly.io deployment configs
- [x] `.github/workflows/deploy.yml` — pytest → Fly deploy → Vercel auto-deploys
- [x] Server: `/ws/viewer` endpoint + `broadcast_result()` fan-out
- [x] `dev.sh` — starts backend via Docker + Vite HMR natively (Ctrl-C stops everything)
- [x] `setup.sh` — fixed to support both `docker compose` (v2) and `docker-compose` (v1)
- [x] All 249 tests still passing

### Step 6 — Customer readiness

#### Track D — Local virtual rig development ✅ COMPLETE (255 → 261 tests)

- [x] Agent: env var cloud config (`CRUCIHIL_BASE_URL` + `CRUCIHIL_API_KEY` override `[rig.cloud]` TOML)
- [x] Agent: `run_suite` WS command handler + `run_start`/`run_complete` lifecycle messages
- [x] Server WS: `run_start` → sets status=running; `run_complete` → calls finalize_run
- [x] `docker-compose.yml`: `CRUCIHIL_API_KEY` env var passed to agent service
- [x] `dev.sh`: `--agent` flag starts virtual rig agent alongside backend + dashboard
- [x] 6 new agent integration tests (255 → 261 passing)

#### Track A — RBAC + Rig Registration UI ✅ COMPLETE (261 → 278 tests)

- [x] Alembic migration 0002: `role` column on `rigs` table + `viewer_keys` table
- [x] `ViewerKeyRow` ORM model (`crucihil/server/models/viewer_key.py`)
- [x] `RigRow.role` column (default: `"admin"`)
- [x] `issue_jwt()` extended with `role` param; `generate_viewer_key()` added
- [x] `/api/v1/auth/token`: tries rig keys (role=rig.role), then viewer keys (role="viewer")
- [x] `deps.py`: shared `_decode_token` dep + `get_admin_rig` (403 if not admin)
- [x] `POST /api/v1/rigs`: dual auth (REGISTRATION_TOKEN OR admin JWT); new rig gets role="admin"
- [x] `DELETE /api/v1/rigs/{name}`: requires admin JWT; 204 No Content
- [x] `POST /api/v1/rigs/{name}/viewers`: create viewer key; returns key once
- [x] `DELETE /api/v1/rigs/{name}/viewers/{id}`: revoke viewer key
- [x] `POST /api/v1/runs`, `POST /api/v1/runs/{id}/cancel`: require admin JWT
- [x] Dashboard `AuthContext`: `role: 'admin' | 'viewer' | null` extracted from JWT
- [x] Dashboard `RigsPage`: "Register Rig" button + two-step modal (admin only)
- [x] Dashboard `RunDetailPage`: Cancel button gated on `role === 'admin'`
- [x] 23 RBAC integration tests — all green; TypeScript: zero errors
- [x] Total: 278 tests passing

#### Track B — `crucihil discover` CLI (AI-assisted rig setup) ✅ COMPLETE
- [x] `crucihil discover` command — probes interfaces, calls AI, generates TOML
- [x] TOML validation against RigConfig schema before write (warnings shown, write not blocked)
- [x] Markdown fence stripping on AI output (`_strip_fences`)
- [x] Gemini (gemini-2.0-flash) as third AI provider via `GOOGLE_API_KEY`
- [x] `--model` CLI flag to override default model per provider
- [x] Confirm-on-first-write via `typer.confirm()` (session token deferred to Phase 3)
- [x] CLI integration tests: validation, fence stripping, Gemini detection (379 tests total)

#### Track C — Production deployment ✅ COMPLETE
- [x] Fly.io + Vercel one-time setup
- [ ] First paid customer

#### Track F — OAuth 2.1 + PKCE multi-tenancy ✅ COMPLETE (394 → 417 tests)

- [x] `crucihil/server/models/oauth.py` — `OAuthClientRow` + `OAuthCodeRow` (256-bit codes stored as SHA256 hash, 10-min TTL, single-use)
- [x] `crucihil/server/db/migrations/versions/0005_oauth.py` — Alembic migration
- [x] `crucihil/server/api/v1/oauth.py` — full OAuth 2.1 AS:
  - `GET /.well-known/oauth-authorization-server` — RFC 8414 discovery
  - `POST /oauth/register` — RFC 7591 dynamic client registration (HTTPS-only redirect URIs)
  - `GET /oauth/authorize` — login form with CSRF form tokens (in-memory, 2-min TTL, single-use)
  - `POST /oauth/authorize` — login + code issuance (S256-only PKCE, constant-time, rate-limited)
  - `POST /oauth/token` — PKCE code exchange → user JWT with `iss` + `org_id`
- [x] `crucihil/server/services/auth.py` — `issue_user_jwt` now sets `iss` claim from `CRUCIHIL_SERVER_URL`
- [x] `crucihil/server/config.py` — `CRUCIHIL_SERVER_URL` setting
- [x] `fly.server.toml` — `CRUCIHIL_SERVER_URL = "https://crucihil-server.fly.dev"` in `[env]`
- [x] Org scoping: `rigs`, `runs`, `results` list endpoints filter by `(org_id = ? OR org_id IS NULL)` for user tokens; rig/viewer tokens unaffected
- [x] `crucihil/mcp/server.py` — `RemoteAuthProvider` + `JWTVerifier(HS256)` when `SECRET_KEY` + `MCP_SERVER_URL` set
- [x] `crucihil/mcp/client.py` — `bearer_token` param, `make_user_client()`, `get_request_client()` (auto OAuth fallback)
- [x] MCP tools (`rigs`, `runs`, `results`) — use `get_request_client()` for org-scoped responses; `register_rig` keeps admin client
- [x] `fly.mcp.toml` — `MCP_SERVER_URL` env var added; `SECRET_KEY` set via `fly secrets set`
- [x] 23 new OAuth integration tests — all passing
- [x] Claude.ai connects via OAuth; tools return only the authenticated user's org's rigs/runs/results

#### Track E — User auth UX ✅ COMPLETE (379 → 394 tests)

- [x] `POST /api/v1/setup` — first-time org bootstrap endpoint (org name + admin email + password)
- [x] `SetupPage` at `/setup` — sign-up flow for new deployments; auto-logs in, redirects on 409
- [x] Git hash in dashboard sidebar — `VITE_GIT_HASH` env var, `execSync` with explicit repo-root cwd, `'dev'` fallback; injected in `dev.sh` and `docker-compose.override.yml`
- [x] Alembic migration 0004 — `password_reset_token_hash` + `password_reset_token_expires_at` on `users`
- [x] `generate_password_reset_token` / `hash_password_reset_token` in `services/auth.py`
- [x] `send_password_reset_email` in `services/email.py` (Resend when key present, stdout fallback)
- [x] `POST /api/v1/auth/forgot-password` — always 200, rate-limited 5/5 min, no email enumeration
- [x] `GET /api/v1/auth/password-reset/{token}` — validate token, return email (does not consume)
- [x] `POST /api/v1/auth/reset-password` — consume token, set new password, return user JWT
- [x] `ForgotPasswordPage` at `/forgot-password` — email form → success state; 429 surfaced
- [x] `ResetPasswordPage` at `/reset-password?token=…` — validates on mount, expired-link state, password+confirm, auto-redirect on success
- [x] "Forgot your password?" link on `LoginPage`
- [x] 12 new integration tests covering happy path, single-use token, expiry, enumeration resistance, rate limiting, JWT type

---

## Phase 3 — Intelligence (Weeks 40–72)

**Goal:** AI differentiation, enterprise readiness, $10k MRR.

- [x] `generate_test_suite` MCP tool — YAML suite + Python stubs from natural language
  - `context_items: list[str]` — accepts CAN signals, camera, GPS, power, fault scenarios, integration flows
  - AI-generated assertions when key available; silent fallback to static template
  - YAML entries auto-derived from AI function names
  - 5 new tests (17 total in test_tools_suites.py)
- [x] `generate_test_suite` enhanced with DBC + TOML auto-context (425 tests passing)
  - `dbc_path` — auto-extracts all MessageName.SignalName pairs via cantools (R10)
  - `rig_toml_path` — extracts ECU names, power rails, GPIO presence (no interface names — R1)
  - manual `context_items` merged on top of auto-extracted context
  - returns `auto_context_count` + `context_items_used` in result dict
  - 8 new tests in `TestAutoContext`

---

## `analyze_component` — SWC Static Analysis + AI Signal Matching

**Goal:** Given a firmware SWC (source dir + dependencies + one or more DBCs), extract which
signals the component reads and writes — even when code uses shim/RTE naming, not raw DBC names.
Output feeds directly into `generate_test_suite` as context, eliminating signal guessing entirely.

### Design decisions (locked)

- `source_path` accepts a file OR directory (full SWC)
- `dependencies: list[str]` — shim headers, other SWCs, wrapper files; these are parsed too
  because signal names often live in the shim layer, not the SWC itself
- `dbc_paths: list[str]` — multiple DBCs supported; CAN and ETH signals can both be in DBC
  (confirmed by Rivian practice)
- `rig_toml_path` — auto-discovers DBCs from `[rig.definitions]`, infers interface type from
  key name (`can_dbc` → CAN, `eth_dbc` → ETH); explicit `dbc_paths` merged on top
- tree-sitter extraction is intentionally broad (fn calls, struct members, enums, macros) —
  the AI does the fuzzy matching, not exact string matching
- AI matching required for useful output; fallback (no key) returns raw identifiers only
- C and C++ both supported (`tree-sitter-c` + `tree-sitter-cpp`); covers arduino .ino files
- Confidence scoring per match: ≥0.85 high, 0.60–0.84 medium, <0.60 low
- `review_required: true` when confidence < 0.85
- ARXML/FIDL not supported in this version — DBC-only signal sources

### Output shape

```json
{
  "component": "brake_controller",
  "inputs": [
    { "signal": "EngineData.RPM",    "dbc": "defs/powertrain_can.dbc", "interface": "CAN",
      "matched_identifier": "Com_ReceiveSignal_EngineRPM", "confidence": 0.92, "review_required": false },
    { "signal": "BrakeDemand.Value", "dbc": "defs/chassis_eth.dbc",    "interface": "ETH",
      "matched_identifier": "Rte_Read_BC_BrakeDemand",    "confidence": 0.71, "review_required": true }
  ],
  "outputs": [
    { "signal": "BrakeStatus.Active", "dbc": "defs/powertrain_can.dbc", "interface": "CAN",
      "matched_identifier": "Rte_Write_BC_BrakeActive",  "confidence": 0.88, "review_required": false }
  ],
  "unmatched_identifiers": ["internal_state", "get_sensor_raw"],
  "confidence_summary": { "high": 2, "medium": 1, "low": 0 },
  "review_required_count": 1
}
```

### Build order

#### Step A — Example firmware project (CURRENT)

`tests/fixtures/example_firmware/` — realistic multi-SWC firmware for validation.
Must use mixed naming conventions (AUTOSAR RTE-style + COM-style) so the AI matching
is non-trivial. Signal names in shim headers must NOT appear verbatim in SWC source.

Structure:

```text
tests/fixtures/example_firmware/
├── defs/
│   ├── powertrain_can.dbc      ← Engine (RPM, CoolantTemp, OilPressure),
│   │                              Transmission (Gear, TorqueRequest),
│   │                              Brake (Pressure, Active) — CAN bus
│   └── chassis_eth.dbc         ← Suspension (HeaveRate, RollRate),
│                                  Steering (WheelAngle, TorqueFeedback),
│                                  BrakeDemand (Value, Source) — ETH-over-DBC
├── rte/                         ← AUTOSAR-style generated shim (Rte_Read/Write)
│   ├── Rte_Type.h
│   ├── Rte_EngineController.h  ← Rte_Read_EC_ThrottleCmd → EngineControl.Throttle
│   │                              Rte_Write_EC_EngineRPM → EngineData.RPM
│   └── Rte_BrakeController.h  ← Rte_Read_BC_BrakeDemand → BrakeDemand.Value
│                                  Rte_Write_BC_BrakeActive → BrakeStatus.Active
├── com/
│   ├── ComSignalIds.h          ← enum: COM_SIG_ENGINE_RPM, COM_SIG_BRAKE_DEMAND …
│   └── com_api.h               ← Com_ReceiveSignal / Com_SendSignal prototypes
├── swc/
│   ├── engine_controller/
│   │   ├── engine_controller.h
│   │   └── engine_controller.c ← reads ThrottleCmd + Mode via Rte_Read
│   │                              writes RPM + CoolantTemp + OilPressure via Rte_Write
│   │                              writes FaultActive if overtemp via Com_SendSignal
│   └── brake_controller/
│       ├── brake_controller.h
│       └── brake_controller.c  ← reads EngineRPM via Com_ReceiveSignal (CAN)
│                                  reads BrakeDemand via Rte_Read (ETH)
│                                  reads SteeringAngle via Rte_Read (ETH)
│                                  writes BrakeActive + BrakePressure via Rte_Write (CAN)
└── rig.toml                    ← [rig.definitions] can_dbc + eth_dbc pointing to both
```

Validation targets for Step A:

- `brake_controller` analyzed with both DBCs + rte/ as dependency → should identify
  signals from both CAN and ETH DBCs
- `engine_controller` analyzed with powertrain DBC only + rte/ → CAN signals only

#### Step B — `crucihil/discover/analyzer.py` (core logic)

Key implementation decisions:

- `AIClient.__init__` gains optional `system_prompt: str | None = None` — defaults to existing
  rig-config prompt; analyzer passes its own matching prompt. Backward-compatible.
- tree-sitter imports are LAZY (inside `_extract_identifiers`) — ImportError returns a
  clear error dict with install instructions. MCP server must not crash on import.
- AI `max_tokens` set to 4096 for signal matching (responses are larger than TOML gen).
- Confidence thresholds: ≥0.85 high (review_required=false), 0.60–0.84 medium
  (review_required=true), <0.50 excluded entirely.
- `_filter_identifiers` removes C stdlib/keywords and names < 4 chars before sending to AI.
- Identifier extraction collects `identifier`, `field_identifier`, `type_identifier` AST nodes.
- Language detection: `.c` → C parser, `.cpp`/`.ino`/`.cc`/`.cxx` → C++ parser, `.h` → try
  C++ first (headers often contain C++ even in C projects).
- TOML interface inference: key prefix before `_dbc` → interface label
  (`can_dbc` → "CAN", `eth_dbc` → "ETH", `lin_dbc` → "LIN", unknown → "unknown").
- Explicit `dbc_paths` + TOML-discovered DBCs are merged and deduplicated by resolved path.
- `analyze_component` is sync; MCP tool wraps in `asyncio.to_thread` if needed (actually
  `run_in_executor` pattern — but simpler: just call sync from async with `await
  asyncio.get_event_loop().run_in_executor(None, analyze_component, ...)`).
  Actually: MCP tools can just be `async def` that call sync functions directly since
  tree-sitter and httpx calls are fast enough. No threading needed.

AI system prompt for signal matching (stored as `_SIGNAL_MATCH_SYSTEM_PROMPT` in analyzer.py):

```text
You are a CruciHiL signal analyzer for automotive firmware.
Match identifiers from C/C++ source code to DBC signal names (MessageName.SignalName format).
Signals are NEVER used by their DBC name in source — they appear via shim layers:
  - AUTOSAR RTE: Rte_Read_<Port>_<Signal>, Rte_Write_<Port>_<Signal>
  - COM module: Com_ReceiveSignal(COM_SIG_X, &val), Com_SendSignal(COM_SIG_X, &val)
  - Custom HAL: get_<signal>(), set_<signal>(), HAL_CAN_Read<Signal>()
Direction rules:
  Read/Receive/Get/Input → INPUT to the SWC
  Write/Send/Set/Output → OUTPUT from the SWC
Output ONLY valid JSON (no markdown, no explanation):
{
  "inputs":  [{"signal":"Msg.Sig","dbc":"path","interface":"CAN","matched_identifier":"...","confidence":0.92}],
  "outputs": [...same...],
  "unmatched_identifiers": ["list of identifiers with no confident match"]
}
Only include matches with confidence >= 0.50. Do not guess wildly.
```

- [ ] Extend `crucihil/discover/ai_client.py` — add `system_prompt: str | None = None`
  to `AIClient.__init__`; use `self._system_prompt` in all three `_call_*` methods.

- [ ] `_collect_source_files(path: str) -> list[Path]`
  If path is file: return `[Path(path)]` (validate exists + is file).
  If path is dir: `rglob` for `*.c`, `*.cpp`, `*.h`, `*.ino`, `*.cc`, `*.cxx`.
  Raises `ValueError` if path doesn't exist.

- [ ] `_load_signal_corpus(dbc_paths: list[str] | None, rig_toml_path: str | None) -> list[dict]`
  1. If `rig_toml_path`: parse TOML, read `data["rig"]["definitions"]`, for each `*_dbc` key
     infer interface from prefix (`can_dbc`→CAN, `eth_dbc`→ETH, else key prefix uppercase).
  2. Merge with explicit `dbc_paths` (interface="unknown" unless inferable from path).
  3. Deduplicate by `str(Path(p).resolve())`.
  4. Load each DBC via `load_dbc()`, emit `{"signal":"Msg.Sig","dbc":path,"interface":iface}`.
  5. Returns list of signal dicts. Raises on DBC parse failure.

- [ ] `_filter_identifiers(identifiers: set[str]) -> list[str]`
  Remove: C/C++ keywords, stdlib function names, names < 4 chars, pure-numeric strings.
  Return sorted by length descending (longer names = more likely meaningful shim identifiers).
  Cap at 500 identifiers to stay within AI token budget.

- [ ] `_extract_identifiers(files: list[Path]) -> set[str]`
  Lazy-import tree-sitter. For each file: detect language from suffix, parse bytes,
  walk AST collecting `identifier`, `field_identifier`, `type_identifier` node text.
  Returns raw set (filtering happens in `_filter_identifiers`).
  On `ImportError`: raise `RuntimeError("tree-sitter not installed...")`.

- [ ] `_build_match_prompt(component_name, identifiers, corpus) -> str`
  Formats the user message: component name, identifier list (comma-separated),
  signal corpus as `MessageName.SignalName [dbc_path, INTERFACE]` per line.

- [ ] `_parse_ai_response(response_text: str, corpus: list[dict]) -> dict`
  Parse JSON from AI response. Add `review_required` flag per match.
  Build `confidence_summary` counts. Handle malformed JSON gracefully (return raw text).

- [ ] `analyze_component(source_path, component_name, dbc_paths, rig_toml_path, dependencies, ai_provider) -> dict`
  Full orchestration. Returns error dict on any fatal failure (bad path, bad DBC, etc.).
  No-AI-key path: returns `{"component":..., "identifiers_extracted":...,
  "signal_corpus_size":..., "note":"No AI key — matching skipped"}`.

- [ ] `pyproject.toml`: add `analyze = ["tree-sitter>=0.21", "tree-sitter-c>=0.21", "tree-sitter-cpp>=0.21"]`
  under `[project.optional-dependencies]`. Install in dev venv for tests.

#### Step C — MCP tool + server registration

- [ ] `crucihil/mcp/tools/analyzer.py`

  ```python
  async def analyze_component(source_path, component_name, dbc_paths=None,
                               rig_toml_path=None, dependencies=None, ai_provider=None) -> dict
  ```

  Calls `crucihil.discover.analyzer.analyze_component(...)` directly (sync call is fine
  for MCP tools — no blocking I/O in the hot path beyond the AI HTTP call which is
  already handled by httpx with a 60s timeout).
  Full docstring explaining all params — this is what the AI client sees via MCP.

- [ ] `crucihil/mcp/server.py`: import `analyze_component` from `tools/analyzer.py`,
  add `mcp.add_tool(analyze_component)`. Update `_INSTRUCTIONS` to mention the tool.

#### Step D — CLI command

- [ ] `crucihil analyze` in `crucihil/cli/main.py`

  ```text
  --source / -s   PATH        SWC source file or directory (required)
  --component / -c NAME       Component name label (required)
  --dbc           PATH        DBC file (repeatable, min 1 unless --rig given)
  --rig           PATH        Rig TOML for auto-DBC discovery
  --dep           PATH        Dependency path: shim headers, other SWCs (repeatable)
  --provider / -p NAME        AI provider override
  --output / -o   FORMAT      'pretty' (default) | 'json'
  ```

  Pretty output: colored table of inputs/outputs with confidence bars; list unmatched.
  JSON output: raw dict printed via `json.dumps(..., indent=2)`.
  Error if tree-sitter not installed: print install command and exit(1).

#### Step E — Tests

- [ ] Install tree-sitter in dev venv: `pip install "tree-sitter>=0.21" tree-sitter-c tree-sitter-cpp`
  Verify installed version; update pyproject.toml `analyze` extra to match.

- [ ] `tests/unit/discover/test_analyzer.py` — all sync tests, no AI key needed
  - `test_collect_single_file` — single .c file path
  - `test_collect_directory` — example_firmware/swc/engine_controller/ → finds .c + .h
  - `test_collect_directory_recursive` — example_firmware/swc/ → finds all SWC files
  - `test_collect_missing_path_raises` — ValueError on bad path
  - `test_load_corpus_single_dbc` — powertrain_can.dbc → 15 signals tagged CAN
  - `test_load_corpus_multi_dbc` — both DBCs → 26 signals, correct interface labels
  - `test_load_corpus_from_toml` — example_firmware/rig.toml → auto-discovers both DBCs
  - `test_load_corpus_deduplicates` — same DBC in dbc_paths + TOML → counted once
  - `test_load_corpus_bad_dbc_raises` — ConfigurationError on missing DBC
  - `test_extract_identifiers_c_file` — engine_controller.c → includes Rte_Write_EC_EngineRPM
  - `test_extract_identifiers_h_file` — Rte_EngineController.h → includes Rte_Read_EC_ThrottleCmd
  - `test_filter_identifiers_removes_keywords` — 'if', 'int', 'for' filtered out
  - `test_filter_identifiers_removes_short` — names < 4 chars filtered
  - `test_filter_identifiers_sorted_by_length` — longer names first
  - `test_analyze_no_ai_key` — returns identifiers + corpus size, no inputs/outputs
  - `test_analyze_bad_source_path` — returns error dict
  - `test_analyze_bad_dbc` — returns error dict

- [ ] `tests/integration/discover/__init__.py` — empty
- [ ] `tests/integration/discover/test_analyzer_integration.py` — mocks AI call
  - `test_brake_controller_multi_dbc` — mock AI returns realistic JSON with signals
    from both DBCs; verify inputs include BrakeDemand.Value (ETH) + EngineData.RPM (CAN),
    outputs include BrakeStatus.Active (CAN)
  - `test_engine_controller_can_only` — single DBC, rte/ as dep; mock AI
  - `test_review_required_flagging` — confidence 0.7 → review_required=true, 0.9 → false
  - `test_confidence_summary_counts` — verify high/medium/low counts are correct
  - `test_no_ai_key_fallback` — no env vars; verify note field + identifiers_extracted
  - `test_toml_auto_discovers_both_dbcs` — rig_toml_path only (no explicit dbc_paths);
    verify corpus includes signals from both DBCs

#### Step F — Docs

- [ ] Update `CLAUDE.md` Phase 3 checklist with `analyze_component` ✓ when done
- [ ] Update `docs/ARCHITECTURE.md` — Layer 5 tool list (add analyze_component)
- [ ] README: `crucihil analyze` usage section with example output

- [ ] AI failure analysis + coverage gap detection
- [ ] Pass/fail trend monitoring + regression alerting via MCP
- [ ] AI conversational fallback for rig setup (Level 3/4 graceful degradation)
- [ ] `crucihil discover` Path C — `crucihil discover` → AI generates TOML → confirm-on-first-write session tokens
- [ ] CANvas MCP integration (the flywheel)
- [ ] SOME/IP Methods
- [ ] dSPACE + NI adapters
- [ ] SSO, audit logs, on-premise option
- [ ] Kubernetes Helm chart
- [ ] First paid customer
