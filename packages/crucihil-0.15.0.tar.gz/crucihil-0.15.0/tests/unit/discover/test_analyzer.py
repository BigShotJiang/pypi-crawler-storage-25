"""Unit tests for crucihil.discover.analyzer."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

pytest.importorskip("tree_sitter_c", reason="requires crucihil[analyze]: pip install crucihil[analyze]")

from crucihil.discover.analyzer import (
    _build_match_prompt,
    _collect_source_files,
    _extract_identifiers,
    _filter_identifiers,
    _infer_interface,
    _load_signal_corpus,
    _parse_ai_response,
    _strip_json_fences,
    analyze_component,
)

# ---------------------------------------------------------------------------
# Fixture paths
# ---------------------------------------------------------------------------

_FIXTURE = Path("tests/fixtures/example_firmware")
_CAN_DBC  = str(_FIXTURE / "defs" / "powertrain_can.dbc")
_ETH_DBC  = str(_FIXTURE / "defs" / "chassis_eth.dbc")
_RIG_TOML = str(_FIXTURE / "rig.toml")
_BRAKE_SWC = str(_FIXTURE / "swc" / "brake_controller")
_ENGINE_SWC = str(_FIXTURE / "swc" / "engine_controller")
_RTE_DIR   = str(_FIXTURE / "rte")
_COM_DIR   = str(_FIXTURE / "com")


# ---------------------------------------------------------------------------
# _collect_source_files
# ---------------------------------------------------------------------------

def test_collect_source_files_single_file():
    f = _FIXTURE / "swc" / "engine_controller" / "engine_controller.c"
    result = _collect_source_files(str(f))
    assert len(result) == 1
    assert result[0] == f


def test_collect_source_files_directory():
    result = _collect_source_files(_BRAKE_SWC)
    assert any(p.suffix == ".c" for p in result)


def test_collect_source_files_missing_raises():
    with pytest.raises(ValueError, match="does not exist"):
        _collect_source_files("/nonexistent/path/swc.c")


# ---------------------------------------------------------------------------
# _infer_interface
# ---------------------------------------------------------------------------

def test_infer_interface_can():
    assert _infer_interface("can_dbc") == "CAN"


def test_infer_interface_eth():
    assert _infer_interface("eth_dbc") == "ETH"


def test_infer_interface_ethernet():
    assert _infer_interface("ethernet_dbc") == "ETH"


def test_infer_interface_lin():
    assert _infer_interface("lin_dbc") == "LIN"


def test_infer_interface_unknown():
    result = _infer_interface("mystery_dbc")
    assert result == "MYSTERY"


# ---------------------------------------------------------------------------
# _load_signal_corpus
# ---------------------------------------------------------------------------

def test_load_signal_corpus_from_explicit_dbc():
    corpus = _load_signal_corpus([_CAN_DBC], None)
    signals = [e["signal"] for e in corpus]
    assert "EngineData.RPM" in signals
    assert all(e["interface"] == "unknown" for e in corpus)


def test_load_signal_corpus_from_rig_toml():
    corpus = _load_signal_corpus(None, _RIG_TOML)
    signals = [e["signal"] for e in corpus]
    # CAN DBC signals
    assert "EngineData.RPM" in signals
    # ETH DBC signals
    assert "SuspensionData.HeaveRate" in signals


def test_load_signal_corpus_interface_labels():
    corpus = _load_signal_corpus(None, _RIG_TOML)
    by_iface = {e["signal"]: e["interface"] for e in corpus}
    assert by_iface["EngineData.RPM"] == "CAN"
    assert by_iface["SuspensionData.HeaveRate"] == "ETH"


def test_load_signal_corpus_deduplication():
    # Providing the same DBC twice should not double the corpus
    corpus = _load_signal_corpus([_CAN_DBC, _CAN_DBC], None)
    can_signals = [e for e in corpus if "EngineData" in e["signal"]]
    assert len(can_signals) == len({e["signal"] for e in can_signals})


def test_load_signal_corpus_toml_plus_explicit():
    # rig.toml covers both DBCs; adding CAN DBC again should not duplicate
    corpus_rig   = _load_signal_corpus(None, _RIG_TOML)
    corpus_extra = _load_signal_corpus([_CAN_DBC], _RIG_TOML)
    # sizes should be the same (CAN DBC already discovered via TOML)
    assert len(corpus_rig) == len(corpus_extra)


# ---------------------------------------------------------------------------
# _extract_identifiers
# ---------------------------------------------------------------------------

def test_extract_identifiers_finds_rte_calls():
    files = _collect_source_files(_ENGINE_SWC)
    ids = _extract_identifiers(files)
    assert "Rte_Read_EC_ThrottleCmd" in ids


def test_extract_identifiers_finds_com_signals():
    files = _collect_source_files(_ENGINE_SWC)
    ids = _extract_identifiers(files)
    assert "COM_SIG_FAULT_ACTIVE" in ids


def test_extract_identifiers_from_headers():
    files = _collect_source_files(_RTE_DIR)
    ids = _extract_identifiers(files)
    assert any("Rte_" in i for i in ids)


# ---------------------------------------------------------------------------
# _filter_identifiers
# ---------------------------------------------------------------------------

def test_filter_removes_noise():
    raw = {"int", "return", "void", "Rte_Read_EC_ThrottleCmd", "RPM"}
    result = _filter_identifiers(raw)
    assert "int" not in result
    assert "return" not in result
    assert "Rte_Read_EC_ThrottleCmd" in result


def test_filter_removes_short_names():
    raw = {"x", "ok", "rpm", "Rte_Write_EC_EngineRPM"}
    result = _filter_identifiers(raw)
    assert "x" not in result
    assert "ok" not in result


def test_filter_sorts_longest_first():
    raw = {"short_name", "a_very_long_identifier_name", "medium_id"}
    result = _filter_identifiers(raw)
    assert result[0] == "a_very_long_identifier_name"


def test_filter_caps_at_500():
    raw = {f"identifier_{i:04d}" for i in range(600)}
    result = _filter_identifiers(raw)
    assert len(result) <= 500


# ---------------------------------------------------------------------------
# _build_match_prompt
# ---------------------------------------------------------------------------

def test_build_match_prompt_contains_component():
    corpus = [{"signal": "EngineData.RPM", "dbc": "a.dbc", "interface": "CAN"}]
    prompt = _build_match_prompt("BrakeCtrl", ["Rte_Read_BC_RPM"], corpus)
    assert "BrakeCtrl" in prompt
    assert "Rte_Read_BC_RPM" in prompt
    assert "EngineData.RPM" in prompt


def test_build_match_prompt_contains_dbc_count():
    corpus = [
        {"signal": "EngineData.RPM",        "dbc": "a.dbc", "interface": "CAN"},
        {"signal": "SuspensionData.HeaveRate", "dbc": "b.dbc", "interface": "ETH"},
    ]
    prompt = _build_match_prompt("X", ["id1"], corpus)
    assert "2 DBC file(s)" in prompt


# ---------------------------------------------------------------------------
# _strip_json_fences
# ---------------------------------------------------------------------------

def test_strip_json_fences_removes_markdown():
    text = "```json\n{\"a\": 1}\n```"
    assert _strip_json_fences(text) == '{"a": 1}'


def test_strip_json_fences_no_fences():
    text = '{"a": 1}'
    assert _strip_json_fences(text) == '{"a": 1}'


# ---------------------------------------------------------------------------
# _parse_ai_response
# ---------------------------------------------------------------------------

_GOOD_AI_RESPONSE = json.dumps({
    "inputs": [
        {
            "signal": "EngineData.RPM",
            "dbc": "powertrain.dbc",
            "interface": "CAN",
            "matched_identifier": "COM_SIG_ENGINE_RPM",
            "confidence": 0.92,
        }
    ],
    "outputs": [
        {
            "signal": "BrakeStatus.Pressure",
            "dbc": "powertrain.dbc",
            "interface": "CAN",
            "matched_identifier": "Rte_Write_BC_BrakePressure",
            "confidence": 0.75,
        }
    ],
    "unmatched_identifiers": ["some_local_var"],
})

_CORPUS = [
    {"signal": "EngineData.RPM",     "dbc": "powertrain.dbc", "interface": "CAN"},
    {"signal": "BrakeStatus.Pressure", "dbc": "powertrain.dbc", "interface": "CAN"},
]


def test_parse_ai_response_happy_path():
    result = _parse_ai_response(_GOOD_AI_RESPONSE, _CORPUS)
    assert len(result["inputs"]) == 1
    assert result["inputs"][0]["signal"] == "EngineData.RPM"
    assert result["inputs"][0]["confidence"] == 0.92
    assert result["inputs"][0]["review_required"] is False  # >= 0.85


def test_parse_ai_response_review_required_below_threshold():
    result = _parse_ai_response(_GOOD_AI_RESPONSE, _CORPUS)
    assert result["outputs"][0]["review_required"] is True  # 0.75 < 0.85


def test_parse_ai_response_confidence_summary():
    result = _parse_ai_response(_GOOD_AI_RESPONSE, _CORPUS)
    assert result["confidence_summary"]["high"] == 1    # 0.92
    assert result["confidence_summary"]["medium"] == 1  # 0.75
    assert result["confidence_summary"]["low"] == 0


def test_parse_ai_response_review_required_count():
    result = _parse_ai_response(_GOOD_AI_RESPONSE, _CORPUS)
    assert result["review_required_count"] == 1


def test_parse_ai_response_deduplicates_same_signal():
    # Two shim paths both map to EngineData.RPM — only highest confidence kept
    response = json.dumps({
        "inputs": [
            {"signal": "EngineData.RPM", "dbc": "p.dbc", "interface": "CAN",
             "matched_identifier": "COM_SIG_ENGINE_RPM",      "confidence": 0.92},
            {"signal": "EngineData.RPM", "dbc": "p.dbc", "interface": "CAN",
             "matched_identifier": "Rte_Read_EC_EngineRPM",   "confidence": 0.95},
        ],
        "outputs": [],
        "unmatched_identifiers": [],
    })
    result = _parse_ai_response(response, [{"signal": "EngineData.RPM", "dbc": "p.dbc", "interface": "CAN"}])
    assert len(result["inputs"]) == 1
    assert result["inputs"][0]["matched_identifier"] == "Rte_Read_EC_EngineRPM"
    assert result["inputs"][0]["confidence"] == 0.95


def test_parse_ai_response_invalid_json():
    result = _parse_ai_response("not valid json at all", [])
    assert "parse_error" in result
    assert result["inputs"] == []


def test_parse_ai_response_strips_fences():
    wrapped = f"```json\n{_GOOD_AI_RESPONSE}\n```"
    result = _parse_ai_response(wrapped, _CORPUS)
    assert len(result["inputs"]) == 1


# ---------------------------------------------------------------------------
# analyze_component — integration-style (no AI key)
# ---------------------------------------------------------------------------

def test_analyze_component_no_ai_key(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    result = analyze_component(
        source_path=_BRAKE_SWC,
        component_name="BrakeController",
        rig_toml_path=_RIG_TOML,
        dependencies=[_RTE_DIR, _COM_DIR],
    )
    assert "note" in result
    assert result["signal_corpus_size"] > 0
    assert len(result["identifiers_extracted"]) > 0


def test_analyze_component_missing_source():
    result = analyze_component(
        source_path="/no/such/path",
        component_name="X",
        dbc_paths=[_CAN_DBC],
    )
    assert "error" in result


def test_analyze_component_no_dbc_or_rig():
    result = analyze_component(
        source_path=_ENGINE_SWC,
        component_name="EngineController",
    )
    assert "error" in result


def test_analyze_component_with_ai_mocked(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-fake")
    ai_response = json.dumps({
        "inputs": [
            {
                "signal": "EngineData.RPM",
                "dbc": _CAN_DBC,
                "interface": "CAN",
                "matched_identifier": "COM_SIG_ENGINE_RPM",
                "confidence": 0.93,
            }
        ],
        "outputs": [],
        "unmatched_identifiers": [],
    })
    with patch("crucihil.discover.analyzer.AIClient") as MockClient:
        instance = MagicMock()
        instance.complete.return_value = ai_response
        MockClient.return_value = instance

        result = analyze_component(
            source_path=_ENGINE_SWC,
            component_name="EngineController",
            dbc_paths=[_CAN_DBC],
        )

    assert result["component"] == "EngineController"
    assert len(result["inputs"]) == 1
    assert result["inputs"][0]["signal"] == "EngineData.RPM"
    assert result["files_analyzed"] > 0
    assert result["signal_corpus_size"] > 0
