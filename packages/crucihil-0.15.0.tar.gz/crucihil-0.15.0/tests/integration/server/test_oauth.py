"""Integration tests for OAuth 2.1 + PKCE authorization server.

Covers: discovery, dynamic client registration, authorize GET/POST, token exchange,
PKCE validation, code reuse protection, redirect_uri enforcement.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import secrets
import urllib.parse

import pytest

# ---------------------------------------------------------------------------
# Reset module-level state between tests
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def reset_oauth_module_state():
    """Clear in-memory dicts that persist across test runs within the same process."""
    from crucihil.server.api.v1 import oauth as oauth_mod
    oauth_mod._login_attempts.clear()
    oauth_mod._form_tokens.clear()
    yield
    oauth_mod._login_attempts.clear()
    oauth_mod._form_tokens.clear()


# ---------------------------------------------------------------------------
# PKCE helpers (mirrors the production logic in oauth.py)
# ---------------------------------------------------------------------------

def _pkce_pair() -> tuple[str, str]:
    """Return (verifier, challenge) using S256."""
    verifier = secrets.token_urlsafe(32)[:43]  # exactly 43 chars, valid charset
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def _register_client(client, redirect_uris: list[str] | None = None) -> str:
    """POST /oauth/register and return the client_id."""
    resp = client.post("/oauth/register", json={
        "client_name": "Test Client",
        "redirect_uris": redirect_uris or ["https://example.com/callback"],
    })
    assert resp.status_code == 201, resp.text
    return resp.json()["client_id"]


def _authorize_url_params(
    client_id: str,
    redirect_uri: str = "https://example.com/callback",
    challenge: str | None = None,
    state: str = "test-state-xyz",
) -> dict:
    if challenge is None:
        _, challenge = _pkce_pair()
    return {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "scope": "crucihil",
    }


def _extract_form_token(html: str) -> str:
    m = re.search(r'name="form_token"\s+value="([^"]+)"', html)
    assert m, "form_token not found in HTML"
    return m.group(1)


def _do_login(client, params: dict, email: str, password: str, *, form_html: str) -> str:
    """POST /oauth/authorize and follow the redirect to extract the auth code."""
    form_token = _extract_form_token(form_html)
    resp = client.post("/oauth/authorize", data={
        "client_id":        params["client_id"],
        "redirect_uri":     params["redirect_uri"],
        "state":            params["state"],
        "code_challenge":   params["code_challenge"],
        "scope":            params.get("scope", "crucihil"),
        "form_token":       form_token,
        "email":            email,
        "password":         password,
    }, follow_redirects=False)
    assert resp.status_code == 302, f"Expected redirect, got {resp.status_code}: {resp.text[:300]}"
    location = resp.headers["location"]
    qs = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
    assert "code" in qs, f"No code in redirect: {location}"
    return qs["code"][0]


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

def test_discovery_doc(client):
    resp = client.get("/.well-known/oauth-authorization-server")
    assert resp.status_code == 200
    data = resp.json()
    assert data["response_types_supported"] == ["code"]
    assert data["code_challenge_methods_supported"] == ["S256"]
    assert data["grant_types_supported"] == ["authorization_code"]
    assert data["require_pkce"] is True
    assert "/oauth/authorize" in data["authorization_endpoint"]
    assert "/oauth/token" in data["token_endpoint"]
    assert "/oauth/register" in data["registration_endpoint"]


# ---------------------------------------------------------------------------
# Dynamic client registration
# ---------------------------------------------------------------------------

def test_client_registration(client):
    resp = client.post("/oauth/register", json={
        "client_name": "My App",
        "redirect_uris": ["https://app.example.com/callback"],
    })
    assert resp.status_code == 201
    data = resp.json()
    assert "client_id" in data
    assert data["client_name"] == "My App"
    assert data["redirect_uris"] == ["https://app.example.com/callback"]


def test_registration_rejects_http_non_localhost(client):
    resp = client.post("/oauth/register", json={
        "redirect_uris": ["http://evil.example.com/callback"],
    })
    assert resp.status_code == 400
    assert "redirect_uri" in resp.json()["detail"].lower()


def test_registration_allows_localhost(client):
    resp = client.post("/oauth/register", json={
        "redirect_uris": ["http://localhost:3000/callback"],
    })
    assert resp.status_code == 201


def test_registration_requires_redirect_uris(client):
    resp = client.post("/oauth/register", json={"redirect_uris": []})
    assert resp.status_code == 400


def test_registration_enforces_max_redirect_uris(client):
    uris = [f"https://example.com/cb{i}" for i in range(11)]
    resp = client.post("/oauth/register", json={"redirect_uris": uris})
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Authorization GET — form rendering
# ---------------------------------------------------------------------------

def test_authorize_renders_form(client):
    client_id = _register_client(client)
    _, challenge = _pkce_pair()
    params = _authorize_url_params(client_id, challenge=challenge)
    resp = client.get("/oauth/authorize", params=params)
    assert resp.status_code == 200
    assert "Sign in" in resp.text
    assert "form_token" in resp.text


def test_authorize_invalid_client(client):
    params = _authorize_url_params("nonexistent-client-id")
    resp = client.get("/oauth/authorize", params=params)
    assert resp.status_code == 400


def test_authorize_unregistered_redirect_uri(client):
    client_id = _register_client(client)
    params = _authorize_url_params(client_id, redirect_uri="https://attacker.example.com/")
    resp = client.get("/oauth/authorize", params=params)
    assert resp.status_code == 400


def test_authorize_rejects_plain_pkce(client):
    client_id = _register_client(client)
    _, challenge = _pkce_pair()
    params = _authorize_url_params(client_id, challenge=challenge)
    params["code_challenge_method"] = "plain"
    resp = client.get("/oauth/authorize", params=params)
    assert resp.status_code == 400


def test_authorize_rejects_unknown_scope(client):
    client_id = _register_client(client)
    _, challenge = _pkce_pair()
    params = _authorize_url_params(client_id, challenge=challenge)
    params["scope"] = "crucihil openid unknown_scope"
    resp = client.get("/oauth/authorize", params=params)
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Authorization POST — login + code issuance
# ---------------------------------------------------------------------------

def test_authorize_login_issues_code(client, admin_user, org):
    client_id = _register_client(client)
    verifier, challenge = _pkce_pair()
    params = _authorize_url_params(client_id, challenge=challenge)

    get_resp = client.get("/oauth/authorize", params=params)
    assert get_resp.status_code == 200

    code = _do_login(client, params, admin_user.email, "password123", form_html=get_resp.text)
    assert len(code) > 20


def test_authorize_wrong_password_rerenders_form(client, admin_user, org):
    client_id = _register_client(client)
    _, challenge = _pkce_pair()
    params = _authorize_url_params(client_id, challenge=challenge)

    get_resp = client.get("/oauth/authorize", params=params)
    form_token = _extract_form_token(get_resp.text)

    resp = client.post("/oauth/authorize", data={
        **{k: params[k] for k in ("client_id", "redirect_uri", "state", "code_challenge", "scope")},
        "form_token": form_token,
        "email": admin_user.email,
        "password": "wrong-password",
    }, follow_redirects=False)
    assert resp.status_code == 200  # re-renders form, not redirect
    assert "Invalid email or password" in resp.text


def test_authorize_unknown_email_constant_time(client):
    client_id = _register_client(client)
    _, challenge = _pkce_pair()
    params = _authorize_url_params(client_id, challenge=challenge)

    get_resp = client.get("/oauth/authorize", params=params)
    form_token = _extract_form_token(get_resp.text)

    resp = client.post("/oauth/authorize", data={
        **{k: params[k] for k in ("client_id", "redirect_uri", "state", "code_challenge", "scope")},
        "form_token": form_token,
        "email": "nobody@nowhere.example",
        "password": "doesntmatter",
    }, follow_redirects=False)
    assert resp.status_code == 200
    assert "Invalid email or password" in resp.text


def test_authorize_csrf_token_single_use(client, admin_user, org):
    """Replaying the same form_token must fail."""
    client_id = _register_client(client)
    verifier, challenge = _pkce_pair()
    params = _authorize_url_params(client_id, challenge=challenge)

    get_resp = client.get("/oauth/authorize", params=params)
    form_token = _extract_form_token(get_resp.text)

    post_data = {
        **{k: params[k] for k in ("client_id", "redirect_uri", "state", "code_challenge", "scope")},
        "form_token": form_token,
        "email": admin_user.email,
        "password": "password123",
    }
    # First POST succeeds
    resp1 = client.post("/oauth/authorize", data=post_data, follow_redirects=False)
    assert resp1.status_code == 302

    # Second POST with same form_token fails
    resp2 = client.post("/oauth/authorize", data=post_data, follow_redirects=False)
    assert resp2.status_code == 400


# ---------------------------------------------------------------------------
# Token exchange
# ---------------------------------------------------------------------------

def _full_code_flow(client, admin_user) -> tuple[str, str]:
    """Return (code, verifier) via a complete authorize flow."""
    c_id = _register_client(client)
    verifier, challenge = _pkce_pair()
    params = _authorize_url_params(c_id, challenge=challenge)
    get_resp = client.get("/oauth/authorize", params=params)
    code = _do_login(client, params, admin_user.email, "password123", form_html=get_resp.text)
    return code, verifier, c_id


def test_token_exchange_pkce(client, admin_user, org):
    code, verifier, c_id = _full_code_flow(client, admin_user)

    resp = client.post("/oauth/token", data={
        "grant_type":     "authorization_code",
        "code":           code,
        "redirect_uri":   "https://example.com/callback",
        "client_id":      c_id,
        "code_verifier":  verifier,
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"
    assert data["expires_in"] > 0


def test_token_exchange_wrong_verifier(client, admin_user, org):
    code, _, c_id = _full_code_flow(client, admin_user)
    wrong_verifier = secrets.token_urlsafe(32)[:43]

    resp = client.post("/oauth/token", data={
        "grant_type":     "authorization_code",
        "code":           code,
        "redirect_uri":   "https://example.com/callback",
        "client_id":      c_id,
        "code_verifier":  wrong_verifier,
    })
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_grant"


def test_token_code_reuse(client, admin_user, org):
    """Second exchange with the same code must be rejected."""
    code, verifier, c_id = _full_code_flow(client, admin_user)

    payload = {
        "grant_type":     "authorization_code",
        "code":           code,
        "redirect_uri":   "https://example.com/callback",
        "client_id":      c_id,
        "code_verifier":  verifier,
    }
    resp1 = client.post("/oauth/token", data=payload)
    assert resp1.status_code == 200

    resp2 = client.post("/oauth/token", data=payload)
    assert resp2.status_code == 400
    assert resp2.json()["error"] == "invalid_grant"


def test_token_wrong_redirect_uri(client, admin_user, org):
    code, verifier, c_id = _full_code_flow(client, admin_user)

    resp = client.post("/oauth/token", data={
        "grant_type":     "authorization_code",
        "code":           code,
        "redirect_uri":   "https://example.com/OTHER",  # wrong URI
        "client_id":      c_id,
        "code_verifier":  verifier,
    })
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_grant"


def test_token_wrong_client_id(client, admin_user, org):
    code, verifier, c_id = _full_code_flow(client, admin_user)

    resp = client.post("/oauth/token", data={
        "grant_type":     "authorization_code",
        "code":           code,
        "redirect_uri":   "https://example.com/callback",
        "client_id":      "wrong-client-id",
        "code_verifier":  verifier,
    })
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_grant"


def test_token_unsupported_grant_type(client, admin_user, org):
    resp = client.post("/oauth/token", data={
        "grant_type":    "client_credentials",
        "code":          "x",
        "redirect_uri":  "https://example.com/callback",
        "client_id":     "x",
        "code_verifier": "x" * 43,
    })
    assert resp.status_code == 400
    assert resp.json()["error"] == "unsupported_grant_type"


def test_token_contains_org_id(client, admin_user, org):
    """JWT returned by /oauth/token must encode org_id in claims."""
    import base64 as b64
    code, verifier, c_id = _full_code_flow(client, admin_user)

    resp = client.post("/oauth/token", data={
        "grant_type":     "authorization_code",
        "code":           code,
        "redirect_uri":   "https://example.com/callback",
        "client_id":      c_id,
        "code_verifier":  verifier,
    })
    assert resp.status_code == 200
    token = resp.json()["access_token"]

    # Decode JWT payload (no signature verification needed here)
    payload_b64 = token.split(".")[1]
    # Add padding
    payload_b64 += "=" * (-len(payload_b64) % 4)
    payload = json.loads(b64.urlsafe_b64decode(payload_b64))
    assert payload.get("org_id") == admin_user.org_id
    assert payload.get("type") == "user"


# ---------------------------------------------------------------------------
# Org scoping via user JWT (rigs / runs / results)
# ---------------------------------------------------------------------------

def test_user_token_scopes_rigs(client, db_session, org, admin_user_headers, auth_headers):
    """A user token only sees rigs belonging to their org."""
    from crucihil.server.models.rig import RigRow
    from crucihil.server.services.auth import generate_api_key, hash_api_key, issue_user_jwt
    import time

    # Rig belonging to a different org — not visible to admin_user
    other_rig = RigRow(
        name="other-org-rig",
        api_key_hash=hash_api_key(generate_api_key()),
        org_id="other-org-id",
        created_at=time.time(),
    )
    db_session.add(other_rig)
    db_session.commit()

    # admin_user_headers uses user JWT with org_id = org.id
    resp = client.get("/api/v1/rigs", headers=admin_user_headers)
    assert resp.status_code == 200
    names = [r["name"] for r in resp.json()]
    assert "other-org-rig" not in names

    # rig token (no type=user) sees all rigs
    resp_rig = client.get("/api/v1/rigs", headers=auth_headers)
    assert resp_rig.status_code == 200
    names_rig = [r["name"] for r in resp_rig.json()]
    assert "other-org-rig" in names_rig
