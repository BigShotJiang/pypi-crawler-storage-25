"""Integration tests for crucihil.discover.analyzer using example_firmware fixture.

All AI calls are mocked — these tests verify the full pipeline (file collection →
corpus loading → identifier extraction → prompt building → response parsing)
without making real API calls or requiring tree-sitter edge-case handling.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

pytest.importorskip("tree_sitter_c", reason="requires crucihil[analyze]: pip install crucihil[analyze]")

from crucihil.discover.analyzer import analyze_component

_FIXTURE   = Path("tests/fixtures/example_firmware")
_CAN_DBC   = str(_FIXTURE / "defs" / "powertrain_can.dbc")
_ETH_DBC   = str(_FIXTURE / "defs" / "chassis_eth.dbc")
_RIG_TOML  = str(_FIXTURE / "rig.toml")
_BRAKE_SWC = str(_FIXTURE / "swc" / "brake_controller")
_ENGINE_SWC = str(_FIXTURE / "swc" / "engine_controller")
_RTE_DIR   = str(_FIXTURE / "rte")
_COM_DIR   = str(_FIXTURE / "com")


def _fake_ai_response(inputs: list[dict], outputs: list[dict]) -> str:
    return json.dumps({
        "inputs":  inputs,
        "outputs": outputs,
        "unmatched_identifiers": [],
    })


# ---------------------------------------------------------------------------
# Corpus loading — real DBC parsing, no AI
# ---------------------------------------------------------------------------

def test_corpus_from_rig_toml_contains_both_dbc_signals(monkeypatch):
    """Both CAN and ETH DBC signals appear when loading via rig TOML."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

    result = analyze_component(
        source_path=_BRAKE_SWC,
        component_name="BrakeController",
        rig_toml_path=_RIG_TOML,
        dependencies=[_RTE_DIR, _COM_DIR],
    )
    corpus_size = result.get("signal_corpus_size", 0)
    # powertrain_can.dbc has 15 signals, chassis_eth.dbc has 11 signals
    assert corpus_size >= 26


def test_identifiers_extracted_from_swc_and_deps(monkeypatch):
    """Identifier count should include IDs from RTE headers and COM headers."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

    result = analyze_component(
        source_path=_BRAKE_SWC,
        component_name="BrakeController",
        rig_toml_path=_RIG_TOML,
        dependencies=[_RTE_DIR, _COM_DIR],
    )
    assert len(result.get("identifiers_extracted", [])) > 10


# ---------------------------------------------------------------------------
# Full pipeline with mocked AI — engine controller (CAN only)
# ---------------------------------------------------------------------------

def test_engine_controller_can_signals(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-fake")

    ai_response = _fake_ai_response(
        inputs=[
            {"signal": "EngineControl.Throttle",  "dbc": _CAN_DBC, "interface": "CAN",
             "matched_identifier": "Rte_Read_EC_ThrottleCmd", "confidence": 0.95},
        ],
        outputs=[
            {"signal": "EngineData.RPM",           "dbc": _CAN_DBC, "interface": "CAN",
             "matched_identifier": "Rte_Write_EC_EngineRPM", "confidence": 0.93},
            {"signal": "FaultStatus.FaultActive",  "dbc": _CAN_DBC, "interface": "CAN",
             "matched_identifier": "COM_SIG_FAULT_ACTIVE",   "confidence": 0.88},
        ],
    )

    with patch("crucihil.discover.analyzer.AIClient") as MockClient:
        instance = MagicMock()
        instance.complete.return_value = ai_response
        MockClient.return_value = instance

        result = analyze_component(
            source_path=_ENGINE_SWC,
            component_name="EngineController",
            dbc_paths=[_CAN_DBC],
        )

    assert result["component"] == "EngineController"
    assert len(result["inputs"]) == 1
    assert len(result["outputs"]) == 2
    input_signals  = {m["signal"] for m in result["inputs"]}
    output_signals = {m["signal"] for m in result["outputs"]}
    assert "EngineControl.Throttle" in input_signals
    assert "EngineData.RPM" in output_signals


# ---------------------------------------------------------------------------
# Full pipeline with mocked AI — brake controller (cross-bus CAN + ETH)
# ---------------------------------------------------------------------------

def test_brake_controller_cross_bus_signals(monkeypatch):
    """Brake controller reads ETH signals and writes CAN signals."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-fake")

    ai_response = _fake_ai_response(
        inputs=[
            {"signal": "BrakeDemand.Value",         "dbc": _ETH_DBC, "interface": "ETH",
             "matched_identifier": "Rte_Read_BC_BrakeDemandVal", "confidence": 0.91},
            {"signal": "SteeringData.WheelAngle",   "dbc": _ETH_DBC, "interface": "ETH",
             "matched_identifier": "Rte_Read_BC_SteeringAngle",  "confidence": 0.87},
            {"signal": "EngineData.RPM",             "dbc": _CAN_DBC, "interface": "CAN",
             "matched_identifier": "COM_SIG_ENGINE_RPM",          "confidence": 0.93},
        ],
        outputs=[
            {"signal": "BrakeStatus.Active",        "dbc": _CAN_DBC, "interface": "CAN",
             "matched_identifier": "Rte_Write_BC_BrakeActive",   "confidence": 0.95},
            {"signal": "BrakeStatus.Pressure",      "dbc": _CAN_DBC, "interface": "CAN",
             "matched_identifier": "Rte_Write_BC_BrakePressure", "confidence": 0.70},
        ],
    )

    with patch("crucihil.discover.analyzer.AIClient") as MockClient:
        instance = MagicMock()
        instance.complete.return_value = ai_response
        MockClient.return_value = instance

        result = analyze_component(
            source_path=_BRAKE_SWC,
            component_name="BrakeController",
            rig_toml_path=_RIG_TOML,
            dependencies=[_RTE_DIR, _COM_DIR],
        )

    assert result["component"] == "BrakeController"
    input_ifaces = {m["interface"] for m in result["inputs"]}
    output_ifaces = {m["interface"] for m in result["outputs"]}
    assert "ETH" in input_ifaces
    assert "CAN" in input_ifaces
    assert "CAN" in output_ifaces


def test_brake_controller_review_required_flagged(monkeypatch):
    """Match with confidence < 0.85 should be flagged for review."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-fake")

    ai_response = _fake_ai_response(
        inputs=[],
        outputs=[
            {"signal": "BrakeStatus.Pressure", "dbc": _CAN_DBC, "interface": "CAN",
             "matched_identifier": "Rte_Write_BC_BrakePressure", "confidence": 0.70},
        ],
    )

    with patch("crucihil.discover.analyzer.AIClient") as MockClient:
        instance = MagicMock()
        instance.complete.return_value = ai_response
        MockClient.return_value = instance

        result = analyze_component(
            source_path=_BRAKE_SWC,
            component_name="BrakeController",
            rig_toml_path=_RIG_TOML,
        )

    assert result["review_required_count"] >= 1
    low_conf = [m for m in result["outputs"] if m["review_required"]]
    assert len(low_conf) >= 1


# ---------------------------------------------------------------------------
# Dependency resolution — shim headers parsed alongside SWC source
# ---------------------------------------------------------------------------

def test_dependency_headers_increase_identifier_count(monkeypatch):
    """Parsing RTE and COM headers alongside the SWC should yield more IDs."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

    result_no_deps = analyze_component(
        source_path=_BRAKE_SWC,
        component_name="BrakeController",
        rig_toml_path=_RIG_TOML,
    )
    result_with_deps = analyze_component(
        source_path=_BRAKE_SWC,
        component_name="BrakeController",
        rig_toml_path=_RIG_TOML,
        dependencies=[_RTE_DIR, _COM_DIR],
    )

    no_deps_count   = len(result_no_deps.get("identifiers_extracted", []))
    with_deps_count = len(result_with_deps.get("identifiers_extracted", []))
    assert with_deps_count >= no_deps_count
