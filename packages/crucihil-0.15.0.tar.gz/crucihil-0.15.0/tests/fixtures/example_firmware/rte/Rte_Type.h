#ifndef RTE_TYPE_H
#define RTE_TYPE_H

/* Generated RTE type definitions — do not edit manually */

#include <stdint.h>

typedef uint8_t  Std_ReturnType;
typedef uint8_t  uint8;
typedef int8_t   sint8;
typedef uint16_t uint16;
typedef int16_t  sint16;
typedef uint32_t uint32;
typedef int32_t  sint32;
typedef float    float32;

#define E_OK     ((Std_ReturnType)0x00u)
#define E_NOT_OK ((Std_ReturnType)0x01u)

/* EcuState values */
typedef enum {
    ECU_STATE_INIT    = 0,
    ECU_STATE_RUNNING = 1,
    ECU_STATE_FAULT   = 2,
    ECU_STATE_SLEEP   = 3,
} EcuState_t;

/* PowerState values */
typedef enum {
    POWER_STATE_OFF     = 0,
    POWER_STATE_STANDBY = 1,
    POWER_STATE_ACTIVE  = 2,
    POWER_STATE_FAULT   = 3,
} PowerState_t;

/* BrakeDemand source */
typedef enum {
    BRAKE_SRC_DRIVER    = 0,
    BRAKE_SRC_AEB       = 1,
    BRAKE_SRC_REGEN     = 2,
    BRAKE_SRC_STABILITY = 3,
} BrakeDemandSource_t;

#endif /* RTE_TYPE_H */
