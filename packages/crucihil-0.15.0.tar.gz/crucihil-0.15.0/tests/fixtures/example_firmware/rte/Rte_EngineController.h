#ifndef RTE_ENGINECONTROLLER_H
#define RTE_ENGINECONTROLLER_H

/*
 * Generated RTE interface for SWC: EngineController
 *
 * Signal mapping (RTE port → DBC signal):
 *   Rte_Read_EC_ThrottleCmd    ← EngineControl.Throttle   (powertrain_can.dbc)
 *   Rte_Read_EC_EngineMode     ← EngineControl.Mode       (powertrain_can.dbc)
 *   Rte_Write_EC_EngineRPM     → EngineData.RPM           (powertrain_can.dbc)
 *   Rte_Write_EC_CoolantTemp   → EngineData.CoolantTemp   (powertrain_can.dbc)
 *   Rte_Write_EC_OilPressure   → EngineData.OilPressure   (powertrain_can.dbc)
 *   Rte_Write_EC_BusVoltage    → PowerStatus.BusVoltage   (powertrain_can.dbc)
 *   Rte_Write_EC_PowerState    → PowerStatus.PowerState   (powertrain_can.dbc)
 *   Rte_Write_EC_EcuState      → FaultStatus.EcuState     (powertrain_can.dbc)
 */

#include "Rte_Type.h"

/* Inputs — engine control commands from gateway */
Std_ReturnType Rte_Read_EC_ThrottleCmd(uint8  *value);
Std_ReturnType Rte_Read_EC_EngineMode(uint8   *value);

/* Outputs — engine telemetry to bus */
Std_ReturnType Rte_Write_EC_EngineRPM(uint16   value);
Std_ReturnType Rte_Write_EC_CoolantTemp(sint8  value);
Std_ReturnType Rte_Write_EC_OilPressure(uint8  value);

/* Outputs — power and state reporting */
Std_ReturnType Rte_Write_EC_BusVoltage(uint8   value);
Std_ReturnType Rte_Write_EC_PowerState(uint8   value);
Std_ReturnType Rte_Write_EC_EcuState(uint8     value);

#endif /* RTE_ENGINECONTROLLER_H */
