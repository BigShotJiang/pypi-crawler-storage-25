#ifndef RTE_BRAKECONTROLLER_H
#define RTE_BRAKECONTROLLER_H

/*
 * Generated RTE interface for SWC: BrakeController
 *
 * Signal mapping (RTE port → DBC signal):
 *   Rte_Read_BC_BrakeDemandVal   ← BrakeDemand.Value          (chassis_eth.dbc)
 *   Rte_Read_BC_BrakeDemandSrc   ← BrakeDemand.Source         (chassis_eth.dbc)
 *   Rte_Read_BC_SteeringAngle    ← SteeringData.WheelAngle    (chassis_eth.dbc)
 *   Rte_Read_BC_LateralAccel     ← VehicleDynamics.LateralAccel (chassis_eth.dbc)
 *   Rte_Write_BC_BrakeActive     → BrakeStatus.Active         (powertrain_can.dbc)
 *   Rte_Write_BC_BrakePressure   → BrakeStatus.Pressure       (powertrain_can.dbc)
 *   Rte_Write_BC_ABSActive       → BrakeStatus.ABSActive      (powertrain_can.dbc)
 */

#include "Rte_Type.h"

/* Inputs — brake demand from ETH chassis bus */
Std_ReturnType Rte_Read_BC_BrakeDemandVal(float32 *value);
Std_ReturnType Rte_Read_BC_BrakeDemandSrc(BrakeDemandSource_t *source);

/* Inputs — vehicle dynamics from ETH chassis bus */
Std_ReturnType Rte_Read_BC_SteeringAngle(float32  *value);
Std_ReturnType Rte_Read_BC_LateralAccel(float32   *value);

/* Outputs — brake actuation status to powertrain CAN bus */
Std_ReturnType Rte_Write_BC_BrakeActive(uint8    value);
Std_ReturnType Rte_Write_BC_BrakePressure(float32 value);
Std_ReturnType Rte_Write_BC_ABSActive(uint8      value);

#endif /* RTE_BRAKECONTROLLER_H */
