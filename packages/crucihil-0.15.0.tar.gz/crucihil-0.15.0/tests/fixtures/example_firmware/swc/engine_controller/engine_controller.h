#ifndef ENGINE_CONTROLLER_H
#define ENGINE_CONTROLLER_H

#include "Rte_Type.h"

/* Thermal thresholds */
#define ENGINE_COOLANT_WARN_THRESHOLD  100   /* degC */
#define ENGINE_COOLANT_FAULT_THRESHOLD 110   /* degC */
#define ENGINE_OIL_MIN_PRESSURE        10    /* 0.1 bar units = 1.0 bar */

/* RPM limits */
#define ENGINE_RPM_IDLE   800   /* rpm units = 100 rpm */
#define ENGINE_RPM_REDLINE 60000 /* rpm units = 7500 rpm */

void EngineController_Init(void);
void EngineController_Step(void);

#endif /* ENGINE_CONTROLLER_H */
