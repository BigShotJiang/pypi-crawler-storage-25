/*
 * EngineController SWC — periodic runnable, 10ms cycle.
 *
 * Reads throttle command and engine mode from the gateway via RTE.
 * Computes engine RPM from throttle map, monitors thermal limits,
 * and reports telemetry and fault state back to the bus.
 *
 * All signal access goes through the RTE (Rte_Read_EC_* / Rte_Write_EC_*)
 * or the COM module (Com_SendSignal) — never raw CAN/ETH APIs.
 */

#include "engine_controller.h"
#include "Rte_EngineController.h"
#include "com/com_api.h"
#include "com/ComSignalIds.h"

/* Internal state */
static uint8      s_engine_mode       = 0;
static uint16     s_current_rpm       = 0;
static sint8      s_coolant_temp_raw  = 0;
static uint8      s_oil_pressure_raw  = 0;
static EcuState_t s_ecu_state         = ECU_STATE_INIT;

/* ---------------------------------------------------------------------------
 * Throttle-to-RPM lookup (simplified linear map)
 * throttle: 0–255 (0.392 %/count) → RPM: idle to redline
 * --------------------------------------------------------------------------- */
static uint16 throttle_to_rpm(uint8 throttle_raw)
{
    uint32 rpm_range = ENGINE_RPM_REDLINE - ENGINE_RPM_IDLE;
    return (uint16)(ENGINE_RPM_IDLE + ((uint32)throttle_raw * rpm_range) / 255u);
}

/* ---------------------------------------------------------------------------
 * Thermal protection — returns 1 if engine must be shutdown
 * --------------------------------------------------------------------------- */
static uint8 check_thermal_fault(sint8 coolant, uint8 oil_press)
{
    if (coolant >= ENGINE_COOLANT_FAULT_THRESHOLD) {
        return 1u;
    }
    if (oil_press < ENGINE_OIL_MIN_PRESSURE) {
        return 1u;
    }
    return 0u;
}

/* ---------------------------------------------------------------------------
 * Init — called once at ECU startup
 * --------------------------------------------------------------------------- */
void EngineController_Init(void)
{
    s_ecu_state = ECU_STATE_RUNNING;
    Rte_Write_EC_EcuState((uint8)s_ecu_state);
    Rte_Write_EC_PowerState((uint8)POWER_STATE_ACTIVE);
}

/* ---------------------------------------------------------------------------
 * Step — called every 10ms by the OS task scheduler
 * --------------------------------------------------------------------------- */
void EngineController_Step(void)
{
    uint8 throttle_cmd = 0u;
    uint8 fault_active = 0u;
    uint8 fault_code   = 0u;

    /* Read driver throttle demand and engine operating mode */
    Rte_Read_EC_ThrottleCmd(&throttle_cmd);
    Rte_Read_EC_EngineMode(&s_engine_mode);

    /* Simulate sensor reads (in a real ECU these come from ADC drivers) */
    /* For test purposes the values are driven via rig.sim or hardware ADC */
    s_current_rpm      = throttle_to_rpm(throttle_cmd);
    s_coolant_temp_raw = (sint8)(s_current_rpm / 400 - 40);  /* rough thermal model */
    s_oil_pressure_raw = (s_current_rpm > ENGINE_RPM_IDLE) ? 30u : 5u;

    /* Thermal and oil fault check */
    if (check_thermal_fault(s_coolant_temp_raw, s_oil_pressure_raw)) {
        fault_active   = 1u;
        fault_code     = (s_coolant_temp_raw >= ENGINE_COOLANT_FAULT_THRESHOLD) ? 0x01u : 0x02u;
        s_current_rpm  = 0u;
        s_ecu_state    = ECU_STATE_FAULT;
    }

    /* Publish engine telemetry via RTE */
    Rte_Write_EC_EngineRPM(s_current_rpm);
    Rte_Write_EC_CoolantTemp(s_coolant_temp_raw);
    Rte_Write_EC_OilPressure(s_oil_pressure_raw);
    Rte_Write_EC_EcuState((uint8)s_ecu_state);

    /* Publish fault state via COM (triggers immediate send on fault) */
    Com_SendSignal(COM_SIG_FAULT_ACTIVE, &fault_active);
    Com_SendSignal(COM_SIG_FAULT_CODE,   &fault_code);

    if (fault_active) {
        Com_TriggerIPDUSend(COM_SIG_FAULT_ACTIVE);
    }

    /* Update power bus voltage estimate (battery model stub) */
    uint8 bus_v = (s_ecu_state == ECU_STATE_FAULT) ? 110u : 140u; /* 0.1V units */
    Rte_Write_EC_BusVoltage(bus_v);
}
