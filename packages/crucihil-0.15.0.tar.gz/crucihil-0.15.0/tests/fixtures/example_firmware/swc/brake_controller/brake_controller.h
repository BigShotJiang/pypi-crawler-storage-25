#ifndef BRAKE_CONTROLLER_H
#define BRAKE_CONTROLLER_H

#include "Rte_Type.h"

/* ABS intervention thresholds */
#define BRAKE_ABS_LATERAL_THRESHOLD   5.0f   /* m/s2 — abs activates above this */
#define BRAKE_MAX_PRESSURE            80.0f  /* bar  — hard upper limit */
#define BRAKE_PRESSURE_RAMP_RATE      10.0f  /* bar/step at 10ms cycle */

/* Demand source priority (higher = higher priority) */
#define BRAKE_PRIORITY_DRIVER    0
#define BRAKE_PRIORITY_REGEN     1
#define BRAKE_PRIORITY_AEB       2
#define BRAKE_PRIORITY_STABILITY 3

void BrakeController_Init(void);
void BrakeController_Step(void);

#endif /* BRAKE_CONTROLLER_H */
