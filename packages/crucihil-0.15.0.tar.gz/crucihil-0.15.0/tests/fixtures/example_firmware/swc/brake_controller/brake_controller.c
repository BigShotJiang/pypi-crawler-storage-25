/*
 * BrakeController SWC — periodic runnable, 10ms cycle.
 *
 * Arbitrates brake demand from multiple sources (driver pedal, AEB, regen,
 * stability control). Reads vehicle dynamics from the chassis ETH bus and
 * engine RPM from the powertrain CAN bus to inform ABS and blending logic.
 * Outputs brake actuation state back to the powertrain CAN bus.
 *
 * Signals span two DBCs:
 *   powertrain_can.dbc — EngineData.RPM, BrakeStatus.*
 *   chassis_eth.dbc    — BrakeDemand.*, SteeringData.WheelAngle,
 *                        VehicleDynamics.LateralAccel
 *
 * All signal access goes through RTE (Rte_Read_BC_* / Rte_Write_BC_*)
 * or COM (Com_ReceiveSignal) — never raw transport APIs.
 */

#include "brake_controller.h"
#include "Rte_BrakeController.h"
#include "com/com_api.h"
#include "com/ComSignalIds.h"

/* Internal state */
static float32 s_applied_pressure  = 0.0f;
static uint8   s_abs_active        = 0u;
static uint8   s_brake_active      = 0u;

/* ---------------------------------------------------------------------------
 * Demand arbitration — highest-priority source wins
 * --------------------------------------------------------------------------- */
static float32 arbitrate_demand(float32 demand_val, BrakeDemandSource_t source)
{
    /* AEB and stability demands are safety-critical — clamp but never ignore */
    if (source == BRAKE_SRC_AEB || source == BRAKE_SRC_STABILITY) {
        if (demand_val > BRAKE_MAX_PRESSURE) {
            return BRAKE_MAX_PRESSURE;
        }
        return demand_val;
    }
    /* Driver and regen demands are rate-limited */
    float32 delta = demand_val - s_applied_pressure;
    if (delta > BRAKE_PRESSURE_RAMP_RATE)  delta = BRAKE_PRESSURE_RAMP_RATE;
    if (delta < -BRAKE_PRESSURE_RAMP_RATE) delta = -BRAKE_PRESSURE_RAMP_RATE;
    float32 result = s_applied_pressure + delta;
    if (result < 0.0f)                result = 0.0f;
    if (result > BRAKE_MAX_PRESSURE)  result = BRAKE_MAX_PRESSURE;
    return result;
}

/* ---------------------------------------------------------------------------
 * ABS logic — uses lateral acceleration and engine RPM to detect wheel lock
 * --------------------------------------------------------------------------- */
static uint8 evaluate_abs(float32 lateral_accel, uint16 engine_rpm_raw)
{
    /* Lateral accel above threshold indicates cornering — ABS more likely needed */
    if (lateral_accel > BRAKE_ABS_LATERAL_THRESHOLD ||
        lateral_accel < -BRAKE_ABS_LATERAL_THRESHOLD) {
        return 1u;
    }
    /* Engine RPM below idle while brakes are applied → wheel lock likely */
    if (s_brake_active && engine_rpm_raw < 6400u) { /* 6400 * 0.125 = 800 rpm */
        return 1u;
    }
    return 0u;
}

/* ---------------------------------------------------------------------------
 * Init
 * --------------------------------------------------------------------------- */
void BrakeController_Init(void)
{
    s_applied_pressure = 0.0f;
    s_abs_active       = 0u;
    s_brake_active     = 0u;
}

/* ---------------------------------------------------------------------------
 * Step — called every 10ms
 * --------------------------------------------------------------------------- */
void BrakeController_Step(void)
{
    float32           demand_val   = 0.0f;
    BrakeDemandSource_t demand_src = BRAKE_SRC_DRIVER;
    float32           steering_angle = 0.0f;
    float32           lateral_accel  = 0.0f;
    uint16            engine_rpm_raw = 0u;

    /* Read brake demand from chassis ETH bus (BrakeDemand message) */
    Rte_Read_BC_BrakeDemandVal(&demand_val);
    Rte_Read_BC_BrakeDemandSrc(&demand_src);

    /* Read vehicle dynamics from chassis ETH bus */
    Rte_Read_BC_SteeringAngle(&steering_angle);
    Rte_Read_BC_LateralAccel(&lateral_accel);

    /* Read engine RPM from powertrain CAN bus via COM
     * (used for wheel-lock detection in ABS logic) */
    Com_ReceiveSignal(COM_SIG_ENGINE_RPM, &engine_rpm_raw);

    /* Arbitrate and compute target pressure */
    float32 target_pressure = arbitrate_demand(demand_val, demand_src);

    /* ABS evaluation — may override pressure */
    s_abs_active = evaluate_abs(lateral_accel, engine_rpm_raw);
    if (s_abs_active) {
        /* Reduce pressure in ABS mode to prevent lock */
        target_pressure *= 0.6f;
    }

    s_applied_pressure = target_pressure;
    s_brake_active     = (s_applied_pressure > 0.5f) ? 1u : 0u;

    /* Publish actuation state to powertrain CAN bus (BrakeStatus message) */
    Rte_Write_BC_BrakeActive(s_brake_active);
    Rte_Write_BC_BrakePressure(s_applied_pressure);
    Rte_Write_BC_ABSActive(s_abs_active);
}
