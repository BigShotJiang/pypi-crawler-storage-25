#ifndef COM_SIGNAL_IDS_H
#define COM_SIGNAL_IDS_H

/*
 * COM signal ID enumeration — generated from DBC definitions.
 * Used with Com_ReceiveSignal / Com_SendSignal.
 *
 * Signal mapping (COM ID → DBC signal):
 *   COM_SIG_ENGINE_RPM         → EngineData.RPM           (powertrain_can.dbc)
 *   COM_SIG_ENGINE_COOLANT     → EngineData.CoolantTemp   (powertrain_can.dbc)
 *   COM_SIG_ENGINE_OIL_PRESS   → EngineData.OilPressure   (powertrain_can.dbc)
 *   COM_SIG_THROTTLE_CMD       → EngineControl.Throttle   (powertrain_can.dbc)
 *   COM_SIG_ENGINE_MODE        → EngineControl.Mode       (powertrain_can.dbc)
 *   COM_SIG_TRANS_GEAR         → TransmissionData.Gear    (powertrain_can.dbc)
 *   COM_SIG_TRANS_TORQUE_REQ   → TransmissionData.TorqueRequest (powertrain_can.dbc)
 *   COM_SIG_FAULT_ACTIVE       → FaultStatus.FaultActive  (powertrain_can.dbc)
 *   COM_SIG_FAULT_CODE         → FaultStatus.FaultCode    (powertrain_can.dbc)
 *   COM_SIG_ECU_STATE          → FaultStatus.EcuState     (powertrain_can.dbc)
 *   COM_SIG_BRAKE_DEMAND_VAL   → BrakeDemand.Value        (chassis_eth.dbc)
 *   COM_SIG_BRAKE_DEMAND_SRC   → BrakeDemand.Source       (chassis_eth.dbc)
 *   COM_SIG_STEERING_ANGLE     → SteeringData.WheelAngle  (chassis_eth.dbc)
 *   COM_SIG_LATERAL_ACCEL      → VehicleDynamics.LateralAccel (chassis_eth.dbc)
 *   COM_SIG_BRAKE_PRESSURE     → BrakeStatus.Pressure     (powertrain_can.dbc)
 *   COM_SIG_BRAKE_ACTIVE       → BrakeStatus.Active       (powertrain_can.dbc)
 *   COM_SIG_ABS_ACTIVE         → BrakeStatus.ABSActive    (powertrain_can.dbc)
 */

#include <stdint.h>

typedef uint16_t Com_SignalIdType;

typedef enum {
    /* Powertrain CAN signals */
    COM_SIG_THROTTLE_CMD       = 0x0001u,
    COM_SIG_ENGINE_MODE        = 0x0002u,
    COM_SIG_ENGINE_RPM         = 0x0010u,
    COM_SIG_ENGINE_COOLANT     = 0x0011u,
    COM_SIG_ENGINE_OIL_PRESS   = 0x0012u,
    COM_SIG_TRANS_GEAR         = 0x0020u,
    COM_SIG_TRANS_TORQUE_REQ   = 0x0021u,
    COM_SIG_BRAKE_PRESSURE     = 0x0030u,
    COM_SIG_BRAKE_ACTIVE       = 0x0031u,
    COM_SIG_ABS_ACTIVE         = 0x0032u,
    COM_SIG_FAULT_ACTIVE       = 0x0040u,
    COM_SIG_FAULT_CODE         = 0x0041u,
    COM_SIG_ECU_STATE          = 0x0042u,

    /* Chassis ETH signals */
    COM_SIG_HEAVE_RATE         = 0x0100u,
    COM_SIG_ROLL_RATE          = 0x0101u,
    COM_SIG_STEERING_ANGLE     = 0x0110u,
    COM_SIG_STEERING_TORQUE    = 0x0111u,
    COM_SIG_BRAKE_DEMAND_VAL   = 0x0120u,
    COM_SIG_BRAKE_DEMAND_SRC   = 0x0121u,
    COM_SIG_LATERAL_ACCEL      = 0x0130u,
    COM_SIG_LONG_ACCEL         = 0x0131u,
    COM_SIG_YAW_RATE           = 0x0132u,
} Com_SignalId_t;

#endif /* COM_SIGNAL_IDS_H */
