#ifndef COM_API_H
#define COM_API_H

#include "Rte_Type.h"
#include "ComSignalIds.h"

/*
 * COM module public API — signal read/write over CAN and ETH buses.
 * Internally routes to the correct transport based on signal ID range.
 */

/* Read a signal value from the COM receive buffer */
Std_ReturnType Com_ReceiveSignal(Com_SignalIdType signalId, void *signalDataPtr);

/* Write a signal value into the COM transmit buffer */
Std_ReturnType Com_SendSignal(Com_SignalIdType signalId, const void *signalDataPtr);

/* Trigger immediate transmission of a message containing this signal */
Std_ReturnType Com_TriggerIPDUSend(Com_SignalIdType signalId);

#endif /* COM_API_H */
