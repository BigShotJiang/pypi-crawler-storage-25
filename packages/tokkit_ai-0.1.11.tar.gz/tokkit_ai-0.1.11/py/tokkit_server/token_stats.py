"""Token savings estimation and tracking."""

import json
import os
import time
from pathlib import Path
from threading import Lock

CHARS_PER_TOKEN = 4  # rough estimate for code

_lock = Lock()


def show_savings() -> bool:
    """Check if inline savings display is enabled via TOKKIT_SHOW_SAVINGS=1."""
    return os.environ.get("TOKKIT_SHOW_SAVINGS") == "1"


def _data_dir() -> str:
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        base = os.path.join(xdg, "tokkit")
    else:
        base = os.path.join(Path.home(), ".local", "share", "tokkit")
    os.makedirs(base, exist_ok=True)
    return base


def _stats_path() -> str:
    return os.path.join(_data_dir(), "stats.json")


def _load_stats() -> dict:
    path = _stats_path()
    if os.path.exists(path):
        try:
            with open(path) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {
        "total_queries": 0,
        "total_tokens_used": 0,
        "total_tokens_avoided": 0,
        "total_tokens_saved": 0,
        "by_tool": {},
        "sessions": [],
    }


def _save_stats(stats: dict) -> None:
    path = _stats_path()
    with open(path, "w") as f:
        json.dump(stats, f, indent=2)


def estimate_tokens_avoided(tool_name: str, args: dict, result_text: str, session_project_path: str | None, raw_size: int | None = None) -> int:
    """Estimate how many tokens the agent would have consumed without tokkit.

    This is the key metric: what would the agent have had to read from raw files
    to get the same information that this tool call provided?
    """
    if tool_name == "clean_html":
        if raw_size:
            return raw_size // CHARS_PER_TOKEN
        return len(result_text) * 2 // CHARS_PER_TOKEN

    if tool_name == "compact_json":
        if raw_size:
            return raw_size // CHARS_PER_TOKEN
        return len(result_text) * 2 // CHARS_PER_TOKEN

    if tool_name == "search_markdown":
        if raw_size:
            return raw_size // CHARS_PER_TOKEN
        return len(result_text) * 2 // CHARS_PER_TOKEN

    if tool_name == "compact_output":
        if raw_size:
            return raw_size // CHARS_PER_TOKEN
        return len(result_text) * 2 // CHARS_PER_TOKEN

    if not session_project_path:
        return 0

    if tool_name == "index_repository":
        # Indexing is setup cost — no savings on this call itself
        return 0

    if tool_name in ("search_graph", "search_code"):
        # Without tokkit: agent would grep the repo, then read matching files entirely
        # Estimate: agent reads ~5 files of average 200 lines = ~1000 lines = ~20K chars
        # With tokkit: we return structured node data
        try:
            nodes = json.loads(result_text)
            if isinstance(nodes, list) and nodes:
                # Each matched node saves reading its entire file
                file_chars = _sum_file_sizes(session_project_path, nodes)
                return file_chars // CHARS_PER_TOKEN
        except (json.JSONDecodeError, TypeError):
            pass
        return 5000  # fallback: assume 5 files * 4K chars each / 4

    if tool_name == "get_code_snippet":
        # Without tokkit: agent reads the entire file
        # With tokkit: we return just the relevant function/class
        try:
            snippet = json.loads(result_text)
            if isinstance(snippet, dict) and snippet.get("file_path"):
                full_path = os.path.join(session_project_path, snippet["file_path"])
                if os.path.exists(full_path):
                    return os.path.getsize(full_path) // CHARS_PER_TOKEN
        except (json.JSONDecodeError, TypeError):
            pass
        return 2000  # fallback: average file

    if tool_name == "trace_path":
        # Without tokkit: agent reads multiple files to manually trace call chain
        # With tokkit: we return the exact path
        try:
            steps = json.loads(result_text)
            if isinstance(steps, list):
                # Each step in the path = one file the agent would read
                file_chars = _sum_file_sizes_from_steps(session_project_path, steps)
                return file_chars // CHARS_PER_TOKEN
        except (json.JSONDecodeError, TypeError):
            pass
        return 10000  # fallback: tracing is expensive

    if tool_name == "get_architecture":
        # Without tokkit: agent reads the entire repo structure + key files
        # This is the biggest savings — architecture overview vs reading everything
        total = _total_source_chars(session_project_path)
        return total // CHARS_PER_TOKEN

    if tool_name == "get_graph_schema":
        # Without tokkit: agent would scan files to understand the codebase structure
        return 3000

    if tool_name == "detect_changes":
        # Without tokkit: agent runs git diff + reads changed files
        return 2000

    if tool_name in ("index_status", "list_projects", "delete_project"):
        # Metadata queries — minimal savings
        return 100

    return 0


def _sum_file_sizes(repo_path: str, nodes: list) -> int:
    """Sum the file sizes for all unique files referenced by nodes."""
    seen = set()
    total = 0
    for node in nodes:
        fp = node.get("file_path") if isinstance(node, dict) else None
        if fp and fp not in seen:
            seen.add(fp)
            full = os.path.join(repo_path, fp)
            if os.path.exists(full):
                total += os.path.getsize(full)
    return total


def _sum_file_sizes_from_steps(repo_path: str, steps: list) -> int:
    """Sum file sizes for path trace steps."""
    seen = set()
    total = 0
    for step in steps:
        node = step.get("node", {}) if isinstance(step, dict) else {}
        fp = node.get("file_path")
        if fp and fp not in seen:
            seen.add(fp)
            full = os.path.join(repo_path, fp)
            if os.path.exists(full):
                total += os.path.getsize(full)
    return total


def _total_source_chars(repo_path: str) -> int:
    """Total characters in all source files (the full repo baseline)."""
    total = 0
    skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "dist", "target"}
    exts = {".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs"}
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for f in files:
            if any(f.endswith(ext) for ext in exts):
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
    return total


def record_query(tool_name: str, tokens_used: int, tokens_avoided: int) -> None:
    """Record a query's token metrics to persistent stats."""
    with _lock:
        stats = _load_stats()
        stats["total_queries"] += 1
        stats["total_tokens_used"] += tokens_used
        stats["total_tokens_avoided"] += tokens_avoided
        stats["total_tokens_saved"] += max(0, tokens_avoided - tokens_used)

        tool_stats = stats["by_tool"].setdefault(tool_name, {
            "queries": 0, "tokens_used": 0, "tokens_avoided": 0, "tokens_saved": 0
        })
        tool_stats["queries"] += 1
        tool_stats["tokens_used"] += tokens_used
        tool_stats["tokens_avoided"] += tokens_avoided
        tool_stats["tokens_saved"] += max(0, tokens_avoided - tokens_used)

        _save_stats(stats)


def get_stats() -> dict:
    """Get aggregate token savings statistics."""
    with _lock:
        stats = _load_stats()

    total_avoided = stats["total_tokens_avoided"]
    total_used = stats["total_tokens_used"]

    stats["savings_pct"] = (
        round((1 - total_used / total_avoided) * 100, 1)
        if total_avoided > 0 else 0.0
    )
    stats["efficiency_ratio"] = (
        round(total_avoided / total_used, 1)
        if total_used > 0 else 0.0
    )
    return stats


def make_meta(tool_name: str, result_text: str, session_project_path: str | None, raw_size: int | None = None) -> dict:
    """Build the _meta field for a tool response.

    Also records the query to persistent stats.
    Returns a dict to be added to the tool result.
    """
    tokens_used = len(result_text) // CHARS_PER_TOKEN
    tokens_avoided = estimate_tokens_avoided(tool_name, {}, result_text, session_project_path, raw_size=raw_size)
    tokens_saved = max(0, tokens_avoided - tokens_used)

    record_query(tool_name, tokens_used, tokens_avoided)

    return {
        "tokens_used": tokens_used,
        "tokens_avoided": tokens_avoided,
        "tokens_saved": tokens_saved,
    }


def reset_stats() -> None:
    """Reset all statistics."""
    with _lock:
        _save_stats({
            "total_queries": 0,
            "total_tokens_used": 0,
            "total_tokens_avoided": 0,
            "total_tokens_saved": 0,
            "by_tool": {},
            "sessions": [],
        })
