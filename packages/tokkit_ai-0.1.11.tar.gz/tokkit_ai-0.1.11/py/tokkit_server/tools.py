"""Tool dispatch for the MCP server."""

import json
import os
from pathlib import Path

from tokkit_server.token_stats import make_meta, get_stats, show_savings

_session_project_path: str | None = None
_session_db_path: str | None = None


def _get_cache_dir() -> str:
    if val := os.environ.get("TOKKIT_CACHE_DIR"):
        return val
    return str(Path("/tmp/tokkit"))


def _db_path_for(repo_path: str) -> str:
    project = Path(repo_path).resolve().name
    cache = _get_cache_dir()
    return str(Path(cache) / f"{project}.redb")


def _call_rust(fn_name: str, *args, **kwargs):
    """Lazy import of tokkit_py to allow tests to mock this function."""
    import tokkit_py
    return getattr(tokkit_py, fn_name)(*args, **kwargs)


def _ok(text: str, meta: dict | None = None) -> dict:
    body = text
    if meta and show_savings():
        saved = meta["tokens_saved"]
        pct = round((1 - meta["tokens_used"] / meta["tokens_avoided"]) * 100, 1) if meta["tokens_avoided"] > 0 else 0.0
        stats = get_stats()
        body += f"\n\n[tokkit: saved ~{saved:,} tokens ({pct}%) | session total: {stats['total_tokens_saved']:,} tokens saved]"
    result = {"content": [{"type": "text", "text": body}]}
    if meta:
        result["_meta"] = {"token_savings": meta}
    return result


def _err(text: str) -> dict:
    return {"content": [{"type": "text", "text": text}], "isError": True}


def handle_tool_call(tool_name: str, args: dict) -> dict:
    """Dispatch a tool call and return an MCP tool result dict."""
    global _session_project_path, _session_db_path

    try:
        if tool_name == "index_repository":
            path = args.get("path", "")
            mode = args.get("mode", "full")
            if not path:
                return _err("path is required")
            result = _call_rust("index_repository", path, mode)
            _session_project_path = path
            _session_db_path = _db_path_for(path)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "search_graph":
            if not _session_db_path:
                return _err("No project indexed in this session. Call index_repository first.")
            query = args.get("query", "")
            label = args.get("label")
            limit = args.get("limit")
            name_pattern = args.get("name_pattern")
            max_degree = args.get("max_degree")
            exclude_entry_points = args.get("exclude_entry_points")
            relationship = args.get("relationship")
            result = _call_rust(
                "search_nodes", _session_db_path, query,
                label=label, limit=limit, name_pattern=name_pattern,
                max_degree=max_degree, exclude_entry_points=exclude_entry_points,
                relationship=relationship,
            )
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "trace_path":
            if not _session_db_path:
                return _err("No project indexed in this session. Call index_repository first.")
            from_qn = args.get("from", "")
            to_qn = args.get("to", "")
            max_depth = args.get("max_depth")
            result = _call_rust("trace_path", _session_db_path, from_qn, to_qn, max_depth=max_depth)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "trace_fan":
            if not _session_db_path:
                return _err("No project indexed in this session. Call index_repository first.")
            function_name = args.get("function_name", "")
            direction = args.get("direction", "both")
            depth = args.get("depth", 3)
            result = _call_rust("trace_fan", _session_db_path, function_name, direction=direction, depth=depth)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "get_code_snippet":
            if not _session_db_path or not _session_project_path:
                return _err("No project indexed in this session. Call index_repository first.")
            qn = args.get("qualified_name", "")
            context = args.get("context_lines")
            result = _call_rust("get_snippet", _session_db_path, qn, _session_project_path, context_lines=context)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "get_architecture":
            if not _session_db_path:
                return _err("No project indexed in this session. Call index_repository first.")
            project = args.get("project", "")
            result = _call_rust("get_architecture", _session_db_path, project)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "search_code":
            if not _session_db_path or not _session_project_path:
                return _err("No project indexed in this session. Call index_repository first.")
            pattern = args.get("pattern", "")
            limit = args.get("limit")
            result = _call_rust("search_code", _session_db_path, _session_project_path, pattern, limit=limit)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "detect_changes":
            if not _session_db_path or not _session_project_path:
                return _err("No project indexed in this session. Call index_repository first.")
            result = _call_rust("detect_changes", _session_db_path, _session_project_path)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "index_status":
            if not _session_db_path:
                result = json.dumps({"indexed": False, "node_count": 0, "edge_count": 0})
                meta = make_meta(tool_name, result, _session_project_path)
                return _ok(result, meta)
            result = _call_rust("index_status", _session_db_path)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "list_projects":
            result = _call_rust("list_projects", _get_cache_dir())
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "delete_project":
            project = args.get("project", "")
            db_path = str(Path(_get_cache_dir()) / f"{project}.redb")
            deleted = _call_rust("delete_project", db_path)
            result = json.dumps({"deleted": deleted})
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "get_graph_schema":
            if not _session_db_path:
                return _err("No project indexed in this session. Call index_repository first.")
            result = _call_rust("get_graph_schema", _session_db_path)
            meta = make_meta(tool_name, result, _session_project_path)
            return _ok(result, meta)

        if tool_name == "clean_html":
            html = args.get("html", "")
            path = args.get("path", "")
            mode = args.get("mode", "markdown")
            if path:
                try:
                    with open(path) as f:
                        html = f.read()
                except (OSError, IOError) as exc:
                    return _err(f"Cannot read file: {exc}")
            if not html:
                return _err("html or path is required")
            from tokkit_scraper import clean_html
            cleaned = clean_html(html, mode=mode)
            meta = make_meta(tool_name, cleaned, _session_project_path, raw_size=len(html))
            return _ok(cleaned, meta)

        if tool_name == "compact_json":
            json_str = args.get("json", "")
            path = args.get("path", "")
            if path:
                try:
                    with open(path) as f:
                        json_str = f.read()
                except (OSError, IOError) as exc:
                    return _err(f"Cannot read file: {exc}")
            if not json_str:
                return _err("json or path is required")
            from tokkit_json import compact_json
            compacted = compact_json(json_str)
            meta = make_meta(tool_name, compacted, _session_project_path, raw_size=len(json_str))
            return _ok(compacted, meta)

        if tool_name == "search_markdown":
            path = args.get("path", "")
            query = args.get("query", "")
            if not path:
                return _err("path is required")
            try:
                with open(path) as f:
                    markdown = f.read()
            except (OSError, IOError) as exc:
                return _err(f"Cannot read file: {exc}")
            from tokkit_markdown import search_markdown
            result = search_markdown(markdown, query)
            meta = make_meta(tool_name, result, _session_project_path, raw_size=len(markdown))
            return _ok(result, meta)

        if tool_name == "compact_output":
            text = args.get("text", "")
            path = args.get("path", "")
            hint = args.get("hint")
            verbose = args.get("verbose", False)
            if path:
                try:
                    with open(path) as f:
                        text = f.read()
                except (OSError, IOError) as exc:
                    return _err(f"Cannot read file: {exc}")
            if not text:
                return _err("text or path is required")
            from tokkit_output import compact_output
            compacted = compact_output(text, hint=hint, verbose=verbose)
            meta = make_meta(tool_name, compacted, _session_project_path, raw_size=len(text))
            return _ok(compacted, meta)

        if tool_name == "get_token_stats":
            stats = get_stats()
            result = json.dumps(stats, indent=2)
            return _ok(result)

        return _err(f"Unknown tool: {tool_name}")

    except Exception as exc:
        return _err(f"Tool error: {exc}")
