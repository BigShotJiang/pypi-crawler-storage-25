"""Evidence building types for detection findings.

A :class:`Finding` is the output of a detection rule.  Detectors
build findings using the immutable builder pattern: each call to
:meth:`Finding.evidence` returns a **new** ``Finding`` with the
additional evidence appended.

Detectors yield findings directly as generators::

    yield (
        route.finding("Path ID guards write, body ID flows to target")
        .evidence(path_read, "Authorization uses path parameter")
        .evidence(body_read, "Write target from body parameter")
        .evidence(guard, "Guard condition uses path value")
        .evidence(effect, "Data write")
    )

Each :class:`Evidence` item records a domain object (the *fact*) and
a human-readable description of its role in the finding.  The
:data:`EvidenceFact` union type specifies which domain objects can
serve as evidence: input reads, effects, conditions, call sites,
and decorators.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Union

if TYPE_CHECKING:
    from flawed.calls import CallSite
    from flawed.conditions import Condition
    from flawed.core import Location
    from flawed.effects import Effect
    from flawed.function import Decorator
    from flawed.inputs import InputRead

# Union of domain objects that can serve as evidence
EvidenceFact = Union[
    "InputRead", "Effect", "Condition", "CallSite", "Decorator"
]
"""Domain objects that can serve as evidence in a finding.

Any object with a ``location`` attribute from the core domain model
is eligible.
"""


@dataclass(frozen=True)
class Evidence:
    """A single piece of evidence supporting a finding.

    Pairs a domain object (the *fact*) with a description of why
    it is relevant to the finding.  The ``location`` is extracted
    automatically from the fact.
    """

    fact: EvidenceFact
    """The domain object serving as evidence (InputRead, Effect, etc.)."""

    description: str
    """Human-readable description of this evidence's role in the finding."""

    location: Location
    """Source location of the evidence fact."""


@dataclass(frozen=True)
class Finding:
    """A detection finding with an evidence chain.

    Findings use the immutable builder pattern: each call to
    :meth:`evidence` returns a **new** ``Finding`` with the additional
    evidence appended.  The original finding is never modified.

    Created via :meth:`Route.finding() <flawed.route.Route.finding>`,
    not directly by rule authors::

        finding = route.finding("Missing auth guard")
        finding = finding.evidence(read, "Unguarded user input")
        finding = finding.evidence(effect, "Database write")
        yield finding

    Or chained in a single expression::

        yield (
            route.finding("Missing auth guard")
            .evidence(read, "Unguarded user input")
            .evidence(effect, "Database write")
        )
    """

    route_endpoint: str
    """Endpoint name of the route this finding applies to."""

    summary: str
    """One-line summary of the detection finding."""

    evidence_items: tuple[Evidence, ...] = ()
    """Accumulated evidence chain (in order of attachment)."""

    location: Location | None = None
    """Source location of the route registration, if available."""

    def evidence(self, fact: EvidenceFact, description: str) -> Finding:
        """Return a new Finding with one more evidence item.

        Args:
            fact: A domain object (InputRead, Effect, Condition, etc.).
            description: Why this fact is relevant to the finding.

        Returns:
            A new ``Finding`` with the evidence appended.
        """
        new_item = Evidence(
            fact=fact,
            description=description,
            location=_extract_location(fact),
        )
        return replace(self, evidence_items=(*self.evidence_items, new_item))


def _extract_location(fact: EvidenceFact) -> Location:
    """Pull the ``location`` attribute that every evidence-eligible type carries."""
    return fact.location
