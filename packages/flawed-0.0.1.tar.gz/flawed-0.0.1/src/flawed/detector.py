"""Detector registration decorator.

The ``@detector`` decorator marks a function as a detection rule.
Detection rules are Python generator functions that receive a
:class:`~flawed.repo.RepoView` and yield
:class:`~flawed.evidence.Finding` objects.

Example::

    from collections.abc import Iterator

    from flawed import detector
    from flawed.evidence import Finding
    from flawed.repo import RepoView

    @detector("my-rule-id")
    def detect(kb: RepoView) -> Iterator[Finding]:
        for route in kb.routes:
            yield route.finding("Example finding")
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

F = TypeVar("F", bound=Callable[..., object])


def detector(name: str) -> Callable[[F], F]:
    """Decorator that registers a function as a detection rule.

    Stores the rule name as ``__detector_name__`` on the function
    for runtime discovery by the detection engine.

    Args:
        name: Unique identifier for this detection rule
              (e.g. ``"path-guard-body-write"``).

    Example::

        @detector("missing-auth-on-write")
        def detect(kb: "RepoView") -> Iterator[Finding]:
            ...
    """

    def wrapper(fn: F) -> F:
        # Registration is a runtime concern; store the name as metadata
        fn.__detector_name__ = name  # type: ignore[attr-defined]
        return fn

    return wrapper
