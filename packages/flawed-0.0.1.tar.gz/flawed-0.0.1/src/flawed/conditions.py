"""Condition domain type for conditional expressions in code.

A :class:`Condition` represents a conditional expression (``if``,
``elif``, ternary) observed in analyzed code.  Each condition exposes
its :attr:`true_branch` and :attr:`false_branch` as queryable
:class:`~flawed.scopes.CodeScope` objects, enabling rules to
reason about what happens under different conditions.

The :attr:`error_branch` and :attr:`pass_branch` properties provide
semantic classification of branches:

- **error_branch** -- the branch that leads to an error return, raise,
  or abort.  Determined by the Semantic Layer by recognizing patterns
  like ``return jsonify({"error": ...}), 4xx``, ``raise Forbidden()``,
  or ``abort(403)``.
- **pass_branch** -- the branch that continues normal execution flow.

These are ``None`` when the Semantic Layer cannot determine which
branch is the error path.

Example::

    for cond in route.reachable.conditions():
        print(cond.expression, cond.operator)
        if cond.error_branch:
            # This condition acts as a guard
            writes_after = cond.pass_branch.effects(Mutation.write())
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flawed.core import Location
    from flawed.flow import ValueHandle
    from flawed.function import Function
    from flawed.scopes import CodeScope


@dataclass(frozen=True)
class Condition:
    """A conditional expression observed in code.

    Produced by Layer 2 when it identifies ``if`` / ``elif`` / ternary
    expressions.  Not directly constructable by rule authors -- obtained
    from :meth:`~flawed.scopes.CodeScope.conditions` or
    :meth:`~flawed.scopes.CodeScope.conditions_using`.

    Use :attr:`operator` to filter by comparison type, and
    :attr:`true_branch` / :attr:`false_branch` to query code that
    executes under each branch::

        for cond in route.body.conditions():
            if cond.operator in ("==", "!="):
                writes_in_true = cond.true_branch.effects(Mutation.write())
    """

    expression: str
    """Source text of the entire conditional expression."""

    location: Location
    """Source location of the ``if`` / ``elif`` keyword."""

    function: Function
    """The function containing this condition."""

    @property
    def left(self) -> ValueHandle:
        """The left operand of the condition as a trackable value."""
        raise NotImplementedError

    @property
    def right(self) -> ValueHandle:
        """The right operand of the condition as a trackable value."""
        raise NotImplementedError

    @property
    def operator(self) -> str:
        """The comparison operator (``==``, ``!=``, ``in``, ``not in``, ``<``, etc.)."""
        raise NotImplementedError

    @property
    def true_branch(self) -> CodeScope:
        """Code reachable when the condition evaluates to true.

        Returns a :class:`~flawed.scopes.CodeScope` covering the
        ``if`` / ``elif`` body.
        """
        raise NotImplementedError

    @property
    def false_branch(self) -> CodeScope:
        """Code reachable when the condition evaluates to false.

        Returns a :class:`~flawed.scopes.CodeScope` covering the
        ``else`` body (or the continuation after the ``if`` block when
        there is no explicit ``else``).
        """
        raise NotImplementedError

    @property
    def error_branch(self) -> CodeScope | None:
        """Branch that leads to an error return, raise, or abort.

        Determined by the Semantic Layer by recognizing error-return
        patterns.  Returns ``None`` when the error path cannot be
        determined (e.g. both branches have similar structure).
        """
        raise NotImplementedError

    @property
    def pass_branch(self) -> CodeScope | None:
        """Branch that continues normal execution flow.

        The complement of :attr:`error_branch`.  Returns ``None``
        when the pass path cannot be determined.
        """
        raise NotImplementedError
