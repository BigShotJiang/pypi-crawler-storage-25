"""Route domain type, HttpMethod enum, and HTTP method helpers.

Routes are HTTP endpoints identified by Layer 2 (Semantic Layer)
interpreters.  They are **not directly constructable** by rule
authors -- they are produced by analyzing framework-specific patterns
(e.g. ``@app.route``) and made available through
:attr:`~flawed.repo.RepoView.routes`.

Each route provides three scoping levels for queries:

- :attr:`Route.body` -- only the handler function body
- :attr:`Route.reachable` -- transitively reachable code from the handler
- :attr:`Route.full_stack` -- including lifecycle hooks and middleware

Example::

    from flawed import open_repo
    from flawed.route import POST, accepting

    kb = open_repo("path/to/store")
    for route in kb.routes.where(accepting(POST)):
        print(route.endpoint, route.url_rule, route.methods)
        for read in route.reachable.reads(Json()):
            print(f"  reads {read.source}")
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from flawed.evidence import Finding

if TYPE_CHECKING:
    from collections.abc import Callable

    from flawed.core import InterpretationProvenance, Location
    from flawed.function import Function
    from flawed.scopes import CodeScope


class HttpMethod(Enum):
    """Standard HTTP methods.

    Used in :attr:`Route.methods` as a ``frozenset[HttpMethod]`` and
    with the :func:`accepting` predicate factory for route filtering.
    Module-level aliases (``GET``, ``POST``, etc.) are provided for
    convenience.
    """

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    OPTIONS = "OPTIONS"
    HEAD = "HEAD"


# Module-level aliases for convenience, importable directly:
#     from flawed.route import POST, GET
GET = HttpMethod.GET
"""Alias for ``HttpMethod.GET``."""

POST = HttpMethod.POST
"""Alias for ``HttpMethod.POST``."""

PUT = HttpMethod.PUT
"""Alias for ``HttpMethod.PUT``."""

PATCH = HttpMethod.PATCH
"""Alias for ``HttpMethod.PATCH``."""

DELETE = HttpMethod.DELETE
"""Alias for ``HttpMethod.DELETE``."""

OPTIONS = HttpMethod.OPTIONS
"""Alias for ``HttpMethod.OPTIONS``."""

HEAD = HttpMethod.HEAD
"""Alias for ``HttpMethod.HEAD``."""


@dataclass(frozen=True)
class Route:
    """An HTTP endpoint identified by the Semantic Layer.

    Created by Layer 2 interpreters (e.g. the Flask route interpreter)
    by analyzing decorator patterns, URL rules, and handler function
    signatures.  Not directly constructable by rule authors.

    A route is the primary iteration target for per-route detectors::

        @detector("my-rule")
        def detect(kb: "RepoView") -> Iterator[Finding]:
            for route in kb.routes.where(accepting(POST)):
                # query route.body, route.reachable, or route.full_stack
                ...
    """

    endpoint: str
    """Framework endpoint name (e.g. ``"api.create_user"``, ``"profile"``)."""

    url_rule: str
    """URL rule pattern (e.g. ``"/users/<int:id>"``, ``"/profile"``)."""

    methods: frozenset[HttpMethod]
    """HTTP methods this endpoint accepts."""

    handler: Function
    """The handler function that processes requests to this endpoint."""

    blueprint: str | None
    """Flask blueprint name, or ``None`` if registered on the app directly."""

    location: Location
    """Source location of the route registration (e.g. the ``@app.route`` decorator)."""

    provenance: InterpretationProvenance
    """Semantic Layer provenance with supporting facts."""

    @property
    def body(self) -> CodeScope:
        """Direct handler body as a queryable scope.

        Covers only statements inside the handler function itself.
        Does not include transitively called functions.
        """
        raise NotImplementedError

    @property
    def reachable(self) -> CodeScope:
        """Transitively reachable code from the handler.

        Includes the handler body plus all functions called directly
        or indirectly.  This is the most common scope for detection
        rules.
        """
        raise NotImplementedError

    @property
    def full_stack(self) -> CodeScope:
        """Reachable code including lifecycle hooks and middleware.

        Extends :attr:`reachable` to cover before-request hooks,
        after-request hooks, error handlers, and middleware that
        execute as part of the request lifecycle for this route.
        """
        raise NotImplementedError

    def branch(self, method: HttpMethod) -> CodeScope | None:
        """Code scope for a single HTTP method branch, if present.

        Some handlers dispatch on the HTTP method internally
        (``if request.method == "POST": ...``).  Returns the
        :class:`~flawed.scopes.CodeScope` for the branch handling
        the given method, or ``None`` if no such branch is detected.
        """
        raise NotImplementedError

    def source(self, context: int = 3) -> str:
        """Return handler source text with surrounding context lines.

        Args:
            context: Number of lines before and after to include.
        """
        raise NotImplementedError

    def finding(self, summary: str) -> Finding:
        """Start building a detection finding for this route.

        Returns a :class:`~flawed.evidence.Finding` pre-populated
        with this route's endpoint and location.  Chain ``.evidence()``
        calls to build the evidence trail::

            yield route.finding("Missing auth guard").evidence(read, "Unguarded input")
        """
        return Finding(
            route_endpoint=self.endpoint,
            summary=summary,
            location=self.location,
        )


def accepting(*methods: HttpMethod) -> Callable[[Route], bool]:
    """Predicate factory for filtering routes by accepted HTTP methods.

    Returns a callable that returns ``True`` for routes whose
    :attr:`Route.methods` intersect with the given methods.

    Example::

        from flawed.route import POST, PUT, accepting

        write_routes = kb.routes.where(accepting(POST, PUT))
    """
    method_set = frozenset(methods)

    def predicate(route: Route) -> bool:
        return bool(route.methods & method_set)

    return predicate
