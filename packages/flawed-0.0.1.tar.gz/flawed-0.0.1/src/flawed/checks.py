"""Composable selectors for security-relevant validation functions.

Parallel to the effects module: where effects describe *what side
effects occur*, checks describe *what validation functions are called*.
Use checks to determine whether a route validates its inputs before
performing a sensitive operation.

The selector namespaces are:

- :class:`Crypto` -- cryptographic comparison and hashing
- :class:`Token` -- JWT / signed-token verification
- :class:`Schema` -- input schema validation (pydantic, marshmallow, etc.)
- :class:`Permission` -- authorization / permission checks (heuristic)

Compose checks with effects to express security patterns::

    from flawed.checks import Crypto, Token, Schema, Permission
    from flawed.calls import Fn
    from flawed.effects import Mutation, Session

    VALIDATORS = Crypto.compare() | Token.verify()
    SENSITIVE  = Mutation.any() | Session.write()

    validators = route.reachable.calls(VALIDATORS).with_argument_from(read.value)

Permission selectors use name-pattern matching (heuristic) since
authorization functions are project-specific.  Extend with
``Fn.fqn()`` for precision when the target project's auth functions
are known.
"""

from __future__ import annotations

from flawed.calls import Fn, FnSelector


class Crypto:
    """Selectors for cryptographic verification functions.

    Example::

        Crypto.compare()  # hmac.compare_digest, check_password_hash, etc.
        Crypto.hash()     # hashlib.sha256, hashlib.pbkdf2_hmac, etc.
    """

    @staticmethod
    def compare() -> FnSelector:
        """Hash/digest comparison functions.

        Matches: ``hmac.compare_digest``, ``werkzeug.security.check_password_hash``,
        ``bcrypt.checkpw``, ``passlib.hash.bcrypt.verify``, ``argon2.verify_password``.
        """
        return (
            Fn.fqn("hmac.compare_digest")
            | Fn.fqn("werkzeug.security.check_password_hash")
            | Fn.fqn("bcrypt.checkpw")
            | Fn.fqn("passlib.hash.bcrypt.verify")
            | Fn.fqn("argon2.verify_password")
        )

    @staticmethod
    def hash() -> FnSelector:
        """Cryptographic hash construction functions.

        Matches: ``hashlib.sha256``, ``hashlib.sha512``, ``hashlib.sha384``,
        ``hashlib.sha3_256``, ``hashlib.pbkdf2_hmac``, ``hashlib.scrypt``.
        """
        return (
            Fn.fqn("hashlib.sha256")
            | Fn.fqn("hashlib.sha512")
            | Fn.fqn("hashlib.sha384")
            | Fn.fqn("hashlib.sha3_256")
            | Fn.fqn("hashlib.pbkdf2_hmac")
            | Fn.fqn("hashlib.scrypt")
        )


class Token:
    """Selectors for token verification functions.

    Example::

        Token.verify()  # jwt.decode, itsdangerous loads, etc.
    """

    @staticmethod
    def verify() -> FnSelector:
        """Token decode / verification functions.

        Matches: ``jwt.decode``, ``jose.jwt.decode``, ``authlib.jose.jwt.decode``,
        ``itsdangerous.URLSafeTimedSerializer.loads``,
        ``itsdangerous.URLSafeSerializer.loads``, ``itsdangerous.Signer.unsign``.
        """
        return (
            Fn.fqn("jwt.decode")
            | Fn.fqn("jose.jwt.decode")
            | Fn.fqn("authlib.jose.jwt.decode")
            | Fn.fqn("itsdangerous.URLSafeTimedSerializer.loads")
            | Fn.fqn("itsdangerous.URLSafeSerializer.loads")
            | Fn.fqn("itsdangerous.Signer.unsign")
        )


class Schema:
    """Selectors for schema / input validation functions.

    Example::

        Schema.validate()  # pydantic, marshmallow, wtforms, cerberus, etc.
    """

    @staticmethod
    def validate() -> FnSelector:
        """Schema validation functions.

        Matches: ``pydantic.BaseModel.model_validate``,
        ``marshmallow.Schema.load``, ``wtforms.Form.validate``,
        ``cerberus.Validator.validate``, ``voluptuous.Schema.__call__``,
        and their common variants.
        """
        return (
            Fn.fqn("pydantic.BaseModel.model_validate")
            | Fn.fqn("pydantic.BaseModel.model_validate_json")
            | Fn.fqn("marshmallow.Schema.load")
            | Fn.fqn("marshmallow.Schema.loads")
            | Fn.fqn("wtforms.Form.validate")
            | Fn.fqn("wtforms.Form.validate_on_submit")
            | Fn.fqn("cerberus.Validator.validate")
            | Fn.fqn("voluptuous.Schema.__call__")
        )


class Permission:
    """Selectors for authorization / permission check functions.

    These use name matching (heuristic) since permission check
    functions are project-specific.  Extend with ``Fn.fqn()`` for
    precision when the target project's auth functions are known.

    Example::

        Permission.check()    # has_permission, authorize, etc.
        Permission.require()  # require_permission, require_role, etc.
    """

    @staticmethod
    def check() -> FnSelector:
        """Common permission-check function names.

        Matches: ``has_permission``, ``check_permission``, ``can_access``,
        ``authorize``, ``is_authorized``.
        """
        return Fn.matching(
            r"^(has_permission|check_permission|can_access|authorize|is_authorized)$"
        )

    @staticmethod
    def require() -> FnSelector:
        """Common permission-require function names.

        Matches: ``require_permission``, ``require_role``,
        ``require_admin``, ``require_auth``.
        """
        return Fn.matching(
            r"^(require_permission|require_role|require_admin|require_auth)$"
        )
