"""Generic and typed collection classes for domain objects.

Every query method on :class:`~flawed.scopes.CodeScope` returns a
typed collection.  Collections support:

- **Iteration** -- ``for item in collection``
- **Length** -- ``len(collection)``
- **Boolean** -- ``if collection`` (true when non-empty)
- **Chaining** -- ``collection.where(...).in_file(...).named(...)``
  Each filter returns a new collection; the original is unchanged.
- **Extraction** -- ``.first()`` returns the first item or ``None``;
  ``.one()`` returns the single item or raises if not exactly one.

The base :class:`DomainCollection` provides generic operations.
Typed subclasses add domain-specific filters (e.g.
:meth:`FunctionCollection.named`, :meth:`RouteCollection.accepting`).

Example::

    fns = kb.functions.in_file("app.py").named("create_user")
    fn = fns.one()  # exactly one match, or raises

    for route in kb.routes.where(accepting(POST)):
        reads = route.reachable.reads(Json())
        if reads:
            print(f"{route.endpoint}: {len(reads)} JSON reads")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Generic, Self, TypeVar

from flawed.calls import CallSite
from flawed.conditions import Condition
from flawed.effects import Effect
from flawed.function import Decorator, Function
from flawed.inputs import InputRead
from flawed.route import Route

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

    from flawed.calls import FnSelector
    from flawed.effects import EffectSelector
    from flawed.flow import ValueHandle
    from flawed.inputs import InputSource
    from flawed.route import HttpMethod

T = TypeVar("T")


class DomainCollection(Generic[T]):
    """Base collection with filtering, iteration, and location scoping.

    All typed collections inherit from this class.  Filtering methods
    return new collections (immutable chaining) -- the original
    collection is never modified.
    """

    def __iter__(self) -> Iterator[T]:
        raise NotImplementedError

    def __len__(self) -> int:
        raise NotImplementedError

    def __bool__(self) -> bool:
        raise NotImplementedError

    def where(self, predicate: Callable[[T], bool]) -> Self:
        """Filter items by an arbitrary predicate.

        Returns a new collection containing only items for which
        ``predicate(item)`` returns ``True``.

        Example::

            large_fns = kb.functions.where(lambda f: len(f.params) > 3)
        """
        raise NotImplementedError

    def first(self) -> T | None:
        """Return the first item, or ``None`` if the collection is empty."""
        raise NotImplementedError

    def one(self) -> T:
        """Return the single item; raise if not exactly one.

        Raises ``ValueError`` if the collection is empty or contains
        more than one item.
        """
        raise NotImplementedError

    def in_file(self, path: str) -> Self:
        """Filter to items located in the given file.

        Matches items whose source file path ends with the given
        string (suffix match).

        Example::

            helpers = kb.functions.in_file("helpers.py")
        """
        raise NotImplementedError

    def in_dir(self, path: str) -> Self:
        """Filter to items located in the given directory.

        Matches items whose source file path contains the given
        directory path.
        """
        raise NotImplementedError


class RouteCollection(DomainCollection[Route]):
    """Collection of Route domain objects with route-specific filters.

    Obtained from :attr:`~flawed.repo.RepoView.routes`.

    Example::

        post_routes = kb.routes.where(accepting(POST))
        api_routes = kb.routes.in_blueprint("api")
    """

    def accepting(self, method: HttpMethod) -> Self:
        """Filter to routes that accept the given HTTP method.

        Example::

            post_routes = kb.routes.accepting(POST)
        """
        raise NotImplementedError

    def in_blueprint(self, name: str) -> Self:
        """Filter to routes in the named blueprint.

        Example::

            api_routes = kb.routes.in_blueprint("api")
        """
        raise NotImplementedError


class FunctionCollection(DomainCollection[Function]):
    """Collection of Function domain objects with function-specific filters.

    Obtained from :attr:`~flawed.repo.RepoView.functions`,
    :attr:`~flawed.function.Function.calls`, or
    :attr:`~flawed.function.Function.called_by`.

    Example::

        fn = kb.functions.named("create_user").one()
        decorated = kb.functions.decorated_with("login_required")
    """

    def named(self, name: str) -> Self:
        """Filter to functions with the given short name.

        Example::

            fns = kb.functions.named("create_user")
        """
        raise NotImplementedError

    def with_fqn(self, fqn: str) -> Self:
        """Filter to functions with the given fully qualified name.

        Example::

            fns = kb.functions.with_fqn("myapp.views.create_user")
        """
        raise NotImplementedError

    def decorated_with(self, name_or_fqn: str) -> Self:
        """Filter to functions decorated with the given decorator.

        Matches by decorator short name or FQN.

        Example::

            protected = kb.functions.decorated_with("login_required")
        """
        raise NotImplementedError


class InputReadCollection(DomainCollection[InputRead]):
    """Collection of InputRead observations with source filters.

    Obtained from :meth:`~flawed.scopes.CodeScope.reads`.

    Example::

        all_reads = scope.reads(Json())
        form_reads = scope.reads(Form()).from_source(Form(key=Key("name")))
    """

    def from_source(self, source: InputSource) -> Self:
        """Filter to reads from the given input source.

        Narrows an existing collection to reads matching a more
        specific source.
        """
        raise NotImplementedError


class EffectCollection(DomainCollection[Effect]):
    """Collection of Effect observations with selector filters.

    Obtained from :meth:`~flawed.scopes.CodeScope.effects`.

    Example::

        writes = scope.effects(Mutation.write())
        narrow = writes.matching(Mutation.write())  # further filter
    """

    def matching(self, selector: EffectSelector) -> Self:
        """Filter to effects matching the given selector.

        Applies an additional category filter to an existing
        collection.
        """
        raise NotImplementedError


class ConditionCollection(DomainCollection[Condition]):
    """Collection of Condition domain objects with value-aware filters.

    Obtained from :meth:`~flawed.scopes.CodeScope.conditions` or
    :meth:`~flawed.scopes.CodeScope.conditions_using`.

    Example::

        all_conds = scope.conditions()
        guards = scope.conditions_using(read.value)
        eq_checks = all_conds.comparing("request.method", "POST")
    """

    def using(self, value: ValueHandle) -> Self:
        """Filter to conditions that reference the given value.

        Example::

            guards = scope.conditions().using(read.value)
        """
        raise NotImplementedError

    def comparing(self, left_pattern: str, right_pattern: str) -> Self:
        """Filter to conditions comparing expressions matching the patterns.

        Matches conditions where the left operand's expression matches
        ``left_pattern`` and the right operand matches ``right_pattern``.
        """
        raise NotImplementedError


class CallSiteCollection(DomainCollection[CallSite]):
    """Collection of CallSite domain objects with target and argument filters.

    Obtained from :meth:`~flawed.scopes.CodeScope.calls`.

    Example::

        db_calls = scope.calls(Fn.named("execute"))
        tainted = db_calls.with_argument_from(read.value)
    """

    def to(self, selector: FnSelector) -> Self:
        """Filter to call sites targeting functions matching the selector.

        Applies an additional target filter to an existing collection.
        """
        raise NotImplementedError

    def with_argument_from(self, value: ValueHandle) -> Self:
        """Filter to call sites with an argument derived from the given value.

        Checks whether any argument at the call site has a data-flow
        path from the given :class:`~flawed.flow.ValueHandle`.

        Example::

            validators = scope.calls(VALIDATORS).with_argument_from(read.value)
        """
        raise NotImplementedError


class DecoratorCollection(DomainCollection[Decorator]):
    """Collection of Decorator domain objects with name filters.

    Obtained from :attr:`~flawed.function.Function.decorators` or
    :meth:`~flawed.scopes.CodeScope.decorators`.

    Example::

        routes = fn.decorators.named("route")
        specific = fn.decorators.with_fqn("flask.Flask.route")
    """

    def named(self, name: str) -> Self:
        """Filter to decorators with the given short name.

        Example::

            route_decs = fn.decorators.named("route")
        """
        raise NotImplementedError

    def with_fqn(self, fqn: str) -> Self:
        """Filter to decorators with the given fully qualified name.

        Example::

            flask_routes = fn.decorators.with_fqn("flask.Flask.route")
        """
        raise NotImplementedError
