"""CodeScope and ControlFlowView for querying regions of code.

:class:`CodeScope` is the central query interface for the Rule API.
Every query about what happens in code -- reads, effects, conditions,
calls, decorators -- goes through a ``CodeScope``.  Scopes are
obtained from routes and functions at three granularity levels:

- ``.body`` -- direct function body only
- ``.reachable`` -- transitively reachable code (body + all callees)
- ``.full_stack`` -- reachable code plus lifecycle hooks and middleware

:class:`ControlFlowView` answers ordering and dominance questions
over source locations within a scope.

Example::

    scope = route.reachable
    reads = scope.reads(Json())
    effects = scope.effects(Mutation.write())
    cfg = scope.cfg

    for read in reads:
        for effect in effects:
            if read.value.flows_to(effect.target):
                if cfg.dominates(guard.location, effect.location):
                    print("Guard protects the write")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flawed.calls import FnSelector
    from flawed.collections import (
        CallSiteCollection,
        ConditionCollection,
        DecoratorCollection,
        EffectCollection,
        InputReadCollection,
    )
    from flawed.core import Location
    from flawed.effects import EffectSelector
    from flawed.flow import ValueHandle
    from flawed.inputs import InputSource


class CodeScope:
    """A queryable region of code (function body, reachable closure, etc.).

    The central query interface for the Rule API.  All domain queries
    (reads, effects, conditions, calls, decorators) are scoped to a
    ``CodeScope``, which determines what code is included in the search.

    Obtained from:

    - :attr:`Route.body <flawed.route.Route.body>` /
      :attr:`~flawed.route.Route.reachable` /
      :attr:`~flawed.route.Route.full_stack`
    - :attr:`Function.body <flawed.function.Function.body>` /
      :attr:`~flawed.function.Function.reachable`
    - :attr:`Condition.true_branch <flawed.conditions.Condition.true_branch>` /
      :attr:`~flawed.conditions.Condition.false_branch`

    Example::

        scope = route.reachable
        for read in scope.reads(Json()):
            for effect in scope.effects(Mutation.write()):
                if read.value.flows_to(effect.target):
                    yield route.finding("Input flows to write")
    """

    def conditions(self) -> ConditionCollection:
        """All conditional expressions in this scope.

        Returns every ``if`` / ``elif`` / ternary observed in the
        scoped code region.
        """
        raise NotImplementedError

    def conditions_using(self, value: ValueHandle) -> ConditionCollection:
        """Conditions that reference the given value.

        Filters to conditions where the given
        :class:`~flawed.flow.ValueHandle` appears as an operand.

        Example::

            guards = route.body.conditions_using(read.value)
        """
        raise NotImplementedError

    def reads(self, source: InputSource) -> InputReadCollection:
        """Input reads from the given source in this scope.

        Returns observations of code reading from the specified HTTP
        request container.  Pass a wildcard source (no key) to match
        all reads from that container type.

        Example::

            json_reads = scope.reads(Json())
            specific   = scope.reads(Json(path=JsonPath("$.user_id")))
        """
        raise NotImplementedError

    def effects(self, selector: EffectSelector) -> EffectCollection:
        """Effects matching the given selector in this scope.

        Returns side-effect observations matching the category selector.
        Compose selectors with ``|`` for multiple categories.

        Example::

            writes = scope.effects(Mutation.write())
            any_mutation = scope.effects(Mutation.any() | Session.write())
        """
        raise NotImplementedError

    def calls(self, selector: FnSelector) -> CallSiteCollection:
        """Call sites matching the given function selector in this scope.

        Returns call sites where the called function matches the
        selector.  Use :class:`~flawed.calls.Fn` to construct
        selectors.

        Example::

            db_calls = scope.calls(Fn.named("execute") | Fn.named("add"))
        """
        raise NotImplementedError

    def decorators(self) -> DecoratorCollection:
        """Decorators applied to functions in this scope."""
        raise NotImplementedError

    @property
    def cfg(self) -> ControlFlowView:
        """Control flow graph scoped to this code region.

        Returns a :class:`ControlFlowView` for answering ordering
        and dominance questions.

        - ``route.body.cfg`` is intra-procedural (single function).
        - ``route.reachable.cfg`` is interprocedural (when available).
        """
        raise NotImplementedError


@dataclass(frozen=True)
class ControlFlowView:
    """Answers ordering and dominance questions over source locations.

    Obtained via :attr:`CodeScope.cfg`.  All methods accept
    :class:`~flawed.core.Location` objects and return booleans.

    Example::

        cfg = route.body.cfg

        cfg.dominates(a, b)            # every path to b passes through a
        cfg.precedes(a, b)             # a executes before b on all paths
        cfg.ordered(a, b, c)           # a, b, c in order on all paths
        cfg.reachable_between(a, b)    # any execution path from a to b
    """

    def dominates(self, a: Location, b: Location) -> bool:
        """Return True if location ``a`` dominates location ``b`` in the CFG.

        Dominance means every execution path reaching ``b`` must first
        pass through ``a``.  Dominance is reflexive: a location
        dominates itself.
        """
        raise NotImplementedError

    def precedes(self, a: Location, b: Location) -> bool:
        """Return True if ``a`` precedes ``b`` on all execution paths.

        Stronger than dominance: ``a`` must execute *before* ``b`` on
        every path (not just be reachable before ``b``).
        """
        raise NotImplementedError

    def ordered(self, *locations: Location) -> bool:
        """Return True if locations appear in this order on all paths.

        Generalizes :meth:`precedes` to an arbitrary sequence of
        locations.

        Example::

            cfg.ordered(auth_check.location, guard.location, write.location)
        """
        raise NotImplementedError

    def reachable_between(self, a: Location, b: Location) -> bool:
        """Return True if there is any execution path from ``a`` to ``b``.

        Weaker than :meth:`precedes` -- only requires that *some* path
        exists, not that *all* paths go through both.
        """
        raise NotImplementedError
