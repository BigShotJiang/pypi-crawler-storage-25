"""Call site, argument, and function selector types.

A :class:`CallSite` represents a specific location where a function is
called with specific arguments.  This is distinct from
:class:`~flawed.function.Function` -- a ``Function`` is the
*definition*, while a ``CallSite`` is a particular *invocation* with
its actual arguments and return value handle.

The :class:`FnSelector` type and its :class:`Fn` sugar namespace
provide composable selectors for matching functions by name, FQN, or
pattern.  Selectors compose with ``|``::

    from flawed.calls import Fn

    selector = Fn.named("execute") | Fn.fqn("sqlalchemy.Session.add")
    calls = route.reachable.calls(selector)

    for call in calls:
        print(call.target, call.arguments)
        if call.return_value.flows_to(some_effect.target):
            print("Return value reaches the effect")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flawed.core import Location
    from flawed.flow import ValueHandle
    from flawed.function import Function


@dataclass(frozen=True)
class Argument:
    """A specific argument at a call site.

    Represents one positional or keyword argument passed at a
    particular call site.  The :attr:`value` property provides a
    :class:`~flawed.flow.ValueHandle` for tracking the argument
    value through the program.

    Example::

        call = route.reachable.calls(Fn.named("execute")).first()
        for arg in call.arguments:
            print(arg.index, arg.name, arg.expression)
            if arg.value.derived_from(Json()):
                print("Argument comes from JSON input!")
    """

    index: int
    """0-based positional index of the argument."""

    name: str | None
    """Keyword name if passed as a keyword argument, or ``None``."""

    expression: str
    """Source text of the argument expression."""

    location: Location
    """Source location of the argument expression."""

    @property
    def value(self) -> ValueHandle:
        """Handle for tracking this argument's value through the program."""
        raise NotImplementedError


@dataclass(frozen=True)
class CallSite:
    """A specific invocation of a function with specific arguments.

    Distinct from :class:`~flawed.function.Function` -- a function
    may be called from many sites, and each site carries its own
    arguments and return value.

    The :attr:`target` is ``None`` when the called function cannot be
    resolved (e.g. a call through a variable whose value is unknown).

    Example::

        for call in route.reachable.calls(Fn.named("execute")):
            print(call.target_expression)
            arg0 = call.argument(0)
            if arg0.value.derived_from(Json()):
                yield route.finding("SQL from JSON").evidence(call, "db call")
    """

    target: Function | None
    """The called function, or ``None`` if the target is unresolved."""

    target_expression: str
    """Source text of the call target (e.g. ``"db.execute"``)."""

    arguments: tuple[Argument, ...]
    """All arguments in call-site order."""

    location: Location
    """Source location of the call expression."""

    function: Function
    """The function containing this call site."""

    def argument(self, index: int) -> Argument:
        """Look up an argument by 0-based positional index.

        Raises ``IndexError`` if the index is out of range.
        """
        raise NotImplementedError

    def keyword_argument(self, name: str) -> Argument | None:
        """Look up an argument by keyword name.

        Returns ``None`` if no keyword argument with the given name
        exists at this call site.
        """
        raise NotImplementedError

    @property
    def return_value(self) -> ValueHandle:
        """Handle for tracking the call's return value.

        Use to check whether the return value flows to a particular
        effect or is used in a condition.
        """
        raise NotImplementedError


@dataclass(frozen=True)
class FnSelector:
    """Composable selector for filtering functions by name, FQN, or pattern.

    Single selectors match by one criterion (name, FQN, or regex).
    Composed selectors (via ``|``) match if *any* alternative matches.

    Construct via the :class:`Fn` sugar namespace rather than directly::

        selector = Fn.named("execute") | Fn.fqn("db.Session.add")
    """

    name_filter: str | None = None
    """Match functions with this exact short name."""

    fqn_filter: str | None = None
    """Match functions with this exact fully qualified name."""

    pattern_filter: str | None = None
    """Match functions whose name matches this regex pattern."""

    _alternatives: tuple[FnSelector, ...] = ()
    """Internal: composed alternatives from ``|`` operations."""

    def __or__(self, other: FnSelector) -> FnSelector:
        """Compose selectors: the result matches if either matches.

        Example::

            combined = Fn.named("execute") | Fn.named("run_query")
        """
        my = self._alternatives if self._alternatives else (self,)
        theirs = other._alternatives if other._alternatives else (other,)
        return FnSelector(_alternatives=(*my, *theirs))


class Fn:
    """Sugar namespace for constructing function selectors.

    Example::

        Fn.named("execute")                  # match by short name
        Fn.fqn("sqlalchemy.Session.add")     # match by FQN
        Fn.matching(r"^(get|fetch)_")        # match by regex
    """

    @staticmethod
    def named(name: str) -> FnSelector:
        """Select functions with the given short name.

        Args:
            name: Exact function name to match (e.g. ``"execute"``).
        """
        return FnSelector(name_filter=name)

    @staticmethod
    def fqn(fqn: str) -> FnSelector:
        """Select functions with the given fully qualified name.

        Args:
            fqn: Exact FQN to match (e.g. ``"hmac.compare_digest"``).
        """
        return FnSelector(fqn_filter=fqn)

    @staticmethod
    def matching(pattern: str) -> FnSelector:
        """Select functions matching the given regex pattern.

        Args:
            pattern: Regular expression matched against the function name.
        """
        return FnSelector(pattern_filter=pattern)
