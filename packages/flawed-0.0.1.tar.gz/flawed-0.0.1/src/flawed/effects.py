"""Effect observations, categories, selectors, and sugar namespaces.

An **effect** is a security-relevant side effect observed in code: a
database write, session mutation, outbound HTTP request, file write, or
notification.  The :class:`EffectCategory` enum defines the taxonomy,
and the :class:`EffectSelector` type provides composable filtering.

Three sugar namespaces make selectors readable:

- :class:`Mutation` -- data writes and deletes
- :class:`Session` -- session / context mutations
- :class:`Outbound` -- outbound HTTP requests

Selectors compose with ``|``::

    from flawed.effects import Mutation, Session, Outbound

    Mutation.any()                # DATA_WRITE or DATA_DELETE
    Mutation.write()              # DATA_WRITE only
    Session.write()               # SESSION_WRITE (any key)
    Session.write(key="email")    # SESSION_WRITE to specific key
    Outbound.request()            # OUTBOUND_REQUEST

    # Compose with |
    effects = route.reachable.effects(Mutation.any() | Session.write())

Categories:

===================  ==========================================
Category             Meaning
===================  ==========================================
``DATA_WRITE``       Database insert or update
``DATA_DELETE``      Database delete
``DATA_READ``        Database read (query-then-act pattern)
``SESSION_WRITE``    Server-side session mutation
``CONTEXT_WRITE``    Application context mutation (e.g. Flask g)
``OUTBOUND_REQUEST`` HTTP call to an external service
``FILE_WRITE``       Filesystem write
``NOTIFICATION``     Email, SMS, or push notification
===================  ==========================================
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flawed.core import InterpretationProvenance, Location
    from flawed.flow import ValueHandle
    from flawed.function import Function


class EffectCategory(Enum):
    """Taxonomy of security-relevant side effects.

    Each value represents a class of observable side effect that
    Layer 2 interpreters can identify.  Rule authors query for effects
    by category using :class:`EffectSelector` or the sugar namespaces.
    """

    DATA_WRITE = "data_write"
    """Database insert or update (e.g. ``db.execute("INSERT ...")``))."""

    DATA_DELETE = "data_delete"
    """Database delete (e.g. ``db.execute("DELETE ...")``))."""

    DATA_READ = "data_read"
    """Database read in a query-then-act pattern."""

    SESSION_WRITE = "session_write"
    """Server-side session mutation (e.g. ``session["user_id"] = ...``)."""

    CONTEXT_WRITE = "context_write"
    """Application context mutation (e.g. ``g.user = ...`` in Flask)."""

    OUTBOUND_REQUEST = "outbound_request"
    """HTTP call to an external service (e.g. ``requests.post(...)``)."""

    FILE_WRITE = "file_write"
    """Filesystem write (e.g. ``open("f", "w").write(...)``)."""

    NOTIFICATION = "notification"
    """Email, SMS, or push notification dispatch."""


@dataclass(frozen=True)
class EffectSelector:
    """Composable selector for filtering effects by category.

    Construct via the sugar namespaces (:class:`Mutation`,
    :class:`Session`, :class:`Outbound`) rather than directly.
    Combine selectors with ``|`` to match multiple categories::

        combined = Mutation.any() | Session.write()
        effects = route.reachable.effects(combined)
    """

    categories: frozenset[EffectCategory]
    """Set of categories this selector matches."""

    key_filter: str | None = None
    """Optional key filter for key-scoped effects (e.g. session key)."""

    def __or__(self, other: EffectSelector) -> EffectSelector:
        """Compose two selectors into a union selector.

        The resulting selector matches effects in *either* set of
        categories.  Key filters are dropped on composition.
        """
        return EffectSelector(
            categories=self.categories | other.categories,
            key_filter=None,
        )


@dataclass(frozen=True)
class Effect:
    """A security-relevant side effect observed in code.

    Produced by Layer 2 interpreters.  Not directly constructable by
    rule authors -- obtained from
    :meth:`~flawed.scopes.CodeScope.effects`.

    The :attr:`target` and :attr:`value` properties return
    :class:`~flawed.flow.ValueHandle` objects for tracking what
    is being written to and what value is being written.

    Example::

        for effect in route.reachable.effects(Mutation.write()):
            print(effect.category, effect.expression)
            if effect.target and read.value.flows_to(effect.target):
                print("User input reaches the write target!")
    """

    category: EffectCategory
    """The effect's category from the taxonomy."""

    function: Function
    """The function containing this effect."""

    location: Location
    """Source location of the effect expression."""

    expression: str
    """Source text of the effect expression."""

    provenance: InterpretationProvenance
    """Semantic Layer provenance for this observation."""

    @property
    def target(self) -> ValueHandle | None:
        """What is being written to (e.g. the table or session key).

        Returns ``None`` when the target cannot be determined.
        """
        raise NotImplementedError

    @property
    def value(self) -> ValueHandle | None:
        """What value is being written.

        Returns ``None`` when the written value cannot be determined.
        """
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Sugar namespaces
# ---------------------------------------------------------------------------


class Mutation:
    """Sugar namespace for data mutation effect selectors.

    Example::

        Mutation.any()     # DATA_WRITE or DATA_DELETE
        Mutation.write()   # DATA_WRITE only
        Mutation.delete()  # DATA_DELETE only
    """

    @staticmethod
    def any() -> EffectSelector:
        """Select any data mutation effect (write or delete)."""
        return EffectSelector(
            categories=frozenset({
                EffectCategory.DATA_WRITE,
                EffectCategory.DATA_DELETE,
            }),
        )

    @staticmethod
    def write() -> EffectSelector:
        """Select data write effects (``DATA_WRITE``)."""
        return EffectSelector(
            categories=frozenset({EffectCategory.DATA_WRITE}),
        )

    @staticmethod
    def delete() -> EffectSelector:
        """Select data delete effects (``DATA_DELETE``)."""
        return EffectSelector(
            categories=frozenset({EffectCategory.DATA_DELETE}),
        )


class Session:
    """Sugar namespace for session effect selectors.

    Example::

        Session.write()              # any session write
        Session.write(key="email")   # session write to specific key
        Session.read()               # session read
    """

    @staticmethod
    def write(key: str | None = None) -> EffectSelector:
        """Select session write effects, optionally filtered by key.

        Args:
            key: Session key name to filter on, or ``None`` for any.
        """
        return EffectSelector(
            categories=frozenset({EffectCategory.SESSION_WRITE}),
            key_filter=key,
        )

    @staticmethod
    def read(key: str | None = None) -> EffectSelector:
        """Select session read effects, optionally filtered by key.

        Args:
            key: Session key name to filter on, or ``None`` for any.
        """
        return EffectSelector(
            categories=frozenset({EffectCategory.DATA_READ}),
            key_filter=key,
        )


class Outbound:
    """Sugar namespace for outbound request effect selectors.

    Example::

        Outbound.request()  # any outbound HTTP request
    """

    @staticmethod
    def request() -> EffectSelector:
        """Select outbound HTTP request effects (``OUTBOUND_REQUEST``)."""
        return EffectSelector(
            categories=frozenset({EffectCategory.OUTBOUND_REQUEST}),
        )
