"""RepoView -- the top-level entry point for exploring an analyzed repository.

:class:`RepoView` is returned by :func:`~flawed.open_repo` and is the
single entry point for all navigation and detection.  It provides
access to the three main collections (routes, functions, classes) and
on-demand data-flow tracing.

Example::

    from flawed import open_repo

    kb = open_repo("/path/to/analysis-store/repos/slug/snapshot")
    kb.routes       # RouteCollection -- all identified HTTP endpoints
    kb.functions    # FunctionCollection -- every function in the repo
    kb.classes      # ClassCollection -- every class in the repo
    kb.trace_flow(source_loc, sink_loc)  # on-demand data-flow tracing
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flawed.collections import (
        FunctionCollection,
        RouteCollection,
    )
    from flawed.core import Location
    from flawed.flow import FlowTrace


class ClassCollection:
    """Collection of class domain objects.

    Provides access to all classes discovered in the analyzed
    repository.  Supports the same iteration and filtering interface
    as other domain collections.
    """


class RepoView:
    """Top-level navigation object returned by ``open_repo``.

    The single entry point for all Rule API queries.  Rule authors
    receive a ``RepoView`` as the argument to their detector function
    and use it to navigate routes, functions, and classes.

    Example::

        @detector("my-rule")
        def detect(kb: "RepoView") -> Iterator[Finding]:
            for route in kb.routes.where(accepting(POST)):
                ...
    """

    @property
    def routes(self) -> RouteCollection:
        """All HTTP routes identified in the repository.

        Returns a :class:`~flawed.collections.RouteCollection`
        that can be filtered with ``.where()``, ``.accepting()``,
        ``.in_blueprint()``, etc.
        """
        raise NotImplementedError

    @property
    def functions(self) -> FunctionCollection:
        """All functions discovered in the repository.

        Returns a :class:`~flawed.collections.FunctionCollection`
        that can be filtered with ``.named()``, ``.with_fqn()``,
        ``.in_file()``, ``.decorated_with()``, etc.
        """
        raise NotImplementedError

    @property
    def classes(self) -> ClassCollection:
        """All classes discovered in the repository."""
        raise NotImplementedError

    def trace_flow(self, source: Location, sink: Location) -> FlowTrace:
        """Trace data flow between two specific source locations.

        Returns a :class:`~flawed.flow.FlowTrace` with the full
        path of :class:`~flawed.flow.FlowStep` objects and a
        ``reachable`` flag.

        Args:
            source: The origin location.
            sink: The destination location.
        """
        raise NotImplementedError
