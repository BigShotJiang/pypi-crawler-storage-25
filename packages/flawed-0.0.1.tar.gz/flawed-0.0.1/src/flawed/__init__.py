"""Rift: static analysis engine for confusion vulnerability research.

Rule authors start here::

    from flawed import open_repo, detector
    from flawed.inputs import Query, Form, Json
    from flawed.effects import Mutation, Session
    from flawed.checks import Crypto, Token
    from flawed.route import Route, POST, accepting

The top-level package IS the Rule API. Deeper layers live in subpackages:

- ``flawed.semantic`` — Semantic Layer (framework interpretation)
- ``flawed.index`` — Code Index (structural extraction)
"""

from __future__ import annotations

from flawed.detector import detector
from flawed.repo import RepoView


def open_repo(path: str) -> RepoView:
    """Load an analyzed repository and return the top-level navigation object.

    Constructs a Code Index (Layer 1), runs the Semantic Layer
    interpreters (Layer 2), and returns a :class:`RepoView` -- the
    single entry point for all navigation and detection.

    Args:
        path: Path to the analysis store snapshot directory.

    Returns:
        A :class:`RepoView` for querying the analyzed repository.
    """
    raise NotImplementedError


__all__ = [
    "RepoView",
    "detector",
    "open_repo",
]
