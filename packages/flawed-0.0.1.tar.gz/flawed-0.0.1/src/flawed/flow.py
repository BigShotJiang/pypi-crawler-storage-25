"""Value flow tracking handles and trace results.

A :class:`ValueHandle` is **not** a plain value -- it is an opaque
handle that carries an engine reference for tracking how a value
propagates through the program.  Handles are available on:

- :attr:`~flawed.inputs.InputRead.value`
- :attr:`~flawed.effects.Effect.target` and ``.value``
- :attr:`~flawed.calls.CallSite.return_value`
- :attr:`~flawed.calls.Argument.value`
- :attr:`~flawed.conditions.Condition.left` and ``.right``

Flow queries have two scopes:

1. **Intra-function** (pre-computed) -- flows within a single function
   body are resolved statically during analysis and are always
   available.
2. **Interprocedural** (structural) -- flows across function boundaries
   use the call graph and are available when the engine has computed
   interprocedural data flow.

Example::

    read = route.reachable.reads(Json()).first()
    effect = route.reachable.effects(Mutation.write()).first()

    read.value.flows_to(effect.target)       # does the read reach the effect?
    effect.target.derived_from(PathParam())   # traced back to URL path?

:class:`FlowTrace` and :class:`FlowStep` provide detailed path
information when tracing flow between two specific points via
:meth:`~flawed.repo.RepoView.trace_flow`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flawed.core import Location
    from flawed.inputs import InputSource


@dataclass(frozen=True)
class ValueHandle:
    """Opaque handle for tracking value flow through the program.

    Not a plain value -- carries an engine reference that enables
    flow queries.  Obtained from domain objects, never constructed
    directly by rule authors.

    The three flow query methods answer different questions:

    - :meth:`flows_to` -- forward: does this value reach the target?
    - :meth:`flows_from` -- backward: does this value come from the source?
    - :meth:`derived_from` -- provenance: is this value derived from a
      specific input source type?
    """

    location: Location
    """Source location where this value was observed."""

    expression: str
    """Source text of the expression producing this value."""

    def flows_to(self, target: ValueHandle) -> bool:
        """Return True if this value flows to the target.

        Checks whether there is a data-flow path from this handle to
        the target handle, combining intra-function and interprocedural
        analysis.

        Example::

            if read.value.flows_to(effect.target):
                print("User input reaches the write target")
        """
        raise NotImplementedError

    def flows_from(self, source: ValueHandle) -> bool:
        """Return True if this value flows from the source.

        The reverse of :meth:`flows_to`: ``a.flows_from(b)`` is
        equivalent to ``b.flows_to(a)``.
        """
        raise NotImplementedError

    def derived_from(self, source: InputSource) -> bool:
        """Return True if this value is derived from the given input source.

        Traces backwards from this handle to determine whether any
        input read matching the given source type contributes to this
        value.

        Example::

            if effect.target.derived_from(PathParam()):
                print("Write target comes from URL path parameter")
        """
        raise NotImplementedError


@dataclass(frozen=True)
class FlowStep:
    """A single step in a traced flow path.

    Represents one node in the chain of assignments, calls, and
    transformations that connect a source to a sink.
    """

    location: Location
    """Source location of this step."""

    expression: str
    """Source text at this step."""

    description: str
    """Human-readable description of what happens at this step."""


@dataclass(frozen=True)
class FlowTrace:
    """The result of tracing data flow between two specific points.

    Returned by :meth:`~flawed.repo.RepoView.trace_flow`.
    Contains the full path of :class:`FlowStep` objects and a
    :attr:`reachable` flag indicating whether the flow is connected.

    Example::

        trace = kb.trace_flow(source_loc, sink_loc)
        if trace.reachable:
            for step in trace.steps:
                print(f"  {step.location.line}: {step.expression} -- {step.description}")
    """

    source: ValueHandle
    """The source (origin) of the traced flow."""

    sink: ValueHandle
    """The sink (destination) of the traced flow."""

    steps: tuple[FlowStep, ...]
    """Ordered sequence of flow steps from source to sink."""

    reachable: bool
    """Whether a data-flow path exists from source to sink."""
