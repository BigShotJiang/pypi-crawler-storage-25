"""Input source hierarchy, InputRead observation, and access enums.

This module defines **where** HTTP request data comes from and **how**
code accesses it.  The :class:`InputSource` hierarchy models request
containers (query string, form body, JSON body, headers, cookies, etc.)
and the :class:`InputRead` type records an observation that code reads
from one of these containers.

When an :class:`InputSource` subclass is constructed **without** its
identifying field (no ``key``, ``name``, or ``path``), it matches *any*
read from that container type.  This is the wildcard form used for
broad queries::

    from flawed.inputs import Json, Form, PathParam

    all_json_reads = route.reachable.reads(Json())        # any JSON field
    specific_read  = route.reachable.reads(Json(path="$.user_id"))  # one field

The :class:`AnyOf` combinator matches reads from any of several
sources::

    from flawed.inputs import AnyOf, Form, Json

    body_reads = route.reachable.reads(AnyOf(sources=(Form(), Json())))
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flawed.core import (
        InterpretationProvenance,
        JsonPath,
        Key,
        Location,
    )
    from flawed.flow import ValueHandle
    from flawed.function import Function


class AccessPattern(Enum):
    """How an input source was accessed in code.

    Determined by the Semantic Layer from the syntactic form of the
    read expression.

    Values:

    - ``GET`` -- dict-style ``.get("key")`` access
    - ``SUBSCRIPT`` -- bracket ``["key"]`` access
    - ``GETLIST`` -- ``.getlist("key")`` for multi-value fields
    - ``ATTRIBUTE`` -- attribute access (e.g. ``request.json``)
    - ``ITERATION`` -- iteration over the container
    - ``UNKNOWN`` -- access pattern could not be determined
    """

    GET = "get"
    SUBSCRIPT = "subscript"
    GETLIST = "getlist"
    ATTRIBUTE = "attribute"
    ITERATION = "iteration"
    UNKNOWN = "unknown"


class Cardinality(Enum):
    """Whether an input read produces a single value or multiple.

    Values:

    - ``SINGLE`` -- one value (e.g. ``request.args.get("id")``)
    - ``MULTI`` -- multiple values (e.g. ``request.args.getlist("ids")``)
    - ``UNKNOWN`` -- cardinality could not be determined
    """

    SINGLE = "single"
    MULTI = "multi"
    UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# InputSource hierarchy
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InputSource:
    """Base class for all HTTP request input sources.

    All subclasses are frozen dataclasses.  Construct without the
    identifying field to create a wildcard that matches any read from
    that container type.
    """


@dataclass(frozen=True)
class Query(InputSource):
    """Query string parameter source.

    Example::

        Query(key=Key("user_id"))  # specific parameter
        Query()                    # any query parameter (wildcard)
    """

    key: Key
    """Parameter name in the query string."""


@dataclass(frozen=True)
class Form(InputSource):
    """Form-encoded body field source.

    Example::

        Form(key=Key("amount"))   # specific field
        Form()                    # any form field (wildcard)
    """

    key: Key
    """Field name in the form-encoded body."""


@dataclass(frozen=True)
class Json(InputSource):
    """JSON body field source addressed by JSONPath.

    Example::

        Json(path=JsonPath("$.restaurant_id"))  # specific path
        Json()                                  # any JSON read (wildcard)
    """

    path: JsonPath
    """JSONPath expression identifying the field (e.g. ``"$.user.email"``)."""


@dataclass(frozen=True)
class Header(InputSource):
    """HTTP header source.

    Example::

        Header(name=Key("X-Api-Key"))  # specific header
        Header()                       # any header (wildcard)
    """

    name: Key
    """Header name (case-insensitive by HTTP convention)."""


@dataclass(frozen=True)
class Cookie(InputSource):
    """Cookie value source.

    Example::

        Cookie(name=Key("session"))  # specific cookie
        Cookie()                     # any cookie (wildcard)
    """

    name: Key
    """Cookie name."""


@dataclass(frozen=True)
class PathParam(InputSource):
    """URL path parameter source.

    Matches path parameters extracted from URL rules like
    ``/users/<int:id>``.

    Example::

        PathParam(name=Key("id"))  # specific parameter
        PathParam()                # any path parameter (wildcard)
    """

    name: Key
    """Path parameter name as declared in the URL rule."""


@dataclass(frozen=True)
class SessionKey(InputSource):
    """Server-side session value source.

    Reads from the server-side session store (e.g. ``session["user_id"]``
    in Flask).

    Example::

        SessionKey(key=Key("user_id"))  # specific key
        SessionKey()                    # any session read (wildcard)
    """

    key: Key
    """Session key name."""


@dataclass(frozen=True)
class FileUpload(InputSource):
    """Uploaded file source.

    Example::

        FileUpload(field=Key("avatar"))  # specific file field
        FileUpload()                     # any file upload (wildcard)
    """

    field: Key
    """Form field name for the uploaded file."""


@dataclass(frozen=True)
class RawBody(InputSource):
    """Raw request body source.

    Matches reads of the entire request body as bytes or text
    (e.g. ``request.data``, ``request.get_data()``).
    """


@dataclass(frozen=True)
class AnyContainer(InputSource):
    """Matches any request container with the given key name.

    Use when the key name matters but the container type does not::

        AnyContainer(key=Key("id"))  # "id" from query, form, JSON, etc.
    """

    key: Key
    """Key name to match across all container types."""


@dataclass(frozen=True)
class AnyOf(InputSource):
    """Union of input sources -- matches any read from the given sources.

    Example::

        body_reads = route.reachable.reads(AnyOf(sources=(Form(), Json())))
    """

    sources: tuple[InputSource, ...]
    """Input sources to match (any match counts)."""


# ---------------------------------------------------------------------------
# InputRead observation
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InputRead:
    """Observation that code reads from an HTTP request container.

    Produced by Layer 2 (Semantic Layer) when it recognizes a pattern
    like ``request.args.get("id")``.  Not directly constructable by
    rule authors -- obtained from
    :meth:`~flawed.scopes.CodeScope.reads`.

    The :attr:`value` property returns a :class:`~flawed.flow.ValueHandle`
    for tracking how the read value propagates through the program.

    Example::

        for read in route.reachable.reads(Json()):
            print(read.source, read.access_pattern)
            if read.value.flows_to(effect.target):
                print("Input reaches the effect!")
    """

    source: InputSource
    """The typed input source (``Query``, ``Form``, ``Json``, etc.)."""

    access_pattern: AccessPattern
    """How the source was accessed (``GET``, ``SUBSCRIPT``, etc.)."""

    cardinality: Cardinality
    """Whether the read produces a single value or multiple."""

    function: Function
    """The function containing this read."""

    location: Location
    """Source location of the read expression."""

    expression: str
    """Source text of the read expression."""

    provenance: InterpretationProvenance
    """Semantic Layer provenance for this observation."""

    @property
    def value(self) -> ValueHandle:
        """Handle for tracking the read value through the program.

        Returns a :class:`~flawed.flow.ValueHandle` that can be
        used with ``flows_to``, ``flows_from``, and ``derived_from``
        to trace how the input data propagates.
        """
        raise NotImplementedError
