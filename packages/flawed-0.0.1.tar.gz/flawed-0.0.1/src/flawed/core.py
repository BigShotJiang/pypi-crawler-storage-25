"""Foundational types shared across the Rule API domain model.

Every domain object carries a :class:`Location` for source-mapping and a
provenance record (:class:`Provenance` or :class:`InterpretationProvenance`)
that documents which analysis layer produced the fact.

Type aliases :data:`Key` and :data:`JsonPath` give semantic meaning to
plain strings used as parameter names, header names, or JSONPath
expressions.

Example::

    from flawed.core import Location, Provenance

    loc = Location(file="app.py", line=42, column=0)
    prov = Provenance(source_layer="L1", interpreter="ast", confidence=1.0)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import NewType

Key = NewType("Key", str)
"""Typed key for request parameter names, header names, cookie names, etc.

Used wherever a domain object identifies a named value in an HTTP request
container (e.g. ``Query(key=Key("user_id"))``).  The ``NewType`` wrapper
lets mypy distinguish ``Key`` from arbitrary strings while remaining a
plain ``str`` at runtime.
"""

JsonPath = NewType("JsonPath", str)
"""JSONPath expression for addressing JSON body fields.

Follows the JSONPath draft syntax (``$.field``, ``$.nested.field``).
Used by :class:`~flawed.inputs.Json` to specify which part of a
JSON request body is being read.
"""


@dataclass(frozen=True)
class Location:
    """A specific position in source code.

    Coordinates use a **1-based line, 0-based column** system consistent
    with LSP and most editor integrations.  ``end_line`` / ``end_column``
    are ``None`` when only the start position is known (e.g. for a
    function-level location derived from the ``def`` keyword).

    Example::

        loc = Location(file="app.py", line=10, column=4, end_line=10, end_column=28)
    """

    file: str
    """Relative path to the source file within the analysis store."""

    line: int
    """1-based start line number."""

    column: int
    """0-based start column offset."""

    end_line: int | None = None
    """1-based end line number, or ``None`` if unknown."""

    end_column: int | None = None
    """0-based end column offset, or ``None`` if unknown."""


@dataclass(frozen=True)
class Provenance:
    """Records which analysis layer produced a fact and why.

    Attached to domain objects that originate from Layer 1 (Code Index)
    where a single pass produces the fact directly (e.g. function
    discovery, decorator extraction).

    Example::

        prov = Provenance(source_layer="L1", interpreter="ast", confidence=1.0)
    """

    source_layer: str
    """Layer identifier that produced this fact (``"L1"``, ``"L2"``)."""

    interpreter: str
    """Name of the specific interpreter or pass (``"ast"``, ``"flask_routes"``)."""

    confidence: float
    """Confidence score in ``[0.0, 1.0]``."""


@dataclass(frozen=True)
class InterpretationProvenance:
    """Extended provenance for facts produced by Layer 2 (Semantic Layer).

    Semantic Layer interpreters combine multiple Layer 1 facts to
    produce higher-level interpretations.  The ``supporting_facts``
    tuple records which lower-level facts contributed to the conclusion.

    Use this instead of :class:`Provenance` when the fact is an
    *interpretation* (routes, input reads, effects) rather than a
    direct syntactic extraction.

    Example::

        prov = InterpretationProvenance(
            source_layer="L2",
            interpreter="flask_routes",
            confidence=0.95,
            supporting_facts=("decorator @app.route found", "handler has request.json read"),
        )
    """

    source_layer: str
    """Layer identifier (typically ``"L2"``)."""

    interpreter: str
    """Semantic Layer interpreter name (``"flask_routes"``, ``"sqlalchemy_effects"``)."""

    confidence: float
    """Confidence score in ``[0.0, 1.0]``."""

    supporting_facts: tuple[str, ...]
    """Human-readable descriptions of the lower-level facts that support this interpretation."""
