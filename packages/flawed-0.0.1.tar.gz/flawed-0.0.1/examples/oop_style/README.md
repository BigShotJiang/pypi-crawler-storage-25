# OOP Rule Style — Thought Exercise

Exploration of what a class-based detection rule system could look like,
using the same `flawed` types the functional `@detector` API
uses.  This is NOT the production API.  It stress-tests API
expressiveness and explores where OOP helps, where it hurts, and what
it reveals about the underlying domain model.

## Files

| File | Contents |
|------|----------|
| `base.py` | Abstract base classes (`Rule`, `RouteRule`, `InputEffectRule`, `CrossLayerRule`) and composable mixins for route selection, input selection, effect selection, and guard strategies |
| `rules.py` | Five concrete rules of increasing complexity, each covering real UCL vulnerability patterns |
| `showcase.py` | Same rule written three ways (functional, OOP, hybrid) plus one-line mixin variants |

## What the OOP approach gives you

**Shared structure without copy-paste.**  The
`InputEffectRule` base class encodes the universal confusion-rule
algorithm (iterate routes → collect inputs → collect effects → find
guards → check dominance → yield findings).  Twenty-two of 28 UCL
vulnerabilities follow this exact pattern.  Writing a new variant
means composing mixins and overriding `describe`.

**One-line rule variants.**  Once mixins exist, spinning up related
rules is trivial:

```python
class PathGuardBodyWrite(PostOnly, PathInputs, WriteMutations, FlowAwareGuard, InputEffectRule):
    name = "path-guard-body-write"
    def describe(self, ...): return "Path ID in guard, write target from body"

class QueryGuardBodyWrite(PostOnly, QueryInputs, WriteMutations, FlowAwareGuard, InputEffectRule):
    name = "query-guard-body-write"
    def describe(self, ...): return "Query param guards write, body supplies target"
```

Each of these is a complete, working rule.  The only difference is
which mixin supplies `interesting_inputs`.

**Named override points.**  When a rule needs custom behaviour, the
override is surgical: replace `is_protected` for a different guard
strategy, replace `scope_for` to examine `full_stack` instead of
`reachable`, replace `applicable_routes` to restrict by blueprint.
Every other part of the algorithm stays inherited.

**Composable guard strategies.**  `FlowAwareGuard` vs
`FullStackGuard` vs the default dominance-only check are swappable
traits.  A rule author picks the appropriate one by adding a mixin.

## What it costs

**MRO complexity.**  `PathGuardBodyWrite` has eight classes in its
MRO.  Understanding what happens when you call `.detect()` requires
tracing through `Rule → RouteRule → InputEffectRule → FlowAwareGuard
→ WriteMutations → PathInputs → PostOnly`.  The functional version
puts the entire algorithm in one function.

**Mixin ordering matters.**  `PostOnly` must precede
`InputEffectRule` in the inheritance list for `super().applicable_routes`
to chain correctly.  Getting this wrong produces silent bugs (the
filter doesn't apply, all routes are visited).

**Debugging indirection.**  When a rule misfires, the rule author
must open `base.py` and trace through `examine_route` to understand
why.  With the functional style, the complete algorithm is inline.

**New concepts to learn.**  Rule authors must understand: Rule,
RouteRule, InputEffectRule, the mixin protocols, MRO chaining
semantics.  The functional API requires understanding only Python
generators and the domain types.

## When each style is better

| Style | Best for |
|-------|----------|
| **Functional** | One-off rules, prototyping, rules with unusual structure, rules that don't fit the standard loop |
| **OOP** | Rule libraries with dozens of variants sharing the same structure, teams with shared conventions |
| **Hybrid** | Rules where the structure is standard but the decisions are project-specific and need isolated testing |

## What this reveals about the API

The exercise confirms several things about the underlying type system:

1. **The types compose cleanly in both settings.**  `CodeScope.reads()`,
   `.effects()`, `.conditions_using()` and `ControlFlowView.dominates()`
   work identically whether called from a generator function or a class
   method.  No special adaptation was needed.

2. **`InputEffectRule` encodes a real structural pattern.**  The
   input → guard → effect → dominance check loop is not artificial;
   22/28 UCL vulnerabilities follow it.  This validates the domain
   model's shape: inputs, effects, conditions, and CFG dominance are
   the right primitives.

3. **Rules that DON'T fit need full flexibility.**  Cross-route
   comparison (rule 4), structural audits (rule 5), and method-gated
   auth (rule 2) cannot be expressed with `InputEffectRule`.  They
   drop down to `RouteRule` or `Rule` and use the primitives directly.
   The OOP hierarchy helps only for the common case; the uncommon
   cases fall through to the same functional primitives anyway.

4. **The Gate type was correctly eliminated.**  None of these rules
   need a `Gate` object.  They need conditions (`conditions_using`)
   and decorators (`route.handler.decorators`).  The structural
   primitives are more composable than a semantic `Gate` classification
   would have been.

5. **`route.full_stack` earns its place.**  Rules 2, 3, and the
   `FullStackGuard` mixin need it.  Without it, cross-layer analysis
   would require manual lifecycle stitching in every rule.

## Recommendation

**The functional `@detector` style is the production primary API.**
OOP is an advanced pattern for rule library authors who maintain
dozens of related rules.  Both styles are fully supported by the
same type system.  Nothing forces the choice — a project can mix
functional and OOP rules freely.

The OOP layer could ship as an optional `flawed.patterns`
module: useful scaffolding for power users, invisible to newcomers.
