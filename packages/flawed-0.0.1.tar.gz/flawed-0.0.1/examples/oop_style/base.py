"""Abstract base classes and composable mixins for OOP-style detection rules.

This module defines a class hierarchy that encodes the common execution
patterns observed across 28 confusion vulnerabilities (r01-r05).  The
hierarchy lets rule authors express a new detector by composing traits
(mixins) instead of writing the iteration/matching loop from scratch.

Every class uses the exact same ``flawed`` domain types that
the functional ``@detector`` API uses.  Nothing here is a separate type
system -- it is organisational scaffolding over the same primitives.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator

    from flawed.repo import RepoView
    from flawed.conditions import Condition
    from flawed.effects import Effect, EffectSelector
    from flawed.evidence import Finding
    from flawed.inputs import InputRead, InputSource
    from flawed.route import HttpMethod, Route
    from flawed.scopes import CodeScope


# ---------------------------------------------------------------------------
# Core rule hierarchy
# ---------------------------------------------------------------------------


class Rule(ABC):
    """Absolute base for every detection rule.

    A ``Rule`` knows its name and can be invoked against a repository.
    All concrete rules eventually implement ``detect``.
    """

    name: str

    @abstractmethod
    def detect(self, kb: RepoView) -> Iterator[Finding]: ...


class RouteRule(Rule):
    """A rule that examines one route at a time.

    Subclasses override ``applicable_routes`` to narrow which routes are
    visited, and implement ``examine_route`` to produce findings.  The
    outer iteration loop is provided for free.
    """

    def applicable_routes(self, kb: RepoView) -> Iterable[Route]:
        """Routes this rule should inspect.  Override to filter."""
        return kb.routes

    @abstractmethod
    def examine_route(self, route: Route, kb: RepoView) -> Iterator[Finding]: ...

    def detect(self, kb: RepoView) -> Iterator[Finding]:
        for route in self.applicable_routes(kb):
            yield from self.examine_route(route, kb)


class InputEffectRule(RouteRule):
    """The most common confusion-vulnerability rule shape.

    The algorithm encoded here:

    1. For each route, collect *interesting inputs* and *interesting
       effects*.
    2. For each (input, effect) pair, look for *guards* -- conditions
       that use the input's value.
    3. If no guard exists, or the guard does not dominate the effect in
       the CFG, yield a finding.

    Subclasses provide the concrete definitions of "interesting input",
    "interesting effect", guard lookup strategy, and finding description.
    Everything else is inherited.
    """

    @abstractmethod
    def interesting_inputs(self, scope: CodeScope) -> Iterable[InputRead]: ...

    @abstractmethod
    def interesting_effects(self, scope: CodeScope) -> Iterable[Effect]: ...

    def scope_for(self, route: Route) -> CodeScope:
        """The code scope to search.  Default: transitively reachable."""
        return route.reachable

    def guards_for(
        self,
        route: Route,
        scope: CodeScope,
        read: InputRead,
    ) -> Iterable[Condition]:
        """Conditions that guard the given input value."""
        return scope.conditions_using(read.value)

    def is_protected(
        self,
        route: Route,
        guard: Condition,
        effect: Effect,
    ) -> bool:
        """True when *guard* adequately protects *effect*.

        Default: the guard must dominate the effect in the handler CFG.
        Override for richer flow-aware or value-aware checks.
        """
        return route.body.cfg.dominates(guard.location, effect.location)

    @abstractmethod
    def describe(
        self,
        route: Route,
        read: InputRead,
        effect: Effect,
        guard: Condition | None,
    ) -> str:
        """One-line finding summary.  *guard* is ``None`` when no guard
        was found at all."""
        ...

    # ------------------------------------------------------------------

    def examine_route(self, route: Route, kb: RepoView) -> Iterator[Finding]:
        scope = self.scope_for(route)

        for read in self.interesting_inputs(scope):
            for effect in self.interesting_effects(scope):
                guards = list(self.guards_for(route, scope, read))

                if not guards:
                    yield (
                        route.finding(self.describe(route, read, effect, None))
                        .evidence(read, "Unguarded input")
                        .evidence(effect, "Unguarded effect")
                    )
                    continue

                for guard in guards:
                    if not self.is_protected(route, guard, effect):
                        yield (
                            route.finding(self.describe(route, read, effect, guard))
                            .evidence(read, "Input")
                            .evidence(guard, "Insufficient guard")
                            .evidence(effect, "Effect")
                        )


class CrossLayerRule(RouteRule):
    """A rule that examines the full request-handling stack.

    Like ``InputEffectRule`` but searches ``route.full_stack`` instead of
    ``route.reachable``, covering ``before_request`` hooks, decorator
    wrappers, and middleware in addition to the handler body.

    Useful for r01-v104, r02-v201/v204, r03-v302/v304 patterns where the
    disagreement is between middleware and the handler.
    """

    def scope_for(self, route: Route) -> CodeScope:
        return route.full_stack


# ---------------------------------------------------------------------------
# Route-selection mixins
# ---------------------------------------------------------------------------


class PostOnly:
    """Mixin: only visit routes that accept POST."""

    def applicable_routes(self, kb: RepoView) -> Iterable[Route]:
        from flawed.route import POST

        return kb.routes.where(lambda r: POST in r.methods)


class MutatingOnly:
    """Mixin: only visit routes whose reachable code contains mutations."""

    def applicable_routes(self, kb: RepoView) -> Iterable[Route]:
        from flawed.effects import Mutation

        parent: Iterable[Route] = super().applicable_routes(kb)  # type: ignore[misc]
        return (r for r in parent if r.reachable.effects(Mutation.any()))


class WriteOnly:
    """Mixin: only visit routes whose reachable code contains data writes."""

    def applicable_routes(self, kb: RepoView) -> Iterable[Route]:
        from flawed.effects import Mutation

        parent: Iterable[Route] = super().applicable_routes(kb)  # type: ignore[misc]
        return (r for r in parent if r.reachable.effects(Mutation.write()))


# ---------------------------------------------------------------------------
# Input-selection mixins
# ---------------------------------------------------------------------------


class PathInputs:
    """Mixin: interesting inputs are URL path parameters."""

    def interesting_inputs(self, scope: CodeScope) -> Iterable[InputRead]:
        from flawed.inputs import PathParam

        return scope.reads(PathParam())


class BodyInputs:
    """Mixin: interesting inputs are form-encoded or JSON body fields."""

    def interesting_inputs(self, scope: CodeScope) -> Iterable[InputRead]:
        from flawed.inputs import AnyOf, Form, Json

        return scope.reads(AnyOf(sources=(Form(), Json())))


class QueryInputs:
    """Mixin: interesting inputs are query-string parameters."""

    def interesting_inputs(self, scope: CodeScope) -> Iterable[InputRead]:
        from flawed.inputs import Query

        return scope.reads(Query())


class SessionInputs:
    """Mixin: interesting inputs are server-side session values."""

    def interesting_inputs(self, scope: CodeScope) -> Iterable[InputRead]:
        from flawed.inputs import SessionKey

        return scope.reads(SessionKey())


class AllInputs:
    """Mixin: every input read is interesting."""

    def interesting_inputs(self, scope: CodeScope) -> Iterable[InputRead]:
        from flawed.inputs import InputSource

        return scope.reads(InputSource())


class SpecificInputs:
    """Mixin: interesting inputs are one or more explicit source types.

    Set the ``input_sources`` class variable to a tuple of ``InputSource``
    instances::

        class MyRule(SpecificInputs, WriteMutations, InputEffectRule):
            input_sources = (Header(name=Key.exact("X-Api-Key")),)
            ...
    """

    input_sources: tuple[InputSource, ...] = ()

    def interesting_inputs(self, scope: CodeScope) -> Iterable[InputRead]:
        from flawed.inputs import AnyOf

        if len(self.input_sources) == 1:
            return scope.reads(self.input_sources[0])
        return scope.reads(AnyOf(sources=self.input_sources))


# ---------------------------------------------------------------------------
# Effect-selection mixins
# ---------------------------------------------------------------------------


class WriteMutations:
    """Mixin: interesting effects are database writes."""

    def interesting_effects(self, scope: CodeScope) -> Iterable[Effect]:
        from flawed.effects import Mutation

        return scope.effects(Mutation.write())


class AnyMutations:
    """Mixin: interesting effects are all mutations including session."""

    def interesting_effects(self, scope: CodeScope) -> Iterable[Effect]:
        from flawed.effects import Mutation, Session

        return scope.effects(Mutation.any() | Session.write())


class SpecificEffects:
    """Mixin: interesting effects match a user-specified selector.

    Set the ``effect_selector`` class variable::

        class MyRule(PathInputs, SpecificEffects, InputEffectRule):
            effect_selector = Outbound.request()
            ...
    """

    effect_selector: EffectSelector

    def interesting_effects(self, scope: CodeScope) -> Iterable[Effect]:
        return scope.effects(self.effect_selector)


# ---------------------------------------------------------------------------
# Guard-strategy mixins
# ---------------------------------------------------------------------------


class FlowAwareGuard:
    """Mixin: a guard only protects if the *same* value that flows through
    the guard also flows to the effect's target.

    This catches the core confusion pattern: guard reads X, effect uses Y.
    Dominance alone (the default) only checks ordering, not value identity.
    """

    def is_protected(
        self,
        route: Route,
        guard: Condition,
        effect: Effect,
    ) -> bool:
        if not route.body.cfg.dominates(guard.location, effect.location):
            return False
        if effect.target is None:
            return False
        # The guard's left or right operand must flow to the effect target
        return (
            guard.left.flows_to(effect.target)
            or guard.right.flows_to(effect.target)
        )


class FullStackGuard:
    """Mixin: evaluate guard dominance in the full lifecycle stack rather
    than just the handler body.

    Necessary for cross-layer vulnerabilities where the guard is in
    middleware / ``before_request`` and the effect is in the handler.
    """

    def is_protected(
        self,
        route: Route,
        guard: Condition,
        effect: Effect,
    ) -> bool:
        return route.full_stack.cfg.dominates(guard.location, effect.location)
