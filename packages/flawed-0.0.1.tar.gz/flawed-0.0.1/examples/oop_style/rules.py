"""Concrete detection rules using the OOP class system.

Five rules of increasing complexity show how mixins compose and where
override points let you drop down to fully custom logic.

These are NOT executable -- the ``flawed`` types are
contract-only stubs.  The purpose is to prove that the functional API
types compose naturally in a class setting and to explore where the
abstraction helps, hurts, or breaks down.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from examples.oop_style.base import (
    AnyMutations,
    BodyInputs,
    CrossLayerRule,
    FlowAwareGuard,
    InputEffectRule,
    PathInputs,
    PostOnly,
    RouteRule,
    Rule,
    WriteMutations,
)

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator

    from flawed.repo import RepoView
    from flawed.conditions import Condition
    from flawed.effects import Effect
    from flawed.evidence import Finding
    from flawed.inputs import InputRead
    from flawed.route import Route


# ======================================================================
# Rule 1: Path Guard Body Write  (4-line mixin composition)
# ======================================================================
#
# UCL coverage: v103 (order_id injection), v106 (token email vs body
# email), v304 (query restaurant_id vs body restaurant_id).
#
# Pattern: route accepts path parameter, uses it in a guard, but the
# data write's target comes from the request body.  Guard checks the
# wrong derivation.
#
# This is the dream case for OOP composition -- the entire detection
# algorithm is inherited.  The subclass provides only the wiring
# (which inputs, which effects) and a human-readable description.


class PathGuardBodyWrite(
    PostOnly,           # only POST routes
    PathInputs,         # inputs: path parameters
    WriteMutations,     # effects: database writes
    FlowAwareGuard,     # guard must flow-connect to the write target
    InputEffectRule,     # the standard input→guard→effect loop
):
    """Path parameter guards a data write whose target comes from the body."""

    name = "path-guard-body-write"

    def describe(
        self,
        route: Route,
        read: InputRead,
        effect: Effect,
        guard: Condition | None,
    ) -> str:
        if guard is None:
            return "Path parameter read with unguarded data write"
        return "Path ID in guard, but write target does not flow from path"


# ======================================================================
# Rule 2: Method-Gated Auth  (custom examine_route)
# ======================================================================
#
# UCL coverage: v202 (admin check only runs for POST; GET with form
# body still triggers mutation branch).
#
# Pattern: an auth/admin check is inside a ``if request.method ==
# "POST":`` block, so GET requests carrying a form body reach the
# mutation path without the check.
#
# This does NOT fit the InputEffectRule template because the
# vulnerability is about a *missing* guard on one branch, not about
# input/effect disagreement.  A RouteRule with custom logic is the
# right level.


class MethodGatedAuth(PostOnly, RouteRule):
    """Auth condition is gated on HTTP method -- unguarded branch has mutations."""

    name = "method-gated-auth"

    def examine_route(self, route: Route, kb: RepoView) -> Iterator[Finding]:
        from flawed.effects import Mutation

        for cond in route.body.conditions():
            # We look for conditionals whose operator suggests a method
            # check (==, !=) and whose operands reference request.method.
            # The Semantic Layer will have flagged request.method reads,
            # so we heuristically check expression text.  A production
            # rule would use ``cond.left.derived_from(...)`` once method
            # reads are modeled as InputRead.
            if cond.operator not in ("==", "!="):
                continue

            true_mutations = cond.true_branch.effects(Mutation.any())
            false_mutations = cond.false_branch.effects(Mutation.any())

            # One branch has mutations, the other does not: the guard
            # only fires in one direction.
            if true_mutations and not false_mutations:
                yield (
                    route.finding("Mutations only in method-true branch")
                    .evidence(cond, "Method-conditional guard")
                )
            elif false_mutations and not true_mutations:
                yield (
                    route.finding("Mutations only in method-false branch")
                    .evidence(cond, "Method-conditional guard")
                )


# ======================================================================
# Rule 3: Stale Context After Failed Auth  (CrossLayerRule)
# ======================================================================
#
# UCL coverage: v201 (g.email set before password verified), v204
# (g.manager_request survives failed authenticator), v107 (second
# middleware overwrites first).
#
# Pattern: a ``before_request`` hook or decorator wrapper writes to
# application context (``g``, ``session``) *before* a subsequent auth
# check.  If that check fails (error branch), the written context
# value persists.
#
# Uses ``route.full_stack`` to see middleware + handler as one scope.


class StaleContextAfterFailedAuth(CrossLayerRule):
    """Context written before auth check survives when auth fails."""

    name = "stale-context-after-failed-auth"

    def examine_route(self, route: Route, kb: RepoView) -> Iterator[Finding]:
        from flawed.effects import Session

        stack = route.full_stack  # includes before_request, decorators

        # Context/session writes in the full lifecycle stack
        context_selector = Session.write()  # also covers g via CONTEXT_WRITE
        for ctx_write in stack.effects(context_selector):
            for cond in stack.conditions():
                if cond.error_branch is None:
                    continue
                # Context write precedes the condition (happens first)
                if stack.cfg.precedes(ctx_write.location, cond.location):
                    yield (
                        route.finding(
                            "Context write before auth check -- "
                            "value survives on auth failure"
                        )
                        .evidence(ctx_write, "Context/session write")
                        .evidence(cond, "Auth condition with error branch")
                    )


# ======================================================================
# Rule 4: Cross-Route Normalization  (repo-wide, extends Rule)
# ======================================================================
#
# UCL coverage: v502 (whitespace), v503 (unicode), v504 (NFKC vs
# raw), v508 (dot-to-hyphen).
#
# Pattern: two routes operate on the same logical entity (e.g.
# restaurant name), but apply different string transformations.
# One route creates/validates, the other reads/matches.
#
# This is fundamentally NOT a per-route rule -- it requires comparing
# two routes that share an entity.  It extends Rule directly.


class CrossRouteNormalization(Rule):
    """Two routes transform the same entity value differently."""

    name = "cross-route-normalization"

    def detect(self, kb: RepoView) -> Iterator[Finding]:
        from flawed.calls import Fn
        from flawed.effects import Mutation

        # Find all routes that write to persistent storage
        writers = [
            r for r in kb.routes
            if r.reachable.effects(Mutation.write())
        ]

        # Heuristic: look for pairs of routes whose handlers call
        # different string-processing functions on values derived from
        # the same logical input.  This is necessarily imprecise --
        # "same logical input" is application-specific.

        normalize_fns = Fn.matching(
            r"lower|upper|strip|slugify|normalize|replace|encode|decode"
        )

        for writer in writers:
            writer_calls = set(
                c.target_expression
                for c in writer.reachable.calls(normalize_fns)
            )
            if not writer_calls:
                continue

            # Compare against every other route with the same URL
            # prefix (sibling routes on the same resource)
            for other in kb.routes:
                if other.endpoint == writer.endpoint:
                    continue
                other_calls = set(
                    c.target_expression
                    for c in other.reachable.calls(normalize_fns)
                )
                if not other_calls:
                    continue

                # Different normalization functions used?
                if writer_calls != other_calls:
                    yield (
                        writer.finding(
                            f"Different normalization vs {other.endpoint}: "
                            f"{writer_calls} ≠ {other_calls}"
                        )
                    )


# ======================================================================
# Rule 5: Decorator-Route Parameter Mismatch  (structural audit)
# ======================================================================
#
# UCL coverage: v303 (decorator expects ``restaurant_id`` in
# view_args, but the route's URL rule doesn't have it -- decorator
# silently passes).
#
# Pattern: a decorator is written to read a path parameter by name.
# The route URL rule doesn't define that parameter.  The decorator
# receives None / KeyError / silently skips its check.
#
# This is a structural audit, not data-flow analysis.  It compares
# decorator argument strings against the URL rule's ``<param>``
# captures.


class DecoratorRouteParamMismatch(RouteRule):
    """Decorator expects a view_arg the URL rule doesn't define."""

    name = "decorator-route-param-mismatch"

    # Decorators whose second positional argument is a view_arg name.
    # In a real deployment this would be configurable.
    ownership_decorators: tuple[str, ...] = (
        "restaurant_owns",
        "verify_order_access",
        "require_resource_owner",
    )

    def examine_route(self, route: Route, kb: RepoView) -> Iterator[Finding]:
        import re

        # Extract <param_name> from the URL rule
        url_params = set(re.findall(r"<(?:\w+:)?(\w+)>", route.url_rule))

        for dec in route.handler.decorators:
            if dec.name not in self.ownership_decorators:
                continue

            # Convention: second argument is the expected view_arg name
            if len(dec.arguments) < 2:
                continue
            expected_param = dec.arguments[1].strip("\"'")

            if expected_param not in url_params:
                yield (
                    route.finding(
                        f"@{dec.name} expects '{expected_param}' but URL "
                        f"rule '{route.url_rule}' does not define it"
                    )
                    .evidence(dec, f"Decorator expects '{expected_param}'")
                )
