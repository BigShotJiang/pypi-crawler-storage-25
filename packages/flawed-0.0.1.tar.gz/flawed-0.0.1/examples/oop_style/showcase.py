"""Side-by-side: the same rule written in three styles.

Rule: "Path parameter used in guard, body parameter used for write
target, and the guard's value does not flow to the write target."

Coverage: UCL v103, v106, v304.

This file is NOT executable.  It demonstrates that the same
``flawed`` types compose naturally in functional, OOP, and
hybrid styles.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator

    from flawed.repo import RepoView
    from flawed.evidence import Finding
    from flawed.route import Route


# ======================================================================
# Style 1:  Functional  (@detector + generator)
# ======================================================================
#
# This is the production primary API.  The full algorithm is visible in
# one function.  No base classes, no mixins, no inheritance to trace.
#
# Strengths:
#   - Everything is right here.  No ctrl-clicking through a hierarchy.
#   - Easy to copy-paste-modify into a new rule.
#   - The control flow is exactly Python -- no inversion of control.
#
# Weaknesses:
#   - The route iteration + input iteration + effect iteration + guard
#     iteration + dominance check structure is repeated verbatim in
#     every rule that shares this pattern.
#   - Changing the guard strategy (e.g. flow-aware vs dominance-only)
#     means editing every rule that uses it.

def functional_style() -> None:
    from flawed import detector, open_repo
    from flawed.effects import Mutation
    from flawed.inputs import AnyOf, Form, Json, PathParam
    from flawed.route import POST, accepting

    @detector("path-guard-body-write")
    def detect(kb: RepoView) -> Iterator[Finding]:
        for route in kb.routes.where(accepting(POST)):
            for path_read in route.reachable.reads(PathParam()):
                for body_read in route.reachable.reads(AnyOf(sources=(Form(), Json()))):
                    for effect in route.reachable.effects(Mutation.write()):
                        if effect.target is None:
                            continue
                        if not body_read.value.flows_to(effect.target):
                            continue
                        for guard in route.reachable.conditions_using(path_read.value):
                            if route.body.cfg.dominates(guard.location, effect.location):
                                # Guard dominates, but check value flow
                                if not (
                                    guard.left.flows_to(effect.target)
                                    or guard.right.flows_to(effect.target)
                                ):
                                    yield (
                                        route.finding(
                                            "Path ID in guard, write target "
                                            "does not flow from path"
                                        )
                                        .evidence(path_read, "Path parameter")
                                        .evidence(body_read, "Body parameter")
                                        .evidence(guard, "Guard condition")
                                        .evidence(effect, "Data write")
                                    )


# ======================================================================
# Style 2:  Full OOP  (class + mixins)
# ======================================================================
#
# Strengths:
#   - The rule definition is 6 lines.  All the iteration, guarding,
#     and evidence assembly is inherited.
#   - Changing the guard strategy for a family of rules means swapping
#     one mixin (FlowAwareGuard vs FullStackGuard vs default).
#   - Adding a new rule variant (e.g. "QueryGuardBodyWrite") is
#     literally swapping one mixin class.
#   - Shared behaviour is defined once, tested once, trusted everywhere.
#
# Weaknesses:
#   - You must understand the class hierarchy to know what happens.
#     The MRO for this class is:
#       PathGuardBodyWrite → PostOnly → PathInputs → WriteMutations
#       → FlowAwareGuard → InputEffectRule → RouteRule → Rule
#     That is a LOT of implicit behaviour.
#   - Debugging a misfiring rule means tracing through 4+ files.
#   - Mixin ordering matters (PostOnly must precede InputEffectRule
#     so ``super().applicable_routes`` chains correctly).

def oop_style() -> None:
    from examples.oop_style.base import (
        FlowAwareGuard,
        InputEffectRule,
        PathInputs,
        PostOnly,
        WriteMutations,
    )

    class PathGuardBodyWrite(
        PostOnly,
        PathInputs,
        WriteMutations,
        FlowAwareGuard,
        InputEffectRule,
    ):
        name = "path-guard-body-write"

        def describe(
            self,
            route: Route,
            read: "InputRead",  # noqa: F821 — type-checking import above
            effect: "Effect",   # noqa: F821
            guard: "Condition | None",  # noqa: F821
        ) -> str:
            if guard is None:
                return "Path parameter read with unguarded data write"
            return "Path ID in guard, write target does not flow from path"

    # That's it.  Six lines of rule-specific code.


# ======================================================================
# Style 3:  Hybrid  (class provides structure, key logic is plain code)
# ======================================================================
#
# A middle ground: the class encodes the *structure* (what to iterate,
# in what order) but delegates the interesting decisions to standalone
# functions that are easy to read, test, and reuse independently.
#
# Strengths:
#   - Structure is shared (no copy-paste loop), but each decision
#     point is a visible, named function.
#   - The functions can be tested in isolation.
#   - Easier to trace than deep mixin chains: the class body is the
#     wiring diagram, the functions are the components.
#
# Weaknesses:
#   - More verbose than pure OOP (you write the functions + the
#     wiring).
#   - Still requires understanding the base class API to know which
#     methods to override.

def hybrid_style() -> None:
    from examples.oop_style.base import InputEffectRule
    from flawed.effects import Mutation
    from flawed.inputs import (
        AnyOf,
        Form,
        InputRead,
        Json,
        PathParam,
    )
    from flawed.route import POST, Route, accepting

    # --- standalone functions, each testable in isolation ---

    def post_routes(kb: "RepoView") -> "Iterator[Route]":
        return iter(kb.routes.where(accepting(POST)))

    def path_reads(scope: "CodeScope") -> "Iterator[InputRead]":  # noqa: F821
        return iter(scope.reads(PathParam()))

    def body_writes(scope: "CodeScope") -> "Iterator[Effect]":  # noqa: F821
        return iter(scope.effects(Mutation.write()))

    def guard_flows_to_target(
        route: Route,
        guard: "Condition",  # noqa: F821
        effect: "Effect",    # noqa: F821
    ) -> bool:
        if not route.body.cfg.dominates(guard.location, effect.location):
            return False
        if effect.target is None:
            return False
        return (
            guard.left.flows_to(effect.target)
            or guard.right.flows_to(effect.target)
        )

    # --- class wires the functions together ---

    class PathGuardBodyWrite(InputEffectRule):
        name = "path-guard-body-write"

        def applicable_routes(self, kb: "RepoView") -> "Iterator[Route]":
            return post_routes(kb)

        def interesting_inputs(self, scope: "CodeScope") -> "Iterator[InputRead]":  # noqa: F821
            return path_reads(scope)

        def interesting_effects(self, scope: "CodeScope") -> "Iterator[Effect]":  # noqa: F821
            return body_writes(scope)

        def is_protected(self, route: Route, guard: "Condition", effect: "Effect") -> bool:  # noqa: F821
            return guard_flows_to_target(route, guard, effect)

        def describe(self, route: Route, read: InputRead, effect: "Effect", guard: "Condition | None") -> str:  # noqa: F821
            if guard is None:
                return "Path parameter read with unguarded data write"
            return "Path ID in guard, write target does not flow from path"


# ======================================================================
# Variant showcase: how one-line mixin swaps create rule families
# ======================================================================
#
# Once the base mixins exist, spinning up related rules is trivial.
# Each line below is a complete, distinct rule.

def mixin_variants() -> None:
    from examples.oop_style.base import (
        AnyMutations,
        BodyInputs,
        FlowAwareGuard,
        InputEffectRule,
        PostOnly,
        QueryInputs,
        SessionInputs,
        WriteMutations,
    )

    class QueryGuardBodyWrite(PostOnly, QueryInputs, WriteMutations, FlowAwareGuard, InputEffectRule):
        name = "query-guard-body-write"
        def describe(self, route: Route, read: "InputRead", effect: "Effect", guard: "Condition | None") -> str:  # noqa: F821
            return "Query param guards write, body supplies target"

    class PathGuardAnyMutation(PostOnly, BodyInputs, AnyMutations, FlowAwareGuard, InputEffectRule):
        name = "path-guard-any-mutation"
        def describe(self, route: Route, read: "InputRead", effect: "Effect", guard: "Condition | None") -> str:  # noqa: F821
            return "Body input flows to mutation target without path-derived guard"

    class SessionGuardWrite(PostOnly, SessionInputs, WriteMutations, FlowAwareGuard, InputEffectRule):
        name = "session-guard-write"
        def describe(self, route: Route, read: "InputRead", effect: "Effect", guard: "Condition | None") -> str:  # noqa: F821
            return "Session value guards write, but guard value doesn't reach target"
