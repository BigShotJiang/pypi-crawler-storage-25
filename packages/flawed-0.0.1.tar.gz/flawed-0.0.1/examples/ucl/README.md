# UCL Examples -- Unsafe Code Lab

Detection rules targeting synthetic vulnerable Flask applications from
~/Projects/unsafe-code/vulnerabilities/python/flask/confusion/webapp/

| Rule | Targets | Status |
|------|---------|--------|
| (none yet) | | |
