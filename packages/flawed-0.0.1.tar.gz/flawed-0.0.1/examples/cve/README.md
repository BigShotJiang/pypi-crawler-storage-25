# CVE Examples -- Real-World Vulnerabilities

Detection rules targeting real-world Flask applications with confirmed
vulnerabilities.

| Rule | Repo | Vulnerability | Status |
|------|------|---------------|--------|
| input-reaches-mutation-without-validation | murtaza-nasir/speakr | Unvalidated input reaches DB write | Draft |
