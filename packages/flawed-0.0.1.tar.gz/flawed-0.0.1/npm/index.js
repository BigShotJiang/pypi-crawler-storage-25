// flawed-engine: Python static analysis engine
// Install the Python package: pip install flawed
// https://github.com/execveat/flawed
throw new Error("flawed-engine is a Python package. Install with: pip install flawed");
