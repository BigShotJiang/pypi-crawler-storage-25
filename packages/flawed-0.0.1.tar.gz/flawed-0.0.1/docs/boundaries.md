# Layer Boundaries

Normative reference for what belongs where. Every component, fact, and
capability must live in exactly one layer. When in doubt, this document
decides.

## The Three Layers

```
Layer 1: Code Index          run once per repo snapshot
Layer 2: Semantic Layer      run per detection, extensible
Layer 3: Rule API            user-facing, consumes Layer 2 only
```

Dependencies flow strictly downward. Layer 3 depends on Layer 2. Layer 2
depends on Layer 1. No skipping. No reverse references.

---

## Layer 1: Code Index

Layer 1 owns mechanically-grounded Python structural observations. It
runs once per repository snapshot, persists its outputs, and exposes them
through a typed Python API. It knows Python the language. It does not
know any framework, library, or application convention.

### Owns

- Files, packages, modules, source locations.
- Import statements and resolved fully-qualified names.
- Symbol uses and name resolution.
- Function inventory: name, FQN, parameters (with defaults and
  annotations), decorators (syntactic presence only), nesting,
  closures, lambdas, method vs. top-level classification.
- Class inventory: name, FQN, bases, MRO, methods, class variables,
  metaclass (when statically determinable).
- Call-site inventory: caller, callee (resolved or unresolved),
  arguments (positional and keyword, with source expressions),
  location.
- Call graph: direct calls, method resolution through class hierarchy,
  super() chains, and unresolved dispatch patterns (getattr, dict
  dispatch, importlib, reflection) as edges with resolution metadata.
  Does NOT include framework-injected edges such as route-to-handler
  or lifecycle-hook-to-function.
- Value-flow edges: assignments, argument passing, return values,
  aliases, tuple/list unpacking, dictionary spreads, comprehension
  bindings. Intra-procedural is mandatory. Inter-procedural is
  structural only (follows call graph edges).
- CFG per function: basic blocks, edges, dominance frontiers, immediate
  dominators, post-dominators, branch conditions (as AST expressions).
- Class hierarchy: inheritance edges, MRO ordering, method resolution
  order, abstract method declarations. Stored on Class objects directly
  (not a separate index).
- Attribute reads and writes on any object: target expression,
  attribute name, read vs. write, access kind, location. Includes
  dict operations (`obj["key"]`, `obj["key"] = val`), list/set
  mutations (`.append`, `.add`), del statements, and augmented
  assignments. There is no separate mutation index; Layer 2 classifies
  which accesses are security-relevant mutations.
- Symbolic values: Semgrep-derived data-flow observations, value
  propagation within function bodies.
- Decorator inventory: name, resolved FQN (when determinable),
  arguments (as source expressions), application order, target
  function. No semantic interpretation.
- Errors and gaps: per-file parse failures, per-function CFG
  construction failures, unresolved symbols, astroid inference
  failures, Semgrep extraction errors.

### Never

- Identifies routes, handlers, endpoints, or URL rules.
- Classifies any expression as a request input read.
- Recognizes session, g, current_user, or any application-state proxy.
- Tags any decorator, call, or conditional as a security gate.
- Tags any call or write as a security-relevant effect.
- Assigns vulnerability semantics to any code pattern.
- Contains logic specific to Flask, Django, SQLAlchemy, marshmallow,
  webargs, or any other framework or library.

### Public API Vocabulary

Layer 1 speaks in: functions, classes (with hierarchy), decorators
(with resolved FQNs), call edges (including unresolved dispatch),
parameters, imports, assignments, attribute accesses (including
mutations), CFG blocks, dominance, value-flow edges, source locations.
Every object returned is frozen and provenance-tagged.

---

## Layer 2: Semantic Layer

Layer 2 interprets Layer 1's structural facts through framework,
library, and convention knowledge. It runs on every detection execution.
It is the sole location of framework-specific logic in the system.

### Owns

- **Route identification.** Which functions are HTTP handlers. Which
  decorators register routes. URL rules, HTTP methods, endpoint names,
  blueprint membership. Covers @app.route, MethodView, add_url_rule,
  and equivalent patterns in Flask-RESTful, Flask-RESTx, and others.
- **Request input mapping.** Which code expressions access HTTP request
  data. Maps call sites and attribute accesses to typed locators
  (Query, Form, Json, Header, Cookie, PathParam, File, RawBody,
  SessionKey). Covers Flask's request object, function parameters from
  URL rules, and library parsers (marshmallow, webargs, pydantic).
- **Context and state access.** Which attribute reads/writes touch
  application-state containers: Flask's g, session, current_user, and
  equivalents. Classification of reads vs. writes.
- **Gate identification.** Which decorators, function calls, and
  conditional expressions serve as security checks. Includes auth
  decorators, permission-check calls, identity comparisons, CSRF
  validation. Tags with gate kind and security semantics.
- **Effect identification.** Which calls and writes are
  security-relevant side effects. ORM writes, external HTTP requests,
  file writes, cache mutations, session mutations, notification sends.
  Tags with effect kind and target model/resource.
- **Lifecycle hook resolution.** Maps before_request, after_request,
  teardown_request (and equivalents) to their scopes and execution
  order relative to route handlers.
- **Method branch reconstruction.** Identifies single-handler functions
  that dispatch on HTTP method via conditionals. Reconstructs
  per-method code scopes within the CFG.
- **Mutation classification.** Promotes Layer 1's generic mutations
  into security-relevant categories based on library knowledge: ORM
  writes, session mutations, cache operations, state transitions.
- **Framework-specific dispatch resolution.** Resolves dispatch
  patterns that require framework knowledge: MethodView method
  dispatch, Flask-RESTful resource dispatch, plugin registries.
- **On-demand data flow tracing.** Traces data propagation from
  arbitrary user-specified sources through the call graph and
  value-flow edges. Uses Layer 1 structural facts. Replaces
  pre-computed taint summaries with a runtime service that accepts
  any source, not just request.

### Properties

- Runs per detection execution. Results are NOT persisted alongside
  Layer 1 artifacts.
- Extensible. Users register new framework patterns, override built-in
  behavior, add library adapters. Extensions have full parity with
  built-in interpreters.
- All framework knowledge lives here and ONLY here.
- Consumes Layer 1 through its public Python API exclusively. Never
  reads Layer 1's internal file formats directly.
- Handles absent frameworks gracefully. If a repo does not use Flask,
  Flask interpreters produce empty results without error.
- Every observation is evidence-backed, linking to the Layer 1 facts
  that support it.

### Public API Vocabulary

Layer 2 speaks in: routes, request reads, context accesses, gates,
effects, lifecycle hooks, method branches, classified mutations,
framework dispatch, data flow traces. It exposes these as typed domain
objects that Layer 3 navigates and queries.

---

## Layer 3: Rule API

Layer 3 is the user-facing surface for vulnerability detection rule
authoring and interactive code exploration. It consumes Layer 2
exclusively. It owns security invariant expression and evidence
evaluation.

### Owns

- Typed domain object navigation: Route, Function, Gate, Effect,
  RequestRead, and their properties and relationships.
- Scoped queries: .reads(), .effects(), .gates(), .calls(),
  .conditions(), .mutations(), .context_writes().
- Collection API: filtering, grouping, chaining, set operations over
  domain objects.
- CFG relationship queries: dominance, ordering, path enumeration.
  Accesses Layer 1 CFGs through Layer 2 domain objects.
- Evidence building: structured evidence chains, missing-evidence
  records, analysis gap records.
- Candidate building: severity, tags, summary, evidence, invariant
  description.
- Detector framework: registration, config, required/optional
  projections, lifecycle.
- Development tools: trace, dry_run, explain, interactive exploration.
- Rule profiles and detector configuration.

### Never

- Imports or references Layer 1 directly. All structural facts arrive
  through Layer 2's domain objects.
- Parses raw artifacts, AST nodes, JSONL files, or Semgrep output.
- Contains framework-identification logic. Does not decide what
  constitutes a "route" or a "request read."
- Assigns meaning to decorators, calls, or conditionals. Uses the
  meanings Layer 2 has already assigned.

### Public API Vocabulary

Layer 3 speaks in: invariants, evidence, candidates, confusion
patterns, detection rules, security observations, research hypotheses.

---

## Promotion Rules

### From Layer 2 to Layer 1

A dynamic observation may be promoted into the run-once pipeline ONLY
when ALL of the following hold:

1. Multiple independent Layer 2 interpreters require the same primitive
   observation.
2. The observation is mechanically derivable from Python structure
   alone, without framework or library knowledge.
3. Keeping it dynamic requires repeated expensive traversal that
   Layer 2 cannot reasonably cache within a single detection run.
4. The promoted fact encodes zero framework, library, or convention
   semantics.
5. Fixtures demonstrate the exact input and output contract.

Valid promotions: a new value-flow edge kind, a new generic dispatch
pattern, a missing decorator argument projection.

Invalid promotions: "this decorator is an auth gate," "this call writes
to the database," "this function is a route handler."

### From Layer 3 to Layer 2

A detection-rule pattern may be promoted into a reusable interpreter
ONLY when ALL of the following hold:

1. Multiple independent detectors repeat the same framework
   interpretation logic.
2. The logic can be expressed as a model library, selector factory, or
   interpreter registration.
3. The logic does not encode vulnerability semantics: it does not
   decide which detector to run, what severity to assign, or what
   constitutes a reportable finding.

---

## Failure Semantics

### Layer 1 Failures

- **Per-file parse failure.** Recorded as an error fact with file path,
  error kind, and message. Other files continue. Layer 2 sees the gap
  when it queries for functions in that file.
- **Per-function CFG failure.** Recorded as an error fact. The function
  exists in the inventory but has no CFG. Layer 2 reports this as an
  analysis gap on any route whose reachable code includes that
  function.
- **Semgrep extraction failure.** Recorded per-file. The call graph and
  symbol analysis may be incomplete. Layer 1 API exposes
  which files lack Semgrep coverage.
- **Unresolved symbol.** The symbol ref exists with resolution status
  UNRESOLVED. Layer 2 sees it and can include it in evidence chains.
- **Fatal failures.** Invalid repo path, missing snapshot directory,
  Semgrep Pro binary missing, manifest corruption. These stop the
  pipeline and produce a machine-readable error. No partial results.

### Layer 2 Failures

- **Framework not detected.** Not an error. Flask interpreters return
  empty results. Other interpreters still run.
- **Pattern not matched.** A registered interpreter found no instances.
  Not an error. Returned as empty collections.
- **Ambiguous interpretation.** When a code pattern matches multiple
  interpreter rules, Layer 2 reports all matches with confidence
  scores. Layer 3 (or the rule author) decides.
- **Layer 1 gap encountered.** A function has no CFG, a file was not
  parsed, a symbol is unresolved. Layer 2 propagates the gap as a
  structured AnalysisGap attached to the affected domain object. It
  does NOT silently skip the object or fabricate certainty.
- **Interpreter error.** A user-provided interpreter raises an
  exception. Layer 2 catches it, records it as an interpreter failure
  with full traceback, and continues with remaining interpreters.

### Layer 3 Failures

- **Required evidence missing.** A detector cannot find facts it needs.
  It emits an InsufficientEvidence record instead of a Candidate. It
  must NOT silently conclude that code is safe because evidence is
  absent.
- **Optional evidence missing.** Noted in the Candidate's gaps field.
  The candidate is still emitted with reduced confidence.
- **Detector error.** An unhandled exception in detector code. The
  framework catches it, records the failure, and continues with
  remaining detectors.

### The Cardinal Rule

No layer may fail open. Missing analysis is never treated as proof that
code is safe. Every gap, error, and unresolved observation is recorded,
propagated, and available for inspection by the layer above.
