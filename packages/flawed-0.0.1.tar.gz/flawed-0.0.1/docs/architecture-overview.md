# Confusion Analysis Engine

Specification for the standalone analysis engine for researching confusion
vulnerabilities in Python web applications.

## Problem Statement

> Given a local repository snapshot, compile source code into stable
> structural facts, interpretable framework-specific domain objects, and
> composable detection-rule primitives for confusion vulnerability research.

## Architecture

Three layers. Each owns a distinct concern. Dependencies flow in one
direction: Layer 3 -> Layer 2 -> Layer 1. No skipping, no reverse.

```
  repository snapshot
        |
        v
  Layer 1: Code Index
    Python-generic structural extraction.
    Runs once per repo snapshot. Persists artifacts.
    Exposes: functions, classes, call graph, CFGs, value-flow,
             symbols, decorators, imports, class hierarchy.
        |
        |  CodeIndex API (frozen Python objects)
        v
  Layer 2: Semantic Layer
    Framework/library/convention interpretation.
    Runs per detection. Extensible by users.
    Exposes: routes, request reads, gates, effects,
             lifecycle hooks, on-demand flow traces.
        |
        |  WebApp API (frozen domain objects)
        v
  Layer 3: Rule API
    Typed domain navigation, scoped queries,
    evidence building, detector framework, dev tools.
    Consumers: rule authors, notebooks, batch detection.
```

## Directory Structure

```
L6/
  README.md                  <- You are here
  principles.md              <- Vision, non-negotiable principles, API design principles
  architecture.md            <- Three-layer overview, data flow, execution model
  boundaries.md              <- Normative boundary spec: what belongs where

  API-L1-Code-Index/         <- Layer 1: Python-generic structural extraction
    README.md                  Extraction pipeline, CodeIndex API, data types

  API-L2-Semantic-Layer/     <- Layer 2: Framework/library interpretation
    README.md                  Interpreter architecture, WebApp API, flow tracing

  API-L3-Rule-API/           <- Layer 3: Rule authoring and exploration surface
    README.md                  Domain objects, queries, evidence, detector framework
```

## Reading Order

### For rule authors (start here)

1. `principles.md` sections 1-3 -- vision and API design principles
2. `API-L3-Rule-API/README.md` -- domain objects, queries, examples
3. Start writing rules

### For framework adapter authors

1. `principles.md` -- non-negotiable design principles
2. `boundaries.md` -- what belongs in which layer
3. `API-L2-Semantic-Layer/README.md` -- interpreter protocol, extension model

### For pipeline developers

1. `principles.md` -- full document
2. `architecture.md` -- three-layer overview, data flow, execution model
3. `boundaries.md` -- normative boundary spec
4. `API-L1-Code-Index/README.md` -- extraction pipeline, CodeIndex API
5. `API-L2-Semantic-Layer/README.md` -- interpreter architecture, WebApp API
6. `API-L3-Rule-API/README.md` -- rule authoring surface

## Key Design Decisions

1. **Framework knowledge is never in the run-once pipeline.** The Code
   Index knows Python the language. Flask, SQLAlchemy, marshmallow, and
   every other framework live exclusively in the Semantic Layer.

2. **Extensibility without re-extraction.** Adding a new framework,
   fixing a route-detection pattern, or recognizing a new ORM call
   requires zero re-extraction. User extensions have full parity with
   built-in defaults.

3. **On-demand flow tracing replaces pre-computed taint.** Semgrep's
   taint signatures are removed from the internal pipeline. Data-flow
   tracing is a runtime Semantic Layer service that accepts arbitrary
   sources, not just `request`.

4. **Decorators split: syntax in Layer 1, meaning in Layer 2.** The Code
   Index records decorator name, arguments, and location. The Semantic
   Layer decides whether a decorator is an auth gate, a route
   registration, or a CSRF exemption.

5. **Strict unidirectional layering.** Layer 3 -> Layer 2 -> Layer 1.
   No skipping. No reverse dependencies. No exceptions.

## Supersession

This directory supersedes `wip/round2/L5/confusion-analysis/`.

What changed from L5 to L6:

| L5 | L6 | Why |
|----|-----|-----|
| 7-stage monolithic pipeline | 3-layer architecture | Clear responsibility boundaries, strict layering |
| Flask-specific extraction in run-once pipeline | All framework logic in Semantic Layer | Extensibility without re-extraction |
| No middle layer | Semantic Layer (Layer 2) | Framework interpretation must be dynamic and extensible |
| Pre-computed taint via Semgrep rule | On-demand flow tracing at Layer 2 | Arbitrary sources, not just `request`; no Semgrep dependency |
| Extension via model libraries only | Full interpreter replacement/extension | First-class framework adapter protocol |
| Mixed generic/Flask components per stage | Pure generic pipeline + pure framework layer | Each layer testable in isolation |

## Relationship to Other Documentation

| Document | Role |
|----------|------|
| `wip/round2/L5/confusion-analysis/` | Previous iteration (superseded by this directory) |
| `wip/round2/L4/confusion-analysis-pipeline.md` | Historical: original monolithic spec |
| `docs/analysis-pipeline/` | Empirical research: Semgrep capabilities, tool evaluations |
| `.claude/scratch/semgrep-pro-investigation/` | Research artifacts: extraction outputs, wave test results |
