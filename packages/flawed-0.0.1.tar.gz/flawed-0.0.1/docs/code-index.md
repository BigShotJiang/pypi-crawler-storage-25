# Layer 1: Code Index

Run-once-per-repo Python-generic structural extraction pipeline and its
public API.

The Code Index extracts structural facts from Python source code. It knows
Python the language. It does not know Flask, SQLAlchemy, marshmallow, or
any other framework or library. It runs once per repository snapshot,
persists artifacts to a deterministic directory tree, and exposes them
through a single typed Python entry point: `CodeIndex`.

---

## 1. Tooling

The Code Index builds on mature, well-maintained static analysis
libraries. Each serves a distinct role. None is optional.

| Tool | Role | Why |
|------|------|-----|
| **LibCST** | Primary parsing layer | Lossless concrete syntax tree with metadata framework. `ScopeProvider` and `QualifiedNameProvider` give per-node scope and FQN resolution. The visitor pattern is designed for building analysis passes. |
| **astroid** | Inference engine | `node.infer()` yields possible values. `ClassDef.mro()` computes inheritance. Brain plugins understand stdlib patterns. Fills the gap where LibCST has no type or value inference. |
| **Semgrep Pro** | Cross-file call graph and symbols | Project-wide call graph extraction, per-file call edges, symbol analysis, and symbolic value observations. Runs as a subprocess. |
| **basedpyright** | Type oracle | Best available Python type inference. Run via CLI with `--outputjson`, parse the output, enrich our own analysis with inferred types. Subprocess integration. |
| **NetworkX** | Graph data structures | All graph algorithms: reachability, SCC, dominators, topological sort, transitive closure. Used for call graph, CFG, class hierarchy, and value-flow graphs internally. |

Every extraction pass uses LibCST + astroid as the primary analysis
foundation. Semgrep Pro supplements with cross-file structural data that
is expensive to replicate. basedpyright supplements with type inference
that neither LibCST nor astroid can match.

If astroid fails to infer a specific node, that failure is recorded as
an `ExtractionError` on the affected entity. astroid itself is never
treated as optional.

---

## 2. Extraction Pipeline

Seven steps execute in a fixed order. Steps 1-2 use Semgrep Pro.
Steps 3-5 use LibCST and astroid. Steps 6-7 merge and index.

### Step 1: Semgrep Structural Extraction

Extract raw structural representations from Semgrep Pro's internal
analysis.

| | |
|---|---|
| **Consumes** | Repository source files, Semgrep Pro binary |
| **Produces** | `raw/semgrep/callgraph.raw.json` -- project-wide call graph |
| | `raw/semgrep/call_edges/<slug>.raw.json` -- per-file call edges |
| | `raw/semgrep/symbols/<slug>.raw.json` -- per-file symbol analysis |
| | `raw/semgrep/svalues/<slug>.raw.txt` -- per-file symbolic values |
| **Tool** | Semgrep Pro with `--dump-callgraph`, `--dump-call-edges`, `--dump-il-all`, `--dump-svalue` |
| **Mandatory** | Yes |

Does NOT run taint analysis. There is no taint rule, no
`-dump_taint_sigs` invocation.

### Step 2: Semgrep Normalization

Parse raw Semgrep output into typed fact records with a common envelope
schema.

| | |
|---|---|
| **Consumes** | All raw Semgrep artifacts from Step 1 |
| **Produces** | `symbol_refs.jsonl` -- symbol uses, resolved FQNs |
| | `semgrep_call_edges.jsonl` -- call edges from both call graph modes |
| | `svalue_facts.jsonl` -- parsed symbolic value observations |
| **Tool** | Custom parsers for each Semgrep output format |
| **Mandatory** | Yes |

### Step 3: Structural Entity Pass

Walk every Python file and extract a complete structural inventory using
LibCST with its metadata providers and astroid for inference.

| | |
|---|---|
| **Consumes** | Repository source files; Step 2 symbol_refs for FQN cross-referencing |
| **Produces** | `functions.jsonl` -- function/method definitions with full signatures |
| | `classes.jsonl` -- class definitions with bases, MRO, class variables |
| | `imports.jsonl` -- import statements with resolved FQNs |
| | `decorators.jsonl` -- decorator applications with resolved FQNs |
| | `aliases.jsonl` -- name aliases from assignments and imports |
| | `attribute_accesses.jsonl` -- reads and writes on any object |
| | `assignments.jsonl` -- all assignment targets and values |
| | `locations.jsonl` -- source location index for all entities |
| **Tool** | LibCST (`MetadataWrapper`, `ScopeProvider`, `QualifiedNameProvider`) + astroid (inference, MRO) |
| **Mandatory** | Yes (per-file failures are recorded, not fatal) |

LibCST provides scope resolution and qualified name metadata per node.
astroid provides value inference for decorator arguments, base class
resolution for complex inheritance, and MRO computation. Both run on
every file. FQN resolution combines LibCST's `QualifiedNameProvider`,
astroid's inference, and Semgrep's cross-file symbol analysis.

Class hierarchy (MRO, inheritance edges, method resolution) is computed
as part of this step using astroid's `ClassDef.mro()`. The hierarchy
data is stored on `Class` objects directly rather than in a separate
pass.

### Step 4: CFG and Dominance Pass

Build per-function control-flow graphs with dominance information.

| | |
|---|---|
| **Consumes** | Step 3 functions, repository source files |
| **Produces** | `cfgs.jsonl` -- per-function CFGs: basic blocks, edges, dominance frontiers, immediate dominators, post-dominators, branch conditions |
| **Tool** | Custom CFG builder on LibCST + NetworkX for dominance computation |
| **Mandatory** | Yes (per-function failures recorded, not fatal) |

A basic block is a maximal straight-line sequence of statements with no
branches or branch targets in the middle. Entry is through the first
statement; exit through the last. Branch conditions are preserved as
source expressions on the outgoing edges.

### Step 5: Value Flow Pass

Compute intra-function value-flow edges and structural interprocedural
links.

| | |
|---|---|
| **Consumes** | Step 3 functions, assignments, attribute_accesses; Step 2 svalue_facts |
| **Produces** | `value_flow.jsonl` -- assignment chains, argument bindings, return flows, aliases, unpacking |
| **Tool** | LibCST + astroid + Semgrep svalues |
| **Mandatory** | Yes |

Within each function body: tracks assignments, aliasing, tuple/list
unpacking, comprehension bindings, augmented assignments.

Across function boundaries: links call-site arguments to callee
parameters and callee return values to call-site targets, using the
call graph edges from Step 6. These interprocedural links are
structural -- they follow the call graph, not taint propagation rules.

### Step 6: Call Graph Merge

Produce a single unified call graph from all available sources, including
unresolved dispatch edges.

| | |
|---|---|
| **Consumes** | Step 2 semgrep_call_edges, Step 3 functions and classes (AST-extracted calls, class hierarchy), Step 3 attribute_accesses (for dispatch pattern detection) |
| **Produces** | `merged_call_graph.nodes.jsonl` -- function nodes |
| | `merged_call_graph.edges.jsonl` -- call edges with source, resolution, dispatch metadata |
| **Tool** | Custom merge with conflict resolution; NetworkX for graph storage |
| **Mandatory** | Yes |

The merge combines three edge sources:

1. **Semgrep cross-file call edges** -- high-confidence structural calls
   detected by Semgrep Pro's interprocedural analysis.
2. **AST-extracted call edges** -- calls detected by LibCST traversal
   of function bodies, with FQN resolution from LibCST metadata and
   astroid inference.
3. **Class hierarchy method resolution** -- `super()` chains and method
   calls resolved through the MRO computed in Step 3.

Additionally, the merge detects **generic dynamic dispatch patterns**
and represents them as call graph edges with `resolution=UNRESOLVED`:

- `getattr(obj, name)` / `setattr(obj, name, val)` -- with
  `possible_targets` populated when the name is a literal string.
- Dictionary-based dispatch (`handlers[key]()`) -- with
  `possible_targets` when dict entries are statically determinable.
- `importlib.import_module()` / `__import__()` calls.
- `*args` / `**kwargs` forwarding through wrapper functions.

These unresolved edges carry `dispatch_type` metadata describing the
dispatch pattern. Layer 2 may resolve them further using framework
knowledge (e.g., MethodView dispatch, signal handlers).

Contains only Python-structural edges. Does NOT include
route-to-handler, lifecycle-hook-to-function, or any framework-injected
call relationship. Layer 2 extends the call graph with those at runtime.

### Step 7: Index Construction

Build lookup indexes over the merged facts for fast API queries.

| | |
|---|---|
| **Consumes** | All normalized facts from Steps 2-6 |
| **Produces** | `indexes.json` -- function-by-FQN, calls-by-caller, calls-by-callee, decorators-by-target, decorators-by-fqn, attributes-by-object, classes-by-FQN, classes-by-base |
| **Tool** | Custom indexing |
| **Mandatory** | Yes |

---

## 3. Public API: CodeIndex

`CodeIndex` is the sole entry point for Layer 2 to access Layer 1 data.
No Layer 2 code reads JSONL files, raw Semgrep output, or internal
indexes directly. All access goes through this typed API.

```python
idx = CodeIndex.open("/path/to/analysis-store/repos/slug/snapshot")
```

**Collection chaining rule.** Every filter method on every collection
returns a new instance of the same collection type. All filters compose
through chaining:

```python
idx.functions.in_dir("app/").methods().decorated_with("login_required")
# returns FunctionCollection, each step narrowing the set
```

### Entity Collections

```python
idx.functions                       # FunctionCollection
idx.functions.named("process")      # filter by short name
idx.functions.with_fqn("app.views.process")  # filter by FQN
idx.functions.in_file("app/views.py")
idx.functions.in_dir("app/")
idx.functions.decorated_with("login_required")  # matches short name OR FQN;
                                    # dotted names match FQN, simple names match short name
idx.functions.methods()             # is_method == True
idx.functions.top_level()           # kind == TOP_LEVEL
idx.functions.nested()              # kind == NESTED
idx.functions.where(predicate)      # arbitrary predicate

idx.classes                         # ClassCollection
idx.classes.named("UserModel")
idx.classes.with_fqn("app.models.UserModel")
idx.classes.in_file("models.py")
idx.classes.in_dir("app/models/")
idx.classes.decorated_with("dataclass")
idx.classes.subclasses_of("Base")           # transitive (all descendants)
idx.classes.direct_subclasses_of("Base")    # single level only
idx.classes.where(predicate)

idx.imports                         # ImportCollection
idx.imports.in_file("app/views.py")
idx.imports.importing("flask")      # module name match
idx.imports.importing_name("request")  # specific imported name
idx.imports.where(predicate)

idx.decorators                      # DecoratorCollection
idx.decorators.named("route")       # short name match
idx.decorators.with_fqn("flask.Flask.route")  # FQN match
idx.decorators.on_function("app.views.index")  # by decorated function FQN
idx.decorators.on_function_named("index")      # by decorated function short name
idx.decorators.in_file("app/views.py")
idx.decorators.where(predicate)
```

Collections are iterable, support `len()`, indexing, slicing, and return
frozen objects. `.first()` returns the first item or `None`. `.one()`
returns exactly one item or raises. `.exists()` returns `True` if
non-empty.

### Call Graph

The call graph answers two kinds of questions: **who** calls whom
(function-level) and **how** they call each other (edge-level with
arguments, location, resolution status).

```python
idx.call_graph                      # CallGraph

# WHO questions -- return FunctionCollection
idx.call_graph.callees(fn_fqn)      # direct callees
idx.call_graph.callers(fn_fqn)      # direct callers
idx.call_graph.reachable_from(fn_fqn)  # transitive closure of callees

# PATH questions -- return sequences of function FQNs
idx.call_graph.paths_between(fqn_a, fqn_b)  # all call chains from a to b

# HOW questions -- return CallEdgeCollection (with arguments, dispatch info)
idx.call_graph.edges_from(fn_fqn)   # outgoing edges with full metadata
idx.call_graph.edges_to(fn_fqn)     # incoming edges with full metadata
idx.call_graph.edge(caller_fqn, callee_fqn)  # specific edge or None
```

Why both? `callees("f")` tells you that `f` calls `g` and `h`.
`edges_from("f")` tells you that `f` calls `g` at line 42 passing
`user_id` as the first argument with resolution status `RESOLVED`,
and calls `h` at line 58 via `getattr(self, name)` with resolution
`UNRESOLVED` and `dispatch_type=GETATTR`.

Rule authors at Layer 2 and Layer 3 primarily use the WHO and PATH
questions. The HOW questions are essential for Layer 2 interpreters
that need to inspect call arguments to classify request reads, effects,
and gates.

Dispatch patterns (getattr, dict dispatch, etc.) live as call graph
edges with `resolution=UNRESOLVED` rather than in a separate dispatch
index. They participate in reachability and path queries the same as
any other edge.

### Control Flow

A per-function control-flow graph. Every function with a successfully
built CFG exposes this interface. Functions where CFG construction
failed have no CFG (the failure is on `idx.errors`).

```python
cfg = idx.cfg(fn_fqn)               # ControlFlowGraph or None

# Structure (primarily for debugging and inspection)
cfg.blocks                          # tuple of CFGBlock -- basic blocks
cfg.entry                           # the entry CFGBlock
cfg.exits                           # exit CFGBlocks (return, raise, implicit)

# Query methods (the intended API for consumers)
cfg.dominates(loc_a, loc_b)         # bool: every path from entry to loc_b
                                    # passes through loc_a
cfg.post_dominates(loc_a, loc_b)    # bool: every path from loc_b to exit
                                    # passes through loc_a
cfg.precedes(loc_a, loc_b)          # bool: loc_a appears before loc_b on
                                    # EVERY execution path that visits both
cfg.block_for(location)             # CFGBlock containing a source location
cfg.paths_between(loc_a, loc_b)     # tuple of CFGPath objects, each a
                                    # sequence of blocks from loc_a to loc_b
cfg.conditions_between(loc_a, loc_b)  # tuple of BranchCondition objects:
                                    # every branch condition on every path
                                    # from loc_a to loc_b, with the boolean
                                    # direction taken on each path
```

All `loc_*` parameters are `Location` objects -- source file positions,
not block IDs. The CFG resolves locations to blocks internally.

A `CFGBlock` is a maximal straight-line sequence: no branches or branch
targets mid-block. It carries `statements` (tuple of `Location` values
for each statement), `successors` and `predecessors` (block IDs), and
`condition_expr` (source text of the branch condition, if this block
ends with a branch).

A `CFGPath` is a sequence of `CFGBlock` objects forming a concrete
execution path. A `BranchCondition` is a branch point with its
condition expression and the direction (True/False) taken.

### Value Flow

Pre-computed value-flow edges within function bodies, plus structural
interprocedural links along call graph edges. This is the foundation
that Layer 2 builds upon for on-demand cross-project flow tracing.

```python
idx.value_flow                      # ValueFlowGraph

# Intra-function: where does a value go / come from?
idx.value_flow.flows_from(location)   # ValueFlowEdgeCollection: edges
                                      # originating at this location
idx.value_flow.flows_to(location)     # ValueFlowEdgeCollection: edges
                                      # arriving at this location

# Interprocedural structural links
idx.value_flow.binding_chain(fn_fqn, param_name)
    # tuple of ValueFlowEdge objects: the assignment chain across callers
    # that reaches this parameter, following call graph edges structurally
    # (i.e. argument at call site -> parameter at function entry)

idx.value_flow.assignments_to(name, fn_fqn)
    # ValueFlowEdgeCollection: all assignments to `name` within the
    # function identified by fn_fqn
```

**Scope.** Intra-function edges are pre-computed for every function.
Interprocedural links are structural: they follow call graph edges
(argument-to-parameter, return-to-caller) without taint propagation
rules. Full cross-project flow tracing -- with framework-specific
propagators, source/sink definitions, and library-aware data movement
-- is Layer 2's responsibility, built on top of this value-flow
foundation and the call graph.

### Symbol Resolution

```python
idx.symbols                         # SymbolIndex

idx.symbols.resolve(name, file)     # str | None: given a name used in a
                                    # file, return its resolved FQN (using
                                    # LibCST QualifiedNameProvider, astroid
                                    # inference, and Semgrep symbols)
idx.symbols.usages(fqn)             # tuple of Location: every location
                                    # where this FQN is referenced
idx.symbols.unresolved()            # SymbolRefCollection: all symbol
                                    # references that could not be resolved
```

### Attribute Access

```python
idx.attributes                      # AttributeAccessCollection
idx.attributes.reads_on(target_expr)  # reads on a target expression pattern
idx.attributes.writes_on(target_expr) # writes on a target expression pattern
idx.attributes.named(attr_name)       # all accesses of a named attribute
idx.attributes.in_function(fn_fqn)    # all accesses within a function
idx.attributes.in_file(path)
idx.attributes.where(predicate)
```

Attribute access covers all object attribute reads and writes, including
`obj.attr`, `obj.attr = val`, and `del obj.attr`. Dict operations
(`obj["key"]`, `obj["key"] = val`) and other mutation patterns
(`list.append(v)`, `set.add(v)`, `del x[k]`) are captured here as
well, through the `access_kind` field on `AttributeAccess`.

There is no separate mutation index. Layer 2 classifies which accesses
and writes are security-relevant mutations using framework knowledge.

### Source Text and Errors

```python
idx.source(location)                # source text at a Location
idx.source(location, context=3)     # with N lines of surrounding context

idx.errors                          # ExtractionErrorCollection
idx.errors.in_file("app/views.py")
idx.errors.for_pass("cfg")
idx.errors.for_pass("astroid")
idx.errors.fatal()                  # only fatal errors
idx.errors.where(predicate)
```

---

## 4. Key Design Decisions

### Mandatory astroid and LibCST

astroid and LibCST are mandatory core dependencies, not optional
enhancements. LibCST provides the parsing foundation with its metadata
framework (scope analysis, qualified names). astroid provides inference
(value inference, MRO computation, decorator argument evaluation) that
LibCST cannot. basedpyright supplements both with type inference via
subprocess. Semgrep Pro provides cross-file call graph and symbol data.

If astroid fails to infer a specific node, the failure is recorded as
an error on that entity. The tool itself is never optional or degraded
to a fallback.

### No taint tracking

Taint analysis requires defining sources and sinks. Useful source
definitions like "Flask request object," "session proxy," or "function
parameters from URL rules" are framework-specific. Layer 1 provides the
structural building blocks -- call graph, value-flow edges, symbolic
values -- that Layer 2 uses to implement on-demand flow tracing from
arbitrary, user-defined sources.

### No route identification

Determining that a function is an HTTP route handler requires recognizing
framework-specific decorator patterns, class hierarchies, and
registration calls. Layer 1 provides the raw material: decorators
(syntactically with FQNs), class hierarchies, and call sites. Layer 2
interprets them.

### No separate mutation or dispatch index

Mutations (dict writes, list mutations, attribute writes) are already
captured by the attribute access inventory and assignment tracking.
Layer 2 classifies which of these are security-relevant mutations using
framework knowledge. A separate mutation-only index at Layer 1 adds no
information that the attribute access and assignment data doesn't
already provide.

Dynamic dispatch patterns (getattr, dict dispatch, importlib) are
represented as call graph edges with `resolution=UNRESOLVED` and
dispatch metadata. This means they participate in reachability queries,
path finding, and caller/callee lookups alongside resolved edges.
A separate dispatch index would force consumers to consult two sources
for what is fundamentally the same question: "what does this function
call?"

### Decorators carry resolved FQNs

Layer 1 records both the syntactic decorator name and the resolved FQN
(when determinable via LibCST + astroid + Semgrep symbols). The
`decorated_with()` filter method matches against both: dotted names
match the FQN, simple names match the short name. This lets Layer 2
interpreters identify `@flask_login.login_required` by FQN rather than
hoping the short name `login_required` is unambiguous.

Semantic meaning assignment (whether a decorator is an auth gate, a
route registration, or a CSRF exemption) remains Layer 2's
responsibility.

### Call graph excludes framework-injected edges

A route-to-handler relationship is not a Python call edge -- it is a
framework registration. Layer 1's call graph reflects actual Python
call structure. Layer 2 extends it with framework-specific edges at
runtime.

### Value-flow is structural, not semantic

Value-flow edges track assignments, argument passing, return values, and
aliases as they appear in the code. Taint propagation rules -- which
function calls propagate tainted values, which container operations
preserve taint, which sanitizers remove it -- require framework and
library knowledge. Layer 1 provides the structural edges. Layer 2
defines propagation semantics and builds cross-project flow tracing on
top.

---

## 5. Data Types

All types are frozen dataclasses with `__slots__`. All carry `location`
and `provenance`.

```python
@dataclass(frozen=True)
class Location:
    file: str
    start_line: int
    start_col: int
    end_line: int
    end_col: int

@dataclass(frozen=True)
class Provenance:
    producer: str        # "structural_entity_pass", "semgrep_callgraph", etc.
    producer_version: str
    artifact: str        # source artifact path

@dataclass(frozen=True)
class Function:
    fqn: str
    name: str
    file: str
    line: int
    params: tuple[Parameter, ...]
    decorator_names: tuple[str, ...]   # syntactic names
    decorator_fqns: tuple[str | None, ...]  # resolved FQNs (parallel to names)
    kind: FunctionKind                 # TOP_LEVEL, METHOD, NESTED, LAMBDA
    is_method: bool
    is_nested: bool
    parent_class: str | None           # FQN of containing class, if any
    location: Location
    provenance: Provenance

@dataclass(frozen=True)
class Class:
    fqn: str
    name: str
    file: str
    bases: tuple[str, ...]             # FQNs when resolved, names otherwise
    mro: tuple[str, ...]               # FQNs in MRO order (computed by astroid)
    method_names: tuple[str, ...]
    class_var_names: tuple[str, ...]
    metaclass: str | None
    subclasses: tuple[str, ...]        # FQNs of direct subclasses
    all_subclasses: tuple[str, ...]    # FQNs of transitive descendants
    inherited_methods: tuple[InheritedMethod, ...]  # (name, defining_class_fqn) in MRO order
    location: Location
    provenance: Provenance

@dataclass(frozen=True)
class CallEdge:
    caller_fqn: str
    callee_fqn: str | None             # None when fully unresolved
    arguments: tuple[CallArgument, ...]
    resolution: ResolutionStatus       # RESOLVED, UNRESOLVED, PARTIAL
    source: EdgeSource                 # SEMGREP, AST, HIERARCHY, DISPATCH
    dispatch_type: DispatchType | None # GETATTR, DICT_DISPATCH, IMPORTLIB, REFLECTION
    possible_targets: tuple[str, ...] | None  # FQNs when partially resolvable
    unresolved_reason: str | None
    location: Location
    provenance: Provenance

@dataclass(frozen=True)
class CFGBlock:
    id: int
    statements: tuple[Location, ...]   # source location of each statement
    successors: tuple[int, ...]        # block IDs
    predecessors: tuple[int, ...]      # block IDs
    condition_expr: str | None         # branch condition source text (on exit)

@dataclass(frozen=True)
class CFGPath:
    blocks: tuple[CFGBlock, ...]       # ordered sequence of blocks traversed

@dataclass(frozen=True)
class BranchCondition:
    condition_expr: str                # source text of the branch condition
    direction: bool                    # True/False branch taken
    location: Location                 # where the branch is in source

@dataclass(frozen=True)
class ValueFlowEdge:
    source_expr: str
    source_location: Location
    target_expr: str
    target_location: Location
    kind: FlowKind                     # ASSIGN, ARGUMENT, RETURN, ALIAS, UNPACK,
                                       # AUGMENTED_ASSIGN, COMPREHENSION_BINDING
    provenance: Provenance

@dataclass(frozen=True)
class DecoratorFact:
    name: str                          # syntactic short name
    fqn: str | None                    # resolved FQN when determinable
    args: tuple[str, ...]              # argument source expressions
    kwargs: tuple[tuple[str, str], ...]
    target_fqn: str                    # FQN of decorated function
    application_order: int             # 0 = innermost
    location: Location
    provenance: Provenance

@dataclass(frozen=True)
class AttributeAccess:
    target_expr: str                   # source text of the object expression
    attr_name: str                     # attribute or key name
    is_write: bool
    access_kind: AccessKind            # ATTR, SUBSCRIPT, DEL, AUGMENTED,
                                       # CALL_MUTATOR (e.g. .append, .add)
    value_expr: str | None             # source text of written value (writes only)
    location: Location
    provenance: Provenance

@dataclass(frozen=True)
class SymbolRef:
    name: str
    fqn: str | None
    resolution: ResolutionStatus
    location: Location
    provenance: Provenance

@dataclass(frozen=True)
class ImportFact:
    module: str
    names: tuple[str, ...]             # imported names (empty for bare import)
    aliases: tuple[tuple[str, str], ...]  # (original, alias) pairs
    is_from_import: bool
    location: Location
    provenance: Provenance

@dataclass(frozen=True)
class ExtractionError:
    file: str
    pass_name: str
    error_kind: ErrorKind              # PARSE, CFG, ASTROID, SEMGREP,
                                       # RESOLUTION, BASEDPYRIGHT
    message: str
    is_fatal: bool
    location: Location | None
```

---

## 6. Dependency Graph

```
Step 1: Semgrep Extraction
    |
    v
Step 2: Semgrep Normalization
    |
    +------------------------------+
    v                              v
Step 3: Structural Entity Pass   (symbol_refs used for FQN linking)
    |      (classes, functions,
    |       decorators, imports,
    |       hierarchy, attributes,
    |       assignments)
    |
    +----------+-----------+
    v          v           v
Step 4:    Step 5:     (entities
CFG &      Value        feed both)
Dominance  Flow
    |          |
    +----+-----+
         v
     Step 6: Call Graph Merge
      (semgrep edges + AST calls + hierarchy + dispatch patterns)
         |
         v
     Step 7: Index Construction
      (all normalized facts)
```

Steps 4 and 5 are independent of each other and may execute in
parallel. Step 6 requires Steps 2, 3, 4, and 5. Step 7 requires all
preceding steps.

---

## 7. Storage Format

Layer 1 owns a directory tree per repo snapshot:

```
analysis-store/repos/<slug>/<snapshot>/
    raw/semgrep/         Semgrep output preserved for audit
    normalized/          JSONL facts with common envelope schema
    projections/         Merged call graph, indexes
    manifest.json        Step status, effective version hashes
    errors.jsonl         All extraction errors
```

The internal format (JSONL schemas, file naming, directory layout) is an
implementation detail of the Code Index. It is NOT part of the public
contract. Consumers access everything through the `CodeIndex` Python
API. The storage format may change between versions without affecting
Layer 2 or Layer 3 code.
