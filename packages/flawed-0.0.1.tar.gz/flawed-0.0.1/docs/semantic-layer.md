# Layer 2: Semantic Layer

The Semantic Layer interprets Layer 1's Python-structural facts through
framework, library, and project-convention knowledge. It is the sole
location of framework-specific logic in the engine.

It runs on every detection execution. Adding support for a new framework,
fixing a recognition pattern, or extending library coverage requires
changing only this layer and never re-running the Code Index.

---

## 1. Responsibilities

The Semantic Layer receives a `CodeIndex` (Layer 1) and a set of
**interpreters** — pluggable modules that encode framework and library
knowledge. It executes every active interpreter, collects their typed
domain objects, and exposes the combined result through the `WebApp` API.

Concrete duties:

- Run route interpreters to discover HTTP endpoints.
- Run input interpreters to classify request-data access expressions.
- Run gate interpreters to identify security-check patterns.
- Run effect interpreters to classify security-relevant side effects.
- Run state interpreters to identify application-state container access.
- Run lifecycle interpreters to map framework hook registrations.
- Reconstruct method-specific code branches within handlers.
- Classify Layer 1's generic mutations into security-relevant categories.
- Resolve framework-specific dynamic dispatch targets.
- Build an enhanced call graph that includes framework-injected edges.
- Provide on-demand data-flow tracing from arbitrary sources.
- Aggregate and expose analysis gaps inherited from Layer 1.

The Semantic Layer does NOT own security invariants, vulnerability
semantics, candidate construction, or evidence evaluation. Those belong
to Layer 3.

---

## 2. Interpreter Architecture

An interpreter is an ordinary Python class that implements a typed
protocol, receives a `CodeIndex`, and returns domain objects. There is
one protocol per domain concept.

### Interpreter Protocols

```python
from typing import Protocol, Sequence

class RouteInterpreter(Protocol):
    framework: str                              # e.g. "flask", "flask-restful"
    def interpret(self, idx: CodeIndex) -> Sequence[Route]: ...

class InputInterpreter(Protocol):
    framework: str
    def interpret(self, idx: CodeIndex, routes: Sequence[Route]) -> Sequence[RequestRead]: ...

class GateInterpreter(Protocol):
    framework: str
    def interpret(self, idx: CodeIndex) -> Sequence[Gate]: ...

class EffectInterpreter(Protocol):
    framework: str
    def interpret(self, idx: CodeIndex) -> Sequence[Effect]: ...

class StateInterpreter(Protocol):
    framework: str
    def interpret(self, idx: CodeIndex) -> Sequence[ContextAccess]: ...

class LifecycleInterpreter(Protocol):
    framework: str
    def interpret(self, idx: CodeIndex, routes: Sequence[Route]) -> Sequence[Hook]: ...

class DispatchInterpreter(Protocol):
    framework: str
    def interpret(self, idx: CodeIndex) -> Sequence[DispatchResolution]: ...
```

### Execution Order

Interpreters run in a defined order because some consume the output of
others:

```
1. RouteInterpreters     — produce Routes from structural facts
2. InputInterpreters     — produce RequestReads (may scope to Routes)
3. StateInterpreters     — produce ContextAccess observations
4. GateInterpreters      — produce Gates (may reference Routes, Reads, State)
5. EffectInterpreters    — produce Effects
6. LifecycleInterpreters — produce Hooks (scoped to Routes/blueprints)
7. DispatchInterpreters  — produce enhanced dispatch resolutions
```

Within a single phase, interpreters from different frameworks run
independently and their results merge. A Flask route interpreter and a
Flask-RESTful route interpreter both contribute to the same
`RouteCollection`.

### Contract

Every interpreter must:

- Accept a `CodeIndex` and return domain objects.
- Declare `framework: str` identifying what it supports.
- Return an empty sequence when the framework is absent from the repo.
  Absence is not an error.
- Attach `InterpretationProvenance` to every domain object, linking
  back to the Layer 1 facts that support it.
- Raise no exceptions during normal operation. If interpretation fails
  for a specific code location, record an `InterpreterGap` and continue.

Every interpreter must NOT:

- Read Layer 1's internal files, JSONL artifacts, or storage paths.
- Mutate the `CodeIndex` or any object received from it.
- Import or reference Layer 3 types (rules, candidates, evidence).
- Encode vulnerability semantics (which pattern is dangerous, which
  gate is sufficient, which effect matters for a specific detector).

---

## 3. Built-in Flask Interpreters

The engine ships a default set of Flask interpreters. These are ordinary
interpreter modules — not privileged internal code. Users can replace,
extend, or disable any of them.

### FlaskRouteInterpreter

Recognizes Flask route registration patterns and produces `Route`
objects.

Patterns handled:

- `@app.route("/path", methods=["GET", "POST"])` on a function.
- `@blueprint.route(...)` with blueprint URL prefix resolution.
- `app.add_url_rule("/path", view_func=handler)`.
- `MethodView` subclasses registered via `as_view()`.
- Multiple decorators stacking methods on the same handler.
- Endpoint name inference from function name and blueprint.

Consumes from CodeIndex: `functions`, `decorators`, `classes`,
`hierarchy`, `symbols`.

### FlaskInputInterpreter

Maps code expressions to typed `RequestRead` observations with `Locator`
values.

Patterns handled:

| Code pattern | Locator |
|-------------|---------|
| `request.args.get("k")` | `Query("k")` |
| `request.args["k"]` | `Query("k")` |
| `request.form.get("k")` | `Form("k")` |
| `request.form["k"]` | `Form("k")` |
| `request.json.get("k")` | `Json("$.k")` |
| `request.json["k"]` | `Json("$.k")` |
| `request.headers.get("X-Token")` | `Header("X-Token")` |
| `request.cookies.get("sid")` | `Cookie("sid")` |
| `request.files["upload"]` | `File("upload")` |
| `request.data` | `RawBody()` |
| `request.get_json()` | `Json("$")` |
| `request.values.get("k")` | `AnyOf(Query("k"), Form("k"))` |
| Function parameter matching URL rule `<int:id>` | `PathParam("id")` |
| `request.args.getlist("ids")` | `Query("ids")`, cardinality=MULTI |

Also handles aliased access (`args = request.args; args.get("k")`)
using CodeIndex value-flow tracking and symbol resolution.

Consumes from CodeIndex: `call_graph`, `attributes`, `symbols`,
`value_flow`, `functions` (for path param binding).

### FlaskStateInterpreter

Identifies reads and writes to Flask application-state containers.

Patterns handled:

- `g.current_user`, `g.db`, `g.<any>` — attribute access on Flask `g`.
- `session["k"]`, `session.get("k")` — Flask session reads.
- `session["k"] = v` — Flask session writes.
- `current_user` (Flask-Login) — treated as state read when imported
  from `flask_login`.

Consumes from CodeIndex: `attributes`, `symbols`, `value_flow`.

### FlaskGateInterpreter

Classifies security-gate-like patterns.

Patterns handled:

- `@login_required` decorator (Flask-Login).
- `@roles_required(...)`, `@permissions_required(...)` patterns.
- `@csrf.exempt` (Flask-WTF) — negative gate (removal of protection).
- Conditional checks: `if g.current_user`, `if session.get("user_id")`.
- Function calls matching common auth patterns: `check_permission()`,
  `verify_token()`, `authorize()`.

Gate kind classification:

| Pattern | GateKind |
|---------|----------|
| Decorator | DECORATOR |
| Function call | FUNCTION_CALL |
| `if` condition on state | CONDITIONAL |
| Identity comparison | COMPARISON |

Consumes from CodeIndex: `decorators`, `call_graph`, `cfg`, `value_flow`,
`attributes`.

### FlaskEffectInterpreter

Classifies security-relevant side effects.

Patterns handled:

- `db.session.add(obj)`, `.commit()`, `.delete(obj)` — SQLAlchemy ORM.
- `Model.query.filter_by(...).update(...)` — SQLAlchemy query API.
- `requests.post(...)`, `requests.get(...)` — external HTTP.
- `open(path, "w")`, file write patterns.
- `session["k"] = v` — session mutation (also classified by state
  interpreter; the effect interpreter tags the security implication).
- `send_mail(...)`, notification-like calls.

Consumes from CodeIndex: `call_graph`, `attributes`, `symbols`.

### FlaskLifecycleInterpreter

Resolves Flask lifecycle hooks and their execution scope.

Patterns handled:

- `@app.before_request` — app-wide before hook.
- `@blueprint.before_request` — blueprint-scoped before hook.
- `@app.after_request`, `@app.teardown_request`.
- `@app.before_first_request`.
- Blueprint-level equivalents for all hooks.
- Execution order: before_request hooks run in registration order,
  scoped hooks run after app-wide hooks.

Consumes from CodeIndex: `decorators`, `functions`, `symbols`.

---

## 4. On-Demand Flow Tracing

Flow tracing replaces pre-computed Semgrep taint signatures. Instead of
running a fixed taint rule at extraction time, the Semantic Layer traces
data propagation on demand from any user-specified source.

### Why it replaces taint extraction

The L5 taint rule tracked only `request` and `request.$ANYTHING` as
sources — Flask-specific and incomplete even for Flask. It missed
`session`, `g`, `view_args` as function parameters, and every
third-party parser library. Moving flow tracing to Layer 2 means:

- Sources are framework-defined, not hard-coded in a Semgrep rule.
- Any interpreter can declare new sources.
- Users can trace from arbitrary starting points.
- No re-extraction is needed when source definitions change.

### How it works

The flow tracer is a runtime service built on Layer 1's pre-computed
structural facts:

```
CodeIndex.call_graph    — inter-procedural structure
CodeIndex.value_flow    — assignment chains, argument passing, returns
CodeIndex.symbols       — name resolution across files
CodeIndex.cfg           — intra-procedural control flow and branching
```

Given a source (a specific code location or a pattern matching multiple
locations) and an optional sink pattern, the tracer:

1. Identifies all matching source locations.
2. Follows value-flow edges forward from each source within its
   containing function.
3. At call sites, follows argument-to-parameter bindings across the
   call graph.
4. At return sites, follows return-to-caller bindings.
5. Records every step as a `FlowStep` with location and evidence.
6. Terminates at sinks, dead ends, or a configurable depth limit.

The result is a `FlowTrace` — a set of paths from source to reachable
points, each path a sequence of `FlowStep` values with provenance.

### API

```python
# Trace from a specific request read to any database write
traces = app.trace_flow(
    source=read.location,
    sink=EffectPattern(kind=EffectKind.DB_WRITE),
)

# Trace from any session read, no sink constraint
traces = app.trace_flow(
    source=StatePattern(namespace="session"),
)

# Trace with custom propagation rules
traces = app.trace_flow(
    source=read.location,
    propagators=[orm_propagator, serializer_propagator],
)
```

### Flow Interpreters

Interpreters can register **propagation rules** — patterns that the
tracer recognizes as data flowing through a function even when the
structural value-flow edges do not capture the relationship.

```python
class SQLAlchemyFlowInterpreter:
    """Tells the tracer that data flows through ORM operations."""
    framework = "sqlalchemy"

    def propagators(self, idx: CodeIndex) -> Sequence[Propagator]:
        return [
            Propagator(
                pattern=CallPattern(fqn="sqlalchemy.orm.Session.add"),
                input_arg=0,
                output="persisted to database",
            ),
        ]
```

This extensibility is critical: the structural value-flow graph cannot
capture every data propagation convention used by third-party libraries.
Flow interpreters fill the gaps.

---

## 5. Enhanced Call Graph

The Semantic Layer builds an enhanced call graph that extends Layer 1's
structural call graph with framework-injected edges.

### Edge sources

| Edge kind | Source | Interpreter |
|-----------|--------|-------------|
| Direct call | Layer 1 structural analysis | (none — passthrough) |
| Method resolution | Layer 1 class hierarchy | (none — passthrough) |
| Route → handler | Route identification | RouteInterpreter |
| Lifecycle hook → function | Hook resolution | LifecycleInterpreter |
| Signal → handler | Signal registration | (future DispatchInterpreter) |
| MethodView → dispatch method | Class dispatch | DispatchInterpreter |

### Usage

```python
# Enhanced reachability includes framework edges
scope = app.reachable_from(route.handler)

# The enhanced call graph is available directly
graph = app.enhanced_call_graph
graph.callers(fn)       # includes framework-injected callers
graph.callees(fn)       # includes framework-injected callees
graph.paths(fn_a, fn_b) # paths through enhanced graph
```

Layer 1's original call graph is preserved unchanged. The enhanced graph
is a new object that includes all Layer 1 edges plus framework edges.
Layer 1 data is never mutated.

---

## 6. Public API: WebApp

The `WebApp` object is the Semantic Layer's single entry point. All
Layer 2 capabilities are accessed through it.

### Construction

```python
from confusion_analysis.semantic import WebApp, flask_defaults

# Standard Flask analysis
idx = CodeIndex.open("/path/to/store/repos/slug/snapshot")
app = WebApp.from_index(idx, interpreters=flask_defaults())

# Extended with project-specific interpreters
app = WebApp.from_index(idx, interpreters=[
    *flask_defaults(),
    ProjectAuthInterpreter(),
    CustomORMEffectInterpreter(),
])

# Without any framework (structural exploration only)
app = WebApp.from_index(idx, interpreters=[])
```

### Domain collections

```python
app.routes                  # RouteCollection — all discovered routes
app.request_reads           # RequestReadCollection — all identified reads
app.gates                   # GateCollection — all identified gates
app.effects                 # EffectCollection — all identified effects
app.hooks                   # HookCollection — all resolved lifecycle hooks
app.context_accesses        # ContextAccessCollection — all state accesses
app.classified_mutations    # ClassifiedMutationCollection
```

Every collection supports filtering, iteration, grouping, and set
operations. Every object within is frozen and provenance-tagged.

### On-demand services

```python
app.trace_flow(source, sink)    # data-flow tracing (see section 4)
app.reachable_from(fn)          # transitive closure with framework edges
app.enhanced_call_graph         # call graph with framework-injected edges
```

### Structural passthrough

The `WebApp` delegates structural queries to the underlying `CodeIndex`
so that Layer 3 never needs to reference Layer 1 directly:

```python
app.functions       # delegates to CodeIndex.functions
app.classes         # delegates to CodeIndex.classes
app.decorators      # delegates to CodeIndex.decorators (syntactic facts)
app.imports         # delegates to CodeIndex.imports
app.cfg(function)   # delegates to CodeIndex.cfg(function)
app.source(loc)     # delegates to CodeIndex.source(location)
app.errors          # delegates to CodeIndex.errors
```

These are read-only delegations. Layer 2 cannot modify Layer 1's data
through these accessors.

### Analysis gaps

```python
app.gaps            # all analysis gaps from Layer 1 + Layer 2
app.interpreter_gaps  # gaps from interpreter execution
app.coverage        # which interpreters ran, what they found/missed
```

---

## 7. Method Branch Reconstruction

Many Flask handlers serve multiple HTTP methods in a single function
and dispatch internally:

```python
@app.route("/item", methods=["GET", "POST"])
def item():
    if request.method == "POST":
        # handle creation
        ...
    else:
        # handle display
        ...
```

The Semantic Layer reconstructs per-method code scopes from these
patterns.

### How it works

1. The `FlaskInputInterpreter` (or a dedicated branch interpreter)
   identifies conditionals that compare against `request.method`.
2. Using the CodeIndex's CFG, it maps each branch arm to a set of
   CFG blocks.
3. It produces `BranchScope` objects — one per HTTP method — that
   represent the subset of the handler's code reachable under that
   method.

### BranchScope

```python
branch = route.branch(POST)
branch.reads(...)       # reads within the POST-specific code path
branch.effects(...)     # effects within the POST-specific code path
branch.gates(...)       # gates within the POST-specific code path
branch.cfg              # CFG restricted to this branch's blocks
```

A `BranchScope` is a filtered view over the same underlying facts. It
does not duplicate data — it restricts which CFG blocks and which
observations are visible.

### Limitations

- Handlers that dispatch via dictionary lookup or MethodView are handled
  by the DispatchInterpreter, not by branch reconstruction.
- Nested method checks (`if method == "POST": if method == ...`) are
  treated as a single branch for the outermost condition.
- When the branch pattern is not recognized, `route.branch(method)`
  returns `None` and the route has no per-method scopes. This is an
  explicit gap, not a silent failure.

---

## 8. Extension Protocol

### Adding a new interpreter

Users add interpreters by passing them to `WebApp.from_index`. An
interpreter is any object that satisfies the relevant protocol.

```python
class FlaskRESTfulRouteInterpreter:
    """Recognizes Flask-RESTful Resource subclasses as routes."""

    framework = "flask-restful"

    def interpret(self, idx: CodeIndex) -> list[Route]:
        routes = []
        for cls in idx.classes.where(
            lambda c: idx.hierarchy.is_subclass(c, "flask_restful.Resource")
        ):
            for method_name in ("get", "post", "put", "patch", "delete"):
                method = cls.method(method_name)
                if method is None:
                    continue
                routes.append(Route(
                    handler=method,
                    methods=frozenset([HttpMethod[method_name.upper()]]),
                    endpoint=cls.name.lower(),
                    rule=None,  # determined by add_resource() call
                    blueprint=None,
                    provenance=InterpretationProvenance(
                        producer="flask-restful-route-interpreter",
                        evidence=[cls.location, method.location],
                    ),
                ))
        return routes
```

**Note on provenance types.** Layer 2 domain objects carry
`InterpretationProvenance` — not Layer 1's `Provenance`. The key
difference is the `evidence` field: an interpretation links back to
multiple Layer 1 source locations that collectively support the
observation. Layer 1's `Provenance` tracks a single producer and
artifact path.

### Replacing a built-in interpreter

To replace the default Flask gate interpreter with a project-specific
one, omit it from the interpreter list and supply a replacement:

```python
from confusion_analysis.semantic import flask_defaults_except

app = WebApp.from_index(idx, interpreters=[
    *flask_defaults_except("flask-gate"),
    ProjectGateInterpreter(),
])
```

The replacement interpreter receives the same `CodeIndex` and must
return the same domain types. It has full parity — there is no
capability available to the built-in that is unavailable to the
replacement.

### Composing interpreters

Interpreters can be composed. A meta-interpreter can delegate to
several sub-interpreters and merge results:

```python
class CompositeGateInterpreter:
    framework = "composite"

    def __init__(self, *children: GateInterpreter):
        self._children = children

    def interpret(self, idx: CodeIndex) -> list[Gate]:
        gates = []
        for child in self._children:
            gates.extend(child.interpret(idx))
        return gates
```

### Testing interpreters

Every interpreter can be tested in isolation. Given a `CodeIndex`
built from a fixture repo, the interpreter produces domain objects
that tests assert against:

```python
def test_flask_route_interpreter(fixture_index):
    interp = FlaskRouteInterpreter()
    routes = interp.interpret(fixture_index)
    assert len(routes) == 3
    assert routes[0].rule == "/items"
    assert routes[0].methods == frozenset([GET, POST])
```

No running web server, no Semgrep binary, no analysis store needed.
The fixture CodeIndex is constructed from a small Python source tree
processed through Layer 1.

---

## 9. Relationship to Other Layers

### What the Semantic Layer receives from Layer 1

The `CodeIndex` API. Nothing else. No JSONL files, no raw Semgrep
output, no internal storage paths. The CodeIndex provides:

- Function, class, decorator, import inventories.
- Call graph with resolution status per edge.
- CFG per function with dominance and branch structure.
- Value-flow graph with assignment, argument, return, and alias edges.
- Symbol resolution and fully-qualified names.
- Class hierarchy with MRO.
- Attribute access inventory (reads and writes on any object).
- Generic mutation inventory (structural patterns only).
- Generic dynamic dispatch inventory.
- Source text for any location.
- Errors and analysis gaps.

### What the Semantic Layer provides to Layer 3

The `WebApp` API. Nothing else. Layer 3 never imports `CodeIndex`,
never references Layer 1 types, never reads analysis store files.
The WebApp provides:

- Routes, request reads, gates, effects, hooks, context accesses,
  classified mutations — all as frozen typed domain objects.
- Enhanced call graph with framework-injected edges.
- On-demand flow tracing.
- Structural passthrough (functions, classes, CFGs) — accessed through
  WebApp, not through CodeIndex directly.
- Analysis gaps aggregated from both Layer 1 and Layer 2.

### What the Semantic Layer does NOT provide

- Security invariant evaluation.
- Vulnerability candidate construction.
- Evidence chain assembly beyond what interpreters produce as
  provenance.
- Detection rule execution or lifecycle.
- Triage, reporting, or verdict assignment.

Those capabilities belong to Layer 3.
