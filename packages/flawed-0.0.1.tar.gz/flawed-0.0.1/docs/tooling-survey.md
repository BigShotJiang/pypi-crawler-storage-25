# Python Static Analysis Tools Survey

Research date: 2026-05-16.
Purpose: evaluate off-the-shelf libraries for building a custom Python SAST
engine that extracts structural facts (functions, classes, call graphs, CFGs,
data flow, symbol resolution, class hierarchies, imports, decorators, attribute
accesses) from Python Flask codebases.

---

## 1. astroid

**What it is.** Extended Python AST library with static inference, powering
pylint. Rebuilds the stdlib `ast` tree with extra methods for type inference,
scope analysis, and name resolution.

**Relevant strengths.**
- Inference engine: `node.infer()` yields possible values/types statically.
- `ClassDef.mro()` and `ClassDef.ancestors()` for class hierarchy and MRO.
- Import resolution and module manager with caching.
- "Brain" plugins for stdlib and third-party modules (enum, dataclasses,
  typing, namedtuple, attrs).
- Inference transforms: extensible hooks to teach astroid about new patterns.
- Type constraint support (`isinstance` narrowing) in inference.

**Maintenance.** Actively maintained (pylint core dependency). v4.1.2 current,
v4.2.0 beta in progress. Pushed 2026-05-16. 575 stars, 326 forks, 206
contributors. Tidelift-funded.

**Python support.** Runs on 3.9+, understands 3.8--3.14 syntax including PEP
695 type parameters.

**Limitations.**
- Inference is best-effort: yields `Uninferable` when it cannot follow dynamic
  code. No formal soundness guarantee.
- Recursive/circular class hierarchies can trigger `RecursionError` (mitigated
  but not eliminated in v4.x).
- No CFG or call graph -- purely AST + inference.
- Tightly coupled to pylint internals; API changes between major versions.
- Single-file focus: cross-module inference works via the module manager but is
  not a full project-level type checker.

**Could replace.** Custom AST inference, MRO computation, import resolution,
decorator introspection. Strong candidate for the "enriched AST" layer.

**Compared to alternatives.** Deeper inference than raw `ast` module. Less
rigorous than pyright/mypy for type checking but more hackable from Python.
Heavier than tree-sitter for pure parsing.

---

## 2. jedi

**What it is.** Code intelligence library: autocompletion, goto-definition,
reference finding, type inference, refactoring. Used by IPython, many editors.

**Relevant strengths.**
- `Script.infer()`: follows imports and statements to resolve definitions.
- `Script.goto()`: jump to definition, including across files and into stubs.
- `Script.get_references()`: find all usages of a name.
- `Script.get_names()`: list all names in a module with scope info.
- Cross-file resolution with virtualenv/venv awareness.
- Understands type hints, stub files, dataclasses, pytest fixtures.
- Pure Python, no code execution -- safe for untrusted code.

**Maintenance.** v0.20.0 on PyPI. 6,142 stars, 530 forks. Last pushed
2026-05-01. The author is building a Rust successor (Zuban) but jedi is not
deprecated.

**Python support.** Runs on 3.10+, analyzes code from older versions.

**Limitations.**
- Designed for IDE use cases; not optimized for batch whole-project analysis.
- Intentionally stops inference on very large/complex projects to avoid hanging.
- No CFG or call graph output.
- Metaclasses partially unsupported (enums, dataclasses reimplemented
  specially).
- API is position-based (line/column), not AST-node-based -- awkward for
  building analyzers.

**Could replace.** Goto-definition resolution, cross-file name resolution,
type inference for targeted queries. Good for ad-hoc "what does this name
resolve to?" queries.

**Compared to alternatives.** More battle-tested than astroid for cross-file
resolution. Less structured output than LibCST metadata. Not designed as a
library for building analyzers -- it IS the analyzer.

---

## 3. scip-python (Sourcegraph SCIP indexer)

**What it is.** A fork of pyright that emits SCIP (Source Code Intelligence
Protocol) index files: cross-file symbol indexing with fully qualified names,
import/export monikers, and find-implementations support.

**Relevant strengths.**
- Produces stable FQN references across files and repositories.
- Built on pyright's type analysis -- high quality symbol resolution.
- Cross-repository navigation via import/export monikers.
- Find-implementations for classes and methods.

**Maintenance.** Low activity. 86 stars, 50 forks. Last pushed 2026-04-16.
Not archived but not actively developed. Node.js-based (pyright fork).

**Python support.** Inherits pyright's support (3.x, current).

**Limitations.**
- Node.js runtime required (not Python-native).
- Designed to produce index files for Sourcegraph, not a general-purpose
  library. No Python API.
- Requires full pip-installable environment for dependency resolution.
- Can hit OOM on large projects (manual `NODE_OPTIONS` tuning needed).
- Low bus factor: few maintainers, infrequent updates.

**Could replace.** Cross-file FQN resolution and symbol indexing. However, the
output format (SCIP protobuf) adds integration overhead.

**Compared to alternatives.** Pyright itself (via CLI JSON output) gives most
of the same information with better maintenance. LibCST's
FullyQualifiedNameProvider is Python-native and easier to integrate.

---

## 4. pyright / basedpyright

**What it is.** Microsoft's static type checker for Python (TypeScript/Node.js).
basedpyright is a community fork with stricter defaults, PyPI packaging (bundles
Node.js), and open-source Pylance features.

**Relevant strengths.**
- Industry-leading type inference and flow analysis.
- `--outputjson` mode: full diagnostics, inferred types, symbol info as JSON.
- Flow-sensitive type narrowing (isinstance, is None, truthiness, etc.).
- Understands decorators, descriptors, metaclasses, generics, overloads.
- ~97.8% typing spec conformance.
- basedpyright: pip-installable, no separate Node.js setup.
- LSP interface available for rich programmatic interaction.

**Maintenance.** pyright: 15,438 stars, pushed 2026-05-12, extremely active
(Microsoft). basedpyright: 3,346 stars, pushed 2026-05-17, tracks upstream
closely.

**Python support.** Analyzes Python 3.x including 3.13/3.14 features.

**Limitations.**
- Written in TypeScript, runs on Node.js -- not embeddable in Python.
- No Python API. Integration is via subprocess (CLI) or LSP protocol.
- Designed for type checking, not structural fact extraction. Getting call
  graphs or CFGs out of it is not feasible.
- JSON output is diagnostics-focused, not a structured program model.

**Could replace.** Type inference oracle: run basedpyright, parse JSON output,
use inferred types to enhance our own analysis. Cannot replace structural
extraction.

**Compared to alternatives.** Best type inference available. ty (Astral) may
surpass it on speed but is still beta. For our use case, pyright is an oracle
to query, not a framework to build on.

---

## 5. rope

**What it is.** Python refactoring library with deep code understanding:
rename, move, extract, inline, and more. Pure Python.

**Relevant strengths.**
- Full project model: `Project`, `PyCore`, modules, classes, functions.
- Name resolution and scope analysis.
- Static + optional dynamic type inference.
- Object inference system tracks attribute types across assignments.
- `AutoImport` with SQLite caching for fast import lookup.
- Understands Python packaging, relative imports, `__init__.py`.

**Maintenance.** v1.14.0 (2025-07). 2,212 stars, 184 forks. Pushed
2026-01-04. Active but slower release cadence.

**Python support.** 3.8--3.13. Most syntax up to 3.10 fully supported; 3.11+
features still catching up.

**Limitations.**
- Refactoring-focused: extracting raw structural facts requires digging into
  internal APIs (rope.base.pyobjects, rope.base.oi).
- Type inference is shallow compared to pyright/mypy.
- No CFG, call graph, or data flow graph output.
- Performance: "static analysis on all files may be very time-consuming."
- Internal APIs not guaranteed stable between versions.

**Could replace.** Name resolution and basic type inference for a
project-level model. The `rope.base` infrastructure (PyModule, PyClass,
PyFunction) provides a workable structural skeleton.

**Compared to alternatives.** Less capable for type inference than jedi or
astroid. More project-aware than astroid. The refactoring infrastructure
implies it solves many of the same problems we need (find references, resolve
names) but the API is oriented toward refactoring actions, not fact extraction.

---

## 6. LibCST

**What it is.** Concrete syntax tree parser from Meta/Instagram. Parses Python
source preserving all whitespace and comments. Ships with a metadata framework
for semantic analysis.

**Relevant strengths.**
- Lossless CST: every character of the source is represented.
- Visitor/transformer pattern for tree traversal and modification.
- **Metadata providers** (the key feature for our use case):
  - `ScopeProvider`: full scope hierarchy (Global, Class, Function,
    Comprehension), variable assignments and accesses.
  - `QualifiedNameProvider`: PEP-3155 qualified names for every reference.
  - `FullyQualifiedNameProvider`: repo-relative fully qualified names.
  - `TypeInferenceProvider`: integrates with Pyre for inferred types.
  - `ParentNodeProvider`, `PositionProvider`, `ExpressionContextProvider`.
- `FullRepoManager`: manages inter-file metadata across a whole project.
- Codemod framework for automated large-scale refactoring.
- Matcher DSL for pattern matching on CST nodes.
- Native Rust parser for performance; pre-built wheels for major platforms.

**Maintenance.** v1.8.6 (2025-11). 1,887 stars, 227 forks. Pushed 2026-01-22.
Healthy release cadence. Production-hardened at Meta scale.

**Python support.** Parses Python 3.0--3.14. Runs on 3.9+.

**Limitations.**
- Metadata is per-module by default; FullRepoManager exists but requires Pyre
  setup for TypeInferenceProvider and FullyQualifiedNameProvider.
- No CFG, call graph, or data flow analysis.
- Scope analysis does not track string-based forward references.
- QualifiedNameProvider is module-relative, not project-relative (need
  FullyQualifiedNameProvider for that).
- Heavier than ast for pure structure extraction due to whitespace tracking.

**Could replace.** Core parsing layer, scope analysis, qualified name
resolution, AST visitor infrastructure. Strong candidate for the foundational
CST/AST layer. The metadata framework is designed exactly for building custom
analyzers on top.

**Compared to alternatives.** More structured and extensible than ast/astroid
for building analysis passes. Scope/name providers go beyond tree-sitter. Less
inference capability than astroid (no value inference) but cleaner API.
Production-proven at massive scale.

---

## 7. Pyre / Pysa

**What it is.** Meta's type checker (Pyre) and static taint analyzer (Pysa).
Pysa tracks data flow from sources to sinks for security vulnerability
detection.

**Relevant strengths.**
- **Pysa** is a production taint tracker: interprocedural, source-to-sink.
- Pre-built models for Django, SQLite3, Flask (via test fixtures).
- Configurable sources, sinks, sanitizers, TITO propagation.
- Integration with LibCST for TypeInferenceProvider.
- SAPP (Static Analysis Post Processor) for exploring taint traces.
- `reveal_taint()` for debugging taint propagation.
- Written in OCaml -- high performance.

**Maintenance.** pyre-check v0.9.25 on PyPI. 7,158 stars, 451 forks. Pushed
2026-05-12. Very active (Meta internal tool).

**Python support.** Requires Python 3.8+. Primarily Linux; macOS supported.
Windows not supported.

**Limitations.**
- Requires project-level setup: `.pyre_configuration`, watchman, stub files.
- Flask models are minimal; you will write custom `.pysa` models.
- OCaml codebase -- extending the core analysis requires OCaml expertise.
- Overtainting: anything passing through an unmodeled function gets tainted.
- macOS support is secondary to Linux.
- Heavy setup overhead for small/targeted analysis tasks.

**Could replace.** Could serve as the taint analysis backend if we model Flask
sources/sinks properly. However, its "all or nothing" project setup makes it
hard to use as a library for extracting structural facts. Better as a
complementary tool that consumes our structural analysis.

**Compared to alternatives.** Only production-grade open-source Python taint
tracker available. Semgrep does pattern-based taint; Pysa does interprocedural
data flow. They are complementary, not competing.

---

## 8. py2cfg

**What it is.** Control flow graph generator for Python 3. Produces CFGs
visualizable with graphviz.

**Relevant strengths.**
- Generates intra-procedural CFGs from Python source.
- Simple API: `CFGBuilder().build_from_file(name, path)`.
- Graphviz output for visualization.

**Maintenance.** v1.0.5 on PyPI. Appears to be a fork/evolution of staticfg.
Limited GitHub presence. Documentation at py2cfg.readthedocs.io.

**Python support.** Python 3.

**Limitations.**
- Visualization-oriented, not analysis-oriented. CFG data structures may be
  too simple for data flow analysis.
- No inter-procedural CFG support.
- Small project with uncertain long-term maintenance.
- No integration with other analysis tools.

**Could replace.** Basic CFG generation. However, for a SAST engine we need
richer CFG nodes (with expression-level detail, not just statement-level).

**Compared to alternatives.** Equivalent to staticfg (likely derived from it).
Scalpel includes CFG generation with more features. For production use, we
would likely need our own CFG builder or use Scalpel's.

---

## 9. staticfg

**What it is.** Python 3 control flow graph generator. The predecessor to
py2cfg.

**Relevant strengths.**
- `CFGBuilder().build_from_file()` API.
- Designed explicitly for static analysis use (hence the name).
- Graphviz visualization.

**Maintenance.** v0.9.5 on PyPI. 215 stars, 38 forks. Last pushed 2022-08.
**Effectively unmaintained** -- no commits in 4 years.

**Python support.** Python 3. No recent Python version testing.

**Limitations.**
- Unmaintained since 2022.
- Statement-level CFG only.
- No exception handling edges, no generator/async support.

**Could replace.** Nothing that py2cfg or a custom implementation cannot do
better.

**Compared to alternatives.** Superseded by py2cfg. Scalpel's CFG module is
more capable.

---

## 10. PyCG

**What it is.** Static Python call graph generator. Academic origin (ICSE '21).
Handles modules, generators, closures, multiple inheritance.

**Relevant strengths.**
- Whole-program static call graph generation.
- High precision (~99.2%) on micro-benchmarks.
- No dependencies, lightweight.
- JSON output format.

**Maintenance.** **Archived.** Last pushed 2023-11. 365 stars, 72 forks.
No further development planned.

**Python support.** Python 3.4+. No updates for 3.12+ syntax.

**Limitations.**
- Archived and unmaintained.
- Flow-insensitive: ignores control flow, leading to false positives.
- Does not scale to large programs (>2K LOC can trigger OOM).
- Does not fully support context managers, built-in types.
- Recall is only ~69.9% -- misses many real call edges.

**Could replace.** Basic call graph generation, but only for small codebases.
For Flask apps of any size, the scaling limitations are disqualifying.

**Compared to alternatives.** JARVIS (successor) is 84% more precise and 67%
faster. Pyan3 is actively maintained and handles larger codebases. Scalpel
wraps PyCG but adds its own improvements.

---

## 11. NetworkX

**What it is.** The standard Python graph library. Creation, manipulation, and
analysis of complex networks.

**Relevant strengths.**
- Comprehensive graph algorithms: shortest paths, centrality, community
  detection, connectivity, flow, DAG operations, topological sort.
- DiGraph, MultiDiGraph for directed graphs with parallel edges.
- Reachability analysis, transitive closure, strongly connected components.
- 80M+ monthly downloads. 16,916 stars. Extremely well-documented.
- GPU acceleration via cuGraph backend. Parallel backend via nx-parallel.

**Maintenance.** v3.6.1 stable, v3.7 in development. Pushed 2026-05-14.
Extremely active. Funded development (BIDS retreat, NSF grants).

**Python support.** Python 3.10+.

**Limitations.**
- General-purpose graph library, not code-analysis-specific.
- No understanding of Python code -- we build the graph, it operates on it.
- In-memory only for standard backend. Large call graphs need care.

**Could replace.** The graph data structure and algorithm layer. Use it to
store and query call graphs, import graphs, class hierarchies, control flow
graphs. All graph algorithms we need (reachability, SCC, dominators,
topological sort) are built in.

**Compared to alternatives.** No real competitor for this role in Python. igraph
is faster for very large graphs but less Pythonic.

---

## 12. tree-sitter (with Python grammar)

**What it is.** Incremental parsing library (Rust/C core) with Python bindings
(`py-tree-sitter`) and a Python grammar (`tree-sitter-python`).

**Relevant strengths.**
- Extremely fast parsing: handles thousands of files in seconds.
- Incremental: re-parses only changed regions.
- Error-tolerant: produces a tree even for syntactically broken files.
- Query language (S-expression patterns) for structural matching.
- Concrete syntax tree preserving all tokens.
- Pre-built wheels, no build dependencies.

**Maintenance.** tree-sitter: 25,394 stars, pushed 2026-05-16. py-tree-sitter:
1,429 stars, pushed 2026-04-24. tree-sitter-python: 548 stars, pushed
2025-09-15. All very active.

**Python support.** Grammar covers Python 3.x. Bindings run on 3.8+.

**Limitations.**
- No semantic analysis: no scopes, no type inference, no name resolution.
- CST nodes are generic (identified by type string), not typed Python objects.
- Query language is pattern-based, not semantic -- like Semgrep but lower-level.
- Version compatibility between CLI, bindings, and grammar can be fragile.

**Could replace.** Fast initial parsing pass, especially for screening large
corpora. Good for structural pattern matching (find all `@app.route` decorators,
all `request.args` accesses) without needing full semantic analysis.

**Compared to alternatives.** Faster than LibCST or ast for pure parsing. Less
semantic than either. Complementary: use tree-sitter for fast screening, LibCST
for deep analysis.

---

## 13. vulture

**What it is.** Dead code detector for Python. Finds unused functions, classes,
variables, imports, and unreachable code.

**Relevant strengths.**
- Confidence-scored results (60--100%).
- Detects unreachable code after return/break/continue/raise.
- Detects unsatisfiable if/while conditions.
- Whitelisting mechanism for false positives.
- Sort by size for prioritizing cleanup.

**Maintenance.** v2.16 on PyPI. 4,607 stars, 185 forks. Pushed 2026-04-30.
Healthy.

**Python support.** Python 3.8+.

**Limitations.**
- Designed for dead code detection, not general structural analysis.
- High false positive rate on framework code (Flask, Django) where functions
  are called dynamically.
- Does not build a call graph or data flow model -- uses name matching.

**Could replace.** Reachability screening pass: identify definitely-dead code
to prune from analysis. However, for Flask apps specifically, the false
positive rate on route handlers and plugin hooks makes it less useful.

**Compared to alternatives.** Skylos claims fewer false positives for
framework code. For our use case, a call-graph-based reachability analysis
(using our own engine) would be more accurate.

---

## 14. importlab

**What it is.** Google library for computing Python import dependency graphs.
Topological sorting of files by import order, cycle detection.

**Relevant strengths.**
- Computes import graph from Python source files.
- Topological ordering for dependency-ordered processing.
- Cycle detection.
- Used internally by pytype.

**Maintenance.** **Archived.** v0.8.1 on PyPI, last pushed 2024-05-03.
179 stars. No updates in 2+ years.

**Python support.** Python 3.6+.

**Limitations.**
- Archived and unmaintained.
- Very basic: only computes import ordering, not symbol-level resolution.
- Depends on networkx>=2.
- pytype (its primary consumer) is being sunset by Google.

**Could replace.** Import graph computation and topological sorting. However,
this is straightforward to implement ourselves with ast + networkx, and the
archived status makes it a liability.

**Compared to alternatives.** LibCST's FullyQualifiedNameProvider plus our own
import graph builder would be more reliable and integrated.

---

## Additional tools discovered

### Scalpel (SMAT-Lab)

**What it is.** Academic Python static analysis framework combining CFGs, call
graphs, SSA, alias analysis, type inference, and FQN resolution.

**Relevant strengths.** Closest to a "batteries included" Python analysis
framework. Provides CFG construction, SSA form, call graphs (wraps PyCG),
fully qualified name inference, type inference via backward data flow, and
import graph construction.

**Maintenance.** v0.8.2 on PyPI. 329 stars, 46 forks. Last commit 2024-03.
Still in beta. **Low activity** -- no commits in over 2 years.

**Limitations.** Beta quality, academic project, uncertain maintenance.
Wraps PyCG for call graphs (inheriting its limitations). Documentation is
sparse.

**Verdict.** Interesting as a reference implementation and for ideas, but too
immature and unmaintained for production use.

### Pyan3

**What it is.** Static call dependency graph generator. Determines call
relationships between functions and methods via static analysis.

**Maintenance.** v2.6.0 on PyPI. 417 stars, 74 forks. Pushed 2026-05-06.
Actively maintained. Supports Python 3.10--3.14.

**Strengths.** Depth-controlled graph output (module/class/function/method),
confidence scoring on edges, multiple output formats (dot, json, etc.).

**Limitations.** Shallow analysis (two-pass linear scan). Limited type
inference. Cannot resolve dynamic dispatch or metaclass-generated methods.

**Verdict.** Useful for quick call graph visualization. Too shallow for
SAST-grade analysis.

### JARVIS

**What it is.** Academic successor to PyCG. Flow-sensitive, application-centered
call graph construction using function-scoped type graphs.

**Strengths.** 84% higher precision than PyCG, 20%+ higher recall, 67% faster.
Flow-sensitive analysis with strong updates.

**Maintenance.** Academic paper (arXiv 2305.05949, v5 Sept 2024). No PyPI
package found. Research prototype.

**Verdict.** Best published call graph results for Python, but not
production-ready. Worth monitoring.

### ty (Astral)

**What it is.** Rust-based Python type checker and language server from Astral
(Ruff/uv creators). Beta released Dec 2025.

**Strengths.** 10--60x faster than mypy/pyright. Incremental architecture.
Use-def chains, scope analysis, symbol tables built internally. 18,654 stars.

**Limitations.** 0.0.x versioning, unstable API. No Python bindings or library
API -- CLI and LSP only. Stable 1.0 targeted for 2026.

**Verdict.** Future type inference oracle (faster than pyright). Not usable as
a library today. Worth tracking for CLI-based type queries.

### pytype (Google)

**What it is.** Google's type inference tool. Unique flow-based analysis
across function boundaries.

**Maintenance.** **Being sunset.** Python 3.12 is the last supported version.

**Verdict.** Do not adopt. Deprecated.

---

## Synthesis: recommendations

### Recommended architecture

```
Layer 1: Parsing
  tree-sitter  -- fast screening of large corpus
  LibCST       -- deep CST for files that pass screening

Layer 2: Semantic enrichment
  LibCST metadata (ScopeProvider, QualifiedNameProvider,
                   FullyQualifiedNameProvider)
  astroid      -- value inference, MRO, decorator introspection
  basedpyright -- type oracle via CLI JSON output

Layer 3: Graph construction (our code)
  Call graph builder    -- built on LibCST + astroid resolution
  CFG builder           -- built on LibCST CST nodes
  Import graph builder  -- built on LibCST FQN + ast
  Class hierarchy graph -- built on astroid MRO

Layer 4: Graph analysis
  NetworkX     -- all graph algorithms

Layer 5: Taint / security analysis
  Pysa         -- complementary interprocedural taint (when configured)
  Our engine   -- custom Flask-aware taint rules using Layers 1-4
```

### Tool-by-tool verdict

| Tool | Verdict | Role |
|------|---------|------|
| **LibCST** | ADOPT | Core parsing + scope/name resolution layer |
| **astroid** | ADOPT | Value inference, MRO, decorator analysis |
| **NetworkX** | ADOPT | Graph storage and algorithms |
| **basedpyright** | USE AS ORACLE | Type inference via CLI subprocess |
| **tree-sitter** | ADOPT | Fast screening parser for corpus-scale work |
| **Pyre/Pysa** | EVALUATE | Complementary taint analysis (heavy setup) |
| **jedi** | CONSIDER | Ad-hoc name resolution queries; not core |
| **Pyan3** | SKIP | Too shallow for SAST; use our own call graph |
| **rope** | SKIP | Refactoring-focused; internal APIs unstable |
| **scip-python** | SKIP | Low maintenance, Node.js, niche output format |
| **PyCG** | SKIP | Archived, does not scale |
| **py2cfg** | SKIP | Too basic for production CFG needs |
| **staticfg** | SKIP | Unmaintained, superseded |
| **vulture** | SKIP | High FP on Flask; we can do better with call graph |
| **importlab** | SKIP | Archived; trivial to replicate with ast + networkx |
| **Scalpel** | REFERENCE | Good ideas, beta quality, stale |
| **JARVIS** | MONITOR | Best call graph results, not production-ready |
| **ty** | MONITOR | Future type oracle, still 0.0.x |

### Key insight

No single tool covers all our needs. The productive path is a layered
architecture: **LibCST for parsing and scope analysis**, **astroid for
inference**, **basedpyright as a type oracle**, and **NetworkX for graph
operations**. We build the call graph, CFG, and data flow layers ourselves,
using these tools as foundations rather than trying to extract what we need from
a tool designed for a different purpose.

The only existing tool that attempts to be a complete Python analysis framework
(Scalpel) is unmaintained and beta. This confirms that building our own engine
on top of solid libraries is the right approach.

### Sources

- [astroid](https://github.com/pylint-dev/astroid) -- [docs](https://pylint.pycqa.org/projects/astroid/en/latest/) -- [PyPI](https://pypi.org/project/astroid/)
- [jedi](https://github.com/davidhalter/jedi) -- [docs](https://jedi.readthedocs.io/) -- [PyPI](https://pypi.org/project/jedi/)
- [scip-python](https://github.com/sourcegraph/scip-python) -- [blog](https://sourcegraph.com/blog/scip-python)
- [pyright](https://github.com/microsoft/pyright) -- [basedpyright](https://github.com/DetachHead/basedpyright) -- [PyPI](https://pypi.org/project/basedpyright/)
- [rope](https://github.com/python-rope/rope) -- [docs](https://rope.readthedocs.io/) -- [PyPI](https://pypi.org/project/rope/)
- [LibCST](https://github.com/Instagram/LibCST) -- [docs](https://libcst.readthedocs.io/) -- [PyPI](https://pypi.org/project/libcst/)
- [Pyre/Pysa](https://github.com/facebook/pyre-check) -- [docs](https://pyre-check.org/docs/pysa-basics/) -- [PyPI](https://pypi.org/project/pyre-check/)
- [py2cfg](https://pypi.org/project/py2cfg/) -- [docs](https://py2cfg.readthedocs.io/)
- [staticfg](https://github.com/coetaur0/staticfg)
- [PyCG](https://github.com/vitsalis/PyCG) -- [paper](https://arxiv.org/abs/2103.00587)
- [NetworkX](https://github.com/networkx/networkx) -- [docs](https://networkx.org/documentation/stable/) -- [PyPI](https://pypi.org/project/networkx/)
- [tree-sitter](https://github.com/tree-sitter/tree-sitter) -- [py-tree-sitter](https://github.com/tree-sitter/py-tree-sitter) -- [Python grammar](https://github.com/tree-sitter/tree-sitter-python)
- [vulture](https://github.com/jendrikseipp/vulture) -- [PyPI](https://pypi.org/project/vulture/)
- [importlab](https://github.com/google/importlab) -- [PyPI](https://pypi.org/project/importlab/)
- [Scalpel](https://github.com/SMAT-Lab/Scalpel) -- [docs](https://python-scalpel.readthedocs.io/) -- [paper](https://arxiv.org/pdf/2202.11840)
- [Pyan3](https://github.com/Technologicat/pyan) -- [PyPI](https://pypi.org/project/pyan3/)
- [JARVIS](https://pythonjarvis.github.io/) -- [paper](https://arxiv.org/abs/2305.05949)
- [ty](https://github.com/astral-sh/ty) -- [docs](https://docs.astral.sh/ty/) -- [blog](https://astral.sh/blog/ty)
- [pytype](https://github.com/google/pytype) -- [sunset notice](https://pydevtools.com/blog/google-sunsets-pytype-the-end-of-an-era-for-python-type-checking/)
