# Design Principles

## 1. Vision

This project is a standalone analysis engine for researching confusion
vulnerabilities in Python web applications. The engine builds a queryable,
versioned knowledge base for each repository snapshot. Rule authors write
detection logic in ordinary Python against a typed API, without understanding
static analysis internals.

The engine has three layers:

| Layer | Name | Runs | Knows about |
|-------|------|------|-------------|
| 1 | **Code Index** | Once per repo snapshot | Python language structure |
| 2 | **Semantic Layer** | Per detection execution | Frameworks, libraries, conventions |
| 3 | **Rule API** | Per detection execution | Vulnerability patterns, security invariants |

The Code Index extracts structural facts from Python source code. It knows
nothing about Flask, SQLAlchemy, or any other framework. It runs once per
repository snapshot and produces durable artifacts behind a typed Python API.

The Semantic Layer interprets those structural facts through framework-specific
models. It identifies routes, request inputs, security gates, side effects,
and lifecycle hooks. It runs on every detection execution. Rule authors and
library maintainers can replace, extend, or compose its interpreters without
re-running extraction.

The Rule API provides the vocabulary for writing detection rules and
exploring codebases interactively. It consumes the Semantic Layer and exposes
typed domain objects, composable queries, control-flow reasoning, and
evidence-building primitives.

## 2. Non-Negotiable Principles

### 2.1 Framework Knowledge Lives in the Semantic Layer

The Code Index must not contain framework-specific, library-specific, or
convention-specific logic. Flask route patterns, SQLAlchemy ORM calls,
marshmallow parsers, session proxies, `g` attributes, and all similar
framework-derived concepts belong exclusively in the Semantic Layer.

The test: if a fact requires knowing that `request.args` is a query-string
container, or that `@app.route` registers an HTTP endpoint, or that
`db.session.commit()` is a database write, it is framework knowledge and must
not exist in the Code Index.

### 2.2 Extensibility Without Re-Extraction

Adding support for a new framework, library, or project convention must never
require re-running the Code Index. Fixing a false negative in route
detection, expanding request-input coverage, or recognizing a new ORM pattern
must never require re-running the Code Index.

User-supplied extensions operate with full parity to built-in defaults. There
is no privileged fast path for shipped interpreters that user-supplied
interpreters cannot access.

### 2.3 Strict Unidirectional Layering

Dependencies flow in exactly one direction: Rule API depends on Semantic
Layer, Semantic Layer depends on Code Index. No reverse dependencies. No
skipping.

The Rule API must not import from or query the Code Index directly. The
Semantic Layer must not reference the Rule API. The Code Index must not
reference either layer above it.

### 2.4 Facts and Rules Are Separate

The Code Index extracts stable structural facts. The Semantic Layer
interprets those facts through framework models. The Rule API evaluates
security invariants against interpreted observations. Each concern has one
owner, and the boundaries between them are enforced by API contracts.

Extraction is conservative and durable. Interpretation is dynamic and
iterable. Detection is fast and hypothesis-driven.

### 2.5 Non-Leaky Abstractions

Each layer speaks the vocabulary of its consumers:

- The Code Index speaks in functions, classes, call edges, CFG blocks,
  decorators, assignments, attribute accesses, and source locations.
- The Semantic Layer speaks in routes, request inputs, security gates,
  effects, lifecycle hooks, and application-state containers.
- The Rule API speaks in invariants, evidence, candidates, confusion
  patterns, and missing-evidence records.

No layer exposes its internal storage format, file layout, or implementation
data structures to its consumers. Errors translate at boundaries into the
consuming layer's taxonomy.

### 2.6 Atomic Fact Builders

Every fact builder in the Code Index detects exactly one kind of structural
observation. It emits exactly one fact kind. It avoids vulnerability
semantics. It avoids joining unrelated concepts. It preserves source
locations and provenance. It fails independently without invalidating
unrelated builders.

### 2.7 Graceful Degradation

The engine remains useful when any single analysis tool is incomplete.
Semgrep may miss dynamic behavior. Python AST may miss import resolution.
astroid may fail inference. CFG builders may fail on unsupported syntax.

The engine handles this by keeping all facts provenance-rich, recording
unresolved reasons and missing evidence explicitly, recording parse and
extraction errors as artifacts, and returning `insufficient_evidence` instead
of fabricating certainty.

The engine never fails open. Missing analysis is never silently interpreted
as proof that a code path is safe.

### 2.8 No Overpromising

A layer must not claim to provide a capability it cannot deliver reliably.
If the Code Index cannot identify all request inputs without framework
knowledge, it must not ship a partial request-input extractor and call it
complete. Instead, it provides the structural facts (call sites, attribute
accesses, symbol resolution) and the Semantic Layer uses framework models to
classify them.

This applies recursively. If a Semantic Layer interpreter cannot recognize
all SQLAlchemy patterns, it must declare what it covers and record gaps for
what it does not.

### 2.9 Raw Artifacts Preserved, Normalized Facts Exported

Tool output is not the public API. Raw Semgrep JSON, raw text dumps, and
raw AST walker outputs are preserved for audit and debugging. Downstream
layers consume typed Python objects through the owning layer's API.

No consumer above the Code Index should parse JSONL files, read raw Semgrep
output, or access the file system layout of the analysis store.

### 2.10 No Premature Database Monoculture

The engine uses multiple storage forms because they serve different roles.
Raw files for auditability. JSONL for per-repo facts. JSON for manifests.
SQLite for operational state. DuckDB and Parquet for cross-repo analytics.
NetworkX for in-memory graph exploration.

No single storage backend is mandated. Storage decisions are encapsulated
behind API boundaries and can change without affecting consumers.

## 3. API Design Principles

These apply to all three layers.

### 3.1 Tell, Don't Ask

Behavior lives with the object that owns the relevant state. The Code Index
owns reachability; consumers ask it for transitive closures, not for raw
edge lists to walk themselves. The Semantic Layer owns route identification;
consumers ask for routes, not for decorator lists to classify themselves.

Carve-out: pure read accessors are legitimate when consumers need to display,
serialize, or transmit values.

### 3.2 Law of Demeter

A method may use: itself, its parameters, objects it constructs, and its
direct fields. Reaching through returned objects to strangers is prohibited.

Designed-for-chaining surfaces (scoped queries, collection filters, fluent
builders) are not Demeter violations. Each step returns the same conceptual
receiver. The violation is reaching across object identities into someone
else's internals.

### 3.3 Single Source of Truth

Every concern has exactly one owner. All access goes through the owner's
API. The ban on raw access is structural (module boundaries, import
restrictions), not conventional.

Data crossing out of a layer is deeply immutable: frozen dataclasses,
immutable sequences, or structural snapshots. Mutability the owner cannot
observe is a defect.

### 3.4 Make Illegal States Unrepresentable

Use typed atoms for every ambiguous concept. `POST` not `"POST"`. `Query("id")`
not `"request.args"`. `Fn.named("authorize")` not a raw string. Distinct types
for distinct concepts even when they share a primitive representation.

Where the type system cannot prevent an invalid state, the constructing
layer's factories validate and reject impossible records.

### 3.5 Parse at the Boundary

Inputs are converted into typed, trusted values at the point they cross a
layer boundary. Inside the trusted region, invariants hold by construction.
No re-validation deep in the system.

### 3.6 Composability Over Feature Accumulation

Small, focused operations that combine cleanly beat large operations with
many parameters. The API provides composable primitives that rule authors
assemble. Vulnerability-shaped helpers that collapse detection logic into
opaque calls are prohibited.

### 3.7 Consistency Over Cleverness

The same concept uses the same name and pattern everywhere. Collections and
scopes use a uniform query vocabulary. A reader who learns one module's
idioms can predict another module's idioms.

### 3.8 Defaults Bias Toward Safety

Where an API has a default, the default is the conservative one. Missing
evidence produces explicit gaps, not silent omissions. Incomplete
interpretation produces declared coverage boundaries, not false confidence.

### 3.9 Minimal Surface Area

Every exposed symbol is a contract. Start private. Promote only what
consumers actually need, and only when they need it. Prefer many small
focused interfaces over one large interface.

## 4. Explicit Non-Goals

### 4.1 Performance Optimization

Performance is not a design constraint at this stage. Correctness,
verifiability, clarity, and simplicity take absolute precedence. Caching and
pre-computation are future concerns that must not compromise architectural
clarity.

### 4.2 Backwards Compatibility

No existing API, schema, contract, or file format is sacred. Any component
can be rewritten, replaced, or restructured. Design for the right answer,
not for migration convenience.

### 4.3 Incremental Repository Tracking

Repositories are immutable snapshots. There is no git fetch, branch
switching, or differential re-analysis. If the source changes, the Code
Index runs from scratch. Optimizations for incremental analysis are out of
scope and considered harmful as premature optimization.

### 4.4 CI/CD Integration

This engine is a research tool for application security analysis across
600+ real-world repositories. It is not a CI/CD gate, a commit hook, or a
developer-facing linter.

## 5. Repository Boundary

### 5.1 Owned by This Repository

- Code Index extractors, normalizers, and the typed Python API over their
  outputs.
- Semantic Layer framework interpreters, model libraries, and the typed
  Python API exposing interpreted domain objects.
- Rule API domain objects, query surfaces, evidence builders, and the
  detector framework.
- Detection rule implementations.
- Fixture suites for all three layers.
- Local CLI for extraction, interpretation, detection, and reporting.

### 5.2 Not Owned by This Repository

- GitHub discovery, corpus membership, repo cloning, sync policy.
- Remote execution, SSH supervision, sandbox management.
- Those capabilities are consumed through narrow external interfaces.

### 5.3 Tool Boundary Rule

New tooling belongs here only if it directly improves extraction,
interpretation, detection, or reporting. Repeated operational hurdles become
separate utilities when they are useful beyond this engine.
