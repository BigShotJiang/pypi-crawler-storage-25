# Rule API (Layer 3)

User-facing surface for writing detection rules and exploring analyzed
codebases interactively. Consumes Layer 2 (Semantic Layer) exclusively.
Never imports Layer 1 (Code Index) types or reads raw analysis
artifacts.

Rule authors are Python developers who understand the web application
code they are securing. They are not static analysis experts. The API
speaks their vocabulary: routes, request inputs, conditional guards,
database writes, control-flow ordering, and evidence chains.

Python type contracts for this API live in `src/flawed/`.
They are strictly typed, mypy-strict-clean, and ruff-clean.

---

## Entry Point

```python
from flawed import open_repo

kb = open_repo("/path/to/analysis-store/repos/slug/snapshot")
```

`open_repo` constructs a `CodeIndex` (Layer 1), runs the Semantic
Layer interpreters (Layer 2), and returns a `RepoView` -- the single
entry point for all navigation and detection.

`RepoView` provides:

```python
kb.routes       # RouteCollection -- all identified HTTP endpoints
kb.functions    # FunctionCollection -- every function in the repo
kb.classes      # ClassCollection -- every class in the repo
kb.trace_flow(source_loc, sink_loc)  # on-demand data-flow tracing
```

---

## Detector Format

A detector is a Python generator function decorated with `@detector`.

### Per-route detector

The most common form. Iterates over routes and yields findings:

```python
from collections.abc import Iterator

from flawed import detector, open_repo
from flawed.route import POST, Route, accepting
from flawed.inputs import PathParam, Form, Json, AnyOf
from flawed.effects import Mutation
from flawed.evidence import Finding

@detector("path-guard-body-write")
def detect(kb: "RepoView") -> Iterator[Finding]:
    """Path parameter guards a write whose target comes from body."""
    for route in kb.routes.where(accepting(POST)):
        for path_read in route.reachable.reads(PathParam()):
            for body_read in route.reachable.reads(AnyOf((Form(), Json()))):
                for effect in route.reachable.effects(Mutation.write()):
                    if effect.target is None:
                        continue
                    if not body_read.value.flows_to(effect.target):
                        continue
                    for guard in route.reachable.conditions_using(path_read.value):
                        if route.body.cfg.dominates(guard.location, effect.location):
                            yield (
                                route.finding("Path ID guards write, body ID flows to target")
                                .evidence(path_read, "Authorization uses path parameter")
                                .evidence(body_read, "Write target from body parameter")
                                .evidence(guard, "Guard condition uses path value")
                                .evidence(effect, "Data write")
                            )
```

### Repo-wide detector

For rules that audit configuration, middleware patterns, or cross-route
relationships:

```python
@detector("method-gated-auth")
def detect(kb: "RepoView") -> Iterator[Finding]:
    """Auth check conditional on HTTP method -- mutation in unguarded branch."""
    for route in kb.routes.where(accepting(POST)):
        for cond in route.body.conditions():
            if cond.operator not in ("==", "!="):
                continue
            if cond.true_branch.effects(Mutation.any()) and not cond.false_branch.effects(Mutation.any()):
                yield route.finding("Mutation only in one method branch").evidence(
                    cond, "Method-conditional branch"
                )
```

### Cross-layer detector

Examines the full request handling stack including middleware and hooks:

```python
from flawed.effects import Session

@detector("stale-context-after-failed-auth")
def detect(kb: "RepoView") -> Iterator[Finding]:
    """Context write before auth check -- survives on auth failure."""
    for route in kb.routes:
        stack = route.full_stack
        for ctx_write in stack.effects(Session.write()):
            for cond in stack.conditions():
                if cond.error_branch is None:
                    continue
                if stack.cfg.precedes(ctx_write.location, cond.location):
                    yield (
                        route.finding("Context written before auth -- survives on failure")
                        .evidence(ctx_write, "Context/session write")
                        .evidence(cond, "Condition with error branch")
                    )
```

---

## Domain Objects

All domain objects are frozen dataclasses with provenance.

### Route

| Field | Type | Description |
|-------|------|-------------|
| `endpoint` | `str` | Framework endpoint name |
| `url_rule` | `str` | URL rule pattern |
| `methods` | `frozenset[HttpMethod]` | Accepted HTTP methods |
| `handler` | `Function` | The handler function |
| `blueprint` | `str \| None` | Blueprint name, if any |
| `location` | `Location` | Registration site |
| `provenance` | `InterpretationProvenance` | Supporting facts |

| Property / Method | Returns | Description |
|-------------------|---------|-------------|
| `.body` | `CodeScope` | Handler function body |
| `.reachable` | `CodeScope` | Transitively reachable code from handler |
| `.full_stack` | `CodeScope` | Including lifecycle hooks and middleware |
| `.branch(method)` | `CodeScope \| None` | Code scope for one HTTP method branch |
| `.finding(summary)` | `Finding` | Start building a detection finding |

### Function

| Field | Type | Description |
|-------|------|-------------|
| `fqn` | `str` | Fully qualified name |
| `name` | `str` | Short name |
| `file` | `str` | Source file path |
| `line` | `int` | Start line |
| `params` | `tuple[Parameter, ...]` | Parameters with names, annotations, defaults |
| `kind` | `FunctionKind` | `TOP_LEVEL`, `METHOD`, `NESTED`, `LAMBDA`, `CLOSURE` |
| `parent_class` | `str \| None` | FQN of enclosing class |
| `parent_function` | `str \| None` | FQN of enclosing function |

| Property / Method | Returns | Description |
|-------------------|---------|-------------|
| `.decorators` | `DecoratorCollection` | Applied decorators |
| `.body` | `CodeScope` | Direct function body |
| `.reachable` | `CodeScope` | Transitively reachable code |
| `.called_by` | `FunctionCollection` | Functions that call this one |
| `.calls` | `FunctionCollection` | Functions this one calls |

### InputRead

| Field | Type | Description |
|-------|------|-------------|
| `source` | `InputSource` | Typed source (`Query`, `Form`, etc.) |
| `access_pattern` | `AccessPattern` | `GET`, `SUBSCRIPT`, `GETLIST`, etc. |
| `cardinality` | `Cardinality` | `SINGLE`, `MULTI`, `UNKNOWN` |
| `function` | `Function` | Containing function |
| `location` | `Location` | Source location |
| `.value` | `ValueHandle` | Handle for tracking through the program |

### Effect

| Field | Type | Description |
|-------|------|-------------|
| `category` | `EffectCategory` | Category from the taxonomy |
| `function` | `Function` | Containing function |
| `location` | `Location` | Source location |
| `.target` | `ValueHandle \| None` | What is being written to |
| `.value` | `ValueHandle \| None` | What value is being written |

### Condition

| Field | Type | Description |
|-------|------|-------------|
| `expression` | `str` | Source text of the condition |
| `location` | `Location` | Source location |
| `.operator` | `str` | `==`, `!=`, `in`, `not in`, etc. |
| `.true_branch` | `CodeScope` | Code reachable when true |
| `.false_branch` | `CodeScope` | Code reachable when false |
| `.error_branch` | `CodeScope \| None` | Branch leading to error/raise |
| `.pass_branch` | `CodeScope \| None` | Branch continuing normal flow |

### CallSite

| Field | Type | Description |
|-------|------|-------------|
| `target` | `Function \| None` | Called function (None if unresolved) |
| `arguments` | `tuple[Argument, ...]` | Positional and keyword arguments |
| `location` | `Location` | Source location |
| `.return_value` | `ValueHandle` | Handle for the call's return value |

---

## Input Sources

| Type | Meaning | Constructor |
|------|---------|-------------|
| `Query` | Query string parameter | `Query(key="user_id")` |
| `Form` | Form-encoded body field | `Form(key="amount")` |
| `Json` | JSON body field | `Json(path="$.restaurant_id")` |
| `Header` | HTTP header | `Header(name="X-Api-Key")` |
| `Cookie` | Cookie value | `Cookie(name="session")` |
| `PathParam` | URL path parameter | `PathParam(name="id")` |
| `SessionKey` | Server-side session value | `SessionKey(key="user_id")` |
| `FileUpload` | Uploaded file | `FileUpload(field="avatar")` |
| `RawBody` | Raw request body | `RawBody()` |
| `AnyContainer` | Any container with this key | `AnyContainer(key="id")` |
| `AnyOf` | Union of sources | `AnyOf(sources=(Form(), Json()))` |

When no key is provided, an input source matches any read from that
container type. All input sources are frozen dataclasses inheriting
from `InputSource`.

---

## Effects

Single `category` field. Sugar namespaces compose with `|`.

| Category | Meaning |
|----------|---------|
| `DATA_WRITE` | Database insert or update |
| `DATA_DELETE` | Database delete |
| `DATA_READ` | Database read (query-then-act) |
| `SESSION_WRITE` | Session mutation |
| `CONTEXT_WRITE` | Application context mutation |
| `OUTBOUND_REQUEST` | HTTP call to external service |
| `FILE_WRITE` | Filesystem write |
| `NOTIFICATION` | Email, SMS, push notification |

```python
from flawed.effects import Mutation, Session, Outbound

Mutation.any()               # DATA_WRITE or DATA_DELETE
Mutation.write()             # DATA_WRITE only
Session.write()              # SESSION_WRITE (any key)
Session.write(key="email")   # SESSION_WRITE to specific key
Outbound.request()           # OUTBOUND_REQUEST

# Compose with |
effects = route.reachable.effects(Mutation.any() | Session.write())
```

---

## Checks

Composable selectors for security-relevant validation functions,
defined in `src/flawed/checks.py`. Parallel to effects -- select by
function FQN or name pattern.

```python
from flawed.checks import Crypto, Token, Schema, Permission
from flawed.calls import Fn

Crypto.compare()             # hmac.compare_digest, check_password_hash, etc.
Crypto.hash()                # hashlib.sha256, hashlib.pbkdf2_hmac, etc.
Token.verify()               # jwt.decode, itsdangerous loads, etc.
Schema.validate()            # pydantic, marshmallow, wtforms, cerberus, etc.
Permission.check()           # has_permission, authorize, etc. (name heuristic)
Permission.require()         # require_permission, require_role, etc.

# Compose checks with effects
VALIDATORS = Crypto.compare() | Token.verify()
SENSITIVE  = Mutation.any() | Session.write()
validators = route.reachable.calls(VALIDATORS).with_argument_from(read.value)
```

---

## Control Flow

Accessed through `scope.cfg`. Answers ordering and dominance questions.

```python
cfg = route.body.cfg

cfg.dominates(a, b)          # every path to b passes through a
cfg.precedes(a, b)           # a executes before b on all paths
cfg.ordered(a, b, c)         # a, b, c appear in this order on all paths
cfg.reachable_between(a, b)  # any execution path from a to b exists
```

`route.body.cfg` is intra-procedural (single function).
`route.reachable.cfg` is interprocedural (when available).

---

## Value Flow

`ValueHandle` tracks how values propagate. Available on `InputRead.value`,
`Effect.target`, `Effect.value`, `CallSite.return_value`, `Argument.value`,
and `Condition.left`/`.right`.

```python
read.value.flows_to(effect.target)      # does read reach the effect?
call.return_value.flows_to(effect.target)
effect.target.derived_from(PathParam())  # traced back to input source?
```

Automatic tracing instruments every query during rule execution for
debugging false positives and negatives.

---

## What Changed From L5

1. **No Gate type.** Replaced by composable structural primitives:
   decorator presence, conditional analysis with branch scoping,
   value-flow through conditions.

2. **No `@for_routes` or `@invariant`.** Route iteration is explicit
   Python.

3. **Simplified effects.** Single `category` field. Sugar namespaces
   compose with `|`.

4. **CallSite is first-class.** Carries arguments and return value
   handle for a specific invocation.

5. **Condition is first-class.** With `.true_branch`, `.false_branch`,
   `.error_branch`, `.pass_branch`.

6. **cfg on CodeScope, not Route.** `route.body.cfg` for single-
   function CFG.

7. **full_stack scope.** Replaces `route.lifecycle` with a queryable
   scope including middleware and hooks.

8. **Checks module.** `src/flawed/checks.py` provides composable selectors
   for crypto, token, schema, and permission validation functions.
