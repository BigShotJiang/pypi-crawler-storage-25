# flawed

Static analysis engine for confusion vulnerability research in Python web applications.

```python
from flawed import open_repo, detector
from flawed.inputs import Query, Form, Json
from flawed.effects import Mutation, Session
from flawed.checks import Crypto, Token
from flawed.route import Route, POST, accepting
```

## Status

Early development. API contracts are defined; engine runtime is not yet implemented.

## Structure

- `src/flawed/` — Rule API (Layer 3) — the primary user-facing surface
- `src/flawed/semantic/` — Semantic Layer (Layer 2) — framework interpretation (planned)
- `src/flawed/index/` — Code Index (Layer 1) — structural extraction (planned)

## Design

See `docs/` for architecture and design documents.
