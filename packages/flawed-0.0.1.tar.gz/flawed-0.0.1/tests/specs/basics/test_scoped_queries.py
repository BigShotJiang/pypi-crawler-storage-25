"""Specs: scoped queries on CodeScope (body, reachable, full_stack).

Fixture: tests/fixtures/apps/flask_basic/
"""

from __future__ import annotations

from flawed import open_repo
from flawed.effects import Mutation
from flawed.inputs import Json, SessionKey

FIXTURE = "tests/fixtures/apps/flask_basic"


class TestBodyScope:
    """route.body only includes the handler function body."""

    def test_body_reads_are_local(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "create_user").one()
        reads = route.body.reads(Json())
        # create_user reads request.json in its body
        assert len(reads) >= 1

    def test_body_effects_are_local(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "create_user").one()
        effects = route.body.effects(Mutation.write())
        # create_user performs a db write in its body
        assert len(effects) >= 1

    def test_body_does_not_include_other_routes(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "list_users").one()
        writes = route.body.effects(Mutation.write())
        # list_users does not write -- it only reads
        assert len(writes) == 0


class TestReachableScope:
    """route.reachable includes transitively called functions."""

    def test_reachable_includes_helper_calls(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "create_user").one()
        # get_db() is called from create_user; its effects should be reachable
        # The db.execute and db.commit calls happen in the handler body
        effects = route.reachable.effects(Mutation.write())
        assert len(effects) >= 1

    def test_reachable_conditions(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "profile").one()
        conds = route.reachable.conditions()
        # profile() has `if not user_id:` check
        assert len(conds) >= 1


class TestScopeFiltering:
    """Scoped queries filter correctly by source type."""

    def test_reads_filter_by_source(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "profile").one()
        session_reads = route.body.reads(SessionKey())
        json_reads = route.body.reads(Json())
        # profile reads from session, not from JSON body
        assert len(session_reads) >= 1
        assert len(json_reads) == 0

    def test_effects_filter_by_selector(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "create_user").one()
        writes = route.body.effects(Mutation.write())
        deletes = route.body.effects(Mutation.delete())
        # create_user writes but does not delete
        assert len(writes) >= 1
        assert len(deletes) == 0

    def test_conditions_using_value(self):
        kb = open_repo(FIXTURE)
        route = kb.routes.where(lambda r: r.endpoint == "profile").one()
        reads = route.body.reads(SessionKey())
        if reads:
            read = reads.first()
            conds = route.body.conditions_using(read.value)
            # The `if not user_id:` condition uses the session read
            assert len(conds) >= 1
