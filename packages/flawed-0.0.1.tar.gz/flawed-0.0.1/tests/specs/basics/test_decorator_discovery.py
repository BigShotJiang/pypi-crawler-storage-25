"""Specs: decorator discovery and properties.

Fixture: tests/fixtures/apps/decorators/
"""

from __future__ import annotations

from flawed import open_repo

FIXTURE = "tests/fixtures/apps/decorators"


class TestDecoratorDiscovery:
    def test_discovers_simple_decorator(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("plain").one()
        decs = fn.decorators
        assert len(decs) == 1
        assert decs.first().name == "simple_decorator"

    def test_discovers_parameterized_decorator(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("admin_only").one()
        decs = fn.decorators
        assert len(decs) == 1
        dec = decs.first()
        assert dec.name == "requires_role"
        assert '"admin"' in dec.args or "'admin'" in dec.args

    def test_discovers_stacked_decorators(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("stacked").one()
        assert len(fn.decorators) == 3

    def test_decorator_order(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("stacked").one()
        names = [d.name for d in fn.decorators]
        # Application order: innermost first (simple_decorator applied first)
        # Source order: top to bottom (log_calls, requires_role, simple_decorator)
        assert "log_calls" in names
        assert "requires_role" in names
        assert "simple_decorator" in names

    def test_decorated_with_filter(self):
        kb = open_repo(FIXTURE)
        fns = kb.functions.decorated_with("requires_role")
        names = {f.name for f in fns}
        assert "admin_only" in names
        assert "stacked" in names
        assert "restricted" in names
        assert "plain" not in names

    def test_method_decorators(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("restricted").one()
        assert fn.decorators.named("requires_role")
