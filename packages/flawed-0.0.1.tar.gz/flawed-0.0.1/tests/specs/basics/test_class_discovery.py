"""Specs: class discovery, filtering, and hierarchy.

Fixture: tests/fixtures/apps/classes/
"""

from __future__ import annotations

from flawed import open_repo

FIXTURE = "tests/fixtures/apps/classes"


class TestClassDiscovery:
    def test_discovers_all_classes(self):
        kb = open_repo(FIXTURE)
        names = {c.name for c in kb.classes}
        assert names >= {"Base", "Timestamped", "User", "Admin", "Serializable", "APIUser"}

    def test_named_filter(self):
        kb = open_repo(FIXTURE)
        assert kb.classes.named("User").one().name == "User"

    def test_subclasses_of_transitive(self):
        kb = open_repo(FIXTURE)
        subs = kb.classes.subclasses_of("Base")
        names = {c.name for c in subs}
        # User extends Base, Admin extends User, APIUser extends User
        assert names >= {"User", "Admin", "APIUser"}

    def test_direct_subclasses_of(self):
        kb = open_repo(FIXTURE)
        direct = kb.classes.direct_subclasses_of("Base")
        names = {c.name for c in direct}
        assert "User" in names
        assert "Admin" not in names  # Admin extends User, not Base directly


class TestClassHierarchy:
    def test_mro(self):
        kb = open_repo(FIXTURE)
        api_user = kb.classes.named("APIUser").one()
        mro_names = [c for c in api_user.mro]
        # APIUser -> Serializable -> User -> Timestamped -> Base -> ABC -> object
        assert "APIUser" in mro_names[0] or api_user.name in mro_names[0]

    def test_bases(self):
        kb = open_repo(FIXTURE)
        user = kb.classes.named("User").one()
        base_names = [b for b in user.bases]
        assert any("Timestamped" in b for b in base_names)
        assert any("Base" in b for b in base_names)

    def test_methods(self):
        kb = open_repo(FIXTURE)
        user = kb.classes.named("User").one()
        assert "__init__" in user.method_names
        assert "greet" in user.method_names

    def test_inherited_methods(self):
        kb = open_repo(FIXTURE)
        admin = kb.classes.named("Admin").one()
        inherited = {m.name for m in admin.inherited_methods}
        assert "save" in inherited      # from Base
        assert "greet" in inherited     # from User
        assert "touch" in inherited     # from Timestamped
