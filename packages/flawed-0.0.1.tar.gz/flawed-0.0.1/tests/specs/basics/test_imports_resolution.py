"""Specs: import resolution and symbol tracking.

Fixture: tests/fixtures/apps/imports/
"""

from __future__ import annotations

from flawed import open_repo

FIXTURE = "tests/fixtures/apps/imports"


class TestImportDiscovery:
    def test_discovers_stdlib_import(self):
        kb = open_repo(FIXTURE)
        # The module has `import os` at the top
        # This should be discoverable via the functions module's imports
        assert kb is not None  # skeleton: needs engine to verify import tracking

    def test_discovers_relative_import(self):
        kb = open_repo(FIXTURE)
        # `from . import helpers` should be resolved
        assert kb is not None  # skeleton: needs engine to verify relative imports

    def test_discovers_aliased_import(self):
        kb = open_repo(FIXTURE)
        # `from .helpers import transform as t` -- `t` resolves to helpers.transform
        assert kb is not None  # skeleton: needs engine to verify aliased imports

    def test_cross_file_call_resolves(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("run").one()
        callees = fn.calls
        # helpers.setup(), process_data(), t() should all resolve
        names = {f.name for f in callees}
        assert "setup" in names
