"""Specs: control flow graph queries.

Fixture: tests/fixtures/apps/functions/
"""

from __future__ import annotations

from flawed import open_repo

FIXTURE = "tests/fixtures/apps/functions"


class TestCFGAvailability:
    def test_cfg_available_for_function(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("top_level").one()
        cfg = fn.body.cfg
        assert cfg is not None

    def test_cfg_has_blocks(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("validate_positive").one()
        cfg = fn.body.cfg
        # validate_positive has an if statement -> at least 2 blocks
        assert len(list(cfg.blocks)) >= 2


class TestDominance:
    def test_entry_dominates_all(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("validate_positive").one()
        # The function entry dominates everything in the function
        # First statement dominates last statement
        assert fn is not None  # skeleton: needs engine to verify dominance

    def test_dominates_reflexive(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("top_level").one()
        cfg = fn.body.cfg
        # A location dominates itself
        assert cfg.dominates(fn.location, fn.location)

    def test_branch_does_not_dominate_sibling(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("validate_positive").one()
        cfg = fn.body.cfg
        # The raise inside the if does NOT dominate the return after the if
        # (They're in different branches)
        # This is a structural property we need to verify
        assert cfg is not None  # skeleton: needs engine to verify branch dominance
