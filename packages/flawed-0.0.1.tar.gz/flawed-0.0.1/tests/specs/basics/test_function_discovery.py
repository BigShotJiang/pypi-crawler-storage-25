"""Specs: function discovery and filtering.

Fixture: tests/fixtures/apps/functions/
"""

from __future__ import annotations

import pytest

from flawed import open_repo
from flawed.function import FunctionKind

FIXTURE = "tests/fixtures/apps/functions"


class TestFunctionDiscovery:
    """The repo view discovers all functions in the fixture."""

    def test_discovers_top_level_functions(self):
        kb = open_repo(FIXTURE)
        fns = kb.functions.where(lambda f: f.kind == FunctionKind.TOP_LEVEL)
        names = {f.name for f in fns}
        assert "top_level" in names
        assert "with_nested" in names
        assert "with_lambda" in names
        assert "with_closure" in names

    def test_discovers_methods(self):
        kb = open_repo(FIXTURE)
        methods = kb.functions.where(lambda f: f.kind == FunctionKind.METHOD)
        names = {f.name for f in methods}
        assert "add" in names
        assert "multiply" in names

    def test_discovers_nested_functions(self):
        kb = open_repo(FIXTURE)
        nested = kb.functions.where(lambda f: f.kind == FunctionKind.NESTED)
        names = {f.name for f in nested}
        assert "inner" in names

    def test_discovers_lambdas(self):
        kb = open_repo(FIXTURE)
        lambdas = kb.functions.where(lambda f: f.kind == FunctionKind.LAMBDA)
        assert len(lambdas) >= 1

    def test_discovers_static_methods(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("zero").one()
        assert fn.parent_class is not None

    def test_discovers_class_methods(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("from_value").one()
        assert fn.parent_class is not None

    def test_cross_file_discovery(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("validate_positive").one()
        assert "helpers.py" in fn.file

    def test_total_function_count(self):
        kb = open_repo(FIXTURE)
        # top_level, with_nested, with_lambda, with_closure,
        # inner (nested), lambda, inner (closure),
        # add, multiply, zero, from_value,
        # validate_positive, format_result
        assert len(kb.functions) >= 13


class TestFunctionFiltering:
    """Collection filters return the correct subsets."""

    def test_named_filter(self):
        kb = open_repo(FIXTURE)
        fns = kb.functions.named("add")
        assert len(fns) == 1
        assert fns.one().name == "add"

    def test_with_fqn_filter(self):
        kb = open_repo(FIXTURE)
        # FQN depends on how the fixture is indexed
        fn = kb.functions.named("add").one()
        result = kb.functions.with_fqn(fn.fqn)
        assert len(result) == 1

    def test_in_file_filter(self):
        kb = open_repo(FIXTURE)
        fns = kb.functions.in_file("helpers.py")
        names = {f.name for f in fns}
        assert "validate_positive" in names
        assert "format_result" in names
        assert "top_level" not in names

    def test_in_dir_filter(self):
        kb = open_repo(FIXTURE)
        # All functions should be in the fixture dir
        all_fns = kb.functions.in_dir(".")
        assert len(all_fns) == len(kb.functions)

    def test_decorated_with_filter(self):
        # This fixture doesn't have decorators -- see decorators fixture
        kb = open_repo(FIXTURE)
        decorated = kb.functions.decorated_with("staticmethod")
        names = {f.name for f in decorated}
        assert "zero" in names

    def test_chained_filters(self):
        kb = open_repo(FIXTURE)
        result = kb.functions.in_file("main.py").named("top_level")
        assert len(result) == 1

    def test_where_predicate(self):
        kb = open_repo(FIXTURE)
        fns = kb.functions.where(lambda f: len(f.params) > 1)
        for fn in fns:
            assert len(fn.params) > 1

    def test_first_returns_none_on_empty(self):
        kb = open_repo(FIXTURE)
        result = kb.functions.named("nonexistent").first()
        assert result is None

    def test_one_raises_on_multiple(self):
        kb = open_repo(FIXTURE)
        # "inner" appears in both with_nested and with_closure
        with pytest.raises(Exception, match=""):  # noqa: B017
            kb.functions.named("inner").one()


class TestFunctionProperties:
    """Individual function properties are correctly populated."""

    def test_fqn_is_nonempty(self):
        kb = open_repo(FIXTURE)
        for fn in kb.functions:
            assert fn.fqn, f"{fn.name} has empty fqn"

    def test_name_matches_declaration(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("top_level").one()
        assert fn.name == "top_level"

    def test_file_is_set(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("top_level").one()
        assert fn.file.endswith("main.py")

    def test_line_is_positive(self):
        kb = open_repo(FIXTURE)
        for fn in kb.functions:
            assert fn.line > 0, f"{fn.name} has line {fn.line}"

    def test_params_include_defaults(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("top_level").one()
        assert len(fn.params) == 2
        assert fn.params[0].name == "x"
        assert fn.params[1].name == "y"
        assert fn.params[1].default == "10"

    def test_method_has_parent_class(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("add").one()
        assert fn.parent_class is not None
        assert "Calculator" in fn.parent_class

    def test_nested_has_parent_function(self):
        kb = open_repo(FIXTURE)
        # The inner function inside with_nested
        inners = kb.functions.named("inner")
        for inner in inners:
            assert inner.parent_function is not None

    def test_top_level_has_no_parent(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("top_level").one()
        assert fn.parent_class is None
        assert fn.parent_function is None

    def test_location_spans_declaration(self):
        kb = open_repo(FIXTURE)
        fn = kb.functions.named("top_level").one()
        assert fn.location.start_line == fn.line
        assert fn.location.start_col >= 0
