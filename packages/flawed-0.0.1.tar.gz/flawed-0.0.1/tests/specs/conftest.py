import pytest


def pytest_collection_modifyitems(items):
    """Skip all spec tests until the engine runtime is implemented."""
    skip = pytest.mark.skip(reason="engine runtime not yet implemented")
    for item in items:
        item.add_marker(skip)
