"""Verify selector construction and composability."""

from __future__ import annotations


class TestEffectSelector:
    def test_mutation_any(self) -> None:
        from flawed.effects import EffectCategory, Mutation

        sel = Mutation.any()
        assert EffectCategory.DATA_WRITE in sel.categories
        assert EffectCategory.DATA_DELETE in sel.categories
        assert sel.key_filter is None

    def test_mutation_write(self) -> None:
        from flawed.effects import EffectCategory, Mutation

        sel = Mutation.write()
        assert sel.categories == frozenset({EffectCategory.DATA_WRITE})

    def test_mutation_delete(self) -> None:
        from flawed.effects import EffectCategory, Mutation

        sel = Mutation.delete()
        assert sel.categories == frozenset({EffectCategory.DATA_DELETE})

    def test_session_write(self) -> None:
        from flawed.effects import EffectCategory, Session

        sel = Session.write()
        assert sel.categories == frozenset({EffectCategory.SESSION_WRITE})
        assert sel.key_filter is None

    def test_session_write_with_key(self) -> None:
        from flawed.effects import Session

        sel = Session.write(key="user_id")
        assert sel.key_filter == "user_id"

    def test_session_read(self) -> None:
        from flawed.effects import EffectCategory, Session

        sel = Session.read()
        assert sel.categories == frozenset({EffectCategory.DATA_READ})

    def test_outbound_request(self) -> None:
        from flawed.effects import EffectCategory, Outbound

        sel = Outbound.request()
        assert sel.categories == frozenset({EffectCategory.OUTBOUND_REQUEST})

    def test_or_composition(self) -> None:
        from flawed.effects import EffectCategory, Mutation, Session

        combined = Mutation.any() | Session.write()
        assert EffectCategory.DATA_WRITE in combined.categories
        assert EffectCategory.DATA_DELETE in combined.categories
        assert EffectCategory.SESSION_WRITE in combined.categories
        assert combined.key_filter is None

    def test_or_composition_multiple(self) -> None:
        from flawed.effects import (
            EffectCategory,
            Mutation,
            Outbound,
            Session,
        )

        combined = Mutation.write() | Session.write() | Outbound.request()
        assert EffectCategory.DATA_WRITE in combined.categories
        assert EffectCategory.SESSION_WRITE in combined.categories
        assert EffectCategory.OUTBOUND_REQUEST in combined.categories
        assert len(combined.categories) == 3

    def test_or_is_a_new_selector(self) -> None:
        from flawed.effects import Mutation, Session

        a = Mutation.write()
        b = Session.write()
        combined = a | b
        assert combined is not a
        assert combined is not b
        # Originals unchanged (frozen)
        assert len(a.categories) == 1
        assert len(b.categories) == 1


class TestFnSelector:
    def test_named(self) -> None:
        from flawed.calls import Fn

        sel = Fn.named("save")
        assert sel.name_filter == "save"
        assert sel.fqn_filter is None
        assert sel.pattern_filter is None

    def test_fqn(self) -> None:
        from flawed.calls import Fn

        sel = Fn.fqn("app.models.User.save")
        assert sel.fqn_filter == "app.models.User.save"
        assert sel.name_filter is None

    def test_matching(self) -> None:
        from flawed.calls import Fn

        sel = Fn.matching(r"auth.*")
        assert sel.pattern_filter == r"auth.*"

    def test_or_composition(self) -> None:
        from flawed.calls import Fn

        a = Fn.named("save")
        b = Fn.fqn("app.models.User.save")
        combined = a | b
        assert combined is not a
        assert combined is not b
        assert len(combined._alternatives) == 2
        assert combined._alternatives[0].name_filter == "save"
        assert combined._alternatives[1].fqn_filter == "app.models.User.save"

    def test_or_composition_multiple(self) -> None:
        from flawed.calls import Fn

        combined = Fn.named("a") | Fn.fqn("b.c") | Fn.matching(r"d.*")
        assert len(combined._alternatives) == 3

    def test_or_preserves_originals(self) -> None:
        from flawed.calls import Fn

        a = Fn.named("save")
        b = Fn.fqn("app.save")
        _ = a | b
        # Originals unchanged (frozen)
        assert a.name_filter == "save"
        assert a._alternatives == ()
        assert b.fqn_filter == "app.save"
        assert b._alternatives == ()


class TestCheckSelectors:
    def test_crypto_compare_is_composite(self) -> None:
        from flawed.checks import Crypto

        sel = Crypto.compare()
        assert len(sel._alternatives) >= 3

    def test_token_verify_is_composite(self) -> None:
        from flawed.checks import Token

        sel = Token.verify()
        assert len(sel._alternatives) >= 3

    def test_schema_validate_is_composite(self) -> None:
        from flawed.checks import Schema

        sel = Schema.validate()
        assert len(sel._alternatives) >= 4

    def test_permission_check_uses_pattern(self) -> None:
        from flawed.checks import Permission

        sel = Permission.check()
        assert sel.pattern_filter is not None

    def test_cross_compose_checks_and_effects(self) -> None:
        """Checks and effects are different types; this just verifies
        they can be constructed together without errors."""
        from flawed.checks import Crypto, Token
        from flawed.effects import Mutation, Session

        validators = Crypto.compare() | Token.verify()
        sensitive = Mutation.any() | Session.write()
        assert validators._alternatives
        assert sensitive.categories


class TestAccepting:
    def test_accepting_predicate(self) -> None:
        from flawed.core import (
            InterpretationProvenance,
            Location,
            Provenance,
        )
        from flawed.function import Function, FunctionKind
        from flawed.route import (
            HttpMethod,
            Route,
            accepting,
        )

        loc = Location(file="a.py", line=1, column=0)
        prov = InterpretationProvenance(
            source_layer="L2",
            interpreter="test",
            confidence=1.0,
            supporting_facts=(),
        )
        handler = Function(
            fqn="app.views.index",
            name="index",
            file="a.py",
            line=1,
            params=(),
            kind=FunctionKind.TOP_LEVEL,
            parent_class=None,
            parent_function=None,
            location=loc,
            provenance=Provenance(
                source_layer="L1",
                interpreter="ast",
                confidence=1.0,
            ),
        )
        route = Route(
            endpoint="index",
            url_rule="/",
            methods=frozenset({HttpMethod.GET, HttpMethod.POST}),
            handler=handler,
            blueprint=None,
            location=loc,
            provenance=prov,
        )

        assert accepting(HttpMethod.GET)(route) is True
        assert accepting(HttpMethod.POST)(route) is True
        assert accepting(HttpMethod.DELETE)(route) is False
        assert accepting(HttpMethod.GET, HttpMethod.DELETE)(route) is True
