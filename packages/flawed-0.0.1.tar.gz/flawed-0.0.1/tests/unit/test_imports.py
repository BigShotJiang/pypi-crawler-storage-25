"""Verify all public types import cleanly from the package."""

from __future__ import annotations


def test_top_level_imports() -> None:
    from flawed import (
        RepoView,
        detector,
        open_repo,
    )
    assert callable(open_repo)
    assert callable(detector)
    assert RepoView is not None


def test_core_imports() -> None:
    from flawed.core import (
        InterpretationProvenance,
        JsonPath,
        Key,
        Location,
        Provenance,
    )
    assert Location is not None
    assert Provenance is not None
    assert InterpretationProvenance is not None
    assert Key is not None
    assert JsonPath is not None


def test_route_imports() -> None:
    from flawed.route import (
        DELETE,
        GET,
        HEAD,
        OPTIONS,
        PATCH,
        POST,
        PUT,
        HttpMethod,
        Route,
        accepting,
    )
    assert Route is not None
    assert HttpMethod is not None
    assert callable(accepting)
    assert GET is HttpMethod.GET
    assert POST is HttpMethod.POST
    assert PUT is HttpMethod.PUT
    assert PATCH is HttpMethod.PATCH
    assert DELETE is HttpMethod.DELETE
    assert OPTIONS is HttpMethod.OPTIONS
    assert HEAD is HttpMethod.HEAD


def test_function_imports() -> None:
    from flawed.function import (
        Decorator,
        Function,
        FunctionKind,
        Parameter,
    )
    assert Function is not None
    assert Parameter is not None
    assert Decorator is not None
    assert FunctionKind is not None


def test_input_imports() -> None:
    from flawed.inputs import (
        AccessPattern,
        AnyContainer,
        AnyOf,
        Cardinality,
        Cookie,
        FileUpload,
        Form,
        Header,
        InputRead,
        InputSource,
        Json,
        PathParam,
        Query,
        RawBody,
        SessionKey,
    )
    assert InputSource is not None
    assert Query is not None
    assert Form is not None
    assert Json is not None
    assert Header is not None
    assert Cookie is not None
    assert PathParam is not None
    assert SessionKey is not None
    assert FileUpload is not None
    assert RawBody is not None
    assert AnyContainer is not None
    assert AnyOf is not None
    assert InputRead is not None
    assert AccessPattern is not None
    assert Cardinality is not None


def test_effect_imports() -> None:
    from flawed.effects import (
        Effect,
        EffectCategory,
        EffectSelector,
        Mutation,
        Outbound,
        Session,
    )
    assert Effect is not None
    assert EffectCategory is not None
    assert EffectSelector is not None
    assert Mutation is not None
    assert Session is not None
    assert Outbound is not None


def test_condition_imports() -> None:
    from flawed.conditions import Condition
    assert Condition is not None


def test_call_imports() -> None:
    from flawed.calls import (
        Argument,
        CallSite,
        Fn,
        FnSelector,
    )
    assert CallSite is not None
    assert Argument is not None
    assert FnSelector is not None
    assert Fn is not None


def test_flow_imports() -> None:
    from flawed.flow import (
        FlowStep,
        FlowTrace,
        ValueHandle,
    )
    assert ValueHandle is not None
    assert FlowTrace is not None
    assert FlowStep is not None


def test_scope_imports() -> None:
    from flawed.scopes import (
        CodeScope,
        ControlFlowView,
    )
    assert CodeScope is not None
    assert ControlFlowView is not None


def test_collection_imports() -> None:
    from flawed.collections import (
        CallSiteCollection,
        ConditionCollection,
        DecoratorCollection,
        DomainCollection,
        EffectCollection,
        FunctionCollection,
        InputReadCollection,
        RouteCollection,
    )
    assert DomainCollection is not None
    assert RouteCollection is not None
    assert FunctionCollection is not None
    assert InputReadCollection is not None
    assert EffectCollection is not None
    assert ConditionCollection is not None
    assert CallSiteCollection is not None
    assert DecoratorCollection is not None


def test_evidence_imports() -> None:
    from flawed.evidence import (
        Evidence,
        Finding,
    )
    assert Evidence is not None
    assert Finding is not None
