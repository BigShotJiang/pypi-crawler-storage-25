"""Verify type hierarchy and subclass relationships."""

from __future__ import annotations


def test_input_source_hierarchy() -> None:
    from flawed.inputs import (
        AnyContainer,
        AnyOf,
        Cookie,
        FileUpload,
        Form,
        Header,
        InputSource,
        Json,
        PathParam,
        Query,
        RawBody,
        SessionKey,
    )

    subclasses = [
        Query, Form, Json, Header, Cookie, PathParam,
        SessionKey, FileUpload, RawBody, AnyContainer, AnyOf,
    ]
    for cls in subclasses:
        assert issubclass(cls, InputSource), f"{cls.__name__} should be InputSource subclass"


def test_collection_hierarchy() -> None:
    from flawed.collections import (
        CallSiteCollection,
        ConditionCollection,
        DecoratorCollection,
        DomainCollection,
        EffectCollection,
        FunctionCollection,
        InputReadCollection,
        RouteCollection,
    )

    typed_collections = [
        RouteCollection,
        FunctionCollection,
        InputReadCollection,
        EffectCollection,
        ConditionCollection,
        CallSiteCollection,
        DecoratorCollection,
    ]
    for cls in typed_collections:
        assert issubclass(cls, DomainCollection), (
            f"{cls.__name__} should be DomainCollection subclass"
        )


def test_input_source_instances_are_frozen() -> None:
    import pytest

    from flawed.core import Key
    from flawed.inputs import Query

    q = Query(key=Key("user_id"))
    with pytest.raises(AttributeError):
        q.key = Key("other")  # type: ignore[misc]


def test_input_source_instantiation() -> None:
    from flawed.core import JsonPath, Key
    from flawed.inputs import (
        AnyContainer,
        AnyOf,
        Cookie,
        FileUpload,
        Form,
        Header,
        Json,
        PathParam,
        Query,
        RawBody,
        SessionKey,
    )

    assert Query(key=Key("q")).key == Key("q")
    assert Form(key=Key("name")).key == Key("name")
    assert Json(path=JsonPath("$.data")).path == JsonPath("$.data")
    assert Header(name=Key("Authorization")).name == Key("Authorization")
    assert Cookie(name=Key("session")).name == Key("session")
    assert PathParam(name=Key("id")).name == Key("id")
    assert SessionKey(key=Key("user")).key == Key("user")
    assert FileUpload(field=Key("avatar")).field == Key("avatar")
    assert RawBody() == RawBody()
    assert AnyContainer(key=Key("id")).key == Key("id")

    q = Query(key=Key("a"))
    f = Form(key=Key("b"))
    any_of = AnyOf(sources=(q, f))
    assert len(any_of.sources) == 2
    assert any_of.sources[0] is q
    assert any_of.sources[1] is f


