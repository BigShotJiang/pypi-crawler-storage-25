"""Verify enum values and completeness."""

from __future__ import annotations


def test_http_method_values() -> None:
    from flawed.route import HttpMethod

    expected = {"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"}
    actual = {m.value for m in HttpMethod}
    assert actual == expected


def test_http_method_aliases() -> None:
    from flawed.route import (
        DELETE,
        GET,
        HEAD,
        OPTIONS,
        PATCH,
        POST,
        PUT,
        HttpMethod,
    )

    assert GET == HttpMethod.GET
    assert POST == HttpMethod.POST
    assert PUT == HttpMethod.PUT
    assert PATCH == HttpMethod.PATCH
    assert DELETE == HttpMethod.DELETE
    assert OPTIONS == HttpMethod.OPTIONS
    assert HEAD == HttpMethod.HEAD


def test_function_kind_values() -> None:
    from flawed.function import FunctionKind

    expected = {"top_level", "method", "nested", "lambda", "closure"}
    actual = {k.value for k in FunctionKind}
    assert actual == expected


def test_access_pattern_values() -> None:
    from flawed.inputs import AccessPattern

    expected = {"get", "subscript", "getlist", "attribute", "iteration", "unknown"}
    actual = {p.value for p in AccessPattern}
    assert actual == expected


def test_cardinality_values() -> None:
    from flawed.inputs import Cardinality

    expected = {"single", "multi", "unknown"}
    actual = {c.value for c in Cardinality}
    assert actual == expected


def test_effect_category_values() -> None:
    from flawed.effects import EffectCategory

    expected = {
        "data_write", "data_delete", "data_read",
        "session_write", "context_write",
        "outbound_request", "file_write", "notification",
    }
    actual = {c.value for c in EffectCategory}
    assert actual == expected
