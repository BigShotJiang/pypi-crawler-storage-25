"""Verify frozen dataclasses can be instantiated with valid data."""

from __future__ import annotations

import pytest

from flawed.core import (
    InterpretationProvenance,
    Location,
    Provenance,
)
from flawed.function import (
    Decorator,
    Function,
    FunctionKind,
    Parameter,
)


def make_location(
    *,
    file: str = "app/views.py",
    line: int = 10,
    column: int = 0,
) -> Location:
    return Location(file=file, line=line, column=column)


def make_provenance() -> Provenance:
    return Provenance(
        source_layer="L2",
        interpreter="FlaskRouteInterpreter",
        confidence=0.95,
    )


def make_interpretation_provenance() -> InterpretationProvenance:
    return InterpretationProvenance(
        source_layer="L2",
        interpreter="FlaskRouteInterpreter",
        confidence=0.95,
        supporting_facts=("route_decorator_found",),
    )


def make_parameter() -> Parameter:
    return Parameter(
        name="user_id",
        annotation="int",
        default=None,
        kind="positional_or_keyword",
    )


def make_function() -> Function:
    return Function(
        fqn="app.views.get_user",
        name="get_user",
        file="app/views.py",
        line=10,
        params=(make_parameter(),),
        kind=FunctionKind.TOP_LEVEL,
        parent_class=None,
        parent_function=None,
        location=make_location(),
        provenance=make_provenance(),
    )


class TestLocation:
    def test_basic(self) -> None:
        loc = make_location()
        assert loc.file == "app/views.py"
        assert loc.line == 10
        assert loc.column == 0
        assert loc.end_line is None
        assert loc.end_column is None

    def test_with_end(self) -> None:
        loc = Location(file="a.py", line=1, column=0, end_line=5, end_column=20)
        assert loc.end_line == 5
        assert loc.end_column == 20

    def test_frozen(self) -> None:
        loc = make_location()
        with pytest.raises(AttributeError):
            loc.line = 99  # type: ignore[misc]


class TestProvenance:
    def test_basic(self) -> None:
        p = make_provenance()
        assert p.source_layer == "L2"
        assert p.confidence == 0.95

    def test_interpretation_provenance(self) -> None:
        ip = make_interpretation_provenance()
        assert ip.supporting_facts == ("route_decorator_found",)

    def test_frozen(self) -> None:
        p = make_provenance()
        with pytest.raises(AttributeError):
            p.confidence = 0.5  # type: ignore[misc]


class TestParameter:
    def test_basic(self) -> None:
        p = make_parameter()
        assert p.name == "user_id"
        assert p.annotation == "int"
        assert p.default is None

    def test_no_annotation(self) -> None:
        p = Parameter(name="x", annotation=None, default="42", kind="positional_or_keyword")
        assert p.annotation is None
        assert p.default == "42"


class TestDecorator:
    def test_basic(self) -> None:
        d = Decorator(
            name="login_required",
            fqn="flask_login.login_required",
            arguments=(),
            location=make_location(),
        )
        assert d.name == "login_required"
        assert d.fqn == "flask_login.login_required"


class TestFunction:
    def test_basic(self) -> None:
        fn = make_function()
        assert fn.fqn == "app.views.get_user"
        assert fn.kind == FunctionKind.TOP_LEVEL
        assert fn.parent_class is None
        assert fn.parent_function is None
        assert len(fn.params) == 1

    def test_method_kind(self) -> None:
        fn = Function(
            fqn="app.models.User.save",
            name="save",
            file="app/models.py",
            line=20,
            params=(),
            kind=FunctionKind.METHOD,
            parent_class="app.models.User",
            parent_function=None,
            location=make_location(file="app/models.py", line=20),
            provenance=make_provenance(),
        )
        assert fn.kind == FunctionKind.METHOD
        assert fn.parent_class == "app.models.User"

    def test_nested_kind(self) -> None:
        fn = Function(
            fqn="app.views.outer.<locals>.inner",
            name="inner",
            file="app/views.py",
            line=15,
            params=(),
            kind=FunctionKind.NESTED,
            parent_class=None,
            parent_function="app.views.outer",
            location=make_location(line=15),
            provenance=make_provenance(),
        )
        assert fn.kind == FunctionKind.NESTED
        assert fn.parent_function == "app.views.outer"

    def test_frozen(self) -> None:
        fn = make_function()
        with pytest.raises(AttributeError):
            fn.name = "other"  # type: ignore[misc]
