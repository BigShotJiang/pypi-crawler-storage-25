"""RabbitMQ publisher package."""
