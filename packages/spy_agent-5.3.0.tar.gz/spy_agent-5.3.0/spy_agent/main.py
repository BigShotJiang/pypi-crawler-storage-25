import cloudscraper
from bs4 import BeautifulSoup
import json
import os
import re
import requests
import ssl
import shutil
import tarfile
from requests.adapters import HTTPAdapter

# --- GHOST CORE (TLS Spoofing) ---
CHROME_CIPHER_SUITES = [
    'ECDHE-ECDSA-AES128-GCM-SHA256','ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-ECDSA-AES256-GCM-SHA384','ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-CHACHA20-POLY1305','ECDHE-RSA-CHACHA20-POLY1305'
]

class CipherAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        context.set_ciphers(':'.join(CHROME_CIPHER_SUITES))
        kwargs['ssl_context'] = context
        return super(CipherAdapter, self).init_poolmanager(*args, **kwargs)

class SpyAgent:
    def __init__(self):
        self.scraper = cloudscraper.create_scraper(browser={'browser': 'chrome', 'platform': 'android', 'desktop': False})
        self.scraper.mount("https://", CipherAdapter())
        self.patterns = {
            "Secrets": r"(?i)(token|auth|config|secret|key|admin|password|access_token|client_id|aws_|firebase|s3_)[^=]{0,20}[:=]\s*['\"`]([a-zA-Z0-9\-_=\.\/\+]{8,})['\"`]",
            "Endpoints": r"['\"`](/(?:api|v\d|auth|config|admin|graphql|rest|user|account|payment)/[\w\-\._~%?#&=/]*)['\"`]"
        }

    def print_banner(self):
        os.system("clear")
        print("\033[1;36m.---.\n/     \\\n| () () |  AGENT\n \\  ^  /   JS-MINER\n  |||||\n--- DARK VISION V5.3 ---\n   [ STORAGE ENABLED ]\033[0m\n")

    def archive_and_move(self, base_dir, domain):
        """Loot ko compress karke Downloads mein bhejta hai"""
        archive_name = f"{domain}.tar.gz"
        print(f"\n📦 Packing loot into {archive_name}...")
        
        try:
            # 1. Create Archive
            with tarfile.open(archive_name, "w:gz") as tar:
                tar.add(base_dir, arcname=os.path.basename(base_dir))
            
            # 2. Move to Android Downloads
            download_path = f"/sdcard/Download/{archive_name}"
            if os.path.exists("/sdcard"):
                shutil.move(archive_name, download_path)
                print(f"\033[1;32m✅ Master Loot Moved: Internal Storage/Download/{archive_name}\033[0m")
            else:
                print(f"⚠️ Move failed: Run 'termux-setup-storage' first.")
        except Exception as e:
            print(f"❌ Archiving failed: {e}")

    def run(self):
        self.print_banner()
        target = input("🎯 TARGET URL: ").strip()
        if not target.startswith(('http://', 'https://')): target = 'https://' + target

        domain = target.replace('https://','').replace('http://','').split('/')[0]
        base_dir = f"scan_{domain}"
        js_dir = f"{base_dir}/js_files"
        asset_dir = f"{base_dir}/other_assets"
        secret_dir = f"{base_dir}/secret_intel"

        for d in [js_dir, asset_dir, secret_dir]:
            if not os.path.exists(d): os.makedirs(d)

        print(f"📡 Initializing Folders in: {base_dir}")

        try:
            res = self.scraper.get(target, timeout=15)
            soup = BeautifulSoup(res.text, 'html.parser')

            scripts = [s['src'] for s in soup.find_all('script', src=True)]
            links = [l['href'] for l in soup.find_all('link', href=True)]
            all_assets = list(set(scripts + links))

            print(f"📦 Harvesting {len(all_assets)} Assets (JS/CSS/JSON)...")

            all_secrets = []
            all_endpoints = []

            for i, link in enumerate(all_assets):
                asset_url = link if link.startswith('http') else requests.compat.urljoin(target, link)
                asset_name = asset_url.split('/')[-1].split('?')[0] or f"asset_{i}"
                save_path = js_dir if asset_name.endswith('.js') else asset_dir

                try:
                    asset_res = self.scraper.get(asset_url, timeout=10)
                    with open(f"{save_path}/{asset_name}", 'w', encoding='utf-8') as f:
                        f.write(asset_res.text)

                    secrets = re.findall(self.patterns["Secrets"], asset_res.text)
                    endpoints = re.findall(self.patterns["Endpoints"], asset_res.text)

                    if secrets:
                        all_secrets.extend([f"FILE: {asset_name} | {s[0]}: {s[1]}" for s in secrets])
                    if endpoints:
                        all_endpoints.extend([f"FILE: {asset_name} | {e}" for e in endpoints])

                    print(f"  [+] Downloaded & Scanned: {asset_name}")
                except: continue

            # Final Reports
            loot_file = f"{base_dir}/stolen_intel.txt"
            with open(loot_file, 'w') as f:
                f.write(f"--- DARK VISION LOOT REPORT [{domain}] ---\n")
                f.write("\n[!] CRITICAL SECRETS:\n" + "\n".join(list(set(all_secrets))))
                f.write("\n\n[!] ENDPOINTS:\n" + "\n".join(list(set(all_endpoints))))

            print(f"\n\033[1;32m[✅] SCANNED SUCCESSFULLY!")
            
            # ARCHIVE AND MOVE TO DOWNLOADS
            self.archive_and_move(base_dir, domain)

        except Exception as e: print(f"❌ Error: {e}")

if __name__ == "__main__":
    SpyAgent().run()
