"""Sample scripts for QPDK."""
