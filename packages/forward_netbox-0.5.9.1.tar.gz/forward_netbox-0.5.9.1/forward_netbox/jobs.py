import logging
from datetime import datetime
from datetime import timedelta

from core.choices import JobStatusChoices
from core.exceptions import SyncError
from core.models import ObjectType
from netbox.context_managers import event_tracking
from rq.timeouts import JobTimeoutException
from utilities.datetime import local_now
from utilities.request import NetBoxFakeRequest

from .choices import ForwardIngestionPhaseChoices
from .choices import ForwardSyncStatusChoices
from .exceptions import ForwardSyncError
from .models import ForwardIngestion
from .models import ForwardIngestionIssue
from .models import ForwardSync
from .utilities.logging import SyncLogging
from .utilities.validation import ForwardValidationRunner

logger = logging.getLogger(__name__)


def _normalize_job_log_level(level):
    return {
        "success": "info",
        "failure": "error",
    }.get(level, level)


def _build_job_log_entries(log_data):
    entries = []
    for entry in (log_data or {}).get("logs", []):
        if not isinstance(entry, (list, tuple)) or len(entry) < 5:
            continue
        timestamp = entry[0]
        if isinstance(timestamp, str):
            try:
                timestamp = datetime.fromisoformat(timestamp)
            except ValueError:
                timestamp = local_now()
        entries.append(
            {
                "timestamp": timestamp,
                "level": _normalize_job_log_level(entry[1]),
                "message": entry[4],
            }
        )
    return entries


def safe_save_job_data(job, obj_with_logger):
    try:
        if hasattr(obj_with_logger, "logger") and hasattr(
            obj_with_logger.logger, "log_data"
        ):
            log_data = obj_with_logger.logger.log_data
            update_fields = ["data"]
            job.data = log_data
            job.log_entries = _build_job_log_entries(log_data)
            update_fields.append("log_entries")
            job.save(update_fields=update_fields)
    except Exception as exc:
        logger.warning("Failed to save job data for job %s: %s", job.pk, exc)


def record_timeout_issue(ingestion, phase, message):
    if ingestion is None:
        return None
    existing = ForwardIngestionIssue.objects.filter(
        ingestion=ingestion,
        phase=phase,
        exception=JobTimeoutException.__name__,
    ).first()
    if existing:
        return existing
    return ForwardIngestionIssue.objects.create(
        ingestion=ingestion,
        phase=phase,
        message=message,
        exception=JobTimeoutException.__name__,
        raw_data={},
        coalesce_fields={},
        defaults={},
    )


def sync_forwardsync(job, *args, **kwargs):
    sync = ForwardSync.objects.get(pk=job.object_id)

    try:
        job.start()
        sync.sync(job=job)
        safe_save_job_data(job, sync)
        job.terminate()
    except Exception as exc:
        safe_save_job_data(job, sync)
        timeout = isinstance(exc, JobTimeoutException)
        job.terminate(status=JobStatusChoices.STATUS_ERRORED)
        ForwardSync.objects.filter(pk=sync.pk).update(
            status=(
                ForwardSyncStatusChoices.TIMEOUT
                if timeout
                else ForwardSyncStatusChoices.FAILED
            )
        )
        if timeout:
            ingestion = (
                ForwardIngestion.objects.filter(sync=sync).order_by("-pk").first()
            )
            message = "Forward sync job timed out. Increase RQ worker timeout and rerun the sync."
            record_timeout_issue(
                ingestion,
                ForwardIngestionPhaseChoices.SYNC,
                message,
            )
            sync.logger.log_failure(message, obj=sync)
        if isinstance(exc, (ForwardSyncError, SyncError, JobTimeoutException)):
            logger.error(exc)
        else:
            raise
    finally:
        if sync.interval and not kwargs.get("adhoc"):
            new_scheduled_time = local_now() + timedelta(minutes=sync.interval)
            sync.refresh_from_db()
            should_skip = not sync.scheduled or (
                sync.scheduled
                and sync.scheduled > job.started
                and sync.jobs.filter(
                    status__in=[
                        JobStatusChoices.STATUS_SCHEDULED,
                        JobStatusChoices.STATUS_PENDING,
                        JobStatusChoices.STATUS_RUNNING,
                    ]
                )
                .exclude(pk=job.pk)
                .exists()
            )
            if should_skip:
                logger.info(
                    "Not scheduling a new job for ForwardSync %s because scheduling changed while the current job was running.",
                    sync.pk,
                )
            if not should_skip:
                request = NetBoxFakeRequest(
                    {
                        "META": {},
                        "POST": sync.parameters,
                        "GET": {},
                        "FILES": {},
                        "user": sync.user,
                        "path": "",
                        "id": job.job_id,
                    }
                )

                with event_tracking(request):
                    sync.scheduled = new_scheduled_time
                    sync.full_clean()
                    sync.save()
                logger.info(
                    "Scheduled next sync for ForwardSync %s at %s.",
                    sync.pk,
                    new_scheduled_time,
                )


def validate_forwardsync(job, *args, **kwargs):
    sync = ForwardSync.objects.get(pk=job.object_id)

    try:
        job.start()
        sync.logger = SyncLogging(job=job.pk)
        validation_run = ForwardValidationRunner(
            sync,
            sync.source.get_client(),
            sync.logger,
            job=job,
        ).run_query_validation()
        safe_save_job_data(job, sync)
        job.object_type = ObjectType.objects.get_for_model(validation_run)
        job.object_id = validation_run.pk
        job.save(update_fields=["object_type", "object_id"])
        job.terminate()
    except Exception as exc:
        safe_save_job_data(job, sync)
        job.terminate(status=JobStatusChoices.STATUS_ERRORED)
        if type(exc) in (SyncError, JobTimeoutException):
            logger.error(exc)
        else:
            raise


def merge_forwardingestion(job, remove_branch=True, *args, **kwargs):
    ingestion = ForwardIngestion.objects.get(pk=job.object_id)
    try:
        request = NetBoxFakeRequest(
            {
                "META": {},
                "POST": ingestion.sync.parameters,
                "GET": {},
                "FILES": {},
                "user": ingestion.sync.user,
                "path": "",
                "id": job.job_id,
            }
        )

        job.start()
        ingestion.merge_job = job
        ingestion.save(update_fields=["merge_job"])
        ingestion.sync.logger = SyncLogging(job=job.pk)
        with event_tracking(request):
            ingestion.sync_merge(remove_branch=remove_branch)

        safe_save_job_data(job, ingestion.sync)
        job.terminate()
    except Exception as exc:
        logger.exception(
            "Error during merge for ForwardIngestion %s: %s", ingestion.pk, exc
        )
        safe_save_job_data(job, ingestion.sync)
        timeout = isinstance(exc, JobTimeoutException)
        job.terminate(status=JobStatusChoices.STATUS_ERRORED)
        ForwardSync.objects.filter(pk=ingestion.sync.pk).update(
            status=(
                ForwardSyncStatusChoices.TIMEOUT
                if timeout
                else ForwardSyncStatusChoices.FAILED
            )
        )
        if timeout:
            message = "Forward merge job timed out. Increase RQ worker timeout and rerun the merge."
            record_timeout_issue(
                ingestion,
                ForwardIngestionPhaseChoices.MERGE,
                message,
            )
            ingestion.sync.logger.log_failure(message, obj=ingestion)
        if type(exc) in (SyncError, JobTimeoutException):
            logger.error(exc)
        else:
            raise
