"""Local inference backend using llama-cpp-python."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import uuid
from pathlib import Path
from typing import Any

from natshell.inference.engine import CompletionResult, EngineInfo, ToolCall

logger = logging.getLogger(__name__)

# Regex to match <tool_call>{"name": ..., "arguments": ...}</tool_call> blocks
_TOOL_CALL_RE = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.DOTALL)
# Regex to match [TOOL_CALLS] JSON array (Mistral style)
_MISTRAL_TOOL_CALLS_RE = re.compile(r"\[TOOL_CALLS\]\s*(\[.*?\])", re.DOTALL)
# Regex to extract JSON from markdown code fences (Mistral sometimes wraps tool calls)
_CODE_FENCE_JSON_RE = re.compile(
    r"```(?:json)?\s*\n?\s*(\{.*?\}|\[.*?\])\s*\n?\s*```", re.DOTALL
)
# Regex to match <think>...</think> blocks (including empty ones)
_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)
# Regex to match unclosed <think> blocks (truncated responses)
_THINK_UNCLOSED_RE = re.compile(r"<think>(?:(?!</think>).)*$", re.DOTALL)
# Gemma 4 tool call: <|tool_call>call:NAME{...}<tool_call|>
_GEMMA_TOOL_CALL_RE = re.compile(
    r"<\|tool_call>call:(\w+)\{(.*?)\}<tool_call\|>", re.DOTALL
)
# Gemma 4 think blocks: <|channel>thought...<channel|>
_GEMMA_THINK_RE = re.compile(r"<\|channel>.*?<channel\|>", re.DOTALL)
_GEMMA_THINK_UNCLOSED_RE = re.compile(
    r"<\|channel>(?:(?!<channel\|>).)*$", re.DOTALL
)


def _is_degenerate_output(text: str) -> bool:
    """Detect degenerate repetitive output from local models.

    Returns True when the output is dominated by a single repeated
    character, which indicates context exhaustion or model collapse.
    Only triggers on outputs longer than 100 characters to avoid
    false positives on short valid responses.
    """
    if len(text) < 100:
        return False
    non_ws = text.replace(" ", "").replace("\n", "").replace("\t", "")
    if not non_ws:
        return False
    from collections import Counter

    counts = Counter(non_ws)
    _char, top_count = counts.most_common(1)[0]
    return top_count / len(non_ws) > 0.5


def _gemma_escape(value: str) -> str:
    """Wrap a string value with Gemma's <|"|> delimiter."""
    return f'<|"|>{value}<|"|>'


def _parse_gemma_tool_args(text: str) -> dict[str, Any]:
    """Parse Gemma 4 tool call arguments from ``key:<|"|>val<|"|>,key2:num`` format.

    String values are wrapped with ``<|"|>``; numeric and boolean values are bare.
    """
    args: dict[str, Any] = {}
    if not text.strip():
        return args

    # Split on top-level commas that are outside <|"|>...<|"|> delimiters
    parts: list[str] = []
    current: list[str] = []
    inside_string = False
    i = 0
    while i < len(text):
        if text[i:].startswith('<|"|>'):
            inside_string = not inside_string
            current.append('<|"|>')
            i += 5
        elif text[i] == "," and not inside_string:
            parts.append("".join(current))
            current = []
            i += 1
        else:
            current.append(text[i])
            i += 1
    if current:
        parts.append("".join(current))

    for part in parts:
        colon = part.find(":")
        if colon == -1:
            continue
        key = part[:colon].strip()
        val_raw = part[colon + 1:].strip()

        # String value: strip <|"|> delimiters
        if '<|"|>' in val_raw:
            args[key] = val_raw.replace('<|"|>', '')
        else:
            # Numeric or boolean
            if val_raw.lower() == "true":
                args[key] = True
            elif val_raw.lower() == "false":
                args[key] = False
            else:
                try:
                    args[key] = int(val_raw)
                except ValueError:
                    try:
                        args[key] = float(val_raw)
                    except ValueError:
                        args[key] = val_raw
    return args


def _detect_model_family(model_path: str) -> str:
    """Detect the model family from the filename.

    Returns "mistral" for Mistral models, "gemma" for Gemma models,
    "qwen" for everything else.
    """
    name = Path(model_path).name.lower()
    if "mistral" in name:
        return "mistral"
    if "gemma" in name:
        return "gemma"
    if "qwen" not in name:
        logger.warning(
            "Unknown model family for %r — defaulting to qwen tool format. "
            "If tool calls fail, the model may need a custom parser.",
            Path(model_path).name,
        )
    return "qwen"


def _infer_context_size(model_path: str) -> int:
    """Infer an appropriate context size from the model filename.

    Looks for a parameter-count pattern like '4B', '8B', '1.7B' in the
    filename and maps it to a reasonable context size.
    Falls back to 4096 if no pattern is found.
    """
    name = Path(model_path).name.lower()
    # Mistral Nemo supports 128K; 32K default fits ~11 GB VRAM (integrated GPUs)
    if "mistral" in name and "nemo" in name:
        return 32768
    # Gemma 4: E2B/E4B support 128K, 26B-A4B/31B support 256K.
    # Conservative defaults to fit integrated GPUs.
    if "gemma" in name:
        if "e2b" in name or "e4b" in name:
            return 16384
        if "26b" in name or "31b" in name:
            return 32768
        return 16384
    match = re.search(r"(\d+(?:\.\d+)?)b", name)
    if match:
        param_billions = float(match.group(1))
        if param_billions <= 1:
            return 2048
        elif param_billions <= 4:
            return 4096
        elif param_billions <= 8:
            return 8192
        elif param_billions <= 14:
            return 16384
        else:
            return 32768
    return 4096


def _format_tool_entries(
    tools: list[dict[str, Any]], *, compact: bool = False
) -> list[str]:
    """Format tool entries (shared by Qwen and Mistral formatters).

    Returns a list of lines describing each tool's name, description,
    and parameters. The caller provides the header.
    """
    lines: list[str] = []
    for tool in tools:
        func = tool.get("function", {})
        name = func.get("name", "")
        desc = func.get("description", "")
        params = func.get("parameters", {})

        lines.append(f"## {name}")
        if compact:
            first_sentence = desc.split(". ")[0]
            if not first_sentence.endswith("."):
                first_sentence += "."
            lines.append(first_sentence)
        else:
            lines.append(desc)

        props = params.get("properties", {})
        required = params.get("required", [])
        if props:
            if not compact:
                lines.append("Parameters:")
            for pname, pdef in props.items():
                req = ", required" if pname in required else ""
                ptype = pdef.get("type", "")
                if compact:
                    enum_vals = pdef.get("enum")
                    if enum_vals:
                        enum_str = "|".join(str(v) for v in enum_vals)
                        lines.append(f"- {pname} ({enum_str}{req})")
                    else:
                        lines.append(f"- {pname} ({ptype}{req})")
                else:
                    pdesc = pdef.get("description", "")
                    lines.append(f"- {pname} ({ptype}{req}): {pdesc}")
        lines.append("")
    return lines


def _format_tools_for_prompt(
    tools: list[dict[str, Any]], *, compact: bool = False
) -> str:
    """Format tool schemas as plain text for injection into the system prompt.

    This is used instead of llama-cpp-python's built-in tool handling because
    Qwen3 models don't follow the chatml-function-calling response format.

    Args:
        tools: Tool schemas in OpenAI-compatible format.
        compact: When True, use abbreviated descriptions and parameter lists
            to reduce token usage on small context windows (≤16K).
    """
    if compact:
        header = [
            "# Available Tools",
            "You MUST use the <tool_call> format to call tools.",
            "NEVER substitute pseudocode or Python scripts for tool calls.",
            '<tool_call>{"name": "tool_name", "arguments": {...}}</tool_call>',
            "",
        ]
    else:
        header = [
            "# Available Tools",
            "",
            "You MUST use tools to perform actions. To call a tool, output:",
            "",
            "<tool_call>",
            '{"name": "tool_name", "arguments": {"param": "value"}}',
            "</tool_call>",
            "",
        ]
    return "\n".join(header + _format_tool_entries(tools, compact=compact))


def _format_tools_for_prompt_mistral(
    tools: list[dict[str, Any]], *, compact: bool = False
) -> str:
    """Format tool schemas for Mistral models.

    Mistral models use [TOOL_CALLS] followed by a JSON array instead of XML tags.

    Args:
        tools: Tool schemas in OpenAI-compatible format.
        compact: When True, use abbreviated descriptions and parameter lists.
    """
    if compact:
        header = [
            "# Available Tools",
            "You MUST call tools using the exact format below.",
            "Do NOT describe commands in prose — call the tool directly.",
            "NEVER wrap tool calls in markdown code fences.",
            '[TOOL_CALLS] [{"name": "tool_name", "arguments": {...}}]',
            "",
        ]
    else:
        header = [
            "# Available Tools",
            "",
            "You MUST use tools to perform actions. To call a tool, output:",
            "",
            '[TOOL_CALLS] [{"name": "tool_name", "arguments": {"param": "value"}}]',
            "",
            "Do NOT describe commands in prose — call the tool directly.",
            "NEVER wrap tool calls in markdown code fences.",
            "You can call multiple tools at once by including multiple objects in the array.",
            "",
        ]
    return "\n".join(header + _format_tool_entries(tools, compact=compact))


def _format_tools_for_prompt_gemma(
    tools: list[dict[str, Any]], *, compact: bool = False
) -> str:
    """Format tool schemas for Gemma 4 models.

    Gemma 4 uses ``<|tool>declaration:NAME{...}<tool|>`` blocks with
    ``<|"|>`` string delimiters instead of JSON.

    Args:
        tools: Tool schemas in OpenAI-compatible format.
        compact: When True, use abbreviated descriptions.
    """
    esc = _gemma_escape

    if compact:
        header = [
            "# Available Tools",
            "You MUST call tools using the exact format below.",
            "<|tool_call>call:tool_name{param:" + esc("value") + "}<tool_call|>",
            "",
        ]
    else:
        header = [
            "# Available Tools",
            "",
            "You MUST use tools to perform actions. To call a tool, output:",
            "",
            "<|tool_call>call:tool_name{param:" + esc("value") + "}<tool_call|>",
            "",
            "String values MUST be wrapped with <|\"|> delimiters.",
            "You can call multiple tools by outputting multiple <|tool_call> blocks.",
            "",
        ]

    lines: list[str] = list(header)
    for tool in tools:
        func = tool.get("function", {})
        name = func.get("name", "")
        desc = func.get("description", "")
        params = func.get("parameters", {})

        if compact:
            first_sentence = desc.split(". ")[0]
            if not first_sentence.endswith("."):
                first_sentence += "."
            desc = first_sentence

        # Build the <|tool>declaration:...<tool|> block
        props = params.get("properties", {})
        required = params.get("required", [])

        prop_parts: list[str] = []
        for pname, pdef in props.items():
            ptype = pdef.get("type", "string")
            pdesc = pdef.get("description", "")
            if compact:
                prop_parts.append(
                    f"{pname}:{{type:{esc(ptype)}}}"
                )
            else:
                prop_parts.append(
                    f"{pname}:{{type:{esc(ptype)},description:{esc(pdesc)}}}"
                )

        req_parts = ",".join(esc(r) for r in required)
        props_str = ",".join(prop_parts)

        decl = (
            f"<|tool>declaration:{name}{{"
            f"description:{esc(desc)},"
            f"parameters:{{properties:{{{props_str}}},"
            f"required:[{req_parts}],"
            f"type:{esc('object')}}}"
            f"}}<tool|>"
        )
        lines.append(decl)

    return "\n".join(lines)


class LocalEngine:
    """LLM inference via bundled llama.cpp (llama-cpp-python)."""

    def __init__(
        self,
        model_path: str,
        n_ctx: int = 0,
        n_threads: int = 0,
        n_gpu_layers: int = 0,
        main_gpu: int = -1,
        prompt_cache: bool = True,
        prompt_cache_mb: int = 256,
    ) -> None:
        from llama_cpp import Llama

        if n_ctx <= 0:
            n_ctx = _infer_context_size(model_path)

        # Resolve main_gpu: -1 means auto-detect best GPU
        from natshell.gpu import best_gpu_index, gpu_backend_available

        resolved_gpu = main_gpu
        if main_gpu == -1 and n_gpu_layers != 0 and gpu_backend_available():
            resolved_gpu = best_gpu_index()
            if resolved_gpu != 0:
                logger.info(f"Auto-selected GPU device {resolved_gpu}")

        self.model_path = model_path
        self.model_family = _detect_model_family(model_path)
        self.n_ctx = n_ctx
        self.n_gpu_layers = n_gpu_layers
        self.main_gpu = resolved_gpu
        self._configured_main_gpu = main_gpu  # preserve -1 for "auto" display

        llama_kwargs: dict[str, Any] = {
            "model_path": model_path,
            "n_ctx": n_ctx,
            "n_threads": n_threads or os.cpu_count() or 4,
            "n_gpu_layers": n_gpu_layers,
            "verbose": False,
        }
        if resolved_gpu > 0 and gpu_backend_available():
            llama_kwargs["main_gpu"] = resolved_gpu

        self.llm = Llama(**llama_kwargs)

        # Enable RAM-based prompt cache for faster repeated prefixes
        if prompt_cache:
            try:
                from llama_cpp import LlamaRAMCache

                self.llm.set_cache(
                    LlamaRAMCache(capacity_bytes=prompt_cache_mb * 1024 * 1024)
                )
                logger.info("Prompt cache enabled (%d MB)", prompt_cache_mb)
            except (ImportError, AttributeError, Exception) as exc:
                logger.debug("Prompt cache unavailable: %s", exc)

        if n_gpu_layers != 0:
            try:
                from llama_cpp import llama_supports_gpu_offload

                if not llama_supports_gpu_offload():
                    logger.warning(
                        "GPU layers requested but llama-cpp-python"
                        " has no GPU support — running on CPU"
                    )
            except ImportError:
                pass
        logger.info(
            "Loaded model: %s (ctx=%d, threads=%d, main_gpu=%d)",
            model_path, n_ctx, n_threads, resolved_gpu,
        )

    def count_tokens(self, text: str) -> int:
        """Count tokens in text using the model's tokenizer."""
        return len(self.llm.tokenize(text.encode("utf-8")))

    def engine_info(self) -> EngineInfo:
        return EngineInfo(
            engine_type="local",
            model_name=Path(self.model_path).name,
            n_ctx=self.n_ctx,
            n_gpu_layers=self.n_gpu_layers,
            main_gpu=self._configured_main_gpu,  # -1 = auto; resolved value used for llama
            resolved_main_gpu=self.main_gpu,
        )

    def _normalize_messages_strict_alternation(
        self, messages: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Normalize messages for strict role-alternation (Mistral, Gemma 4).

        These models' chat templates require: system? → (user → assistant)*.
        Two passes fix violations:

        Pass 1: Fold mid-conversation system messages into the initial system
        message (the template only allows one system message at position 0).

        Pass 2: Merge consecutive same-role messages. This happens when e.g.
        /cmd appends a user message with command output and then the next user
        input appends another user message. Never merge assistant messages that
        carry tool_calls, and never merge or touch tool-role messages.
        """
        # --- Pass 1: fold mid-conversation system messages ---
        pass1: list[dict[str, Any]] = []
        system_extras: list[str] = []

        for msg in messages:
            if msg["role"] == "system" and pass1:
                system_extras.append(msg["content"])
            else:
                pass1.append(msg)

        if system_extras and pass1 and pass1[0]["role"] == "system":
            merged = pass1[0]["content"] + "\n\n" + "\n\n".join(system_extras)
            pass1[0] = {**pass1[0], "content": merged}

        # --- Pass 2: merge consecutive same-role messages ---
        result: list[dict[str, Any]] = []
        for msg in pass1:
            role = msg["role"]
            if (
                result
                and role == result[-1]["role"]
                and role in ("user", "assistant")
                and "tool_calls" not in msg
                and "tool_calls" not in result[-1]
            ):
                result[-1] = {
                    **result[-1],
                    "content": result[-1]["content"] + "\n\n" + msg["content"],
                }
            else:
                result.append(msg)

        return result

    async def chat_completion(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        max_tokens: int = 2048,
    ) -> CompletionResult:
        """Run chat completion via llama.cpp. Runs in thread to avoid blocking.

        Tool definitions are injected as plain text into the system prompt
        rather than relying on llama-cpp-python's tool handling, which doesn't
        work correctly with Qwen3 models.
        """
        if self.model_family in ("mistral", "gemma"):
            messages = self._normalize_messages_strict_alternation(messages)

        if tools:
            messages = self._inject_tools(messages, tools)

        kwargs: dict[str, Any] = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "repeat_penalty": 1.1,
        }

        # llama-cpp-python's create_chat_completion is synchronous
        try:
            response = await asyncio.to_thread(self.llm.create_chat_completion, **kwargs)
        except ValueError as e:
            err_str = str(e).lower()
            if "context window" in err_str or "exceed" in err_str:
                from natshell.inference.remote import ContextOverflowError

                raise ContextOverflowError(
                    f"Prompt exceeds local model context window ({self.n_ctx} tokens): {e}"
                ) from e
            raise

        return self._parse_response(response)

    def _inject_tools(
        self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Inject tool definitions into the system message as plain text."""
        compact = self.n_ctx < 16384
        if self.model_family == "mistral":
            tool_text = _format_tools_for_prompt_mistral(tools, compact=compact)
        elif self.model_family == "gemma":
            tool_text = _format_tools_for_prompt_gemma(tools, compact=compact)
        else:
            tool_text = _format_tools_for_prompt(tools, compact=compact)

        # Shallow-copy the list and deep-copy only the system message
        messages = list(messages)
        for i, msg in enumerate(messages):
            if msg["role"] == "system":
                messages[i] = {**msg, "content": msg["content"] + "\n\n" + tool_text}
                break

        return messages

    def _parse_response(self, response: dict) -> CompletionResult:
        """Parse llama-cpp-python response into our CompletionResult.

        Qwen3 models output <tool_call> XML tags in the content field rather
        than using the structured tool_calls field. This method extracts those
        tool calls and strips <think> blocks from content.
        """
        choice = response["choices"][0]
        message = choice["message"]
        finish_reason = choice.get("finish_reason", "stop")

        content = message.get("content") or ""
        tool_calls: list[ToolCall] = []

        # First, check for structured tool_calls (standard OpenAI format)
        if message.get("tool_calls"):
            for tc in message["tool_calls"]:
                func = tc.get("function", {})
                try:
                    args = json.loads(func.get("arguments", "{}"))
                except json.JSONDecodeError:
                    args = {}

                tool_calls.append(
                    ToolCall(
                        id=tc.get("id", str(uuid.uuid4())[:9]),
                        name=func.get("name", ""),
                        arguments=args,
                    )
                )

        # Parse <tool_call> XML tags from content (Qwen3 style)
        if not tool_calls:
            for match in _TOOL_CALL_RE.finditer(content):
                try:
                    parsed = json.loads(match.group(1))
                    name = parsed.get("name", "")
                    arguments = parsed.get("arguments", {})
                    if isinstance(arguments, str):
                        arguments = json.loads(arguments)
                    tool_calls.append(
                        ToolCall(
                            id=str(uuid.uuid4())[:9],
                            name=name,
                            arguments=arguments,
                        )
                    )
                except (json.JSONDecodeError, KeyError):
                    logger.warning("Failed to parse tool_call from content: %s", match.group(0))

        # Parse <|tool_call>call:NAME{...}<tool_call|> from content (Gemma 4 style)
        if not tool_calls:
            for match in _GEMMA_TOOL_CALL_RE.finditer(content):
                name = match.group(1)
                args_text = match.group(2)
                try:
                    arguments = _parse_gemma_tool_args(args_text)
                except Exception:
                    logger.warning(
                        "Failed to parse Gemma tool_call args: %s", match.group(0)
                    )
                    arguments = {}
                tool_calls.append(
                    ToolCall(
                        id=str(uuid.uuid4())[:9],
                        name=name,
                        arguments=arguments,
                    )
                )

        # Parse [TOOL_CALLS] JSON array from content (Mistral style)
        if not tool_calls:
            mistral_match = _MISTRAL_TOOL_CALLS_RE.search(content)
            if mistral_match:
                try:
                    calls = json.loads(mistral_match.group(1))
                    for call in calls:
                        name = call.get("name", "")
                        if "arguments" in call:
                            arguments = call.get("arguments", {})
                            if isinstance(arguments, str):
                                arguments = json.loads(arguments)
                        else:
                            # Flat format: args at top level alongside "name"
                            arguments = {
                                k: v for k, v in call.items() if k != "name"
                            }
                        tool_calls.append(
                            ToolCall(
                                id=str(uuid.uuid4())[:9],
                                name=name,
                                arguments=arguments,
                            )
                        )
                except (json.JSONDecodeError, KeyError):
                    logger.warning(
                        "Failed to parse [TOOL_CALLS] from content: %s",
                        mistral_match.group(0),
                    )

        # Fallback: Mistral forgot the [TOOL_CALLS] prefix but emitted valid JSON.
        # Accept bare JSON at the start of content, or inside markdown code fences.
        # Handles three Mistral variants:
        #   1. {"name": "tool", "arguments": {"key": "val"}}  — standard
        #   2. {"name": "tool"}                                — no arguments
        #   3. {"name": "tool", "key": "val"}                  — flat (args at top level)
        _bare_json_recovered = False
        if not tool_calls and self.model_family == "mistral":
            json_text = None

            # Strategy A: bare JSON at start of content
            stripped = content.strip()
            if stripped.startswith(("{", "[")):
                json_text = stripped

            # Strategy B: JSON inside markdown code fences
            if json_text is None:
                fence_match = _CODE_FENCE_JSON_RE.search(content)
                if fence_match:
                    json_text = fence_match.group(1)

            if json_text is not None:
                try:
                    parsed = json.loads(json_text)
                    candidates = parsed if isinstance(parsed, list) else [parsed]
                    if all(isinstance(c, dict) and "name" in c for c in candidates):
                        for call in candidates:
                            if "arguments" in call:
                                # Standard format: {"name": ..., "arguments": {...}}
                                arguments = call["arguments"]
                                if isinstance(arguments, str):
                                    arguments = json.loads(arguments)
                            else:
                                # Flat format: args at top level alongside "name"
                                arguments = {
                                    k: v for k, v in call.items() if k != "name"
                                }
                            tool_calls.append(
                                ToolCall(
                                    id=str(uuid.uuid4())[:9],
                                    name=call["name"],
                                    arguments=arguments,
                                )
                            )
                        _bare_json_recovered = True
                        logger.debug(
                            "Recovered %d bare-JSON Mistral tool call(s) "
                            "(missing [TOOL_CALLS] prefix)",
                            len(tool_calls),
                        )
                except (json.JSONDecodeError, KeyError):
                    pass

        # Strip think blocks, tool call markers, and Gemma channel blocks from content
        content = _THINK_RE.sub("", content)
        content = _THINK_UNCLOSED_RE.sub("", content)  # handle truncated think blocks
        content = _GEMMA_THINK_RE.sub("", content)
        content = _GEMMA_THINK_UNCLOSED_RE.sub("", content)
        content = _TOOL_CALL_RE.sub("", content)
        content = _GEMMA_TOOL_CALL_RE.sub("", content)
        content = _MISTRAL_TOOL_CALLS_RE.sub("", content)

        # Strip recovered bare JSON / code-fenced JSON so it doesn't leak to UI
        if _bare_json_recovered:
            content = _CODE_FENCE_JSON_RE.sub("", content)
            # If remaining content is bare JSON matching a tool call, clear it
            remaining = content.strip()
            if remaining.startswith(("{", "[")):
                try:
                    parsed = json.loads(remaining)
                    candidates = parsed if isinstance(parsed, list) else [parsed]
                    if all(
                        isinstance(c, dict) and "name" in c and "arguments" in c
                        for c in candidates
                    ):
                        content = ""
                except (json.JSONDecodeError, KeyError, TypeError):
                    pass

        content = content.strip() or None

        degenerate = False
        if content and _is_degenerate_output(content):
            logger.warning(
                "Degenerate output detected (%d chars, dominated by "
                "repeated characters) — suppressing garbage output",
                len(content),
            )
            content = None
            degenerate = True

        usage = response.get("usage", {})
        return CompletionResult(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            degenerate=degenerate,
        )
