from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class KernelNode:
    key: str
    depends_on: tuple[str, ...] = ()


def validate_graph(nodes: list[KernelNode]) -> None:
    keys = [node.key for node in nodes]
    if len(keys) != len(set(keys)):
        raise ValueError("node keys must be unique")
    known = set(keys)
    for node in nodes:
        missing = set(node.depends_on) - known
        if missing:
            raise ValueError(f"unknown dependencies for {node.key}: {sorted(missing)}")


def prerequisites(nodes: list[KernelNode], key: str) -> list[str]:
    validate_graph(nodes)
    mapping = {node.key: node for node in nodes}
    seen: set[str] = set()

    def visit(current: str) -> None:
        for dep in mapping[current].depends_on:
            if dep not in seen:
                seen.add(dep)
                visit(dep)

    visit(key)
    return sorted(seen)


def execution_order(nodes: list[KernelNode]) -> list[str]:
    validate_graph(nodes)
    mapping = {node.key: set(node.depends_on) for node in nodes}
    ready = sorted([key for key, deps in mapping.items() if not deps])
    order: list[str] = []
    while ready:
        current = ready.pop(0)
        order.append(current)
        for key, deps in mapping.items():
            if current in deps:
                deps.remove(current)
                if not deps and key not in order and key not in ready:
                    ready.append(key)
        ready.sort()
    if len(order) != len(nodes):
        raise ValueError("kernel graph contains a cycle")
    return order

