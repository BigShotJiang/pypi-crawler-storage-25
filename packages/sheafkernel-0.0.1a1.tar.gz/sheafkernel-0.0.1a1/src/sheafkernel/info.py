def project_info() -> dict[str, str]:
    return {
        "name": "sheafkernel",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheafkernel-python",
    }

