import unittest

from sheafkernel import KernelNode, execution_order, prerequisites, validate_graph


class GraphTests(unittest.TestCase):
    def setUp(self) -> None:
        self.nodes = [
            KernelNode("base"),
            KernelNode("meaning", ("base",)),
            KernelNode("trace", ("meaning",)),
        ]

    def test_validate_graph(self) -> None:
        validate_graph(self.nodes)

    def test_prerequisites(self) -> None:
        self.assertEqual(prerequisites(self.nodes, "trace"), ["base", "meaning"])

    def test_execution_order(self) -> None:
        self.assertEqual(execution_order(self.nodes), ["base", "meaning", "trace"])

