# sheafkernel

`sheafkernel` is the official Python package namespace for lightweight kernel
graph helpers used by the SheafLab project.

This initial public release provides a compact but real core: describing node
dependencies, validating graph references, computing transitive prerequisites,
and producing a deterministic execution order.

