# NetSight

[![CI](https://github.com/magicboxlab-ai/netsight-sdk/actions/workflows/ci.yml/badge.svg)](https://github.com/magicboxlab-ai/netsight-sdk/actions/workflows/ci.yml)
[![PyPI](https://img.shields.io/pypi/v/netsight-sdk)](https://pypi.org/project/netsight-sdk/)
[![Python](https://img.shields.io/pypi/pyversions/netsight-sdk)](https://pypi.org/project/netsight-sdk/)
[![License](https://img.shields.io/github/license/magicboxlab-ai/netsight-sdk)](LICENSE)

**NetSight** is a read-only, multi-vendor network device query SDK written in Python 3.14. It connects to devices over vendor-native APIs (currently PAN-OS XML; more vendors planned), enforces a deny-all command allowlist, and returns structured data parsed from declarative YAML parser specs.

## For users

See the [**User Guide**](https://github.com/magicboxlab-ai/netsight-sdk/blob/main/docs/guides/user-guide.md) for installation, configuration, and day-to-day SDK usage — connecting to a device, running an operation, handling results, writing a template workflow.

```python
from netsight import NetSight

ns = NetSight(config="config/devices.yaml")
device = ns.device("fw-01")
info = device.show_system_info()
routes = device.show_routing_table()
```

### Installing the core SDK

```sh
# Minimal SDK install — just the device-query core
pip install netsight-sdk

# With the dev MCP server (for Claude Code contributors)
pip install 'netsight-sdk[dev]'
```

Or, to track the development branch directly:

```sh
pip install git+https://github.com/magicboxlab-ai/netsight-sdk.git
```

### First-time setup

After installing the core SDK, run `netsight init` to create your device
configuration file:

```sh
# Create ~/.config/netsight/devices.yaml with a template
netsight init

# Edit the file to add your devices, then verify
netsight doctor
```

The config file search order is: `$NETSIGHT_CONFIG_DIR` → `./config/`
(cwd, for project-local dev workflows) → `$XDG_CONFIG_HOME/netsight/`
→ `~/.config/netsight/`.

### Installing vendor packs

The core SDK is vendor-agnostic. Vendor support ships as separate pack packages installed alongside the core. Use the `netsight pack` CLI to discover and install packs:

```sh
# List packs available in the bundled catalog
netsight pack list --available

# Install a pack
netsight pack install paloalto-firewall-xml

# Verify everything loaded correctly
netsight doctor
```

Packs can also be installed directly from their source repositories:

```sh
pip install git+https://github.com/magicboxlab-ai/netsight-packs-paloalto.git#subdirectory=packs/paloalto-firewall-xml
```

After installation, the pack is auto-discovered at startup via the `netsight.packs` entry-point group — no config change required.

See [**User Guide → Vendor packs**](https://github.com/magicboxlab-ai/netsight-sdk/blob/main/docs/guides/user-guide.md#vendor-packs) for the full install and configuration flow.

## For contributors

NetSight ships a purpose-built MCP server (`netsight-dev`) that exposes the codebase to Claude Code as structured resources and validation tools. The bootstrap flow for a new clone is documented end-to-end in the developer guide:

See [**Developer Guide → Getting Started for Development**](https://github.com/magicboxlab-ai/netsight-sdk/blob/main/docs/guides/developer-guide.md#getting-started-for-development).

**TL;DR:**

```sh
git clone <repo-url> netsight
cd netsight
python3.14 -m venv .venv
source .venv/bin/activate
pip install -e .
netsight init --local # creates ./config/devices.yaml from the template
netsight doctor       # verifies the dev env end-to-end
claude                # approve the netsight-dev MCP server when prompted
```

The rest of the developer guide covers adding vendor packs, writing parser specs, custom types and transforms, registry wiring, self-documentation conventions, testing, and the release workflow.

## Project layout at a glance

- `netsight/` — SDK source (pack registry, parsers, config management, security module, dev MCP server).
- `UNITTEST/` — pytest test suite (not `tests/`).
- `TOOLS/` — shell utilities (`full_test_cycle.sh`, `security_check.sh`).
- `docs/guides/` — user guide and developer guide.
