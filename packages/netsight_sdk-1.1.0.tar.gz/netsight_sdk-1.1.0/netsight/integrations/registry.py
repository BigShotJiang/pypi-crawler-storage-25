"""Integration registry for NetSight.

Provides :class:`IntegrationRegistry` — a central store for integration
adapters, sinks, and enrichment providers — and the module-level singleton
:data:`integration_registry` that the rest of the application imports to
register and look up integrations.

Integrations are grouped into three categories:

* ``"inventory"``    — :class:`~netsight.integrations.base.BaseInventoryAdapter` subclasses
* ``"sink"``         — :class:`~netsight.integrations.base.BaseOutputSink` subclasses
* ``"enrichment"``   — :class:`~netsight.integrations.base.BaseEnrichmentProvider` subclasses

Usage example::

    from netsight.integrations.registry import integration_registry
    from netsight.integrations.inventory.yaml_file import YAMLInventoryAdapter

    integration_registry.register(
        name="yaml_inventory",
        integration_class=YAMLInventoryAdapter,
        category="inventory",
        metadata={"source": "local_yaml"},
    )
    info = integration_registry.get("yaml_inventory")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class IntegrationInfo:
    """Metadata record for a single registered integration.

    Attributes
    ----------
    name:
        Unique integration identifier (matches the key in the registry).
    integration_class:
        The class that implements this integration.
    category:
        Integration category — one of ``"inventory"``, ``"sink"``, or
        ``"enrichment"``.
    metadata:
        Arbitrary key/value data supplied by the integration author.
    """

    name: str
    integration_class: type
    category: str
    metadata: dict[str, Any] = field(default_factory=dict)


class IntegrationRegistry:
    """Central registry of NetSight integrations.

    Each integration is identified by a unique *name* string and stored as an
    :class:`IntegrationInfo` record.  Duplicate names are rejected at
    registration time so that accidental re-imports or conflicting packages are
    caught early.

    The typical entry point is :data:`integration_registry`, the module-level
    singleton, but tests may construct independent :class:`IntegrationRegistry`
    instances for isolation.
    """

    def __init__(self) -> None:
        """Initialise an empty registry."""
        self._integrations: dict[str, IntegrationInfo] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(
        self,
        name: str,
        integration_class: type,
        category: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Register an integration under *name*.

        Parameters
        ----------
        name:
            Unique identifier for this integration.
        integration_class:
            The class that implements the integration.
        category:
            One of ``"inventory"``, ``"sink"``, or ``"enrichment"``.
        metadata:
            Optional free-form metadata dict.  Defaults to ``{}``.

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._integrations:
            raise ValueError(f"Integration '{name}' is already registered")

        info = IntegrationInfo(
            name=name,
            integration_class=integration_class,
            category=category,
            metadata=metadata if metadata is not None else {},
        )
        self._integrations[name] = info
        logger.info(
            "Integration registered: '%s' (category=%s, class=%s)",
            name,
            category,
            integration_class.__name__,
        )

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, name: str) -> IntegrationInfo:
        """Return the :class:`IntegrationInfo` for *name*.

        Parameters
        ----------
        name:
            The integration identifier to look up.

        Returns
        -------
        IntegrationInfo
            The :class:`IntegrationInfo` associated with *name*.

        Raises
        ------
        KeyError
            If no integration with *name* has been registered.
        """
        if name not in self._integrations:
            raise KeyError(name)
        return self._integrations[name]

    # ------------------------------------------------------------------
    # Listing
    # ------------------------------------------------------------------

    def list_by_category(self, category: str) -> list[IntegrationInfo]:
        """Return all integrations that belong to *category*.

        Parameters
        ----------
        category:
            The category to filter by (``"inventory"``, ``"sink"``, or
            ``"enrichment"``).

        Returns
        -------
        list[IntegrationInfo]
            A new list containing only integrations with matching *category*.
            Returns an empty list when no integrations match.
        """
        return [
            info
            for info in self._integrations.values()
            if info.category == category
        ]

    def list_all(self) -> list[IntegrationInfo]:
        """Return all registered integrations.

        Returns
        -------
        list[IntegrationInfo]
            A new list of all registered :class:`IntegrationInfo` objects.
            Modifications to the returned list do not affect the registry.
        """
        return list(self._integrations.values())


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

#: Global singleton registry.  Import this in integrations and application code::
#:
#:     from netsight.integrations.registry import integration_registry
integration_registry: IntegrationRegistry = IntegrationRegistry()
