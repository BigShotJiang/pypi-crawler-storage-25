"""JSON file output sink for NetSight.

Appends serialised operation results to a JSON array stored in a local file.
Each :meth:`JSONFileSink.send` call reads the existing array (or starts with
an empty one), appends the new entry, then writes the updated array back to
disk atomically.

Usage example::

    from netsight.integrations.sinks.json_file import JSONFileSink

    sink = JSONFileSink("output/results.json")
    sink.send(query_result)   # accepts QueryResult or dict
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from netsight.integrations.base import BaseOutputSink

logger = logging.getLogger(__name__)

# Import is done lazily inside send() to avoid a hard circular dependency at
# module load time, but we do want type-checking support.
try:
    from netsight.data.models import QueryResult as _QueryResult
except ImportError:  # pragma: no cover
    _QueryResult = None  # type: ignore[assignment,misc]


class JSONFileSink(BaseOutputSink):
    """Output sink that appends results to a JSON array file.

    If the file does not exist it is created together with any missing parent
    directories.  If the file exists and already contains a valid JSON array,
    new entries are appended.  If the file is empty or contains non-array JSON,
    it is treated as an empty array.

    Parameters
    ----------
    output_path:
        Path (``str``) to the target JSON file.
    """

    def __init__(self, output_path: str) -> None:
        self.output_path = output_path

    # ------------------------------------------------------------------
    # BaseOutputSink interface
    # ------------------------------------------------------------------

    def send(self, result: Any) -> None:
        """Append *result* to the JSON array at :attr:`output_path`.

        Accepted types:

        * :class:`~netsight.data.models.QueryResult` — serialised via
          ``result.to_dict()``.
        * ``dict`` — appended as-is.
        * Any other type — converted via ``str(result)`` and stored under
          a ``{"value": ...}`` key.

        Parent directories are created automatically if they do not exist.

        Parameters
        ----------
        result:
            The value to append to the output file.
        """
        output_path = Path(self.output_path)

        # Ensure parent directories exist.
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Read the existing array (or start fresh).
        existing: list[Any] = []
        if output_path.exists():
            raw = output_path.read_text(encoding="utf-8").strip()
            if raw:
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, list):
                        existing = parsed
                    else:
                        logger.warning(
                            "JSONFileSink: existing content at %s is not a JSON "
                            "array — starting a fresh array.",
                            output_path,
                        )
                except json.JSONDecodeError:
                    logger.warning(
                        "JSONFileSink: could not parse existing content at %s "
                        "as JSON — starting a fresh array.",
                        output_path,
                    )

        # Serialise the new entry.
        if _QueryResult is not None and isinstance(result, _QueryResult):
            entry: Any = result.to_dict()
        elif isinstance(result, dict):
            entry = result
        else:
            entry = {"value": str(result)}

        existing.append(entry)

        output_path.write_text(
            json.dumps(existing, indent=2, default=str),
            encoding="utf-8",
        )
        logger.debug("JSONFileSink: wrote %d entries to %s", len(existing), output_path)
