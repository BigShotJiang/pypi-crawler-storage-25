"""YAML file inventory adapter for NetSight.

Reads device configurations from a YAML file using
:class:`~netsight.config.ConfigLoader` and exposes them via the
:class:`~netsight.integrations.base.BaseInventoryAdapter` interface.

Usage example::

    from netsight.integrations.inventory.yaml_file import YAMLInventoryAdapter

    adapter = YAMLInventoryAdapter("config/devices.yaml")
    devices = adapter.get_devices()
    for device in devices:
        print(device.name, device.host)
"""

from __future__ import annotations

from netsight.config import ConfigLoader, DeviceConfig
from netsight.integrations.base import BaseInventoryAdapter


class YAMLInventoryAdapter(BaseInventoryAdapter):
    """Inventory adapter that sources devices from a YAML configuration file.

    Delegates all parsing and validation to
    :class:`~netsight.config.ConfigLoader`, which eagerly validates the file
    on construction and raises
    :class:`~netsight.exceptions.ConfigValidationError` on any problem.

    Parameters
    ----------
    config_path:
        Path (``str``) to the YAML devices file.

    Raises
    ------
    netsight.exceptions.ConfigValidationError
        If the file does not exist, is malformed, or contains an invalid
        device entry.
    """

    def __init__(self, config_path: str) -> None:
        self._loader = ConfigLoader(config_path)

    def get_devices(self) -> list[DeviceConfig]:
        """Return all devices defined in the YAML configuration file.

        Delegates to :meth:`~netsight.config.ConfigLoader.get_devices`, which
        returns a shallow copy of the internal device list.

        Returns
        -------
        list[DeviceConfig]
            Ordered list of device configuration records parsed from the
            YAML file.
        """
        return self._loader.get_devices()
