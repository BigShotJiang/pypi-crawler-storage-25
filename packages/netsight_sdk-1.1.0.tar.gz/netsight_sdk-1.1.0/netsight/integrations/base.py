"""Abstract base classes for the NetSight integration layer.

Each category of integration — inventory adapters, output sinks, and
enrichment providers — extends one of the ABCs defined here.  Concrete
implementations live in the appropriate sub-package
(``inventory/``, ``sinks/``, ``enrichment/``).

Usage example::

    from netsight.integrations.base import BaseInventoryAdapter

    class MyInventoryAdapter(BaseInventoryAdapter):
        def get_devices(self) -> list[DeviceConfig]:
            ...
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from netsight.config import DeviceConfig


class BaseInventoryAdapter(ABC):
    """Abstract base for inventory adapters.

    An inventory adapter is responsible for sourcing the list of
    :class:`~netsight.config.DeviceConfig` objects that NetSight should
    manage.  Concrete implementations may read from YAML files, a CMDB,
    a REST API, or any other source.
    """

    @abstractmethod
    def get_devices(self) -> list[DeviceConfig]:
        """Return all devices known to this adapter.

        Returns
        -------
        list[DeviceConfig]
            Ordered list of device configuration records.
        """


class BaseOutputSink(ABC):
    """Abstract base for output sinks.

    An output sink receives the result of a NetSight operation and
    persists or forwards it.  Examples include a JSON file sink, a
    database sink, or a message-queue publisher.
    """

    @abstractmethod
    def send(self, result: Any) -> None:
        """Persist or forward *result*.

        Parameters
        ----------
        result:
            The operation result to write out.  Implementations are
            responsible for serialising this value appropriately.
        """


class BaseEnrichmentProvider(ABC):
    """Abstract base for enrichment providers.

    An enrichment provider accepts a data dict and returns an augmented
    version of that dict with additional context.  Examples include
    GeoIP lookups, CMDB asset enrichment, or threat-intelligence lookups.
    """

    @abstractmethod
    def enrich(self, data: dict) -> dict:
        """Return an enriched copy of *data*.

        Parameters
        ----------
        data:
            The input mapping to enrich.

        Returns
        -------
        dict
            A new mapping containing the original keys plus any additional
            data added by this provider.
        """
