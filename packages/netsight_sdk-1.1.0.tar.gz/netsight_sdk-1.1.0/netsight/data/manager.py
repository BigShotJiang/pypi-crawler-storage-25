"""NetSight DataManager — high-level data access facade.

:class:`DataManager` wraps :class:`~netsight.data.store.SQLiteStore` and
provides the business-logic operations (snapshot creation, diff computation,
template management) that the rest of the SDK and API layers consume.

All callers should use ``DataManager`` rather than touching ``SQLiteStore``
directly.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from netsight.data.models import DiffResult, QueryResult, Snapshot, Template
from netsight.data.store import SQLiteStore


class DataManager:
    """High-level data access facade for NetSight persistence.

    Parameters
    ----------
    db_path:
        Filesystem path to the SQLite file (or ``":memory:"`` for tests).
    """

    def __init__(self, db_path: str | Path) -> None:
        self._store = SQLiteStore(db_path)

    # ------------------------------------------------------------------
    # QueryResult operations
    # ------------------------------------------------------------------

    def store(self, result: QueryResult) -> str:
        """Persist *result* and return its ``id``."""
        self._store.store_result(result)
        return result.id

    def get(self, result_id: str) -> QueryResult | None:
        """Return the :class:`~netsight.data.models.QueryResult` with *result_id*, or ``None``."""
        return self._store.get_result(result_id)

    def search(
        self,
        device_name: str | None = None,
        operation: str | None = None,
        limit: int = 100,
    ) -> list[QueryResult]:
        """Search stored query results.

        Parameters
        ----------
        device_name:
            Restrict to results from this device.
        operation:
            Restrict to results for this operation.
        limit:
            Maximum number of results to return (most recent first).
        """
        return self._store.search_results(
            device_name=device_name,
            operation=operation,
            limit=limit,
        )

    # ------------------------------------------------------------------
    # Snapshot operations
    # ------------------------------------------------------------------

    def create_snapshot(self, device_name: str, results: list[QueryResult]) -> Snapshot:
        """Create, persist, and return a new :class:`~netsight.data.models.Snapshot`.

        Parameters
        ----------
        device_name:
            Logical name of the device being snapshotted.
        results:
            Query results to include in the snapshot.
        """
        snapshot = Snapshot(device_name=device_name, results=results)
        self._store.store_snapshot(snapshot)
        return snapshot

    def get_snapshot(self, snapshot_id: str) -> Snapshot | None:
        """Return the :class:`~netsight.data.models.Snapshot` with *snapshot_id*, or ``None``."""
        return self._store.get_snapshot(snapshot_id)

    def list_snapshots(self, device_name: str | None = None) -> list[Snapshot]:
        """Return all snapshots, optionally filtered to *device_name*."""
        return self._store.list_snapshots(device_name=device_name)

    # ------------------------------------------------------------------
    # Diff operations
    # ------------------------------------------------------------------

    def diff(self, snapshot_a_id: str, snapshot_b_id: str) -> DiffResult:
        """Compare two snapshots and return a :class:`~netsight.data.models.DiffResult`.

        The diff inspects every operation present in either snapshot and
        reports per-operation changes as a dict with keys:

        * ``"added"``   — operations present in B but not A
        * ``"removed"`` — operations present in A but not B
        * ``"modified"`` — operations present in both where data differs

        Parameters
        ----------
        snapshot_a_id:
            ID of the *before* snapshot.
        snapshot_b_id:
            ID of the *after* snapshot.

        Raises
        ------
        KeyError
            If either snapshot ID is not found in the store.
        """
        snap_a = self._store.get_snapshot(snapshot_a_id)
        snap_b = self._store.get_snapshot(snapshot_b_id)

        if snap_a is None:
            raise KeyError(f"Snapshot not found: {snapshot_a_id!r}")
        if snap_b is None:
            raise KeyError(f"Snapshot not found: {snapshot_b_id!r}")

        # Build operation->data maps for quick lookup
        ops_a: dict[str, Any] = {r.operation: r.data for r in snap_a.results}
        ops_b: dict[str, Any] = {r.operation: r.data for r in snap_b.results}

        all_ops = set(ops_a) | set(ops_b)
        changes: dict[str, dict[str, Any]] = {}

        for op in sorted(all_ops):
            in_a = op in ops_a
            in_b = op in ops_b

            if in_b and not in_a:
                changes[op] = {"status": "added", "data": ops_b[op]}
            elif in_a and not in_b:
                changes[op] = {"status": "removed", "data": ops_a[op]}
            elif ops_a[op] != ops_b[op]:
                changes[op] = {
                    "status": "modified",
                    "before": ops_a[op],
                    "after": ops_b[op],
                }
            # If equal, omit — no change to report

        device_name = snap_a.device_name
        diff_result = DiffResult(
            device_name=device_name,
            snapshot_a_id=snapshot_a_id,
            snapshot_b_id=snapshot_b_id,
            changes=changes,
        )
        self._store.store_diff(diff_result)
        return diff_result

    # ------------------------------------------------------------------
    # Template operations
    # ------------------------------------------------------------------

    def save_template(self, template: Template) -> None:
        """Persist *template* (insert or replace)."""
        self._store.store_template(template)

    def get_template(self, name: str) -> Template | None:
        """Return the :class:`~netsight.data.models.Template` with *name*, or ``None``."""
        return self._store.get_template(name)

    def list_templates(self) -> list[Template]:
        """Return all stored templates ordered by name."""
        return self._store.list_templates()

    def delete_template(self, name: str) -> bool:
        """Delete the template named *name*.  Returns ``True`` if it existed."""
        return self._store.delete_template(name)

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def purge(self, older_than_days: int) -> int:
        """Delete data older than *older_than_days* days.

        Returns the number of ``QueryResult`` rows removed.
        """
        return self._store.purge(older_than_days)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Release the underlying SQLite connection."""
        self._store.close()

    def __enter__(self) -> "DataManager":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
