"""NetSight data models.

Immutable-ish dataclasses representing the core persistence entities used by
the SQLite store and DataManager.  Every model carries an auto-generated UUID
``id`` and a UTC ``timestamp`` so callers never have to supply either field.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _utcnow() -> datetime:
    """Return the current UTC time as a timezone-aware datetime."""
    return datetime.now(timezone.utc)


def _uuid() -> str:
    """Return a new random UUID4 as a string."""
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# QueryResult
# ---------------------------------------------------------------------------


@dataclass
class QueryResult:
    """The raw result of a single operation executed against a device.

    Attributes
    ----------
    device_name:
        Logical name of the device that was queried.
    operation:
        Name of the operation that was executed (e.g. ``"show_routes"``).
    data:
        Parsed response payload as a plain dict.
    timestamp:
        UTC datetime the result was captured.  Defaults to now.
    id:
        Unique identifier for this result.  Defaults to a new UUID4.
    """

    device_name: str
    operation: str
    data: dict[str, Any]
    timestamp: datetime = field(default_factory=_utcnow)
    id: str = field(default_factory=_uuid)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict suitable for JSON encoding."""
        return {
            "id": self.id,
            "device_name": self.device_name,
            "operation": self.operation,
            "data": self.data,
            "timestamp": self.timestamp.isoformat(),
        }


# ---------------------------------------------------------------------------
# Snapshot
# ---------------------------------------------------------------------------


@dataclass
class Snapshot:
    """A point-in-time collection of :class:`QueryResult` objects for one device.

    Attributes
    ----------
    device_name:
        Logical name of the device that was snapshotted.
    results:
        Ordered list of query results captured during this snapshot.
    timestamp:
        UTC datetime the snapshot was created.  Defaults to now.
    id:
        Unique identifier for this snapshot.  Defaults to a new UUID4.
    """

    device_name: str
    results: list[QueryResult]
    timestamp: datetime = field(default_factory=_utcnow)
    id: str = field(default_factory=_uuid)

    def get_result(self, operation: str) -> QueryResult | None:
        """Return the first :class:`QueryResult` matching *operation*, or ``None``."""
        for result in self.results:
            if result.operation == operation:
                return result
        return None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict suitable for JSON encoding."""
        return {
            "id": self.id,
            "device_name": self.device_name,
            "results": [r.to_dict() for r in self.results],
            "timestamp": self.timestamp.isoformat(),
        }


# ---------------------------------------------------------------------------
# DiffResult
# ---------------------------------------------------------------------------


@dataclass
class DiffResult:
    """The outcome of comparing two :class:`Snapshot` objects for the same device.

    Attributes
    ----------
    device_name:
        Logical name of the device whose snapshots were compared.
    snapshot_a_id:
        ID of the *before* snapshot.
    snapshot_b_id:
        ID of the *after* snapshot.
    changes:
        Mapping of operation name to a dict describing what changed.
        Structure is ``{"added": [...], "removed": [...], "modified": [...]}``.
    timestamp:
        UTC datetime the diff was computed.  Defaults to now.
    id:
        Unique identifier for this diff.  Defaults to a new UUID4.
    """

    device_name: str
    snapshot_a_id: str
    snapshot_b_id: str
    changes: dict[str, Any]
    timestamp: datetime = field(default_factory=_utcnow)
    id: str = field(default_factory=_uuid)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict suitable for JSON encoding."""
        return {
            "id": self.id,
            "device_name": self.device_name,
            "snapshot_a_id": self.snapshot_a_id,
            "snapshot_b_id": self.snapshot_b_id,
            "changes": self.changes,
            "timestamp": self.timestamp.isoformat(),
        }


# ---------------------------------------------------------------------------
# Template
# ---------------------------------------------------------------------------


@dataclass
class Template:
    """A named collection of operations that can be applied to a device.

    Attributes
    ----------
    name:
        Human-readable name for the template (e.g. ``"full_audit"``).
    operations:
        Ordered list of operation names that the template executes.
    description:
        Optional human-readable description.  Defaults to ``""``.
    id:
        Unique identifier for this template.  Defaults to a new UUID4.
    """

    name: str
    operations: list[str]
    description: str = ""
    id: str = field(default_factory=_uuid)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict suitable for JSON encoding."""
        return {
            "id": self.id,
            "name": self.name,
            "operations": self.operations,
            "description": self.description,
        }
