"""NetSight data layer — models, SQLite store, and DataManager.

This package provides the full persistence stack for NetSight:

* :mod:`netsight.data.models`  — Dataclass entities (QueryResult, Snapshot,
  DiffResult, Template) with auto-generated UUIDs and UTC timestamps.
* :mod:`netsight.data.store`   — :class:`~netsight.data.store.SQLiteStore`,
  a thin SQLite wrapper handling schema creation and typed CRUD operations.
* :mod:`netsight.data.manager` — :class:`~netsight.data.manager.DataManager`,
  the high-level facade used by the rest of the SDK (snapshot creation, diff
  computation, template management, purge).

Typical usage::

    from netsight.data.manager import DataManager
    from netsight.data.models import QueryResult

    with DataManager("/var/lib/netsight/data.db") as dm:
        result = QueryResult(device_name="fw-01", operation="show_routes", data={...})
        dm.store(result)
        snap = dm.create_snapshot("fw-01", [result])
"""
