"""NetSight — dual-mode SDK client.

:class:`NetSight` is the main entry point for SDK consumers.  It supports two
operating modes:

* **local** — connects directly to devices using
  :class:`~netsight.sdk.local.LocalBackend`.  Suitable for scripts,
  automation pipelines, and testing without a running API server.

* **remote** — delegates all operations to a running NetSight API server via
  :class:`~netsight.sdk.remote.RemoteBackend`.  Suitable for production
  deployments, web frontends, and multi-tenant environments.

Quick start (local mode)::

    from netsight import NetSight

    with NetSight.from_config("config/devices.yaml") as ns:
        for name in ns.list_devices():
            fw = ns.device(name=name)
            print(fw.show_system_info())

Quick start (remote mode)::

    from netsight import NetSight

    ns = NetSight.from_api("https://netsight.example.com", api_key="secret")
    fw = ns.device(name="fw-01")
    snap = fw.snapshot()
"""

from __future__ import annotations

import logging
from typing import Any

from netsight.sdk.device import DeviceHandle

logger = logging.getLogger(__name__)


class NetSight:
    """Dual-mode SDK client for the NetSight platform.

    This class should not normally be instantiated directly.  Use the
    :meth:`from_config` or :meth:`from_api` class methods instead.

    Parameters
    ----------
    backend:
        A backend instance (either :class:`~netsight.sdk.local.LocalBackend`
        or :class:`~netsight.sdk.remote.RemoteBackend`, or any object that
        implements the backend protocol).
    mode:
        Operating mode string — either ``"local"`` or ``"remote"``.
    """

    def __init__(self, *, backend: Any, mode: str) -> None:
        self._backend = backend
        self._mode = mode

    # ------------------------------------------------------------------
    # Factory class methods
    # ------------------------------------------------------------------

    @classmethod
    def from_config(
        cls,
        config_path: str = "config/devices.yaml",
        db_path: str = "storage/netsight.db",
    ) -> "NetSight":
        """Create a :class:`NetSight` client that connects directly to devices.

        This factory instantiates a :class:`~netsight.sdk.local.LocalBackend`
        using the supplied configuration and database paths, then returns a
        ``NetSight`` instance in ``"local"`` mode.

        Parameters
        ----------
        config_path:
            Path to the ``devices.yaml`` configuration file.
            Defaults to ``"config/devices.yaml"``.
        db_path:
            Path to the SQLite persistence database.
            Defaults to ``"storage/netsight.db"``.  Pass ``":memory:"`` to
            use an in-memory database (useful for testing).

        Returns
        -------
        NetSight
            A configured client in ``"local"`` mode.
        """
        from netsight.sdk.local import LocalBackend

        backend = LocalBackend(config_path, db_path=db_path)
        logger.info(
            "NetSight.from_config: created local client (config=%s, db=%s)",
            config_path,
            db_path,
        )
        return cls(backend=backend, mode="local")

    @classmethod
    def from_api(
        cls,
        base_url: str,
        api_key: str,
        timeout: int = 30,
    ) -> "NetSight":
        """Create a :class:`NetSight` client that delegates to an API server.

        This factory instantiates a :class:`~netsight.sdk.remote.RemoteBackend`
        pointed at *base_url*, then returns a ``NetSight`` instance in
        ``"remote"`` mode.

        Parameters
        ----------
        base_url:
            Base URL of the NetSight API server
            (e.g. ``"https://netsight.example.com"``).
        api_key:
            API key used for every request via the ``X-API-Key`` header.
        timeout:
            HTTP request timeout in seconds.  Defaults to ``30``.

        Returns
        -------
        NetSight
            A configured client in ``"remote"`` mode.
        """
        from netsight.sdk.remote import RemoteBackend

        backend = RemoteBackend(base_url, api_key=api_key, timeout=timeout)
        logger.info(
            "NetSight.from_api: created remote client (base_url=%s)", base_url
        )
        return cls(backend=backend, mode="remote")

    # ------------------------------------------------------------------
    # Device access
    # ------------------------------------------------------------------

    def device(self, *, name: str) -> DeviceHandle:
        """Return a :class:`~netsight.sdk.device.DeviceHandle` for *name*.

        The returned handle is bound to this client's backend so all
        operations are routed through the same local or remote transport.

        Parameters
        ----------
        name:
            The logical device name as defined in the configuration.

        Returns
        -------
        DeviceHandle
            A handle for the named device.
        """
        return DeviceHandle(name, self._backend)

    def list_devices(self) -> list[str]:
        """Return the names of all devices known to the backend.

        Delegates to ``backend.list_devices()``.

        Returns
        -------
        list[str]
            Device names in the order returned by the backend.
        """
        return self._backend.list_devices()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Release resources held by the backend.

        Calls ``backend.close()`` if that method exists.  Safe to call
        multiple times.
        """
        if hasattr(self._backend, "close"):
            self._backend.close()
            logger.info("NetSight.close: backend closed (mode=%s)", self._mode)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "NetSight":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"NetSight(mode={self._mode!r}, "
            f"backend={type(self._backend).__name__})"
        )
