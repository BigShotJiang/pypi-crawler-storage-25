"""RemoteBackend — HTTP client to a running NetSight API server.

:class:`RemoteBackend` implements the same backend protocol as
:class:`~netsight.sdk.local.LocalBackend` but delegates all operations to a
remote NetSight API server over HTTP.  This is the appropriate backend for
production deployments, web frontends, and multi-tenant environments.

Usage::

    from netsight.sdk.remote import RemoteBackend
    from netsight.sdk.device import DeviceHandle

    backend = RemoteBackend("https://netsight.example.com", api_key="secret")
    fw = DeviceHandle("fw-01", backend)
    info = fw.show_system_info()
"""

from __future__ import annotations

import logging
from typing import Any

import requests

logger = logging.getLogger(__name__)


class RemoteBackend:
    """HTTP client backend that delegates to a NetSight API server.

    Parameters
    ----------
    base_url:
        Base URL of the NetSight API server (e.g. ``"https://netsight.example.com"``).
        Must not include a trailing slash or ``/api/v1`` prefix.
    api_key:
        API key used to authenticate every request via the ``X-API-Key`` header.
    timeout:
        HTTP request timeout in seconds.  Defaults to ``30``.
    """

    def __init__(self, base_url: str, api_key: str, timeout: int = 30) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._headers: dict[str, str] = {
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _api_url(self, path: str) -> str:
        """Construct a full API URL for *path*.

        Parameters
        ----------
        path:
            API path beginning with ``/`` (e.g. ``"/devices/fw-01/info"``).

        Returns
        -------
        str
            Absolute URL including the ``/api/v1`` prefix.
        """
        return f"{self._base_url}/api/v1{path}"

    def _check_response(self, resp_data: dict[str, Any]) -> None:
        """Raise :class:`RuntimeError` if *resp_data* indicates an API error.

        The NetSight API uses an envelope format with a ``status`` field.
        A value of ``"error"`` signals a server-side problem.

        Parameters
        ----------
        resp_data:
            Parsed JSON response from the API server.

        Raises
        ------
        RuntimeError
            If ``resp_data["status"] == "error"``.
        """
        if resp_data.get("status") == "error":
            message = resp_data.get("message") or resp_data.get("detail") or "API error"
            raise RuntimeError(f"NetSight API error: {message}")

    # ------------------------------------------------------------------
    # Backend protocol
    # ------------------------------------------------------------------

    def execute(self, device_name: str, operation: str, params: Any = None) -> Any:
        """Execute *operation* on *device_name* via a POST to the API server.

        Parameters
        ----------
        device_name:
            Logical name of the target device.
        operation:
            Operation string to execute.
        params:
            Optional parameters sent as the JSON request body.

        Returns
        -------
        Any
            The ``data`` field of the API response envelope.

        Raises
        ------
        RuntimeError
            If the API server returns an error status.
        requests.HTTPError
            If the HTTP response has a 4xx or 5xx status code.
        """
        url = self._api_url(f"/devices/{device_name}/execute")
        logger.info(
            "RemoteBackend.execute POST %s op=%s", url, operation
        )
        resp = requests.post(
            url,
            params={"operation": operation},
            json=params,
            headers=self._headers,
            timeout=self._timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        self._check_response(data)
        return data.get("data", data)

    def get_device_info(self, device_name: str) -> dict:
        """Retrieve metadata for *device_name* from the API server.

        Parameters
        ----------
        device_name:
            Logical name of the device.

        Returns
        -------
        dict
            Device metadata as returned by the API server.

        Raises
        ------
        RuntimeError
            If the API server returns an error status.
        requests.HTTPError
            If the HTTP response has a 4xx or 5xx status code.
        """
        url = self._api_url(f"/devices/{device_name}/info")
        logger.debug("RemoteBackend.get_device_info GET %s", url)
        resp = requests.get(url, headers=self._headers, timeout=self._timeout)
        resp.raise_for_status()
        data = resp.json()
        self._check_response(data)
        return data.get("data", data)

    def get_supported_operations(self, device_name: str) -> list[str]:
        """Retrieve the list of operations supported by *device_name*.

        Parameters
        ----------
        device_name:
            Logical name of the device.

        Returns
        -------
        list[str]
            Sorted list of operation strings.

        Raises
        ------
        RuntimeError
            If the API server returns an error status.
        requests.HTTPError
            If the HTTP response has a 4xx or 5xx status code.
        """
        url = self._api_url(f"/devices/{device_name}/operations")
        logger.debug("RemoteBackend.get_supported_operations GET %s", url)
        resp = requests.get(url, headers=self._headers, timeout=self._timeout)
        resp.raise_for_status()
        data = resp.json()
        self._check_response(data)
        return data.get("data", data)

    def list_devices(self) -> list[str]:
        """Return the names of all devices known to the API server.

        Returns
        -------
        list[str]
            Device names extracted from the ``data`` array in the API response.

        Raises
        ------
        RuntimeError
            If the API server returns an error status.
        requests.HTTPError
            If the HTTP response has a 4xx or 5xx status code.
        """
        url = self._api_url("/devices")
        logger.debug("RemoteBackend.list_devices GET %s", url)
        resp = requests.get(url, headers=self._headers, timeout=self._timeout)
        resp.raise_for_status()
        data = resp.json()
        self._check_response(data)
        devices = data.get("data", data)
        # Extract names — the API returns a list of device objects or name strings.
        if isinstance(devices, list):
            return [d["name"] if isinstance(d, dict) else d for d in devices]
        return []

    def snapshot(self, device_name: str) -> Any:
        """Request a snapshot of *device_name* from the API server.

        Parameters
        ----------
        device_name:
            Logical name of the device to snapshot.

        Returns
        -------
        Any
            The snapshot data as returned by the API server.

        Raises
        ------
        RuntimeError
            If the API server returns an error status.
        requests.HTTPError
            If the HTTP response has a 4xx or 5xx status code.
        """
        url = self._api_url(f"/devices/{device_name}/snapshots")
        logger.info("RemoteBackend.snapshot POST %s", url)
        resp = requests.post(url, headers=self._headers, timeout=self._timeout)
        resp.raise_for_status()
        data = resp.json()
        self._check_response(data)
        return data.get("data", data)
