"""NetSight SDK — public Python interface for device interaction.

This package exposes a stable, high-level API for working with managed
network devices.  It supports two backend modes:

* :class:`~netsight.sdk.local.LocalBackend` — direct device communication
  without a running API server (useful for scripts and automation).
* :class:`~netsight.sdk.remote.RemoteBackend` — delegates to a running
  NetSight API server over HTTP (useful for distributed or web deployments).

Quick start::

    from netsight.sdk.local import LocalBackend
    from netsight.sdk.device import DeviceHandle

    backend = LocalBackend("config/devices.yaml")
    fw = DeviceHandle("fw-01", backend)
    info = fw.show_system_info()
"""
