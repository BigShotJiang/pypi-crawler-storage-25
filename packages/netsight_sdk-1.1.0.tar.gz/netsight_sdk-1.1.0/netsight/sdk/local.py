"""LocalBackend — direct device communication for the NetSight SDK.

:class:`LocalBackend` connects directly to managed devices without requiring
a running NetSight API server.  It is suitable for scripts, automation
pipelines, and testing.

Usage::

    from netsight.sdk.local import LocalBackend
    from netsight.sdk.device import DeviceHandle

    backend = LocalBackend("config/devices.yaml")
    for name in backend.list_devices():
        fw = DeviceHandle(name, backend)
        snap = fw.snapshot()
    backend.close()

    # Context manager form:
    with LocalBackend("config/devices.yaml") as backend:
        info = backend.get_device_info("fw-01")
"""

from __future__ import annotations

import logging
from typing import Any

from netsight.config import ConfigLoader, DeviceConfig
from netsight.data.manager import DataManager
from netsight.data.models import QueryResult, Snapshot
from netsight.exceptions import ConfigValidationError
from netsight.registry import plugin_registry

logger = logging.getLogger(__name__)


class LocalBackend:
    """Direct-device backend for the NetSight SDK.

    Loads configuration from a YAML file, lazily instantiates plugin clients
    on first use, and persists results via :class:`~netsight.data.manager.DataManager`.

    The PAN-OS XML plugin is auto-registered if it has not already been added
    to the global :data:`~netsight.registry.plugin_registry`.

    Parameters
    ----------
    config_path:
        Path to a ``devices.yaml`` configuration file.
    db_path:
        Path to the SQLite database used for persistence.
        Defaults to ``"storage/netsight.db"``.
    """

    def __init__(self, config_path: str, db_path: str = "storage/netsight.db") -> None:
        # Discover and load every installed pack via the netsight.packs
        # entry-point group. Idempotent across the process — subsequent
        # LocalBackend instantiations skip the discovery walk.
        from netsight.packs import pack_registry

        pack_registry.ensure_loaded()

        self._config_loader = ConfigLoader(config_path)
        self._config_dir = self._config_loader.config_dir
        self._data_manager = DataManager(db_path)

        # Cache of device_name -> client instance (lazy-populated).
        self._clients: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_device_config(self, device_name: str) -> DeviceConfig:
        """Return the :class:`DeviceConfig` for *device_name*.

        Raises
        ------
        KeyError
            If no device with *device_name* is found in the configuration
            (wraps :class:`~netsight.exceptions.ConfigValidationError`).
        """
        try:
            return self._config_loader.get_device(device_name)
        except ConfigValidationError as exc:
            raise KeyError(device_name) from exc

    def _get_client(self, device_name: str) -> Any:
        """Return a cached plugin client for *device_name*, creating one if needed.

        Parameters
        ----------
        device_name:
            Logical name of the device.

        Returns
        -------
        Any
            A plugin client instance for the device's ``api_type``.

        Raises
        ------
        KeyError
            If the device is not found in config.
        """
        if device_name not in self._clients:
            config = self._get_device_config(device_name)
            plugin_info = plugin_registry.get(config.api_type)

            # The compiled config is REQUIRED — it is the validated,
            # schema-checked, parser-resolved output of the config
            # compiler. We never bypass it or fall back to reading the
            # raw pack catalog directly, because that would skip:
            #   - Schema validation (read_only enforcement)
            #   - Parser spec resolution
            #   - Per-model overrides
            #   - Allowlist cross-checking
            #
            # If the compiled config doesn't exist, the user must run
            # `netsight config compile` first.
            resolved_config = None

            # Try 1: legacy vendor-config store (config/.compiled/<vendor>/<model>/)
            try:
                from netsight.config_mgmt.store import FileConfigStore
                store = FileConfigStore(self._config_dir or "config")
                resolved_config = store.get_resolved(
                    config.vendor or plugin_info.name.split("-")[0],
                    config.model or "default",
                    config.name,
                )
            except FileNotFoundError:
                pass
            except Exception as exc:  # noqa: BLE001
                logger.debug("Legacy compiled config lookup failed: %s", exc)

            # Try 2: pack-mode compiled output (~/.cache/netsight/compiled/<pack>/default/)
            if resolved_config is None:
                try:
                    from netsight.config_mgmt.user_config import resolve_cache_dir
                    import json
                    from pathlib import Path
                    cache_dir = resolve_cache_dir()
                    pack_name = plugin_info.name
                    # Try model-specific first, then default
                    for model_dir in [config.model or "default", "default"]:
                        compiled_path = Path(cache_dir) / "compiled" / pack_name / model_dir / "resolved.json"
                        if compiled_path.is_file():
                            resolved_config = json.loads(compiled_path.read_text(encoding="utf-8"))
                            logger.debug(
                                "Loaded compiled config from pack cache: %s",
                                compiled_path,
                            )
                            break
                except Exception as exc:  # noqa: BLE001
                    logger.debug("Pack cache compiled config lookup failed: %s", exc)

            if resolved_config is None:
                from netsight.exceptions import ConfigValidationError
                raise ConfigValidationError(
                    field="resolved_config",
                    detail=(
                        f"No compiled configuration found for device "
                        f"'{device_name}'. The config compiler must run "
                        f"before any device operation.\n\n"
                        f"  netsight config compile\n\n"
                        f"This validates the pack catalog, resolves parser "
                        f"specs, and produces the compiled output that the "
                        f"SDK requires. Without it, operation dispatch, "
                        f"parser resolution, and model-gating cannot work."
                    ),
                )

            client = plugin_info.client_class(config=config, resolved_config=resolved_config)
            self._clients[device_name] = client
            logger.debug("Created %s client for device '%s'", config.api_type, device_name)
        return self._clients[device_name]

    # ------------------------------------------------------------------
    # Backend protocol
    # ------------------------------------------------------------------

    def execute(self, device_name: str, operation: str, params: Any = None) -> Any:
        """Execute *operation* on *device_name* and return the result.

        Parameters
        ----------
        device_name:
            Logical name of the target device.
        operation:
            Operation string recognised by the device plugin.
        params:
            Optional parameters forwarded to the plugin client.

        Returns
        -------
        Any
            The raw response from the plugin client.

        Raises
        ------
        KeyError
            If *device_name* is not in the configuration.
        """
        client = self._get_client(device_name)
        logger.info("LocalBackend.execute device='%s' op='%s'", device_name, operation)
        return client.execute(operation=operation, params=params)

    def get_device_info(self, device_name: str) -> dict:
        """Return configuration metadata for *device_name*.

        Parameters
        ----------
        device_name:
            Logical name of the device.

        Returns
        -------
        dict
            A dict with keys ``name``, ``host``, ``api_type``, ``username``,
            ``verify_ssl``, ``timeout_connect``, ``timeout_read``, and
            ``rate_limit``.

        Raises
        ------
        KeyError
            If *device_name* is not found in the configuration.
        """
        config = self._get_device_config(device_name)
        return {
            "name": config.name,
            "host": config.host,
            "api_type": config.api_type,
            "username": config.username,
            "verify_ssl": config.verify_ssl,
            "timeout_connect": config.timeout_connect,
            "timeout_read": config.timeout_read,
            "rate_limit": config.rate_limit,
        }

    def get_supported_operations(self, device_name: str) -> list[str]:
        """Return the sorted list of supported operations for *device_name*.

        Looks up the plugin registered for the device's ``api_type`` and
        returns its ``allowed_operations`` set with ``"keygen"`` excluded.

        Parameters
        ----------
        device_name:
            Logical name of the device.

        Returns
        -------
        list[str]
            Alphabetically sorted list of publicly available operation strings.

        Raises
        ------
        KeyError
            If *device_name* is not found in the configuration.
        """
        config = self._get_device_config(device_name)
        plugin_info = plugin_registry.get(config.api_type)
        return sorted(plugin_info.allowed_operations - {"keygen"})

    def list_devices(self) -> list[str]:
        """Return the names of all devices in the configuration.

        Returns
        -------
        list[str]
            Device names in the order they appear in the config file.
        """
        return [d.name for d in self._config_loader.get_devices()]

    def snapshot(self, device_name: str) -> Snapshot:
        """Capture a full snapshot of *device_name* by running all supported operations.

        Each operation is executed in turn; failures are logged and skipped so
        that a partial result is still stored.  The resulting
        :class:`~netsight.data.models.Snapshot` is persisted via the
        :class:`~netsight.data.manager.DataManager`.

        Parameters
        ----------
        device_name:
            Logical name of the device to snapshot.

        Returns
        -------
        Snapshot
            The captured and persisted snapshot.

        Raises
        ------
        KeyError
            If *device_name* is not found in the configuration.
        """
        operations = self.get_supported_operations(device_name)
        results: list[QueryResult] = []

        for operation in operations:
            try:
                raw = self.execute(device_name, operation)
                # Normalise result to a plain dict for uniform storage.
                if isinstance(raw, dict):
                    data = raw
                elif isinstance(raw, str):
                    data = {"raw": raw}
                else:
                    data = {"raw": str(raw)}
                results.append(QueryResult(device_name=device_name, operation=operation, data=data))
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Snapshot: skipping operation '%s' for device '%s': %s",
                    operation,
                    device_name,
                    exc,
                )

        snapshot = self._data_manager.create_snapshot(device_name, results)
        logger.info(
            "Snapshot created for '%s': id=%s ops=%d", device_name, snapshot.id, len(results)
        )
        return snapshot

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close all plugin clients and release the database connection."""
        for name, client in self._clients.items():
            try:
                client.close()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Error closing client for '%s': %s", name, exc)
        self._clients.clear()
        self._data_manager.close()
        logger.debug("LocalBackend closed")

    def __enter__(self) -> "LocalBackend":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
