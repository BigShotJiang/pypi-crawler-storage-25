"""Per-device operation interface for the NetSight SDK.

:class:`DeviceHandle` wraps a backend (local or remote) and provides a
convenient, device-centric API for executing operations, retrieving device
metadata, and capturing snapshots.

Usage::

    from netsight.sdk.local import LocalBackend
    from netsight.sdk.device import DeviceHandle

    backend = LocalBackend("config/devices.yaml")
    fw = DeviceHandle("fw-01", backend)

    info = fw.show_system_info()
    routes = fw.show_routes(vr="default")
    snap = fw.snapshot()
"""

from __future__ import annotations

from typing import Any


class DeviceHandle:
    """Per-device operation interface that delegates to a backend.

    All operations are dispatched through the backend protocol, which may be
    a :class:`~netsight.sdk.local.LocalBackend` for direct device access or a
    :class:`~netsight.sdk.remote.RemoteBackend` for server-mediated access.

    The backend must implement the following protocol::

        class BackendProtocol:
            def execute(self, device_name: str, operation: str, params=None) -> Any: ...
            def get_device_info(self, device_name: str) -> dict: ...
            def get_supported_operations(self, device_name: str) -> list[str]: ...
            def snapshot(self, device_name: str) -> Any: ...

    Parameters
    ----------
    device_name:
        The logical name of the device as defined in the configuration.
    backend:
        A backend instance implementing the protocol described above.
    """

    def __init__(self, device_name: str, backend: Any) -> None:
        self._name = device_name
        self._backend = backend

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """The logical device name."""
        return self._name

    # ------------------------------------------------------------------
    # Core execution
    # ------------------------------------------------------------------

    def execute(self, operation: str, params: Any = None) -> Any:
        """Execute an arbitrary operation on this device.

        Delegates to ``backend.execute(device_name, operation, params)``.

        Parameters
        ----------
        operation:
            Operation string recognised by the plugin (e.g. ``"show_interfaces"``).
        params:
            Optional parameters forwarded verbatim to the backend.

        Returns
        -------
        Any
            The raw result returned by the backend.
        """
        return self._backend.execute(self._name, operation, params)

    # ------------------------------------------------------------------
    # Convenience operation methods
    # ------------------------------------------------------------------

    def show_system_info(self) -> Any:
        """Retrieve basic system information from the device."""
        return self.execute("show_system_info")

    def show_interfaces(self) -> Any:
        """Retrieve interface status information from the device."""
        return self.execute("show_interfaces")

    def show_routes(self, vr: str = "default") -> Any:
        """Retrieve the routing table from the device.

        Parameters
        ----------
        vr:
            Virtual router name.  Defaults to ``"default"``.
        """
        return self.execute("show_routing_table", {"vr": vr})

    def show_arp(self) -> Any:
        """Retrieve the ARP / neighbour table from the device."""
        return self.execute("show_arp_table")

    def show_ha_status(self) -> Any:
        """Retrieve high-availability state information from the device."""
        return self.execute("show_ha_status")

    def show_sessions(self) -> Any:
        """Retrieve global session statistics from the device."""
        return self.execute("show_session_info")

    def get_traffic_logs(self, query: str = "", nlogs: int = 100) -> Any:
        """Retrieve traffic log entries from the device.

        Parameters
        ----------
        query:
            Optional filter query string.
        nlogs:
            Maximum number of log entries to retrieve.  Defaults to ``100``.
        """
        return self.execute("get_traffic_logs", {"query": query, "nlogs": nlogs})

    def get_threat_logs(self, query: str = "", nlogs: int = 100) -> Any:
        """Retrieve threat log entries from the device.

        Parameters
        ----------
        query:
            Optional filter query string.
        nlogs:
            Maximum number of log entries to retrieve.  Defaults to ``100``.
        """
        return self.execute("get_threat_logs", {"query": query, "nlogs": nlogs})

    def get_system_logs(self, query: str = "", nlogs: int = 100) -> Any:
        """Retrieve system log entries from the device.

        Parameters
        ----------
        query:
            Optional filter query string.
        nlogs:
            Maximum number of log entries to retrieve.  Defaults to ``100``.
        """
        return self.execute("get_system_logs", {"query": query, "nlogs": nlogs})

    # ------------------------------------------------------------------
    # Metadata
    # ------------------------------------------------------------------

    def info(self) -> dict:
        """Return device metadata from the backend.

        Delegates to ``backend.get_device_info(device_name)``.

        Returns
        -------
        dict
            Device metadata including at minimum the device name and
            configuration details.
        """
        return self._backend.get_device_info(self._name)

    def operations(self) -> list[str]:
        """Return the list of operations supported by this device's plugin.

        Delegates to ``backend.get_supported_operations(device_name)``.

        Returns
        -------
        list[str]
            Sorted list of publicly advertised operation strings.
        """
        return self._backend.get_supported_operations(self._name)

    # ------------------------------------------------------------------
    # Snapshot
    # ------------------------------------------------------------------

    def snapshot(self) -> Any:
        """Capture a point-in-time snapshot of this device's state.

        Delegates to ``backend.snapshot(device_name)``.

        Returns
        -------
        Any
            A :class:`~netsight.data.models.Snapshot` instance (or the
            equivalent representation from the remote backend).
        """
        return self._backend.snapshot(self._name)

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"DeviceHandle(name={self._name!r}, backend={type(self._backend).__name__})"
