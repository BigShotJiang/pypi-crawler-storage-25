"""NetSight resilience primitives.

Provides three building blocks for safe, robust device interactions:

- :func:`retry_with_backoff` — decorator that retries on transient errors with
  exponential backoff and random jitter.
- :class:`RateLimiter` — per-device sliding-window request rate limiter.
- :class:`ResponseGuard` — rejects oversized device responses before they
  consume excessive memory.
"""

from __future__ import annotations

import functools
import logging
import random
import time
from collections import defaultdict
from typing import Any, Callable, TypeVar

from netsight.exceptions import RateLimitError, ResponseSizeError

_log = logging.getLogger(__name__)

# Type variable used to preserve the wrapped function's return type annotation.
_R = TypeVar("_R")


# ---------------------------------------------------------------------------
# retry_with_backoff
# ---------------------------------------------------------------------------


def retry_with_backoff(
    max_retries: int = 3,
    base_delay: float = 1.0,
    retryable: tuple[type[BaseException], ...] = (ConnectionError, TimeoutError, OSError),
) -> Callable[[Callable[..., _R]], Callable[..., _R]]:
    """Decorator: retry *func* up to *max_retries* times on transient errors.

    Parameters
    ----------
    max_retries:
        Maximum number of retry attempts *after* the initial call.  Total
        invocations are therefore ``max_retries + 1``.
    base_delay:
        Delay (seconds) before the first retry.  Each subsequent retry doubles
        the delay (exponential backoff), plus a random jitter of up to 50 % of
        the current delay.
    retryable:
        Tuple of exception *types* that are considered transient and warrant a
        retry.  Any exception not in this tuple is re-raised immediately.

    Returns
    -------
    Callable
        The decorated function with identical signature and preserved metadata
        (``__name__``, ``__doc__``, etc.) via :func:`functools.wraps`.

    Examples
    --------
    >>> @retry_with_backoff(max_retries=3, base_delay=0.5)
    ... def fetch_arp_table(host: str) -> str: ...
    """

    def decorator(func: Callable[..., _R]) -> Callable[..., _R]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> _R:
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except retryable as exc:
                    if attempt < max_retries:
                        delay = base_delay * (2 ** attempt)
                        jitter = random.uniform(0, delay * 0.5)
                        sleep_time = delay + jitter
                        _log.warning(
                            "Attempt %d/%d failed for '%s' with %s: %s. "
                            "Retrying in %.3fs.",
                            attempt + 1,
                            max_retries + 1,
                            func.__name__,
                            type(exc).__name__,
                            exc,
                            sleep_time,
                        )
                        time.sleep(sleep_time)
                    else:
                        _log.error(
                            "All %d attempts failed for '%s'. Last error: %s: %s",
                            max_retries + 1,
                            func.__name__,
                            type(exc).__name__,
                            exc,
                        )
                        raise

            # Unreachable, but satisfies type checkers.
            raise RuntimeError("retry_with_backoff: unreachable")  # pragma: no cover

        return wrapper

    return decorator


# ---------------------------------------------------------------------------
# RateLimiter
# ---------------------------------------------------------------------------


class RateLimiter:
    """Sliding-window per-device request rate limiter.

    Tracks call timestamps for each device independently using a 1-second
    sliding window.  Raises :class:`~netsight.exceptions.RateLimitError` when
    a device would exceed *max_rps*.

    Parameters
    ----------
    max_rps:
        Maximum number of requests allowed per second for any single device.

    Example
    -------
    >>> limiter = RateLimiter(max_rps=5)
    >>> limiter.acquire("fw-core-01")   # allowed
    >>> limiter.reset("fw-core-01")     # clear window for device
    """

    def __init__(self, max_rps: int = 5) -> None:
        self._max_rps = max_rps
        # Maps device_name -> list of monotonic timestamps (within the last 1 s)
        self._timestamps: defaultdict[str, list[float]] = defaultdict(list)

    def acquire(self, device_name: str) -> None:
        """Record a request for *device_name*, raising if the rate limit is hit.

        Parameters
        ----------
        device_name:
            Logical name of the device being queried.

        Raises
        ------
        RateLimitError
            When the number of requests in the past second is already at or
            above *max_rps*.
        """
        now = time.monotonic()
        cutoff = now - 1.0

        # Evict timestamps outside the current 1-second window.
        self._timestamps[device_name] = [
            ts for ts in self._timestamps[device_name] if ts > cutoff
        ]

        if len(self._timestamps[device_name]) >= self._max_rps:
            raise RateLimitError(device_name=device_name, max_rps=self._max_rps)

        self._timestamps[device_name].append(now)

    def reset(self, device_name: str) -> None:
        """Clear the rate-limit window for *device_name*.

        Parameters
        ----------
        device_name:
            Logical name of the device whose history should be cleared.
        """
        self._timestamps[device_name] = []


# ---------------------------------------------------------------------------
# ResponseGuard
# ---------------------------------------------------------------------------


class ResponseGuard:
    """Guard that rejects device responses exceeding a configured byte limit.

    Parameters
    ----------
    max_bytes:
        Upper size limit in bytes.  Defaults to 50 MiB (``50 * 1024 * 1024``).

    Example
    -------
    >>> guard = ResponseGuard(max_bytes=50 * 1024 * 1024)
    >>> guard.check(raw_response_bytes)
    """

    def __init__(self, max_bytes: int = 50 * 1024 * 1024) -> None:
        self._max_bytes = max_bytes

    def check(self, data: bytes | str) -> None:
        """Validate that *data* does not exceed the configured byte limit.

        Parameters
        ----------
        data:
            The response payload.  If a :class:`str` is given it is encoded
            to UTF-8 to determine the byte length.

        Raises
        ------
        ResponseSizeError
            When the byte length of *data* exceeds *max_bytes*.
        """
        actual = len(data.encode() if isinstance(data, str) else data)
        if actual > self._max_bytes:
            raise ResponseSizeError(actual_bytes=actual, max_bytes=self._max_bytes)
