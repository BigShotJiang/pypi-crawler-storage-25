"""Automated pipeline for adding a new operation to a pack.

Drives the full scaffold-to-compile chain in one call:

1. Execute the command against a live device to capture real XML
2. Analyze the XML structure (extract dotted paths)
3. Scaffold a parser spec YAML from the XML sample
4. Scaffold the operations_catalog.toml entry
5. Validate the parser spec + catalog entry
6. Write files to the pack's _data/ directory
7. Generate a per-command test file
8. Run compile_dry_run to verify the pack still compiles

Both a library function (``add_operation``) and the backend for the
CLI command ``netsight pack add-operation``.
"""

from __future__ import annotations

import logging
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class AddOperationResult:
    """Result of the add-operation pipeline."""

    operation: str
    success: bool = False
    files_written: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    sample_xml: str = ""
    parser_spec_yaml: str = ""
    catalog_entry_toml: str = ""
    test_file_content: str = ""


def add_operation(
    *,
    operation: str,
    command: str,
    category: str,
    description: str,
    op_type: str = "op",
    log_type: str = "",
    pack_name: str = "paloalto-firewall-xml",
    pack_root: Path | None = None,
    device_name: str | None = None,
    config_path: str = "config/devices.yaml",
    sample_xml: str = "",
    write: bool = True,
    skip_parser: bool = False,
) -> AddOperationResult:
    """Add a new operation to a pack with full validation.

    Parameters
    ----------
    operation:
        Operation name (e.g. ``"show_bgp_peers"``).
    command:
        PAN-OS XML command string for op-type operations.
    category:
        Operation category (``"system"``, ``"network"``, etc.).
    description:
        One-line human-readable description.
    op_type:
        ``"op"`` for operational commands, ``"log"`` for log queries.
    log_type:
        Required when ``op_type="log"`` — the PAN-OS log channel name.
    pack_name:
        Canonical pack name for the pack registry.
    pack_root:
        Path to the pack's source root (where ``_data/`` lives). If
        ``None``, attempts to locate it via the pack registry.
    device_name:
        If provided, executes the command against this device to
        capture a real XML sample. Requires ``config_path``.
    config_path:
        Path to ``devices.yaml`` for live device access.
    sample_xml:
        Pre-captured XML sample. Used when ``device_name`` is not
        provided (offline mode).
    write:
        If ``True``, writes files to disk. If ``False``, dry-run.
    skip_parser:
        If ``True``, skip parser spec generation (raw output op).

    Returns
    -------
    AddOperationResult
        Contains success flag, files written, errors, and generated
        content for inspection.
    """
    result = AddOperationResult(operation=operation)

    # --- Step 1: Capture XML sample ---
    if device_name and not sample_xml:
        logger.info("Step 1: Capturing live XML from device '%s'...", device_name)
        try:
            sample_xml = _capture_live_xml(
                device_name=device_name,
                config_path=config_path,
                command=command,
                op_type=op_type,
                log_type=log_type,
            )
            result.sample_xml = sample_xml
            logger.info("  Captured %d bytes of XML", len(sample_xml))
        except Exception as exc:
            result.errors.append(f"Failed to capture live XML: {exc}")
            result.success = False
            return result
    elif sample_xml:
        result.sample_xml = sample_xml
        logger.info("Step 1: Using provided XML sample (%d bytes)", len(sample_xml))
    else:
        result.warnings.append("No XML sample — parser spec will be skipped")
        skip_parser = True
        logger.info("Step 1: No XML sample available, skipping parser")

    # --- Step 2: Resolve pack root ---
    if pack_root is None:
        pack_root = _resolve_pack_root(pack_name=pack_name)
        if pack_root is None:
            result.errors.append(
                f"Cannot find pack root for '{pack_name}'. "
                f"Pass --pack-root explicitly."
            )
            result.success = False
            return result

    data_dir = pack_root / "_data"
    parsers_dir = data_dir / "parsers"
    catalog_path = data_dir / "operations_catalog.toml"
    tests_dir = pack_root.parent / "tests" if (pack_root.parent / "tests").is_dir() else pack_root / "tests"

    # --- Step 3: Check operation doesn't already exist ---
    if catalog_path.is_file():
        existing = tomllib.loads(catalog_path.read_text(encoding="utf-8"))
        if operation in existing:
            result.errors.append(
                f"Operation '{operation}' already exists in "
                f"{catalog_path}. Remove it first to re-scaffold."
            )
            result.success = False
            return result

    # --- Step 4: Generate parser spec ---
    parser_spec_yaml = ""
    if not skip_parser and sample_xml:
        logger.info("Step 2: Analyzing XML structure...")
        try:
            from netsight.mcp_dev.tools.scaffolding import ScaffoldParserSpecTool
            tool = ScaffoldParserSpecTool()
            scaffold_result = tool.execute(
                operation=operation,
                sample_xml=sample_xml,
                vendor=pack_name.split("-")[0],
            )
            parser_spec_yaml = scaffold_result.get("yaml_content", "")
            if parser_spec_yaml:
                result.parser_spec_yaml = parser_spec_yaml
                logger.info("  Generated parser spec (%d lines)", parser_spec_yaml.count("\n"))
            else:
                result.warnings.append("scaffold_parser_spec returned empty YAML")
                skip_parser = True
        except Exception as exc:
            result.warnings.append(f"Parser spec generation failed: {exc}")
            skip_parser = True

    # --- Step 5: Validate parser spec ---
    if parser_spec_yaml and not skip_parser:
        logger.info("Step 3: Validating parser spec...")
        try:
            from netsight.mcp_dev.tools.validation import ValidateParserSpecTool
            validator = ValidateParserSpecTool()
            val_result = validator.execute(yaml_content=parser_spec_yaml)
            if val_result.get("errors"):
                for err in val_result["errors"]:
                    result.warnings.append(f"Parser spec validation: {err}")
                logger.warning("  Parser spec has validation warnings")
            else:
                logger.info("  Parser spec is valid")
        except Exception as exc:
            result.warnings.append(f"Parser spec validation skipped: {exc}")

    # --- Step 6: Generate catalog TOML entry ---
    logger.info("Step 4: Generating catalog entry...")
    catalog_entry = _build_catalog_entry(
        operation=operation,
        command=command,
        category=category,
        description=description,
        op_type=op_type,
        log_type=log_type,
        has_parser=bool(parser_spec_yaml and not skip_parser),
    )
    result.catalog_entry_toml = catalog_entry

    # --- Step 7: Generate test file ---
    logger.info("Step 5: Generating test file...")
    test_content = _build_test_file(
        operation=operation,
        op_type=op_type,
        command=command,
        log_type=log_type,
    )
    result.test_file_content = test_content

    # --- Step 8: Write files ---
    if write:
        logger.info("Step 6: Writing files...")
        try:
            # Append to catalog
            with catalog_path.open("a", encoding="utf-8") as fh:
                fh.write("\n" + catalog_entry)
            result.files_written.append(str(catalog_path))
            logger.info("  Appended to %s", catalog_path)

            # Write parser spec
            if parser_spec_yaml and not skip_parser:
                parsers_dir.mkdir(parents=True, exist_ok=True)
                spec_path = parsers_dir / f"{operation}.yaml"
                spec_path.write_text(parser_spec_yaml, encoding="utf-8")
                result.files_written.append(str(spec_path))
                logger.info("  Wrote %s", spec_path)

            # Write test file
            tests_dir.mkdir(parents=True, exist_ok=True)
            test_path = tests_dir / f"test_{operation}.py"
            test_path.write_text(test_content, encoding="utf-8")
            result.files_written.append(str(test_path))
            logger.info("  Wrote %s", test_path)

        except Exception as exc:
            result.errors.append(f"File write failed: {exc}")
            result.success = False
            return result
    else:
        logger.info("Step 6: Dry run — no files written")

    result.success = len(result.errors) == 0
    logger.info(
        "Pipeline complete: %s (%d files, %d warnings, %d errors)",
        "SUCCESS" if result.success else "FAILED",
        len(result.files_written),
        len(result.warnings),
        len(result.errors),
    )
    return result


def _capture_live_xml(
    *,
    device_name: str,
    config_path: str,
    command: str,
    op_type: str,
    log_type: str,
) -> str:
    """Execute a command against a live device and return raw XML.

    Uses raw requests + keygen rather than LocalBackend to avoid the
    compiled-config requirement. The add-operation pipeline is a
    development-time tool that needs to run BEFORE the operation is
    in the catalog, so the normal execute() path can't work.
    """
    import warnings
    warnings.filterwarnings("ignore", message=".*Unverified HTTPS.*")

    import requests
    from netsight.config import ConfigLoader

    loader = ConfigLoader(config_path)
    config = loader.get_device(device_name)

    # Keygen — get a fresh API key
    keygen_url = f"https://{config.host}/api/"
    password = config.get_password()
    keygen_resp = requests.get(
        keygen_url,
        params={"type": "keygen", "user": config.username, "password": password},
        verify=config.verify_ssl,
        timeout=config.timeout_connect,
    )

    import xml.etree.ElementTree as ET
    root = ET.fromstring(keygen_resp.text)
    key = root.findtext(".//key", "")
    if not key:
        raise RuntimeError(f"Keygen failed: {keygen_resp.text[:200]}")

    # Execute the command
    params: dict[str, str] = {"key": key}
    if op_type == "log":
        params["type"] = "log"
        params["log-type"] = log_type
        params["nlogs"] = "5"
    else:
        params["type"] = "op"
        params["cmd"] = command

    response = requests.get(
        keygen_url,
        params=params,
        verify=config.verify_ssl,
        timeout=(config.timeout_connect, config.timeout_read),
    )
    return response.text


def _resolve_pack_root(*, pack_name: str) -> Path | None:
    """Find the pack's source root via the registry."""
    try:
        from netsight.packs import pack_registry
        pack_registry.ensure_loaded()
        info = pack_registry.get(name=pack_name)
        # config_root is a Traversable pointing at _data/
        # We need the parent (the package root containing _data/)
        config_root = info.config_root
        # For editable installs, config_root is a Path
        if hasattr(config_root, "parent"):
            return Path(str(config_root)).parent if "_data" in str(config_root) else Path(str(config_root))
        return None
    except Exception:
        return None


def _build_catalog_entry(
    *,
    operation: str,
    command: str,
    category: str,
    description: str,
    op_type: str,
    log_type: str,
    has_parser: bool,
) -> str:
    """Build a TOML catalog entry string."""
    lines = [
        f"[{operation}]",
        f'command = "{command}"',
        f'type = "{op_type}"',
    ]
    if op_type == "log" and log_type:
        lines.append(f'log_type = "{log_type}"')
    lines.extend([
        'required_model = "*"',
        f'category = "{category}"',
        f'description = "{description}"',
        "read_only = true",
    ])
    if has_parser:
        lines.append(f'parser_spec = "parsers/{operation}.yaml"')
    lines.append("")
    return "\n".join(lines)


def _build_test_file(
    *,
    operation: str,
    op_type: str,
    command: str,
    log_type: str,
) -> str:
    """Build a per-command test file."""
    class_name = "".join(w.capitalize() for w in operation.split("_"))

    if op_type == "log":
        expected_log_type = log_type
        return f'''"""Per-command tests for the ``{operation}`` operation."""

from __future__ import annotations

from typing import Callable
from unittest.mock import MagicMock

from netsight_pack_paloalto_firewall_xml.client import PanOSXMLClient

OPERATION = "{operation}"
EXPECTED_LOG_TYPE = "{expected_log_type}"


class Test{class_name}:
    def test_calls_get_once(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        mock_get.assert_called_once()

    def test_sends_type_log(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        assert mock_get.call_args[1]["params"]["type"] == "log"

    def test_sends_log_type(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        assert mock_get.call_args[1]["params"]["log-type"] == EXPECTED_LOG_TYPE

    def test_does_not_send_cmd_param(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        assert "cmd" not in mock_get.call_args[1]["params"]

    def test_sends_api_key(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        assert mock_get.call_args[1]["params"]["key"] == "TESTTOKEN"
'''
    else:
        return f'''"""Per-command tests for the ``{operation}`` operation."""

from __future__ import annotations

from typing import Callable
from unittest.mock import MagicMock

from netsight_pack_paloalto_firewall_xml.client import PanOSXMLClient

OPERATION = "{operation}"
EXPECTED_CMD = "{command}"


class Test{class_name}:
    def test_calls_get_once(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        mock_get.assert_called_once()

    def test_sends_type_op(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        assert mock_get.call_args[1]["params"]["type"] == "op"

    def test_sends_exact_command_xml(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        assert mock_get.call_args[1]["params"]["cmd"] == EXPECTED_CMD

    def test_sends_api_key(
        self,
        client: PanOSXMLClient,
        run_operation: Callable[..., tuple[str, MagicMock]],
    ) -> None:
        _, mock_get = run_operation(client, OPERATION)
        assert mock_get.call_args[1]["params"]["key"] == "TESTTOKEN"
'''
