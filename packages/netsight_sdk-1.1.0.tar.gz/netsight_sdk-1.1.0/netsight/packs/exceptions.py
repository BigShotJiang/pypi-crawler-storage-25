"""Pack-specific exception hierarchy for NetSight.

All pack exceptions inherit from :class:`~netsight.exceptions.NetSightError`
so callers can catch the entire family with a single ``except NetSightError``
clause.

These classes are defined here but **must be imported from**
:mod:`netsight.exceptions`, which re-exports them as the canonical location::

    from netsight.exceptions import PackRegistrationError, PackConflictError, PackNotInstalledError
"""

from __future__ import annotations

from netsight.exceptions import NetSightError


class PackRegistrationError(NetSightError):
    """Raised when a pack cannot be registered due to a metadata constraint.

    This is the base class for all pack registration failures.  Callers that
    want to catch any registration problem can catch this class; callers that
    need to distinguish duplicate-name conflicts from other constraint failures
    should catch :class:`PackConflictError` specifically.

    Attributes
    ----------
    pack_name:
        The canonical pack name (``<vendor>-<device_type>-<protocol>``) that
        failed to register, or ``None`` when the name itself is invalid.
    detail:
        Human-readable description of the constraint that was violated.
    """

    def __init__(self, pack_name: str | None, detail: str) -> None:
        self.pack_name = pack_name
        self.detail = detail
        prefix = f"Pack '{pack_name}'" if pack_name else "Pack"
        super().__init__(f"{prefix} registration failed: {detail}")


class PackConflictError(PackRegistrationError):
    """Raised when a pack name is already registered.

    Signals that a second pack attempted to register under the same canonical
    name as an existing pack.  This can happen when two installed distributions
    both declare the same ``netsight.packs`` entry point name.

    Attributes
    ----------
    pack_name:
        The canonical name (``<vendor>-<device_type>-<protocol>``) that is
        already registered.
    """

    def __init__(self, pack_name: str) -> None:
        super().__init__(
            pack_name=pack_name,
            detail=f"a pack named '{pack_name}' is already registered",
        )


class PackNotInstalledError(NetSightError):
    """Raised when a requested pack is not installed in the environment.

    Attributes
    ----------
    pack_name:
        The canonical name (``<vendor>-<device_type>-<protocol>``) that was
        requested but is not available.
    """

    def __init__(self, pack_name: str) -> None:
        self.pack_name = pack_name
        super().__init__(
            f"Pack '{pack_name}' is not installed. "
            f"Install it with: netsight pack install {pack_name}"
        )


class PackIncompatibleError(Exception):
    """Raised when an installed pack's declared compatibility doesn't match the running SDK.

    This exception is recorded (not raised) by the pack loader via
    :meth:`~netsight.packs.registry.PackRegistry.record_load_error` when:

    - ``PackInfo.declared_plugin_api`` does not match
      :data:`~netsight.packs.PLUGIN_API_VERSION`, or
    - ``PackInfo.min_sdk_version`` is a non-empty PEP 440 specifier and the
      running ``netsight.__version__`` is outside that range.

    Attributes
    ----------
    pack_name:
        The canonical pack name that failed the compatibility check.
    detail:
        Human-readable description of the specific incompatibility.
    """

    def __init__(self, pack_name: str, detail: str) -> None:
        self.pack_name = pack_name
        self.detail = detail
        super().__init__(f"Pack '{pack_name}' is incompatible: {detail}")
