"""NetSight pack system — public API.

This package provides the types and singleton needed to register, discover,
and load NetSight vendor packs.

Public surface
--------------
:class:`PackInfo`
    Frozen dataclass describing a single vendor pack's identity and
    capabilities.
:class:`PackRegistry`
    Registry that stores :class:`PackInfo` records keyed by canonical name.
:data:`pack_registry`
    Module-level singleton :class:`PackRegistry` used throughout the
    application.
:func:`bootstrap`
    Trigger pack discovery and loading.  Call once at application startup.
    This is a no-op until Phase 1 wires up the loader.

Canonical import paths
----------------------
All pack exceptions are imported from :mod:`netsight.exceptions`::

    from netsight.exceptions import PackRegistrationError, PackConflictError

Pack types and the singleton are imported from here or from the sub-module::

    from netsight.packs import PackInfo, pack_registry
    from netsight.packs.registry import pack_registry  # equivalent
"""

from __future__ import annotations

from netsight.packs.registry import PackInfo, PackRegistry, pack_registry

#: Integer plugin-API slot for the current SDK release.  Packs must declare
#: ``declared_plugin_api`` equal to this value or the loader will refuse to
#: register them and record a :class:`~netsight.packs.exceptions.PackIncompatibleError`.
PLUGIN_API_VERSION: int = 1

__all__ = [
    "PackInfo",
    "PackRegistry",
    "PLUGIN_API_VERSION",
    "bootstrap",
    "pack_registry",
]


def bootstrap() -> None:
    """Trigger vendor pack discovery and loading.

    Call this once at application startup (before any pack is looked up)
    to ensure all installed packs are registered.  This function is
    idempotent — repeated calls are safe.

    This is a placeholder for Phase 0.  Phase 1 will wire the actual
    entry-point loader into :meth:`~netsight.packs.registry.PackRegistry.ensure_loaded`.
    Until then this is a no-op.
    """
    pack_registry.ensure_loaded()
