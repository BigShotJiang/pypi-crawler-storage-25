"""CLI handler functions for the ``netsight pack`` subcommand.

Each ``_run_pack_*`` function maps directly to one ``netsight pack``
sub-action. Handlers follow the project convention: accept a parsed
:class:`argparse.Namespace`, print output, and return an ``int`` exit
code (0 = success, non-zero = failure).

Handlers are *pure* with respect to I/O — they do not call
:func:`sys.exit` themselves; the caller in :func:`netsight.cli.main`
does that.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Module-level imports for symbols that tests need to patch at
# ``netsight.packs.cli.<name>``.  Using local imports inside each handler
# would prevent patching via the module path.
from netsight.packs.registry import pack_registry  # noqa: E402
from netsight.packs.index import load_index  # noqa: E402

# Column widths for the list table.
_COL_NAME = 36
_COL_VERSION = 12
_COL_DEVICE_CLASS = 14
_COL_PROTOCOL = 12
_COL_STATUS = 12

# Status colour mappings for rich output.
_STATUS_STYLES: dict[str, str] = {
    "installed": "green",
    "stable": "green",
    "beta": "yellow",
    "experimental": "magenta",
    "deprecated": "red strike",
    "load_error": "bold red",
}


def _use_color(args: argparse.Namespace) -> bool:
    """Return True if coloured output should be used.

    Colour is suppressed when:
    - ``--no-color`` flag is set on *args*, OR
    - ``NO_COLOR`` environment variable is set (per no-color.org), OR
    - ``--json`` flag is set (JSON and colour are mutually exclusive).

    Parameters
    ----------
    args:
        Parsed namespace. Reads optional ``args.no_color`` and
        ``args.json`` attributes.

    Returns
    -------
    bool
        ``True`` if colour output should be used, ``False`` otherwise.
    """
    if getattr(args, "json", False):
        return False
    if getattr(args, "no_color", False):
        return False
    if os.environ.get("NO_COLOR"):
        return False
    return True


def _make_table_header() -> str:
    """Return the formatted table header line for ``pack list``."""
    return (
        f"{'NAME':<{_COL_NAME}} "
        f"{'VERSION':<{_COL_VERSION}} "
        f"{'DEVICE_CLASS':<{_COL_DEVICE_CLASS}} "
        f"{'PROTOCOL':<{_COL_PROTOCOL}} "
        f"{'STATUS':<{_COL_STATUS}}"
    )


def _make_table_separator() -> str:
    """Return a separator line matching the table header."""
    total = _COL_NAME + _COL_VERSION + _COL_DEVICE_CLASS + _COL_PROTOCOL + _COL_STATUS + 4
    return "-" * total


def _run_pack_list(args: argparse.Namespace) -> int:
    """Print a table of installed packs, optionally including available packs.

    With ``--available``, uninstalled index entries are printed with ``-``
    in the version column and the index entry's status in the status column.

    With ``--json``, emits a JSON document instead of a table.

    With colour enabled (default when stdout is a TTY and ``NO_COLOR`` is
    not set), status values are colour-coded via ``rich``.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.available`` (bool), ``args.json``
        (bool), and ``args.no_color`` (bool).

    Returns
    -------
    int
        Always 0.
    """
    installed = {info.name: info for info in pack_registry.list()}
    load_errors = pack_registry.load_errors()

    if getattr(args, "json", False):
        # JSON output — skip colour entirely.
        rows: list[dict[str, Any]] = []
        for name, info in sorted(installed.items()):
            rows.append({
                "name": info.name,
                "vendor": info.vendor,
                "device_type": info.device_type,
                "protocol": info.protocol,
                "version": info.version,
                "distribution": info.distribution,
                "status": "installed",
            })
        if load_errors:
            for name in sorted(load_errors):
                rows.append({
                    "name": name,
                    "vendor": None,
                    "device_type": None,
                    "protocol": None,
                    "version": None,
                    "distribution": None,
                    "status": "LOAD_ERROR",
                    "error": str(load_errors[name]),
                })
        if getattr(args, "available", False):
            index = load_index()
            for name, entry in sorted(index.items()):
                if name not in installed and name not in load_errors:
                    rows.append({
                        "name": name,
                        "vendor": None,
                        "device_type": None,
                        "protocol": None,
                        "version": None,
                        "distribution": None,
                        "status": entry.status,
                    })
        print(json.dumps({"packs": rows}, indent=2, default=str))
        return 0

    if _use_color(args):
        return _run_pack_list_rich(args, installed, load_errors)

    # Plain-text fallback.
    print(_make_table_header())
    print(_make_table_separator())

    # Print installed packs first.
    for name, info in sorted(installed.items()):
        print(
            f"{info.name:<{_COL_NAME}} "
            f"{info.version:<{_COL_VERSION}} "
            f"{info.device_type:<{_COL_DEVICE_CLASS}} "
            f"{info.protocol:<{_COL_PROTOCOL}} "
            f"{'installed':<{_COL_STATUS}}"
        )

    if load_errors:
        for name in sorted(load_errors):
            exc = load_errors[name]
            err_msg = str(exc)
            print(
                f"{name:<{_COL_NAME}} "
                f"{'—':<{_COL_VERSION}} "
                f"{'—':<{_COL_DEVICE_CLASS}} "
                f"{'—':<{_COL_PROTOCOL}} "
                f"{'LOAD_ERROR':<{_COL_STATUS}}"
            )
            print(f"  {'':>{_COL_NAME}}  error: {err_msg}")

    if getattr(args, "available", False):
        index = load_index()
        for name, entry in sorted(index.items()):
            if name not in installed:
                print(
                    f"{name:<{_COL_NAME}} "
                    f"{'—':<{_COL_VERSION}} "
                    f"{'—':<{_COL_DEVICE_CLASS}} "
                    f"{'—':<{_COL_PROTOCOL}} "
                    f"{entry.status:<{_COL_STATUS}}"
                )

    return 0


def _run_pack_list_rich(
    args: argparse.Namespace,
    installed: dict[str, Any],
    load_errors: dict[str, Exception],
) -> int:
    """Render the pack list table using ``rich`` for colour output.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.available`` (bool).
    installed:
        Mapping of pack name to :class:`~netsight.packs.registry.PackInfo`.
    load_errors:
        Mapping of pack name to the exception that prevented it from loading.

    Returns
    -------
    int
        Always 0.
    """
    from rich.console import Console
    from rich.table import Table

    console = Console()
    table = Table(show_header=True, header_style="bold")
    table.add_column("NAME", style="", no_wrap=True)
    table.add_column("VERSION", style="")
    table.add_column("DEVICE_CLASS", style="")
    table.add_column("PROTOCOL", style="")
    table.add_column("STATUS", style="")

    for name, info in sorted(installed.items()):
        style = _STATUS_STYLES.get("installed", "")
        table.add_row(
            info.name,
            info.version,
            info.device_type,
            info.protocol,
            f"[{style}]installed[/{style}]",
        )

    for name in sorted(load_errors):
        style = _STATUS_STYLES.get("load_error", "bold red")
        exc = load_errors[name]
        err_msg = str(exc)
        table.add_row(
            name,
            "—",
            "—",
            f"[{style}]{err_msg}[/{style}]",
            f"[{style}]LOAD_ERROR[/{style}]",
        )

    if getattr(args, "available", False):
        index = load_index()
        for name, entry in sorted(index.items()):
            if name not in installed and name not in load_errors:
                style = _STATUS_STYLES.get(entry.status, "")
                status_cell = f"[{style}]{entry.status}[/{style}]" if style else entry.status
                table.add_row(name, "—", "—", "—", status_cell)

    console.print(table)
    return 0


def _run_pack_search(args: argparse.Namespace) -> int:
    """Search the bundled index by a case-insensitive substring.

    Matches against pack name, vendor (derived from name), device type
    (derived from name), protocol (derived from name), and description.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.query`` (str).

    Returns
    -------
    int
        0 if at least one result, 1 if no results.
    """
    query = args.query.lower()
    index = load_index()
    matches: list[dict[str, Any]] = []

    for name, entry in sorted(index.items()):
        # Derive searchable fields from the pack name convention.
        parts = name.split("-")
        vendor = parts[0] if parts else ""
        device_type = parts[1] if len(parts) > 1 else ""
        protocol = parts[2] if len(parts) > 2 else ""

        haystack = " ".join([
            name,
            vendor,
            device_type,
            protocol,
            entry.description,
            entry.status,
        ]).lower()

        if query in haystack:
            matches.append({
                "name": name,
                "description": entry.description,
                "status": entry.status,
                "repo": entry.repo,
                "min_sdk": entry.min_sdk,
            })

    if not matches:
        print(f"No packs found matching {args.query!r}.")
        return 1

    for m in matches:
        print(f"  {m['name']}")
        print(f"    Description: {m['description']}")
        print(f"    Status:      {m['status']}")
        print(f"    Repo:        {m['repo']}")
        print(f"    Min core:    {m['min_sdk']}")
        print()

    return 0


def _run_pack_install(args: argparse.Namespace) -> int:
    """Install a pack from the bundled index via pip.

    Builds a ``git+<url>`` install URL from the index entry, then shells
    out to pip. Output streams directly to the user's terminal.

    With ``--dry-run``, prints the pip command that would be executed and
    exits 0 without actually installing.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.name`` (str), ``args.ref``
        (str | None), and ``args.dry_run`` (bool).

    Returns
    -------
    int
        pip's exit code, or 0 for a dry run, or 1 if the pack name is
        not found in the index.
    """
    index = load_index()
    entry = index.get(args.name)
    if entry is None:
        print(
            f"Error: Pack {args.name!r} is not in the pack index.",
            file=sys.stderr,
        )
        print(
            "Run 'netsight pack list --available' to see available packs.",
            file=sys.stderr,
        )
        return 1

    # Build the git+ install URL.
    # Shape: git+<repo>.git[@<ref>][#subdirectory=<subdir>]
    repo_url = entry.repo
    if not repo_url.endswith(".git"):
        repo_url = repo_url + ".git"

    ref = getattr(args, "ref", None)
    if ref:
        repo_url = f"{repo_url}@{ref}"

    if entry.subdirectory:
        url = f"git+{repo_url}#subdirectory={entry.subdirectory}"
    else:
        url = f"git+{repo_url}"

    pip_cmd = f"pip install {url}"

    if getattr(args, "dry_run", False):
        print(f"Would run: {pip_cmd}")
        print("Dry run — no install performed.")
        return 0

    print(f"Installing {args.name} from {url} ...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", url],
        check=False,
    )

    if result.returncode == 0:
        print(f"Installed: {args.name}")
    else:
        print(
            f"Install failed (pip exit code {result.returncode})",
            file=sys.stderr,
        )

    return result.returncode


def _run_pack_info(args: argparse.Namespace) -> int:
    """Print detailed information about a named pack.

    If the pack is installed, prints its :class:`~netsight.packs.PackInfo`
    fields. If the pack is also in the index (or only in the index), the
    index metadata is printed too. Errors if the name is found in neither.

    With ``--json``, emits a single JSON document combining installed info
    and index metadata instead of plain text.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.name`` (str), ``args.json`` (bool),
        and ``args.no_color`` (bool).

    Returns
    -------
    int
        0 if information was found, 1 otherwise.
    """
    name = args.name
    found = False

    if getattr(args, "json", False):
        return _run_pack_info_json(args)

    if pack_registry.has(name=name):
        info = pack_registry.get(name=name)
        print(f"Pack: {info.name}")
        print(f"  Vendor:        {info.vendor}")
        print(f"  Device class:  {info.device_type}")
        print(f"  Protocol:      {info.protocol}")
        print(f"  Distribution:  {info.distribution}")
        print(f"  Version:       {info.version}")
        print(f"  Config root:   {info.config_root}")
        if info.metadata:
            print("  Metadata:")
            for k, v in sorted(info.metadata.items()):
                print(f"    {k}: {v}")
        found = True

    index = load_index()
    entry = index.get(name)
    if entry is not None:
        if found:
            print()
        print(f"Index entry: {entry.name}")
        print(f"  Description: {entry.description}")
        print(f"  Status:      {entry.status}")
        print(f"  Repo:        {entry.repo}")
        if entry.subdirectory:
            print(f"  Subdir:      {entry.subdirectory}")
        print(f"  Min core:    {entry.min_sdk}")
        if entry.maintainers:
            print(f"  Maintainers: {', '.join(entry.maintainers)}")
        found = True

    if not found:
        print(
            f"Error: Pack {name!r} is not installed and not in the index.",
            file=sys.stderr,
        )
        return 1

    return 0


def _run_pack_info_json(args: argparse.Namespace) -> int:
    """Emit pack info as a JSON document.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.name`` (str).

    Returns
    -------
    int
        0 if information was found, 1 otherwise.
    """
    name = args.name
    doc: dict[str, Any] = {}
    found = False

    if pack_registry.has(name=name):
        info = pack_registry.get(name=name)
        doc["installed"] = {
            "name": info.name,
            "vendor": info.vendor,
            "device_type": info.device_type,
            "protocol": info.protocol,
            "distribution": info.distribution,
            "version": info.version,
            "config_root": str(info.config_root),
            "metadata": dict(info.metadata),
        }
        found = True

    index = load_index()
    entry = index.get(name)
    if entry is not None:
        doc["index"] = {
            "name": entry.name,
            "description": entry.description,
            "status": entry.status,
            "repo": entry.repo,
            "subdirectory": entry.subdirectory,
            "min_sdk": entry.min_sdk,
            "maintainers": list(entry.maintainers),
        }
        found = True

    if not found:
        print(
            f"Error: Pack {name!r} is not installed and not in the index.",
            file=sys.stderr,
        )
        return 1

    print(json.dumps(doc, indent=2, default=str))
    return 0


def _run_pack_uninstall(args: argparse.Namespace) -> int:
    """Uninstall a pack via pip.

    Calls ``pip uninstall -y netsight-pack-<name>`` and streams output
    directly to the user's terminal.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.name`` (str).

    Returns
    -------
    int
        pip's exit code.
    """
    dist_name = f"netsight-pack-{args.name}"
    print(f"Uninstalling {dist_name} ...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "uninstall", "-y", dist_name],
        check=False,
    )
    return result.returncode


def _run_pack_doctor(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Validate every installed pack's config tree via the compiler.

    For each registered pack, constructs a :class:`ConfigCompiler` in
    pack mode and runs ``compile_pack(name, validate_only=True)``. Prints
    ``ok`` or ``FAIL + first error`` per pack. Also dumps any packs that
    failed to register at all (via
    :meth:`~netsight.packs.PackRegistry.load_errors`).

    Parameters
    ----------
    args:
        Parsed namespace (unused).

    Returns
    -------
    int
        0 if every pack compiles cleanly, 1 if any pack fails.
    """
    from netsight.config_mgmt.compiler import ConfigCompiler

    any_failed = False

    installed = pack_registry.list()
    if not installed:
        print("No packs installed.")
    else:
        print(f"{'PACK':<36} {'RESULT'}")
        print("-" * 55)
        for info in sorted(installed, key=lambda p: p.name):
            compiler = ConfigCompiler(
                pack_roots={info.name: info.config_root}
            )
            result = compiler.compile_pack(info.name, validate_only=True)
            if result.success:
                print(f"  {info.name:<34} ok")
            else:
                first_err = result.errors[0].message if result.errors else "unknown error"
                print(f"  {info.name:<34} FAIL: {first_err}")
                any_failed = True

    load_errors = pack_registry.load_errors()
    if load_errors:
        print()
        print("Pack load errors (failed to register):")
        for name, exc in sorted(load_errors.items()):
            print(f"  {name}: {type(exc).__name__}: {exc}")
        any_failed = True

    return 1 if any_failed else 0
