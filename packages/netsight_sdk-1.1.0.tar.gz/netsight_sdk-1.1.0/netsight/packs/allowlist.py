"""User-managed allowlist for installed NetSight packs.

A pack ships a catalog of operations it KNOWS HOW to execute. Installing
a pack does NOT grant permission to run any of these — the user must
explicitly opt in via a per-pack allowlist file in the user config
directory. This module provides load/save/validate helpers for those
files.

File shape (``~/.config/netsight/allowlists/<pack-name>.toml``)::

    pack = "paloalto-firewall-xml"
    pack_version = "0.1.0"          # recorded at last update — for drift detection
    updated_at = "2026-04-08T14:23:17Z"
    enabled = [
        "show_system_info",
        "show_interfaces",
    ]

Default state: no file on disk → empty allowlist → CommandGate denies
every operation for that pack.
"""

from __future__ import annotations

import datetime
import tomllib
from dataclasses import dataclass
from pathlib import Path

from netsight.config_mgmt.user_config import resolve_config_dir


@dataclass(frozen=True)
class Allowlist:
    """A user allowlist file for a single pack.

    Attributes
    ----------
    pack:
        The pack name this allowlist applies to.
    pack_version:
        The version of the pack recorded when the allowlist was last
        updated. Used for drift detection.
    enabled:
        The frozenset of operation names the user has enabled.
    updated_at:
        ISO-8601 timestamp of the last update.
    """

    pack: str
    enabled: frozenset[str]
    pack_version: str = ""
    updated_at: str = ""


def allowlist_dir() -> Path:
    """Return the user's allowlists directory (not necessarily existing).

    Built on top of :func:`resolve_config_dir` so the search order for
    user config (env var → cwd → XDG → home) applies uniformly to
    both ``devices.yaml`` and the allowlist files.

    Returns
    -------
    Path
        The path to ``<config_dir>/allowlists/``.
    """
    return resolve_config_dir() / "allowlists"


def allowlist_path(pack_name: str) -> Path:
    """Return the path to a single pack's allowlist file.

    Parameters
    ----------
    pack_name:
        The canonical pack name (e.g. ``"paloalto-firewall-xml"``).

    Returns
    -------
    Path
        ``<allowlist_dir>/<pack_name>.toml``.
    """
    return allowlist_dir() / f"{pack_name}.toml"


def load_allowlist(pack_name: str) -> Allowlist:
    """Load the allowlist for *pack_name* from disk.

    Returns an empty :class:`Allowlist` if no file exists — the
    default-deny state. Errors on malformed TOML are surfaced to the
    caller as :class:`OSError` / :class:`tomllib.TOMLDecodeError`.

    Parameters
    ----------
    pack_name:
        The canonical pack name.

    Returns
    -------
    Allowlist
        The loaded allowlist, or an empty one when no file exists.

    Raises
    ------
    tomllib.TOMLDecodeError
        If the allowlist file exists but contains invalid TOML.
    OSError
        If the file exists but cannot be read.
    """
    path = allowlist_path(pack_name)
    if not path.is_file():
        return Allowlist(pack=pack_name, enabled=frozenset())
    data = tomllib.loads(path.read_text(encoding="utf-8"))
    return Allowlist(
        pack=data.get("pack", pack_name),
        enabled=frozenset(data.get("enabled", [])),
        pack_version=data.get("pack_version", ""),
        updated_at=data.get("updated_at", ""),
    )


def save_allowlist(allowlist: Allowlist, *, pack_version: str = "") -> Path:
    """Write an :class:`Allowlist` to disk.

    Creates the parent directory (mode ``0o700``) if missing. Overwrites
    any existing file at the target path. The ``updated_at`` field is
    stamped with the current UTC time; the ``pack_version`` field is
    taken from the parameter (callers pass ``pack_info.version``).

    Parameters
    ----------
    allowlist:
        The allowlist to persist.
    pack_version:
        The current installed version of the pack; stored in the file
        for drift detection.

    Returns
    -------
    Path
        The path the file was written to.
    """
    path = allowlist_path(allowlist.pack)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Restrict permissions to owner-only on POSIX (harmless no-op on Windows).
    try:
        path.parent.chmod(0o700)
    except (OSError, NotImplementedError):
        pass
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    content_lines = [
        f'pack = "{allowlist.pack}"',
        f'pack_version = "{pack_version}"',
        f'updated_at = "{now}"',
        "enabled = [",
    ]
    for op in sorted(allowlist.enabled):
        content_lines.append(f'    "{op}",')
    content_lines.append("]")
    content_lines.append("")
    path.write_text("\n".join(content_lines), encoding="utf-8")
    return path


def list_allowlist_files() -> list[Path]:
    """Return every ``*.toml`` under the allowlists dir, sorted.

    Returns an empty list if the allowlists directory does not yet
    exist (fresh install state).

    Returns
    -------
    list[Path]
        Sorted list of ``.toml`` file paths.
    """
    d = allowlist_dir()
    if not d.is_dir():
        return []
    return sorted(d.glob("*.toml"))
