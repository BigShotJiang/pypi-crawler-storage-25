"""Traversable adapter helpers for the NetSight pack system.

:func:`as_traversable` accepts either a :class:`pathlib.Path` or an object
already satisfying :class:`importlib.resources.abc.Traversable` (such as the
result of ``importlib.resources.files(pkg)``) and returns a value that
satisfies the :class:`~importlib.resources.abc.Traversable` protocol.

In Python 3.14 both :class:`~pathlib.Path` and the return value of
:func:`importlib.resources.files` already implement the full
:class:`~importlib.resources.abc.Traversable` surface, so no wrapping is
needed — this helper exists to provide a single, typed coercion point that
callers throughout the pack system can use without worrying about the
underlying type.

Usage
-----
::

    from pathlib import Path
    from netsight.packs._traversable import as_traversable

    root = as_traversable(Path("/etc/netsight"))

    import importlib.resources
    root = as_traversable(importlib.resources.files("my_pack"))
"""

from __future__ import annotations

import logging
from importlib.resources.abc import Traversable
from pathlib import Path

logger = logging.getLogger(__name__)


def as_traversable(root: Path | Traversable) -> Traversable:
    """Coerce *root* to a :class:`~importlib.resources.abc.Traversable`.

    Both :class:`~pathlib.Path` instances and the objects returned by
    :func:`importlib.resources.files` satisfy the
    :class:`~importlib.resources.abc.Traversable` protocol in Python 3.14,
    so this function is an identity coercion: it validates that *root* is an
    acceptable input type and returns it unchanged, typed as
    :class:`~importlib.resources.abc.Traversable`.

    Parameters
    ----------
    root:
        A filesystem path (:class:`~pathlib.Path`) or any object that already
        satisfies the :class:`~importlib.resources.abc.Traversable` protocol.

    Returns
    -------
    Traversable
        The same object, typed as :class:`~importlib.resources.abc.Traversable`.

    Raises
    ------
    TypeError
        If *root* is neither a :class:`~pathlib.Path` nor a
        :class:`~importlib.resources.abc.Traversable`.

    Examples
    --------
    Wrapping a filesystem path::

        from pathlib import Path
        from netsight.packs._traversable import as_traversable

        t = as_traversable(Path("/etc/netsight"))
        assert t.is_dir()

    Wrapping a package resource root::

        import importlib.resources
        from netsight.packs._traversable import as_traversable

        t = as_traversable(importlib.resources.files("netsight"))
        assert t.is_dir()
    """
    if isinstance(root, Traversable):
        # Path satisfies Traversable in Python 3.14, so this branch handles
        # both Path objects and any other Traversable (e.g. importlib.resources
        # MultiplexedPath, zipfile.Path, etc.).
        logger.debug("as_traversable: returning %r as Traversable", root)
        return root

    raise TypeError(
        f"as_traversable() expects a pathlib.Path or Traversable, "
        f"got {type(root).__qualname__!r}"
    )
