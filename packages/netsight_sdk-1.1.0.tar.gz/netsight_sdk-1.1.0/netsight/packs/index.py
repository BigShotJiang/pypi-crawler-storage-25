"""Load the bundled + user pack index."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from importlib.resources import files
from pathlib import Path

import logging

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class IndexEntry:
    """Metadata entry from the bundled or user-provided pack index.

    Attributes
    ----------
    name:
        Canonical pack name, e.g. ``"paloalto-firewall-xml"``.
    repo:
        GitHub repository URL, e.g.
        ``"https://github.com/<org>/netsight-packs-paloalto"``.
    subdirectory:
        Optional subdirectory within the repo that contains the pack, e.g.
        ``"packs/paloalto-firewall-xml"``.
    description:
        Human-readable description of what the pack provides.
    status:
        Lifecycle status: ``"stable"``, ``"beta"``, ``"experimental"``, or
        ``"deprecated"``.
    min_sdk:
        PEP-440 version specifier describing the compatible core version
        range, e.g. ``">=0.2.0,<0.3"``.
    maintainers:
        Tuple of maintainer strings from the index entry.
    """

    name: str
    repo: str
    subdirectory: str | None
    description: str
    status: str
    min_sdk: str
    maintainers: tuple[str, ...] = field(default_factory=tuple)


def load_index() -> dict[str, IndexEntry]:
    """Load and merge the bundled + user pack indexes.

    The bundled ``netsight/packs/_index.toml`` is always loaded. If
    ``$NETSIGHT_PACK_INDEX`` is set and points at a readable TOML file,
    its entries are merged into the result. User entries win on name
    conflict (last-wins, matching the plan's locked-in decision).

    Returns
    -------
    dict[str, IndexEntry]
        Pack name -> IndexEntry mapping.
    """
    entries: dict[str, IndexEntry] = {}

    bundled = files("netsight.packs") / "_index.toml"
    try:
        entries.update(_parse_index(bundled.read_text(encoding="utf-8")))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to load bundled pack index: %s", exc)

    user_path = os.environ.get("NETSIGHT_PACK_INDEX")
    if user_path:
        try:
            user_text = Path(user_path).read_text(encoding="utf-8")
            entries.update(_parse_index(user_text))
        except (FileNotFoundError, PermissionError):
            pass  # Silent fallback — the override is optional.

    return entries


def _parse_index(toml_text: str) -> dict[str, IndexEntry]:
    """Parse a TOML index document into a dict of IndexEntry objects.

    Parameters
    ----------
    toml_text:
        Raw TOML text containing a ``[packs]`` section.

    Returns
    -------
    dict[str, IndexEntry]
        Mapping of pack name to :class:`IndexEntry`.
    """
    data = tomllib.loads(toml_text)
    result: dict[str, IndexEntry] = {}
    for name, spec in data.get("packs", {}).items():
        result[name] = IndexEntry(
            name=name,
            repo=spec["repo"],
            subdirectory=spec.get("subdirectory"),
            description=spec.get("description", ""),
            status=spec.get("status", "unknown"),
            min_sdk=spec.get("min_sdk", ""),
            maintainers=tuple(spec.get("maintainers", [])),
        )
    return result
