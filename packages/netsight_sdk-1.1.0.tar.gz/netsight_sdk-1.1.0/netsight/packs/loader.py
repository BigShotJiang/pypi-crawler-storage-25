"""Entry-point discovery and per-pack error-isolated loading for NetSight packs.

This module implements the runtime discovery half of the install-packs
architecture.  At application startup the caller invokes
:func:`load_installed_packs`, which iterates every distribution that declares
an entry point in the ``netsight.packs`` group and calls its ``register()``
callable with the registry as the sole argument.

Failures are **isolated per pack**: if one pack's import or ``register()``
call raises, that exception is recorded via
:meth:`~netsight.packs.registry.PackRegistry.record_load_error` and the loop
continues with the next pack.  This means a broken pack never prevents healthy
packs from loading.

The typical call site is
:meth:`~netsight.packs.registry.PackRegistry.ensure_loaded`, which delegates
here exactly once (guarded by a :class:`threading.Lock`).

Usage
-----
::

    from netsight.packs.registry import pack_registry
    pack_registry.ensure_loaded()  # idempotent; safe to call many times
"""

from __future__ import annotations

import logging
from importlib.metadata import entry_points
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from netsight.packs.registry import PackRegistry

logger = logging.getLogger(__name__)


def load_installed_packs(registry: PackRegistry) -> None:
    """Discover and load all installed ``netsight.packs`` entry points.

    Iterates every distribution that advertises a ``netsight.packs`` entry
    point, imports the callable it points to, and calls it with *registry*
    as the sole argument.  Failures at either the import stage or the
    registration stage are caught, logged, and recorded on *registry* via
    :meth:`~netsight.packs.registry.PackRegistry.record_load_error`; the
    loop always continues to the next entry point.

    Parameters
    ----------
    registry:
        The :class:`~netsight.packs.registry.PackRegistry` instance that
        each pack's ``register()`` callable will receive.  Typically the
        module-level :data:`~netsight.packs.registry.pack_registry` singleton.

    Returns
    -------
    None
        This function has no return value.  Side effects are recorded on
        *registry* (successful registrations) and via the module logger
        (warnings for failed packs).

    Notes
    -----
    The broad ``except Exception`` clauses carry ``# noqa: BLE001`` because
    this function is a top-level aggregation point: letting *any* pack failure
    propagate would prevent all subsequent packs from loading, which violates
    the per-pack isolation contract.  The same pattern is used throughout
    ``netsight/cli.py`` for the same reason.
    """
    # Local imports avoid a circular dependency at module level.
    # loader.py is imported *from inside* registry.py's ensure_loaded(), which
    # itself is called from within the netsight.packs package initialisation
    # chain.  Importing netsight.packs or netsight at module level in loader.py
    # would create a cycle that Python cannot resolve at import time.
    from packaging.specifiers import SpecifierSet  # noqa: PLC0415
    from packaging.version import Version  # noqa: PLC0415

    import netsight  # noqa: PLC0415
    from netsight.packs import PLUGIN_API_VERSION  # noqa: PLC0415
    from netsight.packs.exceptions import PackIncompatibleError  # noqa: PLC0415

    eps = entry_points(group="netsight.packs")
    for ep in eps:
        try:
            register_fn = ep.load()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Pack %r failed to import: %s", ep.name, exc)
            registry.record_load_error(name=ep.name, exc=exc)
            continue

        try:
            register_fn(registry)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Pack %r register() raised: %s", ep.name, exc)
            registry.record_load_error(name=ep.name, exc=exc)
            continue

        # ------------------------------------------------------------------
        # Post-registration compatibility checks.
        # If either check fails the pack is unregistered and a load error is
        # recorded so the CLI can surface it without crashing.
        # ------------------------------------------------------------------

        # Retrieve the PackInfo that register_fn just stored, if any.
        # A badly-behaved pack might not call registry.register() at all;
        # in that case there is nothing to validate.
        if not registry.has(name=ep.name):
            continue

        info = registry.get(name=ep.name)

        # Check 1 — plugin API version.
        if info.declared_plugin_api != PLUGIN_API_VERSION:
            exc = PackIncompatibleError(
                pack_name=ep.name,
                detail=(
                    f"declared_plugin_api={info.declared_plugin_api} "
                    f"does not match SDK PLUGIN_API_VERSION={PLUGIN_API_VERSION}"
                ),
            )
            registry.unregister(name=ep.name)
            registry.record_load_error(name=ep.name, exc=exc)
            continue

        # Check 2 — SDK version range.
        if info.min_sdk_version:
            try:
                spec = SpecifierSet(info.min_sdk_version)
                sdk_ver = Version(netsight.__version__)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Pack %r has an unparseable min_sdk_version %r: %s",
                    ep.name,
                    info.min_sdk_version,
                    exc,
                )
                registry.unregister(name=ep.name)
                registry.record_load_error(name=ep.name, exc=exc)
                continue

            if sdk_ver not in spec:
                exc = PackIncompatibleError(
                    pack_name=ep.name,
                    detail=(
                        f"SDK version {netsight.__version__!r} does not satisfy "
                        f"pack requirement {info.min_sdk_version!r}"
                    ),
                )
                registry.unregister(name=ep.name)
                registry.record_load_error(name=ep.name, exc=exc)
                continue
