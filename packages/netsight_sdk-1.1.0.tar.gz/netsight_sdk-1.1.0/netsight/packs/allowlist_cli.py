"""CLI handler functions for the ``netsight allowlist`` subcommand.

Each ``_run_allowlist_*`` function maps directly to one ``netsight allowlist``
sub-action. Handlers follow the project convention: accept a parsed
:class:`argparse.Namespace`, print output, and return an ``int`` exit
code (0 = success, non-zero = failure).

Handlers are *pure* with respect to I/O — they do not call
:func:`sys.exit` themselves; the caller in :func:`netsight.cli.main`
does that.
"""

from __future__ import annotations

import argparse
import logging
import sys
import tomllib
from typing import Any

logger = logging.getLogger(__name__)

# Module-level imports so tests can patch at ``netsight.packs.allowlist_cli.<name>``.
from netsight.packs.allowlist import (  # noqa: E402
    Allowlist,
    list_allowlist_files,
    load_allowlist,
    save_allowlist,
)
from netsight.packs.registry import pack_registry  # noqa: E402


def _load_catalog(pack_name: str) -> dict[str, dict[str, Any]] | None:
    """Load the operations catalog for *pack_name* from its config_root.

    Returns the catalog dict (op_name → op_config) or ``None`` when the
    pack is not installed or the catalog file cannot be read.

    Parameters
    ----------
    pack_name:
        Canonical pack name (e.g. ``"paloalto-firewall-xml"``).

    Returns
    -------
    dict[str, dict[str, Any]] | None
        The catalog, or ``None`` on failure.
    """
    pack_registry.ensure_loaded()
    if not pack_registry.has(name=pack_name):
        return None
    pack_info = pack_registry.get(name=pack_name)
    config_root = pack_info.config_root

    # Prefer new name; fall back to legacy.
    ops_file = config_root.joinpath("operations_catalog.toml")
    if not ops_file.is_file():
        ops_file = config_root.joinpath("operations.toml")
    if not ops_file.is_file():
        return None

    try:
        raw = tomllib.loads(ops_file.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read catalog for %s: %s", pack_name, exc)
        return None

    return {k: v for k, v in raw.items() if isinstance(v, dict)}


def _run_allowlist_list(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Print every installed pack with ``enabled / total`` counts.

    Example output::

        paloalto-firewall-xml: 2 of 10 enabled
        other-pack:            0 of 5 enabled (all denied)

    Parameters
    ----------
    args:
        Parsed namespace (unused).

    Returns
    -------
    int
        Always 0.
    """
    pack_registry.ensure_loaded()
    installed = pack_registry.list()

    if not installed:
        print("No packs installed.")
        return 0

    for pack_info in sorted(installed, key=lambda p: p.name):
        catalog = _load_catalog(pack_info.name) or {}
        total = len(catalog)
        user = load_allowlist(pack_info.name)
        enabled_count = len(user.enabled & set(catalog))
        suffix = " (all denied)" if enabled_count == 0 else ""
        print(f"  {pack_info.name}: {enabled_count} of {total} enabled{suffix}")

    return 0


def _run_allowlist_show(args: argparse.Namespace) -> int:
    """Print the full catalog for *args.pack* with checkbox status.

    For each operation in the catalog, prints ``[x]`` when enabled and
    ``[ ]`` when disabled, followed by a summary of all enabled op names.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.pack`` (str).

    Returns
    -------
    int
        0 on success, 1 if the pack is not installed.
    """
    pack_name = args.pack
    pack_registry.ensure_loaded()

    if not pack_registry.has(name=pack_name):
        print(
            f"Error: Pack {pack_name!r} is not installed.",
            file=sys.stderr,
        )
        return 1

    catalog = _load_catalog(pack_name)
    if catalog is None:
        print(
            f"Error: Could not load catalog for {pack_name!r}.",
            file=sys.stderr,
        )
        return 1

    user = load_allowlist(pack_name)
    print(f"Allowlist for {pack_name}:")
    print()

    for op_name, op_config in sorted(catalog.items()):
        mark = "x" if op_name in user.enabled else " "
        category = op_config.get("category", "")
        desc = op_config.get("description", "")
        ro_flag = " [read_only]" if op_config.get("read_only") else " [NOT read_only]"
        print(f"  [{mark}]  {op_name:<36} {category:<10} {desc}{ro_flag}")

    print()
    enabled_in_catalog = sorted(user.enabled & set(catalog))
    if enabled_in_catalog:
        print(f"Enabled: {', '.join(enabled_in_catalog)}")
    else:
        print("Enabled: (none — all operations denied)")

    return 0


def _run_allowlist_enable(args: argparse.Namespace) -> int:
    """Enable one or more operations in a pack's allowlist.

    Accepts positional op names, ``--category <name>``, or ``--all``
    (requires ``--yes`` to guard against accidental bulk-enable).

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.pack``, ``args.ops``,
        ``args.category``, ``args.all``, ``args.yes``.

    Returns
    -------
    int
        0 on success, 1 on any error.
    """
    pack_name = args.pack
    pack_registry.ensure_loaded()

    if not pack_registry.has(name=pack_name):
        print(
            f"Error: Pack {pack_name!r} is not installed.",
            file=sys.stderr,
        )
        return 1

    catalog = _load_catalog(pack_name)
    if catalog is None:
        print(
            f"Error: Could not load catalog for {pack_name!r}.",
            file=sys.stderr,
        )
        return 1

    use_all: bool = getattr(args, "all", False)
    use_category: str | None = getattr(args, "category", None)
    positional_ops: list[str] = list(getattr(args, "ops", None) or [])

    # Determine the set of ops to enable.
    if use_all:
        if not getattr(args, "yes", False):
            print(
                "Error: --all requires --yes to prevent accidental bulk-enable.",
                file=sys.stderr,
            )
            return 1
        ops_to_enable = [
            op for op, cfg in catalog.items() if cfg.get("read_only", False)
        ]
    elif use_category:
        ops_to_enable = [
            op
            for op, cfg in catalog.items()
            if cfg.get("category") == use_category and cfg.get("read_only", False)
        ]
        if not ops_to_enable:
            print(
                f"Error: No read_only=true operations found in category "
                f"{use_category!r} for pack {pack_name!r}.",
                file=sys.stderr,
            )
            return 1
    else:
        ops_to_enable = positional_ops

    if not ops_to_enable:
        print("Error: No operations specified.", file=sys.stderr)
        return 1

    # Validate: must be in catalog and must be read_only.
    not_in_catalog = [op for op in ops_to_enable if op not in catalog]
    if not_in_catalog:
        print(
            f"Error: The following operation(s) are not in the catalog for "
            f"{pack_name!r}: {not_in_catalog}\n"
            f"Run 'netsight allowlist show {pack_name}' to see available operations.",
            file=sys.stderr,
        )
        return 1

    not_read_only = [op for op in ops_to_enable if not catalog[op].get("read_only", False)]
    if not_read_only:
        print(
            f"Error: The following operation(s) are not marked read_only=true "
            f"in the catalog and cannot be enabled: {not_read_only}",
            file=sys.stderr,
        )
        return 1

    # Load, update, save.
    user = load_allowlist(pack_name)
    new_enabled = user.enabled | frozenset(ops_to_enable)
    updated = Allowlist(pack=pack_name, enabled=new_enabled)

    pack_info = pack_registry.get(name=pack_name)
    path = save_allowlist(updated, pack_version=pack_info.version)

    newly_added = sorted(frozenset(ops_to_enable) - user.enabled)
    if newly_added:
        ops_str = ", ".join(f"+ {op}" for op in newly_added)
        print(f"Enabled {len(newly_added)} operation(s): {ops_str}")
        print(f"Allowlist written to: {path}")
    else:
        print("All specified operations were already enabled. No changes made.")

    return 0


def _run_allowlist_disable(args: argparse.Namespace) -> int:
    """Disable one or more operations from a pack's allowlist.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.pack`` and ``args.ops``.

    Returns
    -------
    int
        0 on success, 1 on error.
    """
    pack_name = args.pack
    pack_registry.ensure_loaded()

    if not pack_registry.has(name=pack_name):
        print(
            f"Error: Pack {pack_name!r} is not installed.",
            file=sys.stderr,
        )
        return 1

    ops_to_disable: list[str] = list(getattr(args, "ops", None) or [])
    if not ops_to_disable:
        print("Error: No operations specified.", file=sys.stderr)
        return 1

    user = load_allowlist(pack_name)
    not_enabled = [op for op in ops_to_disable if op not in user.enabled]
    if not_enabled:
        print(
            f"Error: The following operation(s) are not currently enabled "
            f"and cannot be disabled: {not_enabled}",
            file=sys.stderr,
        )
        return 1

    new_enabled = user.enabled - frozenset(ops_to_disable)
    updated = Allowlist(pack=pack_name, enabled=new_enabled)

    pack_info = pack_registry.get(name=pack_name)
    path = save_allowlist(updated, pack_version=pack_info.version)

    removed = sorted(ops_to_disable)
    ops_str = ", ".join(f"- {op}" for op in removed)
    print(f"Disabled {len(removed)} operation(s): {ops_str}")
    print(f"Allowlist written to: {path}")

    return 0


def _run_allowlist_clear(args: argparse.Namespace) -> int:
    """Write an empty ``enabled = []`` allowlist for *args.pack*.

    Requires ``--yes`` to guard against accidental wipes.

    Parameters
    ----------
    args:
        Parsed namespace. Reads ``args.pack`` and ``args.yes``.

    Returns
    -------
    int
        0 on success, 1 on error.
    """
    pack_name = args.pack

    if not getattr(args, "yes", False):
        print(
            "Error: 'netsight allowlist clear' requires --yes to confirm.",
            file=sys.stderr,
        )
        return 1

    pack_registry.ensure_loaded()
    if not pack_registry.has(name=pack_name):
        print(
            f"Error: Pack {pack_name!r} is not installed.",
            file=sys.stderr,
        )
        return 1

    empty = Allowlist(pack=pack_name, enabled=frozenset())
    pack_info = pack_registry.get(name=pack_name)
    path = save_allowlist(empty, pack_version=pack_info.version)
    print(f"Allowlist for {pack_name!r} cleared (all operations denied).")
    print(f"Allowlist written to: {path}")

    return 0


def _run_allowlist_audit(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Cross-check every device in devices.yaml against its pack's allowlist.

    Reports:
    - Devices referencing an uninstalled pack.
    - Devices with ``allowed_operations`` containing ops not in the global
      allowlist.
    - Packs with allowlist files but no installed pack (orphan allowlists).

    Parameters
    ----------
    args:
        Parsed namespace (unused — reads devices.yaml via resolve_config_file).

    Returns
    -------
    int
        0 when no issues found, 1 otherwise.
    """
    from netsight.config_mgmt.user_config import resolve_config_file

    pack_registry.ensure_loaded()
    issues: list[str] = []

    # Check devices.yaml if it exists.
    devices_path = resolve_config_file("devices.yaml")
    if devices_path is not None:
        try:
            import yaml  # type: ignore[import-untyped]
            raw = yaml.safe_load(devices_path.read_text(encoding="utf-8"))
            devices = raw.get("devices", []) if isinstance(raw, dict) else []
        except Exception as exc:  # noqa: BLE001
            print(f"Warning: Could not parse devices.yaml: {exc}", file=sys.stderr)
            devices = []

        for device in devices:
            if not isinstance(device, dict):
                continue
            name = device.get("name", "<unnamed>")
            api_type = device.get("api_type", "")
            if not pack_registry.has(name=api_type):
                issues.append(
                    f"  Device {name!r}: api_type {api_type!r} is not an installed pack"
                )
                continue

            global_allowlist = load_allowlist(api_type).enabled
            per_device = device.get("allowed_operations")
            if per_device is not None and isinstance(per_device, list):
                orphaned = set(per_device) - global_allowlist
                if orphaned:
                    issues.append(
                        f"  Device {name!r}: allowed_operations references op(s) not in "
                        f"global allowlist for {api_type!r}: {sorted(orphaned)}"
                    )

    # Check for orphan allowlist files (no installed pack).
    for alist_path in list_allowlist_files():
        pack_name = alist_path.stem
        if not pack_registry.has(name=pack_name):
            issues.append(
                f"  Orphan allowlist: {alist_path.name} — pack {pack_name!r} is not installed"
            )

    if issues:
        print("Allowlist audit found issues:")
        for issue in issues:
            print(issue)
        return 1

    print("Allowlist audit: no issues found.")
    return 0
