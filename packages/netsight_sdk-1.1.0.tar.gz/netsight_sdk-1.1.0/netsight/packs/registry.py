"""PackInfo dataclass and PackRegistry for the NetSight pack system.

Provides the two central types of the install-packs architecture:

:class:`PackInfo`
    A frozen dataclass that records the full identity and capabilities of a
    single vendor pack.  The ``name``, ``vendor``, ``device_type``,
    ``protocol``, and ``distribution`` fields are mutually constrained by
    convention (enforced in ``__post_init__``).

:class:`PackRegistry`
    A registry that stores :class:`PackInfo` records keyed by canonical pack
    name.  Supports registration, lookup, filtering, and load-error recording.

:data:`pack_registry`
    The module-level singleton :class:`PackRegistry` that the rest of
    the application imports::

        from netsight.packs.registry import pack_registry

Usage
-----
::

    from netsight.packs.registry import PackInfo, pack_registry

    info = PackInfo(
        name="paloalto-firewall-xml",
        vendor="paloalto",
        device_type="firewall",
        protocol="xml",
        distribution="netsight-pack-paloalto-firewall-xml",
        version="0.1.0",
        client_class=PanosXmlClient,
        allowed_operations={"show_routes", "show_arp_table", "show_system_info"},
        config_root=importlib.resources.files("netsight_pack_paloalto_firewall_xml") / "_data",
    )
    pack_registry.register(info=info)
"""

from __future__ import annotations

import builtins
import logging
import threading
from dataclasses import dataclass, field
from importlib.resources.abc import Traversable
from typing import Any

from netsight.packs.exceptions import PackConflictError, PackRegistrationError

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PackInfo:
    """Metadata record for a single NetSight vendor pack.

    Instances are immutable (``frozen=True``).  The ``name``,
    ``vendor``, ``device_type``, ``protocol``, and ``distribution``
    fields must satisfy the naming convention enforced by
    :meth:`__post_init__`::

        name         == f"{vendor}-{device_type}-{protocol}"
        distribution == f"netsight-pack-{name}"

    Attributes
    ----------
    name:
        Canonical pack identity string.  Format: ``<vendor>-<device_type>-<protocol>``.
        This is also the key used in the registry and the entry-point name.
    vendor:
        Vendor identifier component, e.g. ``"paloalto"``, ``"cisco"``.
    device_type:
        High-level device class component, e.g. ``"firewall"``, ``"router"``,
        ``"switch"``.  This is the *class*, not the product model.
    protocol:
        Transport/API protocol component, e.g. ``"xml"``, ``"rest"``,
        ``"ssh"``.
    distribution:
        PyPI/GitHub distribution package name.  Format:
        ``netsight-pack-<name>``.
    version:
        Installed version string, e.g. ``"0.1.0"``.
    client_class:
        The class used to connect to and query devices of this type.
    allowed_operations:
        Frozenset of operation strings this pack permits.  The config
        compiler will reject any operation not in this set.
    config_root:
        A :class:`~importlib.resources.abc.Traversable` pointing at the
        pack's bundled ``_data/`` directory.  Use
        :func:`~netsight.packs._traversable.as_traversable` to coerce a
        :class:`~pathlib.Path` before passing it here.
    validator_class:
        Optional class responsible for validating device configuration.
    metadata:
        Arbitrary key/value data supplied by the pack author.
    min_sdk_version:
        PEP 440 specifier constraining the required SDK version range, e.g.
        ``">=1.0,<2.0"``.  An empty string means unconstrained (the default).
        The loader enforces this at registration time.
    max_sdk_version:
        Reserved upper-bound specifier.  Unused today but recorded for
        forward compatibility.  Defaults to an empty string (unconstrained).
    declared_plugin_api:
        Integer plugin-API slot the pack was built against.  Must match
        :data:`netsight.packs.PLUGIN_API_VERSION` at load time; a mismatch
        causes the loader to record a :class:`PackIncompatibleError` and
        skip the pack.  Defaults to ``1``.
    """

    name: str
    vendor: str
    device_type: str
    protocol: str
    distribution: str
    version: str
    client_class: type
    allowed_operations: frozenset[str]
    config_root: Traversable
    validator_class: type | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    min_sdk_version: str = ""
    max_sdk_version: str = ""
    declared_plugin_api: int = 1

    def __post_init__(self) -> None:
        """Enforce naming conventions.

        Raises
        ------
        PackRegistrationError
            If ``name != f"{vendor}-{device_type}-{protocol}"`` or
            ``distribution != f"netsight-pack-{name}"``.
        """
        expected_name = f"{self.vendor}-{self.device_type}-{self.protocol}"
        if self.name != expected_name:
            raise PackRegistrationError(
                pack_name=self.name,
                detail=(
                    f"name must equal 'vendor-device_type-protocol'; "
                    f"expected '{expected_name}', got '{self.name}'"
                ),
            )

        expected_dist = f"netsight-pack-{self.name}"
        if self.distribution != expected_dist:
            raise PackRegistrationError(
                pack_name=self.name,
                detail=(
                    f"distribution must equal 'netsight-pack-{{name}}'; "
                    f"expected '{expected_dist}', got '{self.distribution}'"
                ),
            )


class PackRegistry:
    """Central registry of installed NetSight vendor packs.

    Each pack is identified by its canonical *name*
    (``<vendor>-<device_type>-<protocol>``) and stored as a
    :class:`PackInfo` record.  Duplicate names are rejected at registration
    time so that conflicting installed distributions are caught early.

    The typical entry point is :data:`pack_registry`, the module-level
    singleton, but tests may construct independent :class:`PackRegistry`
    instances for isolation.

    Load errors (exceptions raised by a pack's ``register()`` entry point
    during discovery) can be recorded via :meth:`record_load_error` and
    retrieved via :meth:`load_errors`.  This allows the rest of the
    application to surface problems without crashing.
    """

    def __init__(self) -> None:
        """Initialise an empty registry."""
        self._packs: dict[str, PackInfo] = {}
        self._errors: dict[str, Exception] = {}
        self._loaded: bool = False
        self._load_lock: threading.Lock = threading.Lock()

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, *, info: PackInfo) -> None:
        """Register *info* under its canonical name.

        Parameters
        ----------
        info:
            The :class:`PackInfo` record to store.

        Raises
        ------
        PackConflictError
            If a pack with the same ``name`` has already been registered.
        """
        if info.name in self._packs:
            raise PackConflictError(info.name)
        self._packs[info.name] = info
        logger.info(
            "Pack registered: '%s' v%s (client=%s)",
            info.name,
            info.version,
            info.client_class.__name__,
        )

    def unregister(self, *, name: str) -> None:
        """Remove the pack named *name* from the registry.

        Used by the loader to roll back a successfully-registered pack when
        post-registration compatibility checks fail.  Silently does nothing
        if *name* is not currently registered.

        Parameters
        ----------
        name:
            The canonical pack name to remove.
        """
        if name in self._packs:
            del self._packs[name]
            logger.debug("Pack unregistered (compatibility rollback): '%s'", name)

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, *, name: str) -> PackInfo:
        """Return the :class:`PackInfo` for *name*.

        Parameters
        ----------
        name:
            The canonical pack name to look up.

        Returns
        -------
        PackInfo
            The registered pack record.

        Raises
        ------
        KeyError
            If no pack with *name* has been registered.
        """
        try:
            return self._packs[name]
        except KeyError:
            raise KeyError(
                f"Pack '{name}' is not registered. "
                "Check the pack name or call ensure_loaded() first."
            ) from None

    def has(self, *, name: str) -> bool:
        """Return ``True`` if a pack named *name* is registered.

        Parameters
        ----------
        name:
            The canonical pack name to test.

        Returns
        -------
        bool
            ``True`` if registered, ``False`` otherwise.
        """
        return name in self._packs

    def list(self) -> builtins.list[PackInfo]:
        """Return a list of all registered :class:`PackInfo` records.

        Modifications to the returned list do not affect the registry.

        Returns
        -------
        list[PackInfo]
            A new list of all registered pack records, ordered by insertion.
        """
        return builtins.list(self._packs.values())

    def filter(
        self,
        *,
        vendor: str | None = None,
        device_type: str | None = None,
        protocol: str | None = None,
    ) -> builtins.list[PackInfo]:
        """Return packs matching the given criteria.

        All supplied keyword arguments must match.  Omit an argument (or pass
        ``None``) to leave that axis unconstrained.

        Parameters
        ----------
        vendor:
            Filter by vendor string, e.g. ``"paloalto"``.
        device_type:
            Filter by device class string, e.g. ``"firewall"``.
        protocol:
            Filter by protocol string, e.g. ``"xml"``.

        Returns
        -------
        list[PackInfo]
            All registered packs whose fields match every non-``None``
            constraint, ordered by insertion.
        """
        results: builtins.list[PackInfo] = []
        for info in self._packs.values():
            if vendor is not None and info.vendor != vendor:
                continue
            if device_type is not None and info.device_type != device_type:
                continue
            if protocol is not None and info.protocol != protocol:
                continue
            results.append(info)
        return results

    # ------------------------------------------------------------------
    # Load-error recording
    # ------------------------------------------------------------------

    def record_load_error(self, *, name: str, exc: Exception) -> None:
        """Record that the pack named *name* failed to load with *exc*.

        This is called by the loader (Phase 1) when a pack's entry-point
        ``register()`` raises.  Recording rather than re-raising allows the
        rest of the application to continue operating with the packs that
        did load successfully.

        Parameters
        ----------
        name:
            The canonical pack name (or entry-point name) that failed.
        exc:
            The exception raised during loading.
        """
        self._errors[name] = exc
        logger.warning(
            "Pack '%s' failed to load: %s: %s",
            name,
            type(exc).__name__,
            exc,
        )

    def load_errors(self) -> dict[str, Exception]:
        """Return a copy of the load-error mapping.

        Returns
        -------
        dict[str, Exception]
            Mapping of pack name → exception for every pack that failed to
            load.  Returns an empty dict if no errors occurred.
        """
        return dict(self._errors)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def ensure_loaded(self) -> None:
        """Ensure packs have been discovered and loaded exactly once.

        Iterates every ``netsight.packs`` entry point advertised by installed
        distributions (via :func:`~netsight.packs.loader.load_installed_packs`)
        and calls each one's ``register()`` callable with this registry.
        Subsequent calls are no-ops; the method is therefore safe to call from
        multiple code paths without double-loading.

        Thread Safety
        -------------
        A :class:`threading.Lock` serialises concurrent callers so that the
        loader runs exactly once even when several threads call this method
        simultaneously at startup.
        """
        # Fast path — no lock acquisition if already loaded.
        if self._loaded:
            return

        with self._load_lock:
            # Re-check inside the lock: another thread may have finished
            # loading while we were waiting to acquire it.
            if self._loaded:
                return

            # Local import avoids a module-level circular dependency:
            # loader.py imports PackRegistry (for type annotations only, via
            # TYPE_CHECKING), but registry.py must not import loader.py at
            # module level because the singleton is created during import.
            from netsight.packs.loader import load_installed_packs  # noqa: PLC0415

            load_installed_packs(self)
            self._loaded = True


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

#: Global singleton registry.  Import this in pack registration code and
#: application startup::
#:
#:     from netsight.packs.registry import pack_registry
pack_registry: PackRegistry = PackRegistry()
