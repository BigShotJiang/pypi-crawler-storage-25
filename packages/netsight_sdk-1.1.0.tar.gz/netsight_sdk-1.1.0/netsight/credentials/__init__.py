"""Pluggable credential management for the NetSight SDK.

This package provides a ``CredentialProvider`` protocol and a registry
that discovers installed providers via the
``netsight.credential_providers`` entry-point group — the same pattern
used by ``netsight.packs`` for vendor packs.

Built-in providers:

- ``env`` — reads from environment variables (default, backward-compatible)
- ``dotenv`` — reads from a specific ``.env`` file

Additional providers (KeePass, Ansible Vault, NetsightVault) ship as
optional built-in modules or as third-party entry-point packages.

Usage from DeviceConfig::

    # Legacy (still works unchanged):
    password_env: FW01_PASSWORD

    # New (explicit provider):
    credential:
      provider: vault
      key: fw-01/password
"""

from netsight.credentials.provider import (
    CredentialProvider,
    CredentialProviderInfo,
    RotatableCredentialProvider,
    RotatableProviderMixin,
)
from netsight.credentials.registry import (
    CredentialProviderRegistry,
    credential_provider_registry,
)

CREDENTIAL_PROVIDER_API_VERSION: int = 1

__all__ = [
    "CREDENTIAL_PROVIDER_API_VERSION",
    "CredentialProvider",
    "CredentialProviderInfo",
    "CredentialProviderRegistry",
    "RotatableCredentialProvider",
    "RotatableProviderMixin",
    "credential_provider_registry",
]
