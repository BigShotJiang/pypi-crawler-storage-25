"""Credential audit — inspect all device credentials for availability and staleness.

Typical usage::

    from netsight.credentials.audit import audit_credentials
    report = audit_credentials(config_path="config/devices.yaml", max_age_days=90)
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Sentinel used in audit results when rotation timestamp is not available.
_UNKNOWN_ROTATION = "—"


def audit_credentials(
    *,
    config_path: str | None = None,
    max_age_days: int = 90,
) -> dict[str, Any]:
    """Audit all configured device credentials.

    For each device in ``devices.yaml``:

    1. Identify which credential provider the device uses.
    2. Check whether the credential is accessible (``get_credential`` succeeds).
    3. If the provider implements ``RotatableCredentialProvider``, check
       ``last_rotated`` and flag credentials older than *max_age_days*.

    Parameters
    ----------
    config_path:
        Path to ``devices.yaml``.  When ``None``, the standard search order
        is used via :func:`~netsight.config_mgmt.user_config.resolve_config_file`.
    max_age_days:
        Number of days after which a credential is considered stale.
        Defaults to ``90``.

    Returns
    -------
    dict
        A report dictionary with three top-level keys:

        - ``devices`` — list of per-device audit result dicts, each with
          ``device``, ``provider``, ``key``, ``status``, and
          ``last_rotated`` fields.
        - ``providers`` — list of provider health-check result dicts.
        - ``summary`` — totals: ``total``, ``accessible``, ``missing``,
          ``stale``, ``rotation_supported``.
    """
    resolved_path = _resolve_config_path(config_path)
    if resolved_path is None:
        logger.warning("audit_credentials: no devices.yaml found; returning empty report")
        return _empty_report()

    devices = _load_devices(resolved_path)
    if not devices:
        logger.info("audit_credentials: no devices configured in %s", resolved_path)
        return _empty_report()

    from netsight.credentials.registry import credential_provider_registry
    from netsight.credentials.provider import RotatableCredentialProvider

    credential_provider_registry.ensure_loaded()

    stale_threshold = timedelta(days=max_age_days)
    now = datetime.now(tz=timezone.utc)

    device_results: list[dict[str, Any]] = []
    summary = {
        "total": 0,
        "accessible": 0,
        "missing": 0,
        "stale": 0,
        "rotation_supported": 0,
    }

    for device in devices:
        summary["total"] += 1
        result = _audit_device(
            device=device,
            registry=credential_provider_registry,
            rotatable_protocol=RotatableCredentialProvider,
            now=now,
            stale_threshold=stale_threshold,
        )
        device_results.append(result)

        status = result["status"]
        if status == "ok":
            summary["accessible"] += 1
        elif status == "MISSING":
            summary["missing"] += 1
        elif status == "STALE":
            summary["accessible"] += 1
            summary["stale"] += 1

        if result.get("rotation_supported"):
            summary["rotation_supported"] += 1

    provider_results = _audit_providers(credential_provider_registry)

    return {
        "devices": device_results,
        "providers": provider_results,
        "summary": summary,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_config_path(config_path: str | None) -> Path | None:
    """Return a resolved Path to devices.yaml, or None if not found."""
    if config_path is not None:
        p = Path(config_path)
        return p if p.is_file() else None

    try:
        from netsight.config_mgmt.user_config import resolve_config_file
        result = resolve_config_file("devices.yaml")
        return result
    except Exception as exc:  # noqa: BLE001
        logger.debug("_resolve_config_path: config resolution failed: %s", exc)
        return None


def _load_devices(config_path: Path) -> list[dict[str, Any]]:
    """Parse devices.yaml and return a list of raw device dicts."""
    try:
        import yaml
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.error("audit_credentials: failed to parse %s: %s", config_path, exc)
        return []

    if not isinstance(raw, dict):
        return []

    devices_section = raw.get("devices", raw)
    if isinstance(devices_section, list):
        return [d for d in devices_section if isinstance(d, dict)]
    if isinstance(devices_section, dict):
        # Support map-style: {name: {fields...}} where name is inlined
        results = []
        for name, attrs in devices_section.items():
            if isinstance(attrs, dict):
                entry = dict(attrs)
                entry.setdefault("name", name)
                results.append(entry)
        return results
    return []


def _audit_device(
    *,
    device: dict[str, Any],
    registry: Any,
    rotatable_protocol: Any,
    now: datetime,
    stale_threshold: timedelta,
) -> dict[str, Any]:
    """Produce a single-device audit result dict.

    Parameters
    ----------
    device:
        Raw device dict from devices.yaml.
    registry:
        The live ``CredentialProviderRegistry`` instance.
    rotatable_protocol:
        The ``RotatableCredentialProvider`` Protocol class (passed in to
        avoid re-importing inside the loop).
    now:
        Current UTC datetime used for stale-age calculation.
    stale_threshold:
        Age beyond which a credential is flagged as STALE.

    Returns
    -------
    dict
        Audit result with keys: device, provider, key, status,
        last_rotated, rotation_supported.
    """
    from netsight.credentials.exceptions import (
        CredentialNotFoundError,
        CredentialProviderError,
    )

    device_name = device.get("name", "<unknown>")

    # Determine provider name and key from device config.
    provider_name, cred_key = _extract_credential_info(device)

    result: dict[str, Any] = {
        "device": device_name,
        "provider": provider_name or "—",
        "key": cred_key or "—",
        "status": "ok",
        "last_rotated": _UNKNOWN_ROTATION,
        "rotation_supported": False,
    }

    if not provider_name or not cred_key:
        result["status"] = "MISSING"
        result["detail"] = "No credential source configured"
        return result

    # Retrieve the provider instance from the registry.
    try:
        provider_info = registry.get(name=provider_name)
        provider = provider_info.provider
    except KeyError:
        result["status"] = "MISSING"
        result["detail"] = f"Provider '{provider_name}' is not registered"
        return result

    # Check credential accessibility.
    try:
        provider.get_credential(key=cred_key)
    except CredentialNotFoundError:
        result["status"] = "MISSING"
        return result
    except CredentialProviderError as exc:
        result["status"] = "MISSING"
        result["detail"] = str(exc)
        return result
    except Exception as exc:  # noqa: BLE001
        result["status"] = "MISSING"
        result["detail"] = f"Unexpected error: {exc}"
        return result

    # Check rotation metadata when the provider supports it.
    if isinstance(provider, rotatable_protocol) and provider.supports_rotation():
        result["rotation_supported"] = True
        try:
            last_rotated = provider.last_rotated(key=cred_key)
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "audit: last_rotated(%s) from provider '%s' raised: %s",
                cred_key, provider_name, exc,
            )
            last_rotated = None

        if last_rotated is not None:
            # Normalise to UTC-aware for comparison.
            if last_rotated.tzinfo is None:
                last_rotated = last_rotated.replace(tzinfo=timezone.utc)
            result["last_rotated"] = last_rotated.strftime("%Y-%m-%d")
            age = now - last_rotated
            if age > stale_threshold:
                result["status"] = "STALE"

    return result


def _extract_credential_info(device: dict[str, Any]) -> tuple[str, str]:
    """Return (provider_name, credential_key) for a raw device dict.

    Handles both explicit ``credential:`` sub-dict and legacy
    ``password_env:`` styles.

    Returns
    -------
    tuple[str, str]
        ``(provider_name, credential_key)``.  Either or both may be empty
        strings when neither credential style is configured.
    """
    cred_block = device.get("credential")
    if isinstance(cred_block, dict):
        provider = str(cred_block.get("provider", "")).strip()
        key = str(cred_block.get("key", "")).strip()
        if provider and key:
            return provider, key

    # Fall back to legacy password_env style (implicitly uses env provider).
    password_env = str(device.get("password_env", "")).strip()
    if password_env:
        return "env", password_env

    return "", ""


def _audit_providers(registry: Any) -> list[dict[str, Any]]:
    """Return health-check results for every registered provider."""
    results = []
    for info in registry.list():
        try:
            health = info.provider.health_check()
        except Exception as exc:  # noqa: BLE001
            health = {
                "name": info.name,
                "status": "error",
                "detail": str(exc),
            }
        results.append(health)
    return results


def _empty_report() -> dict[str, Any]:
    """Return an empty audit report with zero-value summary."""
    return {
        "devices": [],
        "providers": [],
        "summary": {
            "total": 0,
            "accessible": 0,
            "missing": 0,
            "stale": 0,
            "rotation_supported": 0,
        },
    }
