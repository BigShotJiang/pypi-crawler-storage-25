"""Exception types for credential providers."""

from __future__ import annotations


class CredentialProviderError(Exception):
    """Raised when a credential provider is unreachable or misconfigured.

    Attributes
    ----------
    provider_name:
        The canonical name of the provider that failed.
    detail:
        Human-readable description of what went wrong.
    """

    def __init__(self, provider_name: str, detail: str) -> None:
        self.provider_name = provider_name
        self.detail = detail
        super().__init__(f"Credential provider '{provider_name}': {detail}")


class CredentialNotFoundError(Exception):
    """Raised when a credential key does not exist in the backend.

    The error message intentionally includes the *key name* but never
    the *credential value* — consistent with the SDK's security
    invariant that secrets never appear in logs or exceptions.

    Attributes
    ----------
    provider_name:
        The provider that was queried.
    key:
        The credential key that was not found.
    """

    def __init__(self, provider_name: str, key: str) -> None:
        self.provider_name = provider_name
        self.key = key
        super().__init__(
            f"Credential key '{key}' not found in provider '{provider_name}'"
        )


class CredentialProviderConflictError(Exception):
    """Raised when two providers register with the same name."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(
            f"Credential provider '{name}' is already registered. "
            "Check for duplicate entry-point declarations."
        )
