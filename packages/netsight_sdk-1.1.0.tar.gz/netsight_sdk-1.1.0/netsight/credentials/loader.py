"""Entry-point discovery for third-party credential providers."""

from __future__ import annotations

import logging
from importlib.metadata import entry_points
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from netsight.credentials.registry import CredentialProviderRegistry

logger = logging.getLogger(__name__)


def load_credential_providers(registry: CredentialProviderRegistry) -> None:
    """Discover and load ``netsight.credential_providers`` entry points.

    Each entry point's callable receives *registry* and is expected to
    call ``registry.register(info=CredentialProviderInfo(...))``.
    Failures are isolated per provider.
    """
    from netsight.credentials import CREDENTIAL_PROVIDER_API_VERSION

    eps = entry_points(group="netsight.credential_providers")
    for ep in eps:
        try:
            register_fn = ep.load()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Credential provider %r failed to import: %s", ep.name, exc)
            registry.record_load_error(name=ep.name, exc=exc)
            continue

        try:
            register_fn(registry)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Credential provider %r register() raised: %s", ep.name, exc)
            registry.record_load_error(name=ep.name, exc=exc)
            continue

        # Post-registration compatibility check.
        if not registry.has(name=ep.name):
            continue

        info = registry.get(name=ep.name)
        if info.declared_api != CREDENTIAL_PROVIDER_API_VERSION:
            registry.unregister(name=ep.name)
            from netsight.credentials.exceptions import CredentialProviderError
            registry.record_load_error(
                name=ep.name,
                exc=CredentialProviderError(
                    provider_name=ep.name,
                    detail=(
                        f"declared_api={info.declared_api} does not match "
                        f"CREDENTIAL_PROVIDER_API_VERSION="
                        f"{CREDENTIAL_PROVIDER_API_VERSION}"
                    ),
                ),
            )
