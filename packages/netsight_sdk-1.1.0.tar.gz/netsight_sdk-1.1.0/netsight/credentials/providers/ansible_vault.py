"""Ansible Vault credential provider — reads from an encrypted YAML file.

This provider uses ``ansible-core`` which is an optional dependency. If it
is not installed, importing this module succeeds but calling
:meth:`AnsibleVaultProvider.get_credential` or decrypting the file raises a
:class:`~netsight.credentials.exceptions.CredentialProviderError` with an
install hint.

Usage in devices.yaml::

    credential:
      provider: ansible-vault
      key: firewalls.fw_01.password

The path to the encrypted YAML file and the env var name holding the vault
password are supplied at instantiation time (typically by the config file
parser, not by auto-registration).

Security invariant: the vault password and all decrypted credential values
are held only in memory for the lifetime of this provider instance. They are
never written to disk, logged, or included in ``__repr__``.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from netsight.credentials.exceptions import (
    CredentialNotFoundError,
    CredentialProviderError,
)

logger = logging.getLogger(__name__)


class AnsibleVaultProvider:
    """Reads credentials from an Ansible Vault encrypted YAML file.

    The credential key is a dotted path into the decrypted YAML structure:
    e.g. ``"firewalls.fw_01.password"`` navigates
    ``{"firewalls": {"fw_01": {"password": "secret"}}}``.

    Parameters
    ----------
    path:
        Filesystem path to the Ansible Vault encrypted file.
    password_env:
        Name of the environment variable holding the vault password.
        Defaults to ``ANSIBLE_VAULT_PASSWORD``.
    """

    _name = "ansible-vault"

    def __init__(
        self,
        *,
        path: str,
        password_env: str = "ANSIBLE_VAULT_PASSWORD",
    ) -> None:
        self._path = Path(path)
        self._password_env = password_env
        self._cache: dict[str, Any] | None = None

    # ------------------------------------------------------------------
    # CredentialProvider protocol
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Provider identifier: ``"ansible-vault"``."""
        return self._name

    def get_credential(self, *, key: str, **context: Any) -> str:
        """Navigate the dotted path in the decrypted YAML and return the value.

        Parameters
        ----------
        key:
            Dotted path into the YAML structure, e.g.
            ``"firewalls.fw_01.password"``.
        **context:
            Ignored — accepted for protocol compatibility.

        Returns
        -------
        str
            The string value at the specified path.

        Raises
        ------
        CredentialNotFoundError
            If any segment of the dotted path is absent, or if the
            resolved value is not a string.
        CredentialProviderError
            If ``ansible-core`` is not installed, the vault file is
            missing, the password env var is unset, or decryption fails.
        """
        data = self._load()
        parts = key.split(".")
        current: Any = data
        for part in parts:
            if not isinstance(current, dict) or part not in current:
                raise CredentialNotFoundError(self.name, key)
            current = current[part]

        if not isinstance(current, str):
            raise CredentialNotFoundError(self.name, key)

        return current

    def health_check(self) -> dict[str, Any]:
        """Return provider status suitable for ``netsight doctor``.

        Returns
        -------
        dict
            Keys: ``name``, ``type``, ``path``,
            ``ansible_installed`` (when library is present), ``status``
            (``"ok"`` or ``"error"``), and optionally ``detail``.
        """
        result: dict[str, Any] = {
            "name": self.name,
            "type": "ansible-vault",
            "path": str(self._path),
        }

        try:
            from ansible.parsing.vault import VaultLib  # noqa: F401
            result["ansible_installed"] = True
        except ImportError:
            result["status"] = "error"
            result["detail"] = (
                "ansible-core not installed. "
                "Install with: pip install ansible-core"
            )
            return result

        if not self._path.is_file():
            result["status"] = "error"
            result["detail"] = f"Vault file not found: {self._path}"
        else:
            result["status"] = "ok"

        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> dict[str, Any]:
        """Decrypt the vault file, parse YAML, and cache the result.

        The decrypted dict is memoised for the lifetime of this instance.

        Raises
        ------
        CredentialProviderError
            If ``ansible-core`` is not installed, the password env var
            is unset, the vault file is missing, or decryption fails.
        """
        if self._cache is not None:
            return self._cache

        try:
            from ansible.parsing.vault import VaultLib, VaultSecret
        except ImportError as exc:
            raise CredentialProviderError(
                provider_name=self.name,
                detail=(
                    "ansible-core is not installed. "
                    "Install with: pip install ansible-core"
                ),
            ) from exc

        password = os.environ.get(self._password_env)
        if not password:
            raise CredentialProviderError(
                provider_name=self.name,
                detail=f"Vault password env var '{self._password_env}' not set",
            )

        if not self._path.is_file():
            raise CredentialProviderError(
                provider_name=self.name,
                detail=f"Vault file not found: {self._path}",
            )

        raw = self._path.read_bytes()
        vault = VaultLib(secrets=[("default", VaultSecret(password.encode()))])

        try:
            decrypted = vault.decrypt(raw)
        except Exception as exc:
            raise CredentialProviderError(
                provider_name=self.name,
                detail=f"Decryption failed: {exc}",
            ) from exc

        import yaml  # stdlib pyyaml — already a project dependency

        self._cache = yaml.safe_load(decrypted)
        return self._cache

    def __repr__(self) -> str:
        return (
            f"AnsibleVaultProvider("
            f"path={str(self._path)!r}, "
            f"password_env={self._password_env!r})"
        )
