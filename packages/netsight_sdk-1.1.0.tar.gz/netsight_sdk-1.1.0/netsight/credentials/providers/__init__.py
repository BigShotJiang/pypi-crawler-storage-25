"""Built-in credential providers for the NetSight SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from netsight.credentials.registry import CredentialProviderRegistry


def register_builtins(registry: CredentialProviderRegistry) -> None:
    """Register the built-in credential providers.

    Called by :meth:`CredentialProviderRegistry.ensure_loaded` before
    entry-point discovery runs. This guarantees the ``env`` provider
    is always available as the default.
    """
    from netsight.credentials.providers.env import register as register_env
    from netsight.credentials.providers.dotenv import register as register_dotenv

    register_env(registry)
    register_dotenv(registry)
