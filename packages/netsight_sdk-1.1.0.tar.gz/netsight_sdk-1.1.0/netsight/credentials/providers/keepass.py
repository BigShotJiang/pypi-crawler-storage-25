"""KeePass credential provider — reads from a .kdbx database file.

This provider uses ``pykeepass`` which is an optional dependency. If it is
not installed, importing this module succeeds but calling
:meth:`KeePassProvider.get_credential` or opening the database raises a
:class:`~netsight.credentials.exceptions.CredentialProviderError` with an
install hint.

Usage in devices.yaml::

    credential:
      provider: keepass
      key: Network/Firewalls/fw-01

The path to the ``.kdbx`` file and the env var name holding the master
password are supplied at instantiation time (typically by the config file
parser, not by auto-registration).

Security invariant: the master password and all credential values are held
only in memory for the lifetime of this provider instance. They are never
written to disk, logged, or included in ``__repr__``.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from netsight.credentials.exceptions import (
    CredentialNotFoundError,
    CredentialProviderError,
)

logger = logging.getLogger(__name__)


class KeePassProvider:
    """Reads credentials from a KeePass .kdbx database.

    The credential key is the entry path in the database using
    forward-slash separators: e.g. ``"Network/Firewalls/fw-01"``
    maps to group ``"Network"`` → group ``"Firewalls"`` → entry
    ``"fw-01"``, and returns the entry's password field.

    Parameters
    ----------
    path:
        Filesystem path to the ``.kdbx`` database file.
    master_env:
        Name of the environment variable holding the master password.
        Defaults to ``KEEPASS_MASTER_PASSWORD``.
    """

    _name = "keepass"

    def __init__(
        self,
        *,
        path: str,
        master_env: str = "KEEPASS_MASTER_PASSWORD",
    ) -> None:
        self._path = Path(path)
        self._master_env = master_env
        self._db: Any = None  # cached pykeepass database instance

    # ------------------------------------------------------------------
    # CredentialProvider protocol
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Provider identifier: ``"keepass"``."""
        return self._name

    def get_credential(self, *, key: str, **context: Any) -> str:
        """Look up an entry by path and return its password field.

        Parameters
        ----------
        key:
            Entry path using forward-slash separators, e.g.
            ``"Group1/Group2/EntryTitle"``. When no slash is present the
            entire key is treated as an entry title and searched across
            the whole database.
        **context:
            Ignored — accepted for protocol compatibility.

        Returns
        -------
        str
            The password field of the matched entry.

        Raises
        ------
        CredentialNotFoundError
            If no matching entry is found, or the entry has no password.
        CredentialProviderError
            If ``pykeepass`` is not installed, the database file is
            missing, the master password env var is unset, or the
            database cannot be opened.
        """
        db = self._load_db()

        parts = key.rsplit("/", 1)
        if len(parts) == 2:
            group_path, title = parts
            # Navigate the group hierarchy depth-first.
            group = db.root_group
            for part in group_path.split("/"):
                found = next(
                    (g for g in group.subgroups if g.name == part), None
                )
                if found is None:
                    raise CredentialNotFoundError(self.name, key)
                group = found
            entry = db.find_entries(title=title, group=group, first=True)
        else:
            # No path separator — search the whole database by title.
            entry = db.find_entries(title=key, first=True)

        if entry is None or entry.password is None:
            raise CredentialNotFoundError(self.name, key)

        return entry.password

    def health_check(self) -> dict[str, Any]:
        """Return provider status suitable for ``netsight doctor``.

        Returns
        -------
        dict
            Keys: ``name``, ``type``, ``path``, ``pykeepass_installed``
            (when library is present), ``status`` (``"ok"`` or
            ``"error"``), and optionally ``detail``.
        """
        result: dict[str, Any] = {
            "name": self.name,
            "type": "keepass",
            "path": str(self._path),
        }

        try:
            from pykeepass import PyKeePass  # noqa: F401
            result["pykeepass_installed"] = True
        except ImportError:
            result["status"] = "error"
            result["detail"] = (
                "pykeepass not installed. Install with: pip install pykeepass"
            )
            return result

        if not self._path.is_file():
            result["status"] = "error"
            result["detail"] = f"Database not found: {self._path}"
        else:
            result["status"] = "ok"

        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_db(self) -> Any:
        """Lazy-load ``pykeepass`` and open the database.

        The opened database is cached for the lifetime of this instance.

        Raises
        ------
        CredentialProviderError
            If ``pykeepass`` is not installed, the master password env
            var is unset, the database file is missing, or the database
            cannot be opened (e.g. wrong password).
        """
        try:
            from pykeepass import PyKeePass
        except ImportError as exc:
            raise CredentialProviderError(
                provider_name=self.name,
                detail=(
                    "pykeepass is not installed. "
                    "Install with: pip install pykeepass"
                ),
            ) from exc

        if self._db is not None:
            return self._db

        master = os.environ.get(self._master_env)
        if not master:
            raise CredentialProviderError(
                provider_name=self.name,
                detail=f"Master password env var '{self._master_env}' not set",
            )

        if not self._path.is_file():
            raise CredentialProviderError(
                provider_name=self.name,
                detail=f"KeePass database not found: {self._path}",
            )

        try:
            self._db = PyKeePass(str(self._path), password=master)
        except Exception as exc:
            raise CredentialProviderError(
                provider_name=self.name,
                detail=f"Failed to open KeePass database: {exc}",
            ) from exc

        return self._db

    def __repr__(self) -> str:
        return (
            f"KeePassProvider("
            f"path={str(self._path)!r}, "
            f"master_env={self._master_env!r})"
        )
