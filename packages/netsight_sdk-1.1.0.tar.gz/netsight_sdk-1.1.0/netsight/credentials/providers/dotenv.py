"""DotEnv credential provider — reads from a specific .env file."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, TYPE_CHECKING

from netsight.credentials.exceptions import (
    CredentialNotFoundError,
    CredentialProviderError,
)
from netsight.credentials.provider import RotatableProviderMixin

if TYPE_CHECKING:
    from netsight.credentials.registry import CredentialProviderRegistry


class DotEnvProvider(RotatableProviderMixin):
    """Credential provider that reads a specific ``.env`` file.

    Unlike the ``env`` provider (which reads ``os.environ`` after
    ``python-dotenv`` has loaded the default ``.env``), this provider
    parses a specific file path on demand. Useful when multiple
    envfiles coexist (e.g. per-environment secrets).
    """

    _name = "dotenv"

    def __init__(self, *, path: str = ".env") -> None:
        self._path = Path(path)
        self._cache: dict[str, str] | None = None

    @property
    def name(self) -> str:
        return self._name

    def _load(self) -> dict[str, str]:
        """Parse the .env file into a dict. Cached after first call."""
        if self._cache is not None:
            return self._cache

        if not self._path.is_file():
            raise CredentialProviderError(
                provider_name=self.name,
                detail=f"File not found: {self._path}",
            )

        entries: dict[str, str] = {}
        for line in self._path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip("'\"")
            entries[key] = value

        self._cache = entries
        return entries

    def get_credential(self, *, key: str, **context: Any) -> str:
        entries = self._load()
        if key not in entries:
            raise CredentialNotFoundError(
                provider_name=self.name,
                key=key,
            )
        return entries[key]

    def health_check(self) -> dict:
        # A missing .env file is NOT an error — it's the normal state
        # for environments that don't use dotenv (CI, containers, etc.).
        # The provider only becomes unhealthy if the file exists but
        # can't be read.
        result: dict[str, Any] = {
            "name": self.name,
            "status": "ok",
            "type": "dotenv",
            "path": str(self._path),
        }
        if not self._path.is_file():
            result["detail"] = "no .env file (optional)"
        elif not os.access(self._path, os.R_OK):
            result["status"] = "error"
            result["detail"] = f"File exists but is not readable: {self._path}"
        return result

    def __repr__(self) -> str:
        return f"DotEnvProvider(path={self._path!r})"


def register(registry: "CredentialProviderRegistry") -> None:
    from netsight.credentials.provider import CredentialProviderInfo

    registry.register(info=CredentialProviderInfo(
        name="dotenv",
        display_name=".env File",
        description="Reads credentials from a specific .env file",
        provider=DotEnvProvider(),
        builtin=True,
    ))
