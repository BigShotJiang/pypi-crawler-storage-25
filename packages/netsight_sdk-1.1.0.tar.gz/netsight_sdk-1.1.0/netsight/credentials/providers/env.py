"""Environment variable credential provider (default).

This is the backward-compatible provider that wraps ``os.environ.get()``.
When a device declares ``password_env: FW01_PASSWORD``, the system
resolves it through this provider automatically.
"""

from __future__ import annotations

import os
from typing import Any, TYPE_CHECKING

from netsight.credentials.exceptions import CredentialNotFoundError
from netsight.credentials.provider import RotatableProviderMixin

if TYPE_CHECKING:
    from netsight.credentials.registry import CredentialProviderRegistry


class EnvVarProvider(RotatableProviderMixin):
    """Credential provider backed by environment variables.

    The simplest backend: ``get_credential(key="X")`` returns
    ``os.environ["X"]``.
    """

    _name = "env"

    @property
    def name(self) -> str:
        return self._name

    def get_credential(self, *, key: str, **context: Any) -> str:
        value = os.environ.get(key)
        if value is None:
            raise CredentialNotFoundError(
                provider_name=self.name,
                key=key,
            )
        return value

    def health_check(self) -> dict:
        return {"name": self.name, "status": "ok", "type": "env"}

    def __repr__(self) -> str:
        return "EnvVarProvider()"


def register(registry: "CredentialProviderRegistry") -> None:
    from netsight.credentials.provider import CredentialProviderInfo

    registry.register(info=CredentialProviderInfo(
        name="env",
        display_name="Environment Variables",
        description="Reads credentials from os.environ (default, backward-compatible)",
        provider=EnvVarProvider(),
        builtin=True,
    ))
