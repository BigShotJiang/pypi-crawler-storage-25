"""CredentialProviderRegistry — singleton registry for credential backends."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from netsight.credentials.exceptions import CredentialProviderConflictError

if TYPE_CHECKING:
    from netsight.credentials.provider import CredentialProviderInfo

logger = logging.getLogger(__name__)


class CredentialProviderRegistry:
    """Central registry of installed credential providers.

    Mirrors the shape of ``PackRegistry`` and ``ServiceRegistry``:
    register, get, list, ensure_loaded, record_load_error.

    Built-in providers (env, dotenv) are registered by
    :func:`netsight.credentials.providers.register_builtins` which
    is called inside :meth:`ensure_loaded` before entry-point
    discovery runs.
    """

    def __init__(self) -> None:
        self._providers: dict[str, "CredentialProviderInfo"] = {}
        self._errors: dict[str, Exception] = {}
        self._loaded: bool = False

    def register(self, *, info: "CredentialProviderInfo") -> None:
        """Register a credential provider."""
        if info.name in self._providers:
            raise CredentialProviderConflictError(info.name)
        self._providers[info.name] = info
        logger.info("Credential provider registered: '%s'", info.name)

    def unregister(self, *, name: str) -> None:
        """Remove a provider. Silently does nothing if not registered."""
        self._providers.pop(name, None)

    def get(self, *, name: str) -> "CredentialProviderInfo":
        """Return the provider info for *name*."""
        try:
            return self._providers[name]
        except KeyError:
            raise KeyError(
                f"Credential provider '{name}' is not registered. "
                "Check provider name or call ensure_loaded() first."
            ) from None

    def has(self, *, name: str) -> bool:
        return name in self._providers

    def list(self) -> list["CredentialProviderInfo"]:
        return list(self._providers.values())

    def record_load_error(self, *, name: str, exc: Exception) -> None:
        self._errors[name] = exc
        logger.warning(
            "Credential provider '%s' failed to load: %s: %s",
            name, type(exc).__name__, exc,
        )

    def load_errors(self) -> dict[str, Exception]:
        return dict(self._errors)

    def ensure_loaded(self) -> None:
        """Register built-in providers, then discover entry-point providers."""
        if self._loaded:
            return

        # Register built-in providers first.
        from netsight.credentials.providers import register_builtins
        register_builtins(self)

        # Then discover third-party providers via entry points.
        from netsight.credentials.loader import load_credential_providers
        load_credential_providers(self)

        self._loaded = True


credential_provider_registry: CredentialProviderRegistry = CredentialProviderRegistry()
