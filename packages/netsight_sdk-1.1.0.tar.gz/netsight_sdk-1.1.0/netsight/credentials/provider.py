"""CredentialProvider protocol and CredentialProviderInfo dataclass."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol, runtime_checkable

from netsight.credentials.exceptions import CredentialProviderError

logger = logging.getLogger(__name__)


@runtime_checkable
class CredentialProvider(Protocol):
    """Contract for credential backends.

    Implementations retrieve secrets from a specific source:
    environment variables, encrypted files, KeePass databases,
    Ansible Vault, HashiCorp Vault, AWS Secrets Manager, etc.

    Security invariant: implementations MUST NOT log, cache to disk,
    or include credential *values* in ``__repr__``, exceptions, or
    any other observable output. Key *names* are safe to include.
    """

    @property
    def name(self) -> str:
        """Provider identifier used in config files (e.g. ``"env"``)."""
        ...

    def get_credential(self, *, key: str, **context: Any) -> str:
        """Return the secret value for *key*.

        Parameters
        ----------
        key:
            Lookup key. Meaning depends on the backend:
            - env: environment variable name
            - keepass: entry path (e.g. ``"netsight/fw-01/password"``)
            - vault: secret path within the vault file
        context:
            Provider-specific hints (``host``, ``username``, etc.).

        Raises
        ------
        CredentialNotFoundError
            If the key does not exist.
        CredentialProviderError
            If the backend is unreachable or misconfigured.
        """
        ...

    def health_check(self) -> dict:
        """Return provider status for ``netsight doctor``.

        Expected keys: ``{"name": str, "status": "ok"|"error", ...}``.
        """
        ...


@runtime_checkable
class RotatableCredentialProvider(CredentialProvider, Protocol):
    """Extended protocol for providers that support credential rotation.

    Providers that can store new credential values (e.g. KeePass, Vault)
    should implement this protocol.  The base ``CredentialProvider``
    protocol is intentionally unchanged so existing providers remain valid
    without modification.

    Use ``isinstance(provider, RotatableCredentialProvider)`` at runtime
    to detect rotation support; this check is safe because the protocol is
    decorated with ``@runtime_checkable``.
    """

    def supports_rotation(self) -> bool:
        """Return ``True`` if this provider can rotate credentials."""
        ...

    def rotate(self, *, key: str, new_value: str, **context: Any) -> None:
        """Store a new value for *key*, recording rotation metadata.

        Parameters
        ----------
        key:
            The credential key to rotate.
        new_value:
            The replacement secret value. Must not be logged or persisted
            anywhere other than the credential backend.
        context:
            Provider-specific hints (e.g. ``group``, ``username``).

        Raises
        ------
        CredentialProviderError
            If rotation is not supported or the backend is unreachable.
        """
        ...

    def last_rotated(self, *, key: str) -> datetime | None:
        """Return when *key* was last rotated, or ``None`` if unknown.

        Parameters
        ----------
        key:
            The credential key to query.

        Returns
        -------
        datetime | None
            Timezone-aware or naive datetime of the last rotation, or
            ``None`` when the backend does not track rotation timestamps.
        """
        ...


class RotatableProviderMixin:
    """Mixin that provides default no-op rotation methods.

    Providers that do not support rotation can mix this in to satisfy
    the ``RotatableCredentialProvider`` protocol without implementing
    the methods.  The default implementations return safe sentinel values
    (``False`` / ``None``) or raise :exc:`CredentialProviderError` with a
    clear message so callers are never silently misled.

    Example::

        class EnvVarProvider(RotatableProviderMixin, ...):
            ...
    """

    def supports_rotation(self) -> bool:
        """Return ``False`` — this provider does not support rotation."""
        return False

    def rotate(self, *, key: str, new_value: str, **context: Any) -> None:
        """Raise :exc:`CredentialProviderError` — rotation is not supported.

        Parameters
        ----------
        key:
            The credential key that was requested for rotation.
        new_value:
            Ignored — the call always raises.
        context:
            Ignored — the call always raises.

        Raises
        ------
        CredentialProviderError
            Always, with a descriptive message.
        """
        raise CredentialProviderError(
            provider_name=getattr(self, "name", "unknown"),
            detail="This provider does not support credential rotation",
        )

    def last_rotated(self, *, key: str) -> datetime | None:
        """Return ``None`` — this provider does not track rotation timestamps.

        Parameters
        ----------
        key:
            The credential key to query (ignored).

        Returns
        -------
        datetime | None
            Always ``None``.
        """
        return None


@dataclass(frozen=True)
class CredentialProviderInfo:
    """Metadata record for a registered credential provider.

    Attributes
    ----------
    name:
        Canonical provider name (e.g. ``"env"``, ``"keepass"``).
    display_name:
        Human-friendly name for CLI output.
    description:
        One-line summary.
    provider:
        The live ``CredentialProvider`` instance.
    builtin:
        ``True`` for providers that ship with the SDK.
    config:
        Provider-specific configuration from ``devices.yaml``.
    declared_api:
        Must match ``CREDENTIAL_PROVIDER_API_VERSION`` at load time.
    """

    name: str
    display_name: str
    description: str
    provider: CredentialProvider
    builtin: bool = True
    config: dict[str, Any] = field(default_factory=dict)
    declared_api: int = 1
