"""NetSight configuration loader.

Parses a YAML devices file and exposes typed :class:`DeviceConfig` instances.
Passwords are never stored in the config file; they are resolved at runtime
through a :class:`~netsight.credentials.provider.CredentialProvider`.

Two credential styles are supported:

- **Legacy** — ``password_env: VAR_NAME`` resolves through the built-in
  ``env`` provider (backward-compatible, unchanged behaviour).
- **Explicit** — a ``credential:`` sub-dict with ``provider`` and ``key``
  fields routes through any registered provider (``env``, ``dotenv``,
  ``vault``, etc.).

Typical usage::

    from netsight.config import ConfigLoader

    loader = ConfigLoader("config/devices.yaml")
    device = loader.get_device("fw-01")
    password = device.get_password()
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

# Load .env file from project root if it exists. Must happen BEFORE
# importing any netsight module that reads env vars at import time.
load_dotenv()

from netsight.exceptions import ConfigValidationError  # noqa: E402

logger = logging.getLogger(__name__)

# Required fields that every device entry must supply.
# ``password_env`` is kept here for backward compatibility — the validation
# logic relaxes this requirement when a ``credential:`` sub-dict is present.
_REQUIRED_FIELDS: frozenset[str] = frozenset(
    {"name", "api_type", "host", "username"}
)

# Fields that satisfy the credential requirement — at least one must be set.
_CREDENTIAL_FIELDS: frozenset[str] = frozenset({"password_env", "credential"})


@dataclass(frozen=True)
class DeviceConfig:
    """Immutable configuration record for a single managed device.

    Attributes
    ----------
    name:
        Logical name used to look up the device (e.g. ``"fw-01"``).
    api_type:
        Plugin identifier string (e.g. ``"paloalto-firewall-xml"``, ``"ios_xe"``).
    host:
        Hostname or IP address of the device.
    username:
        Login username for the device API.
    password_env:
        Name of the environment variable that holds the password.
        Legacy credential style — still fully supported.  When
        ``credential_provider`` and ``credential_key`` are also set,
        the explicit ``credential`` block takes priority.
    credential_provider:
        Registered credential provider name (e.g. ``"env"``, ``"vault"``).
        Set alongside ``credential_key`` to use the explicit credential style.
    credential_key:
        Lookup key within the named provider (e.g. an env-var name, a vault
        path such as ``"fw-01/password"``, or a KeePass entry path).
    verify_ssl:
        Whether TLS certificates should be verified. Defaults to ``True``.
    timeout_connect:
        TCP connection timeout in seconds. Defaults to ``10``.
    timeout_read:
        HTTP read timeout in seconds. Defaults to ``30``.
    rate_limit:
        Maximum API requests per second. Defaults to ``5``.
    allowed_operations:
        Optional list of operation names permitted for this specific device.
        When set, the effective allowlist is the intersection of this list
        with the global per-pack user allowlist (narrowing only — never
        widens). ``None`` means inherit the full global allowlist.
    """

    name: str
    api_type: str
    host: str
    username: str
    password_env: str = ""
    credential_provider: str = ""
    credential_key: str = ""
    verify_ssl: bool = True
    timeout_connect: int = 10
    timeout_read: int = 30
    rate_limit: int = 5
    vendor: str = ""
    model: str = ""
    allowed_operations: list[str] | None = None

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeviceConfig":
        """Create a :class:`DeviceConfig` from a raw dictionary.

        Parameters
        ----------
        data:
            Mapping that must contain all keys in ``_REQUIRED_FIELDS`` plus
            at least one of ``password_env`` (legacy) or a ``credential``
            sub-dict with ``provider`` and ``key`` entries.

        Raises
        ------
        ConfigValidationError
            If any required field is absent from *data*, or if neither a
            credential source is provided.

        Notes
        -----
        When both ``credential`` and ``password_env`` are present,
        ``credential`` takes priority at runtime (inside
        :meth:`get_password`).  Both values are stored so that callers
        can inspect which credential style was configured.
        """
        missing = _REQUIRED_FIELDS - data.keys()
        if missing:
            # Report the first missing field deterministically.
            first_missing = sorted(missing)[0]
            raise ConfigValidationError(
                field=first_missing,
                detail=(
                    f"Required field(s) missing from device config: "
                    f"{', '.join(sorted(missing))}"
                ),
            )

        # Parse the optional explicit ``credential:`` sub-dict.
        credential_provider = ""
        credential_key = ""
        raw_cred = data.get("credential")
        if raw_cred is not None:
            if not isinstance(raw_cred, dict):
                raise ConfigValidationError(
                    field="credential",
                    detail=(
                        f"'credential' must be a mapping with 'provider' and 'key', "
                        f"got {type(raw_cred).__name__!r}"
                    ),
                )
            credential_provider = str(raw_cred.get("provider", "")).strip()
            credential_key = str(raw_cred.get("key", "")).strip()
            if not credential_provider or not credential_key:
                raise ConfigValidationError(
                    field="credential",
                    detail=(
                        "'credential' mapping must contain non-empty "
                        "'provider' and 'key' fields"
                    ),
                )

        # Validate that at least one credential source is present.
        password_env = str(data.get("password_env", "")).strip()
        if not password_env and not (credential_provider and credential_key):
            raise ConfigValidationError(
                field="credential",
                detail=(
                    f"Device '{data.get('name', '?')}' has no credential configured. "
                    "Set either 'credential:' (provider + key) or "
                    "'password_env:' in devices.yaml."
                ),
            )

        # ``model`` supersedes the old ``device_type`` key.  Accept both
        # spellings so existing devices.yaml files keep working.
        model_value = data.get("model") or data.get("device_type", "")

        # Parse optional per-device allowed_operations narrowing list.
        raw_allowed = data.get("allowed_operations")
        allowed_ops: list[str] | None = None
        if raw_allowed is not None:
            if isinstance(raw_allowed, list):
                allowed_ops = [str(op) for op in raw_allowed]
            else:
                raise ConfigValidationError(
                    field="allowed_operations",
                    detail=(
                        f"'allowed_operations' must be a list, got "
                        f"{type(raw_allowed).__name__!r}"
                    ),
                )

        return cls(
            name=data["name"],
            api_type=data["api_type"],
            host=data["host"],
            username=data["username"],
            password_env=password_env,
            credential_provider=credential_provider,
            credential_key=credential_key,
            verify_ssl=bool(data.get("verify_ssl", True)),
            timeout_connect=int(data.get("timeout_connect", 10)),
            timeout_read=int(data.get("timeout_read", 30)),
            rate_limit=int(data.get("rate_limit", 5)),
            vendor=data.get("vendor", ""),
            model=model_value,
            allowed_operations=allowed_ops,
        )

    # ------------------------------------------------------------------
    # Runtime helpers
    # ------------------------------------------------------------------

    def get_password(self) -> str:
        """Return the device password by resolving it through the configured provider.

        Resolution order:

        1. If both ``credential_provider`` and ``credential_key`` are set,
           the named provider is used.  This is the explicit credential style
           and takes priority over ``password_env`` when both are present.
        2. If ``password_env`` is set, it is resolved through the built-in
           ``env`` provider (backward-compatible behaviour).
        3. Otherwise, raise :class:`~netsight.exceptions.ConfigValidationError`.

        The credential registry is loaded lazily on first call to avoid
        circular imports at module load time.

        Raises
        ------
        ConfigValidationError
            If no credential source is configured, or if the credential
            provider raises an exception that is not itself a
            :class:`~netsight.credentials.exceptions.CredentialNotFoundError`
            or :class:`~netsight.credentials.exceptions.CredentialProviderError`
            (those propagate unchanged so callers can handle them).
        """
        from netsight.credentials.registry import credential_provider_registry

        credential_provider_registry.ensure_loaded()

        if self.credential_provider and self.credential_key:
            info = credential_provider_registry.get(name=self.credential_provider)
            return info.provider.get_credential(
                key=self.credential_key,
                host=self.host,
                username=self.username,
            )

        if self.password_env:
            info = credential_provider_registry.get(name="env")
            return info.provider.get_credential(key=self.password_env)

        raise ConfigValidationError(
            field="credential",
            detail=(
                f"Device '{self.name}' has no credential configured. "
                f"Set either 'credential:' (provider + key) or "
                f"'password_env:' in devices.yaml."
            ),
        )


class ConfigLoader:
    """Loads and validates a YAML devices configuration file.

    Parameters
    ----------
    config_path:
        Path to the YAML file (``Path`` or ``str``).  The file is parsed and
        validated eagerly during ``__init__``; any problem raises
        :class:`~netsight.exceptions.ConfigValidationError` immediately.

    Raises
    ------
    ConfigValidationError
        If the file does not exist, is empty, lacks the ``devices`` key, or
        contains an invalid device entry.
    """

    def __init__(self, config_path: Path | str) -> None:
        self._config_path = Path(config_path)
        self._devices: list[DeviceConfig] = []
        self.config_dir: str = ""
        self._load()

    # ------------------------------------------------------------------
    # Internal loading
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Parse the YAML file and populate ``self._devices``.

        Raises
        ------
        ConfigValidationError
            On any structural or semantic problem.
        """
        if not self._config_path.exists():
            raise ConfigValidationError(
                field=str(self._config_path),
                detail=f"Config file not found: {self._config_path}",
            )

        logger.debug("Loading config from %s", self._config_path)

        raw_text = self._config_path.read_text(encoding="utf-8")
        try:
            data = yaml.safe_load(raw_text)
        except yaml.YAMLError as exc:
            raise ConfigValidationError(
                field=str(self._config_path),
                detail=f"YAML parse error: {exc}",
            ) from exc

        if data is None:
            raise ConfigValidationError(
                field=str(self._config_path),
                detail="Config file is empty.",
            )

        self.config_dir = data.get("config_dir", "")

        if "devices" not in data:
            raise ConfigValidationError(
                field="devices",
                detail=(
                    f"Required top-level key 'devices' is missing from "
                    f"{self._config_path}."
                ),
            )

        raw_devices = data["devices"]
        if not isinstance(raw_devices, list):
            raise ConfigValidationError(
                field="devices",
                detail=(
                    f"'devices' must be a list, got "
                    f"{type(raw_devices).__name__!r} in {self._config_path}."
                ),
            )

        devices: list[DeviceConfig] = []
        for idx, entry in enumerate(raw_devices):
            if not isinstance(entry, dict):
                raise ConfigValidationError(
                    field=f"devices[{idx}]",
                    detail=f"Device entry at index {idx} must be a mapping, got {type(entry).__name__!r}.",
                )
            # DeviceConfig.from_dict raises ConfigValidationError on bad entries.
            devices.append(DeviceConfig.from_dict(entry))

        self._devices = devices
        logger.info(
            "Loaded %d device(s) from %s",
            len(self._devices),
            self._config_path,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_devices(self) -> list[DeviceConfig]:
        """Return a copy of the loaded device list.

        Returns
        -------
        list[DeviceConfig]
            Shallow copy; modifying the returned list does not affect the
            internal state of the loader.
        """
        return list(self._devices)

    def get_device(self, name: str) -> DeviceConfig:
        """Return the :class:`DeviceConfig` whose ``name`` matches *name*.

        Parameters
        ----------
        name:
            Exact logical name of the device.

        Raises
        ------
        ConfigValidationError
            If no device with that name exists in the config.
        """
        for device in self._devices:
            if device.name == name:
                return device

        raise ConfigValidationError(
            field="name",
            detail=(
                f"Device '{name}' not found in {self._config_path}. "
                f"Available: {[d.name for d in self._devices]}"
            ),
        )
