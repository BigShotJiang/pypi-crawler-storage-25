"""Plugin registry for NetSight — compatibility shim over PackRegistry.

Provides :class:`PluginRegistry` — a thin wrapper over
:data:`~netsight.packs.registry.pack_registry` — and the module-level
singleton :data:`plugin_registry` that the rest of the application imports
to register and look up plugins.

.. deprecated::
    All symbols in this module (``PluginInfo``, ``PluginRegistry``,
    ``plugin_registry``) are deprecated.  New code should import
    :class:`~netsight.packs.registry.PackInfo`,
    :class:`~netsight.packs.registry.PackRegistry`, and
    :data:`~netsight.packs.registry.pack_registry` from
    :mod:`netsight.packs.registry`.  The shim will be removed in the
    release after this one (Phase 6).

Usage example (legacy — kept for backwards-compatibility only)::

    from netsight.registry import plugin_registry

    @plugin_registry.register_decorator(
        "panos_xml",
        allowed_operations={"show_routes", "show_arp"},
        parser_class=PanosXmlParser,
    )
    class PanosXmlClient:
        ...
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from netsight.exceptions import PluginNotFoundError
from netsight.packs.exceptions import PackConflictError, PackNotInstalledError
from netsight.packs.registry import PackInfo, pack_registry

logger = logging.getLogger(__name__)


@dataclass
class PluginInfo:
    """Metadata record for a single registered plugin.

    .. deprecated::
        Use :class:`~netsight.packs.registry.PackInfo` instead.
        This class is retained for one release as a compatibility shim and
        will be removed in Phase 6.

    Attributes
    ----------
    name:
        Unique plugin identifier (matches the key in the registry).
    client_class:
        The class used to connect to and query a device.
    allowed_operations:
        Set of operation strings this plugin permits.
    parser_class:
        Optional class responsible for parsing device responses.  There is
        no equivalent field in :class:`PackInfo`; this is always ``None``
        for packs round-tripped through the shim.
    validator_class:
        Optional class responsible for validating operation commands.
    metadata:
        Arbitrary key/value data supplied by the plugin author.
    """

    name: str
    client_class: type
    allowed_operations: set[str]
    parser_class: type | None = None
    validator_class: type | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_pack_info(
        cls,
        pack: PackInfo,
        *,
        legacy_name: str | None = None,
    ) -> PluginInfo:
        """Construct a :class:`PluginInfo` from a :class:`PackInfo`.

        Parameters
        ----------
        pack:
            The source :class:`~netsight.packs.registry.PackInfo` record.
        legacy_name:
            When provided, this string is used as the ``name`` field of the
            returned :class:`PluginInfo` instead of ``pack.name``.  This
            allows the shim to present ``"panos_xml"`` rather than the
            synthesised pack name ``"legacy-panos_xml-shim"`` to callers
            that compare ``plugin_info.name == "panos_xml"``.

        Returns
        -------
        PluginInfo
            A new :class:`PluginInfo` whose fields are populated from *pack*.
            ``parser_class`` is always ``None`` (no pack equivalent).
        """
        return cls(
            name=legacy_name if legacy_name is not None else pack.name,
            client_class=pack.client_class,
            allowed_operations=set(pack.allowed_operations),
            parser_class=None,
            validator_class=pack.validator_class,
            metadata=dict(pack.metadata),
        )


class PluginRegistry:
    """Compatibility shim: delegates to :data:`~netsight.packs.registry.pack_registry`.

    .. deprecated::
        This class will be removed in Phase 6.  New code should use
        :class:`~netsight.packs.registry.PackRegistry` directly.

    Each method in this class translates the legacy ``PluginInfo``-based API
    to the :class:`~netsight.packs.registry.PackInfo`-based ``pack_registry``
    API.  The module-level singleton :data:`plugin_registry` is the canonical
    entry point for legacy code.

    The shim maintains an internal ``_legacy_name_to_pack`` map so that names
    registered via the legacy :meth:`register` API (e.g. ``"panos_xml"``) can
    be resolved even though the underlying pack was stored under a synthesised
    triplet name (e.g. ``"legacy-panos_xml-shim"``).
    """

    def __init__(self) -> None:
        """Initialise the shim with an empty legacy-name mapping."""
        # Maps legacy plugin name → synthesised pack name in pack_registry.
        # e.g. "panos_xml" → "legacy-panos_xml-shim"
        self._legacy_name_to_pack: dict[str, str] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(
        self,
        name: str,
        client_class: type,
        allowed_operations: set[str],
        parser_class: type | None = None,
        validator_class: type | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Register a plugin under *name* via the legacy API.

        .. deprecated::
            Use :meth:`~netsight.packs.registry.PackRegistry.register` with a
            :class:`~netsight.packs.registry.PackInfo` instead.

        A :exc:`DeprecationWarning` is emitted on every call.  The plugin is
        stored in the underlying :data:`~netsight.packs.registry.pack_registry`
        under the synthesised pack name ``"legacy-{name}-shim"``, and the
        original *name* is recorded in ``_legacy_name_to_pack`` so that
        subsequent :meth:`get` / :meth:`has` calls resolve correctly.

        Duplicate registrations are silently ignored (idempotent).  This
        matches the behaviour expected by call sites such as
        ``netsight.plugins.panos_xml.register()`` which may fire more than
        once across test isolation boundaries when the underlying
        :data:`~netsight.packs.registry.pack_registry` singleton is reused.

        Parameters
        ----------
        name:
            Unique identifier for this plugin, e.g. ``"panos_xml"``.
        client_class:
            Client class that handles device communication.
        allowed_operations:
            Set of permitted operation strings.
        parser_class:
            Optional parser class.  Accepted for API compatibility but has no
            :class:`~netsight.packs.registry.PackInfo` equivalent; the value
            is discarded.
        validator_class:
            Optional validator class for operation commands.
        metadata:
            Optional free-form metadata dict.  Defaults to ``{}``.
        """
        warnings.warn(
            "plugin_registry.register is deprecated; migrate to "
            "pack_registry.register with a PackInfo",
            DeprecationWarning,
            stacklevel=2,
        )

        pack_name = f"legacy-{name}-shim"

        # If already registered (e.g. called again after a test fixture
        # resets the plugin_registry shim but NOT the underlying pack_registry),
        # just refresh the legacy-name mapping and return.
        if pack_registry.has(name=pack_name):
            self._legacy_name_to_pack[name] = pack_name
            return

        info = PackInfo(
            name=pack_name,
            vendor="legacy",
            device_type=name,
            protocol="shim",
            distribution=f"netsight-pack-{pack_name}",
            version="0.0.0-legacy-shim",
            client_class=client_class,
            allowed_operations=frozenset(allowed_operations),
            config_root=Path("."),
            validator_class=validator_class,
            metadata=metadata if metadata is not None else {},
        )

        try:
            pack_registry.register(info=info)
        except PackConflictError:
            # Another path (e.g. a concurrent call or a second import) already
            # registered this pack name; treat as idempotent.
            pass  # noqa: BLE001

        self._legacy_name_to_pack[name] = pack_name
        logger.info(
            "Plugin registered via legacy shim: '%s' → pack '%s'",
            name,
            pack_name,
        )

    def register_decorator(
        self,
        name: str,
        allowed_operations: set[str],
        parser_class: type | None = None,
        validator_class: type | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        """Return a class decorator that registers the decorated class as a plugin.

        .. deprecated::
            Use :meth:`~netsight.packs.registry.PackRegistry.register` with a
            :class:`~netsight.packs.registry.PackInfo` instead.

        The decorator calls :meth:`register` (which emits a
        :exc:`DeprecationWarning`) and returns the class unchanged.

        Parameters
        ----------
        name:
            Unique plugin identifier.
        allowed_operations:
            Set of permitted operation strings.
        parser_class:
            Optional parser class for device responses.
        validator_class:
            Optional validator class for operation commands.
        metadata:
            Optional free-form metadata dict.

        Returns
        -------
        Callable[[type], type]
            A decorator that accepts a class and registers it under *name*.

        Example::

            @registry.register_decorator("my_vendor", allowed_operations={"show_routes"})
            class MyVendorClient:
                ...
        """

        def decorator(cls: type) -> type:
            self.register(
                name=name,
                client_class=cls,
                allowed_operations=allowed_operations,
                parser_class=parser_class,
                validator_class=validator_class,
                metadata=metadata,
            )
            return cls

        return decorator

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, name: str) -> PluginInfo:
        """Return the :class:`PluginInfo` for *name*.

        Resolves *name* through the legacy-name map (for plugins registered
        via :meth:`register`) before delegating to
        :data:`~netsight.packs.registry.pack_registry`.

        Parameters
        ----------
        name:
            The plugin identifier to look up (legacy name, e.g. ``"panos_xml"``).

        Returns
        -------
        PluginInfo
            The :class:`PluginInfo` associated with *name*, with ``name``
            set to the original legacy identifier rather than the synthesised
            pack name.

        Raises
        ------
        PluginNotFoundError
            If no plugin with *name* has been registered.
        """
        pack_name = self._legacy_name_to_pack.get(name, name)
        try:
            pack = pack_registry.get(name=pack_name)
        except (KeyError, PackNotInstalledError) as exc:
            raise PluginNotFoundError(name) from exc

        # Use the original legacy name so callers see "panos_xml", not
        # "legacy-panos_xml-shim".
        legacy_name = self._reverse_lookup(pack.name) or name
        return PluginInfo.from_pack_info(pack, legacy_name=legacy_name)

    def has(self, name: str) -> bool:
        """Return whether *name* has been registered.

        This method never raises; it returns a plain boolean.

        Parameters
        ----------
        name:
            The plugin identifier to test (legacy name).

        Returns
        -------
        bool
            ``True`` if the plugin is registered, ``False`` otherwise.
        """
        pack_name = self._legacy_name_to_pack.get(name, name)
        return pack_registry.has(name=pack_name)

    def list(self) -> list[PluginInfo]:
        """Return a list of all registered :class:`PluginInfo` records.

        Iterates every pack in
        :data:`~netsight.packs.registry.pack_registry` and converts each
        :class:`~netsight.packs.registry.PackInfo` to a :class:`PluginInfo`.
        For packs that were registered via the legacy :meth:`register` API, the
        original legacy name is restored; for natively-registered packs the
        full triplet name is used.

        Modifications to the returned list do not affect the registry.

        Returns
        -------
        list[PluginInfo]
            A new list of all registered :class:`PluginInfo` objects.
        """
        return [
            PluginInfo.from_pack_info(
                pack,
                legacy_name=self._reverse_lookup(pack.name),
            )
            for pack in pack_registry.list()
        ]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _reverse_lookup(self, pack_name: str) -> str | None:
        """Return the legacy plugin name for a synthesised *pack_name*, or ``None``.

        Parameters
        ----------
        pack_name:
            A pack name as stored in ``pack_registry``, e.g.
            ``"legacy-panos_xml-shim"``.

        Returns
        -------
        str | None
            The original legacy plugin name (e.g. ``"panos_xml"``) if one
            was recorded, otherwise ``None``.
        """
        for legacy, pname in self._legacy_name_to_pack.items():
            if pname == pack_name:
                return legacy
        return None


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

#: Global singleton registry (compatibility shim).  Import this in legacy
#: plugins and application code::
#:
#:     from netsight.registry import plugin_registry
#:
#: .. deprecated::
#:     Use :data:`netsight.packs.registry.pack_registry` for new code.
plugin_registry: PluginRegistry = PluginRegistry()
