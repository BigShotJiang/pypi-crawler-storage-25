"""NetSight custom exception hierarchy.

All exceptions inherit from :class:`NetSightError` so callers can catch the
entire family with a single ``except NetSightError`` clause, or target
individual sub-types for fine-grained handling.

Security note
-------------
:class:`AuthenticationError` deliberately omits credentials from its message.
The ``detail`` attribute should contain only a terse reason string — never a
raw password or API key.
"""

from __future__ import annotations


class NetSightError(Exception):
    """Base exception for all NetSight errors."""


class CommandDeniedError(NetSightError):
    """Raised when a requested operation is blocked by the allow-list gate.

    Attributes
    ----------
    operation:
        The command or operation string that was denied.
    reason:
        Human-readable reason for the denial.
    """

    def __init__(self, operation: str, reason: str = "not in allowlist") -> None:
        self.operation = operation
        self.reason = reason
        super().__init__(f"Operation denied: '{operation}' \u2014 {reason}")


class AuthenticationError(NetSightError):
    """Raised when authentication against a device fails.

    Credentials are *never* included in the exception message to prevent
    accidental exposure in logs or tracebacks.

    Attributes
    ----------
    host:
        Hostname or IP address of the device that rejected the credentials.
    detail:
        Terse, credential-free description of why authentication failed.
    """

    def __init__(self, host: str, detail: str = "authentication failed") -> None:
        self.host = host
        self.detail = detail
        super().__init__(f"Authentication failed for {host}: {detail}")


class DeviceConnectionError(NetSightError):
    """Raised when a device is unreachable.

    Attributes
    ----------
    host:
        Hostname or IP address that could not be reached.
    detail:
        Terse description of the failure (e.g. "timed out after 30s").
    """

    def __init__(self, host: str, detail: str = "connection failed") -> None:
        self.host = host
        self.detail = detail
        super().__init__(f"Cannot connect to {host}: {detail}")


class PluginNotFoundError(NetSightError):
    """Raised when no plugin is registered for a requested ``api_type``.

    Attributes
    ----------
    plugin_name:
        The ``api_type`` string (or plugin identifier) that was not found.
    """

    def __init__(self, plugin_name: str) -> None:
        self.plugin_name = plugin_name
        super().__init__(
            f"Plugin not found: '{plugin_name}'. "
            "Check the api_type in your config or install the plugin."
        )


class ConfigValidationError(NetSightError):
    """Raised when device or application configuration fails validation.

    Attributes
    ----------
    field:
        The configuration key or field path that failed validation.
    detail:
        Human-readable description of the validation failure.
    """

    def __init__(self, field: str, detail: str) -> None:
        self.field = field
        self.detail = detail
        super().__init__(f"Config validation error on '{field}': {detail}")


class RateLimitError(NetSightError):
    """Raised when a device's request rate limit is exceeded.

    Attributes
    ----------
    device_name:
        Logical name of the device whose rate limit was hit.
    max_rps:
        Configured maximum requests per second for this device.
    """

    def __init__(self, device_name: str, max_rps: int) -> None:
        self.device_name = device_name
        self.max_rps = max_rps
        super().__init__(
            f"Rate limit exceeded for '{device_name}': max {max_rps} requests/sec"
        )


class ResponseSizeError(NetSightError):
    """Raised when a device response exceeds the configured size limit.

    Attributes
    ----------
    actual_bytes:
        Size of the response that was received (or detected), in bytes.
    max_bytes:
        Configured upper limit in bytes.
    """

    def __init__(self, actual_bytes: int, max_bytes: int) -> None:
        self.actual_bytes = actual_bytes
        self.max_bytes = max_bytes
        super().__init__(
            f"Response size {actual_bytes:,} bytes exceeds limit of {max_bytes:,} bytes"
        )


# ---------------------------------------------------------------------------
# Pack exceptions — defined in netsight.packs.exceptions, re-exported here
# as the canonical import location per the exception_handling recipe.
# ---------------------------------------------------------------------------

from netsight.packs.exceptions import (  # noqa: E402
    PackConflictError,
    PackNotInstalledError,
    PackRegistrationError,
)

__all__ = [
    "AuthenticationError",
    "CommandDeniedError",
    "ConfigValidationError",
    "DeviceConnectionError",
    "NetSightError",
    "PackConflictError",
    "PackNotInstalledError",
    "PackRegistrationError",
    "PluginNotFoundError",
    "RateLimitError",
    "ResponseSizeError",
]
