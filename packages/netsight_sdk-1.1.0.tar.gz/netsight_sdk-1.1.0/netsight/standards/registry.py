"""Standards registry — loads YAML definitions and runs validation."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

_DEFINITIONS_DIR = Path(__file__).resolve().parent / "definitions"


@dataclass(frozen=True)
class Finding:
    """A single finding from a standards check."""

    file: str
    line: int | None
    message: str
    severity: str = "error"


@dataclass(frozen=True)
class StandardInfo:
    """Loaded standard definition."""

    name: str
    category: str
    severity: str
    description: str
    introduced: str
    scope: dict[str, Any]
    rule: dict[str, Any]
    positive_examples: list[str] = field(default_factory=list)
    negative_examples: list[str] = field(default_factory=list)
    related: list[dict[str, str]] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class CheckResult:
    """Result of validating code against a single standard."""

    standard: str
    passed: bool
    findings: list[Finding] = field(default_factory=list)
    skipped: bool = False
    skip_reason: str = ""


class StandardsRegistry:
    """Loads standards from YAML and validates code against them."""

    def __init__(self, *, definitions_dir: Path | None = None) -> None:
        self._dir = definitions_dir or _DEFINITIONS_DIR
        self._standards: dict[str, StandardInfo] = {}
        self._loaded = False

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        self._loaded = True
        if not self._dir.is_dir():
            logger.warning("Standards definitions directory not found: %s", self._dir)
            return
        for path in sorted(self._dir.glob("*.yaml")):
            if path.name.startswith("_"):
                continue
            try:
                raw = yaml.safe_load(path.read_text(encoding="utf-8"))
                if not isinstance(raw, dict) or "name" not in raw:
                    continue
                info = StandardInfo(
                    name=raw["name"],
                    category=raw.get("category", "general"),
                    severity=raw.get("severity", "warning"),
                    description=raw.get("description", ""),
                    introduced=raw.get("introduced", ""),
                    scope=raw.get("scope", {}),
                    rule=raw.get("rule", {}),
                    positive_examples=raw.get("positive_examples", []),
                    negative_examples=raw.get("negative_examples", []),
                    related=raw.get("related", []),
                    raw=raw,
                )
                self._standards[info.name] = info
            except Exception as exc:
                logger.warning("Failed to load standard %s: %s", path.name, exc)

    def list_standards(self) -> list[StandardInfo]:
        self._ensure_loaded()
        return sorted(self._standards.values(), key=lambda s: (s.category, s.name))

    def get_standard(self, *, name: str) -> StandardInfo:
        self._ensure_loaded()
        try:
            return self._standards[name]
        except KeyError:
            raise KeyError(f"Standard '{name}' not found") from None

    def has(self, *, name: str) -> bool:
        self._ensure_loaded()
        return name in self._standards

    def list_categories(self) -> list[str]:
        self._ensure_loaded()
        return sorted({s.category for s in self._standards.values()})

    def check_standard(
        self, *, name: str, path: str | None = None
    ) -> CheckResult:
        """Validate code against a single standard."""
        self._ensure_loaded()
        info = self.get_standard(name=name)
        return self._run_check(info=info, path=path)

    def check_all(self, *, path: str | None = None) -> list[CheckResult]:
        """Validate code against all standards."""
        self._ensure_loaded()
        results = []
        for info in self.list_standards():
            results.append(self._run_check(info=info, path=path))
        return results

    def check_category(
        self, *, category: str, path: str | None = None
    ) -> list[CheckResult]:
        """Validate code against all standards in a category."""
        self._ensure_loaded()
        results = []
        for info in self.list_standards():
            if info.category == category:
                results.append(self._run_check(info=info, path=path))
        return results

    def _run_check(
        self, *, info: StandardInfo, path: str | None
    ) -> CheckResult:
        """Dispatch to the appropriate validation engine."""
        engine_name = info.rule.get("engine", "")
        if not engine_name:
            return CheckResult(
                standard=info.name,
                passed=True,
                skipped=True,
                skip_reason="No validation engine specified",
            )

        try:
            engine = _get_engine(engine_name)
            findings = engine.check(
                rule=info.rule,
                scope=info.scope,
                path=path,
                severity=info.severity,
            )
            return CheckResult(
                standard=info.name,
                passed=len(findings) == 0,
                findings=findings,
            )
        except Exception as exc:
            logger.warning("Engine '%s' failed for standard '%s': %s", engine_name, info.name, exc)
            return CheckResult(
                standard=info.name,
                passed=True,
                skipped=True,
                skip_reason=f"Engine error: {exc}",
            )


def _get_engine(name: str):
    """Lazy-load a validation engine by name."""
    if name == "ast":
        from netsight.standards.engines.ast_engine import ASTEngine
        return ASTEngine()
    elif name == "grep":
        from netsight.standards.engines.grep_engine import GrepEngine
        return GrepEngine()
    elif name == "custom":
        from netsight.standards.engines.custom_engine import CustomEngine
        return CustomEngine()
    else:
        raise ValueError(f"Unknown validation engine: {name!r}")


standards_registry: StandardsRegistry = StandardsRegistry()
