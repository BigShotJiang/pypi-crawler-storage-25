"""Code development standards framework for the NetSight SDK.

Each standard is a YAML file under ``definitions/`` that is BOTH
human-readable documentation AND machine-checkable rules. The human
reads the ``description``; the machine reads the ``rule``.

Public API::

    from netsight.standards import standards_registry

    # List all standards
    for s in standards_registry.list_standards():
        print(f"{s.name}: {s.severity}")

    # Validate code against all standards
    results = standards_registry.check_all()
    for r in results:
        print(f"{r.standard}: {'PASS' if r.passed else 'FAIL'}")
"""

from netsight.standards.registry import (
    StandardInfo,
    CheckResult,
    Finding,
    StandardsRegistry,
    standards_registry,
)

__all__ = [
    "StandardInfo",
    "CheckResult",
    "Finding",
    "StandardsRegistry",
    "standards_registry",
]
