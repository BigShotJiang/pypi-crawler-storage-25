"""Custom validation engine for complex checks that don't fit AST or grep."""

from __future__ import annotations

import logging
from typing import Any

from netsight.standards.registry import Finding

logger = logging.getLogger(__name__)


class CustomEngine:
    """Dispatches to named custom check functions."""

    def check(
        self, *, rule: dict, scope: dict, path: str | None, severity: str
    ) -> list[Finding]:
        check_name = rule.get("check", "")
        checker = _CUSTOM_CHECKS.get(check_name)
        if checker is None:
            logger.warning("Unknown custom check: %s", check_name)
            return []
        return checker(rule=rule, scope=scope, path=path, severity=severity)


def _check_catalog_test_coverage(
    *, rule: dict, scope: dict, path: str | None, severity: str
) -> list[Finding]:
    """Verify every pack operation has a dedicated test file."""
    findings: list[Finding] = []

    try:
        from netsight.packs import pack_registry
        pack_registry.ensure_loaded()
    except Exception:
        return findings

    import tomllib

    for pack in pack_registry.list():
        try:
            catalog_node = pack.config_root / "operations_catalog.toml"
            if not catalog_node.is_file():
                continue
            with catalog_node.open("rb") as fh:
                catalog = tomllib.load(fh)

            # Find the tests directory
            config_root_path = str(pack.config_root)
            if "_data" in config_root_path:
                pack_dir = str(pack.config_root).replace("/_data", "").replace("\\_data", "")
                from pathlib import Path
                tests_dir = Path(pack_dir).parent / "tests"
            else:
                continue

            if not tests_dir.is_dir():
                findings.append(Finding(
                    file=str(tests_dir),
                    line=None,
                    message=f"Pack '{pack.name}' has no tests/ directory",
                    severity=severity,
                ))
                continue

            for op_name in catalog:
                test_file = tests_dir / f"test_{op_name}.py"
                if not test_file.is_file():
                    findings.append(Finding(
                        file=str(test_file),
                        line=None,
                        message=f"Operation '{op_name}' has no test file",
                        severity=severity,
                    ))
        except Exception as exc:
            logger.debug("catalog-test-coverage check failed for %s: %s", pack.name, exc)

    return findings


_CUSTOM_CHECKS = {
    "catalog-test-coverage": _check_catalog_test_coverage,
}
