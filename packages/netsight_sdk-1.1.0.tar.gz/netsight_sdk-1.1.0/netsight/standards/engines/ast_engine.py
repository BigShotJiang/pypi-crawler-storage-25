"""AST-based validation engine for structural code checks."""

from __future__ import annotations

import ast
import inspect
import logging
from pathlib import Path
from typing import Any

from netsight.standards.registry import Finding

logger = logging.getLogger(__name__)


class ASTEngine:
    """Validates code structure via Python AST analysis."""

    def check(
        self, *, rule: dict, scope: dict, path: str | None, severity: str
    ) -> list[Finding]:
        check_type = rule.get("check", "")
        if check_type == "parameter-kind-after-self":
            return self._check_parameter_kind(rule=rule, scope=scope, severity=severity)
        elif check_type == "except-block-has-action":
            return self._check_except_blocks(rule=rule, scope=scope, path=path, severity=severity)
        elif check_type == "module-has-pattern":
            return self._check_module_pattern(rule=rule, scope=scope, path=path, severity=severity)
        elif check_type == "frozen-info-dataclasses":
            return self._check_frozen_info_dataclasses(rule=rule, scope=scope, path=path, severity=severity)
        else:
            logger.warning("Unknown AST check type: %s", check_type)
            return []

    def _check_parameter_kind(
        self, *, rule: dict, scope: dict, severity: str
    ) -> list[Finding]:
        """Check that public methods use keyword-only parameters."""
        findings: list[Finding] = []
        classes = scope.get("classes", [])
        exclude_methods = set(scope.get("exclude", []))

        for class_path in classes:
            try:
                parts = class_path.rsplit(".", 1)
                mod = __import__(parts[0], fromlist=[parts[1]])
                cls = getattr(mod, parts[1])
            except (ImportError, AttributeError) as exc:
                findings.append(Finding(
                    file=class_path,
                    line=None,
                    message=f"Cannot import class: {exc}",
                    severity=severity,
                ))
                continue

            for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
                if name.startswith("_") and name not in ("__init__",):
                    continue
                if name in exclude_methods:
                    continue
                if name not in cls.__dict__:
                    continue

                sig = inspect.signature(method)
                for pname, param in sig.parameters.items():
                    if pname == "self":
                        continue
                    if param.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD:
                        findings.append(Finding(
                            file=class_path,
                            line=None,
                            message=f"{cls.__name__}.{name}({pname}): POSITIONAL_OR_KEYWORD — must be KEYWORD_ONLY",
                            severity=severity,
                        ))
                        break

        return findings

    def _check_except_blocks(
        self, *, rule: dict, scope: dict, path: str | None, severity: str
    ) -> list[Finding]:
        """Check that except blocks have logging, re-raise, or recording."""
        findings: list[Finding] = []
        actions = set(rule.get("actions", []))

        search_paths = scope.get("paths", ["netsight/**/*.py"])
        exclude_paths = set(scope.get("exclude_paths", []))

        from netsight.mcp_dev.path_security import PROJECT_ROOT

        for pattern in search_paths:
            for py_file in PROJECT_ROOT.glob(pattern):
                rel = str(py_file.relative_to(PROJECT_ROOT))
                if any(rel.startswith(ep.rstrip("*").rstrip("/")) for ep in exclude_paths):
                    continue

                try:
                    tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))
                except SyntaxError:
                    continue

                for node in ast.walk(tree):
                    if not isinstance(node, ast.ExceptHandler):
                        continue

                    has_action = False
                    for child in ast.walk(node):
                        if isinstance(child, ast.Raise):
                            has_action = True
                            break
                        if isinstance(child, ast.Call):
                            func = child.func
                            if isinstance(func, ast.Attribute):
                                if func.attr in actions or func.attr in (
                                    "debug", "info", "warning", "error", "critical",
                                ):
                                    has_action = True
                                    break

                    if not has_action:
                        findings.append(Finding(
                            file=rel,
                            line=node.lineno,
                            message="except block has no logging, raise, or recording action",
                            severity=severity,
                        ))

        return findings

    def _check_module_pattern(
        self, *, rule: dict, scope: dict, path: str | None, severity: str
    ) -> list[Finding]:
        """Check that modules contain a required pattern (e.g. module-level logger)."""
        findings: list[Finding] = []
        pattern = rule.get("pattern", "")
        message = rule.get("message", f"Missing pattern: {pattern}")

        search_paths = scope.get("paths", [])
        exclude_paths = set(scope.get("exclude_paths", []))

        from netsight.mcp_dev.path_security import PROJECT_ROOT

        for glob_pattern in search_paths:
            for py_file in PROJECT_ROOT.glob(glob_pattern):
                rel = str(py_file.relative_to(PROJECT_ROOT))
                if any(rel.startswith(ep.rstrip("*").rstrip("/")) for ep in exclude_paths):
                    continue
                content = py_file.read_text(encoding="utf-8")
                if pattern not in content:
                    findings.append(Finding(
                        file=rel,
                        line=None,
                        message=message,
                        severity=severity,
                    ))

        return findings

    def _check_frozen_info_dataclasses(
        self, *, rule: dict, scope: dict, path: str | None, severity: str
    ) -> list[Finding]:
        """Check that dataclasses whose names end in 'Info' are frozen=True.

        Any class decorated with ``@dataclass`` (with or without arguments)
        whose name ends in the configured ``pattern`` (default ``"Info"``)
        must have ``frozen=True`` in the decorator call.
        """
        findings: list[Finding] = []
        name_suffix = rule.get("pattern", "Info")

        search_paths = scope.get("paths", ["netsight/**/*.py"])
        exclude_paths = set(scope.get("exclude_paths", []))

        from netsight.mcp_dev.path_security import PROJECT_ROOT

        for glob_pattern in search_paths:
            for py_file in PROJECT_ROOT.glob(glob_pattern):
                rel = str(py_file.relative_to(PROJECT_ROOT))
                if any(rel.startswith(ep.rstrip("*").rstrip("/")) for ep in exclude_paths):
                    continue

                try:
                    source = py_file.read_text(encoding="utf-8")
                    tree = ast.parse(source, filename=str(py_file))
                except SyntaxError:
                    continue

                for node in ast.walk(tree):
                    if not isinstance(node, ast.ClassDef):
                        continue
                    if not node.name.endswith(name_suffix):
                        continue

                    # Check if the class has a @dataclass decorator
                    for decorator in node.decorator_list:
                        is_dataclass_deco = False
                        frozen_true = False

                        if isinstance(decorator, ast.Name) and decorator.id == "dataclass":
                            # bare @dataclass — no frozen argument → defaults to False
                            is_dataclass_deco = True
                            frozen_true = False

                        elif isinstance(decorator, ast.Call):
                            func = decorator.func
                            if (isinstance(func, ast.Name) and func.id == "dataclass") or (
                                isinstance(func, ast.Attribute) and func.attr == "dataclass"
                            ):
                                is_dataclass_deco = True
                                # Look for frozen=True keyword argument
                                for kw in decorator.keywords:
                                    if kw.arg == "frozen":
                                        if isinstance(kw.value, ast.Constant):
                                            frozen_true = bool(kw.value.value)
                                        break

                        if is_dataclass_deco and not frozen_true:
                            findings.append(Finding(
                                file=rel,
                                line=node.lineno,
                                message=(
                                    f"Dataclass '{node.name}' ends in '{name_suffix}' "
                                    f"but is not declared with frozen=True"
                                ),
                                severity=severity,
                            ))
                            break  # Only report once per class

        return findings
