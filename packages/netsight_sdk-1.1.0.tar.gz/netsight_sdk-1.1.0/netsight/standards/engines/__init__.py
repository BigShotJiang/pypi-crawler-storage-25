"""Validation engines for the standards framework."""
