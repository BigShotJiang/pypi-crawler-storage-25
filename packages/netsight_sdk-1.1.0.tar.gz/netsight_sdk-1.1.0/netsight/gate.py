"""Deny-all-by-default command safety gate for NetSight."""

import logging
from collections.abc import Set as AbstractSet

from netsight.exceptions import CommandDeniedError

logger = logging.getLogger(__name__)


class CommandGate:
    """Deny-all-by-default safety layer for NetSight operations.

    Every operation is denied unless it is explicitly present in the
    allowlist supplied at construction time.  There is no deny list and no
    pattern matching — only exact, case-sensitive membership tests.

    Attributes:
        _allowed: Immutable frozenset of permitted operation strings.
    """

    def __init__(self, allowed_operations: AbstractSet[str]) -> None:
        """Initialise the gate with an explicit set of permitted operations.

        Args:
            allowed_operations: Any set (or frozenset) of operation strings
                that the gate should permit.  An empty set creates a gate
                that denies every operation.
        """
        self._allowed: frozenset[str] = frozenset(allowed_operations)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(self, operation: str) -> None:
        """Assert that *operation* is in the allowlist.

        Logs at DEBUG on success and at WARNING on denial before raising.

        Args:
            operation: The operation string to check.

        Raises:
            CommandDeniedError: If *operation* is not in the allowlist.
        """
        if operation in self._allowed:
            logger.debug("Gate ALLOWED operation: %r", operation)
            return

        logger.warning("Gate DENIED operation: %r", operation)
        raise CommandDeniedError(operation)

    def is_allowed(self, operation: str) -> bool:
        """Return whether *operation* is in the allowlist.

        Unlike :meth:`validate`, this method never raises; it returns a
        plain boolean and produces no log output.

        Args:
            operation: The operation string to check.

        Returns:
            ``True`` if the operation is explicitly allowed, ``False``
            otherwise.
        """
        return operation in self._allowed

    def get_allowed_operations(self) -> set[str]:
        """Return a mutable copy of the current allowlist.

        Modifications to the returned set do **not** affect this gate.

        Returns:
            A new :class:`set` containing all permitted operation strings.
        """
        return set(self._allowed)
