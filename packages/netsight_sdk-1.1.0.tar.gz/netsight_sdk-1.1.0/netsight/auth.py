"""Authentication strategy and token-caching manager for NetSight.

Design
------
``AuthStrategy`` is an ABC that vendor-specific adapters implement — they
handle the actual network call to obtain or revoke a session token.

``AuthManager`` owns a per-host token cache and enforces TTL-based expiry.
It deliberately never exposes raw token values in ``repr`` or log output.

Usage example::

    class MyStrategy(AuthStrategy):
        def acquire_token(self, host, username, password):
            ...  # POST /login, return token string
        def revoke_token(self, host, token):
            ...  # POST /logout

    manager = AuthManager(MyStrategy(), token_ttl_seconds=1800)
    token = manager.get_token("192.168.1.1", "admin", "hunter2")
    manager.close()
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Abstract strategy
# ---------------------------------------------------------------------------


class AuthStrategy(ABC):
    """Contract that every authentication back-end must satisfy."""

    @abstractmethod
    def acquire_token(self, host: str, username: str, password: str) -> str:
        """Obtain a new session token from *host*.

        Parameters
        ----------
        host:
            Hostname or IP address of the target device.
        username:
            Account name to authenticate with.
        password:
            Credential.  Implementations must not log this value.

        Returns
        -------
        str
            An opaque token string suitable for subsequent API calls.

        Raises
        ------
        netsight.exceptions.AuthenticationError
            If the device rejects the credentials.
        Any network/transport exception the caller may choose to handle.
        """

    @abstractmethod
    def revoke_token(self, host: str, token: str) -> None:
        """Invalidate *token* on *host*.

        Implementations should be best-effort; ``AuthManager`` handles
        failures by logging a warning rather than propagating exceptions.

        Parameters
        ----------
        host:
            Same host that issued the token.
        token:
            The token to invalidate.
        """


# ---------------------------------------------------------------------------
# Internal cached-token container
# ---------------------------------------------------------------------------


class _CachedToken:
    """Lightweight container for a token and its acquisition timestamp.

    Uses ``__slots__`` to minimise per-instance memory overhead — there may
    be hundreds of these alive at once in a large environment.
    """

    __slots__ = ("token", "acquired_at")

    def __init__(self, token: str) -> None:
        self.token: str = token
        self.acquired_at: float = time.monotonic()

    def is_expired(self, ttl: float) -> bool:
        """Return ``True`` if the token is older than *ttl* seconds."""
        return (time.monotonic() - self.acquired_at) >= ttl


# ---------------------------------------------------------------------------
# AuthManager
# ---------------------------------------------------------------------------


class AuthManager:
    """Caching authentication manager.

    Maintains one valid token per host; transparently reacquires when the
    TTL expires or after an explicit ``invalidate`` call.

    Parameters
    ----------
    strategy:
        The ``AuthStrategy`` instance used to acquire/revoke tokens.
    token_ttl_seconds:
        How long (in seconds) a cached token is considered valid before a
        new one is acquired.  Defaults to 3600 (one hour).
    """

    def __init__(
        self, strategy: AuthStrategy, token_ttl_seconds: float = 3600
    ) -> None:
        self._strategy = strategy
        self._token_ttl: float = token_ttl_seconds
        # Maps host -> _CachedToken
        self._cache: dict[str, _CachedToken] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_token(self, host: str, username: str, password: str) -> str:
        """Return a valid token for *host*, acquiring one if necessary.

        The token is taken from the in-memory cache when it exists and has
        not exceeded the TTL.  Otherwise a new token is acquired from the
        strategy.

        Parameters
        ----------
        host:
            Target device hostname or IP.
        username:
            Credential — passed through to the strategy unchanged.
        password:
            Credential — never logged.

        Returns
        -------
        str
            A non-empty token string.
        """
        cached = self._cache.get(host)
        if cached is not None and not cached.is_expired(self._token_ttl):
            logger.debug("Using cached token for host=%s", host)
            return cached.token

        logger.info("Acquiring new token for host=%s", host)
        token = self._strategy.acquire_token(host, username, password)
        self._cache[host] = _CachedToken(token)
        return token

    def invalidate(self, host: str) -> None:
        """Remove the cached token for *host* and attempt to revoke it.

        If the strategy raises during revocation the exception is caught
        and a ``WARNING`` is emitted; the cache entry is removed regardless.

        Parameters
        ----------
        host:
            The host whose token should be invalidated.
        """
        cached = self._cache.pop(host, None)
        if cached is None:
            return

        try:
            self._strategy.revoke_token(host, cached.token)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Failed to revoke token for host=%s: %s", host, exc
            )

    def has_token(self, host: str) -> bool:
        """Return ``True`` if a non-expired token is cached for *host*.

        Parameters
        ----------
        host:
            The host to query.
        """
        cached = self._cache.get(host)
        if cached is None:
            return False
        return not cached.is_expired(self._token_ttl)

    def close(self) -> None:
        """Revoke all cached tokens and clear the cache.

        Revocation failures are logged at ``WARNING`` and do not prevent the
        remaining tokens from being processed.
        """
        # Snapshot keys so we can safely mutate the dict during iteration
        hosts = list(self._cache.keys())
        for host in hosts:
            self.invalidate(host)

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return a safe representation that never includes token values."""
        hosts = list(self._cache.keys())
        strategy_name = type(self._strategy).__name__
        return (
            f"AuthManager(strategy={strategy_name}, "
            f"hosts={hosts!r}, "
            f"ttl={self._token_ttl}s)"
        )
