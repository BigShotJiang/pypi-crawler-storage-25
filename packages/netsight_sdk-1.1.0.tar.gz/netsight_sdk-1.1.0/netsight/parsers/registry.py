"""Generic pluggable registry for the NetSight parser engine.

Usage
-----
Direct registration::

    registry.register("my_parser", MyParserClass)

Decorator registration::

    @registry.register("my_parser")
    class MyParserClass:
        ...

Retrieval::

    cls = registry.get("my_parser")   # raises KeyError if not found
    exists = registry.has("my_parser")
    names = registry.list_names()     # sorted list of registered names
"""

from __future__ import annotations

from typing import Any, Callable, Union


# Sentinel used to distinguish "no item supplied" from a legitimate None value.
_MISSING: Any = object()


class Registry:
    """A named registry that maps string keys to arbitrary items.

    Supports both direct ``register(name, item)`` and decorator
    ``@register(name)`` forms.  Duplicate registrations raise
    :class:`ValueError`; missing lookups raise :class:`KeyError`.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self._store: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(
        self, name: str, item: Any = _MISSING
    ) -> Union[None, Callable[[Any], Any]]:
        """Register *item* under *name*, or return a decorator when *item* is omitted.

        Parameters
        ----------
        name:
            The key to register under.
        item:
            The object to store.  When omitted the method returns a decorator
            that registers whatever callable/class is decorated.

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if item is _MISSING:
            # Decorator form: @registry.register("name")
            def decorator(obj: Any) -> Any:
                self._store_item(name, obj)
                return obj

            return decorator

        # Direct form: registry.register("name", item)
        self._store_item(name, item)
        return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _store_item(self, name: str, item: Any) -> None:
        if name in self._store:
            raise ValueError(
                f"'{name}' is already registered in the '{self.name}' registry"
            )
        self._store[name] = item

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get(self, name: str) -> Any:
        """Return the item registered under *name*.

        Raises
        ------
        KeyError
            If *name* has not been registered.
        """
        try:
            return self._store[name]
        except KeyError:
            raise KeyError(
                f"'{name}' is not registered in the '{self.name}' registry"
            ) from None

    def has(self, name: str) -> bool:
        """Return ``True`` if *name* is registered."""
        return name in self._store

    def list_names(self) -> list[str]:
        """Return a sorted list of all registered names."""
        return sorted(self._store)


# ---------------------------------------------------------------------------
# Module-level singletons
# ---------------------------------------------------------------------------

#: Registry for parser engine implementations.
parser_registry: Registry = Registry("engine")

#: Registry for field type coercion functions.
type_registry: Registry = Registry("type")

#: Registry for field transform functions.
transform_registry: Registry = Registry("transform")

#: Registry for expression/helper functions.
function_registry: Registry = Registry("function")
