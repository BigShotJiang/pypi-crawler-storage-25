"""Base classes for the NetSight config parser engine.

This module defines the data structures and abstract interfaces used by all
config parsers in NetSight.

Design
------
``ConfigNode`` is a tree node that also supports cross-tree reference links,
enabling parsers to model constructs like zone references, interface groups, and
policy rule targets as first-class graph edges.

``ConfigTree`` wraps a root ``ConfigNode`` and provides path-based access,
recursive search, and full enumeration.

``BaseConfigParser`` is the abstract contract every concrete parser must satisfy.

Usage example::

    from netsight.parsers.base import ConfigNode, ConfigTree, BaseConfigParser

    root = ConfigNode(name="root", value=None, node_type="root")
    child = ConfigNode(name="interface", value="eth0", node_type="interface")
    root.add_child(child)

    tree = ConfigTree(root)
    node = tree.get("root.interface")
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ConfigNode:
    """A single node in a configuration parse tree.

    Nodes form a parent-child hierarchy (the tree dimension) and may also carry
    reference links to other nodes (the graph dimension).

    Parameters
    ----------
    name:
        The identifier for this node within its parent (e.g. ``"interface"``,
        ``"address-object"``).
    value:
        The parsed value at this position in the configuration.  May be any
        Python object including ``None``, ``str``, ``int``, ``dict``, etc.
    node_type:
        A parser-defined type label such as ``"zone"``, ``"policy-rule"``,
        ``"address-group"``.
    source_file:
        Path of the source configuration file this node originated from.
    line_number:
        1-based line number in *source_file* where this node begins.
    children:
        Ordered list of child nodes.  Mutate via :meth:`add_child`.
    parent:
        The parent node, or ``None`` if this node is the root.
    references:
        Nodes that this node explicitly references (outbound edges).
    referenced_by:
        Nodes that hold a reference back to this node (inbound edges).
    """

    name: str
    value: Any
    node_type: str
    source_file: str = ""
    line_number: int = 0
    children: list[ConfigNode] = field(default_factory=list, repr=False)
    parent: ConfigNode | None = field(default=None, repr=False)
    references: list[ConfigNode] = field(default_factory=list, repr=False)
    referenced_by: list[ConfigNode] = field(default_factory=list, repr=False)

    def add_child(self, child: ConfigNode) -> None:
        """Attach *child* under this node and set its parent pointer.

        Parameters
        ----------
        child:
            The node to attach.  Its ``parent`` attribute is updated to ``self``.
        """
        child.parent = self
        self.children.append(child)

    def add_reference(self, target: ConfigNode) -> None:
        """Create a directed reference edge from this node to *target*.

        The relationship is recorded in both directions to support impact
        analysis:

        * ``self.references`` gains *target* (if not already present).
        * ``target.referenced_by`` gains ``self`` (if not already present).

        Parameters
        ----------
        target:
            The node being referenced by ``self``.
        """
        if target not in self.references:
            self.references.append(target)
        if self not in target.referenced_by:
            target.referenced_by.append(self)

    @property
    def path(self) -> str:
        """Dot-separated path from the root node down to this node.

        The path is built by walking the parent chain from ``self`` up to the
        root, then reversing and joining with ``"."``.

        Returns
        -------
        str
            For example ``"root.devices.firewall-01.interfaces"``.
        """
        parts: list[str] = []
        current: ConfigNode | None = self
        while current is not None:
            parts.append(current.name)
            current = current.parent
        parts.reverse()
        return ".".join(parts)


class ConfigTree:
    """A thin wrapper around a root ``ConfigNode`` with query helpers.

    Parameters
    ----------
    root:
        The root node of the tree.
    """

    def __init__(self, root: ConfigNode) -> None:
        self.root = root

    def get(self, path: str) -> ConfigNode | None:
        """Return the node at *path*, or ``None`` if not found.

        The path is split on ``"."`` and each segment is matched against the
        children of the previous node, starting from the root.

        Parameters
        ----------
        path:
            Dot-separated path string.  The first segment must match the root
            node's name.

        Returns
        -------
        ConfigNode | None
            The node at the resolved path, or ``None`` if any segment is
            missing.
        """
        if not path:
            return None

        segments = path.split(".")
        current: ConfigNode | None = self.root

        for segment in segments:
            if current is None:
                return None
            if current.name == segment:
                # Matched this level — move on to the next segment
                continue
            # Look for the segment among children
            found: ConfigNode | None = None
            for child in current.children:
                if child.name == segment:
                    found = child
                    break
            current = found

        return current

    def search(
        self,
        name: str | None = None,
        node_type: str | None = None,
    ) -> list[ConfigNode]:
        """Recursively find all nodes matching the given criteria.

        Both *name* and *node_type* are optional.  When both are supplied a
        node must match on both criteria.  When neither is supplied every node
        is returned.

        Parameters
        ----------
        name:
            Filter by ``ConfigNode.name`` (exact match).
        node_type:
            Filter by ``ConfigNode.node_type`` (exact match).

        Returns
        -------
        list[ConfigNode]
            All matching nodes in depth-first order.
        """
        results: list[ConfigNode] = []
        self._walk_search(self.root, name, node_type, results)
        return results

    def _walk_search(
        self,
        node: ConfigNode,
        name: str | None,
        node_type: str | None,
        results: list[ConfigNode],
    ) -> None:
        """Recursive helper for :meth:`search`."""
        name_match = (name is None) or (node.name == name)
        type_match = (node_type is None) or (node.node_type == node_type)
        if name_match and type_match:
            results.append(node)
        for child in node.children:
            self._walk_search(child, name, node_type, results)

    def children(self, path: str) -> list[ConfigNode]:
        """Return the direct children of the node at *path*.

        Parameters
        ----------
        path:
            Dot-separated path to the target node.

        Returns
        -------
        list[ConfigNode]
            The direct children, or an empty list if the node does not exist.
        """
        node = self.get(path)
        if node is None:
            return []
        return list(node.children)

    def all_nodes(self) -> list[ConfigNode]:
        """Return every node in the tree in depth-first order.

        Returns
        -------
        list[ConfigNode]
            All nodes including the root.
        """
        results: list[ConfigNode] = []
        self._walk_all(self.root, results)
        return results

    def _walk_all(self, node: ConfigNode, results: list[ConfigNode]) -> None:
        """Recursive helper for :meth:`all_nodes`."""
        results.append(node)
        for child in node.children:
            self._walk_all(child, results)


class BaseConfigParser(ABC):
    """Abstract contract for all NetSight configuration parsers.

    Concrete parsers must implement :meth:`parse` (convert raw text to a
    ``ConfigTree``) and :meth:`resolve` (wire cross-node references).
    """

    @abstractmethod
    def parse(self, raw_input: str) -> ConfigTree:
        """Parse *raw_input* into a ``ConfigTree``.

        Parameters
        ----------
        raw_input:
            The raw configuration text (e.g. vendor CLI output or a config
            file body).

        Returns
        -------
        ConfigTree
            A tree representation of the parsed configuration.
        """

    @abstractmethod
    def resolve(self, tree: ConfigTree) -> ConfigTree:
        """Wire up cross-node references within *tree*.

        Called after :meth:`parse`; implementations should use
        :meth:`ConfigNode.add_reference` to record dependency edges between
        nodes.

        Parameters
        ----------
        tree:
            The tree returned by :meth:`parse`.

        Returns
        -------
        ConfigTree
            The same *tree* with references populated.
        """
