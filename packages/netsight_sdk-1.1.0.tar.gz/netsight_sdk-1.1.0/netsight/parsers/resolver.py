"""Dependency resolver for NetSight config trees.

This module provides ``DependencyResolver``, which walks a ``ConfigTree`` and
wires up symbolic name references stored on nodes into live ``ConfigNode``
reference edges.

Design
------
Parsers often produce nodes that carry a list of *names* they reference (stored
as ``node._ref_names``), but at parse time the target nodes may not exist yet.
``DependencyResolver.resolve()`` is called after the full tree is built; it
indexes every node by name and then creates the cross-node edges.

Usage example::

    from netsight.parsers.resolver import DependencyResolver

    resolver = DependencyResolver()
    resolved_tree = resolver.resolve(tree)
    issues = resolver.validate(tree)
"""

from __future__ import annotations

from netsight.parsers.base import ConfigNode, ConfigTree


class DependencyResolver:
    """Wires symbolic name references into live ``ConfigNode`` edges.

    After a parser produces a ``ConfigTree``, call :meth:`resolve` to convert
    any ``_ref_names`` lists stored on nodes into real
    :meth:`~netsight.parsers.base.ConfigNode.add_reference` links.
    """

    def resolve(
        self,
        tree: ConfigTree,
        ref_attr: str = "_ref_names",
    ) -> ConfigTree:
        """Walk all nodes, build a name index, and wire reference edges.

        For every node in *tree* that has an attribute named *ref_attr* (a
        list of name strings), each name is looked up in the global name index
        and, if found, a reference edge is created via
        :meth:`~netsight.parsers.base.ConfigNode.add_reference`.

        Parameters
        ----------
        tree:
            The ``ConfigTree`` to resolve.
        ref_attr:
            The attribute name on each node that holds a list of referenced
            node names.  Defaults to ``"_ref_names"``.

        Returns
        -------
        ConfigTree
            The same *tree* with reference edges populated.
        """
        all_nodes = tree.all_nodes()

        # Build a name -> node index (last writer wins for duplicate names)
        index: dict[str, ConfigNode] = {}
        for node in all_nodes:
            index[node.name] = node

        # Wire references
        for node in all_nodes:
            ref_names: list[str] = getattr(node, ref_attr, []) or []
            for target_name in ref_names:
                target = index.get(target_name)
                if target is not None:
                    node.add_reference(target)

        return tree

    def get_impact(self, node: ConfigNode) -> list[ConfigNode]:
        """Return the nodes that depend on *node* (inbound references).

        Parameters
        ----------
        node:
            The node whose impact set is requested.

        Returns
        -------
        list[ConfigNode]
            All nodes that hold a reference to *node* (i.e. ``node.referenced_by``).
        """
        return list(node.referenced_by)

    def get_dependencies(self, node: ConfigNode) -> list[ConfigNode]:
        """Return the nodes that *node* depends on (outbound references).

        Parameters
        ----------
        node:
            The node whose dependencies are requested.

        Returns
        -------
        list[ConfigNode]
            All nodes that *node* references (i.e. ``node.references``).
        """
        return list(node.references)

    def validate(self, tree: ConfigTree) -> list[dict]:
        """Find unresolved symbolic references across the tree.

        A reference is considered unresolved when a name in ``_ref_names``
        does not correspond to any node in the tree.

        Parameters
        ----------
        tree:
            The tree to validate.

        Returns
        -------
        list[dict]
            A list of issue records.  Each record has:

            ``source``
                The node that carries the unresolved reference.
            ``target``
                The name string that could not be resolved.
            ``path``
                The dot-separated path of the source node.

            An empty list means no broken references were found.
        """
        all_nodes = tree.all_nodes()

        # Build name index
        index: dict[str, ConfigNode] = {n.name: n for n in all_nodes}

        issues: list[dict] = []
        for node in all_nodes:
            ref_names: list[str] = getattr(node, "_ref_names", []) or []
            for target_name in ref_names:
                if target_name not in index:
                    issues.append(
                        {
                            "source": node,
                            "target": target_name,
                            "path": node.path,
                        }
                    )

        return issues
