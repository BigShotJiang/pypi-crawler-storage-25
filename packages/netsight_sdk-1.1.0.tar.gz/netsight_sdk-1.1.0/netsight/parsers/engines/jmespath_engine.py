"""JMESPath-based parser engine for XML and JSON inputs."""

from __future__ import annotations
import json
import logging
from dataclasses import dataclass
from typing import Any

import jmespath
import xmltodict

from netsight.parsers.exceptions import ParserError
from netsight.parsers.registry import (
    function_registry,
    parser_registry,
    transform_registry,
    type_registry,
)

logger = logging.getLogger(__name__)

_DEFAULT_FORCE_LIST = ("entry", "member", "item")
_REQUIRED_FIELDS = ("spec_version", "engine", "operation", "input_format", "output_shape")


@dataclass
class _ValidationError:
    field: str
    message: str

    def __str__(self) -> str:
        return f"{self.field}: {self.message}"


@parser_registry.register("jmespath")
class JMESPathEngine:
    name = "jmespath"

    def parse(self, raw: str | bytes | dict, spec: dict) -> Any:
        decoded = self._decode(raw, spec)
        decoded = self._pre_process(decoded, spec)

        # extract_function bypass — calls a registered function with decoded data
        if "extract_function" in spec:
            func = function_registry.get(spec["extract_function"])
            return func(decoded, **spec.get("extract_args", {}))

        output_shape = spec.get("output_shape", "dict")
        result: Any
        if output_shape == "list":
            result = self._extract_list(decoded, spec)
        elif output_shape == "dict":
            result = self._extract_dict(decoded, spec)
        else:
            result = self._extract_scalar(decoded, spec)

        return self._post_process(result, spec)

    def _decode(self, raw: str | bytes | dict, spec: dict) -> dict:
        if isinstance(raw, dict):
            return raw
        input_format = spec.get("input_format", "xml")
        force_list = tuple(spec.get("force_list", _DEFAULT_FORCE_LIST))
        try:
            if input_format == "xml":
                return xmltodict.parse(raw, force_list=force_list)
            elif input_format == "json":
                return json.loads(raw)
        except Exception as exc:
            raise ParserError(
                f"{input_format} decode failed: {exc}",
                operation=spec.get("operation"),
            ) from exc
        raise ParserError(
            f"Unsupported input_format: {input_format}",
            operation=spec.get("operation"),
        )

    def _pre_process(self, data: dict, spec: dict) -> dict:
        return data

    def _post_process(self, result: Any, spec: dict) -> Any:
        return result

    def _extract_list(self, data: dict, spec: dict) -> list:
        iterate_expr = spec.get("iterate", "")
        if not iterate_expr:
            raise ParserError(
                "List output shape requires 'iterate'",
                operation=spec.get("operation"),
            )
        items = jmespath.search(iterate_expr, data)
        if items is None:
            return []
        if not isinstance(items, list):
            items = [items]
        return [
            self._extract_fields(item, spec.get("fields", {}), data, spec)
            for item in items
        ]

    def _extract_dict(self, data: dict, spec: dict) -> dict:
        root_expr = spec.get("root", "@")
        root = jmespath.search(root_expr, data)
        if root is None:
            return {}
        return self._extract_fields(root, spec.get("fields", {}), data, spec)

    def _extract_scalar(self, data: dict, spec: dict) -> Any:
        return self._extract_dict(data, spec)

    def _extract_fields(
        self, item: Any, fields_spec: dict, full_data: dict, spec: dict
    ) -> dict:
        return {
            name: self._extract_field(name, fdef, item, full_data, spec)
            for name, fdef in fields_spec.items()
        }

    def _extract_field(
        self,
        name: str,
        field_def: dict,
        item: Any,
        full_data: dict,
        spec: dict,
    ) -> Any:
        if "function" in field_def:
            func = function_registry.get(field_def["function"])
            return func(full_data, **field_def.get("args", {}))

        path = field_def.get("path", name)
        raw_value = jmespath.search(path, item) if isinstance(item, dict) else None

        if raw_value is None:
            if field_def.get("required", False):
                raise ParserError(
                    f"Required field '{name}' missing",
                    operation=spec.get("operation"),
                )
            return field_def.get("default")

        type_name = field_def.get("type", "str")
        coerced = type_registry.get(type_name)(raw_value)

        for transform in field_def.get("transforms", []):
            coerced = self._apply_transform(transform, coerced)
        return coerced

    def _apply_transform(self, transform: Any, value: Any) -> Any:
        if isinstance(transform, str):
            name, args = transform, {}  # type: ignore[var-annotated]
        elif isinstance(transform, dict):
            name = next(iter(transform.keys()))
            arg_value = transform[name]
            args = arg_value if isinstance(arg_value, dict) else {"arg": arg_value}
        else:
            raise ParserError(f"Invalid transform spec: {transform}")
        func = transform_registry.get(name)
        return func(value, **args) if args else func(value)

    def validate_spec(self, spec: dict) -> list[_ValidationError]:
        errors: list[_ValidationError] = []

        for req in _REQUIRED_FIELDS:
            if req not in spec:
                errors.append(
                    _ValidationError(field=req, message="Required field missing")
                )

        output_shape = spec.get("output_shape")
        if output_shape and output_shape not in ("dict", "list", "scalar"):
            errors.append(
                _ValidationError(
                    field="output_shape",
                    message=f"Must be dict/list/scalar (got {output_shape})",
                )
            )

        input_format = spec.get("input_format")
        if input_format and input_format not in ("xml", "json"):
            errors.append(
                _ValidationError(
                    field="input_format",
                    message=f"Must be xml/json (got {input_format})",
                )
            )

        if (
            output_shape == "list"
            and not spec.get("iterate")
            and "extract_function" not in spec
        ):
            errors.append(
                _ValidationError(
                    field="iterate",
                    message="List output requires 'iterate' or 'extract_function'",
                )
            )

        for fname, fdef in spec.get("fields", {}).items():
            if "path" in fdef:
                try:
                    jmespath.compile(fdef["path"])
                except Exception as e:
                    errors.append(
                        _ValidationError(
                            field=f"fields.{fname}.path",
                            message=f"Invalid JMESPath: {e}",
                        )
                    )
            type_name = fdef.get("type", "str")
            if not type_registry.has(type_name):
                errors.append(
                    _ValidationError(
                        field=f"fields.{fname}.type",
                        message=f"Unknown type: {type_name}",
                    )
                )

        if spec.get("iterate"):
            try:
                jmespath.compile(spec["iterate"])
            except Exception as e:
                errors.append(
                    _ValidationError(
                        field="iterate",
                        message=f"Invalid JMESPath: {e}",
                    )
                )

        return errors
