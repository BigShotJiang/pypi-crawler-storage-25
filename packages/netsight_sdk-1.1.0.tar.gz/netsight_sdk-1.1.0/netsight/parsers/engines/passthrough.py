"""Passthrough engine — returns decoded input as-is."""

from __future__ import annotations
import json
from typing import Any

import xmltodict

from netsight.parsers.registry import parser_registry


@parser_registry.register("passthrough")
class PassthroughEngine:
    name = "passthrough"

    def parse(self, raw: str | bytes | dict, spec: dict) -> Any:
        if isinstance(raw, dict):
            return raw
        input_format = spec.get("input_format", "xml")
        if input_format == "xml":
            return xmltodict.parse(raw)
        elif input_format == "json":
            return json.loads(raw)
        return raw

    def validate_spec(self, spec: dict) -> list:
        return []
