"""NetSight config parser engine.

This package provides the building blocks for parsing, resolving, and loading
network device configuration files from multiple vendors.

Modules
-------
base
    ``ConfigNode``, ``ConfigTree``, and ``BaseConfigParser`` — the core data
    structures and abstract interface every parser must implement.
resolver
    ``DependencyResolver`` — walks a ``ConfigTree`` and converts symbolic
    ``_ref_names`` lists into live reference edges between nodes.
loader
    ``MultiFileLoader`` and ``SourceLocation`` — reads one or more config
    files into a single merged string and tracks which source file each line
    originated from.

Quick start::

    from netsight.parsers.base import ConfigNode, ConfigTree
    from netsight.parsers.resolver import DependencyResolver
    from netsight.parsers.loader import MultiFileLoader, SourceLocation
"""

# Existing exports (preserved)
from netsight.parsers.base import BaseConfigParser, ConfigNode, ConfigTree
from netsight.parsers.loader import MultiFileLoader, SourceLocation
from netsight.parsers.resolver import DependencyResolver

# New parser engine exports
from netsight.parsers.engine import ParserEngine
from netsight.parsers.exceptions import ParserError, SpecValidationError
from netsight.parsers.registry import (
    function_registry,
    parser_registry,
    transform_registry,
    type_registry,
)
from netsight.parsers.spec import load_parser_spec, validate_parser_spec

# Trigger registration of built-in types, transforms, and engines
from netsight.parsers import types as _types  # noqa: F401
from netsight.parsers import transforms as _transforms  # noqa: F401
from netsight.parsers.engines import jmespath_engine as _jmespath  # noqa: F401
from netsight.parsers.engines import passthrough as _passthrough  # noqa: F401

__all__ = [
    # Config parser (Tasks 1-5)
    "BaseConfigParser",
    "ConfigNode",
    "ConfigTree",
    "MultiFileLoader",
    "SourceLocation",
    "DependencyResolver",
    # Engine infrastructure
    "ParserEngine",
    "ParserError",
    "SpecValidationError",
    "function_registry",
    "parser_registry",
    "transform_registry",
    "type_registry",
    "load_parser_spec",
    "validate_parser_spec",
]
