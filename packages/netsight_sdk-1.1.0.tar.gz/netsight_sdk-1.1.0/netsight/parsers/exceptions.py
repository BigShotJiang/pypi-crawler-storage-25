"""Parser-related exceptions for NetSight."""

from __future__ import annotations

from netsight.exceptions import NetSightError


class ParserError(NetSightError):
    """Raised when a parser fails to parse a device response."""

    def __init__(self, message: str, operation: str | None = None) -> None:
        self.operation = operation
        if operation:
            message = f"Parser error for operation '{operation}': {message}"
        super().__init__(message)


class SpecValidationError(ParserError):
    """Raised when a parser spec fails validation."""

    def __init__(self, message: str, spec_path: str | None = None) -> None:
        self.spec_path = spec_path
        if spec_path:
            message = f"Spec validation error in '{spec_path}': {message}"
        super().__init__(message)
