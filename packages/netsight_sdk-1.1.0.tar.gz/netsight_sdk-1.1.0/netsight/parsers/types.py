"""Built-in field type coercion functions for the NetSight parser engine.

Each function is registered in :data:`~netsight.parsers.registry.type_registry`
under its canonical name (``"str"``, ``"int"``, etc.).  Call a coercion function
by fetching it from the registry::

    from netsight.parsers.registry import type_registry
    fn = type_registry.get("ip")
    result = fn("192.168.1.1")   # → "192.168.1.1"

Type functions must accept a single value and return the coerced result.  On
failure they return a safe empty value rather than raising an exception, so
parser pipelines remain resilient.
"""

from __future__ import annotations

import ipaddress
import re
from typing import Any

from netsight.parsers.registry import type_registry

# ---------------------------------------------------------------------------
# str
# ---------------------------------------------------------------------------

@type_registry.register("str")
def _coerce_str(value: Any) -> str:
    """Return ``str(value)``, or ``""`` for ``None``."""
    if value is None:
        return ""
    return str(value)


# ---------------------------------------------------------------------------
# int
# ---------------------------------------------------------------------------

@type_registry.register("int")
def _coerce_int(value: Any) -> int:
    """Return ``int(value)``, or ``0`` on any conversion failure."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------------------
# float
# ---------------------------------------------------------------------------

@type_registry.register("float")
def _coerce_float(value: Any) -> float:
    """Return ``float(value)``, or ``0.0`` on any conversion failure."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


# ---------------------------------------------------------------------------
# bool
# ---------------------------------------------------------------------------

_TRUTHY: frozenset[str] = frozenset(
    {"yes", "enabled", "up", "active", "true", "1", "on"}
)
_FALSY: frozenset[str] = frozenset(
    {"no", "disabled", "down", "inactive", "false", "0", "off"}
)


@type_registry.register("bool")
def _coerce_bool(value: Any) -> bool:
    """Vendor-aware boolean coercion.

    Native ``bool`` values pass through unchanged.  String values are matched
    case-insensitively against vendor keyword sets.  Unrecognised strings
    return ``False``.
    """
    if isinstance(value, bool):
        return value
    lowered = str(value).lower()
    if lowered in _TRUTHY:
        return True
    return False


# ---------------------------------------------------------------------------
# ip
# ---------------------------------------------------------------------------

@type_registry.register("ip")
def _coerce_ip(value: Any) -> str:
    """Validate *value* as an IP address; return normalised string or ``""``."""
    if value is None:
        return ""
    try:
        return str(ipaddress.ip_address(str(value).strip()))
    except ValueError:
        return ""


# ---------------------------------------------------------------------------
# cidr
# ---------------------------------------------------------------------------

@type_registry.register("cidr")
def _coerce_cidr(value: Any) -> str:
    """Validate *value* as a CIDR prefix; return network string or ``""``.

    Uses ``strict=False`` so host bits are silently masked
    (e.g. ``"10.0.0.1/8"`` → ``"10.0.0.0/8"``).
    """
    if value is None:
        return ""
    try:
        return str(ipaddress.ip_network(str(value).strip(), strict=False))
    except ValueError:
        return ""


# ---------------------------------------------------------------------------
# mac
# ---------------------------------------------------------------------------

# Accepts colon, dash, or Cisco dot-separated formats.
_MAC_COLON_DASH = re.compile(
    r"^([0-9a-fA-F]{2})[:\-]"
    r"([0-9a-fA-F]{2})[:\-]"
    r"([0-9a-fA-F]{2})[:\-]"
    r"([0-9a-fA-F]{2})[:\-]"
    r"([0-9a-fA-F]{2})[:\-]"
    r"([0-9a-fA-F]{2})$"
)
_MAC_DOT = re.compile(
    r"^([0-9a-fA-F]{4})\.([0-9a-fA-F]{4})\.([0-9a-fA-F]{4})$"
)


@type_registry.register("mac")
def _coerce_mac(value: Any) -> str:
    """Normalise a MAC address to lowercase colon-separated form, or ``""``."""
    if value is None:
        return ""
    raw = str(value).strip()

    m = _MAC_COLON_DASH.match(raw)
    if m:
        return ":".join(g.lower() for g in m.groups())

    m = _MAC_DOT.match(raw)
    if m:
        # Expand each 4-char group into two 2-char octets
        octets: list[str] = []
        for group in m.groups():
            octets.append(group[:2].lower())
            octets.append(group[2:].lower())
        return ":".join(octets)

    return ""


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

@type_registry.register("list")
def _coerce_list(value: Any) -> list[Any]:
    """Split a comma-separated string into a list, pass lists through, ``[]`` for None."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [item.strip() for item in str(value).split(",")]
