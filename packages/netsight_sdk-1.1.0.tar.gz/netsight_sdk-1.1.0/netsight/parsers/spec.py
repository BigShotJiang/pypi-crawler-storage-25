"""Parser spec loader and validator."""

from __future__ import annotations
import logging
from pathlib import Path
from typing import Any

import yaml

from netsight.parsers.exceptions import SpecValidationError
from netsight.parsers.registry import parser_registry

logger = logging.getLogger(__name__)


def load_parser_spec(spec_path: Path | str) -> dict[str, Any]:
    """Load a parser spec from a YAML file.

    Parameters
    ----------
    spec_path:
        Path to the YAML spec file.

    Returns
    -------
    dict
        The parsed spec as a dictionary.

    Raises
    ------
    SpecValidationError
        If the file does not exist, is not valid YAML, or does not contain a
        top-level mapping.
    """
    path = Path(spec_path)
    if not path.exists():
        raise SpecValidationError(
            f"Parser spec file not found: {path}",
            spec_path=str(path),
        )
    return load_parser_spec_from_text(
        path.read_text(encoding="utf-8"),
        source_ref=str(path),
    )


def load_parser_spec_from_text(
    yaml_text: str,
    source_ref: str = "<inline>",
) -> dict[str, Any]:
    """Load and validate a parser spec from a YAML text string.

    Used by the config compiler when reading parser specs from pack-bundled
    ``_data/`` trees via :class:`importlib.resources.abc.Traversable` handles,
    where there is no filesystem path to pass to :func:`load_parser_spec`.

    Parameters
    ----------
    yaml_text:
        The YAML source as a string.
    source_ref:
        An identifier used in error messages (typically a rendered
        Traversable path or a package-relative location).

    Returns
    -------
    dict
        The parsed spec as a dictionary.

    Raises
    ------
    SpecValidationError
        If the YAML is invalid or does not contain a top-level mapping.
    """
    try:
        spec = yaml.safe_load(yaml_text)
    except yaml.YAMLError as e:
        raise SpecValidationError(
            f"Invalid YAML: {e}",
            spec_path=source_ref,
        ) from e
    if not isinstance(spec, dict):
        raise SpecValidationError(
            f"Spec must be a dict, got {type(spec).__name__}",
            spec_path=source_ref,
        )
    logger.debug("Loaded parser spec: %s", source_ref)
    return spec


def validate_parser_spec(spec: dict) -> list:
    """Validate a parser spec via the engine's validate_spec() method.

    Parameters
    ----------
    spec:
        Parser specification dict to validate.

    Returns
    -------
    list
        A list of validation error objects (empty means valid).  Each item
        is either a string or an object whose ``str()`` representation
        describes the error.
    """
    engine_name = spec.get("engine")
    if not engine_name:
        return [{"field": "engine", "message": "Required field missing"}]
    if not parser_registry.has(engine_name):
        return [
            {
                "field": "engine",
                "message": (
                    f"Unknown engine '{engine_name}'."
                    f" Available: {parser_registry.list_names()}"
                ),
            }
        ]
    engine_class = parser_registry.get(engine_name)
    engine = engine_class()
    return engine.validate_spec(spec)
