"""ParserEngine Protocol — abstract interface for all parser engines."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ParserEngine(Protocol):
    """Abstract parser engine interface.

    All concrete parser engines must satisfy this structural Protocol.
    The ``@runtime_checkable`` decorator enables ``isinstance`` checks at
    runtime so registries and dependency-injection helpers can validate
    engine implementations without importing concrete classes.

    Attributes
    ----------
    name:
        Unique identifier for this engine (e.g. ``"textfsm"``, ``"ttp"``).
        Used as the key in :data:`~netsight.parsers.registry.parser_registry`.

    Methods
    -------
    parse(raw, spec):
        Parse *raw* device output according to *spec* and return structured data.
    validate_spec(spec):
        Validate *spec* for this engine and return a (possibly empty) list of
        error strings.  An empty list means the spec is valid.
    """

    name: str

    def parse(self, raw: str | bytes | dict, spec: dict) -> Any:
        """Parse raw device response according to spec.

        Parameters
        ----------
        raw:
            The raw device response — may be a string, bytes, or a pre-parsed
            dict depending on the collection mechanism.
        spec:
            Parser specification dict describing how to extract fields from
            *raw*.

        Returns
        -------
        Any
            Structured data (typically a dict or list of dicts).
        """
        ...

    def validate_spec(self, spec: dict) -> list:
        """Validate a parser spec for this engine.

        Parameters
        ----------
        spec:
            Parser specification dict to validate.

        Returns
        -------
        list
            A list of human-readable error strings.  An empty list indicates
            the spec is valid.
        """
        ...
