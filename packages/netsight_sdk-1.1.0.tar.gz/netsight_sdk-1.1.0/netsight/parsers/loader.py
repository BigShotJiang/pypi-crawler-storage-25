"""Multi-file configuration loader for NetSight.

Reads one or more config files into a single merged string while tracking
which source file and line number each merged line originated from.

Design
------
``MultiFileLoader.load()`` concatenates files in order, recording a
``SourceLocation`` for every output line.  Parsers can later call
``track_origin()`` with a 1-based merged line number to obtain the original
file path and line number.

Usage example::

    from netsight.parsers.loader import MultiFileLoader

    loader = MultiFileLoader()
    merged = loader.load(["/etc/netsight/fw1.conf", "/etc/netsight/fw2.conf"])
    origin = loader.track_origin(42)   # -> SourceLocation(file_path=..., line_number=...)
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class SourceLocation:
    """The origin of a single line in a merged config string.

    Attributes
    ----------
    file_path:
        Absolute or relative path of the source file.
    line_number:
        1-based line number within *file_path*.
    """

    file_path: str
    line_number: int


class MultiFileLoader:
    """Loads multiple config files into a single merged text blob.

    After calling :meth:`load`, use :meth:`track_origin` to map any merged
    line number back to its original file and line.
    """

    def __init__(self) -> None:
        self._origins: list[SourceLocation] = []

    def load(self, paths: list[str]) -> str:
        """Read all *paths* and return their contents concatenated.

        Lines are concatenated in file order.  Origin tracking is reset on
        each call so ``track_origin`` always reflects the most recent
        ``load()`` invocation.

        Parameters
        ----------
        paths:
            Ordered list of file paths to read.

        Returns
        -------
        str
            The merged file contents with newlines preserved.

        Raises
        ------
        FileNotFoundError
            If any path in *paths* does not exist or is not a regular file.
        """
        self._origins = []
        merged_parts: list[str] = []

        for file_path in paths:
            p = Path(file_path)
            if not p.exists():
                raise FileNotFoundError(
                    f"Config file not found: {file_path!r}"
                )

            raw = p.read_text(encoding="utf-8")
            lines = raw.splitlines(keepends=True)

            for source_line_number, line in enumerate(lines, start=1):
                self._origins.append(
                    SourceLocation(
                        file_path=str(file_path),
                        line_number=source_line_number,
                    )
                )
                merged_parts.append(line)

        return "".join(merged_parts)

    def track_origin(self, merged_line_number: int) -> SourceLocation | None:
        """Return the source location for a 1-based merged line number.

        Parameters
        ----------
        merged_line_number:
            1-based index into the merged output produced by the most recent
            :meth:`load` call.

        Returns
        -------
        SourceLocation | None
            The original file path and line number, or ``None`` if
            *merged_line_number* is out of range.
        """
        index = merged_line_number - 1  # convert to 0-based
        if index < 0 or index >= len(self._origins):
            return None
        return self._origins[index]

    def get_origins(self) -> list[SourceLocation]:
        """Return the full origin list from the most recent :meth:`load` call.

        Returns
        -------
        list[SourceLocation]
            One entry per line in the merged output, in order.
        """
        return list(self._origins)
