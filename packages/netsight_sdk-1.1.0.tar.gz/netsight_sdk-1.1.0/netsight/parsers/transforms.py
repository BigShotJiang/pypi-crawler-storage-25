"""Built-in field transform functions for the NetSight parser engine.

Each function is registered in
:data:`~netsight.parsers.registry.transform_registry` under its canonical name.

Transform signatures
--------------------
All transforms accept *value* as the first positional argument.  Optional
configuration is passed either as a named ``arg`` keyword (single-value config)
or as named keyword arguments (multi-value config like ``from_`` / ``to``).

Example::

    from netsight.parsers.registry import transform_registry

    fn = transform_registry.get("split")
    result = fn("a,b,c", arg=",")   # → ["a", "b", "c"]
"""

from __future__ import annotations

import re
from typing import Any

from netsight.parsers.registry import transform_registry

# ---------------------------------------------------------------------------
# strip
# ---------------------------------------------------------------------------


@transform_registry.register("strip")
def _transform_strip(value: Any) -> str:
    """Return ``str(value).strip()``."""
    return str(value).strip()


# ---------------------------------------------------------------------------
# lower
# ---------------------------------------------------------------------------


@transform_registry.register("lower")
def _transform_lower(value: Any) -> str:
    """Return ``str(value).lower()``."""
    return str(value).lower()


# ---------------------------------------------------------------------------
# upper
# ---------------------------------------------------------------------------


@transform_registry.register("upper")
def _transform_upper(value: Any) -> str:
    """Return ``str(value).upper()``."""
    return str(value).upper()


# ---------------------------------------------------------------------------
# split
# ---------------------------------------------------------------------------


@transform_registry.register("split")
def _transform_split(value: Any, arg: str = ",") -> list[str]:
    """Split *value* on *arg* delimiter; strip each piece.

    Parameters
    ----------
    value:
        String to split.
    arg:
        Delimiter character or string (default ``","``).
    """
    return [item.strip() for item in str(value).split(arg)]


# ---------------------------------------------------------------------------
# enum
# ---------------------------------------------------------------------------


@transform_registry.register("enum")
def _transform_enum(value: Any, arg: list[Any] | None = None) -> Any:
    """Return *value* if it is present in the *arg* allow-list, else ``""``.

    Parameters
    ----------
    value:
        The value to validate.
    arg:
        Ordered list of permitted values.
    """
    if arg is None:
        arg = []
    return value if value in arg else ""


# ---------------------------------------------------------------------------
# regex_extract
# ---------------------------------------------------------------------------


@transform_registry.register("regex_extract")
def _transform_regex_extract(value: Any, arg: str = "") -> str:
    """Return the first capture group of *arg* applied to *value*, or ``""``.

    If the pattern has no capture groups, the full match text is returned.

    Parameters
    ----------
    value:
        String to search.
    arg:
        Regular expression pattern.  Should include a capture group to extract
        a sub-string; without one the full match is returned.
    """
    if not arg:
        return ""
    m = re.search(arg, str(value))
    if m is None:
        return ""
    groups = m.groups()
    if groups:
        return groups[0] if groups[0] is not None else ""
    return m.group(0)


# ---------------------------------------------------------------------------
# replace
# ---------------------------------------------------------------------------


@transform_registry.register("replace")
def _transform_replace(value: Any, from_: str = "", to: str = "") -> str:
    """Return ``str(value).replace(from_, to)``.

    Parameters
    ----------
    value:
        String in which replacements are performed.
    from_:
        Sub-string to search for.
    to:
        Replacement string.
    """
    return str(value).replace(from_, to)
