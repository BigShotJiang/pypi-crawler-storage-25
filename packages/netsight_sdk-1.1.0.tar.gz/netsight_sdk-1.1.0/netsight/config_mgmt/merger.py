"""Config merger for the NetSight hierarchical config system.

Merges a list of level dicts (produced by :class:`~netsight.config_mgmt.reader.ConfigReader`)
into a single resolved configuration dict.

Merge semantics
---------------
* **Simple sections** (``connection``, ``resilience``, ``auth``, ``metadata``):
  levels are applied top-to-bottom with ``dict.update()``, so lower levels
  override individual fields from upper levels.

* **Operations**: accumulated additively across levels (lower level overrides
  an operation of the same name).  At each level, any names listed in
  ``remove_operations`` are removed from the accumulated set *after* that
  level's additions have been applied.

All methods are static — ``ConfigMerger`` has no instance state.
"""

from __future__ import annotations

_SIMPLE_SECTIONS: tuple[str, ...] = ("connection", "resilience", "auth", "metadata")
_REMOVE_OPS_KEY = "remove_operations"


class ConfigMerger:
    """Static methods for merging hierarchical level dicts."""

    @staticmethod
    def merge_section(section: str, levels: list[dict]) -> dict:
        """Merge a simple parameter section across all levels.

        Levels are visited in order (index 0 = most general, last index =
        most specific).  Each level's section dict is merged with
        ``dict.update()``, so later levels override individual keys from
        earlier levels.

        Parameters
        ----------
        section:
            Section key to merge (e.g. ``"connection"``).
        levels:
            Ordered list of level dicts as returned by
            :meth:`ConfigReader.read_vendor_tree`.

        Returns
        -------
        dict
            Merged section dict.
        """
        merged: dict = {}
        for level in levels:
            section_data = level.get(section, {})
            if section_data:
                merged.update(section_data)
        return merged

    @staticmethod
    def merge_operations(levels: list[dict]) -> dict:
        """Merge operations across all levels with additive + remove semantics.

        For each level in order:

        1. Merge that level's ``operations`` dict into the accumulated set
           (lower-level definitions override same-named upper-level ones).
        2. Remove any names listed in ``remove_operations`` from the
           accumulated set.

        Parameters
        ----------
        levels:
            Ordered list of level dicts as returned by
            :meth:`ConfigReader.read_vendor_tree`.

        Returns
        -------
        dict
            Resolved operations dict mapping operation name to its definition.
        """
        accumulated: dict[str, dict] = {}
        for level in levels:
            ops = level.get("operations", {})
            if ops:
                accumulated.update(ops)
            for name in level.get(_REMOVE_OPS_KEY, []):
                accumulated.pop(name, None)
        return accumulated

    @staticmethod
    def merge_all(levels: list[dict]) -> dict:
        """Merge all sections and operations into a single resolved config dict.

        Parameters
        ----------
        levels:
            Ordered list of level dicts as returned by
            :meth:`ConfigReader.read_vendor_tree`.

        Returns
        -------
        dict
            Keys: ``connection``, ``resilience``, ``auth``, ``metadata``,
            ``operations``.
        """
        result: dict = {}
        for section in _SIMPLE_SECTIONS:
            result[section] = ConfigMerger.merge_section(section, levels)
        result["operations"] = ConfigMerger.merge_operations(levels)
        return result
