"""TOML config reader for the NetSight hierarchical config system.

Reads section TOML files from a directory hierarchy organised as::

    <config_dir>/
      global/
      <vendor>/
      <vendor>/<model>/
      <vendor>/<model>/instances/<instance>/

Each directory level may contain any subset of the standard section files:
``connection.toml``, ``resilience.toml``, ``auth.toml``, ``metadata.toml``,
and ``operations_catalog.toml``.

The reader accepts any :class:`importlib.resources.abc.Traversable` as its
root — in practice that means either a :class:`pathlib.Path` (for the
legacy in-tree ``config/vendors/`` layout) or an
``importlib.resources.files(pack)`` handle (for pack-bundled ``_data/``
trees delivered via wheel package-data).
"""

from __future__ import annotations

import tomllib
import warnings
from importlib.resources.abc import Traversable
from pathlib import Path

from netsight.packs._traversable import as_traversable

_SIMPLE_SECTIONS: tuple[str, ...] = ("connection", "resilience", "auth", "metadata")
_REMOVE_OPS_KEY = "remove_operations"

# Canonical operations filename inside a pack's _data/ directory.
# Changed from ``operations.toml`` in Phase 11 (catalog vs permissions split).
_OPERATIONS_FILENAME = "operations_catalog.toml"
# Legacy filename kept for a deprecation-shim grace period.
_OPERATIONS_FILENAME_LEGACY = "operations.toml"


def _find_operations_file(level_dir: Traversable) -> Traversable | None:
    """Locate the operations file in *level_dir*, preferring the new name.

    Returns the ``operations_catalog.toml`` Traversable if present, falls
    back to ``operations.toml`` with a :class:`DeprecationWarning`, or
    returns ``None`` when neither exists.

    Parameters
    ----------
    level_dir:
        Any Traversable pointing at a config level directory.

    Returns
    -------
    Traversable | None
        The file to read, or ``None`` when neither candidate exists.
    """
    catalog = level_dir.joinpath(_OPERATIONS_FILENAME)
    if catalog.is_file():
        return catalog
    legacy = level_dir.joinpath(_OPERATIONS_FILENAME_LEGACY)
    if legacy.is_file():
        warnings.warn(
            f"Pack ships '{_OPERATIONS_FILENAME_LEGACY}' — rename to "
            f"'{_OPERATIONS_FILENAME}'. "
            "The old filename will be removed in a future release.",
            DeprecationWarning,
            stacklevel=3,
        )
        return legacy
    return None


class ConfigReader:
    """Reads TOML section files from a config directory hierarchy.

    Parameters
    ----------
    config_dir:
        Root directory that contains the ``global/`` folder and all
        vendor sub-directories. Accepts a :class:`pathlib.Path`, a
        string path (coerced to ``Path``), or any
        :class:`importlib.resources.abc.Traversable`.
    """

    def __init__(self, config_dir: Path | str | Traversable) -> None:
        if isinstance(config_dir, str):
            config_dir = Path(config_dir)
        self._config_dir: Traversable = as_traversable(config_dir)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def read_level(self, level_dir: Traversable) -> dict:
        """Read all section TOML files from *level_dir*.

        Parameters
        ----------
        level_dir:
            Directory to read from. Any :class:`Traversable` works —
            :class:`Path` and ``importlib.resources`` handles both
            qualify. Missing files produce empty dicts/lists rather than
            errors.

        Returns
        -------
        dict
            Keys: ``connection``, ``resilience``, ``auth``, ``metadata``,
            ``operations``, ``remove_operations``.
        """
        level = self._empty_level()

        # Simple key-value sections — each file has a single top-level table
        # whose name matches the section, e.g. ``[connection]``.
        for section in _SIMPLE_SECTIONS:
            raw = self._read_toml(level_dir.joinpath(f"{section}.toml"))
            level[section] = raw.get(section, {})

        # Operations are special: each operation is a top-level table keyed by
        # its name, and an optional ``[remove_operations]`` table holds the
        # list of names to remove at this level.
        ops_file = _find_operations_file(level_dir)
        ops_raw = self._read_toml(ops_file) if ops_file is not None else {}
        remove_list: list[str] = []
        operations: dict[str, dict] = {}

        for key, value in ops_raw.items():
            if key == _REMOVE_OPS_KEY:
                # Extract the nested ``operations = [...]`` list.
                if isinstance(value, dict):
                    remove_list = list(value.get("operations", []))
            elif isinstance(value, dict):
                operations[key] = value

        level["operations"] = operations
        level[_REMOVE_OPS_KEY] = remove_list

        return level

    def read_vendor_tree(
        self,
        vendor: str,
        model: str,
        instance: str | None = None,
    ) -> list[dict]:
        """Read all hierarchy levels for a given vendor/model/instance.

        The levels are returned in top-down order:

        0. ``global/``
        1. ``<vendor>/``
        2. ``<vendor>/<model>/``
        3. ``<vendor>/<model>/instances/<instance>/``  *(only when* instance *given)*

        Missing directories produce empty level dicts rather than errors.

        Parameters
        ----------
        vendor:
            Vendor directory name (e.g. ``"paloalto"``).
        model:
            Model directory name (e.g. ``"pa-vm"``).
        instance:
            Optional instance name.  When supplied a fourth level is included.

        Returns
        -------
        list[dict]
            Three or four level dicts.
        """
        dirs: list[Traversable] = [
            self._config_dir.joinpath("global"),
            self._config_dir.joinpath(vendor),
            self._config_dir.joinpath(vendor).joinpath(model),
        ]
        if instance is not None:
            dirs.append(
                self._config_dir.joinpath(vendor)
                .joinpath(model)
                .joinpath("instances")
                .joinpath(instance)
            )

        return [
            self.read_level(d) if d.is_dir() else self._empty_level()
            for d in dirs
        ]

    def get_source_files(
        self,
        vendor: str,
        model: str,
        instance: str | None = None,
    ) -> list[str]:
        """Return relative paths of all TOML files that would be read.

        Only files that actually exist on disk are included. Relative
        prefixes are computed from the known hierarchy components rather
        than by ``Path.relative_to`` so the method works uniformly over
        :class:`Path` and ``importlib.resources`` Traversables.

        Parameters
        ----------
        vendor:
            Vendor directory name.
        model:
            Model directory name.
        instance:
            Optional instance name.

        Returns
        -------
        list[str]
            Relative paths (strings) of existing TOML files, in
            hierarchy order.
        """
        # Each entry pairs the on-disk Traversable with the string prefix
        # used to build the returned relative paths.
        levels: list[tuple[Traversable, str]] = [
            (self._config_dir.joinpath("global"), "global"),
            (self._config_dir.joinpath(vendor), vendor),
            (
                self._config_dir.joinpath(vendor).joinpath(model),
                f"{vendor}/{model}",
            ),
        ]
        if instance is not None:
            levels.append(
                (
                    self._config_dir.joinpath(vendor)
                    .joinpath(model)
                    .joinpath("instances")
                    .joinpath(instance),
                    f"{vendor}/{model}/instances/{instance}",
                )
            )

        simple_section_files = list(_SIMPLE_SECTIONS)
        result: list[str] = []

        for level_dir, prefix in levels:
            if not level_dir.is_dir():
                continue
            for section in simple_section_files:
                candidate = level_dir.joinpath(f"{section}.toml")
                if candidate.is_file():
                    result.append(f"{prefix}/{section}.toml")
            # Operations file: check new name first, then legacy.
            ops_file = _find_operations_file(level_dir)
            if ops_file is not None:
                # Determine the actual filename that exists on disk.
                ops_name = _OPERATIONS_FILENAME if level_dir.joinpath(_OPERATIONS_FILENAME).is_file() else _OPERATIONS_FILENAME_LEGACY
                result.append(f"{prefix}/{ops_name}")

        return result

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _read_toml(resource: Traversable) -> dict:
        """Read a TOML file from a Traversable and return its parsed contents.

        Returns an empty dict if the file does not exist. Works uniformly
        over :class:`Path` and ``importlib.resources`` handles because
        :class:`Traversable` defines ``is_file`` and ``read_text`` on
        both.

        Parameters
        ----------
        resource:
            A Traversable pointing at a (possibly missing) TOML file.
        """
        if not resource.is_file():
            return {}
        return tomllib.loads(resource.read_text(encoding="utf-8"))

    @staticmethod
    def _empty_level() -> dict:
        """Return a level dict with all sections set to their empty defaults."""
        return {
            "connection": {},
            "resilience": {},
            "auth": {},
            "metadata": {},
            "operations": {},
            _REMOVE_OPS_KEY: [],
        }
