"""Section schema definitions and validation helpers for NetSight configs.

Each ``validate_*`` function accepts a plain Python dictionary representing
one config section and returns a (possibly empty) list of
:class:`ValidationError` objects describing any problems found.

An empty return list means the section is valid.

Design notes
------------
* Unknown fields are flagged as errors to catch typos early.
* Type errors are checked before semantic constraints (positivity) so that
  we never attempt arithmetic on a non-numeric value.
* ``read_only`` on operations must be explicitly ``True``; absent or ``False``
  are both rejected because allowing mutable operations would violate the
  read-only contract of the SDK.
"""

from __future__ import annotations

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# ValidationError dataclass
# ---------------------------------------------------------------------------


@dataclass
class ValidationError:
    """A single validation finding.

    Attributes
    ----------
    field:
        The dotted config key path that caused the error (e.g. ``"connection.timeout_connect"``).
    message:
        Human-readable description of the problem.
    level:
        Severity string — ``"error"`` (default) or ``"warning"``.
    """

    field: str
    message: str
    level: str = "error"

    def __str__(self) -> str:  # noqa: D105
        return f"[{self.level.upper()}] {self.field}: {self.message}"


# ---------------------------------------------------------------------------
# Schema definitions
# ---------------------------------------------------------------------------

_CONNECTION_SCHEMA: dict[str, type] = {
    "verify_ssl": bool,
    "timeout_connect": int,
    "timeout_read": int,
}

_RESILIENCE_SCHEMA: dict[str, type] = {
    "rate_limit": int,
    "max_retries": int,
    "retry_base_delay": (int, float),  # type: ignore[dict-item]
    "max_response_bytes": int,
}

_AUTH_SCHEMA: dict[str, type] = {
    "method": str,
    "token_ttl": int,
}

_METADATA_SCHEMA: dict[str, type] = {
    "vendor": str,
    "display_name": str,
    "description": str,
    "device_type": str,
}

_OPERATION_REQUIRED_FIELDS: frozenset[str] = frozenset(
    {"command", "type", "category", "description", "read_only"}
)

_OPERATION_OPTIONAL_FIELDS: frozenset[str] = frozenset(
    {
        "panos_cli_equivalent",
        "min_panos_version",
        "output_format",
        "parameters",
        "parameter_descriptions",
        "notes",
        "doc_url",
        "tags",
        "parser_spec",      # Path to a parser spec YAML file for this operation
        "log_type",         # For type="log" operations: the vendor log category
                            # (e.g. "traffic", "threat", "system" for PAN-OS)
        "required_model",   # Model-gating: "*" (default, any model) or a list
                            # of model names this operation only works on.
    }
)

# ``type`` field is free-form by design. Different vendor packs use
# different dispatch shapes: PAN-OS uses "op" / "log", Cisco IOS might
# use "cli" / "get", NETCONF packs might use "get" / "get-config" / "rpc".
# The schema validates that a ``type`` value is present, not that it
# matches a specific enum. The ONLY special case is ``type == "log"``,
# which triggers the conditional log_type requirement below.
_LOG_TYPE_TRIGGER: str = "log"


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _check_unknown_fields(
    data: dict, known: frozenset[str], section: str
) -> list[ValidationError]:
    """Return errors for every key in *data* that is not in *known*."""
    errors: list[ValidationError] = []
    for key in data:
        if key not in known:
            errors.append(
                ValidationError(
                    field=f"{section}.{key}",
                    message=f"unknown field '{key}'",
                )
            )
    return errors


def _check_type(
    data: dict,
    key: str,
    expected: type | tuple[type, ...],
    section: str,
) -> list[ValidationError]:
    """Return an error if *key* is present in *data* but has the wrong type.

    Missing keys are silently skipped (required-field presence is the caller's
    responsibility).
    """
    if key not in data:
        return []
    value = data[key]
    if not isinstance(value, expected):
        # Build a human-readable type name.
        if isinstance(expected, tuple):
            type_name = " or ".join(t.__name__ for t in expected)
        else:
            type_name = expected.__name__
        return [
            ValidationError(
                field=f"{section}.{key}",
                message=f"expected {type_name}, got {type(value).__name__}",
            )
        ]
    return []


def _check_positive(data: dict, key: str, section: str) -> list[ValidationError]:
    """Return an error if *key* is present and its numeric value is <= 0."""
    if key not in data:
        return []
    value = data[key]
    if isinstance(value, (int, float)) and value <= 0:
        return [
            ValidationError(
                field=f"{section}.{key}",
                message=f"must be positive (> 0), got {value}",
            )
        ]
    return []


# ---------------------------------------------------------------------------
# Public validation functions
# ---------------------------------------------------------------------------


def validate_connection(data: dict) -> list[ValidationError]:
    """Validate the ``connection`` config section.

    Checks for unknown fields, correct types, and that timeout values are
    strictly positive.

    Parameters
    ----------
    data:
        The connection section as a plain dictionary.

    Returns
    -------
    list[ValidationError]
        Empty if valid; otherwise one entry per problem found.
    """
    section = "connection"
    errors: list[ValidationError] = []
    known = frozenset(_CONNECTION_SCHEMA)

    errors.extend(_check_unknown_fields(data, known, section))

    for key, expected in _CONNECTION_SCHEMA.items():
        errors.extend(_check_type(data, key, expected, section))

    for key in ("timeout_connect", "timeout_read"):
        errors.extend(_check_positive(data, key, section))

    return errors


def validate_resilience(data: dict) -> list[ValidationError]:
    """Validate the ``resilience`` config section.

    Checks for unknown fields, correct types, and that all numeric fields are
    strictly positive.

    Parameters
    ----------
    data:
        The resilience section as a plain dictionary.

    Returns
    -------
    list[ValidationError]
        Empty if valid; otherwise one entry per problem found.
    """
    section = "resilience"
    errors: list[ValidationError] = []
    known = frozenset(_RESILIENCE_SCHEMA)

    errors.extend(_check_unknown_fields(data, known, section))

    for key, expected in _RESILIENCE_SCHEMA.items():
        errors.extend(_check_type(data, key, expected, section))

    for key in _RESILIENCE_SCHEMA:
        errors.extend(_check_positive(data, key, section))

    return errors


def validate_auth(data: dict) -> list[ValidationError]:
    """Validate the ``auth`` config section.

    Checks field types and that ``token_ttl`` is strictly positive.

    Parameters
    ----------
    data:
        The auth section as a plain dictionary.

    Returns
    -------
    list[ValidationError]
        Empty if valid; otherwise one entry per problem found.
    """
    section = "auth"
    errors: list[ValidationError] = []
    known = frozenset(_AUTH_SCHEMA)

    errors.extend(_check_unknown_fields(data, known, section))

    for key, expected in _AUTH_SCHEMA.items():
        errors.extend(_check_type(data, key, expected, section))

    errors.extend(_check_positive(data, "token_ttl", section))

    return errors


def validate_metadata(data: dict) -> list[ValidationError]:
    """Validate the ``metadata`` config section.

    Checks field types and unknown fields.

    Parameters
    ----------
    data:
        The metadata section as a plain dictionary.

    Returns
    -------
    list[ValidationError]
        Empty if valid; otherwise one entry per problem found.
    """
    section = "metadata"
    errors: list[ValidationError] = []
    known = frozenset(_METADATA_SCHEMA)

    errors.extend(_check_unknown_fields(data, known, section))

    for key, expected in _METADATA_SCHEMA.items():
        errors.extend(_check_type(data, key, expected, section))

    return errors


def validate_operations(data: dict) -> list[ValidationError]:
    """Validate the ``operations`` config section.

    *data* is expected to be a mapping of operation name to operation dict.
    For each operation this function checks:

    * All required fields are present.
    * ``read_only`` is explicitly ``True`` (absent or ``False`` are errors).
    * No unknown fields are present.

    Parameters
    ----------
    data:
        The operations section as ``{operation_name: {field: value, ...}}``.

    Returns
    -------
    list[ValidationError]
        Empty if valid; otherwise one entry per problem found.
    """
    errors: list[ValidationError] = []
    all_known = _OPERATION_REQUIRED_FIELDS | _OPERATION_OPTIONAL_FIELDS

    for op_name, op_dict in data.items():
        section = f"operations.{op_name}"

        if not isinstance(op_dict, dict):
            errors.append(
                ValidationError(
                    field=section,
                    message="operation value must be a dict",
                )
            )
            continue

        # Required fields present.
        for req in _OPERATION_REQUIRED_FIELDS:
            if req not in op_dict:
                errors.append(
                    ValidationError(
                        field=f"{section}.{req}",
                        message=f"required field '{req}' is missing",
                    )
                )

        # read_only must be explicitly True.
        if "read_only" in op_dict and op_dict["read_only"] is not True:
            errors.append(
                ValidationError(
                    field=f"{section}.read_only",
                    message="read_only must be True; False is not permitted",
                )
            )

        # type == "log" operations must declare a log_type so the generic
        # dispatcher in BaseDeviceClient knows which vendor log channel to
        # query. Without this the pack would need hardcoded mapping tables
        # in client.py, which is exactly what the data-driven design
        # eliminates. Packs using other type values ("op", "cli", "get",
        # "rpc", etc.) are not subject to this rule — log_type is only
        # meaningful for the "log" dispatch shape.
        if op_dict.get("type") == _LOG_TYPE_TRIGGER and "log_type" not in op_dict:
            errors.append(
                ValidationError(
                    field=f"{section}.log_type",
                    message=(
                        "log-type operations must declare a 'log_type' field "
                        "naming the vendor log channel (e.g. 'traffic', "
                        "'threat', 'system')"
                    ),
                )
            )

        # required_model: absent OR the wildcard "*" OR a non-empty list
        # of strings. No other shapes accepted. Default is wildcard
        # (handled at dispatch time, not schema time).
        if "required_model" in op_dict:
            rm = op_dict["required_model"]
            valid_shape = (
                rm == "*"
                or (
                    isinstance(rm, list)
                    and len(rm) > 0
                    and all(isinstance(m, str) and m for m in rm)
                )
            )
            if not valid_shape:
                errors.append(
                    ValidationError(
                        field=f"{section}.required_model",
                        message=(
                            "required_model must be the wildcard '*' or a "
                            "non-empty list of model-name strings; got "
                            f"{rm!r}"
                        ),
                    )
                )

        # Unknown fields.
        errors.extend(_check_unknown_fields(op_dict, all_known, section))

    return errors
