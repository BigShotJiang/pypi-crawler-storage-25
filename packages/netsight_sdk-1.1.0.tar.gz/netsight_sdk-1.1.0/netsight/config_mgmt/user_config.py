"""User config directory and file resolution for NetSight.

Implements the search-order rule for the user's ``devices.yaml`` and any
other user-provided configuration:

    1. Explicit CLI flag (handled by the caller; not this module)
    2. ``$NETSIGHT_CONFIG_DIR`` env var
    3. Current working directory (``./config/``) — dev workflow override
    4. ``$XDG_CONFIG_HOME/netsight/`` — user default
    5. ``~/.config/netsight/`` — XDG fallback on POSIX, also on Windows
       when neither ``$NETSIGHT_CONFIG_DIR`` nor ``$XDG_CONFIG_HOME`` is
       set (users on Windows who want a different location should set
       ``$NETSIGHT_CONFIG_DIR``)

First-hit wins. No merging.

Also provides the cache directory resolver with an analogous search
order: ``$NETSIGHT_CACHE_DIR`` → ``$XDG_CACHE_HOME/netsight/`` →
``~/.cache/netsight/``.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)


def resolve_config_dir() -> Path:
    """Return the effective user config directory.

    Does NOT create the directory. Callers that need to write must
    ``mkdir(parents=True, exist_ok=True)`` themselves.

    Search order:

    1. ``$NETSIGHT_CONFIG_DIR`` env var
    2. Current working directory ``./config/`` (only if it already exists)
    3. ``$XDG_CONFIG_HOME/netsight/``
    4. ``~/.config/netsight/`` (final fallback)

    Returns
    -------
    Path
        The first directory in the search order that either exists or
        is the canonical default. Callers should check ``.exists()``
        before reading.
    """
    env = os.environ.get("NETSIGHT_CONFIG_DIR")
    if env:
        return Path(env).expanduser()

    local = Path.cwd() / "config"
    if local.is_dir():
        return local

    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg).expanduser() / "netsight"

    return Path.home() / ".config" / "netsight"


def resolve_config_file(name: str) -> Path | None:
    """Search every location for a named config file.

    Returns the first match in the search order, or ``None`` if no
    location contains the file.

    Parameters
    ----------
    name:
        Filename relative to the config directory root (e.g.
        ``"devices.yaml"`` or ``"packs.toml"``).

    Returns
    -------
    Path | None
        Absolute path to the found file, or ``None``.
    """
    # Use an explicit ordered list so callers can understand the priority
    # without reading resolve_config_dir's internal branching.
    candidates: list[Path] = []

    env = os.environ.get("NETSIGHT_CONFIG_DIR")
    if env:
        candidates.append(Path(env).expanduser() / name)

    candidates.append(Path.cwd() / "config" / name)

    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        candidates.append(Path(xdg).expanduser() / "netsight" / name)

    candidates.append(Path.home() / ".config" / "netsight" / name)

    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def resolve_cache_dir() -> Path:
    """Return the effective user cache directory.

    Search order: ``$NETSIGHT_CACHE_DIR`` → ``$XDG_CACHE_HOME/netsight/``
    → ``~/.cache/netsight/``.

    Returns
    -------
    Path
        Resolved cache directory path. The directory is NOT created
        by this function.
    """
    env = os.environ.get("NETSIGHT_CACHE_DIR")
    if env:
        return Path(env).expanduser()

    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg).expanduser() / "netsight"

    return Path.home() / ".cache" / "netsight"
