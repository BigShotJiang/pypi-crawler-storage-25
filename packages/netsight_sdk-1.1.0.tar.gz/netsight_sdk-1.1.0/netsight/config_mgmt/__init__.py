"""Config management subsystem for NetSight.

This package provides:

- :class:`~netsight.config_mgmt.store.ConfigStore` — abstract base class for
  resolved-config storage backends.
- :class:`~netsight.config_mgmt.store.FileConfigStore` — filesystem-backed
  implementation that persists resolved configs as JSON under ``.compiled/``.
- Schema validation helpers in :mod:`~netsight.config_mgmt.schemas` for each
  config section (connection, resilience, auth, metadata, operations).
- :class:`~netsight.config_mgmt.reader.ConfigReader` — reads TOML section
  files from a hierarchical config directory tree.
- :class:`~netsight.config_mgmt.merger.ConfigMerger` — merges level dicts
  produced by :class:`ConfigReader` into a single resolved config.
"""

from netsight.config_mgmt.merger import ConfigMerger
from netsight.config_mgmt.reader import ConfigReader
from netsight.config_mgmt.store import ConfigStore, FileConfigStore

__all__ = ["ConfigStore", "FileConfigStore", "ConfigReader", "ConfigMerger"]
