"""Config compiler for the NetSight hierarchical config system.

The :class:`ConfigCompiler` orchestrates reading, validating, merging,
and persisting resolved device configs.

Compile semantics (fail-closed)
--------------------------------
* Schema validation is run at every hierarchy level before merging.  A
  single error at any level causes the device-type to fail.
* Vendor-specific operation validation (if a validator is registered for
  that vendor) is run on the *merged* operations after all levels are
  merged.  Any error there also aborts the compile and prevents output.
* No partial or intermediate output is ever written.  If compilation
  fails the store is left unchanged.

Output format
-------------
The resolved JSON written by the store contains:

``compiled_at``
    ISO-8601 UTC timestamp of when the compile ran.
``source_files``
    Relative paths to every TOML file that contributed to this compile.
``connection``, ``resilience``, ``auth``, ``metadata``, ``operations``
    Merged config sections.
``_audit``
    A sub-dict with ``vendor``, ``model``, ``instance``, and
    ``compiled_by`` keys for downstream traceability.
"""

from __future__ import annotations

import datetime
import importlib.resources
import logging
import tomllib
from dataclasses import dataclass, field
from importlib.resources.abc import Traversable
from pathlib import Path
from typing import TYPE_CHECKING

from netsight.config_mgmt.merger import ConfigMerger
from netsight.config_mgmt.reader import ConfigReader
from netsight.config_mgmt.schemas import (
    ValidationError,
    validate_auth,
    validate_connection,
    validate_metadata,
    validate_operations,
    validate_resilience,
)
from netsight.config_mgmt.store import FileConfigStore
from netsight.config_mgmt.user_config import resolve_cache_dir

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from netsight.config_mgmt.validator import BaseOperationValidator


# ---------------------------------------------------------------------------
# CompileResult dataclass
# ---------------------------------------------------------------------------


@dataclass
class CompileResult:
    """Result of a vendor compilation run.

    Attributes
    ----------
    vendor:
        The vendor directory name that was compiled.
    success:
        ``True`` if compilation completed with no errors.
    errors:
        Accumulated :class:`~netsight.config_mgmt.schemas.ValidationError`
        instances from any model that failed.
    warnings:
        Non-fatal warnings collected during compilation.
    models_compiled:
        Names of models that compiled successfully.
    """

    vendor: str
    success: bool
    errors: list[ValidationError] = field(default_factory=list)
    warnings: list[ValidationError] = field(default_factory=list)
    models_compiled: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# ConfigCompiler
# ---------------------------------------------------------------------------


class ConfigCompiler:
    """Reads, validates, merges, and stores resolved device configs.

    The compiler operates in one of two mutually exclusive modes.

    **Legacy mode** (``config_dir=``) walks the in-tree
    ``config/vendors/<vendor>/<model>/`` directory hierarchy. This
    is the original behaviour used by the CLI's ``netsight config
    compile`` command and the dev MCP server's ``compile_dry_run`` tool.

    **Pack mode** (``pack_roots=``) takes a mapping of pack name to a
    :class:`importlib.resources.abc.Traversable` that points at the
    pack's bundled ``_data/`` directory. Used when the SDK discovers
    vendor packs via Python entry points and wants to validate their
    shipped configs without copying them to a filesystem tree.

    Parameters
    ----------
    config_dir:
        Legacy mode root: directory containing ``global/`` and all
        vendor sub-directories. Accepts a :class:`pathlib.Path` or
        string.
    pack_roots:
        Pack mode mapping: pack name → Traversable root of that pack's
        ``_data/`` directory.

    Raises
    ------
    ValueError
        If neither or both of ``config_dir`` and ``pack_roots`` are
        provided.
    """

    # Directories inside a vendor folder that are not model dirs.
    _VENDOR_NON_MODEL_DIRS: frozenset[str] = frozenset({"reference", "instances", "parsers"})

    # Name of the 'global' pseudo-vendor that should not be compiled.
    _GLOBAL_DIR = "global"

    def __init__(
        self,
        config_dir: Path | str | None = None,
        *,
        pack_roots: dict[str, Traversable] | None = None,
    ) -> None:
        if config_dir is None and pack_roots is None:
            raise ValueError(
                "ConfigCompiler requires either config_dir (legacy mode) "
                "or pack_roots (pack mode); both were None"
            )
        if config_dir is not None and pack_roots is not None:
            raise ValueError(
                "ConfigCompiler received both config_dir and pack_roots; "
                "pass exactly one"
            )

        if config_dir is not None:
            # Legacy mode — filesystem tree at config_dir.
            self._config_dir: Path = Path(config_dir)
            self._pack_roots: dict[str, Traversable] | None = None
        else:
            # Pack mode — per-pack Traversables. The sentinel _config_dir
            # is never walked; every legacy-mode method guards on
            # ``self._pack_roots is not None`` and raises before touching it.
            self._config_dir = Path(".")
            self._pack_roots = pack_roots

        self._reader: ConfigReader = ConfigReader(self._config_dir)
        cache_root = resolve_cache_dir() / "compiled"
        self._store: FileConfigStore = FileConfigStore(cache_dir=cache_root)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compile_vendor(self, vendor: str, validate_only: bool = False) -> CompileResult:
        """Compile all device types for *vendor*.

        Legacy-mode entry point. Raises :class:`ValueError` if the
        compiler was constructed in pack mode — use
        :meth:`compile_pack` instead.

        Parameters
        ----------
        vendor:
            Vendor directory name (e.g. ``"paloalto"``).
        validate_only:
            When ``True``, validation and merging run but no output is
            written to the store.

        Returns
        -------
        CompileResult
            Aggregated result for all device types under this vendor.
        """
        if self._pack_roots is not None:
            raise ValueError(
                "compile_vendor is a legacy-mode method; "
                "this compiler was constructed in pack mode — "
                "use compile_pack(name) instead"
            )

        # Security pre-check — run once per compiler instance.
        # If critical dependency findings exist, abort compilation.
        if not getattr(self, "_security_checked", False):
            try:
                from netsight.security.audit import AuditOrchestrator

                orch = AuditOrchestrator()
                report = orch.audit_deps_only()
                if orch.has_critical(report):
                    aborted = CompileResult(vendor=vendor, success=False)
                    for f in report["dependency_findings"]:
                        if f.get("severity") == "critical":
                            aborted.errors.append(
                                ValidationError(
                                    field="security.dependencies",
                                    message=f"{f['package']}: {f['issue']}",
                                )
                            )
                    return aborted
                self._security_checked = True
            except Exception:
                # Security module failure is non-fatal; continue compilation.
                pass

        result = CompileResult(vendor=vendor, success=True)
        vendor_dir = self._config_dir / vendor
        validator = self._get_vendor_validator(vendor)

        if not vendor_dir.is_dir():
            return result  # Nothing to compile; treat as vacuous success.

        models = self._discover_models(vendor_dir)

        for model in models:
            model_errors = self._compile_model(
                vendor=vendor,
                model=model,
                validator=validator,
                validate_only=validate_only,
            )
            if model_errors:
                result.errors.extend(model_errors)
                result.success = False
            else:
                result.models_compiled.append(model)

        return result

    def compile_all(self) -> dict[str, CompileResult]:
        """Compile every known unit (vendor in legacy mode, pack in pack mode).

        In legacy mode, iterates every sub-directory of the configured
        ``config_dir`` (excluding ``global/``) and calls
        :meth:`compile_vendor`. In pack mode, iterates ``self._pack_roots``
        and calls :meth:`compile_pack` for each (validate-only — pack-mode
        writes are a future phase).

        Returns
        -------
        dict[str, CompileResult]
            Mapping of unit name to its :class:`CompileResult`.
        """
        if self._pack_roots is not None:
            return {
                name: self.compile_pack(name, validate_only=True)
                for name in self._pack_roots
            }

        results: dict[str, CompileResult] = {}

        if not self._config_dir.is_dir():
            return results

        for entry in sorted(self._config_dir.iterdir()):
            if not entry.is_dir():
                continue
            if entry.name == self._GLOBAL_DIR:
                continue
            results[entry.name] = self.compile_vendor(entry.name)

        return results

    def compile_pack(
        self,
        name: str,
        validate_only: bool = True,
    ) -> CompileResult:
        """Compile the config tree of a single installed pack.

        Pack-mode entry point. The pack's ``_data/`` subtree is walked as
        a single-vendor tree: the pack root supplies ``metadata.toml``,
        ``auth.toml``, ``operations_catalog.toml``, and ``parsers/*.yaml``; any
        sub-directory of the pack root is treated as a model-variant
        level (equivalent to legacy ``<vendor>/<device_type>/``).

        Parameters
        ----------
        name:
            Pack registry key — must be present in ``self._pack_roots``.
        validate_only:
            When ``True`` (default), validation and merging run but
            nothing is written to the store.  When ``False``, the resolved
            JSON is written to the user cache dir under
            ``<cache_dir>/compiled/<name>/default/resolved.json``.

        Returns
        -------
        CompileResult
            Aggregated result for the pack. ``success=False`` if the
            pack is unknown, any section fails schema validation, the
            validator (if any) rejects a merged operation, or any
            parser spec fails to load.

        Raises
        ------
        ValueError
            If called on a compiler constructed in legacy mode.
        """
        if self._pack_roots is None:
            raise ValueError(
                "compile_pack is a pack-mode method; "
                "this compiler was constructed in legacy mode — "
                "use compile_vendor(vendor) instead"
            )

        result = CompileResult(vendor=name, success=True)

        if name not in self._pack_roots:
            result.success = False
            result.errors.append(
                ValidationError(
                    field="pack",
                    message=f"Pack {name!r} is not registered in this compiler",
                )
            )
            return result

        # Security pre-check — run once per compiler instance (mirrors
        # the legacy compile_vendor behaviour so pack-mode callers get
        # the same fail-closed guarantees at compile time).
        aborted = self._run_security_precheck(name)
        if aborted is not None:
            return aborted

        pack_root = self._pack_roots[name]

        if not pack_root.is_dir():
            result.success = False
            result.errors.append(
                ValidationError(
                    field="pack",
                    message=f"Pack {name!r} data_root is not a directory",
                )
            )
            return result

        # A pack's layout is flat: the pack root itself IS the vendor
        # level. A reader rooted at the pack lets us reuse the existing
        # read_level implementation unchanged.
        pack_reader = ConfigReader(pack_root)
        level = pack_reader.read_level(pack_root)

        section_validators = {
            "connection": validate_connection,
            "resilience": validate_resilience,
            "auth": validate_auth,
            "metadata": validate_metadata,
        }
        for section, validate_fn in section_validators.items():
            section_data = level.get(section, {})
            if section_data:
                result.errors.extend(validate_fn(section_data))

        ops_data = level.get("operations", {})
        if ops_data:
            result.errors.extend(validate_operations(ops_data))

        if result.errors:
            result.success = False
            return result

        # ------------------------------------------------------------------
        # Three-layer intersection (Phase 11 — catalog vs permissions split)
        #
        # Layer 1: pack catalog  — ops_data (already loaded above)
        # Layer 2: user allowlist — per-pack TOML in the user config dir
        # Layer 3: per-device narrowing — applied later in LocalBackend
        #
        # NOTE: The legacy compile_vendor / _compile_model path is NOT
        # touched here. The in-tree config/vendors/ tree was removed in
        # Phase 6; only the global/ pseudo-vendor remains, and it contains
        # no operations. The allowlist intersection therefore only runs in
        # pack mode (here), never in legacy mode.
        # ------------------------------------------------------------------
        from netsight.packs.allowlist import load_allowlist

        user = load_allowlist(name)

        # Enforce read_only ceiling and intersect with user allowlist.
        effective: dict[str, dict] = {}
        for op_name, op_config in ops_data.items():
            if op_name not in user.enabled:
                continue
            if not op_config.get("read_only", False):
                result.errors.append(
                    ValidationError(
                        field=f"allowlist.{name}.{op_name}",
                        message=(
                            f"Operation {op_name!r} is enabled in the user allowlist "
                            f"but is not read_only=true in the pack catalog. "
                            f"NetSight is read-only by design; non-read-only ops "
                            f"cannot be enabled."
                        ),
                    )
                )
                continue
            effective[op_name] = op_config

        if result.errors:
            result.success = False
            return result

        # Surface drift: user allowlist references ops that don't exist in catalog.
        orphaned = user.enabled - set(ops_data)
        if orphaned:
            result.warnings.append(
                ValidationError(
                    field=f"allowlist.{name}",
                    message=(
                        f"Allowlist references {len(orphaned)} operation(s) not in "
                        f"the pack catalog: {sorted(orphaned)}"
                    ),
                )
            )

        # Replace the full catalog with the effective (gated) set so that
        # parser-spec resolution only runs for ops the user has enabled.
        ops_data = effective
        level["operations"] = effective

        # Vendor-specific operation validator is sourced from the pack
        # registry in pack mode (no hardcoded "paloalto" branch).
        from netsight.packs.registry import pack_registry

        pack_info = pack_registry.get(name=name) if pack_registry.has(name=name) else None

        validator = None
        if pack_info is not None and pack_info.validator_class is not None:
            validator = pack_info.validator_class()

        if validator is not None:
            for op_name, op_config in ops_data.items():
                result.errors.extend(
                    validator.validate_operation(op_name, op_config)
                )
            if result.errors:
                result.success = False
                return result

        # Resolve parser specs relative to the pack root (via
        # importlib.resources, not a filesystem path).
        self._resolve_parser_specs_from_pack(pack_root, ops_data, result.errors)
        if result.errors:
            result.success = False
            return result

        # Write the resolved payload to the user cache dir when the caller
        # requests a real compile (not a dry-run validation).
        if not validate_only:
            compiled_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
            source_files = self._list_pack_source_files(pack_root)

            resolved: dict = {
                "compiled_at": compiled_at,
                "source_files": source_files,
                "metadata": level.get("metadata", {}),
                "connection": level.get("connection", {}),
                "auth": level.get("auth", {}),
                "resilience": level.get("resilience", {}),
                "operations": effective,
                "_audit": {
                    "vendor": pack_info.vendor if pack_info is not None else "unknown",
                    "model": "default",
                    "instance": None,
                    "compiled_by": "ConfigCompiler.compile_pack",
                    "pack_name": name,
                    "pack_version": pack_info.version if pack_info is not None else "unknown",
                },
            }
            # Packs do not have sub-model trees yet; all writes use
            # model="default" and instance="resolved".  The store produces:
            #   <cache_dir>/compiled/<name>/default/resolved.json
            self._store.put_resolved(name, "default", "resolved", resolved)

        result.models_compiled.append(name)
        return result

    def _run_security_precheck(self, name: str) -> "CompileResult | None":
        """Run the one-shot security pre-check.

        Mirrors the inline check in :meth:`compile_vendor` so pack-mode
        callers get the same compile-time dependency-audit guarantees.
        Returns an aborted :class:`CompileResult` if critical findings
        exist, or ``None`` if the pre-check passed (or the security
        module itself failed — non-fatal).

        Parameters
        ----------
        name:
            Unit name to embed in the aborted result for traceability.
        """
        if getattr(self, "_security_checked", False):
            return None
        try:
            from netsight.security.audit import AuditOrchestrator

            orch = AuditOrchestrator()
            report = orch.audit_deps_only()
            if orch.has_critical(report):
                aborted = CompileResult(vendor=name, success=False)
                for f in report["dependency_findings"]:
                    if f.get("severity") == "critical":
                        aborted.errors.append(
                            ValidationError(
                                field="security.dependencies",
                                message=f"{f['package']}: {f['issue']}",
                            )
                        )
                return aborted
            self._security_checked = True
        except Exception:  # noqa: BLE001 — security failure is non-fatal here
            pass
        return None

    def _list_pack_source_files(self, pack_root: Traversable) -> list[str]:
        """Return relative paths of all config files a pack compile consumed.

        Walks the pack root Traversable looking for the standard files
        (``metadata.toml``, ``auth.toml``, ``operations_catalog.toml``, etc.
        plus parser specs under ``parsers/``). Missing files are simply not
        listed — an empty return is legal (e.g. for a pack with no ops).

        Parameters
        ----------
        pack_root:
            Traversable rooted at the pack's data directory.

        Returns
        -------
        list[str]
            Sorted list of relative file paths that exist in the pack root.
        """
        result: list[str] = []
        for fname in (
            "metadata.toml",
            "auth.toml",
            "connection.toml",
            "resilience.toml",
            "operations_catalog.toml",
            "validator_schema.toml",
        ):
            try:
                if pack_root.joinpath(fname).is_file():
                    result.append(fname)
            except Exception:  # noqa: BLE001 — Traversable.is_file can raise
                pass
        parsers_dir = pack_root.joinpath("parsers")
        try:
            if parsers_dir.is_dir():
                for child in parsers_dir.iterdir():
                    try:
                        if child.is_file() and child.name.endswith(".yaml"):
                            result.append(f"parsers/{child.name}")
                    except Exception:  # noqa: BLE001
                        pass
        except Exception:  # noqa: BLE001 — Traversable.iterdir can raise
            pass
        return sorted(result)

    def _resolve_parser_specs_from_pack(
        self,
        pack_root: Traversable,
        operations: dict,
        errors: list,
    ) -> None:
        """Load parser specs from a pack's ``_data`` Traversable.

        Mirrors :meth:`_resolve_parser_specs` but sources the YAML text
        via :meth:`Traversable.read_text` so it works on both on-disk
        packs (editable installs) and importlib.resources handles
        (wheel-backed installs).

        Parameters
        ----------
        pack_root:
            Traversable rooted at the pack's data directory.
        operations:
            Mutable mapping of operation name → operation config dict.
            Mutated in place with ``parser_resolved`` entries on success.
        errors:
            Accumulator list; any spec errors are appended here.
        """
        from netsight.parsers.spec import (
            load_parser_spec_from_text,
            validate_parser_spec,
        )

        for op_name, op_config in list(operations.items()):
            spec_ref = op_config.get("parser_spec")
            if not spec_ref:
                continue

            try:
                spec_resource = pack_root.joinpath(spec_ref)
            except Exception as exc:  # noqa: BLE001 — surface as a validation err
                errors.append(
                    ValidationError(
                        field=f"operations.{op_name}.parser_spec",
                        message=f"Failed to resolve pack resource: {exc}",
                    )
                )
                continue

            if not spec_resource.is_file():
                errors.append(
                    ValidationError(
                        field=f"operations.{op_name}.parser_spec",
                        message=f"Parser spec file not found in pack: {spec_ref}",
                    )
                )
                continue

            try:
                yaml_text = spec_resource.read_text(encoding="utf-8")
                parser_spec = load_parser_spec_from_text(
                    yaml_text,
                    source_ref=spec_ref,
                )
            except Exception as exc:  # noqa: BLE001 — surface as a validation err
                errors.append(
                    ValidationError(
                        field=f"operations.{op_name}.parser_spec",
                        message=f"Failed to load: {exc}",
                    )
                )
                continue

            spec_errors = validate_parser_spec(parser_spec)
            if spec_errors:
                for spec_err in spec_errors:
                    msg = (
                        str(spec_err)
                        if not isinstance(spec_err, dict)
                        else spec_err.get("message", str(spec_err))
                    )
                    errors.append(
                        ValidationError(
                            field=f"operations.{op_name}.parser_spec",
                            message=msg,
                        )
                    )
                continue

            op_config["parser_resolved"] = parser_spec

    def _get_vendor_validator(self, vendor: str) -> "BaseOperationValidator | None":
        """Return a vendor-specific operation validator, or ``None``.

        Legacy-mode validators are no longer registered via the in-tree
        plugin system.  Pack-mode validators are sourced from
        ``pack_registry.get(name).validator_class`` inside
        :meth:`compile_pack`.  This method always returns ``None`` so
        that ``compile_vendor`` (called only for whatever remains under
        ``config/vendors/`` — typically just ``global/``) continues to
        work without error.

        Parameters
        ----------
        vendor:
            Vendor directory name.

        Returns
        -------
        BaseOperationValidator or None
        """
        return None

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_core_defaults() -> dict:
        """Load the innermost default layer from the in-package TOML files.

        Reads ``connection.toml``, ``auth.toml``, and ``resilience.toml``
        from ``netsight.config_mgmt._defaults`` via
        :func:`importlib.resources.files` so the method works for both
        editable installs (on-disk) and wheel-backed installs
        (``importlib.resources`` handle).

        The returned dict has the same shape as
        :meth:`ConfigReader._empty_level` so it can be prepended to the
        ``levels`` list passed to :meth:`ConfigMerger.merge_all`.

        Returns
        -------
        dict
            Level dict with defaults pre-filled for ``connection``,
            ``auth``, and ``resilience`` sections.  Operations and
            ``remove_operations`` are always empty — defaults do not add
            operations.
        """
        result: dict = {
            "connection": {},
            "resilience": {},
            "auth": {},
            "metadata": {},
            "operations": {},
            "remove_operations": [],
        }

        defaults_pkg = importlib.resources.files("netsight.config_mgmt._defaults")
        for section in ("connection", "auth", "resilience"):
            resource = defaults_pkg / f"{section}.toml"
            try:
                text = resource.read_text(encoding="utf-8")
                parsed = tomllib.loads(text)
                result[section] = parsed.get(section, {})
            except Exception:  # noqa: BLE001
                logger.warning(
                    "Could not load core default %s.toml; section will be empty",
                    section,
                )

        return result

    def _discover_models(self, vendor_dir: Path) -> list[str]:
        """Return model sub-directory names under *vendor_dir*.

        Excludes any directory whose name is in
        :attr:`_VENDOR_NON_MODEL_DIRS`.
        """
        return sorted(
            entry.name
            for entry in vendor_dir.iterdir()
            if entry.is_dir() and entry.name not in self._VENDOR_NON_MODEL_DIRS
        )

    def _resolve_parser_specs(
        self, vendor: str, operations: dict, errors: list
    ) -> None:
        """Load and embed parser specs into operations.

        Mutates *operations* in place: for each operation that declares a
        ``parser_spec`` path, loads the YAML file, validates it, and stores
        the result in ``op_config["parser_resolved"]``.  Appends
        :class:`ValidationError` instances to *errors* if any spec is missing
        or invalid.

        Parameters
        ----------
        vendor:
            Vendor directory name used to locate the spec file relative to the
            config root.
        operations:
            Mutable mapping of operation name to operation config dict.
        errors:
            Accumulator list; any spec errors are appended here.
        """
        from netsight.parsers.spec import load_parser_spec, validate_parser_spec

        vendor_dir = self._config_dir / vendor

        for op_name, op_config in list(operations.items()):
            spec_ref = op_config.get("parser_spec")
            if not spec_ref:
                continue

            spec_path = vendor_dir / spec_ref
            try:
                parser_spec = load_parser_spec(spec_path)
            except Exception as e:
                errors.append(
                    ValidationError(
                        field=f"operations.{op_name}.parser_spec",
                        message=f"Failed to load: {e}",
                    )
                )
                continue

            spec_errors = validate_parser_spec(parser_spec)
            if spec_errors:
                for spec_err in spec_errors:
                    msg = (
                        str(spec_err)
                        if not isinstance(spec_err, dict)
                        else spec_err.get("message", str(spec_err))
                    )
                    errors.append(
                        ValidationError(
                            field=f"operations.{op_name}.parser_spec",
                            message=msg,
                        )
                    )
                continue

            op_config["parser_resolved"] = parser_spec

    def _compile_model(
        self,
        vendor: str,
        model: str,
        validator: "BaseOperationValidator | None",
        validate_only: bool,
    ) -> list[ValidationError]:
        """Compile a single vendor/model combination.

        Steps performed:

        1. Read all hierarchy levels via :meth:`ConfigReader.read_vendor_tree`.
        2. Validate each level's sections using the schema validators.
        3. Validate each level's operations using
           :func:`~netsight.config_mgmt.schemas.validate_operations`.
        4. Fail immediately if any schema errors are found (fail-closed).
        5. Merge all levels with :meth:`ConfigMerger.merge_all`.
        6. Run the vendor-specific operation validator on merged ops (if
           a validator was provided).
        7. Fail if vendor validation found errors.
        8. Build the resolved JSON payload and write via the store (unless
           *validate_only* is ``True``).
        9. Compile instances under ``instances/`` if the directory exists.

        Parameters
        ----------
        vendor, model:
            Hierarchy identifiers.
        validator:
            Optional vendor-specific validator.
        validate_only:
            Suppresses all store writes when ``True``.

        Returns
        -------
        list[ValidationError]
            Empty on success; non-empty on failure (no output written).
        """
        errors: list[ValidationError] = []

        # --- Step 1: read all levels (core defaults are the innermost base). ---
        levels = [self._load_core_defaults()] + self._reader.read_vendor_tree(vendor, model)

        # --- Steps 2 + 3: validate each level's sections. ---
        section_validators = {
            "connection": validate_connection,
            "resilience": validate_resilience,
            "auth": validate_auth,
            "metadata": validate_metadata,
        }

        for level_idx, level in enumerate(levels):
            for section, validate_fn in section_validators.items():
                section_data = level.get(section, {})
                if section_data:
                    errors.extend(validate_fn(section_data))

            ops_data = level.get("operations", {})
            if ops_data:
                errors.extend(validate_operations(ops_data))

        # --- Step 4: fail-closed on schema errors. ---
        if errors:
            return errors

        # --- Step 5: merge all levels. ---
        merged = ConfigMerger.merge_all(levels)

        # --- Steps 6 + 7: vendor-specific operation validation. ---
        if validator is not None:
            for op_name, op_config in merged.get("operations", {}).items():
                errors.extend(validator.validate_operation(op_name, op_config))

            if errors:
                return errors

        # --- Step 7b: resolve parser specs (must come after merge). ---
        self._resolve_parser_specs(vendor, merged.get("operations", {}), errors)
        if errors:
            return errors

        # --- Step 8: build resolved payload and write. ---
        if not validate_only:
            compiled_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
            source_files = self._reader.get_source_files(vendor, model)

            resolved: dict = {
                "compiled_at": compiled_at,
                "source_files": source_files,
                **merged,
                "_audit": {
                    "vendor": vendor,
                    "model": model,
                    "instance": None,
                    "compiled_by": "ConfigCompiler",
                },
            }
            # Write to the sentinel instance name "resolved" so that
            # FileConfigStore.get_resolved(vendor, model) (no instance)
            # finds this file as the model default (resolved.json).
            self._store.put_resolved(vendor, model, "resolved", resolved)

        # --- Step 9: compile instances if the instances/ dir exists. ---
        instances_dir = self._config_dir / vendor / model / "instances"
        if instances_dir.is_dir():
            for instance_entry in sorted(instances_dir.iterdir()):
                if not instance_entry.is_dir():
                    continue
                instance_errors = self._compile_instance(
                    vendor=vendor,
                    model=model,
                    instance=instance_entry.name,
                    validator=validator,
                    validate_only=validate_only,
                )
                errors.extend(instance_errors)

        return errors

    def _compile_instance(
        self,
        vendor: str,
        model: str,
        instance: str,
        validator: "BaseOperationValidator | None",
        validate_only: bool,
    ) -> list[ValidationError]:
        """Compile a single vendor/model/instance combination.

        Follows the same fail-closed pattern as :meth:`_compile_model`
        but produces an instance-scoped resolved JSON rather than the
        model default.

        Parameters
        ----------
        vendor, model, instance:
            Hierarchy identifiers.
        validator:
            Optional vendor-specific validator.
        validate_only:
            Suppresses all store writes when ``True``.

        Returns
        -------
        list[ValidationError]
            Empty on success; non-empty on failure.
        """
        errors: list[ValidationError] = []

        levels = [self._load_core_defaults()] + self._reader.read_vendor_tree(
            vendor, model, instance
        )

        section_validators = {
            "connection": validate_connection,
            "resilience": validate_resilience,
            "auth": validate_auth,
            "metadata": validate_metadata,
        }

        for level in levels:
            for section, validate_fn in section_validators.items():
                section_data = level.get(section, {})
                if section_data:
                    errors.extend(validate_fn(section_data))

            ops_data = level.get("operations", {})
            if ops_data:
                errors.extend(validate_operations(ops_data))

        if errors:
            return errors

        merged = ConfigMerger.merge_all(levels)

        if validator is not None:
            for op_name, op_config in merged.get("operations", {}).items():
                errors.extend(validator.validate_operation(op_name, op_config))

            if errors:
                return errors

        if not validate_only:
            compiled_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
            source_files = self._reader.get_source_files(vendor, model, instance)

            resolved: dict = {
                "compiled_at": compiled_at,
                "source_files": source_files,
                **merged,
                "_audit": {
                    "vendor": vendor,
                    "model": model,
                    "instance": instance,
                    "compiled_by": "ConfigCompiler",
                },
            }
            self._store.put_resolved(vendor, model, instance, resolved)

        return errors
