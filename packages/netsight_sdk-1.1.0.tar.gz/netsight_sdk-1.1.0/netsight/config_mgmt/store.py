"""Config store abstraction and file-based implementation.

The :class:`ConfigStore` ABC defines a vendor/model/instance hierarchy
for storing and retrieving resolved (compiled) device configs.

:class:`FileConfigStore` persists configs as indented JSON files under a
``.compiled/`` directory tree.  The path structure is::

    <base>/.compiled/<vendor>/<model>/<instance>.json
    <base>/.compiled/<vendor>/<model>/resolved.json   ← model default

When an instance-level file is missing, :meth:`FileConfigStore.get_resolved`
falls back to the model-level ``resolved.json`` so that a vendor-wide
default config remains usable even if no per-instance override has been written.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path


class ConfigStore(ABC):
    """Abstract base class for resolved-config storage backends.

    All identifiers (vendor, model, instance) are plain strings.
    Implementations decide the physical storage representation.
    """

    @abstractmethod
    def get_resolved(self, vendor: str, model: str, instance: str | None = None) -> dict:
        """Return the resolved config for the given hierarchy level.

        Parameters
        ----------
        vendor:
            Vendor identifier (e.g. ``"paloalto"``).
        model:
            Model identifier (e.g. ``"pa-vm"``).
        instance:
            Optional instance name.  When ``None`` the model-level
            config is returned.

        Returns
        -------
        dict
            The stored config as a plain Python dictionary.

        Raises
        ------
        FileNotFoundError
            If no config exists at the requested level or its fallback.
        """

    @abstractmethod
    def put_resolved(self, vendor: str, model: str, instance: str, data: dict) -> None:
        """Persist *data* at the given vendor/model/instance location.

        Parameters
        ----------
        vendor:
            Vendor identifier.
        model:
            Model identifier.
        instance:
            Instance name.  Use the model identifier itself to store a
            model-level default.
        data:
            Plain Python dictionary to serialise and store.
        """

    @abstractmethod
    def list_vendors(self) -> list[str]:
        """Return sorted list of all vendor identifiers known to the store."""

    @abstractmethod
    def list_models(self, vendor: str) -> list[str]:
        """Return sorted list of model identifiers for *vendor*."""

    def list_device_types(self, vendor: str) -> list[str]:
        """Deprecated alias for :meth:`list_models`. Use ``list_models`` instead."""
        import warnings
        warnings.warn(
            "list_device_types is deprecated; use list_models instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.list_models(vendor)

    @abstractmethod
    def list_instances(self, vendor: str, model: str) -> list[str]:
        """Return sorted list of instance names for the given vendor/model.

        The model-level sentinel file ``resolved.json`` is excluded.
        """


# Subdirectory names that can appear under a vendor's config tree but are
# NOT model dirs. Kept in sync with ``ConfigCompiler._VENDOR_NON_MODEL_DIRS``
# so that source-side discovery and compiled-tree listing stay consistent.
# If an old compile leaves a stale ``.compiled/<vendor>/parsers/`` directory
# behind, ``list_models`` must still exclude it.
_NON_MODEL_SUBDIRS: frozenset[str] = frozenset({"reference", "instances", "parsers"})


class FileConfigStore(ConfigStore):
    """Filesystem-backed config store.

    Configs are stored as ``indent=2`` JSON files under::

        <base_dir>/.compiled/<vendor>/<device_type>/<instance>.json

    A device-type-level fallback file ``resolved.json`` is used when no
    instance-specific file exists.

    Parameters
    ----------
    base_dir:
        Root directory of the project (or any directory whose ``.compiled/``
        sub-tree should be used for storage).  Mutually exclusive with
        *cache_dir*.
    cache_dir:
        Keyword-only.  When supplied the store writes directly into
        *cache_dir* without appending a ``.compiled/`` suffix — the
        caller is responsible for supplying the full target path (e.g.
        ``resolve_cache_dir() / "compiled"``).  Mutually exclusive with
        *base_dir*.

    Raises
    ------
    ValueError
        If both *base_dir* and *cache_dir* are provided.
    """

    _MODEL_SENTINEL = "resolved.json"

    def __init__(
        self,
        base_dir: Path | str | None = None,
        *,
        cache_dir: Path | None = None,
    ) -> None:
        if base_dir is not None and cache_dir is not None:
            raise ValueError(
                "FileConfigStore received both base_dir and cache_dir; pass exactly one"
            )
        if cache_dir is not None:
            self._base: Path = Path(cache_dir)
        elif base_dir is not None:
            self._base = Path(base_dir) / ".compiled"
        else:
            raise ValueError(
                "FileConfigStore requires either base_dir or cache_dir"
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolved_path(self, vendor: str, model: str, instance: str | None = None) -> Path:
        """Return the filesystem path for a config file.

        When *instance* is ``None``, returns the model-level
        ``resolved.json`` path.  Otherwise returns
        ``<vendor>/<model>/<instance>.json``.
        """
        if instance is None:
            return self._base / vendor / model / self._MODEL_SENTINEL
        return self._base / vendor / model / f"{instance}.json"

    # ------------------------------------------------------------------
    # ConfigStore interface
    # ------------------------------------------------------------------

    def get_resolved(self, vendor: str, model: str, instance: str | None = None) -> dict:
        """Read and return a resolved config dict.

        If *instance* is provided and its file does not exist, falls back
        to the model-level ``resolved.json``.

        Raises
        ------
        FileNotFoundError
            If neither the instance file nor the model fallback exists.
        """
        primary = self._resolved_path(vendor, model, instance)
        if primary.exists():
            return json.loads(primary.read_text(encoding="utf-8"))

        # Fall back to model level when instance file is missing.
        if instance is not None:
            fallback = self._resolved_path(vendor, model, instance=None)
            if fallback.exists():
                return json.loads(fallback.read_text(encoding="utf-8"))

        raise FileNotFoundError(
            f"No resolved config found for vendor={vendor!r}, "
            f"model={model!r}, instance={instance!r}"
        )

    def put_resolved(self, vendor: str, model: str, instance: str, data: dict) -> None:
        """Write *data* as JSON to the instance config file.

        Parent directories are created automatically.
        """
        path = self._resolved_path(vendor, model, instance)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def list_vendors(self) -> list[str]:
        """Return sorted list of vendor sub-directory names under ``.compiled/``."""
        if not self._base.exists():
            return []
        return sorted(p.name for p in self._base.iterdir() if p.is_dir())

    def list_models(self, vendor: str) -> list[str]:
        """Return sorted list of model sub-directory names for *vendor*.

        Subdirectories whose names appear in :data:`_NON_MODEL_SUBDIRS`
        (``parsers``, ``reference``, ``instances``) are excluded — they are
        reserved for other purposes and must never be mistaken for models
        by downstream consumers like the MCP server or the parser engine's
        operation lookup.
        """
        vendor_dir = self._base / vendor
        if not vendor_dir.exists():
            return []
        return sorted(
            p.name
            for p in vendor_dir.iterdir()
            if p.is_dir() and p.name not in _NON_MODEL_SUBDIRS
        )

    def list_instances(self, vendor: str, model: str) -> list[str]:
        """Return sorted list of instance stems in the model directory.

        ``resolved.json`` is excluded because it represents the model
        default, not a named instance.
        """
        model_dir = self._base / vendor / model
        if not model_dir.exists():
            return []
        return sorted(
            p.stem
            for p in model_dir.iterdir()
            if p.is_file()
            and p.suffix == ".json"
            and p.name != self._MODEL_SENTINEL
        )
