"""Abstract base class for vendor-specific operation validators.

Each vendor plugin may supply a concrete :class:`BaseOperationValidator`
subclass that knows how to inspect operation commands and metadata for
correctness, safety, and vendor-specific constraints.

The concrete :meth:`validate_operation` method orchestrates validation
against categories, types, and the vendor-specific command grammar.
Subclasses provide the implementation details via the abstract methods.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from netsight.config_mgmt.schemas import ValidationError


class BaseOperationValidator(ABC):
    """Abstract base for vendor-specific operation validators.

    Subclasses must implement :meth:`validate_command`,
    :meth:`get_valid_categories`, and :meth:`get_valid_types`.

    The :meth:`validate_operation` concrete method combines all checks
    into a single pass that callers can invoke without knowing the
    vendor-specific rules.
    """

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @abstractmethod
    def validate_command(
        self, operation_name: str, command: str, op_type: str
    ) -> list[ValidationError]:
        """Validate the raw command string for a single operation.

        Implementations perform vendor-specific checks (e.g. XML parsing
        for PAN-OS, CLI syntax for IOS).

        Parameters
        ----------
        operation_name:
            The key under which this operation is registered (used to
            populate :attr:`ValidationError.field`).
        command:
            The raw command string from the config.
        op_type:
            The operation type string (e.g. ``"op"``, ``"log"``).

        Returns
        -------
        list[ValidationError]
            Empty if the command is valid; otherwise one entry per problem.
        """

    @abstractmethod
    def get_valid_categories(self) -> list[str]:
        """Return the list of category strings accepted by this validator.

        Returns
        -------
        list[str]
            Accepted category values (e.g. ``["system", "network", ...]``).
        """

    @abstractmethod
    def get_valid_types(self) -> list[str]:
        """Return the list of operation-type strings accepted by this validator.

        Returns
        -------
        list[str]
            Accepted type values (e.g. ``["op", "log"]``).
        """

    # ------------------------------------------------------------------
    # Optional hook (default returns None)
    # ------------------------------------------------------------------

    def get_command_template(self, category: str) -> str | None:
        """Return an example command template for *category*, or ``None``.

        Subclasses may override this to provide IDE/tooling hints.  The
        default implementation always returns ``None``.

        Parameters
        ----------
        category:
            A category string (e.g. ``"system"``).

        Returns
        -------
        str or None
            A template string, or ``None`` if no template is available.
        """
        return None

    # ------------------------------------------------------------------
    # Concrete validation orchestration
    # ------------------------------------------------------------------

    def validate_operation(
        self, operation_name: str, op_config: dict
    ) -> list[ValidationError]:
        """Validate a single operation's config dict.

        Checks performed (in order):

        1. ``type`` must be in :meth:`get_valid_types`.
        2. ``category`` must be in :meth:`get_valid_categories`.
        3. ``command`` is passed to :meth:`validate_command`.

        All errors are collected and returned together.

        Parameters
        ----------
        operation_name:
            Key used to identify the operation in error ``field`` paths.
        op_config:
            The operation's config dict (from the merged config).

        Returns
        -------
        list[ValidationError]
            Empty if valid; otherwise one entry per problem found.
        """
        errors: list[ValidationError] = []
        prefix = f"operations.{operation_name}"

        # 1. Validate type.
        op_type: str = op_config.get("type", "")
        if op_type not in self.get_valid_types():
            errors.append(
                ValidationError(
                    field=f"{prefix}.type",
                    message=(
                        f"invalid type {op_type!r}; "
                        f"valid types are {self.get_valid_types()}"
                    ),
                )
            )

        # 2. Validate category.
        category: str = op_config.get("category", "")
        if category not in self.get_valid_categories():
            errors.append(
                ValidationError(
                    field=f"{prefix}.category",
                    message=(
                        f"invalid category {category!r}; "
                        f"valid categories are {self.get_valid_categories()}"
                    ),
                )
            )

        # 3. Validate the command itself.
        command: str = op_config.get("command", "")
        errors.extend(self.validate_command(operation_name, command, op_type))

        return errors
