"""Introspector — walks classes and registries to extract operation metadata.

This is the core module that all documentation surfaces call:
CLI help, Swagger, GraphQL, MCP server, AI tool definitions.

Type mapping for JSON Schema generation:
    str   -> "string"
    int   -> "integer"
    float -> "number"
    bool  -> "boolean"
    list  -> "array"
    dict  -> "object"

Parameters whose default is None are treated as required.
"""

from __future__ import annotations

import inspect
from typing import Any

from netsight.docs.decorators import OperationMeta

_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


class Introspector:
    """Extracts operation metadata from decorated classes.

    All methods are static — this class is used as a namespace.
    """

    @staticmethod
    def extract_operations(cls: type) -> list[OperationMeta]:
        """Extract all @operation-decorated methods from a class.

        Uses inspect.getmembers to find all callable members that carry
        an ``_operation_meta`` attribute attached by the @operation decorator.

        Args:
            cls: The class to inspect.

        Returns:
            List of OperationMeta instances, one per decorated method.
            Order matches inspect.getmembers (alphabetical by member name).
        """
        ops: list[OperationMeta] = []
        for _name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
            meta = getattr(method, "_operation_meta", None)
            if meta is not None:
                ops.append(meta)
        return ops

    @staticmethod
    def to_tool_definitions(ops: list[OperationMeta]) -> list[dict[str, Any]]:
        """Convert a list of OperationMeta to AI tool definition dicts.

        Each tool definition follows the format expected by AI tool-use APIs:
        name, description, parameters (JSON Schema object), and optional
        tags, related_operations, and investigation_hint fields.

        Parameters with default=None are treated as required; all others
        are optional.

        Args:
            ops: List of OperationMeta to convert.

        Returns:
            List of tool definition dicts ready for JSON serialisation.
        """
        tools: list[dict[str, Any]] = []
        for op in ops:
            properties: dict[str, Any] = {}
            required: list[str] = []

            for param_name, param in op.parameters.items():
                json_type = _TYPE_MAP.get(param.param_type, "string")
                properties[param_name] = {
                    "type": json_type,
                    "description": param.description,
                }
                if param.default is None:
                    required.append(param_name)

            tool: dict[str, Any] = {
                "name": op.name,
                "description": op.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            }
            if op.tags:
                tool["tags"] = op.tags
            if op.related_operations:
                tool["related_operations"] = op.related_operations
            if op.investigation_hint:
                tool["investigation_hint"] = op.investigation_hint

            tools.append(tool)
        return tools

    @staticmethod
    def extract_from_compiled(resolved_config: dict[str, Any]) -> list[OperationMeta]:
        """Extract OperationMeta from a compiled vendor config.

        Parses the ``operations`` mapping of a resolved (compiled) vendor
        config dict and constructs an :class:`OperationMeta` for each entry.
        Fields not present in the config default to empty strings.

        Args:
            resolved_config: A compiled vendor config dict as returned by
                :meth:`~netsight.config_mgmt.store.FileConfigStore.get_resolved`.

        Returns:
            List of :class:`OperationMeta` instances, one per operation key.
        """
        ops: list[OperationMeta] = []
        for op_name, op_config in resolved_config.get("operations", {}).items():
            ops.append(OperationMeta(
                name=op_name,
                description=op_config.get("description", ""),
                category=op_config.get("category", ""),
            ))
        return ops

    @staticmethod
    def to_json_schema(ops: list[OperationMeta]) -> dict[str, Any]:
        """Wrap tool definitions in a JSON Schema document envelope.

        Args:
            ops: List of OperationMeta to convert.

        Returns:
            Dict of the form ``{"tools": [...]}``.
        """
        return {"tools": Introspector.to_tool_definitions(ops)}

    @staticmethod
    def parser_spec_to_json_schema(spec: dict) -> dict:
        """Convert a parser spec to a JSON Schema for output documentation.

        Args:
            spec: A loaded parser spec dict.

        Returns:
            JSON Schema dict.
        """
        type_map = {
            "str": "string",
            "int": "integer",
            "float": "number",
            "bool": "boolean",
            "list": "array",
            "ip": "string",
            "cidr": "string",
            "mac": "string",
        }

        properties = {}
        required = []

        for field_name, field_def in spec.get("fields", {}).items():
            field_type = field_def.get("type", "str")
            json_type = type_map.get(field_type, "string")
            properties[field_name] = {
                "type": json_type,
                "description": field_def.get("description", ""),
            }
            if field_def.get("required", False):
                required.append(field_name)

        item_schema = {
            "type": "object",
            "properties": properties,
            "required": required,
        }

        if spec.get("output_shape") == "list":
            return {"type": "array", "items": item_schema}
        return item_schema
