"""Usage patterns — common workflows encoded as structured guides.

Patterns teach AI agents and users the preferred sequences of operations
for achieving common investigation and monitoring goals.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PatternStep:
    """A single step in a usage pattern.

    Args:
        operation: Operation name to execute.
        description: What this step does.
    """

    operation: str
    description: str


@dataclass
class Pattern:
    """A documented usage pattern.

    Args:
        name: Pattern name (e.g. 'device-health-check').
        description: What this pattern accomplishes.
        steps: Ordered list of steps.
    """

    name: str
    description: str
    steps: list[PatternStep]


def get_builtin_patterns() -> list[Pattern]:
    """Return the built-in usage patterns.

    Returns:
        List of Pattern objects covering common investigation workflows.
    """
    return [
        Pattern(
            name="device-health-check",
            description="Assess overall device health",
            steps=[
                PatternStep("show_system_info", "Get system information and uptime"),
                PatternStep("show_ha_status", "Check high-availability state"),
                PatternStep("show_interfaces", "Verify interface status"),
                PatternStep("show_session_info", "Check session counts and resource usage"),
            ],
        ),
        Pattern(
            name="route-investigation",
            description="Troubleshoot routing issues",
            steps=[
                PatternStep("show_routing_table", "Get current routing table"),
                PatternStep("show_arp_table", "Check ARP resolution"),
                PatternStep("show_interfaces", "Verify interface status"),
            ],
        ),
        Pattern(
            name="security-audit",
            description="Review security posture",
            steps=[
                PatternStep("show_system_info", "Identify device and firmware version"),
                PatternStep("show_interfaces", "Map network zones"),
                PatternStep("show_session_info", "Check active sessions"),
            ],
        ),
        Pattern(
            name="change-detection",
            description="Detect what changed since last snapshot",
            steps=[
                PatternStep("show_system_info", "Capture current state"),
                PatternStep("show_routing_table", "Capture routing table"),
                PatternStep("show_interfaces", "Capture interface state"),
            ],
        ),
        Pattern(
            name="log-investigation",
            description="Investigate a security event",
            steps=[
                PatternStep("get_threat_logs", "Pull threat logs filtered by criteria"),
                PatternStep("get_traffic_logs", "Correlate with traffic logs"),
                PatternStep("show_system_info", "Identify the source device"),
            ],
        ),
    ]
