"""Export utilities — serialize operation metadata to various formats.

Provides high-level functions to build a complete catalog (tools +
patterns + relations) and serialise it to JSON.
"""

from __future__ import annotations

import json
from typing import Any

from netsight.docs.introspect import Introspector, OperationMeta
from netsight.docs.patterns import get_builtin_patterns
from netsight.docs.relations import RelationGraph, get_default_relation_graph


def export_full_catalog(
    operation_classes: list[type],
    relation_graph: RelationGraph | None = None,
) -> dict[str, Any]:
    """Export a complete catalog of operations, patterns, and relations.

    Iterates over every class in ``operation_classes``, extracts all
    @operation-decorated methods via the Introspector, and combines them
    with the built-in usage patterns and the supplied (or default) relation
    graph into a single catalog dict.

    Args:
        operation_classes: List of classes whose @operation-decorated
            methods should be included in the catalog.
        relation_graph: Optional pre-built RelationGraph.  When None the
            default PAN-OS relation graph is used.

    Returns:
        Dict with three top-level keys:
        - ``"tools"``     — list of tool definition dicts
        - ``"patterns"``  — list of usage pattern dicts
        - ``"relations"`` — list of operation relation dicts
    """
    all_ops: list[OperationMeta] = []
    for cls in operation_classes:
        all_ops.extend(Introspector.extract_operations(cls))

    graph = relation_graph or get_default_relation_graph()

    return {
        "tools": Introspector.to_tool_definitions(all_ops),
        "patterns": [
            {
                "name": p.name,
                "description": p.description,
                "steps": [
                    {"operation": s.operation, "description": s.description}
                    for s in p.steps
                ],
            }
            for p in get_builtin_patterns()
        ],
        "relations": [
            {
                "source": r.source,
                "target": r.target,
                "type": r.relation_type,
            }
            for r in graph.all_relations()
        ],
    }


def export_as_json(catalog: dict[str, Any], pretty: bool = True) -> str:
    """Serialize a catalog dict to a JSON string.

    Args:
        catalog: Catalog dict as returned by :func:`export_full_catalog`.
        pretty: When True (default) the output is indented with 2-space
            indentation for human readability.  Set to False for compact
            output suitable for network transfer.

    Returns:
        JSON-encoded string.
    """
    return json.dumps(catalog, indent=2 if pretty else None, default=str)
