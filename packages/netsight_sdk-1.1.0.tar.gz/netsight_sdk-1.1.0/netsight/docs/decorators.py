"""Self-documenting decorators — @operation and @code_path.

The @operation decorator is the single source of truth for all
documentation surfaces: CLI help, Swagger, GraphQL, MCP tools,
and AI tool definitions.

The @code_path decorator annotates execution flows for AI agents.
"""

from __future__ import annotations

import functools
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


@dataclass
class Param:
    """Parameter definition for an operation.

    Args:
        param_type: Python type of the parameter.
        description: Human-readable description.
        default: Default value (None means required).
    """

    param_type: type
    description: str
    default: Any = None


@dataclass
class OperationMeta:
    """Metadata attached to an operation by the @operation decorator.

    This is the single source of truth for all documentation surfaces.
    """

    name: str
    description: str
    category: str
    parameters: dict[str, Param] = field(default_factory=dict)
    response_model: type | None = None
    example_output: Any = None
    tags: list[str] = field(default_factory=list)
    related_operations: list[str] = field(default_factory=list)
    follows: list[str] = field(default_factory=list)
    useful_with: list[str] = field(default_factory=list)
    investigation_hint: str = ""


def operation(
    name: str,
    description: str,
    category: str,
    parameters: dict[str, Param] | None = None,
    response_model: type | None = None,
    example_output: Any = None,
    tags: list[str] | None = None,
    related_operations: list[str] | None = None,
    follows: list[str] | None = None,
    useful_with: list[str] | None = None,
    investigation_hint: str = "",
) -> Callable[[F], F]:
    """Decorator that marks a method as a documented operation.

    This decorator attaches OperationMeta to the function, which is
    then read by the CLI, Swagger, GraphQL, MCP, and AI tool endpoints.

    Args:
        name: Operation name (e.g. 'show_routes').
        description: Human-readable description.
        category: Category (e.g. 'network', 'system', 'logs').
        parameters: Dict of parameter name -> Param definition.
        response_model: Pydantic model for the response.
        example_output: Example output dict.
        tags: Search/filter tags.
        related_operations: Operations that are often used together.
        follows: Operations that typically precede this one.
        useful_with: Operations that complement this one.
        investigation_hint: Advice for when results are unexpected.
    """

    def decorator(func: F) -> F:
        meta = OperationMeta(
            name=name,
            description=description,
            category=category,
            parameters=parameters or {},
            response_model=response_model,
            example_output=example_output,
            tags=tags or [],
            related_operations=related_operations or [],
            follows=follows or [],
            useful_with=useful_with or [],
            investigation_hint=investigation_hint,
        )
        func._operation_meta = meta  # type: ignore[attr-defined]

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return func(*args, **kwargs)

        wrapper._operation_meta = meta  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator


@dataclass
class Step:
    """A single step in a code path.

    Args:
        name: Step name (e.g. 'initialize', 'execute').
        description: What happens in this step.
    """

    name: str
    description: str


@dataclass
class CodePath:
    """An annotated execution flow.

    Teaches AI agents how operations fit together.
    """

    name: str
    description: str
    steps: list[Step]
    error_handling: dict[str, str] = field(default_factory=dict)
    example: str = ""


def code_path(
    name: str,
    description: str,
    steps: list[Step],
    error_handling: dict[str, str] | None = None,
    example: str = "",
) -> Callable[[F], F]:
    """Decorator that attaches a CodePath to a function.

    Args:
        name: Code path name.
        description: What this flow does.
        steps: List of Steps in order.
        error_handling: Map of exception name -> guidance.
        example: Code example string.
    """

    def decorator(func: F) -> F:
        meta = CodePath(
            name=name,
            description=description,
            steps=steps,
            error_handling=error_handling or {},
            example=example,
        )
        func._code_path_meta = meta  # type: ignore[attr-defined]
        return func

    return decorator
