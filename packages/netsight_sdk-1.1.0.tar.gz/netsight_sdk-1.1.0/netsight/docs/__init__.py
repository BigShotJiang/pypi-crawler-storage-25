"""Self-documenting metadata utilities for NetSight operations.

This package provides decorators and dataclasses for annotating NetSight
operations with structured metadata including parameters, tags, usage
patterns, code paths, and inter-operation relationships.  The metadata
is purely declarative — it does not alter runtime behaviour — but enables
automatic documentation generation, discovery tooling, and AI-assisted
network investigation workflows.

Modules
-------
decorators
    ``@operation`` and ``@code_path`` decorators together with their
    supporting dataclasses (``Param``, ``OperationMeta``, ``Step``,
    ``CodePath``).
patterns
    Pre-defined investigation workflows expressed as ordered sequences
    of operations (``Pattern``, ``PatternStep``, ``get_builtin_patterns``).
relations
    A lightweight directed graph that models how operations relate to one
    another (``Relation``, ``RelationGraph``, ``get_default_relation_graph``).
"""
