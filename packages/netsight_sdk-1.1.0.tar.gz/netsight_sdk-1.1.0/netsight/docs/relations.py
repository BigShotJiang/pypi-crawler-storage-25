"""Operation relationship graph.

Tracks how operations relate to each other for AI agent guidance.
Relationships are bidirectional — if A relates to B, B relates to A.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Relation:
    """A relationship between two operations.

    Args:
        source: Source operation name.
        target: Target operation name.
        relation_type: Type of relationship (e.g. 'complementary', 'prerequisite').
    """

    source: str
    target: str
    relation_type: str


class RelationGraph:
    """Bidirectional graph of operation relationships.

    Stores relations and supports lookup by either endpoint.
    """

    def __init__(self) -> None:
        self._relations: list[Relation] = []

    def add_relation(self, source: str, target: str, relation_type: str) -> None:
        """Add a bidirectional relation between two operations.

        Args:
            source: Source operation name.
            target: Target operation name.
            relation_type: Type of relation (e.g. 'complementary').
        """
        self._relations.append(Relation(source, target, relation_type))

    def get_related(self, operation: str) -> list[Relation]:
        """Get all relations involving an operation (either as source or target).

        Args:
            operation: Operation name to look up.

        Returns:
            List of Relation objects where the operation appears.
        """
        return [
            r
            for r in self._relations
            if r.source == operation or r.target == operation
        ]

    def all_relations(self) -> list[Relation]:
        """Return all relations in the graph.

        Returns:
            List of all Relation objects.
        """
        return list(self._relations)


def get_default_relation_graph() -> RelationGraph:
    """Return the default relation graph for PAN-OS operations.

    Returns:
        A RelationGraph pre-populated with known PAN-OS operation relationships.
    """
    graph = RelationGraph()
    graph.add_relation("show_routing_table", "show_arp_table", "complementary")
    graph.add_relation("show_routing_table", "show_interfaces", "complementary")
    graph.add_relation("show_interfaces", "show_arp_table", "complementary")
    graph.add_relation("show_ha_status", "show_system_info", "complementary")
    graph.add_relation("get_threat_logs", "get_traffic_logs", "correlative")
    graph.add_relation("show_system_info", "show_session_info", "complementary")
    return graph
