"""Output formatting utilities for NetSight query results.

All methods are classmethods so OutputFormatter can be used without
instantiation — it is intentionally stateless.
"""

from __future__ import annotations

import json
import logging
from typing import Any

import xmltodict
from tabulate import tabulate

logger = logging.getLogger(__name__)

_VALID_FORMATS: tuple[str, ...] = ("dict", "json", "table", "raw")


class OutputFormatter:
    """Stateless collection of output-format converters.

    Supported formats
    -----------------
    dict  — Python dict (parsed from XML, JSON, or passed through)
    json  — JSON string (pretty or compact)
    table — Tabulated string via *tabulate* (simple format)
    raw   — Plain string; non-strings are coerced with ``str()``
    """

    # ------------------------------------------------------------------
    # to_dict
    # ------------------------------------------------------------------

    @classmethod
    def to_dict(cls, data: Any) -> dict:
        """Coerce *data* to a Python dict.

        - ``dict``  — returned as-is (passthrough).
        - ``str`` starting with ``"<"`` — parsed as XML via
          :func:`xmltodict.parse`.
        - Any other ``str`` — parsed as JSON via :func:`json.loads`.

        Args:
            data: The data to coerce.  Must be a ``dict`` or a ``str``
                containing valid XML or JSON.

        Returns:
            A Python ``dict`` representation of *data*.
        """
        if isinstance(data, dict):
            return data
        if isinstance(data, str) and data.lstrip().startswith("<"):
            logger.debug("OutputFormatter.to_dict: parsing as XML")
            return xmltodict.parse(data)
        logger.debug("OutputFormatter.to_dict: parsing as JSON")
        return json.loads(data)

    # ------------------------------------------------------------------
    # to_json
    # ------------------------------------------------------------------

    @classmethod
    def to_json(cls, data: Any, pretty: bool = True) -> str:
        """Convert *data* to a JSON string.

        The input is first coerced to a dict via :meth:`to_dict` when it
        is not already a dict; this means XML and JSON strings are handled
        transparently.

        Non-JSON-serialisable values (e.g. :class:`datetime.date`) are
        rendered using ``str()`` via ``default=str``.

        Args:
            data: Data to serialise.
            pretty: If ``True`` (default), the output is indented with
                2 spaces.  If ``False``, the output is compact (no
                extra whitespace).

        Returns:
            A JSON string.
        """
        if not isinstance(data, dict):
            data = cls.to_dict(data)
        indent = 2 if pretty else None
        return json.dumps(data, indent=indent, default=str)

    # ------------------------------------------------------------------
    # to_table
    # ------------------------------------------------------------------

    @classmethod
    def to_table(cls, data: Any, columns: list[str] | None = None) -> str:
        """Render *data* as a plain-text table using *tabulate*.

        - ``list[dict]`` — rendered with ``headers="keys"`` (one row per
          dict).  An optional *columns* filter restricts which columns are
          shown; missing keys in individual rows become empty strings.
        - ``dict`` — rendered as a two-column key / value table.

        Args:
            data: A ``dict`` or a ``list`` of ``dict`` objects.
            columns: Optional list of column names to include.  Only
                applies to list-of-dict input; order is preserved.
                Ignored for single-dict input.

        Returns:
            A plain-text table string (``tablefmt="simple"``).
        """
        if isinstance(data, list):
            if columns is not None:
                rows = [{col: row.get(col, "") for col in columns} for row in data]
            else:
                rows = data
            return tabulate(rows, headers="keys", tablefmt="simple")

        # Single dict — key / value pairs
        if isinstance(data, dict):
            rows_kv = list(data.items())
            return tabulate(rows_kv, tablefmt="simple")

        # Fallback: convert to string representation
        return str(data)

    # ------------------------------------------------------------------
    # to_raw
    # ------------------------------------------------------------------

    @classmethod
    def to_raw(cls, data: Any) -> str:
        """Return a raw string representation of *data*.

        ``str`` inputs are returned unchanged (same object).  All other
        types are coerced with ``str()``.

        Args:
            data: Any value.

        Returns:
            A ``str``.
        """
        if isinstance(data, str):
            return data
        return str(data)

    # ------------------------------------------------------------------
    # format (dispatcher)
    # ------------------------------------------------------------------

    @classmethod
    def format(cls, data: Any, fmt: str, **kwargs: Any) -> Any:
        """Dispatch to the appropriate formatter method.

        Args:
            data: The data to format.
            fmt: One of ``"dict"``, ``"json"``, ``"table"``, or ``"raw"``.
            **kwargs: Additional keyword arguments forwarded to the target
                method (e.g. ``pretty=False`` for JSON, ``columns=[...]``
                for table).

        Returns:
            The formatted output; type depends on *fmt*.

        Raises:
            ValueError: If *fmt* is not one of the supported formats.
        """
        if fmt == "dict":
            return cls.to_dict(data)
        if fmt == "json":
            return cls.to_json(data, **kwargs)
        if fmt == "table":
            return cls.to_table(data, **kwargs)
        if fmt == "raw":
            return cls.to_raw(data)

        valid = ", ".join(f"'{f}'" for f in _VALID_FORMATS)
        raise ValueError(f"Unknown format: '{fmt}'. Use: [{valid}]")
