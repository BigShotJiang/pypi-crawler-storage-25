"""AST-based code pattern auditor.

Walks Python source code looking for common unsafe patterns. Emits
SecurityFinding objects with a pattern name, severity, and suggestion.

This module is a static analyzer — it does NOT execute the audited code.
Keywords that name unsafe functions (eval, exec, pickle, etc.) appear
here strictly as detection targets.
"""

from __future__ import annotations

import ast
import logging
import re
from pathlib import Path

from netsight.security.findings import SecurityFinding

logger = logging.getLogger(__name__)


# Regex for identifier-like targets that likely hold secrets.
_SECRET_NAME_RE = re.compile(
    r"(?i)(password|passwd|secret|api[_-]?key|token|credential)"
)


class CodePatternAuditor(ast.NodeVisitor):
    """Static analyzer that flags unsafe Python code patterns.

    Usage::

        auditor = CodePatternAuditor()
        findings = auditor.audit_source(source_text, "path/to/file.py")
    """

    def __init__(self) -> None:
        self.findings: list[SecurityFinding] = []
        self._file_path: str = ""

    # ------------------------------------------------------------------
    # Entry points
    # ------------------------------------------------------------------

    def audit_source(self, source: str, file_path: str) -> list[SecurityFinding]:
        """Parse *source* and return findings for *file_path*.

        The auditor state is reset between calls, so reusing a single
        instance across files is safe.
        """
        self.findings = []
        self._file_path = file_path
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            logger.debug("Skipping %s: syntax error: %s", file_path, exc)
            return []
        self.visit(tree)
        return list(self.findings)

    def audit_file(self, path: Path) -> list[SecurityFinding]:
        """Audit a single file on disk."""
        try:
            source = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            logger.debug("Cannot read %s: %s", path, exc)
            return []
        return self.audit_source(source, str(path))

    def audit_directory(self, path: Path) -> list[SecurityFinding]:
        """Audit all .py files under *path* recursively."""
        collected: list[SecurityFinding] = []
        for py_file in sorted(path.rglob("*.py")):
            if not py_file.is_file():
                continue
            collected.extend(self.audit_file(py_file))
        return collected

    # ------------------------------------------------------------------
    # AST visitors
    # ------------------------------------------------------------------

    def visit_Call(self, node: ast.Call) -> None:  # noqa: N802
        self._check_arbitrary_execution(node)
        self._check_shell_injection(node)
        self._check_unsafe_deserialization(node)
        self._check_unsafe_yaml(node)
        self._check_weak_hash(node)
        self._check_tls_bypass(node)
        self._check_insecure_tempfile(node)
        self._check_query_injection(node)
        self.generic_visit(node)

    def visit_Try(self, node: ast.Try) -> None:  # noqa: N802
        for handler in node.handlers:
            if handler.type is None:
                self._add(
                    node=handler,
                    severity="low",
                    pattern="bare_except",
                    message="Bare except clause catches all exceptions including KeyboardInterrupt and SystemExit.",
                    suggestion="Catch a specific exception type, or use 'except Exception:' at minimum.",
                )
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:  # noqa: N802
        self._check_hardcoded_secret(node)
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Per-pattern checks
    # ------------------------------------------------------------------

    def _check_arbitrary_execution(self, node: ast.Call) -> None:
        name = self._call_name(node)
        if name in {"eval", "exec"}:
            self._add(
                node=node,
                severity="critical",
                pattern="arbitrary_execution",
                message=f"Use of builtin {name}() allows arbitrary code execution.",
                suggestion="Avoid dynamic code evaluation. Parse input with ast.literal_eval or a dedicated parser.",
            )

    def _check_shell_injection(self, node: ast.Call) -> None:
        name = self._call_name(node)
        if name not in {"subprocess.run", "subprocess.call", "subprocess.Popen",
                        "subprocess.check_call", "subprocess.check_output"}:
            return
        for kw in node.keywords:
            if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                self._add(
                    node=node,
                    severity="critical",
                    pattern="shell_injection",
                    message=f"{name} called with shell=True — enables shell injection.",
                    suggestion="Pass a list of arguments and use shell=False (the default).",
                )

    def _check_unsafe_deserialization(self, node: ast.Call) -> None:
        name = self._call_name(node)
        if name in {"pickle.loads", "pickle.load"}:
            self._add(
                node=node,
                severity="critical",
                pattern="unsafe_deserialization",
                message=f"{name} can execute arbitrary code on untrusted input.",
                suggestion="Use a safe serialization format like JSON or msgpack.",
            )

    def _check_unsafe_yaml(self, node: ast.Call) -> None:
        name = self._call_name(node)
        if name != "yaml.load":
            return
        for kw in node.keywords:
            if kw.arg == "Loader":
                # Loader is set — assume caller chose appropriately.
                return
        self._add(
            node=node,
            severity="high",
            pattern="unsafe_yaml",
            message="yaml.load() without an explicit Loader defaults to FullLoader which can instantiate arbitrary Python objects.",
            suggestion="Use yaml.safe_load() or pass Loader=yaml.SafeLoader.",
        )

    def _check_weak_hash(self, node: ast.Call) -> None:
        name = self._call_name(node)
        if name in {"hashlib.md5", "hashlib.sha1"}:
            algo = name.split(".", 1)[1]
            self._add(
                node=node,
                severity="high",
                pattern="weak_hash",
                message=f"{algo.upper()} is cryptographically broken and must not be used for security purposes.",
                suggestion="Use hashlib.sha256 or a dedicated password hash like bcrypt/argon2 for passwords.",
            )

    def _check_tls_bypass(self, node: ast.Call) -> None:
        name = self._call_name(node)
        tls_methods = {
            "requests.get", "requests.post", "requests.put", "requests.delete",
            "requests.head", "requests.patch", "requests.request",
        }
        if name not in tls_methods:
            return
        for kw in node.keywords:
            if kw.arg == "verify" and isinstance(kw.value, ast.Constant) and kw.value.value is False:
                self._add(
                    node=node,
                    severity="medium",
                    pattern="tls_bypass",
                    message=f"{name} called with verify=False disables TLS certificate validation.",
                    suggestion="Leave verify unset (defaults to True) or point it at a CA bundle path.",
                )

    def _check_insecure_tempfile(self, node: ast.Call) -> None:
        name = self._call_name(node)
        if name == "tempfile.mktemp":
            self._add(
                node=node,
                severity="medium",
                pattern="insecure_tempfile",
                message="tempfile.mktemp() is vulnerable to symlink attacks (TOCTOU).",
                suggestion="Use tempfile.mkstemp() or NamedTemporaryFile() instead.",
            )

    def _check_query_injection(self, node: ast.Call) -> None:
        # Detect cursor.execute(<f-string or concatenation>)
        if not isinstance(node.func, ast.Attribute):
            return
        if node.func.attr != "execute":
            return
        if not node.args:
            return
        arg = node.args[0]
        if isinstance(arg, ast.JoinedStr):
            # f-string
            self._add(
                node=node,
                severity="critical",
                pattern="query_injection",
                message="cursor.execute() called with an f-string — allows SQL injection.",
                suggestion="Pass parameters via the second argument: cursor.execute(sql, params).",
            )
            return
        if isinstance(arg, ast.BinOp) and isinstance(arg.op, ast.Add):
            self._add(
                node=node,
                severity="critical",
                pattern="query_injection",
                message="cursor.execute() called with string concatenation — allows SQL injection.",
                suggestion="Pass parameters via the second argument: cursor.execute(sql, params).",
            )

    def _check_hardcoded_secret(self, node: ast.Assign) -> None:
        # Check each target for a name matching the secret pattern.
        if not isinstance(node.value, ast.Constant) or not isinstance(node.value.value, str):
            return
        # An empty string is never a hardcoded secret — it is a default
        # sentinel used by dataclass fields and local variable initialisation
        # (e.g. ``credential_provider = ""``).  Flagging empty strings
        # produces false positives without any security value.
        if node.value.value == "":
            return
        for target in node.targets:
            target_name: str | None = None
            if isinstance(target, ast.Name):
                target_name = target.id
            elif isinstance(target, ast.Attribute):
                target_name = target.attr
            if target_name and _SECRET_NAME_RE.search(target_name):
                self._add(
                    node=node,
                    severity="critical",
                    pattern="hardcoded_secret",
                    message=f"Hardcoded string value assigned to '{target_name}' — possible secret in source.",
                    suggestion="Load secrets from environment variables or a secret manager.",
                )
                return

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _call_name(node: ast.Call) -> str:
        """Return a dotted name for node.func, or an empty string."""
        func = node.func
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            parts: list[str] = [func.attr]
            current: ast.expr = func.value
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
                return ".".join(reversed(parts))
        return ""

    def _add(
        self,
        *,
        node: ast.AST,
        severity: str,
        pattern: str,
        message: str,
        suggestion: str,
    ) -> None:
        self.findings.append(
            SecurityFinding(
                file_path=self._file_path,
                line=getattr(node, "lineno", 0),
                column=getattr(node, "col_offset", 0),
                severity=severity,
                pattern=pattern,
                message=message,
                suggestion=suggestion,
            )
        )
