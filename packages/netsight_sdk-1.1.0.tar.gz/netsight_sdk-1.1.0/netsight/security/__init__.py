"""NetSight security module — code pattern audit and dependency vulnerability scanning."""
