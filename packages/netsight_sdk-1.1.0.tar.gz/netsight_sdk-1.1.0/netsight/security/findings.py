"""Dataclasses for security audit findings."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class SecurityFinding:
    """A single finding from code pattern audit."""

    file_path: str
    line: int
    column: int
    severity: str  # critical | high | medium | low
    pattern: str
    message: str
    suggestion: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class DependencyFinding:
    """A single finding from dependency audit."""

    package: str
    installed_version: str
    severity: str
    issue: str
    cve_id: str | None
    suggested_action: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
