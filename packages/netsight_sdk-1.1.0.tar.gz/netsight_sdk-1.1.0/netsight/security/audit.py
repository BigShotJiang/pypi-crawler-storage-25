"""Top-level security audit orchestrator."""

from __future__ import annotations

import logging
import tomllib
from pathlib import Path
from typing import Any

from netsight.mcp_dev.path_security import PROJECT_ROOT
from netsight.security.code_patterns import CodePatternAuditor
from netsight.security.dependencies import DependencyAuditor
from netsight.security.findings import DependencyFinding, SecurityFinding

logger = logging.getLogger(__name__)

_POLICIES_PATH = Path(__file__).parent / "policies.toml"

_SEVERITY_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1}


def load_policies() -> dict[str, Any]:
    """Load security audit policies from policies.toml."""
    if not _POLICIES_PATH.exists():
        return {
            "severity_thresholds": {
                "fail_on": "critical",
                "warn_on": "high",
                "ignore": ["low"],
            },
            "exclusions": {},
        }
    with open(_POLICIES_PATH, "rb") as f:
        return tomllib.load(f)


class AuditOrchestrator:
    """Coordinates code pattern and dependency audits."""

    def __init__(self) -> None:
        self._policies = load_policies()
        self._code_auditor = CodePatternAuditor()
        self._dep_auditor = DependencyAuditor()

    def audit_code_only(self) -> dict[str, Any]:
        """Run only the code pattern audit."""
        findings = self._code_auditor.audit_directory(PROJECT_ROOT / "netsight")
        return {
            "code_findings": [f.to_dict() for f in findings],
            "summary": self._summarize_code(findings),
        }

    def audit_deps_only(self) -> dict[str, Any]:
        """Run only the dependency audit."""
        known_findings = self._dep_auditor.audit_known_safe_check()
        pip_findings = self._dep_auditor.audit_pip_audit()
        all_findings = known_findings + pip_findings
        return {
            "dependency_findings": [f.to_dict() for f in all_findings],
            "summary": self._summarize_deps(all_findings),
        }

    def audit_full(self) -> dict[str, Any]:
        """Run both code and dependency audits."""
        code_report = self.audit_code_only()
        dep_report = self.audit_deps_only()
        return {
            "code_findings": code_report["code_findings"],
            "dependency_findings": dep_report["dependency_findings"],
            "summary": {
                "code": code_report["summary"],
                "dependencies": dep_report["summary"],
            },
        }

    def has_critical(self, report: dict[str, Any]) -> bool:
        """Check if a report has any critical findings."""
        for f in report.get("code_findings", []):
            if f.get("severity") == "critical":
                return True
        for f in report.get("dependency_findings", []):
            if f.get("severity") == "critical":
                return True
        return False

    @staticmethod
    def _summarize_code(findings: list[SecurityFinding]) -> dict[str, int]:
        summary = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for f in findings:
            summary[f.severity] = summary.get(f.severity, 0) + 1
        return summary

    @staticmethod
    def _summarize_deps(findings: list[DependencyFinding]) -> dict[str, int]:
        summary = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for f in findings:
            summary[f.severity] = summary.get(f.severity, 0) + 1
        return summary
