"""Dependency auditor — supply chain security."""

from __future__ import annotations

import json
import logging
import subprocess
import tomllib
from importlib.metadata import distributions
from pathlib import Path
from typing import Any

from packaging.version import InvalidVersion, Version

from netsight.security.findings import DependencyFinding

logger = logging.getLogger(__name__)

_KNOWN_SAFE_PATH = Path(__file__).parent / "known_safe.toml"


def load_known_safe() -> dict[str, dict[str, Any]]:
    """Load known_safe.toml and return a package→metadata dict."""
    if not _KNOWN_SAFE_PATH.exists():
        return {}
    with open(_KNOWN_SAFE_PATH, "rb") as f:
        data = tomllib.load(f)
    packages: dict[str, dict[str, Any]] = data.get("packages", {})
    return packages


class DependencyAuditor:
    """Audits installed dependencies against CVE databases and known_safe.toml."""

    def __init__(self) -> None:
        self._known_safe = load_known_safe()

    def audit_known_safe_check(self) -> list[DependencyFinding]:
        """Check installed packages against known_safe.toml."""
        findings: list[DependencyFinding] = []
        installed: dict[str, str] = {}
        for dist in distributions():
            name = dist.metadata["Name"]
            if name:
                installed[name.lower().replace("_", "-")] = dist.version

        for name, version in installed.items():
            entry = self._known_safe.get(name)
            if entry is None:
                findings.append(DependencyFinding(
                    package=name,
                    installed_version=version,
                    severity="medium",
                    issue="Package not in known_safe.toml (unvetted)",
                    cve_id=None,
                    suggested_action=f"Verify {name}=={version} and add to known_safe.toml",
                ))
                continue

            try:
                installed_ver = Version(version)
                min_ver = Version(entry["min_version"])
                max_ver = Version(entry["max_version"])
            except (InvalidVersion, KeyError):
                continue

            if installed_ver < min_ver:
                findings.append(DependencyFinding(
                    package=name,
                    installed_version=version,
                    severity="high",
                    issue=f"Version {version} is older than vetted minimum {entry['min_version']}",
                    cve_id=None,
                    suggested_action=f"Upgrade to {entry['min_version']} or later",
                ))
            elif installed_ver > max_ver:
                findings.append(DependencyFinding(
                    package=name,
                    installed_version=version,
                    severity="high",
                    issue=f"Version {version} is newer than vetted maximum {entry['max_version']}",
                    cve_id=None,
                    suggested_action=f"Downgrade to {entry['max_version']} or verify new version",
                ))

        return findings

    def audit_pip_audit(self) -> list[DependencyFinding]:
        """Run pip-audit to find known vulnerabilities."""
        findings: list[DependencyFinding] = []
        try:
            result = subprocess.run(
                [".venv/bin/pip-audit", "--format=json"],
                capture_output=True,
                text=True,
                timeout=60,
            )
            if result.returncode != 0 and result.stdout:
                data = json.loads(result.stdout)
                for dep in data.get("dependencies", []):
                    for vuln in dep.get("vulns", []):
                        findings.append(DependencyFinding(
                            package=dep.get("name", "unknown"),
                            installed_version=dep.get("version", ""),
                            severity="critical",
                            issue=vuln.get("description", ""),
                            cve_id=vuln.get("id"),
                            suggested_action=(
                                f"Upgrade to {vuln.get('fix_versions', ['latest'])}"
                            ),
                        ))
        except (subprocess.SubprocessError, json.JSONDecodeError, FileNotFoundError) as e:
            logger.warning("pip-audit failed: %s", e)
        return findings

    def verify_package(self, name: str, version: str) -> dict[str, Any]:
        """Verify a specific package/version against known_safe.toml."""
        entry = self._known_safe.get(name.lower().replace("_", "-"))
        if entry is None:
            return {
                "status": "unvetted",
                "message": f"{name} is not in known_safe.toml",
            }

        try:
            v = Version(version)
            min_v = Version(entry["min_version"])
            max_v = Version(entry["max_version"])
        except (InvalidVersion, KeyError):
            return {"status": "error", "message": "Version parsing failed"}

        if min_v <= v <= max_v:
            return {"status": "ok", "message": f"{name}=={version} is vetted"}
        return {
            "status": "out_of_range",
            "message": f"{name}=={version} is outside vetted range [{entry['min_version']}, {entry['max_version']}]",
        }
