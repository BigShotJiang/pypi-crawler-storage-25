"""Abstract base class that wires together NetSight's safety and resilience
primitives so every plugin gets them automatically.

Design
------
``BaseDeviceClient`` enforces a strict execution pipeline:

1. **CommandGate** validates the requested operation against the
   catalog-derived operation set built from the compiled
   ``resolved_config``.  Unknown operations are denied before any
   network I/O occurs.
2. **AuthManager** provides lazy, cached authentication.  The first call to
   :meth:`execute` triggers authentication; subsequent calls reuse the cached
   token until it expires.
3. **RateLimiter** enforces a per-device sliding-window rate limit to protect
   devices from being overwhelmed.
4. **ResponseGuard** rejects oversized responses before they consume excessive
   memory.

Plugin authors subclass ``BaseDeviceClient``, ship a pack catalog
(``_data/operations_catalog.toml``), and implement the four abstract
methods.  The class reads ``self._op_commands``, ``self._op_types``,
``self._log_types``, and ``self._required_models`` out of the compiled
catalog at construction time — there is no class-level fallback set.

Usage example::

    class PanOSClient(BaseDeviceClient):
        def _authenticate(self) -> str:
            return self._auth_manager.get_token(
                self._config.host,
                self._config.username,
                self._config.get_password(),
            )

        def _execute_raw(self, operation, params=None):
            # self._op_commands / self._op_types come from the catalog
            cmd = self._op_commands[operation]
            ...  # vendor-specific HTTP/XML call

        def get_device_info(self) -> dict:
            ...

        def get_supported_operations(self) -> list[str]:
            return sorted(self._op_commands.keys())
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from netsight.auth import AuthManager, AuthStrategy
from netsight.config import DeviceConfig
from netsight.gate import CommandGate
from netsight.resilience import RateLimiter, ResponseGuard

logger = logging.getLogger(__name__)


class BaseDeviceClient(ABC):
    """Abstract base that wires CommandGate, AuthManager, RateLimiter, and
    ResponseGuard together for every NetSight plugin.

    Parameters
    ----------
    config:
        Immutable configuration for the target device.
    auth_strategy:
        ``AuthStrategy`` implementation used to acquire/revoke session tokens.
    resolved_config:
        **Required.** Compiled catalog dict produced by
        :class:`~netsight.config_mgmt.ConfigCompiler` and loaded by
        :class:`~netsight.sdk.local.LocalBackend`. Must contain an
        ``"operations"`` sub-dict keyed by operation name. Passing
        ``None`` or a dict with no ``"operations"`` key is a pack
        authoring error and raises :class:`ValueError`.

        Before commit 5 of the pack-design refactor this argument was
        optional and the base class fell back to a class-level
        ``ALLOWED_OPERATIONS`` attribute. That fallback is gone: packs
        must ship an ``_data/operations_catalog.toml`` and clients
        receive the compiled form via this argument.
    rate_limit_override:
        If provided, overrides ``config.rate_limit`` as the max-rps value
        passed to :class:`~netsight.resilience.RateLimiter`.
    max_response_bytes:
        Upper size limit (bytes) enforced by
        :class:`~netsight.resilience.ResponseGuard`.  Defaults to 50 MiB.

    Raises
    ------
    ValueError
        If *resolved_config* is ``None``, not a dict, or missing the
        ``"operations"`` section.
    """

    def __init__(
        self,
        *,
        config: DeviceConfig,
        auth_strategy: AuthStrategy,
        rate_limit_override: int | None = None,
        max_response_bytes: int = 50 * 1024 * 1024,
        resolved_config: dict[str, Any] | None = None,
    ) -> None:
        # resolved_config is strictly required — commit 5 of the
        # pack-design refactor deleted the legacy class-level
        # ALLOWED_OPERATIONS fallback. A None / empty / mal-shaped
        # resolved_config is a pack authoring bug, not a runtime
        # user error: fail loud, with a pointer at the compiler.
        if resolved_config is None or not isinstance(resolved_config, dict):
            raise ValueError(
                f"{type(self).__name__} requires a compiled resolved_config "
                "dict at construction time. Pass the output of "
                "netsight.config_mgmt.ConfigCompiler (LocalBackend does "
                "this automatically) instead of None."
            )
        if "operations" not in resolved_config:
            raise ValueError(
                f"{type(self).__name__} received a resolved_config without "
                "an 'operations' section. Every compiled pack catalog must "
                "declare at least one operation; check the pack's "
                "_data/operations_catalog.toml."
            )

        self._config = config
        self._resolved = resolved_config

        # Build per-instance dispatch metadata from the resolved
        # catalog. Every operation's command / type / log_type /
        # required_model comes from the catalog; there is no class-
        # level fallback.
        self._op_commands: dict[str, str] = {}
        self._op_types: dict[str, str] = {}
        self._log_types: dict[str, str] = {}
        self._required_models: dict[str, str | list[str]] = {}

        ops_meta = resolved_config["operations"]
        for name, op in ops_meta.items():
            self._op_commands[name] = op.get("command", "")
            self._op_types[name] = op.get("type", "op")
            if op.get("type") == "log" and "log_type" in op:
                self._log_types[name] = op["log_type"]
            # required_model defaults to the wildcard "*" when absent,
            # meaning "this operation works on every model".
            self._required_models[name] = op.get("required_model", "*")

        # The command gate is seeded from the catalog keys alone.
        # Auth primitives like PAN-OS keygen MUST NOT appear here —
        # they are private to the AuthStrategy and never reach
        # execute().
        self._gate = CommandGate(set(ops_meta.keys()))
        self._auth_manager = AuthManager(auth_strategy)

        rc = self._resolved.get("resilience", {})
        self._rate_limiter = RateLimiter(
            max_rps=rate_limit_override or rc.get("rate_limit", config.rate_limit)
        )
        self._response_guard = ResponseGuard(
            max_bytes=rc.get("max_response_bytes", max_response_bytes)
        )
        self._token: str | None = None

    # ------------------------------------------------------------------
    # Public execution pipeline
    # ------------------------------------------------------------------

    def execute(self, *, operation: str, params: Any = None) -> Any:
        """Run *operation* through the full safety pipeline and return the result.

        Pipeline steps:

        1. Gate validation — raises :class:`~netsight.exceptions.CommandDeniedError`
           if the operation is not in ``ALLOWED_OPERATIONS``.
        2. Lazy authentication — acquires a token on the first call.
        3. Rate limiting — raises :class:`~netsight.exceptions.RateLimitError`
           if the per-device budget is exhausted.
        4. Delegate to :meth:`_execute_raw` for the actual device call.
        5. Response size check via :class:`~netsight.resilience.ResponseGuard`
           — raises :class:`~netsight.exceptions.ResponseSizeError` if the
           payload exceeds ``max_response_bytes``.

        Parameters
        ----------
        operation:
            The operation string to execute.  Must be in ``ALLOWED_OPERATIONS``.
        params:
            Optional parameters forwarded verbatim to :meth:`_execute_raw`.

        Returns
        -------
        Any
            The raw response returned by :meth:`_execute_raw`.

        Raises
        ------
        netsight.exceptions.CommandDeniedError
            If the operation is blocked by the gate.
        netsight.exceptions.RateLimitError
            If the device's rate limit is exceeded.
        netsight.exceptions.ResponseSizeError
            If the response payload exceeds *max_response_bytes*.
        """
        # Step 1: Gate check
        self._gate.validate(operation)

        # Step 1b: Model gate — the catalog can narrow an operation to
        # specific device models via the ``required_model`` field. A
        # missing entry, or the wildcard "*", means "any model". A list
        # means "only these models". If the current device's model is
        # not in the allowed set, refuse with a CommandDeniedError that
        # names both the operation and the model.
        self._check_model_gate(operation)

        # Step 2: Lazy authentication
        if self._token is None:
            self._token = self._authenticate()

        # Step 3: Rate limit
        self._rate_limiter.acquire(self._config.name)

        # Step 4: Execute
        logger.info(
            "Executing %s on %s (%s)",
            operation,
            self._config.name,
            self._config.host,
        )
        response = self._execute_raw(operation, params)

        # Step 5: Response guard (only for str/bytes payloads)
        if isinstance(response, (str, bytes)):
            self._response_guard.check(response)

        # Step 6: Apply parser engine if a spec is registered
        parser_spec = self._get_parser_spec(operation)
        if parser_spec is not None:
            from netsight.parsers.registry import parser_registry

            engine_name = parser_spec.get("engine", "jmespath")
            engine_class = parser_registry.get(engine_name)
            engine = engine_class()
            return engine.parse(response, parser_spec)

        return response

    # ------------------------------------------------------------------
    # Model gate
    # ------------------------------------------------------------------

    def _check_model_gate(self, operation: str) -> None:
        """Refuse *operation* if the device's model is not in its ``required_model``.

        Every operation declares a ``required_model`` in the catalog —
        either the string ``"*"`` (any model, the default when absent)
        or a list of model-name strings. When ``required_model`` is a
        list, this check compares the current device's ``config.model``
        against it and raises :class:`CommandDeniedError` on mismatch.

        This is a second line of defence after the command gate and
        before any authentication happens — it prevents a device query
        from reaching the vendor API when the operation is known to be
        unsupported on that model. It also catches configuration
        mistakes where a user enables an operation in their allowlist
        but their device is the wrong hardware / software class.

        Parameters
        ----------
        operation:
            Name of the operation being dispatched. Looked up in
            ``self._required_models`` (built from the catalog at
            ``__init__`` time).

        Raises
        ------
        netsight.exceptions.CommandDeniedError
            If the operation's ``required_model`` is a list and the
            device's model is not in it.
        """
        from netsight.exceptions import CommandDeniedError

        required = self._required_models.get(operation, "*")
        if required == "*":
            return  # wildcard — any model is acceptable

        # required is a list (schema validator guarantees this shape).
        # Absent device model → fail loud, don't silently allow. Note
        # that DeviceConfig.model defaults to the empty string rather
        # than None, so both sentinels are treated as "not set".
        device_model = getattr(self._config, "model", None) or None
        if device_model is None:
            raise CommandDeniedError(
                operation=operation,
                reason=(
                    f"operation requires model in {required!r} but the "
                    f"device config does not declare a model. Set "
                    f"`model:` in devices.yaml for this device."
                ),
            )

        if device_model not in required:
            raise CommandDeniedError(
                operation=operation,
                reason=(
                    f"operation is gated to models {required!r}; the "
                    f"device '{self._config.name}' has model "
                    f"{device_model!r} which is not in that set"
                ),
            )

    # ------------------------------------------------------------------
    # Parser helpers
    # ------------------------------------------------------------------

    def _get_parser_spec(self, operation: str) -> dict | None:
        """Return the resolved parser spec for *operation*, or ``None``.

        Looks up ``parser_resolved`` in the resolved config for the given
        operation.  Returns ``None`` when either the operation has no resolved
        config or no ``parser_resolved`` key is present.

        Parameters
        ----------
        operation:
            Operation name to look up.

        Returns
        -------
        dict or None
            The parser spec dict if present, otherwise ``None``.
        """
        ops = self._resolved.get("operations", {})
        op_config = ops.get(operation, {})
        return op_config.get("parser_resolved")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Release authentication state and invalidate the cached token.

        Calls :meth:`~netsight.auth.AuthManager.close` on the underlying
        manager, which revokes all cached tokens, then clears ``_token``.
        """
        self._auth_manager.close()
        self._token = None
        logger.info(
            "Closed client for %s (%s)",
            self._config.name,
            self._config.host,
        )

    def __enter__(self) -> "BaseDeviceClient":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Abstract interface — subclasses must implement
    # ------------------------------------------------------------------

    @abstractmethod
    def _authenticate(self) -> str:
        """Obtain a session token for the configured device.

        Implementations should call :meth:`~netsight.auth.AuthManager.get_token`
        on ``self._auth_manager`` and return the resulting token string.

        Returns
        -------
        str
            A non-empty session token.
        """

    @abstractmethod
    def _execute_raw(self, operation: str, params: Any = None) -> Any:
        """Perform the actual device call and return the raw response.

        This method is only called after the gate, authentication, and rate
        limiter have all passed.  The response size check happens *after*
        this method returns.

        Parameters
        ----------
        operation:
            Validated operation string.
        params:
            Optional parameters as received from :meth:`execute`.

        Returns
        -------
        Any
            The raw device response.  ``str`` and ``bytes`` values are
            automatically checked against the response size limit.
        """

    @abstractmethod
    def get_device_info(self) -> dict:
        """Return basic device information such as hostname and model.

        Returns
        -------
        dict
            A mapping with at least ``hostname`` and ``model`` keys.
        """

    @abstractmethod
    def get_supported_operations(self) -> list[str]:
        """Return the list of operations intended for external callers.

        Implementations should exclude any internal or privileged operations
        (e.g. ``keygen``) from the returned list.

        Returns
        -------
        list[str]
            Sorted list of publicly advertised operation strings.
        """
