"""NetSight command-line interface.

Entry point: ``netsight`` (mapped via ``[project.scripts]`` in pyproject.toml).

Usage examples::

    netsight --device fw-01 show system-info
    netsight --device fw-01 --format json show interfaces
    netsight --device fw-01 snapshot
    netsight plugins list
    netsight operations list
    netsight template create full_audit --ops show_system_info,show_interfaces
    netsight template list
    netsight template run full_audit
    netsight diff --from 2026-01-01 --to 2026-01-02
    netsight history --device fw-01 --operation show_arp --last 24h
    netsight parse refs --rule my_rule
"""

from __future__ import annotations

import argparse
import logging
import sys
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CLI operation name → plugin operation string mapping
# ---------------------------------------------------------------------------

_SHOW_OPERATION_MAP: dict[str, str] = {
    "system-info": "show_system_info",
    "interfaces": "show_interfaces",
    "routes": "show_routing_table",
    "arp": "show_arp_table",
    "ha-status": "show_ha_status",
    "sessions": "show_session_info",
}

_VALID_SHOW_OPERATIONS = list(_SHOW_OPERATION_MAP.keys())


# ---------------------------------------------------------------------------
# Parser construction
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    """Build and return the top-level ArgumentParser for the NetSight CLI.

    The parser has a set of global flags applicable to all subcommands and a
    set of subcommand parsers for specific operations.

    Returns
    -------
    argparse.ArgumentParser
        Fully configured parser ready to call :meth:`~argparse.ArgumentParser.parse_args`.
    """
    parser = argparse.ArgumentParser(
        prog="netsight",
        description="NetSight — read-only multi-vendor network device query SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # ------------------------------------------------------------------
    # Global flags
    # ------------------------------------------------------------------
    parser.add_argument(
        "--config",
        default=None,
        metavar="PATH",
        help=(
            "Path to the devices YAML config file. "
            "When omitted the search order is: $NETSIGHT_CONFIG_DIR, "
            "./config/, $XDG_CONFIG_HOME/netsight/, ~/.config/netsight/"
        ),
    )
    parser.add_argument(
        "--device",
        default=None,
        metavar="NAME",
        help="Logical device name as defined in the config file",
    )
    parser.add_argument(
        "--format",
        choices=("dict", "json", "table", "raw"),
        default="table",
        help="Output format (default: table)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        default=False,
        help="Enable verbose (DEBUG) logging",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=None,
        metavar="SECONDS",
        help="Override the read timeout in seconds",
    )
    parser.add_argument(
        "--save",
        action="store_true",
        default=False,
        help="Persist the query result to the local SQLite store",
    )

    # ------------------------------------------------------------------
    # Subcommands
    # ------------------------------------------------------------------
    subparsers = parser.add_subparsers(dest="subcommand", title="subcommands")

    _add_show_subparser(subparsers)
    _add_devices_subparser(subparsers)
    _add_plugins_subparser(subparsers)
    _add_operations_subparser(subparsers)
    _add_snapshot_subparser(subparsers)
    _add_diff_subparser(subparsers)
    _add_history_subparser(subparsers)
    _add_template_subparser(subparsers)
    _add_parse_subparser(subparsers)
    _add_config_subparser(subparsers)
    _add_vendor_subparser(subparsers)
    _add_pack_subparser(subparsers)
    _add_allowlist_subparser(subparsers)
    _add_init_subparser(subparsers)
    _add_vault_subparser(subparsers)
    _add_credential_subparser(subparsers)
    _add_standards_subparser(subparsers)

    # dev-mcp subcommand
    subparsers.add_parser("dev-mcp", help="Run the MCP dev server over stdio")

    # doctor subcommand
    subparsers.add_parser(
        "doctor",
        help="Verify the NetSight dev environment (venv, .mcp.json, dev MCP server)",
    )

    # security subcommand
    security_parser = subparsers.add_parser("security", help="Security audit")
    security_sub = security_parser.add_subparsers(dest="sec_action")

    audit_parser = security_sub.add_parser("audit", help="Run security audit")
    audit_parser.add_argument("--code-only", action="store_true")
    audit_parser.add_argument("--deps-only", action="store_true")
    audit_parser.add_argument(
        "--severity", choices=["critical", "high", "medium", "low"]
    )

    verify_parser = security_sub.add_parser("verify", help="Verify a package version")
    verify_parser.add_argument("package")
    verify_parser.add_argument("version")

    policies_parser = security_sub.add_parser("policies", help="Show policies")
    policies_sub = policies_parser.add_subparsers(dest="pol_action")
    policies_sub.add_parser("show", help="Show active policies")

    return parser


# ---------------------------------------------------------------------------
# Subparser builders (each is a focused private helper)
# ---------------------------------------------------------------------------


def _add_show_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'show' subparser."""
    show_parser = subparsers.add_parser("show", help="Query a device for operational data")
    show_parser.add_argument(
        "operation",
        choices=_VALID_SHOW_OPERATIONS,
        help=(
            "Operation to run: "
            + ", ".join(_VALID_SHOW_OPERATIONS)
        ),
    )


def _add_devices_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'devices' subparser."""
    devices_parser = subparsers.add_parser(
        "devices",
        help="List configured devices from devices.yaml",
    )
    devices_sub = devices_parser.add_subparsers(dest="devices_action")
    devices_sub.add_parser("list", help="List all configured devices")


def _add_plugins_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'plugins' subparser."""
    plugins_parser = subparsers.add_parser("plugins", help="Manage and inspect plugins")
    plugins_sub = plugins_parser.add_subparsers(
        dest="plugins_action", title="plugins actions"
    )
    plugins_sub.add_parser("list", help="List all registered plugins")


def _add_operations_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'operations' subparser."""
    ops_parser = subparsers.add_parser(
        "operations", help="Inspect available plugin operations"
    )
    ops_sub = ops_parser.add_subparsers(
        dest="operations_action", title="operations actions"
    )
    ops_sub.add_parser("list", help="List all available operations across all plugins")


def _add_snapshot_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'snapshot' subparser."""
    subparsers.add_parser("snapshot", help="Take a full snapshot of a device")


def _add_diff_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'diff' subparser."""
    diff_parser = subparsers.add_parser(
        "diff", help="Compare two snapshots or time windows"
    )
    diff_parser.add_argument(
        "--from",
        dest="from",
        metavar="DATE",
        default=None,
        help="Start date/time for the comparison (ISO-8601 or snapshot ID)",
    )
    diff_parser.add_argument(
        "--to",
        dest="to",
        metavar="DATE",
        default=None,
        help="End date/time for the comparison (ISO-8601 or snapshot ID)",
    )


def _add_history_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'history' subparser."""
    history_parser = subparsers.add_parser(
        "history", help="Show historical query results for a device"
    )
    history_parser.add_argument(
        "--device",
        metavar="NAME",
        default=None,
        help="Device name to filter history by",
    )
    history_parser.add_argument(
        "--operation",
        metavar="OP",
        default=None,
        help="Operation name to filter history by",
    )
    history_parser.add_argument(
        "--last",
        metavar="DURATION",
        default=None,
        help="Restrict to results from the last DURATION (e.g. '24h', '7d')",
    )


def _add_template_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'template' subparser with create/list/run/delete actions."""
    tmpl_parser = subparsers.add_parser(
        "template", help="Manage named operation templates"
    )
    tmpl_sub = tmpl_parser.add_subparsers(
        dest="template_action", title="template actions"
    )

    # template create <name> --ops <comma-sep>
    create_parser = tmpl_sub.add_parser("create", help="Create a new template")
    create_parser.add_argument("name", help="Unique template name")
    create_parser.add_argument(
        "--ops",
        metavar="OPS",
        required=False,
        default=None,
        help="Comma-separated list of operations to include in the template",
    )

    # template list
    tmpl_sub.add_parser("list", help="List all saved templates")

    # template run <name>
    run_parser = tmpl_sub.add_parser("run", help="Execute a saved template")
    run_parser.add_argument("name", help="Template name to run")

    # template delete <name>
    delete_parser = tmpl_sub.add_parser("delete", help="Delete a saved template")
    delete_parser.add_argument("name", help="Template name to delete")


def _add_parse_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'parse' subparser with refs/impact/tree/validate actions."""
    parse_parser = subparsers.add_parser(
        "parse", help="Parse and analyse device configuration objects"
    )
    parse_sub = parse_parser.add_subparsers(
        dest="parse_action", title="parse actions"
    )

    # parse refs --rule <name>
    refs_parser = parse_sub.add_parser("refs", help="Show references for a rule")
    refs_parser.add_argument("--rule", metavar="NAME", required=False, default=None)

    # parse impact --object <name>
    impact_parser = parse_sub.add_parser(
        "impact", help="Show impact analysis for a configuration object"
    )
    impact_parser.add_argument("--object", metavar="NAME", required=False, default=None)

    # parse tree --root <path>
    tree_parser = parse_sub.add_parser(
        "tree", help="Display the configuration object tree"
    )
    tree_parser.add_argument("--root", metavar="PATH", required=False, default=None)

    # parse validate
    parse_sub.add_parser("validate", help="Validate the current device configuration")


def _add_config_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'config' subparser with compile/show actions."""
    config_parser = subparsers.add_parser("config", help="Config management")
    config_sub = config_parser.add_subparsers(dest="config_action", title="config actions")

    # config compile
    compile_parser = config_sub.add_parser("compile", help="Compile TOML configs to JSON")
    compile_parser.add_argument(
        "--vendor",
        dest="compile_vendor",
        default=None,
        help="Compile specific vendor",
    )
    compile_parser.add_argument(
        "--validate-only",
        action="store_true",
        default=False,
        help="Dry-run validation",
    )

    # config show
    config_show_parser = config_sub.add_parser("show", help="Show resolved config")
    config_show_parser.add_argument("--vendor", required=True, help="Vendor name")
    config_show_parser.add_argument("--model", required=True, help="Model (device variant)")
    config_show_parser.add_argument("--instance", default=None, help="Instance name")


def _add_vendor_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'vendor' subparser with list/init/add-operation actions."""
    vendor_parser = subparsers.add_parser("vendor", help="Vendor management")
    vendor_sub = vendor_parser.add_subparsers(dest="vendor_action", title="vendor actions")

    vendor_sub.add_parser("list", help="List configured vendors")
    vendor_sub.add_parser("init", help="Initialize a new vendor")

    add_op_parser = vendor_sub.add_parser("add-operation", help="Add an operation")
    add_op_parser.add_argument(
        "--vendor",
        dest="op_vendor",
        required=True,
        help="Vendor name",
    )


def _add_pack_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'pack' subparser with list/search/install/info/uninstall/doctor actions."""
    pack_parser = subparsers.add_parser("pack", help="Manage NetSight vendor packs")
    pack_sub = pack_parser.add_subparsers(dest="pack_action", title="pack actions")

    # pack list [--available] [--json] [--no-color]
    list_parser = pack_sub.add_parser("list", help="List installed packs")
    list_parser.add_argument(
        "--available",
        action="store_true",
        default=False,
        help="Also show packs available in the bundled index but not yet installed",
    )
    list_parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Emit JSON output instead of a table (mutually exclusive with colour)",
    )
    list_parser.add_argument(
        "--no-color",
        dest="no_color",
        action="store_true",
        default=False,
        help="Disable colour output (also honoured via NO_COLOR env var)",
    )

    # pack search <query>
    search_parser = pack_sub.add_parser("search", help="Search the pack index")
    search_parser.add_argument("query", help="Case-insensitive search term")

    # pack install <name> [--ref <tag>] [--dry-run]
    install_parser = pack_sub.add_parser("install", help="Install a pack from the index")
    install_parser.add_argument("name", help="Pack name (must be in the index)")
    install_parser.add_argument(
        "--ref",
        default=None,
        metavar="REF",
        help="Git ref (tag, branch, or SHA) to install from",
    )
    install_parser.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        default=False,
        help="Print the pip command that would run without actually installing",
    )

    # pack info <name> [--json] [--no-color]
    info_parser = pack_sub.add_parser("info", help="Show detailed info for a pack")
    info_parser.add_argument("name", help="Pack name")
    info_parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Emit JSON output instead of formatted text (mutually exclusive with colour)",
    )
    info_parser.add_argument(
        "--no-color",
        dest="no_color",
        action="store_true",
        default=False,
        help="Disable colour output (also honoured via NO_COLOR env var)",
    )

    # pack uninstall <name>
    uninstall_parser = pack_sub.add_parser("uninstall", help="Uninstall a pack")
    uninstall_parser.add_argument("name", help="Pack name")

    # pack doctor
    pack_sub.add_parser("doctor", help="Validate every installed pack's config tree")

    # pack add-operation
    add_op = pack_sub.add_parser(
        "add-operation",
        help="Add a new operation to a pack (automated scaffold-to-compile pipeline)",
    )
    add_op.add_argument("operation", help="Operation name (e.g. show_bgp_peers)")
    add_op.add_argument("--command", required=True, help="XML command string")
    add_op.add_argument("--category", required=True, help="Category (system/network/routing/vpn/security/logs)")
    add_op.add_argument("--description", required=True, help="One-line description")
    add_op.add_argument("--type", dest="op_type", default="op", choices=["op", "log"], help="Operation type")
    add_op.add_argument("--log-type", default="", help="Log channel name (required for --type log)")
    add_op.add_argument("--pack", default="paloalto-firewall-xml", help="Pack name")
    add_op.add_argument("--pack-root", default=None, help="Path to pack source root")
    add_op.add_argument("--sample-from-device", default=None, metavar="DEVICE", help="Capture live XML from this device")
    add_op.add_argument("--sample-xml", default=None, help="Path to a file containing XML sample")
    add_op.add_argument("--skip-parser", action="store_true", help="Skip parser spec generation (raw output)")
    add_op.add_argument("--dry-run", action="store_true", help="Show what would be generated without writing")


def _add_allowlist_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'allowlist' subparser with list/show/enable/disable/clear/audit actions."""
    al_parser = subparsers.add_parser(
        "allowlist",
        help="Manage per-pack operation allowlists (default-deny permissions)",
    )
    al_sub = al_parser.add_subparsers(dest="allowlist_action", title="allowlist actions")

    # allowlist list
    al_sub.add_parser("list", help="List all installed packs with enabled/total counts")

    # allowlist show <pack>
    show_parser = al_sub.add_parser("show", help="Show catalog with checkboxes for a pack")
    show_parser.add_argument("pack", help="Pack name")

    # allowlist enable <pack> [<op>...] [--category <name>] [--all [--yes]]
    enable_parser = al_sub.add_parser("enable", help="Enable one or more operations")
    enable_parser.add_argument("pack", help="Pack name")
    enable_parser.add_argument(
        "ops",
        nargs="*",
        metavar="OP",
        help="Operation name(s) to enable",
    )
    enable_parser.add_argument(
        "--category",
        default=None,
        metavar="NAME",
        help="Enable all read_only ops in this category",
    )
    enable_parser.add_argument(
        "--all",
        action="store_true",
        default=False,
        help="Enable all read_only ops in the catalog (requires --yes)",
    )
    enable_parser.add_argument(
        "--yes",
        action="store_true",
        default=False,
        help="Confirm bulk-enable (required with --all)",
    )

    # allowlist disable <pack> <op>...
    disable_parser = al_sub.add_parser("disable", help="Disable one or more operations")
    disable_parser.add_argument("pack", help="Pack name")
    disable_parser.add_argument(
        "ops",
        nargs="+",
        metavar="OP",
        help="Operation name(s) to disable",
    )

    # allowlist clear <pack> [--yes]
    clear_parser = al_sub.add_parser("clear", help="Clear all enabled operations for a pack")
    clear_parser.add_argument("pack", help="Pack name")
    clear_parser.add_argument(
        "--yes",
        action="store_true",
        default=False,
        help="Confirm clearing the allowlist",
    )

    # allowlist audit
    al_sub.add_parser("audit", help="Cross-check devices.yaml against pack allowlists")


def _add_credential_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'credential' subcommand group with audit/providers actions."""
    cred_parser = subparsers.add_parser(
        "credential",
        help="Credential management (audit, list providers)",
    )
    cred_sub = cred_parser.add_subparsers(
        dest="credential_action", title="credential actions"
    )

    # credential audit [--max-age-days N] [--config PATH]
    audit_parser = cred_sub.add_parser(
        "audit",
        help="Audit device credentials for availability and staleness",
    )
    audit_parser.add_argument(
        "--max-age-days",
        dest="max_age_days",
        type=int,
        default=90,
        metavar="DAYS",
        help="Flag credentials not rotated within DAYS days as stale (default: 90)",
    )
    audit_parser.add_argument(
        "--config",
        dest="audit_config",
        default=None,
        metavar="PATH",
        help="Path to devices.yaml (defaults to the standard search order)",
    )

    # credential providers
    cred_sub.add_parser(
        "providers",
        help="List registered credential providers",
    )


def _add_init_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'init' subparser for first-install config bootstrapping."""
    init_parser = subparsers.add_parser(
        "init",
        help="Bootstrap a user config directory with a template devices.yaml",
    )
    init_parser.add_argument(
        "--local",
        action="store_true",
        default=False,
        help="Write to ./config/ instead of the user config directory",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Overwrite an existing devices.yaml",
    )
    init_parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        dest="dry_run",
        help="Print what would be created without writing any files",
    )
    init_parser.add_argument(
        "--cache-dir",
        action="store_true",
        default=False,
        dest="create_cache_dir",
        help="Also pre-create the user cache directory",
    )


def _add_standards_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'standards' subparser with list/check actions."""
    std_parser = subparsers.add_parser(
        "standards",
        help="List and validate code development standards",
    )
    std_sub = std_parser.add_subparsers(dest="standards_action", title="standards actions")

    # standards list
    std_sub.add_parser("list", help="List all defined code standards")

    # standards check [--category CAT] [--standard NAME]
    check_parser = std_sub.add_parser("check", help="Validate code against standards")
    check_parser.add_argument(
        "--category",
        dest="standards_category",
        default=None,
        metavar="CATEGORY",
        help="Check all standards in this category",
    )
    check_parser.add_argument(
        "--standard",
        dest="standards_name",
        default=None,
        metavar="NAME",
        help="Check a specific standard by name",
    )


def _add_vault_subparser(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the 'vault' subcommand group if netsight-vault is installed."""
    try:
        from netsight_vault.vault_cli import add_vault_subparsers
        add_vault_subparsers(subparsers)
    except ImportError:
        # netsight-vault not installed — add a stub that tells the user
        vault_parser = subparsers.add_parser(
            "vault",
            help="Encrypted credential vault (requires: pip install netsight-vault)",
        )
        vault_parser.set_defaults(
            vault_not_installed=True,
        )


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------


def _setup_logging(verbose: bool) -> None:
    """Configure root and netsight logger based on verbosity.

    Parameters
    ----------
    verbose:
        If ``True``, set the netsight logger to DEBUG level; otherwise INFO.
    """
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.getLogger("netsight").setLevel(level)


# ---------------------------------------------------------------------------
# Dispatch handlers
# ---------------------------------------------------------------------------


def _run_show(args: argparse.Namespace) -> int:
    """Execute a 'show' query against a device.

    Loads config, looks up the plugin, creates a client, executes the
    mapped operation, formats the result, and prints it.

    Parameters
    ----------
    args:
        Parsed namespace containing: config, device, operation, format,
        timeout, save.

    Returns
    -------
    int
        0 on success, 1 on any error.
    """
    from netsight.config import ConfigLoader
    from netsight.config_mgmt.user_config import resolve_config_file
    from netsight.exceptions import NetSightError
    from netsight.registry import plugin_registry

    # Resolve CLI operation name to plugin operation name
    plugin_operation = _SHOW_OPERATION_MAP.get(args.operation)
    if plugin_operation is None:
        logger.error("Unknown show operation: %s", args.operation)
        return 1

    config_path = args.config or (
        str(resolve_config_file("devices.yaml"))
        if resolve_config_file("devices.yaml") is not None
        else None
    )
    if config_path is None:
        print(
            "No devices.yaml found. Run `netsight init` to create a template, "
            "then edit it to add your devices."
        )
        return 1

    try:
        # Use the SDK's LocalBackend which compiles the resolved_config
        # from the pack catalog and passes it to the client constructor.
        # Direct client construction (client_cls(config=device_cfg)) is
        # no longer valid after the pack-design refactor made
        # resolved_config mandatory.
        from netsight.sdk.local import LocalBackend
        backend = LocalBackend(config_path=config_path)
        raw_result = backend.execute(
            device_name=args.device,
            operation=plugin_operation,
        )
    except NetSightError as exc:
        logger.error("Execution error: %s", exc)
        return 1

    formatted = _format_output(raw_result, args.format)
    print(formatted)

    if args.save:
        _persist_result(device_name=args.device, operation=plugin_operation, data=raw_result)

    return 0


def _format_output(data: Any, fmt: str) -> str:
    """Convert *data* to a displayable string using the chosen format.

    Parameters
    ----------
    data:
        Raw device response.
    fmt:
        One of 'dict', 'json', 'table', 'raw'.

    Returns
    -------
    str
        Formatted output ready for printing.
    """
    from netsight.output import OutputFormatter

    try:
        result = OutputFormatter.format(data, fmt)
        if not isinstance(result, str):
            import json as _json
            return _json.dumps(result, indent=2, default=str)
        return result
    except Exception as exc:  # noqa: BLE001
        logger.warning("Formatting failed (%s), falling back to raw: %s", fmt, exc)
        return str(data)


def _persist_result(device_name: str, operation: str, data: Any) -> None:
    """Store a query result in the local SQLite data store.

    Parameters
    ----------
    device_name:
        Logical device name for the result record.
    operation:
        Operation string that was executed.
    data:
        Raw result payload.  Dict is used directly; str payloads are wrapped.
    """
    from netsight.data.manager import DataManager
    from netsight.data.models import QueryResult

    payload: dict[str, Any] = data if isinstance(data, dict) else {"raw": str(data)}

    result = QueryResult(device_name=device_name, operation=operation, data=payload)
    with DataManager("storage/netsight.db") as dm:
        dm.store(result)
    logger.info("Result saved: id=%s", result.id)


def _run_plugins_list() -> int:
    """Discover installed packs then list all registered plugins.

    Iterates ``pack_registry`` directly (rather than ``plugin_registry``)
    so the richer :class:`~netsight.packs.registry.PackInfo` metadata —
    vendor, device_type, protocol, version — is available. Renders one
    row per pack with an ``Ops`` count column; use ``netsight operations
    list`` for the full per-operation drill-down.

    Returns
    -------
    int
        Always 0.
    """
    from rich.console import Console
    from rich.table import Table

    from netsight.packs import pack_registry

    pack_registry.ensure_loaded()

    packs = pack_registry.list()
    load_errors = pack_registry.load_errors()

    if not packs and not load_errors:
        print("No plugins registered.")
        return 0

    console = Console()
    table = Table(
        show_header=True,
        header_style="bold",
        title="Registered plugins",
        title_justify="left",
        expand=False,
    )
    # Columns kept narrow on purpose: vendor / device_type / protocol
    # are already encoded in ``pack.name`` (``<vendor>-<type>-<proto>``),
    # so a separate column per component just adds noise. Drill-down
    # details are one command away via ``netsight operations list``.
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Version", style="dim", no_wrap=True)
    table.add_column("Ops", justify="right", style="green", no_wrap=True)
    table.add_column("Client class", no_wrap=True)

    for pack in sorted(packs, key=lambda p: p.name):
        public_ops = pack.allowed_operations - {"keygen"}
        table.add_row(
            pack.name,
            pack.version or "—",
            str(len(public_ops)),
            pack.client_class.__name__,
        )

    for name in sorted(load_errors):
        exc = load_errors[name]
        table.add_row(
            f"[bold red]{name}[/bold red]",
            "—",
            "—",
            f"[bold red]LOAD_ERROR: {exc}[/bold red]",
        )

    console.print(table)
    console.print(
        "[dim]Tip: run `netsight operations list` for the full per-op "
        "breakdown.[/dim]"
    )
    return 0


def _run_operations_list() -> int:
    """List all operations across all registered plugins.

    Renders one Rich table per pack, one row per operation. This is
    the drill-down companion to ``netsight plugins list``, which only
    shows a summary ``Ops`` count.

    Returns
    -------
    int
        Always 0.
    """
    from rich.console import Console
    from rich.table import Table

    from netsight.packs import pack_registry

    pack_registry.ensure_loaded()

    packs = pack_registry.list()
    if not packs:
        print("No plugins registered. Try running 'netsight plugins list' first.")
        return 0

    console = Console()
    for pack in sorted(packs, key=lambda p: p.name):
        public_ops = sorted(pack.allowed_operations - {"keygen"})
        if not public_ops:
            continue
        table = Table(
            show_header=True,
            header_style="bold",
            title=(
                f"[cyan]{pack.name}[/cyan] "
                f"(v{pack.version}) — {len(public_ops)} operation(s)"
            ),
            title_justify="left",
            expand=False,
        )
        table.add_column("#", justify="right", style="dim", width=4)
        table.add_column("Operation", style="green")
        for idx, op in enumerate(public_ops, start=1):
            table.add_row(str(idx), op)
        console.print(table)

    return 0


def _run_snapshot(args: argparse.Namespace) -> int:
    """Take a full device snapshot by executing all supported show operations.

    Parameters
    ----------
    args:
        Parsed namespace with: config, device.

    Returns
    -------
    int
        0 on success, 1 on error.
    """
    from netsight.config import ConfigLoader
    from netsight.config_mgmt.user_config import resolve_config_file
    from netsight.data.manager import DataManager
    from netsight.data.models import QueryResult
    from netsight.exceptions import NetSightError
    from netsight.output import OutputFormatter
    from netsight.registry import plugin_registry

    if not args.device:
        logger.error("--device is required for the snapshot subcommand")
        return 1

    config_path = args.config or (
        str(resolve_config_file("devices.yaml"))
        if resolve_config_file("devices.yaml") is not None
        else None
    )
    if config_path is None:
        print(
            "No devices.yaml found. Run `netsight init` to create a template, "
            "then edit it to add your devices."
        )
        return 1

    results: list[QueryResult] = []

    try:
        # Use LocalBackend which compiles the resolved_config from the
        # pack catalog. Direct client construction is not valid after
        # the pack-design refactor made resolved_config mandatory.
        from netsight.sdk.local import LocalBackend
        backend = LocalBackend(config_path=config_path)

        for cli_op, plugin_op in _SHOW_OPERATION_MAP.items():
            try:
                raw = backend.execute(
                    device_name=args.device,
                    operation=plugin_op,
                )
                payload: dict[str, Any] = (
                    OutputFormatter.to_dict(raw) if isinstance(raw, str) else raw
                )
                results.append(
                    QueryResult(
                        device_name=args.device,
                        operation=plugin_op,
                        data=payload,
                    )
                )
                logger.info("Snapshotted %s", plugin_op)
            except NetSightError as op_exc:
                logger.warning("Skipping %s: %s", cli_op, op_exc)
    except NetSightError as exc:
        logger.error("Snapshot error: %s", exc)
        return 1

    with DataManager("storage/netsight.db") as dm:
        snapshot = dm.create_snapshot(device_name=args.device, results=results)

    print(f"Snapshot created: id={snapshot.id} ({len(results)} operations)")
    return 0


def _run_diff(args: argparse.Namespace) -> int:
    """Display a diff between two snapshots identified by date/ID strings.

    Parameters
    ----------
    args:
        Parsed namespace with: from, to.

    Returns
    -------
    int
        0 on success, 1 on error.
    """
    from_val = getattr(args, "from", None)
    to_val = args.to

    if not from_val or not to_val:
        logger.error("Both --from and --to are required for diff")
        return 1

    from netsight.data.manager import DataManager

    try:
        with DataManager("storage/netsight.db") as dm:
            diff_result = dm.diff(from_val, to_val)
        print(_format_output(diff_result.to_dict(), args.format))
    except KeyError as exc:
        logger.error("Snapshot not found: %s", exc)
        return 1
    except Exception as exc:  # noqa: BLE001
        logger.error("Diff error: %s", exc)
        return 1

    return 0


def _run_history(args: argparse.Namespace) -> int:
    """Show historical query results for a device/operation.

    Parameters
    ----------
    args:
        Parsed namespace with: device, operation, last.

    Returns
    -------
    int
        0 on success, 1 on error.
    """
    from netsight.data.manager import DataManager

    # Resolve device: CLI --device takes precedence over subcommand --device
    device_name = getattr(args, "device", None)

    try:
        with DataManager("storage/netsight.db") as dm:
            results = dm.search(
                device_name=device_name,
                operation=getattr(args, "operation", None),
                limit=100,
            )
    except Exception as exc:  # noqa: BLE001
        logger.error("History query error: %s", exc)
        return 1

    if not results:
        print("No history found.")
        return 0

    rows = [
        {
            "id": r.id[:8],
            "device": r.device_name,
            "operation": r.operation,
            "timestamp": r.timestamp.isoformat(),
        }
        for r in results
    ]
    print(_format_output(rows, args.format))
    return 0


def _run_template(args: argparse.Namespace) -> int:
    """Dispatch template sub-actions (create/list/run/delete).

    Parameters
    ----------
    args:
        Parsed namespace with: template_action, name (where applicable), ops.

    Returns
    -------
    int
        0 on success, 1 on error.
    """
    from netsight.data.manager import DataManager
    from netsight.data.models import Template

    action = getattr(args, "template_action", None)

    if action == "create":
        ops_str = getattr(args, "ops", None) or ""
        operations = [o.strip() for o in ops_str.split(",") if o.strip()]
        template = Template(name=args.name, operations=operations)
        with DataManager("storage/netsight.db") as dm:
            dm.save_template(template)
        print(f"Template '{args.name}' created with {len(operations)} operation(s).")
        return 0

    if action == "list":
        with DataManager("storage/netsight.db") as dm:
            templates = dm.list_templates()
        if not templates:
            print("No templates saved.")
            return 0
        for t in templates:
            print(f"{t.name}: {', '.join(t.operations)}")
        return 0

    if action == "run":
        with DataManager("storage/netsight.db") as dm:
            template_opt = dm.get_template(args.name)
        if template_opt is None:
            logger.error("Template '%s' not found", args.name)
            return 1
        template = template_opt
        print(f"Running template '{args.name}': {', '.join(template.operations)}")
        # Delegate each operation to _run_show via synthetic args
        for op in template.operations:
            logger.info("Template op: %s", op)
        return 0

    if action == "delete":
        with DataManager("storage/netsight.db") as dm:
            deleted = dm.delete_template(args.name)
        if deleted:
            print(f"Template '{args.name}' deleted.")
        else:
            logger.error("Template '%s' not found", args.name)
            return 1
        return 0

    logger.error("Unknown template action: %s", action)
    return 1


def _run_parse(args: argparse.Namespace) -> int:
    """Dispatch parse sub-actions (refs/impact/tree/validate).

    This is a stub implementation — the full parser engine is expected to
    be contributed by the netsight.parsers sub-package.

    Parameters
    ----------
    args:
        Parsed namespace with: parse_action, and action-specific options.

    Returns
    -------
    int
        0 on success, 1 on unknown action.
    """
    action = getattr(args, "parse_action", None)

    if action == "refs":
        rule = getattr(args, "rule", None)
        print(f"parse refs: rule={rule!r} — (stub: parser engine not yet implemented)")
        return 0

    if action == "impact":
        obj = getattr(args, "object", None)
        print(f"parse impact: object={obj!r} — (stub: parser engine not yet implemented)")
        return 0

    if action == "tree":
        root = getattr(args, "root", None)
        print(f"parse tree: root={root!r} — (stub: parser engine not yet implemented)")
        return 0

    if action == "validate":
        print("parse validate — (stub: parser engine not yet implemented)")
        return 0

    logger.error("Unknown parse action: %s", action)
    return 1


def _run_config_compile(args: argparse.Namespace) -> int:
    """Compile TOML vendor configs to JSON.

    Parameters
    ----------
    args:
        Parsed namespace with: compile_vendor (optional), validate_only.

    Returns
    -------
    int
        0 on success, 1 on any compilation error.
    """
    from netsight.config_mgmt.compiler import ConfigCompiler
    from netsight.packs import pack_registry
    from pathlib import Path

    pack_registry.ensure_loaded()

    config_dir = getattr(args, "config_dir", None) or "config/vendors"
    validate_only = getattr(args, "validate_only", False)

    if getattr(args, "compile_vendor", None):
        # Legacy single-vendor compile
        compiler = ConfigCompiler(config_dir)
        result = compiler.compile_vendor(
            args.compile_vendor,
            validate_only=validate_only,
        )
        if result.success:
            print(
                f"Compiled {args.compile_vendor}: "
                f"{len(result.models_compiled)} models"
            )
            return 0
        else:
            for err in result.errors:
                print(f"  ERROR: {err}")
            return 1

    # Compile all: try pack-mode first (installed packs), then legacy
    packs = pack_registry.list()
    if packs:
        # Pack-mode compile — each installed pack's catalog
        pack_roots = {p.name: p.config_root for p in packs}
        compiler = ConfigCompiler(pack_roots=pack_roots)
        results = {}
        for name in pack_roots:
            result = compiler.compile_pack(
                name=name,
                validate_only=validate_only,
            )
            results[name] = result
    elif Path(config_dir).is_dir():
        # Legacy fallback — vendor config directory
        compiler = ConfigCompiler(config_dir)
        results = compiler.compile_all()
    else:
        print("No packs installed and no vendor configs found.")
        return 1

    # Print results
    failed = False
    for name, result in results.items():
        ops_count = len(result.resolved.get("operations", {})) if hasattr(result, "resolved") and result.resolved else 0
        status_str = "OK" if result.success else "FAILED"
        models_str = f", {len(result.models_compiled)} models" if hasattr(result, "models_compiled") and result.models_compiled else ""
        print(f"  {name}: {status_str} ({ops_count} operations{models_str})")
        for err in result.errors:
            print(f"    ERROR: {err}")
        if not result.success:
            failed = True
    return 1 if failed else 0


def _run_config_show(args: argparse.Namespace) -> int:
    """Show resolved (compiled) config for a given vendor/model.

    Parameters
    ----------
    args:
        Parsed namespace with: vendor, model, instance (optional).

    Returns
    -------
    int
        0 on success, 1 if the config is not found.
    """
    import json
    from pathlib import Path

    from netsight.config_mgmt.store import FileConfigStore

    resolved = None
    instance = getattr(args, "instance", None)

    # Try 1: legacy vendor config store
    try:
        store = FileConfigStore("config/vendors")
        resolved = store.get_resolved(args.vendor, args.model, instance)
    except FileNotFoundError:
        pass

    # Try 2: pack-cache compiled output
    if resolved is None:
        try:
            from netsight.config_mgmt.user_config import resolve_cache_dir
            cache_dir = resolve_cache_dir()
            # Pack-mode uses pack name as the vendor key
            for model_dir in [args.model, "default"]:
                compiled_path = Path(cache_dir) / "compiled" / args.vendor / model_dir / "resolved.json"
                if compiled_path.is_file():
                    resolved = json.loads(compiled_path.read_text(encoding="utf-8"))
                    break
        except Exception:
            pass

    if resolved is None:
        print(
            f"No compiled config found for vendor={args.vendor!r}, "
            f"model={args.model!r}. Run `netsight config compile` first."
        )
        return 1

    print(json.dumps(resolved, indent=2))
    return 0


def _run_vendor_list(args: argparse.Namespace) -> int:  # noqa: ARG001
    """List all installed vendor packs with their operation counts.

    Shows data from the pack registry rather than the legacy
    ``config/vendors/`` directory (which no longer exists after the
    pack-design refactor).
    """
    from rich.console import Console
    from rich.table import Table

    from netsight.packs import pack_registry

    pack_registry.ensure_loaded()
    packs = pack_registry.list()

    if not packs:
        print("No vendor packs installed.")
        return 0

    console = Console()
    table = Table(
        title="Installed vendor packs",
        title_justify="left",
        show_header=True,
        header_style="bold",
        expand=False,
    )
    table.add_column("Pack", style="cyan", no_wrap=True)
    table.add_column("Vendor", no_wrap=True)
    table.add_column("Type", no_wrap=True)
    table.add_column("Protocol", no_wrap=True)
    table.add_column("Version", style="dim", no_wrap=True)
    table.add_column("Ops", justify="right", style="green", no_wrap=True)

    for pack in sorted(packs, key=lambda p: p.name):
        table.add_row(
            pack.name,
            pack.vendor,
            pack.device_type,
            pack.protocol,
            pack.version,
            str(len(pack.allowed_operations)),
        )

    console.print(table)

    return 0


def _run_devices_list(args: argparse.Namespace) -> int:
    """List all configured devices from devices.yaml."""
    from rich.console import Console
    from rich.table import Table

    from netsight.config import ConfigLoader

    config_path = getattr(args, "config", None) or "config/devices.yaml"
    try:
        loader = ConfigLoader(config_path)
    except Exception:
        print("No devices.yaml found. Run `netsight init` to create one.")
        return 0
    devices = loader.get_devices()

    if not devices:
        print("No devices configured in devices.yaml.")
        return 0

    console = Console()
    table = Table(
        title=f"Configured devices ({config_path})",
        title_justify="left",
        show_header=True,
        header_style="bold",
        expand=False,
    )
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Host", no_wrap=True)
    table.add_column("API Type", no_wrap=True)
    table.add_column("Username", no_wrap=True)
    table.add_column("Vendor", no_wrap=True)
    table.add_column("Model", no_wrap=True)

    for device in devices:
        table.add_row(
            device.name,
            device.host,
            device.api_type,
            device.username,
            device.vendor or "—",
            device.model or "—",
        )

    console.print(table)
    return 0


# ---------------------------------------------------------------------------
# Init subcommand handler
# ---------------------------------------------------------------------------


def _run_init(args: argparse.Namespace) -> int:
    """Bootstrap a user config directory with a template devices.yaml.

    Steps
    -----
    1. Resolve the target directory (``--local`` → ``./config/``,
       otherwise the user config dir from
       :func:`~netsight.config_mgmt.user_config.resolve_config_dir`).
    2. Check if devices.yaml already exists; skip unless ``--force``.
    3. If ``--dry-run``, print intent and exit 0.
    4. Create the target directory (mode ``0o700`` on POSIX).
    5. Write the bundled ``devices.yaml.example`` template.
    6. If ``--cache-dir``, also pre-create the user cache directory.
    7. Print next-steps guidance.

    Parameters
    ----------
    args:
        Parsed namespace with: local, force, dry_run, create_cache_dir.

    Returns
    -------
    int
        0 on success.
    """
    import importlib.resources
    import os
    import stat
    from pathlib import Path

    from netsight.config_mgmt.user_config import resolve_cache_dir, resolve_config_dir

    # --- Step 1: resolve target directory. ---
    if getattr(args, "local", False):
        target_dir = Path.cwd() / "config"
    else:
        target_dir = resolve_config_dir()

    target_file = target_dir / "devices.yaml"

    # --- Step 2: check for existing file. ---
    if target_file.exists() and not getattr(args, "force", False):
        print(
            f"devices.yaml already exists at {target_file}\n"
            "Run with --force to overwrite."
        )
        return 0

    # --- Step 3: dry-run short circuit. ---
    if getattr(args, "dry_run", False):
        print(f"Would create: {target_file}")
        if getattr(args, "create_cache_dir", False):
            cache = resolve_cache_dir()
            print(f"Would create cache dir: {cache}")
        return 0

    # --- Step 5a: create target directory. ---
    target_dir.mkdir(parents=True, exist_ok=True)

    # Restrict permissions to owner-only on POSIX so credentials that
    # land here are not world-readable.
    if os.name == "posix":
        target_dir.chmod(stat.S_IRWXU)

    # --- Step 5b: read and write the template. ---
    defaults_pkg = importlib.resources.files("netsight.config_mgmt._defaults")
    template_text = (defaults_pkg / "devices.yaml.example").read_text(encoding="utf-8")
    target_file.write_text(template_text, encoding="utf-8")

    print(f"Created {target_file} (template)")

    # --- Step 6: optionally pre-create cache dir. ---
    if getattr(args, "create_cache_dir", False):
        cache_dir = resolve_cache_dir()
        cache_dir.mkdir(parents=True, exist_ok=True)
        print(f"Created cache dir: {cache_dir}")

    # --- Step 7: print next-steps guidance. ---
    print(
        f"\nNext steps:\n"
        f"  1. Edit {target_file} to add your devices.\n"
        f"  2. Install a pack:   netsight pack install paloalto-firewall-xml\n"
        f"  3. Verify the env:   netsight doctor\n"
        f"  4. Query a device:   netsight --device my-fw show system-info"
    )

    return 0


# ---------------------------------------------------------------------------
# Doctor subcommand handler
# ---------------------------------------------------------------------------


def _run_doctor(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Verify the NetSight dev environment and print a status report.

    Runs every check in :func:`netsight.mcp_dev.doctor.run_checks`
    against the current working directory and renders a human-readable
    ``[ ok ]`` / ``[FAIL]`` line per check. Returns ``0`` when every
    check passes and ``1`` otherwise, suitable for shell ``&&`` chaining
    during bootstrap or CI.

    Parameters
    ----------
    args:
        Parsed namespace (unused — the handler reads only ``Path.cwd()``).

    Returns
    -------
    int
        ``0`` on success, ``1`` if any check failed.
    """
    from pathlib import Path

    from netsight.mcp_dev.doctor import run_checks

    root = Path.cwd()
    results = run_checks(root)

    print(f"NetSight dev environment — running checks from {root}\n")

    failed = 0
    name_width = max(len(name) for name, _ok, _msg in results)
    for name, ok, message in results:
        marker = "[ ok ]" if ok else "[FAIL]"
        print(f"  {marker}  {name:<{name_width}}  {message}")
        if not ok:
            failed += 1

    print()
    if failed:
        print(
            f"{failed} check(s) failed. Fix the issues above before starting "
            f"the dev MCP server."
        )
        return 1

    print(
        "All checks passed. Run `claude` in this directory to load the "
        "netsight-dev MCP server."
    )
    return 0


# ---------------------------------------------------------------------------
# Pack subcommand handler
# ---------------------------------------------------------------------------


def _run_pack(args: argparse.Namespace) -> int:
    """Dispatch pack sub-actions (list/search/install/info/uninstall/doctor).

    Parameters
    ----------
    args:
        Parsed namespace with ``pack_action`` and action-specific options.

    Returns
    -------
    int
        0 on success, 1 on error or unknown action.
    """
    from netsight.packs.cli import (
        _run_pack_list,
        _run_pack_search,
        _run_pack_install,
        _run_pack_info,
        _run_pack_uninstall,
        _run_pack_doctor,
    )

    action = getattr(args, "pack_action", None)

    if action == "list":
        return _run_pack_list(args)
    if action == "search":
        return _run_pack_search(args)
    if action == "install":
        return _run_pack_install(args)
    if action == "info":
        return _run_pack_info(args)
    if action == "uninstall":
        return _run_pack_uninstall(args)
    if action == "doctor":
        return _run_pack_doctor(args)
    if action == "add-operation":
        return _run_pack_add_operation(args)

    logger.error("Unknown pack action: %s", action)
    return 1


def _run_pack_add_operation(args: argparse.Namespace) -> int:
    """Run the automated add-operation pipeline."""
    from pathlib import Path
    from netsight.packs.add_operation import add_operation

    sample_xml = ""
    if args.sample_xml:
        sample_xml = Path(args.sample_xml).read_text(encoding="utf-8")

    result = add_operation(
        operation=args.operation,
        command=args.command,
        category=args.category,
        description=args.description,
        op_type=args.op_type,
        log_type=args.log_type,
        pack_name=args.pack,
        pack_root=Path(args.pack_root) if args.pack_root else None,
        device_name=args.sample_from_device,
        config_path=getattr(args, "config", None) or "config/devices.yaml",
        sample_xml=sample_xml,
        write=not args.dry_run,
        skip_parser=args.skip_parser,
    )

    if result.success:
        print(f"Operation '{result.operation}' added successfully!")
        if result.files_written:
            print(f"Files written:")
            for f in result.files_written:
                print(f"  {f}")
        if result.warnings:
            print(f"Warnings:")
            for w in result.warnings:
                print(f"  {w}")
        return 0
    else:
        print(f"Failed to add operation '{result.operation}':")
        for e in result.errors:
            print(f"  ERROR: {e}")
        return 1


# ---------------------------------------------------------------------------
# Allowlist subcommand handler
# ---------------------------------------------------------------------------


def _run_allowlist(args: argparse.Namespace) -> int:
    """Dispatch allowlist sub-actions (list/show/enable/disable/clear/audit).

    Parameters
    ----------
    args:
        Parsed namespace with ``allowlist_action`` and action-specific options.

    Returns
    -------
    int
        0 on success, 1 on error or unknown action.
    """
    from netsight.packs.allowlist_cli import (
        _run_allowlist_audit,
        _run_allowlist_clear,
        _run_allowlist_disable,
        _run_allowlist_enable,
        _run_allowlist_list,
        _run_allowlist_show,
    )

    action = getattr(args, "allowlist_action", None)

    if action == "list":
        return _run_allowlist_list(args)
    if action == "show":
        return _run_allowlist_show(args)
    if action == "enable":
        return _run_allowlist_enable(args)
    if action == "disable":
        return _run_allowlist_disable(args)
    if action == "clear":
        return _run_allowlist_clear(args)
    if action == "audit":
        return _run_allowlist_audit(args)

    logger.error("Unknown allowlist action: %s", action)
    return 1


# ---------------------------------------------------------------------------
# Security subcommand handlers
# ---------------------------------------------------------------------------


def _run_security_audit(args: argparse.Namespace) -> int:
    """Run a security audit and print the JSON report."""
    import json

    from netsight.security.audit import AuditOrchestrator

    orch = AuditOrchestrator()
    if getattr(args, "code_only", False):
        report = orch.audit_code_only()
    elif getattr(args, "deps_only", False):
        report = orch.audit_deps_only()
    else:
        report = orch.audit_full()
    print(json.dumps(report, indent=2, default=str))
    if orch.has_critical(report):
        return 1
    return 0


def _run_security_verify(args: argparse.Namespace) -> int:
    """Verify a package version against known_safe.toml."""
    from netsight.security.dependencies import DependencyAuditor

    auditor = DependencyAuditor()
    result = auditor.verify_package(args.package, args.version)
    print(f"{result['status']}: {result['message']}")
    return 0 if result["status"] == "ok" else 1


def _run_security_policies(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Show active security policies."""
    import json

    from netsight.security.audit import load_policies

    print(json.dumps(load_policies(), indent=2))
    return 0


# ---------------------------------------------------------------------------
# Credential subcommand handlers
# ---------------------------------------------------------------------------


def _run_credential_audit(args: argparse.Namespace) -> int:
    """Run a credential audit and print a Rich table.

    Parameters
    ----------
    args:
        Parsed namespace with ``max_age_days`` and ``audit_config``.

    Returns
    -------
    int
        0 when all credentials are accessible (or stale but present),
        1 when any credential is missing or an error occurs.
    """
    from rich.console import Console
    from rich.table import Table

    from netsight.credentials.audit import audit_credentials

    config_path = getattr(args, "audit_config", None) or getattr(args, "config", None)
    max_age_days = getattr(args, "max_age_days", 90)

    try:
        report = audit_credentials(
            config_path=config_path,
            max_age_days=max_age_days,
        )
    except Exception as exc:  # noqa: BLE001
        logger.error("Credential audit failed: %s", exc)
        return 1

    devices = report.get("devices", [])
    summary = report.get("summary", {})

    console = Console()

    if not devices:
        console.print("[dim]No devices configured — nothing to audit.[/dim]")
        return 0

    table = Table(
        show_header=True,
        header_style="bold",
        title="Credential Audit",
        title_justify="left",
        expand=False,
    )
    table.add_column("Device", style="cyan", no_wrap=True)
    table.add_column("Provider", no_wrap=True)
    table.add_column("Key", no_wrap=True)
    table.add_column("Status", no_wrap=True)
    table.add_column("Last Rotated", no_wrap=True)

    has_problems = False
    for row in devices:
        status = row.get("status", "ok")
        last_rotated = row.get("last_rotated", "—")

        if status == "ok":
            status_cell = "[green]ok[/green]"
        elif status == "STALE":
            status_cell = "[yellow]STALE[/yellow]"
            has_problems = True
        elif status == "MISSING":
            status_cell = "[bold red]MISSING[/bold red]"
            has_problems = True
        else:
            status_cell = status

        table.add_row(
            row.get("device", "—"),
            row.get("provider", "—"),
            row.get("key", "—"),
            status_cell,
            str(last_rotated),
        )

    console.print(table)

    total = summary.get("total", 0)
    accessible = summary.get("accessible", 0)
    stale = summary.get("stale", 0)
    missing = summary.get("missing", 0)

    parts = [f"{total} device(s)", f"{accessible} ok"]
    if stale:
        parts.append(f"[yellow]{stale} stale (>{max_age_days} days)[/yellow]")
    if missing:
        parts.append(f"[bold red]{missing} missing[/bold red]")

    console.print("\nSummary: " + ", ".join(parts))

    return 1 if has_problems else 0


def _run_credential_providers(args: argparse.Namespace) -> int:  # noqa: ARG001
    """List all registered credential providers in a Rich table.

    Parameters
    ----------
    args:
        Parsed namespace (unused — all data comes from the registry).

    Returns
    -------
    int
        Always 0.
    """
    from rich.console import Console
    from rich.table import Table

    from netsight.credentials.registry import credential_provider_registry
    from netsight.credentials.provider import RotatableCredentialProvider

    credential_provider_registry.ensure_loaded()

    infos = credential_provider_registry.list()
    if not infos:
        print("No credential providers registered.")
        return 0

    console = Console()
    table = Table(
        show_header=True,
        header_style="bold",
        title="Credential Providers",
        title_justify="left",
        expand=False,
    )
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Display Name", no_wrap=True)
    table.add_column("Description")
    table.add_column("Builtin", justify="center", no_wrap=True)
    table.add_column("Rotatable", justify="center", no_wrap=True)
    table.add_column("Status", no_wrap=True)

    for info in sorted(infos, key=lambda i: i.name):
        provider = info.provider
        rotatable = (
            isinstance(provider, RotatableCredentialProvider)
            and provider.supports_rotation()
        )

        try:
            health = provider.health_check()
            status = health.get("status", "?")
        except Exception:  # noqa: BLE001
            status = "error"

        status_cell = "[green]ok[/green]" if status == "ok" else f"[red]{status}[/red]"
        table.add_row(
            info.name,
            info.display_name,
            info.description,
            "[green]yes[/green]" if info.builtin else "no",
            "[green]yes[/green]" if rotatable else "[dim]no[/dim]",
            status_cell,
        )

    console.print(table)
    return 0


# ---------------------------------------------------------------------------
# Standards subcommand handlers
# ---------------------------------------------------------------------------


def _run_standards_list() -> int:
    """List all defined code standards in a Rich table.

    Returns
    -------
    int
        Always 0.
    """
    from rich.console import Console
    from rich.table import Table

    from netsight.standards import standards_registry

    standards = standards_registry.list_standards()
    if not standards:
        print("No standards loaded.")
        return 0

    console = Console()
    table = Table(
        title="Code Development Standards",
        title_justify="left",
        show_header=True,
        header_style="bold",
        expand=False,
    )
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Category", no_wrap=True)
    table.add_column("Severity", no_wrap=True)
    table.add_column("Description")

    for s in standards:
        severity_style = "bold red" if s.severity == "error" else "yellow"
        # Truncate description at 80 chars for table readability
        desc = s.description.strip().replace("\n", " ")
        if len(desc) > 80:
            desc = desc[:77] + "..."
        table.add_row(
            s.name,
            s.category,
            f"[{severity_style}]{s.severity}[/{severity_style}]",
            desc,
        )

    console.print(table)
    console.print(f"[dim]{len(standards)} standard(s) loaded[/dim]")
    return 0


def _run_standards_check(args: argparse.Namespace) -> int:
    """Validate code against all standards or a specific one.

    Parameters
    ----------
    args:
        Parsed namespace with: standards_name, standards_category.

    Returns
    -------
    int
        0 when all checked standards pass, 1 when any error-severity
        standard fails.
    """
    from rich.console import Console
    from rich.table import Table

    from netsight.standards import standards_registry

    standard_name = getattr(args, "standards_name", None)
    category = getattr(args, "standards_category", None)

    if standard_name:
        try:
            results = [standards_registry.check_standard(name=standard_name)]
        except KeyError as exc:
            logger.error("Unknown standard: %s", exc)
            return 1
    elif category:
        results = standards_registry.check_category(category=category)
        if not results:
            print(f"No standards found in category: {category!r}")
            return 0
    else:
        results = standards_registry.check_all()

    console = Console()
    table = Table(
        title="Standards Check Results",
        title_justify="left",
        show_header=True,
        header_style="bold",
        expand=False,
    )
    table.add_column("Standard", style="cyan", no_wrap=True)
    table.add_column("Status", no_wrap=True, justify="center")
    table.add_column("Findings", justify="right", no_wrap=True)

    failed_error = False
    for r in results:
        if r.skipped:
            status_cell = "[dim]SKIP[/dim]"
            findings_cell = "—"
        elif r.passed:
            status_cell = "[green]PASS[/green]"
            findings_cell = "0"
        else:
            # Check severity to decide if this is a hard failure
            try:
                s = standards_registry.get_standard(name=r.standard)
                is_error = s.severity == "error"
            except KeyError:
                is_error = True
            if is_error:
                status_cell = "[bold red]FAIL[/bold red]"
                failed_error = True
            else:
                status_cell = "[yellow]WARN[/yellow]"
            findings_cell = str(len(r.findings))

        table.add_row(r.standard, status_cell, findings_cell)

    console.print(table)

    # Print detailed findings for failures
    for r in results:
        if not r.passed and not r.skipped and r.findings:
            console.print(f"\n[bold]Findings for '{r.standard}':[/bold]")
            for f in r.findings[:20]:
                line_info = f":{f.line}" if f.line is not None else ""
                console.print(f"  [dim]{f.file}{line_info}[/dim]  {f.message}")
            if len(r.findings) > 20:
                console.print(
                    f"  [dim]... and {len(r.findings) - 20} more findings[/dim]"
                )

    passed_count = sum(1 for r in results if r.passed)
    failed_count = sum(1 for r in results if not r.passed and not r.skipped)
    skipped_count = sum(1 for r in results if r.skipped)

    console.print(
        f"\n[dim]Checked {len(results)} standard(s): "
        f"{passed_count} passed, {failed_count} failed, {skipped_count} skipped[/dim]"
    )

    return 1 if failed_error else 0


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    """Parse CLI arguments and dispatch to the appropriate handler.

    Discovers every installed NetSight pack via
    :func:`netsight.bootstrap` before parsing arguments so subcommands
    that enumerate installed packs (``show``, ``snapshot``, ``pack
    list``, ``config compile``, etc.) see the full set.

    Parameters
    ----------
    argv:
        Argument list (defaults to ``sys.argv[1:]`` when ``None``).

    Returns
    -------
    int
        0 on success, 1 on error.
    """
    from netsight import bootstrap

    bootstrap()

    parser = build_parser()
    args = parser.parse_args(argv)

    _setup_logging(getattr(args, "verbose", False))

    subcommand = getattr(args, "subcommand", None)

    if subcommand is None:
        parser.print_help()
        return 1

    try:
        if subcommand == "show":
            return _run_show(args)

        if subcommand == "devices":
            action = getattr(args, "devices_action", None)
            if action == "list":
                return _run_devices_list(args)
            # Default: list
            return _run_devices_list(args)

        if subcommand == "plugins":
            action = getattr(args, "plugins_action", None)
            if action == "list":
                return _run_plugins_list()
            logger.error("Unknown plugins action: %s", action)
            return 1

        if subcommand == "operations":
            action = getattr(args, "operations_action", None)
            if action == "list":
                return _run_operations_list()
            logger.error("Unknown operations action: %s", action)
            return 1

        if subcommand == "snapshot":
            return _run_snapshot(args)

        if subcommand == "diff":
            return _run_diff(args)

        if subcommand == "history":
            return _run_history(args)

        if subcommand == "template":
            return _run_template(args)

        if subcommand == "parse":
            return _run_parse(args)

        if subcommand == "config":
            if args.config_action == "compile":
                return _run_config_compile(args)
            elif args.config_action == "show":
                return _run_config_show(args)

        if subcommand == "vendor":
            if args.vendor_action == "list":
                return _run_vendor_list(args)

        if subcommand == "dev-mcp":
            from netsight.mcp_dev.cli import run as run_dev_mcp
            return run_dev_mcp()

        if subcommand == "init":
            return _run_init(args)

        if subcommand == "doctor":
            return _run_doctor(args)

        if subcommand == "pack":
            return _run_pack(args)

        if subcommand == "allowlist":
            return _run_allowlist(args)

        if subcommand == "vault":
            if getattr(args, "vault_not_installed", False):
                print(
                    "The vault requires the netsight-vault package.\n"
                    "Install with: pip install netsight-vault",
                    file=sys.stderr,
                )
                return 2
            from netsight_vault.vault_cli import run_vault
            return run_vault(args)

        if subcommand == "security":
            sec_action = getattr(args, "sec_action", None)
            if sec_action == "audit":
                return _run_security_audit(args)
            if sec_action == "verify":
                return _run_security_verify(args)
            if sec_action == "policies":
                return _run_security_policies(args)
            logger.error("Unknown security action: %s", sec_action)
            return 1

        if subcommand == "credential":
            cred_action = getattr(args, "credential_action", None)
            if cred_action == "audit":
                return _run_credential_audit(args)
            if cred_action == "providers":
                return _run_credential_providers(args)
            logger.error("Unknown credential action: %s", cred_action)
            return 1

        if subcommand == "standards":
            standards_action = getattr(args, "standards_action", None)
            if standards_action == "list":
                return _run_standards_list()
            if standards_action == "check":
                return _run_standards_check(args)
            # Default: list
            return _run_standards_list()

    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001
        logger.error("Unexpected error: %s", exc, exc_info=True)
        return 1

    logger.error("Unhandled subcommand: %s", subcommand)
    return 1


if __name__ == "__main__":
    sys.exit(main())
