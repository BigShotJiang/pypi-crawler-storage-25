"""JSON-RPC over stdio transport for MCP dev server.

Implements the minimum subset of the Model Context Protocol required to
handshake with clients like Claude Code:

- ``initialize`` — capability negotiation (required first method)
- ``initialized`` — post-handshake notification (no response)
- ``resources/list`` / ``resources/read``
- ``tools/list`` / ``tools/call``
- ``ping`` — liveness probe

Notifications (requests with no ``id``) are processed without sending
a response, per the JSON-RPC 2.0 spec.
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Any

logger = logging.getLogger(__name__)

# MCP protocol version this server speaks. Matches the current Anthropic
# Claude Code client expectation as of 2025-06-18.
PROTOCOL_VERSION = "2025-06-18"

SERVER_INFO = {
    "name": "netsight-dev",
    "version": "0.1.0",
}

SERVER_CAPABILITIES: dict[str, Any] = {
    "resources": {},
    "tools": {},
}


def run_stdio(server: Any) -> None:
    """Run the MCP server over stdio.

    Reads JSON-RPC messages line-by-line from stdin and writes responses to stdout.
    """
    logger.info("NetSight Dev MCP server started (stdio)")
    server.start()
    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                _send_error(None, -32700, "Parse error")
                continue

            req_id = request.get("id")
            method = request.get("method", "")
            params = request.get("params") or {}
            is_notification = req_id is None

            try:
                result = _dispatch(server, method, params)
            except _MethodNotFound as e:
                if not is_notification:
                    _send_error(req_id, -32601, str(e))
                continue
            except Exception as e:
                logger.error("Dispatch error: %s", e, exc_info=True)
                if not is_notification:
                    _send_error(req_id, -32603, str(e))
                continue

            # Notifications never receive a response, even on success.
            if is_notification:
                continue
            _send_result(req_id, result)
    finally:
        server.stop()


class _MethodNotFound(Exception):
    """Raised when a method is not recognised — maps to JSON-RPC -32601."""


def _dispatch(server: Any, method: str, params: dict[str, Any]) -> Any:
    # Handshake
    if method == "initialize":
        return {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": SERVER_CAPABILITIES,
            "serverInfo": SERVER_INFO,
        }

    # Post-handshake notification from client; no result expected.
    if method == "notifications/initialized" or method == "initialized":
        return None

    if method == "ping":
        return {}

    # Resources
    if method == "resources/list":
        return {"resources": server.list_resources()}
    if method == "resources/read":
        uri = params.get("uri", "")
        content = server.get_resource(uri)
        return {
            "contents": [
                {
                    "uri": uri,
                    "mimeType": "application/json",
                    "text": json.dumps(content, default=str),
                }
            ]
        }
    if method == "resources/templates/list":
        # We don't publish any URI templates distinct from the listed resources.
        return {"resourceTemplates": []}

    # Prompts (not implemented — return empty list so clients don't error)
    if method == "prompts/list":
        return {"prompts": []}

    # Tools
    if method == "tools/list":
        return {"tools": server.list_tools()}
    if method == "tools/call":
        name = params.get("name", "")
        arguments = params.get("arguments") or {}
        tool_result = server.call_tool(name, arguments)
        # MCP tools/call expects content blocks; wrap the tool's native dict
        # as a single JSON text block.
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps(tool_result, default=str),
                }
            ],
            "isError": False,
        }

    raise _MethodNotFound(f"Unknown method: {method}")


def _send_result(req_id: Any, result: Any) -> None:
    response = {"jsonrpc": "2.0", "id": req_id, "result": result}
    sys.stdout.write(json.dumps(response, default=str) + "\n")
    sys.stdout.flush()


def _send_error(req_id: Any, code: int, message: str) -> None:
    response: dict[str, Any] = {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": code, "message": message},
    }
    sys.stdout.write(json.dumps(response) + "\n")
    sys.stdout.flush()
