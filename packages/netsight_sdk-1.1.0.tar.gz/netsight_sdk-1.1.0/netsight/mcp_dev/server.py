"""NetSightDevMCPServer — main orchestrator."""

from __future__ import annotations

import logging
from typing import Any

from netsight.mcp_dev.cache import ResourceCache
from netsight.mcp_dev.resources import resource_registry
from netsight.mcp_dev.tools import tool_registry
from netsight.mcp_dev.watch import FileSystemWatcher

logger = logging.getLogger(__name__)

_loaded = False


def _load_all_handlers() -> None:
    """Import and register all resource handlers."""
    global _loaded
    if _loaded:
        return
    _loaded = True

    # Ensure core registrations are loaded
    import netsight.parsers  # noqa: F401

    # Import handler modules — each has a register_all() function
    from netsight.mcp_dev.resources import (
        registries,
        vendors,
        packs,
        operations,
        parsers,
        recipes as recipes_resource,
        source,
        docs,
        api,
        fixtures,
        patterns,
        conventions,
        security,
        allowlists,
        credentials,
        standards as standards_resource,
    )
    for mod in (
        registries,
        packs,
        vendors,
        operations,
        parsers,
        recipes_resource,
        source,
        docs,
        api,
        fixtures,
        patterns,
        conventions,
        security,
        allowlists,
        credentials,
        standards_resource,
    ):
        if hasattr(mod, "register_all"):
            mod.register_all()

    # Tool modules (Plan B)
    from netsight.mcp_dev.tools import (
        inspection,
        overview,
        recipes as recipes_tool,
        scaffolding,
        validation,
        standards as standards_tool,
    )
    from netsight.mcp_dev.tools import security as tools_security

    for mod in (
        overview,
        recipes_tool,
        validation,
        scaffolding,
        inspection,
        tools_security,
        standards_tool,
    ):
        if hasattr(mod, "register_all"):
            mod.register_all()


class NetSightDevMCPServer:
    """Read-only MCP server exposing NetSight codebase knowledge."""

    def __init__(self) -> None:
        # Load every installed pack before handler registration so that
        # resource handlers which enumerate vendors / parsers / operations
        # (registries.py, vendors.py, parsers.py, operations.py) see a
        # fully populated pack_registry when they build their caches.
        from netsight.packs import pack_registry

        pack_registry.ensure_loaded()

        self._cache = ResourceCache()
        self._watcher = FileSystemWatcher(self)
        _load_all_handlers()

    def start(self) -> None:
        self._watcher.start()
        logger.info("NetSightDevMCPServer started")

    def stop(self) -> None:
        self._watcher.stop()
        logger.info("NetSightDevMCPServer stopped")

    def list_resources(self) -> list[dict[str, Any]]:
        result = []
        for handler in resource_registry.list_handlers():
            result.extend(handler.list_uris())
        return result

    def get_resource(self, uri: str) -> Any:
        handler = resource_registry.find_handler(uri)
        if handler is None:
            return {"error": f"Unknown resource: {uri}"}
        return self._cache.get_or_compute(uri, lambda: handler.get(uri))

    def list_tools(self) -> list[dict[str, Any]]:
        return [t.tool_definition() for t in tool_registry.list_handlers()]

    def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        handler = tool_registry.get(name)
        if handler is None:
            return {"error": f"Unknown tool: {name}"}
        return handler.execute(**arguments)
