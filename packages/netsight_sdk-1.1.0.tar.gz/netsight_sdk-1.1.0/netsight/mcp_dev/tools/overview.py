"""Orientation tool for the NetSight Dev MCP Server.

Returns a markdown document that teaches an LLM (or a human) what the
server exposes, which resources to browse first, and which tool workflows
match common development tasks. The intent is that a fresh assistant
calls ``netsight_dev_overview`` on first contact to ground itself before
reaching for other tools.
"""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.tools import ToolHandler, tool_registry


_OVERVIEW_MARKDOWN = """\
# NetSight Dev MCP Server — Orientation

This MCP server is a **purpose-built development assistant for the NetSight SDK**
— a read-only, multi-vendor network device query SDK written in Python 3.14.
Use the resources and tools exposed here to navigate the codebase, validate
config changes before writing them, scaffold new vendors/operations/parser
specs, trace execution pipelines, analyse refactor impact, and audit security.

**You are not working on arbitrary code. Every tool in this server exists to
help build, understand, or safeguard the NetSight SDK specifically.**

## What NetSight Is

NetSight connects to network devices (currently Palo Alto Networks / PAN-OS
XML API; more vendors planned), enforces a deny-all command gate, and returns
structured data parsed via YAML parser specs. The core layout:

- `netsight/` — SDK core (pack registry, parsers, config management, security module, dev MCP server)
- `netsight/parsers/` — parser engine that runs YAML specs against device responses
- `netsight/config_mgmt/` — fail-closed config compiler for vendor configs
- `netsight/security/` — AST-based code pattern auditor + dependency auditor
- `netsight/mcp_dev/` — this MCP server (tools + resources)
- `UNITTEST/` — pytest tests (not `tests/`)
- `TOOLS/` — shell utility scripts

**This repo is part of a three-repo architecture:**

| Repo | Distribution | What it contains |
|---|---|---|
| `magicboxlab-ai/netsight-sdk` (this repo) | `netsight-sdk` | Core SDK: base client, parsers, config compiler, packs, security, dev MCP |
| `magicboxlab-ai/netsight-ops` | `netsight-ops` | Runtime services: HTTP API (FastAPI+GraphQL), runtime MCP server |
| `magicboxlab-ai/netsight-packs-paloalto` | `netsight-pack-paloalto-firewall-xml` | Palo Alto Networks vendor pack |

See `netsight://docs/guides/multi-repo-workflow` for the full cross-repo development workflow.

## First-Contact Resources (browse before reaching for tools)

Fetch these with `ReadMcpResourceTool` to orient yourself:

| Resource URI | What it tells you |
|---|---|
| `netsight://registries` | Counts of plugins, engines, types, transforms, functions |
| `netsight://registries/plugins` | All registered vendor plugins |
| `netsight://registries/engines` | Parser engines (jmespath, passthrough) |
| `netsight://registries/types` | Field type coercers |
| `netsight://registries/transforms` | Field transforms |
| `netsight://vendors` | All vendors with their device types |
| `netsight://vendors/{vendor}` | Vendor metadata + device types |
| `netsight://vendors/{vendor}/parsers` | Parser specs for a vendor |
| `netsight://vendors/{vendor}/parsers/{op}` | A single parser spec |
| `netsight://operations` | Every allowlisted operation (parsed AND raw) with `has_parser_spec` flag |
| `netsight://parsers` | All parser specs across all vendors (the parsed subset only) |
| `netsight://patterns` | Built-in usage patterns (health check, route investigation, etc.) |
| `netsight://relations` | Operation relationship graph |
| `netsight://exceptions` | NetSight exception hierarchy |
| `netsight://credentials` | Registered credential providers + health status |
| `netsight://standards` | All code development standards with name, category, severity, and pass/fail status |
| `netsight://docs/guides/user-guide` | Full user guide |
| `netsight://docs/guides/user-guide#sections` | TOC of the user guide |
| `netsight://docs/guides/user-guide#using-the-sdk` | Just one section of the user guide |
| `netsight://docs/guides/developer-guide` | Full developer guide (section fragments supported) |
| `netsight://docs/guides/credential-management` | Credential providers: quick start, vault CLI, custom providers |
| `netsight://docs/guides/multi-repo-workflow` | Cross-repo development workflow: setup, testing, version bumps, adding packs/services |
| `netsight://docs/changelog` | Changelog |
| `netsight://source/{path}` | Read any allowlisted file in the source tree |
| `netsight://conventions/commits` | Commit message conventions |
| `netsight://conventions/file_naming` | File naming conventions |
| `netsight://conventions/test_patterns` | TDD conventions |
| `netsight://recipes` | Canonical implementation patterns across 13 categories — the "how do we write X here" catalog |
| `netsight://recipes/{name}` | A single recipe with canonical example, common mistakes, and cross-references |
| `netsight://security/policies` | Active security policies |
| `netsight://security/known_safe` | Vetted package versions |

## Common Workflows

### Adding a new read-only operation to an existing pack

1. Capture sample XML from the device.
2. `extract_xml_structure` — inspect the XML dotted paths.
3. `scaffold_operation_entry` — generate the `operations_catalog.toml` entry.
4. `validate_operations_toml` — verify the entry.
5. `scaffold_parser_spec` — generate the YAML parser spec from the sample XML.
6. `validate_jmespath` — test individual field paths against the sample data.
7. `validate_parser_spec` — verify the full YAML structure.
8. `lint_yaml_spec` — catch style issues (missing description, missing types).
9. Write the entry to the pack's `_data/operations_catalog.toml` and the
   parser spec to `_data/parsers/<op>.yaml`.
10. Reinstall the pack: `pip install -e packs/<vendor>-<class>-<protocol>/`
11. Enable the operation: `netsight allowlist enable <pack-name> <op-name>`
12. `compile_dry_run` — final gate: full NetSight ConfigCompiler in validate-only mode.

### Adding operations with the automated pipeline

When the target device is reachable, `netsight pack add-operation` runs the
full scaffold-to-compile sequence for a single operation in one command:

```sh
netsight pack add-operation show_bgp_peers \\
    --command "<show><routing>...</routing></show>" \\
    --category routing \\
    --description "Show BGP peer status" \\
    --sample-from-device sandbox-fw
```

The command generates 3 files (catalog entry, parser spec, test stub), runs
`validate_parser_spec` + `lint_yaml_spec` + `compile_dry_run` as a gate, and
writes nothing if the gate fails. Use `--dry-run` to preview output, `--skip-parser`
for raw-return ops, and `--type log --log-type <name>` for log retrieval ops.

### Adding a new vendor plugin (pack)

1. `scaffold_vendor_plugin` — generate client, `__init__.py`, and minimum TOML configs.
2. Write the returned files to disk under `packs/<vendor>-<class>-<protocol>/`.
3. Implement `client.py::execute()` for the vendor's protocol.
4. Add operations via the "new operation" workflow above.
5. `compile_dry_run` — validate the pack config tree.

### First-time user setup

1. `pip install netsight` — install the core SDK.
2. `pip install git+...` — install the vendor pack (e.g. `paloalto-firewall-xml`).
3. `netsight init` — create `~/.config/netsight/devices.yaml` from the template.
4. Edit `devices.yaml` — add device entries with `api_type: <pack-name>`.
5. `netsight allowlist enable <pack-name> <op>` — opt into each operation.
6. `netsight doctor` — verify the full environment is wired correctly.

### Managing installed packs

- `netsight pack list` — show installed packs.
- `netsight pack list --available` — show all packs in the bundled catalog.
- `netsight pack install <pack-name>` — install a pack via pip.
- `netsight pack info <pack-name>` — show pack metadata.

### Listing configured devices

- `netsight devices list` — list all devices configured in `devices.yaml`
  with name, `api_type`, host, and enabled-operation count. Useful for
  verifying the device inventory before running compile or allowlist commands.

### Managing the operation allowlist

- `netsight allowlist list` — show all packs and their allowlist status.
- `netsight allowlist show <pack-name>` — show enabled operations.
- `netsight allowlist enable <pack-name> <op>` — enable one or more operations.
- `netsight allowlist disable <pack-name> <op>` — disable an operation.
- `netsight allowlist audit <pack-name>` — show effective permissions (catalog ∩ allowlist).

### Debugging an operation that returns empty fields

1. `trace_operation_pipeline` on the operation name — see the full pipeline.
2. Read the parser spec: `netsight://vendors/<vendor>/parsers/<operation>`.
3. Capture the raw XML device response.
4. `extract_xml_structure` on the raw XML.
5. `validate_jmespath` on each failing field path against the XML dict.
6. Edit the spec → `validate_parser_spec` → write back → `compile_dry_run`.

### Refactoring a class or function

1. `find_definitions <symbol>` — where is it defined?
2. `find_usages <symbol>` — who calls it?
3. `analyze_impact <symbol>` — how many directories are affected?
4. Make the change.
5. `check_pattern` on new code → `audit_code` on the whole tree before commit.

### Adding or upgrading a dependency

1. `verify_dependency <name> <version>` — is it already vetted?
2. If unvetted: manually review, then add to `netsight/security/known_safe.toml`.
3. `audit_dependencies` — full environment scan to confirm no new findings.
4. `audit_full` — final CI-gate check.

### Investigating a validation error

1. `explain_validation_error <error text>` — get human-readable guidance.
2. Apply the suggested fix.
3. Re-run whichever validator produced the error.

### Finding operations to use in code

1. `find_operations_by_category <category>` — ops for a workflow (system, network, logs).
2. `find_operations_by_tag <tag>` — cross-cutting queries (troubleshooting, snapshot).
3. Read `netsight://operations` to browse everything at once. Each entry
   has a `has_parser_spec: bool` flag that tells you whether the SDK
   returns parsed data or raw XML for that op.
4. Read `netsight://patterns` to see curated op sequences.

### Before writing new code in an unfamiliar area

Call `get_implementation_recipe` (or read `netsight://recipes/<category>`)
for the pattern category that matches what you're about to write. The
recipes are short, include a canonical example from real source files,
and list common mistakes — they catch the class of errors an LLM makes
by defaulting to "how other Python projects do it".

Current categories:

- `docstrings` — numpydoc vs Google-style, which this codebase uses where
- `parser_specs` — YAML structure, JMESPath quirks, dict vs list shape
- `plugin_clients` — BaseDeviceClient contract, why you MUST NOT override
  `execute()`, the AuthStrategy + retry_with_backoff pattern
- `logging` — stdlib `logging` conventions (NOT OSLog, that's a Swift rule)
- `self_documentation` — `operations_catalog.toml` + `@operation` decorator
  two-surface pattern; both must stay in sync or discovery tooling breaks
- `tests` — UNITTEST/ layout, `TestSomething:` class naming, tmp_path /
  monkeypatch fixture patterns, TDD workflow
- `registry_usage` — the four pluggable registries (types, transforms,
  functions, engines) and the decorator-form registration idiom
- `exception_handling` — NetSightError hierarchy, credential redaction
  rule, `raise ... from exc` chaining
- `commits` — conventional-commit prefixes, imperative mood, 72-char
  subject cap, and the pre-commit hook that blocks "claude" in messages
- `changelog` — Keep a Changelog format, `## [Unreleased]` section,
  when user-visible changes belong in the log vs the git history only
- `mcp_handlers` — ResourceHandler / ToolHandler ABCs, template URI
  patterns, the `_load_all_handlers` wiring trap
- `security_workflow` — when to call each of the five security tools
  (check_pattern, audit_code, verify_dependency, audit_dependencies,
  audit_full) across the development lifecycle

The scaffolding tools (`scaffold_parser_spec`, `scaffold_vendor_plugin`,
`scaffold_operation_entry`, `scaffold_custom_function`,
`scaffold_field_type`, `scaffold_test_file`) inject a `_recipe_hint`
field into their responses that points at the relevant recipe — follow
the hint before writing the generated content to disk.

### Understanding parser spec coverage

Parser specs are the YAML files that transform a device's raw response
into structured Python data. Not every operation has one — some return raw.

1. `list_parser_specs` (or read `netsight://parsers`) — every parser spec
   across every vendor, with engine, field count, and summary. **Distinct
   from `netsight://operations`**, which also lists ops that have NO
   parser spec.
2. `trace_operation_pipeline <op>` — see how a single spec is wired into
   command → engine → output.
3. `diff_parser_specs` — compare two specs structurally.

## Guided responses (read the `_guidance` block)

Several entry-point resources return a `_guidance` block alongside the
data. These exist specifically to help LLMs navigate the server without
pre-existing knowledge. When you see one of these keys in a response,
read it — it tells you the next useful calls and the common
misconceptions about the current data.

Entry points with guided responses:

- `netsight://registries`
- `netsight://vendors`
- `netsight://operations`
- `netsight://parsers`
- `list_parser_specs` tool

Shape of the `_guidance` block:

```
{
  "what_this_is": "One-paragraph explanation of what the data represents.",
  "not_to_be_confused_with": "Similar-sounding resources that mean different things.",
  "next_steps": ["ordered list of suggested follow-up calls"],
  "see_also": {"uri": "why you'd read it next"}
}
```

The `see_also` map is especially useful for cross-referencing — if the
resource you read has a `see_also` entry, read that one next.

## Tools vs Resources — when to use which

- **Resources** (`ReadMcpResourceTool` on `netsight://...`) are for
  **browsing existing state** — registries, vendor configs, docs, source
  files, compiled configs. Read-only, cached, fast.
- **Tools** (`mcp__netsight-dev__*`) are for **validation, scaffolding,
  search, and audit** — they compute something or transform input.
  Stateless; call them when you need an action, not a lookup.

If you want to *look at* something that exists, prefer the matching
resource. If you want to *verify*, *generate*, or *search*, use a tool.

## Project Conventions to Know

- Tests live in `UNITTEST/` (not `tests/`).
- Validation scripts go in `UNITTEST/`, tooling scripts in `TOOLS/`.
- TDD: write a failing test first, then the minimum implementation.
- Commit messages MUST NOT contain "Claude" or AI references (a pre-commit hook enforces this).
- Scaffolding tools return strings — they never write files. You choose where.
- The config compiler is fail-closed: any single error blocks all output.

## What This Server Does NOT Do

- **Does not execute device commands.** Runtime device operations live in
  the `netsight-ops` distribution (`pip install netsight-ops`). Its runtime
  MCP server exposes live device ops to AI agents; this dev MCP server
  exposes codebase introspection tools for developers.
- **Does not write files.** All scaffolding tools return content strings.
- **Does not expose internal AI planning docs** (`docs/superpowers/` is blocked).
- **Does not require authentication.** Binds to stdio only; localhost-only by construction.
"""


class NetSightDevOverviewTool(ToolHandler):
    name = "netsight_dev_overview"
    description = (
        "**START HERE on first contact.** Returns an orientation document "
        "for the NetSight Dev MCP Server — explains what NetSight is, lists "
        "the key resources to browse, walks through common development "
        "workflows (adding a vendor, adding an operation, debugging a "
        "parser spec, refactoring, auditing security), and explains when "
        "to use tools versus resources. Call this tool before any other "
        "netsight-dev tool if you are unfamiliar with the NetSight SDK or "
        "this server. Returns markdown."
    )
    parameters_schema = {"type": "object", "properties": {}, "required": []}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        return {
            "format": "markdown",
            "content": _OVERVIEW_MARKDOWN,
        }


def register_all() -> None:
    """Register the orientation tool."""
    tool_registry.register(NetSightDevOverviewTool())
