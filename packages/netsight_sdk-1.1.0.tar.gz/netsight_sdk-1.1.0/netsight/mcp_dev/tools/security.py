"""MCP security tools — thin wrappers over the security module."""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.tools import ToolHandler, tool_registry


class AuditCodeTool(ToolHandler):
    name = "audit_code"
    description = (
        "Run the NetSight AST-based code pattern audit against the whole "
        "netsight/ source tree. Detects arbitrary code execution, shell "
        "injection, unsafe deserialization, unsafe YAML loaders, weak "
        "hashes, hardcoded secrets, TLS bypass, bare except, query "
        "injection, and insecure tempfile usage. Use this to scan the "
        "whole project; use check_pattern for a single snippet; use "
        "audit_full for code + dependencies together. The NetSight config "
        "compiler calls the same underlying auditor as a compile-time gate."
    )
    parameters_schema = {"type": "object", "properties": {}, "required": []}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.security.audit import AuditOrchestrator

        return AuditOrchestrator().audit_code_only()


class AuditDependenciesTool(ToolHandler):
    name = "audit_dependencies"
    description = (
        "Run the NetSight dependency audit: verifies each installed "
        "package against netsight/security/known_safe.toml (min/max vetted "
        "versions) and runs pip-audit for known CVEs. Use this after "
        "adding, upgrading, or pinning a dependency. Use verify_dependency "
        "for a single package/version check without scanning the whole "
        "environment."
    )
    parameters_schema = {"type": "object", "properties": {}, "required": []}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.security.audit import AuditOrchestrator

        return AuditOrchestrator().audit_deps_only()


class AuditFullTool(ToolHandler):
    name = "audit_full"
    description = (
        "Run the complete NetSight security audit: code pattern audit "
        "(AST-based) plus dependency audit (known_safe.toml + pip-audit). "
        "This is the CI-gate check — TOOLS/security_check.sh and the "
        "NetSight config compiler's security pre-check call the same "
        "underlying orchestrator. Use this before commits that touch "
        "dependencies or add new files; use audit_code or audit_dependencies "
        "for narrower, faster checks."
    )
    parameters_schema = {"type": "object", "properties": {}, "required": []}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.security.audit import AuditOrchestrator

        return AuditOrchestrator().audit_full()


class CheckPatternTool(ToolHandler):
    name = "check_pattern"
    description = (
        "Check a Python code snippet against the NetSight AST code "
        "pattern auditor without touching disk. Use this before pasting "
        "new code into a file — the auditor detects the same 10+ unsafe "
        "patterns that audit_code scans for (arbitrary execution, shell "
        "injection, hardcoded secrets, unsafe yaml, weak hashes, bare "
        "except, etc.). Returns findings with line/column and a concrete "
        "suggestion for each issue."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "snippet": {"type": "string"},
        },
        "required": ["snippet"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.security.code_patterns import CodePatternAuditor

        snippet = kwargs.get("snippet", "")
        auditor = CodePatternAuditor()
        findings = auditor.audit_source(snippet, "<snippet>")
        return {
            "findings": [f.to_dict() for f in findings],
            "count": len(findings),
        }


class VerifyDependencyTool(ToolHandler):
    name = "verify_dependency"
    description = (
        "Check if a specific package/version is vetted in NetSight's "
        "netsight/security/known_safe.toml (returns ok / unvetted / "
        "out_of_range). Use this before adding a new dependency — if "
        "unvetted, the package needs to be manually verified and added "
        "to known_safe.toml. For a full environment scan use "
        "audit_dependencies."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "version": {"type": "string"},
        },
        "required": ["name", "version"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.security.dependencies import DependencyAuditor

        name = kwargs.get("name", "")
        version = kwargs.get("version", "")
        return DependencyAuditor().verify_package(name, version)


def register_all() -> None:
    """Register all security tools."""
    tool_registry.register(AuditCodeTool())
    tool_registry.register(AuditDependenciesTool())
    tool_registry.register(AuditFullTool())
    tool_registry.register(CheckPatternTool())
    tool_registry.register(VerifyDependencyTool())
