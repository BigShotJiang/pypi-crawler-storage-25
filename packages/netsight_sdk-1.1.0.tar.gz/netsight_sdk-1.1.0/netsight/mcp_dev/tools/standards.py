"""MCP tools for the code development standards framework."""

from __future__ import annotations

import logging
from typing import Any

from netsight.mcp_dev.tools import ToolHandler, tool_registry

logger = logging.getLogger(__name__)


class ListStandardsTool(ToolHandler):
    """List all defined code standards with their categories and severity levels."""

    name = "list_standards"
    description = (
        "List all defined NetSight code-development standards. Returns every standard "
        "loaded from netsight/standards/definitions/ including its name, category, "
        "severity (error or warning), description, and whether it has an automated "
        "validation engine. Use this to discover what standards exist before calling "
        "check_standards to validate the codebase. Error-severity standards are "
        "enforced by the CI gate; warning-severity standards are informational."
    )
    parameters_schema: dict[str, Any] = {"type": "object", "properties": {}, "required": []}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.standards import standards_registry

        standards = standards_registry.list_standards()
        return {
            "standards": [
                {
                    "name": s.name,
                    "category": s.category,
                    "severity": s.severity,
                    "description": s.description[:200],
                    "introduced": s.introduced,
                    "has_engine": bool(s.rule.get("engine")),
                }
                for s in standards
            ],
            "count": len(standards),
            "categories": standards_registry.list_categories(),
        }


class CheckStandardsTool(ToolHandler):
    """Validate code against all defined NetSight standards or a specific one."""

    name = "check_standards"
    description = (
        "Validate the NetSight codebase against all defined code-development standards "
        "or a specific subset. Pass 'standard' to check a single standard by name "
        "(e.g. 'credential-safety'), 'category' to check all standards in a category "
        "(e.g. 'security', 'api-contract'), or omit both to run all standards. "
        "Returns pass/fail/skip status per standard plus up to 20 findings per failing "
        "standard. Documentation-only standards (rule: {}) are reported as skipped. "
        "Use list_standards first to see available standard names and categories."
    )
    parameters_schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "standard": {
                "type": "string",
                "description": "Specific standard name to check (optional)",
            },
            "category": {
                "type": "string",
                "description": "Check all standards in this category (optional)",
            },
        },
        "required": [],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.standards import standards_registry

        name = kwargs.get("standard")
        category = kwargs.get("category")

        if name:
            try:
                results = [standards_registry.check_standard(name=name)]
            except KeyError:
                return {"error": f"Standard '{name}' not found"}
        elif category:
            results = standards_registry.check_category(category=category)
            if not results:
                return {"error": f"No standards found in category: {category!r}"}
        else:
            results = standards_registry.check_all()

        return {
            "results": [
                {
                    "standard": r.standard,
                    "passed": r.passed,
                    "skipped": r.skipped,
                    "skip_reason": r.skip_reason if r.skipped else None,
                    "findings_count": len(r.findings),
                    "findings": [
                        {"file": f.file, "line": f.line, "message": f.message}
                        for f in r.findings[:20]
                    ],
                }
                for r in results
            ],
            "summary": {
                "total": len(results),
                "passed": sum(1 for r in results if r.passed),
                "failed": sum(1 for r in results if not r.passed and not r.skipped),
                "skipped": sum(1 for r in results if r.skipped),
            },
        }


def register_all() -> None:
    """Register all standards tool handlers."""
    tool_registry.register(ListStandardsTool())
    tool_registry.register(CheckStandardsTool())
    logger.debug("Standards tools registered: list_standards, check_standards")
