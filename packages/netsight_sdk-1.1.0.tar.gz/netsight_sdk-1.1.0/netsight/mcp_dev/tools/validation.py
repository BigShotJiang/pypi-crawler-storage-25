"""MCP validation tools — validate parser specs, operations_catalog.toml, JMESPath."""

from __future__ import annotations

from typing import Any

import yaml

from netsight.mcp_dev.tools import ToolHandler, tool_registry


class ValidateParserSpecTool(ToolHandler):
    name = "validate_parser_spec"
    description = (
        "Validate a NetSight parser spec (YAML) before writing it to disk. "
        "Parser specs live at config/vendors/<vendor>/parsers/<op>.yaml and "
        "tell the NetSight parser engine how to extract structured data from "
        "a device's raw response. Use this after editing a spec or after "
        "calling scaffold_parser_spec. If validation fails, pass the error "
        "text to explain_validation_error for step-by-step guidance."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "yaml_content": {
                "type": "string",
                "description": "The YAML content of a parser spec to validate.",
            }
        },
        "required": ["yaml_content"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        yaml_content = kwargs.get("yaml_content", "")
        try:
            spec = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            return {"valid": False, "errors": [f"Invalid YAML: {e}"]}

        if not isinstance(spec, dict):
            return {
                "valid": False,
                "errors": [f"Spec must be a mapping, got {type(spec).__name__}"],
            }

        from netsight.parsers.spec import validate_parser_spec

        errors = validate_parser_spec(spec)
        if errors:
            return {
                "valid": False,
                "errors": [str(e) for e in errors],
            }
        return {"valid": True, "errors": []}


class ValidateOperationsTomlTool(ToolHandler):
    name = "validate_operations_toml"
    description = (
        "Validate an operations_catalog.toml entry for a NetSight pack "
        "before committing it. operations_catalog.toml defines which device "
        "commands the pack supports; the user allowlist (managed via "
        "'netsight allowlist enable') controls which of those are actually "
        "permitted at runtime. Use this after editing an operation or after "
        "calling scaffold_operation_entry. Pair with compile_dry_run to "
        "check the full pack config tree."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "toml_content": {
                "type": "string",
                "description": "TOML content of an operations_catalog.toml file.",
            },
            "vendor": {
                "type": "string",
                "description": "Vendor name (used for context in error messages).",
            },
        },
        "required": ["toml_content", "vendor"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        import tomllib

        toml_content = kwargs.get("toml_content", "")
        vendor = kwargs.get("vendor", "")

        try:
            data = tomllib.loads(toml_content)
        except tomllib.TOMLDecodeError as e:
            return {
                "valid": False,
                "errors": [f"Invalid TOML ({vendor}): {e}"],
            }

        from netsight.config_mgmt.schemas import validate_operations

        # validate_operations iterates directly over {op_name: op_dict} pairs
        errors = validate_operations(data)
        if errors:
            return {
                "valid": False,
                "errors": [str(e) for e in errors],
            }
        return {"valid": True, "errors": []}


class CompileDryRunTool(ToolHandler):
    name = "compile_dry_run"
    description = (
        "Run the NetSight ConfigCompiler in validate-only mode against a "
        "vendor's full config tree (metadata, auth, connection, operations, "
        "parser specs). Use this as the final gate after editing any file "
        "under config/vendors/<vendor>/ — the compiler is fail-closed, so "
        "any single error blocks all output. Validate individual pieces "
        "first with validate_parser_spec and validate_operations_toml."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "vendor": {
                "type": "string",
                "description": "Vendor name to compile (e.g. 'paloalto').",
            }
        },
        "required": ["vendor"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from netsight.config_mgmt.compiler import ConfigCompiler

        vendor = kwargs.get("vendor", "")
        compiler = ConfigCompiler("config/vendors")
        result = compiler.compile_vendor(vendor, validate_only=True)
        return {
            "success": result.success,
            "vendor": result.vendor,
            "models_compiled": list(result.models_compiled),
            "errors": [str(e) for e in result.errors],
            "warnings": [str(w) for w in result.warnings],
        }


class LintYamlSpecTool(ToolHandler):
    name = "lint_yaml_spec"
    description = (
        "Lint a NetSight parser spec for style issues — missing description, "
        "missing field types, missing spec_version, non-lowercase operation "
        "name. Accepts EITHER ``yaml_content`` (for in-memory specs fresh "
        "from scaffold_parser_spec) OR ``file_path`` (for on-disk specs). "
        "Use ``yaml_content`` during the scaffold → validate → lint → write "
        "workflow so you can lint before committing to disk. Complements "
        "validate_parser_spec, which only checks structural validity. Use "
        "both: validate_parser_spec for correctness, this tool for quality."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "yaml_content": {
                "type": "string",
                "description": (
                    "YAML spec content to lint in-memory. Preferred when "
                    "linting output from scaffold_parser_spec before the "
                    "file has been written to disk."
                ),
            },
            "file_path": {
                "type": "string",
                "description": (
                    "Path to an on-disk YAML spec file. Used as a fallback "
                    "when yaml_content is not supplied."
                ),
            },
        },
        "required": [],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        from pathlib import Path

        yaml_content = kwargs.get("yaml_content")
        file_path = kwargs.get("file_path")

        # Prefer in-memory content when both are supplied.
        if yaml_content:
            source_label = "<in-memory>"
            raw = yaml_content
        elif file_path:
            path = Path(file_path)
            if not path.exists():
                return {"error": f"File not found: {path}"}
            source_label = str(path)
            raw = path.read_text(encoding="utf-8")
        else:
            return {
                "error": (
                    "Must supply either 'yaml_content' (preferred for "
                    "in-memory specs) or 'file_path' (for on-disk specs)."
                )
            }

        try:
            spec = yaml.safe_load(raw)
        except yaml.YAMLError as e:
            return {"error": f"Invalid YAML: {e}"}
        if not isinstance(spec, dict):
            return {"error": "Spec root must be a mapping."}

        warnings: list[str] = []

        if "spec_version" not in spec:
            warnings.append("Missing 'spec_version' field.")
        if "description" not in spec or not spec.get("description"):
            warnings.append("Missing or empty 'description' field.")

        op_name = spec.get("operation", "")
        if op_name and op_name != op_name.lower():
            warnings.append(f"Operation name '{op_name}' should be lowercase.")

        fields = spec.get("fields", {})
        if isinstance(fields, dict):
            for field_name, field_def in fields.items():
                if not isinstance(field_def, dict):
                    continue
                if "type" not in field_def:
                    warnings.append(
                        f"Field '{field_name}' is missing 'type'."
                    )

        return {"warnings": warnings, "source": source_label}


class ValidateJmesPathTool(ToolHandler):
    name = "validate_jmespath"
    description = (
        "Compile and evaluate a JMESPath expression against sample data. "
        "The primary use case is testing paths you're about to put in a "
        "NetSight parser spec's fields[*].path — verify each field "
        "extraction against captured device XML (converted to a dict via "
        "xmltodict) before writing the YAML. Pair with extract_xml_structure "
        "to discover which dotted paths exist in a given XML response."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "expression": {
                "type": "string",
                "description": "JMESPath expression to evaluate.",
            },
            "sample_data": {
                "description": "Sample data (any JSON-compatible value) to evaluate against.",
            },
        },
        "required": ["expression", "sample_data"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        import json

        import jmespath
        from jmespath.exceptions import JMESPathError

        expression = kwargs.get("expression", "")
        sample_data = kwargs.get("sample_data")

        # MCP clients sometimes serialise structured parameters as JSON
        # strings even when the schema allows any JSON value. If we receive
        # a string, try to parse it as JSON; fall back to the raw string
        # when parsing fails (so a literal string target still works).
        if isinstance(sample_data, str):
            try:
                sample_data = json.loads(sample_data)
            except json.JSONDecodeError:
                pass

        try:
            compiled = jmespath.compile(expression)
            result = compiled.search(sample_data)
        except JMESPathError as e:
            return {"valid": False, "error": str(e), "result": None}
        return {"valid": True, "error": None, "result": result}


def register_all() -> None:
    """Register all validation tools with the tool registry."""
    tool_registry.register(ValidateParserSpecTool())
    tool_registry.register(ValidateOperationsTomlTool())
    tool_registry.register(CompileDryRunTool())
    tool_registry.register(LintYamlSpecTool())
    tool_registry.register(ValidateJmesPathTool())
