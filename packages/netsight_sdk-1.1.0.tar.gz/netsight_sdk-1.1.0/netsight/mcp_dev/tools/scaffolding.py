"""MCP scaffolding tools — generate file templates (return strings, do not write)."""

from __future__ import annotations

import re
from typing import Any

from netsight.mcp_dev.tools import ToolHandler, tool_registry


def _walk_leaves(node: Any, path: list[str]) -> list[tuple[str, str]]:
    """Yield (parent_path, leaf_name) tuples for every scalar leaf in a nested dict."""
    leaves: list[tuple[str, str]] = []
    if isinstance(node, dict):
        for key, child in node.items():
            leaves.extend(_walk_leaves(child, path + [key]))
    elif isinstance(node, list):
        if node:
            leaves.extend(_walk_leaves(node[0], path))
    else:
        # Scalar leaf; parent is path[:-1], leaf name is path[-1]
        if path:
            leaves.append((".".join(path[:-1]), path[-1]))
    return leaves


class ScaffoldParserSpecTool(ToolHandler):
    name = "scaffold_parser_spec"
    description = (
        "Generate a starter NetSight parser YAML spec by analysing a sample "
        "XML response from a device. This is the first step when adding a "
        "new read-only operation. Workflow: capture sample XML → call "
        "extract_xml_structure to see available paths → call this tool with "
        "the chosen operation name and XML → validate_parser_spec on the "
        "output → write to config/vendors/<vendor>/parsers/<op>.yaml. "
        "Returns YAML as a string; does not touch disk."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "operation": {"type": "string"},
            "sample_xml": {"type": "string"},
            "vendor": {"type": "string"},
        },
        "required": ["operation", "sample_xml", "vendor"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        import xmltodict

        operation = kwargs.get("operation", "")
        sample_xml = kwargs.get("sample_xml", "")
        vendor = kwargs.get("vendor", "")

        try:
            parsed = xmltodict.parse(sample_xml)
        except Exception as e:
            return {"error": f"Could not parse XML: {e}"}

        leaves = _walk_leaves(parsed, [])
        if not leaves:
            return {"error": "No leaf nodes found in XML sample."}

        # Use the most common parent path as the root
        parent_counts: dict[str, int] = {}
        for parent, _leaf in leaves:
            parent_counts[parent] = parent_counts.get(parent, 0) + 1
        root = max(parent_counts, key=lambda p: parent_counts[p])

        lines = [
            'spec_version: "1.0"',
            "engine: jmespath",
            f"operation: {operation}",
            "input_format: xml",
            "output_shape: dict",
            f'description: "Scaffolded from sample XML for {vendor}/{operation}"',
            "",
            f"root: {root}",
            "",
            "fields:",
        ]
        seen: set[str] = set()
        for parent, leaf in leaves:
            if parent != root:
                continue
            if leaf in seen:
                continue
            seen.add(leaf)
            jmes_path = f'"{leaf}"' if "-" in leaf else leaf
            lines.append(f"  {leaf.replace('-', '_')}:")
            lines.append(f"    path: {jmes_path}")
            lines.append("    type: str")

        yaml_content = "\n".join(lines) + "\n"
        return {
            "yaml_content": yaml_content,
            "operation": operation,
            "vendor": vendor,
            "field_count": len(seen),
            "_recipe_hint": {
                "recipe": "parser_specs",
                "uri": "netsight://recipes/parser_specs",
                "why": (
                    "You've scaffolded a parser spec. Read this recipe "
                    "before writing it to disk to confirm output_shape, "
                    "description, field types, and JMESPath key quoting "
                    "match NetSight conventions. The recipe's "
                    "common_mistakes list is the same set of issues "
                    "lint_yaml_spec will flag later — cheaper to fix now."
                ),
            },
        }


class ScaffoldOperationEntryTool(ToolHandler):
    name = "scaffold_operation_entry"
    description = (
        "Generate a TOML snippet for a new NetSight operations_catalog.toml "
        "entry. operations_catalog.toml lives inside a pack's _data/ directory "
        "and defines which device commands the pack supports. Use this when "
        "adding a new read-only operation to a NetSight pack — run it before "
        "scaffold_parser_spec so the new op is in the catalog, then validate "
        "with validate_operations_toml. After updating the catalog, reinstall "
        "the pack and enable the op via 'netsight allowlist enable'. Returns "
        "TOML as a string; does not touch disk."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "operation": {"type": "string"},
            "command": {"type": "string"},
            "category": {"type": "string"},
            "description": {"type": "string"},
        },
        "required": ["operation", "command", "category"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        operation = kwargs.get("operation", "")
        command = kwargs.get("command", "")
        category = kwargs.get("category", "")
        description = kwargs.get("description", f"Run {operation}")

        safe_command = command.replace('"', '\\"')

        lines = [
            f"[{operation}]",
            f'command = "{safe_command}"',
            'type = "op"',
            f'category = "{category}"',
            f'description = "{description}"',
            "read_only = true",
            f'parser_spec = "parsers/{operation}.yaml"',
        ]
        return {
            "toml_content": "\n".join(lines) + "\n",
            "operation": operation,
            "_recipe_hint": {
                "recipe": "self_documentation",
                "uri": "netsight://recipes/self_documentation",
                "why": (
                    "You've scaffolded an operations_catalog.toml entry. Read "
                    "this recipe before writing it to disk — NetSight operations "
                    "are self-documenting via BOTH operations_catalog.toml AND "
                    "the @operation decorator on the client method. Skipping "
                    "either surface breaks the help/discovery tooling that "
                    "downstream users rely on."
                ),
            },
        }


class ScaffoldCustomFunctionTool(ToolHandler):
    name = "scaffold_custom_function"
    description = (
        "Generate a Python template for a NetSight custom parser function. "
        "Parser functions live in netsight/plugins/<vendor>/parser_functions.py "
        "and are invoked from parser specs via {function: name, args: {...}} "
        "to handle complex field transforms the built-in transforms can't "
        "express. Use this when a parser spec needs logic beyond "
        "path + type + transform. See netsight://registries/functions for "
        "functions that already exist. Returns source code as a string."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "signature": {
                "type": "string",
                "description": "Python signature like '(value: str) -> str'.",
            },
        },
        "required": ["name", "signature"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        name = kwargs.get("name", "")
        signature = kwargs.get("signature", "(value: Any) -> Any")
        template = (
            f'"""Custom parser function: {name}."""\n\n'
            "from __future__ import annotations\n\n"
            "from netsight.parsers.registry import function_registry\n\n\n"
            f"def {name}{signature}:\n"
            f'    """TODO: describe what {name} does."""\n'
            "    # TODO: implement\n"
            "    return value\n\n\n"
            f'function_registry.register("{name}", {name})\n'
        )
        return {
            "py_content": template,
            "name": name,
            "_recipe_hint": {
                "recipe": "registry_usage",
                "uri": "netsight://recipes/registry_usage",
                "why": (
                    "You've scaffolded a parser function. Read this recipe "
                    "before writing it to disk — the codebase uses the "
                    "decorator form (@function_registry.register(\"name\")) "
                    "uniformly, and the module must be imported somewhere "
                    "in the import chain or the registration never runs."
                ),
            },
        }


class ScaffoldFieldTypeTool(ToolHandler):
    name = "scaffold_field_type"
    description = (
        "Generate a Python template for a NetSight custom field type "
        "coercer. Field types (str, int, ip, bool, etc.) normalize raw "
        "extracted values into Python types. Add a new one in "
        "netsight/parsers/types.py when no built-in type fits — e.g. MAC "
        "address normalisation, timestamp parsing. Check "
        "netsight://registries/types first to see what already exists. "
        "Returns source code as a string."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "description": {"type": "string"},
        },
        "required": ["name", "description"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        name = kwargs.get("name", "")
        description = kwargs.get("description", "")
        template = (
            f'"""Custom field type: {name}."""\n\n'
            "from __future__ import annotations\n\n"
            "from typing import Any\n\n"
            "from netsight.parsers.registry import type_registry\n\n\n"
            f"def {name}(value: Any) -> Any:\n"
            f'    """{description}"""\n'
            "    # TODO: implement coercion logic\n"
            "    return value\n\n\n"
            f'type_registry.register("{name}", {name})\n'
        )
        return {
            "py_content": template,
            "name": name,
            "_recipe_hint": {
                "recipe": "registry_usage",
                "uri": "netsight://recipes/registry_usage",
                "why": (
                    "You've scaffolded a field type coercer. Read this "
                    "recipe before writing it to disk — NetSight uses "
                    "decorator-form registration "
                    "(@type_registry.register(\"name\")) and the module "
                    "must be imported somewhere (typically "
                    "netsight/parsers/__init__.py) or the registration "
                    "never runs and the type stays 'unknown'."
                ),
            },
        }


class ScaffoldTestFileTool(ToolHandler):
    name = "scaffold_test_file"
    description = (
        "Generate a pytest test file template for a NetSight module. Place "
        "output at UNITTEST/test_<module>.py per project convention (the "
        "NetSight repo uses UNITTEST/, not tests/). Use this when starting "
        "a new test file — it emits the import + test class boilerplate so "
        "you can jump straight to writing assertions. Returns source code "
        "as a string; does not touch disk."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "target_module": {
                "type": "string",
                "description": "Dotted path like 'netsight.parsers.engine'.",
            }
        },
        "required": ["target_module"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        target_module = kwargs.get("target_module", "")
        parts = target_module.split(".")
        tail = parts[-1] if parts else "module"
        # If tail is a single word with no underscores, prefix with the
        # second-to-last dotted segment so class names stay descriptive.
        # Strip a trailing 's' from the parent segment (e.g. 'parsers' -> 'parser').
        tail_words = tail.split("_")
        if len(tail_words) == 1 and len(parts) >= 2:
            parent_seg = parts[-2].rstrip("s") if parts[-2].endswith("s") else parts[-2]
            name_parts = parent_seg.split("_") + tail_words
        else:
            name_parts = tail_words
        class_name = "Test" + "".join(p.capitalize() for p in name_parts)
        template = (
            f'"""Tests for {target_module}."""\n\n'
            "import pytest\n\n"
            f"from {target_module} import *  # noqa: F401,F403\n\n\n"
            f"class {class_name}:\n"
            '    def test_placeholder(self) -> None:\n'
            '        """TODO: replace with real assertions."""\n'
            "        assert True\n"
        )
        return {
            "py_content": template,
            "target_module": target_module,
            "class_name": class_name,
            "_recipe_hint": {
                "recipe": "tests",
                "uri": "netsight://recipes/tests",
                "why": (
                    "You've scaffolded a NetSight test file. Read this "
                    "recipe before writing assertions — UNITTEST/ "
                    "conventions, fixture patterns (tmp_path / "
                    "monkeypatch), and the TDD workflow the project "
                    "follows. Note the filename goes under UNITTEST/, "
                    "not tests/."
                ),
            },
        }


_SUPPORTED_AUTH_METHODS = {"basic", "token", "keygen"}


def _vendor_class_name(vendor: str) -> str:
    """Return the CamelCase class name for a vendor string.

    Splits on underscores and hyphens so both ``acme`` → ``Acme`` and
    ``cisco-ios-xr`` → ``CiscoIosXr`` work correctly.
    """
    parts = re.split(r"[_\-]+", vendor)
    return "".join(p.capitalize() for p in parts if p)


class ScaffoldVendorPluginTool(ToolHandler):
    name = "scaffold_vendor_plugin"
    description = (
        "Generate the file map for a new NetSight vendor pack. The pack is a "
        "self-contained Python distribution that ships a BaseDeviceClient "
        "subclass, a parser_functions module (optional), and a bundled "
        "_data/ directory containing operations_catalog.toml, metadata.toml, "
        "auth.toml, and parser specs. Use this as the FIRST step when adding "
        "support for a new vendor. Naming follows <vendor>-<device_class>-"
        "<protocol>; the generated layout goes under packs/<name>/. The "
        "returned map is boilerplate — you still need to implement "
        "client.py's _authenticate/_execute_raw hooks, add operations to "
        "operations_catalog.toml, scaffold parser specs, and tag a release "
        "in the pack's own repository. Supported auth_method values: basic, "
        "token, keygen. Returns a dict of path -> content; does not touch "
        "disk."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "vendor": {"type": "string"},
            "device_class": {"type": "string"},
            "protocol": {"type": "string"},
            "auth_method": {
                "type": "string",
                "enum": sorted(_SUPPORTED_AUTH_METHODS),
            },
        },
        "required": ["vendor", "device_class", "protocol", "auth_method"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        vendor = kwargs.get("vendor", "")
        device_class = kwargs.get("device_class", "")
        protocol = kwargs.get("protocol", "")
        auth_method = kwargs.get("auth_method", "")

        if auth_method not in _SUPPORTED_AUTH_METHODS:
            return {
                "error": (
                    f"Unsupported auth_method '{auth_method}'. "
                    f"Supported: {sorted(_SUPPORTED_AUTH_METHODS)}"
                )
            }

        if not vendor:
            return {"error": "vendor parameter is required"}
        if not device_class:
            return {"error": "device_class parameter is required"}
        if not protocol:
            return {"error": "protocol parameter is required"}

        # Pack name and Python package name
        pack_name = f"{vendor}-{device_class}-{protocol}"
        pkg_name = f"netsight_pack_{vendor}_{device_class}_{protocol}".replace("-", "_")
        dist_name = f"netsight-pack-{vendor}-{device_class}-{protocol}"
        pack_dir = f"packs/{pack_name}"
        pkg_dir = f"{pack_dir}/{pkg_name}"

        # Class name: CamelCase from vendor only (e.g. acme -> Acme,
        # cisco-ios-xr -> CiscoIosXr)
        base_class = _vendor_class_name(vendor)
        class_name = f"{base_class}Client"

        # Human-readable vendor display name (title-cased vendor)
        vendor_display = vendor.replace("-", " ").replace("_", " ").title()

        files: dict[str, str] = {}

        # ------------------------------------------------------------------ #
        # pyproject.toml                                                       #
        # ------------------------------------------------------------------ #
        files[f"{pack_dir}/pyproject.toml"] = (
            "[build-system]\n"
            'requires = ["setuptools>=68.0", "wheel"]\n'
            'build-backend = "setuptools.build_meta"\n'
            "\n"
            "[project]\n"
            f'name = "{dist_name}"\n'
            'version = "0.1.0"\n'
            f'description = "NetSight pack for {vendor_display} {device_class} via {protocol}"\n'
            'requires-python = ">=3.14"\n'
            "dependencies = [\n"
            '    "netsight>=0.2.0",\n'
            "    # TODO: add vendor-specific deps (e.g. requests, xmltodict, pyangbind, etc.)\n"
            "]\n"
            "\n"
            '[project.entry-points."netsight.packs"]\n'
            f'{pack_name} = "{pkg_name}:register"\n'
            "\n"
            "[tool.setuptools.packages.find]\n"
            f'include = ["{pkg_name}*"]\n'
            "\n"
            "[tool.setuptools.package-data]\n"
            f'{pkg_name} = [\n'
            '    "_data/**/*.toml",\n'
            '    "_data/**/*.yaml",\n'
            '    "py.typed",\n'
            "]\n"
        )

        # ------------------------------------------------------------------ #
        # README.md                                                            #
        # ------------------------------------------------------------------ #
        files[f"{pack_dir}/README.md"] = (
            f"# {dist_name}\n"
            "\n"
            f"NetSight pack for {vendor_display} {device_class} over {protocol}.\n"
            "\n"
            "## Install\n"
            "\n"
            f"    pip install git+https://github.com/magicboxlab-ai/netsight-packs-{vendor}.git"
            f"#subdirectory=packs/{pack_name}\n"
            "\n"
            "## Usage\n"
            "\n"
            "    netsight pack list   # verify discovery\n"
            f"    netsight allowlist enable {pack_name} <operation-name>\n"
            "    netsight --device my-device show <operation-name>\n"
            "\n"
            "## Authoring\n"
            "\n"
            "See `netsight://recipes/pack_authoring` for the canonical pack contract.\n"
        )

        # ------------------------------------------------------------------ #
        # __init__.py                                                          #
        # ------------------------------------------------------------------ #
        files[f"{pkg_dir}/__init__.py"] = (
            f'"""NetSight pack: {vendor_display} {device_class} via {protocol}."""\n'
            "\n"
            "from __future__ import annotations\n"
            "\n"
            "import tomllib\n"
            "from importlib.metadata import version\n"
            "from importlib.resources import files\n"
            "\n"
            "from netsight.packs import PackInfo, PackRegistry\n"
            f"from {pkg_name}.client import {class_name}\n"
            "\n"
            f'_DISTRIBUTION = "{dist_name}"\n'
            f'_PACK_NAME = "{pack_name}"\n'
            "\n"
            "\n"
            "def _load_catalog_operation_names() -> frozenset[str]:\n"
            '    """Return the operation names declared in the pack\'s catalog.\n'
            "\n"
            "    The catalog at ``_data/operations_catalog.toml`` is the\n"
            "    single source of truth for this pack's operation set.\n"
            "    Reading it at registration time keeps ``PackInfo\n"
            "    .allowed_operations`` in sync with the catalog without\n"
            "    any drift window.\n"
            '    """\n'
            "    catalog_res = (\n"
            f'        files("{pkg_name}") / "_data" / "operations_catalog.toml"\n'
            "    )\n"
            '    with catalog_res.open("rb") as fh:\n'
            "        catalog = tomllib.load(fh)\n"
            "    return frozenset(catalog.keys())\n"
            "\n"
            "\n"
            "def register(registry: PackRegistry) -> None:\n"
            '    """Entry point — called by netsight.packs.loader at startup."""\n'
            "    try:\n"
            "        pack_version = version(_DISTRIBUTION)\n"
            "    except Exception:  # noqa: BLE001 — pip metadata missing in unusual installs\n"
            '        pack_version = "0.1.0"\n'
            "\n"
            "    info = PackInfo(\n"
            "        name=_PACK_NAME,\n"
            f'        vendor="{vendor}",\n'
            f'        device_type="{device_class}",\n'
            f'        protocol="{protocol}",\n'
            "        distribution=_DISTRIBUTION,\n"
            "        version=pack_version,\n"
            f"        client_class={class_name},\n"
            "        # Operation set comes from _data/operations_catalog.toml,\n"
            "        # NOT from a class-level attribute. The pack-design\n"
            "        # refactor deleted ALLOWED_OPERATIONS entirely.\n"
            "        allowed_operations=_load_catalog_operation_names(),\n"
            f'        config_root=files("{pkg_name}") / "_data",\n'
            "        metadata={\n"
            f'            "vendor": "{vendor_display}",\n'
            f'            "api_type": "{protocol}",\n'
            f'            "auth_method": "{auth_method}",\n'
            "        },\n"
            "    )\n"
            "    registry.register(info)\n"
        )

        # ------------------------------------------------------------------ #
        # client.py                                                            #
        # ------------------------------------------------------------------ #
        files[f"{pkg_dir}/client.py"] = (
            f'"""{vendor_display} {device_class} client."""\n'
            "\n"
            "from __future__ import annotations\n"
            "\n"
            "from typing import Any\n"
            "\n"
            "from netsight.base import BaseDeviceClient\n"
            "\n"
            "\n"
            f"class {class_name}(BaseDeviceClient):\n"
            f'    """{vendor_display} ({protocol}) client for {device_class} devices.\n'
            "\n"
            "    Operation metadata (commands, types, log channels,\n"
            "    required models) comes exclusively from\n"
            "    ``_data/operations_catalog.toml`` via the compiled\n"
            "    ``resolved_config`` dict passed to ``__init__``. Do NOT\n"
            "    declare a class-level ``ALLOWED_OPERATIONS`` attribute —\n"
            "    the pack-design refactor deleted that pattern because it\n"
            "    drifted from the catalog.\n"
            '    """\n'
            "\n"
            "    def _authenticate(self) -> str:\n"
            f"        # TODO: implement vendor-specific auth ({auth_method})\n"
            '        raise NotImplementedError("_authenticate not implemented")\n'
            "\n"
            "    def _execute_raw(self, operation: str, params: Any = None) -> Any:\n"
            "        # Dispatch is fully data-driven. Look up the XML\n"
            "        # payload / type / log_type in the per-instance\n"
            "        # dispatch dicts populated by BaseDeviceClient from\n"
            "        # the catalog:\n"
            "        #\n"
            "        #     op_type = self._op_types[operation]\n"
            "        #     if op_type == 'op':\n"
            "        #         cmd = self._op_commands[operation]\n"
            "        #         ... build request with type=op + cmd ...\n"
            "        #     elif op_type == 'log':\n"
            "        #         log_type = self._log_types[operation]\n"
            "        #         ... build request with type=log + log-type ...\n"
            "        #\n"
            "        # TODO: implement the vendor-specific HTTP / SSH / \n"
            "        # gRPC call.\n"
            "        raise NotImplementedError(\n"
            '            f"_execute_raw({operation!r}) not implemented"\n'
            "        )\n"
            "\n"
            "    def get_device_info(self) -> dict:\n"
            "        # TODO: run the catalog's ``show_system_info`` op\n"
            "        # (or equivalent) and return a dict with at least\n"
            "        # ``hostname`` and ``model`` keys.\n"
            '        raise NotImplementedError("get_device_info not implemented")\n'
            "\n"
            "    def get_supported_operations(self) -> list[str]:\n"
            "        # The catalog-backed op list. ``_op_commands`` is\n"
            "        # populated by BaseDeviceClient from the compiled\n"
            "        # resolved_config at construction time.\n"
            "        return sorted(self._op_commands.keys())\n"
        )

        # ------------------------------------------------------------------ #
        # py.typed (PEP 561 marker)                                           #
        # ------------------------------------------------------------------ #
        files[f"{pkg_dir}/py.typed"] = ""

        # ------------------------------------------------------------------ #
        # _data/metadata.toml                                                 #
        # ------------------------------------------------------------------ #
        files[f"{pkg_dir}/_data/metadata.toml"] = (
            "[metadata]\n"
            f'vendor = "{vendor}"\n'
            f'display_name = "{vendor_display}"\n'
            f'api_type = "{protocol}"\n'
            'description = "TODO: describe this pack"\n'
        )

        # ------------------------------------------------------------------ #
        # _data/auth.toml                                                     #
        # ------------------------------------------------------------------ #
        files[f"{pkg_dir}/_data/auth.toml"] = (
            "[auth]\n"
            f'method = "{auth_method}"\n'
            "# TODO: add method-specific auth config\n"
        )

        # ------------------------------------------------------------------ #
        # _data/operations_catalog.toml                                       #
        # ------------------------------------------------------------------ #
        files[f"{pkg_dir}/_data/operations_catalog.toml"] = (
            f"# Operations catalog for {pack_name}\n"
            "#\n"
            "# Each TOML table below is one operation this pack knows how to execute.\n"
            "# Installing the pack does NOT grant permission to run these — users must\n"
            "# opt in via `netsight allowlist enable`. See netsight://recipes/pack_authoring\n"
            "# for the authoring guide.\n"
            "#\n"
            "# Example:\n"
            "#\n"
            "# [show_system_info]\n"
            '# command = "..."\n'
            '# type = "op"\n'
            '# category = "system"\n'
            '# description = "Show system info"\n'
            "# read_only = true\n"
            '# parser_spec = "parsers/show_system_info.yaml"\n'
        )

        # ------------------------------------------------------------------ #
        # _data/validator_schema.toml                                         #
        # ------------------------------------------------------------------ #
        files[f"{pkg_dir}/_data/validator_schema.toml"] = (
            "# Vendor-specific validator schema (optional)\n"
            "# If this pack ships a PanOSXMLOperationValidator-style class, declare\n"
            "# its schema here. Otherwise leave empty.\n"
        )

        return {
            "files": files,
            "file_count": len(files),
            "pack_name": pack_name,
            "vendor": vendor,
            "device_class": device_class,
            "protocol": protocol,
            "class_name": class_name,
            "_recipe_hint": {
                "recipe": "pack_authoring",
                "uri": "netsight://recipes/pack_authoring",
                "why": (
                    "You've scaffolded a vendor pack skeleton. Read this recipe "
                    "before implementing client.py — the PackInfo contract, the "
                    "BaseDeviceClient hooks (_authenticate + _execute_raw, NOT "
                    "execute() directly), and the operations_catalog.toml schema "
                    "are all documented there. The paloalto-firewall-xml pack is "
                    "the canonical reference implementation."
                ),
            },
        }


_SUPPORTED_TRANSPORTS = {"tcp", "stdio", "websocket"}

_SERVICE_NAME_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def _service_class_name(name: str) -> str:
    """Return the CamelCase class name for a snake_case service name.

    Splits on underscores and appends ``Service``.  E.g. ``"audit_logger"`` →
    ``"AuditLoggerService"``.
    """
    return "".join(seg.capitalize() for seg in name.split("_")) + "Service"


class ScaffoldServiceTool(ToolHandler):
    name = "scaffold_service"
    description = (
        "Generate the file map for a new netsight-ops service. The service is "
        "a self-contained module that ships a ServiceBase subclass with stub "
        "start/stop/health hooks, an __init__.py register() entry point, and "
        "a basic pytest test file. Use this as the FIRST step when adding "
        "a new runtime service to the netsight-ops repo. Supported transport "
        "values: tcp, stdio, websocket. Returns a dict of path -> content "
        "plus a pyproject_snippet; does not touch disk."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "snake_case service name, e.g. 'audit_logger'.",
            },
            "display_name": {
                "type": "string",
                "description": "Human-friendly name, e.g. 'Audit Logger Service'.",
            },
            "description": {
                "type": "string",
                "description": "One-line summary of what this service does.",
            },
            "transport": {
                "type": "string",
                "enum": sorted(_SUPPORTED_TRANSPORTS),
                "description": "Transport protocol. Default: 'tcp'.",
            },
        },
        "required": ["name", "display_name", "description"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        name = kwargs.get("name", "")
        display_name = kwargs.get("display_name", "")
        description = kwargs.get("description", "")
        transport = kwargs.get("transport", "tcp")

        # Validate name
        if not _SERVICE_NAME_RE.match(name):
            return {
                "error": (
                    f"Invalid service name '{name}'. "
                    "Must match ^[a-z][a-z0-9_]*$ (snake_case, starts with a letter)."
                )
            }

        # Validate transport
        if transport not in _SUPPORTED_TRANSPORTS:
            return {
                "error": (
                    f"Unsupported transport '{transport}'. "
                    f"Supported: {sorted(_SUPPORTED_TRANSPORTS)}"
                )
            }

        class_name = _service_class_name(name)
        files: dict[str, str] = {}

        # ------------------------------------------------------------------ #
        # netsight_ops/{name}/__init__.py                                      #
        # ------------------------------------------------------------------ #
        files[f"netsight_ops/{name}/__init__.py"] = (
            f'"""netsight-ops service: {display_name}."""\n'
            "\n"
            "from __future__ import annotations\n"
            "\n"
            "from netsight_ops.registry import ServiceInfo, ServiceRegistry\n"
            f"from netsight_ops.{name}.service import {class_name}\n"
            "\n"
            f'_SERVICE_NAME = "{name}"\n'
            "\n"
            "\n"
            "def register(registry: ServiceRegistry) -> None:\n"
            '    """Entry point — called by netsight_ops loader at startup."""\n'
            "    info = ServiceInfo(\n"
            f'        name=_SERVICE_NAME,\n'
            f'        display_name="{display_name}",\n'
            f'        description="{description}",\n'
            f'        transport="{transport}",\n'
            f"        service_class={class_name},\n"
            "    )\n"
            "    registry.register(info)\n"
        )

        # ------------------------------------------------------------------ #
        # netsight_ops/{name}/service.py                                       #
        # ------------------------------------------------------------------ #
        files[f"netsight_ops/{name}/service.py"] = (
            f'"""{display_name} service implementation."""\n'
            "\n"
            "from __future__ import annotations\n"
            "\n"
            "import logging\n"
            "\n"
            "from netsight_ops.base import ServiceBase\n"
            "\n"
            f"logger = logging.getLogger(__name__)\n"
            "\n"
            "\n"
            f"class {class_name}(ServiceBase):\n"
            f'    """{display_name}.\n'
            "\n"
            f"    {description}\n"
            "\n"
            f"    Transport: {transport}\n"
            '    """\n'
            "\n"
            "    def start(self) -> None:\n"
            '        """Start the service and begin handling requests."""\n'
            f"        logger.info(\"Starting {display_name}\")\n"
            "        # TODO: implement service startup\n"
            "        raise NotImplementedError(\"start() not implemented\")\n"
            "\n"
            "    def stop(self) -> None:\n"
            '        """Gracefully shut down the service."""\n'
            f"        logger.info(\"Stopping {display_name}\")\n"
            "        # TODO: implement graceful shutdown\n"
            "        raise NotImplementedError(\"stop() not implemented\")\n"
            "\n"
            "    def health(self) -> dict:\n"
            '        """Return a health status dict with at least a ``status`` key."""\n'
            "        # TODO: implement real health check\n"
            "        return {\"status\": \"unknown\", \"service\": self.__class__.__name__}\n"
        )

        # ------------------------------------------------------------------ #
        # tests/test_{name}_service.py                                         #
        # ------------------------------------------------------------------ #
        files[f"tests/test_{name}_service.py"] = (
            f'"""Basic tests for {display_name}."""\n'
            "\n"
            "import pytest\n"
            "\n"
            f"from netsight_ops.{name}.service import {class_name}\n"
            "\n"
            "\n"
            f"class Test{class_name}:\n"
            "    def test_health_returns_dict_with_status(self) -> None:\n"
            f'        """health() must return a dict containing a ``status`` key."""\n'
            f"        svc = {class_name}()\n"
            "        result = svc.health()\n"
            "        assert isinstance(result, dict)\n"
            "        assert \"status\" in result\n"
            "\n"
            "    def test_start_raises_not_implemented(self) -> None:\n"
            '        """start() stub must raise NotImplementedError until implemented."""\n'
            f"        svc = {class_name}()\n"
            "        with pytest.raises(NotImplementedError):\n"
            "            svc.start()\n"
            "\n"
            "    def test_stop_raises_not_implemented(self) -> None:\n"
            '        """stop() stub must raise NotImplementedError until implemented."""\n'
            f"        svc = {class_name}()\n"
            "        with pytest.raises(NotImplementedError):\n"
            "            svc.stop()\n"
        )

        # ------------------------------------------------------------------ #
        # pyproject_snippet                                                     #
        # ------------------------------------------------------------------ #
        pyproject_snippet = (
            '[project.entry-points."netsight_ops.services"]\n'
            f'{name} = "netsight_ops.{name}:register"\n'
        )

        return {
            "files": files,
            "file_count": len(files),
            "service_name": name,
            "class_name": class_name,
            "transport": transport,
            "pyproject_snippet": pyproject_snippet,
            "note": (
                "Add the pyproject_snippet to the netsight-ops pyproject.toml under "
                "[project.entry-points.\"netsight_ops.services\"]. "
                "The generated files go in the netsight-ops repo, not api-sandbox."
            ),
            "_recipe_hint": {
                "recipe": "pack_authoring",
                "uri": "netsight://recipes/pack_authoring",
                "why": (
                    "You've scaffolded a netsight-ops service skeleton. Read this "
                    "recipe before implementing service.py — the ServiceBase contract, "
                    "the start/stop/health lifecycle hooks, and the ServiceRegistry "
                    "entry-point convention are all documented there. The netsight-ops "
                    "repo follows the same pack contract as vendor packs: the "
                    "register() entry point is the single integration surface."
                ),
            },
        }


class ScaffoldCredentialProviderTool(ToolHandler):
    name = "scaffold_credential_provider"
    description = (
        "Generate the file map for a new NetSight credential provider package. "
        "Credential providers implement the CredentialProvider protocol and are "
        "discovered via the 'netsight.credential_providers' entry-point group. "
        "Use this as the FIRST step when shipping a custom provider "
        "(e.g. HashiCorp Vault, AWS Secrets Manager, 1Password). The generated "
        "package contains an __init__.py with a register() entry point, a "
        "provider.py with the CredentialProvider protocol stub, and a "
        "pyproject_snippet showing the required entry-point declaration. "
        "Returns a dict of path -> content; does not touch disk."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": (
                    "Provider name used in devices.yaml (e.g. 'hashicorp-vault'). "
                    "Must be lowercase, hyphens or underscores allowed."
                ),
            },
            "display_name": {
                "type": "string",
                "description": "Human-friendly name (e.g. 'HashiCorp Vault').",
            },
            "description": {
                "type": "string",
                "description": "One-line summary of what this provider does.",
            },
        },
        "required": ["name", "display_name", "description"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        name = kwargs.get("name", "").strip()
        display_name = kwargs.get("display_name", "").strip()
        description = kwargs.get("description", "").strip()

        if not name:
            return {"error": "name parameter is required"}
        if not display_name:
            return {"error": "display_name parameter is required"}
        if not description:
            return {"error": "description parameter is required"}

        # Derive the Python package name: replace hyphens with underscores,
        # prefix with netsight_creds_ so the namespace is unambiguous.
        name_underscored = name.replace("-", "_")
        pkg_name = f"netsight_creds_{name_underscored}"
        dist_name = f"netsight-creds-{name.replace('_', '-')}"

        # CamelCase class name from the provider name.
        class_name = (
            "".join(seg.capitalize() for seg in re.split(r"[_\-]+", name))
            + "CredentialProvider"
        )

        files: dict[str, str] = {}

        # ------------------------------------------------------------------ #
        # {pkg_name}/__init__.py                                              #
        # ------------------------------------------------------------------ #
        files[f"{pkg_name}/__init__.py"] = (
            f'"""NetSight credential provider: {display_name}."""\n'
            "\n"
            "from __future__ import annotations\n"
            "\n"
            "from netsight.credentials import CredentialProviderInfo\n"
            "from netsight.credentials.registry import CredentialProviderRegistry\n"
            f"from {pkg_name}.provider import {class_name}\n"
            "\n"
            f'_PROVIDER_NAME = "{name}"\n'
            "\n"
            "\n"
            "def register(registry: CredentialProviderRegistry) -> None:\n"
            '    """Entry point — called by the credential loader at startup."""\n'
            "    info = CredentialProviderInfo(\n"
            f"        name=_PROVIDER_NAME,\n"
            f'        display_name="{display_name}",\n'
            f'        description="{description}",\n'
            f"        provider={class_name}(),\n"
            "        builtin=False,\n"
            "    )\n"
            "    registry.register(info=info)\n"
        )

        # ------------------------------------------------------------------ #
        # {pkg_name}/provider.py                                              #
        # ------------------------------------------------------------------ #
        files[f"{pkg_name}/provider.py"] = (
            f'"""{display_name} credential provider implementation."""\n'
            "\n"
            "from __future__ import annotations\n"
            "\n"
            "import logging\n"
            "from typing import Any\n"
            "\n"
            "from netsight.credentials.exceptions import (\n"
            "    CredentialNotFoundError,\n"
            "    CredentialProviderError,\n"
            ")\n"
            "\n"
            f"logger = logging.getLogger(__name__)\n"
            "\n"
            "\n"
            f"class {class_name}:\n"
            f'    """{display_name} credential backend.\n'
            "\n"
            f"    {description}\n"
            "\n"
            "    Security invariant: NEVER log, cache to disk, or include\n"
            "    credential *values* in __repr__, exceptions, or any other\n"
            "    observable output. Key *names* are safe to log.\n"
            '    """\n'
            "\n"
            "    @property\n"
            "    def name(self) -> str:\n"
            f'        return "{name}"\n'
            "\n"
            "    def get_credential(self, *, key: str, **context: Any) -> str:\n"
            '        """Return the secret value for *key*.\n'
            "\n"
            "        Parameters\n"
            "        ----------\n"
            "        key:\n"
            "            Lookup key as specified in the device's\n"
            "            ``credential.key`` field in devices.yaml.\n"
            "        context:\n"
            "            Optional hints (``host``, ``username``, etc.).\n"
            "\n"
            "        Raises\n"
            "        ------\n"
            "        CredentialNotFoundError\n"
            "            If the key does not exist in this backend.\n"
            "        CredentialProviderError\n"
            "            If the backend is unreachable or misconfigured.\n"
            '        """\n'
            "        # TODO: implement credential lookup against the backend.\n"
            "        # Example:\n"
            "        #   value = self._client.get_secret(key)\n"
            "        #   if value is None:\n"
            "        #       raise CredentialNotFoundError(key)\n"
            "        #   return value\n"
            "        raise CredentialNotFoundError(\n"
            f'            f"Key {{key!r}} not found in {display_name} — '
            'get_credential() not yet implemented"\n'
            "        )\n"
            "\n"
            "    def health_check(self) -> dict:\n"
            '        """Return provider health for ``netsight doctor``.\n'
            "\n"
            "        Returns a dict with at least ``name`` and ``status``\n"
            '        keys. ``status`` must be ``"ok"`` or ``"error"``.\n'
            '        """\n'
            "        # TODO: implement real connectivity/auth check.\n"
            "        return {\n"
            f'            "name": "{name}",\n'
            '            "status": "error",\n'
            '            "detail": "health_check() not yet implemented",\n'
            "        }\n"
        )

        # ------------------------------------------------------------------ #
        # pyproject.toml snippet                                               #
        # ------------------------------------------------------------------ #
        pyproject_snippet = (
            "[build-system]\n"
            'requires = ["setuptools>=68.0", "wheel"]\n'
            'build-backend = "setuptools.build_meta"\n'
            "\n"
            "[project]\n"
            f'name = "{dist_name}"\n'
            'version = "0.1.0"\n'
            f'description = "{description}"\n'
            'requires-python = ">=3.14"\n'
            "dependencies = [\n"
            '    "netsight-sdk>=1.0.0",\n'
            "    # TODO: add provider-specific deps\n"
            "]\n"
            "\n"
            '[project.entry-points."netsight.credential_providers"]\n'
            f'{name} = "{pkg_name}:register"\n'
            "\n"
            "[tool.setuptools.packages.find]\n"
            f'include = ["{pkg_name}*"]\n'
        )

        return {
            "files": files,
            "file_count": len(files),
            "provider_name": name,
            "class_name": class_name,
            "pkg_name": pkg_name,
            "dist_name": dist_name,
            "pyproject_snippet": pyproject_snippet,
            "note": (
                "Write the files under a new directory named after the distribution "
                f"(e.g. {dist_name}/). Add pyproject_snippet as the package's "
                "pyproject.toml. Install with 'pip install -e .' to activate the "
                "provider, then verify with 'netsight doctor' and read "
                "netsight://credentials to confirm registration."
            ),
            "_recipe_hint": {
                "recipe": "plugin_clients",
                "uri": "netsight://recipes/plugin_clients",
                "why": (
                    "You've scaffolded a credential provider skeleton. The "
                    "CredentialProvider protocol contract (get_credential, "
                    "health_check, name property), the security invariant "
                    "(never log values), and the entry-point registration "
                    "pattern all follow the same conventions as vendor packs. "
                    "Read this recipe before implementing provider.py — it "
                    "documents the common mistakes that cause silent lookup "
                    "failures or credential leaks."
                ),
            },
        }


def register_all() -> None:
    """Register all scaffolding tools."""
    tool_registry.register(ScaffoldParserSpecTool())
    tool_registry.register(ScaffoldOperationEntryTool())
    tool_registry.register(ScaffoldCustomFunctionTool())
    tool_registry.register(ScaffoldFieldTypeTool())
    tool_registry.register(ScaffoldTestFileTool())
    tool_registry.register(ScaffoldVendorPluginTool())
    tool_registry.register(ScaffoldServiceTool())
    tool_registry.register(ScaffoldCredentialProviderTool())
