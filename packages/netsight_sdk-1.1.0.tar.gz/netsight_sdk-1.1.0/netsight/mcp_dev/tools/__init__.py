"""ToolHandler ABC and ToolRegistry for MCP dev server.

Plan A provides the ABC + registry. Plan B populates it with concrete tools.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


class ToolHandler(ABC):
    """Base class for MCP tool handlers."""

    name: str
    description: str
    parameters_schema: dict[str, Any]

    @abstractmethod
    def execute(self, **kwargs: Any) -> Any:
        """Execute the tool with given arguments."""

    def tool_definition(self) -> dict[str, Any]:
        """Return the MCP tool definition."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.parameters_schema,
        }


class ToolRegistry:
    """Registry of tool handlers keyed by name."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolHandler] = {}

    def register(self, tool: ToolHandler) -> None:
        """Register a tool handler."""
        self._tools[tool.name] = tool
        logger.debug("Registered tool: %s", tool.name)

    def get(self, name: str) -> ToolHandler | None:
        """Get a tool by name, or None if not registered."""
        return self._tools.get(name)

    def list_handlers(self) -> list[ToolHandler]:
        """Return all registered tools."""
        return list(self._tools.values())


tool_registry = ToolRegistry()
