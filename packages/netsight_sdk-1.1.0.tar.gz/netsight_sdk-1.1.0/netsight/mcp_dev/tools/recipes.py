"""Tool wrapper for the implementation-recipe catalog.

Thin convenience tool that delegates to :class:`RecipesHandler`. Exists
alongside the ``netsight://recipes`` resource so the model has a
tool-list-discoverable entry point — ``tools/list`` shows every tool on
session start, so a tool is more visible than a bare URI namespace.
"""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.tools import ToolHandler, tool_registry


class GetImplementationRecipeTool(ToolHandler):
    name = "get_implementation_recipe"
    description = (
        "Fetch a canonical NetSight implementation pattern. Each recipe "
        "returns a structured dict with ``canonical_example``, "
        "``common_mistakes``, ``canonical_source_files``, and "
        "cross-references to related recipes, resources, and tools.\n\n"
        "**Call this BEFORE writing new code in an unfamiliar area.** "
        "NetSight uses specific conventions (numpydoc docstrings for new "
        "modules, stdlib logging NOT OSLog, parser specs with quoted "
        "hyphenated JMESPath keys, plugin clients that MUST NOT override "
        "``execute()``, decorator-form registries, NetSightError "
        "hierarchy, conventional-commit prefixes, Keep a Changelog "
        "format) that an LLM will otherwise get wrong by analogy with "
        "other Python projects. This catalog exists specifically to "
        "prevent that drift.\n\n"
        "Also call this when a scaffolding tool returns a "
        "``_recipe_hint`` field — the hint points at the exact recipe "
        "that applies to the content you are about to write.\n\n"
        "Current categories: ``docstrings``, ``parser_specs``, "
        "``plugin_clients``, ``logging``, ``self_documentation``, "
        "``tests``, ``registry_usage``, ``exception_handling``, "
        "``commits``, ``changelog``, ``mcp_handlers``, "
        "``security_workflow``, ``pack_authoring``. For a browsable "
        "index, read ``netsight://recipes``."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "category": {
                "type": "string",
                "description": (
                    "Recipe category name. One of: docstrings, "
                    "parser_specs, plugin_clients, logging, "
                    "self_documentation, tests, registry_usage, "
                    "exception_handling, commits, changelog, "
                    "mcp_handlers, security_workflow, pack_authoring."
                ),
            }
        },
        "required": ["category"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        # Delegates to the resource handler so tool and resource stay in
        # lockstep — one source of truth, two access paths.
        from netsight.mcp_dev.resources.recipes import RecipesHandler

        category = kwargs.get("category", "")
        return RecipesHandler().get(f"netsight://recipes/{category}")


def register_all() -> None:
    """Register the implementation-recipe tool."""
    tool_registry.register(GetImplementationRecipeTool())
