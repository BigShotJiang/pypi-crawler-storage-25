"""MCP inspection tools — find usages, definitions, traces, and impact."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from netsight.mcp_dev.path_security import (
    PROJECT_ROOT,
    SIBLING_ROOTS,
    is_path_allowed,
    is_path_allowed_for_root,
)
from netsight.mcp_dev.tools import ToolHandler, tool_registry


# Search scope → list of (root_dir, extensions) tuples.
#
# ``source`` = the Python package (default). Historical name; kept for
# backward compatibility with the original scoped behaviour that avoided
# test-file noise. ``tests`` = UNITTEST/ only. ``all`` = source + tests +
# top-level project files (CLAUDE.md, pyproject.toml, README.md, etc.) and
# the config tree. Scope values map to these root sets via :func:`_scope_roots`.
_SCOPE_ROOTS: dict[str, list[tuple[str, tuple[str, ...]]]] = {
    "source": [("netsight", (".py",))],
    "tests": [("UNITTEST", (".py",))],
    "all": [
        ("netsight", (".py",)),
        ("UNITTEST", (".py",)),
        ("TOOLS", (".py", ".sh")),
        ("examples", (".py",)),
        ("config", (".toml", ".yaml", ".yml")),
        # Top-level project files — handled specially as rooted globs
        # rather than a directory walk. See _scope_roots().
    ],
}

_VALID_SCOPES = frozenset({"source", "tests", "all", "cross_repo"})

# Subdirectories (relative to sibling repo root) that are searched per
# sibling when scope="cross_repo" is active. The first list covers pure-
# Python repos (netsight-ops); the second covers pack repos that also
# contain YAML/TOML config.
_CROSS_REPO_SCOPE: list[tuple[str, tuple[str, ...]]] = [
    ("netsight_ops", (".py",)),
    ("tests", (".py",)),
]

_CROSS_REPO_PACK_SCOPE: list[tuple[str, tuple[str, ...]]] = [
    ("packs", (".py", ".yaml", ".toml")),
]


def _scope_roots(scope: str) -> list[tuple[Path, tuple[str, ...]]]:
    """Return the list of (root_directory, extensions) tuples for a scope.

    ``scope='all'`` additionally includes top-level markdown/toml files
    (CLAUDE.md, README.md, CHANGELOG.md, pyproject.toml) which live at the
    project root and would otherwise be missed by a subdirectory walk.

    ``scope='cross_repo'`` is handled by :func:`_cross_repo_search` and
    should not be passed here directly; callers that receive ``cross_repo``
    must route to that helper instead. This function falls back to ``"all"``
    if given ``"cross_repo"`` so that the SDK side of a cross-repo search
    can reuse the same root list.
    """
    if scope not in _VALID_SCOPES:
        scope = "source"
    # cross_repo uses "all" for the SDK side; sibling roots are handled
    # separately via _scope_roots_for_sibling / _cross_repo_search.
    effective = "all" if scope == "cross_repo" else scope
    roots: list[tuple[Path, tuple[str, ...]]] = []
    for rel_dir, exts in _SCOPE_ROOTS[effective]:
        root = PROJECT_ROOT / rel_dir
        if root.exists():
            roots.append((root, exts))
    # For ``all`` (and ``cross_repo``), add a sentinel entry that
    # _text_search interprets as "scan top-level project files directly,
    # not a subtree walk".
    if effective == "all":
        roots.append((PROJECT_ROOT, (".md", ".toml")))
    return roots


def _scope_roots_for_sibling(
    repo_name: str, root: Path
) -> list[tuple[Path, tuple[str, ...]]]:
    """Return (abs_dir, extensions) pairs for a sibling repo.

    The directory list is chosen based on naming convention: repos whose
    name contains ``"packs"`` use :data:`_CROSS_REPO_PACK_SCOPE`; all
    others use :data:`_CROSS_REPO_SCOPE`.
    """
    scope_spec = (
        _CROSS_REPO_PACK_SCOPE if "packs" in repo_name else _CROSS_REPO_SCOPE
    )
    pairs: list[tuple[Path, tuple[str, ...]]] = []
    for rel_dir, exts in scope_spec:
        candidate = root / rel_dir
        if candidate.is_dir():
            pairs.append((candidate, exts))
    return pairs


def _cross_repo_search(pattern: str) -> list[dict]:
    """Search all roots (SDK + siblings) and merge results.

    SDK hits are returned with their existing unprefixed ``file`` keys for
    backward compatibility (e.g. ``"netsight/foo.py"``). Hits from sibling
    repos are prefixed with ``"{repo_name}:"`` so callers can tell them
    apart (e.g. ``"netsight-ops:netsight_ops/registry.py"``).
    """
    results: list[dict] = []

    # SDK side — use scope="all" for maximum coverage
    sdk_hits = _text_search(pattern, search_roots=_scope_roots("all"))
    results.extend(sdk_hits)

    # Sibling repos
    for repo_name, sibling_root in SIBLING_ROOTS.items():
        sibling_pairs = _scope_roots_for_sibling(repo_name, sibling_root)
        if not sibling_pairs:
            continue
        sibling_hits = _text_search(
            pattern,
            search_roots=sibling_pairs,
            repo_label=repo_name,
            sibling_root=sibling_root,
        )
        results.extend(sibling_hits)

    return results


def _text_search(
    pattern: str,
    allowed_extensions: tuple[str, ...] = (".py",),
    search_root: Path | None = None,
    search_roots: list[tuple[Path, tuple[str, ...]]] | None = None,
    repo_label: str | None = None,
    sibling_root: Path | None = None,
) -> list[dict[str, Any]]:
    """Search the project for a regex pattern, returning matches via path_security.

    Args:
        pattern: Regex pattern to search for.
        allowed_extensions: File extensions to include when ``search_root`` or
            the default are used. Ignored when ``search_roots`` is supplied.
        search_root: Single subdirectory to restrict search to; defaults to
            PROJECT_ROOT. Mutually exclusive with ``search_roots``.
        search_roots: List of (directory, extensions) tuples for a
            multi-root search. When the directory IS ``PROJECT_ROOT`` itself,
            the walk is non-recursive — this is how top-level files like
            CLAUDE.md are scanned without traversing into subdirectories.
        repo_label: When set, indicates results belong to a sibling repo and
            the ``file`` key in each hit is prefixed with ``"{repo_label}:"``.
            Must be provided together with ``sibling_root``.
        sibling_root: Alternate root to use for ``path.relative_to()`` and
            ``is_path_allowed_for_root()`` checks. When provided, paths are
            resolved relative to this root rather than ``PROJECT_ROOT``.
    """
    hits: list[dict[str, Any]] = []
    regex = re.compile(pattern)

    # Determine the anchor root used for relative-path computation and
    # security checks.  For sibling repos this is the sibling root; for the
    # SDK it is PROJECT_ROOT (the historic default).
    effective_root: Path = sibling_root if sibling_root is not None else PROJECT_ROOT

    if search_roots is not None:
        # top_level_only sentinel: when the search dir IS the effective root,
        # glob only the immediate level (no recursion) so we don't accidentally
        # traverse the entire tree looking for top-level .md/.toml files.
        roots: list[tuple[Path, tuple[str, ...], bool]] = [
            (root, exts, root == effective_root) for root, exts in search_roots
        ]
    else:
        base = search_root if search_root is not None else effective_root
        roots = [(base, allowed_extensions, False)]

    seen: set[str] = set()
    for base, exts, top_level_only in roots:
        for ext in exts:
            iterator = base.glob(f"*{ext}") if top_level_only else base.rglob(f"*{ext}")
            for path in iterator:
                try:
                    rel = path.relative_to(effective_root).as_posix()
                except ValueError:
                    continue
                if rel in seen:
                    continue
                # Use the appropriate security check depending on whether this
                # is a sibling-repo search or the primary SDK tree.
                if sibling_root is not None and repo_label is not None:
                    if not is_path_allowed_for_root(rel, sibling_root, repo_label):
                        continue
                else:
                    if not is_path_allowed(rel):
                        continue
                try:
                    lines = path.read_text(encoding="utf-8").splitlines()
                except (OSError, UnicodeDecodeError):
                    continue
                seen.add(rel)
                # Prefix with repo label for sibling-repo hits so callers can
                # distinguish them from SDK-rooted paths.
                file_key = f"{repo_label}:{rel}" if repo_label is not None else rel
                for lineno, line in enumerate(lines, start=1):
                    if regex.search(line):
                        hits.append({
                            "file": file_key,
                            "line_number": lineno,
                            "line": line.rstrip(),
                        })
    return hits


class FindUsagesTool(ToolHandler):
    name = "find_usages"
    description = (
        "Find all files and line numbers that reference a Python symbol "
        "(class, function, variable) in the NetSight codebase. Use this as "
        "the 'who calls this?' tool when tracing code paths, investigating "
        "a failing test, or starting a refactor. Pair with find_definitions "
        "(where it's declared) and analyze_impact (refactor blast radius).\n\n"
        "The ``scope`` parameter controls which part of the tree is searched:\n"
        "  - ``source`` (default): ``netsight/**/*.py`` only. Safe default "
        "for code-lookup questions — no test-file noise.\n"
        "  - ``tests``: ``UNITTEST/**/*.py`` only. Use when the question is "
        "specifically about test coverage of a symbol.\n"
        "  - ``all``: source + tests + TOOLS/ + examples/ + config/ + the "
        "top-level ``*.md`` and ``*.toml`` files. Use for refactor impact "
        "analysis where you need every reference, including test files, "
        "CLAUDE.md, and the config tree.\n"
        "  - ``cross_repo``: everything in ``all`` plus all detected sibling "
        "repos (netsight-ops, netsight-packs-*). Sibling hits are prefixed "
        "with ``\"{repo_name}:\"`` in the ``file`` key so they are "
        "distinguishable from SDK paths."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "symbol": {"type": "string"},
            "scope": {
                "type": "string",
                "enum": ["source", "tests", "all", "cross_repo"],
                "description": (
                    "Search scope: 'source' = netsight/ only (default), "
                    "'tests' = UNITTEST/ only, 'all' = every allowlisted "
                    "file including tests, config, tooling, docs, and "
                    "top-level files, 'cross_repo' = all of the above plus "
                    "sibling repos with prefixed file keys."
                ),
            },
        },
        "required": ["symbol"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        symbol = kwargs.get("symbol", "")
        scope = kwargs.get("scope", "source")
        if scope not in _VALID_SCOPES:
            scope = "source"
        pattern = rf"\b{re.escape(symbol)}\b"
        if scope == "cross_repo":
            usages = _cross_repo_search(pattern)
        else:
            usages = _text_search(pattern, search_roots=_scope_roots(scope))
        return {
            "symbol": symbol,
            "scope": scope,
            "count": len(usages),
            "usages": usages,
        }


class FindDefinitionsTool(ToolHandler):
    name = "find_definitions"
    description = (
        "Locate where a Python class or function is defined in the NetSight "
        "codebase. Use this as the entry point when you see a class/function "
        "name in code, an error, or a config reference and need to jump to "
        "its implementation. Pair with find_usages to see who calls it.\n\n"
        "The ``scope`` parameter controls which part of the tree is searched:\n"
        "  - ``source`` (default): ``netsight/**/*.py`` only.\n"
        "  - ``tests``: ``UNITTEST/**/*.py`` only — use when you want to "
        "find test classes or test helper functions.\n"
        "  - ``all``: both source and test trees.\n"
        "  - ``cross_repo``: all of the above plus detected sibling repos "
        "(netsight-ops, netsight-packs-*). Sibling hits carry a "
        "``\"{repo_name}:\"`` prefix in the ``file`` key."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "symbol": {"type": "string"},
            "scope": {
                "type": "string",
                "enum": ["source", "tests", "all", "cross_repo"],
                "description": (
                    "Search scope: 'source' = netsight/ only (default), "
                    "'tests' = UNITTEST/ only, 'all' = both, "
                    "'cross_repo' = all repos including siblings."
                ),
            },
        },
        "required": ["symbol"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        symbol = kwargs.get("symbol", "")
        scope = kwargs.get("scope", "source")
        if scope not in _VALID_SCOPES:
            scope = "source"
        pattern = rf"^\s*(?:class|def)\s+{re.escape(symbol)}\b"
        if scope == "cross_repo":
            definitions = _cross_repo_search(pattern)
        else:
            definitions = _text_search(pattern, search_roots=_scope_roots(scope))
        return {
            "symbol": symbol,
            "scope": scope,
            "count": len(definitions),
            "definitions": definitions,
        }


class ExtractXmlStructureTool(ToolHandler):
    name = "extract_xml_structure"
    description = (
        "Convert a sample XML device response into a flat list of "
        "JMESPath-friendly dotted paths. This is the companion tool to "
        "scaffold_parser_spec: before writing a NetSight parser spec, use "
        "this to inspect the XML structure and decide which subtree should "
        "become the spec's root: and which leaves become fields[*].path. "
        "Pair with validate_jmespath to test candidate paths against the "
        "XML dict."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "xml": {"type": "string"},
        },
        "required": ["xml"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        import xmltodict

        xml = kwargs.get("xml", "")
        try:
            parsed = xmltodict.parse(xml)
        except Exception as e:
            return {"error": f"Could not parse XML: {e}"}

        paths: list[str] = []

        def walk(node: Any, prefix: list[str]) -> None:
            if isinstance(node, dict):
                for key, child in node.items():
                    if key.startswith("@") or key == "#text":
                        continue
                    walk(child, prefix + [key])
            elif isinstance(node, list):
                if node:
                    walk(node[0], prefix)
            else:
                paths.append(".".join(prefix))

        walk(parsed, [])
        return {"paths": sorted(set(paths)), "count": len(set(paths))}


def _coerce_dict(value: Any) -> dict[str, Any]:
    """Accept either a dict or a JSON-encoded string and return a dict.

    MCP clients sometimes serialise object-typed parameters as JSON strings
    even when the schema declares ``type: object``. This helper makes tools
    tolerant of both forms.
    """
    import json

    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return {}
        return parsed if isinstance(parsed, dict) else {}
    return {}


class DiffParserSpecsTool(ToolHandler):
    name = "diff_parser_specs"
    description = (
        "Structurally compare two NetSight parser specs — engine, root, "
        "and added/removed/changed fields. Use this when refactoring or "
        "migrating a parser spec — e.g. to see what changed between the "
        "version in git and a freshly scaffolded one, or between the raw "
        "spec under config/vendors/ and the compiled copy under .compiled/. "
        "Text diff misses the semantic structure; this surfaces field-level "
        "changes directly."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "spec_a": {"type": "object"},
            "spec_b": {"type": "object"},
        },
        "required": ["spec_a", "spec_b"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        a = _coerce_dict(kwargs.get("spec_a"))
        b = _coerce_dict(kwargs.get("spec_b"))

        differences: list[str] = []

        for key in ("engine", "root", "operation", "input_format", "output_shape"):
            if a.get(key) != b.get(key):
                differences.append(
                    f"{key}: {a.get(key)!r} -> {b.get(key)!r}"
                )

        fields_a = a.get("fields", {}) or {}
        fields_b = b.get("fields", {}) or {}
        added = set(fields_b) - set(fields_a)
        removed = set(fields_a) - set(fields_b)
        changed: list[str] = []
        for name in sorted(set(fields_a) & set(fields_b)):
            if fields_a[name] != fields_b[name]:
                changed.append(name)

        for name in sorted(added):
            differences.append(f"field added: {name}")
        for name in sorted(removed):
            differences.append(f"field removed: {name}")
        for name in changed:
            differences.append(f"field changed: {name}")

        return {
            "identical": not differences,
            "differences": differences,
            "fields_added": sorted(added),
            "fields_removed": sorted(removed),
            "fields_changed": changed,
        }


def _all_operations() -> list[dict[str, Any]]:
    """Return operations from all compiled vendor configs and installed packs."""
    import tomllib

    from netsight.config_mgmt.store import FileConfigStore

    ops: list[dict[str, Any]] = []
    seen_ops: set[str] = set()

    # Source 1: compiled legacy store
    store = FileConfigStore(PROJECT_ROOT / "config/vendors")
    for vendor in store.list_vendors():
        for model in store.list_models(vendor):
            try:
                resolved = store.get_resolved(vendor, model)
            except FileNotFoundError:
                continue
            for op_name, op_config in (resolved.get("operations") or {}).items():
                ops.append({
                    "name": op_name,
                    "vendor": vendor,
                    "model": model,
                    **op_config,
                })
                seen_ops.add(op_name)

    # Source 2: installed packs
    try:
        from netsight.packs.registry import pack_registry

        for pack_info in pack_registry.list():
            # Prefer the new catalog filename; fall back to legacy name.
            ops_file = pack_info.config_root.joinpath("operations_catalog.toml")
            if not ops_file.is_file():
                ops_file = pack_info.config_root.joinpath("operations.toml")
            if not ops_file.is_file():
                continue
            try:
                raw_ops = tomllib.loads(ops_file.read_text(encoding="utf-8"))
            except Exception:
                continue
            for op_name, op_config in raw_ops.items():
                if not isinstance(op_config, dict) or op_name in seen_ops:
                    continue
                ops.append({
                    "name": op_name,
                    "vendor": pack_info.vendor,
                    "model": pack_info.device_type,
                    **op_config,
                })
                seen_ops.add(op_name)
    except Exception:
        pass

    return ops


class ListParserSpecsTool(ToolHandler):
    name = "list_parser_specs"
    description = (
        "List all NetSight parser specs across every vendor — NOT the same "
        "as listing operations. A parser spec is a YAML file at "
        "config/vendors/<vendor>/parsers/<op>.yaml that transforms a "
        "device's raw response into a structured Python dict/list. Many "
        "operations are allowlisted without a parser spec and return raw "
        "responses; this tool gives you just the parsed ones. Optionally "
        "filter by vendor. The response includes guidance for common "
        "follow-up queries. Pair with trace_operation_pipeline to see how "
        "a spec is wired into an operation and with diff_parser_specs to "
        "compare two specs structurally."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "vendor": {
                "type": "string",
                "description": (
                    "Optional vendor name filter (e.g. 'paloalto'). "
                    "Omit to list specs across every vendor."
                ),
            }
        },
        "required": [],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        # Reuse the resource-layer helpers so the two surfaces stay in sync.
        from netsight.mcp_dev.resources.parsers import (
            ParsersIndexHandler,
            _iter_pack_parser_specs,
            _iter_parser_spec_files,
            _summarize_spec,
        )

        vendor_filter = kwargs.get("vendor")
        if vendor_filter:
            specs = [
                _summarize_spec(p)
                for p in _iter_parser_spec_files()
                if p.parent.parent.name == vendor_filter
            ]
            # Also include pack specs for this vendor
            specs.extend(
                s for s in _iter_pack_parser_specs()
                if s.get("vendor") == vendor_filter
            )
        else:
            # Delegate to the index handler so tool and resource return
            # identical shapes (including _guidance).
            full_response = ParsersIndexHandler().get("netsight://parsers")
            return full_response

        return {
            "parser_specs": specs,
            "count": len(specs),
            "vendor_filter": vendor_filter,
            "_guidance": {
                "next_steps": [
                    f"Read a spec via ReadMcpResourceTool on its 'uri' "
                    f"field (e.g. netsight://vendors/{vendor_filter}/"
                    f"parsers/<op>).",
                    "Drop the vendor filter and call this tool again to "
                    "compare spec coverage across vendors.",
                    "Call netsight://operations to see ALL operations for "
                    "this vendor (including those without specs).",
                ],
            },
        }


class FindOperationsByCategoryTool(ToolHandler):
    name = "find_operations_by_category"
    description = (
        "List all NetSight operations that belong to a given category "
        "(e.g. 'system', 'network', 'logs'). Categories are declared in "
        "each operation's operations_catalog.toml entry. Use this to discover what "
        "operations exist for a workflow like 'device health check' or "
        "'route investigation'. To browse ALL operations with full "
        "metadata, read the netsight://operations resource directly."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "category": {"type": "string"},
        },
        "required": ["category"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        category = kwargs.get("category", "")
        ops = [op for op in _all_operations() if op.get("category") == category]
        return {"category": category, "count": len(ops), "operations": ops}


class FindOperationsByTagTool(ToolHandler):
    name = "find_operations_by_tag"
    description = (
        "List all NetSight operations that include a specific tag in their "
        "metadata. Tags are set via the @operation(tags=[...]) decorator "
        "on plugin client methods. Use this for cross-cutting queries like "
        "'all operations tagged troubleshooting' or 'all operations tagged "
        "snapshot'. See netsight://operations for all operations with full "
        "metadata."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "tag": {"type": "string"},
        },
        "required": ["tag"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        tag = kwargs.get("tag", "")
        matching = [
            op
            for op in _all_operations()
            if tag in (op.get("tags") or [])
        ]
        return {"tag": tag, "count": len(matching), "operations": matching}


class TraceOperationPipelineTool(ToolHandler):
    name = "trace_operation_pipeline"
    description = (
        "Show the full execution pipeline for a NetSight operation: "
        "command → parser spec → engine → root JMESPath → output shape. "
        "Use this as the 'show me how this works' tool whenever you "
        "encounter an operation name — it reveals the XML command the "
        "device will receive, which YAML spec transforms the response, "
        "and what shape Python dict/list the SDK returns. Pair with "
        "netsight://vendors/<vendor>/parsers/<op> to read the full spec."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "operation": {"type": "string"},
        },
        "required": ["operation"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        operation = kwargs.get("operation", "")
        for op in _all_operations():
            if op.get("name") == operation:
                steps = [
                    {
                        "step": "command",
                        "value": op.get("command", ""),
                    },
                    {
                        "step": "parser_spec",
                        "value": op.get("parser_spec", "(none)"),
                    },
                ]
                parser_resolved = op.get("parser_resolved") or {}
                if parser_resolved:
                    steps.append({
                        "step": "engine",
                        "value": parser_resolved.get("engine", "(none)"),
                    })
                    steps.append({
                        "step": "root",
                        "value": parser_resolved.get("root", "(none)"),
                    })
                    steps.append({
                        "step": "output_shape",
                        "value": parser_resolved.get("output_shape", "(none)"),
                    })
                return {
                    "operation": operation,
                    "vendor": op.get("vendor"),
                    "model": op.get("model"),
                    "steps": steps,
                }
        return {"error": f"Operation not found: {operation}"}


class AnalyzeImpactTool(ToolHandler):
    name = "analyze_impact"
    description = (
        "Analyse the potential impact of removing or renaming a Python "
        "symbol in the NetSight codebase: counts usages grouped by "
        "directory. Use this before any refactor (rename/remove/move) to "
        "judge blast radius — a symbol with 30 usages across 5 packages is "
        "a bigger change than one with 2 usages in a single file.\n\n"
        "Defaults to ``scope='all'`` so refactor analysis includes tests, "
        "config files, and top-level markdown references — the set of "
        "things that actually break when you rename. Built on top of "
        "find_usages; pass scope='source' for netsight/ only if you want "
        "to exclude tests. Pass scope='cross_repo' to include sibling repos "
        "(netsight-ops, netsight-packs-*) in the blast-radius estimate — "
        "sibling hits carry a ``\"{repo_name}:\"`` prefix in file keys."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "symbol": {"type": "string"},
            "scope": {
                "type": "string",
                "enum": ["source", "tests", "all", "cross_repo"],
                "description": (
                    "Search scope: 'all' (default for refactor analysis), "
                    "'source' = netsight/ only, 'tests' = UNITTEST/ only, "
                    "'cross_repo' = all repos including siblings."
                ),
            },
        },
        "required": ["symbol"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        symbol = kwargs.get("symbol", "")
        # Default to 'all' for refactor impact — the whole point is to see
        # every reference, including tests and config that find_usages
        # defaults to excluding.
        scope = kwargs.get("scope", "all")
        if scope not in _VALID_SCOPES:
            scope = "all"
        usages = FindUsagesTool().execute(symbol=symbol, scope=scope)["usages"]
        by_directory: dict[str, int] = {}
        for u in usages:
            directory = str(Path(u["file"]).parent)
            by_directory[directory] = by_directory.get(directory, 0) + 1
        return {
            "symbol": symbol,
            "scope": scope,
            "total_usages": len(usages),
            "affected_files": sorted({u["file"] for u in usages}),
            "usages_by_directory": by_directory,
        }


_EXPLANATION_HINTS: list[tuple[str, str]] = [
    (
        r"engine.*required|required.*engine",
        "The parser spec must declare `engine:` at the top level. Use `engine: jmespath` for XML-based vendors or `engine: passthrough` for vendors that already return structured data.",
    ),
    (
        r"unknown engine|engine.*not.*found|engine.*not registered",
        "The named engine is not registered. Check `netsight.parsers.registry.parser_registry` for available engines, or add a new engine and register it.",
    ),
    (
        r"missing.*description|description.*missing",
        "Add a `description` field — it improves discoverability and appears in AI tool definitions.",
    ),
    (
        r"type.*missing|missing.*type",
        "Each field must declare its `type` (e.g. `type: str`, `type: int`, `type: ip`). See `netsight://registries/types` for available types.",
    ),
    (
        r"invalid.*yaml|yaml.*error",
        "YAML syntax is invalid. Most commonly: inconsistent indentation, unescaped special characters, or a missing colon.",
    ),
    (
        r"invalid.*toml|toml.*error",
        "TOML syntax is invalid. Check quoted strings, equals signs, and table headers in square brackets.",
    ),
]


class ExplainValidationErrorTool(ToolHandler):
    name = "explain_validation_error"
    description = (
        "Given a NetSight validation error string (from "
        "validate_parser_spec, validate_operations_toml, compile_dry_run, "
        "or the netsight config compile CLI), return human-readable "
        "guidance on what to fix. Use this whenever you hit a validation "
        "failure and the raw message isn't obvious — it maps common error "
        "patterns to concrete fixes. Call this before guessing; the "
        "patterns it recognises are the ones users actually hit."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "error_text": {"type": "string"},
        },
        "required": ["error_text"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        error_text = kwargs.get("error_text", "")
        for pattern, explanation in _EXPLANATION_HINTS:
            if re.search(pattern, error_text, flags=re.IGNORECASE):
                return {
                    "error_text": error_text,
                    "explanation": explanation,
                    "matched_pattern": pattern,
                }
        return {
            "error_text": error_text,
            "explanation": (
                "No specific guidance for this error. Check the parser spec format "
                "in `docs/guides/developer-guide.md`, and try `validate_parser_spec` "
                "to pinpoint the issue."
            ),
            "matched_pattern": None,
        }


def register_all() -> None:
    """Register inspection tools."""
    tool_registry.register(FindUsagesTool())
    tool_registry.register(FindDefinitionsTool())
    tool_registry.register(ExtractXmlStructureTool())
    tool_registry.register(DiffParserSpecsTool())
    tool_registry.register(ListParserSpecsTool())
    tool_registry.register(FindOperationsByCategoryTool())
    tool_registry.register(FindOperationsByTagTool())
    tool_registry.register(TraceOperationPipelineTool())
    tool_registry.register(AnalyzeImpactTool())
    tool_registry.register(ExplainValidationErrorTool())
