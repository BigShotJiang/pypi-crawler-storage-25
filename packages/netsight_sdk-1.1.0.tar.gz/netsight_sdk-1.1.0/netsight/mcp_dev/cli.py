"""CLI entry point for the MCP dev server."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def run() -> int:
    """Start the MCP dev server over stdio.

    Fails with a friendly install hint if the ``mcp-dev`` extras are not
    installed. The only third-party dependency is ``watchdog``, which
    powers the filesystem watcher at :mod:`netsight.mcp_dev.cache`; the
    stdio JSON-RPC transport is implemented internally at
    :mod:`netsight.mcp_dev.transport` and does not require the
    third-party ``mcp`` package.
    """
    try:
        from netsight.mcp_dev.server import NetSightDevMCPServer
        from netsight.mcp_dev.transport import run_stdio
    except ImportError as exc:
        print("Error: the netsight dev MCP server requires extras not installed.")
        print(f"Missing: {exc.name}")
        print()
        print("Install with:")
        print("    pip install 'netsight[mcp-dev]'")
        return 1

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    server = NetSightDevMCPServer()
    run_stdio(server)
    return 0
