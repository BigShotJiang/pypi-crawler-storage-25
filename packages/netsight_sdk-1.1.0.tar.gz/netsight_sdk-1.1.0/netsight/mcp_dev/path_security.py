"""Path security for MCP source file access.

Allowlist + blocklist with deny-wins precedence. Path traversal protection
via resolution to absolute paths and project-root containment check.

After the SDK/ops split (v1.0.0), NetSight spans three repos. This module
supports **multi-root** operation: the SDK is the primary root, and sibling
repos (netsight-ops, netsight-packs-*) on disk are detected at import time
and made available to tools that request ``scope="cross_repo"`` and to the
``netsight://source/@{repo_name}/{path}`` resource URI scheme.

Glob patterns support ``**`` to match zero or more path components, consistent
with gitignore / PEP 471 semantics (unlike ``fnmatch`` which treats ``**`` as a
single-segment wildcard).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Primary root — the netsight-sdk repo
# ---------------------------------------------------------------------------

# Project root — two levels up from this file (netsight/mcp_dev/path_security.py)
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

# ---------------------------------------------------------------------------
# Sibling repo discovery
# ---------------------------------------------------------------------------

# Static registry of known sibling repos. The key is the canonical repo
# name used in URIs (``netsight://source/@{key}/...``). The value is a
# ``(directory_name_on_disk, allow_patterns)`` tuple.
SIBLING_REPO_SPECS: dict[str, tuple[str, list[str]]] = {
    "netsight-ops": (
        "netsight-ops",
        [
            "netsight_ops/**/*.py",
            "tests/**/*.py",
            "pyproject.toml",
            "README.md",
            "CHANGELOG.md",
            "CLAUDE.md",
            "CONTRIBUTING.md",
            "SEMVER.md",
        ],
    ),
    "netsight-packs-paloalto": (
        "netsight-packs-paloalto",
        [
            "packs/**/*.py",
            "packs/**/*.yaml",
            "packs/**/*.toml",
            "packs/**/tests/**/*.py",
            "README.md",
        ],
    ),
}


def _discover_sibling_roots() -> dict[str, Path]:
    """Probe the filesystem for known sibling repos next to PROJECT_ROOT.

    A sibling is accepted only if its directory AND a ``.git`` subdirectory
    exist — this prevents adopting a leftover archive directory that happens
    to have the right name.

    Called once at module import time. If a sibling is cloned after the MCP
    server starts, it won't be visible until the server restarts.
    """
    parent = PROJECT_ROOT.parent
    found: dict[str, Path] = {}
    for repo_name, (dir_name, _patterns) in SIBLING_REPO_SPECS.items():
        candidate = parent / dir_name
        if candidate.is_dir() and (candidate / ".git").exists():
            found[repo_name] = candidate
            logger.debug("Sibling repo detected: %s at %s", repo_name, candidate)
    return found


SIBLING_ROOTS: dict[str, Path] = _discover_sibling_roots()

ALL_ROOTS: list[tuple[str, Path]] = [("netsight-sdk", PROJECT_ROOT)] + [
    (name, path) for name, path in SIBLING_ROOTS.items()
]


SOURCE_ALLOW_PATTERNS: list[str] = [
    "netsight/**/*.py",
    "netsight/py.typed",
    "config/vendors/**/*.toml",
    "config/vendors/**/*.yaml",
    "config/vendors/**/*.yml",
    "config/devices.yaml",
    "examples/**/*.py",
    "examples/**/*.md",
    "UNITTEST/**/*.py",
    "UNITTEST/fixtures/**/*.xml",
    "UNITTEST/fixtures/**/*.json",
    "TOOLS/**/*.sh",
    "TOOLS/**/*.py",
    "docs/**/*.md",
    "pyproject.toml",
    "CHANGELOG.md",
    "CLAUDE.md",
    "README.md",
]


SOURCE_BLOCK_PATTERNS: list[str] = [
    "**/.env*",
    ".env*",
    "**/.git/**",
    ".git/**",
    "**/.venv/**",
    ".venv/**",
    "**/venv/**",
    "venv/**",
    "**/storage/**",
    "storage/**",
    "**/__pycache__/**",
    "**/.pytest_cache/**",
    "**/.mypy_cache/**",
    "**/.ruff_cache/**",
    "**/*.db",
    "**/*.sqlite*",
    "**/*secret*",
    "*secret*",
    "**/*credential*",
    "*credential*",
    "**/*password*",
    "**/*.pem",
    "**/*.key",
    "**/.compiled/**",
    "**/.idea/**",
    "**/.vscode/**",
    # Internal AI planning artifacts — not user documentation, not for MCP exposure
    "docs/superpowers/**",
    "**/docs/superpowers/**",
]


def _glob_to_regex(pattern: str) -> re.Pattern[str]:
    """Convert a glob pattern with ``**`` support to a compiled regex.

    Semantics:
    - ``*``  — matches any sequence of characters except ``/``
    - ``?``  — matches any single character except ``/``
    - ``**`` — matches zero or more path components (including the empty string)
    - ``**/`` — zero or more leading directories followed by ``/``

    This is intentionally stricter than ``fnmatch`` which does not correctly
    handle ``**`` as zero-or-more path segments.
    """
    i = 0
    result: list[str] = []
    n = len(pattern)
    while i < n:
        c = pattern[i]
        if c == "*":
            if i + 1 < n and pattern[i + 1] == "*":
                # Consume both stars
                i += 2
                if i < n and pattern[i] == "/":
                    # **/ → zero or more directory components
                    i += 1
                    result.append("(?:.*/)?")
                else:
                    # ** at end of pattern → matches everything
                    result.append(".*")
            else:
                # Single * → matches anything except path separator
                result.append("[^/]*")
                i += 1
        elif c == "?":
            result.append("[^/]")
            i += 1
        else:
            result.append(re.escape(c))
            i += 1
    return re.compile("^" + "".join(result) + "$")


# Pre-compile all patterns for performance
_COMPILED_ALLOW: list[re.Pattern[str]] = [
    _glob_to_regex(p) for p in SOURCE_ALLOW_PATTERNS
]
_COMPILED_BLOCK: list[re.Pattern[str]] = [
    _glob_to_regex(p) for p in SOURCE_BLOCK_PATTERNS
]

# Sibling repo allow patterns (block patterns are shared — .env, .git,
# __pycache__, secrets etc. are equally dangerous in sibling repos).
_SIBLING_COMPILED_ALLOW: dict[str, list[re.Pattern[str]]] = {
    repo_name: [_glob_to_regex(p) for p in patterns]
    for repo_name, (_dir, patterns) in SIBLING_REPO_SPECS.items()
}


def is_path_allowed_for_root(
    path: str,
    root: Path,
    repo_name: str = "netsight-sdk",
) -> bool:
    """Check if a relative path is allowed under an arbitrary root.

    This is the generalized form of :func:`is_path_allowed` that works
    for both the primary SDK root and sibling repos. The *repo_name*
    selects the correct allow-pattern list.

    Parameters
    ----------
    path:
        Relative path from *root* to check (POSIX or native).
    root:
        The repo root to anchor the containment check against.
    repo_name:
        Canonical name of the repo; selects the right allow patterns.
        ``"netsight-sdk"`` uses the primary ``SOURCE_ALLOW_PATTERNS``;
        anything else looks up ``_SIBLING_COMPILED_ALLOW[repo_name]``.
    """
    norm = Path(path).as_posix()

    # Path traversal guard — reject anything that resolves outside root
    try:
        abs_path = (root / norm).resolve()
        abs_path.relative_to(root)
    except (ValueError, OSError):
        return False

    # Blocklist takes precedence — shared across all roots
    for rx in _COMPILED_BLOCK:
        if rx.match(norm):
            return False

    # Must match at least one allow pattern from the correct set
    if repo_name == "netsight-sdk":
        compiled_allow = _COMPILED_ALLOW
    else:
        compiled_allow = _SIBLING_COMPILED_ALLOW.get(repo_name, [])

    for rx in compiled_allow:
        if rx.match(norm):
            return True

    return False


def is_path_allowed(path: str) -> bool:
    """Check if a source path can be served via MCP (SDK root only).

    Thin wrapper around :func:`is_path_allowed_for_root` anchored to
    ``PROJECT_ROOT``. All existing callers keep working unchanged.

    Parameters
    ----------
    path:
        Relative path (from SDK project root) to check.

    Returns
    -------
    bool
        ``True`` if the path passes both the blocklist and allowlist.
    """
    return is_path_allowed_for_root(path, PROJECT_ROOT, "netsight-sdk")
