"""NetSight Dev MCP Server — read-only codebase knowledge for AI development."""
