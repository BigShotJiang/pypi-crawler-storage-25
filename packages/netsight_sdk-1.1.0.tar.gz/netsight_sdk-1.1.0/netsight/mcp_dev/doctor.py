"""Dev-environment verification checks for ``netsight doctor``.

This module powers the ``netsight doctor`` subcommand. Its purpose is to
give a fresh contributor (or a CI bootstrap script) a single command that
answers "is my environment wired up to run the NetSight dev MCP server?".

Each check is a small pure function returning ``(passed, message)`` so
the checks are independently unit-testable with ``tmp_path`` fixtures.
``run_checks(root)`` aggregates them into a list of
``(name, passed, message)`` tuples for the CLI layer to render.

The module is deliberately scoped under ``netsight.mcp_dev`` because
every check exists to validate the dev MCP bootstrap flow (venv,
``netsight`` importable from that venv, ``.mcp.json`` pointing at the
``dev-mcp`` subcommand, the server constructing cleanly, the TOOLS
scripts the CI gate relies on). If the check set grows beyond "dev
MCP bootstrap" it should move up to ``netsight.doctor``.
"""

from __future__ import annotations

import importlib.util
import json
import logging
import sys
from pathlib import Path

from netsight.packs.registry import pack_registry

logger = logging.getLogger(__name__)

_MIN_PYTHON: tuple[int, int] = (3, 14)
_EXPECTED_TOOLS_SCRIPTS: tuple[str, ...] = (
    "TOOLS/full_test_cycle.sh",
    "TOOLS/security_check.sh",
)


def check_python_version() -> tuple[bool, str]:
    """Verify the active interpreter meets NetSight's minimum Python version.

    Returns
    -------
    tuple[bool, str]
        ``(True, "<major>.<minor>.<micro>")`` when the interpreter is at
        least :data:`_MIN_PYTHON`, otherwise ``(False, <explanation>)``.
    """
    cur = sys.version_info
    if (cur.major, cur.minor) < _MIN_PYTHON:
        return (
            False,
            f"{cur.major}.{cur.minor}.{cur.micro} — need "
            f">= {_MIN_PYTHON[0]}.{_MIN_PYTHON[1]} (see requires-python in pyproject.toml)",
        )
    return True, f"{cur.major}.{cur.minor}.{cur.micro}"


def check_netsight_importable() -> tuple[bool, str]:
    """Verify the ``netsight`` package is importable from the active interpreter.

    This catches the "forgot to run ``pip install -e .``" case — the most
    common bootstrap failure for new contributors.

    Returns
    -------
    tuple[bool, str]
        ``(True, <interpreter path>)`` on success, otherwise
        ``(False, <ImportError detail>)``.
    """
    try:
        spec = importlib.util.find_spec("netsight")
    except (ImportError, ValueError) as exc:
        return False, f"find_spec failed: {exc} (run `pip install -e .`)"
    if spec is None:
        return False, "netsight package not found (run `pip install -e .`)"
    return True, f"importable from {sys.executable}"


def check_mcp_json(root: Path) -> tuple[bool, str]:
    """Verify ``.mcp.json`` exists at ``root`` and points at ``netsight dev-mcp``.

    Parameters
    ----------
    root
        Project root directory (normally ``Path.cwd()`` when invoked from
        the CLI; tests pass a ``tmp_path`` fixture).

    Returns
    -------
    tuple[bool, str]
        ``(True, <summary>)`` when the file is present, parses as JSON,
        has an ``mcpServers.netsight-dev`` entry, and that entry invokes
        the ``dev-mcp`` subcommand. Otherwise ``(False, <explanation>)``.
    """
    path = root / ".mcp.json"
    if not path.exists():
        return False, f"missing at {path} (expected project-scoped MCP config)"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return False, f"invalid JSON in {path.name}: {exc}"
    servers = data.get("mcpServers", {}) if isinstance(data, dict) else {}
    if "netsight-dev" not in servers:
        return False, f"{path.name} has no 'netsight-dev' entry under mcpServers"
    entry = servers["netsight-dev"]
    args = entry.get("args", []) if isinstance(entry, dict) else []
    if "dev-mcp" not in args:
        return (
            False,
            f"{path.name} 'netsight-dev' entry does not invoke the 'dev-mcp' subcommand",
        )
    return True, f"{path.name} points at netsight-dev via dev-mcp"


def check_dev_mcp_server_constructs() -> tuple[bool, str]:
    """Verify :class:`NetSightDevMCPServer` instantiates without error.

    A successful construction means every ``ResourceHandler`` and
    ``ToolHandler`` registered in ``_load_all_handlers`` loaded cleanly
    — a broken handler module would raise here rather than at stdio
    handshake time.

    When the ``mcp-dev`` extras are not installed (``watchdog`` missing),
    server construction fails with an :class:`ImportError` and the check
    reports "skipped" and returns ``True`` — missing extras is a valid
    state, not a failure. Matches the degradation pattern used by
    ``check_config_discovery`` and ``check_allowlist_discovery``.

    The check does NOT probe for the ``mcp`` package specifically because
    neither the runtime MCP server (``netsight.mcp``) nor the dev MCP
    server (``netsight.mcp_dev``) imports the third-party ``mcp``
    package — both use their own stdio JSON-RPC transports at
    ``netsight.mcp.transport`` and ``netsight.mcp_dev.transport``. The
    only real optional dependency is ``watchdog`` for the filesystem
    watcher used by ``netsight.mcp_dev.cache``.

    Returns
    -------
    tuple[bool, str]
        ``(True, <summary>)`` on clean construction or when extras are
        absent, otherwise ``(False, <short error>)``.
    """
    try:
        from netsight.mcp_dev.server import NetSightDevMCPServer

        NetSightDevMCPServer()
    except ImportError as exc:
        return (
            True,
            f"skipped — missing {exc.name!r}; "
            f"install with pip install 'netsight-sdk[dev]'",
        )
    except RuntimeError as exc:
        # FileSystemWatcher raises RuntimeError when watchdog is absent
        # (lazy-import pattern introduced during the SDK/ops split).
        if "watchdog" in str(exc).lower():
            return (
                True,
                "skipped — watchdog not installed; "
                "install with pip install 'netsight-sdk[dev]'",
            )
        return False, f"NetSightDevMCPServer() raised RuntimeError: {exc}"
    except Exception as exc:  # noqa: BLE001  — top-level doctor aggregation
        return False, f"NetSightDevMCPServer() raised {type(exc).__name__}: {exc}"
    return True, "NetSightDevMCPServer() constructs cleanly"


def check_tools_scripts(root: Path) -> tuple[bool, str]:
    """Verify the shell scripts under ``TOOLS/`` that the CI gate expects are present.

    Parameters
    ----------
    root
        Project root directory.

    Returns
    -------
    tuple[bool, str]
        ``(True, <count summary>)`` when every path in
        :data:`_EXPECTED_TOOLS_SCRIPTS` exists, otherwise
        ``(False, <missing list>)``.
    """
    missing = [p for p in _EXPECTED_TOOLS_SCRIPTS if not (root / p).exists()]
    if missing:
        return False, f"missing: {', '.join(missing)}"
    return True, f"{len(_EXPECTED_TOOLS_SCRIPTS)} script(s) present under TOOLS/"


def check_pack_discovery() -> tuple[bool, str]:
    """Report the number of installed packs visible to the pack registry.

    Calls :meth:`~netsight.packs.registry.PackRegistry.ensure_loaded` on the
    global singleton (idempotent — safe to call repeatedly) and then counts
    the registered packs.  Zero packs is a valid state for an SDK-only
    install, so this check **always returns True** — it exists to make pack
    count visible in ``netsight doctor`` output, not to fail on zero.

    Returns
    -------
    tuple[bool, str]
        Always ``(True, <summary>)`` where *summary* is either
        ``"0 pack(s) loaded: none"`` or
        ``"N pack(s) loaded: name1, name2, ..."`` with names in
        sorted order.
    """
    pack_registry.ensure_loaded()
    packs = pack_registry.list()
    count = len(packs)
    if count == 0:
        names_str = "none"
    else:
        names_str = ", ".join(sorted(p.name for p in packs))
    return True, f"{count} pack(s) loaded: {names_str}"


def check_pack_load_errors() -> tuple[bool, str]:
    """Report any packs that failed to register during discovery.

    Reads the load-error mapping recorded by the pack loader via
    :meth:`~netsight.packs.registry.PackRegistry.record_load_error`.
    A broken pack is surfaced without blocking other checks — this is the
    only pack-related check that can return ``False``.

    Returns
    -------
    tuple[bool, str]
        ``(True, "no pack load errors")`` when no errors were recorded.
        ``(False, "<N> pack(s) failed to register: <details>")`` otherwise,
        where *details* lists each failing pack name and its exception type.
    """
    errors = pack_registry.load_errors()
    if not errors:
        return True, "no pack load errors"
    n = len(errors)
    details = ", ".join(
        f"{name} ({type(exc).__name__})" for name, exc in sorted(errors.items())
    )
    return False, f"{n} pack(s) failed to register: {details}"


def check_config_discovery() -> tuple[bool, str]:
    """Report which location the user's devices.yaml resolves from.

    Always returns True — a missing devices.yaml is a valid state for
    an SDK-only install or for fresh setups. Reports the effective
    path and a hint pointing at ``netsight init`` when no config file
    is found.

    Returns
    -------
    tuple[bool, str]
        Always ``(True, <message>)`` where *message* is either the
        resolved path or a hint to run ``netsight init``.
    """
    from netsight.config_mgmt.user_config import resolve_config_file

    path = resolve_config_file("devices.yaml")
    if path is None:
        return True, "no devices.yaml found — run `netsight init` to create a template"
    return True, f"devices.yaml found at {path}"


def check_allowlist_discovery() -> tuple[bool, str]:
    """Report how many packs have an allowlist file and total enabled ops.

    Iterates every installed pack from the pack registry. For each pack,
    loads the allowlist file if it exists and counts enabled operations.
    This is a visibility check only — it always returns ``True`` so that
    zero-allowlist state is clearly reported without failing ``doctor``.

    Returns
    -------
    tuple[bool, str]
        Always ``(True, <summary>)``. Summary is either the count summary
        or a hint to run ``netsight allowlist enable`` when no ops are enabled.
    """
    from netsight.packs.allowlist import load_allowlist

    pack_registry.ensure_loaded()
    packs = pack_registry.list()

    if not packs:
        return True, "no packs installed — allowlist check skipped"

    packs_with_allowlist = 0
    total_enabled = 0
    for pack_info in packs:
        user = load_allowlist(pack_info.name)
        if user.enabled:
            packs_with_allowlist += 1
            total_enabled += len(user.enabled)

    if total_enabled == 0:
        return (
            True,
            "no allowlists configured — run `netsight allowlist enable <pack> <op>` to opt in",
        )
    return (
        True,
        f"{packs_with_allowlist} pack(s) with allowlist, {total_enabled} op(s) total",
    )


def check_allowlist_drift() -> tuple[bool, str]:
    """Detect drift between user allowlist files and installed pack catalogs.

    For each installed pack with an allowlist file, compares the user's
    enabled operations against the pack's current catalog. Operations in
    the allowlist that no longer exist in the catalog are reported as drift.

    Returns
    -------
    tuple[bool, str]
        ``(True, "no drift detected")`` when all enabled ops exist in
        their respective catalogs, or
        ``(False, "<N> pack(s) with drift: <details>")`` when orphaned
        enabled ops are found.
    """
    import tomllib

    from netsight.packs.allowlist import load_allowlist

    pack_registry.ensure_loaded()
    packs = pack_registry.list()

    drifted: list[str] = []

    for pack_info in packs:
        user = load_allowlist(pack_info.name)
        if not user.enabled:
            continue

        # Load the pack catalog.
        ops_file = pack_info.config_root.joinpath("operations_catalog.toml")
        if not ops_file.is_file():
            ops_file = pack_info.config_root.joinpath("operations.toml")
        if not ops_file.is_file():
            # No catalog on disk means all enabled ops are orphaned.
            drifted.append(
                f"{pack_info.name}: catalog not found; "
                f"{len(user.enabled)} orphaned op(s): {sorted(user.enabled)}"
            )
            continue

        try:
            raw = tomllib.loads(ops_file.read_text(encoding="utf-8"))
            catalog_ops = {k for k, v in raw.items() if isinstance(v, dict)}
        except Exception as exc:  # noqa: BLE001
            drifted.append(f"{pack_info.name}: could not read catalog: {exc}")
            continue

        orphaned = user.enabled - catalog_ops
        if orphaned:
            drifted.append(
                f"{pack_info.name}: {len(orphaned)} orphaned op(s) in allowlist "
                f"(not in catalog): {sorted(orphaned)}"
            )

    if drifted:
        details = "; ".join(drifted)
        return False, f"{len(drifted)} pack(s) with drift: {details}"
    return True, "no drift detected"


def check_credential_providers() -> tuple[bool, str]:
    """Report the health of all registered credential providers.

    Calls :meth:`~netsight.credentials.registry.CredentialProviderRegistry.ensure_loaded`
    on the global singleton to register built-in providers and discover any
    third-party providers installed via the ``netsight.credential_providers``
    entry-point group.

    For each registered provider, :meth:`~netsight.credentials.provider.CredentialProvider.health_check`
    is called.  If any provider reports ``status != "ok"``, the check fails
    with a message identifying the unhealthy provider and its error detail.

    Returns
    -------
    tuple[bool, str]
        ``(True, "N provider(s): name1, name2, ...")`` when all providers are
        healthy, or ``(False, "provider <name> is unhealthy: <detail>")`` for
        the first unhealthy provider encountered.
    """
    from netsight.credentials.registry import credential_provider_registry

    credential_provider_registry.ensure_loaded()
    providers = credential_provider_registry.list()

    for info in providers:
        try:
            result = info.provider.health_check()
        except Exception as exc:  # noqa: BLE001  — doctor aggregation
            return (
                False,
                f"provider '{info.name}' raised during health_check: "
                f"{type(exc).__name__}: {exc}",
            )
        if result.get("status") != "ok":
            detail = result.get("detail", "no detail provided")
            return False, f"provider '{info.name}' is unhealthy: {detail}"

    count = len(providers)
    names_str = ", ".join(sorted(p.name for p in providers)) if providers else "none"
    return True, f"{count} provider(s): {names_str}"


def check_compiled_config() -> tuple[bool, str]:
    """Check whether a compiled config exists for each configured device.

    Iterates every device in the user's ``devices.yaml`` (if it exists)
    and verifies that at least one of the two compiled-output paths
    contains a ``resolved.json``:

    1. **Legacy path** — ``<config_dir>/.compiled/<vendor>/<model>/resolved.json``
       (the project-local compile output written by the legacy
       ``FileConfigStore``).
    2. **Pack-cache path** — ``~/.cache/netsight/compiled/<pack>/<model>/resolved.json``
       (the user-cache output written by the pack-mode compiler).

    If no ``devices.yaml`` exists, the check passes silently — a fresh
    install with no config is a valid state.

    Returns
    -------
    tuple[bool, str]
        ``(True, "N device(s) have compiled configs")`` when every device
        has at least one compiled output, or
        ``(False, "Device 'X' has no compiled config — run netsight config compile")``
        for the first device found without one.  When no ``devices.yaml``
        exists, returns ``(True, "no devices configured — compile check skipped")``.
    """
    import json

    from netsight.config_mgmt.user_config import resolve_cache_dir, resolve_config_file

    devices_path = resolve_config_file("devices.yaml")
    if devices_path is None:
        return True, "no devices configured — compile check skipped"

    try:
        import yaml  # type: ignore[import-untyped]

        raw = yaml.safe_load(devices_path.read_text(encoding="utf-8"))
        devices = raw.get("devices", []) if isinstance(raw, dict) else []
    except Exception as exc:  # noqa: BLE001
        return True, f"could not parse devices.yaml — compile check skipped: {exc}"

    if not devices:
        return True, "no devices configured — compile check skipped"

    # Derive the config directory from the devices.yaml location so the
    # legacy-path check uses the same base directory that LocalBackend does.
    config_dir = devices_path.parent
    cache_dir = resolve_cache_dir()

    checked = 0
    for device in devices:
        if not isinstance(device, dict):
            continue
        name = device.get("name", "<unnamed>")
        api_type = device.get("api_type", "")
        model = device.get("model") or "default"

        # Derive vendor from api_type (e.g. "paloalto-firewall-xml" → "paloalto").
        vendor = api_type.split("-")[0] if api_type else "unknown"

        found = False

        # Try 1: legacy project-local compiled output.
        legacy_path = config_dir / ".compiled" / vendor / model / "resolved.json"
        if legacy_path.is_file():
            try:
                json.loads(legacy_path.read_text(encoding="utf-8"))
                found = True
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Compiled config at %s exists but is corrupt or invalid JSON: %s",
                    legacy_path, exc,
                )

        # Try 2: pack-cache compiled output.
        if not found and api_type:
            for model_dir in ([model] if model != "default" else []) + ["default"]:
                pack_path = cache_dir / "compiled" / api_type / model_dir / "resolved.json"
                if pack_path.is_file():
                    try:
                        json.loads(pack_path.read_text(encoding="utf-8"))
                        found = True
                        break
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "Compiled config at %s exists but is corrupt or invalid JSON: %s",
                            pack_path, exc,
                        )

        if not found:
            return (
                False,
                f"Device '{name}' has no compiled config — run `netsight config compile`",
            )

        checked += 1

    return True, f"{checked} device(s) have compiled configs"


def check_standards_compliance() -> tuple[bool, str]:
    """Run all error-severity standards and report compliance.

    Runs :meth:`~netsight.standards.StandardsRegistry.check_all` on the
    global standards registry. Only error-severity standards that produce
    findings (and are not skipped or excluded as known-false-positives) are
    considered failures.

    Standards in :data:`_STANDARDS_KNOWN_FALSE_POSITIVES` are excluded from
    the failure count and noted in the message — they remain tracked but do
    not block the doctor check until their engine exclusion lists are refined.

    Returns
    -------
    tuple[bool, str]
        ``(True, "N standards: all pass")`` when no qualifying error-severity
        standard has findings, or
        ``(False, "N standard(s) failed: name1, name2, ...")``.
    """
    # Standards with known false positives — tracked but not hard failures yet.
    _known_false_positives: frozenset[str] = frozenset(
        {
            "no-silent-failures",
            "module-level-logger",
            "no-legacy-paths",
        }
    )

    try:
        from netsight.standards import standards_registry
    except Exception as exc:  # noqa: BLE001
        return True, f"standards check skipped — import error: {exc}"

    try:
        results = standards_registry.check_all()
    except Exception as exc:  # noqa: BLE001
        return True, f"standards check skipped — registry error: {exc}"

    failed_names: list[str] = []
    for r in results:
        if r.skipped or r.passed:
            continue
        if r.standard in _known_false_positives:
            continue
        try:
            s = standards_registry.get_standard(name=r.standard)
            if s.severity == "error":
                failed_names.append(r.standard)
        except KeyError:
            failed_names.append(r.standard)

    total = len(results)
    if failed_names:
        return (
            False,
            f"{len(failed_names)} error standard(s) failed: {', '.join(sorted(failed_names))}",
        )
    return True, f"{total} standard(s): all pass"


def run_checks(root: Path) -> list[tuple[str, bool, str]]:
    """Run every dev-environment check and return a list of results.

    Parameters
    ----------
    root
        Project root directory to resolve path-based checks against.

    Returns
    -------
    list[tuple[str, bool, str]]
        One ``(check_name, passed, message)`` tuple per check, in a stable
        order suitable for direct rendering by the CLI layer.
    """
    return [
        ("python version", *check_python_version()),
        ("netsight importable", *check_netsight_importable()),
        (".mcp.json", *check_mcp_json(root)),
        ("dev MCP server", *check_dev_mcp_server_constructs()),
        ("TOOLS scripts", *check_tools_scripts(root)),
        ("pack discovery", *check_pack_discovery()),
        ("pack load errors", *check_pack_load_errors()),
        ("config discovery", *check_config_discovery()),
        ("compiled config", *check_compiled_config()),
        ("allowlist discovery", *check_allowlist_discovery()),
        ("allowlist drift", *check_allowlist_drift()),
        ("credential providers", *check_credential_providers()),
        ("standards compliance", *check_standards_compliance()),
    ]
