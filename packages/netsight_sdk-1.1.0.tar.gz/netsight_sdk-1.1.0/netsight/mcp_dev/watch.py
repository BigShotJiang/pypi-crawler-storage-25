"""Filesystem watcher for live cache invalidation.

The recipe-drift watcher is the **only** part of ``netsight.mcp_dev``
that needs the ``watchdog`` third-party package. Every other module
under ``mcp_dev`` is pure stdlib and can be imported on a lean
``pip install netsight-sdk`` (no ``[dev]`` extra).

To preserve that property, ``watchdog`` is imported lazily — inside
:meth:`FileSystemWatcher.__init__` rather than at module level — so
that:

* ``from netsight.mcp_dev.watch import FileSystemWatcher`` works on
  a lean install (the import succeeds; the class object exists).
* Constructing a ``FileSystemWatcher`` is what actually requires
  ``watchdog`` to be installed; if it isn't, we raise a clear
  :class:`RuntimeError` pointing the user at
  ``pip install 'netsight-sdk[dev]'``.

Other ``mcp_dev`` resources/tools that have nothing to do with file
watching are unaffected and remain importable on a lean install.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


_DEFAULT_WATCH_PATHS = [
    "netsight",
    "config/vendors",
    "examples",
    "docs",
    "UNITTEST/fixtures",
]


def _load_watchdog() -> tuple[Any, Any]:
    """Lazy-load ``watchdog.observers.Observer`` and ``FileSystemEventHandler``.

    Returns ``(Observer, FileSystemEventHandler)``. Raises
    :class:`RuntimeError` with an actionable message if ``watchdog``
    is not installed (i.e. the user installed ``netsight-sdk`` without
    the ``[dev]`` extra and is now trying to start the file watcher).

    The return type is annotated as ``tuple[Any, Any]`` because
    ``Observer`` is a factory function in modern watchdog (not a
    class), and Pyright complains if we promise ``type``.
    """
    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer
    except ImportError as exc:
        raise RuntimeError(
            "The dev MCP server's filesystem watcher requires the "
            "`watchdog` package. Install it with:\n"
            "    pip install 'netsight-sdk[dev]'"
        ) from exc
    return Observer, FileSystemEventHandler


class FileSystemWatcher:
    """Watches paths and invalidates server caches on changes.

    Args:
        server: The MCP server instance with a ``_cache`` attribute.
        watch_paths: List of paths to watch. Defaults to NetSight standard paths.

    Raises:
        RuntimeError: If ``watchdog`` is not installed. Importing this
            class is fine on a lean install; constructing it is what
            requires the optional dependency.
    """

    def __init__(
        self,
        server: Any,
        watch_paths: list[str] | None = None,
    ) -> None:
        observer_factory, handler_base_cls = _load_watchdog()
        watcher = self  # closure capture for the inner handler class

        # Build the per-instance handler subclass on demand so the
        # ``FileSystemEventHandler`` base class is only referenced
        # AFTER the watchdog import has succeeded.
        class _Handler(handler_base_cls):  # type: ignore[misc, valid-type]
            def on_any_event(self, event: Any) -> None:
                if event.is_directory:
                    return
                watcher._on_change(event.src_path)

        self._server = server
        self._paths = watch_paths or _DEFAULT_WATCH_PATHS
        self._observer = observer_factory()
        self._handler = _Handler()
        self._started = False

    def start(self) -> None:
        """Start watching the filesystem."""
        if self._started:
            return
        for path in self._paths:
            if Path(path).exists():
                self._observer.schedule(self._handler, path, recursive=True)
                logger.info("Watching path: %s", path)
        self._observer.start()
        self._started = True

    def stop(self) -> None:
        """Stop the watcher cleanly."""
        if not self._started:
            return
        self._observer.stop()
        self._observer.join(timeout=2)
        self._started = False

    def _on_change(self, src_path: str) -> None:
        """Dispatch a file change to the appropriate cache invalidation."""
        logger.debug("File change detected: %s", src_path)

        # Normalize path for prefix matching
        try:
            rel = Path(src_path).as_posix()
        except Exception:
            return

        cache = getattr(self._server, "_cache", None)
        if cache is None:
            return

        # Invalidation rules
        if "config/vendors/" in rel:
            # Extract vendor name
            try:
                idx = rel.index("config/vendors/") + len("config/vendors/")
                remainder = rel[idx:]
                vendor = remainder.split("/")[0]
                if vendor and vendor not in (".compiled", "global"):
                    cache.invalidate_prefix(f"vendors/{vendor}")
                    cache.invalidate_prefix("vendors")
                    cache.invalidate_prefix("operations")
            except (ValueError, IndexError):
                pass

        if "netsight/parsers/types.py" in rel or "netsight/parsers/transforms.py" in rel:
            cache.invalidate_prefix("registries/types")
            cache.invalidate_prefix("registries/transforms")

        if "netsight/parsers/engines/" in rel:
            cache.invalidate_prefix("registries/engines")

        if "netsight/plugins/" in rel:
            cache.invalidate_prefix("registries/plugins")
            cache.invalidate_prefix("registries/functions")

        if rel.startswith("docs/") or rel.endswith(".md"):
            cache.invalidate_prefix("docs")

        if "UNITTEST/fixtures/" in rel:
            cache.invalidate_prefix("fixtures")

        if "examples/" in rel:
            cache.invalidate_prefix("examples")
