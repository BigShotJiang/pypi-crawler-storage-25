"""Resource cache with TTL and prefix invalidation."""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

logger = logging.getLogger(__name__)


class ResourceCache:
    """Simple TTL cache with invalidation by key or prefix.

    Args:
        default_ttl: Default time-to-live in seconds. None means no expiry.
    """

    def __init__(self, default_ttl: float | None = None) -> None:
        self._default_ttl = default_ttl
        self._store: dict[str, tuple[Any, float | None]] = {}

    def get_or_compute(
        self,
        key: str,
        compute: Callable[[], Any],
        ttl: float | None = None,
    ) -> Any:
        """Get a cached value or compute it if missing or expired.

        Args:
            key: Cache key.
            compute: Function to compute the value on miss.
            ttl: Override the default TTL for this entry.

        Returns:
            The cached or computed value.
        """
        now = time.monotonic()
        entry = self._store.get(key)
        if entry is not None:
            value, expires_at = entry
            if expires_at is None or expires_at > now:
                logger.debug("Cache hit: %s", key)
                return value
            logger.debug("Cache expired: %s", key)

        logger.debug("Cache miss: %s", key)
        value = compute()
        effective_ttl = ttl if ttl is not None else self._default_ttl
        expires_at = now + effective_ttl if effective_ttl is not None else None
        self._store[key] = (value, expires_at)
        return value

    def invalidate(self, key: str) -> None:
        """Remove a specific key from the cache."""
        self._store.pop(key, None)
        logger.debug("Invalidated: %s", key)

    def invalidate_prefix(self, prefix: str) -> None:
        """Remove all keys starting with the given prefix."""
        to_remove = [k for k in self._store if k.startswith(prefix)]
        for k in to_remove:
            del self._store[k]
        logger.debug("Invalidated %d keys with prefix '%s'", len(to_remove), prefix)

    def invalidate_all(self) -> None:
        """Clear the entire cache."""
        count = len(self._store)
        self._store.clear()
        logger.debug("Invalidated all %d entries", count)

    def __contains__(self, key: str) -> bool:
        return key in self._store
