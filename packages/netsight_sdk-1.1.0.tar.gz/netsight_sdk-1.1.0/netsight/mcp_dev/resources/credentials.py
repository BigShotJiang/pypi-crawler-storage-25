"""Resource handler for credential provider registry queries.

Exposes ``netsight://credentials`` — a live view of every registered
credential provider (built-in and third-party), including each
provider's health status so ``netsight doctor`` style checks can be
surfaced through the MCP interface without additional tooling.
"""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry


class CredentialsHandler(ResourceHandler):
    """Expose the credential provider registry at ``netsight://credentials``."""

    uri_pattern = "netsight://credentials"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": "netsight://credentials", "name": "Credential providers"}]

    def get(self, uri: str, **params: Any) -> Any:
        from netsight.credentials.registry import credential_provider_registry

        credential_provider_registry.ensure_loaded()

        providers = []
        for info in credential_provider_registry.list():
            health = info.provider.health_check()
            providers.append({
                "name": info.name,
                "display_name": info.display_name,
                "description": info.description,
                "builtin": info.builtin,
                "health": health,
            })

        load_errors = credential_provider_registry.load_errors()
        error_summary = [
            {"name": name, "error": str(exc)}
            for name, exc in load_errors.items()
        ]

        return {
            "providers": providers,
            "count": len(providers),
            "entry_point_group": "netsight.credential_providers",
            "load_errors": error_summary,
            "_guidance": {
                "what_this_is": (
                    "Live snapshot of every credential provider registered in the "
                    "credential_provider_registry. Includes built-in providers "
                    "(env, dotenv, netsight-vault) and any third-party providers "
                    "discovered via the 'netsight.credential_providers' entry-point "
                    "group. The 'health' field mirrors what 'netsight doctor' reports "
                    "for each provider."
                ),
                "next_steps": [
                    "Read netsight://docs/guides/credential-management for the "
                    "full user-facing guide (quick start, vault setup, custom providers).",
                    "Call scaffold_credential_provider to generate boilerplate for a "
                    "new third-party credential provider package.",
                ],
                "see_also": {
                    "netsight://docs/guides/credential-management": (
                        "User-facing guide covering all built-in providers, "
                        "vault CLI, and how to write a custom provider."
                    ),
                    "netsight://registries": (
                        "Runtime registry counts for plugins, engines, types, "
                        "transforms — distinct from credential providers."
                    ),
                },
            },
        }


def register_all() -> None:
    """Register the credentials resource handler."""
    resource_registry.register(CredentialsHandler())
