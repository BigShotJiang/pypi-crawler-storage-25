"""Resource handler for @operation metadata."""

from __future__ import annotations

from typing import Any

from netsight.config_mgmt.store import FileConfigStore
from netsight.mcp_dev.resources import ResourceHandler, resource_registry


class OperationsHandler(ResourceHandler):
    # Template pattern so the registry routes both the index URI
    # (``netsight://operations``) and per-op URIs (``netsight://operations/
    # <name>``) to this handler. Same fix applied earlier to conventions,
    # docs/specs, docs/plans, and docs/guides handlers.
    uri_pattern = "netsight://operations{name}"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": "netsight://operations", "name": "All operations"}]

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://operations":
            return self._list_all_operations()
        # Specific operation
        name = uri.replace("netsight://operations/", "")
        return self._get_operation_detail(name)

    def _list_all_operations(self) -> dict[str, Any]:
        """Collect operations from all compiled vendor configs and installed packs.

        Returns a dict (not a bare list) so the response can carry a
        ``_guidance`` block alongside the data, consistent with other
        entry-point resources. Each operation entry is enriched with a
        ``has_parser_spec`` boolean so consumers can trivially distinguish
        parsed ops from raw-return ops without drilling into the YAML.

        Operations are sourced from two places:
        1. Compiled store (``config/vendors/.compiled/``) — legacy layout.
        2. Installed packs via ``pack_registry`` — reads each pack's
           ``_data/operations_catalog.toml`` directly via its ``config_root``
           Traversable (falls back to legacy ``operations.toml`` for packs
           that have not yet been migrated).
        """
        import tomllib

        ops: list[dict[str, Any]] = []
        parsed_count = 0
        raw_count = 0
        seen_ops: set[str] = set()

        # Source 1: compiled legacy store
        try:
            store = FileConfigStore("config/vendors")
            for vendor in store.list_vendors():
                for model in store.list_models(vendor):
                    try:
                        resolved = store.get_resolved(vendor, model)
                    except FileNotFoundError:
                        continue
                    for op_name, op_config in resolved.get("operations", {}).items():
                        has_spec = bool(
                            op_config.get("parser_spec")
                            or op_config.get("parser_resolved")
                        )
                        if has_spec:
                            parsed_count += 1
                        else:
                            raw_count += 1
                        ops.append({
                            "name": op_name,
                            "vendor": vendor,
                            "model": model,
                            "category": op_config.get("category", ""),
                            "description": op_config.get("description", ""),
                            "has_parser_spec": has_spec,
                        })
                        seen_ops.add(op_name)
        except Exception:
            pass

        # Source 2: installed packs (operations not yet in the compiled store)
        try:
            from netsight.packs.registry import pack_registry

            for pack_info in pack_registry.list():
                # Prefer the new catalog filename; fall back to legacy name.
                ops_file = pack_info.config_root.joinpath("operations_catalog.toml")
                if not ops_file.is_file():
                    ops_file = pack_info.config_root.joinpath("operations.toml")
                if not ops_file.is_file():
                    continue
                try:
                    raw_ops = tomllib.loads(ops_file.read_text(encoding="utf-8"))
                except Exception:
                    continue
                for op_name, op_config in raw_ops.items():
                    if not isinstance(op_config, dict):
                        continue
                    if op_name in seen_ops:
                        continue
                    has_spec = bool(op_config.get("parser_spec"))
                    if has_spec:
                        parsed_count += 1
                    else:
                        raw_count += 1
                    ops.append({
                        "name": op_name,
                        "vendor": pack_info.vendor,
                        "model": pack_info.device_type,
                        "category": op_config.get("category", ""),
                        "description": op_config.get("description", ""),
                        "has_parser_spec": has_spec,
                    })
                    seen_ops.add(op_name)
        except Exception:
            pass

        return {
            "operations": ops,
            "count": len(ops),
            "parsed_count": parsed_count,
            "raw_count": raw_count,
            "_guidance": {
                "what_this_is": (
                    "Every allowlisted operation across all installed "
                    "packs. An operation is a single device command "
                    "(e.g. 'show_system_info') the CommandGate permits "
                    "a pack to run. Operations are declared in the pack's "
                    "_data/operations_catalog.toml and must be enabled by "
                    "the user via 'netsight allowlist enable'. "
                    "'has_parser_spec' tells you whether the SDK returns "
                    "parsed structured data (True) or raw XML/text (False)."
                ),
                "not_to_be_confused_with": (
                    "netsight://parsers — that resource lists ONLY the "
                    "operations that have a parser spec (the 'parsed' "
                    "subset). This resource lists ALL operations "
                    "regardless of parsing state."
                ),
                "next_steps": [
                    "Read netsight://operations/<name> for the full detail "
                    "of a single operation (including output schema if parsed).",
                    "Call trace_operation_pipeline <name> to see the full "
                    "command → engine → spec → output flow.",
                    "Call find_operations_by_category <category> to filter "
                    "by category (system, network, logs).",
                    "Call find_operations_by_tag <tag> to filter by tag.",
                    "Read netsight://parsers to see only the parsed ops "
                    "with their spec summaries.",
                ],
                "see_also": {
                    "netsight://parsers": "The parsed-ops subset with spec summaries.",
                    "netsight://vendors/{vendor}": "Per-vendor operations catalogue.",
                    "netsight://patterns": "Curated multi-op workflows (health check, etc.).",
                },
            },
        }

    def _get_operation_detail(self, name: str) -> dict[str, Any]:
        """Get detailed info about a specific operation.

        Checks the compiled store first, then falls back to reading
        operations directly from installed packs.
        """
        import tomllib

        # Check compiled store first
        try:
            store = FileConfigStore("config/vendors")
            for vendor in store.list_vendors():
                for model in store.list_models(vendor):
                    try:
                        resolved = store.get_resolved(vendor, model)
                    except FileNotFoundError:
                        continue
                    op_config = resolved.get("operations", {}).get(name)
                    if op_config is not None:
                        result = {
                            "name": name,
                            "vendor": vendor,
                            "model": model,
                            **op_config,
                        }
                        # Add output schema if parser_resolved exists
                        parser_resolved = op_config.get("parser_resolved")
                        if parser_resolved:
                            try:
                                from netsight.docs.introspect import Introspector
                                result["output_schema"] = (
                                    Introspector.parser_spec_to_json_schema(parser_resolved)
                                )
                            except Exception:
                                pass
                        return result
        except Exception:
            pass

        # Fallback: search installed packs
        try:
            from netsight.packs.registry import pack_registry

            for pack_info in pack_registry.list():
                # Prefer the new catalog filename; fall back to legacy name.
                ops_file = pack_info.config_root.joinpath("operations_catalog.toml")
                if not ops_file.is_file():
                    ops_file = pack_info.config_root.joinpath("operations.toml")
                if not ops_file.is_file():
                    continue
                try:
                    raw_ops = tomllib.loads(ops_file.read_text(encoding="utf-8"))
                except Exception:
                    continue
                op_config = raw_ops.get(name)
                if op_config is not None and isinstance(op_config, dict):
                    return {
                        "name": name,
                        "vendor": pack_info.vendor,
                        "model": pack_info.device_type,
                        **op_config,
                    }
        except Exception:
            pass

        return {"error": f"Operation not found: {name}"}


def register_all() -> None:
    resource_registry.register(OperationsHandler())
