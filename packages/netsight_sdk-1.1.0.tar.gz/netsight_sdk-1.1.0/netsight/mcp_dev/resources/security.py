"""MCP resource handlers for security audit results."""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry


class SecurityCodeAuditHandler(ResourceHandler):
    uri_pattern = "netsight://security/code_audit"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Code audit findings"}]

    def get(self, uri: str, **params: Any) -> Any:
        try:
            from netsight.security.audit import AuditOrchestrator
            orch = AuditOrchestrator()
            return orch.audit_code_only()
        except Exception as e:
            return {"error": str(e)}


class SecurityDependenciesHandler(ResourceHandler):
    uri_pattern = "netsight://security/dependencies"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Dependency audit findings"}]

    def get(self, uri: str, **params: Any) -> Any:
        try:
            from netsight.security.audit import AuditOrchestrator
            orch = AuditOrchestrator()
            return orch.audit_deps_only()
        except Exception as e:
            return {"error": str(e)}


class SecurityPoliciesHandler(ResourceHandler):
    uri_pattern = "netsight://security/policies"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Security policies"}]

    def get(self, uri: str, **params: Any) -> Any:
        try:
            from netsight.security.audit import load_policies
            return load_policies()
        except Exception as e:
            return {"error": str(e)}


class SecurityKnownSafeHandler(ResourceHandler):
    uri_pattern = "netsight://security/known_safe"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Known safe versions"}]

    def get(self, uri: str, **params: Any) -> Any:
        try:
            from netsight.security.dependencies import load_known_safe
            return load_known_safe()
        except Exception as e:
            return {"error": str(e)}


def register_all() -> None:
    resource_registry.register(SecurityCodeAuditHandler())
    resource_registry.register(SecurityDependenciesHandler())
    resource_registry.register(SecurityPoliciesHandler())
    resource_registry.register(SecurityKnownSafeHandler())
