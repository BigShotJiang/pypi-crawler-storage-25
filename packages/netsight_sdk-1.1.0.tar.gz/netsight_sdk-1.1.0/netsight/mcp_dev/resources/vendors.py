"""Resource handlers for compiled vendor configs and parser specs.

Phase 6 note: the in-tree ``config/vendors/paloalto/`` tree was deleted
and the paloalto pack now ships as ``paloalto-firewall-xml`` via the
``netsight.packs`` entry-point group. The handlers below enumerate from
both the compiled legacy store (``config/vendors/.compiled/``) AND from
installed packs so that ``netsight://vendors`` still returns useful data
after the cutover. Phase 7 will formally introduce ``netsight://packs``
and make these handlers fully pack-native.
"""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from netsight.config_mgmt.store import FileConfigStore
from netsight.mcp_dev.resources import ResourceHandler, resource_registry

_CONFIG_DIR = "config/vendors"


def _store() -> FileConfigStore:
    return FileConfigStore(_CONFIG_DIR)


def _pack_vendor_entries() -> list[dict[str, Any]]:
    """Return vendor-style entries from installed packs.

    Each installed pack contributes one entry keyed by its canonical name
    (e.g. ``paloalto-firewall-xml``). The ``device_types`` list is populated
    from the pack's config_root sub-directories that are not reserved names.
    """
    try:
        from netsight.packs.registry import pack_registry

        entries = []
        for pack_info in pack_registry.list():
            try:
                device_types = [
                    d.name
                    for d in pack_info.config_root.iterdir()
                    if d.is_dir() and d.name not in {"parsers", "reference", "instances"}
                ]
            except Exception:
                device_types = []
            entries.append({
                "name": pack_info.name,
                "vendor": pack_info.vendor,
                "device_types": sorted(device_types),
                "uri": f"netsight://vendors/{pack_info.name}",
            })
        return entries
    except Exception:
        return []


class VendorsIndexHandler(ResourceHandler):
    uri_pattern = "netsight://vendors"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "All vendors"}]

    def get(self, uri: str, **params: Any) -> Any:
        s = _store()
        vendors = []
        seen: set[str] = set()

        # Compiled store entries (legacy)
        for vendor in s.list_vendors():
            vendors.append({
                "name": vendor,
                "device_types": s.list_models(vendor),
                "uri": f"netsight://vendors/{vendor}",
            })
            seen.add(vendor)

        # Pack-registry entries (Phase 6+)
        for entry in _pack_vendor_entries():
            if entry["name"] not in seen:
                vendors.append(entry)
                seen.add(entry["name"])

        return {
            "vendors": vendors,
            "_guidance": {
                "what_this_is": (
                    "Vendor configs from both the compiled config/vendors/ "
                    "tree and installed packs. A 'vendor' entry maps to a "
                    "device manufacturer (e.g. paloalto). Each vendor entry "
                    "lists its supported models/device types."
                ),
                "not_to_be_confused_with": (
                    "netsight://registries/plugins — plugins are the "
                    "Python client classes that talk to a device; vendors "
                    "are the configs consumed by those plugins."
                ),
                "next_steps": [
                    "Read netsight://vendors/<vendor> for a single vendor's "
                    "device types.",
                    "Read netsight://vendors/<vendor>/<device_type> for the "
                    "compiled config (connection, auth, operations).",
                    "Read netsight://vendors/<vendor>/parsers for the "
                    "vendor's parser specs, or netsight://parsers for "
                    "cross-vendor spec discovery.",
                    "Call scaffold_vendor_plugin to start a new vendor.",
                ],
                "see_also": {
                    "netsight://parsers": "All parser specs across all vendors.",
                    "netsight://operations": "All operations across all vendors.",
                    "netsight://registries/plugins": "The Python client classes behind vendors.",
                    "netsight://packs": (
                        "Preferred replacement — same data in the new pack-native "
                        "shape. The netsight://vendors namespace is a transition-window "
                        "alias and will be removed in a future release."
                    ),
                },
                "_deprecated_alias": (
                    "netsight://vendors is a deprecated alias for netsight://packs. "
                    "The vendors namespace returns the same installed-pack data but "
                    "in the legacy 'vendor' shape. Use netsight://packs for new "
                    "tooling — it includes the bundled index, load errors, and "
                    "parser-spec access at netsight://packs/{name}/parsers/{op}."
                ),
            },
        }


class VendorDetailHandler(ResourceHandler):
    uri_pattern = "netsight://vendors/{vendor}"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        s = _store()
        uris = [
            {"uri": f"netsight://vendors/{v}", "name": v}
            for v in s.list_vendors()
        ]
        seen = {v for v in s.list_vendors()}
        for entry in _pack_vendor_entries():
            if entry["name"] not in seen:
                uris.append({"uri": entry["uri"], "name": entry["name"]})
                seen.add(entry["name"])
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        # Extract vendor from URI
        parts = uri.replace("netsight://vendors/", "").split("/")
        if not parts or not parts[0]:
            return {"error": "Vendor name required"}
        vendor = parts[0]
        # If there's more to the path, it's not our handler's concern
        if len(parts) > 1:
            return {"error": "Sub-path not handled here"}

        s = _store()
        if vendor in s.list_vendors():
            return {
                "name": vendor,
                "device_types": s.list_models(vendor),
            }

        # Try pack registry
        for entry in _pack_vendor_entries():
            if entry["name"] == vendor:
                return {
                    "name": entry["name"],
                    "vendor": entry.get("vendor", vendor),
                    "device_types": entry["device_types"],
                }

        return {"error": f"Vendor not found: {vendor}"}


class DeviceTypeHandler(ResourceHandler):
    uri_pattern = "netsight://vendors/{vendor}/{device_type}"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        s = _store()
        uris = []
        seen: set[str] = set()
        for vendor in s.list_vendors():
            for dt in s.list_models(vendor):
                key = f"{vendor}/{dt}"
                uris.append({
                    "uri": f"netsight://vendors/{key}",
                    "name": key,
                })
                seen.add(key)
        # Also list pack sub-directories as device-type URIs
        for entry in _pack_vendor_entries():
            for dt in entry.get("device_types", []):
                key = f"{entry['name']}/{dt}"
                if key not in seen:
                    uris.append({
                        "uri": f"netsight://vendors/{key}",
                        "name": key,
                    })
                    seen.add(key)
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        # Match: netsight://vendors/{vendor}/{device_type}
        parts = uri.replace("netsight://vendors/", "").split("/")
        if len(parts) != 2:
            return {"error": "Invalid URI format"}
        vendor, device_type = parts

        # Try compiled store first
        try:
            return _store().get_resolved(vendor, device_type)
        except FileNotFoundError:
            pass

        # Fall back to pack config_root
        try:
            from netsight.packs.registry import pack_registry

            if pack_registry.has(name=vendor):
                pack_info = pack_registry.get(name=vendor)
                dt_dir = pack_info.config_root.joinpath(device_type)
                if dt_dir.is_dir():
                    # Return the pack-level operations as a minimal config dict
                    # Prefer the new catalog filename; fall back to legacy name.
                    ops_file = pack_info.config_root.joinpath("operations_catalog.toml")
                    if not ops_file.is_file():
                        ops_file = pack_info.config_root.joinpath("operations.toml")
                    ops = {}
                    if ops_file.is_file():
                        ops = tomllib.loads(
                            ops_file.read_text(encoding="utf-8")
                        )
                    return {
                        "pack": vendor,
                        "model": device_type,
                        "operations": {
                            k: v for k, v in ops.items()
                            if isinstance(v, dict)
                        },
                    }
        except Exception:
            pass

        return {"error": f"No compiled config for {vendor}/{device_type}"}


def _get_pack_parsers_traversable(vendor: str):
    """Return the parsers Traversable for a pack, or None if not found."""
    try:
        from netsight.packs.registry import pack_registry

        if pack_registry.has(name=vendor):
            pack_info = pack_registry.get(name=vendor)
            parsers = pack_info.config_root.joinpath("parsers")
            if parsers.is_dir():
                return parsers
    except Exception:
        pass
    return None


class ParserSpecHandler(ResourceHandler):
    uri_pattern = "netsight://vendors/{vendor}/parsers"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        uris: list[dict[str, Any]] = []

        # Legacy filesystem vendors
        vendors_dir = Path(_CONFIG_DIR)
        if vendors_dir.exists():
            for vendor_dir in vendors_dir.iterdir():
                if not vendor_dir.is_dir() or vendor_dir.name in ("global", ".compiled"):
                    continue
                parsers_dir = vendor_dir / "parsers"
                if not parsers_dir.exists():
                    continue
                for spec_file in sorted(parsers_dir.glob("*.yaml")):
                    op_name = spec_file.stem
                    uris.append({
                        "uri": f"netsight://vendors/{vendor_dir.name}/parsers/{op_name}",
                        "name": f"{vendor_dir.name}/{op_name}",
                    })

        # Pack parsers
        try:
            from netsight.packs.registry import pack_registry

            for pack_info in pack_registry.list():
                parsers = pack_info.config_root.joinpath("parsers")
                if not parsers.is_dir():
                    continue
                for spec_resource in sorted(
                    parsers.iterdir(), key=lambda r: r.name
                ):
                    if not spec_resource.name.endswith(".yaml"):
                        continue
                    op_name = spec_resource.name[:-5]
                    uris.append({
                        "uri": f"netsight://vendors/{pack_info.name}/parsers/{op_name}",
                        "name": f"{pack_info.name}/{op_name}",
                    })
        except Exception:
            pass

        return uris

    def get(self, uri: str, **params: Any) -> Any:
        # Formats:
        #   netsight://vendors/{vendor}/parsers           — list specs
        #   netsight://vendors/{vendor}/parsers/{op}      — specific spec
        path = uri.replace("netsight://vendors/", "")
        parts = path.split("/")
        if len(parts) < 2 or parts[1] != "parsers":
            return {"error": "Invalid URI format"}
        vendor = parts[0]

        # Try legacy filesystem parsers first
        parsers_dir = Path(_CONFIG_DIR) / vendor / "parsers"
        if parsers_dir.exists():
            if len(parts) == 2:
                result = []
                for spec_file in sorted(parsers_dir.glob("*.yaml")):
                    try:
                        spec = yaml.safe_load(spec_file.read_text())
                        result.append({
                            "operation": spec.get("operation", spec_file.stem),
                            "output_shape": spec.get("output_shape", "unknown"),
                            "description": spec.get("description", ""),
                        })
                    except Exception:
                        continue
                return result
            op_name = parts[2]
            spec_file = parsers_dir / f"{op_name}.yaml"
            if spec_file.exists():
                try:
                    return yaml.safe_load(spec_file.read_text())
                except Exception as e:
                    return {"error": f"Failed to load spec: {e}"}

        # Fall back to pack parsers
        pack_parsers = _get_pack_parsers_traversable(vendor)
        if pack_parsers is None:
            return {"error": f"No parsers directory for vendor {vendor}"}

        if len(parts) == 2:
            result = []
            for spec_resource in sorted(
                pack_parsers.iterdir(), key=lambda r: r.name
            ):
                if not spec_resource.name.endswith(".yaml"):
                    continue
                try:
                    spec = yaml.safe_load(
                        spec_resource.read_text(encoding="utf-8")
                    )
                    result.append({
                        "operation": spec.get("operation", spec_resource.name[:-5]),
                        "output_shape": spec.get("output_shape", "unknown"),
                        "description": spec.get("description", ""),
                    })
                except Exception:
                    continue
            return result

        op_name = parts[2]
        spec_resource = pack_parsers.joinpath(f"{op_name}.yaml")
        if not spec_resource.is_file():
            return {"error": f"Parser spec not found: {op_name}"}
        try:
            return yaml.safe_load(spec_resource.read_text(encoding="utf-8"))
        except Exception as e:
            return {"error": f"Failed to load spec: {e}"}


def register_all() -> None:
    """Register all vendor handlers."""
    resource_registry.register(VendorsIndexHandler())
    resource_registry.register(ParserSpecHandler())  # More specific — register first
    resource_registry.register(DeviceTypeHandler())
    resource_registry.register(VendorDetailHandler())
