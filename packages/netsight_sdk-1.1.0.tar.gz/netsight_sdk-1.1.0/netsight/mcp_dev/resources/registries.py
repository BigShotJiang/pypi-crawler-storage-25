"""Resource handlers for registry queries (plugins, engines, types, transforms, etc.)."""

from __future__ import annotations

import inspect
from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry
from netsight.parsers.registry import (
    function_registry,
    parser_registry,
    transform_registry,
    type_registry,
)
from netsight.registry import plugin_registry


class RegistriesIndexHandler(ResourceHandler):
    uri_pattern = "netsight://registries"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Registries Index"}]

    def get(self, uri: str, **params: Any) -> Any:
        return {
            "plugins_count": len(plugin_registry.list()),
            "engines_count": len(parser_registry.list_names()),
            "types_count": len(type_registry.list_names()),
            "transforms_count": len(transform_registry.list_names()),
            "functions_count": len(function_registry.list_names()),
            "_guidance": {
                "what_this_is": (
                    "Summary counts for every NetSight runtime registry. "
                    "Registries are the in-memory catalogue of pluggable "
                    "components the parser engine and plugin system can "
                    "use — distinct from on-disk configs (vendors) and "
                    "declared operations."
                ),
                "next_steps": [
                    "Read netsight://registries/plugins to see vendor plugins.",
                    "Read netsight://registries/engines to see parser engines "
                    "(jmespath, passthrough) that specs reference.",
                    "Read netsight://registries/types / transforms / functions "
                    "to see what's available for use inside a parser spec.",
                ],
                "see_also": {
                    "netsight://vendors": "On-disk vendor configs (distinct from plugins).",
                    "netsight://parsers": "Parser specs (YAML files that consume these registry components).",
                    "netsight://docs/guides/developer-guide#architecture-overview": "How the registries fit into the request pipeline.",
                },
            },
        }


class PluginsRegistryHandler(ResourceHandler):
    uri_pattern = "netsight://registries/plugins"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        uris = [{"uri": self.uri_pattern, "name": "All plugins"}]
        for p in plugin_registry.list():
            uris.append({
                "uri": f"netsight://registries/plugins/{p.name}",
                "name": p.name,
            })
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://registries/plugins":
            return [
                {
                    "name": p.name,
                    "metadata": p.metadata,
                    "allowed_operations_count": len(p.allowed_operations),
                }
                for p in plugin_registry.list()
            ]
        # Specific plugin
        name = uri.rsplit("/", 1)[-1]
        for p in plugin_registry.list():
            if p.name == name:
                return {
                    "name": p.name,
                    "client_class": p.client_class.__name__,
                    "validator_class": (
                        p.validator_class.__name__ if p.validator_class else None
                    ),
                    "metadata": p.metadata,
                    "allowed_operations": sorted(p.allowed_operations),
                    "allowed_operations_count": len(p.allowed_operations),
                }
        return {"error": f"Plugin not found: {name}"}


class EnginesRegistryHandler(ResourceHandler):
    uri_pattern = "netsight://registries/engines"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Parser engines"}]

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://registries/engines":
            return [
                {"name": name, "class": parser_registry.get(name).__name__}
                for name in parser_registry.list_names()
            ]
        # Specific engine
        name = uri.rsplit("/", 1)[-1]
        try:
            engine_class = parser_registry.get(name)
            return {
                "name": name,
                "class": engine_class.__name__,
                "module": engine_class.__module__,
                "docstring": inspect.getdoc(engine_class) or "",
            }
        except KeyError:
            return {"error": f"Engine not found: {name}"}


class TypesRegistryHandler(ResourceHandler):
    uri_pattern = "netsight://registries/types"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Field types"}]

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://registries/types":
            return [
                {"name": name, "docstring": inspect.getdoc(type_registry.get(name)) or ""}
                for name in type_registry.list_names()
            ]
        name = uri.rsplit("/", 1)[-1]
        try:
            fn = type_registry.get(name)
            return {
                "name": name,
                "docstring": inspect.getdoc(fn) or "",
                "module": getattr(fn, "__module__", "unknown"),
            }
        except KeyError:
            return {"error": f"Type not found: {name}"}


class TransformsRegistryHandler(ResourceHandler):
    uri_pattern = "netsight://registries/transforms"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Transforms"}]

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://registries/transforms":
            return [
                {"name": name, "docstring": inspect.getdoc(transform_registry.get(name)) or ""}
                for name in transform_registry.list_names()
            ]
        name = uri.rsplit("/", 1)[-1]
        try:
            fn = transform_registry.get(name)
            return {
                "name": name,
                "docstring": inspect.getdoc(fn) or "",
                "module": getattr(fn, "__module__", "unknown"),
            }
        except KeyError:
            return {"error": f"Transform not found: {name}"}


class FunctionsRegistryHandler(ResourceHandler):
    uri_pattern = "netsight://registries/functions"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Custom parser functions"}]

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://registries/functions":
            return [
                {
                    "name": name,
                    "docstring": inspect.getdoc(function_registry.get(name)) or "",
                    "module": getattr(function_registry.get(name), "__module__", "unknown"),
                }
                for name in function_registry.list_names()
            ]
        name = uri.rsplit("/", 1)[-1]
        try:
            fn = function_registry.get(name)
            source = ""
            try:
                source = inspect.getsource(fn)
            except (TypeError, OSError):
                pass
            return {
                "name": name,
                "docstring": inspect.getdoc(fn) or "",
                "module": getattr(fn, "__module__", "unknown"),
                "source": source,
            }
        except KeyError:
            return {"error": f"Function not found: {name}"}


class IntegrationsRegistryHandler(ResourceHandler):
    uri_pattern = "netsight://registries/integrations"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Integrations"}]

    def get(self, uri: str, **params: Any) -> Any:
        try:
            from netsight.integrations.registry import integration_registry
        except ImportError:
            return {"inventory": [], "sinks": [], "enrichment": []}

        return {
            "inventory": sorted(
                i.name for i in integration_registry.list_by_category("inventory")
            ),
            "sinks": sorted(
                i.name for i in integration_registry.list_by_category("sink")
            ),
            "enrichment": sorted(
                i.name for i in integration_registry.list_by_category("enrichment")
            ),
        }


def register_all() -> None:
    """Register all registry handlers."""
    resource_registry.register(RegistriesIndexHandler())
    resource_registry.register(PluginsRegistryHandler())
    resource_registry.register(EnginesRegistryHandler())
    resource_registry.register(TypesRegistryHandler())
    resource_registry.register(TransformsRegistryHandler())
    resource_registry.register(FunctionsRegistryHandler())
    resource_registry.register(IntegrationsRegistryHandler())
