"""Cross-vendor parser-spec resource.

``netsight://parsers`` is the dedicated entry point for discovering parser
specs across ALL vendors — distinct from ``netsight://operations`` which
lists every allowlisted operation (including those that have no parser
spec and return raw responses). Keeping the two listings separate makes
the distinction unambiguous for LLM consumers.

A response from this handler always contains a ``_guidance`` block with
suggested next steps and cross-references, so a model calling it for the
first time learns the surrounding landscape without extra round-trips.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from netsight.mcp_dev.path_security import PROJECT_ROOT
from netsight.mcp_dev.resources import ResourceHandler, resource_registry

_CONFIG_DIR = PROJECT_ROOT / "config" / "vendors"

# Subdirectories under config/vendors/ that are not real vendors.
_NON_VENDOR_DIRS: frozenset[str] = frozenset({"global", ".compiled"})


def _iter_parser_spec_files() -> list[Path]:
    """Return every parser spec YAML Path from the legacy config/vendors/ tree.

    Results are sorted (vendor, then operation name) for deterministic output.
    """
    out: list[Path] = []
    if not _CONFIG_DIR.exists():
        return out
    for vendor_dir in sorted(_CONFIG_DIR.iterdir()):
        if not vendor_dir.is_dir() or vendor_dir.name in _NON_VENDOR_DIRS:
            continue
        parsers_dir = vendor_dir / "parsers"
        if not parsers_dir.exists():
            continue
        out.extend(sorted(parsers_dir.glob("*.yaml")))
    return out


def _iter_pack_parser_specs() -> list[dict[str, Any]]:
    """Return parser spec summaries from all installed packs.

    Reads each pack's ``_data/parsers/*.yaml`` via Traversable so it
    works for both editable installs (Path) and wheel-backed installs.
    """
    specs: list[dict[str, Any]] = []
    try:
        from netsight.packs.registry import pack_registry

        for pack_info in pack_registry.list():
            parsers = pack_info.config_root.joinpath("parsers")
            if not parsers.is_dir():
                continue
            for resource in sorted(parsers.iterdir(), key=lambda r: r.name):
                if not resource.name.endswith(".yaml"):
                    continue
                operation = resource.name[:-5]
                try:
                    raw = yaml.safe_load(
                        resource.read_text(encoding="utf-8")
                    ) or {}
                except Exception as exc:
                    specs.append({
                        "vendor": pack_info.name,
                        "operation": operation,
                        "error": f"Could not parse spec: {exc}",
                    })
                    continue
                fields = raw.get("fields") or {}
                specs.append({
                    "vendor": pack_info.name,
                    "operation": raw.get("operation", operation),
                    "engine": raw.get("engine", "unknown"),
                    "input_format": raw.get("input_format", "unknown"),
                    "output_shape": raw.get("output_shape", "unknown"),
                    "description": raw.get("description", ""),
                    "field_count": len(fields) if isinstance(fields, dict) else 0,
                    "root": raw.get("root", ""),
                    "uri": (
                        f"netsight://vendors/{pack_info.name}/parsers/{operation}"
                    ),
                })
    except Exception:
        pass
    return specs


def _summarize_spec(spec_file: Path) -> dict[str, Any]:
    """Summarise a single parser spec for the index response.

    Returns operation name, engine, input/output format, field count, and a
    deep-link URI pointing at the existing vendor-scoped handler that
    serves the full spec body.
    """
    vendor = spec_file.parent.parent.name
    operation = spec_file.stem
    try:
        raw = yaml.safe_load(spec_file.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        return {
            "vendor": vendor,
            "operation": operation,
            "error": f"Could not parse spec: {exc}",
            "source_path": str(spec_file.relative_to(PROJECT_ROOT)),
        }

    fields = raw.get("fields") or {}
    return {
        "vendor": vendor,
        "operation": raw.get("operation", operation),
        "engine": raw.get("engine", "unknown"),
        "input_format": raw.get("input_format", "unknown"),
        "output_shape": raw.get("output_shape", "unknown"),
        "description": raw.get("description", ""),
        "field_count": len(fields) if isinstance(fields, dict) else 0,
        "root": raw.get("root", ""),
        "uri": f"netsight://vendors/{vendor}/parsers/{operation}",
        "source_path": str(spec_file.relative_to(PROJECT_ROOT)),
    }


def _engines_in_use(specs: list[dict[str, Any]]) -> list[str]:
    """Return the distinct parser engines actually used by the live specs."""
    return sorted({s["engine"] for s in specs if "engine" in s})


_GUIDANCE_NEXT_STEPS = [
    "Read a specific spec with ReadMcpResourceTool on its 'uri' field "
    "(e.g. netsight://vendors/paloalto/parsers/show_system_info) to see "
    "the full YAML — root, fields, types, and transforms.",
    "Call trace_operation_pipeline <operation> to see how a spec is wired "
    "into the end-to-end command → engine → output flow.",
    "Call diff_parser_specs on two spec dicts to compare them "
    "structurally (engine, root, fields added/removed/changed).",
    "Call scaffold_parser_spec with a sample XML blob to generate a new "
    "starter spec for an operation that doesn't have one yet.",
    "Call validate_parser_spec with YAML content to check a spec's "
    "structure before writing it to disk.",
]

_GUIDANCE_SEE_ALSO = {
    "netsight://operations": (
        "EVERY allowlisted operation (parsed and raw). Parser specs exist "
        "only for operations that return structured data — many operations "
        "are allowlisted but have no spec and return raw responses."
    ),
    "netsight://registries/engines": (
        "The parser engines available to specs (jmespath, passthrough). "
        "Every spec's 'engine' field must reference one of these."
    ),
    "netsight://registries/types": (
        "Field type coercers (str, int, ip, bool, etc.) usable in a "
        "spec's fields[*].type."
    ),
    "netsight://registries/transforms": (
        "Field transforms (strip, lower, etc.) usable in a spec's "
        "fields[*].transform pipeline."
    ),
    "netsight://registries/functions": (
        "Custom parser functions that specs can call via "
        "{function: name, args: {...}} for complex field extraction."
    ),
    "netsight://vendors/{vendor}/parsers": (
        "Per-vendor parser spec listing — use this when you only care "
        "about one vendor's specs."
    ),
    "netsight://docs/guides/developer-guide#writing-parser-specs": (
        "Developer guide section on how parser specs are structured and "
        "how the engine evaluates them."
    ),
}


class ParsersIndexHandler(ResourceHandler):
    # Template pattern so the registry's prefix match routes both the
    # index URI (``netsight://parsers``) and future sub-URIs to this
    # handler. The ``{rest}`` marker is placed directly after the prefix.
    uri_pattern = "netsight://parsers{rest}"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [
            {
                "uri": "netsight://parsers",
                "name": "All parser specs (cross-vendor)",
            }
        ]

    def get(self, uri: str, **params: Any) -> Any:
        # Only the bare index URI is served by this handler; sub-URIs
        # (e.g. per-vendor or per-spec reads) are handled by the existing
        # vendor-scoped ParserSpecHandler at netsight://vendors/{vendor}/parsers/...
        if uri != "netsight://parsers":
            return {
                "error": (
                    f"Not served by this handler: {uri}. For a specific "
                    f"spec, use netsight://vendors/<vendor>/parsers/<op>."
                )
            }

        # Combine legacy filesystem specs and installed-pack specs
        specs = [_summarize_spec(p) for p in _iter_parser_spec_files()]
        specs.extend(_iter_pack_parser_specs())
        engines = _engines_in_use(specs)

        # Count by vendor for quick orientation
        vendors: dict[str, int] = {}
        for s in specs:
            vendors[s["vendor"]] = vendors.get(s["vendor"], 0) + 1

        return {
            "parser_specs": specs,
            "count": len(specs),
            "by_vendor": vendors,
            "engines_in_use": engines,
            "_guidance": {
                "what_this_is": (
                    "Parser specs transform a device's raw response (usually "
                    "XML) into a structured Python dict or list. ONE spec "
                    "corresponds to ONE allowlisted operation, and lives at "
                    "config/vendors/<vendor>/parsers/<operation>.yaml. "
                    "Operations without a spec return raw responses — "
                    "compare the count here (parsed ops) vs the count at "
                    "netsight://operations (all ops)."
                ),
                "not_to_be_confused_with": (
                    "netsight://operations (lists ALL ops, including raw); "
                    "netsight://registries/engines (the parser ENGINES, "
                    "which are Python classes like JMESPathEngine — there "
                    "are only 2 of them and they are consumed BY specs, not "
                    "listed as specs)."
                ),
                "next_steps": _GUIDANCE_NEXT_STEPS,
                "see_also": _GUIDANCE_SEE_ALSO,
            },
        }


def register_all() -> None:
    """Register the parsers index handler."""
    resource_registry.register(ParsersIndexHandler())
