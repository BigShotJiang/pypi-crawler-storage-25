"""Resource handlers for project conventions."""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry


_COMMIT_CONVENTIONS = """# Commit Message Conventions

- Use conventional commit prefixes: feat, fix, docs, refactor, test, chore
- Keep subject line under 72 characters
- Use imperative mood: "add feature" not "added feature"
- NEVER include references to "Claude" or AI tools in commit messages
- NEVER add "Co-Authored-By: Claude" trailers
- Pre-commit hook enforces the no-Claude-reference rule

Examples:
  feat: add parser engine with JMESPath support
  fix: skip XML validation for log-type operations
  docs: add user guide and developer guide
  refactor: simplify firewall inventory example using parser engine
"""


_FILE_NAMING = """# File Naming Conventions

## Python files
- Modules: lowercase with underscores (e.g. parser_engine.py)
- Tests: test_<module_name>.py in UNITTEST/
- Private: leading underscore (_internal.py)

## TOML files
- Section files: connection.toml, resilience.toml, auth.toml, metadata.toml
- Operations catalog: operations_catalog.toml (canonical name; legacy operations.toml accepted with DeprecationWarning)

## YAML files
- Parser specs: <operation_name>.yaml (e.g. show_routes.yaml)
- Device inventory: devices.yaml

## Directories
- Python packages: lowercase, no underscores where possible
- Vendor configs: config/vendors/<vendor_name>/
- Device types: config/vendors/<vendor>/<device_type>/
- Instance overrides: config/vendors/<vendor>/<device_type>/instances/<device_name>/
"""


_TEST_PATTERNS = """# Test Patterns

## Test-Driven Development (TDD)
1. Write a failing test first
2. Run it to verify it fails
3. Write minimal code to make it pass
4. Run tests to verify they pass
5. Refactor if needed
6. Commit

## Test organization
- Unit tests: UNITTEST/test_<module>.py
- Fixtures: UNITTEST/fixtures/<vendor>/
- Integration tests: UNITTEST/test_*_integration.py
- Regression tests: UNITTEST/test_*_regression.py

## Running tests
- Full suite: .venv/bin/pytest UNITTEST/
- Single file: .venv/bin/pytest UNITTEST/test_foo.py -v
- With coverage: .venv/bin/pytest UNITTEST/ --cov=netsight
- Full cycle: bash TOOLS/full_test_cycle.sh

## Parser spec regression tests
For each parser spec, capture a representative XML fixture and assert
the parsed output matches expected structure exactly.
"""


class ConventionsHandler(ResourceHandler):
    # Template pattern so the registry's prefix match routes both the
    # index URI (``netsight://conventions``) and per-section URIs
    # (``netsight://conventions/commits`` etc.) here. The ``{section}``
    # marker is placed directly after the prefix — ResourceRegistry matches
    # URIs by the substring preceding the first ``{``, which gives
    # ``netsight://conventions`` and matches both forms.
    uri_pattern = "netsight://conventions{section}"
    strategy = "full"

    _SECTIONS: dict[str, str] = {
        "commits": _COMMIT_CONVENTIONS,
        "file_naming": _FILE_NAMING,
        "test_patterns": _TEST_PATTERNS,
    }

    def list_uris(self) -> list[dict[str, Any]]:
        return [
            {"uri": "netsight://conventions", "name": "Conventions index"},
            {"uri": "netsight://conventions/commits", "name": "Commit conventions"},
            {"uri": "netsight://conventions/file_naming", "name": "File naming"},
            {"uri": "netsight://conventions/test_patterns", "name": "Test patterns"},
        ]

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://conventions":
            return {"sections": sorted(self._SECTIONS.keys())}
        section = uri.replace("netsight://conventions/", "", 1)
        content = self._SECTIONS.get(section)
        if content is None:
            return {"error": f"Unknown convention: {section}"}
        return {"content": content}


def register_all() -> None:
    resource_registry.register(ConventionsHandler())
