"""ResourceHandler ABC and ResourceRegistry for MCP dev server."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


class ResourceHandler(ABC):
    """Base class for MCP resource handlers.

    Subclasses must define:
    - ``uri_pattern`` — the URI pattern this handler matches (e.g. ``netsight://vendors/{vendor}``)
    - ``strategy`` — ``full`` | ``two_tier`` | ``paginated``
    - ``list_uris()`` — return the list-form URIs this handler exposes
    - ``get(uri, **params)`` — return the content for a specific URI
    """

    uri_pattern: str
    strategy: str

    @abstractmethod
    def list_uris(self) -> list[dict[str, Any]]:
        """Return a list of URIs exposed by this handler."""

    @abstractmethod
    def get(self, uri: str, **params: Any) -> Any:
        """Return the content for a specific URI."""


class ResourceRegistry:
    """Registry of resource handlers keyed by URI prefix."""

    def __init__(self) -> None:
        self._handlers: list[ResourceHandler] = []

    def register(self, handler: ResourceHandler) -> None:
        """Register a resource handler."""
        self._handlers.append(handler)
        logger.debug("Registered resource handler: %s", handler.uri_pattern)

    def find_handler(self, uri: str) -> ResourceHandler | None:
        """Find a handler whose pattern matches the given URI.

        Matching rules:
        - If the handler's ``uri_pattern`` contains ``{``, it's a template.
          A URI matches if it starts with the prefix before the first ``{``.
        - Otherwise, the match must be exact.
        """
        for handler in self._handlers:
            if self._matches(handler.uri_pattern, uri):
                return handler
        return None

    def list_handlers(self) -> list[ResourceHandler]:
        """Return all registered handlers."""
        return list(self._handlers)

    @staticmethod
    def _matches(pattern: str, uri: str) -> bool:
        if "{" in pattern:
            prefix = pattern.split("{", 1)[0]
            return uri.startswith(prefix)
        return uri == pattern


resource_registry = ResourceRegistry()
