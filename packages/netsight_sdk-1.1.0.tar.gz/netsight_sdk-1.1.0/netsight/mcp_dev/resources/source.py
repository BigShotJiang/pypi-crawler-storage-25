"""Resource handlers for source file access."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

from netsight.mcp_dev.path_security import (
    PROJECT_ROOT,
    SIBLING_REPO_SPECS,
    SIBLING_ROOTS,
    SOURCE_ALLOW_PATTERNS,
    is_path_allowed,
    is_path_allowed_for_root,
)
from netsight.mcp_dev.resources import ResourceHandler, resource_registry


class SourceTreeHandler(ResourceHandler):
    uri_pattern = "netsight://source"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Source tree"}]

    def get(self, uri: str, **params: Any) -> Any:
        tree: list[dict[str, Any]] = []
        for file_path in self._walk_allowed():
            rel = file_path.relative_to(PROJECT_ROOT).as_posix()
            tree.append({
                "path": rel,
                "uri": f"netsight://source/{rel}",
                "size": file_path.stat().st_size,
            })
        tree.sort(key=lambda item: item["path"])
        return tree

    def _walk_allowed(self) -> Iterator[Path]:
        """Yield Path objects for all files that pass the allow/block list."""
        seen = set()
        for pattern in SOURCE_ALLOW_PATTERNS:
            # fnmatch patterns don't directly map to glob; use rglob for recursive
            base_parts = pattern.split("/**/")
            if len(base_parts) == 2:
                base, rest = base_parts
                base_path = PROJECT_ROOT / base
                if not base_path.exists():
                    continue
                for p in base_path.rglob(rest):
                    rel = p.relative_to(PROJECT_ROOT).as_posix()
                    if rel not in seen and p.is_file() and is_path_allowed(rel):
                        seen.add(rel)
                        yield p
            else:
                # Exact or simple glob
                for p in PROJECT_ROOT.glob(pattern):
                    rel = p.relative_to(PROJECT_ROOT).as_posix()
                    if rel not in seen and p.is_file() and is_path_allowed(rel):
                        seen.add(rel)
                        yield p


class SourceFileHandler(ResourceHandler):
    uri_pattern = "netsight://source/{path}"
    strategy = "paginated"

    def list_uris(self) -> list[dict[str, Any]]:
        # Delegated to SourceTreeHandler
        return []

    def get(self, uri: str, **params: Any) -> Any:
        rel_path = uri.replace("netsight://source/", "", 1)
        if not rel_path or rel_path == "netsight://source":
            return {"error": "Path required"}

        if not is_path_allowed(rel_path):
            return {"error": f"Access denied: {rel_path}"}

        abs_path = (PROJECT_ROOT / rel_path).resolve()
        if not abs_path.exists():
            return {"error": f"File not found: {rel_path}"}
        if not abs_path.is_file():
            return {"error": f"Not a file: {rel_path}"}

        try:
            content = abs_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as e:
            return {"error": f"Cannot read file: {e}"}

        # Apply line range if requested
        lines_param = params.get("lines")
        if lines_param:
            content = self._slice_lines(content, lines_param)

        return {
            "path": rel_path,
            "content": content,
            "size": abs_path.stat().st_size,
        }

    @staticmethod
    def _slice_lines(content: str, lines_spec: str) -> str:
        """Return a line range slice like '10-50'."""
        try:
            start_str, end_str = lines_spec.split("-", 1)
            start = max(1, int(start_str))
            end = int(end_str)
        except ValueError:
            return content
        lines = content.splitlines(keepends=True)
        return "".join(lines[start - 1:end])


class SiblingSourceFileHandler(ResourceHandler):
    """Serves individual files from sibling repos via ``netsight://source/@{repo_name}/{path}``."""

    uri_pattern = "netsight://source/@{repo_name}/{path}"
    strategy = "paginated"

    def list_uris(self) -> list[dict[str, Any]]:
        # Delegated to SiblingSourceTreeHandler
        return []

    def get(self, uri: str, **params: Any) -> Any:
        # Strip the URI prefix
        after_at = uri.replace("netsight://source/@", "", 1)
        if not after_at or "/" not in after_at:
            return {"error": "URI must be netsight://source/@{repo_name}/{path}"}

        repo_name, rel_path = after_at.split("/", 1)

        if not rel_path:
            return {"error": f"Path required after repo name '{repo_name}'"}

        root = SIBLING_ROOTS.get(repo_name)
        if root is None:
            known = sorted(SIBLING_ROOTS.keys())
            return {
                "error": (
                    f"Sibling repo '{repo_name}' not found on disk. "
                    f"Known detected siblings: {known}"
                )
            }

        if not is_path_allowed_for_root(rel_path, root, repo_name):
            return {"error": f"Access denied: {rel_path} in repo '{repo_name}'"}

        abs_path = (root / rel_path).resolve()
        if not abs_path.exists():
            return {"error": f"File not found: {rel_path} in repo '{repo_name}'"}
        if not abs_path.is_file():
            return {"error": f"Not a file: {rel_path} in repo '{repo_name}'"}

        try:
            content = abs_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as e:
            return {"error": f"Cannot read file: {e}"}

        return {
            "repo": repo_name,
            "path": rel_path,
            "uri": uri,
            "content": content,
            "size": abs_path.stat().st_size,
        }


class SiblingSourceTreeHandler(ResourceHandler):
    """Lists allowed files across all detected sibling repos via ``netsight://source/@{repo_name}``."""

    uri_pattern = "netsight://source/@{repo_name}"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        return [
            {
                "uri": f"netsight://source/@{repo_name}",
                "name": f"Source tree: {repo_name}",
            }
            for repo_name in sorted(SIBLING_ROOTS.keys())
        ]

    def get(self, uri: str, **params: Any) -> Any:
        # Extract repo_name from URI
        after_at = uri.replace("netsight://source/@", "", 1)
        # Strip any trailing path component — this handler is tree-only
        repo_name = after_at.split("/", 1)[0] if "/" in after_at else after_at

        root = SIBLING_ROOTS.get(repo_name)
        if root is None:
            known = sorted(SIBLING_ROOTS.keys())
            return {
                "error": (
                    f"Sibling repo '{repo_name}' not found on disk. "
                    f"Known detected siblings: {known}"
                )
            }

        tree: list[dict[str, Any]] = []
        for file_path in self._walk_allowed(repo_name, root):
            rel = file_path.relative_to(root).as_posix()
            tree.append({
                "repo": repo_name,
                "path": rel,
                "uri": f"netsight://source/@{repo_name}/{rel}",
                "size": file_path.stat().st_size,
            })
        tree.sort(key=lambda item: item["path"])
        return tree

    def _walk_allowed(self, repo_name: str, root: Path) -> Iterator[Path]:
        """Yield Path objects for all allowed files in the sibling repo."""
        _dir_name, patterns = SIBLING_REPO_SPECS[repo_name]
        seen: set[str] = set()
        for pattern in patterns:
            base_parts = pattern.split("/**/")
            if len(base_parts) == 2:
                base, rest = base_parts
                base_path = root / base
                if not base_path.exists():
                    continue
                for p in base_path.rglob(rest):
                    rel = p.relative_to(root).as_posix()
                    if rel not in seen and p.is_file() and is_path_allowed_for_root(rel, root, repo_name):
                        seen.add(rel)
                        yield p
            else:
                for p in root.glob(pattern):
                    rel = p.relative_to(root).as_posix()
                    if rel not in seen and p.is_file() and is_path_allowed_for_root(rel, root, repo_name):
                        seen.add(rel)
                        yield p


def register_all() -> None:
    """Register source handlers."""
    # Sibling handlers first — most-specific URI patterns take precedence
    resource_registry.register(SiblingSourceFileHandler())
    resource_registry.register(SiblingSourceTreeHandler())
    resource_registry.register(SourceFileHandler())  # More specific — register first
    resource_registry.register(SourceTreeHandler())
