"""Resource handlers for API contracts (OpenAPI, GraphQL).

These resources expose introspection of the **runtime HTTP API**
that lives in the separate ``netsight-ops`` distribution. After the
SDK/ops split, ``netsight-sdk`` no longer ships ``netsight.api`` —
it lives at ``netsight_ops.api``. The handlers below import from
``netsight_ops.api.*`` lazily and degrade gracefully when
``netsight-ops`` is not installed.

Pre-split (legacy) callers may still try to reach
``netsight.api.*``; we transparently fall back to that import path
to keep the dev MCP server usable in any mixed-version environment
during the transition.
"""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry

_OPS_NOT_INSTALLED_MESSAGE = (
    "netsight-ops is not installed. The HTTP API server lives in the "
    "netsight-ops distribution; install it with `pip install netsight-ops` "
    "to expose API schema introspection through the dev MCP server."
)


def _import_create_app() -> Any:
    """Return ``create_fastapi_app`` from netsight-ops, or ``None``.

    Tries the post-split location first (``netsight_ops.api``); falls
    back to the legacy in-tree location (``netsight.api``) so this
    code keeps working during the transition window when the user
    might have an older sdk that still ships api/.
    """
    try:
        from netsight_ops.api import create_fastapi_app  # type: ignore[import-not-found]
        return create_fastapi_app
    except ImportError:
        pass
    try:
        from netsight.api.server import create_app  # type: ignore[import-not-found]
        return create_app
    except ImportError:
        return None


def _import_graphql_schema() -> Any:
    """Return the GraphQL ``schema`` object from netsight-ops, or ``None``."""
    try:
        from netsight_ops.api.graphql.schema import schema  # type: ignore[import-not-found]
        return schema
    except ImportError:
        pass
    try:
        from netsight.api.graphql.schema import schema  # type: ignore[import-not-found]
        return schema
    except ImportError:
        return None


class OpenAPIHandler(ResourceHandler):
    uri_pattern = "netsight://api/openapi"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "OpenAPI schema"}]

    def get(self, uri: str, **params: Any) -> Any:
        create_app = _import_create_app()
        if create_app is None:
            return {"error": _OPS_NOT_INSTALLED_MESSAGE, "available": False}
        try:
            app = create_app()
            return app.openapi()
        except Exception as e:  # noqa: BLE001 — wrap any vendor-side error
            return {"error": f"Failed to generate OpenAPI: {e}"}


class GraphQLSchemaHandler(ResourceHandler):
    uri_pattern = "netsight://api/graphql/schema"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "GraphQL schema"}]

    def get(self, uri: str, **params: Any) -> Any:
        schema = _import_graphql_schema()
        if schema is None:
            return {"error": _OPS_NOT_INSTALLED_MESSAGE, "available": False}
        try:
            return {"schema": str(schema)}
        except Exception as e:  # noqa: BLE001
            return {"error": f"Failed to generate GraphQL schema: {e}"}


def register_all() -> None:
    resource_registry.register(OpenAPIHandler())
    resource_registry.register(GraphQLSchemaHandler())
