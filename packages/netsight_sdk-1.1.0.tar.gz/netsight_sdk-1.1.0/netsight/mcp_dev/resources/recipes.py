"""Implementation-recipe resource for the NetSight Dev MCP Server.

``netsight://recipes`` returns the index of canonical implementation
patterns for this codebase; ``netsight://recipes/<name>`` returns one
recipe with its canonical example, common mistakes, and cross-references.

Recipes live as YAML files under ``netsight/mcp_dev/recipes/*.yaml`` so
they are editable by humans, reviewable in diffs, and testable via a
drift-detection regression test that asserts each recipe's
``canonical_source_files`` and ``drift_markers`` still resolve against
the live source tree.

Distinct from ``netsight://patterns`` (operation-level investigation
workflows) and ``netsight://conventions`` (high-level project rules).
This resource is about CODE patterns — how to write a docstring, a
parser spec, a plugin client, or a logging statement the way the
NetSight codebase actually does it.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from netsight.mcp_dev.path_security import PROJECT_ROOT
from netsight.mcp_dev.resources import ResourceHandler, resource_registry

_RECIPES_DIR = PROJECT_ROOT / "netsight" / "mcp_dev" / "recipes"


def _list_recipe_files() -> list[Path]:
    """Return sorted .yaml files under the recipes directory."""
    if not _RECIPES_DIR.exists():
        return []
    return sorted(_RECIPES_DIR.glob("*.yaml"))


def _load_recipe(name: str) -> dict[str, Any] | None:
    """Load a single recipe by name (the file stem). Returns None if missing."""
    path = _RECIPES_DIR / f"{name}.yaml"
    if not path.exists():
        return None
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError:
        return None
    return data if isinstance(data, dict) else None


def _load_all_recipes() -> list[dict[str, Any]]:
    """Load every recipe file. Skips files that fail to parse."""
    out: list[dict[str, Any]] = []
    for path in _list_recipe_files():
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
        except yaml.YAMLError:
            continue
        if isinstance(data, dict):
            out.append(data)
    return out


_INDEX_GUIDANCE = {
    "what_this_is": (
        "Canonical implementation patterns for the NetSight SDK — the "
        "'how do we write X here' catalog. Each recipe is a structured "
        "dict with a canonical example, common mistakes, and cross-"
        "references to related resources and tools."
    ),
    "when_to_use": (
        "BEFORE writing new code in an unfamiliar area. Before defaulting "
        "to whatever docstring/logging/test style you would use in a "
        "different Python project — this codebase has canonical forms "
        "and mixing styles is considered a bug."
    ),
    "when_scaffolding": (
        "The scaffolding tools (scaffold_parser_spec, scaffold_vendor_plugin, "
        "etc.) inject a '_recipe_hint' field into their responses pointing "
        "at the relevant recipe. Follow the hint before writing the "
        "generated content to disk — it catches the mistakes that "
        "lint_yaml_spec and compile_dry_run will flag later."
    ),
    "not_to_be_confused_with": (
        "netsight://patterns — that resource lists curated OPERATION "
        "workflows (health check, route investigation). This resource is "
        "about CODE patterns (docstring format, parser spec shape, "
        "plugin client contracts). Completely separate namespaces."
    ),
    "see_also": {
        "netsight://conventions/commits": "Commit message conventions.",
        "netsight://conventions/file_naming": "File and directory naming.",
        "netsight://conventions/test_patterns": "TDD and test organisation.",
        "netsight://docs/guides/developer-guide": (
            "Long-form narrative documentation for the same topics — "
            "recipes are the executive summary, this is the book."
        ),
    },
}


class RecipesHandler(ResourceHandler):
    # Template pattern so the registry routes both the index URI
    # (``netsight://recipes``) and per-recipe URIs
    # (``netsight://recipes/<name>``) to this handler. Same pattern used
    # by ConventionsHandler and the doc-fragment handlers.
    uri_pattern = "netsight://recipes{rest}"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        uris: list[dict[str, Any]] = [
            {
                "uri": "netsight://recipes",
                "name": "Implementation recipes index",
            }
        ]
        for path in _list_recipe_files():
            uris.append(
                {
                    "uri": f"netsight://recipes/{path.stem}",
                    "name": f"recipe: {path.stem}",
                }
            )
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://recipes":
            return self._build_index()
        name = uri.replace("netsight://recipes/", "", 1)
        if not name:
            return self._build_index()
        recipe = _load_recipe(name)
        if recipe is None:
            return {
                "error": f"Recipe not found: {name}",
                "available": sorted(p.stem for p in _list_recipe_files()),
            }
        return recipe

    def _build_index(self) -> dict[str, Any]:
        recipes = []
        for data in _load_all_recipes():
            recipes.append(
                {
                    "name": data.get("name", ""),
                    "title": data.get("title", ""),
                    "summary": data.get("summary", "").strip(),
                    "uri": f"netsight://recipes/{data.get('name', '')}",
                }
            )
        return {
            "recipes": recipes,
            "count": len(recipes),
            "_guidance": _INDEX_GUIDANCE,
        }


def register_all() -> None:
    """Register the recipes handler."""
    resource_registry.register(RecipesHandler())
