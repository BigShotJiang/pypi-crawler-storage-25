"""Resource handlers for patterns, relations, and exceptions."""

from __future__ import annotations

import inspect
from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry


class PatternsHandler(ResourceHandler):
    uri_pattern = "netsight://patterns"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Usage patterns"}]

    def get(self, uri: str, **params: Any) -> Any:
        from netsight.docs.patterns import get_builtin_patterns
        return [
            {
                "name": p.name,
                "description": p.description,
                "steps": [
                    {"operation": s.operation, "description": s.description}
                    for s in p.steps
                ],
            }
            for p in get_builtin_patterns()
        ]


class RelationsHandler(ResourceHandler):
    uri_pattern = "netsight://relations"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Operation relations"}]

    def get(self, uri: str, **params: Any) -> Any:
        from netsight.docs.relations import get_default_relation_graph
        graph = get_default_relation_graph()
        return [
            {"source": r.source, "target": r.target, "type": r.relation_type}
            for r in graph.all_relations()
        ]


class ExceptionsHandler(ResourceHandler):
    uri_pattern = "netsight://exceptions"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Exception hierarchy"}]

    def get(self, uri: str, **params: Any) -> Any:
        from netsight import exceptions as exc_module
        result = []
        for name in dir(exc_module):
            cls = getattr(exc_module, name)
            if inspect.isclass(cls) and issubclass(cls, Exception):
                result.append({
                    "name": name,
                    "parent": cls.__bases__[0].__name__ if cls.__bases__ else "Exception",
                    "docstring": inspect.getdoc(cls) or "",
                })
        return result


def register_all() -> None:
    resource_registry.register(PatternsHandler())
    resource_registry.register(RelationsHandler())
    resource_registry.register(ExceptionsHandler())
