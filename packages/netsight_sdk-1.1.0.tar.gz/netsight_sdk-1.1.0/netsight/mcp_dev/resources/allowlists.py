"""MCP resource handler for user allowlist browsing.

Exposes::

    netsight://allowlists               — index of all packs + allowlist summary
    netsight://allowlists/{pack}        — user's allowlist file + diff vs catalog
    netsight://allowlists/{pack}/catalog   — full pack catalog (read-only view)
    netsight://allowlists/{pack}/effective — final gated set (catalog ∩ allowlist)
"""

from __future__ import annotations

import tomllib
from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry


class AllowlistsHandler(ResourceHandler):
    """Resource handler for the ``netsight://allowlists`` namespace."""

    uri_pattern = "netsight://allowlists{rest}"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        """Return the index URI plus one URI per installed pack's allowlist.

        Returns
        -------
        list[dict[str, Any]]
            List of ``{"uri": ..., "name": ...}`` dicts.
        """
        uris: list[dict[str, Any]] = [
            {"uri": "netsight://allowlists", "name": "Allowlists index"},
        ]
        try:
            from netsight.packs.registry import pack_registry

            pack_registry.ensure_loaded()
            for pack_info in sorted(pack_registry.list(), key=lambda p: p.name):
                uris.append({
                    "uri": f"netsight://allowlists/{pack_info.name}",
                    "name": f"Allowlist: {pack_info.name}",
                })
        except Exception:  # noqa: BLE001
            pass
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        """Return content for the given URI.

        Parameters
        ----------
        uri:
            One of ``netsight://allowlists``,
            ``netsight://allowlists/{pack}``,
            ``netsight://allowlists/{pack}/catalog``, or
            ``netsight://allowlists/{pack}/effective``.

        Returns
        -------
        dict
            The resource payload.
        """
        if uri == "netsight://allowlists":
            return self._index()

        # Strip the prefix to get the rest of the path.
        rest = uri.removeprefix("netsight://allowlists/")
        if not rest:
            return self._index()

        parts = rest.split("/", 1)
        pack_name = parts[0]
        sub = parts[1] if len(parts) > 1 else ""

        if sub == "catalog":
            return self._pack_catalog(pack_name)
        if sub == "effective":
            return self._pack_effective(pack_name)
        if sub == "":
            return self._pack_detail(pack_name)

        return {"error": f"Unknown allowlists sub-resource: {uri!r}"}

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _index(self) -> dict[str, Any]:
        """Return the allowlists index."""
        from netsight.packs.allowlist import load_allowlist
        from netsight.packs.registry import pack_registry

        pack_registry.ensure_loaded()
        installed_packs = [p.name for p in sorted(pack_registry.list(), key=lambda p: p.name)]

        allowlists: dict[str, Any] = {}
        for pack_name in installed_packs:
            user = load_allowlist(pack_name)
            allowlists[pack_name] = {
                "enabled_count": len(user.enabled),
                "enabled": sorted(user.enabled),
                "pack_version": user.pack_version,
                "updated_at": user.updated_at,
            }

        return {
            "installed_packs": installed_packs,
            "allowlists": allowlists,
            "_guidance": {
                "what_this_is": (
                    "The user-managed allowlist index. Each installed pack has a "
                    "per-pack allowlist file in ~/.config/netsight/allowlists/. "
                    "Default state is deny-all (no file = no ops permitted). "
                    "Use 'netsight allowlist enable <pack> <op>' to grant access."
                ),
                "not_to_be_confused_with": (
                    "netsight://operations — that resource lists ALL catalog operations "
                    "regardless of whether they are enabled in the user allowlist. "
                    "This resource shows only what the USER has explicitly permitted."
                ),
                "next_steps": [
                    "Read netsight://allowlists/<pack> for the full diff vs catalog.",
                    "Read netsight://allowlists/<pack>/catalog for the raw catalog.",
                    "Read netsight://allowlists/<pack>/effective for the gated set.",
                    "Run 'netsight allowlist enable <pack> <op>' to enable an op.",
                    "Run 'netsight allowlist audit' to check for drift.",
                ],
                "see_also": {
                    "netsight://operations": "All catalog operations regardless of allowlist.",
                    "netsight://vendors": "Per-vendor config and device types.",
                },
            },
        }

    def _load_catalog(self, pack_name: str) -> dict[str, dict[str, Any]] | None:
        """Load the operations catalog for *pack_name*."""
        from netsight.packs.registry import pack_registry

        pack_registry.ensure_loaded()
        if not pack_registry.has(name=pack_name):
            return None
        pack_info = pack_registry.get(name=pack_name)

        ops_file = pack_info.config_root.joinpath("operations_catalog.toml")
        if not ops_file.is_file():
            ops_file = pack_info.config_root.joinpath("operations.toml")
        if not ops_file.is_file():
            return None

        try:
            raw = tomllib.loads(ops_file.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return None
        return {k: v for k, v in raw.items() if isinstance(v, dict)}

    def _pack_detail(self, pack_name: str) -> dict[str, Any]:
        """Return user allowlist contents plus diff against catalog."""
        from netsight.packs.allowlist import load_allowlist
        from netsight.packs.registry import pack_registry

        pack_registry.ensure_loaded()
        if not pack_registry.has(name=pack_name):
            return {"error": f"Pack {pack_name!r} is not installed"}

        catalog = self._load_catalog(pack_name) or {}
        user = load_allowlist(pack_name)

        enabled_in_catalog = user.enabled & set(catalog)
        orphaned = user.enabled - set(catalog)
        disabled = set(catalog) - user.enabled

        return {
            "pack": pack_name,
            "pack_version": user.pack_version,
            "updated_at": user.updated_at,
            "enabled": sorted(enabled_in_catalog),
            "disabled": sorted(disabled),
            "orphaned": sorted(orphaned),
            "enabled_count": len(enabled_in_catalog),
            "total_catalog": len(catalog),
        }

    def _pack_catalog(self, pack_name: str) -> dict[str, Any]:
        """Return the raw pack catalog."""
        from netsight.packs.registry import pack_registry

        pack_registry.ensure_loaded()
        if not pack_registry.has(name=pack_name):
            return {"error": f"Pack {pack_name!r} is not installed"}

        catalog = self._load_catalog(pack_name)
        if catalog is None:
            return {"error": f"Could not load catalog for {pack_name!r}"}

        return {
            "pack": pack_name,
            "catalog": catalog,
            "count": len(catalog),
        }

    def _pack_effective(self, pack_name: str) -> dict[str, Any]:
        """Return the final gated set (catalog ∩ user allowlist, read_only enforced)."""
        from netsight.packs.allowlist import load_allowlist
        from netsight.packs.registry import pack_registry

        pack_registry.ensure_loaded()
        if not pack_registry.has(name=pack_name):
            return {"error": f"Pack {pack_name!r} is not installed"}

        catalog = self._load_catalog(pack_name) or {}
        user = load_allowlist(pack_name)

        effective: dict[str, dict[str, Any]] = {}
        for op_name, op_config in catalog.items():
            if op_name not in user.enabled:
                continue
            if not op_config.get("read_only", False):
                continue
            effective[op_name] = op_config

        return {
            "pack": pack_name,
            "effective_operations": effective,
            "effective_count": len(effective),
            "catalog_count": len(catalog),
        }


def register_all() -> None:
    resource_registry.register(AllowlistsHandler())
