"""MCP resource handlers for the code development standards framework.

Exposes:
- ``netsight://standards`` — index of all standards
- ``netsight://standards/{name}`` — single standard detail
"""

from __future__ import annotations

import logging
from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry

logger = logging.getLogger(__name__)


class StandardsIndexHandler(ResourceHandler):
    """Handler for ``netsight://standards`` (index) and ``netsight://standards/{name}``."""

    uri_pattern = "netsight://standards"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        from netsight.standards import standards_registry

        uris: list[dict[str, Any]] = [
            {"uri": "netsight://standards", "name": "All code standards"}
        ]
        for s in standards_registry.list_standards():
            uris.append(
                {
                    "uri": f"netsight://standards/{s.name}",
                    "name": f"{s.name} ({s.severity})",
                }
            )
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        from netsight.standards import standards_registry

        if uri == "netsight://standards":
            standards = standards_registry.list_standards()
            return {
                "standards": [
                    {
                        "name": s.name,
                        "category": s.category,
                        "severity": s.severity,
                        "description": s.description.strip(),
                        "introduced": s.introduced,
                        "has_engine": bool(s.rule.get("engine")),
                    }
                    for s in standards
                ],
                "count": len(standards),
                "categories": standards_registry.list_categories(),
                "_guidance": {
                    "what_this_is": (
                        "The full catalogue of code development standards for the "
                        "NetSight SDK. Each standard is a YAML file under "
                        "netsight/standards/definitions/. Standards with "
                        "has_engine=true can be validated programmatically via "
                        "check_standards or netsight standards check; "
                        "documentation-only standards (has_engine=false) are "
                        "visible here and in the CLI but produce no findings."
                    ),
                    "next_steps": [
                        "Read netsight://standards/{name} to see a single "
                        "standard's full definition including examples.",
                        "Call check_standards to run validation against the "
                        "current codebase.",
                        "Run `netsight standards check` from the CLI for a "
                        "Rich table of results.",
                    ],
                    "see_also": {
                        "netsight://recipes/tests": (
                            "Canonical test patterns used by this codebase."
                        ),
                        "netsight://docs/guides/developer-guide": (
                            "Developer guide with architecture context."
                        ),
                    },
                },
            }

        # Single standard: netsight://standards/{name}
        name = uri.removeprefix("netsight://standards/")
        try:
            s = standards_registry.get_standard(name=name)
        except KeyError:
            return {"error": f"Standard not found: {name!r}"}

        return {
            "name": s.name,
            "category": s.category,
            "severity": s.severity,
            "description": s.description.strip(),
            "introduced": s.introduced,
            "scope": s.scope,
            "rule": s.rule,
            "has_engine": bool(s.rule.get("engine")),
            "positive_examples": s.positive_examples,
            "negative_examples": s.negative_examples,
            "related": s.related,
        }


def register_all() -> None:
    """Register all standards resource handlers."""
    resource_registry.register(StandardsIndexHandler())
    logger.debug("Standards resource handler registered: netsight://standards")
