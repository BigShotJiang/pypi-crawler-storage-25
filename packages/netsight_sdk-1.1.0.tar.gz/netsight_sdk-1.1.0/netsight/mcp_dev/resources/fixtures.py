"""Resource handler for test fixtures."""

from __future__ import annotations

from typing import Any

from netsight.mcp_dev.path_security import PROJECT_ROOT
from netsight.mcp_dev.resources import ResourceHandler, resource_registry

_FIXTURES_DIR = PROJECT_ROOT / "UNITTEST" / "fixtures"


class FixturesHandler(ResourceHandler):
    uri_pattern = "netsight://fixtures"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        uris = [{"uri": self.uri_pattern, "name": "Fixtures index"}]
        if not _FIXTURES_DIR.exists():
            return uris
        for vendor_dir in sorted(_FIXTURES_DIR.iterdir()):
            if not vendor_dir.is_dir():
                continue
            for fixture in sorted(vendor_dir.iterdir()):
                if fixture.is_file():
                    uris.append({
                        "uri": f"netsight://fixtures/{vendor_dir.name}/{fixture.stem}",
                        "name": f"{vendor_dir.name}/{fixture.name}",
                    })
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://fixtures":
            result: dict[str, list[str]] = {}
            if _FIXTURES_DIR.exists():
                for vendor_dir in sorted(_FIXTURES_DIR.iterdir()):
                    if vendor_dir.is_dir():
                        result[vendor_dir.name] = [
                            f.stem for f in sorted(vendor_dir.iterdir()) if f.is_file()
                        ]
            return result

        # Specific fixture
        path = uri.replace("netsight://fixtures/", "").split("/")
        if len(path) != 2:
            return {"error": "Invalid fixture URI"}
        vendor, name = path
        # Try common extensions
        for ext in (".xml", ".json", ".txt"):
            fixture_file = _FIXTURES_DIR / vendor / f"{name}{ext}"
            if fixture_file.exists():
                return {
                    "vendor": vendor,
                    "name": name,
                    "extension": ext,
                    "content": fixture_file.read_text(encoding="utf-8"),
                }
        return {"error": f"Fixture not found: {vendor}/{name}"}


def register_all() -> None:
    resource_registry.register(FixturesHandler())
