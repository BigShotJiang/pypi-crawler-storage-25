"""Resource handlers for documentation access.

Exposes user-facing documentation only — guides at ``docs/guides/`` and
``CHANGELOG.md`` at the project root. Internal AI planning artifacts under
``docs/superpowers/`` are intentionally NOT exposed via MCP.

Section-aware fetching
----------------------
Guides support a fragment syntax for retrieving partial content:

* ``netsight://docs/guides/user-guide`` — full file (default)
* ``netsight://docs/guides/user-guide#sections`` — list of section slugs
* ``netsight://docs/guides/user-guide#using-the-sdk`` — only that section

Slugs are derived from ATX heading text by lowercasing, replacing
non-alphanumeric runs with hyphens, and trimming. Section boundaries are
defined by the next heading at the same or shallower level (or EOF).
Fenced code blocks are skipped so ``# comment`` lines inside code do not
register as headings.
"""

from __future__ import annotations

import re
from typing import Any

from netsight.mcp_dev.path_security import PROJECT_ROOT
from netsight.mcp_dev.resources import ResourceHandler, resource_registry

_GUIDES_DIR = PROJECT_ROOT / "docs" / "guides"
_CHANGELOG = PROJECT_ROOT / "CHANGELOG.md"

# Match an ATX heading line: 1-6 leading hashes, space, title, optional
# trailing hashes (commonmark allows ``# Title #``).
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")
_SLUG_NONALNUM = re.compile(r"[^a-z0-9]+")


def _slugify(title: str) -> str:
    """Lowercase + collapse non-alphanumeric runs to hyphens."""
    return _SLUG_NONALNUM.sub("-", title.strip().lower()).strip("-")


def _parse_sections(content: str) -> list[dict[str, Any]]:
    """Parse a markdown document into a list of sections.

    Each section dict has ``level``, ``title``, ``slug``, ``line_start``
    (0-indexed line where the heading appears), and ``line_end``
    (0-indexed exclusive end). Section ends at the next heading at the
    same or shallower level, or at end-of-file.
    """
    lines = content.splitlines()
    headings: list[tuple[int, int, str]] = []  # (line_idx, level, title)
    in_fence = False

    for i, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        match = _HEADING_RE.match(line)
        if match:
            level = len(match.group(1))
            title = match.group(2).strip()
            headings.append((i, level, title))

    sections: list[dict[str, Any]] = []
    for idx, (line_idx, level, title) in enumerate(headings):
        end = len(lines)
        for next_line, next_level, _ in headings[idx + 1:]:
            if next_level <= level:
                end = next_line
                break
        sections.append({
            "level": level,
            "title": title,
            "slug": _slugify(title),
            "line_start": line_idx,
            "line_end": end,
        })
    return sections


def _extract_section(content: str, slug: str) -> str | None:
    """Return the markdown content of a section by slug, or None.

    On duplicate slugs, returns the first match.
    """
    lines = content.splitlines(keepends=True)
    for section in _parse_sections(content):
        if section["slug"] == slug:
            return "".join(lines[section["line_start"]:section["line_end"]])
    return None


class DocsIndexHandler(ResourceHandler):
    uri_pattern = "netsight://docs"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Documentation index"}]

    def get(self, uri: str, **params: Any) -> Any:
        return {
            "guides_count": len(list(_GUIDES_DIR.glob("*.md"))) if _GUIDES_DIR.exists() else 0,
            "changelog_exists": _CHANGELOG.exists(),
        }


class GuidesHandler(ResourceHandler):
    # Template pattern so the registry's prefix match routes both the
    # index URI (``netsight://docs/guides``) and per-guide URIs
    # (``netsight://docs/guides/<name>``) to this handler.
    uri_pattern = "netsight://docs/guides{name}"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        uris = [{"uri": "netsight://docs/guides", "name": "Guides index"}]
        if _GUIDES_DIR.exists():
            for guide in sorted(_GUIDES_DIR.glob("*.md")):
                uris.append({
                    "uri": f"netsight://docs/guides/{guide.stem}",
                    "name": guide.stem,
                })
        return uris

    def get(self, uri: str, **params: Any) -> Any:
        if uri == "netsight://docs/guides":
            if not _GUIDES_DIR.exists():
                return []
            return [
                {"name": p.stem, "size": p.stat().st_size}
                for p in sorted(_GUIDES_DIR.glob("*.md"))
            ]

        # Split off optional ``#fragment`` for section-aware fetching.
        base, _, fragment = uri.partition("#")
        name = base.replace("netsight://docs/guides/", "")
        guide_file = _GUIDES_DIR / f"{name}.md"
        if not guide_file.exists():
            return {"error": f"Guide not found: {name}"}

        content = guide_file.read_text(encoding="utf-8")

        if not fragment:
            # Default: full file (preserves original behaviour).
            return {"name": name, "content": content}

        if fragment == "sections":
            # Lightweight TOC: just slugs/titles/levels — no body content.
            sections = _parse_sections(content)
            return {
                "name": name,
                "sections": [
                    {
                        "slug": s["slug"],
                        "title": s["title"],
                        "level": s["level"],
                    }
                    for s in sections
                ],
            }

        # Single-section fetch.
        section_content = _extract_section(content, fragment)
        if section_content is None:
            return {"error": f"Section not found: {fragment}"}
        return {
            "name": name,
            "section": fragment,
            "content": section_content,
        }


class ChangelogHandler(ResourceHandler):
    uri_pattern = "netsight://docs/changelog"
    strategy = "full"

    def list_uris(self) -> list[dict[str, Any]]:
        return [{"uri": self.uri_pattern, "name": "Changelog"}]

    def get(self, uri: str, **params: Any) -> Any:
        if not _CHANGELOG.exists():
            return {"error": "CHANGELOG.md not found"}
        return {"content": _CHANGELOG.read_text(encoding="utf-8")}


def register_all() -> None:
    """Register doc handlers."""
    resource_registry.register(DocsIndexHandler())
    resource_registry.register(GuidesHandler())
    resource_registry.register(ChangelogHandler())
