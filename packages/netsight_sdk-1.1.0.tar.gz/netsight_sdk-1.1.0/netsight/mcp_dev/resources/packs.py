"""MCP resource handler for the ``netsight://packs`` namespace.

Exposes installed pack metadata and the bundled pack index to AI
assistants via the ``netsight://packs{rest}`` URI family:

``netsight://packs``
    Index of installed packs + available index entries + load errors.

``netsight://packs/available``
    Entries from the bundled ``_index.toml`` (curated pack catalogue).

``netsight://packs/{name}``
    Detail for a single pack — installed metadata and/or index entry.

``netsight://packs/{name}/parsers/{op}``
    Raw YAML content of one parser spec shipped in the pack.

The legacy ``netsight://vendors{rest}`` URIs remain alive in
``vendors.py`` as deprecation aliases that return the same data shape.
"""

from __future__ import annotations

import logging
from typing import Any

from netsight.mcp_dev.resources import ResourceHandler, resource_registry
from netsight.packs.registry import pack_registry
from netsight.packs.index import load_index

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Guidance blocks
# ---------------------------------------------------------------------------

_INDEX_GUIDANCE = {
    "what_this_is": (
        "The pack index and installed-pack catalogue for the NetSight SDK. "
        "'installed' lists every pack registered in the live pack_registry; "
        "'available' lists every entry in the bundled _index.toml. "
        "A pack may appear in both (installed and indexed), only in one "
        "(installed but not in the curated index, or indexed but not yet "
        "installed), or — for load errors — as a name with a failure message."
    ),
    "not_to_be_confused_with": (
        "netsight://vendors — that namespace is a deprecated alias that "
        "returns the same installed-pack data in the legacy 'vendor' shape. "
        "Prefer netsight://packs for new tooling. "
        "netsight://registries/plugins — that lists Python plugin classes "
        "registered in the plugin_registry, not pack metadata."
    ),
    "next_steps": [
        "Read netsight://packs/available to see the full bundled index.",
        "Read netsight://packs/{name} for detail on a specific pack.",
        "Read netsight://packs/{name}/parsers/{op} for a parser spec.",
        "Run 'netsight pack install <name>' to install an indexed pack.",
        "Run 'netsight pack doctor' to validate all installed pack configs.",
    ],
    "see_also": {
        "netsight://vendors": "Deprecated alias — same data, legacy shape.",
        "netsight://registries/plugins": "Python plugin classes (not pack metadata).",
        "netsight://operations": "All allowlisted operations across all packs.",
    },
}


# ---------------------------------------------------------------------------
# Helper: load pack registry safely
# ---------------------------------------------------------------------------


def _installed_packs() -> list[Any]:
    """Return list of PackInfo from the live registry."""
    try:
        return pack_registry.list()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not access pack_registry: %s", exc)
        return []


def _load_errors() -> dict[str, Exception]:
    """Return load-error mapping from the live registry."""
    try:
        return pack_registry.load_errors()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not read pack_registry load_errors: %s", exc)
        return {}


def _index_entries() -> dict[str, Any]:
    """Return the merged bundled + user index as a dict of IndexEntry."""
    try:
        return load_index()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not load pack index: %s", exc)
        return {}


# ---------------------------------------------------------------------------
# PacksHandler
# ---------------------------------------------------------------------------


class PacksHandler(ResourceHandler):
    """Handle all ``netsight://packs{rest}`` URIs.

    Dispatches on the captured ``{rest}`` suffix:

    * ``""`` or ``"/"``     → index
    * ``"/available"``      → bundled index entries
    * ``"/{name}"``         → pack detail (installed + index)
    * ``"/{name}/parsers/{op}"`` → parser spec YAML
    """

    uri_pattern = "netsight://packs{rest}"
    strategy = "two_tier"

    def list_uris(self) -> list[dict[str, Any]]:
        """Return all URIs exposed by this handler.

        Returns
        -------
        list[dict[str, Any]]
            Each entry has ``uri`` and ``name`` keys.
        """
        uris: list[dict[str, Any]] = [
            {"uri": "netsight://packs", "name": "Pack index"},
            {"uri": "netsight://packs/available", "name": "Available packs (bundled index)"},
        ]

        # One URI per installed pack.
        for info in sorted(_installed_packs(), key=lambda p: p.name):
            uris.append({
                "uri": f"netsight://packs/{info.name}",
                "name": info.name,
            })

        # One URI per index entry that is NOT already installed.
        installed_names = {info.name for info in _installed_packs()}
        for name in sorted(_index_entries()):
            if name not in installed_names:
                uris.append({
                    "uri": f"netsight://packs/{name}",
                    "name": f"{name} (available, not installed)",
                })

        return uris

    def get(self, uri: str, **params: Any) -> Any:
        """Dispatch a ``netsight://packs{rest}`` URI to the correct handler.

        Parameters
        ----------
        uri:
            The full resource URI.
        **params:
            Not used; accepted for interface compatibility.

        Returns
        -------
        Any
            A dict with the resource content, or an error dict.
        """
        rest = uri[len("netsight://packs"):]

        # Bare index: netsight://packs  or  netsight://packs/
        if rest in ("", "/"):
            return self._handle_index()

        # Available index: netsight://packs/available
        if rest == "/available":
            return self._handle_available()

        # Strip leading slash for sub-path routing.
        if rest.startswith("/"):
            rest = rest[1:]

        # Parser spec: netsight://packs/{name}/parsers/{op}
        parts = rest.split("/")
        if len(parts) == 3 and parts[1] == "parsers":
            return self._handle_parser_spec(pack_name=parts[0], op_name=parts[2])

        # Pack detail: netsight://packs/{name}
        if len(parts) == 1 and parts[0]:
            return self._handle_detail(pack_name=parts[0])

        return {"error": f"Unrecognised packs URI: {uri}"}

    # ------------------------------------------------------------------
    # Sub-handlers
    # ------------------------------------------------------------------

    def _handle_index(self) -> dict[str, Any]:
        """Return the bare packs index."""
        installed = _installed_packs()
        index = _index_entries()
        errors = _load_errors()

        installed_list = [
            {
                "name": info.name,
                "vendor": info.vendor,
                "device_type": info.device_type,
                "protocol": info.protocol,
                "version": info.version,
                "distribution": info.distribution,
                "uri": f"netsight://packs/{info.name}",
            }
            for info in sorted(installed, key=lambda p: p.name)
        ]

        available_list = [
            {
                "name": name,
                "description": entry.description,
                "status": entry.status,
                "uri": f"netsight://packs/{name}",
            }
            for name, entry in sorted(index.items())
        ]

        load_errors_list = [
            {"name": name, "error": f"{type(exc).__name__}: {exc}"}
            for name, exc in sorted(errors.items())
        ]

        return {
            "installed": installed_list,
            "available": available_list,
            "load_errors": load_errors_list,
            "_guidance": _INDEX_GUIDANCE,
        }

    def _handle_available(self) -> dict[str, Any]:
        """Return the bundled index as a list of dicts."""
        index = _index_entries()
        entries = [
            {
                "name": name,
                "repo": entry.repo,
                "subdirectory": entry.subdirectory,
                "description": entry.description,
                "status": entry.status,
                "min_sdk": entry.min_sdk,
                "maintainers": list(entry.maintainers),
            }
            for name, entry in sorted(index.items())
        ]
        return {"packs": entries, "count": len(entries)}

    def _handle_detail(self, pack_name: str) -> dict[str, Any]:
        """Return combined installed + index detail for *pack_name*."""
        result: dict[str, Any] = {"name": pack_name}

        # Installed info.
        try:
            if pack_registry.has(name=pack_name):
                info = pack_registry.get(name=pack_name)
                result["installed"] = {
                    "vendor": info.vendor,
                    "device_type": info.device_type,
                    "protocol": info.protocol,
                    "distribution": info.distribution,
                    "version": info.version,
                    "config_root": str(info.config_root),
                    "metadata": info.metadata,
                }
        except Exception as exc:  # noqa: BLE001
            result["installed_error"] = str(exc)

        # Index entry (uses module-level load_index via _index_entries).
        index = _index_entries()
        entry = index.get(pack_name)
        if entry is not None:
            result["index"] = {
                "description": entry.description,
                "status": entry.status,
                "repo": entry.repo,
                "subdirectory": entry.subdirectory,
                "min_sdk": entry.min_sdk,
                "maintainers": list(entry.maintainers),
            }

        if "installed" not in result and "index" not in result:
            return {"error": f"Pack not found: {pack_name!r}"}

        return result

    def _handle_parser_spec(self, pack_name: str, op_name: str) -> dict[str, Any]:
        """Return the raw YAML content of a parser spec from a pack.

        Parameters
        ----------
        pack_name:
            The pack whose parsers directory to search.
        op_name:
            The operation name (without ``.yaml`` extension).

        Returns
        -------
        dict[str, Any]
            ``{"uri": ..., "content": ..., "format": "yaml"}`` or an error dict.
        """
        try:
            if not pack_registry.has(name=pack_name):
                return {"error": f"Pack not installed: {pack_name!r}"}

            info = pack_registry.get(name=pack_name)
            spec_path = info.config_root.joinpath("parsers", f"{op_name}.yaml")
            if not spec_path.is_file():
                return {"error": f"Parser spec not found: {pack_name}/{op_name}"}

            content = spec_path.read_text(encoding="utf-8")
            return {
                "uri": f"netsight://packs/{pack_name}/parsers/{op_name}",
                "content": content,
                "format": "yaml",
            }
        except Exception as exc:  # noqa: BLE001
            return {"error": f"Failed to read parser spec: {exc}"}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_all() -> None:
    """Register the packs handler."""
    resource_registry.register(PacksHandler())
