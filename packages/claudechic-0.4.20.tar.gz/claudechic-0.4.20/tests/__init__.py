"""Tests for Claude Chic."""
