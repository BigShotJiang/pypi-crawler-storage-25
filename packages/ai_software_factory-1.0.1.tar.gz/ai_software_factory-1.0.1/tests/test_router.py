"""Tests for model router."""

import pytest
from unittest.mock import Mock, patch, MagicMock

from ai_software_factory.router.model_router import ModelRouter
from ai_software_factory.memory.semantic_cache import SemanticCache


class TestModelRouter:
    """Test model routing and cost tracking."""

    @pytest.fixture
    def mock_cache(self):
        cache = Mock(spec=SemanticCache)
        cache.check_cache = Mock(return_value=None)
        cache.store_result = Mock()
        return cache

    @patch('router.model_router.OpenAI')
    def test_route_request_success(self, mock_openai, mock_cache):
        """Test successful request routing."""
        mock_client = Mock()
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content="test response"))]
        mock_response.usage = Mock(prompt_tokens=10, completion_tokens=5)
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        router = ModelRouter("test_session", mock_cache)
        result = router.route_request("planning", "test prompt")
        
        assert result["response"] == "test response"
        assert result["cache_hit"] is False
        assert "tokens" in result

    @patch('router.model_router.OpenAI')
    def test_cache_hit_returns_cached_result(self, mock_openai, mock_cache):
        """Test cache hit returns stored result."""
        mock_cache.check_cache = Mock(return_value={
            "response": "cached response",
            "cache_hit": True
        })
        
        router = ModelRouter("test_session", mock_cache)
        result = router.route_request("planning", "test prompt")
        
        assert result["cache_hit"] is True
        assert result["response"] == "cached response"
        mock_openai.return_value.chat.completions.create.assert_not_called()

    def test_cost_calculation(self):
        """Test cost calculation for different models."""
        with patch('router.model_router.OpenAI'):
            router = ModelRouter("test_session")
            
            # Test DeepSeek pricing
            cost = router._calculate_cost(1000, 500, "deepseek/deepseek-chat")
            assert cost > 0
            
            # Verify cost is reasonable (should be very small for these token counts)
            assert cost < 0.01

    def test_token_counting(self):
        """Test token counting functionality."""
        with patch('router.model_router.OpenAI'):
            router = ModelRouter("test_session")
            
            tokens = router._count_tokens("Hello world", "gpt-4")
            assert tokens > 0
            assert isinstance(tokens, int)

    def test_cost_estimate(self):
        """Test cost estimation for task types."""
        with patch('router.model_router.OpenAI'):
            router = ModelRouter("test_session")
            
            estimate = router.get_cost_estimate("planning", 1000)
            assert estimate >= 0
            assert isinstance(estimate, float)

    @patch('router.model_router.metrics_collector')
    @patch('router.model_router.OpenAI')
    def test_metrics_recording(self, mock_openai, mock_metrics, mock_cache):
        """Test that metrics are recorded for LLM calls."""
        mock_client = Mock()
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content="response"))]
        mock_response.usage = Mock(prompt_tokens=10, completion_tokens=5)
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        mock_session = Mock()
        mock_metrics.get_session.return_value = mock_session
        
        router = ModelRouter("test_session", mock_cache)
        router.route_request("planning", "test")
        
        mock_metrics.record_llm_call.assert_called()
