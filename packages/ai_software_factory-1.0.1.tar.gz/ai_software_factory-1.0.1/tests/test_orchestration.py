"""Tests for workflow orchestration."""

import pytest
from unittest.mock import Mock, patch, MagicMock

from ai_software_factory.orchestrator.workflow_graph import WorkflowOrchestrator, WorkflowState


class TestWorkflowOrchestrator:
    """Test LangGraph workflow orchestration."""

    @pytest.fixture
    def orchestrator(self):
        """Create orchestrator with mocked components."""
        with patch('orchestrator.workflow_graph.ModelRouter'):
            with patch('orchestrator.workflow_graph.SemanticCache'):
                with patch('orchestrator.workflow_graph.ArchitectAgent'):
                    with patch('orchestrator.workflow_graph.DeveloperAgent'):
                        with patch('orchestrator.workflow_graph.AuditorAgent'):
                            with patch('orchestrator.workflow_graph.SupervisorAgent'):
                                yield WorkflowOrchestrator("test_session")

    def test_workflow_initialization(self, orchestrator):
        """Test workflow initializes correctly."""
        assert orchestrator.session_id == "test_session"
        assert orchestrator.workflow is not None

    def test_route_after_audit_pass(self, orchestrator):
        """Test routing when audit passes."""
        state = {
            "audit_result": {"status": "pass"},
            "debug_cycles": 0
        }
        
        route = orchestrator._route_after_audit(state)
        assert route == "pass"

    def test_route_after_audit_fail_low_cycles(self, orchestrator):
        """Test routing when audit fails with low debug cycles."""
        state = {
            "audit_result": {
                "status": "fail",
                "failure_type": "TestFailure"
            },
            "debug_cycles": 1
        }
        
        route = orchestrator._route_after_audit(state)
        assert route == "retry_developer"

    def test_route_after_audit_fail_high_cycles(self, orchestrator):
        """Test routing when audit fails with high debug cycles."""
        state = {
            "audit_result": {"status": "fail"},
            "debug_cycles": 3
        }
        
        route = orchestrator._route_after_audit(state)
        assert route == "supervisor"

    def test_route_after_audit_architecture_failure(self, orchestrator):
        """Test routing for architecture failures."""
        state = {
            "audit_result": {
                "status": "fail",
                "failure_type": "ArchitectureError"
            },
            "debug_cycles": 0
        }
        
        route = orchestrator._route_after_audit(state)
        assert route == "revise_plan"

    def test_route_after_supervisor_retry(self, orchestrator):
        """Test supervisor routing for retry decision."""
        state = {"supervisor_decision": "retry_developer"}
        
        route = orchestrator._route_after_supervisor(state)
        assert route == "retry_developer"

    def test_route_after_supervisor_escalate(self, orchestrator):
        """Test supervisor routing for escalation."""
        state = {"supervisor_decision": "escalate_to_human"}
        
        route = orchestrator._route_after_supervisor(state)
        assert route == "escalate_to_human"

    @patch.object(WorkflowOrchestrator, '_build_workflow')
    def test_execute_workflow_success(self, mock_build, orchestrator):
        """Test successful workflow execution."""
        mock_graph = Mock()
        mock_graph.invoke = Mock(return_value={
            "user_input": "test",
            "final_status": None,
            "error": None,
            "requires_human_review": False,
            "generated_files": ["file1.py"]
        })
        mock_build.return_value = mock_graph
        
        result = orchestrator.execute("test prompt")
        
        assert result["final_status"] == "success"
        mock_graph.invoke.assert_called_once()

    @patch.object(WorkflowOrchestrator, '_build_workflow')
    def test_execute_workflow_error(self, mock_build, orchestrator):
        """Test workflow execution with error."""
        mock_graph = Mock()
        mock_graph.invoke = Mock(return_value={
            "user_input": "test",
            "error": "Something went wrong",
            "generated_files": []
        })
        mock_build.return_value = mock_graph
        
        result = orchestrator.execute("test prompt")
        
        assert result["final_status"] == "failed"
        assert result["error"] == "Something went wrong"

    @patch.object(WorkflowOrchestrator, '_build_workflow')
    def test_execute_workflow_human_review(self, mock_build, orchestrator):
        """Test workflow requiring human review."""
        mock_graph = Mock()
        mock_graph.invoke = Mock(return_value={
            "user_input": "test",
            "requires_human_review": True,
            "error": None,
            "generated_files": []
        })
        mock_build.return_value = mock_graph
        
        result = orchestrator.execute("test prompt")
        
        assert result["final_status"] == "requires_human_review"
