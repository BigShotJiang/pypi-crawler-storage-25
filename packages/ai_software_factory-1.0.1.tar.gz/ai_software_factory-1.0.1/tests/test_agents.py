"""Tests for agent hierarchy."""

import pytest
from unittest.mock import Mock, MagicMock, patch

from ai_software_factory.agents.architect_agent import ArchitectAgent
from ai_software_factory.agents.developer_agent import DeveloperAgent
from ai_software_factory.agents.auditor_agent import AuditorAgent, AuditResult
from ai_software_factory.agents.supervisor_agent import SupervisorAgent
from ai_software_factory.agents import ArchitectPlan, TaskDefinition


class TestArchitectAgent:
    """Test Architect Agent functionality."""

    @pytest.fixture
    def mock_model_router(self):
        router = Mock()
        router.route_request = Mock(return_value={
            "response": '{"project_name": "test", "tech_stack": ["python"], "architecture": "monolith", "services": [], "database_schema": [], "tasks": []}',
            "tokens": {"prompt": 100, "completion": 50},
            "cost": 0.001,
        })
        return router

    def test_architect_executes_successfully(self, mock_model_router):
        """Test architect agent creates valid plan."""
        agent = ArchitectAgent(mock_model_router, "test_session")
        
        state = {"user_input": "Build a simple API"}
        result = agent.execute(state)
        
        assert result["current_step"] == "architect_complete"
        assert "architect_plan" in result
        assert result["architect_plan"]["project_name"] == "test"

    def test_architect_handles_missing_input(self, mock_model_router):
        """Test architect handles missing user input."""
        agent = ArchitectAgent(mock_model_router, "test_session")
        
        state = {}
        result = agent.execute(state)
        
        assert "error" in result


class TestDeveloperAgent:
    """Test Developer Agent functionality."""

    @pytest.fixture
    def mock_model_router(self):
        return Mock()

    def test_developer_requires_architect_plan(self, mock_model_router):
        """Test developer fails without architect plan."""
        agent = DeveloperAgent(mock_model_router, "test_session")
        
        state = {}
        result = agent.execute(state)
        
        assert "error" in result
        assert "Missing architect plan" in result["error"]


class TestAuditorAgent:
    """Test Auditor Agent functionality."""

    @pytest.fixture
    def mock_model_router(self):
        return Mock()

    def test_auditor_handles_no_files(self, mock_model_router):
        """Test auditor handles missing generated files."""
        agent = AuditorAgent(mock_model_router, "test_session")
        
        state = {"generated_files": []}
        result = agent.execute(state)
        
        assert result["audit_result"]["status"] == "fail"
        assert result["audit_result"]["failure_type"] == "NoFilesGenerated"


class TestSupervisorAgent:
    """Test Supervisor Agent functionality."""

    @pytest.fixture
    def mock_model_router(self):
        return Mock()

    def test_supervisor_detects_max_retries(self, mock_model_router):
        """Test supervisor detects excessive debug cycles."""
        agent = SupervisorAgent(mock_model_router, "test_session")
        
        state = {
            "debug_cycles": 3,
            "audit_result": {"status": "fail"}
        }
        result = agent.execute(state)
        
        assert result["supervisor_decision"] == "escalate_to_human"
        assert result["requires_human_review"] is True

    def test_supervisor_continues_on_success(self, mock_model_router):
        """Test supervisor allows continuation on success."""
        agent = SupervisorAgent(mock_model_router, "test_session")
        
        state = {
            "debug_cycles": 0,
            "audit_result": {"status": "pass"}
        }
        result = agent.execute(state)
        
        assert result["supervisor_decision"] == "continue"

    def test_supervisor_intervention_strategies(self, mock_model_router):
        """Test supervisor determines correct intervention strategy."""
        agent = SupervisorAgent(mock_model_router, "test_session")
        
        # Test architecture failure
        intervention = agent._determine_intervention(
            "ArchitectureError",
            "Bad design",
            0
        )
        assert intervention["decision"] == "revise_plan"
        
        # Test dependency failure
        intervention = agent._determine_intervention(
            "DependencyError",
            "Missing package",
            0
        )
        assert intervention["decision"] == "retry_developer"
