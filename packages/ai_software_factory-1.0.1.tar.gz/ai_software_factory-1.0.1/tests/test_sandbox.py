"""Tests for Docker sandbox executor."""

import pytest
from unittest.mock import Mock, MagicMock, patch

from ai_software_factory.sandbox.docker_executor import SandboxExecutor, ExecutionResult


class TestSandboxExecutor:
    """Test sandbox execution with Docker."""

    @patch('sandbox.docker_executor.docker')
    def test_sandbox_creates_container(self, mock_docker):
        """Test sandbox creates container with correct settings."""
        mock_client = Mock()
        mock_container = Mock()
        mock_container.short_id = "abc123"
        mock_client.containers.run.return_value = mock_container
        mock_docker.from_env.return_value = mock_client
        
        executor = SandboxExecutor()
        executor._create_container()
        
        assert executor.container is not None
        mock_client.containers.run.assert_called_once()

    @patch('sandbox.docker_executor.docker')
    def test_execute_command_in_sandbox(self, mock_docker):
        """Test command execution in sandbox."""
        mock_client = Mock()
        mock_container = Mock()
        mock_container.exec_run.return_value = Mock(
            exit_code=0,
            output=(b"stdout", b"stderr")
        )
        mock_client.containers.run.return_value = mock_container
        mock_docker.from_env.return_value = mock_client
        
        executor = SandboxExecutor()
        result = executor.execute_command("echo test")
        
        assert isinstance(result, ExecutionResult)
        assert result.exit_code == 0
        assert result.stdout == "stdout"

    def test_sandbox_cleanup(self):
        """Test sandbox cleanup removes resources."""
        with patch('sandbox.docker_executor.docker') as mock_docker:
            mock_client = Mock()
            mock_container = Mock()
            mock_client.containers.run.return_value = mock_container
            mock_docker.from_env.return_value = mock_client
            
            executor = SandboxExecutor()
            executor._create_container()
            executor.cleanup()
            
            mock_container.stop.assert_called_once()
            mock_container.remove.assert_called_once()

    def test_copy_files_to_sandbox_dict_format(self):
        """Test copying files to sandbox using dict format."""
        with patch('sandbox.docker_executor.docker'):
            executor = SandboxExecutor()
            
            files = {
                "test.py": "print('hello')",
                "src/main.py": "print('world')"
            }
            executor.copy_files_to_sandbox(files)
            
            # Files should be written to temp directory
            import os
            assert os.path.exists(os.path.join(executor.temp_dir, "test.py"))
