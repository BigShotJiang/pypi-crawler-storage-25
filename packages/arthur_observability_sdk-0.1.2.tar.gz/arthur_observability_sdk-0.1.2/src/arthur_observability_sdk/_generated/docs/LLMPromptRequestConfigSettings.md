# LLMPromptRequestConfigSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timeout** | **float** |  | [optional] 
**temperature** | **float** |  | [optional] 
**top_p** | **float** |  | [optional] 
**max_tokens** | **int** |  | [optional] 
**stop** | **str** |  | [optional] 
**presence_penalty** | **float** |  | [optional] 
**frequency_penalty** | **float** |  | [optional] 
**seed** | **int** |  | [optional] 
**logprobs** | **bool** |  | [optional] 
**top_logprobs** | **int** |  | [optional] 
**logit_bias** | [**List[LogitBiasItem]**](LogitBiasItem.md) |  | [optional] 
**max_completion_tokens** | **int** |  | [optional] 
**reasoning_effort** | [**ReasoningEffortEnum**](ReasoningEffortEnum.md) |  | [optional] 
**thinking** | [**AnthropicThinkingParam**](AnthropicThinkingParam.md) |  | [optional] 
**response_format** | [**LLMResponseFormatInput**](LLMResponseFormatInput.md) |  | [optional] 
**tool_choice** | [**ToolChoice**](ToolChoice.md) |  | [optional] 
**stream_options** | [**StreamOptions**](StreamOptions.md) |  | [optional] 

## Example

```python
from arthur_observability_sdk._generated.models.llm_prompt_request_config_settings import LLMPromptRequestConfigSettings

# TODO update the JSON string below
json = "{}"
# create an instance of LLMPromptRequestConfigSettings from a JSON string
llm_prompt_request_config_settings_instance = LLMPromptRequestConfigSettings.from_json(json)
# print the JSON string representation of the object
print(LLMPromptRequestConfigSettings.to_json())

# convert the object into a dict
llm_prompt_request_config_settings_dict = llm_prompt_request_config_settings_instance.to_dict()
# create an instance of LLMPromptRequestConfigSettings from a dict
llm_prompt_request_config_settings_from_dict = LLMPromptRequestConfigSettings.from_dict(llm_prompt_request_config_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


