# Source

Source of the variable value

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | Type of source: &#39;dataset_column&#39; | 
**dataset_column** | [**DatasetColumnSource**](DatasetColumnSource.md) | Dataset column source | 
**experiment_output** | [**TransformVariableExperimentOutputSource**](TransformVariableExperimentOutputSource.md) | Experiment output source (only transform variables supported) | 

## Example

```python
from arthur_observability_sdk._generated.models.source import Source

# TODO update the JSON string below
json = "{}"
# create an instance of Source from a JSON string
source_instance = Source.from_json(json)
# print the JSON string representation of the object
print(Source.to_json())

# convert the object into a dict
source_dict = source_instance.to_dict()
# create an instance of Source from a dict
source_from_dict = Source.from_dict(source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


