"""
step-distill: Distill verifiable chain-of-thought reasoning into small language models
via hierarchical step supervision.

https://github.com/ductaiphan/step-distill
"""

__version__ = "0.1.6"

# ── Core ────────────────────────────────────────────────────────────────
from step_distill.core.parser import LabelMatrixParser
from step_distill.core.loss import StepAwareLoss
from step_distill.core.trainer import StepAwareTrainer
from step_distill.core.inference import NanoReason, ReasoningResult
from step_distill.core.metrics import (
    AccuracyMetric,
    RFSMetric,
    SVRMetric,
    Evaluator,
    EvalResults,
)

# ── Config ──────────────────────────────────────────────────────────────
from step_distill.config.config import StepDistillConfig  # noqa: E402

# ── Data ────────────────────────────────────────────────────────────────
from step_distill.data.pipeline import TeacherPipeline
from step_distill.data.sources import GSM8KSource, MATHSource, VNHSGESource

__all__ = [
    # Core
    "NanoReason",
    "ReasoningResult",
    "LabelMatrixParser",
    "StepAwareLoss",
    "StepAwareTrainer",
    # Metrics
    "AccuracyMetric",
    "RFSMetric",
    "SVRMetric",
    "Evaluator",
    "EvalResults",
    # Config
    "StepDistillConfig",
    # Data
    "TeacherPipeline",
    "GSM8KSource",
    "MATHSource",
    "VNHSGESource",
]
