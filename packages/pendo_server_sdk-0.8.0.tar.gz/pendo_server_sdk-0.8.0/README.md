# python-sdk

A lightweight Python SDK that instruments AI agents with OpenTelemetry tracing via a single `init()` call. It wires up a
`TracerProvider`, `BatchSpanProcessor`, and custom `PendoSpanExporter` that exports completed spans to Pendo's ingestion
pipeline (`data/agenticsdk`) over OTLP HTTP.

Supports automatic PII redaction (email, phone, SSN) before network export, Pendo identity injection (visitor/account),
and auto-patching of supported LLM client libraries (Anthropic, OpenAI, LangChain, Pydantic AI).

## Quick start

```python
import pendo_sdk

pendo_sdk.init(
    api_key="your-pendo-api-key",
    agent_id="support-bot",
)
```

Both `api_key` and `agent_id` are required. The SDK monkey-patches supported LLM clients on init, so traces show up
automatically — no further code changes needed in the happy path.

## init() parameters

| Param               | Required | Default                | Purpose                                                                                                                                                                                                                                                              |
|---------------------|----------|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `api_key`           | yes      | —                      | Pendo integration key. Sent as `X-API-Key` on export.                                                                                                                                                                                                                |
| `agent_id`          | yes      | —                      | Stable identifier for *this* agent. Stamped on every event as `props.agentId`. Used by Pendo to group traces, conversations, and reactions per agent in analytics. Pick a stable string (`"support-bot"`, `"sales-copilot"`) and keep it consistent across deploys.  |
| `project_id`        | no       | `"default"`            | Maps to OTel Resource `service.name`. Useful for grouping multiple SDK instances in a multi-agent system at the OTel level. Defaults to "default". Distinct from `agent_id`: `project_id` is the subscription ID, while `agent_id` is the Pendo agent analytics key. |
| `redact`            | no       | `False`                | Enable PII redaction (email/phone/SSN) on event content before network export.                                                                                                                                                                                       |
| `visitor_id`        | no       | `None`                 | Pendo visitor ID. Stamped on every span as `pendo.visitor_id`. Identifies the end user. (normally user email)                                                                                                                                                        |
| `account_id`        | no       | `None`                 | Pendo account ID. Stamped on every span as `pendo.account_id`. Identifies the tenant.                                                                                                                                                                                |
| `endpoint`          | no       | `https://app.pendo.io` | Pendo *ingestion* base URL — where events are POSTed. Only override for non-prod stacks (eu, dev, stage). The SDK appends `/data/agenticsdk/<api_key>`.                                                                                                              |
| `url`               | no       | `None`                 | Per-event metadata tag stamped on every event as `props.url`. Describes *where the agent runs* (e.g. `"https://app.customer.com"`) — purely informational. **Not** a substitute for `endpoint`.                                                                      |
| `auto_patch`        | no       | `True`                 | Monkey-patch supported LLM client libraries at init time. Set `False` to instrument manually.                                                                                                                                                                        |
| `batch_size`        | no       | `512`                  | Max spans per export batch.                                                                                                                                                                                                                                          |
| `flush_interval_ms` | no       | `2000`                 | How often the BatchSpanProcessor flushes buffered spans.                                                                                                                                                                                                             |

### `endpoint` vs `url`

These names look similar but do completely different things:

- **`endpoint`** is the *network destination* — the Pendo ingestion host that receives events. Almost everyone leaves
  this at the default.
- **`url`** is *event metadata* — a string tag stamped on every event so you can filter analytics by deployment /
  environment / customer-facing host. It has no effect on where data is sent.

## Full example

```python
import pendo_sdk

pendo_sdk.init(
  api_key="pndo_live_…",
  agent_id="support-bot",
  project_id="support-bot",
  visitor_id="user@customer.com",
  account_id="customer-tenant-42",
  redact=True,
  url="https://app.customer.com",  # metadata where the events happened
  endpoint="https://app.pendo.io",  # this gets /data/agenticsdk/<api_key> appended to it
)
```

## Releasing

See the release runbook in Confluence: https://pendo-io.atlassian.net/wiki/spaces/ENG/pages/4841275444/Releasing+the+Python+SDK+to+PyPi

TL;DR: bump `version` in `pyproject.toml`, merge to `main`, and `.github/workflows/release.yml` tags the commit and publishes to PyPI automatically via Trusted Publishers (no token needed).
