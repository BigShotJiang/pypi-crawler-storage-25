"""
LangChain Callback Handler for Pendo SDK

Creates OTel spans from LangChain callbacks. Every LLM call, tool call,
and chain execution becomes a traced span that flows to Pendo.

Usage:
    from pendo_sdk.langchain_callback import PendoCallbackHandler
    handler = PendoCallbackHandler()

    # Add to LangChain as a global callback:
    import langchain
    langchain.callbacks.manager.add_handler(handler)

    # Or pass per-call:
    llm.invoke(prompt, config={"callbacks": [handler]})
"""

import logging
import time
import uuid
from typing import Any, Dict, List, Optional, Union

from opentelemetry import trace, context
from opentelemetry.trace import StatusCode

logger = logging.getLogger("pendo_sdk")

_SDK_NAME = "pendo_sdk"


# Max bytes of tool input/output content stamped on a span. LangGraph
# Command(update={...}) returns can stringify to tens of KB of serialized
# state, which blows up the agentTraceContent blob on the ingested event.
# 2048 is enough to show the shape of the payload without drowning the UI.
_TRACE_CONTENT_MAX_CHARS = 2048

# Tool-name prefixes that, by LangGraph / LangChain convention, indicate a
# routing tool whose invocation dispatches a named subagent. Example:
#   call_quantitative_agent → subagent "quantitative_agent"
#   handoff_to_legal       → subagent "to_legal" (or "legal" after _to_ strip)
# Pure-prefix match keeps the rule language-agnostic and works for any
# customer's naming scheme without an allow-list of agents.
_ROUTING_TOOL_PREFIXES = ("call_", "handoff_")


def _subagent_name_from_routing_tool(tool_name: str) -> str:
    """Strip a `call_` / `handoff_` prefix off a routing-tool name.

    Returns the remainder verbatim (no further normalization) so the FE
    display path can format it consistently with its own labeling rules
    (e.g. converting `agent_analytics_agent` → "Agent Analytics Agent").
    Returns the empty string when no prefix matches — callers should treat
    that as "this isn't a routing tool, skip the subagent emit."
    """
    for prefix in _ROUTING_TOOL_PREFIXES:
        if tool_name.startswith(prefix):
            return tool_name[len(prefix):]
    return ""


def _coerce_otel_attr(value: Any) -> Any:
    """Coerce a Python value into an OTel-compatible attribute value.

    OpenTelemetry spans accept scalars (str/bool/int/float) and homogeneous
    sequences of those scalars as attributes. Mappings, arbitrary objects,
    and heterogeneous lists must be stringified to avoid a ``TypeError`` on
    ``span.set_attribute``. Earlier versions of this callback stringified
    *everything* non-numeric, which corrupted legitimate list attributes
    like ``pendo.subagents_used = ["quantitative_agent"]`` into the string
    ``"['quantitative_agent']"`` — the exporter then couldn't parse it back
    into a JSON list, and the wire ended up with a nested string.
    """
    if isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, (list, tuple)):
        # OTel allows homogeneous sequences of scalars. If every element is
        # already a supported scalar, pass the list through unchanged; if not,
        # coerce each element via str() to preserve the "it's a list" shape.
        if all(isinstance(x, (str, bool, int, float)) for x in value):
            return list(value)
        return [str(x) for x in value]
    return str(value)


def _normalize_files(files: Optional[List[Any]]) -> List[tuple]:
    """Coerce caller-provided file metadata into ``(type, name)`` tuples.

    Accepts ``ContextItem`` instances or plain dicts. Per the public
    Conversations API docs, each entry must have both ``type`` and ``name`` —
    we drop anything missing either, matching the BE's behavior in
    ``newagenticevent.go`` (which logs+skips incomplete entries).

    Returns tuples (not dicts) because OTel span attributes don't accept
    nested dicts; the exporter reconstructs the wire shape from these tuples.
    """
    if not files:
        return []
    result: List[tuple] = []
    for item in files:
        if item is None:
            continue
        file_type = ""
        name = ""
        if isinstance(item, dict):
            file_type = str(item.get("type") or "")
            name = str(item.get("name") or item.get("title") or "")
        else:
            # ContextItem (pydantic) or any object with `.type` / `.name`.
            type_attr = getattr(item, "type", None)
            file_type = getattr(type_attr, "value", type_attr)
            file_type = str(file_type) if file_type else ""
            name = str(
                getattr(item, "name", None)
                or getattr(item, "title", None)
                or ""
            )
        if not file_type or not name:
            continue
        result.append((file_type, name))
    return result


def _extract_tool_names(tools: Any) -> List[str]:
    """Pull tool names out of a LangChain `tools` / `functions` invocation list.

    LangChain hands us the same payload that goes to the model provider, so
    the shape varies — Chat Completions wraps each tool in
    ``{"type": "function", "function": {"name": ..., ...}}``; older
    function-calling and the Responses API put ``{"name": ...}`` at the top
    level; some integrations pass bound `BaseTool` instances. Best-effort
    extraction with no exceptions: any element we can't read is skipped.
    """
    if not tools:
        return []
    names: List[str] = []
    for item in tools:
        if not item:
            continue
        # `BaseTool`-like object with a .name attribute.
        name_attr = getattr(item, "name", None)
        if isinstance(name_attr, str) and name_attr:
            names.append(name_attr)
            continue
        if isinstance(item, dict):
            fn = item.get("function") if isinstance(item.get("function"), dict) else None
            if fn and isinstance(fn.get("name"), str):
                names.append(fn["name"])
                continue
            if isinstance(item.get("name"), str):
                names.append(item["name"])
    # Dedupe while preserving order — LangChain occasionally double-lists tools.
    seen = set()
    deduped = []
    for n in names:
        if n in seen:
            continue
        seen.add(n)
        deduped.append(n)
    return deduped


def _truncate_for_trace(value: Any) -> str:
    """Stringify ``value`` and truncate to ``_TRACE_CONTENT_MAX_CHARS`` with
    a trailing marker recording how many bytes were dropped. Keeps the UI
    trace viewer readable without discarding that a large payload existed.
    """
    try:
        s = value if isinstance(value, str) else str(value)
    except Exception:
        return "<unstringifiable tool payload>"
    if len(s) <= _TRACE_CONTENT_MAX_CHARS:
        return s
    dropped = len(s) - _TRACE_CONTENT_MAX_CHARS
    return f"{s[:_TRACE_CONTENT_MAX_CHARS]}…[truncated {dropped} bytes]"


def _extract_usage_metadata(response: Any) -> Optional[Dict[str, Any]]:
    """Pull usage_metadata from an LLMResult, checking all known locations.

    LangChain's ``usage_metadata`` dict (``input_tokens`` / ``output_tokens``
    / ``total_tokens``, with optional ``input_token_details`` and
    ``output_token_details`` breakdowns) is populated in different places
    depending on the code path:

    - **Non-streaming Chat Completions or Responses API**: on the single
      ``generations[0][0].message.usage_metadata``.
    - **Streaming**: ``generations[0]`` is a list of ``ChatGenerationChunk``
      and only the final chunk (``response.completed`` for Responses API,
      the last ``chat.completion.chunk`` with usage for Chat Completions)
      carries the aggregated usage. Walking the list in reverse finds it.
    - **Some integrations**: usage is stashed in ``message.response_metadata``
      under ``token_usage`` or ``usage`` rather than ``usage_metadata``.
    - **Older patterns**: usage sits on ``gen.generation_info`` (the
      OpenAI-compatibility dict) instead of on the message itself.

    Returns a dict with ``input_tokens`` / ``output_tokens`` /
    ``total_tokens`` keys (converting ``prompt_tokens`` /
    ``completion_tokens`` if that's what's present), plus the raw
    ``usage_metadata`` nested detail dicts when available.
    """
    generations = getattr(response, "generations", None)
    if not generations or not generations[0]:
        return None

    gens = generations[0] if isinstance(generations[0], list) else [generations[0]]

    # Walk in reverse — for streaming, only the final chunk carries aggregated usage.
    for gen in reversed(gens):
        msg = getattr(gen, "message", None)

        if msg is not None:
            usage_md = getattr(msg, "usage_metadata", None)
            if isinstance(usage_md, dict) and usage_md:
                return usage_md

            # response_metadata.token_usage — some providers stash it here.
            response_md = getattr(msg, "response_metadata", None) or {}
            for key in ("token_usage", "usage"):
                raw = response_md.get(key) if isinstance(response_md, dict) else None
                if isinstance(raw, dict) and raw:
                    normalized = _normalize_openai_usage(raw)
                    if normalized:
                        return normalized

        # Legacy location: gen.generation_info carries the raw OpenAI usage dict.
        gen_info = getattr(gen, "generation_info", None) or {}
        if isinstance(gen_info, dict):
            # gen_info may directly have input_tokens/output_tokens...
            if "input_tokens" in gen_info or "output_tokens" in gen_info:
                normalized = _normalize_openai_usage(gen_info)
                if normalized:
                    return normalized
            # ...or nest it under usage / token_usage / usage_metadata.
            for key in ("usage_metadata", "token_usage", "usage"):
                raw = gen_info.get(key)
                if isinstance(raw, dict) and raw:
                    normalized = _normalize_openai_usage(raw)
                    if normalized:
                        return normalized
    return None


def _normalize_openai_usage(raw: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Coerce an OpenAI-style usage dict into the LangChain usage_metadata shape.

    Chat Completions returns ``prompt_tokens`` / ``completion_tokens`` /
    ``total_tokens`` plus ``prompt_tokens_details`` / ``completion_tokens_details``.
    The Responses API returns ``input_tokens`` / ``output_tokens`` /
    ``total_tokens`` plus ``input_tokens_details`` / ``output_tokens_details``.
    LangChain's ``usage_metadata`` uses the Responses-style names. Normalize
    to that so callers only have to read one shape.
    """
    if not isinstance(raw, dict) or not raw:
        return None

    input_tokens = raw.get("input_tokens")
    if input_tokens is None:
        input_tokens = raw.get("prompt_tokens")
    output_tokens = raw.get("output_tokens")
    if output_tokens is None:
        output_tokens = raw.get("completion_tokens")
    total_tokens = raw.get("total_tokens")

    if input_tokens is None and output_tokens is None and total_tokens is None:
        return None

    result: Dict[str, Any] = {}
    if input_tokens is not None:
        result["input_tokens"] = input_tokens
    if output_tokens is not None:
        result["output_tokens"] = output_tokens
    if total_tokens is not None:
        result["total_tokens"] = total_tokens

    # Preserve detail breakdowns if present under either naming.
    input_details = (
        raw.get("input_token_details")
        or raw.get("input_tokens_details")
        or raw.get("prompt_tokens_details")
    )
    if isinstance(input_details, dict):
        result["input_token_details"] = input_details
    output_details = (
        raw.get("output_token_details")
        or raw.get("output_tokens_details")
        or raw.get("completion_tokens_details")
    )
    if isinstance(output_details, dict):
        result["output_token_details"] = output_details

    return result


class PendoCallbackHandler:
    """LangChain callback handler that creates OTel spans for Pendo tracing."""

    # Required attributes for LangChain callback manager compatibility
    run_inline = True
    raise_error = False
    ignore_chain = False
    ignore_llm = False
    ignore_retry = True
    ignore_agent = False
    ignore_chat_model = False
    ignore_retriever = True
    ignore_custom_event = True

    # Chain names that are LangGraph infrastructure, not meaningful traces.
    # These are kept out of `_chain_parents` so that nested LLM/tool calls
    # don't resolve their parent through them (which would inherit the
    # previous tool's span as a parent and produce misnesting — e.g. an
    # LLM call inside a routing-style node rendering under the previous
    # sibling routing tool instead of the supervisor).
    _NOISE_CHAINS = {
        "start_node", "route_after_start_node", "__start__", "__end__",
        "next_actions_node", "route_after_supervisor", "route_after_start",
        "RunnableSequence", "RunnableLambda", "RunnableParallel",
        "RunnableWithFallbacks", "RunnableBinding", "RunnableAssign",
        "ChannelWrite", "ChannelRead", "tool_node", "tools",
        "model", "agent", "",
    }

    # Chain names that look like subagents to the suffix heuristic but are
    # actually top-level orchestrators in common LangGraph patterns. Excluded
    # so we don't render the supervisor itself as a subagent span wrapping the
    # whole turn.
    _HEURISTIC_NON_SUBAGENT_CHAINS = {
        "supervisor_agent", "supervisor", "root_agent", "main_agent",
    }

    def __init__(self, conversation_id: Optional[str] = None,
                 visitor_id: Optional[str] = None,
                 account_id: Optional[str] = None,
                 auto_turn: bool = False,
                 suggested_prompt: bool = False,
                 subagent_chain_names: Optional[List[str]] = None,
                 message_id: Optional[str] = None,
                 files: Optional[List[Any]] = None):
        self._tracer = trace.get_tracer(_SDK_NAME)
        self._prompt_emitted = False  # Only emit one prompt event per turn
        self._spans: Dict[str, Any] = {}  # run_id -> (span, token)
        self._chain_parents: Dict[str, Optional[str]] = {}  # chain run_id -> parent run_id
        self._conversation_id = conversation_id or ""
        self._visitor_id = visitor_id or ""
        self._account_id = account_id or ""
        self._auto_turn = auto_turn  # Auto-end turn when all spans complete
        # Chain names that should be treated as subagents — when LangChain fires
        # on_chain_start with one of these names, we emit a SUBAGENT_REQUEST span
        # so child LLM/tool calls nest under it in the trace tree (instead of
        # under the routing tool that initiated the subagent, which is what
        # used to happen when chain spans were universally suppressed).
        #
        # Pattern: in a typical LangGraph supervisor-with-subagents setup, the
        # supervisor exposes routing tools (e.g. `call_research_agent`,
        # `handoff_to_specialist`) that, when called, spin up a sub-chain
        # whose name IS the subagent (e.g. `research_agent`). The routing tool
        # is a TOOL; the chain it spins up is the SUBAGENT.
        #
        # Most customers don't need to set this. The callback's primary
        # subagent-detection signal is STRUCTURAL — see `_tool_run_ids`: any
        # chain whose direct parent in LangChain's call graph is an active
        # tool span IS that tool's subroutine, by definition, regardless of
        # what the customer named either the tool or the chain. Use the
        # explicit list only when the structural signal doesn't apply (e.g.
        # a subagent chain that's invoked directly from the supervisor
        # without going through a routing tool).
        #
        # Example:
        #     handler = PendoCallbackHandler(
        #         subagent_chain_names=["research_agent", "summarizer_agent"],
        #     )
        self._subagent_chain_names: set = set(subagent_chain_names or [])
        # Run IDs of currently-live TOOL_REQUEST spans. Populated in
        # on_tool_start, cleared in on_tool_end. When on_chain_start fires
        # with parent_run_id pointing into this set, the chain is structurally
        # a subroutine of an active tool — i.e. a routing-tool-invoked
        # subagent — and we emit a SUBAGENT_REQUEST span for it.
        #
        # This is the replacement for an earlier prefix-matching approach
        # (call_*, handoff_*, transfer_to_*, ...) that only recognized a
        # hard-coded set of English routing-verb conventions. Using the
        # actual call graph instead of name patterns works for any naming
        # convention, in any language, with any verb the customer chooses.
        self._tool_run_ids: set = set()
        # Routing tools (`call_*` / `handoff_*`) → synthetic SUBAGENT_REQUEST
        # span we emit alongside the tool span. The routing-tool name is the
        # signal: any tool whose LangChain `name` matches the prefix IS a
        # subagent dispatch by convention (LangGraph + custom Python agents
        # both follow this pattern). Inferring from the tool name rather than
        # relying on the inner chain's serialized.name means we don't depend
        # on the chain firing with a recognizable name — e.g. when the chain
        # is wrapped in `RunnableWithFallbacks` / `RunnableSequence` and its
        # own name gets swallowed as noise. The subagent span anchors the
        # structural depth so descendant LLM / tool spans nest correctly.
        # Keyed by the routing tool's LangChain run_id.
        self._routing_tool_subagent_spans: Dict[str, Any] = {}
        # When set, the single prompt event this turn emits is flagged as a
        # suggested/pre-built prompt (e.g. user clicked a starter chip in the UI
        # rather than typing). Consumed by _emit_prompt_event.
        self._suggested_prompt = bool(suggested_prompt)
        self._explicit_message_id = str(message_id) if message_id else ""
        # Caller-provided file metadata for this turn. Stamped on the
        # agent.response span in end_turn → surfaces as agentFilesUploaded on
        # the wire (BE auto-splits into Names/Types columns). Normalized
        # upfront so end_turn doesn't have to re-parse mixed input shapes.
        self._files_uploaded: List[tuple] = _normalize_files(files)
        self._root_span = None  # Root span for the current conversation turn
        self._root_token = None
        # Accumulate response data across the turn for a single merged agent_response
        self._turn_response_text = ""  # Last response text wins
        self._turn_models: List[str] = []
        self._turn_tools: List[str] = []
        # Subagents invoked in this turn (dedup, insertion-ordered). Surfaces as
        # agentSubagentsUsed on the agent_response wire event so the Conversations
        # API column populates without the FE having to walk the trace tree.
        self._turn_subagents: List[str] = []
        # Cumulative token usage across all user-visible (non-no_stream) LLM
        # calls in the turn — surfaces as agentInputTokenCount /
        # agentOutputTokenCount / agentCacheReadTokenCount /
        # agentTotalTokenCount on the agent_response wire event. Per-call
        # tokens are still stamped on each llm_request/llm_response trace event.
        # `total` is computed as input + output (not summed from per-call
        # `total_tokens` fields, which providers don't always report).
        self._turn_input_tokens: int = 0
        self._turn_output_tokens: int = 0
        self._turn_cache_read_tokens: int = 0
        # ID of the final user-visible AIMessage in this turn. Captured on
        # the same "last response wins" path as _turn_response_text so the
        # agent_response event carries the SAME id the FE sees in the stream
        # (serialize_langchain_message → AIMessage.id) — that is the id the FE
        # will later send back on `record_reaction(message_id=...)`, and the
        # FE pairs the two events by matching messageId. (APP-153064)
        # `_explicit_message_id` (set above from the constructor) wins over
        # this auto-captured value when the caller chose to provide one.
        self._turn_response_message_id: str = ""
        # Per-run_id tokens for the langchain_llm_active ContextVar. Set when
        # on_llm_start/on_chat_model_start fires so the OpenAI patchers can
        # detect "LangChain already owns this LLM call" and skip creating a
        # duplicate GENERATION span. Reset in on_llm_end/on_llm_error.
        self._llm_active_tokens: Dict[str, Any] = {}
        # Tool call ids that on_tool_end has already emitted a span for in the
        # current turn. ``_emit_tool_result_spans`` checks this to avoid
        # emitting a second TOOL_RESPONSE span for the same tool call when the
        # next LLM call sees the tool result in its message history.
        self._emitted_tool_call_ids: set = set()
        # Per-run_id tags captured at llm_start so on_llm_end can skip internal
        # LLM calls (tag "no_stream") from overwriting the turn's user-facing
        # response text. Without this, a classifier/evaluator LLM that runs
        # after the main response wins "last response" and pollutes agent_response.
        #
        # Thread-safety: this dict is not locked. We rely on the handler being
        # scoped to a single request (the typical `langchain_turn()` pattern),
        # in which LangChain callbacks for a given run_id fire serially on the
        # same event loop. Sharing a handler across concurrent requests (e.g.
        # a long-lived global handler with auto_turn=True under RunnableParallel
        # across threads) would be unsafe — callers should prefer per-request
        # handlers via `langchain_turn()`.
        self._span_tags: Dict[str, List[str]] = {}

    def set_conversation_id(self, conversation_id: str):
        self._conversation_id = conversation_id

    def set_identity(self, visitor_id: Optional[str] = None,
                     account_id: Optional[str] = None):
        """Set visitor/account identity stamped on every span this handler creates."""
        if visitor_id is not None:
            self._visitor_id = visitor_id
        if account_id is not None:
            self._account_id = account_id

    def start_turn(self):
        """Start a new conversation turn — creates a root span that all child spans nest under.
        This ensures all spans in a single turn share the same agentTraceId.
        """
        self.end_turn()  # Clean up any previous turn
        self._prompt_emitted = False  # Reset prompt flag for new turn
        self._turn_response_text = ""
        self._turn_models = []
        self._emitted_tool_call_ids = set()
        self._turn_tools = []
        self._turn_subagents = []
        self._turn_input_tokens = 0
        self._turn_output_tokens = 0
        self._turn_cache_read_tokens = 0
        self._routing_tool_subagent_spans = {}
        self._span_tags = {}
        self._root_span = self._tracer.start_span("conversation.turn")
        self._root_span.set_attribute("pendo.span.type", "AGENT")
        self._root_span.set_attribute("message.role", "system")  # Won't emit conversation event
        if self._conversation_id:
            self._root_span.set_attribute("pendo.conversation_id", self._conversation_id)
        # Tell the exporter this span ID should be stripped from children's parent
        # Set immediately so it's available before any child spans flush
        from .core import _exporter
        if _exporter:
            _exporter._suppressed_root_span_id = format(self._root_span.context.span_id, "016x")

    def end_turn(self):
        """End the current conversation turn.
        Emits a single merged agent_response conversation event with accumulated
        models and tools from all LLM calls in the turn.
        """
        if self._root_span:
            # Emit one merged agent_response if we have response text
            if self._turn_response_text:
                parent_ctx = trace.set_span_in_context(self._root_span)
                span = self._tracer.start_span("agent.response", context=parent_ctx)
                span.set_attribute("pendo.span.type", "ASSISTANT_RESPONSE")
                span.set_attribute("message.role", "assistant")
                span.set_attribute("message.content", self._turn_response_text)
                span.set_attribute("message.response_content", self._turn_response_text)
                if self._turn_models:
                    # Primary model = the last one used (the one that produced the
                    # visible response text). The full set goes on llm.model_names so
                    # the exporter can emit agentModelsUsed as a list — joining models
                    # into a single comma-string broke the donut chart by treating
                    # each combination as its own slice (APP-152157).
                    span.set_attribute("llm.model_name", self._turn_models[-1])
                    if len(self._turn_models) > 1:
                        span.set_attribute("llm.model_names", tuple(self._turn_models))
                if self._turn_tools:
                    span.set_attribute("tool.name", ", ".join(self._turn_tools))
                if self._turn_subagents:
                    # Surfaced as agentSubagentsUsed on the wire by the exporter.
                    span.set_attribute("pendo.subagents_used", tuple(self._turn_subagents))
                if self._files_uploaded:
                    # OTel attrs don't accept nested dicts, so the wire shape
                    # `[{type, name}, ...]` is stored as two parallel string
                    # tuples and reassembled in the exporter.
                    span.set_attribute(
                        "pendo.files_uploaded_types",
                        tuple(t for t, _ in self._files_uploaded),
                    )
                    span.set_attribute(
                        "pendo.files_uploaded_names",
                        tuple(n for _, n in self._files_uploaded),
                    )
                # Stamp cumulative token counts only when we actually observed
                # usage — leaving them off when no LLM reported usage_metadata
                # so the wire event omits the field (vs. emitting a misleading
                # zero). Surfaces as agentInputTokenCount / agentOutputTokenCount.
                if self._turn_input_tokens or self._turn_output_tokens:
                    span.set_attribute("pendo.input_token_count", int(self._turn_input_tokens))
                    span.set_attribute("pendo.output_token_count", int(self._turn_output_tokens))
                    # total = input + output. We don't sum providers'
                    # per-call `total_tokens` because some omit it; computing
                    # locally guarantees the column populates whenever
                    # input/output are present.
                    span.set_attribute(
                        "pendo.total_token_count",
                        int(self._turn_input_tokens + self._turn_output_tokens),
                    )
                if self._turn_cache_read_tokens:
                    span.set_attribute(
                        "pendo.cache_read_token_count",
                        int(self._turn_cache_read_tokens),
                    )
                if self._conversation_id:
                    span.set_attribute("pendo.conversation_id", self._conversation_id)
                # Caller-provided id wins; otherwise use the AIMessage.id
                # captured from the final user-visible LLM response so the
                # event matches what the FE has in hand for a later reaction.
                chosen_message_id = self._explicit_message_id or self._turn_response_message_id
                if chosen_message_id:
                    span.set_attribute("pendo.message_id", chosen_message_id)
                self._stamp_identity(span)
                span.end()

            self._root_span.end()
            self._root_span = None

    def _stamp_identity(self, span) -> None:
        """Stamp visitor/account identity on a span at creation time.

        This captures identity on the request thread so the exporter
        reads it from the span — not from mutable exporter state that
        may be overwritten by a concurrent request.
        """
        if self._visitor_id:
            span.set_attribute("pendo.visitor_id", self._visitor_id)
        if self._account_id:
            span.set_attribute("pendo.account_id", self._account_id)

    def _mark_llm_active(self, run_id: Any) -> None:
        """Mark the langchain_llm_active ContextVar True for the duration of
        this LLM call. The OpenAI patchers check this and skip span creation,
        so a streamed ``ChatOpenAI`` call produces exactly one GENERATION span
        (from this handler) instead of two (handler + patcher).
        """
        try:
            from .patchers.langchain import langchain_llm_active
            self._llm_active_tokens[str(run_id)] = langchain_llm_active.set(True)
        except Exception:
            # Never let instrumentation bookkeeping break the LLM call.
            pass

    def _unmark_llm_active(self, run_id: Any) -> None:
        """Reset the langchain_llm_active ContextVar set by _mark_llm_active."""
        token = self._llm_active_tokens.pop(str(run_id), None)
        if token is None:
            return
        try:
            from .patchers.langchain import langchain_llm_active
            langchain_llm_active.reset(token)
        except Exception:
            pass

    def _resolve_parent_run_id(self, parent_run_id: Optional[str]) -> Optional[str]:
        """Traverse chain parents to find an ancestor that has a real span.
        Chains don't emit events but sub-agent LLM/tool calls are parented to them.
        Walk up the chain_parents map until we find a run_id in self._spans.
        """
        if not parent_run_id:
            return None
        current = str(parent_run_id)
        visited = set()
        while current and current not in visited:
            if current in self._spans:
                return current
            visited.add(current)
            current = self._chain_parents.get(current)
        return None

    def _start_span(self, run_id: str, name: str, span_type: str,
                    attrs: Optional[Dict] = None, parent_run_id: Optional[str] = None):
        # Determine parent context:
        # 1. Resolve parent through chain hierarchy to find a real span
        # 2. Otherwise use the root turn span (so all spans share same trace ID)
        # 3. If no root span, create one automatically
        parent_ctx = None
        resolved_parent = self._resolve_parent_run_id(str(parent_run_id) if parent_run_id else None)
        # Routing-tool re-parenting: if the resolved parent is a routing
        # tool we've emitted a synthetic SUBAGENT_REQUEST under, point this
        # child at the subagent span instead of the tool span. That way the
        # subagent gains its own subtree in the trace, matching the
        # LangSmith view (routing tool → subagent header → inner LLM/tool).
        if resolved_parent and resolved_parent in self._routing_tool_subagent_spans:
            subagent_span = self._routing_tool_subagent_spans[resolved_parent]
            parent_ctx = trace.set_span_in_context(subagent_span)
        elif resolved_parent and resolved_parent in self._spans:
            parent_span, _ = self._spans[resolved_parent]
            parent_ctx = trace.set_span_in_context(parent_span)

        if not parent_ctx and self._root_span:
            parent_ctx = trace.set_span_in_context(self._root_span)

        if not parent_ctx:
            # Auto-create root span if none exists
            self.start_turn()
            parent_ctx = trace.set_span_in_context(self._root_span)

        span = self._tracer.start_span(name, context=parent_ctx)
        span.set_attribute("pendo.span.type", span_type)
        if self._conversation_id:
            span.set_attribute("pendo.conversation_id", self._conversation_id)
        self._stamp_identity(span)
        if attrs:
            for k, v in attrs.items():
                if v is None:
                    continue
                span.set_attribute(k, _coerce_otel_attr(v))
        # Don't attach to global context — async tasks cross boundaries
        # and context.detach fails across different async contexts.
        # Just store the span for parent lookup.
        self._spans[str(run_id)] = (span, None)

    def _emit_prompt_event(self, content: str, model: str = ""):
        """Emit a standalone prompt span for the user's message.

        This creates a separate short-lived span so the user's prompt
        appears as a 'prompt' conversation event, independent of the
        LLM generation span which will become 'agent_response'.
        """
        parent_ctx = trace.set_span_in_context(self._root_span) if self._root_span else None
        span = self._tracer.start_span("user.prompt", context=parent_ctx)
        span.set_attribute("pendo.span.type", "USER_MESSAGE")
        span.set_attribute("message.role", "user")
        span.set_attribute("message.content", content if content else "")
        if model:
            span.set_attribute("llm.model_name", model)
        if self._conversation_id:
            span.set_attribute("pendo.conversation_id", self._conversation_id)
        if self._suggested_prompt:
            span.set_attribute("message.suggested_prompt", True)
        self._stamp_identity(span)
        span.end()  # End immediately — this is a point event

    def _end_span(self, run_id: str, error: Optional[str] = None):
        key = str(run_id)
        if key not in self._spans:
            # No span was started for this run_id — nothing to end. Leave any
            # _span_tags entry alone (it shouldn't exist, but if it does,
            # start_turn() will clear it on the next turn).
            return
        span, _ = self._spans.pop(key)
        # Pop tag entry AFTER we've confirmed the span existed, to keep
        # _span_tags and _spans lifecycles symmetric.
        self._span_tags.pop(key, None)
        if error:
            span.set_status(StatusCode.ERROR, error)
        else:
            span.set_status(StatusCode.OK)
        span.end()

        # In auto_turn mode, end the turn when all spans have completed.
        # This means the outermost LangChain invocation has finished.
        if self._auto_turn and not self._spans and not self._chain_parents and self._root_span:
            self.end_turn()
            from .core import flush
            flush()

    # ---- LLM callbacks ----

    def _format_messages_as_prompt(self, messages: List[Any]) -> str:
        """Format the delta messages for this specific LLM call's agentTraceContent.

        Only captures NEW non-tool messages since the last assistant response.
        Tool results are emitted as separate TOOL_RESPONSE trace events by
        _emit_tool_result_spans(), so they're excluded here to avoid duplication
        and keep the llm_request content focused on the actual prompt/instruction.

        For the first LLM call in a turn: includes system + user message.
        For subsequent calls (after tool use): includes only new user/human messages.
        """
        if not messages:
            return ""
        msg_list = messages[0] if isinstance(messages[0], list) else messages

        # Find the last assistant message index — everything after it is "new"
        last_ai_idx = -1
        for i, msg in enumerate(msg_list):
            role = getattr(msg, "type", "unknown")
            if role in ("ai", "assistant"):
                last_ai_idx = i

        # If no prior AI message, this is the first LLM call — include system + user
        if last_ai_idx == -1:
            parts = []
            for msg in msg_list:
                role = getattr(msg, "type", "unknown")
                # Skip tool messages — they get their own trace events
                if role == "tool":
                    continue
                content = str(getattr(msg, "content", ""))
                if not content:
                    continue
                parts.append(f"[{role}] {content}")
            return "\n".join(parts)

        # Otherwise, only include non-tool messages AFTER the last AI response
        parts = []
        delta = msg_list[last_ai_idx + 1:]
        has_tool_results = False
        for msg in delta:
            role = getattr(msg, "type", "unknown")
            # Skip tool messages — they get their own trace events
            if role == "tool":
                has_tool_results = True
                continue
            content = str(getattr(msg, "content", ""))
            if not content:
                continue
            parts.append(f"[{role}] {content}")
        if parts:
            return "\n".join(parts)
        # Continuation call driven purely by tool results: return a placeholder
        # so downstream trace_content is non-empty. Without this the exporter
        # would fall back to message.content (which on_llm_end overwrites with
        # the response), making the llm_request event display the response text.
        if has_tool_results:
            return "[continuation after tool results]"
        return ""

    def _emit_tool_result_spans(
        self,
        messages: List[Any],
        parent_llm_run_id: Optional[Any] = None,
    ) -> None:
        """Emit TOOL_RESPONSE trace spans for tool result messages in the delta.

        When the LLM is called after tools return, the message history includes
        tool result messages. These are emitted as separate tool_response nodes
        in the trace tree — unless ``on_tool_end`` has already emitted a span
        for the same ``tool_call_id`` in this turn, in which case we'd produce
        a duplicate event. Two correctness requirements:

        1. Skip ToolMessages whose ``tool_call_id`` was already handled by
           ``on_tool_end`` (tracked in ``_emitted_tool_call_ids``). This is the
           common path in LangGraph-based agents.
        2. Parent context: prefer the **current chat model span** (``parent_llm_run_id``)
           so replayed tool results nest under the LLM invocation that consumes
           them — closer to LangSmith than flattening under the turn root. If that
           span is not available, fall back to ``_root_span``. Skip if neither
           exists (would orphan on the wire).

        Emitted attributes use ``message.content`` (what the exporter reads
        for TOOL_RESPONSE spans), not ``tool.output`` (which the exporter
        routes into tool_request/response pairs on TOOL_REQUEST spans).
        """
        if not messages:
            return
        parent_ctx = None
        if parent_llm_run_id is not None:
            llm_key = str(parent_llm_run_id)
            if llm_key in self._spans:
                parent_span, _ = self._spans[llm_key]
                parent_ctx = trace.set_span_in_context(parent_span)
        if parent_ctx is None and self._root_span is not None:
            parent_ctx = trace.set_span_in_context(self._root_span)
        if parent_ctx is None:
            return
        msg_list = messages[0] if isinstance(messages[0], list) else messages

        # Find delta messages (after last AI response)
        last_ai_idx = -1
        for i, msg in enumerate(msg_list):
            role = getattr(msg, "type", "unknown")
            if role in ("ai", "assistant"):
                last_ai_idx = i

        delta = msg_list[last_ai_idx + 1:] if last_ai_idx >= 0 else []

        for msg in delta:
            role = getattr(msg, "type", "unknown")
            if role != "tool":
                continue

            tool_call_id = getattr(msg, "tool_call_id", None)
            if tool_call_id and str(tool_call_id) in self._emitted_tool_call_ids:
                # on_tool_end already emitted a paired tool_request/tool_response
                # for this call — don't double-emit.
                continue

            tool_name = getattr(msg, "name", "") or "tool"
            content = str(getattr(msg, "content", ""))
            if not content:
                continue

            span = self._tracer.start_span(f"tool.{tool_name}", context=parent_ctx)
            span.set_attribute("pendo.span.type", "TOOL_RESPONSE")
            span.set_attribute("tool.name", tool_name)
            # The exporter reads message.content for non-tool-split spans; use
            # that instead of tool.output so the content actually renders on
            # the wire (tool.output is only consulted for TOOL_REQUEST spans).
            span.set_attribute("message.content", _truncate_for_trace(content))
            if self._conversation_id:
                span.set_attribute("pendo.conversation_id", self._conversation_id)
            self._stamp_identity(span)
            span.end()

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        serialized_kwargs = (serialized.get("kwargs") or {})
        model = (
            serialized_kwargs.get("model_name", "")
            or serialized_kwargs.get("model", "")
            or serialized.get("id", [""])[-1]
        )
        content = "\n".join(prompts) if prompts else ""
        self._span_tags[str(run_id)] = list(tags or [])
        self._mark_llm_active(run_id)
        self._start_span(run_id, f"llm.{model}", "GENERATION", {
            "llm.model_name": model,
            "message.content": content,
            "message.role": "user",
        }, parent_run_id=parent_run_id)

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[Any],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        serialized_kwargs = serialized.get("kwargs") or {}
        model = (
            serialized_kwargs.get("model_name", "")
            or serialized_kwargs.get("model", "")
            or kwargs.get("invocation_params", {}).get("model_name", "")
            or kwargs.get("invocation_params", {}).get("model", "")
            or serialized.get("id", [""])[-1]
        )
        # Full prompt context for agentTraceContent (excludes tool results)
        full_prompt = self._format_messages_as_prompt(messages)
        # User's actual message for conversation event content
        user_content = ""
        msg_list = messages[0] if messages and isinstance(messages[0], list) else (messages or [])
        for msg in reversed(msg_list):
            if getattr(msg, "type", "") == "human":
                user_content = str(getattr(msg, "content", ""))
                break
        # Emit a separate prompt event for the user's message
        # Always emit — use user_content if found, otherwise extract from full prompt
        prompt_text = user_content
        if not prompt_text and full_prompt:
            # Try to extract last [human] message from formatted prompt
            for line in reversed(full_prompt.split("\n")):
                if line.startswith("[human]"):
                    prompt_text = line[len("[human]"):].strip()
                    break
        if prompt_text and not self._prompt_emitted:
            self._emit_prompt_event(prompt_text, model)
            self._prompt_emitted = True
            logger.info("Emitted prompt event: %s", prompt_text[:80])
        elif not self._prompt_emitted and not prompt_text:
            # First LLM call in the turn with no extractable human message — unusual.
            logger.warning(
                "No user content found for prompt event. msg_list types: %s",
                [type(m).__name__ for m in msg_list[:3]],
            )
        # Follow-up LLM calls (tool continuations, already-emitted prompt): quiet.

        # Capture the tool catalog the LLM was given for THIS call. Lets the
        # AA UI render "tools available" alongside "tools used" so a reviewer
        # can tell whether the LLM picked the right tool out of the set it
        # had. LangChain stashes this on `invocation_params["tools"]` (Chat
        # Completions / Responses API) or `invocation_params["functions"]`
        # (older function-calling shape).
        invocation_params = kwargs.get("invocation_params") or {}
        tools_available = _extract_tool_names(
            invocation_params.get("tools") or invocation_params.get("functions")
        )

        # The LLM generation span starts as "assistant" — it'll become agent_response
        # when on_llm_end fires with the model's response content
        self._span_tags[str(run_id)] = list(tags or [])
        self._mark_llm_active(run_id)
        attrs: Dict[str, Any] = {
            "llm.model_name": model,
            "message.content": "",  # Will be set by on_llm_end with response content
            "message.trace_content": full_prompt,
            "message.role": "assistant",
        }
        if tools_available:
            attrs["llm.tools_available"] = tools_available
        self._start_span(run_id, f"llm.{model}", "GENERATION", attrs,
                         parent_run_id=parent_run_id)
        # After the GENERATION span exists, emit replayed tool results as children
        # of this LLM call (inputs to this invocation).
        self._emit_tool_result_spans(messages, parent_llm_run_id=run_id)

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key in self._spans:
            span, _ = self._spans[key]
            # Resolve token usage. Preference order:
            #   1. llm_output.token_usage (non-streaming Chat Completions).
            #   2. usage_metadata on the final generation / response_metadata
            #      / generation_info — the most reliable for streaming and for
            #      the Responses API path used by reasoning models (o1/o3/gpt-5.x).
            llm_output = getattr(response, "llm_output", None) or {}
            raw_usage = llm_output.get("token_usage") if isinstance(llm_output, dict) else None
            usage_source = "llm_output.token_usage"
            normalized = _normalize_openai_usage(raw_usage) if isinstance(raw_usage, dict) else None

            if normalized is None:
                normalized = _extract_usage_metadata(response)
                usage_source = "generations.usage_metadata" if normalized else "none"

            if normalized:
                input_tokens = normalized.get("input_tokens")
                output_tokens = normalized.get("output_tokens")
                total_tokens = normalized.get("total_tokens")
                if input_tokens is not None:
                    span.set_attribute("llm.token_count.prompt", input_tokens)
                if output_tokens is not None:
                    span.set_attribute("llm.token_count.completion", output_tokens)
                if total_tokens is not None:
                    span.set_attribute("llm.token_count.total", total_tokens)

                # Cache-read input tokens and reasoning output tokens — these
                # mirror what LangSmith's cost-tracking UI shows under
                # "cache read" and "reasoning" sub-rows.
                input_details = normalized.get("input_token_details") or {}
                if isinstance(input_details, dict):
                    cache_read = input_details.get("cache_read")
                    if cache_read is None:
                        # Chat Completions names it cached_tokens under prompt_tokens_details.
                        cache_read = input_details.get("cached_tokens")
                    if cache_read is not None:
                        span.set_attribute(
                            "llm.token_count.prompt_cache_read", cache_read
                        )

                output_details = normalized.get("output_token_details") or {}
                if isinstance(output_details, dict):
                    reasoning = output_details.get("reasoning")
                    if reasoning is None:
                        reasoning = output_details.get("reasoning_tokens")
                    if reasoning is not None:
                        span.set_attribute(
                            "llm.token_count.completion_reasoning", reasoning
                        )

                logger.info(
                    "pendo_sdk tokens stamped (source=%s): prompt=%s completion=%s total=%s",
                    usage_source,
                    input_tokens,
                    output_tokens,
                    total_tokens,
                )
            else:
                logger.warning(
                    "pendo_sdk: no token usage found on LLM response — "
                    "llm_output.token_usage empty and no usage_metadata on any generation"
                )

            model = llm_output.get("model_name", "") if isinstance(llm_output, dict) else ""
            if model:
                span.set_attribute("llm.model_name", model)

            # Extract the LLM's response text for agent_response event
            response_text = ""
            generations = getattr(response, "generations", None)
            if generations and generations[0]:
                gen = generations[0][0] if isinstance(generations[0], list) else generations[0]
                response_text = str(getattr(gen, "text", ""))
                # Check for tool calls in the response
                msg = getattr(gen, "message", None)
                if msg:
                    tool_calls = getattr(msg, "tool_calls", None)
                    if tool_calls:
                        tool_names = [tc.get("name", "") for tc in tool_calls if isinstance(tc, dict)]
                        if tool_names:
                            span.set_attribute("tool.name", tool_names[0])
                            response_text = response_text or f"tool_call: {', '.join(tool_names)}"

            # Determine if this is a tool call or a real text response
            has_tool_calls = bool(getattr(getattr(gen, "message", None), "tool_calls", None) if generations and generations[0] else None)

            # Internal/meta LLM calls (classifiers, next-action evaluators,
            # tool-generation helpers) are tagged "no_stream" by ai-connect.
            # Suppress ALL accumulation for these calls — content, model name,
            # and tool names — so the merged agent_response event reflects
            # only user-facing LLM activity. (Pre-fix, the classifier's JSON
            # output + gpt-4o-mini model name would leak into agent_response,
            # masking the real gemini-2.5-flash response.)
            #
            # ASSUMPTION: LangChain propagates `tags` from
            # make_runnable_config(tags=[...]) into on_llm_start /
            # on_chat_model_start callbacks, including through
            # with_structured_output() wrappers. Verified empirically against
            # ai-connect's create_guide evaluator (which uses both). If this
            # propagation ever regresses, classifier output will leak back
            # into agent_response events.
            is_internal = "no_stream" in self._span_tags.get(key, [])

            # Accumulate token totals across ALL LLM calls in the turn —
            # including no_stream classifier/evaluator calls. Tokens are a
            # usage/cost fact: a classifier still consumes real tokens
            # against the customer's budget, and excluding them would make
            # Pendo undercount vs. LangSmith (which sums every call). The
            # model/tool/subagent aggregators below still skip no_stream so
            # the user-facing summary stays clean.
            if normalized:
                in_tokens = normalized.get("input_tokens")
                out_tokens = normalized.get("output_tokens")
                if isinstance(in_tokens, int):
                    self._turn_input_tokens += in_tokens
                if isinstance(out_tokens, int):
                    self._turn_output_tokens += out_tokens
                # Cache-read tokens live under input_token_details; the per-
                # call attribute was already stamped above. Sum across the
                # turn so the agent_response surfaces the customer's actual
                # cache savings.
                input_details = normalized.get("input_token_details") or {}
                if isinstance(input_details, dict):
                    cache_read = input_details.get("cache_read")
                    if cache_read is None:
                        cache_read = input_details.get("cached_tokens")
                    if isinstance(cache_read, int):
                        self._turn_cache_read_tokens += cache_read

            if has_tool_calls:
                # Tool call decision — LLM decided to call a tool/agent.
                # Capture the full response including reasoning + tool call info.
                span.set_attribute("message.role", "tool_decision")

                # Build the decision output: reasoning text + tool calls
                decision_parts = []
                # Get reasoning from message.content (where LLMs put their thinking)
                if msg:
                    msg_content = str(getattr(msg, "content", ""))
                    if msg_content:
                        decision_parts.append(msg_content)
                # Append tool call details
                tool_calls_list = getattr(msg, "tool_calls", []) if msg else []
                for tc in tool_calls_list:
                    if isinstance(tc, dict):
                        tc_name = tc.get("name", "")
                        tc_args = tc.get("args", {})
                        decision_parts.append(f"Action: {tc_name}({tc_args})")
                        if tc_name and not is_internal and tc_name not in self._turn_tools:
                            self._turn_tools.append(tc_name)

                decision_text = "\n".join(decision_parts) if decision_parts else response_text
                span.set_attribute("message.response_content", decision_text)
            else:
                # Real text response — accumulate for merged agent_response at end_turn
                # Don't set role="assistant" so exporter skips conversation event
                span.set_attribute("message.role", "llm_response")
                if response_text:
                    span.set_attribute("message.content", response_text)
                    span.set_attribute("message.response_content", response_text)
                    if not is_internal:
                        self._turn_response_text = response_text  # Last response wins
                        # Capture the AIMessage.id alongside the response text so
                        # the merged agent_response event carries the same id the
                        # FE serializes onto the streamed assistant message.
                        msg_id_attr = getattr(msg, "id", "") if msg else ""
                        if msg_id_attr:
                            self._turn_response_message_id = str(msg_id_attr)

            # Accumulate model name (skip for internal/no_stream calls —
            # otherwise classifier models like gpt-4o-mini would pollute
            # agent_response.ModelUsed alongside the real main-LLM model).
            current_model = span.attributes.get("llm.model_name", "") if hasattr(span, 'attributes') else ""
            if not current_model:
                current_model = model
            if current_model and not is_internal and current_model not in self._turn_models:
                self._turn_models.append(current_model)

        self._end_span(run_id)
        self._unmark_llm_active(run_id)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self._end_span(run_id, error=str(error))
        self._unmark_llm_active(run_id)

    # ---- Tool callbacks ----

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        tool_name = (serialized or {}).get("name", "") or (serialized or {}).get("id", [""])[-1]
        # Routing tools (e.g. `call_research_agent`, `handoff_*`) used to be
        # classified as SUBAGENT_REQUEST here, but they are themselves just tools
        # — the *chain* they spin up (e.g. `research_agent`) is the actual
        # subagent. Emitting a subagent span on the routing tool caused the
        # subagent's LLM/tool calls to nest under the routing tool name in the
        # UI and forced the routing tool's short duration into the parent role.
        # All tools are TOOL_REQUEST now; the subsequent chain is classified
        # as a subagent structurally — see `_chain_parent_is_tool`.
        span_attrs: Dict[str, Any] = {
            "tool.name": tool_name,
            "tool.input": _truncate_for_trace(input_str),
        }

        self._start_span(run_id, f"tool.{tool_name}", "TOOL_REQUEST", span_attrs,
                         parent_run_id=parent_run_id)
        # Track that this run_id is a live tool span so that any chain firing
        # under it can be recognized as a routing-tool-invoked subagent.
        self._tool_run_ids.add(str(run_id))

        # Routing-tool inference: when LangChain hands us a tool whose name
        # starts with `call_` / `handoff_`, treat that as the dispatch into a
        # subagent and emit a SUBAGENT_REQUEST span right now — derived from
        # the tool name, no allow-list needed. Inner LLM / tool / chain spans
        # whose parent_run_id resolves to this tool get re-parented onto the
        # subagent span (see `_start_span` parent resolution), so the trace
        # tree gains the structural depth even when the inner chain has no
        # recognizable name (e.g. wrapped in RunnableWithFallbacks or anon).
        subagent_name = _subagent_name_from_routing_tool(tool_name)
        if subagent_name:
            tool_span_entry = self._spans.get(str(run_id))
            if tool_span_entry is not None:
                tool_span = tool_span_entry[0]
                parent_ctx = trace.set_span_in_context(tool_span)
                subagent_span = self._tracer.start_span(
                    f"subagent.{subagent_name}", context=parent_ctx,
                )
                subagent_span.set_attribute("pendo.span.type", "SUBAGENT_REQUEST")
                subagent_span.set_attribute("tool.name", subagent_name)
                subagent_span.set_attribute("pendo.subagents_used", (subagent_name,))
                if self._conversation_id:
                    subagent_span.set_attribute(
                        "pendo.conversation_id", self._conversation_id,
                    )
                self._stamp_identity(subagent_span)
                self._routing_tool_subagent_spans[str(run_id)] = subagent_span
                # Roll up into the turn list too so agent_response's
                # agentSubagentsUsed reflects the dispatch even when no inner
                # chain ever fired.
                if subagent_name not in self._turn_subagents:
                    self._turn_subagents.append(subagent_name)

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key in self._spans:
            span, _ = self._spans[key]
            span.set_attribute("tool.output", _truncate_for_trace(output))
        # Record the tool_call_id so _emit_tool_result_spans can dedup on the
        # next LLM call — LangChain's ToolMessage carries the same tool_call_id
        # that the tool invocation was keyed on.
        tool_call_id = (
            getattr(output, "tool_call_id", None)
            or (kwargs.get("inputs") or {}).get("tool_call_id")
        )
        if tool_call_id:
            self._emitted_tool_call_ids.add(str(tool_call_id))
        self._tool_run_ids.discard(key)
        # End the routing-tool subagent span (if we emitted one) BEFORE
        # ending the tool span, so its end_time falls inside the tool's
        # interval — keeps the trace timeline sane.
        subagent_span = self._routing_tool_subagent_spans.pop(key, None)
        if subagent_span is not None:
            subagent_span.end()
        self._end_span(run_id)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        self._tool_run_ids.discard(key)
        # Propagate the failure onto the synthetic subagent span before
        # ending it — if a routing tool errored, the dispatched subagent
        # is also considered failed for trace-status purposes.
        subagent_span = self._routing_tool_subagent_spans.pop(key, None)
        if subagent_span is not None:
            from opentelemetry.trace import Status, StatusCode

            subagent_span.set_status(Status(StatusCode.ERROR, str(error)))
            subagent_span.end()
        self._end_span(run_id, error=str(error))

    # ---- Chain callbacks ----

    def _chain_name(self, serialized: Dict[str, Any]) -> str:
        """Best-effort chain name from the LangChain serialized payload.

        LangChain puts the chain name on either `serialized["name"]` (graph
        nodes, custom Runnables) or as the last segment of `serialized["id"]`
        (compiled state graphs). Defaulting to empty string keeps callers
        from having to None-check downstream.
        """
        s = serialized or {}
        name = s.get("name") or ""
        if not name:
            sid = s.get("id") or [""]
            if isinstance(sid, list) and sid:
                name = str(sid[-1])
        return str(name or "")

    def _is_subagent_chain(
        self, name: str, parent_run_id: Optional[Any] = None,
    ) -> bool:
        """Whether a chain should emit a SUBAGENT_REQUEST span.

        Decision order (most reliable first):
          1. Exclude known top-level orchestrators (supervisor / root_agent)
             — these are never subagents.
          2. Exclude known LangGraph infrastructure (RunnableSequence,
             ChannelWrite, etc.).
          3. Explicit allowlist passed at construction.
          4. STRUCTURAL: chain whose parent in the LangChain call graph is
             an active tool span IS that tool's subroutine — a routing-tool-
             invoked subagent — regardless of naming convention. This is the
             primary signal; works for any verb in any language.
          5. Suffix heuristic — chain names ending in `_agent`. Last-resort
             fallback for cases where the chain is invoked directly (not via
             a tool) and the customer hasn't passed an explicit list.
        """
        if not name:
            return False
        if name in self._HEURISTIC_NON_SUBAGENT_CHAINS:
            return False
        if name in self._NOISE_CHAINS:
            return False
        if name in self._subagent_chain_names:
            return True
        if self._chain_parent_is_tool(parent_run_id):
            return True
        return name.endswith("_agent")

    def _chain_parent_is_tool(self, parent_run_id: Optional[Any]) -> bool:
        """Whether the chain's nearest real-span ancestor is a tool.

        Uses LangChain's run-id parent relationship (the SDK equivalent of an
        OTel parent_span_id walk): we kept a record of which run_ids belong
        to live tool spans in `_tool_run_ids`. If the chain's parent resolves
        to one of those, the chain is structurally that tool's subroutine.

        Known limitations:
          - LangGraph can insert noise chains (RunnableSequence, etc.) between
            a tool call and the subagent chain. We deliberately don't track
            noise chains in `_chain_parents`, so the walk-up can stop short.
            Customers hit by this can fall back to `subagent_chain_names`.
          - Tools that legitimately invoke a non-noise internal chain for
            data shaping (not a real subagent) would be misclassified. In
            practice these internal chains are usually noise types and get
            filtered before reaching here.
          - Async parallel tool calls: parent_run_id resolution depends on
            LangChain's context propagation. For unusual orchestrators this
            may be lossy.
        """
        if not parent_run_id:
            return False
        resolved = self._resolve_parent_run_id(str(parent_run_id))
        return bool(resolved and resolved in self._tool_run_ids)

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        name = self._chain_name(serialized)

        # Skip emitting a SUBAGENT_REQUEST when this chain is firing inside a
        # routing tool that already has one (we emitted it in on_tool_start).
        # The inner chain still becomes a useful waypoint — register it in
        # `_chain_parents` so its child LLM/tool spans can resolve through it
        # — but we don't want two SUBAGENT rows for one dispatch.
        if parent_run_id and str(parent_run_id) in self._routing_tool_subagent_spans:
            self._chain_parents[key] = str(parent_run_id)
            return

        # Subagent chains get a real span so child LLM/tool calls nest under
        # the subagent in the trace tree (APP-153559). Without this, the
        # subagent's children parented to whatever closest-real-ancestor we
        # could find — typically the routing tool that initiated the subagent.
        if self._is_subagent_chain(name, parent_run_id=parent_run_id):
            self._start_span(
                run_id,
                f"subagent.{name}",
                "SUBAGENT_REQUEST",
                {
                    "tool.name": name,
                    "pendo.subagents_used": [name],
                },
                parent_run_id=parent_run_id,
            )
            # Accumulate at the turn level too so the agent_response wire event
            # carries the full set under agentSubagentsUsed (dedupe; insertion-
            # order preserved for deterministic output).
            if name and name not in self._turn_subagents:
                self._turn_subagents.append(name)
            # Subagent run_ids are tracked in _spans (via _start_span) — no
            # need to also stash them in _chain_parents.
            return

        # Noise chains (LangGraph routing/infrastructure) are NOT recorded as
        # parent waypoints. If we tracked them, _resolve_parent_run_id would
        # walk through them and could pick up an earlier sibling tool span as
        # the "closest real ancestor", causing an LLM call inside a routing
        # node (e.g. a next-action classifier) to render under the previous
        # tool span instead of the supervisor.
        # Skipping them lets child spans fall back to the root turn span.
        if name in self._NOISE_CHAINS:
            return

        # Regular chains (custom user-defined) — record the parent so child
        # LLM/tool spans can traverse up if needed.
        self._chain_parents[key] = str(parent_run_id) if parent_run_id else None

    def on_chain_end(
        self,
        outputs: Any,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self._chain_parents.pop(str(run_id), None)
        self._end_span(run_id)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self._chain_parents.pop(str(run_id), None)
        self._end_span(run_id, error=str(error))

    # ---- Required no-op callbacks ----

    def on_text(self, text: str, **kwargs: Any) -> None:
        pass

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        pass

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        pass

    def on_retry(self, retry_state: Any, **kwargs: Any) -> None:
        pass

    def on_llm_new_token(self, token: str, **kwargs: Any) -> None:
        pass
