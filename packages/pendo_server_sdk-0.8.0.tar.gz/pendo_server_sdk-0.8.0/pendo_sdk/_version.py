from importlib.metadata import version

__version__ = version("pendo-server-sdk")
