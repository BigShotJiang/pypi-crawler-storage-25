"""
SDK Initialization

Single entry point customers call. One line sets up the entire OTel pipeline:
TracerProvider -> BatchSpanProcessor -> PendoSpanExporter -> OTLP HTTP POST.

The agent thread never blocks on export. BatchSpanProcessor buffers completed
spans in memory and flushes asynchronously on a background thread.
"""

import contextlib
import logging
import warnings
from typing import Any, Generator, List, Optional

from ._version import __version__

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from .exporter import PendoSpanExporter
from .patchers import patch_all, unpatch_all

logger = logging.getLogger("pendo_sdk")

_SDK_NAME = "pendo_sdk"
_SDK_VERSION = __version__
_DEFAULT_ENDPOINT = "https://app.pendo.io"
_DEFAULT_BATCH_SIZE = 512
_DEFAULT_FLUSH_INTERVAL_MS = 2000

# Module-level state
_provider: Optional[TracerProvider] = None
_exporter: Optional[PendoSpanExporter] = None
_initialized: bool = False
_visitor_id: Optional[str] = None
_account_id: Optional[str] = None


def _is_noop_provider(provider: trace.TracerProvider) -> bool:
    return isinstance(provider, trace.ProxyTracerProvider)


def init(
        api_key: str,
        agent_id: str,
        *,
        project_id: Optional[str] = None,
        redact: bool = False,
        visitor_id: Optional[str] = None,
        account_id: Optional[str] = None,
        endpoint: Optional[str] = None,
        url: Optional[str] = None,
        auto_patch: bool = True,
        batch_size: int = _DEFAULT_BATCH_SIZE,
        flush_interval_ms: int = _DEFAULT_FLUSH_INTERVAL_MS,
) -> None:
    """
    Initialize the Pendo Agent tracing SDK.

    This is the only setup the customer needs. Sets up the OTel TracerProvider,
    the BatchSpanProcessor, and optionally activates monkey-patching.

    Args:
        api_key: Required. Pendo API key, sent as X-API-Key on OTLP export.
        agent_id: Required. Stable identifier for the agent this SDK instance is
            instrumenting. Stamped on every emitted event as `props.agentId` and
            used by Pendo to group traces, conversations, and reactions per agent
            in agent analytics.
        project_id: Maps to OTel Resource `service.name`. Useful for grouping
            multiple SDK instances in a multi-agent system at the OTel level.
            Defaults to "default". Distinct from `agent_id`: `project_id` is
            the subscription ID, while `agent_id` is the Pendo agent analytics key.
        redact: Enable PII redaction (email, phone, SSN) on event content before
            network export. Default False.
        visitor_id: Pendo visitor ID. Injected as `pendo.visitor_id` on every
            span. Identifies the end user interacting with the agent. (normally user email)
        account_id: Pendo account ID. Injected as `pendo.account_id` on every
            span. Identifies the account/tenant the visitor belongs to.
        endpoint: Pendo *ingestion* base URL — where events are POSTed. Default
            "https://app.pendo.io". Only override for non-prod stacks (eu, dev,
            stage). The SDK appends `/data/agenticsdk/<api_key>` to this.
        url: A per-event metadata tag stamped on every event as `props.url`.
            Describes *where the agent runs* (e.g. "https://app.customer.com")
            — purely informational, not a network destination. This is *not* a
            substitute for `endpoint`: `endpoint` controls where data goes,
            `url` describes where it came from.
        auto_patch: Monkey-patch supported LLM client libraries (Anthropic,
            OpenAI, LangChain, …) at init time so calls are auto-traced.
            Default True. Set False if you want to instrument manually.
        batch_size: Max spans per export batch. Default 512.
        flush_interval_ms: How often the BatchSpanProcessor flushes buffered
            spans, in milliseconds. Default 2000.
    """
    global _provider, _exporter, _initialized, _visitor_id, _account_id

    if not api_key:
        raise ValueError("api_key is required")
    if not agent_id:
        raise ValueError("agent_id is required")

    # Step 1: Check if TracerProvider has already been set. If so, warn and return.
    if _initialized:
        warnings.warn(
            "pendo_sdk.init() has already been called. "
            "Ignoring duplicate initialization.",
            stacklevel=2,
        )
        return

    current_provider = trace.get_tracer_provider()
    if not _is_noop_provider(current_provider):
        warnings.warn(
            "A TracerProvider is already registered globally. "
            "pendo_sdk will not override it. Call pendo_sdk.shutdown() first "
            "if you want to re-initialize.",
            stacklevel=2,
        )
        return

    # Step 2: Create the Resource. Tags every span with project identity.
    resolved_project_id = project_id or "default"
    resource = Resource.create({
        "service.name": resolved_project_id,
        "pendo.sdk.name": _SDK_NAME,
        "pendo.sdk.version": _SDK_VERSION,
    })

    # Step 3: Create the TracerProvider.
    _provider = TracerProvider(resource=resource)

    # Step 4: Create the PendoSpanExporter.
    resolved_endpoint = endpoint or _DEFAULT_ENDPOINT
    _exporter = PendoSpanExporter(
        api_key=api_key,
        endpoint=resolved_endpoint,
        redact_pii=redact,
        visitor_id=visitor_id,
        account_id=account_id,
        agent_id=agent_id,
        url=url,
    )

    # Step 5: Attach the BatchSpanProcessor.
    # Buffers completed spans in memory and flushes asynchronously on a
    # background thread. The agent thread never blocks on network I/O.
    processor = BatchSpanProcessor(
        _exporter,
        max_export_batch_size=batch_size,
        schedule_delay_millis=flush_interval_ms,
    )
    _provider.add_span_processor(processor)

    # Step 6: Set as the process-wide global TracerProvider.
    # All subsequent trace.get_tracer() calls will use this.
    trace.set_tracer_provider(_provider)

    # Step 7: Persist identity. Injected as span attributes on every span.
    _visitor_id = visitor_id
    _account_id = account_id

    # Step 8: Activate monkey-patching if requested.
    if auto_patch:
        _auto_patch_clients()
        _setup_langchain_handler(visitor_id, account_id)

    # Step 9: Mark init complete.
    _initialized = True

    logger.info(
        "Pendo Agent SDK initialized. project=%s endpoint=%s",
        resolved_project_id,
        resolved_endpoint,
    )


def _auto_patch_clients() -> None:
    """
    Detect installed LLM client libraries and monkey-patch them.

    Uses the patcher registry to apply all registered patchers. Each patcher
    checks if its library is importable before patching — missing libraries
    are silently skipped.
    """
    patched = patch_all()
    if patched:
        logger.info("Auto-patched: %s", ", ".join(patched))


def _setup_langchain_handler(
        visitor_id: Optional[str] = None,
        account_id: Optional[str] = None,
) -> None:
    """Set up a global LangChain callback handler if LangChain was patched.

    Creates a PendoCallbackHandler with auto_turn=True and registers it
    in the LangChain contextvar. This means any LangChain invoke/astream
    call will automatically be traced — zero additional code needed.

    For multi-tenant servers where visitor_id changes per request, use
    set_context() instead — it creates a per-request handler that
    overrides this global one.
    """
    try:
        from .patchers.langchain import pendo_callback_var
        from .patchers.registry import get_registry

        # Only set up if LangChain was actually patched
        registry = get_registry()
        if "langchain" not in registry:
            return

        # Check if langchain patcher actually ran successfully
        from .patchers.registry import _active_unpatchers
        if "langchain" not in _active_unpatchers:
            return

        from .langchain_callback import PendoCallbackHandler

        handler = PendoCallbackHandler(
            visitor_id=visitor_id,
            account_id=account_id,
            auto_turn=True,
        )
        pendo_callback_var.set(handler)
        logger.info("LangChain auto-tracing enabled (auto_turn=True)")
    except Exception:
        logger.debug("Could not set up LangChain auto-handler", exc_info=True)


def get_tracer(name: Optional[str] = None) -> trace.Tracer:
    """
    Convenience wrapper for trace.get_tracer().

    Returns a Tracer bound to the global TracerProvider. Use this to create
    spans via context managers:

        tracer = pendo_sdk.get_tracer()
        with tracer.start_as_current_span("my_operation") as span:
            span.set_attribute("type", "CHAIN")
            ...

    Args:
        name: Tracer name. Defaults to "pendo_sdk".
    """
    return trace.get_tracer(name or _SDK_NAME)


def get_visitor_id() -> Optional[str]:
    """Return the configured visitor ID, or None if not set."""
    return _visitor_id


def get_account_id() -> Optional[str]:
    """Return the configured account ID, or None if not set."""
    return _account_id


def flush() -> None:
    """Force-flush all buffered spans immediately."""
    if _provider:
        _provider.force_flush()


@contextlib.contextmanager
def langchain_turn(
        *,
        visitor_id: Optional[str] = None,
        account_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        message_id: Optional[str] = None,
        files: Optional[List[Any]] = None,
        suggested_prompt: bool = False,
) -> Generator:
    """Context manager that handles the full LangChain turn lifecycle.

    Creates a per-request PendoCallbackHandler with identity and conversation
    context, starts a turn, and yields the handler. On exit (including errors),
    ends the turn and flushes buffered spans.

    Usage::

        with pendo_sdk.langchain_turn(
            visitor_id=user.email,
            account_id=user.org_id,
            conversation_id=thread_id,
            message_id=assistant_message_id,
            files=[{"type": "csv", "name": "sales.csv"}],
        ) as handler:
            response = agent.invoke(
                {"input": message},
                config={"callbacks": [handler]},
            )

    The yielded handler is a ``PendoCallbackHandler`` that can be passed
    to any LangChain ``.invoke()``, ``.astream()``, or ``AgentExecutor``
    callbacks list. It automatically traces LLM calls, tool calls, and
    emits prompt / agent_response conversation events.

    Identity (visitor_id, account_id) is stamped on every span at creation
    time, so concurrent requests never cross-contaminate.

    ``message_id`` (optional) is the FE-generated id for the assistant
    response this turn will produce. Stamped on the agent_response event
    so a later ``record_reaction(message_id=...)`` can pair with it.

    ``files`` (optional) is the list of files the user attached to this
    turn. Each entry is a ``{"type": str, "name": str}`` dict (or a
    ``ContextItem`` instance). Surfaces on the agent_response event as
    ``agentFilesUploaded`` — backend splits it into the documented
    ``agentFilesUploadedNames`` / ``agentFilesUploadedTypes`` columns.
    """
    from .langchain_callback import PendoCallbackHandler

    if not _initialized:
        logger.warning(
            "pendo_sdk.langchain_turn() called before init(). "
            "Call pendo_sdk.init() first. Yielding a no-op handler."
        )
        yield None
        return

    handler = PendoCallbackHandler(
        conversation_id=conversation_id,
        visitor_id=visitor_id,
        account_id=account_id,
        suggested_prompt=suggested_prompt,
        message_id=message_id,
        files=files,
    )
    handler.start_turn()
    try:
        yield handler
    finally:
        handler.end_turn()
        flush()


@contextlib.contextmanager
def set_context(
        *,
        visitor_id: Optional[str] = None,
        account_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        message_id: Optional[str] = None,
        files: Optional[List[Any]] = None,
        suggested_prompt: bool = False,
) -> Generator:
    """Set per-request context for automatic LangChain tracing.

    Creates a per-request PendoCallbackHandler and registers it with
    LangChain's callback system via a contextvar. All LangChain calls
    within this context (``invoke()``, ``astream()``, sub-agent calls)
    are automatically traced — no ``callbacks=[handler]`` needed.

    Handles the full turn lifecycle: ``start_turn()`` on entry,
    ``end_turn()`` + ``flush()`` on exit (including errors).

    Usage::

        pendo_sdk.init(api_key="...", agent_id="...")

        # Per request:
        with pendo_sdk.set_context(
            visitor_id=user.email,
            account_id=user.org_id,
            conversation_id=thread_id,
        ):
            response = agent.invoke({"input": message})
            # That's it — callbacks are auto-injected by LangChain.

    Requires ``langchain-core`` to be installed and ``auto_patch=True``
    (the default) in ``init()``. The LangChain patcher registers a
    configure hook that reads the handler from the contextvar.

    The handler is also yielded for cases where you need to pass it
    explicitly (e.g., to a sub-process or custom runner)::

        with pendo_sdk.set_context(visitor_id=...) as handler:
            custom_runner(callback=handler)
    """
    from .langchain_callback import PendoCallbackHandler
    from .patchers.langchain import pendo_callback_var

    if not _initialized:
        logger.warning(
            "pendo_sdk.set_context() called before init(). "
            "Call pendo_sdk.init() first."
        )
        yield None
        return

    handler = PendoCallbackHandler(
        conversation_id=conversation_id,
        visitor_id=visitor_id,
        account_id=account_id,
        suggested_prompt=suggested_prompt,
        message_id=message_id,
        files=files,
    )
    handler.start_turn()

    # Set the contextvar so LangChain's configure hook auto-injects it.
    token = pendo_callback_var.set(handler)
    try:
        yield handler
    finally:
        pendo_callback_var.reset(token)
        handler.end_turn()
        flush()


def record_reaction(
        *,
        conversation_id: str,
        reaction_type: str,
        message_id: str,
        feedback_comment: Optional[str] = None,
        visitor_id: Optional[str] = None,
        account_id: Optional[str] = None,
) -> None:
    """Record a user reaction (thumbs up/down, copy, retry, edit) to a message.

    Reactions arrive asynchronously from the UI — typically a separate HTTP
    request fired when the user clicks a feedback button — so this is a
    standalone emitter that does not need to be inside a ``langchain_turn`` /
    ``set_context`` block. The reaction is linked to the conversation via
    ``conversation_id`` and to the specific message via ``message_id``, which
    must equal the messageId previously stamped on the agent_response (passed
    in via ``langchain_turn(message_id=...)`` / ``set_context(message_id=...)``).
    Matching messageIds is how the FE pairs the reaction with its target —
    same mechanism the web SDK uses.

    Args:
        conversation_id: The conversation this reaction belongs to.
        reaction_type: One of the values from ``ReactionType`` (``thumbs_up``,
            ``thumbs_down``, ``unreact``, ``copy``, ``retry``, ``edit``).
            Accepts either the enum or its string value.
        message_id: ID of the message being reacted to. Must equal the
            messageId the FE has for that message (and stamped on the
            corresponding agent_response).
        feedback_comment: Free-text comment accompanying a thumbs-up/-down.
        visitor_id / account_id: Pendo identity for the user submitting the
            reaction. Falls back to the identity passed to ``init()``.

    Usage::

        # In Leo's reaction webhook / endpoint:
        pendo_sdk.record_reaction(
            conversation_id=thread_id,
            reaction_type=pendo_sdk.ReactionType.THUMBS_DOWN,
            message_id=assistant_message_id,
            feedback_comment="didn't answer my question",
            visitor_id=user.email,
            account_id=user.org_id,
        )
    """
    if not _initialized:
        logger.warning(
            "pendo_sdk.record_reaction() called before init(). "
            "Call pendo_sdk.init() first. Reaction dropped."
        )
        return

    tracer = trace.get_tracer(_SDK_NAME)
    span = tracer.start_span("user.reaction")
    span.set_attribute("pendo.span.type", "REACTION")
    span.set_attribute("message.role", "user")
    if conversation_id:
        span.set_attribute("pendo.conversation_id", conversation_id)
    # Coerce enum → string value so the exporter's attrs.get() sees the raw
    # wire value (e.g. "thumbs_up") rather than a Python enum repr.
    reaction_value = getattr(reaction_type, "value", reaction_type)
    span.set_attribute("reaction.type", str(reaction_value))
    span.set_attribute("pendo.message_id", str(message_id))
    if feedback_comment:
        span.set_attribute("reaction.feedback_comment", str(feedback_comment))
    resolved_visitor = visitor_id or _visitor_id
    resolved_account = account_id or _account_id
    if resolved_visitor:
        span.set_attribute("pendo.visitor_id", resolved_visitor)
    if resolved_account:
        span.set_attribute("pendo.account_id", resolved_account)
    span.end()
    flush()


def shutdown() -> None:
    """Flush remaining spans and shut down the SDK.

    After shutdown, init() can be called again to re-initialize.
    """
    global _provider, _exporter, _initialized, _visitor_id, _account_id
    if _provider:
        unpatch_all()
        _provider.shutdown()
        _provider = None
        _exporter = None
        _initialized = False
        _visitor_id = None
        _account_id = None
        logger.info("Pendo Agent SDK shut down.")
