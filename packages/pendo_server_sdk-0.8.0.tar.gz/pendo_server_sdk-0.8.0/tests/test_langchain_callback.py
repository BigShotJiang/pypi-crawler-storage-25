"""Tests for PendoCallbackHandler classification and nesting (APP-153559).

These cover the data-quality fixes called out by the AA-vs-LangSmith review:

- `call_*` / `handoff_*` routing tools must classify as TOOL_REQUEST, not
  SUBAGENT_REQUEST.
- Subagent chains named in `subagent_chain_names` (or matching the `_agent`
  suffix heuristic) must emit a SUBAGENT_REQUEST span so child LLM/tool
  calls nest under them in the trace tree.
- The supervisor chain must not be misclassified as a subagent.
- Noise chains (`next_actions_node`, `tool_node`, …) must NOT be tracked as
  parent waypoints — child LLM calls inside them should fall back to the
  root turn span instead of inheriting a sibling tool's parent.
"""

import uuid

import pytest
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
    InMemorySpanExporter,
)

from pendo_sdk.langchain_callback import (
    PendoCallbackHandler,
    _extract_tool_names,
    _normalize_files,
)


@pytest.fixture(autouse=True)
def memory_exporter():
    """Per-test TracerProvider with an in-memory exporter.

    Mirrors the pattern in tests/test_decorators.py — OTel's
    `set_tracer_provider` is set-once globally, so we reset the underlying
    sentinels on teardown so the next test can install its own provider.
    """
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    yield exporter
    provider.shutdown()
    trace._TRACER_PROVIDER = None  # type: ignore[attr-defined]
    trace._TRACER_PROVIDER_SET_ONCE._done = False  # type: ignore[attr-defined]


def _attr(span, key):
    """Read an attribute off a finished ReadableSpan, tolerating missing keys."""
    return (span.attributes or {}).get(key)


class TestRoutingToolNotSubagent:
    """`call_quantitative_agent` is a tool, not a subagent (APP-153559 #1)."""

    def test_call_prefix_classifies_as_tool(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        handler.on_tool_start(
            {"name": "call_quantitative_agent"},
            "{}",
            run_id=uuid.uuid4(),
            parent_run_id=None,
        )
        # End the turn so spans flush to the in-memory exporter.
        # We don't need to call on_tool_end — start_turn → end_turn is
        # enough to flush whatever spans were created so far via OTel.
        # But _end_span on the tool gives a clean span lifecycle:
        run_id = list(handler._spans.keys())[0]
        handler.on_tool_end("ok", run_id=run_id)
        handler.end_turn()

        tool_spans = [
            s for s in memory_exporter.get_finished_spans()
            if s.name.startswith("tool.")
        ]
        assert tool_spans, "expected a tool span to be emitted"
        assert _attr(tool_spans[0], "pendo.span.type") == "TOOL_REQUEST"
        # The routing tool itself is not the subagent — no subagents_used.
        assert _attr(tool_spans[0], "pendo.subagents_used") is None

    def test_handoff_prefix_classifies_as_tool(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_tool_start(
            {"name": "handoff_to_artifacts"},
            "{}",
            run_id=run_id,
            parent_run_id=None,
        )
        handler.on_tool_end("ok", run_id=run_id)
        handler.end_turn()

        tool_spans = [
            s for s in memory_exporter.get_finished_spans()
            if s.name.startswith("tool.")
        ]
        assert _attr(tool_spans[0], "pendo.span.type") == "TOOL_REQUEST"


class TestRoutingToolEmitsSubagent:
    """A `call_*` / `handoff_*` tool invocation is, by convention, a subagent
    dispatch. The SDK must emit a SUBAGENT_REQUEST span keyed off the tool
    name itself — no allow-list required, no dependency on the inner chain
    firing with a recognizable name. This is what lets the trace tree show
    "routing tool → Agent Analytics Agent → inner LLM/tools" for any
    customer's subagent without configuration.
    """

    def _subagent_spans(self, exporter):
        return [
            s for s in exporter.get_finished_spans()
            if s.name.startswith("subagent.")
        ]

    def test_call_prefix_emits_synthetic_subagent_span(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_tool_start(
            {"name": "call_agent_analytics_agent"},
            "{}",
            run_id=run_id,
            parent_run_id=None,
        )
        handler.on_tool_end("ok", run_id=run_id)
        handler.end_turn()

        subs = self._subagent_spans(memory_exporter)
        assert len(subs) == 1
        assert subs[0].name == "subagent.agent_analytics_agent"
        assert _attr(subs[0], "pendo.span.type") == "SUBAGENT_REQUEST"
        assert _attr(subs[0], "tool.name") == "agent_analytics_agent"

    def test_handoff_prefix_emits_synthetic_subagent_span(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_tool_start(
            {"name": "handoff_to_legal"},
            "{}",
            run_id=run_id,
            parent_run_id=None,
        )
        handler.on_tool_end("ok", run_id=run_id)
        handler.end_turn()

        subs = self._subagent_spans(memory_exporter)
        assert len(subs) == 1
        assert _attr(subs[0], "tool.name") == "to_legal"

    def test_plain_tool_does_not_emit_subagent(self, memory_exporter):
        """Regular tools (no `call_` / `handoff_` prefix) stay as plain
        TOOL_REQUEST spans — we don't speculatively wrap every tool."""
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_tool_start(
            {"name": "search_db"},
            "{}",
            run_id=run_id,
            parent_run_id=None,
        )
        handler.on_tool_end("ok", run_id=run_id)
        handler.end_turn()

        assert self._subagent_spans(memory_exporter) == []

    def test_inner_spans_nest_under_subagent_not_tool(self, memory_exporter):
        """Children of the routing tool (an inner LLM call, an inner tool)
        re-parent onto the synthetic SUBAGENT span — that's what gives the
        FE the structural depth to render the subagent as its own row with
        descendants underneath."""
        handler = PendoCallbackHandler()
        handler.start_turn()

        tool_run = uuid.uuid4()
        handler.on_tool_start(
            {"name": "call_agent_analytics_agent"},
            "{}",
            run_id=tool_run,
            parent_run_id=None,
        )

        # An inner LLM call dispatched by the subagent.
        llm_run = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-5.2"}},
            [[]],
            run_id=llm_run,
            parent_run_id=tool_run,
        )
        handler.on_llm_end(
            type("Resp", (), {"generations": [[]], "llm_output": {}})(),
            run_id=llm_run,
        )

        handler.on_tool_end("ok", run_id=tool_run)
        handler.end_turn()

        spans = memory_exporter.get_finished_spans()
        subagent_span = next(s for s in spans if s.name.startswith("subagent."))
        llm_spans = [s for s in spans if s.name.startswith("llm.")]
        assert llm_spans, "expected an LLM span"

        # The LLM's OTel parent must be the SUBAGENT, not the routing TOOL.
        llm_parent = llm_spans[0].parent
        assert llm_parent is not None
        assert llm_parent.span_id == subagent_span.context.span_id

    def test_inner_chain_does_not_double_emit_subagent(self, memory_exporter):
        """If LangChain ALSO fires `on_chain_start` for the inner subagent
        chain (with a recognizable name), we don't emit a second
        SUBAGENT_REQUEST — the routing-tool emit takes precedence. Avoids
        showing two stacked "Agent Analytics Agent" rows in the trace."""
        handler = PendoCallbackHandler(
            subagent_chain_names=["agent_analytics_agent"],
        )
        handler.start_turn()

        tool_run = uuid.uuid4()
        handler.on_tool_start(
            {"name": "call_agent_analytics_agent"},
            "{}",
            run_id=tool_run,
            parent_run_id=None,
        )
        chain_run = uuid.uuid4()
        handler.on_chain_start(
            {"name": "agent_analytics_agent"},
            {},
            run_id=chain_run,
            parent_run_id=tool_run,
        )
        handler.on_chain_end({}, run_id=chain_run)
        handler.on_tool_end("ok", run_id=tool_run)
        handler.end_turn()

        subs = self._subagent_spans(memory_exporter)
        assert len(subs) == 1, [s.name for s in subs]
        # Exactly one subagent row for the dispatch.

    def test_subagent_added_to_turn_rollup(self, memory_exporter):
        """The routing-tool inference also feeds the turn-level rollup so
        agent_response's `agentSubagentsUsed` lists the subagent even when
        no chain ever fired."""
        handler = PendoCallbackHandler()
        handler.start_turn()

        tool_run = uuid.uuid4()
        handler.on_tool_start(
            {"name": "call_quantitative_agent"},
            "{}",
            run_id=tool_run,
            parent_run_id=None,
        )
        handler.on_tool_end("ok", run_id=tool_run)

        # An LLM response so end_turn emits the agent.response span we can
        # assert against.
        llm_run = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=llm_run,
            parent_run_id=None,
        )

        class _Msg:
            content = "done"
            id = "lc-1"
            tool_calls = []

        class _Gen:
            text = "done"
            message = _Msg()

        handler.on_llm_end(
            type("Resp", (), {"generations": [[_Gen()]], "llm_output": {}})(),
            run_id=llm_run,
        )
        handler.end_turn()

        agent_resp = next(
            (s for s in memory_exporter.get_finished_spans()
             if s.name == "agent.response"),
            None,
        )
        assert agent_resp is not None
        assert "quantitative_agent" in (_attr(agent_resp, "pendo.subagents_used") or ())


class TestSubagentChainEmitsSpan:
    """Subagent chains emit a SUBAGENT_REQUEST span (APP-153559 #2, #4)."""

    def test_explicit_list_emits_subagent_span(self, memory_exporter):
        handler = PendoCallbackHandler(
            subagent_chain_names=["quantitative_agent", "artifacts_agent"],
        )
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "quantitative_agent"},
            {},
            run_id=run_id,
            parent_run_id=None,
        )
        handler.on_chain_end({}, run_id=run_id)
        handler.end_turn()

        sub_spans = [
            s for s in memory_exporter.get_finished_spans()
            if s.name.startswith("subagent.")
        ]
        assert sub_spans, "expected a subagent span to be emitted"
        assert _attr(sub_spans[0], "pendo.span.type") == "SUBAGENT_REQUEST"
        assert _attr(sub_spans[0], "pendo.subagents_used") == (
            "quantitative_agent",
        )

    def test_suffix_heuristic_treats_underscore_agent_as_subagent(
        self, memory_exporter
    ):
        handler = PendoCallbackHandler()  # no explicit list
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "research_agent"},
            {},
            run_id=run_id,
            parent_run_id=None,
        )
        handler.on_chain_end({}, run_id=run_id)
        handler.end_turn()

        sub_spans = [
            s for s in memory_exporter.get_finished_spans()
            if s.name.startswith("subagent.")
        ]
        assert sub_spans
        assert _attr(sub_spans[0], "tool.name") == "research_agent"

    def test_supervisor_agent_not_classified_as_subagent(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "supervisor_agent"},
            {},
            run_id=run_id,
            parent_run_id=None,
        )
        handler.on_chain_end({}, run_id=run_id)
        handler.end_turn()

        # The supervisor is the orchestrator, not a subagent — it should not
        # produce a SUBAGENT_REQUEST span (would otherwise wrap the whole turn
        # with a redundant "supervisor_agent" subagent in the trace tree).
        sub_spans = [
            s for s in memory_exporter.get_finished_spans()
            if s.name.startswith("subagent.")
        ]
        assert sub_spans == []


class TestSubagentDetectedStructurally:
    """A chain whose parent in the LangChain call graph is an active TOOL
    span IS that tool's subroutine — a routing-tool-invoked subagent — by
    definition, regardless of what either was named. We classify it as
    a subagent without any string/prefix matching.

    This replaces an earlier prefix-list approach (`call_*`, `handoff_*`,
    `transfer_to_*`, etc.) that only worked for hard-coded English routing
    verbs. The structural signal works for any verb, any language, any
    naming convention the customer chooses.
    """

    def _subagent_span_names(self, memory_exporter):
        return [
            _attr(s, "tool.name") for s in memory_exporter.get_finished_spans()
            if s.name.startswith("subagent.")
        ]

    def _fire_tool_then_child_chain(self, handler, tool_name, chain_name):
        """Simulate the LangChain callback sequence for `tool → chain`.

        Note: chain fires WHILE the tool is still in-flight (parent_run_id
        points to the tool's run_id, tool hasn't ended yet). This matches
        the order LangChain actually invokes callbacks in.
        """
        handler.start_turn()
        tool_run = uuid.uuid4()
        handler.on_tool_start(
            {"name": tool_name}, "{}", run_id=tool_run, parent_run_id=None,
        )
        chain_run = uuid.uuid4()
        handler.on_chain_start(
            {"name": chain_name}, {}, run_id=chain_run, parent_run_id=tool_run,
        )
        handler.on_chain_end({}, run_id=chain_run)
        handler.on_tool_end("done", run_id=tool_run)
        handler.end_turn()

    def test_chain_parented_by_tool_is_classified_as_subagent(self, memory_exporter):
        # `researcher` does NOT end in `_agent`. The only signal that it's a
        # subagent is that its parent is an active tool span. No naming
        # convention assumed.
        handler = PendoCallbackHandler()
        self._fire_tool_then_child_chain(handler, "call_researcher", "researcher")
        assert "researcher" in self._subagent_span_names(memory_exporter)

    def test_works_for_arbitrary_routing_verbs(self, memory_exporter):
        # No hard-coded prefix list — `dispatch`, `consult`, `ask`, anything
        # works as long as the chain's parent is the tool. Tests three
        # different verbs in one go.
        for tool, chain in [
            ("dispatch_writer", "writer"),
            ("consult_legal", "legal"),
            ("ask_the_expert", "expert"),
        ]:
            mem = memory_exporter
            handler = PendoCallbackHandler()
            self._fire_tool_then_child_chain(handler, tool, chain)
            assert chain in self._subagent_span_names(mem), \
                f"expected {chain!r} as subagent for tool {tool!r}"

    def test_supervisor_never_demoted_even_if_parented_by_tool(self, memory_exporter):
        # If a customer somehow has a tool whose child chain is named
        # `supervisor`, supervisor must NOT be demoted — the
        # NON_SUBAGENT_CHAINS allowlist takes precedence over the structural
        # signal.
        handler = PendoCallbackHandler()
        self._fire_tool_then_child_chain(handler, "weird_tool", "supervisor")
        assert "supervisor" not in self._subagent_span_names(memory_exporter)

    def test_noise_chain_never_promoted_even_if_parented_by_tool(self, memory_exporter):
        # Tools sometimes invoke internal RunnableSequence / RunnableLambda
        # for data shaping. These must NOT be classified as subagents even
        # though they're parented by a tool.
        handler = PendoCallbackHandler()
        self._fire_tool_then_child_chain(handler, "search_db", "RunnableSequence")
        assert self._subagent_span_names(memory_exporter) == []

    def test_chain_with_no_tool_parent_falls_back_to_suffix_heuristic(self, memory_exporter):
        # Direct invocation pattern: chain runs without a parent tool. We
        # still classify it as a subagent via the `_agent` suffix heuristic
        # so customers using direct-invoke patterns aren't forced to declare.
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "research_agent"}, {}, run_id=run_id, parent_run_id=None,
        )
        handler.on_chain_end({}, run_id=run_id)
        handler.end_turn()
        assert "research_agent" in self._subagent_span_names(memory_exporter)


class TestNoiseChainsNotTrackedAsParents:
    """`next_actions_node` and friends must not parent child LLM calls
    (APP-153559 #4c, Scenario 3). Otherwise children resolve through the
    chain hierarchy and pick up the previous tool's span as a parent."""

    def test_next_actions_node_skipped_from_chain_parents(self):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "next_actions_node"},
            {},
            run_id=run_id,
            parent_run_id=None,
        )
        # The noise chain must not be recorded as a waypoint, otherwise
        # children inside it would walk up through it during parent
        # resolution.
        assert str(run_id) not in handler._chain_parents
        handler.end_turn()

    def test_tool_node_skipped_from_chain_parents(self):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "tool_node"},
            {},
            run_id=run_id,
            parent_run_id=None,
        )
        assert str(run_id) not in handler._chain_parents
        handler.end_turn()

    def test_llm_inside_next_actions_node_does_not_inherit_sibling_tool(
        self, memory_exporter
    ):
        """The headline regression: an LLM call fired inside `next_actions_node`
        must NOT end up parented to a sibling routing-tool span. Before the
        fix it did, because next_actions_node was tracked in `_chain_parents`
        and parent resolution walked up through it to find the most recent
        real span — which happened to be the prior `call_quantitative_agent`
        tool."""
        handler = PendoCallbackHandler()
        handler.start_turn()

        # 1. Routing tool runs and ends.
        tool_run_id = uuid.uuid4()
        handler.on_tool_start(
            {"name": "call_quantitative_agent"},
            "{}",
            run_id=tool_run_id,
            parent_run_id=None,
        )
        handler.on_tool_end("ok", run_id=tool_run_id)

        # 2. next_actions_node fires (noise chain — should not be a waypoint).
        nan_run_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "next_actions_node"},
            {},
            run_id=nan_run_id,
            parent_run_id=None,
        )

        # 3. ChatOpenAI fires inside next_actions_node.
        llm_run_id = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o-mini"}},
            [[]],  # empty messages list
            run_id=llm_run_id,
            parent_run_id=nan_run_id,
        )
        handler.on_llm_end(
            type("FakeResp", (), {"generations": [[]], "llm_output": {}})(),
            run_id=llm_run_id,
        )
        handler.on_chain_end({}, run_id=nan_run_id)
        handler.end_turn()

        # The next-actions LLM span must be parented to the conversation.turn
        # root (or top-level), NOT to the call_quantitative_agent tool.
        spans = memory_exporter.get_finished_spans()
        llm_spans = [s for s in spans if s.name.startswith("llm.")]
        tool_spans = [s for s in spans if s.name.startswith("tool.")]
        assert llm_spans, "expected an LLM span"
        assert tool_spans, "expected a tool span"
        tool_span_id = tool_spans[0].context.span_id

        for llm in llm_spans:
            parent = getattr(llm, "parent", None)
            parent_id = parent.span_id if parent else None
            assert parent_id != tool_span_id, (
                f"LLM {llm.name} was parented to the routing tool — "
                "next_actions_node should not be a waypoint"
            )


class TestExtractToolNames:
    """`_extract_tool_names` normalizes the various shapes LangChain hands
    us for tool catalogs into a flat name list (Chat Completions, Responses
    API, function-calling, BaseTool instances)."""

    def test_chat_completions_shape(self):
        tools = [
            {"type": "function", "function": {"name": "search", "description": "..."}},
            {"type": "function", "function": {"name": "lookup"}},
        ]
        assert _extract_tool_names(tools) == ["search", "lookup"]

    def test_function_calling_shape(self):
        tools = [{"name": "search"}, {"name": "lookup"}]
        assert _extract_tool_names(tools) == ["search", "lookup"]

    def test_base_tool_object_shape(self):
        class _BaseToolish:
            def __init__(self, name):
                self.name = name

        tools = [_BaseToolish("search"), _BaseToolish("lookup")]
        assert _extract_tool_names(tools) == ["search", "lookup"]

    def test_dedupes_preserving_order(self):
        tools = [{"name": "search"}, {"name": "lookup"}, {"name": "search"}]
        assert _extract_tool_names(tools) == ["search", "lookup"]

    def test_empty_or_none(self):
        assert _extract_tool_names(None) == []
        assert _extract_tool_names([]) == []

    def test_skips_unreadable_entries(self):
        tools = [{"name": "search"}, {}, None, {"function": {}}, "not a dict"]
        assert _extract_tool_names(tools) == ["search"]


class TestToolsAvailableOnLLMSpan:
    """`on_chat_model_start` should stamp `llm.tools_available` from
    invocation_params.tools / functions so the AA UI can render the
    available-tools chips alongside the used ones."""

    def _fake_msg(self, content="hi"):
        return type("Msg", (), {"type": "human", "content": content})()

    def test_invocation_params_tools_become_attribute(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[self._fake_msg()]],
            run_id=run_id,
            parent_run_id=None,
            invocation_params={
                "tools": [
                    {"type": "function", "function": {"name": "search"}},
                    {"type": "function", "function": {"name": "lookup"}},
                ],
            },
        )
        handler.on_llm_end(
            type("Resp", (), {"generations": [[]], "llm_output": {}})(),
            run_id=run_id,
        )
        handler.end_turn()

        spans = memory_exporter.get_finished_spans()
        llm_spans = [s for s in spans if s.name.startswith("llm.")]
        assert llm_spans
        assert llm_spans[0].attributes.get("llm.tools_available") == ("search", "lookup")

    def test_no_tools_means_no_attribute(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        run_id = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[self._fake_msg()]],
            run_id=run_id,
            parent_run_id=None,
            invocation_params={},
        )
        handler.on_llm_end(
            type("Resp", (), {"generations": [[]], "llm_output": {}})(),
            run_id=run_id,
        )
        handler.end_turn()

        spans = memory_exporter.get_finished_spans()
        llm_spans = [s for s in spans if s.name.startswith("llm.")]
        assert llm_spans
        # Section in the UI hides cleanly when the attribute is absent.
        assert "llm.tools_available" not in (llm_spans[0].attributes or {})


class TestToolResultReplayUnderLlm:
    """Replayed ToolMessages (no matching on_tool_end) nest under the LLM that
    consumes them, not under the turn root (APP-153559 follow-up)."""

    def test_replayed_tool_message_parented_to_consuming_llm(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()

        class _Human:
            type = "human"
            content = "read the file"

        class _AI:
            type = "ai"
            content = ""
            tool_calls = [{"name": "read_file", "id": "call_1"}]

        class _Tool:
            type = "tool"
            tool_call_id = "call_1"
            name = "read_file"
            content = "file contents here"

        r1 = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[_Human()]],
            run_id=r1,
            parent_run_id=None,
        )
        handler.on_llm_end(
            type("Resp", (), {"generations": [[]], "llm_output": {}})(),
            run_id=r1,
        )

        r2 = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[_Human(), _AI(), _Tool()]],
            run_id=r2,
            parent_run_id=None,
        )
        handler.on_llm_end(
            type("Resp", (), {"generations": [[]], "llm_output": {}})(),
            run_id=r2,
        )
        handler.end_turn()

        spans = memory_exporter.get_finished_spans()
        tool_resp = [
            s
            for s in spans
            if s.name == "tool.read_file"
            and _attr(s, "pendo.span.type") == "TOOL_RESPONSE"
        ]
        assert len(tool_resp) == 1
        parent = tool_resp[0].parent
        assert parent is not None

        consuming = next(
            (s for s in spans if s.context.span_id == parent.span_id),
            None,
        )
        assert consuming is not None
        assert consuming.name.startswith("llm.")
        assert "gpt-4o" in consuming.name


def _make_llm_result(text="ok", message_id="run-fake", input_tokens=None,
                     output_tokens=None, tool_calls=None, cache_read=None):
    """Build a LangChain-shaped LLMResult for on_llm_end."""
    class _Msg:
        def __init__(self, content, id_, tool_calls):
            self.content = content
            self.id = id_
            self.tool_calls = tool_calls or []

    class _Gen:
        def __init__(self, text, msg):
            self.text = text
            self.message = msg

    llm_output = {}
    if input_tokens is not None or output_tokens is not None or cache_read is not None:
        token_usage = {}
        if input_tokens is not None:
            token_usage["input_tokens"] = input_tokens
        if output_tokens is not None:
            token_usage["output_tokens"] = output_tokens
        if cache_read is not None:
            token_usage["input_token_details"] = {"cache_read": cache_read}
        llm_output["token_usage"] = token_usage

    return type(
        "Resp",
        (),
        {
            "generations": [[_Gen(text, _Msg(text, message_id, tool_calls))]],
            "llm_output": llm_output,
        },
    )()


class TestTurnRollupsOnAgentResponse:
    """At end_turn, the merged agent.response span carries turn-level
    rollups (subagents used, cumulative token counts) so the wire event
    surfaces the Conversations-API recommended fields without the FE
    having to walk the trace tree."""

    def _agent_response_span(self, exporter):
        return next(
            (s for s in exporter.get_finished_spans()
             if s.name == "agent.response"),
            None,
        )

    def test_subagents_accumulated_and_stamped(self, memory_exporter):
        handler = PendoCallbackHandler(
            subagent_chain_names=["quantitative_agent", "qualitative_agent"],
        )
        handler.start_turn()

        # Two distinct subagent chains run during the turn.
        for name in ("quantitative_agent", "qualitative_agent"):
            rid = uuid.uuid4()
            handler.on_chain_start(
                {"name": name}, {}, run_id=rid, parent_run_id=None,
            )
            handler.on_chain_end({}, run_id=rid)

        # An LLM response so end_turn actually emits the agent.response span
        # (it's only emitted when _turn_response_text is non-empty).
        llm_run = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=llm_run,
            parent_run_id=None,
        )
        handler.on_llm_end(_make_llm_result(text="done"), run_id=llm_run)
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert agent_resp is not None
        assert _attr(agent_resp, "pendo.subagents_used") == (
            "quantitative_agent",
            "qualitative_agent",
        )

    def test_subagents_dedupe_repeats(self, memory_exporter):
        """A subagent invoked twice in one turn appears once in the rollup."""
        handler = PendoCallbackHandler(
            subagent_chain_names=["quantitative_agent"],
        )
        handler.start_turn()
        for _ in range(2):
            rid = uuid.uuid4()
            handler.on_chain_start(
                {"name": "quantitative_agent"}, {},
                run_id=rid, parent_run_id=None,
            )
            handler.on_chain_end({}, run_id=rid)

        llm_run = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=llm_run,
            parent_run_id=None,
        )
        handler.on_llm_end(_make_llm_result(text="done"), run_id=llm_run)
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.subagents_used") == (
            "quantitative_agent",
        )

    def test_tokens_summed_across_calls(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()

        for in_t, out_t in [(100, 25), (200, 30)]:
            rid = uuid.uuid4()
            handler.on_chat_model_start(
                {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
                [[]],
                run_id=rid,
                parent_run_id=None,
            )
            handler.on_llm_end(
                _make_llm_result(
                    text="done", input_tokens=in_t, output_tokens=out_t,
                ),
                run_id=rid,
            )
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.input_token_count") == 300
        assert _attr(agent_resp, "pendo.output_token_count") == 55
        # total is computed locally as input + output (providers don't
        # always report a total_tokens field).
        assert _attr(agent_resp, "pendo.total_token_count") == 355

    def test_cache_read_tokens_summed_across_calls(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()

        for in_t, out_t, cache in [(100, 25, 40), (200, 30, 60)]:
            rid = uuid.uuid4()
            handler.on_chat_model_start(
                {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
                [[]],
                run_id=rid,
                parent_run_id=None,
            )
            handler.on_llm_end(
                _make_llm_result(
                    text="done",
                    input_tokens=in_t,
                    output_tokens=out_t,
                    cache_read=cache,
                ),
                run_id=rid,
            )
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.cache_read_token_count") == 100

    def test_tokens_include_no_stream_internal_calls(self, memory_exporter):
        """Classifier / next-action LLMs tagged ``no_stream`` by ai-connect
        STILL consume real tokens. Pendo's turn rollup must include them so
        the agent_response total matches LangSmith (which sums every call)
        and the BE conversation rollup (which sums all trace events).

        Model/tool/subagent aggregators below still skip no_stream so the
        user-facing summary stays clean — this is the inverse rule for
        billing-relevant counters."""
        handler = PendoCallbackHandler()
        handler.start_turn()

        # User-visible call.
        r1 = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=r1,
            parent_run_id=None,
        )
        handler.on_llm_end(
            _make_llm_result(text="done", input_tokens=120, output_tokens=40),
            run_id=r1,
        )

        # Internal classifier call — tokens still count.
        r2 = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o-mini"}},
            [[]],
            run_id=r2,
            parent_run_id=None,
            tags=["no_stream"],
        )
        handler.on_llm_end(
            _make_llm_result(text="{}", input_tokens=300, output_tokens=10),
            run_id=r2,
        )
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.input_token_count") == 420
        assert _attr(agent_resp, "pendo.output_token_count") == 50

        # Model from the classifier call must NOT pollute the user-facing
        # models list — different rule for the descriptive aggregator.
        models = _attr(agent_resp, "llm.model_names")
        if models is not None:
            assert "gpt-4o-mini" not in models

    def test_files_uploaded_stamped_on_agent_response(self, memory_exporter):
        """Caller-provided `files` list becomes two parallel attrs on the
        merged agent.response span. The exporter reassembles them into
        the documented `agentFilesUploaded: [{type, name}, ...]` wire shape."""
        handler = PendoCallbackHandler(
            files=[
                {"type": "csv", "name": "sales.csv"},
                {"type": "pdf", "name": "report.pdf"},
            ],
        )
        handler.start_turn()
        rid = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=rid,
            parent_run_id=None,
        )
        handler.on_llm_end(_make_llm_result(text="done"), run_id=rid)
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.files_uploaded_types") == ("csv", "pdf")
        assert _attr(agent_resp, "pendo.files_uploaded_names") == (
            "sales.csv",
            "report.pdf",
        )

    def test_files_uploaded_drops_incomplete_entries(self, memory_exporter):
        """Per the BE's contract (newagenticevent.go), entries missing
        either type or name are dropped at the SDK boundary too — keeps
        the agent.response span clean instead of pushing junk through."""
        handler = PendoCallbackHandler(
            files=[
                {"type": "csv", "name": "ok.csv"},
                {"type": "", "name": "no-type.txt"},
                {"type": "pdf", "name": ""},
                {},  # totally empty
            ],
        )
        handler.start_turn()
        rid = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=rid,
            parent_run_id=None,
        )
        handler.on_llm_end(_make_llm_result(text="done"), run_id=rid)
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.files_uploaded_types") == ("csv",)
        assert _attr(agent_resp, "pendo.files_uploaded_names") == ("ok.csv",)

    def test_files_uploaded_omitted_when_no_files(self, memory_exporter):
        handler = PendoCallbackHandler()
        handler.start_turn()
        rid = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=rid,
            parent_run_id=None,
        )
        handler.on_llm_end(_make_llm_result(text="done"), run_id=rid)
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.files_uploaded_types") is None
        assert _attr(agent_resp, "pendo.files_uploaded_names") is None

    def test_normalize_files_accepts_context_item_like(self):
        """`ContextItem`-style objects (.type / .name attrs) work alongside
        plain dicts so callers can use either shape."""
        class _CI:
            def __init__(self, t, n):
                self.type = t
                self.name = n

        normalized = _normalize_files([
            _CI("csv", "x.csv"),
            {"type": "pdf", "name": "y.pdf"},
        ])
        assert normalized == [("csv", "x.csv"), ("pdf", "y.pdf")]

    def test_tokens_omitted_when_provider_reports_none(self, memory_exporter):
        """If no LLM call returned usage, the attributes are omitted so
        the wire event drops the field rather than emitting zeros."""
        handler = PendoCallbackHandler()
        handler.start_turn()

        rid = uuid.uuid4()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI", "kwargs": {"model_name": "gpt-4o"}},
            [[]],
            run_id=rid,
            parent_run_id=None,
        )
        handler.on_llm_end(_make_llm_result(text="done"), run_id=rid)
        handler.end_turn()

        agent_resp = self._agent_response_span(memory_exporter)
        assert _attr(agent_resp, "pendo.input_token_count") is None
        assert _attr(agent_resp, "pendo.output_token_count") is None
