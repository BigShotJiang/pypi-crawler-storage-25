"""Tests for init() and core SDK lifecycle."""

import tomllib
import warnings
from pathlib import Path

import pytest
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider

import pendo_sdk
import pendo_sdk.core as core
from pendo_sdk import exporter as exporter_module


@pytest.fixture(autouse=True)
def _reset_sdk():
    """Ensure clean SDK state before and after each test."""
    core.shutdown()
    # Reset the global tracer provider to the default no-op
    trace._TRACER_PROVIDER = None
    trace._TRACER_PROVIDER_SET_ONCE._done = False
    yield
    core.shutdown()
    trace._TRACER_PROVIDER = None
    trace._TRACER_PROVIDER_SET_ONCE._done = False


class TestInit:
    def test_init_sets_global_tracer_provider(self):
        core.init(api_key="test-key", agent_id="test-agent", project_id="test-project")

        provider = trace.get_tracer_provider()
        assert isinstance(provider, TracerProvider)

    def test_init_creates_tracer_with_correct_resource(self):
        core.init(api_key="test-key", agent_id="test-agent", project_id="my-agent")

        provider = trace.get_tracer_provider()
        resource_attrs = dict(provider.resource.attributes)
        assert resource_attrs["service.name"] == "my-agent"
        assert resource_attrs["pendo.sdk.name"] == "pendo_sdk"
        assert resource_attrs["pendo.sdk.version"] == core._SDK_VERSION

    def test_init_default_project_id(self):
        core.init(api_key="test-key", agent_id="test-agent")

        provider = trace.get_tracer_provider()
        assert provider.resource.attributes["service.name"] == "default"

    def test_init_passes_agent_id_to_exporter(self):
        core.init(api_key="test-key", agent_id="my-bot")

        assert core._exporter is not None
        assert core._exporter._agent_id == "my-bot"

    def test_init_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key is required"):
            core.init(api_key="", agent_id="test-agent")

    def test_init_requires_agent_id(self):
        with pytest.raises(ValueError, match="agent_id is required"):
            core.init(api_key="test-key", agent_id="")

    def test_init_requires_agent_id_positionally(self):
        with pytest.raises(TypeError):
            core.init(api_key="test-key")  # type: ignore[call-arg]

    def test_init_warns_on_duplicate_call(self):
        core.init(api_key="test-key", agent_id="test-agent")

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            core.init(api_key="test-key", agent_id="test-agent")
            assert len(w) == 1
            assert "already been called" in str(w[0].message)

    def test_init_warns_if_provider_already_set(self):
        # Manually set a non-default provider before init
        existing_provider = TracerProvider()
        trace.set_tracer_provider(existing_provider)

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            core.init(api_key="test-key", agent_id="test-agent")
            assert len(w) == 1
            assert "already registered" in str(w[0].message)

    def test_init_stores_visitor_and_account_id(self):
        core.init(
            api_key="test-key",
            agent_id="test-agent",
            visitor_id="visitor-123",
            account_id="account-456",
        )

        assert core.get_visitor_id() == "visitor-123"
        assert core.get_account_id() == "account-456"

    def test_init_identity_defaults_to_none(self):
        core.init(api_key="test-key", agent_id="test-agent")

        assert core.get_visitor_id() is None
        assert core.get_account_id() is None


class TestShutdown:
    def test_shutdown_clears_state(self):
        core.init(
            api_key="test-key",
            agent_id="test-agent",
            visitor_id="v1",
            account_id="a1",
        )
        assert core._initialized is True

        core.shutdown()

        assert core._initialized is False
        assert core._provider is None
        assert core._exporter is None
        assert core.get_visitor_id() is None
        assert core.get_account_id() is None

    def test_shutdown_allows_reinit(self):
        core.init(api_key="key-1", agent_id="test-agent", project_id="first")
        core.shutdown()

        # Reset the global provider so init can set a new one
        trace._TRACER_PROVIDER = None
        trace._TRACER_PROVIDER_SET_ONCE._done = False

        core.init(api_key="key-2", agent_id="test-agent", project_id="second")

        provider = trace.get_tracer_provider()
        assert provider.resource.attributes["service.name"] == "second"

    def test_shutdown_is_safe_when_not_initialized(self):
        core.shutdown()  # Should not raise


class TestGetTracer:
    def test_get_tracer_returns_tracer(self):
        core.init(api_key="test-key", agent_id="test-agent")

        tracer = core.get_tracer()
        assert tracer is not None

    def test_get_tracer_custom_name(self):
        core.init(api_key="test-key", agent_id="test-agent")

        tracer = core.get_tracer("my-component")
        assert tracer is not None

    def test_get_tracer_creates_working_spans(self):
        core.init(api_key="test-key", agent_id="test-agent", project_id="test")

        tracer = core.get_tracer()
        with tracer.start_as_current_span("test-span") as span:
            span.set_attribute("type", "CHAIN")
            assert span.is_recording()


class TestFlush:
    def test_flush_when_initialized(self):
        core.init(api_key="test-key", agent_id="test-agent")
        core.flush()  # Should not raise

    def test_flush_when_not_initialized(self):
        core.flush()  # Should not raise


class TestRecordReaction:
    """record_reaction() fires a standalone REACTION span outside any active
    turn — reactions arrive async from the UI long after the llm response."""

    def test_record_reaction_no_op_before_init(self, caplog):
        # Pre-init: log a warning, drop the reaction, don't raise.
        import logging
        with caplog.at_level(logging.WARNING, logger="pendo_sdk"):
            core.record_reaction(
                conversation_id="c1",
                reaction_type="thumbs_up",
                message_id="run-abc-123",
            )
        assert any("before init()" in r.message for r in caplog.records)

    def test_record_reaction_emits_reaction_span(self):
        from pendo_sdk.schema import ReactionType

        core.init(api_key="test-key", agent_id="test-agent", visitor_id="v1", account_id="a1")

        exported_spans = []
        original_export = core._exporter.export

        def capture(spans):
            # ReadableSpan.attributes is a frozen mapping — copy to a dict so
            # the assertion below can pull values out after shutdown clears state.
            for s in spans:
                exported_spans.append({
                    "name": s.name,
                    "attrs": dict(s.attributes),
                })
            return original_export(spans)

        core._exporter.export = capture

        core.record_reaction(
            conversation_id="conv-42",
            reaction_type=ReactionType.THUMBS_DOWN,
            message_id="run-abc-123",
            feedback_comment="wrong answer",
        )

        matches = [s for s in exported_spans if s["name"] == "user.reaction"]
        assert len(matches) == 1
        attrs = matches[0]["attrs"]
        assert attrs["pendo.span.type"] == "REACTION"
        assert attrs["reaction.type"] == "thumbs_down"
        assert attrs["pendo.message_id"] == "run-abc-123"
        assert attrs["reaction.feedback_comment"] == "wrong answer"
        assert attrs["pendo.conversation_id"] == "conv-42"
        # Falls back to identity from init() when not passed explicitly.
        assert attrs["pendo.visitor_id"] == "v1"
        assert attrs["pendo.account_id"] == "a1"

    def test_record_reaction_accepts_explicit_identity_override(self):
        core.init(api_key="test-key", agent_id="test-agent", visitor_id="default", account_id="default-acct")

        captured = []
        original_export = core._exporter.export
        core._exporter.export = lambda spans: (
            captured.extend({"attrs": dict(s.attributes)} for s in spans),
            original_export(spans),
        )[1]

        core.record_reaction(
            conversation_id="c",
            reaction_type="copy",
            message_id="run-abc-123",
            visitor_id="override-visitor",
            account_id="override-acct",
        )

        reaction = next(c for c in captured
                        if c["attrs"].get("pendo.span.type") == "REACTION")
        assert reaction["attrs"]["pendo.visitor_id"] == "override-visitor"
        assert reaction["attrs"]["pendo.account_id"] == "override-acct"


class TestSDKVersion:
    """Regression coverage for APP-153138.

    Why: the SDK version was hardcoded across core/exporter/schema and drifted
    from pyproject.toml. These tests pin every consumer to the dist metadata so
    a future hardcode reintroduction fails fast.
    """

    @staticmethod
    def _pyproject_version() -> str:
        root = Path(__file__).resolve().parent.parent
        with open(root / "pyproject.toml", "rb") as f:
            return tomllib.load(f)["project"]["version"]

    def test_core_version_matches_pyproject(self):
        assert core._SDK_VERSION == self._pyproject_version()

    def test_package_version_matches_pyproject(self):
        assert pendo_sdk.__version__ == self._pyproject_version()

    def test_exporter_version_matches_pyproject(self):
        assert exporter_module._SDK_VERSION == self._pyproject_version()

    def test_all_version_constants_agree(self):
        assert core._SDK_VERSION == pendo_sdk.__version__ == exporter_module._SDK_VERSION
