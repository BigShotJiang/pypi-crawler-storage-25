from __future__ import annotations

import asyncio
import os
import random

from db2_hj3415.settings import load_db2_settings_from_env
from scraper2_hj3415.app.dart.composition import build_dart_usecases


async def main() -> None:
    db2_settings = load_db2_settings_from_env()
    sleep_sec_between_pages = random.uniform(8, 12)
    usecases = build_dart_usecases(
        db_setting=db2_settings,
        dart_api_key=os.getenv("DART_API_KEY", ""),
    )

    result = await usecases.collect_reports.execute(
        sdate="20260101",
        edate="20260131",
        corp_code=None,
        restrict_to_krx300=True,
        only_kospi_kosdaq=True,
        sleep_sec_between_pages=sleep_sec_between_pages,
    )

    print("total_pages =", result.total_pages)
    print("raw_count =", result.raw_count)
    print("filtered_count =", result.filtered_count)
    print("head =", result.reports[:3])


if __name__ == "__main__":
    asyncio.run(main())
