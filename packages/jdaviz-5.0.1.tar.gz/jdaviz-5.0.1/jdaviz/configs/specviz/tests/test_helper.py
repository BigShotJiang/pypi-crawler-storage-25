from zipfile import ZipFile
import numpy as np
from numpy.testing import assert_allclose
import pytest
from astropy import units as u
from astropy.io import fits
from astropy.tests.helper import assert_quantity_allclose
from specutils import Spectrum, SpectrumList, SpectrumCollection, SpectralRegion
from astropy.utils.data import download_file

from jdaviz.app import PrivateApplication
from jdaviz.core.marks import LineUncertainties
from jdaviz import Specviz


class TestSpecvizHelper:
    @pytest.fixture(autouse=True)
    def setup_class(self, specviz_helper, spectrum1d, multi_order_spectrum_list):
        self.spec_app = specviz_helper
        self.spec = spectrum1d
        self.spec_list = SpectrumList([spectrum1d] * 3)
        self.multi_order_spectrum_list = multi_order_spectrum_list

        self.label = "Test 1D Spectrum"
        self.spec_app.load_data(spectrum1d, data_label=self.label)

    def test_load_spectrum1d(self):
        # starts with a single loaded spectrum1d object:
        assert len(self.spec_app._app.data_collection) == 1
        dc_0 = self.spec_app._app.data_collection[0]
        assert dc_0.label == self.label
        assert dc_0.meta['uncertainty_type'] == 'std'

        # Test both the old and new API
        data = self.spec_app.datasets[self.label].get_data()
        data_old_api = self.spec_app.get_data(data_label=self.label)

        assert isinstance(data, Spectrum)
        assert isinstance(data_old_api, Spectrum)
        # Verify both APIs return equivalent data
        assert np.array_equal(data.flux, data_old_api.flux)
        assert np.array_equal(data.spectral_axis, data_old_api.spectral_axis)

    def test_load_hdulist(self):
        # Create a fake fits file with a 1D spectrum for testing.
        primary_header = fits.Header({'TELESCOP': 'Fake Telescope'})
        primary_hdu = fits.PrimaryHDU(header=primary_header)

        # Image extension HDU with a 1D spectrum
        wavelength = np.linspace(5000, 6000, 100)
        flux = np.ones(100)
        spectrum_table = fits.BinTableHDU.from_columns([
            fits.Column(name='WAVELENGTH', array=wavelength, format='E', unit="Angstrom"),
            fits.Column(name='FLUX', array=flux, format='E', unit="Jy")
        ])
        spectrum_table.header['INSTRUME'] = 'Fake Instrument'
        fake_hdulist = fits.HDUList([primary_hdu, spectrum_table])
        self.label = "Test 1D Spectrum"
        self.spec_app.load_data(fake_hdulist)
        data = self.spec_app.datasets[self.label].get_data()
        # HDUList should load as Spectrum
        assert isinstance(data, Spectrum)

    @pytest.mark.parametrize(
        'kwargs',
        ({'data_label': [f"List test {i}" for i in (1, 2, 3)]},
         {'sources': [f"1D Spectrum at index: {i}" for i in (0, 1, 2)]},
         {'sources': '*'}))
    def test_load_spectrum_list_with_kwargs(self, kwargs):
        # When loading via the ``data_label`` argument, the length of the
        # list must match the number of sources in the SpectrumList.
        self.spec_app.load_data(self.spec_list, **kwargs)
        assert len(self.spec_app._app.data_collection) == 4
        if 'load' in list(kwargs.keys())[0]:
            for i in (1, 2, 3):
                assert "1D Spectrum" in self.spec_app._app.data_collection[i].label

    def test_load_multi_order_spectrum_list(self):
        assert len(self.spec_app._app.data_collection) == 1
        # now load ten spectral orders from a SpectrumList:
        self.spec_app.load_data(self.multi_order_spectrum_list, sources='*')
        assert len(self.spec_app._app.data_collection) == 11

    def test_mismatched_label_length(self):
        # NOTE: will be removed after load_data deprecation is removed
        with pytest.raises(ValueError, match='Length'):
            labels = ["List test 1", "List test 2"]
            self.spec_app.load_data(self.spec_list, data_label=labels)

    def test_load_spectrum_collection(self):
        with pytest.raises(ValueError):
            collection = SpectrumCollection([1]*u.AA)
            self.spec_app.load_data(collection)

    def test_get_spectra_no_viewer_reference(self):
        """
        Test _spectrum_viewer and get_spectra with no reference viewer.
        """
        # Get spectra without a reference viewer
        self.spec_app._app._viewer_store.pop('specviz-0')  # remove the default viewer
        assert self.spec_app._spectrum_viewer is None
        assert self.spec_app.get_spectra() == {}

    def test_get_spectra(self):
        with pytest.warns(UserWarning, match='Applying the value from the redshift slider'):
            spectra = self.spec_app.get_spectra()

        assert_quantity_allclose(spectra[self.label].flux,
                                 self.spec.flux, atol=1e-5*u.Unit(self.spec.flux.unit))

    def test_get_spectra_no_redshift(self):
        spectra = self.spec_app.get_spectra(apply_slider_redshift=None)

        assert_quantity_allclose(spectra[self.label].flux,
                                 self.spec.flux, atol=1e-5*u.Unit(self.spec.flux.unit))

    def test_get_spectra_no_data_label(self):
        spectra = self.spec_app.get_spectra(data_label=None, apply_slider_redshift=True)

        assert_quantity_allclose(spectra[self.label].flux,
                                 self.spec.flux, atol=1e-5*u.Unit(self.spec.flux.unit))

    def test_get_spectra_label_redshift(self):
        spectra = self.spec_app.get_spectra(data_label=self.label, apply_slider_redshift=True)

        assert_quantity_allclose(spectra.flux,
                                 self.spec.flux, atol=1e-5*u.Unit(self.spec.flux.unit))

    def test_get_spectra_label_redshift_warn(self):
        with pytest.warns(UserWarning, match='Applying the value from the redshift slider'):
            spectra = self.spec_app.get_spectra(data_label=self.label, apply_slider_redshift="Warn")

        assert_quantity_allclose(spectra.flux,
                                 self.spec.flux, atol=1e-5*u.Unit(self.spec.flux.unit))

    def test_get_spectra_with_spectral_subset(self):
        """
        Test get_spectra with a spectral_subset and data label.

        When spectral_subset is provided without data_label, get_spectra
        returns a dictionary. With, it returns a spectrum with a mask applied.
        """
        subset = SpectralRegion(
            6200 * self.spec.spectral_axis.unit,
            7000 * self.spec.spectral_axis.unit
        )
        self.spec_app.plugins['Subset Tools'].import_region(subset)

        for data_label in [None, self.label]:
            spectra = self.spec_app.get_spectra(
                spectral_subset='Subset 1',
                data_label=data_label,
                apply_slider_redshift=False
            )

            # When data_label is None, the result is a dict of Spectrum objects
            if data_label is None:
                assert isinstance(spectra, dict)
                spectra = spectra[self.label]

            assert isinstance(spectra, Spectrum)
            # Points outside the subset (6200-7000 Angstrom) should be masked (True),
            # points inside should not be (False).
            assert np.array_equal(spectra.mask,
                                  [True, False, False, False, False, True, True, True, True, True])

    def test_get_spectral_regions_none(self):
        plg = self.spec_app.plugins['Subset Tools']
        spec_region = plg.get_regions()
        assert spec_region == {}

    def test_get_spectral_regions_one(self):
        self.spec_app.plugins['Subset Tools'].import_region(
            SpectralRegion(6000*self.spec.spectral_axis.unit, 6500*self.spec.spectral_axis.unit))
        plg = self.spec_app.plugins['Subset Tools']
        spec_region = plg.get_regions()
        assert len(spec_region['Subset 1'].subregions) == 1

    def test_get_spectral_regions_two(self):
        subset = (SpectralRegion(6000*self.spec.spectral_axis.unit,
                                 6500*self.spec.spectral_axis.unit) +
                  SpectralRegion(7300*self.spec.spectral_axis.unit,
                                 7800*self.spec.spectral_axis.unit))
        self.spec_app.plugins['Subset Tools'].import_region(subset, combination_mode='or')

        spec_region = self.spec_app.plugins['Subset Tools'].get_regions()

        assert len(spec_region['Subset 1'].subregions) == 2

    def test_get_spectral_regions_three(self):
        subset = (SpectralRegion(6000*self.spec.spectral_axis.unit,
                                 6400*self.spec.spectral_axis.unit) +
                  SpectralRegion(6600*self.spec.spectral_axis.unit,
                                 7000*self.spec.spectral_axis.unit) +
                  SpectralRegion(7300*self.spec.spectral_axis.unit,
                                 7800*self.spec.spectral_axis.unit))
        self.spec_app.plugins['Subset Tools'].import_region(subset, combination_mode='or')

        spec_region = self.spec_app.plugins['Subset Tools'].get_regions()

        assert len(spec_region['Subset 1'].subregions) == 3
        # Assert correct values for test with 3 subregions
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][0].value,
                                 6000., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][1].value,
                                 6400., atol=1e-5)

        assert_quantity_allclose(spec_region['Subset 1'].subregions[1][0].value,
                                 6600., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[1][1].value,
                                 7000., atol=1e-5)

        assert_quantity_allclose(spec_region['Subset 1'].subregions[2][0].value,
                                 7300., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[2][1].value,
                                 7800., atol=1e-5)

    def test_get_spectral_regions_does_not_raise_value_error(self):
        subset = (SpectralRegion(1*self.spec.spectral_axis.unit,
                                 3*self.spec.spectral_axis.unit) +
                  SpectralRegion(4*self.spec.spectral_axis.unit,
                                 6*self.spec.spectral_axis.unit))
        self.spec_app.plugins['Subset Tools'].import_region(subset, combination_mode='or')

        spec_region = self.spec_app.plugins['Subset Tools'].get_regions()
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][0].value,
                                 1, atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][1].value,
                                 3, atol=1e-5)

        assert_quantity_allclose(spec_region['Subset 1'].subregions[1][0].value,
                                 4, atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[1][1].value,
                                 6, atol=1e-5)

    def test_get_spectral_regions_composite_region(self):
        subset = (SpectralRegion(6000*self.spec.spectral_axis.unit,
                                 7400*self.spec.spectral_axis.unit) +
                  SpectralRegion(6600*self.spec.spectral_axis.unit,
                                 7000*self.spec.spectral_axis.unit) +
                  SpectralRegion(7300*self.spec.spectral_axis.unit,
                                 7800*self.spec.spectral_axis.unit))
        self.spec_app.plugins['Subset Tools'].import_region(
            subset, combination_mode=['new', 'andnot', 'and'])

        spec_region = self.spec_app.plugins['Subset Tools'].get_regions()

        assert len(spec_region['Subset 1'].subregions) == 1
        # Assert correct values for test with 3 subregions
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][0].value,
                                 7300., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][1].value,
                                 7400., atol=1e-5)

    def test_get_spectral_regions_composite_region_multiple_and_nots(self):
        subset = (SpectralRegion(6000*self.spec.spectral_axis.unit,
                                 7800*self.spec.spectral_axis.unit) +
                  SpectralRegion(6200*self.spec.spectral_axis.unit,
                                 6600*self.spec.spectral_axis.unit) +
                  SpectralRegion(7300*self.spec.spectral_axis.unit,
                                 7700*self.spec.spectral_axis.unit))
        self.spec_app.plugins['Subset Tools'].import_region(
            subset, combination_mode=['new', 'andnot', 'andnot'])

        spec_region = self.spec_app.plugins['Subset Tools'].get_regions()

        assert len(spec_region['Subset 1'].subregions) == 3
        # Assert correct values for test with 3 subregions
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][0].value,
                                 6000., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[0][1].value,
                                 6200., atol=1e-5)

        assert_quantity_allclose(spec_region['Subset 1'].subregions[1][0].value,
                                 6600., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[1][1].value,
                                 7300., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[2][0].value,
                                 7700., atol=1e-5)
        assert_quantity_allclose(spec_region['Subset 1'].subregions[2][1].value,
                                 7800., atol=1e-5)


def test_get_spectra_no_spectra(specviz_helper, spectrum1d):
    with pytest.warns(UserWarning, match='Applying the value from the redshift slider'):
        spectra = specviz_helper.get_spectra()

    assert spectra == {}


def test_get_spectra_no_spectra_redshift_error(specviz_helper, spectrum1d):
    spectra = specviz_helper.get_spectra(apply_slider_redshift=True)

    assert spectra == {}


def test_get_spectra_no_spectra_label(specviz_helper, spectrum1d):
    label = "label"
    with pytest.raises(ValueError):
        specviz_helper.get_spectra(data_label=label)


def test_get_spectra_no_spectra_label_redshift_error(specviz_helper, spectrum1d):
    label = "label"
    with pytest.raises(ValueError):
        specviz_helper.get_spectra(data_label=label, apply_slider_redshift=True)


def test_add_spectrum_after_subset(specviz_helper, spectrum1d):
    specviz_helper.load_data(spectrum1d, data_label="test")
    subset = SpectralRegion(6200 * spectrum1d.spectral_axis.unit,
                            7000 * spectrum1d.spectral_axis.unit)
    specviz_helper.plugins['Subset Tools'].import_region(subset)

    new_spec = specviz_helper.get_spectra(apply_slider_redshift=True)["test"]*0.9
    specviz_helper.load_data(new_spec, data_label="test2")


def test_get_spectral_regions_unit(specviz_helper, spectrum1d):
    # Ensure units we put in are the same as the units we get out
    specviz_helper.load_data(spectrum1d)
    subset = SpectralRegion(6200 * spectrum1d.spectral_axis.unit,
                            7000 * spectrum1d.spectral_axis.unit)
    specviz_helper.plugins['Subset Tools'].import_region(subset)

    subsets = specviz_helper.plugins['Subset Tools'].get_regions()
    reg = subsets.get('Subset 1')

    assert spectrum1d.spectral_axis.unit == reg.lower.unit
    assert spectrum1d.spectral_axis.unit == reg.upper.unit


def test_get_spectral_regions_unit_conversion(specviz_helper, spectrum1d):
    spec_viewer = specviz_helper._app.get_viewer('spectrum-viewer')

    # Mouseover without data should not crash.
    label_mouseover = specviz_helper._coords_info
    label_mouseover._viewer_mouse_event(spec_viewer,
                                        {'event': 'mousemove', 'domain': {'x': 6100, 'y': 12.5}})
    assert label_mouseover.as_text() == ('', '', '')
    assert label_mouseover.icon == ''

    # If the reference (visible) data changes via unit conversion,
    # check that the region's units convert too
    specviz_helper.load_data(spectrum1d)  # Originally Angstrom

    # Also check coordinates info panel.
    # x=0 -> 6000 A, x=1 -> 6222.222 A
    label_mouseover._viewer_mouse_event(spec_viewer,
                                        {'event': 'mousemove', 'domain': {'x': 6100, 'y': 12.5}})
    assert label_mouseover.as_text() == ('Cursor 6.10000e+03, 1.25000e+01',
                                         'Wave 6.00000e+03 Angstrom (0 pix)',  # actual 0.4
                                         'Flux 1.24967e+01 Jy')
    assert label_mouseover.icon == 'a'

    label_mouseover._viewer_mouse_event(spec_viewer,
                                        {'event': 'mousemove', 'domain': {'x': None, 'y': 12.5}})
    assert label_mouseover.as_text() == ('', '', '')
    assert label_mouseover.icon == ''

    # Convert the wavelength axis to micron
    new_spectral_axis = "um"
    specviz_helper.plugins['Unit Conversion'].spectral_unit = new_spectral_axis
    spectral_axis_unit = u.Unit(specviz_helper.plugins['Unit Conversion'].spectral_unit.selected)
    subset = SpectralRegion(0.6 * spectral_axis_unit, 0.7 * spectral_axis_unit)
    specviz_helper.plugins['Subset Tools'].import_region(subset)

    # Retrieve the Subset
    ss = specviz_helper.plugins['Subset Tools'].get_regions(use_display_units=False)
    reg = ss.get('Subset 1')
    assert reg.lower.unit == u.Angstrom
    assert reg.upper.unit == u.Angstrom

    ss = specviz_helper.plugins['Subset Tools'].get_regions(use_display_units=True)
    reg = ss.get('Subset 1')
    assert reg.lower.unit == u.um
    assert reg.upper.unit == u.um

    # Coordinates info panel should show new unit
    label_mouseover._viewer_mouse_event(spec_viewer,
                                        {'event': 'mousemove', 'domain': {'x': 0.61, 'y': 12.5}})
    label_mouseover.as_text() == ('Cursor 6.10000e-01, 1.25000e+01',
                                  'Wave 6.00000e-01 micron (0 pix)',
                                  'Flux 1.24967e+01 Jy')
    assert label_mouseover.icon == 'a'

    label_mouseover._viewer_mouse_event(spec_viewer, {'event': 'mouseleave'})
    assert label_mouseover.as_text() == ('', '', '')
    assert label_mouseover.icon == ''


def test_subset_default_thickness(specviz_helper, spectrum1d):
    specviz_helper.load_data(spectrum1d)

    sv = specviz_helper._app.get_viewer('spectrum-viewer')
    sv.toolbar.active_tool = sv.toolbar.tools['bqplot:xrange']

    spectral_axis_unit = u.Unit(specviz_helper.plugins['Unit Conversion'].spectral_unit.selected)
    subset = SpectralRegion(2.5 * spectral_axis_unit,
                            3.5 * spectral_axis_unit)
    specviz_helper.plugins['Subset Tools'].import_region(subset)
    # _on_layers_update is not triggered within CI
    sv._on_layers_update()
    assert sv.state.layers[-1].linewidth == 3


def test_app_links(specviz_helper, spectrum1d):
    specviz_helper.load_data(spectrum1d)
    sv = specviz_helper._app.get_viewer('spectrum-viewer')
    assert isinstance(sv.jdaviz_app, PrivateApplication)
    assert isinstance(sv.jdaviz_helper, Specviz)


@pytest.mark.remote_data
@pytest.mark.xfail(reason='Multiple file support not yet implemented in loaders')
def test_load_spectrum_list_directory(tmpdir, specviz_helper):
    # niriss_parser_test_data.zip
    test_data = 'https://stsci.box.com/shared/static/7ndets0vjjsa97la2hvjvm6xvnu5b594.zip'
    fn = download_file(test_data, cache=True, timeout=30)
    with ZipFile(fn, 'r') as sample_data_zip:
        sample_data_zip.extractall(tmpdir.strpath)
    data_path = str(tmpdir.join('NIRISS_for_parser_p0171'))

    # Load two NIRISS x1d files from FITS. They have 19 and 20 EXTRACT1D
    # extensions per file, for a total of 39 spectra to load:
    with pytest.warns(UserWarning, match='SRCTYPE is missing or UNKNOWN in JWST x1d loader'):
        specviz_helper.load_data(data_path)

    # NOTE: the length was 3 before specutils 1.9 (https://github.com/astropy/specutils/pull/982)
    expected_len = 39
    assert len(specviz_helper._app.data_collection) == expected_len

    for data in specviz_helper._app.data_collection:
        assert data.main_components[:2] == ['flux', 'uncertainty']

    dc_0 = specviz_helper._app.data_collection[0]
    assert 'header' not in dc_0.meta
    assert dc_0.meta['SPORDER'] == 1


@pytest.mark.remote_data
@pytest.mark.xfail(reason='Multiple file support not yet implemented in loaders')
def test_load_spectrum_list_directory_concat(tmpdir, specviz_helper):
    # niriss_parser_test_data.zip
    test_data = 'https://stsci.box.com/shared/static/7ndets0vjjsa97la2hvjvm6xvnu5b594.zip'
    fn = download_file(test_data, cache=True, timeout=30)
    with ZipFile(fn, 'r') as sample_data_zip:
        sample_data_zip.extractall(tmpdir.strpath)
    data_path = str(tmpdir.join('NIRISS_for_parser_p0171'))

    # Load two x1d files from FITS. They have 19 and 20 EXTRACT1D
    # extensions per file, for a total of 39 spectra to load. Also concatenate
    # spectra common to each file into one "Combined" spectrum to load per file.
    # Now the total is (19 EXTRACT 1D + 1 Combined) + (20 EXTRACT 1D + 1 Combined) = 41.
    with pytest.warns(UserWarning, match='SRCTYPE is missing or UNKNOWN in JWST x1d loader'):
        specviz_helper.load_data(data_path, concat_by_file=True)
    assert len(specviz_helper._app.data_collection) == 41


def test_load_2d_flux(specviz_helper):
    # Test loading a spectrum with a 2D flux, which should be split into separate
    # 1D Spectrum objects to load in Specviz.
    spec = Spectrum(spectral_axis=np.linspace(4000, 6000, 10)*u.Angstrom,
                    flux=np.ones((4, 10))*u.Unit("1e-17 erg / (Angstrom cm2 s)"))

    # NOTE: this maps to specviz_helper.load(spec, data_label='test', extension='*')
    specviz_helper.load_data(spec, data_label="test", sources='*')

    assert len(specviz_helper._app.data_collection) == 4
    assert specviz_helper._app.data_collection[0].label == "test_index-0"

    spec2 = Spectrum(spectral_axis=np.linspace(4000, 6000, 10)*u.Angstrom,
                     flux=np.ones((2, 10))*u.Unit("1e-17 erg / (Angstrom cm2 s)"))

    # Make sure 2D spectra in a SpectrumList also get split properly.
    spec_list = SpectrumList([spec, spec2])
    # NOTE: this maps to specviz_helper.load(spec_list, data_label='second test', extension='*')
    specviz_helper.load_data(spec_list, data_label="second test", sources='*')

    assert len(specviz_helper._app.data_collection) == 6
    assert specviz_helper._app.data_collection[-1].label == "second test_index-1"


def test_plot_uncertainties(specviz_helper, spectrum1d):
    specviz_helper.load_data(spectrum1d)

    specviz_viewer = specviz_helper._app.get_viewer('spectrum-viewer')

    assert len([m for m in specviz_viewer.figure.marks if isinstance(m, LineUncertainties)]) == 0

    specviz_viewer.state.show_uncertainty = True
    uncert_marks = [m for m in specviz_viewer.figure.marks if isinstance(m, LineUncertainties)]
    assert len(uncert_marks) == 1
    # mark has a lower and upper boundary, but each should have the same length as the spectrum
    assert len(uncert_marks[0].x[0]) == len(spectrum1d.flux)

    # enable as-steps and make sure doesn't crash (won't change the number of marks)
    specviz_viewer.state.layers[0].as_steps = True
    specviz_viewer._plot_uncertainties()
    uncert_marks = [m for m in specviz_viewer.figure.marks if isinstance(m, LineUncertainties)]
    assert len(uncert_marks) == 1
    # now the mark should have double the length as its drawn on the bin edges
    assert len(uncert_marks[0].x[0]) == len(spectrum1d.flux) * 2

    specviz_viewer.state.show_uncertainty = False

    assert len([m for m in specviz_viewer.figure.marks if isinstance(m, LineUncertainties)]) == 0


# Some API might be going through deprecation, so ignore the warning.
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
def test_plugin_user_apis(specviz_helper):
    for plugin_name, plugin_api in specviz_helper.plugins.items():
        plugin = plugin_api._obj
        for attr in plugin_api._expose:
            assert hasattr(plugin, attr)


def test_data_label_as_posarg(specviz_helper, spectrum1d):
    # Passing in data_label keyword as posarg.
    specviz_helper.load_data(spectrum1d, 'my_spec')
    assert specviz_helper._app.data_collection[0].label == 'my_spec'


def test_spectra_partial_overlap(specviz_helper):
    spec_viewer = specviz_helper._app.get_viewer('spectrum-viewer')

    wave_1 = np.linspace(6000, 7000, 10) * u.AA
    flux_1 = ([1200] * wave_1.size) * u.nJy
    sp_1 = Spectrum(flux=flux_1, spectral_axis=wave_1)

    wave_2 = wave_1 + (800 * u.AA)
    flux_2 = ([60] * wave_2.size) * u.nJy
    sp_2 = Spectrum(flux=flux_2, spectral_axis=wave_2)

    specviz_helper.load_data(sp_1, data_label='left')
    specviz_helper.load_data(sp_2, data_label='right')

    # Test mouseover outside of left but in range for right.
    # Should show right spectrum even when mouse is near left flux.
    label_mouseover = specviz_helper._coords_info
    label_mouseover._viewer_mouse_event(spec_viewer,
                                        {'event': 'mousemove', 'domain': {'x': 7022, 'y': 1000}})
    assert label_mouseover.as_text() == ('Cursor 7.02200e+03, 1.00000e+03',
                                         'Wave 7.02222e+03 Angstrom (2 pix)',
                                         'Flux 6.00000e+01 nJy')
    assert label_mouseover.icon == 'b'


def test_spectra_incompatible_flux(specviz_helper):
    """https://github.com/spacetelescope/jdaviz/issues/2459"""
    wav = [1.1, 1.2, 1.3] * u.um
    sp1 = Spectrum(flux=[1, 1.1, 1] * (u.MJy / u.sr), spectral_axis=wav)
    sp2 = Spectrum(flux=[1, 1, 1.1] * (u.MJy), spectral_axis=wav)
    flux3 = ([1, 1.1, 1] * u.MJy).to(u.erg / u.s / u.cm / u.cm / u.AA, u.spectral_density(wav))
    sp3 = Spectrum(flux=flux3, spectral_axis=wav)

    specviz_helper.load_data(sp2, data_label="2")  # OK
    specviz_helper.load_data(sp1, data_label="1")  # Not OK
    specviz_helper.load_data(sp3, data_label="3")  # OK

    # all 3 load into data-collection, but only two in the viewer (with snackbar error)
    assert len(specviz_helper._app.data_collection.labels) == 3
    assert len(specviz_helper.viewers['spectrum-viewer']._obj.glue_viewer.layers) == 2


def test_delete_data_with_subsets(specviz_helper, spectrum1d, spectrum1d_nm):
    specviz_helper.load_data(spectrum1d, 'my_spec_AA')
    specviz_helper.load_data(spectrum1d_nm, 'my_spec_nm')

    spectral_axis_unit = u.Unit(specviz_helper.plugins['Unit Conversion'].spectral_unit.selected)

    subset = SpectralRegion(6200 * spectral_axis_unit,
                            7000 * spectral_axis_unit)
    specviz_helper.plugins['Subset Tools'].import_region(subset)

    assert len(specviz_helper._app.data_collection.subset_groups) == 1
    subset1 = specviz_helper._app.data_collection.subset_groups[0]
    assert subset1.subset_state.att.parent.label == "my_spec_AA"
    assert_allclose((subset1.subset_state.lo, subset1.subset_state.hi), (6200, 7000))

    specviz_helper._app.remove_data_from_viewer('spectrum-viewer', "my_spec_AA")
    specviz_helper._app.data_item_remove("my_spec_AA")

    # Check that the reparenting and coordinate recalculations happened
    assert subset1.subset_state.att.parent.label == "my_spec_nm"
    assert_allclose((subset1.subset_state.lo, subset1.subset_state.hi), (620, 700))


# TODO: Delete on full deprecation of load_data
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
class TestLoadData:
    def test_load_data_errors(self, specviz_helper, spectrum1d):
        """
        Test that errors from load_data.
        """
        with pytest.raises(NotImplementedError, match='format is ignored'):
            specviz_helper.load_data(spectrum1d, format='some_format')

        with pytest.raises(ValueError, match='Cannot set both'):
            specviz_helper.load_data(spectrum1d, load_as_list=True, concat_by_file=True)

    def test_load_data_with_cache_timeout_local_path(self, specviz_helper, spectrum1d, tmpdir):
        """
        Test load_data with cache, timeout, and local_path kwargs.
        """
        specviz_helper.load_data(
            spectrum1d,
            data_label='test_cache',
            cache=True,
            timeout=30,
            local_path=tmpdir
        )
        assert 'test_cache' in specviz_helper._app.data_collection.labels
        assert len(specviz_helper._app.data_collection) == 1

    def test_load_data_with_sources_and_exposures(self, specviz_helper, premade_spectrum_list):
        """
        Test load_data with sources and exposures kwargs.
        """
        specviz_helper.load_data(premade_spectrum_list, sources='*')
        assert len(specviz_helper._app.data_collection) == 5

    def test_load_data_show_in_viewer_false(self, specviz_helper, spectrum1d):
        """
        Test load_data with show_in_viewer=False.
        """
        with pytest.warns(DeprecationWarning, match='show_in_viewer'):
            specviz_helper.load_data(
                spectrum1d,
                data_label='hidden_spec',
                show_in_viewer=False
            )
        assert 'hidden_spec' in specviz_helper._app.data_collection.labels

    def test_load_data_concat_by_file(self, specviz_helper, premade_spectrum_list):
        """
        Test load_data with concat_by_file=True.
        """
        initial_count = len(specviz_helper._app.data_collection)
        specviz_helper.load_data(
            premade_spectrum_list,
            data_label='concatenated',
            concat_by_file=True
        )
        assert len(specviz_helper._app.data_collection) == initial_count + 1

    def test_load_data_with_load_as_list(self, specviz_helper, premade_spectrum_list):
        """
        Test load_data with load_as_list=True.
        """
        specviz_helper.load_data(
            premade_spectrum_list,
            data_label='as_list',
            load_as_list=True
        )
        assert 'as_list_index-0' in specviz_helper._app.data_collection.labels


# TODO: Delete on full deprecation of x_limits, y_limits, autoscale_x, autoscale_y
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.filterwarnings("ignore::astropy.utils.exceptions.AstropyDeprecationWarning")
class TestDeprecatedLimits:
    def test_x_limits(self, specviz_helper, spectrum1d):
        """
        Test deprecated x_limits.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')
        sv = specviz_helper._app.get_viewer('spectrum-viewer')

        specviz_helper.x_limits()
        assert sv.scale_x.min == 6000
        assert sv.scale_x.max == 8000

        specviz_helper.x_limits(x_min=6000*u.AA, x_max=7000*u.AA)
        assert sv.scale_x.min == 6000
        assert sv.scale_x.max == 7000

        region = SpectralRegion(6500 * u.AA, 6600 * u.AA)
        specviz_helper.x_limits(x_min=region)
        assert sv.scale_x.min == 6500
        assert sv.scale_x.max == 6600

        specviz_helper.x_limits(x_min='auto', x_max='auto')
        assert sv.scale_x.min == 6000
        assert sv.scale_x.max == 8000

    def test_y_limits(self, specviz_helper, spectrum1d):
        """
        Test deprecated y_limits.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')
        sv = specviz_helper._app.get_viewer('spectrum-viewer')

        specviz_helper.y_limits()
        assert_allclose(sv.scale_y.min, 12, atol=1)
        assert_allclose(sv.scale_y.max, 16.5, atol=1)

        specviz_helper.y_limits(y_min=0*u.Jy, y_max=20*u.Jy)
        assert sv.scale_y.min == 0
        assert sv.scale_y.max == 20

        region = SpectralRegion(5 * u.Jy, 10 * u.Jy)
        specviz_helper.y_limits(y_min=region)

        assert sv.scale_y.min == 5
        assert sv.scale_y.max == 10

        specviz_helper.y_limits(y_min='auto', y_max='auto')
        assert_allclose(sv.scale_y.min, 12, atol=1)
        assert_allclose(sv.scale_y.max, 16.5, atol=1)

    def test_autoscale_x_deprecated(self, specviz_helper, spectrum1d):
        """
        Test deprecated autoscale_x method.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')
        specviz_helper.autoscale_x()

        sv = specviz_helper._app.get_viewer('spectrum-viewer')
        assert sv.scale_x.min == 6000
        assert sv.scale_x.max == 8000

    def test_autoscale_y_deprecated(self, specviz_helper, spectrum1d):
        """
        Test deprecated autoscale_y method.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')
        specviz_helper.autoscale_y()

        sv = specviz_helper._app.get_viewer('spectrum-viewer')
        assert_allclose(sv.scale_y.min, 12, atol=1)
        assert_allclose(sv.scale_y.max, 16.5, atol=1)

    def test_flip_x(self, specviz_helper, spectrum1d):
        """
        Test deprecated flip_x method.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')

        sv = specviz_helper._app.get_viewer('spectrum-viewer')
        original_min = sv.scale_x.min
        original_max = sv.scale_x.max

        specviz_helper.flip_x()

        assert sv.scale_x.min == original_max
        assert sv.scale_x.max == original_min

    def test_flip_y(self, specviz_helper, spectrum1d):
        """
        Test deprecated flip_y method.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')

        sv = specviz_helper._app.get_viewer('spectrum-viewer')
        original_min = sv.scale_y.min
        original_max = sv.scale_y.max

        specviz_helper.flip_y()

        assert sv.scale_y.min == original_max
        assert sv.scale_y.max == original_min

    def test_set_spectrum_tick_format_x_axis(self, specviz_helper, spectrum1d):
        """
        Test deprecated set_spectrum_tick_format for x-axis.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')
        specviz_helper.set_spectrum_tick_format('0.2f', axis=0)

    def test_set_spectrum_tick_format_y_axis(self, specviz_helper, spectrum1d):
        """
        Test deprecated set_spectrum_tick_format for y-axis.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')
        specviz_helper.set_spectrum_tick_format('0.1e', axis=1)

    def test_set_spectrum_tick_format_invalid_axis(self, specviz_helper, spectrum1d):
        """
        Test deprecated set_spectrum_tick_format with invalid axis.
        """
        specviz_helper.load_data(spectrum1d, data_label='test_spec')
        with pytest.warns(UserWarning, match='Please use either 0 or 1'):
            specviz_helper.set_spectrum_tick_format('0.2f', axis=2)
