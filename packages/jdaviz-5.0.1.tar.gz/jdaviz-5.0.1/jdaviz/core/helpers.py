"""
Helper classes are meant to provide a convenient user API for specific
configurations. They allow a separation of "viztool-specific" API and the glue
application objects.

See also https://github.com/spacetelescope/jdaviz/issues/104 for more details
on the motivation behind this concept.
"""
import warnings
from contextlib import contextmanager
from inspect import isclass

import numpy as np
from glue.core import ComponentID, HubListener
from glue.core.edit_subset_mode import NewMode
from glue.core.message import SubsetCreateMessage, SubsetDeleteMessage
from glue.core.subset import Subset, MaskSubsetState
from glue.config import data_translator
from ipywidgets.widgets import widget_serialization

from astropy.nddata import NDDataArray, CCDData, StdDevUncertainty
import astropy.units as u
from astropy.utils.decorators import deprecated
from regions.core.core import Region
from specutils import Spectrum, SpectralRegion

from jdaviz.app import PrivateApplication
from jdaviz.configs.default.plugins.viewers import JdavizViewerWindow
from jdaviz.core.events import SnackbarMessage, ExitBatchLoadMessage, SliceSelectSliceMessage
from jdaviz.core.loaders.resolvers import find_matching_resolver
from jdaviz.core.template_mixin import show_widget
from jdaviz.core.user_api import (DataApi, SpectralDataApi, SpatialDataApi,
                                  TemporalSpatialDataApi, SpectralSpatialDataApi)
from jdaviz.utils import data_has_valid_wcs, CONFIGS_WITH_LOADERS
from jdaviz.core.unit_conversion_utils import (all_flux_unit_conversion_equivs,
                                               check_if_unit_is_per_solid_angle,
                                               flux_conversion_general,
                                               spectral_axis_conversion)


__all__ = ['ConfigHelper', 'ImageConfigHelper', 'CubeConfigHelper']


class ConfigHelper(HubListener):
    """The Base Helper Class.
    Provides shared abstracted helper methods to the user.

    Subclasses should set ``_default_configuration`` if they are meant to be
    used with a specific configuration.

    Parameters
    ----------
    app : `~jdaviz.app.PrivateApplication` or `None`
        The application object, or if `None`, creates a new one based on the
        default configuration for this helper.
    verbosity : {'debug', 'info', 'warning', 'error'}
        Verbosity of the popup messages in the application.
    history_verbosity : {'debug', 'info', 'warning', 'error'}
        Verbosity of the history logger in the application.
    """
    _default_configuration = 'default'
    _component_ids = {}

    def __init__(self, app=None, verbosity=None, history_verbosity=None):
        if app is None:
            self._app = PrivateApplication(configuration=self._default_configuration)
        else:
            self._app = app
        if (logger_plg := self.plugins.get('Logger')) is not None:
            if verbosity is not None:
                logger_plg.popup_verbosity = verbosity
            if history_verbosity is not None:
                logger_plg.history_verbosity = history_verbosity

        # give a reference from the app back to this config helper.  These can be accessed from a
        # viewer via viewer.jdaviz_app and viewer.jdaviz_helper
        # if the helper has already been set, this is probably a nested viz tool. Don't overwrite
        if self._app._jdaviz_helper is None:
            self._app._jdaviz_helper = self

        self._app.hub.subscribe(self, SubsetCreateMessage,
                               handler=lambda msg: self._propagate_callback_to_viewers('_on_subset_create', msg)) # noqa
        self._app.hub.subscribe(self, SubsetDeleteMessage,
                               handler=lambda msg: self._propagate_callback_to_viewers('_on_subset_delete', msg)) # noqa

        self._in_batch_load = 0
        self._delayed_show_in_viewer_labels = {}  # label: viewer_reference pairs
        self.pending_set_data_visibility = []  # list of kwarg dicts for set_data_visibility

    @property
    @deprecated(since="5.2", alternative="._app")
    def app(self):
        """Access to the underlying application instance."""
        return self._app

    def _propagate_callback_to_viewers(self, method, msg):
        # viewers don't have access to the app/hub to subscribe to messages, so we'll
        # catch all messages here and pass them on to each of the viewers that
        # have the applicable method implemented.
        for viewer in self._app._viewer_store.values():
            if hasattr(viewer, method):
                getattr(viewer, method)(msg)

    @contextmanager
    def batch_load(self):
        """
        Context manager to delay linking and loading data into viewers
        """
        # we'll use a counter instead of a boolean to allow the user to nest multiple
        # context managers.  Once they're all exited, then the linking/showing will
        # take place.
        self._in_batch_load += 1
        with self._app.data_collection.delay_link_manager_update():
            # user entrypoint (anything within the with-statement will get called here)
            yield

        self._in_batch_load -= 1
        if not self._in_batch_load:
            self._app.hub.broadcast(ExitBatchLoadMessage(sender=self._app))

            # Process any deferred set_data_visibility calls
            for call_kwargs in self.pending_set_data_visibility:
                self._app.set_data_visibility(**call_kwargs)
            self.pending_set_data_visibility = []

            # add any data to viewers that were requested but deferred
            for data_label, viewer_ref in self._delayed_show_in_viewer_labels.items():
                self._app.set_data_visibility(viewer_ref, data_label,
                                              visible=True, replace=False)
            self._delayed_show_in_viewer_labels = {}

    def load_data(self, data, data_label=None, parser_reference=None, **kwargs):
        if data_label:
            kwargs['data_label'] = data_label
        self._app.load_data(data, parser_reference=parser_reference, **kwargs)

    @property
    def _coords_info(self):
        return self._app.session.application._tools.get('g-coords-info')

    @property
    def loaders(self):
        """
        Access API objects for data loaders in the import dialog.

        Returns
        -------
        loaders : dict
            dict of loader objects
        """
        if not (self._app.state.dev_loaders or self._app.config in CONFIGS_WITH_LOADERS):  # noqa
            raise NotImplementedError("loaders is under active development and requires a dev-flag to test")  # noqa
        loaders = {item['label']: widget_serialization['from_json'](item['widget'], None).user_api
                   for item in self._app.state.loader_items}
        return loaders

    def _get_loader(self, resolver_name, parser_name=None, importer_name=None):
        """
        Attempt to retrieve a resolver/parser/importer for debugging purposes.
        Can be used to debug an importer that shows as invalid because of an internal error.
        """
        ldr = self.loaders.get(resolver_name)
        resolver = ldr._obj
        if parser_name is None:
            return resolver

        orig_debug = ldr.format.debug
        ldr.format.debug = True
        parser = ldr.format._parsers[parser_name]
        ldr.format.debug = orig_debug
        if importer_name is None:
            return parser

        input = parser.output
        ldr.format.debug = orig_debug

        from jdaviz.core.registries import loader_importer_registry
        ImporterCls = loader_importer_registry.members.get(importer_name)
        return ImporterCls(app=self._app, resolver=resolver, parser=parser, input=input)

    @property
    def new_viewers(self):
        """
        Access API objects for creating new viewers.

        Returns
        -------
        new_viewers : dict
            dict of viewer-creator objects
        """
        if not self._app.config == 'deconfigged':
            raise NotImplementedError("new_viewers is only enabled in the deconfigged app")  # noqa
        new_viewers = {item['label']: widget_serialization['from_json'](item['widget'], None).user_api  # noqa
                       for item in self._app.state.new_viewer_items if item['is_relevant']}
        return new_viewers

    def _load(self,
              inp=None,
              loader=None,
              format=None,
              target=None,
              ignore_invalid_kwargs=False,
              **kwargs):
        """
        Load data into the app. A single valid loader/importer must be able to be
        matched based on the input, otherwise an error will be raised suggesting
        what further information to provide.  For an interactive approach,
        see ``loaders``.

        Parameters
        ----------
        inp : string or object or None
            Input filename, url, data object, etc.
        loader : string, optional
            Only consider a specific loader/resolver
        format : string, optional
            Only consider a specific format
        target : string, optional
            Only consider a specific target
        ignore_invalid_kwargs : bool, optional
            If True, silently ignore kwargs that do not match valid inputs for the
            selected loader/importer. If False (default), raise an error for invalid kwargs.
        kwargs :
            Additional kwargs are passed on to both the loader and importer, as applicable.
            If ignore_invalid_kwargs is False, any kwargs that do not match valid inputs
            will raise a ValueError.
        """
        resolver = find_matching_resolver(self._app, inp,
                                          resolver=loader,
                                          format=format,
                                          target=target,
                                          **kwargs)

        if 'show_in_viewer' in kwargs.keys():
            if 'viewer' in kwargs.keys():
                raise ValueError('Cannot specify both "show_in_viewer" and "viewer".')
            warnings.warn('The "show_in_viewer" argument is deprecated and will be removed in a future version. Use "viewer" instead.', DeprecationWarning)  # noqa
            kwargs['viewer'] = '*' if kwargs.pop('show_in_viewer') else []

        importer = resolver.importer
        valid_kwargs = resolver._expose + (importer._expose if importer else [])
        invalid_kwargs = [k for k in kwargs if k not in valid_kwargs]
        if not ignore_invalid_kwargs and len(invalid_kwargs):
            raise ValueError(f"Invalid argument for {resolver.format.selected} format: {', '.join(invalid_kwargs)}")  # noqa

        importer._obj._apply_kwargs(kwargs)
        out = resolver.load()
        # force cleanup before returning
        resolver._obj._cleanup()
        return out

    @property
    def datasets(self):
        """
        Access API object for data loaded in jdaviz.

        Returns
        -------
        datasets : dict
            dict of data objects, with keys corresponding to data labels
        """
        def _get_data_api_class(data):
            """
            Determine the appropriate DataApi subclass for a given data object.

            Parameters
            ----------
            data : glue.core.Data
                The data object from the data collection.

            Returns
            -------
            cls : type
                The appropriate DataApi subclass.
            """
            config = self._app.config
            ndim = data.ndim
            is_spectral = 'spectral_axis_index' in data.meta

            if ndim == 1:
                # 1D spectrum
                return SpectralDataApi
            elif ndim == 2:
                if config == 'specviz2d' or is_spectral:
                    # 2D spectrum
                    return SpectralDataApi
                else:
                    # 2D image (imviz, etc.)
                    return SpatialDataApi
            elif ndim == 3:
                if config == 'rampviz':
                    return TemporalSpatialDataApi
                else:
                    # Cube data (cubeviz, mosviz)
                    return SpectralSpatialDataApi
            else:
                # Fallback to base class
                return DataApi
        return {data.label: _get_data_api_class(data)(self._app, data.label)
                for data in self._app.data_collection}

    @property
    @deprecated(since="5.0", alternative="datasets")
    def data_labels(self):
        """
        List of data labels loaded and available in jdaviz

        Returns
        -------
        data_labels : list
            list of strings
        """
        return [data.label for data in self._app.data_collection]

    @property
    def plugins(self):
        """
        Access API objects for plugins in the plugin tray.

        Returns
        -------
        plugins : dict
            dict of plugin objects
        """
        plugins = {item['label']: widget_serialization['from_json'](item['widget'], None).user_api
                   for item in self._app.state.tray_items if item['is_relevant']}

        msg_temp = "in the future, the formerly named \"{}\" plugin will only be available by its new name: \"{}\""  # noqa

        old_new = [('Imviz Line Profiles (XY)', 'Image Profiles (XY)'),  # renamed in 4.0
                   ('Spectral Extraction', '2D Spectral Extraction'),  # renamed in 4.3
                   ('Spectral Extraction', '3D Spectral Extraction')]  # renamed in 4.3

        if self._app.config == 'cubeviz':
            old_new.append(('Slice', 'Spectral Slice'))  # renamed in 4.5
        elif self._app.config == 'rampviz':
            old_new.append(('Slice', 'Ramp Slice'))  # renamed in 4.5

        # handle renamed plugins during deprecation
        for old, new in old_new:
            if new in plugins:
                plugins[old] = plugins[new]._obj.user_api
                plugins[old]._deprecation_msg = msg_temp.format(old, new)

        if 'Catalog Search' in plugins.keys():
            plugins['Catalog Search']._deprecation_msg = ("The Catalogs plugin is deprecated, please see the "  # noqa
                                                          "warning at https://jdaviz.readthedocs.io/en/latest/plugins/catalog_search.html")  # noqa

        return plugins

    @property
    def plugin_tables(self):
        return self._app._plugin_tables

    @property
    def plugin_plots(self):
        return self._app._plugin_plots

    @property
    def viewers(self):
        """
        Access API objects for any viewer.

        Returns
        -------
        viewers : dict
            dict of viewer objects
        """
        return {viewer._ref_or_id: JdavizViewerWindow(viewer, app=self._app).user_api
                for viewer in list(self._app._viewer_store.values())}

    def _get_clone_viewer_reference(self, reference):
        base_name = reference.split("[")[0]
        name = base_name
        ind = 0
        while name in self.viewers.keys():
            ind += 1
            name = f"{base_name}[{ind}]"
        return name

    def _set_data_component(self, data, component_label, values):
        if component_label in self._component_ids:
            component_id = self._component_ids[component_label]
        else:
            existing_components = [component.label for component in data.components]
            if component_label in existing_components:
                component_id = data.components[existing_components.index(component_label)]
            else:
                component_id = ComponentID(component_label)
                self._component_ids[component_label] = component_id

        if component_id in data.components:
            data.update_components({component_id: values})
        else:
            data.add_component(values, component_id)

    @property
    @deprecated(since="4.2", alternative="plugins['Model Fitting'].fitted_models")
    def fitted_models(self):
        """
        Returns the fitted models.

        Returns
        -------
        parameters : dict
            dict of `astropy.modeling.Model` objects, or None.
        """
        plg = self.plugins.get('Model Fitting', None)
        if plg is None:
            raise ValueError("Model Fitting plugins is not loaded")
        return plg.fitted_models

    @deprecated(since="4.2", alternative="plugins['Model Fitting'].get_models")
    def get_models(self, models=None, model_label=None, x=None, y=None):
        """
        Loop through all models and output models of the label model_label.
        If x or y is set, return model_labels of those (x, y) coordinates.
        If x and y are None, print all models regardless of coordinates.

        Parameters
        ----------
        models : dict
            A dict of models, with the key being the label name and the value
            being an `astropy.modeling.CompoundModel` object. Defaults to
            `fitted_models` if no parameter is provided.
        model_label : str
            The name of the model that will be found and returned. If it
            equals default, every model present will be returned.
        x : int
            The x coordinate of the model spaxels that will be returned.
        y : int
            The y coordinate of the model spaxels that will be returned.

        Returns
        -------
        selected_models : dict
            Dictionary of the selected models.
        """
        plg = self.plugins.get('Model Fitting', None)
        if plg is None:
            raise ValueError("Model Fitting plugins is not loaded")
        return plg._obj.get_models(models=models,
                                   model_label=model_label,
                                   x=x, y=y)

    @deprecated(since="4.2")
    def get_model_parameters(self, models=None, model_label=None, x=None, y=None):
        """
        Convert each parameter of model inside models into a coordinate that
        maps the model name and parameter name to a `astropy.units.Quantity`
        object.

        Parameters
        ----------
        models : dict
            A dictionary where the key is a model name and the value is an
            `astropy.modeling.CompoundModel` object.
        model_label : str
            Get model parameters for a particular model by inputting its label.
        x : int
            The x coordinate of the model spaxels that will be returned from
            get_models.
        y : int
            The y coordinate of the model spaxels that will be returned from
            get_models.

        Returns
        -------
        :dict: a dictionary of the form
            {model name: {parameter name: [[`astropy.units.Quantity`]]}}
            for 3d models or
            {model name: {parameter name: `astropy.units.Quantity`}} where the
            Quantity object represents the parameter value and unit of one of
            spaxel models or the 1d models, respectively.
        """
        plg = self.plugins.get('Model Fitting', None)
        if plg is None:
            raise ValueError("Model Fitting plugins is not loaded")
        return plg._obj.get_model_parameters(models=models,
                                             model_label=model_label,
                                             x=x, y=y)

    def show(self, loc="inline", title=None, height=None,
             tray=None):  # pragma: no cover
        """Display the Jdaviz application.

        Parameters
        ----------
        loc : str
            The display location determines where to present the viz app.
            Supported locations:

            "inline": Display the Jdaviz application inline in a notebook.
            Note this is functionally equivalent to displaying the cell
            ``viz._app`` in the notebook.

            "sidecar": Display the Jdaviz application in a separate JupyterLab window from the
            notebook, the location of which is decided by the 'anchor.' right is the default

                Other anchors:

                * ``sidecar:right`` (The default, opens a tab to the right of display)
                * ``sidecar:tab-before`` (Full-width tab before the current notebook)
                * ``sidecar:tab-after`` (Full-width tab after the current notebook)
                * ``sidecar:split-right`` (Split-tab in the same window right of the notebook)
                * ``sidecar:split-left`` (Split-tab in the same window left of the notebook)
                * ``sidecar:split-top`` (Split-tab in the same window above the notebook)
                * ``sidecar:split-bottom`` (Split-tab in the same window below the notebook)

                See `jupyterlab-sidecar <https://github.com/jupyter-widgets/jupyterlab-sidecar>`_
                for the most up-to-date options.

            "popout": Display the Jdaviz application in a detached display. By default, a new
            window will open. Browser popup permissions required.

                Other anchors:

                * ``popout:window`` (The default, opens Jdaviz in a new, detached popout)
                * ``popout:tab`` (Opens Jdaviz in a new, detached tab in your browser)

        title : str, optional
            The title of the sidecar tab.  Defaults to the name of the
            application; e.g., "specviz".

            NOTE: Only applicable to a "sidecar" display.

        height: int, optional
            The height of the top-level application widget, in pixels. Applies to all
            instances of the same application in the notebook.

        tray: str, optional
            Override the default open sidebar in the tray.  If not provided, will default to
            loaders if no data is loaded, or plugins if data is loaded.

        Notes
        -----
        If "sidecar" is requested in the "classic" Jupyter notebook, the app will appear inline,
        as only JupyterLab has a mechanism to have multiple tabs.
        """
        title = self._app.config if title is None else title
        if height is not None:
            if isinstance(height, int):
                height = f"{height}px"
            self._app.layout.height = height
            self._app.state.settings['context']['notebook']['max_height'] = height

        if tray is not None:
            self._app.state.drawer_content = tray
        elif self._app.config in CONFIGS_WITH_LOADERS or self._app.state.dev_loaders:  # noqa
            if not len(self.viewers) and not len(self._app.state.drawer_content):
                self._app.state.drawer_content = 'loaders'
            else:
                self._app.state.drawer_content = 'plugins'
        else:
            self._app.state.drawer_content = 'plugins'

        show_widget(self._app, loc=loc, title=title)

    def show_in_sidecar(self, anchor=None, title=None):  # pragma: no cover
        """
        Preserved for backwards compatibility
        Shows Jdaviz in a sidecar with the default anchor: right
        """
        warnings.warn('show_in_sidecar has been replaced with show(loc="sidecar")',
                      DeprecationWarning)
        location = 'sidecar' if anchor is None else f"sidecar:{anchor}"
        return self.show(loc=location, title=title)

    def show_in_new_tab(self, title=None):  # pragma: no cover
        """
        Preserved for backwards compatibility
        Shows Jdaviz in a sidecar in a new tab to the right
        """
        warnings.warn('show_in_new_tab has been replaced with show(loc="sidecar:tab-after")',
                      DeprecationWarning)
        return self.show(loc="sidecar:tab-after", title=title)

    def toggle_api_hints(self, enabled=None):
        """
        Toggle the visibility of API hints in the application.

        Parameters
        ----------
        enabled : bool, optional
            If `True`, show API hints. If `False`, hide API hints.
            If `None`, toggle the current state.
        """
        if enabled is None:
            enabled = not self._app.state.show_api_hints
        self._app.state.show_api_hints = enabled

    def _handle_display_units(self, data, use_display_units=True):
        """
        If use_display_units is True, convert data (Spectrum) to the app's
        current display units, which are set by the unit conversion plugin,
        otherwise return data unchanged. This method is called by get_data, so
        it is intended for handling when retrieving data from the app
        and have it automatically converted to app display units, rather than the
        native data units.

        Parameters
        ----------
        data : specutils.Spectrum
            The Spectrum object to convert.
        use_display_units : bool
            If True (default), convert the spectrum to display units. If False,
            return the data unchanged.

        Returns
        -------
        specutils.Spectrum
            A new Spectrum object with data converted to display units. If
            use_display_units is False, returns the input data unchanged.

        Notes
        -----
        If the spectral axis unit of data is pixels, and the
        display unit is not pixels (or vice versa), no conversion is done to allow
        for mixed pixel/world unit viewing (this logic is handled by
        spectral_axis_conversion, which is called from this method when converting
        the spectral axis).

        """
        if use_display_units:
            if isinstance(data, Spectrum):
                spectral_unit = self._app._get_display_unit('spectral')
                if not spectral_unit:
                    return data
                if self._app.config == 'specviz' and self._app._get_display_unit('sb'):
                    y_unit = self._app._get_display_unit('sb')
                else:
                    y_unit = self._app._get_display_unit('spectral_y')

                # if there is no pixel scale factor, and the requested conversion
                # is between flux/sb, then skip. this case is encountered when
                # starting the app? ideally this should raise an error, and this
                # should allow pix2/spaxel but it doesn't - keeping this
                # condition as-is until further investigation
                orig_sa = check_if_unit_is_per_solid_angle(u.Unit(data.flux.unit))
                targ_sa = check_if_unit_is_per_solid_angle(u.Unit(y_unit))
                skip_flux_conv = ('_pixel_scale_factor' not in data.meta) & (orig_sa != targ_sa)

                # equivalencies for flux/sb unit conversions
                pixar_sr = data.meta.get('_pixel_scale_factor', None)
                eqv = all_flux_unit_conversion_equivs(pixar_sr=pixar_sr,
                                                      cube_wave=data.spectral_axis)

                # TODO: any other attributes (meta, wcs, etc)?
                # TODO: implement uncertainty.to upstream
                uncertainty = data.uncertainty
                if uncertainty is not None:
                    # convert the uncertainties to StdDevUncertainties, since
                    # that is assumed in a few places in jdaviz:
                    if uncertainty.unit is None:
                        uncertainty.unit = data.flux.unit
                    if hasattr(uncertainty, 'represent_as'):
                        new_uncert = uncertainty.represent_as(StdDevUncertainty)
                    else:
                        # if not specified as NDUncertainty, assume stddev:
                        new_uncert = uncertainty

                    # convert uncertainty units to display units
                    if skip_flux_conv:
                        new_uncert = StdDevUncertainty(new_uncert, unit=data.flux.unit)
                    else:
                        new_uncert_conv = flux_conversion_general(new_uncert.quantity.value,
                                                                  new_uncert.unit,
                                                                  y_unit,
                                                                  eqv,
                                                                  with_unit=False)
                        new_uncert = StdDevUncertainty(new_uncert_conv,
                                                       unit=y_unit)
                else:
                    new_uncert = None

                # convert flux/sb units to display units
                if skip_flux_conv:
                    new_y = data.flux.value * u.Unit(data.flux.unit)
                else:
                    # multiply by unit rather than using with_unit because of
                    # edge case for dimensionless we want here
                    new_y = flux_conversion_general(data.flux.value,
                                                    data.flux.unit,
                                                    y_unit,
                                                    eqv, with_unit=False) * u.Unit(y_unit)

                # convert spectral axis to display units
                if data.spectral_axis.unit != spectral_unit:
                    new_spec = (spectral_axis_conversion(data.spectral_axis.value,
                                                         data.spectral_axis.unit,
                                                         spectral_unit, with_unit=True))
                else:
                    new_spec = data.spectral_axis

                data = Spectrum(spectral_axis=new_spec,
                                flux=new_y,
                                uncertainty=new_uncert,
                                mask=data.mask,
                                spectral_axis_index=data.spectral_axis_index)
            else:  # pragma: nocover
                raise NotImplementedError(f"converting {data.__class__.__name__} to display units is not supported")  # noqa
        return data

    def _get_data(self, data_label=None, spatial_subset=None, spectral_subset=None,
                  temporal_subset=None, mask_subset=None, cls=None, use_display_units=False):
        list_of_valid_subset_names = [x.label for x in self._app.data_collection.subset_groups]
        for subset in (spatial_subset, spectral_subset, mask_subset):
            if subset and subset not in list_of_valid_subset_names:
                raise ValueError(f"Subset {subset} not in list of valid"
                                 f" subset names {list_of_valid_subset_names}")

        if data_label and data_label not in self._app.data_collection.labels:
            raise ValueError(f'{data_label} not in {self._app.data_collection.labels}.')
        elif not data_label and len(self._app.data_collection) > 1:
            raise ValueError('data_label must be set if more than'
                             ' one data exists in data_collection.')
        elif not data_label and len(self._app.data_collection) == 1:
            data_label = self._app.data_collection[0].label

        if cls is not None and not isclass(cls):
            raise TypeError(
                "cls in get_data must be a class or None.")

        if spectral_subset:
            if mask_subset is not None:
                raise ValueError("cannot use both mask_subset and spectral_subset")
            # spectral_subset is applied as a mask, the only difference is that it has
            # its own set of validity checks (whereas mask_subset can be used by downstream
            # apps which would then need to do their own type checks, if necessary)
            mask_subset = spectral_subset

        if temporal_subset:
            if mask_subset is not None:
                raise ValueError("cannot use both mask_subset and temporal_subset")
            mask_subset = temporal_subset

        # End validity checks and start data retrieval
        data = self._app.data_collection[data_label]

        if not cls:
            if data.meta.get('_native_data_cls', None) is not None:
                cls = data.meta['_native_data_cls']
            # TODO: once everything goes through loaders, can we remove everything below?
            elif 'Trace' in data.meta:
                cls = None
            elif data.ndim == 2 and self._app.config == "specviz2d":
                cls = Spectrum
            elif data.ndim == 2:
                cls = CCDData
            elif data.ndim in [1, 3]:
                if self._app.config == 'rampviz':
                    cls = NDDataArray
                else:
                    # for cubeviz, specviz, mosviz, this must be a spectrum:
                    cls = Spectrum

        object_kwargs = {}
        if cls == Spectrum:
            object_kwargs['statistic'] = None
            if 'spectral_axis_index' in data.meta:
                object_kwargs['spectral_axis_index'] = data.meta['spectral_axis_index']

        if not spatial_subset and not mask_subset:
            if 'Trace' in data.meta:
                # ignore cls
                data = data.get_object()
            else:
                data = data.get_object(cls=cls, **object_kwargs)

            return self._handle_display_units(data, use_display_units)

        if not cls and spatial_subset:
            raise AttributeError(f"A valid cls must be provided to"
                                 f" apply subset {spatial_subset} to data. "
                                 f"Instead, {cls} was given.")
        elif not cls and mask_subset:
            raise AttributeError(f"A valid cls must be provided to"
                                 f" apply subset {mask_subset} to data. "
                                 f"Instead, {cls} was given.")

        # Now we work on applying subsets to the data
        all_subsets = self._app.get_subsets(object_only=True)

        # Handle spatial subset
        if spatial_subset and not isinstance(all_subsets[spatial_subset][0],
                                             Region):
            raise ValueError(f"{spatial_subset} is not a spatial subset.")
        elif spatial_subset:
            real_spatial = [sub for subsets in self._app.data_collection.subset_groups
                            for sub in subsets.subsets
                            if sub.data.label == data_label and subsets.label == spatial_subset][0]
            handler, _ = data_translator.get_handler_for(cls)
            try:
                data = handler.to_object(real_spatial, **object_kwargs)
            except Exception as e:
                warnings.warn(f"Not able to get {data_label} returned with"
                              f" subset {spatial_subset} applied of type {cls}."
                              f" Exception: {e}")

        # Handle spectral subset, including case where spatial subset is also set
        if spectral_subset and not isinstance(all_subsets[spectral_subset],
                                              SpectralRegion):
            raise ValueError(f"{spectral_subset} is not a spectral subset.")

        if mask_subset:
            real_spectral = [sub for subsets in self._app.data_collection.subset_groups
                             for sub in subsets.subsets
                             if sub.data.label == data_label and subsets.label == mask_subset][0] # noqa

            handler, _ = data_translator.get_handler_for(cls)
            try:
                spec_subset = handler.to_object(real_spectral, **object_kwargs)
            except Exception as e:
                warnings.warn(f"Not able to get {data_label} returned with"
                              f" subset {mask_subset} applied of type {cls}."
                              f" Exception: {e}")
            if spatial_subset:
                # Return collapsed Spectrum object with spectral subset mask applied
                data.mask = spec_subset.mask
            else:
                data = spec_subset

        return self._handle_display_units(data, use_display_units)

    def get_data(self, data_label=None, cls=None, use_display_units=False, **kwargs):
        """
        Returns data with name equal to data_label of type cls.

        Parameters
        ----------
        data_label : str, optional
            Provide a label to retrieve a specific data set from data_collection.
        cls : `~specutils.Spectrum`, `~astropy.nddata.CCDData`, optional
            The type that data will be returned as.
        use_display_units : bool, optional
            Whether to convert to the display units defined in the <unit-conversion> plugin.

        Returns
        -------
        data : cls
            Data is returned as type ``cls``.

        """
        return self._get_data(data_label=data_label,
                              cls=cls, use_display_units=use_display_units)


class ImageConfigHelper(ConfigHelper):
    """`ConfigHelper` that uses an image viewer as its primary viewer.
    For example, Imviz and Cubeviz.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # NOTE: The first viewer must always be there and is an image viewer.
        self._default_viewer = self._app.get_viewer_by_id(f'{self._app.config}-0')

    @property
    def default_viewer(self):
        """Default viewer instance. This is typically the first viewer
        (e.g., "imviz-0" or "cubeviz-0")."""
        return JdavizViewerWindow(self._default_viewer, app=self._app).user_api

    @deprecated(since="4.2", alternative="subset_tools.import_region")
    def load_regions_from_file(self, region_file, region_format='ds9', max_num_regions=20,
                               **kwargs):
        """Load regions defined in the given file.
        See :ref:`regions:regions_io` for supported file formats.
        See :meth:`load_regions` for how regions are loaded.

        Parameters
        ----------
        region_file : str
            Path to region file.

        region_format : {'crtf', 'ds9', 'fits'}
            See :meth:`regions.Regions.get_formats`.

        max_num_regions : int or `None`
            Maximum number of regions to read from the file, starting
            from top of the file. Default is first 20 regions that
            can be successfully loaded. If `None`, it will load everything.

        kwargs : dict
            See :meth:`load_regions`.

        Returns
        -------
        bad_regions : list of (obj, str) or `None`
            See :meth:`load_regions`.

        """
        from regions import Regions
        raw_regs = Regions.read(region_file, format=region_format)
        return self.load_regions(raw_regs, max_num_regions=max_num_regions, **kwargs)

    @deprecated(since="4.2", alternative="subset_tools.import_region")
    def load_regions(self, regions, max_num_regions=None, refdata_label=None,
                     return_bad_regions=False, **kwargs):
        """Load given region(s) into the viewer.
        WCS-to-pixel translation and mask creation, if needed, is relative
        to the image defined by ``refdata_label``. Meanwhile, the rest of
        the Subset operations are based on reference image as defined by Glue.

        .. note:: Loading too many regions will affect performance.

        A valid region can be loaded into one of the following categories:

        * An interactive Subset, as if it was drawn by hand. This is
          always done for supported shapes. Its label will be
          ``'Subset N'``, where ``N`` is an integer.
        * A masked Subset that will display on the image but cannot be
          modified once loaded. This is done if the shape cannot be
          made interactive. Its label will be ``'MaskedSubset N'``,
          where ``N`` is an integer.

        Parameters
        ----------
        regions : list of obj
            A list of region objects. A region object can be one of the following:

            * Astropy ``regions`` object
            * ``photutils`` apertures (limited support until ``photutils``
              fully supports ``regions``)

        max_num_regions : int or `None`
            Maximum number of regions to load, starting from top of the list.
            Default is to load everything.

        refdata_label : str or `None`
            Label of data to use for sky-to-pixel conversion for a region, or
            mask creation. Data must already be loaded into Jdaviz.
            If `None`, defaults to the reference data in the default viewer.
            Choice of this data is particularly important when sky
            region is involved.

        return_bad_regions : bool
            If `True`, return the regions that failed to load (see ``bad_regions``);
            This is useful for debugging. If `False`, do not return anything (`None`).

        kwargs : dict
            Extra keywords to be passed into the region's ``to_mask`` method.
            **This is ignored if the region can be made interactive.**

        Returns
        -------
        bad_regions : list of (obj, str) or `None`
            If requested (see ``return_bad_regions`` option), return a
            list of ``(region, reason)`` tuples for region objects that failed to load.
            If all the regions loaded successfully, this list will be empty.
            If not requested, return `None`.

        """
        if len(self._app.data_collection) == 0:
            raise ValueError('Cannot load regions without data.')

        from photutils.aperture import (CircularAperture, SkyCircularAperture,
                                        EllipticalAperture, SkyEllipticalAperture,
                                        RectangularAperture, SkyRectangularAperture,
                                        CircularAnnulus, SkyCircularAnnulus)
        from regions import (Regions, CirclePixelRegion, CircleSkyRegion,
                             EllipsePixelRegion, EllipseSkyRegion,
                             RectanglePixelRegion, RectangleSkyRegion,
                             CircleAnnulusPixelRegion, CircleAnnulusSkyRegion)
        from jdaviz.core.region_translators import regions2roi, aperture2regions

        # If user passes in one region obj instead of list, try to be smart.
        if not isinstance(regions, (list, tuple, Regions)):
            regions = [regions]

        n_loaded = 0
        bad_regions = []

        # To keep track of masked subsets.
        msg_prefix = 'MaskedSubset'
        msg_count = _next_subset_num(msg_prefix, self._app.data_collection.subset_groups)

        # Subset is global but reference data is viewer-dependent.
        if refdata_label is None:
            data = self.default_viewer._obj.glue_viewer.state.reference_data
        else:
            data = self._app.data_collection[refdata_label]

        # TODO: Make this work for data cube.
        # https://github.com/glue-viz/glue-astronomy/issues/75
        has_wcs = data_has_valid_wcs(data, ndim=2)

        for region in regions:
            if (isinstance(region, (SkyCircularAperture, SkyEllipticalAperture,
                                    SkyRectangularAperture, SkyCircularAnnulus,
                                    CircleSkyRegion, EllipseSkyRegion,
                                    RectangleSkyRegion, CircleAnnulusSkyRegion))
                    and not has_wcs):
                bad_regions.append((region, 'Sky region provided but data has no valid WCS'))
                continue

            if (isinstance(region, (CircularAperture, EllipticalAperture,
                                    RectangularAperture, CircularAnnulus,
                                    CirclePixelRegion, EllipsePixelRegion,
                                    RectanglePixelRegion, CircleAnnulusPixelRegion))
                    and self._app._align_by == "wcs"):
                bad_regions.append((region, 'Pixel region provided by data is aligned by WCS'))
                continue

            # photutils: Convert to regions shape first
            if isinstance(region, (CircularAperture, SkyCircularAperture,
                                   EllipticalAperture, SkyEllipticalAperture,
                                   RectangularAperture, SkyRectangularAperture,
                                   CircularAnnulus, SkyCircularAnnulus)):
                region = aperture2regions(region)

            # regions: Convert to ROI.
            # NOTE: Out-of-bounds ROI will succeed; this is native glue behavior.
            if isinstance(region, (CirclePixelRegion, CircleSkyRegion,
                                   EllipsePixelRegion, EllipseSkyRegion,
                                   RectanglePixelRegion, RectangleSkyRegion,
                                   CircleAnnulusPixelRegion, CircleAnnulusSkyRegion)):
                state = regions2roi(region, wcs=data.coords)

                # TODO: Do we want user to specify viewer? Does it matter?
                self._app.session.edit_subset_mode._mode = NewMode
                self.default_viewer._obj.glue_viewer.apply_roi(state)
                self._app.session.edit_subset_mode.edit_subset = None  # No overwrite next iteration # noqa

            # Last resort: Masked Subset that is static (if data is not a cube)
            elif data.ndim == 2:
                im = None
                if hasattr(region, 'to_pixel'):  # Sky region: Convert to pixel region
                    if not has_wcs:
                        bad_regions.append((region, 'Sky region provided but data has no valid WCS'))  # noqa
                        continue
                    region = region.to_pixel(data.coords)

                if hasattr(region, 'to_mask'):
                    try:
                        mask = region.to_mask(**kwargs)
                        im = mask.to_image(data.shape)  # Can be None
                    except Exception as e:  # pragma: no cover
                        bad_regions.append((region, f'Failed to load: {repr(e)}'))
                        continue

                # Boolean mask as input is supported but not advertised.
                elif (isinstance(region, np.ndarray) and region.shape == data.shape
                        and region.dtype == np.bool_):
                    im = region

                if im is None:
                    bad_regions.append((region, 'Mask creation failed'))
                    continue

                # NOTE: Region creation info is thus lost.
                try:
                    subset_label = f'{msg_prefix} {msg_count}'
                    state = MaskSubsetState(im, data.pixel_component_ids)
                    self._app.data_collection.new_subset_group(subset_label, state)
                    msg_count += 1
                except Exception as e:  # pragma: no cover
                    bad_regions.append((region, f'Failed to load: {repr(e)}'))
                    continue

            else:
                bad_regions.append((region, 'Mask creation failed'))
                continue

            n_loaded += 1
            if max_num_regions is not None and n_loaded >= max_num_regions:
                break

        n_reg_in = len(regions)
        n_reg_bad = len(bad_regions)
        if n_loaded == 0:
            snack_color = "error"
        elif n_reg_bad > 0:
            snack_color = "warning"
        else:
            snack_color = "success"
        self._app.hub.broadcast(SnackbarMessage(
            f"Loaded {n_loaded}/{n_reg_in} regions, max_num_regions={max_num_regions}, "
            f"bad={n_reg_bad}", color=snack_color, timeout=8000, sender=self._app))

        if return_bad_regions:
            return bad_regions

    @deprecated(since="4.1", alternative="subset_tools.get_regions")
    def get_interactive_regions(self):
        """
        Return spatial regions that can be interacted with in the viewer.
        This does not return masked regions added via :meth:`load_regions`.

        Unsupported region shapes will be skipped. When that happens,
        a yellow snackbar message will appear on display.

        Returns
        -------
        regions : dict
            Dictionary mapping interactive region names to respective Astropy
            ``regions`` objects.

        """
        from glue_astronomy.translators.regions import roi_subset_state_to_region

        regions = {}
        failed_regs = set()
        to_sky = self._app._align_by == 'wcs'

        # Subset is global, so we just use default viewer.
        for lyr in self.default_viewer._obj.glue_viewer.layers:
            if (not hasattr(lyr, 'layer') or not isinstance(lyr.layer, Subset)
                    or lyr.layer.ndim not in (2, 3)):
                continue

            subset_data = lyr.layer
            subset_label = subset_data.label

            try:
                if self._app.config == "imviz" and to_sky:
                    region = roi_subset_state_to_region(subset_data.subset_state, to_sky=to_sky)
                else:
                    region = subset_data.data.get_selection_definition(
                        subset_id=subset_label, format='astropy-regions')
            except (NotImplementedError, ValueError):
                failed_regs.add(subset_label)
            else:
                regions[subset_label] = region

        if len(failed_regs) > 0:
            self._app.hub.broadcast(SnackbarMessage(
                f"Regions skipped: {', '.join(sorted(failed_regs))}",
                color="warning", timeout=8000, sender=self._app))

        return regions

    # TODO: Make this public API?
    def _delete_region(self, subset_label):
        """Delete region given the Subset label."""
        all_subset_labels = [s.label for s in self._app.data_collection.subset_groups]
        if subset_label not in all_subset_labels:
            return
        i = all_subset_labels.index(subset_label)
        subset_grp = self._app.data_collection.subset_groups[i]
        self._app.data_collection.remove_subset_group(subset_grp)


def _next_subset_num(label_prefix, subset_groups):
    """Assumes ``prefix i`` format.
    Does not go back and fill in lower but available numbers. This is consistent with Glue.
    """
    max_i = 0

    for sg in subset_groups:
        if sg.label.startswith(label_prefix):
            sub_label = sg.label.split(' ')
            if len(sub_label) > 1:
                i_str = sub_label[-1]
                try:
                    i = int(i_str)
                except Exception:  # nosec
                    continue
                else:
                    if i > max_i:
                        max_i = i

    return max_i + 1


class CubeConfigHelper(ImageConfigHelper):
    """Base config helper class for cubes"""

    _loaded_flux_cube = None
    _loaded_uncert_cube = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @deprecated(since="4.1", alternative="plugins['Spectral Slice'].slice")
    def select_slice(self, value):
        """
        Select the slice closest to the provided value.

        Parameters
        ----------
        value : float or int, optional
            Slice value to select in units of the x-axis of the profile viewer.
            The nearest slice will be selected if "snap to slice" is enabled in
            the slice plugin.
        """
        msg = SliceSelectSliceMessage(value=value, sender=self)
        self._app.hub.broadcast(msg)
