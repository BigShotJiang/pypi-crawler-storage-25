<template>
  <v-container>
    <plugin-select
      :items="extension_items"
      :selected.sync="extension_selected"
      :show_if_single_entry="true"
      :multiselect="multiselect"
      :exists_in_dc="existing_data_in_dc"
      label="Extension"
      api_hint="ldr.importer.extension ="
      :api_hints_enabled="api_hints_enabled"
      hint="Extension to use for flux."
    />
    <!-- NOTE: do not pass existing_data_in_dc here since unc does not get its own DC entries -->
    <plugin-select
      v-if="has_unc"
      :items="unc_extension_items"
      :selected.sync="unc_extension_selected"
      :show_if_single_entry="true"
      :multiselect="multiselect"
      :nonmultiselect_allow_clear="true"
      label="Uncertainty Extension"
      api_hint="ldr.importer.unc_extension ="
      :api_hints_enabled="api_hints_enabled"
      hint="Extension to use for uncertainty."
    />
    <plugin-auto-label
      :value.sync="data_label_value"
      :default="data_label_default"
      :auto.sync="data_label_auto"
      :invalid_msg="data_label_invalid_msg"
      label="Data Label"
      api_hint="ldr.importer.data_label ="
      :api_hints_enabled="api_hints_enabled"
      hint="Label to assign to the new data entry."
    ></plugin-auto-label>

    <plugin-viewer-create-new
      :items="viewer_items"
      :selected.sync="viewer_selected"
      :create_new_items="viewer_create_new_items"
      :create_new_selected.sync="viewer_create_new_selected"
      :new_label_value.sync="viewer_label_value"
      :new_label_default="viewer_label_default"
      :new_label_auto.sync="viewer_label_auto"
      :new_label_invalid_msg="viewer_label_invalid_msg"
      :multiselect="viewer_multiselect"
      :show_multiselect_toggle="false"
      label="Viewer"
      api_hint='ldr.importer.viewer = '
      :api_hints_enabled="api_hints_enabled"
      :show_if_single_entry="true"
      hint="Select the viewer to use for the new data entry."
    ></plugin-viewer-create-new>

    <j-plugin-section-header>Extracted Spectrum</j-plugin-section-header>
    <plugin-switch
      :value.sync="auto_extract"
      label="Extract 1D Spectrum"
      api_hint="ldr.importer.auto_extract ="
      :api_hints_enabled="api_hints_enabled"
      hint="Extract a 1D spectrum from the 2D data (use the 2D Spectral Extraction Plugin after importing to extract with custom aperture/options)."
    ></plugin-switch>
    <div v-if="auto_extract">
      <plugin-auto-label
        :value.sync="ext_data_label_value"
        :default="ext_data_label_default"
        :auto.sync="ext_data_label_auto"
        :invalid_msg="ext_data_label_invalid_msg"
        label="Extracted 1D Spectrum Data Label"
        api_hint="ldr.importer.ext_data_label ="
        :api_hints_enabled="api_hints_enabled"
        hint="Label to assign to the auto-extracted 1D Spectrum."
      ></plugin-auto-label>

      <plugin-viewer-create-new
        :items="ext_viewer_items"
        :selected.sync="ext_viewer_selected"
        :create_new_items="ext_viewer_create_new_items"
        :create_new_selected.sync="ext_viewer_create_new_selected"
        :new_label_value.sync="ext_viewer_label_value"
        :new_label_default="ext_viewer_label_default"
        :new_label_auto.sync="ext_viewer_label_auto"
        :new_label_invalid_msg="ext_viewer_label_invalid_msg"
        :multiselect="ext_viewer_multiselect"
        :show_multiselect_toggle="false"
        label="Viewer for Extracted Spectrum"
        api_hint='ldr.importer.ext_viewer = '
        :api_hints_enabled="api_hints_enabled"
        :show_if_single_entry="true"
        hint="Select the viewer to use for the new extracted 1D Spectrum data entry."
      ></plugin-viewer-create-new>
    </div>

    <loader-import-button
      :spinner="import_spinner"
      :disabled_msg="import_disabled_msg"
      :api_hints_enabled="api_hints_enabled"
      api_hint="ldr.load()"
      :data_label_overwrite="data_label_overwrite"
      @click="import_clicked">
    </loader-import-button>
  </v-container>
</template>