from astropy.coordinates import SkyCoord
from astropy.io.fits import BinTableHDU, HDUList, TableHDU
from astropy.table import Table, QTable, vstack
import astropy.units as u
import numpy as np
from traitlets import Any, Bool, List, Unicode, observe

from jdaviz.core.loaders.importers import BaseImporterToDataCollection
from jdaviz.core.template_mixin import SelectFileExtensionComponent, SelectPluginComponent
from jdaviz.core.registries import loader_importer_registry
from jdaviz.core.user_api import ImporterUserApi
from jdaviz.utils import RA_COMPS, DEC_COMPS, create_data_hash

__all__ = ['CatalogImporter']


@loader_importer_registry("Catalog")
class CatalogImporter(BaseImporterToDataCollection):

    template_file = __file__, "./catalog.vue"

    # for catalogs with source positions in sky coordinates
    col_ra_items = List().tag(sync=True)
    col_ra_selected = Unicode().tag(sync=True)
    col_dec_items = List().tag(sync=True)
    col_dec_selected = Unicode().tag(sync=True)

    col_ra_has_unit = Bool().tag(sync=True)  # if input already has units
    col_ra_unit_items = List().tag(sync=True)
    col_ra_unit_selected = Unicode().tag(sync=True)
    col_dec_has_unit = Bool().tag(sync=True)  # if input already has units
    col_dec_unit_items = List().tag(sync=True)
    col_dec_unit_selected = Unicode().tag(sync=True)

    # for catalogs with source positions in pixel coordinates
    col_x_items = List().tag(sync=True)
    col_x_selected = Unicode().tag(sync=True)
    col_y_items = List().tag(sync=True)
    col_y_selected = Unicode().tag(sync=True)

    # (optional) to select column used as source IDs, which will be what is
    # displayed for mouseover. If None selected, an index column is used.
    col_id_items = List().tag(sync=True)
    col_id_selected = Unicode().tag(sync=True)

    # additional (optional) non-position columns to load (e.g. flux, id)
    col_other_items = List().tag(sync=True)
    col_other_selected = List().tag(sync=True)
    col_other_multiselect = Bool(True).tag(sync=True)

    # HDUList-specific options
    input_has_extensions = Bool(False).tag(sync=True)
    extension_items = List().tag(sync=True)
    extension_selected = Any().tag(sync=True)
    extension_multiselect = Bool(True).tag(sync=True)
    no_common_col_msg = Unicode().tag(sync=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if not self.is_valid:
            return

        if isinstance(self.input, HDUList):
            self.input_has_extensions = True

            ext_options = [{'label': f"{index}: [{hdu.name},{hdu.ver}]",
                            'name': hdu.name,
                            'ver': hdu.ver,
                            'name_ver': f"{hdu.name},{hdu.ver}",
                            'index': index,
                            'data_hash': create_data_hash(hdu),
                            'obj': hdu} for index, hdu in enumerate(self.input)]

            self.extension = SelectFileExtensionComponent(self,
                                                          items='extension_items',
                                                          selected='extension_selected',
                                                          multiselect='extension_multiselect',
                                                          manual_options=ext_options,
                                                          filters=[_validate_fits_tablehdu])

            # the choices have already been filtered to only valid table HDUs, so
            # choose the 0th to select the first valid table HDU by default
            self.extension.selected = [self.extension.choices[0]]

        else:
            # otherwise, we got a Table object as input and can proceed
            # to create the column selection components directly
            self.input_has_extensions = False

        input = self.input_as_table

        # dropdowns for catalogs with source positions in sky coordinates
        self.col_ra = SelectPluginComponent(self,
                                            items='col_ra_items',
                                            selected='col_ra_selected',
                                            manual_options=self._guess_coord_cols('ra'))
        self.col_dec = SelectPluginComponent(self,
                                             items='col_dec_items',
                                             selected='col_dec_selected',
                                             manual_options=self._guess_coord_cols('dec'))

        self.col_ra_unit = SelectPluginComponent(self,
                                                 items='col_ra_unit_items',
                                                 selected='col_ra_unit_selected',
                                                 manual_options=self._valid_coord_units('ra'))
        self.col_dec_unit = SelectPluginComponent(self,
                                                  items='col_dec_unit_items',
                                                  selected='col_dec_unit_selected',
                                                  manual_options=self._valid_coord_units('dec'))

        # dropdown for source ID column
        self.col_id = SelectPluginComponent(self,
                                            items='col_id_items',
                                            selected='col_id_selected',
                                            manual_options=['Default (index)'] + input.colnames)  # noqa

        # dropdowns for tables with pixel source positions
        self.col_x = SelectPluginComponent(self,
                                           items='col_x_items',
                                           selected='col_x_selected',
                                           manual_options=self._guess_coord_cols('x'))
        self.col_y = SelectPluginComponent(self,
                                           items='col_y_items',
                                           selected='col_y_selected',
                                           manual_options=self._guess_coord_cols('y'))

        # dropdowns for (optional) additional columns
        self.col_other = SelectPluginComponent(self,
                                               items='col_other_items',
                                               selected='col_other_selected',
                                               manual_options=input.colnames,
                                               multiselect='col_other_multiselect')

    @property
    def input_as_table(self):
        if hasattr(self, 'extension'):
            if self.extension.selected in [None, '', []]:
                return None

            table_ext = self.extension.selected_obj

            # reset message about no common columns between extensions each time
            # we get the input as table, so that if the user changes to a different
            # extension or selection of extensions, the message will be cleared
            self.no_common_col_msg = ''
            table_types = (TableHDU, BinTableHDU)

            if len(table_ext) == 1 and isinstance(table_ext[0], table_types):
                return QTable(table_ext[0].data)

            elif len(table_ext) > 1 and all(isinstance(t, table_types) for t in table_ext):
                # combine tables, only including columns that are common beween
                # all tables in the selection. There will be text in the UI to
                # indicate this and suggest loading tables individually if the
                # the selected extensions contain different column names.
                tables = [QTable(ext.data) for ext in table_ext]
                common_cols = set(tables[0].colnames)
                for tab in tables[1:]:
                    common_cols = common_cols & set(tab.colnames)

                common_cols = list(common_cols)

                # if there are no common columns between tables, we can't combine
                # them. return None and the UI will indicate that the user should
                # load tables separately.
                if len(common_cols) == 0:
                    msg = (
                        "The selected extensions have no columns in common. "
                        "Please select a single extension to load, or select "
                        "multiple extensions that have at least one column "
                        "name in common to enable loading in multiselect mode."
                    )
                    self.no_common_col_msg = msg
                    return None

                combined_table = vstack([t[common_cols] for t in tables],
                                        join_type="exact")

                return combined_table

        return self.input

    @property
    def is_valid(self):
        if self._app.config not in ('deconfigged', 'imviz', 'mastviz'):
            # NOTE: temporary during deconfig process
            return False
        if isinstance(self.input, (Table, QTable)) and len(self.input):
            return True
        elif isinstance(self.input, HDUList):
            # check for the presence of at least one TableHDU/BinTableHDU extension
            for i, hdu in enumerate(self.input):
                if isinstance(hdu, (TableHDU, BinTableHDU)) and len(hdu.data) > 0:
                    return True
        return False

    def _update_col_items_and_selected(self, base_attr, options, select_first=True):
        """update column items and selected value."""
        items_attr = f'{base_attr}_items'
        selected_attr = f'{base_attr}_selected'

        setattr(self, items_attr, [{'label': item} for item in options])
        self.send_state(items_attr)

        if select_first:
            setattr(self, selected_attr, options[0] if options else None)
        else:
            setattr(self, selected_attr, [])
        self.send_state(selected_attr)

    @observe('extension_selected')
    def _on_extension_selected_change(self, event):
        # when the selected extension changes, we need to update the column selection dropdowns
        # with the columns from the newly selected extension
        if not hasattr(self, 'extension'):
            return

        # if no column selection dropdowns have been created yet, we can skip
        # the update since they will be created with the correct columns based
        # on the selected extension in the __init__
        if not hasattr(self, 'col_x'):
            return

        input = self.input_as_table

        if input is None:
            # if input is None, that means the selected extensions had no common
            # columns, so we should clear out the column selection dropdowns
            # options (this section will be hidden in the UI)
            for col in ['ra', 'dec', 'x', 'y']:
                self._update_col_items_and_selected(f'col_{col}', ['---'])
            self._update_col_items_and_selected('col_other', ['---'], select_first=False)
            return

        if not isinstance(input, (Table, QTable)):
            return

        # update column selection dropdowns with columns from the newly selected extension
        for col in ['ra', 'dec', 'x', 'y']:
            self._update_col_items_and_selected(f'col_{col}', self._guess_coord_cols(col))

        self._update_col_items_and_selected('col_other', input.colnames, select_first=False)

    def _guess_coord_cols(self, col):
        """
        Rough guess at detecting RA/Dec/X/Y columns from input table to determine
        the initial selections for the column select dropdown. This starts
        by checking for the presence of a SkyCoord (if col is 'ra' or 'dec') or
        PixCoord column (if col is 'x' or 'y'), and next checking
        against some common source catalog column names. If no good candidate
        column is found, the initial selection in the drop down for RA/x, dec/y
        columns will be '---' (no selection)
        """

        input = self.input_as_table

        if not isinstance(input, (Table, QTable)):
            return

        colnames = input.colnames

        if colnames is None:
            return

        idx = None
        if col in ['ra', 'dec']:
            col_is_sc = [isinstance(input[colnames[i]], SkyCoord) for i in range(len(colnames))]
            if np.any(col_is_sc):
                idx = np.where(col_is_sc)[0][0]

        if idx is None:
            # remove spaces/underscores/hyphens/quotes/parentheses and make lowercase for matching
            # TODO: merge this functionality with utils.in_ra_comps / in_dec_comps?
            all_column_names = np.array([
                str(x).lower()
                .replace(' ', '')
                .replace('_', '')
                .replace('-', '')
                .replace('"', '')
                .replace('(', '')
                .replace(')', '')
                for x in colnames
            ])
            get_idx = lambda x, s, d: np.where(np.isin(x, s))[0][0] if np.any(np.isin(x, s)) else d  # noqa
            if col == 'ra':
                idx = get_idx(all_column_names, RA_COMPS, None)
            elif col == 'dec':
                idx = get_idx(all_column_names, DEC_COMPS, None)
            elif col == 'x':
                col_possibilities = ["x", "xpos", "xcentroid", "xcenter",
                                     "xpixel", "pixelx", "xpix", "ximage", "ximg",
                                     "xcoord", "xcoordinate", "sourcex", "xsource",
                                     "x1", "x2", "x_centroid", "x_center",
                                     "x_peak"]
                idx = get_idx(all_column_names, col_possibilities, None)
            elif col == 'y':
                col_possibilities = ["y", "ypos", "ycentroid", "ycenter",
                                     "ypixel", "pixely", "ypix", "yimage", "yimg",
                                     "ycoord", "ycoordinate", "sourcey", "ysource",
                                     "y1", "y2", "y_centroid", "y_center",
                                     "y_peak"]
                idx = get_idx(all_column_names, col_possibilities, None)

        # if no good candidate found, default to '---' (no selection) for
        # the default selection.
        if idx is None:
            return ['---'] + colnames
        return_cols = colnames if idx == 0 else (colnames[idx:] + colnames[:idx])
        # non-selection is the second option, so you don't have to scroll
        # all the way down to see that its an option not to load a column
        return [return_cols[0]] + ['---'] + return_cols[1:]

    def _valid_coord_units(self, coord):
        """Valid choices for Ra, Dec units."""

        choices = ['deg', 'rad', 'arcmin', 'arcsec']

        if 'ra' in coord:
            choices += ['hour minute second']
        elif 'dec' in coord:
            choices += ['degree arcmin arcsec']

        return choices

    @observe('col_ra_selected', 'col_dec_selected', 'col_x_selected', 'col_y_selected')
    def _on_coordinate_column_selected(self, msg):
        """
        - Check if the newly selected 'ra' or 'dec' column has units assigned
        already, to set the col_ra_has_unit and col_dec_has_unit traitlets.
        -  Make sure that ra and dec columns are not the same (unless SkyCoord) and
        disable the import button if they are the same.
        - Check if only RA or Dec is selected without the other, and disable import
        in that case.
        """

        ra = self.col_ra_selected
        dec = self.col_dec_selected
        x = self.col_x_selected
        y = self.col_y_selected

        import_disabled = False

        input = self.input_as_table

        if not isinstance(input, (Table, QTable)):
            return

        if msg['name'] in ('col_ra_selected', 'col_dec_selected'):

            axis = ra if msg['name'] == 'col_ra_selected' else dec

            if axis == '---':
                # no selection, assume 'has units' to disable unit selection dropdown
                if msg['name'] == 'col_ra_selected':
                    self.col_ra_has_unit = True
                elif msg['name'] == 'col_dec_selected':
                    self.col_dec_has_unit = True
                # disable import if RA is selected but Dec is not (or vice versa)
                if (ra in ['---', ''] or ra is None) != (dec in ['---', ''] or dec is None):
                    import_disabled = True
                return

            has_units = False
            if isinstance(input[axis], SkyCoord):
                has_units = True
            elif hasattr(input[axis], 'unit'):
                if input[axis].unit is not None:
                    has_units = True
                    # unit must be an angle unit
                    if input[axis].unit.physical_type != 'angle':
                        has_units = False

            # set the 'has units' traitlets for ra/dec, which determine if the unit
            # selection dropdowns should be exposed
            if msg['name'] == 'col_ra_selected':
                self.col_ra_has_unit = has_units
            elif msg['name'] == 'col_dec_selected':
                self.col_dec_has_unit = has_units

            # disable import if the same ra and dec columns are selected
            # and they are NOT a SkyCoord column (which contains both RA and Dec),
            if ra == dec and not isinstance(input[axis], SkyCoord):
                import_disabled = True
            else:
                import_disabled = False

            # disable import if RA is selected but Dec is not (or vice versa)
            if (ra in ['---', ''] or ra is None) != (dec in ['---', ''] or dec is None):
                import_disabled = True

        elif msg['name'] in ('col_x_selected', 'col_y_selected'):
            # disable import if RA is selected but Dec is not (or vice versa)
            if (x in ['---', ''] or x is None) != (y in ['---', ''] or y is None):
                import_disabled = True

        # finally, set the import_disabled_msg traitlet based on what was determined
        # from the checks above. Empty msg = enabled, non-empty = disabled
        if import_disabled:
            self.import_disabled_msg = (
                "Cannot import catalog without valid coordinate column pair. "
                "Select both RA and Dec, or both X and Y coordinates."
            )
        else:
            self.import_disabled_msg = ''

    @staticmethod
    def _get_supported_viewers():
        return [{'label': 'Image', 'reference': 'imviz-image-viewer', 'allow_create': False},
                {'label': 'Scatter', 'reference': 'scatter-viewer'},
                {'label': 'Histogram', 'reference': 'histogram-viewer'},
                {'label': 'Table', 'reference': 'table-viewer'}]

    @property
    def user_api(self):
        expose = ['col_ra', 'col_dec', 'col_x', 'col_y', 'col_id', 'col_other']
        if self.input_has_extensions:
            expose += ['extension']
        return ImporterUserApi(self, expose=expose)

    @property
    def output_cols(self):

        input = self.input_as_table

        if not isinstance(input, (Table, QTable)):
            return

        coordinate_cols = []
        for col in [self.col_ra_selected, self.col_dec_selected]:
            if col not in ['---', ''] and col is not None:
                coordinate_cols.append(col)
        for col in [self.col_x_selected, self.col_y_selected]:
            if col not in ['---', ''] and col is not None:
                coordinate_cols.append(col)
        if self.col_id_selected not in ['Default (index)', '', None]:
            coordinate_cols.append(self.col_id_selected)

        cols_all = coordinate_cols + self.col_other_selected

        return [col for col in set(cols_all) if col in input.colnames]

    @property
    def output(self):

        input = self.input_as_table

        if not isinstance(input, (Table, QTable)):
            return

        table = input[self.output_cols]
        output_table = QTable()

        # Handle RA / Dec columns, if selected
        if (self.col_ra_selected in table.colnames) and (self.col_dec_selected in table.colnames):  # noqa
            ra = input[self.col_ra_selected]
            dec = input[self.col_dec_selected]

            # The only modification made to the output table is the addition of individual
            # RA, Dec columns if the input columns are SkyCoord. This avoids unpacking
            # RA and Dec and checking if components are a SkyCoord every time they
            # are accessed.
            col_ra_selected = self.col_ra_selected  # final output col name
            col_dec_selected = self.col_dec_selected  # final output col name
            if isinstance(ra, SkyCoord):
                ra = ra.ra
                col_ra_selected = 'SkyCoord_RA'
            if isinstance(dec, SkyCoord):
                dec = dec.dec
                col_dec_selected = 'SkyCoord_Dec'

            # If the columns are strings, pass them through 'SkyCoord', which can
            # determine if the string format is recognizable as Lon/Lat coordinates.
            if isinstance(ra[0], str):
                try:
                    ra = SkyCoord(ra, ra).ra  # dummy value 'ra' twice, just to parse string
                except (ValueError, u.UnitTypeError):
                    raise ValueError("Could not parse RA column as string coordinates.")
            if isinstance(dec[0], str):
                try:
                    dec = SkyCoord(dec, dec).dec  # dummy value 'dec' twice, just to parse string
                except (ValueError, u.UnitTypeError):
                    raise ValueError("Could not parse Dec column as string coordinates.")

            # append units to RA/Dec, if they weren't loaded in with units or
            # assigned units above when parsing strings as units
            if getattr(ra, 'unit') is None:
                ra = ra.astype(float) * u.Unit(self.col_ra_unit_selected)
            if getattr(dec, 'unit') is None:
                dec = dec.astype(float) * u.Unit(self.col_dec_unit_selected)

            output_table[col_ra_selected] = ra
            output_table[col_dec_selected] = dec

            # add the selected ra/dec columns to meta
            output_table.meta['_jdaviz_loader_ra_col'] = col_ra_selected
            output_table.meta['_jdaviz_loader_dec_col'] = col_dec_selected

        # handle output construction for X and Y coordinate columns, if selected
        if (self.col_x_selected in table.colnames) and (self.col_y_selected in table.colnames):  # noqa
            # if input is a string, try to convert to floats
            if isinstance(input[self.col_x_selected][0], str):
                try:
                    x_col = [float(x) for x in table[self.col_x_selected]]
                    output_table['X'] = x_col
                except ValueError:
                    raise ValueError("Could not parse X column as numeric values.")
            else:
                output_table['X'] = table[self.col_x_selected].astype(float)

            if isinstance(input[self.col_y_selected][0], str):
                try:
                    y_col = [float(y) for y in table[self.col_y_selected]]
                    output_table['Y'] = y_col
                except ValueError:
                    raise ValueError("Could not parse Y column as numeric values.")
            else:
                output_table['Y'] = table[self.col_y_selected].astype(float)

            output_table[self.col_x_selected] = table[self.col_x_selected]
            output_table[self.col_y_selected] = table[self.col_y_selected]

            # add the selected ra/dec columns to meta
            output_table.meta['_jdaviz_loader_x_col'] = self.col_x_selected
            output_table.meta['_jdaviz_loader_y_col'] = self.col_y_selected

        # add source ID column. If no column selected, just use table index
        # for now this will be added as a column named 'ID' in the output table,
        # but this should be changed to adding a component label in JDAT-5716

        if self.col_id_selected in table.colnames:
            output_table['ID'] = table[self.col_id_selected]
            output_table.meta['_jdaviz_id_col'] = self.col_id_selected
        else:
            output_table['ID'] = np.arange(len(table))
            output_table.meta['_jdaviz_id_col'] = 'ID'

        # add additional columns to output table
        for col in self.output_cols:
            if col not in output_table.colnames + [self.col_ra_selected, self.col_dec_selected]:
                output_table[col] = table[col]

        return output_table


def _validate_fits_tablehdu(item):
    hdu = item.get('obj')
    return isinstance(hdu, (TableHDU, BinTableHDU))
