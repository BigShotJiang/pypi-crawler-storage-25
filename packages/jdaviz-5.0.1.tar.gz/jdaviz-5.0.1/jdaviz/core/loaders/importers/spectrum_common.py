import itertools
import numpy as np

from asdf import AsdfFile
from astropy import units as u
from astropy.io import fits
from astropy.nddata import InverseVariance, StdDevUncertainty, VarianceUncertainty
from astropy.table import Table, Column
from astropy.wcs import WCS
from functools import cached_property
from glue.core import HubListener
from ipyvuetify import VuetifyTemplate
from specutils import Spectrum, SpectrumList, SpectrumCollection
from specutils.io.parsing_utils import generic_spectrum_from_table
from traitlets import Any, Bool, List, Unicode, observe

from jdaviz.core.events import SnackbarMessage
from jdaviz.core.template_mixin import SelectFileExtensionComponent
from jdaviz.core.unit_conversion_utils import check_if_unit_is_per_solid_angle
from jdaviz.core.custom_units_and_equivs import PIX2, _eqv_flux_to_sb_pixel
from jdaviz.utils import (standardize_metadata,
                          create_data_hash,
                          PRIHDR_KEY,
                          SPECTRAL_AXIS_COMP_LABELS,
                          _get_celestial_wcs)

__all__ = ['SpectrumInputExtensionsMixin', '_spectrum_assign_component_type']


def _spectrum_assign_component_type(comp_id, comp, units, physical_type):
    if not len(units) and comp_id == 'flux':
        units = 'ct'
    if units in ('ct', 'pixel'):
        physical_type = units

    if comp_id in SPECTRAL_AXIS_COMP_LABELS:
        if 'Pixel Axis' in comp_id and physical_type is None:
            physical_type = 'pixel'
        if physical_type in ('frequency', 'length'):
            # link frequency to wavelength
            return 'spectral_axis'
        if physical_type is not None:
            return f'spectral_axis:{physical_type}'

    if physical_type is None:
        return None
    if comp_id == 'uncertainty':
        # don't link with flux columns
        return f'uncertainty:{physical_type}'
    return physical_type


class SpectrumInputExtensionsMixin(VuetifyTemplate, HubListener):
    input_type = Unicode().tag(sync=True)

    multiselect = Bool(True).tag(sync=True)
    data_label_is_prefix = Bool(False).tag(sync=True)

    extension_items = List().tag(sync=True)
    extension_selected = Any().tag(sync=True)

    unc_extension_items = List().tag(sync=True)
    unc_extension_selected = Any().tag(sync=True)

    mask_extension_items = List().tag(sync=True)
    mask_extension_selected = Any().tag(sync=True)

    dq_extension_items = List().tag(sync=True)
    dq_extension_selected = Any().tag(sync=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if isinstance(self.input, fits.HDUList):
            self.input_type = 'fits:hdulist'
            ext_options = [{'label': f"{index}: {hdu.name}",
                            'name': hdu.name,
                            'ver': hdu.ver,
                            'name_ver': f"{hdu.name},{hdu.ver}",
                            'index': index,
                            'data_hash': create_data_hash(hdu),
                            'obj': hdu}
                           for index, hdu in enumerate(self.input)
                           ]

        elif isinstance(self.input, AsdfFile) and 'roman' in self.input:
            self.input_type = 'asdf:roman'
            ext_options = [{'label': f"{ind}: {k}",
                            'name': k,
                            'name_ver': k,
                            'index': ind,
                            'data_hash': create_data_hash(ext),
                            'obj': ext}
                           for ind, (k, ext) in enumerate(self.input['roman']['data'].items())
                           ]

        elif isinstance(self.input, (SpectrumList, SpectrumCollection)):
            self.input_type = 'specutils:spectrumlist'
            ext_options = []
            for index, spec in enumerate(self.input):
                if self.is_wfssmulti(spec):
                    # ver, name are stand-ins for exposure and source_id
                    # ver == exposure, name == source_id
                    ver, name = self._extract_exposure_sourceid(spec)
                    exposure_label = f"Exposure {ver}"

                    label = f"{exposure_label}, Source ID: {name}"
                    # Flipping the two from the variable naming convention
                    name_ver = f"{ver}_{name}"
                    suffix = f"EXP-{ver}_ID-{name}"

                else:
                    name_ver = index
                    name = index
                    ver = index
                    label = f"1D Spectrum at index: {index}"
                    suffix = f"index-{index}"

                spec = self._apply_spectral_mask(spec)
                ext_options.append({'label': label,
                                    'index': index,
                                    'name': str(name),
                                    'ver': str(ver),
                                    'name_ver': str(name_ver),
                                    'suffix': suffix,
                                    'data_hash': create_data_hash(spec),
                                    'obj': spec})
        elif isinstance(self.input, Spectrum) and self.input.flux.ndim == self.supported_flux_ndim:
            self.input_type = 'specutils:spectrum'
            ext_options = [{'label': f'spectrum.{attr}',
                            'name': attr,
                            'name_ver': None,
                            'index': ind+1,  # to match indexing of HDUList for load_data defaults
                            'data_hash': create_data_hash(self.input),
                            'obj': self.input}
                           for ind, attr in enumerate(('flux', 'uncertainty', 'mask'))
                           if getattr(self.input, attr, None) is not None
                           ]
        elif isinstance(self.input, Spectrum) and self.input.flux.ndim > self.supported_flux_ndim:
            if self.supported_flux_ndim != 1 or self.input.flux.ndim != 2:
                # currently only support 2D Spectrum > list of 1D Spectra
                raise ValueError("Input spectrum has more than supported number of dimensions.")
            # convert 2D Spectrum to SpectrumList of 1D Spectra
            self.input_type = 'specutils:spectrumlist'
            spectra = self._to_list_of_spectra(self.input)
            ext_options = [{'label': f'1D Spectrum at index: {index}',
                            'index': index,
                            'name': index,
                            'name_ver': index,
                            'suffix': f"index-{index}",
                            'data_hash': create_data_hash(spec),
                            'obj': spec}
                           for index, spec in enumerate(spectra)
                           ]
        else:
            raise TypeError(f"Input type not supported for SpectrumInputExtensionsMixin: "
                            f"{type(self.input).__name__} ({type(self.input).__module__})")

        self.extension = SelectFileExtensionComponent(self,
                                                      items='extension_items',
                                                      selected='extension_selected',
                                                      multiselect='multiselect',
                                                      manual_options=ext_options,
                                                      filters=[self.is_valid_flux],
                                                      default_mode='first')
        self.data_hashes = self.extension.data_hashes
        self.hash_map_to_label = dict(zip(self.extension.data_hashes, self.extension.labels))
        self.extension.select_default()

        self.unc_extension = SelectFileExtensionComponent(self,
                                                          items='unc_extension_items',
                                                          selected='unc_extension_selected',
                                                          multiselect='multiselect',
                                                          manual_options=ext_options,
                                                          filters=[self.is_valid_unc],
                                                          default_mode='first')
        self.unc_extension.select_default()
        self.mask_extension = SelectFileExtensionComponent(self,
                                                           items='mask_extension_items',
                                                           selected='mask_extension_selected',
                                                           multiselect='multiselect',
                                                           manual_options=ext_options,
                                                           filters=[self.is_valid_mask],
                                                           default_mode='first')
        self.mask_extension.select_default()
        self.dq_extension = SelectFileExtensionComponent(self,
                                                         items='dq_extension_items',
                                                         selected='dq_extension_selected',
                                                         multiselect='multiselect',
                                                         manual_options=ext_options,
                                                         filters=[self.is_valid_dq],
                                                         default_mode='first')
        self.dq_extension.select_default()

        # set default data-label
        self._on_extension_change()

    def _cleanup(self):
        for attr in ('extension', 'unc_extension', 'mask_extension', 'dq_extension'):
            if not hasattr(self, attr):
                continue

            for ext in getattr(self, attr).manual_options:
                try:
                    del ext['obj'].data
                except Exception:  # nosec
                    pass

        if self.input_type == 'fits:hdulist':
            for hdu in self.input:
                try:
                    del hdu.data
                except Exception:  # nosec
                    pass

        self._clear_cache('spectra')

    @staticmethod
    def is_wfssmulti(spec):
        return 'WFSSMulti' in spec.meta.get('header', {}).get('DATAMODL', '')

    @staticmethod
    def _extract_exposure_sourceid(spec):
        """
        Generate a label for WFSSMulti sources based on the header information.
        """
        header = spec.meta.get('header', {})
        exp_num = header.get('EXPGRPID', '0_0_0').split('_')[-2]
        source_id = str(spec.meta.get('source_id', ''))

        return exp_num, source_id

    @staticmethod
    def _has_mask(spec):
        if hasattr(spec, 'mask'):
            if spec.mask is not None and len(spec.mask):
                return True
        return False

    def _is_fully_masked(self, spec):
        if self._has_mask(spec):
            # all == True implies the entire array is masked and unusable
            if all(spec.mask):
                return True
        return False

    def _apply_spectral_mask(self, spec):
        # The masks (spec.spectral_axis.mask and spec.mask) for WFSS L3 spectra
        # may not be equivalent, so we only apply the spectral_axis mask to avoid
        # a Specutils error. Specutils expects the spectral axis to be strictly
        # increasing/decreasing so applying the 'full' mask may throw that error.
        if self._has_mask(spec.spectral_axis) and not self._is_fully_masked(spec):
            mask = spec.spectral_axis.mask
            # NOTE: Something breaks when the following is attempted instead
            # of the current implementation
            #
            # spec.mask = spec.mask | spec.spectral_axis.mask
            # return spec
            return Spectrum(
                spectral_axis=spec.spectral_axis[~mask],
                flux=spec.flux[~mask],
                uncertainty=spec.uncertainty[~mask],
                mask=mask[~mask],
                meta=spec.meta)

        return spec

    @property
    def supported_flux_ndim(self):
        return 2

    @property
    def default_spectral_axis_index(self):
        return 1

    def is_valid_flux(self, item):
        if self.input_type == 'fits:hdulist':
            return self.hdu_is_valid_flux(item)
        if self.input_type == 'asdf:roman':
            return self.asdf_roman_is_valid_flux(item)
        if self.input_type == 'specutils:spectrum':
            return item.get('name') == 'flux'
        if self.input_type == 'specutils:spectrumlist':
            return True  # TODO: replace this
        raise NotImplementedError("Unknown input type")

    def hdu_is_valid_flux(self, item):
        """
        Check if the HDU is valid to be imported for the flux in a Spectrum.

        Parameters
        ----------
        hdu : `astropy.io.fits.hdu.base.HDUBase`
            The HDU to check.

        Returns
        -------
        bool
            True if the HDU is a valid flux HDU, False otherwise.
        """
        if item.get('label') == 'None':
            # require selection for flux
            return False
        hdu = item.get('obj')

        # Check for Binary Table HDU with spectral columns (for 1D spectra only)
        if isinstance(hdu, (fits.BinTableHDU, fits.TableHDU)):
            if (hasattr(hdu, 'columns') and hdu.columns is not None and
                    self.supported_flux_ndim == 1):
                col_names = [name.upper() for name in hdu.columns.names]
                # Check for wavelength column
                has_wave = any(name in col_names for name in ['WAVE', 'WAVELENGTH', 'LAMBDA'])
                # Check for flux column (or variations)
                has_flux = any('FLUX' in name for name in col_names)
                if has_wave and has_flux:
                    return True

        # Check for Image HDU (existing logic)
        return (len(getattr(hdu, 'shape', [])) == self.supported_flux_ndim
                and ('DISPAXIS' in hdu.header
                     or hdu.header.get('CTYPE1', '') == 'WAVE'
                     or hdu.header.get('EXTNAME', '') == 'FLUX'))

    def asdf_roman_is_valid_flux(self, item):
        if item.get('label') == 'None':
            # require selection for flux
            return False
        if self.supported_flux_ndim == 1:
            return all(k in item.get('obj').keys() for k in ["wl", "flux"])
        elif self.supported_flux_ndim == 2:
            return all(k in item.get('obj').keys() for k in ["spectrum", "wavelength"])
        else:
            raise NotImplementedError("Only 1D and 2D spectra are supported for ASDF Roman data")

    def is_valid_unc(self, item):
        if item.get('label') == 'None':
            return True
        if self.input_type == 'fits:hdulist':
            return self.hdu_is_valid_unc(item)
        if self.input_type == 'asdf:roman':
            return self.asdf_roman_is_valid_unc(item)
        if self.input_type == 'specutils:spectrum':
            return item.get('name') == 'uncertainty'
        if self.input_type == 'specutils:spectrumlist':
            return False  # TODO: replace this
        raise NotImplementedError("Unknown input type")

    def hdu_is_valid_unc(self, item):
        """
        Check if the HDU is valid to be imported for the uncertainty in a Spectrum.

        Parameters
        ----------
        hdu : `astropy.io.fits.hdu.base.HDUBase`
            The HDU to check.

        Returns
        -------
        bool
            True if the HDU is a valid uncertainty HDU. False otherwise.
        """
        hdu = item.get('obj')
        return (len(getattr(hdu, 'shape', [])) == self.supported_flux_ndim
                and (hdu.header.get('EXTNAME', '') in ['ERR', 'IVAR', 'VAR']))

    def asdf_roman_is_valid_unc(self, item):
        # TODO: should this instead have options just to include or not
        # include and pull from the flux extension?
        return all(k in item.get('obj').keys() for k in ["flux", "flux_err"])

    def is_valid_mask(self, item):
        if item.get('label') == 'None':
            return True
        if self.input_type == 'fits:hdulist':
            return self.hdu_is_valid_mask(item)
        if self.input_type == 'asdf:roman':
            return self.asdf_roman_is_valid_mask(item)
        if self.input_type == 'specutils:spectrum':
            return item.get('name') == 'mask'
        if self.input_type == 'specutils:spectrumlist':
            return False  # TODO: replace this
        raise NotImplementedError("Unknown input type")

    def hdu_is_valid_mask(self, item):
        """
        Check if the HDU is valid to be imported for the mask in a Spectrum.

        Parameters
        ----------
        hdu : `astropy.io.fits.hdu.base.HDUBase`
            The HDU to check.

        Returns
        -------
        bool
            True if the HDU is a valid mask HDU, False otherwise.
        """
        hdu = item.get('obj')
        return (len(getattr(hdu, 'shape', [])) == self.supported_flux_ndim
                and hdu.header.get('EXTNAME', '') == 'MASK')

    def asdf_roman_is_valid_mask(self, item):
        # TODO: should this instead have options just to include or not
        # include and pull from the flux extension?
        return False

    def is_valid_dq(self, item):
        if item.get('label') == 'None':
            return True
        if self.input_type == 'fits:hdulist':
            return self.hdu_is_valid_dq(item)
        if self.input_type == 'asdf:roman':
            return self.asdf_roman_is_valid_dq(item)
        if self.input_type == 'specutils:spectrum':
            return False  # Spectrum doesn't have a dq attribute
        if self.input_type == 'specutils:spectrumlist':
            return False  # TODO: replace this
        raise NotImplementedError("Unknown input type")

    def hdu_is_valid_dq(self, item):
        """
        Check if the HDU is valid to be imported for the data quality in a Spectrum.

        Parameters
        ----------
        hdu : `astropy.io.fits.hdu.base.HDUBase`
            The HDU to check.

        Returns
        -------
        bool
            True if the HDU is a valid DQ HDU, False otherwise.
        """
        hdu = item.get('obj')
        return (len(getattr(hdu, 'shape', [])) == self.supported_flux_ndim
                and hdu.header.get('EXTNAME', '') == 'DQ')

    def asdf_roman_is_valid_dq(self, item):
        name = item.get('name')
        return name == 'dq'

    @observe('extension_items',
             'extension_selected',
             'unc_extension_selected',
             'mask_extension_selected',
             'dq_extension_selected')
    def _on_extension_change(self, change={}):
        self._clear_cache('spectra')

        if not hasattr(self, 'extension'):
            return
        self.data_label_is_prefix = self.multiselect and len(self.extension.selected) > 1

    def _to_list_of_spectra(self, inp):
        def this_row(field, i):
            if field is None:
                return None
            return field[i, :]

        if isinstance(inp, Spectrum):
            if inp.flux.ndim == 1:
                return [self._apply_spectral_mask(inp)]

            # 2D spectrum: split into list of 1D spectra
            return [Spectrum(spectral_axis=inp.spectral_axis,
                             flux=this_row(inp.flux, i),
                             uncertainty=this_row(inp.uncertainty, i),
                             mask=this_row(inp.mask, i),
                             meta=inp.meta)
                    for i in range(inp.flux.shape[0])]

        elif isinstance(inp, (list, SpectrumList, SpectrumCollection)):
            return list(itertools.chain(*[self._to_list_of_spectra(spec) for spec in inp]))

        else:
            raise NotImplementedError(f"{inp} is not supported")

    def _spectrum_from_table_hdu(self, hdulist, hdu):
        """Extract spectrum from Binary Table HDU with array-valued columns."""
        # Read the HDU as an astropy Table
        table = Table.read(hdu)

        # if columns are shape (1, N), flatten them before passing to generic_spectrum_from_table
        needs_flattening = any(
            col.ndim == 2 and col.shape[0] == 1 for col in table.itercols()
        )

        if needs_flattening:
            # Create new columns with flattened data, preserving units
            new_cols = []
            for col in table.itercols():
                if col.ndim == 2 and col.shape[0] == 1:
                    # Extract first row and preserve unit
                    new_cols.append(Column(name=col.name, data=col[0], unit=col.unit))
                else:
                    new_cols.append(col)
            # Create a new table with flattened columns
            table = Table(new_cols, meta=table.meta)

        # Use specutils' generic_spectrum_from_table to parse the data
        spectrum = generic_spectrum_from_table(table)

        # Update metadata with standardized headers
        header = hdu.header
        metadata = standardize_metadata(header)
        if hdu.name != 'PRIMARY' and 'PRIMARY' in hdulist:
            metadata[PRIHDR_KEY] = standardize_metadata(hdulist[0].header)

        # Preserve any metadata from the table parsing and update with our standardized metadata
        if spectrum.meta is None:
            spectrum.meta = metadata
        else:
            spectrum.meta.update(metadata)

        return spectrum

    def _spectrum_from_hdu(self, hdulist, hdu):
        # Handle Binary Table HDU with spectral columns
        if isinstance(hdu, (fits.BinTableHDU, fits.TableHDU)):
            return self._spectrum_from_table_hdu(hdulist, hdu)

        data = hdu.data
        header = hdu.header
        metadata = standardize_metadata(header)
        if hdu.name != 'PRIMARY' and 'PRIMARY' in hdulist:
            metadata[PRIHDR_KEY] = standardize_metadata(hdulist[0].header)

        wcs = WCS(header, hdulist)

        spectral_axis_index = None

        try:
            data_unit = u.Unit(header['BUNIT'])
        except Exception:
            data_unit = u.count

        if self.unc_extension.selected not in ('', 'None'):
            unc_hdu = self.unc_extension.selected_obj
            unc_data = unc_hdu.data
        else:
            unc_data = None
        if self.mask_extension.selected not in ('', 'None'):
            mask_hdu = self.mask_extension.selected_obj
            mask_data = mask_hdu.data
        else:
            mask_data = None

        if unc_data is not None:
            # if extension is IVAR/VAR, convert to standard deviation for
            # consistency internally
            if self.unc_extension.selected_obj.header.get('EXTNAME', '') == 'IVAR':
                unc = InverseVariance(unc_data).represent_as(StdDevUncertainty)
                unc.unit = data_unit
            elif self.unc_extension.selected_obj.header.get('EXTNAME', '') == 'VAR':
                unc = VarianceUncertainty(unc_data).represent_as(StdDevUncertainty)
                unc.unit = data_unit
            else:
                unc = StdDevUncertainty(unc_data * data_unit)
        else:
            unc = None

        if self.supported_flux_ndim == 2:
            spectral_axis_index = 1
            if data.shape[0] > data.shape[1]:
                data = data.T
                if unc_data is not None:
                    unc_data = unc_data.T
                if mask_data is not None:
                    mask_data = mask_data.T
                if getattr(wcs, 'naxis', 0) == 2:
                    wcs = wcs.swapaxes(0, 1)
                self._app.hub.broadcast(SnackbarMessage(
                    f"Transposed input data to {data.shape}",
                    sender=self, color="warning"))

        # Check for data types that have a GWCS stored in ASDF
        telescop = metadata[PRIHDR_KEY].get('TELESCOP', '').lower()
        exptype = metadata[PRIHDR_KEY].get('EXP_TYPE', '').lower()
        # NOTE: Alerted to deprecation of FILETYPE keyword from pipeline on 2022-07-08
        # Kept for posterity in for data processed prior to this date. Use EXP_TYPE instead
        filetype = metadata[PRIHDR_KEY].get('FILETYPE', '').lower()

        # Cubes and 2D data need different checks to see if we want WCS from ASDF
        asdf_3d = (telescop == 'jwst' and ('ifu' in exptype or
                                           'mrs' in exptype or
                                           filetype == '3d ifu cube'))
        asdf_2d = (wcs.world_axis_physical_types == [None, None] or
                   (hasattr(wcs, 'spectral') and wcs.spectral.naxis == 0))

        if (data.ndim == 2 and asdf_2d) or (data.ndim == 3 and asdf_3d):
            if 'ASDF' in hdulist:
                try:
                    from stdatamodels import asdf_in_fits
                    tree = asdf_in_fits.open(hdulist).tree
                    if 'meta' in tree and 'wcs' in tree['meta']:
                        wcs = tree["meta"]["wcs"]
                        if isinstance(wcs, (list, tuple)):
                            wcs = wcs[0]
                        # Check needed for BSUB files, which we want to allow without worrying
                        # about the wavelength solution for now
                        if len(wcs.forward_transform.inputs) == 5:
                            wcs = None
                        # TODO: This is a temporary fix until handled upstream in glue
                        # For 2D spectra, disable 3D GWCS
                        # This prevents glue-astronomy from misidentifying component
                        # units (setting Wavelength to 'deg' instead of wavelength unit).
                        elif (self.supported_flux_ndim == 2 and
                              getattr(wcs, 'world_n_dim', 0) > self.supported_flux_ndim):
                            wcs = None
                    else:
                        wcs = None
                except ValueError:
                    wcs = None
            else:
                wcs = None

        try:
            sc = Spectrum(flux=data * data_unit, uncertainty=unc,
                          mask=mask_data, meta=metadata, wcs=wcs,
                          spectral_axis_index=spectral_axis_index)
        except ValueError:
            # In some cases, the above call to Spectrum will fail if no
            # spectral axis is found in the WCS. Even without a spectral axis,
            # the Spectrum.read parser may work, so we try that next.
            # If that also fails, then drop the WCS.
            try:
                sc = Spectrum.read(self._parser.input)
            except Exception:
                # specutils.Spectrum reader would fail, so use no WCS
                sc = Spectrum(
                        flux=data * data_unit, uncertainty=unc,
                        meta=metadata, spectral_axis_index=self.default_spectral_axis_index)
            else:
                # raising an error here will consider this parser as non-valid
                # so that specutils.Spectrum parser is preferred
                raise

        # convert flux and uncertainty to per-pix2 if input is not a surface brightness
        target_flux_unit = None
        target_wave_unit = None
        apply_pix2 = 'FLUX' in self.extension.selected or 'ERR' in self.extension.selected
        flux = sc.flux
        if (apply_pix2 and
                (not check_if_unit_is_per_solid_angle(flux.unit))):
            target_flux_unit = flux.unit / PIX2
        elif check_if_unit_is_per_solid_angle(flux.unit, return_unit=True) == "spaxel":
            # We need to convert spaxel to pixel squared, since spaxel isn't fully supported
            # by astropy
            # This is horribly ugly but just multiplying by u.Unit("spaxel") doesn't work
            target_flux_unit = flux.unit * u.Unit('spaxel') / PIX2
        if target_wave_unit is None and hdulist is not None:
            found_target = False
            for ext in ('SCI', 'FLUX', 'PRIMARY', 'DATA'):  # In priority order
                if found_target:
                    break
                if ext not in hdulist:
                    continue
                hdr = hdulist[ext].header
                # The WCS could be swapped or unswapped.
                for cunit_num in (3, 1):
                    cunit_key = f"CUNIT{cunit_num}"
                    ctype_key = f"CTYPE{cunit_num}"
                    if cunit_key in hdr and 'WAV' in hdr[ctype_key]:
                        target_wave_unit = u.Unit(hdr[cunit_key])
                        found_target = True
                        break
        if target_wave_unit == sc.spectral_axis.unit:
            target_wave_unit = None
        if (target_wave_unit is None) and (target_flux_unit is None):  # Nothing to convert
            new_sc = sc
        elif target_flux_unit is None:  # Convert wavelength only
            new_sc = sc.with_spectral_axis_unit(target_wave_unit)
        elif target_wave_unit is None:  # Convert flux only and only PIX2 stuff
            new_sc = sc.with_flux_unit(target_flux_unit, equivalencies=_eqv_flux_to_sb_pixel())
        else:  # Convert both
            new_sc = sc.with_spectral_axis_and_flux_units(
                target_wave_unit, target_flux_unit, flux_equivalencies=_eqv_flux_to_sb_pixel())
        if target_wave_unit is not None:
            new_sc.meta['_orig_spec'] = sc
        # Since we create a new Spectrum, we need to copy over any original WCS info
        # since the WCS will be replaced by a SpectralGWCS object instead of the original
        # astropy.wcs.WCS object.
        # This is needed for the subset tools to work properly.
        if new_sc.flux.ndim == 3 and _get_celestial_wcs(sc.wcs) is not None:
            new_sc.meta['_orig_spatial_wcs'] = _get_celestial_wcs(sc.wcs)

        return new_sc

    def _spectrum_from_roman_asdf(self, extension, meta):
        def _to_unit(x):
            """Coerce str/bytes/Unit to astropy.units.Unit."""
            if isinstance(x, bytes):
                x = x.decode()
            return u.Unit(x)

        if self.supported_flux_ndim == 1:
            wavelength = np.asarray(extension["wl"])
            flux = np.asarray(extension["flux"])
            wl_unit = _to_unit(meta["unit_wl"])
            flux_unit = _to_unit(meta["unit_flux"])

            # TODO: expose option in unc_extension that defaults to pulling
            # from flux extension, but also allowing user to set to "None"
            # to skip loading uncertainty
            flux_error = extension.get("flux_error", None)
            variance = extension.get("var", None)
            uncertainty = None
        elif self.supported_flux_ndim == 2:
            # TODO: handle detecting/selecting spectral axis?
            flux = np.asarray(extension["spectrum"]).transpose()
            flux_unit = _to_unit(meta["unit_flux"])
            if extension['wavelength'] is not None:
                wavelength = np.asarray(extension["wavelength"])
                wl_unit = _to_unit(meta["unit_wl"])
            else:
                wavelength = np.arange(flux.shape[1])
                wl_unit = u.pix

            flux_error = None
            variance = extension.get("variance", None)
            if variance is not None:
                variance = np.asarray(variance).transpose()
            uncertainty = None
        else:
            raise NotImplementedError("Only 1D and 2D spectra are supported for ASDF Roman data")  # noqa

        if flux_error is not None:
            uncertainty = StdDevUncertainty(np.asarray(flux_error) * flux_unit)
        elif variance is not None:
            var = np.asarray(variance) * (flux_unit ** 2)
            var = np.where(np.asarray(var.value) < 0, np.nan, var.value) * var.unit
            uncertainty = StdDevUncertainty(np.sqrt(var))
        else:
            uncertainty = None

        spectrum = Spectrum(
            flux=flux * flux_unit,
            spectral_axis=wavelength * wl_unit,
            uncertainty=uncertainty
        )
        return spectrum

    @property
    def spectrum(self):
        spectra = self.spectra
        if len(spectra) > 1:
            raise ValueError("Multiple spectra found; use 'spectra' property instead.")
        return spectra[0]

    @cached_property
    def spectra(self):
        if self.input_type == 'fits:hdulist':
            hdulist = self.input
            hdus = self.extension.selected_obj if self.multiselect else [self.extension.selected_obj]  # noqa
            return [self._spectrum_from_hdu(hdulist, hdu) for hdu in hdus]
        elif self.input_type == 'asdf:roman':
            roman = self.input["roman"]
            meta = roman["meta"]
            extensions = self.extension.selected_obj if self.multiselect else [self.extension.selected_obj]  # noqa
            return [self._spectrum_from_roman_asdf(extension, meta) for extension in extensions]
        elif self.input_type == 'specutils:spectrum':
            spectrum = self.input
            # TODO: remove uncertainty or mask if requested
            return [spectrum]
        elif self.input_type == 'specutils:spectrumlist':
            # return list of specutils.Spectrum objects
            selected_spectra = (self.extension.selected_obj if self.multiselect
                                else [self.extension.selected_obj])
            return self._to_list_of_spectra(selected_spectra)
