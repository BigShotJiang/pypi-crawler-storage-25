import os

from astropy.coordinates import SkyCoord
from astropy.table import Table, QTable
from astropy.tests.helper import assert_quantity_allclose
from astropy.io import fits
from astropy.nddata import NDData
import astropy.units as u
import numpy as np
import pytest


def _make_catalog(with_units=True, as_skycoord=False):
    """
    Create a sample catalog table with optional units and SkyCoord columns
    for testing purposes.
    """

    ra = [9.423, 9.421, 9.415] * (u.deg if with_units else 1)
    dec = [-33.711, -33.716, -33.717] * (u.deg if with_units else 1)
    obj_id = ['source1', 'source2', 'source3']
    flux = [10, 20, 30] * (u.Jy if with_units else 1)

    tab_cls = QTable if with_units else Table

    if as_skycoord:
        sc = SkyCoord(ra, dec)
        return tab_cls(data=[sc, obj_id, flux], names=['SkyCoord', 'Obj_ID', 'flux'])
    return tab_cls(data=[ra, dec, obj_id, flux],
                   names=['RA', 'Dec', 'Obj_ID', 'flux'])


def _make_catalog_xy_radec(with_units=True, colnames=None):

    ra = [337.52274, 337.48273, 337.48296, 337.52333] * (u.deg if with_units else 1)
    dec = [-20.80742, -20.80741, -20.82380, -20.82425] * (u.deg if with_units else 1)
    x = [-7.27571754, 127.36624541, 126.57857853, -9.26004303]
    y = [94.28695926, 94.30831263, 35.30447687, 33.69891921]
    obj_id = ['source1', 'source2', 'source3', 'source4']
    flux = [10, 20, 30, 40] * (u.Jy if with_units else 1)

    tab_cls = QTable if with_units else Table

    if colnames is None:
        colnames = ['RA', 'Dec', 'X', 'Y', 'Obj_ID', 'flux']

    return tab_cls(data=[ra, dec, x, y, obj_id, flux],
                   names=colnames)


def _make_catalog_string_coord_columns():
    # complete nonsense coordinates, just care about parsing the units
    ra = ['5° 55′ 55″', '5° 55′ 55″', '5° 55′ 55″']
    dec = ['4° 44′ 44″', '4° 44′ 44″', '4° 44′ 44″']
    x = ['1', '2', '3']
    y = ['4', '5', '6']
    obj_id = ['source1', 'source2', 'source3']
    flux = [10, 20, 30] * u.Jy

    return QTable(data=[ra, dec, x, y, obj_id, flux],
                  names=['RA', 'Dec', 'X', 'Y', 'Obj_ID', 'flux'])


def _make_catalog_no_coordinates():
    # Table to test loading catalogs that aren't 'Source Catalogs',
    col1 = ['A', 'B', 'C']
    col2 = [1, 2, 3]
    col3 = [True, False, True]

    return Table(data=[col1, col2, col3],
                 names=['col1', 'col2', 'col3'])


def test_load_catalog_no_source_positions(imviz_helper, image_2d_wcs):
    """
    A table should be able to be loaded without selecting
    an RA/Dec or X/Y pair. This table will not have the functionality
    of a 'Source Catalog' that does have source positions
    (linking, mouseover) but it may be loaded to plot for example
    in the scatter or histogram viewer.
    """
    catalog_obj = _make_catalog_no_coordinates()

    # load data so we can test orientation later
    data = NDData(np.ones((128, 128)), wcs=image_2d_wcs)
    imviz_helper.load(data)

    # load catalog, all columns
    imviz_helper.load(catalog_obj, col_other=['col1', 'col2', 'col3'])

    # check for the table in the data collection
    dc = imviz_helper._app.data_collection
    assert len(dc) == 2
    assert 'Catalog' in imviz_helper._app.data_collection.labels
    tab = imviz_helper._app.data_collection[1].get_object(Table)
    assert 'col1' in tab.colnames

    # make sure linking doesn't produce any errors when alignment changes.
    # this isn't relevant for this catalog with no source positons,
    # but orientation will check for the presence of certain
    # components in a table to decide not to link and we
    # want to make sure that works correctly
    imviz_helper.plugins['Orientation'].align_by = 'WCS'


def test_load_catalog_with_string_coord_cols(imviz_helper):
    """
    Test loading a catalog with string RA/Dec columns (that can be converted
    into units, e.g string representation of hourangle units) into the
    Imviz helper."""
    catalog_obj = _make_catalog_string_coord_columns()

    # load catalog
    imviz_helper.load(catalog_obj)

    dc = imviz_helper._app.data_collection
    assert len(dc) == 1
    assert 'Catalog' in imviz_helper._app.data_collection.labels

    # make coordinate columns were renamed to Right Ascension and Declination,
    # X and Y in the data collection for consistency, and that RA / Dec always
    # has units
    qtab = dc[0].get_object(QTable)
    assert 'RA' in qtab.colnames
    assert 'Dec' in qtab.colnames
    assert 'X' in qtab.colnames
    assert 'Y' in qtab.colnames
    # make sure only ra/dec/x/y/index loaded, since we didn't specify more columns
    assert len(qtab.colnames) == 5
    # and that it has the correct contents, and always has units assigned
    # when data is loaded from a unitless table, units should always be assigned
    # to the catalog in the data collection based on selections in the loader

    # go through SkyCoord to parse weird string format into deg units for comparison
    sc = SkyCoord(ra=catalog_obj['RA'], dec=catalog_obj['Dec'])

    assert_quantity_allclose(qtab['RA'], sc.ra.deg * u.deg)
    assert_quantity_allclose(qtab['Dec'], sc.dec.deg * u.deg)

    # cast data collection X/Y back to strings for comparison
    assert np.all(qtab['X'].astype(str) == catalog_obj['X'].astype(str))
    assert np.all(qtab['Y'].astype(str) == catalog_obj['Y'].astype(str))


@pytest.mark.parametrize("from_file", [True, False])
@pytest.mark.parametrize("with_units", [True, False])
def test_load_catalog_xy_and_radec(imviz_helper, tmp_path, from_file, with_units):
    catalog_obj = _make_catalog_xy_radec(with_units=True)

    if from_file:
        fn = os.path.join(tmp_path, "catalog.ecsv")
        catalog_obj.write(fn)
        catalog = fn
    else:
        catalog = catalog_obj

    # load catalog
    imviz_helper.load(catalog)

    dc = imviz_helper._app.data_collection
    assert len(dc) == 1
    assert 'Catalog' in imviz_helper._app.data_collection.labels

    # make sure 'RA' column was renamed to Right Ascension and 'Dec' to 'Declination'
    # in the data collection for consistency, and that the table in the data
    # collection always has units
    qtab = imviz_helper._app.data_collection[0].get_object(QTable)
    assert 'RA' in qtab.colnames
    assert 'Dec' in qtab.colnames
    assert 'X' in qtab.colnames
    assert 'Y' in qtab.colnames

    # make sure only ra/dec/x/y/index loaded, since we didn't specify more columns
    assert len(qtab.colnames) == 5
    # and that it has the correct contents
    assert_quantity_allclose(qtab['RA'], catalog_obj['RA'])
    assert_quantity_allclose(qtab['Dec'], catalog_obj['Dec'])
    assert_quantity_allclose(qtab['X'], catalog_obj['X'])
    assert_quantity_allclose(qtab['Y'], catalog_obj['Y'])


def test_import_enabled_disabled(imviz_helper):
    """
    Verify that when no coordinate column pair (RA/Dec or X/Y) is selected,
    importing is disabled, when at least one coordinate column pair is selected
    importing is enabled, and when RA is selected but Dec is not (and vice versa,
    along with the same logic for X/Y) importing is disabled.
    """

    catalog_obj = _make_catalog_xy_radec(with_units=True)

    loaders = imviz_helper.loaders
    ldr = loaders['object']
    ldr.object = catalog_obj

    ldr.format = 'Catalog'
    ldr.importer.col_ra.selected = '---'
    ldr.importer.col_dec.selected = '---'
    ldr.importer.col_x.selected = '---'
    ldr.importer.col_y.selected = '---'
    # no coordinate column pair selected, import should still be enabled
    assert len(ldr.importer._obj.import_disabled_msg) == 0

    # when RA is selected but Dec is not, import should be disabled
    ldr.importer.col_ra.selected = 'RA'
    assert len(ldr.importer._obj.import_disabled_msg) > 0
    # and then when Dec is selected too, import should be enabled
    ldr.importer.col_dec.selected = 'Dec'
    assert len(ldr.importer._obj.import_disabled_msg) == 0

    # reset and test the same logic for X/Y
    ldr.importer.col_ra.selected = '---'
    ldr.importer.col_dec.selected = '---'
    ldr.importer.col_x.selected = 'X'
    ldr.importer.col_y.selected = '---'
    # now with no coordinate column pair selected, import should be disabled
    assert len(ldr.importer._obj.import_disabled_msg) > 0
    # when Y is selected too, import should be enabled
    ldr.importer.col_y.selected = 'Y'
    assert len(ldr.importer._obj.import_disabled_msg) == 0


@pytest.mark.parametrize("from_file", [True, False])
@pytest.mark.parametrize("with_units", [True, False])
def test_load_catalog(imviz_helper, image_2d_wcs, tmp_path, from_file, with_units):
    """
    Verify the basic functionality loading catalogs into the data collection.
    Test cases cover both in-memory Astropy tables and ECSV files, and catalogs
    with and without units on RA/Dec columns already assigned.
    """

    # basic catalog with RA, Dec, ID, and Flux columns and units
    catalog_obj = _make_catalog(with_units)

    if from_file:
        fn = os.path.join(tmp_path, "catalog.ecsv")
        catalog_obj.write(fn)
        catalog = fn
    else:
        catalog = catalog_obj

    # load image and align by WCS so loading the catalog will run through the
    # linking code to test it
    data = NDData(np.ones((128, 128)), wcs=image_2d_wcs)
    imviz_helper.load(data)
    imviz_helper.plugins['Orientation'].align_by = 'WCS'

    # load catalog
    imviz_helper.load(catalog)

    # ensure that it is in the data collection with the correct label "Catalog"
    dc = imviz_helper._app.data_collection
    assert len(dc) == 3  # image, orientation layer, and catalog
    assert 'Catalog' in imviz_helper._app.data_collection.labels

    # make sure 'RA' column was renamed to Right Ascension and 'Dec' to 'Declination'
    # in the data collection for consistency, and that the table in the data
    # collection always has units
    qtab = imviz_helper._app.data_collection[-1].get_object(QTable)
    assert 'RA' in qtab.colnames
    assert 'Dec' in qtab.colnames
    # there should also be an ID column
    assert 'ID' in qtab.colnames
    # we didn't specify a specific ID column, so it should just be the index
    # of each source
    assert np.all(qtab['ID'] == np.arange(len(catalog_obj)))
    # make sure only ra and dec (plus index) loaded, since we didn't specify more columns
    assert len(qtab.colnames) == 3
    # and that it has the correct contents, and always has units assigned
    # when data is loaded from a unitless table, units should always be assigned
    # to the catalog in the data collection based on selections in the loader
    un = 1
    if not with_units:
        un = u.deg
    assert_quantity_allclose(qtab['RA'], catalog_obj['RA'] * un)
    assert_quantity_allclose(qtab['Dec'], catalog_obj['Dec'] * un)
    assert qtab['RA'].unit == qtab['Dec'].unit == u.deg

    # make sure 'col_ra_has_unit' is True if the input catalog has units, and is
    # False if the input doesn't have units. This controls the dropdown to
    # select unit is exposed, which is eventually assigned to the table column
    # in the data collection
    ldr = imviz_helper.loaders['file' if from_file else 'object']
    setattr(ldr, 'filepath' if from_file else 'object', catalog)
    assert ldr.importer._obj.col_ra_has_unit == with_units

    # load it again, make sure label incremented by 1
    imviz_helper.load(catalog)
    assert len(dc) == 4  # image, orientation layer, and 2 catalogs
    assert 'Catalog (1)' in imviz_helper._app.data_collection.labels

    # load with custom label and check label
    imviz_helper.load(catalog, data_label='my_catalog')
    assert len(dc) == 5  # image, orientation layer, and 3 catalogs
    assert 'my_catalog' in imviz_helper._app.data_collection.labels

    # test other loader API options. switch RA and Dec col just to test
    # non-default column selection
    imviz_helper.load(catalog, data_label='with_flux', col_other='flux',
                      col_ra='Dec', col_dec='RA')
    assert len(dc) == 6  # image, orientation layer, and 4 catalogs
    assert 'flux' in dc['with_flux'].get_object(QTable).colnames
    qtab = imviz_helper._app.data_collection[-1].get_object(QTable)
    assert_quantity_allclose(qtab['RA'], catalog_obj['RA'] * un)
    assert_quantity_allclose(qtab['Dec'], catalog_obj['Dec'] * un)


@pytest.mark.parametrize("from_file", [True, False])
def test_load_catalog_skycoord(imviz_helper, tmp_path, from_file):
    """
    Test loading a catalog with a SkyCoord column into the Imviz helper.

    This test verifies that when a catalog containing a SkyCoord column is
    loaded, the loader correctly uses this column as the default for
    Right Ascension (RA) and Declination (Dec).
    """
    # test loading catalog with SkyCoord column, which should be used
    # as default for Ra and Dec
    catalog_obj = _make_catalog(as_skycoord=True)

    if from_file:
        fn = os.path.join(tmp_path, "catalog.ecsv")
        catalog_obj.write(fn)
        catalog = fn
    else:
        catalog = catalog_obj

    # load catalog
    imviz_helper.load(catalog)

    dc = imviz_helper._app.data_collection
    assert len(dc) == 1
    assert 'Catalog' in imviz_helper._app.data_collection.labels

    qtab = imviz_helper._app.data_collection[0].get_object(QTable)
    assert 'SkyCoord_RA' in qtab.colnames
    assert 'SkyCoord_Dec' in qtab.colnames
    # make sure only ra and dec (plus index) loaded, since we didn't specify more columns
    assert len(qtab.colnames) == 3
    # and that it has the correct contents, and always has units assigned
    # when data is loaded from a unitless table, units should always be assigned
    # to the catalog in the data collection based on selections in the loader
    assert_quantity_allclose(qtab['SkyCoord_RA'], catalog_obj['SkyCoord'].ra)
    assert_quantity_allclose(qtab['SkyCoord_Dec'], catalog_obj['SkyCoord'].dec)


@pytest.mark.remote_data
@pytest.mark.filterwarnings('ignore::pytest.PytestUnraisableExceptionWarning')
def test_astroquery_load_catalog_source(deconfigged_helper):
    ldr = deconfigged_helper.loaders['astroquery']
    ldr.source = 'M4'
    ldr.telescope = 'Gaia'
    ldr.max_results = 10
    ldr.query_archive()
    assert 'Catalog' in ldr.format.choices
    ldr.format = 'Catalog'

    ldr.importer.col_id = 'source_id'
    ldr.importer.col_other = ['parallax', 'pm', 'bp_rp', 'phot_rp_mean_mag']
    ldr.importer.viewer.create_new = 'Scatter'
    ldr.load()
    assert 'Scatter' in deconfigged_helper.viewers
    assert 'Catalog' in deconfigged_helper.viewers['Scatter'].data_menu.layer.choices


@pytest.mark.remote_data
def test_astroquery_load_catalog_from_viewer(deconfigged_helper):
    arr = np.ones((1489, 2048))

    # header is based on the data provided above
    hdu1 = fits.ImageHDU(arr, name='SCI')
    hdu1.header.update({'CTYPE1': 'RA---TAN',
                        'CUNIT1': 'deg',
                        'CD1_1': -7.80378407867e-05,
                        'CD1_2': 7.74904339463e-05,
                        'CRPIX1': 1025.0,
                        'CRVAL1': 6.62750450757,
                        'NAXIS1': 2048,
                        'CTYPE2': 'DEC--TAN',
                        'CUNIT2': 'deg',
                        'CD2_1': 7.74973322238e-05,
                        'CD2_2': 7.80788034973e-05,
                        'CRPIX2': 745.0,
                        'CRVAL2': 1.54470013629,
                        'NAXIS2': 1489})
    deconfigged_helper.load(hdu1, format='Image', data_label='has_wcs')

    ldr = deconfigged_helper.loaders['astroquery']
    ldr.viewer = list(deconfigged_helper.viewers.keys())[0]
    ldr.telescope = 'SDSS'
    ldr.max_results = 10
    ldr.query_archive()
    assert 'Catalog' in ldr.format.choices
    ldr.format = 'Catalog'
    ldr.load()


@pytest.mark.remote_data
@pytest.mark.parametrize("telescope", ["JWST", "HST"])
def test_astroquery_jwst_hst(deconfigged_helper, telescope):
    ldr = deconfigged_helper.loaders['astroquery']
    ldr.source = 'M4'
    ldr.telescope = telescope
    ldr.max_results = 10
    ldr.query_archive()

    assert ldr._obj.parsed_input_is_query is True
    assert ldr.treat_table_as_query is True

    # note: querying coverage covered by test_resolver_table_as_query_astroquery

    ldr.treat_table_as_query = False
    assert 'Catalog' in ldr.format.choices
    ldr.load()
    assert len(deconfigged_helper._app.data_collection) == 1


def test_invalid(imviz_helper, tmp_path):
    # make sure you can't load an empty table
    empty_table = Table()

    # empty table from object
    ldr = imviz_helper.loaders['object']
    with pytest.raises(ValueError, match="Parsed input is empty or None, cannot resolve."):
        ldr.object = empty_table
    assert 'Catalog' not in ldr.format.choices

    # empty table from file
    fn = os.path.join(tmp_path, "empty_catalog.ecsv")
    empty_table.write(fn)

    ldr = imviz_helper.loaders['file']
    # Since no parsing of the actual file happens with the file parser
    # we don't error out as we did above.
    ldr.filepath = fn
    assert 'Catalog' not in ldr.format.choices

    # while a fits file can be opened with table.read, it should not be
    # validated as a Catalog
    ldr = imviz_helper.loaders['object']
    ldr.object = fits.ImageHDU(np.ones((32, 25)))
    assert 'Image' in ldr.format.choices
    assert 'Catalog' not in ldr.format.choices


def test_scatter_viewer(deconfigged_helper):
    ldr = deconfigged_helper.loaders['object']
    ldr.object = _make_catalog(with_units=True)
    ldr.format = 'Catalog'

    assert 'Scatter' in ldr.importer.viewer.create_new.choices
    ldr.importer.viewer.create_new = 'Scatter'
    ldr.load()

    assert 'Scatter' in deconfigged_helper.viewers
    assert 'Scatter' in deconfigged_helper.new_viewers

    nv = deconfigged_helper.new_viewers['Scatter']
    nv.dataset = ['Catalog']
    nv.viewer_label = 'Added Scatter Viewer'
    nv()

    assert 'Added Scatter Viewer' in deconfigged_helper.viewers


def test_histogram_viewer(deconfigged_helper):
    ldr = deconfigged_helper.loaders['object']
    ldr.object = _make_catalog(with_units=True)
    ldr.format = 'Catalog'
    ldr.importer.col_other = ['flux']

    assert 'Histogram' in ldr.importer.viewer.create_new.choices
    ldr.importer.viewer.create_new = 'Histogram'
    ldr.load()

    assert 'Histogram' in deconfigged_helper.viewers
    assert 'Histogram' in deconfigged_helper.new_viewers

    nv = deconfigged_helper.new_viewers['Histogram']
    nv.dataset = ['Catalog']
    nv.xatt = 'flux'
    nv.viewer_label = 'Added Histogram Viewer'
    nv()

    assert 'Added Histogram Viewer' in deconfigged_helper.viewers

    po = deconfigged_helper.plugins['Plot Options']
    po.viewer = 'Added Histogram Viewer'
    po.xatt = 'RA'

    assert str(deconfigged_helper.viewers['Histogram']._obj.glue_viewer.state.x_att) == 'RA'  # noqa


def test_table_viewer(deconfigged_helper):
    ldr = deconfigged_helper.loaders['object']
    ldr.object = _make_catalog(with_units=True)
    ldr.format = 'Catalog'
    ldr.importer.viewer.create_new = 'Table'
    ldr.load()

    assert len(deconfigged_helper.viewers) == 1  # Table viewer created upon load
    tv = deconfigged_helper.viewers['Table']
    assert len(tv._obj.glue_viewer.layers) == 1

    # create another viewer through viewer creator
    vc = deconfigged_helper.new_viewers['Table']
    vc.dataset.select_all()
    nv = vc()

    assert len(deconfigged_helper.viewers) == 2
    assert len(nv._obj.glue_viewer.layers) == 1

    # subset creation tool should always be visible (no longer requires checked rows)
    toolbar = tv._obj.glue_viewer.toolbar
    assert toolbar.tools['jdaviz:table_subset'].is_visible() is True

    # checkboxes should be hidden by default
    assert tv._obj.glue_viewer.widget_table.selection_enabled is False

    # activate the tool to show checkboxes
    toolbar.select_tool('jdaviz:table_subset')
    assert tv._obj.glue_viewer.widget_table.selection_enabled is True

    # check some rows and apply
    tv._obj.glue_viewer.widget_table.checked = [1, 2]
    # apply subset via the custom toolbar tool
    toolbar.tools['jdaviz:table_apply_subset'].activate()
    assert 'Subset 1' in deconfigged_helper.plugins['Subset Tools'].subset.choices

    # after applying, checkboxes should be hidden again
    assert tv._obj.glue_viewer.widget_table.selection_enabled is False


@pytest.mark.parametrize("from_file", [True, False])
def test_load_catalog_from_hdulist(deconfigged_helper, tmp_path, from_file):
    """
    Test loading a catalog from a FITS file HDUList (from opened file in memory,
    and from a fits file) containing a BinTableHDU extension and verify that it
    can be loaded through the catalog importer.
    """

    # create an HDUList with a table extension
    catalog_obj = _make_catalog(with_units=True)
    primary_hdu = fits.PrimaryHDU()
    table_hdu = fits.BinTableHDU(catalog_obj, name='CATALOG')
    hdulist = fits.HDUList([primary_hdu, table_hdu])

    if from_file:
        # Write to file
        fn = os.path.join(tmp_path, "catalog_hdulist.fits")
        hdulist.writeto(fn)

        ldr = deconfigged_helper.loaders['file']
        ldr.filepath = fn
    else:
        ldr = deconfigged_helper.loaders['object']
        ldr.object = hdulist

    # Verify Catalog format is available
    assert 'Catalog' in ldr.format.choices

    ldr.format = 'Catalog'

    # Check that Primary HDU (index 0) is not in the extension choices, it should
    # have been filtered out because it is not a table extension
    extension_labels = ldr.importer.extension.choices
    assert len(extension_labels) == 1
    assert extension_labels[0] == '1: [CATALOG,1]'

    # load catalog
    ldr.load()

    # verify catalog is in the data collection
    dc = deconfigged_helper._app.data_collection
    assert len(dc) == 1
    assert 'Catalog' in dc.labels

    # verify the table contents
    qtab = dc[0].get_object(QTable)
    assert 'RA' in qtab.colnames
    assert 'Dec' in qtab.colnames
    assert len(qtab) == len(catalog_obj)
    assert_quantity_allclose(qtab['RA'], catalog_obj['RA'])
    assert_quantity_allclose(qtab['Dec'], catalog_obj['Dec'])


def test_catalog_visibility(imviz_helper, image_2d_wcs):
    """
    Verify that catalog visibility is toggled on/off correctly
    based on link type and presence of pixel and/or world coordinates
    in loaded catalog.
    """
    data = NDData(np.ones((128, 128)), wcs=image_2d_wcs)
    imviz_helper.load(data)

    # catalog with ra, dec, x, y
    orig_catalog = _make_catalog_xy_radec(with_units=True)
    # catalog with ra, dec only
    table_ra_dec_only = orig_catalog['RA', 'Dec', 'Obj_ID']
    # catalog with x, y only
    table_x_y_only = orig_catalog['X', 'Y', 'Obj_ID']

    imviz_helper.load(table_ra_dec_only,
                      data_label='catalog0')

    # since we're pixel linked and catalog has only world coordinates,
    # visibility should be off by default
    dm = imviz_helper.viewers['imviz-0'].data_menu
    assert dm.data_labels_visible == ['Image[DATA]']

    # and it should not be available as a layer in plot options
    po = imviz_helper.plugins['Plot Options']
    po.viewer = 'imviz-0'
    assert po.layer.choices == ['Image[DATA]']  # catalog layer not an option

    # but if we load the catalog with X, Y, it should be visible
    imviz_helper.load(table_x_y_only,
                      data_label='catalog1')
    assert dm.data_labels_visible == ['catalog1', 'Image[DATA]']

    assert po.layer.choices == ['Image[DATA]', 'catalog1']  # catalog layer is now an option

    # now change to WCS linking
    imviz_helper.plugins['Orientation'].align_by = 'WCS'

    # load catalog with RA, Dec only again. Its default visibility should
    # now be on since we're WCS linked
    imviz_helper.load(table_ra_dec_only,
                      data_label='catalog2')

    # the pixel-only 'catalog1' should now be hidden
    assert dm.data_labels_visible == ['catalog2', 'Image[DATA]']

    # loading a pixel-coordinate-only catalog should now be hidden by default
    # since were WCS linked
    imviz_helper.load(table_x_y_only,
                      data_label='catalog3')
    assert 'catalog3' not in dm.data_labels_visible


def test_hdulist_multiple_table_extensions(deconfigged_helper):
    """
    Test loading a catalog from an HDUList with multiple table extensions,
    each with different column names. Verify that when switching between
    extensions, the column selection dropdowns update correctly.
    """
    # Create two (identical, doesn't matter) tables with different column names
    ra = [9.423, 9.421, 9.415] * u.deg
    dec = [-33.711, -33.716, -33.717] * u.deg
    x = [1.0, 2.0, 3.0]
    y = [4.0, 5.0, 6.0]
    table1 = QTable(data=[ra, dec, x, y],
                    names=['ra1', 'dec1', 'x1', 'y1'])
    table2 = QTable(data=[ra, dec, x, y],
                    names=['ra2', 'dec2', 'x2', 'y2'])

    # create two HDULists that also contain a primary HDU to verify that is
    # filtered out of the extension choices
    primary_hdu = fits.PrimaryHDU()
    image_hdu = fits.ImageHDU(np.ones((32, 25)), name='SCI')
    table_hdu1 = fits.BinTableHDU(table1, name='CATALOG1')
    table_hdu2 = fits.BinTableHDU(table2, name='CATALOG2')
    hdulist = fits.HDUList([primary_hdu, table_hdu1, table_hdu2, image_hdu])

    ldr = deconfigged_helper.loaders['object']
    ldr.object = hdulist

    # This HDUList contains both table and image extensions, so both Catalog and Image
    # formats should be valid. Verify Catalog is listed last when multiple formats exist.
    assert 'Catalog' in ldr.format.choices
    assert len(ldr.format.choices) > 1
    assert ldr.format.choices[-1] == 'Catalog'

    ldr.format = 'Catalog'

    # check that both table extensions are available. Checking this indirectly
    # verifies that the primary and image HDUs were correctly filtered out of
    # the extension choices
    extension_labels = ldr.importer.extension.choices
    assert len(extension_labels) == 2
    assert extension_labels[0] == '1: [CATALOG1,1]'
    assert extension_labels[1] == '2: [CATALOG2,1]'

    # check that first extension is selected by default and that column items
    # include ra1, dec1, x1, y1 and do not include ra2, dec2, x2, y2
    assert ldr.importer.extension.selected == ['1: [CATALOG1,1]']
    col_x_labels = [item['label'] for item in ldr.importer.col_x.items]
    assert 'x1' in col_x_labels
    assert 'x2' not in col_x_labels

    col_y_labels = [item['label'] for item in ldr.importer.col_y.items]
    assert 'y1' in col_y_labels
    assert 'y2' not in col_y_labels

    col_ra_labels = [item['label'] for item in ldr.importer.col_ra.items]
    assert 'ra1' in col_ra_labels
    assert 'ra2' not in col_ra_labels

    col_dec_labels = [item['label'] for item in ldr.importer.col_dec.items]
    assert 'dec1' in col_dec_labels
    assert 'dec2' not in col_dec_labels

    # test selecting no extension to make sure nothing crashes
    ldr.importer.extension.selected = []

    # switch to second extension
    ldr.importer.extension.selected = ['2: [CATALOG2,1]']

    # check that column items now include ra2, dec2, x2, y2
    # but not ra1, dec1, x1, y1
    col_x_labels = [item['label'] for item in ldr.importer.col_x.items]
    assert 'x2' in col_x_labels
    assert 'x1' not in col_x_labels

    col_y_labels = [item['label'] for item in ldr.importer.col_y.items]
    assert 'y2' in col_y_labels
    assert 'y1' not in col_y_labels

    col_ra_labels = [item['label'] for item in ldr.importer.col_ra.items]
    assert 'ra2' in col_ra_labels
    assert 'ra1' not in col_ra_labels

    col_dec_labels = [item['label'] for item in ldr.importer.col_dec.items]
    assert 'dec2' in col_dec_labels
    assert 'dec1' not in col_dec_labels

    # check that a non-selection does not cause an error
    ldr.importer.extension.selected = []


def test_load_catalog_from_fits_multiselect(deconfigged_helper):
    """
    Test loading multiple catalogs from a multi-extension FITS file at once
    using multiselect mode.
    """

    # create two catalogs with the same column names
    # this will be in individual FITS table extensions, and because they
    # have the same column names they can be loaded in multiselect mode
    table1 = _make_catalog_xy_radec()
    table2 = _make_catalog_xy_radec()

    # make columns distinct for second table so we can make sure the tables
    # were combined properly and contain both table1 and table2
    table2['RA'] += 1. * u.deg
    table2['Dec'] += 1. * u.deg
    table2['X'] += 1.
    table2['Y'] += 1.

    # put both tables in a HDUList
    hdul = fits.HDUList([fits.PrimaryHDU(), fits.BinTableHDU(table1),
                        fits.BinTableHDU(table2)])

    ldr = deconfigged_helper.loaders['object']
    ldr.object = hdul
    ldr.format = 'Catalog'

    assert ldr.importer.extension.multiselect is True

    # select all available extensions, which should already be filtered to only
    # include table extensions
    ldr.importer.extension.selected = ldr.importer.extension.choices

    # since these two tables share common column names, we should not see a warning
    # in the UI
    assert ldr.importer._obj.no_common_col_msg == ''

    # check that the logic to find common column names across both tables and
    # populate the column selection dropdowns accordingly works correctly
    assert ldr.importer.col_ra.selected == 'RA'
    assert ldr.importer.col_dec.selected == 'Dec'
    assert ldr.importer.col_x.selected == 'X'
    assert ldr.importer.col_y.selected == 'Y'

    ldr.importer()

    # verify that the table in the data collection contains the combined data
    # from both tables, and that the correct number of rows are present
    dc = deconfigged_helper._app.data_collection
    assert len(dc) == 1
    qtab = dc[0].get_object(QTable)
    assert len(qtab) == len(table1) + len(table2)

    # check that the first part of the table matches table1 and the second part
    # matches table2, which verifies that the tables were combined in the correct order
    assert_quantity_allclose(qtab['RA'][:len(table1)], table1['RA'])
    assert_quantity_allclose(qtab['Dec'][:len(table1)], table1['Dec'])
    assert_quantity_allclose(qtab['X'][:len(table1)], table1['X'])
    assert_quantity_allclose(qtab['Y'][:len(table1)], table1['Y'])
    assert_quantity_allclose(qtab['RA'][len(table1):], table2['RA'])
    assert_quantity_allclose(qtab['Dec'][len(table1):], table2['Dec'])
    assert_quantity_allclose(qtab['X'][len(table1):], table2['X'])
    assert_quantity_allclose(qtab['Y'][len(table1):], table2['Y'])

    # now test attempting to load two tables that don't share any common column names.
    # in this case, there should be a message displayed in the UI indicating this
    # and prompting the user to load tables individually, and the column selection
    # dropdowns should not be populated
    table3 = _make_catalog_xy_radec(colnames=['RA2', 'Dec2', 'X2', 'Y2', 'Obj_ID2', 'flux2'])
    hdul2 = fits.HDUList([fits.PrimaryHDU(), fits.BinTableHDU(table1),
                          fits.BinTableHDU(table3)])

    ldr.object = hdul2
    ldr.format = 'Catalog'

    ldr.importer.extension.selected = ldr.importer.extension.choices

    assert ldr.importer.col_ra.choices == ['---']
    assert ldr.importer.col_dec.choices == ['---']
    assert ldr.importer.col_x.choices == ['---']
    assert ldr.importer.col_y.choices == ['---']

    msg = (
        "The selected extensions have no columns in common. "
        "Please select a single extension to load, or select "
        "multiple extensions that have at least one column "
        "name in common to enable loading in multiselect mode."
    )

    assert ldr.importer._obj.no_common_col_msg == msg
