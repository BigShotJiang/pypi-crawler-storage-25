<template>
  <div style="overflow: hidden; margin-right: 0px">
    <!-- Override mode indicator -->
    <v-btn-toggle
      v-if="tool_override_mode.length > 0"
      style="border-top-left-radius: 24px; border-bottom-left-radius: 24px;"
    >
      <v-btn @click="restore_tools" style="background-color: #007ba1; color: white; border-bottom-right-radius: 0; border-top-right-radius: 0; margin-right: -6px; padding-top: 3px">
        <j-tooltip :tooltipcontent="`exit '${tool_override_mode}' mode and restore original toolbar`" span_style="height: inherit; display: inherit; pointer-events: cursor;">
          <v-icon style="margin-left: 4px;">mdi-close</v-icon>
          <span style="color: white; margin-top: 3px; margin-left: 12px">{{ tool_override_mode }}</span>
        </j-tooltip>
      </v-btn>
    </v-btn-toggle>

    <!-- Custom widgets (e.g., viewer selector) -->
    <span v-if="custom_widget_items.length > 0" style="display: inline-flex; align-items: center; vertical-align: top; height: 42px; background-color: #007ba1; padding: 0 4px; margin-right: -4px;">
      <v-select
        v-for="(widget, idx) in custom_widget_items"
        :key="idx"
        :value="custom_widget_selected[idx]"
        @input="(val) => update_widget_selection(idx, val)"
        :items="widget.items"
        :placeholder="widget.label"
        :multiple="widget.multiselect"
        :chips="widget.multiselect"
        :small-chips="widget.multiselect"
        deletable-chips
        dense
        solo
        flat
        hide-details
        style="min-width: 120px; max-width: 250px;"
        class="custom-toolbar-select"
        item-text="label"
        item-value="value"
      ></v-select>
    </span>

    <v-btn-toggle v-model="active_tool_id" :style="" class="transparent">
        <v-tooltip v-for="[id, {tooltip, img, menu_ind, has_suboptions, primary, visible, disabled_msg}] of Object.entries(tools_data)" v-if="primary && visible" bottom>
            <template v-slot:activator="{ on }">
                <v-btn v-on="on" icon :value="id" :disabled="disabled_msg.length > 0" :style="`min-width: 40px !important; ${tool_override_mode.length > 0 ? 'background-color: #007ba1;' : ''} ${disabled_msg.length > 0 ? 'opacity: 0.5;' : ''}`" @contextmenu="(e) => show_submenu(e, has_suboptions, menu_ind)">
                    <img class="invert-if-dark" :src="img" width="20px" @click.ctrl.stop=""/>
                    <v-icon small v-if="has_suboptions" class="suboptions-carrot invert-if-dark" @click="(e) => show_submenu(e, has_suboptions, menu_ind)" @click.ctrl.stop="">mdi-menu-down</v-icon>
                </v-btn>
            </template>
            <span>{{ disabled_msg.length > 0 ? disabled_msg : tooltip }}{{has_suboptions ? " [click arrow for alt. tools]" : ""}}</span>
        </v-tooltip>
    </v-btn-toggle>
    <v-menu
      v-model="show_suboptions"
      :position-x="suboptions_x"
      :position-y="suboptions_y"
      absolute
      offset-y
      dense
      :close-on-click="close_on_click"
    >
      <v-list>
        <v-tooltip
          v-for="[id, {tooltip, img, menu_ind, has_suboptions, primary, visible}] of Object.entries(tools_data)"
          v-if="menu_ind==suboptions_ind && visible"
          :key="id"
          left
        >
          <template v-slot:activator="{ on, attrs }">
            <v-list-item v-bind="attrs" v-on="on" :input-value="primary" @click="() => select_primary([menu_ind, id])">
              <v-list-item-title><img class='invert-if-dark' :src="img" width="20"/></v-list-item-title>
            </v-list-item>
          </template>
          <span>{{ tooltip }}</span>
        </v-tooltip>
      </v-list>
    </v-menu>
  </div>
</template>

<script>
  export default {
    watch: {
      show_suboptions(value) {
        /* workaround for safari on MacOS, which triggers an extra click when using ctrl-click as right-click. The
         * `close-on-click` can't be prevented with `@click.ctrl.stop` */
        if (value) {
          setTimeout(() => {
            this.close_on_click = true;
          }, 100)
        } else {
          this.close_on_click = false;
        }
      }
    },
    methods: {
      update_widget_selection(idx, val) {
        // Update the selection for a specific widget index
        let newSelected = [...this.custom_widget_selected];
        newSelected[idx] = val;
        this.custom_widget_selected = newSelected;
      },
      show_submenu (e, has_suboptions, menu_ind) {
        // needed to prevent browser context-menu
        e.preventDefault()
        // needed to prevent lab context-menu
        e.stopPropagation()
        if (!has_suboptions) {
          return
        }
        /* find the absolute position of the clicked button and position the overlaying
           submenu directly below.  Note that scrolling while the menu is open will leave
           the menu fixed on the window */
        this.show_suboptions = false
        this.suboptions_ind = menu_ind
        // e.path is not standard and not available in all browsers: https://stackoverflow.com/questions/39245488/event-path-is-undefined-running-in-firefox
        const path = e.path || (e.composedPath && e.composedPath());
        const bb = path.find(element => element.nodeName == 'BUTTON').getBoundingClientRect()
        this.suboptions_x = bb.left
        this.suboptions_y = bb.bottom
        this.$nextTick(() => {
          this.show_suboptions = true
        })
      }
    },
  }
</script>

<style scoped>
.suboptions-carrot {
  transform: rotate(-45deg);
  bottom: 0px;
  right: 6px !important;
  margin-right: -22px;
  /* the parent button will invert everything anyways, so we need to override this to be black first,
     regardless of light or dark theme */
  color: black !important;
}
.suboptions-carrot:hover {
  scale: 1.75;
}
.theme--dark .invert-if-dark {
  filter: invert(1) !important;
}
.custom-toolbar-select {
  background-color: #007ba1 !important;
  border-radius: 4px !important;
}
.custom-toolbar-select.v-text-field.v-text-field--solo .v-input__slot {
  background-color: #007ba1 !important;
}
.custom-toolbar-select >>> .v-input__slot {
  min-height: 32px !important;
  padding: 0 8px !important;
  background-color: #007ba1 !important;
}
.custom-toolbar-select >>> .v-text-field__slot {
  background-color: #007ba1 !important;
}
.custom-toolbar-select >>> .v-select__slot {
  background-color: #007ba1 !important;
}
.custom-toolbar-select >>> .v-input__control {
  min-height: 32px !important;
}
.custom-toolbar-select >>> .v-select__selections {
  min-height: 28px !important;
  padding: 0 !important;
}
.custom-toolbar-select >>> .v-select__selection {
  color: white !important;
  font-size: 12px;
  margin: 2px 4px 2px 0 !important;
}
.custom-toolbar-select >>> .v-chip {
  height: 22px !important;
  margin: 2px !important;
}
.custom-toolbar-select >>> .v-chip .v-chip__content {
  font-size: 11px;
}
.custom-toolbar-select >>> .v-icon {
  color: white !important;
}
.custom-toolbar-select >>> input::placeholder {
  color: rgba(255, 255, 255, 0.7) !important;
}
</style>
