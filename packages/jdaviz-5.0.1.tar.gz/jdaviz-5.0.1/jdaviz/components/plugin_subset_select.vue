<template>
  <div>
  <v-row v-if="items.length > 1 || selected.length===0 || show_if_single_entry || api_hints_enabled">
    <v-select
      v-if="mode=='select' || mode===undefined"
      :menu-props="{ left: true }"
      attach
      :items="items"
      v-model="selected"
      @change="$emit('update:selected', $event)"
      :label="api_hints_enabled && api_hint ? api_hint : (label ? label : 'Subset')"
      :class="api_hints_enabled && api_hint ? 'api-hint' : null"
      :hint="hint ? hint : 'Select subset.'"
      :rules="rules ? rules : []"
      :multiple="multiselect"
      :chips="multiselect && !api_hints_enabled"
      item-text="label"
      item-value="label"
      persistent-hint
    >
      <template v-slot:selection="{ item, index }">
        <div class="single-line" style="width: 100%">
          <span v-if="api_hints_enabled" class="api-hint" :style="index > 0 ? 'display: none' : null">
            {{ multiselect ?
              selected
              :
              '\'' + selected + '\''
            }}
          </span>
          <v-chip v-else-if="multiselect" style="width: calc(100% - 10px)">
            <span>
              <v-icon v-if="item.color" left :color="item.color">
                {{ item.type=='spectral' ? 'mdi-chart-bell-curve' : 'mdi-chart-scatter-plot' }}
              </v-icon>
              {{ item.label }}
            </span>
          </v-chip>
          <span v-else>
            <v-icon v-if="item.color" left :color="item.color">
              {{ item.type=='spectral' ? 'mdi-chart-bell-curve' : 'mdi-chart-scatter-plot' }}
            </v-icon>
            {{ item.label }}
          </span>
        </div>
      </template>
      <template v-slot:append v-if="selected !== 'Create New' && !multiselect">
        <v-icon style="cursor: pointer">mdi-menu-down</v-icon>
        <j-tooltip tooltipcontent="rename" v-if="api_hint_rename">
          <v-icon style="cursor: pointer" @click="modeRename">mdi-pencil</v-icon>
        </j-tooltip>
        <j-tooltip tooltipcontent="delete" v-if="api_hint_remove">
          <v-icon style="cursor: pointer" @click="modeRemove">mdi-delete</v-icon>
        </j-tooltip>
      </template>
      <template v-slot:prepend-item v-if="multiselect">
        <v-list-item
        ripple
        @mousedown.prevent
        @click="() => {if (selected.length < items.length) { $emit('update:selected', items.map((item) => item.label))} else {$emit('update:selected', [])}}"
        >
        <v-list-item-action>
          <v-icon>
            {{ selected.length == items.length ? 'mdi-close-box' : selected.length ? 'mdi-minus-box' : 'mdi-checkbox-blank-outline' }}
          </v-icon>
        </v-list-item-action>
        <v-list-item-content>
          <v-list-item-title>
            {{ selected.length < items.length ? "Select All" : "Clear All" }}
          </v-list-item-title>
        </v-list-item-content>
        </v-list-item>
        <v-divider class="mt-2"></v-divider>
      </template>
      <template slot="item" slot-scope="data">
        <div class="single-line">
          <v-icon v-if="data.item.color" left :color="data.item.color">
            {{ data.item.type=='spectral' ? 'mdi-chart-bell-curve' : 'mdi-chart-scatter-plot' }}
          </v-icon>
          <span>
            {{ data.item.label }}
          </span>
        </div>
      </template>
    </v-select>
    <v-alert
      v-else-if="mode=='remove'"
      type="warning"
      style="width: 100%; padding-top: 16px; padding-bottom: 16px"
    >
      <span v-if="api_hints_enabled && api_hint_remove" class="api-hint">
        {{api_hint_remove}}('{{selected}}')
      </span>
      <span v-else>
        remove '{{selected}}'?
      </span>
      <template v-slot:append>
        <j-tooltip tooltipcontent="cancel">
          <v-icon style="cursor: pointer" @click="changeCancel">mdi-close</v-icon>
        </j-tooltip>
        <j-tooltip :tooltipcontent="'Remove '+selected+' '+label.toLowerCase()">
          <v-icon style="cursor: pointer" @click="changeAccept">mdi-delete</v-icon>
        </j-tooltip>
      </template>
    </v-alert>
    <div v-else-if="['rename'].indexOf(mode) !== -1" class="rename-container">
      <j-rename-text
        :value="selected"
        :edit-hint="'Rename '+label.toLowerCase()"
        :show-pencil="false"
        :auto-edit="true"
        :api-hint-rename="api_hint_rename"
        :show-api-hint="api_hints_enabled"
        :rename-error-message="rename_error_message || ''"
        font-size="16px"
        :small-icons="false"
        @input="(newLabel) => {$emit('update:edit_value', newLabel)}"
        @rename="handleRename"
        @cancel="handleCancel"
      />
    </div>
    <span v-else>
      <v-alert
        type="success"
        style="width: 100%; padding-top: 16px; padding-bottom: 16px"
      >
        Applying changes...
      </v-alert>
    </span>
  </v-row>
  <v-row v-if="has_subregions_warning && has_subregions">
    <span class="v-messages v-messages__message text--secondary" style="color: red !important">
        {{ has_subregions_warning }}
    </span>
  </v-row>
  </div>
</template>

<script>
module.exports = {
  props: ['items', 'selected', 'label', 'has_subregions', 'has_subregions_warning', 'hint', 'rules', 'show_if_single_entry', 'multiselect',
          'api_hint', 'api_hints_enabled', 'api_hint_rename', 'api_hint_remove', 'edit_value', 'mode', 'rename_error_message'
  ],
  methods: {
    handleRename(newLabel) {
      this.$emit('update:edit_value', newLabel);
      this.$emit('update:mode', 'rename:accept');
    },
    handleCancel() {
      this.$emit('update:edit_value', this.selected);
      this.$emit('update:mode', 'select');
    },
    changeCancel() {
      this.$emit('update:edit_value', this.selected);
      this.$emit('update:mode', 'select');
    },
    changeAccept() {
      this.$emit('update:mode', this.mode+':accept')
    },
    modeRename() {
      this.$emit('update:mode', 'rename')
    },
    modeRemove() {
      this.$emit('update:mode', 'remove')
    }
  }
};
</script>

<style scoped>
  .v-select__selections {
    flex-wrap: nowrap !important;
    display: block !important;
    margin-bottom: -32px;
  }
  .single-line {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
  }
  .rename-container {
    width: 100%;
    /* Match v-select padding: 20px top for label, content area, then hint space */
    padding-top: 20px;
    padding-bottom: 22px;
    display: flex;
    align-items: center;
  }
</style>

<style>
  /* Hide caret in v-select internal input to prevent errant cursor display */
  .v-select input {
    caret-color: transparent !important;
  }
</style>

