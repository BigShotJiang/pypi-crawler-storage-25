from collections import OrderedDict
import os
import traitlets

from glue.config import viewer_tool
from glue.core import HubListener
from glue.icons import icon_path
from glue.viewers.common.tool import CheckableTool
from glue_jupyter.common.toolbar_vuetify import BasicJupyterToolbar, read_icon

from jdaviz.core.events import (AddDataMessage, RemoveDataMessage,
                                ViewerAddedMessage, ViewerRemovedMessage,
                                SpectralMarksChangedMessage, CatalogResultsChangedMessage,
                                FootprintMarkVisibilityChangedMessage, RestoreToolbarMessage)

__all__ = ['NestedJupyterToolbar']


class NestedJupyterToolbar(BasicJupyterToolbar, HubListener):
    template_file = (__file__, 'toolbar_nested.vue')

    # defined in BasicJupyterToolbar:
    # active_tool = traitlets.Instance
    # tools_data = traitlets.Dict
    # active_tool_id = traitlets.Any

    # whether to show a popup menu
    show_suboptions = traitlets.Bool(False).tag(sync=True)
    close_on_click = traitlets.Bool(False).tag(sync=True)
    # which submenu to show when show_suboptions is True
    suboptions_ind = traitlets.Int(0).tag(sync=True)
    # absolute positions to display the menu
    suboptions_x = traitlets.Float().tag(sync=True)
    suboptions_y = traitlets.Float().tag(sync=True)
    # string indicating the current tool override mode
    tool_override_mode = traitlets.Unicode("").tag(sync=True)
    # list of custom widget items to display in the toolbar
    # currently only supports dropdowns:
    # (list of dicts with 'label', 'value', 'items', 'multiselect')
    custom_widget_items = traitlets.List([]).tag(sync=True)
    # currently selected values in custom widgets (list of values, one per widget)
    custom_widget_selected = traitlets.List([]).tag(sync=True)

    def __init__(self, viewer, tools_nested, default_tool_priority=[]):
        super().__init__(viewer)
        self.viewer = viewer

        # Store original values for reset functionality
        if isinstance(tools_nested, list):
            self._original_tools_nested = tools_nested.copy()
        else:
            self._original_tools_nested = tools_nested
        self._original_default_tool_priority = default_tool_priority.copy()

        # Build the initial toolbar
        self._build_toolbar(tools_nested, default_tool_priority)

        # toolbars in the main app viewers need to respond to the data-collection, etc,
        # but those in plugins do not
        if hasattr(self.viewer, 'hub'):
            for msg in (AddDataMessage, RemoveDataMessage, ViewerAddedMessage,
                        SpectralMarksChangedMessage, CatalogResultsChangedMessage,
                        FootprintMarkVisibilityChangedMessage):
                self.viewer.hub.subscribe(self, msg,
                                          handler=lambda _: self._update_tool_visibilities())
            # ViewerRemovedMessage needs special handling - both update visibilities
            # and clean up toolbar overrides if this viewer is being removed
            self.viewer.hub.subscribe(self, ViewerRemovedMessage,
                                      handler=self._on_viewer_removed)
            # Subscribe to restore toolbar message with dedicated handler
            self.viewer.hub.subscribe(self, RestoreToolbarMessage,
                                      handler=lambda msg: self.restore_tools(all_viewers=False))

    def _on_viewer_removed(self, msg):
        """Handle viewer removal - clean up toolbar overrides if this viewer is removed."""
        # Always update tool visibilities when any viewer is removed
        self._update_tool_visibilities()

        # If THIS viewer is being removed and has a toolbar override active,
        # restore toolbars in all other viewers before removal
        if (hasattr(self.viewer, 'reference_id') and
                msg.viewer_id == self.viewer.reference_id and
                self.tool_override_mode):
            self.restore_tools(all_viewers=True)

    def override_tools(self, tools_nested, tool_override_mode, default_tool_priority=[],
                       custom_widgets=None, custom_widgets_callback=None, active_tool=None):
        """
        Rebuild the toolbar with passed values.

        Parameters
        ----------
        tools_nested : list
            Nested list of tool configurations for the new toolbar
        tool_override_mode : str
            String indicating the current tool override mode
        default_tool_priority : list, optional
            Priority list for default tool selection
        custom_widgets : list, optional
            List of dicts defining custom widgets to display. Each dict should have:
            - 'label': tooltip/label for the widget
            - 'items': list of dicts with 'label' and 'value' keys
            - 'selected': initial selected value(s)
            - 'multiselect': bool, whether to allow multi-select (default False)
        custom_widgets_callback : callable, optional
            A callback function that returns custom_widgets. If provided, this will be
            called on viewer add/remove to refresh the widget items dynamically.  Currently
            only supports dropdowns.
        active_tool : str, optional
            Tool ID to activate after building the toolbar. If not provided,
            the default tool selection logic will be used.
        """
        # Store the override mode
        self.tool_override_mode = tool_override_mode

        # Store callback for refreshing custom widgets
        self._custom_widgets_callback = custom_widgets_callback

        # Clear current toolbar (this also clears custom widgets)
        self._clear_toolbar()

        # Set custom widgets AFTER clearing
        if custom_widgets is not None:
            self.custom_widget_items = custom_widgets
            self.custom_widget_selected = [w.get('selected', []) for w in custom_widgets]

        # Rebuild toolbar with new configuration
        self._build_toolbar(tools_nested, default_tool_priority)

        # Activate the specified tool if provided
        if active_tool is not None and active_tool in self.tools:
            self.active_tool_id = active_tool

    def _build_toolbar(self, tools_nested, default_tool_priority):
        """
        Build the toolbar with the given configuration.

        Parameters
        ----------
        tools_nested : list
            Nested list of tool configurations
        default_tool_priority : list
            Priority list for default tool selection
        """
        # Store values
        self.default_tool_priority = default_tool_priority
        self._max_menu_ind = len(tools_nested)

        # iterate through the nested list.  The first item in each entry
        # is treated as the default primary tool of that subcategory,
        # with each additional entry available from a dropdown.  For
        # backwards compatibility with BasicJupyterToolbar, single strings
        # will be treated as having no submenu.
        tools_data = OrderedDict()
        for menu_ind, subtools in enumerate(tools_nested):
            if isinstance(subtools, str):
                subtools = [subtools]
            for i, tool_id in enumerate(subtools):
                tool_cls = viewer_tool.members[tool_id]
                tool = tool_cls(self.viewer)
                tools_data = self.add_tool(tools_data,
                                           tool=tool,
                                           menu_ind=menu_ind,
                                           has_suboptions=len(subtools) > 1,
                                           primary=i == 0,
                                           visible=True)
        self.tools_data = tools_data

        # handle logic for tool visibilities (which will also handle setting the primary
        # to something other than the first entry, if necessary)
        # NOTE: this will also call _handle_default_tool
        self._update_tool_visibilities()

    def restore_tools(self, all_viewers=True):
        """
        Restore the toolbar to its original configuration from initialization.
        """
        # Only restore if currently in override mode
        if self.tool_override_mode:
            self.override_tools(self._original_tools_nested,
                                "",
                                self._original_default_tool_priority)
        if all_viewers and hasattr(self.viewer, 'hub'):
            self.viewer.hub.broadcast(RestoreToolbarMessage(sender=self))

    def vue_restore_tools(self, *args):
        """
        Vue method to restore all toolbar instances to their original configuration.
        Emits a RestoreToolbarMessage that all toolbar instances will respond to.
        """
        self.restore_tools()

    def _clear_toolbar(self):
        """
        Clear all current tools from the toolbar.
        """
        # Clear the tools and tools_data dictionaries
        self.tools.clear()
        self.tools_data = {}
        self.active_tool_id = None
        # Clear custom widgets and callback
        self.custom_widget_items = []
        self.custom_widget_selected = []
        self._custom_widgets_callback = None

    def _is_visible(self, tool_id):
        # tools can optionally implement self.is_visible(). If not NotImplementedError
        # the tool will always be visible
        if hasattr(self.tools[tool_id], 'is_visible'):
            return self.tools[tool_id].is_visible()
        return True

    def _disabled_msg(self, tool_id):
        """Get disabled message for a tool. Empty string means enabled."""
        if hasattr(self.tools[tool_id], 'disabled_msg'):
            return self.tools[tool_id].disabled_msg()
        return ''

    def _refresh_custom_widgets(self):
        """Refresh custom widget items from callback, preserving current selections."""
        if self._custom_widgets_callback is None:
            return

        new_widgets = self._custom_widgets_callback()
        if new_widgets is None:
            return

        # Preserve current selections where possible
        for i, widget in enumerate(new_widgets):
            if i < len(self.custom_widget_selected):
                current_selected = self.custom_widget_selected[i]
                new_values = [item['value'] for item in widget.get('items', [])]
                if widget.get('multiselect', False):
                    # Filter to only values that still exist
                    valid_selected = [v for v in current_selected if v in new_values]
                    widget['selected'] = valid_selected if len(valid_selected) else new_values
                else:
                    # Keep current if still valid, otherwise use widget default
                    if current_selected in new_values:
                        widget['selected'] = current_selected

        self.custom_widget_items = new_widgets
        self.custom_widget_selected = [w.get('selected', []) for w in new_widgets]

    def _update_tool_visibilities(self):
        # Refresh custom widgets if callback is provided (e.g., for viewer changes)
        if getattr(self, '_custom_widgets_callback', None) is not None:
            self._refresh_custom_widgets()

        needs_deactivate_active = False
        for menu_ind in range(self._max_menu_ind):
            has_primary = False
            n_visible = 0
            if self.active_tool_id:
                current_primary_active = self.tools_data[self.active_tool_id]['menu_ind'] == menu_ind  # noqa
            else:
                current_primary_active = False
            for tool_id, info in self.tools_data.items():
                if info['menu_ind'] != menu_ind:
                    continue
                visible = self._is_visible(tool_id)
                if visible:
                    n_visible += 1

                if tool_id == self.active_tool_id:
                    # then the primary was already set by which tool is active
                    if visible:
                        # then keep this as primary
                        primary = True
                    else:
                        # then the currently active tool is being removed, so we need to deactivate
                        # the tool and allow the default logic to be triggered
                        primary = False
                        needs_deactivate_active = True
                elif current_primary_active and self._is_visible(self.active_tool_id):
                    # then we are keeping the previous primary
                    primary = False
                else:
                    # then there is no primary already in this submenu, so the first visible
                    # entry will be selected as primary
                    primary = visible and not has_primary

                if primary:
                    has_primary = True

                disabled_msg = self._disabled_msg(tool_id)
                self.tools_data[tool_id] = {**info,
                                            'primary': primary,
                                            'visible': visible,
                                            'disabled_msg': disabled_msg}

            # update has_suboptions for all entries in this menu
            for tool_id, info in self.tools_data.items():
                if info['menu_ind'] != menu_ind:
                    continue
                self.tools_data[tool_id] = {**self.tools_data[tool_id],
                                            'has_suboptions': n_visible > 1}

        # mutation to dictionary needs to be manually sent to update the UI
        self.send_state("tools_data")
        if needs_deactivate_active:
            self.active_tool_id = None
        self._handle_default_tool()

    def _handle_default_tool(self):
        # default to the first item in the default_tool_priority list that is currently
        # already primary
        for tool_id in self.default_tool_priority:
            if tool_id not in self.tools_data:
                continue
            if self.tools_data[tool_id]['primary'] and self.tools_data[tool_id]['visible']:
                self.active_tool_id = tool_id
                break

    @traitlets.observe('active_tool_id')
    def _on_change_v_model(self, event):
        super()._on_change_v_model(event)

        if event['new'] is None and event['old'] not in self.default_tool_priority:
            # then we're unchecking a non-default tool
            self._handle_default_tool()
        elif event['new'] in self.tools and not isinstance(self.tools[event['new']], CheckableTool):
            # then we're clicking on a non-checkable tool and want to default to the previous
            if event['old'] is not None:
                self.active_tool_id = event['old']

    def _select_tool(self, tool_id, menu_ind):
        for search_tool_id, info in self.tools_data.items():
            if info['menu_ind'] == menu_ind and info['primary']:
                prev_id = search_tool_id
                prev_info = info
                break
        else:
            raise ValueError("could not find previous selection")

        if isinstance(self.tools[tool_id], CheckableTool):
            # only switch to primary if its actually checkable, otherwise
            # just activate once
            self.tools_data = {
                **self.tools_data,
                prev_id: {
                    **prev_info,
                    'primary': False
                },
                tool_id: {
                    **self.tools_data[tool_id],
                    'primary': True
                }
            }

        # and finally, set to be the active tool (this triggers _on_change_v_model which in turn
        # triggers BasicJupyterToolbar._on_change_active_tool)
        self.active_tool_id = tool_id

    def select_tool(self, tool_id):
        # find the previous primary tool in the same menu_ind
        menu_ind = self.tools_data[tool_id]['menu_ind']
        self._select_tool(tool_id, menu_ind)

    def add_tool(self, tools_data, tool, menu_ind, has_suboptions=True,
                 primary=False, visible=True):
        # NOTE: this method is essentially copied from glue-jupyter's BasicJupyterToolbar,
        # but we need extra values in the tools_data dictionary.  We could call super(),
        # but then that would create tools_data twice, which would then cause
        # issues/re-rerendering
        self.tools[tool.tool_id] = tool
        if os.path.exists(tool.icon):
            path = tool.icon
        else:
            path = icon_path(tool.icon, icon_format='svg')
        tools_data = {
            **tools_data,
            tool.tool_id: {
                'tooltip': tool.tool_tip,
                'img': read_icon(path, 'svg+xml'),
                'menu_ind': menu_ind,
                'has_suboptions': has_suboptions,
                'primary': primary,
                'visible': visible,
                'disabled': False,
                'disabled_msg': ''
            }
        }
        return tools_data

    def vue_select_primary(self, args):
        """
        Activate the primary tool from a given menu index
        """
        menu_ind, tool_id = args
        self._select_tool(tool_id, menu_ind)
