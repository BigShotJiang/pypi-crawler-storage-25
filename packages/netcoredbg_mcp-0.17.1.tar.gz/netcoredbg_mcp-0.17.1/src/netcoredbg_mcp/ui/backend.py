"""UI automation backend abstraction layer.

Provides a protocol for UI automation backends (FlaUI, pywinauto)
and a factory function that selects the best available backend.
"""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@runtime_checkable
class UIBackend(Protocol):
    """Protocol for UI automation backends."""

    async def connect(self, pid: int) -> None:
        """Connect to a process by PID."""
        ...

    async def disconnect(self) -> None:
        """Disconnect from the current process."""
        ...

    async def find_element(
        self,
        automation_id: str | None = None,
        name: str | None = None,
        control_type: str | None = None,
        root_id: str | None = None,
        xpath: str | None = None,
    ) -> dict[str, Any]:
        """Find a UI element by criteria.

        Args:
            automation_id: AutomationId property.
            name: Element Name property.
            control_type: Control type (e.g. "Button").
            root_id: Optional AutomationId to scope search to a subtree.
            xpath: Optional XPath expression (FlaUI backend only).
        """
        ...

    async def invoke_element(
        self,
        automation_id: str | None = None,
        name: str | None = None,
        control_type: str | None = None,
        root_id: str | None = None,
        xpath: str | None = None,
    ) -> dict[str, Any]:
        """Invoke element via InvokePattern (no mouse), fallback to Click."""
        ...

    async def toggle_element(
        self,
        automation_id: str | None = None,
        name: str | None = None,
        control_type: str | None = None,
        root_id: str | None = None,
        xpath: str | None = None,
    ) -> dict[str, Any]:
        """Toggle CheckBox/ToggleButton via TogglePattern. Returns new state."""
        ...

    async def find_by_xpath(
        self,
        xpath: str,
        root_id: str | None = None,
    ) -> dict[str, Any]:
        """Find element by XPath expression. Returns element info + matchCount."""
        ...

    async def find_all_cascade(
        self,
        name: str | None = None,
        control_type: str | None = None,
        root_id: str | None = None,
        max_results: int = 10,
    ) -> dict[str, Any]:
        """Find all matching elements with ranked scoring for disambiguation."""
        ...

    async def extract_text(
        self,
        automation_id: str | None = None,
        name: str | None = None,
        control_type: str | None = None,
        root_id: str | None = None,
        xpath: str | None = None,
    ) -> dict[str, Any]:
        """Extract text using multi-strategy fallback. Returns text + source."""
        ...

    async def click_at(self, x: int, y: int) -> None:
        """Click at screen coordinates."""
        ...

    async def right_click_at(self, x: int, y: int) -> None:
        """Right-click at screen coordinates."""
        ...

    async def double_click_at(self, x: int, y: int) -> None:
        """Double-click at screen coordinates."""
        ...

    async def drag(
        self,
        from_x: int,
        from_y: int,
        to_x: int,
        to_y: int,
        speed_ms: int = 200,
        hold_modifiers: list[str] | None = None,
    ) -> dict[str, Any]:
        """Drag from one position to another."""
        ...

    async def drag_path(
        self,
        points: list[dict[str, Any]],
        speed_ms: int = 200,
        hold_modifiers: list[str] | None = None,
        cancel_key: str | None = None,
    ) -> dict[str, Any]:
        """Drag through a path of screen points, including optional waypoint holds."""
        ...

    async def send_system_event(self, event: str, mode: str = "toggle") -> dict[str, Any]:
        """Send a supported system event through the active backend."""
        ...

    async def hold_modifiers(self, modifiers: list[str]) -> dict[str, Any]:
        """Hold one or more modifiers until a later release."""
        ...

    async def release_modifiers(self, modifiers: list[str] | str) -> dict[str, Any]:
        """Release specific held modifiers or all held modifiers."""
        ...

    async def get_held_modifiers(self) -> dict[str, Any]:
        """Inspect currently held modifiers."""
        ...

    async def scoped_key_sequence(
        self,
        selector: dict[str, Any],
        modifiers: list[str],
        keys: list[str],
    ) -> dict[str, Any]:
        """Focus a target, hold modifiers across keys, and release them."""
        ...

    async def send_keys(self, keys: str) -> None:
        """Send keyboard input."""
        ...

    async def grid_visible_rows(self, selector: dict[str, Any]) -> dict[str, Any]:
        """Read visible DataGrid rows."""
        ...

    async def grid_selected_rows(
        self,
        selector: dict[str, Any],
        columns: list[str] | None = None,
    ) -> dict[str, Any]:
        """Read selected DataGrid rows."""
        ...

    async def grid_snapshot(
        self,
        selector: dict[str, Any],
        rows: dict[str, Any] | None = None,
        columns: list[str] | None = None,
    ) -> dict[str, Any]:
        """Read visible DataGrid rows with cell text/value evidence."""
        ...

    async def grid_assert_rows(
        self,
        selector: dict[str, Any],
        rows: list[dict[str, Any]],
        columns: list[str] | None = None,
    ) -> dict[str, Any]:
        """Assert visible DataGrid row cell values."""
        ...

    async def grid_select_range(
        self,
        selector: dict[str, Any],
        start_index: int,
        end_index: int,
    ) -> dict[str, Any]:
        """Select a DataGrid row range."""
        ...

    async def grid_assert_range(
        self,
        selector: dict[str, Any],
        start_index: int,
        end_index: int,
    ) -> dict[str, Any]:
        """Assert a DataGrid row range."""
        ...

    async def query_ui(
        self,
        selector: dict[str, Any],
        fields: list[str],
        max_results: int = 20,
    ) -> dict[str, Any]:
        """Read focused field-limited UI evidence."""
        ...

    async def list_invoke_item(
        self,
        selector: dict[str, Any],
        item: dict[str, Any],
        invoke: str = "default",
    ) -> dict[str, Any]:
        """Invoke a list item by name or index."""
        ...

    async def list_toggle_item_child(
        self,
        selector: dict[str, Any],
        item: dict[str, Any],
        child: dict[str, Any],
        target_state: str | None = None,
    ) -> dict[str, Any]:
        """Toggle a child element scoped to a resolved list item."""
        ...

    async def assert_focus(self, selector: dict[str, Any]) -> dict[str, Any]:
        """Assert keyboard focus is on or inside a selector."""
        ...

    async def multi_select(self, container_id: str, indices: list[int]) -> int:
        """Select multiple items in a container. Returns count selected."""
        ...

    async def get_window_tree(self, max_depth: int = 3, max_children: int = 50) -> Any:
        """Get the UI element tree."""
        ...

    async def switch_window(
        self,
        name: str | None = None,
        automation_id: str | None = None,
    ) -> dict:
        """Retarget the backend at a different top-level window of the same process."""
        ...

    @property
    def element_cache(self) -> dict[str, dict]:
        """Cached element rectangles from last tree walk."""
        ...

    @property
    def process_id(self) -> int | None:
        """Currently connected process ID."""
        ...


async def connect_backend(backend: UIBackend, pid: int, *, stealth_mode: bool = False) -> None:
    """Connect a UI backend, passing stealth context only to backends that support it."""
    from .flaui_client import FlaUIBackend

    if isinstance(backend, FlaUIBackend):
        await backend.connect(pid, stealth=stealth_mode)
        return

    await backend.connect(pid)


def find_flaui_bridge() -> str | None:
    """Find or build FlaUIBridge.exe.

    Delegates to setup.bridge module which manages builds in
    ~/.netcoredbg-mcp/bridge/ with mtime-based rebuild detection.

    Search order:
    1. FLAUI_BRIDGE_PATH environment variable (explicit override)
    2. ~/.netcoredbg-mcp/bridge/ (managed build — rebuild if stale)
    3. Auto-build from source if available
    4. System PATH

    Returns:
        Absolute path to FlaUIBridge.exe, or None if not found.
    """
    from ..setup.bridge import find_or_build_bridge

    return find_or_build_bridge()


def create_backend(process_registry: Any = None) -> UIBackend:
    """Create the best available UI automation backend.

    Tries FlaUI first (if bridge binary found), falls back to pywinauto.

    Args:
        process_registry: Optional ProcessRegistry for FlaUI PID tracking.

    Returns:
        UIBackend implementation.
    """
    bridge_path = find_flaui_bridge()

    if bridge_path:
        logger.info("Using FlaUI backend (bridge: %s)", bridge_path)
        from .flaui_client import FlaUIBackend

        return FlaUIBackend(bridge_path, process_registry)

    logger.info("FlaUIBridge.exe not found, using pywinauto backend")
    from .pywinauto_backend import PywinautoBackend

    return PywinautoBackend()
