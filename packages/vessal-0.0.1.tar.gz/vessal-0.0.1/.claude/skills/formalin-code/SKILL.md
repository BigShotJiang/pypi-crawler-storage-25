---
name: formalin-code
description: Formalin DTC Code 阶段。按照 CONTEXT.md 约束实现代码，包含完整标注。当实现功能、写代码、修复 bug 时自动加载。
---

# Formalin Code 阶段

Code 是 DTC 循环的第三步。目标：通过所有测试，遵循 Constraints，包含完整标注。

## 前置条件

CONTEXT.md 已确认，测试已写好且全部失败（Design 和 Test 阶段完成）。

## 流程

### 1. 理解规格

读 CONTEXT.md 和测试文件。明确：
- Constraints 中的硬约束（不可违反）
- Design 中的不变量（修改时保持）
- 测试定义的期望行为

### 2. 实现代码

编写实现，目标通过所有测试且遵循 Constraints。

**标注要求（缺失即编译失败）：**

每个 `.py` 文件：
```python
"""module_name.py — 一句话职责描述。"""
```

每个公开函数：
```python
def function(param: Type) -> ReturnType:
    """一句话描述。

    Args:
        param: 语义说明

    Returns:
        语义说明

    Raises:
        ErrorType: 条件说明
    """
```

每个公开类：
```python
class ClassName:
    """一句话角色描述。

    Attributes:
        attr: 语义说明
    """
```

所有公开函数参数和返回值必须有类型注解。

详细标注规格见 formalin skill 的 [reference/annotation-spec.md](../formalin/reference/annotation-spec.md)。

### 3. 自查

完成实现后，自查以下内容：
- 所有测试通过？
- 所有公开函数有 docstring + 类型注解？
- 所有 `.py` 文件有模块文档字符串？
- 是否违反 Constraints 中的任何条目？
- 是否超出 CONTEXT.md 声明的边界（scope creep）？

### 4. 报告状态

向用户报告：

- **DONE**：测试全过，标注完整，无疑虑
- **DONE_WITH_CONCERNS**：完成但有疑虑（列出具体内容）
- **NEEDS_CONTEXT**：缺少信息（列出需要什么）
- **BLOCKED**：无法完成（列出原因）

NEEDS_CONTEXT 和 BLOCKED 时等待用户提供信息或调整设计。

## 检查点

Code 阶段完成的标志：
- 所有测试通过
- 标注完整（docstring + 类型注解）
- 报告 DONE 或 DONE_WITH_CONCERNS
- 接下来运行 `/formalin-compile` 进入 Compile 阶段
