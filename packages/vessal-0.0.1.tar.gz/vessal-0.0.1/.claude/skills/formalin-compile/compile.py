#!/usr/bin/env python3
"""compile.py — Formalin 编译器：验证组件合规性，生成 README.md。

用法：
    python compile.py [path]           验证并生成 README
    python compile.py [path] --check   仅验证，不生成
"""

from __future__ import annotations

import ast
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path


# ── 数据类型 ──────────────────────────────────────────────


@dataclass
class Violation:
    """单条违规记录。"""

    rule: int
    path: str
    message: str

    def __str__(self) -> str:
        return f"#{self.rule} {self.path}: {self.message}"


@dataclass
class ComponentResult:
    """单个组件的验证结果。"""

    component: Path
    violations: list[Violation] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return len(self.violations) == 0

    def add(self, rule: int, path: str, msg: str) -> None:
        self.violations.append(Violation(rule, path, msg))


# ── 组件发现 ──────────────────────────────────────────────


def discover_components(root: Path) -> list[Path]:
    """递归查找含 CONTEXT.md + __init__.py 的目录。"""
    components = []
    for ctx in root.rglob("CONTEXT.md"):
        if (ctx.parent / "__init__.py").exists():
            components.append(ctx.parent)
    return sorted(components)


# ── CONTEXT.md 解析 ──────────────────────────────────────


def parse_context(ctx_path: Path) -> dict[str, str]:
    """将 CONTEXT.md 解析为区段字典。

    Returns:
        {"identity": str, "constraints": str, "design": str, "status": str}
    """
    text = ctx_path.read_text(encoding="utf-8")
    sections: dict[str, str] = {
        "identity": "",
        "constraints": "",
        "design": "",
        "status": "",
    }

    # 按 ## 标题分割，排除 ### 子标题
    parts = re.split(r"^(## (?!#).+)$", text, flags=re.MULTILINE)

    if parts:
        sections["identity"] = parts[0].strip()

    i = 1
    while i < len(parts) - 1:
        header = parts[i].strip().lower()
        content = parts[i + 1].strip()
        if "constraints" in header:
            sections["constraints"] = content
        elif "design" in header:
            sections["design"] = content
        elif "status" in header:
            sections["status"] = content
        i += 2

    return sections


def parse_constraints(text: str) -> list[str]:
    """从 Constraints 区段提取约束列表。"""
    constraints = []
    for line in text.splitlines():
        m = re.match(r"^\s*(?:\d+\.|[-*])\s+(.+)$", line)
        if m:
            constraints.append(m.group(1).strip())
    return constraints


# ── 验证：CONTEXT.md 结构 (#1-5) ─────────────────────────


def validate_context_structure(
    ctx_path: Path, result: ComponentResult
) -> dict[str, str]:
    """验证 CONTEXT.md 四区段结构，返回解析后的区段。"""
    if not ctx_path.exists():
        result.add(1, "CONTEXT.md", "文件不存在")
        return {}

    sections = parse_context(ctx_path)

    # #1: 身份区段
    if not sections["identity"] or not sections["identity"].startswith("#"):
        result.add(1, "CONTEXT.md", "缺少身份区段（# 标题）")

    # #2-4: 三个主区段
    for num, key, name in [
        (2, "constraints", "Constraints"),
        (3, "design", "Design"),
        (4, "status", "Status"),
    ]:
        if not sections[key]:
            result.add(num, "CONTEXT.md", f"缺少 ## {name} 区段")

    # #5: Status 子区段
    if sections["status"]:
        full_text = ctx_path.read_text(encoding="utf-8")
        for sub in ["### TODO", "### Known Issues", "### Active"]:
            if sub not in full_text:
                result.add(5, "CONTEXT.md", f"Status 缺少 {sub} 子区段")

    return sections


# ── 验证：代码标注 (#6-10) ────────────────────────────────


def _get_public_names(init_path: Path) -> set[str] | None:
    """从 __init__.py 获取公开名称集合。优先 __all__，其次相对导入。"""
    try:
        tree = ast.parse(init_path.read_text(encoding="utf-8"))
    except SyntaxError:
        return None

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    if isinstance(node.value, (ast.List, ast.Tuple)):
                        return {
                            elt.value
                            for elt in node.value.elts
                            if isinstance(elt, ast.Constant)
                            and isinstance(elt.value, str)
                        }

    names: set[str] = set()
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ImportFrom) and node.level > 0:
            for alias in node.names:
                names.add(alias.asname or alias.name)
    return names or None


def _collect_py_files(component: Path) -> list[Path]:
    """收集组件内非测试、非缓存的 .py 文件。"""
    return [
        f
        for f in component.rglob("*.py")
        if "tests" not in f.relative_to(component).parts
        and "__pycache__" not in str(f)
    ]


def validate_annotations(component: Path, result: ComponentResult) -> None:
    """验证代码标注完整性（#6-10）。"""
    py_files = _collect_py_files(component)
    public_names = _get_public_names(component / "__init__.py")

    for py_file in py_files:
        rel = str(py_file.relative_to(component))
        try:
            source = py_file.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except SyntaxError:
            result.add(6, rel, "语法错误，无法解析")
            continue

        # #6: 模块文档字符串
        if not ast.get_docstring(tree):
            result.add(6, rel, "缺少模块文档字符串")

        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                _validate_function(node, rel, public_names, result)
            elif isinstance(node, ast.ClassDef):
                _validate_class(node, rel, public_names, result)


def _validate_function(
    node: ast.FunctionDef,
    rel: str,
    public_names: set[str] | None,
    result: ComponentResult,
) -> None:
    """验证单个函数的标注。"""
    if node.name.startswith("_"):
        return
    if public_names is not None and node.name not in public_names:
        return

    loc = f"{rel}:{node.name}()"

    # #7: docstring
    doc = ast.get_docstring(node)
    if not doc:
        result.add(7, loc, "缺少 docstring")
    else:
        params = [a.arg for a in node.args.args if a.arg not in ("self", "cls")]
        if params and "args:" not in doc.lower():
            result.add(7, loc, "docstring 缺少 Args 区段")

    # #8: 参数类型注解
    for arg in node.args.args:
        if arg.arg in ("self", "cls"):
            continue
        if arg.annotation is None:
            result.add(8, f"{rel}:{node.name}({arg.arg})", "参数缺少类型注解")

    # #9: 返回值类型注解
    if node.returns is None:
        result.add(9, loc, "缺少返回值类型注解")


def _validate_class(
    node: ast.ClassDef,
    rel: str,
    public_names: set[str] | None,
    result: ComponentResult,
) -> None:
    """验证单个类的标注。"""
    if node.name.startswith("_"):
        return
    if public_names is not None and node.name not in public_names:
        return
    if not ast.get_docstring(node):
        result.add(10, f"{rel}:{node.name}", "类缺少 docstring")


# ── 验证：约束合规 (#11) ──────────────────────────────────

_LINE_LIMIT_RE = re.compile(r"单文件不超过\s*(\d+)\s*行")
_NO_IMPORT_RE = re.compile(r"不(?:直接\s*)?import\s+(\S+)")
_NESTING_RE = re.compile(r"嵌套不超过\s*(\d+)\s*层")


def _max_indent_depth(source: str) -> int:
    """计算源码最大缩进深度（4 空格 = 1 层）。"""
    max_depth = 0
    for line in source.splitlines():
        stripped = line.lstrip()
        if not stripped or stripped.startswith("#"):
            continue
        depth = (len(line) - len(stripped)) // 4
        if depth > max_depth:
            max_depth = depth
    return max_depth


def validate_constraints(
    component: Path, constraints: list[str], result: ComponentResult
) -> None:
    """自动验证可机械检查的约束（#11）。"""
    py_files = [f for f in component.rglob("*.py") if "__pycache__" not in str(f)]

    for constraint in constraints:
        m = _LINE_LIMIT_RE.search(constraint)
        if m:
            limit = int(m.group(1))
            for f in py_files:
                lines = len(f.read_text(encoding="utf-8").splitlines())
                if lines > limit:
                    result.add(
                        11,
                        str(f.relative_to(component)),
                        f"超过 {limit} 行（{lines} 行）",
                    )
            continue

        m = _NO_IMPORT_RE.search(constraint)
        if m:
            forbidden = m.group(1)
            for f in py_files:
                _check_forbidden_import(f, component, forbidden, result)
            continue

        m = _NESTING_RE.search(constraint)
        if m:
            limit = int(m.group(1))
            for f in py_files:
                source = f.read_text(encoding="utf-8")
                depth = _max_indent_depth(source)
                if depth > limit:
                    result.add(
                        11,
                        str(f.relative_to(component)),
                        f"嵌套深度 {depth} 超过限制 {limit}",
                    )
            continue


def _check_forbidden_import(
    py_file: Path, component: Path, forbidden: str, result: ComponentResult
) -> None:
    """检查文件中是否存在禁止的 import。"""
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8"))
    except SyntaxError:
        return
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if forbidden in alias.name:
                    result.add(
                        11,
                        f"{py_file.relative_to(component)}:{node.lineno}",
                        f"import 了 {forbidden}",
                    )
        elif isinstance(node, ast.ImportFrom) and node.module and forbidden in node.module:
            result.add(
                11,
                f"{py_file.relative_to(component)}:{node.lineno}",
                f"import 了 {forbidden}",
            )


# ── 验证：一致性 (#12-13) ─────────────────────────────────

_ARROW_REF_RE = re.compile(r"→\s*(\S+)")
_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")


def validate_consistency(
    component: Path,
    sections: dict[str, str],
    project_root: Path,
    result: ComponentResult,
) -> None:
    """验证引用路径和日期格式（#12-13）。"""
    full_text = (component / "CONTEXT.md").read_text(encoding="utf-8")

    # #12: → 路径引用
    for m in _ARROW_REF_RE.finditer(full_text):
        ref = m.group(1).strip("`").rstrip("）)。，,").strip("`")
        # 跳过非路径引用（如 "Hull"、"Cell" 等单词）
        if "/" not in ref and not ref.endswith(".py") and not ref.endswith(".md"):
            continue
        if not (project_root / ref).exists() and not (component / ref).exists():
            result.add(12, "CONTEXT.md", f"引用路径不存在：{ref}")

    # #13: Status 条目有日期
    for line in sections.get("status", "").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line == "无。":
            continue
        if line.startswith("- ") and not _DATE_RE.search(line):
            result.add(13, "CONTEXT.md", f"Status 条目缺少日期：{line[:60]}")


# ── README 生成 ───────────────────────────────────────────

FORMALIN_MARKER = "<!-- Generated by Formalin. Do not edit. Source: CONTEXT.md -->"


def _module_first_line(py_file: Path) -> str:
    """提取模块文档字符串第一行。"""
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8"))
        doc = ast.get_docstring(tree)
        return doc.split("\n")[0] if doc else ""
    except SyntaxError:
        return ""


def _format_signature(node: ast.FunctionDef) -> str:
    """格式化函数签名。"""
    params = []
    for arg in node.args.args:
        if arg.arg in ("self", "cls"):
            continue
        ann = ast.unparse(arg.annotation) if arg.annotation else "..."
        params.append(f"{arg.arg}: {ann}")
    ret = ast.unparse(node.returns) if node.returns else "None"
    return f"{node.name}({', '.join(params)}) -> {ret}"


def _build_public_interface(component: Path) -> str:
    """从代码提取公开接口文档。"""
    public_names = _get_public_names(component / "__init__.py")
    if not public_names:
        return "_未声明公开接口。_\n"

    defs: dict[str, str] = {}
    for py_file in _collect_py_files(component):
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name in public_names:
                    doc = ast.get_docstring(node) or ""
                    first = doc.split("\n")[0] if doc else "_无 docstring。_"
                    defs[node.name] = f"### {_format_signature(node)}\n\n{first}\n"
            elif isinstance(node, ast.ClassDef) and node.name in public_names:
                doc = ast.get_docstring(node) or ""
                first = doc.split("\n")[0] if doc else "_无 docstring。_"
                defs[node.name] = f"### class {node.name}\n\n{first}\n"

    parts = []
    for name in sorted(public_names):
        parts.append(defs.get(name, f"### {name}\n\n_定义未找到。_\n"))
    return "\n".join(parts)


def _build_file_structure(component: Path) -> str:
    """生成文件结构清单。"""
    lines = []
    for entry in sorted(component.iterdir()):
        if entry.name.startswith((".", "__pycache__")):
            continue
        if entry.is_dir():
            ctx = entry / "CONTEXT.md"
            if ctx.exists():
                desc = ""
                for ln in ctx.read_text(encoding="utf-8").splitlines():
                    ln = ln.strip()
                    if ln and not ln.startswith("#"):
                        desc = ln
                        break
                lines.append(f"{entry.name}/  {desc}")
            elif entry.name == "tests":
                lines.append("tests/")
            else:
                lines.append(f"{entry.name}/")
        elif entry.suffix == ".py":
            desc = _module_first_line(entry)
            lines.append(f"{entry.name:<20s} {desc}")
    return "\n".join(lines) if lines else "_空组件。_"


def _build_dependencies(component: Path, project_root: Path) -> str:
    """提取项目内部依赖。"""
    src_dir = project_root / "src"
    imports: set[str] = set()

    for py_file in _collect_py_files(component):
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.add(alias.name)
            elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
                imports.add(node.module)

    internal = {imp for imp in imports if (src_dir / imp.split(".")[0]).exists()}
    if not internal:
        return "_无项目内部依赖。_\n"
    return "\n".join(f"- `{d}`" for d in sorted(internal)) + "\n"


def _build_tests(component: Path, project_root: Path) -> str:
    """扫描 tests/ 目录。"""
    tests_dir = component / "tests"
    if not tests_dir.exists():
        return "_无测试目录。_\n"

    test_files = sorted(tests_dir.glob("test_*.py"))
    if not test_files:
        return "_无测试文件。_\n"

    lines = []
    for f in test_files:
        desc = _module_first_line(f)
        lines.append(f"- `{f.name}` — {desc}" if desc else f"- `{f.name}`")

    rel = component.relative_to(project_root)
    lines.append(f"\n运行：`uv run pytest {rel}/tests/`")
    return "\n".join(lines) + "\n"


def generate_readme(
    component: Path, sections: dict[str, str], project_root: Path
) -> str:
    """从 CONTEXT.md + 代码标注生成 README.md。"""
    parts = [FORMALIN_MARKER, "", sections["identity"], ""]

    if sections["design"]:
        parts.extend(["## Design", "", sections["design"], ""])

    parts.extend(["## Public Interface", "", _build_public_interface(component), ""])
    parts.extend(
        ["## File Structure", "", "```", _build_file_structure(component), "```", ""]
    )
    parts.extend(
        ["## Dependencies", "", _build_dependencies(component, project_root), ""]
    )
    parts.extend(["## Tests", "", _build_tests(component, project_root), ""])

    if sections["status"]:
        parts.extend(["## Status", "", sections["status"], ""])

    return "\n".join(parts)


# ── 主函数 ────────────────────────────────────────────────


def find_project_root(start: Path) -> Path:
    """向上查找含 pyproject.toml 或 .git 的目录。"""
    current = start.resolve()
    while current != current.parent:
        if (current / "pyproject.toml").exists() or (current / ".git").exists():
            return current
        current = current.parent
    return start.resolve()


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Formalin 编译器")
    parser.add_argument("path", nargs="?", help="组件路径或扫描目录")
    parser.add_argument("--check", action="store_true", help="仅验证，不生成 README")
    args = parser.parse_args()

    project_root = find_project_root(Path.cwd())
    scan_path = Path(args.path).resolve() if args.path else project_root / "src"
    if not scan_path.exists():
        scan_path = project_root

    components = discover_components(scan_path)
    if not components:
        print(f"未发现组件（{scan_path} 中无 CONTEXT.md + __init__.py）")
        return 1

    print(f"发现 {len(components)} 个组件\n")

    results: list[ComponentResult] = []
    all_passed = True

    for comp in components:
        result = ComponentResult(comp)
        sections = validate_context_structure(comp / "CONTEXT.md", result)
        if sections:
            validate_annotations(comp, result)
            validate_constraints(comp, parse_constraints(sections.get("constraints", "")), result)
            validate_consistency(comp, sections, project_root, result)
        results.append(result)

        rel = comp.relative_to(project_root)
        if result.passed:
            print(f"[{rel}] PASS")
        else:
            all_passed = False
            print(f"[{rel}] FAIL:")
            for v in result.violations:
                print(f"  - {v}")
        print()

    passed = sum(1 for r in results if r.passed)
    failed = len(results) - passed

    if not all_passed:
        print(f"结果：{passed}/{len(results)} 通过，{failed} 失败")
        print("修复后重新编译。")
        return 1

    if args.check:
        print(f"验证通过：{len(results)} 个组件全部合规。")
        return 0

    generated = 0
    for comp, res in zip(components, results):
        sections = parse_context(comp / "CONTEXT.md")
        readme_path = comp / "README.md"

        if readme_path.exists():
            existing = readme_path.read_text(encoding="utf-8")
            if not existing.startswith(FORMALIN_MARKER):
                print(f"警告：{readme_path.relative_to(project_root)} 非 Formalin 生成，跳过")
                continue

        readme_path.write_text(generate_readme(comp, sections, project_root), encoding="utf-8")
        generated += 1
        print(f"生成：{readme_path.relative_to(project_root)}")

    print(f"\n完成：验证 {len(results)} 个组件，生成 {generated} 个 README。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
