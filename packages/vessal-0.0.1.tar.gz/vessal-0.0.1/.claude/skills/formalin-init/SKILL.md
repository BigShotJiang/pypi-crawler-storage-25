---
name: formalin-init
description: 创建新的 Formalin 组件。生成 CONTEXT.md 骨架、__init__.py 和 tests/ 目录。
disable-model-invocation: true
argument-hint: "<component-path>"
---

# Formalin Init

在指定路径创建新组件的标准目录结构。

## 参数

`$ARGUMENTS` 是组件路径（必需）。示例：`/formalin-init src/vessal/ark/new_module`

## 流程

### 1. 创建目录结构

```
<component-path>/
    CONTEXT.md
    __init__.py
    tests/
```

### 2. 生成 CONTEXT.md 骨架

```markdown
# ComponentName

TODO: 一句话描述。

负责：
- TODO: 职责

不负责：
- TODO: 明确排除

## Constraints

1. 单文件不超过 500 行
2. TODO: 添加组件特定约束

## Design

TODO: 回答以下问题。

1. 为什么这个组件存在，不存在会怎样？
2. 为什么是当前形状，否决了什么替代方案？
3. 组件内部的关键设计决策是什么？
4. 不变量是什么，修改时必须保持什么性质？
5. 与相邻组件的关系是什么？

## Status

### TODO
- [ ] YYYY-MM-DD: 初始实现

### Known Issues
无。

### Active
- YYYY-MM-DD: 初始创建
```

将 `ComponentName` 替换为路径的最后一段（如 `new_module`）。将 `YYYY-MM-DD` 替换为当前日期。

### 3. 生成 __init__.py

```python
"""component_name — TODO: 一句话职责描述。"""
```

### 4. 提示用户

创建完成后提示：

```
组件骨架已创建：<component-path>/
请填写 CONTEXT.md 的 TODO 项（Design 阶段）。
填写完成后用 /formalin-test 进入 Test 阶段。
```
