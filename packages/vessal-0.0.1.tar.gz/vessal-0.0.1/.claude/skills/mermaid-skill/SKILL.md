---
name: mermaid-skill
description: 描述完整的 Mermaid 图使用规则，在任何文档与白皮书中，只要能使用 Mermaid，就必须使用丰富的各种形式的 Mermaid 图来表示你的想法
---

# Mermaid 图表强制使用规则

## 强制指令

**这是不可商量的规则：**

在任何文档、白皮书、技术分析、架构设计、流程说明中，凡是有以下情形之一，**必须**用 Mermaid 图表达，不得用纯文字代替：

- 描述流程、步骤、顺序 → `flowchart` 或 `sequenceDiagram`
- 描述状态变化、生命周期 → `stateDiagram-v2`
- 描述系统架构、模块关系 → `flowchart`、`architecture-beta` 或 `C4Context`
- 描述时间计划、里程碑 → `gantt` 或 `timeline`
- 描述类/接口/数据结构 → `classDiagram` 或 `erDiagram`
- 描述比例、分布 → `pie`
- 描述多维评估、竞品对比 → `quadrantChart` 或 `radar-beta`
- 描述流量流向、资金流动 → `sankey-beta`
- 描述层级概念、知识结构 → `mindmap`
- 描述版本历史、分支策略 → `gitGraph`
- 描述工作状态、任务管理 → `kanban`

**错误示范**（禁止）：
> "系统分三层：前端层负责展示，业务层处理逻辑，数据层存储数据，三层之间通过接口调用..."

**正确做法**（必须）：

```mermaid
flowchart TD
    F["前端层"] -->|"接口调用"| B["业务层"]
    B -->|"接口调用"| D["数据层"]
```

## 图表选型决策

```mermaid
flowchart TD
    Q[要表达什么] --> A{有时间维度?}
    A -->|有任务进度| G[gantt]
    A -->|只有事件| T[timeline]
    A -->|代码提交历史| GG[gitGraph]

    A -->|否| B{有交互消息传递?}
    B -->|是| S[sequenceDiagram]

    B -->|否| C{表达结构关系?}
    C -->|系统服务架构| AR[architecture-beta 或 flowchart]
    C -->|类接口设计| CL[classDiagram]
    C -->|数据库表结构| ER[erDiagram]
    C -->|大型系统上下文| C4[C4Context]
    C -->|层级概念| MM[mindmap]

    C -->|否| D{表达数量比例?}
    D -->|占比分布| PI[pie]
    D -->|流量流向| SK[sankey-beta]
    D -->|二维定位| QD[quadrantChart]
    D -->|多维对比| RD[radar-beta]
    D -->|趋势折线柱状| XY[xychart-beta]
    D -->|层级占比| TM[treemap-beta]

    D -->|否| E{表达状态流程?}
    E -->|状态机| ST[stateDiagram-v2]
    E -->|决策流程| FL[flowchart]
    E -->|用户体验路径| JR[journey]
    E -->|任务管理| KB[kanban]
```

---

## 一、Mermaid 简介

Mermaid 是一个基于 JavaScript 的开源图表绘制工具，允许用户通过类似 Markdown 的纯文本语法定义和生成各种类型的图表。"图表即代码"（Diagrams as Code）的核心理念让所有图表定义保存在纯文本中，易于 Git 追踪和版本管理。目前已被 GitHub、GitLab、Notion、Obsidian、Typora、VS Code 等平台原生支持。

**基本语法格式**：

````markdown
```mermaid
关键字
  图表定义内容...
```
````

**方向控制**（适用于流程图等有向图）：
- `TB` / `TD` — 从上到下（Top to Bottom）
- `BT` — 从下到上（Bottom to Top）
- `LR` — 从左到右（Left to Right）
- `RL` — 从右到左（Right to Left）


## 二、流程图（Flowchart）

**关键字**：`flowchart` 或 `graph`（新版推荐使用 `flowchart`）

**用途**：展示业务流程、决策树、算法流程、系统架构等。

**核心语法**：
- 节点定义：`id[文本]`、`id{文本}`（菱形）、`id(文本)`（圆角矩形）、`id([文本])`（体育场形）、`id[[文本]]`（子程序形）、`id[(文本)]`（圆柱形）、`id((文本))`（圆形）、`id>文本]`（不对称形）
- 连接线：`-->`（实线箭头）、`---`（实线无箭头）、`-.->`（虚线箭头）、`==>`（粗线箭头）
- 连线标签：`-->|标签文本|B`
- 子图：`subgraph 标题 ... end`
- 样式：`classDef 样式名 样式属性` 和 `class 节点ID 样式名`
- 方向控制：`flowchart LR`（左到右）、`flowchart TD`（上到下）等

**示例**：

```mermaid
flowchart TD
    A[开始] --> B{是否有效?}
    B -->|是| C[处理数据]
    B -->|否| D[返回错误]
    C --> E([结束])
    D --> E
```


## 三、时序图（Sequence Diagram）

**关键字**：`sequenceDiagram`

**用途**：展示对象间的消息交互顺序，如 API 调用流程、用户交互时序、协议交互等。

**核心语法**：
- 参与者：`participant 名称` 或 `actor 名称`
- 消息箭头：
  - `->>` — 实线箭头
  - `-->>` — 虚线箭头
  - `-x` — 带 X 的箭头（异步消息）
  - `-)` — 异步箭头
- 激活/停用：`activate 对象` / `deactivate 对象`
- 注释：`Note right of 对象: 文本`、`Note over 对象1,对象2: 文本`
- 循环：`loop 循环条件 ... end`
- 条件分支：`alt 条件1 ... else 条件2 ... end`、`opt 条件 ... end`
- 并行：`par ... and ... and ... end`

**示例**：

```mermaid
sequenceDiagram
    participant 用户
    participant 前端
    participant 后端

    用户->>前端: 输入账号密码
    前端->>后端: POST /login
    activate 后端
    后端-->>前端: 返回 token
    deactivate 后端
    前端-->>用户: 登录成功
```


## 四、类图（Class Diagram）

**关键字**：`classDiagram`

**用途**：展示面向对象设计中类与接口的结构和关系，如软件架构设计、数据模型等。

**核心语法**：
- 类定义：`class 类名 { ... }` 或 `类名 : 属性/方法`
- 可见性符号：`+` 公有、`-` 私有、`#` 保护、`~` 包内
- 接口：`<<interface>>`、抽象类：`<<abstract>>`、泛型：`类名~T~`
- 关系类型：
  - `<|--` — 继承（泛化）
  - `*--` — 组合（强拥有）
  - `o--` — 聚合（弱拥有）
  - `-->` — 关联
  - `..>` — 依赖
  - `..|>` — 实现
- 基数标记：`"1"`、`"0..1"`、`"1..*"`、`"*"`

**示例**：

```mermaid
classDiagram
    Animal <|-- Dog : 继承
    Animal <|-- Cat : 继承
    Dog o-- Tail : 聚合
    Cat *-- Paw : 组合

    class Animal {
        +String name
        +int age
        +eat()
        +sleep()
    }

    class Dog {
        +bark()
    }

    class Cat {
        +meow()
    }
```


## 五、状态图（State Diagram）

**关键字**：`stateDiagram-v2`（推荐使用 v2 版本，`stateDiagram` 为旧版）

**用途**：展示对象状态的变化过程，如状态机建模、生命周期管理等。

**核心语法**：
- 状态定义：`state "状态名" as 别名`
- 初始状态：`[*]`，终止状态：`[*]`
- 状态转换：`状态A --> 状态B : 事件/动作`
- 复合状态：`state 复合状态名 { ... }`
- 选择分支：`state 选择名 <<choice>>`
- 分叉/汇合：`state 分叉名 <<fork>>`、`<<join>>`
- 并发：`--` 分隔符
- 注释：`note right of 状态 : 注释内容`

**示例**：

```mermaid
stateDiagram-v2
    [*] --> 待支付
    待支付 --> 已支付 : 支付成功
    待支付 --> 已取消 : 超时/取消
    已支付 --> 已发货 : 发货
    已发货 --> 已完成 : 确认收货
    已完成 --> [*]
    已取消 --> [*]
```


## 六、实体关系图（ER Diagram）

**关键字**：`erDiagram`

**用途**：数据库实体关系建模，展示表结构和外键关系。

**核心语法**：
- 实体定义：`实体名 { 属性名 类型 约束 }`
- 属性类型：`string`、`int`、`float`、`date`、`bool`、`datetime` 等
- 约束：`PK`（主键）、`FK`（外键）、`UK`（唯一键）
- 关系连接：`实体1 关系标记 实体2 : "标签"`
- 关系类型标记：
  - `||--||` — 一对一（强制-强制）
  - `||--o{` — 一对多（强制-可选）
  - `}o--||` — 多对一（可选-强制）
  - `}|--|{` — 多对多（强制-强制）

**示例**：

```mermaid
erDiagram
    USER {
        int id PK
        string name
        string email UK
        datetime created_at
    }

    ORDER {
        int id PK
        int user_id FK
        float total
        string status
    }

    USER ||--o{ ORDER : places
```


## 七、用户旅程图（User Journey）

**关键字**：`journey`

**用途**：用户与系统的交互流程分析，UX 体验映射。

**核心语法**：
- 标题：`title 标题名称`
- 阶段定义：`section 阶段名称`
- 任务：`任务名称 : 重要性分值 : 执行者`（重要性分值 1-5，数值越大显示越突出）

**示例**：

```mermaid
journey
    title 用户购物旅程
    section 浏览商品
        搜索商品 : 5 : 用户
        查看详情 : 4 : 用户
    section 下单购买
        加入购物车 : 5 : 用户
        填写地址 : 3 : 用户
        完成支付 : 5 : 用户, 支付系统
    section 收货评价
        确认收货 : 4 : 用户
        发表评价 : 3 : 用户
```


## 八、甘特图（Gantt Chart）

**关键字**：`gantt`

**用途**：项目管理和时间线规划，任务调度可视化。

**核心语法**：
- 标题：`title 标题`
- 日期格式：`dateFormat YYYY-MM-DD`
- 坐标轴格式：`axisFormat %m/%d`
- 排除日期：`excludes weekends`、`excludes 2024-01-01`
- 分区：`section 分区名`
- 任务定义：`任务名 : 状态, 任务ID, 开始日期/依赖, 持续时间`
- 状态标记：`done`（已完成）、`active`（进行中）、`crit`（关键任务）、`milestone`（里程碑，持续时间 0d）
- 依赖关系：`after 任务ID`
- 持续时间单位：`d`（天）、`w`（周）、`h`（小时）

**示例**：

```mermaid
gantt
    title 项目开发计划
    dateFormat YYYY-MM-DD
    axisFormat %m月%d日
    excludes weekends

    section 需求分析
    需求调研 : done, a1, 2024-01-01, 5d
    需求评审 : active, a2, after a1, 2d

    section 开发阶段
    前端开发 : crit, a3, after a2, 10d
    后端开发 : crit, a4, after a2, 10d
    联调测试 : a5, after a3 a4, 5d

    section 里程碑
    v1.0发布 : milestone, after a5, 0d
```


## 九、饼图（Pie Chart）

**关键字**：`pie`

**用途**：展示数据比例分布，占比分析。

**核心语法**：
- `showData` — 可选，放在 `pie` 后显示原始数值
- 标题：`title 标题名称`
- 数据：`"标签名" : 数值`

**示例**：

```mermaid
pie showData
    title 月度支出分布
    "住房" : 2500
    "食品" : 1200
    "交通" : 800
    "娱乐" : 500
    "其他" : 300
```


## 十、需求图（Requirement Diagram）

**关键字**：`requirementDiagram`

**用途**：系统需求分解与追踪，需求可追溯性分析。

**核心语法**：
- 需求定义：`requirement 需求ID { 属性 }`
- 功能需求：`functionalRequirement 需求ID { 属性 }`
- 接口需求：`interfaceRequirement 需求ID { 属性 }`
- 属性字段：`id`（用数字，避免连字符）、`text`（不加引号的纯文本，**中文不可靠，建议用英文**）、`risk`（High/Medium/Low）、`verifyMethod`（Test/Inspection/Analysis/Demonstration）
- 关系语法：`A - {type} -> B`（箭头格式，无需标签）
- 关系类型：`contains`、`copies`、`derives`、`satisfies`、`verifies`、`refines`、`traces`

**示例**：

```mermaid
requirementDiagram
    requirement req_login {
        id: 1
        text: User shall login with username and password
        risk: High
        verifyMethod: Test
    }

    functionalRequirement req_encrypt {
        id: 2
        text: Password must be stored with encryption
        risk: Medium
        verifyMethod: Inspection
    }

    req_login - contains -> req_encrypt
```


## 十一、Git 分支图（Git Graph）

**关键字**：`gitGraph`

**用途**：版本控制分支可视化，Git 工作流展示。

**核心语法**：
- 方向控制：`gitGraph LR`（左到右）或默认上到下
- 提交：`commit`、`commit id: "自定义ID"`、`commit type: HIGHLIGHT`
- 分支：`branch 分支名`
- 切换分支：`checkout 分支名`
- 合并：`merge 分支名`
- 标签：`commit tag: "标签名"`
- 提交类型：`NORMAL`（默认）、`REVERSE`（回滚）、`HIGHLIGHT`（高亮）

**示例**：

```mermaid
gitGraph
    commit
    commit
    branch develop
    checkout develop
    commit
    commit
    checkout main
    commit
    checkout develop
    commit
    checkout main
    merge develop
    commit tag: "v1.0"
```


## 十二、思维导图（Mindmap）

**关键字**：`mindmap`

**用途**：知识整理、创意发散、层级概念可视化。

**核心语法**：
- 层级结构通过缩进定义（空格或 Tab）
- 节点形状：
  - `(文本)` — 圆角矩形
  - `[文本]` — 方形
  - `((文本))` — 圆形
  - `))文本((` — 云形
  - `{{文本}}` — 六边形
- 图标：`::icon(图标类名)`
- 样式类：`:::样式类名`

**示例**：

```mermaid
mindmap
    root((项目管理))
        需求分析
            [用户调研]
            [竞品分析]
            (需求文档)
        开发阶段
            [前端开发]
            [后端开发]
            [测试]
        上线运维
            ))部署((
            [监控]
            [迭代优化]
```


## 十三、时间线图（Timeline）

**关键字**：`timeline`

**用途**：历史事件展示、项目里程碑、时间轴可视化。

**核心语法**：
- 标题：`title 标题名称`
- 时间段/事件：`时间段名称 : 事件1 : 事件2 : 事件3`
- 一个时间段可以跟多个事件，用冒号分隔

**示例**：

```mermaid
timeline
    title 公司发展历程
    2020 : 公司成立 : 获得天使轮融资
    2021 : 发布 v1.0 产品 : 用户数突破 10 万
    2022 : 完成 A 轮融资 : 团队扩张至 50 人
    2023 : 发布 v2.0 产品 : 开拓海外市场
    2024 : 用户数突破 100 万 : 获得行业大奖
```


## 十四、象限图（Quadrant Chart）

**关键字**：`quadrantChart`

**用途**：四象限分析（优先级矩阵、战略定位、二维分类）。

**核心语法**：
- 标题：`title 标题名称`
- X 轴定义：`x-axis "起点标签" --> "终点标签"`（中文标签必须加引号）
- Y 轴定义：`y-axis "起点标签" --> "终点标签"`（中文标签必须加引号）
- 象限标签：`quadrant-1 标签`（右上，逆时针编号）、`quadrant-2`（左上）、`quadrant-3`（左下）、`quadrant-4`（右下）
- 数据点：`"数据点名称" : [x坐标, y坐标]`（坐标值范围 0-1）

**示例**：

```mermaid
quadrantChart
    title 产品功能优先级分析
    x-axis "低价值" --> "高价值"
    y-axis "低成本" --> "高成本"
    quadrant-1 "优先开发"
    quadrant-2 "优化提升"
    quadrant-3 "暂缓考虑"
    quadrant-4 "重新评估"
    "登录功能" : [0.8, 0.3]
    "支付系统" : [0.9, 0.7]
    "消息推送" : [0.4, 0.2]
    "数据分析" : [0.6, 0.8]
```


## 十五、XY 图表（XY Chart）

**关键字**：`xychart-beta`

**用途**：二维数值数据可视化，包括柱状图和折线图。

**核心语法**：
- 标题：`title 标题名称`
- X 轴（分类）：`x-axis [类别1, 类别2, ...]`
- X 轴（数值范围）：`x-axis "标签" 最小值 --> 最大值`
- Y 轴定义：`y-axis "标签" 最小值 --> 最大值`
- 数据系列：
  - 柱状图：`bar [数值1, 数值2, ...]`
  - 折线图：`line [数值1, 数值2, ...]`

**示例**：

```mermaid
xychart-beta
    title "季度销售数据"
    x-axis [Q1, Q2, Q3, Q4]
    y-axis "销售额(万元)" 0 --> 100
    bar [35, 45, 55, 70]
    line [30, 50, 60, 80]
```


## 十六、架构图（Architecture Diagram）

**关键字**：`architecture-beta`

**用途**：展示云服务/CI/CD 部署架构，服务与资源之间的关系。

**核心语法**：
- 分组：`group 组ID[组标签]` 或 `group 组ID(图标)[组标签]`
- 服务：`service 服务ID(图标)[服务标签]`
- 服务归属：`service 服务ID(图标)[服务标签] in 组ID`
- 连接：`服务1:方向 --> 方向:服务2`（方向：L/R/T/B；**注意目标侧是 `方向:ID`，不是 `ID:方向`**）
- 常用图标：`cloud`、`database`、`disk`、`internet`、`server`
- **注意**：`(icon)` 位置只能填 ASCII 图标名，中文标签放 `[label]` 里

**示例**：

```mermaid
architecture-beta
    group api[API Gateway]
    service web(server)[Web] in api
    service auth(server)[Auth] in api

    group data[Data Layer]
    service db(database)[DB] in data
    service cache(disk)[Cache] in data

    web:R --> L:auth
    auth:R --> L:db
    auth:B --> T:cache
```


## 十七、看板图（Kanban Diagram）

**关键字**：`kanban`

**用途**：任务看板管理，工作流可视化，展示任务在不同阶段的流动情况。

**核心语法**：
- 列定义：`列ID[列标题]`
- 任务定义（缩进放置于对应列下）：`任务ID[任务描述]`
- 元数据（使用 `@{ ... }` 语法添加）：
  - `assigned` — 负责人
  - `ticket` — 工单号
  - `priority` — 优先级（Very High、High、Low、Very Low）

**示例**：

```mermaid
kanban
    todo[待办]
        task1[设计登录页面]
        task2[编写 API 文档]@{ assigned: '张三', priority: 'High' }

    progress[进行中]
        task3[开发用户模块]@{ assigned: '李四', ticket: 'PROJ-101' }
        task4[修复首页 Bug]@{ assigned: '王五', priority: 'Very High' }

    review[待审核]
        task5[代码审查 - 支付模块]@{ assigned: '赵六' }

    done[已完成]
        task6[项目初始化]
        task7[数据库设计]
```


## 十八、雷达图（Radar Chart）

**关键字**：`radar-beta`（v11.6.0+）

**用途**：多维数据对比，如性能评分、能力评估、竞品分析等。

**核心语法**：
- 标题：`title "标题名称"`（注意：无冒号，直接跟引号字符串）
- 轴定义：`axis 轴ID["轴标签"], 轴ID2["轴标签2"], ...`
- 曲线定义：`curve 曲线ID["曲线标签"]{值1, 值2, 值3, ...}`（值顺序与轴定义顺序对应）
- 选项：
  - `max 最大值` — 设定最大值
  - `min 最小值` — 设定最小值
  - `showLegend` — 显示图例
  - `graticule polygon` — 网格线类型（polygon 或 circle）
  - `ticks 数量` — 刻度数量
- **注意**：轴 ID（`axis` 后的第一个词）必须是 ASCII 标识符，中文显示名放在 `["..."]` 里

**示例**：

```mermaid
radar-beta
    title "产品性能对比"
    axis spd["处理速度"], stb["系统稳定性"], ue["易用性"]
    axis sec["安全性"], ext["扩展性"]

    curve a["产品 A"]{85, 75, 90, 70, 80}
    curve b["产品 B"]{70, 90, 65, 85, 75}
    curve c["竞品"]{80, 70, 60, 65, 90}

    max 100
    min 0
    graticule polygon
```


## 十九、桑基图（Sankey Diagram）

**关键字**：`sankey-beta`

**用途**：展示流量、能量、资金等从源到目标的流动关系和数量。

**核心语法**：
- 数据格式：`源节点,目标节点,流量值`（每行一条，CSV 格式）
- **节点名必须是纯 ASCII**，不支持中文（无论是否加引号）；含空格的 ASCII 名称用引号包裹
- 显示数值需通过全局初始化配置：`%%{init: {'sankey': {'showValues': true}}}%%`

**示例**：

```mermaid
sankey-beta
    Visit,Homepage,1000
    Homepage,Products,600
    Homepage,Search,200
    Homepage,Other,200
    Products,Detail,400
    Products,Exit,200
    Detail,Cart,250
    Cart,Checkout,200
    Cart,Browse,50
    Checkout,Paid,180
    Checkout,Failed,20
```


## 二十、矩形树图（Treemap Diagram）

**关键字**：`treemap-beta`

**用途**：展示层级数据的比例关系，以嵌套矩形表示数据层次结构。

**核心语法**：
- 层级关系通过缩进定义
- **父节点**（有子节点）：`"节点名称"`（无数值）
- **叶子节点**（无子节点）：`"叶子名称": 数值`（有数值）
- 父节点不能同时携带数值和子节点——有数值则为叶子，有子节点则不写数值

**示例**：

```mermaid
treemap-beta
    "项目预算"
        "研发"
            "前端开发": 80000
            "后端开发": 120000
            "测试": 50000
        "市场"
            "线上推广": 100000
            "线下活动": 50000
        "运营"
            "服务器": 60000
            "人员": 40000
```


## 二十一、数据包图（Packet Diagram）

**关键字**：`packet-beta`

**用途**：展示网络数据包结构、二进制协议格式等。

**核心语法**：
- 标题：`title "标题名称"`
- 字段定义：`起始位-结束位: "字段名称"`（位范围从 0 开始，闭区间）
- 每行定义一个字段，按位顺序从上到下排列
- 位范围必须连续，不得有空隙

**示例**：

```mermaid
packet-beta
    title "IPv4 数据包头"
    0-3: "Version"
    4-7: "IHL"
    8-13: "DSCP"
    14-15: "ECN"
    16-31: "Total Length"
    32-47: "Identification"
    48-50: "Flags"
    51-63: "Fragment Offset"
    64-71: "TTL"
    72-79: "Protocol"
    80-95: "Header Checksum"
    96-127: "Source Address"
    128-159: "Destination Address"
```


## 二十二、块图（Block Diagram）

**关键字**：`block-beta`

**用途**：模块化系统设计图，网络架构，分层系统可视化。

**核心语法**：
- 列数定义：`columns 数量`
- 块形状：
  - `["文本"]` — 方形
  - `("文本")` — 圆角矩形
  - `(("文本"))` — 圆形
  - `{文本}` — 菱形
- 连接：`块1 --> 块2`
- 空间占位：`space`
- 嵌套块：`block:块名 ... end`
- 样式：`style 块ID fill:#颜色,stroke:#颜色`

**示例**：

```mermaid
block-beta
    columns 1
    A["用户界面"]
    B["业务逻辑层"]
    C["数据访问层"]
    D["数据库"]

    A --> B
    B --> C
    C --> D
```


## 二十三、C4 架构图（C4 Diagram）

**关键字**：`C4Context`、`C4Container`、`C4Component`、`C4Dynamic`、`C4Deployment`

**用途**：软件系统架构建模，支持 C4 模型的四个层次（上下文、容器、组件、代码）以及动态图和部署图。

**核心语法**（`C4Context`）：
- `Person(别名, 标签, 描述)` — 人员
- `Person_Ext(别名, 标签, 描述)` — 外部人员
- `System(别名, 标签, 描述)` — 系统
- `System_Ext(别名, 标签, 描述)` — 外部系统
- `SystemDb_Ext(别名, 标签, 描述)` — 外部数据库系统
- `Boundary(别名, 标签) { ... }` — 边界框
- `Rel(源, 目标, 标签)` — 关系
- `BiRel(源, 目标, 标签)` — 双向关系

> **注意**：C4 图表是实验性功能，语法和属性可能在未来的版本中发生变化。

**示例**：

```mermaid
C4Context
    title 网上银行系统上下文图

    Person(customer, "银行客户", "使用网上银行的个人用户")
    System(banking_system, "网上银行系统", "允许客户查看账户信息并进行交易")
    System_Ext(email_system, "邮件系统", "发送通知邮件")
    SystemDb_Ext(core_banking, "核心银行系统", "存储账户、交易等核心数据")

    Rel(customer, banking_system, "使用")
    Rel(banking_system, core_banking, "读写数据")
    Rel(banking_system, email_system, "发送邮件")
    BiRel(customer, email_system, "接收通知")
```


## 二十四、ZenUML（插件）

**关键字**：`zenuml`

**用途**：使用 ZenUML 替代语法创建时序图（通过外部插件支持）。

> **注意**：ZenUML 是外部插件，需要单独安装和配置，不在 Mermaid 标准内置中。

**示例**：

```zenuml
title 用户登录流程
User->Frontend: 输入凭证
Frontend->AuthService: POST /login
try {
  AuthService->Database: 验证用户
  Database-->AuthService: 返回用户信息
  AuthService-->Frontend: 返回 Token
} catch {
  AuthService-->Frontend: 返回错误
}
Frontend-->User: 显示结果
```


---

## 图表类型速查表

| 类别 | 图表类型 | 关键字 | 主要用途 |
|------|----------|--------|----------|
| **流程与逻辑** | 流程图 | `flowchart` | 业务流程、决策树、系统架构 |
| | 状态图 | `stateDiagram-v2` | 状态机、生命周期建模 |
| **交互** | 时序图 | `sequenceDiagram` | 消息交互、API 调用 |
| | 用户旅程图 | `journey` | UX 体验映射 |
| **时间规划** | 甘特图 | `gantt` | 项目调度、时间线 |
| | 时间线 | `timeline` | 历史事件、里程碑 |
| | Git 分支图 | `gitGraph` | 版本控制分支可视化 |
| | 看板图 | `kanban` | 任务管理、工作流 |
| **结构** | 类图 | `classDiagram` | 面向对象设计 |
| | ER 图 | `erDiagram` | 数据库架构 |
| | 架构图 | `architecture-beta` | 云/服务架构 |
| | C4 图 | `C4Context` 等 | 系统上下文建模 |
| | 块图 | `block-beta` | 模块化系统设计 |
| | 数据包图 | `packet-beta` | 网络包/协议结构 |
| **数据可视化** | 饼图 | `pie` | 比例数据 |
| | XY 图表 | `xychart-beta` | 柱状图、折线图 |
| | 象限图 | `quadrantChart` | 二维分类、优先级矩阵 |
| | 桑基图 | `sankey-beta` | 流量/能量流向 |
| | 雷达图 | `radar-beta` | 多维数据对比 |
| | 矩形树图 | `treemap-beta` | 层级比例数据 |
| **概念** | 思维导图 | `mindmap` | 层级概念组织 |
| | 需求图 | `requirementDiagram` | 需求追踪 |

> **关于实验性功能**：带 `-beta` 标记的图表类型处于实验阶段，语法可能在后续版本中调整。在生产文档中优先使用稳定版图表类型。
