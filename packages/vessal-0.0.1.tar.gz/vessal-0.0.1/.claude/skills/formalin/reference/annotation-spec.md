# 代码标注完整规格

标注是编译的数据源。公开接口的标注由编译过程强制检查，缺失即编译失败。

## 模块文档字符串

每个 `.py` 文件的第一个语句为文档字符串：

```python
"""hull_api.py — Hull 对 skill 暴露的 API 接口层。"""
```

格式：`文件名 + 一句话职责`。一行。编译过程从此提取文件结构说明。

## 函数文档字符串

每个公开函数（不以 `_` 开头且在 `__all__` 中或由 `__init__.py` 导出）必须有 docstring：

```python
def register_route(self, method: str, path: str, handler: RouteHandler) -> None:
    """注册 HTTP 路由到 Hull 路由表。

    Args:
        method: HTTP 方法（"GET" 或 "POST"）
        path: 路由路径，相对于组件根
        handler: 请求处理函数，签名 (body: dict) -> tuple[int, dict]

    Raises:
        ValueError: path 已被注册
    """
```

必需字段：
- 第一行：一句话描述
- Args：每个参数一行，名称加语义说明
- Returns：返回值说明（非 None 时必需）
- Raises：可能抛出的异常及条件（有异常时必需）

可选字段：Side Effects、Note。

私有函数（`_` 前缀）不强制 docstring，鼓励。

## 类型注解

所有公开函数的参数和返回值必须有类型注解：

```python
# 正确
def wake(self, reason: str = "skill") -> None: ...

# 编译失败：缺少类型注解
def wake(self, reason="skill"): ...
```

使用 `from __future__ import annotations` 支持延迟求值。私有函数不强制。

## 类文档字符串

每个公开类必须有 docstring：

```python
class ScopedHullApi:
    """skill 专用的 HullApi wrapper，自动为路由加 /skills/{name} 前缀。

    Attributes:
        _prefix: 路由前缀字符串
    """
```

第一行角色描述。Attributes 列出关键属性。
