---
name: formalin
description: AI 时代的软件工程范式。合约驱动的 DTC 工作流，防止项目腐化。当修改代码、创建组件、讨论架构或组件设计时自动加载。
---

# Formalin

合约驱动的 DTC（Design → Test → Code）工作流。合约（CONTEXT.md）是权威，代码是合约的实现产物。

## 核心原则

1. **合约先于实现。** CONTEXT.md 是权威。修改设计时先改合约再改代码。
2. **生成优于手写。** 凡可从代码或合约推导的信息，由工具生成。README.md 是编译产物，禁止手写。
3. **编译强制合规。** 缺失标注、违反约束、结构不完整，编译失败。
4. **人指挥 AI 执行。** 人写合约、审阅产出。AI 读合约、写实现、报告状态。
5. **渐进披露。** 自顶向下导航，每层 CONTEXT.md 足以判断是否深入。

## 组件协议

组件是含 `CONTEXT.md` + `__init__.py` 的目录。缺一不可。

```
component/
    CONTEXT.md          合约（手写，必需）
    __init__.py         公开接口（必需）
    *.py                实现文件
    tests/              单元测试（共置，不放项目级 tests/）
        test_*.py       测试文件
    README.md           编译产物（/formalin-compile 生成）
```

**单元测试与组件共置。** 集成测试和端到端测试放项目级 `tests/`。

## CONTEXT.md 格式

四个区段，顺序固定。详细规格见 [reference/context-spec.md](reference/context-spec.md)。

```markdown
# ComponentName

一句话描述。

负责：
- ...

不负责：
- ...

## Constraints

1. 机械可验证的硬规则

## Design

散文形式。回答：为什么存在、为什么是这个形状、否决了什么、不变量是什么。
使用 Mermaid 图（graph, sequenceDiagram, stateDiagram-v2, flowchart 等）辅助解释组件关系、数据流、状态变化和关键决策。图内联在被解释的段落旁，按内容复杂度自适应，不设数量限制。

## Status

### TODO
- [ ] YYYY-MM-DD: 事项

### Known Issues
- YYYY-MM-DD: 问题

### Active
无。
```

## 代码标注要求

所有公开接口必须有完整标注，缺失即编译失败。详细规格见 [reference/annotation-spec.md](reference/annotation-spec.md)。

- 每个 `.py` 文件：模块文档字符串（一行，文件名 + 职责）
- 每个公开函数：docstring（描述 + Args + Returns + Raises）+ 类型注解
- 每个公开类：docstring（角色描述 + Attributes）

## DTC 工作流

每个功能变更、bug 修复、重构走完整 DTC 循环：

### Phase 1: Design（人类主导）

更新 CONTEXT.md。新组件用 `/formalin-init` 创建骨架。
详细指导：`/formalin-design`

### Phase 2: Test（AI 起草，人类审阅）

从 CONTEXT.md 的 Constraints 和 Design 推导测试，放在组件 `tests/` 目录。
详细指导：`/formalin-test`

### Phase 3: Code（AI 实现，人类审阅）

通过所有测试，遵循 Constraints，包含完整标注。
详细指导：`/formalin-code`

### Phase 4: Compile（验证 + 生成）

验证合约完整性、标注完整性、约束合规性，生成 README.md。
操作：`/formalin-compile`

### Phase 5: Review（人类或 review agent）

两阶段：先合约合规性，再代码质量。
详细指导：`/formalin-review`

## 渐进披露协议

导航项目时，自顶向下逐层读 CONTEXT.md：

```
项目 CONTEXT.md → 子系统 CONTEXT.md → 组件 CONTEXT.md
  → __init__.py → 文件 docstring → 函数 docstring → 函数体
```

每层只获取路由决策所需的信息。无关则跳过，不读下一层。代码是最后才读的东西。

## 行为规则

**修改代码前：** 检查组件目录是否有 CONTEXT.md。有则先读，遵循 Constraints。

**创建新组件时：** 先创建 CONTEXT.md（Design phase），再写任何代码。

**写代码时：** 所有公开函数必须有 docstring 和类型注解。

**完成变更后：** 自查是否符合 CONTEXT.md 的 Constraints。报告状态（DONE / DONE_WITH_CONCERNS / NEEDS_CONTEXT / BLOCKED）。

**探索阶段例外：** 问题不清楚时可跳出 DTC 做原型，但原型在独立分支，正式实现回到 DTC。

## 可用操作

- `/formalin-init <path>` — 创建新组件（CONTEXT.md 骨架 + 目录结构）
- `/formalin-compile` — 验证全部组件 + 生成 README.md
- `/formalin-design` — Design 阶段详细指导
- `/formalin-test` — Test 阶段详细指导
- `/formalin-code` — Code 阶段详细指导
- `/formalin-review` — Review 阶段详细指导
