---
name: formalin-design
description: Formalin DTC Design 阶段。创建或更新 CONTEXT.md，定义组件的边界、约束和设计意图。当讨论新功能设计、组件规划、架构决策时自动加载。
---

# Formalin Design 阶段

Design 是 DTC 循环的第一步。产出是更新的 CONTEXT.md。此阶段结束时不应有实现代码。

## 流程

### 1. 确定变更范围

分析用户的需求，确定涉及哪些组件。如果需要新组件，用 `/formalin-init` 创建骨架。

### 2. 更新 CONTEXT.md

**新组件：** 填写全部四个区段。

身份区段要回答：这是什么、做什么、不做什么。"不负责"比"负责"更重要。

Constraints 要写可机械验证的规则。"保持代码整洁"不是约束。"单文件不超过 500 行"是约束。

Design 要回答五个问题：
1. 为什么存在，不存在会怎样
2. 为什么是这个形状，否决了什么替代方案
3. 内部关键决策
4. 不变量（修改时必须保持的性质）
5. 与相邻组件的关系

Status 标记当前活跃工作。

**现有组件：** 只更新受影响的区段。如果变更不影响边界和约束，可能只需更新 Status。如果变更影响设计，必须更新 Design。

### 3. 跨组件变更

如果变更涉及多个组件的协作关系，先更新白皮书或 spec 文档，再更新各组件 CONTEXT.md。CONTEXT.md 中跨组件推导用 `→ 路径` 引用，不重复。

### 4. 人类审阅

将 CONTEXT.md 变更展示给用户确认。确认后进入 Test 阶段（`/formalin-test`）。

## 检查点

Design 阶段完成的标志：
- CONTEXT.md 准确反映即将实现的变更
- 用户确认设计意图
- 此时无实现代码

## CONTEXT.md 格式参考

详细格式见 formalin skill 的 [reference/context-spec.md](../formalin/reference/context-spec.md)。
