# Tasks

层级任务树管理 Skill。树形结构 + 自动焦点 + 极简 API。

负责：
- 树形任务增删改查（add/done/remove/list）
- 层级编号 ID 自动分配（"1"、"1.1"、"1.1.1"）
- 当前任务自动选取（第一个未完成叶子节点）
- 唤醒时预填引导任务
- 每帧渲染任务树 + 当前任务（_signal）
- 注入认知协议（_prompt，只写方法论不写方法名）

不负责：
- 任务持久化
- 依赖关系（blocked_by，后续版本）
- 任务分配与调度

## Constraints

1. 有效状态只有两种：active、done
2. add() 必须 print 反馈
3. done() 必须 print 反馈，包括下一个当前任务
4. remove() 必须级联删除所有子任务
5. _prompt() 不允许包含方法签名
6. 当前任务由系统自动选取，agent 不手动设置
7. 唤醒时任务列表为空自动预填引导任务
8. ID 排序必须用数值排序（"1.10" > "1.2"），禁止字典序排序
9. add()/done()/remove() 必须同步 ns["_current_task_id"]（供 event_loop._should_compress 读取）。_signal() 只读取，不写 namespace。

## Design

### Map 哲学

Agent 的任务树是它的 map，也是它的 life。Agent 的任何行动必须沿着 map 进行——没有 map 就不行动。Map 可以随时修改，但必须始终存在。

### 理论框架

四个理论支撑 Tasks 的设计：

**GTD（Getting Things Done）**——project/next-action 分离。根任务 = project（多步 outcome），子任务 = next action（最小可执行步骤）。Tasks 强制 agent 先建 project 再分解。

**HTN（Hierarchical Task Network）**——abstract→primitive 惰性分解。agent 不需要一次规划完所有子任务，可以边做边发现。

**Kanban WIP=1**——任何时刻最多一个 in-progress 任务。Claude Code、Codex 都用这个硬约束。

**DFS/LIFO**——深度优先执行。当前任务永远是最深的未完成叶子。完成后自动回到下一个。

```mermaid
flowchart TD
    Start["收到工作请求"] --> Add["add(目标) 创建根任务"]
    Add --> Split{"目标可直接执行?"}
    Split -->|"太大"| AddChild["add(子目标, parent=id)"]
    AddChild --> Split
    Split -->|"可以"| Execute["执行代码"]
    Execute --> Done["done() 标记完成"]
    Done --> More{"还有未完成任务?"}
    More -->|"有"| Execute
    More -->|"没有"| Sleep["sleep()"]
```

### 层级编号

ID 格式 "1.2.3"——第 1 个 project 的第 2 个子任务的第 3 个子任务。ID 本身编码层级关系，复制粘贴到任何地方都能看出结构。不需要树连接符或特殊排版。

### 自动焦点

当前任务 = 按编号排序，第一个 status != "done" 的叶子节点。agent 不需要手动管理焦点。做完 done()，系统自动切到下一个。

## Status

### TODO
无。

### Known Issues
无。

### Active
- 2026-04-13: tasks API 重设计——从 6 方法 footgun 砍到 4 方法极简 API
