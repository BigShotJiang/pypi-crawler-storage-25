/**
 * render.js — 帧区段渲染纯函数集合。
 *
 * 每个 render* 函数：输入帧数据子结构 → 输出 HTML 字符串。
 * 无副作用、无 DOM 操作、无状态。
 *
 * 数据路径参考（FrameRecord schema v6）：
 *   ping.system_prompt         → renderSystemPrompt
 *   ping.state.frame_stream    → renderFrameStream
 *   ping.state.signals         → renderSignals
 *   pong.think                 → renderThink
 *   pong.action.operation      → renderOperation
 *   pong.action.expect         → renderExpect
 *   observation.stdout         → renderStdout
 *   observation.diff           → renderDiff
 *   observation.error          → renderError
 *   observation.verdict        → renderVerdict
 */

// ── 工具函数 ──

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function diffColorize(diff) {
  return diff.split('\n').map(line => {
    if (line.startsWith('+')) return `<span class="diff-plus">${escHtml(line)}</span>`;
    if (line.startsWith('-')) return `<span class="diff-minus">${escHtml(line)}</span>`;
    return escHtml(line);
  }).join('\n');
}

/**
 * 单个区段的 HTML 包装。支持 <details> 局部折叠。
 * @param {string} key - 区段标识（用于 CSS class 和 toggle 匹配）
 * @param {string} label - 显示标题
 * @param {string} bodyHtml - 内容 HTML
 * @param {boolean} collapsed - 默认折叠
 * @param {string} [extraClass] - 额外 CSS class
 * @param {boolean} raw - true 时 bodyHtml 直接输出（不包 <pre>），用于 verdict 等结构化内容
 */
function section(key, label, bodyHtml, collapsed = false, extraClass = '', raw = false) {
  const cls = `frame-section ${extraClass}`.trim();
  const inner = raw ? `<div class="section-body">${bodyHtml}</div>`
                     : `<div class="section-body"><pre class="code-block">${bodyHtml}</pre></div>`;
  if (collapsed) {
    return `<details class="${cls}" data-section="${key}">
      <summary class="section-label">${label}</summary>
      ${inner}
    </details>`;
  }
  return `<div class="${cls}" data-section="${key}">
    <div class="section-label">${label}</div>
    ${inner}
  </div>`;
}

// ── 10 个区段渲染函数 ──

// Ping 层
function renderSystemPrompt(ping) {
  const text = (ping && ping.system_prompt) || '';
  if (!text.trim()) return '';
  return section('system_prompt', '系统提示词', escHtml(text), true);
}

function renderFrameStream(ping) {
  const state = (ping && ping.state) || {};
  const text = state.frame_stream || '';
  if (!text.trim()) return '';
  return section('frame_stream', '帧流', escHtml(text), false);
}

function renderSignals(ping) {
  const state = (ping && ping.state) || {};
  const text = state.signals || '';
  if (!text.trim()) return '';
  return section('signals', '信号', escHtml(text), true);
}

// Pong 层
function renderThink(pong) {
  const text = (pong && pong.think) || '';
  if (!text.trim()) return '';
  return section('think', 'Think', escHtml(text), true, 'think');
}

function renderOperation(pong) {
  const action = (pong && pong.action) || {};
  const text = action.operation || '';
  if (!text.trim()) return '';
  return section('operation', 'Operation', escHtml(text));
}

function renderExpect(pong) {
  const action = (pong && pong.action) || {};
  const text = action.expect || '';
  if (!text.trim()) return '';
  return section('expect', 'Expect', escHtml(text));
}

// Observation 层
function renderStdout(obs) {
  const text = (obs && obs.stdout) || '';
  if (!text.trim()) return '';
  return section('stdout', 'Stdout', escHtml(text));
}

function renderDiff(obs) {
  const text = (obs && obs.diff) || '';
  if (!text.trim()) return '';
  return section('diff', 'Diff', diffColorize(text));
}

function renderError(obs) {
  const text = (obs && obs.error) || null;
  if (!text) return '';
  return section('error', 'Error', escHtml(text), false, 'error');
}

function renderVerdict(obs) {
  const v = obs && obs.verdict;
  if (!v) return '';
  const isPass = v.passed === v.total;
  let html = `<div class="verdict-bar ${isPass ? 'pass' : 'fail'}">
    ${isPass ? '✓' : '✗'} 断言 ${v.passed}/${v.total} 通过
  </div>`;
  if (v.failures && v.failures.length > 0) {
    html += '<div class="verdict-failures">';
    for (const f of v.failures) {
      html += `<div class="verdict-failure-item">
        <div class="assertion">${escHtml(f.assertion || '')}</div>
        <div class="message">${escHtml(f.message || '')}</div>
      </div>`;
    }
    html += '</div>';
  }
  return section('verdict', 'Verdict', html, false, '', true);
}

// ── 帧级渲染 ──

/**
 * 渲染单帧全部区段。
 * @param {object} frame - FrameRecord schema v6
 * @param {Set<string>} visible - 可见区段 key 集合
 * @returns {string} HTML
 */
function renderFrame(frame, visible) {
  const ping = frame.ping || {};
  const pong = frame.pong || {};
  const obs = frame.observation || {};
  const hasError = obs.error != null;
  const num = frame.number || '?';

  const renderers = [
    ['system_prompt', () => renderSystemPrompt(ping)],
    ['frame_stream', () => renderFrameStream(ping)],
    ['signals',      () => renderSignals(ping)],
    ['think',        () => renderThink(pong)],
    ['operation',    () => renderOperation(pong)],
    ['expect',       () => renderExpect(pong)],
    ['stdout',       () => renderStdout(obs)],
    ['diff',         () => renderDiff(obs)],
    ['error',        () => renderError(obs)],
    ['verdict',      () => renderVerdict(obs)],
  ];

  let body = '';
  for (const [key, fn] of renderers) {
    if (visible.has(key)) body += fn();
  }

  return `<div class="frame-card${hasError ? ' has-error' : ''}">
    <div class="frame-card-header">
      <span>帧 #${num}</span>
    </div>
    <div class="frame-card-body">${body || '<span class="empty">（空帧）</span>'}</div>
  </div>`;
}
