/**
 * app.js — 应用逻辑：轮询、toggle 状态、聊天收发。
 *
 * 依赖：render.js（renderFrame 函数）
 * 数据源：/frames（帧数据）、/status（agent 状态）、/skills/chat/*（聊天）
 */

const SKILL_API = window.location.origin + '/skills/chat';
const SYSTEM_API = window.location.origin;

// ── 区段定义 ──

const SECTIONS = [
  { key: 'system_prompt', label: '系统提示词', defaultOn: false },
  { key: 'frame_stream',  label: '帧流',       defaultOn: true },
  { key: 'signals',       label: '信号',       defaultOn: false },
  { key: 'think',         label: 'Think',      defaultOn: true },
  { key: 'operation',     label: 'Operation',  defaultOn: true },
  { key: 'expect',        label: 'Expect',     defaultOn: true },
  { key: 'stdout',        label: 'Stdout',     defaultOn: true },
  { key: 'diff',          label: 'Diff',       defaultOn: true },
  { key: 'error',         label: 'Error',      defaultOn: true },
  { key: 'verdict',       label: 'Verdict',    defaultOn: true },
];

const STORAGE_KEY = 'vessal_visible_sections';

// ── Toggle 状态管理 ──

function loadVisibleSections() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return new Set(JSON.parse(stored));
  } catch {}
  return new Set(SECTIONS.filter(s => s.defaultOn).map(s => s.key));
}

function saveVisibleSections(visible) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify([...visible]));
}

let visibleSections = loadVisibleSections();

function initToggleBar() {
  const bar = document.getElementById('toggleBar');
  for (const s of SECTIONS) {
    const label = document.createElement('label');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = visibleSections.has(s.key);
    cb.addEventListener('change', () => {
      if (cb.checked) visibleSections.add(s.key);
      else visibleSections.delete(s.key);
      saveVisibleSections(visibleSections);
      rerenderAllFrames();
    });
    label.appendChild(cb);
    label.appendChild(document.createTextNode(s.label));
    bar.appendChild(label);
  }
}

// ── 帧轮询 + 渲染 ──

let frames = [];
let lastFrameNumber = 0;
let isTailing = true;
const frameList = document.getElementById('frameList');

async function pollFrames() {
  try {
    const resp = await fetch(`${SYSTEM_API}/frames?after=${lastFrameNumber}`);
    const data = await resp.json();
    const newFrames = data.frames || [];
    for (const f of newFrames) {
      frames.push(f);
      if ((f.number || 0) > lastFrameNumber) lastFrameNumber = f.number;
      appendFrameCard(f);
    }
    if (newFrames.length > 0 && isTailing) {
      frameList.scrollTop = frameList.scrollHeight;
    }
    document.getElementById('frameStats').textContent = `${frames.length} 帧`;
  } catch {}
}

function appendFrameCard(frame) {
  const div = document.createElement('div');
  div.innerHTML = renderFrame(frame, visibleSections);
  const card = div.firstElementChild;
  if (card) frameList.appendChild(card);
}

function rerenderAllFrames() {
  frameList.innerHTML = '';
  for (const f of frames) appendFrameCard(f);
  if (isTailing) frameList.scrollTop = frameList.scrollHeight;
}

// 检测用户手动滚动——离底部 > 100px 时取消 tailing
frameList.addEventListener('scroll', () => {
  const atBottom = frameList.scrollHeight - frameList.scrollTop - frameList.clientHeight < 100;
  isTailing = atBottom;
});

// ── Agent 状态轮询 ──

const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');

async function pollStatus() {
  try {
    const resp = await fetch(`${SYSTEM_API}/status`);
    const data = await resp.json();
    if (data.sleeping) {
      statusDot.style.background = '#ffc107';
      statusText.textContent = '休眠中';
    } else {
      statusDot.style.background = '#4caf50';
      statusText.textContent = `工作中 (帧 ${data.frame || 0})`;
    }
  } catch {
    statusDot.style.background = '#f44336';
    statusText.textContent = '离线';
  }
}

// ── 聊天 ──

const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
let lastOutboxTs = 0;

sendBtn.addEventListener('click', sendMessage);
chatInput.addEventListener('keydown', e => { if (e.key === 'Enter') sendMessage(); });

function sendMessage() {
  const text = chatInput.value.trim();
  if (!text) return;
  chatInput.value = '';
  appendChat('user', text);
  fetch(`${SKILL_API}/inbox`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content: text }),
  }).catch(err => appendChat('agent', `[发送失败: ${err.message}]`));
}

function appendChat(role, content) {
  const div = document.createElement('div');
  div.className = `msg ${role}`;
  div.textContent = content;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

async function loadHistory() {
  try {
    const resp = await fetch(`${SKILL_API}/history`);
    const data = await resp.json();
    for (const msg of (data.messages || [])) {
      appendChat(msg.role || 'agent', msg.content || '');
      if ((msg.ts || 0) > lastOutboxTs) lastOutboxTs = msg.ts;
    }
  } catch {}
}

async function pollOutbox() {
  try {
    const resp = await fetch(`${SKILL_API}/outbox?after=${lastOutboxTs}`);
    const data = await resp.json();
    for (const msg of (data.messages || [])) {
      appendChat('agent', msg.content || '');
      if (msg.ts > lastOutboxTs) lastOutboxTs = msg.ts;
    }
  } catch {}
}

// ── 初始化 ──

initToggleBar();
loadHistory().then(() => setInterval(pollOutbox, 2000));
pollFrames();
setInterval(pollFrames, 1500);
pollStatus();
setInterval(pollStatus, 2000);
