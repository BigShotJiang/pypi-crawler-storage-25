# Chat

双向人机异步通信 Skill。维护 inbox/outbox 消息队列，持久化对话历史到 JSONL 文件，每帧向 Agent 报告未读消息状态。

负责：
- 接收来自 server.py 的人类消息（receive()）
- 提供 Agent 读取对话历史的接口（read(n=5)）
- 提供 Agent 向人类发送消息并可选阻塞等待回复的接口（reply(content, wait=0)）
- 提供 Shell 取走回复的接口（drain_outbox()）
- 对话历史 append-only 持久化到 data/chat.jsonl

不负责：
- HTTP 传输（由 server.py 伴生服务器处理）
- Agent 调度与唤醒（由 Hull 负责）
- 对话历史压缩或摘要（由 Cell 负责）

## Constraints

1. inbox 是瞬态队列，不从 JSONL 恢复（重启后 unread_count 归零）
2. chat.jsonl 只追加写入，永不覆盖
3. read() 或 reply() 调用后 _inbox 被清除，unread_count 归零——回复即确认
4. receive() 和 reply() 必须同步写入 chat.jsonl，不能异步延迟落盘
5. 单文件不超过 500 行
6. reply(wait=N) 只返回 read() 之后新到达的消息，不返回旧消息

## Design

Chat skill 存在的理由是将异步通信与 Agent 执行解耦。人类发消息的时机不可预测，而 Agent 以帧为单位运行。inbox/outbox 队列是缓冲层，允许人类随时发消息而不阻塞 Agent。

形状选择上，skill 是纯内存队列加文件持久化的组合，没有自己的 HTTP 服务器。HTTP 入口由伴生 server.py 提供：Hull 托管模式通过 `start(hull_api, skill)` 注册路由，_handle_inbox 直接调用 `skill.receive()` 投递消息并唤醒 Agent，绕过文件 IPC。

API 设计：两个公开方法。`read(n=5)` 返回最近 n 条对话（user + agent），清空 inbox 和 unread_count，供 Agent 在处理消息前阅读上下文。`reply(content, wait=0)` 发送一条 agent 消息，wait=0 不等待，wait=N 在 N 秒内轮询 inbox 等待人类回复并返回内容（超时返回 None）。

```mermaid
sequenceDiagram
    participant Human as 人类用户
    participant Server as server.py (HTTP)
    participant Skill as chat skill
    participant Agent

    Human->>Server: POST /skills/chat/message {content}
    Server->>Skill: skill.receive(content)
    Skill->>Skill: 追加到 _inbox + 写入 chat.jsonl
    Server->>Agent: hull_api.wake("user_message")

    Note over Agent: 下一帧被唤醒
    Agent->>Skill: chat.read(n=5)
    Skill-->>Agent: 最近 n 条历史 + _inbox.clear()

    Agent->>Skill: chat.reply("回复内容", wait=0)
    Skill->>Skill: 写入 chat.jsonl + 加入 _outbox

    alt wait=N（等待回复）
        loop 轮询 N 秒
            Skill->>Skill: _inbox 非空?
        end
        Skill-->>Agent: 新消息内容（或超时 None）
    end
```

关键不变量：read() 或 reply() 后 _inbox.clear() 保证 reply(wait=N) 不会误判旧消息为新回复——回复时先清空旧 inbox，轮询只捡到 receive() 新投递的消息。

与 server.py 的关系：Hull 托管模式下 server.py 持有 skill 实例引用（通过 start 注入），receive() 是唯一的消息投递入口，不再需要 _sync_chat() 文件轮询。

## Status

### TODO
无。

### Known Issues
无。

### Active
无。
