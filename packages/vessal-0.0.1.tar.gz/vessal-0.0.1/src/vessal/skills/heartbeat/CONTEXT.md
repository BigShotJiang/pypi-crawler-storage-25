# Heartbeat

周期性定时唤醒 Skill。在后台线程以可配置间隔调用 hull.wake("heartbeat")，防止 Agent 因无外部事件而无限休眠。

负责：
- 启动后台定时线程（server.py start()）
- 周期性调用 hull_api.wake("heartbeat")
- 干净停止定时线程（server.py stop()）

不负责：
- 执行任何 Agent 逻辑（仅唤醒，不执行）
- 管理唤醒后的 Agent 行为（由 Hull/Cell 负责）
- 配置持久化（间隔由 Hull 从 hull.toml 传入）

## Constraints

1. 后台线程必须设为 daemon=True，确保主进程退出时不被阻塞
2. stop() 必须 join 线程（timeout=5s），不能直接 kill
3. 默认间隔 1800 秒（30 分钟），可通过 hull.toml [hull].heartbeat 覆盖
4. start() 调用前若已有实例，必须先 stop() 旧实例再创建新实例
5. 使用实例模式（_HeartbeatServer 类），禁止模块级全局可变状态（除 _instance 指针外）

## Design

Heartbeat 解决的问题是 Agent 事件驱动模型下的"死锁"场景：Hull 等待事件才唤醒 Agent，但如果外部没有任何事件（用户沉默、所有任务阻塞），Agent 会永久休眠，无法进行主动性工作（如轮询、定期检查、维护任务）。Heartbeat 作为时间驱动的兜底机制，保证 Agent 至少每隔 N 秒被唤醒一次。

形状选择：server.py 模式（而非 skill.py 内嵌逻辑）。Heartbeat 的核心逻辑是定时器，不需要 SkillBase 的帧信号机制，只需要 start/stop 生命周期。这与 Human skill 的 server.py 伴生模式一致，Hull 自动发现并管理生命周期。

```mermaid
stateDiagram-v2
    [*] --> stopped : 初始

    stopped : stopped（无后台线程）
    running : running（_HeartbeatServer 实例存在）
    sleeping : sleeping（等待间隔 N 秒）
    waking : waking（调用 hull_api.wake）

    stopped --> running : start(hull_api, heartbeat=N)
    running --> sleeping : 线程启动，开始计时
    sleeping --> waking : 间隔到期
    waking --> sleeping : wake() 完成，重新计时
    running --> stopped : stop()（join thread, timeout=5s）
    sleeping --> stopped : stop() 信号
```

使用实例模式而非模块级线程对象，确保测试隔离安全：每次 start() 创建新的 _HeartbeatServer 实例，stop() 销毁旧实例，没有跨测试的状态泄漏。

间隔通过 hull.toml 的 `[hull].heartbeat` 配置键传入，而不是硬编码或环境变量，保持配置集中在一处。默认值 1800 秒是基于"Agent 不应超过 30 分钟无任何主动行为"的判断。

与 Hull 的关系：Hull 调用 server.start(hull_api)，传入 hull_api 引用，heartbeat 线程持有此引用并定期调用 wake()。Hull 负责将 heartbeat 事件路由到 Cell 执行帧。

## Status

### TODO
- [ ] 2026-04-09: 编写 heartbeat skill 初始测试

### Known Issues
无。

### Active
无。
