# Pin

变量固定观测 Skill。将指定命名空间变量名加入观测列表，每帧渲染其当前值到 Agent 信号区，只读不写。

负责：
- 添加变量到观测列表（pin()）
- 从观测列表移除变量（unpin()）
- 每帧从命名空间读取被 pin 变量的当前值并渲染（_signal()）

不负责：
- 修改命名空间中的任何变量
- 变量值历史记录或变化检测
- 格式化逻辑（由 kernel.describe.render_value() 负责）

## Constraints

1. Pin 永远不修改 ns 中的任何值，只读
2. 不存在于 ns 中的变量名以 `[name: 不存在]` 渲染，不抛异常
3. _signal() 输出按变量名字母排序，保证稳定输出
4. ns 为 None 时 _signal() 输出空字符串，不报错
5. 单文件不超过 100 行（skill.py）

## Design

Pin 存在是因为 Agent 调试需要"持续关注某个变量"的能力。没有 Pin，Agent 只能在每帧手动打印变量，或者依赖 Cell 的完整 namespace 渲染（噪音太多）。Pin 提供精准的"变量窗口"——只展示 Agent 关心的那几个变量。

形状极其简单：一个 set 存储变量名，一个 dict 引用（ns）用于读值。没有持久化，因为观测列表是调试状态，随会话结束消失是合理的。没有变化检测，因为每帧都渲染当前值已经足够 Agent 发现变化。

```mermaid
graph LR
    Agent["Agent 代码"]
    Pin["pin skill\n_pinned: set of str"]
    NS["Cell namespace (ns)"]
    RV["kernel.describe.render_value()"]
    Signal["_signal()\n每帧渲染 pinned 变量"]

    Agent -->|"pin.pin('var_name')"| Pin
    Agent -->|"pin.unpin('var_name')"| Pin
    Pin -->|"只读取，不修改"| NS
    NS -->|"当前值"| RV
    RV -->|"格式化文本"| Signal
    Signal -->|"注入信号区"| Agent
```

渲染委托给 `kernel.describe.render_value()`，保持与 Cell 的渲染一致性，避免 Pin 和 Cell 对同一变量产生不同的展示格式。

不变量：ns 引用只读。任何修改 ns 的行为都违反 Pin 的边界，应放在 Agent 代码或其他 skill 中。

与 Cell/Kernel 的关系：依赖 kernel.describe.render_value 渲染，但不依赖 Cell 本身。与 Hull 的关系：通过 SkillBase 协议参与帧循环，_signal() 输出注入 Agent 系统提示。

## Status

### TODO
无。

### Known Issues
无。

### Active
无。
