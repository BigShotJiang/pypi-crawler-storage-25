# Memory

文件持久化的键值记忆。Agent 通过 save() 存储跨会话记忆，全量显示在 signal 中。同时监测上下文压力，超过阈值时提示 Agent 总结旧帧并删除。

**核心定位：搜索代替常驻上下文。** 不需要每帧都在上下文里的信息，存到 memory，用时检索。这是 Agent 管理自身上下文的主动手段。

负责：
- 键值存储（save/get/delete）
- 每帧 signal 输出所有记忆
- 上下文压力信号（读 `_context_pct`，超过 `_compress_threshold` 时警告）
- 物理删帧（drop(n)：截断 `_frame_log` 最旧 n 帧）

不负责：
- 搜索/检索（未来优化）
- 向量化/嵌入（未来优化）
- 自动摘要（Agent 手动用 memory.save() 总结后再 drop）

## Constraints

1. 存储文件为 data/memory.json，JSON 格式
2. save() 必须立即写盘
3. signal 全量输出所有记忆（key: value 摘要），无筛选
4. value 可以是任意 JSON 可序列化对象
5. drop(n) 至少保留 1 帧，不允许清空帧流
6. drop(n) 必须先输出确认提示再执行删除
7. signal 阈值默认 50%，由 `_compress_threshold` namespace 变量控制（hull.toml [cell].compress_threshold 配置）

## Design

最简方案：一个 JSON 文件存所有键值对。signal 全量 dump。

上下文压力检测在 `_signal()` 中实现：读 `_context_pct`（由 Kernel 渲染后计算），超过 `_compress_threshold`（默认 50）时附加警告行，引导 Agent 使用 drop(n) 管理帧流。

drop(n) 直接操作 `_frame_log`（从 ns 引用，Memory 在初始化时保存 ns 引用）。物理删除后帧流缩短，下帧渲染时 `_context_pct` 自然下降。冷存储（FrameLogger JSONL）不受影响。

```mermaid
flowchart TD
    A["Agent 每帧看到 signal: ⚠ 上下文 N%"] --> B["memory.save() 保存旧帧关键信息"]
    B --> C["memory.drop(n) 物理删帧"]
    C --> D["drop 输出确认提示"]
    D --> E["_frame_log[:n] 删除"]
    E --> F["下帧 _context_pct 自然下降"]

    G["_signal() 每帧"] --> H{"_context_pct >= _compress_threshold?"}
    H -->|是| I["输出 ⚠ 警告行"]
    H -->|否| J["只输出记忆条目"]
```

```mermaid
flowchart LR
    Agent["Agent 代码"]
    Skill["memory skill"]
    JSON["data/memory.json"]
    Signal["_signal()\n每帧输出记忆 + 压力警告"]
    FL["_frame_log"]

    Agent -->|"memory.save(key, value)"| Skill
    Skill -->|"立即写盘"| JSON
    Agent -->|"memory.get(key)"| Skill
    Agent -->|"memory.drop(n)"| Skill
    Skill -->|"物理删帧"| FL
    JSON -->|"每帧全量读取"| Signal
    Signal -->|"注入信号区"| Agent
```

## Status

### TODO
- [ ] 2026-04-10: 未来添加搜索/检索能力

### Known Issues
无。

### Active
无。
