# Vision

Qwen3 VL 235B 本地服务器的封装。Agent 通过 vision.ask() 和 vision.describe() 理解图片内容。主要用于 GAIA 评测中读取图表、图片题目。

负责：
- 图片内容描述（describe()）
- 针对图片的问答（ask()）

不负责：
- 视频理解
- 多图对比
- URL 图片（需先下载到本地）

## Constraints

1. 图片文件必须存在于本地文件系统
2. 支持 png/jpg/jpeg/gif/webp；其他格式按 image/png 处理
3. 使用懒初始化：OpenAI client 在首次调用时创建
4. 后端地址和 api_key 通过环境变量配置（VISION_BASE_URL, VISION_API_KEY）

## Design

```mermaid
flowchart LR
    Agent["Agent 代码"]
    V["Vision Skill"]
    QW["Qwen3 VL 235B\nhttp://192.168.40.42:8001/v1\nOpenAI 兼容格式"]

    Agent -->|"vision.ask(path, q)"| V
    Agent -->|"vision.describe(path)"| V
    V -->|"base64 image + question"| QW
    QW -->|"text answer"| V
```

## Status

### TODO
无。

### Known Issues
无。

### Active
无。
