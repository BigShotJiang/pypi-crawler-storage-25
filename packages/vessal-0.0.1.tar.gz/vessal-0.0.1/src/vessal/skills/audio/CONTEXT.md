# Audio

302AI GLM-ASR-2512 语音转写 API 的封装。Agent 通过 audio.transcribe() 将音频文件转为文字。主要用于 GAIA 评测中处理音频题目。

负责：
- 音频文件转文字（transcribe()）
- base64 编码后通过 HTTP 上传

不负责：
- 长音频切片（≤30 秒限制由 API 强制执行）
- 实时语音
- 文件格式转换

## Constraints

1. API key 从环境变量 `API_302AI_KEY` 读取，未设置时调用即报错
2. 文件不存在时抛出 FileNotFoundError
3. 文件 > 25MB 时抛出 ValueError（客户端强制执行）
4. HTTP 错误包含 API 返回的 body（最多 200 字符）
5. 返回文本自动 strip()

## Design

```mermaid
flowchart LR
    Agent["Agent 代码"]
    A["Audio Skill"]
    ASR["302AI GLM-ASR-2512\nPOST /bigmodel/api/paas/v4/audio/transcriptions"]

    Agent -->|"audio.transcribe(path)"| A
    A -->|"base64(file) + model=glm-asr-2512"| ASR
    ASR -->|"text"| A
```

## Status

### TODO
无。

### Known Issues
无。

### Active
无。
