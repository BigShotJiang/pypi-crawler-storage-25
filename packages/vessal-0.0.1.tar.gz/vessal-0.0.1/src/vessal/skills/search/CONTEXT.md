# Search

302AI Web-Search 和 Web-Reader 的封装。Agent 通过 search.web() 搜索网页，通过 search.read() 读取网页全文。解决了 DuckDuckGo 在中国大陆网络环境下 100% 失败的问题。

负责：
- 网络搜索（web-search API，返回 [{name, url, snippet, summary}]）
- 网页全文读取（web-reader API，返回 markdown）

不负责：
- 图片搜索
- 分页（count 参数控制单次返回数量）
- 缓存

## Constraints

1. API key 从环境变量 `API_302AI_KEY` 读取，未设置时调用即报错
2. 网络错误（HTTPError/URLError）包装为 RuntimeError 再抛出
3. web() 的 `code` 检查使用默认值 0（`data.get("code", 0) != 0`）
4. 无状态：每次调用独立，不缓存，不保持连接

## Design

```mermaid
flowchart LR
    Agent["Agent 代码"]
    S["Search Skill"]
    WS["302AI Web-Search\nPOST /unifuncs/api/web-search/search"]
    WR["302AI Web-Reader\nPOST /unifuncs/api/web-reader/read"]

    Agent -->|"search.web(query)"| S
    Agent -->|"search.read(url)"| S
    S --> WS
    S --> WR
```

## Status

### TODO
无。

### Known Issues
无。

### Active
无。
