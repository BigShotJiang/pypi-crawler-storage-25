# UI

赛博具身 Skill。两层架构：body（avatar 控制）+ 组件环境。Server-driven，Python namespace 是唯一状态来源。

负责：
- Avatar 控制（位置、表情、语音气泡、交互选项）
- 组件环境（面板、按钮、图表等 6 种基础组件）
- 用户事件收集（点击、输入、avatar 点击）
- 每帧渲染页面状态摘要（_signal）
- 注入认知协议（_prompt）
- HTTP 路由（/render 轮询、/events 事件接收、静态文件）

不负责：
- 前端本地视觉反馈（hover、动画过渡——前端自行处理）
- 持久化（UI 状态纯内存，不写文件）
- 与其他 skill 的通信（严格禁止 skill 间耦合）

## Constraints

1. body 和 ui 组件是独立对象，不互相调用，通过 namespace 间接通信
2. button 和 input 必须指定 id（事件识别）
3. render() 替换整个组件树，不是追加
4. read() 清空 inbox，和 chat.read() 行为一致
5. _signal() 放完整页面状态摘要（body + 组件 + 事件）
6. _prompt() 不允许包含方法签名
7. 前端动作队列顺序播放 body 动作，每个动作之间有过渡延迟
8. 点击 avatar 是固定的唤醒/中断入口，事件走 UI skill 自己的 inbox

## Design

### 两层模型

Layer 1 body：寄居蟹 avatar。6 个方法控制位置、表情、语音、指向、选择和输入。每帧内调用累积到动作队列，render() 时 body._drain() 导出并清空队列（保留状态字段 position/emotion/speech）。_drain() 返回 deepcopy 防止调用方意外修改内部队列。

Layer 2 ui：组件环境。6 个工厂方法生成 dict，render() 序列化推送。前端用 replaceWith 全树替换 DOM（不做 diff，避免事件监听器泄漏）。

### 数据流

AI 帧代码 → body._drain() + components → render spec JSON → HTTP → 前端渲染
用户操作 → 前端事件 → POST /events → skill._inbox → AI 下一帧 ui.read()

### 动画节奏

思考时（帧间）前端播放 CSS idle 动画。帧代码中的 body 动作通过前端动作队列顺序播放，每个动作 200-600ms 过渡。

## Status

### TODO
无。

### Known Issues
无。

### Active
- 2026-04-13: 初始实现
