/**
 * poll.js — HTTP 轮询 + 事件发送。
 * 每 300ms 轮询 GET /render，有更新时调用 window.onRenderSpec(spec)。
 * sendEvent(event) POST 到 /events。
 */
(function() {
  let currentVersion = -1;

  async function poll() {
    try {
      // 使用当前页面路径作为 base（/skills/ui/）
      const base = location.pathname.replace(/\/$/, '');
      const res = await fetch(`${base}/render?after_version=${currentVersion}`);
      if (!res.ok) return;
      const data = await res.json();
      if (data.unchanged === true) return;
      if (data.version > currentVersion) {
        currentVersion = data.version;
        if (window.onRenderSpec) {
          window.onRenderSpec(data);
        }
      }
    } catch (e) {
      // Ignore network errors, retry next poll
    }
  }

  window.sendEvent = async function(event) {
    try {
      const base = location.pathname.replace(/\/$/, '');
      const res = await fetch(`${base}/events`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(event),
      });
      if (!res.ok) console.warn('sendEvent failed:', res.status);
    } catch (e) {
      console.error('sendEvent failed:', e);
    }
  };

  setInterval(poll, 300);
  poll();  // Initial poll
})();
