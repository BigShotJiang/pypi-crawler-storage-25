# Shell

HTTP 边界层。将外部 HTTP 请求解析后代理给 Hull，并将 Hull 的响应返回给调用方。

## 公开接口

- `cli.py` — 运行时命令实现（vessal start / stop / init 等）
- `server.py` — HTTP 服务器（ShellServer）
- `hull_runner.py` — Hull 子进程入口（standalone 适配器，绑定 127.0.0.1）
- `container/` — Shell 容器化实现（entry.py = Docker ENTRYPOINT 适配器，绑定 0.0.0.0，处理 SIGTERM，提供 /healthz）
- `protocol.py` — handle() 协议类型定义（HandleResult = tuple[int, dict | StaticResponse]），所有 Shell 实现共享

## 负责

- HTTP 服务器启动与监听（主进程，用户指定端口）
- 请求反向代理到 Hull 子进程
- 响应序列化（JSON 或 StaticResponse 原样返回）
- Hull 子进程的监护（崩溃检测 + 自动重启 + 重启期间返回"agent 重启中"）
- CLI 入口（vessal start / stop / send / status / read / init / skill）
- /logs 端点（通过 Hull 内置路由）：GET /logs → viewer.html，GET /logs/raw → 当前 run 的 JSONL 内容

不负责：
- 业务逻辑（由 Hull 处理）
- 帧执行（由 Cell 处理）
- Skill 管理（由 Hull 处理）
- 心跳调度（由 vessal.skills.heartbeat.server 处理）
- 状态维护（Shell 无状态，所有状态在 Hull 和 Cell）

## Constraints

1. Shell 不 import Cell 或 Kernel——依赖方向：Shell 依赖 Hull，Hull 依赖 Cell，不可反向
2. 所有公开类和函数必须有完整 docstring 和类型注解
3. Shell 只通过 Hull.handle() 与 Hull 交互，不访问 Hull 内部属性

## Design

Shell 存在的理由有两个。第一，把 HTTP 协议细节从 Hull 隔离出去——Hull 只看到 `(method, path, body_dict)` 三元组，不知道 HTTP 头和 JSON 编解码。第二，提供进程级崩溃隔离——Shell 运行在主进程中，Hull 运行在子进程中（由 `subprocess.Popen` 启动 `hull_runner.py`，使用 `sys.executable`）。LLM 生成的代码在 Hull 子进程中执行，原生库的致命错误（abort、segfault）只杀子进程。Shell 的监护线程检测到子进程退出后自动重启，期间对外返回"agent 重启中"，用户看到的是暂时的 HTTP 503 而非"连接被拒绝"。Shell 之于 Hull，如同 Docker 之于容器内的应用。

Shell 启动 Hull 子进程的步骤：调用 `_spawn_hull()`，它启动 `hull_runner.py` 作为子进程，等待 stdout 输出 `READY:{port}` 消息（表示 Hull 内部 HTTP 服务已就绪），然后 `_ProxyHandler` 开始转发请求到 Hull 的内部端口。启动前 Shell 拉起监护线程（monitor），定期检查子进程状态，若发现进程已死亡则自动调用 `_spawn_hull()` 重启。

```mermaid
sequenceDiagram
    participant CLI
    participant Shell
    participant HullSubprocess as Hull 子进程

    CLI->>Shell: ShellServer.start()
    Shell->>HullSubprocess: subprocess.Popen(hull_runner.py)
    HullSubprocess-->>Shell: stdout: READY:{port}
    Shell->>Shell: 启动监护线程（monitor）
    Shell->>Shell: 启动 HTTP 服务器

    loop 每个 HTTP 请求
        Note over Shell: 用户请求到达
        Shell->>HullSubprocess: 反向代理转发请求
        HullSubprocess-->>Shell: 响应
        Shell-->>CLI: 响应返回给调用方
    end

    Note over Shell,HullSubprocess: 若子进程崩溃
    HullSubprocess--xShell: 进程退出
    Shell->>Shell: monitor 检测到死亡
    Shell->>HullSubprocess: _spawn_hull() 重启
    Note over Shell: 期间返回 503
```

Shell 是纯代理，不做任何路由决策。它收到请求后原样转发给 Hull 子进程（反向代理），不知道有哪些路由存在。路由表在 Hull 内部，Shell 不持有副本。

ShellServer 有三个公开方法：`start()`（非阻塞，启动 HTTP 线程 + 启动 Hull 子进程 + 启动监护线程）、`serve_forever()`（阻塞到 shutdown 被调用）、`shutdown()`（停止所有线程 + 杀子进程）。

心跳调度从 Shell 移出的决策：早期版本 ShellServer 持有心跳定时器，但定时器是 Agent 行为策略（多久 wake 一次），不是 HTTP 协议关注点。把它移到 heartbeat Skill 后，Shell 变为无状态——它没有要初始化的定时器（只有监护定时器），没有业务后台线程，测试时不需要关心任何调度副作用。

不变量：每一个到达 Shell HTTP 服务器的请求，无论何种路径、何种方法，必须转发给 Hull 子进程的 HTTP 服务。Shell 不得在转发之前短路（除了协议级错误，如 Content-Length 缺失时 body 为 None，但这也会被尝试转发）。若 Hull 子进程不可用（崩溃期间），Shell 返回 503 Service Unavailable。

Shell 与 Hull 的关系：Shell 依赖 Hull，Hull 不知道 Shell。类型注解用 `TYPE_CHECKING` 块，避免运行时循环 import。

## Status

### TODO
- [ ] 2026-04-09: cli.py 中 _cmd_start 的 companion 进程启动逻辑过长，可考虑提取

### Known Issues
- 2026-04-09: cli.py 当前 739 行，超过 500 行惯例（未设为硬约束，因为 CLI 入口集中式设计需要较长文件）
- 2026-04-10: daemon 生命周期身份模型重建——PID 文件替换为 flock（data/vessal.lock），详见 flock 身份模型计划

### Active
- 2026-04-10: 重构 start/stop 为 flock 身份模型：默认前台，--daemon 可选后台，stop 等待进程退出

### Completed
- 2026-04-10: Shell-Hull 进程隔离——Hull 在子进程中运行（subprocess.Popen hull_runner.py），Shell 主进程作为 HTTP 网关和监护，包含崩溃检测和自动重启
