# Container

Docker 容器入口适配器。当 Vessal 以 Docker 容器运行时，此模块提供引导程序，创建 Hull 实例并启动 HTTP 服务。

负责：
- Hull 实例创建和初始化（从 project_dir 读取 hull.toml）
- HTTP 服务器启动（绑定 0.0.0.0，跨容器外部可访问）
- HTTP 请求路由转发至 Hull（对所有非 /healthz 路由）
- /healthz 健康检查端点（不经过 Hull）
- SIGTERM 信号处理（优雅关闭）
- 镜像→volume 文件同步（sync_image_to_volume）：首次启动全量复制，镜像更新覆盖定义文件，运行时数据不动

不负责：
- Agent 执行（由 Hull 处理）
- Skill 管理（由 Hull 处理）
- 日志系统（由 vessal.util.logging 处理；本模块只输出到 stdout）

## Constraints

1. HTTP 服务绑定 0.0.0.0（容器外部可访问），不是 127.0.0.1
2. 无子进程调用——Shell 逻辑在 Hull 中，不在此处
3. 所有错误都返回有效 HTTP 响应，不抛异常到容器外
4. 优雅关闭：SIGTERM 触发 Hull.stop()，HTTP 服务等待现有请求完成后关闭
5. _ContainerHandler 与 hull_runner._HullHandler 参数签名保持一致
6. sync_image_to_volume 不删除 volume 中镜像不存在的文件（Agent 自建 skill、运行时数据）

## Design

Container 是 Hull 的直接容器包装——它做的只是初始化和 HTTP 代理，所有业务逻辑都是 Hull 的职责。与 hull_runner.py 的区别：

1. **网络绑定**：hull_runner 绑定 127.0.0.1（Shell 内部通信），Container 绑定 0.0.0.0（容器外部访问）
2. **信号处理**：hull_runner 处理 SIGTERM 后打印 READY，Container 直接调用 Hull.stop()
3. **日志输出**：hull_runner 输出 READY 信号到 stdout 给 Shell 解析，Container 输出日志到 docker logs

_ContainerHandler.do_GET() 和 do_POST() 调用 Hull.handle() 返回 (status, data) 对，然后调用 _respond() 或 _respond_json() 序列化。两个响应方法的签名遵循 Formalin DTC：data 优先，status 可选（默认 200）。

```mermaid
graph LR
    Client["Docker 外部客户端\n(docker run -p)"]
    Handler["_ContainerHandler"]
    Hull["Hull\n(处理逻辑)"]

    Client -->|"HTTP GET/POST"| Handler
    Handler -->|"转发请求"| Hull
    Hull -->|"返回 (status, data)"| Handler
    Handler -->|"序列化响应"| Client
```

## Public Surface

- `main()` — 容器入口点，解析参数（--dir, --port），创建 Hull，启动 HTTP，运行事件循环
- `_ContainerHandler` — HTTP 请求处理器，转发至 Hull 或响应 /healthz
- `sync_image_to_volume(image_src, volume_dst)` — 镜像文件同步到 volume（首次启动全量复制 / 镜像更新选择性覆盖）

## Status

### TODO
无。

### Known Issues
无。

### Active
无。

### Completed
- 2026-04-13: 参数签名对齐 — _respond() 和 _respond_json() 改为 (data, status=200) 格式，与 hull_runner._HullHandler 一致
- 2026-04-14: volume 持久化修复 — 挂载点从 /app/agent/data 扩展为 /app/agent，新增 sync_image_to_volume 处理镜像→volume 文件同步
