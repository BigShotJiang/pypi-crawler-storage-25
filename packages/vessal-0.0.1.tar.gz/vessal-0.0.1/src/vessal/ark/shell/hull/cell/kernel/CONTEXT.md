# Kernel

Agent 执行内核。持有 namespace dict，协调代码执行、断言求值和状态渲染，是 Agent 行为的完整决定因子。

负责：
- namespace dict 的持有、初始化、快照（cloudpickle）、恢复
- 操作代码执行（exec_operation → executor.py）
- expect 断言求值（eval_expect → expect.py）
- 信号收集（update_signals：BASE_SIGNALS + duck-typing 扫描）
- namespace 渲染为 Ping（render → render/renderer.py）

不负责：
- 门控检查（由 Gate 负责）
- 帧日志归档（由 Cell 负责，_commit_frame 由 Cell 触发但在 kernel.run() 中执行）
- LLM 调用（由 Core 负责）
- HTTP 通信（由 Shell 负责）

## Constraints

1. kernel.py 不超过 420 行
2. executor.py 不超过 500 行
3. expect.py 不超过 250 行
4. namespace dict 是 Agent 状态的唯一来源，Kernel 本身不持有 ns 之外的运行时状态
5. eval_expect() 永不抛出异常，所有错误收入 Verdict.failures
6. execute() 不写 _frame_log，不构造 FrameRecord（这是 Cell 的职责）
7. 所有公开接口必须有完整 docstring 和类型注解
8. describe/ 和 render/ 是 Kernel 的内部实现子包，不应被 Kernel 外部直接导入
9. snapshot 降级（全量序列化失败）时必须将丢失的 key 记录到 _dropped_keys（list）和 _dropped_keys_context（dict），不得静默丢弃

## Design

Kernel 运行在 Hull 子进程中。namespace dict 活在子进程的内存里，exec(code, ns) 在线程池线程上执行（asyncio.to_thread），直接操作同进程内的 namespace dict。skill 实例（chat, tasks 等）也在同一进程中，LLM 代码调 chat.read() 时直接内存调用，不跨进程。数据库连接、文件句柄等不可序列化对象正常跨帧保持。子进程崩溃时，namespace 从 snapshot 恢复，不可序列化对象丢失并记录在 _dropped_keys 中。

Kernel 存在是为了将 Agent 的"大脑"封装为一个可快照、可恢复的单元。它的核心方程是：`namespace dict = Agent 的完整状态`。所有变量、函数、类、历史帧、配置全部活在这个 dict 里。这意味着 Kernel 本身无状态——它只是 namespace 的执行器和渲染器，可以在任意时刻被序列化和恢复。

为什么 executor 是独立文件而不是 Kernel 的方法？executor.py 是纯机制层（exec + 副作用收集），不依赖任何其他 Kernel 模块，稳定性极高。独立文件让它可以被单独测试，边界清晰。同理，expect.py 和 describe/ 也是纯函数子系统，与 Kernel 解耦。

```mermaid
graph TD
    KernelPy["kernel.py\n（主类：协调器）"]
    Exec["executor.py\n（纯机制：exec + 副作用）"]
    Expect["expect.py\n（纯函数：断言求值）"]
    Describe["describe/\n（纯函数：对象渲染为文本）"]
    Render["render/\n（namespace → Ping 组装）"]

    KernelPy -->|"exec_operation()"| Exec
    KernelPy -->|"eval_expect()"| Expect
    KernelPy -->|"render()"| Render
    Exec -->|"diff 计算"| Describe
    Render -->|"namespace 展示"| Describe
```

describe/ 子包负责将 Python 对象渲染为文本，支持三种详细程度：directory（摘要行）、diff（截断展示）、pin（详细观测）。它是 executor 的 diff 计算和 renderer 的 namespace 展示的共同依赖。render/ 子包负责将 namespace 组装为 Ping（system_prompt + 帧流 + 信号），其中 `prompt.py` 维护 SystemPromptBuilder 的三段拼接（kernel protocol + SOUL + skill protocols），`_signal_render.py` 负责信号区段渲染（每帧辅助信号），`_prompt_render.py` 负责技能认知协议收集与渲染（duck-type 扫描 _prompt() 方法），是 Kernel.render() 的实现。这两个子包是 Kernel 的实现细节，外部不应直接导入。

snapshot/restore 使用 cloudpickle，支持函数、类、lambda、闭包。restore 前先修复 sys.path（从 _loaded_skills 读取 parent_path），确保 cloudpickle 反序列化时能找到模块。原子写入（写临时文件后 os.replace 替换）防止写入中断导致文件损坏。全量序列化失败时降级为过滤不可序列化 key 后保存，同时将被丢弃的 key 列表写入 _dropped_keys，原始创建代码（从 _frame_log 反向搜索）写入 _dropped_keys_context。restore 后 update_signals() 调用 dropped_keys 信号，若 _dropped_keys 非空则向 Agent 输出重建提示。

```mermaid
flowchart TD
    Snapshot["snapshot(path)"]
    TryFull["尝试全量 cloudpickle 序列化"]
    FullOK{成功?}
    AtomicWrite["原子写入\n（写临时文件 → os.replace）"]
    Filter["过滤不可序列化 key"]
    PartialWrite["写入部分快照\n记录 _dropped_keys"]

    Restore["restore(path)"]
    FixPath["修复 sys.path\n（从 _loaded_skills 读取）"]
    Unpickle["cloudpickle 反序列化"]
    CheckDropped{_dropped_keys 非空?}
    Signal["向 Agent 输出\n重建提示信号"]
    Done["恢复完成"]

    Snapshot --> TryFull
    TryFull --> FullOK
    FullOK -->|是| AtomicWrite
    FullOK -->|否| Filter --> PartialWrite

    Restore --> FixPath --> Unpickle --> CheckDropped
    CheckDropped -->|是| Signal --> Done
    CheckDropped -->|否| Done
```

_frame_log 的不变量：帧记录由 Cell 通过 kernel.run() 间接构造，_commit_frame 负责拼接 FrameRecord，但追加逻辑在 kernel.py 内，最大容量 _FRAME_LOG_MAX=200 帧。schema 版本不匹配时 restore 后清空 _frame_log，防止旧格式帧污染新逻辑。

Kernel 与相邻组件的关系：Cell 调用 Kernel.run() 完成单帧执行，Gate 在 Cell 层拦截，不进入 Kernel。Core 接收 Ping（Kernel.render() 的输出）并返回 Pong，Pong 再传入 Kernel.run()。Kernel 不引用 Cell、Core、Gate。

已知规模问题：kernel.py 已近 400 行上限，describe/ + render/ 合计超过 700 行，整体超过 1100 行。规模来自 namespace 管理的固有复杂性，当前不拆分，但新增功能需评估是否提取子模块。

## Status

### TODO
- [ ] 2026-04-09: kernel.py 重构评估——若超过 400 行需提取子模块

### Known Issues
- 2026-04-09: snapshot 恢复在模块路径变更后可能失败（cloudpickle 模块引用绑定到序列化时的路径）
- ~~2026-04-09: 约束 #8 违规——hull.py 直接 import kernel.render.RenderConfig、pin/skill.py 直接 import kernel.describe.render_value~~ [已修复 2026-04-09：RenderConfig 和 render_value 已从 kernel/__init__.py 再导出，外部代码改为从 kernel 包顶层导入]

### Active
- 2026-04-13: _init_namespace() 新增两个 namespace 键：_protected_keys（初始化时所有 key 的列表，executor 据此恢复被 agent 删除的 builtin）；_errors（list[ErrorRecord]，executor 和 Cell 在运行时/协议错误时追加）。_actual_tokens_in/_actual_tokens_out 初始化为 None，由 Cell 在 API 返回 usage 时写入真实值。
