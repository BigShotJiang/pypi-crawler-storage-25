# Gate

action / state 执行前的安全门控模块。提供 ActionGate（代码执行前）和 StateGate（LLM 调用前）两个独立门控。

负责：
- ActionGate：action 代码送入 Kernel.exec_operation() 之前检查
- StateGate：state 字符串送入 Core.run() 之前检查
- 三种模式：auto（直接放行）、safe（规则检查）、human（预留）
- 内置规则集（rules.py）：拦截高危文件系统操作和进程操作
- add_rule / remove_rule：用户自定义规则注入

不负责：
- 代码执行（由 Kernel 负责）
- LLM 调用（由 Core 负责）
- 规则的持久化存储
- 修改或转换通过的内容（只检查，不变换）

## Constraints

1. 单文件不超过 300 行
2. Gate 只做检查，不修改传入内容（reject-only，无内容变换）
3. auto 模式必须零开销：不执行任何规则，直接返回
4. 规则函数签名固定：`(content: str) -> str | None`，None 表示放行，字符串表示拦截原因
5. 规则执行异常必须 catch + log，不向外传播（单条规则崩溃不影响其他规则）
6. 所有公开接口必须有完整 docstring 和类型注解

## Design

Gate 存在是因为 Agent 执行的代码和送入 LLM 的 state 都是不可信内容。不加任何检查，Agent 可以向宿主写入任意文件、杀死进程、或将大量私有数据发往 LLM。Gate 是这条路径上唯一的静态防线。

为什么是两个独立门控而不是一个？ActionGate 针对 Python 代码做文本模式匹配，StateGate 针对渲染后的 prompt 字符串做结构检查（如长度预算），两者的规则类型不同，合并会造成不必要的耦合。

三种模式的存在原因：auto 是开发阶段默认，零开销；safe 是生产部署模式；human 预留给未来人类确认交互（当前行为等同 safe）。**auto 模式是不变量**——任何代码修改都不得在 auto 模式下引入任何规则执行开销。

```mermaid
stateDiagram-v2
    [*] --> auto : 默认

    auto : auto 模式（零开销，直接放行）
    safe : safe 模式（运行内置规则 + 用户规则）
    human : human 模式（预留，当前行为 = safe）

    auto --> safe : cell.action_gate = "safe"
    safe --> auto : cell.action_gate = "auto"
    safe --> human : cell.action_gate = "human"
    human --> safe : cell.action_gate = "safe"
    auto --> human : cell.action_gate = "human"
    human --> auto : cell.action_gate = "auto"
```

rules.py 定义内置规则集。规则只拦截"几乎不可能是合理 Agent 行为"的操作：递归删除根目录或用户目录、系统路径写入、批量进程杀死。不拦截普通文件读写、网络请求、第三方库导入，这些是 Agent 正常工作的必要操作。过度拦截比欠拦截危害更大，因为它会让 Agent 无法完成任务。

safe 模式的另一个不变量：**只拒绝，不修改**。Gate 不做内容变换（如截断过长的 state），修改语义是 Cell 的职责，Gate 只报告是否通过。

```mermaid
flowchart TD
    Input["content（代码字符串或 state 字符串）"]
    ModeCheck{模式?}
    Allow["允许通过\nallowed=True"]
    Rules["运行规则列表\n(内置规则 + 用户规则)"]
    AnyReject{任意规则返回非 None?}
    Reject["拒绝\nallowed=False, reason=规则返回值"]

    Input --> ModeCheck
    ModeCheck -->|"auto"| Allow
    ModeCheck -->|"safe / human"| Rules
    Rules --> AnyReject
    AnyReject -->|"否"| Allow
    AnyReject -->|"是"| Reject
```

Gate 与 Cell 的关系：Cell 调用 Gate.check()，根据返回的 allowed 字段决定是否继续执行，Gate 不直接引用 Cell，依赖是单向的。

## Status

### TODO
- [ ] 2026-04-09: human 模式实现（交互式人类确认）

### Known Issues
- 2026-04-09: StateGate 当前无内置规则（内置规则预留但未实现），safe 模式下只运行用户自定义规则

### Active
无。
