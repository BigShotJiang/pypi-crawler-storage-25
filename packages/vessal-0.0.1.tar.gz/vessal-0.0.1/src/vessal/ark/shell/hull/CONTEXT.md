# Hull

Agent 运行时编排器。读取 hull.toml 配置，初始化 Cell，管理 Skill 生命周期、事件循环和元技能调度。

负责：
- hull.toml 配置解析与 Cell 初始化
- Skill 发现、加载、实例化和卸载（通过 SkillManager）
- 事件循环驱动（通过 EventLoop，wake/sleep 生命周期）
- 元技能注册（SkillsManager，以 `skills` 注入 namespace；每帧通过 _signal() 输出可用 Skill 列表，通过 _prompt() 注入 guide 使用协议）
- HTTP 请求路由（handle() 是 Shell 的唯一入口）

不负责：
- HTTP 服务（由 Shell 处理）
- 单帧 LLM 调用（由 Cell 处理）
- 具体 Skill 逻辑（由各 Skill 组件处理）
- 心跳调度（由 vessal.skills.heartbeat.server 处理）

## Constraints

1. Hull 不 import Shell 层——依赖方向：Shell 依赖 Hull，Hull 依赖 Cell，不可反向
2. 所有公开方法必须有完整 docstring 和类型注解
3. Shell 只通过 Hull 公开方法访问（handle / wake / status / frames / next_alarm / run / run_once / stop / snapshot）

## Design

Hull 运行在独立的子进程中（由 Shell 主进程通过 `subprocess.Popen` 启动 `hull_runner.py`，使用 `sys.executable`）。所有 Agent 状态——namespace、skill 实例、帧循环——活在这个子进程中。exec(code, ns) 在这个子进程内直接操作 namespace dict，skill 方法在内存中直接调用，不存在跨进程序列化。数据库连接、文件句柄、import 的模块等不可序列化对象正常跨帧保持。子进程崩溃时由 Shell 自动重启，从 snapshot 恢复。

Hull 存在的理由是把"通用 Cell 变成特定 Agent"的配置工作集中在一处。Cell 是纯引擎，不知道 hull.toml、Skill 路径、系统提示词或日志目录在哪里。如果没有 Hull，Shell 就要承担所有初始化工作，而 Shell 的职责只是 HTTP 网关和监护，两者混合会让启动逻辑散落各处。

Hull 的形状是"配置层 + 生命周期管理器"而非"God Object"。它持有 Cell、EventLoop、SkillManager、SkillsManager 的引用，但只通过它们的公开接口操作，不越界访问内部实现。这个设计否决了"Hull 直接操作 Cell.ns 做路由"的方案——路由由 `_routes` dict 动态维护，Skill server 通过 HullApi 注册，Hull.handle() 查表分发，路由表和路由逻辑各自独立。

```mermaid
graph LR
    Hull["Hull\n（编排器）"]
    Cell["Cell\n（单帧执行）"]
    EL["EventLoop\n（帧调度）"]
    SM["SkillManager\n（Skill 发现/加载）"]
    Meta["SkillsManager\n（Agent 的 Skill 管理接口）"]
    HullApi["HullApi\n（Skill 路由注册）"]

    Hull -->|"创建 + 驱动"| Cell
    Hull -->|"创建 + 运行"| EL
    Hull -->|"创建 + 查询"| SM
    Hull -->|"注入 namespace (as skills)"| Meta
    Hull -->|"持有路由表"| HullApi
    SM -.->|"load/unload"| Meta
    EL -->|"FrameHooks 回调"| Hull
```

内部关键决策有三个。第一，runtime-owned 变量（`_frame_type`、`_render_config`、`_system_prompt`、`_soul`）由 Hull 在每帧前通过 `_rewrite_runtime_owned()` 回填，而不是由 Cell 或 LLM 维护。这保证 Agent 无法通过写入这些变量来改变它自己的视角。`_soul` 特殊：每帧检测 SOUL.md 的 mtime，文件变化时重读，使 Agent 运行时修改 SOUL.md 后下一帧即生效。第二，Skill 分两阶段加载：先加载类并实例化注入 namespace，再启动 server；server 启动失败时回滚第一阶段，避免 namespace 中存在无 server 支持的 Skill 实例。第三，心跳从 Shell 移出到 heartbeat Skill，使 Hull 初始化后的 ShellServer 是无状态的 HTTP 代理，简化了测试和生命周期管理。

```mermaid
sequenceDiagram
    participant Meta as SkillsManager.load()
    participant Hull
    participant SM as SkillManager
    participant NS as Cell namespace
    participant Server as Skill server.py

    Meta->>Hull: _load_and_instantiate_skill(name)
    Hull->>SM: load(name) → SkillClass
    Hull->>Hull: SkillClass() → instance
    Hull->>NS: cell.set(name, instance)

    Hull->>SM: has_server(name)?
    alt 有 server.py
        Hull->>Server: start(scoped_api)
        alt 启动成功
            Server-->>Hull: 路由已注册
        else 启动失败
            Hull->>NS: cell.set(name, None)  ← 回滚
            Hull->>SM: unload(name)          ← 回滚
        end
    end
```

```mermaid
graph LR
    Hull["Hull._rewrite_runtime_owned()"]
    Hull -->|"每帧回填"| FT["_frame_type"]
    Hull -->|"每帧回填"| RC["_render_config"]
    Hull -->|"每帧回填"| SP["_system_prompt"]
    Hull -->|"每帧检测 mtime\n变化时重读"| SOUL["_soul"]
```

不变量：每次 `wake()` 调用最终产生一个完整的帧周期——inject_wake、帧循环直到 `_sleeping` 置位、快照保存。EventLoop 保证这个过程不被中断（除非超过 max_frames_per_wake）。Hull.handle() 对所有未知路由返回 404，不抛异常，保证 Shell 层总能得到有效响应。

Hull 与 Cell 的关系：Hull 创建 Cell，通过 `cell.step()`、`cell.get()`、`cell.set()`、`cell.ns` 等公开接口操作。Hull 不 import Kernel 或 Core——这些在 Cell 内部。Hull 与 EventLoop 的关系：Hull 创建 EventLoop，通过 FrameHooks 注入回调（before_frame、snapshot、run_compression），EventLoop 不知道 Hull 的存在。

### Skill 信息三层分工

Skill 通过三个通道向 Agent 传递不同粒度的信息：

- **_prompt()（持久层）**：返回 (condition, methodology) tuple，renderer 注入 system prompt。每帧都在，不会被挤出上下文。适用于行为 Skill 的核心规则。
- **guide（手册层）**：SkillBase 属性，Agent 通过 print(name.guide) 按需查阅。内容包含方法签名、参数说明、使用示例。丢失后 re-print，成本 = 1 帧延迟。
- **_signal()（提醒层）**：返回 (title, body) tuple，每帧出现在辅助信号区段。展示当前状态信息，末尾提醒 "print(name.guide) 查看方法"。不包含方法名。

创建规范：description ≤ 15 字只写功能；_signal() 不泄露方法签名；SKILL.md 是唯一包含方法签名的地方；_prompt() 只写行为规则。_prompt() 变更必须走文件（unload → 修改 → reload），不允许运行时动态修改。

Skill 修改策略：Agent 可修改任何 Skill（含内置）。内置 Skill 修改在 vessal 包升级时被覆盖；持久修改应在 skill_paths 创建同名用户 Skill 覆盖。

## Status

### TODO
无。

### Known Issues
- 2026-04-09: hull.py 当前 623 行，超过 500 行惯例，需拆分——建议将 `_load_gate_files`、`_activate_venv`、`_restore_latest_snapshot` 等内部工具函数提取到 `hull_init.py`
- 2026-04-09: Skill 协议字段 `summary` 已重命名为 `description`（SkillBase 类属性 + SKILL.md frontmatter + SkillManager.list() 输出），旧名称不再有效
- 2026-04-12: SkillsManager 已完成改名——name 从 `_meta` 改为 `skills`，方法 `load_skill/unload_skill` 改为 `load/unload`，`query_guide` 已删除，namespace 注入键从 `_meta` 改为 `skills`

### Active
- 2026-04-10: 信号协议从 _signal_output 副作用迁移到 _signal() -> (title, body) tuple 返回值，renderer 统一分隔符包装
- 2026-04-13: hull.toml 未配置 [cell].context_budget 时输出 logger.warning（默认值 128000），提示用户按模型窗口设置
- 2026-04-12: _prompt() 认知协议——Skill 可通过 _prompt() 注入 (condition, methodology) 到系统提示词
- 2026-04-12: Skill UX 规范落地——三层信息分工（_prompt/guide/_signal）写入 SkillBase docstring 和 Hull CONTEXT.md

### Completed
- 2026-04-10: Hull 进程隔离——Hull 在子进程中运行（subprocess.Popen hull_runner.py），Shell 主进程作为网关和监护
- 2026-04-14: SOUL.md 热重载——每帧 mtime 检测，Agent 运行时修改文件后下一帧生效（hull.py _init_prompts + _rewrite_runtime_owned）
- 2026-04-14: 上下文生命周期重构——删除压缩帧机制（event_loop/hull/prompts/tests），渲染裁剪改为物理删帧，Memory skill 增加 drop(n) + 上下文压力信号，hull.toml [cell].compress_threshold 配置（默认 50）
