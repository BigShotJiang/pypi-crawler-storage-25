# Cell

单帧 SORA 执行引擎。封装 Kernel（执行）和 Core（推理），通过 step() 驱动一次 Ping、Core、Pong、Kernel、FrameRecord 循环。

负责：
- 单帧执行编排（step()）：prepare、state_gate、core.run、action_gate、kernel.run
- ActionGate 和 StateGate 的生命周期与模式切换
- namespace 的读写代理（get / set / keys / ns 透传 Kernel）
- 快照序列化与恢复（透传 Kernel）
- 帧感知生成（每帧开始时调用 kernel.prepare() 生成 fresh Ping）

不负责：
- 自动循环（由 Hull EventLoop 处理）
- HTTP 服务（由 Shell 处理）
- LLM 调用（由 Core 处理）
- namespace 执行与帧记录（由 Kernel 处理）
- protocol 数据结构定义（由 protocol.py 定义）

## Constraints

1. 不 import Hull 或 Shell 层代码——依赖方向：Hull 依赖 Cell，Cell 依赖 Core/Kernel，不可反向
2. step() 每次调用恰好产生一个 FrameRecord（由 Kernel 提交），或在 protocol_error 时不提交
3. 所有公开方法必须有完整 docstring 和类型注解
4. cell.py 不超过 300 行

## Design

Cell 运行在 Hull 子进程中。exec() 通过 asyncio.to_thread 在线程池中执行，不阻塞子进程的事件循环（HTTP 请求在帧执行期间仍可处理）。

Cell 存在的理由是提供一个边界清晰的单帧执行单元。Hull 驱动循环，Cell 执行帧——如果没有 Cell 这层，Hull 就要直接操作 Kernel 和 Core 的内部细节，Hull 的职责就从"编排循环"退化成"实现执行逻辑"。Cell 把推理半区（Core）和执行半区（Kernel）胶合在一起，同时屏蔽 Gate 逻辑，是一个边界清晰的胶水层。

Cell 的形状是"有状态的门控执行器"而非"无状态工具函数集合"。它持有 Kernel、Core、ActionGate、StateGate 四个协作对象，以及当前帧的 Ping/Pong 缓存，但本身不保存帧历史——帧历史是 Kernel 的职责。否决了"Hull 直接组合 Kernel + Core"的方案，原因是 Gate 逻辑放在哪里会很尴尬：放 Hull 里增加编排层复杂度，放 Kernel 里破坏 Kernel 的执行纯粹性。

```mermaid
sequenceDiagram
    participant Hull
    participant Cell
    participant StateGate
    participant Core
    participant ActionGate
    participant Kernel

    Hull->>Cell: cell.step()

    Cell->>Kernel: kernel.prepare() → Ping
    Note over Kernel: update_signals + render（每帧 fresh）

    Cell->>StateGate: check(ping.state)
    alt state 被拦截
        StateGate-->>Cell: rejected
        Cell-->>Hull: protocol_error
    end

    Cell->>Core: core.run(ping) → (Pong, prompt_tokens, completion_tokens)
    Cell->>ActionGate: check(pong.action.operation)
    alt action 被拦截
        ActionGate-->>Cell: rejected
        Cell-->>Hull: protocol_error
    end

    Cell->>Kernel: kernel.run(pong)
    Note over Kernel: exec code, commit frame（不再渲染）
    Cell-->>Hull: FrameRecord 已提交到 _frame_log
```

内部关键决策有两个。第一，step() 每帧无条件调用 kernel.prepare() 生成 fresh Ping，确保信号（未读消息、时间戳等）始终是最新的。kernel.run() 只负责 exec + commit，不再预渲染下一帧 Ping。第二，Gate 通过字符串属性暴露给外部（cell.action_gate = "safe"），Hull 无需知道 ActionGate/StateGate 的具体类型，降低了层间耦合。

不变量：每次成功的 step() 调用（protocol_error 为 None）恰好产生一个由 Kernel 提交的 FrameRecord（schema v6，含 ping 字段）；_ping 是当前帧 prepare() 的输出，帧结束后语义失效（下帧重新生成）；_pong 总是指向上一帧的 LLM 输出；_actual_tokens_in/_actual_tokens_out 在 API 返回 usage 时被真实值覆盖，否则保持 None；protocol 异常时 _errors 追加 ErrorRecord("protocol", ...)。

Cell 与 Hull 的关系：Hull 创建 Cell，通过 step()、get()、set()、ns、snapshot()、restore() 等公开接口操作，不访问 Cell 内部对象。Cell 与 Kernel 的关系：Cell 调用 kernel.prepare() 和 kernel.run()，读取 kernel.ns，但不直接操作 Kernel 内部的 Executor 或 Renderer。Cell 与 Core 的关系：Cell 调用 core.run(ping)，将结果 Pong 直接传给 Kernel，Core 是无状态的。

## Status

### TODO
无。

### Known Issues
- 2026-04-09: tests/test_cell.py 当前 581 行，超过 500 行惯例——测试用例密度高导致，暂不拆分

### Active
- 2026-04-09: FrameRecord schema v6 已落地，新增 ping 字段（Ping.to_dict/from_dict），from_dict 兼容 v5。
- 2026-04-13: Core.run() 返回 (Pong, prompt_tokens, completion_tokens) tuple；Cell.step() 用真实 API token 数据覆盖 _context_pct（_actual_tokens_in/_actual_tokens_out）；protocol 异常写入 _errors（ErrorRecord）。
