# tests/test_renderer.py — v4 renderer tests
#
# Coverage:
#   TestRenderConfig      RenderConfig dataclass
#   TestEstimateTokens    token estimation utility function
#   TestSystemPrompt      _render_system_prompt
#   TestRenderSingleFrame project_frame() tested via _render_frame_stream
#   TestRenderFrameStream _render_frame_stream
#   TestRenderAuxiliary   _render_auxiliary (reads from ns["_signal_outputs"])
#   TestRender            render() main function — returns Pong
#   TestRenderPing        render() returning Ping focused tests
#   TestKernelRenderV3    Kernel integration tests (v4 render path)

import pytest

from vessal.ark.shell.hull.cell.kernel.render.renderer import (
    RenderConfig,
    DEFAULT_CONFIG,
    render,
    _render_system_prompt,
    _render_frame_stream,
    _render_auxiliary,
)
from vessal.ark.shell.hull.cell.kernel.render import render
from vessal.ark.shell.hull.cell.protocol import Ping, State
from vessal.ark.util.token_util import estimate_tokens
from vessal.ark.shell.hull.cell.protocol import (
    FrameRecord, Pong, Action, Observation,
    FRAME_SCHEMA_VERSION,
)


# ──────────────────────────────────────────────────────────────────────────────
# Helper construction
# ──────────────────────────────────────────────────────────────────────────────

def make_frame_record(
    number=1,
    operation="x = 1",
    think="",
    expect="",
    stdout="",
    diff="",
    error=None,
    verdict=None,
):
    """Construct a test frame dict (simulating an entry in _frame_log).

    _frame_log now stores dicts (FrameRecord.to_dict() output), not FrameRecord instances.
    """
    return {
        "schema_version": FRAME_SCHEMA_VERSION,
        "number": number,
        "pong": {"think": think, "action": {"operation": operation, "expect": expect}},
        "observation": {
            "stdout": stdout,
            "diff": diff,
            "error": error,
            "verdict": verdict.to_dict() if hasattr(verdict, "to_dict") else verdict,
        },
    }


def bare_ns_v3() -> dict:
    """Return a minimal v4 namespace for test isolation."""
    return {
        "_frame": 0,
        "_frame_log": [],
        "_system_prompt": "",
        "_context_budget": 128000,
        "_max_tokens": 4096,
        "_builtin_names": [],
        "_context_pct": 0,
        "_ns_meta": {},
        "_stdout": "",
        "_error": None,
        "_action": "",
        "_diff": "",
        "_signal_outputs": [],
        "_dropped_frame_count": 0,
    }


@pytest.fixture
def minimal_ns():
    """Minimal namespace fixture for Ping tests."""
    return {
        "_frame": 0,
        "_frame_log": [],
        "_system_prompt": "",
        "_context_budget": 128000,
        "_max_tokens": 4096,
        "_builtin_names": [],
        "_context_pct": 0,
        "_ns_meta": {},
        "_stdout": "",
        "_error": None,
        "_action": "",
        "_diff": "",
        "_signal_outputs": [],
        "_dropped_frame_count": 0,
    }


# ──────────────────────────────────────────────────────────────────────────────
# TestRenderPing — focused tests for render() returning Ping
# ──────────────────────────────────────────────────────────────────────────────


def test_render_returns_ping(minimal_ns):
    """render() returns Ping, no longer returns str."""
    ping = render(minimal_ns)
    assert isinstance(ping, Ping)
    assert isinstance(ping.system_prompt, str)
    assert isinstance(ping.state.frame_stream, str)
    assert isinstance(ping.state.signals, str)


def test_render_ping_system_prompt(minimal_ns):
    minimal_ns["_system_prompt"] = "You are an agent."
    ping = render(minimal_ns)
    assert ping.system_prompt == "You are an agent."


def test_render_ping_frame_stream_empty_when_no_frames(minimal_ns):
    minimal_ns["_frame_log"] = []
    ping = render(minimal_ns)
    assert ping.state.frame_stream == ""


# ──────────────────────────────────────────────────────────────────────────────
# Step 1: TestRenderConfig + TestEstimateTokens
# ──────────────────────────────────────────────────────────────────────────────

class TestRenderConfig:
    def test_default_system_prompt_key(self):
        assert DEFAULT_CONFIG.system_prompt_key == "_system_prompt"

    def test_no_auxiliary_modules_field(self):
        # RenderConfig has no auxiliary_modules field; auxiliary signals are driven by ns["_signal_outputs"]
        assert not hasattr(DEFAULT_CONFIG, "auxiliary_modules")

    def test_default_frame_budget_ratio(self):
        assert DEFAULT_CONFIG.frame_budget_ratio == 0.7

    def test_frozen(self):
        with pytest.raises(Exception):
            DEFAULT_CONFIG.frame_budget_ratio = 0.5

    def test_custom_config(self):
        cfg = RenderConfig(system_prompt_key="_sp", frame_budget_ratio=0.5)
        assert cfg.system_prompt_key == "_sp"
        assert cfg.frame_budget_ratio == 0.5

    def test_two_configs_are_independent(self):
        # two independent config instances do not share state
        c1 = RenderConfig()
        c2 = RenderConfig(frame_budget_ratio=0.5)
        assert c1.frame_budget_ratio != c2.frame_budget_ratio


class TestEstimateTokens:
    def test_empty_string(self):
        assert estimate_tokens("") == 0

    def test_ascii(self):
        # 4 ASCII chars = 4 bytes => 1 token
        assert estimate_tokens("abcd") == 1

    def test_utf8_multibyte(self):
        # each Chinese character is 3 bytes
        text = "中文"  # 6 bytes => 1 token
        assert estimate_tokens(text) == 1

    def test_longer_text(self):
        text = "a" * 400  # 400 bytes => 100 tokens
        assert estimate_tokens(text) == 100

    def test_returns_int(self):
        assert isinstance(estimate_tokens("hello"), int)


# ──────────────────────────────────────────────────────────────────────────────
# Step 2: TestSystemPrompt
# ──────────────────────────────────────────────────────────────────────────────

class TestSystemPrompt:
    def test_empty_ns(self):
        assert _render_system_prompt({}, "_system_prompt") == ""

    def test_missing_key(self):
        ns = {"_other": "value"}
        assert _render_system_prompt(ns, "_system_prompt") == ""

    def test_normal_prompt(self):
        ns = {"_system_prompt": "You are an agent."}
        assert _render_system_prompt(ns, "_system_prompt") == "You are an agent."

    def test_strips_whitespace(self):
        ns = {"_system_prompt": "  hello  \n"}
        assert _render_system_prompt(ns, "_system_prompt") == "hello"

    def test_whitespace_only_returns_empty(self):
        ns = {"_system_prompt": "   \n\t  "}
        assert _render_system_prompt(ns, "_system_prompt") == ""

    def test_custom_key(self):
        ns = {"_my_prompt": "Custom prompt."}
        assert _render_system_prompt(ns, "_my_prompt") == "Custom prompt."

    def test_non_string_coerced(self):
        ns = {"_system_prompt": 42}
        result = _render_system_prompt(ns, "_system_prompt")
        assert result == "42"


# ──────────────────────────────────────────────────────────────────────────────
# Step 3: TestRenderSingleFrame — now via project_frame() through frame stream
# ──────────────────────────────────────────────────────────────────────────────

class TestRenderSingleFrame:
    """Tests for FrameRecord rendering via project_frame()."""

    def test_header_format(self):
        frame = make_frame_record(number=42, operation="x = 1")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "── frame 42 ──" in rendered

    def test_operation_section(self):
        frame = make_frame_record(operation="x = requests.get(...)")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[operation]" in rendered
        assert "x = requests.get(...)" in rendered

    def test_think_section_when_present(self):
        frame = make_frame_record(think="let me think...")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[think]" in rendered
        assert "let me think..." in rendered

    def test_think_section_absent_when_empty(self):
        frame = make_frame_record(think="")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[think]" not in rendered

    def test_stdout_section(self):
        frame = make_frame_record(stdout="142")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[stdout]" in rendered
        assert "142" in rendered

    def test_diff_section(self):
        frame = make_frame_record(diff="+ x = 42")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[diff]" in rendered
        assert "+ x = 42" in rendered

    def test_error_section(self):
        frame = make_frame_record(error="Traceback: NameError")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[error]" in rendered
        assert "Traceback: NameError" in rendered

    def test_no_stdout_section_when_empty(self):
        frame = make_frame_record(stdout="", diff="+ x = 1")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[stdout]" not in rendered

    def test_no_diff_section_when_empty(self):
        frame = make_frame_record(stdout="hello", diff="")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[diff]" not in rendered

    def test_expect_section_when_present(self):
        frame = make_frame_record(expect="assert x == 1")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[expect]" in rendered
        assert "assert x == 1" in rendered

    def test_expect_absent_when_empty(self):
        frame = make_frame_record(expect="")
        ns = {"_frame_log": [frame]}
        rendered = _render_frame_stream(ns, 100000)
        assert "[expect]" not in rendered


# ──────────────────────────────────────────────────────────────────────────────
# Step 4: TestRenderFrameStream + TestCompressFrames
# ──────────────────────────────────────────────────────────────────────────────

class TestRenderFrameStream:
    def test_empty_frame_log(self):
        ns = bare_ns_v3()
        assert _render_frame_stream(ns, 100000) == ""

    def test_header_present(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = [make_frame_record(number=1)]
        result = _render_frame_stream(ns, 100000)
        assert result.startswith("══════ frame stream ══════\n")

    def test_single_frame_content(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = [make_frame_record(number=1, operation="x = 1")]
        result = _render_frame_stream(ns, 100000)
        assert "── frame 1 ──" in result
        assert "x = 1" in result

    def test_multiple_frames(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = [make_frame_record(number=1), make_frame_record(number=2)]
        result = _render_frame_stream(ns, 100000)
        assert "── frame 1 ──" in result
        assert "── frame 2 ──" in result

    def test_within_budget_no_deletion(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = [make_frame_record(number=1, operation="x = 1")]
        result = _render_frame_stream(ns, 100000)
        assert "earlier" not in result

    def test_over_budget_triggers_hard_delete(self):
        # 1 token budget will always trigger hard deletion
        ns = bare_ns_v3()
        ns["_frame_log"] = [
            make_frame_record(number=1, operation="x = 1"),
            make_frame_record(number=2, operation="y = 2"),
        ]
        result = _render_frame_stream(ns, 1)
        # after hard deletion, at least 1 frame is retained (══════ frame stream ══════ header is present)
        assert "══════ frame stream ══════" in result


# ──────────────────────────────────────────────────────────────────────────────
# Step 5: TestRenderAuxiliary — reads from ns["_signal_outputs"]
# ──────────────────────────────────────────────────────────────────────────────

class TestRenderAuxiliary:
    def test_render_auxiliary_reads_signal_outputs(self):
        """_render_auxiliary reads ns["_signal_outputs"] directly without scanning prefix keys."""
        ns = {"_signal_outputs": [("任务", "做某事"), ("系统", "帧: 1")]}
        result = _render_auxiliary(ns)
        assert "══════ 任务 ══════" in result
        assert "做某事" in result
        assert "══════ 系统 ══════" in result

    def test_render_auxiliary_empty_outputs_returns_empty(self):
        """_render_auxiliary returns empty string when _signal_outputs is empty."""
        ns = {"_signal_outputs": []}
        result = _render_auxiliary(ns)
        assert result == ""

    def test_render_auxiliary_missing_outputs_returns_empty(self):
        """_render_auxiliary returns empty string when _signal_outputs is absent from ns."""
        result = _render_auxiliary({})
        assert result == ""

    def test_render_auxiliary_does_not_scan_signal_prefix_keys(self):
        """_render_auxiliary no longer scans _signal_* prefix keys."""
        ns = {
            "_signal_outputs": [],
            "_signal_something": "should not appear",
        }
        result = _render_auxiliary(ns)
        assert result == ""

    def test_render_auxiliary_header_present_when_has_content(self):
        """Auxiliary section includes a header when there is content."""
        ns = {"_signal_outputs": [("信号", "信号内容")]}
        result = _render_auxiliary(ns)
        assert "══════ 信号 ══════" in result
        assert "信号内容" in result


# ──────────────────────────────────────────────────────────────────────────────
# Step 6: TestRender
# ──────────────────────────────────────────────────────────────────────────────

class TestRender:
    def test_returns_string(self):
        ns = bare_ns_v3()
        result = render(ns)
        assert isinstance(result, Ping)

    def test_no_system_prompt_no_frame_stream(self):
        ns = bare_ns_v3()
        ping = render(ns)
        assert ping.state.frame_stream == ""
        assert isinstance(ping, Ping)

    def test_system_prompt_in_output(self):
        ns = bare_ns_v3()
        ns["_system_prompt"] = "You are Vessal."
        ping = render(ns)
        assert "You are Vessal." in ping.system_prompt

    def test_frame_stream_in_output(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = [make_frame_record(number=1, operation="x = 1")]
        ping = render(ns)
        assert "══════ frame stream ══════" in ping.state.frame_stream
        assert "x = 1" in ping.state.frame_stream

    def test_context_pct_written(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = [make_frame_record(number=1, operation="x = 1")]
        render(ns)
        assert "_context_pct" in ns
        assert isinstance(ns["_context_pct"], int)
        assert 0 <= ns["_context_pct"] <= 100

    def test_context_pct_nonzero_when_content(self):
        ns = bare_ns_v3()
        ns["_context_budget"] = 1000
        ns["_max_tokens"] = 100
        ns["_frame_log"] = [make_frame_record(number=1, operation="x = 1")]
        render(ns)
        assert ns["_context_pct"] > 0

    def test_none_config_uses_default(self):
        ns = bare_ns_v3()
        result = render(ns, config=None)
        assert isinstance(result, Ping)

    def test_custom_system_prompt_key(self):
        ns = bare_ns_v3()
        ns["_compression_prompt"] = "I am compression."
        cfg = RenderConfig(system_prompt_key="_compression_prompt")
        ping = render(ns, config=cfg)
        assert "I am compression." in ping.system_prompt

    def test_three_segments_ordering(self):
        ns = bare_ns_v3()
        ns["_system_prompt"] = "System."
        ns["_frame_log"] = [make_frame_record(number=1)]
        ns["_signal_outputs"] = [("辅助", "辅助内容")]
        ping = render(ns)
        # system_prompt, frame_stream, signals are independent fields — order is guaranteed by structure
        assert "System." in ping.system_prompt
        assert "══════ frame stream ══════" in ping.state.frame_stream

    def test_invalid_budget_raises(self):
        ns = bare_ns_v3()
        ns["_context_budget"] = 1000
        ns["_max_tokens"] = 4096
        with pytest.raises(ValueError, match="context_budget.*<=.*max_tokens"):
            render(ns)

    def test_render_side_effects_are_allowlisted(self):
        ns = bare_ns_v3()
        ns_copy = dict(ns)
        render(ns)
        for k, v in ns_copy.items():
            if k in ("_context_pct", "_budget_total", "_dropped_frame_count"):
                continue
            assert ns[k] == v, f"Key {k} was modified unexpectedly"

    def test_render_writes_budget_total_to_ns(self):
        ns = bare_ns_v3()
        ns["_context_budget"] = 10000
        ns["_max_tokens"] = 2000
        render(ns)
        assert ns["_budget_total"] == 8000  # 10000 - 2000

    def test_render_uses_signal_outputs_from_namespace(self):
        """render() reads _signal_outputs from ns to populate ping.signals."""
        ns = bare_ns_v3()
        ns["_signal_outputs"] = [("系统", "帧: 5\nコンテキスト: 0%")]
        ping = render(ns)
        assert "帧: 5" in ping.state.signals


class TestDroppedFrameCount:
    """render() writes ns["_dropped_frame_count"] recording the number of dropped frames."""

    def test_no_frames_dropped_zero(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = [make_frame_record(number=1)]
        render(ns)
        assert ns["_dropped_frame_count"] == 0

    def test_frames_dropped_when_over_budget(self):
        ns = bare_ns_v3()
        # create many frames so the frame stream exceeds budget
        ns["_frame_log"] = [
            make_frame_record(number=i, stdout="x" * 500) for i in range(50)
        ]
        ns["_context_budget"] = 2000
        ns["_max_tokens"] = 500
        render(ns)
        assert ns["_dropped_frame_count"] > 0

    def test_empty_frame_log_zero(self):
        ns = bare_ns_v3()
        ns["_frame_log"] = []
        render(ns)
        assert ns["_dropped_frame_count"] == 0


# ──────────────────────────────────────────────────────────────────────────────
# Step 7: TestKernelRenderV3  (filled after step 8 modifications)
# ──────────────────────────────────────────────────────────────────────────────

class TestKernelRenderV3:
    """Integration tests for Kernel using v4 renderer."""

    def test_kernel_render_returns_string(self):
        from vessal.ark.shell.hull.cell.kernel import Kernel
        k = Kernel()
        result = k.render()
        assert isinstance(result, Ping)

    def test_kernel_exec_operation_returns_exec_result(self):
        from vessal.ark.shell.hull.cell.kernel import Kernel
        from vessal.ark.shell.hull.cell.kernel.executor import ExecResult
        k = Kernel()
        result = k.exec_operation("x = 1", frame_number=1)
        assert isinstance(result, ExecResult)

    def test_frame_log_populated(self):
        from vessal.ark.shell.hull.cell.kernel import Kernel
        k = Kernel()
        k.exec_operation("x = 1", frame_number=1)
        # exec_operation does NOT write _frame_log — that is Cell's job
        assert len(k.ns.get("_frame_log", [])) == 0

    def test_system_prompt_key_used(self):
        from vessal.ark.shell.hull.cell.kernel import Kernel
        k = Kernel()
        k.ns["_system_prompt"] = "Test system prompt"
        ping = k.render()
        assert "Test system prompt" in ping.system_prompt

    def test_no_tracer_arg_in_render(self):
        from vessal.ark.shell.hull.cell.kernel import Kernel
        k = Kernel()
        result = k.render()
        assert isinstance(result, Ping)

    def test_kernel_render_updates_context_pct(self):
        from vessal.ark.shell.hull.cell.kernel import Kernel
        k = Kernel()
        k.render()
        assert "_context_pct" in k.ns
        assert isinstance(k.ns["_context_pct"], int)


# ──────────────────────────────────────────────────────────────────────────────
# Three-segment system prompt assembly tests
# ──────────────────────────────────────────────────────────────────────────────

class TestThreeSegmentAssembly:
    def test_render_three_segment_assembly(self):
        """Three-segment system prompt assembly: kernel protocol + SOUL + skill protocol."""
        ns = bare_ns_v3()
        ns["_system_prompt"] = "你是一个执行引擎。"
        ns["_soul"] = "我是一个友善的助手。"

        class FakeBehaviorSkill:
            name = "reviewer"
            description = "审查"

            def _prompt(self):
                return ("审查代码时", "先看 diff")

        ns["reviewer"] = FakeBehaviorSkill()

        ping = render(ns)
        sp = ping.system_prompt

        # all three segments are present and in order
        assert "你是一个执行引擎" in sp
        assert "══════ SOUL ══════" in sp
        assert "我是一个友善的助手" in sp
        assert "══════ skill protocol ══════" in sp
        assert "── reviewer ──" in sp
        assert "When 审查代码时:" in sp

        # order: kernel protocol before SOUL, SOUL before skill protocol
        kernel_pos = sp.index("你是一个执行引擎")
        soul_pos = sp.index("══════ SOUL ══════")
        protocol_pos = sp.index("══════ skill protocol ══════")
        assert kernel_pos < soul_pos < protocol_pos

    def test_render_no_soul_no_protocols(self):
        """Only kernel protocol when there is no SOUL and no _prompt()."""
        ns = bare_ns_v3()
        ns["_system_prompt"] = "内核协议"
        ns.pop("_soul", None)

        ping = render(ns)
        assert ping.system_prompt == "内核协议"
        assert "══════ SOUL ══════" not in ping.system_prompt
        assert "══════ skill protocol ══════" not in ping.system_prompt

    def test_render_soul_only(self):
        """Two segments when there is SOUL but no _prompt()."""
        ns = bare_ns_v3()
        ns["_system_prompt"] = "内核协议"
        ns["_soul"] = "我的灵魂"

        ping = render(ns)
        assert "══════ SOUL ══════" in ping.system_prompt
        assert "我的灵魂" in ping.system_prompt
        assert "══════ skill protocol ══════" not in ping.system_prompt

    def test_assemble_skill_context_false_skips_soul_and_protocols(self):
        """RenderConfig with assemble_skill_context=False omits SOUL and skill protocol sections."""
        ns = bare_ns_v3()
        ns["_compression_prompt"] = "整理记忆"
        ns["_soul"] = "我的灵魂"

        class FakeSkill:
            name = "some_skill"
            description = "does something"

            def _prompt(self):
                return ("任何时候", "按某种方式做")

        ns["some_skill"] = FakeSkill()

        cfg = RenderConfig(
            system_prompt_key="_compression_prompt",
            assemble_skill_context=False,
        )
        ping = render(ns, config=cfg)
        assert "整理记忆" in ping.system_prompt
        assert "══════ SOUL ══════" not in ping.system_prompt
        assert "══════ skill protocol ══════" not in ping.system_prompt
