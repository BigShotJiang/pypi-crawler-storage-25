# Core

LLM 推理接口。将 Ping 转为 OpenAI 兼容的 messages，调用模型 API，将响应解析为 Pong。

负责：
- 将 Ping（system_prompt + state）渲染为 messages 列表
- OpenAI 兼容 API 调用（含指数退避重试）
- LLM 响应文本解析（提取 think / action / expect 标签）
- 可重试错误与不可重试错误的分类

不负责：
- namespace 维护（由 Kernel 处理）
- 帧历史记录（由 Kernel 处理）
- 门控逻辑（由 Cell 处理）
- 具体模型选择以外的 API 参数硬编码（由调用方通过 api_params 注入）

## Constraints

1. 不 import Hull、Shell 或 Kernel——仅依赖 Cell protocol 层
2. run(ping) 返回 Pong 或抛出异常，不返回 None，不吞异常
3. 可重试错误（APITimeoutError、APIConnectionError、InternalServerError、RateLimitError）执行指数退避；其余错误立即抛出
4. 所有公开方法必须有完整 docstring 和类型注解

## Design

Core 存在的理由是把 LLM 调用从 Kernel 和 Cell 中剥离。如果没有 Core，Cell 既要编排执行又要处理网络重试和响应解析，职责混乱，测试也难以 mock。Core 是推理半区，Kernel 是执行半区，两者通过 Pong 协议对接。

```mermaid
graph LR
    Ping["Ping\n(system_prompt + state)"]
    Msg["messages 列表\n[system, ...frames]"]
    API["OpenAI 兼容 API"]
    Parse["parse_response()"]
    Pong["Pong\n(think + action + expect)"]

    Ping -->|"渲染"| Msg
    Msg -->|"create()"| API
    API -->|"响应文本"| Parse
    Parse --> Pong
```

Core 的形状是"无状态管道"而非"对话管理器"。每次 run() 是独立的 API 调用，不维护多轮对话历史，不缓存响应——历史由 Kernel 渲染为 frame_stream 注入 Ping.state，Core 只看当前帧的感知。这个设计否决了"Core 维护 messages 历史"的方案，原因是状态管理已经在 Kernel.ns 中，双重维护会导致状态分裂。

内部关键决策有两个。第一，模型兼容性通过 api_params 实现：Core 只固定 model（来自 OPENAI_MODEL 环境变量）和 messages，其余参数全部由调用方通过 api_params dict 注入到 create()，不同 Provider 或模型的差异（max_tokens 对比 max_completion_tokens、extra_body 等）完全由外部配置解决。第二，retry.py 和 parser.py 是纯函数模块，独立于 Core 类——is_retryable_error 和 calculate_backoff_seconds 无副作用，parse_response 无网络依赖，均可独立测试。

```mermaid
flowchart TD
    Call["API 调用"]
    Err{异常？}
    Retry{is_retryable_error?}
    Backoff["calculate_backoff_seconds()\n指数退避等待"]
    MaxRetry{超过最大重试次数?}
    Raise["向上抛出异常"]
    Success["返回 Pong"]

    Call --> Err
    Err -->|否| Success
    Err -->|是| Retry
    Retry -->|否，立即失败| Raise
    Retry -->|是| MaxRetry
    MaxRetry -->|是| Raise
    MaxRetry -->|否| Backoff
    Backoff --> Call
```

不变量：run(ping) 要么返回有效的 Pong（含非空 action.operation），要么抛出异常；不存在"成功调用但无法解析"后返回默认值的情况——ParseError 向上传播，由 Cell 处理。重试耗尽后抛出最后一次异常，调用方可区分超时与认证失败。

Core 与 Cell 的关系：Cell 调用 core.run(ping)，将返回的 Pong 传给 Kernel。Core 不知道 Cell 的存在，也不知道 Kernel。Core 与 parser 的关系：core.run() 在成功收到 API 响应后调用 parse_response()，ParseError 向上传播。Core 与 retry 的关系：每次 API 调用异常时，通过 is_retryable_error() 分类，通过 calculate_backoff_seconds() 计算等待时间。

## Status

### TODO
无。

### Known Issues
- 2026-04-09: core/tests/test_core.py 当前 505 行，超过 500 行惯例——测试用例密度高导致，暂不拆分

### Active
无。
