# ARK

Agent Runtime Kit。三层同心架构（Shell → Hull → Cell）的机制底座，提供执行环境但不提供业务策略。

负责：
- 导出核心类型（Cell、Core、Hull）给顶层使用
- 定义并强制执行三层依赖方向
- 为所有层提供共享工具（Util）

不负责：
- HTTP 协议细节（→ `shell/`）
- Agent 编排与帧调度（→ `shell/hull/`）
- 单帧 LLM 推理计算（→ `shell/hull/cell/`）
- 具体 Skill 实现（→ `src/vessal/skills/`）

## Constraints

1. 依赖方向严格单向：Shell → Hull → Cell，任何反向 import 即违规 → `tests/architecture/test_dependency_direction.py`
2. `__init__.py` 只做再导出，不含逻辑
3. Util 可被所有层 import，但 Util 本身不 import Shell / Hull / Cell

## Design

ARK 存在是因为 Agent 运行时的三个关切（HTTP 边界、编排调度、单帧计算）在复杂度和变化频率上差异显著，必须物理隔离。如果三层混在一起，任何一层的变更都会涟漪传播到其他层，且依赖关系无法机械验证。

三层同心结构的选择来自对职责的分析。Shell 处理外部世界的不确定性（HTTP、进程信号、文件系统），需要频繁适配；Hull 管理 Agent 的生命周期和 Skill 注册，变化速率中等；Cell 是纯粹的计算引擎，接口最稳定。同心圆确保内层对外层一无所知——Cell 不知道 Hull 存在，Hull 不知道 Shell 存在，这个性质使得单独测试和替换每一层成为可能。

操作系统层面，Shell 和 Hull 之间存在进程边界：Shell 运行在主进程中（HTTP 网关 + 监护），Hull + Cell + Kernel 运行在子进程中（用 agent 的 .venv/bin/python 启动）。这个边界提供崩溃隔离——LLM 代码中的原生致命错误只杀子进程，Shell 自动重启。详见白皮书 02-architecture.md 第 2.7 节。

```mermaid
graph LR
    subgraph MainProcess["主进程（Shell）"]
        ShellHTTP["HTTP 服务器\n监听用户端口"]
        Monitor["监护线程\n崩溃检测 + 自动重启"]
    end

    subgraph SubProcess["子进程（Hull + Cell + Kernel）"]
        HullHTTP["Hull 内部 HTTP\n监听随机端口"]
        HullCore["Hull — Agent 编排"]
        CellCore["Cell — 单帧执行"]
        KernelCore["Kernel — namespace + exec"]
    end

    Util["util/ — 共享工具（两个进程均可 import）"]

    ShellHTTP -->|"反向代理"| HullHTTP
    Monitor -->|"subprocess.Popen\nhull_runner.py"| SubProcess
    HullCore --> CellCore --> KernelCore
    MainProcess -.-> Util
    SubProcess -.-> Util
```

否决了平铺模块的方案（shell.py + hull.py + cell.py）。平铺结构无法阻止循环依赖，也无法表达层次关系。目录结构即架构文档——看到 `ark/shell/hull/cell/` 的嵌套，依赖方向一目了然。

```mermaid
graph TD
    Shell["ark/shell/"] --> Hull["ark/shell/hull/"]
    Hull --> Cell["ark/shell/hull/cell/"]
    Cell --> Kernel["ark/shell/hull/cell/kernel/"]
    Util["ark/util/"] -.->|"横切，被所有层 import"| Shell
    Util -.-> Hull
    Util -.-> Cell
```

关键决策：Util 作为横切关注点，被所有层共享但不依赖任何层。这避免了在每层重复实现日志、序列化、类型工具等公用设施，同时不破坏依赖方向。

不变量：物理目录结构 `shell/hull/cell/` 编码依赖方向：Shell 包含 Hull，Hull 包含 Cell，外层不可反向依赖内层。架构测试在每次 CI 运行时自动验证此不变量。

与上层的关系：`vessal/__init__.py` 通过本层 `__init__.py` 再导出 Cell、Core、Hull，构成用户可见的公开 API。ARK 内部的目录嵌套对顶层透明。

## Status

### TODO
- [ ] 2026-04-09: 为各子层创建独立的 CONTEXT.md（Shell、Hull、Cell、Util）

### Known Issues
无。

### Active
无。
