# Util

ARK 共享工具层。提供无状态、纯函数的通用工具，供 Cell、Hull、Shell 共同使用。

负责：
- Token 数量估算（token_util）
- 为上层组件提供无依赖的基础计算能力

不负责：
- 可观测性与日志（在 logging/ 子包中）
- 任何有状态逻辑
- 与 Shell、Hull、Cell 的协议细节

## Constraints

1. 不直接 import Shell、Hull、Cell 层代码（依赖方向：上层调用 Util，不可反向）
2. 所有函数必须是纯函数（无副作用、无全局状态）
3. 不引入外部依赖（仅使用标准库）
4. 单文件不超过 300 行
5. 所有公开函数必须有完整 docstring 和类型注解

## Design

Util 存在是为了打破循环依赖。如果 token 估算逻辑直接写在 Hull 里，Cell 就无法复用它而不反向依赖 Hull；写在 Cell 里同理。将无状态工具单独提取到 Util 层，任何上层组件都可以直接 import，依赖方向始终向下。

当前只有 token_util.py 一个模块。它故意不引入 tiktoken 等外部库——精确计数不是 Vessal 的设计目标，预算控制用字节估算足够安全。算法（UTF-8 字节数 / 4）在模块文档字符串中有完整说明，未来需要替换时只需改实现，接口签名保持稳定。

替代方案曾考虑：将 token_util 放入 Cell（因为 Cell 是最先使用它的组件），但这样 Hull 就必须 import Cell 才能做上下文窗口管理，与架构依赖方向冲突。将其放在 Util 是唯一不产生循环依赖的方案。

```mermaid
graph LR
    Shell["Shell 层"] -->|"import"| Util["util/\n（无状态，纯函数）"]
    Hull["Hull 层"] -->|"import"| Util
    Cell["Cell 层"] -->|"import"| Util
```

不变量：Util 的每个函数调用结果只取决于其参数，不依赖外部状态，不产生副作用。这是可测试性和可移植性的基础。

相邻关系：被 Hull 用于上下文窗口预算管理，被 Cell 用于 token 计量。Util 不知道调用方是谁。日志子系统在 logging/ 子包中，各自独立。

## Status

### TODO
无。

### Known Issues
无。

### Active
无。
