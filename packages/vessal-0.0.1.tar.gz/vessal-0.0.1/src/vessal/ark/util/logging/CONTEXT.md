# Logging

ARK 可观测性子系统。提供帧日志写入、读取、HTML 查看器、追踪和终端输出四个独立模块。

负责：
- 帧日志写入（frame_logger.py）— 追加写入单一 frames.jsonl，跨 run 连续
- 帧日志读取（reader.py）— 解析 JSONL 为 FrameRecord 列表
- HTML 查看器（viewer.html）— 浏览器内自包含查看器，支持实时模式和独立文件模式
- 执行阶段追踪（tracer.py）— 阶段进入/退出时间记录
- 终端实时输出（console.py）— 每帧摘要和运行总结

不负责：
- Markdown 报告生成（已删除 reporter.py，由 HTML 查看器替代）
- 日志以外的通用工具（在 util/ 父包中）
- 与 Shell、Hull、Cell 层的协议
- 配置管理（由 Hull 负责）

## Constraints

1. 不直接 import Shell、Hull、Cell 层代码（只允许 import FrameRecord 协议）
2. 持久化格式必须是 JSONL（一条记录一行 JSON），不允许其他格式
3. 所有写入操作在每次 write 后立即 flush，防止崩溃丢失数据
4. 四个模块无横向依赖（frame_logger 不再依赖 reporter），只依赖标准库
5. 所有终端输出写入 sys.stderr，不污染 stdout
6. 所有公开函数必须有完整 docstring 和类型注解
7. 单文件不超过 400 行
8. viewer.html 必须自包含（无外部 CDN 依赖），支持离线使用

## Design

Logging 存在是为了将可观测性关注点从运行时逻辑中分离出来。Hull 的 run() 循环只负责执行帧，不负责理解"发生了什么"。写入（frame_logger）、读取（reader）、HTML 查看（viewer.html）、追踪（tracer）、终端显示（console）四个职责各自独立，可以独立替换。

```mermaid
graph LR
    subgraph logging["util/logging/ — 四个独立模块"]
        FL["frame_logger.py\n写入 frames.jsonl"]
        Reader["reader.py\n解析 JSONL"]
        Tracer["tracer.py\n阶段耗时追踪"]
        Console["console.py\n终端实时输出（stderr）"]
        Viewer["viewer.html\n浏览器自包含查看器"]
    end

    Hull["Hull（调用方）"]
    Browser["浏览器"]
    JSONL["logs/frames.jsonl"]

    Hull -->|"每帧写入"| FL
    FL --> JSONL
    Reader -->|"解析"| JSONL
    Viewer -->|"GET /logs/raw 轮询"| JSONL
    Browser -->|"访问 /logs"| Viewer
    Hull -->|"阶段计时"| Tracer
    Hull -->|"帧摘要"| Console
```

reporter.py 在 v6 中删除，原因：Markdown 报告是单次生成产物，不支持增量查看、实时追踪或过滤。HTML 查看器通过 `/logs` 端点提供两个功能：实时模式（轮询 `/logs/raw?after=N`）和独立文件模式（本地 file:// 拖入 JSONL）。两种模式都在浏览器内运行，无需构建工具，viewer.html 是唯一的产物。

frame_logger.close() 不再生成报告文件（summary.md、detailed.md），只关闭文件句柄。依赖链从"写入→报告"变为"写入→HTTP 查看器"，frame_logger 的 close() 不再有副作用，测试验证更简单。

JSONL 是唯一的持久化格式。每次 write 后立即 flush 是崩溃安全的基础——Agent 执行中途崩溃时，已写入的帧不丢失。所有 run 追加到同一个 `logs/frames.jsonl`，不再为每次 run 创建时间戳子目录。这使得历史日志连续可查，`/logs/raw` 端点始终指向固定路径。

```mermaid
flowchart LR
    Frame["FrameRecord\n（每帧执行结果）"]
    FL["frame_logger.write(record)"]
    JSONL["logs/frames.jsonl\n（append-only）"]
    Flush["立即 flush（崩溃安全）"]

    Frame --> FL --> Flush --> JSONL

    subgraph 查询路径
        Raw["GET /logs/raw?after=N"]
        Viewer["viewer.html（实时模式）"]
        JSONL --> Raw --> Viewer
    end
```

viewer.html 支持 v5（无 ping 字段）和 v6（含 ping 字段）两种格式，向后兼容。调试视图显示完整 Ping+Pong，行为视图只显示 Action+State 信号+Observation，system_prompt 默认折叠。

不变量：所有落盘数据必须是合法 JSONL；每个写入模块在 open() 前调用 write 必须抛出 RuntimeError；终端输出只写 stderr。

## Status

### TODO
无。

### Known Issues
无。

### Active
无。
