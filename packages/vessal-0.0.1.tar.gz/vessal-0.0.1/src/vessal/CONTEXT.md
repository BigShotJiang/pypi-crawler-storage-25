# Vessal

LLM 驱动的 Agent 运行时。实现 SORA 模型（State, Observation, Reasoning, Action），为 Agent 应用提供可托管的执行环境。

负责：
- 公开顶层 API（Cell、Core、Hull）
- CLI 统一入口（`vessal` 命令）
- 导出 ARK 核心类型给外部使用者

不负责：
- HTTP 服务（→ `ark/shell/`）
- Agent 编排逻辑（→ `ark/shell/hull/`）
- 单帧计算（→ `ark/shell/hull/cell/`）
- Skill 具体实现（→ `skills/`）

## Constraints

1. `__init__.py` 只做再导出，不含任何逻辑
2. `cli.py` 只通过 Shell / Hull 公开 API 操作运行时，不直接访问内部模块
3. 依赖方向固定：Shell → Hull → Cell，不可反向 → `tests/architecture/test_dependency_direction.py`

## Design

Vessal 存在的理由是提供一个统一的 Agent 运行时，让应用开发者无需关心帧调度、事件循环、Skill 生命周期等底层机制，直接面向任务目标编写 Skill。如果没有 Vessal，每个 Agent 项目都需要自行解决状态持久化、唤醒调度、LLM 调用管理等问题，导致大量重复且不可复用的基础设施代码。

项目顶层（`src/vessal/`）是整个包的对外门面，而非功能实现层。它只做两件事：再导出 ARK 核心类型，以及提供 CLI 入口。所有真正的运行时逻辑下沉到 ARK 子系统。这个设计选择是刻意的——顶层的稳定性优先于灵活性，外部使用者 `from vessal import Hull` 的路径不因内部重构而改变。

否决了将 CLI 实现直接放在顶层的方案。CLI 的运行时命令（start、stop、send 等）需要访问 Shell 层，开发工具命令（init、skill）需要访问项目脚手架逻辑，两者都不属于顶层职责。当前设计将实现委托给 `ark/shell/cli`，顶层只持有 `main()` 分发入口，保持顶层无业务逻辑的不变量。

不变量：`__init__.py` 的 `__all__` 必须与 ARK 导出保持一致。顶层不引入新的运行时依赖。CLI 子命令的实现全部在 ARK 内部，顶层 `cli.py` 只做懒加载转发。

两个子系统的关系：ARK（`ark/`）是运行时核心，Skills（`skills/`）是能力层。ARK 提供机制，Skills 提供策略。顶层对两者均通过公开接口访问，不深入其内部结构。架构详见 → `references/whitepaper/02-architecture.md`。

```mermaid
graph TD
    subgraph vessal["vessal 包（对外门面）"]
        CLI["cli.py — CLI 入口"]
        API["__init__.py — 再导出公开类型"]
    end

    subgraph ARK["ark/ — 运行时核心"]
        Shell["shell/ — HTTP 边界层（主进程）"]
        Hull["hull/ — Agent 编排层（子进程）"]
        Cell["cell/ — 单帧执行引擎（子进程）"]
        Util["util/ — 共享工具（无状态）"]
    end

    subgraph Skills["skills/ — 能力层"]
        chat["chat"]
        tasks["tasks"]
        memory["memory"]
        pin["pin"]
        heartbeat["heartbeat"]
    end

    CLI --> Shell
    API --> ARK
    Shell --> Hull
    Hull --> Cell
    Shell -.->|"import（工具）"| Util
    Hull -.->|"import（工具）"| Util
    Cell -.->|"import（工具）"| Util
    Hull -->|"加载 Skill"| Skills
```

### 进程架构

Shell 与 Hull 运行在不同操作系统进程中。进程边界画在两者之间，因为 exec() 可能触发原生崩溃，必须隔离 HTTP 服务。

```mermaid
flowchart TB
    外界 -->|"HTTP :8420"| Shell

    subgraph 主进程["主进程 — Shell"]
        Shell["网关 + 监护"]
    end

    Shell -->|"handle(method, path, body)\n反向代理 · 进程边界"| Hull

    subgraph 子进程["子进程 — agent/.venv/bin/python"]
        Hull["Hull 编排器"]
        EL["EventLoop\n事件循环"]
        SM["SkillManager\n发现 + 加载"]
        Cell["Cell\n单帧执行"]
        Kernel["Kernel\nnamespace + exec()"]
        Gate["Gate\nstate/action 审核"]
        SkillSrv["Skill Servers\n持续运行"]

        Hull --> EL
        Hull --> SM
        EL -->|"step()"| Cell
        Cell --> Kernel
        Cell --> Gate
        SM -->|"加载/卸载"| SkillSrv
        SM -->|"cell.set(name, instance)"| Kernel
    end

    Kernel <-->|"Ping / Pong"| LLM["LLM API"]
    Shell -.->|"崩溃 → 重启\nrestore(snapshot)"| 子进程
```

### 数据流：一次 HTTP 请求

外部请求进入后如何流过三层。

```mermaid
sequenceDiagram
    participant W as 外界
    participant S as Shell（主进程）
    participant H as Hull（子进程）
    participant SK as Skill Server

    W->>S: HTTP 请求
    S->>H: handle(method, path, body)

    alt 系统路由（/status, /wake, /stop）
        H-->>S: (status, dict)
    else Skill 路由（/skills/{name}/...）
        H->>SK: 转发给 handler
        SK-->>H: 响应
        H-->>S: (status, dict)
    end

    S-->>W: HTTP 响应
```

### 数据流：一帧执行

事件驱动的帧执行过程。

```mermaid
sequenceDiagram
    participant EL as EventLoop
    participant K as Kernel
    participant G as Gate
    participant C as Core（LLM）
    participant NS as Namespace

    EL->>NS: _wake = reason, _sleeping = False

    loop 帧循环（直到 sleep 或 max_frames）
        K->>NS: 扫描 _signal()
        K->>K: 渲染 Ping
        K->>G: state_gate 检查
        G-->>K: 通过
        K->>C: Ping
        C-->>K: Pong（think + action）
        K->>G: action_gate 检查
        G-->>K: 通过
        K->>NS: exec(code)
        K->>K: 提交帧记录
    end

    NS-->>EL: _sleeping = True
```

### Skill 在系统中的位置

Skill 横跨 Cell 和 Hull 两层，是 Agent 与外界的双面接口。

```mermaid
flowchart LR
    subgraph Cell_Side["Cell 侧 — Namespace 内"]
        SK["Skill 实例\nname · tool · signal"]
    end

    subgraph Hull_Side["Hull 侧 — 帧循环外"]
        SV["Skill Server\nHTTP · 定时器 · UI"]
    end

    Agent["Agent\n(LLM exec 代码)"] -->|"skill.tool()"| SK
    SK -->|"_signal() → Ping"| Agent
    外界 -->|"HTTP /skills/{name}/..."| SV
    SV -->|"写入共享数据"| SK
    SK <-->|"共享 mutable / HTTP / NS 键"| SV
```

### Agent 事件循环状态机

Hull 事件循环在休眠和执行之间切换。

```mermaid
stateDiagram-v2
    [*] --> 休眠

    休眠 --> 唤醒 : 事件到达（消息/定时器/手动）
    唤醒 --> 帧执行 : 设 _wake, 加载提示词

    state 帧执行 {
        [*] --> signal
        signal --> render : 扫描 _signal()
        render --> state_gate
        state_gate --> LLM调用 : 通过
        LLM调用 --> action_gate
        action_gate --> exec : 通过
        exec --> commit : 提交帧记录
        commit --> [*]
    }

    帧执行 --> 帧执行 : _sleeping=False 且未达 max_frames
    帧执行 --> 休眠 : sleep() 或 max_frames
    帧执行 --> 快照 : 崩溃恢复
    快照 --> 休眠 : restore 完成
```

## Status

### TODO
- [ ] 2026-04-09: 为 `__init__.py` 和 `cli.py` 补全 Formalin 标注规范

### Known Issues
无。

### Active
无。
