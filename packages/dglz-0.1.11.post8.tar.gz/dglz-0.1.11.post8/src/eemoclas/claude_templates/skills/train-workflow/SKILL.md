---
name: train-workflow
description: |
  Master workflow specification for dglztr agent.
  Defines the 5-step training cycle (Plan→Config→Train→Review→Archive),
  stage targets, metrics priority, error handling, and k-fold rules.
allowed-tools:
  - bash
  - Agent
metadata:
  language: zh-CN
---

# DGLZ Training Workflow

## 核心目标

| 阶段 | 模型 | 目标 acc | 目标 AUC |
|------|------|-------------------|---------|
| Stage 1 | subject_state | ≥ 95% | ≥ 97% |
| Stage 2 | normal_emotion + depression_emotion | ≥ 95% | ≥ 97% |

**指标优先级**: accuracy > AUC > macro_f1 (USER MANDATED)

## 5 步训练循环

### Step 1: Plan（用户交互）

1. 用户指定阶段: `stage1` 或 `stage2`
2. 读取 dglzvr 上轮分析报告（如有）
3. 创建 TSV 实验计划（最多 3 个配置）
4. **等待用户确认**

TSV 格式（6 列）:
```
exp_name	task_conf	model_conf	train_conf	split_conf	aug_conf
```

每列 JSON 内容合并到 `models.{target}.{section}` 的内部键。

Stage 1 目标模型: `subject_state`
Stage 2 目标模型: `normal_emotion` + `depression_emotion`（每个配置生成两份）

### Step 2: Config（自动）

1. 调用 configs-creator skill
   ```bash
   python .claude/skills/configs-creator/scripts/configs_creator.py \
       --base configs/base/train_full.yaml \
       --input .agent/dglztr/exp_conf_tsv/batch{N}.tsv \
       --name batch{N} --stage {stage} --output configs/
   ```
2. 配置失败 → 记录到 `.agent/dglztr/failed/configs/`，用有效配置继续
3. 生成 batch TXT 文件供 configs-runner 使用

### Step 3: Train（自动）

1. 调用 configs-runner skill
   ```bash
   python .claude/skills/configs-runner/scripts/configs_runner.py \
       --file .agent/dglztr/exp_conf_tsv/batch{N}.txt \
       --verbose
   ```
2. Bash 命令超时: **259200ms** (3天)
3. 串行执行，最多 3 个配置
4. 训练失败 → 跳过，继续下一个

**关键**: configs-runner 自动传递 `--models {target}` 和 `--experiment-name {exp_name}` 给 `eemo train`。

### Step 4: Review（自动）

1. 调用 exp-review skill
2. get-results 提取指标:
   ```bash
   python .claude/skills/get-results/scripts/get_results.py \
       --experiments-dir experiments \
       --exp-names {names} --stage {stage}
   ```
3. 读取实验配置（用于参数-性能关联）
4. 调用 dglzvr sub-agent（通过 Agent tool）进行深度分析
5. dglztr 对 dglzvr 建议做 critical review
6. 保存报告到 `.agent/dglzvr/reviews/batch{N}_review.md`

**K-fold 分析规则**:
- Holdout: 直接使用单值指标
- K-fold: 使用聚合 mean ± std；比较各折稳定性
- 不可直接对比 k-fold mean 与 holdout 单值
- 最佳折指标同时纳入目标评估

**目标评估**: 检查是否达到阶段目标指标。

### Step 5: Archive（自动）

1. 调用 move-exp skill:
   ```bash
   python .claude/skills/move-exp/scripts/move_exp.py \
       --batch {N} --stage {stage} --exp-names {names}
   ```
2. 先 dry-run 预览，确认后实际归档
3. 更新 `history_batch.json`
4. 更新 `current_batch.json` 的 `current_best` 和 `stage_completion`
5. 未达标 → 回到 Step 1
6. 达标 → 报告用户，询问是否进入下一阶段

## 约束

- GPU 12GB → 串行训练，不可并行
- 每批最多 3 个配置
- 超时 259200s (3天)
- `history_batch.json` 只追加不删除
- K-fold 和 holdout 分开追踪
- 阶段门控: Stage 2 需 Stage 1 达标（用户可覆盖）

## 错误处理

- 配置生成失败: 记录失败，用有效配置继续
- 训练超时: Kill 进程，记录，继续
- 训练崩溃: 记录错误，继续
- dglzvr 分析失败: dglztr 独立分析日志
- 全部失败: 报告所有错误，回到 Step 1
