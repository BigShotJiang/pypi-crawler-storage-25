import json
import threading
import time

import pytest

from tinysdk import TinyLogger
from tinysdk.profiler import _Stats, TinyProfiler


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_profiler(monkeypatch: pytest.MonkeyPatch) -> TinyProfiler:
  """Create a TinyProfiler backed by a DEBUG-level TinyLogger.

  Must be called inside the test body (after capsys is active) so the
  logger's StreamHandler references capsys's captured sys.stdout.
  """
  monkeypatch.setenv("LOG_LEVEL", "DEBUG")
  return TinyProfiler(TinyLogger())


def _parse_events(capsys: pytest.CaptureFixture) -> list:
  out = capsys.readouterr().out.strip()
  if not out:
    return []
  return [json.loads(line) for line in out.split("\n") if line]


# ---------------------------------------------------------------------------
# _Stats
# ---------------------------------------------------------------------------


class TestStats:
  def test_initial_values(self):
    s = _Stats()
    assert s.call_count == 0
    assert s.error_count == 0
    assert s.total_ms == 0.0
    assert s.max_ms == 0.0
    assert s.avg_ms == 0.0

  def test_record_success(self):
    s = _Stats()
    s.record(100.0, error=False)
    assert s.call_count == 1
    assert s.error_count == 0
    assert s.total_ms == 100.0
    assert s.min_ms == 100.0
    assert s.max_ms == 100.0
    assert s.avg_ms == 100.0

  def test_record_error(self):
    s = _Stats()
    s.record(50.0, error=True)
    assert s.call_count == 1
    assert s.error_count == 1

  def test_min_max_avg_across_multiple_records(self):
    s = _Stats()
    s.record(100.0, error=False)
    s.record(200.0, error=False)
    s.record(300.0, error=True)
    assert s.min_ms == 100.0
    assert s.max_ms == 300.0
    assert s.avg_ms == 200.0
    assert s.call_count == 3
    assert s.error_count == 1

  def test_reset_clears_all_fields(self):
    s = _Stats()
    s.record(100.0, error=True)
    s.reset()
    assert s.call_count == 0
    assert s.error_count == 0
    assert s.total_ms == 0.0
    assert s.max_ms == 0.0
    assert s.avg_ms == 0.0

  def test_avg_ms_zero_when_no_calls(self):
    assert _Stats().avg_ms == 0.0

  def test_record_after_reset_works_correctly(self):
    s = _Stats()
    s.record(500.0, error=False)
    s.reset()
    s.record(50.0, error=False)
    assert s.min_ms == 50.0
    assert s.max_ms == 50.0
    assert s.avg_ms == 50.0
    assert s.call_count == 1


# ---------------------------------------------------------------------------
# Per-call PROFILE events
# ---------------------------------------------------------------------------


class TestPerCallEvents:
  def test_profile_event_emitted_on_context_manager_exit(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    with profiler.trace("my_op"):
      pass
    events = _parse_events(capsys)
    assert len(events) == 1
    assert events[0]["event_type"] == "PROFILE"
    assert events[0]["level"] == "DEBUG"
    assert events[0]["message"] == "my_op"

  def test_profile_event_context_fields(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    with profiler.trace("my_op"):
      pass
    ctx = _parse_events(capsys)[0]["context"]
    assert ctx["trace_name"] == "my_op"
    assert isinstance(ctx["duration_ms"], float)
    assert ctx["duration_ms"] >= 0.0
    assert ctx["success"] is True

  def test_success_false_on_exception(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    with pytest.raises(ValueError):
      with profiler.trace("failing_op"):
        raise ValueError("boom")
    ctx = _parse_events(capsys)[0]["context"]
    assert ctx["success"] is False
    assert ctx["trace_name"] == "failing_op"

  def test_exception_propagates(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    with pytest.raises(RuntimeError, match="propagated"):
      with profiler.trace("op"):
        raise RuntimeError("propagated")

  def test_context_manager_and_decorator_produce_equivalent_events(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    with profiler.trace("op"):
      pass

    @profiler.trace("op")
    def do_op():
      pass

    do_op()

    events = _parse_events(capsys)
    assert len(events) == 2
    assert events[0]["event_type"] == events[1]["event_type"] == "PROFILE"
    assert events[0]["context"]["trace_name"] == events[1]["context"]["trace_name"] == "op"
    assert events[0]["context"]["success"] == events[1]["context"]["success"] is True

  def test_document_id_in_context_when_provided(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    with profiler.trace("op", document_id="doc-42"):
      pass
    ctx = _parse_events(capsys)[0]["context"]
    assert ctx["document_id"] == "doc-42"

  def test_document_id_absent_from_context_when_not_provided(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    with profiler.trace("op"):
      pass
    ctx = _parse_events(capsys)[0]["context"]
    assert "document_id" not in ctx

  def test_bare_decorator_uses_function_name(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)

    @profiler.trace
    def my_function():
      pass

    my_function()
    ctx = _parse_events(capsys)[0]["context"]
    assert ctx["trace_name"] == "my_function"

  def test_named_decorator_uses_explicit_name(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)

    @profiler.trace("custom_name")
    def some_function():
      pass

    some_function()
    ctx = _parse_events(capsys)[0]["context"]
    assert ctx["trace_name"] == "custom_name"

  def test_decorator_preserves_return_value(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)

    @profiler.trace("op")
    def add(a, b):
      return a + b

    assert add(2, 3) == 5

  def test_decorator_preserves_function_name(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)

    @profiler.trace("op")
    def my_func():
      pass

    assert my_func.__name__ == "my_func"


# ---------------------------------------------------------------------------
# PROFILE_SUMMARY events
# ---------------------------------------------------------------------------


class TestSummary:
  def test_summary_event_type_and_level(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler._record("op", 100.0, error=False)
    profiler._emit_summary()
    events = _parse_events(capsys)
    assert len(events) == 1
    assert events[0]["event_type"] == "PROFILE_SUMMARY"
    assert events[0]["level"] == "INFO"
    assert events[0]["message"] == "op"

  def test_summary_stats_correct(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler._record("op", 100.0, error=False)
    profiler._record("op", 200.0, error=False)
    profiler._record("op", 300.0, error=True)
    profiler._emit_summary()
    ctx = _parse_events(capsys)[0]["context"]
    assert ctx["trace_name"] == "op"
    assert ctx["call_count"] == 3
    assert ctx["error_count"] == 1
    assert ctx["duration_ms"]["min"] == 100.0
    assert ctx["duration_ms"]["avg"] == 200.0
    assert ctx["duration_ms"]["max"] == 300.0

  def test_stats_reset_after_flush(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler._record("op", 100.0, error=False)
    profiler._emit_summary()
    capsys.readouterr()  # discard first flush output

    profiler._emit_summary()  # second flush — nothing has run since reset
    assert capsys.readouterr().out.strip() == ""

  def test_names_with_no_calls_skipped_in_summary(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler._record("op_a", 100.0, error=False)
    with profiler._lock:
      profiler._stats["op_b"] = _Stats()  # zero calls

    profiler._emit_summary()
    events = _parse_events(capsys)
    trace_names = [e["context"]["trace_name"] for e in events if e["event_type"] == "PROFILE_SUMMARY"]
    assert "op_a" in trace_names
    assert "op_b" not in trace_names

  def test_summary_emits_one_event_per_traced_name(self, capsys, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler._record("alpha", 10.0, error=False)
    profiler._record("beta", 20.0, error=False)
    profiler._record("alpha", 30.0, error=False)
    profiler._emit_summary()
    events = [e for e in _parse_events(capsys) if e["event_type"] == "PROFILE_SUMMARY"]
    assert len(events) == 2
    names = {e["context"]["trace_name"] for e in events}
    assert names == {"alpha", "beta"}


# ---------------------------------------------------------------------------
# Lifecycle: start / stop
# ---------------------------------------------------------------------------


class TestLifecycle:
  def test_start_launches_daemon_thread(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler.start()
    assert profiler._thread is not None
    assert profiler._thread.is_alive()
    assert profiler._thread.daemon is True
    profiler.stop()

  def test_stop_joins_thread(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler.start()
    thread = profiler._thread
    profiler.stop()
    assert not thread.is_alive()
    assert profiler._thread is None

  def test_start_idempotent(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler.start()
    first_thread = profiler._thread
    profiler.start()
    assert profiler._thread is first_thread
    profiler.stop()

  def test_stop_before_start_is_safe(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler.stop()  # must not raise

  def test_restart_after_stop(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    profiler.start()
    first_thread = profiler._thread
    profiler.stop()
    profiler.start()
    assert profiler._thread is not first_thread
    assert profiler._thread.is_alive()
    profiler.stop()

  def test_profiler_interval_env_var_triggers_summary(self, capsys, monkeypatch):
    monkeypatch.setenv("PROFILER_INTERVAL", "1")
    monkeypatch.setenv("LOG_LEVEL", "INFO")
    profiler = TinyProfiler(TinyLogger())
    profiler._record("timed_op", 50.0, error=False)
    profiler.start()
    time.sleep(1.5)
    profiler.stop()
    events = [e for e in _parse_events(capsys) if e["event_type"] == "PROFILE_SUMMARY"]
    assert len(events) >= 1
    assert events[0]["context"]["trace_name"] == "timed_op"


# ---------------------------------------------------------------------------
# Thread safety
# ---------------------------------------------------------------------------


class TestThreadSafety:
  def test_concurrent_traces_do_not_corrupt_stats(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    errors: list = []

    def do_traces():
      try:
        for _ in range(50):
          with profiler.trace("concurrent_op"):
            pass
      except Exception as e:
        errors.append(e)

    threads = [threading.Thread(target=do_traces) for _ in range(10)]
    for t in threads:
      t.start()
    for t in threads:
      t.join()

    assert not errors
    with profiler._lock:
      assert profiler._stats["concurrent_op"].call_count == 500

  def test_summary_and_record_concurrent(self, monkeypatch):
    profiler = _make_profiler(monkeypatch)
    errors: list = []

    def record_loop():
      try:
        for _ in range(100):
          profiler._record("op", 10.0, error=False)
      except Exception as e:
        errors.append(e)

    def summary_loop():
      try:
        for _ in range(10):
          profiler._emit_summary()
      except Exception as e:
        errors.append(e)

    threads = [threading.Thread(target=record_loop) for _ in range(5)]
    threads += [threading.Thread(target=summary_loop) for _ in range(2)]
    for t in threads:
      t.start()
    for t in threads:
      t.join()

    assert not errors
