"""Tests for TinyDBService."""

import json
import mongomock
import pytest
from bson.objectid import ObjectId
from unittest.mock import patch, MagicMock

from tinysdk import TinyDBService
from tinysdk.collections import Collection
from tinysdk.models import compute_aggregated_status

# Use a plain collection without unique-index constraints for bundle tests.
# The bundle logic is collection-agnostic; real DOCUMENT indexes are tested separately.
DOCS = "bundle_test_docs"
BUNDLES = Collection.DOCUMENT_BUNDLES.value


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------


def test_tinydbservice_import():
  assert TinyDBService is not None


def test_tinydbservice_initialization_with_params(mongodb_credentials):
  db = TinyDBService(**mongodb_credentials)
  assert db.db_link == mongodb_credentials["db_link"]
  assert db.db_name == mongodb_credentials["db_name"]


def test_tinydbservice_initialization_without_params_fails():
  with pytest.raises(AssertionError):
    TinyDBService()


def test_tinydbservice_has_crud_methods():
  for method in ("create", "read", "update", "delete", "upsert", "exists", "count"):
    assert hasattr(TinyDBService, method)


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


def test_create_single_doc_returns_list_with_one_string_id(mongo_db):
  """create() must return a list even for a single document."""
  ids = mongo_db.create("users", [{"name": "Alice", "email": "alice@example.com"}])
  assert isinstance(ids, list)
  assert len(ids) == 1
  assert isinstance(ids[0], str)
  assert len(ids[0]) == 24


def test_create_multiple_docs_returns_list_of_string_ids(mongo_db):
  ids = mongo_db.create("multi_test", [{"name": "alpha"}, {"name": "beta"}, {"name": "gamma"}])
  assert isinstance(ids, list)
  assert len(ids) == 3
  assert all(isinstance(i, str) for i in ids)


def test_create_preserves_insertion_order(mongo_db):
  """create() must return IDs in the same order as the input documents."""
  docs = [{"name": "doc1"}, {"name": "doc2"}, {"name": "doc3"}]
  ids = mongo_db.create("order_test", docs)
  results = mongo_db.read("order_test", filter={"_id": {"$in": ids}})
  name_by_id = {r["_id"]: r["name"] for r in results}
  assert [name_by_id[id] for id in ids] == ["doc1", "doc2", "doc3"]


def test_create_result_is_json_serializable(mongo_db):
  ids = mongo_db.create("multi_test", [{"name": "a"}, {"name": "b"}])
  data = json.loads(json.dumps(ids))
  assert len(data) == 2


def test_create_retries_on_transient_mongodb_error():
  """create() must retry on transient MongoDB errors."""
  from pymongo.errors import ServerSelectionTimeoutError

  fake_id = ObjectId()
  with patch("tinysdk.database.MongoClient") as MockClient:
    mock_col = MagicMock()
    MockClient.return_value.get_database.return_value.get_collection.return_value = mock_col
    mock_col.insert_many.side_effect = [
      ServerSelectionTimeoutError("primary not found"),
      MagicMock(inserted_ids=[fake_id]),
    ]
    db = TinyDBService(db_link="mongodb://test", db_name="test")
    with patch("time.sleep"):
      ids = db.create("users", [{"name": "John"}])

  assert ids == [str(fake_id)]
  assert mock_col.insert_many.call_count == 2


# ---------------------------------------------------------------------------
# read
# ---------------------------------------------------------------------------


def test_read_returns_list(mongo_db):
  mongo_db.create("users", [{"name": "Bob"}])
  results = mongo_db.read("users")
  assert isinstance(results, list)
  assert len(results) >= 1


def test_read_with_filter(mongo_db):
  mongo_db.create("filter_test", [{"name": "Carol", "role": "admin"}, {"name": "Dave", "role": "user"}])
  results = mongo_db.read("filter_test", filter={"role": "admin"})
  assert all(r["role"] == "admin" for r in results)


def test_read_with_sort(mongo_db):
  mongo_db.create("sort_test", [{"score": 10}, {"score": 5}, {"score": 20}])
  results = mongo_db.read("sort_test", sort=("score", 1))
  scores = [r["score"] for r in results]
  assert scores == sorted(scores)


def test_read_with_pagination(mongo_db):
  mongo_db.create("paging_test", [{"i": i} for i in range(5)])
  page0 = mongo_db.read("paging_test", page=0, limit=2)
  page1 = mongo_db.read("paging_test", page=1, limit=2)
  assert len(page0) == 2
  assert len(page1) == 2
  assert page0 != page1


def test_read_does_not_mutate_caller_filter_dict(mongo_db):
  doc_id = mongo_db.create("mut_test", [{"val": "hello"}])[0]
  caller_filter = {"_id": doc_id}
  mongo_db.read("mut_test", filter=caller_filter)
  assert isinstance(caller_filter["_id"], str)


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


def test_update_returns_modified_count(mongo_db):
  mongo_db.create("update_test", [{"name": "Eve", "status": "pending"}, {"name": "Frank", "status": "pending"}])
  count = mongo_db.update("update_test", {"status": "pending"}, {"$set": {"status": "done"}})
  assert count == 2


def test_update_returns_zero_when_no_match(mongo_db):
  count = mongo_db.update("update_test", {"name": "NoSuchUser"}, {"$set": {"x": 1}})
  assert count == 0


def test_update_does_not_mutate_caller_filter_dict(mongo_db):
  doc_id = mongo_db.create("mut_test", [{"val": "hello"}])[0]
  caller_filter = {"_id": doc_id}
  mongo_db.update("mut_test", caller_filter, {"$set": {"val": "world"}})
  assert isinstance(caller_filter["_id"], str)


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


def test_delete_returns_deleted_count(mongo_db):
  mongo_db.create("del_test", [{"name": "to_delete"}, {"name": "to_delete"}])
  count = mongo_db.delete("del_test", {"name": "to_delete"})
  assert count == 2


def test_delete_by_string_id(mongo_db):
  doc_id = mongo_db.create("del_test", [{"name": "by_id"}])[0]
  assert mongo_db.exists("del_test", {"_id": doc_id})
  mongo_db.delete("del_test", {"_id": doc_id})
  assert not mongo_db.exists("del_test", {"_id": doc_id})


def test_delete_returns_zero_when_no_match(mongo_db):
  count = mongo_db.delete("del_test", {"name": "ghost"})
  assert count == 0


# ---------------------------------------------------------------------------
# exists / count
# ---------------------------------------------------------------------------


def test_exists_returns_true_when_document_found(mongo_db):
  mongo_db.create("ex_test", [{"email": "x@y.com"}])
  assert mongo_db.exists("ex_test", {"email": "x@y.com"})


def test_exists_returns_false_when_no_document(mongo_db):
  assert not mongo_db.exists("ex_test", {"email": "nobody@nowhere.com"})


def test_count_returns_correct_number(mongo_db):
  mongo_db.create("count_test", [{"role": "admin"}, {"role": "admin"}, {"role": "user"}])
  assert mongo_db.count("count_test", {"role": "admin"}) == 2


def test_count_returns_zero_when_no_match(mongo_db):
  assert mongo_db.count("count_test", {"role": "ghost"}) == 0


# ---------------------------------------------------------------------------
# upsert
# ---------------------------------------------------------------------------


def test_upsert_inserts_when_no_match(mongo_db):
  is_new = mongo_db.upsert(
    "upsert_test",
    {"name": "Alice"},
    {"$setOnInsert": {"role": "admin"}, "$set": {"lastSeen": "today"}},
  )
  assert is_new is True
  docs = mongo_db.read("upsert_test", {"name": "Alice"})
  assert len(docs) == 1
  assert docs[0]["role"] == "admin"
  assert docs[0]["lastSeen"] == "today"


def test_upsert_updates_when_match_exists(mongo_db):
  mongo_db.create("upsert_test", [{"name": "Bob", "role": "user", "score": 10}])
  is_new = mongo_db.upsert(
    "upsert_test",
    {"name": "Bob"},
    {"$setOnInsert": {"role": "should_not_apply"}, "$set": {"score": 20}},
  )
  assert is_new is False
  docs = mongo_db.read("upsert_test", {"name": "Bob"})
  assert docs[0]["role"] == "user"
  assert docs[0]["score"] == 20


def test_upsert_set_on_insert_only_applies_on_insert(mongo_db):
  for i, vals in enumerate([("t1", "A"), ("t2", "B")]):
    mongo_db.upsert(
      "upsert_test",
      {"docId": "doc1"},
      {"$setOnInsert": {"createdAt": vals[0], "category": vals[1]}, "$set": {f"modelTrace.m{i + 1}": {"conf": 0.9 - i * 0.1}}},
    )
  docs = mongo_db.read("upsert_test", {"docId": "doc1"})
  assert docs[0]["createdAt"] == "t1"
  assert docs[0]["category"] == "A"
  assert docs[0]["modelTrace"]["m1"]["conf"] == pytest.approx(0.9)
  assert docs[0]["modelTrace"]["m2"]["conf"] == pytest.approx(0.8)


def test_upsert_with_push_operator(mongo_db):
  for fname in ("file1.json", "file2.json"):
    mongo_db.upsert(
      "upsert_test",
      {"docId": "doc2"},
      {"$setOnInsert": {"bucketName": "results"}, "$push": {"fileNames": fname}},
    )
  docs = mongo_db.read("upsert_test", {"docId": "doc2"})
  assert docs[0]["bucketName"] == "results"
  assert docs[0]["fileNames"] == ["file1.json", "file2.json"]


def test_upsert_with_string_id_filter(mongo_db):
  doc_id = mongo_db.create("upsert_test", [{"val": "original"}])[0]
  is_new = mongo_db.upsert("upsert_test", {"_id": doc_id}, {"$set": {"val": "updated"}})
  assert is_new is False
  assert mongo_db.read("upsert_test", {"_id": doc_id})[0]["val"] == "updated"


def test_upsert_with_inc_operator(mongo_db):
  for _ in range(3):
    mongo_db.upsert("upsert_test", {"docId": "counter"}, {"$inc": {"views": 1}})
  assert mongo_db.read("upsert_test", {"docId": "counter"})[0]["views"] == 3


def test_upsert_does_not_mutate_caller_filter_dict(mongo_db):
  doc_id = mongo_db.create("mut_test", [{"val": "hello"}])[0]
  caller_filter = {"_id": doc_id}
  mongo_db.upsert("mut_test", caller_filter, {"$set": {"val": "world"}})
  assert isinstance(caller_filter["_id"], str)


def test_upsert_retries_on_transient_mongodb_error():
  from pymongo.errors import ServerSelectionTimeoutError

  with patch("tinysdk.database.MongoClient") as MockClient:
    mock_col = MagicMock()
    MockClient.return_value.get_database.return_value.get_collection.return_value = mock_col
    mock_col.update_one.side_effect = [
      ServerSelectionTimeoutError("primary not found"),
      MagicMock(upserted_id=ObjectId()),
    ]
    db = TinyDBService(db_link="mongodb://test", db_name="test")
    with patch("time.sleep"):
      result = db.upsert("test_col", {"name": "retry"}, {"$set": {"val": 1}})

  assert result is True
  assert mock_col.update_one.call_count == 2


# ---------------------------------------------------------------------------
# Infrastructure
# ---------------------------------------------------------------------------


def test_collection_str_returns_value():
  """str(Collection.X) must return the collection name string, not 'Collection.X'."""
  from tinysdk.collections import Collection

  assert str(Collection.DOCUMENT) == "document"
  assert str(Collection.DOCUMENT_BUNDLES) == "documentBundles"
  assert str(Collection.USERS) == "users"


def test_collection_value_still_works():
  """Collection.X.value must remain accessible and unchanged."""
  from tinysdk.collections import Collection

  assert Collection.DOCUMENT.value == "document"
  assert Collection.DOCUMENT_BUNDLES.value == "documentBundles"


def test_init_index_with_bundle_initializes_both_collections(mongo_db):
  """_init_index with bundle=True must initialize both the collection and DOCUMENT_BUNDLES."""
  mongo_db._init_index("some_collection", bundle=True)
  assert "some_collection" in mongo_db._initialized_collections
  assert Collection.DOCUMENT_BUNDLES.value in mongo_db._initialized_collections


def test_index_created_only_once_per_collection(mongo_db):
  """Index creation must run once per collection lifetime, not on every CRUD call."""
  mongo_db.index_config["perf_test"] = [[("field", 1), {"unique": True}]]
  with patch.object(mongomock.collection.Collection, "create_index") as mock_ci:
    for i in range(3):
      mongo_db.create("perf_test", [{"field": f"val_{i}"}])
    assert mock_ci.call_count == 1


def test_close_releases_connection_pool():
  with patch("tinysdk.database.MongoClient") as MockClient:
    mock_client = MagicMock()
    MockClient.return_value = mock_client
    mock_client.get_database.return_value = MagicMock()
    db = TinyDBService(db_link="mongodb://test", db_name="test")
    db.close()
  mock_client.close.assert_called_once()


def test_connection_timeout_passed_to_mongo_client():
  with patch("tinysdk.database.MongoClient") as MockClient:
    MockClient.return_value.get_database.return_value = MagicMock()
    TinyDBService(db_link="mongodb://test", db_name="test", connection_timeout_ms=3000)
  MockClient.assert_called_once_with("mongodb://test", serverSelectionTimeoutMS=3000)


def test_connection_timeout_defaults_to_5000():
  with patch("tinysdk.database.MongoClient") as MockClient:
    MockClient.return_value.get_database.return_value = MagicMock()
    TinyDBService(db_link="mongodb://test", db_name="test")
  MockClient.assert_called_once_with("mongodb://test", serverSelectionTimeoutMS=5000)


# ---------------------------------------------------------------------------
# Bundle — create
# ---------------------------------------------------------------------------


def test_create_bundle_creates_bundle_document(mongo_db):
  """create() with bundle=True must create an entry in DOCUMENT_BUNDLES."""
  ids = mongo_db.create(DOCS, [{"name": "doc1"}], bundle=True)
  bundles = mongo_db.read(BUNDLES)
  assert len(bundles) == 1
  assert bundles[0]["bundleIds"] == ids


def test_create_bundle_groups_all_doc_ids(mongo_db):
  """create() with multiple docs and bundle=True must group all IDs in one bundle."""
  ids = mongo_db.create(DOCS, [{"name": "doc1"}, {"name": "doc2"}, {"name": "doc3"}], bundle=True)
  bundles = mongo_db.read(BUNDLES)
  assert len(bundles) == 1
  assert set(bundles[0]["bundleIds"]) == set(ids)


def test_create_bundle_system_generated_ids_starts_empty(mongo_db):
  """systemGeneratedDocumentIds must be an empty list on bundle creation."""
  mongo_db.create(DOCS, [{"name": "doc1"}], bundle=True)
  bundle = mongo_db.read(BUNDLES)[0]
  assert bundle["systemGeneratedDocumentIds"] == []


def test_create_without_bundle_does_not_create_bundle_document(mongo_db):
  """create() with bundle=False (default) must not create any bundle entry."""
  mongo_db.create(DOCS, [{"name": "doc1"}])
  assert mongo_db.read(BUNDLES) == []


def test_create_bundle_returns_only_document_ids(mongo_db):
  """create() with bundle=True must return document IDs, not the bundle ID."""
  ids = mongo_db.create(DOCS, [{"name": "doc1"}, {"name": "doc2"}], bundle=True)
  docs = mongo_db.read(DOCS)
  doc_ids = {d["_id"] for d in docs}
  assert set(ids) == doc_ids


def test_create_each_bundle_is_independent(mongo_db):
  """Two separate create() calls with bundle=True must produce two separate bundles."""
  mongo_db.create(DOCS, [{"name": "a"}], bundle=True)
  mongo_db.create(DOCS, [{"name": "b"}], bundle=True)
  assert len(mongo_db.read(BUNDLES)) == 2


# ---------------------------------------------------------------------------
# Bundle — read
# ---------------------------------------------------------------------------


def test_read_bundle_returns_all_docs_in_bundle(mongo_db):
  """read() with bundle=True must return all documents that share a bundle."""
  ids = mongo_db.create(DOCS, [{"name": "x"}, {"name": "y"}, {"name": "z"}], bundle=True)
  results = mongo_db.read(DOCS, filter={"_id": ids[0]}, bundle=True)
  result_ids = {r["_id"] for r in results}
  assert result_ids == set(ids)


def test_read_bundle_using_any_member_id_returns_same_results(mongo_db):
  """read() with bundle=True must return the same bundle regardless of which member ID is used."""
  ids = mongo_db.create(DOCS, [{"name": "a"}, {"name": "b"}], bundle=True)
  results_via_first = {r["_id"] for r in mongo_db.read(DOCS, filter={"_id": ids[0]}, bundle=True)}
  results_via_last = {r["_id"] for r in mongo_db.read(DOCS, filter={"_id": ids[-1]}, bundle=True)}
  assert results_via_first == results_via_last == set(ids)


def test_read_bundle_false_returns_only_requested_doc(mongo_db):
  """read() with bundle=False must not expand to other docs in the bundle."""
  ids = mongo_db.create(DOCS, [{"name": "p"}, {"name": "q"}], bundle=True)
  results = mongo_db.read(DOCS, filter={"_id": ids[0]}, bundle=False)
  assert len(results) == 1
  assert results[0]["_id"] == ids[0]


def test_read_bundle_fallback_when_no_bundle_found(mongo_db):
  """read() with bundle=True must fall back to the original filter if no bundle exists."""
  ids = mongo_db.create(DOCS, [{"name": "solo"}])  # no bundle
  results = mongo_db.read(DOCS, filter={"_id": ids[0]}, bundle=True)
  assert len(results) == 1
  assert results[0]["_id"] == ids[0]


# ---------------------------------------------------------------------------
# Bundle — update
# ---------------------------------------------------------------------------


def test_update_bundle_updates_all_docs_in_bundle(mongo_db):
  """update() with bundle=True must apply the update to every doc in the bundle."""
  ids = mongo_db.create(DOCS, [{"name": "u1", "status": "new"}, {"name": "u2", "status": "new"}], bundle=True)
  count = mongo_db.update(DOCS, {"_id": ids[0]}, {"$set": {"status": "done"}}, bundle=True)
  assert count == 2
  docs = mongo_db.read(DOCS, filter={"_id": {"$in": ids}})
  assert all(d["status"] == "done" for d in docs)


def test_update_bundle_false_updates_only_matched_doc(mongo_db):
  """update() with bundle=False must only update the matched document."""
  ids = mongo_db.create(DOCS, [{"name": "v1", "status": "new"}, {"name": "v2", "status": "new"}], bundle=True)
  mongo_db.update(DOCS, {"_id": ids[0]}, {"$set": {"status": "done"}}, bundle=False)
  docs = mongo_db.read(DOCS, filter={"_id": {"$in": ids}})
  statuses = {d["_id"]: d["status"] for d in docs}
  assert statuses[ids[0]] == "done"
  assert statuses[ids[1]] == "new"


def test_update_bundle_fallback_when_no_bundle_found(mongo_db):
  """update() with bundle=True must fall back to updating only the matched doc if no bundle exists."""
  ids = mongo_db.create(DOCS, [{"name": "solo", "status": "new"}])  # no bundle
  count = mongo_db.update(DOCS, {"_id": ids[0]}, {"$set": {"status": "done"}}, bundle=True)
  assert count == 1
  assert mongo_db.read(DOCS, filter={"_id": ids[0]})[0]["status"] == "done"


def test_update_bundle_skips_aggregated_status_write_when_unchanged(mongo_db):
  """update() must not write to documentBundles when aggregatedStatus would not change."""
  ids = mongo_db.create(DOCS, [{"name": "w1", "status": "pending"}, {"name": "w2", "status": "pending"}], bundle=True)
  bundle_before = mongo_db.read(Collection.DOCUMENT_BUNDLES.value)[0]
  assert bundle_before["aggregatedStatus"] == "pending"
  # Updating a non-status field — aggregatedStatus stays "pending"
  mongo_db.update(DOCS, {"_id": ids[0]}, {"$set": {"name": "w1-renamed"}}, bundle=True)
  bundle_after = mongo_db.read(Collection.DOCUMENT_BUNDLES.value)[0]
  assert bundle_after["aggregatedStatus"] == "pending"
  assert bundle_after["updatedDate"] == bundle_before["updatedDate"]


def test_update_bundle_writes_aggregated_status_when_changed(mongo_db):
  """update() with bundle=True cascades to all docs and updates aggregatedStatus when it changes."""
  ids = mongo_db.create(DOCS, [{"name": "x1", "status": "pending"}, {"name": "x2", "status": "pending"}], bundle=True)
  bundle_before = mongo_db.read(Collection.DOCUMENT_BUNDLES.value)[0]
  assert bundle_before["aggregatedStatus"] == "pending"
  # bundle=True expands the update to ALL docs in the bundle — both become "completed"
  mongo_db.update(DOCS, {"_id": ids[0]}, {"$set": {"status": "completed"}}, bundle=True)
  bundle_after = mongo_db.read(Collection.DOCUMENT_BUNDLES.value)[0]
  assert bundle_after["aggregatedStatus"] == "completed"
  assert bundle_after["updatedDate"] != bundle_before["updatedDate"]


# ---------------------------------------------------------------------------
# Bundle — delete
# ---------------------------------------------------------------------------


def test_delete_bundle_removes_all_docs(mongo_db):
  """delete() with bundle=True must remove all documents in the bundle."""
  ids = mongo_db.create(DOCS, [{"name": "d1"}, {"name": "d2"}, {"name": "d3"}], bundle=True)
  mongo_db.delete(DOCS, {"_id": ids[0]}, bundle=True)
  remaining = mongo_db.read(DOCS, filter={"_id": {"$in": ids}})
  assert remaining == []


def test_delete_bundle_removes_bundle_document(mongo_db):
  """delete() with bundle=True must also delete the bundle entry from DOCUMENT_BUNDLES."""
  ids = mongo_db.create(DOCS, [{"name": "d1"}, {"name": "d2"}], bundle=True)
  mongo_db.delete(DOCS, {"_id": ids[0]}, bundle=True)
  assert mongo_db.read(BUNDLES) == []


def test_delete_bundle_false_leaves_bundle_and_other_docs_intact(mongo_db):
  """delete() with bundle=False must only delete the matched doc and not touch the bundle."""
  ids = mongo_db.create(DOCS, [{"name": "e1"}, {"name": "e2"}], bundle=True)
  mongo_db.delete(DOCS, {"_id": ids[0]}, bundle=False)
  assert not mongo_db.exists(DOCS, {"_id": ids[0]})
  assert mongo_db.exists(DOCS, {"_id": ids[1]})
  assert len(mongo_db.read(BUNDLES)) == 1


def test_delete_bundle_fallback_when_no_bundle_found(mongo_db):
  """delete() with bundle=True must delete only the matched doc if no bundle exists."""
  ids = mongo_db.create(DOCS, [{"name": "solo1"}, {"name": "solo2"}])  # no bundle
  mongo_db.delete(DOCS, {"_id": ids[0]}, bundle=True)
  assert not mongo_db.exists(DOCS, {"_id": ids[0]})
  assert mongo_db.exists(DOCS, {"_id": ids[1]})


def test_delete_bundle_returns_correct_deleted_count(mongo_db):
  """delete() with bundle=True must return the number of deleted documents."""
  ids = mongo_db.create(DOCS, [{"name": "f1"}, {"name": "f2"}, {"name": "f3"}], bundle=True)
  count = mongo_db.delete(DOCS, {"_id": ids[0]}, bundle=True)
  assert count == 3


# ---------------------------------------------------------------------------
# _expand_bundle_filter
# ---------------------------------------------------------------------------


def test_expand_bundle_filter_returns_in_filter_when_bundle_found(mongo_db):
  """_expand_bundle_filter must return an $in filter covering all bundle member IDs."""
  ids = mongo_db.create(DOCS, [{"name": "g1"}, {"name": "g2"}], bundle=True)
  result = mongo_db._expand_bundle_filter({"_id": ids[0]})
  assert "$in" in result["_id"]
  assert set(result["_id"]["$in"]) == set(ids)


def test_expand_bundle_filter_returns_original_filter_when_no_bundle(mongo_db):
  """_expand_bundle_filter must return the original filter unchanged if no bundle found."""
  ids = mongo_db.create(DOCS, [{"name": "solo"}])  # no bundle
  original = {"_id": ids[0]}
  result = mongo_db._expand_bundle_filter(original)
  assert result == original


def test_expand_bundle_filter_raises_when_no_id(mongo_db):
  """_expand_bundle_filter must raise ValueError if filter contains no _id."""
  with pytest.raises(ValueError, match="_id"):
    mongo_db._expand_bundle_filter({"name": "whoever"})


def test_read_bundle_raises_without_id_in_filter(mongo_db):
  """read() with bundle=True must raise ValueError if filter has no _id."""
  mongo_db.create(DOCS, [{"name": "doc1"}], bundle=True)
  with pytest.raises(ValueError, match="_id"):
    mongo_db.read(DOCS, filter={"name": "doc1"}, bundle=True)


def test_update_bundle_raises_without_id_in_filter(mongo_db):
  """update() with bundle=True must raise ValueError if filter has no _id."""
  mongo_db.create(DOCS, [{"name": "doc1", "status": "new"}], bundle=True)
  with pytest.raises(ValueError, match="_id"):
    mongo_db.update(DOCS, {"name": "doc1"}, {"$set": {"status": "done"}}, bundle=True)


def test_delete_bundle_raises_without_id_in_filter(mongo_db):
  """delete() with bundle=True must raise ValueError if filter has no _id."""
  mongo_db.create(DOCS, [{"name": "doc1"}], bundle=True)
  with pytest.raises(ValueError, match="_id"):
    mongo_db.delete(DOCS, {"name": "doc1"}, bundle=True)


# ---------------------------------------------------------------------------
# compute_aggregated_status
# ---------------------------------------------------------------------------


class TestComputeAggregatedStatus:
  def test_empty_list_returns_pending(self):
    assert compute_aggregated_status([]) == "pending"

  def test_all_completed(self):
    assert compute_aggregated_status([{"status": "completed"}, {"status": "finalized"}]) == "completed"

  def test_all_processed(self):
    assert compute_aggregated_status([{"status": "processed"}]) == "completed"

  def test_any_in_progress_dominates(self):
    assert compute_aggregated_status([{"status": "completed"}, {"status": "in_progress"}]) == "in_progress"

  def test_processing_maps_to_in_progress(self):
    assert compute_aggregated_status([{"status": "processing"}]) == "in_progress"

  def test_uploaded_maps_to_in_progress(self):
    assert compute_aggregated_status([{"status": "uploaded"}]) == "in_progress"

  def test_error_dominates_all(self):
    assert compute_aggregated_status([{"status": "in_progress"}, {"status": "error"}]) == "error"

  def test_failed_dominates_all(self):
    assert compute_aggregated_status([{"status": "completed"}, {"status": "failed"}]) == "error"

  def test_error_dominates_completed(self):
    assert compute_aggregated_status([{"status": "completed"}, {"status": "error"}]) == "error"

  def test_missing_status_falls_back_to_processingStatus(self):
    assert compute_aggregated_status([{"processingStatus": "in_progress"}]) == "in_progress"

  def test_missing_both_status_fields_treated_as_pending(self):
    assert compute_aggregated_status([{"documentName": "no-status"}]) == "pending"

  def test_mixed_pending_and_completed_returns_pending(self):
    assert compute_aggregated_status([{"status": "completed"}, {}]) == "pending"

  def test_unknown_status_treated_as_pending(self):
    assert compute_aggregated_status([{"status": "unknown_state"}]) == "pending"

  def test_multiple_files_all_error(self):
    files = [{"status": "error"}, {"status": "failed"}]
    assert compute_aggregated_status(files) == "error"

  def test_single_pending_file(self):
    assert compute_aggregated_status([{"status": "pending"}]) == "pending"
