"""Tests for TinySearchService."""

from unittest.mock import MagicMock, patch

from tinysdk.models.bundle_document import BundleDocument
from tinysdk.models.file_document import FileDocument
from tinysdk.search import _BUNDLE_DEFAULTS, _DOC_DEFAULTS


def _make_service():
  with patch("meilisearch.Client") as mock_cls:
    mock_client = MagicMock()
    mock_cls.return_value = mock_client
    mock_client.create_index.return_value = None
    mock_client.index.return_value = MagicMock()

    from tinysdk import TinySearchService

    svc = TinySearchService(host="http://localhost:7700", key="test", logger=MagicMock())
    svc.client = mock_client
    return svc, mock_client


def _bundle(overrides=None, **kwargs) -> dict:
  data = BundleDocument(**kwargs).to_dict()
  data["_id"] = "bundle1"
  if overrides:
    data.update(overrides)
  return data


def _doc(overrides=None, **kwargs) -> dict:
  defaults = dict(
    documentName="Invoice.pdf",
    fileName="uuid.pdf",
    mimeType="application/pdf",
    size=1024,
    uploadedBy="user1",
    bucketName="customer-documents",
    bucketNameProcessed="preprocessed-documents",
  )
  defaults.update(kwargs)
  data = FileDocument(**defaults).to_dict()
  data["_id"] = "doc1"
  if overrides:
    data.update(overrides)
  return data


class TestBuildDocRecord:
  def setup_method(self):
    self.svc, _ = _make_service()

  def test_picks_file_document_fields(self):
    doc = _doc()
    result = self.svc._build_doc_record(doc)
    assert result["id"] == "doc1"
    assert result["documentName"] == doc["documentName"]
    assert result["mimeType"] == doc["mimeType"]
    assert result["status"] == doc["status"]

  def test_defaults_for_missing_fields(self):
    result = self.svc._build_doc_record({"_id": "x", "uploadedBy": ""})
    assert result["documentName"] == _DOC_DEFAULTS["documentName"]
    assert result["status"] == _DOC_DEFAULTS["status"]

  def test_uploadedby_coerced_to_string(self):
    doc = _doc(overrides={"uploadedBy": 12345})
    assert self.svc._build_doc_record(doc)["uploadedBy"] == "12345"


class TestBuildRecord:
  def setup_method(self):
    self.svc, _ = _make_service()

  def test_picks_bundle_document_fields(self):
    bundle = _bundle(
      bundleName="My Bundle",
      tags=["loans"],
      owner="alice",
      aggregatedStatus="completed",
      createdDate="2026-01-01T00:00:00Z",
      totalFiles=3,
    )
    result = self.svc._build_record(bundle, [])
    assert result["id"] == "bundle1"
    assert result["bundleName"] == bundle["bundleName"]
    assert result["tags"] == bundle["tags"]
    assert result["totalFiles"] == bundle["totalFiles"]

  def test_total_files_falls_back_to_doc_count(self):
    bundle = _bundle()
    result = self.svc._build_record(bundle, [_doc(), _doc(overrides={"_id": "doc2"})])
    assert result["totalFiles"] == 2

  def test_documents_embedded(self):
    doc = _doc(documentName="Doc A")
    result = self.svc._build_record(_bundle(bundleName="B"), [doc])
    assert len(result["documents"]) == 1
    assert result["documents"][0]["documentName"] == "Doc A"

  def test_defaults_for_missing_bundle_fields(self):
    result = self.svc._build_record({"_id": "b1"}, [])
    assert result["bundleName"] == _BUNDLE_DEFAULTS["bundleName"]
    assert result["aggregatedStatus"] == _BUNDLE_DEFAULTS["aggregatedStatus"]
    assert result["tags"] == _BUNDLE_DEFAULTS["tags"]


class TestUpsertAndDelete:
  def test_upsert_calls_add_documents(self):
    svc, mock_client = _make_service()
    mock_index = MagicMock()
    mock_client.index.return_value = mock_index
    svc.upsert_bundle(_bundle(bundleName="Test"), [])
    mock_index.add_documents.assert_called_once()
    assert mock_index.add_documents.call_args[0][0][0]["bundleName"] == "Test"

  def test_delete_calls_delete_document(self):
    svc, mock_client = _make_service()
    mock_index = MagicMock()
    mock_client.index.return_value = mock_index
    svc.delete_bundle("bundle-xyz")
    mock_index.delete_document.assert_called_once_with("bundle-xyz")


class TestSearch:
  def test_passes_all_params_to_meilisearch(self):
    svc, mock_client = _make_service()
    mock_index = MagicMock()
    mock_client.index.return_value = mock_index
    mock_index.search.return_value = {"hits": [], "estimatedTotalHits": 0}

    svc.search("loans", filter_expr="aggregatedStatus = pending", sort=["createdDate:desc"], page=1, limit=5)

    params = mock_index.search.call_args[0][1]
    assert params["filter"] == "aggregatedStatus = pending"
    assert params["sort"] == ["createdDate:desc"]
    assert params["offset"] == 5
    assert params["limit"] == 5
    assert params["matchingStrategy"] == "all"

  def test_omits_filter_and_sort_when_none(self):
    svc, mock_client = _make_service()
    mock_index = MagicMock()
    mock_client.index.return_value = mock_index
    mock_index.search.return_value = {"hits": [], "estimatedTotalHits": 0}

    svc.search("test")

    params = mock_index.search.call_args[0][1]
    assert "filter" not in params
    assert "sort" not in params
