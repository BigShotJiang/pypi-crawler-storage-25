"""MongoDB collection name enums for the TinyAI microservices platform."""

from enum import Enum


class Collection(str, Enum):
  def __str__(self) -> str:
    return self.value

  USERS = "users"
  OCR = "ocr"
  EXTRACTION = "extraction"
  DOCUMENT = "document"
  CLASSIFICATION = "classification"
  HITL = "humanInTheLoop"
  METRICS = "metrics"
  FILETYPES = "filetypes"
  MODELS = "models"
  LABELS = "labels"
  CUSTOMDATA = "customData"
  ROUTINES = "routines"
  AUDITLOGS = "auditlogs"
  RESUMETOKENS = "__resume_tokens"
  DOCUMENT_BUNDLES = "documentBundles"
  API = "api"
