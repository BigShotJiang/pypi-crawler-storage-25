from typing import Any, Dict, List

from pymongo import ASCENDING, DESCENDING

from tinysdk.collections import Collection

INDEX_CONFIG: Dict[str, List[Any]] = {
  Collection.USERS.value: [[("name", ASCENDING)], [("email", ASCENDING), {"unique": True}]],
  Collection.OCR.value: [[("documentId", ASCENDING), {"unique": True}], [("completedAt", ASCENDING)]],
  Collection.EXTRACTION.value: [[("documentId", ASCENDING), {"unique": True}], [("completedAt", ASCENDING)]],
  Collection.CLASSIFICATION.value: [[("documentId", ASCENDING), {"unique": True}], [("completedAt", ASCENDING)], [("category", ASCENDING)]],
  Collection.METRICS.value: [[("userId", ASCENDING), {"unique": True}]],
  Collection.HITL.value: [[("documentId", ASCENDING), {"unique": True}], [("reviewerId", ASCENDING)], [("processorId", ASCENDING)]],
  Collection.MODELS.value: [[("status", ASCENDING)], [("created_at", DESCENDING)], [("model_name", ASCENDING), ("version", ASCENDING)]],
  Collection.DOCUMENT.value: [
    [("ocrCompleted", ASCENDING)],
    [("classificationCompleted", ASCENDING)],
    [("extractionCompleted", ASCENDING)],
    # hitlCompleted standalone removed — covered as prefix by the compound index below
    [("uploadDate", ASCENDING)],
    [("documentName", "text")],
    [("fileName", ASCENDING), {"unique": True}],
    # Compound index for process/review queue page loads:
    # covers: processingCompleted=x, hitlCompleted=x, status $in [...], sort uploadDate
    [("processingCompleted", ASCENDING), ("hitlCompleted", ASCENDING), ("status", ASCENDING), ("uploadDate", ASCENDING)],
  ],
  Collection.DOCUMENT_BUNDLES.value: [
    # multikey index — each element of bundleIds array gets an entry, enabling doc → bundle reverse lookup
    [("bundleIds", ASCENDING)],
  ],
}
