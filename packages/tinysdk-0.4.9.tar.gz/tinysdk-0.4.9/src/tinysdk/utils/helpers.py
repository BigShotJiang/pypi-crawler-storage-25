import re

from datetime import datetime, timezone
from typing import Any, Dict, List


def is_valid(data: Dict[str, Any], keys: List[str]) -> bool:
  if data is None or data == {}:
    return False
  return all(key in data for key in keys)


def get_date() -> str:
  return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def to_snake_case(s: str) -> str:
  """Convert a string to snake_case. Handles camelCase, PascalCase, spaces, and consecutive underscores."""
  return re.sub(r"_+", "_", re.sub(r"\s+", "_", re.sub(r"(?<!^)(?=[A-Z])", "_", s))).lower()
