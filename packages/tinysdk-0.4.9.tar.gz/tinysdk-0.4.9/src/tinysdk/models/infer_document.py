from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List

from tinysdk.utils.helpers import get_date


@dataclass
class InferenceDocument:
  documentId: str
  fileNames: List[str]
  modelTrace: Dict[str, Any]
  bucketName: str
  completedAt: str = field(default_factory=get_date)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
