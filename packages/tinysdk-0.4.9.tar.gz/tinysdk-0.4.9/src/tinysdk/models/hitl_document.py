from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List

from tinysdk.utils.helpers import get_date


@dataclass
class HITLDocument:
  documentId: str
  extractionDocumentId: str
  originalExtraction: List[Dict[str, Any]]
  modifiedExtraction: List[Dict[str, Any]]
  customColumnData: List[Dict[str, Any]] = field(default_factory=list)
  createdAt: str = field(default_factory=get_date)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
