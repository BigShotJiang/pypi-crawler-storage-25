from dataclasses import asdict, dataclass, field
from typing import Any, Dict

from tinysdk.utils.helpers import get_date


@dataclass
class OCRDocument:
  documentId: str
  confidence: float
  fileName: str
  bucketName: str
  completedAt: str = field(default_factory=get_date)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
