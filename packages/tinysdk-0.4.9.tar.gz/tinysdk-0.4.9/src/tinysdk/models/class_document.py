from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List

from tinysdk.utils.helpers import get_date


@dataclass
class ClassificationDocument:
  documentId: str
  category: str
  confidence: float
  classificationModelsId: List[str]
  extractionModelsId: List[str]
  modelTrace: Dict[str, Any]
  completedAt: str = field(default_factory=get_date)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
