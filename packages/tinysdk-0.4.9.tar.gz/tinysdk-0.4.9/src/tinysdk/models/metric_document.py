from dataclasses import asdict, dataclass, field
from typing import Any, Dict


@dataclass
class Metric:
  userId: str
  docs_approved: int = field(default=0)
  docs_sent_back: int = field(default=0)
  docs_sent_manual: int = field(default=0)
  docs_submitted: int = field(default=0)
  docs_total_processed: int = field(default=0)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
