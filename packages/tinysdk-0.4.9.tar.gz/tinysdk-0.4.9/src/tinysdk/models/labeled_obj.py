from dataclasses import asdict, dataclass, field
from typing import Any, Dict, Optional


@dataclass
class LabeledObject:
  _id: str
  label: str
  value: str
  confidence: float
  pageNumber: int
  bbox: Dict[str, int]
  page_size: Dict[str, int]
  modelName: Optional[str] = field(default=None)
  valid: bool = field(default=True)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
