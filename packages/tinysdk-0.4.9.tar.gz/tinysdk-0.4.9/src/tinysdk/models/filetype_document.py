from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List


@dataclass
class FileTypeDocument:
  name: str
  labels: List[Dict[str, Any]] = field(default_factory=list)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
