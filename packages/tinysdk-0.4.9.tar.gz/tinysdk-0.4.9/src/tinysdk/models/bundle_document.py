from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List

from tinysdk.utils.helpers import get_date

# Lower rank = higher severity. Used to reduce a list of file statuses to one bundle status.
_STATUS_RANKS: Dict[str, int] = {
  "error": 0,
  "failed": 0,
  "ocr_queued": 1,
  "ai_queued": 1,
  "class_queued": 1,
  "ai_processing": 1,
  "class_processing": 1,
  "class_done": 1,
  "in_progress": 1,
  "processing": 1,
  "uploaded": 1,
  "created": 2,
  "pending": 2,
  "ai_done": 3,
  "completed": 3,
  "processed": 3,
  "finalized": 3,
}


def compute_aggregated_status(files: List[Dict[str, Any]]) -> str:
  """Reduce a list of FileDocument dicts to a single bundle status string."""
  if not files:
    return "pending"
  statuses = [f.get("status") or f.get("processingStatus") or "pending" for f in files]
  worst = min(_STATUS_RANKS.get(s, 2) for s in statuses)
  if worst == 0:
    return "error"
  if worst == 1:
    return "in_progress"
  if all(_STATUS_RANKS.get(s, 2) == 3 for s in statuses):
    return "completed"
  return "pending"


@dataclass
class BundleDocument:
  bundleName: str = ""
  bundleIds: List[str] = field(default_factory=list)
  systemGeneratedDocumentIds: List[Dict[str, Any]] = field(default_factory=list)
  tags: List[str] = field(default_factory=list)
  owner: str = ""
  totalFiles: int = 0
  aggregatedStatus: str = "pending"
  createdDate: str = field(default_factory=get_date)
  updatedDate: str = field(default_factory=get_date)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
