from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List

from tinysdk.utils.helpers import get_date


@dataclass
class ModelDocument:
  modelName: str
  modelPath: str
  labels: List[str]
  inferenceQueue: str
  inferenceMode: str
  trigger: str
  metrics: Dict[str, Any] = field(default_factory=dict)
  version: str = field(default="1.0")
  createdAt: str = field(default_factory=get_date)
  createdBy: str = field(default="system")

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
