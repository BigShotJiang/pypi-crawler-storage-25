import os
import threading
import time
from dataclasses import dataclass
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from tinysdk.tinylogger import TinyLogger


@dataclass
class _Stats:
  call_count: int = 0
  error_count: int = 0
  total_ms: float = 0.0
  min_ms: float = float("inf")
  max_ms: float = 0.0

  @property
  def avg_ms(self) -> float:
    return self.total_ms / self.call_count if self.call_count else 0.0

  def record(self, duration_ms: float, error: bool) -> None:
    self.call_count += 1
    if error:
      self.error_count += 1
    self.total_ms += duration_ms
    if duration_ms < self.min_ms:
      self.min_ms = duration_ms
    if duration_ms > self.max_ms:
      self.max_ms = duration_ms

  def reset(self) -> None:
    self.call_count = 0
    self.error_count = 0
    self.total_ms = 0.0
    self.min_ms = float("inf")
    self.max_ms = 0.0


class _Trace:
  """Dual-mode profiling object: context manager and decorator."""

  def __init__(self, profiler: "TinyProfiler", name: str, document_id: str = "") -> None:
    self._profiler = profiler
    self._name = name
    self._document_id = document_id
    self._start: float = 0.0

  def __enter__(self) -> "_Trace":
    self._start = time.perf_counter()
    return self

  def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
    duration_ms = (time.perf_counter() - self._start) * 1000.0
    error = exc_type is not None
    self._profiler._record(self._name, duration_ms, error)
    self._profiler._emit_per_call(self._name, duration_ms, error, self._document_id)

  def __call__(self, func: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
      with _Trace(self._profiler, self._name, self._document_id):
        return func(*args, **kwargs)

    return wrapper


class TinyProfiler:
  """Profiling component that emits structured timing events through TinyLogger.

  Emits PROFILE events (DEBUG) on every traced call and PROFILE_SUMMARY events
  (INFO) on a configurable interval suitable for Grafana dashboards.

  Environment Variables:
      PROFILER_INTERVAL: Seconds between PROFILE_SUMMARY flushes (default: 60)

  Example:
      >>> profiler = TinyProfiler(logger)
      >>> profiler.start()
      >>>
      >>> @profiler.trace
      ... def extract(doc): ...
      >>>
      >>> @profiler.trace("ocr_pipeline")
      ... def run(doc): ...
      >>>
      >>> with profiler.trace("db_lookup", document_id="doc-42"):
      ...     result = db.find(...)
      >>>
      >>> profiler.stop()
  """

  def __init__(self, logger: TinyLogger) -> None:
    self._logger = logger
    self._interval = int(os.getenv("PROFILER_INTERVAL", "60"))
    self._stats: Dict[str, _Stats] = {}
    self._lock = threading.Lock()
    self._thread: Optional[threading.Thread] = None
    self._stop_event = threading.Event()

  def start(self) -> None:
    """Start the background summary thread. Idempotent — safe to call multiple times."""
    if self._thread is not None and self._thread.is_alive():
      return
    self._stop_event.clear()
    self._thread = threading.Thread(target=self._summary_loop, daemon=True)
    self._thread.start()

  def stop(self) -> None:
    """Stop the background summary thread and wait for it to exit. Idempotent."""
    self._stop_event.set()
    if self._thread is not None and self._thread.is_alive():
      self._thread.join(timeout=5)
    self._thread = None

  def trace(self, name_or_func: Union[Callable[..., Any], str, None] = None, document_id: str = "") -> Any:
    """Profile a function or code block.

    Usage::

        @profiler.trace                              # bare decorator, uses func.__name__
        @profiler.trace("custom_name")              # named decorator
        with profiler.trace("block_name"):          # context manager
        with profiler.trace("block", document_id="doc-42"):  # with document correlation
    """
    if callable(name_or_func):
      func = name_or_func
      return _Trace(self, func.__name__, document_id)(func)
    name = name_or_func if isinstance(name_or_func, str) else "unnamed"
    return _Trace(self, name, document_id)

  def _record(self, name: str, duration_ms: float, error: bool) -> None:
    with self._lock:
      if name not in self._stats:
        self._stats[name] = _Stats()
      self._stats[name].record(duration_ms, error)

  def _emit_per_call(self, name: str, duration_ms: float, error: bool, document_id: str = "") -> None:
    ctx: Dict[str, Any] = {
      "trace_name": name,
      "duration_ms": round(duration_ms, 3),
      "success": not error,
    }
    if document_id:
      ctx["document_id"] = document_id
    self._logger._emit(event_type="PROFILE", level="DEBUG", message=name, ctx=ctx, document_id=document_id)

  def _emit_summary(self) -> None:
    with self._lock:
      to_emit: List[Tuple[str, int, int, float, float, float]] = []
      for name, stats in self._stats.items():
        if stats.call_count > 0:
          to_emit.append((name, stats.call_count, stats.error_count, stats.min_ms, stats.avg_ms, stats.max_ms))
          stats.reset()

    for name, call_count, error_count, min_ms, avg_ms, max_ms in to_emit:
      ctx: Dict[str, Any] = {
        "trace_name": name,
        "call_count": call_count,
        "error_count": error_count,
        "duration_ms": {"min": round(min_ms, 3), "avg": round(avg_ms, 3), "max": round(max_ms, 3)},
      }
      self._logger._emit(event_type="PROFILE_SUMMARY", level="INFO", message=name, ctx=ctx)

  def _summary_loop(self) -> None:
    while not self._stop_event.is_set():
      self._stop_event.wait(self._interval)
      if self._stop_event.is_set():
        break
      self._emit_summary()
