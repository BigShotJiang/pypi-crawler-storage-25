import os
from typing import Any, Dict, List, Optional

import meilisearch
import meilisearch.errors

from tinysdk.tinylogger import TinyLogger

_BUNDLE_DEFAULTS: Dict[str, Any] = {
  "bundleName": "",
  "tags": [],
  "owner": "",
  "aggregatedStatus": "pending",
  "createdDate": "",
}

_DOC_DEFAULTS: Dict[str, Any] = {
  "documentName": "",
  "fileName": "",
  "mimeType": "",
  "uploadedBy": "",
  "uploadDate": "",
  "status": "created",
}


class TinySearchService:
  _INDEX = "bundles"

  def __init__(self, host: Optional[str] = None, key: Optional[str] = None, logger: Optional[TinyLogger] = None) -> None:
    host = host or os.getenv("MEILI_HOST", "http://meilisearch-server:7700") or "http://meilisearch-server:7700"
    key = key or os.getenv("MEILI_MASTER_KEY", "") or ""
    self.client = meilisearch.Client(host, key)
    self.logger = logger or TinyLogger()
    self._index_ready = False
    self._ensure_index()

  def _ensure_index(self) -> None:
    try:
      created = True
      try:
        self.client.create_index(self._INDEX, {"primaryKey": "id"})
      except meilisearch.errors.MeilisearchApiError as e:
        if e.code != "index_already_exists":
          raise
        created = False
      if created:
        self.client.index(self._INDEX).update_settings(
          {
            "filterableAttributes": ["aggregatedStatus", "createdDate"],
            "sortableAttributes": ["createdDate", "totalFiles"],
          }
        )
      self._index_ready = True
    except meilisearch.errors.MeilisearchCommunicationError as e:
      self.logger.log(f"Meilisearch unreachable, index setup deferred: {e}", level="WARNING")

  def _require_index(self) -> None:
    if not self._index_ready:
      self._ensure_index()

  def upsert_bundle(self, bundle: Dict[str, Any], documents: List[Dict[str, Any]]) -> None:
    self._require_index()
    record = self._build_record(bundle, documents)
    self.client.index(self._INDEX).add_documents([record])
    self.logger.log("Search index updated", context={"bundle_id": record["id"]})

  def delete_bundle(self, bundle_id: str) -> None:
    self._require_index()
    self.client.index(self._INDEX).delete_document(bundle_id)
    self.logger.log("Search index entry removed", context={"bundle_id": bundle_id})

  def _build_record(self, bundle: Dict[str, Any], documents: List[Dict[str, Any]]) -> Dict[str, Any]:
    record: Dict[str, Any] = {k: bundle.get(k) or v for k, v in _BUNDLE_DEFAULTS.items()}
    record["id"] = str(bundle["_id"])
    record["totalFiles"] = bundle.get("totalFiles") or len(documents)
    record["documents"] = [self._build_doc_record(d) for d in documents]
    return record

  def _build_doc_record(self, doc: Dict[str, Any]) -> Dict[str, Any]:
    record: Dict[str, Any] = {k: doc.get(k) or v for k, v in _DOC_DEFAULTS.items()}
    record["id"] = str(doc["_id"])
    record["uploadedBy"] = str(record["uploadedBy"])
    return record

  def search(self, q: str, filter_expr: Optional[str] = None, sort: Optional[List[str]] = None, page: int = 0, limit: int = 20) -> Dict[str, Any]:
    self._require_index()
    params: Dict[str, Any] = {"q": q, "offset": page * limit, "limit": limit, "matchingStrategy": "all"}
    if filter_expr:
      params["filter"] = filter_expr
    if sort:
      params["sort"] = sort
    return self.client.index(self._INDEX).search(q, params)
