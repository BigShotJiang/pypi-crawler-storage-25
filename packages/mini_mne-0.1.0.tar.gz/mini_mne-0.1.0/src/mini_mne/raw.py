from __future__ import annotations

import mne
import numpy as np
from pathlib import Path
from .raw_io import DefaultImportRawHandler, FileImportRawHandler

class SimpleRaw:
    """
    A simplified wrapper around MNE's Raw object for teaching purposes.
    Exposes only essential attributes and methods.
    """
    def __init__(self, raw_input: mne.io.BaseRaw | Path | None = None):
        """
        Parameters
        ----------
        raw_input : mne.io.BaseRaw, Path, or None
            The data source. Pass an MNE Raw object to wrap it directly, a
            Path to load from a BrainVision file, or None to download and
            use the MNE ERP-CORE example dataset.
        """
        # If no raw object and no path is provided, download and use an MNE example file instead
        if raw_input is None:
            handler = DefaultImportRawHandler()
            self._raw = handler.load_raw()
        elif isinstance(raw_input, mne.io.BaseRaw):
            self._raw = raw_input
        else:
            file_path = Path(raw_input)
            handler = FileImportRawHandler(file_path)
            self._raw = handler.load_raw()

    # Attributes (read-only properties)
    @property
    def sampling_frequency(self) -> float:
        """Get the sampling frequency in Hz."""
        return self._raw.info['sfreq']

    @property
    def channel_names(self) -> list:
        """Get the list of channel names."""
        return self._raw.ch_names

    @property
    def duration(self) -> float:
        """Get the duration in seconds."""
        return self._raw.duration

    @property
    def frequency_range(self) -> tuple[float, float]:
        """Get the frequency range in Hz: tuple of lowpass and highpass frequencies. """
        return self._raw.info['highpass'], self._raw.info['lowpass']

    @property
    def custom_reference(self) -> bool:
        """Has a custom reference been applied"""
        return bool(self._raw.info['custom_ref_applied'])

    def __str__(self):
        return f"Raw (continuous) EEG object | length: {self._raw.duration} seconds; {len(self._raw.ch_names)} channels"

    def __repr__(self):
        return f"MiniRaw(raw={self._raw})"

    def __dir__(self):
        return ['sampling_frequency', 'channel_names', 'duration', 'custom_reference',
                'plot', 'plot_psd', 'filter', 're_reference', 'get_events']

    # Methods
    def plot(self, *args, **kwargs):
        return self._raw.plot(*args, **kwargs)

    def plot_psd(self, fmin: float = 0, fmax: float = np.inf,
                 tmin: float | None = None, tmax: float | None = None, **kwargs):
        """Plot the power spectral density (PSD) using Welch's method.

        Parameters
        ----------
        fmin : float
            Lower frequency bound in Hz.
        fmax : float
            Upper frequency bound in Hz.
        tmin : float or None
            Start of the time window in seconds. None uses the start of the recording.
        tmax : float or None
            End of the time window in seconds. None uses the end of the recording.
        **kwargs
            Additional arguments passed to the MNE PSD plot function.
        """
        return self._raw.compute_psd(method='welch', fmin=fmin, fmax=fmax,
                                     tmin=tmin, tmax=tmax).plot(**kwargs)

    def filter(self, l_freq: float, h_freq: float) -> SimpleRaw:
        """
        Apply a bandpass filter to the data.

        Parameters
        ----------
        l_freq : float
            Low frequency cutoff in Hz (e.g., 0.1 for high-pass at 0.1 Hz)
        h_freq : float
            High frequency cutoff in Hz (e.g., 40 for low-pass at 40 Hz)

        Returns
        -------
        SimpleRaw
            A new SimpleRaw object with filtered data
        """
        filtered_raw = self._raw.copy().filter(l_freq=l_freq, h_freq=h_freq)
        return SimpleRaw(filtered_raw)

    def re_reference(self, ref_channels: list | None = None) -> SimpleRaw:
        """
        Re-reference the data.

        Parameters
        ----------
        ref_channels : list or None
            Channel(s) to use as reference. If None, uses average reference.

        Returns
        -------
        SimpleRaw
            A new SimpleRaw object with re-referenced data
        """
        reref_raw = self._raw.copy()
        if ref_channels is None:
            # Average reference
            reref_raw.set_eeg_reference('average')
        else:
            reref_raw.set_eeg_reference(ref_channels)
        return SimpleRaw(reref_raw)

    def get_events(self) -> tuple[np.ndarray, dict]:
        """Extract events from annotations.

        Returns
        -------
        events : np.ndarray, shape (n_events, 3)
            Array of events (sample, duration, event_id).
        event_id : dict
            Mapping of event labels to integer IDs.
        """
        return mne.events_from_annotations(self._raw)


