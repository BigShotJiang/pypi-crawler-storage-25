import mne
import os.path as op
from pathlib import Path
from typing import Protocol

class ImportRawHandler(Protocol):
    """Protocol for reading data into the SimpleRaw class"""

    def load_raw(self, directory: Path | None) -> mne.io.Raw:
        """Read data from file and return a mne.io.Raw object"""
        ...

    # def save_raw(self, directory: Path, raw: mne.io.Raw) -> None:
    #     """Save data to file"""
    #     ...

class DefaultImportRawHandler:
    """Default implementation of ImportRawHandler Protocol using MNE example data"""

    FIF_FILE = "ERP-CORE_Subject-001_Task-Flankers_eeg.fif"

    def load_raw(self, directory: Path | None = None) -> mne.io.Raw:
        if directory is None:
            directory = Path(".")
        else:
            directory = Path(directory)
            directory.mkdir(parents=True, exist_ok=True)
        # extend this later so that the user can abort if this is not what they want
        # could also give them a choice of path?
        print("No raw data provided, downloading MNE sample data to {directory}.")
        data_path = mne.datasets.erp_core.data_path(directory)

        erp_core_file = data_path / self.FIF_FILE
        print(f"Downloaded {erp_core_file}.")
        raw = mne.io.read_raw_fif(erp_core_file, preload=True)

        return raw

    # def save_raw(self, directory: Path, raw: mne.io.Raw) -> None:
    #     """Save data to file"""

class FileImportRawHandler:
    """
    Implementation of ImportRawHandler Protocol that reads raw data from file.
    Only equipped to handle BrainVision at the moment.
    """
    # Extend this to handle fif and BIDS
    # perhaps use a dispatch dictionary?
    def __init__(self, directory: Path):
        directory = Path(directory)
        self.directory = directory

    def load_raw(self) -> mne.io.Raw:
        raw = mne.io.read_raw_brainvision(self.directory, preload=True)
        return raw

