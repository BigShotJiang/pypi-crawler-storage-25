import mne


class SimpleEvoked:
    """
    A simplified wrapper around MNE's Evoked object for teaching purposes.
    Exposes only essential attributes and methods.
    """
    def __init__(self, evoked: mne.Evoked):
        """
        Parameters
        ----------
        evoked : mne.Evoked
            The underlying MNE Evoked object, typically obtained via
            SimpleEpoch.average().
        """
        self._evoked = evoked

    @property
    def comment(self) -> str:
        """Get the event type label."""
        return self._evoked.comment

    @property
    def nave(self) -> int:
        """Get the number of averaged epochs."""
        return self._evoked.nave

    @property
    def time_range(self) -> tuple[float, float]:
        """Get the time range in seconds as (tmin, tmax)."""
        return self._evoked.times[0], self._evoked.times[-1]

    @property
    def channel_names(self) -> list:
        """Get the list of channel names."""
        return self._evoked.ch_names

    def __str__(self):
        tmin, tmax = self.time_range
        return (f"Evoked object | condition: {self.comment}; "
                f"{self.nave} epochs averaged; "
                f"time range: {tmin:.3f}–{tmax:.3f} s; "
                f"{len(self.channel_names)} channels")

    def __repr__(self):
        return repr(self._evoked)

    def __dir__(self):
        return ['comment', 'nave', 'time_range', 'channel_names', 'plot']

    def plot(self, *args, **kwargs):
        return self._evoked.plot(*args, **kwargs)


def _unwrap(e: "SimpleEvoked | mne.Evoked") -> mne.Evoked:
    return e._evoked if isinstance(e, SimpleEvoked) else e


def plot_evokeds(
    evokeds: "SimpleEvoked | mne.Evoked | list | dict",
    *args,
    **kwargs
):
    """Plot and compare evoked responses.

    Parameters
    ----------
    evokeds : SimpleEvoked, mne.Evoked, list, or dict of str -> evoked
        The evoked response(s) to plot. Accepts SimpleEvoked wrappers or
        raw mne.Evoked objects interchangeably.
    """
    if isinstance(evokeds, (SimpleEvoked, mne.Evoked)):
        unwrapped = _unwrap(evokeds)
    elif isinstance(evokeds, dict):
        unwrapped = {label: _unwrap(e) for label, e in evokeds.items()}
    else:
        unwrapped = [_unwrap(e) for e in evokeds]
    return mne.viz.plot_compare_evokeds(unwrapped, *args, **kwargs)