from __future__ import annotations

import mne
from .raw import SimpleRaw
from .evoked import SimpleEvoked

class SimpleEpoch:
    """
    A simplified wrapper around MNE's Epoch object for teaching purposes.
    Exposes only essential attributes and methods.
    """
    def __init__(self,
                 raw: SimpleRaw,
                 events=None,
                 event_id=None,
                 tmin: float = -0.2,
                 tmax: float = 1.0,
                 baseline: tuple | None = None,
                 reject: dict | None = None):
        """
        Parameters
        ----------
        raw : SimpleRaw
            The continuous EEG data to epoch.
        events : np.ndarray, shape (n_events, 3)
            Event array as returned by SimpleRaw.get_events().
        event_id : dict
            Mapping of event labels to integer IDs, as returned by
            SimpleRaw.get_events().
        tmin : float
            Start of the epoch in seconds, relative to the event onset.
        tmax : float
            End of the epoch in seconds, relative to the event onset.
        baseline : tuple or None
            Time interval for baseline correction as (tmin, tmax) in seconds.
            None applies no baseline correction.
        reject : dict or None
            Peak-to-peak amplitude rejection thresholds, e.g.
            {'eeg': 100e-6} rejects epochs exceeding 100 µV.
            None applies no rejection.
        """
        base_raw = raw._raw

        epochs = mne.Epochs(base_raw, events, event_id, tmin, tmax,
                            baseline=baseline, reject=reject, preload=True)
        self._epochs = epochs

    @property
    def event_types(self) -> list:
        """Get the list of event type labels."""
        return list(self._epochs.event_id.keys())

    @property
    def time_range(self) -> tuple[float, float]:
        """Get the epoch time range in seconds as (tmin, tmax)."""
        return self._epochs.tmin, self._epochs.tmax

    @property
    def dropped_epochs(self) -> int:
        """Get the number of dropped epochs."""
        return len([d for d in self._epochs.drop_log if len(d) > 0])

    def __str__(self):
        event_labels = ", ".join(self.event_types)
        tmin, tmax = self.time_range
        return (f"Epoch object | {len(self)} epochs; "
                f"event types: {event_labels}; "
                f"time range: {tmin}–{tmax} s; "
                f"{self.dropped_epochs} dropped")

    def __repr__(self):
        return repr(self._epochs)

    def __len__(self):
        return len(self._epochs)

    def __iter__(self):
        return iter(self._epochs)

    def __dir__(self):
        return ['event_types', 'time_range', 'dropped_epochs', 'average', 'plot']

    @classmethod
    def _from_epochs(cls, epochs: mne.Epochs) -> "SimpleEpoch":
        """Wrap an existing mne.Epochs object without going through __init__."""
        instance = cls.__new__(cls)
        instance._epochs = epochs
        return instance

    def __getitem__(self, item) -> "SimpleEpoch":
        return SimpleEpoch._from_epochs(self._epochs[item])

    def average(self, by_event_type: bool = False) -> SimpleEvoked | list[SimpleEvoked]:
        """Compute the ERP by averaging across epochs.

        Parameters
        ----------
        by_event_type : bool
            If False (default), average across all epochs regardless of
            condition, returning a single SimpleEvoked. If True, average
            separately per condition, returning a list of SimpleEvoked
            (one per event type).

        Returns
        -------
        SimpleEvoked or list of SimpleEvoked
        """
        evoked = self._epochs.average(by_event_type=by_event_type)
        if isinstance(evoked, list):
            return [SimpleEvoked(e) for e in evoked]
        else:
            return SimpleEvoked(evoked)

    def plot(self, *args, **kwargs):
        return self._epochs.plot(*args, **kwargs)



