# mini-mne

A simplified wrapper around [MNE-Python](https://mne.tools) for teaching EEG data analysis. mini-mne exposes only the essential classes and methods, reducing the cognitive load for learners who are new to EEG preprocessing and analysis.

## Installation

```bash
pip install --upgrade mini-mne
```

Requires Python ≥ 3.11.

## Usage

mini-mne follows the standard EEG analysis pipeline: load continuous data → epoch around events → compute ERPs.

```python
from mini_mne import SimpleRaw, SimpleEpoch, SimpleEvoked, plot_evokeds

# Load data (downloads the MNE ERP-CORE example dataset if no path is given)
raw = SimpleRaw()

# Inspect the data
print(raw)
print(raw.sampling_frequency)  # Hz
print(raw.channel_names)
print(raw.duration)            # seconds

# Preprocess
raw = raw.filter(l_freq=0.1, h_freq=40.0)
raw = raw.re_reference()

# Extract events from annotations
events, event_id = raw.get_events()

# Epoch the data
epochs = SimpleEpoch(raw, events, event_id,
                     tmin=-0.2, tmax=0.8,
                     baseline=(-0.2, 0),
                     reject={"eeg": 100e-6})

print(epochs)
print(epochs.event_types)
print(epochs.dropped_epochs)

# Compute ERPs
evokeds = epochs.average(by_event_type=True)

# Plot
plot_evokeds(evokeds)
```

## Classes

| Class | Wraps | Purpose |
|---|---|---|
| `SimpleRaw` | `mne.io.Raw` | Continuous EEG data |
| `SimpleEpoch` | `mne.Epochs` | Segmented data around events |
| `SimpleEvoked` | `mne.Evoked` | Averaged ERP |

## Licence

mini-mne is licenced under the [BSD-3-Clause licence](LICENSE).

## Acknowledgements

mini-mne is built on top of [MNE-Python](https://mne.tools). The default example dataset is from the [ERP-CORE dataset](https://osf.io/thsqg/) (Kappenman et al., 2021).
