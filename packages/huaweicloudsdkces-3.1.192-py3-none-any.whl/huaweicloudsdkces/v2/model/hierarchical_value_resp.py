# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class HierarchicalValueResp:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'critical': 'float',
        'major': 'float',
        'minor': 'float',
        'info': 'float'
    }

    attribute_map = {
        'critical': 'critical',
        'major': 'major',
        'minor': 'minor',
        'info': 'info'
    }

    def __init__(self, critical=None, major=None, minor=None, info=None):
        r"""HierarchicalValueResp

        The model defined in huaweicloud sdk

        :param critical: **参数解释**： 紧急级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 
        :type critical: float
        :param major: **参数解释**： 重要级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 
        :type major: float
        :param minor: **参数解释**： 次要级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 
        :type minor: float
        :param info: **参数解释**： 提示级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 
        :type info: float
        """
        
        

        self._critical = None
        self._major = None
        self._minor = None
        self._info = None
        self.discriminator = None

        if critical is not None:
            self.critical = critical
        if major is not None:
            self.major = major
        if minor is not None:
            self.minor = minor
        if info is not None:
            self.info = info

    @property
    def critical(self):
        r"""Gets the critical of this HierarchicalValueResp.

        **参数解释**： 紧急级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :return: The critical of this HierarchicalValueResp.
        :rtype: float
        """
        return self._critical

    @critical.setter
    def critical(self, critical):
        r"""Sets the critical of this HierarchicalValueResp.

        **参数解释**： 紧急级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :param critical: The critical of this HierarchicalValueResp.
        :type critical: float
        """
        self._critical = critical

    @property
    def major(self):
        r"""Gets the major of this HierarchicalValueResp.

        **参数解释**： 重要级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :return: The major of this HierarchicalValueResp.
        :rtype: float
        """
        return self._major

    @major.setter
    def major(self, major):
        r"""Sets the major of this HierarchicalValueResp.

        **参数解释**： 重要级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :param major: The major of this HierarchicalValueResp.
        :type major: float
        """
        self._major = major

    @property
    def minor(self):
        r"""Gets the minor of this HierarchicalValueResp.

        **参数解释**： 次要级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :return: The minor of this HierarchicalValueResp.
        :rtype: float
        """
        return self._minor

    @minor.setter
    def minor(self, minor):
        r"""Sets the minor of this HierarchicalValueResp.

        **参数解释**： 次要级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :param minor: The minor of this HierarchicalValueResp.
        :type minor: float
        """
        self._minor = minor

    @property
    def info(self):
        r"""Gets the info of this HierarchicalValueResp.

        **参数解释**： 提示级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :return: The info of this HierarchicalValueResp.
        :rtype: float
        """
        return self._info

    @info.setter
    def info(self, info):
        r"""Sets the info of this HierarchicalValueResp.

        **参数解释**： 提示级别的阈值。 **取值范围**： [-1.7976931348623157e+108, 1.7976931348623157e+108] 

        :param info: The info of this HierarchicalValueResp.
        :type info: float
        """
        self._info = info

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, HierarchicalValueResp):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
