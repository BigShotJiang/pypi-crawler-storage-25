# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDashboardWidgetsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'widgets': 'list[WidgetInfoWithId]'
    }

    attribute_map = {
        'widgets': 'widgets'
    }

    def __init__(self, widgets=None):
        r"""ListDashboardWidgetsResponse

        The model defined in huaweicloud sdk

        :param widgets: **参数解释** 监控视图列表 
        :type widgets: list[:class:`huaweicloudsdkces.v2.WidgetInfoWithId`]
        """
        
        super().__init__()

        self._widgets = None
        self.discriminator = None

        if widgets is not None:
            self.widgets = widgets

    @property
    def widgets(self):
        r"""Gets the widgets of this ListDashboardWidgetsResponse.

        **参数解释** 监控视图列表 

        :return: The widgets of this ListDashboardWidgetsResponse.
        :rtype: list[:class:`huaweicloudsdkces.v2.WidgetInfoWithId`]
        """
        return self._widgets

    @widgets.setter
    def widgets(self, widgets):
        r"""Sets the widgets of this ListDashboardWidgetsResponse.

        **参数解释** 监控视图列表 

        :param widgets: The widgets of this ListDashboardWidgetsResponse.
        :type widgets: list[:class:`huaweicloudsdkces.v2.WidgetInfoWithId`]
        """
        self._widgets = widgets

    def to_dict(self):
        import warnings
        warnings.warn("ListDashboardWidgetsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDashboardWidgetsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
