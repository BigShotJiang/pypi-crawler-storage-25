# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListAlarmRulesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'alarms': 'list[ListAlarmRespBodyAlarms]',
        'count': 'int'
    }

    attribute_map = {
        'alarms': 'alarms',
        'count': 'count'
    }

    def __init__(self, alarms=None, count=None):
        r"""ListAlarmRulesResponse

        The model defined in huaweicloud sdk

        :param alarms: **参数解释**： 告警规则列表。 **取值范围**： 最多包含100个告警规则信息。 
        :type alarms: list[:class:`huaweicloudsdkces.v2.ListAlarmRespBodyAlarms`]
        :param count: **参数解释**： 告警规则总数。 **取值范围**： [0,10000] 
        :type count: int
        """
        
        super().__init__()

        self._alarms = None
        self._count = None
        self.discriminator = None

        if alarms is not None:
            self.alarms = alarms
        if count is not None:
            self.count = count

    @property
    def alarms(self):
        r"""Gets the alarms of this ListAlarmRulesResponse.

        **参数解释**： 告警规则列表。 **取值范围**： 最多包含100个告警规则信息。 

        :return: The alarms of this ListAlarmRulesResponse.
        :rtype: list[:class:`huaweicloudsdkces.v2.ListAlarmRespBodyAlarms`]
        """
        return self._alarms

    @alarms.setter
    def alarms(self, alarms):
        r"""Sets the alarms of this ListAlarmRulesResponse.

        **参数解释**： 告警规则列表。 **取值范围**： 最多包含100个告警规则信息。 

        :param alarms: The alarms of this ListAlarmRulesResponse.
        :type alarms: list[:class:`huaweicloudsdkces.v2.ListAlarmRespBodyAlarms`]
        """
        self._alarms = alarms

    @property
    def count(self):
        r"""Gets the count of this ListAlarmRulesResponse.

        **参数解释**： 告警规则总数。 **取值范围**： [0,10000] 

        :return: The count of this ListAlarmRulesResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ListAlarmRulesResponse.

        **参数解释**： 告警规则总数。 **取值范围**： [0,10000] 

        :param count: The count of this ListAlarmRulesResponse.
        :type count: int
        """
        self._count = count

    def to_dict(self):
        import warnings
        warnings.warn("ListAlarmRulesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAlarmRulesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
