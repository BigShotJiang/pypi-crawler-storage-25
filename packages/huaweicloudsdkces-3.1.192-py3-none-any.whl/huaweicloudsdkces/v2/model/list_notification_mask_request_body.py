# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListNotificationMaskRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'relation_type': 'ListRelationType',
        'alarm_ids': 'list[str]',
        'relation_ids': 'list[str]',
        'metric_name': 'str',
        'resource_level': 'str',
        'mask_id': 'str',
        'mask_name': 'str',
        'mask_status': 'str',
        'resource_id': 'str',
        'namespace': 'str',
        'dimensions': 'list[ResourceDimension]'
    }

    attribute_map = {
        'relation_type': 'relation_type',
        'alarm_ids': 'alarm_ids',
        'relation_ids': 'relation_ids',
        'metric_name': 'metric_name',
        'resource_level': 'resource_level',
        'mask_id': 'mask_id',
        'mask_name': 'mask_name',
        'mask_status': 'mask_status',
        'resource_id': 'resource_id',
        'namespace': 'namespace',
        'dimensions': 'dimensions'
    }

    def __init__(self, relation_type=None, alarm_ids=None, relation_ids=None, metric_name=None, resource_level=None, mask_id=None, mask_name=None, mask_status=None, resource_id=None, namespace=None, dimensions=None):
        r"""ListNotificationMaskRequestBody

        The model defined in huaweicloud sdk

        :param relation_type: 
        :type relation_type: :class:`huaweicloudsdkces.v2.ListRelationType`
        :param alarm_ids: **参数解释**： 告警规则ID列表，用于查询对应的告警通知屏蔽。 **约束限制**： 当relation_type为ALARM_RULE、RESOURCE_POLICY_NOTIFICATION时，应通过alarm_ids查询。当relation_type为RESOURCE、EVENT.SYS时，不支持使用alarm_ids查询，此时alarm_ids为空或不选，表示查询所有的RESOURCE、EVENT.SYS类型的告警屏蔽。 **取值范围**： 包含的告警规则ID数量最多不超过100个，最少为0个。 **默认取值**： 不涉及 
        :type alarm_ids: list[str]
        :param relation_ids: （已废弃，不推荐使用）关联编号（目前是告警规则ID）
        :type relation_ids: list[str]
        :param metric_name: **参数解释**： 资源的监控指标名称，各服务资源的指标名称，请参阅具体云服务的文档。您可以直接从[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)页面导航至相应文档。 **约束限制**： 不涉及。 **取值范围**： 必须以字母开头，只能包含0-9/a-z/A-Z/_/-。字符长度最短为1，最大为96。如：弹性云服务器中的监控指标cpu_util，表示弹性服务器的CPU使用率；文档数据库中的指标mongo001_command_ps，表示command执行频率。         **默认取值**： 不涉及。 
        :type metric_name: str
        :param resource_level: **参数解释**： 资源层级。 **约束限制**： 不涉及。 **取值范围**： - product: 云产品   - dimension: 子维度 **默认取值**： 不涉及。 
        :type resource_level: str
        :param mask_id: **参数解释**： 屏蔽规则ID,可选。 **约束限制**： 不涉及。 **取值范围**： 以nm开头，后跟[0,62]个英文或数字。 **默认取值**： 不涉及。 
        :type mask_id: str
        :param mask_name: **参数解释**： 屏蔽规则名称,可选。 **约束限制**： 不涉及。 **取值范围**： 只能为字母、数字、汉字、-、_，长度为[1,64]个字符。 **默认取值**： 不涉及。 
        :type mask_name: str
        :param mask_status: **参数解释**： 屏蔽状态,可选。 **约束限制**： 不涉及。 **取值范围**： - MASK_EFFECTIVE：已生效。 - MASK_INEFFECTIVE：未生效。 **默认取值**： 不涉及。 
        :type mask_status: str
        :param resource_id: **参数解释**： 资源维度值,提供一个维度的资源ID即可,可选 **约束限制**： 不涉及。 **取值范围**： 长度为[1,700]个字符。 **默认取值**： 不涉及。 
        :type resource_id: str
        :param namespace: **参数解释**： 查询服务的命名空间，各服务命名空间请参阅[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)。 **约束限制**： 不涉及。 **取值范围**： 格式为service.item；service和item必须是字符串，必须以字母开头，只能包含0-9/a-z/A-Z/_。字符串的长度必须在 3 到 32个字符之间。 **默认取值**： 不涉及。 
        :type namespace: str
        :param dimensions: **参数解释**： 资源的维度信息 **约束限制**： 包含的维度信息数量为[1,4]个。 
        :type dimensions: list[:class:`huaweicloudsdkces.v2.ResourceDimension`]
        """
        
        

        self._relation_type = None
        self._alarm_ids = None
        self._relation_ids = None
        self._metric_name = None
        self._resource_level = None
        self._mask_id = None
        self._mask_name = None
        self._mask_status = None
        self._resource_id = None
        self._namespace = None
        self._dimensions = None
        self.discriminator = None

        self.relation_type = relation_type
        if alarm_ids is not None:
            self.alarm_ids = alarm_ids
        self.relation_ids = relation_ids
        if metric_name is not None:
            self.metric_name = metric_name
        if resource_level is not None:
            self.resource_level = resource_level
        if mask_id is not None:
            self.mask_id = mask_id
        if mask_name is not None:
            self.mask_name = mask_name
        if mask_status is not None:
            self.mask_status = mask_status
        if resource_id is not None:
            self.resource_id = resource_id
        if namespace is not None:
            self.namespace = namespace
        if dimensions is not None:
            self.dimensions = dimensions

    @property
    def relation_type(self):
        r"""Gets the relation_type of this ListNotificationMaskRequestBody.

        :return: The relation_type of this ListNotificationMaskRequestBody.
        :rtype: :class:`huaweicloudsdkces.v2.ListRelationType`
        """
        return self._relation_type

    @relation_type.setter
    def relation_type(self, relation_type):
        r"""Sets the relation_type of this ListNotificationMaskRequestBody.

        :param relation_type: The relation_type of this ListNotificationMaskRequestBody.
        :type relation_type: :class:`huaweicloudsdkces.v2.ListRelationType`
        """
        self._relation_type = relation_type

    @property
    def alarm_ids(self):
        r"""Gets the alarm_ids of this ListNotificationMaskRequestBody.

        **参数解释**： 告警规则ID列表，用于查询对应的告警通知屏蔽。 **约束限制**： 当relation_type为ALARM_RULE、RESOURCE_POLICY_NOTIFICATION时，应通过alarm_ids查询。当relation_type为RESOURCE、EVENT.SYS时，不支持使用alarm_ids查询，此时alarm_ids为空或不选，表示查询所有的RESOURCE、EVENT.SYS类型的告警屏蔽。 **取值范围**： 包含的告警规则ID数量最多不超过100个，最少为0个。 **默认取值**： 不涉及 

        :return: The alarm_ids of this ListNotificationMaskRequestBody.
        :rtype: list[str]
        """
        return self._alarm_ids

    @alarm_ids.setter
    def alarm_ids(self, alarm_ids):
        r"""Sets the alarm_ids of this ListNotificationMaskRequestBody.

        **参数解释**： 告警规则ID列表，用于查询对应的告警通知屏蔽。 **约束限制**： 当relation_type为ALARM_RULE、RESOURCE_POLICY_NOTIFICATION时，应通过alarm_ids查询。当relation_type为RESOURCE、EVENT.SYS时，不支持使用alarm_ids查询，此时alarm_ids为空或不选，表示查询所有的RESOURCE、EVENT.SYS类型的告警屏蔽。 **取值范围**： 包含的告警规则ID数量最多不超过100个，最少为0个。 **默认取值**： 不涉及 

        :param alarm_ids: The alarm_ids of this ListNotificationMaskRequestBody.
        :type alarm_ids: list[str]
        """
        self._alarm_ids = alarm_ids

    @property
    def relation_ids(self):
        r"""Gets the relation_ids of this ListNotificationMaskRequestBody.

        （已废弃，不推荐使用）关联编号（目前是告警规则ID）

        :return: The relation_ids of this ListNotificationMaskRequestBody.
        :rtype: list[str]
        """
        return self._relation_ids

    @relation_ids.setter
    def relation_ids(self, relation_ids):
        r"""Sets the relation_ids of this ListNotificationMaskRequestBody.

        （已废弃，不推荐使用）关联编号（目前是告警规则ID）

        :param relation_ids: The relation_ids of this ListNotificationMaskRequestBody.
        :type relation_ids: list[str]
        """
        self._relation_ids = relation_ids

    @property
    def metric_name(self):
        r"""Gets the metric_name of this ListNotificationMaskRequestBody.

        **参数解释**： 资源的监控指标名称，各服务资源的指标名称，请参阅具体云服务的文档。您可以直接从[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)页面导航至相应文档。 **约束限制**： 不涉及。 **取值范围**： 必须以字母开头，只能包含0-9/a-z/A-Z/_/-。字符长度最短为1，最大为96。如：弹性云服务器中的监控指标cpu_util，表示弹性服务器的CPU使用率；文档数据库中的指标mongo001_command_ps，表示command执行频率。         **默认取值**： 不涉及。 

        :return: The metric_name of this ListNotificationMaskRequestBody.
        :rtype: str
        """
        return self._metric_name

    @metric_name.setter
    def metric_name(self, metric_name):
        r"""Sets the metric_name of this ListNotificationMaskRequestBody.

        **参数解释**： 资源的监控指标名称，各服务资源的指标名称，请参阅具体云服务的文档。您可以直接从[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)页面导航至相应文档。 **约束限制**： 不涉及。 **取值范围**： 必须以字母开头，只能包含0-9/a-z/A-Z/_/-。字符长度最短为1，最大为96。如：弹性云服务器中的监控指标cpu_util，表示弹性服务器的CPU使用率；文档数据库中的指标mongo001_command_ps，表示command执行频率。         **默认取值**： 不涉及。 

        :param metric_name: The metric_name of this ListNotificationMaskRequestBody.
        :type metric_name: str
        """
        self._metric_name = metric_name

    @property
    def resource_level(self):
        r"""Gets the resource_level of this ListNotificationMaskRequestBody.

        **参数解释**： 资源层级。 **约束限制**： 不涉及。 **取值范围**： - product: 云产品   - dimension: 子维度 **默认取值**： 不涉及。 

        :return: The resource_level of this ListNotificationMaskRequestBody.
        :rtype: str
        """
        return self._resource_level

    @resource_level.setter
    def resource_level(self, resource_level):
        r"""Sets the resource_level of this ListNotificationMaskRequestBody.

        **参数解释**： 资源层级。 **约束限制**： 不涉及。 **取值范围**： - product: 云产品   - dimension: 子维度 **默认取值**： 不涉及。 

        :param resource_level: The resource_level of this ListNotificationMaskRequestBody.
        :type resource_level: str
        """
        self._resource_level = resource_level

    @property
    def mask_id(self):
        r"""Gets the mask_id of this ListNotificationMaskRequestBody.

        **参数解释**： 屏蔽规则ID,可选。 **约束限制**： 不涉及。 **取值范围**： 以nm开头，后跟[0,62]个英文或数字。 **默认取值**： 不涉及。 

        :return: The mask_id of this ListNotificationMaskRequestBody.
        :rtype: str
        """
        return self._mask_id

    @mask_id.setter
    def mask_id(self, mask_id):
        r"""Sets the mask_id of this ListNotificationMaskRequestBody.

        **参数解释**： 屏蔽规则ID,可选。 **约束限制**： 不涉及。 **取值范围**： 以nm开头，后跟[0,62]个英文或数字。 **默认取值**： 不涉及。 

        :param mask_id: The mask_id of this ListNotificationMaskRequestBody.
        :type mask_id: str
        """
        self._mask_id = mask_id

    @property
    def mask_name(self):
        r"""Gets the mask_name of this ListNotificationMaskRequestBody.

        **参数解释**： 屏蔽规则名称,可选。 **约束限制**： 不涉及。 **取值范围**： 只能为字母、数字、汉字、-、_，长度为[1,64]个字符。 **默认取值**： 不涉及。 

        :return: The mask_name of this ListNotificationMaskRequestBody.
        :rtype: str
        """
        return self._mask_name

    @mask_name.setter
    def mask_name(self, mask_name):
        r"""Sets the mask_name of this ListNotificationMaskRequestBody.

        **参数解释**： 屏蔽规则名称,可选。 **约束限制**： 不涉及。 **取值范围**： 只能为字母、数字、汉字、-、_，长度为[1,64]个字符。 **默认取值**： 不涉及。 

        :param mask_name: The mask_name of this ListNotificationMaskRequestBody.
        :type mask_name: str
        """
        self._mask_name = mask_name

    @property
    def mask_status(self):
        r"""Gets the mask_status of this ListNotificationMaskRequestBody.

        **参数解释**： 屏蔽状态,可选。 **约束限制**： 不涉及。 **取值范围**： - MASK_EFFECTIVE：已生效。 - MASK_INEFFECTIVE：未生效。 **默认取值**： 不涉及。 

        :return: The mask_status of this ListNotificationMaskRequestBody.
        :rtype: str
        """
        return self._mask_status

    @mask_status.setter
    def mask_status(self, mask_status):
        r"""Sets the mask_status of this ListNotificationMaskRequestBody.

        **参数解释**： 屏蔽状态,可选。 **约束限制**： 不涉及。 **取值范围**： - MASK_EFFECTIVE：已生效。 - MASK_INEFFECTIVE：未生效。 **默认取值**： 不涉及。 

        :param mask_status: The mask_status of this ListNotificationMaskRequestBody.
        :type mask_status: str
        """
        self._mask_status = mask_status

    @property
    def resource_id(self):
        r"""Gets the resource_id of this ListNotificationMaskRequestBody.

        **参数解释**： 资源维度值,提供一个维度的资源ID即可,可选 **约束限制**： 不涉及。 **取值范围**： 长度为[1,700]个字符。 **默认取值**： 不涉及。 

        :return: The resource_id of this ListNotificationMaskRequestBody.
        :rtype: str
        """
        return self._resource_id

    @resource_id.setter
    def resource_id(self, resource_id):
        r"""Sets the resource_id of this ListNotificationMaskRequestBody.

        **参数解释**： 资源维度值,提供一个维度的资源ID即可,可选 **约束限制**： 不涉及。 **取值范围**： 长度为[1,700]个字符。 **默认取值**： 不涉及。 

        :param resource_id: The resource_id of this ListNotificationMaskRequestBody.
        :type resource_id: str
        """
        self._resource_id = resource_id

    @property
    def namespace(self):
        r"""Gets the namespace of this ListNotificationMaskRequestBody.

        **参数解释**： 查询服务的命名空间，各服务命名空间请参阅[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)。 **约束限制**： 不涉及。 **取值范围**： 格式为service.item；service和item必须是字符串，必须以字母开头，只能包含0-9/a-z/A-Z/_。字符串的长度必须在 3 到 32个字符之间。 **默认取值**： 不涉及。 

        :return: The namespace of this ListNotificationMaskRequestBody.
        :rtype: str
        """
        return self._namespace

    @namespace.setter
    def namespace(self, namespace):
        r"""Sets the namespace of this ListNotificationMaskRequestBody.

        **参数解释**： 查询服务的命名空间，各服务命名空间请参阅[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)。 **约束限制**： 不涉及。 **取值范围**： 格式为service.item；service和item必须是字符串，必须以字母开头，只能包含0-9/a-z/A-Z/_。字符串的长度必须在 3 到 32个字符之间。 **默认取值**： 不涉及。 

        :param namespace: The namespace of this ListNotificationMaskRequestBody.
        :type namespace: str
        """
        self._namespace = namespace

    @property
    def dimensions(self):
        r"""Gets the dimensions of this ListNotificationMaskRequestBody.

        **参数解释**： 资源的维度信息 **约束限制**： 包含的维度信息数量为[1,4]个。 

        :return: The dimensions of this ListNotificationMaskRequestBody.
        :rtype: list[:class:`huaweicloudsdkces.v2.ResourceDimension`]
        """
        return self._dimensions

    @dimensions.setter
    def dimensions(self, dimensions):
        r"""Sets the dimensions of this ListNotificationMaskRequestBody.

        **参数解释**： 资源的维度信息 **约束限制**： 包含的维度信息数量为[1,4]个。 

        :param dimensions: The dimensions of this ListNotificationMaskRequestBody.
        :type dimensions: list[:class:`huaweicloudsdkces.v2.ResourceDimension`]
        """
        self._dimensions = dimensions

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListNotificationMaskRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
