# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateAlarmRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'alarm_id': 'str',
        'body': 'UpdateAlarmRequestBody'
    }

    attribute_map = {
        'alarm_id': 'alarm_id',
        'body': 'body'
    }

    def __init__(self, alarm_id=None, body=None):
        r"""UpdateAlarmRequest

        The model defined in huaweicloud sdk

        :param alarm_id: **参数解释**： 告警规则ID， **约束限制**： 不涉及。 **取值范围**： 以al开头，后跟22位由字母或数字组成的字符串。长度为24个字符。 **默认取值**： 不涉及。 
        :type alarm_id: str
        :param body: Body of the UpdateAlarmRequest
        :type body: :class:`huaweicloudsdkces.v1.UpdateAlarmRequestBody`
        """
        
        

        self._alarm_id = None
        self._body = None
        self.discriminator = None

        self.alarm_id = alarm_id
        if body is not None:
            self.body = body

    @property
    def alarm_id(self):
        r"""Gets the alarm_id of this UpdateAlarmRequest.

        **参数解释**： 告警规则ID， **约束限制**： 不涉及。 **取值范围**： 以al开头，后跟22位由字母或数字组成的字符串。长度为24个字符。 **默认取值**： 不涉及。 

        :return: The alarm_id of this UpdateAlarmRequest.
        :rtype: str
        """
        return self._alarm_id

    @alarm_id.setter
    def alarm_id(self, alarm_id):
        r"""Sets the alarm_id of this UpdateAlarmRequest.

        **参数解释**： 告警规则ID， **约束限制**： 不涉及。 **取值范围**： 以al开头，后跟22位由字母或数字组成的字符串。长度为24个字符。 **默认取值**： 不涉及。 

        :param alarm_id: The alarm_id of this UpdateAlarmRequest.
        :type alarm_id: str
        """
        self._alarm_id = alarm_id

    @property
    def body(self):
        r"""Gets the body of this UpdateAlarmRequest.

        :return: The body of this UpdateAlarmRequest.
        :rtype: :class:`huaweicloudsdkces.v1.UpdateAlarmRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this UpdateAlarmRequest.

        :param body: The body of this UpdateAlarmRequest.
        :type body: :class:`huaweicloudsdkces.v1.UpdateAlarmRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateAlarmRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
