from __future__ import annotations

import unittest

from gauntlet.layer1.llms_slim import slim_llms_text


LLMS_FIXTURE = """# Steel Documentation

Quick Reference

Use the `STEEL_API_KEY` environment variable when calling `https://api.steel.dev`.
Send it as the `steel-api-key` request header.

## Agent Instructions

```python
from steel import Steel
client = Steel(api_key="...")
```

```js
import puppeteer from "puppeteer"
```

## Documentation Index

- [Cookbook 1](https://docs.steel.dev/cookbook/1)
- [Cookbook 2](https://docs.steel.dev/cookbook/2)
- [Cookbook 3](https://docs.steel.dev/cookbook/3)
- [Cookbook 4](https://docs.steel.dev/cookbook/4)
- [Cookbook 5](https://docs.steel.dev/cookbook/5)
- [Cookbook 6](https://docs.steel.dev/cookbook/6)
- [Integrations 1](https://docs.steel.dev/integrations/1)
- [Integrations 2](https://docs.steel.dev/integrations/2)
- [Integrations 3](https://docs.steel.dev/integrations/3)
- [Integrations 4](https://docs.steel.dev/integrations/4)
- [Changelog #000](https://docs.steel.dev/changelog/000)

## Concepts

Short conceptual content that should survive slimming.
"""


class SlimLlmsTextTests(unittest.TestCase):
    def setUp(self) -> None:
        self.raw = LLMS_FIXTURE
        self.slim = slim_llms_text(self.raw)

    def test_prelude_and_quick_reference_survive(self) -> None:
        self.assertIn("# Steel Documentation", self.slim)
        self.assertIn("Quick Reference", self.slim)
        self.assertIn("STEEL_API_KEY", self.slim)
        self.assertIn("https://api.steel.dev", self.slim)
        self.assertIn("steel-api-key", self.slim)

    def test_code_cheatsheet_section_is_dropped(self) -> None:
        self.assertNotIn("Agent Instructions", self.slim)
        self.assertNotIn("import puppeteer", self.slim)
        self.assertNotIn("from steel import Steel", self.slim)
        self.assertNotIn("```python", self.slim)
        self.assertNotIn("```js", self.slim)

    def test_manifest_link_list_is_dropped(self) -> None:
        self.assertNotIn("docs.steel.dev/cookbook", self.slim)
        self.assertNotIn("docs.steel.dev/integrations", self.slim)
        self.assertNotIn("Changelog #000", self.slim)

    def test_footer_directs_to_ground_docs(self) -> None:
        self.assertIn("ground_docs", self.slim)

    def test_meaningful_size_reduction(self) -> None:
        ratio = len(self.slim) / len(self.raw)
        self.assertLess(ratio, 0.50, f"slim is only {ratio:.0%} smaller than raw")

    def test_idempotent(self) -> None:
        twice = slim_llms_text(self.slim)
        self.assertEqual(twice.strip(), self.slim.strip())

    def test_empty_input_returns_empty(self) -> None:
        self.assertEqual(slim_llms_text(""), "")


if __name__ == "__main__":
    unittest.main()
