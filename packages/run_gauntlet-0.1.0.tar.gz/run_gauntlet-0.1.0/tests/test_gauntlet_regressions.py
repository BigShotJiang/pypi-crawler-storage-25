from __future__ import annotations

import tempfile
import unittest
import json
from pathlib import Path
from unittest.mock import patch

from gauntlet.layer1.llms_docs import _chunk_allowed_for_intents
from gauntlet.layer2.agent_runner import (
    _extract_file_refs,
    _extract_public_urls,
    _generate_execution_profile,
    _initial_grounding_validation_errors,
    _is_uncertainty_resolution_action,
    _json_shape_summary,
    _materialize_large_outputs,
    _prepare_tool_runtime_arguments,
    _uncertainty_resolution_for_result,
    _uncertainty_validation_errors,
    _validate_tool_arguments,
)
from gauntlet.layer3.aggregate_runs import aggregate_judged_runs
from gauntlet.layer3.judge_run import _reconcile_outcome_with_classification
from gauntlet.layer3.reasoning_judge import JudgeConfig, run_reasoning_judge
from gauntlet.layer3.verify_task import verify_task
from gauntlet.task_validation import direct_http_usage, is_direct_http_tool_call


PROMPT_1 = (
    "Use the Steel CLI to open https://docs.python.org/3/tutorial/introduction.html, scrape the page, "
    "save a full-page screenshot, and generate a PDF. Then give me a short summary of the page and "
    "tell me where the screenshot and PDF were saved."
)

PROMPT_2 = (
    "Using the Steel REST API directly, fetch https://news.ycombinator.com/ and return the page title, "
    "the first 10 story titles, and the first 10 outbound links."
)


def _ten_items(prefix: str) -> str:
    return "\n".join(f"{index}. {prefix} {index}" for index in range(1, 11))


class GauntletRegressionTests(unittest.TestCase):
    def test_prompt1_json_artifact_reference_is_suspect_success(self) -> None:
        run = {
            "task": PROMPT_1,
            "status": "completed",
            "run_status": "completed",
            "steps": [
                {
                    "step": 1,
                    "tool": {"name": "run_cli", "arguments": {"command": ["steel", "scrape"]}},
                    "tool_result": {"ok": True, "stdout": "{}"},
                }
            ],
            "final_response": (
                "The page is an informal introduction to Python covering arithmetic, strings, lists, "
                "and the interactive interpreter. The screenshot and PDF were generated, but the exact "
                "filenames are available in $steps[4].artifacts.stdout_json."
            ),
        }

        result = verify_task(run)

        self.assertEqual(result["task_status"], "suspect_success")
        self.assertIn("missing_required_output", result["failure_labels"])

    def test_recovered_401_is_success_not_blocked_by_credentials(self) -> None:
        final_response = (
            "Page Title: Hacker News\n\n"
            "First 10 Story Titles:\n"
            f"{_ten_items('Story')}\n\n"
            "First 10 Outbound Links:\n"
            + "\n".join(f"{index}. https://example.com/{index}" for index in range(1, 11))
        )
        run = {
            "task": PROMPT_2,
            "status": "completed",
            "run_status": "completed",
            "steps": [
                {
                    "step": 1,
                    "tool": {"name": "run_http", "arguments": {"method": "POST", "url": "https://api.steel.dev/v1/scrape"}},
                    "tool_result": {"ok": False, "error": "HTTP request returned status 401", "status": 401},
                },
                {
                    "step": 2,
                    "tool": {
                        "name": "run_cli",
                        "arguments": {
                            "command": "curl -H 'steel-api-key: $STEEL_API_KEY' https://api.steel.dev/v1/scrape",
                            "shell": True,
                        },
                    },
                    "tool_result": {"ok": True, "stdout": "{}"},
                },
            ],
            "final_response": final_response,
        }

        result = verify_task(run)

        self.assertEqual(result["task_status"], "success")
        self.assertIn("initial_auth_error_recovered", result["failure_labels"])

    def test_prompt2_structured_final_aliases_satisfy_required_outputs(self) -> None:
        run = {
            "task": PROMPT_2,
            "status": "completed",
            "run_status": "completed",
            "steps": [
                {
                    "step": 1,
                    "tool": {"name": "run_cli", "arguments": {"command": "curl https://api.example.test/v1/scrape", "shell": True}},
                    "tool_result": {"ok": True, "stdout": "{}"},
                }
            ],
            "final_response": json.dumps(
                {
                    "page_title": "Hacker News",
                    "story_titles": [f"Story {index}" for index in range(1, 11)],
                    "outbound_links": [f"https://news.ycombinator.com/item?id={index}" for index in range(1, 11)],
                }
            ),
        }

        result = verify_task(run)

        self.assertEqual(result["task_status"], "success")
        self.assertEqual(result["missing_outputs"], [])
        self.assertEqual(result["normalized_outputs"]["page_title"], "Hacker News")

    def test_curl_via_run_cli_counts_as_direct_http(self) -> None:
        run = {
            "steps": [
                {
                    "step": 1,
                    "tool": {
                        "name": "run_cli",
                        "arguments": {"command": "curl https://api.example.test/v1/scrape", "shell": True},
                    },
                }
            ]
        }

        usages = direct_http_usage(run)

        self.assertTrue(usages)
        self.assertEqual(usages[0]["tool"], "run_cli")
        self.assertTrue(is_direct_http_tool_call("run_http", {}))

    def test_run_http_literal_env_is_rejected_before_request(self) -> None:
        with self.assertRaisesRegex(ValueError, "run_http does not expand shell variables"):
            _prepare_tool_runtime_arguments(
                "run_http",
                {"headers": {"steel-api-key": "$STEEL_API_KEY"}},
                run_record={},
            )

    def test_run_python_stdin_read_requires_explicit_stdin(self) -> None:
        with self.assertRaisesRegex(ValueError, "reads from stdin"):
            _prepare_tool_runtime_arguments(
                "run_python",
                {"code": "import sys\nprint(sys.stdin.read())"},
                run_record={},
            )

    def test_batch_summary_counts_task_statuses(self) -> None:
        judged_runs = [
            {
                "prompt_id": "1",
                "run_key": "1_a",
                "persona": "a",
                "task": PROMPT_1,
                "run_path": "run-a.json",
                "outcome": {"run_status": "completed", "task_status": "suspect_success", "is_suspect_success": True, "task_verification": {"failure_labels": ["missing_required_output"]}},
                "classification": {"primary_error_class": "false-success", "blame_surface": "agent"},
                "evidence": {},
                "recommendations": [],
                "judgment": {},
            },
            {
                "prompt_id": "2",
                "run_key": "2_a",
                "persona": "a",
                "task": PROMPT_2,
                "run_path": "run-b.json",
                "outcome": {"run_status": "completed", "task_status": "success", "is_suspect_success": False, "task_verification": {"failure_labels": []}},
                "classification": {"primary_error_class": None, "blame_surface": None},
                "evidence": {},
                "recommendations": [],
                "judgment": {},
            },
        ]

        summary = aggregate_judged_runs(judged_runs, batch_name="fixture")

        self.assertEqual(summary["failed_runs"], 0)
        self.assertEqual(summary["failed_tasks"], 1)
        self.assertEqual(summary["suspect_successes"], 1)
        self.assertEqual(summary["task_status_breakdown"]["suspect_success"], 1)

    def test_judge_false_success_reconciles_success_outcome(self) -> None:
        outcome = {
            "run_status": "completed",
            "task_status": "success",
            "is_suspect_success": False,
            "task_unsatisfied": False,
            "final_answer_supported_by_tools": True,
            "task_verification": {"failure_labels": []},
        }
        classification = {
            "primary_error_class": "false-success",
            "secondary_error_classes": [],
            "blame_surface": "agent",
        }

        reconciled = _reconcile_outcome_with_classification(outcome, classification)

        self.assertEqual(reconciled["task_status"], "suspect_success")
        self.assertTrue(reconciled["is_suspect_success"])
        self.assertTrue(reconciled["task_unsatisfied"])
        self.assertFalse(reconciled["final_answer_supported_by_tools"])
        self.assertEqual(reconciled["original_task_status"], "success")
        self.assertIn("false_success_judged", reconciled["task_verification"]["failure_labels"])

    def test_aggregate_reclassifies_judged_false_success_as_suspect(self) -> None:
        judged_runs = [
            {
                "prompt_id": "2",
                "run_key": "2_chaotic",
                "persona": "chaotic",
                "task": PROMPT_2,
                "run_path": "run-chaotic.json",
                "outcome": {
                    "run_status": "completed",
                    "task_status": "success",
                    "is_suspect_success": False,
                    "task_verification": {"failure_labels": []},
                },
                "classification": {
                    "primary_error_class": "false-success",
                    "secondary_error_classes": [],
                    "blame_surface": "agent",
                },
                "evidence": {},
                "recommendations": [],
                "judgment": {},
            }
        ]

        summary = aggregate_judged_runs(judged_runs, batch_name="fixture")

        self.assertEqual(summary["successful_tasks"], 0)
        self.assertEqual(summary["failed_tasks"], 1)
        self.assertEqual(summary["suspect_successes"], 1)
        self.assertEqual(summary["task_status_breakdown"]["suspect_success"], 1)
        self.assertEqual(summary["run_rows"][0]["task_status"], "suspect_success")
        self.assertTrue(summary["run_rows"][0]["is_suspect_success"])
        self.assertIn("false_success_judged", summary["run_rows"][0]["failure_labels"])
        self.assertEqual(summary["issue_groups"][0]["affected_runs"], ["2_chaotic"])

    def test_provider_failure_is_not_missing_output_or_schema_mismatch(self) -> None:
        run = {
            "task": PROMPT_1,
            "status": "failed",
            "run_status": "crashed",
            "task_status": "blocked_by_provider",
            "failure": {"type": "model_call_failed", "error": "Gemini response did not contain text output"},
            "final_response": None,
            "steps": [],
        }

        result = verify_task(run)

        self.assertEqual(result["task_status"], "blocked_by_provider")
        self.assertEqual(result["failure_labels"], ["provider_failure"])

    def test_protocol_relative_artifact_urls_are_public_urls_not_files(self) -> None:
        payload = {"data": {"pdf": "//files.steel.dev/run.pdf", "screenshot": "//images.steel.dev/run.png"}}

        self.assertEqual(
            _extract_public_urls(payload),
            ["https://files.steel.dev/run.pdf", "https://images.steel.dev/run.png"],
        )
        self.assertEqual(_extract_file_refs(payload), [])

    def test_artifact_map_records_json_shape(self) -> None:
        with tempfile.TemporaryDirectory() as workspace:
            run_record = {"workspace": workspace}
            result = {
                "ok": True,
                "stdout": '{"data":{"content":"hello","links":[{"href":"https://example.com"}],"metadata":{},"pdf":"//files.steel.dev/a.pdf","screenshot":"//images.steel.dev/a.png"}}',
            }

            artifacts = _materialize_large_outputs(
                tool_name="run_cli",
                tool_result=result,
                step=2,
                workspace_dir=workspace,
                run_record=run_record,
            )

            stdout_json = Path(workspace) / artifacts["stdout_json"]
            self.assertTrue(stdout_json.exists())
            shape = run_record["artifact_map"]["2"]["stdout_json_shape"]
            self.assertIn("data", shape)
            self.assertIn("links", shape["data"])
            paths = run_record["artifact_map"]["2"]["stdout_json_paths"]
            self.assertIn("data.links[].href: str", paths)
            self.assertIn("data.screenshot: str", paths)
            self.assertIn("https://files.steel.dev/a.pdf", run_record["artifact_map"]["2"]["public_urls"])

    def test_cli_boolean_flag_values_are_rejected_from_generic_examples(self) -> None:
        profile = _generate_execution_profile(
            {
                "llms_full_text": "Example:\nacme scrape https://example.com --json --pdf --screenshot\n",
                "llms_text": "",
            }
        )
        errors = _validate_tool_arguments(
            "run_cli",
            {"command": ["acme", "scrape", "https://docs.python.org", "--screenshot", "shot.png", "--pdf=page.pdf"]},
            generated_profile=profile,
        )

        self.assertEqual([error["type"] for error in errors], ["cli_boolean_flag_value", "cli_boolean_flag_value"])

    def test_cli_contracts_are_generated_from_generic_option_sections(self) -> None:
        profile = _generate_execution_profile(
            {
                "llms_full_text": (
                    "Usage: acme scrape [OPTIONS] [URL]\n\n"
                    "Options:\n"
                    "  --json                 Return JSON output.\n"
                    "  --screenshot           Capture a screenshot.\n"
                    "  --pdf                  Generate a PDF.\n"
                    "  --output PATH          Write output to a path.\n"
                    "  --timeout <seconds>    Request timeout.\n"
                ),
                "llms_text": "",
            }
        )

        contract = profile["cli_contracts"]["acme scrape"]
        self.assertIn("--screenshot", contract["boolean_flags"])
        self.assertIn("--pdf", contract["boolean_flags"])
        self.assertIn("--output", contract["value_flags"])
        self.assertIn("--timeout", contract["value_flags"])

        boolean_errors = _validate_tool_arguments(
            "run_cli",
            {"command": ["acme", "scrape", "--screenshot", "shot.png", "https://example.com"]},
            generated_profile=profile,
        )
        value_errors = _validate_tool_arguments(
            "run_cli",
            {"command": ["acme", "scrape", "--output", "--json", "https://example.com"]},
            generated_profile=profile,
        )

        self.assertEqual(boolean_errors[0]["type"], "cli_boolean_flag_value")
        self.assertEqual(value_errors[0]["type"], "cli_value_flag_missing_value")

    def test_first_cli_execution_with_unverified_flags_requires_grounding(self) -> None:
        profile = _generate_execution_profile(
            {
                "llms_full_text": "Example:\nacme scrape https://example.com --raw\n",
                "llms_text": "",
            }
        )

        blocked = _initial_grounding_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "https://example.com", "--screenshot", "shot.png"]},
            run_record={"steps": []},
            generated_profile=profile,
        )
        help_allowed = _initial_grounding_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "--help"]},
            run_record={"steps": []},
            generated_profile=profile,
        )
        documented_allowed = _initial_grounding_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "https://example.com", "--raw"]},
            run_record={"steps": []},
            generated_profile=profile,
        )
        after_grounding_allowed = _initial_grounding_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "https://example.com", "--screenshot", "shot.png"]},
            run_record={
                "steps": [
                    {
                        "tool": {"name": "ground_docs", "arguments": {"task": "use acme"}},
                        "tool_result": {"ok": True},
                    }
                ]
            },
            generated_profile=profile,
        )

        self.assertEqual(blocked[0]["type"], "initial_grounding_required")
        self.assertEqual(help_allowed, [])
        self.assertEqual(documented_allowed, [])
        self.assertEqual(after_grounding_allowed, [])

    def test_top_level_help_does_not_ground_subcommand_flags(self) -> None:
        profile = _generate_execution_profile(
            {
                "llms_full_text": "Example:\nacme scrape https://example.com\n",
                "llms_text": "",
            }
        )
        run_record = {
            "steps": [
                {
                    "tool": {"name": "run_cli", "arguments": {"command": ["acme", "--help"]}},
                    "tool_result": {"ok": True},
                }
            ]
        }

        blocked = _initial_grounding_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "https://example.com", "--output", "out.md"]},
            run_record=run_record,
            generated_profile=profile,
        )

        self.assertEqual(blocked[0]["type"], "initial_grounding_required")

    def test_matching_subcommand_help_grounds_subcommand_flags(self) -> None:
        profile = _generate_execution_profile(
            {
                "llms_full_text": "Example:\nacme scrape https://example.com\n",
                "llms_text": "",
            }
        )
        run_record = {
            "steps": [
                {
                    "tool": {"name": "run_cli", "arguments": {"command": ["acme", "scrape", "--help"]}},
                    "tool_result": {"ok": True},
                }
            ]
        }

        errors = _initial_grounding_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "https://example.com", "--output", "out.md"]},
            run_record=run_record,
            generated_profile=profile,
        )

        self.assertEqual(errors, [])

    def test_run_python_local_artifact_analysis_does_not_require_product_grounding(self) -> None:
        errors = _initial_grounding_validation_errors(
            "run_python",
            {
                "code": (
                    "import json\n"
                    "with open('.gauntlet_artifacts/step_2_run_cli_stdout.json') as f:\n"
                    "    data = json.load(f)\n"
                    "print(type(data), data.keys())\n"
                )
            },
            run_record={"steps": []},
            generated_profile={},
        )

        self.assertEqual(errors, [])

    def test_run_python_product_execution_still_requires_grounding(self) -> None:
        errors = _initial_grounding_validation_errors(
            "run_python",
            {
                "code": (
                    "import requests\n"
                    "response = requests.post('https://api.example.test/v1/scrape', json={'url': 'https://example.com'})\n"
                    "print(response.json())\n"
                )
            },
            run_record={"steps": []},
            generated_profile={},
        )

        self.assertEqual(errors[0]["type"], "initial_grounding_required")

    def test_uncertainty_gate_blocks_guess_after_parse_failure_until_inspection(self) -> None:
        pending = _uncertainty_resolution_for_result(
            "run_python",
            {"ok": False, "error_type": "CommandExitCode", "stderr": "Traceback...\nKeyError: 'data'"},
        )
        self.assertIsNotNone(pending)
        runtime = {"pending_uncertainty_resolution": pending}

        blocked = _uncertainty_validation_errors(
            "run_python",
            {"code": "import json\nprint(json.load(open('result.json'))['base64'])"},
            runtime,
        )
        allowed = _uncertainty_validation_errors(
            "run_python",
            {"code": "import json\nwith open('.gauntlet_artifacts/step_3_run_cli_stdout.json') as f:\n data=json.load(f)\nprint(type(data), data.keys())"},
            runtime,
        )

        self.assertEqual(blocked[0]["type"], "uncertainty_resolution_required")
        self.assertEqual(allowed, [])
        self.assertTrue(
            _is_uncertainty_resolution_action(
                "run_python",
                {"code": "print(open('.gauntlet_artifacts/step_3_run_cli_stdout.json').read()[:200])"},
                pending,
            )
        )

    def test_uncertainty_gate_allows_help_after_cli_usage_error(self) -> None:
        pending = _uncertainty_resolution_for_result(
            "run_cli",
            {"ok": False, "error_type": "CommandExitCode", "stderr": "error: unexpected argument '--output' found\nUsage: acme scrape [OPTIONS]"},
        )
        self.assertIsNotNone(pending)

        blocked = _uncertainty_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "--output", "file.json", "https://example.com"]},
            {"pending_uncertainty_resolution": pending},
        )
        allowed = _uncertainty_validation_errors(
            "run_cli",
            {"command": ["acme", "scrape", "--help"]},
            {"pending_uncertainty_resolution": pending},
        )

        self.assertEqual(blocked[0]["type"], "uncertainty_resolution_required")
        self.assertEqual(allowed, [])

    def test_rest_body_contract_is_generated_from_ingested_curl_docs(self) -> None:
        profile = _generate_execution_profile(
            {
                "llms_full_text": (
                    "Use the REST API directly:\n"
                    "curl -X POST https://api.example.test/v1/scrape "
                    "-H 'content-type: application/json' "
                    "-d '{\"url\":\"https://example.com\"}'\n"
                ),
                "llms_text": "",
            }
        )

        errors = _validate_tool_arguments(
            "run_http",
            {"method": "POST", "url": "https://api.example.test/v1/scrape", "body": {}},
            generated_profile=profile,
        )
        ok_errors = _validate_tool_arguments(
            "run_http",
            {"method": "POST", "url": "https://api.example.test/v1/scrape", "body": {"url": "https://example.com"}},
            generated_profile=profile,
        )

        self.assertEqual(errors[0]["type"], "missing_required_body_field")
        self.assertEqual(errors[0]["missing_fields"], ["url"])
        self.assertEqual(ok_errors, [])

    def test_recommendation_summary_normalizes_scope_and_owner_aliases(self) -> None:
        judged_runs = [
            {
                "prompt_id": "1",
                "run_key": "1_a",
                "persona": "a",
                "task": PROMPT_1,
                "run_path": "run-a.json",
                "outcome": {
                    "run_status": "crashed",
                    "task_status": "blocked_by_provider",
                    "is_suspect_success": False,
                    "task_verification": {"failure_labels": ["provider_failure"]},
                },
                "classification": {"primary_error_class": "provider-failure", "blame_surface": "runtime"},
                "evidence": {},
                "recommendations": [
                    {
                        "priority": "urgent",
                        "scope": "provider-integration",
                        "owner": "agent-runtime-team",
                        "action": "Retry transient empty provider responses.",
                    }
                ],
                "judgment": {},
            }
        ]

        summary = aggregate_judged_runs(judged_runs, batch_name="fixture")

        self.assertEqual(summary["task_status_breakdown"]["blocked_by_provider"], 1)
        self.assertEqual(summary["error_class_breakdown"]["provider-failure"], 1)
        self.assertEqual(summary["top_recommendations"][0]["priority"], "high")
        self.assertEqual(summary["top_recommendations"][0]["scope"], "provider")
        self.assertEqual(summary["top_recommendations"][0]["owner"], "gauntlet")

    def test_retrieval_routing_filters_unrelated_interface_docs(self) -> None:
        replit_chunk = {
            "path_text": "Replit > Requirements",
            "title": "Requirements",
            "preview": "Steel API Key and Replit account",
            "text": "Steel API Key: Any plan; Replit account required.",
        }
        rest_chunk = {
            "path_text": "API Reference > Scrape",
            "title": "REST API scrape",
            "preview": "POST /v1/scrape with steel-api-key",
            "text": "curl -X POST https://api.steel.dev/v1/scrape -H 'steel-api-key: ...'",
        }
        claude_chunk = {
            "path_text": "Claude Code > Resources",
            "title": "Claude Code",
            "preview": "Steel CLI docs link",
            "text": "Steel CLI docs and Claude Code resources.",
        }
        cli_chunk = {
            "path_text": "Steel CLI + Skill > Overview",
            "title": "Steel CLI + Skill",
            "preview": "Run browser automation from terminal",
            "text": "steel scrape https://example.com --json --pdf --screenshot",
        }

        self.assertFalse(_chunk_allowed_for_intents(replit_chunk, ["REST_API"]))
        self.assertTrue(_chunk_allowed_for_intents(rest_chunk, ["REST_API"]))
        self.assertFalse(_chunk_allowed_for_intents(claude_chunk, ["CLI"]))
        self.assertTrue(_chunk_allowed_for_intents(cli_chunk, ["CLI"]))

    def test_llm_judge_schema_completion_handles_empty_repair_fields(self) -> None:
        run = {
            "run_path": "run.json",
            "status": "completed",
            "run_status": "completed",
            "task_status": "success",
            "provider": "fixture",
            "model": "fixture",
            "task": PROMPT_2,
            "prompt_id": "2",
            "run_key": "2_fixture",
            "batch_prompt_count": 1,
            "persona": "fixture",
            "llms_source": None,
            "llms_full_source": None,
            "max_steps": 8,
            "max_format_retries": 1,
            "started_at": None,
            "finished_at": None,
            "docs": {},
            "environment": {},
            "workspace": None,
            "steps": [],
            "final_response": "Page Title: Hacker News\n" + _ten_items("Story"),
            "failure": None,
        }
        evidence = {
            "outcome": {
                "run_status": "completed",
                "task_status": "success",
                "terminal_failure_type": None,
                "completed_with_tool_errors": False,
                "is_suspect_success": False,
                "task_verification": {"failure_labels": []},
            },
            "path_summary": {"docs_consulted": False, "ground_docs_used": False},
            "trace": {
                "execution_trace": [{"step": 1, "kind": "tool", "status": "succeeded"}],
                "reproduction_candidate_steps": [],
                "success_path_steps": [1],
            },
            "first_failing_step": None,
            "failing_tool": None,
            "error": None,
            "error_type": None,
            "repeated_pattern": False,
        }
        docs_context = {
            "relevant_doc_chunks": [],
            "retrieval_diagnostics": {"retrieval_relevance": "irrelevant", "retrieval_notes": "No relevant docs."},
        }
        invalid_first = {
            "summary": "LLM summary",
            "why_it_happened": "LLM why",
            "documentation_evidence": [],
            "trace_evidence": [],
            "classification": {"primary_error_class": "clean-success", "secondary_error_classes": [], "blame_surface": "not_applicable", "classification_confidence": 0.5, "blame_confidence": 0.5},
            "reproduction": {"required": False, "steps": [], "summary": "No reproduction path required."},
            "successful_path": {"steps": [1], "summary": "Successful path."},
            "cross_agent_comparison": {},
            "confidence": {"classification_confidence": 0.5, "blame_confidence": 0.5},
            "recommendations": [],
            "doc_assessment": {"retrieval_relevance": "irrelevant", "retrieval_notes": "No relevant docs."},
            "why_docs_should_have_prevented_it": "",
            "counterfactual": "No change needed.",
        }
        invalid_repair = {
            **invalid_first,
            "why_docs_should_have_prevented_it": "Docs were not relevant to this clean run.",
            "reproduction": {"required": False, "steps": [], "summary": ""},
        }

        with patch(
            "gauntlet.layer3.reasoning_judge.send_prompt",
            side_effect=[json.dumps(invalid_first), json.dumps(invalid_repair)],
        ):
            judgment = run_reasoning_judge(
                run,
                evidence,
                docs_context,
                judge_config=JudgeConfig(provider="fixture", model="fixture", fallback_deterministic=True),
            )

        self.assertTrue(judgment["why_docs_should_have_prevented_it"])
        self.assertEqual(judgment["reproduction"]["summary"], "No reproduction path required.")


if __name__ == "__main__":
    unittest.main()
