from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

from gauntlet.layer3.aggregate_runs import _is_agent_side as _is_agent_side_rec


def _safe_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=True, indent=2)
    return str(value)


def _badge(label: str, kind: str) -> str:
    return f'<span class="badge badge-{kind}">{html.escape(str(label))}</span>'


def _owner_chip(label: str) -> str:
    owner = str(label)
    css = {
        "gauntlet": "info",
        "docs-team": "warn",
        "infra": "bad",
        "product-team": "good",
    }.get(owner, "info")
    return f'<span class="badge badge-{css}">{html.escape(owner)}</span>'


def _write(path: str | Path, content: str) -> None:
    target = Path(path).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")


def _base_html(title: str, body: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    :root {{
      --bg: #f4efe5;
      --panel: #fffaf2;
      --ink: #1e1b18;
      --muted: #6e6256;
      --line: #d6c8b7;
      --accent: #a44d1a;
      --accent-2: #204b57;
      --good: #2d6a4f;
      --bad: #9b2226;
      --warn: #b7791f;
      --shadow: 0 14px 40px rgba(42, 31, 21, 0.12);
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: "Avenir Next", "Segoe UI", ui-sans-serif, sans-serif;
      color: var(--ink);
      background:
        radial-gradient(circle at top left, rgba(164,77,26,0.12), transparent 28%),
        linear-gradient(180deg, #efe2d1 0%, var(--bg) 42%);
    }}
    .page {{
      max-width: 1200px;
      margin: 0 auto;
      padding: 32px 20px 64px;
    }}
    .hero {{
      background: linear-gradient(135deg, rgba(255,250,242,0.98), rgba(247,237,222,0.96));
      border: 1px solid rgba(164,77,26,0.16);
      border-radius: 24px;
      padding: 28px;
      box-shadow: var(--shadow);
      margin-bottom: 20px;
    }}
    h1, h2, h3 {{ margin: 0 0 12px; line-height: 1.1; }}
    h1 {{ font-size: 40px; letter-spacing: -0.03em; }}
    h2 {{ font-size: 22px; margin-top: 24px; }}
    h3 {{ font-size: 16px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.08em; }}
    p, li {{ line-height: 1.55; }}
    .subtle {{ color: var(--muted); }}
    .grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 16px;
      margin: 18px 0 0;
    }}
    .card {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 18px;
      padding: 18px;
      box-shadow: var(--shadow);
    }}
    .timeline {{
      display: grid;
      gap: 12px;
    }}
    .timeline-item {{
      border-left: 4px solid var(--line);
      padding: 12px 14px;
      background: rgba(255,255,255,0.75);
      border-radius: 12px;
    }}
    .timeline-item.failed {{ border-left-color: var(--bad); }}
    .timeline-item.succeeded {{ border-left-color: var(--good); }}
    .timeline-item.final {{ border-left-color: var(--accent-2); }}
    .nav {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 14px;
    }}
    .nav a {{
      text-decoration: none;
      color: var(--accent-2);
      background: rgba(32,75,87,0.08);
      border: 1px solid rgba(32,75,87,0.15);
      padding: 8px 12px;
      border-radius: 999px;
      font-size: 13px;
      font-weight: 700;
    }}
    .badge {{
      display: inline-block;
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      margin-right: 6px;
    }}
    .badge-good {{ background: rgba(45,106,79,0.12); color: var(--good); }}
    .badge-bad {{ background: rgba(155,34,38,0.12); color: var(--bad); }}
    .badge-warn {{ background: rgba(183,121,31,0.12); color: var(--warn); }}
    .badge-info {{ background: rgba(32,75,87,0.12); color: var(--accent-2); }}
    code, pre {{
      font-family: "JetBrains Mono", "SFMono-Regular", ui-monospace, monospace;
      font-size: 12px;
    }}
    code {{
      white-space: normal;
      overflow-wrap: anywhere;
      word-break: break-word;
    }}
    pre {{
      white-space: pre-wrap;
      background: #261d17;
      color: #f7f3eb;
      border-radius: 14px;
      padding: 14px;
      overflow-wrap: anywhere;
    }}
    pre code {{
      white-space: inherit;
    }}
    table {{
      width: 100%;
      table-layout: fixed;
      border-collapse: collapse;
      font-size: 14px;
    }}
    th, td {{
      padding: 12px;
      border-bottom: 1px solid var(--line);
      text-align: left;
      vertical-align: top;
      min-width: 0;
      overflow-wrap: anywhere;
      word-break: break-word;
    }}
    th {{ color: var(--muted); font-weight: 700; }}
    details {{
      border: 1px solid var(--line);
      border-radius: 14px;
      padding: 12px 14px;
      background: rgba(255,255,255,0.7);
    }}
    summary {{
      cursor: pointer;
      font-weight: 700;
    }}
    .section {{ margin-top: 22px; }}
    .kpi {{
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -0.04em;
    }}
    .metric-list {{
      display: grid;
      gap: 10px;
    }}
    .metric-row {{
      display: flex;
      justify-content: space-between;
      gap: 20px;
      padding: 10px 0;
      border-bottom: 1px dashed var(--line);
    }}
    .metric-row:last-child {{
      border-bottom: 0;
    }}
  </style>
</head>
<body>
  <div class="page">
    {body}
  </div>
</body>
</html>"""


def render_summary_html(summary: dict[str, Any]) -> str:
    prompt_mapping = summary.get("prompt_mapping", {})

    rows = []
    for row in summary["run_rows"]:
        status_badge = _badge(row["run_status"], "good" if row["run_status"] == "completed" else "bad")
        task_kind = "good" if row.get("task_status") == "success" else ("warn" if row.get("task_status") == "suspect_success" else "bad")
        task_badge = _badge(row.get("task_status") or "unknown", task_kind)
        suspect = _badge("suspect", "bad") if row["is_suspect_success"] else ""
        rows.append(
            f"<tr><td><a href=\"#run-{html.escape(str(row['run_key']))}\">{html.escape(str(row['run_key']))}</a></td><td>{html.escape(str(row['prompt_text']))}</td><td>{status_badge} {suspect}</td><td>{task_badge}</td><td>{html.escape(str(row['primary_error_class']))}</td><td>{html.escape(str(row['blame_surface']))}</td><td><code>{html.escape(str(row['run_path']))}</code></td></tr>"
        )

    nav_links = "".join(
        f'<a href="#run-{html.escape(run["run_key"])}">{html.escape(run["run_key"])}</a>'
        for run in summary.get("judged_runs", [])
    )

    fingerprint_rows = "".join(
        f'<div class="metric-row"><span><code>{html.escape(item["fingerprint"])}</code></span><strong>{item["count"]}</strong></div>'
        for item in summary.get("top_issue_fingerprints", [])
    ) or '<div class="metric-row"><span>No repeated issue fingerprints.</span><strong>0</strong></div>'

    recommendation_rows = "".join(
        f'<div class="metric-row"><span><strong>{html.escape(item["priority"])}</strong> · {html.escape(item["scope"])} · {_owner_chip(item["owner"])}<br>{html.escape(item["action"])}</span><strong>{item["count"]}</strong></div>'
        for item in summary.get("top_recommendations", [])
    ) or '<div class="metric-row"><span>No aggregate recommendations.</span><strong>0</strong></div>'

    agent_side_recommendation_rows = "".join(
        f'<div class="metric-row"><span>{_badge("not your fix", "warn")} <strong>{html.escape(item["priority"])}</strong> · {html.escape(item["scope"])} · {_owner_chip(item["owner"])}<br>{html.escape(item["action"])}</span><strong>{item["count"]}</strong></div>'
        for item in summary.get("agent_side_recommendations", [])
    ) or '<div class="metric-row"><span>No agent-side recommendations.</span><strong>0</strong></div>'

    cross_agent_rows = "".join(
        f'<div class="metric-row"><span>{html.escape(item["summary"])}</span><strong>{item["count"]}</strong></div>'
        for item in summary.get("cross_agent_patterns", [])
    ) or '<div class="metric-row"><span>No cross-agent comparison patterns.</span><strong>0</strong></div>'

    issue_rows = "".join(
        f"<tr><td><code>{html.escape(item['issue_id'])}</code></td><td>{html.escape(item['title'])}</td><td>{_badge(item['severity'], 'bad' if item['severity'] == 'high' else 'warn')}</td><td>{html.escape(', '.join(item['affected_runs']))}</td><td>{html.escape(item['primary_blame_surface'])}</td><td>{_owner_chip(item['recommended_owner'])}</td><td>{html.escape(item['recommended_fix'])}</td></tr>"
        for item in summary.get("issue_groups", [])
    ) or '<tr><td colspan="7">No repeated issues.</td></tr>'

    run_sections = []
    for run in summary.get("judged_runs", []):
        outcome = run["outcome"]
        classification = run["classification"]
        evidence = run["evidence"]
        trace = run["trace"]
        judgment = run.get("judgment") or {}
        prompt_text = prompt_mapping.get(str(run["prompt_id"]), run["task"])

        badges = [_badge(f"run: {outcome['run_status']}", "good" if outcome["run_status"] == "completed" else "bad")]
        task_status = outcome.get("task_status") or "unknown"
        badges.append(_badge(f"task: {task_status}", "good" if task_status == "success" else ("warn" if task_status == "suspect_success" else "bad")))
        if classification["primary_error_class"] is not None:
            badges.append(_badge(classification["primary_error_class"], "warn"))
        if classification["blame_surface"] is not None:
            badges.append(_badge(classification["blame_surface"], "info"))
        if outcome["is_suspect_success"]:
            badges.append(_badge("suspect success", "bad"))
        task_verification = outcome.get("task_verification") or {}
        for label in task_verification.get("failure_labels", []):
            badges.append(_badge(str(label), "bad"))

        timeline_items = []
        for item in trace["execution_trace"]:
            kind = item["kind"]
            status = item["status"]
            css_class = "final" if kind == "final" else status
            body = html.escape(_safe_text(item.get("response") or item.get("error") or ""))
            header = f"Step {item['step']}"
            if kind == "tool":
                header += f": {item['tool']}"
            elif kind == "final":
                header += ": final"
            timeline_items.append(
                f'<div class="timeline-item {css_class}"><strong>{header}</strong><div class="subtle">{html.escape(status)}</div><p>{body}</p></div>'
            )

        docs_rows = []
        for chunk in judgment.get("documentation_evidence", evidence.get("relevant_doc_chunks", [])):
            location = ""
            if chunk.get("line_start") is not None and chunk.get("line_end") is not None:
                location = f"lines {chunk.get('line_start')}-{chunk.get('line_end')}"
            elif chunk.get("source_text"):
                location = str(chunk.get("source_text"))
            docs_rows.append(
                f"<tr><td><code>{html.escape(str(chunk.get('chunk_id') or chunk.get('citation_id')))}</code></td><td>{html.escape(str(chunk.get('path_text')))}<br><span class=\"subtle\">{html.escape(location)}</span></td><td>{html.escape(str(chunk.get('why_relevant')))}<br><pre>{html.escape(str(chunk.get('quoted_text') or ''))}</pre></td></tr>"
            )

        recommendations = "".join(
            f"<li>{(_badge('not your fix', 'warn') + ' ') if _is_agent_side_rec(item) else ''}<strong>{html.escape(item['priority'])}</strong> · {html.escape(item['scope'])} · {_owner_chip(item['owner'])}: {html.escape(item['action'])}<br><span class=\"subtle\">{html.escape(item['reason'])}</span></li>"
            for item in run["recommendations"]
        )

        trace_rows = "".join(
            f"<tr><td>{html.escape(str(item.get('step')))}</td><td>{html.escape(str(item.get('kind')))}</td><td>{html.escape(str(item.get('tool')))}</td><td>{html.escape(str(item.get('reason')))}</td></tr>"
            for item in judgment.get("trace_evidence", [])
        )

        reproduction = judgment.get("reproduction", {})
        successful_path = judgment.get("successful_path", {})
        cross_agent = judgment.get("cross_agent_comparison", {})
        environment = (evidence.get("run_metadata") or {}).get("environment") or {}
        retrieval_diagnostics = evidence.get("retrieval_diagnostics") or {}
        if evidence.get("relevant_doc_chunks"):
            retrieval_diagnostics = {
                **retrieval_diagnostics,
                "retrieved_chunk_count": len(evidence.get("relevant_doc_chunks") or []),
            }

        raw_trace = trace.get("raw_error_trace")
        raw_trace_block = ""
        if raw_trace:
            raw_trace_block = f"""
            <details>
              <summary>Raw Error Trace</summary>
              <pre>{html.escape(json.dumps(raw_trace, indent=2, ensure_ascii=True))}</pre>
            </details>
            """

        run_sections.append(
            f"""
            <section class="section card">
              <h2 id="run-{html.escape(run['run_key'])}">{html.escape(run['run_key'])}</h2>
              <p><strong>Prompt {html.escape(str(run['prompt_id']))}:</strong> {html.escape(prompt_text)}</p>
              <p class="subtle">Persona: {html.escape(run['persona'])}</p>
              <div>{''.join(badges)}</div>
              <div class="grid">
                <div class="card">
                  <h3>Outcome</h3>
                  <p><strong>Summary:</strong> {html.escape(_safe_text(run['root_cause']['summary']))}</p>
                  <p><strong>Why it happened:</strong> {html.escape(_safe_text(run['root_cause']['why_it_happened']))}</p>
                  <p><strong>Why docs should have prevented it:</strong> {html.escape(_safe_text(run['root_cause']['why_docs_should_have_prevented_it']))}</p>
                  <p><strong>Counterfactual:</strong> {html.escape(_safe_text(run['root_cause']['counterfactual']))}</p>
                </div>
                <div class="card">
                  <h3>Evidence</h3>
                  <p><strong>First failing step:</strong> {html.escape(str(evidence['first_failing_step']))}</p>
                  <p><strong>Failing tool:</strong> {html.escape(str(evidence['failing_tool']))}</p>
                  <p><strong>Error type:</strong> {html.escape(str(evidence['error_type']))}</p>
                  <p><strong>Docs consulted:</strong> {html.escape(str(evidence['docs_consulted']))}</p>
                  <p><strong>Ground docs used:</strong> {html.escape(str(evidence['ground_docs_used']))}</p>
                  <p><strong>Issue fingerprint:</strong> <code>{html.escape(str(evidence['issue_fingerprint']))}</code></p>
                  <p><strong>Docs sufficient:</strong> {html.escape(str(evidence['doc_assessment']['docs_sufficient']))}</p>
                  <p><strong>Docs followed:</strong> {html.escape(str(evidence['doc_assessment']['docs_followed']))}</p>
                  <p><strong>Docs clarity issue:</strong> {html.escape(str(evidence['doc_assessment']['docs_clarity_issue']))}</p>
                  <p><strong>Retrieval relevance:</strong> {html.escape(str(evidence['doc_assessment']['retrieval_relevance']))}</p>
                  <p><strong>Retrieval notes:</strong> {html.escape(str(evidence['doc_assessment']['retrieval_notes']))}</p>
                </div>
              </div>
              <div class="section grid">
                <div class="card">
                  <h3>Task Verification</h3>
                  <pre>{html.escape(json.dumps(task_verification, indent=2, ensure_ascii=True))}</pre>
                </div>
                <div class="card">
                  <h3>Environment</h3>
                  <pre>{html.escape(json.dumps(environment, indent=2, ensure_ascii=True))}</pre>
                </div>
                <div class="card">
                  <h3>Retrieval Diagnostics</h3>
                  <pre>{html.escape(json.dumps(retrieval_diagnostics, indent=2, ensure_ascii=True))}</pre>
                </div>
              </div>
              <div class="section">
                <h3>Execution Timeline</h3>
                <div class="timeline">{''.join(timeline_items)}</div>
              </div>
              <div class="section">
                <h3>Recommendations</h3>
                <ul>{recommendations}</ul>
              </div>
              <div class="section">
                <h3>Documentation Evidence</h3>
                <table>
                  <thead><tr><th>Chunk</th><th>Path</th><th>Why Relevant</th></tr></thead>
                  <tbody>{''.join(docs_rows)}</tbody>
                </table>
              </div>
              <div class="section grid">
                <div class="card">
                  <h3>Successful Path</h3>
                  <p><strong>Summary:</strong> {html.escape(str(successful_path.get('summary')))}</p>
                  <p><strong>Steps:</strong> {html.escape(', '.join(str(step) for step in successful_path.get('steps', [])) or 'None')}</p>
                </div>
                <div class="card">
                  <h3>Reproduction</h3>
                  <p><strong>Required:</strong> {html.escape(str(reproduction.get('required')))}</p>
                  <p><strong>Summary:</strong> {html.escape(str(reproduction.get('summary')))}</p>
                  <p><strong>Steps:</strong> {html.escape(', '.join(str(step) for step in reproduction.get('steps', [])) or 'None')}</p>
                </div>
              </div>
              <div class="section">
                <h3>Cross-Agent Comparison</h3>
                <p><strong>Summary:</strong> {html.escape(str(cross_agent.get('summary')))}</p>
                <p><strong>Peer count:</strong> {html.escape(str(cross_agent.get('peer_count')))}</p>
                <p><strong>Matching issue count:</strong> {html.escape(str(cross_agent.get('matching_issue_count')))}</p>
                <pre>{html.escape(json.dumps({'divergent_outcomes': cross_agent.get('divergent_outcomes', []), 'common_success_patterns': cross_agent.get('common_success_patterns', [])}, indent=2, ensure_ascii=True))}</pre>
              </div>
              <div class="section">
                <h3>Trace Evidence</h3>
                <table>
                  <thead><tr><th>Step</th><th>Kind</th><th>Tool</th><th>Reason</th></tr></thead>
                  <tbody>{trace_rows}</tbody>
                </table>
              </div>
              <div class="section">
                {raw_trace_block}
              </div>
            </section>
            """
        )

    body = f"""
    <section class="hero">
      <h1>Layer 3 Batch Report</h1>
      <p class="subtle">Batch: {html.escape(summary['batch_name'])}</p>
      <p>This report analyzes one Gauntlet command run end to end. It highlights where execution drifted, where recoveries succeeded, which failures repeated across personas, and which fixes have the highest leverage.</p>
      <div class="grid">
        <div class="card"><h3>Total Runs</h3><div class="kpi">{summary['total_runs']}</div></div>
        <div class="card"><h3>Completed</h3><div class="kpi">{summary['completed_runs']}</div></div>
        <div class="card"><h3>Task Failures</h3><div class="kpi">{summary['failed_tasks']}</div></div>
        <div class="card"><h3>Suspect Successes</h3><div class="kpi">{summary['suspect_successes']}</div></div>
      </div>
      <div class="nav">{nav_links}</div>
    </section>

    <section class="section grid">
      <div class="card">
        <h2>Error Class Breakdown</h2>
        <pre>{html.escape(json.dumps(summary['error_class_breakdown'], indent=2, ensure_ascii=True))}</pre>
      </div>
      <div class="card">
        <h2>Task Status Breakdown</h2>
        <pre>{html.escape(json.dumps(summary.get('task_status_breakdown', {}), indent=2, ensure_ascii=True))}</pre>
      </div>
    </section>

    <section class="section grid">
      <div class="card">
        <h2>Top Issue Fingerprints</h2>
        <div class="metric-list">{fingerprint_rows}</div>
      </div>
      <div class="card">
        <h2>Top Recommended Fixes</h2>
        <p class="subtle">Fixes targeted at your surface (docs, runtime, provider integration).</p>
        <div class="metric-list">{recommendation_rows}</div>
      </div>
    </section>

    <section class="section card">
      <h2>Model / Agent-Side Recommendations <span class="badge badge-warn">not your fix</span></h2>
      <p class="subtle">These are issues with the agent or model provider, not your product. Shown here so they don't drown out your own fixes above.</p>
      <div class="metric-list">{agent_side_recommendation_rows}</div>
    </section>

    <section class="section card">
      <h2>Cross-Agent Comparison</h2>
      <div class="metric-list">{cross_agent_rows}</div>
    </section>

    <section class="section card">
      <h2>Batch Issue Groups</h2>
      <table>
        <thead><tr><th>ID</th><th>Title</th><th>Severity</th><th>Affected Runs</th><th>Blame</th><th>Owner</th><th>Recommended Fix</th></tr></thead>
        <tbody>{issue_rows}</tbody>
      </table>
    </section>

    <section class="section card">
      <h2>Per-Run Results</h2>
      <table>
        <thead><tr><th>Run Key</th><th>Prompt</th><th>Run Status</th><th>Task Status</th><th>Primary Class</th><th>Blame Surface</th><th>Run Path</th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table>
    </section>

    {''.join(run_sections)}
    """
    return _base_html(f"Layer 3 Batch Report - {summary['batch_name']}", body)


def write_summary_outputs(summary: dict[str, Any], json_path: str | Path, html_path: str | Path) -> None:
    _write(json_path, json.dumps(summary, indent=2, ensure_ascii=True))
    _write(html_path, render_summary_html(summary))
