from __future__ import annotations

from typing import Literal, TypedDict


ExecutionStepKind = Literal["tool", "final", "parse_error"]
ExecutionStepStatus = Literal["succeeded", "failed", "completed"]
RunStatus = Literal["completed", "crashed", "timeout"]
TaskStatus = Literal[
    "success",
    "failure",
    "blocked_by_provider",
    "blocked_by_credentials",
    "suspect_success",
    "schema_mismatch",
]

# These labels stay centralized so later stages validate against one source
# of truth instead of re-defining classes ad hoc across modules.
ErrorClass = Literal[
    "artifact-reference-error",
    "stdin-handoff-error",
    "env-expansion-error",
    "schema-mismatch",
    "false-success",
    "provider-failure",
    "recovered-auth-error",
    "clean-success",
    "reasoning/recovery",
    "sdk-usage",
    "tool-contract-error",
]

BlameSurface = Literal[
    "agent",
    "runtime",
    "environment",
    "docs",
    "mixed",
    "not_applicable",
]


ALLOWED_ERROR_CLASSES: tuple[str, ...] = (
    "artifact-reference-error",
    "stdin-handoff-error",
    "env-expansion-error",
    "schema-mismatch",
    "false-success",
    "provider-failure",
    "recovered-auth-error",
    "clean-success",
    "reasoning/recovery",
    "sdk-usage",
    "tool-contract-error",
)

ALLOWED_BLAME_SURFACES: tuple[str, ...] = (
    "agent",
    "runtime",
    "environment",
    "docs",
    "mixed",
    "not_applicable",
)


class NormalizedRun(TypedDict):
    run_path: str
    status: str | None
    run_status: str | None
    task_status: str | None
    provider: str | None
    model: str | None
    task: str
    prompt_id: str
    run_key: str
    batch_prompt_count: int | None
    persona: str
    llms_source: str | None
    llms_full_source: str | None
    max_steps: int | None
    max_format_retries: int | None
    started_at: str | None
    finished_at: str | None
    docs: dict
    environment: dict
    workspace: str | None
    steps: list[dict]
    final_response: str | None
    failure: dict | None


class ExecutionTraceItem(TypedDict, total=False):
    step: int | None
    kind: ExecutionStepKind
    status: ExecutionStepStatus
    tool: str
    response: str
    error_type: str | None
    error: str | None


class FirstFailure(TypedDict, total=False):
    step: int | None
    tool: str | None
    error_type: str | None
    error: str | None
    payload: dict | None


class DerivedSignals(TypedDict):
    has_failures: bool
    docs_consulted: bool
    ground_docs_used: bool
    recovery_attempted: bool
    recovery_succeeded: bool
    adapted_after_error: bool
    repeated_failure_pattern: bool
    completed_after_failure: bool
    has_final_response: bool


class PathSummary(TypedDict):
    tools_used: list[str]
    successful_tools: list[str]
    failed_tools: list[str]
    docs_consulted: bool
    ground_docs_used: bool
    recovery_attempted: bool
    recovery_succeeded: bool


class OutcomeSummary(TypedDict):
    run_status: str | None
    task_status: str | None
    task_verification: dict
    terminal_failure_type: str | None
    has_tool_errors: bool
    completed_with_tool_errors: bool
    steps_count: int


class TracePacket(TypedDict):
    execution_trace: list[ExecutionTraceItem]
    raw_error_trace: dict | None
    final_response: str | None
    success_path_steps: list[int]
    reproduction_candidate_steps: list[int]
    step_details: list[dict]
    first_failure: FirstFailure | None


class EvidencePacket(TypedDict):
    run_path: str
    run_metadata: dict
    task: dict
    agent: dict
    outcome: OutcomeSummary
    path_summary: PathSummary
    derived_signals: DerivedSignals
    first_failing_step: int | None
    failing_tool: str | None
    error_type: str | None
    error: str | None
    issue_fingerprint: str | None
    repeated_pattern: bool
    adapted_after_error: bool
    trace: TracePacket
    raw_failure_facts: dict
    judge_query: dict


class RetrievedDocChunk(TypedDict, total=False):
    citation_id: str
    chunk_id: str | None
    path_text: str | None
    title: str | None
    preview: str | None
    text: str | None
    source_text: str | None
    start_char: int | None
    end_char: int | None
    line_start: int | None
    line_end: int | None
    quoted_text: str | None
    why_relevant: str
    rerank_score: float | None
    anchor_overlap_count: float | None


class DocsContext(TypedDict):
    llms_source: str | None
    llms_full_source: str | None
    manifest: dict | None
    grounding_block: str | None
    retrieval_query: dict | None
    retrieval_diagnostics: dict | None
    relevant_doc_chunks: list[RetrievedDocChunk]


class PeerRunSummary(TypedDict, total=False):
    run_path: str
    prompt_id: str
    run_key: str
    persona: str
    provider: str | None
    model: str | None
    status: str | None
    issue_fingerprint: str | None
    primary_error_class: str | None


class BatchContext(TypedDict):
    prompt_mapping: dict[str, str]
    peer_run_summaries: list[PeerRunSummary]
    common_failure_fingerprints: list[dict]
    common_success_patterns: list[dict]
    divergent_outcomes: list[dict]
    docs_source_summary: dict
    task_cluster_summary: dict


class DocumentationCitation(TypedDict, total=False):
    citation_id: str
    chunk_id: str | None
    path_text: str | None
    why_relevant: str | None
    quoted_text: str | None


class TraceCitation(TypedDict, total=False):
    step: int
    kind: ExecutionStepKind
    tool: str | None
    status: ExecutionStepStatus
    reason: str


class ReproductionPlan(TypedDict):
    required: bool
    steps: list[int]
    summary: str


class SuccessfulPath(TypedDict):
    steps: list[int]
    summary: str


class Recommendation(TypedDict):
    priority: str
    scope: str
    owner: str
    reason: str
    action: str


class Classification(TypedDict):
    primary_error_class: ErrorClass | None
    secondary_error_classes: list[str]
    blame_surface: BlameSurface | None
    classification_confidence: float
    blame_confidence: float


class DocAssessment(TypedDict):
    docs_available: bool
    docs_consulted: bool
    ground_docs_used: bool
    docs_sufficient: bool
    docs_followed: bool | str
    docs_clarity_issue: bool | str
    retrieval_relevance: str
    retrieval_notes: str


class JudgeResult(TypedDict):
    summary: str
    why_it_happened: str
    documentation_evidence: list[DocumentationCitation]
    trace_evidence: list[TraceCitation]
    classification: Classification
    reproduction: ReproductionPlan
    successful_path: SuccessfulPath
    cross_agent_comparison: dict
    confidence: dict
    recommendations: list[Recommendation]
    doc_assessment: DocAssessment
    why_docs_should_have_prevented_it: str
    counterfactual: str


class JudgedRun(TypedDict):
    run_path: str
    status: str
    task: str
    prompt_id: str
    run_key: str
    persona: str
    provider: str | None
    model: str | None
    outcome: dict
    classification: Classification
    evidence: dict
    trace: TracePacket
    root_cause: dict
    recommendations: list[Recommendation]
    judgment: JudgeResult
