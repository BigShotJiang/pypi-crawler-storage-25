from __future__ import annotations

from gauntlet.layer3.contracts import BatchContext, DocsContext, EvidencePacket, JudgeResult, JudgedRun, NormalizedRun
from gauntlet.layer3.reasoning_judge import JudgeConfig, run_reasoning_judge
from gauntlet.layer3.validate_judgment import validate_judgment


def _classification_marks_false_success(classification: dict) -> bool:
    secondary = classification.get("secondary_error_classes") or []
    return classification.get("primary_error_class") == "false-success" or "false-success" in secondary


def _reconcile_outcome_with_classification(outcome: dict, classification: dict) -> dict:
    if not _classification_marks_false_success(classification):
        return outcome

    reconciled = dict(outcome)
    original_status = reconciled.get("task_status")
    verification = dict(reconciled.get("task_verification") or {})
    failure_labels = list(verification.get("failure_labels") or [])
    if "false_success_judged" not in failure_labels:
        failure_labels.append("false_success_judged")

    if original_status == "success":
        reconciled["task_status"] = "suspect_success"
        reconciled["status_reconciled_by_judge"] = True
        reconciled["original_task_status"] = original_status

    verification["task_status"] = reconciled.get("task_status")
    verification["failure_labels"] = failure_labels
    reconciled["task_verification"] = verification
    reconciled["is_suspect_success"] = True
    reconciled["task_unsatisfied"] = True
    reconciled["final_answer_supported_by_tools"] = False
    return reconciled


def _assemble_judged_run(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    judgment: JudgeResult,
) -> JudgedRun:
    classification = judgment["classification"]
    doc_assessment = judgment["doc_assessment"]
    outcome = _reconcile_outcome_with_classification(evidence["outcome"], classification)

    return {
        "run_path": run["run_path"],
        "status": "analyzed",
        "task": run["task"],
        "prompt_id": run["prompt_id"],
        "run_key": run["run_key"],
        "persona": run["persona"],
        "provider": run["provider"],
        "model": run["model"],
        "outcome": outcome,
        "classification": classification,
        "evidence": {
            "run_metadata": evidence["run_metadata"],
            "path_summary": evidence["path_summary"],
            "derived_signals": evidence["derived_signals"],
            "first_failing_step": evidence.get("first_failing_step"),
            "failing_tool": evidence.get("failing_tool"),
            "error_type": evidence.get("error_type"),
            "error": evidence.get("error"),
            "repeated_pattern": evidence.get("repeated_pattern"),
            "adapted_after_error": evidence.get("adapted_after_error"),
            "docs_consulted": evidence["path_summary"]["docs_consulted"],
            "ground_docs_used": evidence["path_summary"]["ground_docs_used"],
            "issue_fingerprint": evidence.get("issue_fingerprint"),
            "doc_assessment": doc_assessment,
            "retrieval_diagnostics": docs_context.get("retrieval_diagnostics") or {},
            "relevant_doc_chunks": docs_context.get("relevant_doc_chunks") or [],
            "documentation_evidence": judgment["documentation_evidence"],
            "trace_evidence": judgment["trace_evidence"],
            "reproduction": judgment["reproduction"],
            "successful_path": judgment["successful_path"],
            "cross_agent_comparison": judgment["cross_agent_comparison"],
        },
        "trace": evidence["trace"],
        "root_cause": {
            "summary": judgment["summary"],
            "why_it_happened": judgment["why_it_happened"],
            "why_docs_should_have_prevented_it": judgment["why_docs_should_have_prevented_it"],
            "counterfactual": judgment["counterfactual"],
        },
        "recommendations": judgment["recommendations"],
        "judgment": judgment,
    }


def judge_run(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    batch_context: BatchContext | None = None,
    judge_config: JudgeConfig | None = None,
) -> JudgedRun:
    judgment = run_reasoning_judge(
        run,
        evidence,
        docs_context,
        batch_context=batch_context,
        judge_config=judge_config,
    )
    validate_judgment(judgment, evidence, docs_context)
    return _assemble_judged_run(run, evidence, docs_context, judgment)
