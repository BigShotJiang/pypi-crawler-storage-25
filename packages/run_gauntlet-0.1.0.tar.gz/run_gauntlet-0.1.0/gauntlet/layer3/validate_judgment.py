from __future__ import annotations

from typing import Any

from gauntlet.layer3.contracts import ALLOWED_BLAME_SURFACES, ALLOWED_ERROR_CLASSES, DocsContext, EvidencePacket, JudgeResult


def _step_numbers(evidence: EvidencePacket) -> set[int]:
    steps: set[int] = set()
    for item in evidence["trace"]["execution_trace"]:
        step = item.get("step")
        if isinstance(step, int):
            steps.add(step)
    return steps


def validate_judgment(judgment: JudgeResult, evidence: EvidencePacket, docs_context: DocsContext) -> None:
    if not isinstance(judgment, dict):
        raise ValueError("Judgment must be a JSON object.")

    required_fields = (
        "summary",
        "why_it_happened",
        "documentation_evidence",
        "trace_evidence",
        "classification",
        "reproduction",
        "successful_path",
        "cross_agent_comparison",
        "confidence",
        "recommendations",
        "doc_assessment",
        "why_docs_should_have_prevented_it",
        "counterfactual",
    )
    for field in required_fields:
        if field not in judgment:
            raise ValueError(f"Missing judgment field: {field}")

    for field in (
        "summary",
        "why_it_happened",
        "why_docs_should_have_prevented_it",
        "counterfactual",
    ):
        value = judgment[field]
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{field} must be a non-empty string.")

    for field in ("documentation_evidence", "trace_evidence", "recommendations"):
        value = judgment[field]
        if not isinstance(value, list):
            raise ValueError(f"{field} must be a JSON array.")

    classification = judgment["classification"]
    if not isinstance(classification, dict):
        raise ValueError("classification must be a JSON object.")
    primary = classification.get("primary_error_class")
    blame = classification.get("blame_surface")
    if primary is not None and primary not in ALLOWED_ERROR_CLASSES:
        raise ValueError(f"Invalid primary_error_class: {primary}")
    if blame is not None and blame not in ALLOWED_BLAME_SURFACES:
        raise ValueError(f"Invalid blame_surface: {blame}")

    doc_assessment = judgment["doc_assessment"]
    if not isinstance(doc_assessment, dict):
        raise ValueError("doc_assessment must be a JSON object.")
    retrieval_relevance = doc_assessment.get("retrieval_relevance")
    if retrieval_relevance not in {"relevant", "partial", "irrelevant"}:
        raise ValueError(f"Invalid retrieval_relevance: {retrieval_relevance}")
    retrieval_notes = doc_assessment.get("retrieval_notes")
    if not isinstance(retrieval_notes, str) or not retrieval_notes.strip():
        raise ValueError("doc_assessment.retrieval_notes must be a non-empty string.")

    valid_citation_ids = {
        chunk.get("citation_id")
        for chunk in docs_context.get("relevant_doc_chunks", [])
        if chunk.get("citation_id") is not None
    }
    valid_chunk_ids = {
        chunk.get("chunk_id")
        for chunk in docs_context.get("relevant_doc_chunks", [])
        if chunk.get("chunk_id") is not None
    }
    for citation in judgment["documentation_evidence"]:
        if not isinstance(citation, dict):
            raise ValueError("Each documentation_evidence entry must be a JSON object.")
        citation_id = citation.get("citation_id")
        chunk_id = citation.get("chunk_id")
        if citation_id is not None and citation_id not in valid_citation_ids:
            raise ValueError(f"Doc citation references unknown citation_id: {citation_id}")
        if chunk_id is not None and chunk_id not in valid_chunk_ids:
            raise ValueError(f"Doc citation references unknown chunk_id: {chunk_id}")

    valid_steps = _step_numbers(evidence)
    for citation in judgment["trace_evidence"]:
        if not isinstance(citation, dict):
            raise ValueError("Each trace_evidence entry must be a JSON object.")
        step = citation.get("step")
        if step is None:
            continue
        if step not in valid_steps:
            raise ValueError(f"Trace citation references unknown step: {step}")

    for field in ("reproduction", "successful_path"):
        plan = judgment[field]
        if not isinstance(plan, dict):
            raise ValueError(f"{field} must be a JSON object.")
        summary = plan.get("summary")
        if not isinstance(summary, str) or not summary.strip():
            raise ValueError(f"{field}.summary must be a non-empty string.")
        steps = plan.get("steps")
        if not isinstance(steps, list):
            raise ValueError(f"{field}.steps must be a JSON array.")
        for step in plan.get("steps", []):
            if step not in valid_steps:
                raise ValueError(f"{field} references unknown step: {step}")

    if judgment["reproduction"].get("required") and not judgment["reproduction"].get("steps"):
        raise ValueError("Reproduction steps are required but missing.")

    if evidence["trace"]["success_path_steps"] and not judgment["successful_path"].get("steps"):
        raise ValueError("Successful path steps are available but missing from judgment.")
