from __future__ import annotations

from collections import Counter
from typing import Any


def _prompt_mapping(judged_runs: list[dict[str, Any]]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for run in judged_runs:
        mapping.setdefault(str(run["prompt_id"]), run["task"])
    return mapping


def _severity_for_group(task_status: str, count: int) -> str:
    if task_status in {"schema_mismatch", "blocked_by_credentials", "blocked_by_provider"}:
        return "high"
    if task_status in {"suspect_success", "failure"}:
        return "high" if count > 1 else "medium"
    return "low"


def _owner_for_group(blame_surface: str, task_status: str) -> str:
    if task_status == "blocked_by_credentials":
        return "infra"
    if task_status == "blocked_by_provider":
        return "gauntlet"
    if blame_surface == "docs":
        return "docs-team"
    return "gauntlet"


AGENT_SIDE_OWNERS = {"model-provider", "agent-dev"}
AGENT_SIDE_SCOPES = {"agent"}


def _is_agent_side(recommendation: dict[str, Any]) -> bool:
    scope = str(recommendation.get("scope") or "").strip().lower()
    owner = str(recommendation.get("owner") or "").strip().lower()
    return scope in AGENT_SIDE_SCOPES or owner in AGENT_SIDE_OWNERS


def _normalize_recommendation(recommendation: dict[str, Any]) -> dict[str, str]:
    priority = str(recommendation.get("priority") or "medium").strip().lower()
    priority = {"urgent": "high", "critical": "high", "p0": "high", "p1": "high"}.get(priority, priority)
    if priority not in {"high", "medium", "low"}:
        priority = "medium"

    raw_scope = str(recommendation.get("scope") or "runtime").strip().lower().replace(" ", "-").replace("_", "-")
    scope_aliases = {
        "runtime": "runtime",
        "agent-runtime": "runtime",
        "provider-integration": "provider",
        "tool-documentation": "docs",
        "documentation": "docs",
        "agent-reasoning": "agent",
        "agent-prompt": "agent",
        "agent-dev": "agent",
        "tooling": "runtime",
        "layer2-runtime": "runtime",
    }
    scope = scope_aliases.get(raw_scope, raw_scope or "runtime")

    raw_owner = str(recommendation.get("owner") or "gauntlet").strip().lower().replace(" ", "-").replace("_", "-")
    owner_aliases = {
        "agent-runtime-team": "gauntlet",
        "provider-integration-team": "gauntlet",
        "tooling-team": "gauntlet",
        "agent-dev": "agent-dev",
        "agent-development-team": "agent-dev",
        "steel": "docs-team",
        "steel-cli-team": "docs-team",
    }
    owner = owner_aliases.get(raw_owner, raw_owner or "gauntlet")

    return {
        "priority": priority,
        "scope": scope,
        "owner": owner,
        "action": str(recommendation.get("action") or "Investigate the grouped issue."),
    }


def _classification_marks_false_success(classification: dict[str, Any]) -> bool:
    secondary = classification.get("secondary_error_classes") or []
    return classification.get("primary_error_class") == "false-success" or "false-success" in secondary


def _with_effective_outcome(run: dict[str, Any]) -> dict[str, Any]:
    if not _classification_marks_false_success(run.get("classification") or {}):
        return run
    if (run.get("outcome") or {}).get("task_status") != "success":
        return run

    normalized_run = dict(run)
    outcome = dict(run["outcome"])
    verification = dict(outcome.get("task_verification") or {})
    failure_labels = list(verification.get("failure_labels") or [])
    if "false_success_judged" not in failure_labels:
        failure_labels.append("false_success_judged")

    verification["task_status"] = "suspect_success"
    verification["failure_labels"] = failure_labels
    outcome["task_status"] = "suspect_success"
    outcome["is_suspect_success"] = True
    outcome["task_unsatisfied"] = True
    outcome["final_answer_supported_by_tools"] = False
    outcome["status_reconciled_by_judge"] = True
    outcome["original_task_status"] = "success"
    outcome["task_verification"] = verification
    normalized_run["outcome"] = outcome
    return normalized_run


def _issue_title(run: dict[str, Any]) -> str:
    verification = run["outcome"].get("task_verification") or {}
    if verification.get("failure_labels"):
        return f"failure label: {', '.join(verification['failure_labels'])}"
    if verification.get("forbidden_tools_used"):
        return f"violated forbidden tool constraint: {', '.join(verification['forbidden_tools_used'])}"
    if verification.get("forbidden_interfaces_used"):
        return f"violated forbidden interface constraint: {', '.join(verification['forbidden_interfaces_used'])}"
    if verification.get("missing_tools"):
        return f"missing required tool: {', '.join(verification['missing_tools'])}"
    if verification.get("missing_interfaces"):
        return f"missing required interface: {', '.join(verification['missing_interfaces'])}"
    if verification.get("missing_artifacts"):
        return f"missing required artifact: {', '.join(verification['missing_artifacts'])}"
    if verification.get("missing_outputs"):
        return f"missing required output: {', '.join(verification['missing_outputs'])}"
    fingerprint = run["evidence"].get("issue_fingerprint")
    if fingerprint:
        return str(fingerprint)
    return str(run["outcome"].get("task_status") or "clean-success")


def _issue_group_key(run: dict[str, Any]) -> tuple[str, str]:
    verification = run["outcome"].get("task_verification") or {}
    if verification.get("failure_labels"):
        return ("failure_label", ",".join(verification["failure_labels"]))
    if verification.get("forbidden_tools_used"):
        return ("violated_constraint", ",".join(verification["forbidden_tools_used"]))
    if verification.get("forbidden_interfaces_used"):
        return ("violated_constraint", ",".join(verification["forbidden_interfaces_used"]))
    if verification.get("missing_tools"):
        return ("violated_constraint", "missing:" + ",".join(verification["missing_tools"]))
    if verification.get("missing_interfaces"):
        return ("violated_constraint", "missing:" + ",".join(verification["missing_interfaces"]))
    if verification.get("missing_artifacts"):
        return ("missing_artifact", ",".join(verification["missing_artifacts"]))
    if verification.get("missing_outputs"):
        return ("missing_output", ",".join(verification["missing_outputs"]))
    fingerprint = run["evidence"].get("issue_fingerprint")
    if fingerprint:
        return ("fingerprint", str(fingerprint))
    doc_chunks = run["evidence"].get("relevant_doc_chunks") or []
    if doc_chunks:
        return ("docs_chunk", str(doc_chunks[0].get("path_text") or doc_chunks[0].get("chunk_id")))
    return ("task_status", str(run["outcome"].get("task_status") or "unknown"))


def _issue_groups(judged_runs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for run in judged_runs:
        task_status = run["outcome"].get("task_status")
        if task_status == "success":
            continue
        grouped.setdefault(_issue_group_key(run), []).append(run)

    issue_rows: list[dict[str, Any]] = []
    for index, ((kind, key), runs) in enumerate(
        sorted(grouped.items(), key=lambda item: len(item[1]), reverse=True),
        start=1,
    ):
        first = runs[0]
        task_status = str(first["outcome"].get("task_status") or "failure")
        blame_surface = str(first["classification"].get("blame_surface") or "mixed")
        owner = _owner_for_group(blame_surface, task_status)
        title = _issue_title(first)
        issue_rows.append(
            {
                "issue_id": f"I{index:03d}",
                "title": title,
                "group_kind": kind,
                "group_key": key,
                "severity": _severity_for_group(task_status, len(runs)),
                "affected_runs": [run["run_key"] for run in runs],
                "affected_run_count": len(runs),
                "primary_blame_surface": blame_surface,
                "recommended_owner": owner,
                "recommended_fix": (first.get("recommendations") or [{}])[0].get("action")
                or "Investigate the grouped failure and update the responsible surface.",
            }
        )
    return issue_rows


def aggregate_judged_runs(judged_runs: list[dict[str, Any]], *, batch_name: str) -> dict[str, Any]:
    judged_runs = [_with_effective_outcome(run) for run in judged_runs]
    run_status = Counter(run["outcome"]["run_status"] for run in judged_runs)
    task_status = Counter(run["outcome"].get("task_status") for run in judged_runs)
    error_class = Counter((run["classification"]["primary_error_class"] or "clean-success") for run in judged_runs)
    blame_surface = Counter((run["classification"]["blame_surface"] or "not_applicable") for run in judged_runs)
    fingerprints = Counter(
        run["evidence"].get("issue_fingerprint")
        for run in judged_runs
        if run["evidence"].get("issue_fingerprint")
    )
    recommendation_counter: Counter = Counter()
    agent_side_recommendation_counter: Counter = Counter()
    cross_agent_patterns = Counter()

    prompt_mapping = _prompt_mapping(judged_runs)
    run_rows = []
    for run in judged_runs:
        run_rows.append(
            {
                "prompt_id": run["prompt_id"],
                "run_key": run["run_key"],
                "persona": run["persona"],
                "prompt_text": prompt_mapping[str(run["prompt_id"])],
                "run_status": run["outcome"]["run_status"],
                "task_status": run["outcome"].get("task_status"),
                "primary_error_class": run["classification"]["primary_error_class"] or "clean-success",
                "blame_surface": run["classification"]["blame_surface"] or "not_applicable",
                "is_suspect_success": run["outcome"]["is_suspect_success"],
                "failure_labels": (run["outcome"].get("task_verification") or {}).get("failure_labels", []),
                "run_path": run["run_path"],
            }
        )
        for recommendation in run.get("recommendations", []):
            normalized_recommendation = _normalize_recommendation(recommendation)
            target_counter = (
                agent_side_recommendation_counter
                if _is_agent_side(normalized_recommendation)
                else recommendation_counter
            )
            target_counter[
                (
                    normalized_recommendation.get("priority"),
                    normalized_recommendation.get("scope"),
                    normalized_recommendation.get("owner"),
                    normalized_recommendation.get("action"),
                )
            ] += 1
        comparison = (run.get("judgment") or {}).get("cross_agent_comparison") or {}
        summary = comparison.get("summary")
        if summary:
            cross_agent_patterns[summary] += 1

    return {
        "batch_name": batch_name,
        "prompt_mapping": prompt_mapping,
        "total_runs": len(judged_runs),
        "completed_runs": sum(1 for run in judged_runs if run["outcome"]["run_status"] == "completed"),
        "failed_runs": sum(1 for run in judged_runs if run["outcome"]["run_status"] != "completed"),
        "successful_tasks": sum(1 for run in judged_runs if run["outcome"].get("task_status") == "success"),
        "failed_tasks": sum(1 for run in judged_runs if run["outcome"].get("task_status") != "success"),
        "suspect_successes": sum(1 for run in judged_runs if run["outcome"].get("task_status") == "suspect_success"),
        "run_status_breakdown": dict(run_status),
        "task_status_breakdown": dict(task_status),
        "error_class_breakdown": dict(error_class),
        "blame_surface_breakdown": dict(blame_surface),
        "top_issue_fingerprints": [
            {"fingerprint": fingerprint, "count": count}
            for fingerprint, count in fingerprints.most_common(10)
        ],
        "top_recommendations": [
            {
                "priority": priority,
                "scope": scope,
                "owner": owner,
                "action": action,
                "count": count,
            }
            for (priority, scope, owner, action), count in recommendation_counter.most_common(10)
        ],
        "agent_side_recommendations": [
            {
                "priority": priority,
                "scope": scope,
                "owner": owner,
                "action": action,
                "count": count,
            }
            for (priority, scope, owner, action), count in agent_side_recommendation_counter.most_common(10)
        ],
        "cross_agent_patterns": [
            {"summary": summary, "count": count}
            for summary, count in cross_agent_patterns.most_common(10)
        ],
        "issue_groups": _issue_groups(judged_runs),
        "run_rows": run_rows,
        "run_reports": [
            {
                "prompt_id": run["prompt_id"],
                "run_key": run["run_key"],
                "persona": run["persona"],
                "prompt_text": prompt_mapping[str(run["prompt_id"])],
                "run_path": run["run_path"],
                "primary_error_class": run["classification"]["primary_error_class"] or "clean-success",
                "run_status": run["outcome"]["run_status"],
                "task_status": run["outcome"].get("task_status"),
                "failure_labels": (run["outcome"].get("task_verification") or {}).get("failure_labels", []),
            }
            for run in judged_runs
        ],
        "judged_runs": judged_runs,
    }
