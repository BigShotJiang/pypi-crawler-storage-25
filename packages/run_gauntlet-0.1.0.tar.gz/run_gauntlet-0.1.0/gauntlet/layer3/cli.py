from __future__ import annotations

import argparse
import glob
from pathlib import Path

from gauntlet.layer1.llms_docs import load_environment
from gauntlet.layer3.aggregate_runs import aggregate_judged_runs
from gauntlet.layer3.build_batch_context import build_batch_context
from gauntlet.layer3.extract_evidence import extract_evidence
from gauntlet.layer3.judge_run import judge_run
from gauntlet.layer3.normalize_run import load_normalized_runs
from gauntlet.layer3.reasoning_judge import JudgeConfig
from gauntlet.layer3.render_report import write_summary_outputs
from gauntlet.layer3.retrieve_docs import DocsCache, retrieve_relevant_doc_chunks


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="gauntlet.layer3", description="Analyze Layer 2 run records.")
    parser.add_argument(
        "inputs",
        nargs="+",
        help="Run-record paths or glob patterns.",
    )
    parser.add_argument(
        "--output-dir",
        default="artifacts/judge_runs",
        help="Directory for judged JSON and HTML artifacts.",
    )
    parser.add_argument(
        "--name",
        default="layer3_batch",
        help="Base name for the aggregate summary artifacts.",
    )
    parser.add_argument("--judge-provider", help="Optional provider for the Layer 3 reasoning judge.")
    parser.add_argument("--judge-model", help="Optional model for the Layer 3 reasoning judge.")
    parser.add_argument(
        "--judge-max-doc-chunks",
        type=int,
        default=3,
        help="Maximum number of retrieved docs chunks to provide to the judge.",
    )
    parser.add_argument(
        "--judge-disable-batch-context",
        action="store_true",
        help="Disable batch-context input when judging runs.",
    )
    parser.add_argument(
        "--judge-fallback-deterministic",
        action="store_true",
        help="Fall back to the deterministic judge if the configured judge provider fails.",
    )
    return parser


def _resolve_inputs(patterns: list[str]) -> list[str]:
    resolved: list[str] = []
    for pattern in patterns:
        matches = sorted(glob.glob(pattern))
        if matches:
            resolved.extend(matches)
        else:
            resolved.append(pattern)

    deduped: list[str] = []
    seen: set[str] = set()
    for item in resolved:
        if item in seen:
            continue
        seen.add(item)
        deduped.append(item)
    return deduped


def _slug(value: str) -> str:
    return (
        value.lower()
        .replace(" ", "_")
        .replace("/", "_")
    )


def analyze_run_paths(
    input_paths: list[str],
    *,
    output_dir: str,
    name: str,
    judge_provider: str | None = None,
    judge_model: str | None = None,
    judge_max_doc_chunks: int = 3,
    judge_disable_batch_context: bool = False,
    judge_fallback_deterministic: bool = True,
) -> tuple[str, str]:
    runs = load_normalized_runs(input_paths)
    docs_cache = DocsCache()

    output_dir_path = Path(output_dir).expanduser()
    output_dir_path.mkdir(parents=True, exist_ok=True)

    evidence_packets = [extract_evidence(run) for run in runs]
    docs_contexts = [
        retrieve_relevant_doc_chunks(run, evidence, docs_cache, max_chunks=judge_max_doc_chunks)
        for run, evidence in zip(runs, evidence_packets)
    ]
    batch_context = build_batch_context(
        runs,
        evidence_packets,
        docs_contexts,
        batch_name=name,
    )
    judge_config = JudgeConfig(
        provider=judge_provider,
        model=judge_model,
        disable_batch_context=judge_disable_batch_context,
        fallback_deterministic=judge_fallback_deterministic,
    )
    judged_runs = [
        judge_run(run, evidence, docs_context, batch_context=batch_context, judge_config=judge_config)
        for run, evidence, docs_context in zip(runs, evidence_packets, docs_contexts)
    ]

    summary = aggregate_judged_runs(judged_runs, batch_name=name)
    summary_json = output_dir_path / f"{name}.json"
    summary_html = output_dir_path / f"{name}.html"
    write_summary_outputs(summary, summary_json, summary_html)
    return str(summary_json), str(summary_html)


def cli_main() -> int:
    load_environment()
    parser = build_parser()
    args = parser.parse_args()

    input_paths = _resolve_inputs(args.inputs)
    summary_json, summary_html = analyze_run_paths(
        input_paths,
        output_dir=args.output_dir,
        name=args.name,
        judge_provider=args.judge_provider,
        judge_model=args.judge_model,
        judge_max_doc_chunks=args.judge_max_doc_chunks,
        judge_disable_batch_context=args.judge_disable_batch_context,
        judge_fallback_deterministic=args.judge_fallback_deterministic or not (args.judge_provider and args.judge_model),
    )

    print(f"Analyzed {len(input_paths)} run(s).")
    print(f"Summary JSON: {summary_json}")
    print(f"Summary HTML: {summary_html}")
    return 0


def app() -> None:
    raise SystemExit(cli_main())


if __name__ == "__main__":
    app()
