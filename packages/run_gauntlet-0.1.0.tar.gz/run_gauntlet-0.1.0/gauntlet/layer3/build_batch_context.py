from __future__ import annotations

from collections import Counter

from gauntlet.layer3.contracts import BatchContext, DocsContext, EvidencePacket, NormalizedRun, PeerRunSummary


def _prompt_mapping(runs: list[NormalizedRun]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for run in runs:
        mapping.setdefault(run["prompt_id"], run["task"])
    return mapping


def _peer_run_summaries(runs: list[NormalizedRun], evidence_packets: list[EvidencePacket]) -> list[PeerRunSummary]:
    summaries: list[PeerRunSummary] = []
    for run, evidence in zip(runs, evidence_packets):
        summaries.append(
            {
                "run_path": run["run_path"],
                "prompt_id": run["prompt_id"],
                "run_key": run["run_key"],
                "persona": run["persona"],
                "provider": run["provider"],
                "model": run["model"],
                "status": run["status"],
                "run_status": evidence["outcome"].get("run_status"),
                "task_status": evidence["outcome"].get("task_status"),
                "issue_fingerprint": evidence.get("issue_fingerprint"),
            }
        )
    return summaries


def _common_failure_fingerprints(evidence_packets: list[EvidencePacket]) -> list[dict]:
    counts = Counter(
        evidence["issue_fingerprint"]
        for evidence in evidence_packets
        if evidence.get("issue_fingerprint")
    )
    return [
        {"fingerprint": fingerprint, "count": count}
        for fingerprint, count in counts.most_common()
        if fingerprint is not None
    ]


def _common_success_patterns(evidence_packets: list[EvidencePacket]) -> list[dict]:
    counts = Counter(
        tuple(evidence["path_summary"]["successful_tools"])
        for evidence in evidence_packets
        if evidence["path_summary"]["successful_tools"]
    )
    return [
        {"successful_tools": list(pattern), "count": count}
        for pattern, count in counts.most_common()
    ]


def _divergent_outcomes(runs: list[NormalizedRun], evidence_packets: list[EvidencePacket]) -> list[dict]:
    statuses = {run["status"] for run in runs}
    if len(statuses) <= 1:
        return []

    return [
        {
            "prompt_id": run["prompt_id"],
            "run_key": run["run_key"],
            "persona": run["persona"],
            "run_path": run["run_path"],
            "status": run["status"],
            "issue_fingerprint": evidence.get("issue_fingerprint"),
            "has_failures": evidence["derived_signals"]["has_failures"],
        }
        for run, evidence in zip(runs, evidence_packets)
    ]


def _docs_source_summary(runs: list[NormalizedRun], docs_contexts: list[DocsContext]) -> dict:
    llms_sources = [run.get("llms_source") for run in runs if run.get("llms_source")]
    llms_full_sources = [run.get("llms_full_source") for run in runs if run.get("llms_full_source")]
    citation_counts = [len(context.get("relevant_doc_chunks") or []) for context in docs_contexts]

    return {
        "llms_sources": sorted(set(llms_sources)),
        "llms_full_sources": sorted(set(llms_full_sources)),
        "shared_llms_source": len(set(llms_sources)) <= 1,
        "shared_llms_full_source": len(set(llms_full_sources)) <= 1,
        "docs_context_count": len(docs_contexts),
        "doc_chunk_counts": citation_counts,
    }


def _task_cluster_summary(runs: list[NormalizedRun]) -> dict:
    tasks = [run["task"] for run in runs]
    personas = [run["persona"] for run in runs]
    return {
        "task_count": len(set(tasks)),
        "tasks": list(dict.fromkeys(tasks)),
        "run_count": len(runs),
        "persona_count": len(set(personas)),
        "personas": list(dict.fromkeys(personas)),
    }


def build_batch_context(
    runs: list[NormalizedRun],
    evidence_packets: list[EvidencePacket],
    docs_contexts: list[DocsContext],
    *,
    batch_name: str | None = None,
) -> BatchContext:
    return {
        "prompt_mapping": _prompt_mapping(runs),
        "peer_run_summaries": _peer_run_summaries(runs, evidence_packets),
        "common_failure_fingerprints": _common_failure_fingerprints(evidence_packets),
        "common_success_patterns": _common_success_patterns(evidence_packets),
        "divergent_outcomes": _divergent_outcomes(runs, evidence_packets),
        "docs_source_summary": {
            "batch_name": batch_name,
            **_docs_source_summary(runs, docs_contexts),
        },
        "task_cluster_summary": _task_cluster_summary(runs),
    }
