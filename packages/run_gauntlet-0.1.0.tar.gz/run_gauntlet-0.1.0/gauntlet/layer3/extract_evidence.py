from __future__ import annotations

import re
from collections import Counter
from typing import Any

from gauntlet.layer3.contracts import EvidencePacket, ExecutionTraceItem, FirstFailure, TracePacket
from gauntlet.layer3.verify_task import verify_task


DOC_TOOLS = {"read_docs", "read_doc", "ground_docs"}
OBSERVATION_LIMIT = 1200
TEXT_FIELD_LIMIT = 2500
ERROR_TRACE_LIMIT = 6000
FINAL_RESPONSE_LIMIT = 4000
PREVIOUS_OUTPUT_LIMIT = 3000
RAW_FACT_KEYWORD_LIMIT = 24

QUERY_STOP_TERMS = {
    "the",
    "and",
    "for",
    "with",
    "from",
    "that",
    "this",
    "then",
    "into",
    "after",
    "before",
    "error",
    "failed",
    "failure",
    "response",
    "payload",
    "output",
    "step",
    "task",
    "tool",
    "run",
}


def _successful_tool_steps(run: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        step
        for step in run["steps"]
        if step.get("tool_result") and step["tool_result"].get("ok") is True
    ]


def _failed_tool_steps(run: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        step
        for step in run["steps"]
        if step.get("tool_result") and step["tool_result"].get("ok") is False
    ]


def _tool_name(step: dict[str, Any]) -> str | None:
    tool = step.get("tool") or {}
    return tool.get("name")


def _extract_domains(text: str) -> list[str]:
    domains: list[str] = []
    for match in re.finditer(r"(?:https?://)?([a-z0-9][a-z0-9.-]+\.[a-z]{2,})(?:[:/][^\s]*)?", text.lower()):
        host = match.group(1).strip(".")
        if host.startswith("www."):
            host = host[4:]
        if host:
            domains.append(host)
            domains.extend(part for part in host.split(".") if len(part) > 2)
    return domains


def _extract_identifiers(text: str) -> list[str]:
    identifiers: list[str] = []
    for match in re.finditer(r"\b[a-zA-Z][a-zA-Z0-9_./:-]{2,}\b", text):
        value = match.group(0).strip()
        lowered = value.lower()
        if not lowered:
            continue
        if any(separator in lowered for separator in ("_", "/", ".", ":", "-")) or any(char.isdigit() for char in lowered):
            identifiers.append(lowered)
    return identifiers


def _keyword_terms(*values: Any, limit: int = RAW_FACT_KEYWORD_LIMIT) -> list[str]:
    keywords: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value is None:
            continue
        text = str(value)
        for term in re.findall(r"[a-z0-9_/-]+", text.lower()):
            if len(term) <= 2 or term in QUERY_STOP_TERMS:
                continue
            if term in seen:
                continue
            seen.add(term)
            keywords.append(term)
            if len(keywords) >= limit:
                return keywords
    return keywords


def _unique_strings(values: list[str], *, limit: int | None = None) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = re.sub(r"\s+", " ", value.strip().lower())
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        result.append(value.strip())
        if limit is not None and len(result) >= limit:
            break
    return result


def _truncate(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    omitted = len(value) - limit
    return value[:limit] + f"\n... <truncated {omitted} chars>"


def _compact_value(value: Any, *, string_limit: int = TEXT_FIELD_LIMIT) -> Any:
    if isinstance(value, str):
        return _truncate(value, string_limit)
    if isinstance(value, dict):
        return {str(key): _compact_value(item, string_limit=string_limit) for key, item in value.items()}
    if isinstance(value, list):
        return [_compact_value(item, string_limit=string_limit) for item in value]
    return value


def _compact_tool_call(step: dict[str, Any]) -> dict[str, Any] | None:
    tool = step.get("tool")
    if not isinstance(tool, dict):
        return None

    compact = {"name": tool.get("name")}
    for key, value in tool.items():
        if key == "name":
            continue
        compact[key] = _compact_value(value, string_limit=TEXT_FIELD_LIMIT)
    return compact


def _compact_tool_result(step: dict[str, Any]) -> dict[str, Any] | None:
    tool_result = step.get("tool_result")
    if not isinstance(tool_result, dict):
        return None

    compact: dict[str, Any] = {}
    for key, value in tool_result.items():
        compact[key] = _compact_value(value, string_limit=TEXT_FIELD_LIMIT)
    return compact


def _compact_response(step: dict[str, Any]) -> dict[str, Any] | None:
    response = step.get("response")
    if not isinstance(response, dict):
        return None
    return {str(key): _compact_value(value, string_limit=TEXT_FIELD_LIMIT) for key, value in response.items()}


def _compact_parse_error(step: dict[str, Any]) -> dict[str, Any] | None:
    parse_error = step.get("parse_error")
    if not isinstance(parse_error, dict):
        return None
    return {str(key): _compact_value(value, string_limit=TEXT_FIELD_LIMIT) for key, value in parse_error.items()}


def _step_observation_text(step: dict[str, Any]) -> str | None:
    response = step.get("response") or {}
    if isinstance(response.get("response"), str) and response.get("response"):
        return str(response["response"])

    tool_result = step.get("tool_result") or {}
    for key in ("text", "stdout", "stderr", "grounding_block", "error"):
        value = tool_result.get(key)
        if isinstance(value, str) and value:
            return value

    parse_error = step.get("parse_error") or {}
    if isinstance(parse_error.get("error"), str) and parse_error.get("error"):
        return str(parse_error["error"])

    return None


def _step_details(run: dict[str, Any]) -> list[dict[str, Any]]:
    details: list[dict[str, Any]] = []
    for step in run["steps"]:
        details.append(
            {
                "step": step.get("step"),
                "tool": _compact_tool_call(step),
                "tool_result": _compact_tool_result(step),
                "response": _compact_response(step),
                "parse_error": _compact_parse_error(step),
                "observation": _truncate(_step_observation_text(step) or "", OBSERVATION_LIMIT) or None,
            }
        )
    return details


def _find_first_failure(run: dict[str, Any]) -> tuple[int | None, str | None, str | None, str | None, dict[str, Any] | None]:
    for step in run["steps"]:
        parse_error = step.get("parse_error")
        if parse_error:
            return (
                step.get("step"),
                None,
                parse_error.get("error_type"),
                parse_error.get("error"),
                parse_error,
            )

        tool_result = step.get("tool_result")
        if tool_result and tool_result.get("ok") is False:
            return (
                step.get("step"),
                _tool_name(step),
                tool_result.get("error_type"),
                tool_result.get("error"),
                tool_result,
            )

    failure = run.get("failure") or {}
    if failure:
        return (
            failure.get("step"),
            failure.get("tool"),
            failure.get("type"),
            failure.get("error") or failure.get("response_type"),
            failure,
        )
    return None, None, None, None, None


def _build_first_failure(
    step_number: int | None,
    failing_tool: str | None,
    error_type: str | None,
    error: str | None,
    payload: dict[str, Any] | None,
) -> FirstFailure | None:
    if step_number is None and failing_tool is None and error_type is None and error is None and payload is None:
        return None

    return {
        "step": step_number,
        "tool": failing_tool,
        "error_type": error_type,
        "error": error,
        "payload": _compact_value(payload, string_limit=ERROR_TRACE_LIMIT) if payload is not None else None,
    }


def _repeated_failure_pattern(run: dict[str, Any]) -> bool:
    patterns = Counter()
    for step in _failed_tool_steps(run):
        tool_result = step.get("tool_result") or {}
        patterns[(_tool_name(step), tool_result.get("error_type"), tool_result.get("error"))] += 1
    return any(count > 1 for count in patterns.values())


def _adapted_after_error(run: dict[str, Any]) -> bool:
    failure_seen = False
    for step in run["steps"]:
        tool_result = step.get("tool_result")
        if tool_result and tool_result.get("ok") is False:
            failure_seen = True
            continue
        if failure_seen and tool_result and tool_result.get("ok") is True:
            return True
        response = step.get("response") or {}
        if failure_seen and response.get("type") == "final":
            return True
    return False


def _execution_trace(run: dict[str, Any]) -> list[ExecutionTraceItem]:
    trace: list[ExecutionTraceItem] = []
    for step in run["steps"]:
        response = step.get("response") or {}
        tool = step.get("tool")
        if tool:
            tool_result = step.get("tool_result") or {}
            trace.append(
                {
                    "step": step.get("step"),
                    "kind": "tool",
                    "tool": tool.get("name"),
                    "status": "succeeded" if tool_result.get("ok") else "failed",
                    "error_type": tool_result.get("error_type"),
                    "error": tool_result.get("error"),
                }
            )
        elif response.get("type") == "final":
            trace.append(
                {
                    "step": step.get("step"),
                    "kind": "final",
                    "status": "completed",
                    "response": response.get("response"),
                }
            )
        elif step.get("parse_error"):
            trace.append(
                {
                    "step": step.get("step"),
                    "kind": "parse_error",
                    "status": "failed",
                    "error_type": step["parse_error"].get("error_type"),
                    "error": step["parse_error"].get("error"),
                }
            )
    return trace


def _issue_fingerprint(failing_tool: str | None, error_type: str | None, error: str | None) -> str | None:
    if not (failing_tool or error_type or error):
        return None
    normalized_error = (error or "").lower()
    normalized_error = re.sub(r"\s+", " ", normalized_error).strip()
    normalized_error = normalized_error[:120]
    return "|".join(
        part
        for part in (
            failing_tool or "",
            error_type or "",
            normalized_error,
        )
        if part
    ) or None


def _raw_error_trace(first_failure_payload: dict[str, Any] | None) -> dict[str, Any] | None:
    if not first_failure_payload:
        return None
    raw = {}
    for key in ("stdout", "stderr", "exit_code", "response_text"):
        value = first_failure_payload.get(key)
        if value not in (None, ""):
            if isinstance(value, str):
                raw[key] = _truncate(value, ERROR_TRACE_LIMIT)
            else:
                raw[key] = value
    stderr = raw.get("stderr")
    if isinstance(stderr, str) and "Traceback" in stderr:
        raw["traceback_snippet"] = stderr[:ERROR_TRACE_LIMIT]
    return raw or None


def _success_path_steps(run: dict[str, Any]) -> list[int]:
    steps: list[int] = []
    for step in run["steps"]:
        tool_result = step.get("tool_result") or {}
        response = step.get("response") or {}
        if tool_result.get("ok") is True or response.get("type") == "final":
            step_number = step.get("step")
            if isinstance(step_number, int):
                steps.append(step_number)
    return steps


def _reproduction_candidate_steps(run: dict[str, Any], first_failing_step: int | None) -> list[int]:
    if first_failing_step is None:
        return []

    steps: list[int] = []
    for step in run["steps"]:
        step_number = step.get("step")
        if not isinstance(step_number, int):
            continue
        if step_number <= first_failing_step:
            steps.append(step_number)
    return steps


def _build_judge_query(run: dict[str, Any], first_failing_step: int | None, error: str | None) -> dict[str, Any]:
    previous_output = None
    failing_tool = None
    failure_payload = None
    failure_details = None
    if first_failing_step is not None:
        for step in run["steps"]:
            if step.get("step") == first_failing_step - 1:
                tool_result = step.get("tool_result")
                if isinstance(tool_result, dict):
                    previous_output = str(_compact_value(tool_result, string_limit=PREVIOUS_OUTPUT_LIMIT))
            if step.get("step") == first_failing_step:
                failing_tool = _tool_name(step)
                tool_result = step.get("tool_result")
                parse_error = step.get("parse_error")
                if isinstance(tool_result, dict):
                    failure_payload = str(_compact_value(tool_result, string_limit=PREVIOUS_OUTPUT_LIMIT))
                elif isinstance(parse_error, dict):
                    failure_payload = str(_compact_value(parse_error, string_limit=PREVIOUS_OUTPUT_LIMIT))
        if failing_tool or error:
            failure_details = f"step={first_failing_step}; tool={failing_tool}; error={error}"

    return {
        "task": run["task"],
        "current_error": error,
        "previous_output": previous_output,
        "next_goal": (
            "Determine what happened in the run, identify the exact docs-backed correction path for the failing step, "
            f"and explain the failure using the most relevant product documentation. Failure details: {failure_details or 'none'}"
        ),
        "failure_payload": failure_payload,
    }


def _build_raw_failure_facts(
    run: dict[str, Any],
    first_failing_step: int | None,
    failing_tool: str | None,
    error_type: str | None,
    error: str | None,
    first_failure_payload: dict[str, Any] | None,
) -> dict[str, Any]:
    previous_output = None
    previous_tool = None
    failing_tool_call = None
    failure_payload = None
    if first_failing_step is not None:
        for step in run["steps"]:
            if step.get("step") == first_failing_step - 1:
                previous_tool = _tool_name(step)
                tool_result = step.get("tool_result")
                if isinstance(tool_result, dict):
                    previous_output = str(_compact_value(tool_result, string_limit=PREVIOUS_OUTPUT_LIMIT))
            if step.get("step") == first_failing_step:
                compact_tool = _compact_tool_call(step)
                if compact_tool is not None:
                    failing_tool_call = compact_tool
                tool_result = step.get("tool_result")
                parse_error = step.get("parse_error")
                if isinstance(tool_result, dict):
                    failure_payload = str(_compact_value(tool_result, string_limit=PREVIOUS_OUTPUT_LIMIT))
                elif isinstance(parse_error, dict):
                    failure_payload = str(_compact_value(parse_error, string_limit=PREVIOUS_OUTPUT_LIMIT))

    source_parts = [
        run.get("task") or "",
        failing_tool or "",
        previous_tool or "",
        error_type or "",
        error or "",
        previous_output or "",
        failure_payload or "",
        str(failing_tool_call or ""),
        str(first_failure_payload or ""),
    ]
    domains = _unique_strings(_extract_domains("\n".join(source_parts)), limit=12)
    identifiers = _unique_strings(_extract_identifiers("\n".join(source_parts)), limit=18)
    phrases = _unique_strings(
        [value for value in [failing_tool, error_type, error, previous_tool] if isinstance(value, str) and value.strip()],
        limit=8,
    )

    return {
        "task": run["task"],
        "failing_step": first_failing_step,
        "failing_tool": failing_tool,
        "previous_tool": previous_tool,
        "error_type": error_type,
        "error": error,
        "previous_output": previous_output,
        "failure_payload": failure_payload,
        "failing_tool_call": failing_tool_call,
        "domains": domains,
        "identifiers": identifiers,
        "tools": _unique_strings([value for value in [failing_tool, previous_tool] if isinstance(value, str)], limit=4),
        "keywords": _keyword_terms(*source_parts),
        "phrases": phrases,
        "next_goal": (
            "Retrieve the most relevant product documentation for the failing step, using the raw failure facts "
            "instead of the exploratory narrative."
        ),
    }


def _trace_packet(
    run: dict[str, Any],
    first_failing_step: int | None,
    failing_tool: str | None,
    error_type: str | None,
    error: str | None,
    first_failure_payload: dict[str, Any] | None,
) -> TracePacket:
    return {
        "execution_trace": _execution_trace(run),
        "raw_error_trace": _raw_error_trace(first_failure_payload),
        "final_response": _truncate(run.get("final_response"), FINAL_RESPONSE_LIMIT)
        if isinstance(run.get("final_response"), str) and run.get("final_response")
        else run.get("final_response"),
        "success_path_steps": _success_path_steps(run),
        "reproduction_candidate_steps": _reproduction_candidate_steps(run, first_failing_step),
        "step_details": _step_details(run),
        "first_failure": _build_first_failure(
            first_failing_step,
            failing_tool,
            error_type,
            error,
            first_failure_payload,
        ),
    }


def extract_evidence(run: dict[str, Any]) -> EvidencePacket:
    failed_steps = _failed_tool_steps(run)
    successful_steps = _successful_tool_steps(run)
    first_failing_step, failing_tool, error_type, error, first_failure_payload = _find_first_failure(run)
    docs_consulted = any(_tool_name(step) in DOC_TOOLS for step in run["steps"])
    ground_docs_used = any(_tool_name(step) == "ground_docs" for step in run["steps"])
    repeated_pattern = _repeated_failure_pattern(run)
    adapted_after_error = _adapted_after_error(run)
    completed_with_tool_errors = run["status"] == "completed" and bool(failed_steps)
    task_verification = verify_task(run)

    trace = _trace_packet(
        run,
        first_failing_step,
        failing_tool,
        error_type,
        error,
        first_failure_payload,
    )

    # Transitional compatibility fields remain for the current deterministic
    # judge. They are intentionally neutral because Track A is removing
    # product-specific task judgments from evidence extraction.
    return {
        "run_path": run["run_path"],
        "run_metadata": {
            "run_path": run["run_path"],
            "started_at": run.get("started_at"),
            "finished_at": run.get("finished_at"),
            "max_steps": run.get("max_steps"),
            "max_format_retries": run.get("max_format_retries"),
            "environment": run.get("environment") or {},
            "workspace": run.get("workspace"),
        },
        "task": {
            "task_text": run["task"],
            "final_response": run.get("final_response"),
        },
        "agent": {
            "persona": run["persona"],
            "provider": run["provider"],
            "model": run["model"],
        },
        "outcome": {
            "run_status": task_verification["run_status"],
            "task_status": task_verification["task_status"],
            "task_verification": task_verification,
            "terminal_failure_type": (run.get("failure") or {}).get("type"),
            "has_tool_errors": bool(failed_steps),
            "completed_with_tool_errors": completed_with_tool_errors,
            "steps_count": len(run["steps"]),
            "is_suspect_success": task_verification["task_status"] == "suspect_success",
            "unsupported_fact_claims": False,
            "contradicts_tool_evidence": False,
            "claimed_completion_without_artifact": bool(task_verification["missing_artifacts"]),
            "task_unsatisfied": task_verification["task_status"] != "success",
            "final_answer_supported_by_tools": task_verification["task_status"] == "success",
        },
        "path_summary": {
            "tools_used": [_tool_name(step) for step in run["steps"] if _tool_name(step)],
            "successful_tools": [_tool_name(step) for step in successful_steps if _tool_name(step)],
            "failed_tools": [_tool_name(step) for step in failed_steps if _tool_name(step)],
            "docs_consulted": docs_consulted,
            "ground_docs_used": ground_docs_used,
            "recovery_attempted": bool(failed_steps),
            "recovery_succeeded": completed_with_tool_errors,
        },
        "derived_signals": {
            "has_failures": bool(failed_steps),
            "docs_consulted": docs_consulted,
            "ground_docs_used": ground_docs_used,
            "recovery_attempted": bool(failed_steps),
            "recovery_succeeded": completed_with_tool_errors,
            "adapted_after_error": adapted_after_error,
            "repeated_failure_pattern": repeated_pattern,
            "completed_after_failure": completed_with_tool_errors,
            "has_final_response": bool(run.get("final_response")),
        },
        "first_failing_step": first_failing_step,
        "failing_tool": failing_tool,
        "error_type": error_type,
        "error": error,
        "issue_fingerprint": _issue_fingerprint(failing_tool, error_type, error),
        "repeated_pattern": repeated_pattern,
        "adapted_after_error": adapted_after_error,
        "trace": trace,
        "raw_failure_facts": _build_raw_failure_facts(
            run,
            first_failing_step,
            failing_tool,
            error_type,
            error,
            first_failure_payload,
        ),
        "judge_query": _build_judge_query(run, first_failing_step, error),
    }
