from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_normalized_run(path: str | Path) -> dict[str, Any]:
    run_path = Path(path).expanduser()
    payload = json.loads(run_path.read_text(encoding="utf-8"))

    return {
        "run_path": str(run_path),
        "status": payload.get("status"),
        "run_status": payload.get("run_status"),
        "task_status": payload.get("task_status"),
        "provider": payload.get("provider"),
        "model": payload.get("model"),
        "task": payload.get("task", ""),
        "prompt_id": str(payload.get("prompt_id", "1")),
        "run_key": payload.get("run_key") or f"{str(payload.get('prompt_id', '1'))}_{payload.get('persona', 'default')}",
        "batch_prompt_count": payload.get("batch_prompt_count"),
        "persona": payload.get("persona", "default"),
        "llms_source": payload.get("llms_source"),
        "llms_full_source": payload.get("llms_full_source"),
        "max_steps": payload.get("max_steps"),
        "max_format_retries": payload.get("max_format_retries"),
        "started_at": payload.get("started_at"),
        "finished_at": payload.get("finished_at"),
        "docs": payload.get("docs") or {},
        "environment": payload.get("environment") or {},
        "workspace": payload.get("workspace"),
        "steps": payload.get("steps") or [],
        "final_response": payload.get("final_response"),
        "failure": payload.get("failure"),
    }


def load_normalized_runs(paths: list[str | Path]) -> list[dict[str, Any]]:
    return [load_normalized_run(path) for path in paths]
