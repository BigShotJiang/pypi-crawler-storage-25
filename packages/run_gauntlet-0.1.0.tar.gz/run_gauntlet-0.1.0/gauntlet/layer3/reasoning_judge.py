from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from gauntlet.layer3.contracts import (
    ALLOWED_BLAME_SURFACES,
    ALLOWED_ERROR_CLASSES,
    BatchContext,
    Classification,
    DocAssessment,
    DocsContext,
    EvidencePacket,
    JudgeResult,
    NormalizedRun,
    Recommendation,
)
from gauntlet.layer3.validate_judgment import validate_judgment
from gauntlet.providers import ProviderConfig, send_prompt


@dataclass(frozen=True)
class JudgeConfig:
    provider: str | None = None
    model: str | None = None
    disable_batch_context: bool = False
    fallback_deterministic: bool = True


def _sdk_evidence_present(evidence: EvidencePacket) -> bool:
    trace_text = json.dumps(evidence.get("trace") or {}, ensure_ascii=True).lower()
    return any(
        needle in trace_text
        for needle in (
            '"tool": "run_sdk"',
            '"name": "run_sdk"',
            "factory_import_path",
            "method_path",
        )
    )


def _recovered_secondary_classes(evidence: EvidencePacket) -> list[str]:
    failing_tool = evidence.get("failing_tool")
    error_type = str(evidence.get("error_type") or "").lower()
    error = str(evidence.get("error") or "").lower()
    all_trace_text = json.dumps(evidence.get("trace") or {}, ensure_ascii=True).lower()
    classes: list[str] = []
    if "initial_auth_error_recovered" in set((evidence["outcome"].get("task_verification") or {}).get("failure_labels") or []):
        classes.append("recovered-auth-error")
    if "$steps[" in all_trace_text and "artifacts." in all_trace_text:
        classes.append("artifact-reference-error")
    if "stdin" in all_trace_text and ("no stdin" in all_trace_text or "timed out" in all_trace_text):
        classes.append("stdin-handoff-error")
    if "$steel_api_key" in all_trace_text:
        classes.append("env-expansion-error")
    if failing_tool == "run_http" and ("401" in error or "unauthorized" in error):
        classes.append("recovered-auth-error")
    elif failing_tool == "run_http":
        classes.append("tool-contract-error")
    elif failing_tool == "run_cli":
        classes.append("tool-contract-error")
    elif failing_tool == "run_python" and any(item in error_type or item in error for item in ("keyerror", "json", "schema", "missing")):
        classes.append("schema-mismatch")
    elif failing_tool == "run_sdk":
        classes.append("sdk-usage")
    return list(dict.fromkeys(classes))


def _classify(run: NormalizedRun, evidence: EvidencePacket) -> Classification:
    failure_type = evidence["outcome"]["terminal_failure_type"]
    task_status = evidence["outcome"].get("task_status")
    failing_tool = evidence.get("failing_tool")
    error_type = evidence.get("error_type") or ""
    error = (evidence.get("error") or "").lower()
    task_verification = evidence["outcome"].get("task_verification") or {}
    failure_labels = set(task_verification.get("failure_labels") or [])
    all_trace_text = json.dumps(evidence.get("trace") or {}, ensure_ascii=True).lower()

    if task_status == "success" and (evidence["outcome"].get("completed_with_tool_errors") or evidence.get("first_failing_step") is not None):
        return {
            "primary_error_class": "reasoning/recovery",
            "secondary_error_classes": _recovered_secondary_classes(evidence),
            "blame_surface": "agent",
            "classification_confidence": 0.94,
            "blame_confidence": 0.86,
        }
    if task_status == "success" and evidence["outcome"].get("run_status") == "completed":
        return {
            "primary_error_class": None,
            "secondary_error_classes": [],
            "blame_surface": None,
            "classification_confidence": 1.0,
            "blame_confidence": 1.0,
        }
    if task_status == "schema_mismatch":
        return {
            "primary_error_class": "schema-mismatch",
            "secondary_error_classes": [],
            "blame_surface": "agent",
            "classification_confidence": 0.96,
            "blame_confidence": 0.9,
        }
    if task_status == "blocked_by_provider":
        return {
            "primary_error_class": "provider-failure",
            "secondary_error_classes": [],
            "blame_surface": "runtime",
            "classification_confidence": 0.98,
            "blame_confidence": 0.95,
        }
    if task_status == "blocked_by_credentials":
        return {
            "primary_error_class": "env-expansion-error" if "$steel_api_key" in all_trace_text else "tool-contract-error",
            "secondary_error_classes": ["credentials"],
            "blame_surface": "environment",
            "classification_confidence": 0.96,
            "blame_confidence": 0.9,
        }
    if "$steps[" in all_trace_text and "artifacts." in all_trace_text:
        return {
            "primary_error_class": "artifact-reference-error",
            "secondary_error_classes": ["false-success"] if evidence["outcome"]["is_suspect_success"] else [],
            "blame_surface": "agent",
            "classification_confidence": 0.94,
            "blame_confidence": 0.86,
        }
    if "stdin" in all_trace_text and ("no stdin" in all_trace_text or "timed out" in all_trace_text):
        return {
            "primary_error_class": "stdin-handoff-error",
            "secondary_error_classes": [],
            "blame_surface": "agent",
            "classification_confidence": 0.9,
            "blame_confidence": 0.84,
        }
    if evidence["outcome"]["is_suspect_success"] or task_status == "suspect_success":
        return {
            "primary_error_class": "false-success",
            "secondary_error_classes": ["reasoning/recovery"] if evidence["outcome"]["completed_with_tool_errors"] else [],
            "blame_surface": "agent",
            "classification_confidence": 0.9,
            "blame_confidence": 0.82,
        }
    if failure_type == "docs_load_failed":
        return {
            "primary_error_class": "tool-contract-error",
            "secondary_error_classes": [],
            "blame_surface": "docs",
            "classification_confidence": 0.93,
            "blame_confidence": 0.85,
        }
    if failure_type in {"response_parse_failed", "invalid_response_type"}:
        return {
            "primary_error_class": "schema-mismatch",
            "secondary_error_classes": [],
            "blame_surface": "agent",
            "classification_confidence": 0.95,
            "blame_confidence": 0.9,
        }
    if failing_tool == "run_sdk":
        secondary = ["tool-argument-shape"] if "method path" in error or "attributeerror" in error_type.lower() else []
        return {
            "primary_error_class": "sdk-usage",
            "secondary_error_classes": secondary,
            "blame_surface": "agent" if secondary else "mixed",
            "classification_confidence": 0.94,
            "blame_confidence": 0.84,
        }
    if failing_tool == "run_http":
        if "401" in error or "unauthorized" in error:
            return {
                "primary_error_class": "env-expansion-error" if "$steel_api_key" in all_trace_text else "tool-contract-error",
                "secondary_error_classes": [],
                "blame_surface": "environment",
                "classification_confidence": 0.96,
                "blame_confidence": 0.88,
            }
        return {
            "primary_error_class": "tool-contract-error",
            "secondary_error_classes": [],
            "blame_surface": "agent",
            "classification_confidence": 0.72,
            "blame_confidence": 0.7,
        }
    if failing_tool == "run_cli":
        return {
            "primary_error_class": "tool-contract-error",
            "secondary_error_classes": [],
            "blame_surface": "runtime",
            "classification_confidence": 0.9,
            "blame_confidence": 0.78,
        }
    if evidence.get("repeated_pattern"):
        return {
            "primary_error_class": "reasoning/recovery",
            "secondary_error_classes": ["tool-contract-error"],
            "blame_surface": "agent",
            "classification_confidence": 0.88,
            "blame_confidence": 0.84,
        }
    if evidence["outcome"]["completed_with_tool_errors"]:
        return {
            "primary_error_class": "reasoning/recovery",
            "secondary_error_classes": [],
            "blame_surface": "agent",
            "classification_confidence": 0.7,
            "blame_confidence": 0.68,
        }
    return {
        "primary_error_class": "tool-contract-error",
        "secondary_error_classes": [],
        "blame_surface": "mixed",
        "classification_confidence": 0.55,
        "blame_confidence": 0.5,
    }


def _doc_assessment(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    classification: Classification,
) -> DocAssessment:
    docs_consulted = evidence["path_summary"]["docs_consulted"]
    relevant_doc_chunks = docs_context.get("relevant_doc_chunks") or []
    retrieval_diagnostics = docs_context.get("retrieval_diagnostics") or {}
    retrieval_relevance = str(retrieval_diagnostics.get("retrieval_relevance") or ("relevant" if relevant_doc_chunks else "irrelevant"))
    retrieval_notes = str(
        retrieval_diagnostics.get("retrieval_notes")
        or ("Retrieved documentation evidence was available." if relevant_doc_chunks else "No documentation evidence was retrieved.")
    )
    docs_sufficient = bool(relevant_doc_chunks) and retrieval_relevance != "irrelevant"
    primary = classification["primary_error_class"]
    clean_success = primary is None and not evidence["outcome"]["is_suspect_success"]
    if clean_success and not docs_consulted:
        docs_followed: bool | str = "not_applicable"
    elif not docs_consulted:
        docs_followed = False
    elif primary in {"sdk-usage", "false-success", "schema-mismatch", "artifact-reference-error", "stdin-handoff-error", "env-expansion-error", "tool-contract-error"}:
        docs_followed = False
    else:
        docs_followed = True

    if clean_success and not docs_consulted:
        docs_clarity_issue: bool | str = "not_applicable"
    else:
        docs_clarity_issue = docs_consulted and primary in {"false-success", "tool-contract-error"} and docs_followed is False

    return {
        "docs_available": bool((run.get("docs") or {}).get("ok")),
        "docs_consulted": docs_consulted,
        "ground_docs_used": evidence["path_summary"]["ground_docs_used"],
        "docs_sufficient": docs_sufficient,
        "docs_followed": docs_followed,
        "docs_clarity_issue": docs_clarity_issue,
        "retrieval_relevance": retrieval_relevance,
        "retrieval_notes": retrieval_notes,
    }


def _recommendations(classification: Classification, evidence: EvidencePacket, doc_assessment: DocAssessment) -> list[Recommendation]:
    primary = classification["primary_error_class"]
    task_verification = evidence["outcome"].get("task_verification") or {}
    recommendations: list[Recommendation] = []
    if primary is None:
        return [{
            "priority": "low",
            "scope": "reporting",
            "owner": "gauntlet",
            "reason": "This run is a clean baseline.",
            "action": "Treat this run as a clean success baseline for future comparisons.",
        }]
    if primary == "sdk-usage":
        recommendations.extend([
            {
                "priority": "high",
                "scope": "tooling",
                "owner": "gauntlet",
                "reason": "The agent recovered only after an SDK contract mismatch.",
                "action": "Normalize common SDK import and method-path variants before invocation and return a corrective example in the error payload.",
            },
            {
                "priority": "medium",
                "scope": "agent-prompt",
                "owner": "gauntlet",
                "reason": "The model still emits unsupported `run_sdk` shapes.",
                "action": "Teach the agent the exact `run_sdk` factory and method contract with one canonical example.",
            },
        ])
    elif primary == "false-success":
        missing_outputs = task_verification.get("missing_outputs") or []
        missing_artifacts = task_verification.get("missing_artifacts") or []
        recommendations.extend([
            {
                "priority": "high",
                "scope": "agent-prompt",
                "owner": "gauntlet",
                "reason": "The final answer was accepted without fully satisfying the task.",
                "action": f"Tighten finalization rules so required outputs/artifacts are checked before `final`. Missing outputs={missing_outputs}; missing artifacts={missing_artifacts}.",
            },
            {
                "priority": "medium",
                "scope": "layer2-runtime",
                "owner": "gauntlet",
                "reason": "The runtime currently accepts partial completions for extraction-heavy tasks.",
                "action": "Add task-specific satisfaction checks before accepting a final answer.",
            },
        ])
    elif primary in {"env-expansion-error", "tool-contract-error"}:
        recommendations.append({
            "priority": "medium",
            "scope": "runtime",
            "owner": "gauntlet",
            "reason": "The run hit a tool contract or environment handling issue.",
            "action": "Expose the relevant Gauntlet tool contract in the execution state and fail invalid calls before execution with a corrective example.",
        })
    else:
        recommendations.append({
            "priority": "medium",
            "scope": "agent",
            "owner": "gauntlet",
            "reason": "The run took a noisier recovery path than necessary.",
            "action": "Bias the agent toward the shortest docs-aligned recovery path after the first failure.",
        })

    if evidence.get("repeated_pattern"):
        recommendations.append({
            "priority": "medium",
            "scope": "layer2-runtime",
            "owner": "gauntlet",
            "reason": "The same failure pattern appeared repeatedly in a single run.",
            "action": "Detect repeated failing patterns and steer the agent into a different tool family or a docs-grounding step.",
        })
    if not doc_assessment["docs_consulted"] and primary in {"sdk-usage", "tool-contract-error", "false-success"}:
        recommendations.append({
            "priority": "medium",
            "scope": "agent-prompt",
            "owner": "gauntlet",
            "reason": "The run never consulted docs before diverging.",
            "action": "For product workflows, require at least one docs-consult or explicit justification before free-form tool choice.",
        })
    if doc_assessment["docs_consulted"] and doc_assessment["docs_followed"] is False:
        recommendations.append({
            "priority": "low",
            "scope": "docs",
            "owner": "docs-team",
            "reason": "The run consulted docs but still deviated from the likely documented path.",
            "action": "Make the canonical path more obvious in the docs with one short exact-usage example near the top of the relevant section.",
        })
    if doc_assessment["retrieval_relevance"] in {"partial", "irrelevant"}:
        recommendations.append({
            "priority": "medium" if doc_assessment["retrieval_relevance"] == "partial" else "high",
            "scope": "retrieval",
            "owner": "gauntlet",
            "reason": doc_assessment["retrieval_notes"],
            "action": "Improve failure-fact extraction and doc retrieval so the judge sees evidence anchored to the failing tool, error, and payload.",
        })
    return recommendations


def _documentation_evidence(docs_context: DocsContext) -> list[dict[str, Any]]:
    citations: list[dict[str, Any]] = []
    for index, chunk in enumerate(docs_context.get("relevant_doc_chunks") or [], start=1):
        citations.append({
            "citation_id": chunk.get("citation_id") or f"doc-{index}",
            "chunk_id": chunk.get("chunk_id"),
            "path_text": chunk.get("path_text"),
            "why_relevant": chunk.get("why_relevant"),
            "quoted_text": chunk.get("quoted_text") or chunk.get("text") or chunk.get("preview"),
            "line_start": chunk.get("line_start"),
            "line_end": chunk.get("line_end"),
            "source_text": chunk.get("source_text"),
        })
    return citations


def _trace_evidence(evidence: EvidencePacket) -> list[dict[str, Any]]:
    citations: list[dict[str, Any]] = []
    for item in evidence["trace"]["execution_trace"][:6]:
        citations.append({
            "step": item.get("step"),
            "kind": item.get("kind"),
            "tool": item.get("tool"),
            "status": item.get("status"),
            "reason": item.get("error") or item.get("response") or "Relevant execution step.",
        })
    return citations


def _cross_agent_comparison(run: NormalizedRun, batch_context: BatchContext | None, classification: Classification) -> dict[str, Any]:
    if not batch_context:
        return {
            "used_batch_context": False,
            "summary": "Batch context was not used for this judgment.",
            "peer_count": 0,
            "matching_issue_count": 0,
            "divergent_outcomes": [],
            "common_success_patterns": [],
        }
    fingerprint = None
    for peer in batch_context.get("peer_run_summaries", []):
        if peer.get("run_path") == run["run_path"]:
            fingerprint = peer.get("issue_fingerprint")
            break
    matching_issue_count = 0
    if fingerprint:
        matching_issue_count = sum(1 for item in batch_context.get("common_failure_fingerprints", []) if item.get("fingerprint") == fingerprint for _ in [0] for __ in range(item.get("count", 0)))
    peers = [peer for peer in batch_context.get("peer_run_summaries", []) if peer.get("run_path") != run["run_path"]]
    primary = classification["primary_error_class"] or "clean-success"
    if matching_issue_count > 1:
        summary = f"This run shares the same issue fingerprint with {matching_issue_count - 1} peer run(s), suggesting a repeated adoption break."
    elif primary == "clean-success" or primary is None:
        summary = f"This run is one of {len(batch_context.get('common_success_patterns', [])) or 1} observed success patterns in the batch."
    else:
        summary = "This run's issue does not strongly repeat across peers, but batch context still helps compare outcomes."
    return {
        "used_batch_context": True,
        "summary": summary,
        "peer_count": len(peers),
        "matching_issue_count": matching_issue_count,
        "divergent_outcomes": batch_context.get("divergent_outcomes", []),
        "common_success_patterns": batch_context.get("common_success_patterns", []),
    }


def _root_cause(run: NormalizedRun, evidence: EvidencePacket, docs_context: DocsContext, classification: Classification) -> dict[str, str]:
    primary = classification["primary_error_class"]
    error = evidence.get("error")
    chunks = docs_context.get("relevant_doc_chunks") or []
    first_chunk = chunks[0] if chunks else None
    retrieval_relevance = str((docs_context.get("retrieval_diagnostics") or {}).get("retrieval_relevance") or "irrelevant")
    if primary == "false-success":
        return {
            "summary": "The run terminated with a completed status, but the final answer did not fully satisfy the task from the available tool evidence.",
            "why_it_happened": "The agent finalized after partial evidence instead of proving the requested fact or artifact.",
            "why_docs_should_have_prevented_it": f"The retrieved docs section '{first_chunk['path_text']}' contained a path that could have supported a stronger final answer." if first_chunk and retrieval_relevance != "irrelevant" else "The retrieved docs were not strong enough to claim they should have prevented the issue.",
            "counterfactual": "If the agent had taken one more docs-aligned retrieval or extraction step, it likely could have answered the task directly.",
        }
    if primary == "sdk-usage":
        return {
            "summary": "The agent attempted an SDK invocation shape that did not match the runtime contract.",
            "why_it_happened": f"The first failing step used `{evidence.get('failing_tool')}` and hit `{error}`.",
            "why_docs_should_have_prevented_it": f"The docs chunk '{first_chunk['path_text']}' is relevant because it shows the intended SDK usage pattern." if first_chunk and retrieval_relevance != "irrelevant" else "The relevant SDK docs were not retrieved with enough confidence to rely on them.",
            "counterfactual": "If the agent had used the correct SDK factory and method path on the first try, it would have avoided the recovery step.",
        }
    if primary == "provider-failure":
        return {
            "summary": "The run was blocked by a provider/runtime failure before the agent could complete the task.",
            "why_it_happened": f"The model/provider call failed with `{error}`.",
            "why_docs_should_have_prevented_it": "Product documentation could not have prevented a provider transport or empty-response failure.",
            "counterfactual": "If the provider response had been retried or recovered from, the agent could have continued from the checkpointed state.",
        }
    if primary in {"env-expansion-error", "tool-contract-error", "schema-mismatch", "artifact-reference-error", "stdin-handoff-error"}:
        return {
            "summary": f"The run hit a Gauntlet runtime/tool contract issue classified as {primary}.",
            "why_it_happened": f"The failing step used `{evidence.get('failing_tool')}` and hit `{error}`.",
            "why_docs_should_have_prevented_it": "This should be prevented by Gauntlet runtime guidance and pre-execution validation rather than product documentation alone.",
            "counterfactual": "If the harness had exposed and enforced the relevant tool contract before execution, the agent would have avoided this failure path.",
        }
    if primary is None:
        return {
            "summary": "The run completed cleanly with no clear evidence of adoption breakage.",
            "why_it_happened": "The final answer was supported by successful tool evidence and the run did not require recovery.",
            "why_docs_should_have_prevented_it": "The available docs and tool contract were sufficient for this run.",
            "counterfactual": "No corrective action is needed for this specific run.",
        }
    return {
        "summary": f"The dominant issue was classified as {primary}.",
        "why_it_happened": f"The first meaningful failure was `{error}` while working on: {run['task']}",
        "why_docs_should_have_prevented_it": f"The docs chunk '{first_chunk['path_text']}' is the closest relevant section for this failure." if first_chunk and retrieval_relevance != "irrelevant" else "The current retrieval did not surface a clearly relevant docs section for this failure.",
        "counterfactual": "If the agent had followed the shortest docs-aligned path after the first failure, the run likely would have been cleaner.",
    }


def _reproduction(evidence: EvidencePacket) -> dict[str, Any]:
    required = evidence["outcome"]["run_status"] != "completed" or evidence["outcome"]["completed_with_tool_errors"]
    steps = list(evidence["trace"]["reproduction_candidate_steps"])
    if required and not steps:
        steps = [
            item["step"]
            for item in evidence["trace"]["execution_trace"]
            if isinstance(item.get("step"), int)
        ]

    if steps and evidence.get("first_failing_step") is not None:
        summary = "Re-run the task and follow the execution steps up to the first failure."
    elif steps and required:
        summary = "Re-run the task and follow the executed steps until the run terminates without a final answer."
    else:
        summary = "No reproduction path required."

    return {
        "required": required,
        "steps": steps,
        "summary": summary,
    }


def _successful_path(evidence: EvidencePacket) -> dict[str, Any]:
    steps = evidence["trace"]["success_path_steps"]
    return {
        "steps": steps,
        "summary": "These steps represent the successful path that produced the final outcome." if steps else "No successful path was identified.",
    }


def _schema_complete_judgment(
    judgment: JudgeResult,
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    batch_context: BatchContext | None,
    *,
    judge_mode: str,
    repair_reason: str | None = None,
) -> JudgeResult:
    completed = json.loads(json.dumps(judgment))
    deterministic = _deterministic_judge(run, evidence, docs_context, batch_context)

    for field in ("summary", "why_it_happened", "why_docs_should_have_prevented_it", "counterfactual"):
        value = completed.get(field)
        if not isinstance(value, str) or not value.strip():
            completed[field] = deterministic[field]

    for field in ("documentation_evidence", "trace_evidence", "recommendations"):
        if not isinstance(completed.get(field), list):
            completed[field] = deterministic[field]

    for field in ("classification", "doc_assessment", "confidence", "cross_agent_comparison"):
        if not isinstance(completed.get(field), dict):
            completed[field] = deterministic[field]

    for field in ("reproduction", "successful_path"):
        plan = completed.get(field)
        if not isinstance(plan, dict):
            completed[field] = deterministic[field]
            continue
        summary = plan.get("summary")
        if not isinstance(summary, str) or not summary.strip():
            plan["summary"] = deterministic[field]["summary"]
        if not isinstance(plan.get("steps"), list):
            plan["steps"] = deterministic[field]["steps"]
        if field == "reproduction" and "required" not in plan:
            plan["required"] = deterministic[field].get("required", False)

    confidence = completed.setdefault("confidence", {})
    if isinstance(confidence, dict):
        confidence.setdefault("judge_mode", judge_mode)
        confidence.setdefault("batch_context_used", bool(batch_context))
        if repair_reason:
            confidence.setdefault("repair_reason", repair_reason)
        confidence.setdefault("schema_completed", True)
    return completed


def _llm_prompt(run: NormalizedRun, evidence: EvidencePacket, docs_context: DocsContext, batch_context: BatchContext | None) -> str:
    doc_chunks = []
    for chunk in docs_context.get("relevant_doc_chunks", []):
        doc_chunks.append({
            "citation_id": chunk.get("citation_id"),
            "chunk_id": chunk.get("chunk_id"),
            "path_text": chunk.get("path_text"),
            "why_relevant": chunk.get("why_relevant"),
            "quoted_text": chunk.get("quoted_text"),
            "line_start": chunk.get("line_start"),
            "line_end": chunk.get("line_end"),
            "source_text": chunk.get("source_text"),
        })
    prompt_payload = {
        "run": {
            "task": run["task"],
            "persona": run["persona"],
            "provider": run["provider"],
            "model": run["model"],
            "status": run["status"],
        },
        "evidence": evidence,
        "docs_context": {
            "llms_source": docs_context.get("llms_source"),
            "llms_full_source": docs_context.get("llms_full_source"),
            "grounding_block": docs_context.get("grounding_block"),
            "retrieval_query": docs_context.get("retrieval_query"),
            "retrieval_diagnostics": docs_context.get("retrieval_diagnostics"),
            "relevant_doc_chunks": doc_chunks,
        },
        "batch_context": batch_context,
    }
    return (
        "You are the Layer 3 reasoning judge. Use only the provided evidence, docs citations, and batch context. "
        "Return exactly one JSON object and no surrounding prose or markdown fences. "
        "Use this exact shape and preserve object-vs-array structure exactly:\n"
        "{\n"
        '  "summary": "string",\n'
        '  "why_it_happened": "string",\n'
        '  "documentation_evidence": [\n'
        "    {\n"
        '      "citation_id": "string or null",\n'
        '      "chunk_id": "string or null",\n'
        '      "path_text": "string or null",\n'
        '      "why_relevant": "string or null",\n'
        '      "quoted_text": "string or null"\n'
        "    }\n"
        "  ],\n"
        '  "trace_evidence": [\n'
        "    {\n"
        '      "step": 1,\n'
        '      "kind": "tool|final|parse_error",\n'
        '      "tool": "string or null",\n'
        '      "status": "succeeded|failed|completed",\n'
        '      "reason": "string"\n'
        "    }\n"
        "  ],\n"
        '  "classification": {\n'
        '    "primary_error_class": "artifact-reference-error|stdin-handoff-error|env-expansion-error|schema-mismatch|false-success|provider-failure|recovered-auth-error|clean-success|reasoning/recovery|sdk-usage|tool-contract-error|null",\n'
        '    "secondary_error_classes": ["string"],\n'
        '    "blame_surface": "agent|runtime|environment|docs|mixed|not_applicable|null",\n'
        '    "classification_confidence": 0.0,\n'
        '    "blame_confidence": 0.0\n'
        "  },\n"
        '  "reproduction": {\n'
        '    "required": true,\n'
        '    "steps": [1],\n'
        '    "summary": "string"\n'
        "  },\n"
        '  "successful_path": {\n'
        '    "steps": [1],\n'
        '    "summary": "string"\n'
        "  },\n"
        '  "cross_agent_comparison": {},\n'
        '  "confidence": {},\n'
        '  "recommendations": [\n'
        "    {\n"
        '      "priority": "string",\n'
        '      "scope": "string",\n'
        '      "owner": "string",\n'
        '      "reason": "string",\n'
        '      "action": "string"\n'
        "    }\n"
        "  ],\n"
        '  "doc_assessment": {\n'
        '    "docs_available": true,\n'
        '    "docs_consulted": true,\n'
        '    "ground_docs_used": true,\n'
        '    "docs_sufficient": true,\n'
        '    "docs_followed": true,\n'
        '    "docs_clarity_issue": false,\n'
        '    "retrieval_relevance": "relevant|partial|irrelevant",\n'
        '    "retrieval_notes": "string"\n'
        "  },\n"
        '  "why_docs_should_have_prevented_it": "string",\n'
        '  "counterfactual": "string"\n'
        "}\n"
        "Do not change field names. Do not replace objects with strings. "
        "Use null for unknown nullable fields, not omitted keys. "
        "Only cite citation_id/chunk_id values that exist in the provided docs context. "
        "Only cite step numbers that exist in the provided trace. "
        "Inside doc_assessment, explicitly set retrieval_relevance to one of relevant, partial, or irrelevant, "
        "and explain that decision in retrieval_notes. If the retrieved docs look weak or off-topic, say so. "
        "Do not invent citations or steps.\n\n"
        + json.dumps(prompt_payload, ensure_ascii=True)
    )


def _repair_llm_prompt(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    batch_context: BatchContext | None,
    invalid_judgment: JudgeResult,
    validation_error: str,
) -> str:
    original_prompt = _llm_prompt(run, evidence, docs_context, batch_context)
    return (
        original_prompt
        + "\n\n"
        + "Your previous response was invalid against the required schema. "
        + "Repair only the invalid fields and keep all valid reasoning unchanged. "
        + "Return exactly one JSON object and no surrounding prose or markdown fences.\n\n"
        + "Validation error:\n"
        + validation_error
        + "\n\n"
        + "Previous invalid JSON:\n"
        + json.dumps(invalid_judgment, ensure_ascii=True)
        + "\n\n"
        + "Important repair rules:\n"
        + "- Every required top-level field must be present.\n"
        + "- summary, why_it_happened, why_docs_should_have_prevented_it, and counterfactual must be non-empty strings.\n"
        + "- classification and doc_assessment must remain JSON objects, never strings.\n"
        + "- reproduction and successful_path must remain JSON objects with a non-empty summary string and a steps array.\n"
        + "- recommendations, documentation_evidence, and trace_evidence must be arrays.\n"
        + "- If docs were irrelevant or insufficient, why_docs_should_have_prevented_it must still be a non-empty explanatory string saying why docs should not or could not have prevented the issue.\n"
    )


def _truncate_text(text: str, limit: int = 240) -> str:
    if len(text) <= limit:
        return text
    omitted = len(text) - limit
    return text[:limit] + f"... <truncated {omitted} chars>"


def _parse_judge_response(response_text: str) -> JudgeResult:
    candidate = response_text.strip()
    if not candidate:
        raise ValueError("Judge model returned empty text")
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 3:
            candidate = "\n".join(lines[1:-1]).strip()
    start = candidate.find("{")
    end = candidate.rfind("}")
    if start == -1 or end == -1 or end < start:
        preview = _truncate_text(candidate.replace("\n", "\\n"))
        raise ValueError(f"Judge model did not return a JSON object. Response preview: {preview!r}")
    try:
        data = json.loads(candidate[start : end + 1])
    except json.JSONDecodeError as exc:
        preview = _truncate_text(candidate.replace("\n", "\\n"))
        raise ValueError(f"Judge model returned invalid JSON. Response preview: {preview!r}") from exc
    if not isinstance(data, dict):
        raise ValueError("Judge model did not return a JSON object")
    return data


def _valid_trace_steps(evidence: EvidencePacket) -> set[int]:
    steps: set[int] = set()
    for item in evidence["trace"]["execution_trace"]:
        step = item.get("step")
        if isinstance(step, int):
            steps.add(step)
    return steps


def _sanitize_llm_judgment_references(
    judgment: JudgeResult,
    evidence: EvidencePacket,
    docs_context: DocsContext,
) -> tuple[JudgeResult, list[str]]:
    """Remove hallucinated references while preserving the judge's reasoning."""

    sanitized = json.loads(json.dumps(judgment))
    notes: list[str] = []

    valid_citation_ids = {
        chunk.get("citation_id")
        for chunk in docs_context.get("relevant_doc_chunks", [])
        if chunk.get("citation_id") is not None
    }
    valid_chunk_ids = {
        chunk.get("chunk_id")
        for chunk in docs_context.get("relevant_doc_chunks", [])
        if chunk.get("chunk_id") is not None
    }

    doc_evidence = sanitized.get("documentation_evidence")
    if isinstance(doc_evidence, list):
        has_unknown_doc_ref = False
        for citation in doc_evidence:
            if not isinstance(citation, dict):
                continue
            citation_id = citation.get("citation_id")
            chunk_id = citation.get("chunk_id")
            if citation_id is not None and citation_id not in valid_citation_ids:
                has_unknown_doc_ref = True
            if chunk_id is not None and chunk_id not in valid_chunk_ids:
                has_unknown_doc_ref = True
        if has_unknown_doc_ref:
            sanitized["documentation_evidence"] = _documentation_evidence(docs_context)
            notes.append("Replaced hallucinated documentation citations with retrieved docs context citations.")

    valid_steps = _valid_trace_steps(evidence)
    trace_evidence = sanitized.get("trace_evidence")
    if isinstance(trace_evidence, list):
        for citation in trace_evidence:
            if not isinstance(citation, dict):
                continue
            step = citation.get("step")
            if step is not None and step not in valid_steps:
                citation["step"] = None
                notes.append("Removed hallucinated trace step from trace_evidence.")

    reproduction = sanitized.get("reproduction")
    if isinstance(reproduction, dict) and isinstance(reproduction.get("steps"), list):
        filtered_steps = [step for step in reproduction["steps"] if step in valid_steps]
        if filtered_steps != reproduction["steps"]:
            reproduction["steps"] = filtered_steps
            notes.append("Removed hallucinated step from reproduction.steps.")
        if reproduction.get("required") and not reproduction["steps"]:
            sanitized["reproduction"] = _reproduction(evidence)
            notes.append("Replaced empty required reproduction with trace-derived reproduction.")

    successful_path = sanitized.get("successful_path")
    if isinstance(successful_path, dict) and isinstance(successful_path.get("steps"), list):
        filtered_steps = [step for step in successful_path["steps"] if step in valid_steps]
        if filtered_steps != successful_path["steps"]:
            successful_path["steps"] = filtered_steps
            notes.append("Removed hallucinated step from successful_path.steps.")
        if evidence["trace"]["success_path_steps"] and not successful_path["steps"]:
            sanitized["successful_path"] = _successful_path(evidence)
            notes.append("Replaced empty successful_path with trace-derived successful path.")

    if notes:
        confidence = sanitized.setdefault("confidence", {})
        if isinstance(confidence, dict):
            confidence["reference_sanitization"] = sorted(set(notes))

    classification = sanitized.get("classification")
    if isinstance(classification, dict):
        primary = classification.get("primary_error_class")
        class_aliases = {
            "tool-selection": "tool-contract-error",
            "documentation-resolution": "tool-contract-error",
            "environment/network": "tool-contract-error",
            "cli-execution": "tool-contract-error",
            "parsing/formatting": "schema-mismatch",
            "provider-error": "provider-failure",
        }
        if primary in class_aliases:
            classification["primary_error_class"] = class_aliases[primary]
            notes.append(f"Normalized primary_error_class {primary!r}.")
        primary = classification.get("primary_error_class")
        if primary == "sdk-usage" and not _sdk_evidence_present(evidence):
            if evidence["outcome"].get("task_status") == "success" and evidence["outcome"].get("completed_with_tool_errors"):
                classification["primary_error_class"] = "reasoning/recovery"
                secondary = classification.setdefault("secondary_error_classes", [])
                if isinstance(secondary, list) and "tool-contract-error" not in secondary:
                    secondary.append("tool-contract-error")
            elif evidence["outcome"].get("task_status") == "suspect_success":
                classification["primary_error_class"] = "false-success"
            else:
                classification["primary_error_class"] = "tool-contract-error"
            notes.append("Replaced sdk-usage classification because no SDK use appears in the trace.")

    return sanitized, notes


def _try_llm_judge(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    batch_context: BatchContext | None,
    judge_config: JudgeConfig,
) -> JudgeResult | None:
    if not judge_config.provider or not judge_config.model:
        return None
    prompt = _llm_prompt(run, evidence, docs_context, None if judge_config.disable_batch_context else batch_context)
    response_text = send_prompt(ProviderConfig(name=judge_config.provider, model=judge_config.model), prompt)
    return _parse_judge_response(response_text)


def _repair_llm_judgment(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    batch_context: BatchContext | None,
    judge_config: JudgeConfig,
    invalid_judgment: JudgeResult,
    validation_error: str,
) -> JudgeResult:
    prompt = _repair_llm_prompt(
        run,
        evidence,
        docs_context,
        None if judge_config.disable_batch_context else batch_context,
        invalid_judgment,
        validation_error,
    )
    response_text = send_prompt(ProviderConfig(name=judge_config.provider, model=judge_config.model), prompt)
    return _parse_judge_response(response_text)


def _deterministic_judge(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    batch_context: BatchContext | None,
) -> JudgeResult:
    classification = _classify(run, evidence)
    if classification["primary_error_class"] is not None and classification["primary_error_class"] not in ALLOWED_ERROR_CLASSES:
        raise ValueError(f"Unsupported primary_error_class: {classification['primary_error_class']}")
    if classification["blame_surface"] is not None and classification["blame_surface"] not in ALLOWED_BLAME_SURFACES:
        raise ValueError(f"Unsupported blame_surface: {classification['blame_surface']}")
    doc_assessment = _doc_assessment(run, evidence, docs_context, classification)
    recommendations = _recommendations(classification, evidence, doc_assessment)
    root_cause = _root_cause(run, evidence, docs_context, classification)
    return {
        "summary": root_cause["summary"],
        "why_it_happened": root_cause["why_it_happened"],
        "documentation_evidence": _documentation_evidence(docs_context),
        "trace_evidence": _trace_evidence(evidence),
        "classification": classification,
        "reproduction": _reproduction(evidence),
        "successful_path": _successful_path(evidence),
        "cross_agent_comparison": _cross_agent_comparison(run, batch_context, classification),
        "confidence": {
            "classification_confidence": classification["classification_confidence"],
            "blame_confidence": classification["blame_confidence"],
            "batch_context_used": bool(batch_context),
            "judge_mode": "deterministic",
        },
        "recommendations": recommendations,
        "doc_assessment": doc_assessment,
        "why_docs_should_have_prevented_it": root_cause["why_docs_should_have_prevented_it"],
        "counterfactual": root_cause["counterfactual"],
    }


def run_reasoning_judge(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_context: DocsContext,
    batch_context: BatchContext | None = None,
    judge_config: JudgeConfig | None = None,
) -> JudgeResult:
    effective_batch_context = None if (judge_config and judge_config.disable_batch_context) else batch_context
    if judge_config:
        try:
            judgment = _try_llm_judge(run, evidence, docs_context, effective_batch_context, judge_config)
            if judgment is not None:
                try:
                    sanitized, notes = _sanitize_llm_judgment_references(judgment, evidence, docs_context)
                    sanitized = _schema_complete_judgment(
                        sanitized,
                        run,
                        evidence,
                        docs_context,
                        effective_batch_context,
                        judge_mode="llm_sanitized" if notes else "llm",
                    )
                    validate_judgment(sanitized, evidence, docs_context)
                    confidence = sanitized.get("confidence")
                    if isinstance(confidence, dict):
                        confidence.setdefault("judge_mode", "llm_sanitized" if notes else "llm")
                        confidence.setdefault("batch_context_used", bool(effective_batch_context))
                    return sanitized
                except ValueError as validation_error:
                    try:
                        repaired = _repair_llm_judgment(
                            run,
                            evidence,
                            docs_context,
                            effective_batch_context,
                            judge_config,
                            judgment,
                            str(validation_error),
                        )
                        sanitized_repaired, notes = _sanitize_llm_judgment_references(repaired, evidence, docs_context)
                        sanitized_repaired = _schema_complete_judgment(
                            sanitized_repaired,
                            run,
                            evidence,
                            docs_context,
                            effective_batch_context,
                            judge_mode="llm_repaired_sanitized" if notes else "llm_repaired",
                            repair_reason=str(validation_error),
                        )
                        validate_judgment(sanitized_repaired, evidence, docs_context)
                        confidence = sanitized_repaired.get("confidence")
                        if isinstance(confidence, dict):
                            confidence.setdefault("judge_mode", "llm_repaired_sanitized" if notes else "llm_repaired")
                            confidence.setdefault("batch_context_used", bool(effective_batch_context))
                            confidence.setdefault("repair_reason", str(validation_error))
                        return sanitized_repaired
                    except Exception:
                        if not judge_config.fallback_deterministic:
                            raise
                        print(
                            f"[gauntlet] LLM judge repair failed after validation error: {validation_error}. Falling back to deterministic judge.",
                            flush=True,
                        )
                        return _deterministic_judge(run, evidence, docs_context, effective_batch_context)
        except Exception as e:
            if not judge_config.fallback_deterministic:
                raise
            print(f"[gauntlet] LLM judge failed with error: {e}. Falling back to deterministic judge.", flush=True)
    return _deterministic_judge(run, evidence, docs_context, effective_batch_context)
