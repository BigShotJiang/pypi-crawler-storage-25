from __future__ import annotations

import asyncio
from typing import Any

from gauntlet.layer1.llms_docs import build_runtime_doc_grounding, load_llms_docs
from gauntlet.layer3.contracts import DocsContext, EvidencePacket, NormalizedRun, RetrievedDocChunk

GAUNTLET_TOOL_SCHEMAS = {
    "run_http": "Make an HTTP request. Arguments: method, url, body?, headers?, headers_from_env?, query?, timeout_seconds?. Does not expand shell variables.",
    "run_cli": "Run a CLI command. Arguments: command, cwd?, env?, timeout_seconds?, shell?. shell=true expands environment variables.",
    "run_python": "Execute Python code. Arguments: code, cwd?, env?, timeout_seconds?, stdin_from_step?, stdin_path?. It does not automatically receive prior stdout.",
}


class DocsCache:
    def __init__(self) -> None:
        self._cache: dict[tuple[str | None, str | None], dict[str, Any]] = {}

    def get(self, llms_source: str | None, llms_full_source: str | None) -> dict[str, Any]:
        key = (llms_source, llms_full_source)
        if key not in self._cache:
            self._cache[key] = asyncio.run(
                load_llms_docs(
                    llms_source=llms_source,
                    llms_full_source=llms_full_source,
                )
            )
        return self._cache[key]


def _quoted_text_from_chunk(chunk_text: str, *, max_chars: int = 1200) -> str | None:
    if not chunk_text:
        return None

    parts: list[str] = []
    total = 0
    for raw_line in chunk_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        projected = total + len(line) + (1 if parts else 0)
        if projected > max_chars and parts:
            break
        if projected > max_chars:
            parts.append(line[:max_chars])
            break
        parts.append(line)
        total = projected

    if not parts:
        trimmed = chunk_text.strip()
        return trimmed[:max_chars] if trimmed else None
    return "\n".join(parts)


def _quoted_span_within_chunk(chunk_text: str, quoted_text: str | None) -> tuple[int | None, int | None]:
    if not chunk_text or not quoted_text:
        return None, None
    start = chunk_text.find(quoted_text)
    if start == -1:
        return None, None
    end = start + len(quoted_text)
    return start, end


def _build_retrieved_doc_chunk(
    chunk: dict[str, Any],
    *,
    llms_full_source: str | None,
    evidence: EvidencePacket,
) -> RetrievedDocChunk:
    chunk_text = chunk.get("text")
    if not isinstance(chunk_text, str):
        chunk_text = ""

    quoted_text = _quoted_text_from_chunk(chunk_text)
    quoted_start_in_chunk, quoted_end_in_chunk = _quoted_span_within_chunk(chunk_text, quoted_text)

    chunk_start_char = chunk.get("start_char")
    chunk_end_char = chunk.get("end_char")
    chunk_line_start = chunk.get("line_start")
    chunk_line_end = chunk.get("line_end")

    start_char = chunk_start_char
    end_char = chunk_end_char
    line_start = chunk_line_start
    line_end = chunk_line_end

    if (
        isinstance(chunk_start_char, int)
        and quoted_start_in_chunk is not None
        and quoted_end_in_chunk is not None
    ):
        start_char = chunk_start_char + quoted_start_in_chunk
        end_char = chunk_start_char + quoted_end_in_chunk

    if isinstance(chunk_line_start, int) and quoted_text:
        quoted_line_count = max(len(quoted_text.splitlines()), 1)
        line_start = chunk_line_start
        line_end = chunk_line_start + quoted_line_count - 1

    chunk_id = chunk.get("chunk_id")
    citation_suffix = (
        f"{line_start}-{line_end}"
        if line_start is not None and line_end is not None
        else "unknown-span"
    )

    return {
        "citation_id": f"{chunk_id}:{citation_suffix}" if chunk_id else f"doc:{citation_suffix}",
        "chunk_id": chunk_id,
        "path_text": chunk.get("path_text"),
        "title": chunk.get("title"),
        "preview": chunk.get("preview"),
        "text": chunk_text,
        "source_text": llms_full_source,
        "start_char": start_char,
        "end_char": end_char,
        "line_start": line_start,
        "line_end": line_end,
        "quoted_text": quoted_text,
        "rerank_score": chunk.get("rerank_score"),
        "anchor_overlap_count": chunk.get("anchor_overlap_count"),
        "why_relevant": (
            f"Matches the task/error query for {evidence.get('failing_tool') or 'the run'}"
        ),
    }


def retrieve_relevant_doc_chunks(
    run: NormalizedRun,
    evidence: EvidencePacket,
    docs_cache: DocsCache,
    *,
    max_chunks: int = 3,
) -> DocsContext:
    docs = docs_cache.get(run.get("llms_source"), run.get("llms_full_source"))
    raw_failure_facts = evidence.get("raw_failure_facts") or {}
    previous_output = raw_failure_facts.get("previous_output")
    failure_payload = raw_failure_facts.get("failure_payload")
    if previous_output and failure_payload:
        previous_output = f"{previous_output}\n\nFailure payload:\n{failure_payload}"
    elif failure_payload:
        previous_output = str(failure_payload)

    grounding = build_runtime_doc_grounding(
        task=raw_failure_facts.get("task") or run.get("task"),
        previous_output=previous_output,
        current_error=raw_failure_facts.get("error") or evidence.get("error"),
        next_goal=raw_failure_facts.get("next_goal"),
        llms_text=docs["llms_text"],
        llms_full_text=docs["llms_full_text"],
        tool_schemas=GAUNTLET_TOOL_SCHEMAS,
        retrieval_hints=raw_failure_facts,
        max_chunks=max_chunks,
    )

    relevant_chunks: list[RetrievedDocChunk] = []
    for chunk in grounding.get("retrieved_chunks", []):
        relevant_chunks.append(
            _build_retrieved_doc_chunk(
                chunk,
                llms_full_source=docs.get("llms_full_source"),
                evidence=evidence,
            )
        )

    return {
        "llms_source": docs.get("llms_source"),
        "llms_full_source": docs.get("llms_full_source"),
        "manifest": docs.get("llms_manifest"),
        "grounding_block": grounding.get("grounding_block"),
        "retrieval_query": grounding.get("retrieval_query"),
        "retrieval_diagnostics": grounding.get("retrieval_diagnostics"),
        "relevant_doc_chunks": relevant_chunks,
    }
