from __future__ import annotations

import json
import re
from typing import Any

from gauntlet.task_validation import infer_task_spec as _shared_infer_task_spec
from gauntlet.task_validation import validate_interface_usage


RUN_STATUSES = {"completed", "crashed", "timeout", "max_steps_exceeded", "provider_error"}
TASK_STATUSES = {
    "success",
    "failure",
    "blocked_by_provider",
    "blocked_by_credentials",
    "suspect_success",
    "schema_mismatch",
}


def _contains_any(text: str, needles: tuple[str, ...]) -> bool:
    lowered = text.lower()
    return any(needle in lowered for needle in needles)


def _tool_names(run: dict[str, Any]) -> list[str]:
    names: list[str] = []
    for step in run.get("steps") or []:
        tool = step.get("tool") or {}
        name = tool.get("name")
        if isinstance(name, str):
            names.append(name)
    return names


def _all_tool_text(run: dict[str, Any]) -> str:
    parts: list[str] = []
    for step in run.get("steps") or []:
        for key in ("response", "tool", "tool_result", "parse_error", "validation_errors"):
            value = step.get(key)
            if value is not None:
                parts.append(str(value))
    if run.get("failure"):
        parts.append(str(run.get("failure")))
    if run.get("final_response"):
        parts.append(str(run.get("final_response")))
    return "\n".join(parts)


def _failure_text(run: dict[str, Any]) -> str:
    parts: list[str] = []
    for step in run.get("steps") or []:
        tool_result = step.get("tool_result") or {}
        if tool_result.get("ok") is False:
            parts.append(str(tool_result))
        parse_error = step.get("parse_error")
        if parse_error:
            parts.append(str(parse_error))
        validation_errors = step.get("validation_errors")
        if validation_errors:
            parts.append(str(validation_errors))
    if run.get("failure"):
        parts.append(str(run.get("failure")))
    return "\n".join(parts)


def _has_artifact(text: str, artifact_name: str) -> bool:
    lowered = text.lower()
    if artifact_name == "screenshot_url":
        return bool(re.search(r"https?://\S+\.(?:png|jpg|jpeg|webp)\b|\b\S+\.png\b|\bscreenshot\b", lowered))
    if artifact_name == "pdf_url":
        return bool(re.search(r"https?://\S+\.pdf\b|\b\S+\.pdf\b|\bpdf\b", lowered))
    if artifact_name == "zip_path":
        return bool(re.search(r"\b\S+\.zip\b|\bzip\b", lowered))
    if artifact_name == "live_session_link":
        return bool(re.search(r"https?://\S+", lowered)) and "session" in lowered
    return artifact_name.lower() in lowered


def _has_screenshot_path(text: str) -> bool:
    return bool(re.search(r"(?:https?://\S+|\.?/?[\w./-]+)\.(?:png|jpg|jpeg|webp)\b", text, flags=re.I))


def _has_pdf_path(text: str) -> bool:
    return bool(re.search(r"(?:https?://\S+|\.?/?[\w./-]+)\.pdf\b", text, flags=re.I))


def _count_links(text: str) -> int:
    return len(re.findall(r"https?://[^\s,)>\"]+", text))


def _count_list_like_items(text: str) -> int:
    bulleted = len(re.findall(r"(?m)^\s*(?:[-*]|\d+[.)])\s+\S", text))
    if bulleted:
        return bulleted
    quoted = re.findall(r"[\"\u201c]([^\"\u201c\u201d]{3,200})[\"\u201d]", text)
    return len(quoted)


def _parse_final_json(final_text: str) -> Any | None:
    candidate = final_text.strip()
    if not candidate:
        return None
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 3:
            candidate = "\n".join(lines[1:-1]).strip()
    start_candidates = [index for index in (candidate.find("{"), candidate.find("[")) if index != -1]
    if not start_candidates:
        return None
    start = min(start_candidates)
    end = max(candidate.rfind("}"), candidate.rfind("]"))
    if end < start:
        return None
    try:
        return json.loads(candidate[start : end + 1])
    except json.JSONDecodeError:
        return None


def _iter_structured_fields(value: Any, prefix: str = "") -> list[tuple[str, Any]]:
    fields: list[tuple[str, Any]] = []
    if isinstance(value, dict):
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            fields.append((path, child))
            fields.extend(_iter_structured_fields(child, path))
    elif isinstance(value, list):
        for child in value[:3]:
            fields.extend(_iter_structured_fields(child, f"{prefix}[]"))
    return fields


def _field_tokens(path: str) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", path.lower()) if token}


def _string_items(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return []


def _absolute_urls(items: list[str]) -> list[str]:
    return [item for item in items if re.match(r"^https?://", item)]


def _structured_output_satisfies(name: str, structured: Any) -> bool:
    if structured is None:
        return False
    fields = _iter_structured_fields(structured)
    if name == "page_title":
        for path, value in fields:
            tokens = _field_tokens(path)
            if "title" in tokens and isinstance(value, str) and value.strip():
                return True
        return False
    if name == "page_summary":
        for path, value in fields:
            tokens = _field_tokens(path)
            if "summary" in tokens and isinstance(value, str) and len(value.split()) >= 6:
                return True
        return False
    if name in {"10_story_titles", "5_items"}:
        required_count = 10 if name == "10_story_titles" else 5
        for path, value in fields:
            tokens = _field_tokens(path)
            items = _string_items(value)
            if len(items) >= required_count and ({"title", "titles"} & tokens or "items" in tokens or "stories" in tokens):
                return True
        return False
    if name in {"10_links", "links"}:
        required_count = 10 if name == "10_links" else 1
        for path, value in fields:
            tokens = _field_tokens(path)
            items = _string_items(value)
            if len(_absolute_urls(items)) >= required_count and ({"link", "links", "url", "urls"} & tokens):
                return True
        return False
    if name == "screenshot_url_or_path":
        for path, value in fields:
            if "screenshot" in _field_tokens(path) and isinstance(value, str) and (_has_screenshot_path(value) or re.match(r"^https?://", value)):
                return True
        return False
    if name == "pdf_url_or_path":
        for path, value in fields:
            if "pdf" in _field_tokens(path) and isinstance(value, str) and (_has_pdf_path(value) or re.match(r"^https?://", value)):
                return True
        return False
    return False


def _final_has_unsupported_artifact_reference(final_text: str) -> bool:
    lowered = final_text.lower()
    return (
        bool(re.search(r"\$steps\[\d+\]\.artifacts\.", final_text))
        or "not sure where" in lowered
        or "check the json output" in lowered
        or "available within the json output" in lowered
    )


def infer_task_spec(task: str) -> dict[str, Any]:
    return _shared_infer_task_spec(task)


_COMPLETION_CLAIM_RE = re.compile(
    r"\b(?:successfully|completed?|finished|all\s+(?:set|good)|task\s+(?:complete|done)|"
    r"as\s+requested|i\s+have\s+(?:successfully|completed|finished|extracted|fetched|generated|saved))\b",
    re.IGNORECASE,
)
_INABILITY_RE = re.compile(
    r"\b(?:unable\s+to|could\s*n['’]?t|cannot|can'?t|failed\s+to|was\s+not\s+able|did\s+not\s+(?:succeed|manage)|"
    r"no\s+(?:screenshot|pdf|artifact)\s+(?:was\s+)?(?:produced|saved|generated))\b",
    re.IGNORECASE,
)


def _claims_completion(final_text: str) -> bool:
    if _INABILITY_RE.search(final_text):
        return False
    return bool(_COMPLETION_CLAIM_RE.search(final_text))


def _failure_labels(
    *,
    task_status: str,
    run_status: str,
    missing_tools: list[str],
    missing_interfaces: list[str],
    forbidden_tools_used: list[str],
    forbidden_interfaces_used: list[str],
    missing_outputs: list[str],
    missing_artifacts: list[str],
    final_text: str,
) -> list[str]:
    if task_status == "blocked_by_provider":
        return ["provider_failure"]

    labels: list[str] = []
    if forbidden_tools_used or forbidden_interfaces_used or missing_tools or missing_interfaces:
        labels.append("answer_correct_but_constraint_violated")
    if missing_outputs:
        labels.append("missing_required_output")
    if missing_artifacts:
        labels.append("missing_required_artifact")
    if task_status == "suspect_success" and final_text and _claims_completion(final_text):
        labels.append("hallucinated_success")
    if task_status == "failure" or (run_status != "completed" and not labels):
        labels.append("answer_wrong")
    if task_status == "schema_mismatch":
        labels.append("schema_mismatch")
    if task_status == "blocked_by_provider":
        labels.append("provider_failure")
    return list(dict.fromkeys(labels))


def _failure_source(failures_text: str, interface_validation: dict[str, Any]) -> str | None:
    lowered = failures_text.lower()
    gauntlet_needles = (
        "run_cli command",
        "read_doc only accepts",
        "tool arguments must",
        "schema_validation",
        "missing_required_argument",
        "invalid_tool_arguments",
        "unsupported tool",
    )
    if any(needle in lowered for needle in gauntlet_needles):
        return "gauntlet_tool_contract_confusion"
    return None


def classify_run_status(run: dict[str, Any]) -> str:
    explicit = run.get("run_status")
    if explicit in RUN_STATUSES:
        return str(explicit)
    status = run.get("status")
    failure_type = (run.get("failure") or {}).get("type")
    if status == "completed":
        return "completed"
    if failure_type == "max_steps_exceeded":
        return "timeout"
    if failure_type in {"model_call_failed", "docs_load_failed"}:
        return "crashed"
    return "crashed"


def _environment_blocked(text: str, run: dict[str, Any]) -> bool:
    env = run.get("environment") or {}
    node_major = env.get("node_major")
    if isinstance(node_major, int) and node_major < 20 and _contains_any(text, ("playwright", "node", "npm")):
        return True
    return _contains_any(
        text,
        (
            "node version",
            "unsupported engine",
            "playwright install",
            "browser dependencies",
            "executable doesn't exist",
            "module not found",
            "no module named playwright",
        ),
    )


def _credentials_blocked(text: str) -> bool:
    return _contains_any(
        text,
        (
            "401",
            "403",
            "unauthorized",
            "forbidden",
            "api key",
            "missing credential",
            "missing steel_api_key",
            "invalid token",
        ),
    )


def _check_required_output(name: str, final_text: str, all_text: str, structured_final: Any | None = None) -> bool:
    combined = final_text
    if _structured_output_satisfies(name, structured_final):
        return True
    if name == "page_title":
        return bool(
            re.search(r"(?:page\s+)?title\s*(?:[:=-]|is|was|=)\s*[\"'\u201c]?\S+", combined, flags=re.I)
        )
    if name == "page_summary":
        words = re.findall(r"\b[a-zA-Z]{3,}\b", final_text)
        return len(words) >= 12 and not _final_has_unsupported_artifact_reference(final_text)
    if name == "screenshot_url_or_path":
        return _has_screenshot_path(final_text)
    if name == "pdf_url_or_path":
        return _has_pdf_path(final_text)
    if name == "10_story_titles":
        return _count_list_like_items(final_text) >= 10 or len(re.findall(r"\btitle\b", final_text, flags=re.I)) >= 10
    if name == "10_links":
        return _count_links(final_text) >= 10
    if name == "5_items":
        return _count_list_like_items(final_text) >= 5
    if name == "links":
        return _count_links(combined) > 0
    if name == "cleanup_confirmation":
        return _contains_any(combined, ("released", "closed", "cleanup", "cleaned up"))
    if name == "auth_success_confirmation":
        return _contains_any(combined, ("secure area", "authenticated", "logged in", "login succeeded"))
    if name == "upload_success_confirmation":
        return _contains_any(combined, ("file uploaded", "upload success", "uploaded successfully"))
    if name == "captcha_outcome":
        return _contains_any(combined, ("captcha", "turnstile", "accepted", "blocked"))
    if name == "proxy_observation":
        return _contains_any(combined, ("proxy", "region", "ip", "origin"))
    return name.lower() in combined.lower()


def verify_task(run: dict[str, Any]) -> dict[str, Any]:
    spec = infer_task_spec(str(run.get("task") or ""))
    run_status = classify_run_status(run)
    tools_used = _tool_names(run)
    final_text = str(run.get("final_response") or "")
    structured_final = _parse_final_json(final_text)
    all_text = _all_tool_text(run)
    failures_text = _failure_text(run)

    missing_tools = [tool for tool in spec["required_tools"] if tool not in tools_used]
    forbidden_tools_used = [tool for tool in spec["forbidden_tools"] if tool in tools_used]
    interface_validation = validate_interface_usage(run, spec)
    missing_interfaces = list(interface_validation["missing_interfaces"])
    forbidden_interfaces_used = list(interface_validation["forbidden_interfaces_used"])
    missing_outputs = [
        output
        for output in spec["required_outputs"]
        if not _check_required_output(output, final_text, all_text, structured_final)
    ]
    missing_artifacts = [
        artifact
        for artifact in spec["required_artifacts"]
        if not _has_artifact(final_text, artifact)
    ]
    has_schema_error = bool(
        (run.get("failure") or {}).get("type") in {"tool_schema_validation_failed", "invalid_tool_arguments", "unknown_tool"}
        or any(step.get("validation_errors") for step in run.get("steps") or [])
    )
    provider_blocked = (run.get("failure") or {}).get("type") in {"model_call_failed", "docs_load_failed"}
    recovered_auth_error = (
        _credentials_blocked(failures_text)
        and run_status == "completed"
        and bool(final_text.strip())
    )
    unsupported_artifact_reference = _final_has_unsupported_artifact_reference(final_text)

    if provider_blocked:
        task_status = "blocked_by_provider"
    elif _environment_blocked(failures_text, run):
        task_status = "failure"
    elif has_schema_error:
        task_status = "schema_mismatch"
    elif _credentials_blocked(failures_text) and not recovered_auth_error:
        task_status = "blocked_by_credentials"
    elif forbidden_tools_used or forbidden_interfaces_used or missing_tools or missing_interfaces:
        task_status = "schema_mismatch"
    elif run_status != "completed":
        task_status = "failure"
    elif missing_outputs or missing_artifacts or unsupported_artifact_reference:
        task_status = "suspect_success" if final_text else "failure"
    else:
        task_status = "success"

    passed_conditions = [
        condition for condition in spec["success_conditions"]
        if not (
            ("story title" in condition and any(item in missing_outputs for item in ("10_story_titles", "5_items")))
            or ("link" in condition and any(item in missing_outputs for item in ("10_links", "links")))
            or ("artifact" in condition and missing_artifacts)
            or ("tooling" in condition and (missing_tools or forbidden_tools_used or missing_interfaces or forbidden_interfaces_used))
            or ("interface" in condition and (missing_interfaces or forbidden_interfaces_used))
            or ("page title" in condition and "page_title" in missing_outputs)
        )
    ]
    failure_labels = _failure_labels(
        task_status=task_status,
        run_status=run_status,
        missing_tools=missing_tools,
        missing_interfaces=missing_interfaces,
        forbidden_tools_used=forbidden_tools_used,
        forbidden_interfaces_used=forbidden_interfaces_used,
        missing_outputs=missing_outputs,
        missing_artifacts=missing_artifacts,
        final_text=final_text,
    )
    if recovered_auth_error:
        failure_labels.append("initial_auth_error_recovered")
    if unsupported_artifact_reference and "missing_required_output" not in failure_labels:
        failure_labels.append("missing_required_output")
    failure_source = _failure_source(failures_text, interface_validation)

    return {
        "run_status": run_status,
        "task_status": task_status,
        "task_spec": spec,
        "tools_used": tools_used,
        **interface_validation,
        "missing_tools": missing_tools,
        "missing_interfaces": missing_interfaces,
        "forbidden_tools_used": forbidden_tools_used,
        "forbidden_interfaces_used": forbidden_interfaces_used,
        "missing_outputs": missing_outputs,
        "missing_artifacts": missing_artifacts,
        "normalized_outputs": structured_final if isinstance(structured_final, dict) else None,
        "failure_labels": failure_labels,
        "failure_source": failure_source,
        "passed_conditions": passed_conditions,
        "failed_conditions": [
            condition for condition in spec["success_conditions"] if condition not in passed_conditions
        ],
    }
