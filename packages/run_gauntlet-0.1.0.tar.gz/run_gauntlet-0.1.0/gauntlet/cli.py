from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from gauntlet.layer1.llms_docs import load_environment
from gauntlet import run_orchestrator as orchestrator
from gauntlet.layer2.personas import PERSONAS, get_persona
from gauntlet.providers import available_providers


PERSONA_TARGET_CHOICES = orchestrator.PERSONA_TARGET_CHOICES
BATCH_PROMPT_SEPARATOR = orchestrator.BATCH_PROMPT_SEPARATOR


def load_dotenv() -> None:
    load_environment()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="gauntlet", description="Multi-provider agent CLI.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    chat_parser = subparsers.add_parser("chat", help="Send one prompt and print one reply.")
    chat_parser.add_argument(
        "--provider",
        "-p",
        required=True,
        choices=available_providers(),
        type=str.lower,
        help="Agent provider to use.",
    )
    chat_parser.add_argument(
        "--model",
        "-m",
        help="Model name. Defaults per provider if omitted.",
    )
    chat_parser.add_argument(
        "--persona",
        action="append",
        choices=PERSONA_TARGET_CHOICES,
        type=str.lower,
        help="Optional persona to shape behavior. Repeatable. Supports 'default' and 'all'.",
    )
    chat_parser.add_argument(
        "--docs",
        help="Explicit source for llms.txt. Accepts a local path or URL.",
    )
    chat_parser.add_argument(
        "--docs-full",
        help="Explicit source for llms-full.txt. Accepts a local path or URL.",
    )
    chat_parser.add_argument(
        "--max-steps",
        type=int,
        default=8,
        help="Maximum number of tool-use steps per attempt. Defaults to 8.",
    )
    chat_parser.add_argument(
        "--max-restarts",
        type=int,
        default=3,
        help="Restart from the latest checkpoint after max steps, up to this many times. Defaults to 3.",
    )
    chat_parser.add_argument(
        "--max-runtime-seconds",
        type=float,
        help="Optional wall-clock runtime budget per run.",
    )
    chat_parser.add_argument(
        "--max-model-calls",
        type=int,
        help="Optional provider-call budget per run.",
    )
    chat_parser.add_argument(
        "--max-estimated-cost-usd",
        type=float,
        help="Optional estimated-cost budget. Requires cost rate flags to be meaningful.",
    )
    chat_parser.add_argument(
        "--cost-per-1k-prompt-chars",
        type=float,
        help="Optional prompt cost rate used for character-based cost estimates.",
    )
    chat_parser.add_argument(
        "--cost-per-1k-response-chars",
        type=float,
        help="Optional response cost rate used for character-based cost estimates.",
    )
    chat_parser.add_argument(
        "--resume-run",
        help="Resume a Layer 2 run record from its latest checkpoint.",
    )
    chat_parser.add_argument(
        "--debug",
        action="store_true",
        help="Print lightweight step-by-step agent logs to stderr.",
    )
    chat_parser.add_argument(
        "--run-record",
        help="Optional output directory override. If omitted, Gauntlet creates artifacts/gauntlet_runs/gauntlet_<n>/ automatically.",
    )
    chat_parser.add_argument(
        "--batch",
        help=f"Optional path to a text file containing prompts separated by a line with exactly {BATCH_PROMPT_SEPARATOR!r}. Prompts may span multiple lines.",
    )
    chat_parser.add_argument("--judge-provider", help="Optional provider for the Layer 3 reasoning judge.")
    chat_parser.add_argument("--judge-model", help="Optional model for the Layer 3 reasoning judge.")
    chat_parser.add_argument(
        "--judge-max-doc-chunks",
        type=int,
        default=3,
        help="Maximum number of retrieved docs chunks to provide to the Layer 3 judge.",
    )
    chat_parser.add_argument(
        "--judge-disable-batch-context",
        action="store_true",
        help="Disable batch-context input when producing the Layer 3 report.",
    )
    chat_parser.add_argument(
        "--judge-fallback-deterministic",
        action="store_true",
        help="Fall back to the deterministic Layer 3 judge if the configured judge provider fails.",
    )
    chat_parser.add_argument(
        "--validation-mode",
        choices=("real-agent", "diagnostic"),
        default="real-agent",
        help="Preflight validation behavior. real-agent records/warns without revealing the path; diagnostic rejects invalid plans.",
    )
    chat_parser.add_argument(
        "prompt",
        nargs="?",
        help="Prompt to send. If omitted, the CLI will ask for it interactively.",
    )

    personas_parser = subparsers.add_parser("personas", help="List the built-in personas.")
    personas_parser.add_argument(
        "persona",
        nargs="?",
        help="Optional persona key to show detailed behavior contract.",
    )

    replay_parser = subparsers.add_parser("replay", help="Print a replay-friendly summary of a Layer 2 run record.")
    replay_parser.add_argument("run_record", help="Path to a Layer 2 run record JSON file.")
    replay_parser.add_argument(
        "--show-payloads",
        action="store_true",
        help="Print compact tool results and parse errors in addition to the step outline.",
    )

    server_parser = subparsers.add_parser("server", help="Run the Gauntlet FastAPI backend.")
    server_parser.add_argument("--host", default="127.0.0.1", help="Host to bind. Defaults to 127.0.0.1.")
    server_parser.add_argument("--port", type=int, default=8000, help="Port to bind. Defaults to 8000.")
    server_parser.add_argument("--reload", action="store_true", help="Enable uvicorn reload for local development.")
    return parser


def run_chat(args: argparse.Namespace) -> int:
    resume_payload: dict | None = None
    if args.resume_run:
        if args.batch:
            print("Pass either --resume-run or --batch, not both.", file=sys.stderr)
            return 2
        try:
            resume_payload = json.loads(Path(args.resume_run).expanduser().read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"Could not load resume run record: {exc}", file=sys.stderr)
            return 2

    if args.batch and args.prompt is not None:
        print("Pass either a positional prompt or --batch, not both.", file=sys.stderr)
        return 2
    if args.batch:
        try:
            prompt_entries = orchestrator.load_batch_prompt_entries(args.batch)
        except (OSError, ValueError) as exc:
            print(f"Could not load batch prompts: {exc}", file=sys.stderr)
            return 2
    elif resume_payload is not None and args.prompt is None:
        prompt_text = str(resume_payload.get("task") or "").strip()
        if not prompt_text:
            print("Resume run record does not contain a task. Pass a positional prompt.", file=sys.stderr)
            return 2
        prompt_entries = [orchestrator.PromptEntry(prompt_id=str(resume_payload.get("prompt_id") or "1"), prompt_text=prompt_text)]
    else:
        final_prompt = args.prompt if args.prompt is not None else input("Prompt: ")
        if not final_prompt.strip():
            print("Prompt cannot be empty.", file=sys.stderr)
            return 2
        prompt_entries = [orchestrator.PromptEntry(prompt_id="1", prompt_text=final_prompt.strip())]

    if resume_payload is not None and not args.persona:
        persona = str(resume_payload.get("persona") or "default")
        persona_targets = [persona]
    else:
        persona_targets = orchestrator.resolve_persona_targets(args.persona)

    result = orchestrator.run_gauntlet_batch(
        orchestrator.GauntletRunOptions(
            provider=args.provider,
            model=args.model or (str(resume_payload.get("model")) if resume_payload and resume_payload.get("model") else None),
            persona_targets=tuple(persona_targets),
            prompt_entries=tuple(prompt_entries),
            docs=args.docs or (resume_payload.get("llms_source") if resume_payload else None),
            docs_full=args.docs_full or (resume_payload.get("llms_full_source") if resume_payload else None),
            max_steps=args.max_steps,
            max_restarts=args.max_restarts,
            max_runtime_seconds=args.max_runtime_seconds,
            max_model_calls=args.max_model_calls,
            max_estimated_cost_usd=args.max_estimated_cost_usd,
            cost_per_1k_prompt_chars=args.cost_per_1k_prompt_chars,
            cost_per_1k_response_chars=args.cost_per_1k_response_chars,
            validation_mode=args.validation_mode,
            debug=args.debug,
            run_record_dir=args.run_record,
            resume_run_record=args.resume_run,
            judge_provider=args.judge_provider,
            judge_model=args.judge_model,
            judge_max_doc_chunks=args.judge_max_doc_chunks,
            judge_disable_batch_context=args.judge_disable_batch_context,
            judge_fallback_deterministic=args.judge_fallback_deterministic,
        ),
        progress=lambda message: print(message, file=sys.stderr, flush=True),
    )

    multiple_runs = len(result.persona_results) > 1
    for index, persona_result in enumerate(result.persona_results):
        if persona_result.error is not None:
            if multiple_runs:
                if index:
                    print()
                print(f"=== prompt {persona_result.prompt_id} / {persona_result.persona} ===")
            print(f"{persona_result.prompt_id}_{persona_result.persona}: {persona_result.error}", file=sys.stderr)
            continue

        if multiple_runs:
            if index:
                print()
            print(f"=== prompt {persona_result.prompt_id} / {persona_result.persona} ===")
        print(persona_result.response)

    if result.run_record_paths:
        print(f"\n[gauntlet] batch folder: {result.batch_dir}", file=sys.stderr)
        print(f"[gauntlet] layer2 records: {len(result.run_record_paths)}", file=sys.stderr)
        print(f"[gauntlet] layer3 json: {result.summary_json}", file=sys.stderr)
        print(f"[gauntlet] layer3 html: {result.summary_html}", file=sys.stderr)

    return 1 if result.had_failure else 0


def run_replay(args: argparse.Namespace) -> int:
    try:
        payload = json.loads(Path(args.run_record).expanduser().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"Could not load run record: {exc}", file=sys.stderr)
        return 2

    runtime = payload.get("runtime") or {}
    usage = runtime.get("usage") or {}
    print(f"status: {payload.get('status')}")
    print(f"task: {payload.get('task')}")
    print(f"provider/model: {payload.get('provider')}/{payload.get('model')}")
    print(f"persona: {payload.get('persona')}")
    print(f"steps: {len(payload.get('steps') or [])}")
    print(f"restarts: {runtime.get('restart_count', 0)}/{runtime.get('max_restarts', payload.get('max_restarts', 0))}")
    print(
        "usage: "
        f"model_calls={usage.get('model_calls', 0)} "
        f"tool_calls={usage.get('tool_calls', 0)} "
        f"prompt_chars={usage.get('prompt_chars', 0)} "
        f"response_chars={usage.get('response_chars', 0)} "
        f"estimated_cost_usd={usage.get('estimated_cost_usd')}"
    )
    failure = payload.get("failure")
    if failure:
        print(f"failure: {failure.get('type')} {failure.get('error') or failure.get('budget') or ''}".rstrip())

    for step in payload.get("steps") or []:
        tool = step.get("tool") or {}
        result = step.get("tool_result") or {}
        response = step.get("response") or {}
        if tool:
            ok = result.get("ok")
            status = "ok" if ok is True else "failed" if ok is False else "unknown"
            print(f"{step.get('step')}. attempt={step.get('attempt', 1)} tool={tool.get('name')} status={status}")
            if args.show_payloads:
                print(json.dumps({"arguments": tool.get("arguments"), "result": result}, ensure_ascii=True, indent=2))
        elif response.get("type") == "final":
            print(f"{step.get('step')}. attempt={step.get('attempt', 1)} final")
            if args.show_payloads:
                print(str(response.get("response") or ""))
        elif step.get("parse_error"):
            print(f"{step.get('step')}. attempt={step.get('attempt', 1)} parse_error")
            if args.show_payloads:
                print(json.dumps(step.get("parse_error"), ensure_ascii=True, indent=2))
    return 0


def run_server(args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError:
        print("Install server dependencies with `pip install -e '.[server]'`.", file=sys.stderr)
        return 2

    uvicorn.run(
        "gauntlet.server.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )
    return 0


def cli_main() -> int:
    load_dotenv()
    parser = build_parser()
    args = parser.parse_args()
    if args.command == "chat":
        return run_chat(args)
    if args.command == "replay":
        return run_replay(args)
    if args.command == "server":
        return run_server(args)
    if args.command == "personas":
        if getattr(args, "persona", None):
            persona = get_persona(args.persona)
            print(f"{persona.key}: {persona.name}")
            print(f"Behavior: {persona.behavior}")
            print(f"Stress-tests: {persona.stress_test_focus}")
            print(f"Identity: {persona.identity}")
            print(f"Ambiguity handling: {persona.ambiguity_handling}")
            print(f"Error behavior: {persona.error_behavior}")
            print(f"Input behavior: {persona.input_behavior}")
            print(f"Execution pacing: {persona.execution_pacing}")
            print(f"Communication style: {persona.communication_style}")
            print("Default priorities:")
            for item in persona.default_priorities:
                print(f"- {item}")
            print("Action biases:")
            for item in persona.action_biases:
                print(f"- {item}")
            print("Anti-goals:")
            for item in persona.anti_goals:
                print(f"- {item}")
            return 0
        for persona in PERSONAS.values():
            print(f"{persona.key}: {persona.behavior} Stress-tests: {persona.stress_test_focus}")
        return 0
    return 0


def app() -> None:
    raise SystemExit(cli_main())


if __name__ == "__main__":
    app()
