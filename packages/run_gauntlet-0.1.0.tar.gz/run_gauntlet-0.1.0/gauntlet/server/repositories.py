from __future__ import annotations

from datetime import datetime
from typing import Any

from gauntlet.server.config import ServerSettings
from gauntlet.server.db import get_connection


def jsonb(value: Any) -> Any:
    from psycopg.types.json import Jsonb

    return Jsonb(value)


def vector_literal(vector: list[float]) -> str:
    return "[" + ",".join(f"{float(item):.8g}" for item in vector) + "]"


class PostgresRepository:
    def __init__(self, settings: ServerSettings) -> None:
        self.settings = settings
        self.conn = get_connection(settings)

    def commit(self) -> None:
        self.conn.commit()


class RunRepository(PostgresRepository):
    def ensure_schema(self) -> None:
        with self.conn.cursor() as cur:
            cur.execute("create extension if not exists vector")
            cur.execute(
                """
                create table if not exists gauntlet_batches (
                    id text primary key,
                    source jsonb not null default '{}'::jsonb,
                    summary jsonb not null,
                    created_at timestamptz not null default now(),
                    updated_at timestamptz not null default now()
                )
                """
            )
            cur.execute("create index if not exists gauntlet_batches_created_at_idx on gauntlet_batches(created_at)")
            cur.execute("create index if not exists gauntlet_batches_summary_gin_idx on gauntlet_batches using gin(summary)")
        self.commit()

    def upsert_batch(
        self,
        *,
        batch_id: str,
        source: dict[str, Any],
        summary: dict[str, Any],
        created_at: datetime,
        updated_at: datetime,
    ) -> None:
        with self.conn.cursor() as cur:
            cur.execute(
                """
                insert into gauntlet_batches (id, source, summary, created_at, updated_at)
                values (%s, %s, %s, %s, %s)
                on conflict (id) do update set
                    source = excluded.source,
                    summary = excluded.summary,
                    updated_at = excluded.updated_at
                """,
                (batch_id, jsonb(source), jsonb(summary), created_at, updated_at),
            )

    def list_batches(self, *, ascending: bool, limit: int) -> list[dict[str, Any]]:
        direction = "asc" if ascending else "desc"
        with self.conn.cursor() as cur:
            cur.execute(
                f"select id, source, summary, created_at, updated_at from gauntlet_batches order by created_at {direction} limit %s",
                (max(1, min(limit, 200)),),
            )
            return list(cur.fetchall())

    def get_batch(self, batch_id: str) -> dict[str, Any] | None:
        with self.conn.cursor() as cur:
            cur.execute(
                "select id, source, summary, created_at, updated_at from gauntlet_batches where id = %s",
                (batch_id,),
            )
            return cur.fetchone()


class DocumentRepository(PostgresRepository):
    def ensure_schema(self) -> None:
        with self.conn.cursor() as cur:
            cur.execute("create extension if not exists vector")
            cur.execute(
                """
                create table if not exists document_sources (
                    id text primary key,
                    project_id text not null,
                    source_type text,
                    source_url text,
                    title text,
                    content_hash text,
                    metadata jsonb not null default '{}'::jsonb,
                    created_at timestamptz not null default now(),
                    updated_at timestamptz not null default now()
                )
                """
            )
            cur.execute(
                """
                create table if not exists document_chunks (
                    id text primary key,
                    project_id text not null,
                    document_source_id text not null references document_sources(id) on delete cascade,
                    chunk_id text not null,
                    path_text text,
                    title text,
                    text text,
                    context text,
                    preview text,
                    start_char integer,
                    end_char integer,
                    line_start integer,
                    line_end integer,
                    content_hash text not null,
                    embedding_model text not null,
                    embedding_dimension integer not null,
                    embedding vector,
                    embedding_created_at timestamptz not null default now(),
                    created_at timestamptz not null default now(),
                    updated_at timestamptz not null default now()
                )
                """
            )
            cur.execute("create index if not exists document_sources_project_idx on document_sources(project_id)")
            cur.execute("create index if not exists document_chunks_project_idx on document_chunks(project_id)")
            cur.execute("create index if not exists document_chunks_source_idx on document_chunks(document_source_id)")
        self.commit()

    def upsert_source(self, *, source_id: str, project_id: str, document_source: dict[str, Any]) -> None:
        with self.conn.cursor() as cur:
            cur.execute(
                """
                insert into document_sources (
                    id, project_id, source_type, source_url, title, content_hash, metadata, created_at, updated_at
                )
                values (%s, %s, %s, %s, %s, %s, %s, now(), now())
                on conflict (id) do update set
                    project_id = excluded.project_id,
                    source_type = excluded.source_type,
                    source_url = excluded.source_url,
                    title = excluded.title,
                    content_hash = excluded.content_hash,
                    metadata = excluded.metadata,
                    updated_at = now()
                """,
                (
                    source_id,
                    project_id,
                    document_source.get("source_type"),
                    document_source.get("source_url"),
                    document_source.get("title"),
                    document_source.get("content_hash"),
                    jsonb(document_source),
                ),
            )

    def get_chunk_fingerprint(self, chunk_id: str) -> dict[str, Any] | None:
        with self.conn.cursor() as cur:
            cur.execute("select content_hash, embedding_model from document_chunks where id = %s", (chunk_id,))
            return cur.fetchone()

    def upsert_chunk(self, record: dict[str, Any]) -> None:
        with self.conn.cursor() as cur:
            cur.execute(
                """
                insert into document_chunks (
                    id, project_id, document_source_id, chunk_id, path_text, title, text, context, preview,
                    start_char, end_char, line_start, line_end, content_hash, embedding_model,
                    embedding_dimension, embedding, embedding_created_at, updated_at
                )
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::vector, %s, now())
                on conflict (id) do update set
                    path_text = excluded.path_text,
                    title = excluded.title,
                    text = excluded.text,
                    context = excluded.context,
                    preview = excluded.preview,
                    start_char = excluded.start_char,
                    end_char = excluded.end_char,
                    line_start = excluded.line_start,
                    line_end = excluded.line_end,
                    content_hash = excluded.content_hash,
                    embedding_model = excluded.embedding_model,
                    embedding_dimension = excluded.embedding_dimension,
                    embedding = excluded.embedding,
                    embedding_created_at = excluded.embedding_created_at,
                    updated_at = now()
                """,
                (
                    record["_id"],
                    record["project_id"],
                    record["document_source_id"],
                    record["chunk_id"],
                    record.get("path_text"),
                    record.get("title"),
                    record.get("text"),
                    record.get("context"),
                    record.get("preview"),
                    record.get("start_char"),
                    record.get("end_char"),
                    record.get("line_start"),
                    record.get("line_end"),
                    record["content_hash"],
                    record["embedding_model"],
                    record["embedding_dimension"],
                    vector_literal(record["embedding"]),
                    record["embedding_created_at"],
                ),
            )
