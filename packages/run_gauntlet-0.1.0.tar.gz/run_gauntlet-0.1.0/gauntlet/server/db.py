from __future__ import annotations

from typing import Any

from gauntlet.server.config import ServerSettings


class DatabaseUnavailable(RuntimeError):
    pass


def get_connection(settings: ServerSettings) -> Any:
    if not settings.database_url:
        raise DatabaseUnavailable("Set GAUNTLET_DATABASE_URL, SUPABASE_DB_URL, or DATABASE_URL.")

    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError as exc:  # pragma: no cover - depends on optional extras
        raise DatabaseUnavailable("Install server dependencies with `pip install -e '.[server]'`.") from exc

    try:
        conn = psycopg.connect(settings.database_url, row_factory=dict_row, connect_timeout=5)
        with conn.cursor() as cur:
            cur.execute("select 1")
        return conn
    except Exception as exc:  # noqa: BLE001 - normalize driver/network errors
        raise DatabaseUnavailable("Could not connect to Supabase/Postgres.") from exc
