from __future__ import annotations

from typing import Annotated
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query

from gauntlet import run_orchestrator as orchestrator
from gauntlet.server.storage import RunStore


router = APIRouter(prefix="/api/runs", tags=["runs"])


def get_store() -> RunStore:
    from gauntlet.server.app import get_run_store

    return get_run_store()


@router.post("")
def create_run(payload: dict[str, Any]) -> dict[str, Any]:
    provider = str(payload.get("provider") or "").strip().lower()
    if not provider:
        raise HTTPException(status_code=400, detail="provider is required")

    raw_prompts = payload.get("prompts")
    if raw_prompts is None and payload.get("prompt") is not None:
        raw_prompts = [payload.get("prompt")]
    if not isinstance(raw_prompts, list) or not raw_prompts:
        raise HTTPException(status_code=400, detail="prompt or prompts is required")

    prompt_entries: list[orchestrator.PromptEntry] = []
    for index, item in enumerate(raw_prompts, start=1):
        if isinstance(item, dict):
            prompt_text = str(item.get("prompt_text") or item.get("prompt") or "").strip()
            prompt_id = str(item.get("prompt_id") or index)
        else:
            prompt_text = str(item or "").strip()
            prompt_id = str(index)
        if not prompt_text:
            raise HTTPException(status_code=400, detail=f"prompt {index} is empty")
        prompt_entries.append(orchestrator.PromptEntry(prompt_id=prompt_id, prompt_text=prompt_text))

    raw_personas = payload.get("personas") or payload.get("persona")
    if isinstance(raw_personas, str):
        persona_targets = orchestrator.resolve_persona_targets([raw_personas])
    elif isinstance(raw_personas, list):
        persona_targets = orchestrator.resolve_persona_targets([str(item).lower() for item in raw_personas])
    elif raw_personas is None:
        persona_targets = ["default"]
    else:
        raise HTTPException(status_code=400, detail="persona/personas must be a string or list")

    try:
        result = orchestrator.run_gauntlet_batch(
            orchestrator.GauntletRunOptions(
                provider=provider,
                model=payload.get("model"),
                persona_targets=tuple(persona_targets),
                prompt_entries=tuple(prompt_entries),
                docs=payload.get("docs"),
                docs_full=payload.get("docs_full"),
                max_steps=int(payload.get("max_steps") or 8),
                max_restarts=int(payload.get("max_restarts") or 3),
                max_runtime_seconds=payload.get("max_runtime_seconds"),
                max_model_calls=payload.get("max_model_calls"),
                max_estimated_cost_usd=payload.get("max_estimated_cost_usd"),
                cost_per_1k_prompt_chars=payload.get("cost_per_1k_prompt_chars"),
                cost_per_1k_response_chars=payload.get("cost_per_1k_response_chars"),
                validation_mode=str(payload.get("validation_mode") or "real-agent"),
                debug=bool(payload.get("debug") or False),
                run_record_dir=payload.get("run_record_dir"),
                judge_provider=payload.get("judge_provider"),
                judge_model=payload.get("judge_model"),
                judge_max_doc_chunks=int(payload.get("judge_max_doc_chunks") or 3),
                judge_disable_batch_context=bool(payload.get("judge_disable_batch_context") or False),
                judge_fallback_deterministic=bool(payload.get("judge_fallback_deterministic") or False),
            )
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "batch_dir": str(result.batch_dir),
        "run_record_paths": list(result.run_record_paths),
        "summary_json": result.summary_json,
        "summary_html": result.summary_html,
        "had_failure": result.had_failure,
        "results": [
            {
                "prompt_id": item.prompt_id,
                "persona": item.persona,
                "response": item.response,
                "run_record_path": item.run_record_path,
                "error": str(item.error) if item.error else None,
            }
            for item in result.persona_results
        ],
    }


@router.get("")
def list_runs(
    store: Annotated[RunStore, Depends(get_store)],
    q: str | None = None,
    status: str | None = None,
    persona: str | None = None,
    provider: str | None = None,
    blame_surface: str | None = None,
    sort: str = "created_at_desc",
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict:
    return {
        "runs": store.list_runs(
            q=q,
            status=status,
            persona=persona,
            provider=provider,
            blame_surface=blame_surface,
            sort=sort,
            limit=limit,
        )
    }


@router.get("/{batch_id}")
def get_run(batch_id: str, store: Annotated[RunStore, Depends(get_store)]) -> dict:
    run = store.get_run(batch_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Run batch not found")
    return run


@router.get("/{batch_id}/raw")
def get_raw_run(batch_id: str, store: Annotated[RunStore, Depends(get_store)]) -> dict:
    run = store.get_raw_run(batch_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Run batch not found")
    return run


@router.get("/{batch_id}/personas")
def get_personas(batch_id: str, store: Annotated[RunStore, Depends(get_store)]) -> dict:
    summary = store.get_run_summary(batch_id)
    if summary is None:
        raise HTTPException(status_code=404, detail="Run batch not found")
    return {"personas": summary.get("run_rows") or []}


@router.get("/{batch_id}/issues")
def get_issues(batch_id: str, store: Annotated[RunStore, Depends(get_store)]) -> dict:
    summary = store.get_run_summary(batch_id)
    if summary is None:
        raise HTTPException(status_code=404, detail="Run batch not found")
    return {"issue_groups": summary.get("issue_groups", [])}


@router.get("/{batch_id}/recommendations")
def get_recommendations(batch_id: str, store: Annotated[RunStore, Depends(get_store)]) -> dict:
    summary = store.get_run_summary(batch_id)
    if summary is None:
        raise HTTPException(status_code=404, detail="Run batch not found")
    return {"recommendations": summary.get("top_recommendations", [])}


@router.post("/ingest-artifacts")
def ingest_artifacts(store: Annotated[RunStore, Depends(get_store)]) -> dict:
    return store.ingest_artifacts()
