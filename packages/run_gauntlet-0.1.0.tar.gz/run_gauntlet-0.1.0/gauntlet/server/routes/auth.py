from __future__ import annotations

from fastapi import APIRouter


router = APIRouter(prefix="/api", tags=["auth"])


@router.get("/me")
def me() -> dict:
    return {"user": None, "authenticated": False}


@router.post("/auth/login")
def login() -> dict:
    return {"ok": False, "detail": "Authentication is not implemented yet."}


@router.post("/auth/logout")
def logout() -> dict:
    return {"ok": True}

