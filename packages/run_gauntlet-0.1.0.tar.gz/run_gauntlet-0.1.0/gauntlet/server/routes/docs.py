from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException

from gauntlet.server.storage import RunStore


router = APIRouter(prefix="/api/docs", tags=["docs"])


def get_store() -> RunStore:
    from gauntlet.server.app import get_run_store

    return get_run_store()


@router.post("/ingest")
def ingest_docs(payload: dict[str, Any], store: Annotated[RunStore, Depends(get_store)]) -> dict[str, Any]:
    project_id = str(payload.get("project_id") or "").strip()
    chunks = payload.get("chunks") or []
    if not project_id:
        raise HTTPException(status_code=400, detail="project_id is required")
    if not isinstance(chunks, list):
        raise HTTPException(status_code=400, detail="chunks must be a list")

    document_source = payload.get("document_source") or {}
    if not isinstance(document_source, dict):
        raise HTTPException(status_code=400, detail="document_source must be an object")

    try:
        return store.ingest_document_chunks(
            project_id=project_id,
            document_source=document_source,
            chunks=chunks,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

