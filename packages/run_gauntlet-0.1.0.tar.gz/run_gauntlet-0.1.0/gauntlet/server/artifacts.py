from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def find_summary_files(artifacts_dir: Path) -> list[Path]:
    if not artifacts_dir.exists():
        return []

    summary_files: list[Path] = []
    for child in sorted(artifacts_dir.iterdir()):
        if not child.is_dir():
            continue
        expected = child / f"{child.name}.json"
        if expected.exists():
            summary_files.append(expected)
    return summary_files


def load_summary(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Summary is not a JSON object: {path}")
    return payload


def summary_document(path: Path) -> dict[str, Any]:
    summary = load_summary(path)
    batch_id = str(summary.get("batch_name") or path.parent.name)
    stat = path.stat()
    return {
        "_id": batch_id,
        "batch_id": batch_id,
        "source": {
            "kind": "artifact",
            "summary_path": str(path),
            "batch_dir": str(path.parent),
        },
        "created_at": stat.st_ctime,
        "updated_at": stat.st_mtime,
        "summary": summary,
    }

