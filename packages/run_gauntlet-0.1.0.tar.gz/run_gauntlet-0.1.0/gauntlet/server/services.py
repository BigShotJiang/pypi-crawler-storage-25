from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

from gauntlet.server.artifacts import find_summary_files, summary_document
from gauntlet.server.config import ServerSettings
from gauntlet.server.embeddings import build_chunk_embedding_documents
from gauntlet.server.repositories import DocumentRepository, RunRepository


def public_run(doc: dict[str, Any]) -> dict[str, Any]:
    summary = doc.get("summary") or {}
    total_runs = int(summary.get("total_runs") or 0)
    successful_tasks = int(summary.get("successful_tasks") or 0)
    failed_tasks = int(summary.get("failed_tasks") or 0)
    success_rate = successful_tasks / total_runs if total_runs else 0
    return {
        "batch_id": doc.get("batch_id") or doc.get("id"),
        "created_at": _iso(doc.get("created_at")),
        "updated_at": _iso(doc.get("updated_at")),
        "total_runs": total_runs,
        "completed_runs": summary.get("completed_runs", 0),
        "failed_runs": summary.get("failed_runs", 0),
        "successful_tasks": successful_tasks,
        "failed_tasks": failed_tasks,
        "suspect_successes": summary.get("suspect_successes", 0),
        "success_rate": success_rate,
        "run_status_breakdown": summary.get("run_status_breakdown", {}),
        "task_status_breakdown": summary.get("task_status_breakdown", {}),
        "error_class_breakdown": summary.get("error_class_breakdown", {}),
        "blame_surface_breakdown": summary.get("blame_surface_breakdown", {}),
        "top_issue_fingerprints": summary.get("top_issue_fingerprints", []),
        "top_recommendations": summary.get("top_recommendations", []),
        "issue_groups": summary.get("issue_groups", []),
    }


def row_to_doc(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": row["id"],
        "batch_id": row["id"],
        "source": row.get("source") or {},
        "summary": row.get("summary") or {},
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
    }


def _iso(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


class RunQueryService:
    def __init__(self, repository: RunRepository) -> None:
        self.repository = repository

    def list_runs(
        self,
        *,
        q: str | None = None,
        status: str | None = None,
        persona: str | None = None,
        provider: str | None = None,
        blame_surface: str | None = None,
        sort: str = "created_at_desc",
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        rows = self.repository.list_batches(ascending=sort == "created_at_asc", limit=limit)
        docs = [row_to_doc(row) for row in rows]
        filtered = [
            doc
            for doc in docs
            if _matches_filters(
                doc,
                q=q,
                status=status,
                persona=persona,
                provider=provider,
                blame_surface=blame_surface,
            )
        ]
        return [public_run(doc) for doc in filtered]

    def get_run(self, batch_id: str) -> dict[str, Any] | None:
        doc = self.get_raw_run(batch_id)
        if not doc:
            return None
        public = public_run(doc)
        public["run_rows"] = (doc.get("summary") or {}).get("run_rows", [])
        public["run_reports"] = (doc.get("summary") or {}).get("run_reports", [])
        public["cross_agent_patterns"] = (doc.get("summary") or {}).get("cross_agent_patterns", [])
        return public

    def get_raw_run(self, batch_id: str) -> dict[str, Any] | None:
        row = self.repository.get_batch(batch_id)
        return row_to_doc(row) if row else None

    def get_run_summary(self, batch_id: str) -> dict[str, Any] | None:
        doc = self.get_raw_run(batch_id)
        if not doc:
            return None
        return doc.get("summary") or {}


class ArtifactIngestionService:
    def __init__(self, settings: ServerSettings, repository: RunRepository) -> None:
        self.settings = settings
        self.repository = repository

    def ingest_artifacts(self) -> dict[str, int]:
        inserted_or_updated = 0
        for path in find_summary_files(self.settings.artifacts_dir):
            doc = summary_document(path)
            self.repository.upsert_batch(
                batch_id=doc["batch_id"],
                source=doc["source"],
                summary=doc["summary"],
                created_at=datetime.fromtimestamp(float(doc["created_at"]), timezone.utc),
                updated_at=datetime.fromtimestamp(float(doc["updated_at"]), timezone.utc),
            )
            inserted_or_updated += 1
        self.repository.commit()
        return {"runs": inserted_or_updated}


class DocumentIngestionService:
    def __init__(self, repository: DocumentRepository) -> None:
        self.repository = repository

    def ingest_document_chunks(
        self,
        *,
        project_id: str,
        document_source: dict[str, Any],
        chunks: list[dict[str, Any]],
    ) -> dict[str, Any]:
        if not chunks:
            return {"document_source_id": document_source.get("_id"), "chunks": 0}

        source_id = str(
            document_source.get("_id")
            or document_source.get("document_source_id")
            or document_source.get("source_url")
            or "default"
        )
        now = datetime.now(timezone.utc).isoformat()
        source_doc = {
            **document_source,
            "project_id": project_id,
            "updated_at": now,
        }
        source_doc.setdefault("created_at", now)
        self.repository.upsert_source(source_id=source_id, project_id=project_id, document_source=source_doc)

        records = build_chunk_embedding_documents(
            project_id=project_id,
            document_source_id=source_id,
            chunks=chunks,
        )
        written = 0
        for record in records:
            existing = self.repository.get_chunk_fingerprint(record["_id"])
            if (
                existing
                and existing.get("content_hash") == record["content_hash"]
                and existing.get("embedding_model") == record["embedding_model"]
            ):
                continue
            self.repository.upsert_chunk(record)
            written += 1
        self.repository.commit()
        return {
            "document_source_id": source_id,
            "chunks": len(records),
            "chunks_written": written,
            "embedding_model": records[0]["embedding_model"] if records else None,
        }


def _matches_filters(
    doc: dict[str, Any],
    *,
    q: str | None,
    status: str | None,
    persona: str | None,
    provider: str | None,
    blame_surface: str | None,
) -> bool:
    summary = doc.get("summary") or {}
    rows = summary.get("run_rows") or []
    judged_runs = summary.get("judged_runs") or []
    if status and not any(row.get("task_status") == status for row in rows):
        return False
    if persona and not any(row.get("persona") == persona for row in rows):
        return False
    if provider and not any(run.get("provider") == provider for run in judged_runs):
        return False
    if blame_surface and blame_surface not in (summary.get("blame_surface_breakdown") or {}):
        return False
    if q:
        haystack = json.dumps(
            {
                "prompt_mapping": summary.get("prompt_mapping"),
                "issue_groups": summary.get("issue_groups"),
                "top_recommendations": summary.get("top_recommendations"),
            },
            ensure_ascii=True,
        ).lower()
        if q.lower() not in haystack:
            return False
    return True
