from __future__ import annotations

from typing import Any

from gauntlet.server.config import ServerSettings
from gauntlet.server.repositories import DocumentRepository, RunRepository
from gauntlet.server.services import ArtifactIngestionService, DocumentIngestionService, RunQueryService


class RunStore:
    """Compatibility facade for existing routes.

    New code should depend on the narrower services directly. This class keeps
    the current API stable while persistence and use-case logic are separated.
    """

    def __init__(self, settings: ServerSettings) -> None:
        self.settings = settings
        self.run_repository = RunRepository(settings)
        self.document_repository = DocumentRepository(settings)
        self.run_repository.ensure_schema()
        self.document_repository.ensure_schema()
        self.runs = RunQueryService(self.run_repository)
        self.artifacts = ArtifactIngestionService(settings, self.run_repository)
        self.documents = DocumentIngestionService(self.document_repository)

    def ingest_artifacts(self) -> dict[str, int]:
        return self.artifacts.ingest_artifacts()

    def list_runs(
        self,
        *,
        q: str | None = None,
        status: str | None = None,
        persona: str | None = None,
        provider: str | None = None,
        blame_surface: str | None = None,
        sort: str = "created_at_desc",
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        return self.runs.list_runs(
            q=q,
            status=status,
            persona=persona,
            provider=provider,
            blame_surface=blame_surface,
            sort=sort,
            limit=limit,
        )

    def get_run(self, batch_id: str) -> dict[str, Any] | None:
        return self.runs.get_run(batch_id)

    def get_raw_run(self, batch_id: str) -> dict[str, Any] | None:
        return self.runs.get_raw_run(batch_id)

    def get_run_summary(self, batch_id: str) -> dict[str, Any] | None:
        return self.runs.get_run_summary(batch_id)

    def ingest_document_chunks(
        self,
        *,
        project_id: str,
        document_source: dict[str, Any],
        chunks: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return self.documents.ingest_document_chunks(
            project_id=project_id,
            document_source=document_source,
            chunks=chunks,
        )
