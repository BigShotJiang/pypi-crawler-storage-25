from __future__ import annotations

from functools import lru_cache

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from gauntlet.server.config import get_settings
from gauntlet.server.db import DatabaseUnavailable
from gauntlet.server.routes import auth, docs, runs
from gauntlet.server.storage import RunStore


@lru_cache(maxsize=1)
def get_run_store() -> RunStore:
    return RunStore(get_settings())


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title="Gauntlet API", version="0.1.0")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/api/health")
    def health() -> dict:
        try:
            get_run_store()
        except DatabaseUnavailable as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        return {"ok": True, "storage": "supabase-postgres"}

    app.include_router(auth.router)
    app.include_router(docs.router)
    app.include_router(runs.router)
    return app


app = create_app()
