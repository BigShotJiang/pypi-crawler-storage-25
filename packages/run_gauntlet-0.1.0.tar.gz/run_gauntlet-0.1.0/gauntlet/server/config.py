from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ServerSettings:
    database_url: str
    artifacts_dir: Path
    cors_origins: tuple[str, ...]


def _csv_env(name: str, default: str = "") -> tuple[str, ...]:
    raw = os.getenv(name, default)
    return tuple(item.strip() for item in raw.split(",") if item.strip())


def get_settings() -> ServerSettings:
    return ServerSettings(
        database_url=os.getenv("GAUNTLET_DATABASE_URL", os.getenv("SUPABASE_DB_URL", os.getenv("DATABASE_URL", ""))),
        artifacts_dir=Path(os.getenv("GAUNTLET_ARTIFACTS_DIR", "artifacts/gauntlet_runs")).expanduser(),
        cors_origins=_csv_env("GAUNTLET_CORS_ORIGINS", "http://localhost:3000"),
    )
