from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any

from gauntlet.layer1.embeddings import active_model, embed_texts


def chunk_content_hash(text: str, context: str | None = None) -> str:
    h = hashlib.sha256()
    h.update((context or "").encode("utf-8", errors="replace"))
    h.update(b"\x00")
    h.update(text.encode("utf-8", errors="replace"))
    return h.hexdigest()


def build_chunk_embedding_documents(
    *,
    project_id: str,
    document_source_id: str,
    chunks: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    model = active_model()
    if model is None:
        raise RuntimeError("No embedding provider key found (OPENAI_API_KEY or GEMINI_API_KEY)")

    texts: list[str] = []
    fingerprints: list[str] = []
    for chunk in chunks:
        text = str(chunk.get("text") or "")
        context = str(chunk.get("context") or "")
        fingerprints.append(chunk_content_hash(text, context))
        texts.append(f"{context}\n\n{text}".strip() or " ")

    vectors = embed_texts(texts)
    now = datetime.now(timezone.utc).isoformat()
    records: list[dict[str, Any]] = []
    for index, chunk in enumerate(chunks):
        vector = vectors[index].astype(float).tolist()
        chunk_id = str(chunk.get("chunk_id") or f"chunk-{index}")
        records.append(
            {
                "_id": f"{project_id}:{document_source_id}:{chunk_id}:{model}",
                "project_id": project_id,
                "document_source_id": document_source_id,
                "chunk_id": chunk_id,
                "path_text": chunk.get("path_text"),
                "title": chunk.get("title"),
                "text": chunk.get("text"),
                "context": chunk.get("context"),
                "preview": chunk.get("preview"),
                "start_char": chunk.get("start_char"),
                "end_char": chunk.get("end_char"),
                "line_start": chunk.get("line_start"),
                "line_end": chunk.get("line_end"),
                "content_hash": fingerprints[index],
                "embedding_model": model,
                "embedding_dimension": len(vector),
                "embedding": vector,
                "embedding_created_at": now,
            }
        )
    return records

