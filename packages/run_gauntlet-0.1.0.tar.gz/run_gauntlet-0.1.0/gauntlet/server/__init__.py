"""FastAPI backend for Gauntlet."""

