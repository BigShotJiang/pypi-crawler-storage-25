from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Callable

from gauntlet.layer2.agent_runner import AgentRunConfig, run_agent_task
from gauntlet.layer2.personas import available_personas, get_persona
from gauntlet.layer3.cli import analyze_run_paths
from gauntlet.providers import ProviderConfig, default_model_for


BATCH_PROMPT_SEPARATOR = "==="
PERSONA_TARGET_CHOICES = ("default", "all", *available_personas())


@dataclass(frozen=True)
class PromptEntry:
    prompt_id: str
    prompt_text: str


@dataclass(frozen=True)
class GauntletRunOptions:
    provider: str
    model: str | None = None
    persona_targets: tuple[str, ...] = ("default",)
    prompt_entries: tuple[PromptEntry, ...] = ()
    docs: str | None = None
    docs_full: str | None = None
    max_steps: int = 8
    max_restarts: int = 3
    max_runtime_seconds: float | None = None
    max_model_calls: int | None = None
    max_estimated_cost_usd: float | None = None
    cost_per_1k_prompt_chars: float | None = None
    cost_per_1k_response_chars: float | None = None
    validation_mode: str = "real_agent"
    debug: bool = False
    run_record_dir: str | None = None
    resume_run_record: str | None = None
    judge_provider: str | None = None
    judge_model: str | None = None
    judge_max_doc_chunks: int = 3
    judge_disable_batch_context: bool = False
    judge_fallback_deterministic: bool = False


@dataclass(frozen=True)
class PersonaRunResult:
    prompt_id: str
    persona: str
    response: str | None
    run_record_path: str | None
    error: Exception | None = None


@dataclass(frozen=True)
class GauntletRunResult:
    batch_dir: Path
    run_record_paths: tuple[str, ...]
    persona_results: tuple[PersonaRunResult, ...]
    summary_json: str | None
    summary_html: str | None

    @property
    def had_failure(self) -> bool:
        return any(result.error is not None for result in self.persona_results)


def resolve_persona_targets(selected: Iterable[str] | None) -> list[str]:
    if not selected:
        return ["default"]

    resolved: list[str] = []
    for item in selected:
        if item == "all":
            resolved.extend(available_personas())
            continue
        resolved.append(item)

    deduped: list[str] = []
    seen: set[str] = set()
    for item in resolved:
        if item in seen:
            continue
        seen.add(item)
        deduped.append(item)
    return deduped


def label_for_target(target: str) -> str:
    if target == "default":
        return "default"
    return get_persona(target).key


def batch_prompt_entries_from_text(text: str) -> list[PromptEntry]:
    normalized_text = text.replace("\r\n", "\n").replace("\r", "\n")
    prompts: list[PromptEntry] = []
    chunks = normalized_text.split(f"\n{BATCH_PROMPT_SEPARATOR}\n")
    if normalized_text.startswith(f"{BATCH_PROMPT_SEPARATOR}\n") or normalized_text.endswith(f"\n{BATCH_PROMPT_SEPARATOR}"):
        raise ValueError(f"Batch prompt file cannot start or end with {BATCH_PROMPT_SEPARATOR!r}.")
    for index, chunk in enumerate(chunks, start=1):
        prompt_text = chunk.strip()
        if not prompt_text:
            raise ValueError(f"Batch prompt {index} is empty.")
        prompts.append(PromptEntry(prompt_id=str(index), prompt_text=prompt_text))
    return prompts


def load_batch_prompt_entries(path: str) -> list[PromptEntry]:
    batch_path = Path(path).expanduser()
    text = batch_path.read_text(encoding="utf-8")
    return batch_prompt_entries_from_text(text)


def create_batch_directory(base_dir: str = "artifacts/gauntlet_runs") -> Path:
    root = Path(base_dir).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    existing_numbers = []
    for child in root.iterdir():
        if not child.is_dir():
            continue
        name = child.name
        if not name.startswith("gauntlet_"):
            continue
        suffix = name.split("gauntlet_", 1)[1]
        if suffix.isdigit():
            existing_numbers.append(int(suffix))
    next_number = max(existing_numbers, default=0) + 1
    batch_dir = root / f"gauntlet_{next_number:03d}"
    batch_dir.mkdir(parents=True, exist_ok=False)
    return batch_dir


def run_record_path_for_target(
    base_path: str | None,
    target: str,
    multiple_personas: bool,
    *,
    prompt_id: str | None = None,
) -> str | None:
    if not base_path:
        return None
    if not multiple_personas and prompt_id is None:
        return base_path

    path = Path(base_path).expanduser()
    suffix = path.suffix
    stem = path.stem if suffix else path.name
    name_parts: list[str] = []
    if prompt_id is not None:
        name_parts.append(_sanitize_filename_part(prompt_id))
    if multiple_personas:
        name_parts.append(_sanitize_filename_part(label_for_target(target)))
    target_label = "_".join(name_parts) if name_parts else _sanitize_filename_part(label_for_target(target))
    if suffix:
        return str(path.with_name(f"{stem}_{target_label}{suffix}"))
    return str(path.with_name(f"{stem}_{target_label}"))


def run_gauntlet_batch(
    options: GauntletRunOptions,
    *,
    progress: Callable[[str], None] | None = None,
) -> GauntletRunResult:
    if not options.prompt_entries:
        raise ValueError("At least one prompt entry is required.")

    provider = ProviderConfig(
        name=options.provider,
        model=options.model or default_model_for(options.provider),
    )
    if options.resume_run_record and options.run_record_dir:
        batch_dir = Path(options.run_record_dir).expanduser()
    elif options.resume_run_record:
        batch_dir = Path(options.resume_run_record).expanduser().parent
    else:
        batch_dir = Path(options.run_record_dir).expanduser() if options.run_record_dir else create_batch_directory()
    batch_dir.mkdir(parents=True, exist_ok=True)

    layer2_record_base = batch_dir / "layer2_run.json"
    multiple_prompts = len(options.prompt_entries) > 1
    multiple_personas = len(options.persona_targets) > 1
    total_runs = len(options.prompt_entries) * len(options.persona_targets)
    run_record_paths: list[str] = []
    persona_results: list[PersonaRunResult] = []

    for prompt_index, prompt_entry in enumerate(options.prompt_entries):
        for persona_index, target in enumerate(options.persona_targets):
            current_run = prompt_index * len(options.persona_targets) + persona_index + 1
            if total_runs > 1 and progress:
                progress(f"[gauntlet] running {current_run}/{total_runs}: prompt {prompt_entry.prompt_id} persona {label_for_target(target)}")

            run_record_path = run_record_path_for_target(
                str(layer2_record_base),
                target,
                multiple_personas,
                prompt_id=prompt_entry.prompt_id if multiple_prompts else None,
            )
            if options.resume_run_record and not options.run_record_dir:
                run_record_path = options.resume_run_record
            if run_record_path:
                run_record_paths.append(run_record_path)

            try:
                response = run_agent_task(
                    AgentRunConfig(
                        provider=provider,
                        task=prompt_entry.prompt_text,
                        persona=None if target == "default" else target,
                        llms_source=options.docs,
                        llms_full_source=options.docs_full,
                        max_steps=options.max_steps,
                        max_restarts=options.max_restarts,
                        max_runtime_seconds=options.max_runtime_seconds,
                        max_model_calls=options.max_model_calls,
                        max_estimated_cost_usd=options.max_estimated_cost_usd,
                        cost_per_1k_prompt_chars=options.cost_per_1k_prompt_chars,
                        cost_per_1k_response_chars=options.cost_per_1k_response_chars,
                        validation_mode=options.validation_mode.replace("-", "_"),
                        debug=options.debug,
                        run_record_path=run_record_path,
                        resume_from_run_record=options.resume_run_record,
                        prompt_id=prompt_entry.prompt_id,
                        batch_prompt_count=len(options.prompt_entries),
                    )
                )
                persona_results.append(
                    PersonaRunResult(
                        prompt_id=prompt_entry.prompt_id,
                        persona=label_for_target(target),
                        response=response,
                        run_record_path=run_record_path,
                    )
                )
            except Exception as exc:
                persona_results.append(
                    PersonaRunResult(
                        prompt_id=prompt_entry.prompt_id,
                        persona=label_for_target(target),
                        response=None,
                        run_record_path=run_record_path,
                        error=exc,
                    )
                )

    existing_run_records = [path for path in run_record_paths if Path(path).exists()]
    summary_json: str | None = None
    summary_html: str | None = None
    if existing_run_records:
        summary_json, summary_html = analyze_run_paths(
            existing_run_records,
            output_dir=str(batch_dir),
            name=batch_dir.name,
            judge_provider=options.judge_provider,
            judge_model=options.judge_model,
            judge_max_doc_chunks=options.judge_max_doc_chunks,
            judge_disable_batch_context=options.judge_disable_batch_context,
            judge_fallback_deterministic=options.judge_fallback_deterministic
            or not (options.judge_provider and options.judge_model),
        )

    return GauntletRunResult(
        batch_dir=batch_dir,
        run_record_paths=tuple(existing_run_records),
        persona_results=tuple(persona_results),
        summary_json=summary_json,
        summary_html=summary_html,
    )


def _sanitize_filename_part(value: str) -> str:
    sanitized = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
    return sanitized or "run"
