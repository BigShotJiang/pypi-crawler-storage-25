"""Slim the inline llms.txt the agent sees at step 0.

The full llms.txt is ~21KB. Most of that mass is two things:
  1. An "Agent Instructions" cheat sheet of fenced code blocks. Inlining
     it pushes the agent toward "guess from the snippet" instead of
     "ground via ground_docs" for anything not literally on the page.
  2. A bullet-link manifest of every doc page. That manifest is already
     re-derived from llms-full.txt by `read_docs` and concatenated as
     `llms_manifest_text`, so it's in the prompt twice today.

The trim is signal-based rather than name-based so it survives the
upstream docs being renamed:

  * Walk the file by `##`/`###`/`####` sections.
  * Always keep the prelude (everything before the first `##`).
  * Drop a section when its body is mostly fenced code (>=25%) — that's
    the cheat-sheet shape.
  * Drop a section when it's mostly link-bullets (>=60% of >10 bullets
    are `- [Title](http...)` lines) — that's the manifest shape.
  * Append a single line telling the agent to call `ground_docs` for
    anything beyond the prelude.

Gated by GAUNTLET_SLIM_LLMS=1 at the call site so it can be A/B tested.
"""
from __future__ import annotations

import hashlib
import os
import re


_FENCE_RE = re.compile(r"```")
_HEADING_RE = re.compile(r"^(#{2,6})\s+(.+?)\s*$")
_TOP_HEADING_RE = re.compile(r"^##\s+(.+?)\s*$")
_LINK_BULLET_RE = re.compile(r"^\s*-\s*\[[^\]]+\]\(https?://", re.MULTILINE)
_BULLET_RE = re.compile(r"^\s*-\s+", re.MULTILINE)

_CODE_FENCE_DENSITY_DROP = 0.25
_LINK_BULLET_DENSITY_DROP = 0.60
_MIN_BULLETS_FOR_MANIFEST = 10

_FALLBACK_FOOTER = "For specifics beyond the Quick Reference, call `ground_docs`."

_cache: dict[str, str] = {}


def _fence_density(body: str) -> float:
    if not body:
        return 0.0
    fence_chars = 0
    inside = False
    last = 0
    for match in _FENCE_RE.finditer(body):
        if not inside:
            last = match.start()
            inside = True
        else:
            fence_chars += match.end() - last
            inside = False
    if inside:
        fence_chars += len(body) - last
    return fence_chars / len(body)


def _link_bullet_density(body: str) -> tuple[float, int]:
    bullets = _BULLET_RE.findall(body)
    if not bullets:
        return 0.0, 0
    link_bullets = _LINK_BULLET_RE.findall(body)
    return len(link_bullets) / len(bullets), len(bullets)


def _split_into_sections(text: str) -> list[tuple[str | None, str]]:
    """Returns [(heading_line_or_None, body), ...] grouped by `##` heading.

    The first tuple's heading is None and holds the prelude. Each later tuple
    spans one `##` heading plus everything beneath it (including `###`/`####`
    subsections) until the next `##` heading. We group at `##` so a parent
    that's mostly manifest in its subsections is dropped wholesale.
    """
    lines = text.splitlines(keepends=True)
    sections: list[tuple[str | None, list[str]]] = [(None, [])]
    for line in lines:
        if _TOP_HEADING_RE.match(line):
            sections.append((line.rstrip("\n"), []))
        else:
            sections[-1][1].append(line)
    return [(heading, "".join(body_lines)) for heading, body_lines in sections]


def _should_drop(body: str) -> bool:
    if _fence_density(body) >= _CODE_FENCE_DENSITY_DROP:
        return True
    density, bullet_count = _link_bullet_density(body)
    if bullet_count > _MIN_BULLETS_FOR_MANIFEST and density >= _LINK_BULLET_DENSITY_DROP:
        return True
    return False


def slim_llms_text(raw: str) -> str:
    """Return the slim form of an llms.txt blob. Pure function, cached."""
    if not raw:
        return raw
    key = hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()
    cached = _cache.get(key)
    if cached is not None:
        return cached

    sections = _split_into_sections(raw)
    kept: list[str] = []
    _, prelude_body = sections[0]
    if prelude_body.strip():
        kept.append(prelude_body.rstrip())

    for heading, body in sections[1:]:
        if _should_drop(body):
            continue
        kept.append((heading or "").rstrip() + ("\n" + body.rstrip() if body.strip() else ""))

    body_text = "\n\n".join(part for part in kept if part).strip()
    if _FALLBACK_FOOTER not in body_text:
        body_text = f"{body_text}\n\n{_FALLBACK_FOOTER}".strip()
    result = body_text + "\n"
    _cache[key] = result
    return result


def is_enabled() -> bool:
    return os.getenv("GAUNTLET_SLIM_LLMS", "").lower() in {"1", "true", "yes", "on"}
