"""Contextual chunking via Gemini 2.5 Flash.

For each chunk we ask Gemini to write a 1-2 sentence "where this sits"
blurb based on neighboring sections. The blurb is prepended to the chunk
before embedding/indexing, which is the Anthropic "contextual retrieval"
trick adapted for a smaller context window.

We use a sliding-neighborhood window (prev/next sections) rather than
re-sending the whole document per chunk, because:
  * the markdown sections in llms-full are already topical
  * neighborhood context is enough to disambiguate "this section shows
    the CDP URL format" from "this section configures Playwright"
  * cost is ~$0.10 one-shot vs ~$3 with the full doc per chunk

Results are cached to disk keyed by SHA256 of the chunk bodies + model
name so re-runs are free. Set GAUNTLET_CONTEXTUAL_CHUNKING=1 to enable.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import httpx


GEMINI_MODEL = os.getenv("GAUNTLET_CONTEXT_MODEL", "gemini-2.5-flash")
_GEMINI_URL_TMPL = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
)
NEIGHBORHOOD_RADIUS = 2
MAX_CHUNK_CHARS_IN_PROMPT = 2400
MAX_NEIGHBOR_CHARS = 800
DEFAULT_TIMEOUT = 30.0


def _clean_key(name: str) -> str:
    raw = os.getenv(name, "")
    if not raw:
        return ""
    return raw.strip().split()[0] if raw.strip() else ""


def is_enabled() -> bool:
    if os.getenv("GAUNTLET_CONTEXTUAL_CHUNKING", "").lower() not in {"1", "true", "yes", "on"}:
        return False
    return bool(_clean_key("GEMINI_API_KEY"))


def _truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit].rstrip() + " …"


def _content_hash(chunk_bodies: Sequence[str]) -> str:
    h = hashlib.sha256()
    h.update(GEMINI_MODEL.encode("utf-8"))
    h.update(b"\x00")
    for body in chunk_bodies:
        h.update(body.encode("utf-8", errors="replace"))
        h.update(b"\x00")
    return h.hexdigest()


def _build_prompt(target: Mapping[str, Any], neighbors: list[Mapping[str, Any]]) -> str:
    target_path = target.get("path_text") or target.get("title") or ""
    target_body = _truncate(str(target.get("text") or ""), MAX_CHUNK_CHARS_IN_PROMPT)

    neighbor_lines: list[str] = []
    for n in neighbors:
        n_path = n.get("path_text") or n.get("title") or ""
        n_body = _truncate(str(n.get("text") or ""), MAX_NEIGHBOR_CHARS)
        neighbor_lines.append(f"### {n_path}\n{n_body}")
    neighbors_block = "\n\n".join(neighbor_lines) if neighbor_lines else "(no neighbors)"

    return (
        "You are situating a single documentation chunk for a retrieval index.\n"
        "Write ONE OR TWO short sentences (max 240 characters total) that describe what the "
        "TARGET section is about and how it relates to surrounding sections. Mention any "
        "concrete API names, flags, headers, endpoints, env vars, file paths, or commands "
        "from the TARGET so retrieval can match short queries. Do NOT mention 'this section' "
        "or 'this chunk'. Do NOT repeat the heading verbatim. Output the blurb only.\n\n"
        f"=== TARGET ({target_path}) ===\n{target_body}\n\n"
        f"=== NEIGHBORS ===\n{neighbors_block}\n"
    )


def _call_gemini(prompt: str, *, api_key: str, timeout: float) -> str:
    url = _GEMINI_URL_TMPL.format(model=GEMINI_MODEL, key=api_key)
    payload = {
        "contents": [{"parts": [{"text": prompt}], "role": "user"}],
        "generationConfig": {
            "temperature": 0.1,
            "maxOutputTokens": 256,
            "responseMimeType": "text/plain",
            "thinkingConfig": {"thinkingBudget": 0},
        },
    }
    with httpx.Client(timeout=timeout) as client:
        response = client.post(url, json=payload, headers={"Content-Type": "application/json"})
        response.raise_for_status()
        body = response.json()
    candidates = body.get("candidates") or []
    if not candidates:
        return ""
    parts = candidates[0].get("content", {}).get("parts") or []
    text = "".join(part.get("text", "") for part in parts).strip()
    return text


def _build_neighborhood(chunks: list[Mapping[str, Any]], index: int) -> list[Mapping[str, Any]]:
    start = max(0, index - NEIGHBORHOOD_RADIUS)
    end = min(len(chunks), index + NEIGHBORHOOD_RADIUS + 1)
    return [chunks[i] for i in range(start, end) if i != index]


def _load_cache(cache_path: Path, fingerprint: str) -> dict[str, str] | None:
    if not cache_path.exists():
        return None
    try:
        payload = json.loads(cache_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("fingerprint") != fingerprint:
        return None
    contexts = payload.get("contexts")
    if not isinstance(contexts, dict):
        return None
    return {str(k): str(v) for k, v in contexts.items()}


def _save_cache(cache_path: Path, fingerprint: str, contexts: Mapping[str, str]) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "fingerprint": fingerprint,
        "model": GEMINI_MODEL,
        "contexts": dict(contexts),
    }
    cache_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def augment_chunks_with_context(
    *,
    chunks: list[dict[str, Any]],
    cache_path: Path,
    timeout: float = DEFAULT_TIMEOUT,
) -> list[dict[str, Any]]:
    """Returns the chunk list with a `context` field added to each chunk.

    Falls back to the original chunks unchanged if:
      * GAUNTLET_CONTEXTUAL_CHUNKING is not set,
      * no GEMINI_API_KEY is configured,
      * the Gemini call fails.
    """
    if not chunks:
        return chunks
    if not is_enabled():
        return chunks

    api_key = _clean_key("GEMINI_API_KEY")
    if not api_key:
        return chunks

    bodies = [str(c.get("text") or "") for c in chunks]
    fingerprint = _content_hash(bodies)

    cached = _load_cache(cache_path, fingerprint)
    contexts: dict[str, str] = dict(cached) if cached else {}

    needs_update = False
    save_every = 25
    for index, chunk in enumerate(chunks):
        chunk_id = str(chunk.get("chunk_id") or f"chunk-{index}")
        if chunk_id in contexts and contexts[chunk_id]:
            continue
        neighbors = _build_neighborhood(chunks, index)
        prompt = _build_prompt(chunk, neighbors)
        attempts = 0
        while True:
            try:
                blurb = _call_gemini(prompt, api_key=api_key, timeout=timeout)
                break
            except httpx.HTTPError:
                attempts += 1
                if attempts >= 3:
                    blurb = ""
                    break
                time.sleep(0.5 * attempts)
        contexts[chunk_id] = blurb or ""
        needs_update = True
        if (index + 1) % save_every == 0:
            try:
                _save_cache(cache_path, fingerprint, contexts)
            except OSError:
                pass

    if needs_update:
        try:
            _save_cache(cache_path, fingerprint, contexts)
        except OSError:
            pass

    augmented: list[dict[str, Any]] = []
    for index, chunk in enumerate(chunks):
        chunk_id = str(chunk.get("chunk_id") or f"chunk-{index}")
        context = contexts.get(chunk_id, "").strip()
        new_chunk = dict(chunk)
        if context:
            new_chunk["context"] = context
        augmented.append(new_chunk)
    return augmented
