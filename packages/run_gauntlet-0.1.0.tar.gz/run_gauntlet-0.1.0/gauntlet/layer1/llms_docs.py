from __future__ import annotations

import json
import math
import os
import re
from collections import Counter
from pathlib import Path
from typing import Any, Mapping

import httpx
from dotenv import load_dotenv

try:
    from rank_bm25 import BM25Okapi  # type: ignore[import-not-found]

    _BM25_AVAILABLE = True
except ImportError:  # pragma: no cover
    BM25Okapi = None  # type: ignore[assignment,misc]
    _BM25_AVAILABLE = False

from gauntlet.layer1 import embeddings as _embeddings_module
from gauntlet.layer1 import contextual_chunking as _contextual_chunking_module
from gauntlet.layer1 import query_rewriting as _query_rewriting_module

_EMBEDDINGS_CACHE_DIR = Path(os.getenv("GAUNTLET_EMBEDDINGS_CACHE_DIR", ".gauntlet_cache"))
_EMBEDDINGS_INDEX: tuple[Any, list[str]] | None = None
_EMBEDDINGS_CORPUS_HASH: str | None = None
_CONTEXTS_CACHE_DIR = Path(os.getenv("GAUNTLET_CONTEXTS_CACHE_DIR", ".gauntlet_cache"))


def load_environment() -> None:
    for path in [
        Path.cwd() / ".env",
        Path.cwd() / "gauntlet" / ".env",
        Path(__file__).resolve().parent / ".env",
    ]:
        if path.exists():
            load_dotenv(path, override=False)


def _find_local_doc(filename: str) -> tuple[str, str] | None:
    for path in [
        Path.cwd() / filename,
        Path.cwd() / "docs" / filename,
        Path.cwd() / "gauntlet" / filename,
        Path.cwd() / "gauntlet" / "docs" / filename,
        Path(__file__).resolve().parent / filename,
    ]:
        if path.exists() and path.is_file():
            return path.read_text(encoding="utf-8"), str(path)
    return None


async def _fetch_url(url: str) -> tuple[str, str]:
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        response = await client.get(url)
        response.raise_for_status()
        return response.text, url


def _slugify(value: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return value or "section"


def _clean_line(line: str) -> str:
    return re.sub(r"\s+", " ", line.strip())


def _tokenize_terms(text: str) -> list[str]:
    return [token for token in re.findall(r"[a-z0-9_/-]+", text.lower()) if len(token) > 1]


def _tokenize(text: str) -> set[str]:
    return set(_tokenize_terms(text))


COMMON_DOMAIN_PARTS = {
    "www",
    "com",
    "org",
    "net",
    "io",
    "dev",
    "app",
    "ai",
    "co",
    "api",
}

QUERY_STOP_TERMS = {
    "the",
    "and",
    "for",
    "with",
    "from",
    "that",
    "this",
    "what",
    "when",
    "where",
    "into",
    "after",
    "before",
    "then",
    "step",
    "steps",
    "error",
    "failed",
    "failure",
    "output",
    "response",
    "payload",
    "task",
    "goal",
    "run",
}


def _extract_domain_terms(text: str) -> list[str]:
    domains: list[str] = []
    for match in re.finditer(r"(?:https?://)?([a-z0-9][a-z0-9.-]+\.[a-z]{2,})(?:[:/][^\s]*)?", text.lower()):
        host = match.group(1).strip(".")
        if not host:
            continue
        if host.startswith("www."):
            host = host[4:]
        domains.append(host)
        for part in host.split("."):
            if part and part not in COMMON_DOMAIN_PARTS:
                domains.append(part)
    return domains


def _extract_identifier_terms(text: str) -> list[str]:
    identifiers: list[str] = []
    for match in re.finditer(r"\b[a-zA-Z][a-zA-Z0-9_./:-]{2,}\b", text):
        value = match.group(0).strip().lower()
        if not value:
            continue
        if not any(separator in value for separator in ("_", "/", ".", ":", "-")) and not any(
            char.isdigit() for char in value
        ):
            continue
        identifiers.append(value)
        identifiers.extend(part for part in re.split(r"[_./:-]+", value) if len(part) > 2)
    return identifiers


def _normalize_hint_terms(values: Any) -> list[str]:
    if isinstance(values, str):
        values = [values]
    if not isinstance(values, list):
        return []
    normalized: list[str] = []
    for value in values:
        if not isinstance(value, str):
            continue
        for term in _tokenize_terms(value):
            if term not in QUERY_STOP_TERMS:
                normalized.append(term)
    return normalized


def _distinct_phrases(*values: str | None, limit: int = 8) -> list[str]:
    phrases: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        cleaned = re.sub(r"\s+", " ", value).strip()
        if not cleaned:
            continue
        lowered = cleaned.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        phrases.append(cleaned[:180])
        if len(phrases) >= limit:
            break
    return phrases


def _extract_links(text: str) -> list[dict[str, str]]:
    links: list[dict[str, str]] = []
    for label, href in re.findall(r"\[([^\]]+)\]\(([^)]+)\)", text):
        links.append({"label": _clean_line(label), "href": href.strip()})
    return links


def _split_markdown_sections(text: str) -> list[dict[str, Any]]:
    lines = text.splitlines()
    sections: list[dict[str, Any]] = []
    current_title = "Document Overview"
    current_level = 0
    current_path = ["Document Overview"]
    current_lines: list[str] = []
    heading_stack: list[tuple[int, str]] = []
    current_line_start = 1
    current_char_start = 0
    char_offset = 0

    def flush() -> None:
        body = "\n".join(current_lines).strip()
        if not body:
            return
        start_line = current_line_start
        end_line = current_line_start + len(current_lines) - 1
        sections.append(
            {
                "title": current_title,
                "anchor": _slugify(current_title),
                "level": current_level,
                "path": list(current_path),
                "text": body,
                "line_start": start_line,
                "line_end": end_line,
                "start_char": current_char_start,
                "end_char": char_offset,
            }
        )

    for line_number, line in enumerate(lines, start=1):
        heading_match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if heading_match:
            flush()
            title = _clean_line(heading_match.group(2))
            level = len(heading_match.group(1))

            while heading_stack and heading_stack[-1][0] >= level:
                heading_stack.pop()
            heading_stack.append((level, title))

            current_title = title
            current_level = level
            current_path = [item[1] for item in heading_stack]
            current_lines = []
            current_line_start = line_number + 1
            current_char_start = char_offset + len(line) + 1
            char_offset += len(line) + 1
            continue
        current_lines.append(line)
        char_offset += len(line) + 1

    flush()
    return sections


def _pick_summary_lines(text: str, limit: int = 6) -> list[str]:
    summary_lines: list[str] = []
    for raw_line in text.splitlines():
        line = _clean_line(raw_line)
        if not line or line.startswith("#"):
            continue
        summary_lines.append(line.lstrip("-* "))
        if len(summary_lines) >= limit:
            break
    return summary_lines


def _manifest_line(section: Mapping[str, Any]) -> str:
    path = " > ".join(section["path"])
    return f"- {path} [{section['anchor']}] preview={section['preview']}"


def _summarize_section(text: str, limit: int = 220) -> str:
    cleaned = _clean_line(text)
    return cleaned[:limit]


def normalize_llms_manifest(llms_text: str) -> dict[str, Any]:
    sections = _split_markdown_sections(llms_text)
    manifest_sections: list[dict[str, Any]] = []

    for index, section in enumerate(sections):
        manifest_sections.append(
            {
                "id": section["anchor"],
                "index": index,
                "title": section["title"],
                "anchor": section["anchor"],
                "level": section["level"],
                "path": section["path"],
                "path_text": " > ".join(section["path"]),
                "parent_path": section["path"][:-1],
                "preview": _summarize_section(section["text"]),
                "links": _extract_links(section["text"]),
            }
        )

    outline = "\n".join(_manifest_line(section) for section in manifest_sections[:20])
    path_index = {section["path_text"]: section["anchor"] for section in manifest_sections}

    return {
        "summary_lines": _pick_summary_lines(llms_text),
        "section_count": len(manifest_sections),
        "sections": manifest_sections,
        "path_index": path_index,
        "manifest_text": outline,
    }


def _chunk_llms_full_text(llms_full_text: str) -> list[dict[str, Any]]:
    chunks: list[dict[str, Any]] = []
    for index, section in enumerate(_split_markdown_sections(llms_full_text)):
        path_text = " > ".join(section["path"])
        title_terms = _tokenize_terms(section["title"])
        path_terms = _tokenize_terms(path_text)
        body_terms = _tokenize_terms(section["text"])
        ranking_terms = title_terms + path_terms + body_terms
        chunks.append(
            {
                "chunk_id": f"chunk-{index}",
                "title": section["title"],
                "anchor": section["anchor"],
                "level": section["level"],
                "path": section["path"],
                "path_text": path_text,
                "preview": _summarize_section(section["text"], limit=260),
                "text": section["text"],
                "line_start": section.get("line_start"),
                "line_end": section.get("line_end"),
                "start_char": section.get("start_char"),
                "end_char": section.get("end_char"),
                "domain_terms": sorted(set(_extract_domain_terms(f"{path_text}\n{section['text']}"))),
                "identifier_terms": sorted(
                    set(_extract_identifier_terms(f"{section['title']}\n{path_text}\n{section['text']}"))
                ),
                "tokens": sorted(set(ranking_terms)),
                "title_terms": title_terms,
                "path_terms": path_terms,
                "body_terms": body_terms,
                "ranking_terms": ranking_terms,
            }
        )

    if _contextual_chunking_module.is_enabled():
        cache_path = _CONTEXTS_CACHE_DIR / "contexts.json"
        chunks = _contextual_chunking_module.augment_chunks_with_context(
            chunks=chunks,
            cache_path=cache_path,
        )
        for chunk in chunks:
            context = str(chunk.get("context") or "").strip()
            if not context:
                continue
            context_terms = _tokenize_terms(context)
            if not context_terms:
                continue
            chunk["context_terms"] = context_terms
            chunk["ranking_terms"] = list(chunk.get("ranking_terms", [])) + context_terms
            chunk["body_terms"] = list(chunk.get("body_terms", [])) + context_terms
            chunk["tokens"] = sorted(set(chunk["ranking_terms"]))
    return chunks


def _normalize_runtime_need(*parts: str | None) -> str:
    return "\n".join(part.strip() for part in parts if part and part.strip())


def _build_idf(chunks: list[Mapping[str, Any]]) -> dict[str, float]:
    document_count = max(len(chunks), 1)
    doc_freq: Counter[str] = Counter()

    for chunk in chunks:
        doc_freq.update(set(chunk.get("ranking_terms", [])))

    return {
        term: math.log((1 + document_count) / (1 + freq)) + 1.0
        for term, freq in doc_freq.items()
    }


def _chunk_embedding_text(chunk: Mapping[str, Any]) -> str:
    """Compose the text we embed for a chunk. Prepending the breadcrumb
    path gives the embedding much more topical context than the body alone,
    especially for the short fragments the markdown chunker produces. When
    contextual chunking is enabled we also prepend the generated context
    blurb so semantic search can match on intent words the body lacks."""
    path_text = str(chunk.get("path_text") or chunk.get("title") or "")
    context = str(chunk.get("context") or "").strip()
    body = str(chunk.get("text") or "")
    parts = [path_text]
    if context:
        parts.append(f"Context: {context}")
    parts.append(body)
    return "\n\n".join(part for part in parts if part).strip()


def _dense_scores(chunks: list[Mapping[str, Any]], query_text: str) -> dict[str, float]:
    if not _embeddings_module.is_available() or not chunks or not query_text.strip():
        return {}

    global _EMBEDDINGS_INDEX, _EMBEDDINGS_CORPUS_HASH
    model = _embeddings_module.active_model()
    if not model:
        return {}
    chunk_ids = [str(c.get("chunk_id") or f"chunk-{i}") for i, c in enumerate(chunks)]
    chunk_texts = [_chunk_embedding_text(c) for c in chunks]
    corpus_hash = _embeddings_module._content_hash(chunk_texts, model)

    if _EMBEDDINGS_INDEX is None or _EMBEDDINGS_CORPUS_HASH != corpus_hash:
        cache_path = _EMBEDDINGS_CACHE_DIR / f"embeddings_{corpus_hash[:16]}.npz"
        built = _embeddings_module.load_or_build_index(
            chunk_ids=chunk_ids,
            chunk_texts=chunk_texts,
            cache_path=cache_path,
        )
        if built is None:
            return {}
        _EMBEDDINGS_INDEX = built
        _EMBEDDINGS_CORPUS_HASH = corpus_hash

    matrix, cached_ids = _EMBEDDINGS_INDEX
    return _embeddings_module.dense_scores(
        query_text=query_text,
        matrix=matrix,
        chunk_ids=cached_ids,
    )


def _bm25_scores(chunks: list[Mapping[str, Any]], query_terms: list[str]) -> dict[str, float]:
    if not _BM25_AVAILABLE or not chunks or not query_terms:
        return {}
    corpus = [list(chunk.get("ranking_terms", [])) for chunk in chunks]
    if not any(corpus):
        return {}
    bm25 = BM25Okapi(corpus)
    raw = bm25.get_scores(query_terms)
    return {
        str(chunk.get("chunk_id") or f"chunk-{idx}"): float(raw[idx])
        for idx, chunk in enumerate(chunks)
    }


def _rrf_fuse(rankings: list[list[str]], k: int = 60) -> dict[str, float]:
    """Reciprocal Rank Fusion. Each input is an ordered list of chunk_ids
    (best-first). Returns chunk_id -> fused score."""
    fused: dict[str, float] = {}
    for ranking in rankings:
        for rank, chunk_id in enumerate(ranking):
            fused[chunk_id] = fused.get(chunk_id, 0.0) + 1.0 / (k + rank + 1)
    return fused


def _weighted_vector(terms: list[str], idf: Mapping[str, float]) -> dict[str, float]:
    counts = Counter(terms)
    if not counts:
        return {}
    return {
        term: (1.0 + math.log(freq)) * idf.get(term, 1.0)
        for term, freq in counts.items()
    }


def _cosine_similarity(left: Mapping[str, float], right: Mapping[str, float]) -> float:
    if not left or not right:
        return 0.0

    dot = sum(weight * right.get(term, 0.0) for term, weight in left.items())
    if dot <= 0.0:
        return 0.0

    left_norm = math.sqrt(sum(weight * weight for weight in left.values()))
    right_norm = math.sqrt(sum(weight * weight for weight in right.values()))
    if left_norm == 0.0 or right_norm == 0.0:
        return 0.0
    return dot / (left_norm * right_norm)


def _count_markdown_steps(text: str) -> int:
    count = 0
    for line in text.splitlines():
        stripped = line.strip()
        if re.match(r"^([-*]|\d+[.)])\s+", stripped):
            count += 1
    return count


def _generic_complexity_penalty(chunk: Mapping[str, Any]) -> float:
    text = str(chunk.get("text", ""))
    path = chunk.get("path", [])
    line_count = len([line for line in text.splitlines() if line.strip()])
    code_blocks = text.count("```")
    step_lines = _count_markdown_steps(text)
    path_depth = len(path) if isinstance(path, list) else 0

    penalty = 0.0
    penalty += min(line_count / 220.0, 1.0) * 0.08
    penalty += min(code_blocks / 4.0, 1.0) * 0.06
    penalty += min(step_lines / 10.0, 1.0) * 0.04
    penalty += min(max(path_depth - 1, 0) / 6.0, 1.0) * 0.03
    return penalty


def _rare_term_bonus(overlap_terms: set[str], idf: Mapping[str, float]) -> float:
    if not overlap_terms:
        return 0.0
    return min(sum(idf.get(term, 1.0) for term in overlap_terms) / 18.0, 0.22)


def _phrase_match_bonus(text: str, phrases: list[str]) -> float:
    if not text or not phrases:
        return 0.0
    lowered = text.lower()
    matches = 0
    for phrase in phrases:
        if len(phrase) < 4:
            continue
        if phrase.lower() in lowered:
            matches += 1
    return min(matches * 0.05, 0.2)


def _score_chunk(
    chunk: Mapping[str, Any],
    *,
    query_terms: list[str],
    query_vector: Mapping[str, float],
    idf: Mapping[str, float],
    error_terms: list[str],
    error_vector: Mapping[str, float],
    anchor_terms: list[str],
    anchor_phrases: list[str],
    preferred_paths: list[str],
) -> dict[str, float]:
    ranking_vector = _weighted_vector(list(chunk.get("ranking_terms", [])), idf)
    title_vector = _weighted_vector(list(chunk.get("title_terms", [])), idf)
    path_vector = _weighted_vector(list(chunk.get("path_terms", [])), idf)
    body_vector = _weighted_vector(list(chunk.get("body_terms", [])), idf)

    semantic_similarity = _cosine_similarity(query_vector, ranking_vector)
    title_similarity = _cosine_similarity(query_vector, title_vector)
    path_similarity = _cosine_similarity(query_vector, path_vector)
    body_similarity = _cosine_similarity(query_vector, body_vector)
    error_alignment = _cosine_similarity(error_vector, ranking_vector) if error_terms else 0.0

    query_token_set = set(query_terms)
    chunk_token_set = set(chunk.get("tokens", []))
    overlap_ratio = len(query_token_set & chunk_token_set) / max(len(query_token_set), 1)
    specificity_bonus = min(overlap_ratio, 0.5) * 0.18
    complexity_penalty = _generic_complexity_penalty(chunk)
    anchor_token_set = set(anchor_terms)
    chunk_anchor_terms = set(chunk.get("domain_terms", [])) | set(chunk.get("identifier_terms", [])) | set(
        chunk.get("title_terms", [])
    ) | set(chunk.get("path_terms", []))
    anchor_overlap = anchor_token_set & chunk_anchor_terms
    anchor_bonus = _rare_term_bonus(anchor_overlap, idf)
    if anchor_token_set and not anchor_overlap:
        anchor_bonus -= 0.06

    path_text = str(chunk.get("path_text") or "")
    preferred_path_bonus = 0.0
    for preferred in preferred_paths:
        preferred_lower = preferred.lower()
        if preferred_lower and preferred_lower in path_text.lower():
            preferred_path_bonus = 0.08
            break

    phrase_bonus = _phrase_match_bonus("\n".join([str(chunk.get("title") or ""), path_text, str(chunk.get("text") or "")]), anchor_phrases)

    final_score = (
        semantic_similarity * 0.60
        + body_similarity * 0.15
        + title_similarity * 0.15
        + path_similarity * 0.10
        + specificity_bonus
        + error_alignment * 0.12
        + anchor_bonus
        + preferred_path_bonus
        + phrase_bonus
        - complexity_penalty
    )

    return {
        "score": final_score,
        "semantic_similarity": semantic_similarity,
        "title_similarity": title_similarity,
        "path_similarity": path_similarity,
        "body_similarity": body_similarity,
        "specificity_bonus": specificity_bonus,
        "complexity_penalty": complexity_penalty,
        "error_alignment": error_alignment,
        "anchor_overlap_count": float(len(anchor_overlap)),
        "anchor_bonus": anchor_bonus,
        "phrase_bonus": phrase_bonus,
        "preferred_path_bonus": preferred_path_bonus,
    }


def _rerank_chunks(
    chunks: list[dict[str, Any]],
    *,
    anchor_terms: list[str],
    anchor_phrases: list[str],
) -> list[dict[str, Any]]:
    if not chunks:
        return []

    anchor_set = set(anchor_terms)
    reranked: list[dict[str, Any]] = []
    for chunk in chunks:
        path_text = str(chunk.get("path_text") or "").lower()
        title = str(chunk.get("title") or "").lower()
        text = str(chunk.get("text") or "").lower()
        chunk_anchor_terms = set(chunk.get("domain_terms", [])) | set(chunk.get("identifier_terms", []))
        overlap = anchor_set & chunk_anchor_terms
        anchor_coverage = len(overlap) / max(len(anchor_set), 1)
        exact_phrase_hits = sum(1 for phrase in anchor_phrases if len(phrase) >= 4 and phrase.lower() in text)
        header_phrase_hits = sum(
            1 for phrase in anchor_phrases if len(phrase) >= 4 and phrase.lower() in f"{title}\n{path_text}"
        )
        rerank_score = (
            chunk["score"]
            + float(chunk.get("rrf_score", 0.0)) * 5.0
            + anchor_coverage * 0.18
            + min(exact_phrase_hits, 2) * 0.05
            + min(header_phrase_hits, 1) * 0.06
        )
        reranked.append(
            {
                **chunk,
                "anchor_coverage": anchor_coverage,
                "rerank_score": rerank_score,
                "exact_phrase_hits": exact_phrase_hits,
            }
        )
    reranked.sort(
        key=lambda chunk: (
            chunk["rerank_score"],
            chunk.get("anchor_overlap_count", 0.0),
            chunk.get("title_similarity", 0.0),
            -chunk.get("level", 0),
        ),
        reverse=True,
    )
    return reranked


def _chunk_diversity_key(chunk: Mapping[str, Any]) -> str:
    path = chunk.get("path")
    if isinstance(path, list) and len(path) >= 2:
        return str(path[1]).lower()
    if isinstance(path, list) and path:
        return str(path[0]).lower()
    return str(chunk.get("path_text") or "").split(" > ", 1)[0].lower()


def _select_diverse_chunks(chunks: list[dict[str, Any]], *, max_chunks: int) -> list[dict[str, Any]]:
    if len(chunks) <= max_chunks:
        return chunks[:max_chunks]

    selected: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for chunk in chunks:
        diversity_key = _chunk_diversity_key(chunk)
        if diversity_key and diversity_key in seen_keys and len(selected) + 1 < max_chunks:
            continue
        selected.append(chunk)
        if diversity_key:
            seen_keys.add(diversity_key)
        if len(selected) >= max_chunks:
            break

    if len(selected) < max_chunks:
        selected_ids = {chunk["chunk_id"] for chunk in selected}
        for chunk in chunks:
            if chunk["chunk_id"] in selected_ids:
                continue
            selected.append(chunk)
            if len(selected) >= max_chunks:
                break
    return selected


def _retrieval_relevance_label(selected_chunks: list[dict[str, Any]], anchor_terms: list[str]) -> tuple[str, str]:
    if not selected_chunks:
        return "irrelevant", "No documentation chunks were retrieved."

    top = selected_chunks[0]
    top_score = float(top.get("rerank_score", top.get("score", 0.0)))
    top_anchor_count = int(top.get("anchor_overlap_count", 0.0))
    if anchor_terms:
        if top_anchor_count == 0 and top_score < 0.3:
            return "irrelevant", "Top retrieved docs did not match the failure-specific anchors."
        if top_anchor_count == 0 or top_score < 0.42:
            return "partial", "Retrieved docs were only partially aligned with the failure-specific anchors."
        return "relevant", "Retrieved docs matched the failure-specific anchors and scored strongly."
    if top_score < 0.24:
        return "irrelevant", "Retrieved docs scored weakly against the runtime need."
    if top_score < 0.42:
        return "partial", "Retrieved docs matched the runtime need only partially."
    return "relevant", "Retrieved docs scored strongly against the runtime need."


def _choose_tool_contract(
    runtime_need: str,
    selected_chunks: list[Mapping[str, Any]],
    tool_schemas: Mapping[str, str] | None,
) -> dict[str, str] | None:
    if not tool_schemas:
        return None

    chunk_context = "\n".join(
        f"{chunk.get('path_text', '')}\n{chunk.get('title', '')}\n{chunk.get('preview', '')}"
        for chunk in selected_chunks
    )
    ranking_context = _normalize_runtime_need(runtime_need, chunk_context)
    query_terms = _tokenize_terms(ranking_context)
    if not query_terms:
        return None

    pseudo_chunk = {"ranking_terms": query_terms}
    tool_entries = [
        {
            "tool": tool_name,
            "description": description,
            "terms": _tokenize_terms(f"{tool_name} {description}"),
        }
        for tool_name, description in tool_schemas.items()
    ]
    idf = _build_idf([pseudo_chunk, *({"ranking_terms": entry["terms"]} for entry in tool_entries)])
    query_vector = _weighted_vector(query_terms, idf)
    query_token_set = set(query_terms)
    docs_intent = bool(query_token_set & {"docs", "documentation", "read", "ground", "manifest", "reference"})

    ranked: list[tuple[float, str, str]] = []
    for entry in tool_entries:
        tool_vector = _weighted_vector(entry["terms"], idf)
        score = _cosine_similarity(query_vector, tool_vector)
        description_lower = entry["description"].lower()
        is_meta_docs_tool = any(
            keyword in description_lower
            for keyword in ("documentation", "manifest", "ground", "read a single documentation file")
        ) or entry["tool"] in {"read_docs", "read_doc", "ground_docs"}
        if is_meta_docs_tool and not docs_intent:
            score -= 0.18
        if score > 0:
            ranked.append((score, entry["tool"], entry["description"]))

    if not ranked:
        return None

    ranked.sort(key=lambda item: item[0], reverse=True)
    _, tool_name, description = ranked[0]
    return {"tool": tool_name, "description": description}


INTENT_KEYWORDS: dict[str, tuple[str, ...]] = {
    "REST_API": ("rest api", "rest", "curl", "http request", "/v1/", "api directly"),
    "CLI": ("cli", "command line", "steel forge", "npx", "terminal"),
    "SDK": ("sdk", "python sdk", "typescript sdk", "client."),
    "AUTH": ("auth", "authorization", "bearer", "api key", "login"),
    "FILE_UPLOAD": ("upload", "file", "multipart", "download", "archive"),
    "EXTENSIONS": ("extension", "manifest v3", "browser extension", "/extensions"),
    "RESPONSE_SCHEMA": ("response schema", "schema", "content.html", "content.markdown", "json response"),
    "BROWSER_SESSION": ("session", "browser session", "live session", "recording"),
    "PLAYWRIGHT": ("playwright", "page.goto", "chromium"),
    "SELENIUM": ("selenium", "webdriver"),
    "CREDENTIALS": ("credential", "credentials", "api key", "secret", "namespace"),
    "PROXY": ("proxy", "proxies", "region", "residential", "lax", "ord", "uk"),
    "CAPTCHA": ("captcha", "turnstile", "challenge"),
    "PROFILE_OR_AUTH_CONTEXT": ("profile", "auth context", "authenticated state", "reusable auth"),
}


EXPECTED_DOC_TYPES_BY_INTENT: dict[str, tuple[str, ...]] = {
    "REST_API": ("rest_auth", "rest_endpoint", "curl_example"),
    "CLI": ("cli_example", "forge_template"),
    "SDK": ("sdk_example",),
    "AUTH": ("rest_auth", "credentials", "auth_context"),
    "FILE_UPLOAD": ("file_upload",),
    "EXTENSIONS": ("extension_upload", "rest_endpoint"),
    "RESPONSE_SCHEMA": ("response_schema",),
    "BROWSER_SESSION": ("session_docs",),
    "PLAYWRIGHT": ("playwright", "forge_template"),
    "SELENIUM": ("selenium",),
    "CREDENTIALS": ("credentials",),
    "PROXY": ("proxy",),
    "CAPTCHA": ("captcha",),
    "PROFILE_OR_AUTH_CONTEXT": ("profile", "auth_context"),
}


def _detect_intents(text: str) -> list[str]:
    lowered = text.lower()
    detected: list[str] = []
    for intent, keywords in INTENT_KEYWORDS.items():
        if any(keyword in lowered for keyword in keywords):
            detected.append(intent)
    return detected


def _doc_types_for_text(text: str) -> list[str]:
    lowered = text.lower()
    types: list[str] = []
    checks = {
        "sdk_example": ("sdk", "client.", "from ", "import "),
        "rest_auth": ("authorization", "bearer", "api key", "x-api-key"),
        "rest_endpoint": ("/v1/", "post /", "get /", "put /", "delete /"),
        "curl_example": ("curl ", "multipart/form-data"),
        "extension_upload": ("extension", "/extensions", "manifest v3"),
        "cli_example": (" cli", "command line", "usage:", "npx ", "$ "),
        "forge_template": ("template", "playwright-py", "playwright-ts", "forge"),
        "response_schema": ("content.html", "content.markdown", "schema", "response"),
        "session_docs": ("session", "browser session"),
        "playwright": ("playwright", "page.goto"),
        "selenium": ("selenium", "webdriver"),
        "credentials": ("credential", "api key", "secret", "namespace"),
        "proxy": ("proxy", "region", "residential"),
        "captcha": ("captcha", "turnstile", "challenge"),
        "profile": ("profile",),
        "auth_context": ("auth context", "authenticated state"),
        "file_upload": ("upload", "download", "file"),
    }
    for doc_type, keywords in checks.items():
        if any(keyword in lowered for keyword in keywords):
            types.append(doc_type)
    return types


def _chunk_doc_types(chunk: Mapping[str, Any]) -> list[str]:
    return _doc_types_for_text(
        "\n".join(
            str(chunk.get(key) or "")
            for key in ("path_text", "title", "preview", "text")
        )
    )


def _expected_doc_types(intents: list[str]) -> list[str]:
    expected: list[str] = []
    for intent in intents:
        expected.extend(EXPECTED_DOC_TYPES_BY_INTENT.get(intent, ()))
    return _dedupe_keep_order(expected, limit=24)


def _intent_bonus(chunk: Mapping[str, Any], intents: list[str]) -> float:
    if not intents:
        return 0.0
    doc_types = set(_chunk_doc_types(chunk))
    expected = set(_expected_doc_types(intents))
    bonus = 0.0
    if expected & doc_types:
        bonus += 0.16
    if "REST_API" in intents and "sdk_example" in doc_types:
        bonus -= 0.35
    if "CLI" in intents and "sdk_example" in doc_types:
        bonus -= 0.35
    unrelated_by_intent = {
        "REST_API": {"captcha", "proxy", "file_upload", "playwright", "selenium", "auth_context", "profile"},
        "CLI": {"captcha", "proxy", "file_upload", "playwright", "selenium", "auth_context", "profile", "sdk_example"},
    }
    explicit_doc_type_intents = {
        "captcha": "CAPTCHA",
        "proxy": "PROXY",
        "file_upload": "FILE_UPLOAD",
        "auth_context": "PROFILE_OR_AUTH_CONTEXT",
        "profile": "PROFILE_OR_AUTH_CONTEXT",
    }
    for intent, unrelated_types in unrelated_by_intent.items():
        if intent not in intents:
            continue
        for doc_type in doc_types & unrelated_types:
            explicit_intent = explicit_doc_type_intents.get(doc_type)
            if explicit_intent and explicit_intent in intents:
                continue
            bonus -= 0.18
    if "EXTENSIONS" in intents and {"extension_upload", "rest_endpoint"} & doc_types:
        bonus += 0.12
    if "RESPONSE_SCHEMA" in intents and "response_schema" in doc_types:
        bonus += 0.18
    return bonus


def _chunk_text_for_filter(chunk: Mapping[str, Any]) -> str:
    return "\n".join(str(chunk.get(key) or "") for key in ("path_text", "title", "preview", "text")).lower()


def _doc_families_for_chunk(chunk: Mapping[str, Any]) -> list[str]:
    doc_types = set(_chunk_doc_types(chunk))
    text = _chunk_text_for_filter(chunk)
    path_title = "\n".join(str(chunk.get(key) or "") for key in ("path_text", "title")).lower()
    families: list[str] = []

    if doc_types & {"rest_endpoint", "curl_example", "response_schema"}:
        families.append("rest")
    if doc_types & {"cli_example", "forge_template"} or re.search(r"\b[a-z0-9_.-]+\s+--help\b", text):
        families.append("cli")
    if "sdk_example" in doc_types:
        families.append("sdk")
    if doc_types & {"credentials", "auth_context", "profile"}:
        families.append("auth")
    if "file_upload" in doc_types:
        families.append("file_upload")
    if "extension_upload" in doc_types:
        families.append("extensions")
    if "proxy" in doc_types:
        families.append("proxy")
    if "captcha" in doc_types:
        families.append("captcha")
    if doc_types & {"playwright", "selenium", "session_docs"}:
        families.append("browser")

    integration_markers = (
        "integration",
        "cookbook",
        "agent",
        "framework",
        "template",
        "quickstart",
        "setup",
        "requirements",
        "resources",
        "related",
    )
    if any(marker in path_title for marker in integration_markers):
        families.append("integration")

    if any(marker in path_title for marker in ("reference", "api reference", "endpoint")):
        families.append("reference")
    if not families:
        families.append("general")
    return _dedupe_keep_order(families, limit=12)


def _generated_profile_for_chunks(chunks: list[dict[str, Any]]) -> dict[str, Any]:
    family_counts: dict[str, int] = {}
    path_families: dict[str, list[str]] = {}
    for chunk in chunks:
        families = _doc_families_for_chunk(chunk)
        path = str(chunk.get("path_text") or chunk.get("title") or chunk.get("chunk_id") or "")
        path_families[path] = families
        for family in families:
            family_counts[family] = family_counts.get(family, 0) + 1
    return {
        "source": "generated_from_docs",
        "family_counts": family_counts,
        "path_families": path_families,
    }


def _allowed_families_for_intents(intents: list[str]) -> set[str] | None:
    if "REST_API" in intents:
        return {"rest", "auth", "reference"}
    if "CLI" in intents:
        return {"cli", "reference"}
    if "SDK" in intents:
        return {"sdk", "auth", "reference"}
    if "EXTENSIONS" in intents:
        return {"extensions", "rest", "auth", "reference"}
    if "BROWSER_SESSION" in intents:
        return {"browser", "auth", "reference"}
    return None


def _chunk_allowed_for_intents(chunk: Mapping[str, Any], intents: list[str], profile: Mapping[str, Any] | None = None) -> bool:
    del profile
    allowed = _allowed_families_for_intents(intents)
    if allowed is None:
        return True
    families = set(_doc_families_for_chunk(chunk))
    path_title = "\n".join(str(chunk.get(key) or "") for key in ("path_text", "title")).lower()
    if "REST_API" in intents and not any(marker in path_title for marker in ("api", "auth", "endpoint", "request", "response", "curl")):
        return False
    if "CLI" in intents and not any(marker in path_title for marker in ("cli", "command", "terminal", "reference", "usage")):
        return False
    if "integration" in families or "browser" in families:
        if "REST_API" in intents and not any(marker in path_title for marker in ("api", "auth", "endpoint", "request", "response", "curl")):
            return False
        if "CLI" in intents and not any(marker in path_title for marker in ("cli", "command", "reference")):
            return False
        if "integration" in families and not families & (allowed - {"auth"}):
            return False
    if "REST_API" in intents and "cli" in families and not any(marker in path_title for marker in ("api", "curl", "http", "request")):
        return False
    return bool(families & allowed)



def _filter_chunks_for_intents(
    ranked_chunks: list[dict[str, Any]],
    intents: list[str],
    profile: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    if not any(intent in intents for intent in ("REST_API", "CLI")):
        return ranked_chunks
    filtered = [chunk for chunk in ranked_chunks if _chunk_allowed_for_intents(chunk, intents, profile)]
    if filtered:
        return filtered
    non_integration = [chunk for chunk in ranked_chunks if "integration" not in _doc_families_for_chunk(chunk)]
    return non_integration or ranked_chunks


def _retrieval_quality(
    *,
    selected_chunks: list[dict[str, Any]],
    detected_intents: list[str],
) -> tuple[list[str], list[str], str]:
    retrieved = _dedupe_keep_order(
        [doc_type for chunk in selected_chunks for doc_type in _chunk_doc_types(chunk)],
        limit=24,
    )
    expected = _expected_doc_types(detected_intents)
    missing = [doc_type for doc_type in expected if doc_type not in retrieved]
    if not expected:
        quality = "unknown"
    elif not missing:
        quality = "good"
    elif len(missing) < len(expected):
        quality = "partial"
    else:
        quality = "poor"
    return retrieved, missing, quality


def _parse_tool_argument_names(description: str, *, required_only: bool) -> list[str]:
    match = re.search(r"Arguments:\s*(.+?)(?:\.\s*$|$)", description)
    if not match:
        return []

    names: list[str] = []
    for raw_part in match.group(1).split(","):
        part = raw_part.strip()
        if not part:
            continue
        name_match = re.match(r"([a-zA-Z_][a-zA-Z0-9_]*)(\?)?", part)
        if not name_match:
            continue
        if required_only and name_match.group(2) == "?":
            continue
        names.append(name_match.group(1))
    return _dedupe_keep_order(names, limit=12)


def _dedupe_keep_order(items: list[str], limit: int) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
        if len(result) >= limit:
            break
    return result


def _extract_grounding_details(selected_chunks: list[dict[str, Any]]) -> dict[str, list[str] | str | None]:
    required_params: list[str] = []
    sequencing_rules: list[str] = []
    limits_errors: list[str] = []
    example: str | None = None

    for chunk in selected_chunks:
        chunk_lines = [_clean_line(line) for line in chunk["text"].splitlines() if _clean_line(line)]
        for line in chunk_lines:
            lowered = line.lower()
            if any(
                keyword in lowered
                for keyword in ("header", "parameter", "body", "query", "api key", "authorization", "required")
            ):
                required_params.append(line)
            if any(keyword in lowered for keyword in ("first", "then", "before", "after", "must", "required")):
                sequencing_rules.append(line)
            if any(
                keyword in lowered for keyword in ("rate limit", "limit", "timeout", "retry", "error", "429", "403")
            ):
                limits_errors.append(line)
            if example is None and any(keyword in lowered for keyword in ("example", "curl", "python", "javascript")):
                example = line

    return {
        "required_params": _dedupe_keep_order(required_params, limit=4),
        "sequencing_rules": _dedupe_keep_order(sequencing_rules, limit=4),
        "limits_errors": _dedupe_keep_order(limits_errors, limit=4),
        "example": example,
    }


METHOD_PATH_STOPWORDS = {
    "console.log",
    "console.error",
    "page.goto",
    "page.click",
    "page.fill",
    "page.textcontent",
    "browser.close",
    "main.catch",
}


def _code_like_blocks(text: str) -> list[str]:
    blocks = re.findall(r"```(?:[^\n`]*)\n(.*?)```", text, flags=re.DOTALL)
    if blocks:
        return [block for block in blocks if block.strip()]
    return [text] if text.strip() else []


def _extract_allowed_method_paths(selected_chunks: list[dict[str, Any]]) -> list[str]:
    candidates: list[str] = []
    for chunk in selected_chunks:
        text = str(chunk.get("text") or "")
        for block in _code_like_blocks(text):
            for raw_match in re.findall(r"\b([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*){1,4})\s*(?=\()", block):
                cleaned = raw_match.strip().strip("`").strip()
                if cleaned.lower() in METHOD_PATH_STOPWORDS:
                    continue
                if cleaned.startswith("client."):
                    cleaned = cleaned[len("client.") :]
                if cleaned.startswith("sdk."):
                    cleaned = cleaned[len("sdk.") :]
                if cleaned.count(".") < 1:
                    continue
                candidates.append(cleaned)
    return _dedupe_keep_order(candidates, limit=10)


def _build_doc_binding(
    *,
    tool_contract: Mapping[str, str] | None,
    selected_chunks: list[dict[str, Any]],
    details: Mapping[str, Any],
) -> dict[str, Any] | None:
    if not tool_contract:
        return None

    preferred_tool = tool_contract.get("tool")
    description = tool_contract.get("description")
    if not isinstance(preferred_tool, str) or not preferred_tool:
        return None

    required_tool_args = (
        _parse_tool_argument_names(description, required_only=True) if isinstance(description, str) else []
    )
    allowed_method_paths = _extract_allowed_method_paths(selected_chunks)
    example = details.get("example")
    known_good_example = example if isinstance(example, str) and ("```" in example or "(" in example) else None
    chunk_scores = [float(chunk.get("rerank_score", chunk.get("score", 0.0)) or 0.0) for chunk in selected_chunks]
    confidence = round(max(chunk_scores) if chunk_scores else 0.0, 2)
    allowed_tools = _dedupe_keep_order(
        [
            preferred_tool,
            "run_http",
            "run_cli",
            "run_python",
            "run_sdk",
        ],
        limit=6,
    )

    return {
        "preferred_tool": preferred_tool,
        "allowed_tools": allowed_tools,
        "confidence": confidence,
        "reason": "Retrieved docs and tool schemas suggest this tool, but this is soft guidance only.",
        "required_tool_args": required_tool_args,
        "allowed_method_paths": allowed_method_paths,
        "known_good_example": known_good_example,
        "source_chunk_ids": [chunk.get("chunk_id") for chunk in selected_chunks if chunk.get("chunk_id")],
    }


def _grounding_block_text(
    capability: str,
    tool_contract: Mapping[str, str] | None,
    doc_binding: Mapping[str, Any] | None,
    required_params: list[str],
    sequencing_rules: list[str],
    limits_errors: list[str],
    example: str | None,
) -> str:
    lines = [f"Capability: {capability}"]
    if tool_contract:
        lines.append(f"Exact tool: {tool_contract['tool']} | {tool_contract['description']}")
    if doc_binding:
        preferred_tool = doc_binding.get("preferred_tool")
        if preferred_tool:
            lines.append(f"Binding preferred tool: {preferred_tool}")
        required_tool_args = doc_binding.get("required_tool_args")
        if isinstance(required_tool_args, list) and required_tool_args:
            lines.append(f"Binding required tool args: {'; '.join(required_tool_args)}")
        allowed_method_paths = doc_binding.get("allowed_method_paths")
        if isinstance(allowed_method_paths, list) and allowed_method_paths:
            lines.append(f"Binding allowed method paths: {'; '.join(allowed_method_paths)}")
        known_good_example = doc_binding.get("known_good_example")
        if isinstance(known_good_example, str) and known_good_example:
            lines.append(f"Binding example: {known_good_example}")
    if required_params:
        lines.append(f"Required params/headers: {'; '.join(required_params)}")
    if sequencing_rules:
        lines.append(f"Sequencing rules: {'; '.join(sequencing_rules)}")
    if limits_errors:
        lines.append(f"Limits/errors: {'; '.join(limits_errors)}")
    if example:
        lines.append(f"Example: {example}")
    return "\n".join(lines)


def _tool_guidance_block(tool_schemas: Mapping[str, str] | None) -> str:
    if not tool_schemas:
        return ""
    ordered_names = [
        "read_doc",
        "ground_docs",
        "run_cli",
        "run_python",
        "run_http",
        "check_credentials",
    ]
    lines = ["Gauntlet tool usage guidance:"]
    for name in ordered_names:
        description = tool_schemas.get(name)
        if description:
            lines.append(f"- {name}: {description}")
    lines.append("- shell=true: use only when a command string needs shell expansion, pipes, redirects, globs, or environment-variable expansion.")
    lines.append("- Artifact references: use exact literal paths from Available artifacts, such as .gauntlet_artifacts/step_2_run_cli_stdout.json.")
    return "\n".join(lines)


def build_runtime_doc_grounding(
    *,
    task: str | None = None,
    previous_output: str | None = None,
    current_error: str | None = None,
    next_goal: str | None = None,
    llms_text: str,
    llms_full_text: str,
    tool_schemas: Mapping[str, str] | None = None,
    retrieval_hints: Mapping[str, Any] | None = None,
    max_chunks: int = 3,
) -> dict[str, Any]:
    manifest = normalize_llms_manifest(llms_text)
    runtime_need = _normalize_runtime_need(task, previous_output, current_error, next_goal)
    detected_intents = _detect_intents(runtime_need)
    chunks = _chunk_llms_full_text(llms_full_text)
    generated_profile = _generated_profile_for_chunks(chunks)
    idf = _build_idf(chunks)
    query_terms = _tokenize_terms(runtime_need)
    if retrieval_hints:
        query_terms.extend(_normalize_hint_terms(retrieval_hints.get("keywords")))
        query_terms.extend(_normalize_hint_terms(retrieval_hints.get("tools")))
        query_terms.extend(_normalize_hint_terms(retrieval_hints.get("domains")))
        query_terms.extend(_normalize_hint_terms(retrieval_hints.get("identifiers")))
    query_vector = _weighted_vector(query_terms, idf)
    error_terms = _tokenize_terms(current_error or "")
    error_vector = _weighted_vector(error_terms, idf)
    anchor_terms = list(
        dict.fromkeys(
            [
                *_normalize_hint_terms(retrieval_hints.get("domains") if retrieval_hints else None),
                *_normalize_hint_terms(retrieval_hints.get("identifiers") if retrieval_hints else None),
                *_normalize_hint_terms(retrieval_hints.get("tools") if retrieval_hints else None),
                *_extract_domain_terms(runtime_need),
                *_extract_identifier_terms(runtime_need),
            ]
        )
    )
    anchor_phrases = _distinct_phrases(
        current_error,
        retrieval_hints.get("error") if retrieval_hints else None,
        retrieval_hints.get("error_type") if retrieval_hints else None,
        retrieval_hints.get("failing_tool") if retrieval_hints else None,
    )
    preferred_paths = _normalize_hint_terms(retrieval_hints.get("tools") if retrieval_hints else None)

    scored_chunks = [
        {
            **chunk,
            **_score_chunk(
                chunk,
                query_terms=query_terms,
                query_vector=query_vector,
                idf=idf,
                error_terms=error_terms,
                error_vector=error_vector,
                anchor_terms=anchor_terms,
                anchor_phrases=anchor_phrases,
                preferred_paths=preferred_paths,
            ),
        }
        for chunk in chunks
    ]

    bm25_scores = _bm25_scores(chunks, query_terms)
    dense_scores = _dense_scores(chunks, runtime_need)
    tfidf_ranking = [
        str(c.get("chunk_id") or "")
        for c in sorted(scored_chunks, key=lambda c: c["score"], reverse=True)
        if c["score"] > 0.0
    ]
    bm25_ranking = [
        cid for cid, score in sorted(bm25_scores.items(), key=lambda kv: kv[1], reverse=True)
        if score > 0.0
    ]
    dense_ranking = [
        cid for cid, score in sorted(dense_scores.items(), key=lambda kv: kv[1], reverse=True)
        if score > 0.0
    ]
    rankings: list[list[str]] = [r for r in (tfidf_ranking, bm25_ranking, dense_ranking) if r]

    query_variants = _query_rewriting_module.rewrite_query(
        task=task,
        next_goal=next_goal,
        runtime_need=runtime_need,
    )
    extra_query_variants: list[str] = []
    for variant in query_variants:
        if not variant or variant.strip() == runtime_need.strip():
            continue
        extra_query_variants.append(variant)
        variant_terms = _tokenize_terms(variant)
        if not variant_terms:
            continue
        variant_bm25 = _bm25_scores(chunks, variant_terms)
        variant_dense = _dense_scores(chunks, variant)
        if variant_bm25:
            rankings.append([
                cid for cid, score in sorted(variant_bm25.items(), key=lambda kv: kv[1], reverse=True)
                if score > 0.0
            ])
        if variant_dense:
            rankings.append([
                cid for cid, score in sorted(variant_dense.items(), key=lambda kv: kv[1], reverse=True)
                if score > 0.0
            ])
    rrf = _rrf_fuse(rankings)

    for chunk in scored_chunks:
        cid = str(chunk.get("chunk_id") or "")
        chunk["bm25_score"] = float(bm25_scores.get(cid, 0.0))
        chunk["dense_score"] = float(dense_scores.get(cid, 0.0))
        chunk["rrf_score"] = float(rrf.get(cid, 0.0))
        chunk["intent_bonus"] = _intent_bonus(chunk, detected_intents)
        chunk["score"] = chunk["score"] + chunk["intent_bonus"]

    ranked_chunks = sorted(
        scored_chunks,
        key=lambda chunk: (
            chunk["rrf_score"],
            chunk["score"],
            chunk["title_similarity"],
            -chunk["level"],
        ),
        reverse=True,
    )

    intent_ranked_chunks = _filter_chunks_for_intents(ranked_chunks, detected_intents, generated_profile)
    candidate_chunks = [
        chunk for chunk in intent_ranked_chunks
        if chunk["score"] > 0.02 or chunk["bm25_score"] > 0.0 or chunk["dense_score"] > 0.0
    ][: max(max_chunks * 4, 8)]
    reranked_chunks = _rerank_chunks(candidate_chunks, anchor_terms=anchor_terms, anchor_phrases=anchor_phrases)
    selected_chunks = _select_diverse_chunks(reranked_chunks, max_chunks=max_chunks)
    if not selected_chunks and intent_ranked_chunks:
        selected_chunks = intent_ranked_chunks[:1]

    details = _extract_grounding_details(selected_chunks)
    tool_contract = _choose_tool_contract(runtime_need, selected_chunks, tool_schemas)
    doc_binding = _build_doc_binding(
        tool_contract=tool_contract,
        selected_chunks=selected_chunks,
        details=details,
    )
    capability = " | ".join(chunk["path_text"] for chunk in selected_chunks) or "general product docs"
    retrieval_relevance, retrieval_notes = _retrieval_relevance_label(selected_chunks, anchor_terms)
    retrieved_doc_types, missing_doc_types, retrieval_quality = _retrieval_quality(
        selected_chunks=selected_chunks,
        detected_intents=detected_intents,
    )

    grounding_block = _grounding_block_text(
        capability=capability,
        tool_contract=tool_contract,
        doc_binding=doc_binding,
        required_params=details["required_params"],
        sequencing_rules=details["sequencing_rules"],
        limits_errors=details["limits_errors"],
        example=details["example"],
    )
    tool_guidance = _tool_guidance_block(tool_schemas)
    if tool_guidance:
        grounding_block = f"{grounding_block}\n\n{tool_guidance}"

    return {
        "runtime_need": runtime_need,
        "manifest": manifest,
        "retrieved_chunks": [
            {
                "chunk_id": chunk["chunk_id"],
                "title": chunk["title"],
                "anchor": chunk["anchor"],
                "path": chunk["path"],
                "path_text": chunk["path_text"],
                "preview": chunk["preview"],
                "score": chunk["score"],
                "semantic_similarity": chunk["semantic_similarity"],
                "specificity_bonus": chunk["specificity_bonus"],
                "complexity_penalty": chunk["complexity_penalty"],
                "error_alignment": chunk["error_alignment"],
                "anchor_bonus": chunk.get("anchor_bonus"),
                "anchor_overlap_count": chunk.get("anchor_overlap_count"),
                "phrase_bonus": chunk.get("phrase_bonus"),
                "preferred_path_bonus": chunk.get("preferred_path_bonus"),
                "intent_bonus": chunk.get("intent_bonus"),
                "bm25_score": chunk.get("bm25_score", 0.0),
                "dense_score": chunk.get("dense_score", 0.0),
                "rrf_score": chunk.get("rrf_score", 0.0),
                "doc_types": _chunk_doc_types(chunk),
                "rerank_score": chunk.get("rerank_score", chunk["score"]),
                "text": chunk["text"],
                "line_start": chunk.get("line_start"),
                "line_end": chunk.get("line_end"),
                "start_char": chunk.get("start_char"),
                "end_char": chunk.get("end_char"),
            }
            for chunk in selected_chunks
        ],
        "tool_contract": tool_contract,
        "doc_binding": doc_binding,
        "grounding_block": grounding_block,
        "retrieval_query": {
            "runtime_need": runtime_need,
            "query_terms": query_terms[:80],
            "anchor_terms": anchor_terms[:40],
            "anchor_phrases": anchor_phrases[:8],
            "detected_intents": detected_intents,
            "query_variants": extra_query_variants,
        },
        "retrieval_diagnostics": {
            "strategy": "hybrid-lexical-reranked",
            "detected_intents": detected_intents,
            "generated_profile": {
                "source": generated_profile.get("source"),
                "family_counts": generated_profile.get("family_counts"),
                "allowed_families": sorted(_allowed_families_for_intents(detected_intents) or []),
            },
            "retrieved_doc_types": retrieved_doc_types,
            "missing_doc_types": missing_doc_types,
            "retrieval_quality": retrieval_quality,
            "retrieval_relevance": retrieval_relevance,
            "retrieval_notes": retrieval_notes,
            "candidate_count": len(candidate_chunks),
            "selected_paths": [chunk["path_text"] for chunk in selected_chunks],
            "gauntlet_tool_guidance_included": bool(tool_guidance),
            "contextual_chunking_enabled": _contextual_chunking_module.is_enabled(),
            "query_rewriting_enabled": _query_rewriting_module.is_enabled(),
            "query_variant_count": 1 + len(extra_query_variants),
        },
    }


def render_manifest_for_prompt(manifest: Mapping[str, Any]) -> str:
    summary = "\n".join(f"- {line}" for line in manifest.get("summary_lines", []))
    outline = manifest.get("manifest_text", "")
    return (
        "llms.txt manifest:\n"
        f"Summary:\n{summary or '- No summary lines found'}\n"
        f"Outline:\n{outline or '- No sections found'}"
    )


async def load_doc_source(
    filename: str,
    source: str | None = None,
    fallback_url: str | None = None,
) -> tuple[str, str]:
    if source:
        explicit_path = Path(source).expanduser()
        if explicit_path.exists() and explicit_path.is_file():
            return explicit_path.read_text(encoding="utf-8"), str(explicit_path.resolve())
        if source.startswith(("http://", "https://")):
            return await _fetch_url(source)
        raise FileNotFoundError(f"Could not find explicit source for {filename}: {source}")
    return await load_doc(filename, fallback_url=fallback_url)


async def load_doc(filename: str, fallback_url: str | None = None) -> tuple[str, str]:
    local_doc = _find_local_doc(filename)
    if local_doc is not None:
        return local_doc
    if not fallback_url:
        raise FileNotFoundError(f"Could not find {filename} locally and no fallback URL was provided")

    return await _fetch_url(fallback_url)


async def load_llms_docs(
    llms_source: str | None = None,
    llms_full_source: str | None = None,
    llms_url: str | None = None,
    llms_full_url: str | None = None,
) -> dict[str, Any]:
    llms_text, llms_source_value = await load_doc_source(
        "llms.txt",
        source=llms_source,
        fallback_url=llms_url or os.getenv("LLMS_URL"),
    )
    llms_full_text, llms_full_source_value = await load_doc_source(
        "llms-full.txt",
        source=llms_full_source,
        fallback_url=llms_full_url or os.getenv("LLMS_FULL_URL"),
    )
    manifest = normalize_llms_manifest(llms_text)
    return {
        "llms_text": llms_text,
        "llms_source": llms_source_value,
        "llms_manifest": manifest,
        "llms_manifest_text": render_manifest_for_prompt(manifest),
        "llms_full_text": llms_full_text,
        "llms_full_source": llms_full_source_value,
    }


async def retrieve_runtime_doc_context(
    *,
    task: str | None = None,
    previous_output: str | None = None,
    current_error: str | None = None,
    next_goal: str | None = None,
    llms_source: str | None = None,
    llms_full_source: str | None = None,
    llms_url: str | None = None,
    llms_full_url: str | None = None,
    tool_schemas: Mapping[str, str] | None = None,
    retrieval_hints: Mapping[str, Any] | None = None,
    max_chunks: int = 3,
) -> dict[str, Any]:
    docs = await load_llms_docs(
        llms_source=llms_source,
        llms_full_source=llms_full_source,
        llms_url=llms_url,
        llms_full_url=llms_full_url,
    )
    grounding = build_runtime_doc_grounding(
        task=task,
        previous_output=previous_output,
        current_error=current_error,
        next_goal=next_goal,
        llms_text=docs["llms_text"],
        llms_full_text=docs["llms_full_text"],
        tool_schemas=tool_schemas,
        retrieval_hints=retrieval_hints,
        max_chunks=max_chunks,
    )
    return {
        "llms_source": docs["llms_source"],
        "llms_full_source": docs["llms_full_source"],
        "llms_manifest": docs["llms_manifest"],
        "grounding_block": grounding["grounding_block"],
        "runtime_need": grounding["runtime_need"],
        "retrieved_chunks": grounding["retrieved_chunks"],
        "tool_contract": grounding["tool_contract"],
        "doc_binding": grounding["doc_binding"],
        "llms_manifest_text": docs["llms_manifest_text"],
        "llms_manifest_json": json.dumps(docs["llms_manifest"], ensure_ascii=True, indent=2),
    }
