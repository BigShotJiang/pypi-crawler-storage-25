from __future__ import annotations

import sys
from collections.abc import Awaitable, Callable
from typing import Any, Mapping

from gauntlet.layer1.llms_docs import (
    load_doc,
    load_environment,
    load_llms_docs,
    retrieve_runtime_doc_context,
)
from gauntlet.layer1.utility import http_request, invoke_python_sdk, run_cli_command, run_python_code
from gauntlet.layer1.utility import credential_status, environment_metadata


load_environment()


def _success_result(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": True,
        "error_type": None,
        "error": None,
        **payload,
    }


def _error_result(
    error: Exception,
    payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    message = str(error).strip() or repr(error)
    return {
        "ok": False,
        "error_type": type(error).__name__,
        "error": message,
        **dict(payload or {}),
    }


async def _wrap_async_tool(
    fn: Callable[[], Awaitable[dict[str, Any]]],
    *,
    error_payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    try:
        return _success_result(await fn())
    except Exception as error:
        return _error_result(error, payload=error_payload)


def _wrap_sync_tool(
    fn: Callable[[], dict[str, Any]],
    *,
    error_payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    try:
        return _success_result(fn())
    except Exception as error:
        return _error_result(error, payload=error_payload)


def _finalize_process_result(result: dict[str, Any]) -> dict[str, Any]:
    if result.get("ok") is False and result.get("exit_code") is None:
        return result

    exit_code = result.get("exit_code")
    if exit_code == 0:
        return result
    return {
        **result,
        "ok": False,
        "error_type": "CommandExitCode",
        "error": f"Command exited with code {exit_code}",
    }


def _finalize_http_result(result: dict[str, Any]) -> dict[str, Any]:
    status = result.get("status")
    if not isinstance(status, int) or status < 400:
        return result
    return {
        **result,
        "ok": False,
        "error_type": "HTTPStatusError",
        "error": f"HTTP request returned status {status}",
    }


async def read_docs(
    llms_source: str | None = None,
    llms_full_source: str | None = None,
    llms_url: str | None = None,
    llms_full_url: str | None = None,
) -> dict[str, Any]:
    return await _wrap_async_tool(
        lambda: load_llms_docs(
            llms_source=llms_source,
            llms_full_source=llms_full_source,
            llms_url=llms_url,
            llms_full_url=llms_full_url,
        ),
        error_payload={
            "llms_text": "",
            "llms_source": llms_source or llms_url or "",
            "llms_manifest": {},
            "llms_manifest_text": "",
            "llms_full_text": "",
            "llms_full_source": llms_full_source or llms_full_url or "",
        },
    )


async def read_doc(
    filename: str,
    fallback_url: str | None = None,
) -> dict[str, Any]:
    async def _run() -> dict[str, Any]:
        if isinstance(filename, str) and filename.lower().startswith(("http://", "https://")):
            raise ValueError("read_doc only accepts local documentation paths. For URLs, use fallback_url or ground_docs.")
        text, source = await load_doc(filename, fallback_url=fallback_url)
        return {
            "filename": filename,
            "text": text,
            "source": source,
        }

    return await _wrap_async_tool(
        _run,
        error_payload={
            "filename": filename,
            "text": "",
            "source": fallback_url or "",
        },
    )


async def ground_docs(
    task: str | None = None,
    previous_output: str | None = None,
    current_error: str | None = None,
    next_goal: str | None = None,
    llms_source: str | None = None,
    llms_full_source: str | None = None,
    llms_url: str | None = None,
    llms_full_url: str | None = None,
    tool_schemas: Mapping[str, str] | None = None,
    max_chunks: int = 3,
) -> dict[str, Any]:
    return await _wrap_async_tool(
        lambda: retrieve_runtime_doc_context(
            task=task,
            previous_output=previous_output,
            current_error=current_error,
            next_goal=next_goal,
            llms_source=llms_source,
            llms_full_source=llms_full_source,
            llms_url=llms_url,
            llms_full_url=llms_full_url,
            tool_schemas=tool_schemas,
            max_chunks=max_chunks,
        ),
        error_payload={
            "llms_source": llms_source or llms_url or "",
            "llms_full_source": llms_full_source or llms_full_url or "",
            "llms_manifest": {},
            "grounding_block": "",
            "runtime_need": "",
            "retrieved_chunks": [],
            "tool_contract": None,
            "doc_binding": None,
            "llms_manifest_text": "",
            "llms_manifest_json": "{}",
        },
    )


async def run_http(
    method: str,
    url: str,
    body: Any | None = None,
    headers: Mapping[str, str] | None = None,
    headers_from_env: Mapping[str, str] | None = None,
    query: Mapping[str, str | int | float | bool] | None = None,
    timeout_seconds: int = 90,
    docs_text: str | None = None,
    app_name: str | None = None,
) -> dict[str, Any]:
    return _finalize_http_result(
        await _wrap_async_tool(
            lambda: http_request(
                method=method,
                url=url,
                body=body,
                headers=headers,
                headers_from_env=headers_from_env,
                query=query,
                timeout_seconds=timeout_seconds,
                docs_text=docs_text,
                app_name=app_name,
            ),
            error_payload={
                "status": None,
                "url": url,
                "headers": {},
                "body": None,
                "request_headers": dict(headers or {}),
                "headers_from_env": dict(headers_from_env or {}),
                "matched_env_vars": {},
                "candidate_headers": [],
            },
        )
    )


def run_cli(
    command: list[str] | str,
    cwd: str | None = None,
    env: Mapping[str, str] | None = None,
    timeout_seconds: int = 120,
    shell: bool = False,
) -> dict[str, Any]:
    return _finalize_process_result(
        _wrap_sync_tool(
            lambda: run_cli_command(
                command=command,
                cwd=cwd,
                env=env,
                timeout_seconds=timeout_seconds,
                shell=shell,
            ),
            error_payload={
                "command": command,
                "shell": shell,
                "cwd": cwd,
                "exit_code": None,
                "stdout": "",
                "stderr": "",
            },
        )
    )


def run_sdk(
    factory_import_path: str,
    method_path: str | None = None,
    factory_args: list[Any] | None = None,
    factory_kwargs: Mapping[str, Any] | None = None,
    method_args: list[Any] | None = None,
    method_kwargs: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return _wrap_sync_tool(
        lambda: invoke_python_sdk(
            factory_import_path=factory_import_path,
            method_path=method_path,
            factory_args=factory_args,
            factory_kwargs=factory_kwargs,
            method_args=method_args,
            method_kwargs=method_kwargs,
        ),
        error_payload={
            "factory_import_path": factory_import_path,
            "method_path": method_path,
            "result": None,
        },
    )


def run_python(
    code: str,
    cwd: str | None = None,
    env: Mapping[str, str] | None = None,
    timeout_seconds: int = 120,
    stdin_text: str | None = None,
) -> dict[str, Any]:
    return _finalize_process_result(
        _wrap_sync_tool(
            lambda: run_python_code(
                code=code,
                cwd=cwd,
                env=env,
                timeout_seconds=timeout_seconds,
                stdin_text=stdin_text,
            ),
            error_payload={
                "command": [sys.executable, "-c", code],
                "cwd": cwd,
                "exit_code": None,
                "stdout": "",
                "stderr": "",
            },
        )
    )


def check_credentials(names: list[str] | None = None) -> dict[str, Any]:
    return _wrap_sync_tool(lambda: {"credentials": credential_status(names)})


def inspect_environment() -> dict[str, Any]:
    return _wrap_sync_tool(lambda: environment_metadata())
