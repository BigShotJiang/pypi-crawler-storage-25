"""Dense-embedding index for retrieval.

Provider-agnostic: picks OpenAI text-embedding-3-large if OPENAI_API_KEY is
set, otherwise Gemini text-embedding-004 if GEMINI_API_KEY is set. Fails
soft when neither is available so the retriever degrades to BM25+TF-IDF.

Embeddings are persisted to a numpy file keyed by (model, corpus content
hash) so re-runs are free.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Iterable, Sequence

import httpx

try:
    import numpy as np

    _NUMPY_AVAILABLE = True
except ImportError:  # pragma: no cover
    np = None  # type: ignore[assignment]
    _NUMPY_AVAILABLE = False


OPENAI_MODEL = "text-embedding-3-large"
GEMINI_MODEL = "gemini-embedding-001"
DEFAULT_BATCH = 96

_OPENAI_URL = "https://api.openai.com/v1/embeddings"
_GEMINI_URL_TMPL = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:embedContent?key={key}"
)


def _clean_key(name: str) -> str:
    raw = os.getenv(name, "")
    if not raw:
        return ""
    return raw.strip().split()[0] if raw.strip() else ""


def _provider() -> str | None:
    if _clean_key("OPENAI_API_KEY"):
        return "openai"
    if _clean_key("GEMINI_API_KEY"):
        return "gemini"
    return None


def active_model() -> str | None:
    provider = _provider()
    if provider == "openai":
        return OPENAI_MODEL
    if provider == "gemini":
        return GEMINI_MODEL
    return None


def is_available() -> bool:
    return _NUMPY_AVAILABLE and _provider() is not None


def _content_hash(items: Sequence[str], model: str) -> str:
    h = hashlib.sha256()
    h.update(model.encode("utf-8"))
    h.update(b"\x00")
    for item in items:
        h.update(item.encode("utf-8", errors="replace"))
        h.update(b"\x00")
    return h.hexdigest()


def _embed_batch_openai(texts: list[str], *, api_key: str, timeout: float) -> list[list[float]]:
    payload = {"model": OPENAI_MODEL, "input": texts}
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    with httpx.Client(timeout=timeout) as client:
        response = client.post(_OPENAI_URL, json=payload, headers=headers)
        response.raise_for_status()
        body = response.json()
    return [item["embedding"] for item in body["data"]]


def _embed_batch_gemini(texts: list[str], *, api_key: str, timeout: float) -> list[list[float]]:
    """gemini-embedding-001 does not expose batchEmbedContents on the v1beta
    HTTP API for free-tier keys, so we make one embedContent call per text.
    Results are cached on disk so the indexing pass only runs once per
    corpus version."""
    url = _GEMINI_URL_TMPL.format(model=GEMINI_MODEL, key=api_key)
    headers = {"Content-Type": "application/json"}
    vectors: list[list[float]] = []
    with httpx.Client(timeout=timeout) as client:
        for text in texts:
            payload = {
                "model": f"models/{GEMINI_MODEL}",
                "content": {"parts": [{"text": text}]},
                "outputDimensionality": 768,
            }
            response = client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            body = response.json()
            vectors.append(body["embedding"]["values"])
    return vectors


def embed_texts(
    texts: Iterable[str],
    *,
    batch_size: int = DEFAULT_BATCH,
    timeout: float = 60.0,
) -> "np.ndarray":  # type: ignore[name-defined]
    if not _NUMPY_AVAILABLE:
        raise RuntimeError("numpy is required for dense embeddings")
    provider = _provider()
    if provider is None:
        raise RuntimeError("No embedding provider key found (OPENAI_API_KEY or GEMINI_API_KEY)")

    text_list = [t if t else " " for t in texts]
    if not text_list:
        return np.zeros((0, 0), dtype=np.float32)

    if provider == "gemini":
        batch_size = min(batch_size, 100)

    api_key = _clean_key("OPENAI_API_KEY") if provider == "openai" else _clean_key("GEMINI_API_KEY")
    assert api_key

    vectors: list[list[float]] = []
    for i in range(0, len(text_list), batch_size):
        batch = text_list[i : i + batch_size]
        attempts = 0
        while True:
            try:
                if provider == "openai":
                    vectors.extend(_embed_batch_openai(batch, api_key=api_key, timeout=timeout))
                else:
                    vectors.extend(_embed_batch_gemini(batch, api_key=api_key, timeout=timeout))
                break
            except httpx.HTTPError as exc:
                attempts += 1
                if attempts >= 3:
                    raise RuntimeError(f"Embedding request failed after retries: {exc}") from exc
                time.sleep(0.5 * attempts)

    arr = np.asarray(vectors, dtype=np.float32)
    if arr.size == 0:
        return arr
    norms = np.linalg.norm(arr, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return arr / norms


def load_or_build_index(
    *,
    chunk_ids: list[str],
    chunk_texts: list[str],
    cache_path: Path,
) -> tuple["np.ndarray", list[str]] | None:  # type: ignore[name-defined]
    if not _NUMPY_AVAILABLE:
        return None
    model = active_model()
    if model is None:
        return None
    fingerprint = _content_hash(chunk_texts, model)

    if cache_path.exists():
        try:
            payload = np.load(cache_path, allow_pickle=False)
            cached_hash = bytes(payload["fingerprint"]).decode("ascii")
            if cached_hash == fingerprint:
                matrix = payload["matrix"]
                cached_ids = json.loads(bytes(payload["chunk_ids"]).decode("utf-8"))
                if cached_ids == chunk_ids:
                    return matrix, cached_ids
        except (KeyError, ValueError, OSError):
            pass

    try:
        matrix = embed_texts(chunk_texts)
    except Exception:  # noqa: BLE001 -- soft failure
        return None

    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        cache_path,
        matrix=matrix,
        chunk_ids=np.frombuffer(json.dumps(chunk_ids).encode("utf-8"), dtype=np.uint8),
        fingerprint=np.frombuffer(fingerprint.encode("ascii"), dtype=np.uint8),
    )
    return matrix, chunk_ids


def dense_scores(
    *,
    query_text: str,
    matrix: "np.ndarray",  # type: ignore[name-defined]
    chunk_ids: list[str],
) -> dict[str, float]:
    if not _NUMPY_AVAILABLE or matrix is None or matrix.size == 0:
        return {}
    try:
        query_vec = embed_texts([query_text])
    except Exception:  # noqa: BLE001
        return {}
    if query_vec.size == 0:
        return {}
    q = query_vec[0]
    sims = matrix @ q
    return {chunk_id: float(sims[idx]) for idx, chunk_id in enumerate(chunk_ids)}
