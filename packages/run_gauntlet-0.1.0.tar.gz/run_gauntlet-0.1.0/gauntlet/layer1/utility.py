from __future__ import annotations

import asyncio
import importlib
import inspect
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import date, datetime, time
from pathlib import Path
from typing import Any, Mapping

import httpx

from gauntlet.layer1.llms_docs import load_environment


@dataclass(slots=True)
class HeaderInference:
    headers: dict[str, str]
    matched_env_vars: dict[str, str]
    candidate_headers: list[str]


def _normalize_app_name(app_name: str | None) -> str:
    return (app_name or "").strip().upper().replace("-", "_").replace(" ", "_")


def _dedupe_keep_order(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def _header_candidates_from_docs(text: str) -> list[str]:
    candidates: list[str] = []

    backticked = re.findall(r"`([A-Za-z][A-Za-z0-9-]*(?:auth|token|key)[A-Za-z0-9-]*)`", text, flags=re.I)
    candidates.extend(backticked)

    header_lines = re.findall(
        r"(?im)^\s*([A-Za-z][A-Za-z0-9-]*(?:auth|token|key)[A-Za-z0-9-]*)\s*:",
        text,
    )
    candidates.extend(header_lines)

    if re.search(r"authorization\s*:\s*bearer", text, flags=re.I):
        candidates.append("Authorization")
    if re.search(r"\bbearer\b", text, flags=re.I) and "Authorization" not in candidates:
        candidates.append("Authorization")

    return _dedupe_keep_order(candidates)


def _env_candidates_from_docs(text: str, app_name: str | None) -> list[str]:
    candidates = re.findall(
        r"\b([A-Z][A-Z0-9_]*(?:API_KEY|ACCESS_TOKEN|AUTH_TOKEN|TOKEN|SECRET|KEY))\b",
        text,
    )

    prefix = _normalize_app_name(app_name)
    if prefix:
        candidates.extend(
            [
                f"{prefix}_API_KEY",
                f"{prefix}_ACCESS_TOKEN",
                f"{prefix}_AUTH_TOKEN",
                f"{prefix}_TOKEN",
                f"{prefix}_SECRET",
                f"{prefix}_KEY",
            ]
        )

    candidates.extend(
        [
            "API_KEY",
            "ACCESS_TOKEN",
            "AUTH_TOKEN",
            "TOKEN",
        ]
    )
    return _dedupe_keep_order(candidates)


def _pick_env_var(
    header_name: str,
    env_candidates: list[str],
    env: Mapping[str, str],
) -> tuple[str | None, str | None]:
    lowered = header_name.lower()

    prioritized = env_candidates[:]
    if lowered == "authorization":
        prioritized = sorted(
            env_candidates,
            key=lambda name: (
                0 if "TOKEN" in name else 1,
                0 if "ACCESS" in name or "AUTH" in name else 1,
                env_candidates.index(name),
            ),
        )
    elif "api-key" in lowered or lowered.endswith("api-key") or lowered.endswith("api_key"):
        prioritized = sorted(
            env_candidates,
            key=lambda name: (0 if "API_KEY" in name else 1, env_candidates.index(name)),
        )

    for name in prioritized:
        value = env.get(name)
        if value:
            return name, value
    return None, None


def infer_auth_headers(
    docs_text: str | None = None,
    app_name: str | None = None,
    explicit_headers: Mapping[str, str] | None = None,
    env: Mapping[str, str] | None = None,
) -> HeaderInference:
    env_values = dict(os.environ if env is None else env)
    headers = dict(explicit_headers or {})
    matched_env_vars: dict[str, str] = {}
    combined_docs_text = docs_text or ""

    candidate_headers = _header_candidates_from_docs(combined_docs_text)
    env_candidates = _env_candidates_from_docs(combined_docs_text, app_name=app_name)

    for header_name in candidate_headers:
        if header_name in headers:
            continue
        env_name, env_value = _pick_env_var(header_name, env_candidates, env_values)
        if not env_value:
            continue
        if header_name.lower() == "authorization":
            headers[header_name] = f"Bearer {env_value}"
        else:
            headers[header_name] = env_value
        matched_env_vars[header_name] = env_name

    return HeaderInference(
        headers=headers,
        matched_env_vars=matched_env_vars,
        candidate_headers=candidate_headers,
    )


def _normalize_body(body: Any) -> tuple[Any | None, bytes | str | None]:
    if body is None:
        return None, None
    if isinstance(body, (dict, list, int, float, bool)):
        return body, None
    if isinstance(body, str):
        try:
            return json.loads(body), None
        except json.JSONDecodeError:
            return None, body
    return None, str(body)


def _is_placeholder_env_value(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    stripped = value.strip()
    if not stripped:
        return False

    upper = stripped.upper()
    return (
        upper.startswith("YOUR_")
        or upper.endswith("_HERE")
        or stripped.startswith("${")
        or bool(re.fullmatch(r"\$[A-Za-z_][A-Za-z0-9_]*", stripped))
        or ("API_KEY" in upper and "YOUR" in upper)
    )


def _merge_process_env(env: Mapping[str, str] | None = None, *, cwd: str | None = None) -> dict[str, str]:
    merged_env = _apply_project_node_path(os.environ.copy(), cwd=cwd)
    if not env:
        return merged_env

    for key, value in env.items():
        if _is_placeholder_env_value(value):
            continue
        merged_env[key] = str(value)
    return merged_env


async def http_request(
    method: str,
    url: str,
    body: Any | None = None,
    headers: Mapping[str, str] | None = None,
    headers_from_env: Mapping[str, str] | None = None,
    query: Mapping[str, str | int | float | bool] | None = None,
    timeout_seconds: int = 90,
    docs_text: str | None = None,
    app_name: str | None = None,
) -> dict[str, Any]:
    explicit_headers = dict(headers or {})
    for header_name, env_name in dict(headers_from_env or {}).items():
        env_value = os.getenv(str(env_name))
        if not env_value:
            raise ValueError(f"Environment variable {env_name!r} for header {header_name!r} is not set.")
        explicit_headers[str(header_name)] = env_value

    inference = infer_auth_headers(
        docs_text=docs_text,
        app_name=app_name,
        explicit_headers=explicit_headers,
    )
    json_body, raw_body = _normalize_body(body)

    async with httpx.AsyncClient(timeout=timeout_seconds, follow_redirects=True) as client:
        response = await client.request(
            method=method.upper(),
            url=url,
            params=query,
            headers=inference.headers,
            json=json_body,
            content=raw_body,
        )

    content_type = response.headers.get("content-type", "")
    try:
        parsed_body = response.json() if "json" in content_type else response.text
    except ValueError:
        parsed_body = response.text

    return {
        "status": response.status_code,
        "url": str(response.url),
        "headers": dict(response.headers),
        "body": parsed_body,
        "request_headers": inference.headers,
        "matched_env_vars": inference.matched_env_vars,
        "candidate_headers": inference.candidate_headers,
    }


COMMON_CREDENTIAL_NAMES = (
    "STEEL_API_KEY",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
)


def credential_status(names: list[str] | tuple[str, ...] | None = None) -> dict[str, str]:
    return {
        name: "present" if os.getenv(name) else "missing"
        for name in (names or COMMON_CREDENTIAL_NAMES)
    }


def _find_upward(start: Path, filename: str) -> Path | None:
    current = start.expanduser().resolve()
    if current.is_file():
        current = current.parent
    for candidate_dir in (current, *current.parents):
        candidate = candidate_dir / filename
        if candidate.exists():
            return candidate
    return None


def _project_node_bin(start: str | Path | None = None) -> str | None:
    start_path = Path(start).expanduser() if start else Path.cwd()
    nvmrc = _find_upward(start_path, ".nvmrc")
    if nvmrc is None:
        return None
    requested = nvmrc.read_text(encoding="utf-8").strip().lstrip("v")
    if not requested:
        return None

    nvm_dir = Path(os.getenv("NVM_DIR") or Path.home() / ".nvm").expanduser()
    versions_dir = nvm_dir / "versions" / "node"
    if not versions_dir.exists():
        return None

    candidates = sorted(
        child
        for child in versions_dir.iterdir()
        if child.is_dir() and child.name.lstrip("v").startswith(requested)
    )
    if not candidates:
        return None
    node_bin = candidates[-1] / "bin"
    return str(node_bin) if (node_bin / "node").exists() else None


def _apply_project_node_path(env: dict[str, str], *, cwd: str | None = None) -> dict[str, str]:
    node_bin = _project_node_bin(cwd or Path.cwd())
    if not node_bin:
        return env
    path = env.get("PATH", "")
    path_parts = [part for part in path.split(os.pathsep) if part]
    env["PATH"] = os.pathsep.join([node_bin, *[part for part in path_parts if part != node_bin]])
    return env


def environment_metadata() -> dict[str, Any]:
    def _version(command: list[str]) -> str | None:
        command_env = _merge_process_env()
        executable = shutil.which(command[0], path=command_env.get("PATH"))
        if executable is None:
            return None
        try:
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
                env=command_env,
            )
        except Exception:
            return None
        output = (completed.stdout or completed.stderr).strip()
        return output.splitlines()[0] if output else None

    python_packages: dict[str, str] = {}
    for package_name, import_name in (
        ("requests", "requests"),
        ("beautifulsoup4", "bs4"),
        ("playwright", "playwright"),
    ):
        try:
            module = importlib.import_module(import_name)
        except Exception:
            python_packages[package_name] = "missing"
            continue
        version = getattr(module, "__version__", None)
        python_packages[package_name] = str(version) if version else "present"

    playwright_cache = Path.home() / "Library" / "Caches" / "ms-playwright"
    if not playwright_cache.exists():
        playwright_cache = Path.home() / ".cache" / "ms-playwright"
    playwright_browsers = sorted(child.name for child in playwright_cache.iterdir()) if playwright_cache.exists() else []

    node_version = _version(["node", "--version"])
    node_major: int | None = None
    if node_version:
        match = re.search(r"v?(\d+)", node_version)
        if match:
            node_major = int(match.group(1))

    return {
        "platform": platform.platform(),
        "os": platform.system(),
        "machine": platform.machine(),
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "node_version": node_version,
        "node_path": shutil.which("node", path=_merge_process_env().get("PATH")),
        "node_major": node_major,
        "node_20_lts_or_newer": bool(node_major is not None and node_major >= 20),
        "npm_version": _version(["npm", "--version"]),
        "npm_path": shutil.which("npm", path=_merge_process_env().get("PATH")),
        "python_packages": python_packages,
        "playwright_browsers": playwright_browsers,
        "credentials": credential_status(),
    }


def _command_contains_shell_variable(command: list[str] | str) -> bool:
    text = command if isinstance(command, str) else " ".join(command)
    return bool(re.search(r"\$[A-Za-z_][A-Za-z0-9_]*|\$\{[A-Za-z_][A-Za-z0-9_]*\}", text))


def _command_requires_shell(command: str) -> bool:
    return bool(re.search(r"[|&;<>`$]", command))


def run_cli_command(
    command: list[str] | str,
    cwd: str | None = None,
    env: Mapping[str, str] | None = None,
    timeout_seconds: int = 120,
    shell: bool = False,
    stdin_text: str | None = None,
) -> dict[str, Any]:
    merged_env = _merge_process_env(env, cwd=cwd)
    if shell:
        rewritten_command: list[str] | str = command if isinstance(command, str) else " ".join(command)
    else:
        if isinstance(command, str):
            if _command_requires_shell(command):
                raise ValueError(
                    "run_cli command strings with shell syntax require shell=true. "
                    'Valid formats: command=["steel", "scrape", "https://example.com"] '
                    'or command="steel scrape https://example.com", shell=true.'
                )
            try:
                rewritten_command = shlex.split(command)
            except ValueError as exc:
                raise ValueError(
                    "run_cli command must be a list of strings, or a shell command string with shell=true. "
                    'Valid formats: command=["steel", "scrape", "https://example.com"] '
                    'or command="steel scrape https://example.com", shell=true.'
                ) from exc
            if not rewritten_command:
                raise ValueError(
                    "run_cli command cannot be empty. "
                    'Valid formats: command=["steel", "scrape", "https://example.com"] '
                    'or command="steel scrape https://example.com", shell=true.'
                )
            rewritten_command = _normalize_python_command(rewritten_command)
            warnings = ["Split string command with shlex because shell=false. Use command=[...] for deterministic argument boundaries."]
        else:
            warnings = []
            rewritten_command = _normalize_python_command(command)

    if shell:
        warnings = []
    if not shell and _command_contains_shell_variable(command):
        warnings.append("Command contains $VAR syntax but shell=false, so environment variables will not be expanded. Use shell=true for shell expansion.")

    completed = subprocess.run(
        rewritten_command,
        cwd=cwd,
        env=merged_env,
        capture_output=True,
        text=True,
        input=stdin_text,
        timeout=timeout_seconds,
        check=False,
        shell=shell,
    )
    return {
        "command": rewritten_command,
        "shell": shell,
        "warnings": warnings,
        "cwd": cwd or str(Path.cwd()),
        "exit_code": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def _serialize_sdk_result(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(key): _serialize_sdk_result(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_serialize_sdk_result(item) for item in value]
    if hasattr(value, "model_dump") and callable(value.model_dump):
        return _serialize_sdk_result(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _serialize_sdk_result(value.dict())
    if hasattr(value, "__dataclass_fields__"):
        return _serialize_sdk_result(asdict(value))
    if hasattr(value, "__dict__"):
        return {
            key: _serialize_sdk_result(val)
            for key, val in vars(value).items()
            if not key.startswith("_")
        }
    return repr(value)


def _resolve_dotted_attr(root: Any, dotted_path: str) -> Any:
    current = root
    for part in dotted_path.split("."):
        try:
            current = getattr(current, part)
        except AttributeError as error:
            current_type = type(current).__name__
            raise AttributeError(
                f"Method path segment {part!r} was not found on object of type {current_type}"
            ) from error
    return current


def _normalize_sdk_method_path(method_path: str | None, symbol_name: str, target: Any) -> str | None:
    if method_path is None:
        return None

    normalized = method_path.strip()
    if not normalized:
        raise ValueError("method_path must not be empty when provided")

    path_parts = normalized.split(".")
    if any(not part for part in path_parts):
        raise ValueError(f"method_path must not contain empty path segments, got {method_path!r}")

    # Agents sometimes pass a redundant constructor/class prefix, e.g.
    # factory_import_path=module:Client plus method_path=Client.fetch or
    # Client().fetch. Once the factory is instantiated, attribute resolution
    # should run against the instance, not re-mention the factory symbol.
    redundant_prefixes = {
        symbol_name,
        type(target).__name__,
        f"{symbol_name}()",
        f"{type(target).__name__}()",
    }
    if len(path_parts) > 1 and path_parts[0] in redundant_prefixes:
        normalized = ".".join(path_parts[1:])

    return normalized


def invoke_python_sdk(
    factory_import_path: str,
    method_path: str | None = None,
    factory_args: list[Any] | None = None,
    factory_kwargs: Mapping[str, Any] | None = None,
    method_args: list[Any] | None = None,
    method_kwargs: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    if factory_import_path == "steel":
        factory_import_path = "steel:Steel"
    elif ":" not in factory_import_path and "." in factory_import_path:
        module_path, _, symbol_name = factory_import_path.rpartition(".")
        if module_path and symbol_name:
            factory_import_path = f"{module_path}:{symbol_name}"

    if ":" not in factory_import_path:
        raise ValueError(
            f"factory_import_path must be in 'module:symbol' format, got {factory_import_path!r}"
        )

    module_path, symbol_name = factory_import_path.split(":", 1)
    if not module_path or not symbol_name:
        raise ValueError(
            f"factory_import_path must be in 'module:symbol' format, got {factory_import_path!r}"
        )

    try:
        module = importlib.import_module(module_path)
    except ImportError as error:
        raise ImportError(
            f"Could not import module {module_path!r} from factory_import_path {factory_import_path!r}"
        ) from error

    try:
        factory = getattr(module, symbol_name)
    except AttributeError as error:
        raise AttributeError(
            f"Could not import symbol {symbol_name!r} from module {module_path!r}"
        ) from error

    try:
        instance_or_result = factory(*(factory_args or []), **dict(factory_kwargs or {}))
    except Exception as error:
        message = f"Factory call {factory_import_path!r} failed: {error}"
        raise RuntimeError(message) from error

    original_method_path = method_path
    method_path = _normalize_sdk_method_path(method_path, symbol_name, instance_or_result)

    if method_path:
        try:
            target = _resolve_dotted_attr(instance_or_result, method_path)
        except AttributeError as error:
            raise AttributeError(
                f"Method path {method_path!r} not found on object returned by {factory_import_path!r}: {error}"
            ) from error
    else:
        target = instance_or_result

    has_call_arguments = bool(method_args or method_kwargs)
    if has_call_arguments and not callable(target):
        target_type = type(target).__name__
        raise TypeError(
            f"Resolved target for method_path {method_path!r} is not callable; got object of type {target_type}"
        )

    try:
        result = target(*(method_args or []), **dict(method_kwargs or {})) if callable(target) else target
    except Exception as error:
        target_label = method_path or factory_import_path
        raise RuntimeError(f"Invocation of {target_label!r} failed: {error}") from error

    if inspect.isawaitable(result):
        try:
            result = asyncio.run(result)
        except Exception as error:
            target_label = method_path or factory_import_path
            raise RuntimeError(f"Awaiting result from {target_label!r} failed: {error}") from error

    payload = {
        "factory_import_path": factory_import_path,
        "method_path": method_path,
        "target_type": type(target).__name__,
        "result": _serialize_sdk_result(result),
    }
    if original_method_path != method_path:
        payload["normalized_method_path_from"] = original_method_path
        payload["normalized_method_path_to"] = method_path
    return payload


def run_python_code(
    code: str,
    cwd: str | None = None,
    env: Mapping[str, str] | None = None,
    timeout_seconds: int = 120,
    stdin_text: str | None = None,
) -> dict[str, Any]:
    return run_cli_command(
        command=[sys.executable, "-c", code],
        cwd=cwd,
        env=env,
        timeout_seconds=timeout_seconds,
        shell=False,
        stdin_text=stdin_text,
    )


def _normalize_python_command(command: list[str]) -> list[str]:
    if not command:
        return command

    current_python = sys.executable
    first = command[0]

    if first in {"pip", "pip3"}:
        return [current_python, "-m", "pip", *command[1:]]

    if first in {"python", "python3"}:
        return [current_python, *command[1:]]

    if first.endswith("/python") or first.endswith("/python3") or first.endswith("/python3.14"):
        return [current_python, *command[1:]]

    return command
