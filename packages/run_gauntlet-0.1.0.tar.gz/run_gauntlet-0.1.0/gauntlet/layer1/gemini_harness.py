from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from gauntlet.layer1 import agent_tools
from gauntlet.layer1.llms_docs import load_environment
from gauntlet.providers import ProviderConfig, ProviderError, send_prompt


TEST_PROMPTS = [
    
    "Go to espncricinfo and tell me latest IPL game's score use only the steel-sdk to do this nothing else",
    "Go to espncricinfo.com and scrape the page only using the sdk version of steel not CLI or HTTP",
]

DEFAULT_LLMS_URL = "https://docs.steel.dev/llms.txt"
DEFAULT_LLMS_FULL_URL = "https://docs.steel.dev/llms-full.txt"

TOOL_DESCRIPTIONS = {
    "read_docs": "Load llms.txt and llms-full.txt sources, and return llms.txt plus a normalized manifest. Arguments: llms_source?, llms_full_source?, llms_url?, llms_full_url?.",
    "read_doc": "Load a single documentation file. Arguments: filename, fallback_url?.",
    "ground_docs": "Retrieve targeted runtime grounding from llms-full.txt using the current task, prior output, current error, and next goal. Arguments: task?, previous_output?, current_error?, next_goal?, llms_source?, llms_full_source?, llms_url?, llms_full_url?, tool_schemas?, max_chunks?.",
    "run_http": "Make an HTTP request. Arguments: method, url, body?, headers?, query?, timeout_seconds?, docs_text?, app_name?.",
    "run_cli": "Run a CLI command. Arguments: command (list of strings), cwd?, env?, timeout_seconds?.",
    "run_sdk": "Import a Python SDK factory and invoke a method directly. Best when docs specify a concrete SDK method or factory/method path. Arguments: factory_import_path, method_path?, factory_args?, factory_kwargs?, method_args?, method_kwargs?.",
    "run_python": "Execute Python code in a subprocess. This may also be used for SDK work when you need a longer script, multiple SDK calls, control flow, or imports that do not fit a single run_sdk invocation. Arguments: code, cwd?, env?, timeout_seconds?.",
}

SYSTEM_INSTRUCTIONS = """You are a simple tool-using agent.

Available tools:
{tool_descriptions}

Rules:
- You may call at most one tool at a time.
- Start from the provided llms.txt manifest when product docs are relevant.
- Call ground_docs when you need targeted llms-full.txt context for the next step.
- For Python SDK tasks, either `run_sdk` or `run_python` may be valid. Prefer `run_sdk` for a single direct SDK method call, and use `run_python` when the SDK workflow needs a fuller script.
- Inspect tool results carefully. If ok is false, adapt or explain the limitation.
- Never claim a screenshot, browser interaction, or scraped result unless a tool actually produced it.
- Respond in JSON only.
- Tool call format:
  {{"type":"tool_call","tool":"run_http","arguments":{{"method":"GET","url":"https://example.com"}}}}
- Final answer format:
  {{"type":"final","response":"your final answer"}}
"""

FORMAT_REPAIR_INSTRUCTION = """Your previous response was invalid because it did not contain exactly one JSON object in the required format.
Reply again with JSON only and no surrounding text."""


@dataclass(frozen=True)
class HarnessConfig:
    provider: ProviderConfig
    output_dir: Path
    max_steps: int = 8
    max_format_retries: int = 1
    llms_source: str | None = None
    llms_full_source: str | None = None
    llms_url: str | None = DEFAULT_LLMS_URL
    llms_full_url: str | None = DEFAULT_LLMS_FULL_URL


def _tool_descriptions_text() -> str:
    return "\n".join(f"- {name}: {description}" for name, description in TOOL_DESCRIPTIONS.items())


def _extract_json_block(text: str) -> dict[str, Any]:
    candidate = text.strip()
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 3:
            candidate = "\n".join(lines[1:-1]).strip()
    start = candidate.find("{")
    end = candidate.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ProviderError("Agent response did not contain JSON")
    try:
        parsed = json.loads(candidate[start : end + 1])
    except json.JSONDecodeError as exc:
        raise ProviderError(f"Agent returned invalid JSON: {candidate}") from exc
    if isinstance(parsed, dict) and parsed.get("type") == "tool_code":
        parsed = dict(parsed)
        parsed["type"] = "tool_call"
    return parsed


def _call_tool(tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    if tool_name == "read_docs":
        return asyncio.run(agent_tools.read_docs(**arguments))
    if tool_name == "read_doc":
        return asyncio.run(agent_tools.read_doc(**arguments))
    if tool_name == "ground_docs":
        grounded_arguments = dict(arguments)
        grounded_arguments.setdefault("tool_schemas", TOOL_DESCRIPTIONS)
        return asyncio.run(agent_tools.ground_docs(**grounded_arguments))
    if tool_name == "run_http":
        return asyncio.run(agent_tools.run_http(**arguments))
    if tool_name == "run_cli":
        return agent_tools.run_cli(**arguments)
    if tool_name == "run_sdk":
        return agent_tools.run_sdk(**arguments)
    if tool_name == "run_python":
        return agent_tools.run_python(**arguments)
    raise ProviderError(f"Unsupported tool requested by agent: {tool_name}")


def _save_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8")


def _save_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _build_initial_messages(task: str, docs: dict[str, Any]) -> list[str]:
    return [
        SYSTEM_INSTRUCTIONS.format(tool_descriptions=_tool_descriptions_text()),
        (
            "Product documentation:\n"
            f"llms.txt source: {docs['llms_source']}\n"
            f"{docs['llms_text']}\n\n"
            f"{docs['llms_manifest_text']}\n\n"
            f"llms-full.txt source: {docs['llms_full_source']}\n"
            "llms-full.txt is available through the `ground_docs` tool for targeted retrieval."
        ),
        f"User task:\n{task}",
    ]


def _send_and_parse_response(
    config: HarnessConfig,
    transcript: list[str],
    raw_responses: list[dict[str, Any]],
    step: int,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    attempt_transcript = transcript[:]

    for attempt in range(config.max_format_retries + 1):
        prompt = "\n\n".join(attempt_transcript)
        response_text = send_prompt(config.provider, prompt)
        raw_responses.append(
            {
                "step": step,
                "attempt": attempt + 1,
                "response_text": response_text,
            }
        )
        print(f"Raw Gemini response at step {step}, attempt {attempt + 1}:")
        print(response_text)
        print()

        try:
            return _extract_json_block(response_text), None
        except ProviderError as error:
            if attempt >= config.max_format_retries:
                return None, {
                    "step": step,
                    "attempt": attempt + 1,
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "response_text": response_text,
                }
            attempt_transcript = transcript + [FORMAT_REPAIR_INSTRUCTION]

    return None, {
        "step": step,
        "attempt": config.max_format_retries + 1,
        "error_type": "ProviderError",
        "error": "Unknown parse failure",
        "response_text": "",
    }


def run_prompt(task: str, docs: dict[str, Any], config: HarnessConfig) -> dict[str, Any]:
    transcript = _build_initial_messages(task, docs)
    tool_calls: list[dict[str, Any]] = []
    raw_responses: list[dict[str, Any]] = []

    print(f"\nTask: {task}")

    for step in range(1, config.max_steps + 1):
        response, parse_error = _send_and_parse_response(config, transcript, raw_responses, step)
        if parse_error is not None:
            return {
                "task": task,
                "status": "failed",
                "failure_stage": "response_parse",
                "final_response": None,
                "parse_error": parse_error,
                "tool_calls": tool_calls,
                "raw_responses": raw_responses,
            }

        assert response is not None
        response_type = response.get("type")

        if response_type == "final":
            final_response = response.get("response")
            if not isinstance(final_response, str) or not final_response.strip():
                return {
                    "task": task,
                    "status": "failed",
                    "failure_stage": "empty_final",
                    "final_response": None,
                    "tool_calls": tool_calls,
                    "raw_responses": raw_responses,
                }
            print("Final response produced.")
            return {
                "task": task,
                "status": "completed",
                "failure_stage": None,
                "final_response": final_response.strip(),
                "tool_calls": tool_calls,
                "raw_responses": raw_responses,
            }

        if response_type != "tool_call":
            return {
                "task": task,
                "status": "failed",
                "failure_stage": "invalid_response_type",
                "invalid_response": response,
                "final_response": None,
                "tool_calls": tool_calls,
                "raw_responses": raw_responses,
            }

        tool_name = response.get("tool")
        arguments = response.get("arguments", {})
        if not isinstance(tool_name, str) or tool_name not in TOOL_DESCRIPTIONS:
            return {
                "task": task,
                "status": "failed",
                "failure_stage": "unknown_tool",
                "invalid_response": response,
                "final_response": None,
                "tool_calls": tool_calls,
                "raw_responses": raw_responses,
            }
        if not isinstance(arguments, dict):
            return {
                "task": task,
                "status": "failed",
                "failure_stage": "invalid_tool_arguments",
                "invalid_response": response,
                "final_response": None,
                "tool_calls": tool_calls,
                "raw_responses": raw_responses,
            }

        try:
            tool_result = _call_tool(tool_name, arguments)
        except Exception as error:
            tool_result = {
                "ok": False,
                "error_type": type(error).__name__,
                "error": str(error).strip() or repr(error),
            }

        tool_ok = bool(tool_result.get("ok"))
        print(f"Step {step}: {tool_name} -> {'ok' if tool_ok else 'error'}")

        tool_call = {
            "step": step,
            "tool": tool_name,
            "arguments": arguments,
            "ok": tool_ok,
            "error_type": tool_result.get("error_type"),
            "error": tool_result.get("error"),
            "result": tool_result,
        }
        tool_calls.append(tool_call)

        transcript.append(
            "Tool result:\n"
            + json.dumps(
                {
                    "step": step,
                    "tool": tool_name,
                    "arguments": arguments,
                    "result": tool_result,
                },
                ensure_ascii=True,
                indent=2,
            )
        )

    return {
        "task": task,
        "status": "failed",
        "failure_stage": "max_steps_exceeded",
        "final_response": None,
        "tool_calls": tool_calls,
        "raw_responses": raw_responses,
    }


def run_harness(config: HarnessConfig) -> dict[str, Any]:
    docs = asyncio.run(
        agent_tools.read_docs(
            llms_source=config.llms_source,
            llms_full_source=config.llms_full_source,
            llms_url=config.llms_url,
            llms_full_url=config.llms_full_url,
        )
    )
    if not docs.get("ok"):
        raise ProviderError(f"Could not load docs: {docs.get('error')}")

    manifest_dir = config.output_dir / "docs"
    _save_json(manifest_dir / "llms_manifest.json", docs["llms_manifest"])
    _save_text(manifest_dir / "llms_manifest.txt", docs["llms_manifest_text"])
    _save_text(manifest_dir / "llms.txt", docs["llms_text"])

    reports: list[dict[str, Any]] = []
    for index, task in enumerate(TEST_PROMPTS, start=1):
        report = run_prompt(task, docs, config)
        reports.append(report)
        _save_json(config.output_dir / "reports" / f"prompt_{index}.json", report)

    summary = {
        "provider": config.provider.name,
        "model": config.provider.model,
        "output_dir": str(config.output_dir),
        "manifest_path": str(manifest_dir / "llms_manifest.json"),
        "reports": [
            {
                "task": report["task"],
                "status": report["status"],
                "failure_stage": report.get("failure_stage"),
                "tool_calls": [
                    {
                        "step": call["step"],
                        "tool": call["tool"],
                        "ok": call["ok"],
                        "error_type": call["error_type"],
                    }
                    for call in report["tool_calls"]
                ],
            }
            for report in reports
        ],
    }
    _save_json(config.output_dir / "summary.json", summary)
    return summary


def main() -> None:
    load_environment()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(__file__).resolve().parents[2] / "artifacts" / "layer1_harness" / timestamp
    config = HarnessConfig(
        provider=ProviderConfig(name="gemini", model="gemini-2.5-pro"),
        output_dir=output_dir,
    )
    summary = run_harness(config)

    print("\nHarness complete.")
    print(f"Manifest saved to: {summary['manifest_path']}")
    print(f"Summary saved to: {output_dir / 'summary.json'}")
    for report in summary["reports"]:
        print(f"\nPrompt: {report['task']}")
        print(f"  status={report['status']}")
        if report["failure_stage"]:
            print(f"  failure_stage={report['failure_stage']}")
        for call in report["tool_calls"]:
            print(
                f"  step={call['step']} tool={call['tool']} ok={call['ok']}"
                + (f" error_type={call['error_type']}" if call["error_type"] else "")
            )


if __name__ == "__main__":
    main()
