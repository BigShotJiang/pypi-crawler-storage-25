"""Layer 1: primitive tools and product-context loading."""
