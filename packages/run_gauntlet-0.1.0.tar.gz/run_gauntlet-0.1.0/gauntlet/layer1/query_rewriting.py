"""Query rewriting via Gemini 2.5 Flash-Lite.

Expands a (task, next_goal) pair into a short list of alternative search
queries. Each variant is run through the lexical + dense retrievers and
the rankings are fused via RRF in the caller. This helps when the
runtime "need" string under-specifies the terminology the docs actually
use (e.g. asking about "screenshot" when docs talk about "scrape
output").

Falls back to a single-element list `[runtime_need]` when disabled or on
error so the pipeline is never blocked. Set GAUNTLET_QUERY_REWRITING=1
to enable.
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Any

import httpx


GEMINI_MODEL = os.getenv("GAUNTLET_QUERY_REWRITE_MODEL", "gemini-2.5-flash-lite")
_GEMINI_URL_TMPL = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
)
DEFAULT_MAX_VARIANTS = 4
DEFAULT_TIMEOUT = 15.0


def _clean_key(name: str) -> str:
    raw = os.getenv(name, "")
    if not raw:
        return ""
    return raw.strip().split()[0] if raw.strip() else ""


def is_enabled() -> bool:
    if os.getenv("GAUNTLET_QUERY_REWRITING", "").lower() not in {"1", "true", "yes", "on"}:
        return False
    return bool(_clean_key("GEMINI_API_KEY"))


def _build_prompt(task: str, next_goal: str, max_variants: int) -> str:
    return (
        "Rewrite the user's intent into search queries for a documentation index.\n"
        f"Return up to {max_variants} short queries as a JSON array of strings.\n"
        "Rules:\n"
        "- Each query is 3-12 words.\n"
        "- Prefer different angles: literal terms, API/CLI names, error keywords, broader concept.\n"
        "- Include concrete identifiers (flag names, endpoints, env vars) when implied.\n"
        "- Do NOT invent terms that are not implied by the input.\n"
        "- Output JSON only, no prose, no code fence.\n\n"
        f"TASK: {task or '(none)'}\n"
        f"NEXT_GOAL: {next_goal or '(none)'}\n"
    )


def _call_gemini(prompt: str, *, api_key: str, timeout: float) -> str:
    url = _GEMINI_URL_TMPL.format(model=GEMINI_MODEL, key=api_key)
    payload = {
        "contents": [{"parts": [{"text": prompt}], "role": "user"}],
        "generationConfig": {
            "temperature": 0.2,
            "maxOutputTokens": 320,
            "responseMimeType": "application/json",
            "thinkingConfig": {"thinkingBudget": 0},
        },
    }
    with httpx.Client(timeout=timeout) as client:
        response = client.post(url, json=payload, headers={"Content-Type": "application/json"})
        response.raise_for_status()
        body = response.json()
    candidates = body.get("candidates") or []
    if not candidates:
        return ""
    parts = candidates[0].get("content", {}).get("parts") or []
    return "".join(part.get("text", "") for part in parts).strip()


def _parse_variants(raw: str) -> list[str]:
    if not raw:
        return []
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.MULTILINE)
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    variants: list[str] = []
    for item in parsed:
        if isinstance(item, str):
            cleaned = item.strip()
            if cleaned:
                variants.append(cleaned)
    return variants


def rewrite_query(
    *,
    task: str | None,
    next_goal: str | None,
    runtime_need: str,
    max_variants: int = DEFAULT_MAX_VARIANTS,
    timeout: float = DEFAULT_TIMEOUT,
) -> list[str]:
    """Returns a deduped list of search queries.

    The original `runtime_need` is always first so the lexical scorers
    still see the verbatim user input. Disabled (or failure) collapses
    to `[runtime_need]`.
    """
    base = [runtime_need.strip()] if runtime_need and runtime_need.strip() else []

    if not is_enabled():
        return base

    api_key = _clean_key("GEMINI_API_KEY")
    if not api_key:
        return base

    prompt = _build_prompt(task or "", next_goal or "", max_variants)
    attempts = 0
    raw = ""
    while True:
        try:
            raw = _call_gemini(prompt, api_key=api_key, timeout=timeout)
            break
        except httpx.HTTPError:
            attempts += 1
            if attempts >= 2:
                return base
            time.sleep(0.3 * attempts)

    variants = _parse_variants(raw)
    combined: list[str] = []
    seen: set[str] = set()
    for q in base + variants:
        norm = q.strip().lower()
        if not norm or norm in seen:
            continue
        seen.add(norm)
        combined.append(q.strip())
        if len(combined) >= max_variants + len(base):
            break
    return combined or base
