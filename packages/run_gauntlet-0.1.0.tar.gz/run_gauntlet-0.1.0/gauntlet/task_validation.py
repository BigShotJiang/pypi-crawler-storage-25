from __future__ import annotations

import re
import shlex
from typing import Any


EMPTY_TASK_SPEC: dict[str, Any] = {
    "required_outputs": [],
    "required_tools": [],
    "required_interfaces": [],
    "forbidden_tools": [],
    "forbidden_interfaces": [],
    "required_artifacts": [],
    "must_verify": True,
    "success_conditions": [],
}


def infer_task_spec(task: str) -> dict[str, Any]:
    return {key: (list(value) if isinstance(value, list) else value) for key, value in EMPTY_TASK_SPEC.items()}


def _stringify_command(command: Any) -> str:
    if isinstance(command, str):
        return command
    if isinstance(command, list):
        return " ".join(str(part) for part in command)
    return str(command)


def _command_tokens(command: Any, *, shell: bool = False) -> list[str]:
    if isinstance(command, list):
        return [str(part) for part in command]
    if not isinstance(command, str):
        return []
    if shell:
        try:
            return shlex.split(command)
        except ValueError:
            return command.split()
    try:
        return shlex.split(command)
    except ValueError:
        return command.split()


def _step_tool_and_arguments(step: dict[str, Any]) -> tuple[str | None, dict[str, Any]]:
    tool = step.get("tool") or {}
    if not isinstance(tool, dict):
        return None, {}
    tool_name = tool.get("name")
    arguments = tool.get("arguments")
    return (tool_name if isinstance(tool_name, str) else None), (arguments if isinstance(arguments, dict) else {})


def is_direct_http_tool_call(tool_name: str | None, arguments: dict[str, Any]) -> bool:
    if tool_name == "run_http":
        return True
    if tool_name == "run_cli":
        tokens = _command_tokens(arguments.get("command"), shell=bool(arguments.get("shell")))
        return bool(tokens and tokens[0] == "curl")
    if tool_name == "run_python":
        code = str(arguments.get("code") or "")
        return bool(
            re.search(r"(?m)^\s*import\s+(requests|httpx|urllib\.request|http\.client)\b", code)
            or re.search(r"(?m)^\s*from\s+(requests|httpx|urllib|http\.client)\s+import\b", code)
            or re.search(r"\b(requests|httpx)\s*\.\s*(get|post|put|patch|delete|request)\s*\(", code)
        )
    return False


def direct_http_usage(run: dict[str, Any]) -> list[dict[str, Any]]:
    usages: list[dict[str, Any]] = []
    for step in run.get("steps") or []:
        tool_name, arguments = _step_tool_and_arguments(step)
        if is_direct_http_tool_call(tool_name, arguments):
            usages.append({"step": step.get("step"), "tool": tool_name})
    return usages


def validate_interface_usage(run: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
    return {
        "required_interfaces": list(spec.get("required_interfaces") or []),
        "missing_interfaces": [],
        "interface_usage": {},
        "sdk_usage": [],
        "forbidden_interfaces_used": [],
    }


def validate_preflight_plan(plan: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
    return {"ok": True, "violations": [], "plan": plan}
