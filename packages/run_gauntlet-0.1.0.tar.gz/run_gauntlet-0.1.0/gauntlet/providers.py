from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass


class ProviderError(RuntimeError):
    pass


@dataclass(frozen=True)
class ProviderConfig:
    name: str
    model: str


def available_providers() -> tuple[str, ...]:
    return ("openai", "gemini", "ollama")


def default_model_for(provider: str) -> str:
    defaults = {
        "openai": "gpt-5.4",
        "gemini": "gemini-2.5-pro",
        "ollama": "llama3.1",
    }
    try:
        return defaults[provider]
    except KeyError as exc:
        raise ProviderError(f"Unsupported provider: {provider}") from exc


def send_prompt(config: ProviderConfig, prompt: str) -> str:
    provider = config.name.lower()
    if provider == "openai":
        return _send_openai(config.model, prompt)
    if provider == "gemini":
        return _send_gemini(config.model, prompt)
    if provider == "ollama":
        return _send_ollama(config.model, prompt)
    raise ProviderError(f"Unsupported provider: {config.name}")


def _post_json(url: str, payload: dict, headers: dict[str, str]) -> dict:
    timeout_seconds = float(os.getenv("GAUNTLET_PROVIDER_TIMEOUT_SECONDS", "500"))
    request = urllib.request.Request(
        url=url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", **headers},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            body = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace")
        raise ProviderError(f"Request failed with HTTP {exc.code}: {details}") from exc
    except urllib.error.URLError as exc:
        raise ProviderError(f"Network request failed: {exc.reason}") from exc

    try:
        return json.loads(body)
    except json.JSONDecodeError as exc:
        raise ProviderError("Provider returned invalid JSON") from exc


def _require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise ProviderError(f"Missing required environment variable: {name}")
    return value


def _send_openai(model: str, prompt: str) -> str:
    api_key = _require_env("OPENAI_API_KEY")
    payload = {
        "model": model,
        "input": prompt,
    }
    data = _post_json(
        "https://api.openai.com/v1/responses",
        payload,
        {"Authorization": f"Bearer {api_key}"},
    )

    text = data.get("output_text")
    if isinstance(text, str) and text.strip():
        return text.strip()

    # Fallback for alternate response shapes.
    for item in data.get("output", []):
        for content in item.get("content", []):
            if content.get("type") == "output_text" and content.get("text"):
                return str(content["text"]).strip()
    raise ProviderError("OpenAI response did not contain text output")


def _send_gemini(model: str, prompt: str) -> str:
    api_key = _require_env("GEMINI_API_KEY")
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{model}:generateContent?key={api_key}"
    )
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt},
                ]
            }
        ]
    }
    data = _post_json(url, payload, {})
    candidates = data.get("candidates", [])
    for candidate in candidates:
        content = candidate.get("content", {})
        for part in content.get("parts", []):
            text = part.get("text")
            if text:
                stripped = str(text).strip()
                if stripped:
                    return stripped
    raise ProviderError("Gemini response did not contain text output")


def _send_ollama(model: str, prompt: str) -> str:
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
    }
    data = _post_json(f"{base_url}/api/generate", payload, {})
    response = data.get("response")
    if isinstance(response, str) and response.strip():
        return response.strip()
    raise ProviderError("Ollama response did not contain text output")
