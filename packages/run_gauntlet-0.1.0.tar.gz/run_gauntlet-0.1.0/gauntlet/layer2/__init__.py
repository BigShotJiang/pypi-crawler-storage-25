"""Layer 2: agent orchestration and persona behavior."""
