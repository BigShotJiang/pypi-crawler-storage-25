from __future__ import annotations

import asyncio
import importlib.util
import inspect
import json
import os
import re
import shutil
import shlex
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from gauntlet.layer1 import agent_tools
from gauntlet.layer1.llms_slim import is_enabled as _slim_enabled, slim_llms_text
from gauntlet.layer1.utility import environment_metadata
from gauntlet.layer2.personas import build_persona_prompt
from gauntlet.task_validation import infer_task_spec
from gauntlet.providers import ProviderConfig, ProviderError, send_prompt


TOOL_DESCRIPTIONS = {
    "read_docs": "Load llms.txt and llms-full.txt sources, and return llms.txt plus a normalized manifest. Arguments: llms_source?, llms_full_source?, llms_url?, llms_full_url?.",
    "read_doc": "Load a single local documentation file. Arguments: filename, fallback_url?. For URLs, pass a local filename plus fallback_url, or use ground_docs.",
    "ground_docs": "Retrieve targeted runtime grounding from llms-full.txt and Gauntlet tool docs using task, previous_output, current_error, and next_goal. Arguments: task?, previous_output?, current_error?, next_goal?, llms_source?, llms_full_source?, llms_url?, llms_full_url?, tool_schemas?, max_chunks?.",
    "run_http": "Make an HTTP request. Arguments: method, url, body?, headers?, headers_from_env?, query?, timeout_seconds?, docs_text?, app_name?. Does not expand shell variables such as $STEEL_API_KEY; use headers_from_env for environment-backed headers.",
    "run_cli": "Run a CLI command. Arguments: command (list of strings by default, or string when shell=true), cwd?, env?, timeout_seconds?, shell?. Valid examples: command=[\"steel\", \"scrape\", \"https://example.com\"] or command=\"steel scrape https://example.com\", shell=true. Use shell=true for shell expansion such as $STEEL_API_KEY.",
    "run_sdk": "Import a Python SDK factory and invoke a method directly. Best when docs specify a concrete SDK method or factory/method path. Arguments: factory_import_path, method_path?, factory_args?, factory_kwargs?, method_args?, method_kwargs?.",
    "run_python": "Execute Python code in a subprocess. This may also be used for SDK work when you need a longer script, multiple SDK calls, control flow, or imports that do not fit a single run_sdk invocation. Arguments: code, cwd?, env?, timeout_seconds?, stdin_from_step?, stdin_path?.",
    "check_credentials": "Report whether requested environment credentials are present without revealing values. Arguments: names?.",
    "inspect_environment": "Report runtime metadata such as Node, npm, Python, platform, Python packages, and credential status. Arguments: none.",
}

SYSTEM_INSTRUCTIONS = """You are a simple tool-using agent.

Available tools:
{tool_descriptions}

Rules:
- You may call at most one tool at a time.
- Start from the provided llms.txt manifest when product docs are relevant.
- Call ground_docs when you need targeted llms-full.txt context for the next step.
- For Python SDK tasks, either `run_sdk` or `run_python` may be valid. Prefer `run_sdk` for a single direct SDK method call, and use `run_python` when the SDK workflow needs a fuller script.
- Inspect tool results carefully. If ok is false, adapt or explain the limitation.
- For direct REST/API work, use direct HTTP interfaces: run_http, curl through run_cli, or requests/httpx through run_python. Do not use SDKs when the user asks for REST/API directly.
- For large outputs, prefer literal artifact paths from the Available artifacts section instead of copying truncated text.
- Never claim a screenshot, browser interaction, or scraped result unless a tool actually produced it.
- Use `check_credentials` when credential presence is relevant.
- Never pass placeholder secrets or example credentials in tool arguments or env, such as YOUR_API_KEY, YOUR_STEEL_API_KEY, or ${{STEEL_API_KEY}}.
- Respond in JSON only.
- Tool call format:
  {{"type":"tool_call","tool":"run_http","arguments":{{"method":"GET","url":"https://example.com"}}}}
- Final answer format:
  {{"type":"final","response":"your final answer"}}
"""

GAUNTLET_TOOL_GUIDANCE = """Gauntlet tool mechanics:
- run_python does not automatically receive stdout from previous steps.
- run_cli stdout is saved as an artifact file under .gauntlet_artifacts/.
- run_http does not expand shell variables like $STEEL_API_KEY.
- run_cli with shell=true can expand shell variables.
- Previous outputs must be referenced using exact artifact paths unless the harness explicitly resolves a placeholder.
- Python code should open artifact files using literal relative paths.
- If parsing fails once, inspect the raw artifact before retrying.
- Unsupported placeholder syntax such as $steps[2].artifacts.stdout_json should be replaced with the literal path shown in Available artifacts.
"""

FORMAT_REPAIR_INSTRUCTION = """Your previous response was invalid because it did not contain exactly one JSON object in the required format.
Reply again with JSON only and no surrounding text."""



@dataclass(frozen=True)
class AgentRunConfig:
    provider: ProviderConfig
    task: str
    persona: str | None = None
    prompt_id: str = "1"
    batch_prompt_count: int = 1
    llms_source: str | None = None
    llms_full_source: str | None = None
    max_steps: int = 8
    max_restarts: int = 3
    max_runtime_seconds: float | None = None
    max_model_calls: int | None = None
    max_estimated_cost_usd: float | None = None
    cost_per_1k_prompt_chars: float | None = None
    cost_per_1k_response_chars: float | None = None
    max_format_retries: int = 1
    validation_mode: str = "real_agent"
    max_schema_corrections: int = 2
    transient_retry_attempts: int = 2
    debug: bool = False
    run_record_path: str | None = None
    resume_from_run_record: str | None = None


def _tool_descriptions_text() -> str:
    return "\n".join(f"- {name}: {description}" for name, description in TOOL_DESCRIPTIONS.items())


def _truncate_text(text: str, limit: int = 3000) -> str:
    if len(text) <= limit:
        return text
    kept = max(limit - 64, 0)
    omitted = len(text) - kept
    return text[:kept] + f"\n... <truncated {omitted} chars>"


def _debug_log(config: AgentRunConfig, title: str, payload: Any) -> None:
    if not config.debug:
        return
    if isinstance(payload, str):
        text = payload
    else:
        text = json.dumps(payload, ensure_ascii=True, indent=2)
    print(f"[debug] {title}\n{text}", file=sys.stderr, flush=True)


def _is_transient_provider_error(error: Exception) -> bool:
    text = str(error).lower()
    return any(
        needle in text
        for needle in (
            "did not contain text output",
            "empty response",
            "network request failed",
            "timed out",
            "timeout",
            "temporarily unavailable",
            "429",
            "500",
            "502",
            "503",
            "504",
        )
    )


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_run_record(path: str | None, payload: dict[str, Any]) -> None:
    if not path:
        return
    target = Path(path).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(payload, ensure_ascii=True, indent=2)
    temp = target.with_name(f".{target.name}.tmp")
    temp.write_text(encoded, encoding="utf-8")
    os.replace(temp, target)


def _run_workspace_path(run_record_path: str | None, run_key: str) -> str | None:
    if not run_record_path:
        return None
    batch_dir = Path(run_record_path).expanduser().parent
    return str(batch_dir / run_key / "workspace")


def _prepare_workspace(workspace_path: str | None, *, clean: bool) -> None:
    if not workspace_path:
        return
    target = Path(workspace_path).expanduser()
    if clean and target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True, exist_ok=True)


def _load_run_record(path: str) -> dict[str, Any]:
    return json.loads(Path(path).expanduser().read_text(encoding="utf-8"))


def _extract_json_block(text: str) -> dict[str, Any]:
    candidate = text.strip()
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 3:
            candidate = "\n".join(lines[1:-1]).strip()
    start = candidate.find("{")
    end = candidate.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ProviderError("Agent response did not contain JSON")
    try:
        parsed = json.loads(candidate[start : end + 1])
    except json.JSONDecodeError as exc:
        raise ProviderError(f"Agent returned invalid JSON: {candidate}") from exc

    if isinstance(parsed, dict):
        response_type = parsed.get("type")
        if response_type == "tool_code":
            parsed = dict(parsed)
            parsed["type"] = "tool_call"
        response_type = parsed.get("type")
        if isinstance(response_type, str) and response_type in TOOL_DESCRIPTIONS and "tool" not in parsed:
            parsed = dict(parsed)
            parsed["type"] = "tool_call"
            parsed["tool"] = response_type
    return parsed


def _send_and_parse_response(
    config: AgentRunConfig,
    transcript: list[str],
    step: int,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, dict[str, Any]]:
    attempt_transcript = transcript[:]
    model_usage: dict[str, Any] = {
        "model_calls": 0,
        "prompt_chars": 0,
        "response_chars": 0,
        "attempts": [],
    }

    for attempt in range(config.max_format_retries + 1):
        prompt = "\n\n".join(attempt_transcript)
        prompt_chars = len(prompt)
        _debug_log(config, f"step {step} prompt attempt {attempt + 1}", _truncate_text(prompt, 4000))
        provider_attempts = config.transient_retry_attempts + 1
        for provider_attempt in range(1, provider_attempts + 1):
            try:
                response_text = send_prompt(config.provider, prompt)
                break
            except ProviderError as error:
                model_usage["model_calls"] += 1
                model_usage["prompt_chars"] += prompt_chars
                model_usage["attempts"].append(
                    {
                        "attempt": attempt + 1,
                        "provider_attempt": provider_attempt,
                        "prompt_chars": prompt_chars,
                        "response_chars": 0,
                        "error_type": type(error).__name__,
                        "error": str(error),
                    }
                )
                if provider_attempt < provider_attempts and _is_transient_provider_error(error):
                    time.sleep(min(0.5 * provider_attempt, 2.0))
                    continue
                return None, {
                    "attempt": attempt + 1,
                    "provider_attempt": provider_attempt,
                    "stage": "model_call",
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "response_text": "",
                }, model_usage
        else:
            model_usage["model_calls"] += 1
            model_usage["prompt_chars"] += prompt_chars
            return None, {
                "attempt": attempt + 1,
                "stage": "model_call",
                "error_type": "ProviderError",
                "error": "Provider call failed",
                "response_text": "",
            }, model_usage
        response_chars = len(response_text)
        model_usage["model_calls"] += 1
        model_usage["prompt_chars"] += prompt_chars
        model_usage["response_chars"] += response_chars
        model_usage["attempts"].append(
            {
                "attempt": attempt + 1,
                "prompt_chars": prompt_chars,
                "response_chars": response_chars,
            }
        )
        _debug_log(config, f"step {step} model response attempt {attempt + 1}", _truncate_text(response_text, 4000))
        try:
            parsed = _extract_json_block(response_text)
            _debug_log(config, f"step {step} parsed response attempt {attempt + 1}", parsed)
            return parsed, None, model_usage
        except ProviderError as error:
            if attempt >= config.max_format_retries:
                return None, {
                    "attempt": attempt + 1,
                    "stage": "response_parse",
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "response_text": response_text,
                }, model_usage
            attempt_transcript = transcript + [FORMAT_REPAIR_INSTRUCTION]

    return None, {
        "attempt": config.max_format_retries + 1,
        "stage": "response_parse",
        "error_type": "ProviderError",
        "error": "Unknown parse failure",
        "response_text": "",
    }, model_usage


def _build_initial_task(task: str, persona: str | None, docs: dict[str, Any]) -> str:
    user_task = task if not persona else build_persona_prompt(persona, task)
    llms_text = docs["llms_text"]
    if _slim_enabled():
        llms_text = slim_llms_text(llms_text)
    docs_block = (
        f"llms.txt source: {docs['llms_source']}\n"
        f"{llms_text}\n\n"
        f"{docs['llms_manifest_text']}\n\n"
        f"llms-full.txt source: {docs['llms_full_source']}\n"
        "llms-full.txt is available through the `ground_docs` tool for targeted retrieval."
    )
    return (
        f"{SYSTEM_INSTRUCTIONS.format(tool_descriptions=_tool_descriptions_text())}\n\n"
        f"{GAUNTLET_TOOL_GUIDANCE}\n\n"
        f"Product documentation:\n{docs_block}\n\n"
        f"User task:\n{user_task}"
    )


def _compact_tool_result_for_grounding(tool_result: dict[str, Any]) -> dict[str, Any]:
    compact = {
        "ok": tool_result.get("ok"),
        "error_type": tool_result.get("error_type"),
        "error": tool_result.get("error"),
    }

    for key in ("status", "url", "stdout", "stderr", "exit_code", "grounding_block"):
        if key in tool_result:
            compact[key] = tool_result.get(key)

    if "result" in tool_result:
        compact["result"] = tool_result.get("result")

    return compact


def _compact_tool_result_for_transcript(tool_name: str, tool_result: dict[str, Any]) -> dict[str, Any]:
    if tool_name == "ground_docs":
        return _ground_docs_result_for_transcript(tool_result)

    if tool_name == "read_doc":
        compact = {
            "ok": tool_result.get("ok"),
            "error_type": tool_result.get("error_type"),
            "error": tool_result.get("error"),
            "filename": tool_result.get("filename"),
            "source": tool_result.get("source"),
        }
        text = tool_result.get("text")
        if isinstance(text, str) and text:
            compact["text"] = _truncate_text(text, 2000)
        return compact

    compact = {
        "ok": tool_result.get("ok"),
        "error_type": tool_result.get("error_type"),
        "error": tool_result.get("error"),
    }

    for key in ("status", "url", "exit_code", "ignored_arguments", "warnings", "shell", "artifacts", "automatic_retries"):
        if key in tool_result:
            compact[key] = tool_result.get(key)

    if tool_name == "run_sdk":
        for key in ("factory_import_path", "method_path", "target_type"):
            if key in tool_result:
                compact[key] = tool_result.get(key)
        if "result" in tool_result:
            sdk_result = tool_result.get("result")
            if isinstance(sdk_result, dict):
                compact_result: dict[str, Any] = {}
                for key, value in sdk_result.items():
                    if isinstance(value, str):
                        compact_result[key] = _truncate_text(value, 4000)
                    elif isinstance(value, dict):
                        nested: dict[str, Any] = {}
                        for nested_key, nested_value in value.items():
                            if isinstance(nested_value, str):
                                nested[nested_key] = _truncate_text(nested_value, 4000)
                            else:
                                nested[nested_key] = nested_value
                        compact_result[key] = nested
                    else:
                        compact_result[key] = value
                compact["result"] = compact_result
            elif sdk_result is not None:
                compact["result"] = sdk_result

    stdout = tool_result.get("stdout")
    if isinstance(stdout, str) and stdout:
        compact["stdout"] = _truncate_text(stdout, 800)

    stderr = tool_result.get("stderr")
    if isinstance(stderr, str) and stderr:
        compact["stderr"] = _truncate_text(stderr, 800)

    body = tool_result.get("body")
    if isinstance(body, str) and body:
        compact["body"] = _truncate_text(body, 1200)
    elif isinstance(body, (dict, list)):
        compact["body"] = body

    data = tool_result.get("data")
    if isinstance(data, dict):
        data_compact = {}
        for key in ("status", "url", "cwd", "exit_code", "stdout", "stderr"):
            if key in data:
                value = data.get(key)
                if isinstance(value, str) and key in {"stdout", "stderr"}:
                    data_compact[key] = _truncate_text(value, 800)
                else:
                    data_compact[key] = value
        if data_compact:
            compact["data"] = data_compact
    elif data is not None and not isinstance(data, (list, dict)):
        compact["data"] = data

    return compact


def _ground_docs_result_for_transcript(tool_result: dict[str, Any]) -> dict[str, Any]:
    if not tool_result.get("ok"):
        return tool_result

    retrieved_chunks = []
    for chunk in tool_result.get("retrieved_chunks", []):
        retrieved_chunks.append(
            {
                "chunk_id": chunk.get("chunk_id"),
                "title": chunk.get("title"),
                "anchor": chunk.get("anchor"),
                "path": chunk.get("path"),
                "path_text": chunk.get("path_text"),
                "preview": chunk.get("preview"),
                "score": chunk.get("score"),
                "text": chunk.get("text"),
            }
        )

    return {
        "ok": True,
        "error_type": None,
        "error": None,
        "llms_source": tool_result.get("llms_source"),
        "llms_full_source": tool_result.get("llms_full_source"),
        "runtime_need": tool_result.get("runtime_need"),
        "tool_contract": tool_result.get("tool_contract"),
        "doc_binding": tool_result.get("doc_binding"),
        "grounding_block": tool_result.get("grounding_block"),
        "retrieved_chunks": retrieved_chunks,
    }


def _tool_result_for_transcript(tool_name: str, tool_result: dict[str, Any]) -> dict[str, Any]:
    return _compact_tool_result_for_transcript(tool_name, tool_result)


def _transcript_tool_result_entry(step: int, tool_name: str, arguments: dict[str, Any], tool_result: dict[str, Any]) -> str:
    return (
        "Tool result:\n"
        + json.dumps(
            {
                "step": step,
                "tool": tool_name,
                "arguments": arguments,
                "result": tool_result,
            },
            ensure_ascii=True,
            indent=2,
        )
    )


def _rebuild_transcript_from_steps(
    task: str,
    persona: str | None,
    docs: dict[str, Any],
    steps: list[dict[str, Any]],
) -> tuple[list[str], dict[str, Any] | None, dict[str, Any] | None]:
    transcript = [_build_initial_task(task, persona, docs)]
    previous_tool_result: dict[str, Any] | None = None
    active_doc_binding: dict[str, Any] | None = None

    for step in steps:
        tool = step.get("tool") or {}
        tool_name = tool.get("name")
        tool_result = step.get("tool_result")
        if not isinstance(tool_name, str) or not isinstance(tool_result, dict):
            continue

        arguments = tool.get("arguments")
        if not isinstance(arguments, dict):
            arguments = {}

        transcript.append(
            _transcript_tool_result_entry(
                int(step.get("step") or len(transcript)),
                tool_name,
                arguments,
                tool_result,
            )
        )
        previous_tool_result = tool_result

        if tool_name == "ground_docs" and tool_result.get("ok") is True:
            doc_binding = tool_result.get("doc_binding")
            active_doc_binding = doc_binding if isinstance(doc_binding, dict) and doc_binding else None
        elif tool_name in {"run_http", "run_cli", "run_sdk", "run_python"} and tool_result.get("ok") is True:
            active_doc_binding = None

    return transcript, previous_tool_result, active_doc_binding


def _new_runtime_record(config: AgentRunConfig) -> dict[str, Any]:
    return {
        "checkpoint_version": 1,
        "checkpoint_count": 0,
        "checkpointed_at": None,
        "attempt": 1,
        "restart_count": 0,
        "max_restarts": config.max_restarts,
        "budget": {
            "max_steps_per_attempt": config.max_steps,
            "max_total_steps": config.max_steps * (config.max_restarts + 1),
            "max_runtime_seconds": config.max_runtime_seconds,
            "max_model_calls": config.max_model_calls,
            "max_estimated_cost_usd": config.max_estimated_cost_usd,
            "cost_per_1k_prompt_chars": config.cost_per_1k_prompt_chars,
            "cost_per_1k_response_chars": config.cost_per_1k_response_chars,
        },
        "usage": {
            "model_calls": 0,
            "prompt_chars": 0,
            "response_chars": 0,
            "tool_calls": 0,
            "estimated_cost_usd": None,
            "runtime_seconds": 0.0,
        },
        "events": [],
    }


def _runtime(run_record: dict[str, Any], config: AgentRunConfig) -> dict[str, Any]:
    runtime = run_record.get("runtime")
    if not isinstance(runtime, dict):
        runtime = _new_runtime_record(config)
        run_record["runtime"] = runtime
    runtime.setdefault("usage", {})
    runtime.setdefault("events", [])
    runtime.setdefault("budget", _new_runtime_record(config)["budget"])
    runtime.setdefault("restart_count", 0)
    runtime.setdefault("attempt", 1)
    runtime.setdefault("max_restarts", config.max_restarts)
    runtime.setdefault("checkpoint_count", 0)
    return runtime


def _langgraph_available() -> bool:
    return importlib.util.find_spec("langgraph") is not None


def _graph_checkpoint(
    run_record: dict[str, Any],
    config: AgentRunConfig,
    *,
    node: str,
    step: int | None = None,
    status: str = "completed",
    payload: dict[str, Any] | None = None,
) -> None:
    runtime = _runtime(run_record, config)
    graph = runtime.setdefault(
        "graph",
        {
            "style": "langgraph_state_machine",
            "checkpointer": "run_record",
            "langgraph_library_available": _langgraph_available(),
            "nodes": [
                "agent_decision",
                "tool_validation",
                "tool_execution",
                "artifact_index",
                "final_validation",
            ],
            "checkpoints": [],
        },
    )
    checkpoints = graph.setdefault("checkpoints", [])
    checkpoint = {
        "id": len(checkpoints) + 1,
        "at": _utc_now_iso(),
        "node": node,
        "status": status,
    }
    if step is not None:
        checkpoint["step"] = step
    if payload:
        checkpoint["payload"] = payload
    checkpoints.append(checkpoint)
    if len(checkpoints) > 200:
        del checkpoints[:-200]


def _estimate_cost_usd(config: AgentRunConfig, usage: dict[str, Any]) -> float | None:
    prompt_rate = config.cost_per_1k_prompt_chars
    response_rate = config.cost_per_1k_response_chars
    if prompt_rate is None and response_rate is None:
        return None
    prompt_cost = (float(usage.get("prompt_chars") or 0) / 1000.0) * float(prompt_rate or 0.0)
    response_cost = (float(usage.get("response_chars") or 0) / 1000.0) * float(response_rate or 0.0)
    return round(prompt_cost + response_cost, 8)


def _add_model_usage(run_record: dict[str, Any], config: AgentRunConfig, model_usage: dict[str, Any]) -> None:
    usage = _runtime(run_record, config)["usage"]
    usage["model_calls"] = int(usage.get("model_calls") or 0) + int(model_usage.get("model_calls") or 0)
    usage["prompt_chars"] = int(usage.get("prompt_chars") or 0) + int(model_usage.get("prompt_chars") or 0)
    usage["response_chars"] = int(usage.get("response_chars") or 0) + int(model_usage.get("response_chars") or 0)
    usage["estimated_cost_usd"] = _estimate_cost_usd(config, usage)


def _add_tool_usage(run_record: dict[str, Any], config: AgentRunConfig) -> None:
    usage = _runtime(run_record, config)["usage"]
    usage["tool_calls"] = int(usage.get("tool_calls") or 0) + 1


def _update_runtime_seconds(run_record: dict[str, Any], config: AgentRunConfig, started_monotonic: float) -> None:
    usage = _runtime(run_record, config)["usage"]
    usage["runtime_seconds"] = round(time.monotonic() - started_monotonic, 3)


def _budget_failure(
    run_record: dict[str, Any],
    config: AgentRunConfig,
    started_monotonic: float,
) -> dict[str, Any] | None:
    usage = _runtime(run_record, config)["usage"]
    elapsed = time.monotonic() - started_monotonic
    if config.max_runtime_seconds is not None and elapsed >= config.max_runtime_seconds:
        return {
            "type": "budget_exceeded",
            "budget": "max_runtime_seconds",
            "limit": config.max_runtime_seconds,
            "observed": round(elapsed, 3),
        }
    if config.max_model_calls is not None and int(usage.get("model_calls") or 0) >= config.max_model_calls:
        return {
            "type": "budget_exceeded",
            "budget": "max_model_calls",
            "limit": config.max_model_calls,
            "observed": int(usage.get("model_calls") or 0),
        }
    estimated_cost = usage.get("estimated_cost_usd")
    if (
        config.max_estimated_cost_usd is not None
        and isinstance(estimated_cost, (int, float))
        and estimated_cost >= config.max_estimated_cost_usd
    ):
        return {
            "type": "budget_exceeded",
            "budget": "max_estimated_cost_usd",
            "limit": config.max_estimated_cost_usd,
            "observed": estimated_cost,
        }
    return None


def _checkpoint_run_record(
    run_record: dict[str, Any],
    config: AgentRunConfig,
    started_monotonic: float,
) -> None:
    runtime = _runtime(run_record, config)
    _update_runtime_seconds(run_record, config, started_monotonic)
    runtime["checkpoint_count"] = int(runtime.get("checkpoint_count") or 0) + 1
    runtime["checkpointed_at"] = _utc_now_iso()
    _write_run_record(config.run_record_path, run_record)


def _filter_supported_kwargs(callable_obj: Any, arguments: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    signature = inspect.signature(callable_obj)
    supported = set(signature.parameters.keys())
    filtered = {key: value for key, value in arguments.items() if key in supported}
    ignored = [key for key in arguments.keys() if key not in supported]
    return filtered, ignored


def _is_placeholder_secret(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    stripped = value.strip()
    if not stripped:
        return False
    upper = stripped.upper()
    return (
        upper.startswith("YOUR_")
        or upper.endswith("_HERE")
        or stripped.startswith("${")
        or "API_KEY" in upper and "YOUR" in upper
    )


def _sanitize_placeholders(value: Any) -> Any:
    if isinstance(value, dict):
        sanitized: dict[str, Any] = {}
        for key, child in value.items():
            cleaned = _sanitize_placeholders(child)
            if cleaned is not None:
                sanitized[key] = cleaned
        return sanitized
    if isinstance(value, list):
        return [cleaned for item in value if (cleaned := _sanitize_placeholders(item)) is not None]
    if _is_placeholder_secret(value):
        return None
    return value


def _sanitize_tool_arguments(arguments: dict[str, Any]) -> dict[str, Any]:
    sanitized = _sanitize_placeholders(arguments)
    return sanitized if isinstance(sanitized, dict) else dict(arguments)


def _render_active_doc_binding(binding: dict[str, Any] | None) -> str | None:
    if not binding:
        return None

    lines = ["Documentation guidance for the next execution step:"]
    preferred_tool = binding.get("preferred_tool")
    if isinstance(preferred_tool, str) and preferred_tool:
        lines.append(f"- Preferred tool: {preferred_tool}")

    allowed_tools = binding.get("allowed_tools")
    if isinstance(allowed_tools, list) and allowed_tools:
        lines.append(f"- Reasonable tools: {', '.join(str(item) for item in allowed_tools)}")

    confidence = binding.get("confidence")
    if isinstance(confidence, (int, float)):
        lines.append(f"- Retrieval confidence: {confidence:.2f}")

    reason = binding.get("reason")
    if isinstance(reason, str) and reason:
        lines.append(f"- Reason: {reason}")

    required_tool_args = binding.get("required_tool_args")
    if isinstance(required_tool_args, list) and required_tool_args:
        lines.append(f"- Suggested tool args from docs: {', '.join(str(item) for item in required_tool_args)}")

    allowed_method_paths = binding.get("allowed_method_paths")
    if isinstance(allowed_method_paths, list) and allowed_method_paths:
        lines.append(f"- Allowed method paths: {', '.join(str(item) for item in allowed_method_paths)}")

    known_good_example = binding.get("known_good_example")
    if isinstance(known_good_example, str) and known_good_example:
        lines.append(f"- Example pattern: {known_good_example}")

    lines.append("- This is guidance, not a hard constraint. Follow the user task if it conflicts with retrieved docs.")
    return "\n".join(lines)


def _render_available_artifacts(run_record: dict[str, Any]) -> str:
    artifact_map = run_record.get("artifact_map") or {}
    lines: list[str] = []
    for _, record in sorted(
        artifact_map.items(),
        key=lambda item: int(item[0]) if str(item[0]).isdigit() else 0,
    ):
        if not isinstance(record, dict):
            continue
        step_id = record.get("step_id")
        for label, key in (
            ("stdout", "stdout_path"),
            ("stdout JSON", "stdout_json_path"),
            ("stderr", "stderr_path"),
            ("body", "body_path"),
            ("text", "text_path"),
        ):
            path = record.get(key)
            if isinstance(path, str) and path:
                lines.append(f"- Step {step_id} {label}: {path}")
        for label, key in (
            ("stdout JSON shape", "stdout_json_shape"),
            ("body JSON shape", "body_json_shape"),
            ("text JSON shape", "text_json_shape"),
        ):
            shape = record.get(key)
            if shape:
                lines.append(f"- Step {step_id} {label}: {json.dumps(shape, ensure_ascii=True)}")
        for label, key in (
            ("stdout JSON paths", "stdout_json_paths"),
            ("body JSON paths", "body_json_paths"),
            ("text JSON paths", "text_json_paths"),
        ):
            paths = record.get(key)
            if isinstance(paths, list) and paths:
                rendered = "; ".join(str(item) for item in paths[:16])
                lines.append(f"- Step {step_id} {label}: {rendered}")
        files = [item for item in record.get("files", []) if isinstance(item, str)]
        for file_path in files[:6]:
            if file_path not in "\n".join(lines):
                lines.append(f"- Step {step_id} file: {file_path}")
        public_urls = [item for item in record.get("public_urls", []) if isinstance(item, str)]
        for url in public_urls[:6]:
            lines.append(f"- Step {step_id} public URL: {url}")
    return "\n".join(lines) if lines else "- No artifacts are available yet."


def _last_error(run_record: dict[str, Any]) -> str:
    for step in reversed(run_record.get("steps") or []):
        tool_result = step.get("tool_result")
        if isinstance(tool_result, dict) and tool_result.get("ok") is False:
            return str(tool_result.get("error") or tool_result.get("error_type") or "tool failed")
        validation_errors = step.get("validation_errors")
        if validation_errors:
            return _truncate_text(json.dumps(validation_errors, ensure_ascii=True), 500)
        parse_error = step.get("parse_error")
        if isinstance(parse_error, dict):
            return str(parse_error.get("error") or "parse error")
    return "None"


def _render_execution_state(run_record: dict[str, Any], config: AgentRunConfig, spec: dict[str, Any]) -> str:
    usage = (_runtime(run_record, config).get("usage") or {})
    budget = (_runtime(run_record, config).get("budget") or {})
    pending_uncertainty = _runtime(run_record, config).get("pending_uncertainty_resolution")
    pending_block = ""
    if isinstance(pending_uncertainty, dict) and pending_uncertainty:
        pending_block = (
            "Pending uncertainty resolution:\n"
            f"- Reason: {pending_uncertainty.get('reason')}\n"
            f"- Failing tool: {pending_uncertainty.get('failing_tool')}\n"
            f"- Required next action: {', '.join(str(item) for item in pending_uncertainty.get('allowed_next_actions') or [])}\n"
        )
    max_total_steps = int(budget.get("max_total_steps") or config.max_steps * (config.max_restarts + 1))
    used_steps = len(run_record.get("steps") or [])
    remaining_steps = max(max_total_steps - used_steps, 0)
    allowed_interfaces = list(spec.get("required_interfaces") or ["task-dependent"])
    forbidden_interfaces = list(spec.get("forbidden_interfaces") or [])
    forbidden_tools = list(spec.get("forbidden_tools") or [])
    return (
        "Current execution state:\n"
        f"Current task: {run_record.get('task')}\n"
        f"Required outputs: {', '.join(spec.get('required_outputs') or []) or 'None inferred'}\n"
        f"Allowed interfaces: {', '.join(allowed_interfaces)}\n"
        f"Forbidden interfaces: {', '.join(forbidden_interfaces) or 'None'}\n"
        f"Forbidden tools: {', '.join(forbidden_tools) or 'None'}\n"
        "Available artifacts:\n"
        f"{_render_available_artifacts(run_record)}\n"
        f"Last error: {_last_error(run_record)}\n"
        f"{pending_block}"
        f"Budget remaining: {remaining_steps} tool/model decision steps; model calls used={usage.get('model_calls', 0)}\n"
        "Important tool mechanics:\n"
        f"{GAUNTLET_TOOL_GUIDANCE}"
    )


def _doc_binding_followed(
    *,
    tool_name: str,
    arguments: dict[str, Any],
    active_doc_binding: dict[str, Any] | None,
) -> tuple[bool | None, list[str]]:
    if not active_doc_binding or tool_name in {"ground_docs", "read_docs", "read_doc"}:
        return None, []

    violations: list[str] = []
    preferred_tool = active_doc_binding.get("preferred_tool")
    if isinstance(preferred_tool, str) and preferred_tool and tool_name != preferred_tool:
        violations.append(f"preferred_tool={preferred_tool}, actual_tool={tool_name}")

    required_tool_args = active_doc_binding.get("required_tool_args")
    if isinstance(required_tool_args, list):
        missing = [name for name in required_tool_args if isinstance(name, str) and name not in arguments]
        if missing:
            violations.append(f"missing_suggested_args={', '.join(missing)}")

    allowed_method_paths = active_doc_binding.get("allowed_method_paths")
    if isinstance(allowed_method_paths, list) and allowed_method_paths:
        method_path = arguments.get("method_path")
        if isinstance(method_path, str) and method_path not in allowed_method_paths:
            violations.append(f"method_path={method_path} not in doc_examples")

    return not violations, violations


def _normalize_tool_arguments(tool_name: str, response: dict[str, Any], arguments: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    normalized = dict(arguments)
    notes: list[str] = []
    if tool_name == "run_python" and "code" not in normalized:
        for alias in ("script", "python", "source", "program"):
            value = normalized.get(alias)
            if isinstance(value, str) and value.strip():
                normalized["code"] = value
                notes.append(f"mapped `{alias}` to `code`")
                break
        if "code" not in normalized:
            top_level_code = response.get("code")
            if isinstance(top_level_code, str) and top_level_code.strip():
                normalized["code"] = top_level_code
                notes.append("mapped top-level `code` to arguments.code")
    return normalized, notes


def _schema_for_tool(tool_name: str) -> dict[str, type | tuple[type, ...]]:
    return {
        "read_doc": {"filename": str},
        "run_http": {"method": str, "url": str},
        "run_cli": {"command": (list, str)},
        "run_sdk": {"factory_import_path": str},
        "run_python": {"code": str},
    }.get(tool_name, {})


def _validate_tool_arguments(
    tool_name: str,
    arguments: dict[str, Any],
    *,
    generated_profile: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    errors: list[dict[str, Any]] = []
    schema = _schema_for_tool(tool_name)
    for name, expected_type in schema.items():
        if name not in arguments:
            errors.append(
                {
                    "type": "missing_required_argument",
                    "argument": name,
                    "message": f"`{tool_name}` requires `{name}`.",
                }
            )
            continue
        if not isinstance(arguments[name], expected_type):
            expected_name = (
                " or ".join(item.__name__ for item in expected_type)
                if isinstance(expected_type, tuple)
                else expected_type.__name__
            )
            errors.append(
                {
                    "type": "invalid_argument_type",
                    "argument": name,
                    "expected": expected_name,
                    "observed": type(arguments[name]).__name__,
                    "message": f"`{tool_name}.{name}` must be {expected_name}.",
                }
            )
    if tool_name == "run_cli" and isinstance(arguments.get("command"), str) and not arguments.get("shell"):
        command = str(arguments.get("command") or "")
        if re.search(r"[|&;<>`$]", command):
            errors.append(
                {
                    "type": "shell_required_for_command_string",
                    "argument": "command",
                    "message": (
                        "String commands with shell syntax require shell=true. Valid formats: "
                        'command=["steel", "scrape", "https://example.com"] or '
                        'command="steel scrape https://example.com", shell=true.'
                    ),
                }
            )
    if tool_name == "run_cli":
        errors.extend(_validate_cli_command_contract(arguments, generated_profile))
    if tool_name == "run_http":
        errors.extend(_validate_http_endpoint_contract(arguments, generated_profile))
    return errors


def _command_tokens_for_validation(arguments: dict[str, Any]) -> list[str]:
    command = arguments.get("command")
    if isinstance(command, list):
        return [str(item) for item in command]
    if isinstance(command, str):
        try:
            return shlex.split(command)
        except ValueError:
            return command.split()
    return []


def _looks_like_url(value: str) -> bool:
    return bool(re.match(r"https?://", value))


def _clean_doc_line(line: str) -> str:
    cleaned = line.strip()
    cleaned = re.sub(r"^[-*]\s+", "", cleaned)
    cleaned = cleaned.strip("`$ ")
    cleaned = cleaned.replace("`", "")
    if "|" in cleaned:
        cells = [cell.strip(" `") for cell in cleaned.strip("|").split("|")]
        cleaned = " ".join(cell for cell in cells if cell and not re.fullmatch(r":?-{2,}:?", cell))
    return re.sub(r"\s+", " ", cleaned).strip()


def _command_root_from_tokens(tokens: list[str]) -> str | None:
    if len(tokens) < 1:
        return None
    if tokens[0] in {"curl", "python", "node", "npm", "npx"}:
        return None
    if tokens[0].startswith("-") or _looks_like_url(tokens[0]):
        return None
    root_tokens = [tokens[0]]
    for token in tokens[1:2]:
        if token.startswith("-") or _looks_like_url(token) or _looks_like_placeholder(token):
            break
        if token.upper() == token and any(char.isalpha() for char in token):
            break
        root_tokens.append(token)
    return " ".join(root_tokens)


def _looks_like_placeholder(token: str) -> bool:
    stripped = token.strip("[](){}.,")
    if not stripped:
        return False
    if re.fullmatch(r"<[^>]+>", stripped):
        return True
    if re.fullmatch(r"\[[A-Z][A-Z0-9_-]*\]", token):
        return True
    if stripped.upper() == stripped and any(char.isalpha() for char in stripped):
        return True
    return stripped.lower() in {
        "path",
        "file",
        "filename",
        "dir",
        "directory",
        "url",
        "uri",
        "value",
        "name",
        "key",
        "token",
        "seconds",
        "timeout",
        "format",
        "json",
        "text",
        "id",
        "number",
        "count",
    }


def _flag_entries_from_line(line: str) -> list[tuple[str, bool]]:
    entries: list[tuple[str, bool]] = []
    try:
        tokens = shlex.split(line)
    except ValueError:
        tokens = line.split()
    for index, token in enumerate(tokens):
        if not token.startswith("--"):
            continue
        flag, has_inline_value = token.split("=", 1)[0], "=" in token
        if not re.fullmatch(r"--[A-Za-z0-9][A-Za-z0-9_-]*", flag):
            continue
        next_token = tokens[index + 1] if index + 1 < len(tokens) else ""
        entries.append((flag, has_inline_value or _looks_like_placeholder(next_token)))
    return entries


def _contract_for_root(contracts: dict[str, dict[str, Any]], root: str) -> dict[str, Any]:
    contract = contracts.setdefault(root, {"boolean_flags": [], "value_flags": [], "sources": []})
    contract.setdefault("boolean_flags", [])
    contract.setdefault("value_flags", [])
    contract.setdefault("sources", [])
    return contract


def _add_flag_contract(contract: dict[str, Any], flag: str, *, has_value: bool, source: str) -> None:
    boolean_flags = set(contract.get("boolean_flags") or [])
    value_flags = set(contract.get("value_flags") or [])
    if has_value:
        value_flags.add(flag)
        boolean_flags.discard(flag)
    elif flag not in value_flags:
        boolean_flags.add(flag)
    contract["boolean_flags"] = sorted(boolean_flags)
    contract["value_flags"] = sorted(value_flags)
    sources = [str(item) for item in contract.get("sources") or []]
    if source not in sources:
        sources.append(source)
    contract["sources"] = sources


def _infer_cli_contracts_from_docs(docs: dict[str, Any]) -> dict[str, Any]:
    text = str(docs.get("llms_full_text") or docs.get("llms_text") or "")
    contracts: dict[str, dict[str, Any]] = {}
    active_root: str | None = None
    for raw_line in text.splitlines():
        line = _clean_doc_line(raw_line)
        lowered = line.lower()
        if not line:
            continue
        if lowered.rstrip(":") in {"options", "flags", "arguments", "commands"}:
            continue
        usage_match = re.search(r"\b(?:usage|command)\s*:?\s+(.+)$", line, flags=re.I)
        root_candidate_text = usage_match.group(1) if usage_match else line
        try:
            root_tokens = shlex.split(root_candidate_text)
        except ValueError:
            root_tokens = root_candidate_text.split()
        root = _command_root_from_tokens(root_tokens)
        if usage_match and root and not root_tokens[0].startswith("--"):
            active_root = root

        if "--" not in line or len(line) > 260:
            continue
        try:
            tokens = shlex.split(line)
        except ValueError:
            tokens = line.split()
        line_root = _command_root_from_tokens(tokens)
        if line_root:
            active_root = line_root
        target_root = line_root or active_root
        if not target_root:
            continue
        source = "command_example" if line_root else "option_section"
        contract = _contract_for_root(contracts, target_root)
        for flag, has_value in _flag_entries_from_line(line):
            _add_flag_contract(contract, flag, has_value=has_value, source=source)
        if lowered.startswith(("options", "flags", "arguments")):
            active_root = target_root
    return contracts


def _json_body_keys(text: str) -> list[str]:
    keys: list[str] = []
    for match in re.findall(r"\{[^{}]{0,600}\}", text, flags=re.S):
        keys.extend(re.findall(r'"([A-Za-z_][A-Za-z0-9_-]*)"\s*:', match))
    return list(dict.fromkeys(keys))


def _infer_rest_contracts_from_docs(docs: dict[str, Any]) -> dict[str, Any]:
    text = str(docs.get("llms_full_text") or docs.get("llms_text") or "")
    contracts: dict[str, dict[str, Any]] = {}
    curl_pattern = re.compile(
        r"curl\b(?P<command>.*?)(?=\n\s*(?:curl\b|[A-Za-z][\w -]{0,80}:|\#{1,6}\s|$))",
        flags=re.I | re.S,
    )
    for match in curl_pattern.finditer(text):
        command = "curl " + match.group("command").strip()
        if len(command) > 2000:
            command = command[:2000]
        method_match = re.search(r"(?:-X|--request)\s+([A-Za-z]+)", command)
        method = method_match.group(1).upper() if method_match else "GET"
        url_match = re.search(r"https?://[^\s'\"\\]+", command)
        if not url_match:
            continue
        parsed = urlparse(url_match.group(0))
        path = parsed.path.rstrip("/") or "/"
        body_keys = _json_body_keys(command)
        if not body_keys:
            continue
        key = f"{method} {path}"
        contracts[key] = {
            "method": method,
            "path": path,
            "required_body_fields": body_keys,
            "source": "curl_example",
        }
    return contracts


def _generate_execution_profile(docs: dict[str, Any]) -> dict[str, Any]:
    return {
        "source": "generated_from_ingested_docs",
        "cli_contracts": _infer_cli_contracts_from_docs(docs),
        "rest_contracts": _infer_rest_contracts_from_docs(docs),
    }


def _validate_cli_command_contract(arguments: dict[str, Any], profile: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    tokens = _command_tokens_for_validation(arguments)
    if len(tokens) < 2:
        return []
    contracts = (profile or {}).get("cli_contracts") if isinstance(profile, dict) else None
    if not isinstance(contracts, dict) or not contracts:
        return []
    root_candidates = []
    if len(tokens) > 1 and not tokens[1].startswith("-") and not _looks_like_url(tokens[1]):
        root_candidates.append(f"{tokens[0]} {tokens[1]}")
    root_candidates.append(tokens[0])
    root = next((candidate for candidate in root_candidates if candidate in contracts), None)
    if root is None:
        return []

    errors: list[dict[str, Any]] = []
    contract = contracts.get(root) if isinstance(contracts.get(root), dict) else {}
    boolean_flags = set(contract.get("boolean_flags") or [])
    value_flags = set(contract.get("value_flags") or [])
    for index, token in enumerate(tokens):
        flag_name = token.split("=", 1)[0] if token.startswith("--") else token
        if any(token.startswith(f"{flag}=") for flag in boolean_flags):
            flag = token.split("=", 1)[0]
            errors.append(
                {
                    "type": "cli_boolean_flag_value",
                    "argument": flag,
                    "message": (
                        f"`{root} {flag}` appears to be a boolean flag in the ingested docs. "
                        "Do not pass a filename or value unless the docs show that the flag accepts one."
                    ),
                }
            )
            continue
        if flag_name in value_flags:
            if "=" in token:
                continue
            next_token = tokens[index + 1] if index + 1 < len(tokens) else ""
            if not next_token or next_token.startswith("-"):
                errors.append(
                    {
                        "type": "cli_value_flag_missing_value",
                        "argument": flag_name,
                        "message": (
                            f"`{root} {flag_name}` appears to require a value in the ingested docs. "
                            "Pass a value or consult targeted docs/help before retrying."
                        ),
                    }
                )
            continue
        if token not in boolean_flags:
            continue
        next_token = tokens[index + 1] if index + 1 < len(tokens) else ""
        if next_token and not next_token.startswith("-") and not _looks_like_url(next_token):
            errors.append(
                {
                    "type": "cli_boolean_flag_value",
                    "argument": token,
                    "observed_value": next_token,
                    "message": (
                        f"`{root} {token}` appears to be a boolean flag in the ingested docs. "
                        "Do not pass a filename or value unless the docs show that the flag accepts one."
                    ),
                }
            )
    return errors


def _cli_contract_root_and_flags(arguments: dict[str, Any], profile: dict[str, Any] | None = None) -> tuple[str | None, set[str], set[str]]:
    tokens = _command_tokens_for_validation(arguments)
    contracts = (profile or {}).get("cli_contracts") if isinstance(profile, dict) else None
    if not isinstance(contracts, dict) or not tokens:
        return None, set(), set()
    root_candidates = []
    if len(tokens) > 1 and not tokens[1].startswith("-") and not _looks_like_url(tokens[1]):
        root_candidates.append(f"{tokens[0]} {tokens[1]}")
    root_candidates.append(tokens[0])
    root = next((candidate for candidate in root_candidates if candidate in contracts), None)
    flags = {token.split("=", 1)[0] for token in tokens if token.startswith("--")}
    if root is None:
        return None, flags, set()
    contract = contracts.get(root) if isinstance(contracts.get(root), dict) else {}
    known_flags = set(contract.get("boolean_flags") or []) | set(contract.get("value_flags") or [])
    return root, flags, known_flags


def _cli_command_is_covered_by_docs(arguments: dict[str, Any], profile: dict[str, Any] | None = None) -> bool:
    root, flags, known_flags = _cli_contract_root_and_flags(arguments, profile)
    if root is None:
        return False
    if flags - known_flags:
        return False
    return not _validate_cli_command_contract(arguments, profile)


def _http_endpoint_is_covered_by_docs(arguments: dict[str, Any], profile: dict[str, Any] | None = None) -> bool:
    contracts = (profile or {}).get("rest_contracts") if isinstance(profile, dict) else None
    if not isinstance(contracts, dict) or not contracts:
        return False
    method = str(arguments.get("method") or "GET").upper()
    url = str(arguments.get("url") or "")
    if not url:
        return False
    path = urlparse(url).path.rstrip("/") or "/"
    for candidate in contracts.values():
        if not isinstance(candidate, dict):
            continue
        candidate_method = str(candidate.get("method") or "").upper()
        candidate_path = str(candidate.get("path") or "").rstrip("/") or "/"
        if method == candidate_method and (path == candidate_path or path.endswith(candidate_path)):
            return not _validate_http_endpoint_contract(arguments, profile)
    return False


def _request_body_keys(body: Any) -> set[str]:
    if isinstance(body, dict):
        return {str(key) for key in body.keys()}
    if isinstance(body, str) and body.strip():
        try:
            parsed = json.loads(body)
        except json.JSONDecodeError:
            return set()
        if isinstance(parsed, dict):
            return {str(key) for key in parsed.keys()}
    return set()


def _validate_http_endpoint_contract(arguments: dict[str, Any], profile: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    contracts = (profile or {}).get("rest_contracts") if isinstance(profile, dict) else None
    if not isinstance(contracts, dict) or not contracts:
        return []
    method = str(arguments.get("method") or "GET").upper()
    url = str(arguments.get("url") or "")
    if not url:
        return []
    path = urlparse(url).path.rstrip("/") or "/"
    contract = None
    for candidate in contracts.values():
        if not isinstance(candidate, dict):
            continue
        candidate_method = str(candidate.get("method") or "").upper()
        candidate_path = str(candidate.get("path") or "").rstrip("/") or "/"
        if method == candidate_method and (path == candidate_path or path.endswith(candidate_path)):
            contract = candidate
            break
    if not contract:
        return []
    required = [str(item) for item in contract.get("required_body_fields") or [] if str(item)]
    if not required:
        return []
    observed = _request_body_keys(arguments.get("body"))
    missing = [field for field in required if field not in observed]
    if not missing:
        return []
    return [
        {
            "type": "missing_required_body_field",
            "argument": "body",
            "missing_fields": missing,
            "message": f"{method} {path} requires JSON body field(s): {', '.join(missing)} based on ingested docs.",
        }
    ]


def _contains_literal_shell_env(value: Any) -> bool:
    if isinstance(value, str):
        return bool(re.search(r"\$[A-Za-z_][A-Za-z0-9_]*|\$\{[A-Za-z_][A-Za-z0-9_]*\}", value))
    if isinstance(value, dict):
        return any(_contains_literal_shell_env(child) for child in value.values())
    if isinstance(value, list):
        return any(_contains_literal_shell_env(child) for child in value)
    return False


def _python_reads_stdin(code: str) -> bool:
    return bool(
        re.search(r"\bsys\.stdin\.read\s*\(", code)
        or re.search(r"\bjson\.load\s*\(\s*sys\.stdin\s*\)", code)
        or re.search(r"\binput\s*\(", code)
    )


def _stdin_from_step(run_record: dict[str, Any], step_number: int) -> str:
    result = _get_step_result(run_record, step_number) or {}
    artifacts = result.get("artifacts")
    if isinstance(artifacts, dict):
        for key in ("stdout_json", "stdout"):
            path = artifacts.get(key)
            if isinstance(path, str):
                return _resolve_workspace_path(run_record, path).read_text(encoding="utf-8")
    for key in ("stdout", "body", "text"):
        value = result.get(key)
        if isinstance(value, str):
            return value
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=True)
    raise ValueError(f"stdin_from_step={step_number} did not reference a step with readable stdout/body content.")


def _prepare_tool_runtime_arguments(
    tool_name: str,
    arguments: dict[str, Any],
    *,
    run_record: dict[str, Any],
) -> dict[str, Any]:
    prepared = dict(arguments)
    if tool_name == "run_http":
        if _contains_literal_shell_env(prepared.get("headers")) or _contains_literal_shell_env(prepared.get("body")):
            raise ValueError("run_http does not expand shell variables. Use headers_from_env or pass the resolved credential.")
    if tool_name == "run_python":
        code = str(prepared.get("code") or "")
        stdin_from_step = prepared.pop("stdin_from_step", None)
        stdin_path = prepared.pop("stdin_path", None)
        if stdin_from_step is not None:
            prepared["stdin_text"] = _stdin_from_step(run_record, int(stdin_from_step))
        elif stdin_path is not None:
            prepared["stdin_text"] = _resolve_workspace_path(run_record, str(stdin_path)).read_text(encoding="utf-8")
        elif _python_reads_stdin(code):
            raise ValueError("This run_python call reads from stdin, but no stdin was provided. Use stdin_from_step or stdin_path.")
    return prepared


def _schema_feedback(tool_name: str, errors: list[dict[str, Any]]) -> str:
    return (
        "Tool call validation failed before execution. No external tool was run.\n"
        + json.dumps(
            {
                "tool": tool_name,
                "errors": errors,
                "valid_examples": {
                    "run_cli_list": {"command": ["example-cli", "command", "https://example.com"]},
                    "run_cli_shell": {"command": "example-cli command https://example.com", "shell": True},
                    "run_python": {"code": "print('hello')"},
                    "run_http": {"method": "GET", "url": "https://example.com"},
                },
            },
            ensure_ascii=True,
            indent=2,
        )
    )


def _get_step_result(run_record: dict[str, Any], step_number: int) -> dict[str, Any] | None:
    for step in run_record.get("steps") or []:
        if int(step.get("step") or -1) == step_number:
            result = step.get("tool_result")
            return result if isinstance(result, dict) else None
    return None


def _parse_json_reference(value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return value
    if isinstance(value, str):
        return json.loads(value)
    raise ValueError("reference does not contain JSON")


def _read_artifact_reference(run_record: dict[str, Any], name: str) -> str | None:
    artifacts = run_record.get("artifacts") or {}
    path = artifacts.get(name)
    if not isinstance(path, str):
        return None
    try:
        return _resolve_workspace_path(run_record, path).read_text(encoding="utf-8")
    except OSError:
        return None


def _resolve_workspace_path(run_record: dict[str, Any], path: str) -> Path:
    candidate = Path(path).expanduser()
    if candidate.is_absolute():
        return candidate
    workspace = run_record.get("workspace")
    if isinstance(workspace, str) and workspace:
        workspace_path = Path(workspace).expanduser()
        joined = workspace_path / candidate
        if joined.exists() or path.startswith(".gauntlet_artifacts/"):
            return joined
    return candidate


def _artifact_path_for_step(run_record: dict[str, Any], step_number: int, field: str) -> str | None:
    artifact_map = run_record.get("artifact_map") or {}
    record = artifact_map.get(str(step_number)) or artifact_map.get(step_number)
    if isinstance(record, dict):
        key = {
            "stdout_json": "stdout_json_path",
            "json": "stdout_json_path",
            "stdout": "stdout_path",
            "stderr": "stderr_path",
            "body": "body_path",
            "text": "text_path",
        }.get(field, f"{field}_path")
        value = record.get(key)
        if isinstance(value, str):
            return value
    artifacts = run_record.get("artifacts") or {}
    legacy_key = f"step_{step_number}_{'json' if field in {'stdout_json', 'json'} else field}"
    value = artifacts.get(legacy_key)
    return value if isinstance(value, str) else None


def _resolve_reference_token(token: str, run_record: dict[str, Any]) -> Any:
    artifact_step_match = re.fullmatch(r"\$steps\[(\d+)\]\.artifacts\.(stdout_json|stdout|stderr|body|text)", token)
    if artifact_step_match:
        path = _artifact_path_for_step(run_record, int(artifact_step_match.group(1)), artifact_step_match.group(2))
        if isinstance(path, str):
            return path
        return token

    step_match = re.fullmatch(r"\$steps\[(\d+)\]\.(stdout|stderr|json|result)", token)
    if step_match:
        result = _get_step_result(run_record, int(step_match.group(1))) or {}
        field = step_match.group(2)
        if field == "json":
            if isinstance(result.get("artifacts"), dict):
                json_path = result["artifacts"].get("stdout_json")
                if isinstance(json_path, str):
                    return json.loads(_resolve_workspace_path(run_record, json_path).read_text(encoding="utf-8"))
            return _parse_json_reference(result.get("stdout") or result.get("body") or result.get("result"))
        return result.get(field)

    artifact_match = re.fullmatch(r"\$artifacts\.([A-Za-z0-9_.-]+)", token)
    if artifact_match:
        content = _read_artifact_reference(run_record, artifact_match.group(1))
        return content if content is not None else token
    return token


def _resolve_argument_references(value: Any, run_record: dict[str, Any]) -> Any:
    if isinstance(value, dict):
        return {key: _resolve_argument_references(child, run_record) for key, child in value.items()}
    if isinstance(value, list):
        return [_resolve_argument_references(child, run_record) for child in value]
    if not isinstance(value, str):
        return value
    stripped = value.strip()
    token_pattern = r"\$steps\[\d+\]\.(?:artifacts\.(?:stdout_json|stdout|stderr|body|text)|stdout|stderr|json|result)|\$artifacts\.[A-Za-z0-9_.-]+"
    if re.fullmatch(token_pattern, stripped):
        try:
            return _resolve_reference_token(stripped, run_record)
        except Exception:
            return value

    def _replace(match: re.Match[str]) -> str:
        try:
            resolved = _resolve_reference_token(match.group(0), run_record)
        except Exception:
            return match.group(0)
        if isinstance(resolved, str):
            return resolved
        return json.dumps(resolved, ensure_ascii=True)

    return re.sub(token_pattern, _replace, value)


def _extract_public_urls(value: Any) -> list[str]:
    text = json.dumps(value, ensure_ascii=True) if isinstance(value, (dict, list)) else str(value or "")
    urls: list[str] = []
    pattern = r"https?://[^\s\"'<>),]+|(?<!:)//[A-Za-z0-9.-]+\.[A-Za-z]{2,}/[^\s\"'<>),]+"
    for match in re.findall(pattern, text):
        urls.append(f"https:{match}" if match.startswith("//") else match)
    return list(dict.fromkeys(urls))


def _extract_file_refs(value: Any) -> list[str]:
    text = json.dumps(value, ensure_ascii=True) if isinstance(value, (dict, list)) else str(value or "")
    pattern = r"(?:\.gauntlet_artifacts/|[\w./-]+/)?[\w.-]+\.(?:png|jpg|jpeg|webp|pdf|zip|json|txt)"
    refs: list[str] = []
    for match in re.findall(pattern, text, flags=re.I):
        if match.startswith(("http://", "https://", "//")):
            continue
        refs.append(match)
    return list(dict.fromkeys(refs))


def _json_shape_summary(value: Any, *, depth: int = 2) -> Any:
    if isinstance(value, dict):
        if depth <= 0:
            return f"object({len(value)})"
        summary: dict[str, Any] = {}
        for key, child in list(value.items())[:12]:
            if isinstance(child, (dict, list)):
                summary[str(key)] = _json_shape_summary(child, depth=depth - 1)
            else:
                summary[str(key)] = type(child).__name__
        if len(value) > 12:
            summary["..."] = f"{len(value) - 12} more keys"
        return summary
    if isinstance(value, list):
        if not value:
            return "array(0)"
        first = _json_shape_summary(value[0], depth=depth - 1) if depth > 0 else type(value[0]).__name__
        return {"array_length": len(value), "first_item": first}
    return type(value).__name__


def _json_leaf_paths(value: Any, *, prefix: str = "", limit: int = 32) -> list[str]:
    paths: list[str] = []

    def visit(child: Any, path: str) -> None:
        if len(paths) >= limit:
            return
        if isinstance(child, dict):
            if not child and path:
                paths.append(f"{path}: object(0)")
            for key, item in child.items():
                visit(item, f"{path}.{key}" if path else str(key))
            return
        if isinstance(child, list):
            if not child:
                paths.append(f"{path}: array(0)")
                return
            visit(child[0], f"{path}[]" if path else "[]")
            return
        paths.append(f"{path}: {type(child).__name__}")

    visit(value, prefix)
    return paths


def _materialize_large_outputs(
    *,
    tool_name: str,
    tool_result: dict[str, Any],
    step: int,
    workspace_dir: str | None,
    run_record: dict[str, Any],
) -> dict[str, str]:
    if not workspace_dir:
        return {}
    artifact_dir = Path(workspace_dir).expanduser() / ".gauntlet_artifacts"
    artifacts: dict[str, str] = {}
    step_artifact_record: dict[str, Any] = {
        "step_id": step,
        "tool_name": tool_name,
        "working_directory": workspace_dir,
        "files": [],
        "public_urls": [],
    }
    for field in ("stdout", "stderr", "body", "text"):
        value = tool_result.get(field)
        if value in (None, ""):
            continue
        artifact_dir.mkdir(parents=True, exist_ok=True)
        if isinstance(value, (dict, list)):
            path = artifact_dir / f"step_{step}_{tool_name}_{field}.json"
            path.write_text(json.dumps(value, ensure_ascii=True, indent=2), encoding="utf-8")
            display_path = f".gauntlet_artifacts/{path.name}"
            step_artifact_record[f"{field}_json_shape"] = _json_shape_summary(value)
            step_artifact_record[f"{field}_json_paths"] = _json_leaf_paths(value)
        else:
            text_value = str(value)
            path = artifact_dir / f"step_{step}_{tool_name}_{field}.txt"
            path.write_text(text_value, encoding="utf-8")
            display_path = f".gauntlet_artifacts/{path.name}"
        artifacts[field] = display_path
        step_artifact_record[f"{field}_path"] = display_path
        run_record.setdefault("artifacts", {})[f"step_{step}_{field}"] = display_path
        step_artifact_record["files"].append(display_path)
        step_artifact_record["public_urls"].extend(_extract_public_urls(value))
        step_artifact_record["files"].extend(_extract_file_refs(value))
        if field == "stdout" and isinstance(value, str):
            stripped = value.strip()
            if stripped.startswith(("{", "[")):
                try:
                    parsed = json.loads(stripped)
                except json.JSONDecodeError:
                    parsed = None
                if parsed is not None:
                    json_path = artifact_dir / f"step_{step}_{tool_name}_{field}.json"
                    json_path.write_text(json.dumps(parsed, ensure_ascii=True, indent=2), encoding="utf-8")
                    json_display_path = f".gauntlet_artifacts/{json_path.name}"
                    artifacts["stdout_json"] = json_display_path
                    step_artifact_record["stdout_json_path"] = json_display_path
                    step_artifact_record["stdout_json_shape"] = _json_shape_summary(parsed)
                    step_artifact_record["stdout_json_paths"] = _json_leaf_paths(parsed)
                    step_artifact_record["files"].append(json_display_path)
                    run_record.setdefault("artifacts", {})[f"step_{step}_json"] = json_display_path
        if field == "body" and isinstance(value, (dict, list)):
            step_artifact_record["body_json_path"] = display_path
    if artifacts:
        tool_result["artifacts"] = artifacts
    step_artifact_record["files"] = list(dict.fromkeys(str(item) for item in step_artifact_record["files"] if item))
    step_artifact_record["public_urls"] = list(dict.fromkeys(str(item) for item in step_artifact_record["public_urls"] if item))
    run_record.setdefault("artifact_map", {})[str(step)] = step_artifact_record
    return artifacts


def _is_transient_tool_failure(tool_result: dict[str, Any]) -> bool:
    if tool_result.get("ok") is not False:
        return False
    status = tool_result.get("status")
    if isinstance(status, int):
        if status in {401, 403, 400, 404, 422}:
            return False
        if status in {500, 502, 503, 504}:
            return True
    text = " ".join(str(tool_result.get(key) or "") for key in ("error", "stdout", "stderr", "body")).lower()
    semantic_needles = (
        "401",
        "403",
        "unauthorized",
        "forbidden",
        "invalid argument",
        "valueerror",
        "typeerror",
        "schema",
        "missing required",
    )
    if any(needle in text for needle in semantic_needles):
        return False
    transient_needles = (
        "500",
        "502",
        "503",
        "504",
        "internal server error",
        "timeout",
        "timed out",
        "connection reset",
        "connection refused",
        "temporarily unavailable",
        "websocket",
        "cdp",
        "connect_over_cdp",
    )
    return any(needle in text for needle in transient_needles)


def _tool_result_text(tool_result: dict[str, Any]) -> str:
    return "\n".join(str(tool_result.get(key) or "") for key in ("error", "stdout", "stderr", "body", "text"))


def _error_correction_for_result(tool_result: dict[str, Any]) -> tuple[str | None, str | None]:
    text = _tool_result_text(tool_result).lower()
    if "$steps[" in text and ("filenotfounderror" in text or "no such file or directory" in text):
        return (
            "artifact-reference-error",
            "Placeholder syntax is not supported in executed code. Use the literal artifact path from Available artifacts.",
        )
    if "401" in text and "$steel_api_key" in text:
        return (
            "env-expansion-error",
            "run_http does not expand shell variables. Use headers_from_env or run_cli with shell=true.",
        )
    if "timed out" in text and "stdin" in text:
        return (
            "stdin-handoff-error",
            "No stdin was provided. Use stdin_from_step or read the artifact file.",
        )
    if "empty" in text and ("title" in text or "link" in text):
        return (
            "raw-output-inspection-required",
            "Parsing returned empty titles or links. Inspect the raw artifact shape before retrying: top-level JSON keys, where HTML/text is stored, whether links include href values, and whether expected fields exist.",
        )
    if "jsondecodeerror" in text or "keyerror" in text or "html content not found" in text or "missing keys" in text:
        return (
            "raw-output-inspection-required",
            "Parsing failed. Inspect the raw artifact shape before retrying: top-level JSON keys, where HTML/text is stored, whether links include href values, and whether expected fields exist.",
        )
    return None, None


def _uncertainty_resolution_for_result(tool_name: str, tool_result: dict[str, Any]) -> dict[str, Any] | None:
    if tool_result.get("ok") is not False:
        return None
    text = _tool_result_text(tool_result).lower()
    error_type = str(tool_result.get("error_type") or "").lower()
    category: str | None = None
    allowed = ["ground_docs"]
    if any(
        needle in text
        for needle in (
            "unexpected argument",
            "unexpected value",
            "unknown option",
            "unrecognized option",
            "no such option",
            "requires a value",
            "invalid choice",
            "usage:",
        )
    ):
        category = "cli_usage"
        allowed.append("help_command")
    elif (
        "keyerror" in text
        or "jsondecodeerror" in text
        or "missing keys" in text
        or "html content not found" in text
        or "string indices must be integers" in text
        or error_type in {"keyerror", "jsondecodeerror"}
    ):
        category = "output_schema"
        allowed.append("raw_artifact_inspection")
    elif "$steps[" in text or "filenotfounderror" in text or "no such file or directory" in text:
        category = "artifact_reference"
        allowed.append("raw_artifact_inspection")
    elif (
        str(tool_result.get("status") or "") in {"400", "401", "403"}
        or any(needle in text for needle in ("unauthorized", "forbidden", "missing api key", "missing header", "missing required"))
    ):
        category = "auth_or_contract"
        allowed.extend(["check_credentials", "inspect_environment"])
    if not category:
        return None
    return {
        "category": category,
        "reason": (
            "The previous tool failed in a way that suggests an ungrounded assumption about command syntax, "
            "output schema, credentials, or artifact references."
        ),
        "failing_tool": tool_name,
        "error_type": tool_result.get("error_type"),
        "error": tool_result.get("error"),
        "allowed_next_actions": list(dict.fromkeys(allowed)),
    }


def _is_help_command(tool_name: str, arguments: dict[str, Any]) -> bool:
    if tool_name != "run_cli":
        return False
    tokens = _command_tokens_for_validation(arguments)
    if not tokens:
        return False
    return "--help" in tokens or "-h" in tokens or "help" in tokens


def _command_root_from_arguments(arguments: dict[str, Any]) -> str | None:
    return _command_root_from_tokens(_command_tokens_for_validation(arguments))


def _help_command_root(arguments: dict[str, Any]) -> str | None:
    tokens = _command_tokens_for_validation(arguments)
    if not tokens:
        return None
    filtered = [token for token in tokens if token not in {"--help", "-h", "help"}]
    return _command_root_from_tokens(filtered or tokens)


def _is_raw_artifact_inspection(tool_name: str, arguments: dict[str, Any]) -> bool:
    if tool_name == "run_python":
        code = str(arguments.get("code") or "").lower()
        return ".gauntlet_artifacts/" in code and any(
            needle in code
            for needle in (
                "json.load",
                "json.loads",
                ".keys(",
                "type(",
                "len(",
                "print(",
                "read_text(",
                "open(",
            )
        )
    if tool_name == "run_cli":
        tokens = _command_tokens_for_validation(arguments)
        if not tokens:
            return False
        inspection_commands = {"cat", "head", "tail", "file", "wc", "ls", "sed"}
        return tokens[0] in inspection_commands and any(".gauntlet_artifacts/" in token for token in tokens[1:])
    return False


def _run_python_is_product_execution(arguments: dict[str, Any]) -> bool:
    code = str(arguments.get("code") or "").lower()
    product_execution_needles = (
        "requests.",
        "httpx.",
        "urllib.request",
        "aiohttp",
        "subprocess.",
        "os.system",
        "popen(",
        "import steel",
        "from steel",
        "steel(",
        "steel.",
        "api_key",
        "authorization",
        "bearer ",
        "headers_from_env",
    )
    return any(needle in code for needle in product_execution_needles)


def _run_python_is_local_analysis(arguments: dict[str, Any]) -> bool:
    code = str(arguments.get("code") or "").lower()
    if _run_python_is_product_execution(arguments):
        return False
    local_input_markers = (
        ".gauntlet_artifacts/",
        "stdin_path",
        "stdin_from_step",
        "json.load",
        "json.loads",
        "open(",
        "read_text(",
    )
    analysis_markers = (
        "print(",
        ".keys(",
        "type(",
        "len(",
        "json.load",
        "json.loads",
        "split(",
        "get(",
    )
    return any(marker in code for marker in local_input_markers) and any(marker in code for marker in analysis_markers)


def _is_uncertainty_resolution_action(
    tool_name: str,
    arguments: dict[str, Any],
    pending: dict[str, Any] | None,
) -> bool:
    if not pending:
        return True
    allowed = set(str(item) for item in pending.get("allowed_next_actions") or [])
    if tool_name == "ground_docs" and "ground_docs" in allowed:
        return True
    if tool_name == "check_credentials" and "check_credentials" in allowed:
        return True
    if tool_name == "inspect_environment" and "inspect_environment" in allowed:
        return True
    if "help_command" in allowed and _is_help_command(tool_name, arguments):
        return True
    if "raw_artifact_inspection" in allowed and _is_raw_artifact_inspection(tool_name, arguments):
        return True
    return False


def _uncertainty_validation_errors(
    tool_name: str,
    arguments: dict[str, Any],
    runtime: dict[str, Any],
) -> list[dict[str, Any]]:
    pending = runtime.get("pending_uncertainty_resolution")
    if not isinstance(pending, dict) or not pending:
        return []
    if _is_uncertainty_resolution_action(tool_name, arguments, pending):
        return []
    return [
        {
            "type": "uncertainty_resolution_required",
            "tool": tool_name,
            "message": (
                "The previous failure indicates the agent may be guessing. Before another execution attempt, "
                "reduce uncertainty with one of the allowed next actions."
            ),
            "pending_uncertainty_resolution": pending,
        }
    ]


def _grounded_cli_roots(run_record: dict[str, Any]) -> set[str]:
    roots: set[str] = set()
    for step in run_record.get("steps") or []:
        tool = step.get("tool") or {}
        result = step.get("tool_result") or {}
        if result.get("ok") is False:
            continue
        tool_name = tool.get("name")
        arguments = tool.get("arguments")
        if not isinstance(arguments, dict):
            arguments = {}
        if tool_name == "ground_docs":
            roots.add("*")
        if tool_name == "run_cli" and _is_help_command("run_cli", arguments):
            root = _help_command_root(arguments)
            if root:
                roots.add(root)
    return roots


def _has_prior_grounding_or_help_for_tool(
    tool_name: str,
    arguments: dict[str, Any],
    run_record: dict[str, Any],
) -> bool:
    roots = _grounded_cli_roots(run_record)
    if "*" in roots:
        return True
    if tool_name != "run_cli":
        return False
    root = _command_root_from_arguments(arguments)
    return bool(root and root in roots)


def _initial_grounding_validation_errors(
    tool_name: str,
    arguments: dict[str, Any],
    *,
    run_record: dict[str, Any],
    generated_profile: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    if tool_name in {"read_docs", "read_doc", "ground_docs", "check_credentials", "inspect_environment"}:
        return []
    if _has_prior_grounding_or_help_for_tool(tool_name, arguments, run_record):
        return []
    if tool_name == "run_cli":
        if _is_help_command(tool_name, arguments):
            return []
        if _cli_command_is_covered_by_docs(arguments, generated_profile):
            return []
        root, flags, known_flags = _cli_contract_root_and_flags(arguments, generated_profile)
        unknown_flags = sorted(flags - known_flags)
        detail = (
            f"Command root {root!r} has unverified flag(s): {', '.join(unknown_flags)}."
            if root and unknown_flags
            else "No docs-derived contract covers this command shape."
        )
    elif tool_name == "run_http":
        if _http_endpoint_is_covered_by_docs(arguments, generated_profile):
            return []
        detail = "No docs-derived REST contract covers this request shape."
    elif tool_name == "run_python":
        if _run_python_is_local_analysis(arguments):
            return []
        detail = "This Python execution appears capable of product/API/SDK execution and has no prior targeted documentation grounding."
    else:
        detail = "This execution tool has no prior targeted documentation grounding."
    return [
        {
            "type": "initial_grounding_required",
            "tool": tool_name,
            "message": (
                "Before the first nontrivial product execution, use `ground_docs` or a CLI help command unless "
                "the exact tool/API shape is already covered by ingested documentation contracts. "
                f"{detail}"
            ),
        }
    ]


def _update_uncertainty_resolution_state(
    *,
    run_record: dict[str, Any],
    config: AgentRunConfig,
    step: int,
    tool_name: str,
    arguments: dict[str, Any],
    tool_result: dict[str, Any],
) -> None:
    runtime = _runtime(run_record, config)
    pending = runtime.get("pending_uncertainty_resolution")
    if isinstance(pending, dict) and pending and _is_uncertainty_resolution_action(tool_name, arguments, pending) and tool_result.get("ok") is True:
        runtime["pending_uncertainty_resolution"] = None
        runtime.setdefault("events", []).append(
            {
                "type": "uncertainty_resolution_cleared",
                "at": _utc_now_iso(),
                "step": step,
                "tool": tool_name,
            }
        )
    next_pending = _uncertainty_resolution_for_result(tool_name, tool_result)
    if next_pending:
        runtime["pending_uncertainty_resolution"] = next_pending
        runtime.setdefault("events", []).append(
            {
                "type": "uncertainty_resolution_required",
                "at": _utc_now_iso(),
                "step": step,
                **next_pending,
            }
        )


def _record_error_correction(
    *,
    run_record: dict[str, Any],
    config: AgentRunConfig,
    step: int,
    tool_result: dict[str, Any],
    transcript: list[str],
) -> None:
    pattern, message = _error_correction_for_result(tool_result)
    if not pattern or not message:
        return
    runtime = _runtime(run_record, config)
    counts = runtime.setdefault("error_pattern_counts", {})
    counts[pattern] = int(counts.get(pattern) or 0) + 1
    if pattern == "raw-output-inspection-required" or counts[pattern] >= 2:
        correction = f"Harness correction after step {step}:\n{message}\nDo not repeat the same invalid tool call."
        transcript.append(correction)
        runtime.setdefault("events", []).append(
            {
                "type": "repeated_error_correction",
                "at": _utc_now_iso(),
                "step": step,
                "pattern": pattern,
                "message": message,
            }
        )


def _call_tool(
    tool_name: str,
    arguments: dict[str, Any],
    *,
    config: AgentRunConfig,
    docs: dict[str, Any],
    previous_tool_result: dict[str, Any] | None,
    workspace_dir: str | None,
    run_record: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    if tool_name == "run_http" and (
        _contains_literal_shell_env(arguments.get("headers")) or _contains_literal_shell_env(arguments.get("body"))
    ):
        raise ValueError("run_http does not expand shell variables. Use headers_from_env or pass the resolved credential.")
    final_arguments = _sanitize_tool_arguments(arguments)
    final_arguments = _resolve_argument_references(final_arguments, run_record)
    if tool_name in {"run_cli", "run_python"} and workspace_dir and not final_arguments.get("cwd"):
        final_arguments["cwd"] = workspace_dir
    final_arguments = _prepare_tool_runtime_arguments(tool_name, final_arguments, run_record=run_record)

    if tool_name == "read_docs":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.read_docs, final_arguments)
        tool_result = asyncio.run(agent_tools.read_docs(**filtered_arguments))
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "read_doc":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.read_doc, final_arguments)
        tool_result = asyncio.run(agent_tools.read_doc(**filtered_arguments))
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "ground_docs":
        if final_arguments.get("llms_source") in {None, "", "llms.txt"}:
            final_arguments["llms_source"] = docs.get("llms_source")
        if final_arguments.get("llms_full_source") in {None, "", "llms-full.txt"}:
            final_arguments["llms_full_source"] = docs.get("llms_full_source")
        final_arguments.setdefault("tool_schemas", TOOL_DESCRIPTIONS)
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.ground_docs, final_arguments)
        tool_result = asyncio.run(agent_tools.ground_docs(**filtered_arguments))
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "run_http":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.run_http, final_arguments)
        tool_result = asyncio.run(agent_tools.run_http(**filtered_arguments))
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "run_cli":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.run_cli, final_arguments)
        tool_result = agent_tools.run_cli(**filtered_arguments)
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "run_sdk":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.run_sdk, final_arguments)
        tool_result = agent_tools.run_sdk(**filtered_arguments)
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "run_python":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.run_python, final_arguments)
        tool_result = agent_tools.run_python(**filtered_arguments)
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "check_credentials":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.check_credentials, final_arguments)
        tool_result = agent_tools.check_credentials(**filtered_arguments)
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    if tool_name == "inspect_environment":
        filtered_arguments, ignored = _filter_supported_kwargs(agent_tools.inspect_environment, final_arguments)
        tool_result = agent_tools.inspect_environment(**filtered_arguments)
        if ignored:
            tool_result.setdefault("ignored_arguments", ignored)
        return tool_result, filtered_arguments
    raise ProviderError(f"Unsupported tool requested by agent: {tool_name}")


def _call_tool_with_retries(
    tool_name: str,
    arguments: dict[str, Any],
    *,
    config: AgentRunConfig,
    docs: dict[str, Any],
    previous_tool_result: dict[str, Any] | None,
    workspace_dir: str | None,
    run_record: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    retries: list[dict[str, Any]] = []
    last_result: dict[str, Any] | None = None
    last_arguments: dict[str, Any] | None = None
    for attempt in range(config.transient_retry_attempts + 1):
        tool_result, final_arguments = _call_tool(
            tool_name,
            arguments,
            config=config,
            docs=docs,
            previous_tool_result=previous_tool_result,
            workspace_dir=workspace_dir,
            run_record=run_record,
        )
        last_result = tool_result
        last_arguments = final_arguments
        if attempt >= config.transient_retry_attempts or not _is_transient_tool_failure(tool_result):
            break
        retries.append(
            {
                "attempt": attempt + 1,
                "error_type": tool_result.get("error_type"),
                "error": tool_result.get("error"),
                "status": tool_result.get("status"),
                "exit_code": tool_result.get("exit_code"),
                "reason": "transient_failure",
            }
        )
        time.sleep(min(0.5 * (attempt + 1), 2.0))
    assert last_result is not None and last_arguments is not None
    return last_result, last_arguments, retries


def run_agent_task(config: AgentRunConfig) -> str:
    started_monotonic = time.monotonic()

    if config.resume_from_run_record:
        run_record = _load_run_record(config.resume_from_run_record)
        if run_record.get("status") == "completed" and isinstance(run_record.get("final_response"), str):
            return str(run_record["final_response"])

        previous_failure = run_record.get("failure")
        if previous_failure:
            run_record.setdefault("failure_history", []).append(previous_failure)
        run_record["status"] = "running"
        run_record["run_status"] = "running"
        run_record["failure"] = None
        run_record.pop("finished_at", None)
        run_record["resumed_at"] = _utc_now_iso()
        task = str(run_record.get("task") or config.task)
        persona_value = run_record.get("persona")
        persona = None if persona_value in {None, "default"} else str(persona_value)
        llms_source = config.llms_source or run_record.get("llms_source")
        llms_full_source = config.llms_full_source or run_record.get("llms_full_source")
    else:
        task = config.task
        persona = config.persona
        llms_source = config.llms_source
        llms_full_source = config.llms_full_source
        run_record = {
            "status": "running",
            "run_status": "running",
            "task_status": None,
            "provider": config.provider.name,
            "model": config.provider.model,
            "task": task,
            "prompt_id": config.prompt_id,
            "run_key": f"{config.prompt_id}_{persona or 'default'}",
            "batch_prompt_count": config.batch_prompt_count,
            "persona": persona or "default",
            "llms_source": llms_source,
            "llms_full_source": llms_full_source,
            "max_steps": config.max_steps,
            "max_restarts": config.max_restarts,
            "max_format_retries": config.max_format_retries,
            "started_at": _utc_now_iso(),
            "docs": {},
            "steps": [],
            "final_response": None,
            "failure": None,
            "runtime": _new_runtime_record(config),
        }

    workspace_dir = run_record.get("workspace") or _run_workspace_path(
        config.run_record_path,
        str(run_record.get("run_key") or f"{config.prompt_id}_{config.persona or 'default'}"),
    )
    run_record["workspace"] = workspace_dir
    _prepare_workspace(workspace_dir, clean=not bool(config.resume_from_run_record))
    run_record["environment"] = environment_metadata()

    runtime = _runtime(run_record, config)
    runtime["max_restarts"] = config.max_restarts
    runtime["budget"] = _new_runtime_record(config)["budget"]
    runtime.setdefault("events", []).append(
        {
            "type": "run_started" if not config.resume_from_run_record else "run_resumed",
            "at": _utc_now_iso(),
            "step_count": len(run_record.get("steps") or []),
        }
    )

    docs = asyncio.run(
        agent_tools.read_docs(
            llms_source=llms_source,
            llms_full_source=llms_full_source,
        )
    )
    if not docs.get("ok"):
        run_record["status"] = "failed"
        run_record["run_status"] = "crashed"
        run_record["task_status"] = "failure"
        run_record["failure"] = {
            "type": "docs_load_failed",
            "error": docs.get("error"),
        }
        run_record["finished_at"] = _utc_now_iso()
        _checkpoint_run_record(run_record, config, started_monotonic)
        raise ProviderError(f"Could not load docs: {docs.get('error')}")

    run_record["docs"] = {
        "ok": docs.get("ok"),
        "llms_source": docs.get("llms_source"),
        "llms_full_source": docs.get("llms_full_source"),
        "manifest_section_count": docs.get("llms_manifest", {}).get("section_count"),
    }
    run_record["generated_profile"] = _generate_execution_profile(docs)
    run_record["llms_source"] = docs.get("llms_source") or llms_source
    run_record["llms_full_source"] = docs.get("llms_full_source") or llms_full_source
    run_record["max_steps"] = config.max_steps
    run_record["max_restarts"] = config.max_restarts
    run_record["max_format_retries"] = config.max_format_retries

    transcript, previous_tool_result, active_doc_binding = _rebuild_transcript_from_steps(
        task,
        persona,
        docs,
        run_record.get("steps") or [],
    )
    _checkpoint_run_record(run_record, config, started_monotonic)

    task_spec = infer_task_spec(task)
    steps_in_attempt = 0
    schema_corrections = 0
    while True:
        budget_failure = _budget_failure(run_record, config, started_monotonic)
        if budget_failure is not None:
            run_record["status"] = "failed"
            run_record["run_status"] = "crashed"
            run_record["task_status"] = "blocked_by_provider" if parse_error.get("stage") == "model_call" else "schema_mismatch"
            run_record["failure"] = budget_failure
            run_record["finished_at"] = _utc_now_iso()
            _checkpoint_run_record(run_record, config, started_monotonic)
            raise ProviderError(f"Run budget exceeded: {budget_failure['budget']}")

        if steps_in_attempt >= config.max_steps:
            restart_count = int(runtime.get("restart_count") or 0)
            if restart_count < config.max_restarts:
                restart_count += 1
                runtime["restart_count"] = restart_count
                runtime["attempt"] = restart_count + 1
                steps_in_attempt = 0
                event = {
                    "type": "checkpoint_restart",
                    "at": _utc_now_iso(),
                    "restart_count": restart_count,
                    "step_count": len(run_record.get("steps") or []),
                    "reason": "max_steps_exceeded",
                }
                runtime.setdefault("events", []).append(event)
                transcript.append(
                    "Harness checkpoint restart:\n"
                    f"The previous segment reached the per-attempt limit of {config.max_steps} steps. "
                    f"This is restart {restart_count} of {config.max_restarts}. Continue from the recorded state above. "
                    "Do not repeat completed tool calls unless new evidence requires it. If the task is already sufficiently resolved, return a final answer."
                )
                _checkpoint_run_record(run_record, config, started_monotonic)
                continue

            run_record["status"] = "failed"
            run_record["run_status"] = "timeout"
            run_record["task_status"] = "failure"
            run_record["failure"] = {
                "type": "max_steps_exceeded",
                "max_steps": config.max_steps,
                "max_restarts": config.max_restarts,
                "restart_count": restart_count,
                "total_steps": len(run_record.get("steps") or []),
            }
            run_record["finished_at"] = _utc_now_iso()
            _checkpoint_run_record(run_record, config, started_monotonic)
            raise ProviderError(
                f"Agent exceeded {config.max_steps} steps across {config.max_restarts + 1} attempt(s) without returning a final answer"
            )

        step = len(run_record.get("steps") or []) + 1
        steps_in_attempt += 1
        active_binding_block = _render_active_doc_binding(active_doc_binding)
        execution_state_block = _render_execution_state(run_record, config, task_spec)
        effective_transcript = transcript + [execution_state_block]
        if active_binding_block is not None:
            effective_transcript.append(active_binding_block)
        _graph_checkpoint(run_record, config, node="agent_decision", step=step, status="started")
        response, parse_error, model_usage = _send_and_parse_response(config, effective_transcript, step)
        _graph_checkpoint(
            run_record,
            config,
            node="agent_decision",
            step=step,
            status="failed" if parse_error else "completed",
            payload={"response_type": response.get("type") if isinstance(response, dict) else None},
        )
        _add_model_usage(run_record, config, model_usage)
        step_record: dict[str, Any] = {
            "step": step,
            "attempt": int(runtime.get("attempt") or 1),
            "restart_count": int(runtime.get("restart_count") or 0),
            "response": response,
            "parse_error": parse_error,
            "model_usage": model_usage,
            "tool": None,
            "tool_result": None,
        }
        if parse_error is not None:
            _debug_log(config, f"step {step} parse error", parse_error)
            run_record["steps"].append(step_record)
            run_record["status"] = "failed"
            run_record["run_status"] = "crashed"
            run_record["task_status"] = "failure"
            run_record["failure"] = {
                "type": "model_call_failed" if parse_error.get("stage") == "model_call" else "response_parse_failed",
                "step": step,
                **parse_error,
            }
            run_record["finished_at"] = _utc_now_iso()
            _checkpoint_run_record(run_record, config, started_monotonic)
            raise ProviderError(parse_error["error"])

        assert response is not None
        response_type = response.get("type")

        if response_type == "final":
            final_response = response.get("response")
            if isinstance(final_response, (dict, list)):
                final_response = json.dumps(final_response, ensure_ascii=False, indent=2)
            elif final_response is not None and not isinstance(final_response, str):
                final_response = str(final_response)
            if not isinstance(final_response, str) or not final_response.strip():
                run_record["steps"].append(step_record)
                run_record["status"] = "failed"
                run_record["run_status"] = "crashed"
                run_record["task_status"] = "failure"
                run_record["failure"] = {
                    "type": "empty_final_response",
                    "step": step,
                }
                run_record["finished_at"] = _utc_now_iso()
                _checkpoint_run_record(run_record, config, started_monotonic)
                raise ProviderError("Agent final response was empty")
            run_record["steps"].append(step_record)
            run_record["status"] = "completed"
            run_record["run_status"] = "completed"
            run_record["final_response"] = final_response.strip()
            _graph_checkpoint(run_record, config, node="final_validation", step=step, status="started")
            try:
                from gauntlet.layer3.verify_task import verify_task

                task_verification = verify_task(run_record)
                run_record["task_status"] = task_verification.get("task_status")
                run_record["task_verification"] = task_verification
                _graph_checkpoint(
                    run_record,
                    config,
                    node="final_validation",
                    step=step,
                    status="completed",
                    payload={"task_status": run_record.get("task_status")},
                )
            except Exception as verification_error:
                run_record["task_status"] = "schema_mismatch"
                run_record["task_verification_error"] = str(verification_error)
                _graph_checkpoint(
                    run_record,
                    config,
                    node="final_validation",
                    step=step,
                    status="failed",
                    payload={"error": str(verification_error)},
                )
            run_record["finished_at"] = _utc_now_iso()
            _checkpoint_run_record(run_record, config, started_monotonic)
            return final_response.strip()

        if response_type != "tool_call":
            run_record["steps"].append(step_record)
            run_record["status"] = "failed"
            run_record["run_status"] = "crashed"
            run_record["task_status"] = "failure"
            run_record["failure"] = {
                "type": "invalid_response_type",
                "step": step,
                "response_type": response_type,
            }
            run_record["finished_at"] = _utc_now_iso()
            _checkpoint_run_record(run_record, config, started_monotonic)
            raise ProviderError(f"Agent returned unsupported response type: {response_type!r}")

        tool_name = response.get("tool")
        arguments = response.get("arguments", {})
        if not isinstance(tool_name, str) or tool_name not in TOOL_DESCRIPTIONS:
            schema_corrections += 1
            errors = [
                {
                    "type": "unknown_tool",
                    "tool": tool_name,
                    "message": f"Unsupported tool. Available tools: {', '.join(TOOL_DESCRIPTIONS)}.",
                }
            ]
            runtime.setdefault("events", []).append(
                {"type": "schema_validation_feedback", "at": _utc_now_iso(), "step": step, "errors": errors}
            )
            if schema_corrections > config.max_schema_corrections:
                run_record["steps"].append({**step_record, "validation_errors": errors})
                run_record["status"] = "failed"
                run_record["run_status"] = "crashed"
                run_record["task_status"] = "schema_mismatch"
                run_record["failure"] = {"type": "unknown_tool", "step": step, "tool": tool_name}
                run_record["finished_at"] = _utc_now_iso()
                _checkpoint_run_record(run_record, config, started_monotonic)
                raise ProviderError(f"Agent requested unknown tool: {tool_name!r}")
            transcript.append(_schema_feedback(str(tool_name), errors))
            steps_in_attempt -= 1
            _checkpoint_run_record(run_record, config, started_monotonic)
            continue
        if not isinstance(arguments, dict):
            schema_corrections += 1
            errors = [
                {
                    "type": "invalid_tool_arguments",
                    "tool": tool_name,
                    "message": "Tool arguments must be a JSON object.",
                }
            ]
            runtime.setdefault("events", []).append(
                {"type": "schema_validation_feedback", "at": _utc_now_iso(), "step": step, "errors": errors}
            )
            if schema_corrections > config.max_schema_corrections:
                run_record["steps"].append({**step_record, "validation_errors": errors})
                run_record["status"] = "failed"
                run_record["run_status"] = "crashed"
                run_record["task_status"] = "schema_mismatch"
                run_record["failure"] = {"type": "invalid_tool_arguments", "step": step, "tool": tool_name}
                run_record["finished_at"] = _utc_now_iso()
                _checkpoint_run_record(run_record, config, started_monotonic)
                raise ProviderError("Agent tool arguments must be a JSON object")
            transcript.append(_schema_feedback(tool_name, errors))
            steps_in_attempt -= 1
            _checkpoint_run_record(run_record, config, started_monotonic)
            continue

        normalized_arguments, argument_notes = _normalize_tool_arguments(tool_name, response, arguments)
        step_record["raw_tool_call_json"] = response
        step_record["parsed_tool_args"] = arguments
        if argument_notes:
            step_record["argument_normalization"] = argument_notes
        _graph_checkpoint(run_record, config, node="tool_validation", step=step, status="started", payload={"tool": tool_name})
        generated_profile = run_record.get("generated_profile") if isinstance(run_record.get("generated_profile"), dict) else None
        schema_errors = _initial_grounding_validation_errors(
            tool_name,
            normalized_arguments,
            run_record=run_record,
            generated_profile=generated_profile,
        )
        schema_errors.extend(_uncertainty_validation_errors(tool_name, normalized_arguments, runtime))
        schema_errors.extend(
            _validate_tool_arguments(
                tool_name,
                normalized_arguments,
                generated_profile=generated_profile,
            )
        )
        _graph_checkpoint(
            run_record,
            config,
            node="tool_validation",
            step=step,
            status="failed" if schema_errors else "completed",
            payload={"tool": tool_name, "error_count": len(schema_errors)},
        )
        if schema_errors:
            schema_corrections += 1
            runtime.setdefault("events", []).append(
                {"type": "schema_validation_feedback", "at": _utc_now_iso(), "step": step, "tool": tool_name, "errors": schema_errors}
            )
            if schema_corrections > config.max_schema_corrections:
                run_record["steps"].append({**step_record, "validation_errors": schema_errors})
                run_record["status"] = "failed"
                run_record["run_status"] = "crashed"
                run_record["task_status"] = "schema_mismatch"
                run_record["failure"] = {
                    "type": "tool_schema_validation_failed",
                    "step": step,
                    "tool": tool_name,
                    "errors": schema_errors,
                }
                run_record["finished_at"] = _utc_now_iso()
                _checkpoint_run_record(run_record, config, started_monotonic)
                raise ProviderError(f"Agent tool call failed schema validation for {tool_name}")
            transcript.append(_schema_feedback(tool_name, schema_errors))
            steps_in_attempt -= 1
            _checkpoint_run_record(run_record, config, started_monotonic)
            continue

        _debug_log(config, f"step {step} tool request", {"tool": tool_name, "arguments": normalized_arguments})
        _graph_checkpoint(run_record, config, node="tool_execution", step=step, status="started", payload={"tool": tool_name})
        doc_binding_followed, doc_binding_notes = _doc_binding_followed(
            tool_name=tool_name,
            arguments=normalized_arguments,
            active_doc_binding=active_doc_binding,
        )
        if doc_binding_followed is not None:
            step_record["doc_binding_followed"] = doc_binding_followed
            step_record["doc_binding_notes"] = doc_binding_notes
            step_record["active_doc_binding"] = active_doc_binding
        try:
            tool_result, final_arguments, automatic_retries = _call_tool_with_retries(
                tool_name,
                normalized_arguments,
                config=config,
                docs=docs,
                previous_tool_result=previous_tool_result,
                workspace_dir=workspace_dir,
                run_record=run_record,
            )
        except Exception as error:
            tool_result = {
                "ok": False,
                "error_type": type(error).__name__,
                "error": str(error).strip() or repr(error),
            }
            final_arguments = normalized_arguments
            automatic_retries = []
            step_record.setdefault("validation_errors", []).append(
                {
                    "error_type": type(error).__name__,
                    "error": str(error).strip() or repr(error),
                    "raw_tool_call_json": response,
                    "parsed_tool_args": arguments,
                }
            )
        _graph_checkpoint(
            run_record,
            config,
            node="tool_execution",
            step=step,
            status="completed" if tool_result.get("ok") is not False else "failed",
            payload={"tool": tool_name, "ok": tool_result.get("ok")},
        )
        if automatic_retries:
            step_record["automatic_retries"] = automatic_retries
            tool_result["automatic_retries"] = automatic_retries
        _materialize_large_outputs(
            tool_name=tool_name,
            tool_result=tool_result,
            step=step,
            workspace_dir=workspace_dir,
            run_record=run_record,
        )
        _graph_checkpoint(run_record, config, node="artifact_index", step=step, status="completed", payload={"tool": tool_name})
        _debug_log(
            config,
            f"step {step} tool result",
            {
                "tool": tool_name,
                "arguments": final_arguments,
                "result": _tool_result_for_transcript(tool_name, tool_result),
            },
        )
        step_record["tool"] = {
            "name": tool_name,
            "arguments": final_arguments,
        }
        step_record["tool_result"] = _tool_result_for_transcript(tool_name, tool_result)
        run_record["steps"].append(step_record)
        _add_tool_usage(run_record, config)
        previous_tool_result = tool_result
        _update_uncertainty_resolution_state(
            run_record=run_record,
            config=config,
            step=step,
            tool_name=tool_name,
            arguments=final_arguments,
            tool_result=tool_result,
        )
        if tool_name == "ground_docs" and tool_result.get("ok") is True:
            doc_binding = tool_result.get("doc_binding")
            active_doc_binding = doc_binding if isinstance(doc_binding, dict) and doc_binding else None
        elif tool_name in {"run_http", "run_cli", "run_sdk", "run_python"} and tool_result.get("ok") is True:
            active_doc_binding = None
        transcript.append(
            _transcript_tool_result_entry(
                step,
                tool_name,
                final_arguments,
                _tool_result_for_transcript(tool_name, tool_result),
            )
        )
        _record_error_correction(
            run_record=run_record,
            config=config,
            step=step,
            tool_result=tool_result,
            transcript=transcript,
        )
        _checkpoint_run_record(run_record, config, started_monotonic)
