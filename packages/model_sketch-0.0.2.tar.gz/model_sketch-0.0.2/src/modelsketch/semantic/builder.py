"""Builders that derive semantic structure from extracted graphs."""

from __future__ import annotations

from collections import OrderedDict
from typing import TYPE_CHECKING, Literal

from modelsketch.semantic.models import (
    SemanticBlock,
    SemanticLayer,
    SemanticModel,
    SemanticStage,
)

if TYPE_CHECKING:
    from modelsketch.extract.models import GraphNode, GraphSpec


SemanticGrouping = Literal["module_prefix", "single_block"]


def build_semantic_model(
    graph: GraphSpec,
    *,
    grouping: SemanticGrouping = "module_prefix",
) -> SemanticModel:
    """Build a minimal semantic model from the extracted graph.

    The MVP groups layers with simple deterministic heuristics:
    - Placeholder nodes are grouped into an "Inputs" block.
    - call_module nodes are grouped by top-level module path prefix.
    - Function and method nodes follow the most recent module block when
      possible, otherwise they are grouped into "Ops".

    Args:
        graph: Extracted graph specification.
        grouping: Deterministic grouping strategy to apply.

    Returns:
        Semantic model with stage/block/layer hierarchy.
    """

    if grouping == "single_block":
        return _build_single_block_model(graph)

    grouped_layers: OrderedDict[str, list[SemanticLayer]] = OrderedDict()
    current_module_block: str | None = None

    for node in graph.nodes:
        block_name, current_module_block = _select_block_name(
            node=node,
            current_module_block=current_module_block,
        )
        grouped_layers.setdefault(block_name, []).append(
            SemanticLayer(id=node.id, name=node.label, op_type=node.op_type),
        )

    blocks = [
        SemanticBlock(name=block_name, layers=layers)
        for block_name, layers in grouped_layers.items()
    ]
    stage = SemanticStage(name="Stage 1", blocks=blocks)
    return SemanticModel(stages=[stage])


def _build_single_block_model(graph: GraphSpec) -> SemanticModel:
    """Build semantic model as one stage with one block."""

    layers = [
        SemanticLayer(id=node.id, name=node.label, op_type=node.op_type)
        for node in graph.nodes
    ]
    block = SemanticBlock(name="Main Block", layers=layers)
    stage = SemanticStage(name="Stage 1", blocks=[block])
    return SemanticModel(stages=[stage])


def _select_block_name(
    *,
    node: GraphNode,
    current_module_block: str | None,
) -> tuple[str, str | None]:
    """Select semantic block name for a graph node."""

    if node.op_type == "placeholder":
        return "Inputs", current_module_block

    if node.op_type == "call_module":
        if node.module_path:
            prefix = node.module_path.split(".", maxsplit=1)[0]
            block_name = f"Module: {prefix}"
            return block_name, block_name
        return "Modules", "Modules"

    if node.op_type in {"call_function", "call_method"}:
        return current_module_block or "Ops", current_module_block

    return current_module_block or "Graph", current_module_block
