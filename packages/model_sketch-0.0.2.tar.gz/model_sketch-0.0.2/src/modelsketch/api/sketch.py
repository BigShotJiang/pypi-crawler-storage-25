"""High-level API for generating model architecture sketches."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from modelsketch.api.notebook import display_sketch
from modelsketch.extract import GraphEdge, GraphNode, GraphSpec, extract_graph
from modelsketch.layout import plan_layout
from modelsketch.render import render_svg, svg_to_png
from modelsketch.semantic import SemanticGrouping, build_semantic_model

if TYPE_CHECKING:
    from collections.abc import Mapping

    from modelsketch.semantic.models import SemanticModel

OutputFormat = Literal["svg", "png", "both"]
NotebookFormat = Literal["auto", "svg", "png"]
SemanticView = Literal["layers", "blocks"]


@dataclass(frozen=True)
class SketchResult:
    """Container for generated sketch outputs.

    Attributes:
        svg: SVG document string generated for the model.
        png: Optional PNG payload generated from the SVG document.
    """

    svg: str
    png: bytes | None = None


@dataclass(frozen=True)
class SketchOptions:
    """Output options accepted by the sketch API.

    Attributes:
        output_format: Output format to generate.
        png_scale: Rasterization scale used for PNG conversion.
        png_background: PNG background color.
        png_dpi: PNG DPI metadata when supported by backend.
        save_svg_path: Optional filesystem path where SVG is saved.
        save_png_path: Optional filesystem path where PNG is saved.
        render_in_notebook: Whether to display the result in a notebook.
        notebook_format: Notebook display preference.
        semantic_grouping: Semantic grouping strategy for block construction.
        semantic_inter_block_gap: Extra horizontal gap between semantic blocks.
        semantic_view: Display layers directly or collapsed semantic blocks.
    """

    output_format: OutputFormat = "svg"
    png_scale: float = 2.0
    png_background: str = "white"
    png_dpi: int = 300
    save_svg_path: str | Path | None = None
    save_png_path: str | Path | None = None
    render_in_notebook: bool = False
    notebook_format: NotebookFormat = "auto"
    semantic_grouping: SemanticGrouping = "module_prefix"
    semantic_inter_block_gap: float = 96.0
    semantic_view: SemanticView = "layers"


def sketch_model(
    model: Any,
    *,
    example_args: tuple[Any, ...] = (),
    example_kwargs: Mapping[str, Any] | None = None,
    options: SketchOptions | None = None,
) -> SketchResult:
    """Generate a model sketch using the MVP pipeline.

    Args:
        model: PyTorch model object to visualize.
        example_args: Example positional arguments for model forward execution.
        example_kwargs: Example keyword arguments for model forward execution.
        options: Output options controlling format and PNG conversion settings.

    Returns:
        SketchResult with SVG output and optional PNG bytes.
    """

    effective_options = options or SketchOptions()

    if effective_options.output_format not in {"svg", "png", "both"}:
        msg = "output_format must be one of: 'svg', 'png', 'both'"
        raise ValueError(msg)

    if effective_options.semantic_grouping not in {"module_prefix", "single_block"}:
        msg = "semantic_grouping must be one of: 'module_prefix', 'single_block'"
        raise ValueError(msg)

    if effective_options.semantic_inter_block_gap < 0.0:
        msg = "semantic_inter_block_gap must be non-negative"
        raise ValueError(msg)

    if effective_options.semantic_view not in {"layers", "blocks"}:
        msg = "semantic_view must be one of: 'layers', 'blocks'"
        raise ValueError(msg)

    normalized_kwargs = dict(example_kwargs or {})
    graph = extract_graph(model, args=example_args, kwargs=normalized_kwargs)
    semantic_model = build_semantic_model(
        graph,
        grouping=effective_options.semantic_grouping,
    )
    render_graph = _graph_for_semantic_view(
        graph,
        semantic_model=semantic_model,
        semantic_view=effective_options.semantic_view,
    )
    layout = plan_layout(
        render_graph,
        semantic_model=(
            semantic_model if effective_options.semantic_view == "layers" else None
        ),
        inter_block_gap=effective_options.semantic_inter_block_gap,
    )
    svg = render_svg(graph=render_graph, layout=layout)

    png_payload: bytes | None = None
    if effective_options.output_format in {"png", "both"}:
        png_payload = svg_to_png(
            svg=svg,
            scale=effective_options.png_scale,
            background=effective_options.png_background,
            dpi=effective_options.png_dpi,
        )

    if effective_options.save_svg_path is not None:
        _write_text_file(effective_options.save_svg_path, svg)

    if effective_options.save_png_path is not None:
        if png_payload is None:
            png_payload = svg_to_png(
                svg=svg,
                scale=effective_options.png_scale,
                background=effective_options.png_background,
                dpi=effective_options.png_dpi,
            )
        _write_binary_file(effective_options.save_png_path, png_payload)

    result = SketchResult(svg=svg, png=png_payload)

    if effective_options.render_in_notebook:
        display_sketch(result, preferred_format=effective_options.notebook_format)

    return result


def _write_text_file(path: str | Path, content: str) -> None:
    """Write UTF-8 text content and create parent directories when needed."""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding="utf-8")


def _write_binary_file(path: str | Path, content: bytes) -> None:
    """Write binary content and create parent directories when needed."""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(content)


def _graph_for_semantic_view(
    graph: GraphSpec,
    *,
    semantic_model: SemanticModel,
    semantic_view: SemanticView,
) -> GraphSpec:
    """Select graph representation for rendering based on semantic view."""

    if semantic_view == "layers":
        return graph
    return _collapse_graph_to_semantic_blocks(
        graph=graph,
        semantic_model=semantic_model,
    )


def _collapse_graph_to_semantic_blocks(
    *,
    graph: GraphSpec,
    semantic_model: SemanticModel,
) -> GraphSpec:
    """Build block-level graph so rendering shows semantic blocks, not raw layers."""

    node_to_block_id: dict[str, str] = {}
    block_nodes: list[GraphNode] = []

    block_index = 0
    for stage in semantic_model.stages:
        for block in stage.blocks:
            if not block.layers:
                continue
            block_id = f"semantic_block_{block_index}"
            block_index += 1
            for layer in block.layers:
                node_to_block_id[layer.id] = block_id
            block_nodes.append(
                GraphNode(
                    id=block_id,
                    op_type="semantic_block",
                    label=(
                        f"{_block_display_name(block.name)}"
                        f"{_shape_suffix_from_label(block.layers[-1].name)}"
                    ),
                ),
            )

    dedup_edges: dict[tuple[str, str], None] = {}
    for edge in graph.edges:
        source_block = node_to_block_id.get(edge.source)
        target_block = node_to_block_id.get(edge.target)
        if source_block is None or target_block is None:
            continue
        if source_block == target_block:
            continue
        dedup_edges[(source_block, target_block)] = None

    block_edges = [
        GraphEdge(source=source, target=target) for source, target in dedup_edges
    ]
    return GraphSpec(nodes=block_nodes, edges=block_edges)


def _shape_suffix_from_label(label: str) -> str:
    """Extract shape-like suffix from layer label for block summaries."""

    marker = " ("
    marker_index = label.find(marker)
    if marker_index < 0:
        return ""
    return label[marker_index:]


def _block_display_name(block_name: str) -> str:
    """Convert internal semantic block name into a user-facing display label."""

    prefix = "Module: "
    if block_name.startswith(prefix):
        return block_name[len(prefix) :]
    return block_name
