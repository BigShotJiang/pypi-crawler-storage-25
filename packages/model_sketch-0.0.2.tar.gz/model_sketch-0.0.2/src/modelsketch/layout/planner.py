"""Simple layout planner for MVP model diagrams."""

from __future__ import annotations

from typing import TYPE_CHECKING

from modelsketch.layout.types import LayoutPlan, NodeBox

if TYPE_CHECKING:
    from modelsketch.extract.models import GraphSpec
    from modelsketch.semantic.models import SemanticModel


def plan_layout(
    graph: GraphSpec,
    *,
    semantic_model: SemanticModel | None = None,
    inter_block_gap: float = 96.0,
) -> LayoutPlan:
    """Plan a deterministic left-to-right layout for graph nodes.

    Args:
        graph: Extracted model graph.
        semantic_model: Optional semantic grouping used for visual spacing.
        inter_block_gap: Horizontal gap inserted between semantic blocks.

    Returns:
        Layout plan with node boxes and viewport dimensions.
    """

    start_x = 24.0
    start_y = 24.0
    box_width = 180.0
    box_height = 72.0
    gap = 48.0

    if inter_block_gap < 0.0:
        msg = "inter_block_gap must be non-negative"
        raise ValueError(msg)

    node_to_block = _node_to_block_mapping(semantic_model)

    boxes: dict[str, NodeBox] = {}
    cursor_x = start_x
    previous_block: str | None = None

    for node in graph.nodes:
        current_block = node_to_block.get(node.id)
        if boxes:
            step_gap = inter_block_gap if current_block != previous_block else gap
            cursor_x += box_width + step_gap
        x = cursor_x
        boxes[node.id] = NodeBox(x=x, y=start_y, width=box_width, height=box_height)
        previous_block = current_block

    width = cursor_x + box_width + start_x if boxes else start_x * 2
    height = start_y * 2 + box_height

    return LayoutPlan(boxes=boxes, width=width, height=height)


def _node_to_block_mapping(semantic_model: SemanticModel | None) -> dict[str, str]:
    """Create a lookup from node id to semantic block name."""

    if semantic_model is None:
        return {}

    mapping: dict[str, str] = {}
    for stage in semantic_model.stages:
        for block in stage.blocks:
            for layer in block.layers:
                mapping[layer.id] = block.name
    return mapping
