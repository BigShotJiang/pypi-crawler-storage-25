"""
AHA! API Client
Handles all API interactions with the AHA! service.
"""

from typing import Any, Optional, Dict, List, Tuple
import asyncio
import httpx
from datetime import datetime, timedelta, timezone

_IDEA_SEARCH_SORT = frozenset({"recent", "trending", "popular"})


def _field_suggests_picklist(definition: Dict[str, Any]) -> bool:
    """Heuristic: field likely has discrete options worth fetching from /options."""
    blob = f"{definition.get('type') or ''} {definition.get('api_type') or ''}".lower()
    return any(n in blob for n in ("select", "tag", "choice", "multiselect", "dropdown", "list"))


class AhaClient:
    """Client for interacting with the AHA! API."""
    
    def __init__(self, account_domain: str, api_key: str, context_cache=None):
        """
        Initialize the AHA client.
        
        Args:
            account_domain: Your AHA! account domain (e.g., 'company' for company.aha.io)
            api_key: Your AHA! API key
            context_cache: Optional ContextCache instance for name-based resolution
        """
        self.account_domain = account_domain
        self.api_key = api_key
        self.base_url = f"https://{account_domain}.aha.io/api/v1"
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        self.context_cache = context_cache
        # Short TTL cache for layouts and picklist option payloads (lazy discovery path).
        self._metadata_cache: Dict[str, Tuple[datetime, Any]] = {}
        self._metadata_cache_lock = asyncio.Lock()
        self.metadata_cache_ttl = timedelta(minutes=15)

    async def _metadata_cache_get(self, key: str) -> Optional[Any]:
        async with self._metadata_cache_lock:
            row = self._metadata_cache.get(key)
            if not row:
                return None
            ts, val = row
            if datetime.now(timezone.utc) - ts > self.metadata_cache_ttl:
                del self._metadata_cache[key]
                return None
            return val

    async def _metadata_cache_set(self, key: str, value: Any) -> None:
        async with self._metadata_cache_lock:
            self._metadata_cache[key] = (datetime.now(timezone.utc), value)

    async def invalidate_metadata_cache(self) -> None:
        """Clear the metadata cache (screen layouts and custom field options)."""
        async with self._metadata_cache_lock:
            self._metadata_cache.clear()

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the AHA! API.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint (e.g., '/ideas')
            params: Query parameters
            data: Request body data
        
        Returns:
            JSON response as a dictionary, or {} when the response has no JSON body
            (e.g. HTTP 204 from DELETE record_links / DELETE pages).
        """
        url = f"{self.base_url}{endpoint}"
        
        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=method,
                url=url,
                headers=self.headers,
                params=params,
                json=data,
                timeout=30.0
            )
            if response.status_code == 204:
                return {}
            if response.status_code >= 400:
                body = (response.text or "").strip()
                msg = f"{response.status_code} {response.reason_phrase}"
                if body:
                    msg = f"{msg}: {body}"
                raise httpx.HTTPStatusError(
                    msg, request=response.request, response=response
                )
            content = response.content or b""
            if not content.strip():
                return {}
            return response.json()
    
    # Ideas methods
    
    async def search_ideas(
        self,
        product_id: str,
        query: Optional[str] = None,
        release_id: Optional[str] = None,
        release_name: Optional[str] = None,
        epic_id: Optional[str] = None,
        epic_name: Optional[str] = None,
        initiative_id: Optional[str] = None,
        initiative_name: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        sort: Optional[str] = None,
        fields: Optional[str] = None,
        created_since: Optional[str] = None,
        created_before: Optional[str] = None,
        updated_since: Optional[str] = None,
        tag: Optional[str] = None,
        user_id: Optional[str] = None,
        idea_user_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for ideas in a product. All operations are scoped to a specific product.
        
        If release_id/epic_id/initiative_id or their names are provided, filters ideas
        using query parameters. Names are resolved to IDs using the context cache if available.
        If both ID and name are provided for the same resource type, ID takes precedence.
        
        Args:
            product_id: Product ID (required - all operations are scoped to a product)
            query: Search query string
            release_id: Filter by release ID
            release_name: Filter by release name (resolved to ID if context_cache available)
            epic_id: Filter by epic ID
            epic_name: Filter by epic name (resolved to ID if context_cache available)
            initiative_id: Filter by initiative ID
            initiative_name: Filter by initiative name (resolved to ID if context_cache available)
            workflow_status_id: Filter by workflow status ID
            sort: Aha! sort: recent, trending, or popular (only these are forwarded).
            fields: Comma-separated extra fields (pass-through to Aha! `fields`).
            created_since, created_before, updated_since: ISO8601 filters (pass-through).
            tag, user_id, idea_user_id: Pass-through query filters.
            limit: Maximum per page (clamped to 200, Aha! cap)
            page: Page number
        
        Returns:
            Search results with ideas and pagination
        """
        # Resolve names to IDs if context cache is available
        if self.context_cache:
            if release_name and not release_id:
                match = await self.context_cache.find_release_by_name(product_id, release_name)
                if match:
                    release_id = match[0]
            
            if epic_name and not epic_id:
                match = await self.context_cache.find_epic_by_name(product_id, epic_name, release_id)
                if match:
                    epic_id = match[0]
            
            if initiative_name and not initiative_id:
                match = await self.context_cache.find_initiative_by_name(product_id, initiative_name)
                if match:
                    initiative_id = match[0]
        
        lim = int(limit) if limit is not None else 25
        per_page = min(max(lim, 1), 200)
        params: Dict[str, Any] = {"per_page": per_page, "page": page}

        if query:
            params["q"] = query
        if sort and sort in _IDEA_SEARCH_SORT:
            params["sort"] = sort
        if fields:
            params["fields"] = fields
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        if release_id:
            params["release_id"] = release_id
        if epic_id:
            params["epic_id"] = epic_id
        if initiative_id:
            params["initiative_id"] = initiative_id
        if created_since:
            params["created_since"] = created_since
        if created_before:
            params["created_before"] = created_before
        if updated_since:
            params["updated_since"] = updated_since
        if tag:
            params["tag"] = tag
        if user_id:
            params["user_id"] = user_id
        if idea_user_id:
            params["idea_user_id"] = idea_user_id

        return await self._request("GET", f"/products/{product_id}/ideas", params=params)
    
    async def get_idea(self, idea_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific idea by ID.
        
        Args:
            idea_id: Idea ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Idea details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/ideas/{idea_id}", params=params)
    
    async def create_idea(
        self,
        name: str,
        product_id: str,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        submitted_idea_portal_id: Optional[str] = None,
        skip_portal: bool = False
    ) -> Dict[str, Any]:
        """
        Create a new idea.
        
        Args:
            name: Name of the idea
            product_id: Product ID (products belong to workspaces, so this ensures creation in the correct workspace)
            description: Description (HTML or plain text)
            workflow_status_id: Initial workflow status ID
            submitted_idea_portal_id: Idea portal ID if submitting from a portal
            skip_portal: Skip portal submission
        
        Returns:
            Created idea details
        """
        # Documented as POST /products/:product_id/ideas; POST /ideas with product_id in
        # the body can mirror the old /features bug (create succeeds but drops some fields).
        idea_data: Dict[str, Any] = {"name": name}

        if description:
            idea_data["description"] = description
        if workflow_status_id:
            idea_data["workflow_status"] = {"id": workflow_status_id}
        if submitted_idea_portal_id:
            idea_data["submitted_idea_portal_id"] = submitted_idea_portal_id
        if skip_portal:
            idea_data["skip_portal"] = True

        return await self._request(
            "POST",
            f"/products/{product_id}/ideas",
            data={"idea": idea_data},
        )
    
    async def update_idea(
        self,
        idea_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        product_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update an existing idea.
        
        Args:
            idea_id: Idea ID or reference number
            name: New name
            description: New description
            workflow_status_id: New workflow status ID
            product_id: Product ID to move the idea to
        
        Returns:
            Updated idea details
        """
        idea_data = {}
        
        if name:
            idea_data["name"] = name
        if description:
            idea_data["description"] = description
        if workflow_status_id:
            idea_data["workflow_status"] = {"id": workflow_status_id}
        if product_id:
            idea_data["product_id"] = product_id

        return await self._request("PUT", f"/ideas/{idea_id}", data={"idea": idea_data})
    
    # Features methods
    
    async def search_features(
        self,
        product_id: str,
        query: Optional[str] = None,
        release_id: Optional[str] = None,
        release_name: Optional[str] = None,
        epic_id: Optional[str] = None,
        epic_name: Optional[str] = None,
        initiative_id: Optional[str] = None,
        initiative_name: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for features. All operations are scoped to a specific product.
        
        If release_id/epic_id/initiative_id or their names are provided, uses the specific endpoint
        for that resource. Otherwise, uses the product-scoped features endpoint.
        
        Names are resolved to IDs using the context cache if available. If both ID and name
        are provided for the same resource type, ID takes precedence.
        
        Args:
            product_id: Product ID (required - all operations are scoped to a product)
            query: Search query string (searches feature names and descriptions)
            release_id: Filter by release ID (uses /releases/{release_id}/features endpoint)
            release_name: Filter by release name (resolved to ID if context_cache available)
            epic_id: Filter by epic ID (uses /epics/{epic_id}/features endpoint)
            epic_name: Filter by epic name (resolved to ID if context_cache available)
            initiative_id: Filter by initiative ID (uses /initiatives/{initiative_id}/features endpoint)
            initiative_name: Filter by initiative name (resolved to ID if context_cache available)
            workflow_status_id: Filter by workflow status ID
            limit: Maximum number of results
            page: Page number
        
        Returns:
            Search results with features and pagination
        """
        # Resolve names to IDs if context cache is available
        if self.context_cache:
            if release_name and not release_id:
                match = await self.context_cache.find_release_by_name(product_id, release_name)
                if match:
                    release_id = match[0]
            
            if epic_name and not epic_id:
                match = await self.context_cache.find_epic_by_name(product_id, epic_name, release_id)
                if match:
                    epic_id = match[0]
            
            if initiative_name and not initiative_id:
                match = await self.context_cache.find_initiative_by_name(product_id, initiative_name)
                if match:
                    initiative_id = match[0]
        
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        
        # Use specific endpoint if release_id, epic_id, or initiative_id is provided
        if release_id:
            return await self._request("GET", f"/releases/{release_id}/features", params=params)
        elif epic_id:
            return await self._request("GET", f"/epics/{epic_id}/features", params=params)
        elif initiative_id:
            return await self._request("GET", f"/initiatives/{initiative_id}/features", params=params)
        else:
            # Use product-scoped features endpoint
            return await self._request("GET", f"/products/{product_id}/features", params=params)
    
    async def get_feature(self, feature_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific feature by ID.
        
        Args:
            feature_id: Feature ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Feature details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/features/{feature_id}", params=params)
    
    async def create_feature(
        self,
        name: str,
        release_id: str,
        description: Optional[str] = None,
        epic_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None,
        release_phase: Optional[str] = None,
        custom_fields: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Create a new feature.
        
        Args:
            name: Name of the feature
            release_id: Release ID (required - releases belong to products, which belong to workspaces)
            description: Description (HTML or plain text)
            epic_id: Epic ID to associate with
            workflow_status_id: Initial workflow status ID
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
            custom_fields: Map of custom field keys to values (see Aha! API custom_fields on features)
            release_phase: Release phase id (string) or exact phase name on this release (Aha! API field release_phase).

        Returns:
            Created feature details
        """
        # Aha! requires release-scoped creation; POST /features with release_id in the
        # body can succeed but omit optional fields like description and workflow_status.
        feature_data: Dict[str, Any] = {"name": name}

        if description:
            feature_data["description"] = description
        if release_phase is not None and str(release_phase).strip() != "":
            feature_data["release_phase"] = release_phase
        if epic_id:
            feature_data["epic_id"] = epic_id
        if workflow_status_id:
            feature_data["workflow_status"] = {"id": workflow_status_id}
        if start_date:
            feature_data["start_date"] = start_date
        if due_date:
            feature_data["due_date"] = due_date
        if custom_fields:
            feature_data["custom_fields"] = custom_fields

        return await self._request(
            "POST",
            f"/releases/{release_id}/features",
            data={"feature": feature_data},
        )
    
    async def update_feature(
        self,
        feature_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        release_id: Optional[str] = None,
        epic_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None,
        release_phase: Optional[str] = None,
        custom_fields: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing feature.
        
        Args:
            feature_id: Feature ID or reference number
            name: New name
            description: New description
            workflow_status_id: New workflow status ID
            release_id: Release ID to move the feature to
            epic_id: Epic ID to associate with
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
            release_phase: Release phase id or name (Aha! API field release_phase); pass None to leave unchanged
            custom_fields: Map of custom field keys to values (partial merge per Aha! API)

        Returns:
            Updated feature details
        """
        feature_data = {}
        
        if name:
            feature_data["name"] = name
        if description:
            feature_data["description"] = description
        if workflow_status_id:
            feature_data["workflow_status"] = {"id": workflow_status_id}
        if release_id:
            feature_data["release_id"] = release_id
        if release_phase is not None:
            feature_data["release_phase"] = release_phase
        if epic_id:
            feature_data["epic_id"] = epic_id
        if start_date:
            feature_data["start_date"] = start_date
        if due_date:
            feature_data["due_date"] = due_date
        if custom_fields:
            feature_data["custom_fields"] = custom_fields

        return await self._request("PUT", f"/features/{feature_id}", data={"feature": feature_data})
    
    # Epics methods
    
    async def search_epics(
        self,
        product_id: str,
        query: Optional[str] = None,
        release_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for epics in a product.
        
        Args:
            product_id: Product ID (required)
            query: Search query string
            release_id: Filter by release ID (uses /releases/{release_id}/epics endpoint)
            workflow_status_id: Filter by workflow status ID
            limit: Maximum number of results
            page: Page number
        
        Returns:
            Search results with epics and pagination
        """
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        
        # Use release-specific endpoint if release_id is provided
        if release_id:
            return await self._request("GET", f"/releases/{release_id}/epics", params=params)
        else:
            # Use product-specific endpoint
            return await self._request("GET", f"/products/{product_id}/epics", params=params)
    
    async def get_epic(self, epic_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific epic by ID.
        
        Args:
            epic_id: Epic ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Epic details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/epics/{epic_id}", params=params)
    
    async def create_epic(
        self,
        name: str,
        release_id: Optional[str] = None,
        product_id: Optional[str] = None,
        description: Optional[str] = None,
        initiative_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new epic.
        
        Args:
            name: Name of the epic
            release_id: Release ID (required if product_id not provided)
            product_id: Product ID (creates in default release if release_id not provided)
            description: Description (HTML or plain text)
            initiative_id: Initiative ID to associate with
            workflow_status_id: Initial workflow status ID
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
        
        Returns:
            Created epic details
        """
        if not release_id and not product_id:
            raise ValueError("Either release_id or product_id must be provided")
        
        epic_data = {
            "name": name
        }
        
        if description:
            epic_data["description"] = description
        if initiative_id:
            epic_data["initiative_id"] = initiative_id
        if workflow_status_id:
            epic_data["workflow_status"] = {"id": workflow_status_id}
        if start_date:
            epic_data["start_date"] = start_date
        if due_date:
            epic_data["due_date"] = due_date

        if release_id:
            return await self._request("POST", f"/releases/{release_id}/epics", data={"epic": epic_data})
        else:
            return await self._request("POST", f"/products/{product_id}/epics", data={"epic": epic_data})
    
    async def update_epic(
        self,
        epic_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        release_id: Optional[str] = None,
        initiative_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update an existing epic.
        
        Args:
            epic_id: Epic ID or reference number
            name: New name
            description: New description
            workflow_status_id: New workflow status ID
            release_id: Release ID to move the epic to
            initiative_id: Initiative ID to associate with
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
        
        Returns:
            Updated epic details
        """
        epic_data = {}
        
        if name:
            epic_data["name"] = name
        if description:
            epic_data["description"] = description
        if workflow_status_id:
            epic_data["workflow_status"] = {"id": workflow_status_id}
        if release_id:
            epic_data["release_id"] = release_id
        if initiative_id:
            epic_data["initiative_id"] = initiative_id
        if start_date:
            epic_data["start_date"] = start_date
        if due_date:
            epic_data["due_date"] = due_date

        return await self._request("PUT", f"/epics/{epic_id}", data={"epic": epic_data})
    
    # Releases methods
    
    async def search_releases(
        self,
        query: Optional[str] = None,
        product_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for releases.
        
        Args:
            query: Search query string
            product_id: Filter by product ID (required for listing)
            workflow_status_id: Filter by workflow status ID
            limit: Maximum number of results
            page: Page number
        
        Returns:
            Search results with releases and pagination
        """
        if not product_id:
            raise ValueError("product_id is required for searching releases")
        
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        
        return await self._request("GET", f"/products/{product_id}/releases", params=params)
    
    async def get_release(self, release_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific release by ID.
        
        Args:
            release_id: Release ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Release details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/releases/{release_id}", params=params)
    
    async def create_release(
        self,
        name: str,
        product_id: str,
        description: Optional[str] = None,
        release_date: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        owner_email: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new release.
        
        Args:
            name: Name of the release
            product_id: Product ID (required)
            description: Description/theme (HTML or plain text)
            release_date: Release date in YYYY-MM-DD format
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            workflow_status_id: Initial workflow status ID
            owner_email: Owner email address
        
        Returns:
            Created release details
        """
        release_data = {
            "name": name
        }
        
        if description:
            release_data["theme"] = description
        if release_date:
            release_data["release_date"] = release_date
        if start_date:
            release_data["start_date"] = start_date
        if end_date:
            release_data["end_date"] = end_date
        if workflow_status_id:
            release_data["status"] = workflow_status_id
        if owner_email:
            release_data["owner"] = owner_email
        
        return await self._request("POST", f"/products/{product_id}/releases", data={"release": release_data})
    
    async def update_release(
        self,
        release_id: str,
        product_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        release_date: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        owner_email: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update an existing release.
        
        Args:
            release_id: Release ID or reference number
            product_id: Product ID (required)
            name: New name
            description: New description/theme
            release_date: Release date in YYYY-MM-DD format
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            workflow_status_id: New workflow status ID
            owner_email: Owner email address
        
        Returns:
            Updated release details
        """
        release_data = {}
        
        if name:
            release_data["name"] = name
        if description:
            release_data["theme"] = description
        if release_date:
            release_data["release_date"] = release_date
        if start_date:
            release_data["start_date"] = start_date
        if end_date:
            release_data["end_date"] = end_date
        if workflow_status_id:
            release_data["status"] = workflow_status_id
        if owner_email:
            release_data["owner"] = owner_email
        
        return await self._request("PUT", f"/products/{product_id}/releases/{release_id}", data={"release": release_data})

    # Release phases (schedule phases and milestones on a release)

    @staticmethod
    def _release_phase_body_release_id(release_id: str) -> Any:
        """Numeric release ids as int for JSON body; keep reference keys as strings."""
        if isinstance(release_id, str) and release_id.strip().isdigit():
            return int(release_id.strip())
        return release_id

    async def list_release_phases(
        self,
        release_id: str,
        phase_kind: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        GET /releases/:release_id/release_phases — phases and milestones on a release.

        Args:
            release_id: Release id or reference key.
            phase_kind: Optional filter passed to Aha! as ``type``: ``phase`` or ``milestone``.
        """
        params: Optional[Dict[str, Any]] = None
        if phase_kind:
            if phase_kind not in ("phase", "milestone"):
                raise ValueError("phase_kind must be 'phase' or 'milestone'")
            params = {"type": phase_kind}
        return await self._request(
            "GET",
            f"/releases/{release_id}/release_phases",
            params=params,
        )

    async def get_release_phase(
        self, release_phase_id: str, fields: Optional[str] = None
    ) -> Dict[str, Any]:
        """GET /release_phases/:id"""
        params: Dict[str, Any] = {}
        if fields:
            params["fields"] = fields
        return await self._request(
            "GET", f"/release_phases/{release_phase_id}", params=params or None
        )

    async def create_release_phase(
        self,
        name: str,
        release_id: str,
        phase_type: str,
        start_on: Optional[str] = None,
        end_on: Optional[str] = None,
        description: Optional[str] = None,
        progress_source: Optional[str] = None,
        progress: Optional[Any] = None,
        duration_source: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        POST /release_phases — body ``release_phase``.

        phase_type: ``phase`` or ``milestone`` (Aha! API).
        """
        if phase_type not in ("phase", "milestone"):
            raise ValueError("phase_type must be 'phase' or 'milestone'")
        rp: Dict[str, Any] = {
            "name": name,
            "phase_type": phase_type,
            "release_id": self._release_phase_body_release_id(release_id),
        }
        if start_on is not None:
            rp["start_on"] = start_on
        if end_on is not None:
            rp["end_on"] = end_on
        if description is not None:
            rp["description"] = description
        if progress_source is not None:
            rp["progress_source"] = progress_source
        if progress is not None:
            rp["progress"] = progress
        if duration_source is not None:
            rp["duration_source"] = duration_source
        return await self._request("POST", "/release_phases", data={"release_phase": rp})

    async def update_release_phase(
        self,
        release_phase_id: str,
        name: Optional[str] = None,
        phase_type: Optional[str] = None,
        start_on: Optional[str] = None,
        end_on: Optional[str] = None,
        description: Optional[str] = None,
        progress_source: Optional[str] = None,
        progress: Optional[Any] = None,
        duration_source: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        PUT /release_phases/:id — partial body. If ``phase_type`` is omitted but other
        fields are set, the current ``phase_type`` is read from GET and included (Aha!
        expects it on update).
        """
        rp: Dict[str, Any] = {}
        if name is not None:
            rp["name"] = name
        if phase_type is not None:
            if phase_type not in ("phase", "milestone"):
                raise ValueError("phase_type must be 'phase' or 'milestone'")
            rp["phase_type"] = phase_type
        if start_on is not None:
            rp["start_on"] = start_on
        if end_on is not None:
            rp["end_on"] = end_on
        if description is not None:
            rp["description"] = description
        if progress_source is not None:
            rp["progress_source"] = progress_source
        if progress is not None:
            rp["progress"] = progress
        if duration_source is not None:
            rp["duration_source"] = duration_source
        if not rp:
            raise ValueError("No fields to update; pass at least one optional field.")
        if "phase_type" not in rp:
            cur = await self.get_release_phase(release_phase_id)
            blob = cur.get("release_phase")
            if isinstance(blob, dict) and blob.get("phase_type"):
                rp["phase_type"] = blob["phase_type"]
            else:
                raise ValueError(
                    "Could not infer phase_type from API; pass phase_type explicitly."
                )
        return await self._request(
            "PUT",
            f"/release_phases/{release_phase_id}",
            data={"release_phase": rp},
        )

    async def delete_release_phase(self, release_phase_id: str) -> Dict[str, Any]:
        """DELETE /release_phases/:id — Aha! returns 204 with no body."""
        return await self._request("DELETE", f"/release_phases/{release_phase_id}")

    # Initiatives methods
    
    async def list_initiatives(
        self,
        product_id: str,
        query: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        List initiatives for a product.
        
        Args:
            product_id: Product ID (required)
            query: Search query string
            limit: Maximum number of results
            page: Page number
        
        Returns:
            List of initiatives with pagination
        """
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        
        return await self._request("GET", f"/products/{product_id}/initiatives", params=params)
    
    async def get_initiative(self, initiative_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific initiative by ID.
        
        Args:
            initiative_id: Initiative ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Initiative details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/initiatives/{initiative_id}", params=params)

    async def get_product(self, product_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """GET /products/:id — used to resolve screen_definition_ids for custom layouts."""
        params: Dict[str, Any] = {}
        if fields:
            params["fields"] = fields
        return await self._request("GET", f"/products/{product_id}", params=params)

    async def list_custom_field_definitions(
        self,
        limit: int = 100,
        page: int = 1,
        custom_fieldable_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List account-wide custom field definitions (GET /custom_field_definitions).

        If custom_fieldable_type is set (e.g. 'Feature', 'Epic', 'Ideas::Idea'), the
        returned custom_field_definitions array is filtered to that type for this page
        only; paginate without the filter to scan the full account.
        """
        params: Dict[str, Any] = {"per_page": limit, "page": page}
        data = await self._request("GET", "/custom_field_definitions", params=params)
        defs = data.get("custom_field_definitions")
        if custom_fieldable_type and isinstance(defs, list):
            data = {
                **data,
                "custom_field_definitions": [
                    d
                    for d in defs
                    if d.get("custom_fieldable_type") == custom_fieldable_type
                ],
            }
        return data

    async def list_custom_field_options(
        self, custom_field_definition_id: str, *, use_cache: bool = True
    ) -> Dict[str, Any]:
        """List allowed values for a choice-style custom field (GET .../options)."""
        key = f"cfo:{custom_field_definition_id}"
        if use_cache:
            hit = await self._metadata_cache_get(key)
            if hit is not None:
                return hit
        data = await self._request(
            "GET",
            f"/custom_field_definitions/{custom_field_definition_id}/options",
        )
        if use_cache:
            await self._metadata_cache_set(key, data)
        return data

    async def get_screen_definition(self, screen_definition_id: str) -> Dict[str, Any]:
        """GET /screen_definitions/:id — layout fields including required and inline options."""
        return await self._request("GET", f"/screen_definitions/{screen_definition_id}")

    async def get_custom_layout_for_product_record(
        self,
        product_id: str,
        record_type: str = "Feature",
        *,
        use_cache: bool = True,
    ) -> Dict[str, Any]:
        """
        Product-specific custom layout: reads product.screen_definition_ids[record_type]
        then GET /screen_definitions/:id. Often includes `required` and `options` on
        each custom_field_definition. May require configuration-admin API permissions.
        """
        cache_key = f"layout:{product_id}:{record_type}"
        if use_cache:
            hit = await self._metadata_cache_get(cache_key)
            if hit is not None:
                return hit
        prod = await self.get_product(product_id)
        product = prod.get("product") if isinstance(prod.get("product"), dict) else prod
        if not isinstance(product, dict):
            raise ValueError("Unexpected product response shape")
        sid_map = product.get("screen_definition_ids") or {}
        screen_id = sid_map.get(record_type)
        if not screen_id:
            keys = ", ".join(sorted(str(k) for k in sid_map.keys())) or "(none)"
            raise ValueError(
                f"No screen layout id for record_type={record_type!r}. "
                f"Available screen_definition_ids keys: {keys}"
            )
        layout = await self.get_screen_definition(str(screen_id))
        if use_cache:
            await self._metadata_cache_set(cache_key, layout)
        return layout

    async def export_product_seed_bundle(
        self,
        product_id: str,
        record_types: Optional[List[str]] = None,
        include_picklist_options: bool = True,
        max_layout_types: int = 12,
        max_option_api_calls: int = 48,
        custom_definitions_max_pages: int = 30,
        bypass_cache: bool = True,
    ) -> Dict[str, Any]:
        """
        One-shot export for seeding: product, layouts by record type, merged custom field
        definitions (paginated), and picklist options for fields that need /options.
        """
        warnings: List[str] = []
        use_cache = not bypass_cache
        generated = datetime.now(timezone.utc).isoformat()

        prod_wrap = await self.get_product(product_id)
        product = prod_wrap.get("product") if isinstance(prod_wrap.get("product"), dict) else prod_wrap
        if not isinstance(product, dict):
            raise ValueError("Unexpected product response shape")

        sid_map = product.get("screen_definition_ids") or {}
        if record_types is not None:
            rts: List[str] = [str(x) for x in record_types[:max_layout_types]]
        else:
            rts = [str(k) for k, v in sid_map.items() if v][:max_layout_types]
            if not rts:
                rts = ["Feature"]

        layouts: Dict[str, Any] = {}
        for rt in rts:
            sid = sid_map.get(rt)
            if not sid:
                warnings.append(f"No screen_definition_ids entry for record_type={rt!r}")
                continue
            try:
                layouts[rt] = await self.get_screen_definition(str(sid))
            except Exception as e:
                warnings.append(f"Layout fetch failed for {rt!r} (id={sid}): {e!s}")

        all_defs: List[Dict[str, Any]] = []
        for page in range(1, custom_definitions_max_pages + 1):
            chunk = await self.list_custom_field_definitions(limit=100, page=page)
            defs = chunk.get("custom_field_definitions") or []
            if isinstance(defs, list):
                all_defs.extend(defs)
            if not isinstance(defs, list) or len(defs) < 100:
                break

        picklist_options: Dict[str, Any] = {}
        calls = 0
        rt_set = set(rts)

        if include_picklist_options:
            candidate_ids: set[str] = set()
            for lay in layouts.values():
                if not isinstance(lay, dict):
                    continue
                for d in lay.get("custom_field_definitions") or []:
                    if not isinstance(d, dict):
                        continue
                    did = d.get("id")
                    if did is None or not _field_suggests_picklist(d):
                        continue
                    if not d.get("options"):
                        candidate_ids.add(str(did))
            for d in all_defs:
                if not isinstance(d, dict):
                    continue
                if d.get("custom_fieldable_type") not in rt_set:
                    continue
                did = d.get("id")
                if did is None or not _field_suggests_picklist(d):
                    continue
                if not d.get("options"):
                    candidate_ids.add(str(did))

            for did in sorted(candidate_ids):
                if calls >= max_option_api_calls:
                    warnings.append(
                        f"Reached max_option_api_calls={max_option_api_calls}; "
                        f"{len(candidate_ids) - calls} picklist definition(s) not fetched."
                    )
                    break
                try:
                    picklist_options[did] = await self.list_custom_field_options(
                        did, use_cache=use_cache
                    )
                    calls += 1
                except Exception as e:
                    warnings.append(f"options for definition {did}: {e!s}")

        return {
            "schema_version": 1,
            "generated_at": generated,
            "account_domain": self.account_domain,
            "product_id": product.get("id"),
            "product": product,
            "layouts_by_record_type": layouts,
            "custom_field_definitions": all_defs,
            "picklist_options_by_definition_id": picklist_options,
            "warnings": warnings,
            "export_settings": {
                "record_types": rts,
                "include_picklist_options": include_picklist_options,
                "max_layout_types": max_layout_types,
                "max_option_api_calls": max_option_api_calls,
                "custom_definitions_max_pages": custom_definitions_max_pages,
                "bypass_cache": bypass_cache,
            },
        }

    # Pages (Notes) — UI "Notes" are `pages` in the REST API.

    async def list_pages(
        self,
        product_id: str,
        query: Optional[str] = None,
        limit: int = 30,
        page: int = 1,
    ) -> Dict[str, Any]:
        """GET /products/:product_id/pages — optional q matches page name."""
        params: Dict[str, Any] = {"per_page": limit, "page": page}
        if query:
            params["q"] = query
        return await self._request("GET", f"/products/{product_id}/pages", params=params)

    async def get_page(self, page_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """GET /pages/:id — id may be numeric or page reference key."""
        params: Optional[Dict[str, Any]] = None
        if fields:
            params = {"fields": fields}
        return await self._request("GET", f"/pages/{page_id}", params=params)

    async def create_page(
        self,
        product_id: str,
        name: str,
        description: Optional[str] = None,
        document_type: Optional[str] = None,
        table_of_contents_enabled: Optional[bool] = None,
        parent_id: Optional[str] = None,
        tags: Optional[str] = None,
        editor_width: Optional[str] = None,
        workflow_status: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        POST /products/:product_id/pages — body uses top-level key ``page`` per Aha! API.
        """
        page_payload: Dict[str, Any] = {"name": name}
        if description is not None:
            page_payload["description_attributes"] = {"body": description}
        if document_type is not None:
            page_payload["document_type"] = document_type
        if table_of_contents_enabled is not None:
            page_payload["table_of_contents_enabled"] = table_of_contents_enabled
        if parent_id is not None:
            page_payload["parent_id"] = parent_id
        if tags is not None:
            page_payload["tags"] = tags
        if editor_width is not None:
            page_payload["editor_width"] = editor_width
        if workflow_status is not None:
            page_payload["workflow_status"] = workflow_status
        return await self._request(
            "POST",
            f"/products/{product_id}/pages",
            data={"page": page_payload},
        )

    async def update_page(
        self,
        page_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        table_of_contents_enabled: Optional[bool] = None,
        parent_id: Optional[str] = None,
        tags: Optional[str] = None,
        editor_width: Optional[str] = None,
        workflow_status: Optional[str] = None,
    ) -> Dict[str, Any]:
        """PUT /pages/:id — partial updates: only include fields you pass."""
        page_payload: Dict[str, Any] = {}
        if name is not None:
            page_payload["name"] = name
        if description is not None:
            page_payload["description_attributes"] = {"body": description}
        if table_of_contents_enabled is not None:
            page_payload["table_of_contents_enabled"] = table_of_contents_enabled
        if parent_id is not None:
            page_payload["parent_id"] = parent_id
        if tags is not None:
            page_payload["tags"] = tags
        if editor_width is not None:
            page_payload["editor_width"] = editor_width
        if workflow_status is not None:
            page_payload["workflow_status"] = workflow_status
        return await self._request(
            "PUT",
            f"/pages/{page_id}",
            data={"page": page_payload},
        )

    async def delete_page(self, page_id: str) -> Dict[str, Any]:
        """DELETE /pages/:id — Aha! returns 204 with no body."""
        return await self._request("DELETE", f"/pages/{page_id}")

    async def list_page_record_links(
        self,
        page_id: str,
        parent_and_child_links: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """
        GET /pages/:id/record_links — use response record link ``id`` values with delete_record_link.
        When parent_and_child_links is True, query includes links where the page is parent or child.
        """
        params: Optional[Dict[str, Any]] = None
        if parent_and_child_links is True:
            params = {"parent_and_child_links": True}
        return await self._request("GET", f"/pages/{page_id}/record_links", params=params)

    async def create_page_record_link(
        self,
        page_id: str,
        record_type: str,
        record_id: str,
        link_type: int,
    ) -> Dict[str, Any]:
        """
        POST /pages/:page_id/record_links — link this page to another record.
        record_type: feature, release, idea, epic, release_phase, initiative, page, goal.
        link_type: 10 relates to, 20 depends on, 30 duplicated by, 40 contained by,
        50 impacted by, 60 blocked by, 80 research for.
        May return 204 with no JSON body.
        """
        rid: Any = record_id
        if isinstance(rid, str) and rid.strip().isdigit():
            rid = int(rid.strip())
        body: Dict[str, Any] = {
            "record_link": {
                "record_type": record_type,
                "record_id": rid,
                "link_type": link_type,
            }
        }
        return await self._request("POST", f"/pages/{page_id}/record_links", data=body)

    async def delete_record_link(self, record_link_id: str) -> Dict[str, Any]:
        """DELETE /record_links/:id — Aha! returns 204 with no body."""
        return await self._request("DELETE", f"/record_links/{record_link_id}")

