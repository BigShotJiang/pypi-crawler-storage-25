"""Aha! Model Context Protocol server package."""

__version__ = "1.2.0"
