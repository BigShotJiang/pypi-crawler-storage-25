#!/usr/bin/env python3
"""
MCP Server for AHA! API
Supports ideas, features, epics, releases, release phases, initiatives, custom fields, pages (notes), and record links.
"""

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .aha_client import AhaClient
from .context_cache import ContextCache

# Load .env from the package directory, then current working directory
_pkg_dir = Path(__file__).resolve().parent
_env_candidates = (_pkg_dir / ".env", Path.cwd() / ".env")
for _env_path in _env_candidates:
    if _env_path.exists():
        load_dotenv(_env_path, override=True)
        break
else:
    load_dotenv(override=True)


# Initialize the MCP server
server = Server("aha-mcp-server")

# Reusable JSON Schema descriptions for tool parameters (LLM-oriented).
_WF_STATUS_FILTER = (
    "Optional. Aha! workflow status id for filtering (API id), not the human-readable status name. "
    "Use ids from get_*/search_* results (e.g. workflow_status.id on each record)."
)
_WF_STATUS_WRITE = (
    "Optional. Aha! workflow status id to set (API id), not the status label. "
    "Get ids from get_*/search_* responses (workflow_status.id) or your Aha! workflow configuration."
)
_FIELDS_OPT = (
    "Optional. Comma-separated Aha! API attribute names to return (smaller payload). "
    "Example: name,description,workflow_status,start_date. See Aha! REST API docs for that resource type."
)
_IDEAS_SORT_DESC = (
    "Sort order. 'popular' = most voted (use for 'top voted' queries). "
    "'trending' = recent vote velocity. 'recent' = newest first (default in Aha)."
)
_IDEAS_FIELDS_SEARCH = (
    "Comma-separated extra fields to include. Common: endorsements_count,score,workflow_status. "
    "Default response excludes vote count."
)
_PARTIAL_UPDATE = (
    "Partial update: include only parameters you want to change; omitted keys leave existing values unchanged."
)
_LINK_TYPE_DESC = (
    "Aha! link_type integer: 10=relates to, 20=depends on, 30=duplicated by, 40=contained by, "
    "50=impacted by, 60=blocked by, 80=research for."
)
_RECORD_LINK_TARGET_TYPE = (
    "Target record type for the link (Aha! API value): feature, release, idea, epic, "
    "release_phase, initiative, page, or goal."
)
_FEATURE_RELEASE_PHASE = (
    "Optional. Aha! release phase for the feature (API field release_phase): numeric id as string "
    "(from list_release_phases or get_feature → belongs_to_release_phase.id) or the exact phase name on that release."
)

# Initialize AHA client and context cache
aha_client: Optional[AhaClient] = None
context_cache: Optional[ContextCache] = None


def get_client() -> AhaClient:
    """Get or create the AHA client instance with context cache."""
    global aha_client, context_cache
    if aha_client is None:
        account_domain = os.getenv("AHA_ACCOUNT_DOMAIN")
        api_key = os.getenv("AHA_API_KEY")
        
        if not account_domain:
            raise ValueError("AHA_ACCOUNT_DOMAIN environment variable is required. Please set it in your .env file or as an environment variable.")
        if not api_key:
            raise ValueError("AHA_API_KEY environment variable is required. Please set it in your .env file or as an environment variable.")
        
        # Create client first
        aha_client = AhaClient(account_domain, api_key)
        # Initialize context cache with the client
        context_cache = ContextCache(aha_client, ttl_minutes=30)
        # Set the cache in the client
        aha_client.context_cache = context_cache
    return aha_client


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List all available tools."""
    return [
        Tool(
            name="search_ideas",
            description="Search for ideas in a product. Typical flow: resolve product_id (argument or AHA_PRODUCT_ID env) → search or get records → create_idea / update_idea with only the fields you need. All operations are scoped to a product. Filter by release, epic, or initiative using IDs or names (names are resolved via an internal cache). If product_id is omitted, AHA_PRODUCT_ID is used when set. Discovery-first: preloads releases, epics, and initiatives into the cache before searching. For 'most voted' or 'top ideas' queries, pass sort='popular' and fields='endorsements_count'. Aha! caps per_page at 200; larger limit is clamped to 200.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter ideas by name or description (e.g., 'mobile app'). Uses the 'q' parameter to search idea names and descriptions."
                    },
                    "sort": {
                        "type": "string",
                        "enum": ["recent", "trending", "popular"],
                        "description": _IDEAS_SORT_DESC,
                    },
                    "fields": {
                        "type": "string",
                        "description": _IDEAS_FIELDS_SEARCH,
                    },
                    "created_since": {
                        "type": "string",
                        "description": "ISO8601 timestamp; pass-through to Aha! created_since filter.",
                    },
                    "created_before": {
                        "type": "string",
                        "description": "ISO8601 timestamp; pass-through to Aha! created_before filter.",
                    },
                    "updated_since": {
                        "type": "string",
                        "description": "ISO8601 timestamp; pass-through to Aha! updated_since filter.",
                    },
                    "tag": {
                        "type": "string",
                        "description": "Tag filter (pass-through to Aha!).",
                    },
                    "user_id": {
                        "type": "string",
                        "description": "User id filter (pass-through to Aha!).",
                    },
                    "idea_user_id": {
                        "type": "string",
                        "description": "Idea user id filter (pass-through to Aha!).",
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Filter by release ID. Takes precedence over release_name if both are provided."
                    },
                    "release_name": {
                        "type": "string",
                        "description": "Filter by release name (e.g., 'Q4 Release', 'Q4 2024'). Will be automatically resolved to release_id using fuzzy matching. Use this for natural language queries like 'ideas in Q4 Release'."
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Filter by epic ID. Takes precedence over epic_name if both are provided."
                    },
                    "epic_name": {
                        "type": "string",
                        "description": "Filter by epic name. Will be automatically resolved to epic_id using fuzzy matching. Use this for natural language queries."
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Filter by initiative ID. Takes precedence over initiative_name if both are provided."
                    },
                    "initiative_name": {
                        "type": "string",
                        "description": "Filter by initiative name. Will be automatically resolved to initiative_id using fuzzy matching. Use this for natural language queries."
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_FILTER
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results per page (default: 25). Capped at 200 (Aha! per_page maximum).",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_idea",
            description="Retrieve a specific idea by ID or reference number. Call before update_idea when you need current fields (e.g. workflow_status.id for a status change).",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Idea ID or reference number (e.g., 'PRJ1-I-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": _FIELDS_OPT
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_idea",
            description="Create a new idea in AHA!. product_id selects the product (workspace). For workflow_status_id, pass the Aha! API id from a prior get/search (workflow_status.id), not the display name.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the idea"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID where the idea should be created (products belong to workspaces)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description of the idea (HTML or plain text)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "submitted_idea_portal_id": {
                        "type": "string",
                        "description": "Idea portal ID if submitting from a portal (optional)"
                    },
                    "skip_portal": {
                        "type": "boolean",
                        "description": "Skip portal submission (default: false)",
                        "default": False
                    }
                },
                "required": ["name", "product_id"]
            }
        ),
        Tool(
            name="update_idea",
            description=_PARTIAL_UPDATE + " Update an existing idea. Pass id plus only fields to change.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Idea ID or reference number"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the idea"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description for the idea"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID to move the idea to"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="search_features",
            description="Search for features in a product. Typical flow: resolve product_id (argument or AHA_PRODUCT_ID) → search or get → create_feature / update_feature. Scoped to a product unless you narrow by release_id, epic_id, or initiative_id (or *_name, resolved via cache). Uses nested Aha! list endpoints when a container id is set. Discovery-first: preloads releases, epics, and initiatives before searching.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter features by name or description (e.g., 'data lake'). Uses the 'q' parameter to search feature names and descriptions."
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Filter by release ID. When provided, searches only within this release. Takes precedence over release_name if both are provided."
                    },
                    "release_name": {
                        "type": "string",
                        "description": "Filter by release name (e.g., 'Q4 Release', 'Q4 2024'). Will be automatically resolved to release_id using fuzzy matching. Use this for natural language queries like 'features in Q4 Release'."
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Filter by epic ID. When provided, searches only within this epic. Takes precedence over epic_name if both are provided."
                    },
                    "epic_name": {
                        "type": "string",
                        "description": "Filter by epic name. Will be automatically resolved to epic_id using fuzzy matching. Use this for natural language queries."
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Filter by initiative ID. When provided, searches only within this initiative. Takes precedence over initiative_name if both are provided."
                    },
                    "initiative_name": {
                        "type": "string",
                        "description": "Filter by initiative name. Will be automatically resolved to initiative_id using fuzzy matching. Use this for natural language queries."
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_FILTER
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_feature",
            description="Retrieve a specific feature by ID or reference number. Call before update_feature when you need current fields (e.g. workflow_status.id, belongs_to_release_phase.id for release_phase updates).",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Feature ID or reference number (e.g., 'PRJ1-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": _FIELDS_OPT
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_feature",
            description=(
                "Create a new feature in AHA!. release_id is required (id or key, e.g. PRJ1-R-1). If the user has no timebox, use search_releases for a backlog release. "
                "Optional release_phase assigns the feature to a release phase or milestone (see list_release_phases). "
                "Built-in columns use top-level parameters (name, description, workflow_status_id, etc.). "
                "When user intent includes product-specific or Deltek-style data (e.g. area, business unit), treat it as custom fields: "
                "(1) Resolve product_id (argument or AHA_PRODUCT_ID). "
                "(2) get_custom_layout_for_product_record with record_type Feature — map user phrases to each item's `key` (and `name`); honor `required`; use inline `options` when present. "
                "(3) If a list field has no inline options, call list_custom_field_options with that field's `id`. "
                "(4) Build custom_fields as {\"<key>\": <value>} only for custom columns; for choice fields prefer each option's `value` from /options when writes expect ids. "
                "(5) Call create_feature once with name, release_id, standard fields, and custom_fields. If mapping is ambiguous, ask the user before inventing keys."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the feature"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID where the feature should be created (releases belong to products, which belong to workspaces)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description of the feature (HTML or plain text)"
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Epic ID to associate the feature with (optional)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format (optional)"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format (optional)"
                    },
                    "release_phase": {
                        "type": "string",
                        "description": _FEATURE_RELEASE_PHASE,
                    },
                    "custom_fields": {
                        "type": "object",
                        "description": "Optional. Only fields that are not standard feature columns. Keys are the string `key` from the layout or definitions (not display names). Same discovery flow as create_feature.",
                        "additionalProperties": True
                    }
                },
                "required": ["name", "release_id"]
            }
        ),
        Tool(
            name="update_feature",
            description=_PARTIAL_UPDATE + " Update an existing feature. Pass id plus only fields to change. Use release_phase to move the feature to a phase (id or name). For custom data the user mentions, use the same layout/options discovery as create_feature, then pass custom_fields.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Feature ID or reference number"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the feature"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description for the feature"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID to move the feature to"
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Epic ID to associate the feature with"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format"
                    },
                    "release_phase": {
                        "type": "string",
                        "description": _FEATURE_RELEASE_PHASE,
                    },
                    "custom_fields": {
                        "type": "object",
                        "description": "Optional. Custom field key → value map to set or merge (see Aha! feature custom_fields).",
                        "additionalProperties": True
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="search_epics",
            description="Search for epics in a product. Typical flow: product_id (or AHA_PRODUCT_ID) → optional release_id to narrow to one release → get_epic / create_epic / update_epic. If release_id is set, uses the release-scoped epic list.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter epics by name or description"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Filter by release ID (searches within this release if provided)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_FILTER
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_epic",
            description="Retrieve a specific epic by ID or reference number. Call before update_epic when you need current fields (e.g. workflow_status.id).",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Epic ID or reference number (e.g., 'PRJ1-E-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": _FIELDS_OPT
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_epic",
            description="Create a new epic in AHA!. Provide release_id, or product_id to create in the product's default release. workflow_status_id must be the Aha! API id (from get_epic / search_epics), not the label.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the epic"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID where the epic should be created (required if product_id not provided)"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (creates in default release if release_id not provided)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description of the epic (HTML or plain text)"
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Initiative ID to associate the epic with (optional)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format (optional)"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format (optional)"
                    }
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="update_epic",
            description=_PARTIAL_UPDATE + " Update an existing epic. Pass id plus only fields to change.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Epic ID or reference number"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the epic"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description for the epic"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID to move the epic to"
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Initiative ID to associate the epic with"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="search_releases",
            description="List or search releases for a product (product_id or AHA_PRODUCT_ID). Use this to find release_id values for create_feature or to pick a backlog release when the user has no ship target yet.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID to list releases for (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter releases by name or description"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_FILTER
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_release",
            description="Retrieve a specific release by ID or reference number. Call before update_release when you need product_id, dates, or workflow_status.id.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Release ID or reference number (e.g., 'PRJ1-R-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": _FIELDS_OPT
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_release",
            description="Create a new release in a product. workflow_status_id maps to Aha! release status (API id from get_release / search_releases or your workflow config), not the display name.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the release"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID where the release should be created (required)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description/theme of the release (HTML or plain text)"
                    },
                    "release_date": {
                        "type": "string",
                        "description": "Release date in YYYY-MM-DD format (optional)"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format (optional)"
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date in YYYY-MM-DD format (optional)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "owner_email": {
                        "type": "string",
                        "description": "Owner email address (optional)"
                    }
                },
                "required": ["name", "product_id"]
            }
        ),
        Tool(
            name="update_release",
            description=_PARTIAL_UPDATE + " Update an existing release. Pass id, product_id, and only fields to change.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Release ID or reference number"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (required)"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the release"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description/theme for the release"
                    },
                    "release_date": {
                        "type": "string",
                        "description": "Release date in YYYY-MM-DD format"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format"
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date in YYYY-MM-DD format"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": _WF_STATUS_WRITE
                    },
                    "owner_email": {
                        "type": "string",
                        "description": "Owner email address"
                    }
                },
                "required": ["id", "product_id"]
            }
        ),
        Tool(
            name="list_release_phases",
            description=(
                "List release phases and milestones for a release (GET /releases/:id/release_phases). "
                "Pass release_id, or release_name with product_id (or AHA_PRODUCT_ID) for fuzzy name resolution via cache. "
                "Use search_releases to discover releases. Optional phase_kind filters to phase or milestone only."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "release_id": {
                        "type": "string",
                        "description": "Release ID or reference key. Takes precedence over release_name.",
                    },
                    "release_name": {
                        "type": "string",
                        "description": "Release name; resolved to release_id when product_id (or AHA_PRODUCT_ID) is set.",
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID for release_name resolution (optional if AHA_PRODUCT_ID is set).",
                    },
                    "phase_kind": {
                        "type": "string",
                        "enum": ["phase", "milestone"],
                        "description": "Maps to Aha! query parameter type: only phases or only milestones.",
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="get_release_phase",
            description="Get one release phase or milestone by id (GET /release_phases/:id).",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Release phase numeric id (string) or API identifier",
                    },
                    "fields": {"type": "string", "description": _FIELDS_OPT},
                },
                "required": ["id"],
            },
        ),
        Tool(
            name="create_release_phase",
            description=(
                "Create a release phase or milestone (POST /release_phases). "
                "Requires name, phase_type (phase or milestone), and release_id or release_name (+ product_id / AHA_PRODUCT_ID). "
                "See Aha! docs for progress_source, duration_source, and progress (manual progress only)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Phase or milestone name"},
                    "phase_type": {
                        "type": "string",
                        "enum": ["phase", "milestone"],
                        "description": "Aha! phase_type: phase or milestone",
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release id or key; takes precedence over release_name",
                    },
                    "release_name": {
                        "type": "string",
                        "description": "Resolved via cache when product_id or AHA_PRODUCT_ID is available",
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID for release_name resolution",
                    },
                    "start_on": {
                        "type": "string",
                        "description": "Start date YYYY-MM-DD",
                    },
                    "end_on": {
                        "type": "string",
                        "description": "End date YYYY-MM-DD",
                    },
                    "description": {
                        "type": "string",
                        "description": "HTML or plain text description",
                    },
                    "progress_source": {
                        "type": "string",
                        "description": (
                            "e.g. progress_manual, progress_from_features, progress_from_todos, "
                            "progress_from_features_completed, … (Aha! API)"
                        ),
                    },
                    "progress": {
                        "type": "number",
                        "description": "Manual progress only; use when progress_source is manual",
                    },
                    "duration_source": {
                        "type": "string",
                        "description": "duration_manual or duration_from_features (Aha! API)",
                    },
                },
                "required": ["name", "phase_type"],
            },
        ),
        Tool(
            name="update_release_phase",
            description=(
                _PARTIAL_UPDATE
                + " Update a release phase (PUT /release_phases/:id). "
                "If you omit phase_type, the server loads the current record and sends the existing phase_type."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {"type": "string", "description": "Release phase id"},
                    "name": {"type": "string"},
                    "phase_type": {"type": "string", "enum": ["phase", "milestone"]},
                    "start_on": {"type": "string", "description": "YYYY-MM-DD"},
                    "end_on": {"type": "string", "description": "YYYY-MM-DD"},
                    "description": {"type": "string"},
                    "progress_source": {"type": "string"},
                    "progress": {"type": "number", "description": "Manual progress when applicable"},
                    "duration_source": {"type": "string"},
                },
                "required": ["id"],
            },
        ),
        Tool(
            name="delete_release_phase",
            description="Delete a release phase or milestone (DELETE /release_phases/:id). Returns 204 from Aha!.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {"type": "string", "description": "Release phase id"},
                },
                "required": ["id"],
            },
        ),
        Tool(
            name="list_initiatives",
            description="List initiatives for a product (product_id or AHA_PRODUCT_ID). Use with search_features / search_ideas when filtering by initiative name or id.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter initiatives by name or description"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_initiative",
            description="Retrieve a specific initiative by ID or reference number. Use fields to limit the payload when chaining with other tools.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Initiative ID or reference number (e.g., 'PRJ1-S-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": _FIELDS_OPT
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="list_custom_field_definitions",
            description=(
                "List account-wide Aha! custom field definitions (GET /custom_field_definitions). "
                "Each entry includes id, key, name, type, and custom_fieldable_type (e.g. Feature, Epic, Ideas::Idea). "
                "Use list_custom_field_options when you need allowed values for a choice field. "
                "For product-specific layouts (which fields appear and required), use get_custom_layout_for_product_record. "
                "If custom_fieldable_type is set, only definitions matching that type are returned for this page (paginate without it to scan all)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "custom_fieldable_type": {
                        "type": "string",
                        "description": "Optional filter: e.g. Feature, Epic, Release, Ideas::Idea, Initiative, Requirement (matches custom_fieldable_type on each definition for this page only)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "per_page (default: 100)",
                        "default": 100
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="list_custom_field_options",
            description=(
                "List allowed values for a choice-style custom field (GET /custom_field_definitions/:id/options). "
                "Pass the custom field definition id from list_custom_field_definitions or from a layout. "
                "Response typically includes options with text, value, and meta."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "custom_field_definition_id": {
                        "type": "string",
                        "description": "Numeric id of the custom field definition (not the field key string)"
                    },
                    "use_cache": {
                        "type": "boolean",
                        "description": "If true (default), reuse cached /options for 15 minutes to reduce API calls.",
                        "default": True
                    }
                },
                "required": ["custom_field_definition_id"]
            }
        ),
        Tool(
            name="get_custom_layout_for_product_record",
            description=(
                "Discover custom fields for a product and record type via the custom layout (screen definition): "
                "loads product.screen_definition_ids[record_type] then GET /screen_definitions/:id. "
                "Response custom_field_definitions entries include `key` (use as create_feature/update_feature custom_fields object keys), `name`, `type`, `required`, and sometimes `options`. "
                "Typical record_type values: Feature, Epic, Release, Ideas::Idea, Initiative, Requirement. "
                "May require configuration-admin API permissions. If this fails, fall back to list_custom_field_definitions + list_custom_field_options."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "record_type": {
                        "type": "string",
                        "description": "Layout key, default Feature (must match a key in product.screen_definition_ids)",
                        "default": "Feature"
                    },
                    "use_cache": {
                        "type": "boolean",
                        "description": "If true (default), reuse cached layout JSON for this product+record_type for 15 minutes.",
                        "default": True
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="export_product_seed_bundle",
            description=(
                "One-shot export for seeding LLM context or files: full product JSON, screen layouts per record type, "
                "all paginated custom_field_definitions for the account, and picklist options (GET .../options) for "
                "choice-like fields missing inline options. Use after Aha! admin changes; save the JSON and prefer lazy "
                "discovery at runtime. Set bypass_cache true (default) so the export is fresh. "
                "Caps (max_option_api_calls, max_layout_types) prevent excessive API traffic."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set)"
                    },
                    "record_types": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Which layouts to fetch (e.g. Feature, Epic). If omitted, uses all keys from product.screen_definition_ids (up to max_layout_types)."
                    },
                    "include_picklist_options": {
                        "type": "boolean",
                        "description": "If true (default), fetch /options for picklist-like fields without inline options.",
                        "default": True
                    },
                    "max_layout_types": {
                        "type": "integer",
                        "description": "Max number of record_type layouts to pull (default: 12)",
                        "default": 12
                    },
                    "max_option_api_calls": {
                        "type": "integer",
                        "description": "Max number of /options GET calls (default: 48)",
                        "default": 48
                    },
                    "custom_definitions_max_pages": {
                        "type": "integer",
                        "description": "Max pages when listing custom_field_definitions at 100 per page (default: 30)",
                        "default": 30
                    },
                    "bypass_cache": {
                        "type": "boolean",
                        "description": "If true (default), bypass 15m layout/options cache so export reflects current Aha! state.",
                        "default": True
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="list_pages",
            description=(
                "List or search pages (Notes) for a product. In Aha!, UI Notes are exposed as `pages` in the API. "
                "Uses GET /products/:product_id/pages with optional q. product_id or AHA_PRODUCT_ID required."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)",
                    },
                    "query": {
                        "type": "string",
                        "description": "Search string matched against page name (maps to API parameter q)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results per page (default: 30)",
                        "default": 30,
                    },
                    "page": {
                        "type": "integer",
                        "description": "Pagination page number (default: 1)",
                        "default": 1,
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="get_page",
            description=(
                "Retrieve one page (Note) by id or reference key. GET /pages/:id. "
                "Use list_pages to discover ids; use fields to trim the payload."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Page id (numeric) or reference key",
                    },
                    "fields": {"type": "string", "description": _FIELDS_OPT},
                },
                "required": ["id"],
            },
        ),
        Tool(
            name="create_page",
            description=(
                "Create a page (Note) under a product. POST /products/:product_id/pages with JSON key `page`. "
                "description is stored as description_attributes.body (HTML). "
                "document_type: note (default), whiteboard, folder, internal_link, external_link. "
                "workflow_status_id sets page workflow status (pass Aha! status id string for this product)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set)",
                    },
                    "name": {"type": "string", "description": "Page title"},
                    "description": {
                        "type": "string",
                        "description": "Body HTML or plain text (maps to description_attributes.body)",
                    },
                    "document_type": {
                        "type": "string",
                        "description": "note | whiteboard | folder | internal_link | external_link",
                    },
                    "table_of_contents_enabled": {"type": "boolean"},
                    "parent_id": {
                        "type": "string",
                        "description": "Parent page or folder id to nest under",
                    },
                    "tags": {
                        "type": "string",
                        "description": "Comma-separated tags",
                    },
                    "editor_width": {
                        "type": "string",
                        "description": "NARROW or FULL",
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Workflow status id for the page (Aha! API field workflow_status)",
                    },
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="update_page",
            description=_PARTIAL_UPDATE + " Update a page (Note). PUT /pages/:id with JSON key `page`.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {"type": "string", "description": "Page id or reference key"},
                    "name": {"type": "string"},
                    "description": {
                        "type": "string",
                        "description": "New body HTML (description_attributes.body)",
                    },
                    "table_of_contents_enabled": {"type": "boolean"},
                    "parent_id": {"type": "string"},
                    "tags": {"type": "string", "description": "Comma-separated tags"},
                    "editor_width": {"type": "string", "description": "NARROW or FULL"},
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Workflow status id (maps to workflow_status in API)",
                    },
                },
                "required": ["id"],
            },
        ),
        Tool(
            name="delete_page",
            description="Delete a page (Note). DELETE /pages/:id — returns success with no body from Aha!.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {"type": "string", "description": "Page id or reference key"},
                },
                "required": ["id"],
            },
        ),
        Tool(
            name="list_page_record_links",
            description=(
                "List record links for a page (GET /pages/:id/record_links). "
                "Use each link's id with delete_record_link to unlink. "
                "Optional parent_and_child_links includes links where the page is parent or child."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "page_id": {"type": "string", "description": "Page id or reference key"},
                    "parent_and_child_links": {
                        "type": "boolean",
                        "description": "If true, include links in both directions (default: false)",
                        "default": False,
                    },
                },
                "required": ["page_id"],
            },
        ),
        Tool(
            name="create_page_record_link",
            description=(
                "Link a page to another Aha! record. POST /pages/:page_id/record_links. "
                + _RECORD_LINK_TARGET_TYPE
                + " "
                + _LINK_TYPE_DESC
                + " Aha! may respond with 204 and no JSON; tool still reports success."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "page_id": {"type": "string", "description": "Source page id or key"},
                    "record_type": {"type": "string", "description": _RECORD_LINK_TARGET_TYPE},
                    "record_id": {
                        "type": "string",
                        "description": "Target record id or reference key (e.g. feature key)",
                    },
                    "link_type": {
                        "type": "integer",
                        "description": _LINK_TYPE_DESC,
                    },
                },
                "required": ["page_id", "record_type", "record_id", "link_type"],
            },
        ),
        Tool(
            name="delete_record_link",
            description=(
                "Remove a record link by its link id (DELETE /record_links/:id). "
                "The id is the record_link id from list_page_record_links (or similar list_*_record_links), "
                "not the page or feature id."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {"type": "string", "description": "record_links row id (numeric string)"},
                },
                "required": ["id"],
            },
        ),
        Tool(
            name="invalidate_metadata_cache",
            description="Clear the server-side 15-minute cache used for get_custom_layout_for_product_record and list_custom_field_options. Call after Aha! configuration changes during an active session.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""
    client = get_client()
    
    # Get default product ID from environment if available
    default_product_id = os.getenv("AHA_PRODUCT_ID")
    
    try:
        if name == "search_ideas":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            
            if "product_id" not in arguments or not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": "product_id is required. Either provide it as a parameter or set AHA_PRODUCT_ID in your environment."}, indent=2)
                )]
            
            # Discovery-first approach: populate context cache before searching
            # This ensures releases, epics, and initiatives are available for name resolution
            if client.context_cache:
                product_id = arguments["product_id"]
                # Pre-populate cache with product structure
                await asyncio.gather(
                    client.context_cache.get_releases(product_id),
                    client.context_cache.get_epics(product_id),
                    client.context_cache.get_initiatives(product_id),
                    return_exceptions=True
                )
            
            # Extract name-based parameters and pass them to search_ideas
            result = await client.search_ideas(
                product_id=arguments["product_id"],
                query=arguments.get("query"),
                release_id=arguments.get("release_id"),
                release_name=arguments.get("release_name"),
                epic_id=arguments.get("epic_id"),
                epic_name=arguments.get("epic_name"),
                initiative_id=arguments.get("initiative_id"),
                initiative_name=arguments.get("initiative_name"),
                workflow_status_id=arguments.get("workflow_status_id"),
                sort=arguments.get("sort"),
                fields=arguments.get("fields"),
                created_since=arguments.get("created_since"),
                created_before=arguments.get("created_before"),
                updated_since=arguments.get("updated_since"),
                tag=arguments.get("tag"),
                user_id=arguments.get("user_id"),
                idea_user_id=arguments.get("idea_user_id"),
                limit=arguments.get("limit", 25),
                page=arguments.get("page", 1)
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_idea":
            result = await client.get_idea(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_idea":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.create_idea(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_idea":
            result = await client.update_idea(arguments["id"], **{k: v for k, v in arguments.items() if k != "id"})
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "search_features":
            # Use default product_id if not provided
            if ("product_id" not in arguments or not arguments.get("product_id")) and default_product_id:
                arguments["product_id"] = default_product_id
            
            if "product_id" not in arguments or not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": "product_id is required. Either provide it as a parameter or set AHA_PRODUCT_ID in your environment."}, indent=2)
                )]
            
            # Discovery-first approach: populate context cache before searching
            # This ensures releases, epics, and initiatives are available for name resolution
            if client.context_cache:
                product_id = arguments["product_id"]
                # Pre-populate cache with product structure
                await asyncio.gather(
                    client.context_cache.get_releases(product_id),
                    client.context_cache.get_epics(product_id),
                    client.context_cache.get_initiatives(product_id),
                    return_exceptions=True
                )
            
            # Extract name-based parameters and pass them to search_features
            result = await client.search_features(
                product_id=arguments["product_id"],
                query=arguments.get("query"),
                release_id=arguments.get("release_id"),
                release_name=arguments.get("release_name"),
                epic_id=arguments.get("epic_id"),
                epic_name=arguments.get("epic_name"),
                initiative_id=arguments.get("initiative_id"),
                initiative_name=arguments.get("initiative_name"),
                workflow_status_id=arguments.get("workflow_status_id"),
                limit=arguments.get("limit", 25),
                page=arguments.get("page", 1)
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_feature":
            result = await client.get_feature(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_feature":
            result = await client.create_feature(
                name=arguments["name"],
                release_id=arguments["release_id"],
                description=arguments.get("description"),
                epic_id=arguments.get("epic_id"),
                workflow_status_id=arguments.get("workflow_status_id"),
                start_date=arguments.get("start_date"),
                due_date=arguments.get("due_date"),
                release_phase=arguments.get("release_phase"),
                custom_fields=arguments.get("custom_fields"),
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_feature":
            _uf_keys = {
                "name", "description", "workflow_status_id", "release_id",
                "epic_id", "start_date", "due_date", "release_phase", "custom_fields",
            }
            payload = {
                k: v for k, v in arguments.items()
                if k != "id" and k in _uf_keys
            }
            result = await client.update_feature(arguments["id"], **payload)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "search_epics":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.search_epics(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_epic":
            result = await client.get_epic(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_epic":
            result = await client.create_epic(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_epic":
            result = await client.update_epic(arguments["id"], **{k: v for k, v in arguments.items() if k != "id"})
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "search_releases":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.search_releases(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_release":
            result = await client.get_release(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_release":
            result = await client.create_release(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_release":
            result = await client.update_release(arguments["id"], arguments["product_id"], **{k: v for k, v in arguments.items() if k not in ["id", "product_id"]})
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]

        elif name == "list_release_phases":
            rid = arguments.get("release_id")
            rname = arguments.get("release_name")
            pid = arguments.get("product_id") or default_product_id
            if not rid and rname:
                if not pid:
                    return [TextContent(
                        type="text",
                        text=json.dumps(
                            {
                                "error": "product_id is required (or AHA_PRODUCT_ID) when using release_name.",
                            },
                            indent=2,
                        ),
                    )]
                if client.context_cache:
                    await client.context_cache.get_releases(str(pid))
                    match = await client.context_cache.find_release_by_name(str(pid), str(rname))
                    if match:
                        rid = match[0]
            if not rid:
                return [TextContent(
                    type="text",
                    text=json.dumps(
                        {"error": "release_id is required, or release_name with product_id/AHA_PRODUCT_ID."},
                        indent=2,
                    ),
                )]
            result = await client.list_release_phases(
                str(rid),
                phase_kind=arguments.get("phase_kind"),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "get_release_phase":
            result = await client.get_release_phase(
                arguments["id"],
                arguments.get("fields"),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "create_release_phase":
            rel_id = arguments.get("release_id")
            rname = arguments.get("release_name")
            pid = arguments.get("product_id") or default_product_id
            if not rel_id and rname:
                if not pid:
                    return [TextContent(
                        type="text",
                        text=json.dumps(
                            {
                                "error": "product_id is required (or AHA_PRODUCT_ID) when using release_name.",
                            },
                            indent=2,
                        ),
                    )]
                if client.context_cache:
                    await client.context_cache.get_releases(str(pid))
                    match = await client.context_cache.find_release_by_name(str(pid), str(rname))
                    if match:
                        rel_id = match[0]
            if not rel_id:
                return [TextContent(
                    type="text",
                    text=json.dumps(
                        {"error": "release_id is required, or release_name with product_id/AHA_PRODUCT_ID."},
                        indent=2,
                    ),
                )]
            prog = arguments.get("progress")
            if isinstance(prog, str) and prog.strip().replace(".", "", 1).isdigit():
                prog = float(prog) if "." in prog else int(prog)
            result = await client.create_release_phase(
                name=arguments["name"],
                release_id=str(rel_id),
                phase_type=arguments["phase_type"],
                start_on=arguments.get("start_on"),
                end_on=arguments.get("end_on"),
                description=arguments.get("description"),
                progress_source=arguments.get("progress_source"),
                progress=prog,
                duration_source=arguments.get("duration_source"),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "update_release_phase":
            prog = arguments.get("progress")
            if isinstance(prog, str) and prog.strip().replace(".", "", 1).isdigit():
                prog = float(prog) if "." in prog else int(prog)
            result = await client.update_release_phase(
                arguments["id"],
                name=arguments.get("name"),
                phase_type=arguments.get("phase_type"),
                start_on=arguments.get("start_on"),
                end_on=arguments.get("end_on"),
                description=arguments.get("description"),
                progress_source=arguments.get("progress_source"),
                progress=prog,
                duration_source=arguments.get("duration_source"),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "delete_release_phase":
            await client.delete_release_phase(arguments["id"])
            return [TextContent(
                type="text",
                text=json.dumps(
                    {"ok": True, "deleted": True, "resource": "release_phase"},
                    indent=2,
                ),
            )]

        elif name == "list_initiatives":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.list_initiatives(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_initiative":
            result = await client.get_initiative(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]

        elif name == "list_custom_field_definitions":
            result = await client.list_custom_field_definitions(
                limit=arguments.get("limit", 100),
                page=arguments.get("page", 1),
                custom_fieldable_type=arguments.get("custom_fieldable_type"),
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]

        elif name == "list_custom_field_options":
            use_cache = arguments.get("use_cache", True)
            if isinstance(use_cache, str):
                use_cache = use_cache.lower() in ("true", "1", "yes")
            result = await client.list_custom_field_options(
                arguments["custom_field_definition_id"],
                use_cache=bool(use_cache),
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]

        elif name == "get_custom_layout_for_product_record":
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            if not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps(
                        {"error": "product_id is required (or set AHA_PRODUCT_ID)."},
                        indent=2,
                    )
                )]
            use_cache = arguments.get("use_cache", True)
            if isinstance(use_cache, str):
                use_cache = use_cache.lower() in ("true", "1", "yes")
            result = await client.get_custom_layout_for_product_record(
                arguments["product_id"],
                arguments.get("record_type") or "Feature",
                use_cache=bool(use_cache),
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]

        elif name == "export_product_seed_bundle":
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            if not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps(
                        {"error": "product_id is required (or set AHA_PRODUCT_ID)."},
                        indent=2,
                    )
                )]

            def _bool_arg(val: Any, default: bool = True) -> bool:
                if val is None:
                    return default
                if isinstance(val, bool):
                    return val
                if isinstance(val, str):
                    return val.lower() in ("true", "1", "yes")
                return bool(val)

            rts = arguments.get("record_types")
            if isinstance(rts, str):
                rts = [x.strip() for x in rts.split(",") if x.strip()]
            result = await client.export_product_seed_bundle(
                arguments["product_id"],
                record_types=rts,
                include_picklist_options=_bool_arg(arguments.get("include_picklist_options"), True),
                max_layout_types=int(arguments.get("max_layout_types", 12)),
                max_option_api_calls=int(arguments.get("max_option_api_calls", 48)),
                custom_definitions_max_pages=int(arguments.get("custom_definitions_max_pages", 30)),
                bypass_cache=_bool_arg(arguments.get("bypass_cache"), True),
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]

        elif name == "list_pages":
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            if not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps(
                        {"error": "product_id is required (or set AHA_PRODUCT_ID)."},
                        indent=2,
                    ),
                )]
            result = await client.list_pages(
                product_id=arguments["product_id"],
                query=arguments.get("query"),
                limit=int(arguments.get("limit", 30)),
                page=int(arguments.get("page", 1)),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "get_page":
            result = await client.get_page(arguments["id"], arguments.get("fields"))
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "create_page":
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            if not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps(
                        {"error": "product_id is required (or set AHA_PRODUCT_ID)."},
                        indent=2,
                    ),
                )]
            wf = arguments.get("workflow_status_id")
            result = await client.create_page(
                product_id=arguments["product_id"],
                name=arguments["name"],
                description=arguments.get("description"),
                document_type=arguments.get("document_type"),
                table_of_contents_enabled=arguments.get("table_of_contents_enabled"),
                parent_id=arguments.get("parent_id"),
                tags=arguments.get("tags"),
                editor_width=arguments.get("editor_width"),
                workflow_status=str(wf) if wf is not None else None,
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "update_page":
            wf = arguments.get("workflow_status_id")
            result = await client.update_page(
                arguments["id"],
                name=arguments.get("name"),
                description=arguments.get("description"),
                table_of_contents_enabled=arguments.get("table_of_contents_enabled"),
                parent_id=arguments.get("parent_id"),
                tags=arguments.get("tags"),
                editor_width=arguments.get("editor_width"),
                workflow_status=str(wf) if wf is not None else None,
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "delete_page":
            await client.delete_page(arguments["id"])
            return [TextContent(
                type="text",
                text=json.dumps({"ok": True, "deleted": True, "resource": "page"}, indent=2),
            )]

        elif name == "list_page_record_links":
            pcl = arguments.get("parent_and_child_links")
            pcl_opt: Optional[bool] = None
            if pcl is not None:
                if isinstance(pcl, str):
                    pcl_opt = pcl.lower() in ("true", "1", "yes")
                else:
                    pcl_opt = bool(pcl)
            result = await client.list_page_record_links(
                arguments["page_id"],
                parent_and_child_links=pcl_opt,
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "create_page_record_link":
            lt = arguments["link_type"]
            if isinstance(lt, str) and lt.strip().isdigit():
                lt = int(lt.strip())
            result = await client.create_page_record_link(
                arguments["page_id"],
                arguments["record_type"],
                str(arguments["record_id"]),
                int(lt),
            )
            out = result if result else {"ok": True, "linked": True, "resource": "record_link"}
            return [TextContent(type="text", text=json.dumps(out, indent=2))]

        elif name == "delete_record_link":
            await client.delete_record_link(arguments["id"])
            return [TextContent(
                type="text",
                text=json.dumps({"ok": True, "deleted": True, "resource": "record_link"}, indent=2),
            )]

        elif name == "invalidate_metadata_cache":
            await client.invalidate_metadata_cache()
            return [TextContent(
                type="text",
                text=json.dumps({"ok": True, "message": "Metadata cache cleared."}, indent=2)
            )]
        
        else:
            raise ValueError(f"Unknown tool: {name}")
    
    except Exception as e:
        error_msg = f"Error executing {name}: {str(e)}"
        return [TextContent(
            type="text",
            text=json.dumps({"error": error_msg}, indent=2)
        )]


async def main():
    """Main entry point for the MCP server."""
    async with stdio_server() as streams:
        await server.run(
            streams[0],
            streams[1],
            server.create_initialization_options()
        )


def run_mcp() -> None:
    """Run the MCP server over stdio (used by CLI and ``python -m aha_mcp``)."""
    asyncio.run(main())

