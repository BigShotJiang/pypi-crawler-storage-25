"""Unit tests for search_ideas query parameter construction."""

import unittest
from unittest.mock import AsyncMock, patch

from aha_mcp.aha_client import AhaClient


class TestSearchIdeasParams(unittest.IsolatedAsyncioTestCase):
    async def test_clamps_per_page_and_passes_sort_fields(self):
        client = AhaClient("deltek1", "test-key")
        with patch.object(AhaClient, "_request", new_callable=AsyncMock) as m:
            m.return_value = {"ideas": []}
            await client.search_ideas(
                "VP2",
                sort="popular",
                fields="name,endorsements_count",
                limit=500,
            )
        m.assert_called_once()
        args, kwargs = m.call_args
        params = kwargs["params"]
        self.assertEqual(params["per_page"], 200)
        self.assertEqual(params["sort"], "popular")
        self.assertEqual(params["fields"], "name,endorsements_count")
        self.assertIn("GET", args)
        self.assertIn("/products/VP2/ideas", args)

    async def test_unknown_sort_not_sent(self):
        client = AhaClient("x", "k")
        with patch.object(AhaClient, "_request", new_callable=AsyncMock) as m:
            m.return_value = {"ideas": []}
            await client.search_ideas("P1", sort="votes")  # type: ignore[arg-type]
        params = m.call_args.kwargs["params"]
        self.assertNotIn("sort", params)

    async def test_pass_through_filters(self):
        client = AhaClient("x", "k")
        with patch.object(AhaClient, "_request", new_callable=AsyncMock) as m:
            m.return_value = {"ideas": []}
            await client.search_ideas(
                "P1",
                query="lake",
                sort="recent",
                created_since="2024-01-01T00:00:00Z",
                created_before="2025-01-01T00:00:00Z",
                updated_since="2024-06-01T00:00:00Z",
                tag="alpha",
                user_id="42",
                idea_user_id="99",
            )
        params = m.call_args.kwargs["params"]
        self.assertEqual(params["q"], "lake")
        self.assertEqual(params["sort"], "recent")
        self.assertEqual(params["created_since"], "2024-01-01T00:00:00Z")
        self.assertEqual(params["created_before"], "2025-01-01T00:00:00Z")
        self.assertEqual(params["updated_since"], "2024-06-01T00:00:00Z")
        self.assertEqual(params["tag"], "alpha")
        self.assertEqual(params["user_id"], "42")
        self.assertEqual(params["idea_user_id"], "99")


if __name__ == "__main__":
    unittest.main()
