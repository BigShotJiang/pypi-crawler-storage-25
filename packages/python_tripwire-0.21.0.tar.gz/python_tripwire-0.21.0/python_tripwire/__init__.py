"""Deprecation shim. python-tripwire has been renamed to pytest-tripwire.

The PyPI distribution ``python-tripwire`` has been renamed to
``pytest-tripwire``. The import name ``tripwire`` is unchanged; only the
distribution name on PyPI changed. This package exists solely to redirect
``pip install python-tripwire`` users to the new distribution by declaring
``pytest-tripwire`` as a dependency.

Nothing in this module is intended to be imported. ``import python_tripwire``
will succeed but only emits a ``DeprecationWarning``.
"""

import warnings

warnings.warn(
    "python-tripwire has been renamed to pytest-tripwire. "
    "The import name `tripwire` is unchanged; only the PyPI distribution "
    "name changed. Run: "
    "`pip uninstall python-tripwire && pip install pytest-tripwire`. "
    "This compatibility shim will not receive further updates.",
    DeprecationWarning,
    stacklevel=2,
)
