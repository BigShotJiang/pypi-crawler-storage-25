# python-tripwire has been renamed to `pytest-tripwire`

This package is a **deprecation shim**. The project formerly published as
`python-tripwire` is now published as
[`pytest-tripwire`](https://pypi.org/project/pytest-tripwire/).

The new name follows the standard pytest plugin convention
(`pytest-<name>`) and reflects the project's identity as a pytest plugin.

## Migrate

```bash
pip uninstall python-tripwire
pip install pytest-tripwire
```

**Your imports do not change.** The Python import name has always been
`tripwire`:

```python
import tripwire  # unchanged
```

Only the PyPI distribution name changed. `python-tripwire` was never an
importable module name (Python disallows hyphens in import names), so no
source code edits are required.

## What this shim does

Installing `python-tripwire` now pulls in `pytest-tripwire` as a
dependency. There is no Python code to ship — `python-tripwire` was only
ever a PyPI distribution name. **This shim will not receive further
updates.** New features, bug fixes, and security patches all land in
`pytest-tripwire`.

## Naming history

This project has been renamed twice:

1. `bigfoot` (original) — also published as a deprecation shim on PyPI
2. `python-tripwire` (transitional) — this package
3. `pytest-tripwire` (current) — the canonical name going forward

If you depend on `bigfoot`, see the
[`bigfoot`](https://pypi.org/project/bigfoot/) shim package, which now
redirects to `python-tripwire` and transitively to `pytest-tripwire`.

## Links

- New project page: <https://pypi.org/project/pytest-tripwire/>
- Source repository: <https://github.com/axiomantic/pytest-tripwire>
- Issues: <https://github.com/axiomantic/pytest-tripwire/issues>
