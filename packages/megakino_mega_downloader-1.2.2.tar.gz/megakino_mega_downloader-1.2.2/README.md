# Megakino Downloader v1.0 (Remastered)

## Description
A completely rebuilt, blazing-fast, asynchronous Command Line Interface (CLI) to search, download, and watch your favorite movies and series from Megakino/VOE.

### ✨ New Features in this Version:
- **Beautiful Interactive TUI:** Built with `Rich` and `InquirerPy`. No more clunky curses/npyscreen mixing.
- **Concurrent Downloads:** Download multiple episodes at the same time using a thread pool and `yt-dlp`'s native Python API, complete with beautiful progress bars!
- **Asynchronous Scraping:** Uses `httpx` and `asyncio` for significantly faster domain checking and HTML parsing.
- **Configuration Manager:** Save your favorite download path, concurrent limits, and provider preferences persistently!
- **Robust Error Handling:** Checks for required dependencies (`mpv`, `syncplay`) before launching.

## Installation
### 🛠️ Prerequisites
Ensure you have **Python 3.8 to 3.14+** installed.

### 📦 Installation using a Virtual Environment (Recommended)
This ensures that all libraries are installed cleanly and don't interfere with your system.

#### Windows
1. Open PowerShell or CMD in the project folder:
   ```powershell
   python -m venv venv
   .\venv\Scripts\activate
   pip install .
   ```
2. Start the program:
   ```powershell
   megakino
   ```

#### macOS / Linux
1. Open your Terminal in the project folder:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install .
   ```
2. Start the program:
   ```bash
   megakino
   ```

### 🚀 Manual Dependencies
If the program detects missing tools, it will show you the exact commands for your OS.
- **Windows:** `winget install mpv`
- **macOS:** `brew install mpv syncplay`
- **Linux:** `sudo apt install mpv`

## Usage
Simply type:
```shell
megakino
```
You will be greeted by an interactive menu where you can Search for Media or modify your Settings.

## Dependencies/Credits
- **yt-dlp** for robust downloading
- **httpx** & **BeautifulSoup4** for fast, asynchronous scraping
- **Rich** & **InquirerPy** for the beautiful terminal UI
- **appdirs** for cross-platform configuration storage
- **mpv** (Needs to be installed on your system) for playing video content
- **syncplay** (Needs to be installed on your system) for syncing videos with friends

## ⚠️ Disclaimer
Provided for educational purposes only. You are solely responsible for your actions.