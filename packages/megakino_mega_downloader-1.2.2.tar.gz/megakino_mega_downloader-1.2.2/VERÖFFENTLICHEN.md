# 🚀 Veröffentlichung: Megakino Mega Downloader

Folge diesen Schritten, um dein Programm unter dem Namen **`megakino-mega-downloader`** und deinem Namen **`SoraMigurdia`** zu veröffentlichen.

## 1. Vorbereitung (Einmalig)
Erstelle ein Konto auf [PyPI.org](https://pypi.org/account/register/).
**Wichtig:** Aktiviere 2FA (Zwei-Faktor-Authentifizierung) in den Kontoeinstellungen und erstelle einen **API-Token**, um hochladen zu können.

## 2. In der Python venv bauen
Öffne dein Terminal im Projektordner:

```bash
# 1. venv aktivieren (falls noch nicht geschehen)
# Windows: .\venv\Scripts\activate
# Mac/Linux: source venv/bin/activate

# 2. Build-Tools installieren/aktualisieren
pip install --upgrade build twine

# 3. Das Paket erstellen (lösche alten 'dist' Ordner falls vorhanden)
python -m build
```

## 3. Auf PyPI hochladen
Nachdem der Befehl `build` fertig ist, hast du einen Ordner namens `dist`. Jetzt lädst du ihn hoch:

```bash
python -m twine upload dist/*
```

**Was passiert dann?**
*   Du wirst nach einem Benutzernamen gefragt. Gib `__token__` ein (exakt so).
*   Du wirst nach dem Passwort gefragt. Gib deinen **API-Token** ein (den du auf PyPI erstellt hast, er beginnt meist mit `pypi-`).

## 4. Testen
Sobald der Upload fertig ist, kann jeder (und du auch) das Programm so installieren:

```bash
pip install megakino-mega-downloader
```

Und starten mit:
*   `megakino`
*   oder `mega-downloader` (habe ich als zweiten Befehl für dich eingebaut!)
