# Megakino Downloader - Anleitung / Manual

[Deutsch](#deutsch) | [English](#english)

---

## Deutsch <a name="deutsch"></a>

### 🌟 Beschreibung
Ein moderner, schneller und asynchroner CLI-Downloader für Filme und Serien von Megakino/VOE. Unterstützt parallele Downloads, Videokomprimierung und Syncplay.

### 🛠️ Voraussetzungen
*   **Python 3.8 bis 3.14+**
*   **FFmpeg** (optional, für Videokomprimierung benötigt)
*   **mpv** (optional, zum direkten Anschauen benötigt)
*   **Syncplay** (optional, für gemeinsames Schauen benötigt)

### 📦 Installation

Du hast zwei Möglichkeiten, das Programm zu installieren:

#### Möglichkeit A: Über PyPI (Am einfachsten)
Wenn das Programm offiziell veröffentlicht ist, kannst du es direkt mit einem Befehl installieren. Probiere diese Befehle nacheinander, falls einer nicht geht:
1.  `pip install megakino-mega-downloader`
2.  `pip3 install megakino-mega-downloader`
3.  `python3 -m pip install megakino-mega-downloader`
4.  `python -m pip install megakino-mega-downloader`

#### Möglichkeit B: Von GitHub / Lokal (Entwickler-Version)
Wenn du den Quellcode heruntergeladen hast:

1.  **Projekt-Ordner öffnen:** Navigiere im Terminal/PowerShell in den Ordner.
2.  **Virtuelle Umgebung erstellen:**
    *   Windows: `python -m venv venv` oder `py -m venv venv`
    *   macOS / Linux: `python3 -m venv venv` oder `python -m venv venv`
3.  **Umgebung aktivieren:**
    *   Windows: `.\venv\Scripts\activate`
    *   macOS / Linux: `source venv/bin/activate`
4.  **Lokal installieren:**
    Probiere diese Befehle, falls `pip` nicht geht:
    *   `pip install .`
    *   `pip3 install .`
    *   `python -m pip install .`

---

### 🚀 Starten
Nach der Installation kannst du das Programm mit einem dieser Befehle starten:
*   `megakino`
*   `mega-downloader`

---

### 🛠️ Für Entwickler: Programm bauen & hochladen
Falls du das Programm selbst auf PyPI hochladen möchtest:
1.  `pip install build twine` (oder `python3 -m pip install build twine`)
2.  `python3 -m build` (oder `python -m build`)
3.  `python3 -m twine upload dist/*` (oder `python -m twine upload dist/*`)

### ⚙️ Einstellungen
Im Hauptmenü findest du den Punkt **"Settings"**. Hier kannst du:
*   Den **Download-Pfad** ändern.
*   Die Anzahl der **gleichzeitigen Downloads** festlegen.
*   **Videokomprimierung** (Slow/Medium/Fast) aktivieren.
*   **Animationen** für das Interface ein-/ausschalten.

---

## English <a name="english"></a>

### 🌟 Description
A modern, fast, and asynchronous CLI downloader for movies and series from Megakino/VOE. Supports concurrent downloads, video compression, and Syncplay.

### 🛠️ Prerequisites
*   **Python 3.8 to 3.14+**
*   **FFmpeg** (optional, required for video compression)
*   **mpv** (optional, required for direct watching)
*   **Syncplay** (optional, required for watching with friends)

### 📦 Installation

You have two ways to install the program:

#### Method A: Via PyPI (Easiest)
If the program is published, you can install it directly. Try these commands in order if one doesn't work:
1.  `pip install megakino-mega-downloader`
2.  `pip3 install megakino-mega-downloader`
3.  `python3 -m pip install megakino-mega-downloader`
4.  `python -m pip install megakino-mega-downloader`

#### Method B: From GitHub / Local (Development Version)
If you downloaded the source code:

1.  **Open Project Folder:** Navigate in your Terminal/PowerShell to the folder.
2.  **Create virtual environment:**
    *   Windows: `python -m venv venv` or `py -m venv venv`
    *   macOS / Linux: `python3 -m venv venv` or `python -m venv venv`
3.  **Activate environment:**
    *   Windows: `.\venv\Scripts\activate`
    *   macOS / Linux: `source venv/bin/activate`
4.  **Install locally:**
    Try these commands if `pip` fails:
    *   `pip install .`
    *   `pip3 install .`
    *   `python -m pip install .`

---

### 🚀 Usage
Once installed, you can start the program with these commands:
*   `megakino`
*   `mega-downloader`

---

### 🛠️ For Developers: Build & Upload
If you want to upload the program to PyPI yourself:
1.  `pip install build twine` (or `python3 -m pip install build twine`)
2.  `python3 -m build` (or `python -m build`)
3.  `python3 -m twine upload dist/*` (or `python -m twine upload dist/*`)

### ⚙️ Settings
In the main menu, go to **"Settings"** to:
*   Change the **Download Path**.
*   Set the number of **concurrent downloads**.
*   Enable **Video Compression** (Slow/Medium/Fast).
*   Toggle **UI Animations**.
