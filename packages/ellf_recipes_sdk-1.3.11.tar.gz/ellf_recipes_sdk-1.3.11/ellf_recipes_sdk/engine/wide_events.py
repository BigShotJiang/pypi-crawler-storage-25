"""Wide event instrumentation for Prodigy recipe servers.

Adds request-level wide event middleware to the Prodigy ASGI app and
starts a background writer that persists events to the same PostgreSQL
database used by the cluster (``cluster_wide_event`` table).
"""

from __future__ import annotations

import contextvars
import json
import logging
import os
import queue
import threading
import time
import traceback as _tb_mod
from types import TracebackType
from typing import Any, Callable

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Per-request event accumulator (same API as pam/cluster wide_events.py)
# ---------------------------------------------------------------------------

_current_event: contextvars.ContextVar[dict[str, Any] | None] = contextvars.ContextVar(
    "wide_event", default=None
)


def init_event() -> dict[str, Any]:
    event: dict[str, Any] = {"_start_ns": time.monotonic_ns()}
    _current_event.set(event)
    return event


def add_event_context(**kwargs: Any) -> None:
    event = _current_event.get(None)
    if event is not None:
        event.update(kwargs)


def finish_event() -> dict[str, Any] | None:
    event = _current_event.get(None)
    if event is None:
        return None
    start_ns = event.pop("_start_ns", None)
    if start_ns is not None:
        event["duration_ms"] = round((time.monotonic_ns() - start_ns) / 1_000_000, 2)
    _current_event.set(None)
    return event


# ---------------------------------------------------------------------------
# Background writer
# ---------------------------------------------------------------------------

_event_queue: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=10_000)


def enqueue_event(event: dict[str, Any]) -> None:
    try:
        _event_queue.put_nowait(event)
    except queue.Full:
        logger.warning("Wide event queue full — dropping event")


def _build_session_factory() -> Callable | None:
    """Build a SQLAlchemy session factory from the Prodigy DB config.

    Returns None if the database is not PostgreSQL (e.g. SQLite in tests).
    """
    overrides = os.environ.get("PRODIGY_CONFIG_OVERRIDES", "")
    if not overrides:
        return None
    try:
        config = json.loads(overrides)
    except (json.JSONDecodeError, TypeError):
        return None
    if config.get("db") != "postgresql":
        return None
    pg = config.get("db_settings", {}).get("postgresql", {})
    host = pg.get("host", "")
    port = pg.get("port", 5432)
    user = pg.get("user", "")
    password = pg.get("password", "")
    dbname = pg.get("dbname", "")
    if not host or not dbname:
        return None
    uri = f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{dbname}"

    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    engine = create_engine(uri, pool_pre_ping=True, pool_size=2)

    # Ensure the cluster_wide_event table exists.
    from .._vendor.wide_event_model import ensure_tables

    ensure_tables(engine)

    maker = sessionmaker(bind=engine, autoflush=False)
    return maker


def _start_writer(session_factory: Callable) -> None:
    t = threading.Thread(
        target=_writer_loop,
        args=(session_factory,),
        daemon=True,
        name="wide-event-writer",
    )
    t.start()


def _writer_loop(session_factory: Callable) -> None:
    from .._vendor.wide_event_model import WideEvent

    job_id = os.environ.get("ELLF_JOB_ID")
    execution_id = os.environ.get("ELLF_EXECUTION_ID")

    while True:
        batch: list[dict[str, Any]] = []
        batch.append(_event_queue.get())
        while len(batch) < 100:
            try:
                batch.append(_event_queue.get_nowait())
            except queue.Empty:
                break
        try:
            session = session_factory()
            try:
                for event in batch:
                    event["job_id"] = job_id
                    event["execution_id"] = execution_id
                    event["event_type"] = "recipe_request"
                    session.add(
                        WideEvent(
                            event_type="recipe_request",
                            request_id=event.get("request_id"),
                            method=event.get("method"),
                            path=event.get("path"),
                            status_code=event.get("status_code"),
                            duration_ms=event.get("duration_ms"),
                            user_id=event.get("user_id"),
                            org_id=event.get("org_id"),
                            traceback=event.get("traceback"),
                            payload=event,
                        )
                    )
                session.commit()
            except Exception:
                session.rollback()
                raise
            finally:
                session.close()
        except Exception:
            logger.exception(
                "Failed to write wide events batch (%d events)", len(batch)
            )


# ---------------------------------------------------------------------------
# ASGI middleware (identical to PAM/cluster pattern)
# ---------------------------------------------------------------------------


class WideEventMiddleware:
    """ASGI middleware that emits one wide event per HTTP request."""

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")
        if path in ("/health", "/healthz", "/healthcheck"):
            await self.app(scope, receive, send)
            return

        init_event()
        add_event_context(
            method=scope.get("method", ""),
            path=scope.get("path", ""),
        )

        status_code = 500

        async def capture_status(message: dict) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message.get("status", 500)
            await send(message)

        try:
            await self.app(scope, receive, capture_status)
        except Exception:
            import sys
            import traceback

            exc_type, exc_value, exc_tb = sys.exc_info()
            raw = traceback.format_exc()
            pruned = _prune_traceback(exc_type, exc_value, exc_tb)
            add_event_context(
                status_code=500,
                error=True,
                traceback=pruned,
                raw_traceback=raw,
            )
            raise
        finally:
            add_event_context(status_code=status_code)
            finished = finish_event()
            if finished is not None:
                enqueue_event(finished)
                tb = finished.get("traceback")
                if tb:
                    _report_traceback_to_cluster(finished, tb)


_FRAMEWORK_MODULES = (
    "starlette",
    "anyio",
    "asyncio",
    "uvicorn",
    "fastapi",
    "fastapi_explosion_extras",
    "prodigy/app",
)


def _is_framework_frame(filename: str) -> bool:
    normalized = filename.replace("\\", "/")
    return any(f"/{mod}/" in normalized for mod in _FRAMEWORK_MODULES)


def _prune_traceback(
    exc_type: type[BaseException] | None,
    exc_value: BaseException | None,
    exc_tb: TracebackType | None,
) -> str:
    """Format a traceback with framework-internal frames removed."""
    if exc_tb is None or exc_type is None:
        return _tb_mod.format_exc()
    frames = _tb_mod.extract_tb(exc_tb)
    kept = [f for f in frames if not _is_framework_frame(f.filename)]
    if not kept:
        kept = frames[-1:]
    parts = ["Traceback (most recent call last):\n"]
    parts.extend(_tb_mod.format_list(kept))
    parts.extend(_tb_mod.format_exception_only(exc_type, exc_value))
    return "".join(parts)


def _report_traceback_to_cluster(event: dict[str, Any], tb: str) -> None:
    """POST the traceback to the cluster so it surfaces in the SSE stream."""
    broker_host = os.environ.get("ELLF_BROKER_HOST", "")
    broker_token = os.environ.get("ELLF_BROKER_BOOTSTRAP_TOKEN", "")
    job_id = os.environ.get("ELLF_JOB_ID", "")
    if not broker_host or not broker_token or not job_id:
        return
    import httpx

    url = f"{broker_host}/api/v1/jobs/{job_id}/report-traceback"
    try:
        httpx.post(
            url,
            json={
                "method": event.get("method"),
                "path": event.get("path"),
                "status_code": event.get("status_code"),
                "traceback": tb,
            },
            headers={"Authorization": f"Bearer {broker_token}"},
            timeout=5,
        )
    except Exception:
        logger.debug("Failed to report traceback to cluster", exc_info=True)


# ---------------------------------------------------------------------------
# Public setup function (called from cli.py before server start)
# ---------------------------------------------------------------------------


def register_wide_events() -> None:
    """Add wide event middleware to the Prodigy app and start the writer."""
    session_factory = _build_session_factory()
    if session_factory is None:
        logger.info("Wide events disabled (no PostgreSQL config)")
        return

    from prodigy.app import app as prodigy_app

    # Wrap the Prodigy ASGI app with our middleware.
    prodigy_app.add_middleware(WideEventMiddleware)
    _start_writer(session_factory)
    logger.info("Wide events enabled for recipe server")
