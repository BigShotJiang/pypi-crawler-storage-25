from pathlib import Path
from typing import Any, Iterable, List, Optional, Type

import srsly
from prodigy.components.db import connect
from prodigy.components.loaders import get_stream
from prodigy.structured_types import Example as StructuredExample
from prodigy.types import StreamType, TaskType
from prodigy.util import set_hashes

from .. import Props
from ..types import Dataset
from .decorator import teams_type

teams_type(
    "dataset",
    title="Dataset",
    description="Select an existing dataset or create a new one",
    exclude={"id", "name", "kind", "cluster_id"},
)(Dataset)


@teams_type(
    "input-dataset",
    # fmt: off
    props=Props(
        title="Existing dataset", description="Select an existing dataset", exists=True
    ),
    # fmt: on
)
class InputDataset(Dataset):
    """Custom type for a Prodigy data set used as an input source."""

    # fmt: off
    def load(self, **kwargs: Any) -> StreamType:  # pyright: ignore[reportIncompatibleMethodOverride]
        # fmt: on
        """Load examples from the dataset. Reads from the structured table
        and returns structured dicts (via to_dict) so downstream
        ensure_structured can reconstruct Examples losslessly."""
        db = connect()
        dataset_meta = db.get_dataset_by_name(self.name)
        if dataset_meta.structured:
            return iter(
                eg.to_dict()
                for eg in db.iter_st_dataset_examples(dataset_name=self.name)
            )
        return get_stream(f"dataset:{self.name}", loader="dataset", **kwargs)

    def export(self, path: Path) -> None:
        examples = self.load()
        srsly.write_jsonl(path, examples)


def save_examples(
    dataset_name: str,
    examples: Iterable[TaskType],
    *,
    session_id: str = "default",
    parse_as: Optional[Type[StructuredExample]] = None,
    input_keys: Optional[List[str]] = None,
    server_ann_keys: Optional[List[str]] = None,
    user_ann_keys: Optional[List[str]] = None,
) -> None:
    """Save unstructured example dicts to the structured table.

    Converts each dict to a structured Example via from_unst_user(),
    then writes via db.add_st_examples(). Creates the dataset if needed.

    When using the base Example class (no parse_as), input_keys is required.
    user_ann_keys defaults to [] (no user annotations) if not provided.

    dataset_name (str): Name of the dataset to save to.
    examples (Iterable[TaskType]): Unstructured example dicts to save.
    session_id (str): Session ID for the structured link. Defaults to "default".
    parse_as (Optional[Type[StructuredExample]]): Structured Example type to parse as.
    input_keys (Optional[List[str]]): Keys to parse into `input`.
    server_ann_keys (Optional[List[str]]): Keys to parse into `server_anns`.
    user_ann_keys (Optional[List[str]]): Keys to parse into `user_anns`. Defaults to [].
    """
    if user_ann_keys is None:
        user_ann_keys = []
    db = connect()
    db.add_dataset(dataset_name, structured=True)
    parse_as = parse_as or StructuredExample
    st_examples: List[StructuredExample] = []
    for eg in examples:
        if "__class__" in eg:
            # Already a structured dict, reconstruct losslessly
            st_eg = parse_as.from_dict(eg, db=db)
        else:
            eg = set_hashes(eg)
            st_eg = parse_as.from_unst_user(
                eg,
                input_keys=input_keys,
                server_ann_keys=server_ann_keys,
                user_ann_keys=user_ann_keys,
                db=db,
            )
        st_examples.append(st_eg)
    db.add_st_examples(st_examples, dataset_name=dataset_name, session_id=session_id)


__all__ = ["InputDataset", "Dataset"]
