"""Async HTTP client for the Prodigy REST API."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import anyio
import httpx

from ellf_pam_sdk.url import URL

logger = logging.getLogger(__name__)

MAX_RETRIES = 5


@dataclass(frozen=True)
class ServerAuth:
    base_url: str
    login_url: str | None = None
    # In-cluster auth fields. When all three are set, ``authenticate()``
    # bypasses Prodigy's OIDC redirect chain (which redirects through
    # ``cfg.broker_host`` — browser-facing and unreachable from inside a
    # pod on BYOC where it's e.g. ``https://localhost:8443``) and instead
    # fetches an auth code straight from the broker via its in-cluster
    # Service URL, then delivers it to Prodigy's ``/login/callback``.
    broker_authorize_url: str | None = None
    login_token: str | None = None
    client_id: str | None = None


class ProdigyClient:
    """Async wrapper around a Prodigy annotation server."""

    def __init__(self, server: ServerAuth, session: str):
        self.base_url = str(URL.parse(server.base_url))
        self.login_url = server.login_url
        self.broker_authorize_url = server.broker_authorize_url
        self.login_token = server.login_token
        self.client_id = server.client_id
        self.session = session
        self.http = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=30,
            follow_redirects=True,
        )

    async def aclose(self) -> None:
        await self.http.aclose()

    async def __aenter__(self) -> ProdigyClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def authenticate(self) -> None:
        """Establish cookies for OIDC-protected task servers when needed."""
        if self.login_url is None:
            return
        if (
            self.broker_authorize_url is not None
            and self.login_token is not None
            and self.client_id is not None
        ):
            await self._authenticate_in_cluster()
            return
        resp = await self.http.get(self.login_url)
        resp.raise_for_status()

    async def _authenticate_in_cluster(self) -> None:
        """Auth bypass for in-cluster agents.

        Prodigy's ``/login`` redirects to ``cfg.broker_host``'s
        ``/oidc/authorize``, which on BYOC is the browser-facing URL
        (e.g. ``https://localhost:8443``) — unreachable from inside a
        pod. So we skip Prodigy's redirect entirely:

        1. ``GET broker_authorize_url`` (in-cluster) with ``login_token``
           → broker mints a one-time auth code, redirects to the
           ``redirect_uri`` we hand it.
        2. ``GET`` that redirect (also in-cluster, because the redirect_uri
           we pass is the in-cluster Prodigy ``/login/callback``) → Prodigy
           exchanges the code for a session cookie on the shared httpx
           client.  Subsequent requests carry the cookie.
        """
        assert self.broker_authorize_url is not None
        assert self.login_token is not None
        assert self.client_id is not None
        callback_url = str(URL.parse(self.base_url) / "login/callback")
        auth_resp = await self.http.get(
            self.broker_authorize_url,
            params={
                "response_type": "code",
                "client_id": self.client_id,
                "redirect_uri": callback_url,
                "scope": "openid profile email",
                "state": "agent",
                "login_token": self.login_token,
            },
            follow_redirects=False,
        )
        if auth_resp.status_code not in (302, 303, 307):
            auth_resp.raise_for_status()
            raise RuntimeError(
                f"unexpected status {auth_resp.status_code} from broker /oidc/authorize"
            )
        # The broker's Location is `redirect_uri` (callback_url, in-cluster)
        # plus `?code=...&state=...`. Follow it directly so the session
        # cookie binds to the in-cluster host that subsequent requests use.
        location = auth_resp.headers["location"]
        cb_resp = await self.http.get(location)
        cb_resp.raise_for_status()

    async def get_config(self) -> dict[str, Any]:
        """Fetch the project config from the Prodigy server."""
        resp = await self.http.get("/project")
        resp.raise_for_status()
        return resp.json()

    async def get_tasks(self) -> tuple[list[dict[str, Any]], float]:
        """Fetch the next batch of tasks. Returns (tasks, progress)."""
        payload: dict[str, Any] = {}
        if self.login_url is None:
            payload["session_id"] = self.session
        resp = await self.http.post(
            "/get_session_questions",
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
        progress = data.get("progress")
        return data["tasks"], progress if progress is not None else 0.0

    async def submit_answers(self, answers: list[dict[str, Any]]) -> float:
        """Submit annotated answers with retry logic. Returns progress."""
        payload: dict[str, Any] = {"answers": answers}
        if self.login_url is None:
            payload["session_id"] = self.session
        annotator_id = _shared_annotator_id(answers)
        if annotator_id is not None:
            payload["annotator_id"] = annotator_id
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                resp = await self.http.post(
                    "/give_answers",
                    json=payload,
                )
                resp.raise_for_status()
                progress = resp.json().get("progress")
                return progress if progress is not None else 0.0
            except httpx.HTTPError:
                logger.warning(
                    "Submit attempt %d/%d failed",
                    attempt,
                    MAX_RETRIES,
                    exc_info=True,
                )
                await anyio.sleep(attempt)
        logger.error("Submit failed after %d retries — dropping batch.", MAX_RETRIES)
        return 0.0


def _shared_annotator_id(answers: list[dict[str, Any]]) -> str | None:
    annotator_ids = {
        annotator_id
        for answer in answers
        if isinstance((annotator_id := answer.get("_annotator_id")), str)
        and annotator_id
    }
    if len(annotator_ids) == 1:
        return next(iter(annotator_ids))
    return None
