"""Server discovery: find Prodigy servers for tasks assigned to this agent.

The agent doesn't receive task URLs directly. Instead it queries PAM
for its related tasks and resolves each task's Prodigy server URL.

Task URLs follow the path-based convention:
  ``https://{broker_address}/tasks/{task_id}``
"""

from __future__ import annotations

import logging
from typing import Any, cast
from uuid import UUID

import httpx

from ellf_pam_sdk.client.full_client import Client
from ellf_pam_sdk.models import AgentDetail
from ellf_pam_sdk.recipe_client import Settings
from ellf_pam_sdk.url import URL

from .client import ServerAuth

logger = logging.getLogger(__name__)


async def discover_servers() -> list[ServerAuth]:
    """Query PAM for tasks assigned to this agent and return their server URLs."""
    settings = Settings()
    if not settings.is_valid():
        missing = [
            name
            for name, value in {
                "ELLF_PAM_BOOTSTRAP_TOKEN": settings.pam_bootstrap_token,
                "ELLF_PAM_HOST": settings.pam_host,
                "ELLF_JOB_ID": settings.job_id,
                "ELLF_EXECUTION_ID": settings.execution_id,
                "ELLF_CLUSTER_ID": settings.cluster_id,
            }.items()
            if not value
        ]
        raise RuntimeError(
            f"Missing ELLF_* environment variables: {', '.join(missing)} "
            "— is this running on the cluster?"
        )
    pam = await Client.from_job_token(settings.pam_host, settings.job_token)
    agent = cast(AgentDetail, await pam.agent.read_async(id=settings.job_id))
    task_ids: list[UUID] = agent.related_tasks
    if not task_ids:
        logger.info("Agent has no related tasks.")
        return []
    cluster = await pam.cluster.read_async(id=settings.cluster_id)
    if settings.has_cluster_auth():
        broker_token = await _exchange_cluster_bootstrap_token(
            broker_host=settings.broker_host,
            cluster_bootstrap_token=settings.cluster_bootstrap_token,
        )
    else:
        broker_token = await _get_cluster_token(
            pam_host=settings.pam_host,
            broker_address=cluster.address,
            pam_access_token=pam.access_token,
        )
    # Server-to-server traffic stays in-cluster (see docs/auth-architecture.md).
    # When has_cluster_auth() is True we are inside the cluster and must call
    # the broker via the in-cluster service URL; cluster.address is the
    # browser-facing URL (e.g. localhost:8443 over an SSH tunnel on BYOC) and
    # is generally not resolvable from inside a pod.
    in_cluster = settings.has_cluster_auth()
    broker_call_address = settings.broker_host if in_cluster else cluster.address
    urls: list[ServerAuth] = []
    for task_id in task_ids:
        try:
            payload = await _fetch_prodigy_login(
                broker_address=broker_call_address,
                broker_token=broker_token,
                task_id=task_id,
            )
        except httpx.ReadTimeout:
            logger.warning(
                "Skipping task %s for agent discovery: cluster prodigy-login timed out",
                task_id,
            )
            continue
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in {404, 503}:
                logger.warning(
                    "Skipping task %s for agent discovery: cluster prodigy-login returned %s",
                    task_id,
                    exc.response.status_code,
                )
                continue
            raise
        # Same in-cluster vs. external split for the task pod itself: in-cluster
        # agents should connect via the K8s Service URL (task_internal_url) so
        # they don't hairpin out through the public ingress, which on BYOC /
        # SSH-tunnel deployments isn't reachable from inside the cluster.
        # External callers (and older brokers that don't return the field)
        # use task_url.
        external_raw = payload.get("task_url") or ""
        internal_raw = payload.get("task_internal_url") or ""
        using_internal = in_cluster and bool(internal_raw)
        chosen_raw = internal_raw if using_internal else external_raw
        task_base = URL.parse(chosen_raw)
        login_token_value = str(payload["login_token"])
        # When we're using the in-cluster task URL, we ALSO need the agent's
        # login flow to stay in-cluster — Prodigy's /login redirects via
        # cfg.broker_host, which on BYOC is unreachable from a pod. Pass
        # the broker's in-cluster /oidc/authorize URL plus the login token
        # so ProdigyClient.authenticate can short-circuit the redirect
        # chain. See ProdigyClient._authenticate_in_cluster.
        if using_internal:
            broker_authorize_url: str | None = str(
                URL.parse(settings.broker_host) / "api/v1/oidc/authorize"
            )
            login_token_for_auth: str | None = login_token_value
            client_id_for_auth: str | None = str(task_id)
        else:
            broker_authorize_url = None
            login_token_for_auth = None
            client_id_for_auth = None
        urls.append(
            ServerAuth(
                base_url=str(task_base),
                login_url=str(
                    (task_base / "login").with_query(login_token=login_token_value)
                ),
                broker_authorize_url=broker_authorize_url,
                login_token=login_token_for_auth,
                client_id=client_id_for_auth,
            )
        )
    return urls


async def _get_cluster_token(
    *,
    pam_host: str,
    broker_address: str,
    pam_access_token: str,
) -> str:
    async with httpx.AsyncClient(timeout=30.0) as http:
        response = await http.post(
            f"{URL.parse(pam_host)}/api/v1/cluster/token",
            headers={"Authorization": f"Bearer {pam_access_token}"},
            json={"address": URL.parse(broker_address)},
        )
        response.raise_for_status()
        pam_cluster_token = response.json()["access_token"]
        exchange = await http.post(
            f"{URL.parse(broker_address)}/api/v1/token/exchange",
            json={"token": pam_cluster_token},
        )
        exchange.raise_for_status()
        return exchange.json()["access_token"]


async def _exchange_cluster_bootstrap_token(
    *,
    broker_host: str,
    cluster_bootstrap_token: str,
) -> str:
    # broker_host may already include a scheme (e.g. the in-cluster
    # http://ellf-broker.ellf:8080).
    base = URL.parse(broker_host)
    async with httpx.AsyncClient(timeout=30.0) as http:
        exchange = await http.post(
            f"{base}/api/v1/token/exchange",
            json={"token": cluster_bootstrap_token},
        )
        exchange.raise_for_status()
        return exchange.json()["access_token"]


async def _fetch_prodigy_login(
    *,
    broker_address: str,
    broker_token: str,
    task_id: UUID,
) -> dict[str, Any]:
    """Fetch the broker's prodigy-login payload for a task.

    Returns the raw dict (``login_token`` plus ``task_url`` and
    ``task_internal_url``). The caller picks which task URL to use based
    on whether it's running in-cluster — see :func:`discover_servers`.
    Always passes ``wait_for_route=false`` because the broker has already
    waited for route readiness before announcing the task to the agent.
    """
    async with httpx.AsyncClient(timeout=30.0) as http:
        response = await http.get(
            f"{URL.parse(broker_address)}/api/v1/jobs/prodigy-login",
            headers={"Authorization": f"Bearer {broker_token}"},
            params={"task_id": str(task_id), "wait_for_route": "false"},
        )
        response.raise_for_status()
        return response.json()
