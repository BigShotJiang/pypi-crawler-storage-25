"""Core event loop for the annotation agent.

Top-level flow:
  1. Discover Prodigy servers for tasks assigned to this agent.
  2. Fan out: poll each server concurrently (staggered start).
  3. Each server loop: fetch tasks, annotate via LLM, submit answers.
"""

from __future__ import annotations

import inspect
import logging
import time
from collections.abc import Awaitable, Callable
from typing import Any

import anyio
import httpx

from .client import ProdigyClient, ServerAuth
from .discovery import discover_servers

logger = logging.getLogger(__name__)

MAX_CONNECT_RETRIES = 6
STARTUP_RETRY_BASE_SECONDS = 2.0
RETRYABLE_STARTUP_STATUS_CODES = frozenset({404, 502, 503, 504})
Annotator = Callable[
    [dict[str, Any], dict[str, Any]],
    dict[str, Any] | Awaitable[dict[str, Any]],
]


async def run_annotator(
    annotate_task: Annotator,
    poll_interval: float,
    session: str,
    idle_shutdown_seconds: float | None = None,
) -> None:
    """Discover servers and drive one annotator across all task servers."""
    active_servers: set[str] = set()
    logged_waiting = False
    idle_since = time.monotonic()

    async def run_server(server: ServerAuth) -> None:
        try:
            await poll_server(
                server,
                session,
                annotate_task,
                poll_interval,
                idle_shutdown_seconds=idle_shutdown_seconds,
            )
        finally:
            active_servers.discard(server.base_url)

    async with anyio.create_task_group() as tg:
        while True:
            servers = await discover_servers()
            if not servers and not active_servers and not logged_waiting:
                logger.info("No servers discovered — waiting for assignments.")
                logged_waiting = True
            if (
                not servers
                and not active_servers
                and _idle_shutdown_elapsed(idle_since, idle_shutdown_seconds)
            ):
                logger.info(
                    "No assignments discovered for %.1f seconds — shutting down.",
                    idle_shutdown_seconds,
                )
                return
            for server in servers:
                if server.base_url in active_servers:
                    continue
                logged_waiting = False
                idle_since = time.monotonic()
                active_servers.add(server.base_url)
                logger.info("Discovered server %s", server.base_url)
                tg.start_soon(run_server, server)
                await anyio.sleep(poll_interval)
            await anyio.sleep(poll_interval)


async def poll_server(
    server: ServerAuth,
    session: str,
    annotate_task: Annotator,
    poll_interval: float,
    idle_shutdown_seconds: float | None = None,
) -> None:
    """Fetch-annotate-submit loop for one Prodigy server."""
    async with ProdigyClient(server, session) as client:
        url = server.base_url
        # The task server may still be starting up; retry on connection errors.
        config = None
        for attempt in range(1, MAX_CONNECT_RETRIES + 1):
            try:
                await client.authenticate()
                config = await client.get_config()
                break
            except httpx.HTTPError as exc:
                if not _is_retryable_startup_error(exc):
                    raise
                logger.warning(
                    "[%s] Startup probe failed (attempt %d/%d), retrying…",
                    url,
                    attempt,
                    MAX_CONNECT_RETRIES,
                    exc_info=True,
                )
                await anyio.sleep(_startup_retry_delay_seconds(poll_interval, attempt))
        if config is None:
            logger.error(
                "[%s] Could not connect after %d attempts, giving up.",
                url,
                MAX_CONNECT_RETRIES,
            )
            return
        total = 0
        idle_since = time.monotonic()
        while True:
            try:
                tasks, progress = await client.get_tasks()
            except httpx.HTTPError:
                logger.warning("[%s] Fetch failed, retrying…", url, exc_info=True)
                await anyio.sleep(poll_interval * 2)
                continue
            if not tasks:
                if _idle_shutdown_elapsed(idle_since, idle_shutdown_seconds):
                    logger.info(
                        "[%s] Idle for %.1f seconds — shutting down.",
                        url,
                        idle_shutdown_seconds,
                    )
                    return
                await anyio.sleep(poll_interval)
                continue
            idle_since = time.monotonic()
            answers = [
                await call_annotator(annotate_task, task, config) for task in tasks
            ]
            progress = await client.submit_answers(answers)
            idle_since = time.monotonic()
            total += len(answers)
            logger.info(
                "[%s] Submitted %d answers (total %d, %.0f%%)",
                url,
                len(answers),
                total,
                progress * 100,
            )
            if progress >= 1.0:
                break
            await anyio.sleep(poll_interval)
        logger.info("[%s] Done. %d annotations.", url, total)


def _idle_shutdown_elapsed(
    idle_since: float, idle_shutdown_seconds: float | None
) -> bool:
    return idle_shutdown_seconds is not None and (
        time.monotonic() - idle_since >= idle_shutdown_seconds
    )


def _is_retryable_startup_error(exc: httpx.HTTPError) -> bool:
    if isinstance(exc, httpx.ConnectError):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in RETRYABLE_STARTUP_STATUS_CODES
    return False


def _startup_retry_delay_seconds(poll_interval: float, attempt: int) -> float:
    return max(STARTUP_RETRY_BASE_SECONDS, poll_interval) * attempt


async def call_annotator(
    annotate_task: Annotator,
    task: dict[str, Any],
    config: dict[str, Any],
) -> dict[str, Any]:
    answer = annotate_task(task, config)
    if inspect.isawaitable(answer):
        return await answer
    return answer
