"""
RunPod SDK compatibility layer for gmi_ieops.

Usage:
    from gmi_ieops import runpod
    runpod.serverless.start({"handler": my_handler})

    from gmi_ieops.runpod.serverless.utils import rp_upload
    rp_upload.upload_image(job_id, file_path)

This module provides a drop-in replacement for the `runpod` package.
Users only need to change their import statement:

    - import runpod
    + from gmi_ieops import runpod

All RunPod SDK serverless APIs are preserved. Additionally, a lightweight
HTTP health server (GET /health on port 8080) is automatically started
when the worker runs, enabling K8s liveness/readiness probes for
queue-based workers that otherwise have no HTTP endpoint.
"""

from . import serverless
from .serverless.modules.rp_logger import RunPodLogger
