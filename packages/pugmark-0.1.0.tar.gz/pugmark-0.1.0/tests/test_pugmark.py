"""
Comprehensive tests for the pugmark Python SDK.

Tests cover Object, Reader, Writer classes and module-level functions,
including HTTP communication, data encoding/decoding, compression, and error handling.
"""

import base64
import gzip
import io
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from unittest.mock import Mock, patch

import pytest

import pugmark
from pugmark import Input, Output, Reader, Writer
from pugmark.http import SESSION_METADATA_HEADER, WSGIPugmark


def mock_session_state():
    """Helper function to create properly mocked session state and urlopen."""
    from contextlib import contextmanager

    @contextmanager
    def _mock_context():
        with patch("pugmark._default_session.state") as mock_state:
            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=False)
            mock_state_instance.get_memory_url = Mock(return_value="http://example.com/test")
            mock_state.return_value = mock_state_instance

            with patch("urllib.request.urlopen") as mock_urlopen:
                mock_response = Mock()
                mock_response.read = Mock(return_value=b"")
                mock_urlopen.return_value.__enter__ = Mock(return_value=mock_response)
                mock_urlopen.return_value.__exit__ = Mock(return_value=None)
                yield mock_state, mock_urlopen

    return _mock_context()


class TestReader:
    """Test the Reader class for input stream processing."""

    def test_reader_initialization(self):
        """Test Reader initialization."""
        stream = io.StringIO()
        reader = Reader(stream)
        assert reader.stream == stream

    def test_read_empty_stream(self):
        """Test reading from empty stream."""
        stream = io.StringIO("")
        reader = Reader(stream)
        objects = list(reader.read())
        assert objects == []

    def test_read_single_object(self):
        """Test reading a single object from stream."""
        input_data = {
            "url": "http://example.com/test.txt",
            "size": 100,
            "content-type": "text/plain",
            "content-encoding": "",
            "metadata": {"name": "test.txt"},
        }
        stream = io.StringIO(json.dumps(input_data) + "\n")
        reader = Reader(stream)

        objects = list(reader.read())
        assert len(objects) == 1

        obj = objects[0]
        assert obj._input.url == "http://example.com/test.txt"
        assert obj.content_type() == "text/plain"
        assert obj.metadata() == {"name": "test.txt"}

    def test_read_multiple_objects(self):
        """Test reading multiple objects from stream."""
        inputs = [
            {
                "url": "http://example.com/test1.txt",
                "size": 100,
                "content-type": "text/plain",
                "metadata": {"name": "test1.txt"},
            },
            {
                "url": "http://example.com/test2.json",
                "size": 200,
                "content-type": "application/json",
                "metadata": {"name": "test2.json"},
            },
        ]

        stream_content = "\n".join(json.dumps(inp) for inp in inputs) + "\n"
        stream = io.StringIO(stream_content)
        reader = Reader(stream)

        objects = list(reader.read())
        assert len(objects) == 2

        assert objects[0]._input.url == "http://example.com/test1.txt"
        assert objects[0].content_type() == "text/plain"
        assert objects[1]._input.url == "http://example.com/test2.json"
        assert objects[1].content_type() == "application/json"

    def test_read_with_empty_lines(self):
        """Test reading stream with empty lines."""
        input_data = {"url": "http://example.com/test.txt", "size": 100}
        stream_content = f"\n\n{json.dumps(input_data)}\n\n"
        stream = io.StringIO(stream_content)
        reader = Reader(stream)

        objects = list(reader.read())
        assert len(objects) == 1
        assert objects[0]._input.url == "http://example.com/test.txt"

    def test_read_invalid_json(self):
        """Test reading stream with invalid JSON."""
        stream = io.StringIO("invalid json\n")
        reader = Reader(stream)

        with pytest.raises(RuntimeError, match="Failed to decode input record"):
            list(reader.read())

    def test_read_missing_optional_fields(self):
        """Test reading stream with missing optional fields uses defaults."""
        # Missing 'url' and 'size' fields (now optional)
        input_data = {"event": "start"}
        stream = io.StringIO(json.dumps(input_data) + "\n")
        reader = Reader(stream)

        objects = list(reader.read())
        assert len(objects) == 1

        obj = objects[0]
        assert obj.name() == ""  # Default name
        assert obj.event() == "start"
        assert obj.body() == b""  # Empty body for missing URL


class TestWriter:
    """Test the Writer class for output stream processing."""

    def test_writer_initialization(self):
        """Test Writer initialization."""
        stream = io.StringIO()
        writer = Writer(stream)
        assert writer.stream == stream
        assert writer._initialized is False

    def test_push_output_record_directly(self):
        """Test pushing an Output record directly."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(data=b"test data", content_type="text/plain", metadata={"source": "test"})
        local_obj = pugmark.LocalObject(output)

        writer.write(local_obj)

        # Parse the JSON output
        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        # Verify base64 encoding (small data is not compressed)
        expected_data = base64.b64encode(b"test data").decode("ascii")
        assert data["data"] == expected_data
        assert data["content-type"] == "text/plain"
        # Small data should not be compressed
        assert "content-encoding" not in data
        assert data["metadata"] == {"source": "test"}

    def test_push_string_data(self):
        """Test pushing string data with automatic encoding."""
        stream = io.StringIO()
        writer = Writer(stream)

        # Create LocalObject from string data
        output = Output(data=b"Hello, World!", content_type="text/plain")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        # Small data is not compressed, decode directly
        original_data = base64.b64decode(data["data"])

        assert original_data == b"Hello, World!"
        assert data["content-type"] == "text/plain"
        # Small data should not be compressed
        assert "content-encoding" not in data

    def test_push_json_data(self):
        """Test pushing JSON data with automatic encoding."""
        stream = io.StringIO()
        writer = Writer(stream)

        test_data = {"message": "Hello", "count": 42}
        json_bytes = json.dumps(test_data).encode("utf-8")
        output = Output(data=json_bytes, content_type="application/json")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        # Small data is not compressed, decode directly
        original_data = base64.b64decode(data["data"])

        assert json.loads(original_data.decode("utf-8")) == test_data
        assert data["content-type"] == "application/json"
        # Small data should not be compressed
        assert "content-encoding" not in data

    def test_push_binary_data(self):
        """Test pushing binary data with automatic encoding."""
        stream = io.StringIO()
        writer = Writer(stream)

        binary_data = b"\x00\x01\x02\x03\xff"
        output = Output(data=binary_data, content_type="application/octet-stream")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        # Small data is not compressed, decode directly
        original_data = base64.b64decode(data["data"])

        assert original_data == binary_data
        assert data["content-type"] == "application/octet-stream"
        # Small data should not be compressed
        assert "content-encoding" not in data

    def test_push_bytearray_data(self):
        """Test pushing bytearray data."""
        stream = io.StringIO()
        writer = Writer(stream)

        bytearray_data = bytearray([1, 2, 3, 4])
        output = Output(data=bytes(bytearray_data), content_type="application/octet-stream")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        # Small data is not compressed, decode directly
        original_data = base64.b64decode(data["data"])

        assert original_data == bytes(bytearray_data)
        assert data["content-type"] == "application/octet-stream"
        # Small data should not be compressed
        assert "content-encoding" not in data

    def test_push_with_custom_options(self):
        """Test pushing data with custom content type and metadata."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(
            data=b"test data",
            content_type="text/custom",
            metadata={"version": "1.0", "source": "test"},
        )
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        assert data["content-type"] == "text/custom"
        assert data["metadata"] == {"version": "1.0", "source": "test"}

    def test_push_with_custom_encoding(self):
        """Test pushing data with custom content encoding (no auto-compression)."""
        stream = io.StringIO()
        writer = Writer(stream)

        # Create properly gzip-compressed data for the test
        original_data = b"test data"
        compressed_data = gzip.compress(original_data)
        output = Output(data=compressed_data, content_encoding="gzip")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        # The LocalObject decompresses the data internally, so Writer gets uncompressed data
        # Since the data is small (< 1024 bytes), Writer won't re-compress it
        assert "content-encoding" not in data  # Small data is not compressed by Writer
        decoded_data = base64.b64decode(data["data"])
        assert decoded_data == original_data

    def test_push_omits_empty_fields(self):
        """Test that empty fields are omitted from JSON output."""
        stream = io.StringIO()
        writer = Writer(stream)

        # Push data with no custom options
        output = Output(data=b"test", content_type="text/plain")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        # Should have data and content-type
        # but no metadata field since it's empty
        # Small data should not have content-encoding since it's not compressed
        assert "data" in data
        assert "content-type" in data
        assert "content-encoding" not in data  # Small data is not compressed
        assert "metadata" not in data

    def test_multiple_pushes(self):
        """Test multiple push operations."""
        stream = io.StringIO()
        writer = Writer(stream)

        output1 = Output(data=b"first", content_type="text/plain")
        output2 = Output(data=b"second", content_type="text/plain")
        writer.write(pugmark.LocalObject(output1))
        writer.write(pugmark.LocalObject(output2))

        lines = stream.getvalue().strip().split("\n")
        assert len(lines) == 2

        # Both should be valid JSON
        data1 = json.loads(lines[0])
        data2 = json.loads(lines[1])

        assert data1["content-type"] == "text/plain"
        assert data2["content-type"] == "text/plain"


class TestModuleLevelFunctions:
    """Test module-level convenience functions."""

    def test_read_function(self):
        """Test the module-level read() function."""
        # Mock the default session's read method
        with patch("pugmark._default_session") as mock_session:
            mock_objects = [Mock(), Mock()]
            mock_session.read.return_value = iter(mock_objects)

            result = list(pugmark.read())

            assert result == mock_objects
            mock_session.read.assert_called_once()

    def test_write_function(self):
        """Test the module-level write() function."""
        # Mock the default session's write method
        with patch("pugmark._default_session") as mock_session:
            # Create an Output and LocalObject to pass to write()
            output = pugmark.Output(
                data=b"test data",
                name="",
                content_type="text/custom",
                content_encoding="",
                schema_url="",
                metadata={"test": "value"},
            )
            test_obj = pugmark.LocalObject(output)

            pugmark.write(test_obj)

            # The module-level write function passes the object to session.write(obj)
            mock_session.write.assert_called_once()
            call_args = mock_session.write.call_args[0]
            obj = call_args[0]
            # Verify the object has the expected properties
            assert obj.content_type() == "text/custom"
            assert obj.metadata() == {"test": "value"}
            assert obj.body() == b"test data"


class TestSession:
    """Test the Session class for encapsulated state management."""

    def test_session_initialization_default(self):
        """Test Session initialization with default streams."""
        session = pugmark.Session()
        assert session.reader is not None
        assert session.writer is not None
        assert session._state is not None

    def test_session_initialization_custom_streams(self):
        """Test Session initialization with custom streams."""
        input_stream = io.StringIO()
        output_stream = io.StringIO()
        session = pugmark.Session(input_stream, output_stream)

        assert session.reader.stream == input_stream
        assert session.writer.stream == output_stream

    def test_session_read(self):
        """Test Session read method."""
        input_data = {"url": "http://example.com/test.txt", "size": 100}
        input_stream = io.StringIO(json.dumps(input_data) + "\n")
        session = pugmark.Session(input_stream, io.StringIO())

        objects = list(session.read())
        assert len(objects) == 1
        assert objects[0]._input.url == "http://example.com/test.txt"
        # Verify object was added to session state
        assert len(session._state._list) == 1

    def test_session_write(self):
        """Test Session write method."""
        output_stream = io.StringIO()
        session = pugmark.Session(io.StringIO(), output_stream)

        output = pugmark.Output(data=b"test", content_type="text/plain")
        obj = pugmark.LocalObject(output)
        session.write(obj)

        # Verify output was written
        json_output = output_stream.getvalue().strip()
        data = json.loads(json_output)
        assert data["content-type"] == "text/plain"

        # Verify object was added to session state
        assert len(session._state._list) == 1

    def test_session_state_isolation(self):
        """Test that different sessions have isolated state."""
        session1 = pugmark.Session(io.StringIO(), io.StringIO())
        session2 = pugmark.Session(io.StringIO(), io.StringIO())

        output1 = pugmark.Output(data=b"session1", name="obj1", content_type="text/plain")
        output2 = pugmark.Output(data=b"session2", name="obj2", content_type="text/plain")

        session1.write(pugmark.LocalObject(output1))
        session2.write(pugmark.LocalObject(output2))

        # Each session should only have its own objects
        assert len(session1._state._list) == 1
        assert len(session2._state._list) == 1
        assert "obj1" in session1._state
        assert "obj1" not in session2._state
        assert "obj2" in session2._state
        assert "obj2" not in session1._state

    def test_session_load_store(self):
        """Test Session load and store methods."""
        session = pugmark.Session(io.StringIO(), io.StringIO())

        # Store an object
        output = pugmark.Output(data=b"stored data", name="stored", content_type="text/plain")
        obj = pugmark.LocalObject(output)
        session.store(obj)

        # Load it back
        loaded = session.load("stored")
        assert loaded is not None
        assert loaded.name() == "stored"
        assert loaded.body() == b"stored data"

        # Try loading non-existent object
        missing = session.load("missing")
        assert missing is None

    def test_session_pause(self):
        """Test Session pause method."""
        output_stream = io.StringIO()
        session = pugmark.Session(io.StringIO(), output_stream)

        session.pause("test pause reason")

        json_output = output_stream.getvalue().strip()
        data = json.loads(json_output)

        assert data["content-type"] == "application/vnd.pugmark.pause+text"
        decoded_reason = base64.b64decode(data["data"]).decode("utf-8")
        assert decoded_reason == "test pause reason"

    def test_session_sleep(self):
        """Test Session sleep method."""
        output_stream = io.StringIO()
        session = pugmark.Session(io.StringIO(), output_stream)

        session.sleep(30.5, "test sleep reason")

        json_output = output_stream.getvalue().strip()
        data = json.loads(json_output)

        assert data["content-type"] == "application/vnd.pugmark.pause+text"
        assert data["metadata"]["duration"] == "30.50s"
        decoded_reason = base64.b64decode(data["data"]).decode("utf-8")
        assert decoded_reason == "test sleep reason"

    def test_session_open_context_manager(self):
        """Test Session open context manager."""
        session = pugmark.Session(io.StringIO(), io.StringIO())

        # Create initial object
        output = pugmark.Output(data=b"initial", name="test.txt", content_type="text/plain")
        session.store(pugmark.LocalObject(output))

        # Test opening and modifying
        with session.open("test.txt") as f:
            content = f.read()
            assert content == b"initial"
            f.seek(0)
            f.write(b"modified")

        # Check that it was updated
        loaded = session.load("test.txt")
        assert loaded.body() == b"modified"

    def test_session_for_testing_mocks(self):
        """Test using Session with mock streams for testing."""
        mock_input = io.StringIO('{"url": "http://test.com", "size": 10}\n')
        mock_output = io.StringIO()

        session = pugmark.Session(mock_input, mock_output)

        # Read from mock input
        objects = list(session.read())
        assert len(objects) == 1
        assert objects[0]._input.url == "http://test.com"

        # Write to mock output
        output = pugmark.Output(data=b"test response", content_type="text/plain")
        session.write(pugmark.LocalObject(output))

        # Verify mock output
        json_output = mock_output.getvalue().strip()
        data = json.loads(json_output)
        assert data["content-type"] == "text/plain"


class TestDefaultSession:
    """Test the default_session() function."""

    def test_default_session_returns_same_instance(self):
        """Test that default_session() returns the same instance."""
        session1 = pugmark.default_session()
        session2 = pugmark.default_session()
        assert session1 is session2

    def test_default_session_is_session_instance(self):
        """Test that default_session() returns a Session instance."""
        session = pugmark.default_session()
        assert isinstance(session, pugmark.Session)

    def test_default_session_used_by_global_functions(self):
        """Test that global functions use the default session."""
        default = pugmark.default_session()

        # The global stdin/stdout should point to the default session's reader/writer
        assert pugmark.stdin is default.reader
        assert pugmark.stdout is default.writer

    def test_default_session_state_access(self):
        """Test accessing the default session's state directly."""
        default = pugmark.default_session()

        # Should be able to access the state
        state = default._state
        assert len(state._list) >= 0  # Should be a valid state object


class TestDataClasses:
    """Test the Input and Output dataclasses."""

    def test_input_creation(self):
        """Test Input dataclass creation."""
        input_record = Input(
            url="http://example.com/test.txt",
            size=100,
            content_type="text/plain",
            content_encoding="gzip",
            schema_url="https://example.com/schema.json",
            metadata={"name": "test.txt"},
        )

        assert input_record.url == "http://example.com/test.txt"
        assert input_record.size == 100
        assert input_record.content_type == "text/plain"
        assert input_record.content_encoding == "gzip"
        assert input_record.schema_url == "https://example.com/schema.json"
        assert input_record.metadata == {"name": "test.txt"}

    def test_input_defaults(self):
        """Test Input dataclass with default values."""
        input_record = Input(url="http://example.com/test.txt", size=100)

        assert input_record.content_type == ""
        assert input_record.content_encoding == ""
        assert input_record.schema_url == ""
        assert input_record.metadata == {}

    def test_input_post_init(self):
        """Test Input __post_init__ method."""
        # With None metadata
        input_record = Input(url="http://example.com/test.txt", size=100, metadata=None)
        assert input_record.metadata == {}

        # With existing metadata
        metadata = {"name": "test.txt"}
        input_record = Input(url="http://example.com/test.txt", size=100, metadata=metadata)
        assert input_record.metadata == metadata

    def test_output_creation(self):
        """Test Output dataclass creation."""
        output_record = Output(
            data=b"test data",
            content_type="text/plain",
            content_encoding="zstd",
            schema_url="https://example.com/output-schema.json",
            metadata={"source": "test"},
        )

        assert output_record.data == b"test data"
        assert output_record.content_type == "text/plain"
        assert output_record.content_encoding == "zstd"
        assert output_record.schema_url == "https://example.com/output-schema.json"
        assert output_record.metadata == {"source": "test"}

    def test_output_defaults(self):
        """Test Output dataclass with default values."""
        output_record = Output(data=b"test data")

        assert output_record.content_type == ""
        assert output_record.content_encoding == ""
        assert output_record.schema_url == ""
        assert output_record.metadata == {}
        assert output_record.fork is False

    def test_output_with_fork(self):
        """Test Output dataclass with fork=True."""
        output_record = Output(data=b"fork data", fork=True)

        assert output_record.fork is True

    def test_local_object_fork_method(self):
        """Test LocalObject.fork() method."""
        # Test fork=False (default)
        output_no_fork = Output(data=b"no fork")
        obj_no_fork = pugmark.LocalObject(output_no_fork)
        assert obj_no_fork.fork() is False

        # Test fork=True
        output_with_fork = Output(data=b"with fork", fork=True)
        obj_with_fork = pugmark.LocalObject(output_with_fork)
        assert obj_with_fork.fork() is True

    def test_remote_object_fork_method(self):
        """Test RemoteObject.fork() always returns False."""
        input_record = Input(url="http://example.com/test")
        obj = pugmark.RemoteObject(input_record)
        assert obj.fork() is False

    def test_writer_serializes_fork_flag(self):
        """Test that Writer serializes the fork flag in JSON output."""
        stream = io.StringIO()
        writer = Writer(stream)

        # Create a LocalObject with fork=True
        output = Output(
            data=b"fork data",
            content_type="application/json",
            fork=True,
        )
        obj = pugmark.LocalObject(output)
        writer.write(obj)

        stream.seek(0)
        result = json.loads(stream.read().strip())
        assert result.get("fork") is True

    def test_writer_omits_fork_when_false(self):
        """Test that Writer omits fork flag when it's False."""
        stream = io.StringIO()
        writer = Writer(stream)

        # Create a LocalObject with fork=False (default)
        output = Output(data=b"no fork", content_type="text/plain")
        obj = pugmark.LocalObject(output)
        writer.write(obj)

        stream.seek(0)
        result = json.loads(stream.read().strip())
        assert "fork" not in result


class TestErrorHandling:
    """Test error handling and edge cases."""

    def test_writer_json_marshal_error(self):
        """Test Writer with unmarshalable JSON data."""
        stream = io.StringIO()
        writer = Writer(stream)

        # Create an unmarshalable object
        class UnmarshalableClass:
            def __init__(self):
                self.circular_ref = self

        unmarshalable_obj = UnmarshalableClass()

        # Try to create an object that would fail JSON encoding
        with pytest.raises(TypeError):
            # This should fail during JSON encoding when creating the Output
            import json

            json_str = json.dumps(unmarshalable_obj)
            output = Output(data=json_str.encode("utf-8"), content_type="application/json")
            writer.write(pugmark.LocalObject(output))


class TestIntegration:
    """Integration tests with real HTTP server."""

    @pytest.fixture
    def http_server(self):
        """Create a test HTTP server."""

        class TestHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == "/text":
                    self.send_response(200)
                    self.send_header("Content-Type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Hello, World!")
                elif self.path == "/json":
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"message": "Hello", "count": 42}')
                elif self.path == "/gzip":
                    self.send_response(200)
                    self.send_header("Content-Type", "text/plain")
                    self.send_header("Content-Encoding", "gzip")
                    self.end_headers()
                    compressed_data = gzip.compress(b"Compressed Hello!")
                    self.wfile.write(compressed_data)
                else:
                    self.send_response(404)
                    self.end_headers()

            def log_message(self, format, *args):
                pass  # Suppress log messages

        server = HTTPServer(("localhost", 0), TestHandler)
        port = server.server_address[1]
        thread = Thread(target=server.serve_forever)
        thread.daemon = True
        thread.start()

        yield f"http://localhost:{port}"

        server.shutdown()
        thread.join()

    def test_real_http_text_decode(self, http_server):
        """Test decoding text from real HTTP server."""
        # Create RemoteObject from Input record
        input_record = Input(url=f"{http_server}/text", size=13, content_type="text/plain")
        obj = pugmark.RemoteObject(input_record)
        data = obj.body()
        text = data.decode("utf-8")
        assert text == "Hello, World!"

    def test_real_http_json_decode(self, http_server):
        """Test decoding JSON from real HTTP server."""
        # Create RemoteObject from Input record
        input_record = Input(url=f"{http_server}/json", size=35, content_type="application/json")
        obj = pugmark.RemoteObject(input_record)
        data = obj.body()
        json_data = json.loads(data.decode("utf-8"))
        assert json_data == {"message": "Hello", "count": 42}

    def test_real_http_auto_decode(self, http_server):
        """Test automatic decoding from real HTTP server."""
        # Text auto-decode
        input_record = Input(url=f"{http_server}/text", size=13, content_type="text/plain")
        obj = pugmark.RemoteObject(input_record)
        text = obj.body().decode("utf-8")
        assert text == "Hello, World!"

        # JSON auto-decode
        input_record = Input(url=f"{http_server}/json", size=35, content_type="application/json")
        obj = pugmark.RemoteObject(input_record)
        data = json.loads(obj.body().decode("utf-8"))
        assert data == {"message": "Hello", "count": 42}

    def test_real_http_gzip_decode(self, http_server):
        """Test decoding gzip-compressed content from real HTTP server."""
        # Create RemoteObject with gzip content encoding
        input_record = Input(
            url=f"{http_server}/gzip",
            size=len(gzip.compress(b"Compressed Hello!")),
            content_type="text/plain",
            content_encoding="gzip",
        )
        obj = pugmark.RemoteObject(input_record)
        # The RemoteObject automatically handles gzip decompression
        data = obj.body()
        text = data.decode("utf-8")
        assert text == "Compressed Hello!"

    def test_end_to_end_workflow(self, http_server):
        """Test complete end-to-end workflow."""
        # Create input stream with object references
        inputs = [
            {
                "url": f"{http_server}/text",
                "size": 13,
                "content-type": "text/plain",
                "name": "hello.txt",
                "metadata": {},
            },
            {
                "url": f"{http_server}/json",
                "size": 35,
                "content-type": "application/json",
                "name": "data.json",
                "metadata": {},
            },
        ]

        input_stream = io.StringIO()
        for inp in inputs:
            input_stream.write(json.dumps(inp) + "\n")
        input_stream.seek(0)

        # Create output stream
        output_stream = io.StringIO()

        # Process objects
        reader = Reader(input_stream)
        writer = Writer(output_stream)

        for obj in reader.read():
            data = obj.body()
            if obj.content_type() == "text/plain":
                text_data = data.decode("utf-8")
                processed = text_data.upper()
            else:
                json_data = json.loads(data.decode("utf-8"))
                processed = {"processed": True, "original": json_data}

            # Create LocalObject for output
            if isinstance(processed, str):
                output_data = processed.encode("utf-8")
                content_type = "text/plain"
            else:
                output_data = json.dumps(processed).encode("utf-8")
                content_type = "application/json"

            output = Output(
                data=output_data, content_type=content_type, metadata={"source": obj.name()}
            )
            writer.write(pugmark.LocalObject(output))

        # Verify outputs
        output_lines = output_stream.getvalue().strip().split("\n")
        assert len(output_lines) == 2

        # Check first output (text -> uppercase)
        output1 = json.loads(output_lines[0])
        assert output1["content-type"] == "text/plain"
        assert output1["metadata"]["source"] == "hello.txt"

        # Check second output (json -> processed object)
        output2 = json.loads(output_lines[1])
        assert output2["content-type"] == "application/json"
        assert output2["metadata"]["source"] == "data.json"


class TestPugmarkOpen:
    """Test the pugmark.open context manager function."""

    def test_open_existing_object(self):
        """Test opening an existing object from state."""
        # Use a real session for more reliable testing
        session = pugmark.Session(io.StringIO(), io.StringIO())

        # Store an existing object
        output = pugmark.Output(data=b"existing data", name="test.txt", content_type="text/plain")
        session.store(pugmark.LocalObject(output))

        # Test opening through session
        with session.open("test.txt", content_type="text/plain") as f:
            # Should contain existing data
            content = f.read()
            assert content == b"existing data"

            # Modify the content
            f.seek(0)
            f.write(b"modified data")

        # Verify it was modified
        loaded = session.load("test.txt")
        assert loaded.body() == b"modified data"
        assert loaded.name() == "test.txt"
        assert loaded.content_type() == "text/plain"

    def test_open_new_object(self):
        """Test opening a new object that doesn't exist in state."""
        # Use a real session
        session = pugmark.Session(io.StringIO(), io.StringIO())

        with session.open("new.txt", content_type="text/plain") as f:
            # Should start empty
            content = f.read()
            assert content == b""

            # Write new content
            f.seek(0)
            f.write(b"new content")

        # Verify it was created
        loaded = session.load("new.txt")
        assert loaded.body() == b"new content"
        assert loaded.name() == "new.txt"
        assert loaded.content_type() == "text/plain"

    def test_open_no_changes(self):
        """Test opening an object without making changes."""
        # Use a real session
        session = pugmark.Session(io.StringIO(), io.StringIO())

        # Store an existing object
        output = pugmark.Output(data=b"unchanged data", name="test.txt", content_type="text/plain")
        session.store(pugmark.LocalObject(output))
        original_list_length = len(session._state._list)

        with session.open("test.txt") as f:
            # Just read, don't modify
            content = f.read()
            assert content == b"unchanged data"

        # Should not have added new objects since data wasn't changed
        assert len(session._state._list) == original_list_length

    def test_open_with_custom_metadata(self):
        """Test opening with custom metadata."""
        with mock_session_state() as (mock_state, mock_urlopen):
            with patch("pugmark._default_session.write") as mock_write:
                custom_metadata = {"version": "1.0", "author": "test"}
                with pugmark.open("custom.txt", metadata=custom_metadata) as f:
                    f.write(b"custom data")

                # Should include custom metadata
                mock_write.assert_called_once()
                call_args = mock_write.call_args[0]
                obj = call_args[0]
                assert obj.body() == b"custom data"
                assert obj.name() == "custom.txt"
                assert obj.metadata() == custom_metadata

    def test_open_with_content_encoding(self):
        """Test opening with custom content encoding."""
        with mock_session_state() as (mock_state, mock_urlopen):
            with patch("pugmark._default_session.write") as mock_write:
                with pugmark.open("encoded.txt", content_encoding="gzip") as f:
                    f.write(b"encoded data")

                mock_write.assert_called_once()
                call_args = mock_write.call_args[0]
                obj = call_args[0]
                # Don't call obj.body() since the test data isn't actually compressed
                # but the LocalObject tries to decompress based on content_encoding
                assert obj.name() == "encoded.txt"

    def test_open_read_write_cycle(self):
        """Test reading existing data, modifying it, and writing back."""
        with patch("pugmark._default_session.state") as mock_state:
            mock_object = Mock()
            mock_object.body.return_value = b"original content"

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=mock_object)
            mock_state_instance.get_memory_url = Mock(return_value="http://example.com/test")
            mock_state.return_value = mock_state_instance

            with patch("pugmark._default_session.write") as mock_write:
                with patch("urllib.request.urlopen") as mock_urlopen:
                    mock_response = Mock()
                    mock_response.read = Mock(return_value=b"original content")
                    mock_urlopen.return_value.__enter__ = Mock(return_value=mock_response)
                    mock_urlopen.return_value.__exit__ = Mock(return_value=None)

                    with pugmark.open("modify.txt", content_type="text/plain") as f:
                        # Read existing content
                        original = f.read()
                        assert original == b"original content"

                        # Append to it
                        f.write(b" + appended")

                    # Should write the combined content
                    mock_write.assert_called_once()
                    call_args = mock_write.call_args[0]
                    obj = call_args[0]
                    assert obj.body() == b"original content + appended"
                    assert obj.name() == "modify.txt"
                    assert obj.content_type() == "text/plain"

    def test_open_seek_and_overwrite(self):
        """Test seeking to beginning and overwriting content."""
        with patch("pugmark._default_session.state") as mock_state:
            mock_object = Mock()
            mock_object.body.return_value = b"old data that will be replaced"

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=mock_object)
            mock_state_instance.get_memory_url = Mock(return_value="http://example.com/test")
            mock_state.return_value = mock_state_instance

            with patch("pugmark._default_session.write") as mock_write:
                with patch("urllib.request.urlopen") as mock_urlopen:
                    mock_response = Mock()
                    mock_response.read = Mock(return_value=b"old data that will be replaced")
                    mock_urlopen.return_value.__enter__ = Mock(return_value=mock_response)
                    mock_urlopen.return_value.__exit__ = Mock(return_value=None)

                    with pugmark.open("overwrite.txt") as f:
                        # Seek to beginning and overwrite
                        f.seek(0)
                        f.write(b"completely new data")
                        f.truncate()  # Truncate to remove old content

                    mock_write.assert_called_once()
                    call_args = mock_write.call_args[0]
                    obj = call_args[0]
                    assert obj.body() == b"completely new data"
                    assert obj.name() == "overwrite.txt"

    def test_open_empty_existing_object(self):
        """Test opening an existing object that has empty content."""
        with patch("pugmark._default_session.state") as mock_state:
            mock_object = Mock()
            mock_object.body.return_value = b""  # Empty existing content

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=mock_object)
            mock_state_instance.get_memory_url = Mock(return_value="http://example.com/test")
            mock_state.return_value = mock_state_instance

            with patch("pugmark._default_session.write") as mock_write:
                with patch("urllib.request.urlopen") as mock_urlopen:
                    mock_response = Mock()
                    mock_response.read = Mock(return_value=b"")
                    mock_urlopen.return_value.__enter__ = Mock(return_value=mock_response)
                    mock_urlopen.return_value.__exit__ = Mock(return_value=None)

                    with pugmark.open("empty.txt") as f:
                        # Should start empty
                        content = f.read()
                        assert content == b""

                        # Write some content
                        f.write(b"now has content")

                    mock_write.assert_called_once()
                    call_args = mock_write.call_args[0]
                    obj = call_args[0]
                    assert obj.body() == b"now has content"
                    assert obj.name() == "empty.txt"

    def test_open_binary_data(self):
        """Test opening and working with binary data."""
        with mock_session_state() as (mock_state, mock_urlopen):
            with patch("pugmark._default_session.write") as mock_write:
                binary_data = b"\x00\x01\x02\x03\xff\xfe\xfd"
                with pugmark.open("binary.dat", content_type="application/octet-stream") as f:
                    f.write(binary_data)

                mock_write.assert_called_once()
                call_args = mock_write.call_args[0]
                obj = call_args[0]
                assert obj.body() == binary_data
                assert obj.name() == "binary.dat"
                assert obj.content_type() == "application/octet-stream"

    def test_open_metadata_copy_safety(self):
        """Test that metadata is properly copied to avoid mutation issues."""
        with mock_session_state() as (mock_state, mock_urlopen):
            with patch("pugmark._default_session.write") as mock_write:
                original_metadata = {"key": "value"}
                with pugmark.open("meta.txt", metadata=original_metadata) as f:
                    f.write(b"test")

                # Original metadata should not be modified
                assert original_metadata == {"key": "value"}

                # Called metadata should be passed through
                mock_write.assert_called_once()
                call_args = mock_write.call_args[0]
                obj = call_args[0]
                assert obj.body() == b"test"
                assert obj.name() == "meta.txt"
                assert obj.metadata() == original_metadata


class TestLoadStoreFunctions:
    """Test the module-level load() and store() functions for state management."""

    def test_load_existing_object(self):
        """Test loading an existing object from state."""
        with patch("pugmark._default_session.state") as mock_state:
            # Create mock object
            mock_object = Mock()
            mock_object.body.return_value = b"test content"
            mock_object.content_type.return_value = "text/plain"

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=mock_object)
            mock_state_instance.get_memory_url = Mock(return_value=None)
            mock_state.return_value = mock_state_instance

            result = pugmark.load("test.txt")

            assert result == mock_object
            mock_state.assert_called_once()
            mock_state_instance.__contains__.assert_called_once_with("test.txt")
            mock_state_instance.__getitem__.assert_called_once_with("test.txt")

    def test_load_nonexistent_object(self):
        """Test loading a non-existent object returns None."""
        with patch("pugmark._default_session.state") as mock_state:
            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=False)
            mock_state_instance.get_memory_url = Mock(return_value=None)
            mock_state.return_value = mock_state_instance

            result = pugmark.load("nonexistent.txt")

            assert result is None
            mock_state.assert_called_once()
            mock_state_instance.__contains__.assert_called_once_with("nonexistent.txt")

    def test_load_with_json_object(self):
        """Test loading an object that contains JSON data."""
        with patch("pugmark._default_session.state") as mock_state:
            mock_object = Mock()
            mock_object.body.return_value = b'{"key": "value", "number": 42}'
            mock_object.content_type.return_value = "application/json"

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=mock_object)
            mock_state_instance.get_memory_url = Mock(return_value=None)
            mock_state.return_value = mock_state_instance

            result = pugmark.load("data.json")

            assert result == mock_object
            assert result.content_type() == "application/json"

    def test_load_with_binary_object(self):
        """Test loading an object that contains binary data."""
        with patch("pugmark._default_session.state") as mock_state:
            binary_data = b"\x00\x01\x02\x03\xff"
            mock_object = Mock()
            mock_object.body.return_value = binary_data
            mock_object.content_type.return_value = "application/octet-stream"

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=mock_object)
            mock_state_instance.get_memory_url = Mock(return_value=None)
            mock_state.return_value = mock_state_instance

            result = pugmark.load("binary.dat")

            assert result == mock_object
            assert result.body() == binary_data

    def test_store_object(self):
        """Test storing an object."""
        with patch("pugmark._default_session.write") as mock_write:
            mock_object = Mock()
            mock_object.body.return_value = b"Hello, World!"
            mock_object.content_type.return_value = "text/plain"
            mock_object.schema_url.return_value = ""
            mock_object.metadata.return_value = {}

            pugmark.store(mock_object)

            # store() now just calls write() with the object directly
            mock_write.assert_called_once_with(mock_object)

    def test_store_object_with_metadata(self):
        """Test storing an object with metadata."""
        with patch("pugmark._default_session.write") as mock_write:
            mock_object = Mock()
            mock_object.body.return_value = b'{"config": "value"}'
            mock_object.content_type.return_value = "application/json"
            mock_object.schema_url.return_value = "https://example.com/schema.json"
            mock_object.metadata.return_value = {"version": "1.0", "author": "test"}

            pugmark.store(mock_object)

            # store() now just calls write() with the object directly
            mock_write.assert_called_once_with(mock_object)

    def test_load_store_roundtrip(self):
        """Test load/store roundtrip with object data."""
        with patch("pugmark._default_session.write") as mock_write, patch(
            "pugmark._default_session.state"
        ) as mock_state:
            # Create a mock object to store
            original_object = Mock()
            original_object.body.return_value = b"test content"
            original_object.content_type.return_value = "text/plain"
            original_object.schema_url.return_value = ""
            original_object.metadata.return_value = {}

            # Store the object
            pugmark.store(original_object)

            # Mock state for loading
            loaded_object = Mock()
            loaded_object.body.return_value = b"test content"
            loaded_object.content_type.return_value = "text/plain"

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=loaded_object)
            mock_state_instance.get_memory_url = Mock(return_value=None)
            mock_state.return_value = mock_state_instance

            # Load the object back
            result = pugmark.load("test.txt")

            assert result == loaded_object
            # store() now just calls write() with the object directly
            mock_write.assert_called_once_with(original_object)

    def test_load_empty_name(self):
        """Test loading an object with an empty name."""
        with patch("pugmark._default_session.state") as mock_state:
            mock_object = Mock()
            mock_object.body.return_value = b"empty name content"

            mock_state_instance = Mock()
            mock_state_instance.__contains__ = Mock(return_value=True)
            mock_state_instance.__getitem__ = Mock(return_value=mock_object)
            mock_state_instance.get_memory_url = Mock(return_value=None)
            mock_state.return_value = mock_state_instance

            result = pugmark.load("")

            assert result == mock_object
            mock_state_instance.__contains__.assert_called_once_with("")
            mock_state_instance.__getitem__.assert_called_once_with("")


class TestPauseFunction:
    """Test the module-level pause() function for execution control."""

    def test_pause_with_default_reason(self):
        """Test pause function with default empty reason."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.pause()

            # pause() creates a LocalObject with the pause control message
            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b""
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_with_custom_reason(self):
        """Test pause function with custom reason."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.pause("Processing complete, waiting for user input")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b"Processing complete, waiting for user input"
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_with_empty_string_reason(self):
        """Test pause function with explicitly empty string reason."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.pause("")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b""
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_with_multiline_reason(self):
        """Test pause function with multiline reason."""
        with patch("pugmark._default_session.write") as mock_write:
            reason = "First line of reason\nSecond line with details\nThird line with more info"
            pugmark.pause(reason)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == reason.encode("utf-8")
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_with_unicode_reason(self):
        """Test pause function with unicode characters in reason."""
        with patch("pugmark._default_session.write") as mock_write:
            reason = "暂停执行：等待用户输入 🔄"
            pugmark.pause(reason)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == reason.encode("utf-8")
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_with_json_like_reason(self):
        """Test pause function with JSON-like string as reason."""
        with patch("pugmark._default_session.write") as mock_write:
            reason = '{"status": "paused", "message": "Waiting for approval"}'
            pugmark.pause(reason)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == reason.encode("utf-8")
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_content_type_is_correct(self):
        """Test that pause function uses the correct content type."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.pause("test reason")

            # Verify the exact content type for pause messages
            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_function_signature(self):
        """Test that pause function has the correct signature and defaults."""
        import inspect

        sig = inspect.signature(pugmark.pause)
        params = sig.parameters

        # Should have exactly one parameter: reason
        assert len(params) == 1
        assert "reason" in params

        # reason should have default value of empty string
        reason_param = params["reason"]
        assert reason_param.default == ""
        assert reason_param.annotation is str

    def test_pause_multiple_calls(self):
        """Test multiple calls to pause function."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.pause("First pause")
            pugmark.pause("Second pause")
            pugmark.pause()  # Default reason

            assert mock_write.call_count == 3

            # Check all three calls
            calls = mock_write.call_args_list
            obj1 = calls[0][0][0]
            assert obj1.body() == b"First pause"
            assert obj1.content_type() == "application/vnd.pugmark.pause+text"

            obj2 = calls[1][0][0]
            assert obj2.body() == b"Second pause"
            assert obj2.content_type() == "application/vnd.pugmark.pause+text"

            obj3 = calls[2][0][0]
            assert obj3.body() == b""
            assert obj3.content_type() == "application/vnd.pugmark.pause+text"

    def test_pause_with_long_reason(self):
        """Test pause function with very long reason text."""
        with patch("pugmark._default_session.write") as mock_write:
            long_reason = "This is a very long reason for pausing execution. " * 100
            pugmark.pause(long_reason)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == long_reason.encode("utf-8")
            assert obj.content_type() == "application/vnd.pugmark.pause+text"


class TestSleepFunction:
    """Test the module-level sleep() function for timed execution control."""

    def test_sleep_with_default_reason(self):
        """Test sleep function with default empty reason."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(30.0)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b""
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "30.00s"}

    def test_sleep_with_custom_reason(self):
        """Test sleep function with custom reason."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(60.5, "Processing batch, waiting for resources")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b"Processing batch, waiting for resources"
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "60.50s"}

    def test_sleep_with_integer_seconds(self):
        """Test sleep function with integer seconds."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(45, "Waiting for external service")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b"Waiting for external service"
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "45.00s"}

    def test_sleep_with_fractional_seconds(self):
        """Test sleep function with fractional seconds."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(2.5)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b""
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "2.50s"}

    def test_sleep_with_very_small_duration(self):
        """Test sleep function with very small duration."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(0.1, "Brief pause")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b"Brief pause"
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "0.10s"}

    def test_sleep_with_zero_duration(self):
        """Test sleep function with zero duration."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(0)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b""
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "0.00s"}

    def test_sleep_with_empty_string_reason(self):
        """Test sleep function with explicitly empty string reason."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(15.0, "")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b""
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "15.00s"}

    def test_sleep_with_multiline_reason(self):
        """Test sleep function with multiline reason."""
        with patch("pugmark._default_session.write") as mock_write:
            reason = "First line of reason\nSecond line with details\nThird line with more info"
            pugmark.sleep(30.0, reason)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == reason.encode("utf-8")
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "30.00s"}

    def test_sleep_with_unicode_reason(self):
        """Test sleep function with unicode characters in reason."""
        with patch("pugmark._default_session.write") as mock_write:
            reason = "休眠执行：等待资源 ⏰"
            pugmark.sleep(10.5, reason)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == reason.encode("utf-8")
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "10.50s"}

    def test_sleep_with_json_like_reason(self):
        """Test sleep function with JSON-like string as reason."""
        with patch("pugmark._default_session.write") as mock_write:
            reason = '{"status": "sleeping", "message": "Waiting for batch processing"}'
            pugmark.sleep(120.0, reason)

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == reason.encode("utf-8")
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "120.00s"}

    def test_sleep_content_type_is_correct(self):
        """Test that sleep function uses the correct content type."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(5.0, "test reason")

            # Verify the exact content type for sleep messages
            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.content_type() == "application/vnd.pugmark.pause+text"

    def test_sleep_metadata_format(self):
        """Test that sleep function formats duration metadata correctly."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(42.123, "precise timing")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.metadata()["duration"] == "42.12s"

    def test_sleep_function_signature(self):
        """Test that sleep function has the correct signature and defaults."""
        import inspect

        sig = inspect.signature(pugmark.sleep)
        params = sig.parameters

        # Should have exactly two parameters: seconds and reason
        assert len(params) == 2
        assert "seconds" in params
        assert "reason" in params

        # seconds should have no default (required)
        seconds_param = params["seconds"]
        assert seconds_param.default == inspect.Parameter.empty
        assert seconds_param.annotation is float

        # reason should have default value of empty string
        reason_param = params["reason"]
        assert reason_param.default == ""
        assert reason_param.annotation is str

    def test_sleep_multiple_calls(self):
        """Test multiple calls to sleep function."""
        with patch("pugmark._default_session.write") as mock_write:
            pugmark.sleep(5.0, "First sleep")
            pugmark.sleep(10.0, "Second sleep")
            pugmark.sleep(15.0)  # Default reason

            assert mock_write.call_count == 3

            # Check all three calls
            calls = mock_write.call_args_list
            obj1 = calls[0][0][0]
            assert obj1.body() == b"First sleep"
            assert obj1.content_type() == "application/vnd.pugmark.pause+text"
            assert obj1.metadata()["duration"] == "5.00s"

            obj2 = calls[1][0][0]
            assert obj2.body() == b"Second sleep"
            assert obj2.content_type() == "application/vnd.pugmark.pause+text"
            assert obj2.metadata()["duration"] == "10.00s"

            obj3 = calls[2][0][0]
            assert obj3.body() == b""
            assert obj3.content_type() == "application/vnd.pugmark.pause+text"
            assert obj3.metadata()["duration"] == "15.00s"

    def test_sleep_with_large_duration(self):
        """Test sleep function with large duration value."""
        with patch("pugmark._default_session.write") as mock_write:
            large_duration = 3600.0  # 1 hour
            pugmark.sleep(large_duration, "Long sleep for batch processing")

            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            obj = call_args[0]
            assert obj.body() == b"Long sleep for batch processing"
            assert obj.content_type() == "application/vnd.pugmark.pause+text"
            assert obj.metadata() == {"duration": "3600.00s"}


class TestEventsAPI:
    """Test the events API for session event handling."""

    def test_event_classes_string_representation(self):
        """Test that all event classes have correct string representations."""
        start_event = pugmark.StartEvent()
        fork_event = pugmark.ForkEvent()
        wake_event = pugmark.WakeEvent()

        # Create a mock object for PushEvent
        mock_obj = Mock()
        push_event = pugmark.PushEvent(mock_obj)

        assert str(start_event) == "start"
        assert str(fork_event) == "fork"
        assert str(wake_event) == "wake"
        assert str(push_event) == "push"

    def test_push_event_object_access(self):
        """Test that PushEvent provides access to its object."""
        mock_obj = Mock()
        mock_obj.name.return_value = "test.txt"
        mock_obj.content_type.return_value = "text/plain"
        mock_obj.body.return_value = b"test content"

        push_event = pugmark.PushEvent(mock_obj)

        assert push_event.object == mock_obj
        assert push_event.object.name() == "test.txt"
        assert push_event.object.content_type() == "text/plain"
        assert push_event.object.body() == b"test content"

    def test_session_events_single_start_event(self):
        """Test Session.events() with a single start event."""
        input_data = '{"event":"start","url":"","size":0}\n'
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        assert len(events) == 1
        assert isinstance(events[0], pugmark.StartEvent)
        assert str(events[0]) == "start"

    def test_session_events_single_fork_event(self):
        """Test Session.events() with a single fork event."""
        input_data = '{"event":"fork","url":"","size":0}\n'
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        assert len(events) == 1
        assert isinstance(events[0], pugmark.ForkEvent)
        assert str(events[0]) == "fork"

    def test_session_events_single_wake_event(self):
        """Test Session.events() with a single wake event."""
        input_data = '{"event":"wake","url":"","size":0}\n'
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        assert len(events) == 1
        assert isinstance(events[0], pugmark.WakeEvent)
        assert str(events[0]) == "wake"

    def test_session_events_single_push_event(self):
        """Test Session.events() with a single push event."""
        input_data = '{"event":"push","url":"http://example.com/test.txt","size":100,"content-type":"text/plain","name":"test.txt"}\n'
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        assert len(events) == 1
        assert isinstance(events[0], pugmark.PushEvent)
        assert str(events[0]) == "push"
        assert events[0].object.name() == "test.txt"
        assert events[0].object.content_type() == "text/plain"
        assert events[0].object.event() == "push"

    def test_session_events_mixed_sequence(self):
        """Test Session.events() with a mixed sequence of events."""
        input_data = """{"event":"start","url":"","size":0}
{"event":"push","url":"http://example.com/file1.txt","size":100,"content-type":"text/plain","name":"file1.txt"}
{"event":"fork","url":"","size":0}
{"event":"wake","url":"","size":0}
{"event":"push","url":"http://example.com/file2.json","size":200,"content-type":"application/json","name":"file2.json"}
"""
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        assert len(events) == 5

        # Check event types and order
        assert isinstance(events[0], pugmark.StartEvent)
        assert isinstance(events[1], pugmark.PushEvent)
        assert isinstance(events[2], pugmark.ForkEvent)
        assert isinstance(events[3], pugmark.WakeEvent)
        assert isinstance(events[4], pugmark.PushEvent)

        # Check PushEvent objects
        assert events[1].object.name() == "file1.txt"
        assert events[1].object.content_type() == "text/plain"
        assert events[4].object.name() == "file2.json"
        assert events[4].object.content_type() == "application/json"

    def test_session_events_unknown_event_types(self):
        """Test that unknown event types are silently ignored."""
        input_data = """{"event":"start","url":"","size":0}
{"event":"unknown-type","url":"","size":0}
{"event":"push","url":"http://example.com/test.txt","size":100,"content-type":"text/plain","name":"test.txt"}
{"event":"invalid","url":"","size":0}
{"event":"fork","url":"","size":0}
"""
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        # Should only have start, push, and fork events (unknown types ignored)
        assert len(events) == 3
        assert isinstance(events[0], pugmark.StartEvent)
        assert isinstance(events[1], pugmark.PushEvent)
        assert isinstance(events[2], pugmark.ForkEvent)

    def test_session_events_empty_input(self):
        """Test Session.events() with empty input."""
        input_stream = io.StringIO("")
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        assert len(events) == 0

    def test_session_events_with_metadata(self):
        """Test Session.events() with events containing metadata."""
        input_data = '{"event":"push","url":"http://example.com/test.txt","size":100,"content-type":"text/plain","name":"test.txt","metadata":{"key1":"value1","key2":"value2"}}\n'
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        events = list(session.events())
        assert len(events) == 1
        assert isinstance(events[0], pugmark.PushEvent)

        metadata = events[0].object.metadata()
        assert metadata == {"key1": "value1", "key2": "value2"}

    def test_session_events_early_termination(self):
        """Test early termination of Session.events() iteration."""
        input_data = """{"event":"start","url":"","size":0}
{"event":"push","url":"http://example.com/file1.txt","size":100,"content-type":"text/plain","name":"file1.txt"}
{"event":"fork","url":"","size":0}
{"event":"wake","url":"","size":0}
{"event":"push","url":"http://example.com/file2.txt","size":100,"content-type":"text/plain","name":"file2.txt"}
"""
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        event_count = 0
        for _event in session.events():
            event_count += 1
            # Stop after the second event
            if event_count >= 2:
                break

        assert event_count == 2

    def test_session_events_type_assertions(self):
        """Test type assertions for different event types."""
        input_data = """{"event":"start","url":"","size":0}
{"event":"fork","url":"","size":0}
{"event":"wake","url":"","size":0}
{"event":"push","url":"http://example.com/test.txt","size":100,"content-type":"text/plain","name":"test.txt"}
"""
        input_stream = io.StringIO(input_data)
        session = pugmark.Session(input_stream, io.StringIO())

        expected_types = ["start", "fork", "wake", "push"]
        events = list(session.events())

        assert len(events) == len(expected_types)

        for _i, (event, expected_type) in enumerate(zip(events, expected_types)):
            if expected_type == "start":
                assert isinstance(event, pugmark.StartEvent)
            elif expected_type == "fork":
                assert isinstance(event, pugmark.ForkEvent)
            elif expected_type == "wake":
                assert isinstance(event, pugmark.WakeEvent)
            elif expected_type == "push":
                assert isinstance(event, pugmark.PushEvent)
                assert event.object is not None

    def test_module_level_events_function(self):
        """Test the module-level pugmark.events() function."""
        # Mock the default session's events method
        with patch("pugmark._default_session") as mock_session:
            mock_events = [pugmark.StartEvent(), pugmark.PushEvent(Mock())]
            mock_session.events.return_value = iter(mock_events)

            result = list(pugmark.events())

            assert len(result) == 2
            assert isinstance(result[0], pugmark.StartEvent)
            assert isinstance(result[1], pugmark.PushEvent)
            mock_session.events.assert_called_once()

    def test_event_interface_compliance(self):
        """Test that all event types implement the Event interface."""
        events = [
            pugmark.StartEvent(),
            pugmark.ForkEvent(),
            pugmark.WakeEvent(),
            pugmark.PushEvent(Mock()),
        ]

        for event in events:
            # Test that str() method works (required by Event base class)
            assert isinstance(str(event), str)
            assert str(event) != ""

            # Test that the event is an instance of the Event class
            assert isinstance(event, pugmark.Event)

    def test_push_event_with_none_object(self):
        """Test PushEvent handling with None object (edge case)."""
        # This shouldn't happen in practice, but test for robustness
        push_event = pugmark.PushEvent(None)  # type: ignore

        # Should not panic when converting to string
        assert str(push_event) == "push"
        assert push_event.object is None

    def test_object_event_method_remote(self):
        """Test that RemoteObject.event() returns the correct event type."""
        input_record = pugmark.Input(
            url="http://example.com/test.txt",
            size=100,
            event="push",
            content_type="text/plain",
            name="test.txt",
        )
        obj = pugmark.RemoteObject(input_record)

        assert obj.event() == "push"

    def test_object_event_method_local(self):
        """Test that LocalObject.event() returns 'push'."""
        output_record = pugmark.Output(data=b"test data", content_type="text/plain")
        obj = pugmark.LocalObject(output_record)

        assert obj.event() == "push"

    def test_reader_parses_event_field(self):
        """Test that Reader correctly parses the event field from JSON."""
        input_data = '{"event":"start","url":"http://example.com/test.txt","size":100,"content-type":"text/plain","name":"test.txt"}\n'
        input_stream = io.StringIO(input_data)
        reader = pugmark.Reader(input_stream)

        objects = list(reader.read())
        assert len(objects) == 1
        assert objects[0].event() == "start"


class TestSchemaURLSupport:
    """Test schema_url support throughout the Python SDK."""

    def test_object_with_schema_url(self):
        """Test Object initialization with schema_url."""
        # Create RemoteObject from Input record
        input_record = Input(
            url="http://example.com/test.json",
            size=100,
            content_type="application/json",
            schema_url="https://example.com/schema/test.json",
            name="test.json",
            metadata={"version": "1.0"},
        )
        obj = pugmark.RemoteObject(input_record)

        assert obj._input.url == "http://example.com/test.json"
        assert obj.name() == "test.json"
        assert obj.content_type() == "application/json"
        assert obj.schema_url() == "https://example.com/schema/test.json"
        assert obj.metadata() == {"version": "1.0"}

    def test_object_default_schema_url(self):
        """Test Object with default empty schema_url."""
        input_record = Input(url="http://example.com/test.txt", size=50)
        obj = pugmark.RemoteObject(input_record)

        assert obj.schema_url() == ""

    def test_reader_with_schema_url(self):
        """Test Reader parsing schema-url from input JSON."""
        input_data = {
            "url": "http://example.com/test.json",
            "size": 100,
            "content-type": "application/json",
            "schema-url": "https://example.com/schemas/test.json",
            "name": "test.json",
            "metadata": {"version": "2.0"},
        }
        stream = io.StringIO(json.dumps(input_data) + "\n")
        reader = Reader(stream)

        objects = list(reader.read())
        assert len(objects) == 1

        obj = objects[0]
        assert obj._input.url == "http://example.com/test.json"
        assert obj.name() == "test.json"
        assert obj.content_type() == "application/json"
        assert obj.schema_url() == "https://example.com/schemas/test.json"
        assert obj.metadata() == {"version": "2.0"}

    def test_reader_without_schema_url(self):
        """Test Reader with input JSON missing schema-url field."""
        input_data = {
            "url": "http://example.com/test.txt",
            "size": 50,
            "content-type": "text/plain",
            "name": "test.txt",
        }
        stream = io.StringIO(json.dumps(input_data) + "\n")
        reader = Reader(stream)

        objects = list(reader.read())
        assert len(objects) == 1

        obj = objects[0]
        assert obj.schema_url() == ""  # Should default to empty string

    def test_writer_with_schema_url_string_data(self):
        """Test Writer including schema-url in output JSON for string data."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(
            data=b"Hello, Schema World!",
            name="greeting.txt",
            content_type="text/plain",
            schema_url="https://example.com/schemas/greeting.json",
            metadata={"version": "1.0"},
        )
        writer.write(pugmark.LocalObject(output))

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        assert data["name"] == "greeting.txt"
        assert data["content-type"] == "text/plain"
        assert data["schema-url"] == "https://example.com/schemas/greeting.json"
        assert data["metadata"] == {"version": "1.0"}

        # Verify data content
        decoded_data = base64.b64decode(data["data"])
        assert decoded_data == b"Hello, Schema World!"

    def test_writer_with_schema_url_json_data(self):
        """Test Writer including schema-url in output JSON for JSON data."""
        stream = io.StringIO()
        writer = Writer(stream)

        test_data = {"message": "Hello", "schema_version": "2.0"}
        json_bytes = json.dumps(test_data).encode("utf-8")
        output = Output(
            data=json_bytes,
            name="data.json",
            content_type="application/json",
            schema_url="https://json-schema.org/draft-07/schema",
        )
        writer.write(pugmark.LocalObject(output))

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        assert data["name"] == "data.json"
        assert data["content-type"] == "application/json"
        assert data["schema-url"] == "https://json-schema.org/draft-07/schema"

    def test_writer_with_output_record_with_schema_url(self):
        """Test Writer with Output record containing schema_url."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(
            data=b"binary data",
            name="data.bin",
            content_type="application/octet-stream",
            schema_url="https://example.com/binary-schema",
            metadata={"encoding": "custom"},
        )

        writer.write(pugmark.LocalObject(output))

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        assert data["name"] == "data.bin"
        assert data["content-type"] == "application/octet-stream"
        assert data["schema-url"] == "https://example.com/binary-schema"
        assert data["metadata"] == {"encoding": "custom"}

    def test_writer_omits_empty_schema_url(self):
        """Test that Writer omits empty schema_url from JSON output."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(data=b"test data", content_type="text/plain", schema_url="")
        writer.write(pugmark.LocalObject(output))  # Explicitly empty

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        assert "schema-url" not in data  # Should be omitted when empty

    def test_writer_omits_none_schema_url(self):
        """Test that Writer omits None schema_url from JSON output."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(data=b"test data", content_type="text/plain", schema_url=None or "")
        writer.write(pugmark.LocalObject(output))  # Explicitly None

        json_output = stream.getvalue().strip()
        data = json.loads(json_output)

        assert "schema-url" not in data  # Should be omitted when None

    def test_module_level_write_with_schema_url(self):
        """Test module-level write function with schema_url."""
        with patch("pugmark._default_session.write") as mock_write:
            # Create Output and LocalObject for the new write() signature
            output = pugmark.Output(
                data=b"schema test",
                name="test.txt",
                content_type="text/plain",
                schema_url="https://example.com/text-schema.json",
                metadata={"version": "1.0"},
            )
            obj = pugmark.LocalObject(output)
            pugmark.write(obj)

            # The module-level write function passes the object to _default_session.write
            mock_write.assert_called_once()
            call_args = mock_write.call_args[0]
            written_obj = call_args[0]
            assert written_obj.content_type() == "text/plain"
            assert written_obj.schema_url() == "https://example.com/text-schema.json"
            assert written_obj.metadata() == {"version": "1.0"}
            assert written_obj.body() == b"schema test"

    def test_store_function_with_schema_url(self):
        """Test store function with schema_url parameter."""
        with patch("pugmark._default_session.write") as mock_write:
            mock_object = Mock()
            mock_object.body.return_value = b'{"setting": "value"}'
            mock_object.content_type.return_value = "application/json"
            mock_object.schema_url.return_value = "https://example.com/config-schema.json"
            mock_object.metadata.return_value = {"env": "test"}

            pugmark.store(mock_object)

            # store() now just calls write() with the object directly
            mock_write.assert_called_once_with(mock_object)

    def test_open_function_with_schema_url(self):
        """Test open context manager with schema_url."""
        with mock_session_state() as (mock_state, mock_urlopen):
            with patch("pugmark._default_session.write") as mock_write:
                with pugmark.open(
                    "schema.json",
                    content_type="application/json",
                    schema_url="https://json-schema.org/draft-07/schema",
                ) as f:
                    f.write(b'{"type": "object"}')

                mock_write.assert_called_once()
                call_args = mock_write.call_args[0]
                obj = call_args[0]
                assert obj.body() == b'{"type": "object"}'
                assert obj.name() == "schema.json"
                assert obj.content_type() == "application/json"
                assert obj.schema_url() == "https://json-schema.org/draft-07/schema"

    def test_schema_url_various_formats(self):
        """Test schema_url with various URL formats."""
        test_cases = [
            "https://example.com/schema.json",
            "http://localhost:8080/schemas/v1/user.json",
            "file:///path/to/schema.json",
            "https://json-schema.org/draft-07/schema",
            "urn:jsonschema:com.example:User:1.0",
            "../relative/path/schema.json",
            "schema.json",
        ]

        for schema_url in test_cases:
            with patch("pugmark._default_session.write") as mock_write:
                # Create Output and LocalObject with the schema_url
                output = pugmark.Output(
                    data=b"test",
                    name="",
                    content_type="text/plain",
                    schema_url=schema_url,
                    metadata={},
                )
                obj = pugmark.LocalObject(output)
                pugmark.write(obj)

                # Module-level write should pass the object to _default_session.write
                mock_write.assert_called_once()
                call_args = mock_write.call_args[0]
                written_obj = call_args[0]
                assert written_obj.schema_url() == schema_url

    def test_schema_url_end_to_end(self):
        """Test schema_url propagation through complete read/write cycle."""
        # Create input with schema_url
        input_data = {
            "url": "http://example.com/data.json",
            "size": 50,
            "content-type": "application/json",
            "schema-url": "https://example.com/input-schema.json",
            "name": "input.json",
        }
        input_stream = io.StringIO(json.dumps(input_data) + "\n")
        output_stream = io.StringIO()

        # Process with Reader/Writer
        reader = Reader(input_stream)
        writer = Writer(output_stream)

        for obj in reader.read():
            # Verify input object has schema_url
            assert obj.schema_url() == "https://example.com/input-schema.json"

            # Process and output with different schema_url
            processed_data = {"processed": True, "original_schema": obj.schema_url()}
            json_bytes = json.dumps(processed_data).encode("utf-8")
            output = Output(
                data=json_bytes,
                name="processed.json",
                content_type="application/json",
                schema_url="https://example.com/output-schema.json",
            )
            writer.write(pugmark.LocalObject(output))

        # Verify output JSON contains schema_url
        output_json = json.loads(output_stream.getvalue().strip())
        assert output_json["schema-url"] == "https://example.com/output-schema.json"
        assert output_json["name"] == "processed.json"


class TestSessionMetadata:
    """Test session metadata functionality."""

    def test_session_metadata_passed_directly(self):
        """Test that metadata passed to Session is accessible."""
        metadata = {"user-id": "12345", "tenant": "acme-corp", "custom-key": "custom-value"}
        session = pugmark.Session(io.StringIO(), io.StringIO(), metadata=metadata)

        assert session.metadata() == metadata
        assert session.metadata()["user-id"] == "12345"
        assert session.metadata()["tenant"] == "acme-corp"
        assert session.metadata()["custom-key"] == "custom-value"

    def test_session_metadata_default_empty(self):
        """Test that metadata defaults to empty dict when not provided."""
        session = pugmark.Session(io.StringIO(), io.StringIO())

        assert session.metadata() == {}

    def test_session_metadata_from_env_var(self):
        """Test that metadata is read from PUGMARK_SESSION_METADATA env var."""
        metadata_json = '{"env-key": "env-value", "user": "test-user"}'
        with patch.dict("os.environ", {"PUGMARK_SESSION_METADATA": metadata_json}):
            # Create a new default session to pick up env var
            session = pugmark.Session(io.StringIO(), io.StringIO())
            assert session.metadata() == {"env-key": "env-value", "user": "test-user"}

    def test_session_metadata_env_var_invalid_json(self):
        """Test that invalid JSON in env var results in empty metadata."""
        with patch.dict("os.environ", {"PUGMARK_SESSION_METADATA": "invalid json"}):
            session = pugmark.Session(io.StringIO(), io.StringIO())
            assert session.metadata() == {}

    def test_session_metadata_direct_overrides_env(self):
        """Test that directly passed metadata overrides env var."""
        direct_metadata = {"direct": "value"}
        env_metadata = '{"env": "value"}'
        with patch.dict("os.environ", {"PUGMARK_SESSION_METADATA": env_metadata}):
            session = pugmark.Session(io.StringIO(), io.StringIO(), metadata=direct_metadata)
            assert session.metadata() == {"direct": "value"}
            assert "env" not in session.metadata()

    def test_module_level_metadata_function(self):
        """Test the module-level metadata() function."""
        with patch("pugmark._default_session") as mock_session:
            mock_session.metadata.return_value = {"key": "value"}

            result = pugmark.metadata()

            assert result == {"key": "value"}
            mock_session.metadata.assert_called_once()

    def test_session_metadata_immutability(self):
        """Test that returned metadata dict doesn't affect internal state."""
        metadata = {"original": "value"}
        session = pugmark.Session(io.StringIO(), io.StringIO(), metadata=metadata)

        # Get metadata and try to modify it
        returned_metadata = session.metadata()
        returned_metadata["new"] = "added"

        # Original should still be accessible (though dict is mutable)
        assert session.metadata()["original"] == "value"


class TestWSGIPugmarkMetadata:
    """Test WSGIPugmark HTTP handler metadata functionality."""

    def _make_environ(self, method="POST", path="/", query_string="", headers=None, body=""):
        """Helper to create a WSGI environ dict."""
        environ = {
            "REQUEST_METHOD": method,
            "PATH_INFO": path,
            "QUERY_STRING": query_string,
            "wsgi.input": io.BytesIO(body.encode("utf-8")),
            "wsgi.errors": io.StringIO(),
            "SERVER_NAME": "localhost",
            "SERVER_PORT": "8080",
        }
        if headers:
            for key, value in headers.items():
                # Convert header name to WSGI format (HTTP_X_HEADER_NAME)
                wsgi_key = f"HTTP_{key.upper().replace('-', '_')}"
                environ[wsgi_key] = value
        return environ

    def _call_wsgi(self, app, environ):
        """Helper to call WSGI app and capture response."""
        response_started = []
        response_body = []

        def start_response(status, headers):
            response_started.append((status, headers))
            return response_body.append

        result = app(environ, start_response)
        body = b"".join(result)
        return response_started[0][0], body

    def test_metadata_passed_via_http_header(self):
        """Test that metadata from HTTP header is passed to Session."""
        captured_session = []

        def handler(session):
            captured_session.append(session)

        app = WSGIPugmark(handler)
        metadata = {"user-id": "test-123", "tenant": "acme"}
        environ = self._make_environ(
            headers={SESSION_METADATA_HEADER: json.dumps(metadata)},
            query_string="agent=test-agent&session=test-session",
        )

        status, _ = self._call_wsgi(app, environ)

        assert status == "200 OK"
        assert len(captured_session) == 1
        assert captured_session[0].metadata() == metadata

    def test_metadata_empty_when_header_missing(self):
        """Test that metadata is empty when header is not present."""
        captured_session = []

        def handler(session):
            captured_session.append(session)

        app = WSGIPugmark(handler)
        environ = self._make_environ()

        status, _ = self._call_wsgi(app, environ)

        assert status == "200 OK"
        assert len(captured_session) == 1
        assert captured_session[0].metadata() == {}

    def test_invalid_json_metadata_returns_400(self):
        """Test that invalid JSON in metadata header returns 400 error."""

        def handler(session):
            pass  # Should never be called

        app = WSGIPugmark(handler)
        environ = self._make_environ(
            headers={SESSION_METADATA_HEADER: "invalid json {"},
        )

        status, body = self._call_wsgi(app, environ)

        assert status == "400 Bad Request"
        assert b"Invalid metadata header" in body

    def test_session_receives_all_params_with_metadata(self):
        """Test that Session receives agent, session_id, snapshot, and metadata."""
        captured_session = []

        def handler(session):
            captured_session.append(session)

        app = WSGIPugmark(handler)
        metadata = {"key": "value"}
        environ = self._make_environ(
            headers={SESSION_METADATA_HEADER: json.dumps(metadata)},
            query_string="agent=my-agent&session=my-session-id&snapshot=42",
        )

        status, _ = self._call_wsgi(app, environ)

        assert status == "200 OK"
        assert len(captured_session) == 1
        session = captured_session[0]
        assert session.agent() == "my-agent"
        assert session.session_id() == "my-session-id"
        assert session.snapshot() == 42
        assert session.metadata() == {"key": "value"}


class TestRemoteOutput:
    """Tests for remote object URI output support."""

    def test_output_uri_field(self):
        """Test that Output accepts a uri field."""
        output = Output(uri="s3://bucket/key", name="result")
        assert output.uri == "s3://bucket/key"
        assert output.name == "result"
        assert output.data == b""

    def test_output_uri_and_data_allowed(self):
        """Test that setting both uri and data is allowed (data takes precedence)."""
        output = Output(uri="s3://bucket/key", data=b"inline wins")
        assert output.uri == "s3://bucket/key"
        assert output.data == b"inline wins"

    def test_writer_write_remote(self):
        """Test that Writer.write_remote emits the correct JSON with uri field."""
        stream = io.StringIO()
        writer = Writer(stream)

        writer.write_remote(
            "s3://bucket/path/to/object",
            name="result.json",
            content_type="application/json",
        )

        output = stream.getvalue().strip()
        data = json.loads(output)

        assert data["uri"] == "s3://bucket/path/to/object"
        assert data["name"] == "result.json"
        assert data["content-type"] == "application/json"
        assert "data" not in data

    def test_writer_write_remote_minimal(self):
        """Test that write_remote with only a URI emits just the uri field."""
        stream = io.StringIO()
        writer = Writer(stream)

        writer.write_remote("gs://my-bucket/obj.bin")

        data = json.loads(stream.getvalue().strip())
        assert data == {"uri": "gs://my-bucket/obj.bin"}

    def test_writer_write_remote_with_metadata(self):
        """Test that write_remote serializes optional fields correctly."""
        stream = io.StringIO()
        writer = Writer(stream)

        writer.write_remote(
            "s3://bucket/key",
            name="file.csv",
            content_type="text/csv",
            schema_url="https://schema.example.com/v1",
            metadata={"source": "server"},
        )

        data = json.loads(stream.getvalue().strip())
        assert data["uri"] == "s3://bucket/key"
        assert data["name"] == "file.csv"
        assert data["content-type"] == "text/csv"
        assert data["schema-url"] == "https://schema.example.com/v1"
        assert data["metadata"] == {"source": "server"}

    def test_module_write_remote(self):
        """Test that the module-level write_remote delegates to the default session."""
        with patch.object(pugmark._default_session, "write_remote") as mock_write:
            pugmark.write_remote("s3://bucket/key", name="result", content_type="text/plain")
            mock_write.assert_called_once_with(
                "s3://bucket/key",
                name="result",
                content_type="text/plain",
                content_encoding="",
                schema_url="",
                metadata=None,
                session="",
            )

    def test_output_data_still_works(self):
        """Ensure existing inline-data output is unchanged after adding uri field."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(data=b"hello", content_type="text/plain")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        data = json.loads(stream.getvalue().strip())
        assert base64.b64decode(data["data"]) == b"hello"
        assert "uri" not in data

    def test_writer_data_wins_when_both_set(self):
        """When both data and uri are set on Output, write() emits the inline data."""
        stream = io.StringIO()
        writer = Writer(stream)

        output = Output(data=b"inline wins", uri="s3://bucket/ignored", content_type="text/plain")
        local_obj = pugmark.LocalObject(output)
        writer.write(local_obj)

        data = json.loads(stream.getvalue().strip())
        # The inline data must be present and the URI must NOT appear.
        assert base64.b64decode(data["data"]) == b"inline wins"
        assert "uri" not in data


class TestWriteHelpers:
    """Test the convenience write signatures and explicit write_text/json/bytes helpers."""

    def _written(self, output_stream):
        return json.loads(output_stream.getvalue().strip())

    def test_write_str_defaults_to_text_plain(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write("hello", name="greeting")
        data = self._written(out)
        assert data["name"] == "greeting"
        assert data["content-type"] == "text/plain"
        assert base64.b64decode(data["data"]) == b"hello"

    def test_write_dict_defaults_to_application_json(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write({"answer": 42}, name="reply")
        data = self._written(out)
        assert data["content-type"] == "application/json"
        assert json.loads(base64.b64decode(data["data"])) == {"answer": 42}

    def test_write_list_defaults_to_application_json(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write([1, 2, 3])
        data = self._written(out)
        assert data["content-type"] == "application/json"
        assert json.loads(base64.b64decode(data["data"])) == [1, 2, 3]

    def test_write_bytes_defaults_to_octet_stream(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write(b"\x00\x01\x02", name="bin")
        data = self._written(out)
        assert data["content-type"] == "application/octet-stream"
        assert base64.b64decode(data["data"]) == b"\x00\x01\x02"

    def test_write_object_passes_through(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        obj = pugmark.LocalObject(Output(data=b"raw", content_type="text/markdown"))
        session.write(obj)
        data = self._written(out)
        assert data["content-type"] == "text/markdown"

    def test_write_content_type_override(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write("# Hello", name="readme", content_type="text/markdown")
        data = self._written(out)
        assert data["content-type"] == "text/markdown"
        assert base64.b64decode(data["data"]) == b"# Hello"

    def test_write_unsupported_type_raises(self):
        session = pugmark.Session(io.StringIO(), io.StringIO())
        with pytest.raises(TypeError):
            session.write(object())

    def test_write_text_helper(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write_text("hello", name="greeting")
        data = self._written(out)
        assert data["content-type"] == "text/plain"
        assert base64.b64decode(data["data"]) == b"hello"

    def test_write_json_helper(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write_json({"k": "v"})
        data = self._written(out)
        assert data["content-type"] == "application/json"
        assert json.loads(base64.b64decode(data["data"])) == {"k": "v"}

    def test_write_bytes_helper(self):
        out = io.StringIO()
        session = pugmark.Session(io.StringIO(), out)
        session.write_bytes(b"abc")
        data = self._written(out)
        assert data["content-type"] == "application/octet-stream"
        assert base64.b64decode(data["data"]) == b"abc"


class TestLoadHelpers:
    """Test load_text, load_json, load_bytes."""

    def _session_with_state(self, name, data, content_type):
        session = pugmark.Session(io.StringIO(), io.StringIO())
        output = Output(data=data, name=name, content_type=content_type)
        session._state.append(pugmark.LocalObject(output))
        return session

    def test_load_text(self):
        session = self._session_with_state("greeting", b"hello", "text/plain")
        assert session.load_text("greeting") == "hello"

    def test_load_text_missing(self):
        session = pugmark.Session(io.StringIO(), io.StringIO())
        assert session.load_text("missing") is None

    def test_load_json(self):
        session = self._session_with_state("reply", b'{"answer": 42}', "application/json")
        assert session.load_json("reply") == {"answer": 42}

    def test_load_json_missing(self):
        session = pugmark.Session(io.StringIO(), io.StringIO())
        assert session.load_json("missing") is None

    def test_load_bytes(self):
        session = self._session_with_state("bin", b"\x00\x01", "application/octet-stream")
        assert session.load_bytes("bin") == b"\x00\x01"

    def test_load_bytes_missing(self):
        session = pugmark.Session(io.StringIO(), io.StringIO())
        assert session.load_bytes("missing") is None
