"""Tests for HTTP request body handling."""

import io

from pugmark.http import _get_request_body


class TestGetRequestBody:
    def test_with_content_length(self) -> None:
        body = b"test body content"
        environ = {
            "CONTENT_LENGTH": str(len(body)),
            "wsgi.input": io.BytesIO(body),
        }
        result = _get_request_body(environ)
        assert result == "test body content"

    def test_with_empty_content_length(self) -> None:
        body = b"fallback body"
        environ = {
            "CONTENT_LENGTH": "",
            "wsgi.input": io.BytesIO(body),
        }
        result = _get_request_body(environ)
        assert result == "fallback body"

    def test_no_content_length_reads_all(self) -> None:
        body = b"plain body"
        environ = {
            "wsgi.input": io.BytesIO(body),
        }
        result = _get_request_body(environ)
        assert result == "plain body"

    def test_json_body(self) -> None:
        body = b'{"session": "data", "key": 123}'
        environ = {
            "CONTENT_LENGTH": str(len(body)),
            "wsgi.input": io.BytesIO(body),
        }
        result = _get_request_body(environ)
        assert result == '{"session": "data", "key": 123}'
