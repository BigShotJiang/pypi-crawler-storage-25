#!/usr/bin/env python3
"""
Tests for pugmark.protoipc functionality.
"""

from google.protobuf import any_pb2, descriptor_pb2

import pugmark
from pugmark import protoipc


def test_basic_imports():
    """Test that all required imports work."""
    # This test passes if the imports above work
    assert hasattr(protoipc, "scan_messages")
    assert hasattr(protoipc, "push_message")
    assert hasattr(protoipc, "Session")


def test_scan_messages_empty_state():
    """Test scan_messages with empty state."""
    state = pugmark.State()
    messages = list(protoipc.scan_messages(state))
    assert len(messages) == 0


def test_push_and_scan_messages():
    """Test pushing and then scanning protobuf messages."""
    # Create a test state and use state.append as write function
    test_state = pugmark.State()

    # Test 1: Push a descriptor proto message
    desc_proto = descriptor_pb2.DescriptorProto()
    desc_proto.name = "TestMessage"

    protoipc.push_message(msg=desc_proto, state=test_state, types=None, write=test_state.append)

    # Test 2: Push an Any message
    any_content = any_pb2.Any()
    any_content.type_url = "type.googleapis.com/test.CustomMessage"
    any_content.value = b"test_data"

    protoipc.push_message(msg=any_content, state=test_state, types=None, write=test_state.append)

    # Verify objects were written to state
    assert len(test_state._list) == 2

    # Verify the written objects have correct properties
    desc_obj = test_state._list[0]
    assert desc_obj.content_type() == "application/protobuf"
    assert desc_obj.schema_url() == "type.googleapis.com/google.protobuf.DescriptorProto"

    any_obj = test_state._list[1]
    assert any_obj.content_type() == "application/protobuf"
    assert any_obj.schema_url() == "type.googleapis.com/google.protobuf.Any"

    # Scan messages (objects are already in state)
    # Note: DescriptorProto messages are registered, not yielded, so we only get the Any message
    scanned_messages = list(protoipc.scan_messages(state=test_state))
    assert len(scanned_messages) == 1

    # Verify message types - only Any message should be returned
    message_types = [type(msg).__name__ for msg in scanned_messages]
    assert "Any" in message_types
    # DescriptorProto should not be in the results as it's registered, not yielded
    assert "DescriptorProto" not in message_types

    # Verify Any message content
    any_messages = [msg for msg in scanned_messages if isinstance(msg, any_pb2.Any)]
    assert len(any_messages) == 1
    assert any_messages[0].type_url == "type.googleapis.com/test.CustomMessage"
    assert any_messages[0].value == b"test_data"


def test_push_message_with_defaults():
    """Test push_message function with default parameters."""
    # Create a simple message
    desc_proto = descriptor_pb2.DescriptorProto()
    desc_proto.name = "DefaultsTest"

    # Test with minimal parameters (provide state to avoid stdin reading)
    test_state = pugmark.State()
    protoipc.push_message(desc_proto, state=test_state, write=test_state.append)

    assert len(test_state._list) == 1
    obj = test_state._list[0]
    assert obj.content_type() == "application/protobuf"
    assert obj.schema_url() == "type.googleapis.com/google.protobuf.DescriptorProto"


def test_scan_messages_with_unknown_type():
    """Test scan_messages skips objects with unknown message types."""
    test_state = pugmark.State()

    # Create an object with unknown schema URL
    output = pugmark.Output(
        data=b"dummy_data",
        name="",
        content_type="application/protobuf",
        content_encoding="",
        schema_url="type.googleapis.com/unknown.MessageType",
        metadata={},
    )
    obj = pugmark.LocalObject(output)
    test_state.append(obj)

    # Should skip unknown types
    messages = list(protoipc.scan_messages(test_state))
    assert len(messages) == 0


def test_scan_messages_skips_non_protobuf():
    """Test scan_messages skips non-protobuf objects."""
    test_state = pugmark.State()

    # Create a non-protobuf object
    output = pugmark.Output(
        data=b"some text data",
        name="",
        content_type="text/plain",
        content_encoding="",
        schema_url="",
        metadata={},
    )
    obj = pugmark.LocalObject(output)
    test_state.append(obj)

    # Should skip non-protobuf objects
    messages = list(protoipc.scan_messages(test_state))
    assert len(messages) == 0


def test_push_message_with_any_handling():
    """Test that push_message properly handles Any messages with inner types."""
    test_state = pugmark.State()

    # Create an Any message containing a DescriptorProto
    desc_proto = descriptor_pb2.DescriptorProto()
    desc_proto.name = "InnerMessage"

    any_msg = any_pb2.Any()
    any_msg.type_url = "type.googleapis.com/google.protobuf.DescriptorProto"
    any_msg.value = desc_proto.SerializeToString()

    # Push the Any message
    protoipc.push_message(msg=any_msg, state=test_state, write=test_state.append)

    # Should have pushed the Any message
    assert len(test_state._list) >= 1

    # The last object should be the Any message itself
    last_obj = test_state._list[-1]
    assert last_obj.content_type() == "application/protobuf"
    assert last_obj.schema_url() == "type.googleapis.com/google.protobuf.Any"


def test_push_message_with_fork():
    """Test push_message with fork=True creates objects with fork=True."""
    test_state = pugmark.State()

    # Create a test message
    desc_proto = descriptor_pb2.DescriptorProto()
    desc_proto.name = "ForkTestMessage"

    # Push as fork message
    protoipc.push_message(msg=desc_proto, state=test_state, write=test_state.append, fork=True)

    # Should have pushed the message
    assert len(test_state._list) == 1

    # The object should be marked as a fork
    obj = test_state._list[0]
    assert obj.content_type() == "application/protobuf"
    assert obj.schema_url() == "type.googleapis.com/google.protobuf.DescriptorProto"
    assert obj.fork() is True


def test_push_message_not_fork():
    """Test that regular push_message creates objects with fork=False."""
    test_state = pugmark.State()

    # Create a test message
    desc_proto = descriptor_pb2.DescriptorProto()
    desc_proto.name = "NotForkMessage"

    # Push as regular message
    protoipc.push_message(msg=desc_proto, state=test_state, write=test_state.append)

    # Should have pushed the message
    assert len(test_state._list) == 1

    # The object should NOT be marked as a fork
    obj = test_state._list[0]
    assert obj.fork() is False


def test_session_push_message_with_fork():
    """Test Session.push_message with fork=True."""
    import io

    # Create a session with custom streams (need both reader and writer)
    input_stream = io.StringIO("")  # Empty input
    output_stream = io.StringIO()
    pugmark_session = pugmark.Session(reader_stream=input_stream, writer_stream=output_stream)
    session = protoipc.Session(pugmark_session)

    # Create a test message
    any_msg = any_pb2.Any()
    any_msg.type_url = "type.googleapis.com/test.ForkMessage"
    any_msg.value = b"fork_data"

    # Push as fork message using push_message with fork=True
    session.push_message(any_msg, fork=True)

    # Verify output contains fork flag
    output_stream.seek(0)
    import json

    lines = output_stream.getvalue().strip().split("\n")
    # Last line should be the fork message
    last_line = lines[-1]
    parsed = json.loads(last_line)
    assert parsed.get("fork") is True
    assert parsed.get("content-type") == "application/protobuf"
    assert parsed.get("schema-url") == "type.googleapis.com/google.protobuf.Any"
