import json
import os
import socket
from contextvars import Token
from io import StringIO
from typing import Dict, Iterable, List, Optional, Protocol, Tuple
from urllib.parse import parse_qs
from wsgiref.simple_server import WSGIRequestHandler, WSGIServer
from wsgiref.types import StartResponse, WSGIEnvironment

from pugmark import Session

# Environment variable set by pugmark CLI with the RPC URL (e.g., "fd://3" for socket on FD 3)
PUGMARK_RPC_URL_ENV = "PUGMARK_RPC_URL"

# HTTP header name for session metadata (must match Go constant)
SESSION_METADATA_HEADER = "X-Pugmark-Session-Metadata"

# Optional OpenTelemetry imports for trace context propagation
try:
    from opentelemetry import context as otel_context
    from opentelemetry import propagate as otel_propagate

    _HAS_OTEL = True
except ImportError:
    _HAS_OTEL = False


def _make_response(body: str, status_code: int, start_response: StartResponse) -> Iterable[bytes]:
    """Create a WSGI response with the given body and status code."""
    status_map = {
        200: "200 OK",
        400: "400 Bad Request",
        404: "404 Not Found",
        405: "405 Method Not Allowed",
    }
    status = status_map.get(status_code, f"{status_code} Unknown")
    body_bytes = body.encode("utf-8")
    headers: List[Tuple[str, str]] = [
        ("Content-Type", "text/plain; charset=utf-8"),
        ("Content-Length", str(len(body_bytes))),
    ]
    start_response(status, headers)
    return [body_bytes]


def _get_query_param(environ: WSGIEnvironment, key: str, default: str = "") -> str:
    """Get a query parameter from the WSGI environ."""
    query_string = environ.get("QUERY_STRING", "")
    params = parse_qs(query_string)
    values = params.get(key, [default])
    return values[0] if values else default


def _get_header(environ: WSGIEnvironment, header_name: str, default: str = "") -> str:
    """Get an HTTP header from the WSGI environ."""
    # WSGI converts headers to HTTP_<UPPERCASE_NAME> format
    wsgi_key = "HTTP_" + header_name.upper().replace("-", "_")
    return environ.get(wsgi_key, default)


def _extract_headers(environ: WSGIEnvironment) -> Dict[str, str]:
    """Extract all HTTP headers from the WSGI environ as lowercase key-value pairs."""
    headers = {}
    for key, value in environ.items():
        if key.startswith("HTTP_"):
            # Convert HTTP_X_HEADER to x-header
            header_name = key[5:].lower().replace("_", "-")
            headers[header_name] = value
    return headers


def _get_request_body(environ: WSGIEnvironment) -> str:
    """Read the request body from the WSGI environ.

    The pugmark Go client always sends Content-Length, so we can simply read
    the specified number of bytes. This avoids issues with chunked transfer
    encoding on wsgiref (Python's stdlib WSGI server).
    """
    content_length = environ.get("CONTENT_LENGTH", "")
    if content_length:
        length = int(content_length)
        return environ["wsgi.input"].read(length).decode("utf-8")

    # Fallback for requests without Content-Length (shouldn't happen with pugmark client)
    return environ["wsgi.input"].read().decode("utf-8")


class Handler(Protocol):
    def __call__(self, session: Session): ...


class WSGIPugmark:
    def __init__(self, handler: Handler):
        self.handler = handler

    def __call__(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
        path = environ.get("PATH_INFO", "/")
        method = environ.get("REQUEST_METHOD", "GET")

        if path == "/" or path == "":
            if method == "GET":
                return self.handle_health(start_response)
            elif method == "POST":
                return self.handle_run(environ, start_response)
            else:
                return _make_response("Method Not Allowed", 405, start_response)
        else:
            return _make_response("Not Found", 404, start_response)

    def handle_run(
        self, environ: WSGIEnvironment, start_response: StartResponse
    ) -> Iterable[bytes]:
        # Extract trace context from HTTP headers for distributed tracing
        ctx_token: Optional[Token[object]] = None
        if _HAS_OTEL:
            # Use lowercase keys for W3C trace context propagator compatibility.
            # HTTP headers are case-insensitive, but dict lookup is case-sensitive,
            # and the W3C propagator looks for lowercase "traceparent"/"tracestate".
            carrier = _extract_headers(environ)
            ctx = otel_propagate.extract(carrier)
            ctx_token = otel_context.attach(ctx)

        try:
            # Extract params from query string (sent by Go RPC client)
            agent = _get_query_param(environ, "agent", "")
            session_id = _get_query_param(environ, "session", "")
            snapshot_str = _get_query_param(environ, "snapshot", "")
            snapshot = int(snapshot_str) if snapshot_str else None

            # Extract metadata from HTTP header (JSON-encoded)
            metadata: Optional[Dict[str, str]] = None
            metadata_header = _get_header(environ, SESSION_METADATA_HEADER, "")
            if metadata_header:
                try:
                    metadata = json.loads(metadata_header)
                except json.JSONDecodeError:
                    return _make_response(
                        "Invalid metadata header: malformed JSON", 400, start_response
                    )

            input_data = _get_request_body(environ)
            input_stream = StringIO(input_data)
            output_stream = StringIO()
            session = Session(
                reader_stream=input_stream,
                writer_stream=output_stream,
                agent=agent if agent else None,
                session_id=session_id if session_id else None,
                snapshot=snapshot,
                metadata=metadata,
            )
            with session.traced_execution():
                self.handler(session)
            return _make_response(output_stream.getvalue(), 200, start_response)
        finally:
            # Detach context when request completes
            if ctx_token is not None:
                otel_context.detach(ctx_token)

    def handle_health(self, start_response: StartResponse) -> Iterable[bytes]:
        return _make_response("OK", 200, start_response)


def serve(app: WSGIPugmark, host: str = "127.0.0.1", port: int = 0) -> None:
    """Serve a WSGI app, automatically using a pre-created socket if available.

    If the PUGMARK_RPC_URL environment variable is set to a fd:// URL (e.g., "fd://3"),
    the app is served using the socket passed from the pugmark CLI on that file descriptor.
    Otherwise, a new socket is created and bound to the specified host and port.

    Args:
        app: The WSGI application to serve (typically a WSGIPugmark instance)
        host: Host to bind to if creating a new socket (default: 127.0.0.1)
        port: Port to bind to if creating a new socket (default: 0 for auto-assign)

    Example:
        from pugmark.http import WSGIPugmark, serve
        from pugmark import Session

        def handler(session: Session):
            for event in session.read():
                pass

        serve(WSGIPugmark(handler))
    """
    rpc_url = os.environ.get(PUGMARK_RPC_URL_ENV, "")
    if rpc_url.startswith("fd://"):
        fd = int(rpc_url[5:])
        serve_from_fd(app, fd)
    else:
        server = WSGIServer((host, port), WSGIRequestHandler)
        server.set_app(app)
        server.serve_forever()


# Default file descriptor for the listening socket passed from Go.
# This is FD 3 because stdin=0, stdout=1, stderr=2, and ExtraFiles[0]=3.
_DEFAULT_LISTEN_FD = 3


def serve_from_fd(app: WSGIPugmark, fd: int = _DEFAULT_LISTEN_FD) -> None:
    """Serve a WSGI app using a socket passed as a file descriptor.

    This function is designed to work with the pugmark Go CLI when it starts
    a Python subprocess in RPC mode. The Go process creates a listening TCP
    socket and passes it to the subprocess as file descriptor 3.

    Args:
        app: The WSGI application to serve (typically a WSGIPugmark instance)
        fd: File descriptor number (default 3, standard for ExtraFiles[0])

    Example:
        from pugmark.http import WSGIPugmark, serve_from_fd
        from pugmark import Session

        def handler(session: Session):
            for event in session.read():
                pass

        serve_from_fd(WSGIPugmark(handler))
    """
    # Get socket from file descriptor
    # The socket is already listening (bound and listen() called by Go)
    sock = socket.fromfd(fd, socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Get the address the socket is bound to
    server_address = sock.getsockname()

    # Create WSGI server without binding (socket is already bound)
    server = WSGIServer(server_address, WSGIRequestHandler, bind_and_activate=False)
    server.socket = sock
    # Manually set server_name and server_port (normally done by server_bind)
    server.server_name, server.server_port = server_address[0], server_address[1]
    server.setup_environ()  # Required to initialize base_environ for WSGI
    server.set_app(app)

    # Serve requests
    server.serve_forever()
