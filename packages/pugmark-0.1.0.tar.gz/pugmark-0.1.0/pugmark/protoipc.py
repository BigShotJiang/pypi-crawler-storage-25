"""
Package protoipc provides a high-level interface for encoding and decoding
protobuf messages in pugmark sessions. It wraps the low-level pugmark ipc
package to provide convenient functions for working with protocol buffer
messages.

The package supports automatic descriptor management, message type
resolution, and follows the protobuf Any type URL convention with
"type.googleapis.com/" prefixes for schema URLs.

Basic usage:

    import pugmark
    from pugmark import protoipc

    # Scan protobuf messages from a session to reconstruct the program state
    for msg in protoipc.scan_messages():
        # Process each message
        if isinstance(msg, MyMessage):
            # Handle MyMessage
            pass

    # Push new protobuf message to a session to save the updated state
    msg = MyMessage(field="value")
    protoipc.push_message(msg)

The push_* and scan_* functions handle all the complexity of descriptor
management and type registration automatically. They use the global protobuf
type registry and maintain a shared descriptor cache for optimal performance.
"""

from typing import Callable, Dict, Iterator, Optional, cast

try:
    from google.protobuf import (
        any_pb2,
        descriptor_pb2,
        message,
        message_factory,
        symbol_database,
    )
    from google.protobuf.descriptor import FileDescriptor
except ImportError as e:
    raise ImportError(
        "protobuf library is required for protoipc functionality. "
        "Install it with: pip install protobuf>=4.0.0"
    ) from e

from . import LocalObject, Object, Output, State
from . import Session as PugmarkSession
from . import state as pugmark_state
from . import write as pugmark_write


def _full_name_from_schema_url(schema_url: str) -> str:
    """Extract the full message name from a schema URL.

    Args:
        schema_url: Schema URL in format "type.googleapis.com/fully.qualified.MessageName"

    Returns:
        The fully qualified message name
    """
    if "/" in schema_url:
        return schema_url.split("/")[-1]
    return schema_url


def scan_messages(
    state: Optional[State] = None,
    types: Optional[symbol_database.SymbolDatabase] = None,
) -> Iterator[message.Message]:
    """
    Scan protobuf messages from the session state.

    This function filters objects to only process those with:
    - ContentType of "application/protobuf"
    - A non-empty SchemaURL

    Schema URLs are expected to follow the protobuf Any type URL convention:
    "type.googleapis.com/fully.qualified.MessageName". The function strips the
    "type.googleapis.com/" prefix when looking up message types in the
    registry.

    The function automatically handles:
    - Message type resolution using well-known protobuf types
    - Protobuf message unmarshaling

    Args:
        state: The pugmark State to scan. Defaults to pugmark.state()
        types: The protobuf type registry. Defaults to the global symbol database

    Yields:
        Decoded protobuf Message instances

    Raises:
        Exception: On unknown message types, unmarshaling errors, or I/O errors
    """
    if state is None:
        state = pugmark_state()
    if types is None:
        types = symbol_database.Default()

    # Map of well-known message types
    well_known_types = {
        "google.protobuf.FileDescriptorProto": descriptor_pb2.FileDescriptorProto,
        "google.protobuf.Any": any_pb2.Any,
    }

    for obj in state:
        if obj.content_type() != "application/protobuf":
            continue  # skip non-protobuf objects

        schema_url = obj.schema_url()
        if not schema_url:
            continue  # skip objects without schema URL

        full_name = _full_name_from_schema_url(schema_url)

        # Try to get message class from well-known types first
        message_class = well_known_types.get(full_name)

        if message_class is None:
            # Try to find the message type in the registry
            try:
                descriptor = types.pool.FindMessageTypeByName(full_name)
                factory = message_factory.MessageFactory(pool=types.pool)
                message_dict = factory.GetMessages([descriptor.file])  # type: ignore[attr-defined]
                message_class = message_dict.get(full_name)
                if message_class is None:
                    continue  # Could not create message class
            except Exception:
                # Message type not found in registry, skip this object
                continue

        # Read the object body
        data = obj.body()

        # Create and parse the message
        msg = message_class()
        try:
            msg.ParseFromString(data)
        except Exception as e:
            raise RuntimeError(f"Failed to parse protobuf message: {e}") from e

        # Handle file descriptor proto registration
        if full_name == "google.protobuf.FileDescriptorProto":
            # Register the file descriptor to the type registry for future use
            try:
                file_desc_proto = cast(descriptor_pb2.FileDescriptorProto, msg)
                types.pool.Add(file_desc_proto)
            except Exception:
                # If registration fails, continue without raising an error
                pass
            # Don't yield file descriptor protos, just register them
            continue

        yield msg


def push_message(
    msg: message.Message,
    state: Optional[State] = None,
    types: Optional[symbol_database.SymbolDatabase] = None,
    registered: Optional[set[str]] = None,
    write: Optional[Callable[[Object], None]] = None,
    *,
    fork: bool = False,
    session: str = "",
    metadata: Optional[Dict[str, str]] = None,
) -> None:
    """
    Push a protobuf message to the session.

    This function performs the following operations:
    1. Pushes the message's complete file descriptor (and any dependencies) if not cached
    2. Marshals the protobuf message to binary format
    3. Writes the message as an output with the appropriate schema URL

    Schema URLs follow the protobuf Any type URL convention:
    "type.googleapis.com/fully.qualified.MessageName"

    The function automatically handles:
    - File descriptor caching to avoid duplicate pushes
    - Recursive file descriptor dependencies for imported types
    - Well-known type detection (skips descriptors for google.protobuf.* types)
    - Complete protobuf file descriptor serialization with all imports

    Args:
        msg: The protobuf message to encode and push
        state: The pugmark State. Defaults to pugmark.state()
        types: The protobuf type registry. Defaults to the global symbol database
        registered: Set to track which file descriptors have already been pushed. Defaults to empty
        write: Function to write objects. Defaults to pugmark.write
        fork: Mark output as creating a child session (keyword-only)
        session: Route output to a different session (keyword-only)
        metadata: Add/merge metadata to the output (keyword-only)

    Raises:
        Exception: On file descriptor push failures, marshaling errors, or write failures
    """
    if state is None:
        state = pugmark_state()
    if types is None:
        types = symbol_database.Default()
    if registered is None:
        registered = set()
    if write is None:
        write = pugmark_write

    # Get message descriptor
    descriptor = msg.DESCRIPTOR
    full_name = descriptor.full_name

    # Push the file descriptor (with all its dependencies) if not already cached
    file_descriptor = descriptor.file
    if file_descriptor.name not in registered:
        _push_file_descriptor_recursive(file_descriptor, registered, write, types)

    # Marshal the message
    data = msg.SerializeToString()

    # Merge metadata if provided
    output_metadata = dict(metadata) if metadata else {}

    # Create and write the output object
    output = Output(
        data=data,
        name="",
        content_type="application/protobuf",
        content_encoding="",
        schema_url=f"type.googleapis.com/{full_name}",
        metadata=output_metadata if output_metadata else {},
        fork=fork,
        session=session,
    )
    obj = LocalObject(output)
    write(obj)


def _push_file_descriptor_recursive(
    file_descriptor: FileDescriptor,
    registered: set[str],
    write: Callable[[Object], None],
    types: symbol_database.SymbolDatabase,
) -> None:
    """
    Push a file descriptor recursively, handling all its dependencies.

    This pushes complete FileDescriptorProto objects with all imports resolved,
    which is what the Go protobuf reflection system expects.
    """
    if file_descriptor.name in registered:
        # Already processed
        return

    # Skip well-known types - they're built into the Go runtime
    if file_descriptor.name.startswith("google/protobuf/"):
        return

    # Mark as cached to avoid recursion
    registered.add(file_descriptor.name)

    # First, recursively push all dependencies
    for dep in file_descriptor.dependencies:
        if dep.name not in registered and not dep.name.startswith("google/protobuf/"):
            _push_file_descriptor_recursive(dep, registered, write, types)

    # Now push this file descriptor
    _push_file_descriptor(file_descriptor, write)


def _push_file_descriptor(
    file_descriptor: FileDescriptor,
    write: Callable[[Object], None],
) -> None:
    """
    Push a complete file descriptor to the session.

    This creates a FileDescriptorProto containing all message types, enums,
    services, and imports from the file.
    """
    # Create the FileDescriptorProto
    file_desc_proto = descriptor_pb2.FileDescriptorProto()
    file_descriptor.CopyToProto(file_desc_proto)
    data = file_desc_proto.SerializeToString()

    # Create and write the file descriptor object
    output = Output(
        data=data,
        name=file_descriptor.name,
        content_type="application/protobuf",
        content_encoding="",
        schema_url="type.googleapis.com/google.protobuf.FileDescriptorProto",
        metadata={
            "package": file_descriptor.package or "",
            "path": file_descriptor.name or "",
            "syntax": file_desc_proto.syntax or "proto3",
        },
    )
    obj = LocalObject(output)
    write(obj)


class Session:
    """
    Protobuf-aware pugmark session.

    Example:
        session = protoipc.Session()
        session.push_message(MyMessage(field="value1"))
        session.push_message(MyMessage(field="value2"))
    """

    def __init__(self, pugmark_session: Optional[PugmarkSession] = None):
        """
        Initialize a protobuf-aware session.

        Args:
            pugmark_session: Optional pugmark.Session to wrap. Creates a new one if None.
        """
        self.pugmark_session = pugmark_session or PugmarkSession()
        self._registered_file_descriptors: set[str] = {
            obj.name()
            for obj in self.pugmark_session.state()
            if obj.schema_url() == "type.googleapis.com/google.protobuf.FileDescriptorProto"
        }

    def push_message(
        self,
        msg: message.Message,
        types: Optional[symbol_database.SymbolDatabase] = None,
        *,
        fork: bool = False,
        session: str = "",
        metadata: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Push a protobuf message to this session with persistent caching.

        Args:
            msg: The protobuf message to encode and push
            types: The protobuf type registry. Defaults to the global symbol database
            fork: Mark output as creating a child session (keyword-only)
            session: Route output to a different session (keyword-only)
            metadata: Add/merge metadata to the output (keyword-only)
        """
        push_message(
            msg=msg,
            state=self.pugmark_session._state,
            types=types,
            registered=self._registered_file_descriptors,
            write=self.pugmark_session.write,
            fork=fork,
            session=session,
            metadata=metadata,
        )

    def scan_messages(
        self, types: Optional[symbol_database.SymbolDatabase] = None
    ) -> Iterator[message.Message]:
        """
        Scan protobuf messages from this session.

        Args:
            types: The protobuf type registry. Defaults to the global symbol database

        Yields:
            Decoded protobuf messages from the session
        """
        return scan_messages(state=self.pugmark_session.state(), types=types)
