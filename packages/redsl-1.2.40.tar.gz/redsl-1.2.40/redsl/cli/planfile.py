"""CLI commands for SUMR → planfile integration."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
import yaml


def _dump_json(data: Any) -> None:
    click.echo(json.dumps(data, indent=2, ensure_ascii=False, default=str))


@click.group("planfile")
def planfile_group() -> None:
    """SUMR.md → planfile.yaml task generation."""


@planfile_group.command("sync")
@click.argument(
    "project_path",
    type=click.Path(path_type=Path, exists=True, file_okay=False),
    default=".",
)
@click.option(
    "--sumr",
    "sumr_path",
    type=click.Path(path_type=Path, exists=True),
    default=None,
    help="Path to SUMR.md (default: PROJECT_PATH/SUMR.md)",
)
@click.option(
    "--dry-run/--no-dry-run",
    default=False,
    help="Print tasks without writing planfile.yaml",
)
@click.option(
    "--no-merge/--merge",
    "no_merge",
    default=False,
    help="Overwrite planfile.yaml completely (default: merge, preserve in_progress/done)",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json", "yaml"]),
    default="text",
    show_default=True,
)
def planfile_sync(
    project_path: Path,
    sumr_path: Path | None,
    dry_run: bool,
    no_merge: bool,
    output_format: str,
) -> None:
    """Generate or update planfile.yaml from SUMR.md.

    Reads the SUMR.md (and any refactor_plan.yaml / *.toon.yaml) in
    PROJECT_PATH and writes structured tasks to planfile.yaml.

    \b
    Examples:
      redsl planfile sync .
      redsl planfile sync /path/to/code2docs --dry-run
      redsl planfile sync . --format json
    """
    from redsl.commands.sumr_planfile import generate_planfile

    try:
        result = generate_planfile(
            project_path,
            dry_run=dry_run,
            merge=not no_merge,
            sumr_path=sumr_path,
        )
    except Exception as exc:
        raise click.ClickException(str(exc)) from exc

    if not result.tasks:
        click.echo("No refactoring tasks found. Check SUMR.md or *.toon.yaml files.", err=True)
        return

    if output_format == "json":
        _dump_json({
            "project": str(result.project_path),
            "planfile": str(result.planfile_path),
            "written": result.written,
            "dry_run": result.dry_run,
            "sources": result.sources,
            "task_count": len(result.tasks),
            "tasks": [t.to_dict() for t in result.tasks],
        })
        return

    if output_format == "yaml":
        click.echo(yaml.safe_dump(
            {
                "project": str(result.project_path),
                "tasks": [t.to_dict() for t in result.tasks],
            },
            sort_keys=False,
            allow_unicode=True,
        ))
        return

    # text output
    todo = [t for t in result.tasks if t.status == "todo"]
    done = [t for t in result.tasks if t.status == "done"]

    click.echo(f"Project:  {result.project_path.name}")
    click.echo(f"Sources:  {', '.join(result.sources) or '(none)'}")
    click.echo(f"Tasks:    {len(result.tasks)} total, {len(todo)} todo, {len(done)} done")
    if result.dry_run:
        click.echo("Mode:     dry-run (planfile.yaml NOT written)")
    else:
        click.echo(f"Output:   {result.planfile_path}")
    click.echo("")

    _PRIORITY_ICON = {1: "🔴", 2: "🟠", 3: "🟡", 4: "🟢"}
    for t in sorted(result.tasks, key=lambda x: (x.priority, x.id)):
        icon = _PRIORITY_ICON.get(t.priority, "⚪")
        status_marker = "✓" if t.status == "done" else " "
        click.echo(f"  [{status_marker}] {icon} [{t.id}] {t.title}")
        if t.file:
            click.echo(f"        file: {t.file}")
        if t.description:
            desc = t.description[:80] + ("…" if len(t.description) > 80 else "")
            click.echo(f"        {desc}")

    if result.written:
        click.echo(f"\n✓ planfile.yaml written ({len(result.tasks)} tasks)")
    elif result.dry_run:
        click.echo(f"\n(dry-run) Would write {len(result.tasks)} tasks to {result.planfile_path}")


@planfile_group.command("show")
@click.argument(
    "project_path",
    type=click.Path(path_type=Path, exists=True, file_okay=False),
    default=".",
)
@click.option(
    "--status",
    type=click.Choice(["todo", "in_progress", "done", "all"]),
    default="todo",
    show_default=True,
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
    show_default=True,
)
def planfile_show(project_path: Path, status: str, output_format: str) -> None:
    """Show tasks from an existing planfile.yaml."""
    planfile = Path(project_path) / "planfile.yaml"
    if not planfile.exists():
        raise click.ClickException(
            f"planfile.yaml not found at {planfile}. Run: redsl planfile sync {project_path}"
        )

    content = planfile.read_text(encoding="utf-8")
    # Split header from tasks section
    if "\ntasks:" in content:
        tasks_raw = yaml.safe_load("tasks:" + content.split("\ntasks:", 1)[1])
        tasks = (tasks_raw or {}).get("tasks", [])
    else:
        data = yaml.safe_load(content)
        tasks = (data or {}).get("tasks", [])

    if status != "all":
        tasks = [t for t in tasks if isinstance(t, dict) and t.get("status") == status]

    if output_format == "json":
        _dump_json({"planfile": str(planfile), "tasks": tasks})
        return

    if not tasks:
        click.echo(f"No tasks with status={status!r}")
        return

    _PRIORITY_ICON = {1: "🔴", 2: "🟠", 3: "🟡", 4: "🟢"}
    for t in sorted(tasks, key=lambda x: (x.get("priority", 3), x.get("id", ""))):
        if not isinstance(t, dict):
            continue
        icon = _PRIORITY_ICON.get(t.get("priority", 3), "⚪")
        click.echo(f"{icon} [{t.get('id','?')}] {t.get('title','?')}")
        click.echo(f"     status={t.get('status')}  effort={t.get('effort')}  action={t.get('action')}")
        if t.get("file"):
            click.echo(f"     file: {t['file']}")


def register(cli_group: "click.Group") -> None:
    cli_group.add_command(planfile_group)
