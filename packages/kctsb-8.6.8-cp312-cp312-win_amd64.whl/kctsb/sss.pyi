"""Type stubs for ``kctsb.sss`` — Shamir's Secret Sharing over GF(2^8).

Byte-wise (t,n) threshold secret sharing. Typical uses:

* Splitting ``k_tee`` across user devices for zero-state recovery.
* Distributing FHE secret keys across MPC parties.
"""
from __future__ import annotations

__all__: list[str]


class Share:
    """A single Shamir share: ``(index, data)``.

    Attributes
    ----------
    index : int
        1-based share identifier (``1 <= index <= 255``).
    data : bytes
        Share payload, same length as the original secret.
    """
    index: int
    data: bytes

    def __init__(self, index: int, data: bytes) -> None: ...


class ShamirSSS:
    """Shamir's (t,n) Secret Sharing over GF(2^8).

    Splits a byte string into ``n`` shares such that any ``t`` of them
    suffice to recover the secret, while ``t-1`` shares yield no
    information.

    Examples
    --------
    >>> from kctsb.sss import ShamirSSS
    >>> sss = ShamirSSS(threshold=2, num_shares=3)
    >>> shares = sss.split(b"my secret payload..............." )
    >>> len(shares)
    3
    >>> recovered = sss.combine([shares[0], shares[2]])
    >>> recovered == b"my secret payload..............."
    True
    """

    threshold: int
    num_shares: int

    def __init__(self, threshold: int, num_shares: int) -> None:
        """Create a Shamir SSS scheme.

        Parameters
        ----------
        threshold : int
            Minimum number of shares to recover the secret (``t``).
        num_shares : int
            Total shares to generate (``n >= t``).
        """

    def split(self, secret: bytes) -> list[Share]:
        """Split a secret into ``num_shares`` shares.

        Parameters
        ----------
        secret : bytes
            Secret data of any length.

        Returns
        -------
        list[Share]
            Fresh shares; randomized polynomial coefficients used.
        """

    def combine(self, shares: list[Share]) -> bytes:
        """Recover the secret from ``>= threshold`` shares.

        Parameters
        ----------
        shares : list[Share]
            At least ``threshold`` shares with distinct indices.

        Returns
        -------
        bytes
            The original secret.
        """
