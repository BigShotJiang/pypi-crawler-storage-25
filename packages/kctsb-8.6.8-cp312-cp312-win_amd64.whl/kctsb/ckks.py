"""
kctsb.ckks - CKKS Homomorphic Encryption Python Interface

Provides a high-level Pythonic API for CKKS approximate homomorphic encryption.
Wraps the C++ core evaluator with automatic parameter management, key lifecycle,
and numpy integration.

Architecture:
    CKKSContext (Python) → _kctsb_core.ckks.Context (C++ pybind11) → CKKSEvaluator (C++)

Usage:
    >>> from kctsb import CKKSContext
    >>> ctx = CKKSContext(poly_modulus_degree=8192, coeff_modulus_levels=5, scale_bits=40)
    >>> sk = ctx.keygen()
    >>> pk = ctx.public_key(sk)
    >>> rk = ctx.relin_key(sk)
    >>> pt = ctx.encode([1.0, 2.0, 3.0])
    >>> ct = ctx.encrypt(pk, pt)
    >>> ct_sum = ctx.add(ct, ct)
    >>> result = ctx.decrypt_decode(sk, ct_sum)
    >>> print(result[:3])  # [2.0, 4.0, 6.0]

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import logging
from typing import List, Optional, Union

import numpy as np

logger = logging.getLogger(__name__)

# Try importing compiled core; fall back to pure-Python stub for type hints
try:
    from ._kctsb_core import ckks as _core
    _HAS_CORE = True
    # Re-export low-level C++ classes/functions so users can call them via
    # `from kctsb import ckks; ckks.Context(...)` without going through `_kctsb_core`.
    Context = _core.Context
    Plaintext = _core.Plaintext
    Ciphertext = _core.Ciphertext
    SecretKey = _core.SecretKey
    PublicKey = _core.PublicKey
    RelinKey = _core.RelinKey
except ImportError:
    _HAS_CORE = False
    Context = None       # type: ignore[assignment]
    Plaintext = None     # type: ignore[assignment]
    Ciphertext = None    # type: ignore[assignment]
    SecretKey = None     # type: ignore[assignment]
    PublicKey = None     # type: ignore[assignment]
    RelinKey = None      # type: ignore[assignment]
    logger.warning(
        "kctsb C++ core not available. Build with KCTSB_BUILD_PYTHON=ON "
        "to enable full functionality."
    )


class CKKSContext:
    """High-level CKKS homomorphic encryption context.

    Manages CKKS parameters, key generation, encoding, encryption,
    homomorphic computation, and decryption in a single unified interface.

    Parameters
    ----------
    poly_modulus_degree : int
        Ring dimension n (power of 2). Larger → more secure & more slots,
        but slower. Typical: 4096, 8192, 16384.
    coeff_modulus_levels : int
        Number of RNS coefficient modulus primes. Determines the
        multiplicative depth available. Typical: 3-8.
    scale_bits : float
        Log₂ of the CKKS scaling factor. Controls encoding precision.
        Typical: 40.0 for 12 decimal digits.

    Attributes
    ----------
    slot_count : int
        Number of plaintext slots (n / 2).
    scale : float
        Default scaling factor (2^scale_bits).

    Examples
    --------
    >>> ctx = CKKSContext(8192, 5, 40.0)
    >>> ctx.slot_count
    4096
    """

    def __init__(
        self,
        poly_modulus_degree: int = 8192,
        coeff_modulus_levels: int = 5,
        scale_bits: float = 40.0,
    ) -> None:
        if not _HAS_CORE:
            raise RuntimeError(
                "kctsb C++ core is not available. "
                "Build with cmake -DKCTSB_BUILD_PYTHON=ON"
            )

        self._ctx = _core.Context(
            poly_modulus_degree=poly_modulus_degree,
            coeff_modulus_levels=coeff_modulus_levels,
            scale_bits=scale_bits,
        )
        self._poly_modulus_degree = poly_modulus_degree
        self._coeff_modulus_levels = coeff_modulus_levels
        self._scale_bits = scale_bits

        logger.info(
            "CKKSContext created: n=%d, L=%d, scale=2^%.1f, slots=%d",
            poly_modulus_degree, coeff_modulus_levels, scale_bits,
            self.slot_count,
        )

    @property
    def slot_count(self) -> int:
        """Number of plaintext slots (n / 2)."""
        return self._ctx.slot_count

    @property
    def poly_modulus_degree(self) -> int:
        """Ring dimension n."""
        return self._ctx.poly_modulus_degree

    @property
    def scale(self) -> float:
        """Default scaling factor."""
        return self._ctx.scale

    # ------------------------------------------------------------------ #
    # Key Generation
    # ------------------------------------------------------------------ #

    def keygen(self):
        """Generate a fresh CKKS secret key.

        Returns
        -------
        SecretKey
            Ternary secret key polynomial.
        """
        return self._ctx.keygen()

    def public_key(self, sk):
        """Derive a public key from a secret key.

        Parameters
        ----------
        sk : SecretKey
            Previously generated secret key.

        Returns
        -------
        PublicKey
        """
        return self._ctx.public_key(sk)

    def relin_key(self, sk):
        """Generate relinearization key.

        Parameters
        ----------
        sk : SecretKey

        Returns
        -------
        RelinKey
        """
        return self._ctx.relin_key(sk)

    # ------------------------------------------------------------------ #
    # Encoding / Decoding
    # ------------------------------------------------------------------ #

    def encode(self, values: Union[List[float], np.ndarray]):
        """Encode real numbers into a CKKS plaintext.

        Parameters
        ----------
        values : list[float] or np.ndarray
            Real-valued input. Length must be ≤ slot_count.

        Returns
        -------
        Plaintext
            Encoded polynomial.
        """
        if isinstance(values, np.ndarray):
            values = values.astype(float).tolist()
        return self._ctx.encode(values)

    def encode_single(self, value: float, scale: float = 0.0):
        """Encode a single real value (broadcast to all slots).

        Parameters
        ----------
        value : float
            Value to encode.
        scale : float, optional
            Encoding scale. If 0 (default), uses context's default
            scale (2^scale_bits).  Pass a ciphertext's ``.scale``
            when the plaintext will be used with ``add_plain`` on
            that ciphertext, to avoid scale mismatch.

        Returns
        -------
        Plaintext
        """
        return self._ctx.encode_single(float(value), float(scale))

    def decode(self, pt) -> np.ndarray:
        """Decode a plaintext to a numpy array of real numbers.

        Parameters
        ----------
        pt : Plaintext

        Returns
        -------
        np.ndarray
            Decoded real values, shape (slot_count,).
        """
        values = self._ctx.decode(pt)
        return np.array(values, dtype=np.float64)

    # ------------------------------------------------------------------ #
    # Encryption / Decryption
    # ------------------------------------------------------------------ #

    def encrypt(self, pk, pt):
        """Encrypt a plaintext with a public key.

        Parameters
        ----------
        pk : PublicKey
        pt : Plaintext

        Returns
        -------
        Ciphertext
        """
        return self._ctx.encrypt(pk, pt)

    def encrypt_symmetric(self, sk, pt):
        """Symmetric encryption using the secret key (faster).

        Parameters
        ----------
        sk : SecretKey
        pt : Plaintext

        Returns
        -------
        Ciphertext
        """
        return self._ctx.encrypt_symmetric(sk, pt)

    def decrypt(self, sk, ct):
        """Decrypt a ciphertext to a plaintext.

        Parameters
        ----------
        sk : SecretKey
        ct : Ciphertext

        Returns
        -------
        Plaintext
            Decrypted plaintext (needs decode() to get values).
        """
        return self._ctx.decrypt(sk, ct)

    def decrypt_decode(self, sk, ct) -> np.ndarray:
        """Decrypt and decode in one step.

        Parameters
        ----------
        sk : SecretKey
        ct : Ciphertext

        Returns
        -------
        np.ndarray
            Decrypted real values.
        """
        pt = self.decrypt(sk, ct)
        return self.decode(pt)

    # ------------------------------------------------------------------ #
    # Homomorphic Operations
    # ------------------------------------------------------------------ #

    def add(self, ct1, ct2):
        """Homomorphic addition: E(m1) + E(m2) → E(m1 + m2).

        Parameters
        ----------
        ct1 : Ciphertext
        ct2 : Ciphertext

        Returns
        -------
        Ciphertext
        """
        return self._ctx.add(ct1, ct2)

    def sub(self, ct1, ct2):
        """Homomorphic subtraction: E(m1) - E(m2) → E(m1 - m2).

        Parameters
        ----------
        ct1 : Ciphertext
        ct2 : Ciphertext

        Returns
        -------
        Ciphertext
        """
        return self._ctx.sub(ct1, ct2)

    def multiply(self, ct1, ct2, rk):
        """Homomorphic multiplication with relin + rescale.

        Parameters
        ----------
        ct1 : Ciphertext
        ct2 : Ciphertext
        rk : RelinKey

        Returns
        -------
        Ciphertext
            E(m1 · m2), relinearized and rescaled.
        """
        return self._ctx.multiply(ct1, ct2, rk)

    def multiply_plain(self, ct, pt):
        """Multiply ciphertext by plaintext: E(m) × p → E(m · p).

        Parameters
        ----------
        ct : Ciphertext
        pt : Plaintext

        Returns
        -------
        Ciphertext
        """
        return self._ctx.multiply_plain(ct, pt)

    def add_plain(self, ct, pt):
        """Add plaintext to ciphertext: E(m) + p → E(m + p).

        Parameters
        ----------
        ct : Ciphertext
        pt : Plaintext

        Returns
        -------
        Ciphertext
        """
        return self._ctx.add_plain(ct, pt)

    def rescale(self, ct):
        """Rescale ciphertext (reduce scale by one prime).

        Parameters
        ----------
        ct : Ciphertext

        Returns
        -------
        Ciphertext
        """
        return self._ctx.rescale(ct)

    # ------------------------------------------------------------------ #
    # Convenience: encode + encrypt
    # ------------------------------------------------------------------ #

    def encrypt_vector(self, pk, values: Union[List[float], np.ndarray]):
        """Encode and encrypt in one step.

        Parameters
        ----------
        pk : PublicKey
        values : list[float] or np.ndarray

        Returns
        -------
        Ciphertext
        """
        pt = self.encode(values)
        return self.encrypt(pk, pt)

    def __repr__(self) -> str:
        return (
            f"CKKSContext(n={self._poly_modulus_degree}, "
            f"L={self._coeff_modulus_levels}, "
            f"scale=2^{self._scale_bits:.0f}, "
            f"slots={self.slot_count})"
        )
