"""Type stubs for ``kctsb.core`` — runtime hardware capability detection.

Detects AES-NI / AVX2 / AVX-512 / PCLMULQDQ / CUDA at runtime and lets
callers force a specific NTT or FHE backend for benchmarking.
"""
from __future__ import annotations

__all__: list[str]


class AccelBackend:
    """Hardware acceleration backend types."""
    NONE: AccelBackend
    AVX2: AccelBackend
    AVX512: AccelBackend
    AES_NI: AccelBackend
    CUDA: AccelBackend
    @property
    def value(self) -> int: ...


# Module-level alias re-exports.
NONE: AccelBackend
AVX2: AccelBackend
AVX512: AccelBackend
AES_NI: AccelBackend
CUDA: AccelBackend


class AccelCaps:
    """Hardware capability flags (bitmask)."""
    AVX2: AccelCaps
    AVX512F: AccelCaps
    AVX512VL: AccelCaps
    AVX512IFMA: AccelCaps
    AES_NI: AccelCaps
    PCLMULQDQ: AccelCaps
    CUDA: AccelCaps
    @property
    def value(self) -> int: ...


AVX512F: AccelCaps
AVX512VL: AccelCaps
AVX512IFMA: AccelCaps
PCLMULQDQ: AccelCaps


class GPUInfo:
    """GPU device information."""
    name: str
    compute_capability: tuple[int, int]
    total_memory_mb: int
    multi_processor_count: int


def accel_detect() -> int:
    """Bitmask of detected ``AccelCaps`` on the current CPU/GPU."""


def accel_status() -> str:
    """Human-readable hardware capability summary."""


def backend_name(backend: AccelBackend) -> str:
    """Friendly name for an ``AccelBackend`` enum."""


def has_cap(cap: AccelCaps) -> bool:
    """Test whether a single capability bit is set in the runtime mask."""


def detect_hardware() -> dict:
    """Detailed dict with CPU brand, vendor, cache, and GPU details."""


def force_backend(backend: AccelBackend) -> None:
    """Force a specific backend (overrides auto-detection)."""


def clear_force() -> None:
    """Restore automatic backend selection."""


def gpu_count() -> int:
    """Number of CUDA-capable GPUs (0 if no CUDA)."""


def gpu_info(device_id: int = 0) -> GPUInfo:
    """Return :class:`GPUInfo` for the given device id."""


def print_status() -> None:
    """Pretty-print acceleration status to stdout."""


def select_fhe_backend(n: int, L: int) -> AccelBackend:
    """Choose the optimal FHE backend for ring degree ``n`` and depth ``L``."""


def select_ntt_backend(n: int, L: int) -> AccelBackend:
    """Choose the optimal NTT backend for ring degree ``n`` and depth ``L``."""
