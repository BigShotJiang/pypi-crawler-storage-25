"""Type stubs for ``kctsb.crypto`` — atomic cryptographic primitives.

This stub file is the authoritative source for static type information and
IDE hover documentation. All symbols in the runtime :mod:`kctsb.crypto`
module are declared here with rich NumPy-style docstrings.
"""
from __future__ import annotations

__all__: list[str]


def sha256(data: bytes) -> bytes:
    """Compute SHA-256 digest in one shot (SHA-NI / AVX2 accelerated).

    Parameters
    ----------
    data : bytes
        Arbitrary-length input message.

    Returns
    -------
    bytes
        32-byte SHA-256 digest.

    Examples
    --------
    >>> from kctsb import crypto
    >>> crypto.sha256(b"abc").hex()
    'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
    """


def sha512(data: bytes) -> bytes:
    """Compute SHA-512 digest in one shot.

    Parameters
    ----------
    data : bytes
        Arbitrary-length input.

    Returns
    -------
    bytes
        64-byte SHA-512 digest.
    """


def sha3_256(data: bytes) -> bytes:
    """Compute SHA3-256 (Keccak f[1600]) digest in one shot.

    Parameters
    ----------
    data : bytes
        Arbitrary-length input.

    Returns
    -------
    bytes
        32-byte SHA3-256 digest.
    """


def hmac_sha256(key: bytes, data: bytes) -> bytes:
    """Compute HMAC-SHA-256 (RFC 2104).

    Parameters
    ----------
    key : bytes
        Authentication key of any length.
    data : bytes
        Message to authenticate.

    Returns
    -------
    bytes
        32-byte HMAC tag.
    """


def hmac_sha512(key: bytes, data: bytes) -> bytes:
    """Compute HMAC-SHA-512 (RFC 2104).

    Parameters
    ----------
    key : bytes
    data : bytes

    Returns
    -------
    bytes
        64-byte HMAC tag.
    """


def hkdf_sha256(ikm: bytes, salt: bytes, info: bytes, length: int) -> bytes:
    """HMAC-based Extract-and-Expand Key Derivation Function (RFC 5869).

    Uses SHA-256 as the underlying HMAC and performs ``Extract`` followed
    by ``Expand`` in a single C call.

    Parameters
    ----------
    ikm : bytes
        Input keying material (e.g., ECDH shared secret, master secret).
    salt : bytes
        Optional non-secret salt (pass ``b""`` for default).
    info : bytes
        Optional context / application-specific string. Use domain
        separation here (e.g., ``b"kctsb-rag/content-key/v2"``).
    length : int
        Desired output key material length in bytes (1 .. 255*32).

    Returns
    -------
    bytes
        ``length`` bytes of derived key material.

    Examples
    --------
    >>> from kctsb import crypto
    >>> key = crypto.hkdf_sha256(
    ...     ikm=b"shared-secret", salt=b"app-salt",
    ...     info=b"my-app/v1/content-key", length=32)
    >>> len(key)
    32
    """


def random_bytes(n: int) -> bytes:
    """Return ``n`` cryptographically secure random bytes.

    Backed by the platform CSPRNG (``BCryptGenRandom`` on Windows,
    ``getrandom(2)`` on Linux, ``arc4random`` on macOS).

    Parameters
    ----------
    n : int
        Number of bytes.

    Returns
    -------
    bytes
        Random byte string of exact length ``n``.
    """


def random_uint32() -> int:
    """Return a uniformly random 32-bit unsigned integer."""


def random_uint64() -> int:
    """Return a uniformly random 64-bit unsigned integer."""


def random_range(max: int) -> int:
    """Return a uniformly random integer in ``[0, max)``.

    Uses rejection sampling to eliminate modulo bias.
    """


def token_bytes(nbytes: int = 32) -> bytes:
    """Return ``nbytes`` cryptographically secure random bytes.

    :mod:`secrets`-compatible alias over :func:`random_bytes`.
    """


def token_hex(nbytes: int = 32) -> str:
    """Return ``2 * nbytes`` hexadecimal characters of secure randomness.

    :mod:`secrets`-compatible alias over :func:`random_bytes`.
    """


def secure_compare(a: bytes, b: bytes) -> bool:
    """Constant-time equality comparison for byte strings.

    Prevents timing side-channels in authentication tag / MAC
    verification. Returns ``False`` if lengths differ.
    """


class AESGCM:
    """AES-GCM authenticated encryption (API-compatible with ``cryptography``).

    Hardware-accelerated via AES-NI + CLMUL on x86-64 / ARMv8 Crypto
    Extensions on aarch64. Key sizes: 128 / 192 / 256 bits.

    Examples
    --------
    >>> from kctsb import crypto
    >>> key   = crypto.AESGCM.generate_key(256)
    >>> nonce = crypto.random_bytes(12)
    >>> aead  = crypto.AESGCM(key)
    >>> ct    = aead.encrypt(nonce, b"message", b"header-aad")
    >>> aead.decrypt(nonce, ct, b"header-aad")
    b'message'
    """

    def __init__(self, key: bytes) -> None:
        """Initialize AEAD with a 16/24/32-byte key."""

    @staticmethod
    def generate_key(bit_length: int) -> bytes:
        """Generate a fresh random key of ``bit_length`` bits (128/192/256)."""

    def encrypt(self, nonce: bytes, data: bytes, associated_data: bytes | None = ...) -> bytes:
        """Authenticate + encrypt; returns ``ciphertext || tag`` (tag is 16 bytes)."""

    def decrypt(self, nonce: bytes, data: bytes, associated_data: bytes | None = ...) -> bytes:
        """Verify tag + decrypt. Raises on tag mismatch."""


class ChaCha20Poly1305:
    """ChaCha20-Poly1305 AEAD (API-compatible with ``cryptography``).

    256-bit key, 96-bit nonce, 128-bit tag (RFC 8439). Constant-time by
    construction — preferred when hardware AES is unavailable.
    """

    def __init__(self, key: bytes) -> None:
        """Initialize with a 32-byte key."""

    @staticmethod
    def generate_key() -> bytes:
        """Generate a fresh random 32-byte key."""

    def encrypt(self, nonce: bytes, data: bytes, associated_data: bytes | None = ...) -> bytes:
        """Authenticate + encrypt; returns ``ciphertext || tag``."""

    def decrypt(self, nonce: bytes, data: bytes, associated_data: bytes | None = ...) -> bytes:
        """Verify tag + decrypt. Raises on tag mismatch."""
