"""
kctsb.crypto — Atomic cryptographic primitives (hardware-accelerated)

Direct re-exports of the ``_kctsb_core.crypto`` C++ extension submodule. All
primitives dispatch to the fastest accelerated backend detected at runtime
(AES-NI, SHA-NI, AVX2, AVX-512; CUDA where implemented).

This module intentionally does NOT provide hashlib / hmac compatibility
shims — callers should use the one-shot functions directly for maximum
performance and clearer audit trails::

    # ❌ Don't do this (adds Python-level buffer overhead):
    h = hashlib.sha256(); h.update(x); digest = h.digest()

    # ✅ Do this (single C call, zero Python overhead):
    from kctsb import crypto
    digest = crypto.sha256(x)
    mac    = crypto.hmac_sha256(key, x)
    okm    = crypto.hkdf_sha256(ikm, salt, info, 32)

Exposed API
-----------
Hashes (one-shot, ``bytes -> bytes``)::

    sha256(data)                 # 32 bytes, SHA-NI / AVX2
    sha512(data)                 # 64 bytes
    sha3_256(data)               # 32 bytes, Keccak f[1600]

MACs (one-shot, ``(key, data) -> bytes``)::

    hmac_sha256(key, data)       # 32 bytes (RFC 2104)
    hmac_sha512(key, data)       # 64 bytes

KDF::

    hkdf_sha256(ikm, salt, info, length) -> bytes   # RFC 5869

CSPRNG (platform-backed)::

    random_bytes(n)              # bytes
    random_uint32()              # int
    random_uint64()              # int
    random_range(max)            # int in [0, max)
    token_bytes(n=32)            # bytes     (secrets-compatible alias)
    token_hex(n=32)              # str       (secrets-compatible alias)

AEAD (API-compatible with ``cryptography.hazmat.primitives.ciphers.aead``)::

    AESGCM(key).encrypt(nonce, data, aad)
    AESGCM(key).decrypt(nonce, data, aad)
    ChaCha20Poly1305(key).encrypt(...)
    ChaCha20Poly1305(key).decrypt(...)

Utilities::

    secure_compare(a, b) -> bool    # constant-time

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

from __future__ import annotations

from ._kctsb_core.crypto import (
    AESGCM,
    ChaCha20Poly1305,
    hkdf_sha256,
    hmac_sha256,
    hmac_sha512,
    random_bytes,
    random_range,
    random_uint32,
    random_uint64,
    secure_compare,
    sha3_256,
    sha256,
    sha512,
)


def token_bytes(nbytes: int = 32) -> bytes:
    """Return ``nbytes`` cryptographically secure random bytes.

    :mod:`secrets`-compatible alias over :func:`random_bytes`.
    """
    return random_bytes(nbytes)


def token_hex(nbytes: int = 32) -> str:
    """Return ``2 * nbytes`` hexadecimal characters of secure randomness.

    :mod:`secrets`-compatible alias over :func:`random_bytes`.
    """
    return random_bytes(nbytes).hex()


__all__ = [
    "sha256",
    "sha512",
    "sha3_256",
    "hmac_sha256",
    "hmac_sha512",
    "hkdf_sha256",
    "random_bytes",
    "random_uint32",
    "random_uint64",
    "random_range",
    "token_bytes",
    "token_hex",
    "secure_compare",
    "AESGCM",
    "ChaCha20Poly1305",
]
