"""Type stubs for ``kctsb.ckks`` — CKKS approximate homomorphic encryption."""
from __future__ import annotations

from typing import List, Optional, Union

import numpy as np

from ._kctsb_core.ckks import (
    Ciphertext as Ciphertext,
    Context as Context,
    Plaintext as Plaintext,
    PublicKey as PublicKey,
    RelinKey as RelinKey,
    SecretKey as SecretKey,
)

__all__: list[str]


class CKKSContext:
    """High-level Pythonic CKKS context with automatic key lifecycle.

    Parameters
    ----------
    poly_modulus_degree : int, default 8192
        Polynomial ring dimension N (must be power of two; 4096/8192/16384).
    coeff_modulus_levels : int, default 5
        Number of coefficient moduli in the chain.
    scale_bits : int, default 40
        log₂ of the default CKKS scaling factor.

    Examples
    --------
    >>> ctx = CKKSContext(poly_modulus_degree=8192,
    ...                   coeff_modulus_levels=5,
    ...                   scale_bits=40)
    >>> sk = ctx.keygen()
    >>> pk = ctx.public_key(sk)
    >>> ct = ctx.encrypt(pk, ctx.encode([1.0, 2.0, 3.0]))
    >>> ct2 = ctx.add(ct, ct)
    >>> ctx.decrypt_decode(sk, ct2)[:3]
    [2.0, 4.0, 6.0]
    """

    poly_modulus_degree: int
    coeff_modulus_levels: int
    scale_bits: int

    def __init__(
        self,
        poly_modulus_degree: int = ...,
        coeff_modulus_levels: int = ...,
        scale_bits: int = ...,
    ) -> None: ...

    def keygen(self) -> SecretKey:
        """Generate a fresh CKKS secret key."""

    def public_key(self, sk: SecretKey) -> PublicKey:
        """Derive the public key from ``sk``."""

    def relin_key(self, sk: SecretKey) -> RelinKey:
        """Derive a relinearization key from ``sk``."""

    def encode(self, values: Union[List[float], np.ndarray]) -> Plaintext:
        """Encode a float vector into a CKKS plaintext polynomial."""

    def decode(self, pt: Plaintext) -> List[float]:
        """Decode a plaintext back to a float vector."""

    def encrypt(self, pk: PublicKey, pt: Plaintext) -> Ciphertext:
        """Encrypt ``pt`` under ``pk``."""

    def decrypt(self, sk: SecretKey, ct: Ciphertext) -> Plaintext:
        """Decrypt ``ct`` under ``sk`` to a plaintext."""

    def decrypt_decode(self, sk: SecretKey, ct: Ciphertext) -> List[float]:
        """Decrypt + decode in one call."""

    def add(self, a: Ciphertext, b: Ciphertext) -> Ciphertext:
        """Homomorphic addition of ciphertexts."""

    def multiply(
        self, a: Ciphertext, b: Ciphertext, rk: Optional[RelinKey] = ...
    ) -> Ciphertext:
        """Homomorphic multiplication of ciphertexts; relinearizes if ``rk`` given."""

    def multiply_plain(self, a: Ciphertext, pt: Plaintext) -> Ciphertext:
        """Homomorphic plaintext–ciphertext multiplication."""

    def rescale(self, ct: Ciphertext) -> Ciphertext:
        """Rescale ``ct`` by dropping the top prime in the modulus chain."""
