"""Type stubs for ``kctsb.dp`` — Differential Privacy mechanisms."""
from __future__ import annotations

from typing import List, Optional, Union

import numpy as np

__all__: list[str]


def add_noise_vector(
    values: Union[List[float], np.ndarray],
    sensitivity: float,
    epsilon: float,
    mechanism: str = ...,
    delta: float = ...,
) -> List[float]:
    """Add calibrated noise to a vector under (ε, δ)-DP.

    Parameters
    ----------
    values : list[float] | np.ndarray
        Query answers (e.g., topic-preference vector).
    sensitivity : float
        L1 sensitivity for Laplace, L2 sensitivity for Gaussian.
    epsilon : float
        Privacy loss parameter (smaller = more private).
    mechanism : {'laplace', 'gaussian'}, default 'laplace'
        Noise distribution.
    delta : float, default 1e-6
        Only used for Gaussian; must be in (0, 1).

    Returns
    -------
    list[float]
        Noisy values of the same length as ``values``.
    """


def laplace_noise(sensitivity: float, epsilon: float) -> float:
    """Draw a single Laplace(0, sensitivity/ε) sample."""


def gaussian_noise(sensitivity: float, epsilon: float, delta: float = ...) -> float:
    """Draw a single Gaussian sample calibrated for (ε, δ)-DP.

    Uses σ = sqrt(2 ln(1.25/δ)) · sensitivity / ε.
    """


class DPMechanism:
    """Differential privacy noise generation mechanisms.

    Provides Laplace, Gaussian, and Exponential mechanisms, plus
    higher-level helpers ``add_noise`` and ``add_noise_vector``. All
    methods are static; no state is kept on the instance.
    """

    @staticmethod
    def laplace(sensitivity: float, epsilon: float) -> float:
        """Draw a Laplace(0, sensitivity/ε) noise sample."""

    @staticmethod
    def gaussian(sensitivity: float, epsilon: float, delta: float = ...) -> float:
        """Draw a Gaussian noise sample for (ε, δ)-DP."""

    @staticmethod
    def exponential(
        utilities: List[float],
        sensitivity: float,
        epsilon: float,
    ) -> int:
        """Sample an index proportional to exp(ε · utility / (2 · sensitivity))."""

    @staticmethod
    def add_noise(
        value: float,
        sensitivity: float,
        epsilon: float,
        mechanism: str = ...,
        delta: float = ...,
    ) -> float:
        """Return ``value + noise`` calibrated for (ε, δ)-DP."""

    @staticmethod
    def add_noise_vector(
        values: Union[List[float], np.ndarray],
        sensitivity: float,
        epsilon: float,
        mechanism: str = ...,
        delta: float = ...,
    ) -> List[float]:
        """Vectorized :func:`add_noise`."""


class DPBudget:
    """Track ε / δ privacy budget across multiple queries.

    Uses basic sequential composition: ε and δ add up across queries.
    Consider advanced composition (RDP / zCDP) for tighter accounting.
    """

    total_epsilon: float
    total_delta: float
    consumed_epsilon: float
    consumed_delta: float

    def __init__(self, total_epsilon: float, total_delta: float = ...) -> None:
        """Create budget with total (ε, δ) caps."""

    def consume(self, epsilon: float, delta: float = ...) -> None:
        """Record a query spending (ε, δ). Raises if cap exceeded."""

    def can_consume(self, epsilon: float, delta: float = ...) -> bool:
        """Check whether a query fits within the remaining budget."""

    @property
    def remaining_epsilon(self) -> float:
        """Return ``total_epsilon - consumed_epsilon``."""

    @property
    def remaining_delta(self) -> float:
        """Return ``total_delta - consumed_delta``."""

    def reset(self) -> None:
        """Reset consumed budget to zero."""
