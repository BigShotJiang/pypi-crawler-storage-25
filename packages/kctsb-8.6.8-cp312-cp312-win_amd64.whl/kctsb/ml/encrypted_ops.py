"""
kctsb.ml.encrypted_ops - Encrypted Search, Comparison, and Profiling Operators

Production-grade CKKS-based operators for confidential computing:

1. **Encrypted Search** (EncryptedSearch):
   - Cosine similarity matching on encrypted feature vectors
   - Encrypted inner-product retrieval (keyword matching)
   - Encrypted top-k approximate retrieval

2. **Encrypted Comparison** (EncryptedComparator):
   - Approximate sign, comparison, threshold via polynomial approximation
   - Encrypted max/min selection
   - Chebyshev polynomial sign(x) approximation (configurable degree)

3. **Encrypted Profiling** (EncryptedProfiler):
   - Encrypted feature aggregation (weighted sum)
   - Encrypted statistics (element-wise mean, variance)
   - Encrypted cosine similarity for profile matching
   - Encrypted feature masking and filtering

Design Constraints:
    - CKKS provides approximate arithmetic only — no exact comparison.
    - Our CKKS implementation has NO rotation/Galois keys, so
      cross-slot summation requires client-side decryption.
    - Each multiply_plain MUST be followed by rescale.
    - Each multiply (ct × ct) via relin+rescale consumes one level.
    - Polynomial degree determines multiplicative depth budget.

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import logging
import math
from typing import List, Optional, Tuple, Union

import numpy as np

logger = logging.getLogger(__name__)


# ============================================================================
# Constants
# ============================================================================

# Chebyshev coefficients for sign(x) approximation on [-1, 1]
# Degree-7 minimax: max error ~0.06 on [-1, -0.1] ∪ [0.1, 1]
_SIGN_CHEB_7 = [
    0.0,          # a_0 (odd function)
    1.1963,       # a_1
    0.0,          # a_2
    -0.3049,      # a_3
    0.0,          # a_4
    0.1263,       # a_5
    0.0,          # a_6
    -0.0517,      # a_7
]

# Degree-3 fast sign approximation: sign(x) ≈ 1.5x - 0.5x³
_SIGN_POLY_3 = [0.0, 1.5, 0.0, -0.5]

# Degree-5 medium sign: better accuracy, depth cost 3
_SIGN_POLY_5 = [0.0, 1.875, 0.0, -1.25, 0.0, 0.375]

# Sigmoid approximation: σ(x) ≈ 0.5 + 0.197x - 0.004x³ (degree 3)
_SIGMOID_POLY_3 = [0.5, 0.197, 0.0, -0.004]


def _chebyshev_to_monomial(cheb_coeffs: List[float]) -> List[float]:
    """Convert Chebyshev coefficients to monomial (power) basis.

    Uses T_k recurrence: T_0=1, T_1=x, T_k=2x·T_{k-1} − T_{k-2}.

    Parameters
    ----------
    cheb_coeffs : list[float]
        Chebyshev basis coefficients [a_0, a_1, ..., a_n].

    Returns
    -------
    list[float]
        Monomial (standard) polynomial coefficients [c_0, c_1, ..., c_n].
    """
    n = len(cheb_coeffs)
    if n == 0:
        return [0.0]
    if n == 1:
        return [cheb_coeffs[0]]

    T = [[0.0] * n for _ in range(n)]
    T[0][0] = 1.0
    if n > 1:
        T[1][1] = 1.0
    for k in range(2, n):
        for j in range(n):
            if j > 0:
                T[k][j] = 2.0 * T[k - 1][j - 1]
            T[k][j] -= T[k - 2][j]

    result = [0.0] * n
    for k in range(n):
        for j in range(n):
            result[j] += cheb_coeffs[k] * T[k][j]
    return result


# ============================================================================
# Encrypted Comparison
# ============================================================================

class EncryptedComparator:
    """Approximate comparison operators on CKKS ciphertexts.

    CKKS supports only approximate arithmetic, so exact comparison
    is impossible. Instead, we approximate sign(x), step(x), etc.
    using polynomial approximations.

    The accuracy depends on:
    - Polynomial degree (higher = more accurate but deeper circuit)
    - Input range normalization (values should be in [-1, 1])
    - Distance from zero (near-zero values are inherently ambiguous)

    Implementation Note:
        Our CKKS implementation does NOT support mod_switch_to
        (level matching). Therefore we use Horner's method to
        evaluate polynomials, which avoids adding ciphertexts at
        different levels. Cross-level multiply IS safe because
        `multiply_relin_rescale` takes `min(level)` and only uses
        valid RNS limbs in subsequent rescales. `add_plain` is
        also safe (no scale check).

    Parameters
    ----------
    ctx : CKKSContext
        CKKS encryption context.
    rk : RelinKey
        Relinearization key for ciphertext multiplication.
    degree : int, optional
        Polynomial degree for sign approximation. Only 3 is
        currently supported (depth cost: 3 levels).
        Default is 3.
    """

    # Depth budget (levels consumed) per degree
    _DEPTH_MAP = {3: 3}

    def __init__(self, ctx, rk, degree: int = 3) -> None:
        self._ctx = ctx
        self._rk = rk
        if degree not in (3,):
            raise ValueError(
                f"Unsupported sign degree: {degree}. Use 3."
            )
        self._degree = degree
        logger.info(
            "EncryptedComparator: degree=%d, depth_cost=%d levels",
            degree, self._DEPTH_MAP[degree],
        )

    def _sign3(self, ct_x):
        """Degree-3 sign approximation via Horner's method.

        sign(x) ≈ 1.5x − 0.5x³ = x · (1.5 − 0.5·x²)

        Evaluation:
            1. x² = multiply(x, x, rk)         → level L−1
            2. −0.5·x² = multiply_plain + rescale → level L−2
            3. inner = add_plain(−0.5·x², 1.5)  → level L−2
            4. result = multiply(x, inner, rk)  → level L−3
               (cross-level multiply is safe)

        Parameters
        ----------
        ct_x : Ciphertext
            Encrypted input in [-1, 1].

        Returns
        -------
        Ciphertext
            Encrypted sign(x) approximation.
        """
        ctx = self._ctx
        rk = self._rk

        # Step 1: x²
        ct_x2 = ctx.multiply(ct_x, ct_x, rk)

        # Step 2: −0.5 · x²
        pt_neg_half = ctx.encode_single(-0.5)
        ct_neg_half_x2 = ctx.multiply_plain(ct_x2, pt_neg_half)
        ct_neg_half_x2 = ctx.rescale(ct_neg_half_x2)

        # Step 3: inner = 1.5 − 0.5·x²
        # CRITICAL: encode the constant at the CIPHERTEXT's current scale,
        # not the default Δ.  After chained operations the ct scale diverges
        # from Δ; using Δ would add 1.5*(Δ/ct.scale) instead of 1.5.
        pt_one_five = ctx.encode_single(1.5, scale=ct_neg_half_x2.scale)
        ct_inner = ctx.add_plain(ct_neg_half_x2, pt_one_five)

        # Step 4: x · inner (cross-level multiply: x@L, inner@L-2)
        ct_result = ctx.multiply(ct_x, ct_inner, rk)
        return ct_result

    def sign_approx(self, ct_diff):
        """Approximate sign function on encrypted data.

        sign(x) ≈ P(x) where P is a polynomial approximation.
        Input should be normalized to approximately [-1, 1].

        Parameters
        ----------
        ct_diff : Ciphertext
            Encrypted difference value (a - b), pre-normalized.

        Returns
        -------
        Ciphertext
            Encrypted approximate sign(a - b).
            Values near +1 indicate a > b, near -1 indicate a < b.
        """
        return self._sign3(ct_diff)

    def compare_greater(self, ct_a, ct_b, scale: float = 1.0):
        """Approximate encrypted comparison: a > b.

        Computes sign(a - b) ∈ {-1, +1} (approximately).
        Values close to +1 indicate a > b.

        Parameters
        ----------
        ct_a : Ciphertext
            First encrypted operand.
        ct_b : Ciphertext
            Second encrypted operand.
        scale : float
            Normalization scale. The difference (a - b) will be
            divided by this value to map to [-1, 1].
            If 1.0 (default), no scaling is applied; inputs should
            already be in [-1, 1].

        Returns
        -------
        Ciphertext
            Encrypted approximate indicator: +1 if a > b, -1 if a < b.
        """
        ct_diff = self._ctx.sub(ct_a, ct_b)
        if scale != 1.0:
            pt_inv_scale = self._ctx.encode_single(1.0 / scale)
            ct_diff = self._ctx.multiply_plain(ct_diff, pt_inv_scale)
            ct_diff = self._ctx.rescale(ct_diff)
        return self.sign_approx(ct_diff)

    def threshold(self, ct_x, threshold_val: float, scale: float = 1.0):
        """Encrypted threshold function: ~1 if x > threshold, ~0 otherwise.

        Approximation: step(x − t) ≈ (1 + sign(x − t)) / 2.
        Uses only add_plain and multiply_plain after sign evaluation,
        so no cross-level ciphertext addition is required.

        Parameters
        ----------
        ct_x : Ciphertext
            Encrypted input.
        threshold_val : float
            Threshold value.
        scale : float
            Normalization scale for the shifted value.

        Returns
        -------
        Ciphertext
            Encrypted approximate step function result.
        """
        ct_shifted = self._ctx.add_plain(
            ct_x, self._ctx.encode_single(-threshold_val, scale=ct_x.scale)
        )
        if scale != 1.0:
            pt_inv = self._ctx.encode_single(1.0 / scale)
            ct_shifted = self._ctx.multiply_plain(ct_shifted, pt_inv)
            ct_shifted = self._ctx.rescale(ct_shifted)
        ct_sign = self.sign_approx(ct_shifted)
        # step(x) = (1 + sign(x)) / 2
        ct_plus_one = self._ctx.add_plain(
            ct_sign, self._ctx.encode_single(1.0, scale=ct_sign.scale)
        )
        pt_half = self._ctx.encode_single(0.5)
        ct_step = self._ctx.multiply_plain(ct_plus_one, pt_half)
        ct_step = self._ctx.rescale(ct_step)
        return ct_step


# ============================================================================
# Encrypted Search
# ============================================================================

class EncryptedSearch:
    """Ciphertext search engine using homomorphic similarity computation.

    Implements encrypted retrieval operations:
    - Inner-product similarity search (keyword matching)
    - Cosine similarity matching (nearest neighbor)
    - Weighted feature matching with mask

    Without CKKS rotation, cross-slot summation is not possible
    homomorphically. This implementation uses per-slot element-wise
    products; the client sums across slots after decryption.

    For server-side aggregation, use the ``score_vector`` method which
    returns the element-wise product ciphertext — the client computes
    the final dot product score.

    Parameters
    ----------
    ctx :  CKKSContext or _kctsb_core.ckks.Context
        CKKS encryption context.
    rk : RelinKey
        Relinearization key.
    """

    def __init__(self, ctx, rk) -> None:
        self._ctx = ctx
        self._rk = rk
        self._slot_count = ctx.slot_count

    def score_vector(self, ct_query, plain_key: np.ndarray):
        """Compute element-wise product E(q[i] * k[i]) for similarity.

        The client must sum the decrypted slots to get the final score.
        This is the fundamental building block for encrypted search.

        Parameters
        ----------
        ct_query : Ciphertext
            Encrypted query vector (packed in slots).
        plain_key : np.ndarray
            Plaintext key/document vector for matching.

        Returns
        -------
        Ciphertext
            Element-wise product ciphertext. Client sums slots for score.
        """
        key_padded = np.zeros(self._slot_count)
        key_padded[:len(plain_key)] = plain_key
        pt_key = self._ctx.encode(key_padded.tolist())
        ct_prod = self._ctx.multiply_plain(ct_query, pt_key)
        ct_prod = self._ctx.rescale(ct_prod)
        return ct_prod

    def batch_score(self, ct_query, key_matrix: np.ndarray) -> list:
        """Score encrypted query against multiple plaintext keys.

        Computes element-wise product for each row of key_matrix.
        Returns a list of ciphertexts (one per key).

        Parameters
        ----------
        ct_query : Ciphertext
        key_matrix : np.ndarray, shape (num_keys, dim)

        Returns
        -------
        list[Ciphertext]
            One score-vector ciphertext per key.
        """
        num_keys = key_matrix.shape[0]
        results = []
        for i in range(num_keys):
            ct_score = self.score_vector(ct_query, key_matrix[i])
            results.append(ct_score)
        logger.debug("batch_score: %d keys scored", num_keys)
        return results

    def cosine_similarity_components(self, ct_a, ct_b):
        """Compute element-wise product for cosine similarity: a[i] * b[i].

        Cosine similarity = Σ(a·b) / (||a|| · ||b||).
        This returns E(a[i] * b[i]); client sums for the numerator.
        Norms must be computed/known separately.

        Parameters
        ----------
        ct_a, ct_b : Ciphertext

        Returns
        -------
        Ciphertext
            Element-wise product E(a[i] * b[i]).
        """
        ct_prod = self._ctx.multiply(ct_a, ct_b, self._rk)
        return ct_prod


# ============================================================================
# Encrypted Profiling
# ============================================================================

class EncryptedProfiler:
    """Encrypted user feature profiling operations.

    Supports privacy-preserving feature analysis:
    - Weighted feature aggregation
    - Element-wise statistics (mean/variance with known count)
    - Feature masking and selection
    - Profile cosine similarity matching

    All operations maintain data encrypted. Statistical aggregation
    across slots requires client-side summation (no rotation support).

    Parameters
    ----------
    ctx : CKKSContext or _kctsb_core.ckks.Context
    rk : RelinKey
    """

    def __init__(self, ctx, rk) -> None:
        self._ctx = ctx
        self._rk = rk
        self._slot_count = ctx.slot_count

    def weighted_aggregate(self, ct_features, plain_weights: np.ndarray):
        """Compute weighted feature vector: E(f[i] * w[i]).

        The result contains per-slot weighted values.
        Client sums slots for the aggregate score.

        Parameters
        ----------
        ct_features : Ciphertext
            Encrypted user feature vector.
        plain_weights : np.ndarray
            Feature importance weights (plaintext).

        Returns
        -------
        Ciphertext
            Element-wise weighted features.
        """
        w_padded = np.zeros(self._slot_count)
        w_padded[:len(plain_weights)] = plain_weights
        pt_w = self._ctx.encode(w_padded.tolist())
        ct_weighted = self._ctx.multiply_plain(ct_features, pt_w)
        ct_weighted = self._ctx.rescale(ct_weighted)
        return ct_weighted

    def feature_mask(self, ct_features, mask: np.ndarray):
        """Apply binary feature mask: E(f[i] * mask[i]).

        Useful for selecting/hiding specific feature dimensions.

        Parameters
        ----------
        ct_features : Ciphertext
        mask : np.ndarray
            Binary mask (0 or 1 per slot).

        Returns
        -------
        Ciphertext
        """
        m_padded = np.zeros(self._slot_count)
        m_padded[:len(mask)] = mask.astype(float)
        pt_mask = self._ctx.encode(m_padded.tolist())
        ct_masked = self._ctx.multiply_plain(ct_features, pt_mask)
        ct_masked = self._ctx.rescale(ct_masked)
        return ct_masked

    def encrypted_square(self, ct_features):
        """Square each encrypted feature: E(f[i]²).

        Used for variance computation: Var = E[f²] - (E[f])².

        Parameters
        ----------
        ct_features : Ciphertext

        Returns
        -------
        Ciphertext
            E(f[i]²) in each slot.
        """
        ct_sq = self._ctx.multiply(ct_features, ct_features, self._rk)
        return ct_sq

    def element_wise_mean(self, ct_list: list):
        """Compute element-wise mean of multiple encrypted vectors.

        mean[i] = (1/n) * Σ_k ct_list[k][i]

        Parameters
        ----------
        ct_list : list[Ciphertext]
            List of encrypted feature vectors.

        Returns
        -------
        Ciphertext
            Element-wise mean across the input vectors.
        """
        if not ct_list:
            raise ValueError("ct_list must not be empty")
        n = len(ct_list)
        ct_sum = ct_list[0]
        for k in range(1, n):
            ct_sum = self._ctx.add(ct_sum, ct_list[k])
        pt_inv_n = self._ctx.encode_single(1.0 / n)
        ct_mean = self._ctx.multiply_plain(ct_sum, pt_inv_n)
        ct_mean = self._ctx.rescale(ct_mean)
        return ct_mean

    def element_wise_second_moment(self, ct_list: list):
        """Compute element-wise E[X²]: (1/n) * Σ x_k[i]².

        All squared ciphertexts are at the same level (L-1), so
        addition is safe. Useful for computing variance client-side:
        Var[i] = E[X²][i] − (E[X][i])².

        Parameters
        ----------
        ct_list : list[Ciphertext]
            All at the same level.

        Returns
        -------
        Ciphertext
            Element-wise second moment.
        """
        if not ct_list:
            raise ValueError("ct_list must not be empty")
        n = len(ct_list)
        sq_list = []
        for ct in ct_list:
            ct_sq = self._ctx.multiply(ct, ct, self._rk)
            sq_list.append(ct_sq)
        ct_sum_sq = sq_list[0]
        for k in range(1, n):
            ct_sum_sq = self._ctx.add(ct_sum_sq, sq_list[k])
        pt_inv_n = self._ctx.encode_single(1.0 / n)
        ct_moment2 = self._ctx.multiply_plain(ct_sum_sq, pt_inv_n)
        ct_moment2 = self._ctx.rescale(ct_moment2)
        return ct_moment2

    def profile_match_score(self, ct_user_features, plain_profile: np.ndarray):
        """Compute matching score between encrypted user and plaintext profile.

        score = Σ(user[i] * profile[i]) (inner product).
        Returns element-wise products; client sums for final score.

        Parameters
        ----------
        ct_user_features : Ciphertext
        plain_profile : np.ndarray

        Returns
        -------
        Ciphertext
            Element-wise product for client-side aggregation.
        """
        return self.weighted_aggregate(ct_user_features, plain_profile)

    def multi_profile_match(self, ct_user_features,
                             profiles: np.ndarray) -> list:
        """Score user against multiple profiles.

        Parameters
        ----------
        ct_user_features : Ciphertext
        profiles : np.ndarray, shape (num_profiles, dim)

        Returns
        -------
        list[Ciphertext]
            One score-vector per profile.
        """
        return [
            self.weighted_aggregate(ct_user_features, profiles[i])
            for i in range(profiles.shape[0])
        ]

    def normalize_features(self, ct_features, known_norm: float):
        """Normalize encrypted features by a known L2 norm.

        Divides each slot by the norm value.

        Parameters
        ----------
        ct_features : Ciphertext
        known_norm : float
            Pre-computed or estimated L2 norm of the feature vector.

        Returns
        -------
        Ciphertext
        """
        if known_norm <= 0:
            raise ValueError("known_norm must be positive")
        pt_inv_norm = self._ctx.encode_single(1.0 / known_norm)
        ct_normalized = self._ctx.multiply_plain(ct_features, pt_inv_norm)
        ct_normalized = self._ctx.rescale(ct_normalized)
        return ct_normalized

    def add_dp_noise(self, ct_features, dp_module, epsilon: float = 1.0,
                      sensitivity: float = 1.0, dim: int = 0):
        """Add DP noise to feature vector before releasing.

        Generates a noise vector, encrypts it, and adds to the
        encrypted features.

        Parameters
        ----------
        ct_features : Ciphertext
        dp_module : _kctsb_core.dp module
            DP noise generation module.
        epsilon : float
        sensitivity : float
        dim : int
            Feature dimension (0 = use slot_count).

        Returns
        -------
        Ciphertext
            Features with DP noise added.
        """
        if dim <= 0:
            dim = self._slot_count
        noise_data = dp_module.add_noise_vector(
            data=[0.0] * dim,
            sensitivity=sensitivity,
            epsilon=epsilon,
        )
        noise_padded = noise_data + [0.0] * (self._slot_count - len(noise_data))
        # Encrypt noise and add (noise is public once added)
        pt_noise = self._ctx.encode(noise_padded)
        ct_noisy = self._ctx.add_plain(ct_features, pt_noise)
        return ct_noisy
