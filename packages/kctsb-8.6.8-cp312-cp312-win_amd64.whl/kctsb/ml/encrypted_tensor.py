"""
kctsb.ml.encrypted_tensor - Encrypted Tensor Representation

Provides an EncryptedTensor class that wraps CKKS ciphertexts as
multi-dimensional tensor objects, supporting batched slot packing
for efficient SIMD-style encrypted computation.

Design:
    A d-dimensional vector is packed into CKKS slots (max n/2 slots).
    For vectors longer than slot_count, multiple ciphertexts are used.
    Matrix rows are encoded as separate ciphertexts for diagonal method.

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import logging
import math
from typing import List, Optional, Tuple, Union

import numpy as np

logger = logging.getLogger(__name__)


class EncryptedTensor:
    """Encrypted tensor backed by CKKS ciphertexts.

    Packs real values into CKKS plaintext slots. One ciphertext holds
    up to slot_count real values. Vectors exceeding slot_count are
    split across multiple ciphertexts.

    Parameters
    ----------
    ctx : CKKSContext
        CKKS encryption context.
    ciphertexts : list
        Internal CKKS ciphertext objects.
    shape : tuple[int, ...]
        Logical shape of the encrypted data.
    pk : PublicKey, optional
        Public key used for encryption (needed for some operations).
    rk : RelinKey, optional
        Relinearization key (needed for multiplication).

    Attributes
    ----------
    shape : tuple[int, ...]
        Logical shape of the tensor data.
    ndim : int
        Number of dimensions.
    size : int
        Total number of elements.
    num_ciphertexts : int
        Number of CKKS ciphertexts used.
    """

    def __init__(
        self,
        ctx,
        ciphertexts: list,
        shape: Tuple[int, ...],
        pk=None,
        rk=None,
    ) -> None:
        self._ctx = ctx
        self._ciphertexts = ciphertexts
        self._shape = shape
        self._pk = pk
        self._rk = rk

    @classmethod
    def encrypt(
        cls,
        ctx,
        data: Union[List[float], np.ndarray],
        pk,
        rk=None,
    ) -> "EncryptedTensor":
        """Create an encrypted tensor from plaintext data.

        Parameters
        ----------
        ctx : CKKSContext
            CKKS context.
        data : array-like
            1D or 2D array of real values.
        pk : PublicKey
            Public key for encryption.
        rk : RelinKey, optional
            Relinearization key.

        Returns
        -------
        EncryptedTensor
            Encrypted representation.
        """
        data_arr = np.asarray(data, dtype=np.float64)
        shape = data_arr.shape
        flat = data_arr.flatten()
        slot_count = ctx.slot_count

        # Split into chunks that fit in one ciphertext
        num_cts = max(1, math.ceil(len(flat) / slot_count))
        ciphertexts = []

        for i in range(num_cts):
            start = i * slot_count
            end = min(start + slot_count, len(flat))
            chunk = flat[start:end].tolist()

            # Pad with zeros to slot_count
            if len(chunk) < slot_count:
                chunk += [0.0] * (slot_count - len(chunk))

            pt = ctx.encode(chunk)
            ct = ctx.encrypt(pk, pt)
            ciphertexts.append(ct)

        logger.debug(
            "EncryptedTensor created: shape=%s, ciphertexts=%d",
            shape, num_cts,
        )
        return cls(ctx, ciphertexts, shape, pk=pk, rk=rk)

    def decrypt(self, sk) -> np.ndarray:
        """Decrypt the tensor back to a numpy array.

        Parameters
        ----------
        sk : SecretKey
            Secret key for decryption.

        Returns
        -------
        np.ndarray
            Decrypted data with original shape.
        """
        slot_count = self._ctx.slot_count
        all_values = []

        for ct in self._ciphertexts:
            values = self._ctx.decrypt_decode(sk, ct)
            all_values.append(values)

        flat = np.concatenate(all_values)
        total_size = int(np.prod(self._shape))
        return flat[:total_size].reshape(self._shape)

    def __add__(self, other: "EncryptedTensor") -> "EncryptedTensor":
        """Element-wise encrypted addition."""
        if self._shape != other._shape:
            raise ValueError(
                f"Shape mismatch: {self._shape} vs {other._shape}"
            )
        result_cts = [
            self._ctx.add(a, b)
            for a, b in zip(self._ciphertexts, other._ciphertexts)
        ]
        return EncryptedTensor(
            self._ctx, result_cts, self._shape,
            pk=self._pk, rk=self._rk,
        )

    def __sub__(self, other: "EncryptedTensor") -> "EncryptedTensor":
        """Element-wise encrypted subtraction."""
        if self._shape != other._shape:
            raise ValueError(
                f"Shape mismatch: {self._shape} vs {other._shape}"
            )
        result_cts = [
            self._ctx.sub(a, b)
            for a, b in zip(self._ciphertexts, other._ciphertexts)
        ]
        return EncryptedTensor(
            self._ctx, result_cts, self._shape,
            pk=self._pk, rk=self._rk,
        )

    def scalar_multiply(self, scalar: float) -> "EncryptedTensor":
        """Multiply each element by a plaintext scalar.

        Parameters
        ----------
        scalar : float
            Scalar multiplier.

        Returns
        -------
        EncryptedTensor
        """
        pt = self._ctx.encode_single(scalar)
        result_cts = [
            self._ctx.multiply_plain(ct, pt)
            for ct in self._ciphertexts
        ]
        return EncryptedTensor(
            self._ctx, result_cts, self._shape,
            pk=self._pk, rk=self._rk,
        )

    def add_scalar(self, scalar: float) -> "EncryptedTensor":
        """Add a plaintext scalar to each element.

        Parameters
        ----------
        scalar : float

        Returns
        -------
        EncryptedTensor
        """
        pt = self._ctx.encode_single(scalar)
        result_cts = [
            self._ctx.add_plain(ct, pt)
            for ct in self._ciphertexts
        ]
        return EncryptedTensor(
            self._ctx, result_cts, self._shape,
            pk=self._pk, rk=self._rk,
        )

    @property
    def shape(self) -> Tuple[int, ...]:
        """Logical shape of the encrypted data."""
        return self._shape

    @property
    def ndim(self) -> int:
        """Number of dimensions."""
        return len(self._shape)

    @property
    def size(self) -> int:
        """Total number of elements."""
        return int(np.prod(self._shape))

    @property
    def num_ciphertexts(self) -> int:
        """Number of CKKS ciphertexts used."""
        return len(self._ciphertexts)

    def __repr__(self) -> str:
        return (
            f"EncryptedTensor(shape={self._shape}, "
            f"ciphertexts={self.num_ciphertexts})"
        )
