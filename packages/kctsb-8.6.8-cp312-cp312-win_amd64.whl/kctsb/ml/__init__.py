"""
kctsb.ml - Encrypted Machine Learning & Confidential Computing Operators

Provides homomorphic encryption-based ML operators for privacy-preserving
machine learning inference, encrypted search/comparison, and user profiling.

Modules:
    - encrypted_tensor: Encrypted tensor representation
    - he_ops: Homomorphic encryption arithmetic operators
    - encrypted_nn: Neural network layers (Linear, activation, attention)
    - pipeline: End-to-end encrypted inference pipeline
    - encrypted_ops: Encrypted search, comparison, and profiling operators

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

from .encrypted_tensor import EncryptedTensor
from .he_ops import HEOps
from .encrypted_nn import (
    EncryptedLinear,
    encrypted_square,
    encrypted_poly_activation,
    encrypted_approx_gelu,
    encrypted_approx_relu,
    encrypted_softmax_approx,
)
from .pipeline import EncryptedInferencePipeline
from .encrypted_ops import (
    EncryptedComparator,
    EncryptedSearch,
    EncryptedProfiler,
)

__all__ = [
    # Core
    "EncryptedTensor",
    "HEOps",
    # Neural Network
    "EncryptedLinear",
    "encrypted_square",
    "encrypted_poly_activation",
    "encrypted_approx_gelu",
    "encrypted_approx_relu",
    "encrypted_softmax_approx",
    # Pipeline
    "EncryptedInferencePipeline",
    # Confidential Computing Operators
    "EncryptedComparator",
    "EncryptedSearch",
    "EncryptedProfiler",
]
