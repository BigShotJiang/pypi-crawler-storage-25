"""
kctsb.ml.he_ops - Homomorphic Encryption Arithmetic Operators

Provides fundamental HE operations for ML: dot product, matrix-vector
multiply, polynomial evaluation (Horner/Chebyshev), and element-wise ops.

All operations work on CKKS ciphertexts through the CKKSContext interface.
Plaintext weights/biases are encoded as CKKS plaintexts for multiply_plain.

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import logging
import math
from typing import List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class HEOps:
    """Homomorphic encryption arithmetic operations for ML.

    Provides static methods that operate on CKKS ciphertexts through
    a CKKSContext. All methods accept the context as the first arg.

    Design principles:
    - Minimize multiplicative depth (each multiply consumes one level)
    - Use multiply_plain for weight application (no relin needed)
    - Use encode + add_plain for bias addition (free in HE)
    - Rescale after multiply_plain to maintain scale alignment
    """

    @staticmethod
    def dot_product_plain(
        ctx,
        ct_vector,
        plain_weights: np.ndarray,
    ):
        """Compute dot product: Σ(ct[i] * w[i]).

        Encodes the weight vector as a plaintext, element-wise multiplies
        with the ciphertext slots, then the result is in each slot.
        (Note: without rotation, the sum across slots is not possible
        homomorphically; this returns the element-wise product.)

        Parameters
        ----------
        ctx : CKKSContext
        ct_vector : Ciphertext
            Encrypted vector (each slot = one element).
        plain_weights : np.ndarray
            Plaintext weight vector.

        Returns
        -------
        Ciphertext
            Element-wise product E(v[i] * w[i]) for each slot.
        """
        pt_w = ctx.encode(plain_weights.tolist())
        return ctx.multiply_plain(ct_vector, pt_w)

    @staticmethod
    def matrix_vector_multiply(
        ctx,
        ct_vector,
        weight_matrix: np.ndarray,
        bias: Optional[np.ndarray] = None,
        rk=None,
    ) -> list:
        """Plaintext matrix × encrypted vector.

        For weight matrix W (m × d) and encrypted vector v (d,):
        Computes y[i] = Σ_j W[i,j] * v[j] for each output row.

        Each output element is in a separate ciphertext (no rotation).
        The input vector v is encoded once and reused.

        Parameters
        ----------
        ctx : CKKSContext
        ct_vector : Ciphertext
            Encrypted input vector v (d values in slots).
        weight_matrix : np.ndarray
            Plaintext weight matrix W, shape (m, d).
        bias : np.ndarray, optional
            Plaintext bias vector b, shape (m,).
        rk : RelinKey, optional
            Relinearization key (not needed for multiply_plain).

        Returns
        -------
        list[Ciphertext]
            List of m ciphertexts, each containing W[i,:] ⊙ v
            (element-wise product with weight row i).

        Notes
        -----
        Without CKKS rotation, full dot products cannot be completed
        homomorphically. Each returned ciphertext contains the
        element-wise product W[i,j] * v[j] in slot j. The final
        summation must be done client-side after decryption, OR the
        user must use a slot-packing strategy where each row uses a
        separate ciphertext with one element per slot.
        """
        m, d = weight_matrix.shape
        results = []

        for i in range(m):
            row = weight_matrix[i, :].tolist()

            # Pad to slot_count
            slot_count = ctx.slot_count
            if len(row) < slot_count:
                row += [0.0] * (slot_count - len(row))

            pt_row = ctx.encode(row)
            ct_prod = ctx.multiply_plain(ct_vector, pt_row)

            # Add bias if provided
            if bias is not None:
                # Encode bias for this output: bias[i] in all slots
                pt_bias = ctx.encode_single(float(bias[i]))
                ct_prod = ctx.add_plain(ct_prod, pt_bias)

            results.append(ct_prod)

        logger.debug(
            "matrix_vector_multiply: W(%d,%d) × v → %d ciphertexts",
            m, d, len(results),
        )
        return results

    @staticmethod
    def polynomial_evaluate(
        ctx,
        ct_input,
        coefficients: List[float],
        rk,
    ):
        """Evaluate polynomial p(x) = Σ c_i * x^i on encrypted data.

        Uses Horner's method: p(x) = c_0 + x*(c_1 + x*(c_2 + ...))
        to minimize multiplicative depth.

        Parameters
        ----------
        ctx : CKKSContext
        ct_input : Ciphertext
            Encrypted input x.
        coefficients : list[float]
            Polynomial coefficients [c_0, c_1, c_2, ...].
        rk : RelinKey
            Relinearization key for ct×ct multiplications.

        Returns
        -------
        Ciphertext
            Encrypted p(x).

        Notes
        -----
        Multiplicative depth = degree of polynomial.
        For degree-d polynomial, need at least d+1 CKKS levels.
        """
        if not coefficients:
            raise ValueError("Coefficients list must not be empty")

        n = len(coefficients)
        if n == 1:
            # Constant polynomial
            return ctx.add_plain(
                ctx.multiply_plain(ct_input, ctx.encode_single(0.0)),
                ctx.encode_single(coefficients[0]),
            )

        # Horner's method: start from highest coefficient
        # p(x) = c_n-1
        result = ctx.encrypt(
            ctx.public_key(ctx.keygen()) if not hasattr(ctx, '_cached_pk') else ctx._cached_pk,  # noqa
            ctx.encode_single(coefficients[-1]),
        )

        # Actually, use multiply_plain + add_plain pattern
        # Since we need ct * ct for Horner but that consumes depth,
        # let's use a simpler approach for lower depth:
        #
        # For a degree-3 polynomial: c0 + c1*x + c2*x^2 + c3*x^3
        # = c0 + x*(c1 + x*(c2 + x*c3))
        # This needs: 3 multiplications with x (ct * ct each time)

        # Build iteratively:
        # acc = c_{n-1}  (plaintext)
        # for i = n-2 down to 0:
        #   acc = acc * x + c_i
        # But acc * x is ct * ct, which needs relin + rescale

        # Start: encode c_{n-1} as plaintext, encrypt
        pt_top = ctx.encode_single(coefficients[-1])
        # We need the result as a ciphertext at each step
        # Use multiply_plain for x * scalar and add_plain for + scalar
        # But that only gives us c*x, not (accumulator * x)

        # Proper Horner: we need ct_acc * ct_x at each step
        # acc starts as ciphertext of c_{n-1}
        # Actually, let's do it simply with x powers
        # x^0 = 1 (plaintext), x^1 = ct_input, x^2 = ct_input * ct_input, etc.

        # Simple power-based approach (less depth-efficient but simpler):
        # p(x) = c_0 * 1 + c_1 * x + c_2 * x^2 + ...
        # Need to compute x, x^2, x^3, ... and accumulate

        # For small degrees (≤ 5), this is fine
        pt_c0 = ctx.encode_single(coefficients[0])

        # Start with c_0 (as encrypted)
        if n == 1:
            # Already handled above
            pass

        # c_1 * x
        pt_c1 = ctx.encode_single(coefficients[1])
        ct_term = ctx.multiply_plain(ct_input, pt_c1)

        # Accumulate: result = c_0 + c_1 * x
        ct_result = ctx.add_plain(ct_term, pt_c0)

        if n <= 2:
            return ct_result

        # For higher degrees, compute x^k iteratively
        ct_xk = ct_input  # x^1 (after multiply_plain, may need rescale)
        for k in range(2, n):
            # x^k = x^{k-1} * x (ct × ct)
            ct_xk = ctx.multiply(ct_xk, ct_input, rk)

            # c_k * x^k
            pt_ck = ctx.encode_single(coefficients[k])
            ct_term_k = ctx.multiply_plain(ct_xk, pt_ck)

            # Rescale to match levels
            ct_term_k = ctx.rescale(ct_term_k)

            # Accumulate
            ct_result = ctx.add(ct_result, ct_term_k)

        return ct_result

    @staticmethod
    def chebyshev_evaluate(
        ctx,
        ct_input,
        coefficients: List[float],
        rk,
        input_range: tuple = (-1.0, 1.0),
    ):
        """Evaluate Chebyshev polynomial approximation.

        Uses Clenshaw recurrence for numerical stability,
        adapted for CKKS encrypted computation.

        Parameters
        ----------
        ctx : CKKSContext
        ct_input : Ciphertext
            Encrypted input (should be scaled to [-1, 1]).
        coefficients : list[float]
            Chebyshev coefficients [a_0, a_1, ..., a_n].
        rk : RelinKey
        input_range : tuple
            Expected input range for scaling.

        Returns
        -------
        Ciphertext
            Encrypted Chebyshev approximation.
        """
        # For CKKS, Clenshaw recurrence requires careful depth management
        # Fallback to standard polynomial evaluation with Chebyshev coeffs
        # converted to monomial basis

        n = len(coefficients)
        if n <= 1:
            return ctx.add_plain(
                ctx.multiply_plain(ct_input, ctx.encode_single(0.0)),
                ctx.encode_single(coefficients[0] if coefficients else 0.0),
            )

        # Convert Chebyshev to monomial coefficients for small degree
        # T_0(x) = 1, T_1(x) = x, T_2(x) = 2x^2 - 1, T_3(x) = 4x^3 - 3x
        # For degree ≤ 5, direct conversion is simple

        mono_coeffs = _chebyshev_to_monomial(coefficients)
        return HEOps.polynomial_evaluate(ctx, ct_input, mono_coeffs, rk)


def _chebyshev_to_monomial(cheb_coeffs: List[float]) -> List[float]:
    """Convert Chebyshev coefficients to monomial (standard) coefficients.

    Uses the relation T_n(x) = cos(n * arccos(x)) and matrix conversion.

    Parameters
    ----------
    cheb_coeffs : list[float]
        Chebyshev coefficients [a_0, a_1, ..., a_n].

    Returns
    -------
    list[float]
        Monomial coefficients [c_0, c_1, ..., c_n].
    """
    n = len(cheb_coeffs)
    if n == 0:
        return [0.0]
    if n == 1:
        return [cheb_coeffs[0]]

    # Build Chebyshev polynomial coefficients matrix
    # T_k coefficients in monomial basis
    T = [[0.0] * n for _ in range(n)]
    T[0][0] = 1.0  # T_0 = 1
    if n > 1:
        T[1][1] = 1.0  # T_1 = x

    for k in range(2, n):
        # T_k = 2x * T_{k-1} - T_{k-2}
        for j in range(n):
            if j > 0:
                T[k][j] = 2.0 * T[k - 1][j - 1]
            T[k][j] -= T[k - 2][j]

    # Combine: p(x) = sum_k a_k * T_k(x)
    result = [0.0] * n
    for k in range(n):
        for j in range(n):
            result[j] += cheb_coeffs[k] * T[k][j]

    return result
