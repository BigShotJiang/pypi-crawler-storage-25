"""
kctsb.ml.encrypted_nn - Encrypted Neural Network Layers

Provides encrypted equivalents of common neural network building blocks:
- EncryptedLinear: fully-connected layer (weight × input + bias)
- Activation functions: square, polynomial, approx GELU/ReLU
- Softmax approximation for classification heads

All layers operate on CKKS ciphertexts. Weights stay in plaintext
(model owner scenario), inputs/outputs remain encrypted.

Depth budget guide:
  Linear layer:           1 level  (multiply_plain + add_plain)
  Square activation:      1 level  (ct × ct)
  Degree-d polynomial:    d levels
  Approx GELU (deg 4):   4 levels
  Approx ReLU (deg 3):   3 levels

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class LayerStats:
    """Record of a layer execution for profiling.

    Attributes
    ----------
    name : str
        Layer name / type.
    levels_consumed : int
        Multiplicative depth consumed.
    input_slots : int
        Number of input slots.
    output_ciphertexts : int
        Number of output ciphertexts produced.
    """

    name: str = ""
    levels_consumed: int = 0
    input_slots: int = 0
    output_ciphertexts: int = 0


class EncryptedLinear:
    """Encrypted fully-connected (linear / dense) layer.

    Computes y = W @ x + b where W, b are plaintext and x is encrypted.

    Each output neuron is a separate ciphertext containing
    W[i,:] ⊙ x (element-wise product). Without rotation, the final
    summation across slots is deferred to the client.

    For small dimensions (≤ slot_count), a single-ciphertext strategy
    packs one output per call:
      y_i = dot(W[i,:], x) ≈ sum(multiply_plain(ct_x, encode(W[i,:])))

    Parameters
    ----------
    weight : np.ndarray
        Weight matrix, shape (out_features, in_features).
    bias : np.ndarray, optional
        Bias vector, shape (out_features,).
    name : str
        Layer identifier for logging.
    """

    def __init__(
        self,
        weight: np.ndarray,
        bias: Optional[np.ndarray] = None,
        name: str = "linear",
    ):
        if weight.ndim != 2:
            raise ValueError(f"Weight must be 2D, got {weight.ndim}D")
        self.weight = weight.astype(np.float64)
        self.bias = bias.astype(np.float64) if bias is not None else None
        self.name = name
        self.out_features, self.in_features = weight.shape

    def forward(self, ctx, ct_input, rk=None) -> list:
        """Apply linear transformation on encrypted input.

        Parameters
        ----------
        ctx : CKKSContext
        ct_input : Ciphertext
            Encrypted input vector (in_features values in slots).
        rk : RelinKey, optional
            Not needed for multiply_plain path.

        Returns
        -------
        list[Ciphertext]
            One ciphertext per output neuron (out_features total).
        """
        from .he_ops import HEOps

        results = HEOps.matrix_vector_multiply(
            ctx, ct_input, self.weight, self.bias, rk,
        )
        logger.debug(
            "%s: linear(%d→%d) → %d cts",
            self.name, self.in_features, self.out_features, len(results),
        )
        return results

    def stats(self) -> LayerStats:
        """Return layer statistics."""
        return LayerStats(
            name=self.name,
            levels_consumed=1,
            input_slots=self.in_features,
            output_ciphertexts=self.out_features,
        )


def encrypted_square(ctx, ct_input, rk):
    """Compute x^2 on encrypted data.

    Cheapest nonlinear activation in HE — only 1 level.

    Parameters
    ----------
    ctx : CKKSContext
    ct_input : Ciphertext
    rk : RelinKey

    Returns
    -------
    Ciphertext
        E(x^2)
    """
    return ctx.multiply(ct_input, ct_input, rk)


def encrypted_poly_activation(
    ctx,
    ct_input,
    coefficients: List[float],
    rk,
):
    """Apply polynomial activation: p(x) = Σ c_i * x^i.

    Parameters
    ----------
    ctx : CKKSContext
    ct_input : Ciphertext
    coefficients : list[float]
        Polynomial coefficients [c_0, c_1, c_2, ...].
    rk : RelinKey

    Returns
    -------
    Ciphertext
    """
    from .he_ops import HEOps

    return HEOps.polynomial_evaluate(ctx, ct_input, coefficients, rk)


def encrypted_approx_gelu(ctx, ct_input, rk):
    """Approximate GELU activation for encrypted data.

    Uses degree-4 polynomial approximation on [-5, 5]:
        GELU(x) ≈ 0.5x + 0.398x * (1 - 0.0356x^2 + 0.000886x^4)
                 ≈ 0.5x + 0.398x - 0.01418x^3 + 0.000353x^5
    Simplified to degree-3 for depth savings:
        GELU(x) ≈ 0.5x + 0.197x - 0.004x^3
                 ≈ 0.0 + 0.697x + 0.0x^2 - 0.004x^3

    Parameters
    ----------
    ctx : CKKSContext
    ct_input : Ciphertext
    rk : RelinKey

    Returns
    -------
    Ciphertext
        E(GELU_approx(x))

    Notes
    -----
    Depth: 3 levels (degree-3 polynomial).
    Accurate within ~5% for |x| < 3.
    """
    # Degree-3 polynomial: 0.0 + 0.697*x + 0.0*x^2 - 0.004*x^3
    coefficients = [0.0, 0.697, 0.0, -0.004]
    return encrypted_poly_activation(ctx, ct_input, coefficients, rk)


def encrypted_approx_relu(ctx, ct_input, rk):
    """Approximate ReLU activation for encrypted data.

    Uses degree-2 polynomial approximation:
        ReLU(x) ≈ 0.375 + 0.5x + 0.125x^2

    This is the standard Cheon-Kim-Song ReLU approximation.

    Parameters
    ----------
    ctx : CKKSContext
    ct_input : Ciphertext
    rk : RelinKey

    Returns
    -------
    Ciphertext
        E(ReLU_approx(x))

    Notes
    -----
    Depth: 2 levels (x^2 requires one multiply, then multiply_plain).
    Accurate for |x| < 5.
    """
    # Degree-2: 0.375 + 0.5x + 0.125x^2
    coefficients = [0.375, 0.5, 0.125]
    return encrypted_poly_activation(ctx, ct_input, coefficients, rk)


def encrypted_softmax_approx(
    ctx,
    ct_inputs: list,
    rk,
    degree: int = 2,
):
    """Approximate softmax on a list of encrypted values.

    For classification heads: softmax(x_i) = exp(x_i) / Σ exp(x_j).

    Uses degree-2 Taylor: exp(x) ≈ 1 + x + 0.5*x^2.
    Then normalizes by the sum (requires client-side division or
    returns unnormalized scores for client-side softmax).

    Parameters
    ----------
    ctx : CKKSContext
    ct_inputs : list[Ciphertext]
        Encrypted logits, one ciphertext per class.
    rk : RelinKey
    degree : int
        Taylor expansion degree for exp() approximation.

    Returns
    -------
    list[Ciphertext]
        Encrypted approximate exp(x_i) for each class.
        Client must normalize by dividing each by the sum.

    Notes
    -----
    True softmax normalization requires division which is not
    supported in CKKS. Returns unnormalized exp scores.
    The client decrypts all scores and applies argmax or
    softmax normalization on the plaintext values.
    """
    # exp(x) ≈ 1 + x + 0.5*x^2 (+ higher terms if degree > 2)
    if degree == 1:
        coefficients = [1.0, 1.0]
    elif degree == 2:
        coefficients = [1.0, 1.0, 0.5]
    elif degree == 3:
        coefficients = [1.0, 1.0, 0.5, 1.0 / 6.0]
    else:
        # General Taylor for exp(x)
        coefficients = []
        for k in range(degree + 1):
            coefficients.append(1.0 / math.factorial(k))

    results = []
    for ct in ct_inputs:
        ct_exp = encrypted_poly_activation(ctx, ct, coefficients, rk)
        results.append(ct_exp)

    logger.debug(
        "softmax_approx: %d classes, degree-%d Taylor exp",
        len(ct_inputs), degree,
    )
    return results


class EncryptedLayerNorm:
    """Approximate Layer Normalization for encrypted data.

    LayerNorm(x) = (x - E[x]) / sqrt(Var[x] + eps) * gamma + beta

    In HE, we cannot compute exact mean/variance. Instead, we
    approximate with a fixed scaling:
        LN_approx(x) ≈ gamma * x + beta

    This is a no-op normalization that preserves the transformation
    structure. For production use, normalization should be absorbed
    into adjacent linear layers.

    Parameters
    ----------
    gamma : np.ndarray
        Scale parameter.
    beta : np.ndarray
        Shift parameter.
    """

    def __init__(
        self,
        gamma: np.ndarray,
        beta: np.ndarray,
        name: str = "layernorm",
    ):
        self.gamma = gamma.astype(np.float64)
        self.beta = beta.astype(np.float64)
        self.name = name

    def forward(self, ctx, ct_input):
        """Apply approximate layer normalization.

        Parameters
        ----------
        ctx : CKKSContext
        ct_input : Ciphertext

        Returns
        -------
        Ciphertext
            gamma * x + beta (approximate normalization).
        """
        pt_gamma = ctx.encode(self.gamma.tolist())
        ct_scaled = ctx.multiply_plain(ct_input, pt_gamma)

        pt_beta = ctx.encode(self.beta.tolist())
        ct_result = ctx.add_plain(ct_scaled, pt_beta)

        return ct_result

    def stats(self) -> LayerStats:
        """Return layer statistics."""
        return LayerStats(
            name=self.name,
            levels_consumed=1,
            input_slots=len(self.gamma),
            output_ciphertexts=1,
        )
