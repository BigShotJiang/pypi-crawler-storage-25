"""
kctsb.ml.pipeline - Encrypted Inference Pipeline

End-to-end pipeline for running ML model inference on CKKS-encrypted data.
Orchestrates: key generation → encryption → layer-by-layer HE computation
→ decryption on client side.

Supports sequential models with linear layers and polynomial activations.
Designed for the privacy-preserving inference scenario where:
  - Model weights are public (held by server)
  - Input data is encrypted (held by client)
  - Inference runs on ciphertexts (server never sees plaintext)
  - Output is decrypted only by the client

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class InferenceResult:
    """Container for encrypted inference results.

    Attributes
    ----------
    encrypted_outputs : list
        List of output ciphertexts (one per output neuron).
    plaintext_outputs : np.ndarray or None
        Decrypted outputs (only if client-side decryption was performed).
    timing : dict
        Timing breakdown for each phase (keygen, encrypt, inference, decrypt).
    layer_stats : list[dict]
        Per-layer statistics (name, levels_consumed, etc.).
    total_levels_consumed : int
        Total multiplicative depth used.
    """

    encrypted_outputs: list = field(default_factory=list)
    plaintext_outputs: Optional[np.ndarray] = None
    timing: Dict[str, float] = field(default_factory=dict)
    layer_stats: List[Dict[str, Any]] = field(default_factory=list)
    total_levels_consumed: int = 0


class EncryptedInferencePipeline:
    """Pipeline for encrypted model inference using CKKS.

    Manages the full lifecycle:
    1. Context setup (polynomial degree, levels, scale)
    2. Key generation (secret, public, relinearization)
    3. Model layer registration
    4. Input encryption
    5. Sequential layer execution
    6. Output decryption

    Parameters
    ----------
    poly_modulus_degree : int
        Ring polynomial degree (e.g., 8192, 16384).
        Determines max slot count = degree / 2.
    coeff_modulus_levels : int
        Number of coefficient modulus levels.
        Must be ≥ total multiplicative depth + 1.
    scale_bits : int
        Bit precision for CKKS encoding scale (e.g., 40).

    Example
    -------
    >>> pipeline = EncryptedInferencePipeline(8192, 5, 40)
    >>> pipeline.add_linear_layer(weight_matrix, bias_vector, "fc1")
    >>> pipeline.add_activation("relu")
    >>> pipeline.add_linear_layer(weight_matrix2, bias_vector2, "fc2")
    >>> result = pipeline.run(input_data)
    >>> print(result.plaintext_outputs)
    """

    def __init__(
        self,
        poly_modulus_degree: int = 8192,
        coeff_modulus_levels: int = 5,
        scale_bits: int = 40,
    ):
        self.poly_modulus_degree = poly_modulus_degree
        self.coeff_modulus_levels = coeff_modulus_levels
        self.scale_bits = scale_bits

        self._layers: List[Tuple[str, Any]] = []
        self._ctx = None
        self._sk = None
        self._pk = None
        self._rk = None
        self._initialized = False

    def _ensure_context(self):
        """Initialize CKKS context and keys if needed."""
        if self._initialized:
            return

        try:
            from ..ckks import CKKSContext
        except ImportError:
            raise RuntimeError(
                "CKKSContext not available. Build kctsb with KCTSB_BUILD_PYTHON=ON."
            )

        t0 = time.perf_counter()
        self._ctx = CKKSContext(
            self.poly_modulus_degree,
            self.coeff_modulus_levels,
            self.scale_bits,
        )

        self._sk = self._ctx.keygen()
        self._pk = self._ctx.public_key(self._sk)
        self._rk = self._ctx.relin_key(self._sk)
        self._initialized = True

        keygen_time = time.perf_counter() - t0
        logger.info(
            "CKKS context initialized: N=%d, levels=%d, scale=%d bits "
            "(keygen: %.3fs)",
            self.poly_modulus_degree,
            self.coeff_modulus_levels,
            self.scale_bits,
            keygen_time,
        )

    @property
    def slot_count(self) -> int:
        """Number of CKKS slots (= poly_modulus_degree / 2)."""
        return self.poly_modulus_degree // 2

    @property
    def context(self):
        """Access underlying CKKSContext (lazy init)."""
        self._ensure_context()
        return self._ctx

    def add_linear_layer(
        self,
        weight: np.ndarray,
        bias: Optional[np.ndarray] = None,
        name: str = "linear",
    ):
        """Register a linear (fully-connected) layer.

        Parameters
        ----------
        weight : np.ndarray
            Weight matrix, shape (out_features, in_features).
        bias : np.ndarray, optional
            Bias vector, shape (out_features,).
        name : str
            Layer name for logging.
        """
        from .encrypted_nn import EncryptedLinear

        layer = EncryptedLinear(weight, bias, name)
        self._layers.append(("linear", layer))
        logger.debug("Added linear layer '%s': %s", name, weight.shape)

    def add_activation(
        self,
        activation_type: str = "square",
        coefficients: Optional[List[float]] = None,
    ):
        """Register an activation layer.

        Parameters
        ----------
        activation_type : str
            One of: "square", "relu", "gelu", "polynomial".
        coefficients : list[float], optional
            Custom polynomial coefficients (for "polynomial" type).
        """
        valid_types = {"square", "relu", "gelu", "polynomial"}
        if activation_type not in valid_types:
            raise ValueError(
                f"Unknown activation '{activation_type}'. "
                f"Choose from: {valid_types}"
            )
        if activation_type == "polynomial" and not coefficients:
            raise ValueError("polynomial activation requires coefficients")

        self._layers.append(("activation", (activation_type, coefficients)))
        logger.debug("Added activation layer: %s", activation_type)

    def add_layer_norm(
        self,
        gamma: np.ndarray,
        beta: np.ndarray,
        name: str = "layernorm",
    ):
        """Register a layer normalization layer.

        Parameters
        ----------
        gamma : np.ndarray
        beta : np.ndarray
        name : str
        """
        from .encrypted_nn import EncryptedLayerNorm

        layer = EncryptedLayerNorm(gamma, beta, name)
        self._layers.append(("layernorm", layer))

    def _apply_activation(self, ctx, ct_input, activation_config, rk):
        """Apply activation function to ciphertext.

        Parameters
        ----------
        ctx : CKKSContext
        ct_input : Ciphertext
        activation_config : tuple(str, list or None)
        rk : RelinKey

        Returns
        -------
        Ciphertext
        """
        from .encrypted_nn import (
            encrypted_approx_gelu,
            encrypted_approx_relu,
            encrypted_poly_activation,
            encrypted_square,
        )

        act_type, coefficients = activation_config

        if act_type == "square":
            return encrypted_square(ctx, ct_input, rk)
        elif act_type == "relu":
            return encrypted_approx_relu(ctx, ct_input, rk)
        elif act_type == "gelu":
            return encrypted_approx_gelu(ctx, ct_input, rk)
        elif act_type == "polynomial":
            return encrypted_poly_activation(ctx, ct_input, coefficients, rk)
        else:
            raise ValueError(f"Unknown activation: {act_type}")

    def estimate_depth(self) -> int:
        """Estimate total multiplicative depth needed.

        Returns
        -------
        int
            Estimated levels consumed by all registered layers.
        """
        depth = 0
        for layer_type, layer_config in self._layers:
            if layer_type == "linear":
                depth += 1  # multiply_plain
            elif layer_type == "activation":
                act_type, coefficients = layer_config
                if act_type == "square":
                    depth += 1
                elif act_type == "relu":
                    depth += 2  # degree-2
                elif act_type == "gelu":
                    depth += 3  # degree-3
                elif act_type == "polynomial":
                    depth += len(coefficients) - 1
            elif layer_type == "layernorm":
                depth += 1  # multiply_plain
        return depth

    def run(
        self,
        input_data: np.ndarray,
        decrypt: bool = True,
    ) -> InferenceResult:
        """Execute encrypted inference pipeline.

        Parameters
        ----------
        input_data : np.ndarray
            Plaintext input vector.
        decrypt : bool
            If True, decrypt output on client side.

        Returns
        -------
        InferenceResult
            Container with encrypted/decrypted outputs and timing.
        """
        self._ensure_context()
        ctx = self._ctx
        timing = {}
        layer_stats = []
        total_depth = 0

        # Check depth budget
        estimated_depth = self.estimate_depth()
        available_depth = self.coeff_modulus_levels - 1
        if estimated_depth > available_depth:
            logger.warning(
                "Estimated depth (%d) exceeds available levels (%d). "
                "Increase coeff_modulus_levels to at least %d.",
                estimated_depth, available_depth, estimated_depth + 1,
            )

        # Phase 1: Encrypt input
        t0 = time.perf_counter()
        input_list = input_data.flatten().tolist()

        # Pad to slot count
        slot_count = ctx.slot_count
        if len(input_list) < slot_count:
            input_list += [0.0] * (slot_count - len(input_list))

        pt_input = ctx.encode(input_list[:slot_count])
        ct_current = ctx.encrypt(self._pk, pt_input)
        timing["encrypt"] = time.perf_counter() - t0

        # Phase 2: Run layers
        t0 = time.perf_counter()

        # Track current representation: could be single ciphertext or list
        is_list = False
        ct_outputs = None

        for i, (layer_type, layer_config) in enumerate(self._layers):
            t_layer = time.perf_counter()
            layer_name = f"layer_{i}"

            if layer_type == "linear":
                layer = layer_config
                layer_name = layer.name

                if is_list:
                    # Apply linear to each ciphertext separately (fan-out)
                    new_outputs = []
                    for ct in ct_outputs:
                        new_outputs.extend(layer.forward(ctx, ct, self._rk))
                    ct_outputs = new_outputs
                else:
                    ct_outputs = layer.forward(ctx, ct_current, self._rk)
                    is_list = True

                total_depth += 1
                stats = layer.stats()

            elif layer_type == "activation":
                act_name = layer_config[0]
                layer_name = f"activation_{act_name}"

                if is_list:
                    ct_outputs = [
                        self._apply_activation(ctx, ct, layer_config, self._rk)
                        for ct in ct_outputs
                    ]
                else:
                    ct_current = self._apply_activation(
                        ctx, ct_current, layer_config, self._rk,
                    )

                depth = {"square": 1, "relu": 2, "gelu": 3}.get(
                    layer_config[0], len(layer_config[1] or []) - 1,
                )
                total_depth += depth
                stats = {"name": layer_name, "levels_consumed": depth}

            elif layer_type == "layernorm":
                layer = layer_config
                layer_name = layer.name

                if is_list:
                    ct_outputs = [
                        layer.forward(ctx, ct) for ct in ct_outputs
                    ]
                else:
                    ct_current = layer.forward(ctx, ct_current)

                total_depth += 1
                stats = layer.stats()

            else:
                raise ValueError(f"Unknown layer type: {layer_type}")

            layer_time = time.perf_counter() - t_layer
            stat_dict = {
                "name": layer_name,
                "time_s": round(layer_time, 4),
            }
            if hasattr(stats, "__dict__"):
                stat_dict.update(
                    {k: v for k, v in stats.__dict__.items() if k != "name"}
                )
            elif isinstance(stats, dict):
                stat_dict.update(stats)
            layer_stats.append(stat_dict)

            logger.info(
                "Layer %d (%s): %.4fs, depth so far: %d/%d",
                i, layer_name, layer_time, total_depth, available_depth,
            )

        timing["inference"] = time.perf_counter() - t0

        # Collect outputs
        if is_list:
            encrypted_outputs = ct_outputs
        else:
            encrypted_outputs = [ct_current]

        # Phase 3: Decrypt (client side)
        result = InferenceResult(
            encrypted_outputs=encrypted_outputs,
            timing=timing,
            layer_stats=layer_stats,
            total_levels_consumed=total_depth,
        )

        if decrypt:
            t0 = time.perf_counter()
            plaintext_values = []
            for ct in encrypted_outputs:
                pt = ctx.decrypt(self._sk, ct)
                values = ctx.decode(pt)
                # Take first meaningful value
                if isinstance(values, (list, np.ndarray)):
                    plaintext_values.append(float(values[0]))
                else:
                    plaintext_values.append(float(values))

            result.plaintext_outputs = np.array(plaintext_values)
            timing["decrypt"] = time.perf_counter() - t0

        # Summary
        total_time = sum(timing.values())
        timing["total"] = total_time
        logger.info(
            "Inference complete: %d layers, depth %d/%d, "
            "total %.3fs (encrypt: %.3fs, infer: %.3fs, decrypt: %.3fs)",
            len(self._layers),
            total_depth,
            available_depth,
            total_time,
            timing.get("encrypt", 0),
            timing.get("inference", 0),
            timing.get("decrypt", 0),
        )

        return result

    def summary(self) -> str:
        """Return a human-readable summary of the pipeline.

        Returns
        -------
        str
            Multi-line summary of pipeline configuration and layers.
        """
        lines = [
            "═" * 60,
            "  kctsb Encrypted Inference Pipeline",
            "═" * 60,
            f"  CKKS Parameters:",
            f"    Polynomial degree (N): {self.poly_modulus_degree}",
            f"    Slot count:            {self.slot_count}",
            f"    Coeff modulus levels:   {self.coeff_modulus_levels}",
            f"    Scale bits:            {self.scale_bits}",
            f"    Available depth:       {self.coeff_modulus_levels - 1}",
            "",
            f"  Registered Layers ({len(self._layers)}):",
        ]

        for i, (lt, lc) in enumerate(self._layers):
            if lt == "linear":
                lines.append(
                    f"    [{i}] Linear: "
                    f"{lc.name} ({lc.in_features}→{lc.out_features})"
                )
            elif lt == "activation":
                lines.append(f"    [{i}] Activation: {lc[0]}")
            elif lt == "layernorm":
                lines.append(f"    [{i}] LayerNorm: {lc.name}")

        est_depth = self.estimate_depth()
        avail = self.coeff_modulus_levels - 1
        status = "✓" if est_depth <= avail else "✗ INSUFFICIENT"
        lines.append("")
        lines.append(f"  Estimated depth: {est_depth} / {avail} {status}")
        lines.append("═" * 60)

        return "\n".join(lines)
