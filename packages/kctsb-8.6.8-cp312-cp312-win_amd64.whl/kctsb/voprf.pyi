"""Type stubs for ``kctsb.voprf`` — Verifiable Oblivious PRF (RFC 9497).

P-256 / SHA-256 ciphersuite implementation supporting OPRF, VOPRF (with
DLEQ proof) and POPRF (partially-oblivious) modes. Used by the kctsb-rag
demo for anonymous token issuance and L0 public-pool deduplication.
"""
from __future__ import annotations

__all__: list[str]


SUITE_ID: bytes
SEED_LEN: int    # 32
NK: int          # secret key length (32)
NS: int          # element length (33, compressed P-256)
NE: int          # evaluated element length
NH: int          # hash output length (32)


class Mode:
    """VOPRF protocol mode (RFC 9497).

    Members
    -------
    OPRF : 0x00 — basic oblivious PRF (no DLEQ proof).
    VOPRF : 0x01 — verifiable; signer publishes ``pk`` and DLEQ proof.
    POPRF : 0x02 — partially oblivious; takes a public ``info`` arg.
    """
    OPRF: Mode
    VOPRF: Mode
    POPRF: Mode

    @property
    def value(self) -> int: ...


def derive_key_pair(seed: bytes, info: bytes, mode: Mode) -> tuple[bytes, bytes]:
    """Deterministically derive ``(sk, pk)`` from a seed (RFC 9497 §3.2).

    Parameters
    ----------
    seed : bytes
        32-byte input keying material.
    info : bytes
        Domain-separation context.
    mode : Mode
        Protocol mode (affects DST tags).

    Returns
    -------
    tuple[bytes, bytes]
        ``(sk, pk)`` with ``len(sk)==NK`` and ``len(pk)==NS``.
    """


def blind(input: bytes, mode: Mode) -> tuple[bytes, bytes]:
    """Client-side blinding step.

    Parameters
    ----------
    input : bytes
        Arbitrary input to be obliviously evaluated.
    mode : Mode

    Returns
    -------
    tuple[bytes, bytes]
        ``(blind, blinded_element)``. The blind scalar must be retained
        by the client; the blinded element is sent to the server.
    """


def evaluate(sk: bytes, input: bytes, mode: Mode) -> bytes:
    """Server-side direct evaluation (debug / oracle mode).

    Returns
    -------
    bytes
        Final OPRF output (``NH`` bytes). Equivalent to the round-trip
        ``blind → evaluate_blinded → finalize`` chain.
    """


def oprf_evaluate_blinded(sk: bytes, blinded_element: bytes) -> bytes:
    """Server evaluates ``sk * blinded_element`` (OPRF mode)."""


def voprf_evaluate_blinded(
    sk: bytes,
    pk: bytes,
    blinded_element: bytes,
    mode: Mode,
) -> tuple[bytes, bytes]:
    """Server evaluates with DLEQ proof (VOPRF mode).

    Returns
    -------
    tuple[bytes, bytes]
        ``(evaluated_element, proof)``. Proof is verified by client
        with ``verify_proof``.
    """


def poprf_evaluate(sk: bytes, input: bytes, info: bytes) -> bytes:
    """POPRF direct evaluation given public ``info``."""


def verify_proof(
    pk: bytes,
    blinded_element: bytes,
    evaluated_element: bytes,
    proof: bytes,
) -> bool:
    """Verify the DLEQ proof attached to a VOPRF response."""


def oprf_finalize(input: bytes, blind: bytes, evaluated_element: bytes) -> bytes:
    """Client-side unblind & hash to produce the final 32-byte output.

    Parameters
    ----------
    input : bytes
        The original (unblinded) input passed to ``blind``.
    blind : bytes
        Blind scalar from ``blind`` step.
    evaluated_element : bytes
        Element returned by the server.

    Returns
    -------
    bytes
        ``NH``-byte deterministic OPRF output, identical regardless of
        which honest server processed the request.
    """
