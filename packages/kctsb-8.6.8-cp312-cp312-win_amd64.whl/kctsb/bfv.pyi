"""Type stubs for ``kctsb.bfv`` — BFV homomorphic encryption.

Provides BFV scheme primitives, batch (SIMD) encoding, and three
high-level building blocks (Garbled-Comparison, HE-sort,
HE-insertion-sorted) used by privacy-preserving DB pipelines.
"""
from __future__ import annotations

from typing import Sequence

__all__: list[str]


# ---------------------------------------------------------------------------
# Core types
# ---------------------------------------------------------------------------
class Context:
    """BFV encryption context (poly degree N, modulus chain, plaintext mod)."""

    @property
    def poly_modulus_degree(self) -> int: ...
    @property
    def plaintext_modulus(self) -> int: ...


class SecretKey: ...
class PublicKey: ...
class RelinKey: ...


class Ciphertext:
    """BFV ciphertext (NTT domain)."""
    @property
    def size(self) -> int: ...


class BatchEncoder:
    """SIMD batch encoder using NTT slot packing.

    Examples
    --------
    >>> from kctsb import bfv
    >>> ctx = bfv.context_n8192(plaintext_modulus=1024)
    >>> enc = bfv.BatchEncoder(ctx)
    >>> pt = enc.encode([1, 2, 3, 4])
    >>> enc.decode(pt)[:4]
    [1, 2, 3, 4]
    """
    def __init__(self, ctx: Context) -> None: ...
    def encode(self, values: Sequence[int]) -> object: ...
    def decode(self, plaintext: object) -> list[int]: ...
    @property
    def slot_count(self) -> int: ...


# ---------------------------------------------------------------------------
# Context factories
# ---------------------------------------------------------------------------
def context_toy(plaintext_modulus: int = 256) -> Context: ...
def context_n4096(plaintext_modulus: int = 256) -> Context: ...
def context_n8192(plaintext_modulus: int = 256) -> Context: ...
def context_n16384(plaintext_modulus: int = 256) -> Context: ...


# ---------------------------------------------------------------------------
# Key generation
# ---------------------------------------------------------------------------
def generate_secret_key(ctx: Context) -> SecretKey: ...
def generate_public_key(ctx: Context, sk: SecretKey) -> PublicKey: ...
def generate_relin_key(ctx: Context, sk: SecretKey, decomp_base: int = ...) -> RelinKey: ...
def generate_keys(ctx: Context, decomp_base: int = ...) -> tuple[SecretKey, PublicKey, RelinKey]: ...


# ---------------------------------------------------------------------------
# Encrypt / decrypt
# ---------------------------------------------------------------------------
def encrypt(ctx: Context, plaintext: Sequence[int], pk: PublicKey) -> Ciphertext: ...
def encrypt_int(ctx: Context, value: int, pk: PublicKey) -> Ciphertext: ...
def decrypt(ctx: Context, ct: Ciphertext, sk: SecretKey) -> list[int]: ...
def decrypt_int(ctx: Context, ct: Ciphertext, sk: SecretKey) -> int: ...
def get_delta(ctx: Context) -> list[int]: ...


# ---------------------------------------------------------------------------
# Homomorphic operations
# ---------------------------------------------------------------------------
def add(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext: ...
def sub(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext: ...
def negate(ctx: Context, ct: Ciphertext) -> Ciphertext: ...
def multiply(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext: ...
def multiply_relin(
    ctx: Context, ct1: Ciphertext, ct2: Ciphertext, rk: RelinKey
) -> Ciphertext: ...
def relinearize(ctx: Context, ct: Ciphertext, rk: RelinKey) -> Ciphertext: ...
def add_plain(ctx: Context, ct: Ciphertext, plain: Sequence[int]) -> Ciphertext: ...
def multiply_plain(ctx: Context, ct: Ciphertext, plain: Sequence[int]) -> Ciphertext: ...


# ---------------------------------------------------------------------------
# High-level: HE sorting + Garbled Comparison
# ---------------------------------------------------------------------------
class SortAlgorithm:
    """Algorithm selection for ``he_sort``."""
    BITONIC: SortAlgorithm
    INSERTION: SortAlgorithm
    RADIX: SortAlgorithm
    MERGE: SortAlgorithm
    @property
    def value(self) -> int: ...


class Acceleration:
    """Hardware acceleration hint for ``he_sort``."""
    AUTO: Acceleration
    CPU: Acceleration
    GPU: Acceleration
    @property
    def value(self) -> int: ...


class SortConfig:
    algorithm: SortAlgorithm
    acceleration: Acceleration
    def __init__(self, algorithm: SortAlgorithm = ..., acceleration: Acceleration = ...) -> None: ...


class SortResult:
    sorted_values: list[int]
    elapsed_ms: float


def he_sort(values: Sequence[int], encoder: BatchEncoder, config: SortConfig | None = ...) -> SortResult: ...


class InsertSortStrategy:
    """Strategy for inserting new values into already-sorted encrypted data."""
    LINEAR: InsertSortStrategy
    BINARY: InsertSortStrategy
    @property
    def value(self) -> int: ...


class InsertSortConfig:
    strategy: InsertSortStrategy
    def __init__(self, strategy: InsertSortStrategy = ...) -> None: ...


class InsertSortResult:
    sorted_values: list[int]
    elapsed_ms: float


def he_insert_sorted(
    sorted_values: Sequence[int],
    new_value: int,
    encoder: BatchEncoder,
    config: InsertSortConfig | None = ...,
) -> InsertSortResult: ...


def he_merge_sorted(
    sorted_a: Sequence[int],
    sorted_b: Sequence[int],
    encoder: BatchEncoder,
) -> SortResult: ...


def insertion_sort_encrypted(
    values: Sequence[int],
    ctx: Context,
    encoder: BatchEncoder,
) -> SortResult: ...


def simd_radix_sort(values: Sequence[int], encoder: BatchEncoder) -> SortResult: ...


def gc_bitonic_sort(values: Sequence[int], ctx: Context) -> SortResult: ...


class GCCompareResult:
    """Result of a Garbled-Circuit ciphertext comparison."""
    a_lt_b: bool
    elapsed_ms: float


class GarbledComparisonCircuit:
    """Yao's Garbled Circuit for non-interactive ciphertext comparison."""

    def __init__(self, bit_width: int = 32) -> None: ...
    def compare(self, a_value: int, b_value: int) -> GCCompareResult: ...


def gc_batch_compare(
    a_values: Sequence[int],
    b_values: Sequence[int],
) -> list[GCCompareResult]: ...
