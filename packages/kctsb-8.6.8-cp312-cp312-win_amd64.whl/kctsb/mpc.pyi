"""Type stubs for ``kctsb.mpc`` — Multi-Party Computation primitives.

Includes Replicated 3-party secret sharing (REP3) and Garbled-Circuit
benchmarking (single & parallel).
"""
from __future__ import annotations

from typing import Sequence

__all__: list[str]


class GCResult:
    """Garbled-Circuit benchmark result.

    Attributes
    ----------
    num_and_gates : int
    elapsed_ms : float
    throughput_gates_per_sec : float
    """
    num_and_gates: int
    elapsed_ms: float
    throughput_gates_per_sec: float


def gc_benchmark(num_and_gates: int = 1_000_000) -> GCResult:
    """Single-threaded Garbled-Circuit AND-gate evaluation benchmark."""


def gc_benchmark_parallel(
    total_and_gates: int = 1_000_000,
    num_threads: int = 4,
) -> GCResult:
    """Multi-threaded Garbled-Circuit benchmark."""


def rep3_share(secret: int) -> list[tuple[int, int]]:
    """Split a secret into 3 replicated shares.

    Returns
    -------
    list[tuple[int, int]]
        Three shares; each party holds one tuple.
    """


def rep3_share_batch(secrets: Sequence[int]) -> list[list[tuple[int, int]]]:
    """Batched REP3 sharing (independent secrets)."""


def rep3_reconstruct(shares: Sequence[tuple[int, int]]) -> int:
    """Recover the secret from 3 replicated shares."""


def rep3_reconstruct_batch(shares: Sequence[Sequence[tuple[int, int]]]) -> list[int]:
    """Batched REP3 reconstruction."""
