"""Type stubs for ``kctsb.ecc_blind_sign`` — Clause Blind Schnorr (ROS-resistant).

A blind signature scheme over Curve25519 / Ristretto255 that hides the
message from the signer while remaining ROS-attack resistant via the
Clause-Blind Schnorr construction (Fuchsbauer, Plouviez, Seurin 2020).

Typical use cases in kctsb:

* anonymous tokens for L0 public-pool access (kctsb-rag privacy demo)
* blind credential issuance for VOPRF-bridged anonymous APIs
* unlinkable receipts for confidential auditing

Examples
--------
>>> from kctsb import ecc_blind_sign as bs
>>> sk, pk = bs.keygen(b"\\x00" * 32)
>>> commit_pub, commit_state = bs.signer_commit()
>>> challenge, blind_state = bs.client_blind(commit_pub, pk, b"order-id-42")
>>> response = bs.signer_sign(sk, commit_state, challenge)
>>> signature = bs.client_unblind(blind_state, response)
>>> bs.verify(pk, b"order-id-42", signature)
True
"""
from __future__ import annotations

__all__: list[str]

# ---------------------------------------------------------------------------
# Constants (lengths in bytes)
# ---------------------------------------------------------------------------
SCALAR_LEN: int        # 32
PK_LEN: int            # 32 (compressed Ristretto)
SK_LEN: int            # 32
COMMIT_PUB_LEN: int    # 64 (two compressed points)
COMMIT_STATE_LEN: int  # 64 (two scalars, signer-private)
BLIND_STATE_LEN: int   # 192
CHALLENGE_LEN: int     # 32
RESPONSE_LEN: int      # 32
SIGNATURE_LEN: int     # 64

CHALLENGE_DST: bytes   # domain separation tag for hash-to-scalar
KEYGEN_DST: bytes      # domain separation tag for keygen


def keygen(seed: bytes) -> tuple[bytes, bytes]:
    """Deterministically derive a (sk, pk) pair from a 32-byte seed.

    Parameters
    ----------
    seed : bytes
        32 bytes of high-entropy randomness (e.g., from ``os.urandom``).

    Returns
    -------
    tuple[bytes, bytes]
        ``(sk, pk)`` where ``len(sk)==SK_LEN`` and ``len(pk)==PK_LEN``.

    Examples
    --------
    >>> import os
    >>> sk, pk = keygen(os.urandom(32))
    >>> len(pk)
    32
    """


def signer_commit() -> tuple[bytes, bytes]:
    """Generate the signer's two-point commitment (round 1).

    Returns
    -------
    tuple[bytes, bytes]
        ``(commit_pub, commit_state)``. ``commit_pub`` is sent to the
        client; ``commit_state`` MUST be kept private by the signer
        until ``signer_sign`` is invoked, then discarded.
    """


def client_blind(commit_pub: bytes, pk: bytes, message: bytes) -> tuple[bytes, bytes]:
    """Client-side blinding (round 2).

    Parameters
    ----------
    commit_pub : bytes
        ``COMMIT_PUB_LEN`` bytes from ``signer_commit``.
    pk : bytes
        Signer's public key.
    message : bytes
        Arbitrary message the client wants signed without revealing.

    Returns
    -------
    tuple[bytes, bytes]
        ``(challenge, blind_state)``. ``challenge`` is sent to signer;
        ``blind_state`` must be kept by the client for ``client_unblind``.
    """


def signer_sign(sk: bytes, commit_state: bytes, challenge: bytes) -> bytes:
    """Signer responds to the challenge (round 3).

    Parameters
    ----------
    sk : bytes
        Signer secret key.
    commit_state : bytes
        State produced by ``signer_commit``; consumed (single-use).
    challenge : bytes
        Challenge from client.

    Returns
    -------
    bytes
        ``RESPONSE_LEN``-byte response.
    """


def client_unblind(blind_state: bytes, response: bytes) -> bytes:
    """Unblind the signer's response into a final signature.

    Parameters
    ----------
    blind_state : bytes
        State produced by ``client_blind``.
    response : bytes
        Response from ``signer_sign``.

    Returns
    -------
    bytes
        ``SIGNATURE_LEN``-byte signature verifiable by anyone with ``pk``
        but unlinkable to the signing session.
    """


def verify(pk: bytes, message: bytes, signature: bytes) -> bool:
    """Verify a Clause-Blind-Schnorr signature.

    Parameters
    ----------
    pk : bytes
        Signer public key.
    message : bytes
        Message that was originally blinded.
    signature : bytes
        Output of ``client_unblind``.

    Returns
    -------
    bool
        ``True`` iff the signature is valid.
    """
