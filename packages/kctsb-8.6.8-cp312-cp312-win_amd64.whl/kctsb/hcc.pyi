"""Type stubs for ``kctsb.hcc`` — Hybrid Confidential Computing.

A unified Session API automatically selecting BFV / BGV / CKKS / DP / GC
based on a (Scenario, DataTier) tuple. Designed for production
confidential-computing workloads with three sensitivity tiers.
"""
from __future__ import annotations

from typing import Sequence

__all__: list[str]


class DataTier:
    """Data sensitivity tier for three-tier encryption."""
    NON_PERSONAL: DataTier
    MODERATE: DataTier
    SENSITIVE: DataTier
    @property
    def value(self) -> int: ...


# Module-level aliases re-exported on the stub.
NON_PERSONAL: DataTier
MODERATE: DataTier
SENSITIVE: DataTier


class Scenario:
    """HCC computation scenario."""
    EQUALITY: Scenario
    COMPARISON: Scenario
    SORTING: Scenario
    STATISTICS: Scenario
    BLINDING: Scenario
    DP_NOISE: Scenario
    @property
    def value(self) -> int: ...


# Module-level aliases.
EQUALITY: Scenario
COMPARISON: Scenario
SORTING: Scenario
STATISTICS: Scenario
BLINDING: Scenario
DP_NOISE: Scenario


class Config:
    """HCC session configuration."""
    tier: DataTier
    scenario: Scenario
    epsilon: float
    delta: float

    def __init__(
        self,
        tier: DataTier = ...,
        scenario: Scenario = ...,
        epsilon: float = ...,
        delta: float = ...,
    ) -> None: ...


class EncryptedValue:
    """Opaque encrypted value handle."""
    @property
    def tier(self) -> DataTier: ...


class Session:
    """HCC Session — unified API for all 6 confidential-computing scenarios.

    Examples
    --------
    >>> from kctsb import hcc
    >>> s = hcc.Session(hcc.Config(tier=hcc.SENSITIVE, scenario=hcc.EQUALITY))
    >>> ev = s.encrypt(42)
    >>> s.equals(ev, 42)
    True
    """
    def __init__(self, config: Config) -> None: ...
    def encrypt(self, value: int) -> EncryptedValue: ...
    def decrypt(self, ev: EncryptedValue) -> int: ...
    def equals(self, ev: EncryptedValue, value: int) -> bool: ...
    def less_than(self, a: EncryptedValue, b: EncryptedValue) -> bool: ...
    def sort(self, evs: Sequence[EncryptedValue]) -> list[EncryptedValue]: ...
    def sum(self, evs: Sequence[EncryptedValue]) -> EncryptedValue: ...
