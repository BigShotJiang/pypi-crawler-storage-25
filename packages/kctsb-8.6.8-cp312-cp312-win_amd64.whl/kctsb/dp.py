"""
kctsb.dp - Differential Privacy Mechanisms

Provides Laplace, Gaussian, and Exponential differential privacy mechanisms
with privacy budget tracking. Integrates with CKKS for encrypted data
processing with formal (ε, δ)-DP guarantees.

Architecture:
    DPMechanism (Python) → _kctsb_core.dp (C++ pybind11) → dp_mechanism.cpp (C++)

Usage:
    >>> from kctsb.dp import DPMechanism, DPBudget
    >>> noise = DPMechanism.laplace(sensitivity=1.0, epsilon=0.1)
    >>> noisy_data = DPMechanism.add_noise([1.0, 2.0, 3.0], sensitivity=1.0, epsilon=0.1)
    >>> budget = DPBudget(total_epsilon=1.0, total_delta=1e-5)
    >>> budget.consume(epsilon=0.1)
    >>> print(budget.remaining)

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import logging
import math
from typing import List, Optional, Union

import numpy as np

logger = logging.getLogger(__name__)

# Try importing compiled core
try:
    from ._kctsb_core import dp as _core
    _HAS_CORE = True
    # Re-export low-level C functions so users can call them via kctsb.dp directly
    add_noise_vector = _core.add_noise_vector
    gaussian_noise = _core.gaussian_noise
    laplace_noise = _core.laplace_noise
except ImportError:
    _HAS_CORE = False
    add_noise_vector = None  # type: ignore[assignment]
    gaussian_noise = None    # type: ignore[assignment]
    laplace_noise = None     # type: ignore[assignment]
    logger.warning("kctsb C++ core not available for DP; using pure-Python fallback.")


class DPMechanism:
    """Differential privacy noise generation mechanisms.

    Provides static methods for generating calibrated noise to achieve
    (ε, δ)-differential privacy guarantees.

    All methods use cryptographically secure random number generation
    when the C++ core is available; falls back to numpy.random otherwise.
    """

    @staticmethod
    def laplace(sensitivity: float, epsilon: float) -> float:
        """Generate Laplace noise for ε-differential privacy.

        Parameters
        ----------
        sensitivity : float
            L1 sensitivity (Δf) of the query function.
        epsilon : float
            Privacy parameter ε (smaller → more private).

        Returns
        -------
        float
            Laplace noise sample with scale b = sensitivity / epsilon.

        Raises
        ------
        ValueError
            If sensitivity ≤ 0 or epsilon ≤ 0.
        """
        if sensitivity <= 0.0:
            raise ValueError(f"sensitivity must be > 0, got {sensitivity}")
        if epsilon <= 0.0:
            raise ValueError(f"epsilon must be > 0, got {epsilon}")

        if _HAS_CORE:
            return _core.laplace_noise(sensitivity, epsilon)
        # Pure-Python fallback
        scale = sensitivity / epsilon
        return float(np.random.laplace(0.0, scale))

    @staticmethod
    def gaussian(
        sensitivity: float,
        epsilon: float,
        delta: float = 1e-5,
    ) -> float:
        """Generate Gaussian noise for (ε, δ)-differential privacy.

        Uses the analytic Gaussian mechanism: σ = √(2·ln(1.25/δ)) · Δf / ε.

        Parameters
        ----------
        sensitivity : float
            L2 sensitivity (Δ₂f) of the query function.
        epsilon : float
            Privacy parameter ε.
        delta : float
            Privacy parameter δ (probability of privacy breach).

        Returns
        -------
        float
            Gaussian noise sample with calibrated standard deviation.

        Raises
        ------
        ValueError
            If any parameter is non-positive, or delta ≥ 1.
        """
        if sensitivity <= 0.0:
            raise ValueError(f"sensitivity must be > 0, got {sensitivity}")
        if epsilon <= 0.0:
            raise ValueError(f"epsilon must be > 0, got {epsilon}")
        if delta <= 0.0 or delta >= 1.0:
            raise ValueError(f"delta must be in (0, 1), got {delta}")

        if _HAS_CORE:
            return _core.gaussian_noise(sensitivity, epsilon, delta)
        # Pure-Python fallback
        sigma = math.sqrt(2.0 * math.log(1.25 / delta)) * sensitivity / epsilon
        return float(np.random.normal(0.0, sigma))

    @staticmethod
    def add_noise(
        data: Union[List[float], np.ndarray],
        sensitivity: float,
        epsilon: float,
        mechanism: str = "laplace",
        delta: float = 1e-5,
    ) -> np.ndarray:
        """Add calibrated noise to a data vector.

        Parameters
        ----------
        data : list[float] or np.ndarray
            Input data vector.
        sensitivity : float
            Query sensitivity (L1 for Laplace, L2 for Gaussian).
        epsilon : float
            Privacy parameter ε.
        mechanism : str
            Either "laplace" or "gaussian".
        delta : float
            Privacy parameter δ (only used for Gaussian).

        Returns
        -------
        np.ndarray
            Noisy data vector satisfying differential privacy.
        """
        data_arr = np.asarray(data, dtype=np.float64)

        if mechanism == "laplace":
            if _HAS_CORE:
                data_list = data_arr.tolist()
                noisy = _core.add_noise_vector(
                    data_list, sensitivity, epsilon, "laplace"
                )
                return np.array(noisy, dtype=np.float64)
            scale = sensitivity / epsilon
            noise = np.random.laplace(0.0, scale, size=data_arr.shape)
            return data_arr + noise

        elif mechanism == "gaussian":
            if _HAS_CORE:
                data_list = data_arr.tolist()
                noisy = _core.add_noise_vector(
                    data_list, sensitivity, epsilon, "gaussian"
                )
                return np.array(noisy, dtype=np.float64)
            sigma = math.sqrt(2.0 * math.log(1.25 / delta)) * sensitivity / epsilon
            noise = np.random.normal(0.0, sigma, size=data_arr.shape)
            return data_arr + noise

        else:
            raise ValueError(f"Unknown mechanism: {mechanism!r}. Use 'laplace' or 'gaussian'.")

    @staticmethod
    def compute_sigma(
        sensitivity: float,
        epsilon: float,
        delta: float = 1e-5,
    ) -> float:
        """Compute the Gaussian noise standard deviation for given DP params.

        Parameters
        ----------
        sensitivity : float
        epsilon : float
        delta : float

        Returns
        -------
        float
            Standard deviation σ.
        """
        return math.sqrt(2.0 * math.log(1.25 / delta)) * sensitivity / epsilon


class DPBudget:
    """Differential privacy budget tracker.

    Implements sequential composition: each query consumes a portion
    of the total privacy budget (ε, δ).

    Parameters
    ----------
    total_epsilon : float
        Total privacy budget ε.
    total_delta : float
        Total privacy budget δ.

    Examples
    --------
    >>> budget = DPBudget(total_epsilon=1.0, total_delta=1e-5)
    >>> budget.consume(0.1, 1e-6)
    >>> budget.remaining_epsilon
    0.9
    >>> budget.is_exhausted
    False
    """

    def __init__(self, total_epsilon: float, total_delta: float = 0.0) -> None:
        if total_epsilon <= 0.0:
            raise ValueError(f"total_epsilon must be > 0, got {total_epsilon}")
        if total_delta < 0.0:
            raise ValueError(f"total_delta must be >= 0, got {total_delta}")

        self._total_epsilon = total_epsilon
        self._total_delta = total_delta
        self._used_epsilon = 0.0
        self._used_delta = 0.0
        self._query_count = 0

        if _HAS_CORE:
            self._core_budget = _core.DPBudget(total_epsilon, total_delta)
        else:
            self._core_budget = None

        logger.info(
            "DPBudget created: ε=%.4f, δ=%.2e", total_epsilon, total_delta
        )

    def consume(self, epsilon: float, delta: float = 0.0) -> None:
        """Consume a portion of the privacy budget.

        Parameters
        ----------
        epsilon : float
            Privacy cost of this query.
        delta : float
            Delta cost of this query.

        Raises
        ------
        RuntimeError
            If budget would be exceeded.
        """
        if self._used_epsilon + epsilon > self._total_epsilon + 1e-12:
            raise RuntimeError(
                f"Privacy budget exceeded: need ε={epsilon}, "
                f"remaining ε={self.remaining_epsilon:.6f}"
            )
        if self._used_delta + delta > self._total_delta + 1e-12:
            raise RuntimeError(
                f"Delta budget exceeded: need δ={delta}, "
                f"remaining δ={self.remaining_delta:.2e}"
            )

        self._used_epsilon += epsilon
        self._used_delta += delta
        self._query_count += 1

        if self._core_budget is not None:
            self._core_budget.consume(epsilon, delta)

        logger.debug(
            "Budget consumed: ε=%.4f, δ=%.2e (remaining: ε=%.4f, δ=%.2e)",
            epsilon, delta, self.remaining_epsilon, self.remaining_delta,
        )

    @property
    def remaining_epsilon(self) -> float:
        """Remaining epsilon budget."""
        return max(0.0, self._total_epsilon - self._used_epsilon)

    @property
    def remaining_delta(self) -> float:
        """Remaining delta budget."""
        return max(0.0, self._total_delta - self._used_delta)

    @property
    def is_exhausted(self) -> bool:
        """Whether the privacy budget is fully consumed."""
        return self._used_epsilon >= self._total_epsilon - 1e-12

    @property
    def query_count(self) -> int:
        """Number of queries made."""
        return self._query_count

    def __repr__(self) -> str:
        return (
            f"DPBudget(ε={self.remaining_epsilon:.4f}/{self._total_epsilon:.4f}, "
            f"δ={self.remaining_delta:.2e}/{self._total_delta:.2e}, "
            f"queries={self._query_count})"
        )
