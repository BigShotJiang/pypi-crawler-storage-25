"""Type stubs for ``kctsb.pir`` — Private Information Retrieval (FHE-based).

Native PIR over BFV / BGV / CKKS with a unified ``NativePIR`` API.
The client encrypts a one-hot selector vector; the server homomorphically
inner-products it with the database and returns one ciphertext that the
client decrypts to obtain ``database[target_index]`` — the server learning
nothing about ``target_index``.
"""
from __future__ import annotations

from typing import Sequence

__all__: list[str]


class PIRScheme:
    """FHE scheme for Native PIR."""
    BFV: PIRScheme
    BGV: PIRScheme
    CKKS: PIRScheme

    @property
    def value(self) -> int: ...


# Convenience aliases re-exported at module level.
BFV: PIRScheme
BGV: PIRScheme
CKKS: PIRScheme


class PIRConfig:
    """Configuration for ``NativePIR``.

    Attributes
    ----------
    poly_modulus_degree : int
        FHE ring dimension N (4096 / 8192 / 16384).
    plaintext_modulus : int
        Plaintext modulus t (BFV/BGV) or scale level proxy (CKKS).
    scheme : PIRScheme
        Underlying FHE scheme.
    """
    poly_modulus_degree: int
    plaintext_modulus: int
    scheme: PIRScheme

    def __init__(
        self,
        poly_modulus_degree: int = ...,
        plaintext_modulus: int = ...,
        scheme: PIRScheme = ...,
    ) -> None: ...


class PIRResult:
    """Result of a single PIR query.

    Attributes
    ----------
    value : int
        Recovered plaintext value at ``target_index``.
    encryption_ms : float
    server_ms : float
    decryption_ms : float
        Per-stage timings (milliseconds).
    """
    value: int
    encryption_ms: float
    server_ms: float
    decryption_ms: float


class NativePIR:
    """Native FHE-based Private Information Retrieval.

    Examples
    --------
    >>> from kctsb import pir
    >>> db = [10, 20, 30, 40, 50]
    >>> engine = pir.NativePIR(pir.PIRConfig(poly_modulus_degree=8192,
    ...                                     plaintext_modulus=1024,
    ...                                     scheme=pir.BFV))
    >>> engine.set_database(db)
    >>> r = engine.query(target_index=2)
    >>> r.value
    30
    """

    def __init__(self, config: PIRConfig) -> None: ...

    def set_database(self, db: Sequence[int]) -> None:
        """Upload the (plaintext) database to the engine."""

    def query(self, target_index: int) -> PIRResult:
        """Retrieve ``database[target_index]`` obliviously.

        The server sees only an FHE-encrypted one-hot vector of length
        ``len(db)`` and cannot determine ``target_index``.
        """

    def batch_query(self, target_indices: Sequence[int]) -> list[PIRResult]:
        """Batch multiple oblivious lookups (independent queries)."""

    @property
    def database_size(self) -> int: ...

    @property
    def scheme(self) -> PIRScheme: ...


def pir_query(
    database: Sequence[int],
    target_index: int,
    config: PIRConfig | None = ...,
) -> PIRResult:
    """One-shot PIR convenience wrapper (builds engine + queries once)."""
