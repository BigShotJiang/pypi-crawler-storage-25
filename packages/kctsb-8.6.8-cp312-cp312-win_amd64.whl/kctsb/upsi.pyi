"""Type stubs for ``kctsb.upsi`` — Unbalanced PSI, SSE & OPE.

Bundles three searchable / matching primitives:

* :class:`UnbalancedPSI` — Bloom-PSI / Cuckoo-OPRF / Partition-OT for
  highly asymmetric set sizes (``|client| << |server|``).
* :class:`SSE` — Symmetric Searchable Encryption with HMAC-tagged
  inverted index. Used by the kctsb-rag L1-Exact lane.
* :class:`OPE` — Order-Preserving Encryption supporting range queries.
"""
from __future__ import annotations

from typing import Sequence

__all__: list[str]


# ---------------------------------------------------------------------------
# Unbalanced PSI
# ---------------------------------------------------------------------------
class UPSIStrategy:
    """Unbalanced PSI protocol strategy."""
    BLOOM_PSI: UPSIStrategy
    CUCKOO_OPRF: UPSIStrategy
    PARTITION_OT: UPSIStrategy

    @property
    def value(self) -> int: ...


# Convenience module-level aliases.
BLOOM_PSI: UPSIStrategy
CUCKOO_OPRF: UPSIStrategy
PARTITION_OT: UPSIStrategy


class UPSIConfig:
    """Configuration for Unbalanced PSI."""
    strategy: UPSIStrategy
    false_positive_rate: float
    bloom_bits_per_item: int

    def __init__(
        self,
        strategy: UPSIStrategy = ...,
        false_positive_rate: float = ...,
        bloom_bits_per_item: int = ...,
    ) -> None: ...


class UPSIResult:
    """Outcome of an Unbalanced PSI run."""
    intersection: list[int]
    client_ms: float
    server_ms: float
    bytes_sent: int
    bytes_received: int


class UnbalancedPSI:
    """Unbalanced PSI for asymmetric set sizes.

    Examples
    --------
    >>> from kctsb import upsi
    >>> client_set = [1, 2, 3]
    >>> server_set = list(range(10000))
    >>> engine = upsi.UnbalancedPSI(upsi.UPSIConfig(strategy=upsi.BLOOM_PSI))
    >>> r = engine.run(client_set, server_set)
    >>> sorted(r.intersection)
    [1, 2, 3]
    """

    def __init__(self, config: UPSIConfig) -> None: ...

    def run(
        self,
        client_set: Sequence[int],
        server_set: Sequence[int],
    ) -> UPSIResult: ...


def unbalanced_psi(
    client_set: Sequence[int],
    server_set: Sequence[int],
    config: UPSIConfig | None = ...,
) -> UPSIResult:
    """One-shot Unbalanced PSI convenience wrapper."""


# ---------------------------------------------------------------------------
# Symmetric Searchable Encryption (SSE)
# ---------------------------------------------------------------------------
class SSEIndexEntry:
    """A keyword-document pair before tagging."""
    keyword: bytes
    doc_id: int

    def __init__(self, keyword: bytes, doc_id: int) -> None: ...


class SSESearchResult:
    """SSE search result (list of doc_ids matching a tagged keyword)."""
    doc_ids: list[int]
    server_ms: float


class SSE:
    """Symmetric Searchable Encryption with HMAC inverted index.

    The client tags each keyword as ``HMAC(k_sse, kw)[:16]``; the
    server stores ``tag → list[doc_id]`` and can answer search queries
    without learning the keyword plaintext.

    Examples
    --------
    >>> from kctsb import upsi
    >>> sse = upsi.SSE(key=b"\\x00" * 32)
    >>> sse.add(upsi.SSEIndexEntry(b"flight", 100))
    >>> sse.add(upsi.SSEIndexEntry(b"flight", 105))
    >>> r = sse.search(b"flight")
    >>> sorted(r.doc_ids)
    [100, 105]
    """

    def __init__(self, key: bytes) -> None:
        """Create an SSE channel keyed by 32-byte HMAC key."""

    def add(self, entry: SSEIndexEntry) -> None: ...
    def add_batch(self, entries: Sequence[SSEIndexEntry]) -> None: ...
    def search(self, keyword: bytes) -> SSESearchResult: ...
    def tag(self, keyword: bytes) -> bytes:
        """Return the 16-byte HMAC tag without performing a lookup."""


# ---------------------------------------------------------------------------
# Order-Preserving Encryption (OPE)
# ---------------------------------------------------------------------------
class OPEResult:
    """Output of an OPE encryption."""
    ciphertext: int
    encryption_ms: float


class OPE:
    """Order-Preserving Encryption.

    Encrypts integers such that ``a < b`` iff ``Enc(a) < Enc(b)``,
    enabling range queries on encrypted columns.

    Examples
    --------
    >>> from kctsb import upsi
    >>> ope = upsi.OPE(key=b"\\x00" * 32, domain_bits=32, range_bits=64)
    >>> c1 = ope.encrypt(100).ciphertext
    >>> c2 = ope.encrypt(200).ciphertext
    >>> c1 < c2
    True
    """

    def __init__(self, key: bytes, domain_bits: int = ..., range_bits: int = ...) -> None: ...
    def encrypt(self, value: int) -> OPEResult: ...
    def decrypt(self, ciphertext: int) -> int: ...
