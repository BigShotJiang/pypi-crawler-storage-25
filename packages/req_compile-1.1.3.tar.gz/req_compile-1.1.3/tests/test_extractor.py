import contextlib
import io
import os
import tarfile
from pathlib import Path

import pytest

import req_compile.metadata.extractor
from req_compile.metadata.extractor import TarExtractor


@contextlib.contextmanager
def temp_cwd(new_cwd):
    old_cwd = os.getcwd()
    try:
        os.chdir(new_cwd)
        yield new_cwd
    finally:
        os.chdir(old_cwd)


@pytest.mark.parametrize("archive_fixture", ["mock_targz", "mock_zip", "mock_zip"])
def test_extractor(archive_fixture, mock_targz, mock_zip):
    directory = "comtypes-1.1.7"
    if archive_fixture == "mock_targz":
        archive = mock_targz(directory)
    elif archive_fixture == "mock_zip":
        archive = mock_zip(directory)
    else:
        archive = os.path.abspath(os.path.join("source-packages", directory))

    if archive_fixture == "mock_targz":
        extractor = req_compile.metadata.extractor.TarExtractor("gz", archive)
        prefix = directory + "/"
    elif archive_fixture == "mock_zip":
        extractor = req_compile.metadata.extractor.ZipExtractor(archive)
        prefix = directory + "/"
    else:
        extractor = req_compile.metadata.extractor.NonExtractor(archive)
        prefix = ""

    with contextlib.closing(extractor):
        all_names = set(extractor.names())
        assert all_names == {
            prefix + "README",
            prefix + "setup.py",
            prefix + "comtypes/__init__.py",
            prefix + "test/setup.py",
        }

        prefix = extractor.fake_root + os.sep + prefix

        assert extractor.contents(prefix + "README") == "README CONTENTS"
        with extractor.open(prefix + "README") as handle:
            assert handle.read(2) == "RE"
        assert extractor.contents(prefix + "README") == "README CONTENTS"
        assert extractor.exists(prefix + "test")
        assert extractor.exists(prefix + "test/setup.py")
        assert not extractor.exists(prefix + "test/setup2.py")


def test_wrapped_encoding(mock_targz, tmp_path):
    directory = "comtypes-1.1.7"
    archive: TarExtractor = TarExtractor("gz", mock_targz(directory))

    root = str(tmp_path)
    archive.fake_root = root
    with temp_cwd(root):
        with archive.open("comtypes-1.1.7/setup.py", "rb") as bin_file:
            assert isinstance(bin_file.read(1), bytes)
        with archive.open("comtypes-1.1.7/setup.py", "r") as ascii_file:
            assert isinstance(ascii_file.read(1), str)
        with archive.open(
            "comtypes-1.1.7/setup.py", "r", encoding="utf-8"
        ) as utf8_file:
            assert isinstance(utf8_file.read(1), str)


def test_default_encoding_handles_non_ascii(mock_targz, tmp_path):
    archive: TarExtractor = TarExtractor("gz", mock_targz("tar-utf8-1.1.0"))
    root = str(tmp_path)
    archive.fake_root = root
    with temp_cwd(root):
        with archive.open("tar-utf8-1.1.0/setup.py", "r") as f:
            contents = f.read()
        assert "Puré" in contents


def test_default_encoding_replaces_invalid_utf8(tmp_path):
    src_dir = tmp_path / "src"
    pkg_dir = src_dir / "pkg-1.0"
    pkg_dir.mkdir(parents=True)
    # 0xa6 is a continuation byte, invalid as a UTF-8 start byte
    (pkg_dir / "data.py").write_bytes(b"version = '1.0'  # \xa6\n")

    tar_path = src_dir / "pkg-1.0.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tarf:
        tarf.add(pkg_dir, arcname="pkg-1.0")

    archive = TarExtractor("gz", str(tar_path))
    root = str(tmp_path)
    archive.fake_root = root
    with temp_cwd(root):
        with archive.open("pkg-1.0/data.py", "r") as f:
            contents = f.read()
        assert "version = '1.0'" in contents
        assert "�" in contents


def test_pathlib_open_with_encoding(monkeypatch, mock_targz, tmp_path):
    directory = "comtypes-1.1.7"
    archive: TarExtractor = TarExtractor("gz", mock_targz(directory))

    root = str(tmp_path)
    archive.fake_root = root
    with contextlib.closing(archive):
        with temp_cwd(root):
            monkeypatch.setattr(io, "open", archive.open)
            # Python 3.10 does not use io.open under the hood.
            def _path_open(self, *args, **kwargs):
                return archive.open(self, *args, **kwargs)

            monkeypatch.setattr(Path, "open", _path_open)
            path = Path("comtypes-1.1.7/setup.py")
            with path.open(encoding="utf-8") as handle:
                assert isinstance(handle.read(1), str)
