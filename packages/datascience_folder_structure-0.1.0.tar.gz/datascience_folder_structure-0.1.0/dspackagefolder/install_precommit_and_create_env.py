## install uv
## uv add requirements.txt
## install pre-commit
## pre-commit install
## creeate env file into the new folder


import subprocess
import sys
from pathlib import Path


def setup_project_environment(project_dir: str | Path = "."):
    project_dir = Path(project_dir).resolve()

    if not project_dir.exists():
        raise FileNotFoundError(f"{project_dir} does not exist")

    def run(cmd: list[str]):
        subprocess.check_call(cmd, cwd=project_dir)

    # 1️⃣ Install uv if missing
    try:
        subprocess.check_call([sys.executable, "-m", "uv", "--version"])
    except subprocess.CalledProcessError:
        print("Installing uv...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "uv"])

    # 2️⃣ Initialise uv project if pyproject.toml is missing
    pyproject = project_dir / "pyproject.toml"
    if not pyproject.exists():
        print("Initialising uv project...")
        run(["uv", "init"])

    # 3️⃣ Add requirements.txt using uv
    requirements = project_dir / "requirements.txt"
    if requirements.exists():
        run(["uv", "add",  "-r", "requirements.txt"])
    else:
        print("requirements.txt not found — skipping uv add")

    # 4️⃣ Install pre-commit if missing
    try:
        subprocess.check_call(["pre-commit", "--version"])
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("Installing pre-commit...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pre-commit"])

    # 5️⃣ Install pre-commit hooks
    run(["git", "init"])  # Ensure git repo is initialized
    run(["pre-commit", "install"])

    # 6️⃣ Create ENVIRONMENT folder and .env file inside it
    env_folder = project_dir / "ENVIRONMENT"
    env_folder.mkdir(parents=True, exist_ok=True)

    env_file = env_folder / ".env"

    if not env_file.exists():
        env_file.write_text("# Environment variables\n", encoding="utf-8")
        print(f"Created {env_file}")
    else:
        print(f"{env_file} already exists")


    gitignore_file = env_folder / ".gitignore"

    if not gitignore_file.exists():
        gitignore_file.write_text("*/\n", encoding="utf-8")
        print(f"Created {gitignore_file}")
    else:
        print(f"{gitignore_file} already exists")

# 7️⃣ Create GitHub Actions workflow for pre-commit
    github_workflows = project_dir / ".github" / "workflows"
    github_workflows.mkdir(parents=True, exist_ok=True)

    precommit_workflow = github_workflows / "pre-commit.yml"

    if not precommit_workflow.exists():
        precommit_workflow.write_text(
            """name: Pre-commit

on:
  push:
  pull_request:

jobs:
  pre-commit:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install dependencies
        run: |
          pip install pre-commit

      - name: Run pre-commit
        run: |
          pre-commit run --all-files
""",
            encoding="utf-8",
        )
        print(f"Created GitHub Actions workflow at {precommit_workflow}")
    else:
        print(f"{precommit_workflow} already exists")

    print("✅ Project environment setup complete")

