## TO USE THIS FOLDER:
run the install_precommit_and_create_env.py first
run uv add requirements.txt



## main_dashboard use and running
main_dashboard.py is used for visualizing the dashboard of the data. 
you run it by uv run streamlit run main_dashboard.py

# WHAT TO DO NEXT
I need to show examples of how to connect the data/sql/validation/logs/config/src


## how to build:
1) first git clone this repo
2) ensure the old artefact build and egg-info folders are deleted first
3) from the directory where the pyproject.toml sits, run:
pip install .

## how to use:
1) createdatasciencefolder datasciencefoldernamed
2) createdatasciencefolder
3) from dspackagefolder.main import create_ds_folder, create_ds_folder()






doing the setup.py style
