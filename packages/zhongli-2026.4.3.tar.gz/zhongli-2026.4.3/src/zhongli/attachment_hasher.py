"""Compute hashes for attachments to detect duplicates."""

import hashlib
from io import BytesIO
from pathlib import Path
from typing import Final

import httpx
from loguru import logger as log
from longwei import APClient

try:
    import imagehash
    from PIL import Image

    IMAGEHASH_AVAILABLE = True
except ImportError:
    IMAGEHASH_AVAILABLE = False

# Default maximum size to download for hashing (100 MB)
# This can be overridden by instance configuration
DEFAULT_MAX_DOWNLOAD_SIZE: Final[int] = 100 * 1024 * 1024

# Default image MIME types that support perceptual hashing
# This can be overridden by instance configuration
DEFAULT_IMAGE_MIME_TYPES: Final[set[str]] = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
}


class AttachmentHasher:
    """Compute content and perceptual hashes for attachments."""

    def __init__(
        self,
        client: httpx.AsyncClient,
        instance: APClient | None = None,
        dhash_size: int = 8,
    ) -> None:
        """Initialize hasher with HTTP client and optional instance configuration.

        Args:
            client: AsyncClient for downloading attachments
            instance: ActivityPub instance (used to get max_att_size and supported_mime_types)
                     If None, uses default values
            dhash_size: Size parameter for dHash — produces dhash_size² bits.
                       Default 8 gives 64-bit hashes (16 hex chars).

        """
        self.client = client
        self.instance = instance
        self.dhash_size = dhash_size

        # Set max download size from instance or use default
        if instance and hasattr(instance, "max_att_size") and instance.max_att_size:
            self.max_download_size = instance.max_att_size
        else:
            self.max_download_size = DEFAULT_MAX_DOWNLOAD_SIZE

        # Set supported image types from instance or use defaults
        if instance and hasattr(instance, "supported_mime_types") and instance.supported_mime_types:
            # Filter to only image types that we can compute dHash for
            self.image_mime_types = {
                mime_type
                for mime_type in instance.supported_mime_types
                if mime_type.startswith("image/") and mime_type in DEFAULT_IMAGE_MIME_TYPES
            }
            # If instance has no image types in defaults, use defaults
            if not self.image_mime_types:
                self.image_mime_types = DEFAULT_IMAGE_MIME_TYPES
        else:
            self.image_mime_types = DEFAULT_IMAGE_MIME_TYPES

    async def hash_attachment(
        self,
        url: str,
        media_type: str | None = None,
    ) -> tuple[str | None, str | None]:
        """Compute SHA-256 and dHash for an attachment.

        Args:
            url: URL of attachment to hash
            media_type: MIME type of attachment (optional, helps optimize)

        Returns:
            Tuple of (content_hash, dhash) where either can be None if unavailable.
            content_hash is always attempted, dhash only for images.

        """
        try:
            # Infer MIME type from URL if not provided
            if not media_type or media_type == "image":
                inferred_type = self._infer_mime_type_from_url(url)
                if inferred_type:
                    media_type = inferred_type
                    log.debug(f"Inferred media_type from URL: {media_type}")

            log.debug(f"Starting hash computation for attachment: url={url}, media_type={media_type}")
            content = await self._download_attachment(url)
            if not content:
                log.debug(f"Failed to download attachment {url}")
                return None, None

            log.debug(f"Downloaded {len(content)} bytes from {url}")

            # Compute content hash (always)
            content_hash = hashlib.sha256(content).hexdigest()
            log.debug(f"Computed content hash for {url}: {content_hash[:16]}...")

            # Compute dHash for images
            dhash = None
            if IMAGEHASH_AVAILABLE and self._is_supported_image_type(media_type):
                dhash = await self._compute_dhash(content)
                log.debug(f"Computed dHash for {url}: {dhash}")
            else:
                log.debug(
                    f"Skipping dHash for {url}: imagehash_available={IMAGEHASH_AVAILABLE}, media_type={media_type}"
                )

            return content_hash, dhash

        except Exception as error:
            log.warning(f"Error hashing attachment {url}: {error}")
            return None, None

    async def _download_attachment(self, url: str) -> bytes | None:
        """Download attachment content with size limit.

        Args:
            url: URL to download

        Returns:
            File content as bytes, or None if download fails or exceeds limit.

        """
        try:
            log.debug(f"Downloading attachment from {url}")
            async with self.client.stream("GET", url, follow_redirects=True) as response:
                log.debug(f"Response status: {response.status_code}")
                response.raise_for_status()

                content = b""
                async for chunk in response.aiter_bytes(chunk_size=8192):
                    content += chunk
                    if len(content) > self.max_download_size:
                        log.warning(
                            f"Attachment {url} exceeds max size ({self.max_download_size} bytes), skipping hash"
                        )
                        return None

                log.debug(f"Successfully downloaded {len(content)} bytes from {url}")
                return content

        except httpx.HTTPStatusError as error:
            log.warning(f"HTTP error downloading attachment {url}: {error.response.status_code}")
            return None
        except httpx.HTTPError as error:
            log.warning(f"Failed to download attachment {url}: {error}")
            return None

    def _infer_mime_type_from_url(self, url: str) -> str | None:
        """Infer MIME type from file extension in URL.

        Args:
            url: URL of the attachment

        Returns:
            MIME type string if extension is recognized, None otherwise.

        """
        # Extract file extension from URL (ignore query parameters)
        path = url.split("?", maxsplit=1)[0]
        suffix = Path(path).suffix.lower()

        # Map common image extensions to MIME types
        mime_map = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
        }

        return mime_map.get(suffix)

    def _is_supported_image_type(self, media_type: str | None) -> bool:
        """Check if media type is a supported image type for dHash.

        Args:
            media_type: MIME type of the media

        Returns:
            True if the media type is in the supported image types, False otherwise.

        """
        if not media_type:
            return False
        return media_type in self.image_mime_types

    async def _compute_dhash(self, content: bytes) -> str | None:
        """Compute difference hash (dHash) for image content.

        Args:
            content: Image file content as bytes

        Returns:
            dHash string, or None if computation fails.

        """
        if not IMAGEHASH_AVAILABLE:
            log.debug("imagehash not available for dHash computation")
            return None

        try:
            log.debug("Opening image for dHash computation")
            image = Image.open(BytesIO(content))
            dhash = imagehash.dhash(image, hash_size=self.dhash_size)
            log.debug(f"Successfully computed dHash: {dhash}")
            return str(dhash)

        except Exception as error:
            log.warning(f"Error computing dHash: {error}")
            return None
