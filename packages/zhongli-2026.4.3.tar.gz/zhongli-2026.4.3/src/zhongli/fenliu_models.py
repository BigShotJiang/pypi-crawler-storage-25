"""Type-safe models for FenLiu v0.4 queue API responses and requests."""

from enum import Enum
from typing import Any

import msgspec


class QueueStatus(str, Enum):
    """Status values for queue feedback operations."""

    ACK = "ack"
    NACK = "nack"
    ERROR = "error"


class QueuedPost(msgspec.Struct):
    """Represents a post from FenLiu's queue.

    This is a minimal ActivityPub-compatible post object that FenLiu
    provides when Fedibooster requests the next post to reblog.

    Attributes:
        id: Unique identifier for the post (usually ActivityPub ID)
        url: URL of the post
        content: HTML content of the post
        created_at: ISO 8601 timestamp when post was created
        actor: ActivityPub actor object (user who posted)
        sensitive: Whether post is marked sensitive/NSFW
        language: Language code (e.g., 'en', 'es')
        tag: List of tag objects (hashtags, mentions, etc.)
        attachment: List of media attachment objects
        in_reply_to: URL if post is a reply
        score: FenLiu spam/quality score (higher = better)
        metadata: Additional metadata from FenLiu

    """

    id: str
    url: str
    content: str
    created_at: str
    actor: dict[str, Any]
    sensitive: bool = False
    language: str | None = None
    tag: list[dict[str, Any]] | None = None
    attachment: list[dict[str, Any]] | None = None
    in_reply_to: str | None = None
    score: float = 0.0
    metadata: dict[str, Any] | None = None
