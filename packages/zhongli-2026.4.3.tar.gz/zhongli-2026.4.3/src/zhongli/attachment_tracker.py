"""Attachment tracker for detecting duplicate content using URL, SHA-256, and dHash."""

import sqlite3
from datetime import datetime
from datetime import timedelta
from pathlib import Path
from typing import NamedTuple

import aiosqlite
from loguru import logger as log

RETENTION_DAYS: int = 90
DHASH_THRESHOLD: int = 10


def _hamming_distance(a: str, b: str) -> int:
    """Compute Hamming distance between two hex-encoded dHash strings."""
    return bin(int(a, 16) ^ int(b, 16)).count("1")


class AttachmentRecord(NamedTuple):
    """Record of a tracked attachment."""

    url: str
    content_hash: str | None
    dhash: str | None
    media_type: str | None
    boosted_post_id: str
    first_seen: datetime
    last_seen: datetime


class _BKNode:
    """Node in a BK-tree."""

    __slots__ = ("children", "dhash", "record")

    def __init__(self, dhash: str, record: AttachmentRecord) -> None:
        self.dhash = dhash
        self.record = record
        self.children: dict[int, _BKNode] = {}


class _BKTree:
    """BK-tree for sub-linear nearest-neighbour search on Hamming distance.

    Suitable for fixed-length binary strings such as perceptual hashes.
    """

    def __init__(self) -> None:
        self._root: _BKNode | None = None

    def insert(self, dhash: str, record: AttachmentRecord) -> None:
        """Insert a dhash and its associated record into the tree."""
        if self._root is None:
            self._root = _BKNode(dhash, record)
            return
        node = self._root
        while True:
            d = _hamming_distance(dhash, node.dhash)
            if d == 0:
                return  # exact duplicate — first insert wins
            if d not in node.children:
                node.children[d] = _BKNode(dhash, record)
                return
            node = node.children[d]

    def search(self, dhash: str, threshold: int) -> AttachmentRecord | None:
        """Return the first record within Hamming distance threshold, or None."""
        if self._root is None:
            return None
        stack: list[_BKNode] = [self._root]
        while stack:
            node = stack.pop()
            d = _hamming_distance(dhash, node.dhash)
            if d <= threshold:
                return node.record
            for dist, child in node.children.items():
                if abs(dist - d) <= threshold:
                    stack.append(child)
        return None


class AttachmentTracker:
    """Track attachments to prevent re-boosting duplicate content.

    Uses a 3-tier approach:
    1. URL check (fast, catches exact URL matches)
    2. SHA-256 hash (detects identical content)
    3. dHash (detects visually similar images via in-memory BK-tree)

    Records are kept for RETENTION_DAYS (default 90 days).
    """

    def __init__(self, db_path: Path | str = "cache.db", dhash_threshold: int = DHASH_THRESHOLD) -> None:
        """Initialize attachment tracker with SQLite database.

        Args:
            db_path: Path to SQLite database file
            dhash_threshold: Maximum Hamming distance to consider two dHashes a match.
                            Default 10 out of 64 bits (~85% similarity).

        """
        self.db_path = Path(db_path)
        self.dhash_threshold = dhash_threshold
        self._bktree = _BKTree()
        self._initialize_db()

    def _initialize_db(self) -> None:
        """Create tables if they don't exist."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS boosted_attachments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT NOT NULL UNIQUE,
                    content_hash TEXT,
                    dhash TEXT,
                    media_type TEXT,
                    boosted_post_id TEXT NOT NULL,
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_content_hash
                ON boosted_attachments(content_hash)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_dhash
                ON boosted_attachments(dhash)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_first_seen
                ON boosted_attachments(first_seen)
                """
            )

    async def load_tree(self) -> None:
        """Load all existing dhash records from the database into the BK-tree.

        Replaces any existing in-memory tree. Call at startup after
        cleanup_old_records() so the tree reflects the current database state.
        """
        self._bktree = _BKTree()
        count = 0
        async with aiosqlite.connect(self.db_path) as conn:
            async with conn.execute("SELECT * FROM boosted_attachments WHERE dhash IS NOT NULL") as cursor:
                async for row in cursor:
                    record = self._row_to_record(row)
                    if record.dhash is not None:
                        self._bktree.insert(record.dhash, record)
                        count += 1
        log.debug(f"BK-tree loaded with {count} dhash records")

    async def check_attachment(
        self,
        url: str,
        content_hash: str | None = None,
        dhash: str | None = None,
    ) -> AttachmentRecord | None:
        """Check if attachment has been boosted before.

        Checks in order:
        1. URL match
        2. Content hash match
        3. dHash match (if both provided and within threshold)

        Args:
            url: Media attachment URL
            content_hash: SHA-256 hash of attachment content
            dhash: Perceptual hash of image (if available)

        Returns:
            AttachmentRecord if found (duplicate), None otherwise.

        """
        async with aiosqlite.connect(self.db_path) as conn:
            return (
                await self._check_url(conn, url)
                or (await self._check_content_hash(conn, content_hash) if content_hash else None)
                or (self._check_dhash(dhash) if dhash else None)
            )

    async def _check_url(self, conn: aiosqlite.Connection, url: str) -> AttachmentRecord | None:
        """Return existing record matching url, or None."""
        async with conn.execute(
            "SELECT * FROM boosted_attachments WHERE url = ?",
            (url,),
        ) as cursor:
            row = await cursor.fetchone()
        return self._row_to_record(row) if row else None

    async def _check_content_hash(self, conn: aiosqlite.Connection, content_hash: str) -> AttachmentRecord | None:
        """Return existing record matching content_hash, or None."""
        async with conn.execute(
            "SELECT * FROM boosted_attachments WHERE content_hash = ?",
            (content_hash,),
        ) as cursor:
            row = await cursor.fetchone()
        return self._row_to_record(row) if row else None

    def _check_dhash(self, dhash: str) -> AttachmentRecord | None:
        """Return first existing record within Hamming distance threshold, or None."""
        return self._bktree.search(dhash, self.dhash_threshold)

    async def record_attachment(
        self,
        url: str,
        boosted_post_id: str,
        content_hash: str | None = None,
        dhash: str | None = None,
        media_type: str | None = None,
    ) -> None:
        """Record an attachment as boosted.

        Args:
            url: Media attachment URL
            boosted_post_id: ID of post this attachment was boosted with
            content_hash: SHA-256 hash of attachment content
            dhash: Perceptual hash of image
            media_type: MIME type of attachment

        """
        now = datetime.now().isoformat()

        async with aiosqlite.connect(self.db_path) as conn:
            try:
                await conn.execute(
                    """
                    INSERT INTO boosted_attachments
                    (url, content_hash, dhash, media_type, boosted_post_id, first_seen, last_seen)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (url, content_hash, dhash, media_type, boosted_post_id, now, now),
                )
            except aiosqlite.IntegrityError:
                # URL already exists, update last_seen
                await conn.execute(
                    "UPDATE boosted_attachments SET last_seen = ? WHERE url = ?",
                    (now, url),
                )
            await conn.commit()
            log.debug(f"Recorded attachment: {url} for post {boosted_post_id}")

        if dhash is not None:
            record = AttachmentRecord(
                url=url,
                content_hash=content_hash,
                dhash=dhash,
                media_type=media_type,
                boosted_post_id=boosted_post_id,
                first_seen=datetime.fromisoformat(now),
                last_seen=datetime.fromisoformat(now),
            )
            self._bktree.insert(dhash, record)

    async def cleanup_old_records(self) -> int:
        """Remove attachment records older than RETENTION_DAYS.

        Returns:
            Number of records deleted.

        """
        cutoff_date = (datetime.now() - timedelta(days=RETENTION_DAYS)).isoformat()

        async with aiosqlite.connect(self.db_path) as conn:
            cursor = await conn.execute(
                "DELETE FROM boosted_attachments WHERE first_seen < ?",
                (cutoff_date,),
            )
            deleted_count = cursor.rowcount
            await conn.commit()

        if deleted_count > 0:
            log.info(f"Cleaned up {deleted_count} old attachment records")
            await self.load_tree()

        return deleted_count

    def _row_to_record(self, row: aiosqlite.Row) -> AttachmentRecord:
        """Convert database row to AttachmentRecord.

        Args:
            row: Database row from aiosqlite cursor

        Returns:
            AttachmentRecord instance

        """
        return AttachmentRecord(
            url=row[1],
            content_hash=row[2],
            dhash=row[3],
            media_type=row[4],
            boosted_post_id=row[5],
            first_seen=datetime.fromisoformat(row[6]),
            last_seen=datetime.fromisoformat(row[7]),
        )
