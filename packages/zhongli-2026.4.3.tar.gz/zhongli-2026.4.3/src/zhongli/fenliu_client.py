"""Client library for FenLiu queue API."""

from typing import Any

import msgspec
import stamina
from httpx import AsyncClient
from loguru import logger as log
from longwei import NetworkError

from zhongli.circuit_breaker import circuit_protected_call
from zhongli.fenliu_models import QueuedPost
from zhongli.fenliu_models import QueueStatus


class FenLiuClient:
    """Client for interacting with FenLiu v0.4 queue API.

    Provides methods to consume posts from FenLiu's curated queue and send feedback
    about reblogging results.

    Attributes:
        base_url: Base URL of the FenLiu instance
        api_key: API key for authentication
        client: HTTP client for making requests

    """

    def __init__(  # noqa: PLR0913
        self,
        base_url: str,
        client: AsyncClient,
        api_key: str,
        random_selection: bool = False,
        prefer_topical: bool = False,
        topical_only: bool = False,
    ) -> None:
        """Initialize FenLiu client.

        Args:
            base_url: Base URL of the FenLiu instance (e.g., 'http://localhost:8000')
            client: AsyncClient instance for HTTP requests
            api_key: API key for authentication (required for v0.4+)
            random_selection: If True, request a random post instead of FIFO
            prefer_topical: If True, request topical posts when today matches a topical day
            topical_only: If True (requires prefer_topical), return nothing when no topical post is available

        Raises:
            ValueError: If base_url or api_key is empty

        """
        if not base_url:
            raise ValueError("base_url is required")
        if not api_key:
            raise ValueError("api_key is required")

        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.client = client
        self.random_selection = random_selection
        self.prefer_topical = prefer_topical
        self.topical_only = topical_only

    def _get_headers(self) -> dict[str, str]:
        """Get headers for API requests.

        Returns:
            Dictionary of HTTP headers including X-API-Key authorization.

        """
        return {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        }

    async def get_next_post(self) -> QueuedPost | None:
        """Get the next post from FenLiu's curated queue.

        This reserves the post for processing (typically ~5 minutes).
        The post must be acknowledged/nacked/errored within the timeout.

        Returns:
            QueuedPost if available, None if queue is empty.

        Raises:
            NetworkError: If there's a network or connection error.

        """

        @circuit_protected_call(
            "fenliu_get_next",
            operation_description="getting next post from FenLiu queue",
        )
        async def protected_get_next():
            query_params: list[str] = []
            if self.random_selection:
                query_params.append("random=true")
            if self.prefer_topical:
                query_params.append("include_topical=true")
            if self.topical_only:
                query_params.append("topical_only=true")
            url_str = f"{self.base_url}/api/v1/curated/next"
            if query_params:
                url_str += "?" + "&".join(query_params)
            log.bind(operation="get_next_post").debug(f"Fetching next post from FenLiu: {url_str}")
            retry_caller = stamina.AsyncRetryingCaller(attempts=3)

            response_data = await retry_caller(
                NetworkError,
                self._fetch_json,
                url=url_str,
                method="get",
            )

            if not response_data:
                log.bind(operation="get_next_post", result="empty").debug("Queue is empty")
                return None

            # Transform the FenLiu response to QueuedPost format
            try:
                # fenliu_post_id is required - reject post if missing
                post_id = response_data.get("fenliu_post_id")
                if not post_id:
                    log.bind(operation="get_next_post", result="invalid").debug("Rejecting post without fenliu_post_id")
                    return None

                post = QueuedPost(
                    id=str(post_id),
                    url=response_data.get("post_url", ""),
                    content=response_data.get("content_snippet", ""),
                    created_at=response_data.get("post_created_at", ""),
                    actor={
                        "id": response_data.get("author_account", ""),
                        "acct": response_data.get("author_account", ""),
                    },
                    sensitive=False,  # FenLiu doesn't provide sensitivity in queue response
                    language=None,  # FenLiu doesn't provide language in queue response
                    tag=[{"name": tag} for tag in response_data.get("hashtags", [])],
                    attachment=[],  # FenLiu indicates attachments exist but doesn't provide details
                    in_reply_to=None,  # FenLiu doesn't provide reply info
                    score=response_data.get("spam_score", 0) / 100.0,  # Normalize to 0-1
                    metadata={
                        "fenliu_post_id": post_id,
                        "post_uri": response_data.get("post_uri"),
                        "stream": response_data.get("stream"),
                        "has_attachments": response_data.get("has_attachments"),
                        "approved_at": response_data.get("approved_at"),
                    },
                )
                log.bind(operation="get_next_post", post_id=str(post_id), result="success").debug(
                    f"Got post {post_id} from queue"
                )
                return post
            except (KeyError, ValueError, TypeError) as exc:
                log.bind(operation="get_next_post", result="parse_error", error_type=type(exc).__name__).warning(
                    f"Failed to parse FenLiu post data: {exc}"
                )
                return None

        return await protected_get_next()

    async def ack(self, post_id: str) -> bool:
        """Acknowledge successful reblog of a post.

        Args:
            post_id: FenLiu post ID that was successfully reblogged

        Returns:
            True if feedback was sent successfully, False otherwise.

        Raises:
            NetworkError: If there's a network or connection error.

        """
        return await self._send_feedback(
            post_id=post_id,
            status=QueueStatus.ACK,
        )

    async def nack(self, post_id: str) -> bool:
        """Send negative acknowledgement (transient error).

        Indicates the post couldn't be reblogged but may be retried later.

        Args:
            post_id: FenLiu post ID that failed to reblog

        Returns:
            True if feedback was sent successfully, False otherwise.

        Raises:
            NetworkError: If there's a network or connection error.

        """
        return await self._send_feedback(
            post_id=post_id,
            status=QueueStatus.NACK,
        )

    async def error(self, post_id: str, message: str | None = None) -> bool:
        """Send error feedback (permanent failure).

        Indicates the post should not be retried.

        Args:
            post_id: FenLiu post ID that permanently failed
            message: Optional message describing the error reason

        Returns:
            True if feedback was sent successfully, False otherwise.

        Raises:
            NetworkError: If there's a network or connection error.

        """
        return await self._send_feedback(
            post_id=post_id,
            status=QueueStatus.ERROR,
            message=message,
        )

    async def requeue(self, post_id: str) -> bool:
        """Request that a post be requeued for another attempt.

        Args:
            post_id: FenLiu post ID to requeue

        Returns:
            True if requeue request was sent successfully, False otherwise.

        Raises:
            NetworkError: If there's a network or connection error.

        """

        @circuit_protected_call(
            "fenliu_requeue",
            operation_description=f"requeueing post {post_id}",
        )
        async def protected_requeue():
            url_str = f"{self.base_url}/api/v1/curated/{post_id}/requeue"
            retry_caller = stamina.AsyncRetryingCaller(attempts=3)

            response_data = await retry_caller(
                NetworkError,
                self._fetch_json,
                url=url_str,
                method="post",
                body=None,
            )

            return response_data is not None

        return await protected_requeue()

    async def _send_feedback(
        self,
        post_id: str,
        status: QueueStatus,
        message: str | None = None,
    ) -> bool:
        """Send feedback about a post to FenLiu.

        Internal method used by ack(), nack(), and error().

        Args:
            post_id: FenLiu post ID
            status: Feedback status (ack, nack, or error)
            message: Optional detailed message (used only for error status)

        Returns:
            True if feedback was sent successfully, False otherwise.

        Raises:
            NetworkError: If there's a network or connection error.

        """

        @circuit_protected_call(
            "fenliu_feedback",
            operation_description=f"sending {status.value} feedback for post {post_id}",
        )
        async def protected_feedback():
            url_str = f"{self.base_url}/api/v1/curated/{post_id}/{status.value}"
            retry_caller = stamina.AsyncRetryingCaller(attempts=3)

            # Only error status includes a reason field
            body = None
            if status == QueueStatus.ERROR and message:
                body = {"reason": message}

            response_data = await retry_caller(
                NetworkError,
                self._fetch_json,
                url=url_str,
                method="post",
                body=body,
            )

            success = response_data is not None
            log.bind(post_id=post_id, feedback_status=status.value, success=success).debug(
                f"Sent {status.value} feedback for post {post_id}"
            )
            return success

        return await protected_feedback()

    async def _fetch_json(
        self,
        url: str,
        method: str = "get",
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Fetch JSON from FenLiu API.

        Args:
            url: The URL to fetch
            method: HTTP method ('get' or 'post')
            body: Request body (dict or None)

        Returns:
            Parsed JSON response or None if request failed or empty.

        Raises:
            NetworkError: If there's a network or connection error.

        """
        headers = self._get_headers()

        try:
            if method.lower() == "post":
                response = await self.client.post(
                    url=url,
                    json=body,
                    headers=headers,
                )
            else:  # GET
                response = await self.client.get(url=url, headers=headers)

            # Handle 204 No Content (queue empty, or successful operation with no body)
            if response.status_code == 204:
                log.debug(f"No content response from {method.upper()} {url}")
                return {}

            response.raise_for_status()

            try:
                return msgspec.json.decode(response.content, type=dict)
            except (msgspec.DecodeError, ValueError) as exc:
                log.warning(f"Failed to decode FenLiu response: {exc}")
                return None

        except Exception as exc:
            log.error(f"FenLiu API request failed for {method.upper()} {url}: {exc}")
            raise NetworkError(message=str(exc)) from exc
