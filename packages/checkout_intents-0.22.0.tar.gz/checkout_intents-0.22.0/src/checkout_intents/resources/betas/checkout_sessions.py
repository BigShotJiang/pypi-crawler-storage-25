# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.betas import checkout_session_create_params
from ..._base_client import make_request_options
from ...types.checkout_session import CheckoutSession
from ...types.variant_selection_param import VariantSelectionParam

__all__ = ["CheckoutSessionsResource", "AsyncCheckoutSessionsResource"]


class CheckoutSessionsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CheckoutSessionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/rye-com/checkout-intents-python#accessing-raw-response-data-eg-headers
        """
        return CheckoutSessionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CheckoutSessionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/rye-com/checkout-intents-python#with_streaming_response
        """
        return CheckoutSessionsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        product_url: str,
        quantity: int,
        buyer: checkout_session_create_params.Buyer | Omit = omit,
        constraints: checkout_session_create_params.Constraints | Omit = omit,
        discover_promo_codes: bool | Omit = omit,
        layout: Literal["default", "wizard"] | Omit = omit,
        promo_codes: SequenceNotStr[str] | Omit = omit,
        variant_selections: Iterable[VariantSelectionParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
        idempotency_key: str | None = None,
    ) -> CheckoutSession:
        """
        Create a new checkout session.

        Checkout sessions are hosted checkout forms your shoppers can use to complete
        their purchases.

        Args:
          buyer: Optional buyer information, used to pre-fill the checkout form with the buyer's
              information.

          layout: Optional layout for the checkout UI (e.g. "wizard"). Defaults to the standard
              layout.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

          idempotency_key: Specify a custom idempotency key for this request
        """
        return self._post(
            "/api/v1/betas/checkout-sessions",
            body=maybe_transform(
                {
                    "product_url": product_url,
                    "quantity": quantity,
                    "buyer": buyer,
                    "constraints": constraints,
                    "discover_promo_codes": discover_promo_codes,
                    "layout": layout,
                    "promo_codes": promo_codes,
                    "variant_selections": variant_selections,
                },
                checkout_session_create_params.CheckoutSessionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                idempotency_key=idempotency_key,
            ),
            cast_to=CheckoutSession,
        )


class AsyncCheckoutSessionsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCheckoutSessionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/rye-com/checkout-intents-python#accessing-raw-response-data-eg-headers
        """
        return AsyncCheckoutSessionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCheckoutSessionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/rye-com/checkout-intents-python#with_streaming_response
        """
        return AsyncCheckoutSessionsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        product_url: str,
        quantity: int,
        buyer: checkout_session_create_params.Buyer | Omit = omit,
        constraints: checkout_session_create_params.Constraints | Omit = omit,
        discover_promo_codes: bool | Omit = omit,
        layout: Literal["default", "wizard"] | Omit = omit,
        promo_codes: SequenceNotStr[str] | Omit = omit,
        variant_selections: Iterable[VariantSelectionParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
        idempotency_key: str | None = None,
    ) -> CheckoutSession:
        """
        Create a new checkout session.

        Checkout sessions are hosted checkout forms your shoppers can use to complete
        their purchases.

        Args:
          buyer: Optional buyer information, used to pre-fill the checkout form with the buyer's
              information.

          layout: Optional layout for the checkout UI (e.g. "wizard"). Defaults to the standard
              layout.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

          idempotency_key: Specify a custom idempotency key for this request
        """
        return await self._post(
            "/api/v1/betas/checkout-sessions",
            body=await async_maybe_transform(
                {
                    "product_url": product_url,
                    "quantity": quantity,
                    "buyer": buyer,
                    "constraints": constraints,
                    "discover_promo_codes": discover_promo_codes,
                    "layout": layout,
                    "promo_codes": promo_codes,
                    "variant_selections": variant_selections,
                },
                checkout_session_create_params.CheckoutSessionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                idempotency_key=idempotency_key,
            ),
            cast_to=CheckoutSession,
        )


class CheckoutSessionsResourceWithRawResponse:
    def __init__(self, checkout_sessions: CheckoutSessionsResource) -> None:
        self._checkout_sessions = checkout_sessions

        self.create = to_raw_response_wrapper(
            checkout_sessions.create,
        )


class AsyncCheckoutSessionsResourceWithRawResponse:
    def __init__(self, checkout_sessions: AsyncCheckoutSessionsResource) -> None:
        self._checkout_sessions = checkout_sessions

        self.create = async_to_raw_response_wrapper(
            checkout_sessions.create,
        )


class CheckoutSessionsResourceWithStreamingResponse:
    def __init__(self, checkout_sessions: CheckoutSessionsResource) -> None:
        self._checkout_sessions = checkout_sessions

        self.create = to_streamed_response_wrapper(
            checkout_sessions.create,
        )


class AsyncCheckoutSessionsResourceWithStreamingResponse:
    def __init__(self, checkout_sessions: AsyncCheckoutSessionsResource) -> None:
        self._checkout_sessions = checkout_sessions

        self.create = async_to_streamed_response_wrapper(
            checkout_sessions.create,
        )
