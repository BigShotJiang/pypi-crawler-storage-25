import logging
import re
from typing import Iterable, Optional

import click
import cwms

from cwmscli.utils.links import CDA_REGEXP_GUIDE_URL

logger = logging.getLogger(__name__)


def load_locations(
    source_cda: str,
    source_office: str,
    target_cda: str,
    target_api_key: Optional[str],
    verbose: int,
    dry_run: bool,
    like: Optional[str],
    location_kind_like: Optional[Iterable[str]] = "ALL",
):
    if verbose:
        logger.info(
            f"[load locations] source={source_cda} ({source_office}) -> target={target_cda}"
        )
        logger.info(
            f"  like={like or '-'}  kinds={list(location_kind_like) or '-'}  dry_run={dry_run}"
        )
        if like or (
            location_kind_like
            and list(location_kind_like) != ["ALL"]
            and list(location_kind_like) != []
        ):
            logger.info("  CDA regex guide: %s", CDA_REGEXP_GUIDE_URL)

    cwms.init_session(api_root=source_cda, api_key=None)

    cat_kwargs = {"office_id": source_office}
    if like:
        cat_kwargs["like"] = like
    kinds = list(location_kind_like) if location_kind_like else ["ALL"]
    if "ALL" in kinds:
        kinds = ["ALL"]

    locations = []

    if kinds == ["ALL"] and not like:
        locations = cwms.get_locations(office_id=source_office).json
    else:
        seen_location_ids = set()
        for kind in kinds:
            cat_kwargs_k = dict(cat_kwargs)
            if kind != "ALL":
                cat_kwargs_k["location_kind_like"] = kind

            if verbose >= 2:
                logger.debug("  > catalog query: %s", cat_kwargs_k)

            resp = cwms.get_locations_catalog(**cat_kwargs_k)
            if resp.df.empty:
                continue

            for location_id in resp.df["name"].tolist():
                if location_id in seen_location_ids:
                    continue
                seen_location_ids.add(location_id)
                if verbose >= 2:
                    logger.debug("  > location fetch: %s", location_id)
                detail_resp = cwms.get_locations(
                    office_id=source_office,
                    location_ids=rf"^{re.escape(location_id)}$",
                )
                if detail_resp and detail_resp.json:
                    locations.extend(detail_resp.json)

    if verbose:
        logger.info("Fetched %s locations from source", len(locations))

    if dry_run:
        for loc in locations:
            logger.info(
                f"[dry-run] would store Location(name={loc['name']}) to {target_cda} ({source_office})"
            )
        return

    # init target once
    cwms.init_session(api_root=target_cda, api_key=target_api_key)

    errors = 0
    for loc in locations:
        try:
            if loc["active"] is True:
                result = cwms.store_location(data=loc, fail_if_exists=False)
                if verbose:
                    logger.info("%s", result)
        except Exception as e:
            errors += 1
            click.echo(f"Error storing location {loc}: \n\t{e}", err=True)

    if errors:
        raise click.ClickException(f"Completed with {errors} error(s).")
    if verbose:
        logger.info("Done.")
