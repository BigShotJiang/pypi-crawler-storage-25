#!/usr/bin/env python3
"""
Test that the standalone functions work correctly with ma_crystal
"""

def test_ma_crystal_with_standalone():
    try:
        from marearts_crystal import ma_crystal

        # Create instance
        secret_key = "test_secret_key_123"
        mc = ma_crystal(secret_key)

        # Test encryption
        test_string = "Hello, World! Testing standalone functions"
        encrypted = mc.encrypt_string(test_string)
        print(f"✓ Encryption works: {encrypted[:50]}...")

        # Test decryption
        decrypted = mc.decrypt_string(encrypted)
        print(f"✓ Decryption works: {decrypted}")

        # Verify round-trip
        if decrypted == test_string:
            print("✓ Round-trip successful: Original == Decrypted")
        else:
            print("✗ Round-trip failed!")
            return False

        # Test multiple operations
        for i in range(5):
            test = f"Test string {i}"
            enc = mc.encrypt_string(test)
            dec = mc.decrypt_string(enc)
            if dec != test:
                print(f"✗ Failed on iteration {i}")
                return False

        print("✓ Multiple operations successful")

        # Test with different secret keys
        mc2 = ma_crystal("different_key_456")
        enc2 = mc2.encrypt_string("Another test")
        dec2 = mc2.decrypt_string(enc2)
        if dec2 == "Another test":
            print("✓ Different instance works")
        else:
            print("✗ Different instance failed")
            return False

        # Test that different keys can't decrypt each other's data
        try:
            wrong_decrypt = mc2.decrypt_string(encrypted)
            if wrong_decrypt is None:
                print("✓ Different keys properly isolated")
            else:
                print("✗ Security issue: Different keys can decrypt!")
                return False
        except:
            print("✓ Different keys properly isolated")

        print("\n" + "="*60)
        print("SUCCESS: All tests passed!")
        print("The standalone functions are working correctly")
        print("with the ma_crystal class")
        print("="*60)
        return True

    except ImportError:
        print("marearts_crystal not installed")
        print("Build it first with:")
        print("  cd /media/m2/dev2/marearts-crystal-main/marearts-crystal-pypi")
        print("  python setup.py build_ext --inplace")
        return False
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_ma_crystal_with_standalone()