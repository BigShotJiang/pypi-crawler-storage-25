#!/usr/bin/env python3
"""Test V2 serial key generation and validation"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Try to import
try:
    # Try installed version first
    import marearts_crystal
    from marearts_crystal import ma_crystal
    print(f"Using marearts_crystal from: {marearts_crystal.__file__}")
except ImportError as e:
    print(f"Cannot import marearts_crystal: {e}")
    print("\nNote: The module needs to be built first:")
    print("  cd /media/m2/dev2/marearts-crystal-main/marearts-crystal-pypi")
    print("  python setup.py build_ext --inplace")
    sys.exit(1)

def test_serial_keys():
    print("Testing Serial Key V2 Generation")
    print("=" * 60)
    
    # Initialize
    skm = ma_crystal.ma_crystal("test_key_123")
    username = "testuser"
    start_date = "2024-01-01"
    end_date = "2024-12-31"
    
    # Test 1: Generate V2 serial key (always V2 now)
    print("\n1. Generate new serial key (always V2):")
    serial_key = skm.generate_serial_key(username, start_date, end_date)
    print(f"   Generated key: {serial_key[:30]}...")
    print(f"   Has MAEV2: prefix? {serial_key.startswith('MAEV2:')}")
    
    # Test 2: Validate V2 serial key
    print("\n2. Validate V2 serial key:")
    validated = skm.validate_serial_key(username, serial_key)
    if validated:
        print(f"   Valid from {validated[0]} to {validated[1]}")
        print(f"   Dates match? {validated[0] == start_date and validated[1] == end_date}")
    else:
        print("   ERROR: Validation failed!")
    
    # Test 3: Wrong username should fail
    print("\n3. Validate with wrong username:")
    wrong_validated = skm.validate_serial_key("wronguser", serial_key)
    print(f"   Correctly rejected? {wrong_validated is None}")
    
    # Test 4: Test date validation
    print("\n4. Date validation:")
    is_valid = skm.validate_date(start_date, end_date)
    print(f"   Date range valid? {is_valid}")
    
    # Test 5: Simulate old V1 key (without MAEV2: prefix)
    print("\n5. Backward compatibility with V1 keys:")
    # Create a V1-style key manually (for testing backward compatibility)
    # In production, V1 keys already exist and need to be validated
    print("   Note: New keys are always V2, but validation still supports V1")
    print("   V1 support is for existing customer keys only")
    
    # Test 6: Different master key should fail
    print("\n6. Wrong master key test:")
    wrong_skm = ma_crystal.ma_crystal("wrong_key")
    wrong_validated = wrong_skm.validate_serial_key(username, serial_key)
    print(f"   Correctly rejected? {wrong_validated is None}")
    
    print("\n" + "=" * 60)
    print("Summary of changes:")
    print("- generate_serial_key: Always generates V2 keys (MAEV2: prefix)")
    print("- validate_serial_key: Supports both V1 and V2 for backward compatibility")
    print("- V1 generation is deprecated, only V2 for new keys")
    print("- Existing V1 keys continue to work")
    
    return True

if __name__ == "__main__":
    test_serial_keys()