#!/usr/bin/env python3
"""
Test serial key compatibility between original and obfuscated implementations
This ensures existing license keys continue to work after the update
"""

import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

class OriginalImplementation:
    """Simulates the original ma_crystal with hardcoded salts"""
    
    def __init__(self, secret_key):
        self.secret_key = secret_key
        self.fernet = self._create_fernet(secret_key)
    
    def _create_fernet(self, secret_key):
        salt = b'ma_crystal_salt'  # Original hardcoded salt
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(secret_key.encode()))
        return Fernet(key)
    
    def _generate_key(self, username):
        salt = username.encode()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(self.secret_key.encode()))
        return Fernet(key)
    
    def generate_serial_key(self, username, start_date, end_date):
        f = self._generate_key(username)
        data = f"{start_date}|{end_date}".encode()
        return f.encrypt(data).decode()
    
    def validate_serial_key(self, username, serial_key):
        f = self._generate_key(username)
        try:
            decrypted_data = f.decrypt(serial_key.encode()).decode()
            start_date, end_date = decrypted_data.split('|')
            return start_date, end_date
        except:
            return None

class ObfuscatedImplementation:
    """Simulates the new ma_crystal with obfuscated salts"""
    
    def __init__(self, secret_key):
        self.secret_key = secret_key
        # Initialize obfuscated salts
        self._main_salt = self._get_obfuscated_main_salt()
        self._user_salt_prefix = self._get_obfuscated_user_salt()
        self.fernet = self._create_fernet(secret_key)
    
    def _get_obfuscated_main_salt(self):
        """Decode obfuscated main salt"""
        main_segments = [
            [218, 194, 190, 198, 228, 242, 230, 232],  # "ma_cryst" * 2
            [162, 173, 160, 180, 162, 173, 181, 0]      # "al_salt" + 65
        ]
        
        decoded = bytearray()
        for i, segment in enumerate(main_segments):
            for val in segment:
                if val == 0:
                    break
                if i == 0:
                    val = val >> 1
                elif i == 1:
                    val = val - 65
                if val > 0:
                    decoded.append(val)
        return bytes(decoded)
    
    def _get_obfuscated_user_salt(self):
        """Decode obfuscated user salt prefix"""
        user_segments = [115, 97, 108, 116, 95, 0, 0, 0]  # "salt_"
        decoded = bytearray()
        for val in user_segments:
            if val == 0:
                break
            if val > 0:
                decoded.append(val)
        return bytes(decoded)
    
    def _create_fernet(self, secret_key):
        salt = self._main_salt  # Use obfuscated salt
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(secret_key.encode()))
        return Fernet(key)
    
    def _generate_key(self, username):
        salt = username.encode()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(self.secret_key.encode()))
        return Fernet(key)
    
    def generate_serial_key(self, username, start_date, end_date):
        f = self._generate_key(username)
        data = f"{start_date}|{end_date}".encode()
        return f.encrypt(data).decode()
    
    def validate_serial_key(self, username, serial_key):
        f = self._generate_key(username)
        try:
            decrypted_data = f.decrypt(serial_key.encode()).decode()
            start_date, end_date = decrypted_data.split('|')
            return start_date, end_date
        except:
            return None

def test_serial_key_compatibility():
    """Test that serial keys work across both implementations"""
    
    print("=" * 70)
    print("SERIAL KEY COMPATIBILITY TEST")
    print("=" * 70)
    
    # Test parameters
    secret_key = "company_secret_2024"
    username = "john_doe_enterprise"
    start_date = "2024-01-01"
    end_date = "2024-12-31"
    
    # Create instances
    original = OriginalImplementation(secret_key)
    obfuscated = ObfuscatedImplementation(secret_key)
    
    print(f"\nTest Parameters:")
    print(f"  Secret Key: '{secret_key}'")
    print(f"  Username: '{username}'")
    print(f"  License Period: {start_date} to {end_date}")
    
    # Test 1: Generate with original, validate with obfuscated
    print("\n" + "-" * 50)
    print("Test 1: Generate with ORIGINAL, validate with OBFUSCATED")
    
    serial_key_original = original.generate_serial_key(username, start_date, end_date)
    print(f"Serial key generated: {serial_key_original[:50]}...")
    
    result = obfuscated.validate_serial_key(username, serial_key_original)
    if result and result[0] == start_date and result[1] == end_date:
        print(f"✅ SUCCESS: Key validated correctly!")
        print(f"   Decoded dates: {result[0]} to {result[1]}")
    else:
        print(f"❌ FAILURE: Key validation failed!")
        print(f"   Result: {result}")
        return False
    
    # Test 2: Generate with obfuscated, validate with original
    print("\n" + "-" * 50)
    print("Test 2: Generate with OBFUSCATED, validate with ORIGINAL")
    
    serial_key_obfuscated = obfuscated.generate_serial_key(username, start_date, end_date)
    print(f"Serial key generated: {serial_key_obfuscated[:50]}...")
    
    result = original.validate_serial_key(username, serial_key_obfuscated)
    if result and result[0] == start_date and result[1] == end_date:
        print(f"✅ SUCCESS: Key validated correctly!")
        print(f"   Decoded dates: {result[0]} to {result[1]}")
    else:
        print(f"❌ FAILURE: Key validation failed!")
        print(f"   Result: {result}")
        return False
    
    # Test 3: Invalid key should fail on both
    print("\n" + "-" * 50)
    print("Test 3: Invalid key should fail on both")
    
    invalid_key = "invalid_serial_key_12345"
    result_original = original.validate_serial_key(username, invalid_key)
    result_obfuscated = obfuscated.validate_serial_key(username, invalid_key)
    
    if result_original is None and result_obfuscated is None:
        print("✅ SUCCESS: Both correctly reject invalid key")
    else:
        print("❌ FAILURE: Invalid key handling mismatch!")
        return False
    
    # Test 4: Wrong username should fail on both
    print("\n" + "-" * 50)
    print("Test 4: Wrong username should fail on both")
    
    wrong_username = "wrong_user"
    result_original = original.validate_serial_key(wrong_username, serial_key_original)
    result_obfuscated = obfuscated.validate_serial_key(wrong_username, serial_key_obfuscated)
    
    if result_original is None and result_obfuscated is None:
        print("✅ SUCCESS: Both correctly reject wrong username")
    else:
        print("❌ FAILURE: Wrong username handling mismatch!")
        return False
    
    return True

def test_existing_license_keys():
    """Test with a simulated existing license key from production"""
    
    print("\n" + "=" * 70)
    print("EXISTING LICENSE KEY COMPATIBILITY TEST")
    print("=" * 70)
    
    # Simulate a customer's existing license
    secret_key = "production_secret_2023"
    customer_username = "acme_corporation"
    
    # Generate a license key using the original implementation
    # (This simulates a key that was already issued to a customer)
    original = OriginalImplementation(secret_key)
    existing_license = original.generate_serial_key(
        customer_username, 
        "2023-06-01", 
        "2025-05-31"
    )
    
    print(f"\nExisting Customer License:")
    print(f"  Customer: {customer_username}")
    print(f"  License Key: {existing_license[:40]}...")
    print(f"  Valid Period: 2023-06-01 to 2025-05-31")
    
    # Now test if the obfuscated implementation can validate it
    print("\nValidating with new obfuscated implementation...")
    obfuscated = ObfuscatedImplementation(secret_key)
    result = obfuscated.validate_serial_key(customer_username, existing_license)
    
    if result and result[0] == "2023-06-01" and result[1] == "2025-05-31":
        print(f"✅ SUCCESS: Existing license key remains valid!")
        print(f"   Customer's license will continue to work after update")
    else:
        print(f"❌ CRITICAL FAILURE: Existing license key is broken!")
        print(f"   This would invalidate all customer licenses!")
        print(f"   Result: {result}")
        return False
    
    return True

def main():
    print("=" * 70)
    print("SERIAL KEY & LICENSE COMPATIBILITY TEST SUITE")
    print("=" * 70)
    
    all_passed = True
    
    # Run serial key compatibility tests
    if not test_serial_key_compatibility():
        all_passed = False
        print("\n⚠️  Serial key compatibility test FAILED!")
    
    # Test existing license keys
    if not test_existing_license_keys():
        all_passed = False
        print("\n⚠️  Existing license key test FAILED!")
    
    # Final verdict
    print("\n" + "=" * 70)
    if all_passed:
        print("✅ ALL SERIAL KEY TESTS PASSED!")
        print("\nConfirmed compatibility:")
        print("  • Existing serial keys will continue to work")
        print("  • Customer licenses remain valid")
        print("  • No disruption to licensed users")
        print("\nThe obfuscated implementation is SAFE to deploy.")
    else:
        print("❌ SERIAL KEY COMPATIBILITY FAILED!")
        print("\n⚠️  DO NOT DEPLOY THIS UPDATE!")
        print("It would break existing customer licenses!")
    print("=" * 70)
    
    return all_passed

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)