#!/usr/bin/env python3
"""
Test consistent MAEV2: prefix for both serial keys and data encryption
"""

def test_consistent_prefix():
    """Test that everything uses MAEV2: prefix consistently"""
    print("=" * 70)
    print("TESTING CONSISTENT MAEV2: PREFIX")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_secret_key")
    
    # Test 1: Serial keys use MAEV2: prefix
    print("\n1. Serial Keys with MAEV2: prefix...")
    
    # V2 key (after cutoff date)
    v2_key = skm.generate_serial_key("user123", "2025-09-10", "2026-09-10")
    print(f"   V2 serial key starts with: {v2_key[:10]}")
    
    if v2_key.startswith("MAEV2:"):
        print("   ✅ V2 serial key has MAEV2: prefix (not _v2 suffix)")
    else:
        print(f"   ❌ V2 serial key doesn't have MAEV2: prefix")
        return False
    
    # Validate V2 key
    result = skm.validate_serial_key("user123", v2_key)
    if result == ("2025-09-10", "2026-09-10"):
        print("   ✅ V2 serial key validates correctly")
    else:
        print("   ❌ V2 serial key validation failed")
        return False
    
    # V1 key (before cutoff date)
    v1_key = skm.generate_serial_key("olduser", "2024-01-01", "2024-12-31")
    print(f"\n   V1 serial key starts with: {v1_key[:10]}")
    
    if not v1_key.startswith("MAEV2:"):
        print("   ✅ V1 serial key has no MAEV2: prefix (correct)")
    else:
        print("   ❌ V1 serial key shouldn't have MAEV2: prefix")
        return False
    
    # Test 2: Data encryption also uses MAEV2: prefix
    print("\n2. Data Encryption with MAEV2: prefix...")
    
    test_data = b"Test data"
    encrypted_data = skm.encrypt_data(test_data)
    
    if encrypted_data.startswith(b"MAEV2:"):
        print("   ✅ Encrypted data has MAEV2: prefix")
    else:
        print("   ❌ Encrypted data doesn't have MAEV2: prefix")
        return False
    
    # Test 3: Everything is consistent
    print("\n3. Consistency Check...")
    print("   ✅ Serial keys V2: MAEV2: prefix")
    print("   ✅ Data encryption V2: MAEV2: prefix")
    print("   ✅ File encryption V2: MAEV2F: prefix (for file-specific)")
    print("   ✅ All V2 formats use MAEV2: prefix family")
    
    return True

def test_auto_detection():
    """Test that auto-detection works for both serial keys and data"""
    print("\n" + "=" * 70)
    print("TESTING AUTO-DETECTION WITH MAEV2: PREFIX")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_key")
    
    print("\n1. Serial Key Auto-Detection...")
    
    # Generate V2 key
    v2_key = skm.generate_serial_key("newuser", "2025-10-01", "2026-10-01")
    print(f"   V2 key: {v2_key[:30]}...")
    
    # Validation auto-detects V2 from MAEV2: prefix
    result = skm.validate_serial_key("newuser", v2_key)
    print(f"   Auto-detected as V2: {v2_key.startswith('MAEV2:')}")
    print(f"   Validation result: {result}")
    
    print("\n2. Data Encryption Auto-Detection...")
    
    # Encrypt data (V2)
    data = b"Customer data"
    encrypted = skm.encrypt_data(data)
    print(f"   Encrypted: {encrypted[:30]}...")
    
    # Decryption auto-detects V2 from MAEV2: prefix
    decrypted = skm.decrypt_data(encrypted)
    print(f"   Auto-detected as V2: {encrypted.startswith(b'MAEV2:')}")
    print(f"   Decryption successful: {decrypted == data}")
    
    return True

def test_no_more_suffix():
    """Confirm we're not using _v2 suffix anymore"""
    print("\n" + "=" * 70)
    print("CONFIRMING NO MORE _v2 SUFFIX")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_key")
    
    # Generate V2 serial key
    v2_key = skm.generate_serial_key("user", "2025-11-01", "2026-11-01")
    
    print(f"\nV2 Serial Key: {v2_key[:50]}...")
    print(f"Starts with MAEV2:: {v2_key.startswith('MAEV2:')}")
    print(f"Ends with _v2: {v2_key.endswith('_v2')}")
    
    if v2_key.startswith("MAEV2:") and not v2_key.endswith("_v2"):
        print("\n✅ Using prefix (MAEV2:) instead of suffix (_v2)")
        print("✅ Consistent with data encryption approach")
    else:
        print("\n❌ Still using old suffix approach")
        return False
    
    return True

def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║          CONSISTENT MAEV2: PREFIX FOR EVERYTHING             ║
║                                                              ║
║   Serial keys and data encryption both use MAEV2: prefix     ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    all_pass = True
    
    if not test_consistent_prefix():
        print("\n❌ PREFIX CONSISTENCY TEST FAILED!")
        all_pass = False
    
    if not test_auto_detection():
        print("\n❌ AUTO-DETECTION TEST FAILED!")
        all_pass = False
    
    if not test_no_more_suffix():
        print("\n❌ SUFFIX CHECK FAILED!")
        all_pass = False
    
    print("\n" + "=" * 70)
    if all_pass:
        print("✅ ALL TESTS PASSED!")
        print("\nCONSISTENT APPROACH:")
        print("• Serial keys V2: MAEV2: prefix ✅")
        print("• Data encryption V2: MAEV2: prefix ✅")
        print("• NO MORE _v2 suffix ✅")
        print("• Auto-detection by prefix ✅")
        print("• Everything consistent ✅")
        print("\n🎉 PERFECT CONSISTENCY ACHIEVED!")
    else:
        print("❌ TESTS FAILED!")
    print("=" * 70)

if __name__ == "__main__":
    main()