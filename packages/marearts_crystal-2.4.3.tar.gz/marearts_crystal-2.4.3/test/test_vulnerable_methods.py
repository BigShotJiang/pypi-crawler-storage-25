#!/usr/bin/env python3
"""
Analysis of public methods that don't use internal cdef protection
"""

def analyze_vulnerable_methods():
    """Identify which public methods are vulnerable to hijacking"""
    
    print("=" * 60)
    print("VULNERABILITY ANALYSIS: Public Methods Without Cdef Protection")
    print("=" * 60)
    
    # Methods with cdef protection (SAFE)
    protected_methods = {
        "generate_serial_key": "_generate_serial_key_internal",
        "validate_serial_key": "_validate_serial_key_internal",
        "validate_date": "_validate_date_internal",
        "encrypt_data": "_encrypt_data_internal",
        "decrypt_data": "_decrypt_data_internal",
        "string_to_secret_key": "_derive_key_from_string",
        "secret_key_to_string": "_decrypt_with_key",
    }
    
    # Methods WITHOUT cdef protection (VULNERABLE)
    vulnerable_methods = [
        {
            "method": "encrypt_string",
            "risk": "HIGH",
            "impact": "Could be hijacked to leak plaintext or use weak encryption",
            "current_impl": "Directly uses self.fernet.encrypt()"
        },
        {
            "method": "decrypt_string", 
            "risk": "HIGH",
            "impact": "Could be hijacked to always return fake decrypted data",
            "current_impl": "Directly uses self.fernet.decrypt()"
        },
        {
            "method": "generate_end_date",
            "risk": "MEDIUM",
            "impact": "Could be hijacked to return incorrect expiry dates",
            "current_impl": "Direct datetime calculation"
        },
        {
            "method": "get_today_date",
            "risk": "MEDIUM", 
            "impact": "Could be hijacked to return fake current date",
            "current_impl": "Direct datetime.now() call"
        },
        {
            "method": "is_v2_serial_key",
            "risk": "HIGH",
            "impact": "Could be hijacked to misidentify key versions",
            "current_impl": "Simple string prefix check"
        },
        {
            "method": "is_v2_data",
            "risk": "HIGH",
            "impact": "Could be hijacked to misidentify data versions",
            "current_impl": "Simple bytes prefix check"
        }
    ]
    
    print("\n✅ PROTECTED METHODS (Using cdef internals):")
    print("-" * 40)
    for pub, internal in protected_methods.items():
        print(f"  • {pub}() → {internal}()")
    
    print("\n⚠️  VULNERABLE METHODS (No cdef protection):")
    print("-" * 40)
    for method in vulnerable_methods:
        print(f"\n  • {method['method']}()")
        print(f"    Risk Level: {method['risk']}")
        print(f"    Impact: {method['impact']}")
        print(f"    Current: {method['current_impl']}")
    
    print("\n" + "=" * 60)
    print("ATTACK SCENARIOS FOR VULNERABLE METHODS:")
    print("=" * 60)
    
    print("""
1. encrypt_string() Hijack:
   def fake_encrypt(self, input_string):
       # Log passwords before encryption
       with open('/tmp/stolen.txt', 'a') as f:
           f.write(input_string + '\\n')
       return self.fernet.encrypt(input_string.encode()).decode()
   
2. decrypt_string() Hijack:
   def fake_decrypt(self, encrypted_string):
       # Always return a backdoor password
       return "backdoor123"
       
3. get_today_date() Hijack:
   def fake_today(self):
       # Make expired licenses appear valid
       return "2099-12-31"
       
4. is_v2_serial_key() Hijack:
   def fake_version_check(self, serial_key):
       # Force all keys to be treated as V2
       return True
""")
    
    return vulnerable_methods

def recommend_fixes():
    """Recommend fixes for vulnerable methods"""
    
    print("\n" + "=" * 60)
    print("RECOMMENDED FIXES:")
    print("=" * 60)
    
    fixes = [
        {
            "method": "encrypt_string",
            "fix": """
    def encrypt_string(self, str input_string):
        return self._encrypt_string_internal(input_string)
    
    cdef str _encrypt_string_internal(self, str input_string):
        if not input_string:
            raise ValueError("Cannot encrypt empty string")
        encrypted = self.fernet.encrypt(input_string.encode())
        return encrypted.decode()
"""
        },
        {
            "method": "decrypt_string",
            "fix": """
    def decrypt_string(self, str encrypted_string):
        return self._decrypt_string_internal(encrypted_string)
    
    cdef object _decrypt_string_internal(self, str encrypted_string):
        if not encrypted_string:
            return None
        try:
            decrypted = self.fernet.decrypt(encrypted_string.encode())
            return decrypted.decode()
        except InvalidToken:
            return None
"""
        },
        {
            "method": "get_today_date",
            "fix": """
    def get_today_date(self):
        return self._get_today_date_internal()
    
    cdef str _get_today_date_internal(self):
        return datetime.now().strftime("%Y-%m-%d")
"""
        },
        {
            "method": "is_v2_serial_key",
            "fix": """
    def is_v2_serial_key(self, str serial_key):
        return self._is_v2_serial_key_internal(serial_key)
    
    cdef bint _is_v2_serial_key_internal(self, str serial_key):
        if not serial_key:
            return False
        return serial_key.startswith("MAEV2:")
"""
        }
    ]
    
    for fix in fixes:
        print(f"\n{fix['method']}() Fix:")
        print("-" * 40)
        print(fix['fix'])
    
    print("\n✅ These fixes move all logic to unhackable cdef methods")

if __name__ == "__main__":
    vulnerable = analyze_vulnerable_methods()
    recommend_fixes()
    
    print("\n" + "=" * 60)
    print(f"SUMMARY: Found {len(vulnerable)} vulnerable methods that need cdef protection")
    print("=" * 60)