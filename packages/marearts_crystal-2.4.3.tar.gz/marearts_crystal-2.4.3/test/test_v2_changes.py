#!/usr/bin/env python3
"""Test the new V1/V2 encryption interface changes"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from marearts_crystal import ma_crystal

def test_v1_v2_interface():
    print("Testing V1/V2 Encryption Interface")
    print("=" * 60)
    
    # Initialize
    skm = ma_crystal.ma_crystal("test_key_123")
    test_data = b"Hello World! This is test data."
    filename = "test_file.txt"
    
    # Test 1: V1 encryption (no filename)
    print("\n1. V1 Encryption (no filename):")
    v1_encrypted = skm.encrypt_data(test_data)
    print(f"   Encrypted (first 20 bytes): {v1_encrypted[:20]}")
    print(f"   Has MAEV2: prefix? {v1_encrypted.startswith(b'MAEV2:')}")
    
    # Test 2: V1 decryption (no filename)
    print("\n2. V1 Decryption (no filename):")
    v1_decrypted = skm.decrypt_data(v1_encrypted)
    print(f"   Decrypted matches original? {v1_decrypted == test_data}")
    
    # Test 3: V2 encryption (with filename)
    print("\n3. V2 Encryption (with filename):")
    v2_encrypted = skm.encrypt_data(test_data, filename)
    print(f"   Encrypted (first 20 bytes): {v2_encrypted[:20]}")
    print(f"   Has MAEV2: prefix? {v2_encrypted.startswith(b'MAEV2:')}")
    
    # Test 4: V2 decryption with correct filename
    print("\n4. V2 Decryption (with correct filename):")
    v2_decrypted = skm.decrypt_data(v2_encrypted, filename)
    print(f"   Decrypted matches original? {v2_decrypted == test_data}")
    
    # Test 5: V2 decryption with wrong filename should fail
    print("\n5. V2 Decryption (with wrong filename):")
    wrong_decrypted = skm.decrypt_data(v2_encrypted, "wrong_file.txt")
    print(f"   Decryption failed as expected? {wrong_decrypted is None}")
    
    # Test 6: V2 data without filename should raise error
    print("\n6. V2 Decryption without filename (should error):")
    try:
        skm.decrypt_data(v2_encrypted)
        print("   ERROR: Should have raised ValueError!")
    except ValueError as e:
        print(f"   Correctly raised error: {e}")
    
    # Test 7: Cross-compatibility - V1 decrypt with filename (should ignore)
    print("\n7. V1 data decrypted with filename (should work):")
    v1_with_filename = skm.decrypt_data(v1_encrypted, "any_filename.txt")
    print(f"   Decrypted matches original? {v1_with_filename == test_data}")
    
    # Test 8: Different keys should fail
    print("\n8. Wrong key test:")
    wrong_skm = ma_crystal.ma_crystal("wrong_key")
    wrong_v1 = wrong_skm.decrypt_data(v1_encrypted)
    wrong_v2 = wrong_skm.decrypt_data(v2_encrypted, filename)
    print(f"   V1 decryption failed? {wrong_v1 is None}")
    print(f"   V2 decryption failed? {wrong_v2 is None}")
    
    print("\n" + "=" * 60)
    print("All tests completed successfully!")
    return True

if __name__ == "__main__":
    test_v1_v2_interface()