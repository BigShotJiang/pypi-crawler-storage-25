#!/usr/bin/env python3
"""
Complete V2 Implementation Test
Tests serial key signatures and data encryption/decryption
"""

import sys
import os

# Add parent directory to path to import marearts_crystal
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_v2_complete():
    """Complete test of V2 functionality"""
    
    print("=" * 70)
    print("MareArts Crystal V2 - Complete Implementation Test")
    print("=" * 70)
    
    try:
        # Import the module
        from marearts_crystal import ma_crystal
        print("✓ Module imported successfully")
        
        # Initialize
        secret_key = "test_master_key_2024"
        skm = ma_crystal(secret_key)
        print(f"✓ Initialized ma_crystal with secret key")
        
        # ================================================================
        # TEST 1: V2 Serial Key Generation Returns Tuple
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 1: V2 Serial Key Generation")
        print("-" * 70)
        
        username = "john_doe"
        start_date = "2025-10-01"  # After V2 cutoff
        end_date = "2026-03-31"
        
        result = skm.generate_serial_key(username, start_date, end_date)
        
        # Check if returns tuple with serial key and signature
        if isinstance(result, tuple) and len(result) == 2:
            serial_key, signature = result
            print(f"✓ Returns tuple: (serial_key, signature)")
            print(f"  Serial Key: {serial_key[:50]}...")
            print(f"  Signature: {signature}")
            
            # Verify serial key has V2 prefix
            if serial_key.startswith("MAEV2:"):
                print(f"✓ Serial key has MAEV2: prefix")
            else:
                print(f"✗ Missing MAEV2: prefix")
                return False
                
            # Verify signature format (16 hex characters)
            if len(signature) == 16:
                try:
                    int(signature, 16)
                    print(f"✓ Signature is 16-character hexadecimal")
                except ValueError:
                    print(f"✗ Signature is not valid hexadecimal")
                    return False
            else:
                print(f"✗ Signature length is {len(signature)}, expected 16")
                return False
        else:
            print(f"✗ Expected tuple(serial_key, signature), got {type(result)}")
            return False
        
        # ================================================================
        # TEST 2: V2 Validation Returns 3 Values with Signature
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 2: V2 Serial Key Validation")
        print("-" * 70)
        
        validation = skm.validate_serial_key(username, serial_key)
        
        if validation and len(validation) == 3:
            val_start, val_end, val_signature = validation
            print(f"✓ Validation returns 3 values")
            print(f"  Start Date: {val_start}")
            print(f"  End Date: {val_end}")
            print(f"  Signature: {val_signature}")
            
            # Verify dates match
            if val_start == start_date and val_end == end_date:
                print(f"✓ Dates match original values")
            else:
                print(f"✗ Date mismatch!")
                return False
            
            # Verify signature matches
            if val_signature == signature:
                print(f"✓ Signature matches! Validation successful")
            else:
                print(f"✗ Signature mismatch!")
                print(f"  Expected: {signature}")
                print(f"  Got: {val_signature}")
                return False
        else:
            print(f"✗ Validation failed or wrong number of values")
            return False
        
        # ================================================================
        # TEST 3: Signature Uniqueness
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 3: Signature Uniqueness")
        print("-" * 70)
        
        # Different username
        user2 = "alice_smith"
        result2 = skm.generate_serial_key(user2, start_date, end_date)
        if isinstance(result2, tuple):
            _, sig2 = result2
            if sig2 != signature:
                print(f"✓ Different user = different signature")
                print(f"  john_doe: {signature}")
                print(f"  alice_smith: {sig2}")
            else:
                print(f"✗ Same signature for different users!")
                return False
        
        # Different dates
        result3 = skm.generate_serial_key(username, "2025-11-01", "2026-04-30")
        if isinstance(result3, tuple):
            _, sig3 = result3
            if sig3 != signature:
                print(f"✓ Different dates = different signature")
                print(f"  Original: {signature}")
                print(f"  New dates: {sig3}")
            else:
                print(f"✗ Same signature for different dates!")
                return False
        
        # ================================================================
        # TEST 4: Tampering Detection
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 4: Tampering Detection")
        print("-" * 70)
        
        # Tampered serial key
        tampered = serial_key[:-5] + "XXXXX"
        tampered_result = skm.validate_serial_key(username, tampered)
        
        if tampered_result is None:
            print(f"✓ Tampered serial key rejected")
        else:
            print(f"✗ Tampered serial key accepted!")
            return False
        
        # Wrong username
        wrong_result = skm.validate_serial_key("hacker", serial_key)
        
        if wrong_result is None:
            print(f"✓ Wrong username rejected")
        else:
            print(f"✗ Wrong username accepted!")
            return False
        
        # ================================================================
        # TEST 5: V2 Data Encryption with Filename
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 5: V2 Data Encryption")
        print("-" * 70)
        
        test_data = b"Sensitive data that needs encryption"
        filename = "important_file.dat"
        
        # Encrypt with filename (V2)
        encrypted_v2 = skm.encrypt_data(test_data, filename)
        
        if encrypted_v2.startswith(b"MAEV2:"):
            print(f"✓ V2 encrypted data has MAEV2: prefix")
            print(f"  Size: {len(encrypted_v2)} bytes")
        else:
            print(f"✗ V2 data missing MAEV2: prefix")
            return False
        
        # Decrypt with correct filename
        decrypted = skm.decrypt_data(encrypted_v2, filename)
        
        if decrypted == test_data:
            print(f"✓ V2 decryption successful with correct filename")
        else:
            print(f"✗ V2 decryption failed")
            return False
        
        # Try with wrong filename
        wrong_decrypt = skm.decrypt_data(encrypted_v2, "wrong_file.dat")
        
        if wrong_decrypt is None:
            print(f"✓ Wrong filename correctly fails decryption")
        else:
            print(f"✗ Wrong filename should fail!")
            return False
        
        # Try without filename (should fail for V2 data)
        try:
            no_file_decrypt = skm.decrypt_data(encrypted_v2, None)
            if no_file_decrypt is None:
                print(f"✓ V2 data requires filename parameter")
            else:
                print(f"✗ V2 data decrypted without filename!")
                return False
        except ValueError as e:
            print(f"✓ V2 data correctly requires filename: {e}")
        
        # ================================================================
        # TEST 6: V1 Data Encryption (Backward Compatibility)
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 6: V1 Data Encryption (Backward Compatibility)")
        print("-" * 70)
        
        # Encrypt without filename (V1)
        encrypted_v1 = skm.encrypt_data(test_data)
        
        if not encrypted_v1.startswith(b"MAEV2:"):
            print(f"✓ V1 encrypted data has no MAEV2: prefix")
            print(f"  Size: {len(encrypted_v1)} bytes")
        else:
            print(f"✗ V1 data should not have MAEV2: prefix")
            return False
        
        # Decrypt V1 data
        decrypted_v1 = skm.decrypt_data(encrypted_v1)
        
        if decrypted_v1 == test_data:
            print(f"✓ V1 decryption successful")
        else:
            print(f"✗ V1 decryption failed")
            return False
        
        # ================================================================
        # TEST 7: String Encryption
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 7: String Encryption/Decryption")
        print("-" * 70)
        
        test_string = "Hello, MareArts Crystal V2!"
        encrypted_str = skm.encrypt_string(test_string)
        decrypted_str = skm.decrypt_string(encrypted_str)
        
        if decrypted_str == test_string:
            print(f"✓ String encryption/decryption successful")
            print(f"  Original: {test_string}")
            print(f"  Encrypted: {encrypted_str[:50]}...")
        else:
            print(f"✗ String decryption failed")
            return False
        
        # ================================================================
        # TEST 8: Cross-Instance Validation
        # ================================================================
        print("\n" + "=" * 70)
        print("TEST 8: Cross-Instance Validation")
        print("-" * 70)
        
        # Create second instance with same key
        skm2 = ma_crystal(secret_key)
        
        # Validate serial key with second instance
        validation2 = skm2.validate_serial_key(username, serial_key)
        
        if validation2 and len(validation2) == 3:
            if validation2[2] == signature:
                print(f"✓ Cross-instance validation successful")
                print(f"  Both instances return same signature")
            else:
                print(f"✗ Cross-instance signature mismatch!")
                return False
        else:
            print(f"✗ Cross-instance validation failed")
            return False
        
        # ================================================================
        # SUMMARY
        # ================================================================
        print("\n" + "=" * 70)
        print("✅ ALL TESTS PASSED!")
        print("=" * 70)
        print("\nV2 Implementation Summary:")
        print("1. Serial key generation returns (key, signature) tuple")
        print("2. Validation returns (start, end, signature) for verification")
        print("3. Signatures are unique per user/dates/secret")
        print("4. Tampering is detected and rejected")
        print("5. V2 data encryption uses filename-based keys")
        print("6. V1 backward compatibility maintained")
        print("7. Cross-instance validation works correctly")
        
        return True
        
    except ImportError as e:
        print(f"✗ Failed to import module: {e}")
        print("\nMake sure to build the module first:")
        print("  cd /media/m2/dev2/marearts-crystal-main/marearts-crystal-pypi")
        print("  ./building_wheels.sh")
        return False
        
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_v2_complete()
    sys.exit(0 if success else 1)