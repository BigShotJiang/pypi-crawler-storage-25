#!/usr/bin/env python3
"""
Test that the library works correctly after removing all logging
"""

def test_no_logging():
    """Verify functionality without logging"""
    print("=" * 70)
    print("TESTING FUNCTIONALITY AFTER REMOVING LOGGING")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    # Create instance
    skm = ma_crystal("test_secret_key")
    print("✅ Instance creation works")
    
    # Generate V1 key (before cutoff)
    v1_key = skm.generate_serial_key("user1", "2024-01-01", "2024-12-31")
    print("✅ V1 key generation works")
    
    # Validate V1 key
    result = skm.validate_serial_key("user1", v1_key)
    assert result == ("2024-01-01", "2024-12-31"), "V1 validation failed"
    print("✅ V1 key validation works")
    
    # Generate V2 key (after cutoff)
    v2_key = skm.generate_serial_key("user2", "2025-09-10", "2026-09-10")
    assert v2_key.endswith("_v2"), "V2 key missing suffix"
    print("✅ V2 key generation works")
    
    # Validate V2 key
    result = skm.validate_serial_key("user2", v2_key)
    assert result == ("2025-09-10", "2026-09-10"), "V2 validation failed"
    print("✅ V2 key validation works")
    
    # Test rate limiting (should silently fail after 5 attempts)
    for i in range(6):
        result = skm.validate_serial_key("bruteforce", "invalid")
        if i < 5:
            assert result is None, f"Attempt {i+1} should return None"
        else:
            # 6th attempt should be rate limited
            assert result is None, "Rate limiting not working"
    print("✅ Rate limiting works (silently)")
    
    # Test encryption/decryption
    encrypted = skm.encrypt_string("test data")
    decrypted = skm.decrypt_string(encrypted)
    assert decrypted == "test data", "Encryption/decryption failed"
    print("✅ Encryption/decryption works")
    
    # Test invalid inputs (should fail silently)
    result = skm.validate_serial_key("x" * 300, "key")  # Too long username
    assert result is None, "Should reject long username"
    print("✅ Input validation works (silently)")
    
    print("\n" + "=" * 70)
    print("✅ ALL TESTS PASSED - NO LOGGING LEAKS!")
    print("Security improved: No information disclosure to attackers")
    print("=" * 70)

if __name__ == "__main__":
    test_no_logging()