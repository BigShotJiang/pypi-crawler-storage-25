#!/usr/bin/env python3
"""
Test that security hardening doesn't break compatibility
CRITICAL: Must pass for 1 million users!
"""

def test_api_compatibility():
    """Test that all public APIs still work"""
    print("=" * 70)
    print("TESTING API COMPATIBILITY AFTER HARDENING")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    # Test 1: Can still create instance
    try:
        skm = ma_crystal("test_secret_key")
        print("✅ Instance creation: PASS")
    except Exception as e:
        print(f"❌ Instance creation: FAIL - {e}")
        return False
    
    # Test 2: Can still generate keys
    try:
        key = skm.generate_serial_key("testuser", "2024-01-01", "2024-12-31")
        print("✅ Key generation: PASS")
    except Exception as e:
        print(f"❌ Key generation: FAIL - {e}")
        return False
    
    # Test 3: Can still validate keys
    try:
        result = skm.validate_serial_key("testuser", key)
        if result == ("2024-01-01", "2024-12-31"):
            print("✅ Key validation: PASS")
        else:
            print(f"❌ Key validation: Wrong result - {result}")
            return False
    except Exception as e:
        print(f"❌ Key validation: FAIL - {e}")
        return False
    
    # Test 4: Can still encrypt/decrypt
    try:
        encrypted = skm.encrypt_string("test data")
        decrypted = skm.decrypt_string(encrypted)
        if decrypted == "test data":
            print("✅ Encryption/Decryption: PASS")
        else:
            print(f"❌ Encryption/Decryption: Wrong result")
            return False
    except Exception as e:
        print(f"❌ Encryption/Decryption: FAIL - {e}")
        return False
    
    return True

def test_security_improvements():
    """Test that security features still work"""
    print("\n" + "=" * 70)
    print("TESTING SECURITY FEATURES")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_secret_key")
    
    # Test 1: Rate limiting still works (internal)
    for i in range(6):
        result = skm.validate_serial_key("bruteforce", "invalid_key")
        if i < 5:
            # First 5 should work (return None for invalid key)
            if result is not None:
                print(f"❌ Rate limit test {i}: Should return None")
                return False
        else:
            # 6th should be rate limited
            if result is not None:
                print(f"❌ Rate limit not working at attempt {i}")
                return False
    print("✅ Rate limiting: PASS")
    
    # Test 2: Input validation still works
    try:
        skm.generate_serial_key("a" * 300, "2024-01-01", "2024-12-31")
        print("❌ Username validation: Should have failed")
        return False
    except ValueError:
        print("✅ Username validation: PASS")
    
    # Test 3: Date validation still works
    try:
        skm.generate_serial_key("user", "invalid-date", "2024-12-31")
        print("❌ Date validation: Should have failed")
        return False
    except ValueError:
        print("✅ Date validation: PASS")
    
    return True

def test_cannot_access_internals():
    """Test that internal methods are no longer accessible"""
    print("\n" + "=" * 70)
    print("TESTING SECURITY HARDENING")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_secret_key")
    
    # Test 1: Cannot access helper methods
    try:
        skm._check_rate_limit("user")
        print("❌ _check_rate_limit is still accessible!")
        return False
    except AttributeError:
        print("✅ _check_rate_limit: Not accessible (Good!)")
    
    # Test 2: Cannot access _validate_username
    try:
        skm._validate_username("user")
        print("❌ _validate_username is still accessible!")
        return False
    except AttributeError:
        print("✅ _validate_username: Not accessible (Good!)")
    
    # Test 3: Cannot directly access rate limiter
    try:
        # Try to access with single underscore (old way)
        limiter = skm._rate_limiter
        print("❌ _rate_limiter is accessible!")
        return False
    except AttributeError:
        print("✅ _rate_limiter: Not directly accessible (Good!)")
    
    # Test 4: Name mangled attributes are harder to access
    try:
        # This would be the mangled name
        limiter = skm._ma_crystal__rate_limiter
        print("⚠️  Rate limiter accessible via name mangling (expected)")
        # This is Python's name mangling - harder but not impossible
    except AttributeError:
        print("✅ Rate limiter: Fully protected")
    
    return True

def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║           SECURITY HARDENING COMPATIBILITY TEST              ║
║                                                              ║
║         Testing for 1 MILLION users compatibility            ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    all_pass = True
    
    # Test 1: API Compatibility
    if not test_api_compatibility():
        print("\n❌ API COMPATIBILITY BROKEN - DO NOT DEPLOY!")
        all_pass = False
    
    # Test 2: Security Features
    if not test_security_improvements():
        print("\n❌ SECURITY FEATURES BROKEN!")
        all_pass = False
    
    # Test 3: Hardening
    if not test_cannot_access_internals():
        print("\n⚠️  HARDENING INCOMPLETE (but compatible)")
    
    print("\n" + "=" * 70)
    if all_pass:
        print("✅ ALL TESTS PASSED - SAFE FOR 1 MILLION USERS!")
        print("Security improved WITHOUT breaking compatibility!")
    else:
        print("❌ TESTS FAILED - DO NOT DEPLOY!")
    print("=" * 70)

if __name__ == "__main__":
    main()