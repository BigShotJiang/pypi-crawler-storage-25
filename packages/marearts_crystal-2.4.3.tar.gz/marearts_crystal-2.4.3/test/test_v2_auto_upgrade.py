#!/usr/bin/env python3
"""
Test V2 Auto-Upgrade: encrypt_data now uses V2 by default
while decrypt_data handles both V1 and V2 automatically
"""

def test_v2_auto_upgrade():
    """Test that encrypt_data now uses V2 automatically"""
    print("=" * 70)
    print("TESTING V2 AUTO-UPGRADE FOR encrypt_data")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_secret_key")
    
    # Test 1: New encryption uses V2 automatically
    print("\n1. Testing new encrypt_data uses V2...")
    test_data = b"Customer data that will be encrypted with V2"
    
    encrypted = skm.encrypt_data(test_data)
    print(f"   Encrypted data starts with: {encrypted[:10]}")
    
    # Check for V2 marker
    if encrypted.startswith(b"MAEV2:"):
        print("   ✅ New encrypt_data uses V2 (has MAEV2: prefix)")
    else:
        print("   ❌ encrypt_data didn't use V2!")
        return False
    
    # Test 2: decrypt_data handles V2 automatically
    print("\n2. Testing decrypt_data handles V2...")
    decrypted = skm.decrypt_data(encrypted)
    
    if decrypted == test_data:
        print("   ✅ decrypt_data successfully handled V2 data")
    else:
        print("   ❌ decrypt_data failed with V2!")
        return False
    
    return True

def test_backward_compatibility():
    """Test that old V1 data still decrypts correctly"""
    print("\n" + "=" * 70)
    print("TESTING BACKWARD COMPATIBILITY WITH V1 DATA")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_secret_key")
    
    # Simulate old V1 encrypted data (without MAEV2: prefix)
    # We need to manually create V1 data for testing
    print("\n1. Simulating existing V1 encrypted data...")
    
    # Use internal fernet directly to create V1-style data
    test_data = b"Legacy customer data encrypted with V1"
    v1_encrypted = skm.fernet.encrypt(test_data)  # Direct V1 encryption
    
    print(f"   V1 data starts with: {v1_encrypted[:10]}")
    print(f"   V1 data does NOT have MAEV2: prefix: {not v1_encrypted.startswith(b'MAEV2:')}")
    
    # Test that decrypt_data handles V1
    print("\n2. Testing decrypt_data handles old V1 data...")
    decrypted = skm.decrypt_data(v1_encrypted)
    
    if decrypted == test_data:
        print("   ✅ Old V1 data still decrypts correctly!")
    else:
        print("   ❌ Failed to decrypt V1 data!")
        return False
    
    return True

def test_mixed_data_scenario():
    """Test handling mixed V1 and V2 data in production"""
    print("\n" + "=" * 70)
    print("TESTING MIXED V1/V2 DATA SCENARIO")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("production_key")
    
    print("\nSimulating production with mixed data:")
    
    # Old customer data (V1)
    old_data = b"Customer enrolled in 2023"
    v1_encrypted = skm.fernet.encrypt(old_data)  # Simulate old V1
    
    # New customer data (V2)
    new_data = b"Customer enrolled in 2025"
    v2_encrypted = skm.encrypt_data(new_data)  # New V2
    
    print(f"\n1. Old V1 data: {v1_encrypted[:20]}...")
    print(f"2. New V2 data: {v2_encrypted[:20]}...")
    
    # Decrypt both with same decrypt_data method
    print("\n3. Testing decrypt_data handles both...")
    
    old_decrypted = skm.decrypt_data(v1_encrypted)
    new_decrypted = skm.decrypt_data(v2_encrypted)
    
    if old_decrypted == old_data:
        print("   ✅ V1 data decrypted successfully")
    else:
        print("   ❌ V1 decryption failed")
        return False
    
    if new_decrypted == new_data:
        print("   ✅ V2 data decrypted successfully")
    else:
        print("   ❌ V2 decryption failed")
        return False
    
    print("\n   ✅ decrypt_data handles both V1 and V2 seamlessly!")
    return True

def test_performance():
    """Check performance impact of V2"""
    print("\n" + "=" * 70)
    print("PERFORMANCE CHECK")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    import time
    
    skm = ma_crystal("test_key")
    test_data = b"x" * 1024 * 100  # 100KB
    
    # Test V2 performance
    start = time.time()
    for _ in range(100):
        encrypted = skm.encrypt_data(test_data)
        decrypted = skm.decrypt_data(encrypted)
    v2_time = time.time() - start
    
    print(f"V2 encryption/decryption (100 iterations): {v2_time:.2f}s")
    print("Note: V2 adds 6-byte prefix, negligible overhead")
    
    return True

def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║              V2 AUTO-UPGRADE TEST                            ║
║                                                              ║
║   encrypt_data now uses V2 by default (with MAEV2: prefix)   ║
║   decrypt_data automatically handles both V1 and V2          ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    all_pass = True
    
    # Test V2 auto-upgrade
    if not test_v2_auto_upgrade():
        print("\n❌ V2 AUTO-UPGRADE FAILED!")
        all_pass = False
    
    # Test backward compatibility
    if not test_backward_compatibility():
        print("\n❌ BACKWARD COMPATIBILITY BROKEN!")
        all_pass = False
    
    # Test mixed scenario
    if not test_mixed_data_scenario():
        print("\n❌ MIXED DATA HANDLING FAILED!")
        all_pass = False
    
    # Test performance
    if not test_performance():
        all_pass = False
    
    print("\n" + "=" * 70)
    if all_pass:
        print("✅ ALL TESTS PASSED!")
        print("\nSUMMARY:")
        print("• encrypt_data now uses V2 (adds MAEV2: prefix)")
        print("• decrypt_data auto-detects V1 vs V2")
        print("• Old V1 data still decrypts perfectly")
        print("• New data gets V2 security automatically")
        print("• Zero compatibility issues!")
        print("\n🎉 1 MILLION USERS GET V2 SECURITY AUTOMATICALLY!")
    else:
        print("❌ TESTS FAILED!")
    print("=" * 70)

if __name__ == "__main__":
    main()