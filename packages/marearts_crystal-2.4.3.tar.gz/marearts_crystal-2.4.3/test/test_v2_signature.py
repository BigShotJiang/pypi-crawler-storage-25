#!/usr/bin/env python3
"""
Test V2 Signature Implementation
Tests the serial key generation with signature and data encryption
"""

import sys
import os

# For testing local build
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_v2_implementation():
    print("=" * 70)
    print("MareArts Crystal V2 - Implementation Test")
    print("=" * 70)
    
    try:
        from marearts_crystal import ma_crystal
        print("✓ Module imported")
        
        # Initialize
        secret_key = "test_secret_2024"
        skm = ma_crystal(secret_key)
        print("✓ Initialized ma_crystal")
        
        # Test 1: V2 Serial Key Generation
        print("\n--- Test 1: V2 Serial Key Generation ---")
        username = "test_user"
        start_date = "2025-10-01"
        end_date = "2026-03-31"
        
        result = skm.generate_serial_key(username, start_date, end_date)
        
        if isinstance(result, tuple) and len(result) == 2:
            serial_key, signature = result
            print(f"✓ Returns tuple: (serial_key, signature)")
            print(f"  Serial: {serial_key[:40]}...")
            print(f"  Signature: {signature}")
        else:
            print(f"✗ Unexpected return type: {type(result)}")
            return False
        
        # Test 2: V2 Validation with Signature
        print("\n--- Test 2: V2 Validation with Signature ---")
        validation = skm.validate_serial_key(username, serial_key)
        
        if validation and len(validation) == 3:
            val_start, val_end, val_sig = validation
            print(f"✓ Returns 3 values: (start, end, signature)")
            print(f"  Dates: {val_start} to {val_end}")
            print(f"  Signature match: {val_sig == signature}")
            
            if val_sig != signature:
                print(f"✗ Signature mismatch!")
                return False
        else:
            print(f"✗ Validation failed")
            return False
        
        # Test 3: Data Encryption V2
        print("\n--- Test 3: V2 Data Encryption ---")
        test_data = b"Test data for encryption"
        filename = "test.dat"
        
        # V2 encryption with filename
        encrypted_v2 = skm.encrypt_data(test_data, filename)
        print(f"✓ V2 encrypted (with filename)")
        print(f"  Has MAEV2 prefix: {encrypted_v2.startswith(b'MAEV2:')}")
        
        # V2 decryption with filename
        decrypted_v2 = skm.decrypt_data(encrypted_v2, filename)
        if decrypted_v2 == test_data:
            print(f"✓ V2 decryption successful")
        else:
            print(f"✗ V2 decryption failed")
            return False
        
        # Test wrong filename
        try:
            wrong = skm.decrypt_data(encrypted_v2, "wrong.dat")
            if wrong is None:
                print(f"✓ Wrong filename correctly fails")
            else:
                print(f"✗ Wrong filename should fail")
        except:
            print(f"✓ Wrong filename correctly fails")
        
        # Test 4: V1 Data Encryption (backward compatibility)
        print("\n--- Test 4: V1 Data Encryption ---")
        encrypted_v1 = skm.encrypt_data(test_data)  # No filename
        print(f"✓ V1 encrypted (no filename)")
        print(f"  No MAEV2 prefix: {not encrypted_v1.startswith(b'MAEV2:')}")
        
        decrypted_v1 = skm.decrypt_data(encrypted_v1)
        if decrypted_v1 == test_data:
            print(f"✓ V1 decryption successful")
        else:
            print(f"✗ V1 decryption failed")
            return False
        
        # Test 5: Tampering Detection
        print("\n--- Test 5: Tampering Detection ---")
        
        # Tampered serial key
        tampered = serial_key[:-5] + "XXXXX"
        if skm.validate_serial_key(username, tampered) is None:
            print(f"✓ Tampered key rejected")
        else:
            print(f"✗ Tampered key accepted!")
            return False
        
        # Wrong username
        if skm.validate_serial_key("wrong_user", serial_key) is None:
            print(f"✓ Wrong username rejected")
        else:
            print(f"✗ Wrong username accepted!")
            return False
        
        print("\n" + "=" * 70)
        print("✅ ALL TESTS PASSED!")
        print("=" * 70)
        return True
        
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        print("Build the module first: ./building_wheels.sh")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_v2_implementation()
    sys.exit(0 if success else 1)