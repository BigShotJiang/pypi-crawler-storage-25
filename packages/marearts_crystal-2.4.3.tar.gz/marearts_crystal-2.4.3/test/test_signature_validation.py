#!/usr/bin/env python3
"""Test the signature validation for anti-tampering protection"""

print("Signature Validation Test")
print("=" * 60)

print("""
How the signature protection works:
-----------------------------------

1. When validating a V2 serial key, validate_serial_key returns 3 values:
   - start_date
   - end_date  
   - signature (unique 16-char hash)

2. The signature is generated using:
   - The serial key itself
   - Internal Fernet signing key (hacker doesn't have)
   - Username
   - Start and end dates

3. Each serial key has a UNIQUE signature that only real ma_crystal can generate

4. Your app should:
   a) Call validate_serial_key() 
   b) Get (start, end, signature)
   c) Verify signature matches expected pattern
   d) Store signature and verify it hasn't changed

Example validation in your app:
--------------------------------
""")

print('''
# In your app:
from marearts_crystal import ma_crystal

skm = ma_crystal("your_master_key")
username = "john_doe"
serial_key = "MAEV2:gAAAAA..."  # User's serial key

# Validate and get signature
result = skm.validate_serial_key(username, serial_key)

if result:
    if len(result) == 3:  # V2 returns 3 values
        start, end, signature = result
        
        # Signature validation checks:
        # 1. Length should be 16 characters
        if len(signature) != 16:
            print("FAKE: Invalid signature length")
            sys.exit()
        
        # 2. Should be hexadecimal
        try:
            int(signature, 16)
        except ValueError:
            print("FAKE: Invalid signature format")
            sys.exit()
        
        # 3. Store and verify consistency
        # Each serial ALWAYS produces same signature
        stored_signature = get_stored_signature(serial_key)
        if stored_signature and signature != stored_signature:
            print("FAKE: Signature mismatch")
            sys.exit()
        
        # 4. Cross-validation with different instance
        skm2 = ma_crystal("your_master_key")
        result2 = skm2.validate_serial_key(username, serial_key)
        if result2[2] != signature:
            print("FAKE: Cross-validation failed")
            sys.exit()
        
        print(f"✓ Valid V2 serial key")
        print(f"  Start: {start}")
        print(f"  End: {end}")
        print(f"  Signature: {signature}")
        
    else:  # V1 returns 2 values (backward compatibility)
        start, end = result
        print(f"✓ Valid V1 serial key (legacy)")
        print(f"  Start: {start}")
        print(f"  End: {end}")
''')

print("""
Why hackers can't fake this:
-----------------------------
1. Fake function returning ("2024-01-01", "2099-12-31", "fake123")
   will be detected because:
   - Signature won't match expected pattern
   - Different instances produce different signatures
   - Signature changes if ANY input changes

2. To generate correct signature, hacker needs:
   - Internal Fernet signing key (compiled in .so)
   - Exact algorithm implementation
   - All the internal state

3. The signature is deterministic:
   - Same inputs ALWAYS produce same signature
   - Makes it easy to detect fakes

This makes the serial key validation tamper-resistant!
""")