#!/usr/bin/env python3

import sys
import os

# Add the local package to the Python path for testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

try:
    import marearts_crystal
    print(f"MareArts Crystal version: {marearts_crystal.__version__}")
    
    # Also test that the main functionality works
    from marearts_crystal import ma_crystal
    print("✓ Package import successful")
    
    # Test basic functionality
    secret_key = 'test_secret_key'
    skm = ma_crystal(secret_key)
    
    original = 'Hello, version test!'
    encrypted = skm.encrypt_string(original)
    decrypted = skm.decrypt_string(encrypted)
    
    if decrypted == original:
        print("✓ Basic functionality test passed")
    else:
        print("✗ Basic functionality test failed")
        
except ImportError as e:
    print(f"✗ Import failed: {e}")
    print("Note: Run this after building the package")
except Exception as e:
    print(f"✗ Test failed: {e}")