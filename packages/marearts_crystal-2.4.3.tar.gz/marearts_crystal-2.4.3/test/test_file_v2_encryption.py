#!/usr/bin/env python3
"""
Test V2 file encryption with filename-based salt
"""

def test_file_v2_encryption():
    """Test the new file-specific encryption methods"""
    print("=" * 70)
    print("TESTING V2 FILE ENCRYPTION WITH FILENAME SALT")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("test_secret_key")
    
    # Test 1: Basic v2 file encryption
    print("\n1. Testing v2 file encryption...")
    test_data = b"This is my sensitive file content"
    filename = "document_v2.pdf"
    
    encrypted = skm.encrypt_file_v2(test_data, filename)
    decrypted = skm.decrypt_file_v2(encrypted, filename)
    
    if decrypted == test_data:
        print(f"   ✅ File '{filename}' encrypted/decrypted successfully")
    else:
        print("   ❌ V2 encryption/decryption failed!")
        return False
    
    # Test 2: Wrong filename should fail
    print("\n2. Testing filename integrity...")
    wrong_filename = "wrong_name_v2.pdf"
    decrypted_wrong = skm.decrypt_file_v2(encrypted, wrong_filename)
    
    if decrypted_wrong is None:
        print("   ✅ Wrong filename correctly rejected")
    else:
        print("   ❌ Decrypted with wrong filename - SECURITY BREACH!")
        return False
    
    # Test 3: Smart decrypt based on filename
    print("\n3. Testing smart_decrypt_file...")
    
    # V2 file (filename ends with _v2)
    v2_filename = "report_v2.doc"
    v2_encrypted = skm.encrypt_file_v2(test_data, v2_filename)
    v2_decrypted = skm.smart_decrypt_file(v2_encrypted, v2_filename)
    
    if v2_decrypted == test_data:
        print(f"   ✅ Smart decrypt worked for v2 file: {v2_filename}")
    else:
        print("   ❌ Smart decrypt failed for v2 file")
        return False
    
    # V1 file (regular filename)
    v1_filename = "legacy_file.doc"
    v1_encrypted = skm.encrypt_data(test_data)
    v1_decrypted = skm.smart_decrypt_file(v1_encrypted, v1_filename)
    
    if v1_decrypted == test_data:
        print(f"   ✅ Smart decrypt worked for v1 file: {v1_filename}")
    else:
        print("   ❌ Smart decrypt failed for v1 file")
        return False
    
    # Test 4: Path handling (only basename matters)
    print("\n4. Testing path handling...")
    full_path = "/home/user/documents/file_v2.txt"
    relative_path = "documents/file_v2.txt"
    just_filename = "file_v2.txt"
    
    encrypted_full = skm.encrypt_file_v2(test_data, full_path)
    
    # Should decrypt with any path as long as basename matches
    dec1 = skm.decrypt_file_v2(encrypted_full, full_path)
    dec2 = skm.decrypt_file_v2(encrypted_full, relative_path)
    dec3 = skm.decrypt_file_v2(encrypted_full, just_filename)
    
    if dec1 == dec2 == dec3 == test_data:
        print("   ✅ Path-independent: only basename matters")
    else:
        print("   ❌ Path handling failed")
        return False
    
    # Test 5: File renaming breaks v2 decryption
    print("\n5. Testing file rename protection...")
    original_name = "contract_v2.pdf"
    renamed = "contract_renamed_v2.pdf"
    
    encrypted_original = skm.encrypt_file_v2(test_data, original_name)
    decrypted_renamed = skm.decrypt_file_v2(encrypted_original, renamed)
    
    if decrypted_renamed is None:
        print("   ✅ File rename protection working")
    else:
        print("   ❌ File renamed but still decrypted - NOT SECURE!")
        return False
    
    return True

def test_usage_examples():
    """Show practical usage examples"""
    print("\n" + "=" * 70)
    print("USAGE EXAMPLES")
    print("=" * 70)
    
    from marearts_crystal import ma_crystal
    
    skm = ma_crystal("production_secret_key")
    
    print("\nExample 1: Encrypting sensitive files with v2")
    print("-" * 40)
    print("""
    # For maximum security, name your sensitive files with _v2
    filename = "medical_records_v2.pdf"
    with open(filename, 'rb') as f:
        data = f.read()
    
    # Encrypt with filename-based salt
    encrypted = skm.encrypt_file_v2(data, filename)
    
    # Save encrypted file
    with open(filename + ".enc", 'wb') as f:
        f.write(encrypted)
    
    # Later, decrypt (requires correct filename)
    decrypted = skm.decrypt_file_v2(encrypted, filename)
    """)
    
    print("\nExample 2: Smart decryption")
    print("-" * 40)
    print("""
    # Smart decrypt automatically detects version
    filename = "document_v2.pdf"  # v2 file
    decrypted = skm.smart_decrypt_file(encrypted_data, filename)
    
    filename = "legacy.pdf"  # v1 file  
    decrypted = skm.smart_decrypt_file(encrypted_data, filename)
    """)
    
    print("\nExample 3: Migration strategy")
    print("-" * 40)
    print("""
    # Old files: Keep using original names
    "report_2024.pdf" → uses v1 encryption
    
    # New sensitive files: Add _v2 to filename
    "report_2025_v2.pdf" → uses v2 encryption with filename salt
    
    # Batch rename sensitive files
    mv "medical_record.pdf" "medical_record_v2.pdf"
    """)
    
    return True

def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║              V2 FILE ENCRYPTION TEST                         ║
║                                                              ║
║     Testing filename-based salt encryption                   ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    all_pass = True
    
    if not test_file_v2_encryption():
        print("\n❌ FILE V2 ENCRYPTION TEST FAILED!")
        all_pass = False
    
    if not test_usage_examples():
        all_pass = False
    
    print("\n" + "=" * 70)
    if all_pass:
        print("✅ ALL FILE V2 TESTS PASSED!")
        print("\nKEY FEATURES:")
        print("• Files ending with '_v2' use filename-based encryption")
        print("• Each file has unique encryption based on its name")
        print("• Renaming a v2 file prevents decryption (security feature)")
        print("• smart_decrypt_file() automatically detects version")
        print("• Full backward compatibility with existing files")
        print("\n🔒 ENHANCED FILE SECURITY READY!")
    else:
        print("❌ TESTS FAILED!")
    print("=" * 70)

if __name__ == "__main__":
    main()