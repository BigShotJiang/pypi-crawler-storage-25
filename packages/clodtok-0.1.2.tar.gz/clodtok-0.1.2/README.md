# clodtok

Capture the `x-api-key` header that [Claude Code](https://claude.com/claude-code) sends to Anthropic, by funneling its traffic through a temporary [mitmproxy](https://mitmproxy.org/) instance.

## Requirements

External CLIs that must already be on `PATH`:

- `uvx` (from [uv](https://docs.astral.sh/uv/))
- `claude` (Claude Code CLI), configured with `x-api-key` auth

## Usage

```
uvx clodtok
```

Flags:

- `--prompt TEXT` — prompt sent to `claude -p` to trigger an API call (default: `"hi"`)
- `--host HOST` — proxy listen host (default: `127.0.0.1`)
- `--port PORT` — proxy listen port (default: `8888`)
- `--timeout SECONDS` — how long to wait for the key (default: `60`)
- `--debug` — show mitmdump and claude output

The captured API key is printed to stdout. Errors go to stderr.

## How it works

1. Launches `mitmdump` (via `uvx --from mitmproxy`) on the configured port with a small Python addon.
2. Launches `claude -p <prompt>` with `HTTPS_PROXY`, `HTTP_PROXY`, and `NODE_TLS_REJECT_UNAUTHORIZED=0` set so its TLS traffic is intercepted.
3. The addon scans each request for an `x-api-key` header and writes it to a sentinel file the parent process is watching.
4. As soon as the key appears, both subprocesses are torn down and the key is printed.

## Caveats

- Only works when Claude Code authenticates with `x-api-key`. OAuth, Bedrock, and Vertex flows use different headers and will not produce a key here.
- The configured port (default `8888`) must be free.
