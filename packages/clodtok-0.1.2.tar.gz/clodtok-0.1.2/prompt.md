$env:HTTPS_PROXY="http://127.0.0.1:8888"; $env:NODE_TLS_REJECT_UNAUTHORIZED="0";  claude  and uvx --from mitmproxy
   mitmdump --listen-host 127.0.0.1 --listen-port 8888 --ssl-insecure --flow-detail 2
  can you write a script that runs mitm proxy and also run claude code and then get the x-api-key out of the claude code
   headers and return it to stdout?  Use python to do this please
