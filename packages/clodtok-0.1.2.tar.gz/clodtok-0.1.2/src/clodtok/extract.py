"""
Spin up mitmdump, run `claude -p` through it, capture the x-api-key header
that Claude Code sends to Anthropic, and print the key to stdout.
"""
from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ADDON_SOURCE = r'''
import os
from mitmproxy import http

SENTINEL = os.environ.get("API_KEY_SENTINEL")
OBSERVED = os.environ.get("API_OBSERVED_LOG")

def request(flow: http.HTTPFlow) -> None:
    if OBSERVED:
        try:
            with open(OBSERVED, "a", encoding="utf-8") as f:
                f.write("-- " + flow.request.method + " " + flow.request.pretty_url + "\n")
                for name, value in flow.request.headers.items():
                    f.write("   " + name + ": " + value + "\n")
                f.write("\n")
        except Exception:
            pass
    if not SENTINEL or os.path.exists(SENTINEL):
        return
    key = flow.request.headers.get("x-api-key")
    if not key:
        return
    tmp = SENTINEL + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(key)
    os.replace(tmp, SENTINEL)
'''


def _wait_for_port(host: str, port: int, timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1):
                return True
        except OSError:
            time.sleep(0.2)
    return False


def _port_in_use(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.5):
            return True
    except OSError:
        return False


def _resolve(cmd: str) -> str:
    found = shutil.which(cmd)
    if not found:
        sys.exit(f"ERROR: '{cmd}' not found on PATH")
    return found


def main() -> int:
    from . import __version__
    parser = argparse.ArgumentParser(prog="clodtok")
    parser.add_argument("--version", action="version", version=f"clodtok {__version__}")
    parser.add_argument("--prompt", default="hi", help="Prompt sent to `claude -p` to force an API request.")
    parser.add_argument("--port", type=int, default=8888)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--timeout", type=float, default=60.0, help="Seconds to wait for a captured key.")
    parser.add_argument("--debug", action="store_true", help="Show mitmdump and claude output for troubleshooting.")
    args = parser.parse_args()

    uvx = _resolve("uvx")
    claude = _resolve("claude")

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        addon_path = tmp / "capture_addon.py"
        sentinel = tmp / "api_key.txt"
        observed = tmp / "observed.log"
        addon_path.write_text(ADDON_SOURCE, encoding="utf-8")

        if _port_in_use(args.host, args.port):
            print(
                f"ERROR: {args.host}:{args.port} is already listening. "
                f"Another mitmdump or service is bound there. "
                f"Pick a different port with --port, or stop the existing process.",
                file=sys.stderr,
            )
            return 1

        mitm_env = os.environ.copy()
        # Strip proxy vars so mitmdump doesn't try to forward upstream through itself.
        for var in ("HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy", "ALL_PROXY", "all_proxy"):
            mitm_env.pop(var, None)
        mitm_env["API_KEY_SENTINEL"] = str(sentinel)
        mitm_env["API_OBSERVED_LOG"] = str(observed)

        mitm_stdio = None if args.debug else subprocess.DEVNULL
        mitm = subprocess.Popen(
            [
                uvx, "--from", "mitmproxy", "mitmdump",
                "--listen-host", args.host,
                "--listen-port", str(args.port),
                "--ssl-insecure",
                "-s", str(addon_path),
                "-q",
            ],
            env=mitm_env,
            stdout=mitm_stdio,
            stderr=mitm_stdio,
        )

        try:
            if not _wait_for_port(args.host, args.port, timeout=20.0):
                if mitm.poll() is not None:
                    return _fail(
                        f"mitmdump exited before opening a socket (code {mitm.returncode}). "
                        f"Re-run with --debug to see its output.",
                        observed,
                    )
                return _fail("mitmdump did not open a listening socket in time", observed, mitm)
            if mitm.poll() is not None:
                return _fail(
                    f"mitmdump exited shortly after starting (code {mitm.returncode}). "
                    f"Re-run with --debug to see its output.",
                    observed,
                )

            claude_env = os.environ.copy()
            claude_env["HTTPS_PROXY"] = f"http://{args.host}:{args.port}"
            claude_env["HTTP_PROXY"] = f"http://{args.host}:{args.port}"
            claude_env["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"

            claude_stdio = None if args.debug else subprocess.DEVNULL
            claude_proc = subprocess.Popen(
                [claude, "-p", args.prompt],
                env=claude_env,
                stdout=claude_stdio,
                stderr=claude_stdio,
                stdin=subprocess.DEVNULL,
            )

            try:
                deadline = time.time() + args.timeout
                while time.time() < deadline:
                    if sentinel.exists():
                        key = sentinel.read_text(encoding="utf-8").strip()
                        if key:
                            print(key)
                            if args.debug:
                                _dump_observed(observed)
                            return 0
                    if claude_proc.poll() is not None and not sentinel.exists():
                        time.sleep(0.5)
                        if sentinel.exists():
                            print(sentinel.read_text(encoding="utf-8").strip())
                            if args.debug:
                                _dump_observed(observed)
                            return 0
                        return _fail(
                            f"claude exited (code {claude_proc.returncode}) without an x-api-key being seen",
                            observed,
                            mitm,
                        )
                    time.sleep(0.2)
                return _fail("Timed out waiting for x-api-key", observed, mitm, claude_proc)
            finally:
                _terminate(claude_proc)
        finally:
            _terminate(mitm)


def _terminate(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    try:
        proc.terminate()
        proc.wait(timeout=5)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _dump_observed(observed: Path) -> None:
    if not observed.exists():
        print("(no requests were observed by the proxy)", file=sys.stderr)
        return
    text = observed.read_text(encoding="utf-8", errors="replace")
    if not text.strip():
        print("(no requests were observed by the proxy)", file=sys.stderr)
        return
    print("--- observed requests ---", file=sys.stderr)
    print(text, file=sys.stderr)
    print("--- end observed requests ---", file=sys.stderr)


def _fail(msg: str, observed: Path, *procs: subprocess.Popen) -> int:
    for p in procs:
        _terminate(p)
    _dump_observed(observed)
    print(f"ERROR: {msg}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
