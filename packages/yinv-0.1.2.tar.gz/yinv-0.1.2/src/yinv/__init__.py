"""yinv — YAML-driven monthly invoice generator."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("yinv")
except PackageNotFoundError:  # package is not installed (e.g. running from source)
    __version__ = "0.0.0+unknown"

__all__ = ["__version__"]
