import pandas as pd
import numpy as np
from scipy.signal import find_peaks
import matplotlib.pyplot as plt


class CV:
    def __init__(self, volts, amps):
        # volts: array of potential values (in Volts)
        # amps: array of current values (in Amperes)
        if volts.ndim != 1 or amps.ndim != 1 or volts.shape != amps.shape:
            raise ValueError("volts and amps must be 1d numpy arrays of same size")

        self.volts = volts
        self.amps = amps

    def getPotentialAt(self, current: float, maxCurrentDist: float = 0.01) -> float:
        """
        Returns the potential (voltage) value that corresponds most closely
        to a given current value.
        """
        ampsDiffs = np.abs(self.amps - current)        # Difference between each current and the target
        closestAmpsIndex = np.argmin(ampsDiffs)        # Find the index of the closest current value

        if np.abs(self.amps[closestAmpsIndex] - current) >= maxCurrentDist + 1e-5:  # check if current value is close enough
            raise ValueError("No current value is close enough")

        return self.volts[closestAmpsIndex]

    def getCurrentAt(self, voltage: float, maxVoltageDist: float = 0.01) -> float:
        """
        Returns the current value that corresponds most closely to a given voltage.
        """
        voltDiffs = np.abs(self.volts - voltage)
        closestVoltIndex = np.argmin(voltDiffs)

        if np.abs(self.volts[closestVoltIndex] - voltage) >= maxVoltageDist + 1e-6:  # check if current value is close enough
            raise ValueError("No voltage value is close enough")

        return self.amps[closestVoltIndex]

    def iRCompensate(self, resistance):
        """
        Applies iR compensation to correct for potential drop due to internal resistance.
        New voltage = measured voltage - (resistance * current)
        """
        if resistance < 0:
            raise ValueError("iR compensation resistance cannot be negative")

        compensatedVolts = self.volts - resistance * self.amps
        return CV(compensatedVolts, self.amps)

    def shiftPotential(self, offsetPotential: float):
        """
        Shifts the entire potential (voltage) curve by a given overpotential value.
        Returns a new CV object with adjusted voltages.
        """
        corrected_potential = np.array(self.volts) + offsetPotential
        return CV(corrected_potential, self.amps)

    def afterLeftVertex(self):
        """
        Returns a subset of the datapoints starting from the left vertex
        """
        vertexIndex = np.argmin(self.volts)

        if vertexIndex == len(self.volts)-1:
            raise ValueError("Left vertex is at end of CV scan")

        if np.count_nonzero(self.volts == self.volts[vertexIndex]) > 1:
            raise ValueError("Left vertex is ambiguous")

        return CV(self.volts[vertexIndex:], self.amps[vertexIndex:])

    def beforeLeftVertex(self):
        """
        Returns a subset of the datapoints up to the left vertex
        """
        vertexIndex = np.argmin(self.volts)

        if vertexIndex == 0:
            raise ValueError("Left vertex is at beginning of CV scan")

        if np.count_nonzero(self.volts == self.volts[vertexIndex]) > 1:
            raise ValueError("Left vertex is ambiguous")

        return CV(self.volts[:(vertexIndex+1)], self.amps[:(vertexIndex+1)])

    def afterRightVertex(self):
        """
        Returns a subset of the datapoints up to the right vertex
        """
        vertexIndex = np.argmax(self.volts)

        if vertexIndex == len(self.volts)-1:
            raise ValueError("Right vertex is at end of CV scan")

        if np.count_nonzero(self.volts == self.volts[vertexIndex]) > 1:
            raise ValueError("Right vertex is ambiguous")

        return CV(self.volts[vertexIndex:], self.amps[vertexIndex:])

    def beforeRightVertex(self):
        """
        Returns a subset of the datapoints up to the right vertex
        """
        vertexIndex = np.argmax(self.volts)

        if vertexIndex == 0:
            raise ValueError("Right vertex is at beginning of CV scan")

        if np.count_nonzero(self.volts == self.volts[vertexIndex]) > 1:
            raise ValueError("Right vertex is ambiguous")

        return CV(self.volts[:(vertexIndex+1)], self.amps[:(vertexIndex+1)])

    def plot(
        self,
        ax=None,
        *,
        cycles=None,           # e.g. [1,2,3] (1-based). None => all (only relevant for list input)
        labels=None,           # optional list of labels for selected cycles
        area_cm2=None,         # if set: plot A/cm^2
        redline=None,         
        redline_label=None,
        xlabel="Voltage [V]",
        ylabel=None,
        grid=True,
        show=True,
        **line_kwargs,
    ):

        # normalize input: allow self to be CV, or list/tuple of CVs (via unbound call)
        if isinstance(self, (list, tuple)):
            cvs = list(self)
        else:
            cvs = [self]

        if len(cvs) == 0:
            raise ValueError("No CVs provided")

        created_fig = False
        if ax is None:
            _, ax = plt.subplots()
            created_fig = True

        # choose selection
        if cycles is None:
            sel_indices = list(range(len(cvs)))
        else:
            sel_indices = []
            for c in cycles:
                if c < 1 or c > len(cvs):
                    raise ValueError(f"Cycle {c} out of range (1..{len(cvs)})")
                sel_indices.append(c - 1)

        # labels
        if labels is None:
            labels_use = [f"Cycle {i+1}" for i in sel_indices]
        else:
            if len(labels) != len(sel_indices):
                raise ValueError("labels length must match number of selected cycles")
            labels_use = list(labels)

        # y scaling / ylabel
        if area_cm2 is not None:
            if area_cm2 <= 0:
                raise ValueError("area_cm2 must be > 0")
            y_factor = 1.0 / float(area_cm2)
            if ylabel is None:
                ylabel = "Current density [A/cm²]"
        else:
            y_factor = 1.0
            if ylabel is None:
                ylabel = "Current [A]"

        # plot cycles
        for lab, idx in zip(labels_use, sel_indices):
            cv = cvs[idx]
            ax.plot(cv.volts, cv.amps * y_factor, label=lab, **line_kwargs)

        # red threshold line
        if redline is not None:
            rl = float(redline)
            if redline_label is None:
                redline_label = f"Threshold {rl:g}"
            ax.axhline(y=rl, color="red", linestyle="--", label=redline_label)

        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)

        if grid:
            ax.grid(True)

        # legend: show if more than 1 curve OR a label was effectively set OR redline exists
        if len(sel_indices) > 1 or labels is not None or redline is not None:
            ax.legend()

        if show and created_fig:
            plt.show()

        return ax



def loadPalmSensCVs(filePath) -> list[CV]:
    """
    Loads cyclic voltammetry data from a PalmSens CSV file.
    Converts current values from µA to A.
    Returns a list of CV objects (for each sweep).
    """
    data = pd.read_csv(filePath, sep=",", skiprows=5)
    matrix = data.to_numpy()

    numberOfCVs = round(len(data.columns) / 2)
    cvs: list[CV] = []

    for i in range(numberOfCVs):
        volts = matrix[0:-1, 2*i].astype(float)
        amps = matrix[0:-1, 2*i+1].astype(float) * 1e-6  # µA → A
        cvs.append(CV(volts, amps))

    return cvs


def loadBioLogicCVs(filePath) -> list[CV]:
    """
    Loads CV data from a BioLogic CSV file.
    Handles multiple cycles and converts mA → A.
    """
    df = pd.read_csv(filePath, sep="\t", decimal=",")
    columnOrder = ["Ewe/V", "<I>/A", "cycle number"]

    missing_cols = [col for col in columnOrder if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Columns not found in CSV: {missing_cols}")

    data = df[columnOrder].to_numpy()
    cycleCount = int(data[-1, -1])
    cvs: list[CV] = []

    for i in range(1, cycleCount + 1):
        cvData = data[data[:, 2] == i]
        volts = cvData[:, 0].astype(float)
        amps = cvData[:, 1].astype(float)
        cvs.append(CV(volts, amps))

    return cvs


def loadSquidstatCV(filePath) -> CV:
    """
    Loads a single CV from a Squidstat CSV file (legacy format).
    """
    df = pd.read_csv(filePath, sep=",", decimal=".")
    columnOrder = ["Working Electrode (V)", "Current (A)"]

    missing_cols = [col for col in columnOrder if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Columns not found in CSV: {missing_cols}")

    data = df[columnOrder].to_numpy()
    return CV(data[:, 0].astype(float), data[:, 1].astype(float))


def loadSquidstatCVs(filePath) -> list[CV]:
    """
    Loads multiple CV cycles from a Squidstat CSV file.
    Groups data by step number and repeat number.
    """
    df = pd.read_csv(filePath, sep=",", decimal=".")
    columnOrder = ["Working Electrode (V)", "Current (A)", "Step number", "Repeats"]

    missing_cols = [col for col in columnOrder if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Columns not found in CSV: {missing_cols}")

    data = df[columnOrder].to_numpy()
    stepCount = int(data[-1, 2])
    cvs: list[CV] = []

    for stepRef in range(1, stepCount + 1):
        stepData = data[data[:, 2] == stepRef]
        cycleCount = int(stepData[-1, -1])

        for cycleRef in range(1, cycleCount + 1):
            cycleData = stepData[stepData[:, 3] == cycleRef]
            cvs.append(CV(cycleData[:, 0].astype(float), cycleData[:, 1].astype(float)))

    return cvs
