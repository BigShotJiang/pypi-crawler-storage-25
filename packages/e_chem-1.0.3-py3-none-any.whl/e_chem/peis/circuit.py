"""Equivalent-circuit model builders and parser utilities for PEIS fitting.

This module exposes small impedance element constructors (`resistor`, `capacitor`,
`cpe`, `warburg_sigma`), combinators (`series`, `parallel`), and a string parser
(`parse_circuit`) to build model callables used by the PEIS fitting pipeline.
"""

from __future__ import annotations

from typing import Callable

import numpy as np

ImpedanceFn = Callable[[np.ndarray, dict[str, float]], np.ndarray]


def _value(v: str | float, params: dict[str, float]) -> float:
    """Resolve a numeric literal or parameter name to a float value.

    Args:
        v: Literal value or parameter key.
        params: Parameter mapping used when ``v`` is a string.

    Returns:
        Resolved numeric value.

    Raises:
        KeyError: If ``v`` is a string not present in ``params``.
    """
    if isinstance(v, str):
        if v not in params:
            raise KeyError(f"Parameter '{v}' missing in params")
        return float(params[v])
    return float(v)


def resistor(r: str | float) -> ImpedanceFn:
    """Create a resistor impedance function.

    Args:
        r: Resistance value or parameter key.

    Returns:
        Callable impedance model ``Z(f, params)`` for a resistor.
    """

    def _z(freq_hz: np.ndarray, params: dict[str, float]) -> np.ndarray:
        return np.full_like(np.asarray(freq_hz, dtype=float), _value(r, params), dtype=complex)

    return _z


def capacitor(c: str | float) -> ImpedanceFn:
    """Create an ideal capacitor impedance function.

    Args:
        c: Capacitance value or parameter key.

    Returns:
        Callable impedance model ``Z(f, params) = 1 / (j*w*C)``.
    """

    def _z(freq_hz: np.ndarray, params: dict[str, float]) -> np.ndarray:
        f = np.asarray(freq_hz, dtype=float)
        w = 2.0 * np.pi * f
        c_val = _value(c, params)
        z = 1.0 / (1j * w * c_val)
        return z.astype(complex)

    return _z


def cpe(q: str | float, alpha: str | float) -> ImpedanceFn:
    """Create a constant-phase element (CPE) impedance function.

    Args:
        q: CPE prefactor value or parameter key.
        alpha: CPE exponent value or parameter key.

    Returns:
        Callable impedance model ``Z(f, params) = 1 / (Q * (j*w)^alpha)``.
    """

    def _z(freq_hz: np.ndarray, params: dict[str, float]) -> np.ndarray:
        f = np.asarray(freq_hz, dtype=float)
        w = 2.0 * np.pi * f
        q_val = _value(q, params)
        a_val = _value(alpha, params)
        z = 1.0 / (q_val * (1j * w) ** a_val)
        return z.astype(complex)

    return _z


def warburg_sigma(sigma: str | float) -> ImpedanceFn:
    """Create a semi-infinite Warburg impedance function.

    Args:
        sigma: Warburg coefficient value or parameter key.

    Returns:
        Callable impedance model ``Z(f, params) = sigma / sqrt(j*w)``.
    """

    def _z(freq_hz: np.ndarray, params: dict[str, float]) -> np.ndarray:
        f = np.asarray(freq_hz, dtype=float)
        w = 2.0 * np.pi * f
        s = _value(sigma, params)
        z = s / np.sqrt(1j * w)
        return z.astype(complex)

    return _z


def series(*elements: ImpedanceFn) -> ImpedanceFn:
    """Combine impedance elements in series.

    Args:
        *elements: Element impedance functions to add.

    Returns:
        Callable impedance model representing the series sum.
    """

    def _z(freq_hz: np.ndarray, params: dict[str, float]) -> np.ndarray:
        total = np.zeros_like(np.asarray(freq_hz, dtype=float), dtype=complex)
        for e in elements:
            total = total + e(freq_hz, params)
        return total

    return _z


def parallel(*elements: ImpedanceFn) -> ImpedanceFn:
    """Combine impedance elements in parallel.

    Args:
        *elements: Element impedance functions to combine.

    Returns:
        Callable impedance model representing the parallel combination.
    """

    def _z(freq_hz: np.ndarray, params: dict[str, float]) -> np.ndarray:
        y = np.zeros_like(np.asarray(freq_hz, dtype=float), dtype=complex)
        for e in elements:
            z = e(freq_hz, params)
            y = y + 1.0 / z
        return 1.0 / y

    return _z


def randles_no_warburg(
    rs: str | float = "Rs",
    rct: str | float = "Rct",
    cdl: str | float = "Cdl",
) -> ImpedanceFn:
    """Build a Randles circuit without Warburg element.

    Args:
        rs: Solution resistance parameter/value.
        rct: Charge-transfer resistance parameter/value.
        cdl: Double-layer capacitance parameter/value.

    Returns:
        Callable impedance model for ``Rs + (Rct || Cdl)``.
    """
    return series(
        resistor(rs),
        parallel(
            resistor(rct),
            capacitor(cdl),
        ),
    )


def _element_from_name(name: str) -> ImpedanceFn:
    """Create an element model from a circuit token.

    Args:
        name: Element token, for example ``R_1``, ``C_1``, ``CPE_1``, or ``W_1``.

    Returns:
        Callable impedance model for the token.

    Raises:
        ValueError: If the token is empty or has an unsupported prefix.
    """
    token = name.strip()
    if not token:
        raise ValueError("Empty element token")

    upper = token.upper()
    if _is_cpe_like_token(upper):
        return cpe(token, _alpha_name_for_cpe_token(token))

    head = token.split("_", 1)[0].upper()
    if head.startswith("R"):
        return resistor(token)
    if head.startswith("C"):
        return capacitor(token)
    if head.startswith("W"):
        return warburg_sigma(token)
    raise ValueError(
        f"Unsupported element token '{name}'. Use prefixes R_, C_, CPE_, DPE_, or W_."
    )


def circuit_params(expr: str) -> list[str]:
    """Return ordered unique parameter names referenced in a circuit expression.

    Args:
        expr: Circuit expression string.

    Returns:
        Parameter names in first-seen order.
    """
    tokens = _tokenize(expr)
    params: list[str] = []
    seen: set[str] = set()
    for t in tokens:
        if t in {"-", "||", "(", ")"}:
            continue
        for p in _params_for_token(t):
            if p not in seen:
                seen.add(p)
                params.append(p)
    return params


def parse_circuit(expr: str) -> ImpedanceFn:
    """Parse a circuit expression into a callable impedance model.

    Supported grammar:
      - Series operator: ``-``
      - Parallel operator: ``||``
      - Grouping: parentheses
      - Element tokens: e.g. ``R_0``, ``C_1``, ``CPE_1``, ``W_1``

    Args:
        expr: Circuit expression string.

    Returns:
        Callable impedance model ``Z(f, params)``.

    Raises:
        ValueError: If parsing fails or there are unconsumed tokens.
    """

    tokens = _tokenize(expr)
    parser = _Parser(tokens)
    model = parser.parse_expression()
    if parser.pos != len(tokens):
        raise ValueError(f"Unexpected token '{tokens[parser.pos]}' in '{expr}'")
    return model


def _tokenize(expr: str) -> list[str]:
    """Tokenize a circuit expression string.

    Args:
        expr: Circuit expression string.

    Returns:
        Token list containing element names and operators.

    Raises:
        ValueError: If invalid characters are encountered or the expression is empty.
    """
    tokens: list[str] = []
    i = 0
    n = len(expr)
    while i < n:
        ch = expr[i]
        if ch.isspace():
            i += 1
            continue
        if ch == "(" or ch == ")" or ch == "-":
            tokens.append(ch)
            i += 1
            continue
        if i + 1 < n and expr[i: i + 2] == "||":
            tokens.append("||")
            i += 2
            continue
        if ch.isalpha():
            j = i + 1
            while j < n and (expr[j].isalnum() or expr[j] == "_"):
                j += 1
            tokens.append(expr[i:j])
            i = j
            continue
        raise ValueError(f"Invalid character '{ch}' in circuit expression '{expr}'")
    if not tokens:
        raise ValueError("Empty circuit expression")
    return tokens


class _Parser:
    """Recursive-descent parser for PEIS circuit expressions."""

    def __init__(self, tokens: list[str]) -> None:
        self.tokens = tokens
        self.pos = 0

    def _peek(self) -> str | None:
        """Return the current token without consuming it."""
        if self.pos >= len(self.tokens):
            return None
        return self.tokens[self.pos]

    def _consume(self, expected: str | None = None) -> str:
        """Consume and return the current token.

        Args:
            expected: Optional exact token that must be present.

        Returns:
            The consumed token.

        Raises:
            ValueError: If the stream ended or ``expected`` does not match.
        """
        tok = self._peek()
        if tok is None:
            raise ValueError("Unexpected end of circuit expression")
        if expected is not None and tok != expected:
            raise ValueError(f"Expected '{expected}' but got '{tok}'")
        self.pos += 1
        return tok

    def parse_expression(self) -> ImpedanceFn:
        """Parse a series expression.

        Returns:
            Impedance model representing one or more terms connected in series.
        """
        # expression := term ( "-" term )*
        left = self.parse_term()
        while self._peek() == "-":
            self._consume("-")
            right = self.parse_term()
            left = series(left, right)
        return left

    def parse_term(self) -> ImpedanceFn:
        """Parse a parallel term.

        Returns:
            Impedance model representing one or more factors connected in parallel.
        """
        # term := factor ( "||" factor )*
        left = self.parse_factor()
        while self._peek() == "||":
            self._consume("||")
            right = self.parse_factor()
            left = parallel(left, right)
        return left

    def parse_factor(self) -> ImpedanceFn:
        """Parse a single element or parenthesized expression.

        Returns:
            Impedance model for the parsed factor.

        Raises:
            ValueError: If tokens appear in an invalid order.
        """
        tok = self._peek()
        if tok is None:
            raise ValueError("Unexpected end of circuit expression")
        if tok == "(":
            self._consume("(")
            inside = self.parse_expression()
            self._consume(")")
            return inside
        if tok in {"-", "||", ")"}:
            raise ValueError(f"Unexpected token '{tok}'")
        name = self._consume()
        return _element_from_name(name)


def _is_cpe_like_token(upper_token: str) -> bool:
    """Return whether a token prefix maps to a CPE-type element.

    Args:
        upper_token: Uppercased token name.

    Returns:
        ``True`` for ``CPE*`` or ``DPE*`` tokens, otherwise ``False``.
    """
    return upper_token.startswith("CPE") or upper_token.startswith("DPE")


def _alpha_name_for_cpe_token(token: str) -> str:
    """Compute the alpha-parameter name for a CPE/DPE token.

    Args:
        token: Original token (case-preserving).

    Returns:
        Matching alpha parameter name, for example ``alpha_1`` for ``CPE_1``.
    """
    upper = token.upper()
    if upper.startswith("CPE_") or upper.startswith("DPE_"):
        return "alpha_" + token.split("_", 1)[1]
    if upper in {"CPE", "DPE"}:
        return "alpha"
    # e.g. CPE1, DPE2
    suffix = token[3:]
    return f"alpha{suffix}" if suffix else "alpha"


def _params_for_token(token: str) -> list[str]:
    """Return all parameter names contributed by one element token.

    Args:
        token: Element token from the circuit expression.

    Returns:
        List containing one name (most elements) or two names (CPE/DPE + alpha).
    """
    upper = token.upper()
    if _is_cpe_like_token(upper):
        return [token, _alpha_name_for_cpe_token(token)]
    return [token]
