"""PEIS package.

This package provides tools for loading PEIS data, constructing equivalent
circuits, fitting impedance models, and running DRT analyses.
"""
