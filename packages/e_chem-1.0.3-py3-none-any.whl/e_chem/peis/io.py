"""Input/output helpers for loading PEIS data files into `Run` objects."""

from __future__ import annotations
from typing import List, Optional, Dict, Sequence, Set, Tuple
import csv
import re
import numpy as np
from e_chem.peis.core import Run
from e_chem.peis import circuit

# Add additional aliases here when new vendor export variants appear.
PEIS_COLUMN_ALIASES: Dict[str, List[str]] = {
    "frequency": [
        "freq/Hz",
        "freq[Hz]",
        "frequency",
        "frequency/Hz",
        "frequency(Hz)",
        "frequency [Hz]",
        "f",
        "f/Hz",
        "f(Hz)",
        "frq",
        "hz",
    ],
    "re_z": [
        "Re(Z)",
        "Re(Z)/Ohm",
        "Re(Z)[Ohm]",
        "Re[Z]",
        "real(Z)",
        "real impedance",
        "zreal",
        "zreal/ohm",
        "zr",
        "Z'",
        "Z'/Ohm",
    ],
    "minus_im_z": [
        "-Im(Z)",
        "-Im(Z)/Ohm",
        "-Im(Z)[Ohm]",
        "-Imag(Z)",
        "-Imag(Z)/Ohm",
        "-Z''",
        "-Z''/Ohm",
        "minusim(z)",
        "minus imag(z)",
        "negim(z)",
        "negative imag(z)",
        "zimagneg",
    ],
    "im_z": [
        "Im(Z)",
        "Im(Z)/Ohm",
        "Im(Z)[Ohm]",
        "Imag(Z)",
        "Imag(Z)/Ohm",
        "Z''",
        "Z''/Ohm",
        "zimag",
        "zi",
    ],
}


def _normalize_column_name(name: str) -> str:
    """Normalize a raw header name for robust alias matching.

    Args:
        name: Raw column name from the file header.

    Returns:
        Canonicalized lowercase token with normalized symbols and punctuation.
    """
    normalized = str(name).strip().lower()
    normalized = normalized.replace("−", "-")
    normalized = normalized.replace("ω", "ohm").replace("Ω", "ohm").replace("Ω", "ohm")
    normalized = normalized.replace("''", "doubleprime")
    normalized = normalized.replace("′′", "doubleprime")
    normalized = normalized.replace("′", "prime")
    normalized = normalized.replace("'", "prime")
    normalized = re.sub(r"\s+", "", normalized)
    normalized = re.sub(r"[^a-z0-9+\-]", "", normalized)
    return normalized


def _merge_column_aliases(
    column_aliases: Optional[Dict[str, Sequence[str]]],
) -> Dict[str, List[str]]:
    """Merge user-provided aliases with built-in PEIS column aliases.

    Args:
        column_aliases: Optional aliases grouped by canonical key.

    Returns:
        Full alias mapping including defaults and user extensions.

    Raises:
        ValueError: If unknown alias-group keys are provided.
    """
    merged = {key: list(values) for key, values in PEIS_COLUMN_ALIASES.items()}
    if not column_aliases:
        return merged

    unknown_keys = sorted(set(column_aliases) - set(merged))
    if unknown_keys:
        raise ValueError(
            f"Unknown column_aliases groups: {unknown_keys}. "
            f"Expected one of: {sorted(merged)}"
        )

    for key, values in column_aliases.items():
        if isinstance(values, str):
            merged[key].append(values)
            continue
        merged[key].extend(str(value) for value in values)
    return merged


def _detect_delimiter(
    input_file: str, skiprows: int, delimiter_in: Optional[str]
) -> str:
    """Determine which delimiter should be used for file parsing.

    Args:
        input_file: Path to the source PEIS file.
        skiprows: Number of header rows to inspect.
        delimiter_in: Explicit delimiter override from the caller.

    Returns:
        Chosen delimiter character.
    """
    if delimiter_in is not None:
        return delimiter_in

    max_lines = max(skiprows, 1)
    candidate_line = ""
    with open(input_file, "r", encoding="utf-8", errors="ignore") as handle:
        for idx, line in enumerate(handle):
            if idx >= max_lines:
                break
            stripped = line.strip()
            if stripped:
                candidate_line = stripped

    if not candidate_line:
        return "\t"

    delimiters = ("\t", ";", "|", ",")
    counts = {delim: candidate_line.count(delim) for delim in delimiters}
    best_delim = max(counts, key=counts.get)
    return best_delim if counts[best_delim] > 0 else "\t"


def _read_header_columns(input_file: str, skiprows: int, delimiter: str) -> List[str]:
    """Read header fields from the last non-empty skipped line.

    Args:
        input_file: Path to the source PEIS file.
        skiprows: Number of initial rows treated as header.
        delimiter: Delimiter used to split header fields.

    Returns:
        List of header column names, or an empty list if unavailable.
    """
    if skiprows < 1:
        return []

    header_line = ""
    with open(input_file, "r", encoding="utf-8", errors="ignore") as handle:
        for idx, line in enumerate(handle):
            if idx >= skiprows:
                break
            stripped = line.strip()
            if stripped:
                header_line = stripped

    if not header_line:
        return []

    return next(csv.reader([header_line], delimiter=delimiter))


def _build_alias_lookup(column_aliases: Dict[str, List[str]]) -> Dict[str, Set[str]]:
    """Build a normalized alias lookup table.

    Args:
        column_aliases: Alias lists grouped by canonical column key.

    Returns:
        Mapping of canonical key to normalized alias set.
    """
    return {
        key: {_normalize_column_name(alias) for alias in aliases}
        for key, aliases in column_aliases.items()
    }


def _infer_column_group(normalized_name: str) -> Optional[str]:
    """Heuristically infer the canonical PEIS group from one header token.

    Args:
        normalized_name: Normalized header name.

    Returns:
        Canonical group name (`frequency`, `re_z`, `minus_im_z`, `im_z`) or
        ``None`` if no heuristic match is found.
    """
    if not normalized_name:
        return None

    if (
        "freq" in normalized_name
        or normalized_name in {"f", "fhz", "frq", "hz", "frequency"}
    ):
        return "frequency"

    if "doubleprime" in normalized_name:
        if (
            normalized_name.startswith("-")
            or "minus" in normalized_name
            or "neg" in normalized_name
        ):
            return "minus_im_z"
        return "im_z"

    if (
        ("real" in normalized_name and "imag" not in normalized_name)
        or "rez" in normalized_name
        or normalized_name in {"zr", "zprime", "zprimeohm"}
    ):
        return "re_z"

    if "im" in normalized_name or "imag" in normalized_name:
        if (
            normalized_name.startswith("-")
            or "-im" in normalized_name
            or "minus" in normalized_name
            or "neg" in normalized_name
        ):
            return "minus_im_z"
        return "im_z"

    return None


def _select_single_index(
    candidates: Set[int], label: str, header_columns: List[str]
) -> int:
    """Validate candidate set and return exactly one column index.

    Args:
        candidates: Candidate indices for one semantic column.
        label: User-facing label used in error messages.
        header_columns: Original header names.

    Returns:
        The detected column index.

    Raises:
        ValueError: If no candidate or multiple candidates are found.
    """
    if not candidates:
        raise ValueError(
            f"Could not detect a '{label}' column from header: {header_columns}"
        )

    if len(candidates) > 1:
        candidate_names = [header_columns[i] for i in sorted(candidates)]
        raise ValueError(
            f"Detected multiple '{label}' columns: {candidate_names}. "
            "Please add more specific aliases to disambiguate."
        )

    return next(iter(candidates))


def _detect_peis_columns(
    header_columns: List[str], column_aliases: Dict[str, List[str]]
) -> Tuple[int, int, int, str]:
    """Detect frequency, real, and imaginary column indices from headers.

    Args:
        header_columns: Raw header names.
        column_aliases: Alias mapping used for direct and heuristic matching.

    Returns:
        Tuple ``(freq_idx, re_idx, imag_idx, resolved_format)`` where
        ``resolved_format`` is either ``f,re,-im`` or ``f,re,im``.

    Raises:
        ValueError: If required columns are missing, ambiguous, or overlapping.
    """
    if len(header_columns) < 3:
        raise ValueError("At least 3 header columns are required for PEIS detection.")

    alias_lookup = _build_alias_lookup(column_aliases)
    matches: Dict[str, Set[int]] = {key: set() for key in alias_lookup}
    normalized_headers = [_normalize_column_name(name) for name in header_columns]

    for idx, normalized in enumerate(normalized_headers):
        for group, alias_set in alias_lookup.items():
            if normalized in alias_set:
                matches[group].add(idx)

    for idx, normalized in enumerate(normalized_headers):
        already_matched = any(idx in group_matches for group_matches in matches.values())
        if already_matched:
            continue
        inferred_group = _infer_column_group(normalized)
        if inferred_group is not None:
            matches[inferred_group].add(idx)

    freq_idx = _select_single_index(matches["frequency"], "frequency", header_columns)
    re_idx = _select_single_index(matches["re_z"], "Re(Z)", header_columns)

    if matches["minus_im_z"]:
        minus_im_idx = _select_single_index(
            matches["minus_im_z"], "-Im(Z)", header_columns
        )
        if len({freq_idx, re_idx, minus_im_idx}) < 3:
            raise ValueError(
                "Detected overlapping columns for frequency, Re(Z), and -Im(Z)."
            )
        return freq_idx, re_idx, minus_im_idx, "f,re,-im"

    if matches["im_z"]:
        im_idx = _select_single_index(matches["im_z"], "Im(Z)", header_columns)
        if len({freq_idx, re_idx, im_idx}) < 3:
            raise ValueError(
                "Detected overlapping columns for frequency, Re(Z), and Im(Z)."
            )
        return freq_idx, re_idx, im_idx, "f,re,im"

    raise ValueError(
        "Could not detect '-Im(Z)' or 'Im(Z)' column from header. "
        f"Header columns were: {header_columns}"
    )


def _load_numeric_columns(
    input_file: str, delimiter: str, skiprows: int, usecols: Sequence[int]
) -> np.ndarray:
    """Load and parse selected numeric columns from a PEIS file.

    Args:
        input_file: Path to the source PEIS file.
        delimiter: Delimiter used in the file.
        skiprows: Number of rows to skip before data starts.
        usecols: Column indices to load.

    Returns:
        Float array with shape ``(n_rows, len(usecols))``.

    Raises:
        ValueError: If loading or float conversion fails.
    """
    try:
        raw = np.loadtxt(
            input_file,
            delimiter=delimiter,
            skiprows=skiprows,
            dtype=str,
            usecols=tuple(usecols),
        )
    except ValueError as exc:
        raise ValueError(
            f"Failed to load PEIS data from columns {tuple(usecols)}. "
            "Check delimiter/skiprows and that the selected columns are numeric."
        ) from exc

    if raw.ndim == 1:
        raw = raw.reshape(1, -1)

    try:
        return np.char.replace(raw, ",", ".").astype(float)
    except ValueError as exc:
        raise ValueError(
            f"Failed to parse PEIS numeric values from columns {tuple(usecols)}."
        ) from exc


def loadBioLogicPEIS(
    input_file: str,
    skiprows: int = 1,
    delimiter_in: Optional[str] = None,
    biologic_format: str = "f,-im,re",
    return_converted_table: bool = False,
    auto_detect_columns: bool = True,
    column_aliases: Optional[Dict[str, Sequence[str]]] = None,
) -> Run:
    """
    Load a BioLogic PEIS export and convert it to impedance.py-compatible arrays.
    This function reads a BioLogic PEIS text or CSV export, handles European
    decimal commas if present, and converts the data into frequency and
    complex impedance arrays suitable for fitting with impedance.py.

    Args:
        input_file (str):
            Path to the BioLogic PEIS export file (.txt or .csv).
        skiprows (int):
            Number of header rows to skip at the top of the file.
        delimiter_in (str, optional):
            Column delimiter used in the file (e.g. "\t", ";"). If None,
            the delimiter is auto-detected from the header line and falls back
            to tab if detection is ambiguous.
        biologic_format (str): Column format of the input file. Supported values:

                - "f,-im,re": Frequency, -Im(Z), Re(Z)
                - "f,re,im":  Frequency, Re(Z), Im(Z)
                - "f,re,-im": Frequency, Re(Z), -Im(Z)
                - "auto":     Require header-based auto detection
        return_converted_table (bool):
            If True, also return the converted data table with columns
            (Frequency, Re(Z), -Im(Z)).
        auto_detect_columns (bool):
            If True (default), detect column indices from header names using
            ``PEIS_COLUMN_ALIASES`` (+ ``column_aliases``). Falls back to
            ``biologic_format`` on columns 0/1/2 when detection fails.
        column_aliases (dict, optional):
            Extra aliases merged into ``PEIS_COLUMN_ALIASES``.
            Valid keys: "frequency", "re_z", "minus_im_z", "im_z".

    Returns:
        Run:
            Object containing:

             - freqs: frequency array
             - Z: complex impedance array,
             - table: optionally the converted data table.
             - source: path to the input file.
             - biologic_format: format of the input file.
             - sweeps: list of individual PEISData sweeps.
             - num_sweeps: count of detected sweeps.
             - mean_re_drift: mean Re(Z) drift between adjacent sweeps.
             - mean_imag_drift: mean Im(Z) drift between adjacent sweeps.

    Raises:
        ValueError:
            If no valid column mapping can be found or an unsupported
            ``biologic_format`` is specified.
    """
    fmt = biologic_format.lower().strip()
    merged_aliases = _merge_column_aliases(column_aliases)
    delim = _detect_delimiter(input_file, skiprows, delimiter_in)

    data = None
    resolved_format = fmt

    if auto_detect_columns and skiprows >= 1:
        header_columns = _read_header_columns(input_file, skiprows, delim)
        if header_columns:
            try:
                f_idx, re_idx, imag_idx, detected_format = _detect_peis_columns(
                    header_columns, merged_aliases
                )
                data = _load_numeric_columns(
                    input_file=input_file,
                    delimiter=delim,
                    skiprows=skiprows,
                    usecols=(f_idx, re_idx, imag_idx),
                )
                resolved_format = detected_format
            except ValueError as exc:
                if fmt == "auto":
                    raise ValueError(f"Auto column detection failed: {exc}") from exc

    if data is None:
        data = _load_numeric_columns(
            input_file=input_file,
            delimiter=delim,
            skiprows=skiprows,
            usecols=(0, 1, 2),
        )

    if data.shape[1] < 3:
        raise ValueError(f"Expected at least 3 columns, got {data.shape[1]}")

    if resolved_format == "f,-im,re":
        f = np.array(data[:, 0])
        minus_im = data[:, 1]
        re = data[:, 2]
        im = -minus_im
        Z = re + 1j * im
        table = np.column_stack([f, re, minus_im])
    elif resolved_format == "f,re,im":
        f = np.array(data[:, 0])
        re = data[:, 1]
        im = data[:, 2]
        Z = re + 1j * im
        table = np.column_stack([f, re, -im])
    elif resolved_format == "f,re,-im":
        f = np.array(data[:, 0])
        re = data[:, 1]
        minus_im = data[:, 2]
        im = -minus_im
        Z = re + 1j * im
        table = np.column_stack([f, re, minus_im])
    elif resolved_format == "auto":
        raise ValueError(
            "biologic_format='auto' requires successful header-based detection."
        )
    else:
        raise ValueError(
            f"Unknown biologic_format='{biologic_format}'. Use one of: "
            "'f,-im,re', 'f,re,im', 'f,re,-im', 'auto'"
        )

    data_obj = Run(
        freqs=f,
        Z=Z,
        table=table if return_converted_table else None,
        source=input_file,
        biologic_format=resolved_format,
    )

    return data_obj

if __name__ == "__main__":
    model_cpe = circuit.parse_circuit('R_0-(R_1||CPE_1)-(R_2||C_2)-(R_3 || C_3)')

    initial_params = {
        'R_0': 1.0,
        'R_1': 100.0,
        'CPE_1': 1e-4,
        'alpha_1': 0.9,
        'R_2': 100.0,
        'C_2': 0.001,
        'R_3': 100.0,
        'C_3': 0.001,
        'R_4': 100.0,
        'C_4': 0.001
    }

    data = loadBioLogicPEIS(
        input_file="/Users/philippsaboi/dev/BSc_work/data/converted/PS6/PEIS/48h_PEIS_after_data.csv"
    )

    data.first_sweep.crop_frequency_range(min_freq=1.0, max_freq=7000)
    data.first_sweep.plot_nyquist()
    data.first_sweep.plot_bode()
    data.first_sweep.fit(model_cpe, initial_params=initial_params)
    data.first_sweep.plot_fit_nyquist()
    data.first_sweep.plot_fit_bode()
    data.first_sweep.run_simple_drt()
    peaks = data.first_sweep.summarize_peaks()
    print(f"Number of peaks: {peaks.num_peaks}")
    data.first_sweep.plot_drt(show_peaks=True)

