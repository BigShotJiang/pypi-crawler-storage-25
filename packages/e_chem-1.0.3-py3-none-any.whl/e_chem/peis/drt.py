"""DRT helpers for the PEIS module.

The active DRT workflow currently lives in `e_chem.peis.core`.
This module is reserved for future dedicated DRT abstractions.
"""
