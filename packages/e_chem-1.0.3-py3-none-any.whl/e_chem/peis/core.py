"""Core PEIS data containers, fitting workflows, and DRT integration utilities."""

from __future__ import annotations
from typing import Callable
from scipy.optimize import least_squares
from typing import List, Optional
import numpy as np
from dataclasses import dataclass, field
plt = None
from pyDRTtools.runs import simple_run, Bayesian_run, BHT_run, EIS_object
import tempfile
import os
from scipy.signal import find_peaks

ModelFn = Callable[[np.ndarray, dict[str, float]], np.ndarray]


@dataclass
class DRTConfig:
    """Configuration for pyDRTtools-based DRT runs.

    Attributes:
        path: Optional source file path used in standalone workflows.
        reg_param: Regularization parameter used by simple DRT.
        prominence: Default peak-detection prominence.
        fmin: Optional lower frequency bound for preprocessing.
        fmax: Optional upper frequency bound for preprocessing.
        plot: Whether DRT run helpers should render plots.
        mark_peaks: Whether DRT plots should mark detected peaks.
        color_by_freq: Whether plotting should color points by frequency.
        rbf_type: Radial-basis type for pyDRTtools.
        data_used: Data mode passed to pyDRTtools.
        induct_used: Whether to include inductance handling in pyDRTtools.
        der_used: Derivative order mode used by pyDRTtools.
        cv_type: Cross-validation mode used by pyDRTtools.
        shape_control: Shape-control mode for pyDRTtools.
        coeff: Shape-control coefficient for pyDRTtools.
    """
    path: str = "/Users/philippsaboi/dev/BSc_work/eChem/data/peis/try.txt"
    reg_param: float = 1e-3
    prominence: float | None = 0.01
    fmin: float | None = None
    fmax: float | None = None
    plot: bool = True
    mark_peaks: bool = True
    color_by_freq: bool = True
    rbf_type: str = "Gaussian"
    data_used: str = "Combined Re-Im Data"
    induct_used: int = 1
    der_used: str = "1st order"
    cv_type: str = "GCV"
    shape_control: str = "FWHM Coefficient"
    coeff: float = 0.5

@dataclass
class PeakSummary:
    """Summary of DRT peak locations and amplitudes.

    Attributes:
        num_peaks: Number of detected peaks.
        peak_indices: Peak indices in the original gamma array.
        peak_tau: Relaxation-time values at peak positions.
        peak_gamma: Gamma values at peak positions.
    """
    num_peaks: int
    peak_indices: np.ndarray
    peak_tau: np.ndarray
    peak_gamma: np.ndarray


@dataclass
class PEISData:
    """Container for one PEIS data series.

    Attributes:
        freqs: Frequency points in Hz.
        Z: Complex impedance values aligned to ``freqs``.
        table: Optional converted table representation used for export/debugging.
    """
    freqs: np.ndarray
    Z: np.ndarray
    table: Optional[np.ndarray] = None

    def __post_init__(self):
        """Normalize array types and validate shape consistency.

        Raises:
            ValueError: If data arrays have inconsistent lengths.
        """
        self.freqs = np.asarray(self.freqs, dtype=float)
        self.Z = np.asarray(self.Z, dtype=complex)

        if self.freqs.shape != self.Z.shape:
            raise ValueError("freqs and Z must have same length")

        if self.table is not None and len(self.table) != len(self.freqs):
            raise ValueError("table row count must match data length")


@dataclass
class EISFitResult:
    """Result bundle returned by `Sweep.fit`.

    Attributes:
        param_names: Parameter order used by the optimizer.
        params: Best-fit parameter values.
        success: Optimizer success flag.
        cost: Final least-squares cost.
        message: Optimizer termination message.
        nfev: Number of function evaluations.
        Z_fit: Best-fit complex impedance response.
        residual_re: Real-part residuals.
        residual_im: Imaginary-part residuals.
        raw: Raw `scipy.optimize.OptimizeResult`.
    """
    param_names: list[str]
    params: dict[str, float]
    success: bool
    cost: float
    message: str
    nfev: int
    Z_fit: np.ndarray
    residual_re: np.ndarray
    residual_im: np.ndarray
    raw: object

    def print_summary(self, *, digits: int = 4) -> None:
        """Print a compact terminal summary of the EIS circuit fit.

        Args:
            digits: Number of significant digits used for floating-point values.
        """
        rows = [
            ("success", str(self.success)),
            ("cost", f"{self.cost:.{digits}g}"),
            ("nfev", str(self.nfev)),
            ("message", self.message),
        ]

        self._print_table("EIS Fit Summary", rows)

        param_rows = [
            (name, f"{self.params[name]:.{digits}g}")
            for name in self.param_names
            if name in self.params
        ]

        if param_rows:
            self._print_table("Fit Parameters", param_rows)

    @staticmethod
    def _print_table(title: str, rows: list[tuple[str, str]]) -> None:
        """Print key-value rows as a simple ASCII table.

        Args:
            title: Table title.
            rows: Ordered ``(name, value)`` pairs.
        """
        if not rows:
            return

        key_width = max(len(str(key)) for key, _ in rows)
        value_width = max(len(str(value)) for _, value in rows)
        table_width = key_width + value_width + 7

        print()
        print(f"+{'-' * table_width}+")
        print(f"| {title.center(table_width - 2)} |")
        print(f"+{'-' * table_width}+")
        print(f"| {'Name'.ljust(key_width)} | {'Value'.ljust(value_width)} |")
        print(f"+{'-' * (key_width + 2)}+{'-' * (value_width + 2)}+")

        for key, value in rows:
            print(f"| {str(key).ljust(key_width)} | {str(value).ljust(value_width)} |")

        print(f"+{'-' * (key_width + 2)}+{'-' * (value_width + 2)}+")


@dataclass
class Sweep(PEISData):
    """Single sweep container with processing, fitting, and DRT helpers.

    Attributes:
        sweep_idx: Optional sweep index inside a `Run`.
        r0: Cached ohmic resistance estimate.
        fit_result: Cached equivalent-circuit fit result.
        drt_entry: Cached pyDRTtools `EIS_object`.
    """
    sweep_idx: Optional[int] = None
    r0: Optional[float] = None
    fit_result: Optional[EISFitResult] = None
    drt_entry: Optional[EIS_object] = None

    def crop_frequency_range(
        self,
        min_freq: Optional[float] = None,
        max_freq: Optional[float] = None,
        inplace: bool = False,
    ) -> "Sweep":
        """
        Crop PEIS data to a frequency window.

        Args:
            min_freq (float, optional):
                Lower frequency bound (inclusive). If None, no lower bound. [Hz]
            max_freq (float, optional):
                Upper frequency bound (inclusive). If None, no upper bound. [Hz]
            inplace (bool):
                If True, modify this object directly and return it.
                If False (default), return a new cropped ``Sweep``.

        Returns:
            Sweep:
                Cropped PEIS data (new or in-place object).

        Raises:
            ValueError:
                If bounds are invalid, if no points remain after cropping,
                or if the optional table length is inconsistent.
        """
        if min_freq is None and max_freq is None:
            raise ValueError("At least one of min_freq or max_freq must be provided.")

        if min_freq is not None and max_freq is not None and min_freq > max_freq:
            raise ValueError(
                f"min_freq ({min_freq}) must be <= max_freq ({max_freq})."
            )

        mask = np.ones_like(self.freqs, dtype=bool)
        if min_freq is not None:
            mask &= self.freqs >= min_freq
        if max_freq is not None:
            mask &= self.freqs <= max_freq

        if not np.any(mask):
            raise ValueError(
                "Frequency crop removed all points. Check min_freq/max_freq."
            )

        freqs_cropped = self.freqs[mask].copy()
        Z_cropped = self.Z[mask].copy()

        table_cropped = None
        if self.table is not None:
            if self.table.shape[0] != self.freqs.shape[0]:
                raise ValueError(
                    "Cannot crop table: table row count does not match frequency count."
                )
            table_cropped = self.table[mask].copy()

        if inplace:
            self.freqs = freqs_cropped
            self.Z = Z_cropped
            self.table = table_cropped
            return self

        return Sweep(
            freqs=freqs_cropped,
            Z=Z_cropped,
            table=table_cropped,
            sweep_idx=self.sweep_idx,
        )

    def get_r0(self, im_tol: float = 1e-3, k: int = 10) -> float:
        """Estimate ohmic resistance (`R0`) from the main Nyquist arc.

        Strategy:
        1. Sort points by descending frequency.
        2. Find contiguous regions where ``-Im(Z) > im_tol``.
        3. Select the first region with at least ``k`` points as the main arc.
        4. Use the first point of this arc and interpolate to ``-Im(Z)=0`` using
           the first negative point found outside the arc boundary.

        Args:
            im_tol: Threshold for considering ``-Im(Z)`` as positive arc data.
            k: Minimum contiguous points required for the main arc.

        Returns:
            float: Estimated R0 in ohms.

        Raises:
            ValueError: If data is empty or no valid arc can be detected.
        """
        if self.freqs.size == 0 or self.Z.size == 0:
            raise ValueError("Cannot compute r0 from empty PEIS data.")
        if k < 1:
            raise ValueError("k must be >= 1.")

        freqs = np.asarray(self.freqs, dtype=float)
        re_vals = np.real(self.Z).astype(float)
        minus_im_vals = (-np.imag(self.Z)).astype(float)

        order = np.argsort(freqs)[::-1]
        re_hf = re_vals[order]
        minus_im_hf = minus_im_vals[order]

        is_arc = minus_im_hf > im_tol

        main_start = None
        main_end = None
        in_region = False
        region_start = 0
        for idx, flag in enumerate(is_arc):
            if flag and not in_region:
                in_region = True
                region_start = idx
            elif not flag and in_region:
                region_end = idx - 1
                if region_end - region_start + 1 >= k:
                    main_start, main_end = region_start, region_end
                    break
                in_region = False
        if in_region and main_start is None:
            region_end = len(is_arc) - 1
            if region_end - region_start + 1 >= k:
                main_start, main_end = region_start, region_end

        if main_start is None or main_end is None:
            raise ValueError(
                "No main arc found with the current thresholds. "
                "Try lowering im_tol or k."
            )

        arc_idx = main_start
        x_arc = re_hf[arc_idx]
        y_arc = minus_im_hf[arc_idx]

        if y_arc <= 0.0:
            raise ValueError("Main arc start is not above zero; adjust im_tol/k.")

        neg_idx = None

        # Prefer the first negative point on the high-frequency side of the arc.
        for idx in range(arc_idx - 1, -1, -1):
            if minus_im_hf[idx] < -im_tol:
                neg_idx = idx
                break

        # Fallback: first negative point after the arc (lower-frequency side).
        if neg_idx is None:
            for idx in range(main_end + 1, len(minus_im_hf)):
                if minus_im_hf[idx] < -im_tol:
                    neg_idx = idx
                    break

        if neg_idx is None:
            closest_idx = int(np.argmin(np.abs(minus_im_hf)))
            self.r0 = float(re_hf[closest_idx])
            return self.r0

        x_neg = re_hf[neg_idx]
        y_neg = minus_im_hf[neg_idx]

        if y_arc == y_neg:
            self.r0 = float(x_arc)
            return self.r0

        self.r0 = float(x_arc + (-y_arc) * (x_neg - x_arc) / (y_neg - y_arc))
        return self.r0

    @property
    def z(self) -> np.ndarray:
        """Return impedance values as complex array."""
        return np.real(self.Z) + 1j * np.imag(self.Z)

    @property
    def n_points(self) -> int:
        """Return number of measurement points in this sweep."""
        return int(self.freqs.size)

    def copy(self) -> "Sweep":
        """Return a shallow data copy of this sweep."""
        return Sweep(
            self.freqs.copy(),
            self.Z.copy(),
        )

    def crop_x(
            self,
            x_min: float | None = None,
            x_max: float | None = None,
            *,
            inplace: bool = False,
    ) -> "Sweep":
        """Alias for Nyquist x-axis crop (`x = Re(Z)`).

        Args:
            x_min: Optional lower bound for ``Re(Z)``.
            x_max: Optional upper bound for ``Re(Z)``.
            inplace: If ``True``, mutate and return `self`.

        Returns:
            Cropped `Sweep`.
        """
        return self.crop_z_re(x_min=x_min, x_max=x_max, inplace=inplace)

    def crop_z_re(
            self,
            x_min: float | None = None,
            x_max: float | None = None,
            *,
            inplace: bool = False,
    ) -> "Sweep":
        """Keep only points with ``Re(Z)`` inside ``[x_min, x_max]``.

        Args:
            x_min: Optional lower bound for ``Re(Z)``.
            x_max: Optional upper bound for ``Re(Z)``.
            inplace: If ``True``, mutate and return `self`.

        Returns:
            Cropped `Sweep`.
        """
        mask = np.ones(self.n_points, dtype=bool)
        if x_min is not None:
            mask &= np.real(self.Z) >= float(x_min)
        if x_max is not None:
            mask &= np.real(self.Z) <= float(x_max)
        return self._filtered(mask, inplace=inplace)

    def remove_freq_range(self, f_min: float, f_max: float, *, inplace: bool = False) -> "Sweep":
        """Remove points with frequency inside ``[f_min, f_max]``.

        Args:
            f_min: One range endpoint in Hz.
            f_max: Other range endpoint in Hz.
            inplace: If ``True``, mutate and return `self`.

        Returns:
            Filtered `Sweep`.
        """
        lo, hi = sorted((float(f_min), float(f_max)))
        mask = ~((self.freqs >= lo) & (self.freqs <= hi))
        return self._filtered(mask, inplace=inplace)

    def remove_x_range(self, x_min: float, x_max: float, *, inplace: bool = False) -> "Sweep":
        """Remove points with ``Re(Z)`` inside ``[x_min, x_max]``.

        Args:
            x_min: One range endpoint for ``Re(Z)``.
            x_max: Other range endpoint for ``Re(Z)``.
            inplace: If ``True``, mutate and return `self`.

        Returns:
            Filtered `Sweep`.
        """
        lo, hi = sorted((float(x_min), float(x_max)))
        mask = ~((np.real(self.Z) >= lo) & (np.real(self.Z) <= hi))
        return self._filtered(mask, inplace=inplace)

    def drop_outliers(self, z_abs_max: float | None = None, *, inplace: bool = False) -> "Sweep":
        """Drop points whose impedance magnitude exceeds a threshold.

        Args:
            z_abs_max: Maximum allowed ``|Z|``. If ``None``, no filtering is applied.
            inplace: If ``True``, mutate and return `self`.

        Returns:
            Filtered `Sweep`.
        """
        target = self if inplace else self.copy()
        if z_abs_max is None:
            return target
        mask = np.abs(target.z) <= float(z_abs_max)
        target.freqs = target.freqs[mask]
        target.Z = target.Z[mask]
        target._sort_by_freq_desc_inplace()
        return target

    def nyquist(self) -> tuple[np.ndarray, np.ndarray]:
        """Return Nyquist plot arrays.

        Returns:
            Tuple ``(Re(Z), -Im(Z))``.
        """
        return np.real(self.Z).copy(), (-np.imag(self.Z)).copy()

    def bode(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return Bode plot arrays.

        Returns:
            Tuple ``(freq_hz, |Z|, phase_deg)``.
        """
        mag = np.abs(self.z)
        phase_deg = np.angle(self.z, deg=True)
        return self.freqs.copy(), mag, phase_deg

    def plot_nyquist(
            self,
            ax=None,
            *,
            label: str = "measurement",
            show: bool = True,
            color_by_frequency: bool = False,
            cmap: str = "viridis",
            add_colorbar: bool = True,
    ):
        """Plot Nyquist diagram for the sweep.

        Args:
            ax: Optional target Matplotlib axes.
            label: Legend label for the data trace.
            show: Whether to call ``plt.show()``.
            color_by_frequency: If ``True``, color points by frequency.
            cmap: Colormap name used when ``color_by_frequency`` is enabled.
            add_colorbar: If ``True``, attach a frequency colorbar when coloring
                by frequency.

        Returns:
            Axes containing the plot.
        """
        _require_matplotlib()
        if ax is None:
            _, ax = plt.subplots(figsize=(6, 5))
        x, y = self.nyquist()
        if color_by_frequency:
            freq_vals = np.asarray(self.freqs, dtype=float)
            scatter_kwargs = {
                "c": freq_vals,
                "cmap": cmap,
                "s": 24,
                "label": label,
            }
            finite_mask = np.isfinite(freq_vals)
            if np.any(finite_mask):
                finite_freq = freq_vals[finite_mask]
                min_freq = float(np.min(finite_freq))
                max_freq = float(np.max(finite_freq))
                if min_freq > 0.0 and max_freq > min_freq:
                    from matplotlib.colors import LogNorm
                    scatter_kwargs["norm"] = LogNorm(vmin=min_freq, vmax=max_freq)

            scatter = ax.scatter(x, y, **scatter_kwargs)
            ax.plot(x, y, "-", lw=1.2, color="0.35", alpha=0.7)
            if add_colorbar:
                cbar = ax.figure.colorbar(scatter, ax=ax)
                cbar.set_label("Frequency [Hz]")
        else:
            ax.plot(x, y, "o-", ms=4, lw=1.5, label=label)
        ax.set_xlabel(r"$Z' \;[\Omega]$")
        ax.set_ylabel(r"$-Z'' \;[\Omega]$")
        ax.set_title("Nyquist")
        ax.axis("equal")
        if label:
            ax.legend()
        if show:
            plt.show()
        return ax

    def plot_bode(self, axes=None, *, label: str = "measurement", show: bool = True):
        """Plot Bode magnitude and phase for the sweep.

        Args:
            axes: Optional tuple of existing ``(ax_mag, ax_phase)`` axes.
            label: Legend label for the data traces.
            show: Whether to call ``plt.show()``.

        Returns:
            Tuple ``(figure, (ax_mag, ax_phase))``.
        """
        _require_matplotlib()
        f, mag, phase = self.bode()
        if axes is None:
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7, 7), sharex=True)
        else:
            ax1, ax2 = axes
            fig = ax1.figure

        ax1.semilogx(f, mag, "o-", ms=4, label=label)
        ax1.set_ylabel(r"$|Z| \;[\Omega]$")
        ax1.set_title("Bode")
        if label:
            ax1.legend()

        ax2.semilogx(f, phase, "o-", ms=4, label=label)
        ax2.set_xlabel("Frequency [Hz]")
        ax2.set_ylabel("Phase [deg]")
        if label:
            ax2.legend()

        fig.tight_layout()
        if show:
            plt.show()
        return fig, (ax1, ax2)

    def plot_fit_nyquist(
            self,
            ax=None,
            *,
            measurement_label: str = "measurement",
            fit_label: str = "fit",
            show: bool = True,
            color_by_frequency: bool = False,
            cmap: str = "viridis",
            add_colorbar: bool = True,
    ):
        """Overlay fitted impedance on the Nyquist plot.

        Args:
            ax: Optional target Matplotlib axes.
            measurement_label: Legend label for measured data.
            fit_label: Legend label for fitted response.
            show: Whether to call ``plt.show()``.
            color_by_frequency: If ``True``, color measured points by frequency.
            cmap: Colormap name used when ``color_by_frequency`` is enabled.
            add_colorbar: If ``True``, attach a frequency colorbar when coloring
                by frequency.

        Returns:
            Axes containing the plot.

        Raises:
            ValueError: If stored fit data shape does not match measurement data.
        """
        _require_matplotlib()
        if self.fit_result.Z_fit.shape != self.z.shape:
            raise ValueError("fit.Z_fit shape does not match measurement data shape")

        if ax is None:
            _, ax = plt.subplots(figsize=(6, 5))

        x_meas = np.real(self.Z)
        y_meas = -np.imag(self.Z)
        if color_by_frequency:
            freq_vals = np.asarray(self.freqs, dtype=float)
            scatter_kwargs = {
                "c": freq_vals,
                "cmap": cmap,
                "s": 24,
                "label": measurement_label,
            }
            finite_mask = np.isfinite(freq_vals)
            if np.any(finite_mask):
                finite_freq = freq_vals[finite_mask]
                min_freq = float(np.min(finite_freq))
                max_freq = float(np.max(finite_freq))
                if min_freq > 0.0 and max_freq > min_freq:
                    from matplotlib.colors import LogNorm
                    scatter_kwargs["norm"] = LogNorm(vmin=min_freq, vmax=max_freq)

            scatter = ax.scatter(x_meas, y_meas, **scatter_kwargs)
            ax.plot(x_meas, y_meas, "-", lw=1.0, color="0.35", alpha=0.7)
            if add_colorbar:
                cbar = ax.figure.colorbar(scatter, ax=ax)
                cbar.set_label("Frequency [Hz]")
        else:
            ax.plot(x_meas, y_meas, "o", ms=4, label=measurement_label)
        ax.plot(np.real(self.fit_result.Z_fit), -np.imag(self.fit_result.Z_fit), "-", lw=2, label=fit_label)
        ax.set_xlabel(r"$Z' \;[\Omega]$")
        ax.set_ylabel(r"$-Z'' \;[\Omega]$")
        ax.set_title("Nyquist: Measurement vs Fit")
        ax.axis("equal")
        ax.legend()
        if show:
            plt.show()
        return ax

    def plot_fit_bode(
            self,
            axes=None,
            *,
            measurement_label: str = "measurement",
            fit_label: str = "fit",
            show: bool = True,
    ):
        """Overlay fitted impedance on Bode magnitude and phase.

        Args:
            axes: Optional tuple of existing ``(ax_mag, ax_phase)`` axes.
            measurement_label: Legend label for measured data.
            fit_label: Legend label for fitted response.
            show: Whether to call ``plt.show()``.

        Returns:
            Tuple ``(figure, (ax_mag, ax_phase))``.

        Raises:
            ValueError: If stored fit data shape does not match measurement data.
        """
        _require_matplotlib()
        if self.fit_result.Z_fit.shape != self.Z.shape:
            raise ValueError("fit.Z_fit shape does not match measurement data shape")

        f = self.freqs
        mag_meas = np.abs(self.Z)
        phase_meas = np.angle(self.Z, deg=True)
        mag_fit = np.abs(self.fit_result.Z_fit)
        phase_fit = np.angle(self.fit_result.Z_fit, deg=True)

        if axes is None:
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7, 7), sharex=True)
        else:
            ax1, ax2 = axes
            fig = ax1.figure

        ax1.semilogx(f, mag_meas, "o", ms=4, label=measurement_label)
        ax1.semilogx(f, mag_fit, "-", lw=2, label=fit_label)
        ax1.set_ylabel(r"$|Z| \;[\Omega]$")
        ax1.set_title("Bode: Measurement vs Fit")
        ax1.legend()

        ax2.semilogx(f, phase_meas, "o", ms=4, label=measurement_label)
        ax2.semilogx(f, phase_fit, "-", lw=2, label=fit_label)
        ax2.set_xlabel("Frequency [Hz]")
        ax2.set_ylabel("Phase [deg]")
        ax2.legend()

        fig.tight_layout()
        if show:
            plt.show()
        return fig, (ax1, ax2)

    def fit(
            self,
            model: ModelFn,
            initial_params: dict[str, float],
            *,
            bounds: dict[str, tuple[float, float]] | None = None,
            max_nfev: int | None = None,
            weight: str = "uniform",
            n_starts: int = 1,
            random_seed: int | None = 0,
            refine_rmse: bool = False,
            x_scale: str = "jac",
            print_res = False,
    ) -> EISFitResult:
        """Fit an equivalent-circuit model using `scipy.optimize.least_squares`.

        The model signature must be:
        ``model(freqs, params_dict) -> complex impedance vector``.

        Args:
            model: Callable impedance model.
            initial_params: Initial parameter values keyed by parameter name.
            bounds: Optional per-parameter bound overrides.
            max_nfev: Maximum number of function evaluations for least squares.
            weight: Residual weighting mode (`uniform` or `modulus`).
            n_starts: Number of randomized start points for multi-start fitting.
            random_seed: Random seed used when ``n_starts > 1``.
            refine_rmse: Whether to run a second uniform-residual refinement pass.
            x_scale: `least_squares` `x_scale` argument.
            print_res: Whether to print a terminal summary after fitting.

        Returns:
            Stored fit result object.

        Raises:
            ValueError: If parameters, bounds, weighting mode, or model shape are invalid.
        """
        if not initial_params:
            raise ValueError("initial_params must not be empty")

        param_names = list(initial_params.keys())
        x0 = np.array([float(initial_params[k]) for k in param_names], dtype=float)

        lower = np.empty_like(x0, dtype=float)
        upper = np.empty_like(x0, dtype=float)
        for i, name in enumerate(param_names):
            lo, hi = _default_bounds_for_param(name)
            if bounds and name in bounds:
                lo, hi = bounds[name]
            lower[i] = float(lo)
            upper[i] = float(hi)

        if np.any(lower > upper):
            raise ValueError("Invalid bounds: lower > upper")

        meas_re = np.real(self.Z)
        meas_im = np.imag(self.Z)
        freq = self.freqs

        if n_starts < 1:
            raise ValueError("n_starts must be >= 1")

        def _pack_params(x: np.ndarray) -> dict[str, float]:
            return {k: float(v) for k, v in zip(param_names, x, strict=True)}

        def _residuals_with_weight(x: np.ndarray, mode: str) -> np.ndarray:
            z_model = np.asarray(model(freq, _pack_params(x)), dtype=complex)
            if z_model.shape != meas_re.shape:
                raise ValueError("Model output shape must match data shape")

            if mode == "uniform":
                w_re = np.ones_like(meas_re)
                w_im = np.ones_like(meas_im)
            elif mode == "modulus":
                m = np.abs(self.z)
                m[m == 0] = 1.0
                w_re = 1.0 / m
                w_im = 1.0 / m
            else:
                raise ValueError("weight must be 'uniform' or 'modulus'")

            res_re = (np.real(z_model) - meas_re) * w_re
            res_im = (np.imag(z_model) - meas_im) * w_im
            return np.concatenate([res_re, res_im])

        def _run_ls(x_init: np.ndarray, mode: str):
            return least_squares(
                lambda x: _residuals_with_weight(x, mode),
                x0=x_init,
                bounds=(lower, upper),
                max_nfev=max_nfev,
                x_scale=x_scale,
            )

        def _clip_to_bounds(x: np.ndarray) -> np.ndarray:
            x_clipped = np.maximum(x, lower)
            x_clipped = np.minimum(x_clipped, upper)
            return x_clipped

        # Multi-start for robustness (first start is the user-provided x0)
        starts: list[np.ndarray] = [x0.copy()]
        if n_starts > 1:
            rng = np.random.default_rng(random_seed)
            for _ in range(n_starts - 1):
                candidate = x0.copy()
                for i in range(candidate.size):
                    lo, hi = lower[i], upper[i]
                    xi = candidate[i]
                    if np.isfinite(lo) and np.isfinite(hi):
                        candidate[i] = rng.uniform(lo, hi)
                    elif np.isfinite(lo) and not np.isfinite(hi) and lo >= 0 and xi > 0:
                        candidate[i] = xi * np.exp(rng.normal(0.0, 0.8))
                    else:
                        scale = max(1.0, abs(xi))
                        candidate[i] = xi + rng.normal(0.0, 0.5 * scale)
                starts.append(_clip_to_bounds(candidate))

        primary_results = [_run_ls(start, weight) for start in starts]
        result = min(primary_results, key=lambda r: float(r.cost))

        # Optional second stage: refine using uniform residual to improve RMSE.
        if refine_rmse:
            refined = _run_ls(result.x, "uniform")
            z_primary = np.asarray(model(freq, _pack_params(result.x)), dtype=complex)
            z_refined = np.asarray(model(freq, _pack_params(refined.x)), dtype=complex)
            rmse_primary = float(np.sqrt(np.mean(np.abs(z_primary - self.z) ** 2)))
            rmse_refined = float(np.sqrt(np.mean(np.abs(z_refined - self.z) ** 2)))
            if rmse_refined < rmse_primary:
                result = refined

        params = _pack_params(result.x)
        Z_fit = np.asarray(model(freq, params), dtype=complex)
        residual_re = np.real(Z_fit) - meas_re
        residual_im = np.imag(Z_fit) - meas_im

        self.fit_result = EISFitResult(
            param_names=param_names,
            params=params,
            success=bool(result.success),
            cost=float(result.cost),
            message=str(result.message),
            nfev=int(result.nfev),
            Z_fit=Z_fit,
            residual_re=residual_re,
            residual_im=residual_im,
            raw=result,
        )
        if print_res:
            self.fit_result.print_summary()
        return self.fit_result


    def run_simple_drt(self, config: DRTConfig | None = None, **overrides) -> EIS_object:
        """
        Run the standard pyDRTtools 'Simple Run' on an EIS_object.

        Args:
            entry (EIS_object): The EIS_object returned by the DataLoader.
            config (SimpleDRTConfig | optional): Base config for the run. If None, SimpleDRTConfig() is used.
            overrides (dict): Keyword arguments to override config fields (e.g. reg_param=1e-2).

        Returns:
            EIS_object: EIS_Object Same object as entry, but with entry.gamma, entry.out_tau_vec, lambda_value, etc.
        """
        self.drt_entry = self._to_eis_object()
        if config is None:
            config = DRTConfig()

        # Turn dataclass into kwargs and apply overrides
        params = config.__dict__.copy()
        params.update(overrides)

        simple_run(
            self.drt_entry,
            rbf_type=params["rbf_type"],
            data_used=params["data_used"],
            induct_used=params["induct_used"],
            der_used=params["der_used"],
            cv_type=params["cv_type"],
            reg_param=params["reg_param"],
            shape_control=params["shape_control"],
            coeff=params["coeff"],
        )

        return self.drt_entry


    def run_bayesian_drt(self, **kwargs) -> EIS_object:
        """
        Run Bayesian DRT on an EIS_object.

        Args:
            entry (EIS_object): EIS_object to run DRT on.

        Returns:
            EIS_object: EIS_object with entry.gamma, entry.out_tau_vec, lambda_value, etc.
        """
        Bayesian_run(self.drt_entry, **kwargs)
        return self.drt_entry


    def run_bht(self, **kwargs) -> EIS_object:
        """
        Run Hilbert transform / EIS quality tests on an EIS_object.

        Args:
            entry (EIS_object): EIS_object to run DRT on.

        Returns:
            EIS_object: EIS_object with entry.gamma, entry.out_tau_vec, lambda_value, etc.
        """
        BHT_run(self.drt_entry, **kwargs)
        return self.drt_entry

    def summarize_peaks(self, **find_peaks_kwargs) -> PeakSummary:
        """
        Analyze the DRT spectrum and return basic peak information.

        Args:
            entry (EIS_object): EIS_object with entry.gamma and entry.out_tau_vec.
            **find_peaks_kwargs: Additional arguments passed to scipy.signal.find_peaks.

        Returns:
            PeakSummary: PeakSummary object containing peak information.
        """
        if self.drt_entry is None:
            raise ValueError("No DRT object provided you must run a form of drt analysis by calling .run_simple_drt() first.")
        tau = self.drt_entry.out_tau_vec
        gamma = self.drt_entry.gamma

        idx, props = find_peaks(gamma, **find_peaks_kwargs)

        return PeakSummary(
            num_peaks=len(idx),
            peak_indices=idx,
            peak_tau=tau[idx],
            peak_gamma=gamma[idx],
        )

    def plot_drt(self,
                 *,
                 ax=None,
                 show_peaks: bool = False,
                 **find_peaks_kwargs
                 ):
        """
        Plot the DRT spectrum gamma(tau).

        Args:
            entry (EIS_object): Must have entry.out_tau_vec and entry.gamma
            ax (matplotlib.axes.Axes | None): Draw into this Axes if provided, otherwise create a new figure.
            show_peaks (bool): If True, detect peaks and mark them.
            find_peaks_kwargs (dict): Passed through to summarize_peaks (e.g. prominence=..., distance=...)

        Returns:
            tuple[matplotlib.axes.Axes, Optional["PeakSummary"]]: tuple containing axes with the plots
            and PeakSummary Object containing Peak Information if show_peaks=True
        """
        if self.drt_entry is None:
            raise ValueError("No DRT object provided you must run a form of drt analysis by calling .run_simple_drt() first.")
        _require_matplotlib()
        tau = self.drt_entry.out_tau_vec
        gamma = self.drt_entry.gamma

        if ax is None:
            _, ax = plt.subplots()

        ax.plot(tau, gamma)
        ax.set_xscale("log")
        ax.set_xlabel("τ (s)")
        ax.set_ylabel("γ(τ)")

        peaks = None
        if show_peaks:
            peaks = self.summarize_peaks(**find_peaks_kwargs)
            ax.scatter(peaks.peak_tau, peaks.peak_gamma, marker="x")

        plt.show()
        return (ax, peaks) if show_peaks else ax

    def _validate_and_clean_inplace(self) -> None:
        """Validate finite values and sort data by descending frequency.

        Raises:
            ValueError: If shape checks fail or all datapoints are filtered out.
        """
        if not (self.freqs.shape == self.Z):
            raise ValueError("freqs, z_re_ohm and z_im_ohm must have same length")
        mask = np.isfinite(self.freqs) & np.isfinite(self.Z)
        self.freqs = self.freqs[mask]
        self.Z = self.Z[mask]

        if self.freqs.size == 0:
            raise ValueError("No valid datapoints after cleaning")
        self._sort_by_freq_desc_inplace()

    def _sort_by_freq_desc_inplace(self) -> None:
        """Sort sweep points by descending frequency."""
        idx = np.argsort(self.freqs)[::-1]
        self.freqs = self.freqs[idx]
        self.Z = self.Z[idx]

    def _filtered(self, mask: np.ndarray, *, inplace: bool) -> "Sweep":
        """Apply a boolean mask and return filtered data.

        Args:
            mask: Boolean mask aligned with current sweep length.
            inplace: If ``True``, mutate and return `self`.

        Returns:
            Filtered `Sweep`.

        Raises:
            ValueError: If filtering removes all datapoints.
        """
        target = self if inplace else self.copy()
        target.freqs = target.freqs[mask]
        target.z_re_ohm = target.z_re_ohm[mask]
        target.z_im_ohm = target.z_im_ohm[mask]
        if target.freqs.size == 0:
            raise ValueError("Filtering removed all datapoints")
        target._sort_by_freq_desc_inplace()
        return target

    # Conversion to pyDRTtools format
    def _to_eis_object(self) -> EIS_object:
        """
        Convert the cleaned data into a pyDRTtools EIS_object.

        Returns:
            EIS_object: EIS_object containing the loaded data.

        Notes:
            We go via a temporary file because EIS_object currently reads from file.
        """
        arr = np.column_stack([self.freqs, np.real(self.Z), np.imag(self.Z)])

        with tempfile.NamedTemporaryFile(
                mode="w", delete=False, suffix=".csv"
        ) as tmp:
            np.savetxt(tmp, arr, delimiter=",")
            tmp_path = tmp.name

        try:
            self.drt_entry = EIS_object.from_file(tmp_path)
        finally:
            # EIS_object reads the file immediately, so it's safe to delete
            os.remove(tmp_path)

        return self.drt_entry


@dataclass
class Run(PEISData):
    """
    Full PEIS run (potentially containing multiple frequency sweeps).

    Attributes:
        sweeps (List[Sweep]): Split single-sweep datasets.
        num_sweeps (int): Number of detected sweeps.
        mean_re_drift (float): Mean drift in real direction between adjacent sweeps.
        mean_imag_drift (float): Mean drift in imaginary direction between adjacent sweeps.
        r0_values (List[float]): Per-sweep R0 values indexed by sweep index.
        mean_r0 (Optional[float]): Mean R0 across the run.
        std_r0 (Optional[float]): Standard deviation of R0 across the run.
    """
    sweeps: List[Sweep] = field(default_factory=list)
    num_sweeps: int = 0
    mean_re_drift: float = 0.0
    mean_imag_drift: float = 0.0
    r0_values: List[float] = field(default_factory=list)
    mean_r0: Optional[float] = None
    std_r0: Optional[float] = None
    sem_r0: Optional[float] = None
    source: Optional[str] = None
    biologic_format: str = "f,-im,re"
    meta: Optional[str] = None

    def __post_init__(self) -> None:
        self.split_sweeps()
        self.get_r0_stats()

    @property
    def first_sweep(self) -> Sweep:
        """Return the first detected sweep."""
        return self.sweeps[0]

    @property
    def second_sweep(self) -> Sweep:
        """Return the second detected sweep.

        Raises:
            ValueError: If fewer than two sweeps are available.
        """
        if len(self.sweeps) < 2:
            raise ValueError(f"Sweeps only contains one sweep")
        return self.sweeps[1]

    def get_sweep(self, idx) -> Sweep:
        """Return a sweep by index.

        Args:
            idx: Zero-based sweep index.

        Returns:
            Requested `Sweep`.

        Raises:
            IndexError: If ``idx`` is outside available sweep range.
        """
        if idx >= len(self.sweeps):
            raise IndexError(f"Index {idx} out of range.")
        return self.sweeps[idx]

    @staticmethod
    def _compute_mean_drift(sweeps: List[Sweep]) -> tuple[float, float]:
        """Compute mean sweep-to-sweep drift in real and imaginary axes.

        Args:
            sweeps: Ordered sweep list.

        Returns:
            Tuple ``(mean_re_drift, mean_imag_drift)``.
        """
        if len(sweeps) < 2:
            return 0.0, 0.0

        re_deltas: List[float] = []
        imag_deltas: List[float] = []
        for prev_sweep, next_sweep in zip(sweeps[:-1], sweeps[1:]):
            n_points = min(prev_sweep.Z.size, next_sweep.Z.size)
            if n_points == 0:
                continue
            re_prev = np.real(prev_sweep.Z[:n_points])
            re_next = np.real(next_sweep.Z[:n_points])
            imag_prev = np.imag(prev_sweep.Z[:n_points])
            imag_next = np.imag(next_sweep.Z[:n_points])

            re_deltas.append(float(np.mean(re_next - re_prev)))
            imag_deltas.append(float(np.mean(imag_next - imag_prev)))

        if not re_deltas:
            return 0.0, 0.0

        return float(np.mean(re_deltas)), float(np.mean(imag_deltas))

    def split_sweeps(
        self,
        reset_ratio: float = 5.0,
        min_points_per_sweep: int = 3,
    ) -> List[Sweep]:
        """
        Split a full PEIS run into individual sweeps.

        Sweep boundaries are detected via large frequency resets between
        consecutive points.

        Args:
            reset_ratio (float):
                Minimum multiplicative jump to classify a reset (must be > 1).
                Example: for descending sweeps, a jump from 1 Hz to 100 kHz.
            min_points_per_sweep (int):
                Minimum number of points required on each side of a detected
                boundary to keep it.

        Returns:
            List[Sweep]:
                List of individual sweep datasets.
        """
        if reset_ratio <= 1.0:
            raise ValueError("reset_ratio must be > 1.")
        if min_points_per_sweep < 1:
            raise ValueError("min_points_per_sweep must be >= 1.")

        n_total = int(self.freqs.size)
        if n_total == 0:
            self.sweeps = []
            self.num_sweeps = 0
            self.mean_re_drift = 0.0
            self.mean_imag_drift = 0.0
            return self.sweeps

        if self.table is not None and self.table.shape[0] != n_total:
            raise ValueError(
                "Cannot split sweeps: table row count does not match frequency count."
            )

        if n_total == 1:
            only_sweep = Sweep(
                freqs=self.freqs.copy(),
                Z=self.Z.copy(),
                table=self.table.copy() if self.table is not None else None,
                source=self.source,
                biologic_format=self.biologic_format,
                sweep_idx=0,
            )
            self.sweeps = [only_sweep]
            self.num_sweeps = 1
            self.mean_re_drift = 0.0
            self.mean_imag_drift = 0.0
            return self.sweeps

        diffs = np.diff(self.freqs.astype(float))
        nonzero_diffs = diffs[np.abs(diffs) > 0]
        descending_sweep = (
            np.median(nonzero_diffs) < 0 if nonzero_diffs.size > 0 else True
        )

        prev = self.freqs[:-1].astype(float)
        curr = self.freqs[1:].astype(float)
        eps = np.finfo(float).eps

        if descending_sweep:
            ratios = curr / np.where(np.abs(prev) < eps, np.nan, prev) # ratio from current to previous element (if close to zero prev is replaced with np.nan)
            candidate_boundaries = np.where(
                (curr > prev) & (ratios >= reset_ratio)
            )[0] + 1
        else:
            ratios = prev / np.where(np.abs(curr) < eps, np.nan, curr)
            candidate_boundaries = np.where(
                (curr < prev) & (ratios >= reset_ratio)
            )[0] + 1

        boundaries: List[int] = []
        start_idx = 0
        for boundary in candidate_boundaries.tolist():
            left_len = boundary - start_idx
            right_len = n_total - boundary
            if left_len >= min_points_per_sweep and right_len >= min_points_per_sweep:
                boundaries.append(boundary)
                start_idx = boundary

        starts = [0, *boundaries]
        ends = [*boundaries, n_total]

        sweeps: List[Sweep] = []
        for start, end in zip(starts, ends):
            if end <= start:
                continue
            sweep_table = (
                self.table[start:end].copy() if self.table is not None else None
            )
            sweep_data = Sweep(
                freqs=self.freqs[start:end].copy(),
                Z=self.Z[start:end].copy(),
                table=sweep_table,
                sweep_idx=len(sweeps),
            )
            sweeps.append(sweep_data)

        self.sweeps = sweeps
        self.num_sweeps = len(sweeps)
        self.mean_re_drift, self.mean_imag_drift = self._compute_mean_drift(sweeps)
        return self.sweeps

    def get_r0_stats(self, im_tol: float = 1e-3, k: int = 5) -> tuple[float, float, float]:
        """
        Compute per-sweep R0 values and aggregate statistics for this run.

        Args:
            im_tol (float): Threshold for considering ``-Im(Z)`` above zero.
            k (int): Minimum number of contiguous points above ``im_tol``
                for main-arc detection.

        Returns:
            tuple[float, float]:
                ``(mean_r0, std_r0)`` across all sweeps.

        Notes:
        """
        if not self.sweeps:
            self.split_sweeps()

        if not self.sweeps:
            raise ValueError("Cannot compute r0 stats: no sweeps available.")

        n_sweeps = len(self.sweeps)
        r0_vals = np.full(n_sweeps, np.nan, dtype=float)

        for list_idx, sweep in enumerate(self.sweeps):
            target_idx = (
                int(sweep.sweep_idx)
                if sweep.sweep_idx is not None and 0 <= int(sweep.sweep_idx) < n_sweeps
                else list_idx
            )
            r0_vals[target_idx] = float(sweep.get_r0(im_tol=im_tol, k=k))

        valid_mask = ~np.isnan(r0_vals)
        n_valid = np.sum(valid_mask)
        if not np.any(valid_mask):
            raise ValueError("Could not compute any valid r0 values for this run.")
        if n_valid <= 1:
            raise ValueError("Cannot compute Statistical Values for runs with only one valid sweep.")

        self.r0_values = r0_vals.tolist()
        self.mean_r0 = float(np.mean(r0_vals[valid_mask]))
        self.std_r0 = float(np.std(r0_vals[valid_mask], ddof=1))
        self.sem_r0 = self.std_r0 / np.sqrt(n_valid)
        return self.mean_r0, self.std_r0, self.sem_r0


def _default_bounds_for_param(name: str) -> tuple[float, float]:
    """Return heuristic optimizer bounds for a parameter name.

    Args:
        name: Parameter identifier.

    Returns:
        Tuple ``(lower_bound, upper_bound)``.
    """
    n = name.strip().lower()

    if n.startswith("alpha"):
        return 0.0, 1.0
    if n.startswith("r"):
        return 0.0, np.inf
    if n.startswith("c"):
        # capacitance-like (C_1), also catches CPE_... unless explicitly overridden
        return 1e-10, 1.0
    if n.startswith("q"):
        # CPE prefactor Q
        return 1e-12, 1.0
    if n.startswith("w") or "warburg" in n or "sigma" in n:
        return 0.0, np.inf

    return -np.inf, np.inf


def _require_matplotlib() -> None:
    """Import and cache `matplotlib.pyplot` lazily for plotting helpers."""
    global plt
    if plt is None:
        import matplotlib.pyplot as _plt

        plt = _plt
