# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "avido"
__version__ = "1.45.0"  # x-release-please-version
