import datetime

from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RouteTargetType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ROUTE_TARGET_TYPE_UNSPECIFIED: _ClassVar[RouteTargetType]
    ROUTE_TARGET_TYPE_PASSENGER: _ClassVar[RouteTargetType]
    ROUTE_TARGET_TYPE_DRIVER: _ClassVar[RouteTargetType]
ROUTE_TARGET_TYPE_UNSPECIFIED: RouteTargetType
ROUTE_TARGET_TYPE_PASSENGER: RouteTargetType
ROUTE_TARGET_TYPE_DRIVER: RouteTargetType

class DirectRoute(_message.Message):
    __slots__ = ("target_id", "target_type", "distance_meters", "duration", "departure_from_org", "departure_window_from_org", "encoded_polyline")
    TARGET_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_TYPE_FIELD_NUMBER: _ClassVar[int]
    DISTANCE_METERS_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    DEPARTURE_FROM_ORG_FIELD_NUMBER: _ClassVar[int]
    DEPARTURE_WINDOW_FROM_ORG_FIELD_NUMBER: _ClassVar[int]
    ENCODED_POLYLINE_FIELD_NUMBER: _ClassVar[int]
    target_id: str
    target_type: RouteTargetType
    distance_meters: int
    duration: _duration_pb2.Duration
    departure_from_org: _timestamp_pb2.Timestamp
    departure_window_from_org: _duration_pb2.Duration
    encoded_polyline: str
    def __init__(self, target_id: _Optional[str] = ..., target_type: _Optional[_Union[RouteTargetType, str]] = ..., distance_meters: _Optional[int] = ..., duration: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., departure_from_org: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., departure_window_from_org: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., encoded_polyline: _Optional[str] = ...) -> None: ...

class OptimizedRoute(_message.Message):
    __slots__ = ("target_group_id", "distance_meters", "duration", "departure_from_org", "departure_window_from_org", "encoded_polyline")
    TARGET_GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    DISTANCE_METERS_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    DEPARTURE_FROM_ORG_FIELD_NUMBER: _ClassVar[int]
    DEPARTURE_WINDOW_FROM_ORG_FIELD_NUMBER: _ClassVar[int]
    ENCODED_POLYLINE_FIELD_NUMBER: _ClassVar[int]
    target_group_id: str
    distance_meters: int
    duration: _duration_pb2.Duration
    departure_from_org: _timestamp_pb2.Timestamp
    departure_window_from_org: _duration_pb2.Duration
    encoded_polyline: str
    def __init__(self, target_group_id: _Optional[str] = ..., distance_meters: _Optional[int] = ..., duration: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., departure_from_org: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., departure_window_from_org: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., encoded_polyline: _Optional[str] = ...) -> None: ...
