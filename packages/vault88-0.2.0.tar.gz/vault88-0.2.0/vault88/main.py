"""CLI Main execution loop"""

import configparser
import importlib
import os
import re
import sys
import traceback

from vault88.args import parseArgs
from vault88.core.environment_loaders import ApiLoader, JsonFileLoader
from vault88.core.loader import Loader
from vault88.core.logger import Logger
from vault88.core.reporters.junit_reporter import JUnitReporter
from vault88.core.runner import Runner


def _loadReporters(logger, config):
    reporters = []
    section_pattern = re.compile(r"^REPORTER\d+$")

    for section in config.sections():
        if not section_pattern.match(section):
            continue

        enabled = config.getboolean(section, "enabled", fallback=True)
        if not enabled:
            logger.info(
                f"Reporter [{config.get(section, 'name', fallback=section)}] is disabled, skipping"
            )
            continue

        module_path = config.get(section, "module", fallback=None)
        class_name = config.get(section, "class", fallback=None)

        if not module_path or not class_name:
            logger.error(
                f"Reporter [{section}] is missing 'module' or 'class' config keys, skipping"
            )
            continue

        try:
            module = importlib.import_module(module_path)
            reporter_class = getattr(module, class_name)
            reporter = reporter_class(logger, dict(config[section]))
            reporters.append(reporter)
            logger.info(f"Loaded reporter: {reporter.name} v{reporter.version}")
        except Exception:
            logger.error(f"Failed to load reporter [{section}] ({module_path}.{class_name})")
            logger.error(traceback.format_exc())

    return reporters


def shutdown(exit_code: int, logger: Logger):
    logger.detachFileHandler()
    logger.detachStreamHandler()
    sys.exit(exit_code)


def _printStartupBanner(logger: Logger, reporters):
    logger.logBanner("PYATF TEST RUNNER")
    logger.info(f"  Loader    : {Loader.name} v{Loader.version}")
    logger.info(f"  Runner    : {Runner.name} v{Runner.version}")
    if reporters:
        reporter_str = ", ".join(f"{r.name} v{r.version}" for r in reporters)
        logger.info(f"  Reporters : {reporter_str}")
    else:
        logger.info("  Reporters : none")
    logger.logHr()


def main(config_file: str = "/etc/vault88.conf"):
    args = parseArgs()

    # Stage 1 - setup logging
    logger = Logger()
    logger.setupLogger(args.log, args.verbose)

    if os.geteuid() == 0:
        logger.warning("Running vault88 as root is unsafe")

    # Stage 2 - load environment (optional)
    environment = None
    if args.env:
        try:
            if args.env.startswith("http://") or args.env.startswith("https://"):
                environment = ApiLoader(args.env).load()
            else:
                environment = JsonFileLoader(args.env).load()
            logger.info(f"Loaded environment: {environment.name}")
        except Exception:
            logger.error(f"Failed to load environment from: {args.env}")
            shutdown(1, logger)

    # Stage 3 - load config and reporters
    config = configparser.ConfigParser()
    config.read(os.path.expanduser(config_file))

    config_width = config.getint("CONSOLE", "width", fallback=None)
    logger.configure_console(config_width)

    reporters = _loadReporters(logger, config)
    if args.junit:
        reporters.append(JUnitReporter(logger, {}))

    _printStartupBanner(logger, reporters)

    # Stage 4 - discover tests
    loader = Loader(logger)
    selected_tests = loader.loadTests(
        args.testpath,
        args.tags or [],
        args.nottags or [],
        args.recursive or False,
    )

    if not selected_tests:
        logger.logBanner("TEST RUN COMPLETE - NO TESTS SELECTED")
        shutdown(1, logger)

    # Stage 5 - run tests and report
    had_exception = False
    had_failure = False
    summary_rows = []

    for test_class in selected_tests:
        test_name = test_class.name or test_class.__name__
        runner = Runner(logger, test_class, environment)
        test = runner.runTest()

        if test is None:
            logger.error(f"Runner failed to initialise {test_class.__name__}, skipping reporters")
            had_exception = True
            summary_rows.append((test_name, "not_run"))
            continue

        if runner.exception:
            logger.error(f"{test_class.__name__} encountered an exception during execution")
            had_exception = True
            summary_rows.append((test_name, "not_run"))
        elif any(
            result.outcome.value == "failed"
            for stage in test.stages
            for result in stage.results
        ):
            had_failure = True
            summary_rows.append((test_name, "failed"))
        else:
            summary_rows.append((test_name, "passed"))

        for reporter in reporters:
            if reporter.check(test):
                reporter.publish(test)

    logger.logSummary(summary_rows)

    if had_exception:
        logger.logBanner("TEST RUN COMPLETE - EXCEPTIONS ENCOUNTERED")
        shutdown(2, logger)
    elif had_failure:
        logger.logBanner("TEST RUN COMPLETE - FAILURES DETECTED")
        shutdown(1, logger)
    else:
        logger.logBanner("TEST RUN COMPLETE - ALL TESTS PASSED")
        shutdown(0, logger)
