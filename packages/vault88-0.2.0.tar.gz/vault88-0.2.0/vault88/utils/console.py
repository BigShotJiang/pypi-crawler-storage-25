"""Console display helper utilities"""

import re
import shutil
import textwrap
from typing import List, Optional

_DEFAULT_WIDTH = 80
_FIELD_INDENT = "    "  # 4-space indent for Expected/Actual/Reqs lines
_FIELD_INDENT_W = 4

_GREEN = "\033[32m"
_RED = "\033[31m"
_ORANGE = "\033[33m"
_RESET = "\033[0m"

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")


def get_console_width(config_width: Optional[int] = None) -> int:
    """Return console width from config, terminal detection, or default of 80."""
    if config_width is not None:
        return config_width
    try:
        cols = shutil.get_terminal_size().columns
        return cols if cols > 0 else _DEFAULT_WIDTH
    except Exception:
        return _DEFAULT_WIDTH


def strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def _visible_truncate(text: str, max_width: int) -> str:
    """Truncate text to max_width visible (non-ANSI) characters, appending … if cut."""
    if max_width <= 0:
        return ""
    if len(strip_ansi(text)) <= max_width:
        return text
    result = []
    visible = 0
    i = 0
    while i < len(text) and visible < max_width - 1:
        m = _ANSI_RE.match(text, i)
        if m:
            result.append(m.group())
            i = m.end()
            continue
        result.append(text[i])
        visible += 1
        i += 1
    return "".join(result) + "…"


def hr(width: int) -> str:
    return "─" * width


def banner(title: str, width: int) -> List[str]:
    return [title, hr(width)]


def _badge(outcome_val: str):
    """Return (colored_text, plain_text) for the outcome badge."""
    if outcome_val == "passed":
        return f"{_GREEN}[PASS]{_RESET}", "[PASS]"
    elif outcome_val == "failed":
        return f"{_RED}[FAIL]{_RESET}", "[FAIL]"
    else:
        return f"{_ORANGE}[----]{_RESET}", "[----]"


def _box_line(content: str, width: int) -> str:
    """Return a single bordered line: │ content(padded to width) │"""
    inner = width - 4  # │ + space + content + space + │
    display_len = len(strip_ansi(content))
    if display_len > inner:
        content = _visible_truncate(content, inner)
        display_len = len(strip_ansi(content))
    padding = max(0, inner - display_len)
    return "│ " + content + " " * padding + " │"


def stage_box_top(name: str, width: int) -> List[str]:
    """Return the opening lines of a stage box: top border, name, separator."""
    hr_inner = "─" * (width - 2)
    return [
        "┌" + hr_inner + "┐",
        _box_line(name, width),
        "├" + hr_inner + "┤",
    ]


def stage_box_bottom(width: int) -> str:
    """Return the closing border of a stage box."""
    return "└" + "─" * (width - 2) + "┘"


def result_box_lines(result, width: int) -> List[str]:
    """Format a Result as box-bordered lines inside a stage box.

    Layout per step:
      blank line
      action text (wraps at inner width)
          Expected: value
          Actual: value
          Reqs: req1, req2   (omitted when empty)
    The last line of each step ends with dot leaders and the pass/fail badge.
    """
    inner = width - 4  # content area between │ and │

    colored_badge, plain_badge = _badge(result.outcome.value)

    lines = [_box_line("", width)]

    for chunk in textwrap.wrap(result.action, width=inner) or [result.action]:
        lines.append(_box_line(chunk, width))

    field_lines: List[str] = []

    exp_label = "Expected: "
    exp_val_w = max(1, inner - _FIELD_INDENT_W - len(exp_label))
    for i, chunk in enumerate(textwrap.wrap(result.expected, width=exp_val_w) or [result.expected]):
        label = exp_label if i == 0 else " " * len(exp_label)
        field_lines.append(_FIELD_INDENT + label + chunk)

    act_label = "Actual: "
    act_val_w = max(1, inner - _FIELD_INDENT_W - len(act_label))
    for i, chunk in enumerate(textwrap.wrap(result.actual, width=act_val_w) or [result.actual]):
        label = act_label if i == 0 else " " * len(act_label)
        field_lines.append(_FIELD_INDENT + label + chunk)

    reqs_str = ", ".join(result.requirements) if result.requirements else ""
    if reqs_str:
        req_label = "Reqs: "
        req_val_w = max(1, inner - _FIELD_INDENT_W - len(req_label))
        for i, chunk in enumerate(textwrap.wrap(reqs_str, width=req_val_w) or [reqs_str]):
            label = req_label if i == 0 else " " * len(req_label)
            field_lines.append(_FIELD_INDENT + label + chunk)

    for field_line in field_lines[:-1]:
        lines.append(_box_line(field_line, width))

    if field_lines:
        last = field_lines[-1]
        last_display = len(strip_ansi(last))
        # Ensure last field text leaves room for " " + min-1-dot + " " + badge
        badge_overhead = len(plain_badge) + 3
        if last_display + badge_overhead > inner:
            last = _visible_truncate(last, max(0, inner - badge_overhead))
            last_display = len(strip_ansi(last))
        dots_count = max(1, inner - last_display - 2 - len(plain_badge))
        badged = last + " " + "." * dots_count + " " + colored_badge
        lines.append(_box_line(badged, width))

    return lines


def traceback_box_lines(tb: str, width: int) -> List[str]:
    """Format a traceback string as box-bordered lines inside a stage box."""
    inner = width - 4
    lines = [_box_line("", width)]
    for raw_line in tb.rstrip().splitlines():
        if len(raw_line) <= inner:
            lines.append(_box_line(raw_line, width))
        else:
            for chunk in textwrap.wrap(raw_line, width=inner) or [raw_line]:
                lines.append(_box_line(chunk, width))
    lines.append(_box_line("", width))
    return lines


def summary_table(rows: List[tuple], width: int) -> List[str]:
    """Format a summary table with dotted leaders."""
    section = "TEST EXECUTION SUMMARY "
    lines = ["", section + "─" * (width - len(section))]

    for name, outcome in rows:
        if outcome == "passed":
            status_plain, color = "PASSED", _GREEN
        elif outcome == "failed":
            status_plain, color = "FAILED", _RED
        else:
            status_plain, color = "NOT RUN", _ORANGE

        colored = f"{color}{status_plain}{_RESET}"
        max_name = width - 2 - 2 - len(status_plain) - 3
        name_str = name[:max_name] if len(name) > max_name else name
        dots = "." * max(3, width - 2 - len(name_str) - 2 - len(status_plain))
        lines.append(f"  {name_str} {dots} {colored}")

    return lines
