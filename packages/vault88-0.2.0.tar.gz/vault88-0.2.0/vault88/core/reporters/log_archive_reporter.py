"""Log Archive Reporter"""

import os
import zipfile
from datetime import datetime, timezone

from vault88.core.reporter import Reporter


class LogArchiveReporter(Reporter):
    name = "Log Archive Reporter"
    version = "1.0.0"

    def check(self, test) -> bool:
        log_dir = getattr(test, "log_dir", None)
        return bool(log_dir and os.path.isdir(log_dir) and os.listdir(log_dir))

    def publish(self, test) -> None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        safe_name = test.name.replace(" ", "_")
        zip_name = f"{safe_name}_{timestamp}.zip"
        output_path = os.path.join(self.config.get("output_dir", os.getcwd()), zip_name)

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for entry in os.scandir(test.log_dir):
                if entry.is_file():
                    zf.write(entry.path, arcname=entry.name)

        self.logger.info(f"Log archive written to {output_path}")
