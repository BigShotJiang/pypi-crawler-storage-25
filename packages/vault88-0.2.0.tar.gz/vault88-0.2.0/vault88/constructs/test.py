"""Test base class"""

from abc import ABC, abstractmethod
from typing import ClassVar, List, Optional

from vault88.constructs.result import Result, ResultOutcome
from vault88.constructs.stage import Stage


class Test(ABC):
    name: ClassVar[str] = ""
    version: ClassVar[str] = ""
    tags: ClassVar[List[str]] = []

    def __init__(self, logger, log_dir: str, environment=None):
        self.logger = logger
        self.log_dir = log_dir
        self.environment = environment
        self.stages: List[Stage] = []
        self._current_stage: Optional[Stage] = None

    # ------------------------------------------------------------------
    # Abstract lifecycle methods
    # ------------------------------------------------------------------

    @abstractmethod
    def selfCheck(self) -> bool: ...

    @abstractmethod
    def setup(self) -> bool: ...

    @abstractmethod
    def run(self) -> None: ...

    @abstractmethod
    def teardown(self) -> None: ...

    # ------------------------------------------------------------------
    # Stage and result tracking
    # ------------------------------------------------------------------

    def newStage(self, name: str) -> None:
        stage = Stage(name)
        self.stages.append(stage)
        self._current_stage = stage
        self.logger.logStage(name)

    def _ensureStage(self) -> None:
        if self._current_stage is None:
            self.newStage("Unnamed Stage")

    def addResult(
        self,
        action: str,
        expected: str,
        actual: str,
        outcome: ResultOutcome,
        requirements: Optional[List[str]] = None,
    ) -> None:
        self._ensureStage()
        result = Result(action, expected, actual, outcome, requirements)
        self._current_stage.addResult(result)
        self.logger.logResult(result)

    # ------------------------------------------------------------------
    # Assertion helpers
    # ------------------------------------------------------------------

    def assertEqual(
        self, action: str, expected, actual, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if expected == actual else ResultOutcome.FAILED
        self.addResult(action, repr(expected), repr(actual), outcome, requirements)

    def assertNotEqual(
        self, action: str, expected, actual, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if expected != actual else ResultOutcome.FAILED
        self.addResult(action, f"not {repr(expected)}", repr(actual), outcome, requirements)

    def assertTrue(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        outcome = ResultOutcome.PASSED if value else ResultOutcome.FAILED
        self.addResult(action, "truthy", repr(value), outcome, requirements)

    def assertFalse(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        outcome = ResultOutcome.PASSED if not value else ResultOutcome.FAILED
        self.addResult(action, "falsy", repr(value), outcome, requirements)

    def assertGreaterThan(
        self, action: str, value, threshold, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if value > threshold else ResultOutcome.FAILED
        self.addResult(action, f"> {threshold}", repr(value), outcome, requirements)

    def assertLessThan(
        self, action: str, value, threshold, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if value < threshold else ResultOutcome.FAILED
        self.addResult(action, f"< {threshold}", repr(value), outcome, requirements)

    def assertGreaterThanOrEqual(
        self, action: str, value, threshold, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if value >= threshold else ResultOutcome.FAILED
        self.addResult(action, f">= {threshold}", repr(value), outcome, requirements)

    def assertLessThanOrEqual(
        self, action: str, value, threshold, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if value <= threshold else ResultOutcome.FAILED
        self.addResult(action, f"<= {threshold}", repr(value), outcome, requirements)

    def assertIn(
        self, action: str, item, container, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if item in container else ResultOutcome.FAILED
        self.addResult(action, f"{repr(item)} in container", repr(container), outcome, requirements)

    def assertNotIn(
        self, action: str, item, container, requirements: Optional[List[str]] = None
    ) -> None:
        outcome = ResultOutcome.PASSED if item not in container else ResultOutcome.FAILED
        self.addResult(
            action,
            f"{repr(item)} not in container",
            repr(container),
            outcome,
            requirements,
        )

    def assertIsNone(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        outcome = ResultOutcome.PASSED if value is None else ResultOutcome.FAILED
        self.addResult(action, "None", repr(value), outcome, requirements)

    def assertIsNotNone(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        outcome = ResultOutcome.PASSED if value is not None else ResultOutcome.FAILED
        self.addResult(action, "not None", repr(value), outcome, requirements)
