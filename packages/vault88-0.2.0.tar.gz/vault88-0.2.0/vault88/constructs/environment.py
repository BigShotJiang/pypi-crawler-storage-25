"""Environment constructs"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Credential:
    username: str
    password: Optional[str] = None
    key_path: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> Credential:
        return cls(
            username=data["username"],
            password=data.get("password"),
            key_path=data.get("key_path"),
        )


@dataclass
class Service:
    name: str
    port: Optional[int] = None
    url: Optional[str] = None
    credential: Optional[Credential] = None

    @classmethod
    def from_dict(cls, data: dict) -> Service:
        cred_data = data.get("credential")
        return cls(
            name=data["name"],
            port=data.get("port"),
            url=data.get("url"),
            credential=Credential.from_dict(cred_data) if cred_data else None,
        )


@dataclass
class Host:
    name: str
    address: str
    services: List[Service] = field(default_factory=list)
    credential: Optional[Credential] = None

    @classmethod
    def from_dict(cls, data: dict) -> Host:
        cred_data = data.get("credential")
        return cls(
            name=data["name"],
            address=data["address"],
            services=[Service.from_dict(s) for s in data.get("services", [])],
            credential=Credential.from_dict(cred_data) if cred_data else None,
        )


@dataclass
class Environment:
    name: str
    hosts: List[Host] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> Environment:
        return cls(
            name=data["name"],
            hosts=[Host.from_dict(h) for h in data.get("hosts", [])],
        )
