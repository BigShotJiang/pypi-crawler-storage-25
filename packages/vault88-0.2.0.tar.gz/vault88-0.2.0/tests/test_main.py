"""Tests for main.py helper functions (_loadReporters, shutdown)"""

import configparser
from unittest.mock import MagicMock, patch

import pytest

from vault88.constructs.result import Result, ResultOutcome
from vault88.constructs.stage import Stage
from vault88.constructs.test import Test
from vault88.core.logger import Logger
from vault88.main import _loadReporters, main, shutdown


@pytest.fixture
def logger(tmp_path):
    log = Logger()
    log.setupLogger(str(tmp_path / "vault88.log"))
    yield log
    log.detachFileHandler()
    log.detachStreamHandler()


def _make_config(sections: dict) -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    for section, values in sections.items():
        config[section] = values
    return config


class TestLoadReporters:
    def test_empty_config_returns_empty_list(self, logger):
        config = _make_config({})
        assert _loadReporters(logger, config) == []

    def test_non_reporter_section_is_ignored(self, logger):
        config = _make_config({"SETTINGS": {"key": "value"}})
        assert _loadReporters(logger, config) == []

    def test_disabled_reporter_is_skipped(self, logger):
        config = _make_config({"REPORTER1": {"enabled": "false", "name": "Noop"}})
        assert _loadReporters(logger, config) == []

    def test_reporter_missing_module_is_skipped(self, logger):
        config = _make_config({"REPORTER1": {"class": "MyReporter"}})
        assert _loadReporters(logger, config) == []

    def test_reporter_missing_class_is_skipped(self, logger):
        config = _make_config({"REPORTER1": {"module": "some.module"}})
        assert _loadReporters(logger, config) == []

    def test_reporter_with_invalid_module_logs_error_and_continues(self, logger):
        config = _make_config(
            {
                "REPORTER1": {"module": "nonexistent.module.xyz", "class": "MyClass"},
            }
        )
        result = _loadReporters(logger, config)
        assert result == []

    def test_valid_reporter_is_loaded(self, logger):
        fake_reporter = MagicMock()
        fake_reporter.name = "FakeReporter"
        fake_reporter.version = "1.0"
        fake_class = MagicMock(return_value=fake_reporter)
        fake_module = MagicMock()
        fake_module.MyReporter = fake_class

        config = _make_config(
            {
                "REPORTER1": {"module": "fake.module", "class": "MyReporter"},
            }
        )

        with patch("importlib.import_module", return_value=fake_module):
            result = _loadReporters(logger, config)

        assert len(result) == 1
        assert result[0] is fake_reporter

    def test_multiple_reporters_loaded_in_order(self, logger):
        fake1 = MagicMock(name="r1", version="1.0")
        fake2 = MagicMock(name="r2", version="1.0")

        def fake_import(module_path):
            mod = MagicMock()
            mod.R = MagicMock(return_value=fake1 if "mod1" in module_path else fake2)
            return mod

        config = _make_config(
            {
                "REPORTER1": {"module": "mod1", "class": "R"},
                "REPORTER2": {"module": "mod2", "class": "R"},
            }
        )

        with patch("importlib.import_module", side_effect=fake_import):
            result = _loadReporters(logger, config)

        assert len(result) == 2


class TestShutdown:
    def test_shutdown_calls_sys_exit_with_code(self, logger):
        with patch("sys.exit") as mock_exit:
            shutdown(0, logger)
        mock_exit.assert_called_once_with(0)

    def test_shutdown_nonzero_exit_code(self, logger):
        with patch("sys.exit") as mock_exit:
            shutdown(1, logger)
        mock_exit.assert_called_once_with(1)


def _make_test_with_outcomes(*outcomes: ResultOutcome):
    """Build a minimal Test-like object with stages containing the given result outcomes."""
    stage = Stage("test stage")
    for outcome in outcomes:
        stage.addResult(Result("action", "expected", "actual", outcome))
    test = MagicMock(spec=Test)
    test.stages = [stage]
    return test


def _make_args(**kwargs):
    defaults = dict(
        log="/dev/null",
        verbose=False,
        env=None,
        junit=False,
        tags=[],
        nottags=[],
        recursive=False,
        testpath=".",
    )
    defaults.update(kwargs)
    return MagicMock(**defaults)


class TestMainExitCodes:
    """Verify main() exits with 0 (pass), 1 (failure), or 2 (exception)."""

    def _run_main(self, runners):
        """runners: list of (runner_exception, test_obj) tuples, one per test class."""
        runner_mocks = []
        for exception, test_obj in runners:
            m = MagicMock()
            m.exception = exception
            m.runTest.return_value = test_obj
            runner_mocks.append(m)

        fake_test_classes = []
        for i in range(len(runners)):
            tc = MagicMock()
            tc.__name__ = f"FakeTest{i}"
            fake_test_classes.append(tc)

        with (
            patch("vault88.main.parseArgs", return_value=_make_args()),
            patch("vault88.main.Logger"),
            patch("vault88.main.Loader") as mock_loader_cls,
            patch("vault88.main.Runner", side_effect=runner_mocks),
            patch("vault88.main.configparser.ConfigParser"),
            patch("sys.exit") as mock_exit,
        ):
            mock_loader_cls.return_value.loadTests.return_value = fake_test_classes
            try:
                main()
            except SystemExit:
                pass
            return mock_exit.call_args[0][0]

    def test_all_pass_exits_zero(self):
        test = _make_test_with_outcomes(ResultOutcome.PASSED, ResultOutcome.PASSED)
        assert self._run_main([(False, test)]) == 0

    def test_one_failed_result_exits_one(self):
        test = _make_test_with_outcomes(ResultOutcome.PASSED, ResultOutcome.FAILED)
        assert self._run_main([(False, test)]) == 1

    def test_all_failed_results_exits_one(self):
        test = _make_test_with_outcomes(ResultOutcome.FAILED, ResultOutcome.FAILED)
        assert self._run_main([(False, test)]) == 1

    def test_exception_exits_two(self):
        test = _make_test_with_outcomes(ResultOutcome.PASSED)
        assert self._run_main([(True, test)]) == 2

    def test_exception_takes_precedence_over_failure(self):
        test = _make_test_with_outcomes(ResultOutcome.FAILED)
        assert self._run_main([(True, test)]) == 2

    def test_runner_returns_none_exits_two(self):
        assert self._run_main([(False, None)]) == 2

    def test_multiple_tests_all_pass_exits_zero(self):
        passing = _make_test_with_outcomes(ResultOutcome.PASSED)
        assert self._run_main([(False, passing), (False, passing)]) == 0

    def test_multiple_tests_one_fails_exits_one(self):
        passing = _make_test_with_outcomes(ResultOutcome.PASSED)
        failing = _make_test_with_outcomes(ResultOutcome.FAILED)
        assert self._run_main([(False, passing), (False, failing)]) == 1

    def test_multiple_tests_exception_in_one_exits_two(self):
        passing = _make_test_with_outcomes(ResultOutcome.PASSED)
        assert self._run_main([(False, passing), (True, passing)]) == 2
