"""Tests for environment dataclasses and their from_dict constructors"""

from vault88.constructs.environment import Credential, Environment, Host, Service


class TestCredential:
    def test_username_only(self):
        c = Credential.from_dict({"username": "alice"})
        assert c.username == "alice"
        assert c.password is None
        assert c.key_path is None

    def test_with_password_and_key_path(self):
        c = Credential.from_dict({"username": "bob", "password": "s3cr3t", "key_path": "/id_rsa"})
        assert c.password == "s3cr3t"
        assert c.key_path == "/id_rsa"


class TestService:
    def test_minimal(self):
        s = Service.from_dict({"name": "http"})
        assert s.name == "http"
        assert s.port is None
        assert s.url is None
        assert s.credential is None

    def test_with_port_url_and_credential(self):
        s = Service.from_dict(
            {
                "name": "api",
                "port": 8080,
                "url": "http://localhost:8080",
                "credential": {"username": "admin"},
            }
        )
        assert s.port == 8080
        assert s.url == "http://localhost:8080"
        assert s.credential is not None
        assert s.credential.username == "admin"


class TestHost:
    def test_minimal(self):
        h = Host.from_dict({"name": "server", "address": "10.0.0.1"})
        assert h.name == "server"
        assert h.address == "10.0.0.1"
        assert h.services == []
        assert h.credential is None

    def test_with_services_and_credential(self):
        h = Host.from_dict(
            {
                "name": "server",
                "address": "10.0.0.1",
                "services": [{"name": "ssh", "port": 22}],
                "credential": {"username": "root"},
            }
        )
        assert len(h.services) == 1
        assert h.services[0].name == "ssh"
        assert h.credential.username == "root"


class TestEnvironment:
    def test_minimal(self):
        e = Environment.from_dict({"name": "staging"})
        assert e.name == "staging"
        assert e.hosts == []

    def test_with_hosts(self):
        e = Environment.from_dict(
            {
                "name": "prod",
                "hosts": [
                    {"name": "web1", "address": "192.168.0.1"},
                    {"name": "db1", "address": "192.168.0.2"},
                ],
            }
        )
        assert len(e.hosts) == 2
        assert e.hosts[0].name == "web1"
        assert e.hosts[1].name == "db1"
