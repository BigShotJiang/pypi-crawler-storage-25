"""Tests for console.py truncation and overflow guards"""

from vault88.constructs.result import Result, ResultOutcome
from vault88.utils.console import (
    _box_line,
    _visible_truncate,
    result_box_lines,
    strip_ansi,
)

_GREEN = "\033[32m"
_RESET = "\033[0m"
_WIDTH = 80


def _result(
    action="act", expected="exp", actual="act", outcome=ResultOutcome.PASSED, requirements=None
):
    return Result(action, expected, actual, outcome, requirements or [])


def _display_width(line: str) -> int:
    return len(strip_ansi(line))


class TestVisibleTruncate:
    def test_zero_width_returns_empty(self):
        assert _visible_truncate("hello", 0) == ""

    def test_negative_width_returns_empty(self):
        assert _visible_truncate("hello", -5) == ""

    def test_text_shorter_than_max_unchanged(self):
        assert _visible_truncate("hi", 10) == "hi"

    def test_text_exactly_at_max_unchanged(self):
        assert _visible_truncate("hello", 5) == "hello"

    def test_plain_text_truncated_with_ellipsis(self):
        result = _visible_truncate("abcdef", 4)
        assert result == "abc…"

    def test_truncated_visible_length_equals_max_width(self):
        result = _visible_truncate("abcdefghij", 6)
        assert len(strip_ansi(result)) == 6

    def test_ansi_codes_not_counted_toward_width(self):
        colored = f"{_GREEN}hello{_RESET}"
        result = _visible_truncate(colored, 5)
        assert strip_ansi(result) == "hello"

    def test_ansi_codes_preserved_before_cut_point(self):
        colored = f"{_GREEN}abcdef{_RESET}"
        result = _visible_truncate(colored, 4)
        assert strip_ansi(result) == "abc…"
        assert _GREEN in result

    def test_ansi_colored_truncated_visible_length_matches_max_width(self):
        colored = f"{_GREEN}abcdefghij{_RESET}"
        result = _visible_truncate(colored, 6)
        assert len(strip_ansi(result)) == 6


class TestBoxLine:
    def test_short_content_pads_to_box_width(self):
        assert _display_width(_box_line("hi", 20)) == 20

    def test_empty_content_pads_to_box_width(self):
        assert _display_width(_box_line("", 20)) == 20

    def test_content_fills_inner_exactly(self):
        inner = 20 - 4
        assert _display_width(_box_line("x" * inner, 20)) == 20

    def test_content_exceeding_inner_truncated_to_box_width(self):
        assert _display_width(_box_line("x" * 200, 20)) == 20

    def test_truncated_line_contains_ellipsis(self):
        assert "…" in _box_line("x" * 200, 20)

    def test_truncated_line_has_right_border(self):
        assert _box_line("x" * 200, 20).endswith("│")

    def test_all_lines_start_with_left_border(self):
        for content in ("", "short", "x" * 200):
            assert _box_line(content, 40).startswith("│")

    def test_ansi_content_exceeding_inner_truncated_to_box_width(self):
        content = f"{_GREEN}" + "x" * 100 + f"{_RESET}"
        assert _display_width(_box_line(content, 20)) == 20


class TestResultBoxLinesOverflow:
    def _badge_in(self, lines, badge="[PASS]"):
        return any(badge in strip_ansi(line) for line in lines)

    def _all_widths(self, lines):
        return [_display_width(line) for line in lines]

    def test_normal_result_all_lines_fit_exactly(self):
        lines = result_box_lines(_result(), _WIDTH)
        assert all(w == _WIDTH for w in self._all_widths(lines))

    def test_pass_badge_present(self):
        lines = result_box_lines(_result(outcome=ResultOutcome.PASSED), _WIDTH)
        assert self._badge_in(lines, "[PASS]")

    def test_fail_badge_present(self):
        lines = result_box_lines(_result(outcome=ResultOutcome.FAILED), _WIDTH)
        assert self._badge_in(lines, "[FAIL]")

    def test_long_action_all_lines_fit(self):
        lines = result_box_lines(_result(action="A" * 300), _WIDTH)
        assert all(w == _WIDTH for w in self._all_widths(lines))

    def test_long_expected_all_lines_fit(self):
        lines = result_box_lines(_result(expected="E" * 300), _WIDTH)
        assert all(w == _WIDTH for w in self._all_widths(lines))

    def test_long_actual_all_lines_fit(self):
        lines = result_box_lines(_result(actual="A" * 300), _WIDTH)
        assert all(w == _WIDTH for w in self._all_widths(lines))

    def test_long_requirements_all_lines_fit(self):
        reqs = ["REQ-" + str(i) for i in range(50)]
        lines = result_box_lines(_result(requirements=reqs), _WIDTH)
        assert all(w == _WIDTH for w in self._all_widths(lines))

    def test_badge_present_with_all_fields_long(self):
        r = _result(
            action="ACT" * 100,
            expected="EXP" * 100,
            actual="ACT" * 100,
            requirements=["REQ-" + str(i) for i in range(30)],
        )
        lines = result_box_lines(r, _WIDTH)
        assert self._badge_in(lines, "[PASS]")
        assert all(w == _WIDTH for w in self._all_widths(lines))

    def test_narrow_width_all_lines_fit(self):
        lines = result_box_lines(_result(), 20)
        assert all(w == 20 for w in self._all_widths(lines))

    def test_narrow_width_badge_present(self):
        lines = result_box_lines(_result(outcome=ResultOutcome.PASSED), 20)
        assert self._badge_in(lines, "[PASS]")

    def test_last_field_line_too_long_badge_still_present(self):
        # Actual is the last field with no reqs; its last wrapped chunk will be
        # artificially wide enough to trigger the badge-overflow guard.
        r = _result(actual="X" * 300)
        lines = result_box_lines(r, _WIDTH)
        assert self._badge_in(lines, "[PASS]")
        assert all(w == _WIDTH for w in self._all_widths(lines))

    def test_long_reqs_last_line_badge_still_present(self):
        r = _result(requirements=["REQ-" + "X" * 60])
        lines = result_box_lines(r, _WIDTH)
        assert self._badge_in(lines, "[PASS]")
        assert all(w == _WIDTH for w in self._all_widths(lines))
