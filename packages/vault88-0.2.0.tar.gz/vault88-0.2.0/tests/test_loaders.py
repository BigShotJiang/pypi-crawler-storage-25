"""Tests for environment loaders (JSON file and API)"""

import json
from unittest.mock import MagicMock, patch

from vault88.core.environment_loaders.api_loader import ApiLoader
from vault88.core.environment_loaders.json_file_loader import JsonFileLoader


class TestJsonFileLoader:
    def test_load_minimal_environment(self, tmp_path):
        data = {"name": "test-env"}
        f = tmp_path / "env.json"
        f.write_text(json.dumps(data))
        env = JsonFileLoader(str(f)).load()
        assert env.name == "test-env"
        assert env.hosts == []

    def test_load_environment_with_hosts(self, tmp_path):
        data = {
            "name": "staging",
            "hosts": [{"name": "h1", "address": "1.2.3.4"}],
        }
        f = tmp_path / "env.json"
        f.write_text(json.dumps(data))
        env = JsonFileLoader(str(f)).load()
        assert len(env.hosts) == 1
        assert env.hosts[0].name == "h1"


class TestApiLoader:
    def _mock_urlopen(self, payload: dict):
        body = json.dumps(payload).encode()
        response = MagicMock()
        response.read.return_value = body
        response.__enter__ = lambda s: s
        response.__exit__ = MagicMock(return_value=False)
        return response

    def test_load_minimal_environment(self):
        mock_resp = self._mock_urlopen({"name": "remote-env"})
        with patch("urllib.request.urlopen", return_value=mock_resp):
            env = ApiLoader("http://example.com/env").load()
        assert env.name == "remote-env"
        assert env.hosts == []

    def test_load_environment_with_hosts(self):
        mock_resp = self._mock_urlopen(
            {
                "name": "prod",
                "hosts": [{"name": "srv", "address": "10.0.0.1"}],
            }
        )
        with patch("urllib.request.urlopen", return_value=mock_resp):
            env = ApiLoader("http://example.com/env").load()
        assert len(env.hosts) == 1
