# FedComp Index Data

![FedComp Index](https://fedcompindex.org/static/img/FedComp-Index-Tabularium-3.png)

Pre-classified federal contractor datasets bundled for Python. Each contractor has a Posture Class (1-4) assigned by two-axis classification (total contract dollars x base contract count) from five years of USASpending award data.

Updated monthly with fresh data from the FedComp Index pipeline.

## Install

```bash
pip install fedcomp-index-data
```

## Usage

```python
from fedcomp_index_data import load_state, lookup

# Load all classified contractors for a state
contractors = load_state("NV")
print(f"{len(contractors)} contractors classified")

# Filter by posture class
class_1 = [c for c in contractors if c["posture_class"] == "Class 1"]
print(f"{len(class_1)} Class 1 contractors")

# Look up a specific contractor by UEI
c = lookup("CGAKREGGN9J3")
print(c["legal_name"])      # FLEET VEHICLE SOURCE INC
print(c["posture_class"])   # Class 1
```

## Available states

| State | Contractors | Updated |
|-------|-------------|---------|
| Nevada (NV) | 348 | March 2026 |

More states are added as the FedComp Index expands coverage.

## Data fields

| Field | Description |
|-------|-------------|
| `rank` | Rank within the state (by total contract dollars) |
| `legal_name` | Registered legal name from SAM.gov |
| `uei` | Unique Entity Identifier |
| `cage` | CAGE code |
| `posture_class` | Posture Class: 1, 2, 3, or 4 (two-axis classification) |
| `total_dollars_5yr` | Total contract dollars (base + delivery orders) over trailing 5-year window |
| `base_contract_count` | Number of distinct base contracts |
| `award_count` | Total award count (including delivery/task orders) |
| `active_contracts` | Currently active contracts |
| `last_award_date` | Date of most recent award (YYYY-MM) |
| `primary_naics` | Primary NAICS code |
| `top_agency` | Most frequent awarding agency |
| `city` | Registered city |
| `certifications` | SBA certifications (pipe-separated) |
| `state` | State of registration |
| `scored_date` | Year-month this classification was computed |

## Classification methodology (v1.1)

Two axes, no composite score, no weighted sum:

| Axis | Threshold | What it measures |
|------|-----------|-----------------|
| Total contract dollars (5yr) | $5M | Volume of all obligated dollars (base + delivery orders) |
| Base contract count (5yr) | 3 | Frequency of distinct base contract wins |

| Posture Class | Volume | Frequency | Profile |
|---------------|--------|-----------|---------|
| Class 1 | $5M+ | 3+ contracts | Systematic winner |
| Class 2 | $5M+ | <3 contracts | Concentrated risk |
| Class 3 | <$5M | 3+ contracts | Growth pipeline |
| Class 4 | <$5M | <3 contracts | Entry level |

Full methodology: [fedcompindex.org/methodology](https://fedcompindex.org/methodology/)

## Related packages

- [fedcomp-index-scoring](https://pypi.org/project/fedcomp-index-scoring/) - classification engine
- [fedcomp-index](https://pypi.org/project/fedcomp-index/) - meta-package

## Data sources

- [USASpending.gov](https://www.usaspending.gov/) - award history
- [SAM.gov](https://sam.gov/) - entity registration
- [SBA.gov](https://www.sba.gov/) - certification verification

## Also available on npm

```bash
npm install fedcomp-index-data
```

- [fedcomp-index](https://www.npmjs.com/package/fedcomp-index) - meta-package
- [fedcomp-index-scoring](https://www.npmjs.com/package/fedcomp-index-scoring) - classification engine
- [fedcomp-index-data](https://www.npmjs.com/package/fedcomp-index-data) - pre-classified datasets

## Links

- Website: [https://fedcompindex.org/](https://fedcompindex.org/)
- Nevada Rankings: [https://fedcompindex.org/nv/](https://fedcompindex.org/nv/)
- Methodology: [https://fedcompindex.org/methodology/](https://fedcompindex.org/methodology/)
- Tabularium: [https://fedcompindex.org/tabularium/](https://fedcompindex.org/tabularium/)
- FAQ: [https://fedcompindex.org/faq/](https://fedcompindex.org/faq/)
- Source: [https://github.com/fedcompindex/FedCompIndex](https://github.com/fedcompindex/FedCompIndex)
- PyPI: [https://pypi.org/project/fedcomp-index/](https://pypi.org/project/fedcomp-index/)
- PyPI (Scoring): [https://pypi.org/project/fedcomp-index-scoring/](https://pypi.org/project/fedcomp-index-scoring/)
- PyPI (Data): [https://pypi.org/project/fedcomp-index-data/](https://pypi.org/project/fedcomp-index-data/)
- HuggingFace: [https://huggingface.co/datasets/npetro6/nevada-federal-contractors](https://huggingface.co/datasets/npetro6/nevada-federal-contractors)
- Kaggle: [https://www.kaggle.com/datasets/npetro6/nevada-federal-contractors-fedcomp-index](https://www.kaggle.com/datasets/npetro6/nevada-federal-contractors-fedcomp-index)

## License

MIT
