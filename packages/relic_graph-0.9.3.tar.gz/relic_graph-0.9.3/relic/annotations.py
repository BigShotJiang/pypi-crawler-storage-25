"""Annotations — per-file constraint memory that survives context compaction.

Agents discover non-obvious constraints while working (e.g. "this function's
signature is frozen", "this flag is intentional, do not fix"). Without a
persistent store these are re-discovered every session. Annotations attach
constraints directly to file paths so they surface automatically in every
future relic_query for that file.

Two scopes:
  permanent  — codebase invariant; survives checkpoint close indefinitely.
  task       — relevant only for the current task; cleaned up on checkpoint close.

Storage: .knowledge/annotations.toon
Format: pipe-separated rows, rendered as TOON for agent consumption.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path

KNOWLEDGE_DIR = Path(".knowledge")
_ANNOTATIONS_FILE = KNOWLEDGE_DIR / "annotations.toon"

_SEP = " | "


def _load_raw() -> list[dict]:
    if not _ANNOTATIONS_FILE.exists():
        return []
    entries: list[dict] = []
    for raw in _ANNOTATIONS_FILE.read_text(encoding="utf-8").splitlines():
        if not raw.startswith("  "):
            continue
        parts = [p.strip() for p in raw.strip().split(_SEP.strip())]
        if len(parts) >= 4:
            entries.append(
                {
                    "file": parts[0],
                    "scope": parts[1],
                    "rule": parts[2],
                    "added": parts[3],
                }
            )
    return entries


def _save_raw(entries: list[dict]) -> None:
    KNOWLEDGE_DIR.mkdir(exist_ok=True)
    if not entries:
        if _ANNOTATIONS_FILE.exists():
            _ANNOTATIONS_FILE.unlink()
        return
    lines = [f"annotations[{len(entries)}]{{file,scope,rule,added}}:"]
    for e in entries:
        lines.append(f"  {e['file']}{_SEP}{e['scope']}{_SEP}{e['rule']}{_SEP}{e['added']}")
    _ANNOTATIONS_FILE.write_text("\n".join(lines), encoding="utf-8")


def _norm(path: str) -> str:
    """Normalise to POSIX relative path — strip leading ./ or /."""
    p = path.strip()
    if p.startswith("./"):
        p = p[2:]
    elif p.startswith("/"):
        p = p.lstrip("/")
    return p or path.strip()


def add_annotation(file: str, rule: str, *, permanent: bool = False) -> None:
    """Add an annotation for a file. Deduplicates by (file, rule)."""
    entries = _load_raw()
    file = _norm(file)
    scope = "permanent" if permanent else "task"
    key = (file, rule)
    if any((e["file"], e["rule"]) == key for e in entries):
        return
    entries.append({"file": file, "scope": scope, "rule": rule, "added": date.today().isoformat()})
    _save_raw(entries)


def get_annotations(file: str) -> list[dict]:
    """Return all annotations for a file path."""
    file = _norm(file)
    return [e for e in _load_raw() if _norm(e["file"]) == file]


def delete_annotation(file: str, rule: str) -> bool:
    """Delete a specific annotation by (file, rule). Returns True if found and removed."""
    file = _norm(file)
    entries = _load_raw()
    kept = [e for e in entries if not (_norm(e["file"]) == file and e["rule"] == rule)]
    if len(kept) == len(entries):
        return False
    _save_raw(kept)
    return True


def delete_task_annotations() -> int:
    """Remove all task-scoped annotations. Called by checkpoint close. Returns count removed."""
    entries = _load_raw()
    kept = [e for e in entries if e["scope"] == "permanent"]
    removed = len(entries) - len(kept)
    _save_raw(kept)
    return removed


def list_annotations(file: str | None = None) -> list[dict]:
    """List annotations, optionally filtered by file."""
    entries = _load_raw()
    return [e for e in entries if file is None or e["file"] == file]


def annotations_to_toon(file: str) -> str | None:
    """Render annotations for a file as a TOON snippet. None if none exist."""
    anns = get_annotations(file)
    if not anns:
        return None
    lines = [f"annotations[{len(anns)}]{{scope,rule,added}}:"]
    for a in anns:
        lines.append(f"  {a['scope']},{a['rule']},{a['added']}")
    return "\n".join(lines)
