"""Agent config writer — injects relic instructions and MCP config for coding agents.

Each agent reads a different config file at session start. This module writes the
relic behaviour block and MCP server registration into the right files.

MCP config paths per agent:
  Claude Code  — .claude/settings.json       (mcpServers key)
  Cursor       — .cursor/mcp.json            (mcpServers key)
  Copilot      — .vscode/mcp.json            (servers key, VS Code 1.99+)
  Codex        — instructions only (no standard MCP config file)
"""

import json
from pathlib import Path

import yaml
from rich.console import Console

console = Console()

RELIC_BLOCK_START = "<!-- relic:start -->"
RELIC_BLOCK_END = "<!-- relic:end -->"

# Token replaced with a real project file path at init time.
# Using a sentinel (not str.format) so curly braces inside the TOON example
# don't have to be escaped.
RELIC_EXAMPLE_PLACEHOLDER = "__RELIC_EXAMPLE_FILE__"

RELIC_INSTRUCTIONS = """\
## Relic — Codebase Knowledge Graph

Relic exposes a static knowledge graph of this repository via MCP tools.
Ground every edit in real dependency information instead of guessing or
re-reading files. Typical query is 300–1,200 tokens vs 5,000–40,000 for
manual file reads.

### Rules

- MUST call `relic_session_start` at the start of every new conversation.
- MUST call `relic_query <path>` before edits when ANY of:
    (a) the file has > 5 callers (check `imported_by` count in TOON output), OR
    (b) the file is > 1,500 tokens (~6 KB) on disk — `cost{focus_file_tokens}` tells you, OR
    (c) you have not loaded the file this session and the task is non-trivial.
- MUST call `relic_reindex` whenever the response header reports `stale=true`, or after you create, delete, or move files.
- MUST call `relic_checkpoint close` when a PR is merged or task is abandoned.
- MUST call `relic_checkpoint save task=<name>` after completing each file in `in_progress` — do not wait until session end.
- SHOULD call `relic_query <symbol>` before introducing a new import or call site for a symbol whose definition you have not seen.
- SHOULD call `relic_search <name>` instead of grep / file listings when you do not know where something lives.
- SHOULD call `relic_annotate` when you re-read a section twice to understand it — that confusion is the signal. Use `permanent=true` for codebase invariants.
- SKIP `relic_query` for small, isolated files (< 200 tokens, 0 callers) you would read in full anyway.
- DO NOT call any "stats" tool — every response carries `index{age_s,stale,files_changed}` and `cost{response_tokens,focus_file_tokens}` headers.

### Decision tree

Starting a new conversation or resuming after context compaction
    → `relic_session_start`.

About to edit a file you have not loaded this session
    → `relic_query <path>` first, then read only the symbols you actually need.

Need to call or import a symbol whose definition you have not seen
    → `relic_query <symbol>`.
    If the response is `ambiguous: ... matches N symbols`, re-query with the full file path.

You don't know where something lives
    → `relic_search <name>` (use `kind=symbol` or `kind=file` to narrow,
      `subproject=<name>` in monorepos).

About to rename a symbol or change a widely-used interface
    → `relic_query "impact:<symbol>"` — every file that will break.

Need the shortest link between two files or symbols
    → `relic_query "A->B"`.

Response header says `stale=true`, or you just created / deleted / moved a file
    → `relic_reindex`. (No need to call this proactively if `stale=false`.)

You re-read a section twice to understand it
    → `relic_annotate file=<path> rule=<text>` — that confusion is the signal.
    Use `permanent=true` for codebase invariants (frozen signatures, intentional quirks).

### Example call

Try this on a real file in this project to see the output format:

```
relic_query __RELIC_EXAMPLE_FILE__
```

### Reading TOON output

```
index{age_s,stale,files_changed}: 12,false,0
cost{response_tokens,focus_file_tokens}: 847,312

focus: src/payments/processor.py

neighbors[3]{path,language,subproject}:
  src/payments/models.py,python,payments
  src/core/database.py,python,core

exports[5]{name,type,line,signature,intent}:
  PaymentProcessor,class,12,PaymentProcessor,Handles payment authorization and capture
  process_payment,function,45,process_payment(order: Order) -> Receipt,Authorize card and emit receipt

imports[2]{from,to}:
  src/payments/processor.py,src/payments/models.py

imported_by[1]{from,to}:
  src/api/views.py,src/payments/processor.py
```

TOON tables declare column names once, then list values row-by-row.
`imports` = this file imports from; `imported_by` = other files that depend on this file.

### CLI (if MCP unavailable)

```bash
relic query __RELIC_EXAMPLE_FILE__
relic search PaymentProcessor
relic impact PaymentProcessor
relic index
```

### Knowledge graph files

- `.knowledge/index.pkl` — binary graph (gitignored, local only)
- `.knowledge/index.toon` — human-readable TOON index (gitignored, local only)
"""


_BARREL_FILES = {"__init__.py", "index.ts", "index.tsx", "index.js", "index.jsx"}


def _pick_example_file(project_root: Path) -> str:
    """Return a representative file path to drop into the agent instructions example.

    Preference order:
    1. Most-connected non-barrel file from the existing index (real demo).
    2. First subproject path from relic.yaml + a placeholder filename.
    3. A generic `src/<your-file>` placeholder.
    """
    # Lazy import to avoid a circular dep at module load time.
    from relic.indexer import load_graph

    knowledge_dir = project_root / ".knowledge"
    try:
        G = load_graph(knowledge_dir)
    except FileNotFoundError:
        G = None
    except Exception:
        G = None

    if G is not None:
        best_path: str | None = None
        best_degree = -1
        for n, d in G.nodes(data=True):
            if d.get("ntype") != "file":
                continue
            if Path(n).name in _BARREL_FILES:
                continue
            deg = G.degree(n)
            if deg > best_degree:
                best_degree = deg
                best_path = n
        if best_path:
            return best_path

    config_file = project_root / "relic.yaml"
    if config_file.exists():
        try:
            with config_file.open(encoding="utf-8") as fh:
                cfg = yaml.safe_load(fh) or {}
            subprojects = cfg.get("subprojects", {})
            if subprojects:
                first = next(iter(subprojects.values()))
                base = (first.get("path", "src") or "src").lstrip("./") or "src"
                return f"{base}/<your-file>"
        except (yaml.YAMLError, OSError):
            pass

    return "src/<your-file>"


def _wrap_block(content: str) -> str:
    return f"{RELIC_BLOCK_START}\n{content}\n{RELIC_BLOCK_END}\n"


def _remove_block(file_path: Path) -> str:
    """Remove the relic block from a file. Returns 'removed' or 'not_found'."""
    if not file_path.exists():
        return "not_found"
    existing = file_path.read_text(encoding="utf-8")
    if RELIC_BLOCK_START not in existing:
        return "not_found"
    start = existing.index(RELIC_BLOCK_START)
    end = existing.index(RELIC_BLOCK_END) + len(RELIC_BLOCK_END)
    updated = existing[:start].rstrip("\n") + existing[end:].lstrip("\n")
    if updated.strip():
        file_path.write_text(updated, encoding="utf-8")
    else:
        file_path.unlink()
    return "removed"


def _remove_mcp_config(agent_key: str, project_root: Path) -> str:
    """Remove the relic MCP server entry from the agent's MCP config file."""
    agent = AGENTS.get(agent_key, {})
    if "mcp_config" not in agent:
        return "not_applicable"
    config_path = project_root / agent["mcp_config"]
    if not config_path.exists():
        return "not_found"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return "not_found"
    servers = config.get(agent["mcp_key"], {})
    if "relic" not in servers:
        return "not_found"
    del servers["relic"]
    config[agent["mcp_key"]] = servers
    if not servers:
        del config[agent["mcp_key"]]
    if config:
        config_path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    else:
        config_path.unlink()
    return "removed"


def uninit_agent(agent_key: str, project_root: Path) -> None:
    """Remove relic instructions and MCP registration for a specific agent."""
    agent = AGENTS[agent_key]
    target = project_root / agent["path"]
    action = _remove_block(target)
    console.print(f"[green]✓[/green] [bold]{agent['name']}[/bold] — instructions {action} [dim]{target}[/dim]")

    if "mcp_config" in agent:
        mcp_action = _remove_mcp_config(agent_key, project_root)
        config_path = project_root / agent["mcp_config"]
        console.print(f"[green]✓[/green] [bold]{agent['name']} MCP[/bold] — {mcp_action} [dim]{config_path}[/dim]")


def _upsert_block(file_path: Path, content: str) -> str:
    """Insert or replace the relic block in a file. Returns 'created' or 'updated'."""
    block = _wrap_block(content)

    if not file_path.exists():
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(block, encoding="utf-8")
        return "created"

    existing = file_path.read_text(encoding="utf-8")

    if RELIC_BLOCK_START in existing:
        start = existing.index(RELIC_BLOCK_START)
        end = existing.index(RELIC_BLOCK_END) + len(RELIC_BLOCK_END)
        updated = existing[:start] + block + existing[end:].lstrip("\n")
        file_path.write_text(updated, encoding="utf-8")
        return "updated"

    separator = "\n\n" if existing.strip() else ""
    file_path.write_text(existing + separator + block, encoding="utf-8")
    return "updated"


AGENTS: dict[str, dict] = {
    "claude": {
        "name": "Claude Code",
        "path": "CLAUDE.md",
        # Project-scope MCP registration — Claude Code reads mcpServers from .mcp.json,
        # NOT from .claude/settings.json (which is for hooks/permissions only).
        "mcp_config": ".mcp.json",
        "mcp_key": "mcpServers",
        "mcp_server": {"command": "relic", "args": ["mcp"]},
    },
    "copilot": {
        "name": "GitHub Copilot",
        "path": ".github/copilot-instructions.md",
        # VS Code workspace MCP config — requires VS Code 1.99+
        "mcp_config": ".vscode/mcp.json",
        "mcp_key": "servers",
        "mcp_server": {"type": "stdio", "command": "relic", "args": ["mcp"]},
    },
    "cursor": {
        "name": "Cursor",
        "path": ".cursorrules",
        "mcp_config": ".cursor/mcp.json",
        "mcp_key": "mcpServers",
        "mcp_server": {"command": "relic", "args": ["mcp"]},
    },
    "codex": {
        "name": "OpenAI Codex",
        "path": "AGENTS.md",
        # No standard MCP config file for Codex CLI — instructions only
    },
}


def _write_mcp_config(agent_key: str, project_root: Path) -> str:
    """Write MCP server registration for the given agent.

    Merges into existing config — does not overwrite unrelated keys.
    Returns 'created' or 'updated'.
    """
    agent = AGENTS[agent_key]
    config_path = project_root / agent["mcp_config"]
    config_path.parent.mkdir(parents=True, exist_ok=True)

    if config_path.exists():
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            config = {}
        action = "updated"
    else:
        config = {}
        action = "created"

    config.setdefault(agent["mcp_key"], {})["relic"] = agent["mcp_server"]

    config_path.write_text(
        json.dumps(config, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return action


def _strip_stale_claude_hooks(project_root: Path) -> None:
    """Remove stale relic PreToolUse hooks written by older relic versions into .claude/settings.json."""
    settings_path = project_root / ".claude" / "settings.json"
    if not settings_path.exists():
        return
    try:
        config = json.loads(settings_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return
    hooks = config.get("hooks", {})
    pre_tool_use = hooks.get("PreToolUse", [])
    cleaned = [
        entry
        for entry in pre_tool_use
        if not (
            isinstance(entry, dict)
            and any(isinstance(h, dict) and "relic" in h.get("command", "") for h in entry.get("hooks", []))
        )
    ]
    if cleaned == pre_tool_use:
        return
    hooks["PreToolUse"] = cleaned
    if not cleaned:
        del hooks["PreToolUse"]
    if not hooks:
        config.pop("hooks", None)
    else:
        config["hooks"] = hooks
    settings_path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def init_agent(agent_key: str, project_root: Path) -> None:
    """Write relic instructions and MCP config for a specific agent."""
    agent = AGENTS[agent_key]
    target = project_root / agent["path"]
    instructions = RELIC_INSTRUCTIONS.replace(RELIC_EXAMPLE_PLACEHOLDER, _pick_example_file(project_root))
    action = _upsert_block(target, instructions)
    console.print(f"[green]✓[/green] [bold]{agent['name']}[/bold] — {action} [dim]{target}[/dim]")

    if "mcp_config" in agent:
        mcp_action = _write_mcp_config(agent_key, project_root)
        config_path = project_root / agent["mcp_config"]
        console.print(f"[green]✓[/green] [bold]{agent['name']} MCP[/bold] — {mcp_action} [dim]{config_path}[/dim]")
        console.print(
            "[dim]tools: relic_session_start, relic_query, relic_search, relic_reindex, relic_diff, relic_checkpoint, relic_annotate[/dim]"
        )

    if agent_key == "claude":
        _strip_stale_claude_hooks(project_root)


def init_all_agents(project_root: Path) -> None:
    """Write relic instructions into config files for all supported agents."""
    for key in AGENTS:
        init_agent(key, project_root)
