# Relic MCP Server

Relic exposes a Model Context Protocol (MCP) server over stdio. Any MCP-compatible
agent can call the seven relic tools natively — no shell commands, no prompting required.

```bash
relic mcp    # start the server (stdio transport)
```

Every response begins with an `index{age_s,stale,files_changed}` freshness header
and a `cost{response_tokens,focus_file_tokens}` cost header so the agent always
knows whether the graph is fresh and can decide whether to skip a query on tiny
files — there is no separate "stats" tool to call. See [Response headers](#response-headers) below.

---

## Setup per agent

Run `relic --init <agent>` to write instructions and register the MCP server automatically.
Or register manually using the config snippets below.

### Claude Code

`relic --init claude` writes this into `.claude/settings.json`:

```json
{
  "mcpServers": {
    "relic": { "command": "relic", "args": ["mcp"] }
  }
}
```

### Cursor

`relic --init cursor` writes this into `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "relic": { "command": "relic", "args": ["mcp"] }
  }
}
```

### GitHub Copilot (VS Code)

Requires VS Code 1.99+. `relic --init copilot` writes this into `.vscode/mcp.json`:

```json
{
  "servers": {
    "relic": { "type": "stdio", "command": "relic", "args": ["mcp"] }
  }
}
```

### OpenAI Codex

Codex CLI does not have a standard MCP config file. `relic --init codex` writes
instructions into `AGENTS.md` — the agent uses the CLI tools documented there.

### Custom agents / orchestrators

Any MCP client (LangGraph, custom stdio client) can connect:

```python
import subprocess
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

server = StdioServerParameters(command="relic", args=["mcp"])
async with stdio_client(server) as (read, write):
    async with ClientSession(read, write) as session:
        await session.initialize()
        result = await session.call_tool("relic_query", {"target": "src/core/processor.py"})
```

---

## Tools

### `relic_query`

Get dependency context for a file or symbol before editing it.

**When to call:** at the start of any edit session for unfamiliar code.

**Parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `target` | string | yes | — | File path, symbol name, `Class.method`, or space-separated batch |
| `depth` | integer | no | `2` | BFS hops from target node. Use `1` for barrel/index files. |
| `exclude_tests` | boolean | no | `true` | Filter test-file symbols from `neighbor_symbols` |
| `max_neighbor_symbols` | integer | no | `30` | Cap neighbor symbols (0 = unlimited), ranked by connectivity |
| `include_intent` | boolean | no | `true` | Include the `intent` column in the exports table. Set `false` to save ~10% tokens on very large graphs. |

**Output:** TOON block — focus file, neighboring files, exported symbols (with intent), import/caller/calls edges, decorators.

```
index{age_s,stale,files_changed}: 12,false,0
cost{response_tokens,focus_file_tokens}: 847,312

focus: src/payments/processor.py

neighbors[3]{path,language,subproject}:
  src/payments/models.py,python,payments
  src/payments/exceptions.py,python,payments
  src/core/database.py,python,core

exports[4]{name,type,line,signature,intent}:
  PaymentProcessor,class,12,PaymentProcessor,Handles payment authorization and capture
  process_payment,function,45,process_payment(order: Order) -> Receipt,Authorize card and emit receipt
  validate_card,function,78,validate_card(card: Card) -> bool,
  RETRY_LIMIT,variable,8,RETRY_LIMIT,

decorators[2]{symbol,decorator,args}:
  process_payment,app.route,/payments POST
  validate_card,require_auth,

neighbor_symbols[6]{name,type,file}:
  Payment,class,src/payments/models.py
  PaymentStatus,type,src/payments/models.py
  DatabaseSession,class,src/core/database.py

imports[3]{from,to}:
  src/payments/processor.py,src/payments/models.py
  src/payments/processor.py,src/payments/exceptions.py
  src/payments/processor.py,src/core/database.py

imported_by[2]{from,to}:
  src/api/views.py,src/payments/processor.py
  src/workers/billing.py,src/payments/processor.py

calls[2]{caller,callee}:
  process_payment,validate_card
  process_payment,DatabaseSession

called_by[1]{caller,callee}:
  handle_checkout,process_payment
```

**Depth guidance:**

| Depth | Use case | Token range |
|---|---|---|
| `1` | Barrel/index files, quick caller check | 300–1,200 |
| `2` (default) | Normal files — see two hops of context | 800–3,000 |
| `3+` | Deep refactors — wide graph, higher token cost | 2,000–8,000 |

---

### `relic_search`

Search for files and symbols across the knowledge graph by name.

**When to call:** when you don't know where a class, function, or file lives.

**Parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `query` | string | yes | — | Partial file path or symbol name (case-insensitive substring). Wrap in double quotes to search string literals: `'"error message"'`. |
| `kind` | string | no | `"all"` | Filter: `"file"`, `"symbol"`, or `"all"` |
| `limit` | integer | no | `20` | Max results per category |

**Output (name search):**

```
index{age_s,stale,files_changed}: 12,false,0
cost{response_tokens,focus_file_tokens}: 312,0

search: processor

file_matches[2]{path,language,exports,imported_by}:
  src/payments/processor.py,python,4,3
  src/core/preprocessor.ts,typescript,2,1

symbol_matches[3]{name,type,file,signature,callers,intent}:
  PaymentProcessor,class,src/payments/processor.py,PaymentProcessor,5,Handles payment authorization and capture
  DataProcessor,class,src/core/preprocessor.ts,DataProcessor(BaseProcessor),2,
  process_payment,function,src/payments/processor.py,process_payment(order: Order) -> Receipt,7,Authorize card and emit receipt
```

**Output (quoted literal search):**

```
search: "authorize card"

literal_matches[1]{value,symbol,file,line}:
  Authorize card and emit receipt,process_payment,src/payments/processor.py,45
```

Each hit carries enough context to skip the follow-up `relic_query` call in
the common case: file results show `exports` (symbol count) and
`imported_by` (in-edges); symbol results carry the signature, callers count,
and intent. Results matched via decorator or string literal show a `via` column
(`via=decorator:app.route` or `via=literal`). Signatures over 80 characters are
truncated with `…`; query the symbol directly for the full text.

**Tips:**
- Search by partial name: `"proc"` matches `processor`, `preprocess`, `ProducerConfig`
- Search by directory: `"payments/"` returns only files in the payments subproject
- Search string literals: `'"payment failed"'` (wrap in double quotes) matches string constants ≥ 8 chars inside function bodies
- Search by decorator: `"app.route"` finds functions decorated with `@app.route`
- Only follow up with `relic_query` when you need neighbors / full graph context

---

### `relic_reindex`

Incrementally update the knowledge graph from source.

**When to call:** when the response header reports `stale=true`, or after you
create, delete, or move source files.

**Parameters:** none.

**Output:**

```
index{age_s,stale,files_changed}: 0,false,0
reindex: incremental in 0.06s
changed: +1 new, ~2 modified, -0 deleted, =79 unchanged
files: 82
symbols: 598
edges: 1,180
```

**Notes:**
- Reparses only files whose mtime changed since the last index. Sub-second on
  large repos in steady state.
- If no index exists yet, the call returns an error asking the user to run
  `relic index` once. The MCP server never does a full cold-start build —
  that path stays in the CLI to avoid blowing past MCP request timeouts.

---

### `relic_diff`

Check what changed since the last index without a full reindex.

**When to call:** after merges or big edits to decide whether `relic_reindex` is needed.

**Parameters:** none.

**Output:**

```
diff_summary:
  new_files: 2
  deleted_files: 0
  changed_files: 3

new_files[2]{path}:
  src/payments/refunds.py
  src/payments/disputes.py

changed_symbols[4]{file,name,status}:
  src/payments/processor.py,process_refund,added
  src/payments/processor.py,validate_card,changed
  src/core/database.py,execute_query,changed
  src/core/database.py,close_pool,added
```

**Notes:**
- Lightweight — compares on-disk source against the stored graph without rebuilding
- If the diff shows changes, follow up with `relic_reindex` to update the graph

---

### `relic_session_start`

Restore task context at the start of every conversation or after context compaction.

**When to call:** MUST be the first relic call in every new conversation.

**Parameters:** none.

**Output:**

```
index{age_s,stale,files_changed}: 12,false,0
cost{response_tokens,focus_file_tokens}: 180,0

session_start: no active checkpoint
```

Or, if a checkpoint and annotations exist:

```
index{age_s,stale,files_changed}: 12,false,0
cost{response_tokens,focus_file_tokens}: 450,0

session_start: checkpoint restored

checkpoint{task,phase,updated,sessions}: oauth-payments,Phase 3/4 — token refresh,2026-05-19T11:35:00+00:00,3

done[2]{file,note}:
  src/auth/oauth.py,refresh flow implemented
  tests/test_oauth.py,unit tests passing

in_progress[1]{file,focus,line}:
  src/auth/middleware.py,attach refresh token to every request,0

constraints[1]{file,rule}:
  src/auth/oauth.py,token TTL is 15 min — do not extend without security review

next_steps[2]{task,priority}:
  wire middleware into view layer,high
  add integration test for token expiry path,medium

annotations[1]{file,scope,rule,added}:
  src/auth/oauth.py,permanent,token TTL is 15 min — do not extend without security review,2026-05-19
```

**Notes:**
- ~180 tokens when no checkpoint, ~450 tokens when one exists — far cheaper than
  re-reading files or context to rediscover task state.
- `sessions` increments each time the checkpoint is saved, tracking how many
  conversations have touched this task.

---

### `relic_checkpoint`

Save and restore task state across sessions and context compactions.

**When to call:**
- `save` — before ending a session or when context approaches limits
- `load` — to inspect current state (session_start does this automatically)
- `close` — when a PR is merged or task is abandoned (logs one summary line)
- `list` — to see all named checkpoints (for parallel tasks)

**Parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `action` | string | yes | — | `"save"`, `"load"`, `"close"`, or `"list"` |
| `task` | string | no | `null` | Named task (omit for default checkpoint) |
| `name` | string | no | `null` | Display name for the task |
| `phase` | string | no | `null` | Current phase description |
| `done` | array | no | `[]` | Delta list of `[file, note]` pairs — additive, merged with existing |
| `in_progress` | array | no | `[]` | Replaces current in-progress list: `[file, note, pct]` triples |
| `constraints` | array | no | `[]` | Delta list of `[file, note]` pairs — additive |
| `next_steps` | array | no | `[]` | Replaces current next-steps list: `[file, note]` pairs |

**Delta merge semantics:** `done` and `constraints` are additive (send only new
entries each call). `in_progress` and `next_steps` replace fully (they change
every session). This means agents never need to resend the full done list.

**Output (save):**

```
checkpoint{task,phase,updated,sessions}: oauth-payments,Phase 3/4,2026-05-19T11:35:00+00:00,2
done[2]{file,note}: ...
```

**Output (close):**

```
checkpoint closed — task logged, checkpoint.toon deleted.
```

**Storage:** `.knowledge/checkpoint.toon` (default), `.knowledge/checkpoints/NAME.toon`
(named), `.knowledge/checkpoint_log.toon` (closed-task history). All TOON format.

---

### `relic_annotate`

Attach a constraint or note to a file — surfaces automatically in every future
`relic_query` for that file.

**When to call:** when you discover a non-obvious constraint, frozen interface,
or "gotcha" that future agents (or your future self after compaction) would
otherwise re-learn the hard way.

**Parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `file` | string | yes | — | Relative file path to annotate |
| `rule` | string | yes | — | The constraint or note text |
| `permanent` | boolean | no | `false` | `true` = codebase invariant, survives checkpoint close. `false` = task-scoped, cleaned up on `relic_checkpoint close`. |
| `action` | string | no | `add` | `add` = attach annotation. `delete` = remove annotation matching (file, rule). |

**Output (add):**

```
annotated: src/auth/oauth.py
scope: permanent
rule: token TTL is 15 min — do not extend without security review
```

**Output (delete):**

```
deleted annotation: src/auth/oauth.py
rule: token TTL is 15 min — do not extend without security review
```

**How annotations surface:** every `relic_query` for an annotated file appends
an `annotations[N]{scope,rule,added}` TOON block at the end of the response.
No extra tool call needed.

```
annotations[1]{scope,rule,added}:
  permanent,token TTL is 15 min — do not extend without security review,2026-05-19
```

**Permanent vs task-scoped:**
- `permanent=true` — codebase invariants (security constraints, API contracts,
  intentional quirks). Written once, never auto-cleaned.
- `permanent=false` (default) — task notes (WIP decisions, current PR context).
  Deleted automatically when `relic_checkpoint close` runs.

---

## Response headers

Every MCP response is prefixed with two lines:

```
index{age_s,stale,files_changed}: 42,false,0
cost{response_tokens,focus_file_tokens}: 847,312
```

### Freshness header (`index{...}`)

| Field | Meaning |
|---|---|
| `age_s` | Seconds since `index.pkl` was last written |
| `stale` | `true` iff at least one source file has changed, been added, or deleted relative to the saved index |
| `files_changed` | Total count of differing files (added + modified + deleted) |

If no index exists yet, the header collapses to `index{indexed,stale}: false,true`
and the body explains how to bootstrap it.

The header is computed via a cheap `stat()` sweep against `.knowledge/mtimes.json`
and cached for 2 seconds, so back-to-back calls in the same agent turn pay the
cost only once. Agents should treat `stale=true` as the sole signal to call
`relic_reindex` — there is no separate "stats" tool, and proactive reindexing
when `stale=false` is wasted work.

### Cost header (`cost{...}`)

| Field | Meaning |
|---|---|
| `response_tokens` | Approximate token count of this response (encoded with tiktoken `cl100k_base`) |
| `focus_file_tokens` | Approximate token count of the focus file on disk — present on `relic_query` responses only, `0` otherwise |

Agents use `focus_file_tokens` to apply the SKIP rule: if `focus_file_tokens < 200`
and the file has 0 callers, it's cheaper to just read the file directly instead
of calling `relic_query`. The cost header is emitted on every response (including
`relic_reindex` and `relic_search`), so agents can track cumulative MCP overhead
without a separate tool call.

---

## Reading TOON output

TOON (Token-Oriented Object Notation) is a tabular format. Column names are declared
once per table; values are listed row by row. ~40% fewer tokens than equivalent JSON.

**Table syntax:**

```
tableName[rowCount]{col1,col2,col3}:
  val1,val2,val3
  val1,val2,val3
```

**Edge tables:**

| Table | Direction | Meaning |
|---|---|---|
| `imports` | `from → to` | focus file imports from these files |
| `imported_by` | `from → to` | these files import the focus file (callers) |
| `extends` | `child → parent` | inheritance relationships |
| `calls` | `caller → callee` | outbound function calls from focus symbols |
| `called_by` | `caller → callee` | inbound function calls into focus symbols |

**`imported_by` is the most important table** — it tells you what breaks if you change
this file. `calls` and `called_by` go deeper — showing which *functions* call which,
so you don't need to read the caller file to understand the dependency.

---

## Workflow examples

### Starting a new conversation

```
→ relic_session_start()
  Returns freshness header + active checkpoint (if any).
  No checkpoint → proceed normally.
  Checkpoint present → task/phase/done/constraints restored, skip re-reading files.
```

### Saving progress before ending a session

```
→ relic_checkpoint(action="save", phase="Phase 3/4 — token refresh",
    done=[["src/auth/oauth.py", "refresh flow implemented"]],
    in_progress=[["src/auth/middleware.py", "attach token to request", 60]],
    next_steps=[["src/api/views.py", "wire middleware"]])
  Done/constraints are additive — only send new entries.
  In_progress/next_steps replace — send the full current list.
```

### Annotating a constraint you just discovered

```
→ relic_annotate(file="src/auth/oauth.py",
    rule="token TTL is 15 min — do not extend without security review",
    permanent=True)
  Surfaces in every future relic_query("src/auth/oauth.py") automatically.
```

### Closing a task on PR merge

```
→ relic_checkpoint(action="close")
  Deletes checkpoint.toon, writes one line to checkpoint_log.toon.
  Cleans up task-scoped annotations (permanent annotations survive).
```

### Full lifecycle: save → compaction → restore

This is the core use case for `relic_checkpoint` and `relic_session_start`.

**Session 1 — start the task:**
```
→ relic_session_start()
  Returns: no active checkpoint — starting fresh session.

→ relic_query("src/auth/oauth.py")
  ... edit the file ...

→ relic_checkpoint(action="save", task="oauth-refresh",
    phase="implementing token refresh",
    done=[{"file": "src/auth/oauth.py", "note": "refresh flow done"}],
    in_progress=[{"file": "src/auth/middleware.py", "focus": "attach token", "line": 45}],
    next_steps=[{"task": "wire middleware into API views", "priority": "high"}])

→ relic_annotate(file="src/auth/middleware.py",
    rule="token TTL is 15 min — do not extend without security review")
```

**Context compaction happens. New session.**

**Session 2 — restore and continue:**
```
→ relic_session_start(task="oauth-refresh")
  Returns:
    checkpoint{task,phase,updated,sessions}: oauth-refresh,implementing token refresh,...,2

    done[1]{file,note}:
      src/auth/oauth.py,refresh flow done

    in_progress[1]{file,focus,line}:
      src/auth/middleware.py,attach token,45

    next[1]{task,priority}:
      wire middleware into API views,high

    annotations[1]{file,scope,rule}:
      src/auth/middleware.py,task,token TTL is 15 min — do not extend without security review

  Full context restored in ~450 tokens. No file re-reads needed.
  Annotation will also appear automatically in relic_query("src/auth/middleware.py").
```

---

### Before editing a file

```
→ relic_query("src/payments/processor.py")
  Read: exports, what it imports, who calls it.
  Header: stale=false → graph is current.
→ Read the file
→ Edit the file
```

Don't call `relic_reindex` proactively. The next response's header will
report `stale=true` if your edits drifted the graph; only then reindex.

### Finding where something lives

```
→ relic_search("PaymentProcessor")
  Hit carries signature + caller count + defining file.
  In most cases that's enough to keep going — no follow-up needed.
→ relic_query("src/payments/processor.py")   # only if you need neighbours
```

### Before a large refactor

```
→ relic_query("src/core/database.py", depth=3)
  Header reports stale=false → graph is current.
→ Read: wide graph context, plan the changes.
```

If the header reports `stale=true`, call `relic_reindex` once first — the
incremental update is sub-second.

---

## Troubleshooting

**`Error: no index found. Ask the user to run relic index ...`**
The graph hasn't been built yet. The MCP server intentionally refuses to do a
full cold-start build (it would blow past client timeouts on large repos). Have
the user run `relic index` once in the project root. Subsequent `relic_reindex`
calls from the agent are incremental and fast.

**`Not found: 'X'. Try relic_search or relic_reindex if recently added.`**
Node not in index. Either the file was added after the last index, or the path is wrong.
Use `relic_search` to find the correct path, or call `relic_reindex` to rebuild.

**Index is stale after editing files**
The freshness header on the next response will say `stale=true`. Call
`relic_reindex` — incremental, sub-second.
