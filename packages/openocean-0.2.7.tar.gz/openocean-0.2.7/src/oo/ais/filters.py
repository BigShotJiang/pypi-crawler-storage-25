import datetime
import typing
from dataclasses import dataclass

from oo.ais.utils import encode_lat_lon


@dataclass
class QueryFilter:

    def to_params(self) -> dict:
        """Helper to convert the dataclass to query parameters."""
        return {k: v for k, v in self.__dict__.items() if v is not None}


@dataclass
class Vessels(QueryFilter):
    mmsi: typing.List[int] = None

    def to_params(self) -> dict:
        params = {}
        if self.mmsi:
            # Join list into a comma-separated string for URL query parameters
            params["mmsi"] = ",".join(map(str, self.mmsi))
        return params


@dataclass
class Spatial(QueryFilter):
    min_lat: float | None = None
    max_lat: float | None = None
    min_lon: float | None = None
    max_lon: float | None = None

    def encode(self):
        return map(encode_lat_lon, [self.min_lat, self.max_lat, self.min_lon, self.max_lon])


@dataclass
class Temporal(QueryFilter):
    start_time: datetime.datetime | None
    stop_time: datetime.datetime | None


@dataclass
class Pagination(QueryFilter):
    page: int = 1
    limit: int = 1000

    def next(self) -> 'Pagination':
        return self.__class__(self.page + 1, self.limit)

    def prev(self) -> 'Pagination':
        return self.__class__(max(self.page - 1, 1), self.limit)
