import abc
from dataclasses import dataclass
from datetime import datetime

from oo.ais.ais_message_dto import AISMessageDTO
from oo.ais.utils import decode_eta, decode_tenth, encode_eta, encode_tenth


@dataclass
class VoyageBaseDTO(AISMessageDTO, abc.ABC):
    destination: str | None = None
    month: int | None = None
    day: int | None = None
    hour: int | None = None
    minute: int | None = None
    draught: int | None = None


@dataclass
class EncodedVoyageDTO(VoyageBaseDTO):
    def encode(self): return self

    def decode(self) -> 'DecodedVoyageDTO':
        eta = decode_eta(self.time, self.month, self.day, self.hour, self.minute)
        return DecodedVoyageDTO(
            mmsi=self.mmsi, time=self.time, destination=self.destination,
            eta=eta, draught=decode_tenth(self.draught)
        )


@dataclass
class DecodedVoyageDTO(AISMessageDTO):
    destination: str | None = None
    eta: datetime | None = None
    draught: float | None = None

    def encode(self) -> 'EncodedVoyageDTO':
        month, day, hour, minute = encode_eta(self.eta)
        return EncodedVoyageDTO(
            mmsi=self.mmsi, time=self.time, destination=self.destination,
            month=month,
            day=day,
            hour=hour,
            minute=minute,
            draught=encode_tenth(self.draught)
        )

    def decode(self): return self


@dataclass
class VoyageDTO(EncodedVoyageDTO):
    pass
