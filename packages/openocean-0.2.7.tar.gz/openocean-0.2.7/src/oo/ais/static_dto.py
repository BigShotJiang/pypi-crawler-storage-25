import abc
from dataclasses import dataclass

from oo.ais import utils
from oo.ais.ais_message_dto import AISMessageDTO
from oo.ais.utils import decode_width, decode_length, encode_length, encode_width


@dataclass
class StaticBaseDTO(AISMessageDTO, abc.ABC):
    imo: int | None = None
    name: str | None = None
    callsign: str | None = None
    ship_type: int | None = None
    to_bow: int | None = None
    to_stern: int | None = None
    to_port: int | None = None
    to_starboard: int | None = None


@dataclass
class EncodedStaticDTO(StaticBaseDTO):
    def encode(self): return self

    def decode(self) -> 'DecodedStaticDTO':
        return DecodedStaticDTO(
            mmsi=self.mmsi, time=self.time, imo=self.imo, name=self.name,
            callsign=self.callsign, ship_type=self.ship_type,
            width=decode_width(self.to_port, self.to_starboard),
            length=decode_length(self.to_bow, self.to_stern),
        )


@dataclass
class DecodedStaticDTO(AISMessageDTO):
    imo: int | None = None
    name: str | None = None
    callsign: str | None = None
    ship_type: int | None = None
    width: int | None = None
    length: int | None = None

    def encode(self) -> EncodedStaticDTO:
        to_bow, to_stern = encode_length(self.length)
        to_port, to_starboard = encode_width(self.width)
        return EncodedStaticDTO(
            mmsi=self.mmsi, time=self.time, imo=self.imo, name=self.name,
            callsign=self.callsign, ship_type=self.ship_type, to_bow=to_bow,
            to_stern=to_stern, to_port=to_port, to_starboard=to_starboard,
        )

    def decode(self): return self


@dataclass
class StaticDTO(EncodedStaticDTO):
    pass


