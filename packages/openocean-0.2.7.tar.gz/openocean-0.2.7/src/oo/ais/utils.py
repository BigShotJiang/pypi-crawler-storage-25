import math
from datetime import datetime


def decode_eta(time, month: int | None, day: int | None, hour: int | None, minute: int | None) -> datetime | None:
    """Decodes AIS month/day/hour/minute into a datetime object."""
    if all(v is not None for v in [month, day, hour, minute]):
        # AIS month/day/hour/minute are always valid. 
        # AIS does not transmit the year; assume current year.
        return datetime(time.year, month, day, hour, minute)
    return None


def encode_eta(eta: datetime | None) -> tuple[int | None, int | None, int | None, int | None]:
    """Encodes a datetime object into AIS month/day/hour/minute components."""
    if eta is None:
        return None, None, None, None
    return eta.month, eta.day, eta.hour, eta.minute


def decode_lat_lon(lat_lon: int) -> float:
    return decode_coord(lat_lon)


def encode_lat_lon(lat_lon: float) -> float:
    return encode_coord(lat_lon)


def decode_timestamp(epoch: int) -> datetime:
    return datetime.fromtimestamp(epoch)


def encode_timestamp(dt: datetime) -> int:
    return int(dt.timestamp())


def decode_cog(cog: int) -> float:
    return decode_tenth(cog)


def encode_cog(cog: int) -> int:
    return encode_tenth(cog)


def decode_heading(heading: int) -> float:
    return decode_tenth(heading)


def encode_heading(heading: int) -> float:
    return encode_tenth(heading)


def decode_rot(rot_enc: int | None) -> float | None:
    """
    Decodes AIS ROT based on ITU-R M.1371.
    Values: 0-126 (right), 0 to -126 (left), 127/ -127 (No TI), 128 (No info).
    https://www.navcen.uscg.gov/ais-class-a-reports
    """
    if rot_enc is None or rot_enc == -128:  # 128 (80 hex) = No info
        return None

    # Handle "No TI" cases (127 and -127)
    if rot_enc == 127: return 5.0  # Or handle as a specific constant
    if rot_enc == -127: return -5.0

    # Formula: ROTAIS = 4.733 * SQRT(ROTsensor)
    # Therefore: ROTsensor = (ROTAIS / 4.733)^2
    return round((abs(rot_enc) / 4.733) ** 2 * (1 if rot_enc >= 0 else -1), 2)


def encode_rot(rot_deg_min: float | None) -> int | None:
    """
    Encodes degrees per minute to AIS raw integer.
    https://www.navcen.uscg.gov/ais-class-a-reports
    """
    if rot_deg_min is None:
        return -128

    # Handle simple "No TI" threshold
    if 0 < rot_deg_min <= 5: return 127
    if -5 <= rot_deg_min < 0: return -127

    # Formula: ROTAIS = 4.733 * SQRT(ROTsensor)
    direction = 1 if rot_deg_min >= 0 else -1
    rot_ais = 4.733 * math.sqrt(abs(rot_deg_min))

    # Clamp to +/- 126
    return int(min(rot_ais, 126)) * direction


def encode_length(length: int | None) -> tuple[int | None, int | None]:
    to_bow = length // 2 if length is not None else None
    to_stern = to_bow
    return to_bow, to_stern


def encode_width(width: int | None) -> tuple[int | None, int | None]:
    to_port = width // 2 if width is not None else None
    to_starboard = to_port
    return to_port, to_starboard


def decode_length(to_bow: int | None, to_stern: int | None) -> int | None:
    if to_bow is None and to_stern is None:
        return None
    return (to_bow or 0) + (to_stern or 0)


def decode_width(to_port: int | None, to_starboard: int | None) -> int | None:
    if to_port is None and to_starboard is None:
        return None
    return (to_port or 0) + (to_starboard or 0)


def decode_coord(value: int | None) -> float | None:
    return value / 600000.0 if value is not None else None


def encode_coord(value: float | None) -> int | None:
    return int(round(value * 600000)) if value is not None else None


def decode_tenth(value: int | None) -> float | None:
    return value / 10.0 if value is not None else None


def encode_tenth(value: float | None) -> int | None:
    return int(value * 10) if value is not None else None
