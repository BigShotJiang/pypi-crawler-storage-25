import abc
from dataclasses import dataclass

from oo.ais.ais_message_dto import AISMessageDTO
from oo.ais.utils import encode_tenth, encode_coord, encode_rot, decode_tenth, decode_rot, decode_coord


@dataclass
class PositionBaseDTO(AISMessageDTO, abc.ABC):
    lat: int | None = None
    lon: int | None = None
    sog: int | None = None
    cog: int | None = None
    status: int | None = None
    rot: int | None = None
    heading: int | None = None
    accuracy: bool | None = None


@dataclass
class EncodedPositionDTO(PositionBaseDTO):
    def encode(self):
        return self

    def decode(self) -> 'DecodedPositionDTO':
        return DecodedPositionDTO(
            mmsi=self.mmsi,
            time=self.time,
            lat=decode_coord(self.lat),
            lon=decode_coord(self.lon),
            sog=decode_tenth(self.sog),
            cog=decode_tenth(self.cog),
            status=self.status,
            rot=decode_rot(self.rot),
            heading=decode_tenth(self.heading),
            accuracy=self.accuracy
        )


@dataclass
class DecodedPositionDTO(AISMessageDTO):
    lat: float | None = None
    lon: float | None = None
    sog: float | None = None
    cog: float | None = None
    status: int | None = None
    rot: float | None = None
    heading: float | None = None
    accuracy: bool | None = None

    def encode(self) -> EncodedPositionDTO:
        return EncodedPositionDTO(
            mmsi=self.mmsi,
            time=self.time,
            lat=encode_coord(self.lat),
            lon=encode_coord(self.lon),
            sog=encode_tenth(self.sog),
            cog=encode_tenth(self.cog),
            status=self.status,
            rot=encode_rot(self.rot),
            heading=encode_tenth(self.heading),
            accuracy=self.accuracy
        )

    def decode(self):
        return self


@dataclass
class PositionDTO(EncodedPositionDTO):
    pass
