import abc
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any


@dataclass
class AISMessageDTO(abc.ABC):
    mmsi: int
    time: datetime

    @abc.abstractmethod
    def encode(self): ...

    @abc.abstractmethod
    def decode(self): ...

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
