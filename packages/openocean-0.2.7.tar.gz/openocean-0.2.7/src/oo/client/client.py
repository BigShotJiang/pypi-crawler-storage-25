from typing import TypeVar, overload, Literal, Union

from oo.ais.ais_message_dto import AISMessageDTO
from oo.ais.filters import Vessels, Temporal, Pagination, Spatial, QueryFilter
from oo.ais.position_dto import PositionDTO, DecodedPositionDTO
from oo.ais.static_dto import StaticDTO, DecodedStaticDTO
from oo.ais.voyage_dto import VoyageDTO, DecodedVoyageDTO
from oo.client.endpoints import OpenOceanEndpoint

try:
    import httpx
except ImportError:
    raise ImportError(
        "Module 'oo.client' requires 'httpx'. "
        "Install it with: pip install openocean[client]"
    )

T = TypeVar("T", bound="AISMessageDTO")


class OpenOceanClient:
    def __init__(self, base_url: str = "https://api.openoceannetwork.com", token: str | None = None,
                 timeout: float = 10.0):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self._headers = {"Authorization": f"Bearer {token}"} if token else {}
        self._client = None

    async def __aenter__(self):
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout, headers=self._headers)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._client.aclose()
        self._client = None

    async def _get(self, endpoint: str, params) -> list | dict:
        if not self._client:
            raise RuntimeError(
                "OpenOceanClient must be used as an async context manager. i.e. async with OpenOceanClient() as client:")
        response = await self._client.get(endpoint, params=params)
        response.raise_for_status()
        data = response.json()
        return data

    async def _get_ais(self,
                       endpoint: OpenOceanEndpoint,
                       dto: type[T],
                       vessels: Vessels | None = None,
                       spatial: Spatial | None = None,
                       temporal: Temporal | None = None,
                       pagination: Pagination | None = None,
                       decode: bool = True,
                       ) -> list[T]:
        params = _to_params(vessels, spatial, temporal, pagination)
        items = await self._get(endpoint.value, params)
        ais = [(dto(**item).decode() if decode else dto(**item)) for item in items]
        return ais

    @overload
    async def get_position(self, decode: Literal[True], **kwargs) -> list[DecodedPositionDTO]:
        ...

    @overload
    async def get_position(self, decode: Literal[False], **kwargs) -> list[PositionDTO]:
        ...

    async def get_position(self,
                           vessels: Vessels | None = None,
                           spatial: Spatial | None = None,
                           temporal: Temporal | None = None,
                           pagination: Pagination | None = None,
                           decode: bool = True,
                           ) -> list[Union[PositionDTO, DecodedPositionDTO]]:
        data = await self._get_ais(
            endpoint=OpenOceanEndpoint.POSITION,
            dto=PositionDTO,
            vessels=vessels,
            spatial=spatial,
            temporal=temporal,
            pagination=pagination,
            decode=decode,
        )
        return data

    @overload
    async def get_static(self, decode: Literal[True], **kwargs) -> list[DecodedStaticDTO]:
        ...

    @overload
    async def get_static(self, decode: Literal[False], **kwargs) -> list[StaticDTO]:
        ...

    async def get_static(self,
                         vessels: Vessels | None = None,
                         spatial: Spatial | None = None,
                         temporal: Temporal | None = None,
                         pagination: Pagination | None = None,
                         decode: bool = True,
                         ) -> list[Union[StaticDTO, DecodedStaticDTO]]:
        data = await self._get_ais(
            endpoint=OpenOceanEndpoint.STATIC,
            dto=StaticDTO,
            vessels=vessels,
            spatial=spatial,
            temporal=temporal,
            pagination=pagination,
            decode=decode,
        )
        return data

    @overload
    async def get_voyage(self, decode: Literal[True], **kwargs) -> list[DecodedVoyageDTO]:
        ...

    @overload
    async def get_voyage(self, decode: Literal[False], **kwargs) -> list[VoyageDTO]:
        ...

    async def get_voyage(self,
                         vessels: Vessels | None = None,
                         spatial: Spatial | None = None,
                         temporal: Temporal | None = None,
                         pagination: Pagination | None = None,
                         decode: bool = True,
                         ) -> list[Union[VoyageDTO, DecodedVoyageDTO]]:
        data = await self._get_ais(
            endpoint=OpenOceanEndpoint.VOYAGE,
            dto=VoyageDTO,
            vessels=vessels,
            spatial=spatial,
            temporal=temporal,
            pagination=pagination,
            decode=decode,
        )
        return data

    # TODO activate auto pagination?
    """ 
    async def get_all_position(self, **kwargs) -> AsyncGenerator[Union[PositionDTO, DecodedPositionDTO], None]:
        # Pass self.get_positions as the fetcher
        async for item in self._paginate(self.get_position, **kwargs):
            yield item

    async def get_all_voyage(self, **kwargs) -> AsyncGenerator[Union[VoyageDTO, DecodedVoyageDTO], None]:
        async for item in self._paginate(self.get_voyage, **kwargs):
            yield item

    async def get_all_static(self, **kwargs) -> AsyncGenerator[Union[StaticDTO, DecodedStaticDTO], None]:
        async for item in self._paginate(self.get_static, **kwargs):
            yield item

    async def _paginate(
            self,
            fetch_func: Callable[..., Awaitable[list[T]]],
            pagination: Pagination = None,
            **kwargs: Any
    ) -> AsyncGenerator[T, None]:
        pagination = pagination or Pagination()
        while True:
            batch = await fetch_func(**kwargs, pagination=pagination)
            if not batch:
                break

            for item in batch:
                yield item
            pagination = pagination.next()
    """


def _to_params(*args: QueryFilter):
    params = {}
    for filter_obj in args:
        if filter_obj:
            params.update(filter_obj.to_params())
    return params
