from enum import Enum


class OpenOceanEndpoint(Enum):
    POSITION = "/position"
    STATIC = "/static"
    VOYAGE = "/voyage"

    LATEST = "/latest"

    DENSITY = "/density"
    DENSITY_DAILY = "/day"
    DENSITY_MONTHLY = "/month"
    DENSITY_YEARLY = "/year"
