import datetime

try:
    import sqlalchemy
    from sqlalchemy.orm import mapped_column, Mapped

except ImportError:
    raise ImportError(
        "Module 'oo.db' requires 'sqlalchemy'. "
        "Install it with: pip install openocean[db]"
    )

from oo.ais.position_dto import PositionDTO
from oo.ais.static_dto import StaticDTO
from oo.ais.voyage_dto import VoyageDTO


class AISMessageTableMixin:
    mmsi: Mapped[int] = mapped_column(sqlalchemy.Integer, primary_key=True)
    time: Mapped[datetime.datetime] = mapped_column(sqlalchemy.DateTime(timezone=True), primary_key=True)


class PositionTableMixin(AISMessageTableMixin):
    status: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    sog: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    cog: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    rot: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    heading: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)

    lat: Mapped[int] = mapped_column(sqlalchemy.Integer, nullable=False)
    lon: Mapped[int] = mapped_column(sqlalchemy.Integer, nullable=False)

    accuracy: Mapped[bool | None] = mapped_column(sqlalchemy.Boolean)

    def to_dto(self) -> PositionDTO:
        return PositionDTO(
            mmsi=self.mmsi,
            time=self.time,
            status=self.status,
            sog=self.sog,
            cog=self.cog,
            rot=self.rot,
            heading=self.heading,
            lat=self.lat,
            lon=self.lon,
            accuracy=self.accuracy,
        )


class StaticTableMixin(AISMessageTableMixin):
    imo: Mapped[int | None] = mapped_column(sqlalchemy.Integer)
    name: Mapped[str | None] = mapped_column(sqlalchemy.Text)
    callsign: Mapped[str | None] = mapped_column(sqlalchemy.Text)

    ship_type: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)

    to_bow: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    to_stern: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    to_port: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    to_starboard: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)

    def to_dto(self) -> StaticDTO:
        return StaticDTO(
            mmsi=self.mmsi,
            time=self.time,
            imo=self.imo,
            name=self.name,
            callsign=self.callsign,
            ship_type=self.ship_type,
            to_bow=self.to_bow,
            to_stern=self.to_stern,
            to_port=self.to_port,
            to_starboard=self.to_starboard,
        )


class VoyageTableMixin(AISMessageTableMixin):
    destination: Mapped[str | None] = mapped_column(sqlalchemy.Text)

    month: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    day: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    hour: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)
    minute: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)

    draught: Mapped[int | None] = mapped_column(sqlalchemy.SmallInteger)

    def to_dto(self) -> VoyageDTO:
        return VoyageDTO(
            mmsi=self.mmsi,
            time=self.time,
            destination=self.destination,
            month=self.month,
            day=self.day,
            hour=self.hour,
            minute=self.minute,
            draught=self.draught,
        )
