import typing

from oo.db.db_filters import DbFilter
from oo.db.tables import AISMessageTableMixin

try:
    from sqlalchemy import select
except ImportError:
    raise ImportError(
        "Module 'oo.db' requires 'sqlalchemy'. "
        "Install it with: pip install openocean[db]"
    )

T = typing.TypeVar("T", bound=AISMessageTableMixin)


class AISMessageRepositoryMixin(typing.Generic[T]):
    model_type: typing.Type[T]

    async def get_filtered(self, filters: typing.List[DbFilter] | None = None) -> typing.Sequence[T]:
        table = self.model_type
        statement = select(table).order_by(table.time.desc())
        if filters:
            for f in filters:
                statement = f.apply(statement, table=table)
        result = await self.session.execute(statement)
        return result.scalars().all()
