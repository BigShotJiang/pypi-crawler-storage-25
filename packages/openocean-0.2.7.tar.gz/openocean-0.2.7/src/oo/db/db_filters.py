import abc
from typing import Any

from oo.ais.filters import Spatial, Temporal, Vessels, Pagination
from oo.db.tables import AISMessageTableMixin
from oo.db.tables import PositionTableMixin

try:
    from sqlalchemy import Select
except ImportError:
    raise ImportError(
        "Module 'oo.db' requires 'sqlalchemy'. "
        "Install it with: pip install openocean[db]"
    )


class DbFilter(abc.ABC):
    @abc.abstractmethod
    def apply(self, statement: Select, table: AISMessageTableMixin) -> Select:
        pass


class SpatialDbFilter(DbFilter, Spatial):
    def apply(self, statement: Select, table: PositionTableMixin) -> Select:
        min_lat, max_lat, min_lon, max_lon = self.encode()
        if min_lat is not None:
            statement = statement.where(table.lat >= min_lat)
        if max_lat is not None:
            statement = statement.where(table.lat <= max_lat)
        if min_lon is not None:
            statement = statement.where(table.lon >= min_lon)
        if max_lon is not None:
            statement = statement.where(table.lon <= max_lon)
        return statement


class TemporalDbFilter(DbFilter, Temporal):
    def apply(self, statement: Select, table: AISMessageTableMixin) -> Select:
        if self.start_time is not None:
            statement = statement.where(table.time >= self.start_time)
        if self.stop_time is not None:
            statement = statement.where(table.time <= self.stop_time)
        return statement


class VesselsDbFilter(DbFilter, Vessels):
    def apply(self, statement: Select, table: AISMessageTableMixin) -> Select:
        if self.mmsi is not None:
            statement = statement.where(table.mmsi.in_(self.mmsi))
        return statement


class PaginationDbFilter(DbFilter, Pagination):
    def apply(self, statement: Select, table: Any) -> Select:
        statement = statement.limit(self.limit).offset((self.page - 1) * self.limit)
        return statement
