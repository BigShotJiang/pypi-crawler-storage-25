# OpenOcean


Get data using the OpenOceanClient:

from oo import OpenOceanClient

client = OpenOceanClient()

data = client.get_positions(decode=True)
