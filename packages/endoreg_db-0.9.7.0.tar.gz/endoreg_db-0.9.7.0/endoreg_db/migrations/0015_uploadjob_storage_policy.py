from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("endoreg_db", "0014_sensitivemeta_tags_sensitivemeta_validation_comment"),
    ]

    operations = [
        migrations.AddField(
            model_name="uploadjob",
            name="cleanup_status",
            field=models.CharField(
                choices=[
                    ("pending", "Pending"),
                    ("eligible", "Eligible"),
                    ("completed", "Completed"),
                    ("skipped", "Skipped"),
                ],
                default="pending",
                help_text="Cleanup state for the persisted source artifact.",
                max_length=64,
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="retention_policy",
            field=models.CharField(
                choices=[
                    ("preserve_source", "Preserve Source"),
                    ("delete_after_success", "Delete After Success"),
                    ("migration_managed", "Migration Managed"),
                ],
                default="preserve_source",
                help_text="Lifecycle policy for the persisted upload artifact.",
                max_length=64,
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="source_file_delete_eligible_at",
            field=models.DateTimeField(
                blank=True,
                help_text="When the persisted source ingest artifact becomes eligible for cleanup.",
                null=True,
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="source_file_persisted",
            field=models.BooleanField(
                default=True,
                help_text="Whether the source ingest artifact is currently expected to remain on disk.",
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="storage_class",
            field=models.CharField(
                choices=[
                    ("ingest", "Ingest"),
                    ("managed", "Managed"),
                    ("quarantine", "Quarantine"),
                ],
                default="ingest",
                help_text="High-level storage lifecycle class for the persisted artifact.",
                max_length=64,
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="storage_tier",
            field=models.CharField(
                choices=[
                    ("upload_api", "API Upload"),
                    ("upload_watcher", "Watcher Upload"),
                    ("upload_preanonymized", "Preanonymized Upload"),
                ],
                default="upload_api",
                help_text="Protected storage tier where the upload artifact is persisted.",
                max_length=64,
            ),
        ),
    ]
