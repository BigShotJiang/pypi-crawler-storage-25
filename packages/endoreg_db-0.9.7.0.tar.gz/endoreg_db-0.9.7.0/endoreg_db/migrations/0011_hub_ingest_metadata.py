from __future__ import annotations

from django.db import migrations, models
from django.utils.text import slugify
import django.db.models.deletion


def populate_center_keys(apps, schema_editor):
    Center = apps.get_model("endoreg_db", "Center")
    used_keys: set[str] = set()

    for center in Center.objects.all().order_by("pk"):
        base = slugify(center.display_name or center.name or "") or "center"
        candidate = base
        suffix = 2
        while candidate in used_keys:
            candidate = f"{base}-{suffix}"
            suffix += 1
        center.center_key = candidate
        center.save(update_fields=["center_key"])
        used_keys.add(candidate)


class Migration(migrations.Migration):
    dependencies = [
        ("endoreg_db", "0010_patientexamination_report_draft"),
    ]

    operations = [
        migrations.AddField(
            model_name="center",
            name="center_key",
            field=models.CharField(blank=True, default="", max_length=255),
            preserve_default=False,
        ),
        migrations.RunPython(populate_center_keys, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="center",
            name="center_key",
            field=models.CharField(blank=True, max_length=255, unique=True),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="created_by",
            field=models.ForeignKey(
                blank=True,
                help_text="Authenticated user who initiated the upload job, if any",
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="created_upload_jobs",
                to="auth.user",
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="idempotency_key",
            field=models.CharField(
                blank=True,
                db_index=True,
                default="",
                help_text="Client-supplied idempotency key for logical deduplication",
                max_length=255,
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="ingest_mode",
            field=models.CharField(
                choices=[("api", "API"), ("watcher", "Watcher")],
                default="api",
                help_text="How the ingest request entered the system",
                max_length=20,
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="original_filename",
            field=models.CharField(
                blank=True,
                default="",
                help_text="Original client-supplied filename",
                max_length=512,
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="processing_provenance",
            field=models.JSONField(
                blank=True,
                default=dict,
                help_text="Additional ingest metadata recorded for audit and processing",
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="source_center",
            field=models.ForeignKey(
                blank=True,
                help_text="Center identity attached to the ingest request",
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="upload_jobs",
                to="endoreg_db.center",
            ),
        ),
        migrations.AddField(
            model_name="uploadjob",
            name="source_system",
            field=models.CharField(
                blank=True,
                default="api",
                help_text="Name of the upstream source system or client",
                max_length=255,
            ),
        ),
    ]
