from __future__ import annotations

import uuid

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("endoreg_db", "0011_hub_ingest_metadata"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="NetworkNode",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("node_key", models.CharField(blank=True, max_length=255, unique=True)),
                ("display_name", models.CharField(max_length=255)),
                (
                    "role",
                    models.CharField(
                        choices=[
                            ("central_hub", "Central Hub"),
                            ("site_node", "Site Node"),
                            ("standalone", "Standalone"),
                        ],
                        default="site_node",
                        max_length=32,
                    ),
                ),
                ("base_url", models.URLField(blank=True, default="")),
                ("is_active", models.BooleanField(default=True)),
                (
                    "shared_secret_hash",
                    models.CharField(blank=True, default="", max_length=255),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "owning_center",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="network_nodes",
                        to="endoreg_db.center",
                    ),
                ),
            ],
            options={"ordering": ["display_name", "pk"]},
        ),
        migrations.CreateModel(
            name="TransferJob",
            fields=[
                (
                    "id",
                    models.UUIDField(
                        default=uuid.uuid4,
                        editable=False,
                        primary_key=True,
                        serialize=False,
                    ),
                ),
                (
                    "transfer_key",
                    models.CharField(db_index=True, max_length=255, unique=True),
                ),
                (
                    "resource_kind",
                    models.CharField(
                        choices=[("video", "Video"), ("report", "Report")],
                        max_length=16,
                    ),
                ),
                ("resource_hash", models.CharField(db_index=True, max_length=255)),
                (
                    "transfer_mode",
                    models.CharField(
                        choices=[
                            ("metadata_only", "Metadata Only"),
                            ("metadata_and_raw_media", "Metadata And Raw Media"),
                            (
                                "metadata_and_processed_media",
                                "Metadata And Processed Media",
                            ),
                            (
                                "metadata_raw_and_processed_media",
                                "Metadata Raw And Processed Media",
                            ),
                        ],
                        default="metadata_only",
                        max_length=48,
                    ),
                ),
                (
                    "transfer_status",
                    models.CharField(
                        choices=[
                            ("pending", "Pending"),
                            ("awaiting_media", "Awaiting Media"),
                            ("applied", "Applied"),
                            ("failed", "Failed"),
                            ("inconsistent", "Inconsistent"),
                        ],
                        default="pending",
                        max_length=32,
                    ),
                ),
                (
                    "processing_policy",
                    models.CharField(
                        choices=[
                            ("reprocess_always", "Reprocess Always"),
                            (
                                "reprocess_if_missing_outputs",
                                "Reprocess If Missing Outputs",
                            ),
                            ("preserve_processing_state", "Preserve Processing State"),
                            ("ingest_only_no_processing", "Ingest Only No Processing"),
                        ],
                        default="preserve_processing_state",
                        max_length=48,
                    ),
                ),
                (
                    "processing_intent",
                    models.CharField(
                        choices=[
                            (
                                "sender_requests_hub_processing",
                                "Sender Requests Hub Processing",
                            ),
                            (
                                "sender_requests_state_preservation",
                                "Sender Requests State Preservation",
                            ),
                            (
                                "sender_requests_archive_only",
                                "Sender Requests Archive Only",
                            ),
                        ],
                        default="sender_requests_state_preservation",
                        max_length=48,
                    ),
                ),
                (
                    "processing_decision",
                    models.CharField(
                        choices=[
                            ("start_processing", "Start Processing"),
                            (
                                "skip_processing_existing_success",
                                "Skip Processing Existing Success",
                            ),
                            (
                                "skip_processing_preserved_state",
                                "Skip Processing Preserved State",
                            ),
                            ("wait_for_missing_media", "Wait For Missing Media"),
                            ("mark_inconsistent", "Mark Inconsistent"),
                            ("reject_transfer", "Reject Transfer"),
                        ],
                        default="wait_for_missing_media",
                        max_length=48,
                    ),
                ),
                (
                    "cleanup_policy",
                    models.CharField(
                        choices=[
                            ("retain_all", "Retain All"),
                            (
                                "delete_central_raw_after_apply",
                                "Delete Central Raw After Apply",
                            ),
                            (
                                "delete_central_raw_after_verified_backup",
                                "Delete Central Raw After Verified Backup",
                            ),
                            (
                                "delete_central_source_after_anonymized_derivatives_exist",
                                "Delete Central Source After Anonymized Derivatives Exist",
                            ),
                        ],
                        default="retain_all",
                        max_length=64,
                    ),
                ),
                (
                    "cleanup_status",
                    models.CharField(
                        choices=[
                            ("pending", "Pending"),
                            ("not_requested", "Not Requested"),
                            ("deferred", "Deferred"),
                            ("completed", "Completed"),
                        ],
                        default="pending",
                        max_length=32,
                    ),
                ),
                (
                    "payload_schema_version",
                    models.CharField(default="1.0", max_length=32),
                ),
                ("resource_rows", models.JSONField(blank=True, default=dict)),
                ("processing_snapshot", models.JSONField(blank=True, default=dict)),
                ("status_detail", models.TextField(blank=True, default="")),
                ("provenance", models.JSONField(blank=True, default=dict)),
                (
                    "target_object_id",
                    models.PositiveBigIntegerField(blank=True, null=True),
                ),
                (
                    "linked_patient_id",
                    models.PositiveBigIntegerField(blank=True, null=True),
                ),
                (
                    "linked_patient_examination_id",
                    models.PositiveBigIntegerField(blank=True, null=True),
                ),
                (
                    "case_resolution_status",
                    models.CharField(
                        choices=[
                            ("pending", "Pending"),
                            ("linked", "Linked"),
                            ("ambiguous", "Ambiguous"),
                            ("unresolved", "Unresolved"),
                        ],
                        default="pending",
                        max_length=24,
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "created_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="created_transfer_jobs",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "source_center",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="transfer_jobs",
                        to="endoreg_db.center",
                    ),
                ),
                (
                    "source_node",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="sent_transfer_jobs",
                        to="endoreg_db.networknode",
                    ),
                ),
                (
                    "target_node",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="received_transfer_jobs",
                        to="endoreg_db.networknode",
                    ),
                ),
                (
                    "upload_job",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="transfer_jobs",
                        to="endoreg_db.uploadjob",
                    ),
                ),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]
