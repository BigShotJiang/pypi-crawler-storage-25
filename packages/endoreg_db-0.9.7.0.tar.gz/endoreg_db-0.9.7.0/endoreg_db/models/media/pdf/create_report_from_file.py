# models/data_file/import_classes/create_pdf_from_file.py
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Type, Union

from endoreg_db.utils.file_operations import get_content_hash_filename
from endoreg_db.utils.hashs import get_pdf_hash
from endoreg_db.utils.paths import IMPORT_REPORT_DIR, SENSITIVE_REPORT_DIR, STORAGE_DIR
from endoreg_db.utils.storage import save_local_file

if TYPE_CHECKING:
    from endoreg_db.models.media.pdf import RawPdfFile

logger = logging.getLogger("raw_pdf")


def _create_from_file(
    cls_model: Type["RawPdfFile"],
    file_path: Union[str, Path],
    center_name: Optional[str] = None,
    save: bool = True,
    **kwargs,
) -> "RawPdfFile":
    """
    Creates a RawPdfFile instance from a given file path, mirroring the video pipeline.
    Handles hashing, orphaned record cleanup, and atomic DB assignment.
    """
    from endoreg_db.models.administration import Center

    # 1. Standardize Path
    if isinstance(file_path, str):
        file_path = Path(file_path)

    if not file_path.exists():
        logger.error(f"Source file does not exist: {file_path}")
        raise FileNotFoundError(f"Source file not found: {file_path}")

    # 2. Pull Center Name (with Environment Fallback)
    if not center_name:
        try:
            center_name = os.environ["CENTER_NAME"]
        except KeyError:
            logger.error("Center name must be provided or set in CENTER_NAME env var.")
            raise ValueError("Center name must be provided.")

    try:
        center = Center.objects.get(name=center_name)
    except Center.DoesNotExist as e:
        logger.error(f"Center '{center_name}' not found.")
        raise ValueError(f"Center '{center_name}' not found.") from e

    # 3. Hash Calculation
    try:
        pdf_hash = get_pdf_hash(file_path)
        logger.debug(f"Calculated PDF hash: {pdf_hash}")
    except Exception as e:
        logger.error(f"Could not calculate hash for {file_path}: {e}")
        raise ValueError(f"Could not calculate hash for {file_path}") from e

    # 4. Handle Existing Records & TOCTOU (Aligned with VideoFile)
    existing_pdf_file = cls_model.objects.filter(pdf_hash=pdf_hash).first()
    if existing_pdf_file:
        logger.warning(
            "RawPdfFile with hash %s already exists (ID: %s)",
            pdf_hash,
            existing_pdf_file.pk,
        )

        # Check if the physical file is still present
        _file = existing_pdf_file.file
        if _file and _file.storage.exists(_file.name):
            logger.warning("File is present. Returning existing instance.")
            return existing_pdf_file

        # Burn orphaned record to stay consistent with VideoFile philosophy
        logger.warning(
            "RawPdfFile exists but file is missing. Deleting orphaned record."
        )
        existing_pdf_file.delete()

    # 5. Create New Record
    new_file_name, _uuid = get_content_hash_filename(file_path)
    try:
        raw_pdf = cls_model(
            pdf_hash=pdf_hash,
            center=center,
            **kwargs,
        )
        save_local_file(raw_pdf.file, file_path, name=new_file_name, save=False)

        if save:
            raw_pdf.save()
            logger.info(f"Successfully created RawPdfFile PK {raw_pdf.pk}")

        return raw_pdf

    except Exception as e:
        logger.error(f"Error processing or saving file {file_path}: {e}")
        raise RuntimeError(f"PDF processing failed: {e}") from e
