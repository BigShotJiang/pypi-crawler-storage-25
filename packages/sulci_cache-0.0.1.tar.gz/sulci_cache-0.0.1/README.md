# sulci-cache

This package name is reserved.

Please install the active package instead:

```bash
pip install sulci
```

The canonical package for Sulci Cache — the AI native 
context-aware semantic cache for LLM apps — is `sulci`.

https://sulci.io
