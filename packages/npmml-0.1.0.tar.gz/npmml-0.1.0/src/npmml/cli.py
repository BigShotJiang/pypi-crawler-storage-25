from __future__ import annotations

import argparse
import sys
from importlib.resources import files

VALID_CODES = ["1", "2", "3", "4a", "4b", "4c", "4d", "4e", "5a", "5b"]


def _data_dir():
    return files("npmml").joinpath("data")


def _read_code(code: str) -> str:
    path = _data_dir().joinpath(f"{code}.txt")
    return path.read_text(encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="npmml", description="Show lab code files")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List available code keys")

    show = sub.add_parser("show", help="Show a code file by key")
    show.add_argument("code", choices=VALID_CODES, help="Code key: 1, 2, 3, 4a..5b")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "list":
        print(" ".join(VALID_CODES))
        return 0

    if args.command == "show":
        print(_read_code(args.code))
        return 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
