# npmml

A small Python CLI package that shows your lab code files.

## Usage

```bash
npmml list
npmml show 1
npmml show 4c
```

`show` accepts: `1`, `2`, `3`, `4a`, `4b`, `4c`, `4d`, `4e`, `5a`, `5b`.
