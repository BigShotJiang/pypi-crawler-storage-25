from __future__ import annotations
import sys
from pathlib import Path
import pytest

def pytest_addoption(parser):
    g = parser.getgroup('velvet_report', 'VelvetReport HTML Reporter')
    g.addoption('--vReport-title',   default=None)
    g.addoption('--vReport-output',  default=None)
    g.addoption('--vReport-history', default=None)
    g.addoption('--vReport-xml',     default=None)
    g.addoption('--vReport-open',    action='store_true', default=False)
    g.addoption('--vReport-disable', action='store_true', default=False)
    g.addoption('--vReport-email',   action='store_true', default=False)
    parser.addini('vReport_Title',   default='',       help='Report title')
    parser.addini('vReport_output',  default='reports', help='Output folder for velvetreport.html')
    parser.addini('vReport_history', default='',       help='History folder (default: <output>/.history)')
    parser.addini('vReport_xml',     default='',       help='Path to JUnit XML (blank = auto-generate)')
    parser.addini('vReport_open',    default='false',  help='Auto-open browser (true/false)')
    parser.addini('vReport_disable', default='false',  help='Disable VelvetReport (true/false)')
    parser.addini('vReport_email',   default='false',  help='Generate email HTML summary (true/false)')

def pytest_configure(config):
    if _dis(config):
        sys.stdout.write('[VelvetReport] Disabled via vReport_disable\n')
        return
    user_xml = _opt(config, 'vReport_xml', '--vReport-xml', None)
    if user_xml:
        sys.stdout.write('[VelvetReport] Using user XML: ' + user_xml + '\n')
    else:
        auto_xml = str(Path(_out(config)) / '.velvetreport_junit.xml')
        if not getattr(config.option, 'xmlpath', None):
            config.option.xmlpath = auto_xml
    Path(_out(config)).mkdir(parents=True, exist_ok=True)

@pytest.hookimpl(trylast=True)
def pytest_sessionfinish(session, exitstatus):
    config = session.config
    if _dis(config): return
    user_xml = _opt(config, 'vReport_xml', '--vReport-xml', None)
    if user_xml:
        xml = Path(user_xml)
    else:
        xmlpath_attr = getattr(config.option, 'xmlpath', None)
        xml = Path(xmlpath_attr) if xmlpath_attr else Path(_out(config)) / '.velvetreport_junit.xml'
    out   = Path(_out(config))
    hist  = Path(_hist(config, out))
    title = _title(config, xml)
    auto_open = bool(_opt(config, 'vReport_open', '--vReport-open', False))
    email_en  = _opt(config, 'vReport_email', '--vReport-email', False) in (True, 'true', 'True', '1')
    sys.stdout.write('\n[VelvetReport] ==============================\n')
    sys.stdout.write('[VelvetReport] Looking for XML : ' + str(xml.resolve()) + '\n')
    if not xml.exists():
        sys.stderr.write('[VelvetReport] WARNING  : XML not found at ' + str(xml.resolve()) + '\n')
        sys.stderr.write('[VelvetReport] FIX      : Add to pytest.ini  ->  vReport_xml = path/to/junit.xml\n')
        sys.stdout.write('[VelvetReport] ==============================\n\n')
        return
    xml_size = xml.stat().st_size
    sys.stdout.write('[VelvetReport] XML found   : ' + str(xml_size) + ' bytes\n')
    hist.mkdir(parents=True, exist_ok=True)
    prev_runs = len(list(hist.glob('run_*.json')))
    sys.stdout.write('[VelvetReport] Output dir  : ' + str(out.resolve()) + '\n')
    sys.stdout.write('[VelvetReport] History runs: ' + str(prev_runs) + ' previous run(s)\n')
    sys.stdout.write('[VelvetReport] Processing  : Generating report...\n')
    try:
        from velvet_report.generator import generate_report
        report_path = generate_report(xml, out, history_dir=hist, title=title, open_browser=auto_open, email_en=email_en)
        sys.stdout.write('[VelvetReport] OK Report   : ' + str(report_path.resolve()) + '\n')
        if email_en:
            sys.stdout.write('[VelvetReport] OK Email    : ' + str((out / 'velvetreport_email.html').resolve()) + '\n')
        sys.stdout.write('[VelvetReport] ==============================\n\n')
    except Exception as exc:
        sys.stderr.write('[VelvetReport] ERROR: ' + str(exc).replace('\n', ' ') + '\n')
        import traceback; traceback.print_exc()

def _opt(c, ini_key, cli_flag, default):
    attr = cli_flag.lstrip('-').replace('-', '_')
    v = getattr(c.option, attr, None)
    if v is not None and v != default: return v
    try:
        iv = c.getini(ini_key)
        if iv and iv not in ('false', ''): return iv
    except (ValueError, KeyError): pass
    return default

def _dis(c): return _opt(c,'vReport_disable','--vReport-disable',False) in (True,'true','True','1')
def _out(c): return _opt(c,'vReport_output','--vReport-output','reports')
def _hist(c,out):
    v=_opt(c,'vReport_history','--vReport-history',None)
    return v if v else str(out/'.history')
def _title(c,xml):
    v=_opt(c,'vReport_Title','--vReport-title',None)
    return v if v else xml.stem