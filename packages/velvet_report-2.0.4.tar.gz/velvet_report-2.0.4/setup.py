from setuptools import setup, find_packages
setup(
    name="velvet-report", version="2.0.4",
    description="VelvetReport — Universal JUnit XML to self-contained offline HTML test reporter. Works with pytest, Playwright, Maven, Jest, Cypress, Robot Framework.",
    long_description=open("README.md",encoding="utf-8").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="VelvetReport Contributors", author_email="hello@velvetreport.dev",
    url="https://github.com/velvetreport/velvet-report",
    packages=find_packages(where="src"), package_dir={"":"src"},
    package_data={"velvet_report":["template.html"]}, include_package_data=True,
    python_requires=">=3.8",
    entry_points={"console_scripts":["velvet-report=velvet_report.cli:main"],"pytest11":["velvet_report=velvet_report.pytest_plugin"]},
    keywords="velvet-report test-report junit pytest playwright html-report offline allure-alternative extent-report robot-framework ci-report test-results velvetreport",
    classifiers=["Development Status :: 5 - Production/Stable","Framework :: Pytest","License :: OSI Approved :: MIT License","Programming Language :: Python :: 3","Topic :: Software Development :: Testing","Topic :: Software Development :: Quality Assurance"],
)
