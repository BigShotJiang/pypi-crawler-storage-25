"""
:mod:`etlplus.utils._substitution` module.

Substitution utility helpers.
"""

from __future__ import annotations

from collections.abc import Iterable
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from ._mapping import MappingParser
from ._types import StrAnyMap

# SECTION: EXPORTS ========================================================== #


__all__ = [
    # Classes
    'SubstitutionResolver',
]


# SECTION: INTERNAL FUNCTIONS =============================================== #


def _prepare_substitutions(
    vars_map: StrAnyMap | None,
    env_map: Mapping[str, object] | None,
) -> tuple[tuple[str, Any], ...]:
    """
    Merge variable and environment maps into an ordered substitutions list.

    Parameters
    ----------
    vars_map : StrAnyMap | None
        Mapping of variable names to replacement values (lower precedence).
    env_map : Mapping[str, object] | None
        Environment-backed values that override entries from *vars_map*.

    Returns
    -------
    tuple[tuple[str, Any], ...]
        Immutable sequence of ``(name, value)`` pairs suitable for token
        replacement.
    """
    if not vars_map and not env_map:
        return ()
    return tuple(MappingParser.merge_to_dict(vars_map, env_map).items())


def _replace_tokens(
    text: str,
    substitutions: Iterable[tuple[str, Any]],
) -> str:
    """
    Replace ``${VAR}`` tokens in *text* using *substitutions*.

    Parameters
    ----------
    text : str
        Input string that may contain ``${VAR}`` tokens.
    substitutions : Iterable[tuple[str, Any]]
        Sequence of ``(name, value)`` pairs used for token replacement.

    Returns
    -------
    str
        Updated text with replacements applied.
    """
    out = text
    for name, replacement in substitutions:
        token = f'${{{name}}}'
        if token in out:
            out = out.replace(token, str(replacement))
    return out


# SECTION: DATA CLASSES ===================================================== #


@dataclass(frozen=True, slots=True)
class SubstitutionResolver:
    """
    Resolve token substitutions across nested Python containers.

    Attributes
    ----------
    vars_map : StrAnyMap | None
        Mapping of variable names to replacement values (lower precedence).
    env_map : Mapping[str, object] | None
        Mapping of environment variables overriding *vars_map* values (higher
        precedence).
    """

    vars_map: StrAnyMap | None = None
    env_map: Mapping[str, object] | None = None

    # -- Getters -- #

    @property
    def substitutions(self) -> tuple[tuple[str, Any], ...]:
        """Return merged substitutions in replacement order."""
        return _prepare_substitutions(self.vars_map, self.env_map)

    # -- Instance Methods -- #

    def deep(
        self,
        value: Any,
    ) -> Any:
        """
        Recursively substitute ``${VAR}`` tokens in nested structures.

        Only strings are substituted; other types are returned as-is.

        Parameters
        ----------
        value : Any
            The value to perform substitutions on.

        Returns
        -------
        Any
            New structure with substitutions applied where tokens were found.
        """
        substitutions = self.substitutions
        if not substitutions:
            return value

        def _apply(node: Any) -> Any:
            match node:
                case str():
                    return _replace_tokens(node, substitutions)
                case Mapping():
                    return {k: _apply(v) for k, v in node.items()}
                case list() | tuple() as seq:
                    resolved = [_apply(item) for item in seq]
                    return resolved if isinstance(seq, list) else tuple(resolved)
                case set():
                    return {_apply(item) for item in node}
                case frozenset():
                    return frozenset(_apply(item) for item in node)
                case _:
                    return node

        return _apply(value)
