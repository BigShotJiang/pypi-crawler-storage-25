"""Sherpa Consolidation processor"""

__version__ = "1.8.19"
