# what_code

A coding agent you control from WhatsApp. Send a text or voice message, and it writes code directly on your machine.

Built with MiniMax-M2.7, Groq Whisper, and Twilio.

## Install

```bash
pip install what-code
```

## Setup (~5 minutes)

Run the interactive setup wizard:

```bash
what_code setup
```

It walks you through creating 3 free accounts and entering your API keys:

| Service | What it does | Sign up |
|---------|-------------|---------|
| **MiniMax** | Powers the AI agent + voice replies | [platform.minimaxi.com](https://platform.minimaxi.com) |
| **Groq** | Transcribes your voice notes | [console.groq.com](https://console.groq.com) |
| **Twilio** | Sends/receives WhatsApp messages | [twilio.com/try-twilio](https://www.twilio.com/try-twilio) |

All three have free tiers. No credit card required.

## Start

```bash
what_code start
```

The CLI will guide you through:

1. **Webhook URL** -- copy it into your Twilio Sandbox settings
2. **QR code** -- scan it to connect your WhatsApp
3. **Start coding** -- send a message and the agent builds it

## What can it do?

Send messages like:

- `"create a flask API with user authentication"`
- `"read the files in my project folder"`
- `"fix the bug in app.py"`
- Or send a **voice note** -- it understands speech too

The agent has full access to your filesystem. It can read, write, and run commands on your machine.

## WhatsApp Commands

| Command | Action |
|---------|--------|
| `\help` | List commands |
| `\clear` | Reset conversation |
| `\pwd` | Show working directory |
| `\cd <path>` | Change directory |
| `\ls` | List files |
| `\history` | Conversation summary |

## How it works

```
You (WhatsApp) --> Twilio --> ngrok --> FastAPI server --> MiniMax-M2.7
                                                              |
                                                         Tool calls:
                                                         - read_file
                                                         - write_file
                                                         - run_command
                                                         - list_directory
                                                         - make_directory
```

Voice notes are transcribed with Groq Whisper, and voice replies use MiniMax TTS.

## License

MIT
