import json
import os
import re
from openai import OpenAI
from coding_agent.tools import TOOL_MAP

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file at the given absolute path.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Absolute file path"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to a file at the given absolute path. Creates parent directories automatically.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute file path"},
                    "content": {"type": "string", "description": "Content to write"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": "List files and directories at the given absolute path.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Absolute directory path"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Run a shell command in the specified working directory. Timeout: 120 seconds.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Shell command to execute"},
                    "cwd": {"type": "string", "description": "Working directory for the command"},
                },
                "required": ["command", "cwd"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "make_directory",
            "description": "Create a directory (and any parent directories) at the given absolute path.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Absolute directory path"}},
                "required": ["path"],
            },
        },
    },
]

SYSTEM_PROMPT = """You are a coding agent running on the user's machine with full filesystem access.

RULES:
- Always use absolute paths.
- Current working directory: {cwd}
- Be concise — your replies go to WhatsApp. Keep responses under 1500 characters.
- Don't ask questions. Make reasonable assumptions and execute.
- If you encounter an error, read the output, self-correct, and retry.
- When creating files, use the current working directory as the base unless told otherwise.

FORMATTING (WhatsApp — NOT Markdown):
- Bold: *text* (NOT **text**)
- Italic: _text_ (NOT *text*)
- Strikethrough: ~text~
- Monospace: ```text``` (for code snippets or file names)
- NO Markdown headers (#), NO bullet dashes (-), NO [links](url)
- Use line breaks and emojis to structure your replies cleanly
- For lists, use emojis or numbers:
  1. First item
  2. Second item
- Keep it visual and scannable — this is a phone screen, not a terminal"""


def run_agent(user_message: str, conversation_history: list, cwd: str) -> tuple[str, list]:
    client = OpenAI(
        api_key=os.environ["MINIMAX_API_KEY"],
        base_url="https://api.minimax.io/v1",
    )

    system = {"role": "system", "content": SYSTEM_PROMPT.format(cwd=cwd)}
    conversation_history.append({"role": "user", "content": user_message})

    for _ in range(25):
        messages = [system] + conversation_history
        response = client.chat.completions.create(
            model="MiniMax-M2.7",
            messages=messages,
            tools=TOOLS,
            tool_choice="auto",
        )
        choice = response.choices[0]

        # Preserve the full assistant message (including <think> blocks)
        assistant_msg = choice.message.model_dump()
        conversation_history.append(assistant_msg)

        if not choice.message.tool_calls:
            reply = choice.message.content or "(no response)"
            # Strip <think> blocks from user-facing reply (kept in history for MiniMax)
            reply = re.sub(r"<think>[\s\S]*?</think>\s*", "", reply).strip()
            return reply or "(no response)", conversation_history

        # Execute each tool call
        for tc in choice.message.tool_calls:
            fn_name = tc.function.name
            try:
                args = json.loads(tc.function.arguments)
            except json.JSONDecodeError:
                args = {}

            fn = TOOL_MAP.get(fn_name)
            if fn:
                result = fn(**args)
            else:
                result = f"Unknown tool: {fn_name}"

            conversation_history.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": result,
            })

    return "I hit the maximum number of steps. Here's where I got to — please send a follow-up message if you need me to continue.", conversation_history
