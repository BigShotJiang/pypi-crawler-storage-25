import os
import sys
from pathlib import Path

import click
import qrcode
import uvicorn
from dotenv import load_dotenv
from pyngrok import ngrok

CONFIG_DIR = Path.home() / ".what_code"
ENV_FILE = CONFIG_DIR / ".env"

BANNER = r"""
 __      __  __    __       ___   .___________.     ______   ______   _______   _______
|  |    |  ||  |  |  |     /   \  |           |    /      | /  __  \ |       \ |   ____|
|  |    |  ||  |__|  |    /  ^  \ `---|  |----`   |  ,----'|  |  |  ||  .--.  ||  |__
|  |/\  |  ||   __   |   /  /_\  \   |  |        |  |     |  |  |  ||  |  |  ||   __|
|        /  |  |  |  |  /  _____  \  |  |        |  `----.|  `--'  ||  '--'  ||  |____
 \__/\__/   |__|  |__| /__/     \__\ |__|         \______| \______/ |_______/ |_______|

  Control a coding agent from WhatsApp
"""


def _divider():
    click.secho("  " + "-" * 60, fg="bright_black")


def _step_header(step_num, total, title, description):
    click.echo()
    _divider()
    click.secho(f"  STEP {step_num}/{total}: {title}", fg="yellow", bold=True)
    click.secho(f"  {description}", fg="bright_black")
    _divider()


def _prompt_key(key_name, label, instructions):
    """Prompt for a single key with clear instructions."""
    click.echo()
    click.secho(f"    {label}", fg="cyan", bold=True)
    for line in instructions:
        click.secho(f"    {line}", fg="bright_black")
    click.echo()

    existing = os.environ.get(key_name, "")
    if existing:
        masked = existing[:6] + "..." + existing[-4:] if len(existing) > 12 else existing[:6] + "..."
        click.secho(f"    Current value: {masked}", fg="bright_black")

    while True:
        value = click.prompt(f"    {key_name}", default=existing or "", show_default=False)
        value = value.strip()
        if value:
            return value
        click.secho("    This field is required. Please enter a value.", fg="red")


def _validate_key_format(key_name, value):
    """Basic format validation for keys."""
    if key_name == "TWILIO_ACCOUNT_SID" and not value.startswith("AC"):
        click.secho("    Warning: Twilio Account SID usually starts with 'AC'", fg="red")
        if not click.confirm("    Continue anyway?", default=True):
            return False
    if key_name == "TWILIO_WHATSAPP_NUMBER" and not value.startswith("+"):
        click.secho("    Warning: Phone number should start with '+' (e.g. +14155238886)", fg="red")
        if not click.confirm("    Continue anyway?", default=True):
            return False
    return True


@click.group()
def main():
    """what_code -- Control a coding agent from WhatsApp."""
    pass


@main.command()
def setup():
    """Interactive setup: get your API keys and connect WhatsApp."""
    click.echo(BANNER)
    click.secho("  WELCOME TO WHAT_CODE SETUP", fg="green", bold=True)
    click.echo()
    click.echo("  This wizard will walk you through getting 3 free API accounts")
    click.echo("  and connecting your WhatsApp to a coding agent on your machine.")
    click.echo()
    click.echo("  You'll need:")
    click.echo("    1. A MiniMax account   (AI model - powers the agent)")
    click.echo("    2. A Groq account      (transcribes voice notes)")
    click.echo("    3. A Twilio account    (WhatsApp messaging)")
    click.echo()
    click.secho("  All three have free tiers. Total setup time: ~5 minutes.", fg="bright_black")

    if not click.confirm("\n  Ready to begin?", default=True):
        click.echo("  Run 'what_code setup' whenever you're ready.\n")
        return

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    if ENV_FILE.exists():
        load_dotenv(ENV_FILE)
        click.echo()
        click.secho("  Found existing config. Press Enter to keep current values.", fg="bright_black")

    values = {}

    # ================================================================
    # STEP 1: MiniMax
    # ================================================================
    _step_header(1, 3, "MiniMax API Key", "This powers the AI model and text-to-speech voice replies.")

    click.echo()
    click.secho("    How to get your MiniMax API key:", fg="white", bold=True)
    click.echo("    1. Go to https://platform.minimaxi.com")
    click.echo("    2. Sign up / log in")
    click.echo("    3. Go to API Keys page:")
    click.secho("       https://platform.minimaxi.com/user-center/basic-information/interface-key", fg="green")
    click.echo("    4. Create a new API key and copy it")

    while True:
        value = _prompt_key(
            "MINIMAX_API_KEY",
            "MiniMax API Key",
            ["Paste the API key you just copied:"],
        )
        values["MINIMAX_API_KEY"] = value
        break

    click.secho("    MiniMax key saved!", fg="green")

    # ================================================================
    # STEP 2: Groq
    # ================================================================
    _step_header(2, 3, "Groq API Key", "This transcribes voice notes you send on WhatsApp.")

    click.echo()
    click.secho("    How to get your Groq API key:", fg="white", bold=True)
    click.echo("    1. Go to https://console.groq.com")
    click.echo("    2. Sign up / log in")
    click.echo("    3. Go to API Keys:")
    click.secho("       https://console.groq.com/keys", fg="green")
    click.echo("    4. Create a new API key and copy it")

    while True:
        value = _prompt_key(
            "GROQ_API_KEY",
            "Groq API Key",
            ["Paste the API key you just copied:"],
        )
        values["GROQ_API_KEY"] = value
        break

    click.secho("    Groq key saved!", fg="green")

    # ================================================================
    # STEP 3: Twilio (4 values)
    # ================================================================
    _step_header(3, 3, "Twilio (WhatsApp)", "This lets you send and receive WhatsApp messages.")

    click.echo()
    click.secho("    How to set up Twilio:", fg="white", bold=True)
    click.echo("    1. Go to https://www.twilio.com/try-twilio")
    click.echo("    2. Sign up for a free account (no credit card needed)")
    click.echo("    3. Once logged in, you'll land on the Console Dashboard")
    click.echo()

    # Account SID
    click.secho("    --- Account SID ---", fg="white", bold=True)
    click.echo("    Found on your Twilio Console Dashboard (starts with 'AC')")
    click.secho("    https://console.twilio.com", fg="green")

    while True:
        value = _prompt_key(
            "TWILIO_ACCOUNT_SID",
            "Twilio Account SID",
            ["Copy the Account SID from your dashboard:"],
        )
        if _validate_key_format("TWILIO_ACCOUNT_SID", value):
            values["TWILIO_ACCOUNT_SID"] = value
            break

    # Auth Token
    click.echo()
    click.secho("    --- Auth Token ---", fg="white", bold=True)
    click.echo("    On the same dashboard page, click 'Show' next to Auth Token")

    while True:
        value = _prompt_key(
            "TWILIO_AUTH_TOKEN",
            "Twilio Auth Token",
            ["Copy the Auth Token:"],
        )
        values["TWILIO_AUTH_TOKEN"] = value
        break

    # WhatsApp number
    click.echo()
    click.secho("    --- WhatsApp Sandbox Number ---", fg="white", bold=True)
    click.echo("    1. In Twilio Console, go to:")
    click.echo("       Messaging > Try it out > Send a WhatsApp message")
    click.secho("       https://console.twilio.com/us1/develop/sms/try-it-out/whatsapp-learn", fg="green")
    click.echo("    2. You'll see a phone number (usually +14155238886)")

    while True:
        value = _prompt_key(
            "TWILIO_WHATSAPP_NUMBER",
            "WhatsApp Sandbox Number",
            ["Enter the number shown (e.g. +14155238886):"],
        )
        if _validate_key_format("TWILIO_WHATSAPP_NUMBER", value):
            values["TWILIO_WHATSAPP_NUMBER"] = value
            break

    # Sandbox code
    click.echo()
    click.secho("    --- Sandbox Join Code ---", fg="white", bold=True)
    click.echo("    On the same page, you'll see a code like 'join yellow-horse'")
    click.echo("    This is what you send on WhatsApp to connect to the sandbox")

    while True:
        value = _prompt_key(
            "TWILIO_SANDBOX_CODE",
            "Sandbox Join Code",
            ["Enter the full code (e.g. 'join yellow-horse'):"],
        )
        values["TWILIO_SANDBOX_CODE"] = value
        break

    click.secho("    Twilio setup complete!", fg="green")

    # ================================================================
    # Save everything
    # ================================================================
    click.echo()
    _divider()

    with open(ENV_FILE, "w") as f:
        for k, v in values.items():
            f.write(f"{k}={v}\n")

    click.echo()
    click.secho("  ALL DONE!", fg="green", bold=True)
    click.secho(f"  Config saved to: {ENV_FILE}", fg="bright_black")

    click.echo()
    click.secho("  WHAT'S NEXT:", fg="yellow", bold=True)
    click.echo()
    click.echo("  1. Run this command to start the agent:")
    click.echo()
    click.secho("     what_code start", fg="green", bold=True)
    click.echo()
    click.echo("  2. It will give you a webhook URL to paste into Twilio")
    click.echo("  3. Then scan the QR code to connect WhatsApp")
    click.echo("  4. Send a message and start coding!")
    click.echo()
    _divider()
    click.echo()


@main.command()
@click.option("--port", default=5000, help="Server port")
@click.option("--sandbox-code", default=None, help='Override sandbox code (e.g. "join yellow-horse")')
def start(port, sandbox_code):
    """Start the WhatsApp coding agent server."""
    if not ENV_FILE.exists():
        click.echo()
        click.secho("  No config found!", fg="red", bold=True)
        click.echo("  Run this first:")
        click.echo()
        click.secho("    what_code setup", fg="green", bold=True)
        click.echo()
        raise SystemExit(1)

    load_dotenv(ENV_FILE)

    # Use saved sandbox code if not provided via flag
    if not sandbox_code:
        sandbox_code = os.environ.get("TWILIO_SANDBOX_CODE", "")

    click.echo(BANNER)

    # ── Start ngrok ─────────────────────────────────────────
    click.secho("  Connecting to ngrok...", fg="bright_black")
    try:
        tunnel = ngrok.connect(port)
    except Exception as e:
        click.secho(f"\n  ngrok failed: {e}", fg="red")
        click.echo("  Make sure ngrok is installed and up to date:")
        click.secho("    ngrok update", fg="yellow")
        click.echo("  Or download from: https://ngrok.com/download\n")
        raise SystemExit(1)

    public_url = tunnel.public_url

    from coding_agent import server
    server.ngrok_url = public_url

    webhook_url = f"{public_url}/webhook"

    # ── Step 1: Webhook ─────────────────────────────────────
    click.echo()
    _divider()
    click.secho("  STEP 1: Set your Twilio webhook", fg="yellow", bold=True)
    _divider()
    click.echo()
    click.echo("  Open Twilio Sandbox Settings:")
    click.secho("  https://console.twilio.com/us1/develop/sms/try-it-out/whatsapp-learn", fg="bright_black")
    click.echo("  Click the 'Sandbox settings' tab")
    click.echo()
    click.echo('  Set "When a message comes in" to:')
    click.echo()
    click.secho(f"  >>> {webhook_url} <<<", fg="green", bold=True)
    click.echo()
    click.echo("  Method: POST")
    click.echo("  Then click Save.")

    # ── Step 2: Connect WhatsApp ────────────────────────────
    click.echo()
    _divider()
    click.secho("  STEP 2: Connect your WhatsApp", fg="yellow", bold=True)
    _divider()

    if sandbox_code:
        wa_number = os.environ.get("TWILIO_WHATSAPP_NUMBER", "").lstrip("+")
        wa_link = f"https://wa.me/{wa_number}?text={sandbox_code}"

        click.echo()
        click.echo(f'  Send "{sandbox_code}" to +{wa_number}')
        click.echo("  Or scan this QR code with your phone camera:")
        click.echo()

        qr = qrcode.QRCode(box_size=1, border=1)
        qr.add_data(wa_link)
        qr.make()
        qr.print_ascii(invert=True)
    else:
        click.echo()
        click.echo("  Send your sandbox join code to your Twilio WhatsApp number.")
        click.echo()
        click.secho("  TIP: Run 'what_code setup' to save your sandbox code", fg="bright_black")
        click.echo("  and get a QR code here automatically.\n")

    # ── Step 3: Start coding ────────────────────────────────
    click.echo()
    _divider()
    click.secho("  STEP 3: Start coding!", fg="yellow", bold=True)
    _divider()
    click.echo()
    click.echo("  Once connected, send any message on WhatsApp like:")
    click.echo()
    click.secho('    "create a todo app in python"', fg="cyan")
    click.secho('    "read the files in my Desktop"', fg="cyan")
    click.secho('    "fix the bug in app.py"', fg="cyan")
    click.echo()
    click.echo("  Or send a voice note -- the agent understands speech too!")

    # ── Server ready ────────────────────────────────────────
    click.echo()
    _divider()
    click.secho(f"  SERVER RUNNING on 0.0.0.0:{port}", fg="green", bold=True)
    click.secho(f"  Webhook: {webhook_url}", fg="bright_black")
    click.secho("  Press Ctrl+C to stop", fg="bright_black")
    _divider()
    click.echo()

    uvicorn.run("coding_agent.server:app", host="0.0.0.0", port=port, log_level="warning")


if __name__ == "__main__":
    main()
