import os
import httpx
from groq import Groq


def transcribe(audio_bytes: bytes) -> str:
    groq_client = Groq(api_key=os.environ["GROQ_API_KEY"])
    transcription = groq_client.audio.transcriptions.create(
        model="whisper-large-v3",
        file=("voice.ogg", audio_bytes),
    )
    return transcription.text


def synthesize(text: str) -> bytes:
    api_key = os.environ["MINIMAX_API_KEY"]
    response = httpx.post(
        "https://api.minimax.io/v1/t2a_v2",
        headers={"Authorization": f"Bearer {api_key}"},
        json={
            "model": "speech-02-turbo",
            "text": text,
            "voice_setting": {"voice_id": "English_Male_1"},
        },
        timeout=30,
    )
    response.raise_for_status()
    return response.content


def download_twilio_media(media_url: str) -> bytes:
    sid = os.environ["TWILIO_ACCOUNT_SID"]
    token = os.environ["TWILIO_AUTH_TOKEN"]
    response = httpx.get(media_url, auth=(sid, token), timeout=30)
    response.raise_for_status()
    return response.content
