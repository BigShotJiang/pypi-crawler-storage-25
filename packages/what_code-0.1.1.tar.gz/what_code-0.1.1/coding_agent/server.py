import os
import uuid
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, Form, Request
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from twilio.rest import Client as TwilioClient

from coding_agent.agent import run_agent
from coding_agent.voice import download_twilio_media, synthesize, transcribe

app = FastAPI()

# In-memory per-user state
conversations: dict[str, list] = {}
cwd: dict[str, str] = {}

AUDIO_DIR = Path(".tmp/audio")
AUDIO_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/audio", StaticFiles(directory=str(AUDIO_DIR)), name="audio")

# Will be set by cli.py after ngrok starts
ngrok_url: str = ""


def get_cwd(sender: str) -> str:
    if sender not in cwd:
        cwd[sender] = str(Path.home())
    return cwd[sender]


def format_reply(sender: str, text: str) -> str:
    return f"\U0001f4c2 {get_cwd(sender)}\n{text}"


def send_whatsapp(to: str, body: str, media_url: str | None = None):
    client = TwilioClient(
        os.environ["TWILIO_ACCOUNT_SID"],
        os.environ["TWILIO_AUTH_TOKEN"],
    )
    kwargs = {
        "from_": f'whatsapp:{os.environ["TWILIO_WHATSAPP_NUMBER"]}',
        "to": to,
        "body": body,
    }
    if media_url:
        kwargs["media_url"] = [media_url]
    client.messages.create(**kwargs)


# ── Slash commands ──────────────────────────────────────────────────

HELP_TEXT = (
    "Available commands:\n"
    "\\help  — Show this message\n"
    "\\clear — Wipe conversation history\n"
    "\\pwd   — Show current directory\n"
    "\\cd <path> — Change directory\n"
    "\\ls    — List files in current dir\n"
    "\\history — Show conversation summary"
)


def handle_slash(sender: str, body: str) -> str | None:
    cmd = body.strip()
    if cmd == "\\help":
        return HELP_TEXT
    if cmd == "\\clear":
        conversations.pop(sender, None)
        cwd[sender] = str(Path.home())
        return "Conversation cleared, directory reset."
    if cmd == "\\pwd":
        return get_cwd(sender)
    if cmd.startswith("\\cd "):
        target = cmd[4:].strip()
        target = os.path.expanduser(target)
        if not os.path.isabs(target):
            target = os.path.join(get_cwd(sender), target)
        target = os.path.normpath(target)
        if os.path.isdir(target):
            cwd[sender] = target
            return f"Changed to {target}"
        return f"Not a directory: {target}"
    if cmd == "\\ls":
        try:
            entries = sorted(os.listdir(get_cwd(sender)))
            lines = []
            for e in entries:
                full = os.path.join(get_cwd(sender), e)
                prefix = "\U0001f4c1" if os.path.isdir(full) else "\U0001f4c4"
                lines.append(f"{prefix} {e}")
            return "\n".join(lines) if lines else "(empty directory)"
        except Exception as exc:
            return f"Error: {exc}"
    if cmd == "\\history":
        hist = conversations.get(sender, [])
        if not hist:
            return "No conversation history."
        turns = sum(1 for m in hist if m.get("role") == "user")
        return f"{turns} message(s) in this conversation."
    return None


# ── Background agent task ───────────────────────────────────────────

async def run_agent_and_reply(sender: str, body: str, is_voice: bool):
    history = conversations.get(sender, [])
    user_cwd = get_cwd(sender)

    reply, updated_history = run_agent(body, history, user_cwd)
    conversations[sender] = updated_history

    formatted = format_reply(sender, reply)

    if is_voice:
        try:
            audio_bytes = synthesize(reply)
            filename = f"reply_{uuid.uuid4().hex[:8]}.mp3"
            filepath = AUDIO_DIR / filename
            filepath.write_bytes(audio_bytes)
            audio_url = f"{ngrok_url}/audio/{filename}"
            send_whatsapp(sender, formatted, media_url=audio_url)
        except Exception:
            send_whatsapp(sender, formatted)
    else:
        send_whatsapp(sender, formatted)


# ── Webhook ─────────────────────────────────────────────────────────

@app.post("/webhook")
async def webhook(
    background_tasks: BackgroundTasks,
    From: str = Form(""),
    Body: str = Form(""),
    NumMedia: str = Form("0"),
    MediaUrl0: str = Form(""),
    MediaContentType0: str = Form(""),
):
    sender = From
    body = Body.strip()
    is_voice = False

    # Handle voice notes
    if int(NumMedia) > 0 and MediaContentType0.startswith("audio/"):
        try:
            audio_bytes = download_twilio_media(MediaUrl0)
            body = transcribe(audio_bytes)
            is_voice = True
        except Exception as e:
            send_whatsapp(sender, format_reply(sender, f"Could not process voice note: {e}"))
            return Response(content="<Response/>", media_type="application/xml")

    # Check slash commands first
    slash_result = handle_slash(sender, body)
    if slash_result is not None:
        send_whatsapp(sender, format_reply(sender, slash_result))
        return Response(content="<Response/>", media_type="application/xml")

    # Run agent in background
    background_tasks.add_task(run_agent_and_reply, sender, body, is_voice)
    return Response(content="<Response/>", media_type="application/xml")
