﻿from __future__ import annotations

from typing import Any

from ..paths import APP_VERSION

# ---------------------------------------------------------------------------
# Translation dictionaries
# ---------------------------------------------------------------------------

_STRINGS: dict[str, dict[str, str]] = {
    # ---- Main window ----
    "app_title":                {"en": "BoardyPy — MicroPython IDE",       "ru": "BoardyPy — MicroPython IDE"},
    "ready":                    {"en": "Ready",                             "ru": "Готово"},
    "no_device_connected":      {"en": "No device connected",              "ru": "Устройство не подключено"},

    # ---- Menus ----
    "menu_file":                {"en": "&File",                             "ru": "&Файл"},
    "menu_edit":                {"en": "&Edit",                             "ru": "&Редактирование"},
    "menu_view":                {"en": "&View",                             "ru": "&Вид"},
    "menu_device":              {"en": "&Device",                           "ru": "&Устройство"},
    "menu_run":                 {"en": "&Run",                              "ru": "&Запуск"},
    "menu_settings":            {"en": "&Settings",                         "ru": "&Настройки"},
    "menu_tools":               {"en": "&Tools",                            "ru": "&Инструменты"},
    "menu_help":                {"en": "&Help",                             "ru": "&Помощь"},

    # File menu
    "action_new":               {"en": "&New",                              "ru": "&Новый"},
    "action_open":              {"en": "&Open...",                          "ru": "&Открыть..."},
    "action_save":              {"en": "&Save",                             "ru": "&Сохранить"},
    "action_save_as":           {"en": "Save &As...",                       "ru": "Сохранить &как..."},
    "action_close_tab":         {"en": "&Close Tab",                        "ru": "&Закрыть вкладку"},
    "action_exit":              {"en": "E&xit",                             "ru": "В&ыход"},

    # Edit menu
    "action_undo":              {"en": "&Undo",                             "ru": "&Отменить"},
    "action_redo":              {"en": "&Redo",                             "ru": "&Повторить"},
    "action_cut":               {"en": "Cu&t",                              "ru": "&Вырезать"},
    "action_copy":              {"en": "&Copy",                             "ru": "&Копировать"},
    "action_paste":             {"en": "&Paste",                            "ru": "Вст&авить"},
    "action_select_all":        {"en": "Select &All",                       "ru": "Выделить вс&ё"},
    "action_find":              {"en": "&Find",                             "ru": "&Найти"},
    "editor_context_web_search": {"en": "Search on the Internet",           "ru": "Поиск в интернете"},

    # View menu
    "action_toggle_console":    {"en": "Toggle &Console",                   "ru": "Показать/скрыть &консоль"},
    "action_toggle_explorer":   {"en": "Toggle &File Explorer",             "ru": "Показать/скрыть &проводник"},
    "action_zoom_in":           {"en": "Zoom &In",                          "ru": "&Увеличить масштаб"},
    "action_zoom_out":          {"en": "Zoom &Out",                         "ru": "У&меньшить масштаб"},
    "action_reset_zoom":        {"en": "&Reset Zoom",                       "ru": "&Сбросить масштаб"},

    # Device menu
    "action_select_port":       {"en": "&Select Port...",                   "ru": "&Выбрать порт..."},
    "action_refresh_ports":     {"en": "&Refresh Ports",                    "ru": "&Обновить порты"},
    "action_connect":           {"en": "&Connect",                          "ru": "&Подключить"},
    "action_disconnect":        {"en": "&Disconnect",                       "ru": "&Отключить"},

    # Run menu
    "action_run_script":        {"en": "&Run Script",                       "ru": "&Запустить скрипт"},
    "action_stop_execution":    {"en": "&Stop Execution",                   "ru": "&Остановить выполнение"},

    # Settings menu
    "menu_theme":               {"en": "&Theme",                            "ru": "&Тема"},
    "action_font_size":         {"en": "&Font Size...",                     "ru": "&Размер шрифта..."},
    "action_auto_save":         {"en": "&Auto Save",                        "ru": "&Автосохранение"},
    "action_syntax_highlight":  {"en": "&Syntax Highlighting",               "ru": "&Подсветка синтаксиса"},
    "action_error_checking":    {"en": "&Error Checking",                    "ru": "&Проверка ошибок"},
    "menu_language":            {"en": "&Language",                          "ru": "&Язык"},
    "lang_russian":             {"en": "Russian",                           "ru": "Русский"},
    "lang_english":             {"en": "English",                           "ru": "Английский"},
    "settings_dialog_title":    {"en": "Settings",                          "ru": "Настройки"},
    "settings_group_appearance":{"en": "Appearance",                         "ru": "Внешний вид"},
    "settings_group_editor":    {"en": "Editor",                             "ru": "Редактор"},
    "settings_font_size_label": {"en": "Font size",                         "ru": "Размер шрифта"},
    "settings_show_toolbar_search": {"en": "Show search field in toolbar",   "ru": "Показывать строку поиска сверху"},
    "settings_btn_save":        {"en": "Save",                              "ru": "Сохранить"},
    "settings_btn_cancel":      {"en": "Cancel",                            "ru": "Отмена"},

    # Help menu
    "action_about":             {"en": "&About",                            "ru": "&О программе"},
    "action_web_search":        {"en": "Yandex &Search",                    "ru": "Яндекс &Поиск"},
    "action_pixel_matrix":      {"en": "Pixel &Matrix...",                  "ru": "Пиксельная &матрица..."},
    "matrix_dialog_title":      {"en": "Pixel Matrix",                      "ru": "Пиксельная матрица"},
    "matrix_size_group":        {"en": "Canvas Size",                       "ru": "Размер холста"},
    "matrix_size_preset":       {"en": "Preset",                            "ru": "Размер"},
    "matrix_size_width":        {"en": "Width",                             "ru": "Ширина"},
    "matrix_size_height":       {"en": "Height",                            "ru": "Высота"},
    "matrix_brush_size":        {"en": "Brush",                            "ru": "Кисть"},
    "matrix_size_custom":       {"en": "Custom",                            "ru": "Свой размер"},
    "matrix_size_current":      {"en": "Size: {width} x {height}",          "ru": "Размер: {width} x {height}"},
    "matrix_canvas_group":      {"en": "Canvas",                            "ru": "Холст"},
    "matrix_preview_group":     {"en": "Preview",                           "ru": "Визуализация"},
    "matrix_preview_bits":      {"en": "Matrix",                            "ru": "Матрица"},
    "matrix_preview_array":     {"en": "Array",                             "ru": "Массив"},
    "matrix_preview_hex":       {"en": "HEX",                               "ru": "HEX"},
    "matrix_copy":              {"en": "Copy Matrix",                       "ru": "Скопировать матрицу"},
    "matrix_copy_array":        {"en": "Copy Array",                        "ru": "Скопировать массив"},
    "matrix_copy_hex":          {"en": "Copy HEX",                          "ru": "Скопировать HEX"},
    "matrix_usage_button":      {"en": "How to Use",                        "ru": "Как использовать"},
    "matrix_usage_title":       {"en": "How to Use the Matrix",             "ru": "Как использовать матрицу"},
    "matrix_usage_hint":        {"en": "These examples use the bundled display libraries from BoardyPy. SSD1306 is ready to run; MAX7219 and TFT/ST7735 can use the same pixel drawing functions after replacing the display setup block.",
                                 "ru": "Примеры используют библиотеки дисплеев из списка BoardyPy. SSD1306 готов к запуску сразу; MAX7219 и TFT/ST7735 используют те же функции через pixel() после замены блока подключения дисплея."},
    "matrix_usage_copy":        {"en": "Copy Example",                      "ru": "Скопировать пример"},
    "matrix_usage_copied":      {"en": "Example copied.",                   "ru": "Пример скопирован."},
    "matrix_clear":             {"en": "Clear",                             "ru": "Очистить"},
    "matrix_close":             {"en": "Close",                             "ru": "Закрыть"},
    "matrix_copied":            {"en": "Matrix copied.",                    "ru": "Матрица скопирована."},
    "matrix_array_copied":      {"en": "Array copied.",                     "ru": "Массив скопирован."},
    "matrix_hex_copied":        {"en": "HEX copied.",                       "ru": "HEX скопирован."},

    # ---- About dialog ----
    "about_title":              {"en": "About BoardyPy",                    "ru": "О программе BoardyPy"},
    "about_description":        {"en": f"<p>Professional MicroPython IDE.</p>"
                               f"<p><b>Version:</b> {APP_VERSION}</p>",
                                 "ru": f"<p>Профессиональная IDE для MicroPython.</p>"
                               f"<p><b>Версия:</b> {APP_VERSION}</p>"},
    "about_creator":            {"en": "<b>Creator:</b> @Timon2306<br>"
                                       "Student of group И24-11<br>"
                                       "ГПОУ ПК, Novokuznetsk<br>"
                                       "named after T.A. Kucheryavenko",
                                 "ru": "<b>Создатель:</b> @Timon2306<br>"
                                       "Студент группы И24-11<br>"
                                       "ГПОУ ПК г. Новокузнецка<br>"
                                       "им. Кучерявенко Т.А."},
    "about_support":            {"en": "Support — Telegram",
                                 "ru": "Поддержка — Telegram"},
    "about_patchnotes_btn":     {"en": "What's New",
                                 "ru": "Что нового"},
    "about_patchnotes_title":   {"en": f"What's New — v{APP_VERSION}",
                                 "ru": f"Что нового — v{APP_VERSION}"},
    "about_patchnotes":         {"en": f"<h3>Version {APP_VERSION}</h3>"
                                       "<ul>"
                                       "<li>Pixel Matrix can now copy drawings as arrays and HEX in addition to 0/1 rows</li>"
                                       "<li>The matrix preview now has Matrix, Array, and HEX tabs that update while drawing</li>"
                                       "<li>Added a brush size control for faster pixel drawing and erasing</li>"
                                       "<li>Canvas presets and custom sizes now support up to 128 x 160 pixels</li>"
                                       "<li>Added How to Use examples for SSD1306, MAX7219, and TFT/ST7735-style pixel drawing</li>"
                                       "<li>Large 128 x 64 examples are now optimized for MicroPython memory by using packed byte data</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.9</h3>"
                                       "<ul>"
                                       "<li>Settings now open in a larger dedicated dialog instead of a compact menu</li>"
                                       "<li>Added a Pixel Matrix tool for drawing black-and-white bitmap patterns and copying them as 0/1 rows</li>"
                                       "<li>The Tools menu was simplified to keep the new matrix tool and library manager easy to find</li>"
                                       "<li>Error checking is now disabled by default and can be enabled from Settings</li>"
                                       "<li>The Problems tab is hidden while error checking is disabled</li>"
                                       "<li>The toolbar web search field is now optional and disabled by default; editor context search still works</li>"
                                       "<li>Dialog controls now stay readable across dark, light, Monokai, and Nord themes</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.8</h3>"
                                       "<ul>"
                                       "<li>Added a Problems panel with compact counters for errors and warnings</li>"
                                       "<li>Code checking now detects several safely fixable syntax issues in one pass</li>"
                                       "<li>Safe Fix can repair missing colons, indentation tabs, trailing whitespace, old print syntax, and obvious unclosed brackets</li>"
                                       "<li>Safe Fix changes can now be reverted with Ctrl+Z</li>"
                                       "<li>Error checking can be disabled from Settings</li>"
                                       "<li>Syntax highlighting now automatically includes bundled MicroPython library symbols such as TFT_GREEN and SSD1306_I2C</li>"
                                       "<li>The What's New dialog is now smaller and scrollable</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.6</h3>"
                                       "<ul>"
                                       "<li>Library Manager now offers a choice between .py and .mpy for each library</li>"
                                       "<li>Installing a library now replaces an older file with the same base name even if one is .py and the other is .mpy</li>"
                                       "<li>Library uploads to ESP8266 were reworked to be more reliable with larger files and noticeably faster</li>"
                                       "<li>Removed the extra console error when /lib already exists during library installation</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.5</h3>"
                                       "<ul>"
                                       "<li>Automatic device connection on startup when a controller is detected</li>"
                                       "<li>Added update check on startup with a download button and version ignore option</li>"
                                       "<li>Crash/session recovery improved: unsaved tabs are restored after restart</li>"
                                       "<li>Toolbar is adaptive in small windows and keeps the main actions visible</li>"
                                       "<li>Device storage panel got improved navigation and the library catalogue was expanded</li>"
                                       "<li>Russian UI labels and text encoding issues were cleaned up</li>"
                                       "<li>Added search in the editor with Ctrl+F, next/previous navigation and match counter</li>"
                                       "<li>Search now opens as a compact popup in the top-right corner of the editor</li>"
                                       "<li>Added code folding buttons near line numbers for functions, loops and other indented blocks</li>"
                                       "<li>Editor indent guides were refined for a cleaner and more readable look</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.4</h3>"
                                       "<ul>"
                                       "<li>Auto-detects the serial device port on connect — prefers CH340/CP210x/FTDI chips and /dev/ttyUSB* on Linux; manual selection always available</li>"
                                       "<li>Extended syntax highlighting: f-strings, b-strings, __dunder__ names, exception classes, -&gt; type annotations, *args/**kwargs — each in a distinct color</li>"
                                       "<li>Special comment colors: #! warning (red bold), ## section header (yellow bold), plain # with TODO/FIXME/NOTE accent</li>"
                                       "<li>Syntax highlighting toggle added to Settings menu (on by default)</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.2</h3>"
                                       "<ul>"
                                       "<li>Priority run: open script runs by its file path (__file__ works, relative imports work)</li>"
                                       "<li>Binary file viewer: .mpy, .bin, .hex files open as hex dump</li>"
                                       "<li>File explorer now shows all file types</li>"
                                       "<li>Library Manager: install bundled MicroPython libraries to device with one click</li>"
                                       "<li>Fixed line number vertical alignment in editor</li>"
                                       "<li>Linux desktop shortcut: run install_desktop.sh once for double-click launch</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.1</h3>"
                                       "<ul>"
                                       "<li>Migrated from PyQt6 to PyQt5 (Python 3.9 / ALT Linux 10.4 support)</li>"
                                       "<li>Dark theme is now the default</li>"
                                       "<li>Fixed print() output in the console (separate line, correct colors)</li>"
                                       "<li>Adaptive console colors when switching themes</li>"
                                       "<li>Reduced line spacing in the console</li>"
                                       "<li>Language switching without restart</li>"
                                       "</ul>",
                                   "ru": f"<h3>Версия {APP_VERSION}</h3>"
                                       "<ul>"
                                       "<li>Пиксельную матрицу теперь можно копировать как массив и HEX, а не только строками из 0 и 1</li>"
                                       "<li>Справа в матрице появились вкладки «Матрица», «Массив» и «HEX», которые обновляются во время рисования</li>"
                                       "<li>Добавлен размер кисти для быстрого рисования и стирания пикселей</li>"
                                       "<li>Пресеты и свои размеры холста теперь поддерживают до 128 x 160 пикселей</li>"
                                       "<li>Добавлена кнопка «Как использовать» с примерами для SSD1306, MAX7219 и TFT/ST7735 через pixel()</li>"
                                       "<li>Большие примеры 128 x 64 оптимизированы для памяти MicroPython через упакованные байты</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.9</h3>"
                                       "<ul>"
                                       "<li>Настройки теперь открываются в большом отдельном окне вместо маленького меню</li>"
                                       "<li>Добавлен инструмент «Пиксельная матрица» для рисования чёрно-белых рисунков и копирования их строками из 0 и 1</li>"
                                       "<li>Меню «Инструменты» очищено: основные новые инструменты стало проще найти</li>"
                                       "<li>Проверка ошибок теперь выключена по умолчанию и включается в настройках</li>"
                                       "<li>Вкладка проблем скрывается, пока проверка ошибок выключена</li>"
                                       "<li>Строка интернет-поиска сверху стала отдельной настройкой и по умолчанию скрыта; поиск по ПКМ в редакторе работает как раньше</li>"
                                       "<li>Элементы диалогов теперь нормально читаются в тёмной, светлой, Monokai и Nord темах</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.8</h3>"
                                       "<ul>"
                                       "<li>Добавлена панель проблем с компактным счётчиком ошибок и предупреждений</li>"
                                       "<li>Проверка кода теперь находит несколько безопасно исправимых синтаксических ошибок за один проход</li>"
                                       "<li>Безопасное исправление умеет чинить пропущенные двоеточия, табы в отступах, пробелы в конце строк, старый print и очевидно незакрытые скобки</li>"
                                       "<li>Безопасные исправления теперь можно отменить через Ctrl+Z</li>"
                                       "<li>Проверку ошибок можно отключить в настройках</li>"
                                       "<li>Подсветка синтаксиса автоматически подтягивает символы встроенных MicroPython-библиотек, например TFT_GREEN и SSD1306_I2C</li>"
                                       "<li>Окно «Что нового» стало компактнее и получило прокрутку</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.6</h3>"
                                       "<ul>"
                                       "<li>Менеджер библиотек теперь предлагает выбор формата .py или .mpy для каждой библиотеки</li>"
                                       "<li>При установке библиотека заменяет старый файл с тем же именем, даже если расширение отличается (.py/.mpy)</li>"
                                       "<li>Загрузка библиотек на ESP8266 переработана: большие файлы передаются надёжнее и заметно быстрее</li>"
                                       "<li>Убрана лишняя ошибка в консоли, если папка /lib уже существует во время установки библиотеки</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.5</h3>"
                                       "<ul>"
                                       "<li>Добавлено автоподключение к контроллеру при запуске, если устройство найдено</li>"
                                       "<li>Добавлена проверка обновлений при старте с кнопкой перехода к скачиванию и возможностью скрыть эту версию</li>"
                                       "<li>Улучшено восстановление сессии после сбоя: несохранённые вкладки возвращаются после перезапуска</li>"
                                       "<li>Тулбар стал адаптивнее в маленьком окне и лучше сохраняет основные кнопки</li>"
                                       "<li>Доработана навигация по хранилищу контроллера и расширен каталог библиотек</li>"
                                       "<li>Исправлены проблемы кодировки и русских подписей в интерфейсе</li>"
                                       "<li>Добавлен поиск в редакторе по Ctrl+F с переходом вперёд/назад и счётчиком совпадений</li>"
                                       "<li>Окно поиска теперь открывается как компактное всплывающее меню справа сверху в редакторе</li>"
                                       "<li>Добавлены кнопки сворачивания кода рядом с номерами строк для функций, циклов и других блоков</li>"
                                       "<li>Подправлена визуализация направляющих табуляции в редакторе</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.4</h3>"
                                       "<ul>"
                                       "<li>Добавлено автоопределение COM-порта при подключении устройства (ручной выбор по-прежнему доступен)</li>"
                                       "<li>Расширена подсветка синтаксиса для MicroPython и популярных библиотек</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.2</h3>"
                                       "<ul>"
                                       "<li>Приоритет запуска: открытый скрипт запускается по пути файла (__file__ работает, импорты работают)</li>"
                                       "<li>Просмотр бинарных файлов: .mpy, .bin, .hex открываются как hex-дамп</li>"
                                       "<li>Проводник теперь показывает все типы файлов</li>"
                                       "<li>Менеджер библиотек: установка встроенных MicroPython библиотек на устройство нажатием одной кнопки</li>"
                                       "<li>Исправлено вертикальное выравнивание номеров строк в редакторе</li>"
                                       "<li>Ярлык для Linux: запусти install_desktop.sh один раз для запуска двойным кликом</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.1</h3>"
                                       "<ul>"
                                       "<li>Переход с PyQt6 на PyQt5 (поддержка Python 3.9 / ALT Linux 10.4)</li>"
                                       "<li>Тёмная тема по умолчанию</li>"
                                       "<li>Исправлен вывод print() в консоли (отдельная строка, корректные цвета)</li>"
                                       "<li>Адаптивные цвета консоли при смене темы</li>"
                                       "<li>Уменьшены промежутки между строками в консоли</li>"
                                       "<li>Смена языка без перезапуска</li>"
                                       "</ul>"},

    # ---- Port dialog ----
    "port_dialog_title":        {"en": "Select Serial Port",               "ru": "Выбор COM-порта"},
    "port_label":               {"en": "Port:",                             "ru": "Порт:"},
    "port_no_ports":            {"en": "(no ports found)",                  "ru": "(порты не найдены)"},
    "port_btn_connect":         {"en": "Connect",                           "ru": "Подключить"},
    "port_btn_cancel":          {"en": "Cancel",                            "ru": "Отмена"},

    # ---- Status bar / messages ----
    "status_port":              {"en": "Port: {port}",                      "ru": "Порт: {port}"},
    "status_selected_port":     {"en": "Selected port: {port}",            "ru": "Выбран порт: {port}"},
    "status_available_ports":   {"en": "Available ports: {ports}",         "ru": "Доступные порты: {ports}"},
    "status_no_ports":          {"en": "No serial ports found.",           "ru": "Последовательные порты не найдены."},
    "status_already_connected": {"en": "Already connected.",               "ru": "Уже подключено."},
    "status_not_connected":     {"en": "Not connected.",                   "ru": "Не подключено."},
    "status_connected":         {"en": "Connected: {port} @ {baud}",      "ru": "Подключено: {port} @ {baud}"},
    "status_connected_to":      {"en": "Connected to {port}",             "ru": "Подключено к {port}"},
    "status_connected_baud":    {"en": "Connected to {port} at {baud} baud.", "ru": "Подключено к {port} на скорости {baud} бод."},
    "status_disconnected":      {"en": "Disconnected",                     "ru": "Отключено"},
    "status_disconnected_err":  {"en": "Disconnected (error)",             "ru": "Отключено (ошибка)"},
    "status_device_disconnected": {"en": "Device disconnected.",           "ru": "Устройство отключено."},

    # ---- Errors / warnings ----
    "err_no_ports_title":       {"en": "No Ports",                         "ru": "Нет портов"},
    "err_no_ports_msg":         {"en": "No serial ports found. Connect a device first.",
                                 "ru": "Последовательные порты не найдены. Сначала подключите устройство."},
    "err_connection_title":     {"en": "Connection Error",                 "ru": "Ошибка подключения"},
    "err_connection_failed":    {"en": "Connection failed: {err}",         "ru": "Не удалось подключиться: {err}"},
    "err_not_connected_title":  {"en": "Not Connected",                    "ru": "Нет подключения"},
    "err_not_connected_msg":    {"en": "Please connect to a MicroPython device first.",
                                 "ru": "Сначала подключитесь к устройству MicroPython."},
    "err_not_connected_send":   {"en": "Not connected to any device.",     "ru": "Нет подключения к устройству."},
    "err_serial":               {"en": "Serial error: {err}",             "ru": "Ошибка порта: {err}"},
    "err_run":                  {"en": "Run error: {err}",                "ru": "Ошибка запуска: {err}"},
    "err_send":                 {"en": "Send error: {err}",               "ru": "Ошибка отправки: {err}"},
    "err_stop":                 {"en": "Stop error: {err}",               "ru": "Ошибка остановки: {err}"},

    # ---- Updates ----
    "update_available_title":   {"en": "Update Available",                "ru": "Доступно обновление"},
    "update_available_text":    {"en": "A new version {version} is available.",
                                 "ru": "Доступна новая версия {version}."},
    "update_available_notes":   {"en": "Changes in this version:\n{notes}",
                                 "ru": "Изменения в этой версии:\n{notes}"},
    "update_auto_hint":         {"en": "BoardyPy will close, install the update, and then restart automatically.",
                                 "ru": "BoardyPy закроется, установит обновление и затем запустится снова автоматически."},
    "update_download":          {"en": "Update",                          "ru": "Обновить"},
    "update_later":             {"en": "Later",                           "ru": "Позже"},
    "update_ignore":            {"en": "Don't show again",                "ru": "Не показывать"},
    "update_auto_connected":    {"en": "Automatic device connection completed.",
                                 "ru": "Автоподключение к устройству выполнено."},
    "update_installing":        {"en": "Closing BoardyPy and starting update…",
                                 "ru": "BoardyPy закрывается и запускает обновление…"},
    "update_installing_short":  {"en": "Updating…",
                                 "ru": "Обновление…"},
    "update_failed_title":      {"en": "Update Failed",
                                 "ru": "Не удалось обновить"},
    "update_failed_text":       {"en": "BoardyPy could not update itself automatically.",
                                 "ru": "BoardyPy не смог обновиться автоматически."},
    "update_failed_hint":       {"en": "You can open the details below or update BoardyPy manually with pip.",
                                 "ru": "Открой подробности ниже или обнови BoardyPy вручную через pip."},
    "update_start_failed":      {"en": "Could not start the update process: {err}",
                                 "ru": "Не удалось запустить процесс обновления: {err}"},

    # ---- Run messages ----
    "run_nothing":              {"en": "Nothing to run — editor is empty.", "ru": "Нечего запускать — редактор пуст."},
    "run_script_sent":          {"en": ">>> Script sent to device.",       "ru": ">>> Скрипт отправлен на устройство."},
    "run_stopped":              {"en": ">>> Execution stopped (CTRL+C sent).", "ru": ">>> Выполнение остановлено (CTRL+C отправлен)."},

    # ---- Font size dialog ----
    "font_size_title":          {"en": "Font Size",                        "ru": "Размер шрифта"},
    "font_size_prompt":         {"en": "Enter font size (6–36):",          "ru": "Введите размер шрифта (6–36):"},

    # ---- Console ----
    "console_title":            {"en": "Console / REPL",                   "ru": "Консоль / REPL"},
    "console_placeholder":      {"en": "Type command and press Enter...",  "ru": "Введите команду и нажмите Enter..."},
    "console_clear":            {"en": "Clear",                            "ru": "Очистить"},
    "console_device_connected": {"en": "Device connected",                 "ru": "Устройство подключено"},
    "console_device_disconnected": {"en": "Device disconnected",           "ru": "Устройство отключено"},

    # ---- File explorer ----
    "explorer_title":           {"en": "PC — File Explorer",               "ru": "ПК — Проводник"},
    "explorer_open_folder":     {"en": "Open Folder",                      "ru": "Открыть папку"},
    "explorer_go_home":         {"en": "Go to Home",                       "ru": "Домашняя папка"},
    "explorer_select_folder":   {"en": "Select Folder",                    "ru": "Выберите папку"},

    # ---- Editor dialogs ----
    "editor_error":             {"en": "Error",                            "ru": "Ошибка"},
    "editor_cannot_open":       {"en": "Cannot open file:\n{err}",        "ru": "Не удалось открыть файл:\n{err}"},
    "editor_cannot_save":       {"en": "Cannot save file:\n{err}",        "ru": "Не удалось сохранить файл:\n{err}"},
    "editor_save_as":           {"en": "Save As",                          "ru": "Сохранить как"},
    "editor_open_file":         {"en": "Open File",                        "ru": "Открыть файл"},
    "editor_unsaved_title":     {"en": "Unsaved Changes",                  "ru": "Несохранённые изменения"},
    "editor_unsaved_msg":       {"en": "'{name}' has unsaved changes. Save before closing?",
                                 "ru": "'{name}' содержит несохранённые изменения. Сохранить перед закрытием?"},
    "editor_py_filter":         {"en": "Python Files (*.py);;All Files (*)",
                                 "ru": "Файлы Python (*.py);;Все файлы (*)"},
    "editor_find_placeholder":  {"en": "Find in current file",             "ru": "Поиск в текущем файле"},
    "editor_find_prev":         {"en": "Find previous",                    "ru": "Найти предыдущее"},
    "editor_find_next":         {"en": "Find next",                        "ru": "Найти следующее"},
    "editor_find_close":        {"en": "Close search",                     "ru": "Закрыть поиск"},

    # ---- Language restart ----
    "lang_restart_title":       {"en": "Restart Required",                 "ru": "Требуется перезапуск"},
    "lang_restart_msg":         {"en": "Language will change after restarting the application.",
                                 "ru": "Язык будет изменён после перезапуска приложения."},

    # ---- Toolbar tooltips ----
    "tb_new":                   {"en": "New File",                         "ru": "Новый файл"},
    "tb_open":                  {"en": "Open File",                        "ru": "Открыть файл"},
    "tb_save":                  {"en": "Save",                             "ru": "Сохранить"},
    "tb_run":                   {"en": "Run (F5)",                         "ru": "Запустить (F5)"},
    "tb_stop":                  {"en": "Stop (F6)",                        "ru": "Остановить (F6)"},
    "tb_restart":               {"en": "Restart",                          "ru": "Перезапустить"},
    "tb_connect":               {"en": "Connect Device",                   "ru": "Подключить устройство"},
    "tb_disconnect":            {"en": "Disconnect Device",                "ru": "Отключить устройство"},
    "web_search_placeholder":   {"en": "Search in Yandex...",              "ru": "Поиск в Яндексе..."},
    "web_search_tooltip":       {"en": "Type a query and press Enter to open Yandex Search in your browser. The URL includes the clid parameter.",
                                 "ru": "Введите запрос и нажмите Enter, чтобы открыть Яндекс Поиск во внешнем браузере. В URL используется параметр clid."},
    "web_search_button":        {"en": "Search",                           "ru": "Поиск"},
    "web_search_empty":         {"en": "Enter a search query.",            "ru": "Введите поисковый запрос."},
    "web_search_opened":        {"en": "Yandex Search opened in your browser.",
                                 "ru": "Яндекс Поиск открыт в браузере."},
    "web_search_failed":        {"en": "Could not open the browser.",      "ru": "Не удалось открыть браузер."},

    # ---- Run menu additions ----
    "action_run_local":         {"en": "&Run Locally",                     "ru": "&Запустить локально"},
    "action_run_on_device":     {"en": "Run on &Device",                   "ru": "Запустить на &устройстве"},
    "action_restart":           {"en": "&Restart",                         "ru": "&Перезапустить"},
    "run_restarting":           {"en": ">>> Restarting script...",         "ru": ">>> Перезапуск скрипта..."},

    # ---- Local run messages ----
    "run_local_started":        {"en": ">>> Running script locally...",    "ru": ">>> Запуск скрипта локально..."},
    "run_local_finished":       {"en": ">>> Script finished (exit code {code}).", "ru": ">>> Скрипт завершён (код выхода {code})."},
    "run_local_error":          {"en": "Local run error: {err}",           "ru": "Ошибка локального запуска: {err}"},
    "run_local_stopped":        {"en": ">>> Local script stopped.",        "ru": ">>> Локальный скрипт остановлен."},
    "run_local_nothing":        {"en": "Nothing to run — editor is empty.", "ru": "Нечего запускать — редактор пуст."},
    "status_running_local":     {"en": "Running locally...",               "ru": "Выполняется локально..."},

    # ---- Console always-on ----
    "console_local_placeholder": {"en": "Type Python or command...",       "ru": "Введите Python-код или команду..."},

    # ---- Device file explorer ----
    "devexp_title":             {"en": "Controller Storage",               "ru": "Хранилище контроллера"},
    "devexp_refresh":           {"en": "Refresh",                          "ru": "Обновить"},
    "devexp_go_up":             {"en": "Go Up",                            "ru": "Наверх"},
    "devexp_upload":            {"en": "Upload",                           "ru": "Загрузить"},
    "devexp_upload_tip":        {"en": "Upload file to device",            "ru": "Загрузить файл на устройство"},
    "devexp_upload_title":      {"en": "Select file to upload",            "ru": "Выберите файл для загрузки"},
    "devexp_mkdir":             {"en": "New Folder",                       "ru": "Новая папка"},
    "devexp_mkdir_tip":         {"en": "Create folder on device",          "ru": "Создать папку на устройстве"},
    "devexp_mkdir_title":       {"en": "New Folder",                       "ru": "Новая папка"},
    "devexp_mkdir_prompt":      {"en": "Folder name:",                     "ru": "Имя папки:"},
    "devexp_download":          {"en": "Download",                         "ru": "Скачать"},
    "devexp_delete":            {"en": "Delete",                           "ru": "Удалить"},
    "devexp_delete_title":      {"en": "Delete",                           "ru": "Удаление"},
    "devexp_delete_confirm":    {"en": "Delete '{name}' from device?",     "ru": "Удалить '{name}' с устройства?"},
    "devexp_save_as":           {"en": "Save file as",                     "ru": "Сохранить файл как"},
    "devexp_not_connected":     {"en": "Device not connected",             "ru": "Устройство не подключено"},
    "devexp_connected":         {"en": "Device connected — loading…",      "ru": "Устройство подключено — загрузка…"},
    "devexp_items_count":       {"en": "{count} items",                    "ru": "Элементов: {count}"},
    "devexp_uploading":         {"en": "Uploading {name}…",                "ru": "Загрузка {name}…"},
    "devexp_file_opened":       {"en": "Opened from device: {name}",       "ru": "Открыт с устройства: {name}"},
    "devexp_downloading":       {"en": "Downloading {name}…",              "ru": "Скачивание {name}…"},
    "devexp_uploaded":          {"en": "{name} uploaded ✓",                "ru": "{name} загружен ✓"},
    "devexp_downloaded":        {"en": "{name} saved ✓",                   "ru": "{name} сохранён ✓"},
    "devexp_dir_created":       {"en": "Folder created ✓",                 "ru": "Папка создана ✓"},
    "devexp_deleted":           {"en": "Deleted ✓",                        "ru": "Удалено ✓"},
    "devexp_col_name":          {"en": "Name",                             "ru": "Имя"},
    "devexp_col_size":          {"en": "Size",                             "ru": "Размер"},
    "devexp_col_type":          {"en": "Type",                             "ru": "Тип"},
    "action_toggle_devexp":     {"en": "Toggle &Device Storage",           "ru": "Показать/скрыть &хранилище контроллера"},
    "action_toggle_problems":   {"en": "Toggle &Problems",                 "ru": "Показать/скрыть &проблемы"},
    "action_check_problems":    {"en": "Check &Problems",                  "ru": "Проверить &проблемы"},
    "action_fix_safe_problems": {"en": "Fix &Safe Problems",               "ru": "Исправить &безопасные проблемы"},
    "explorer_upload_to_device":{"en": "Upload to device",                 "ru": "Загрузить на устройство"},

    # ---- Problems ----
    "problems_title":           {"en": "⚠",                                "ru": "⚠"},
    "problems_title_tooltip":   {"en": "Problems",                         "ru": "Проблемы"},
    "problems_tab_counts":      {"en": "✕ {errors}  ⚠ {warnings}",          "ru": "✕ {errors}  ⚠ {warnings}"},
    "problems_tab_count":       {"en": "⚠ {count}",                         "ru": "⚠ {count}"},
    "problems_summary_ok":      {"en": "No problems found",                "ru": "Проблем не найдено"},
    "problems_summary_counts":  {"en": "Errors: {errors}  Warnings: {warnings}",
                                 "ru": "Ошибки: {errors}  Предупреждения: {warnings}"},
    "problems_check":           {"en": "Check",                            "ru": "Проверить"},
    "problems_fix_safe":        {"en": "Fix Safe",                         "ru": "Исправить безопасное"},
    "problems_show_details":    {"en": "Variants",                         "ru": "Варианты"},
    "problems_details_title":   {"en": "Problem Details",                  "ru": "Подробности проблемы"},
    "problems_col_severity":    {"en": "Type",                             "ru": "Тип"},
    "problems_col_line":        {"en": "Line",                             "ru": "Строка"},
    "problems_col_message":     {"en": "Message",                          "ru": "Сообщение"},
    "problems_col_fix":         {"en": "Fix",                              "ru": "Исправление"},
    "problems_fix_available":   {"en": "safe",                             "ru": "безопасное"},
    "problems_error":           {"en": "Error",                            "ru": "Ошибка"},
    "problems_warning":         {"en": "Warning",                          "ru": "Предупреждение"},
    "problems_info":            {"en": "Info",                             "ru": "Инфо"},
    "problems_status_ok":       {"en": "✕ 0  ⚠ 0",                         "ru": "✕ 0  ⚠ 0"},
    "problems_status_counts":   {"en": "✕ {errors}  ⚠ {warnings}",
                                 "ru": "✕ {errors}  ⚠ {warnings}"},
    "problems_status_tooltip":  {"en": "Open the Problems panel",          "ru": "Открыть панель проблем"},
    "problems_fix_none":        {"en": "No safe fixes available.",         "ru": "Безопасных исправлений нет."},
    "problems_fix_done":        {"en": "Applied safe fixes: {fixes}.",     "ru": "Применены безопасные исправления: {fixes}."},
    "problems_checking_enabled":{"en": "Error checking enabled.",           "ru": "Проверка ошибок включена."},
    "problems_checking_disabled":{"en": "Error checking disabled.",         "ru": "Проверка ошибок отключена."},
    "problems_run_blocked":     {"en": "Run stopped: fix {count} syntax error(s) first.",
                                 "ru": "Запуск остановлен: сначала исправьте синтаксические ошибки ({count})."},
    "problem_tabs":             {"en": "Tabs in indentation. Use spaces for stable MicroPython code.",
                                 "ru": "Табы в отступах. Для MicroPython безопаснее использовать пробелы."},
    "problem_trailing_ws":      {"en": "Trailing spaces at the end of a line.",
                                 "ru": "Пробелы в конце строки."},
    "problem_syntax":           {"en": "Syntax error: {msg}",              "ru": "Синтаксическая ошибка: {msg}"},
    "problem_tabs_detail":      {"en": "Safe fix: replace indentation tabs with 4 spaces. This does not change commands, only indentation characters.",
                                 "ru": "Безопасное исправление: заменить табы в отступах на 4 пробела. Команды не меняются, меняются только символы отступа."},
    "problem_trailing_ws_detail":{"en": "Safe fix: remove spaces and tabs at line ends.",
                                 "ru": "Безопасное исправление: убрать пробелы и табы в конце строк."},
    "problem_missing_colon_detail":{"en": "Safe fix: add ':' to a compound statement line such as if, for, while, def or class.",
                                 "ru": "Безопасное исправление: добавить ':' в строку конструкции вроде if, for, while, def или class."},
    "problem_print_call_detail":{"en": "Safe fix: convert old print syntax to Python 3 function call, for example print \"hi\" -> print(\"hi\").",
                                 "ru": "Безопасное исправление: перевести старую запись print в вызов Python 3, например print \"hi\" -> print(\"hi\")."},
    "problem_missing_closer_detail":{"en": "Safe fix: add an obviously missing closing bracket at the end of the same line.",
                                 "ru": "Безопасное исправление: добавить очевидно пропущенную закрывающую скобку в конце той же строки."},
    "problem_manual_detail":    {"en": "No automatic safe fix is available. Open the line and check the expression manually.",
                                 "ru": "Автоматического безопасного исправления нет. Открой строку и проверь выражение вручную."},
    "problem_fix_tabs":         {"en": "tabs changed to spaces",           "ru": "табы заменены на пробелы"},
    "problem_fix_trailing_ws":  {"en": "trailing spaces removed",          "ru": "убраны пробелы в конце строк"},
    "problem_fix_missing_colon":{"en": "missing colon added",              "ru": "добавлено пропущенное двоеточие"},
    "problem_fix_print_call":   {"en": "print converted to Python 3 call", "ru": "print переведён в формат Python 3"},
    "problem_fix_missing_closer":{"en": "missing closing bracket added",   "ru": "добавлена пропущенная закрывающая скобка"},

    # ---- Library Manager ----
    "menu_libraries":           {"en": "&Libraries",                        "ru": "&Библиотеки"},
    "action_lib_manager":       {"en": "📦 &MicroPython Libraries...",       "ru": "📦 &Библиотеки MicroPython..."},
    "libmgr_title":             {"en": "MicroPython Library Manager",       "ru": "Менеджер библиотек MicroPython"},
    "libmgr_header":            {"en": "Bundled libraries for ESP8266 / MicroPython. "
                                       "Select a library to view description and install it to the device /lib/ folder.",
                                 "ru": "Встроенные библиотеки для ESP8266 / MicroPython. "
                                       "Выбери библиотеку, посмотри описание и установи её в папку /lib/ на устройстве."},
    "libmgr_view":              {"en": "View source",                       "ru": "Посмотреть код"},
    "libmgr_install_device":    {"en": "Install to device /lib/",           "ru": "Установить на устройство /lib/"},
    "libmgr_install_tip":       {"en": "Upload selected library to /lib/ on the connected device",
                                 "ru": "Загрузить выбранную библиотеку в папку /lib/ на подключённом устройстве"},
    "libmgr_formats_line":      {"en": "Available formats: {formats}",
                                 "ru": "Доступные форматы: {formats}"},
    "libmgr_format_title":      {"en": "Choose Library Format",             "ru": "Выбор формата библиотеки"},
    "libmgr_format_msg":        {"en": "Choose how to install '{name}' to the device.",
                                 "ru": "Выбери, в каком формате установить '{name}' на устройство."},
    "libmgr_format_hint":       {"en": ".py: {py_status}\n.mpy: {mpy_status}\n\n"
                                       ".py is more compatible, .mpy is usually smaller but may not work on some firmware.",
                                 "ru": ".py: {py_status}\n.mpy: {mpy_status}\n\n"
                                       ".py совместимее, .mpy обычно меньше по размеру, но поддерживается не всеми прошивками."},
    "libmgr_format_py":         {"en": "Install .py",                       "ru": "Установить .py"},
    "libmgr_format_mpy":        {"en": "Install .mpy",                      "ru": "Установить .mpy"},
    "libmgr_format_missing":    {"en": "not available",                     "ru": "нет в комплекте"},
    "libmgr_format_size":       {"en": "{size} bytes",                      "ru": "{size} байт"},
    "libmgr_install_ok_title":  {"en": "Library Queued",                   "ru": "Библиотека в очереди"},
    "libmgr_install_ok_msg":    {"en": "'{name}' will be uploaded to {path}.\n"
                                       "Check console for progress.",
                                 "ru": "'{name}' будет загружена в {path}.\n"
                                       "Прогресс — в консоли."},
    "tb_libraries":             {"en": "Libraries",                         "ru": "Библиотеки"},
}


# ---------------------------------------------------------------------------
# Current language state
# ---------------------------------------------------------------------------

_current_lang: str = "ru"


def set_language(lang: str) -> None:
    """Set the active language ('en' or 'ru')."""
    global _current_lang
    _current_lang = lang if lang in ("en", "ru") else "ru"


def get_language() -> str:
    return _current_lang


def tr(key: str, **kwargs: Any) -> str:
    """Return translated string by key. Supports {placeholder} formatting."""
    entry = _STRINGS.get(key)
    if entry is None:
        return key
    text = entry.get(_current_lang, entry.get("en", key))
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, IndexError):
            pass
    return text

