from __future__ import annotations

import json
import os
from typing import Any

from ..paths import DEFAULT_UPDATE_FEED_URL


DEFAULT_CONFIG: dict[str, Any] = {
    "theme": "Dark",
    "font_size": 13,
    "auto_save": False,
    "last_port": "",
    "baud_rate": 115200,
    "window_geometry": None,
    "last_directory": "",
    "language": "ru",
    "syntax_highlight": True,
    "error_checking": False,
    "show_toolbar_search": False,
    "session_file": "boardypy_session.json",
    "restore_unsaved_on_start": True,
    "last_session_snapshot_at": 0,
    "has_crash_recovery": False,
    "check_updates_on_start": True,
    "update_feed_url": DEFAULT_UPDATE_FEED_URL,
    "ignored_update_version": "",
}


class ConfigManager:
    def __init__(self, config_path: str) -> None:
        self._path = config_path
        self._data: dict[str, Any] = {}
        self._load()

    @property
    def path(self) -> str:
        return self._path

    @property
    def directory(self) -> str:
        return os.path.dirname(os.path.abspath(self._path))

    def resolve_path(self, value: str) -> str:
        return value if os.path.isabs(value) else os.path.join(self.directory, value)

    def _load(self) -> None:
        if os.path.exists(self._path):
            try:
                with open(self._path, "r", encoding="utf-8") as fh:
                    loaded = json.load(fh)
                self._data = {**DEFAULT_CONFIG, **loaded}
            except (json.JSONDecodeError, OSError):
                self._data = dict(DEFAULT_CONFIG)
        else:
            self._data = dict(DEFAULT_CONFIG)
            self._save()

    def _save(self) -> None:
        try:
            os.makedirs(self.directory, exist_ok=True)
            with open(self._path, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=4, ensure_ascii=False)
        except OSError:
            pass

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value
        self._save()

    def get_all(self) -> dict[str, Any]:
        return dict(self._data)
