"""MCP tool 层单测 — 不依赖 mcp 包，只验证 handler 逻辑。"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from soulpolicy_mcp._tools import make_tools


@dataclass
class FakeBaseline:
    id: str = "bl_x"
    label: str | None = "test"
    fingerprint: str = "sha256:abc"
    sample_count: int = 5
    z_warn: float = 2.0
    z_critical: float = 3.0
    distance_mode: str = "cosine"
    embedding_model: str = "x"


@dataclass
class FakeDrift:
    id: str = "dc_x"
    score: float = 0.5
    z_score: float = 1.0
    severity: str = "warn"
    decision: str = "trigger_review"
    ema: float = 0.0
    evidence: dict[str, Any] = None
    reproducibility: dict[str, Any] = None
    latency_ms: int = 5


class FakeBaselines:
    def create(self, **kwargs):
        self.last_create = kwargs
        return FakeBaseline()

    def retrieve(self, id):  # noqa: A002
        return FakeBaseline(id=id)

    def report(self, id):  # noqa: A002
        from types import SimpleNamespace

        return SimpleNamespace(
            id="rep_1",
            baseline=id,
            sample_count=5,
            holdout_count=1,
            perturbation_count=3,
            auc=0.9,
            fp_rate_at_warn=0.1,
            fn_rate_at_warn=0.2,
            severity_distribution={"ok": 4, "warn": 1},
            weakest_categories=[],
            notes=["ok"],
            generated_at=0,
            object="baseline_report",
        )


class FakeDriftChecks:
    def check(self, *, text, baseline):
        return FakeDrift()

    def replay(self, *, text, baseline, reproducibility):
        from types import SimpleNamespace

        return SimpleNamespace(matched=True, diff={}, result=FakeDrift())

    def feedback(self, id, *, label, note=None):  # noqa: A002
        from types import SimpleNamespace

        return SimpleNamespace(id="fb_1", target_id=id, label=label)


class FakeClient:
    baselines = FakeBaselines()
    drift_checks = FakeDriftChecks()


def test_tools_present_and_have_schema():
    tools = make_tools(FakeClient())
    expected = {
        "soulpolicy_create_baseline",
        "soulpolicy_drift_check",
        "soulpolicy_baseline_report",
        "soulpolicy_drift_replay",
        "soulpolicy_drift_feedback",
    }
    assert set(tools.keys()) == expected
    for t in tools.values():
        assert t.input_schema["type"] == "object"
        assert "required" in t.input_schema


def test_create_baseline_handler():
    tools = make_tools(FakeClient())
    out = tools["soulpolicy_create_baseline"].handler(
        {"samples": ["a", "b", "c", "d", "e"], "label": "x"}
    )
    assert out["id"] == "bl_x"
    assert out["fingerprint"] == "sha256:abc"


def test_drift_check_handler():
    tools = make_tools(FakeClient())
    out = tools["soulpolicy_drift_check"].handler({"text": "x", "baseline": "bl_x"})
    assert out["severity"] == "warn"
    assert out["decision"] == "trigger_review"


def test_drift_replay_handler():
    tools = make_tools(FakeClient())
    out = tools["soulpolicy_drift_replay"].handler(
        {"text": "x", "baseline": "bl_x", "reproducibility": {}}
    )
    assert out["matched"] is True
    assert out["result"]["severity"] == "warn"


def test_baseline_report_handler():
    tools = make_tools(FakeClient())
    out = tools["soulpolicy_baseline_report"].handler({"baseline": "bl_x"})
    assert out["auc"] == 0.9
    assert out["sample_count"] == 5


def test_feedback_handler():
    tools = make_tools(FakeClient())
    out = tools["soulpolicy_drift_feedback"].handler(
        {"drift_check_id": "dc_x", "label": "true_positive"}
    )
    assert out["target_id"] == "dc_x"
    assert out["label"] == "true_positive"


def test_handler_wraps_sdk_errors():
    """SoulPolicyError 应被转译为 RuntimeError。"""
    from soulpolicy import AuthenticationError

    class BoomBaselines:
        def create(self, **k):
            raise AuthenticationError("bad", code="invalid_api_key")

    class BoomClient:
        baselines = BoomBaselines()
        drift_checks = FakeDriftChecks()

    tools = make_tools(BoomClient())
    with pytest.raises(RuntimeError) as ei:
        tools["soulpolicy_create_baseline"].handler(
            {"samples": ["a", "b", "c"]}
        )
    assert "AuthenticationError" in str(ei.value)
