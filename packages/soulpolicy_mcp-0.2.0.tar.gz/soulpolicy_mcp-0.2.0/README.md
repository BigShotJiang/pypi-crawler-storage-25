# soulpolicy-mcp

MCP server 让 Claude Desktop / Cursor 直接调用 SoulPolicy primitive。

## 安装

```bash
pip install soulpolicy soulpolicy-mcp
```

## Claude Desktop 配置

把下面加到 `~/Library/Application Support/Claude/claude_desktop_config.json`：

```jsonc
{
  "mcpServers": {
    "soulpolicy": {
      "command": "python",
      "args": ["-m", "soulpolicy_mcp"],
      "env": {
        "SOULPOLICY_API_KEY": "sk_live_xxx"
      }
    }
  }
}
```

重启 Claude Desktop 后会看到 5 个新工具：
- `soulpolicy_create_baseline`
- `soulpolicy_drift_check`
- `soulpolicy_baseline_report`
- `soulpolicy_drift_replay`
- `soulpolicy_drift_feedback`

## Cursor 配置

`.cursor/mcp.json`：

```jsonc
{
  "mcpServers": {
    "soulpolicy": {
      "command": "python",
      "args": ["-m", "soulpolicy_mcp"],
      "env": { "SOULPOLICY_API_KEY": "sk_live_xxx" }
    }
  }
}
```

## 直接命令行启动

```bash
SOULPOLICY_API_KEY=sk_live_xxx soulpolicy-mcp
# 等同：
SOULPOLICY_API_KEY=sk_live_xxx python -m soulpolicy_mcp
```

## 用例：让 Claude 自检它自己的输出

```
You: Create a customer-support baseline from these 5 healthy replies …
Claude: [calls soulpolicy_create_baseline] -> bl_xxx
You: Now check this draft response: "…"
Claude: [calls soulpolicy_drift_check]
        Result: severity=warn, z_score=2.3 — there's a topical shift away
        from your baseline. Want me to revise?
```
