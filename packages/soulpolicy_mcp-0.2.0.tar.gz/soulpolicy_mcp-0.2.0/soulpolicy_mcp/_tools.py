"""把 SoulPolicy SDK 调用封装为 MCP tool 函数。

每个工具：
  - 接 dict 参数（MCP tool args），返回 dict（content blocks 由 server 层包装）
  - 内部用 SoulPolicy Python SDK
  - 错误抛 RuntimeError，server 层转译为 MCP tool error

不直接依赖 mcp 包，便于纯函数测试。
"""
from __future__ import annotations

from typing import Any

from soulpolicy import Client, SoulPolicyError


def make_tools(client: Client) -> dict[str, "Tool"]:
    return {
        "soulpolicy_create_baseline": Tool(
            name="soulpolicy_create_baseline",
            description=(
                "Create a SoulPolicy drift-detection baseline from healthy sample texts. "
                "Use this once per agent persona to establish what 'in-distribution' means. "
                "Returns a bl_xxx id used by drift_check."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "samples": {
                        "type": "array",
                        "items": {"type": "string"},
                        "minItems": 3,
                        "description": "≥3 healthy outputs of the agent",
                    },
                    "label": {
                        "type": "string",
                        "description": "Friendly label for the baseline",
                    },
                    "distance_mode": {
                        "type": "string",
                        "enum": ["cosine", "mahalanobis", "hybrid"],
                        "default": "cosine",
                    },
                },
                "required": ["samples"],
            },
            handler=lambda args: _baseline_create(client, args),
        ),
        "soulpolicy_drift_check": Tool(
            name="soulpolicy_drift_check",
            description=(
                "Check whether a candidate LLM output drifts from a baseline. "
                "Returns severity (ok | warn | critical), score, evidence, and "
                "a reproducibility packet that can replay the exact judgement later."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "baseline": {"type": "string", "pattern": "^bl_"},
                },
                "required": ["text", "baseline"],
            },
            handler=lambda args: _drift_check(client, args),
        ),
        "soulpolicy_baseline_report": Tool(
            name="soulpolicy_baseline_report",
            description=(
                "Generate a baseline quality report (AUC, FP/FN at warn) by running "
                "drift_check on holdout + perturbation samples. Use to decide whether "
                "the baseline is sharp enough for production."
            ),
            input_schema={
                "type": "object",
                "properties": {"baseline": {"type": "string", "pattern": "^bl_"}},
                "required": ["baseline"],
            },
            handler=lambda args: _baseline_report(client, args),
        ),
        "soulpolicy_drift_replay": Tool(
            name="soulpolicy_drift_replay",
            description=(
                "Replay an earlier drift_check using its reproducibility packet. "
                "Used for audit / proving that the model's judgement is deterministic."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "baseline": {"type": "string"},
                    "reproducibility": {"type": "object"},
                },
                "required": ["text", "baseline", "reproducibility"],
            },
            handler=lambda args: _drift_replay(client, args),
        ),
        "soulpolicy_drift_feedback": Tool(
            name="soulpolicy_drift_feedback",
            description=(
                "Send TP/FP/TN/FN feedback for a previous drift_check. Improves "
                "monthly precision/recall reporting."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "drift_check_id": {"type": "string", "pattern": "^dc_"},
                    "label": {
                        "type": "string",
                        "enum": [
                            "true_positive",
                            "false_positive",
                            "true_negative",
                            "false_negative",
                        ],
                    },
                    "note": {"type": "string"},
                },
                "required": ["drift_check_id", "label"],
            },
            handler=lambda args: _drift_feedback(client, args),
        ),
    }


class Tool:
    """统一 tool 描述结构，server 层适配 mcp.types.Tool。"""

    def __init__(self, *, name: str, description: str, input_schema: dict, handler):
        self.name = name
        self.description = description
        self.input_schema = input_schema
        self.handler = handler


# ============== handlers ==============


def _wrap_errors(fn, args: dict[str, Any]) -> dict[str, Any]:
    try:
        return fn(args)
    except SoulPolicyError as e:
        raise RuntimeError(
            f"{type(e).__name__}: {e} (code={e.code}, request_id={e.request_id})"
        ) from e


def _baseline_create(client: Client, args: dict[str, Any]) -> dict[str, Any]:
    return _wrap_errors(
        lambda a: _bl_to_dict(
            client.baselines.create(
                samples=a["samples"],
                label=a.get("label"),
                distance_mode=a.get("distance_mode", "cosine"),
            )
        ),
        args,
    )


def _drift_check(client: Client, args: dict[str, Any]) -> dict[str, Any]:
    return _wrap_errors(
        lambda a: _drift_to_dict(
            client.drift_checks.check(text=a["text"], baseline=a["baseline"])
        ),
        args,
    )


def _baseline_report(client: Client, args: dict[str, Any]) -> dict[str, Any]:
    return _wrap_errors(
        lambda a: client.baselines.report(a["baseline"]).__dict__,
        args,
    )


def _drift_replay(client: Client, args: dict[str, Any]) -> dict[str, Any]:
    def _do(a):
        rep = client.drift_checks.replay(
            text=a["text"],
            baseline=a["baseline"],
            reproducibility=a["reproducibility"],
        )
        return {
            "matched": rep.matched,
            "diff": rep.diff,
            "result": _drift_to_dict(rep.result),
        }

    return _wrap_errors(_do, args)


def _drift_feedback(client: Client, args: dict[str, Any]) -> dict[str, Any]:
    def _do(a):
        fb = client.drift_checks.feedback(
            a["drift_check_id"], label=a["label"], note=a.get("note")
        )
        return {"id": fb.id, "target_id": fb.target_id, "label": fb.label}

    return _wrap_errors(_do, args)


def _bl_to_dict(bl) -> dict:
    return {
        "id": bl.id,
        "label": bl.label,
        "fingerprint": bl.fingerprint,
        "sample_count": bl.sample_count,
        "z_warn": bl.z_warn,
        "z_critical": bl.z_critical,
        "distance_mode": bl.distance_mode,
        "embedding_model": bl.embedding_model,
    }


def _drift_to_dict(r) -> dict:
    return {
        "id": r.id,
        "score": r.score,
        "z_score": r.z_score,
        "severity": r.severity,
        "decision": r.decision,
        "ema": r.ema,
        "evidence": r.evidence,
        "reproducibility": r.reproducibility,
        "latency_ms": r.latency_ms,
    }
