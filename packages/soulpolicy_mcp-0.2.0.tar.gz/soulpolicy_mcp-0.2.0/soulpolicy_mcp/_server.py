"""mcp server 适配层。

实现策略：
  - 工具定义 / 处理函数纯逻辑放在 _tools.py（可独立测试）
  - 本模块负责把它们注册进官方 mcp Python SDK 的 Server 实例
  - 优先使用 mcp >= 1.x 的 stdio_server 方式
"""
from __future__ import annotations

import json
import os
import sys
from typing import Any

from soulpolicy import Client

from soulpolicy_mcp._tools import Tool, make_tools


def _build_client() -> Client:
    api_key = os.environ.get("SOULPOLICY_API_KEY")
    if not api_key:
        sys.stderr.write(
            "ERROR: SOULPOLICY_API_KEY environment variable is required.\n"
        )
        sys.exit(2)
    return Client(api_key=api_key, base_url=os.environ.get("SOULPOLICY_BASE_URL"))


def build_server(client: Client | None = None):
    """构造 mcp Server 实例并注册 5 个工具。

    返回 (server, tools_dict)。延迟 import mcp 让没装 mcp 的环境也能 import 本包。
    """
    try:
        import mcp.server  # type: ignore
        import mcp.types  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise RuntimeError(
            "mcp package not installed. pip install mcp"
        ) from e

    sp_client = client or _build_client()
    tools = make_tools(sp_client)
    server = mcp.server.Server("soulpolicy")

    @server.list_tools()  # type: ignore
    async def _list_tools():
        return [
            mcp.types.Tool(
                name=t.name,
                description=t.description,
                inputSchema=t.input_schema,
            )
            for t in tools.values()
        ]

    @server.call_tool()  # type: ignore
    async def _call_tool(name: str, arguments: dict[str, Any] | None):
        if name not in tools:
            return [mcp.types.TextContent(type="text", text=f"unknown tool: {name}")]
        try:
            result = tools[name].handler(arguments or {})
        except Exception as e:
            return [mcp.types.TextContent(type="text", text=f"error: {e}")]
        return [mcp.types.TextContent(type="text", text=json.dumps(result, indent=2))]

    return server, tools


def run_stdio() -> None:  # pragma: no cover
    """生产入口：通过 stdio 与 MCP 客户端通信。"""
    import asyncio

    import mcp.server.stdio  # type: ignore

    server, _ = build_server()

    async def _main():
        async with mcp.server.stdio.stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())

    asyncio.run(_main())


if __name__ == "__main__":  # pragma: no cover
    run_stdio()
