"""SoulPolicy MCP server — 让 Claude Desktop / Cursor / 任何 MCP 客户端
直接调用 drift_check / baseline / guardrail。

启动（stdio）：

    python -m soulpolicy_mcp

环境变量：
    SOULPOLICY_API_KEY=sk_live_xxx
    SOULPOLICY_BASE_URL=https://api.soulpolicy.cc  (可选)

Claude Desktop 配置示例（mcp_config.json）：

    {
      "mcpServers": {
        "soulpolicy": {
          "command": "python",
          "args": ["-m", "soulpolicy_mcp"],
          "env": {"SOULPOLICY_API_KEY": "sk_live_xxx"}
        }
      }
    }
"""

from soulpolicy_mcp._server import build_server, run_stdio

__version__ = "0.1.0"

__all__ = ["build_server", "run_stdio", "__version__"]
