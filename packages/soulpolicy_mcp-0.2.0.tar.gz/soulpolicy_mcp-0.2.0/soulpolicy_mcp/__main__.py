"""python -m soulpolicy_mcp 入口。"""
from soulpolicy_mcp._server import run_stdio


if __name__ == "__main__":  # pragma: no cover
    run_stdio()
