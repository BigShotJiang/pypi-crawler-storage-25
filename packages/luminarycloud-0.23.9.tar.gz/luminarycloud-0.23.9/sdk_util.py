# Copyright 2024 Luminary Cloud, Inc. All Rights Reserved.
"""
sdk_util.py contains helper functions that maybe useful when using the Luminary
Python SDK.

This code is not actually a part of the SDK; it is an internal utility library
to make things like connecting to preview environments easier.
"""

import luminarycloud as lc


def get_client_for_env(env_name: str) -> lc.Client:
    """
    Configures and returns a LC SDK client connected to the specified environment.

    :param env_name: any valid env name, e.g. prod, test0, main, itar-prod, etc. or any preview env name
    :return: luminarycloud.Client
    """
    if env_name == "prod":
        # default client will be for prod
        return lc.Client(
            target="apis.luminarycloud.com",
            # below params are kwargs to Auth0Client constructor
            domain="luminarycloud-prod.us.auth0.com",
            client_id="JTsXa4fbArSCl6i9xylUpwrwpovtkss1",
            audience="https://apis.luminarycloud.com",
        )
    elif env_name == "test0":
        return lc.Client(
            target="apis.test0.int.luminarycloud.com",
            # below params are kwargs to Auth0Client constructor
            domain="luminarycloud-staging.us.auth0.com",
            client_id="emcjuelZOrvwlmAqVgqrdchw2cyY58mN",
            audience="https://api-staging.luminarycloud.com",
        )
    elif env_name == "local":
        # this is for targeting a local env running with run_backend.py
        return lc.Client(
            target="localhost:50051",
            http_target="http://localhost:50052",
            localhost=True,
            # below params are kwargs to Auth0Client constructor
            domain="luminarycloud-dev.us.auth0.com",
            client_id="mbM8OSEk5ShoU5iKfzUxSinKluPlxGQ9",
            audience="https://api-dev.luminarycloud.com",
        )
    else:
        if env_name == "main" or env_name.startswith("itar-"):
            target = f"apis.{env_name}.int.luminarycloud.com"
        else:
            # must be a preview env
            target = f"apis-{env_name}.int.luminarycloud.com"
        return lc.Client(
            target=target,
            # below params are kwargs to Auth0Client constructor
            domain="luminarycloud-dev.us.auth0.com",
            client_id="mbM8OSEk5ShoU5iKfzUxSinKluPlxGQ9",
            audience="https://api-dev.luminarycloud.com",
        )
