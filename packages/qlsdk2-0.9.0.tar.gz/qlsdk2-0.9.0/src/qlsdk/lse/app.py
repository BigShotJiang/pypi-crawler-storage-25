from enum import IntEnum
import threading
import time
from qlsdk.lse.ars_lse import ArsLse
from time import sleep
from loguru import logger

'''刺激类型枚举-用于多模态刺激配置'''
class StimTypeEnum(IntEnum):
    ELECTRIC = 0
    LIGHT = 1
    SOUND = 2

'''电刺激配置类-用于纯电刺激管理'''
class electric_stim_config(object):
    def __init__(self, lse:ArsLse, stim_groups:list, total_duration:int, log_realtime_current: bool = False):
        self._device:ArsLse = lse
        self._stim_groups:list = stim_groups
        self._total_duration:int = total_duration
        self._log_realtime_current:bool = log_realtime_current
        self._running = True
        
    def __post_init__(self):
        if not self._device:
            raise ValueError("LSE实例不能为空")
        if not self._device.is_connected():
            raise ValueError("LSE设备未连接")
        
        if not self._stim_groups or len(self._stim_groups) == 0:
            raise ValueError("刺激配置必须是一个非空列表")
        if self._total_duration <= 0:
            raise ValueError("总刺激时间必须大于0")
        
    def stim_monitor(self):
        import time
        start_time = time.time()
        offset = 0
        while offset < self._total_duration and self._running:
            time.sleep(0.01)  # 精度：0.01秒
            offset = (time.time() - start_time) * 1000
        # 提前终止
        if self._running:
            logger.debug(f"刺激监视器触发，达到总刺激时间，正在停止刺激:{offset}")
        self._running = False
            
    def start(self):
        self._running = True
        # 创建监视器，控制最长刺激时间
        monitor = threading.Thread(target=self.stim_monitor, daemon=True)
        monitor.start()
        start_time = time.time()
        for cfg in self._stim_groups:
            if not self._running:
                break
            # 这里可以根据cfg的内容调用lse的刺激接口，例如：
            flag = self._device.start_e_stim(cfg, log_realtime_current=self._log_realtime_current)
            logger.info(f"电刺激配置: {cfg}配置及启动{'成功' if flag else '失败'}")
            stim_time = cfg[0].get('duration', 0) + cfg[0].get('ramp_up_ms', 0) + cfg[0].get('ramp_down_ms', 0)
            logger.debug(f"预计刺激时间: {stim_time}毫秒")
            ref = time.time()
            offset = 0
            while offset < stim_time:
                if not self._running:
                    self._device.stop_e_stim()  # 停止刺激
                    break
                t2 = time.time()
                sleep(0.01)  # 等待刺激完成，精度：0.01秒  实际15ms +- 5ms， 受CPU调度影响较大
                offset = (time.time() - ref) * 1000
            logger.debug(f"刺激完成，实际刺激时间: {(time.time() - ref)*1000}毫秒")
            
        print("电刺激已完成: 实际总执行时间: {:.2f}秒".format(time.time() - start_time))

'''多模态刺激配置类-用于多模态刺激管理'''    
class multimodal_stim_config(object):
    def __init__(self, lse:ArsLse, stim_groups:list, total_duration:int):
        self._device:ArsLse = lse
        self._stim_groups:list = stim_groups
        self._total_duration:int = total_duration
        self._running:bool = True
        
        self.__check__()
        
    def __check__(self):
        if not self._device:
            raise ValueError("LSE实例不能为空")
        
        if not self._device.is_connected():
            raise ValueError("LSE设备未连接")
        
        if not self._stim_groups or len(self._stim_groups) == 0:
            raise ValueError("刺激配置必须是一个非空列表")
        
        if self._total_duration <= 0:
            raise ValueError("总刺激时间必须大于0")
        
        # 参数校验
        for cfg in self._stim_groups:
            public_params = cfg["public_parameters"]
            active_mods = cfg.get("active_modalities", [])
            
            if len(active_mods) == 0:
                raise ValueError(f"刺激配置必须包含至少一个激活的模态: {cfg}")
            if list(set(active_mods) - set([StimTypeEnum.ELECTRIC.value, StimTypeEnum.LIGHT.value, StimTypeEnum.SOUND.value])) != []:
                
                raise ValueError(f"未知的刺激模态: {active_mods}")
            
            if StimTypeEnum.ELECTRIC.value in active_mods:
                required_e_params = ["wave_form", "current_intensity", "anode_channels", "cathode_channels"]
                e_cfg = cfg.get("electric_config", [])
                if len(e_cfg) == 0:
                    raise ValueError(f"已选中电刺激，电刺激参数不能为空: {e_cfg}")
                for c in e_cfg:
                    for param in required_e_params:
                        if param not in c:
                            raise ValueError(f"电刺激配置缺少必要参数: {param}")
            if StimTypeEnum.LIGHT.value in active_mods:
                required_l_params = ["light_freq", "light_duty_cycle", "light_intensity"]
                l_cfg = cfg.get("light_config", [])
                if len(l_cfg) == 0:
                    raise ValueError(f"已选中光刺激，光刺激参数不能为空: {l_cfg}")
                for c in l_cfg:
                    for param in required_l_params:
                        if param not in c:
                            raise ValueError(f"光刺激配置缺少必要参数: {param}")
            if StimTypeEnum.SOUND.value in active_mods:
                required_s_params = ["sound_freq", "sound_duty_cycle", "audio_volume"]
                s_cfg = cfg.get("sound_config", [])
                if len(s_cfg) == 0:
                    raise ValueError(f"已选中声刺激，声刺激参数不能为空: {s_cfg}")
                for c in s_cfg:
                    for param in required_s_params:
                        if param not in c:
                            raise ValueError(f"声刺激配置缺少必要参数: {param}")

            
    '''刺激启动函数-用于多模态刺激管理'''
    def start(self):
        self._running = True
        # 创建监视器，控制最长刺激时间
        monitor = threading.Thread(target=self._stim_monitor, daemon=True)
        monitor.start()
        start_time = time.time()
        for cfg in self._stim_groups:
            if not self._running:
                break
            public_param = cfg.get("public_parameters", {})
            active_mods = cfg.get("active_modalities", [])
            # 电刺激参数
            electric_config = []
            if StimTypeEnum.ELECTRIC.value in active_mods:                
                electric_config = cfg.get("electric_config", {})
                param = {"duration": public_param.get("group_duration", 0) * 1000, "delay_us": public_param.get("post_group_interval", -1) * 1000}
                for c in electric_config:
                    c.update(param)  
                
            # 声光参数           
            light_cfg = []
            sound_cfg = [] 
            if StimTypeEnum.LIGHT.value in active_mods:
                light_cfg = cfg.get("light_config", [])   
                param = {"duration": public_param.get("group_duration", 0), "light_delay_us": public_param.get("post_group_interval", -1) * 1000}            
                for c in light_cfg:
                    c.update(param) 
            if StimTypeEnum.SOUND.value in active_mods:
                sound_cfg = cfg.get("sound_config", [])    
                param = {"duration": public_param.get("group_duration", 0), "sound_delay_us": public_param.get("post_group_interval", -1) * 1000}           
                for c in sound_cfg:
                    c.update(param) 
                    
            # 纯电刺激
            if len(active_mods) == 1 and StimTypeEnum.ELECTRIC.value in active_mods:
                self._start_e_stim(electric_config)
                continue
        
            if len(active_mods) == 1 and StimTypeEnum.LIGHT.value in active_mods:
                self._start_light_sound_stim(light_cfg)
                continue
            
            if len(active_mods) == 1 and StimTypeEnum.SOUND.value in active_mods:
                self._start_light_sound_stim(sound_cfg)
                continue
            
            # 声光配置
            light_sound_cfg = []
            if StimTypeEnum.LIGHT.value in active_mods and StimTypeEnum.SOUND.value in active_mods:
                light_sound_cfg = light_cfg + sound_cfg
            elif StimTypeEnum.LIGHT.value in active_mods:
                light_sound_cfg = light_cfg
            elif StimTypeEnum.SOUND.value in active_mods:
                light_sound_cfg = sound_cfg
                            
            # 纯光刺激
            if len(active_mods) < 3 and not StimTypeEnum.ELECTRIC.value in active_mods:
                self._start_light_sound_stim(light_sound_cfg)
            else:
                self._start_multimodal_stim(electric_config, light_sound_cfg)
            
        logger.info("电刺激已完成: 实际总执行时间: {:.2f}秒".format(time.time() - start_time))
        
        
    ''' ------ 内部函数分割线 ------'''    
    '''刺激监视器-用于控制最长刺激时间'''
    def _stim_monitor(self):
        import time
        start_time = time.time()
        offset = 0
        while offset < self._total_duration:
            time.sleep(0.01)  # 精度：0.01秒
            offset = (time.time() - start_time) * 1000
        logger.debug(f"刺激监视器触发，达到总刺激时间，正在停止刺激:{offset}")
        self._running = False        
        
    '''纯电刺激启动函数-用于纯电刺激管理'''
    def _start_e_stim(self, cfg):      
        try:  
            # 纯电刺激，调用电刺激接口
            flag = self._device.start_e_stim(cfg)
            logger.info(f"【多模态】电刺激配置及启动{'成功' if flag else '失败'}")
            stim_time = cfg[0].get('duration', 0) + cfg[0].get('ramp_up_ms', 0) + cfg[0].get('ramp_down_ms', 0)
            logger.debug(f"预计电刺激时间: {stim_time}毫秒")
            ref = time.time()
            offset = 0
            while offset < stim_time:
                if not self._running:
                    self._device.stop_e_stim()  # 停止刺激
                    break
                sleep(0.01)  # 等待刺激完成，精度：0.01秒  实际15ms +- 5ms， 受CPU调度影响较大
                offset = (time.time() - ref) * 1000
            logger.debug(f"电刺激完成，实际刺激时间: {(time.time() - ref)*1000}毫秒")
        except Exception as e:
            logger.error(f"电刺激配置或启动失败: {e}")
            self._device.stop_e_stim()  # 停止刺激
    
    '''声光刺激启动函数-用于纯声光刺激管理'''
    def _start_light_sound_stim(self, light_sound_cfg):    
        try:  
            flag = self._device.start_light_sound_stim(light_sound_cfg)  
            logger.info(f"【多模态】光声刺激配置及启动{'成功' if flag else '失败'}")
            stim_time = light_sound_cfg[0].get('duration', 0) 
            logger.debug(f"预计光声刺激时间: {stim_time}毫秒")
            ref = time.time()
            offset = 0
            while offset < stim_time:
                if not self._running:
                    self._device.stop_light_sound_stim()  # 停止刺激
                    break
                sleep(0.01)  # 等待刺激完成，精度：0.01秒  实际15ms +- 5ms， 受CPU调度影响较大
                offset = (time.time() - ref) * 1000
            logger.debug(f"光声刺激完成，实际刺激时间: {(time.time() - ref)*1000}毫秒")
        except Exception as e:
            logger.error(f"光声刺激配置或启动失败: {e}")
            self._device.stop_light_sound_stim()  # 停止刺激
        
    
    '''多模态刺激启动函数-用于多模态刺激管理'''
    def _start_multimodal_stim(self, electric_cfg, light_sound_cfg):
        try:
            self._device.config_e_stim(electric_cfg)
            
            # print("多模态刺激配置 - 光声刺激部分: ", light_sound_cfg)
            self._device.config_light_sound_stim(light_sound_cfg)
            sleep(1)
            self._device.start_e_light_sound_stim()
            
            stim_time = electric_cfg[0].get('duration', 0) + electric_cfg[0].get('ramp_up_ms', 0) + electric_cfg[0].get('ramp_down_ms', 0)
            logger.debug(f"预计多模态刺激时间: {stim_time}毫秒")
            ref = time.time()
            offset = 0
            while offset < stim_time:
                if not self._running:
                    self._device.stop_e_light_sound_stim()  # 停止刺激
                    break
                sleep(0.01)  # 等待刺激完成，精度：0.01秒  实际15ms +- 5ms， 受CPU调度影响较大
                offset = (time.time() - ref) * 1000
            logger.debug(f"多模态刺激完成，实际刺激时间: {(time.time() - ref)*1000}毫秒")
        except Exception as e:
            logger.error(f"多模态刺激配置或启动失败: {e}")
            self._device.stop_e_light_sound_stim()  # 停止刺激
        
            
        