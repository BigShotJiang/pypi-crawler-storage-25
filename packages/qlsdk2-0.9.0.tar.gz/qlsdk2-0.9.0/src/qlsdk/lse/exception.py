

class ArsLSError(Exception):
    """自定义协议错误异常类"""
    pass

class EStimConfigError(ArsLSError):
    """自定义设备错误异常类"""
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)
    def __str__(self):
        return f"电刺激参数异常：{self.message}"