from enum import IntEnum, unique
from typing import Dict


class LseControlMode(IntEnum):
    API = 0
    UI = 1
    
class LseConfigMode(IntEnum):
    CONFIG_THEN_STIM = 0    # 先配置参数再开始刺激
    CONFIG_ONLY = 1         # 只配置参数，不开始刺激
    STIM_ONLY = 2           # 直接开始刺激，忽略配置参数

@unique
class WaveFormEnum(IntEnum):
    '''刺激类型枚举类'''
    # 直流
    tDCS= 0
    # 方波
    SQUARE = 1
    # 交流
    tACS = 2
    # 脉冲
    PULSE = 4
    # 非对称CES
    nCES = 5
    # 随机噪声
    RANDOM = 6
    # 随机噪声-别名
    # tRNS = 6
    # 间歇性模式-脉冲的一种
    iTBS = 11
    # 连续性模式-脉冲的一种
    cTBS = 12

@unique
class ArsLSECommand(IntEnum):
    """
    设备指令枚举类
    使用 IntEnum 使得枚举值可以直接作为整数使用
    @unique 装饰器确保所有值都是唯一的
    """
    # 握手指令
    HAND_SHAKE = 0x01           # 握手
    
    # 电刺激相关指令
    STOP_E_STIM = 0x11          # 停止电刺激
    START_E_STIM = 0x17         # 开始电刺激
    GET_E_REMAIN_TIME = 0x18    # 获取剩余电刺激时间
    GET_E_PATTERN = 0x19        # 获取当前电刺激范式
    E_STIM_STATE_NOTIFY = 0x13  # 刺激状态通知(设备主动发)
    
    # 阻抗采集相关指令
    START_IMPEDANCE = 0x21      # 开始阻抗采集
    STOP_IMPEDANCE = 0x22       # 停止阻抗采集
    IMPEDANCE_DATA = 0x23       # 阻抗数据包(设备主动发)
    
    # 刺激电流相关
    E_CURRENT_DATA = 0x24       # 刺激电流推送(设备主动发)
    
    # 声光刺激相关指令
    SET_AL_STIM = 0x25          # 声光刺激配置
    STOP_AL_STIM = 0x26         # 声光刺激停止
    
    # 同步刺激指令
    SYNC_START_ALE = 0x27       # 光声电同步开始
    SYNC_STOP_ALE = 0x28        # 光声电同步结束
    GET_AL_REMAIN_TIME = 0x29   # 获取剩余声光刺激时间
    
    # 使用界面设置的参数开始刺激（不使用指令行参数）
    READY_FOR_UI_STIM = 0x2A        #准备刺激
    START_UI_STIM = 0x2B   #使用界面参数开始刺激
    STOP_UI_STIM = 0x2C    #停止界面参数刺激
    
    # 获取可用音频列表
    CONFIG_AL_STIM = 0x2D          # 声光刺激配置
    GET_AUDIO_LIST = 0x2E    # 获取可用音频列表
    RESP_AL_STIM = 0x2F    # 声光配置结果

# 可选：创建反向查找字典
CMD_DESCRIPTION: Dict[ArsLSECommand, str] = {
    ArsLSECommand.HAND_SHAKE: "握手",
    ArsLSECommand.STOP_E_STIM: "停止电刺激",
    ArsLSECommand.START_E_STIM: "开始电刺激",
    ArsLSECommand.GET_E_REMAIN_TIME: "获取剩余电刺激时间",
    ArsLSECommand.GET_E_PATTERN: "获取当前电刺激范式",
    ArsLSECommand.E_STIM_STATE_NOTIFY: "刺激状态通知(设备主动发)",
    ArsLSECommand.START_IMPEDANCE: "开始阻抗采集",
    ArsLSECommand.STOP_IMPEDANCE: "停止阻抗采集",
    ArsLSECommand.IMPEDANCE_DATA: "阻抗数据包(设备主动发)",
    ArsLSECommand.E_CURRENT_DATA: "刺激电流推送(设备主动发)",
    ArsLSECommand.SET_AL_STIM: "声光刺激配置",
    ArsLSECommand.STOP_AL_STIM: "声光刺激停止",
    ArsLSECommand.SYNC_START_ALE: "光声电同步开始",
    ArsLSECommand.SYNC_STOP_ALE: "光声电同步结束",
    ArsLSECommand.GET_AL_REMAIN_TIME: "获取剩余声光刺激时间",
    ArsLSECommand.READY_FOR_UI_STIM : "准备刺激（使用UI参数）",
    ArsLSECommand.START_UI_STIM : "开始刺激（使用UI参数）",
    ArsLSECommand.STOP_UI_STIM : "停止刺激（使用UI参数）",
    ArsLSECommand.CONFIG_AL_STIM : "配置声光刺激",
    ArsLSECommand.GET_AUDIO_LIST : "获取可用音频列表",
    ArsLSECommand.RESP_AL_STIM : "光声刺激状态"
}    